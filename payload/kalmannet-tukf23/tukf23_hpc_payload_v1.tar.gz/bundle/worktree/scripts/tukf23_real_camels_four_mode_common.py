"""TUKF23 four-mode formal experiment: portable common machinery.

Reuses the audited TUKF17 numerical core and the TUKF21 real-catchment
plumbing (c21) unchanged, but makes every external root overridable through
environment variables so the identical code runs on Windows and on the HPC:

    TUKF23_KALMANNET_RO   root of the read-only kalmannet repo (or bundle copy)
    TUKF23_NH_ROOT        root of the neuralhydrology repo (or bundle copy)
    TUKF23_CAMELS_ROOT    CAMELS-US data root
    TUKF23_CONFIG         path to the frozen TUKF23 config

Heavy package __init__ chains (global_hydrology, hydroagent) are bypassed by
registering lightweight namespace packages BEFORE importing c21, so local and
HPC runs take the identical import path.
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
import types
from pathlib import Path

import numpy as np
import torch

WORKTREE = Path(__file__).resolve().parents[1]
KALMANNET_RO = Path(os.environ.get(
    "TUKF23_KALMANNET_RO", "G:/github/pycharm/projects/kalmannet"))
NH_ROOT = Path(os.environ.get(
    "TUKF23_NH_ROOT", "G:/github/pycharm/projects/neuralhydrology"))
DEFAULT_CONFIG = Path(os.environ.get(
    "TUKF23_CONFIG", str(WORKTREE / "configs/tukf23_real_camels_four_mode_formal_v1.json")))

ROOTS = {"worktree": WORKTREE, "kalmannet": KALMANNET_RO, "nh": NH_ROOT}

EXPERIMENT_ID = "TUKF23_REAL_CAMELS_FOUR_MODE_FORMAL_V1"


def _register_namespace_package(name: str, path: Path) -> None:
    """Register a package by directory without executing its __init__.py."""
    if name in sys.modules:
        return
    module = types.ModuleType(name)
    module.__path__ = [str(path)]
    module.__package__ = name
    sys.modules[name] = module


def _bootstrap_imports() -> None:
    _register_namespace_package("global_hydrology", KALMANNET_RO / "src/global_hydrology")
    _register_namespace_package("global_hydrology.models",
                                KALMANNET_RO / "src/global_hydrology/models")
    _register_namespace_package("global_hydrology.assimilation",
                                KALMANNET_RO / "src/global_hydrology/assimilation")
    _register_namespace_package("hydroagent", NH_ROOT / "src/hydroagent")
    for entry in (str(WORKTREE / "scripts"), str(KALMANNET_RO), str(KALMANNET_RO / "src"),
                  str(NH_ROOT / "src")):
        if entry not in sys.path:
            sys.path.insert(0, entry)


_bootstrap_imports()

import tukf17_hbv_rolling_origin_state_hydrology_common as t17  # noqa: E402
import tukf21_real_camels_rolling_origin_common as c21  # noqa: E402

DTYPE = c21.DTYPE
LEADS = (1, 2, 3)
MODES = ("all_frozen", "hydrology_only", "filter_only", "joint")
TRAINABLE_MODES = ("hydrology_only", "filter_only", "joint")


def sha256_file(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_contract(path: Path | str = DEFAULT_CONFIG, *, verify_hashes: bool = True) -> dict:
    contract = json.loads(Path(path).read_text(encoding="utf-8"))
    if contract["experiment_id"] != EXPERIMENT_ID:
        raise ValueError("wrong experiment id")
    if verify_hashes:
        for key, entry in contract["frozen_input_sha256"].items():
            file_path = ROOTS[entry["root"]] / entry["rel"]
            actual = sha256_file(file_path)
            if actual != entry["sha256"]:
                raise ValueError(
                    f"frozen input drifted: {key}: recorded {entry['sha256']} actual {actual}")
    return contract


def camels_root(contract: dict) -> str:
    env = os.environ.get("TUKF23_CAMELS_ROOT")
    if env:
        return env
    local = contract["data"]["camels_root_local"]
    if Path(local).exists():
        return local
    hpc = contract["data"]["camels_root_hpc"]
    if Path(hpc).exists():
        return hpc
    raise FileNotFoundError("no CAMELS root found; set TUKF23_CAMELS_ROOT")


def c21_view(contract: dict) -> dict:
    """Shape the TUKF23 contract so c21 loader/model functions accept it."""
    return {
        "data": {
            "camels_root": camels_root(contract),
            "window": contract["data"]["window"],
            "forcing": contract["data"]["forcing"],
            "pet_method": contract["data"]["pet_method"],
        },
        "prior": {
            "csv": str(ROOTS[contract["prior"]["csv_root"]] / contract["prior"]["csv_rel"]),
            "param_columns": contract["prior"]["param_columns"],
            "state_columns": contract["prior"]["state_columns"],
        },
        "noise_construction": {
            "observation_ratio_initial": contract["noise_construction"]["observation_ratio_initial"],
            "process_noise_bounds": contract["noise_construction"]["process_noise_bounds"],
            "observation_ratio_bounds": contract["noise_construction"]["observation_ratio_bounds"],
            "state_scale_floor": contract["noise_construction"]["state_scale_floor"],
        },
        "segments_day_index": contract["segments_day_index"],
        "anchor_gate": contract["anchor_gate"],
    }


def build_noise(contract: dict, dim_x: int, open_loop_states: torch.Tensor,
                residual_std: float, mean_flow: float) -> dict:
    """TUKF22 iteration-2 noise construction, frozen verbatim."""
    nc = contract["noise_construction"]
    process = torch.empty(dim_x, dtype=DTYPE)
    process[:5] = torch.tensor(nc["storage_process_variance"], dtype=DTYPE)
    if dim_x > 5:
        routing_var = max((nc["routing_process_fraction"] * mean_flow) ** 2,
                          nc["routing_variance_floor"])
        process[5:] = routing_var
    scales = torch.clamp(open_loop_states.std(dim=0), min=nc["state_scale_floor"])
    covariance = torch.diag_embed(
        (nc["initial_covariance_fraction"] * scales) ** 2).unsqueeze(0)
    base_var = max((nc["observation_floor_residual_fraction"] * residual_std) ** 2,
                   nc["observation_variance_floor_min"])
    return {
        "process_variance": process,
        "observation_ratio": float(nc["observation_ratio_initial"]),
        "initial_covariance": covariance,
        "base_observation_variance": float(base_var),
        "state_scales": scales,
    }


def prepare_basin(contract: dict, basin_id: str) -> dict:
    """Load arrays, run the anchor gate, build the constructed noise.

    Returns everything a worker stage needs. Raises on anchor failure.
    """
    view = c21_view(contract)
    prior = c21.load_prior_table(view)
    matches = prior.loc[prior["basin_id"] == basin_id]
    if len(matches) != 1:
        raise ValueError(f"{basin_id}: expected exactly one prior row, got {len(matches)}")
    row = matches.iloc[0]
    arrays = c21.load_basin_arrays(view, basin_id)
    forcing, obs = arrays["forcing"], arrays["obs"]

    probe = c21.build_basin_model(view, row)
    dim_x = int(probe.dim_x)
    x0 = c21.initial_state(view, row, dim_x)
    with torch.no_grad():
        ol_full = t17.rollout_open_loop_states(probe, forcing, x0, forcing.shape[0])
        sim_full = probe.h(ol_full[1:])[:, 0].cpu().numpy()
    anchor_delta = abs(c21.nse(sim_full, obs) - float(row["nse"]))
    if anchor_delta > float(contract["anchor_gate"]["tolerance"]):
        raise RuntimeError(f"{basin_id}: anchor gate failed ({anchor_delta:.3e})")

    stat_end = int(contract["noise_construction"]["statistic_window_day_indices"][1])
    residual_std = float(np.std(sim_full[:stat_end] - obs[:stat_end]))
    mean_flow = float(np.mean(obs[:stat_end]))
    noise = build_noise(contract, dim_x, ol_full[:stat_end], residual_std, mean_flow)

    return {
        "view": view, "row": row, "forcing": forcing, "obs": obs,
        "dim_x": dim_x, "x0": x0, "anchor_delta": float(anchor_delta),
        "published_nse": float(row["nse"]),
        "residual_std_train": residual_std, "mean_flow_train": mean_flow,
        "noise": noise,
    }


def build_mode_model(contract: dict, prep: dict):
    """Fresh model at the identical four-mode starting point."""
    model = c21.build_basin_model(
        prep["view"], prep["row"],
        process_variance=prep["noise"]["process_variance"].numpy(),
        observation_ratio=prep["noise"]["observation_ratio"])
    return model


def mode_groups(contract: dict, model, mode: str) -> tuple[list, list]:
    """(hydrology group, filter group) with requires_grad set per the mask."""
    mask = contract["modes"]["masks"][mode]
    hyd = [model.hydrology_coordinates]
    fil = [model.log_process_diagonal, model.log_observation_ratio]
    for p in hyd:
        p.requires_grad_(bool(mask["hydrology"]))
    for p in fil:
        p.requires_grad_(bool(mask["filter"]))
    return hyd, fil


def segment_origins(contract: dict, name: str) -> tuple[int, ...]:
    lo, hi = contract["segments_day_index"][f"{name}_origins"]
    return tuple(range(int(lo), int(hi) + 1))


def snapshot(model) -> dict:
    return {"h": model.hydrology_coordinates.detach().clone(),
            "q": model.log_process_diagonal.detach().clone(),
            "r": model.log_observation_ratio.detach().clone()}


def restore_(model, snap: dict) -> None:
    with torch.no_grad():
        model.hydrology_coordinates.copy_(snap["h"])
        model.log_process_diagonal.copy_(snap["q"])
        model.log_observation_ratio.copy_(snap["r"])


def snapshot_to_lists(snap: dict) -> dict:
    return {k: [float(v) for v in t.reshape(-1)] for k, t in snap.items()}


def snapshot_from_lists(model, lists: dict) -> dict:
    return {
        "h": torch.tensor(lists["h"], dtype=DTYPE).reshape(model.hydrology_coordinates.shape),
        "q": torch.tensor(lists["q"], dtype=DTYPE).reshape(model.log_process_diagonal.shape),
        "r": torch.tensor(lists["r"], dtype=DTYPE).reshape(model.log_observation_ratio.shape),
    }


def environment_stamp() -> dict:
    import platform
    return {
        "python": platform.python_version(),
        "torch": torch.__version__,
        "numpy": np.__version__,
        "platform": platform.platform(),
        "node": platform.node(),
    }
