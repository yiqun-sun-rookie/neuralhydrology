"""Runner for the denormalized (absolute-std) transfer control (prereg frozen 2026-09-02).

Preregistration:
docs/plans/2026-09-02-noise-axis-denormalized-transfer-control-prereg-v01.md

Phases (run in order from the payload/repository root):
    p0       replicate registered ratio-transfer cells + diagonal identity (aborts on failure)
    matrix   52 receivers x (52 absolute donors + e1 + m1_c0 + ratio self) ~ 2,860 filter runs
    settle   gain matrix, e1/e2/oracle arms, the frozen outcome rule

Usage:
    python src/camels_switch_confirmation/scripts/run_noise_axis_denormalized_transfer.py <phase> [--workers N]
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

_SRC = Path(__file__).resolve().parents[2]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from camels_switch_confirmation import noise_axis_denormalized_transfer as dn  # noqa: E402

RECEIVERS_DIR = dn.OUTPUT_ROOT / "receivers"


def _worker(basin: str) -> dict:
    out_path = RECEIVERS_DIR / f"{basin}.json"
    if out_path.exists():
        return {"basin_id": basin, "skipped": True}
    record = dn.run_receiver(basin)
    tmp = out_path.with_suffix(".tmp")
    tmp.write_text(json.dumps(record, indent=1), encoding="utf-8")
    tmp.replace(out_path)
    return {"basin_id": basin, "skipped": False, "status": record["status"]}


def phase_p0() -> int:
    report = dn.p0_check()
    dn.OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    (dn.OUTPUT_ROOT / "p0_report.json").write_text(json.dumps(report, indent=1), encoding="utf-8")
    print(json.dumps(report, indent=1))
    print("P0", "PASS" if report["passed"] else "FAIL", f"worst_abs_diff={report['worst_abs_diff']:.3e}")
    return 0 if report["passed"] else 1


def phase_matrix(workers: int) -> int:
    RECEIVERS_DIR.mkdir(parents=True, exist_ok=True)
    basins = list(dn.load_rho_table().index)
    pending = [b for b in basins if not (RECEIVERS_DIR / f"{b}.json").exists()]
    print(f"receivers: {len(basins)}; pending: {len(pending)}; workers: {workers}", flush=True)
    started = time.perf_counter()
    done = 0
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for outcome in pool.map(_worker, pending, chunksize=1):
            done += 1
            elapsed = time.perf_counter() - started
            print(f"  {done}/{len(pending)} {outcome.get('status', 'skipped')}  elapsed {elapsed/60:.1f} min",
                  flush=True)
    print(f"matrix phase complete in {(time.perf_counter() - started)/60:.1f} min", flush=True)
    return 0


def phase_settle() -> int:
    records = []
    for path in sorted(RECEIVERS_DIR.glob("*.json")):
        records.append(json.loads(path.read_text(encoding="utf-8")))
    summary = dn.settle(records)
    (dn.OUTPUT_ROOT / "summary.json").write_text(json.dumps(summary, indent=1), encoding="utf-8")
    rows = []
    for r in records:
        if r["status"] != "success":
            rows.append({"basin_id": r["basin_id"], "status": r["status"], "error": r.get("error", "")})
            continue
        rows.append({"basin_id": r["basin_id"], "status": "success",
                     "m1c0_nse_holdout": r["m1c0_nse_holdout"],
                     "absolute_e1_nse": r["absolute_e1_nse"],
                     "ratio_self_nse": r["ratio_self_nse"],
                     "absolute_self_nse": r["absolute"][r["basin_id"]],
                     "diag_abs_diff": r["diag_abs_diff"]})
    import pandas as pd  # noqa: E402
    pd.DataFrame(rows).sort_values("basin_id").to_csv(dn.OUTPUT_ROOT / "receivers_per_basin.csv", index=False)
    matrix = pd.DataFrame({r["basin_id"]: r["absolute"] for r in records if r["status"] == "success"})
    matrix.index.name = "donor"
    matrix.to_csv(dn.OUTPUT_ROOT / "absolute_matrix_nse_holdout.csv")
    print(json.dumps(summary, indent=1))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=["p0", "matrix", "settle"])
    parser.add_argument("--workers", type=int, default=6)
    arguments = parser.parse_args()
    if arguments.phase == "p0":
        return phase_p0()
    if arguments.phase == "matrix":
        return phase_matrix(arguments.workers)
    return phase_settle()


if __name__ == "__main__":
    sys.exit(main())
