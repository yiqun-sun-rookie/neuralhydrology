"""Assemble the self-contained HPC payload for the id29 transferable-noise experiments.

Stages a mini-repository (same relative layout the import chain expects), writes a
SHA-256 manifest, tars it, and drops the tarball into the mailbox payload directory.
Read-only with respect to the repository; writes only under --staging and --mailbox.

Usage (from the repository root):
    python src/camels_switch_confirmation/scripts/build_hpc_payload_id29.py \
        --staging <dir> --mailbox <hpc-mailbox worktree>
"""
from __future__ import annotations

import argparse
import hashlib
import shutil
import tarfile
from pathlib import Path

NAME = "id29_transferable_noise_20260902"
CHANNEL = "id29-transferable-noise"

PACKAGE_DIRS = (
    "src/camels_switch_confirmation",
    "src/hbv_joint_uncertainty",
    "src/scl_hydro",
    "src/hydroagent",
)
PACKAGE_INCLUDE_SUFFIXES = {".py", ".json", ".slurm"}
PACKAGE_EXCLUDE_PARTS = {"__pycache__", "tests", "test", ".pytest_cache"}

FILES = (
    "docs/plans/2026-08-10-camels-parfc-state-interaction-design90-coverage-v01.csv",
    "docs/plans/2026-09-01-noise-axis-391-global-card-confirmation-prereg-v01.md",
    "docs/plans/2026-09-02-noise-axis-denormalized-transfer-control-prereg-v01.md",
    "docs/plans/2026-09-02-noise-axis-391-confirmation-addendum-01-extra-grid-cells-prereg.md",
    "docs/plans/2026-09-02-noise-axis-training-length-sensitivity-prereg-v01.md",
    "results/10_global_conceptual_model_benchmark/camels_us_531_repro_v01/summary/hbv_lite_cma_rising_local_full.csv",
    "results/23_camels_switch_confirmation/g1_precheck_v01/g1_precheck.csv",
    "results/23_camels_switch_confirmation/noise_axis_step2_learned_q_20260827_local/evaluation_per_basin.csv",
    "results/23_camels_switch_confirmation/noise_axis_step2_learned_q_20260827_local/amplitudes_frozen.csv",
    "results/23_camels_switch_confirmation/noise_axis_step2_learned_q_20260827_local/baselines_per_basin.csv",
    "results/23_camels_switch_confirmation/noise_axis_transfer_loo_20260828_local/transfer_per_basin.csv",
    "results/23_camels_switch_confirmation/noise_axis_transfer_loo_20260828_local/borrow_matrix_nse_holdout.csv",
    "results/23_camels_switch_confirmation/noise_axis_transfer_loo_20260828_local/transfer_summary.json",
    "results/23_camels_switch_confirmation/noise_axis_391_global_card_confirmation_20260901_local/frozen_basin_list.csv",
    "results/23_camels_switch_confirmation/noise_axis_391_global_card_confirmation_20260901_local/confirmation_per_basin.csv",
    "results/23_camels_switch_confirmation/noise_axis_391_global_card_confirmation_20260901_local/summary.json",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def collect(repo: Path) -> list[Path]:
    files: list[Path] = []
    for directory in PACKAGE_DIRS:
        for path in (repo / directory).rglob("*"):
            if not path.is_file() or path.suffix not in PACKAGE_INCLUDE_SUFFIXES:
                continue
            if any(part in PACKAGE_EXCLUDE_PARTS for part in path.relative_to(repo).parts):
                continue
            files.append(path.relative_to(repo))
    for rel in FILES:
        if not (repo / rel).is_file():
            raise FileNotFoundError(rel)
        files.append(Path(rel))
    return sorted(set(files))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", default=".")
    parser.add_argument("--staging", required=True)
    parser.add_argument("--mailbox", required=True)
    arguments = parser.parse_args()
    repo = Path(arguments.repo).resolve()
    staging = Path(arguments.staging).resolve() / NAME
    if staging.exists():
        shutil.rmtree(staging)
    staging.mkdir(parents=True)
    staged: list[Path] = []
    for rel in collect(repo):
        target = staging / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(repo / rel, target)
        staged.append(rel)
    # normalise line endings for every text file that will execute on Linux -- BEFORE hashing,
    # otherwise the manifest describes the CRLF bytes and `sha256sum -c` fails on the cluster
    for path in staging.rglob("*"):
        if path.suffix in {".py", ".slurm", ".sh"}:
            data = path.read_bytes().replace(b"\r\n", b"\n")
            path.write_bytes(data)
    manifest_lines = [f"{sha256(staging / rel)}  {rel.as_posix()}" for rel in staged]
    (staging / "MANIFEST.sha256").write_text("\n".join(manifest_lines) + "\n", encoding="utf-8", newline="\n")
    tarball = staging.parent / f"{NAME}.tar.gz"
    with tarfile.open(tarball, "w:gz") as archive:
        archive.add(staging, arcname=NAME)
    mailbox_dir = Path(arguments.mailbox).resolve() / "payload" / CHANNEL
    mailbox_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(tarball, mailbox_dir / tarball.name)
    print(f"files: {len(manifest_lines)}")
    print(f"tarball: {tarball} ({tarball.stat().st_size / 1e6:.2f} MB)")
    print(f"tarball sha256: {sha256(tarball)}")
    print(f"copied to: {mailbox_dir / tarball.name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
