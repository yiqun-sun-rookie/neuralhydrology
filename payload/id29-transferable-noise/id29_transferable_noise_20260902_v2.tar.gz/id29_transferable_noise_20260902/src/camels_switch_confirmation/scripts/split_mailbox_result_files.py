"""Split a mailbox result text that concatenates files behind `=== FILE <relpath> ===` markers.

The HPC retrieval command prints each result file between
    === FILE <path relative to the landing dir> ===
    ...
    === END FILE ===
This tool writes them back under a local root with the same relative paths.
Read-only with respect to everything except --out.

Usage:
    python split_mailbox_result_files.py --result <result_N.txt> --out <local root> [--dry-run]
"""
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

START = "=== FILE "
END = "=== END FILE ==="


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--result", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--dry-run", action="store_true")
    arguments = parser.parse_args()
    text = Path(arguments.result).read_text(encoding="utf-8", errors="replace")
    out = Path(arguments.out)
    lines = text.splitlines()
    i, written = 0, []
    while i < len(lines):
        line = lines[i]
        if line.startswith(START) and line.endswith(" ==="):
            rel = line[len(START):-4].strip()
            body: list[str] = []
            i += 1
            while i < len(lines) and lines[i] != END:
                body.append(lines[i])
                i += 1
            content = "\n".join(body) + ("\n" if body else "")
            target = out / rel
            digest = hashlib.sha256(content.encode("utf-8")).hexdigest()
            written.append((rel, len(content), digest))
            if not arguments.dry_run:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(content, encoding="utf-8", newline="\n")
        i += 1
    for rel, size, digest in written:
        print(f"{digest[:16]}  {size:>9d}  {rel}")
    print(f"files: {len(written)}  ({'dry-run' if arguments.dry_run else 'written under ' + str(out)})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
