"""Runner for the one-shot 391-basin global-card confirmation (prereg frozen 2026-09-01).

Preregistration:
docs/plans/2026-09-01-noise-axis-391-global-card-confirmation-prereg-v01.md

Phases (run in order from the repository root):
    p0           replicate 2 registered dev numbers through the new task builder (no credential)
    freeze-list  mechanical screening of the candidate holdout basins (credential required)
    run          the formal five-arm evaluation, resumable per basin (credential required)
    summarize    paired statistics and the two frozen gates

Usage:
    python src/camels_switch_confirmation/scripts/run_noise_axis_391_confirmation.py <phase> [--workers 6]
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import numpy as np
import pandas as pd

_SRC = Path(__file__).resolve().parents[2]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from camels_switch_confirmation import noise_axis_391_confirmation as conf  # noqa: E402

PREREGISTRATION = "docs/plans/2026-09-01-noise-axis-391-global-card-confirmation-prereg-v01.md"
BASINS_DIR = conf.OUTPUT_ROOT / "basins"
FROZEN_LIST = conf.OUTPUT_ROOT / "frozen_basin_list.csv"


def _worker_screen(basin: str) -> dict:
    return conf.screen_one(basin)


def _worker_run(basin: str) -> dict:
    out_path = BASINS_DIR / f"{basin}.json"
    if out_path.exists():
        return {"basin_id": basin, "skipped": True}
    cards = conf.load_cards()
    record = conf.run_basin_all_arms(basin, cards)
    tmp = out_path.with_suffix(".tmp")
    tmp.write_text(json.dumps(record, indent=1), encoding="utf-8")
    tmp.replace(out_path)
    return {"basin_id": basin, "skipped": False, "status": record["status"]}


def phase_p0() -> int:
    report = conf.p0_check()
    print(json.dumps(report, indent=1))
    print("P0", "PASS" if report["passed"] else "FAIL",
          f"worst_abs_diff={report['worst_abs_diff']:.3e}")
    return 0 if report["passed"] else 1


def phase_freeze_list(workers: int) -> int:
    conf.OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    universe = conf.candidate_universe()
    print(f"candidate universe (531 minus design90): {len(universe)}")
    started = time.perf_counter()
    with ProcessPoolExecutor(max_workers=workers) as pool:
        rows = list(pool.map(_worker_screen, universe, chunksize=4))
    frame = pd.DataFrame(rows).sort_values("basin_id")
    frame.to_csv(FROZEN_LIST, index=False)
    included = int(frame["included"].sum())
    print(f"included {included} / {len(universe)}  "
          f"(elapsed {time.perf_counter() - started:.0f}s)")
    for _, row in frame[~frame["included"]].iterrows():
        print("  excluded", row["basin_id"], "--", row["reason"][:120])
    return 0


def phase_run(workers: int) -> int:
    frame = pd.read_csv(FROZEN_LIST, dtype={"basin_id": str})
    basins = sorted(frame.loc[frame["included"], "basin_id"].str.zfill(8))
    BASINS_DIR.mkdir(parents=True, exist_ok=True)
    pending = [b for b in basins if not (BASINS_DIR / f"{b}.json").exists()]
    print(f"frozen list: {len(basins)} basins; pending: {len(pending)}")
    started = time.perf_counter()
    done = 0
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for outcome in pool.map(_worker_run, pending, chunksize=1):
            done += 1
            if done % 20 == 0 or done == len(pending):
                elapsed = time.perf_counter() - started
                print(f"  {done}/{len(pending)}  elapsed {elapsed/60:.1f} min  "
                      f"eta {elapsed / done * (len(pending) - done) / 60:.1f} min", flush=True)
    print(f"run phase complete in {(time.perf_counter() - started)/60:.1f} min")
    return 0


def phase_summarize() -> int:
    frame = pd.read_csv(FROZEN_LIST, dtype={"basin_id": str})
    basins = sorted(frame.loc[frame["included"], "basin_id"].str.zfill(8))
    records = []
    for basin in basins:
        path = BASINS_DIR / f"{basin}.json"
        if path.exists():
            records.append(json.loads(path.read_text(encoding="utf-8")))
    rows, failures = [], []
    for record in records:
        if record["status"] != "success":
            failures.append({"basin_id": record["basin_id"], "error": record.get("error", "")})
            continue
        row = {"basin_id": record["basin_id"], "sigma_obs": record["sigma_obs"]}
        for arm, outcome in record["arms"].items():
            if outcome["status"] == "success":
                row[f"{arm}_nse_score"] = outcome["nse_score"]
                row[f"{arm}_nse_full"] = outcome["nse_full"]
            else:
                failures.append({"basin_id": record["basin_id"], "arm": arm,
                                 "error": outcome.get("error", "")})
        rows.append(row)
    table = pd.DataFrame(rows).sort_values("basin_id")
    table.to_csv(conf.OUTPUT_ROOT / "confirmation_per_basin.csv", index=False)

    summary: dict = {
        "preregistration": PREREGISTRATION,
        "n_frozen": len(basins),
        "n_success_records": len(rows),
        "n_failures": len(failures),
        "failures": failures,
        "arms": {},
        "gates": {},
    }
    for arm in conf.ALL_ARMS:
        col = f"{arm}_nse_score"
        if col in table:
            values = table[col].dropna()
            summary["arms"][arm] = {
                "n": int(values.size),
                "median_nse_score": float(values.median()),
            }
    for arm in ("card_median52", "card_selected_noleak", "card_selected_frozen", "m1_c0"):
        base = "open_loop" if arm == "m1_c0" else "m1_c0"
        cols = [f"{arm}_nse_score", f"{base}_nse_score"]
        paired = table.dropna(subset=[c for c in cols if c in table])
        if not all(c in paired for c in cols):
            continue
        gain = paired[cols[0]] - paired[cols[1]]
        entry = {
            "vs": base,
            "n_paired": int(gain.size),
            "gain_median": float(gain.median()),
            "n_improved": int((gain > 0).sum()),
        }
        if arm in ("card_median52", "card_selected_noleak"):
            entry["gate_G1"] = bool(gain.median() > 0.0
                                    and (gain > 0).sum() > conf.G1_MEDIAN_WINS_MIN * gain.size)
            entry["gate_G2"] = bool(gain.median() > conf.G2_GAIN_THRESHOLD)
        summary["gates"][arm] = entry
    (conf.OUTPUT_ROOT / "summary.json").write_text(
        json.dumps(summary, indent=1), encoding="utf-8")
    print(json.dumps(summary["gates"], indent=1))
    print("arms:", json.dumps(summary["arms"], indent=1))
    return 0


# ---- addendum 01 (prereg frozen 2026-09-02): four extra hand-set grid cells on the 391 ----
# docs/plans/2026-09-02-noise-axis-391-confirmation-addendum-01-extra-grid-cells-prereg.md
EXTRA_CELLS = (0.1, 0.3, 3.0, 10.0)
EXTRA_DIR = conf.OUTPUT_ROOT / "extra_cells"
ALL_CELL_TAGS = ("m0.1_c0", "m0.3_c0", "m1_c0", "m3_c0", "m10_c0")


def _worker_extra(basin: str) -> dict:
    out_path = EXTRA_DIR / f"{basin}.json"
    if out_path.exists():
        return {"basin_id": basin, "skipped": True}
    record: dict = {"basin_id": basin, "status": "success", "cells": {}}
    try:
        task = conf.build_task(basin, conf.HOLDOUT_START, conf.HOLDOUT_DAYS)
    except Exception as exc:  # noqa: BLE001
        record["status"] = "task_failed"
        record["error"] = f"{type(exc).__name__}: {exc}"
    else:
        for m in EXTRA_CELLS:
            tag = f"m{m:g}_c0"
            try:
                outcome = conf.filter_arm_nse(task, basin, conf.LegacyGridNoise(m=m, c=0.0), conf.INIT_DAYS)
                record["cells"][tag] = {"status": "success", **outcome}
            except Exception as exc:  # noqa: BLE001
                record["cells"][tag] = {"status": "failed", "error": f"{type(exc).__name__}: {exc}"}
    tmp = out_path.with_suffix(".tmp")
    tmp.write_text(json.dumps(record, indent=1), encoding="utf-8")
    tmp.replace(out_path)
    return {"basin_id": basin, "skipped": False, "status": record["status"]}


def phase_extra_cells(workers: int) -> int:
    frame = pd.read_csv(FROZEN_LIST, dtype={"basin_id": str})
    basins = sorted(frame.loc[frame["included"], "basin_id"].str.zfill(8))
    EXTRA_DIR.mkdir(parents=True, exist_ok=True)
    pending = [b for b in basins if not (EXTRA_DIR / f"{b}.json").exists()]
    print(f"frozen list: {len(basins)} basins; pending: {len(pending)}; workers: {workers}", flush=True)
    started = time.perf_counter()
    done = 0
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for _ in pool.map(_worker_extra, pending, chunksize=1):
            done += 1
            if done % 20 == 0 or done == len(pending):
                elapsed = time.perf_counter() - started
                print(f"  {done}/{len(pending)}  elapsed {elapsed/60:.1f} min", flush=True)
    print(f"extra-cells phase complete in {(time.perf_counter() - started)/60:.1f} min", flush=True)
    return 0


def phase_summarize_extra() -> int:
    main_table = pd.read_csv(conf.OUTPUT_ROOT / "confirmation_per_basin.csv", dtype={"basin_id": str})
    main_table["basin_id"] = main_table["basin_id"].str.zfill(8)
    rows, failures = [], []
    for basin in main_table["basin_id"]:
        path = EXTRA_DIR / f"{basin}.json"
        if not path.exists():
            continue
        record = json.loads(path.read_text(encoding="utf-8"))
        row = {"basin_id": basin}
        if record["status"] != "success":
            failures.append({"basin_id": basin, "error": record.get("error", "")})
        for tag, outcome in record.get("cells", {}).items():
            if outcome["status"] == "success":
                row[f"{tag}_nse_score"] = outcome["nse_score"]
            else:
                failures.append({"basin_id": basin, "cell": tag, "error": outcome.get("error", "")})
        rows.append(row)
    extra = pd.DataFrame(rows)
    table = main_table.merge(extra, on="basin_id", how="inner")
    cell_cols = [f"{t}_nse_score" for t in ALL_CELL_TAGS if f"{t}_nse_score" in table]
    complete = table.dropna(subset=cell_cols + ["card_median52_nse_score", "card_selected_noleak_nse_score"])
    cell_medians = {c.replace("_nse_score", ""): float(complete[c].median()) for c in cell_cols}
    best_single = max(cell_medians, key=cell_medians.get)
    complete = complete.assign(best_per_basin_cell_nse=complete[cell_cols].max(axis=1))
    summary: dict = {
        "addendum": "docs/plans/2026-09-02-noise-axis-391-confirmation-addendum-01-extra-grid-cells-prereg.md",
        "n_complete": int(len(complete)),
        "n_failures": len(failures),
        "failures": failures,
        "cell_median_nse_score": cell_medians,
        "best_single_cell": best_single,
        "comparisons": {},
    }
    for card in ("card_median52", "card_selected_noleak"):
        for base_name, base_values in (
            (f"best_single_cell[{best_single}]", complete[f"{best_single}_nse_score"]),
            ("best_per_basin_cell", complete["best_per_basin_cell_nse"]),
        ):
            gain = complete[f"{card}_nse_score"] - base_values
            median = float(gain.median())
            improved = int((gain > 0).sum())
            if base_name.startswith("best_single_cell"):
                if median > 0.01 and improved > 195:
                    verdict = "confirmed_vs_391_best_single_cell"
                elif median > 0.0:
                    verdict = "weak_confirmation_direction_only"
                else:
                    verdict = "not_better_than_391_best_single_cell"
            else:
                verdict = "reported_only"
            summary["comparisons"][f"{card} vs {base_name}"] = {
                "n_paired": int(gain.size), "gain_median": median,
                "n_improved": improved, "verdict": verdict,
            }
    complete.to_csv(conf.OUTPUT_ROOT / "extra_cells_per_basin.csv", index=False)
    (conf.OUTPUT_ROOT / "extra_cells_summary.json").write_text(json.dumps(summary, indent=1), encoding="utf-8")
    print(json.dumps(summary, indent=1))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=["p0", "freeze-list", "run", "summarize",
                                          "extra-cells", "summarize-extra"])
    parser.add_argument("--workers", type=int, default=6)
    arguments = parser.parse_args()
    if arguments.phase == "p0":
        return phase_p0()
    if arguments.phase == "freeze-list":
        return phase_freeze_list(arguments.workers)
    if arguments.phase == "run":
        return phase_run(arguments.workers)
    if arguments.phase == "extra-cells":
        return phase_extra_cells(arguments.workers)
    if arguments.phase == "summarize-extra":
        return phase_summarize_extra()
    return phase_summarize()


if __name__ == "__main__":
    sys.exit(main())
