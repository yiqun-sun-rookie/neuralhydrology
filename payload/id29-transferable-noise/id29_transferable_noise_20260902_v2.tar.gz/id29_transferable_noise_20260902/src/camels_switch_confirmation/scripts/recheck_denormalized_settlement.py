"""Independent local re-settlement of the denormalized-transfer control from the retrieved CSVs.

Reads the absolute-std borrow matrix (rows = donor, columns = receiver; holdout NSE) and the
per-receiver CSV (m1c0_nse_holdout, absolute_e1_nse), rebuilds the gain matrix, and re-derives
e1/e2/oracle/harmful-donor statistics with the SAME frozen selection functions the registered
ratio-transfer used. Compares against the cluster-side summary.json. Read-only.

Usage (repository root):
    python src/camels_switch_confirmation/scripts/recheck_denormalized_settlement.py <result_root>
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

_SRC = Path(__file__).resolve().parents[2]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from camels_switch_confirmation import noise_axis_transfer_loo as transfer  # noqa: E402
from camels_switch_confirmation import noise_axis_denormalized_transfer as dn  # noqa: E402


def main() -> int:
    root = Path(sys.argv[1])
    matrix = pd.read_csv(root / "absolute_matrix_nse_holdout.csv", index_col=0)
    matrix.index = [str(i).zfill(8) for i in matrix.index]
    matrix.columns = [str(c).zfill(8) for c in matrix.columns]
    per = pd.read_csv(root / "receivers_per_basin.csv", dtype={"basin_id": str})
    per["basin_id"] = per["basin_id"].str.zfill(8)
    per = per[per["status"] == "success"].set_index("basin_id")
    basins = sorted(set(matrix.columns) & set(per.index))
    m1c0 = per.loc[basins, "m1c0_nse_holdout"]
    gain = matrix.loc[basins, basins].astype(float).copy()
    for b in basins:
        gain.loc[b, b] = np.nan
    gain = gain.sub(m1c0, axis=1)  # gain[donor, receiver] = nse - m1c0[receiver]
    e2 = pd.Series({r: float(gain.loc[transfer.select_loo_donor(gain, r), r]) for r in basins})
    e2_donor = pd.Series({r: transfer.select_loo_donor(gain, r) for r in basins})
    oracle = pd.Series({r: float(gain[r].drop(labels=[r]).max()) for r in basins})
    e1 = per.loc[basins, "absolute_e1_nse"] - m1c0
    harmful = int((gain.apply(lambda row: float(np.nanmedian(row.to_numpy())), axis=1) < 0).sum())
    local = {
        "n_receivers": len(basins),
        "absolute_e2_gain_median": float(e2.median()),
        "absolute_e2_wins": int((e2 > 0).sum()),
        "absolute_e1_gain_median": float(e1.median()),
        "absolute_e1_wins": int((e1 > 0).sum()),
        "absolute_oracle_gain_median": float(oracle.median()),
        "absolute_harmful_donors": harmful,
        "e2_donor_top": e2_donor.value_counts().head(3).to_dict(),
        "delta_e2_ratio_minus_absolute": dn.REGISTERED_RATIO_E2_GAIN_MEDIAN - float(e2.median()),
        "diag_abs_diff_max": float(per.loc[basins, "diag_abs_diff"].max()),
    }
    remote = json.loads((root / "summary.json").read_text(encoding="utf-8"))
    print("=== local re-settlement ===")
    print(json.dumps(local, indent=1))
    print("=== comparison with cluster summary.json ===")
    keys = ["absolute_e2_gain_median", "absolute_e2_wins", "absolute_e1_gain_median",
            "absolute_e1_wins", "absolute_oracle_gain_median", "absolute_harmful_donors",
            "delta_e2_ratio_minus_absolute"]
    worst = 0.0
    for k in keys:
        a, b = local[k], remote.get(k)
        diff = abs(float(a) - float(b)) if b is not None else float("nan")
        worst = max(worst, diff if diff == diff else 0.0)
        print(f"{k:32s} local={a!s:>22} remote={b!s:>22} diff={diff:.3e}")
    print(f"remote outcome: {remote.get('outcome')}   worst_key_diff={worst:.3e}")
    # descriptive extras for the results document
    print("=== extras ===")
    print("e2 gain quantiles:", e2.quantile([.05, .25, .5, .75, .95]).round(4).to_dict())
    print("e2 negative receivers:", int((e2 < 0).sum()), " worst:", e2.idxmin(), round(float(e2.min()), 4))
    print("e1 negative receivers:", int((e1 < 0).sum()), " worst:", e1.idxmin(), round(float(e1.min()), 4))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
