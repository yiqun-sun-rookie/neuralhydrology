"""Runner for the training-length sensitivity experiment (prereg frozen 2026-09-02).

Preregistration:
docs/plans/2026-09-02-noise-axis-training-length-sensitivity-prereg-v01.md

Phases (run from the payload/repository root):
    p0                       reproduce the registered 840-day holdout numbers (aborts on failure)
    freeze-list              basins complete at every training length (expected 46/52)
    learn   --length L2|L3   CMA-ES per basin on that training segment, resumable per basin
    borrow  --length L2|L3   N x N leave-one-out borrow matrix at that length, resumable
    settle                   all three lengths (L1 from the registry) and the frozen verdict

Usage:
    python src/camels_switch_confirmation/scripts/run_noise_axis_training_length.py <phase> [--length L2] [--workers N]
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import numpy as np
import pandas as pd

_SRC = Path(__file__).resolve().parents[2]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from camels_switch_confirmation import noise_axis_391_confirmation as conf  # noqa: E402
from camels_switch_confirmation import noise_axis_training_length as tl  # noqa: E402
from camels_switch_confirmation import noise_axis_transfer_loo as transfer  # noqa: E402
from camels_switch_confirmation.noise_axis_learned_q import GROUP_NAMES  # noqa: E402

FROZEN_LIST = tl.OUTPUT_ROOT / "frozen_basin_list.csv"


def learn_dir(length: str) -> Path:
    return tl.OUTPUT_ROOT / length / "learn"


def borrow_dir(length: str) -> Path:
    return tl.OUTPUT_ROOT / length / "borrow"


def frozen_basins() -> list[str]:
    frame = pd.read_csv(FROZEN_LIST, dtype={"basin_id": str})
    return sorted(frame.loc[frame["included"], "basin_id"].str.zfill(8))


def _screen(basin: str) -> dict:
    row = {"basin_id": basin, "included": False, "reason": ""}
    for length in tl.LENGTHS.values():
        start, total = tl.window(length)
        try:
            conf.load_forcing_obs(basin, start, total)
        except Exception as exc:  # noqa: BLE001
            row["reason"] = f"L={length}: {type(exc).__name__}: {exc}"
            return row
    row["included"] = True
    return row


def _learn(args) -> dict:
    basin, length = args
    path = learn_dir(length) / f"{basin}.json"
    if path.exists():
        return {"basin_id": basin, "skipped": True}
    record = tl.learn_one_basin(basin, tl.LENGTHS[length])
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(record, indent=1), encoding="utf-8")
    tmp.replace(path)
    return {"basin_id": basin, "skipped": False, "status": record["status"]}


def _borrow(args) -> dict:
    receiver, length, donor_rho = args
    path = borrow_dir(length) / f"{receiver}.json"
    if path.exists():
        return {"basin_id": receiver, "skipped": True}
    record = tl.borrow_row(receiver, tl.LENGTHS[length], donor_rho)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(record, indent=1), encoding="utf-8")
    tmp.replace(path)
    return {"basin_id": receiver, "skipped": False, "status": record["status"]}


def _read(directory: Path) -> list[dict]:
    return [json.loads(p.read_text(encoding="utf-8")) for p in sorted(directory.glob("*.json"))]


def phase_p0() -> int:
    report = tl.p0_check()
    tl.OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    (tl.OUTPUT_ROOT / "p0_report.json").write_text(json.dumps(report, indent=1), encoding="utf-8")
    print(json.dumps(report, indent=1))
    print("P0", "PASS" if report["passed"] else "FAIL", f"worst_abs_diff={report['worst_abs_diff']:.3e}")
    return 0 if report["passed"] else 1


def phase_freeze_list(workers: int) -> int:
    tl.OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    registry = pd.read_csv(tl.STEP2_ROOT / "evaluation_per_basin.csv", dtype={"basin_id": str})
    basins = sorted(registry["basin_id"].str.zfill(8))
    with ProcessPoolExecutor(max_workers=workers) as pool:
        rows = list(pool.map(_screen, basins, chunksize=1))
    frame = pd.DataFrame(rows).sort_values("basin_id")
    frame.to_csv(FROZEN_LIST, index=False)
    print(f"included {int(frame['included'].sum())} / {len(frame)}")
    for _, row in frame[~frame["included"]].iterrows():
        print("  excluded", row["basin_id"], "--", row["reason"][:100])
    return 0


def phase_learn(length: str, workers: int) -> int:
    learn_dir(length).mkdir(parents=True, exist_ok=True)
    basins = frozen_basins()
    pending = [b for b in basins if not (learn_dir(length) / f"{b}.json").exists()]
    print(f"[{length} train_days={tl.LENGTHS[length]}] basins {len(basins)}; pending {len(pending)}; "
          f"workers {workers}", flush=True)
    started, done = time.perf_counter(), 0
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for outcome in pool.map(_learn, [(b, length) for b in pending], chunksize=1):
            done += 1
            elapsed = time.perf_counter() - started
            print(f"  {done}/{len(pending)} {outcome['basin_id']} {outcome.get('status', 'skipped')}"
                  f"  elapsed {elapsed/60:.1f} min"
                  f"  eta {elapsed/done*(len(pending)-done)/60:.1f} min", flush=True)
    print(f"[{length}] learn complete in {(time.perf_counter()-started)/60:.1f} min", flush=True)
    return 0


def phase_borrow(length: str, workers: int) -> int:
    borrow_dir(length).mkdir(parents=True, exist_ok=True)
    basins = frozen_basins()
    records = {r["basin_id"]: r for r in _read(learn_dir(length)) if r["status"] == "success"}
    donor_rho = {b: records[b]["rho"] for b in basins if b in records}
    print(f"[{length}] donors {len(donor_rho)}", flush=True)
    pending = [b for b in basins if not (borrow_dir(length) / f"{b}.json").exists()]
    started, done = time.perf_counter(), 0
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for outcome in pool.map(_borrow, [(b, length, donor_rho) for b in pending], chunksize=1):
            done += 1
            elapsed = time.perf_counter() - started
            print(f"  {done}/{len(pending)} {outcome['basin_id']} {outcome.get('status', 'skipped')}"
                  f"  elapsed {elapsed/60:.1f} min", flush=True)
    print(f"[{length}] borrow complete in {(time.perf_counter()-started)/60:.1f} min", flush=True)
    return 0


def settle_l1(basins: list[str]) -> dict:
    """L1 from the registered step-2 / transfer artefacts, restricted to the frozen basin set."""
    evaluation = pd.read_csv(tl.STEP2_ROOT / "evaluation_per_basin.csv", dtype={"basin_id": str})
    evaluation["basin_id"] = evaluation["basin_id"].str.zfill(8)
    evaluation = evaluation.set_index("basin_id")
    matrix = pd.read_csv(
        tl.RESULTS / "noise_axis_transfer_loo_20260828_local" / "borrow_matrix_nse_holdout.csv",
        index_col=0,
    )
    matrix.index = [str(i).zfill(8) for i in matrix.index]
    matrix.columns = [str(c).zfill(8) for c in matrix.columns]
    m1c0 = evaluation.loc[basins, "nse_holdout_m1c0"]
    own = evaluation.loc[basins, "nse_holdout_learned"]
    gain = matrix.loc[basins, basins].astype(float).copy()
    for b in basins:
        gain.loc[b, b] = np.nan
    gain = gain.sub(m1c0, axis=1)
    e2 = pd.Series({r: float(gain.loc[transfer.select_loo_donor(gain, r), r]) for r in basins})
    oracle = pd.Series({r: float(gain[r].drop(labels=[r]).max()) for r in basins})
    borrowed_nse = e2 + m1c0
    gap = own - borrowed_nse
    own_gain = own - m1c0
    return {
        "n_basins": len(basins),
        "own_gain_median": float(own_gain.median()),
        "own_wins_vs_m1c0": int((own_gain > 0).sum()),
        "borrowed_gain_median": float(e2.median()),
        "borrowed_wins_vs_m1c0": int((e2 > 0).sum()),
        "oracle_gain_median": float(oracle.median()),
        "headroom": float(oracle.median() - e2.median()),
        "gap_own_minus_borrowed_median": float(gap.median()),
        "gap_own_wins": int((gap > 0).sum()),
        "gap_own_losses": int((gap < 0).sum()),
        "median_m1c0_nse": float(m1c0.median()),
        "median_own_nse": float(own.median()),
        "median_borrowed_nse": float(borrowed_nse.median()),
        "source": "registered step-2 / transfer artefacts, restricted to the frozen basin set",
    }


def phase_settle() -> int:
    basins = frozen_basins()
    summary: dict = {
        "preregistration": "docs/plans/2026-09-02-noise-axis-training-length-sensitivity-prereg-v01.md",
        "n_frozen_basins": len(basins),
        "train_days": tl.LENGTHS,
        "lengths": {"L1": settle_l1(basins)},
    }
    for length in ("L2", "L3"):
        if not learn_dir(length).exists() or not borrow_dir(length).exists():
            continue
        summary["lengths"][length] = tl.settle_length(_read(learn_dir(length)), _read(borrow_dir(length)))
    gaps = {k: v["gap_own_minus_borrowed_median"] for k, v in summary["lengths"].items()}
    summary["gap_curve"] = gaps
    if "L3" in gaps:
        summary["verdict"] = tl.verdict(gaps["L1"], gaps["L3"])
    (tl.OUTPUT_ROOT / "summary.json").write_text(json.dumps(summary, indent=1), encoding="utf-8")
    print(json.dumps(summary, indent=1))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=["p0", "freeze-list", "learn", "borrow", "settle"])
    parser.add_argument("--length", choices=["L2", "L3"], default="L2")
    parser.add_argument("--workers", type=int, default=6)
    arguments = parser.parse_args()
    if arguments.phase == "p0":
        return phase_p0()
    if arguments.phase == "freeze-list":
        return phase_freeze_list(arguments.workers)
    if arguments.phase == "learn":
        return phase_learn(arguments.length, arguments.workers)
    if arguments.phase == "borrow":
        return phase_borrow(arguments.length, arguments.workers)
    return phase_settle()


if __name__ == "__main__":
    raise SystemExit(main())
