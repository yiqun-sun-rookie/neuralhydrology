"""EXPLORATORY: relate the learned noise ratios to CAMELS catchment attributes (52 basins).

Marked exploratory by design (idea doc ID29 section 6 item 3): no gate, no preregistration,
no formal claim. It exists to answer, in the discussion section, whether the residual
between-basin variation in the learned noise has any legible physical signature -- and to
report honestly if it does not. Thiboult & Anctil (2015) section 3.5 already reported no clear
correlation between catchment characteristics and EnKF gain; the dependent variable here is
different (the optimal setting itself, not the gain).

Read-only except for the CSV it writes under the step-2 results root.

Usage (repository root):
    python src/camels_switch_confirmation/scripts/explore_noise_attribute_relations.py
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

_SRC = Path(__file__).resolve().parents[2]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from camels_switch_confirmation.run_online_noise_pilot import RESULTS  # noqa: E402

STEP2 = RESULTS / "noise_axis_step2_learned_q_20260827_local"
TRANSFER = RESULTS / "noise_axis_transfer_loo_20260828_local"
ATTR_DIR = Path("data/camels_us/camels_attributes_v2.0")
OUT = STEP2 / "attribute_exploration_v01.csv"

ATTRIBUTES = {
    "camels_clim.txt": ["p_mean", "pet_mean", "aridity", "p_seasonality", "frac_snow",
                        "high_prec_freq", "low_prec_freq", "low_prec_dur"],
    "camels_hydro.txt": ["q_mean", "runoff_ratio", "baseflow_index", "stream_elas",
                         "hfd_mean", "q5", "q95"],
    "camels_topo.txt": ["elev_mean", "slope_mean", "area_gages2"],
    "camels_soil.txt": ["soil_depth_pelletier", "soil_porosity", "soil_conductivity",
                        "max_water_content", "sand_frac", "clay_frac"],
    "camels_geol.txt": ["carbonate_rocks_frac", "geol_permeability"],
    "camels_vege.txt": ["frac_forest", "lai_max", "gvf_max"],
}


def load_attributes(basins: list[str]) -> pd.DataFrame:
    frames = []
    for filename, columns in ATTRIBUTES.items():
        path = ATTR_DIR / filename
        if not path.is_file():
            print(f"  missing attribute file: {path}")
            continue
        frame = pd.read_csv(path, sep=";", dtype={"gauge_id": str})
        frame["gauge_id"] = frame["gauge_id"].str.zfill(8)
        keep = [c for c in columns if c in frame.columns]
        frames.append(frame.set_index("gauge_id")[keep])
    table = pd.concat(frames, axis=1)
    return table.reindex(basins)


def spearman(x: np.ndarray, y: np.ndarray) -> tuple[float, float]:
    """Spearman rho and a two-sided p-value from the t approximation (no scipy dependency)."""
    mask = np.isfinite(x) & np.isfinite(y)
    n = int(mask.sum())
    if n < 8:
        return float("nan"), float("nan")
    rx = pd.Series(x[mask]).rank().to_numpy()
    ry = pd.Series(y[mask]).rank().to_numpy()
    rho = float(np.corrcoef(rx, ry)[0, 1])
    if abs(rho) >= 1.0:
        return rho, 0.0
    t = rho * np.sqrt((n - 2) / (1 - rho**2))
    # two-sided p from Student-t via the incomplete beta in terms of the normal approximation
    from math import erfc, sqrt
    p = erfc(abs(t) / sqrt(2))  # normal approximation, adequate for a screening table
    return rho, float(p)


def main() -> int:
    evaluation = pd.read_csv(STEP2 / "evaluation_per_basin.csv", dtype={"basin_id": str})
    evaluation["basin_id"] = evaluation["basin_id"].str.zfill(8)
    evaluation = evaluation.set_index("basin_id").sort_index()
    transfer = pd.read_csv(TRANSFER / "transfer_per_basin.csv", dtype={"basin_id": str})
    transfer["basin_id"] = transfer["basin_id"].str.zfill(8)
    transfer = transfer.set_index("basin_id").sort_index()
    basins = list(evaluation.index)

    targets = pd.DataFrame(index=basins)
    targets["log_rho_SLZ"] = np.log10(evaluation["rho_SLZ"])
    targets["share_SLZ"] = evaluation["share_SLZ"]
    targets["log_total_magnitude"] = np.log10(
        evaluation[[f"rho_{g}" for g in ("SNOWPACK", "MELTWATER", "SM", "SUZ", "SLZ", "ROUTING")]].sum(axis=1)
    )
    targets["own_learned_gain"] = transfer["own_learned_gain"]
    targets["premium_own_minus_e2"] = transfer["premium_own_minus_e2"]
    targets["slz_dominant"] = (evaluation["share_SLZ"] > 0.5).astype(int)
    targets["sm_switched_off"] = (evaluation["rho_SM"] <= 1.01e-4).astype(int)

    attributes = load_attributes(basins)
    print(f"basins {len(basins)}  attributes {attributes.shape[1]}  "
          f"complete-attribute basins {int(attributes.notna().all(axis=1).sum())}")

    rows = []
    for target in targets.columns:
        for attribute in attributes.columns:
            rho, p = spearman(attributes[attribute].to_numpy(dtype=float),
                             targets[target].to_numpy(dtype=float))
            rows.append({"target": target, "attribute": attribute, "spearman_rho": rho,
                         "p_normal_approx": p,
                         "n": int((np.isfinite(attributes[attribute].to_numpy(dtype=float))
                                   & np.isfinite(targets[target].to_numpy(dtype=float))).sum())})
    table = pd.DataFrame(rows).sort_values("target").reset_index(drop=True)
    table.to_csv(OUT, index=False)

    n_tests = len(table)
    bonferroni = 0.05 / n_tests
    print(f"\ntests: {n_tests}   Bonferroni threshold: {bonferroni:.2e}")
    for target in targets.columns:
        block = table[table["target"] == target].dropna(subset=["spearman_rho"]).copy()
        block = block.reindex(block["spearman_rho"].abs().sort_values(ascending=False).index).head(4)
        print(f"\n{target}:")
        for _, row in block.iterrows():
            flag = "  **survives Bonferroni**" if row["p_normal_approx"] < bonferroni else ""
            print(f"   {row['attribute']:24s} rho={row['spearman_rho']:+.3f}  p={row['p_normal_approx']:.3g}{flag}")
    survivors = table[table["p_normal_approx"] < bonferroni]
    print(f"\npairs surviving Bonferroni across all {n_tests} tests: {len(survivors)}")
    if len(survivors):
        print(survivors.to_string(index=False))

    minority = evaluation[evaluation["share_SLZ"] <= 0.5]
    print(f"\nnon-SLZ-dominant basins: {len(minority)}")
    if len(minority) and "frac_snow" in attributes:
        for basin in minority.index:
            shares = {g: float(minority.loc[basin, f"share_{g}"])
                      for g in ("SNOWPACK", "MELTWATER", "SM", "SUZ", "SLZ", "ROUTING")}
            leader = max(shares, key=shares.get)
            snow = attributes.loc[basin, "frac_snow"] if basin in attributes.index else np.nan
            arid = attributes.loc[basin, "aridity"] if basin in attributes.index else np.nan
            print(f"   {basin}  leader={leader:10s} share={shares[leader]:.3f}  "
                  f"frac_snow={snow:.3f}  aridity={arid:.2f}")
    print(f"\nwrote {OUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
