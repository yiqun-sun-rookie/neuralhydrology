"""Denormalized (absolute-std) transfer control on the 52 development basins.

Preregistration (frozen before any run):
docs/plans/2026-09-02-noise-axis-denormalized-transfer-control-prereg-v01.md

Everything is inherited from the frozen leave-one-out transfer test except the one thing
that travels between basins: the absolute per-group noise std ``rho_d * A_d`` of the donor
(instead of the dimensionless ratio ``rho_d`` rescaled by the receiver's own amplitude).
``GroupedProcessNoise(rho=std_d, amplitudes=ones)`` expresses "std as-is" bit-for-bit.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from camels_switch_confirmation import noise_axis_391_confirmation as conf
from camels_switch_confirmation import noise_axis_transfer_loo as transfer
from camels_switch_confirmation.noise_axis_filtering import LegacyGridNoise
from camels_switch_confirmation.noise_axis_learned_q import (
    GROUP_NAMES,
    N_GROUPS,
    TRAIN_DAYS as DEV_TRAIN_DAYS,
    GroupedProcessNoise,
    open_loop_states,
)
from camels_switch_confirmation.run_online_noise_pilot import RESULTS

STEP2_ROOT = RESULTS / "noise_axis_step2_learned_q_20260827_local"
TRANSFER_ROOT = RESULTS / "noise_axis_transfer_loo_20260828_local"
OUTPUT_ROOT = RESULTS / "noise_axis_denormalized_transfer_control_20260902_hpc"

# registered ratio-transfer numbers (transfer results doc, 2026-08-28); cited, never recomputed
REGISTERED_RATIO_E2_GAIN_MEDIAN = 0.04093
REGISTERED_RATIO_E2_WINS = 38
REGISTERED_RATIO_E1_GAIN_MEDIAN = 0.0316
REGISTERED_RATIO_HARMFUL_DONORS = 23

P0_TOLERANCE = 1e-8
ONES = tuple(np.ones(N_GROUPS, dtype=np.float64))


def load_rho_table() -> pd.DataFrame:
    frame = pd.read_csv(STEP2_ROOT / "evaluation_per_basin.csv", dtype={"basin_id": str})
    frame["basin_id"] = frame["basin_id"].str.zfill(8)
    table = frame.set_index("basin_id")[[f"rho_{g}" for g in GROUP_NAMES]]
    table.columns = list(GROUP_NAMES)
    return table.sort_index()


def load_amplitude_table() -> pd.DataFrame:
    frame = pd.read_csv(STEP2_ROOT / "amplitudes_frozen.csv", dtype={"basin_id": str})
    frame["basin_id"] = frame["basin_id"].str.zfill(8)
    table = frame.set_index("basin_id")[[f"A_{g}" for g in GROUP_NAMES]]
    table.columns = list(GROUP_NAMES)
    return table.sort_index()


def absolute_std_table() -> pd.DataFrame:
    """std_d = rho_d * A_d, per donor and group (52 x 6), digit-for-digit from the registry."""
    rho = load_rho_table()
    amplitudes = load_amplitude_table()
    if list(rho.index) != list(amplitudes.index):
        raise ValueError("rho and amplitude registries disagree on the basin set")
    return rho * amplitudes


def median_absolute_arm(std_table: pd.DataFrame, receiver: str) -> np.ndarray:
    """e1 in the absolute convention: per-group log-median over the 51 other donors' std."""
    return transfer.median_arm_rho(std_table, receiver)


def receiver_context(basin: str):
    task = conf.build_task(basin, conf.DEV_START, conf.DEV_DAYS)
    amplitudes = conf.windowed_amplitudes(open_loop_states(task, basin), DEV_TRAIN_DAYS)
    return task, amplitudes


def holdout_nse(task: dict, basin: str, noise) -> float:
    return conf.filter_arm_nse(task, basin, noise, DEV_TRAIN_DAYS)["nse_score"]


def run_receiver(basin: str) -> dict:
    """All 52 absolute-std donors + e1-absolute + m1_c0 + ratio self-check for one receiver."""
    std_table = absolute_std_table()
    rho_table = load_rho_table()
    record: dict = {"basin_id": basin, "status": "success", "absolute": {}}
    try:
        task, amplitudes = receiver_context(basin)
        record["amplitudes"] = [float(a) for a in amplitudes]
        record["m1c0_nse_holdout"] = holdout_nse(task, basin, LegacyGridNoise(m=1.0, c=0.0))
        for donor in std_table.index:
            noise = GroupedProcessNoise(tuple(std_table.loc[donor].to_numpy()), ONES)
            record["absolute"][donor] = holdout_nse(task, basin, noise)
        e1 = median_absolute_arm(std_table, basin)
        record["absolute_e1_std"] = [float(v) for v in e1]
        record["absolute_e1_nse"] = holdout_nse(task, basin, GroupedProcessNoise(tuple(e1), ONES))
        ratio_self = GroupedProcessNoise(tuple(rho_table.loc[basin].to_numpy()), tuple(amplitudes))
        record["ratio_self_nse"] = holdout_nse(task, basin, ratio_self)
        record["diag_abs_diff"] = abs(record["ratio_self_nse"] - record["absolute"][basin])
    except Exception as exc:  # noqa: BLE001 - recorded, not raised
        record["status"] = "failed"
        record["error"] = f"{type(exc).__name__}: {exc}"
    return record


# ---- P0 (prereg section 2): replicate registered ratio cells + diagonal identity ------

def p0_check(receivers=("01144000", "01435000"), donors=("14316700", "04233000")) -> dict:
    matrix = pd.read_csv(TRANSFER_ROOT / "borrow_matrix_nse_holdout.csv", index_col=0)
    matrix.index = [str(i).zfill(8) for i in matrix.index]
    matrix.columns = [str(c).zfill(8) for c in matrix.columns]
    rho_table = load_rho_table()
    std_table = absolute_std_table()
    rows, worst = [], 0.0
    for receiver in receivers:
        task, amplitudes = receiver_context(receiver)
        for donor in donors:
            new = holdout_nse(
                task, receiver, GroupedProcessNoise(tuple(rho_table.loc[donor].to_numpy()), tuple(amplitudes))
            )
            # the registry stores rows=donor, columns=receiver; accept either orientation but require a match
            candidates = {
                "donor_row": float(matrix.loc[donor, receiver]),
                "donor_col": float(matrix.loc[receiver, donor]),
            }
            diffs = {k: abs(new - v) for k, v in candidates.items() if np.isfinite(v)}
            orientation, diff = min(diffs.items(), key=lambda kv: kv[1])
            worst = max(worst, diff)
            rows.append({"receiver": receiver, "donor": donor, "ratio_new": new,
                         "registered": candidates[orientation], "orientation": orientation,
                         "abs_diff": diff})
        own_abs = holdout_nse(task, receiver, GroupedProcessNoise(tuple(std_table.loc[receiver].to_numpy()), ONES))
        own_ratio = holdout_nse(task, receiver, GroupedProcessNoise(tuple(rho_table.loc[receiver].to_numpy()), tuple(amplitudes)))
        diag = abs(own_abs - own_ratio)
        worst = max(worst, diag)
        rows.append({"receiver": receiver, "donor": receiver, "absolute_self": own_abs,
                     "ratio_self": own_ratio, "abs_diff": diag, "orientation": "diagonal_identity"})
    return {"rows": rows, "worst_abs_diff": worst, "tolerance": P0_TOLERANCE,
            "passed": bool(worst <= P0_TOLERANCE)}


# ---- settlement (prereg section 3) ------------------------------------------------

def settle(records: list[dict]) -> dict:
    good = [r for r in records if r["status"] == "success"]
    basins = sorted(r["basin_id"] for r in good)
    m1c0 = pd.Series({r["basin_id"]: r["m1c0_nse_holdout"] for r in good})
    # gain[donor, receiver] in the absolute convention; diagonal masked like the registry
    gain = pd.DataFrame(index=basins, columns=basins, dtype=np.float64)
    for r in good:
        for donor, value in r["absolute"].items():
            gain.loc[donor, r["basin_id"]] = value - m1c0[r["basin_id"]]
    for b in basins:
        gain.loc[b, b] = np.nan
    e2_gain, e2_donor, oracle_gain = {}, {}, {}
    for receiver in basins:
        donor = transfer.select_loo_donor(gain, receiver)
        e2_gain[receiver] = float(gain.loc[donor, receiver])
        e2_donor[receiver] = donor
        oracle_gain[receiver] = float(gain[receiver].drop(labels=[receiver]).max())
    e2 = pd.Series(e2_gain)
    e1 = pd.Series({r["basin_id"]: r["absolute_e1_nse"] - m1c0[r["basin_id"]] for r in good})
    donor_column_median = gain.apply(lambda row: float(np.nanmedian(row.to_numpy())), axis=1)
    harmful = int((donor_column_median < 0).sum())
    delta = REGISTERED_RATIO_E2_GAIN_MEDIAN - float(e2.median())
    wins = int((e2 > 0).sum())
    if delta > 0.01 and wins < REGISTERED_RATIO_E2_WINS:
        outcome = "A_normalization_necessary"
    elif abs(delta) <= 0.005:
        outcome = "B_normalization_not_the_cause"
    else:
        outcome = "C_partial_dependence"
    return {
        "n_receivers": len(basins),
        "n_failed": len(records) - len(good),
        "diag_abs_diff_max": max(r.get("diag_abs_diff", 0.0) for r in good) if good else None,
        "absolute_e2_gain_median": float(e2.median()),
        "absolute_e2_wins": wins,
        "absolute_e2_donor_counts": pd.Series(e2_donor).value_counts().head(5).to_dict(),
        "absolute_e1_gain_median": float(e1.median()),
        "absolute_e1_wins": int((e1 > 0).sum()),
        "absolute_oracle_gain_median": float(pd.Series(oracle_gain).median()),
        "absolute_harmful_donors": harmful,
        "registered_ratio_e2_gain_median": REGISTERED_RATIO_E2_GAIN_MEDIAN,
        "registered_ratio_e2_wins": REGISTERED_RATIO_E2_WINS,
        "registered_ratio_e1_gain_median": REGISTERED_RATIO_E1_GAIN_MEDIAN,
        "registered_ratio_harmful_donors": REGISTERED_RATIO_HARMFUL_DONORS,
        "delta_e2_ratio_minus_absolute": delta,
        "outcome": outcome,
    }
