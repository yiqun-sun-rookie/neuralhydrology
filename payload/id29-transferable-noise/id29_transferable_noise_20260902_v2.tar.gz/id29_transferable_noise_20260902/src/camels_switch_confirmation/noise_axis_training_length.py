"""Training-length sensitivity: does the zero customization premium survive longer records?

Preregistration (frozen before any run):
docs/plans/2026-09-02-noise-axis-training-length-sensitivity-prereg-v01.md

Single variable: the length of the training segment. The holdout segment is pinned to the
frozen 420 days (1992-01-19..1993-03-13) at every length, so the thing being scored never
changes. The search loop mirrors ``noise_axis_learned_q.search_one_anchor`` line for line --
same anchors, same seeds, same budget, same projection repair -- with the one difference that
the objective spans the whole training segment instead of the hardwired 840 days. P0 validates
that mirror by reproducing the registered 840-day numbers.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from camels_switch_confirmation import noise_axis_391_confirmation as conf
from camels_switch_confirmation import noise_axis_transfer_loo as transfer
from camels_switch_confirmation.noise_axis_filtering import LegacyGridNoise, run_noise_axis_filter
from camels_switch_confirmation.noise_axis_learned_q import (
    BURN_IN_DAYS,
    CMA_GENERATIONS,
    CMA_POPSIZE,
    CMA_SIGMA0,
    EVALS_PER_ANCHOR,
    GROUP_NAMES,
    LOG_RHO_BOUNDS,
    GroupedProcessNoise,
    anchor_seed,
    anchor_table,
    boundary_diagnostics,
    nse,
    open_loop_states,
)
from camels_switch_confirmation.run_online_noise_pilot import RESULTS

HOLDOUT_END = pd.Timestamp("1993-03-13")
HOLDOUT_DAYS = 420
LENGTHS = {"L1": 840, "L2": 1826, "L3": 3652}   # L1 is the registered step-2 training segment
STEP2_ROOT = RESULTS / "noise_axis_step2_learned_q_20260827_local"
OUTPUT_ROOT = RESULTS / "noise_axis_training_length_20260902_hpc"
P0_TOLERANCE = 1e-8


def window(train_days: int) -> tuple[str, int]:
    """Full task window (training + the frozen holdout) ending on the frozen holdout end."""
    total = int(train_days) + HOLDOUT_DAYS
    start = (HOLDOUT_END - pd.Timedelta(days=total - 1)).strftime("%Y-%m-%d")
    return start, total


def build(basin: str, train_days: int) -> tuple[dict, np.ndarray]:
    start, total = window(train_days)
    task = conf.build_task(basin, start, total)
    amplitudes = conf.windowed_amplitudes(open_loop_states(task, basin), int(train_days))
    return task, amplitudes


def sliced(task: dict, n_days: int) -> dict:
    out = dict(task)
    for key in ("rain", "pet", "temp", "obs"):
        out[key] = np.asarray(task[key])[:n_days]
    return out


def training_objective(task: dict, basin: str, noise: GroupedProcessNoise, train_days: int) -> float:
    result = run_noise_axis_filter(sliced(task, int(train_days)), basin, noise)
    forecast = result["one_step_forecast"][BURN_IN_DAYS:]
    observed = result["observations"][BURN_IN_DAYS:]
    return float(np.mean(np.square(forecast - observed)))


def holdout_nse(task: dict, basin: str, noise) -> float:
    result = run_noise_axis_filter(task, basin, noise)
    forecast = result["one_step_forecast"][-HOLDOUT_DAYS:]
    observed = result["observations"][-HOLDOUT_DAYS:]
    return nse(forecast, observed)


def search_one_anchor(task, basin, amplitudes, anchor_index, anchor_rho, train_days) -> dict:
    """Mirror of the frozen step-2 anchor search, with a window-parameterized objective."""
    import cma

    low, high = LOG_RHO_BOUNDS
    start = np.log(np.asarray(anchor_rho, dtype=np.float64))
    options = {
        "popsize": CMA_POPSIZE,
        "maxiter": CMA_GENERATIONS,
        "seed": anchor_seed(basin, anchor_index),
        "verbose": -9,
        "verb_disp": 0,
        "verb_log": 0,
    }
    strategy = cma.CMAEvolutionStrategy(start, CMA_SIGMA0, options)
    strategy.inject([start])
    best_objective = np.inf
    best_log_rho = np.clip(start, low, high)
    evaluations, crashes = 0, []
    while not strategy.stop() and evaluations < EVALS_PER_ANCHOR:
        candidates = strategy.ask()
        fitnesses = []
        for candidate in candidates:
            clipped = np.clip(np.asarray(candidate, dtype=np.float64), low, high)
            try:
                objective = training_objective(
                    task, basin,
                    GroupedProcessNoise(tuple(np.exp(clipped)), tuple(amplitudes)),
                    train_days,
                )
            except Exception as exc:  # noqa: BLE001 - crashes are data
                objective = float("inf")
                crashes.append({"log_rho": clipped.tolist(), "error": f"{type(exc).__name__}: {exc}"})
            evaluations += 1
            fitnesses.append(objective)
            if objective < best_objective:
                best_objective, best_log_rho = objective, clipped
        strategy.tell(candidates, fitnesses)
    return {"anchor_index": anchor_index, "best_log_rho": np.asarray(best_log_rho),
            "best_objective": float(best_objective), "evaluations": evaluations,
            "crashes": crashes}


def learn_one_basin(basin: str, train_days: int) -> dict:
    """Eight anchors, winner by training objective; holdout score for own and m1_c0."""
    record: dict = {"basin_id": basin, "train_days": int(train_days), "status": "success"}
    try:
        task, amplitudes = build(basin, train_days)
        record["amplitudes"] = [float(a) for a in amplitudes]
        anchors = []
        for index, (name, anchor_rho) in enumerate(anchor_table()):
            outcome = search_one_anchor(task, basin, amplitudes, index, anchor_rho, train_days)
            anchors.append({"name": name, "objective": outcome["best_objective"],
                            "log_rho": outcome["best_log_rho"].tolist(),
                            "evaluations": outcome["evaluations"],
                            "n_crashes": len(outcome["crashes"])})
        alive = [a for a in anchors if np.isfinite(a["objective"])]
        if not alive:
            record["status"] = "all_anchors_failed"
            record["anchors"] = anchors
            return record
        winner = min(alive, key=lambda a: a["objective"])
        log_rho = np.asarray(winner["log_rho"], dtype=np.float64)
        rho = np.exp(log_rho)
        record["winner_anchor"] = winner["name"]
        record["rho"] = [float(v) for v in rho]
        record["train_objective"] = winner["objective"]
        record["anchors"] = anchors
        objectives = np.array([a["objective"] for a in alive], dtype=np.float64)
        record["anchor_objective_relative_iqr"] = float(
            (np.percentile(objectives, 75) - np.percentile(objectives, 25)) / np.median(objectives)
        )
        record.update(boundary_diagnostics(log_rho))
        noise = GroupedProcessNoise(tuple(rho), tuple(amplitudes))
        record["own_nse_holdout"] = holdout_nse(task, basin, noise)
        record["m1c0_nse_holdout"] = holdout_nse(task, basin, LegacyGridNoise(m=1.0, c=0.0))
        variance = (rho * np.asarray(amplitudes)) ** 2
        record["shares"] = [float(v) for v in variance / variance.sum()]
    except Exception as exc:  # noqa: BLE001
        record["status"] = "failed"
        record["error"] = f"{type(exc).__name__}: {exc}"
    return record


def borrow_row(receiver: str, train_days: int, donor_rho: dict[str, list]) -> dict:
    """One receiver borrowing every donor's ratios (receiver's own amplitudes and R)."""
    record: dict = {"basin_id": receiver, "train_days": int(train_days), "status": "success",
                    "borrowed": {}}
    try:
        task, amplitudes = build(receiver, train_days)
        record["m1c0_nse_holdout"] = holdout_nse(task, receiver, LegacyGridNoise(m=1.0, c=0.0))
        for donor, rho in donor_rho.items():
            noise = GroupedProcessNoise(tuple(np.asarray(rho, dtype=np.float64)), tuple(amplitudes))
            record["borrowed"][donor] = holdout_nse(task, receiver, noise)
    except Exception as exc:  # noqa: BLE001
        record["status"] = "failed"
        record["error"] = f"{type(exc).__name__}: {exc}"
    return record


def settle_length(learn_records: list[dict], borrow_records: list[dict]) -> dict:
    """own / borrowed / oracle arms and the frozen gap, on one training length."""
    good_learn = {r["basin_id"]: r for r in learn_records if r["status"] == "success"}
    good_borrow = {r["basin_id"]: r for r in borrow_records if r["status"] == "success"}
    basins = sorted(set(good_learn) & set(good_borrow))
    m1c0 = pd.Series({b: good_borrow[b]["m1c0_nse_holdout"] for b in basins})
    own = pd.Series({b: good_learn[b]["own_nse_holdout"] for b in basins})
    gain = pd.DataFrame(index=basins, columns=basins, dtype=np.float64)
    for receiver in basins:
        for donor, value in good_borrow[receiver]["borrowed"].items():
            if donor in basins:
                gain.loc[donor, receiver] = value - m1c0[receiver]
    for b in basins:
        gain.loc[b, b] = np.nan
    e2 = pd.Series({r: float(gain.loc[transfer.select_loo_donor(gain, r), r]) for r in basins})
    e2_donor = pd.Series({r: transfer.select_loo_donor(gain, r) for r in basins})
    oracle = pd.Series({r: float(gain[r].drop(labels=[r]).max()) for r in basins})
    own_gain = own - m1c0
    borrowed_nse = e2 + m1c0
    gap = own - borrowed_nse
    return {
        "n_basins": len(basins),
        "own_gain_median": float(own_gain.median()),
        "own_wins_vs_m1c0": int((own_gain > 0).sum()),
        "borrowed_gain_median": float(e2.median()),
        "borrowed_wins_vs_m1c0": int((e2 > 0).sum()),
        "oracle_gain_median": float(oracle.median()),
        "headroom": float(oracle.median() - e2.median()),
        "gap_own_minus_borrowed_median": float(gap.median()),
        "gap_own_wins": int((gap > 0).sum()),
        "gap_own_losses": int((gap < 0).sum()),
        "e2_donor_top": e2_donor.value_counts().head(3).to_dict(),
        "median_m1c0_nse": float(m1c0.median()),
        "median_own_nse": float(own.median()),
        "median_borrowed_nse": float(borrowed_nse.median()),
    }


def verdict(gap_l1: float, gap_l3: float) -> str:
    if gap_l3 > 0.01 and gap_l3 > gap_l1:
        return "A_premium_returns_with_longer_records"
    if abs(gap_l3) <= 0.005:
        return "B_zero_premium_holds_at_ten_years"
    return "C_reported_only"


def p0_check(basins=("01144000", "01435000")) -> dict:
    """Reproduce the registered 840-day own-learned holdout NSE through the new builder."""
    registry = pd.read_csv(STEP2_ROOT / "evaluation_per_basin.csv", dtype={"basin_id": str})
    registry["basin_id"] = registry["basin_id"].str.zfill(8)
    registry = registry.set_index("basin_id")
    rows, worst = [], 0.0
    for basin in basins:
        task, amplitudes = build(basin, LENGTHS["L1"])
        rho = registry.loc[basin, [f"rho_{g}" for g in GROUP_NAMES]].to_numpy(dtype=np.float64)
        new = holdout_nse(task, basin, GroupedProcessNoise(tuple(rho), tuple(amplitudes)))
        registered = float(registry.loc[basin, "nse_holdout_learned"])
        diff = abs(new - registered)
        worst = max(worst, diff)
        rows.append({"basin_id": basin, "new": new, "registered": registered, "abs_diff": diff})
    return {"rows": rows, "worst_abs_diff": worst, "tolerance": P0_TOLERANCE,
            "passed": bool(worst <= P0_TOLERANCE)}
