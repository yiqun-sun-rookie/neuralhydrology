"""Re-score every ID33 arm on one common date window, removing the predict_last_n confound.

The confound
------------
``predict_last_n`` does not only control how many timesteps enter the loss.  It also sets the
evaluation warm-up offset: ``neuralhydrology/datasetzoo/basedataset.py:469-470`` computes

    offsets = [(seq_len - predict_last_n) * to_offset(freq) ...]

and the warm-up start is ``validation_start_date - offset``.  The first admissible sample is
index ``seq_length - 1``, and the tester indexes each sample by its LAST date
(``neuralhydrology/evaluation/tester.py:292``).  So with ``seq_length: 270``:

    predict_last_n = 1  -> warm-up starts 269 days early -> first scored date 2006-10-01
    predict_last_n = 30 -> warm-up starts 240 days early -> first scored date 2006-10-30

The metric keeps only the last timestep of each sequence
(``tester.py:319``, ``isel(time_step=slice(-frequency_factor, None))`` with frequency_factor 1),
so for the predict_last_n=30 arms the first 29 days are predicted and then discarded.  T4 and
L33 are therefore scored on 702 days while every other arm is scored on 731 -- a systematic 4%
difference applied identically to all 531 basins, far outside the 0.00356 seed-noise floor and
not caused by seeds at all.

This matters for exactly two comparisons the project relies on: T4 vs T2 (is dense supervision
a Transformer lever?) and L33 vs B01 (is it a symmetric lever?).

The fix needs no retraining: ``save_validation_results: true`` was set, and ``tester.py:302``
stores the full ``xarray`` object -- every timestep, every date -- before the metric slice is
applied.  This script reloads those stored predictions and recomputes NSE for all arms over one
window that every arm can supply.

Read-only with respect to the arm directories: it opens ``validation_results.p`` and writes only
its own report.
"""

import argparse
import json
import pickle
import sys
from pathlib import Path

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[3]


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--arm-root", type=Path, required=True, help="Directory holding one subdirectory per ID33 arm.")
    parser.add_argument("--id30-root", type=Path, default=None, help="ID30 results root, read-only, for D01 and B01.")
    parser.add_argument("--epoch", type=int, default=30)
    parser.add_argument("--common-start", type=str, default="2006-10-30", help="First date every arm can supply.")
    parser.add_argument("--common-end", type=str, default="2008-09-30")
    parser.add_argument("--target", type=str, default="QObs(mm/d)")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--describe-only", action="store_true", help="Print the structure of one file and stop.")
    return parser.parse_args()


def _find_results_file(arm_dir: Path, epoch: int):
    """Return the validation_results.p for the requested epoch, or None."""
    pattern = f"*/validation/model_epoch{epoch:03d}/validation_results.p"
    matches = sorted(arm_dir.glob(pattern))
    return matches[-1] if matches else None


def _extract_dataset(frequency_node):
    """Return the xarray object out of one basin/frequency entry.

    neuralhydrology stores ``results[basin][freq]["xr"] = xr`` alongside the scalar metrics
    (``neuralhydrology/evaluation/tester.py:302``), so the frequency entry is a dict, not the
    Dataset itself. Older layouts stored the Dataset directly; both are handled.
    """
    if hasattr(frequency_node, "dims"):
        return frequency_node
    if isinstance(frequency_node, dict):
        if "xr" in frequency_node:
            return frequency_node["xr"]
        for value in frequency_node.values():
            if hasattr(value, "dims"):
                return value
    raise TypeError(f"cannot find an xarray object in a {type(frequency_node)}")


def _describe(path: Path) -> None:
    with path.open("rb") as handle:
        payload = pickle.load(handle)
    print(f"top-level type: {type(payload)}")
    keys = list(payload)[:3]
    print(f"n_top_level_keys={len(payload)} first={keys}")
    first = payload[keys[0]]
    print(f"  second level type: {type(first)} keys={list(first)[:5]}")
    inner = first[list(first)[0]]
    print(f"    third level type: {type(inner)} keys={list(inner)[:8] if isinstance(inner, dict) else 'n/a'}")
    dataset = _extract_dataset(inner)
    print(f"      dataset type: {type(dataset)}")
    for attribute in ("dims", "coords", "data_vars"):
        if hasattr(dataset, attribute):
            print(f"      {attribute}: {list(getattr(dataset, attribute))}")


def _nse(observed: np.ndarray, simulated: np.ndarray) -> float:
    finite = np.isfinite(observed) & np.isfinite(simulated)
    if finite.sum() < 2:
        return float("nan")
    observed, simulated = observed[finite], simulated[finite]
    denominator = np.sum((observed - observed.mean())**2)
    if denominator <= 0:
        return float("nan")
    return float(1.0 - np.sum((simulated - observed)**2) / denominator)


def _arm_scores(path: Path, target: str, start: str, end: str) -> dict:
    """Recompute per-basin NSE on the last timestep, restricted to [start, end]."""
    with path.open("rb") as handle:
        payload = pickle.load(handle)

    scores, windows = {}, []
    native = None
    for basin, frequencies in payload.items():
        dataset = _extract_dataset(frequencies[list(frequencies)[0]])
        if native is None:
            native = np.asarray(dataset["date"])
        # Keep the last timestep only, exactly as tester.py:319 does, then clip the date axis.
        last = dataset.isel(time_step=-1) if "time_step" in dataset.dims else dataset
        clipped = last.sel(date=slice(np.datetime64(start), np.datetime64(end)))
        observed = np.asarray(clipped[f"{target}_obs"]).squeeze()
        simulated = np.asarray(clipped[f"{target}_sim"]).squeeze()
        scores[str(basin)] = _nse(observed, simulated)
        windows.append(int(observed.shape[0]))

    values = np.array([v for v in scores.values() if np.isfinite(v)])
    return {
        "n_basins": len(scores),
        "n_finite": int(values.size),
        "median_nse": float(np.median(values)) if values.size else float("nan"),
        "window_days": int(np.median(windows)) if windows else 0,
        "native_first_date": str(native.min())[:10],
        "native_last_date": str(native.max())[:10],
        "native_days": int(native.size),
        "per_basin": scores,
    }


def main() -> int:
    args = _parse_args()

    candidates = {}
    for arm_dir in sorted(p for p in args.arm_root.glob("*") if p.is_dir() and not p.name.startswith("_")):
        found = _find_results_file(arm_dir, args.epoch)
        if found:
            candidates[arm_dir.name] = found
    if args.id30_root:
        for name in ("D01", "B01"):
            found = _find_results_file(args.id30_root / name, args.epoch)
            if found:
                candidates[name] = found

    if not candidates:
        print("no validation_results.p found; nothing to score")
        return 1

    print(f"found {len(candidates)} arms: {sorted(candidates)}")
    if args.describe_only:
        _describe(next(iter(candidates.values())))
        return 0

    report = {"epoch": args.epoch, "common_window": [args.common_start, args.common_end], "arms": {}}
    for name, path in candidates.items():
        result = _arm_scores(path, args.target, args.common_start, args.common_end)
        report["arms"][name] = result
        print(f"{name:5s} native {result['native_first_date']}..{result['native_last_date']} "
              f"({result['native_days']}d) -> common window {result['window_days']}d  "
              f"median_nse={result['median_nse']:.6f}  n_finite={result['n_finite']}")

    # Paired comparisons on the common window, over basins both arms scored finitely.
    def _paired(left: str, right: str) -> dict:
        if left not in report["arms"] or right not in report["arms"]:
            return {}
        a, b = report["arms"][left]["per_basin"], report["arms"][right]["per_basin"]
        shared = sorted(set(a) & set(b))
        differences = np.array([a[k] - b[k] for k in shared if np.isfinite(a[k]) and np.isfinite(b[k])])
        if differences.size == 0:
            return {}
        return {
            "n": int(differences.size),
            "median_paired_diff": float(np.median(differences)),
            "win_rate": float(np.mean(differences > 0)),
            "median_diff_of_medians": float(report["arms"][left]["median_nse"] - report["arms"][right]["median_nse"]),
        }

    report["paired_common_window"] = {
        f"{left}_vs_{right}": _paired(left, right)
        for left, right in (("T4", "T2"), ("L33", "B01"), ("T5", "B01"), ("T5", "T2"), ("T2", "T1"), ("T1", "D01"))
    }
    print("=== PAIRED ON COMMON WINDOW ===")
    for name, stats in report["paired_common_window"].items():
        if stats:
            print(f"{name:12s} n={stats['n']} median_paired_diff={stats['median_paired_diff']:+.6f} "
                  f"diff_of_medians={stats['median_diff_of_medians']:+.6f} win_rate={stats['win_rate']:.4f}")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=1, sort_keys=True), encoding="utf-8")
    print(f"wrote {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
