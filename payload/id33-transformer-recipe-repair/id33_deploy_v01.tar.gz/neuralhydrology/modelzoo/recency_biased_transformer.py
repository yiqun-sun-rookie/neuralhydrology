"""Causal Transformer with three switchable, information-preserving recency biases (ID32).

The backbone is the ID30 dense control: identical module names, identical seeded
initialization, identical rotary attention, RMS normalization and gated feed-forward. With
every option disabled this model reproduces ``ModernCausalTransformer`` exactly, so the ID30
D01 result can be cited as the ablation baseline without spending a repeat training run.

Three independent additions, each testing one clause of the diagnosis that a Transformer
underperforms a long short-term memory network on rainfall-runoff because it lacks an
accumulate-and-decay inductive bias rather than because it lacks capacity:

``recency_ema_decays``
    Causal exponentially weighted moving averages of selected raw dynamic inputs are
    projected and added to the hidden state. These are deterministic causal functions of
    inputs the model already receives, so the information content is unchanged and only the
    representation differs. Tests "the model cannot cheaply build an accumulator".
``recency_decay_attention``
    Each attention head carries its own learnable exponential distance penalty on the
    attention logits, which makes the head behave as a linear reservoir whose time constant
    is readable after training. Tests "the model has no recency prior".
``recency_conv_kernel``
    A causal depthwise convolution mixes neighbouring days before attention. Tests "the model
    has no cheap local mixing".

This module never modifies the ID30 or ID31 implementations; it only imports from them.
"""

from __future__ import annotations

from typing import Dict, List, Optional

import torch
from torch import nn
from torch.nn import functional

from neuralhydrology.modelzoo.cudalstm import CudaLSTM
from neuralhydrology.modelzoo.modern_causal_transformer import (
    GatedFeedForward,
    ModernCausalTransformer,
    RMSNorm,
    RotaryEmbedding,
)
from neuralhydrology.utils.config import Config


def causal_ema(x: torch.Tensor, decay: float) -> torch.Tensor:
    """Return the causal exponentially weighted moving average of ``x`` along the time axis.

    Parameters
    ----------
    x : torch.Tensor
        Tensor shaped ``[batch, days, features]``.
    decay : float
        Retention factor in ``(0, 1)``. The equivalent memory length is ``1 / (1 - decay)`` days.

    Returns
    -------
    torch.Tensor
        Tensor shaped ``[batch, days, features]``. Entry ``t`` depends only on days ``<= t``.
    """
    if not 0.0 < decay < 1.0:
        raise ValueError(f"EMA decay must lie strictly between 0 and 1, got {decay}.")
    sequence_length = x.shape[1]
    exponents = torch.arange(sequence_length, device=x.device, dtype=x.dtype)
    decay_tensor = torch.as_tensor(decay, device=x.device, dtype=x.dtype)
    kernel = (1.0 - decay_tensor) * torch.pow(decay_tensor, exponents)
    channels = x.shape[-1]
    weight = kernel.flip(0).view(1, 1, -1).repeat(channels, 1, 1)
    padded = functional.pad(x.transpose(1, 2), (sequence_length - 1, 0))
    filtered = functional.conv1d(padded, weight, groups=channels)
    return filtered.transpose(1, 2)


class RecencyBiasedSelfAttention(nn.Module):
    """Rotary causal self-attention with an optional learnable per-head exponential distance penalty.

    Module and parameter names match ``CausalSelfAttention`` so that name-derived seeding
    produces an identical initialization for the shared weights.
    """

    def __init__(self, model_width: int, num_heads: int, dropout: float, decay_attention: bool):
        super().__init__()
        if model_width % num_heads != 0:
            raise ValueError(f"Model width {model_width} must be divisible by {num_heads} attention heads.")
        head_dimension = model_width // num_heads
        if head_dimension % 2 != 0:
            raise ValueError(
                f"Rotary position encoding requires an even attention-head dimension, got {head_dimension}.")

        self.model_width = model_width
        self.num_heads = num_heads
        self.head_dimension = head_dimension
        self.dropout = dropout
        self.query_projection = nn.Linear(model_width, model_width, bias=False)
        self.key_projection = nn.Linear(model_width, model_width, bias=False)
        self.value_projection = nn.Linear(model_width, model_width, bias=False)
        self.output_projection = nn.Linear(model_width, model_width, bias=False)
        self.rotary_embedding = RotaryEmbedding(head_dimension)
        self.residual_dropout = nn.Dropout(dropout)

        self.decay_attention = decay_attention
        if decay_attention:
            # Geometrically spaced initial slopes give the heads distinct starting memory
            # lengths of roughly 4, 16, 64 and 256 days for a four-head model.
            slopes = torch.tensor([2.0**(-2.0 * (index + 1)) for index in range(num_heads)])
            # Inverse softplus, so that softplus(decay_logit) equals the target slope at start.
            self.decay_logit = nn.Parameter(torch.log(torch.expm1(slopes)))

    def head_decay_rates(self) -> Optional[torch.Tensor]:
        """Return the current per-head decay slope, or ``None`` when the penalty is disabled."""
        if not self.decay_attention:
            return None
        return functional.softplus(self.decay_logit).detach()

    def _split_heads(self, x: torch.Tensor) -> torch.Tensor:
        batch_size, sequence_length, _ = x.shape
        return x.view(batch_size, sequence_length, self.num_heads, self.head_dimension).transpose(1, 2)

    def _decay_mask(self, sequence_length: int, device: torch.device, dtype: torch.dtype) -> torch.Tensor:
        positions = torch.arange(sequence_length, device=device)
        distance = (positions.view(-1, 1) - positions.view(1, -1)).to(dtype)
        future = distance < 0
        slopes = functional.softplus(self.decay_logit).to(device=device, dtype=dtype)
        bias = -slopes.view(-1, 1, 1) * distance.clamp(min=0.0).unsqueeze(0)
        return bias.masked_fill(future.unsqueeze(0), float("-inf"))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        query = self._split_heads(self.query_projection(x))
        key = self._split_heads(self.key_projection(x))
        value = self._split_heads(self.value_projection(x))
        query, key = self.rotary_embedding(query, key)

        if self.decay_attention:
            attention_mask = self._decay_mask(x.shape[1], x.device, query.dtype)
            attended = functional.scaled_dot_product_attention(query,
                                                               key,
                                                               value,
                                                               attn_mask=attention_mask,
                                                               dropout_p=self.dropout if self.training else 0.0,
                                                               is_causal=False)
        else:
            attended = functional.scaled_dot_product_attention(query,
                                                               key,
                                                               value,
                                                               dropout_p=self.dropout if self.training else 0.0,
                                                               is_causal=True)
        attended = attended.transpose(1, 2).contiguous().view(x.shape)
        return self.residual_dropout(self.output_projection(attended))


class RecencyBiasedBlock(nn.Module):
    """Pre-normalized Transformer block using the recency-biased attention.

    Attribute names match ``ModernTransformerBlock`` to preserve name-derived seeding.
    """

    def __init__(self, model_width: int, num_heads: int, feed_forward: nn.Module, dropout: float,
                 decay_attention: bool):
        super().__init__()
        self.attention_norm = RMSNorm(model_width)
        self.attention = RecencyBiasedSelfAttention(model_width, num_heads, dropout, decay_attention)
        self.feed_forward_norm = RMSNorm(model_width)
        self.feed_forward = feed_forward

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.attention(self.attention_norm(x))
        x = x + self.feed_forward(self.feed_forward_norm(x))
        return x


class RecencyBiasedTransformer(ModernCausalTransformer):
    """Dense causal Transformer with optional accumulation, recency and local-mixing biases."""

    module_parts = ["embedding_net", "input_projection", "blocks", "final_norm", "head"]

    def __init__(self, cfg: Config):
        super().__init__(cfg=cfg)
        if self.is_moe:
            raise ValueError("recency_biased_transformer does not support the mixture-of-experts variant.")

        self.ema_decays: List[float] = [float(value) for value in cfg.recency_ema_decays]
        self.ema_inputs: List[str] = list(cfg.recency_ema_inputs)
        self.decay_attention: bool = bool(cfg.recency_decay_attention)
        self.conv_kernel: int = int(cfg.recency_conv_kernel)

        if self.ema_decays and not self.ema_inputs:
            raise ValueError("recency_ema_decays requires a non-empty recency_ema_inputs list.")
        if self.ema_inputs and not self.ema_decays:
            raise ValueError("recency_ema_inputs requires a non-empty recency_ema_decays list.")
        for name in self.ema_inputs:
            if name not in cfg.dynamic_inputs:
                raise ValueError(f"recency_ema_inputs entry '{name}' is not a declared dynamic input.")
        if self.conv_kernel < 0 or (self.conv_kernel > 0 and self.conv_kernel % 2 == 0):
            raise ValueError(f"recency_conv_kernel must be zero or a positive odd integer, got {self.conv_kernel}.")

        # Rebuild the blocks so that attention can carry the optional decay penalty. Module names,
        # shapes and construction order are unchanged, so seeded initialization is unaffected.
        self.blocks = nn.ModuleList([
            RecencyBiasedBlock(self.model_width,
                               cfg.transformer_nheads,
                               GatedFeedForward(self.model_width,
                                                cfg.transformer_dim_feedforward,
                                                dropout=cfg.transformer_dropout),
                               cfg.transformer_dropout,
                               decay_attention=self.decay_attention)
            for _ in range(cfg.transformer_nlayers)
        ])

        if self.ema_decays:
            self.ema_projection = nn.Linear(len(self.ema_decays) * len(self.ema_inputs),
                                            self.model_width,
                                            bias=False)
        if self.conv_kernel > 0:
            self.local_convolution = nn.Conv1d(self.model_width,
                                               self.model_width,
                                               kernel_size=self.conv_kernel,
                                               groups=self.model_width,
                                               bias=False)

        if cfg.seed is None:
            self.apply(self._initialize_module)
        else:
            self._initialize_named_parameters(cfg.seed)

        # Both additive injections start as exact no-ops so that training begins from the
        # unmodified dense control and any gain is attributable to what the model learns to use.
        if self.ema_decays:
            nn.init.zeros_(self.ema_projection.weight)
        if self.conv_kernel > 0:
            with torch.no_grad():
                self.local_convolution.weight.zero_()

    def _ema_features(self, data: dict) -> torch.Tensor:
        columns = []
        for name in self.ema_inputs:
            series = data["x_d"][name]
            if series.dim() == 2:
                series = series.unsqueeze(-1)
            for decay in self.ema_decays:
                columns.append(causal_ema(series, decay))
        return torch.cat(columns, dim=-1)

    def forward(self, data: dict[str, torch.Tensor | dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        embedding = self.embedding_net(data)
        hidden = self.input_projection(embedding.transpose(0, 1))

        if self.ema_decays:
            hidden = hidden + self.ema_projection(self._ema_features(data).to(hidden.dtype))
        if self.conv_kernel > 0:
            padded = functional.pad(hidden.transpose(1, 2), (self.conv_kernel - 1, 0))
            hidden = hidden + self.local_convolution(padded).transpose(1, 2)

        for block in self.blocks:
            hidden = block(hidden)

        prediction = self.head(self.output_dropout(self.final_norm(hidden)))
        prediction["embedding"] = embedding
        if self.decay_attention and not self.training:
            rates = torch.stack([block.attention.head_decay_rates() for block in self.blocks])
            prediction["attention_decay_rates"] = rates.reshape(1, -1)
        return prediction

    def learned_memory_days(self) -> Optional[torch.Tensor]:
        """Return per-layer, per-head memory lengths in days, or ``None`` when the penalty is disabled."""
        if not self.decay_attention:
            return None
        return torch.stack([1.0 / block.attention.head_decay_rates() for block in self.blocks])


class RecencyBiasedLSTM(CudaLSTM):
    """Long short-term memory network with the same optional accumulation injection.

    This is the control that separates "exponentially weighted antecedent forcing is useful to
    any model" from "it specifically repairs what the Transformer cannot build for itself".
    The injection is deliberately identical in form to the Transformer variant: a zero
    initialized additive projection into the embedded input, so training starts from the
    unmodified control.
    """

    module_parts = ["embedding_net", "lstm", "head"]

    def __init__(self, cfg: Config):
        super().__init__(cfg=cfg)
        self.ema_decays: List[float] = [float(value) for value in cfg.recency_ema_decays]
        self.ema_inputs: List[str] = list(cfg.recency_ema_inputs)
        if self.ema_decays and not self.ema_inputs:
            raise ValueError("recency_ema_decays requires a non-empty recency_ema_inputs list.")
        if self.ema_inputs and not self.ema_decays:
            raise ValueError("recency_ema_inputs requires a non-empty recency_ema_decays list.")
        for name in self.ema_inputs:
            if name not in cfg.dynamic_inputs:
                raise ValueError(f"recency_ema_inputs entry '{name}' is not a declared dynamic input.")
        if self.ema_decays:
            self.ema_projection = nn.Linear(len(self.ema_decays) * len(self.ema_inputs),
                                            self.embedding_net.output_size,
                                            bias=False)
            nn.init.zeros_(self.ema_projection.weight)

    def _ema_features(self, data: dict) -> torch.Tensor:
        columns = []
        for name in self.ema_inputs:
            series = data["x_d"][name]
            if series.dim() == 2:
                series = series.unsqueeze(-1)
            for decay in self.ema_decays:
                columns.append(causal_ema(series, decay))
        return torch.cat(columns, dim=-1)

    def forward(self, data: dict[str, torch.Tensor | dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        if not self.ema_decays:
            return super().forward(data)
        embedded = self.embedding_net(data)
        # ``embedding_net`` emits [days, batch, width]; the causal filters work in [batch, days, width].
        injection = self.ema_projection(self._ema_features(data).to(embedded.dtype)).transpose(0, 1)
        return self._forward_with_injection(data, embedded + injection)

    def _forward_with_injection(self, data: dict, x_d: torch.Tensor) -> Dict[str, torch.Tensor]:
        # Mirror CudaLSTM.forward exactly, including the assimilation entry point: callers may
        # supply initial hidden and cell states, and downstream code expects ``lstm_output``.
        batch_size = x_d.shape[1]
        if "h_n" in data:
            h_0 = data["h_n"].transpose(0, 1).contiguous()
        else:
            h_0 = x_d.new_zeros((1, batch_size, self.lstm.hidden_size))
        if "c_n" in data:
            c_0 = data["c_n"].transpose(0, 1).contiguous()
        else:
            c_0 = x_d.new_zeros((1, batch_size, self.lstm.hidden_size))
        lstm_output, (h_n, c_n) = self.lstm(x_d, (h_0, c_0))
        lstm_output = lstm_output.transpose(0, 1)
        prediction = {
            "lstm_output": lstm_output,
            "h_n": h_n.transpose(0, 1),
            "c_n": c_n.transpose(0, 1),
        }
        prediction.update(self.head(self.dropout(lstm_output)))
        return prediction
