"""Train one configuration with the determinism knobs explicitly on or off, then digest the weights.

Why this script exists
----------------------
``neuralhydrology`` seeds numpy, torch, torch.cuda and the dataloader generator
(``neuralhydrology/training/basetrainer.py:393-395``) but never sets any of

    torch.use_deterministic_algorithms   torch.backends.cudnn.deterministic
    torch.backends.cudnn.benchmark       torch.backends.cuda.matmul.allow_tf32
    torch.backends.cudnn.allow_tf32      CUBLAS_WORKSPACE_CONFIG

so a seeded run is repeatable only up to whatever kernels the backend happens to pick.
Meanwhile ``src/transformer_recipe_repair/hpc/submit_packed_arms.slurm:11-13`` justifies
packing three arms onto one card with the ``HPC_PLAYBOOK`` result that concurrent tasks
produce bit-identical weights *under the frozen deterministic settings* -- settings that
were never switched on for ID33.  Batch 2 then failed to reproduce batch 1 on all five
Transformer arms (T1 moved +0.0268, 7.5x the 0.00356 seed-noise floor) while the cudalstm
arm reproduced to six decimals.

Usage: launch several copies concurrently on one card with identical arguments.  With
``--deterministic`` every replica's weight digest must be equal.  With ``--no-deterministic``
they are expected to differ, which is the control.

The script writes one JSON file per replica into ``--digest-dir`` and never touches the six
scored arm directories.
"""

import argparse
import hashlib
import json
import os
import platform
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[3]


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config-file", type=Path, required=True, help="Path to the probe config, relative to the repo root.")
    parser.add_argument("--gpu", type=int, default=0, help="GPU index handed to neuralhydrology.")
    parser.add_argument("--label", type=str, required=True, help="Replica label, e.g. r1. Only used to name outputs.")
    parser.add_argument("--digest-dir", type=Path, required=True, help="Directory that receives <label>.json.")
    determinism = parser.add_mutually_exclusive_group()
    determinism.add_argument("--deterministic", dest="deterministic", action="store_true")
    determinism.add_argument("--no-deterministic", dest="deterministic", action="store_false")
    parser.set_defaults(deterministic=True)
    return parser.parse_args()


def _enable_determinism() -> None:
    """Set every knob that has to be set before the first CUDA kernel runs.

    ``CUBLAS_WORKSPACE_CONFIG`` is read by cuBLAS when it initialises, so it must already be
    in the environment before ``torch`` is imported. The caller guarantees that ordering.
    """
    import torch

    torch.use_deterministic_algorithms(True, warn_only=False)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False


def _determinism_state() -> dict:
    import torch

    return {
        "cublas_workspace_config": os.environ.get("CUBLAS_WORKSPACE_CONFIG", ""),
        "deterministic_algorithms": bool(torch.are_deterministic_algorithms_enabled()),
        "cudnn_deterministic": bool(torch.backends.cudnn.deterministic),
        "cudnn_benchmark": bool(torch.backends.cudnn.benchmark),
        "matmul_allow_tf32": bool(torch.backends.cuda.matmul.allow_tf32),
        "cudnn_allow_tf32": bool(torch.backends.cudnn.allow_tf32),
    }


def _environment_fingerprint() -> dict:
    import torch

    fingerprint = {
        "python": platform.python_version(),
        "torch": torch.__version__,
        "cuda": torch.version.cuda,
        "cudnn": torch.backends.cudnn.version(),
        "node": platform.node(),
    }
    if torch.cuda.is_available():
        fingerprint["gpu_name"] = torch.cuda.get_device_name(0)
        fingerprint["gpu_capability"] = list(torch.cuda.get_device_capability(0))
        fingerprint["gpu_count_visible"] = torch.cuda.device_count()
    else:
        fingerprint["gpu_name"] = None
    return fingerprint


def _existing_run_dirs(base: Path) -> set:
    return {path for path in base.glob("*") if path.is_dir()} if base.is_dir() else set()


def _digest_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    args = _parse_args()

    # Must happen before torch is imported anywhere in this process.
    if args.deterministic:
        os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    else:
        os.environ.pop("CUBLAS_WORKSPACE_CONFIG", None)

    os.chdir(REPO_ROOT)
    sys.path.insert(0, str(REPO_ROOT))

    import torch  # noqa: F401  imported for its side effects on the settings below

    if args.deterministic:
        _enable_determinism()

    from neuralhydrology.nh_run import start_run
    from neuralhydrology.utils.config import Config

    config_path = (REPO_ROOT / args.config_file).resolve()
    config = Config(config_path)
    run_dir_base = (REPO_ROOT / config.run_dir).resolve()

    before = _existing_run_dirs(run_dir_base)
    record = {
        "label": args.label,
        "config_file": str(args.config_file),
        "config_sha256": _digest_file(config_path),
        "deterministic_requested": args.deterministic,
        "determinism_state": _determinism_state(),
        "environment": _environment_fingerprint(),
    }

    failure = None
    try:
        start_run(config_file=config_path, gpu=args.gpu)
    except Exception as error:  # noqa: BLE001  the failure itself is the result we want recorded
        failure = f"{type(error).__name__}: {error}"

    created = sorted(_existing_run_dirs(run_dir_base) - before)
    record["training_failed"] = failure
    record["run_dir"] = str(created[-1]) if created else None

    weights = {}
    if created:
        for checkpoint in sorted(created[-1].glob("model_epoch*.pt")):
            weights[checkpoint.name] = _digest_file(checkpoint)
    record["weight_sha256"] = weights

    args.digest_dir.mkdir(parents=True, exist_ok=True)
    output = args.digest_dir / f"{args.label}.json"
    output.write_text(json.dumps(record, indent=1, sort_keys=True), encoding="utf-8")

    print(f"[{args.label}] deterministic={args.deterministic} failed={failure}")
    for name, value in weights.items():
        print(f"[{args.label}] {name} {value}")
    if not weights:
        print(f"[{args.label}] NO WEIGHTS WRITTEN")
    return 1 if failure else 0


if __name__ == "__main__":
    sys.exit(main())
