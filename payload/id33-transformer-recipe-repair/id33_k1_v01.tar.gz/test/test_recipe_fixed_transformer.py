"""Focused tests for the ID33 initialization-contract repair.

Two assertions carry the arm. First, ``transformer_init_scheme: gpt2`` must reduce this class
bitwise to the ID30 dense control, so the treated arm differs from its baseline in exactly one
declared way. Second, ``fan_in`` must actually repair the three quantities measured on the
control: the embedding layers must keep their own initialization, the static half of the
residual stream must stop dominating the dynamic half, and the first block's attention must
stop starting at exactly uniform ``log(seq_length)`` entropy.
"""

import math
from pathlib import Path

import pytest
import torch
from ruamel.yaml import YAML

from neuralhydrology.modelzoo import get_model
from neuralhydrology.modelzoo.modern_causal_transformer import ModernCausalTransformer
from neuralhydrology.modelzoo.recipe_fixed_transformer import RecipeFixedTransformer
from neuralhydrology.utils.config import Config

BATCH = 4
DAYS = 64
DYNAMIC_INPUTS = ["PRCP(mm/day)", "Tmin(C)", "Tmax(C)", "SRAD(W/m2)", "Vp(Pa)"]
STATIC_ATTRIBUTES = [f"attr_{index}" for index in range(27)]


def _config(tmp_path: Path, **overrides) -> Config:
    tmp_path = Path(tmp_path)
    tmp_path.mkdir(parents=True, exist_ok=True)
    cfg = {
        "experiment_name": "id33_unit",
        "run_dir": str(tmp_path),
        "dataset": "camels_us",
        "data_dir": str(tmp_path),
        "model": "recipe_fixed_transformer",
        "head": "regression",
        "output_activation": "linear",
        "output_dropout": 0.0,
        "dynamics_embedding": {"type": "fc", "hiddens": [64], "activation": "linear", "dropout": 0.0},
        "statics_embedding": {"type": "fc", "hiddens": [64], "activation": "linear", "dropout": 0.0},
        "transformer_nheads": 4,
        "transformer_nlayers": 4,
        "transformer_dim_feedforward": 512,
        "transformer_dropout": 0.0,
        "optimizer": "Adam",
        "loss": "NSE",
        "learning_rate": {0: 1e-3},
        "batch_size": BATCH,
        "epochs": 30,
        "seq_length": DAYS,
        "predict_last_n": 1,
        "seed": 100,
        "forcings": ["maurer"],
        "dynamic_inputs": list(DYNAMIC_INPUTS),
        "target_variables": ["QObs(mm/d)"],
        "static_attributes": list(STATIC_ATTRIBUTES),
        "train_start_date": "01/10/1999",
        "train_end_date": "30/09/2006",
        "validation_start_date": "01/10/2006",
        "validation_end_date": "30/09/2008",
        "test_start_date": "01/10/2006",
        "test_end_date": "30/09/2008",
    }
    cfg.update(overrides)
    path = tmp_path / "config.yml"
    YAML().dump(cfg, path)
    return Config(path)


def _batch(seed: int = 0) -> dict:
    generator = torch.Generator().manual_seed(seed)
    return {
        "x_d": {name: torch.randn(BATCH, DAYS, 1, generator=generator) for name in DYNAMIC_INPUTS},
        "x_s": torch.randn(BATCH, len(STATIC_ATTRIBUTES), generator=generator),
    }


def _embedding_linears(model):
    return {name: module for name, module in model.named_modules()
            if isinstance(module, torch.nn.Linear) and name.startswith("embedding_net")}


def _final_position_attention_entropy(model, data) -> float:
    with torch.no_grad():
        embedding = model.embedding_net(data)
        hidden = model.input_projection(embedding.transpose(0, 1))
        block = model.blocks[0]
        attention = block.attention
        x = block.attention_norm(hidden)
        query = attention._split_heads(attention.query_projection(x))
        key = attention._split_heads(attention.key_projection(x))
        query, key = attention.rotary_embedding(query, key)
        logits = (query @ key.transpose(-2, -1)) / math.sqrt(attention.head_dimension)
        future = torch.triu(torch.ones(DAYS, DAYS, dtype=torch.bool), diagonal=1)
        probabilities = torch.softmax(logits.masked_fill(future, float("-inf")), dim=-1)
        entropy = -(probabilities * torch.log(probabilities.clamp_min(1e-12))).sum(-1)
        return float(entropy[:, :, -1].mean())


def _residual_power_ratio(model, data) -> float:
    with torch.no_grad():
        embedding = model.embedding_net(data)
    width = embedding.shape[-1]
    dynamic = embedding[..., :width // 2]
    static = embedding[..., width // 2:]
    return float(static.pow(2).mean() / dynamic.pow(2).mean())


# --------------------------------------------------------------------------------------
# The control must be reproducible bitwise
# --------------------------------------------------------------------------------------
def test_gpt2_scheme_reproduces_the_dense_control_bitwise(tmp_path):
    control = ModernCausalTransformer(_config(tmp_path / "c", model="modern_transformer")).eval()
    treated = RecipeFixedTransformer(_config(tmp_path / "t")).eval()
    assert set(control.state_dict()) == set(treated.state_dict())
    for name, tensor in control.state_dict().items():
        assert torch.equal(tensor, treated.state_dict()[name]), f"initialization differs for {name}"
    data = _batch()
    with torch.no_grad():
        assert torch.equal(control(data)["y_hat"], treated(data)["y_hat"])


def test_factory_dispatch(tmp_path):
    assert isinstance(get_model(_config(tmp_path)), RecipeFixedTransformer)


@pytest.mark.parametrize("scheme", ["adamw", "kaiming", ""])
def test_invalid_init_scheme_is_rejected(tmp_path, scheme):
    with pytest.raises(ValueError):
        RecipeFixedTransformer(_config(tmp_path, transformer_init_scheme=scheme))


def test_fan_in_requires_a_seed(tmp_path):
    with pytest.raises(ValueError):
        RecipeFixedTransformer(_config(tmp_path, transformer_init_scheme="fan_in", seed=None))


# --------------------------------------------------------------------------------------
# The repair must actually repair the three measured defects
# --------------------------------------------------------------------------------------
def test_fan_in_restores_the_input_embedding_scale(tmp_path):
    """The blanket scheme compresses the embeddings; the repaired scheme must restore them."""
    control = ModernCausalTransformer(_config(tmp_path / "c", model="modern_transformer")).eval()
    fixed = RecipeFixedTransformer(_config(tmp_path / "f", transformer_init_scheme="fan_in")).eval()

    for name, module in _embedding_linears(control).items():
        fan_in = module.weight.shape[1]
        reference = 1.0 / math.sqrt(fan_in)
        control_ratio = float(module.weight.std()) / reference
        fixed_ratio = float(_embedding_linears(fixed)[name].weight.std()) / reference
        # The control compresses these layers by roughly an order of magnitude.
        assert control_ratio < 0.35, (name, control_ratio)
        # The repaired arm must land within a factor of two of the fan-in scale.
        assert 0.4 < fixed_ratio < 2.5, (name, fixed_ratio)


def test_fan_in_reduces_the_static_to_dynamic_power_imbalance(tmp_path):
    data = _batch()
    control = ModernCausalTransformer(_config(tmp_path / "c", model="modern_transformer")).eval()
    fixed = RecipeFixedTransformer(_config(tmp_path / "f", transformer_init_scheme="fan_in")).eval()
    control_ratio = _residual_power_ratio(control, data)
    fixed_ratio = _residual_power_ratio(fixed, data)
    assert control_ratio > 3.0, control_ratio
    assert fixed_ratio < control_ratio / 2.0, (control_ratio, fixed_ratio)


def test_fan_in_breaks_the_uniform_attention_start(tmp_path):
    """The control starts at exactly log(seq_length); the repaired arm must not."""
    data = _batch()
    control = ModernCausalTransformer(_config(tmp_path / "c", model="modern_transformer")).eval()
    fixed = RecipeFixedTransformer(_config(tmp_path / "f", transformer_init_scheme="fan_in")).eval()
    uniform = math.log(DAYS)
    control_entropy = _final_position_attention_entropy(control, data)
    fixed_entropy = _final_position_attention_entropy(fixed, data)
    assert abs(control_entropy - uniform) < 0.01, (control_entropy, uniform)
    assert uniform - fixed_entropy > 0.05, (fixed_entropy, uniform)


def test_fan_in_scales_residual_projections_by_depth(tmp_path):
    cfg = _config(tmp_path, transformer_init_scheme="fan_in")
    model = RecipeFixedTransformer(cfg).eval()
    depth_scale = 1.0 / math.sqrt(2.0 * cfg.transformer_nlayers)
    projection = model.blocks[0].attention.output_projection
    expected = depth_scale / math.sqrt(projection.weight.shape[1])
    assert math.isclose(float(projection.weight.std()), expected, rel_tol=0.25)


def test_fan_in_is_deterministic_and_trains(tmp_path):
    cfg = _config(tmp_path, transformer_init_scheme="fan_in")
    data = _batch()
    first, second = RecipeFixedTransformer(cfg).eval(), RecipeFixedTransformer(cfg).eval()
    with torch.no_grad():
        assert torch.equal(first(data)["y_hat"], second(data)["y_hat"])
    first.train()
    first(data)["y_hat"].sum().backward()
    grads = [p.grad for p in first.parameters() if p.grad is not None]
    assert grads and all(torch.isfinite(g).all() for g in grads)


def test_recency_options_still_work_under_the_repaired_scheme(tmp_path):
    """ID32's injections must remain exact no-ops at step zero under the new scheme."""
    cfg = _config(tmp_path,
                  transformer_init_scheme="fan_in",
                  recency_ema_decays=[0.9, 0.97, 0.99],
                  recency_ema_inputs=["PRCP(mm/day)"],
                  recency_decay_attention=True)
    model = RecipeFixedTransformer(cfg)
    assert torch.count_nonzero(model.ema_projection.weight) == 0
    model.train()
    model(_batch())["y_hat"].sum().backward()
    assert torch.count_nonzero(model.ema_projection.weight.grad) > 0
    for block in model.blocks:
        assert block.attention.decay_logit.grad is not None


def test_initialization_report_records_the_measured_quantities(tmp_path):
    fixed = RecipeFixedTransformer(_config(tmp_path, transformer_init_scheme="fan_in"))
    report = fixed.initialization_report()
    assert report["init_scheme_is_fan_in"] == 1.0
    assert any(key.endswith(".fan_in_reference") for key in report)


def test_conv_embedding_is_an_exact_no_op_at_initialization(tmp_path):
    """K1 (Liu-style causal convolutional embedding) must equal its parent T2 at step zero."""
    parent = get_model(_config(tmp_path, transformer_init_scheme="fan_in", seed=7)).eval()
    child = get_model(_config(tmp_path, transformer_init_scheme="fan_in", seed=7,
                              transformer_conv_embedding_kernel=7, transformer_conv_embedding_layers=2)).eval()
    batch = _batch()
    with torch.no_grad():
        assert torch.equal(parent(batch)["y_hat"], child(batch)["y_hat"])
    assert sum(p.numel() for p in child.parameters()) > sum(p.numel() for p in parent.parameters())


def test_conv_embedding_is_causal_and_trainable(tmp_path):
    model = get_model(_config(tmp_path, transformer_init_scheme="fan_in", seed=7,
                              transformer_conv_embedding_kernel=5, transformer_conv_embedding_layers=2))
    batch = _batch()
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    model.train()
    model(batch)["y_hat"].pow(2).mean().backward()
    optimizer.step()
    assert float(model.conv_embedding.output.weight.abs().max()) > 0.0
    model.eval()
    perturbed = {"x_d": {k: v.clone() for k, v in batch["x_d"].items()}, "x_s": batch["x_s"]}
    for name in perturbed["x_d"]:
        perturbed["x_d"][name][:, -1] += 5.0
    with torch.no_grad():
        before, after = model(batch)["y_hat"], model(perturbed)["y_hat"]
    assert torch.allclose(before[:, :-1], after[:, :-1])
    assert not torch.allclose(before[:, -1], after[:, -1])


def test_conv_embedding_initialization_is_seeded(tmp_path):
    first = get_model(_config(tmp_path, transformer_init_scheme="fan_in", seed=7, transformer_conv_embedding_kernel=7))
    second = get_model(_config(tmp_path, transformer_init_scheme="fan_in", seed=7, transformer_conv_embedding_kernel=7))
    for left, right in zip(first.state_dict().values(), second.state_dict().values()):
        assert torch.equal(left, right)


@pytest.mark.parametrize("kernel", [1, -3])
def test_conv_embedding_rejects_degenerate_kernels(tmp_path, kernel):
    with pytest.raises(ValueError):
        get_model(_config(tmp_path, transformer_init_scheme="fan_in", seed=7, transformer_conv_embedding_kernel=kernel))
