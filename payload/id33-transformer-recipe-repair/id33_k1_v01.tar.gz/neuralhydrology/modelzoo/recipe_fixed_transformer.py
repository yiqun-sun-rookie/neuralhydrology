"""Causal Transformer with a corrected initialization contract (ID33).

The ID30 dense control initializes every ``nn.Linear`` in the model with ``normal(0, 0.02)``.
That constant is GPT-2's, chosen for width 768. Applied here at width 128 it is wrong in two
separate ways, both measured on the instantiated ID30 model:

* The loop runs over ``self.named_modules()`` and therefore also overwrites the input
  embedding layers, which had already been given their own fan-scaled initialization. The
  dynamic-forcing embedding (fan-in 5) is compressed 23-fold, from a fan-scaled 0.447 to
  0.019; the static-attribute embedding (fan-in 27) is compressed 9.9-fold.
* With 27 static inputs and 5 dynamic inputs sharing one standard deviation, the static half
  of the residual stream carries 5.5 times the power of the dynamic half at initialization,
  and the first block's attention starts at an entropy of 5.598 nats against
  ``log(270) = 5.598``. The model therefore begins as an exactly uniform 270-day average,
  which is the worst available prior for rainfall-runoff.

The long short-term memory control never passes through that function: it keeps PyTorch's
fan-scaled initialization and additionally sets ``initial_forget_bias``, an explicit
long-memory prior. The blanket constant is thus a handicap carried by one arm of the
comparison and not the other.

``transformer_init_scheme: fan_in`` replaces it with per-layer fan-in scaling, depth-scaled
residual output projections, and restores the input embedding layers to the fan-scaled uniform
distribution ``torch.nn.Linear`` would have given them. Restoring rather than skipping is
required because the parent constructor has already overwritten them by the time this runs.
Fan-in scaling also equalizes the two halves of the residual stream by construction: with
5 dynamic and 27 static inputs the output powers become ``5 * (1/sqrt(15))**2`` and
``27 * (1/sqrt(81))**2``, both 0.333. The default
``gpt2`` reproduces the inherited behaviour exactly, so this class is a strict superset of
its parent and can be reduced to it by configuration alone.

This module imports from the ID30 and ID32 implementations and modifies neither.
"""

from __future__ import annotations

import math
from typing import Dict

import torch
from torch import nn
from torch.nn import functional

from neuralhydrology.modelzoo.modern_causal_transformer import RMSNorm
from neuralhydrology.modelzoo.recency_biased_transformer import RecencyBiasedTransformer
from neuralhydrology.utils.config import Config

# Module-name prefixes whose initialization belongs to the layer that created it.
_EMBEDDING_PREFIX = "embedding_net"

# Residual write-back projections, scaled down by depth so that the residual stream variance
# does not grow with the number of blocks.
_RESIDUAL_PROJECTION_SUFFIXES = ("attention.output_projection", "feed_forward.down_projection")


class CausalConvEmbedding(nn.Module):
    """Convolutional input embedding of Liu, Bian, Lawson & Shen (2024, J. Hydrology 637:131389).

    Their "modified Transformer" -- the one that matched the long short-term memory baseline on CAMELS
    (KGE 0.74 vs 0.73 single-forcing, 0.80 vs 0.80 multi-forcing, ten-seed ensembles) -- adds, just
    before the attention layers, two stacked one-dimensional convolution sub-layers with a residual
    connection between them and ReLU, whose output goes through a linear layer and is added to the
    input embedding. The kernel only looks backward so no future day leaks into the current step.

    ID32's ``recency_conv_kernel`` is a different object: a single depthwise (per-channel) filter on
    the projected hidden state, without a nonlinearity. This module mixes channels and is nonlinear.
    """

    def __init__(self, input_size: int, width: int, kernel: int, num_layers: int):
        super().__init__()
        if kernel < 2:
            raise ValueError(f"transformer_conv_embedding_kernel must be >= 2, got {kernel}.")
        if num_layers < 1:
            raise ValueError(f"transformer_conv_embedding_layers must be >= 1, got {num_layers}.")
        self.kernel = kernel
        channels = [input_size] + [width] * num_layers
        self.convolutions = nn.ModuleList(
            nn.Conv1d(channels[i], channels[i + 1], kernel_size=kernel) for i in range(num_layers))
        self.output = nn.Linear(width, width, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """``x`` is (batch, time, input_size); returns (batch, time, width)."""
        hidden = x.transpose(1, 2)
        previous = None
        for convolution in self.convolutions:
            out = torch.relu(convolution(functional.pad(hidden, (self.kernel - 1, 0))))
            hidden = out + previous if previous is not None else out
            previous = out
        return self.output(hidden.transpose(1, 2))


class RecipeFixedTransformer(RecencyBiasedTransformer):
    """Dense causal Transformer whose initialization contract can be corrected by configuration."""

    module_parts = ["embedding_net", "input_projection", "blocks", "final_norm", "head"]

    def __init__(self, cfg: Config):
        super().__init__(cfg=cfg)
        self.init_scheme = str(cfg.transformer_init_scheme).lower()
        if self.init_scheme not in {"gpt2", "fan_in"}:
            raise ValueError(f"transformer_init_scheme must be 'gpt2' or 'fan_in', got {self.init_scheme!r}.")
        self.conv_embedding_kernel = int(cfg.transformer_conv_embedding_kernel)
        if self.conv_embedding_kernel < 0:
            raise ValueError(f"transformer_conv_embedding_kernel must be 0 (off) or >= 2, got {self.conv_embedding_kernel}.")
        if self.conv_embedding_kernel > 0:
            self.conv_input_names = list(cfg.dynamic_inputs)
            self.conv_embedding = CausalConvEmbedding(input_size=len(self.conv_input_names),
                                                      width=self.model_width,
                                                      kernel=self.conv_embedding_kernel,
                                                      num_layers=int(cfg.transformer_conv_embedding_layers))
            # House rule shared with the ID32 injections: an additive path starts as an exact no-op, so
            # step zero of this arm equals step zero of its parent and the change is the one declared factor.
            nn.init.zeros_(self.conv_embedding.output.weight)
        if self.init_scheme == "fan_in":
            if cfg.seed is None:
                raise ValueError("The fan_in initialization scheme requires an explicit seed for reproducibility.")
            self._fan_in_initialize(cfg.seed, cfg.transformer_nlayers)

    def _fan_in_initialize(self, base_seed: int, num_layers: int) -> None:
        """Re-initialize every Linear outside the input embedding with fan-in scaling.

        The seed for each parameter is still derived from its full name, exactly as the parent
        does, so the arm remains reproducible and differs from the control in scale only.
        """
        residual_scale = 1.0 / math.sqrt(2.0 * num_layers)
        for module_name, module in self.named_modules():
            if module_name.startswith(_EMBEDDING_PREFIX):
                # The parent constructor has already overwritten these with the blanket
                # constant, so skipping is not enough: restore the fan-scaled uniform
                # distribution that torch.nn.Linear would have given them.
                if isinstance(module, nn.Linear):
                    fan_in = module.weight.shape[1]
                    bound = 1.0 / math.sqrt(fan_in)
                    generator = torch.Generator(device=module.weight.device)
                    generator.manual_seed(self._derive_parameter_seed(base_seed, f"{module_name}.weight"))
                    with torch.no_grad():
                        module.weight.uniform_(-bound, bound, generator=generator)
                    if module.bias is not None:
                        nn.init.zeros_(module.bias)
                continue
            if isinstance(module, nn.Linear):
                parameter_name = f"{module_name}.weight"
                fan_in = module.weight.shape[1]
                std = 1.0 / math.sqrt(fan_in)
                if module_name.endswith(_RESIDUAL_PROJECTION_SUFFIXES):
                    std *= residual_scale
                generator = torch.Generator(device=module.weight.device)
                generator.manual_seed(self._derive_parameter_seed(base_seed, parameter_name))
                with torch.no_grad():
                    module.weight.normal_(mean=0.0, std=std, generator=generator)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
            elif isinstance(module, RMSNorm):
                nn.init.ones_(module.weight)

        # The additive injections inherited from ID32 must stay exact no-ops at step zero.
        if self.ema_decays:
            nn.init.zeros_(self.ema_projection.weight)
        if self.conv_kernel > 0:
            with torch.no_grad():
                self.local_convolution.weight.zero_()
        if self.conv_embedding_kernel > 0:
            for index, convolution in enumerate(self.conv_embedding.convolutions):
                fan_in = convolution.weight.shape[1] * convolution.weight.shape[2]
                bound = 1.0 / math.sqrt(fan_in)
                generator = torch.Generator(device=convolution.weight.device)
                generator.manual_seed(
                    self._derive_parameter_seed(base_seed, f"conv_embedding.convolutions.{index}.weight"))
                with torch.no_grad():
                    convolution.weight.uniform_(-bound, bound, generator=generator)
                    convolution.bias.zero_()
            nn.init.zeros_(self.conv_embedding.output.weight)

    def _conv_embedding_features(self, data: dict) -> torch.Tensor:
        columns = []
        for name in self.conv_input_names:
            series = data["x_d"][name]
            columns.append(series.unsqueeze(-1) if series.dim() == 2 else series)
        return torch.cat(columns, dim=-1)

    def forward(self, data: dict[str, torch.Tensor | dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        # Identical to RecencyBiasedTransformer.forward, with the convolutional embedding added at the
        # same point as the ID32 injections so every additive path shares one contract.
        embedding = self.embedding_net(data)
        hidden = self.input_projection(embedding.transpose(0, 1))

        if self.ema_decays:
            hidden = hidden + self.ema_projection(self._ema_features(data).to(hidden.dtype))
        if self.conv_kernel > 0:
            padded = functional.pad(hidden.transpose(1, 2), (self.conv_kernel - 1, 0))
            hidden = hidden + self.local_convolution(padded).transpose(1, 2)
        if self.conv_embedding_kernel > 0:
            hidden = hidden + self.conv_embedding(self._conv_embedding_features(data).to(hidden.dtype))

        for block in self.blocks:
            hidden = block(hidden)

        prediction = self.head(self.output_dropout(self.final_norm(hidden)))
        prediction["embedding"] = embedding
        if self.decay_attention and not self.training:
            rates = torch.stack([block.attention.head_decay_rates() for block in self.blocks])
            prediction["attention_decay_rates"] = rates.reshape(1, -1)
        return prediction

    def initialization_report(self) -> Dict[str, float]:
        """Return the two quantities that motivated this class, for the run record."""
        report: Dict[str, float] = {"init_scheme_is_fan_in": float(self.init_scheme == "fan_in")}
        for module_name, module in self.named_modules():
            if isinstance(module, nn.Linear) and module_name.startswith(_EMBEDDING_PREFIX):
                fan_in = module.weight.shape[1]
                report[f"{module_name}.std"] = float(module.weight.std())
                report[f"{module_name}.fan_in_reference"] = float(1.0 / math.sqrt(fan_in))
        return report
