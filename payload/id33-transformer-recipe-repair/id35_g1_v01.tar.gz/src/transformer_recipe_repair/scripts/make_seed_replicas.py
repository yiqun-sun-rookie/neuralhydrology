"""Generate seed-replica configs and registry rows for the ID33 seed-replication stage.

Each replica is the base arm's config with three lines changed -- experiment_name, run_dir and
seed -- and nothing else; audit_configs enforces that. The registry row carries the replica's
own config hash so run_development's registry check still binds every file that trains.

Why these three arms and eight seeds: after batch 3 (deterministic), T5 and T2 are the same
model (T5 - T2 = +/-0.001, p=0.91), so the repaired Transformer is T2. Its comparison target is
the deterministic long short-term memory baseline C4, and the deterministic dense control C3
carries the initialization effect's error bar. Seed noise measured on C5 - C3 is 0.004 on the
difference of medians and 0.009 on the paired median, so with eight seeds per arm the standard
error of an arm-to-arm difference is about 0.003: enough to decide whether the observed paired
deficit of -0.008 against the LSTM is real, and not wasted on resolving a 0.001 that would count
as matched anyway.

Idempotent: re-running skips configs and rows that already exist.
"""

import csv
import hashlib
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[3]
CONFIG_DIR = REPO_ROOT / "src/transformer_recipe_repair/configs"
REGISTRY = REPO_ROOT / "src/transformer_recipe_repair/registry/experiments.csv"

PLAN = {
    "T2": [200, 300, 400, 500, 600, 700, 800],
    "C4": [200, 300, 400, 500, 600, 700, 800],
    "C3": [300, 400, 500, 600, 700, 800],  # seed 200 already exists as C5
    "K1": [200, 300, 400, 500, 600, 700, 800],
    "G1": [200, 300, 400, 500, 600, 700, 800],
}

TREATMENT = {
    "T2": "seed_replica_repaired_transformer",
    "C4": "seed_replica_deterministic_lstm_baseline",
    "C3": "seed_replica_deterministic_transformer_baseline",
    "K1": "seed_replica_conv_embedding_transformer",
    "G1": "seed_replica_grace_storage_input",
}


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _write_replica(base: str, seed: int) -> Path:
    source = CONFIG_DIR / f"{base.lower()}.yml"
    target = CONFIG_DIR / f"{base.lower()}_s{seed}.yml"
    if target.exists():
        return target
    lines = []
    for line in source.read_text(encoding="utf-8").splitlines():
        if line.startswith("experiment_name:"):
            line = f"experiment_name: transformer_recipe_repair_{base}_s{seed}"
        elif line.startswith("run_dir:"):
            line = f"run_dir: results/33_transformer_recipe_repair/{base}_s{seed}"
        elif line.startswith("seed:"):
            line = f"seed: {seed}"
        lines.append(line)
    target.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    return target


def main() -> int:
    rows = list(csv.DictReader(REGISTRY.open(encoding="utf-8", newline="")))
    fields = list(rows[0].keys())
    existing = {row["experiment_id"] for row in rows}
    fixed = rows[0]["fixed_factors"]
    parent_nse = {row["experiment_id"]: row["validation_median_nse"] for row in rows}

    created, registered = [], []
    for base, seeds in PLAN.items():
        for seed in seeds:
            path = _write_replica(base, seed)
            arm = f"{base}_s{seed}"
            created.append(arm)
            if arm in existing:
                continue
            rows.append({
                "experiment_id": arm,
                "treatment": TREATMENT[base],
                "hypothesis": (f"Seed replica of {base}. One seed cannot separate the repaired Transformer from "
                               "the LSTM: batch 3 gave T2 - C4 = -0.001 on medians and -0.008 paired, against a "
                               "deterministic seed effect (C5 - C3) of 0.004 and 0.009 respectively."),
                "changed_factor": f"seed 100 -> {seed}, everything else identical to {base}, determinism enabled",
                "fixed_factors": fixed,
                "parent": base,
                "parent_median_nse": parent_nse.get(base, ""),
                "seed": str(seed),
                "config_path": f"src/transformer_recipe_repair/configs/{path.name}",
                "config_sha256": _sha256(path),
                "run_dir": f"results/33_transformer_recipe_repair/{arm}",
                "status": "planned",
                "validation_median_nse": "",
                "notes": "No sealed evaluation access. Seed-replication stage 1 (eight seeds per arm including "
                         "the existing seed 100; C3 seed 200 is the existing C5).",
            })
            registered.append(arm)

    with REGISTRY.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)

    print(f"configs present: {len(created)}  newly registered: {len(registered)}  registry rows: {len(rows)}")
    print(f"registry sha256: {_sha256(REGISTRY)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
