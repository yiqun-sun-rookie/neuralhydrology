"""Stage-1 go/no-go for ID34: do path-signature features explain what the best LSTM leaves behind?

The question the whole line depends on, asked as cheaply as possible: take the deterministic
long short-term memory baseline C4 (ID33), compute its residual on the LAST TWO TRAINING YEARS,
and ask whether a linear model on signature features of the 270-day forcing window can explain
any of that residual out of sample -- and, crucially, whether it explains MORE than a matched
hand-crafted control of identical dimension over identical dyadic windows.

Why training years and not the validation period: the validation period is the project's only
held-out development window and must not take part in feature screening. The last two training
years are data the model has already seen, so using them here adds no new leakage.

Why residual and not the target: any feature set will explain streamflow. The claim ID34 makes
is that signatures carry information the LSTM does not extract; the residual is that information.

Feature sets compared (all on the same rows):
    S0    hand-crafted control, 126 dims (42 per dyadic window x 3 windows)
    SIG2  depth-2 signature, 126 dims           -- same size as S0 by construction
    SIG3  depth-3 signature, 774 dims
    S0+SIG2, S0+SIG3                            -- does the signature add to the control?

Pre-registered gate (written before the job ran):
    KILL  if max(OOS R2[SIG2], OOS R2[SIG3]) on the residual < 0.02
    NOTE  the informative number is SIG minus S0, not SIG alone.

Reads: the run directory's config, scaler, and train/model_epoch030/train_results.p
(produced by ``nh_run evaluate --period train``). Writes: one JSON report. Touches nothing else.
"""

from __future__ import annotations

import argparse
import json
import pickle
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

REPO_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO_ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from signature_features import control_dim, control_features, signature_dim, signature_features  # noqa: E402


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--run-dir", type=Path, required=True, help="Baseline run directory (C4).")
    parser.add_argument("--epoch", type=int, default=30)
    parser.add_argument("--fit-start", default="2004-10-01")
    parser.add_argument("--fit-end", default="2005-09-30")
    parser.add_argument("--test-start", default="2005-10-01")
    parser.add_argument("--test-end", default="2006-09-30")
    parser.add_argument("--window", type=int, default=270)
    parser.add_argument("--dyadic-depth", type=int, default=2, help="1 = whole window only; 2 = plus halves.")
    parser.add_argument("--stride", type=int, default=1, help="Use every k-th day to bound runtime.")
    parser.add_argument("--kill-threshold", type=float, default=0.02)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def _load_predictions(run_dir: Path, epoch: int, target: str) -> dict:
    path = run_dir / f"train/model_epoch{epoch:03d}/train_results.p"
    if not path.is_file():
        raise FileNotFoundError(f"{path} missing: run `nh_run evaluate --period train --epoch {epoch}` first")
    with path.open("rb") as handle:
        payload = pickle.load(handle)
    out = {}
    for basin, freqs in payload.items():
        node = freqs[list(freqs)[0]]
        ds = node["xr"] if isinstance(node, dict) else node
        last = ds.isel(time_step=-1) if "time_step" in ds.dims else ds
        out[str(basin)] = pd.DataFrame({
            "obs": np.asarray(last[f"{target}_obs"]).squeeze(),
            "sim": np.asarray(last[f"{target}_sim"]).squeeze(),
        }, index=pd.to_datetime(np.asarray(last["date"])))
    return out


def _load_forcings(run_dir: Path):
    """Normalised dynamic inputs per basin for the training period, exactly as the model saw them."""
    from neuralhydrology.datasetzoo import get_dataset
    from neuralhydrology.datautils.utils import load_scaler
    from neuralhydrology.utils.config import Config

    cfg = Config(run_dir / "config.yml")
    scaler = load_scaler(run_dir)
    dataset = get_dataset(cfg, is_train=False, period="train", scaler=scaler)
    freq = dataset.frequencies[0]
    inputs = list(cfg.dynamic_inputs)
    forcings = {}
    for basin in dataset.basins:
        block = dataset._x_d[basin][freq]  # noqa: SLF001  read-only access to the loaded arrays
        # Each dynamic input is stored as (T, 1); squeeze the trailing feature axis before stacking.
        matrix = np.stack([np.asarray(block[name]).reshape(-1) for name in inputs], axis=1).astype(np.float32)
        forcings[basin] = pd.DataFrame(matrix, index=pd.to_datetime(np.asarray(dataset._dates[basin][freq])), columns=inputs)  # noqa: SLF001
    return forcings, inputs, cfg


def _ridge_fit_predict(xf: np.ndarray, yf: np.ndarray, xt: np.ndarray, alphas=(1e-2, 1e-1, 1.0, 10.0, 100.0)) -> tuple:
    """Standardise on the fit rows, choose alpha by 3-fold CV inside the fit rows, return test predictions."""
    mu, sd = xf.mean(axis=0), xf.std(axis=0) + 1e-8
    xf_s, xt_s = (xf - mu) / sd, (xt - mu) / sd
    ym = yf.mean()

    def solve(a_x, a_y, alpha):
        n, p = a_x.shape
        gram = a_x.T @ a_x + alpha * n * np.eye(p)
        return np.linalg.solve(gram, a_x.T @ (a_y - ym))

    folds = np.array_split(np.random.default_rng(0).permutation(len(yf)), 3)
    best_alpha, best_err = None, np.inf
    for alpha in alphas:
        err = 0.0
        for k in range(3):
            va = folds[k]
            tr = np.concatenate([folds[j] for j in range(3) if j != k])
            beta = solve(xf_s[tr], yf[tr], alpha)
            err += float(np.mean((xf_s[va] @ beta + ym - yf[va])**2))
        if err < best_err:
            best_err, best_alpha = err, alpha
    beta = solve(xf_s, yf, best_alpha)
    return xt_s @ beta + ym, best_alpha


def _r2(y: np.ndarray, yhat: np.ndarray) -> float:
    denominator = float(np.sum((y - y.mean())**2))
    return float(1.0 - np.sum((y - yhat)**2) / denominator) if denominator > 0 else float("nan")


def main() -> int:
    args = _parse_args()
    started = time.time()
    forcings, inputs, cfg = _load_forcings(args.run_dir)
    target = list(cfg.target_variables)[0]
    predictions = _load_predictions(args.run_dir, args.epoch, target)
    basins = sorted(set(forcings) & set(predictions))
    print(f"basins with forcings and predictions: {len(basins)}  inputs: {inputs}")

    fit_dates = pd.date_range(args.fit_start, args.fit_end, freq="D")[::args.stride]
    test_dates = pd.date_range(args.test_start, args.test_end, freq="D")[::args.stride]
    all_dates = fit_dates.append(test_dates)

    n_ch = len(inputs)
    dims = {"S0": control_dim(n_ch, args.dyadic_depth),
            "SIG2": signature_dim(n_ch, 2, args.dyadic_depth),
            "SIG3": signature_dim(n_ch, 3, args.dyadic_depth)}
    print("feature dims:", dims)

    rows_y, rows_obs, rows_split, rows_basin = [], [], [], []
    feats = {k: [] for k in dims}
    # One day at a time, vectorised across all basins: 531 windows per call keeps memory flat.
    for i, day in enumerate(all_dates):
        window_index = pd.date_range(end=day, periods=args.window, freq="D")
        block, ys, obs, keep = [], [], [], []
        for basin in basins:
            frame = forcings[basin]
            if window_index[0] < frame.index[0] or day not in predictions[basin].index:
                continue
            win = frame.reindex(window_index).to_numpy(dtype=np.float32)
            pred = predictions[basin].loc[day]
            if np.isnan(win).any() or not np.isfinite(pred["obs"]) or not np.isfinite(pred["sim"]):
                continue
            block.append(win)
            ys.append(pred["sim"] - pred["obs"])
            obs.append(pred["obs"])
            keep.append(basin)
        if not block:
            continue
        block = np.stack(block)
        feats["S0"].append(control_features(block, args.dyadic_depth))
        feats["SIG2"].append(signature_features(block, 2, args.dyadic_depth))
        feats["SIG3"].append(signature_features(block, 3, args.dyadic_depth))
        rows_y.extend(ys)
        rows_obs.extend(obs)
        rows_basin.extend(keep)
        rows_split.extend(["fit" if day <= pd.Timestamp(args.fit_end) else "test"] * len(keep))
        if i % 50 == 0:
            print(f"  day {i + 1}/{len(all_dates)} {day.date()} rows so far {len(rows_y)}  {time.time() - started:.0f}s")

    X = {k: np.concatenate(v, axis=0) for k, v in feats.items()}
    X["S0+SIG2"] = np.concatenate([X["S0"], X["SIG2"]], axis=1)
    X["S0+SIG3"] = np.concatenate([X["S0"], X["SIG3"]], axis=1)
    residual = np.asarray(rows_y, dtype=np.float64)
    observed = np.asarray(rows_obs, dtype=np.float64)
    basin_arr = np.asarray(rows_basin)
    split = np.asarray(rows_split)

    # Normalise residual and target per basin by the basin's fit-period observed std, so basins pool.
    scale = {}
    for basin in np.unique(basin_arr):
        mask = (basin_arr == basin) & (split == "fit")
        scale[basin] = float(observed[mask].std()) if mask.sum() > 2 else float("nan")
    s = np.array([scale[b] for b in basin_arr])
    ok = np.isfinite(s) & (s > 0)
    r_norm, o_norm = residual / np.where(ok, s, 1.0), observed / np.where(ok, s, 1.0)
    fit, test = (split == "fit") & ok, (split == "test") & ok
    print(f"rows fit={int(fit.sum())} test={int(test.sum())}  ({time.time() - started:.0f}s)")

    report = {"design": {k: getattr(args, k) for k in ("fit_start", "fit_end", "test_start", "test_end", "window",
                                                       "dyadic_depth", "stride", "kill_threshold")},
              "run_dir": str(args.run_dir), "n_basins": len(basins), "feature_dims": {k: int(v.shape[1]) for k, v in X.items()},
              "residual": {}, "target_reference": {}}
    for name, matrix in X.items():
        for label, y in (("residual", r_norm), ("target_reference", o_norm)):
            yhat, alpha = _ridge_fit_predict(matrix[fit], y[fit], matrix[test])
            pooled = _r2(y[test], yhat)
            per_basin = []
            for basin in np.unique(basin_arr[test]):
                m = basin_arr[test] == basin
                if m.sum() > 10:
                    per_basin.append(_r2(y[test][m], yhat[m]))
            report[label][name] = {"oos_r2_pooled": pooled, "oos_r2_basin_median": float(np.median(per_basin)),
                                   "alpha": alpha}
            print(f"{label:16s} {name:8s} OOS R2 pooled={pooled:+.4f}  basin-median={np.median(per_basin):+.4f}  alpha={alpha}")

    res = report["residual"]
    best_sig = max(res["SIG2"]["oos_r2_pooled"], res["SIG3"]["oos_r2_pooled"])
    report["gate"] = {
        "best_signature_oos_r2": best_sig,
        "control_oos_r2": res["S0"]["oos_r2_pooled"],
        "sig2_minus_control": res["SIG2"]["oos_r2_pooled"] - res["S0"]["oos_r2_pooled"],
        "sig3_minus_control": res["SIG3"]["oos_r2_pooled"] - res["S0"]["oos_r2_pooled"],
        "added_over_control_sig3": res["S0+SIG3"]["oos_r2_pooled"] - res["S0"]["oos_r2_pooled"],
        "verdict": "KILL" if best_sig < args.kill_threshold else "PROCEED",
    }
    print("GATE:", json.dumps(report["gate"], indent=1))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=1, sort_keys=True), encoding="utf-8")
    print(f"wrote {args.output}  total {time.time() - started:.0f}s")
    return 0


if __name__ == "__main__":
    sys.exit(main())
