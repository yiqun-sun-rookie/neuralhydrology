"""Truncated path signatures and a matched hand-crafted control, for batches of fixed-length windows.

No third-party signature library: ``signatory`` is unmaintained and pins an old torch, and for
depth <= 3 the signature of a piecewise-linear path is a short exact recursion (Chen's identity)
that vectorises over a batch in numpy.

Conventions follow the canonical pipeline of Morrill, Fermanian, Kidger & Lyons (2020,
arXiv:2006.00873): time augmentation (append a normalised time channel), basepoint augmentation
(prepend a zero row so the signature sees absolute level, not just shape), signature rather than
log-signature, and hierarchical dyadic windows (the full window plus its halves).

For one linear step with increment ``h`` appended to a path with signature terms (S1, S2, S3):

    S1' = S1 + h
    S2' = S2 + S1 (x) h + h (x) h / 2
    S3' = S3 + S2 (x) h + S1 (x) h (x) h / 2 + h (x) h (x) h / 6

which is exact because the signature of a straight segment is exp(h) in the tensor algebra.
"""

from __future__ import annotations

import numpy as np

__all__ = ["signature_features", "control_features", "signature_dim", "control_dim", "dyadic_slices"]


def dyadic_slices(length: int, depth: int) -> list:
    """Return (start, stop) pairs for the dyadic window hierarchy: level 0 is the whole window."""
    slices = []
    for level in range(depth):
        parts = 2**level
        edges = np.linspace(0, length, parts + 1).astype(int)
        slices.extend((int(edges[k]), int(edges[k + 1])) for k in range(parts))
    return slices


def _augment(window: np.ndarray) -> np.ndarray:
    """Append a normalised time channel and prepend a zero basepoint row. (B, L, d) -> (B, L+1, d+1)."""
    batch, length, _ = window.shape
    time = np.linspace(0.0, 1.0, length, dtype=window.dtype)
    time = np.broadcast_to(time[None, :, None], (batch, length, 1))
    augmented = np.concatenate([window, time], axis=2)
    basepoint = np.zeros((batch, 1, augmented.shape[2]), dtype=window.dtype)
    return np.concatenate([basepoint, augmented], axis=1)


def _signature(path: np.ndarray, depth: int) -> np.ndarray:
    """Depth-``depth`` signature (flattened, without the constant 1) of piecewise-linear paths (B, L, d)."""
    increments = np.diff(path, axis=1).astype(np.float64)
    batch, steps, dim = increments.shape
    s1 = np.zeros((batch, dim))
    s2 = np.zeros((batch, dim, dim)) if depth >= 2 else None
    s3 = np.zeros((batch, dim, dim, dim)) if depth >= 3 else None
    for step in range(steps):
        h = increments[:, step, :]
        hh = np.einsum("bi,bj->bij", h, h)
        if depth >= 3:
            s3 += (np.einsum("bij,bk->bijk", s2, h) + 0.5 * np.einsum("bi,bjk->bijk", s1, hh) +
                   np.einsum("bij,bk->bijk", hh, h) / 6.0)
        if depth >= 2:
            s2 += np.einsum("bi,bj->bij", s1, h) + 0.5 * hh
        s1 += h
    parts = [s1.reshape(batch, -1)]
    if depth >= 2:
        parts.append(s2.reshape(batch, -1))
    if depth >= 3:
        parts.append(s3.reshape(batch, -1))
    return np.concatenate(parts, axis=1).astype(np.float32)


def signature_dim(n_channels: int, depth: int, dyadic_depth: int) -> int:
    d = n_channels + 1  # time channel
    per_window = sum(d**k for k in range(1, depth + 1))
    return per_window * (2**dyadic_depth - 1)


def signature_features(window: np.ndarray, depth: int, dyadic_depth: int) -> np.ndarray:
    """Signature features of (B, L, d) windows over dyadic sub-windows. Returns (B, signature_dim)."""
    blocks = []
    for start, stop in dyadic_slices(window.shape[1], dyadic_depth):
        blocks.append(_signature(_augment(window[:, start:stop, :]), depth))
    return np.concatenate(blocks, axis=1)


def control_dim(n_channels: int, dyadic_depth: int) -> int:
    return (8 * n_channels + 2) * (2**dyadic_depth - 1)


def control_features(window: np.ndarray, dyadic_depth: int, precip_channel: int = 0) -> np.ndarray:
    """Hand-crafted per-window statistics with the SAME dyadic windows and, for 5 channels, the same 42
    dimensions per window as a depth-2 signature. This is the arm a signature has to beat: if the
    signature only matches this, the gain was 'more summary statistics', not path geometry.

    Per channel (8): mean, std, min, max, first, last, total variation, mean of positive increments.
    Extra (2): normalised position of the precipitation maximum; lag-1 autocorrelation of precipitation.
    """
    blocks = []
    for start, stop in dyadic_slices(window.shape[1], dyadic_depth):
        sub = window[:, start:stop, :].astype(np.float64)
        inc = np.diff(sub, axis=1)
        per_channel = np.stack([
            sub.mean(axis=1),
            sub.std(axis=1),
            sub.min(axis=1),
            sub.max(axis=1),
            sub[:, 0, :],
            sub[:, -1, :],
            np.abs(inc).sum(axis=1),
            np.clip(inc, 0, None).mean(axis=1),
        ], axis=2).reshape(sub.shape[0], -1)
        precip = sub[:, :, precip_channel]
        position = precip.argmax(axis=1) / max(sub.shape[1] - 1, 1)
        centred = precip - precip.mean(axis=1, keepdims=True)
        denominator = (centred**2).sum(axis=1)
        lag1 = np.where(denominator > 0, (centred[:, 1:] * centred[:, :-1]).sum(axis=1) / np.maximum(denominator, 1e-12), 0.0)
        blocks.append(np.concatenate([per_channel, position[:, None], lag1[:, None]], axis=1))
    return np.concatenate(blocks, axis=1).astype(np.float32)


if __name__ == "__main__":
    # Self-check: Chen's identity on a random path, plus a hand-computable case.
    rng = np.random.default_rng(0)
    path = rng.normal(size=(2, 9, 3))
    whole = _signature(path, 3)
    # Signature of a single straight segment h is (h, h⊗h/2, h⊗h⊗h/6): check depth-2 term exactly.
    seg = np.array([[[0.0, 0.0], [1.0, 2.0]]])
    s = _signature(seg, 2)
    assert np.allclose(s[0, :2], [1.0, 2.0]) and np.allclose(s[0, 2:].reshape(2, 2), np.outer([1, 2], [1, 2]) / 2)
    # Shape contract.
    win = rng.normal(size=(4, 270, 5)).astype(np.float32)
    assert signature_features(win, 2, 2).shape == (4, signature_dim(5, 2, 2))
    assert signature_features(win, 3, 2).shape == (4, signature_dim(5, 3, 2))
    assert control_features(win, 2).shape == (4, control_dim(5, 2))
    assert signature_dim(5, 2, 2) == control_dim(5, 2) == 126
    print("signature_features self-check OK:", signature_dim(5, 2, 2), signature_dim(5, 3, 2), control_dim(5, 2))
