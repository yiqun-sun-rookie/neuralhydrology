"""Static one-factor audit for the ID33 inductive-bias ablation.

Every arm must differ from its own baseline in exactly one declared way. The Transformer arms
are compared against the ID30 D01 dense control and the long short-term memory arm against the
ID30 B01 control, so a single accidental edit to width, depth, dates, basins, optimizer or
learning rate is caught before any machine time is spent.

Reads only; writes nothing.
"""

from __future__ import annotations

import hashlib
import re
import sys
from pathlib import Path
from typing import Any, Dict, List

from ruamel.yaml import YAML

REPO_ROOT = Path(__file__).resolve().parents[3]
IDEA_DIR = REPO_ROOT / "src/transformer_recipe_repair"
CONFIG_DIR = IDEA_DIR / "configs"
REGISTRY = IDEA_DIR / "registry/experiments.csv"

TRANSFORMER_BASELINE = REPO_ROOT / "src/modern_transformer_moe/configs/dense_d128_l4_s100.yml"
LSTM_BASELINE_NAME = "B01"

# arm -> (config file, baseline kind, keys this arm is allowed to change)
ARMS: Dict[str, tuple] = {
    # arm -> (config file, parent arm or baseline kind, keys this arm may change vs its parent)
    "T1": ("t1.yml", "transformer", {"optimizer", "batch_size", "learning_rate"}),
    "T2": ("t2.yml", "T1", {"transformer_init_scheme"}),
    "T3": ("t3.yml", "T2", {"statics_embedding", "dynamics_embedding"}),
    "T4": ("t4.yml", "T2", {"predict_last_n"}),
    "T5": ("t5.yml", "T2", {"recency_ema_decays", "recency_ema_inputs", "recency_decay_attention"}),
    "L33": ("l33.yml", "lstm", {"predict_last_n"}),
    # Calibration arms. C1 is the ID30 D01 config verbatim, re-run on a different card type,
    # so its delta against 0.671034 measures the card-swap cost alone. C2 changes only the
    # seed on that same card, so C2 minus C1 measures the Transformer family's seed noise,
    # which has never been measured in this project.
    "C1": ("c1.yml", "transformer", set()),
    "C2": ("c2.yml", "C1", {"seed"}),
    # C3 and C4 exist because batches 1 and 2 were run without any determinism setting, so the
    # same config and the same seed do not reproduce: probe 223972 ran three identical replicas
    # concurrently on one card and got three different weight digests, while probe 223971 with
    # use_deterministic_algorithms + cudnn.deterministic + TF32 off + CUBLAS_WORKSPACE_CONFIG
    # got one digest across all three. The ID30 baselines D01 and B01 were produced under the
    # same non-deterministic recipe, so comparing a deterministic arm against them would compare
    # a fixed number against a draw. C3 and C4 re-run those two configs verbatim inside the ID33
    # landing zone under determinism; the ID30 deployment stays read-only.
    "C3": ("c3.yml", "transformer", set()),
    "C4": ("c4.yml", "lstm", set()),
    # C5 minus C3 is the first honest seed-noise measurement in this project. The old C2 minus C1
    # figure of +0.003555 mixed the seed change with run-to-run kernel nondeterminism, so it
    # cannot size a seed-replication plan; C5 and C3 differ in the seed and nothing else, under
    # determinism, so their difference is the seed effect alone.
    "C5": ("c5.yml", "C3", {"seed"}),
}

# Always allowed to differ: identity and the model dispatch name.
IDENTITY_KEYS = {"experiment_name", "run_dir", "model"}

MODEL_BY_ARM = {
    "T1": "modern_transformer",
    "T2": "recipe_fixed_transformer",
    "T3": "recipe_fixed_transformer",
    "T4": "recipe_fixed_transformer",
    "T5": "recipe_fixed_transformer",
    "L33": "cudalstm",
    "C1": "modern_transformer",
    "C2": "modern_transformer",
    "C3": "modern_transformer",
    "C4": "cudalstm",
    "C5": "modern_transformer",
}

# Seed replicas. A config named <base>_s<seed>.yml (e.g. t2_s300.yml) is audited as the base
# arm with only the seed allowed to differ, and the seed must equal the number in the name.
# They are discovered from the configs directory rather than listed here so that a seed-
# replication plan is one generator run, not thirty hand-written entries. Every replica still
# needs a registry row with its own config hash; the registry audit below enforces that.
SEED_REPLICA = re.compile(r"^(?P<base>[a-z][a-z0-9]*)_s(?P<seed>[0-9]+)\.yml$")


def _discover_seed_replicas() -> Dict[str, tuple]:
    found: Dict[str, tuple] = {}
    for path in sorted(CONFIG_DIR.glob("*_s[0-9]*.yml")):
        match = SEED_REPLICA.match(path.name)
        if not match:
            continue
        base = match.group("base").upper()
        if base not in ARMS:
            continue
        found[f"{base}_s{match.group('seed')}"] = (path.name, base, {"seed"})
    return found


ARMS.update(_discover_seed_replicas())


def expected_seed_for(arm: str) -> int:
    """Seed an arm is pinned to: 200 for the two legacy seed-contrast arms, the number in the
    name for a seed replica, and the frozen 100 for everything else."""
    if arm in {"C2", "C5"}:
        return 200
    match = re.match(r"^[A-Z0-9]+_s(?P<seed>[0-9]+)$", arm)
    return int(match.group("seed")) if match else 100


def model_for(arm: str) -> str:
    base = arm.split("_s")[0] if "_s" in arm else arm
    return MODEL_BY_ARM[base]


FORBIDDEN_INPUT_TOKENS = ("usgs_streamflow", "camels_hydro", "_obs_eval")
SEALED_YEARS = tuple(str(year) for year in range(1989, 1999))

REQUIRED_CONTRACT = {
    "number_of_basins": 531,
    "train_start_date": "01/10/1999",
    "train_end_date": "30/09/2006",
    "validation_start_date": "01/10/2006",
    "validation_end_date": "30/09/2008",
    "seq_length": 270,
    "epochs": 30,
    "loss": "NSE",
}

ALLOWED_DYNAMIC_INPUTS = ["PRCP(mm/day)", "Tmin(C)", "Tmax(C)", "SRAD(W/m2)", "Vp(Pa)"]


def load_yaml(path: Path) -> Dict[str, Any]:
    with path.open(encoding="utf-8") as stream:
        return YAML(typ="safe").load(stream)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _lstm_baseline() -> Dict[str, Any] | None:
    """Return the ID30 B01 config when the ID30 workspace carries it, else ``None``."""
    candidate = REPO_ROOT / "src/modern_transformer_moe/configs/baseline_lstm_s100.yml"
    return load_yaml(candidate) if candidate.is_file() else None


def _compare(arm: str, config: Dict[str, Any], baseline: Dict[str, Any], allowed: set) -> List[str]:
    issues: List[str] = []
    permitted = IDENTITY_KEYS | allowed
    for key in sorted(set(config) | set(baseline)):
        if key in permitted:
            continue
        if config.get(key) != baseline.get(key):
            issues.append(f"{arm}: unintended difference in '{key}': "
                          f"baseline={baseline.get(key)!r} arm={config.get(key)!r}")
    for key in sorted(allowed):
        if key == "output_dropout":
            continue
        if key not in config:
            issues.append(f"{arm}: declared changed factor '{key}' is absent from the config")
    return issues


def _audit_contract(arm: str, config: Dict[str, Any]) -> List[str]:
    issues: List[str] = []
    for key, expected in REQUIRED_CONTRACT.items():
        if config.get(key) != expected:
            issues.append(f"{arm}: frozen contract field '{key}' is {config.get(key)!r}, expected {expected!r}")
    if list(config.get("dynamic_inputs", [])) != ALLOWED_DYNAMIC_INPUTS:
        issues.append(f"{arm}: dynamic_inputs deviates from the allowed five Maurer forcings")
    expected_seed = expected_seed_for(arm)
    if config.get("seed") != expected_seed:
        issues.append(f"{arm}: seed is {config.get('seed')!r}, expected {expected_seed}")
    if config.get("model") != model_for(arm):
        issues.append(f"{arm}: model is {config.get('model')!r}, expected {model_for(arm)!r}")
    text = (CONFIG_DIR / ARMS[arm][0]).read_text(encoding="utf-8")
    for token in FORBIDDEN_INPUT_TOKENS:
        if token in text:
            issues.append(f"{arm}: forbidden input token '{token}' appears in the config")
    for year in SEALED_YEARS:
        if f"/{year}" in text:
            issues.append(f"{arm}: sealed evaluation year {year} appears in the config")
    if not str(config.get("run_dir", "")).startswith("results/33_transformer_recipe_repair/"):
        issues.append(f"{arm}: run_dir must stay under results/33_transformer_recipe_repair/")
    return issues


def _audit_registry() -> List[str]:
    if not REGISTRY.is_file():
        return [f"registry missing: {REGISTRY}"]
    issues: List[str] = []
    import csv
    rows = {row["experiment_id"]: row for row in csv.DictReader(REGISTRY.open(encoding="utf-8"))}
    for arm, (filename, _kind, _allowed) in ARMS.items():
        if arm not in rows:
            issues.append(f"registry: arm {arm} is not registered")
            continue
        recorded = rows[arm].get("config_sha256", "")
        actual = sha256_file(CONFIG_DIR / filename)
        if recorded != actual:
            issues.append(f"registry: {arm} config_sha256 is {recorded[:16]}..., file hashes {actual[:16]}...")
    return issues


def audit_repository(repo_root: Path = REPO_ROOT) -> List[str]:
    """Each arm must differ from its PARENT arm in exactly the declared keys.

    T1 is compared to the ID30 D01 dense control; T2 to T1; T3, T4 and T5 to T2; and L33 to
    the ID30 B01 long short-term memory control. A chain, not a star, so that every step is a
    one-factor move and T3, T4 and T5 are directly comparable to one another.
    """
    issues: List[str] = []
    loaded: Dict[str, Dict[str, Any]] = {}
    for arm, (filename, _kind, _allowed) in ARMS.items():
        path = CONFIG_DIR / filename
        if path.is_file():
            loaded[arm] = load_yaml(path)
        else:
            issues.append(f"{arm}: config missing at {path}")

    for arm, (filename, parent, allowed) in ARMS.items():
        if arm not in loaded:
            continue
        config = loaded[arm]
        issues.extend(_audit_contract(arm, config))
        if parent == "transformer":
            baseline, label = load_yaml(TRANSFORMER_BASELINE), "ID30 D01"
        elif parent == "lstm":
            baseline, label = _lstm_baseline(), "ID30 B01"
            if baseline is None:
                issues.append(f"{arm}: the {label} baseline config is not present locally; comparison skipped")
                continue
        else:
            if parent not in loaded:
                issues.append(f"{arm}: parent arm {parent} could not be loaded")
                continue
            baseline, label = loaded[parent], parent
        issues.extend(_compare(f"{arm} vs {label}", config, baseline, allowed))

    issues.extend(_audit_registry())
    return issues


def main() -> int:
    issues = audit_repository()
    if issues:
        print("ID33 CONFIG AUDIT: FAIL")
        for issue in issues:
            print(f"  - {issue}")
        return 1
    print(f"ID33 CONFIG AUDIT: PASS ({len(ARMS)} arms; one factor each; no data read; no training launched)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
