"""Build the GRACE terrestrial-water-storage input feature for ID35, as a neuralhydrology additional-feature pickle.

What the feature is
-------------------
One column, ``grace_twsa_mm``: the CSR RL06.3 mascon liquid-water-equivalent anomaly (cm -> mm)
sampled at the 0.25-degree cell containing each basin's gauge, expanded from monthly to daily.

Three decisions, each a deliberate simplification and each stated in the idea file:

1. Monthly -> daily by SAME-MONTH assignment: every day of a calendar month carries that month's
   value. That gives each day access to the month-average, i.e. an upper bound on the information
   the product can carry. Operationally GRACE arrives ~2 months late; the lagged variant is only
   worth running if this upper-bound version shows any gain.
2. Before the first GRACE month (2002-04) the anomaly is set to 0.0, the product's own reference
   level. A NaN would silently delete every training window that touches the gap, which would
   change the training set and confound the comparison against C4.
3. Missing months inside the record (2002-06, 2002-07, 2003-06 in the development window) are
   filled by linear interpolation between neighbouring months.

Spatial caveat, stated up front: 531 basins (median 310 km^2) fall in 87 cells at GRACE's true
~3-degree resolution, so on average six basins receive the same monthly number. The feature is a
regional slow state, not a basin state. That is exactly what the arm tests.

Output index runs 1998-01-01 .. 2009-12-31, which covers the 270-day warm-up before the training
start (1999-10-01) through the validation end (2008-09-30) with margin.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import pickle
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import xarray as xr

REPO_ROOT = Path(__file__).resolve().parents[3]


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--grace-nc", type=Path,
                        default=REPO_ROOT / "data/grace_csr/CSR_GRACE_GRACE-FO_RL0603_Mascons_all-corrections.nc")
    parser.add_argument("--topo", type=Path, default=REPO_ROOT / "data/camels_us/camels_attributes_v2.0/camels_topo.txt")
    parser.add_argument("--basin-file", type=Path,
                        default=REPO_ROOT / "src/fair_benchmark/frozen/track0_forcing_only_basins.txt")
    parser.add_argument("--start", default="1998-01-01")
    parser.add_argument("--end", default="2009-12-31")
    parser.add_argument("--output", type=Path,
                        default=REPO_ROOT / "src/grace_input_runoff/features/grace_twsa_daily_v01.p")
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    basins = pd.read_csv(args.basin_file, header=None, dtype=str)[0].str.zfill(8).tolist()
    topo = pd.read_csv(args.topo, sep=";", dtype={"gauge_id": str}).set_index("gauge_id")
    missing = [b for b in basins if b not in topo.index]
    if missing:
        raise SystemExit(f"basins without coordinates: {missing}")

    ds = xr.open_dataset(args.grace_nc)
    lwe = ds["lwe_thickness"]
    months = pd.Timestamp("2002-01-01") + pd.to_timedelta(ds["time"].values, unit="D")
    month_index = pd.DatetimeIndex(months).to_period("M")

    # The index MUST be named "date": neuralhydrology concatenates this frame onto the forcing frame and
    # pandas drops the index name when the two names differ, after which xr["date"] raises KeyError.
    daily_index = pd.date_range(args.start, args.end, freq="D", name="date")
    full_months = pd.period_range(daily_index[0].to_period("M"), daily_index[-1].to_period("M"), freq="M")
    first_grace_month = month_index.min()

    feature = {}
    cells_used = set()
    for basin in basins:
        lat = float(topo.loc[basin, "gauge_lat"])
        lon = float(topo.loc[basin, "gauge_lon"]) % 360.0
        cell = lwe.sel(lat=lat, lon=lon, method="nearest")
        cells_used.add((float(cell["lat"]), float(cell["lon"])))
        monthly = pd.Series(np.asarray(cell.values, dtype=np.float64) * 10.0, index=month_index)  # cm -> mm
        monthly = monthly.groupby(level=0).mean()  # a few months carry two solutions
        series = monthly.reindex(full_months)
        inside = series.index >= first_grace_month
        series[inside] = series[inside].interpolate(limit_direction="both")
        series[~inside] = 0.0
        daily = series.reindex(daily_index.to_period("M")).to_numpy(dtype=np.float32)
        feature[basin] = pd.DataFrame({"grace_twsa_mm": daily}, index=daily_index)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("wb") as handle:
        pickle.dump(feature, handle, protocol=4)

    sample = next(iter(feature.values()))
    stack = np.stack([f["grace_twsa_mm"].to_numpy() for f in feature.values()])
    summary = {
        "n_basins": len(feature),
        "index": [str(daily_index[0].date()), str(daily_index[-1].date())],
        "distinct_grace_cells_at_0p25deg": len(cells_used),
        "first_grace_month": str(first_grace_month),
        "zero_filled_days_per_basin": int((sample.index < pd.Timestamp("2002-04-01")).sum()),
        "nan_count": int(np.isnan(stack).sum()),
        "value_mm_p05_p50_p95": [float(v) for v in np.nanpercentile(stack[:, sample.index >= "2002-04-01"], [5, 50, 95])],
        "sha256": hashlib.sha256(args.output.read_bytes()).hexdigest(),
        "bytes": args.output.stat().st_size,
    }
    (args.output.with_suffix(".json")).write_text(json.dumps(summary, indent=1), encoding="utf-8")
    print(json.dumps(summary, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
