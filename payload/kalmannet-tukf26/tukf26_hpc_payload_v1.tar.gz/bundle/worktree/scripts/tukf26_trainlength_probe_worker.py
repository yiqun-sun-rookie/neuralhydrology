# -*- coding: utf-8 -*-
"""TUKF26 dev-probe worker: does more training data fix joint overfitting?

FORWARD split (train early, test late) on the TUKF25 fresh 27 basins, two
training-length variants sharing one geometry:

    y6  train origins [180, 2528]   (2349 origins, 6.4 years)
    y2  train origins [1798, 2528]  ( 731 origins, 2 years, control)

Recipe is the frozen TUKF23/24 one verbatim via c23.prepare_basin (noise
statistic window [0,1462) untouched and fully inside warmup+train; anchor
gate unchanged). Dev grade: no seal ceremony (the basins' window was opened
by TUKF25); records stamp grade=development_probe and are never citable.

    anchor       --stage anchor --basin B --config CFG --out-root R
    anchor_gate  --stage anchor_gate --config CFG --out-root R
    train        --stage train --basin B --mode M --variant y2|y6 --config CFG --out-root R
                 (mode all_frozen ignores --variant, stored as variant 'base')
    readout      --stage readout --basin B --mode M --variant V --config CFG --out-root R
    --updates-override N   dev timing probe only (record not written to train/)
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import tukf24_lead_extension_common as c24  # noqa: E402

c23 = c24.c23
t17 = c24.t17

torch.set_num_threads(1)

EXPERIMENT_ID = "TUKF26_TRAINLENGTH_FORWARD_PROBE_DEV_V1"
LEADS = c24.LEADS_EXTENDED
DEFAULT_CONFIG = c23.WORKTREE / "configs/tukf26_trainlength_probe_v1.json"

ARM_ORDER = (("all_frozen", "base"), ("filter_only", "y2"), ("joint", "y2"),
             ("filter_only", "y6"), ("joint", "y6"))


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_snapshot_sha(lists: dict) -> str:
    return sha256_bytes(json.dumps(lists, sort_keys=True,
                                   separators=(",", ":")).encode())


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=1), encoding="utf-8", newline="\n")


def peak_rss_mb() -> float | None:
    try:  # linux
        for line in open("/proc/self/status", encoding="ascii"):
            if line.startswith("VmHWM"):
                return float(line.split()[1]) / 1024.0
    except OSError:
        pass
    try:  # windows fallback
        import psutil
        return psutil.Process().memory_info().peak_wset / 1e6
    except Exception:
        return None


def load_all(config_path: Path | str) -> tuple[dict, dict]:
    config = json.loads(Path(config_path).read_text(encoding="utf-8"))
    if config["experiment_id"] != EXPERIMENT_ID:
        raise ValueError("wrong experiment id")
    for key, entry in config["frozen_input_sha256"].items():
        file_path = c23.ROOTS[entry["root"]] / entry["rel"]
        if c23.sha256_file(file_path) != entry["sha256"]:
            raise ValueError(f"frozen input drifted: {key}")
    c24.load_config(c23.WORKTREE / config["predecessor"]["tukf24_config"],
                    verify_hashes=True)
    contract23 = c23.load_contract(
        c23.WORKTREE / config["predecessor"]["tukf23_config"], verify_hashes=True)
    return config, contract23


def train_origins_of(config: dict, variant: str) -> tuple[int, ...]:
    lo, hi = config["segments_day_index"]["train_variants"][variant]
    return tuple(range(int(lo), int(hi) + 1))


def fixed_origins(config: dict, name: str) -> tuple[int, ...]:
    lo, hi = config["segments_day_index"][f"{name}_origins"]
    return tuple(range(int(lo), int(hi) + 1))


def selection_score(config: dict, model, prep: dict) -> float:
    sel = fixed_origins(config, "selection")
    hi = max(sel) + max(LEADS) + 1
    first_test = int(config["segments_day_index"]["test_origins"][0])
    if hi > first_test:  # forward guard: selection must not read a test day
        raise ValueError("selection scoring would read a test day")
    with torch.no_grad():
        loss, _ = c24.extended_rolling_objective(
            model, prep["forcing"][:hi], prep["obs"][:hi], prep["x0"],
            prep["noise"]["initial_covariance"], sel, leads=LEADS,
            base_observation_variance=prep["noise"]["base_observation_variance"])
    return float(loss)


def require_anchor_gate(config: dict, out_root: Path, basin_id: str) -> None:
    path = out_root / "anchor_gate_verdict.json"
    if not path.exists():
        raise RuntimeError("train refused: anchor_gate_verdict.json missing")
    verdict = json.loads(path.read_text(encoding="utf-8"))
    if verdict.get("experiment_id") != config["experiment_id"] or not verdict.get("pass"):
        raise RuntimeError("train refused: anchor gate did not pass")
    if basin_id not in verdict.get("passed_basins", []):
        raise RuntimeError(f"train refused: {basin_id} not in the passed anchor list")


def stage_anchor(config: dict, contract23: dict, basin_id: str, out_root: Path) -> dict:
    t0 = time.perf_counter()
    prep = c23.prepare_basin(contract23, basin_id)
    record = {
        "stage": "anchor", "experiment_id": config["experiment_id"],
        "basin_id": basin_id, "dim_x": prep["dim_x"],
        "anchor_delta": prep["anchor_delta"],
        "published_nse": prep["published_nse"],
        "tolerance": float(contract23["anchor_gate"]["tolerance"]),
        "passed": True, "environment": c23.environment_stamp(),
        "seconds": time.perf_counter() - t0,
        "ran_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    write_json(out_root / "anchor" / f"{basin_id}.json", record)
    return record


def stage_anchor_gate(config: dict, contract23: dict, out_root: Path) -> dict:
    basins = list(config["basins"]["basin_ids"])
    tol = float(contract23["anchor_gate"]["tolerance"])
    passed, deltas, missing = [], {}, []
    for basin in basins:
        path = out_root / "anchor" / f"{basin}.json"
        if not path.exists():
            missing.append(basin)
            continue
        rec = json.loads(path.read_text(encoding="utf-8"))
        deltas[basin] = rec["anchor_delta"]
        if rec.get("passed") and rec["anchor_delta"] <= tol:
            passed.append(basin)
    verdict = {
        "experiment_id": config["experiment_id"], "stage": "anchor_gate",
        "required": len(basins), "passed_count": len(passed),
        "passed_basins": passed, "missing": missing, "anchor_deltas": deltas,
        "tolerance": tol,
        "pass": len(passed) == len(basins) == 27 and not missing,
        "ran_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    write_json(out_root / "anchor_gate_verdict.json", verdict)
    return verdict


def stage_train(config: dict, contract23: dict, basin_id: str, mode: str,
                variant: str, out_root: Path,
                updates_override: int | None = None) -> dict:
    t0 = time.perf_counter()
    if mode == "all_frozen":
        variant = "base"
    cell = f"{basin_id}_{mode}_{variant}"
    out = out_root / "train" / f"{cell}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists() and updates_override is None:
        return json.loads(out.read_text(encoding="utf-8"))
    require_anchor_gate(config, out_root, basin_id)

    prep = c23.prepare_basin(contract23, basin_id)
    model = c23.build_mode_model(contract23, prep)
    hyd, fil = c23.mode_groups(contract23, model, mode)
    mask = contract23["modes"]["masks"][mode]

    seg = config["segments_day_index"]
    if mode == "all_frozen":
        train_origins: tuple[int, ...] = ()
        warmup_end = int(seg["warmup"][1]) + 1
    else:
        train_origins = train_origins_of(config, variant)
        warmup_end = train_origins[0]
        train_hi = max(train_origins) + max(LEADS) + 1
        if train_hi > int(seg["selection_origins"][0]):
            raise ValueError("train targets would cross into the selection segment")
        if warmup_end < int(seg["warmup"][1]) + 1:
            raise ValueError("train slice would start inside the warmup segment")
    forcing, obs = prep["forcing"], prep["obs"]
    cov0 = prep["noise"]["initial_covariance"]
    base_var = prep["noise"]["base_observation_variance"]
    spec = contract23["optimizer"]

    trainable = []
    if mask["hydrology"]:
        trainable.append({"params": hyd, "lr": float(spec["hydrology_learning_rate"])})
    if mask["filter"]:
        trainable.append({"params": fil, "lr": float(spec["filter_learning_rate"])})

    step = int(spec["selection_interval"])
    total = int(spec["updates"]) if updates_override is None else updates_override
    queries = tuple(range(0, total + 1, step))
    query_trace: list[list[float]] = []
    train_trace: list[float] = []
    timing: dict = {}

    if not trainable:
        best = {"score": None, "update": 0, "snap": c23.snapshot(model)}
    else:
        optimizer = torch.optim.Adam(trainable)
        clip = float(spec["group_gradient_norm"])
        train_hi = max(train_origins) + max(LEADS) + 1
        train_forcing = torch.as_tensor(forcing[warmup_end:train_hi])
        train_obs = torch.as_tensor(obs[warmup_end:train_hi])
        shifted = tuple(o - warmup_end for o in train_origins)

        def warm_start():
            with torch.no_grad():
                tr = t17.rollout_state_update_trace(
                    model, forcing[:warmup_end], obs[:warmup_end], prep["x0"], cov0,
                    base_observation_variance=base_var)
                return (tr["posterior_state"][-1].detach().clone(),
                        tr["posterior_covariance"][-1].detach().clone())

        tq = time.perf_counter()
        score0 = selection_score(config, model, prep)
        timing["selection_query_s"] = time.perf_counter() - tq
        query_trace.append([0, score0])
        best = {"score": score0, "update": 0, "snap": c23.snapshot(model)}

        for update in range(1, total + 1):
            tu = time.perf_counter()
            optimizer.zero_grad(set_to_none=True)
            warm_state, warm_cov = warm_start()
            loss, _ = c24.extended_rolling_objective(
                model, train_forcing, train_obs, warm_state, warm_cov,
                shifted, leads=LEADS, base_observation_variance=base_var)
            loss.backward()
            if mask["hydrology"]:
                torch.nn.utils.clip_grad_norm_(hyd, clip)
            if mask["filter"]:
                torch.nn.utils.clip_grad_norm_(fil, clip)
            optimizer.step()
            projector = getattr(model, "project_trainable_coordinates_", None)
            if callable(projector):
                projector()
            train_trace.append(float(loss))
            timing["update_s"] = time.perf_counter() - tu
            if update in queries:
                score = selection_score(config, model, prep)
                query_trace.append([update, score])
                if score < best["score"]:
                    best = {"score": score, "update": update,
                            "snap": c23.snapshot(model)}

    c23.restore_(model, best["snap"])
    snap_lists = c23.snapshot_to_lists(best["snap"])
    tail = train_trace[-16:] if len(train_trace) >= 32 else []
    tail_drop = ((tail[0] - tail[-1]) / abs(tail[0])) if tail and tail[0] else None
    record = {
        "stage": "train", "experiment_id": config["experiment_id"],
        "grade": "development_probe", "basin_id": basin_id, "mode": mode,
        "variant": variant, "leads_days": list(LEADS),
        "train_origin_count": len(train_origins),
        "segments_day_index": seg, "dim_x": prep["dim_x"],
        "anchor_delta": prep["anchor_delta"],
        "base_observation_variance": base_var,
        "selected_update": best["update"],
        "selection_score_at_checkpoint": best["score"],
        "selection_query_trace": query_trace,
        "train_loss_trace": train_trace,
        "budget_tail16_relative_drop": tail_drop,
        "checkpoint_snapshot": snap_lists,
        "checkpoint_sha256": canonical_snapshot_sha(snap_lists),
        "learned_observation_ratio": float(model.observation_ratio()),
        "learned_process_diagonal": [float(v) for v in
                                     model.process_diagonal().reshape(-1)],
        "peak_rss_mb": peak_rss_mb(),
        "timing_probe": timing, "updates_override": updates_override,
        "environment": c23.environment_stamp(),
        "seconds": time.perf_counter() - t0,
        "ran_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    if updates_override is None:
        write_json(out, record)
    return record


def stage_readout(config: dict, contract23: dict, basin_id: str, mode: str,
                  variant: str, out_root: Path, train_root: Path) -> dict:
    t0 = time.perf_counter()
    if mode == "all_frozen":
        variant = "base"
    cell = f"{basin_id}_{mode}_{variant}"
    out_dir = out_root / "readout"
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = out_dir / f"{cell}.json"
    npz_path = out_dir / f"{cell}.npz"
    if json_path.exists() and npz_path.exists():
        return json.loads(json_path.read_text(encoding="utf-8"))

    train_record = json.loads(
        (train_root / "train" / f"{cell}.json").read_text(encoding="utf-8"))
    snap_lists = train_record["checkpoint_snapshot"]
    if canonical_snapshot_sha(snap_lists) != train_record["checkpoint_sha256"]:
        raise ValueError(f"{cell}: train record self-hash mismatch")

    prep = c23.prepare_basin(contract23, basin_id)
    model = c23.build_mode_model(contract23, prep)
    c23.restore_(model, c23.snapshot_from_lists(model, snap_lists))

    test_origins = fixed_origins(config, "test")
    with torch.no_grad():
        loss, details = c24.extended_rolling_objective(
            model, prep["forcing"], prep["obs"], prep["x0"],
            prep["noise"]["initial_covariance"], test_origins, leads=LEADS,
            base_observation_variance=prep["noise"]["base_observation_variance"])
        errors = c24.extended_forecast_errors(
            model, details["origin_states"], prep["forcing"], prep["obs"],
            test_origins, LEADS)

    np.savez_compressed(
        npz_path, origins=np.asarray(test_origins, dtype=np.int64),
        **{f"lead_{lead}": errors[lead] for lead in LEADS})
    record = {
        "stage": "readout", "experiment_id": config["experiment_id"],
        "grade": "development_probe", "basin_id": basin_id, "mode": mode,
        "variant": variant,
        "checkpoint_sha256": train_record["checkpoint_sha256"],
        "test_pooled_mse": float(loss),
        "test_mse_by_lead": {str(L): float(errors[L].mean()) for L in LEADS},
        "test_origin_count": len(test_origins),
        "errors_npz": npz_path.name,
        "errors_npz_sha256": c24.sha256_file(npz_path),
        "environment": c23.environment_stamp(),
        "seconds": time.perf_counter() - t0,
        "ran_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    write_json(json_path, record)
    return record


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", required=True,
                    choices=["anchor", "anchor_gate", "train", "readout"])
    ap.add_argument("--basin", default=None)
    ap.add_argument("--mode", default=None, choices=list(c23.MODES))
    ap.add_argument("--variant", default=None, choices=["y2", "y6", "base"])
    ap.add_argument("--config", default=str(DEFAULT_CONFIG))
    ap.add_argument("--out-root", required=True)
    ap.add_argument("--train-root", default=None)
    ap.add_argument("--updates-override", type=int, default=None)
    a = ap.parse_args()

    config, contract23 = load_all(a.config)
    out_root = Path(a.out_root)

    if a.stage == "anchor":
        record = stage_anchor(config, contract23, a.basin, out_root)
        print(json.dumps({k: record[k] for k in
                          ("basin_id", "anchor_delta", "passed", "seconds")}))
        return 0
    if a.stage == "anchor_gate":
        verdict = stage_anchor_gate(config, contract23, out_root)
        print(json.dumps({k: verdict[k] for k in
                          ("passed_count", "required", "pass", "missing")}))
        return 0 if verdict["pass"] else 1
    if not a.basin or not a.mode:
        raise SystemExit("--basin and --mode required")
    if a.mode != "all_frozen" and a.variant not in ("y2", "y6"):
        raise SystemExit("--variant y2|y6 required for learning arms")
    if a.stage == "train":
        record = stage_train(config, contract23, a.basin, a.mode,
                             a.variant or "base", out_root, a.updates_override)
        print(json.dumps({k: record[k] for k in
                          ("basin_id", "mode", "variant", "selected_update",
                           "peak_rss_mb", "seconds")} |
                         ({"timing_probe": record["timing_probe"]}
                          if a.updates_override else {})))
        return 0
    record = stage_readout(config, contract23, a.basin, a.mode,
                           a.variant or "base", out_root,
                           Path(a.train_root or a.out_root))
    print(json.dumps({k: record[k] for k in
                      ("basin_id", "mode", "variant", "test_pooled_mse",
                       "seconds")}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
