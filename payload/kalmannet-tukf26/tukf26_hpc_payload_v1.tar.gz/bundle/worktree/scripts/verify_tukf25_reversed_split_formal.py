# -*- coding: utf-8 -*-
"""TUKF25 independent verifier: recompute the verdict from raw error arrays.

Written and frozen (hash-pinned in the TUKF25 config) BEFORE the reversed
test segment is unsealed — TUKF23/24 discipline. Everything is recomputed
from the per-origin squared-error npz files; worker-reported aggregates
are only cross-checked, never reused.

Order of judgment (contract sections 3 and 5, frozen before any readout):

  0. training-success precondition (eligibility, not a science gate):
     if joint or filter_only has selected_update == 0 in MORE than 1/3 of
     the 27 basins (i.e. >= 10), NO verdict is written; only
     training_diagnosis_required.json is produced.
  1. V1 sanity gate:  filter_only / all_frozen, leads 1-10 pooled,
     wins >= 19/27 AND one-sided sign test p <= 0.05.
     Fail => EXPERIMENT_INVALID: only "the assimilation baseline did not
     reproduce on fresh basins" may ever be reported; no contrast number
     is citable.
  2. G1 primary gate:  joint / filter_only, leads 1-10 pooled, same rule.
     V1 pass + G1 pass => reversed-direction joint gain CONFIRMED
       (year-representativeness reading; forward verdicts unchanged).
     V1 pass + G1 fail => the joint-learning line is CLOSED in both
       directions after three formal experiments.
  CLEAR_HARM flag: any reported contrast median MSE ratio >= 1.10.
  Sign test: n = 27 fixed, ties count against wins.

Metrics: delta-NSE primary, MSE ratio appendix (TUKF24 2026-08-27
addendum); wins are identical under both by construction and this
verifier asserts that on every contrast.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import tukf24_lead_extension_common as c24  # noqa: E402

c23 = c24.c23

EXPERIMENT_ID = "TUKF25_REVERSED_SPLIT_FRESH_BASINS_V1"
DEFAULT_CONFIG = c23.WORKTREE / "configs/tukf25_reversed_split_fresh_basins_v1.json"

LEADS = list(c24.LEADS_EXTENDED)
BANDS = {"band_1_3": (1, 2, 3), "band_4_10": (4, 5, 6, 7, 8, 9, 10),
         "band_1_10": tuple(range(1, 11))}

CONTRASTS = [
    ("filter_only_over_all_frozen", "filter_only", "all_frozen"),   # V1
    ("joint_over_filter_only", "joint", "filter_only"),             # G1
    ("joint_over_all_frozen", "joint", "all_frozen"),               # descriptive
    ("hydrology_only_over_all_frozen", "hydrology_only", "all_frozen"),  # descriptive
]

MIN_WINS = 19
ALPHA = 0.05
PRECHECK_MAX_ZERO = 9   # > 9 of 27 (i.e. > 1/3) zero-update basins halts judging


def load_tukf25_config(path: str) -> dict:
    config = json.loads(Path(path).read_text(encoding="utf-8"))
    if config["experiment_id"] != EXPERIMENT_ID:
        raise ValueError("wrong experiment id")
    for key, entry in config["frozen_input_sha256"].items():
        file_path = c23.ROOTS[entry["root"]] / entry["rel"]
        actual = c23.sha256_file(file_path)
        if actual != entry["sha256"]:
            raise ValueError(f"frozen input drifted: {key}")
    return config


def training_success_precheck(config: dict, train_root: Path) -> dict:
    basins = list(config["basins"]["fresh_basin_ids"])
    counts = {}
    for mode in ("hydrology_only", "filter_only", "joint"):
        zeros = []
        for basin in basins:
            record = json.loads((train_root / "train" / f"{basin}_{mode}.json")
                                .read_text(encoding="utf-8"))
            if int(record["selected_update"]) == 0:
                zeros.append(basin)
        counts[mode] = {"zero_update_basins": zeros, "count": len(zeros)}
    halted = (counts["joint"]["count"] > PRECHECK_MAX_ZERO
              or counts["filter_only"]["count"] > PRECHECK_MAX_ZERO)
    return {"rule": "judging halts if joint or filter_only has selected_update==0 "
                    f"in more than 1/3 of basins (>{PRECHECK_MAX_ZERO}/27)",
            "counts": counts, "halted": bool(halted)}


def load_generation(cell_dir: Path, basins, origins) -> dict:
    errors = {}
    for basin in basins:
        for mode in c23.MODES:
            key = f"{basin}_{mode}"
            record = json.loads((cell_dir / f"{key}.json").read_text(encoding="utf-8"))
            with np.load(cell_dir / f"{key}.npz") as z:
                if not np.array_equal(z["origins"], origins):
                    raise ValueError(f"{key}: origin grid drifted")
                per_lead = {lead: z[f"lead_{lead}"].astype(np.float64)
                            for lead in LEADS}
            for lead in LEADS:
                worker = record["test_mse_by_lead"][str(lead)]
                mine = float(per_lead[lead].mean())
                if not math.isclose(worker, mine, rel_tol=1e-12):
                    raise ValueError(f"{key}: worker MSE lead {lead} disagrees "
                                     "with the raw array")
            errors[(basin, mode)] = per_lead
    return errors


def band_mse(per_lead: dict, band) -> float:
    return float(np.mean([per_lead[lead].mean() for lead in band]))


def _stats(ratios, dnse) -> dict:
    ratios = np.asarray(ratios)
    dnse = np.asarray(dnse)
    wins_r = int(np.sum(ratios < 1.0))
    wins_n = int(np.sum(dnse > 0.0))
    if wins_r != wins_n:
        raise AssertionError("metric invariance broken between ratio and delta-NSE")
    p, fraction = c24.sign_test_p(wins_r)
    return {
        "median_delta_nse": float(np.median(dnse)),
        "median_mse_ratio": float(np.median(ratios)),
        "wins": wins_r,
        "losses": int(np.sum(ratios > 1.0)),
        "ties": int(np.sum(ratios == 1.0)),
        "one_sided_sign_test_p": p,
        "sign_test_fraction": fraction,
        "clear_harm": bool(np.median(ratios) >= 1.10),
    }


def contrast_block(basins, err_num, err_den, var, gate_band=None) -> dict:
    out = {"by_lead": {}, "bands": {}}
    for lead in LEADS:
        ratios, dnse = [], []
        for b in basins:
            m_num = float(err_num[b][lead].mean())
            m_den = float(err_den[b][lead].mean())
            ratios.append(m_num / m_den)
            dnse.append((m_den - m_num) / var[b][lead])
        out["by_lead"][str(lead)] = _stats(ratios, dnse)
    for band_name, band in BANDS.items():
        ratios, dnse = [], []
        for b in basins:
            ratios.append(band_mse(err_num[b], band) / band_mse(err_den[b], band))
            dnse.append(float(np.mean(
                [(err_den[b][L].mean() - err_num[b][L].mean()) / var[b][L]
                 for L in band])))
        out["bands"][band_name] = _stats(ratios, dnse)
    if gate_band is not None:
        stats = out["bands"][gate_band]
        out["gate"] = {
            "band": gate_band,
            "wins": stats["wins"],
            "one_sided_sign_test_p": stats["one_sided_sign_test_p"],
            "pass": bool(stats["wins"] >= MIN_WINS
                         and stats["one_sided_sign_test_p"] <= ALPHA),
        }
    return out


def per_basin_table(basins, err_num, err_den, var, band) -> list[dict]:
    rows = []
    for b in basins:
        dnse = float(np.mean([(err_den[b][L].mean() - err_num[b][L].mean()) / var[b][L]
                              for L in band]))
        rows.append({"basin_id": b, "band_1_10_delta_nse": dnse,
                     "band_1_10_mse_ratio":
                         band_mse(err_num[b], band) / band_mse(err_den[b], band)})
    return sorted(rows, key=lambda r: -r["band_1_10_delta_nse"])


def flow_tercile_block(config, basins, err, var_unused, view, origins) -> dict:
    """Descriptive: thresholds from TRAIN-origin-day observations (reversed:
    the LATE 2 years), each test target day classified by its own obs."""
    lo, hi = (int(v) for v in config["segments_day_index"]["train_origins"])
    out = {}
    for name, num, den in (("filter_only_over_all_frozen", "filter_only", "all_frozen"),
                           ("joint_over_filter_only", "joint", "filter_only")):
        terciles = {"low": [], "mid": [], "high": []}
        for b in basins:
            obs = c23.c21.load_basin_arrays(view, b)["obs"]
            q1, q2 = np.quantile(obs[lo:hi + 1], [1 / 3, 2 / 3])
            masks = {}
            for L in LEADS:
                target_obs = obs[np.asarray(origins) + L]
                masks[L] = {"low": target_obs <= q1,
                            "mid": (target_obs > q1) & (target_obs <= q2),
                            "high": target_obs > q2}
            for terc in terciles:
                num_mse = np.mean([err[(b, num)][L][masks[L][terc]].mean()
                                   for L in LEADS if masks[L][terc].any()])
                den_mse = np.mean([err[(b, den)][L][masks[L][terc]].mean()
                                   for L in LEADS if masks[L][terc].any()])
                terciles[terc].append(float(num_mse / den_mse))
        out[name] = {terc: {"median_ratio": float(np.median(vals)),
                            "wins": int(np.sum(np.asarray(vals) < 1.0))}
                     for terc, vals in terciles.items()}
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results-root", required=True,
                    help="directory containing readout/ (json+npz)")
    ap.add_argument("--train-root", required=True,
                    help="directory containing train/ (108 records)")
    ap.add_argument("--config", default=str(DEFAULT_CONFIG))
    a = ap.parse_args()

    config = load_tukf25_config(a.config)
    contract23 = c23.load_contract(
        c23.WORKTREE / config["predecessor"]["tukf23_config"], verify_hashes=True)
    basins = list(config["basins"]["fresh_basin_ids"])
    if len(basins) != 27:
        raise ValueError("expected 27 fresh basins")

    root = Path(a.results_root)
    out = root / "formal_verdict.json"
    if out.exists():
        print(f"REFUSED: {out} already exists; verdicts are never rewritten")
        return 1

    precheck = training_success_precheck(config, Path(a.train_root))
    if precheck["halted"]:
        diag = {"experiment_id": config["experiment_id"],
                "verdict_withheld": True,
                "reason": "training-success precondition failed",
                "precheck": precheck,
                "at_utc": datetime.now(timezone.utc).isoformat()}
        c24.write_json(root / "training_diagnosis_required.json", diag)
        print("JUDGING HALTED: training-success precondition failed; "
              "wrote training_diagnosis_required.json, no verdict produced")
        return 2

    lo, hi = (int(v) for v in config["segments_day_index"]["test_origins"])
    origins = np.arange(lo, hi + 1, dtype=np.int64)
    err = load_generation(root / "readout", basins, origins)

    view = c23.c21_view(contract23)
    var = {}
    for b in basins:
        obs = c23.c21.load_basin_arrays(view, b)["obs"]
        var[b] = {L: float(np.var(obs[origins + L])) for L in LEADS}

    def mode_errors(mode):
        return {b: err[(b, mode)] for b in basins}

    blocks = {}
    for name, num, den in CONTRASTS:
        gate_band = "band_1_10" if name in ("filter_only_over_all_frozen",
                                            "joint_over_filter_only") else None
        blocks[name] = contrast_block(basins, mode_errors(num), mode_errors(den),
                                      var, gate_band=gate_band)

    v1 = {"contrast": "filter_only_over_all_frozen",
          **blocks["filter_only_over_all_frozen"]["gate"]}
    g1 = {"contrast": "joint_over_filter_only",
          **blocks["joint_over_filter_only"]["gate"]}

    if not v1["pass"]:
        outcome = ("EXPERIMENT_INVALID_BASELINE_NOT_REPRODUCED: only 'the "
                   "assimilation baseline did not reproduce on the fresh basins' "
                   "may be reported; no contrast number is citable (contract 5)")
        citable = False
        g1_judged = False
    else:
        citable = True
        g1_judged = True
        if g1["pass"]:
            outcome = ("REVERSED_JOINT_GAIN_CONFIRMED: joint learning's value is a "
                       "year-representativeness question, not 'no signal'; the "
                       "forward TUKF23/24 verdicts stand unchanged (contract 5)")
        else:
            outcome = ("JOINT_LINE_CLOSED_BOTH_DIRECTIONS: the probe's 16/27 was "
                       "sampling noise or old-27 specificity; after three formal "
                       "experiments in two directions the joint-learning line is "
                       "closed (contract 5)")

    clear_harm_flags = [
        {"contrast": cname, "scope": scope}
        for cname, block in blocks.items()
        for scope, stats in ([(f"lead_{k}", v) for k, v in block["by_lead"].items()]
                             + [(k, v) for k, v in block["bands"].items()])
        if stats["clear_harm"]
    ]

    verdict = {
        "schema_version": "tukf25_formal_verdict_v1",
        "experiment_id": config["experiment_id"],
        "verified_at_utc": datetime.now(timezone.utc).isoformat(),
        "judged_on": "reversed_early_year_test_segment_single_unsealing",
        "replicates": len(basins),
        "test_origin_count": int(origins.size),
        "metric_note": "delta-NSE primary, MSE ratio appendix; wins identical "
                       "under both, asserted per contrast",
        "training_success_precheck": precheck,
        "gates": {"V1_sanity": v1,
                  "G1_primary": {**g1, "judged": g1_judged}},
        "outcome": outcome,
        "contrast_numbers_citable": citable,
        "contrasts": blocks,
        "per_basin_joint_over_filter_only_band_1_10": per_basin_table(
            basins, mode_errors("joint"), mode_errors("filter_only"), var,
            BANDS["band_1_10"]),
        "flow_terciles_descriptive": flow_tercile_block(
            config, basins, err, var, view, origins),
        "clear_harm_flags": clear_harm_flags,
        "verifier_independence": "recomputed from per-origin squared-error arrays; "
                                 "worker aggregates only cross-checked, never reused",
        "probe_numbers_quarantine": "the 2026-08-31 dev-probe numbers (old 27 "
                                    "basins) are hypothesis source only and must "
                                    "never be tabulated next to these results",
    }

    c24.write_json(out, verdict)
    print(f"wrote {out}")
    print(f"verdict sha256 {c24.sha256_file(out)}")
    print(json.dumps({"V1": v1["pass"], "G1": (g1["pass"] if g1_judged else "not_judged"),
                      "outcome": outcome.split(":")[0],
                      "harm_flags": len(clear_harm_flags)}, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
