# -*- coding: utf-8 -*-
"""TUKF25 per-cell worker: anchor | anchor_gate | train | seal | readout.

Kratzert-style REVERSED split (train the latest 2 years, seal the earliest
~5 years) on 27 FRESH basins drawn from the untouched remainder of the
TUKF21 eligible pool. The training/readout math is the verbatim replica of
the 2026-08-31 dev probe (results/tukf25_reversed_split_dev_probe/
tukf_reversed_split_dev.py), which itself replicated the frozen TUKF24
step-2 recipe; formal upgrades over the probe, per contract section 6:

  1. config-driven: segments, noise window, basins, gates all come from
     configs/tukf25_reversed_split_fresh_basins_v1.json, whose
     frozen_input_sha256 manifest is verified at startup (as are the
     frozen TUKF24 config and TUKF23 contract chains).
  2. anchor gate 27/27 precondition: the train stage refuses to run
     unless anchor_gate_verdict.json exists with pass=true and lists the
     basin (the verdict is only written when all 27 fresh basins pass).
  3. checkpoint seal: readout refuses to run without a complete 108-cell
     seal; every checkpoint is re-hashed against the seal before scoring.
  4. single unsealing is procedural (seal installed once, readout array
     submitted once) exactly as TUKF23/24; the independent verifier
     additionally refuses to rewrite a verdict.

Inherent reversed-split disclosures (config noise_construction_override):
the no-grad warm-start/selection rollouts traverse the early (test) years
as filter input history, and the suffix noise-statistic window overlaps
the sealed target days by 350 days; both are common to all four arms and
carry no gradient and no test-target scoring.

    anchor       python tukf25_reversed_split_worker.py --stage anchor --basin B --config CFG --out-root R
    anchor_gate  ... --stage anchor_gate --config CFG --out-root R
    train        ... --stage train --basin B --mode M --config CFG --out-root R
    seal         ... --stage seal --config CFG --out-root R --train-root R
    readout      ... --stage readout --basin B --mode M --config CFG --out-root R \
                     --train-root R --seal R/checkpoint_seal.json
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import tukf24_lead_extension_common as c24  # noqa: E402

c23 = c24.c23
c21 = c23.c21
t17 = c24.t17

torch.set_num_threads(1)

EXPERIMENT_ID = "TUKF25_REVERSED_SPLIT_FRESH_BASINS_V1"
LEADS = c24.LEADS_EXTENDED
DEFAULT_CONFIG = c23.WORKTREE / "configs/tukf25_reversed_split_fresh_basins_v1.json"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_snapshot_sha(lists: dict) -> str:
    payload = json.dumps(lists, sort_keys=True, separators=(",", ":"))
    return sha256_bytes(payload.encode())


def write_json(path: Path, payload: dict) -> None:
    """LF bytes always (TUKF23 CRLF lesson: hash on LF)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=1), encoding="utf-8", newline="\n")


def load_config(path: Path | str = DEFAULT_CONFIG, *, verify_hashes: bool = True) -> dict:
    config = json.loads(Path(path).read_text(encoding="utf-8"))
    if config["experiment_id"] != EXPERIMENT_ID:
        raise ValueError("wrong experiment id")
    if verify_hashes:
        for key, entry in config["frozen_input_sha256"].items():
            file_path = c23.ROOTS[entry["root"]] / entry["rel"]
            actual = c23.sha256_file(file_path)
            if actual != entry["sha256"]:
                raise ValueError(
                    f"frozen input drifted: {key}: recorded {entry['sha256']} actual {actual}")
    return config


def load_all(config_path: Path | str) -> tuple[dict, dict]:
    """TUKF25 config + the full frozen predecessor chain, all hash-verified."""
    config = load_config(config_path, verify_hashes=True)
    c24.load_config(c23.WORKTREE / config["predecessor"]["tukf24_config"],
                    verify_hashes=True)  # provenance attestation of the recipe chain
    contract23 = c23.load_contract(
        c23.WORKTREE / config["predecessor"]["tukf23_config"], verify_hashes=True)
    return config, contract23


def segment_origins(config: dict, name: str) -> tuple[int, ...]:
    lo, hi = config["segments_day_index"][f"{name}_origins"]
    return tuple(range(int(lo), int(hi) + 1))


def prepare_basin_reversed(config: dict, contract23: dict, basin_id: str) -> dict:
    """c23.prepare_basin (anchor gate unchanged) + noise rebuilt from the
    reversed statistic window. Verbatim probe math."""
    prep = c23.prepare_basin(contract23, basin_id)
    view = c23.c21_view(contract23)
    prior = c21.load_prior_table(view)
    row = prior.loc[prior["basin_id"] == basin_id].iloc[0]
    probe = c21.build_basin_model(view, row)
    with torch.no_grad():
        ol_full = t17.rollout_open_loop_states(
            probe, prep["forcing"], prep["x0"], prep["forcing"].shape[0])
        sim_full = probe.h(ol_full[1:])[:, 0].cpu().numpy()
    lo, hi = (int(v) for v in config["noise_construction_override"]["statistic_window_slice"])
    obs = prep["obs"]
    residual_std = float(np.std(sim_full[lo:hi] - obs[lo:hi]))
    mean_flow = float(np.mean(obs[lo:hi]))
    noise = c23.build_noise(contract23, prep["dim_x"], ol_full[lo:hi],
                            residual_std, mean_flow)
    prep = dict(prep)
    prep["noise"] = noise
    prep["residual_std_train"] = residual_std
    prep["mean_flow_train"] = mean_flow
    return prep


def selection_score_rev(config: dict, contract23: dict, model, prep: dict) -> float:
    sel = segment_origins(config, "selection")
    hi = max(sel) + max(LEADS) + 1
    first_train = int(config["segments_day_index"]["train_origins"][0])
    if hi > first_train:  # mirrored guard: selection must not read a train day
        raise ValueError("selection scoring would read a train day")
    with torch.no_grad():
        loss, _ = c24.extended_rolling_objective(
            model, prep["forcing"][:hi], prep["obs"][:hi], prep["x0"],
            prep["noise"]["initial_covariance"], sel, leads=LEADS,
            base_observation_variance=prep["noise"]["base_observation_variance"])
    return float(loss)


def require_anchor_gate(config: dict, out_root: Path, basin_id: str) -> None:
    verdict_path = out_root / "anchor_gate_verdict.json"
    if not verdict_path.exists():
        raise RuntimeError("train refused: anchor_gate_verdict.json missing "
                           "(run --stage anchor for all basins, then --stage anchor_gate)")
    verdict = json.loads(verdict_path.read_text(encoding="utf-8"))
    if verdict.get("experiment_id") != config["experiment_id"] or not verdict.get("pass"):
        raise RuntimeError("train refused: anchor gate did not pass")
    if basin_id not in verdict.get("passed_basins", []):
        raise RuntimeError(f"train refused: basin {basin_id} not in the passed anchor list")


def stage_anchor(config: dict, contract23: dict, basin_id: str, out_root: Path) -> dict:
    t0 = time.perf_counter()
    prep = c23.prepare_basin(contract23, basin_id)  # raises on anchor failure
    record = {
        "stage": "anchor",
        "experiment_id": config["experiment_id"],
        "basin_id": basin_id,
        "dim_x": prep["dim_x"],
        "anchor_delta": prep["anchor_delta"],
        "published_nse": prep["published_nse"],
        "tolerance": float(contract23["anchor_gate"]["tolerance"]),
        "passed": True,
        "environment": c23.environment_stamp(),
        "seconds": time.perf_counter() - t0,
        "ran_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    write_json(out_root / "anchor" / f"{basin_id}.json", record)
    return record


def stage_anchor_gate(config: dict, contract23: dict, out_root: Path) -> dict:
    """Aggregate the 27 per-basin anchor records into the go/no-go verdict."""
    basins = list(config["basins"]["fresh_basin_ids"])
    tolerance = float(contract23["anchor_gate"]["tolerance"])
    passed, deltas, missing = [], {}, []
    for basin in basins:
        path = out_root / "anchor" / f"{basin}.json"
        if not path.exists():
            missing.append(basin)
            continue
        record = json.loads(path.read_text(encoding="utf-8"))
        deltas[basin] = record["anchor_delta"]
        if record.get("passed") and record["anchor_delta"] <= tolerance:
            passed.append(basin)
    verdict = {
        "experiment_id": config["experiment_id"],
        "stage": "anchor_gate",
        "required": len(basins),
        "passed_count": len(passed),
        "passed_basins": passed,
        "missing": missing,
        "anchor_deltas": deltas,
        "tolerance": tolerance,
        "pass": len(passed) == len(basins) == 27 and not missing,
        "ran_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    write_json(out_root / "anchor_gate_verdict.json", verdict)
    return verdict


def stage_train(config: dict, contract23: dict, basin_id: str, mode: str,
                out_root: Path) -> dict:
    t0 = time.perf_counter()
    require_anchor_gate(config, out_root, basin_id)
    out = out_root / "train" / f"{basin_id}_{mode}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        return json.loads(out.read_text(encoding="utf-8"))

    prep = prepare_basin_reversed(config, contract23, basin_id)
    model = c23.build_mode_model(contract23, prep)
    hyd, fil = c23.mode_groups(contract23, model, mode)
    mask = contract23["modes"]["masks"][mode]

    seg = config["segments_day_index"]
    warmup_end = int(seg["train_origins"][0])       # everything before train
    train_origins = segment_origins(config, "train")
    train_hi = max(train_origins) + max(LEADS) + 1
    if train_hi > prep["forcing"].shape[0]:
        raise ValueError("train targets overflow the series")
    if warmup_end <= int(seg["buffer_2"][1]):
        raise ValueError("train slice would start inside the selection era or buffer")
    forcing, obs = prep["forcing"], prep["obs"]
    cov0 = prep["noise"]["initial_covariance"]
    base_var = prep["noise"]["base_observation_variance"]
    spec = contract23["optimizer"]

    trainable_groups = []
    if mask["hydrology"]:
        trainable_groups.append(
            {"params": hyd, "lr": float(spec["hydrology_learning_rate"])})
    if mask["filter"]:
        trainable_groups.append(
            {"params": fil, "lr": float(spec["filter_learning_rate"])})

    step = int(spec["selection_interval"])
    total = int(spec["updates"])
    queries = tuple(range(0, total + 1, step))
    query_trace: list[list[float]] = []
    train_trace: list[float] = []

    if not trainable_groups:
        best = {"score": None, "update": 0, "snap": c23.snapshot(model)}
    else:
        optimizer = torch.optim.Adam(trainable_groups)
        clip = float(spec["group_gradient_norm"])
        train_forcing = torch.as_tensor(forcing[warmup_end:train_hi])
        train_obs = torch.as_tensor(obs[warmup_end:train_hi])
        shifted_origins = tuple(o - warmup_end for o in train_origins)

        def warm_start():
            with torch.no_grad():
                trace = t17.rollout_state_update_trace(
                    model, forcing[:warmup_end], obs[:warmup_end], prep["x0"], cov0,
                    base_observation_variance=base_var)
                return (trace["posterior_state"][-1].detach().clone(),
                        trace["posterior_covariance"][-1].detach().clone())

        score0 = selection_score_rev(config, contract23, model, prep)
        query_trace.append([0, score0])
        best = {"score": score0, "update": 0, "snap": c23.snapshot(model)}

        for update in range(1, total + 1):
            optimizer.zero_grad(set_to_none=True)
            warm_state, warm_cov = warm_start()
            loss, _ = c24.extended_rolling_objective(
                model, train_forcing, train_obs, warm_state, warm_cov,
                shifted_origins, leads=LEADS,
                base_observation_variance=base_var)
            loss.backward()
            if mask["hydrology"]:
                torch.nn.utils.clip_grad_norm_(hyd, clip)
            if mask["filter"]:
                torch.nn.utils.clip_grad_norm_(fil, clip)
            optimizer.step()
            projector = getattr(model, "project_trainable_coordinates_", None)
            if callable(projector):
                projector()
            train_trace.append(float(loss))
            if update in queries:
                score = selection_score_rev(config, contract23, model, prep)
                query_trace.append([update, score])
                if score < best["score"]:  # strict: tie keeps the earlier update
                    best = {"score": score, "update": update, "snap": c23.snapshot(model)}

    c23.restore_(model, best["snap"])
    snap_lists = c23.snapshot_to_lists(best["snap"])
    record = {
        "stage": "train",
        "experiment_id": config["experiment_id"],
        "grade": "formal",
        "basin_id": basin_id,
        "mode": mode,
        "leads_days": list(LEADS),
        "segments_day_index": config["segments_day_index"],
        "noise_stat_slice": list(config["noise_construction_override"]["statistic_window_slice"]),
        "dim_x": prep["dim_x"],
        "anchor_delta": prep["anchor_delta"],
        "base_observation_variance": base_var,
        "selected_update": best["update"],
        "selection_score_at_checkpoint": best["score"],
        "selection_query_trace": query_trace,
        "train_loss_trace": train_trace,
        "checkpoint_snapshot": snap_lists,
        "checkpoint_sha256": canonical_snapshot_sha(snap_lists),
        "learned_observation_ratio": float(model.observation_ratio()),
        "learned_process_diagonal": [float(v) for v in model.process_diagonal().reshape(-1)],
        "test_segment_contact": "no gradient, no test-target scoring "
                                "(reversed-split no-grad traversal disclosed in config)",
        "environment": c23.environment_stamp(),
        "seconds": time.perf_counter() - t0,
        "ran_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    write_json(out, record)
    return record


def stage_seal(config: dict, out_root: Path, train_root: Path) -> dict:
    """Build the 108-cell checkpoint seal (TUKF23 schema). Never rewrites."""
    seal_path = out_root / "checkpoint_seal.json"
    if seal_path.exists():
        raise RuntimeError("seal already exists; seals are never rewritten")
    basins = list(config["basins"]["fresh_basin_ids"])
    cells = {}
    for mode in c23.MODES:
        for basin in basins:
            key = f"{basin}_{mode}"
            path = train_root / "train" / f"{key}.json"
            if not path.exists():
                raise RuntimeError(f"seal refused: train record missing for {key}")
            raw = path.read_bytes()
            record = json.loads(raw.decode("utf-8"))
            snap_sha = canonical_snapshot_sha(record["checkpoint_snapshot"])
            if snap_sha != record["checkpoint_sha256"]:
                raise RuntimeError(f"seal refused: {key} snapshot hash inconsistent")
            cells[key] = {
                "checkpoint_sha256": snap_sha,
                "selected_update": record["selected_update"],
                "train_record_sha256": sha256_bytes(raw),
            }
    if len(cells) != 108:
        raise RuntimeError(f"seal refused: expected 108 cells, found {len(cells)}")
    seal_sha = sha256_bytes(json.dumps(
        cells, sort_keys=True, separators=(",", ":")).encode())
    seal = {
        "experiment_id": config["experiment_id"],
        "sealed_at_utc": datetime.now(timezone.utc).isoformat(),
        "cell_count": len(cells),
        "cells": cells,
        "seal_sha256": seal_sha,
        "statement": "All 108 checkpoints selected without any test-segment metric "
                     "query. The reversed early-year test readout is authorized only "
                     "against these exact checkpoints, exactly once.",
    }
    write_json(seal_path, seal)
    return seal


def stage_readout(config: dict, contract23: dict, basin_id: str, mode: str,
                  out_root: Path, train_root: Path, seal_path: Path) -> dict:
    """Score one sealed checkpoint on the REVERSED (early-year) test grid."""
    t0 = time.perf_counter()
    seal = json.loads(Path(seal_path).read_text(encoding="utf-8"))
    if seal.get("experiment_id") != config["experiment_id"]:
        raise ValueError("seal belongs to a different experiment")
    if seal.get("cell_count") != 108:
        raise ValueError("readout refused: training is not fully sealed")
    cell_key = f"{basin_id}_{mode}"
    if cell_key not in seal["cells"]:
        raise ValueError(f"cell {cell_key} is not sealed")

    out_dir = out_root / "readout"
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = out_dir / f"{cell_key}.json"
    npz_path = out_dir / f"{cell_key}.npz"
    if json_path.exists() and npz_path.exists():
        return json.loads(json_path.read_text(encoding="utf-8"))

    train_path = train_root / "train" / f"{cell_key}.json"
    raw = train_path.read_bytes()
    if sha256_bytes(raw) != seal["cells"][cell_key]["train_record_sha256"]:
        raise ValueError(f"{cell_key}: train record drifted from the seal (file bytes)")
    train_record = json.loads(raw.decode("utf-8"))
    snap_lists = train_record["checkpoint_snapshot"]
    expected_sha = seal["cells"][cell_key]["checkpoint_sha256"]
    if canonical_snapshot_sha(snap_lists) != expected_sha:
        raise ValueError(f"{cell_key}: checkpoint drifted from the seal")

    prep = prepare_basin_reversed(config, contract23, basin_id)
    model = c23.build_mode_model(contract23, prep)
    c23.restore_(model, c23.snapshot_from_lists(model, snap_lists))

    test_origins = segment_origins(config, "test")
    with torch.no_grad():
        loss, details = c24.extended_rolling_objective(
            model, prep["forcing"], prep["obs"], prep["x0"],
            prep["noise"]["initial_covariance"], test_origins, leads=LEADS,
            base_observation_variance=prep["noise"]["base_observation_variance"])
        errors = c24.extended_forecast_errors(
            model, details["origin_states"], prep["forcing"], prep["obs"],
            test_origins, LEADS)

    np.savez_compressed(
        npz_path, origins=np.asarray(test_origins, dtype=np.int64),
        **{f"lead_{lead}": errors[lead] for lead in LEADS})
    record = {
        "stage": "readout",
        "experiment_id": config["experiment_id"],
        "grade": "formal",
        "basin_id": basin_id,
        "mode": mode,
        "checkpoint_sha256": expected_sha,
        "seal_sha256": seal["seal_sha256"],
        "test_pooled_mse": float(loss),
        "test_mse_by_lead": {str(L): float(errors[L].mean()) for L in LEADS},
        "test_origin_count": len(test_origins),
        "errors_npz": npz_path.name,
        "errors_npz_sha256": c24.sha256_file(npz_path),
        "environment": c23.environment_stamp(),
        "seconds": time.perf_counter() - t0,
        "ran_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    write_json(json_path, record)
    return record


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", required=True,
                    choices=["anchor", "anchor_gate", "train", "seal", "readout"])
    ap.add_argument("--basin", default=None)
    ap.add_argument("--mode", default=None, choices=list(c23.MODES))
    ap.add_argument("--config", default=str(DEFAULT_CONFIG))
    ap.add_argument("--out-root", required=True)
    ap.add_argument("--train-root", default=None)
    ap.add_argument("--seal", default=None)
    a = ap.parse_args()

    config, contract23 = load_all(a.config)
    out_root = Path(a.out_root)

    if a.stage == "anchor":
        if not a.basin:
            raise SystemExit("--basin is required for the anchor stage")
        record = stage_anchor(config, contract23, a.basin, out_root)
        print(json.dumps({k: record[k] for k in
                          ("basin_id", "anchor_delta", "passed", "seconds")}))
        return 0
    if a.stage == "anchor_gate":
        verdict = stage_anchor_gate(config, contract23, out_root)
        print(json.dumps({k: verdict[k] for k in
                          ("passed_count", "required", "pass", "missing")}))
        return 0 if verdict["pass"] else 1
    if a.stage == "seal":
        if not a.train_root:
            raise SystemExit("--train-root is required for the seal stage")
        seal = stage_seal(config, out_root, Path(a.train_root))
        print(json.dumps({"cell_count": seal["cell_count"],
                          "seal_sha256": seal["seal_sha256"]}))
        return 0
    if not a.basin or not a.mode:
        raise SystemExit("--basin and --mode are required for train/readout")
    if a.stage == "train":
        record = stage_train(config, contract23, a.basin, a.mode, out_root)
        print(json.dumps({k: record[k] for k in
                          ("basin_id", "mode", "selected_update",
                           "selection_score_at_checkpoint", "seconds")}))
        return 0
    if not a.train_root or not a.seal:
        raise SystemExit("--train-root and --seal are required for readout")
    record = stage_readout(config, contract23, a.basin, a.mode, out_root,
                           Path(a.train_root), Path(a.seal))
    print(json.dumps({k: record[k] for k in
                      ("basin_id", "mode", "test_pooled_mse", "seconds")}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
