"""TUKF24 lead-extension experiment: shared machinery.

Everything TUKF23 is read-only. This module layers the 1-10 day lead
extension on top of the frozen TUKF23 machinery (imported unchanged via
c23). The frozen TUKF17 core hard-rejects leads other than (1, 2, 3), so
the extended forecast rollout is re-implemented here with the identical
math (model.f -> project_mean -> model.h) and is validated per cell
against the frozen code on leads 1-3 (bitwise) before any lead > 3 is
trusted.

Contract: docs/plans/2026-08-27-tukf24-real-camels-lead-extension-contract-draft.md
"""
from __future__ import annotations

import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import tukf23_real_camels_four_mode_common as c23  # noqa: E402

t17 = c23.t17

WORKTREE = c23.WORKTREE
EXPERIMENT_ID = "TUKF24_REAL_CAMELS_LEAD_EXTENSION_V1"
DEFAULT_CONFIG = WORKTREE / "configs/tukf24_real_camels_lead_extension_v1.json"

LEADS_EXTENDED = tuple(range(1, 11))
LEAD_BANDS = {"band_1_3": (1, 2, 3), "band_4_10": (4, 5, 6, 7, 8, 9, 10)}

CONTRASTS = (
    ("filter_only_over_all_frozen", "filter_only", "all_frozen"),
    ("joint_over_all_frozen", "joint", "all_frozen"),
    ("joint_over_filter_only", "joint", "filter_only"),
    ("hydrology_only_over_all_frozen", "hydrology_only", "all_frozen"),
)

SIGN_TEST_N = 27
DIRECTION_MIN_WINS = 19
SIGN_TEST_ALPHA = 0.05
L_STAR_MEDIAN_MAX = 0.95


def sha256_file(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path: Path, payload: dict) -> None:
    """LF bytes always (TUKF23 CRLF lesson: hash on LF)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=1), encoding="utf-8", newline="\n")


def load_config(path: Path | str = DEFAULT_CONFIG, *, verify_hashes: bool = True) -> dict:
    config = json.loads(Path(path).read_text(encoding="utf-8"))
    if config["experiment_id"] != EXPERIMENT_ID:
        raise ValueError("wrong experiment id")
    if verify_hashes:
        for key, entry in config["frozen_input_sha256"].items():
            file_path = c23.ROOTS[entry["root"]] / entry["rel"]
            actual = sha256_file(file_path)
            if actual != entry["sha256"]:
                raise ValueError(
                    f"frozen input drifted: {key}: recorded {entry['sha256']} actual {actual}")
    return config


def step1_origins(contract23: dict, max_lead: int) -> tuple[int, ...]:
    """Selection origins whose farthest target stays inside buffer 2.

    Buffer 2 ends the day before the first test origin, so no test-segment
    day is ever read, as target or otherwise.
    """
    seg = contract23["segments_day_index"]
    selection = c23.segment_origins(contract23, "selection")
    buffer2_end = int(seg["buffer_2"][1])
    first_test = int(seg["test_origins"][0])
    if buffer2_end + 1 != first_test:
        raise ValueError("buffer 2 must end the day before the test segment")
    origins = tuple(o for o in selection if o + max_lead <= buffer2_end)
    if not origins:
        raise ValueError("no usable step-1 origins")
    return origins


def extended_forecast_errors(model, origin_states: torch.Tensor,
                             forcing: np.ndarray, obs: np.ndarray,
                             origins: tuple[int, ...],
                             leads: tuple[int, ...]) -> dict[int, np.ndarray]:
    """Per-origin squared forecast errors for each lead.

    Identical math to the frozen t17.forecast_from_origin_states: the state
    advances through model.f then model.project_mean once per day; the
    discharge readout model.h does not feed back into the state, so the
    incremental rollout is bitwise-identical to t17's per-lead restarts.
    The forcing/obs arrays must already be sliced so that any out-of-bounds
    day access raises instead of silently reading forbidden days.
    """
    max_lead = max(leads)
    if max(origins) + max_lead >= forcing.shape[0]:
        raise ValueError("future forcing is incomplete for the requested origins")
    if max(origins) + max_lead >= obs.shape[0]:
        raise ValueError("future targets are incomplete for the requested origins")
    forcing_t = torch.as_tensor(forcing, dtype=model.dtype, device=model.device)
    origin_tensor = torch.as_tensor(origins, dtype=torch.long, device=model.device)
    state = origin_states
    if state.shape != (len(origins), int(model.dim_x)):
        raise ValueError("one origin state is required for every origin")
    errors: dict[int, np.ndarray] = {}
    with torch.no_grad():
        for step in range(1, max_lead + 1):
            state = model.f(state, forcing_t[origin_tensor + step])
            state = model.project_mean(state)
            if step in leads:
                prediction = model.h(state)[:, 0]
                if not bool(torch.isfinite(prediction).all()):
                    raise FloatingPointError(f"lead-{step} forecast is non-finite")
                target = torch.as_tensor(
                    obs[np.asarray(origins) + step], dtype=model.dtype, device=model.device)
                errors[step] = ((prediction - target) ** 2).cpu().numpy().astype(np.float64)
    return errors


def extended_rolling_objective(model, forcing, obs, initial_state, initial_covariance,
                               origins: tuple[int, ...], *,
                               leads: tuple[int, ...],
                               base_observation_variance) -> tuple[torch.Tensor, dict]:
    """Grad-enabled rolling-origin objective for arbitrary leads.

    Same computation as the frozen t17.rolling_origin_objective (state-update
    branch), with the lead set opened up: filter through the last origin,
    then roll each origin state forward day by day; equal-weight mean of the
    per-lead MSEs. With leads == (1, 2, 3) this must reproduce the frozen
    objective bitwise on the same machine (enforced by the local smoke).
    """
    forcing_t = torch.as_tensor(forcing, dtype=model.dtype, device=model.device)
    if forcing_t.ndim == 3 and forcing_t.shape[1] == 1:
        forcing_t = forcing_t[:, 0, :]
    obs_t = torch.as_tensor(obs, dtype=model.dtype, device=model.device).reshape(-1)
    if forcing_t.shape[0] != obs_t.shape[0]:
        raise ValueError("forcing and observations must share the day axis")
    if not origins:
        raise ValueError("at least one origin is required")
    max_origin = max(origins)
    max_lead = max(leads)
    if max_origin + max_lead >= forcing_t.shape[0]:
        raise ValueError("future forcing is incomplete for the requested origins")

    trace = t17.rollout_state_update_trace(
        model, forcing_t[: max_origin + 1], obs_t[: max_origin + 1],
        initial_state, initial_covariance,
        base_observation_variance=base_observation_variance)
    index = torch.as_tensor(origins, dtype=torch.long, device=model.device)
    states = trace["posterior_state"][index, 0, :]

    losses: dict[int, torch.Tensor] = {}
    state = states
    for step in range(1, max_lead + 1):
        state = model.f(state, forcing_t[index + step])
        state = model.project_mean(state)
        if step in leads:
            prediction = model.h(state)[:, 0]
            if not bool(torch.isfinite(prediction).all()):
                raise FloatingPointError(f"lead-{step} forecast is non-finite")
            losses[step] = torch.mean((prediction - obs_t[index + step]) ** 2)
    loss = torch.stack([losses[lead] for lead in leads]).mean()
    if not bool(torch.isfinite(loss)):
        raise FloatingPointError("extended rolling objective is non-finite")
    return loss, {"origins": tuple(origins), "mse_by_lead": losses,
                  "origin_states": states}


def step2_segment_origins(config: dict, name: str) -> tuple[int, ...]:
    lo, hi = config["step2_retrain"]["segments_day_index"][f"{name}_origins"]
    return tuple(range(int(lo), int(hi) + 1))


def sign_test_p(wins: int, n: int = SIGN_TEST_N) -> tuple[float, list[int]]:
    """One-sided exact sign test, TUKF23 convention: fixed n, ties count
    against the win side. Returns (p, [numerator, denominator])."""
    numerator = sum(math.comb(n, k) for k in range(wins, n + 1))
    denominator = 2 ** n
    return numerator / denominator, [numerator, denominator]


def contrast_stats(ratios: list[float]) -> dict:
    arr = np.asarray(ratios, dtype=np.float64)
    if arr.size != SIGN_TEST_N:
        raise ValueError(f"expected {SIGN_TEST_N} ratios, got {arr.size}")
    wins = int(np.sum(arr < 1.0))
    losses = int(np.sum(arr > 1.0))
    ties = int(np.sum(arr == 1.0))
    p, fraction = sign_test_p(wins)
    return {
        "median_ratio": float(np.median(arr)),
        "wins_below_one": wins,
        "losses_above_one": losses,
        "ties_at_one": ties,
        "one_sided_sign_test_p": p,
        "sign_test_fraction": fraction,
        "ratio_range": [float(arr.min()), float(arr.max())],
    }


def l_star(by_lead: dict[int, dict]) -> int:
    """Largest contiguous lead (from 1) with median ratio <= 0.95 AND
    wins >= 19/27; scanning stops at the first lead violating either."""
    result = 0
    for lead in sorted(by_lead):
        stats = by_lead[lead]
        if (stats["median_ratio"] <= L_STAR_MEDIAN_MAX
                and stats["wins_below_one"] >= DIRECTION_MIN_WINS):
            result = lead
        else:
            break
    return result
