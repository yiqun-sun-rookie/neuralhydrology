"""TUKF21 real-catchment common machinery.

Wraps the audited TUKF17 rolling-origin numerical core (filter trace, open-loop
replay, forecast, objective, statistics) around real CAMELS-US arrays and the
v5 calibrated prior. All heavy numerics are delegated to the pinned modules;
this file owns only data plumbing, per-basin model construction, the anchor
gate, and contract identity checks.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Any, Mapping

import numpy as np
import pandas as pd
import torch

WORKTREE = Path(__file__).resolve().parents[1]
KALMANNET_RO = Path("G:/github/pycharm/projects/kalmannet")
NH_ROOT = Path("G:/github/pycharm/projects/neuralhydrology")
DEFAULT_CONFIG = WORKTREE / "configs/tukf21_real_camels_rolling_origin_v1.json"

for _entry in (str(WORKTREE / "scripts"), str(KALMANNET_RO), str(KALMANNET_RO / "src"),
               str(NH_ROOT / "src")):
    if _entry not in sys.path:
        sys.path.insert(0, _entry)

from hydroagent.data_loading import load_camels_basin  # noqa: E402
import tukf17_hbv_rolling_origin_state_hydrology_common as t17  # noqa: E402
from global_hydrology.models.trainable_hbvlite_ukf_adapter import (  # noqa: E402
    JointTrainableRoutedHBVLiteUKF,
)

DTYPE = torch.float64
DEVICE = torch.device("cpu")

_HASHED_INPUT_PATHS = {
    "prior_csv": NH_ROOT / "results/10_global_conceptual_model_benchmark/camels_us_531_repro_v01_BEST/summary/hbv_lite_cma_local_full.csv",
    "basin_list": NH_ROOT / "src/xaj_global_pilot/configs/conceptual_benchmark_camels_us_531_repro.txt",
    "hbv_numpy": NH_ROOT / "src/scl_hydro/hbv_lite_numpy.py",
    "data_loader": NH_ROOT / "src/hydroagent/data_loading.py",
    "adapter": KALMANNET_RO / "src/global_hydrology/models/trainable_hbvlite_ukf_adapter.py",
    "hbv_torch": KALMANNET_RO / "src/global_hydrology/models/differentiable_hbv_lite.py",
    "ukf": KALMANNET_RO / "scripts/differentiable_ukf_hbvlite.py",
    "conventional_ukf": KALMANNET_RO / "src/global_hydrology/assimilation/conventional_ukf.py",
    "t17_common": WORKTREE / "scripts/tukf17_hbv_rolling_origin_state_hydrology_common.py",
    "screening_registry": WORKTREE / "artifacts/tukf21_real_camels_rolling_origin_v1/screening/basin_registry.json",
    "smoke_report": WORKTREE / "artifacts/tukf21_real_camels_rolling_origin_v1/smoke_local/smoke_report.json",
    "contract_draft": WORKTREE / "docs/plans/2026-08-25-tukf21-real-camels-rolling-origin-contract-draft.md",
}


def sha256_file(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_contract(path: Path | str = DEFAULT_CONFIG, *, verify_hashes: bool = True) -> dict:
    contract = json.loads(Path(path).read_text())
    if contract["experiment_id"] != "TUKF21_REAL_CAMELS_ROLLING_ORIGIN_V1":
        raise ValueError("wrong experiment id")
    if verify_hashes:
        recorded = contract["frozen_input_sha256"]
        for key, file_path in _HASHED_INPUT_PATHS.items():
            actual = sha256_file(file_path)
            if actual != recorded[key]:
                raise ValueError(
                    f"frozen input drifted: {key}: recorded {recorded[key]} actual {actual}")
    return contract


def gates_view(contract: Mapping[str, Any]) -> dict:
    """Adapter dict so t17.classify_contrast reads TUKF21 gate numbers."""
    g = contract["r1_pipeline_gate"]["gates"]
    return {"gates": {
        "independent_replicates": int(g["of"]),
        "minimum_direction_count": int(g["min_improvements"]),
        "clear_benefit_median_ratio_maximum": float(g["median_ratio_max"]),
        "clear_harm_median_ratio_minimum": 1.1,
    }}


def load_prior_table(contract: Mapping[str, Any]) -> pd.DataFrame:
    prior = pd.read_csv(contract["prior"]["csv"], dtype={"basin_id": str})
    prior["basin_id"] = prior["basin_id"].str.zfill(8)
    return prior


def load_basin_arrays(contract: Mapping[str, Any], basin_id: str) -> dict:
    """Load forcing (reordered to adapter order) and observed discharge."""
    window = contract["data"]["window"]
    forcing_df, obs_mm, area_km2 = load_camels_basin(
        basin_id,
        data_root=contract["data"]["camels_root"],
        start_date=window["start"], end_date=window["end"],
        forcing=contract["data"]["forcing"],
        pet_method=contract["data"]["pet_method"],
        keep_obs_nan_days=True,
    )
    # Adapter forcing order is (precipitation, temperature, pet); the loader
    # returns (prcp, ep, tmean). Feeding (P, PET, T) silently destroys skill.
    forcing = np.ascontiguousarray(
        forcing_df[["prcp", "tmean", "ep"]].to_numpy(dtype=np.float64))
    obs = np.ascontiguousarray(
        obs_mm.reindex(forcing_df.index).to_numpy(dtype=np.float64))
    if forcing.shape[0] != int(window["days"]):
        raise ValueError(f"{basin_id}: expected {window['days']} days, got {forcing.shape[0]}")
    if not (np.isfinite(forcing).all() and np.isfinite(obs).all()):
        raise ValueError(f"{basin_id}: NaN in screened window")
    return {"forcing": forcing, "obs": obs, "area_km2": float(area_km2)}


def routing_weights(lag_time: float) -> np.ndarray:
    n = max(int(np.ceil(lag_time)), 1)
    raw = np.arange(n, 0, -1, dtype=np.float64)
    return raw / raw.sum()


def build_basin_model(
    contract: Mapping[str, Any],
    row: Mapping[str, Any],
    *,
    process_variance: np.ndarray | None = None,
    observation_ratio: float | None = None,
) -> JointTrainableRoutedHBVLiteUKF:
    prior = contract["prior"]
    params = torch.tensor([[float(row[c]) for c in prior["param_columns"]]], dtype=DTYPE)
    weights = torch.tensor(routing_weights(float(row["p_lag_time"])), dtype=DTYPE).reshape(1, -1)
    dim_x = 5 + weights.shape[1]
    nc = contract["noise_construction"]
    if process_variance is None:
        process_variance = np.full(dim_x, 1e-4)
    if observation_ratio is None:
        observation_ratio = float(nc["observation_ratio_initial"])
    model = JointTrainableRoutedHBVLiteUKF(
        params, weights,
        initial_process_diagonal=torch.as_tensor(process_variance, dtype=DTYPE),
        initial_observation_ratio=float(observation_ratio),
        process_noise_bounds=tuple(nc["process_noise_bounds"]),
        observation_ratio_bounds=tuple(nc["observation_ratio_bounds"]),
        clamp_storage=True,
        signed_routing_memory=False,
        dtype=DTYPE, device=DEVICE,
    )
    model._tukf17_readonly_predecessor_root = str(KALMANNET_RO)
    return model


def initial_state(contract: Mapping[str, Any], row: Mapping[str, Any], dim_x: int) -> torch.Tensor:
    x0 = torch.zeros(1, dim_x, dtype=DTYPE)
    x0[0, :5] = torch.tensor(
        [float(row[c]) for c in contract["prior"]["state_columns"]], dtype=DTYPE)
    return x0


def nse(sim: np.ndarray, obs: np.ndarray) -> float:
    return float(1.0 - np.sum((sim - obs) ** 2) / np.sum((obs - obs.mean()) ** 2))


def open_loop_states_and_anchor(
    contract: Mapping[str, Any],
    model: JointTrainableRoutedHBVLiteUKF,
    forcing: np.ndarray,
    x0: torch.Tensor,
    published_nse: float,
    obs: np.ndarray,
) -> tuple[torch.Tensor, dict]:
    """Full-window open-loop replay; enforce the published-NSE anchor gate."""
    with torch.no_grad():
        states = t17.rollout_open_loop_states(model, forcing, x0, forcing.shape[0])
        sim = model.h(states[1:])[:, 0].cpu().numpy()
    reproduced = nse(sim, obs)
    delta = abs(reproduced - published_nse)
    tolerance = float(contract["anchor_gate"]["tolerance"])
    record = {
        "published_nse": float(published_nse),
        "reproduced_nse": reproduced,
        "abs_delta": delta,
        "tolerance": tolerance,
        "passed": bool(delta <= tolerance),
    }
    if not record["passed"]:
        raise RuntimeError(f"anchor gate failed: delta {delta} > {tolerance}")
    return states, record


def state_scales(contract: Mapping[str, Any], open_loop_states: torch.Tensor) -> torch.Tensor:
    """Per-state scales from warmup+train trajectory only (never selection/test)."""
    nc = contract["noise_construction"]
    end = int(contract["segments_day_index"]["train_origins"][1]) + 2
    segment = open_loop_states[:end]
    return torch.clamp(segment.std(dim=0), min=float(nc["state_scale_floor"]))


def constructed_noise(contract: Mapping[str, Any], scales: torch.Tensor) -> dict:
    nc = contract["noise_construction"]
    process_variance = (float(nc["process_std_fraction"]) * scales) ** 2
    covariance = torch.diag_embed((0.001 * scales) ** 2).unsqueeze(0)
    return {
        "scales": scales,
        "process_variance": process_variance,
        "observation_ratio": float(nc["observation_ratio_initial"]),
        "initial_covariance": covariance,
        "base_observation_variance": float(nc["base_observation_variance"]),
    }


def segment_origins(contract: Mapping[str, Any], name: str) -> tuple[int, ...]:
    lo, hi = contract["segments_day_index"][f"{name}_origins"]
    return tuple(range(int(lo), int(hi) + 1))


def exact_sign_test_p(wins: int, replicates: int):
    """One-sided exact sign test, ties counted in n (TUKF20 convention)."""
    frac = t17._binomial_tail_fraction(int(wins), int(replicates))
    return float(frac), [int(frac.numerator), int(frac.denominator)]
