"""TUKF23 per-cell worker: anchor | train | readout stages.

One process handles one basin (anchor) or one (basin, mode) cell.
The train stage never touches the test segment. The readout stage refuses to
run without a sealed checkpoint manifest whose entry matches the checkpoint
it is about to score.

Stages
    anchor   python tukf23_four_mode_worker.py --stage anchor --basin 01047000 --out-root R
    train    python tukf23_four_mode_worker.py --stage train --basin B --mode M --out-root R
    readout  python tukf23_four_mode_worker.py --stage readout --basin B --mode M \
                 --out-root R --train-root R --seal PATH
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch

import tukf23_real_camels_four_mode_common as c23

t17 = c23.t17

torch.set_num_threads(1)


def canonical_snapshot_sha(lists: dict) -> str:
    payload = json.dumps(lists, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode()).hexdigest()


def query_updates(contract: dict) -> tuple[int, ...]:
    step = int(contract["optimizer"]["selection_interval"])
    total = int(contract["optimizer"]["updates"])
    return tuple(range(0, total + 1, step))


def selection_score(contract: dict, model, prep: dict) -> float:
    sel = c23.segment_origins(contract, "selection")
    hi = max(sel) + 4
    with torch.no_grad():
        loss, _ = t17.rolling_origin_objective(
            model, prep["forcing"][:hi], prep["obs"][:hi], prep["x0"],
            prep["noise"]["initial_covariance"], sel,
            state_update=True,
            base_observation_variance=prep["noise"]["base_observation_variance"])
    return float(loss)


def stage_anchor(contract: dict, basin_id: str, out_root: Path) -> dict:
    t0 = time.perf_counter()
    prep = c23.prepare_basin(contract, basin_id)
    record = {
        "stage": "anchor",
        "experiment_id": contract["experiment_id"],
        "basin_id": basin_id,
        "dim_x": prep["dim_x"],
        "anchor_delta": prep["anchor_delta"],
        "published_nse": prep["published_nse"],
        "tolerance": float(contract["anchor_gate"]["tolerance"]),
        "passed": True,
        "residual_std_train": prep["residual_std_train"],
        "mean_flow_train": prep["mean_flow_train"],
        "base_observation_variance": prep["noise"]["base_observation_variance"],
        "environment": c23.environment_stamp(),
        "seconds": time.perf_counter() - t0,
        "ran_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    out = out_root / "anchor" / f"{basin_id}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(record, indent=1))
    return record


def stage_train(contract: dict, basin_id: str, mode: str, out_root: Path) -> dict:
    t0 = time.perf_counter()
    out = out_root / "train" / f"{basin_id}_{mode}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        return json.loads(out.read_text())

    prep = c23.prepare_basin(contract, basin_id)
    model = c23.build_mode_model(contract, prep)
    hyd, fil = c23.mode_groups(contract, model, mode)
    mask = contract["modes"]["masks"][mode]

    seg = contract["segments_day_index"]
    warmup_end = int(seg["warmup"][1]) + 1
    train_origins = c23.segment_origins(contract, "train")
    train_hi = max(train_origins) + 4
    forcing, obs = prep["forcing"], prep["obs"]
    cov0 = prep["noise"]["initial_covariance"]
    base_var = prep["noise"]["base_observation_variance"]

    trainable_groups = []
    if mask["hydrology"]:
        trainable_groups.append(
            {"params": hyd, "lr": float(contract["optimizer"]["hydrology_learning_rate"])})
    if mask["filter"]:
        trainable_groups.append(
            {"params": fil, "lr": float(contract["optimizer"]["filter_learning_rate"])})

    queries = query_updates(contract)
    query_trace: list[list[float]] = []
    train_trace: list[float] = []

    if not trainable_groups:
        # all_frozen: the checkpoint is the construction itself; per the frozen
        # budget it spends no selection queries.
        best = {"score": None, "update": 0, "snap": c23.snapshot(model)}
    else:
        optimizer = torch.optim.Adam(trainable_groups)
        clip = float(contract["optimizer"]["group_gradient_norm"])
        train_forcing = torch.as_tensor(forcing[warmup_end:train_hi])
        train_obs = torch.as_tensor(obs[warmup_end:train_hi])
        shifted_origins = tuple(o - warmup_end for o in train_origins)

        def warm_start():
            with torch.no_grad():
                trace = t17.rollout_state_update_trace(
                    model, forcing[:warmup_end], obs[:warmup_end], prep["x0"], cov0,
                    base_observation_variance=base_var)
                return (trace["posterior_state"][-1].detach().clone(),
                        trace["posterior_covariance"][-1].detach().clone())

        score0 = selection_score(contract, model, prep)
        query_trace.append([0, score0])
        best = {"score": score0, "update": 0, "snap": c23.snapshot(model)}

        for update in range(1, int(contract["optimizer"]["updates"]) + 1):
            optimizer.zero_grad(set_to_none=True)
            warm_state, warm_cov = warm_start()
            loss, _ = t17.rolling_origin_objective(
                model, train_forcing, train_obs, warm_state, warm_cov,
                shifted_origins, state_update=True,
                base_observation_variance=base_var)
            loss.backward()
            if mask["hydrology"]:
                torch.nn.utils.clip_grad_norm_(hyd, clip)
            if mask["filter"]:
                torch.nn.utils.clip_grad_norm_(fil, clip)
            optimizer.step()
            projector = getattr(model, "project_trainable_coordinates_", None)
            if callable(projector):
                projector()
            train_trace.append(float(loss))
            if update in queries:
                score = selection_score(contract, model, prep)
                query_trace.append([update, score])
                if score < best["score"]:  # strict: tie keeps the earlier update
                    best = {"score": score, "update": update, "snap": c23.snapshot(model)}

    c23.restore_(model, best["snap"])
    snap_lists = c23.snapshot_to_lists(best["snap"])
    record = {
        "stage": "train",
        "experiment_id": contract["experiment_id"],
        "basin_id": basin_id,
        "mode": mode,
        "dim_x": prep["dim_x"],
        "anchor_delta": prep["anchor_delta"],
        "residual_std_train": prep["residual_std_train"],
        "mean_flow_train": prep["mean_flow_train"],
        "base_observation_variance": base_var,
        "selected_update": best["update"],
        "selection_score_at_checkpoint": best["score"],
        "selection_query_trace": query_trace,
        "train_loss_trace": train_trace,
        "checkpoint_snapshot": snap_lists,
        "checkpoint_sha256": canonical_snapshot_sha(snap_lists),
        "learned_observation_ratio": float(model.observation_ratio()),
        "learned_process_diagonal": [float(v) for v in model.process_diagonal().reshape(-1)],
        "test_segment_contact": "none",
        "environment": c23.environment_stamp(),
        "seconds": time.perf_counter() - t0,
        "ran_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    out.write_text(json.dumps(record, indent=1))
    return record


def stage_readout(contract: dict, basin_id: str, mode: str, out_root: Path,
                  train_root: Path, seal_path: Path) -> dict:
    t0 = time.perf_counter()
    out = out_root / "readout" / f"{basin_id}_{mode}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        return json.loads(out.read_text())

    seal = json.loads(Path(seal_path).read_text())
    if seal["experiment_id"] != contract["experiment_id"]:
        raise ValueError("seal belongs to a different experiment")
    cell_key = f"{basin_id}_{mode}"
    if cell_key not in seal["cells"]:
        raise ValueError(f"cell {cell_key} is not sealed")

    train_record = json.loads(
        (train_root / "train" / f"{basin_id}_{mode}.json").read_text())
    snap_lists = train_record["checkpoint_snapshot"]
    actual_sha = canonical_snapshot_sha(snap_lists)
    if actual_sha != seal["cells"][cell_key]["checkpoint_sha256"]:
        raise ValueError(f"cell {cell_key}: checkpoint drifted from the seal")

    prep = c23.prepare_basin(contract, basin_id)
    model = c23.build_mode_model(contract, prep)
    c23.restore_(model, c23.snapshot_from_lists(model, snap_lists))

    test_origins = c23.segment_origins(contract, "test")
    with torch.no_grad():
        loss, details = t17.rolling_origin_objective(
            model, prep["forcing"], prep["obs"], prep["x0"],
            prep["noise"]["initial_covariance"], test_origins,
            state_update=True,
            base_observation_variance=prep["noise"]["base_observation_variance"])

    errors = {}
    mse_by_lead = {}
    for lead in c23.LEADS:
        sq = (details["forecasts"][lead] - details["targets"][lead]) ** 2
        errors[f"lead_{lead}"] = sq.cpu().numpy().astype(np.float64)
        mse_by_lead[str(lead)] = float(sq.mean())
    pooled = float(np.mean([mse_by_lead[str(lead)] for lead in c23.LEADS]))
    if not math.isclose(pooled, float(loss), rel_tol=1e-12, abs_tol=0.0):
        raise FloatingPointError("pooled MSE does not reproduce the objective")

    seg = contract["segments_day_index"]
    train_days = prep["obs"][int(seg["train_origins"][0]): int(seg["train_origins"][1]) + 1]
    terciles = np.quantile(train_days, [1 / 3, 2 / 3]).tolist()

    npz_path = out_root / "readout" / f"{basin_id}_{mode}.npz"
    np.savez_compressed(
        npz_path,
        origins=np.asarray(test_origins, dtype=np.int64),
        **errors,
    )

    record = {
        "stage": "readout",
        "experiment_id": contract["experiment_id"],
        "basin_id": basin_id,
        "mode": mode,
        "dim_x": prep["dim_x"],
        "anchor_delta": prep["anchor_delta"],
        "selected_update": train_record["selected_update"],
        "checkpoint_sha256": actual_sha,
        "seal_sha256": seal["seal_sha256"],
        "test_pooled_mse": pooled,
        "test_mse_by_lead": mse_by_lead,
        "test_origin_count": len(test_origins),
        "flow_tercile_thresholds": terciles,
        "tercile_threshold_source": "train-origin-day observed discharge, quantiles 1/3 and 2/3",
        "errors_npz": npz_path.name,
        "errors_npz_sha256": c23.sha256_file(npz_path),
        "observation_ratio_at_checkpoint": float(model.observation_ratio()),
        "process_diagonal_at_checkpoint": [float(v) for v in model.process_diagonal().reshape(-1)],
        "environment": c23.environment_stamp(),
        "seconds": time.perf_counter() - t0,
        "ran_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    out.write_text(json.dumps(record, indent=1))
    return record


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", required=True, choices=["anchor", "train", "readout"])
    ap.add_argument("--basin", required=True)
    ap.add_argument("--mode", default=None, choices=list(c23.MODES))
    ap.add_argument("--config", default=str(c23.DEFAULT_CONFIG))
    ap.add_argument("--out-root", required=True)
    ap.add_argument("--train-root", default=None)
    ap.add_argument("--seal", default=None)
    ap.add_argument("--no-verify-hashes", action="store_true",
                    help="engineering smoke only; formal runs always verify")
    a = ap.parse_args()

    contract = c23.load_contract(a.config, verify_hashes=not a.no_verify_hashes)
    out_root = Path(a.out_root)

    if a.stage == "anchor":
        record = stage_anchor(contract, a.basin, out_root)
        print(json.dumps({k: record[k] for k in
                          ("basin_id", "anchor_delta", "passed", "seconds")}))
        return 0
    if a.mode is None:
        raise SystemExit("--mode is required for train/readout")
    if a.stage == "train":
        record = stage_train(contract, a.basin, a.mode, out_root)
        print(json.dumps({k: record[k] for k in
                          ("basin_id", "mode", "selected_update",
                           "selection_score_at_checkpoint", "seconds")}))
        return 0
    if not a.train_root or not a.seal:
        raise SystemExit("--train-root and --seal are required for readout")
    record = stage_readout(contract, a.basin, a.mode, out_root,
                           Path(a.train_root), Path(a.seal))
    print(json.dumps({k: record[k] for k in
                      ("basin_id", "mode", "test_pooled_mse", "seconds")}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
