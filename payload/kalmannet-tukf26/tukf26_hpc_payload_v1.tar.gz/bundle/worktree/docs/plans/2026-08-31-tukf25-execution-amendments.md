# TUKF25 执行修正案（2026-08-31，随冻结 config 一同散列）

本文档记录 TUKF25 在合同草案（`docs/plans/2026-08-31-tukf25-reversed-split-formal-contract-draft.md`）
批准之后、config 冻结之前的三项执行层修正与两项披露。**合同草案的科学内容
（第一节假设、第三节切分几何、第四节四臂与配方、第五节门与判读预案、第七节红线）
一字不动，继续具有约束力。** 草案原文件保持只读，不回写。

## 修正一：执行平台 本地 6 工位 → HPC（用户 2026-08-31 拍板覆盖）

- 草案第六节与第八节第 3 项原拍板为「本地 6 工位 CPU 舰队过夜；不上 HPC」。
- 2026-08-31 首查实测：本机被 P01 学习率边界实验（WRR-HLRB-20260831，
  PID 28240/47076，2026-08-31 11:33 启动）占用——GPU 12GB 占满、进程私有提交内存
  21.1 GB、系统可用物理内存仅 2.5 GB，预计还需 1 天到约 12 天。
  本地 6 工位过夜的前提（空机实测 9.0 小时）不再成立。
- 用户决定（当日对话，先答「TO HPC」，后授权「go …… 不需要跟我确认了……跑起来为止」）：
  **改在 HPC 执行，且授权提交作业、执行到跑通为止。**
- HPC 执行完全照抄 TUKF24 步骤二的成熟链：分区 `hcpu48y`、独立落点
  `/data1/home/sunyiq/kalmannet_tukf25_20260831`、信箱 channel `kalmannet-tukf25`、
  bundle 字节级封运 + frozen-pin 自检、锚点门 27/27 → 训练阵列 108 → 本地建封条 →
  单次开封读出阵列 108 → 取回 → 本地独立验证器判读。
  实测依据：TUKF24 同族 108 训练格在 hcpu48y 单格中位 32.6 分钟（本地 29.8 分钟），
  数值环境差异由锚点门按 TUKF23 config `numerical_environment.cross_platform_rule`
  验收（容差 1e-6 不放宽）。
- 不碰既有实验：不 scancel 任何作业、不进 `~/neuralhydrology`、不写任何已存在目录。

## 修正二：抽签算法勘误（草案括号注解与 TUKF21 实现不符）

- 草案第二节写「算法与 TUKF21 相同（sorted pool + seeded shuffle 取前 27）」。
  括号内的 shuffle 描述**错误**。
- TUKF21 实际实现（`scripts/tukf21_real_camels_basin_screening.py:163`）与登记册
  `preregistered.draw_rule` 字段均为：
  `sorted(random.Random(seed).sample(sorted_eligible, 27))`。
- 2026-08-31 实测：`sample` 精确复现登记册封存的 27 个流域（集合一致）；
  `shuffle 取前 27` 连集合都不一致。
- **TUKF25 采用主句「算法与 TUKF21 相同」**：
  `fresh = sorted(random.Random(20260831).sample(sorted(set(eligible) - set(old27)), 27))`。
  种子 20260831 为用户已拍板项，不变。

## 修正三：交接文档探针日期笔误（记账，不影响任何数字）

- 交接文档第四节写探针「实耗 9.0 小时（13:11–22:05 本地 6 工位）」并在第七节写
  「已于 08-31 22:05 结束」。存档 107+108 个 json 的 `ran_at_utc` 实测为
  2026-08-**28** 05:11–14:05 UTC（北京时间 08-28 13:11–22:05）。
  时长与时刻正确，日期是笔误；探针存档于 08-31 13:08 拷入 `results/`。

## 披露一：反向噪声统计窗与封存段的 350 天重叠（探针管线固有，正式实验原样继承）

- 探针脚本 docstring 声称后缀统计窗「不触及反向测试年份」。**算术上不成立**：
  统计窗为 day index [2189, 3652)（1463 天），而封存测试段目标日为 [731, 2538]，
  重叠 [2189, 2538] 共 **350 天**。另注：正向冻结窗代码切片 `[:1462]` 实为 1462 天，
  探针后缀窗 1463 天，相差 1 天。
- 该窗只产出两个标量（开环残差标准差、平均流量）用于构造噪声底座，
  四臂**共用同一构造**，无梯度、无任何测试目标评分经过此窗。
  与锚点门全窗开环 NSE（TUKF23/24 正向正式实验既有先例，同样经过封存年份）及
  反向切分固有的无梯度暖启动穿越（Kratzert 2019 同类）同属一类披露性接触。
- **TUKF25 正式实验原样继承探针统计窗 [2189, 3652)**，理由：本实验检验的假设
  产自探针管线，改窗即改配方，G1 无论过否都无法归因。重叠事实写入 config
  `noise_construction_override.disclosure` 字段，对外表述必须连带此披露。

## 披露二：训练成功前置门的执行位置

- 交接第三节的铁律门（joint 或 filter_only 有 >1/3 流域 selected_update=0 则判读中止）
  由**独立验证器在开封判读之前**执行：不满足则只写 `training_diagnosis_required.json`、
  不产出任何判决文件。写入 config `gates.training_success_precondition`。

## 与本修正案同时冻结的文件

`configs/tukf25_reversed_split_fresh_basins_v1.json` 的 `frozen_input_sha256`
散列清单包含本文档；config 建成后本文档只读。
