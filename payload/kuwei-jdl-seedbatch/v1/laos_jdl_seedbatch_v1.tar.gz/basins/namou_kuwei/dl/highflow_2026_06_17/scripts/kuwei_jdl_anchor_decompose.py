"""Decompose the anchor-gate discrepancy between two machines.

The anchor gate compares, on ONE machine, the torch mirror against the read-only authority.
It is 0.0 on the Windows workstation and up to 3.60e-2 on the cluster. That single number
cannot say WHICH side moved. This script saves both series so the question can be answered:

    mirror_here   vs mirror_there     -> did the PyTorch side move?
    authority_here vs authority_there -> did the NumPy side move?
    mirror_here   vs authority_here   -> reproduces this machine's anchor-gate number

Usage:
    python kuwei_jdl_anchor_decompose.py --out DIR                  # save this machine's series
    python kuwei_jdl_anchor_decompose.py --out DIR --reference DIR  # save and compare

Writes only into --out. Never touches the experiment family directory.
"""
from __future__ import annotations

import argparse
import json
import platform
from pathlib import Path

import numpy as np
import torch

import kuwei_joint_da_learning as jdl
from kuwei_joint_da_learning import mirror

STATE_ORDER = ("snow_depth", "ice_depth", "last_temp", "W", "WU", "WL", "WD", "S",
               "QS", "QI", "QG")


def both_series(config, forcing, authority, rain, pet, temp, replicate):
    """Return (mirror_series, authority_series) exactly as gate_anchor computes them."""
    start, frozen = jdl.load_start_parameters(jdl.map_path(replicate["start_params"]["path"]))
    configuration = jdl.LearnableConfiguration(start, frozen, False, False)
    xaj, c0, c1, c2 = configuration.xaj()
    musk = mirror.MuskingumParameters(c0=c0, c1=c1, c2=c2,
                                      n_sub=torch.tensor([1], dtype=torch.int64))
    base = {name: 0.0 for name in STATE_ORDER}
    base.update(jdl.XAJ_INITIAL)
    state11 = torch.tensor([[base[name] for name in STATE_ORDER]], dtype=jdl.FLOAT)
    zeros = torch.zeros(len(forcing.index), dtype=jdl.FLOAT)
    with torch.no_grad():
        sequence = mirror.run_lumped_sequence(
            rain_mm=forcing.rain, pet_mm=forcing.pet, temp_c=forcing.temp, snow_mm=zeros,
            xaj=xaj, muskingum=musk, initial_state=state11)
    reference = mirror._run_read_only_sequence(authority, rain, pet, temp, xaj, musk, state11)
    return (np.asarray(sequence.q_outlet.numpy(), dtype=np.float64),
            np.asarray(reference, dtype=np.float64))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True)
    parser.add_argument("--reference", default=None)
    arguments = parser.parse_args()
    out = Path(arguments.out)
    out.mkdir(parents=True, exist_ok=True)

    config = jdl.load_config()
    forcing = jdl.load_forcing(config)
    core = (jdl.map_path(config["repository_contract"]["read_only"][0])
            / "src" / "kernels" / "semi_distributed" / "core" / "hydromod_numba.py")
    authority = mirror._load_read_only_authority(core)
    rain = forcing.rain.numpy().astype(np.float32)
    pet = forcing.pet.numpy().astype(np.float32)
    temp = forcing.temp.numpy().astype(np.float32)

    report = {
        "machine": {"platform": platform.platform(), "torch": torch.__version__,
                    "numpy": np.__version__},
        "hours": int(len(forcing.index)),
        "replicates": {},
    }
    reference_dir = Path(arguments.reference) if arguments.reference else None

    for replicate in config["replicates"]:
        seed = int(replicate["seed"])
        mirror_series, authority_series = both_series(
            config, forcing, authority, rain, pet, temp, replicate)
        np.save(out / f"mirror_{seed}.npy", mirror_series)
        np.save(out / f"authority_{seed}.npy", authority_series)
        entry = {
            "anchor_gate_here_mirror_vs_authority":
                float(np.max(np.abs(mirror_series - authority_series))),
        }
        if reference_dir is not None:
            reference_mirror = np.load(reference_dir / f"mirror_{seed}.npy")
            reference_authority = np.load(reference_dir / f"authority_{seed}.npy")
            mirror_shift = float(np.max(np.abs(mirror_series - reference_mirror)))
            authority_shift = float(np.max(np.abs(authority_series - reference_authority)))
            entry.update({
                "mirror_here_vs_mirror_reference": mirror_shift,
                "authority_here_vs_authority_reference": authority_shift,
                "anchor_gate_reference_mirror_vs_authority":
                    float(np.max(np.abs(reference_mirror - reference_authority))),
                "which_side_moved": (
                    "neither" if max(mirror_shift, authority_shift) <= 1e-6 else
                    "mirror (torch)" if mirror_shift > 10 * max(authority_shift, 1e-30) else
                    "authority (numpy)" if authority_shift > 10 * max(mirror_shift, 1e-30) else
                    "both"),
            })
        report["replicates"][str(seed)] = entry
        print(json.dumps({str(seed): entry}, indent=2), flush=True)

    (out / "anchor_decomposition.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
