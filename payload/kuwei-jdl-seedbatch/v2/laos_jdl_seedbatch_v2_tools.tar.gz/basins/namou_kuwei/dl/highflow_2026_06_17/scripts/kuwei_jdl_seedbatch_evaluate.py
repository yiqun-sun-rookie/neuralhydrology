"""Evaluate the stage-1 learning-seed batch on 2023 and apply the registered criterion.

Runs in the SAME environment that trained the checkpoints, so the ratios have a baseline from
that environment (the preregistration requires the batch to carry its own all_frozen baseline).

Criterion registered before any batch run started, in
docs/experiments/kuwei_jdl_seedbatch_20260831/PREREGISTRATION.md
sha256 462e8452e6e57774d843f2bc27d9f9d04b8d7b8db54d88cd7fbc461b7b4b4b8b:

    spread of the hydro_only 2023 ratio across learning seeds 0..4
        < 0.05   -> learning-seed noise small; the remaining 27 runs are justified
        >= 0.10  -> learning-seed noise large; the line is closed
        between  -> inconclusive, reported as such

Writes one file: <output root>/seedbatch_stage1_2023.json
"""
from __future__ import annotations

import json
from datetime import datetime, timezone

import numpy as np
import torch

import kuwei_joint_da_learning as jdl

START_SEED = 20260826
LEARNING_SEEDS = (0, 1, 2, 3, 4)
LEARNING_ARMS = ("hydro_only", "joint", "noise_only")


def run_directory(arm: str, learning_seed: int):
    suffix = f"_ls{learning_seed}" if learning_seed else ""
    return jdl.OUTPUT_ROOT / "runs" / f"{arm}_seed{START_SEED}{suffix}"


def evaluate(config, forcing, full_end, arm: str, learning_seed: int) -> dict:
    directory = run_directory(arm, learning_seed)
    if not (directory / "checkpoint.pt").exists():
        raise FileNotFoundError(directory / "checkpoint.pt")
    replicate = next(r for r in config["replicates"] if int(r["seed"]) == START_SEED)
    start, frozen = jdl.load_start_parameters(jdl.map_path(replicate["start_params"]["path"]))
    learn_hydro, learn_noise = jdl.ARMS[arm]
    configuration = jdl.LearnableConfiguration(start, frozen, learn_hydro, learn_noise)
    configuration.load_state_dict(torch.load(directory / "checkpoint.pt", weights_only=True))
    evaluation = jdl.evaluate_origins(configuration, forcing, jdl.TEST_ORIGINS, full_end)
    np.save(directory / "test_predictions.npy", evaluation["predictions"])
    np.save(directory / "test_origins.npy", evaluation["scored_origins"])
    return {"combined_mse": evaluation["combined_mse"],
            "per_lead": evaluation["per_lead"],
            "n_scored_origins": evaluation["n_scored_origins"]}


def main() -> None:
    config = jdl.load_config()
    forcing = jdl.load_forcing(config)
    full_end = jdl.hour_index(jdl.FULL_END)

    baseline = evaluate(config, forcing, full_end, "all_frozen", 0)
    base_mse = baseline["combined_mse"]
    print(f"[baseline] all_frozen mse={base_mse:.4f} "
          f"nse24={baseline['per_lead']['24']['nse']:.4f}", flush=True)

    results = {"all_frozen|ls0": baseline}
    ratios: dict[str, dict[str, float]] = {arm: {} for arm in LEARNING_ARMS}
    for arm in LEARNING_ARMS:
        for learning_seed in LEARNING_SEEDS:
            record = evaluate(config, forcing, full_end, arm, learning_seed)
            key = f"{arm}|ls{learning_seed}"
            results[key] = record
            ratios[arm][str(learning_seed)] = record["combined_mse"] / base_mse
            print(f"[stage1] {key}: mse={record['combined_mse']:.4f} "
                  f"ratio={ratios[arm][str(learning_seed)]:.4f} "
                  f"nse24={record['per_lead']['24']['nse']:.4f}", flush=True)

    summary = {}
    for arm in LEARNING_ARMS:
        values = [ratios[arm][str(s)] for s in LEARNING_SEEDS]
        summary[arm] = {
            "ratios_by_learning_seed": ratios[arm],
            "spread_max_minus_min": float(max(values) - min(values)),
            "median": float(np.median(values)),
            "min": float(min(values)),
            "max": float(max(values)),
        }

    spread = summary["hydro_only"]["spread_max_minus_min"]
    if spread < 0.05:
        verdict = "LEARNING_SEED_NOISE_SMALL__REMAINING_27_RUNS_JUSTIFIED"
    elif spread >= 0.10:
        verdict = "LEARNING_SEED_NOISE_LARGE__LINE_CLOSED"
    else:
        verdict = "INCONCLUSIVE"

    payload = {
        "study": "kuwei_jdl_seedbatch_20260831_stage1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "preregistration_sha256":
            "462e8452e6e57774d843f2bc27d9f9d04b8d7b8db54d88cd7fbc461b7b4b4b8b",
        "start_replicate": START_SEED,
        "learning_seeds": list(LEARNING_SEEDS),
        "environment": {"torch": torch.__version__, "numpy": np.__version__},
        "baseline_all_frozen_combined_mse": base_mse,
        "results": results,
        "summary": summary,
        "registered_primary_readout_hydro_only_spread": spread,
        "verdict": verdict,
        "scope": "Self-contained stability study in the cluster environment. The phase-0 anchor "
                 "gate does NOT pass here (0.000427 for this start replicate, threshold 1e-6) and "
                 "is not relaxed; these numbers therefore speak only to learning-seed stability, "
                 "never to absolute model skill, and must not be placed alongside the 18 "
                 "workstation runs as if directly comparable. Future rainfall is post-event "
                 "observed, so nothing here is a forecast-skill claim.",
    }
    path = jdl.OUTPUT_ROOT / "seedbatch_stage1_2023.json"
    jdl.write_json(path, payload)
    print(json.dumps({"verdict": verdict,
                      "hydro_only_spread": spread,
                      "hydro_only_median": summary["hydro_only"]["median"],
                      "joint_spread": summary["joint"]["spread_max_minus_min"],
                      "noise_only_spread": summary["noise_only"]["spread_max_minus_min"]},
                     indent=2))


if __name__ == "__main__":
    main()
