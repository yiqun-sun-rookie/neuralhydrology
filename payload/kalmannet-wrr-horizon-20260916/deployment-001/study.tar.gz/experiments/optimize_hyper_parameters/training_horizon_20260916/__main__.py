"""Default action is a read-only check; training requires an explicit command."""
import argparse
import json

from .protocol import ContractError, inspect_configuration


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    check = commands.add_parser("check", help="Check configuration/source hashes without loading data or models")
    check.add_argument("--check-data-hashes", action="store_true")
    train = commands.add_parser("train-pair", help="Execute a newly authorized pair, with no test evaluation")
    train.add_argument("--seed", required=True, type=int, choices=(42, 43, 44))
    train.add_argument("--execute", action="store_true")
    train.add_argument("--authorization-note", default="")
    args = parser.parse_args(argv)
    if args.command == "check":
        result = inspect_configuration(args.check_data_hashes)
    else:
        if not args.execute or not args.authorization_note.strip():
            parser.error("Training requires --execute and a nonempty --authorization-note")
        # Do not even import the numerical runtime in check mode or on rejection.
        from .runner import execute_pair
        result = execute_pair(args.seed, args.authorization_note)
    print(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
