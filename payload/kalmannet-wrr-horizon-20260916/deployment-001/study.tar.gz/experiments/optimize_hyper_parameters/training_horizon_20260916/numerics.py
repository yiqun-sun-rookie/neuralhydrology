"""Native model adapters. Existing scientific source files remain unchanged."""
from __future__ import annotations

from types import SimpleNamespace

import torch

from knet.dl.nn_kalman_clamp_5 import KalmanNet
from knet.modules.pipeline.core_fun import forward_sequence, system_model_forecast
from knet.modules.utils.metrics import composite_loss
from knet.utils.model_initialization_use_script_mdl_1 import initialize_system_model

from .protocol import ContractError


def make_pipeline(common: dict, device: str | None = None):
    """Use the original initialization and network, without the old train/test wrapper."""
    device = device or common["runtime"]["device"]
    config = common["model"]
    args = SimpleNamespace(
        device=device, n_batch=common["loader"]["batch_size"],
        d_hidden_Q=config["hidden_size"], d_hidden_Sigma=config["hidden_size"],
        num_layers_GRU_Q=config["num_layers"], num_layers_GRU_Sigma=config["num_layers"],
        num_layers_GRU_S=config["num_layers"], dropout_prob=config["dropout"],
        in_mult_KNet=config["in_mult"], out_mult_KNet=config["out_mult"],
        activation_function=config["activation"], state_bounds=config["state_bounds"],
        window_size=common["window_size"],
    )
    system = initialize_system_model(common["window_size"], common["window_size"], device)
    model = KalmanNet()
    model.debug_enabled = False
    model.enable_clamp_scale = True
    model.clamp_scale_info = {
        key: torch.tensor(value, dtype=torch.float32, device=device)
        for key, value in config["clamp_scale"].items() if key != "enable"
    }
    model.build_nn(system, args)
    model.to(device)
    return SimpleNamespace(args=args, sys_model=system, knet_model=model)


def aligned_forecast(system, precipitation, evaporation, states, horizon: int, common_horizon: int = 25):
    """Keep the native operation order, retaining only the common origin set.

    For T=800, H=12 we supply 787 slots to the native forecaster. It then
    generates exactly 776 origins, matching H=25 supplied with all 800 slots.
    The assimilation pass itself still covers all 800 slots in both arms.
    """
    length = precipitation.shape[-1]
    if not 1 <= horizon <= common_horizon <= length:
        raise ContractError("Invalid forecast horizon or sequence length")
    origins = length - common_horizon + 1
    needed = origins + horizon - 1
    _, prediction = system_model_forecast(
        system, precipitation[..., :needed], evaporation[..., :needed],
        states[..., :needed], lead_time=horizon,
    )
    return prediction.reshape(precipitation.shape[0], origins, horizon)


def aligned_observations(observations, horizon: int, common_horizon: int = 25):
    length = observations.shape[-1]
    if observations.ndim != 3 or observations.shape[1] != 1 or not 1 <= horizon <= common_horizon <= length:
        raise ContractError("Invalid observation shape or horizon")
    origins = length - common_horizon + 1
    return observations[:, 0].unfold(-1, horizon, 1)[:, :origins, :]


def horizon_loss(prediction, observation, updated_output, observations, loss_horizon, loss_config):
    origins = prediction.shape[1]
    if prediction.shape != observation.shape or prediction.shape[-1] < loss_horizon:
        raise ContractError("Forecast/observation alignment mismatch")
    return composite_loss(
        outputs_fc=prediction[..., :loss_horizon].reshape(-1, loss_horizon),
        y_future=observation[..., :loss_horizon].reshape(-1, loss_horizon),
        outputs_upd=updated_output[:, 0, :origins].reshape(-1),
        y_now=observations[:, 0, :origins].reshape(-1),
        **loss_config,
    )[0]


def compute_batch(pipeline, batch: dict, loss_config: dict, horizon: int, common_horizon: int = 25, validation: bool = False):
    tensors = {key: batch[key].to(pipeline.args.device) for key in ("p", "etpot", "qobs", "state0")}
    observations = tensors["qobs"]
    b, _, t = observations.shape
    if t != pipeline.args.window_size or any(not torch.isfinite(value).all() for value in tensors.values()):
        raise ContractError("Invalid batch length or non-finite input")
    for key in ("p", "etpot", "qobs"):
        if tensors[key].shape != (b, 1, t):
            raise ContractError(f"Invalid {key} shape")
    if tensors["state0"].shape != (b, pipeline.sys_model.m, t):
        raise ContractError("Invalid initial-state shape")
    model = pipeline.knet_model
    model.batch_size = b
    model.init_hidden_KNet()
    model.update_mode = True
    model.init_sequence(tensors["state0"][:, :, 0], t)
    controls = torch.cat((tensors["p"], tensors["etpot"]), dim=1)
    states, updated = forward_sequence(pipeline, observations, controls)
    forecast_horizon = common_horizon if validation else horizon
    prediction = aligned_forecast(
        pipeline.sys_model, tensors["p"], tensors["etpot"], states, forecast_horizon, common_horizon,
    )
    target = aligned_observations(observations, forecast_horizon, common_horizon)
    loss = horizon_loss(prediction, target, updated, observations, horizon, loss_config)
    if not torch.isfinite(loss):
        raise ContractError("Non-finite loss; no rollback or automatic retry is permitted")
    return loss, prediction, target


def optimizer_step(model, optimizer, loss, clipping: dict) -> float:
    """Retain legacy norm clipping followed by per-parameter relative clipping."""
    optimizer.zero_grad()
    loss.backward()
    norm = torch.nn.utils.clip_grad_norm_(
        model.parameters(), max_norm=clipping["norm"], error_if_nonfinite=True,
    )
    if not torch.isfinite(norm) or norm > clipping["abort_norm"]:
        raise ContractError(f"Invalid gradient norm {float(norm)}")
    for group in optimizer.param_groups:
        rate = group["lr"]
        for parameter in group["params"]:
            if parameter.grad is not None:
                mean_weight = parameter.data.abs().mean().clamp(min=1e-8)
                limit = (clipping["relative"] * mean_weight) / rate
                parameter.grad.data.clamp_(-limit, limit)
    optimizer.step()
    if any(not torch.isfinite(parameter).all() for parameter in model.parameters()):
        raise ContractError("Non-finite parameter after optimizer step")
    return float(norm)
