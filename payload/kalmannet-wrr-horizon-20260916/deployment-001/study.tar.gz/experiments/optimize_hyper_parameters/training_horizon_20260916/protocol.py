"""Read-only configuration checks. Importing this module never loads PyTorch."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
CONFIG_DIR = Path(__file__).with_name("configs")
FAMILY = "training-horizon-common-origins-v2"


class ContractError(ValueError):
    """A frozen comparison contract was not satisfied."""


def file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def object_hash(value: object) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False).encode()
    return hashlib.sha256(raw).hexdigest()


def read_json(path: Path) -> dict:
    with path.open(encoding="utf-8") as stream:
        value = json.load(stream)
    if not isinstance(value, dict):
        raise ContractError(f"Expected a mapping: {path}")
    return value


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ContractError(message)


def checked_output(relative: str, root: Path = ROOT) -> Path:
    base = (root / "artifacts" / "training_horizon_common_origins_v2").resolve()
    target = (root / relative).resolve()
    require(target.is_relative_to(base) and target != base, "Output outside experiment root")
    return target


def load_run(path: Path) -> dict:
    path = path.resolve()
    run = read_json(path)
    expected_keys = {
        "experiment_id", "family", "role", "seed", "training_output_positions",
        "common_config", "output_directory", "status",
    }
    require(set(run) == expected_keys, "Unexpected run keys or missing run fields")
    require(run["family"] == FAMILY, "Wrong experiment family")
    require(run["status"] == "PLANNED_NOT_RUN", "Input manifests must remain immutable plans")
    require(type(run["seed"]) is int and run["seed"] in (42, 43, 44), "Unregistered seed")
    require(type(run["training_output_positions"]) is int and run["training_output_positions"] in (12, 25), "Unregistered horizon")
    common_path = (path.parent / run["common_config"]).resolve()
    require(common_path.parent == path.parent, "Common configuration must be adjacent")
    common = read_json(common_path)
    validate_common(common)
    checked_output(run["output_directory"])
    expected_id = f"COMMON-ORIGINS-V2-OUTPUT{run['training_output_positions']}-SEED{run['seed']}"
    require(run["experiment_id"] == expected_id, "Experiment identity does not match its factors")
    return {"run": run, "common": common, "run_path": str(path), "common_path": str(common_path)}


def validate_common(common: dict) -> None:
    require(set(common) == {
        "schema_version", "family", "window_size", "common_output_positions", "data",
        "model", "loss", "optimizer", "scheduler", "gradient_clipping", "budget",
        "loader", "runtime", "selection",
    }, "Unexpected common configuration keys")
    require(common["family"] == FAMILY and common["schema_version"] == 2, "Wrong common protocol")
    require(set(common["data"]) == {"train", "validation"}, "Only train and validation datasets are accepted")
    require(common["window_size"] == 800 and common["common_output_positions"] == 25, "Origin contract changed")
    require(common["budget"] == {"epochs": 50, "performance_early_stopping": False}, "Budget changed")
    require(common["loader"] == {"batch_size": 2048, "num_workers": 0, "pin_memory": False, "drop_last": False}, "Loader contract changed")
    require(common["runtime"]["device"] == "cuda", "Production device must be CUDA")
    require(common["runtime"]["deterministic_algorithms"] is True, "Determinism disabled")
    require(common["model"]["clamp_scale"]["enable"] is True, "Clamping disabled")
    require(common["selection"]["future_leads"] == list(range(1, 25)), "Common selection leads changed")
    require(common["selection"]["tie_tolerance"] == 1e-12, "Selection tie rule changed")
    for split, item in common["data"].items():
        require(set(item) == {"path", "sha256", "items", "bytes"}, f"Invalid {split} data specification")
        require("test" not in Path(item["path"]).name.lower(), "Test data path rejected")


def load_pair(first: Path, second: Path) -> tuple[dict, dict]:
    specs = sorted((load_run(first), load_run(second)), key=lambda s: s["run"]["training_output_positions"])
    a, b = specs
    require([s["run"]["training_output_positions"] for s in specs] == [12, 25], "A pair requires horizons 12 and 25")
    require(a["run"]["seed"] == b["run"]["seed"], "Paired seeds differ")
    require(a["common"] == b["common"], "Paired common configurations differ")
    require(a["run"]["role"] == b["run"]["role"], "Paired roles differ")
    require(checked_output(a["run"]["output_directory"]) != checked_output(b["run"]["output_directory"]), "Output collision")
    return a, b


def check_sources(manifest_path: Path = CONFIG_DIR / "source_manifest.json") -> dict:
    manifest = read_json(manifest_path)
    require(manifest["family"] == FAMILY, "Wrong source manifest")
    for relative, expected in manifest["files"].items():
        path = (ROOT / relative).resolve()
        require(path.is_relative_to(ROOT), "Source path escapes workspace")
        require(file_hash(path) == expected, f"Source or configuration hash mismatch: {relative}")
    return {"manifest_sha256": file_hash(manifest_path), "files_checked": len(manifest["files"])}


def check_data(common: dict) -> dict:
    receipt = {}
    for split, item in common["data"].items():
        path = Path(item["path"])
        require(path.stat().st_size == item["bytes"], f"Data size mismatch: {split}")
        digest = file_hash(path)
        require(digest == item["sha256"], f"Data hash mismatch: {split}")
        receipt[split] = {"sha256": digest, "bytes": path.stat().st_size}
    return receipt


def inspect_configuration(check_dataset_files: bool = False) -> dict:
    sources = check_sources()
    paths = sorted(CONFIG_DIR.glob("run_*.json"))
    require(len(paths) == 6, "Expected six registered run configurations")
    for seed in (42, 43, 44):
        load_pair(CONFIG_DIR / f"run_output12_seed{seed}.json", CONFIG_DIR / f"run_output25_seed{seed}.json")
    common = load_run(paths[0])["common"]
    registry = read_json(CONFIG_DIR / "registry.json")["experiments"]
    expected = [load_run(path)["run"] for path in paths]
    require(registry == expected, "Registry and individual run configurations differ")
    return {
        "status": "PREPARATION_CHECK_PASSED", "scientific_experiments": "NOT_RUN",
        "sources": sources, "configurations": len(paths), "common_origins": 776,
        "data_hashes": check_data(common) if check_dataset_files else "NOT_CHECKED",
        "data_deserialized": False, "model_constructed": False,
    }
