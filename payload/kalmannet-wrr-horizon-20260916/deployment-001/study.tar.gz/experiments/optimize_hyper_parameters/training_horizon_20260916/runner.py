"""Pair execution. This module is imported only after an explicit execution flag."""
from __future__ import annotations

import gc
import math
import shutil
import subprocess
import time
import traceback
from pathlib import Path

import torch
from torch.utils.data import DataLoader

from .metrics import LeadStatistics, budget_limited, choose_epoch
from .numerics import compute_batch, make_pipeline, optimizer_step
from .protocol import (
    CONFIG_DIR, ROOT, ContractError, check_data, check_sources, checked_output,
    file_hash, load_pair, object_hash, read_json, require,
)
from .runtime import (
    configure_determinism, environment_receipt, epoch_order, load_dataset,
    parameter_hash, rng_snapshot, seed_all, write_json,
)


def run_epoch(pipeline, loader, common, horizon, optimizer=None) -> dict:
    training = optimizer is not None
    pipeline.knet_model.train(training)
    statistics = None if training else LeadStatistics()
    weighted_loss = 0.0
    windows = batches = 0
    maximum_norm = 0.0
    with torch.set_grad_enabled(training):
        for batch in loader:
            loss, prediction, target = compute_batch(
                pipeline, batch, common["loss"], horizon,
                common_horizon=common["common_output_positions"], validation=not training,
            )
            if training:
                norm = optimizer_step(pipeline.knet_model, optimizer, loss, common["gradient_clipping"])
                maximum_norm = max(maximum_norm, norm)
            else:
                statistics.update(prediction.detach().cpu().numpy(), target.detach().cpu().numpy())
            count = batch["qobs"].shape[0]
            weighted_loss += float(loss.detach()) * count
            windows += count
            batches += 1
            del loss, prediction, target
    require(windows == len(loader.dataset) and batches == len(loader), "A batch or window was skipped")
    result = {"objective": weighted_loss / windows, "windows": windows, "batches": batches}
    if training:
        result["maximum_raw_gradient_norm"] = maximum_norm
    else:
        result.update(statistics.result())
    return result


def train_arm(spec, datasets, initial_hash, expected_orders, environment, pair_path):
    run, common = spec["run"], spec["common"]
    seed, horizon, device = run["seed"], run["training_output_positions"], common["runtime"]["device"]
    output = checked_output(run["output_directory"])
    output.mkdir(exist_ok=False)
    state = {"experiment_id": run["experiment_id"], "status": "RUNNING", "completed_epochs": 0}
    write_json(output / "status.json", state)
    try:
        require(environment_receipt(device) == environment, "Runtime changed between paired arms")
        seed_all(seed, device)
        pipeline = make_pipeline(common)
        require(parameter_hash(pipeline.knet_model) == initial_hash, "Initial parameters changed before training")
        write_json(output / "resolved_config.json", {"run": run, "common": common})
        optimizer = torch.optim.AdamW(
            pipeline.knet_model.parameters(), lr=common["optimizer"]["learning_rate"],
            weight_decay=common["optimizer"]["weight_decay"],
            betas=tuple(common["optimizer"]["betas"]), eps=common["optimizer"]["eps"],
            amsgrad=common["optimizer"]["amsgrad"],
        )
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, **common["scheduler"])
        scores, records = [], []
        started = time.perf_counter()
        if device == "cuda":
            torch.cuda.reset_peak_memory_stats()
        for epoch in range(common["budget"]["epochs"]):
            tick = time.perf_counter()
            order, order_hash, sampler_state = epoch_order(len(datasets["train"]), seed, epoch)
            require(order_hash == expected_orders[epoch], "Training sample order changed")
            # DataLoader consumes a base seed even with no workers. Dedicated
            # generators prevent validation from perturbing the training RNG.
            train_generator = torch.Generator().manual_seed(seed + 2_000_003 + epoch)
            validation_generator = torch.Generator().manual_seed(seed + 3_000_017 + epoch)
            train_loader = DataLoader(datasets["train"], sampler=order, generator=train_generator, **common["loader"])
            validation_loader = DataLoader(datasets["validation"], shuffle=False, generator=validation_generator, **common["loader"])
            rate_before = optimizer.param_groups[0]["lr"]
            training = run_epoch(pipeline, train_loader, common, horizon, optimizer)
            validation = run_epoch(pipeline, validation_loader, common, horizon)
            scheduler.step(validation["objective"])
            score = validation["mean_nse_future_1_24"]
            scores.append(score)
            if device == "cuda":
                torch.cuda.synchronize()
            checkpoint = output / f"epoch_{epoch + 1:03d}.pt"
            torch.save({
                "epoch": epoch + 1, "model_state_dict": pipeline.knet_model.state_dict(),
                "optimizer_state_dict": optimizer.state_dict(), "scheduler": scheduler.state_dict(),
                "rng": rng_snapshot(device), "sampler_state": sampler_state,
                "sampler_order_sha256": order_hash, "initial_parameters_sha256": initial_hash,
                "loader_generator_states": {"train": train_generator.get_state(), "validation": validation_generator.get_state()},
                "configuration_sha256": object_hash({"run": run, "common": common}),
                "pair_receipt": str(pair_path / "preflight.json"),
                "validation": validation,
            }, checkpoint)
            record = {
                "epoch": epoch + 1, "training": training, "validation": validation,
                "learning_rate_before": rate_before, "learning_rate_next": optimizer.param_groups[0]["lr"],
                "sampler_order_sha256": order_hash, "checkpoint_sha256": file_hash(checkpoint),
                "seconds": time.perf_counter() - tick,
                "peak_cuda_bytes": torch.cuda.max_memory_allocated() if device == "cuda" else None,
            }
            records.append(record)
            write_json(output / f"epoch_{epoch + 1:03d}.json", record)
            state["completed_epochs"] = epoch + 1
            write_json(output / "status.json", state)
            print(f"{run['experiment_id']} epoch={epoch + 1} mean_validation_nse={score:.9f}", flush=True)
        selected = choose_epoch(scores, common["selection"]["tie_tolerance"])
        checkpoint = output / f"epoch_{selected:03d}.pt"
        shutil.copyfile(checkpoint, output / "best_model.pt")
        state.update({
            "status": "BUDGET_LIMITED_INCONCLUSIVE" if budget_limited(scores, selected) else "COMPLETED",
            "selected_epoch": selected, "selected_checkpoint_sha256": file_hash(checkpoint),
            "mean_validation_nse_future_1_24": scores[selected - 1],
            "wall_seconds": time.perf_counter() - started,
            "initial_parameters_sha256": initial_hash,
            "optimizer_steps": sum(record["training"]["batches"] for record in records),
            "test_data_accessed": False,
        })
        write_json(output / "selection.json", {"scores": scores, **state})
        write_json(output / "status.json", state)
        return state
    except BaseException as error:
        state.update({"status": "FAILED", "error": str(error), "traceback": traceback.format_exc()})
        write_json(output / "status.json", state)
        raise


def execute_pair(seed: int, authorization_note: str) -> dict:
    require(bool(authorization_note.strip()), "An explicit execution authorization note is required")
    specs = load_pair(CONFIG_DIR / f"run_output12_seed{seed}.json", CONFIG_DIR / f"run_output25_seed{seed}.json")
    common = specs[0]["common"]
    source_receipt = check_sources()
    data_receipt = check_data(common)
    paths = [checked_output(spec["run"]["output_directory"]) for spec in specs]
    require(paths[0].parent == paths[1].parent, "Pair outputs do not share an isolated parent")
    pair_path = paths[0].parent
    # Claim the whole pair once. An incomplete or failed directory is never reused.
    pair_path.mkdir(parents=True, exist_ok=False)
    state = {"status": "PREPARING", "seed": seed, "authorization_note": authorization_note,
             "arms": {spec["run"]["experiment_id"]: "NOT_STARTED" for spec in specs}}
    write_json(pair_path / "status.json", state)
    try:
        configure_determinism(common["runtime"]["device"])
        environment = environment_receipt(common["runtime"]["device"])
        manifest = read_json(CONFIG_DIR / "source_manifest.json")
        for relative in manifest["files"]:
            destination = pair_path / "source_snapshot" / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / relative, destination)
            require(file_hash(destination) == manifest["files"][relative], "Snapshot changed during copy")
        shutil.copyfile(CONFIG_DIR / "source_manifest.json", pair_path / "source_manifest.json")
        git_head = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True, capture_output=True, check=True).stdout.strip()
        git_diff = subprocess.run(["git", "diff", "HEAD", "--binary"], cwd=ROOT, capture_output=True, check=True).stdout
        import hashlib
        datasets = {split: load_dataset(item, split, common["window_size"]) for split, item in common["data"].items()}
        initial_hashes = []
        for spec in specs:
            seed_all(seed, common["runtime"]["device"])
            pipeline = make_pipeline(common)
            initial_hashes.append(parameter_hash(pipeline.knet_model))
            if len(initial_hashes) == 1:
                torch.save({
                    "model_state_dict": {key: value.detach().cpu().clone() for key, value in pipeline.knet_model.state_dict().items()},
                    "rng": rng_snapshot(common["runtime"]["device"]),
                }, pair_path / "initial_model.pt")
            del pipeline
        require(len(set(initial_hashes)) == 1, "Paired initialization differs")
        orders = [epoch_order(len(datasets["train"]), seed, epoch)[1] for epoch in range(common["budget"]["epochs"])]
        preflight = {
            "sources": source_receipt, "data": data_receipt, "environment": environment,
            "git_head": git_head, "git_tracked_diff_sha256": hashlib.sha256(git_diff).hexdigest(),
            "untracked_implementation_files": "Included by content in source_manifest and source_snapshot",
            "initial_parameter_hashes": initial_hashes, "sampler_order_hashes": orders,
            "common_origins": 776, "train_batches_per_epoch": math.ceil(len(datasets["train"]) / common["loader"]["batch_size"]),
            "validation_batches_per_epoch": math.ceil(len(datasets["validation"]) / common["loader"]["batch_size"]),
            "test_data_accessed": False,
        }
        write_json(pair_path / "preflight.json", preflight)
        state["status"] = "RUNNING"
        write_json(pair_path / "status.json", state)
        for spec in specs:
            identity = spec["run"]["experiment_id"]
            require(check_sources() == source_receipt, "Source changed before starting an arm")
            state["arms"][identity] = {"status": "RUNNING"}
            write_json(pair_path / "status.json", state)
            try:
                result = train_arm(spec, datasets, initial_hashes[0], orders, environment, pair_path)
            except BaseException as error:
                status_path = checked_output(spec["run"]["output_directory"]) / "status.json"
                state["arms"][identity] = read_json(status_path) if status_path.exists() else {"status": "FAILED", "error": str(error)}
                raise
            state["arms"][identity] = result
            write_json(pair_path / "status.json", state)
            gc.collect()
            if common["runtime"]["device"] == "cuda":
                torch.cuda.empty_cache()
        require(len({item["optimizer_steps"] for item in state["arms"].values()}) == 1, "Paired optimizer step counts differ")
        require(len({item["completed_epochs"] for item in state["arms"].values()}) == 1, "Paired budgets differ")
        state["status"] = "BUDGET_LIMITED_INCONCLUSIVE" if any(item["status"] == "BUDGET_LIMITED_INCONCLUSIVE" for item in state["arms"].values()) else "COMPLETED"
        # Detect accidental source/data drift over the full paired execution.
        require(check_sources() == source_receipt and check_data(common) == data_receipt, "Source or data changed during training")
        write_json(pair_path / "status.json", state)
        return state
    except BaseException as error:
        state.update({"status": "FAILED", "error": str(error), "traceback": traceback.format_exc()})
        write_json(pair_path / "status.json", state)
        raise
