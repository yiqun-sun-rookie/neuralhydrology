"""Explicit runtime state and hash-checked training/validation deserialization."""
from __future__ import annotations

import hashlib
import json
import os
import pickle
import platform
import random
import subprocess
import sys
from pathlib import Path
from types import ModuleType

import numpy as np
import torch

from knet.modules.data_preprocessor.windowed_time_series import WindowedTimeSeriesDataset

from .protocol import ContractError, file_hash, require


def write_json(path: Path, value: dict) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")


def configure_determinism(device: str) -> None:
    require(not torch.cuda.is_initialized(), "Configure deterministic CUDA before initialization")
    existing = os.environ.get("CUBLAS_WORKSPACE_CONFIG")
    require(existing in (None, ":4096:8"), "Conflicting CUBLAS_WORKSPACE_CONFIG")
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    if device == "cuda":
        require(torch.cuda.is_available(), "The frozen CUDA device is unavailable")


def seed_all(seed: int, device: str) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if device == "cuda":
        torch.cuda.manual_seed_all(seed)


def parameter_hash(model) -> str:
    digest = hashlib.sha256()
    for name, tensor in sorted(model.state_dict().items()):
        array = tensor.detach().cpu().contiguous().numpy()
        digest.update(json.dumps([name, str(array.dtype), list(array.shape)]).encode())
        digest.update(array.tobytes())
    return digest.hexdigest()


def epoch_order(size: int, seed: int, epoch: int):
    generator = torch.Generator(device="cpu").manual_seed(seed + 1_000_003 * epoch)
    order = torch.randperm(size, generator=generator)
    digest = hashlib.sha256(order.numpy().astype("<i8").tobytes()).hexdigest()
    return order.tolist(), digest, generator.get_state()


def rng_snapshot(device: str) -> dict:
    return {
        "python": random.getstate(), "numpy": np.random.get_state(),
        "torch_cpu": torch.get_rng_state(),
        "torch_cuda": torch.cuda.get_rng_state_all() if device == "cuda" else [],
    }


class LegacyDatasetUnpickler(pickle.Unpickler):
    def find_class(self, module, name):
        if module == "src.modules.data_preprocessor.windowed_time_series" and name == "WindowedTimeSeriesDataset":
            return WindowedTimeSeriesDataset
        return super().find_class(module, name)


def load_dataset(spec: dict, split: str, window: int):
    """Only trusted, hash-pinned files are deserialized. Constructors do not run."""
    require(split in ("train", "validation"), "Dataset split rejected")
    path = Path(spec["path"])
    require(file_hash(path) == spec["sha256"], "Dataset changed before deserialization")
    compat_pickle = ModuleType("horizon_compat_pickle")
    compat_pickle.Unpickler = LegacyDatasetUnpickler
    compat_pickle.load = pickle.load
    dataset = torch.load(path, map_location="cpu", weights_only=False, pickle_module=compat_pickle)
    require(type(dataset) is WindowedTimeSeriesDataset, "Unexpected dataset type")
    require(dataset.window_size == window and len(dataset) == spec["items"], "Dataset dimensions changed")
    lengths = {len(getattr(dataset, key)) for key in ("p", "etpot", "qobs", "tm_hours", "states_all")}
    require(len(lengths) == 1, "Dataset component lengths differ")
    for key in ("p", "etpot", "qobs", "tm_hours"):
        value = getattr(dataset, key)
        require(value.ndim == 2 and value.shape[1] == 1 and bool(torch.isfinite(value).all()), f"Invalid {split}.{key}")
    require(dataset.states_all.shape == (len(dataset.p), 5), "Invalid initial-state array")
    require(bool(torch.isfinite(dataset.states_all).all()), "Non-finite initial-state array")
    # The frozen training dataset includes offline high-flow augmentation.
    # Do not sort, deduplicate, or filter its saved windows during this study.
    return dataset


def environment_receipt(device: str) -> dict:
    result = {
        "python": sys.version, "executable": sys.executable, "platform": platform.platform(),
        "numpy": np.__version__, "torch": torch.__version__, "torch_config": torch.__config__.show(),
        "cuda_runtime": torch.version.cuda, "cudnn": torch.backends.cudnn.version(),
        "torch_threads": torch.get_num_threads(),
        "deterministic": torch.are_deterministic_algorithms_enabled(),
        "cudnn_benchmark": torch.backends.cudnn.benchmark,
        "cudnn_deterministic": torch.backends.cudnn.deterministic,
        "matmul_tf32": torch.backends.cuda.matmul.allow_tf32,
        "cudnn_tf32": torch.backends.cudnn.allow_tf32,
        "runtime_environment": {key: os.environ.get(key) for key in (
            "CUDA_VISIBLE_DEVICES", "CUBLAS_WORKSPACE_CONFIG", "OMP_NUM_THREADS",
            "MKL_NUM_THREADS", "PYTHONHASHSEED", "NVIDIA_TF32_OVERRIDE",
        )},
    }
    if device == "cuda":
        properties = torch.cuda.get_device_properties(0)
        result["graphics_processor"] = {
            "name": properties.name, "total_memory": properties.total_memory,
            "capability": list(torch.cuda.get_device_capability(0)),
        }
        driver = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,driver_version,uuid", "--format=csv,noheader"],
            capture_output=True, text=True, check=True, timeout=15,
        )
        result["graphics_driver_inventory"] = driver.stdout.strip()
    return result
