"""Isolated, explicitly invoked training-horizon preparation and execution."""
