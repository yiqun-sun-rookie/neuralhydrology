"""Float64 full-sample validation metrics; no batch-average NSE selection."""
from __future__ import annotations

import numpy as np

from .protocol import ContractError


class LeadStatistics:
    """Merge observation moments and error sums over all repeated forecast contexts.

    Inputs contain current output in position zero. That position is never scored.
    Repeated timestamps from different assimilation histories remain distinct,
    matching the frozen window-context evaluation unit.
    """

    def __init__(self):
        self.count = 0
        self.mean = np.zeros(24, dtype=np.float64)
        self.m2 = np.zeros(24, dtype=np.float64)
        self.sse = np.zeros(24, dtype=np.float64)

    def update(self, prediction, observation) -> None:
        prediction, observation = np.asarray(prediction), np.asarray(observation)
        if prediction.shape != observation.shape or prediction.shape[-1] != 25:
            raise ContractError("Selection requires matched arrays with 25 output positions")
        pred = prediction.reshape(-1, 25)
        obs = observation.reshape(-1, 25)
        for start in range(0, len(obs), 32768):
            x = obs[start:start + 32768, 1:].astype(np.float64)
            y = pred[start:start + 32768, 1:].astype(np.float64)
            if not np.isfinite(x).all() or not np.isfinite(y).all():
                raise ContractError("Non-finite common validation values")
            n = len(x)
            mean = x.mean(axis=0)
            delta = mean - self.mean
            total = self.count + n
            self.m2 += ((x - mean) ** 2).sum(axis=0) + delta ** 2 * (self.count * n / total)
            self.mean += delta * (n / total)
            self.sse += ((y - x) ** 2).sum(axis=0)
            self.count = total

    def result(self) -> dict:
        if self.count < 2 or (self.m2 <= 0).any():
            raise ContractError("Undefined validation NSE: too few values or zero observed variance")
        values = 1.0 - self.sse / self.m2
        if not np.isfinite(values).all():
            raise ContractError("Non-finite validation NSE")
        return {
            "mean_nse_future_1_24": float(values.mean()),
            "nse_by_future_hour": values.tolist(),
            "contexts_per_lead": self.count,
            "observation_mean": self.mean.tolist(), "observation_centered_sum_squares": self.m2.tolist(),
            "squared_error_sum": self.sse.tolist(),
        }


def choose_epoch(scores: list[float], tolerance: float = 1e-12) -> int:
    if not scores or not np.isfinite(scores).all():
        raise ContractError("All checkpoint selection scores must be finite")
    maximum = max(scores)
    return next(i + 1 for i, score in enumerate(scores) if maximum - score <= tolerance)


def budget_limited(scores: list[float], selected_epoch: int) -> bool:
    late = selected_epoch > len(scores) - 10
    still_improving = len(scores) > 1 and scores[-1] - max(scores[:-1]) > max(1e-12, abs(max(scores[:-1])) * 0.001)
    return bool(late or still_improving)
