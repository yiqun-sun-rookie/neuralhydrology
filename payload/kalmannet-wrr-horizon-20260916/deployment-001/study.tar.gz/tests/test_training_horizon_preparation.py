"""Software checks only: artificial tensors, temporary archives, and mocked epochs.

No historical checkpoint or real train/validation/test dataset is loaded.
The native network is constructed for identity checks but is never optimized.
"""
from __future__ import annotations

import copy
import json
import math
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest
import torch

from experiments.optimize_hyper_parameters.training_horizon_20260916 import protocol
from experiments.optimize_hyper_parameters.training_horizon_20260916.metrics import LeadStatistics, budget_limited, choose_epoch
from experiments.optimize_hyper_parameters.training_horizon_20260916.numerics import aligned_forecast, aligned_observations, horizon_loss, make_pipeline, optimizer_step
from experiments.optimize_hyper_parameters.training_horizon_20260916.runtime import LegacyDatasetUnpickler, epoch_order, file_hash, load_dataset, parameter_hash, seed_all
from knet.modules.data_preprocessor.windowed_time_series import WindowedTimeSeriesDataset


@pytest.fixture
def common():
    return protocol.read_json(protocol.CONFIG_DIR / "common.json")


class ArtificialSystem:
    m = n = 1

    @staticmethod
    def f(state, controls):
        return state + controls[:, :1] + 2 * controls[:, 1:2]

    @staticmethod
    def h(state):
        return state


@pytest.mark.parametrize("horizon", [12, 25])
def test_forecast_uses_same_776_origins_and_true_future_controls(horizon):
    states = torch.arange(1600, dtype=torch.float64).reshape(2, 1, 800).requires_grad_()
    p = torch.arange(1600, dtype=torch.float64).reshape(2, 1, 800) / 100
    evaporation = p / 3
    prediction = aligned_forecast(ArtificialSystem(), p, evaporation, states, horizon)
    expected = [states[:, 0, :776]]
    for lead in range(1, horizon):
        expected.append(expected[-1] + p[:, 0, lead:lead + 776] + 2 * evaporation[:, 0, lead:lead + 776])
    reference = torch.stack(expected, dim=-1)
    assert prediction.shape == (2, 776, horizon)
    torch.testing.assert_close(prediction, reference, atol=1e-12, rtol=1e-12)
    actual_gradient, = torch.autograd.grad(prediction.square().mean(), states, retain_graph=True)
    reference_gradient, = torch.autograd.grad(reference.square().mean(), states)
    torch.testing.assert_close(actual_gradient, reference_gradient, atol=1e-12, rtol=1e-12)


def test_short_forecast_is_exact_prefix_of_long_forecast():
    states = torch.ones(2, 1, 800)
    p = torch.arange(1600, dtype=torch.float32).reshape(2, 1, 800) / 1000
    short = aligned_forecast(ArtificialSystem(), p, p, states, 12)
    long = aligned_forecast(ArtificialSystem(), p, p, states, 25)
    torch.testing.assert_close(short, long[..., :12], atol=0, rtol=0)


@pytest.mark.parametrize("horizon", [12, 25])
def test_current_update_term_excludes_tail_in_both_arms(common, horizon):
    observed = torch.zeros(1, 1, 800)
    updated = torch.zeros(1, 1, 800)
    updated[..., 775] = 2
    updated[..., 776:] = 1000
    updated.requires_grad_()
    prediction = torch.zeros(1, 776, horizon)
    target = aligned_observations(observed, horizon)
    loss = horizon_loss(prediction, target, updated, observed, horizon, common["loss"])
    assert loss.item() == pytest.approx(0.05 * 4 / 776)
    gradient, = torch.autograd.grad(loss, updated)
    assert torch.count_nonzero(gradient[..., 776:]).item() == 0
    assert gradient[..., 775].item() > 0


def test_observation_alignment_preserves_batch_origin_and_lead():
    observation = torch.arange(1600).reshape(2, 1, 800)
    result = aligned_observations(observation, 25)
    assert result[0, 775].tolist() == list(range(775, 800))
    assert result[1, 775].tolist() == list(range(1575, 1600))


def test_selection_is_full_sample_and_ignores_current_position():
    observation = np.arange(300 * 25, dtype=float).reshape(300, 25) / 100
    prediction = observation + np.linspace(-3, 4, 300)[:, None]
    prediction[:, 0] = np.nan
    statistics = LeadStatistics()
    statistics.update(prediction[:7], observation[:7])
    statistics.update(prediction[7:], observation[7:])
    expected = 1 - ((prediction[:, 1:] - observation[:, 1:]) ** 2).sum(0) / ((observation[:, 1:] - observation[:, 1:].mean(0)) ** 2).sum(0)
    result = statistics.result()
    np.testing.assert_allclose(result["nse_by_future_hour"], expected, rtol=1e-12, atol=1e-12)
    assert result["contexts_per_lead"] == 300


def test_metrics_reject_undefined_or_nonfinite_future_values():
    statistics = LeadStatistics()
    statistics.update(np.ones((5, 25)), np.ones((5, 25)))
    with pytest.raises(protocol.ContractError, match="variance"):
        statistics.result()
    bad = np.ones((2, 25))
    bad[0, 1] = np.nan
    with pytest.raises(protocol.ContractError, match="Non-finite"):
        LeadStatistics().update(bad, np.zeros_like(bad))


def test_selection_ties_use_global_maximum_and_earlier_epoch():
    assert choose_epoch([0.8, 0.9, 0.9 - 1e-13]) == 2
    assert choose_epoch([1.0, 1 + 0.75e-12, 1 + 1.5e-12]) == 2
    with pytest.raises(protocol.ContractError):
        choose_epoch([0.8, float("inf")])


def test_budget_flag_is_distinct_from_technical_completion():
    scores = [0.5] * 50
    scores[9] = 0.9
    assert not budget_limited(scores, choose_epoch(scores))
    scores[-1] = 0.95
    assert budget_limited(scores, choose_epoch(scores))


def test_initial_native_model_identity_is_reproducible_without_loading_data(common, monkeypatch):
    monkeypatch.setattr(torch, "load", lambda *a, **kw: pytest.fail("Native construction must not load data"))
    seed_all(42, "cpu")
    first = make_pipeline(common, "cpu")
    digest = parameter_hash(first.knet_model)
    assert sum(value.numel() for value in first.knet_model.state_dict().values()) == 48937
    seed_all(42, "cpu")
    second = make_pipeline(common, "cpu")
    assert parameter_hash(second.knet_model) == digest
    assert first.knet_model.hq_ub.item() == 50
    assert first.knet_model.enable_clamp_scale


def test_sampler_is_independent_of_ambient_randomness_and_validation():
    first, first_hash, first_state = epoch_order(100, 42, 0)
    torch.rand(300)
    np.random.rand(300)
    next(iter(torch.utils.data.DataLoader(list(range(10)), generator=torch.Generator().manual_seed(99))))
    second, second_hash, second_state = epoch_order(100, 42, 0)
    assert first == second and first_hash == second_hash
    assert sorted(first) == list(range(100))
    assert torch.equal(first_state, second_state)
    assert epoch_order(100, 42, 1)[1] != first_hash
    assert epoch_order(100, 43, 0)[1] != first_hash


def test_gradient_clipping_matches_original_operation_order(common):
    model = torch.nn.Linear(2, 1, bias=False)
    with torch.no_grad():
        model.weight.copy_(torch.tensor([[0.01, 0.02]]))
    reference = copy.deepcopy(model)
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.01, weight_decay=0.01)
    expected_optimizer = torch.optim.AdamW(reference.parameters(), lr=0.01, weight_decay=0.01)
    optimizer_step(model, optimizer, (model.weight * 100).sum(), common["gradient_clipping"])
    expected_optimizer.zero_grad()
    (reference.weight * 100).sum().backward()
    torch.nn.utils.clip_grad_norm_(reference.parameters(), 1.0)
    for parameter in reference.parameters():
        limit = 0.05 * parameter.data.abs().mean().clamp(min=1e-8) / 0.01
        parameter.grad.data.clamp_(-limit, limit)
    expected_optimizer.step()
    torch.testing.assert_close(model.weight, reference.weight, atol=0, rtol=0)


def test_nonfinite_gradient_stops_before_optimizer_step(common, monkeypatch):
    model = torch.nn.Linear(1, 1, bias=False)
    with torch.no_grad():
        model.weight.zero_()
    optimizer = torch.optim.AdamW(model.parameters())
    called = []
    monkeypatch.setattr(optimizer, "step", lambda: called.append(True))
    with pytest.raises(RuntimeError):
        optimizer_step(model, optimizer, model.weight.sqrt().sum(), common["gradient_clipping"])
    assert not called


def test_dataset_loader_maps_legacy_class_and_checks_hash_before_load(tmp_path, monkeypatch):
    dataset = WindowedTimeSeriesDataset.__new__(WindowedTimeSeriesDataset)
    dataset.window_size = 3
    for key in ("p", "etpot", "qobs", "tm_hours"):
        setattr(dataset, key, torch.arange(8, dtype=torch.float32).reshape(8, 1))
    dataset.states_all = torch.ones(8, 5)
    path = tmp_path / "artificial_train.pt"
    torch.save(dataset, path)
    spec = {"path": str(path), "sha256": file_hash(path), "items": 6}
    loaded = load_dataset(spec, "train", 3)
    torch.testing.assert_close(loaded[0]["state0"], torch.ones(5, 3))
    import io
    assert LegacyDatasetUnpickler(io.BytesIO()).find_class("src.modules.data_preprocessor.windowed_time_series", "WindowedTimeSeriesDataset") is WindowedTimeSeriesDataset
    monkeypatch.setattr(torch, "load", lambda *a, **kw: pytest.fail("Hash mismatch must fail before loading"))
    with pytest.raises(protocol.ContractError, match="changed"):
        load_dataset({**spec, "sha256": "0" * 64}, "train", 3)
    with pytest.raises(protocol.ContractError, match="split"):
        load_dataset(spec, "test", 3)


def test_common_contract_rejects_test_paths_and_budget_changes(common):
    changed = copy.deepcopy(common)
    changed["data"]["test"] = changed["data"]["validation"]
    with pytest.raises(protocol.ContractError):
        protocol.validate_common(changed)
    changed = copy.deepcopy(common)
    changed["budget"]["epochs"] = 51
    with pytest.raises(protocol.ContractError):
        protocol.validate_common(changed)
    with pytest.raises(protocol.ContractError):
        protocol.checked_output("../unrelated")


def test_pair_rejects_mismatched_seed(tmp_path):
    first = protocol.read_json(protocol.CONFIG_DIR / "run_output12_seed42.json")
    second = protocol.read_json(protocol.CONFIG_DIR / "run_output25_seed43.json")
    (tmp_path / "common.json").write_bytes((protocol.CONFIG_DIR / "common.json").read_bytes())
    paths = []
    for index, run in enumerate((first, second)):
        path = tmp_path / f"run{index}.json"
        path.write_text(json.dumps(run), encoding="utf-8")
        paths.append(path)
    with pytest.raises(protocol.ContractError, match="seeds differ"):
        protocol.load_pair(*paths)


def test_training_command_requires_explicit_execution_before_runtime_import(monkeypatch):
    from experiments.optimize_hyper_parameters.training_horizon_20260916.__main__ import main
    import builtins
    original_import = builtins.__import__
    def guarded(name, *args, **kwargs):
        if name == "runner":
            pytest.fail("Rejected command must not import execution runtime")
        return original_import(name, *args, **kwargs)
    monkeypatch.setattr(builtins, "__import__", guarded)
    with pytest.raises(SystemExit) as error:
        main(["train-pair", "--seed", "42"])
    assert error.value.code == 2


def test_pair_failure_preserves_record_and_does_not_start_second_arm(common, tmp_path, monkeypatch):
    from experiments.optimize_hyper_parameters.training_horizon_20260916 import runner
    local = copy.deepcopy(common)
    local["runtime"]["device"] = "cpu"
    local["data"] = {"train": {}, "validation": {}}
    pair_root = tmp_path / "pair"
    specs = tuple({"common": local, "run": {"seed": 42, "experiment_id": f"arm{h}", "output_directory": f"arm{h}"}} for h in (12, 25))
    monkeypatch.setattr(runner, "load_pair", lambda *a: specs)
    monkeypatch.setattr(runner, "check_sources", lambda: {"checked": True})
    monkeypatch.setattr(runner, "check_data", lambda *a: {"checked": True})
    monkeypatch.setattr(runner, "checked_output", lambda value: pair_root / value)
    monkeypatch.setattr(runner, "configure_determinism", lambda *a: None)
    monkeypatch.setattr(runner, "environment_receipt", lambda *a: {"mock": True})
    monkeypatch.setattr(runner, "load_dataset", lambda *a: list(range(3)))
    monkeypatch.setattr(runner, "make_pipeline", lambda *a: SimpleNamespace(knet_model=torch.nn.Linear(1, 1)))
    real_read = runner.read_json
    monkeypatch.setattr(runner, "read_json", lambda path: {"files": {}} if path.name == "source_manifest.json" else real_read(path))
    monkeypatch.setattr(runner.shutil, "copyfile", lambda *a: None)
    monkeypatch.setattr(runner.subprocess, "run", lambda *a, **kw: SimpleNamespace(stdout="mock-head\n" if kw.get("text") else b""))
    calls = []
    def fail_first(spec, *args):
        calls.append(spec["run"]["experiment_id"])
        raise RuntimeError("injected engineering failure")
    monkeypatch.setattr(runner, "train_arm", fail_first)
    with pytest.raises(RuntimeError, match="injected"):
        runner.execute_pair(42, "synthetic software check only")
    status = protocol.read_json(pair_root / "status.json")
    assert calls == ["arm12"]
    assert status["status"] == "FAILED"
    assert status["arms"]["arm12"]["status"] == "FAILED"
    assert status["arms"]["arm25"] == "NOT_STARTED"
    with pytest.raises(FileExistsError):
        runner.execute_pair(42, "no overwrite")


def test_real_data_item_counts_do_not_drop_last_batch(common):
    assert math.ceil(common["data"]["train"]["items"] / common["loader"]["batch_size"]) == 60
    assert common["data"]["train"]["items"] % common["loader"]["batch_size"] == 4
    assert math.ceil(common["data"]["validation"]["items"] / common["loader"]["batch_size"]) == 8


def test_mocked_complete_arm_saves_every_epoch_and_selects_common_metric(common, tmp_path, monkeypatch):
    from experiments.optimize_hyper_parameters.training_horizon_20260916 import runner
    local = copy.deepcopy(common)
    local["runtime"]["device"] = "cpu"
    spec = {"common": local, "run": {"seed": 42, "training_output_positions": 12,
            "output_directory": "artificial", "experiment_id": "artificial"}}
    output = tmp_path / "artificial"
    monkeypatch.setattr(runner, "checked_output", lambda *a: output)
    monkeypatch.setattr(runner, "environment_receipt", lambda *a: {"mock": True})
    monkeypatch.setattr(runner, "make_pipeline", lambda *a: SimpleNamespace(knet_model=torch.nn.Linear(1, 1)))
    seed_all(42, "cpu")
    initial = parameter_hash(torch.nn.Linear(1, 1))
    orders = [epoch_order(7, 42, epoch)[1] for epoch in range(50)]
    counter = {"validation": 0, "training": 0}
    def fake_epoch(pipeline, loader, configuration, horizon, optimizer=None):
        if optimizer is not None:
            epoch = counter["training"]
            assert list(loader.sampler) == epoch_order(7, 42, epoch)[0]
            counter["training"] += 1
            return {"objective": 1.0, "batches": 1, "windows": 7}
        counter["validation"] += 1
        epoch = counter["validation"]
        return {"objective": 1.0, "mean_nse_future_1_24": 0.9 if epoch == 10 else 0.8,
                "nse_by_future_hour": [0.9 if epoch == 10 else 0.8] * 24}
    monkeypatch.setattr(runner, "run_epoch", fake_epoch)
    result = runner.train_arm(spec, {"train": list(range(7)), "validation": list(range(5))}, initial, orders, {"mock": True}, tmp_path)
    assert counter == {"validation": 50, "training": 50}
    assert result["selected_epoch"] == 10 and result["status"] == "COMPLETED"
    assert len(list(output.glob("epoch_*.pt"))) == 50
    assert file_hash(output / "best_model.pt") == file_hash(output / "epoch_010.pt")
    assert result["optimizer_steps"] == 50  # Mocked accounting, not real optimization.


def test_check_command_does_not_import_torch_or_create_experiment_outputs():
    module = "experiments.optimize_hyper_parameters.training_horizon_20260916.__main__"
    code = f"import sys; from {module} import main; main(['check']); assert 'torch' not in sys.modules"
    result = subprocess.run([sys.executable, "-B", "-c", code], cwd=protocol.ROOT, capture_output=True, text=True)
    assert result.returncode == 0, result.stdout + result.stderr
    assert '"model_constructed": false' in result.stdout
