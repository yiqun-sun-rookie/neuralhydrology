import torch
from torch.utils.data import Dataset
class WindowedTimeSeriesDataset(Dataset):
    """
    将一条长时间序列切分为多个长度为 window_size 的小窗口。
    每个窗口返回对应的 p、etpot、qobs、state0、tm_hours 片段。

    参数：
        p (np.ndarray or list):          降雨序列, shape = [T,].
        etpot (np.ndarray or list):      蒸发序列, shape = [T,].
        qobs (np.ndarray or list):       流量序列, shape = [T,].
        tm_hours (np.ndarray or list):   时间序列, shape = [T,].
        states_file_path (str):          由 WalrusBatch 运行得到的状态文件路径, shape = [T, m].
        window_size (int):               窗口大小(每个样本的时序长度).
    """

    def __init__(self, p, etpot, qobs, tm_hours, states_file_path, window_size):
        # 将输入数据转换为 PyTorch 张量，并在最后一维增加一个维度（[T,1]），方便后续操作
        self.p = torch.tensor(p, dtype=torch.float32).unsqueeze(-1)
        self.etpot = torch.tensor(etpot, dtype=torch.float32).unsqueeze(-1)
        self.qobs = torch.tensor(qobs, dtype=torch.float32).unsqueeze(-1)
        self.tm_hours = torch.tensor(tm_hours, dtype=torch.float32).unsqueeze(-1)

        # 从文件载入事先保存好的状态序列 [T, m]
        self.states_all = torch.load(states_file_path, weights_only=True)

        self.window_size = window_size

    def __len__(self):
        """
        返回可用的滑窗数量。假设原序列长度为 T，则可切出的窗口数量 = (T - window_size + 1)。
        不在这里与 batch_size 挂钩，方便后续在 DataLoader 中灵活指定 batch_size。
        """
        total_length = len(self.p)  # p, etpot, qobs, tm_hours 应该长度一致
        return total_length - self.window_size + 1

    def __getitem__(self, idx):
        """
        返回第 idx 个窗口的数据字典。
        每个窗口长度 window_size，对应区间为 [idx, idx+window_size)。
        """
        start = idx
        end = idx + self.window_size

        sample = {
            'p': self.p[start:end].transpose(0, 1),  # shape: [1, window_size]
            'etpot': self.etpot[start:end].transpose(0, 1),  # shape: [1, window_size]
            'qobs': self.qobs[start:end].transpose(0, 1),  # shape: [1, window_size]
            'tm_hours': self.tm_hours[start:end].transpose(0, 1),  # shape: [1, window_size]
            'state0': self.states_all[start:end].transpose(0, 1)  # shape: [m, window_size]
        }

        return sample
