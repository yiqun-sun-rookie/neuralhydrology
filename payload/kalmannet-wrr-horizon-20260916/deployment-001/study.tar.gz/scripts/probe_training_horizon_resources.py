"""One isolated, guarded forward/backward resource probe; no optimizer exists."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback

import psutil

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "artifacts/resource_probes/20260916_horizon25_seed42_attempt001"
GIB = 1024 ** 3
TIME_LIMIT = 600


def write_json(path, value):
    with Path(path).open("w", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")


def gpu_budget(total, free):
    budget = min(int(total * 0.8), free - GIB)
    if budget < 2 * GIB:
        raise ValueError("Less than 2 GiB safe CUDA allocation budget")
    return budget


def guard_reason(available, rss, elapsed):
    if available < 4 * GIB:
        return "system_available_below_4_GiB"
    if rss > 8 * GIB:
        return "worker_resident_memory_above_8_GiB"
    if elapsed > TIME_LIMIT:
        return "wall_time_above_600_seconds"
    return None


def claim_output(path):
    path.mkdir(parents=True, exist_ok=False)


def worker(path):
    """Executed only by the monitoring parent in a fresh process."""
    import torch
    from torch.utils.data import DataLoader
    from experiments.optimize_hyper_parameters.training_horizon_20260916.protocol import (
        CONFIG_DIR, inspect_configuration, load_run, file_hash,
    )
    from experiments.optimize_hyper_parameters.training_horizon_20260916.runtime import (
        configure_determinism, seed_all, load_dataset, epoch_order,
        environment_receipt, parameter_hash,
    )
    from experiments.optimize_hyper_parameters.training_horizon_20260916.numerics import (
        make_pipeline, compute_batch,
    )

    result = {
        "status": "RUNNING", "stage": "configuration", "optimizer_steps": 0,
        "test_data_accessed": False, "backward_completed": False,
        "full_training_memory_proven": False,
    }
    started = time.perf_counter()
    process = psutil.Process()
    model = None
    initial_hash = None
    updates = 0

    def snapshot(stage):
        result["stage"] = stage
        sample = {
            "stage": stage, "elapsed_seconds": time.perf_counter() - started,
            "worker_rss_bytes": process.memory_info().rss,
            "system_available_bytes": psutil.virtual_memory().available,
        }
        if torch.cuda.is_initialized():
            sample.update({
                "cuda_allocated_bytes": torch.cuda.memory_allocated(),
                "cuda_reserved_bytes": torch.cuda.memory_reserved(),
                "cuda_peak_allocated_bytes": torch.cuda.max_memory_allocated(),
                "cuda_peak_reserved_bytes": torch.cuda.max_memory_reserved(),
            })
        result["last_snapshot"] = sample
        with (path / "stages.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(sample, allow_nan=False) + "\n")
        write_json(path / "worker_status.json", result)
        print(json.dumps(sample), flush=True)

    def hook(module, inputs, output):
        nonlocal updates
        updates += 1
        if updates == 1 or updates % 100 == 0:
            snapshot(f"assimilation_{updates}_of_800")

    try:
        checked = inspect_configuration(True)
        spec = load_run(CONFIG_DIR / "run_output25_seed42.json")
        common = spec["common"]
        write_json(path / "configuration.json", spec)
        write_json(path / "frozen_checks.json", checked)
        manifest = json.loads((CONFIG_DIR / "source_manifest.json").read_text(encoding="utf-8"))
        for relative, expected in manifest["files"].items():
            destination = path / "source_snapshot" / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / relative, destination)
            if file_hash(destination) != expected:
                raise RuntimeError("Frozen source snapshot mismatch")
        shutil.copyfile(CONFIG_DIR / "source_manifest.json", path / "source_manifest.json")
        configure_determinism("cuda")
        free, total = torch.cuda.mem_get_info()
        budget = gpu_budget(total, free)
        torch.cuda.set_per_process_memory_fraction(budget / total)
        torch.cuda.reset_peak_memory_stats()
        result["cuda_budget"] = {"total_bytes": total, "free_before_bytes": free,
                                  "allocator_limit_bytes": budget, "reserved_headroom_bytes": GIB}
        write_json(path / "environment.json", environment_receipt("cuda"))
        snapshot("cuda_ready")
        datasets = {split: load_dataset(item, split, common["window_size"])
                    for split, item in common["data"].items()}
        order, order_hash, _ = epoch_order(len(datasets["train"]), 42, 0)
        loader = DataLoader(datasets["train"], sampler=order,
                            generator=torch.Generator().manual_seed(42 + 2_000_003),
                            **common["loader"])
        batch = next(iter(loader))
        result["batch_shapes"] = {key: list(value.shape) for key, value in batch.items()}
        result["epoch_order_sha256"] = order_hash
        snapshot("batch_loaded")
        seed_all(42, "cuda")
        pipeline = make_pipeline(common)
        model = pipeline.knet_model
        model.train()
        initial_hash = parameter_hash(model)
        result["initial_parameters_sha256"] = initial_hash
        # Same parameter, gradient and two-moment storage order of magnitude is
        # small; no optimizer state or optimizer step is created in this probe.
        result["optimizer_moment_storage_not_measured_bytes"] = sum(
            tensor.numel() * tensor.element_size() * 2 for tensor in model.parameters())
        handle = model.register_forward_hook(hook)
        snapshot("forward_started")
        loss, prediction, target = compute_batch(pipeline, batch, common["loss"], 25)
        torch.cuda.synchronize()
        handle.remove()
        result["prediction_shape"] = list(prediction.shape)
        snapshot("forward_completed")
        loss.backward()
        torch.cuda.synchronize()
        result["backward_completed"] = True
        result["gradients_finite"] = all(
            bool(torch.isfinite(p.grad).all()) for p in model.parameters() if p.grad is not None)
        if not result["gradients_finite"]:
            raise RuntimeError("Non-finite gradients; no optimizer update attempted")
        final_hash = parameter_hash(model)
        result["final_parameters_sha256"] = final_hash
        if final_hash != initial_hash:
            raise RuntimeError("Parameters changed without an optimizer step")
        result["status"] = "PASSED_SINGLE_BATCH_NO_UPDATE"
        snapshot("backward_completed_parameters_unchanged")
    except BaseException as error:
        result.update({"status": "CUDA_MEMORY_LIMIT" if isinstance(error, torch.cuda.OutOfMemoryError)
                       else "FAILED_COMPUTE", "failed_stage": result["stage"],
                       "error_type": type(error).__name__, "error": str(error),
                       "traceback": traceback.format_exc(), "completed_assimilation_steps": updates})
        # Preserve the original failure; diagnostic collection must not replace it.
        try:
            snapshot("failure")
        except BaseException as collection_error:
            result["snapshot_error"] = str(collection_error)
        if model is not None and initial_hash is not None:
            try:
                result["final_parameters_sha256"] = parameter_hash(model)
                result["parameters_unchanged"] = result["final_parameters_sha256"] == initial_hash
            except BaseException as collection_error:
                result["parameter_check_error"] = str(collection_error)
    finally:
        result["worker_elapsed_seconds"] = time.perf_counter() - started
        write_json(path / "worker_result.json", result)
    return 0 if result["status"] == "PASSED_SINGLE_BATCH_NO_UPDATE" else 1


def monitor(path, authorization_note):
    claim_output(path)
    start_memory = psutil.virtual_memory()._asdict()
    receipt = {"status": "PREPARING", "authorization_note": authorization_note,
               "system_memory_before": start_memory, "optimizer_steps": 0,
               "test_data_accessed": False, "sample_interval_seconds": 0.25,
               "max_worker_rss_bytes": 0, "min_system_available_bytes": start_memory["available"]}
    write_json(path / "monitor_result.json", receipt)
    shutil.copyfile(__file__, path / "probe_script.py")
    receipt["probe_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    if start_memory["available"] < 6 * GIB:
        receipt.update(status="STOPPED_BEFORE_LAUNCH", reason="Less than 6 GiB system memory available")
        write_json(path / "monitor_result.json", receipt)
        return 1
    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    environment["PYTHONHASHSEED"] = "42"
    environment["HORIZON_RESOURCE_PROBE_PARENT"] = str(os.getpid())
    command = [sys.executable, "-B", "-m", "scripts.probe_training_horizon_resources",
               "--worker", "--authorization-note", authorization_note]
    with (path / "worker.stdout.log").open("w", encoding="utf-8") as stdout, \
         (path / "worker.stderr.log").open("w", encoding="utf-8") as stderr, \
         (path / "system_memory_samples.jsonl").open("w", encoding="utf-8") as samples:
        child = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=stdout, stderr=stderr,
                                 creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
        watched = psutil.Process(child.pid)
        receipt["worker_pid"] = child.pid
        receipt["status"] = "RUNNING"
        write_json(path / "monitor_result.json", receipt)
        tick = time.perf_counter()
        reason = None
        try:
            while child.poll() is None:
                elapsed = time.perf_counter() - tick
                available = psutil.virtual_memory().available
                try:
                    info = watched.memory_info()
                except psutil.NoSuchProcess:
                    break
                receipt["max_worker_rss_bytes"] = max(receipt["max_worker_rss_bytes"], info.rss)
                receipt["min_system_available_bytes"] = min(receipt["min_system_available_bytes"], available)
                samples.write(json.dumps({"seconds": elapsed, "available_bytes": available,
                                          "worker_memory": info._asdict()}) + "\n")
                samples.flush()
                reason = guard_reason(available, info.rss, elapsed)
                if reason:
                    child.terminate()
                    break
                time.sleep(0.25)
            child.wait(timeout=15)
        finally:
            if child.poll() is None:
                child.kill()
                child.wait(timeout=15)
        receipt.update({"returncode": child.returncode, "elapsed_seconds": time.perf_counter() - tick,
                        "system_memory_after": psutil.virtual_memory()._asdict()})
        if reason:
            receipt.update(status="STOPPED_BY_GUARD", reason=reason)
        elif (path / "worker_result.json").exists():
            worker_result = json.loads((path / "worker_result.json").read_text(encoding="utf-8"))
            receipt["status"] = worker_result["status"]
        else:
            receipt.update(status="WORKER_EXIT_WITHOUT_RESULT", reason="See stderr; do not retry")
        write_json(path / "monitor_result.json", receipt)
    print(json.dumps(receipt, indent=2, allow_nan=False))
    return 0 if receipt["status"] == "PASSED_SINGLE_BATCH_NO_UPDATE" else 1


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--authorization-note", default="")
    args = parser.parse_args(argv)
    if not args.authorization_note.strip():
        parser.error("An explicit authorization note is required")
    if args.worker:
        if os.environ.get("HORIZON_RESOURCE_PROBE_PARENT") != str(os.getppid()):
            parser.error("Worker may only be started by the monitoring parent")
        return worker(OUTPUT)
    if not args.execute:
        parser.error("--execute is required; no resources have been allocated")
    return monitor(OUTPUT, args.authorization_note)


if __name__ == "__main__":
    raise SystemExit(main())
