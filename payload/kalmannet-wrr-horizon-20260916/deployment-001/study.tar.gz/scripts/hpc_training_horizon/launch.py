"""One compute allocation: unchanged resource probe, then frozen seed-42 pair."""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
PROBE = ROOT / 'artifacts/resource_probes/20260916_horizon25_seed42_attempt001'
RECEIPTS = ROOT / 'artifacts/hpc_execution'
AUTHORIZATION = 'User 2026-09-16 authorized HPC experiments in a new isolated directory, preserving existing experiments; seed42 pair only, no retry or test evaluation.'


def probe_passed(result):
    return (result.get('status') == 'PASSED_SINGLE_BATCH_NO_UPDATE'
            and result.get('backward_completed') is True
            and result.get('gradients_finite') is True
            and result.get('optimizer_steps') == 0
            and result.get('test_data_accessed') is False
            and bool(result.get('initial_parameters_sha256'))
            and result.get('initial_parameters_sha256') == result.get('final_parameters_sha256'))


def train():
    import psutil
    import torch
    from experiments.optimize_hyper_parameters.training_horizon_20260916 import runner
    result = json.loads((PROBE / 'worker_result.json').read_text())
    if not probe_passed(result):
        raise RuntimeError('Resource preflight did not pass; training prohibited')
    original_step = runner.optimizer_step
    count = 0
    started = time.monotonic()

    def observed_step(model, optimizer, loss, clipping):
        nonlocal count
        norm = original_step(model, optimizer, loss, clipping)
        count += 1
        if count == 1 or count % 60 == 0 or count == 3001:
            receipt = {'event': 'optimizer_step_completed', 'pair_optimizer_steps': count,
                       'elapsed_seconds': time.monotonic() - started,
                       'maximum_cuda_allocated_bytes': torch.cuda.max_memory_allocated(),
                       'resident_memory_bytes': psutil.Process().memory_info().rss,
                       'system_available_bytes': psutil.virtual_memory().available,
                       'raw_gradient_norm': norm}
            with (RECEIPTS / 'optimizer_steps.jsonl').open('a', encoding='utf-8') as stream:
                stream.write(json.dumps(receipt) + '\n')
            print(json.dumps(receipt), flush=True)
        return norm

    runner.optimizer_step = observed_step
    result = runner.execute_pair(42, AUTHORIZATION)
    print(json.dumps(result, indent=2), flush=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--train-after-probe', action='store_true')
    args = parser.parse_args(argv)
    if not os.environ.get('SLURM_JOB_ID'):
        parser.error('Execution is permitted only inside a Slurm allocation')
    if args.train_after_probe:
        return train()
    RECEIPTS.mkdir(parents=True, exist_ok=False)
    receipt = {'job_id': os.environ['SLURM_JOB_ID'], 'node': os.environ.get('SLURMD_NODENAME'),
               'status': 'RESOURCE_PREFLIGHT', 'authorized_seed': 42, 'test_data_accessed': False}
    path = RECEIPTS / 'status.json'

    def save():
        path.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')

    save()
    try:
        subprocess.run([sys.executable, '-B', '-m', 'scripts.probe_training_horizon_resources',
                        '--execute', '--authorization-note', AUTHORIZATION], cwd=ROOT, check=True)
        result = json.loads((PROBE / 'worker_result.json').read_text())
        if not probe_passed(result):
            raise RuntimeError('Resource preflight gate failed')
        receipt['status'] = 'PREFLIGHT_PASSED_PAIR_STARTING'
        save()
        # Fresh process: deterministic CUDA initialization is not reused from probe.
        subprocess.run([sys.executable, '-B', '-m', 'scripts.hpc_training_horizon.launch',
                        '--train-after-probe'], cwd=ROOT, check=True)
        receipt['status'] = 'PAIR_PROCESS_FINISHED'
    except BaseException as error:
        receipt.update(status='STOPPED_NO_RETRY', error=str(error))
        save()
        raise
    save()


if __name__ == '__main__':
    main()
