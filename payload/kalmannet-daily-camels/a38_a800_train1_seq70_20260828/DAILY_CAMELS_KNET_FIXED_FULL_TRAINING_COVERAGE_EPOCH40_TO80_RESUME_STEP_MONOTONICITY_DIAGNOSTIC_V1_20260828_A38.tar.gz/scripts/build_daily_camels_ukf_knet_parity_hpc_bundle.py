"""Build one deterministic daily CAMELS UKF/KalmanNet parity HPC bundle.

This builder is deliberately standard-library only.  It has an explicit source
allowlist, treats the frozen basin archive as opaque bytes, normalizes every
tar member, and refuses to replace a different destination.  The active
configuration may be the exact TUKF06 replay contract or a later causal
training contract; both use the same fixed implementation and evidence files.
"""

from __future__ import annotations

import argparse
import ast
from dataclasses import dataclass
import gzip
from hashlib import sha256
from io import BytesIO
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import tarfile
from typing import Any, Mapping
import uuid


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_EXACT_CONFIG_MEMBER = (
    "configs/daily_camels_ukf_knet_parity_exact_replay_dtype_repair_v3.json"
)
DEFAULT_EXACT_CONFIG = ROOT / DEFAULT_EXACT_CONFIG_MEMBER

ARCHIVE_MEMBER = (
    "results/tukf06_full_diagonal_search_head_to_head_v1/"
    "selection_inputs/basin_09035800.npz"
)
SELECTION_MEMBER = (
    "results/tukf06_full_diagonal_search_head_to_head_v1/"
    "selection/basin_09035800.json"
)
TUKF06_CONTRACT_MEMBER = "configs/tukf06_full_diagonal_search_head_to_head_v1.json"
A13_BASELINE_CONFIG_MEMBER = (
    "configs/daily_camels_knet_near_zero_stable_lr_strict_smoke_a13.json"
)


# Archive member -> repository-relative source.  Nothing outside this mapping,
# the one validated active config, and the empty package initializers can enter
# the bundle.
FIXED_SOURCE_MEMBER_PATHS: dict[str, str] = {
    TUKF06_CONTRACT_MEMBER: TUKF06_CONTRACT_MEMBER,
    A13_BASELINE_CONFIG_MEMBER: A13_BASELINE_CONFIG_MEMBER,
    "configs/daily_camels_knet_near_zero_strict_smoke_a12.json": (
        "configs/daily_camels_knet_near_zero_strict_smoke_a12.json"
    ),
    "configs/daily_camels_knet_same_segment_post_step_diagnostic_a14.json": (
        "configs/daily_camels_knet_same_segment_post_step_diagnostic_a14.json"
    ),
    "configs/daily_camels_knet_fixed_full_training_coverage_accumulation_a15.json": (
        "configs/daily_camels_knet_fixed_full_training_coverage_accumulation_a15.json"
    ),
    "configs/daily_camels_knet_fixed_full_training_coverage_forty_epoch_a17.json": (
        "configs/daily_camels_knet_fixed_full_training_coverage_forty_epoch_a17.json"
    ),
    "configs/daily_camels_ukf_knet_parity_causal_replay_dtype_repair_v3.json": (
        "configs/daily_camels_ukf_knet_parity_causal_replay_dtype_repair_v3.json"
    ),
    "hpc/daily_camels_ukf_knet_parity/preflight.py": (
        "hpc/daily_camels_ukf_knet_parity/preflight.py"
    ),
    "hpc/daily_camels_ukf_knet_parity/submit_probe_gpu.slurm": (
        "hpc/daily_camels_ukf_knet_parity/submit_probe_gpu.slurm"
    ),
    "hpc/daily_camels_ukf_knet_parity/submit_replay_gpu.slurm": (
        "hpc/daily_camels_ukf_knet_parity/submit_replay_gpu.slurm"
    ),
    "hpc/daily_camels_ukf_knet_parity/submit_train_gpu.slurm": (
        "hpc/daily_camels_ukf_knet_parity/submit_train_gpu.slurm"
    ),
    ARCHIVE_MEMBER: ARCHIVE_MEMBER,
    SELECTION_MEMBER: SELECTION_MEMBER,
    "knet/dl/nn_kalman_clamp_5.py": "knet/dl/nn_kalman_clamp_5.py",
    "scripts/build_daily_camels_ukf_knet_parity_hpc_bundle.py": (
        "scripts/build_daily_camels_ukf_knet_parity_hpc_bundle.py"
    ),
    "scripts/differentiable_ukf_hbvlite.py": (
        "scripts/differentiable_ukf_hbvlite.py"
    ),
    "scripts/run_aligned_gr4j_da.py": "scripts/run_aligned_gr4j_da.py",
    "scripts/run_aligned_gr4j_differentiable_ukf.py": (
        "scripts/run_aligned_gr4j_differentiable_ukf.py"
    ),
    "scripts/run_daily_camels_ukf_knet_parity.py": (
        "scripts/run_daily_camels_ukf_knet_parity.py"
    ),
    "scripts/tukf06_full_diagonal_common.py": (
        "scripts/tukf06_full_diagonal_common.py"
    ),
    "src/global_hydrology/assimilation/conventional_ukf.py": (
        "src/global_hydrology/assimilation/conventional_ukf.py"
    ),
    "src/global_hydrology/experiments/daily_camels_native_knet_io.py": (
        "src/global_hydrology/experiments/daily_camels_native_knet_io.py"
    ),
    "src/global_hydrology/experiments/daily_camels_ukf_knet_parity_contract.py": (
        "src/global_hydrology/experiments/daily_camels_ukf_knet_parity_contract.py"
    ),
    "src/global_hydrology/experiments/daily_camels_ukf_knet_parity_runner.py": (
        "src/global_hydrology/experiments/daily_camels_ukf_knet_parity_runner.py"
    ),
    "src/global_hydrology/models/differentiable_hbv_lite.py": (
        "src/global_hydrology/models/differentiable_hbv_lite.py"
    ),
    "src/global_hydrology/models/hbvlite_system_model.py": (
        "src/global_hydrology/models/hbvlite_system_model.py"
    ),
    "src/global_hydrology/models/hbvlite_ukf_adapter.py": (
        "src/global_hydrology/models/hbvlite_ukf_adapter.py"
    ),
    "src/global_hydrology/models/knet_native_hbvlite_full_state.py": (
        "src/global_hydrology/models/knet_native_hbvlite_full_state.py"
    ),
    "tests/conftest.py": "tests/conftest.py",
    "tests/test_daily_camels_ukf_knet_parity_contract.py": (
        "tests/test_daily_camels_ukf_knet_parity_contract.py"
    ),
    "tests/test_daily_camels_ukf_knet_parity_runner.py": (
        "tests/test_daily_camels_ukf_knet_parity_runner.py"
    ),
    "tests/test_run_daily_camels_ukf_knet_parity_entry.py": (
        "tests/test_run_daily_camels_ukf_knet_parity_entry.py"
    ),
    "tests/test_daily_camels_ukf_knet_parity_hpc_preflight.py": (
        "tests/test_daily_camels_ukf_knet_parity_hpc_preflight.py"
    ),
    "tests/test_differentiable_ukf_hbvlite.py": (
        "tests/test_differentiable_ukf_hbvlite.py"
    ),
    "tests/test_knet_native_hbvlite_full_state.py": (
        "tests/test_knet_native_hbvlite_full_state.py"
    ),
}

EMPTY_PACKAGE_MEMBERS = (
    "knet/__init__.py",
    "knet/dl/__init__.py",
    "scripts/__init__.py",
    "src/global_hydrology/__init__.py",
    "src/global_hydrology/assimilation/__init__.py",
    "src/global_hydrology/experiments/__init__.py",
    "src/global_hydrology/models/__init__.py",
)

FROZEN_EVIDENCE_HASHES = {
    ARCHIVE_MEMBER: "71e6d163507ae405204bedf63d2c6c06e2c3ea303cea1a0481cfa4d5f280f5fd",
    SELECTION_MEMBER: "8b4888a62052f8d9f0018e907c665d30a72c4c7c29081763db0f4d46904ec3a2",
    TUKF06_CONTRACT_MEMBER: "4b19eda7cf4ce7dcd9c0940693577077d6a6faf3b18912b03178164613cac7a3",
    A13_BASELINE_CONFIG_MEMBER: "31b9a4207c483730249bb379f04d113bc0f6459f1390ba90b7a4121b46a65fe1",
}

PINNED_SCIENCE_SOURCE_HASHES = {
    "knet/dl/nn_kalman_clamp_5.py": (
        "934570d3c840e9d57b8fbddf3a018dc29e190cdd712fc9daaf442e383f74d843"
    ),
    "scripts/differentiable_ukf_hbvlite.py": (
        "5d4d0fce3018aef42d6ef81ac32fa97541654f0a878c0508f5594ff2ec73c02d"
    ),
    "scripts/tukf06_full_diagonal_common.py": (
        "2d0ebdae9447ede8873d19032b2c5d497e8f8bff78aab7d92f1c03daa508cf02"
    ),
    "src/global_hydrology/models/differentiable_hbv_lite.py": (
        "d7a04be86f19cddd8b9703e432fafb999a38215cb85de8983fe39a40bda0d6ea"
    ),
    "src/global_hydrology/models/hbvlite_system_model.py": (
        "0d32d0f8dc656bdfbea81ba9f61eba0775ecc770d4466ff0442597d7c8d7a597"
    ),
    "src/global_hydrology/models/knet_native_hbvlite_full_state.py": (
        "3eb80fc1346a3e86170cac28fecad29951fe938193967e6a8cf6ae705edc22da"
    ),
}

ENTRY_INTEGRATION_HASH_CONSTANTS = {
    "src/global_hydrology/experiments/daily_camels_ukf_knet_parity_contract.py": (
        "EXPECTED_CONTRACT_SHA256"
    ),
    "src/global_hydrology/experiments/daily_camels_ukf_knet_parity_runner.py": (
        "EXPECTED_RUNNER_SHA256"
    ),
    "src/global_hydrology/experiments/daily_camels_native_knet_io.py": (
        "EXPECTED_IO_SHA256"
    ),
}

TEXT_SUFFIXES = frozenset({".json", ".py", ".slurm", ".sh", ".txt"})
WINDOWS_ABSOLUTE_PATH = re.compile(rb"(?i)(?:^|[\"'\s(])[a-z]:[\\/]")
WINDOWS_PATH_ALLOWED_MEMBERS = frozenset({"scripts/tukf06_full_diagonal_common.py"})
EXPERIMENT_ID_PATTERN = re.compile(r"^[A-Z0-9][A-Z0-9_-]{15,159}$")
CONTINUATION_SCHEMA_VERSION = "daily_camels_ukf_knet_parity_continuation_v1"
CHECKPOINT_SCHEMA_VERSION = "daily_camels_ukf_knet_parity_checkpoint_v1"
A16_SOURCE_EXPERIMENT_ID = (
    "DAILY_CAMELS_KNET_FIXED_FULL_TRAINING_COVERAGE_TEN_EPOCH_V1_20260825_A16"
)
A16_SOURCE_SLURM_JOB_ID = "211291"
A16_SOURCE_DEVICE_PROVENANCE_SHA256 = (
    "d9c7a88af68821725083e384601eac70c45f6363d7c13a0fa4e588d5b0f55897"
)
PORTABILITY_CONTRACT_SCHEMA_VERSION = (
    "daily_camels_knet_cross_device_portability_contract_v1"
)
PORTABILITY_CONTRACT_STATUS = "FROZEN_FOR_RTX3090_TO_A800_CONTINUATION"
PORTABILITY_SOURCE_DEVICE = "NVIDIA GeForce RTX 3090"
PORTABILITY_TARGET_DEVICE = "NVIDIA A800-SXM4-80GB"
PORTABILITY_THRESHOLDS = {
    "prediction_maximum_absolute_error_limit": 3.0e-7,
    "prediction_maximum_relative_error_limit": 3.0e-7,
    "objective_and_metric_absolute_error_limit": 3.0e-9,
}
PORTABILITY_PROBE_EXECUTION_ID = (
    "DAILY_CAMELS_KNET_FIXED_FULL_TRAINING_COVERAGE_"
    "A37_A800_PORTABILITY_PROBE2_SEQ57"
)
PORTABILITY_PROBE_DIAGNOSTIC_SHA256 = (
    "00888a1308f000a7337875de19ebf84592fef98989a7d5073a0020b55b4ce436"
)
PORTABILITY_RESULT_59_SHA256 = (
    "798dfea01d82f86a8f0ed93ebb8a73646c632b2703a9bf86f97673350390731d"
)
A37_SOURCE_EXPERIMENT_ID = (
    "DAILY_CAMELS_KNET_FIXED_FULL_TRAINING_COVERAGE_"
    "EPOCH10_TO40_RESUME_V1_20260826_A37"
)
A37_SOURCE_DEVICE = "NVIDIA A800-SXM4-80GB"
A37_SOURCE_COMPLETION_SHA256 = (
    "2b40523a6667ee8794d0c4e705d65711ea1b3d95311b0c3f870ca20d25263c76"
)
A37_SOURCE_RUN_MANIFEST_SHA256 = (
    "bf5ab984bcec6bd6c188548b3177029da1326c7e2d4e6b1fa8b7153d786a425e"
)
GATE_REVISION = {
    "schema_version": "daily_camels_knet_gate_revision_v1",
    "field": "gate.require_same_segment_post_step_improvement",
    "source_value": True,
    "target_value": False,
    "target_role": "diagnostic_only",
    "prospective_only": True,
    "post_hoc_source_reclassification_forbidden": True,
    "source_result_summary_sha256": (
        "e0393fde7084575f89f17e9f64945aafe064c72e3e60f36892376a8965cbb153"
    ),
    "source_optimizer_steps": 40,
    "source_strict_decrease_count": 35,
    "source_not_strictly_decreased_optimizer_steps": [12, 24, 26, 27, 30],
    "retired_cross_device_portability_receipt": True,
    "epoch_zero_reproducibility_migration": {
        "source_device_name": "NVIDIA GeForce RTX 3090",
        "target_device_name": A37_SOURCE_DEVICE,
        "source_checkpoint_objective_728": 0.40192019589669764,
        "target_checkpoint_objective_728": 0.40192019612590385,
        "parameter_sha256": (
            "b4a375c3195cae48c984e9a18cd470746950fda5a5aceec60b6e594f1a352645"
        ),
        "source_prediction_sha256": (
            "17a6f0dbbe145b0262e0b2c1f426c49f1687a29927e8f8348f6ea293e246d91f"
        ),
        "target_prediction_sha256": (
            "0a53b0124662928babe79d7c5959f05538b17c37139bf6cfb5dd3d42f8eb0849"
        ),
        "source_portability_receipt_sha256": (
            "747c304f1ec12d551d4b8b6f6a525fe28c9d757313c9fd009a741f8a3dcfacae"
        ),
    },
}


@dataclass(frozen=True)
class BundleManifest:
    archive_path: Path
    archive_sha256: str
    archive_size: int
    manifest_path: Path
    experiment_id: str
    member_sha256: dict[str, str]
    member_size: dict[str, int]


@dataclass(frozen=True)
class ArchiveInspection:
    payloads: dict[str, bytes]
    manifest: dict[str, Any]


def _json_bytes(payload: Mapping[str, Any]) -> bytes:
    return (
        json.dumps(
            payload,
            allow_nan=False,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        + "\n"
    ).encode("utf-8")


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _validate_digest(value: str, label: str) -> None:
    if len(value) != 64 or any(character not in "0123456789abcdef" for character in value):
        raise ValueError(f"invalid lowercase SHA-256 for {label}")


def _validate_member_name(name: str) -> None:
    if "\\" in name:
        raise ValueError(f"bundle member must use forward slashes: {name}")
    path = PurePosixPath(name)
    if path.is_absolute() or not path.parts or ".." in path.parts:
        raise ValueError(f"unsafe bundle member name: {name}")
    lowered = tuple(part.lower() for part in path.parts)
    canonical = tuple(
        "".join(character for character in part if character.isalnum())
        for part in lowered
    )
    if (
        any("hourly" in part for part in canonical)
        or any("heldout" in part or "reserved" in part for part in canonical)
        or any("formalevaluation" in part for part in canonical)
        or any(part == "evaluation" or part.startswith("evaluation_") for part in lowered)
        or ".git" in lowered
        or "__pycache__" in lowered
    ):
        raise ValueError(f"forbidden bundle member name: {name}")


def _gate_revision_geometry(payload: Mapping[str, Any]) -> dict[str, Any] | None:
    revision = payload.get("gate_revision")
    if revision is None:
        return None
    if not isinstance(revision, Mapping) or dict(revision) != GATE_REVISION:
        raise ValueError("gate revision differs from the frozen prospective contract")
    continuation = payload.get("continuation")
    gate = payload.get("gate")
    if (
        not isinstance(continuation, Mapping)
        or continuation.get("source_experiment_id") != A37_SOURCE_EXPERIMENT_ID
        or continuation.get("completed_epoch") != 40
        or continuation.get("optimizer_steps") != 40
        or continuation.get("sampled_forecast_events") != 306000
        or continuation.get("source_result_summary_sha256")
        != GATE_REVISION["source_result_summary_sha256"]
        or not isinstance(gate, Mapping)
        or gate.get("require_same_segment_post_step_improvement") is not False
        or payload.get("cross_device_portability_receipt") is not None
    ):
        raise ValueError("gate revision source, target, or portability boundary differs")
    return json.loads(json.dumps(dict(revision), allow_nan=False))


def _validate_zero_reserved_access(summary: Mapping[str, Any]) -> int:
    training = summary.get("training")
    if not isinstance(training, Mapping):
        raise ValueError("source result has no training evidence")
    observed: list[int] = []
    for label, ledger in (
        ("top-level", summary.get("access_ledger")),
        ("training", training.get("access_ledger")),
    ):
        if not isinstance(ledger, Mapping):
            raise ValueError(f"{label} reserved evaluation ledger is absent")
        evaluation_keys = sorted(key for key in ledger if "evaluation" in str(key))
        if not evaluation_keys:
            raise ValueError(f"{label} reserved evaluation ledger is incomplete")
        for key in evaluation_keys:
            value = ledger[key]
            if isinstance(value, bool) or not isinstance(value, int) or value != 0:
                raise RuntimeError("reserved evaluation access must remain exactly zero")
            observed.append(value)
    portability = training.get("cross_device_portability")
    if not isinstance(portability, Mapping) or portability.get(
        "reserved_evaluation_operations"
    ) != 0:
        raise RuntimeError("reserved evaluation portability operations must remain zero")
    observed.append(0)
    replays = training.get("same_segment_step_replays")
    if not isinstance(replays, list) or not replays:
        raise ValueError("same-segment replay evidence is absent")
    for replay in replays:
        if not isinstance(replay, Mapping) or replay.get(
            "reserved_evaluation_values_used"
        ) != 0:
            raise RuntimeError("reserved evaluation replay values must remain zero")
        observed.append(0)
        for segment in replay.get("training_segment_replays", []):
            if not isinstance(segment, Mapping) or segment.get(
                "reserved_evaluation_values_used"
            ) != 0:
                raise RuntimeError("reserved evaluation segment values must remain zero")
            observed.append(0)
    return sum(observed)


def _relative_config_member(config_path: Path, root: Path) -> str:
    resolved_root = Path(root).resolve()
    resolved = Path(config_path).resolve()
    try:
        member = resolved.relative_to(resolved_root).as_posix()
    except ValueError as error:
        raise ValueError("active config must be inside the repository root") from error
    _validate_member_name(member)
    if not member.startswith("configs/") or not member.endswith(".json"):
        raise ValueError("active config must be one JSON file below configs/")
    return member


def _load_config(path: Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ValueError("parity config root must be a JSON object")
    return payload


def _continuation_members(payload: Mapping[str, Any]) -> dict[str, str]:
    continuation = payload.get("continuation")
    if continuation is None:
        return {}
    if not isinstance(continuation, Mapping):
        raise ValueError("continuation must be a JSON object")
    required = {
        "schema_version",
        "source_configuration_path",
        "source_configuration_sha256",
        "source_experiment_id",
        "source_identity_sha256",
        "source_device",
        "checkpoint_path",
        "checkpoint_sha256",
        "checkpoint_schema_version",
        "completed_epoch",
        "optimizer_steps",
        "sampled_forecast_events",
        "parameter_sha256",
        "source_epoch_history_sha256",
        "source_result_summary_sha256",
        "source_evidence_archive_sha256",
    }
    if set(continuation) != required:
        raise ValueError("continuation member set changed")
    if continuation.get("schema_version") != CONTINUATION_SCHEMA_VERSION:
        raise ValueError("continuation schema changed")
    if continuation.get("checkpoint_schema_version") != CHECKPOINT_SCHEMA_VERSION:
        raise ValueError("continuation checkpoint schema changed")
    if continuation.get("source_device") != "cuda":
        raise ValueError("continuation source_device must remain cuda")
    if not isinstance(continuation.get("source_experiment_id"), str) or not continuation[
        "source_experiment_id"
    ]:
        raise ValueError("continuation source_experiment_id is absent")

    source_member = str(continuation.get("source_configuration_path", ""))
    checkpoint_member = str(continuation.get("checkpoint_path", ""))
    for member in (source_member, checkpoint_member):
        _validate_member_name(member)
    if not source_member.startswith("configs/") or not source_member.endswith(".json"):
        raise ValueError("continuation source configuration path is invalid")
    if not checkpoint_member.startswith("artifacts/") or not checkpoint_member.endswith(
        ".pt"
    ):
        raise ValueError("continuation checkpoint path is invalid")
    if source_member == checkpoint_member:
        raise ValueError("continuation source config and checkpoint paths collide")

    hashes = {
        source_member: continuation.get("source_configuration_sha256"),
        checkpoint_member: continuation.get("checkpoint_sha256"),
    }
    normalized: dict[str, str] = {}
    for member, value in hashes.items():
        if not isinstance(value, str):
            raise ValueError(f"continuation checkpoint provenance hash is absent: {member}")
        _validate_digest(value, f"continuation checkpoint provenance {member}")
        normalized[member] = value
    for key in (
        "source_identity_sha256",
        "parameter_sha256",
        "source_epoch_history_sha256",
        "source_result_summary_sha256",
        "source_evidence_archive_sha256",
    ):
        value = continuation.get(key)
        if not isinstance(value, str):
            raise ValueError(f"continuation {key} is absent")
        _validate_digest(value, f"continuation {key}")
    for key in ("completed_epoch", "optimizer_steps", "sampled_forecast_events"):
        value = continuation.get(key)
        if isinstance(value, bool) or not isinstance(value, int) or value < 1:
            raise ValueError(f"continuation {key} must be a positive integer")
    optimization = payload.get("optimization")
    if not isinstance(optimization, Mapping):
        raise ValueError("continuation optimization block is absent")
    target_epochs = optimization.get("training_epochs")
    if (
        isinstance(target_epochs, bool)
        or not isinstance(target_epochs, int)
        or target_epochs <= int(continuation["completed_epoch"])
    ):
        raise ValueError("continuation target epoch must exceed completed checkpoint")
    return dict(sorted(normalized.items()))


def _portability_receipt_member(payload: Mapping[str, Any]) -> dict[str, str]:
    declared = payload.get("cross_device_portability_receipt")
    continuation = payload.get("continuation")
    if declared is None:
        if continuation is not None:
            revision = _gate_revision_geometry(payload)
            if revision is None or revision.get(
                "retired_cross_device_portability_receipt"
            ) is not True:
                raise ValueError("checkpoint continuation requires portability evidence")
        return {}
    if not isinstance(declared, Mapping) or set(declared) != {
        "member",
        "sha256",
        "source_device_name",
        "target_device_name",
        "prediction_maximum_absolute_error_limit",
        "prediction_maximum_relative_error_limit",
        "objective_and_metric_absolute_error_limit",
    }:
        raise ValueError("portability receipt declaration changed")
    member = str(declared.get("member", ""))
    _validate_member_name(member)
    if not member.startswith(
        "artifacts/daily_camels_knet_a37_portability_contract/"
    ) or not member.endswith(".json"):
        raise ValueError("portability receipt member is not allowlisted")
    digest = declared.get("sha256")
    if not isinstance(digest, str):
        raise ValueError("portability receipt SHA-256 is absent")
    _validate_digest(digest, "portability receipt")
    if (
        declared.get("source_device_name") != PORTABILITY_SOURCE_DEVICE
        or declared.get("target_device_name") != PORTABILITY_TARGET_DEVICE
    ):
        raise ValueError("portability receipt device pair changed")
    for key, expected in PORTABILITY_THRESHOLDS.items():
        value = declared.get(key)
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError(f"portability threshold is not numeric: {key}")
        if not math.isfinite(float(value)) or float(value) != expected:
            raise ValueError(f"portability threshold changed: {key}")
    return {member: digest}


def _validate_portability_receipt_payload(
    config: Mapping[str, Any],
    receipt: Mapping[str, Any],
) -> None:
    required = {
        "allowed_scope",
        "exact_invariants",
        "experiment_id",
        "measurement",
        "new_optimizer_steps",
        "new_sampled_forecast_events",
        "prediction_file_hash_policy",
        "probe_diagnostic_sha256",
        "probe_execution_id",
        "probe_slurm_job_id",
        "reserved_evaluation_operations",
        "result_59_sha256",
        "schema_version",
        "source_checkpoint_sha256",
        "status",
        "thresholds",
    }
    if set(receipt) != required:
        raise ValueError("portability receipt evidence inventory changed")
    if (
        receipt.get("schema_version") != PORTABILITY_CONTRACT_SCHEMA_VERSION
        or receipt.get("status") != PORTABILITY_CONTRACT_STATUS
        or receipt.get("experiment_id") != config.get("experiment_id")
        or receipt.get("probe_execution_id") != PORTABILITY_PROBE_EXECUTION_ID
        or str(receipt.get("probe_slurm_job_id")) != "215366"
        or receipt.get("probe_diagnostic_sha256")
        != PORTABILITY_PROBE_DIAGNOSTIC_SHA256
        or receipt.get("result_59_sha256") != PORTABILITY_RESULT_59_SHA256
    ):
        raise RuntimeError("portability receipt evidence identity changed")
    continuation = config.get("continuation")
    if not isinstance(continuation, Mapping) or receipt.get(
        "source_checkpoint_sha256"
    ) != continuation.get("checkpoint_sha256"):
        raise RuntimeError("portability receipt checkpoint identity changed")
    if any(
        receipt.get(key) != 0
        for key in (
            "new_optimizer_steps",
            "new_sampled_forecast_events",
            "reserved_evaluation_operations",
        )
    ):
        raise RuntimeError("portability probe performed a forbidden operation")
    scope = receipt.get("allowed_scope")
    if not isinstance(scope, Mapping) or (
        scope.get("basin_id") != "09035800"
        or scope.get("cadence") != "daily"
        or scope.get("checkpoint_completed_epoch") != 10
        or scope.get("forecast_leads_days") != [1, 2, 3]
        or scope.get("source_device_name") != PORTABILITY_SOURCE_DEVICE
        or scope.get("target_device_name") != PORTABILITY_TARGET_DEVICE
    ):
        raise RuntimeError("portability receipt scope changed")
    exact = receipt.get("exact_invariants")
    if not isinstance(exact, Mapping) or exact.get(
        "development_target_count_per_lead"
    ) != 712:
        raise RuntimeError("portability exact geometry changed")
    for key in (
        "checkpoint_sha256",
        "configuration_sha256",
        "model_parameter_sha256",
        "optimizer_state_after_device_normalization",
        "prediction_reference_sha256_before_loading",
        "target_index_and_mask_arrays",
    ):
        if exact.get(key) is not True:
            raise RuntimeError(f"portability exact invariant changed: {key}")
    if exact.get("random_states") != [
        "python",
        "numpy",
        "torch_cpu",
        "torch_cuda",
        "sampler_generator",
    ]:
        raise RuntimeError("portability random-state evidence changed")
    thresholds = receipt.get("thresholds")
    declared = config.get("cross_device_portability_receipt")
    if not isinstance(thresholds, Mapping) or not isinstance(declared, Mapping):
        raise ValueError("portability thresholds are absent")
    if thresholds.get("relative_error_denominator_floor") != 1.0e-12:
        raise RuntimeError("portability relative-error floor changed")
    for key, expected in PORTABILITY_THRESHOLDS.items():
        if thresholds.get(key) != expected or declared.get(key) != expected:
            raise RuntimeError(f"portability threshold changed: {key}")
    measurement = receipt.get("measurement")
    if not isinstance(measurement, Mapping) or set(measurement) != {
        "epoch_zero",
        "completed_epoch",
    }:
        raise ValueError("portability measurement boundaries changed")
    for boundary in ("epoch_zero", "completed_epoch"):
        values = measurement.get(boundary)
        if not isinstance(values, Mapping):
            raise ValueError("portability measurement is absent")
        for key, limit in (
            (
                "maximum_absolute_prediction_error",
                PORTABILITY_THRESHOLDS[
                    "prediction_maximum_absolute_error_limit"
                ],
            ),
            (
                "maximum_relative_prediction_error_with_1e_12_floor",
                PORTABILITY_THRESHOLDS[
                    "prediction_maximum_relative_error_limit"
                ],
            ),
            (
                "maximum_absolute_development_metric_delta_712",
                PORTABILITY_THRESHOLDS[
                    "objective_and_metric_absolute_error_limit"
                ],
            ),
            (
                "objective_absolute_delta_728",
                PORTABILITY_THRESHOLDS[
                    "objective_and_metric_absolute_error_limit"
                ],
            ),
        ):
            value = values.get(key)
            if (
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not math.isfinite(float(value))
                or float(value) < 0.0
                or float(value) > limit
            ):
                raise RuntimeError("portability measurement exceeds frozen limit")


def _continuation_reference_members(payload: Mapping[str, Any]) -> tuple[str, ...]:
    continuation = payload.get("continuation")
    if continuation is None:
        return ()
    if not isinstance(continuation, Mapping):
        raise ValueError("continuation must be a JSON object")
    checkpoint_member = PurePosixPath(str(continuation["checkpoint_path"]))
    if checkpoint_member.parent.name != "checkpoints":
        raise ValueError("continuation checkpoint directory changed")
    completed_epoch = int(continuation["completed_epoch"])
    source_run = checkpoint_member.parent.parent
    source_experiment_id = str(continuation["source_experiment_id"])
    if source_experiment_id == A37_SOURCE_EXPERIMENT_ID:
        return _continuation_source_evidence_members(payload)
    if source_experiment_id != A16_SOURCE_EXPERIMENT_ID:
        raise ValueError("continuation source device provenance is not allowlisted")
    members = (
        (source_run / "epoch_history.json").as_posix(),
        (source_run / "predictions" / "epoch_000.npz").as_posix(),
        (
            source_run
            / "predictions"
            / f"epoch_{completed_epoch:03d}.npz"
        ).as_posix(),
        (
            source_run.parent
            / "status"
            / (
                f"train-preflight-{source_experiment_id}-"
                f"{A16_SOURCE_SLURM_JOB_ID}.json"
            )
        ).as_posix(),
    )
    for member in members:
        _validate_member_name(member)
    if len(set(members)) != len(members):
        raise ValueError("continuation prediction reference members collide")
    return tuple(sorted(members))


def _continuation_source_evidence_members(
    payload: Mapping[str, Any],
) -> tuple[str, ...]:
    continuation = payload.get("continuation")
    if not isinstance(continuation, Mapping) or continuation.get(
        "source_experiment_id"
    ) != A37_SOURCE_EXPERIMENT_ID:
        return ()
    checkpoint = PurePosixPath(str(continuation.get("checkpoint_path", "")))
    if (
        checkpoint.parent.name != "checkpoints"
        or checkpoint.name != "epoch_040.pt"
        or continuation.get("completed_epoch") != 40
    ):
        raise ValueError("A37 continuation must use the pinned epoch-40 checkpoint")
    source_run = checkpoint.parent.parent
    members = tuple(
        (source_run / name).as_posix()
        for name in (
            "epoch_history.json",
            "result_summary.json",
            "experiment_identity.json",
            "completion.marker.json",
            "manifest.sha256.json",
        )
    )
    for member in members:
        _validate_member_name(member)
    if len(set(members)) != len(members):
        raise ValueError("A37 continuation source evidence members collide")
    return tuple(sorted(members))


def _validate_continuation_source_evidence(
    payload: Mapping[str, Any],
    source_paths: Mapping[str, Path],
) -> Mapping[str, Any]:
    revision = _gate_revision_geometry(payload)
    continuation = payload.get("continuation")
    if revision is None or not isinstance(continuation, Mapping):
        raise ValueError("A37 continuation gate revision is absent")
    members = _continuation_source_evidence_members(payload)
    by_name = {PurePosixPath(member).name: member for member in members}
    paths = {name: Path(source_paths[member]) for name, member in by_name.items()}
    expected_hashes = {
        "epoch_history.json": continuation["source_epoch_history_sha256"],
        "result_summary.json": continuation["source_result_summary_sha256"],
        "experiment_identity.json": continuation["source_identity_sha256"],
        "completion.marker.json": A37_SOURCE_COMPLETION_SHA256,
        "manifest.sha256.json": A37_SOURCE_RUN_MANIFEST_SHA256,
    }
    for name, expected in expected_hashes.items():
        _validate_digest(str(expected), f"A37 source {name}")
        if sha256_file(paths[name]) != expected:
            raise RuntimeError(f"A37 continuation source {name} SHA-256 mismatch")

    history = json.loads(paths["epoch_history.json"].read_text(encoding="utf-8"))
    if (
        not isinstance(history, list)
        or len(history) != 41
        or [row.get("epoch") for row in history if isinstance(row, Mapping)]
        != list(range(41))
    ):
        raise RuntimeError("A37 continuation source epoch history is not 0 through 40")
    completed = history[-1]
    if (
        not isinstance(completed, Mapping)
        or completed.get("optimizer_steps") != continuation.get("optimizer_steps")
        or completed.get("parameter_sha256") != continuation.get("parameter_sha256")
    ):
        raise RuntimeError("A37 continuation source epoch-40 history differs")

    summary = json.loads(paths["result_summary.json"].read_text(encoding="utf-8"))
    if not isinstance(summary, Mapping):
        raise ValueError("A37 source result summary must be an object")
    training = summary.get("training")
    if (
        summary.get("experiment_id") != A37_SOURCE_EXPERIMENT_ID
        or summary.get("identity_sha256") != continuation.get("source_identity_sha256")
        or summary.get("status") != "TRAINING_COMPLETE_GATE_FAIL"
        or not isinstance(training, Mapping)
        or training.get("status") != "TRAINING_COMPLETE_GATE_FAIL"
        or training.get("optimizer_steps") != continuation.get("optimizer_steps")
        or training.get("sampled_forecast_events")
        != continuation.get("sampled_forecast_events")
        or training.get("last_checkpoint_sha256") != continuation.get("checkpoint_sha256")
        or training.get("last_parameter_sha256") != continuation.get("parameter_sha256")
        or training.get("cumulative_history_epoch_count") != 41
        or training.get("failed_gates") != ["same_segment_post_step_improvement"]
    ):
        raise RuntimeError("A37 continuation source result identity or counts differ")
    replays = training.get("same_segment_step_replays")
    if not isinstance(replays, list) or len(replays) != 40:
        raise RuntimeError("A37 continuation source replay count differs")
    failed_steps = [
        replay.get("optimizer_step")
        for replay in replays
        if isinstance(replay, Mapping)
        and replay.get("strict_objective_decrease") is not True
    ]
    strict_count = sum(
        1
        for replay in replays
        if isinstance(replay, Mapping)
        and replay.get("strict_objective_decrease") is True
    )
    if (
        strict_count != revision["source_strict_decrease_count"]
        or failed_steps
        != revision["source_not_strictly_decreased_optimizer_steps"]
    ):
        raise RuntimeError("A37 continuation source gate revision facts differ")
    reserved_count = _validate_zero_reserved_access(summary)

    identity = json.loads(paths["experiment_identity.json"].read_text(encoding="utf-8"))
    if not isinstance(identity, Mapping) or (
        identity.get("experiment_id") != A37_SOURCE_EXPERIMENT_ID
        or identity.get("configuration_sha256")
        != continuation.get("source_configuration_sha256")
        or identity.get("phase") != "train"
    ):
        raise RuntimeError("A37 continuation source experiment identity differs")
    completion = json.loads(paths["completion.marker.json"].read_text(encoding="utf-8"))
    if not isinstance(completion, Mapping) or (
        completion.get("experiment_id") != A37_SOURCE_EXPERIMENT_ID
        or completion.get("identity_sha256") != continuation.get("source_identity_sha256")
        or completion.get("summary_sha256")
        != continuation.get("source_result_summary_sha256")
        or completion.get("manifest_sha256") != A37_SOURCE_RUN_MANIFEST_SHA256
        or completion.get("status") != "TRAINING_COMPLETE_GATE_FAIL"
    ):
        raise RuntimeError("A37 continuation completion marker differs")
    run_manifest = json.loads(paths["manifest.sha256.json"].read_text(encoding="utf-8"))
    files = run_manifest.get("files") if isinstance(run_manifest, Mapping) else None
    if not isinstance(files, Mapping) or (
        run_manifest.get("experiment_id") != A37_SOURCE_EXPERIMENT_ID
        or run_manifest.get("identity_sha256") != continuation.get("source_identity_sha256")
        or files.get("epoch_history.json") != continuation.get("source_epoch_history_sha256")
        or files.get("result_summary.json")
        != continuation.get("source_result_summary_sha256")
        or files.get("experiment_identity.json")
        != continuation.get("source_identity_sha256")
        or files.get("checkpoints/epoch_040.pt")
        != continuation.get("checkpoint_sha256")
    ):
        raise RuntimeError("A37 continuation run manifest differs")
    source_device = training.get("cross_device_portability", {}).get(
        "target_device_name"
    )
    if source_device != A37_SOURCE_DEVICE:
        raise RuntimeError("A37 continuation source device differs")
    return {
        "source_epoch_history_member": by_name["epoch_history.json"],
        "source_epoch_history_sha256": expected_hashes["epoch_history.json"],
        "source_result_summary_member": by_name["result_summary.json"],
        "source_result_summary_sha256": expected_hashes["result_summary.json"],
        "source_identity_member": by_name["experiment_identity.json"],
        "source_identity_sha256": expected_hashes["experiment_identity.json"],
        "source_completion_marker_member": by_name["completion.marker.json"],
        "source_completion_marker_sha256": expected_hashes["completion.marker.json"],
        "source_run_manifest_member": by_name["manifest.sha256.json"],
        "source_run_manifest_sha256": expected_hashes["manifest.sha256.json"],
        "source_device_name": source_device,
        "completed_epoch": 40,
        "optimizer_steps": 40,
        "sampled_forecast_events": 306000,
        "parameter_sha256": continuation["parameter_sha256"],
        "status": "TRAINING_COMPLETE_GATE_FAIL",
        "failed_gates": ["same_segment_post_step_improvement"],
        "strict_decrease_count": strict_count,
        "not_strictly_decreased_optimizer_steps": failed_steps,
        "reserved_evaluation_access_count": reserved_count,
        "array_members_materialized_during_build": 0,
    }


def _validate_continuation_reference_sources(
    payload: Mapping[str, Any],
    source_paths: Mapping[str, Path],
) -> Mapping[str, Any] | None:
    continuation = payload.get("continuation")
    if continuation is None:
        return None
    if not isinstance(continuation, Mapping):
        raise ValueError("continuation must be a JSON object")
    if continuation.get("source_experiment_id") == A37_SOURCE_EXPERIMENT_ID:
        return _validate_continuation_source_evidence(payload, source_paths)
    reference_members = _continuation_reference_members(payload)
    history_member = next(
        member for member in reference_members if member.endswith("/epoch_history.json")
    )
    epoch_zero_member = next(
        member for member in reference_members if member.endswith("/epoch_000.npz")
    )
    completed_epoch = int(continuation["completed_epoch"])
    completed_epoch_member = next(
        member
        for member in reference_members
        if member.endswith(f"/epoch_{completed_epoch:03d}.npz")
    )
    source_device_member = next(
        member
        for member in reference_members
        if "/status/train-preflight-" in member
    )
    history_path = Path(source_paths[history_member])
    expected_history_sha256 = str(continuation["source_epoch_history_sha256"])
    if sha256_file(history_path) != expected_history_sha256:
        raise RuntimeError("continuation source epoch history SHA-256 mismatch")
    with history_path.open("r", encoding="utf-8") as handle:
        history = json.load(handle)
    if not isinstance(history, list):
        raise ValueError("continuation source epoch history must be a JSON list")
    if len(history) != completed_epoch + 1:
        raise RuntimeError("continuation source epoch history length changed")
    if [row.get("epoch") for row in history] != list(range(completed_epoch + 1)):
        raise RuntimeError("continuation source epoch history is not contiguous")
    epoch_zero = history[0]
    completed = history[-1]
    if not isinstance(epoch_zero, Mapping) or not isinstance(completed, Mapping):
        raise TypeError("continuation source epoch history rows must be objects")
    epoch_zero_anchor = payload.get("epoch_zero_reproducibility")
    if not isinstance(epoch_zero_anchor, Mapping):
        raise ValueError("continuation epoch-zero reproducibility anchor is absent")
    expected_epoch_zero_sha256 = str(epoch_zero_anchor["prediction_sha256"])
    expected_completed_sha256 = str(completed["fixed_window_prediction_sha256"])
    for digest, label in (
        (expected_epoch_zero_sha256, "epoch-zero prediction reference"),
        (expected_completed_sha256, "completed-epoch prediction reference"),
    ):
        _validate_digest(digest, label)
    if epoch_zero.get("fixed_window_prediction_sha256") != expected_epoch_zero_sha256:
        raise RuntimeError("epoch-zero source history prediction SHA-256 changed")
    if epoch_zero.get("parameter_sha256") != epoch_zero_anchor.get(
        "parameter_sha256"
    ):
        raise RuntimeError("epoch-zero source history parameter SHA-256 changed")
    if float(
        epoch_zero.get(
            "checkpoint_selection_objective_728_origins_without_warmup"
        )
    ) != float(epoch_zero_anchor.get("checkpoint_objective_728")):
        raise RuntimeError("epoch-zero source history objective changed")
    if completed.get("parameter_sha256") != continuation.get("parameter_sha256"):
        raise RuntimeError("completed-epoch source history parameter SHA-256 changed")
    actual_epoch_zero_sha256 = sha256_file(Path(source_paths[epoch_zero_member]))
    actual_completed_sha256 = sha256_file(
        Path(source_paths[completed_epoch_member])
    )
    if actual_epoch_zero_sha256 != expected_epoch_zero_sha256:
        raise RuntimeError("epoch-zero prediction reference SHA-256 mismatch")
    if actual_completed_sha256 != expected_completed_sha256:
        raise RuntimeError("completed-epoch prediction reference SHA-256 mismatch")
    actual_source_device_sha256 = sha256_file(Path(source_paths[source_device_member]))
    if actual_source_device_sha256 != A16_SOURCE_DEVICE_PROVENANCE_SHA256:
        raise RuntimeError("source device provenance SHA-256 mismatch")
    source_device = _load_config(Path(source_paths[source_device_member]))
    if (
        source_device.get("experiment_id") != continuation.get("source_experiment_id")
        or source_device.get("slurm_job_id") != A16_SOURCE_SLURM_JOB_ID
        or source_device.get("hostname") != "ngu011"
        or source_device.get("cuda_probe_without_torch_import", {}).get("device_name")
        != "NVIDIA GeForce RTX 3090"
    ):
        raise RuntimeError("source device provenance identity changed")
    return {
        "source_epoch_history_member": history_member,
        "source_epoch_history_sha256": expected_history_sha256,
        "epoch_zero_prediction_member": epoch_zero_member,
        "epoch_zero_prediction_sha256": expected_epoch_zero_sha256,
        "completed_epoch": completed_epoch,
        "completed_epoch_prediction_member": completed_epoch_member,
        "completed_epoch_prediction_sha256": expected_completed_sha256,
        "source_device_provenance_member": source_device_member,
        "source_device_provenance_sha256": A16_SOURCE_DEVICE_PROVENANCE_SHA256,
        "source_device_name": "NVIDIA GeForce RTX 3090",
        "source_hostname": "ngu011",
        "source_slurm_job_id": A16_SOURCE_SLURM_JOB_ID,
        "array_members_materialized_during_build": 0,
    }


def _validate_config(payload: Mapping[str, Any]) -> tuple[str, str]:
    experiment_id = str(payload.get("experiment_id", ""))
    if not EXPERIMENT_ID_PATTERN.fullmatch(experiment_id):
        raise ValueError("active config has an unsafe or missing experiment_id")
    if payload.get("schema_version") != "daily_camels_ukf_knet_parity_v1":
        raise ValueError("active config schema changed")
    data = payload.get("data")
    forecast = payload.get("forecast")
    initialization = payload.get("initialization")
    model = payload.get("model")
    optimization = payload.get("optimization")
    execution_policy = payload.get("execution_policy")
    gate = payload.get("gate")
    if not all(
        isinstance(item, Mapping)
        for item in (
            data,
            forecast,
            initialization,
            model,
            optimization,
            execution_policy,
            gate,
        )
    ):
        raise ValueError("active config sections are incomplete")
    if (
        payload.get("basin_id") != "09035800"
        or data.get("cadence") != "daily"
        or data.get("archive_path") != ARCHIVE_MEMBER
        or data.get("tukf06_selection_path") != SELECTION_MEMBER
        or data.get("tukf06_contract_path") != TUKF06_CONTRACT_MEMBER
        or forecast.get("recovery_window_days") != 731
        or forecast.get("filter_warmup_days") != 16
        or forecast.get("expected_recovery_target_count_per_lead") != 712
        or model.get("state_dimension") != 18
        or model.get("numeric_dtype") != "float64"
        or model.get("gain_network_numeric_dtype") != "float32"
        or model.get("gain_initialization")
        not in {"native_default", "near_zero_fc2_head"}
        or model.get(
            "correction_scope", "full_eighteen_dimensional_state_correction"
        )
        not in {
            "full_eighteen_dimensional_state_correction",
            "hbv_lite_five_storage_state_correction",
        }
        or optimization.get("training_objective") != "physical_unit_multilead_mse"
        or optimization.get("checkpoint_objective") != "physical_unit_multilead_mse"
        or optimization.get("lead_weights") != [1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0]
    ):
        raise ValueError(
            "active config differs from the daily 09035800 parity geometry, "
            "effective correction scope, or equal-lead loss"
        )
    mode = str(initialization.get("execution_mode", ""))
    if mode not in {
        "exact_tukf06_backward_time_diagnostic",
        "causal_shared_spinup",
    }:
        raise ValueError("active config initialization mode is not allowlisted")
    continuation_members = _continuation_members(payload)
    gate_revision = _gate_revision_geometry(payload)
    if continuation_members and (
        mode != "causal_shared_spinup"
        or execution_policy.get("allow_training") is not True
    ):
        raise ValueError("checkpoint continuation requires authorized causal training")
    if (
        mode == "causal_shared_spinup"
        and execution_policy.get("allow_training") is True
        and gate.get("require_better_than_strict_zero_gain_each_lead") is not True
    ):
        raise ValueError(
            "causal training must require every lead to beat strict zero gain"
        )
    if (
        mode == "causal_shared_spinup"
        and execution_policy.get("allow_training") is True
        and gate.get("require_zero_reserved_data_access") is not True
    ):
        raise ValueError("causal training must require zero reserved data access")
    if gate_revision is not None and not continuation_members:
        raise ValueError("gate revision requires checkpoint continuation")
    for path_key, hash_key, expected_member in (
        ("archive_path", "archive_sha256", ARCHIVE_MEMBER),
        ("tukf06_selection_path", "tukf06_selection_sha256", SELECTION_MEMBER),
        ("tukf06_contract_path", "tukf06_contract_sha256", TUKF06_CONTRACT_MEMBER),
    ):
        if data.get(path_key) != expected_member:
            raise ValueError(f"active config path changed: {path_key}")
        expected = FROZEN_EVIDENCE_HASHES[expected_member]
        if data.get(hash_key) != expected:
            raise ValueError(f"active config frozen evidence hash changed: {hash_key}")
    source_hashes = payload.get("source_sha256")
    if not isinstance(source_hashes, Mapping):
        raise ValueError("active config source_sha256 is absent")
    for name, expected in PINNED_SCIENCE_SOURCE_HASHES.items():
        if source_hashes.get(name) != expected:
            raise ValueError(f"active config science source hash changed: {name}")
    return experiment_id, mode


def bundle_member_sources(
    root: Path = ROOT,
    *,
    config_path: Path,
    exact_config_path: Path = DEFAULT_EXACT_CONFIG,
) -> tuple[dict[str, Path], str, str, str, str]:
    project_root = Path(root).resolve()
    active_member = _relative_config_member(config_path, project_root)
    active_payload = _load_config(project_root / active_member)
    experiment_id, mode = _validate_config(active_payload)
    exact_member = _relative_config_member(exact_config_path, project_root)
    exact_payload = _load_config(project_root / exact_member)
    _, exact_mode = _validate_config(exact_payload)
    if exact_mode != "exact_tukf06_backward_time_diagnostic":
        raise ValueError("the selected replay config is not the exact diagnostic")

    mapping = dict(FIXED_SOURCE_MEMBER_PATHS)
    mapping[exact_member] = exact_member
    mapping[active_member] = active_member
    for member in _continuation_members(active_payload):
        if member in mapping:
            raise ValueError(f"continuation bundle member collides: {member}")
        mapping[member] = member
    for member in _continuation_reference_members(active_payload):
        if member in mapping:
            raise ValueError(
                f"continuation reference bundle member collides: {member}"
            )
        mapping[member] = member
    for member in _portability_receipt_member(active_payload):
        if member in mapping:
            raise ValueError(f"portability receipt bundle member collides: {member}")
        mapping[member] = member
    sources = {name: project_root / relative for name, relative in mapping.items()}
    _validate_source_inventory(sources, expected_names=set(mapping))
    return (
        dict(sorted(sources.items())),
        active_member,
        exact_member,
        experiment_id,
        mode,
    )


def _validate_source_inventory(
    source_paths: Mapping[str, Path], *, expected_names: set[str]
) -> None:
    if set(source_paths) != expected_names:
        missing = sorted(expected_names - set(source_paths))
        extra = sorted(set(source_paths) - expected_names)
        raise ValueError(f"bundle source allowlist differs; missing={missing}, extra={extra}")
    for name, source in source_paths.items():
        _validate_member_name(name)
        path = Path(source)
        if not path.is_file():
            raise FileNotFoundError(f"bundle source is absent: {name} <- {path}")
        if path.is_symlink():
            raise RuntimeError(f"bundle source may not be a symbolic link: {name}")


def _verify_frozen_hashes(source_paths: Mapping[str, Path]) -> None:
    for name, expected in sorted(
        {**FROZEN_EVIDENCE_HASHES, **PINNED_SCIENCE_SOURCE_HASHES}.items()
    ):
        _validate_digest(expected, name)
        actual = sha256_file(Path(source_paths[name]))
        if actual != expected:
            raise RuntimeError(
                f"frozen SHA-256 mismatch for {name}: expected {expected}, got {actual}"
            )


def _entry_integration_hashes(source_paths: Mapping[str, Path]) -> dict[str, str]:
    entry_name = "scripts/run_daily_camels_ukf_knet_parity.py"
    tree = ast.parse(Path(source_paths[entry_name]).read_text(encoding="utf-8"))
    literals: dict[str, str] = {}
    required_constants = set(ENTRY_INTEGRATION_HASH_CONSTANTS.values())
    for node in tree.body:
        if (
            isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id in required_constants
        ):
            value = ast.literal_eval(node.value)
            if not isinstance(value, str):
                raise ValueError(f"entry integration hash is not text: {node.targets[0].id}")
            literals[node.targets[0].id] = value
    if set(literals) != required_constants:
        raise ValueError("entry integration hash constants are incomplete")
    result: dict[str, str] = {}
    for name, constant in ENTRY_INTEGRATION_HASH_CONSTANTS.items():
        expected = literals[constant]
        _validate_digest(expected, constant)
        actual = sha256_file(Path(source_paths[name]))
        if actual != expected:
            raise RuntimeError(
                f"entry integration SHA-256 mismatch for {name}: "
                f"expected {expected}, got {actual}"
            )
        result[name] = expected
    return dict(sorted(result.items()))


def _validate_text_payload(name: str, content: bytes) -> None:
    if PurePosixPath(name).suffix.lower() not in TEXT_SUFFIXES:
        return
    if b"\x00" in content:
        raise RuntimeError(f"text bundle member contains a null byte: {name}")
    if WINDOWS_ABSOLUTE_PATH.search(content) and name not in WINDOWS_PATH_ALLOWED_MEMBERS:
        raise RuntimeError(f"text bundle member contains a Windows absolute path: {name}")


def _payloads(
    source_paths: Mapping[str, Path],
    *,
    active_config_member: str,
    exact_config_member: str,
    experiment_id: str,
    initialization_mode: str,
) -> tuple[dict[str, bytes], dict[str, Any]]:
    active_payload = _load_config(Path(source_paths[active_config_member]))
    continuation_members = _continuation_members(active_payload)
    continuation_reference_members = _continuation_reference_members(active_payload)
    portability_members = _portability_receipt_member(active_payload)
    expected_names = set(FIXED_SOURCE_MEMBER_PATHS) | {
        active_config_member,
        exact_config_member,
    } | set(continuation_members) | set(continuation_reference_members) | set(
        portability_members
    )
    _validate_source_inventory(source_paths, expected_names=expected_names)
    _verify_frozen_hashes(source_paths)
    entry_integration_hashes = _entry_integration_hashes(source_paths)
    for name, expected in continuation_members.items():
        actual = sha256_file(Path(source_paths[name]))
        if actual != expected:
            raise RuntimeError(
                f"continuation checkpoint provenance SHA-256 mismatch for {name}: "
                f"expected {expected}, got {actual}"
            )
    for name, expected in portability_members.items():
        actual = sha256_file(Path(source_paths[name]))
        if actual != expected:
            raise RuntimeError(
                f"portability receipt SHA-256 mismatch for {name}: "
                f"expected {expected}, got {actual}"
            )
        with Path(source_paths[name]).open("r", encoding="utf-8") as handle:
            receipt_payload = json.load(handle)
        if not isinstance(receipt_payload, Mapping):
            raise ValueError("portability receipt root must be a JSON object")
        _validate_portability_receipt_payload(active_payload, receipt_payload)
    continuation_references = _validate_continuation_reference_sources(
        active_payload,
        source_paths,
    )
    is_a37_source = (
        isinstance(active_payload.get("continuation"), Mapping)
        and active_payload["continuation"].get("source_experiment_id")
        == A37_SOURCE_EXPERIMENT_ID
    )
    gate_revision = _gate_revision_geometry(active_payload)
    resume_members = sorted(
        name for name in source_paths if PurePosixPath(name).suffix == ".pt"
    )
    expected_resume_members = sorted(
        name for name in continuation_members if PurePosixPath(name).suffix == ".pt"
    )
    if resume_members != expected_resume_members or len(resume_members) not in {0, 1}:
        raise RuntimeError("bundle must contain exactly the declared resume checkpoint")
    declared_source_hashes = active_payload.get("source_sha256")
    if not isinstance(declared_source_hashes, Mapping) or not declared_source_hashes:
        raise ValueError("active config has no declared source hash inventory")
    for name, expected_value in sorted(declared_source_hashes.items()):
        expected = str(expected_value)
        _validate_digest(expected, str(name))
        if name not in source_paths:
            raise ValueError(f"active config source is outside the bundle allowlist: {name}")
        actual = sha256_file(Path(source_paths[name]))
        if actual != expected:
            raise RuntimeError(
                f"active config source SHA-256 mismatch for {name}: "
                f"expected {expected}, got {actual}"
            )
    payloads = {
        name: Path(source_paths[name]).read_bytes() for name in sorted(source_paths)
    }
    payloads.update({name: b"" for name in EMPTY_PACKAGE_MEMBERS})
    for name, content in payloads.items():
        _validate_member_name(name)
        _validate_text_payload(name, content)
    member_sha256 = {
        name: sha256(content).hexdigest() for name, content in sorted(payloads.items())
    }
    member_size = {name: len(content) for name, content in sorted(payloads.items())}
    manifest = {
        "schema_version": "daily_camels_ukf_knet_parity_hpc_bundle_v1",
        "experiment_id": experiment_id,
        "active_config_member": active_config_member,
        "exact_replay_config_member": exact_config_member,
        "initialization_mode": initialization_mode,
        "purpose": "daily_development_parity_replay_or_causal_training",
        "member_count": len(payloads),
        "input_archive_count": 1,
        "reserved_data_member_count": 0,
        "array_members_materialized_during_build": 0,
        "resume_checkpoint_count": len(resume_members),
        "continuation": (
            dict(active_payload["continuation"])
            if continuation_members
            else None
        ),
        "continuation_prediction_references": (
            None if is_a37_source else continuation_references
        ),
        "continuation_source_evidence": (
            continuation_references if is_a37_source else None
        ),
        "gate_revision": gate_revision,
        "cross_device_portability_receipt": (
            dict(active_payload["cross_device_portability_receipt"])
            if portability_members
            else None
        ),
        "selection_objective": {
            "name": "physical_unit_multilead_mse",
            "filter_warmup_days": 0,
            "common_target_count_per_lead": 728,
        },
        "nse_gate": {
            "filter_warmup_days": 16,
            "common_target_count_per_lead": 712,
            "minimum_exclusive": 0.6,
        },
        "member_sha256": member_sha256,
        "member_size": member_size,
        "frozen_evidence_sha256": dict(sorted(FROZEN_EVIDENCE_HASHES.items())),
        "pinned_science_source_sha256": dict(
            sorted(PINNED_SCIENCE_SOURCE_HASHES.items())
        ),
        "active_config_declared_source_sha256": dict(
            sorted((str(name), str(value)) for name, value in declared_source_hashes.items())
        ),
        "entry_integration_source_sha256": entry_integration_hashes,
        "package_initializers": list(EMPTY_PACKAGE_MEMBERS),
    }
    return dict(sorted(payloads.items())), manifest


def _archive_bytes(payloads: Mapping[str, bytes], manifest: Mapping[str, Any]) -> bytes:
    archive_payloads = dict(payloads)
    archive_payloads["bundle_manifest.json"] = _json_bytes(manifest)
    raw = BytesIO()
    with gzip.GzipFile(
        fileobj=raw,
        mode="wb",
        filename="",
        mtime=0,
        compresslevel=9,
    ) as compressed:
        with tarfile.open(fileobj=compressed, mode="w", format=tarfile.USTAR_FORMAT) as archive:
            for name in sorted(archive_payloads):
                content = archive_payloads[name]
                information = tarfile.TarInfo(name=name)
                information.size = len(content)
                information.mtime = 0
                information.uid = 0
                information.gid = 0
                information.uname = ""
                information.gname = ""
                information.mode = 0o755 if name.endswith((".slurm", ".sh")) else 0o644
                archive.addfile(information, BytesIO(content))
    return raw.getvalue()


def inspect_archive(archive_path: Path) -> ArchiveInspection:
    payloads: dict[str, bytes] = {}
    with tarfile.open(Path(archive_path), "r:gz") as archive:
        members = archive.getmembers()
        names = [member.name for member in members]
        if names != sorted(names) or len(names) != len(set(names)):
            raise RuntimeError("archive member order or uniqueness differs")
        for member in members:
            _validate_member_name(member.name)
            if (
                not member.isfile()
                or member.issym()
                or member.islnk()
                or member.uid != 0
                or member.gid != 0
                or member.uname != ""
                or member.gname != ""
                or member.mtime != 0
            ):
                raise RuntimeError(f"archive member metadata differs: {member.name}")
            stream = archive.extractfile(member)
            if stream is None:
                raise RuntimeError(f"archive member cannot be read: {member.name}")
            payloads[member.name] = stream.read()

    content = payloads.get("bundle_manifest.json")
    if content is None:
        raise RuntimeError("archive internal manifest is absent")
    manifest = json.loads(content.decode("utf-8"))
    if not isinstance(manifest, dict):
        raise RuntimeError("archive internal manifest must be a JSON object")
    expected_names = set(manifest.get("member_sha256", {}))
    if set(payloads) != expected_names | {"bundle_manifest.json"}:
        raise RuntimeError("archive inventory differs from internal manifest")
    if (
        manifest.get("schema_version")
        != "daily_camels_ukf_knet_parity_hpc_bundle_v1"
        or manifest.get("input_archive_count") != 1
        or manifest.get("reserved_data_member_count") != 0
        or manifest.get("array_members_materialized_during_build") != 0
    ):
        raise RuntimeError("archive identity or data policy differs")
    continuation = manifest.get("continuation")
    resume_checkpoint_count = manifest.get("resume_checkpoint_count", 0)
    if continuation is None:
        if resume_checkpoint_count != 0:
            raise RuntimeError("archive resume checkpoint count differs")
        if manifest.get("continuation_prediction_references") is not None:
            raise RuntimeError("archive has unexpected continuation references")
        if manifest.get("continuation_source_evidence") is not None:
            raise RuntimeError("archive has unexpected continuation source evidence")
    else:
        if not isinstance(continuation, dict) or resume_checkpoint_count != 1:
            raise RuntimeError("archive continuation provenance differs")
        continuation_members = _continuation_members(
            {
                "continuation": continuation,
                "optimization": {
                    "training_epochs": int(continuation["completed_epoch"]) + 1
                },
            }
        )
        for name, expected in continuation_members.items():
            if manifest["member_sha256"].get(name) != expected:
                raise RuntimeError(
                    f"archive continuation member SHA-256 differs: {name}"
                )
        is_a37_source = continuation.get("source_experiment_id") == A37_SOURCE_EXPERIMENT_ID
        if is_a37_source and manifest.get("continuation_prediction_references") is not None:
            raise RuntimeError("archive A37 source cannot reactivate prediction references")
        if not is_a37_source and manifest.get("continuation_source_evidence") is not None:
            raise RuntimeError("archive A16 source has unexpected terminal evidence")
        references = manifest.get(
            "continuation_source_evidence"
            if is_a37_source
            else "continuation_prediction_references"
        )
        if not isinstance(references, dict):
            raise RuntimeError("archive continuation source references are absent")
        if references.get("array_members_materialized_during_build") != 0:
            raise RuntimeError("archive continuation arrays were materialized")
        reference_pairs = (
            (
                ("source_epoch_history_member", "source_epoch_history_sha256"),
                ("source_result_summary_member", "source_result_summary_sha256"),
                ("source_identity_member", "source_identity_sha256"),
                ("source_completion_marker_member", "source_completion_marker_sha256"),
                ("source_run_manifest_member", "source_run_manifest_sha256"),
            )
            if is_a37_source
            else (
                ("source_epoch_history_member", "source_epoch_history_sha256"),
                ("epoch_zero_prediction_member", "epoch_zero_prediction_sha256"),
                (
                    "completed_epoch_prediction_member",
                    "completed_epoch_prediction_sha256",
                ),
                ("source_device_provenance_member", "source_device_provenance_sha256"),
            )
        )
        for member_key, digest_key in reference_pairs:
            member_name = references.get(member_key)
            expected_digest = references.get(digest_key)
            if not isinstance(member_name, str) or not isinstance(
                expected_digest, str
            ):
                raise RuntimeError("archive continuation reference identity changed")
            if manifest["member_sha256"].get(member_name) != expected_digest:
                raise RuntimeError(
                    f"archive continuation reference SHA-256 differs: {member_name}"
                )
    active_member = manifest.get("active_config_member")
    if not isinstance(active_member, str) or active_member not in payloads:
        raise RuntimeError("archive active config member is absent")
    active_payload = json.loads(payloads[active_member].decode("utf-8"))
    if not isinstance(active_payload, dict):
        raise RuntimeError("archive active config root differs")
    if manifest.get("gate_revision") != _gate_revision_geometry(active_payload):
        raise RuntimeError("archive gate revision differs from active config")
    portability_members = _portability_receipt_member(active_payload)
    portability_declaration = manifest.get("cross_device_portability_receipt")
    if portability_members:
        if portability_declaration != active_payload.get(
            "cross_device_portability_receipt"
        ):
            raise RuntimeError("archive portability declaration changed")
        if len(portability_members) != 1:
            raise RuntimeError("archive portability receipt count differs")
        portability_member, portability_sha256 = next(
            iter(portability_members.items())
        )
        if (
            manifest["member_sha256"].get(portability_member)
            != portability_sha256
        ):
            raise RuntimeError("archive portability receipt SHA-256 differs")
        receipt_content = payloads.get(portability_member)
        if receipt_content is None:
            raise RuntimeError("archive portability receipt is absent")
        receipt_payload = json.loads(receipt_content.decode("utf-8"))
        if not isinstance(receipt_payload, dict):
            raise RuntimeError("archive portability receipt root differs")
        _validate_portability_receipt_payload(active_payload, receipt_payload)
    elif portability_declaration is not None:
        raise RuntimeError("archive has unexpected portability receipt")
    if manifest.get("frozen_evidence_sha256") != FROZEN_EVIDENCE_HASHES:
        raise RuntimeError("archive frozen evidence inventory differs")
    if manifest.get("pinned_science_source_sha256") != PINNED_SCIENCE_SOURCE_HASHES:
        raise RuntimeError("archive pinned source inventory differs")
    declared = manifest.get("active_config_declared_source_sha256")
    if not isinstance(declared, dict) or not declared:
        raise RuntimeError("archive active-config source inventory is absent")
    for name, expected in declared.items():
        if manifest["member_sha256"].get(name) != expected:
            raise RuntimeError(f"archive active-config source hash differs: {name}")
    entry_hashes = manifest.get("entry_integration_source_sha256")
    if not isinstance(entry_hashes, dict) or set(entry_hashes) != set(
        ENTRY_INTEGRATION_HASH_CONSTANTS
    ):
        raise RuntimeError("archive entry integration source inventory differs")
    for name, expected in entry_hashes.items():
        if manifest["member_sha256"].get(name) != expected:
            raise RuntimeError(f"archive entry integration source hash differs: {name}")
    for name in sorted(expected_names):
        member_content = payloads[name]
        if sha256(member_content).hexdigest() != manifest["member_sha256"][name]:
            raise RuntimeError(f"archive member SHA-256 mismatch: {name}")
        if len(member_content) != int(manifest["member_size"][name]):
            raise RuntimeError(f"archive member size mismatch: {name}")
        _validate_text_payload(name, member_content)
    for name in EMPTY_PACKAGE_MEMBERS:
        if payloads.get(name) != b"":
            raise RuntimeError(f"isolated package initializer is not empty: {name}")
    return ArchiveInspection(payloads=payloads, manifest=manifest)


def _write_new_file(path: Path, content: bytes) -> None:
    with Path(path).open("xb") as handle:
        handle.write(content)
        handle.flush()
        os.fsync(handle.fileno())


def _existing_bundle(
    destination: Path,
    *,
    archive_name: str,
    archive_bytes: bytes,
    manifest_bytes: bytes,
) -> BundleManifest | None:
    if not destination.exists():
        return None
    archive_path = destination / archive_name
    manifest_path = destination / "bundle_manifest.sha256.json"
    if (
        not destination.is_dir()
        or not archive_path.is_file()
        or not manifest_path.is_file()
        or archive_path.read_bytes() != archive_bytes
        or manifest_path.read_bytes() != manifest_bytes
        or len(list(destination.iterdir())) != 2
    ):
        raise FileExistsError(f"refusing to replace a different bundle directory: {destination}")
    inspection = inspect_archive(archive_path)
    return BundleManifest(
        archive_path=archive_path,
        archive_sha256=sha256(archive_bytes).hexdigest(),
        archive_size=len(archive_bytes),
        manifest_path=manifest_path,
        experiment_id=str(inspection.manifest["experiment_id"]),
        member_sha256=dict(inspection.manifest["member_sha256"]),
        member_size={
            name: int(size) for name, size in inspection.manifest["member_size"].items()
        },
    )


def build_bundle(
    destination: Path,
    *,
    config_path: Path,
    exact_config_path: Path = DEFAULT_EXACT_CONFIG,
    root: Path = ROOT,
) -> BundleManifest:
    """Create or byte-verify one deterministic bundle in ``destination``."""

    sources, active_member, exact_member, experiment_id, mode = bundle_member_sources(
        root,
        config_path=config_path,
        exact_config_path=exact_config_path,
    )
    payloads, internal_manifest = _payloads(
        sources,
        active_config_member=active_member,
        exact_config_member=exact_member,
        experiment_id=experiment_id,
        initialization_mode=mode,
    )
    archive_name = f"{experiment_id}.tar.gz"
    archive_content = _archive_bytes(payloads, internal_manifest)
    internal_manifest_bytes = _json_bytes(internal_manifest)
    outer_manifest = {
        "schema_version": "daily_camels_ukf_knet_parity_hpc_archive_v1",
        "experiment_id": experiment_id,
        "active_config_member": active_member,
        "exact_replay_config_member": exact_member,
        "initialization_mode": mode,
        "archive_name": archive_name,
        "archive_sha256": sha256(archive_content).hexdigest(),
        "archive_size": len(archive_content),
        "internal_manifest_sha256": sha256(internal_manifest_bytes).hexdigest(),
        "member_count": len(payloads),
        "input_archive_count": 1,
        "reserved_data_member_count": 0,
        "array_members_materialized_during_build": 0,
        "resume_checkpoint_count": internal_manifest["resume_checkpoint_count"],
        "continuation": internal_manifest["continuation"],
        "continuation_source_evidence": internal_manifest[
            "continuation_source_evidence"
        ],
        "gate_revision": internal_manifest["gate_revision"],
        "cross_device_portability_receipt": internal_manifest[
            "cross_device_portability_receipt"
        ],
        "member_sha256": internal_manifest["member_sha256"],
        "member_size": internal_manifest["member_size"],
    }
    outer_bytes = _json_bytes(outer_manifest)

    target = Path(destination)
    existing = _existing_bundle(
        target,
        archive_name=archive_name,
        archive_bytes=archive_content,
        manifest_bytes=outer_bytes,
    )
    if existing is not None:
        return existing

    target.parent.mkdir(parents=True, exist_ok=True)
    pending = target.with_name(target.name + f".p-{uuid.uuid4().hex[:8]}")
    pending.mkdir(parents=False, exist_ok=False)
    pending_archive = pending / archive_name
    pending_manifest = pending / "bundle_manifest.sha256.json"
    try:
        _write_new_file(pending_archive, archive_content)
        _write_new_file(pending_manifest, outer_bytes)
        inspection = inspect_archive(pending_archive)
        if inspection.manifest != internal_manifest:
            raise RuntimeError("pending archive manifest differs")
        if sha256_file(pending_archive) != outer_manifest["archive_sha256"]:
            raise RuntimeError("pending archive SHA-256 differs")
        if target.exists():
            raise FileExistsError(f"refusing to replace an existing bundle: {target}")
        os.replace(pending, target)
    finally:
        if pending.exists():
            for path in (pending_archive, pending_manifest):
                if path.exists():
                    path.unlink()
            pending.rmdir()

    return BundleManifest(
        archive_path=target / archive_name,
        archive_sha256=str(outer_manifest["archive_sha256"]),
        archive_size=len(archive_content),
        manifest_path=target / "bundle_manifest.sha256.json",
        experiment_id=experiment_id,
        member_sha256=dict(internal_manifest["member_sha256"]),
        member_size={name: int(size) for name, size in internal_manifest["member_size"].items()},
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Build a deterministic daily CAMELS UKF/KalmanNet parity HPC bundle."
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument(
        "--exact-config",
        type=Path,
        default=DEFAULT_EXACT_CONFIG,
        help="Exact diagnostic replay config that must accompany the active config.",
    )
    return parser


def main() -> int:
    arguments = build_parser().parse_args()
    result = build_bundle(
        arguments.output_dir,
        config_path=arguments.config,
        exact_config_path=arguments.exact_config,
    )
    print(
        json.dumps(
            {
                "status": "BUNDLE_READY",
                "experiment_id": result.experiment_id,
                "archive_path": str(result.archive_path),
                "archive_sha256": result.archive_sha256,
                "archive_size": result.archive_size,
                "manifest_path": str(result.manifest_path),
                "member_count": len(result.member_sha256),
                "array_members_materialized": 0,
            },
            indent=2,
            sort_keys=True,
        ),
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
