from __future__ import annotations

from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import sys
from unittest.mock import patch

import pytest


ROOT = Path(__file__).resolve().parents[1]
PREFLIGHT_PATH = ROOT / "hpc" / "daily_camels_ukf_knet_parity" / "preflight.py"
MODULE_NAME = "daily_camels_ukf_knet_parity_hpc_preflight_standalone"
BUILDER_PATH = ROOT / "scripts" / "build_daily_camels_ukf_knet_parity_hpc_bundle.py"
BUILDER_MODULE_NAME = "daily_camels_ukf_knet_parity_hpc_builder_standalone"
TRAIN_SLURM_PATH = (
    ROOT / "hpc" / "daily_camels_ukf_knet_parity" / "submit_train_gpu.slurm"
)
PROBE_SLURM_PATH = (
    ROOT / "hpc" / "daily_camels_ukf_knet_parity" / "submit_probe_gpu.slurm"
)
A37_CONFIG = (
    ROOT
    / "configs"
    / "daily_camels_knet_fixed_full_training_coverage_epoch10_to40_resume_a37.json"
)
A38_CONFIG = (
    ROOT
    / "configs"
    / "daily_camels_knet_epoch40_to80_resume_a38.json"
)
A16_CHECKPOINT_MEMBER = (
    "artifacts/daily_camels_ukf_knet_parity_seq15_failure_evidence/"
    "ff2084c4/seq15_snapshot_2831/run/checkpoints/epoch_010.pt"
)
A37_PORTABILITY_RECEIPT_MEMBER = (
    "artifacts/daily_camels_knet_a37_portability_contract/"
    "A37_A800_PORTABILITY_PROBE2_SEQ57_RECEIPT.json"
)
A37_EXPERIMENT_ID = (
    "DAILY_CAMELS_KNET_FIXED_FULL_TRAINING_COVERAGE_"
    "EPOCH10_TO40_RESUME_V1_20260826_A37"
)
A37_EVIDENCE_RUN_MEMBER = (
    "artifacts/daily_camels_knet_a37_train4_terminal_evidence/"
    "job215699/run"
)
A37_EPOCH40_CHECKPOINT_MEMBER = (
    f"{A37_EVIDENCE_RUN_MEMBER}/checkpoints/epoch_040.pt"
)
A37_RESULT_SUMMARY_SHA256 = (
    "e0393fde7084575f89f17e9f64945aafe064c72e3e60f36892376a8965cbb153"
)


def _a38_config_from_a37() -> dict[str, object]:
    config = deepcopy(json.loads(A37_CONFIG.read_text(encoding="utf-8")))
    config["experiment_id"] = (
        "DAILY_CAMELS_KNET_FIXED_FULL_TRAINING_COVERAGE_"
        "EPOCH40_TO80_RESUME_V1_20260828_A38"
    )
    config["optimization"]["training_epochs"] = 80
    config["gate"]["require_same_segment_post_step_improvement"] = False
    config.pop("cross_device_portability_receipt")
    config["continuation"] = {
        "schema_version": "daily_camels_ukf_knet_parity_continuation_v1",
        "source_configuration_path": (
            "configs/daily_camels_knet_fixed_full_training_coverage_"
            "epoch10_to40_resume_a37.json"
        ),
        "source_configuration_sha256": (
            "29b4bdb604f2bfbba5c1ab78576a7a21811cd0fdd75060b2dc328ff608f06f2a"
        ),
        "source_experiment_id": A37_EXPERIMENT_ID,
        "source_identity_sha256": (
            "6015e3473a478d96908ab9eda46e582244968480db592e056ebc51d3842c1e7a"
        ),
        "source_device": "cuda",
        "checkpoint_path": A37_EPOCH40_CHECKPOINT_MEMBER,
        "checkpoint_sha256": (
            "43ed17aaacabdae7e88a80de8567ac3d29d88635d93f701016c757e7f3a407f5"
        ),
        "checkpoint_schema_version": "daily_camels_ukf_knet_parity_checkpoint_v1",
        "completed_epoch": 40,
        "optimizer_steps": 40,
        "sampled_forecast_events": 306000,
        "parameter_sha256": (
            "448a7c8d21c5eaecb21c375f60d873d6c804ad71376a8e3c95a16e71c3bbc72c"
        ),
        "source_epoch_history_sha256": (
            "ec64cd575dc76312ef9beaafa22c19fd0d82dec552405ac9c04923aeae2af636"
        ),
        "source_result_summary_sha256": A37_RESULT_SUMMARY_SHA256,
        "source_evidence_archive_sha256": (
            "ff788c72a9129cddd4e04a7e6c521864b8d02ff6687e8d8e7fb71655491b103b"
        ),
    }
    config["gate_revision"] = {
        "schema_version": "daily_camels_knet_gate_revision_v1",
        "field": "gate.require_same_segment_post_step_improvement",
        "source_value": True,
        "target_value": False,
        "target_role": "diagnostic_only",
        "prospective_only": True,
        "post_hoc_source_reclassification_forbidden": True,
        "source_result_summary_sha256": A37_RESULT_SUMMARY_SHA256,
        "source_optimizer_steps": 40,
        "source_strict_decrease_count": 35,
        "source_not_strictly_decreased_optimizer_steps": [12, 24, 26, 27, 30],
        "retired_cross_device_portability_receipt": True,
        "epoch_zero_reproducibility_migration": {
            "source_device_name": "NVIDIA GeForce RTX 3090",
            "target_device_name": "NVIDIA A800-SXM4-80GB",
            "source_checkpoint_objective_728": 0.40192019589669764,
            "target_checkpoint_objective_728": 0.40192019612590385,
            "parameter_sha256": (
                "b4a375c3195cae48c984e9a18cd470746950fda5a5aceec60b6e594f1a352645"
            ),
            "source_prediction_sha256": (
                "17a6f0dbbe145b0262e0b2c1f426c49f1687a29927e8f8348f6ea293e246d91f"
            ),
            "target_prediction_sha256": (
                "0a53b0124662928babe79d7c5959f05538b17c37139bf6cfb5dd3d42f8eb0849"
            ),
            "source_portability_receipt_sha256": (
                "747c304f1ec12d551d4b8b6f6a525fe28c9d757313c9fd009a741f8a3dcfacae"
            ),
        },
    }
    return config


def _load_preflight_module():
    numerical_before = {name: name in sys.modules for name in ("numpy", "torch")}
    spec = importlib.util.spec_from_file_location(MODULE_NAME, PREFLIGHT_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load daily parity HPC preflight")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    numerical_after = {name: name in sys.modules for name in ("numpy", "torch")}
    assert numerical_after == numerical_before
    return module


PREFLIGHT = _load_preflight_module()


def _load_builder_module():
    numerical_before = {name: name in sys.modules for name in ("numpy", "torch")}
    spec = importlib.util.spec_from_file_location(BUILDER_MODULE_NAME, BUILDER_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load daily parity HPC bundle builder")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    numerical_after = {name: name in sys.modules for name in ("numpy", "torch")}
    assert numerical_after == numerical_before
    return module


BUILDER = _load_builder_module()


def test_bundle_builder_requires_explicit_active_config() -> None:
    action = next(
        item for item in BUILDER.build_parser()._actions if item.dest == "config"
    )
    assert action.required is True
    assert action.default is None


def _training_config_with_replay_identities() -> dict[str, object]:
    path = (
        ROOT
        / "configs/daily_camels_knet_near_zero_strict_smoke_a12.json"
    )
    config = json.loads(path.read_text(encoding="utf-8"))
    config["replay_gate_requirements"] = {
        "exact": {
            "experiment_id": "EXACT_REPLAY_EXPERIMENT",
            "initialization_mode": "exact_tukf06_backward_time_diagnostic",
            "receipt_sha256": "1" * 64,
            "active_config_sha256": "2" * 64,
            "bundle_manifest_sha256": "3" * 64,
        },
        "causal": {
            "experiment_id": "CAUSAL_REPLAY_EXPERIMENT",
            "initialization_mode": "causal_shared_spinup",
            "receipt_sha256": "4" * 64,
            "active_config_sha256": "5" * 64,
            "bundle_manifest_sha256": "6" * 64,
        },
    }
    return config


def test_training_submission_requires_both_current_replay_gate_paths() -> None:
    source = TRAIN_SLURM_PATH.read_text(encoding="utf-8")

    assert source.count("${PARITY_EXACT_REPLAY_GATE") >= 2
    assert source.count("${PARITY_CAUSAL_REPLAY_GATE") >= 2
    assert "replay_gate_DAILY_CAMELS_UKF_PARITY_KNET_FULL_STATE_V1_20260824_A01" not in source
    assert '--exact-replay-gate "${PARITY_EXACT_REPLAY_GATE}"' in source
    assert '--causal-replay-gate "${PARITY_CAUSAL_REPLAY_GATE}"' in source
    assert '["replay_gate_requirements"]["exact"]["receipt_sha256"]' in source
    assert '["replay_gate_requirements"]["causal"]["receipt_sha256"]' in source
    assert 'ACTUAL_EXACT_GATE_SHA256' in source
    assert 'ACTUAL_CAUSAL_GATE_SHA256' in source


def test_training_submission_supports_an_isolated_remote_root_override() -> None:
    expected = (
        'REMOTE_ROOT="${PARITY_REMOTE_ROOT:-/data1/home/sunyiq/'
        'kalmannet_daily_camels_parity_20260824}"'
    )

    assert expected in TRAIN_SLURM_PATH.read_text(encoding="utf-8")
    assert expected in PROBE_SLURM_PATH.read_text(encoding="utf-8")


def test_training_submission_passes_only_the_config_pinned_resume_checkpoint() -> None:
    source = TRAIN_SLURM_PATH.read_text(encoding="utf-8")

    assert 'CONTINUATION_CHECKPOINT_RELATIVE' in source
    assert 'CONTINUATION_CHECKPOINT_SHA256' in source
    assert 'ACTUAL_CONTINUATION_CHECKPOINT_SHA256' in source
    assert 'RESUME_ARGUMENTS=(--resume "${CONTINUATION_CHECKPOINT}")' in source
    assert '"${RESUME_ARGUMENTS[@]}"' in source


def test_training_submission_requires_explicit_zero_update_portability_mode() -> None:
    source = TRAIN_SLURM_PATH.read_text(encoding="utf-8")

    assert 'PORTABILITY_DIAGNOSTIC_ONLY="${PARITY_PORTABILITY_DIAGNOSTIC_ONLY:-0}"' in source
    assert 'run_training_entry --portability-diagnostic-only' in source
    assert "must be exactly 0 or 1" in source
    assert '"portability_diagnostic_only":sys.argv[3]=="1"' in source


def test_training_submission_avoids_empty_optional_array_expansion() -> None:
    source = TRAIN_SLURM_PATH.read_text(encoding="utf-8")

    assert "PORTABILITY_ARGUMENTS=()" not in source
    assert '"${PORTABILITY_ARGUMENTS[@]}"' not in source
    assert "run_training_entry()" in source
    assert '    "$@" \\\n' in source
    assert "else\n  run_training_entry\nfi" in source


def test_probe_submission_passes_only_the_config_pinned_resume_checkpoint() -> None:
    source = PROBE_SLURM_PATH.read_text(encoding="utf-8")

    assert 'CONTINUATION_CHECKPOINT_RELATIVE' in source
    assert 'CONTINUATION_CHECKPOINT_SHA256' in source
    assert 'ACTUAL_CONTINUATION_CHECKPOINT_SHA256' in source
    assert 'RESUME_ARGUMENTS=(--resume "${CONTINUATION_CHECKPOINT}")' in source
    assert '"${RESUME_ARGUMENTS[@]}"' in source


def test_training_submission_preserves_gpu_and_cgroup_resource_evidence() -> None:
    source = TRAIN_SLURM_PATH.read_text(encoding="utf-8")

    assert "train-gpu-resources-${EXPERIMENT_ID}-${SLURM_JOB_ID}.csv" in source
    assert "train-cgroup-resources-${EXPERIMENT_ID}-${SLURM_JOB_ID}.txt" in source
    assert "memory.peak" in source
    assert "memory.max" in source
    assert "GPU_RESOURCE_SAMPLER_PID" in source
    assert "nvidia-smi" in source
    assert '--id "${CUDA_VISIBLE_DEVICES}"' in source
    assert "sample_gpu_resources()" in source
    assert "while true; do" in source
    assert "sleep 1" in source
    assert "-lms" not in source


def test_training_submission_checks_resources_inside_allocated_job_before_entry() -> None:
    source = TRAIN_SLURM_PATH.read_text(encoding="utf-8")

    assert source.count("${PARITY_HOST_ADMISSION_MIN_BYTES}") >= 2
    assert source.count("${PARITY_GPU_ADMISSION_MIN_FREE_MIB}") >= 2
    assert '--host-admission-min-bytes "${PARITY_HOST_ADMISSION_MIN_BYTES}"' in source
    assert '--gpu-admission-min-free-mib "${PARITY_GPU_ADMISSION_MIN_FREE_MIB}"' in source
    assert source.index("--host-admission-min-bytes") < source.index(
        "scripts/run_daily_camels_ukf_knet_parity.py"
    )
    assert source.index("--gpu-admission-min-free-mib") < source.index(
        "scripts/run_daily_camels_ukf_knet_parity.py"
    )


def test_training_resource_admission_passes_only_above_both_node_local_thresholds() -> None:
    report = PREFLIGHT._resource_admission(
        phase="train",
        available_host_memory_bytes=2_800_353_280,
        cuda={"memory_free_mib": 822},
        host_admission_min_bytes=2_800_353_280,
        gpu_admission_min_free_mib=822,
    )

    assert report == {
        "required": True,
        "status": "PASS",
        "checked_on_allocated_training_node_before_training": True,
        "available_host_memory_bytes": 2_800_353_280,
        "host_admission_min_bytes": 2_800_353_280,
        "gpu_memory_free_mib": 822,
        "gpu_admission_min_free_mib": 822,
    }


@pytest.mark.parametrize(
    ("available_host", "gpu_free", "message"),
    [
        (2_800_353_279, 822, "host memory is below"),
        (2_800_353_280, 821, "GPU free memory is below"),
    ],
)
def test_training_resource_admission_fails_before_training_below_either_threshold(
    available_host: int,
    gpu_free: int,
    message: str,
) -> None:
    with pytest.raises(MemoryError, match=message):
        PREFLIGHT._resource_admission(
            phase="train",
            available_host_memory_bytes=available_host,
            cuda={"memory_free_mib": gpu_free},
            host_admission_min_bytes=2_800_353_280,
            gpu_admission_min_free_mib=822,
        )


def test_training_resource_admission_fails_closed_without_explicit_thresholds() -> None:
    with pytest.raises(PermissionError, match="explicit integer"):
        PREFLIGHT._resource_admission(
            phase="train",
            available_host_memory_bytes=2_800_353_280,
            cuda={"memory_free_mib": 822},
            host_admission_min_bytes=None,
            gpu_admission_min_free_mib=822,
        )


def test_training_config_requires_frozen_replay_gate_identities() -> None:
    config = _training_config_with_replay_identities()

    geometry = PREFLIGHT._validate_config(config, "train")

    assert set(geometry["replay_gate_requirements"]) == {"exact", "causal"}

    del config["replay_gate_requirements"]
    with pytest.raises(PermissionError, match="frozen exact and causal"):
        PREFLIGHT._validate_config(config, "train")


@pytest.mark.parametrize(
    ("section", "key", "value"),
    [
        ("model", "gain_initialization", "zero_gain"),
        ("model", "correction_scope", "five_state_network"),
        ("optimization", "lead_weights", [0.5, 0.25, 0.25]),
    ],
)
def test_builder_and_node_preflight_reject_changed_gain_or_loss_contract(
    section: str,
    key: str,
    value: object,
) -> None:
    config = _training_config_with_replay_identities()
    target = config[section]
    assert isinstance(target, dict)
    target[key] = value

    with pytest.raises(RuntimeError):
        PREFLIGHT._validate_config(config, "train")
    with pytest.raises(ValueError):
        BUILDER._validate_config(config)


def test_builder_and_node_preflight_require_strict_zero_gain_baseline_gate() -> None:
    config = _training_config_with_replay_identities()
    gate = config["gate"]
    assert isinstance(gate, dict)
    gate["require_better_than_strict_zero_gain_each_lead"] = False

    with pytest.raises(PermissionError, match="every lead.*strict zero gain"):
        PREFLIGHT._validate_config(config, "train")
    with pytest.raises(ValueError, match="every lead.*strict zero gain"):
        BUILDER._validate_config(config)


def test_replay_gate_receipt_and_source_identity_are_verified(tmp_path: Path) -> None:
    gate_path = tmp_path / "replay_gate.json"
    gate = {
        "status": "REPLAY_PASS",
        "experiment_id": "EXACT_REPLAY_EXPERIMENT",
        "initialization_mode": "exact_tukf06_backward_time_diagnostic",
        "active_config_sha256": "2" * 64,
        "bundle_manifest_sha256": "3" * 64,
        "archive_sha256": "7" * 64,
        "selection_objective_target_count_per_lead": 728,
        "nse_gate_target_count_per_lead": 712,
        "pytest_exit_code": 77,
        "remote_test_status": "skipped_pytest_unavailable",
        "entry_exit_code": 0,
        "ukf_replay_contract_passed": True,
        "zero_gain_contract_passed": True,
    }
    gate_path.write_text(json.dumps(gate, sort_keys=True), encoding="utf-8")
    expected = {
        "experiment_id": gate["experiment_id"],
        "initialization_mode": gate["initialization_mode"],
        "receipt_sha256": PREFLIGHT.sha256_file(gate_path),
        "active_config_sha256": gate["active_config_sha256"],
        "bundle_manifest_sha256": gate["bundle_manifest_sha256"],
    }

    verified = PREFLIGHT._validate_replay_gate(
        gate_path,
        required_mode="exact_tukf06_backward_time_diagnostic",
        archive_sha256="7" * 64,
        expected_identity=expected,
    )
    assert verified["experiment_id"] == "EXACT_REPLAY_EXPERIMENT"

    gate["active_config_sha256"] = "8" * 64
    gate_path.write_text(json.dumps(gate, sort_keys=True), encoding="utf-8")
    with pytest.raises(PermissionError, match="not admissible"):
        PREFLIGHT._validate_replay_gate(
            gate_path,
            required_mode="exact_tukf06_backward_time_diagnostic",
            archive_sha256="7" * 64,
            expected_identity=expected,
        )


def test_historical_causal_config_selects_exact_replay_but_cannot_be_rebuilt(
    tmp_path: Path,
) -> None:
    exact = ROOT / "configs/daily_camels_ukf_knet_parity_exact_replay_dtype_repair_v3.json"
    causal = ROOT / "configs/daily_camels_ukf_knet_parity_causal_replay_dtype_repair_v3.json"

    sources, active_member, exact_member, experiment_id, mode = (
        BUILDER.bundle_member_sources(
            ROOT,
            config_path=causal,
            exact_config_path=exact,
        )
    )

    assert active_member == causal.relative_to(ROOT).as_posix()
    assert exact_member == exact.relative_to(ROOT).as_posix()
    assert active_member in sources
    assert exact_member in sources
    assert "configs/daily_camels_ukf_knet_parity_v1.json" not in sources
    assert experiment_id.endswith("20260825_A06")
    assert mode == "causal_shared_spinup"

    with pytest.raises(RuntimeError, match="active config source SHA-256 mismatch"):
        BUILDER.build_bundle(
            tmp_path / "historical_causal_bundle",
            config_path=causal,
            exact_config_path=exact,
            root=ROOT,
        )


def test_historical_same_segment_bundle_cannot_be_rebuilt_after_runner_extension(
    tmp_path: Path,
) -> None:
    exact = ROOT / "configs/daily_camels_ukf_knet_parity_exact_replay_dtype_repair_v3.json"
    same_segment_diagnostic = (
        ROOT
        / "configs/daily_camels_knet_same_segment_post_step_diagnostic_a14.json"
    )

    with pytest.raises(RuntimeError, match="active config source SHA-256 mismatch"):
        BUILDER.build_bundle(
            tmp_path / "same_segment_diagnostic_bundle",
            config_path=same_segment_diagnostic,
            exact_config_path=exact,
            root=ROOT,
        )


def test_a14_changes_only_identity_and_same_segment_diagnostic_evidence() -> None:
    a13_path = ROOT / "configs/daily_camels_knet_near_zero_stable_lr_strict_smoke_a13.json"
    a14_path = ROOT / "configs/daily_camels_knet_same_segment_post_step_diagnostic_a14.json"
    a13 = json.loads(a13_path.read_text(encoding="utf-8"))
    a14 = json.loads(a14_path.read_text(encoding="utf-8"))

    assert a13.pop("experiment_id").endswith("20260825_A13")
    assert a14.pop("experiment_id").endswith("20260825_A14")
    assert "stable_learning_rate" in a13.pop("scientific_role")
    assert "same_segment_post_step" in a14.pop("scientific_role")
    assert a14["optimization"].pop("same_segment_post_step_diagnostic") == (
        "fresh_no_grad_forward_on_identical_training_forecast_targets"
    )
    assert a14["gate"].pop("require_same_segment_post_step_improvement") is True

    assert a14 == a13


def test_historical_a15_bundle_cannot_be_rebuilt_after_runner_extension(
    tmp_path: Path,
) -> None:
    exact = ROOT / "configs/daily_camels_ukf_knet_parity_exact_replay_dtype_repair_v3.json"
    full_coverage = (
        ROOT
        / "configs/daily_camels_knet_fixed_full_training_coverage_accumulation_a15.json"
    )

    with pytest.raises(RuntimeError, match="active config source SHA-256 mismatch"):
        BUILDER.build_bundle(
            tmp_path / "full_training_coverage_bundle",
            config_path=full_coverage,
            exact_config_path=exact,
            root=ROOT,
        )


def test_a15_changes_only_identity_training_coverage_and_epoch_zero_anchor() -> None:
    a14_path = ROOT / "configs/daily_camels_knet_same_segment_post_step_diagnostic_a14.json"
    a15_path = (
        ROOT
        / "configs/daily_camels_knet_fixed_full_training_coverage_accumulation_a15.json"
    )
    a14 = json.loads(a14_path.read_text(encoding="utf-8"))
    a15 = json.loads(a15_path.read_text(encoding="utf-8"))

    assert a14.pop("experiment_id").endswith("20260825_A14")
    assert a15.pop("experiment_id").endswith("20260825_A15")
    assert "same_segment_post_step" in a14.pop("scientific_role")
    assert "fixed_full_training_coverage" in a15.pop("scientific_role")
    assert a15.pop("epoch_zero_reproducibility") == {
        "checkpoint_objective_728": 0.40192019589669764,
        "parameter_sha256": (
            "b4a375c3195cae48c984e9a18cd470746950fda5a5aceec60b6e594f1a352645"
        ),
        "prediction_sha256": (
            "17a6f0dbbe145b0262e0b2c1f426c49f1687a29927e8f8348f6ea293e246d91f"
        ),
    }
    assert a15["optimization"].pop("training_segment_sampling") == (
        "fixed_full_training_coverage_round_half_up"
    )
    assert a15["optimization"].pop("segments_per_optimizer_step") == 25
    assert a15["optimization"].pop("fixed_training_segment_start_indices") == [
        0,
        100,
        201,
        301,
        401,
        501,
        602,
        702,
        802,
        903,
        1003,
        1103,
        1204,
        1304,
        1404,
        1504,
        1605,
        1705,
        1805,
        1906,
        2006,
        2106,
        2206,
        2307,
        2407,
    ]
    assert a15["optimization"].pop("same_training_batch_post_step_diagnostic") == (
        "fresh_no_grad_forward_on_identical_25_segment_aggregate_forecast_targets"
    )

    assert a15 == a14


def test_a16_changes_a15_only_by_identity_epoch_budget_and_explicit_full_scope() -> None:
    a15_path = (
        ROOT
        / "configs/daily_camels_knet_fixed_full_training_coverage_accumulation_a15.json"
    )
    a16_path = (
        ROOT
        / "configs/daily_camels_knet_fixed_full_training_coverage_ten_epoch_a16.json"
    )
    a15 = json.loads(a15_path.read_text(encoding="utf-8"))
    a16 = json.loads(a16_path.read_text(encoding="utf-8"))

    assert a15.pop("experiment_id").endswith("20260825_A15")
    assert a16.pop("experiment_id").endswith("20260825_A16")
    assert "single_accumulated_update" in a15.pop("scientific_role")
    assert "ten_epoch_convergence" in a16.pop("scientific_role")
    assert a16["model"].pop("correction_scope") == (
        "full_eighteen_dimensional_state_correction"
    )
    assert a15["optimization"].pop("training_epochs") == 1
    assert a16["optimization"].pop("training_epochs") == 10

    assert a16["reference"].pop("a15_one_step_best_checkpoint_objective") == (
        0.28580983607261695
    )
    assert a16["reference"].pop("a15_one_step_best_nse_by_lead") == [
        0.7931683983822845,
        0.7837451386292139,
        0.7756788158494483,
    ]
    assert a16["reference"].pop("a15_evidence_archive_sha256") == (
        "c13ecc2d10700b7ad1e77531c11048670c7f79b31e6a9154f6101c10ac0f9c96"
    )
    assert a15["reference"].pop("reference_status") == (
        "frozen_from_seq6_causal_replay_gate_A06"
    )
    assert a16["reference"].pop("reference_status") == (
        "frozen_from_seq6_causal_replay_and_seq12_a15_full_coverage"
    )

    runner_name = (
        "src/global_hydrology/experiments/daily_camels_ukf_knet_parity_runner.py"
    )
    assert a15["source_sha256"].pop(runner_name) == (
        "60aac06f2d6fe07a23758f2ed0728eabe493abf511973a50765bb828f616259d"
    )
    assert a16["source_sha256"].pop(runner_name) == BUILDER.sha256_file(
        ROOT / runner_name
    )

    assert a16 == a15


def test_a37_bundle_includes_exact_source_config_and_checkpoint(tmp_path: Path) -> None:
    exact = ROOT / "configs/daily_camels_ukf_knet_parity_exact_replay_dtype_repair_v3.json"
    result = BUILDER.build_bundle(
        tmp_path / "a37_checkpoint_continuation_bundle",
        config_path=A37_CONFIG,
        exact_config_path=exact,
        root=ROOT,
    )
    inspection = BUILDER.inspect_archive(result.archive_path)
    continuation = json.loads(A37_CONFIG.read_text(encoding="utf-8"))["continuation"]

    assert inspection.manifest["resume_checkpoint_count"] == 1
    assert inspection.manifest["continuation"] == continuation
    assert inspection.manifest["member_sha256"][A16_CHECKPOINT_MEMBER] == (
        continuation["checkpoint_sha256"]
    )
    assert inspection.manifest["member_sha256"][
        continuation["source_configuration_path"]
    ] == continuation["source_configuration_sha256"]
    portability = json.loads(A37_CONFIG.read_text(encoding="utf-8"))[
        "cross_device_portability_receipt"
    ]
    assert inspection.manifest["cross_device_portability_receipt"] == portability
    assert inspection.manifest["member_sha256"][
        A37_PORTABILITY_RECEIPT_MEMBER
    ] == portability["sha256"]
    assert inspection.manifest["member_count"] == 51
    references = inspection.manifest["continuation_prediction_references"]
    assert references["source_epoch_history_sha256"] == continuation[
        "source_epoch_history_sha256"
    ]
    assert references["epoch_zero_prediction_sha256"] == (
        "17a6f0dbbe145b0262e0b2c1f426c49f1687a29927e8f8348f6ea293e246d91f"
    )
    assert references["completed_epoch"] == 10
    assert references["completed_epoch_prediction_sha256"] == (
        "0517d0e6d4fb290e0cfe1f70ca1ed22e87b1c2c63618edf2b67d725445d7b440"
    )
    assert references["source_device_provenance_sha256"] == (
        "d9c7a88af68821725083e384601eac70c45f6363d7c13a0fa4e588d5b0f55897"
    )
    assert references["source_device_name"] == "NVIDIA GeForce RTX 3090"
    assert references["source_hostname"] == "ngu011"
    assert references["source_slurm_job_id"] == "211291"
    assert references["array_members_materialized_during_build"] == 0
    for member_key, digest_key in (
        ("source_epoch_history_member", "source_epoch_history_sha256"),
        ("epoch_zero_prediction_member", "epoch_zero_prediction_sha256"),
        (
            "completed_epoch_prediction_member",
            "completed_epoch_prediction_sha256",
        ),
        ("source_device_provenance_member", "source_device_provenance_sha256"),
    ):
        assert inspection.manifest["member_sha256"][references[member_key]] == (
            references[digest_key]
        )


def test_a37_node_preflight_returns_pinned_resume_member() -> None:
    config = json.loads(A37_CONFIG.read_text(encoding="utf-8"))

    geometry = PREFLIGHT._validate_config(config, "train")

    assert geometry["continuation"] == {
        "enabled": True,
        "checkpoint_path": A16_CHECKPOINT_MEMBER,
        "checkpoint_sha256": config["continuation"]["checkpoint_sha256"],
        "completed_epoch": 10,
        "source_device": "cuda",
        "source_experiment_id": config["continuation"]["source_experiment_id"],
    }
    assert geometry["cross_device_portability_receipt"] == {
        "enabled": True,
        "member": A37_PORTABILITY_RECEIPT_MEMBER,
        "sha256": config["cross_device_portability_receipt"]["sha256"],
        "source_device_name": "NVIDIA GeForce RTX 3090",
        "target_device_name": "NVIDIA A800-SXM4-80GB",
        "prediction_maximum_absolute_error_limit": 3.0e-7,
        "prediction_maximum_relative_error_limit": 3.0e-7,
        "objective_and_metric_absolute_error_limit": 3.0e-9,
    }


def test_a37_builder_rejects_unpinned_continuation_checkpoint() -> None:
    config = json.loads(A37_CONFIG.read_text(encoding="utf-8"))
    config["continuation"]["checkpoint_sha256"] = "0" * 63

    with pytest.raises((ValueError, RuntimeError), match="checkpoint"):
        BUILDER._validate_config(config)


def test_a38_gate_revision_retires_only_the_historical_portability_receipt() -> None:
    a37 = json.loads(A37_CONFIG.read_text(encoding="utf-8"))
    a38 = _a38_config_from_a37()

    BUILDER._validate_config(a38)
    assert BUILDER._portability_receipt_member(a38) == {}
    assert BUILDER._gate_revision_geometry(a38) == a38["gate_revision"]

    a37_geometry = PREFLIGHT._validate_config(a37, "train")
    a38_geometry = PREFLIGHT._validate_config(a38, "train")
    assert a37_geometry["cross_device_portability_receipt"]["enabled"] is True
    assert a38_geometry["cross_device_portability_receipt"] == {"enabled": False}
    assert a38_geometry["gate_revision"] == a38["gate_revision"]
    assert a38_geometry["continuation_source_device_name"] == (
        "NVIDIA A800-SXM4-80GB"
    )


def test_checked_in_a38_config_matches_the_frozen_builder_and_preflight_schema() -> None:
    checked_in = json.loads(A38_CONFIG.read_text(encoding="utf-8"))
    expected = _a38_config_from_a37()

    assert checked_in["continuation"] == expected["continuation"]
    assert checked_in["gate_revision"] == expected["gate_revision"]
    assert "cross_device_portability_receipt" not in checked_in
    BUILDER._validate_config(checked_in)
    geometry = PREFLIGHT._validate_config(checked_in, "train")
    assert geometry["gate_revision"] == expected["gate_revision"]
    assert geometry["continuation_source_device_name"] == "NVIDIA A800-SXM4-80GB"


def test_a38_online_preflight_requires_the_same_a800_device_as_its_source() -> None:
    geometry = PREFLIGHT._validate_config(_a38_config_from_a37(), "train")

    assert PREFLIGHT._validate_continuation_device(
        {"device_name": "NVIDIA A800-SXM4-80GB"}, geometry
    ) == "NVIDIA A800-SXM4-80GB"
    with pytest.raises(RuntimeError, match="A800 source device"):
        PREFLIGHT._validate_continuation_device(
            {"device_name": "NVIDIA GeForce RTX 3090"}, geometry
        )


def test_a38_source_evidence_is_derived_without_prediction_arrays() -> None:
    config = _a38_config_from_a37()
    expected_members = {
        f"{A37_EVIDENCE_RUN_MEMBER}/epoch_history.json",
        f"{A37_EVIDENCE_RUN_MEMBER}/result_summary.json",
        f"{A37_EVIDENCE_RUN_MEMBER}/experiment_identity.json",
        f"{A37_EVIDENCE_RUN_MEMBER}/completion.marker.json",
        f"{A37_EVIDENCE_RUN_MEMBER}/manifest.sha256.json",
    }

    members = set(BUILDER._continuation_source_evidence_members(config))
    assert members == expected_members
    assert not any(member.endswith(".npz") for member in members)

    source_paths = {member: ROOT / member for member in members}
    evidence = BUILDER._validate_continuation_source_evidence(config, source_paths)
    assert evidence["completed_epoch"] == 40
    assert evidence["optimizer_steps"] == 40
    assert evidence["sampled_forecast_events"] == 306000
    assert evidence["source_device_name"] == "NVIDIA A800-SXM4-80GB"
    assert evidence["status"] == "TRAINING_COMPLETE_GATE_FAIL"
    assert evidence["failed_gates"] == ["same_segment_post_step_improvement"]
    assert evidence["strict_decrease_count"] == 35
    assert evidence["not_strictly_decreased_optimizer_steps"] == [12, 24, 26, 27, 30]
    assert evidence["reserved_evaluation_access_count"] == 0
    assert evidence["array_members_materialized_during_build"] == 0


@pytest.mark.parametrize(
    ("key", "value"),
    [
        ("source_strict_decrease_count", 34),
        ("source_not_strictly_decreased_optimizer_steps", [12, 24]),
        ("target_role", "scientific_pass"),
        ("retired_cross_device_portability_receipt", False),
    ],
)
def test_a38_gate_revision_rejects_any_changed_frozen_fact(
    key: str,
    value: object,
) -> None:
    config = _a38_config_from_a37()
    config["gate_revision"][key] = value

    with pytest.raises((ValueError, RuntimeError, PermissionError), match="gate revision"):
        BUILDER._gate_revision_geometry(config)
    with pytest.raises((ValueError, RuntimeError, PermissionError), match="gate revision"):
        PREFLIGHT._gate_revision_geometry(config)


def test_a38_without_revision_cannot_silently_drop_portability_evidence() -> None:
    config = _a38_config_from_a37()
    config.pop("gate_revision")

    with pytest.raises((ValueError, RuntimeError), match="portability"):
        BUILDER._portability_receipt_member(config)
    with pytest.raises((ValueError, RuntimeError), match="portability"):
        PREFLIGHT._portability_receipt_geometry(config)


@pytest.mark.parametrize(
    "member",
    [
        "artifacts/heldout/result.json",
        "artifacts/reserved_evaluation/result.json",
        "artifacts/formal-evaluation/result.json",
    ],
)
def test_builder_and_preflight_reject_all_reserved_evaluation_member_names(
    member: str,
) -> None:
    with pytest.raises((ValueError, RuntimeError), match="forbidden"):
        BUILDER._validate_member_name(member)
    with pytest.raises((ValueError, RuntimeError), match="forbidden"):
        PREFLIGHT._safe_member_name(member)


def test_a38_source_summary_requires_zero_reserved_evaluation_access() -> None:
    summary_path = ROOT / A37_EVIDENCE_RUN_MEMBER / "result_summary.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8"))

    assert BUILDER._validate_zero_reserved_access(summary) == 0
    assert PREFLIGHT._validate_zero_reserved_access(summary) == 0

    summary["training"]["access_ledger"]["evaluation_metric_count"] = 1
    with pytest.raises((ValueError, RuntimeError), match="reserved evaluation"):
        BUILDER._validate_zero_reserved_access(summary)
    with pytest.raises((ValueError, RuntimeError), match="reserved evaluation"):
        PREFLIGHT._validate_zero_reserved_access(summary)


def test_ten_epoch_full_coverage_bundle_is_self_consistent(tmp_path: Path) -> None:
    exact = ROOT / "configs/daily_camels_ukf_knet_parity_exact_replay_dtype_repair_v3.json"
    config = (
        ROOT
        / "configs/daily_camels_knet_fixed_full_training_coverage_ten_epoch_a16.json"
    )
    result = BUILDER.build_bundle(
        tmp_path / "ten_epoch_full_coverage_bundle",
        config_path=config,
        exact_config_path=exact,
        root=ROOT,
    )
    inspection = BUILDER.inspect_archive(result.archive_path)

    assert inspection.manifest["active_config_member"] == config.relative_to(
        ROOT
    ).as_posix()
    assert inspection.manifest["experiment_id"].endswith("20260825_A16")


def test_a17_changes_a16_only_by_identity_epoch_budget_and_frozen_reference() -> None:
    a16_path = (
        ROOT
        / "configs/daily_camels_knet_fixed_full_training_coverage_ten_epoch_a16.json"
    )
    a17_path = (
        ROOT
        / "configs/daily_camels_knet_fixed_full_training_coverage_forty_epoch_a17.json"
    )
    a16 = json.loads(a16_path.read_text(encoding="utf-8"))
    a17 = json.loads(a17_path.read_text(encoding="utf-8"))

    assert a16.pop("experiment_id").endswith("20260825_A16")
    assert a17.pop("experiment_id").endswith("20260825_A17")
    assert "ten_epoch_convergence" in a16.pop("scientific_role")
    assert "forty_epoch_budget_extension" in a17.pop("scientific_role")
    assert a16["optimization"].pop("training_epochs") == 10
    assert a17["optimization"].pop("training_epochs") == 40

    assert a17["reference"].pop("a16_ten_epoch_best_checkpoint_objective") == (
        0.07951907715501967
    )
    assert a17["reference"].pop("a16_ten_epoch_best_nse_by_lead") == [
        0.9649952670432475,
        0.9397019701611595,
        0.9155408779559143,
    ]
    assert a17["reference"].pop("a16_evidence_archive_sha256") == (
        "c6ee59e9dbd233858ef3bd310eca41e76d23152aa42d7fba6d5e1d1d414123d9"
    )
    assert a17["reference"].pop("a16_result_summary_sha256") == (
        "07cf27a7f3d18d1a3428f829e2486fcd874157ab678d1f75ddebdfc709b8c71b"
    )
    assert a16["reference"].pop("reference_status") == (
        "frozen_from_seq6_causal_replay_and_seq12_a15_full_coverage"
    )
    assert a17["reference"].pop("reference_status") == (
        "frozen_from_seq6_causal_replay_seq12_a15_and_seq15_a16"
    )

    assert a17 == a16


def test_forty_epoch_full_coverage_bundle_is_self_consistent(tmp_path: Path) -> None:
    exact = ROOT / "configs/daily_camels_ukf_knet_parity_exact_replay_dtype_repair_v3.json"
    config = (
        ROOT
        / "configs/daily_camels_knet_fixed_full_training_coverage_forty_epoch_a17.json"
    )
    result = BUILDER.build_bundle(
        tmp_path / "forty_epoch_full_coverage_bundle",
        config_path=config,
        exact_config_path=exact,
        root=ROOT,
    )
    inspection = BUILDER.inspect_archive(result.archive_path)

    assert inspection.manifest["active_config_member"] == config.relative_to(
        ROOT
    ).as_posix()
    assert inspection.manifest["experiment_id"].endswith("20260825_A17")


def test_pytest_is_optional_but_scientific_runtime_packages_are_required() -> None:
    def fake_find_spec(module: str):
        return None if module == "pytest" else object()

    with patch.object(
        PREFLIGHT.importlib.util, "find_spec", side_effect=fake_find_spec
    ), patch.object(
        PREFLIGHT.importlib.metadata,
        "version",
        side_effect=lambda distribution: f"test-{distribution}",
    ):
        report = PREFLIGHT._package_availability()

    assert report["numpy"] == {
        "available": True,
        "required_for_scientific_runtime": True,
        "version": "test-numpy",
    }
    assert report["torch"] == {
        "available": True,
        "required_for_scientific_runtime": True,
        "version": "test-torch",
    }
    assert report["pytest"] == {
        "available": False,
        "required_for_scientific_runtime": False,
        "version": None,
    }


def test_missing_scientific_runtime_package_still_fails_closed() -> None:
    with patch.object(
        PREFLIGHT.importlib.util,
        "find_spec",
        side_effect=lambda module: None if module == "numpy" else object(),
    ):
        with pytest.raises(RuntimeError, match="required package.*numpy"):
            PREFLIGHT._package_availability()


@pytest.mark.parametrize(
    ("exit_code", "available", "expected"),
    [
        (0, True, "passed"),
        (77, False, "skipped_pytest_unavailable"),
    ],
)
def test_remote_test_attestation_is_explicit(
    exit_code: int,
    available: bool,
    expected: str,
) -> None:
    status = PREFLIGHT._remote_test_attestation(
        exit_code,
        {"pytest": {"available": available}},
    )

    assert status == expected


@pytest.mark.parametrize(
    ("exit_code", "available"),
    [(0, False), (77, True), (1, True), (1, False)],
)
def test_remote_test_attestation_rejects_ambiguous_or_failed_states(
    exit_code: int,
    available: bool,
) -> None:
    with pytest.raises(RuntimeError, match="availability disagree"):
        PREFLIGHT._remote_test_attestation(
            exit_code,
            {"pytest": {"available": available}},
        )
