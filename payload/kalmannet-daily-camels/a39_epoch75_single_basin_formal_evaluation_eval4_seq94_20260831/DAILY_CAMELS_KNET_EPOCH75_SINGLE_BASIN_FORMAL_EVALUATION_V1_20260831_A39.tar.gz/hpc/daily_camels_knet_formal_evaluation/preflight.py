#!/usr/bin/env python3
"""Standard-library-only preflight for the A39 formal evaluation.

The preflight validates the sealed bundle and hashes the external,
read-only artifacts before an evaluator can import NumPy or PyTorch.  It never
deserializes the evaluation NPZ, checkpoint, or source-evidence archive.
"""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
import os
from pathlib import Path, PurePosixPath
import socket
import subprocess
import sys
from typing import Any, Mapping
import uuid


SCHEMA_VERSION = "daily_camels_knet_formal_evaluation_hpc_bundle_v1"
CONFIG_SCHEMA_VERSION = "daily_camels_knet_epoch75_formal_evaluation_v1"
EXPERIMENT_ID = (
    "DAILY_CAMELS_KNET_EPOCH75_SINGLE_BASIN_FORMAL_EVALUATION_V1_20260831_A39"
)
EXECUTION_ID = (
    "DAILY_CAMELS_KNET_EPOCH75_SINGLE_BASIN_FORMAL_EVALUATION_"
    "A39_A800_EVAL4_SEQ94"
)
REMOTE_ROOT = Path(
    "/data1/home/sunyiq/kalmannet_daily_camels_knet_a39_formal_evaluation4_20260831"
)
OUTPUT_ROOT = REMOTE_ROOT / "evaluation"
VERIFICATION_OUTPUT = REMOTE_ROOT / "verification" / "independent_verification.json"
CONFIG_MEMBER = "configs/daily_camels_knet_epoch75_formal_evaluation_a39.json"
REGISTRY_MEMBER = (
    "artifacts/daily_camels_knet_a39_formal_evaluation_bundle/"
    "A39_BUILD_20260831_05/experiment_registry.json"
)
FORMAL_PLAN_MEMBER = (
    "docs/superpowers/plans/"
    "2026-08-31-daily-camels-knet-epoch75-formal-evaluation.md"
)
FORMAL_PLAN_SHA256 = (
    "db528225d1a8525235714823f29b380b3210320e3147da246f37a7c48c249cce"
)
NEXT_STAGE_PLAN_MEMBER = (
    "docs/superpowers/plans/2026-08-31-daily-camels-knet-21-basin-development.md"
)
NEXT_STAGE_PLAN_SHA256 = (
    "28fd091091deef2e81e242e5f9c5eed81e8ee8f94337c752e265dad3cd48e760"
)
DEVELOPMENT_ARCHIVE_MEMBER = (
    "results/tukf06_full_diagonal_search_head_to_head_v1/"
    "selection_inputs/basin_09035800.npz"
)
DEVELOPMENT_ARCHIVE_SHA256 = (
    "71e6d163507ae405204bedf63d2c6c06e2c3ea303cea1a0481cfa4d5f280f5fd"
)
SELECTION_MEMBER = (
    "results/tukf06_full_diagonal_search_head_to_head_v1/"
    "selection/basin_09035800.json"
)
SELECTION_SHA256 = (
    "8b4888a62052f8d9f0018e907c665d30a72c4c7c29081763db0f4d46904ec3a2"
)
CHECKPOINT_PATH_TEXT = (
    "/data1/home/sunyiq/kalmannet_daily_camels_knet_a38_a800_train1_20260828/"
    "runs/DAILY_CAMELS_KNET_FIXED_FULL_TRAINING_COVERAGE_"
    "EPOCH40_TO80_RESUME_STEP_MONOTONICITY_DIAGNOSTIC_V1_20260828_A38/"
    "checkpoints/epoch_075.pt"
)
CHECKPOINT_PATH = Path(CHECKPOINT_PATH_TEXT)
CHECKPOINT_SHA256 = (
    "7cc97138669531688dcd65d606d154330f260346c7c9c6e704cb1be5307a241b"
)
CHECKPOINT_SIZE = 4_260_296
CHECKPOINT_PARAMETER_SHA256 = (
    "5a288a2ac6d2985253b37616d983d6dfaf0638b18169bba8fcd0439e5b922fce"
)
EVALUATION_ARCHIVE_PATH_TEXT = (
    "/data1/home/sunyiq/kalmannet_tukf06_20260809/retry2/results/"
    "tukf06_full_diagonal_search_head_to_head_v1/evaluation/"
    "basin_09035800.npz"
)
EVALUATION_ARCHIVE_PATH = Path(EVALUATION_ARCHIVE_PATH_TEXT)
EVALUATION_ARCHIVE_SHA256 = (
    "59c0acc1afce14da7fe479fc5cdb6c6c4d2b18758d076c32950c5f2b3cfd3596"
)
EVALUATION_ARCHIVE_SIZE = 444_684
A38_ORIGINAL_TERMINAL_ARCHIVE_PATH_TEXT = (
    "/data1/home/sunyiq/hpc_mailbox/outbox/kalmannet-daily-camels/"
    "DAILY_CAMELS_KNET_A38_JOB215801_TERMINAL_EVIDENCE_SEQ82.tar.gz"
)
A38_ORIGINAL_TERMINAL_ARCHIVE_SHA256 = (
    "72feda409ea3490ccd9a289b1313c9beb276c1cc267a15111dc19e63d5815317"
)
A38_ORIGINAL_TERMINAL_ARCHIVE_SIZE = 13_900_887
A38_RECONSTRUCTED_TERMINAL_ARCHIVE_PATH_TEXT = (
    REMOTE_ROOT.as_posix()
    + "/external_evidence/"
    + "DAILY_CAMELS_KNET_A38_JOB215801_TERMINAL_EVIDENCE_RECONSTRUCT_SEQ89.tar.gz"
)
A38_RECONSTRUCTED_TERMINAL_ARCHIVE_PATH = Path(
    A38_RECONSTRUCTED_TERMINAL_ARCHIVE_PATH_TEXT
)
A38_RECONSTRUCTED_TERMINAL_ARCHIVE_SHA256 = (
    "89975d9d69d477d625ae11713a96edf618cb6189284e280f3008bfe0f785676d"
)
A38_RECONSTRUCTED_TERMINAL_ARCHIVE_SIZE = 13_900_887
A38_MEMBER_IDENTITY_RECEIPT_PATH_TEXT = (
    REMOTE_ROOT.as_posix() + "/external_evidence/member_identity_verification.json"
)
A38_MEMBER_IDENTITY_RECEIPT_PATH = Path(A38_MEMBER_IDENTITY_RECEIPT_PATH_TEXT)
A38_MEMBER_IDENTITY_RECEIPT_SHA256 = (
    "ac2fc24c15edb7b9d5e22ced035141c4fa256e79f8067ea9225be9613abe8f56"
)
A38_MEMBER_IDENTITY_RECEIPT_SIZE = 1_278
A38_CANONICAL_MEMBER_INVENTORY_SHA256 = (
    "e6af63ceb2c40f932afd295651104b3268f80ac41ccbccb95f7a0de240a55fe6"
)
MIN_HOST_MEMORY_BYTES = 2_800_353_280
MIN_GPU_FREE_MIB = 4_584
EXPECTED_GPU_NAME = "NVIDIA A800-SXM4-80GB"
ALLOWED_HOSTS = frozenset({"ngu202", "ngu203"})
SUBMISSION_TOKEN = (
    "00ae298e699c5ea81bbb0cc25886f94d30fc8e32a1f23c30202d88f3a5a1bb3f"
)
MODEL_CONTRACT = {
    "state_dimension": 18,
    "gain_network_numeric_dtype": "float32",
    "physical_numeric_dtype": "float64",
    "seed": 20260824,
    "hidden": 24,
    "input_multiplier": 10,
    "output_multiplier": 10,
    "feature_scale_floor": 0.1,
    "normalized_feature_guard": 10.0,
    "correction_scope": "full_eighteen_dimensional_state_correction",
    "checkpoint_state_member": "model_state",
}
EXPECTED_EVALUATION_ARCHIVE_MEMBERS = [
    "dates_ns",
    "target",
    "forcing",
    *[
        f"{system}_lead_{lead}"
        for lead in (1, 2, 3)
        for system in (
            "common_mask",
            "same_forcing_open_loop",
            "default_noise_filter",
            "sampling_search_filter",
            "backpropagation_filter",
            "persistence",
            "second_order_autoregression",
        )
    ],
]


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_json(path: Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise RuntimeError(f"JSON root must be an object: {path}")
    return payload


def _write_new_json(path: Path, payload: Mapping[str, Any]) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists() or destination.is_symlink():
        raise FileExistsError(f"refusing to replace preflight evidence: {destination}")
    content = (
        json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False)
        + "\n"
    ).encode("utf-8")
    pending = destination.with_name(destination.name + f".pending-{uuid.uuid4().hex}")
    try:
        with pending.open("xb") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        if destination.exists() or destination.is_symlink():
            raise FileExistsError(f"refusing to replace preflight evidence: {destination}")
        os.replace(pending, destination)
    finally:
        if pending.exists():
            pending.unlink()


def _mapping(value: Any, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise RuntimeError(f"{label} must be an object")
    return value


def _require_exact(value: Any, expected: Any, label: str) -> None:
    if value != expected:
        raise RuntimeError(f"{label} differs from the frozen A39 contract")


def validate_config(config: Mapping[str, Any]) -> dict[str, Any]:
    """Validate only frozen, pre-evaluation facts; never inspect array data."""

    _require_exact(config.get("schema_version"), CONFIG_SCHEMA_VERSION, "config schema")
    _require_exact(config.get("experiment_id"), EXPERIMENT_ID, "experiment identity")
    _require_exact(config.get("basin_id"), "09035800", "basin")
    _require_exact(config.get("cadence"), "daily", "cadence")
    _require_exact(config.get("forecast_leads"), [1, 2, 3], "forecast leads")
    _require_exact(
        config.get("evaluation_period"),
        ["1989-10-01", "1999-09-30"],
        "evaluation period",
    )
    _require_exact(
        config.get("evaluation_period_role"),
        "reused_historical_benchmark",
        "period role",
    )
    _require_exact(config.get("expected_evaluation_days"), 3652, "period length")
    _require_exact(config.get("warmup_days"), 365, "warm-up")
    evaluation_contract = _mapping(config.get("evaluation"), "evaluation")
    _require_exact(
        evaluation_contract.get("warmup_applies_to_issue_dates"),
        True,
        "issue-date warm-up policy",
    )
    _require_exact(
        evaluation_contract.get("issue_start_index_inclusive"),
        365,
        "issue start",
    )
    _require_exact(
        evaluation_contract.get("issue_end_index_exclusive"),
        3649,
        "issue end",
    )
    _require_exact(
        evaluation_contract.get("nominal_common_issue_count"),
        3284,
        "nominal common issue count",
    )

    policy = _mapping(config.get("execution_policy"), "execution policy")
    for field in (
        "allow_training",
        "allow_optimizer_updates",
        "allow_checkpoint_writes",
        "allow_checkpoint_selection",
        "allow_hyperparameter_tuning",
        "allow_stored_baseline_prediction_reads",
    ):
        _require_exact(policy.get(field), False, field)
    _require_exact(policy.get("evaluation_only"), True, "evaluation-only policy")
    _require_exact(policy.get("one_shot_evaluation"), True, "one-shot policy")
    _require_exact(
        policy.get("require_absent_output_root"),
        True,
        "absent-output-root policy",
    )
    _require_exact(
        policy.get("scientific_hold_is_technical_success"),
        True,
        "scientific-HOLD exit policy",
    )
    _require_exact(
        policy.get("evaluation_archive_open_count"), 1, "evaluation read count"
    )
    allowed_evaluation_members = ["dates_ns", "forcing", "target"]
    _require_exact(
        policy.get("allowed_evaluation_array_members"),
        allowed_evaluation_members,
        "allowed evaluation array reads",
    )

    checkpoint = _mapping(config.get("checkpoint"), "checkpoint")
    _require_exact(checkpoint.get("path"), CHECKPOINT_PATH_TEXT, "checkpoint path")
    _require_exact(checkpoint.get("sha256"), CHECKPOINT_SHA256, "checkpoint SHA-256")
    _require_exact(checkpoint.get("size_bytes"), CHECKPOINT_SIZE, "checkpoint size")
    _require_exact(checkpoint.get("completed_epoch"), 75, "checkpoint epoch")
    _require_exact(
        checkpoint.get("parameter_sha256"),
        CHECKPOINT_PARAMETER_SHA256,
        "checkpoint parameter SHA-256",
    )
    candidate = _mapping(config.get("candidate"), "candidate")
    _require_exact(
        candidate.get("source_experiment_id"),
        "DAILY_CAMELS_KNET_FIXED_FULL_TRAINING_COVERAGE_"
        "EPOCH40_TO80_RESUME_STEP_MONOTONICITY_DIAGNOSTIC_V1_20260828_A38",
        "source experiment",
    )
    _require_exact(
        candidate.get("source_terminal_evidence_archive_sha256"),
        A38_ORIGINAL_TERMINAL_ARCHIVE_SHA256,
        "A38 terminal archive SHA-256",
    )
    _require_exact(
        dict(_mapping(config.get("model"), "model")), MODEL_CONTRACT, "model"
    )
    _require_exact(
        dict(_mapping(config.get("ukf"), "ukf")),
        {
            "default_noise": {
                "process_diagonal": [0.001] * 18,
                "r_b": 0.02,
            },
            "sampled_search": {"selection_method": "sampling_search"},
            "backpropagation_selected": {
                "selection_method": "backpropagation"
            },
        },
        "UKF baselines",
    )
    metrics = _mapping(config.get("metrics"), "metrics")
    _require_exact(
        metrics.get("same_nominal_issue_window_across_leads"),
        True,
        "same issue-window policy",
    )

    inputs = _mapping(config.get("inputs"), "inputs")
    evaluation = _mapping(inputs.get("evaluation_archive"), "evaluation archive")
    _require_exact(
        evaluation.get("path"), EVALUATION_ARCHIVE_PATH_TEXT, "evaluation path"
    )
    _require_exact(
        evaluation.get("sha256"), EVALUATION_ARCHIVE_SHA256, "evaluation SHA-256"
    )
    _require_exact(evaluation.get("size_bytes"), EVALUATION_ARCHIVE_SIZE, "evaluation size")
    if "members" in evaluation:
        raise RuntimeError(
            "evaluation archive must distinguish full expected members from allowed reads"
        )
    _require_exact(
        evaluation.get("expected_archive_members"),
        EXPECTED_EVALUATION_ARCHIVE_MEMBERS,
        "historical archive member inventory",
    )
    _require_exact(
        evaluation.get("stored_baseline_prediction_reads"),
        0,
        "stored baseline reads",
    )
    _require_exact(config.get("output_root"), OUTPUT_ROOT.as_posix(), "output root")

    resources = _mapping(config.get("resource_admission"), "resource admission")
    _require_exact(
        resources.get("host_memory_min_bytes"),
        MIN_HOST_MEMORY_BYTES,
        "host-memory admission",
    )
    _require_exact(
        resources.get("gpu_free_memory_min_mib"),
        MIN_GPU_FREE_MIB,
        "GPU-memory admission",
    )
    _require_exact(
        resources.get("a38_measured_host_peak_bytes"),
        1_405_100_032,
        "A38 measured host peak",
    )
    _require_exact(
        resources.get("a38_slurm_max_rss_bytes"),
        1_394_536_448,
        "A38 Slurm maximum resident set",
    )
    _require_exact(
        resources.get("a38_measured_gpu_peak_used_mib"),
        3_820,
        "A38 measured GPU peak",
    )
    return {
        "experiment_id": EXPERIMENT_ID,
        "completed_epoch": 75,
        "checkpoint_sha256": CHECKPOINT_SHA256,
        "evaluation_archive_sha256": EVALUATION_ARCHIVE_SHA256,
        "output_root": OUTPUT_ROOT.as_posix(),
    }


def _safe_member_name(name: str) -> PurePosixPath:
    if not isinstance(name, str) or not name or "\\" in name:
        raise RuntimeError(f"unsafe bundle member: {name!r}")
    member = PurePosixPath(name)
    if member.is_absolute() or ".." in member.parts or ".git" in member.parts:
        raise RuntimeError(f"unsafe bundle member: {name}")
    lowered = tuple(part.lower() for part in member.parts)
    if member.suffix.lower() == ".pt":
        raise RuntimeError(f"checkpoint may not be packaged: {name}")
    if member.suffix.lower() == ".npz" and (
        "evaluation" in lowered
        or any("heldout" in part or "reserved" in part for part in lowered)
    ):
        raise RuntimeError(f"historical evaluation array may not be packaged: {name}")
    return member


def verify_bundle_root(bundle_root: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    root = Path(bundle_root)
    if not root.is_dir() or root.is_symlink():
        raise RuntimeError("bundle root must be a real directory")
    manifest_path = root / "bundle_manifest.json"
    if not manifest_path.is_file() or manifest_path.is_symlink():
        raise RuntimeError("bundle manifest is absent, non-regular, or symbolic")
    manifest = _read_json(manifest_path)
    _require_exact(manifest.get("schema_version"), SCHEMA_VERSION, "bundle schema")
    _require_exact(manifest.get("experiment_id"), EXPERIMENT_ID, "bundle experiment")
    _require_exact(manifest.get("active_config_member"), CONFIG_MEMBER, "active config")

    hashes = _mapping(manifest.get("member_sha256"), "member SHA-256 inventory")
    sizes = _mapping(manifest.get("member_size"), "member size inventory")
    if set(hashes) != set(sizes) or manifest.get("member_count") != len(hashes):
        raise RuntimeError("bundle member inventories differ")
    actual_files: set[str] = set()
    for path in root.rglob("*"):
        if path.is_symlink():
            raise RuntimeError(f"bundle tree contains a symbolic link: {path}")
        if path.is_file():
            actual_files.add(path.relative_to(root).as_posix())
    expected_files = set(hashes) | {"bundle_manifest.json"}
    if actual_files != expected_files:
        missing = sorted(expected_files - actual_files)
        extra = sorted(actual_files - expected_files)
        raise RuntimeError(f"bundle tree inventory differs; missing={missing}, extra={extra}")
    for name in sorted(hashes):
        member = _safe_member_name(name)
        path = root.joinpath(*member.parts)
        if not path.is_file() or path.is_symlink():
            raise RuntimeError(f"bundle member is absent, non-regular, or symbolic: {name}")
        if path.stat().st_size != sizes[name] or sha256_file(path) != hashes[name]:
            raise RuntimeError(f"bundle member identity differs: {name}")

    npz_members = sorted(name for name in hashes if name.lower().endswith(".npz"))
    if npz_members != [DEVELOPMENT_ARCHIVE_MEMBER]:
        raise RuntimeError("bundle NPZ inventory is not development-only")
    if hashes.get(DEVELOPMENT_ARCHIVE_MEMBER) != DEVELOPMENT_ARCHIVE_SHA256:
        raise RuntimeError("development archive SHA-256 differs")
    if hashes.get(SELECTION_MEMBER) != SELECTION_SHA256:
        raise RuntimeError("selection evidence SHA-256 differs")
    for forbidden_entry in (
        "scripts/run_daily_camels_ukf_knet_parity.py",
        "hpc/daily_camels_ukf_knet_parity/submit_train_gpu.slurm",
    ):
        if forbidden_entry in hashes:
            raise RuntimeError(f"training entry entered A39 bundle: {forbidden_entry}")

    external = _mapping(manifest.get("external_artifacts"), "external artifacts")
    expected_external = {
        "checkpoint": {
            "path": CHECKPOINT_PATH_TEXT,
            "sha256": CHECKPOINT_SHA256,
            "size": CHECKPOINT_SIZE,
        },
        "evaluation_archive": {
            "path": EVALUATION_ARCHIVE_PATH_TEXT,
            "sha256": EVALUATION_ARCHIVE_SHA256,
            "size": EVALUATION_ARCHIVE_SIZE,
            "packaged": False,
        },
        "a38_original_terminal_evidence_identity": {
            "historical_path": A38_ORIGINAL_TERMINAL_ARCHIVE_PATH_TEXT,
            "sha256": A38_ORIGINAL_TERMINAL_ARCHIVE_SHA256,
            "size": A38_ORIGINAL_TERMINAL_ARCHIVE_SIZE,
            "available_at_runtime": False,
            "identity_role": "historical_source_container",
        },
        "a38_reconstructed_terminal_evidence_archive": {
            "path": A38_RECONSTRUCTED_TERMINAL_ARCHIVE_PATH_TEXT,
            "sha256": A38_RECONSTRUCTED_TERMINAL_ARCHIVE_SHA256,
            "size": A38_RECONSTRUCTED_TERMINAL_ARCHIVE_SIZE,
            "packaged": False,
            "opened_as": "opaque_bytes_only",
            "member_count": 33,
            "reserved_evaluation_member_count": 0,
        },
        "a38_member_identity_receipt": {
            "path": A38_MEMBER_IDENTITY_RECEIPT_PATH_TEXT,
            "sha256": A38_MEMBER_IDENTITY_RECEIPT_SHA256,
            "size": A38_MEMBER_IDENTITY_RECEIPT_SIZE,
            "packaged": False,
            "canonical_member_inventory_sha256": (
                A38_CANONICAL_MEMBER_INVENTORY_SHA256
            ),
        },
    }
    _require_exact(dict(external), expected_external, "external artifact inventory")
    config = _read_json(root / CONFIG_MEMBER)
    validate_config(config)
    source_files = _mapping(config.get("source_files"), "config source inventory")
    if not source_files:
        raise RuntimeError("config source inventory is empty")
    for name, expected in source_files.items():
        if name not in hashes or hashes[name] != expected:
            raise RuntimeError(f"config source identity differs from bundle: {name}")
    registry = _read_json(root / REGISTRY_MEMBER)
    _require_exact(registry.get("experiment_id"), EXPERIMENT_ID, "registry experiment")
    _require_exact(
        registry.get("execution_attempt_id"), EXECUTION_ID, "registry execution"
    )
    authorization = _mapping(registry.get("authorization"), "registry authorization")
    _require_exact(
        authorization.get("instruction_utf8_sha256"),
        "57c0dad7188249e27bcf585f0f452f617554a083e79ea2589ff61cbcabedd231",
        "authorization SHA-256",
    )
    _require_exact(
        authorization.get("instruction_utf8_size_bytes"), 111, "authorization size"
    )
    plans = _mapping(registry.get("frozen_documents"), "registry plans")
    _require_exact(
        plans.get("formal_evaluation_plan"), FORMAL_PLAN_MEMBER, "formal plan path"
    )
    _require_exact(
        plans.get("formal_evaluation_plan_sha256"),
        FORMAL_PLAN_SHA256,
        "formal plan SHA-256",
    )
    _require_exact(
        plans.get("next_stage_plan"), NEXT_STAGE_PLAN_MEMBER, "next-stage plan path"
    )
    _require_exact(
        plans.get("next_stage_plan_sha256"),
        NEXT_STAGE_PLAN_SHA256,
        "next-stage plan SHA-256",
    )
    _require_exact(
        plans.get("active_configuration"), CONFIG_MEMBER, "active configuration path"
    )
    _require_exact(
        plans.get("active_configuration_sha256"),
        hashes[CONFIG_MEMBER],
        "active configuration SHA-256",
    )
    _require_exact(
        hashes.get(FORMAL_PLAN_MEMBER), FORMAL_PLAN_SHA256, "bundled formal plan"
    )
    _require_exact(
        hashes.get(NEXT_STAGE_PLAN_MEMBER),
        NEXT_STAGE_PLAN_SHA256,
        "bundled next-stage plan",
    )
    source_evidence = _mapping(
        registry.get("source_evidence"), "registry source evidence"
    )
    _require_exact(
        source_evidence.get("a38_terminal_archive_path"),
        A38_ORIGINAL_TERMINAL_ARCHIVE_PATH_TEXT,
        "registry A38 archive path",
    )
    _require_exact(
        source_evidence.get("a38_terminal_archive_sha256"),
        A38_ORIGINAL_TERMINAL_ARCHIVE_SHA256,
        "registry A38 archive SHA-256",
    )
    _require_exact(
        source_evidence.get("a38_terminal_archive_size_bytes"),
        A38_ORIGINAL_TERMINAL_ARCHIVE_SIZE,
        "registry A38 archive size",
    )
    reconstruction = _mapping(
        source_evidence.get("transport_reconstruction"),
        "registry A38 transport reconstruction",
    )
    expected_reconstruction = {
        "original_archive_sha256": A38_ORIGINAL_TERMINAL_ARCHIVE_SHA256,
        "reconstructed_archive_source_path": (
            "/data1/home/sunyiq/kalmannet_daily_camels_knet_a38_terminal_evidence_"
            "reconstruct_seq89_20260831/"
            "DAILY_CAMELS_KNET_A38_JOB215801_TERMINAL_EVIDENCE_RECONSTRUCT_SEQ89.tar.gz"
        ),
        "reconstructed_archive_runtime_path": (
            A38_RECONSTRUCTED_TERMINAL_ARCHIVE_PATH_TEXT
        ),
        "reconstructed_archive_sha256": A38_RECONSTRUCTED_TERMINAL_ARCHIVE_SHA256,
        "reconstructed_archive_size_bytes": A38_RECONSTRUCTED_TERMINAL_ARCHIVE_SIZE,
        "reconstructed_archive_member_count": 33,
        "reconstructed_archive_reserved_member_count": 0,
        "verification_receipt_source_path": (
            "/data1/home/sunyiq/kalmannet_daily_camels_knet_a38_terminal_evidence_"
            "verify_seq90_20260831/member_identity_verification.json"
        ),
        "verification_receipt_runtime_path": A38_MEMBER_IDENTITY_RECEIPT_PATH_TEXT,
        "verification_receipt_sha256": A38_MEMBER_IDENTITY_RECEIPT_SHA256,
        "verification_receipt_size_bytes": A38_MEMBER_IDENTITY_RECEIPT_SIZE,
        "canonical_member_inventory_sha256": A38_CANONICAL_MEMBER_INVENTORY_SHA256,
        "verification_result_sha256": (
            "dacc0fb4c28ac48942f892df3015b7f92f0b2c9df9e04cf387534d55ac93d74d"
        ),
        "verification_result_size_bytes": 2_092,
        "equivalence_scope": "member_names_order_sizes_and_content_hashes",
        "member_content_identity_verified": True,
        "container_byte_identity_equal": False,
        "difference_classification": "container_metadata_only",
        "evaluation_array_reads": 0,
        "formal_evaluation_outputs_created": 0,
    }
    _require_exact(
        dict(reconstruction),
        expected_reconstruction,
        "registry A38 transport reconstruction",
    )
    slurm_source = (
        root
        / "hpc/daily_camels_knet_formal_evaluation/submit_evaluation_gpu.slurm"
    ).read_text(encoding="utf-8")
    executable_lines = "\n".join(
        line
        for line in slurm_source.lower().splitlines()
        if not line.lstrip().startswith("#")
    )
    for forbidden in (
        "sbatch ",
        "scancel ",
        "scontrol update",
        "submit_train",
        "run_training",
        "optimizer.step",
        ".backward(",
    ):
        if forbidden in executable_lines:
            raise RuntimeError(f"Slurm entry contains forbidden operation: {forbidden}")
    return manifest, config


def verify_external_artifact(
    path: Path,
    *,
    expected_path: Path,
    expected_sha256: str,
    expected_size: int | None,
    label: str,
) -> dict[str, Any]:
    candidate = Path(path)
    if candidate != Path(expected_path):
        raise RuntimeError(f"{label} path differs from the frozen contract")
    if candidate.is_symlink():
        raise RuntimeError(f"{label} may not be symbolic")
    if not candidate.is_file():
        raise RuntimeError(f"{label} is absent or not a regular file")
    size = candidate.stat().st_size
    if expected_size is not None and size != expected_size:
        raise RuntimeError(f"{label} size differs from the frozen contract")
    actual_sha256 = sha256_file(candidate)
    if actual_sha256 != expected_sha256:
        raise RuntimeError(f"{label} SHA-256 differs from the frozen contract")
    return {
        "path": str(candidate),
        "size": size,
        "sha256": actual_sha256,
        "opened_as": "opaque_bytes_only",
    }


def verify_a38_member_identity_receipt(path: Path) -> dict[str, Any]:
    evidence = verify_external_artifact(
        path,
        expected_path=A38_MEMBER_IDENTITY_RECEIPT_PATH,
        expected_sha256=A38_MEMBER_IDENTITY_RECEIPT_SHA256,
        expected_size=A38_MEMBER_IDENTITY_RECEIPT_SIZE,
        label="A38 member-identity receipt",
    )
    receipt = _read_json(Path(path))
    expected = {
        "archive_member_count": 33,
        "archive_reserved_member_count": 0,
        "archive_size_bytes": A38_RECONSTRUCTED_TERMINAL_ARCHIVE_SIZE,
        "canonical_member_inventory_sha256": (
            A38_CANONICAL_MEMBER_INVENTORY_SHA256
        ),
        "container_byte_identity_reproduced": False,
        "evaluation_array_reads": 0,
        "formal_evaluation_outputs_created": 0,
        "member_content_identity_verified": True,
        "original_archive_missing": True,
        "original_archive_sha256": A38_ORIGINAL_TERMINAL_ARCHIVE_SHA256,
        "reconstructed_archive_path": (
            "/data1/home/sunyiq/kalmannet_daily_camels_knet_a38_terminal_evidence_"
            "reconstruct_seq89_20260831/"
            "DAILY_CAMELS_KNET_A38_JOB215801_TERMINAL_EVIDENCE_RECONSTRUCT_SEQ89.tar.gz"
        ),
        "reconstructed_archive_sha256": (
            A38_RECONSTRUCTED_TERMINAL_ARCHIVE_SHA256
        ),
        "schema_version": "a38_terminal_evidence_member_identity_verification_v1",
        "source_execution_id": (
            "DAILY_CAMELS_KNET_FIXED_FULL_TRAINING_COVERAGE_A38_A800_TRAIN1_SEQ70"
        ),
        "source_experiment_id": (
            "DAILY_CAMELS_KNET_FIXED_FULL_TRAINING_COVERAGE_"
            "EPOCH40_TO80_RESUME_STEP_MONOTONICITY_DIAGNOSTIC_V1_20260828_A38"
        ),
        "source_job_id": 215801,
        "source_result82_sha256": (
            "a16bfb72c526ff8ec15bb5940b80d4abe8aabe96ffda6bdd322ea604a4229e69"
        ),
        "source_result89_sha256": (
            "4a04920a7da01b44c61c0f486e4cb6e1760698f93e7d1fa2f845c84083b88045"
        ),
    }
    _require_exact(receipt, expected, "A38 member-identity receipt payload")
    evidence["opened_as"] = "json_text_contract_only"
    evidence["member_content_identity_verified"] = True
    evidence["container_byte_identity_reproduced"] = False
    evidence["canonical_member_inventory_sha256"] = (
        A38_CANONICAL_MEMBER_INVENTORY_SHA256
    )
    return evidence


def available_host_memory_bytes() -> int:
    with Path("/proc/meminfo").open("r", encoding="ascii") as handle:
        for line in handle:
            if line.startswith("MemAvailable:"):
                fields = line.split()
                if len(fields) == 3 and fields[2] == "kB":
                    return int(fields[1]) * 1024
    raise RuntimeError("MemAvailable is unavailable")


def probe_gpu(env: Mapping[str, str]) -> dict[str, Any]:
    visible = env.get("CUDA_VISIBLE_DEVICES", "")
    if not visible or "," in visible:
        raise RuntimeError("exactly one CUDA device must be visible")
    completed = subprocess.run(
        [
            "nvidia-smi",
            "--id",
            visible,
            "--query-gpu=name,memory.total,memory.free",
            "--format=csv,noheader,nounits",
        ],
        check=False,
        capture_output=True,
        text=True,
        timeout=20,
    )
    if completed.returncode != 0:
        raise RuntimeError(f"nvidia-smi failed: {completed.stderr.strip()}")
    lines = [line.strip() for line in completed.stdout.splitlines() if line.strip()]
    if len(lines) != 1:
        raise RuntimeError("GPU query did not return exactly one device")
    fields = [field.strip() for field in lines[0].split(",")]
    if len(fields) != 3:
        raise RuntimeError("GPU query output is malformed")
    try:
        total_mib = int(fields[1])
        free_mib = int(fields[2])
    except ValueError as error:
        raise RuntimeError("GPU memory values are malformed") from error
    return {
        "visible_device": visible,
        "name": fields[0],
        "total_mib": total_mib,
        "free_mib": free_mib,
    }


def _parse_optional_slurm_gpu_count(value: str) -> int | None:
    raw = value.strip()
    if not raw:
        return None
    count_text = raw.split("(", 1)[0]
    if count_text.isdecimal():
        return int(count_text)
    fields = count_text.split(":")
    if len(fields) >= 2 and fields[-1].isdecimal() and all(fields[:-1]):
        return int(fields[-1])
    return None


def validate_resource_admission(
    env: Mapping[str, str],
    *,
    hostname: str,
    available_host_memory_bytes: int,
    gpu: Mapping[str, Any],
) -> dict[str, Any]:
    host = hostname.split(".", 1)[0]
    if host not in ALLOWED_HOSTS:
        raise RuntimeError(f"allocated host is outside ngu202/ngu203: {host}")
    if env.get("SLURM_JOB_PARTITION") != "hgpu8":
        raise RuntimeError("allocated partition is not hgpu8")
    if env.get("SLURM_NNODES") != "1" or env.get("SLURM_NTASKS") != "1":
        raise RuntimeError("allocation must contain one node and one task")
    slurm_gpus_on_node = env.get("SLURM_GPUS_ON_NODE", "").strip()
    parsed_slurm_gpu_count = _parse_optional_slurm_gpu_count(slurm_gpus_on_node)
    if parsed_slurm_gpu_count is not None and parsed_slurm_gpu_count != 1:
        raise RuntimeError(
            "allocation reports a non-single GPU count: "
            f"SLURM_GPUS_ON_NODE={slurm_gpus_on_node!r}"
        )
    visible_device = gpu.get("visible_device")
    if (
        not isinstance(visible_device, str)
        or not visible_device
        or "," in visible_device
    ):
        raise RuntimeError("runtime visibility does not contain exactly one GPU")
    if gpu.get("name") != EXPECTED_GPU_NAME:
        raise RuntimeError("allocated GPU is not NVIDIA A800-SXM4-80GB")
    if isinstance(available_host_memory_bytes, bool) or available_host_memory_bytes < MIN_HOST_MEMORY_BYTES:
        raise RuntimeError("available host memory is below the A39 admission threshold")
    free_mib = gpu.get("free_mib")
    if isinstance(free_mib, bool) or not isinstance(free_mib, int) or free_mib < MIN_GPU_FREE_MIB:
        raise RuntimeError("GPU free memory is below the A39 admission threshold")
    return {
        "status": "PASS",
        "slurm_job_id": env.get("SLURM_JOB_ID"),
        "partition": "hgpu8",
        "hostname": host,
        "nodes": 1,
        "tasks": 1,
        "gpu_count": 1,
        "gpu_count_evidence": {
            "fixed_slurm_request": "--gres=gpu:1",
            "cuda_visible_devices": visible_device,
            "nvidia_smi_visible_row_count": 1,
            "slurm_gpus_on_node_raw": slurm_gpus_on_node or None,
            "slurm_gpus_on_node_parsed_count": parsed_slurm_gpu_count,
            "slurm_gpus_on_node_required": False,
        },
        "gpu_name": EXPECTED_GPU_NAME,
        "gpu_total_mib": int(gpu["total_mib"]),
        "gpu_free_mib": int(free_mib),
        "gpu_free_memory_min_mib": MIN_GPU_FREE_MIB,
        "available_host_memory_bytes": int(available_host_memory_bytes),
        "host_memory_min_bytes": MIN_HOST_MEMORY_BYTES,
    }


def _verify_lock(path: Path, *, label: str) -> dict[str, Any]:
    lock = Path(path)
    if not lock.is_dir() or lock.is_symlink():
        raise RuntimeError(f"{label} must be a real directory")
    owner = lock / "owner.json"
    if not owner.is_file() or owner.is_symlink():
        raise RuntimeError(f"{label} owner evidence is absent or symbolic")
    payload = _read_json(owner)
    _require_exact(payload.get("experiment_id"), EXPERIMENT_ID, f"{label} experiment")
    _require_exact(payload.get("execution_id"), EXECUTION_ID, f"{label} execution")
    return payload


def _verify_submission_lock(path: Path, *, job_id: str) -> dict[str, Any]:
    lock = Path(path)
    if not lock.is_dir() or lock.is_symlink():
        raise RuntimeError("submission lock must be a real directory")
    owner_path = lock / "owner.json"
    bound_path = lock / "bound.json"
    for label, candidate in (("owner", owner_path), ("bound", bound_path)):
        if not candidate.is_file() or candidate.is_symlink():
            raise RuntimeError(
                f"submission lock {label} evidence is absent, non-regular, or symbolic"
            )
    owner = _read_json(owner_path)
    bound = _read_json(bound_path)
    expected_common = {
        "experiment_id": EXPERIMENT_ID,
        "execution_id": EXECUTION_ID,
        "submission_token": SUBMISSION_TOKEN,
        "persistent": True,
        "evaluation_only": True,
    }
    for label, payload in (("owner", owner), ("bound", bound)):
        for key, expected in expected_common.items():
            _require_exact(payload.get(key), expected, f"submission {label} {key}")
    _require_exact(owner.get("state"), "PREPARED", "submission owner state")
    _require_exact(bound.get("state"), "BOUND", "submission bound state")
    _require_exact(str(bound.get("slurm_job_id")), str(job_id), "submission bound job")
    return {"owner": owner, "bound": bound}


def run_preflight(
    *,
    bundle_root: Path,
    checkpoint: Path,
    evaluation_archive: Path,
    a38_terminal_evidence: Path,
    a38_reconstruction_receipt: Path,
    output_root: Path,
    verification_output: Path,
    submission_lock: Path,
    runtime_lock: Path,
    host_admission_min_bytes: int,
    gpu_admission_min_free_mib: int,
    report: Path,
    env: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    if "numpy" in sys.modules or "torch" in sys.modules:
        raise RuntimeError("numerical frameworks were imported before standard preflight")
    _require_exact(host_admission_min_bytes, MIN_HOST_MEMORY_BYTES, "host admission CLI")
    _require_exact(gpu_admission_min_free_mib, MIN_GPU_FREE_MIB, "GPU admission CLI")
    _require_exact(Path(output_root), OUTPUT_ROOT, "evaluation output CLI")
    _require_exact(Path(verification_output), VERIFICATION_OUTPUT, "verification output CLI")
    for label, target in (
        ("evaluation output", Path(output_root)),
        ("verification output", Path(verification_output)),
    ):
        if target.exists() or target.is_symlink():
            raise FileExistsError(f"{label} already exists: {target}")
        pending = sorted(target.parent.glob(f".{target.name}.pending-*"))
        if pending:
            raise FileExistsError(f"{label} has stale pending directories or files: {pending}")

    environment = dict(os.environ if env is None else env)
    job_id = environment.get("SLURM_JOB_ID")
    if not job_id:
        raise RuntimeError("A39 formal evaluation must run inside Slurm")
    _require_exact(
        environment.get("A39_SUBMISSION_TOKEN"),
        SUBMISSION_TOKEN,
        "submission token environment",
    )
    manifest, config = verify_bundle_root(bundle_root)
    submission_evidence = _verify_submission_lock(submission_lock, job_id=job_id)
    runtime_owner = _verify_lock(runtime_lock, label="runtime lock")
    _require_exact(str(runtime_owner.get("slurm_job_id")), job_id, "runtime lock job")

    checkpoint_evidence = verify_external_artifact(
        checkpoint,
        expected_path=CHECKPOINT_PATH,
        expected_sha256=CHECKPOINT_SHA256,
        expected_size=CHECKPOINT_SIZE,
        label="epoch-75 checkpoint",
    )
    evaluation_evidence = verify_external_artifact(
        evaluation_archive,
        expected_path=EVALUATION_ARCHIVE_PATH,
        expected_sha256=EVALUATION_ARCHIVE_SHA256,
        expected_size=EVALUATION_ARCHIVE_SIZE,
        label="historical evaluation archive",
    )
    a38_terminal_evidence_result = verify_external_artifact(
        a38_terminal_evidence,
        expected_path=A38_RECONSTRUCTED_TERMINAL_ARCHIVE_PATH,
        expected_sha256=A38_RECONSTRUCTED_TERMINAL_ARCHIVE_SHA256,
        expected_size=A38_RECONSTRUCTED_TERMINAL_ARCHIVE_SIZE,
        label="A38 reconstructed terminal evidence archive",
    )
    a38_reconstruction_receipt_result = verify_a38_member_identity_receipt(
        a38_reconstruction_receipt
    )
    gpu = probe_gpu(environment)
    resources = validate_resource_admission(
        environment,
        hostname=socket.gethostname(),
        available_host_memory_bytes=available_host_memory_bytes(),
        gpu=gpu,
    )
    evidence = {
        "schema_version": "daily_camels_knet_formal_evaluation_preflight_v1",
        "status": "PASS",
        "experiment_id": EXPERIMENT_ID,
        "execution_id": EXECUTION_ID,
        "formal_evaluation": True,
        "diagnostic_mode": False,
        "training_enabled": False,
        "optimizer_updates_allowed": False,
        "bundle_manifest_sha256": sha256_file(Path(bundle_root) / "bundle_manifest.json"),
        "bundle_member_count": manifest["member_count"],
        "config_identity": validate_config(config),
        "checkpoint": checkpoint_evidence,
        "evaluation_archive": evaluation_evidence,
        "a38_original_terminal_evidence_identity": {
            "historical_path": A38_ORIGINAL_TERMINAL_ARCHIVE_PATH_TEXT,
            "sha256": A38_ORIGINAL_TERMINAL_ARCHIVE_SHA256,
            "size": A38_ORIGINAL_TERMINAL_ARCHIVE_SIZE,
            "available_at_runtime": False,
        },
        "a38_reconstructed_terminal_evidence_archive": (
            a38_terminal_evidence_result
        ),
        "a38_member_identity_receipt": a38_reconstruction_receipt_result,
        "evaluation_array_payloads_materialized": 0,
        "resource_admission": resources,
        "submission_lock": submission_evidence,
        "runtime_lock": runtime_owner,
        "numpy_imported": "numpy" in sys.modules,
        "torch_imported": "torch" in sys.modules,
    }
    if evidence["numpy_imported"] or evidence["torch_imported"]:
        raise RuntimeError("standard preflight imported a numerical framework")
    _write_new_json(report, evidence)
    return evidence


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle-root", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--evaluation-archive", type=Path, required=True)
    parser.add_argument("--a38-terminal-evidence", type=Path, required=True)
    parser.add_argument("--a38-reconstruction-receipt", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--verification-output", type=Path, required=True)
    parser.add_argument("--submission-lock", type=Path, required=True)
    parser.add_argument("--runtime-lock", type=Path, required=True)
    parser.add_argument("--host-admission-min-bytes", type=int, required=True)
    parser.add_argument("--gpu-admission-min-free-mib", type=int, required=True)
    parser.add_argument("--report", type=Path, required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    arguments = build_parser().parse_args(argv)
    try:
        evidence = run_preflight(
            bundle_root=arguments.bundle_root,
            checkpoint=arguments.checkpoint,
            evaluation_archive=arguments.evaluation_archive,
            a38_terminal_evidence=arguments.a38_terminal_evidence,
            a38_reconstruction_receipt=arguments.a38_reconstruction_receipt,
            output_root=arguments.output_root,
            verification_output=arguments.verification_output,
            submission_lock=arguments.submission_lock,
            runtime_lock=arguments.runtime_lock,
            host_admission_min_bytes=arguments.host_admission_min_bytes,
            gpu_admission_min_free_mib=arguments.gpu_admission_min_free_mib,
            report=arguments.report,
        )
    except Exception as error:
        print(f"A39 formal-evaluation preflight failed: {error}", file=sys.stderr)
        return 2
    print(json.dumps(evidence, sort_keys=True, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
