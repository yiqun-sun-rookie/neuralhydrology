from __future__ import annotations

import importlib.util
from pathlib import Path
import sys
from unittest.mock import patch

import pytest


ROOT = Path(__file__).resolve().parents[1]
PREFLIGHT_PATH = ROOT / "hpc" / "daily_camels_ukf_knet_parity" / "preflight.py"
MODULE_NAME = "daily_camels_ukf_knet_parity_hpc_preflight_standalone"
BUILDER_PATH = ROOT / "scripts" / "build_daily_camels_ukf_knet_parity_hpc_bundle.py"
BUILDER_MODULE_NAME = "daily_camels_ukf_knet_parity_hpc_builder_standalone"
TRAIN_SLURM_PATH = (
    ROOT / "hpc" / "daily_camels_ukf_knet_parity" / "submit_train_gpu.slurm"
)


def _load_preflight_module():
    numerical_before = {name: name in sys.modules for name in ("numpy", "torch")}
    spec = importlib.util.spec_from_file_location(MODULE_NAME, PREFLIGHT_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load daily parity HPC preflight")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    numerical_after = {name: name in sys.modules for name in ("numpy", "torch")}
    assert numerical_after == numerical_before
    return module


PREFLIGHT = _load_preflight_module()


def _load_builder_module():
    numerical_before = {name: name in sys.modules for name in ("numpy", "torch")}
    spec = importlib.util.spec_from_file_location(BUILDER_MODULE_NAME, BUILDER_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load daily parity HPC bundle builder")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    numerical_after = {name: name in sys.modules for name in ("numpy", "torch")}
    assert numerical_after == numerical_before
    return module


BUILDER = _load_builder_module()


def test_training_submission_requires_both_current_replay_gate_paths() -> None:
    source = TRAIN_SLURM_PATH.read_text(encoding="utf-8")

    assert source.count("${PARITY_EXACT_REPLAY_GATE") >= 2
    assert source.count("${PARITY_CAUSAL_REPLAY_GATE") >= 2
    assert "replay_gate_DAILY_CAMELS_UKF_PARITY_KNET_FULL_STATE_V1_20260824_A01" not in source
    assert '--exact-replay-gate "${PARITY_EXACT_REPLAY_GATE}"' in source
    assert '--causal-replay-gate "${PARITY_CAUSAL_REPLAY_GATE}"' in source


def test_training_submission_preserves_gpu_and_cgroup_resource_evidence() -> None:
    source = TRAIN_SLURM_PATH.read_text(encoding="utf-8")

    assert "train-gpu-resources-${EXPERIMENT_ID}-${SLURM_JOB_ID}.csv" in source
    assert "train-cgroup-resources-${EXPERIMENT_ID}-${SLURM_JOB_ID}.txt" in source
    assert "memory.peak" in source
    assert "memory.max" in source
    assert "GPU_RESOURCE_SAMPLER_PID" in source
    assert "nvidia-smi" in source


def test_causal_bundle_selects_a_new_exact_replay_config_dynamically(tmp_path: Path) -> None:
    exact = ROOT / "configs/daily_camels_ukf_knet_parity_exact_replay_dtype_repair_v3.json"
    causal = ROOT / "configs/daily_camels_ukf_knet_parity_causal_replay_dtype_repair_v3.json"

    sources, active_member, exact_member, experiment_id, mode = (
        BUILDER.bundle_member_sources(
            ROOT,
            config_path=causal,
            exact_config_path=exact,
        )
    )

    assert active_member == causal.relative_to(ROOT).as_posix()
    assert exact_member == exact.relative_to(ROOT).as_posix()
    assert active_member in sources
    assert exact_member in sources
    assert "configs/daily_camels_ukf_knet_parity_v1.json" not in sources
    assert experiment_id.endswith("20260825_A06")
    assert mode == "causal_shared_spinup"

    result = BUILDER.build_bundle(
        tmp_path / "causal_bundle",
        config_path=causal,
        exact_config_path=exact,
        root=ROOT,
    )
    inspection = BUILDER.inspect_archive(result.archive_path)
    assert inspection.manifest["active_config_member"] == active_member
    assert inspection.manifest["exact_replay_config_member"] == exact_member


def test_pytest_is_optional_but_scientific_runtime_packages_are_required() -> None:
    def fake_find_spec(module: str):
        return None if module == "pytest" else object()

    with patch.object(
        PREFLIGHT.importlib.util, "find_spec", side_effect=fake_find_spec
    ), patch.object(
        PREFLIGHT.importlib.metadata,
        "version",
        side_effect=lambda distribution: f"test-{distribution}",
    ):
        report = PREFLIGHT._package_availability()

    assert report["numpy"] == {
        "available": True,
        "required_for_scientific_runtime": True,
        "version": "test-numpy",
    }
    assert report["torch"] == {
        "available": True,
        "required_for_scientific_runtime": True,
        "version": "test-torch",
    }
    assert report["pytest"] == {
        "available": False,
        "required_for_scientific_runtime": False,
        "version": None,
    }


def test_missing_scientific_runtime_package_still_fails_closed() -> None:
    with patch.object(
        PREFLIGHT.importlib.util,
        "find_spec",
        side_effect=lambda module: None if module == "numpy" else object(),
    ):
        with pytest.raises(RuntimeError, match="required package.*numpy"):
            PREFLIGHT._package_availability()


@pytest.mark.parametrize(
    ("exit_code", "available", "expected"),
    [
        (0, True, "passed"),
        (77, False, "skipped_pytest_unavailable"),
    ],
)
def test_remote_test_attestation_is_explicit(
    exit_code: int,
    available: bool,
    expected: str,
) -> None:
    status = PREFLIGHT._remote_test_attestation(
        exit_code,
        {"pytest": {"available": available}},
    )

    assert status == expected


@pytest.mark.parametrize(
    ("exit_code", "available"),
    [(0, False), (77, True), (1, True), (1, False)],
)
def test_remote_test_attestation_rejects_ambiguous_or_failed_states(
    exit_code: int,
    available: bool,
) -> None:
    with pytest.raises(RuntimeError, match="availability disagree"):
        PREFLIGHT._remote_test_attestation(
            exit_code,
            {"pytest": {"available": available}},
        )
