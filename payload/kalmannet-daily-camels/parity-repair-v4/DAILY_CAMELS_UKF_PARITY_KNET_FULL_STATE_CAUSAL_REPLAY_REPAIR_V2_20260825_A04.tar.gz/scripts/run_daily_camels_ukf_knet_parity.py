"""Sole fail-closed entry for daily CAMELS UKF/KalmanNet parity runs.

The module imports only the Python standard library at import time.  The
configuration contract, every pinned byte source, the development archive,
the TUKF06 selection record, the output target, and the initialization role
are checked before NumPy, PyTorch, or the numerical runner is imported.

``probe`` is read-only.  ``replay`` creates one new evidence directory and
executes only the UKF and zero-gain controls.  ``train`` creates one new
directory, repeats those controls, and is admitted only for causal shared
spin-up with an independently frozen 728-origin UKF reference objective.
"""

from __future__ import annotations

import argparse
import ast
import copy
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from hashlib import sha256
import importlib
import importlib.util
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import random
import re
import shutil
import socket
import subprocess
import sys
from types import ModuleType
from typing import Any, Iterable, Mapping, Sequence


DEFAULT_CONFIG_RELATIVE = (
    "configs/daily_camels_ukf_knet_parity_exact_replay_repair_v2.json"
)
CONTRACT_RELATIVE = (
    "src/global_hydrology/experiments/"
    "daily_camels_ukf_knet_parity_contract.py"
)
RUNNER_RELATIVE = (
    "src/global_hydrology/experiments/"
    "daily_camels_ukf_knet_parity_runner.py"
)
IO_RELATIVE = (
    "src/global_hydrology/experiments/daily_camels_native_knet_io.py"
)

# These two integration files are not part of the older TUKF06 source map, so
# this entry pins them explicitly.  Update only through a new reviewed run
# family when either byte stream changes.
EXPECTED_CONTRACT_SHA256 = (
    "36aba9321c946deab6c77649ef3d09b92539d180f3374fc3c81633c6efeff78c"
)
EXPECTED_RUNNER_SHA256 = (
    "f1ce86fa33b54345d90d56df588beadee8631450ebeca229643ca10f45111de2"
)
EXPECTED_IO_SHA256 = (
    "902ac7159f293fcf89cfbd8aa15e90927650cecbdec0d577da2b54fdf6101d8d"
)

PHASES = ("probe", "replay", "train")
OWNER_LOCK_DIRECTORY = ".owner.lock"
IDENTITY_FILE = "experiment_identity.json"
PREFLIGHT_FILE = "preflight.json"
EVENT_FILE = "events.jsonl"
REPLAY_FILE = "replay_evidence.json"
REPLAY_PREDICTIONS_FILE = "replay_predictions.npz"
FEATURE_FILE = "feature_diagnostics.json"
HISTORY_FILE = "epoch_history.json"
SUMMARY_FILE = "result_summary.json"
MANIFEST_FILE = "manifest.sha256.json"
COMPLETION_FILE = "completion.marker.json"
FAILURE_FILE = "failure.json"
CHECKPOINT_DIRECTORY = "checkpoints"
PREDICTION_DIRECTORY = "predictions"
CAUSAL_REFERENCE_KEY = (
    "causal_tukf06_complete_validation_objective_no_warmup"
)
CAUSAL_NSE_REFERENCE_KEY = "causal_tukf06_recovery_731_day_nse"
REFERENCE_ABSOLUTE_TOLERANCE = 1e-12
CONTRACT_MODULE_ALIAS = "_daily_camels_parity_contract_preflight"
IO_MODULE_ALIAS = "_daily_camels_parity_io_preflight"
EXPERIMENT_ID_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{7,127}\Z")


@dataclass(frozen=True)
class PreflightResult:
    repository_root: Path
    configuration_path: Path
    configuration: Mapping[str, Any]
    configuration_sha256: str
    contract: Any
    declared_source_sha256: Mapping[str, str]
    integration_source_sha256: Mapping[str, str]
    input_sha256: Mapping[str, str]
    input_paths: Mapping[str, Path]
    experiment_id: str
    initialization_mode: str
    scientific_claim_allowed: bool
    phase: str
    run_parent: Path
    run_directory: Path
    identity: Mapping[str, Any]
    identity_sha256: str


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def canonical_json_bytes(value: object) -> bytes:
    return (
        json.dumps(
            _jsonable(value),
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
        + b"\n"
    )


def _jsonable(value: object) -> object:
    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("JSON evidence contains a non-finite float")
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(key): _jsonable(member) for key, member in value.items()}
    if isinstance(value, (list, tuple, set, frozenset)):
        return [_jsonable(member) for member in value]
    if hasattr(value, "item"):
        try:
            return _jsonable(value.item())
        except (TypeError, ValueError):
            pass
    raise TypeError(f"value of type {type(value).__name__} is not JSON evidence")


def _reject_duplicate_members(pairs: Sequence[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON member: {key}")
        result[key] = value
    return result


def _read_json(path: Path) -> Mapping[str, Any]:
    try:
        value = json.loads(
            path.read_text(encoding="utf-8"),
            object_pairs_hook=_reject_duplicate_members,
            parse_constant=lambda token: (_ for _ in ()).throw(
                ValueError(f"non-finite JSON constant: {token}")
            ),
        )
    except UnicodeDecodeError as exc:
        raise ValueError(f"JSON is not UTF-8: {path}") from exc
    if not isinstance(value, Mapping):
        raise TypeError(f"JSON root must be an object: {path}")
    return value


def sha256_file(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _regular_file(path: Path, label: str) -> Path:
    candidate = Path(path)
    if not candidate.is_file() or candidate.is_symlink():
        raise FileNotFoundError(f"{label} must be a regular non-symlink file: {candidate}")
    return candidate


def _relative_path(value: object, label: str) -> str:
    if not isinstance(value, str) or not value or "\\" in value:
        raise ValueError(f"{label} must be a non-empty forward-slash relative path")
    path = PurePosixPath(value)
    if path.is_absolute() or ".." in path.parts or not path.parts:
        raise ValueError(f"{label} must remain below the repository root")
    return path.as_posix()


def _sha256(value: object, label: str) -> str:
    if not isinstance(value, str):
        raise TypeError(f"{label} must be a SHA-256 string")
    lowered = value.lower()
    if len(lowered) != 64 or any(c not in "0123456789abcdef" for c in lowered):
        raise ValueError(f"{label} must contain 64 hexadecimal characters")
    return lowered


def _normalize_nse_reference(
    value: object, leads: Sequence[int]
) -> dict[int, float]:
    ordered = tuple(int(lead) for lead in leads)
    if isinstance(value, Mapping):
        try:
            normalized = {lead: float(value.get(str(lead), value.get(lead))) for lead in ordered}
        except (TypeError, ValueError) as exc:
            raise ValueError("causal UKF NSE reference is invalid") from exc
    elif isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        if len(value) != len(ordered):
            raise ValueError("causal UKF NSE reference length differs from the lead count")
        try:
            normalized = {lead: float(member) for lead, member in zip(ordered, value)}
        except (TypeError, ValueError) as exc:
            raise ValueError("causal UKF NSE reference is invalid") from exc
    else:
        raise ValueError("causal training requires a per-lead UKF NSE reference")
    if any(not math.isfinite(member) for member in normalized.values()):
        raise ValueError("causal UKF NSE reference contains a non-finite value")
    return normalized


def _load_standard_library_module(alias: str, path: Path) -> ModuleType:
    existing = sys.modules.get(alias)
    if isinstance(existing, ModuleType):
        return existing
    specification = importlib.util.spec_from_file_location(alias, path)
    if specification is None or specification.loader is None:
        raise ImportError(f"cannot load module specification for {path}")
    module = importlib.util.module_from_spec(specification)
    sys.modules[alias] = module
    try:
        specification.loader.exec_module(module)
    except Exception:
        sys.modules.pop(alias, None)
        raise
    return module


def _resolved_child(root: Path, relative: str, label: str) -> Path:
    path = (root / Path(*PurePosixPath(relative).parts)).resolve()
    try:
        path.relative_to(root.resolve())
    except ValueError as exc:
        raise ValueError(f"{label} escapes the repository root") from exc
    return _regular_file(path, label)


def _assert_hash(path: Path, expected: str, label: str) -> str:
    actual = sha256_file(path)
    if actual != expected:
        raise RuntimeError(
            f"{label} SHA-256 changed: expected {expected}, received {actual}"
        )
    return actual


def _experiment_directory(run_parent: Path, experiment_id: str) -> tuple[Path, Path]:
    if not EXPERIMENT_ID_PATTERN.fullmatch(experiment_id):
        raise ValueError("experiment_id is not a safe stable directory name")
    parent = Path(run_parent).expanduser().resolve()
    destination = (parent / experiment_id).resolve()
    if destination.parent != parent:
        raise ValueError("experiment output must be one direct child of run-parent")
    return parent, destination


def _validate_training_hyperparameters(optimization: Mapping[str, Any]) -> None:
    for key in ("training_epochs", "steps_per_epoch"):
        value = optimization.get(key)
        if isinstance(value, bool) or not isinstance(value, int) or value < 1:
            raise ValueError(f"optimization.{key} must be a positive integer")
    for key in ("learning_rate", "gradient_maximum_norm"):
        value = optimization.get(key)
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError(f"optimization.{key} must be numeric")
        if not math.isfinite(float(value)) or float(value) <= 0.0:
            raise ValueError(f"optimization.{key} must be finite and positive")


def standard_preflight(
    config_path: Path,
    run_parent: Path,
    *,
    phase: str,
) -> PreflightResult:
    """Verify every frozen byte and output invariant without numerical imports."""

    if "torch" in sys.modules:
        raise RuntimeError("PyTorch was imported before the standard-library preflight")
    if phase not in PHASES:
        raise ValueError(f"phase must be one of {PHASES}")
    root = Path(__file__).resolve().parents[1]
    configuration_path = _regular_file(Path(config_path).resolve(), "configuration")
    configuration = _read_json(configuration_path)
    configuration_hash = sha256_file(configuration_path)

    contract_path = _resolved_child(root, CONTRACT_RELATIVE, "parity contract")
    runner_path = _resolved_child(root, RUNNER_RELATIVE, "parity runner")
    io_path = _resolved_child(root, IO_RELATIVE, "atomic persistence module")
    integration_hashes = {
        CONTRACT_RELATIVE: _assert_hash(
            contract_path, EXPECTED_CONTRACT_SHA256, "parity contract"
        ),
        RUNNER_RELATIVE: _assert_hash(
            runner_path, EXPECTED_RUNNER_SHA256, "parity runner"
        ),
        IO_RELATIVE: _assert_hash(io_path, EXPECTED_IO_SHA256, "persistence module"),
    }

    contract_module = _load_standard_library_module(CONTRACT_MODULE_ALIAS, contract_path)
    contract = contract_module.ParityContract.from_dict(configuration)

    declared = configuration.get("source_sha256")
    if not isinstance(declared, Mapping) or not declared:
        raise ValueError("source_sha256 must be a non-empty mapping")
    declared_hashes: dict[str, str] = {}
    for untrusted_relative, untrusted_digest in declared.items():
        relative = _relative_path(untrusted_relative, "source_sha256 path")
        expected = _sha256(untrusted_digest, f"source_sha256[{relative}]")
        source_path = _resolved_child(root, relative, f"frozen source {relative}")
        declared_hashes[relative] = _assert_hash(source_path, expected, relative)

    data = configuration.get("data")
    if not isinstance(data, Mapping):
        raise TypeError("data must be a JSON object")
    input_specs = (
        ("development_archive", "archive_path", "archive_sha256"),
        ("tukf06_selection", "tukf06_selection_path", "tukf06_selection_sha256"),
        ("tukf06_contract", "tukf06_contract_path", "tukf06_contract_sha256"),
    )
    input_hashes: dict[str, str] = {}
    input_paths: dict[str, Path] = {}
    for name, path_key, hash_key in input_specs:
        relative = _relative_path(data.get(path_key), f"data.{path_key}")
        expected = _sha256(data.get(hash_key), f"data.{hash_key}")
        input_path = _resolved_child(root, relative, name)
        input_paths[name] = input_path
        input_hashes[relative] = _assert_hash(input_path, expected, name)

    archive_relative = _relative_path(data.get("archive_path"), "data.archive_path")
    if input_hashes[archive_relative] != contract.archive_sha256:
        raise RuntimeError("archive hash differs between ParityContract and data block")

    initialization = configuration.get("initialization")
    if not isinstance(initialization, Mapping):
        raise TypeError("initialization must be a JSON object")
    initialization_mode = str(initialization.get("execution_mode"))
    if initialization_mode not in contract.allowed_initialization_modes:
        raise ValueError("execution initialization mode is not allowlisted")
    scientific_claim_allowed = initialization_mode == contract.scientific_initialization_mode

    experiment_id = configuration.get("experiment_id")
    if not isinstance(experiment_id, str):
        raise TypeError("experiment_id must be a string")
    parent, run_directory = _experiment_directory(run_parent, experiment_id)
    if run_directory.exists() or run_directory.is_symlink():
        raise FileExistsError(f"final run directory already exists: {run_directory}")

    policy = configuration.get("execution_policy")
    if policy is not None:
        if not isinstance(policy, Mapping):
            raise TypeError("execution_policy must be a JSON object")
        permission_key = {
            "probe": "allow_probe",
            "replay": "allow_replay",
            "train": "allow_training",
        }[phase]
        if policy.get(permission_key) is not True:
            raise PermissionError(
                f"execution_policy.{permission_key} does not authorize this phase"
            )

    reference = configuration.get("reference")
    if not isinstance(reference, Mapping):
        raise TypeError("reference must be a JSON object")
    exact_archived_value = reference.get(
        "tukf06_complete_validation_objective_no_warmup",
        reference.get("exact_tukf06_complete_validation_objective_no_warmup"),
    )
    if (
        isinstance(exact_archived_value, bool)
        or not isinstance(exact_archived_value, (int, float))
        or not math.isfinite(float(exact_archived_value))
    ):
        raise ValueError("the exact TUKF06 728-origin reference is missing or non-finite")
    independent_exact = reference.get(
        "independent_replay_complete_validation_objective_no_warmup"
    )
    if independent_exact is not None and (
        isinstance(independent_exact, bool)
        or not isinstance(independent_exact, (int, float))
        or not math.isfinite(float(independent_exact))
        or abs(float(exact_archived_value) - float(independent_exact))
        > REFERENCE_ABSOLUTE_TOLERANCE
    ):
        raise ValueError("the two frozen exact TUKF06 reference objectives disagree")

    if phase == "train":
        optimization = configuration.get("optimization")
        if not isinstance(optimization, Mapping):
            raise TypeError("optimization must be a JSON object")
        _validate_training_hyperparameters(optimization)
        if not scientific_claim_allowed:
            raise PermissionError(
                "train is forbidden for backward-time diagnostic initialization; "
                "use replay only and create a causal configuration for training"
            )
        causal_reference = reference.get(CAUSAL_REFERENCE_KEY)
        if (
            isinstance(causal_reference, bool)
            or not isinstance(causal_reference, (int, float))
            or not math.isfinite(float(causal_reference))
            or float(causal_reference) <= 0.0
        ):
            raise PermissionError(
                "causal training requires an independently frozen 728-origin UKF "
                f"reference at reference.{CAUSAL_REFERENCE_KEY}"
            )
        _normalize_nse_reference(
            reference.get(CAUSAL_NSE_REFERENCE_KEY), contract.leads
        )

    identity_sources = {**declared_hashes, **integration_hashes}
    identity = {
        "schema_version": "daily_camels_ukf_knet_parity_run_identity_v1",
        "experiment_id": experiment_id,
        "configuration_sha256": configuration_hash,
        "source_sha256": identity_sources,
        "input_sha256": input_hashes,
        "initialization_mode": initialization_mode,
        "phase": phase,
    }
    identity_hash = sha256(canonical_json_bytes(identity)).hexdigest()
    return PreflightResult(
        repository_root=root,
        configuration_path=configuration_path,
        configuration=configuration,
        configuration_sha256=configuration_hash,
        contract=contract,
        declared_source_sha256=declared_hashes,
        integration_source_sha256=integration_hashes,
        input_sha256=input_hashes,
        input_paths=input_paths,
        experiment_id=experiment_id,
        initialization_mode=initialization_mode,
        scientific_claim_allowed=scientific_claim_allowed,
        phase=phase,
        run_parent=parent,
        run_directory=run_directory,
        identity=identity,
        identity_sha256=identity_hash,
    )


def _host_resource_snapshot(path: Path | None = None) -> Mapping[str, Any]:
    target = Path.cwd() if path is None else Path(path)
    disk = shutil.disk_usage(target if target.exists() else target.parent)
    result: dict[str, Any] = {
        "disk_free_bytes": int(disk.free),
        "disk_total_bytes": int(disk.total),
    }
    meminfo = Path("/proc/meminfo")
    if meminfo.is_file():
        values: dict[str, int] = {}
        for line in meminfo.read_text(encoding="utf-8").splitlines():
            parts = line.replace(":", "").split()
            if len(parts) >= 2 and parts[0] in {"MemTotal", "MemAvailable"}:
                values[parts[0]] = int(parts[1]) * 1024
        result.update(
            {
                "host_memory_total_bytes": values.get("MemTotal"),
                "host_memory_available_bytes": values.get("MemAvailable"),
            }
        )
    return result


def _nvidia_smi_probe() -> Mapping[str, Any]:
    executable = shutil.which("nvidia-smi")
    if executable is None:
        return {"available": False, "error": "nvidia-smi_not_found", "devices": []}
    completed = subprocess.run(
        [
            executable,
            "--query-gpu=index,name,memory.total,memory.free",
            "--format=csv,noheader,nounits",
        ],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=15,
        check=False,
    )
    devices: list[dict[str, Any]] = []
    if completed.returncode == 0:
        for line in completed.stdout.splitlines():
            fields = [field.strip() for field in line.split(",")]
            if len(fields) == 4:
                devices.append(
                    {
                        "index": int(fields[0]),
                        "name": fields[1],
                        "memory_total_mib": int(fields[2]),
                        "memory_free_mib": int(fields[3]),
                    }
                )
    return {
        "available": completed.returncode == 0 and bool(devices),
        "returncode": completed.returncode,
        "stderr": completed.stderr.strip(),
        "devices": devices,
    }


def preflight_report(preflight: PreflightResult, *, device: str) -> Mapping[str, Any]:
    gpu = _nvidia_smi_probe()
    if device == "cuda" and not gpu["available"]:
        raise RuntimeError("CUDA phase requested but the standard-library GPU probe failed")
    return {
        "schema_version": "daily_camels_ukf_knet_parity_preflight_v1",
        "status": "PREFLIGHT_PASS",
        "recorded_at_utc": _utc_now(),
        "host_name": socket.gethostname(),
        "process_id": os.getpid(),
        "python_version": sys.version,
        "phase": preflight.phase,
        "device_requested": device,
        "experiment_id": preflight.experiment_id,
        "identity_sha256": preflight.identity_sha256,
        "configuration_path": str(preflight.configuration_path),
        "configuration_sha256": preflight.configuration_sha256,
        "declared_source_sha256": dict(preflight.declared_source_sha256),
        "integration_source_sha256": dict(preflight.integration_source_sha256),
        "input_sha256": dict(preflight.input_sha256),
        "run_parent": str(preflight.run_parent),
        "run_directory": str(preflight.run_directory),
        "run_directory_absent": True,
        "initialization_mode": preflight.initialization_mode,
        "scientific_claim_allowed": preflight.scientific_claim_allowed,
        "reserved_evaluation_period_access_authorized": False,
        "array_members_materialized": 0,
        "numerical_frameworks_imported_by_entry": 0,
        "host_resources": _host_resource_snapshot(preflight.run_parent),
        "graphics_driver_probe": gpu,
    }


def _load_io(preflight: PreflightResult) -> ModuleType:
    return _load_standard_library_module(
        IO_MODULE_ALIAS, preflight.repository_root / IO_RELATIVE
    )


def _load_numerical_runtime(preflight: PreflightResult) -> tuple[ModuleType, ModuleType, ModuleType]:
    for path in (preflight.repository_root, preflight.repository_root / "src"):
        text = str(path)
        if text not in sys.path:
            sys.path.insert(0, text)
    numpy_module = importlib.import_module("numpy")
    torch_module = importlib.import_module("torch")
    runner_module = importlib.import_module(
        "global_hydrology.experiments.daily_camels_ukf_knet_parity_runner"
    )
    return numpy_module, torch_module, runner_module


def _write_json(io_module: ModuleType, path: Path, value: object, *, replace: bool) -> str:
    return io_module.atomic_write_bytes(path, canonical_json_bytes(value), replace=replace)


def _write_npz(
    io_module: ModuleType,
    numpy_module: ModuleType,
    path: Path,
    arrays: Mapping[str, Any],
    *,
    replace: bool = False,
) -> str:
    buffer = io.BytesIO()
    numpy_module.savez_compressed(buffer, **dict(arrays))
    return io_module.atomic_write_bytes(path, buffer.getvalue(), replace=replace)


def _append_event(
    io_module: ModuleType,
    path: Path,
    events: list[dict[str, Any]],
    value: Mapping[str, Any],
) -> str:
    row = dict(value)
    row["sequence"] = len(events)
    row["recorded_at_utc"] = _utc_now()
    events.append(row)
    content = b"".join(canonical_json_bytes(event) for event in events)
    return io_module.atomic_write_bytes(path, content, replace=path.exists())


def _ledger_dict(ledger: Any) -> Mapping[str, Any]:
    return {
        "archive_member_reads": dict(ledger.archive_member_reads),
        "date_requests": int(ledger.date_requests),
        "evaluation_array_reads": int(ledger.evaluation_array_reads),
        "evaluation_prediction_count": int(ledger.evaluation_prediction_count),
        "evaluation_metric_count": int(ledger.evaluation_metric_count),
        "evaluation_output_count": int(ledger.evaluation_output_count),
    }


def _assert_zero_reserved_access(ledger: Any) -> None:
    counters = (
        ledger.evaluation_array_reads,
        ledger.evaluation_prediction_count,
        ledger.evaluation_metric_count,
        ledger.evaluation_output_count,
    )
    if any(int(value) != 0 for value in counters):
        raise PermissionError("reserved evaluation access ledger is nonzero")


def _score_pairs(runner: ModuleType, score: Any) -> Any:
    return runner.ForecastPairs(
        predictions=score.predictions,
        targets=score.targets,
        issue_indices=score.issue_indices,
        target_indices=score.target_indices,
        finite_masks=score.finite_masks,
    )


def _array_digest(numpy_module: ModuleType, values: Any) -> str:
    array = numpy_module.ascontiguousarray(numpy_module.asarray(values))
    digest = sha256()
    digest.update(str(array.dtype).encode("ascii"))
    digest.update(numpy_module.asarray(array.shape, dtype=numpy_module.int64).tobytes())
    digest.update(array.tobytes())
    return digest.hexdigest()


def _score_evidence(
    numpy_module: ModuleType,
    score: Any,
    *,
    global_start: int,
) -> Mapping[str, Any]:
    geometry: dict[str, Any] = {}
    for lead in sorted(score.target_indices):
        issue = numpy_module.asarray(score.issue_indices[lead], dtype=numpy_module.int64)
        target = numpy_module.asarray(score.target_indices[lead], dtype=numpy_module.int64)
        finite = numpy_module.asarray(score.finite_masks[lead], dtype=bool)
        geometry[str(lead)] = {
            "issue_indices_local": issue.tolist(),
            "issue_indices_global": (issue + int(global_start)).tolist(),
            "target_indices_local": target.tolist(),
            "target_indices_global": (target + int(global_start)).tolist(),
            "finite_mask_sha256": _array_digest(numpy_module, finite),
            "finite_target_count": int(finite.sum()),
        }
    return {
        "gate_objective_after_16_day_warmup": float(score.objective),
        "checkpoint_objective_without_warmup": float(
            score.full_objective_without_warmup
        ),
        "mse_by_lead_after_warmup": dict(score.mse_by_lead),
        "nse_by_lead_after_warmup": dict(score.nse_by_lead),
        "target_count_by_lead_after_warmup": dict(score.target_count_by_lead),
        "target_count_by_lead_without_warmup": dict(
            score.full_target_count_by_lead_without_warmup
        ),
        "geometry": geometry,
        "maximum_open_loop_difference": score.maximum_open_loop_difference,
        "metadata": dict(score.metadata or {}),
    }


def _replay_predictions(numpy_module: ModuleType, results: Mapping[str, Any]) -> Mapping[str, Any]:
    arrays: dict[str, Any] = {}
    for purpose, methods in results.items():
        for method, score in methods.items():
            for lead, values in score.predictions.items():
                arrays[f"{purpose}__{method}__lead_{lead}__prediction"] = values
            for lead, values in score.targets.items():
                arrays[f"{purpose}__{method}__lead_{lead}__target"] = values
            for lead, values in score.target_indices.items():
                arrays[f"{purpose}__{method}__lead_{lead}__target_index"] = values
    return arrays


def _expected_ukf_reference(preflight: PreflightResult) -> float | None:
    reference = preflight.configuration["reference"]
    if preflight.scientific_claim_allowed:
        value = reference.get(CAUSAL_REFERENCE_KEY)
        return None if value is None else float(value)
    value = reference.get(
        "independent_replay_complete_validation_objective_no_warmup",
        reference.get(
            "tukf06_complete_validation_objective_no_warmup",
            reference.get("exact_tukf06_complete_validation_objective_no_warmup"),
        ),
    )
    return float(value)


def execute_replay(
    preflight: PreflightResult,
    numpy_module: ModuleType,
    torch_module: ModuleType,
    runner: ModuleType,
    ledger: Any,
    *,
    device: str,
) -> tuple[Any, Mapping[str, Any], Mapping[str, Any]]:
    """Replay both fixed windows before any optimization is admitted."""

    model = preflight.configuration["model"]
    optimization = preflight.configuration["optimization"]
    runtime = runner.load_archive_context(
        preflight.input_paths["development_archive"],
        preflight.contract,
        ledger,
        initialization_mode=preflight.initialization_mode,
        device=device,
    )
    results: dict[str, dict[str, Any]] = {}
    evidence: dict[str, Any] = {
        "schema_version": "daily_camels_ukf_knet_parity_replay_v1",
        "experiment_id": preflight.experiment_id,
        "identity_sha256": preflight.identity_sha256,
        "initialization": asdict(runtime.initialization_evidence),
        "scientific_claim_allowed": runtime.initialization_evidence.scientific_claim_allowed,
        "diagnostic_limitation": preflight.configuration["initialization"][
            "diagnostic_limitation"
        ],
        "covariance_roles": {
            "ukf_initial_covariance_diagonal": runtime.context.initial_covariance[
                0
            ].diagonal().detach().cpu().tolist(),
            "knet_hidden_prior_state_covariance_diagonal": runtime.context.plain_model.prior_state_cov.diagonal().detach().cpu().tolist(),
            "covariances_are_identical": False,
            "interpretation": (
                "UKF initial state uncertainty and KalmanNet recurrent hidden-state "
                "prior are model-specific quantities; parity does not require equality"
            ),
        },
        "windows": {},
    }
    for purpose in ("diagnostic", "recovery"):
        window = runner.select_window(runtime, purpose)
        ukf = runner.replay_tukf06_ukf(
            runtime,
            window,
            selection_path=preflight.input_paths["tukf06_selection"],
        )
        zero = runner.replay_zero_gain_open_loop(
            runtime,
            window,
            seed=int(optimization["seed"]),
            hidden=int(model["hidden_dimension"]),
            in_mult=int(model["input_multiplier"]),
            out_mult=int(model["output_multiplier"]),
            feature_scale_floor=float(model["feature_scale_floor"]),
            normalized_feature_guard=float(model["normalized_feature_guard"]),
        )
        runner.assert_identical_forecast_geometry(
            _score_pairs(runner, ukf), _score_pairs(runner, zero)
        )
        if zero.maximum_open_loop_difference != 0.0:
            raise RuntimeError("zero-gain KalmanNet is not the exact shared open loop")
        expected_after = (
            preflight.contract.expected_diagnostic_target_count_per_lead
            if purpose == "diagnostic"
            else preflight.contract.expected_recovery_target_count_per_lead
        )
        if dict(ukf.target_count_by_lead) != {
            lead: expected_after for lead in preflight.contract.leads
        }:
            raise RuntimeError(f"{purpose} UKF target count changed")
        if dict(zero.target_count_by_lead) != dict(ukf.target_count_by_lead):
            raise RuntimeError(f"{purpose} zero-gain target count differs from UKF")
        if purpose == "recovery":
            expected_full = len(window.observations) - max(preflight.contract.leads)
            required = {lead: expected_full for lead in preflight.contract.leads}
            if dict(ukf.full_target_count_by_lead_without_warmup) != required:
                raise RuntimeError("recovery UKF does not use 728 no-warmup origins")
            if dict(zero.full_target_count_by_lead_without_warmup) != required:
                raise RuntimeError("zero-gain replay does not use 728 no-warmup origins")
            expected_reference = _expected_ukf_reference(preflight)
            actual_reference = float(ukf.full_objective_without_warmup)
            if expected_reference is not None and abs(
                actual_reference - expected_reference
            ) > REFERENCE_ABSOLUTE_TOLERANCE:
                raise RuntimeError(
                    "complete-window UKF 728-origin physical objective differs from "
                    f"the frozen reference: expected {expected_reference}, got {actual_reference}"
                )
            expected_nse = None
            if preflight.scientific_claim_allowed:
                raw_nse = preflight.configuration["reference"].get(
                    CAUSAL_NSE_REFERENCE_KEY
                )
                if raw_nse is not None:
                    expected_nse = _normalize_nse_reference(
                        raw_nse, preflight.contract.leads
                    )
                    for lead in preflight.contract.leads:
                        actual_nse = float(ukf.nse_by_lead[lead])
                        if abs(actual_nse - expected_nse[lead]) > REFERENCE_ABSOLUTE_TOLERANCE:
                            raise RuntimeError(
                                f"causal UKF lead-{lead} NSE differs from the frozen reference"
                            )
            evidence["recovery_reference"] = {
                "reference_was_frozen_before_replay": expected_reference is not None,
                "expected_checkpoint_objective_728": expected_reference,
                "actual_checkpoint_objective_728": actual_reference,
                "objective_match": (
                    None
                    if expected_reference is None
                    else abs(actual_reference - expected_reference)
                    <= REFERENCE_ABSOLUTE_TOLERANCE
                ),
                "expected_nse_by_lead_712": expected_nse,
                "actual_nse_by_lead_712": dict(ukf.nse_by_lead),
                "candidate_for_new_frozen_causal_config": expected_reference is None,
            }
        results[purpose] = {"ukf": ukf, "zero_gain_knet": zero}
        evidence["windows"][purpose] = {
            "global_start_index": int(window.global_start),
            "global_end_exclusive": int(window.global_end_exclusive),
            "first_date": str(window.dates[0].astype("datetime64[D]")),
            "last_date": str(window.dates[-1].astype("datetime64[D]")),
            "ukf": _score_evidence(
                numpy_module, ukf, global_start=window.global_start
            ),
            "zero_gain_knet": _score_evidence(
                numpy_module, zero, global_start=window.global_start
            ),
            "identical_ukf_knet_geometry": True,
        }
    _assert_zero_reserved_access(ledger)
    evidence["access_ledger"] = _ledger_dict(ledger)
    return runtime, results, evidence


def _quantiles(numpy_module: ModuleType, values: Any) -> Mapping[str, float]:
    array = numpy_module.asarray(values, dtype=numpy_module.float64).reshape(-1)
    array = array[numpy_module.isfinite(array)]
    if array.size == 0:
        raise ValueError("feature diagnostic has no finite values")
    probabilities = (0.0, 0.01, 0.05, 0.5, 0.95, 0.99, 1.0)
    calculated = numpy_module.quantile(array, probabilities)
    return {f"q{int(probability * 100):02d}": float(value) for probability, value in zip(probabilities, calculated)}


def training_scale_diagnostics(
    runtime: Any,
    runner: ModuleType,
    numpy_module: ModuleType,
    *,
    floor: float,
    guard: float,
) -> Mapping[str, Any]:
    states = runner.training_open_loop_states(runtime)[:, 0, :].detach().cpu().numpy()
    observations = runtime.observations[: runtime.training_days, 0].detach().cpu().numpy()
    observation_difference = numpy_module.diff(observations)
    state_difference = numpy_module.diff(states, axis=0)
    finite_observation = numpy_module.isfinite(observation_difference)
    observation_rms_raw = float(
        numpy_module.sqrt(numpy_module.mean(observation_difference[finite_observation] ** 2))
    )
    valid_state = numpy_module.isfinite(state_difference)
    state_counts = valid_state.sum(axis=0)
    if bool((state_counts == 0).any()):
        raise ValueError("a state feature has no finite training differences")
    state_rms_raw = numpy_module.sqrt(
        numpy_module.where(valid_state, state_difference ** 2, 0.0).sum(axis=0)
        / state_counts
    )
    observation_scale = max(observation_rms_raw, float(floor))
    state_scale = numpy_module.maximum(state_rms_raw, float(floor))
    normalized_observation = observation_difference[finite_observation] / observation_scale
    normalized_state = state_difference / state_scale.reshape(1, -1)
    return {
        "fit_start_index": 0,
        "fit_end_exclusive": int(runtime.training_days),
        "fit_last_date": str(runtime.dates[runtime.training_days - 1].astype("datetime64[D]")),
        "validation_or_evaluation_values_used": 0,
        "floor": float(floor),
        "guard": float(guard),
        "observation_scale": float(observation_scale),
        "state_scales": state_scale.tolist(),
        "observation_raw_rms_before_floor": observation_rms_raw,
        "state_raw_rms_before_floor": state_rms_raw.tolist(),
        "observation_scale_hit_floor": observation_rms_raw < float(floor),
        "state_scale_floor_hit_count": int((state_rms_raw < float(floor)).sum()),
        "raw_observation_difference_quantiles": _quantiles(
            numpy_module, observation_difference
        ),
        "raw_state_difference_quantiles": _quantiles(numpy_module, state_difference),
        "normalized_observation_difference_quantiles": _quantiles(
            numpy_module, normalized_observation
        ),
        "normalized_state_difference_quantiles": _quantiles(
            numpy_module, normalized_state
        ),
        "observation_guard_saturation_fraction": float(
            numpy_module.mean(numpy_module.abs(normalized_observation) > float(guard))
        ),
        "state_guard_saturation_fraction": float(
            numpy_module.mean(numpy_module.abs(normalized_state) > float(guard))
        ),
        "state_guard_saturation_fraction_by_coordinate": numpy_module.mean(
            numpy_module.abs(normalized_state) > float(guard), axis=0
        ).tolist(),
    }


def _dynamic_feature_diagnostics(
    net: Any,
    runtime: Any,
    window: Any,
    runner: ModuleType,
    numpy_module: ModuleType,
    torch_module: ModuleType,
    *,
    guard: float,
) -> Mapping[str, Any]:
    net.eval()
    previous_observation = runner.previous_observation_before_window(runtime, window)
    with torch_module.no_grad():
        trace = runner.run_knet_filter(
            net,
            window,
            previous_observation=previous_observation,
        )
        initial = window.initial_state.detach()
        priors = trace.prior_states.detach()
        posteriors = trace.posterior_states.detach()
        observations = window.observations.detach()
        if previous_observation is None:
            previous_observation = window.context.plain_model.h(initial).reshape(1, 1)
        feature_lists: dict[str, list[Any]] = {
            "observation_difference": [],
            "observation_innovation": [],
            "forward_evolution": [],
            "forward_update": [],
        }
        for day in range(len(observations)):
            current_posterior = initial if day == 0 else posteriors[day - 1]
            previous_posterior = initial if day <= 1 else posteriors[day - 2]
            previous_prior = initial if day == 0 else priors[day - 1]
            observation = observations[day, 0].reshape(1, 1)
            valid = bool(torch_module.isfinite(observation).all())
            if valid:
                feature_lists["observation_difference"].append(
                    (observation - previous_observation) / net.observation_feature_scale
                )
                predicted_observation = window.context.plain_model.h(priors[day])
                feature_lists["observation_innovation"].append(
                    (observation - predicted_observation) / net.observation_feature_scale
                )
                feature_lists["forward_evolution"].append(
                    (current_posterior - previous_posterior) / net.state_feature_scale
                )
                feature_lists["forward_update"].append(
                    (current_posterior - previous_prior) / net.state_feature_scale
                )
                previous_observation = observation
            else:
                previous_observation = window.context.plain_model.h(priors[day]).reshape(1, 1)
    evidence: dict[str, Any] = {
        "window": window.purpose,
        "valid_update_count": int(trace.valid_updates.sum().detach().cpu()),
        "guard": float(guard),
    }
    for name, tensors in feature_lists.items():
        if not tensors:
            raise ValueError(f"no dynamic {name} features were observed")
        array = torch_module.cat(tensors, dim=0).detach().cpu().numpy()
        evidence[name] = {
            "normalized_quantiles": _quantiles(numpy_module, array),
            "guard_saturation_fraction": float(
                numpy_module.mean(numpy_module.abs(array) > float(guard))
            ),
            "maximum_absolute_value_before_guard": float(
                numpy_module.max(numpy_module.abs(array))
            ),
            "value_count": int(array.size),
        }
    return evidence


def _resource_peaks(torch_module: ModuleType, *, device: str) -> Mapping[str, Any]:
    result: dict[str, Any] = {}
    status = Path("/proc/self/status")
    if status.is_file():
        values: dict[str, int] = {}
        for line in status.read_text(encoding="utf-8").splitlines():
            fields = line.replace(":", "").split()
            if len(fields) >= 2 and fields[0] in {"VmRSS", "VmHWM"}:
                values[fields[0]] = int(fields[1]) * 1024
        result["host_current_rss_bytes"] = values.get("VmRSS")
        result["host_peak_rss_bytes"] = values.get("VmHWM")
        result["host_peak_measurement"] = "linux_proc_self_status_VmHWM"
    else:
        try:
            import resource  # standard library, unavailable on Windows

            peak = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
            result["host_peak_rss_platform_units"] = peak
            result["host_peak_measurement"] = "resource_ru_maxrss_platform_units"
        except ImportError:
            result["host_peak_measurement"] = "unavailable_on_platform"
    if device == "cuda":
        result.update(
            {
                "graphics_peak_allocated_bytes": int(
                    torch_module.cuda.max_memory_allocated()
                ),
                "graphics_peak_reserved_bytes": int(
                    torch_module.cuda.max_memory_reserved()
                ),
                "graphics_peak_measurement": "pytorch_process_allocator",
            }
        )
        free_bytes, total_bytes = torch_module.cuda.mem_get_info()
        result["graphics_free_bytes_at_snapshot"] = int(free_bytes)
        result["graphics_total_bytes"] = int(total_bytes)
    else:
        result["graphics_peak_allocated_bytes"] = 0
        result["graphics_peak_reserved_bytes"] = 0
        result["graphics_peak_measurement"] = "not_applicable_cpu_execution"
    return result


def _cpu_clone(value: Any, torch_module: ModuleType) -> Any:
    if torch_module.is_tensor(value):
        return value.detach().cpu().clone()
    if isinstance(value, Mapping):
        return {key: _cpu_clone(member, torch_module) for key, member in value.items()}
    if isinstance(value, tuple):
        return tuple(_cpu_clone(member, torch_module) for member in value)
    if isinstance(value, list):
        return [_cpu_clone(member, torch_module) for member in value]
    return copy.deepcopy(value)


def _checkpoint_bytes(torch_module: ModuleType, payload: Mapping[str, Any]) -> bytes:
    buffer = io.BytesIO()
    torch_module.save(dict(payload), buffer)
    return buffer.getvalue()


def _prediction_arrays(score: Any, numpy_module: ModuleType) -> Mapping[str, Any]:
    arrays: dict[str, Any] = {}
    for lead in sorted(score.predictions):
        arrays[f"lead_{lead}_prediction"] = numpy_module.asarray(score.predictions[lead])
        arrays[f"lead_{lead}_target"] = numpy_module.asarray(score.targets[lead])
        arrays[f"lead_{lead}_issue_index"] = numpy_module.asarray(score.issue_indices[lead])
        arrays[f"lead_{lead}_target_index"] = numpy_module.asarray(score.target_indices[lead])
        arrays[f"lead_{lead}_finite_mask"] = numpy_module.asarray(score.finite_masks[lead])
    return arrays


def _summarize_epoch_training_diagnostics(
    mse_values_by_lead: Mapping[int, Sequence[float]],
    finite_target_count_by_lead: Mapping[int, int],
    *,
    gradient_clipped_optimizer_step_count: int,
    optimizer_step_count: int,
) -> Mapping[str, Any]:
    """Summarize one epoch without changing the equal-lead training weights."""

    expected_leads = (1, 2, 3)
    if set(mse_values_by_lead) != set(expected_leads) or set(
        finite_target_count_by_lead
    ) != set(expected_leads):
        raise ValueError("epoch training diagnostics require leads 1, 2, and 3")
    if isinstance(optimizer_step_count, bool) or not isinstance(optimizer_step_count, int):
        raise TypeError("optimizer step count must be an integer")
    if optimizer_step_count < 0:
        raise ValueError("optimizer step count cannot be negative")
    clipped = gradient_clipped_optimizer_step_count
    if isinstance(clipped, bool) or not isinstance(clipped, int):
        raise TypeError("gradient-clipped optimizer step count must be an integer")
    if not 0 <= clipped <= optimizer_step_count:
        raise ValueError("gradient-clipped optimizer step count is outside the epoch")

    means: dict[int, float] = {}
    counts: dict[int, int] = {}
    for lead in expected_leads:
        values = tuple(mse_values_by_lead[lead])
        if len(values) != optimizer_step_count:
            raise ValueError(f"lead-{lead} MSE count differs from optimizer steps")
        normalized: list[float] = []
        for value in values:
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise TypeError(f"lead-{lead} MSE must be numeric")
            numeric = float(value)
            if not math.isfinite(numeric) or numeric < 0.0:
                raise ValueError(f"lead-{lead} MSE must be finite and nonnegative")
            normalized.append(numeric)

        count = finite_target_count_by_lead[lead]
        if isinstance(count, bool) or not isinstance(count, int):
            raise TypeError(f"lead-{lead} finite target count must be an integer")
        if count < 0 or (optimizer_step_count == 0 and count != 0):
            raise ValueError(f"lead-{lead} finite target count is invalid")
        if optimizer_step_count > 0 and count < optimizer_step_count:
            raise ValueError(f"lead-{lead} finite target count is below one per step")
        counts[lead] = count
        if normalized:
            means[lead] = math.fsum(normalized) / len(normalized)

    return {
        "training_mse_by_lead_physical_unit_mean_over_optimizer_steps": (
            means if optimizer_step_count > 0 else None
        ),
        "training_sampled_finite_target_event_count_by_lead": counts,
        "epoch_optimizer_step_count": optimizer_step_count,
        "gradient_clipped_optimizer_step_count": clipped,
        "gradient_clipped_optimizer_step_fraction": (
            clipped / optimizer_step_count if optimizer_step_count > 0 else None
        ),
    }


def _history_row(
    *,
    epoch: int,
    training_objective: float | None,
    validation: Any,
    parameter_sha256: str,
    optimizer_steps: int,
    forecast_events: int,
    gradient_names: Sequence[str],
    maximum_gradient_norm_before_clip: float | None,
    training_diagnostics: Mapping[str, Any],
    prediction_sha256: str,
) -> Mapping[str, Any]:
    row = {
        "epoch": int(epoch),
        "training_objective_physical_unit_multilead_mse": training_objective,
        "checkpoint_selection_objective_728_origins_without_warmup": float(
            validation.full_objective_without_warmup
        ),
        "gate_objective_712_origins_after_16_day_warmup": float(validation.objective),
        "mse_by_lead_after_warmup": dict(validation.mse_by_lead),
        "nse_by_lead_after_warmup": dict(validation.nse_by_lead),
        "target_count_by_lead_after_warmup": dict(validation.target_count_by_lead),
        "target_count_by_lead_without_warmup": dict(
            validation.full_target_count_by_lead_without_warmup
        ),
        "parameter_sha256": parameter_sha256,
        "optimizer_steps": int(optimizer_steps),
        "sampled_forecast_events": int(forecast_events),
        "finite_gradients": None if epoch == 0 else bool(gradient_names),
        "nonzero_gradient_parameter_names": list(gradient_names),
        "nonzero_gradient_parameter_tensor_count": len(gradient_names),
        "maximum_gradient_norm_before_clip": maximum_gradient_norm_before_clip,
        "fixed_window_prediction_sha256": prediction_sha256,
    }
    overlap = set(row).intersection(training_diagnostics)
    if overlap:
        raise ValueError(f"training diagnostics overwrite history fields: {sorted(overlap)}")
    row.update(copy.deepcopy(dict(training_diagnostics)))
    return row


def _epoch_completed_event(
    *,
    epoch: int,
    training_objective: float | None,
    checkpoint_selection_objective: float,
    gate_objective: float,
    checkpoint_sha256: str,
    parameter_sha256: str,
    optimizer_steps: int,
    sampled_forecast_events: int,
    training_diagnostics: Mapping[str, Any],
) -> Mapping[str, Any]:
    event = {
        "event_type": "epoch_completed",
        "epoch": int(epoch),
        "training_objective": training_objective,
        "checkpoint_selection_objective_728": float(
            checkpoint_selection_objective
        ),
        "gate_objective_712": float(gate_objective),
        "checkpoint_sha256": checkpoint_sha256,
        "parameter_sha256": parameter_sha256,
        "optimizer_steps": int(optimizer_steps),
        "sampled_forecast_events": int(sampled_forecast_events),
    }
    overlap = set(event).intersection(training_diagnostics)
    if overlap:
        raise ValueError(f"training diagnostics overwrite event fields: {sorted(overlap)}")
    event.update(copy.deepcopy(dict(training_diagnostics)))
    return event


def _checkpoint_payload(
    *,
    preflight: PreflightResult,
    epoch: int,
    net: Any,
    optimizer: Any,
    history: Sequence[Mapping[str, Any]],
    best_epoch: int,
    best_objective: float,
    best_model_state: Any,
    optimizer_steps: int,
    forecast_events: int,
    gradient_names: Iterable[str],
    generator: Any,
    ledger: Any,
    previous_checkpoint_sha256: str | None,
    torch_module: ModuleType,
    numpy_module: ModuleType,
) -> Mapping[str, Any]:
    return {
        "schema_version": "daily_camels_ukf_knet_parity_checkpoint_v1",
        "identity": dict(preflight.identity),
        "identity_sha256": preflight.identity_sha256,
        "completed_epoch": int(epoch),
        "model_state": _cpu_clone(net.state_dict(), torch_module),
        "optimizer_state": _cpu_clone(optimizer.state_dict(), torch_module),
        "history": copy.deepcopy(list(history)),
        "best_epoch": int(best_epoch),
        "best_checkpoint_selection_objective": float(best_objective),
        "best_model_state": _cpu_clone(best_model_state, torch_module),
        "optimizer_steps": int(optimizer_steps),
        "sampled_forecast_events": int(forecast_events),
        "nonzero_gradient_parameter_names": sorted(set(gradient_names)),
        "python_random_state": random.getstate(),
        "numpy_random_state": numpy_module.random.get_state(),
        "torch_cpu_random_state": torch_module.get_rng_state().cpu(),
        "torch_cuda_random_states": (
            [state.cpu() for state in torch_module.cuda.get_rng_state_all()]
            if torch_module.cuda.is_available()
            else []
        ),
        "sampler_generator_state": generator.get_state().cpu(),
        "access_ledger": dict(_ledger_dict(ledger)),
        "previous_checkpoint_sha256": previous_checkpoint_sha256,
    }


def execute_training(
    preflight: PreflightResult,
    runtime: Any,
    numpy_module: ModuleType,
    torch_module: ModuleType,
    runner: ModuleType,
    io_module: ModuleType,
    ledger: Any,
    events: list[dict[str, Any]],
    *,
    device: str,
) -> Mapping[str, Any]:
    if not runtime.initialization_evidence.scientific_claim_allowed:
        raise PermissionError("backward-time diagnostic initialization is replay-only")
    config = preflight.configuration
    model = config["model"]
    optimization = config["optimization"]
    gate_config = config["gate"]
    _validate_training_hyperparameters(optimization)
    if int(optimization["checkpoint_every_epochs"]) != 1:
        raise ValueError("this recovery route requires an immutable checkpoint every epoch")

    seed = int(optimization["seed"])
    torch_module.manual_seed(seed)
    if device == "cuda":
        torch_module.cuda.manual_seed_all(seed)
    random.seed(seed)
    numpy_module.random.seed(seed)
    generator = torch_module.Generator(device="cpu")
    generator.manual_seed(seed)

    net = runner.build_native_knet(
        runtime,
        zero_gain=False,
        seed=seed,
        hidden=int(model["hidden_dimension"]),
        in_mult=int(model["input_multiplier"]),
        out_mult=int(model["output_multiplier"]),
        feature_scale_floor=float(model["feature_scale_floor"]),
        normalized_feature_guard=float(model["normalized_feature_guard"]),
    )
    optimizer = torch_module.optim.Adam(
        net.parameters(),
        lr=float(optimization["learning_rate"]),
        weight_decay=float(optimization["weight_decay"]),
    )
    recovery = runner.select_window(runtime, "recovery")
    training_states = runner.training_open_loop_states(runtime)
    maximum_start = runtime.training_days - int(optimization["segment_days"])
    if maximum_start < 0:
        raise ValueError("training segment exceeds the training period")

    checkpoint_dir = preflight.run_directory / CHECKPOINT_DIRECTORY
    prediction_dir = preflight.run_directory / PREDICTION_DIRECTORY
    checkpoint_dir.mkdir(parents=False, exist_ok=False)
    prediction_dir.mkdir(parents=False, exist_ok=False)
    previous_checkpoint_hash: str | None = None
    optimizer_steps = 0
    forecast_events = 0
    all_gradient_names: set[str] = set()
    history: list[Mapping[str, Any]] = []

    epoch_zero = runner.evaluate_knet(net, runtime, recovery)
    if dict(epoch_zero.full_target_count_by_lead_without_warmup) != {
        lead: 728 for lead in preflight.contract.leads
    }:
        raise RuntimeError("epoch zero checkpoint objective must use 728 origins per lead")
    epoch_zero_hash = runner.parameter_sha256(net)
    prediction_hash = _write_npz(
        io_module,
        prediction_dir / "epoch_000.npz",
        _prediction_arrays(epoch_zero, numpy_module),
    )
    epoch_zero_training_diagnostics = _summarize_epoch_training_diagnostics(
        {lead: () for lead in preflight.contract.leads},
        {lead: 0 for lead in preflight.contract.leads},
        gradient_clipped_optimizer_step_count=0,
        optimizer_step_count=0,
    )
    history.append(
        _history_row(
            epoch=0,
            training_objective=None,
            validation=epoch_zero,
            parameter_sha256=epoch_zero_hash,
            optimizer_steps=0,
            forecast_events=0,
            gradient_names=(),
            maximum_gradient_norm_before_clip=None,
            training_diagnostics=epoch_zero_training_diagnostics,
            prediction_sha256=prediction_hash,
        )
    )
    best_epoch = 0
    best_objective = float(epoch_zero.full_objective_without_warmup)
    best_model_state = _cpu_clone(net.state_dict(), torch_module)
    payload = _checkpoint_payload(
        preflight=preflight,
        epoch=0,
        net=net,
        optimizer=optimizer,
        history=history,
        best_epoch=best_epoch,
        best_objective=best_objective,
        best_model_state=best_model_state,
        optimizer_steps=optimizer_steps,
        forecast_events=forecast_events,
        gradient_names=all_gradient_names,
        generator=generator,
        ledger=ledger,
        previous_checkpoint_sha256=None,
        torch_module=torch_module,
        numpy_module=numpy_module,
    )
    previous_checkpoint_hash = io_module.atomic_write_bytes(
        checkpoint_dir / "epoch_000.pt",
        _checkpoint_bytes(torch_module, payload),
        replace=False,
    )
    best_payload = _cpu_clone(payload, torch_module)
    _write_json(io_module, preflight.run_directory / HISTORY_FILE, history, replace=False)
    _append_event(
        io_module,
        preflight.run_directory / EVENT_FILE,
        events,
        _epoch_completed_event(
            epoch=0,
            training_objective=None,
            checkpoint_selection_objective=best_objective,
            gate_objective=float(epoch_zero.objective),
            checkpoint_sha256=previous_checkpoint_hash,
            parameter_sha256=epoch_zero_hash,
            optimizer_steps=0,
            sampled_forecast_events=0,
            training_diagnostics=epoch_zero_training_diagnostics,
        ),
    )

    last_payload = payload
    last_validation = epoch_zero
    for epoch in range(1, int(optimization["training_epochs"]) + 1):
        net.train()
        losses: list[float] = []
        lead_training_mse_values: dict[int, list[float]] = {
            lead: [] for lead in preflight.contract.leads
        }
        finite_target_count_by_lead: dict[int, int] = {
            lead: 0 for lead in preflight.contract.leads
        }
        gradient_clipped_optimizer_steps = 0
        epoch_gradient_names: set[str] = set()
        maximum_gradient_norm = 0.0
        for _ in range(int(optimization["steps_per_epoch"])):
            start = int(
                torch_module.randint(
                    0,
                    maximum_start + 1,
                    (1,),
                    generator=generator,
                    device="cpu",
                ).item()
            )
            optimizer.zero_grad(set_to_none=True)
            segment = runner.segment_multilead_mse(
                net,
                runtime,
                start=start,
                segment_days=int(optimization["segment_days"]),
                filter_warmup_days=int(optimization["segment_filter_warmup_days"]),
                open_loop_states=training_states,
            )
            if set(segment.mse_by_lead) != set(preflight.contract.leads) or set(
                segment.target_count_by_lead
            ) != set(preflight.contract.leads):
                raise RuntimeError("training segment lead inventory differs")
            for lead in preflight.contract.leads:
                lead_training_mse_values[lead].append(
                    float(segment.mse_by_lead[lead].detach().cpu())
                )
                finite_target_count_by_lead[lead] += int(
                    segment.target_count_by_lead[lead]
                )
            segment.objective.backward()
            step_gradient_names: set[str] = set()
            for name, parameter in net.named_parameters():
                gradient = parameter.grad
                if gradient is None:
                    continue
                if not bool(torch_module.isfinite(gradient).all()):
                    raise FloatingPointError(f"non-finite gradient in {name}")
                if bool(torch_module.count_nonzero(gradient)):
                    step_gradient_names.add(name)
            if not step_gradient_names:
                raise RuntimeError("an optimizer step has no nonzero parameter gradient")
            epoch_gradient_names.update(step_gradient_names)
            pre_clip_norm_value = torch_module.nn.utils.clip_grad_norm_(
                net.parameters(),
                float(optimization["gradient_maximum_norm"]),
                error_if_nonfinite=True,
            )
            if hasattr(pre_clip_norm_value, "detach"):
                pre_clip_norm_value = pre_clip_norm_value.detach()
            if hasattr(pre_clip_norm_value, "cpu"):
                pre_clip_norm_value = pre_clip_norm_value.cpu()
            if hasattr(pre_clip_norm_value, "item"):
                pre_clip_norm_value = pre_clip_norm_value.item()
            pre_clip_norm = float(pre_clip_norm_value)
            if not math.isfinite(pre_clip_norm):
                raise FloatingPointError("non-finite total gradient norm before clipping")
            maximum_gradient_norm = max(maximum_gradient_norm, pre_clip_norm)
            if pre_clip_norm > float(optimization["gradient_maximum_norm"]):
                gradient_clipped_optimizer_steps += 1
            optimizer.step()
            optimizer_steps += 1
            forecast_events += sum(int(v) for v in segment.target_count_by_lead.values())
            losses.append(float(segment.objective.detach().cpu()))
        all_gradient_names.update(epoch_gradient_names)
        epoch_training_diagnostics = _summarize_epoch_training_diagnostics(
            lead_training_mse_values,
            finite_target_count_by_lead,
            gradient_clipped_optimizer_step_count=gradient_clipped_optimizer_steps,
            optimizer_step_count=len(losses),
        )
        training_objective = math.fsum(losses) / len(losses)
        reconstructed_training_objective = math.fsum(
            epoch_training_diagnostics[
                "training_mse_by_lead_physical_unit_mean_over_optimizer_steps"
            ].values()
        ) / len(preflight.contract.leads)
        if not math.isclose(
            training_objective,
            reconstructed_training_objective,
            rel_tol=1.0e-6,
            abs_tol=1.0e-8,
        ):
            raise RuntimeError("epoch training objective does not reconstruct by equal leads")

        validation = runner.evaluate_knet(net, runtime, recovery)
        checkpoint_objective = float(validation.full_objective_without_warmup)
        if dict(validation.full_target_count_by_lead_without_warmup) != {
            lead: 728 for lead in preflight.contract.leads
        }:
            raise RuntimeError("checkpoint selection geometry changed from 728 origins")
        parameter_hash = runner.parameter_sha256(net)
        prediction_hash = _write_npz(
            io_module,
            prediction_dir / f"epoch_{epoch:03d}.npz",
            _prediction_arrays(validation, numpy_module),
        )
        history.append(
            _history_row(
                epoch=epoch,
                training_objective=training_objective,
                validation=validation,
                parameter_sha256=parameter_hash,
                optimizer_steps=optimizer_steps,
                forecast_events=forecast_events,
                gradient_names=sorted(epoch_gradient_names),
                maximum_gradient_norm_before_clip=maximum_gradient_norm,
                training_diagnostics=epoch_training_diagnostics,
                prediction_sha256=prediction_hash,
            )
        )
        if checkpoint_objective < best_objective:
            best_epoch = epoch
            best_objective = checkpoint_objective
            best_model_state = _cpu_clone(net.state_dict(), torch_module)
        payload = _checkpoint_payload(
            preflight=preflight,
            epoch=epoch,
            net=net,
            optimizer=optimizer,
            history=history,
            best_epoch=best_epoch,
            best_objective=best_objective,
            best_model_state=best_model_state,
            optimizer_steps=optimizer_steps,
            forecast_events=forecast_events,
            gradient_names=all_gradient_names,
            generator=generator,
            ledger=ledger,
            previous_checkpoint_sha256=previous_checkpoint_hash,
            torch_module=torch_module,
            numpy_module=numpy_module,
        )
        checkpoint_path = checkpoint_dir / f"epoch_{epoch:03d}.pt"
        previous_checkpoint_hash = io_module.atomic_write_bytes(
            checkpoint_path,
            _checkpoint_bytes(torch_module, payload),
            replace=False,
        )
        if best_epoch == epoch:
            best_payload = _cpu_clone(payload, torch_module)
        last_payload = payload
        last_validation = validation
        _write_json(
            io_module,
            preflight.run_directory / HISTORY_FILE,
            history,
            replace=True,
        )
        _append_event(
            io_module,
            preflight.run_directory / EVENT_FILE,
            events,
            _epoch_completed_event(
                epoch=epoch,
                training_objective=training_objective,
                checkpoint_selection_objective=checkpoint_objective,
                gate_objective=float(validation.objective),
                checkpoint_sha256=previous_checkpoint_hash,
                parameter_sha256=parameter_hash,
                optimizer_steps=optimizer_steps,
                sampled_forecast_events=forecast_events,
                training_diagnostics=epoch_training_diagnostics,
            ),
        )

    last_checkpoint_hash = io_module.atomic_write_bytes(
        checkpoint_dir / "last.pt",
        _checkpoint_bytes(torch_module, last_payload),
        replace=False,
    )
    best_checkpoint_hash = io_module.atomic_write_bytes(
        checkpoint_dir / "best.pt",
        _checkpoint_bytes(torch_module, best_payload),
        replace=False,
    )
    net.load_state_dict(best_model_state)
    best_validation = runner.evaluate_knet(net, runtime, recovery)
    if not math.isclose(
        float(best_validation.full_objective_without_warmup),
        best_objective,
        rel_tol=0.0,
        abs_tol=1e-15,
    ):
        raise RuntimeError("best checkpoint replay differs from checkpoint selection history")

    performance = sys.modules[CONTRACT_MODULE_ALIAS].performance_gate(
        epoch_zero_objective=float(epoch_zero.full_objective_without_warmup),
        best_objective=best_objective,
        best_epoch=best_epoch,
        nse_by_lead=best_validation.nse_by_lead,
        target_count_by_lead=best_validation.target_count_by_lead,
        contract=preflight.contract,
    )
    failed = list(performance.failed_gates)
    best_parameter_hash = runner.parameter_sha256(net)
    if bool(gate_config["require_parameter_hash_change"]) and best_parameter_hash == epoch_zero_hash:
        failed.append("parameter_hash_change")
    _assert_zero_reserved_access(ledger)
    if bool(gate_config["require_zero_reserved_data_access"]) is not True:
        raise ValueError("zero reserved-data access gate must remain enabled")
    gate_passed = not failed

    feature_evidence = {
        "schema_version": "daily_camels_ukf_knet_parity_feature_diagnostics_v1",
        "training_scale_fit": training_scale_diagnostics(
            runtime,
            runner,
            numpy_module,
            floor=float(model["feature_scale_floor"]),
            guard=float(model["normalized_feature_guard"]),
        ),
        "best_checkpoint_recovery_features": _dynamic_feature_diagnostics(
            net,
            runtime,
            recovery,
            runner,
            numpy_module,
            torch_module,
            guard=float(model["normalized_feature_guard"]),
        ),
    }
    _write_json(
        io_module,
        preflight.run_directory / FEATURE_FILE,
        feature_evidence,
        replace=False,
    )
    return {
        "status": "TRAINING_COMPLETE_GATE_PASS" if gate_passed else "TRAINING_COMPLETE_GATE_FAIL",
        "scientific_claim_allowed": True,
        "objective_definition": {
            "optimizer": "equal_weight_1_2_3_day_physical_unit_mse",
            "checkpoint_selection": "728_origins_without_filter_warmup",
            "nse_gate": "712_origins_after_16_day_filter_warmup",
        },
        "epoch_zero_checkpoint_objective": float(
            epoch_zero.full_objective_without_warmup
        ),
        "best_epoch": int(best_epoch),
        "best_checkpoint_objective": best_objective,
        "objective_improvement": float(performance.objective_improvement),
        "best_gate_objective_after_warmup": float(best_validation.objective),
        "best_nse_by_lead": dict(best_validation.nse_by_lead),
        "best_target_count_by_lead_after_warmup": dict(
            best_validation.target_count_by_lead
        ),
        "best_target_count_by_lead_without_warmup": dict(
            best_validation.full_target_count_by_lead_without_warmup
        ),
        "gate_passed": gate_passed,
        "failed_gates": failed,
        "epoch_zero_parameter_sha256": epoch_zero_hash,
        "best_parameter_sha256": best_parameter_hash,
        "last_parameter_sha256": str(history[-1]["parameter_sha256"]),
        "parameter_hash_changed": best_parameter_hash != epoch_zero_hash,
        "optimizer_steps": optimizer_steps,
        "sampled_forecast_events": forecast_events,
        "nonzero_gradient_parameter_names": sorted(all_gradient_names),
        "best_checkpoint_sha256": best_checkpoint_hash,
        "last_checkpoint_sha256": last_checkpoint_hash,
        "epoch_checkpoint_count": len(history),
        "fixed_window_prediction_artifact_count": len(history),
        "last_validation_checkpoint_objective": float(
            last_validation.full_objective_without_warmup
        ),
        "access_ledger": _ledger_dict(ledger),
        "feature_diagnostics_file": FEATURE_FILE,
    }


def _manifest(io_module: ModuleType, run_directory: Path) -> Mapping[str, str]:
    excluded = {MANIFEST_FILE, COMPLETION_FILE}
    result: dict[str, str] = {}
    for path in sorted(run_directory.rglob("*")):
        if not path.is_file() or OWNER_LOCK_DIRECTORY in path.parts:
            continue
        relative = path.relative_to(run_directory).as_posix()
        if relative in excluded:
            continue
        result[relative] = sha256_file(path)
    return result


def _seal_completion(
    io_module: ModuleType,
    preflight: PreflightResult,
    summary: Mapping[str, Any],
) -> None:
    summary_hash = _write_json(
        io_module,
        preflight.run_directory / SUMMARY_FILE,
        summary,
        replace=False,
    )
    manifest = {
        "schema_version": "daily_camels_ukf_knet_parity_manifest_v1",
        "experiment_id": preflight.experiment_id,
        "identity_sha256": preflight.identity_sha256,
        "files": _manifest(io_module, preflight.run_directory),
    }
    manifest_hash = _write_json(
        io_module,
        preflight.run_directory / MANIFEST_FILE,
        manifest,
        replace=False,
    )
    completion = {
        "schema_version": "daily_camels_ukf_knet_parity_completion_v1",
        "experiment_id": preflight.experiment_id,
        "identity_sha256": preflight.identity_sha256,
        "phase": preflight.phase,
        "status": summary["status"],
        "summary_sha256": summary_hash,
        "manifest_sha256": manifest_hash,
        "completed_at_utc": _utc_now(),
    }
    _write_json(
        io_module,
        preflight.run_directory / COMPLETION_FILE,
        completion,
        replace=False,
    )


def _execute_numerical(
    preflight: PreflightResult,
    report: Mapping[str, Any],
    *,
    device: str,
) -> int:
    io_module = _load_io(preflight)
    io_module.create_new_run(preflight.run_directory)
    owner = io_module.OwnerLock.acquire(
        preflight.run_directory / OWNER_LOCK_DIRECTORY,
        {
            "experiment_id": preflight.experiment_id,
            "identity_sha256": preflight.identity_sha256,
            "phase": preflight.phase,
            "device": device,
        },
    )
    events: list[dict[str, Any]] = []
    try:
        owner_record = _read_json(owner.path / "owner.json")
        _write_json(
            io_module,
            preflight.run_directory / "owner_evidence.json",
            owner_record,
            replace=False,
        )
        _write_json(
            io_module,
            preflight.run_directory / IDENTITY_FILE,
            preflight.identity,
            replace=False,
        )
        _write_json(
            io_module,
            preflight.run_directory / PREFLIGHT_FILE,
            report,
            replace=False,
        )
        _append_event(
            io_module,
            preflight.run_directory / EVENT_FILE,
            events,
            {
                "event_type": "preflight_completed",
                "identity_sha256": preflight.identity_sha256,
                "array_members_materialized": 0,
            },
        )

        numpy_module, torch_module, runner = _load_numerical_runtime(preflight)
        if device == "cuda":
            if not torch_module.cuda.is_available():
                raise RuntimeError("CUDA was requested but PyTorch CUDA is unavailable")
            selected_device = "cuda"
            torch_module.cuda.reset_peak_memory_stats()
        else:
            selected_device = "cpu"
        contract_module = sys.modules[CONTRACT_MODULE_ALIAS]
        ledger = contract_module.AccessLedger()
        runtime, replay_results, replay_evidence = execute_replay(
            preflight,
            numpy_module,
            torch_module,
            runner,
            ledger,
            device=selected_device,
        )
        replay_hash = _write_json(
            io_module,
            preflight.run_directory / REPLAY_FILE,
            replay_evidence,
            replace=False,
        )
        replay_prediction_hash = _write_npz(
            io_module,
            numpy_module,
            preflight.run_directory / REPLAY_PREDICTIONS_FILE,
            _replay_predictions(numpy_module, replay_results),
        )
        _append_event(
            io_module,
            preflight.run_directory / EVENT_FILE,
            events,
            {
                "event_type": "ukf_and_zero_gain_replay_completed",
                "replay_evidence_sha256": replay_hash,
                "replay_predictions_sha256": replay_prediction_hash,
                "recovery_ukf_checkpoint_objective_728": replay_evidence["windows"][
                    "recovery"
                ]["ukf"]["checkpoint_objective_without_warmup"],
                "reserved_evaluation_operations": 0,
            },
        )

        training: Mapping[str, Any] | None = None
        if preflight.phase == "train":
            training = execute_training(
                preflight,
                runtime,
                numpy_module,
                torch_module,
                runner,
                io_module,
                ledger,
                events,
                device=selected_device,
            )
        _assert_zero_reserved_access(ledger)
        resources = _resource_peaks(torch_module, device=selected_device)
        summary = {
            "schema_version": "daily_camels_ukf_knet_parity_result_v1",
            "status": (
                "REPLAY_COMPLETE_DIAGNOSTIC_ONLY"
                if preflight.phase == "replay"
                else training["status"]
            ),
            "experiment_id": preflight.experiment_id,
            "identity_sha256": preflight.identity_sha256,
            "phase": preflight.phase,
            "device": selected_device,
            "initialization_mode": preflight.initialization_mode,
            "scientific_claim_allowed": preflight.scientific_claim_allowed,
            "diagnostic_limitation": preflight.configuration["initialization"][
                "diagnostic_limitation"
            ],
            "ukf_recovery_checkpoint_objective_728": replay_evidence["windows"][
                "recovery"
            ]["ukf"]["checkpoint_objective_without_warmup"],
            "ukf_recovery_nse_by_lead_712": replay_evidence["windows"]["recovery"][
                "ukf"
            ]["nse_by_lead_after_warmup"],
            "zero_gain_maximum_open_loop_difference": replay_evidence["windows"][
                "recovery"
            ]["zero_gain_knet"]["maximum_open_loop_difference"],
            "training": training,
            "access_ledger": _ledger_dict(ledger),
            "resource_peaks": resources,
            "artifacts": {
                "replay_evidence": REPLAY_FILE,
                "replay_predictions": REPLAY_PREDICTIONS_FILE,
                "epoch_history": HISTORY_FILE if training is not None else None,
                "feature_diagnostics": FEATURE_FILE if training is not None else None,
            },
        }
        _append_event(
            io_module,
            preflight.run_directory / EVENT_FILE,
            events,
            {
                "event_type": "run_completed",
                "status": summary["status"],
                "resource_peaks": resources,
            },
        )
        _seal_completion(io_module, preflight, summary)
        print(canonical_json_bytes(summary).decode("utf-8"), end="")
        return 0 if training is None or bool(training["gate_passed"]) else 2
    except BaseException as exc:
        failure = {
            "schema_version": "daily_camels_ukf_knet_parity_failure_v1",
            "status": "FAILED_EVIDENCE_PRESERVED",
            "experiment_id": preflight.experiment_id,
            "identity_sha256": preflight.identity_sha256,
            "phase": preflight.phase,
            "error_type": type(exc).__name__,
            "error_message": str(exc),
            "failed_at_utc": _utc_now(),
        }
        try:
            _write_json(
                io_module,
                preflight.run_directory / FAILURE_FILE,
                failure,
                replace=False,
            )
        except Exception:
            pass
        raise
    finally:
        owner.release()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Run daily CAMELS UKF/KalmanNet parity.  --run-parent is the parent; "
            "the entry appends the exact experiment_id once."
        )
    )
    parser.add_argument(
        "--phase",
        "--stage",
        dest="phase",
        required=True,
        choices=PHASES,
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=Path(__file__).resolve().parents[1] / DEFAULT_CONFIG_RELATIVE,
    )
    parser.add_argument(
        "--run-parent",
        "--run-root",
        dest="run_parent",
        type=Path,
        required=True,
    )
    parser.add_argument("--device", choices=("cuda", "cpu"), default="cuda")
    return parser


def execute(arguments: argparse.Namespace) -> int:
    preflight = standard_preflight(
        arguments.config,
        arguments.run_parent,
        phase=arguments.phase,
    )
    report = preflight_report(preflight, device=arguments.device)
    if arguments.phase == "probe":
        print(canonical_json_bytes(report).decode("utf-8"), end="")
        return 0
    return _execute_numerical(preflight, report, device=arguments.device)


def main(argv: Sequence[str] | None = None) -> int:
    return execute(build_parser().parse_args(argv))


if __name__ == "__main__":
    raise SystemExit(main())
