from __future__ import annotations

import json
import os
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import numpy as np
import pytest

import global_hydrology.experiments.daily_camels_ukf_knet_parity_runner as parity_runner
from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import (
    CAUSAL_SHARED_SPINUP_MODE,
    EXACT_TUKF06_DIAGNOSTIC_MODE,
    AccessLedger,
    ParityContract,
)
from global_hydrology.experiments.daily_camels_ukf_knet_parity_runner import (
    SegmentLoss,
    assert_identical_forecast_geometry,
    build_native_knet,
    forecast_pairs,
    full_state_correction_mask,
    load_archive_context,
    parameter_sha256,
    physical_multilead_mse,
    previous_observation_before_window,
    replay_tukf06_ukf,
    replay_zero_gain_open_loop,
    run_knet_filter,
    score_forecast_pairs,
    segment_multilead_mse,
    select_window,
    train_short_knet,
)


ROOT = Path(__file__).resolve().parents[1]
CONFIG_PATH = ROOT / "configs" / "daily_camels_ukf_knet_parity_v1.json"
REAL_INTEGRATION_ENV = "RUN_DAILY_CAMELS_UKF_KNET_PARITY_INTEGRATION"
requires_torch_development_data = pytest.mark.skipif(
    os.environ.get(REAL_INTEGRATION_ENV) != "1",
    reason=(
        "requires PyTorch and the frozen development archive in an isolated "
        f"compute environment with {REAL_INTEGRATION_ENV}=1"
    ),
)


def _config_payload() -> dict[str, Any]:
    return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))


def _aligned_predictions(
    observations: np.ndarray,
    *,
    issue_start: int,
    issue_end: int,
    errors_by_lead: dict[int, float],
) -> dict[int, np.ndarray]:
    result: dict[int, np.ndarray] = {}
    issues = np.arange(issue_start, issue_end, dtype=np.int64)
    for lead, error in errors_by_lead.items():
        target_indices = issues + int(lead)
        values = np.full(observations.shape, np.nan, dtype=np.float64)
        values[target_indices] = observations[target_indices] + float(error)
        result[int(lead)] = values
    return result


def _as_numpy(value: Any) -> np.ndarray:
    if hasattr(value, "detach"):
        value = value.detach()
    if hasattr(value, "cpu"):
        value = value.cpu()
    if hasattr(value, "numpy"):
        value = value.numpy()
    return np.asarray(value)


def test_forecast_pairs_use_the_same_issue_target_indices_and_finite_masks() -> None:
    observations = np.arange(10, dtype=np.float64) + 1.0
    predictions = _aligned_predictions(
        observations,
        issue_start=2,
        issue_end=6,
        errors_by_lead={1: 0.0, 2: 0.0, 3: 0.0},
    )
    observations[5] = np.nan

    reference = forecast_pairs(
        observations,
        predictions,
        issue_start=2,
        issue_end=6,
        leads=(1, 2, 3),
    )
    candidate = forecast_pairs(
        observations.copy(),
        {lead: values.copy() for lead, values in predictions.items()},
        issue_start=2,
        issue_end=6,
        leads=(1, 2, 3),
    )

    for lead in (1, 2, 3):
        expected_issues = np.arange(2, 6, dtype=np.int64)
        expected_targets = expected_issues + lead
        expected_mask = np.isfinite(observations[expected_targets])
        np.testing.assert_array_equal(reference.issue_indices[lead], expected_issues)
        np.testing.assert_array_equal(reference.target_indices[lead], expected_targets)
        np.testing.assert_array_equal(reference.finite_masks[lead], expected_mask)
    assert_identical_forecast_geometry(reference, candidate)

    candidate.finite_masks[2][0] = ~candidate.finite_masks[2][0]
    with pytest.raises(ValueError, match="finite_masks"):
        assert_identical_forecast_geometry(reference, candidate)


def test_forecast_pairs_reject_nonfinite_predictions_instead_of_masking_them() -> None:
    observations = np.arange(10, dtype=np.float64) + 1.0
    predictions = _aligned_predictions(
        observations,
        issue_start=2,
        issue_end=6,
        errors_by_lead={1: 0.0, 2: 0.0, 3: 0.0},
    )
    predictions[2][5] = np.nan

    with pytest.raises(FloatingPointError, match="non-finite lead-2 prediction"):
        forecast_pairs(
            observations,
            predictions,
            issue_start=2,
            issue_end=6,
            leads=(1, 2, 3),
        )


def test_physical_multilead_loss_is_unscaled_discharge_mse_with_equal_lead_weights() -> None:
    observations = np.linspace(10.0, 80.0, 8, dtype=np.float64)
    predictions = _aligned_predictions(
        observations,
        issue_start=1,
        issue_end=4,
        errors_by_lead={1: 1.0, 2: 2.0, 3: 3.0},
    )
    pairs = forecast_pairs(
        observations,
        predictions,
        issue_start=1,
        issue_end=4,
        leads=(1, 2, 3),
    )

    expected_by_lead = {1: 1.0, 2: 4.0, 3: 9.0}
    expected_objective = float(np.mean(list(expected_by_lead.values())))
    assert physical_multilead_mse(pairs) == pytest.approx(expected_objective)

    score = score_forecast_pairs(pairs)
    assert score.objective == pytest.approx(expected_objective)
    assert score.mse_by_lead == pytest.approx(expected_by_lead)
    assert score.target_count_by_lead == {1: 3, 2: 3, 3: 3}

    # Multiplying every physical discharge error by ten must multiply MSE by 100.
    scaled_error_predictions = _aligned_predictions(
        observations,
        issue_start=1,
        issue_end=4,
        errors_by_lead={1: 10.0, 2: 20.0, 3: 30.0},
    )
    scaled_pairs = forecast_pairs(
        observations,
        scaled_error_predictions,
        issue_start=1,
        issue_end=4,
        leads=(1, 2, 3),
    )
    assert physical_multilead_mse(scaled_pairs) == pytest.approx(
        100.0 * expected_objective
    )


def test_full_state_mask_grants_authority_to_all_18_tukf06_coordinates() -> None:
    torch = pytest.importorskip("torch")

    mask = full_state_correction_mask(18, device="cpu", dtype=torch.float64)

    assert tuple(mask.shape) == (1, 18)
    assert bool(torch.equal(mask, torch.ones((1, 18), dtype=torch.float64)))
    with pytest.raises(ValueError, match="18"):
        full_state_correction_mask(5, device="cpu", dtype=torch.float64)


def test_window_uses_only_the_immediately_preceding_causal_observation() -> None:
    torch = pytest.importorskip("torch")
    observations = torch.tensor(
        [[1.0], [2.0], [3.0], [400.0], [500.0]], dtype=torch.float64
    )
    runtime = SimpleNamespace(observations=observations)

    previous = previous_observation_before_window(
        runtime, SimpleNamespace(global_start=3)
    )

    assert torch.equal(previous, observations[2:3])
    assert previous_observation_before_window(
        runtime, SimpleNamespace(global_start=0)
    ) is None
    observations[2, 0] = torch.nan
    assert previous_observation_before_window(
        runtime, SimpleNamespace(global_start=3)
    ) is None


def test_filter_trace_separates_requested_from_projected_corrections() -> None:
    torch = pytest.importorskip("torch")

    class ProjectingNet:
        def initialize_filter(
            self,
            initial_state: Any,
            sequence_length: int,
            previous_observation: Any = None,
        ) -> None:
            self.state = initial_state.clone()

        def analysis_step(self, observation: Any, controls: Any) -> Any:
            self.m1x_prior = self.state + 1.0
            self.last_correction = torch.full_like(self.state, 2.0)
            self.state = self.m1x_prior + 0.5
            return self.state

        def predict_step(self, controls: Any) -> Any:
            raise AssertionError("all synthetic observations are finite")

    window = SimpleNamespace(
        observations=torch.ones(4, 1, dtype=torch.float64),
        forcing=torch.zeros(4, 1, 3, dtype=torch.float64),
        initial_state=torch.zeros(1, 18, dtype=torch.float64),
    )

    trace = run_knet_filter(ProjectingNet(), window)

    assert torch.equal(
        trace.requested_corrections,
        torch.full((4, 1, 18), 2.0, dtype=torch.float64),
    )
    assert torch.equal(
        trace.corrections,
        torch.full((4, 1, 18), 0.5, dtype=torch.float64),
    )


def test_training_segment_loss_is_physical_unit_mse_and_equal_weights_leads(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    torch = pytest.importorskip("torch")
    observations = torch.tensor(
        [10.0, 21.0, 35.0, 44.0, 60.0, 79.0, 91.0, 120.0],
        dtype=torch.float64,
    ).reshape(-1, 1)
    posterior = torch.zeros(8, 1, 18, dtype=torch.float64)
    errors = {1: 1.0, 2: 2.0, 3: 3.0}

    def fake_filter(*_args: Any, **_kwargs: Any) -> Any:
        return SimpleNamespace(posterior_states=posterior)

    def fake_multilead(
        _model: Any, _posterior: Any, _forcing: Any
    ) -> dict[int, tuple[Any, Any]]:
        result: dict[int, tuple[Any, Any]] = {}
        for lead, error in errors.items():
            indices = torch.arange(lead, lead + 5, dtype=torch.long)
            forecast = observations[indices, 0] + error
            result[lead] = (forecast, indices)
        return result

    monkeypatch.setattr(parity_runner, "run_knet_filter", fake_filter)
    runtime = SimpleNamespace(
        training_days=8,
        context=SimpleNamespace(
            initial_state=torch.zeros(1, 18, dtype=torch.float64),
            dimension=18,
            plain_model=object(),
        ),
        forcing=torch.zeros(8, 1, 3, dtype=torch.float64),
        observations=observations,
        dates=np.arange(8).astype("datetime64[D]"),
        tukf06_module=SimpleNamespace(multilead_torch=fake_multilead),
    )
    open_loop_states = torch.zeros(8, 1, 18, dtype=torch.float64)

    result = segment_multilead_mse(
        object(),
        runtime,
        start=0,
        segment_days=8,
        filter_warmup_days=1,
        open_loop_states=open_loop_states,
    )

    assert {lead: float(value) for lead, value in result.mse_by_lead.items()} == (
        pytest.approx({1: 1.0, 2: 4.0, 3: 9.0})
    )
    assert float(result.objective) == pytest.approx((1.0 + 4.0 + 9.0) / 3.0)
    assert result.target_count_by_lead == {1: 4, 2: 4, 3: 4}
    observation_variance = float(torch.var(observations, unbiased=False))
    assert float(result.objective) != pytest.approx(
        ((1.0 + 4.0 + 9.0) / 3.0) / observation_variance
    )


def test_training_segment_loss_rejects_nonfinite_forecasts_instead_of_masking_them(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    torch = pytest.importorskip("torch")
    observations = torch.arange(8, dtype=torch.float64).reshape(-1, 1)
    posterior = torch.zeros(8, 1, 18, dtype=torch.float64)

    def fake_filter(*_args: Any, **_kwargs: Any) -> Any:
        return SimpleNamespace(posterior_states=posterior)

    def fake_multilead(
        _model: Any, _posterior: Any, _forcing: Any
    ) -> dict[int, tuple[Any, Any]]:
        result: dict[int, tuple[Any, Any]] = {}
        for lead in (1, 2, 3):
            indices = torch.arange(lead, lead + 5, dtype=torch.long)
            forecast = observations[indices, 0].clone()
            if lead == 2:
                forecast[2] = torch.nan
            result[lead] = (forecast, indices)
        return result

    monkeypatch.setattr(parity_runner, "run_knet_filter", fake_filter)
    runtime = SimpleNamespace(
        training_days=8,
        context=SimpleNamespace(
            initial_state=torch.zeros(1, 18, dtype=torch.float64),
            dimension=18,
            plain_model=object(),
        ),
        forcing=torch.zeros(8, 1, 3, dtype=torch.float64),
        observations=observations,
        dates=np.arange(8).astype("datetime64[D]"),
        tukf06_module=SimpleNamespace(multilead_torch=fake_multilead),
    )

    with pytest.raises(FloatingPointError, match="non-finite lead-2 forecast"):
        segment_multilead_mse(
            object(),
            runtime,
            start=0,
            segment_days=8,
            filter_warmup_days=1,
            open_loop_states=torch.zeros(8, 1, 18, dtype=torch.float64),
        )


def test_training_rejects_backward_time_diagnostic_initialization() -> None:
    runtime = SimpleNamespace(
        initialization_evidence=SimpleNamespace(
            mode=EXACT_TUKF06_DIAGNOSTIC_MODE,
            scientific_claim_allowed=False,
        ),
        contract=SimpleNamespace(
            scientific_initialization_mode=CAUSAL_SHARED_SPINUP_MODE
        ),
    )

    with pytest.raises(PermissionError, match="replay-only"):
        train_short_knet(runtime)


def test_checkpoint_selection_uses_728_target_objective_not_712_target_gate(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    torch = pytest.importorskip("torch")

    class TinyNet(torch.nn.Module):
        def __init__(self) -> None:
            super().__init__()
            self.weight = torch.nn.Parameter(torch.tensor(1.0, dtype=torch.float64))

    net = TinyNet()
    runtime = SimpleNamespace(
        initialization_evidence=SimpleNamespace(
            mode=CAUSAL_SHARED_SPINUP_MODE,
            scientific_claim_allowed=True,
        ),
        contract=SimpleNamespace(
            scientific_initialization_mode=CAUSAL_SHARED_SPINUP_MODE
        ),
        training_days=10,
    )
    window = SimpleNamespace(observations=torch.zeros(731, 1, dtype=torch.float64))
    evaluations = iter(
        [
            SimpleNamespace(
                objective=1.0,
                full_objective_without_warmup=10.0,
                full_target_count_by_lead_without_warmup={1: 728, 2: 728, 3: 728},
                nse_by_lead={1: 0.1, 2: 0.1, 3: 0.1},
                target_count_by_lead={1: 712, 2: 712, 3: 712},
            ),
            SimpleNamespace(
                objective=0.1,
                full_objective_without_warmup=12.0,
                full_target_count_by_lead_without_warmup={1: 728, 2: 728, 3: 728},
                nse_by_lead={1: 0.9, 2: 0.9, 3: 0.9},
                target_count_by_lead={1: 712, 2: 712, 3: 712},
            ),
            SimpleNamespace(
                objective=2.0,
                full_objective_without_warmup=9.0,
                full_target_count_by_lead_without_warmup={1: 728, 2: 728, 3: 728},
                nse_by_lead={1: -0.1, 2: -0.1, 3: -0.1},
                target_count_by_lead={1: 712, 2: 712, 3: 712},
            ),
        ]
    )

    monkeypatch.setattr(parity_runner, "build_native_knet", lambda *_a, **_k: net)
    monkeypatch.setattr(parity_runner, "select_window", lambda *_a, **_k: window)
    monkeypatch.setattr(
        parity_runner,
        "training_open_loop_states",
        lambda *_a, **_k: torch.zeros(10, 1, 18, dtype=torch.float64),
    )
    monkeypatch.setattr(
        parity_runner,
        "evaluate_knet",
        lambda *_a, **_k: next(evaluations),
    )

    def fake_segment(current_net: Any, *_args: Any, **_kwargs: Any) -> SegmentLoss:
        objective = current_net.weight.square()
        return SegmentLoss(
            objective=objective,
            mse_by_lead={lead: objective for lead in (1, 2, 3)},
            target_count_by_lead={1: 1, 2: 1, 3: 1},
        )

    monkeypatch.setattr(parity_runner, "segment_multilead_mse", fake_segment)

    result = train_short_knet(
        runtime,
        epochs=2,
        steps_per_epoch=1,
        segment_days=4,
        segment_filter_warmup_days=0,
        learning_rate=0.01,
    )

    assert [row.checkpoint_objective_without_warmup for row in result.history] == [
        10.0,
        12.0,
        9.0,
    ]
    assert [row.gate_objective_after_warmup for row in result.history] == [
        1.0,
        0.1,
        2.0,
    ]
    assert result.epoch_zero_checkpoint_objective == 10.0
    assert result.best_epoch == 2
    assert result.best_checkpoint_objective == 9.0


@pytest.fixture
def real_runtime() -> Any:
    if os.environ.get(REAL_INTEGRATION_ENV) != "1":
        pytest.skip(
            f"requires PyTorch and the frozen development archive; set {REAL_INTEGRATION_ENV}=1 "
            "only in an isolated compute environment"
        )
    payload = _config_payload()
    contract = ParityContract.from_dict(payload)
    ledger = AccessLedger()
    runtime = load_archive_context(
        ROOT / payload["data"]["archive_path"],
        contract,
        ledger,
        initialization_mode=EXACT_TUKF06_DIAGNOSTIC_MODE,
        device="cpu",
    )
    return runtime


@pytest.fixture
def causal_real_runtime() -> Any:
    if os.environ.get(REAL_INTEGRATION_ENV) != "1":
        pytest.skip(
            f"requires PyTorch and the frozen development archive; set {REAL_INTEGRATION_ENV}=1 "
            "only in an isolated compute environment"
        )
    payload = _config_payload()
    contract = ParityContract.from_dict(payload)
    ledger = AccessLedger()
    return load_archive_context(
        ROOT / payload["data"]["archive_path"],
        contract,
        ledger,
        initialization_mode=CAUSAL_SHARED_SPINUP_MODE,
        device="cpu",
    )


@requires_torch_development_data
def test_real_09035800_archive_restores_exact_tukf06_state_and_covariance(
    real_runtime: Any,
) -> None:
    payload = _config_payload()
    archive_path = ROOT / payload["data"]["archive_path"]
    with np.load(archive_path, allow_pickle=False) as archive:
        archived_dates = np.asarray(archive["dates_ns"], dtype=np.int64).astype(
            "datetime64[ns]"
        )
        archived_forcing = np.asarray(archive["forcing"], dtype=np.float64)
        archived_observations = np.asarray(
            archive["observations"], dtype=np.float64
        )
        archived_parameters = np.asarray(archive["parameters"], dtype=np.float64)
        archived_initial_state = np.asarray(archive["initial_state"], dtype=np.float64)
        archived_initial_covariance = np.asarray(
            archive["initial_covariance"], dtype=np.float64
        )
        archived_storage = np.asarray(
            archive["initial_storage_state"], dtype=np.float64
        )

    assert real_runtime.context.basin_id == "09035800"
    assert real_runtime.context.dimension == 18
    np.testing.assert_array_equal(real_runtime.dates, archived_dates)
    np.testing.assert_array_equal(
        _as_numpy(real_runtime.forcing).reshape(-1, 3), archived_forcing
    )
    np.testing.assert_array_equal(
        _as_numpy(real_runtime.observations).reshape(-1), archived_observations
    )
    np.testing.assert_array_equal(
        _as_numpy(real_runtime.context.parameters), archived_parameters
    )
    np.testing.assert_array_equal(
        _as_numpy(real_runtime.context.initial_state), archived_initial_state
    )
    np.testing.assert_array_equal(
        _as_numpy(real_runtime.context.initial_covariance), archived_initial_covariance
    )
    np.testing.assert_array_equal(
        _as_numpy(real_runtime.context.initial_storage_state), archived_storage
    )
    assert real_runtime.dates[0] == np.datetime64("1999-10-01", "ns")
    assert real_runtime.dates[-1] == np.datetime64("2008-09-30", "ns")
    assert real_runtime.ledger.date_requests == 1
    assert set(real_runtime.ledger.archive_member_reads) == set(
        real_runtime.contract.archive_members
    )
    assert set(real_runtime.ledger.archive_member_reads.values()) == {1}
    assert real_runtime.ledger.evaluation_array_reads == 0
    assert real_runtime.ledger.evaluation_prediction_count == 0
    assert real_runtime.ledger.evaluation_metric_count == 0
    assert real_runtime.ledger.evaluation_output_count == 0


@pytest.mark.parametrize(
    ("purpose", "days", "global_end", "issue_end", "targets", "last_date"),
    [
        ("diagnostic", 128, 2685, 125, 109, "2007-02-05"),
        ("recovery", 731, 3288, 728, 712, "2008-09-30"),
    ],
)
@requires_torch_development_data
def test_real_windows_keep_128_days_diagnostic_and_731_days_recovery_only(
    real_runtime: Any,
    purpose: str,
    days: int,
    global_end: int,
    issue_end: int,
    targets: int,
    last_date: str,
) -> None:
    window = select_window(real_runtime, purpose)

    assert window.global_start == 2557
    assert window.global_end_exclusive == global_end
    assert len(window.dates) == days
    assert window.dates[0] == np.datetime64("2006-10-01", "ns")
    assert window.dates[-1] == np.datetime64(last_date, "ns")
    assert window.issue_start_local == 16
    assert window.issue_end_local == issue_end
    observations = _as_numpy(window.observations).reshape(-1)
    perfect = _aligned_predictions(
        observations,
        issue_start=window.issue_start_local,
        issue_end=window.issue_end_local,
        errors_by_lead={1: 0.0, 2: 0.0, 3: 0.0},
    )
    pairs = forecast_pairs(
        observations,
        perfect,
        issue_start=window.issue_start_local,
        issue_end=window.issue_end_local,
        leads=(1, 2, 3),
    )
    assert {lead: int(mask.sum()) for lead, mask in pairs.finite_masks.items()} == {
        1: targets,
        2: targets,
        3: targets,
    }


@requires_torch_development_data
def test_real_runner_uses_tukf06_projection_without_a_knet_only_upper_cap(
    real_runtime: Any,
) -> None:
    torch = pytest.importorskip("torch")
    net = build_native_knet(
        real_runtime,
        zero_gain=True,
        seed=20260824,
        hidden=24,
    )
    mask = _as_numpy(net.correction_mask)
    lower = _as_numpy(net.state_lower_bound)
    upper = _as_numpy(net.state_upper_bound)

    np.testing.assert_array_equal(mask, np.ones((1, 18), dtype=mask.dtype))
    np.testing.assert_array_equal(lower, np.zeros((1, 18), dtype=lower.dtype))
    field_capacity = float(
        real_runtime.context.parameters[
            0, parity_runner.PARAM_NAMES.index("parFC")
        ]
    )
    assert upper[0, 2] == pytest.approx(field_capacity)
    assert np.isposinf(np.delete(upper[0], 2)).all()

    raw = torch.linspace(-3.0, 14.0, 18, dtype=real_runtime.context.dtype).reshape(1, 18)
    raw[0, 2] = field_capacity + 10.0
    projected = _as_numpy(real_runtime.context.project_mean(raw))
    expected = np.maximum(_as_numpy(raw), 0.0)
    expected[0, 2] = min(expected[0, 2], field_capacity)
    np.testing.assert_array_equal(projected, expected)


@requires_torch_development_data
def test_real_tukf06_replay_reproduces_physical_unit_731_day_objective(
    real_runtime: Any,
) -> None:
    payload = _config_payload()
    selection_path = ROOT / payload["data"]["tukf06_selection_path"]
    window = select_window(real_runtime, "recovery")

    score = replay_tukf06_ukf(
        real_runtime,
        window,
        selection_path=selection_path,
        method="backpropagation",
    )

    assert score.full_objective_without_warmup == pytest.approx(
        payload["reference"]["tukf06_complete_validation_objective_no_warmup"],
        abs=1e-12,
        rel=0.0,
    )
    assert score.full_target_count_by_lead_without_warmup == {
        1: 728,
        2: 728,
        3: 728,
    }
    assert score.target_count_by_lead == {1: 712, 2: 712, 3: 712}
    assert set(score.nse_by_lead) == {1, 2, 3}
    assert all(value > 0.6 for value in score.nse_by_lead.values())


@requires_torch_development_data
def test_real_zero_gain_knet_is_exactly_the_shared_open_loop_on_recovery_window(
    real_runtime: Any,
) -> None:
    window = select_window(real_runtime, "recovery")

    score = replay_zero_gain_open_loop(
        real_runtime,
        window,
        seed=20260824,
        hidden=24,
    )

    assert score.maximum_open_loop_difference == pytest.approx(0.0, abs=0.0)
    assert score.posterior_states is not None
    assert score.open_loop is not None
    for lead in (1, 2, 3):
        target_indices = score.target_indices[lead]
        np.testing.assert_array_equal(
            score.predictions[lead], score.open_loop[target_indices]
        )

    zero_pairs = forecast_pairs(
        window.observations,
        {
            lead: np.asarray(score.open_loop, dtype=np.float64)
            for lead in (1, 2, 3)
        },
        issue_start=window.issue_start_local,
        issue_end=window.issue_end_local,
        leads=(1, 2, 3),
    )
    candidate_pairs = parity_runner.ForecastPairs(
        predictions=score.predictions,
        targets=score.targets,
        issue_indices=score.issue_indices,
        target_indices=score.target_indices,
        finite_masks=score.finite_masks,
    )
    assert_identical_forecast_geometry(zero_pairs, candidate_pairs)
    assert score.target_count_by_lead == {1: 712, 2: 712, 3: 712}

    torch = pytest.importorskip("torch")
    posterior = torch.as_tensor(score.posterior_states, dtype=window.context.dtype)
    raw_tukf06 = real_runtime.tukf06_module.multilead_torch(
        window.context.plain_model,
        posterior[:, 0, :],
        window.forcing,
    )
    for lead, (_forecast, tukf06_target_indices) in raw_tukf06.items():
        tukf06_indices = _as_numpy(tukf06_target_indices)
        expected = tukf06_indices[
            (tukf06_indices >= window.issue_start_local + lead)
            & (tukf06_indices < window.issue_end_local + lead)
        ]
        np.testing.assert_array_equal(score.target_indices[lead], expected)
    assert real_runtime.ledger.evaluation_array_reads == 0
    assert real_runtime.ledger.evaluation_prediction_count == 0
    assert real_runtime.ledger.evaluation_metric_count == 0
    assert real_runtime.ledger.evaluation_output_count == 0


@requires_torch_development_data
def test_real_causal_mode_avoids_archived_initialization_and_keeps_zero_gain_open_loop(
    causal_real_runtime: Any,
) -> None:
    evidence = causal_real_runtime.initialization_evidence
    assert evidence.mode == CAUSAL_SHARED_SPINUP_MODE
    assert evidence.scientific_claim_allowed is True
    assert evidence.backward_time_leakage is False
    assert {
        "initial_storage_state",
        "initial_state",
        "initial_covariance",
    }.isdisjoint(evidence.used_archive_members)

    window = select_window(causal_real_runtime, "recovery")
    score = replay_zero_gain_open_loop(
        causal_real_runtime,
        window,
        seed=20260824,
        hidden=24,
    )

    assert score.maximum_open_loop_difference == pytest.approx(0.0, abs=0.0)
    assert score.full_target_count_by_lead_without_warmup == {
        1: 728,
        2: 728,
        3: 728,
    }
    assert score.target_count_by_lead == {1: 712, 2: 712, 3: 712}
    assert causal_real_runtime.ledger.evaluation_array_reads == 0


@requires_torch_development_data
def test_real_causal_full_state_segment_backpropagates_and_changes_parameters(
    causal_real_runtime: Any,
) -> None:
    torch = pytest.importorskip("torch")
    net = build_native_knet(
        causal_real_runtime,
        zero_gain=False,
        seed=20260824,
        hidden=24,
    )
    initial_hash = parameter_sha256(net)
    optimizer = torch.optim.Adam(net.parameters(), lr=1.0e-4)
    open_loop_states = parity_runner.training_open_loop_states(causal_real_runtime)
    initialization_calls = 0
    original_initialize = net.initialize_filter

    def counted_initialize(*args: Any, **kwargs: Any) -> Any:
        nonlocal initialization_calls
        initialization_calls += 1
        return original_initialize(*args, **kwargs)

    net.initialize_filter = counted_initialize
    optimizer.zero_grad(set_to_none=True)
    loss = segment_multilead_mse(
        net,
        causal_real_runtime,
        start=100,
        segment_days=50,
        filter_warmup_days=10,
        open_loop_states=open_loop_states,
    )
    loss.objective.backward()
    nonzero = [
        name
        for name, parameter in net.named_parameters()
        if parameter.grad is not None
        and bool(torch.isfinite(parameter.grad).all())
        and bool(torch.count_nonzero(parameter.grad))
    ]
    optimizer.step()

    assert initialization_calls == 1
    assert nonzero
    assert parameter_sha256(net) != initial_hash
    assert loss.target_count_by_lead == {1: 37, 2: 37, 3: 37}
