"""Isolated full-routed HBV adapter for the repository's original KalmanNet.

The recurrent gain network is imported from ``knet/dl/nn_kalman_clamp_5.py``.
This module changes only the state projection needed because the original step
hard-codes five WALRUS bounds.  The HBV process, observation operator, recurrent
layers, gain generator, and their parameters are not copied or modified.
"""

from __future__ import annotations

import importlib.util
import math
from pathlib import Path

import torch

from .differentiable_hbv_lite import PARAM_NAMES, recession_half_weights
from .hbvlite_system_model import HBVLiteSystemModel


_REPOSITORY_ROOT = Path(__file__).resolve().parents[3]
_NATIVE_PATH = _REPOSITORY_ROOT / "knet" / "dl" / "nn_kalman_clamp_5.py"
_SPEC = importlib.util.spec_from_file_location("hsr_native_kalmannet", _NATIVE_PATH)
if _SPEC is None or _SPEC.loader is None:  # pragma: no cover - importlib platform guard
    raise ImportError(f"cannot load original KalmanNet from {_NATIVE_PATH}")
_MODULE = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_MODULE)
NativeKalmanNet = _MODULE.KalmanNet


class PaddedRoutedHBVSystemModel(HBVLiteSystemModel):
    """HBV routed system whose zero-weight FIFO tail is kept identically zero."""

    def __init__(self, *args, active_lag: int, **kwargs) -> None:
        self.active_lag = int(active_lag)
        super().__init__(*args, **kwargs)
        if self.emission != "routed" or not (1 <= self.active_lag <= self.L):
            raise ValueError("active_lag must identify an active routed FIFO prefix")

    def f(self, x: torch.Tensor, u: torch.Tensor | None = None) -> torch.Tensor:
        state = super().f(x, u)
        active_end = self.N_STORAGE + self.active_lag
        if active_end == self.m:
            return state
        return torch.cat([state[:, :active_end], torch.zeros_like(state[:, active_end:])], dim=-1)


class ResidualMemoryHBVSystemModel:
    """Compose HBV with a causal two-state autoregressive discharge residual."""

    n = 1
    N_STORAGE = 5

    def __init__(
        self,
        base_system: PaddedRoutedHBVSystemModel,
        coefficients: torch.Tensor,
    ) -> None:
        coefficients = coefficients.to(device=base_system.device, dtype=base_system.dtype).reshape(2)
        if not bool(torch.isfinite(coefficients).all()):
            raise ValueError("residual-memory coefficients must be finite")
        self.base_system = base_system
        self.coefficients = coefficients.detach()
        self.device = base_system.device
        self.dtype = base_system.dtype
        self.base_dimension = base_system.m
        self.residual_current_index = self.base_dimension
        self.residual_previous_index = self.base_dimension + 1
        self.m = self.base_dimension + 2
        self.L = base_system.L
        self.active_lag = base_system.active_lag
        eye = torch.eye(self.m, device=self.device, dtype=self.dtype)
        self.prior_q = eye.clone()
        self.prior_state_cov = eye * 10.0
        self.prior_r = torch.eye(1, device=self.device, dtype=self.dtype)

    def f(self, state: torch.Tensor, controls: torch.Tensor | None = None) -> torch.Tensor:
        if state.ndim == 1:
            state = state.unsqueeze(0)
        base_next = self.base_system.f(state[:, : self.base_dimension], controls)
        current = state[:, self.residual_current_index : self.residual_current_index + 1]
        previous = state[:, self.residual_previous_index : self.residual_previous_index + 1]
        predicted = self.coefficients[0] * current + self.coefficients[1] * previous
        return torch.cat([base_next, predicted, current], dim=-1)

    def h(self, state: torch.Tensor) -> torch.Tensor:
        if state.ndim == 1:
            state = state.unsqueeze(0)
        base_discharge = self.base_system.h(state[:, : self.base_dimension])
        residual = state[:, self.residual_current_index : self.residual_current_index + 1]
        # The residual is signed, but discharge remains physically nonnegative.
        return torch.clamp(base_discharge + residual, min=0.0)

    def get_default_initial_state(self) -> torch.Tensor:
        base = self.base_system.get_default_initial_state()
        residual = torch.zeros(base.shape[0], 2, device=base.device, dtype=base.dtype)
        return torch.cat([base, residual], dim=-1)


class _NativeArguments:
    """Only the attributes read by the original ``build_nn`` method."""

    def __init__(
        self,
        device: torch.device,
        *,
        hidden: int,
        in_mult: int,
        out_mult: int,
        activation_function: str,
    ) -> None:
        self.device = device
        self.activation_function = activation_function
        self.in_mult_KNet = int(in_mult)
        self.out_mult_KNet = int(out_mult)
        self.d_hidden_Q = int(hidden)
        self.d_hidden_Sigma = int(hidden)
        self.d_hidden_S = int(hidden)
        self.num_layers_GRU_Q = 1
        self.num_layers_GRU_Sigma = 1
        self.num_layers_GRU_S = 1
        self.dropout_prob = 0.0
        self.n_batch = 1
        self.state_bounds = {}


def build_padded_routed_system(
    params: torch.Tensor,
    *,
    maximum_lag: int,
    x0: torch.Tensor | None = None,
    dtype: torch.dtype = torch.float32,
    device: torch.device | None = None,
) -> tuple[HBVLiteSystemModel, int]:
    """Build an HBV routed state with a fixed, zero-padded FIFO dimension.

    Zero weights beyond ``ceil(lag_time)`` make the padded observation exactly
    equal to the native active-length observation while giving every basin the
    same KalmanNet state dimension.
    """

    if params.ndim != 2 or params.shape[0] != 1 or params.shape[1] != len(PARAM_NAMES):
        raise ValueError("params must have shape [1, 13]")
    if maximum_lag < 1:
        raise ValueError("maximum_lag must be positive")
    lag_index = PARAM_NAMES.index("lag_time")
    active_lag = max(1, int(math.ceil(float(params[0, lag_index]))))
    if active_lag > maximum_lag:
        raise ValueError(
            f"maximum_lag={maximum_lag} truncates active routing length {active_lag}"
        )
    device = device or torch.device("cpu")
    params = params.to(device=device, dtype=dtype)
    lag = params[:, lag_index : lag_index + 1]
    weights = recession_half_weights(lag, maximum_lag).to(device=device, dtype=dtype)
    system = PaddedRoutedHBVSystemModel(
        params,
        active_lag=active_lag,
        x0=x0,
        device=device,
        dtype=dtype,
        emission="routed",
        lag_weights=weights,
    )
    return system, active_lag


def correction_mask_for_active_lag(
    state_dimension: int,
    active_lag: int,
    *,
    storage_dimension: int = 5,
    dtype: torch.dtype = torch.float32,
    device: torch.device | None = None,
) -> torch.Tensor:
    """Return a mask that authorizes all stores and only physically active FIFO slots."""

    active_count = storage_dimension + int(active_lag)
    if active_lag < 1 or state_dimension < active_count:
        raise ValueError("active routing dimensions are outside the state vector")
    mask = torch.zeros(1, state_dimension, dtype=dtype, device=device)
    mask[:, :active_count] = 1.0
    return mask


class NativeHBVFullStateKalmanNet(NativeKalmanNet):
    """Original KalmanNet gain core with an HBV nonnegative full-state update."""

    def __init__(
        self,
        system: HBVLiteSystemModel,
        *,
        correction_mask: torch.Tensor,
        state_lower_bound: torch.Tensor | None = None,
        state_upper_bound: torch.Tensor | None = None,
        device: torch.device | None = None,
        hidden: int = 24,
        in_mult: int = 10,
        out_mult: int = 10,
        activation_function: str = "relu",
        correction_cap_in_state_scale_units: float | None = None,
    ) -> None:
        super().__init__()
        device = device or torch.device("cpu")
        arguments = _NativeArguments(
            device,
            hidden=hidden,
            in_mult=in_mult,
            out_mult=out_mult,
            activation_function=activation_function,
        )
        self.build_nn(system, arguments)
        mask = correction_mask.to(device=device, dtype=system.dtype)
        if mask.shape != (1, system.m):
            raise ValueError(f"correction_mask must have shape (1, {system.m})")
        self.register_buffer("correction_mask", mask)
        if state_lower_bound is None:
            lower = torch.zeros((1, system.m), device=device, dtype=system.dtype)
        else:
            lower = state_lower_bound.to(device=device, dtype=system.dtype)
            if lower.shape not in ((system.m,), (1, system.m)):
                raise ValueError(f"state_lower_bound must have shape ({system.m},) or (1, {system.m})")
            lower = lower.reshape(1, system.m)
        self.register_buffer("state_lower_bound", lower)
        if state_upper_bound is None:
            upper = torch.full((1, system.m), torch.inf, device=device, dtype=system.dtype)
        else:
            upper = state_upper_bound.to(device=device, dtype=system.dtype)
            if upper.shape not in ((system.m,), (1, system.m)):
                raise ValueError(f"state_upper_bound must have shape ({system.m},) or (1, {system.m})")
            upper = upper.reshape(1, system.m)
        self.register_buffer("state_upper_bound", upper)
        self.register_buffer(
            "observation_feature_scale",
            torch.ones(1, self.n, device=device, dtype=system.dtype),
        )
        self.register_buffer(
            "state_feature_scale",
            torch.ones(1, self.m, device=device, dtype=system.dtype),
        )
        self.normalized_features_enabled = False
        self.normalized_feature_guard: float | None = None
        if correction_cap_in_state_scale_units is not None and correction_cap_in_state_scale_units <= 0:
            raise ValueError("correction cap must be positive")
        self.correction_cap_in_state_scale_units = correction_cap_in_state_scale_units
        initial_cap = (
            torch.inf
            if correction_cap_in_state_scale_units is None
            else float(correction_cap_in_state_scale_units)
        )
        self.register_buffer(
            "correction_cap_by_state_scale_units",
            torch.full((1, self.m), initial_cap, device=device, dtype=system.dtype),
        )
        self.last_correction: torch.Tensor | None = None
        self.last_gain: torch.Tensor | None = None

    def set_basin_adaptation(
        self,
        *,
        system: HBVLiteSystemModel,
        correction_mask: torch.Tensor,
        state_lower_bound: torch.Tensor,
        state_upper_bound: torch.Tensor,
        observation_feature_scale: torch.Tensor,
        state_feature_scale: torch.Tensor,
        correction_cap_by_state_scale_units: torch.Tensor | None = None,
        normalized_feature_guard: float | None = 10.0,
    ) -> None:
        """Set calibration-only scales and bounds for one basin.

        The recurrent KalmanNet parameters remain shared.  Normalization only
        changes the downstream unit conversion: the original gain core receives
        dimensionless differences and its output is mapped back to state units.
        """

        if system.m != self.m or system.n != self.n:
            raise ValueError("basin system dimensions do not match the shared KalmanNet")
        # The original build method stores bound f/h callables. A shared network
        # must explicitly rebind them for every basin; changing only scales would
        # otherwise run all basins through the first basin's hydrological model.
        self.f = system.f
        self.h = system.h
        mask = correction_mask.to(self.correction_mask).reshape(1, self.m)
        lower = state_lower_bound.to(self.state_lower_bound).reshape(1, self.m)
        upper = state_upper_bound.to(self.state_upper_bound).reshape(1, self.m)
        obs_scale = observation_feature_scale.to(self.observation_feature_scale).reshape(1, self.n)
        state_scale = state_feature_scale.to(self.state_feature_scale).reshape(1, self.m)
        if correction_cap_by_state_scale_units is None:
            cap = self.correction_cap_by_state_scale_units
        else:
            cap = correction_cap_by_state_scale_units.to(
                self.correction_cap_by_state_scale_units
            ).reshape(1, self.m)
        if bool(torch.isnan(lower).any()) or bool(torch.isnan(upper).any()):
            raise ValueError("state bounds must not contain NaN")
        if bool((lower >= upper).any()):
            raise ValueError("every state lower bound must be smaller than its upper bound")
        if not bool(torch.isfinite(obs_scale).all()) or bool((obs_scale <= 0.0).any()):
            raise ValueError("observation feature scales must be positive and finite")
        if not bool(torch.isfinite(state_scale).all()) or bool((state_scale <= 0.0).any()):
            raise ValueError("state feature scales must be positive and finite")
        if bool(torch.isnan(cap).any()) or bool((cap <= 0.0).any()):
            raise ValueError("correction caps must be positive and not NaN")
        self.correction_mask.copy_(mask)
        self.state_lower_bound.copy_(lower)
        self.state_upper_bound.copy_(upper)
        self.observation_feature_scale.copy_(obs_scale)
        self.state_feature_scale.copy_(state_scale)
        self.correction_cap_by_state_scale_units.copy_(cap)
        self.normalized_features_enabled = True
        self.normalized_feature_guard = normalized_feature_guard

    def _estimate_normalized_gain(self, observation: torch.Tensor) -> torch.Tensor:
        obs_difference = (observation - self.y_previous) / self.observation_feature_scale
        # Match the original KalmanNet separation between gain features and the
        # analysis innovation.  Guards protect only the recurrent gain network;
        # they must not silently cap the physical state correction when the
        # experiment contract has correction capping disabled.
        raw_obs_innovation = (
            observation - self.m1y
        ) / self.observation_feature_scale
        gain_feature_innovation = raw_obs_innovation
        forward_evolution = (
            self.m1x_posterior - self.m1x_posterior_previous
        ) / self.state_feature_scale
        forward_update = (
            self.m1x_posterior - self.m1x_prior_previous
        ) / self.state_feature_scale
        if self.normalized_feature_guard is not None:
            guard = float(self.normalized_feature_guard)
            obs_difference = obs_difference.clamp(-guard, guard)
            gain_feature_innovation = gain_feature_innovation.clamp(-guard, guard)
            forward_evolution = forward_evolution.clamp(-guard, guard)
            forward_update = forward_update.clamp(-guard, guard)
        # These are the original class methods, including its native extreme-value guard.
        inputs = self.apply_clamp_scale_to_diffs(
            obs_difference,
            gain_feature_innovation,
            forward_evolution,
            forward_update,
        )
        gain_vector = self.KGain_step(*inputs)
        self.KGain = gain_vector.reshape(self.batch_size, self.m, self.n)
        return raw_obs_innovation

    def _project_state(self, state: torch.Tensor) -> torch.Tensor:
        return torch.maximum(
            torch.minimum(state, self.state_upper_bound), self.state_lower_bound
        )

    def initialize_filter(
        self,
        initial_state: torch.Tensor,
        sequence_length: int,
        previous_observation: torch.Tensor | None = None,
    ) -> None:
        """Initialize the original recurrent hidden state and state bookkeeping."""

        initial_state = initial_state.reshape(-1, self.m).to(self.device)
        self.batch_size = initial_state.shape[0]
        self.init_hidden_KNet()
        self.init_sequence(initial_state, int(sequence_length))
        if previous_observation is not None:
            previous_observation = previous_observation.reshape(self.batch_size, self.n).to(
                device=self.device, dtype=initial_state.dtype
            )
            if not bool(torch.isfinite(previous_observation).all()):
                raise ValueError("previous observation must be finite when supplied")
            self.y_previous = previous_observation

    def step_prior(self, controls: torch.Tensor) -> None:
        """Original prior calculation followed by the HBV nonnegative projection."""

        self.m1x_prior = self._project_state(self.f(self.m1x_posterior, controls))
        self.m1y = self.h(self.m1x_prior)

    def analysis_step(self, observation: torch.Tensor, controls: torch.Tensor) -> torch.Tensor:
        """Apply the original gain generator to all authorized HBV routed-state channels."""

        self.step_prior(controls)
        observation = observation.reshape(self.batch_size, self.n)
        observation_3d = observation.unsqueeze(-1)
        if self.normalized_features_enabled:
            normalized_innovation = self._estimate_normalized_gain(observation)
            correction_in_scale_units = self.KGain.squeeze(-1) * normalized_innovation
            cap = self.correction_cap_by_state_scale_units
            correction_in_scale_units = torch.maximum(
                torch.minimum(correction_in_scale_units, cap), -cap
            )
            correction = correction_in_scale_units * self.state_feature_scale
        else:
            self.estimate_gain(observation_3d)
            innovation = observation_3d - self.m1y.unsqueeze(-1)
            correction = torch.bmm(self.KGain, innovation).squeeze(-1)
        correction = correction * self.correction_mask
        posterior = self._project_state(self.m1x_prior + correction)

        self.m1x_posterior_previous = self.m1x_posterior
        self.m1x_posterior = posterior
        self.m1x_prior_previous = self.m1x_prior
        self.y_previous = observation
        self.last_correction = correction
        self.last_gain = self.KGain
        return posterior

    def predict_step(self, controls: torch.Tensor) -> torch.Tensor:
        """Advance without an observation while preserving native bookkeeping."""

        self.step_prior(controls)
        posterior = self.m1x_prior
        self.m1x_posterior_previous = self.m1x_posterior
        self.m1x_posterior = posterior
        self.m1x_prior_previous = self.m1x_prior
        self.y_previous = self.m1y.reshape(self.batch_size, self.n)
        self.last_correction = torch.zeros_like(posterior)
        self.last_gain = None
        return posterior
