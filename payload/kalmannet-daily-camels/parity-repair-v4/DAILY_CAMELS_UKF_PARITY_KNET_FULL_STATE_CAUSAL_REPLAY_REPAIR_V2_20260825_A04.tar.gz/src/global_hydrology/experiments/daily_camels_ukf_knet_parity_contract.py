"""Fail-closed contract for the daily CAMELS UKF/KalmanNet parity route.

The module deliberately uses only the Python standard library.  Importing it
must not initialize PyTorch or materialize any CAMELS array while the formal
training process owns the local host.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
import math
from typing import Any, Mapping, Sequence


SCHEMA_VERSION = "daily_camels_ukf_knet_parity_v1"
EXPERIMENT_FAMILY = "DAILY_CAMELS_UKF_KNET_PARITY_V1"
BASIN_ID = "09035800"
DEVELOPMENT_START = "1999-10-01"
DEVELOPMENT_END = "2008-09-30"
EXPECTED_DAYS = 3288
VALIDATION_START = "2006-10-01"
VALIDATION_START_INDEX = 2557
ARCHIVE_SHA256 = "71e6d163507ae405204bedf63d2c6c06e2c3ea303cea1a0481cfa4d5f280f5fd"
OFFICIAL_KNET_SOURCE = "knet/dl/nn_kalman_clamp_5.py"
OFFICIAL_KNET_SHA256 = "934570d3c840e9d57b8fbddf3a018dc29e190cdd712fc9daaf442e383f74d843"
FULL_STATE_ADAPTER = "src/global_hydrology/models/knet_native_hbvlite_full_state.py"
EXPECTED_STATE_DIMENSION = 18
EXPECTED_LEADS = (1, 2, 3)
DIAGNOSTIC_WINDOW_DAYS = 128
RECOVERY_WINDOW_DAYS = 731
FILTER_WARMUP_DAYS = 16
EXPECTED_DIAGNOSTIC_TARGET_COUNT_PER_LEAD = 109
EXPECTED_RECOVERY_TARGET_COUNT_PER_LEAD = 712
MINIMUM_POST_ZERO_IMPROVEMENT = 1e-6
MINIMUM_NSE_EXCLUSIVE = 0.6
PHYSICAL_UNIT_MULTILEAD_MSE = "physical_unit_multilead_mse"
NONFINITE_FORECAST_POLICY = "hard_fail_before_target_missingness_mask"

EXACT_TUKF06_DIAGNOSTIC_MODE = "exact_tukf06_backward_time_diagnostic"
CAUSAL_SHARED_SPINUP_MODE = "causal_shared_spinup"
ALLOWED_INITIALIZATION_MODES = (
    EXACT_TUKF06_DIAGNOSTIC_MODE,
    CAUSAL_SHARED_SPINUP_MODE,
)

ALLOWED_ARCHIVE_MEMBERS = frozenset(
    {
        "dates_ns",
        "forcing",
        "observations",
        "parameters",
        "initial_storage_state",
        "initial_state",
        "initial_covariance",
        "base_observation_variance",
        "state_dimension",
    }
)
ARCHIVED_INITIALIZATION_MEMBERS = frozenset(
    {"initial_storage_state", "initial_state", "initial_covariance"}
)
RESERVED_EVALUATION_START = date(1989, 10, 1)
RESERVED_EVALUATION_END = date(1999, 9, 30)


def _mapping(value: object, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be a JSON object")
    return value


def _boolean(value: object, name: str) -> bool:
    if not isinstance(value, bool):
        raise TypeError(f"{name} must be a JSON boolean")
    return value


@dataclass(frozen=True)
class ParityContract:
    """Immutable scientific contract for one same-window comparison family."""

    schema_version: str
    experiment_family: str
    basin_id: str
    cadence: str
    development_start: str
    development_end: str
    expected_days: int
    archive_sha256: str
    archive_members: tuple[str, ...]
    leads: tuple[int, ...]
    information_timing: str
    diagnostic_window_days: int
    recovery_window_days: int
    filter_warmup_days: int
    expected_diagnostic_target_count_per_lead: int
    expected_recovery_target_count_per_lead: int
    state_dimension: int
    official_knet_source: str
    official_knet_sha256: str
    full_state_adapter: str
    residual_memory_order: int
    preset_residual_gain_enabled: bool
    static_attributes_enabled: bool
    learned_physical_parameters_enabled: bool
    correction_cap_enabled: bool
    allowed_initialization_modes: tuple[str, ...]
    scientific_initialization_mode: str
    training_objective: str
    checkpoint_objective: str
    nonfinite_forecast_policy: str
    minimum_post_zero_improvement: float
    minimum_nse_exclusive: float
    require_each_lead: bool
    require_post_epoch_zero_improvement: bool

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "ParityContract":
        data = _mapping(payload["data"], "data")
        forecast = _mapping(payload["forecast"], "forecast")
        model = _mapping(payload["model"], "model")
        initialization = _mapping(payload["initialization"], "initialization")
        optimization = _mapping(payload["optimization"], "optimization")
        gate = _mapping(payload["gate"], "gate")
        period = data["development_period"]
        if not isinstance(period, Sequence) or isinstance(period, (str, bytes)) or len(period) != 2:
            raise ValueError("development period requires exactly two dates")

        contract = cls(
            schema_version=str(payload["schema_version"]),
            experiment_family=str(payload["experiment_family"]),
            basin_id=str(payload["basin_id"]),
            cadence=str(data["cadence"]),
            development_start=str(period[0]),
            development_end=str(period[1]),
            expected_days=int(data["expected_days"]),
            archive_sha256=str(data["archive_sha256"]),
            archive_members=tuple(str(value) for value in data["archive_members"]),
            leads=tuple(int(value) for value in forecast["leads_days"]),
            information_timing=str(forecast["information_timing"]),
            diagnostic_window_days=int(forecast["diagnostic_window_days"]),
            recovery_window_days=int(forecast["recovery_window_days"]),
            filter_warmup_days=int(forecast["filter_warmup_days"]),
            expected_diagnostic_target_count_per_lead=int(
                forecast["expected_diagnostic_target_count_per_lead"]
            ),
            expected_recovery_target_count_per_lead=int(
                forecast["expected_recovery_target_count_per_lead"]
            ),
            state_dimension=int(model["state_dimension"]),
            official_knet_source=str(model["official_knet_source"]),
            official_knet_sha256=str(model["official_knet_sha256"]),
            full_state_adapter=str(model["full_state_adapter"]),
            residual_memory_order=int(model["residual_memory_order"]),
            preset_residual_gain_enabled=_boolean(
                model["preset_residual_gain_enabled"],
                "preset_residual_gain_enabled",
            ),
            static_attributes_enabled=_boolean(
                model["static_attributes_enabled"], "static_attributes_enabled"
            ),
            learned_physical_parameters_enabled=_boolean(
                model["learned_physical_parameters_enabled"],
                "learned_physical_parameters_enabled",
            ),
            correction_cap_enabled=_boolean(
                model["correction_cap_enabled"], "correction_cap_enabled"
            ),
            allowed_initialization_modes=tuple(
                str(value) for value in initialization["allowed_modes"]
            ),
            scientific_initialization_mode=str(initialization["scientific_mode"]),
            training_objective=str(optimization["training_objective"]),
            checkpoint_objective=str(optimization["checkpoint_objective"]),
            nonfinite_forecast_policy=str(
                optimization["nonfinite_forecast_policy"]
            ),
            minimum_post_zero_improvement=float(
                optimization["minimum_post_zero_improvement"]
            ),
            minimum_nse_exclusive=float(gate["minimum_nse_exclusive"]),
            require_each_lead=_boolean(
                gate["require_each_lead"], "require_each_lead"
            ),
            require_post_epoch_zero_improvement=_boolean(
                gate["require_post_epoch_zero_improvement"],
                "require_post_epoch_zero_improvement",
            ),
        )
        contract.validate()
        return contract

    def validate(self) -> None:
        if self.schema_version != SCHEMA_VERSION:
            raise ValueError(f"schema version must remain {SCHEMA_VERSION}")
        if self.experiment_family != EXPERIMENT_FAMILY:
            raise ValueError(f"experiment family must remain {EXPERIMENT_FAMILY}")
        if self.basin_id != BASIN_ID:
            raise ValueError("first parity basin must remain 09035800")
        if self.cadence != "daily":
            raise ValueError("the parity route requires daily data")
        if (self.development_start, self.development_end) != (
            DEVELOPMENT_START,
            DEVELOPMENT_END,
        ):
            raise ValueError(
                "development period must remain 1999-10-01 through 2008-09-30"
            )
        if self.expected_days != EXPECTED_DAYS:
            raise ValueError("development archive must contain exactly 3,288 days")
        if self.archive_sha256 != ARCHIVE_SHA256:
            raise ValueError("basin 09035800 archive SHA-256 changed")
        if (
            len(self.archive_members) != len(ALLOWED_ARCHIVE_MEMBERS)
            or frozenset(self.archive_members) != ALLOWED_ARCHIVE_MEMBERS
        ):
            raise ValueError(
                "archive members must exactly preserve the TUKF06 data and state evidence"
            )
        if self.leads != EXPECTED_LEADS:
            raise ValueError("forecast leads must remain exactly 1, 2, and 3 days")
        if self.information_timing != "perfect_future_meteorological_forcing":
            raise ValueError("forecast information timing changed")
        if self.diagnostic_window_days != DIAGNOSTIC_WINDOW_DAYS:
            raise ValueError("the reproduction diagnostic requires the same first 128-day window")
        if self.recovery_window_days != RECOVERY_WINDOW_DAYS:
            raise ValueError("the recovery gate requires the complete 731-day validation window")
        if self.filter_warmup_days != FILTER_WARMUP_DAYS:
            raise ValueError("the comparison requires the same 16-day filter warm-up")
        if (
            self.expected_diagnostic_target_count_per_lead
            != EXPECTED_DIAGNOSTIC_TARGET_COUNT_PER_LEAD
        ):
            raise ValueError("each diagnostic forecast lead must retain exactly 109 targets")
        if (
            self.expected_recovery_target_count_per_lead
            != EXPECTED_RECOVERY_TARGET_COUNT_PER_LEAD
        ):
            raise ValueError("each recovery forecast lead must retain exactly 712 targets")
        if self.state_dimension != EXPECTED_STATE_DIMENSION:
            raise ValueError("basin 09035800 requires the full 18-dimensional routed state")
        if self.official_knet_source != OFFICIAL_KNET_SOURCE:
            raise ValueError("official KalmanNet source path changed")
        if self.official_knet_sha256 != OFFICIAL_KNET_SHA256:
            raise ValueError("official KalmanNet source SHA-256 changed")
        if self.full_state_adapter != FULL_STATE_ADAPTER:
            raise ValueError("existing full-state KalmanNet adapter path changed")
        if self.residual_memory_order != 0:
            raise ValueError("the clean parity base forbids appended residual memory")
        if self.preset_residual_gain_enabled:
            raise ValueError("the clean parity base forbids a preset residual gain")
        if self.static_attributes_enabled:
            raise ValueError("the clean parity base forbids static attributes")
        if self.learned_physical_parameters_enabled:
            raise ValueError("the clean parity base forbids learned physical parameters")
        if self.correction_cap_enabled:
            raise ValueError("the clean parity base forbids a correction cap")
        if self.allowed_initialization_modes != ALLOWED_INITIALIZATION_MODES:
            raise ValueError("initialization modes or their order changed")
        if self.scientific_initialization_mode != CAUSAL_SHARED_SPINUP_MODE:
            raise ValueError("only causal shared spin-up may support a scientific claim")
        if (
            self.training_objective != PHYSICAL_UNIT_MULTILEAD_MSE
            or self.checkpoint_objective != PHYSICAL_UNIT_MULTILEAD_MSE
        ):
            raise ValueError(
                "training and checkpoint selection require the same physical-unit objective"
            )
        if self.nonfinite_forecast_policy != NONFINITE_FORECAST_POLICY:
            raise ValueError(
                "non-finite forecasts must hard-fail before the target missingness mask"
            )
        if not math.isclose(
            self.minimum_post_zero_improvement,
            MINIMUM_POST_ZERO_IMPROVEMENT,
            rel_tol=0.0,
            abs_tol=1e-15,
        ):
            raise ValueError("minimum post-epoch-zero improvement must remain 0.000001")
        if not math.isclose(
            self.minimum_nse_exclusive,
            MINIMUM_NSE_EXCLUSIVE,
            rel_tol=0.0,
            abs_tol=1e-15,
        ):
            raise ValueError("Nash-Sutcliffe efficiency gate must remain strictly above 0.6")
        if not self.require_each_lead:
            raise ValueError("the 0.6 gate must apply separately to every lead")
        if not self.require_post_epoch_zero_improvement:
            raise ValueError("post-epoch-zero improvement is mandatory")


@dataclass(frozen=True)
class ScoringWindow:
    window_start_index: int
    window_end_exclusive: int
    issue_start_index: int
    issue_end_exclusive: int
    target_count_by_lead: dict[int, int]
    first_target_index_by_lead: dict[int, int]
    last_target_index_by_lead: dict[int, int]


def fixed_scoring_window(
    contract: ParityContract, *, purpose: str
) -> ScoringWindow:
    """Return the frozen diagnostic or complete recovery window indices."""

    if purpose == "diagnostic":
        window_days = contract.diagnostic_window_days
        expected_count = contract.expected_diagnostic_target_count_per_lead
    elif purpose == "recovery":
        window_days = contract.recovery_window_days
        expected_count = contract.expected_recovery_target_count_per_lead
    else:
        raise ValueError("window purpose must be diagnostic or recovery")
    window_start = VALIDATION_START_INDEX
    window_end = window_start + window_days
    if window_end > contract.expected_days:
        raise ValueError("scoring window extends beyond the development archive")
    issue_start = window_start + contract.filter_warmup_days
    issue_end = window_end - max(contract.leads)
    count = issue_end - issue_start
    if count != expected_count:
        raise ValueError(
            "scoring-window arithmetic does not produce the frozen target count"
        )
    return ScoringWindow(
        window_start_index=window_start,
        window_end_exclusive=window_end,
        issue_start_index=issue_start,
        issue_end_exclusive=issue_end,
        target_count_by_lead={lead: count for lead in contract.leads},
        first_target_index_by_lead={lead: issue_start + lead for lead in contract.leads},
        last_target_index_by_lead={
            lead: issue_end - 1 + lead for lead in contract.leads
        },
    )


@dataclass(frozen=True)
class InitializationEvidence:
    mode: str
    used_archive_members: tuple[str, ...]
    scientific_claim_allowed: bool
    backward_time_leakage: bool


def validate_initialization_usage(
    mode: str, *, used_archive_members: set[str]
) -> InitializationEvidence:
    """Keep exact historical reproduction separate from causal science."""

    if mode not in ALLOWED_INITIALIZATION_MODES:
        raise ValueError(f"unknown initialization mode: {mode}")
    used = frozenset(str(value) for value in used_archive_members)
    unknown = used - ALLOWED_ARCHIVE_MEMBERS
    if unknown:
        raise ValueError(f"initialization used unknown archive members: {sorted(unknown)}")
    if mode == EXACT_TUKF06_DIAGNOSTIC_MODE:
        missing = ARCHIVED_INITIALIZATION_MEMBERS - used
        if missing:
            raise ValueError(
                "exact TUKF06 diagnostic requires archived initial storage, state, and covariance"
            )
        return InitializationEvidence(
            mode=mode,
            used_archive_members=tuple(sorted(used)),
            scientific_claim_allowed=False,
            backward_time_leakage=True,
        )
    forbidden = used & ARCHIVED_INITIALIZATION_MEMBERS
    if forbidden:
        raise ValueError(
            "causal mode forbids use of archived future-derived initialization members"
        )
    return InitializationEvidence(
        mode=mode,
        used_archive_members=tuple(sorted(used)),
        scientific_claim_allowed=True,
        backward_time_leakage=False,
    )


@dataclass
class AccessLedger:
    """Record development access and fail closed on reserved evaluation work."""

    archive_member_reads: dict[str, int] = field(default_factory=dict)
    date_requests: int = 0
    evaluation_array_reads: int = 0
    evaluation_prediction_count: int = 0
    evaluation_metric_count: int = 0
    evaluation_output_count: int = 0

    def record_archive_member(self, member: str) -> None:
        if member not in ALLOWED_ARCHIVE_MEMBERS:
            raise PermissionError(f"archive member is not allowlisted: {member}")
        self.archive_member_reads[member] = self.archive_member_reads.get(member, 0) + 1

    def record_date_request(self, start: str, end: str) -> None:
        requested_start = date.fromisoformat(start)
        requested_end = date.fromisoformat(end)
        if requested_end < requested_start:
            raise ValueError("date request ends before it starts")
        if (
            requested_start <= RESERVED_EVALUATION_END
            and requested_end >= RESERVED_EVALUATION_START
        ):
            raise PermissionError("reserved evaluation period access is forbidden")
        if requested_start < date.fromisoformat(DEVELOPMENT_START) or requested_end > date.fromisoformat(
            DEVELOPMENT_END
        ):
            raise PermissionError("date request falls outside the allowed development period")
        self.date_requests += 1

    def record_evaluation_operation(self, operation: str) -> None:
        if operation not in {"array", "prediction", "metric", "output"}:
            raise ValueError(f"unknown evaluation operation: {operation}")
        raise PermissionError("reserved evaluation operations are forbidden")


@dataclass(frozen=True)
class PerformanceGate:
    passed: bool
    failed_gates: tuple[str, ...]
    objective_improvement: float


def performance_gate(
    *,
    epoch_zero_objective: float,
    best_objective: float,
    best_epoch: int,
    nse_by_lead: Mapping[int, float],
    target_count_by_lead: Mapping[int, int],
    contract: ParityContract,
) -> PerformanceGate:
    """Require both real optimization progress and the requested NSE level."""

    failed: list[str] = []
    improvement = float(epoch_zero_objective) - float(best_objective)
    if (
        best_epoch <= 0
        or not math.isfinite(improvement)
        or improvement <= contract.minimum_post_zero_improvement
    ):
        failed.append("post_epoch_zero_improvement")
    if set(nse_by_lead) != set(contract.leads) or any(
        not math.isfinite(float(nse_by_lead.get(lead, float("nan"))))
        or float(nse_by_lead[lead]) <= contract.minimum_nse_exclusive
        for lead in contract.leads
    ):
        failed.append("nse_above_0.6_each_lead")
    if set(target_count_by_lead) != set(contract.leads) or any(
        int(target_count_by_lead.get(lead, -1))
        != contract.expected_recovery_target_count_per_lead
        for lead in contract.leads
    ):
        failed.append("identical_target_count_each_lead")
    return PerformanceGate(
        passed=not failed,
        failed_gates=tuple(failed),
        objective_improvement=improvement,
    )


__all__ = [
    "ALLOWED_ARCHIVE_MEMBERS",
    "CAUSAL_SHARED_SPINUP_MODE",
    "EXACT_TUKF06_DIAGNOSTIC_MODE",
    "AccessLedger",
    "InitializationEvidence",
    "ParityContract",
    "PerformanceGate",
    "ScoringWindow",
    "fixed_scoring_window",
    "performance_gate",
    "validate_initialization_usage",
]
