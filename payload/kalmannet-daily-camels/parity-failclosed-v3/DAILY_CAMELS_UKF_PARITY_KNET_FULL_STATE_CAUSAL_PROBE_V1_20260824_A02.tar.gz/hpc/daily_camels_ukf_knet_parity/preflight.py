#!/usr/bin/env python3
"""Standard-library-only verifier for the daily CAMELS parity HPC bundle.

The probe verifies package availability and CUDA through metadata and
``nvidia-smi``.  It intentionally does not import NumPy, PyTorch, the
``global_hydrology`` package, or any experiment module.  The frozen NPZ is
opened only as a ZIP container and only NPY headers are read; no array payload
is materialized.
"""

from __future__ import annotations

import argparse
import ast
from hashlib import sha256
import importlib.metadata
import importlib.util
import json
import math
import os
from pathlib import Path, PurePosixPath
import socket
import struct
import subprocess
import sys
from typing import Any, Mapping
import uuid
import zipfile


SCHEMA_VERSION = "daily_camels_ukf_knet_parity_hpc_bundle_v1"
CONFIG_SCHEMA = "daily_camels_ukf_knet_parity_v1"
EXACT_MODE = "exact_tukf06_backward_time_diagnostic"
CAUSAL_MODE = "causal_shared_spinup"
EXACT_REPLAY_EXPERIMENT_ID = (
    "DAILY_CAMELS_UKF_PARITY_KNET_FULL_STATE_V1_20260824_A01"
)
REMOTE_ROOT = Path(
    "/data1/home/sunyiq/kalmannet_daily_camels_parity_20260824"
)
DEFAULT_RUN_PARENT = REMOTE_ROOT / "runs"
DEFAULT_STATUS_DIRECTORY = REMOTE_ROOT / "status"


def _safe_member_name(name: str) -> PurePosixPath:
    if "\\" in name:
        raise RuntimeError(f"manifest member uses a backslash: {name}")
    relative = PurePosixPath(name)
    if relative.is_absolute() or not relative.parts or ".." in relative.parts:
        raise RuntimeError(f"unsafe manifest member: {name}")
    lowered = tuple(part.lower() for part in relative.parts)
    if (
        any("hourly" in part for part in lowered)
        or any(part == "evaluation" or part.startswith("evaluation_") for part in lowered)
        or ".git" in lowered
        or "__pycache__" in lowered
    ):
        raise RuntimeError(f"forbidden manifest member: {name}")
    return relative


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_json(path: Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise RuntimeError(f"JSON root must be an object: {path}")
    return payload


def _atomic_json(path: Path, payload: Mapping[str, Any], *, allow_identical: bool = False) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    content = (
        json.dumps(
            payload,
            allow_nan=False,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        + "\n"
    ).encode("utf-8")
    if destination.exists():
        if allow_identical and destination.is_file() and destination.read_bytes() == content:
            return
        raise FileExistsError(f"refusing to replace status evidence: {destination}")
    pending = destination.with_name(destination.name + f".pending-{uuid.uuid4().hex}")
    try:
        with pending.open("xb") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        if destination.exists():
            raise FileExistsError(f"refusing to replace status evidence: {destination}")
        os.replace(pending, destination)
    finally:
        if pending.exists():
            pending.unlink()


def verify_bundle_root(bundle_root: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    """Verify the extracted byte inventory without importing scientific code."""

    root = Path(bundle_root).resolve()
    manifest_path = root / "bundle_manifest.json"
    if not root.is_dir() or not manifest_path.is_file():
        raise RuntimeError("extracted bundle root or bundle_manifest.json is absent")
    manifest = _read_json(manifest_path)
    if (
        manifest.get("schema_version") != SCHEMA_VERSION
        or manifest.get("purpose")
        != "daily_development_parity_replay_or_causal_training"
        or manifest.get("input_archive_count") != 1
        or manifest.get("reserved_data_member_count") != 0
        or manifest.get("array_members_materialized_during_build") != 0
        or not isinstance(manifest.get("member_sha256"), dict)
        or not isinstance(manifest.get("member_size"), dict)
    ):
        raise RuntimeError("bundle identity or reserved-data policy differs")

    expected_names = set(manifest["member_sha256"])
    if set(manifest["member_size"]) != expected_names:
        raise RuntimeError("bundle size and hash inventories differ")
    actual_names: set[str] = set()
    for path in root.rglob("*"):
        if path.is_symlink():
            raise RuntimeError(f"extracted bundle contains a symbolic link: {path}")
        if path.is_file():
            actual_names.add(path.relative_to(root).as_posix())
    if actual_names != expected_names | {"bundle_manifest.json"}:
        missing = sorted(expected_names - actual_names)
        extra = sorted(actual_names - expected_names - {"bundle_manifest.json"})
        raise RuntimeError(f"extracted inventory differs; missing={missing}, extra={extra}")

    for name in sorted(expected_names):
        relative = _safe_member_name(name)
        path = root.joinpath(*relative.parts)
        resolved = path.resolve()
        if root not in resolved.parents or not path.is_file():
            raise RuntimeError(f"bundle member escapes or is absent: {name}")
        if path.stat().st_size != int(manifest["member_size"][name]):
            raise RuntimeError(f"bundle member size mismatch: {name}")
        if sha256_file(path) != str(manifest["member_sha256"][name]):
            raise RuntimeError(f"bundle member SHA-256 mismatch: {name}")

    active_name = str(manifest.get("active_config_member", ""))
    active_relative = _safe_member_name(active_name)
    active_path = root.joinpath(*active_relative.parts)
    config = _read_json(active_path)
    if config.get("experiment_id") != manifest.get("experiment_id"):
        raise RuntimeError("active config and bundle experiment identifiers differ")
    if config.get("initialization", {}).get("execution_mode") != manifest.get(
        "initialization_mode"
    ):
        raise RuntimeError("active config and bundle initialization modes differ")

    package_initializers = manifest.get("package_initializers")
    if not isinstance(package_initializers, list) or not package_initializers:
        raise RuntimeError("isolated package initializer inventory is absent")
    for name in package_initializers:
        relative = _safe_member_name(str(name))
        if root.joinpath(*relative.parts).read_bytes() != b"":
            raise RuntimeError(f"package initializer is not empty: {name}")

    for section_name in (
        "frozen_evidence_sha256",
        "pinned_science_source_sha256",
        "active_config_declared_source_sha256",
        "entry_integration_source_sha256",
    ):
        hashes = manifest.get(section_name)
        if not isinstance(hashes, dict) or not hashes:
            raise RuntimeError(f"bundle {section_name} is absent")
        for name, expected in hashes.items():
            if manifest["member_sha256"].get(name) != expected:
                raise RuntimeError(f"bundle pinned evidence differs: {name}")

    return manifest, config


def _validate_config(config: Mapping[str, Any], phase: str) -> dict[str, Any]:
    if config.get("schema_version") != CONFIG_SCHEMA:
        raise RuntimeError("daily parity config schema differs")
    data = config.get("data")
    forecast = config.get("forecast")
    model = config.get("model")
    initialization = config.get("initialization")
    optimization = config.get("optimization")
    execution_policy = config.get("execution_policy", {})
    if not all(
        isinstance(item, Mapping)
        for item in (data, forecast, model, initialization, optimization, execution_policy)
    ):
        raise RuntimeError("daily parity config sections are incomplete")
    if (
        config.get("basin_id") != "09035800"
        or data.get("cadence") != "daily"
        or data.get("expected_days") != 3288
        or forecast.get("leads_days") != [1, 2, 3]
        or forecast.get("recovery_window_days") != 731
        or forecast.get("filter_warmup_days") != 16
        or forecast.get("checkpoint_target_count_per_lead_without_warmup") != 728
        or forecast.get("expected_recovery_target_count_per_lead") != 712
        or model.get("state_dimension") != 18
        or optimization.get("training_objective") != "physical_unit_multilead_mse"
        or optimization.get("checkpoint_objective") != "physical_unit_multilead_mse"
    ):
        raise RuntimeError("daily parity geometry or physical-unit objective differs")
    mode = str(initialization.get("execution_mode", ""))
    if mode not in {EXACT_MODE, CAUSAL_MODE}:
        raise RuntimeError("daily parity initialization mode is not allowlisted")

    if phase == "probe" and execution_policy.get("allow_probe") is not True:
        raise PermissionError("active config forbids probe")
    if phase == "replay" and execution_policy.get("allow_replay") is not True:
        raise PermissionError("active config forbids replay")
    if phase == "train":
        if mode != CAUSAL_MODE:
            raise PermissionError("training is forbidden for exact backward-time diagnostic mode")
        if execution_policy.get("allow_training") is not True:
            raise PermissionError("active config is a replay probe and forbids training")
        reference = config.get("reference")
        if not isinstance(reference, Mapping):
            raise PermissionError("causal training reference is absent")
        value = reference.get("causal_tukf06_complete_validation_objective_no_warmup")
        if not isinstance(value, (int, float)) or not math.isfinite(float(value)):
            raise PermissionError(
                "causal training requires a frozen finite 728-target UKF objective"
            )
        nse = reference.get("causal_tukf06_recovery_731_day_nse")
        if (
            not isinstance(nse, list)
            or len(nse) != 3
            or not all(isinstance(item, (int, float)) and math.isfinite(float(item)) for item in nse)
        ):
            raise PermissionError(
                "causal training requires three frozen 712-target UKF NSE values"
            )
    return {
        "experiment_id": str(config["experiment_id"]),
        "initialization_mode": mode,
        "selection_objective_target_count_per_lead": 728,
        "nse_gate_target_count_per_lead": 712,
    }


def _read_npy_header(stream: Any, label: str) -> dict[str, Any]:
    magic = stream.read(6)
    if magic != b"\x93NUMPY":
        raise RuntimeError(f"NPZ member is not an NPY stream: {label}")
    version = stream.read(2)
    if len(version) != 2:
        raise RuntimeError(f"truncated NPY version: {label}")
    major, minor = version[0], version[1]
    if major == 1:
        length_bytes = stream.read(2)
        if len(length_bytes) != 2:
            raise RuntimeError(f"truncated NPY header length: {label}")
        header_length = struct.unpack("<H", length_bytes)[0]
        encoding = "latin1"
    elif major in {2, 3}:
        length_bytes = stream.read(4)
        if len(length_bytes) != 4:
            raise RuntimeError(f"truncated NPY header length: {label}")
        header_length = struct.unpack("<I", length_bytes)[0]
        encoding = "utf-8" if major == 3 else "latin1"
    else:
        raise RuntimeError(f"unsupported NPY version {major}.{minor}: {label}")
    if not 1 <= header_length <= 65536:
        raise RuntimeError(f"unsafe NPY header length {header_length}: {label}")
    header_bytes = stream.read(header_length)
    if len(header_bytes) != header_length:
        raise RuntimeError(f"truncated NPY header: {label}")
    try:
        header = ast.literal_eval(header_bytes.decode(encoding).strip())
    except (SyntaxError, ValueError, UnicodeDecodeError) as error:
        raise RuntimeError(f"invalid NPY header: {label}") from error
    if not isinstance(header, dict) or set(header) != {"descr", "fortran_order", "shape"}:
        raise RuntimeError(f"unexpected NPY header keys: {label}")
    shape = header["shape"]
    if not isinstance(shape, tuple) or not all(
        isinstance(value, int) and value >= 0 for value in shape
    ):
        raise RuntimeError(f"unsafe NPY shape: {label}")
    descriptor = header["descr"]
    if "O" in str(descriptor):
        raise RuntimeError(f"object dtype is forbidden: {label}")
    return {
        "npy_version": f"{major}.{minor}",
        "descriptor": descriptor,
        "fortran_order": bool(header["fortran_order"]),
        "shape": list(shape),
        "header_bytes_read": 8 + len(length_bytes) + header_length,
        "array_payload_materialized": False,
    }


def inspect_npz_headers(bundle_root: Path, config: Mapping[str, Any]) -> dict[str, Any]:
    root = Path(bundle_root).resolve()
    data = config["data"]
    archive_relative = _safe_member_name(str(data["archive_path"]))
    archive_path = root.joinpath(*archive_relative.parts)
    expected_hash = str(data["archive_sha256"])
    if sha256_file(archive_path) != expected_hash:
        raise RuntimeError("frozen 09035800 archive SHA-256 differs")
    expected_arrays = {f"{name}.npy" for name in data["archive_members"]}
    headers: dict[str, Any] = {}
    with zipfile.ZipFile(archive_path, "r") as archive:
        infos = archive.infolist()
        names = [item.filename for item in infos]
        if len(names) != len(set(names)) or set(names) != expected_arrays:
            raise RuntimeError("NPZ member inventory differs from the frozen config")
        for information in sorted(infos, key=lambda item: item.filename):
            relative = _safe_member_name(information.filename)
            if len(relative.parts) != 1 or not information.filename.endswith(".npy"):
                raise RuntimeError(f"unsafe NPZ member name: {information.filename}")
            if information.flag_bits & 0x1:
                raise RuntimeError(f"encrypted NPZ member is forbidden: {information.filename}")
            with archive.open(information, "r") as stream:
                headers[information.filename[:-4]] = _read_npy_header(
                    stream, information.filename
                )
    return {
        "archive_path": data["archive_path"],
        "archive_sha256": expected_hash,
        "npy_member_count": len(headers),
        "npy_headers": headers,
        "array_members_materialized": 0,
        "array_payloads_materialized": 0,
    }


def _package_availability() -> dict[str, Any]:
    report: dict[str, Any] = {}
    for distribution, module in (
        ("numpy", "numpy"),
        ("torch", "torch"),
        ("pytest", "pytest"),
    ):
        spec = importlib.util.find_spec(module)
        if spec is None:
            raise RuntimeError(f"required package is unavailable: {distribution}")
        try:
            version = importlib.metadata.version(distribution)
        except importlib.metadata.PackageNotFoundError as error:
            raise RuntimeError(
                f"required distribution metadata is unavailable: {distribution}"
            ) from error
        report[distribution] = {"available": True, "version": version}
    return report


def _cuda_probe() -> dict[str, Any]:
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "").strip()
    assigned = [item.strip() for item in visible.split(",") if item.strip()]
    if len(assigned) != 1 or assigned[0] in {"-1", "NoDevFiles"}:
        raise RuntimeError(
            "exactly one CUDA_VISIBLE_DEVICES assignment is required for the probe"
        )
    command = [
        "nvidia-smi",
        "--id",
        assigned[0],
        "--query-gpu=index,name,memory.total,memory.free,driver_version",
        "--format=csv,noheader,nounits",
    ]
    try:
        completed = subprocess.run(
            command,
            check=True,
            capture_output=True,
            text=True,
            timeout=20,
        )
    except (FileNotFoundError, subprocess.CalledProcessError, subprocess.TimeoutExpired) as error:
        raise RuntimeError("nvidia-smi CUDA probe failed") from error
    rows = [line.strip() for line in completed.stdout.splitlines() if line.strip()]
    if len(rows) != 1:
        raise RuntimeError(f"exactly one visible CUDA device is required, got {len(rows)}")
    fields = [field.strip() for field in rows[0].split(",")]
    if len(fields) != 5:
        raise RuntimeError("unexpected nvidia-smi output")
    return {
        "visible_device_count": 1,
        "cuda_visible_devices": visible,
        "device_index": fields[0],
        "device_name": fields[1],
        "memory_total_mib": int(fields[2]),
        "memory_free_mib": int(fields[3]),
        "driver_version": fields[4],
    }


def _available_host_memory_bytes() -> int | None:
    path = Path("/proc/meminfo")
    if not path.is_file():
        return None
    for line in path.read_text(encoding="ascii").splitlines():
        if line.startswith("MemAvailable:"):
            return int(line.split()[1]) * 1024
    return None


def _verify_owner_file(path: Path | None, *, phase: str, experiment_id: str) -> dict[str, Any]:
    if path is None:
        raise RuntimeError("scheduled preflight requires an owner file")
    owner = _read_json(path)
    if (
        owner.get("phase") != phase
        or owner.get("experiment_id") != experiment_id
        or owner.get("slurm_job_id") != os.environ.get("SLURM_JOB_ID")
        or owner.get("hostname") != socket.gethostname()
    ):
        raise RuntimeError("exclusive owner file does not match this scheduled job")
    return owner


def _validate_replay_gate(
    path: Path,
    *,
    required_mode: str,
    archive_sha256: str,
) -> dict[str, Any]:
    gate = _read_json(path)
    if (
        gate.get("status") != "REPLAY_PASS"
        or gate.get("initialization_mode") != required_mode
        or gate.get("archive_sha256") != archive_sha256
        or gate.get("selection_objective_target_count_per_lead") != 728
        or gate.get("nse_gate_target_count_per_lead") != 712
        or gate.get("entry_exit_code") != 0
        or gate.get("pytest_exit_code") != 0
        or gate.get("ukf_replay_contract_passed") is not True
        or gate.get("zero_gain_contract_passed") is not True
    ):
        raise PermissionError(f"replay gate is not admissible: {path}")
    return gate


def run_online_preflight(
    bundle_root: Path,
    *,
    phase: str,
    run_parent: Path,
    owner_file: Path | None,
    exact_replay_gate: Path | None,
    causal_replay_gate: Path | None,
) -> dict[str, Any]:
    if phase not in {"probe", "replay", "train"}:
        raise ValueError(f"unknown phase: {phase}")
    if not os.environ.get("SLURM_JOB_ID"):
        raise RuntimeError("online preflight requires a scheduled Slurm job")
    if sys.version_info < (3, 10):
        raise RuntimeError(f"Python 3.10 or newer is required, got {sys.version}")
    if "torch" in sys.modules or "numpy" in sys.modules:
        raise RuntimeError("scientific array packages were imported before the read-only probe")

    manifest, config = verify_bundle_root(bundle_root)
    geometry = _validate_config(config, phase)
    target = Path(run_parent) / geometry["experiment_id"]
    if target.exists():
        raise FileExistsError(f"unique experiment directory already exists: {target}")
    owner = _verify_owner_file(
        owner_file,
        phase=phase,
        experiment_id=geometry["experiment_id"],
    )
    archive_probe = inspect_npz_headers(bundle_root, config)
    packages = _package_availability()
    cuda = _cuda_probe()
    if "torch" in sys.modules or "numpy" in sys.modules:
        raise RuntimeError("read-only preflight imported NumPy or PyTorch")

    replay_gates: dict[str, Any] = {}
    if phase == "train":
        if exact_replay_gate is None or causal_replay_gate is None:
            raise PermissionError("training requires explicit exact and causal replay gates")
        replay_gates = {
            "exact": _validate_replay_gate(
                exact_replay_gate,
                required_mode=EXACT_MODE,
                archive_sha256=archive_probe["archive_sha256"],
            ),
            "causal": _validate_replay_gate(
                causal_replay_gate,
                required_mode=CAUSAL_MODE,
                archive_sha256=archive_probe["archive_sha256"],
            ),
        }
        causal_metrics = replay_gates["causal"].get("verified_replay_metrics")
        reference = config.get("reference", {})
        if not isinstance(causal_metrics, Mapping):
            raise PermissionError("causal replay receipt has no independently sealed metrics")
        frozen_objective = float(
            reference["causal_tukf06_complete_validation_objective_no_warmup"]
        )
        measured_objective = causal_metrics.get("ukf_checkpoint_objective_728")
        if (
            not isinstance(measured_objective, (int, float))
            or abs(float(measured_objective) - frozen_objective) > 1e-12
        ):
            raise PermissionError("training config 728-target UKF objective differs from A02")
        measured_nse = _finite_lead_values(
            causal_metrics.get("ukf_nse_by_lead_712")
        )
        frozen_nse = reference["causal_tukf06_recovery_731_day_nse"]
        frozen_nse_map = {
            str(index): float(value) for index, value in enumerate(frozen_nse, start=1)
        }
        if any(abs(measured_nse[key] - frozen_nse_map[key]) > 1e-12 for key in measured_nse):
            raise PermissionError("training config 712-target UKF NSE differs from A02")

    report = {
        "status": "PREFLIGHT_PASS",
        "phase": phase,
        "experiment_id": geometry["experiment_id"],
        "initialization_mode": geometry["initialization_mode"],
        "bundle_root": str(Path(bundle_root).resolve()),
        "bundle_manifest_sha256": sha256_file(
            Path(bundle_root).resolve() / "bundle_manifest.json"
        ),
        "active_config_member": manifest["active_config_member"],
        "active_config_sha256": manifest["member_sha256"][
            manifest["active_config_member"]
        ],
        "python_version": sys.version,
        "hostname": socket.gethostname(),
        "slurm_job_id": os.environ["SLURM_JOB_ID"],
        "slurm_job_name": os.environ.get("SLURM_JOB_NAME"),
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
        "run_parent": str(Path(run_parent)),
        "run_directory": str(target),
        "run_directory_absent": True,
        "owner": owner,
        "package_availability_without_import": packages,
        "cuda_probe_without_torch_import": cuda,
        "available_host_memory_bytes": _available_host_memory_bytes(),
        "torch_imported": False,
        "numpy_imported": False,
        "array_members_materialized": 0,
        "reserved_data_member_count": 0,
        "archive_probe": archive_probe,
        "selection_objective": {
            "name": "physical_unit_multilead_mse",
            "filter_warmup_days": 0,
            "common_target_count_per_lead": 728,
        },
        "nse_gate": {
            "filter_warmup_days": 16,
            "common_target_count_per_lead": 712,
            "minimum_exclusive": 0.6,
        },
        "replay_gates": replay_gates,
    }
    return report


def _hash_run_tree(run_directory: Path) -> dict[str, str]:
    root = Path(run_directory).resolve()
    if not root.is_dir():
        raise RuntimeError(f"replay result directory is absent: {root}")
    hashes: dict[str, str] = {}
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise RuntimeError(f"replay result contains a symbolic link: {path}")
        if path.is_file():
            hashes[path.relative_to(root).as_posix()] = sha256_file(path)
    if not hashes:
        raise RuntimeError("replay result directory is empty")
    return hashes


def _lead_counts_equal(value: Any, expected: int) -> bool:
    if not isinstance(value, Mapping):
        return False
    return set(str(key) for key in value) == {"1", "2", "3"} and all(
        isinstance(item, int) and not isinstance(item, bool) and item == expected
        for item in value.values()
    )


def _finite_lead_values(value: Any) -> dict[str, float]:
    if not isinstance(value, Mapping) or set(str(key) for key in value) != {"1", "2", "3"}:
        raise RuntimeError("lead metric inventory differs")
    result: dict[str, float] = {}
    for key, item in value.items():
        if isinstance(item, bool) or not isinstance(item, (int, float)):
            raise RuntimeError("lead metric is not numeric")
        numeric = float(item)
        if not math.isfinite(numeric):
            raise RuntimeError("lead metric is non-finite")
        result[str(key)] = numeric
    return dict(sorted(result.items()))


def _zero_reserved_ledger(value: Any) -> bool:
    if not isinstance(value, Mapping):
        return False
    return all(
        value.get(name) == 0
        for name in (
            "evaluation_array_reads",
            "evaluation_prediction_count",
            "evaluation_metric_count",
            "evaluation_output_count",
        )
    )


def _verify_replay_result(
    run_directory: Path,
    *,
    experiment_id: str,
    initialization_mode: str,
) -> dict[str, Any]:
    root = Path(run_directory)
    required = {
        "result_summary.json",
        "replay_evidence.json",
        "replay_predictions.npz",
        "manifest.sha256.json",
        "completion.marker.json",
    }
    if not all((root / name).is_file() for name in required):
        missing = sorted(name for name in required if not (root / name).is_file())
        raise RuntimeError(f"replay result is incomplete; missing={missing}")

    summary = _read_json(root / "result_summary.json")
    evidence = _read_json(root / "replay_evidence.json")
    manifest = _read_json(root / "manifest.sha256.json")
    completion = _read_json(root / "completion.marker.json")
    if (
        summary.get("status") != "REPLAY_COMPLETE_DIAGNOSTIC_ONLY"
        or summary.get("phase") != "replay"
        or summary.get("experiment_id") != experiment_id
        or summary.get("initialization_mode") != initialization_mode
        or evidence.get("experiment_id") != experiment_id
        or completion.get("experiment_id") != experiment_id
        or completion.get("phase") != "replay"
        or completion.get("status") != summary.get("status")
    ):
        raise RuntimeError("replay identity or completion status differs")
    if completion.get("summary_sha256") != sha256_file(root / "result_summary.json"):
        raise RuntimeError("completion marker summary hash differs")
    if completion.get("manifest_sha256") != sha256_file(root / "manifest.sha256.json"):
        raise RuntimeError("completion marker manifest hash differs")
    files = manifest.get("files")
    if not isinstance(files, Mapping) or not files:
        raise RuntimeError("replay manifest file inventory is absent")
    for name, expected in files.items():
        relative = _safe_member_name(str(name))
        path = root.joinpath(*relative.parts)
        if not path.is_file() or sha256_file(path) != expected:
            raise RuntimeError(f"replay manifest hash differs: {name}")
    if not required.difference({"manifest.sha256.json", "completion.marker.json"}).issubset(
        set(files)
    ):
        raise RuntimeError("replay manifest omits a primary artifact")

    windows = evidence.get("windows")
    if not isinstance(windows, Mapping) or set(windows) != {"diagnostic", "recovery"}:
        raise RuntimeError("replay window inventory differs")
    diagnostic = windows["diagnostic"]
    recovery = windows["recovery"]
    if not isinstance(diagnostic, Mapping) or not isinstance(recovery, Mapping):
        raise RuntimeError("replay window evidence is malformed")
    if diagnostic.get("identical_ukf_knet_geometry") is not True:
        raise RuntimeError("diagnostic UKF/KalmanNet geometry differs")
    if recovery.get("identical_ukf_knet_geometry") is not True:
        raise RuntimeError("recovery UKF/KalmanNet geometry differs")
    for method in ("ukf", "zero_gain_knet"):
        diagnostic_method = diagnostic.get(method)
        recovery_method = recovery.get(method)
        if not isinstance(diagnostic_method, Mapping) or not isinstance(
            recovery_method, Mapping
        ):
            raise RuntimeError(f"replay method evidence is absent: {method}")
        if not _lead_counts_equal(
            diagnostic_method.get("target_count_by_lead_after_warmup"), 109
        ):
            raise RuntimeError(f"diagnostic 109-target geometry differs: {method}")
        if not _lead_counts_equal(
            recovery_method.get("target_count_by_lead_after_warmup"), 712
        ):
            raise RuntimeError(f"recovery 712-target geometry differs: {method}")
        if not _lead_counts_equal(
            recovery_method.get("target_count_by_lead_without_warmup"), 728
        ):
            raise RuntimeError(f"recovery 728-target geometry differs: {method}")

    ukf = recovery["ukf"]
    zero = recovery["zero_gain_knet"]
    objective = ukf.get("checkpoint_objective_without_warmup")
    if (
        isinstance(objective, bool)
        or not isinstance(objective, (int, float))
        or not math.isfinite(float(objective))
        or float(objective) <= 0.0
    ):
        raise RuntimeError("recovery UKF 728-target objective is invalid")
    nse = _finite_lead_values(ukf.get("nse_by_lead_after_warmup"))
    if float(summary.get("ukf_recovery_checkpoint_objective_728")) != float(objective):
        raise RuntimeError("summary and replay UKF objectives differ")
    if _finite_lead_values(summary.get("ukf_recovery_nse_by_lead_712")) != nse:
        raise RuntimeError("summary and replay UKF NSE values differ")
    if (
        zero.get("maximum_open_loop_difference") != 0.0
        or summary.get("zero_gain_maximum_open_loop_difference") != 0.0
    ):
        raise RuntimeError("zero-gain KalmanNet does not exactly reproduce open loop")
    if not _zero_reserved_ledger(summary.get("access_ledger")) or not _zero_reserved_ledger(
        evidence.get("access_ledger")
    ):
        raise RuntimeError("replay reserved-evaluation access ledger is nonzero")

    reference = evidence.get("recovery_reference")
    if not isinstance(reference, Mapping):
        raise RuntimeError("recovery reference evidence is absent")
    if initialization_mode == EXACT_MODE:
        if (
            reference.get("reference_was_frozen_before_replay") is not True
            or reference.get("objective_match") is not True
        ):
            raise RuntimeError("exact replay did not reproduce the frozen UKF objective")
    elif initialization_mode == CAUSAL_MODE:
        if reference.get("actual_checkpoint_objective_728") != objective:
            raise RuntimeError("causal replay reference candidate differs")

    return {
        "ukf_checkpoint_objective_728": float(objective),
        "ukf_nse_by_lead_712": nse,
        "zero_gain_maximum_open_loop_difference": 0.0,
        "result_summary_sha256": sha256_file(root / "result_summary.json"),
        "replay_evidence_sha256": sha256_file(root / "replay_evidence.json"),
        "replay_predictions_sha256": sha256_file(root / "replay_predictions.npz"),
        "completion_marker_sha256": sha256_file(root / "completion.marker.json"),
    }


def seal_replay(
    bundle_root: Path,
    *,
    run_parent: Path,
    pytest_exit_code: int,
    entry_exit_code: int,
) -> dict[str, Any]:
    if pytest_exit_code != 0 or entry_exit_code != 0:
        raise RuntimeError("cannot seal a failed test or replay process")
    manifest, config = verify_bundle_root(bundle_root)
    geometry = _validate_config(config, "replay")
    run_directory = Path(run_parent) / geometry["experiment_id"]
    run_hashes = _hash_run_tree(run_directory)
    verified = _verify_replay_result(
        run_directory,
        experiment_id=geometry["experiment_id"],
        initialization_mode=geometry["initialization_mode"],
    )
    if "torch" in sys.modules or "numpy" in sys.modules:
        raise RuntimeError("standard-library replay sealer imported scientific packages")
    archive_sha256 = str(config["data"]["archive_sha256"])
    return {
        "status": "REPLAY_PASS",
        "experiment_id": geometry["experiment_id"],
        "initialization_mode": geometry["initialization_mode"],
        "archive_sha256": archive_sha256,
        "bundle_manifest_sha256": sha256_file(
            Path(bundle_root).resolve() / "bundle_manifest.json"
        ),
        "active_config_member": manifest["active_config_member"],
        "active_config_sha256": manifest["member_sha256"][
            manifest["active_config_member"]
        ],
        "run_directory": str(run_directory),
        "run_member_count": len(run_hashes),
        "run_member_sha256": run_hashes,
        "verified_replay_metrics": verified,
        "pytest_exit_code": pytest_exit_code,
        "entry_exit_code": entry_exit_code,
        "ukf_replay_contract_passed": True,
        "zero_gain_contract_passed": True,
        "selection_objective": "physical_unit_multilead_mse",
        "selection_objective_target_count_per_lead": 728,
        "nse_gate_target_count_per_lead": 712,
        "array_members_materialized_by_sealer": 0,
        "torch_imported_by_sealer": False,
        "numpy_imported_by_sealer": False,
        "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
        "hostname": socket.gethostname(),
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Verify or seal a daily CAMELS UKF/KalmanNet parity HPC stage."
    )
    parser.add_argument(
        "--bundle-root",
        type=Path,
        default=Path(__file__).resolve().parents[2],
    )
    parser.add_argument("--phase", choices=("probe", "replay", "train"), default="probe")
    parser.add_argument("--run-parent", type=Path, default=DEFAULT_RUN_PARENT)
    parser.add_argument("--owner-file", type=Path)
    parser.add_argument("--exact-replay-gate", type=Path)
    parser.add_argument("--causal-replay-gate", type=Path)
    parser.add_argument("--report", type=Path)
    parser.add_argument("--offline-bundle-check", action="store_true")
    parser.add_argument("--seal-replay", action="store_true")
    parser.add_argument("--pytest-exit-code", type=int, default=0)
    parser.add_argument("--entry-exit-code", type=int, default=0)
    return parser


def main() -> int:
    arguments = build_parser().parse_args()
    try:
        if arguments.offline_bundle_check:
            manifest, config = verify_bundle_root(arguments.bundle_root)
            geometry = _validate_config(config, arguments.phase)
            archive_probe = inspect_npz_headers(arguments.bundle_root, config)
            if "torch" in sys.modules or "numpy" in sys.modules:
                raise RuntimeError("offline bundle check imported NumPy or PyTorch")
            report = {
                "status": "BUNDLE_VERIFIED",
                **geometry,
                "member_count": int(manifest["member_count"]),
                "array_members_materialized": 0,
                "archive_probe": archive_probe,
                "torch_imported": "torch" in sys.modules,
                "numpy_imported": "numpy" in sys.modules,
            }
        elif arguments.seal_replay:
            if arguments.phase != "replay":
                raise ValueError("--seal-replay requires --phase replay")
            report = seal_replay(
                arguments.bundle_root,
                run_parent=arguments.run_parent,
                pytest_exit_code=arguments.pytest_exit_code,
                entry_exit_code=arguments.entry_exit_code,
            )
        else:
            report = run_online_preflight(
                arguments.bundle_root,
                phase=arguments.phase,
                run_parent=arguments.run_parent,
                owner_file=arguments.owner_file,
                exact_replay_gate=arguments.exact_replay_gate,
                causal_replay_gate=arguments.causal_replay_gate,
            )
        if arguments.report is not None:
            _atomic_json(arguments.report, report)
    except Exception as error:
        failure = {
            "status": "PREFLIGHT_FAIL",
            "error_type": type(error).__name__,
            "error": str(error),
        }
        if arguments.report is not None:
            try:
                _atomic_json(arguments.report, failure)
            except Exception:
                pass
        print(json.dumps(failure, sort_keys=True), flush=True)
        return 1
    print(json.dumps(report, indent=2, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
