from __future__ import annotations

import pytest
import torch

from global_hydrology.models.differentiable_hbv_lite import PARAM_BOUNDS, PARAM_NAMES
from global_hydrology.models.knet_native_hbvlite_full_state import (
    NativeHBVFullStateKalmanNet,
    NativeKalmanNet,
    ResidualMemoryHBVSystemModel,
    build_padded_routed_system,
    correction_mask_for_active_lag,
)


DTYPE = torch.float64
NET_DTYPE = torch.float32


def _params(lag_time: float = 2.0) -> torch.Tensor:
    values = []
    for name in PARAM_NAMES:
        if name == "lag_time":
            values.append(lag_time)
        else:
            lower, upper = PARAM_BOUNDS[name]
            values.append((lower + upper) / 2.0)
    return torch.tensor([values], dtype=DTYPE)


def _forcing(n: int = 12) -> torch.Tensor:
    forcing = torch.zeros(n, 3, dtype=DTYPE)
    forcing[:, 0] = torch.linspace(0.5, 3.0, n)
    forcing[:, 1] = torch.linspace(-1.0, 8.0, n)
    forcing[:, 2] = 1.0
    return forcing


def test_padded_routing_is_exactly_equivalent_to_native_active_length() -> None:
    params = _params(lag_time=2.2)
    short, active_lag = build_padded_routed_system(params, maximum_lag=3, dtype=DTYPE)
    padded, padded_active = build_padded_routed_system(params, maximum_lag=15, dtype=DTYPE)
    assert active_lag == padded_active == 3
    assert short.m == 8
    assert padded.m == 20

    x_short = short.get_default_initial_state()
    x_padded = padded.get_default_initial_state()
    for control in _forcing():
        x_short = short.f(x_short, control)
        x_padded = padded.f(x_padded, control)
        assert torch.allclose(x_short[:, :5], x_padded[:, :5], atol=1e-12, rtol=0.0)
        assert torch.allclose(short.h(x_short), padded.h(x_padded), atol=1e-12, rtol=0.0)
        assert torch.count_nonzero(x_padded[:, 5 + active_lag :]) == 0


def test_adapter_is_the_original_network_with_full_active_state_authority() -> None:
    system, active_lag = build_padded_routed_system(
        _params().to(NET_DTYPE), maximum_lag=15, dtype=NET_DTYPE
    )
    mask = correction_mask_for_active_lag(system.m, active_lag, dtype=NET_DTYPE)
    net = NativeHBVFullStateKalmanNet(system, correction_mask=mask, hidden=12).to(NET_DTYPE)

    assert isinstance(net, NativeKalmanNet)
    assert net.m == 20
    assert torch.equal(mask[0, : 5 + active_lag], torch.ones(5 + active_lag, dtype=NET_DTYPE))
    assert torch.count_nonzero(mask[0, 5 + active_lag :]) == 0


def test_zero_gain_reproduces_padded_hbv_open_loop_exactly() -> None:
    system, active_lag = build_padded_routed_system(
        _params().to(NET_DTYPE), maximum_lag=15, dtype=NET_DTYPE
    )
    mask = correction_mask_for_active_lag(system.m, active_lag, dtype=NET_DTYPE)
    net = NativeHBVFullStateKalmanNet(system, correction_mask=mask, hidden=8).to(NET_DTYPE)
    with torch.no_grad():
        for parameter in net.parameters():
            parameter.zero_()

    initial = system.get_default_initial_state()
    net.initialize_filter(initial, sequence_length=1)
    control = _forcing(1)[0:1].to(NET_DTYPE)
    expected = system.f(initial, control)
    observation = system.h(expected).reshape(1, 1) + 10.0
    posterior = net.analysis_step(observation, control)

    assert torch.equal(posterior, expected)
    assert torch.count_nonzero(net.last_correction) == 0


def test_unit_feature_scales_are_equivalent_to_original_raw_gain_path() -> None:
    torch.manual_seed(77)
    system, active_lag = build_padded_routed_system(
        _params().to(NET_DTYPE), maximum_lag=15, dtype=NET_DTYPE
    )
    mask = correction_mask_for_active_lag(system.m, active_lag, dtype=NET_DTYPE)
    raw = NativeHBVFullStateKalmanNet(system, correction_mask=mask, hidden=8).to(NET_DTYPE)
    normalized = NativeHBVFullStateKalmanNet(system, correction_mask=mask, hidden=8).to(NET_DTYPE)
    normalized.load_state_dict(raw.state_dict())
    normalized.set_basin_adaptation(
        system=system,
        correction_mask=mask,
        state_lower_bound=torch.zeros(1, system.m, dtype=NET_DTYPE),
        state_upper_bound=torch.full((1, system.m), 1e6, dtype=NET_DTYPE),
        observation_feature_scale=torch.ones(1, 1, dtype=NET_DTYPE),
        state_feature_scale=torch.ones(1, system.m, dtype=NET_DTYPE),
        normalized_feature_guard=None,
    )
    raw.state_upper_bound.fill_(1e6)
    initial = system.get_default_initial_state()
    control = _forcing(1)[0:1].to(NET_DTYPE)
    prior = system.f(initial, control)
    observation = system.h(prior).reshape(1, 1) + 0.25
    raw.initialize_filter(initial, 1)
    normalized.initialize_filter(initial, 1)

    raw_posterior = raw.analysis_step(observation, control)
    normalized_posterior = normalized.analysis_step(observation, control)

    assert torch.equal(raw.last_gain, normalized.last_gain)
    assert torch.equal(raw_posterior, normalized_posterior)


def test_shared_network_rebinds_each_basins_hydrological_model() -> None:
    params_a = _params().to(NET_DTYPE)
    params_b = params_a.clone()
    params_b[0, PARAM_NAMES.index("parK2")] = 0.19
    system_a, active_a = build_padded_routed_system(
        params_a, maximum_lag=15, dtype=NET_DTYPE
    )
    system_b, active_b = build_padded_routed_system(
        params_b, maximum_lag=15, dtype=NET_DTYPE
    )
    mask_a = correction_mask_for_active_lag(system_a.m, active_a, dtype=NET_DTYPE)
    mask_b = correction_mask_for_active_lag(system_b.m, active_b, dtype=NET_DTYPE)
    net = NativeHBVFullStateKalmanNet(system_a, correction_mask=mask_a, hidden=8).to(NET_DTYPE)
    with torch.no_grad():
        for parameter in net.parameters():
            parameter.zero_()
    net.set_basin_adaptation(
        system=system_b,
        correction_mask=mask_b,
        state_lower_bound=torch.zeros(1, system_b.m, dtype=NET_DTYPE),
        state_upper_bound=torch.full((1, system_b.m), torch.inf, dtype=NET_DTYPE),
        observation_feature_scale=torch.ones(1, 1, dtype=NET_DTYPE),
        state_feature_scale=torch.ones(1, system_b.m, dtype=NET_DTYPE),
        normalized_feature_guard=10.0,
    )
    initial = system_b.get_default_initial_state()
    control = _forcing(1)[0:1].to(NET_DTYPE)
    expected_b = system_b.f(initial, control)
    expected_a = system_a.f(initial, control)
    net.initialize_filter(initial, 1)
    posterior = net.analysis_step(system_b.h(expected_b), control)

    assert torch.equal(posterior, expected_b)
    assert not torch.equal(expected_a, expected_b)


def test_forecast_loss_backpropagates_through_original_network_and_routing_state() -> None:
    torch.manual_seed(123)
    system, active_lag = build_padded_routed_system(
        _params().to(NET_DTYPE), maximum_lag=15, dtype=NET_DTYPE
    )
    mask = correction_mask_for_active_lag(system.m, active_lag, dtype=NET_DTYPE)
    upper = torch.full((1, system.m), 1e5, dtype=NET_DTYPE)
    net = NativeHBVFullStateKalmanNet(
        system,
        correction_mask=mask,
        state_upper_bound=upper,
        hidden=12,
    ).to(NET_DTYPE)
    forcing = _forcing(4).to(NET_DTYPE)
    initial = system.get_default_initial_state()
    net.initialize_filter(initial, sequence_length=1)
    prior = system.f(initial, forcing[0:1])
    observation = system.h(prior).reshape(1, 1) + 0.25
    posterior = net.analysis_step(observation, forcing[0:1])
    posterior.retain_grad()

    forecast_state = system.f(posterior, forcing[1:2])
    prediction = system.h(forecast_state)
    loss = (prediction - (observation + 0.1)).square().mean()
    loss.backward()

    nonzero_parameter_gradients = sum(
        parameter.grad is not None
        and bool(torch.isfinite(parameter.grad).all())
        and bool(torch.count_nonzero(parameter.grad))
        for parameter in net.parameters()
    )
    assert nonzero_parameter_gradients >= 20
    assert posterior.grad is not None
    assert torch.isfinite(posterior.grad).all()
    assert torch.count_nonzero(posterior.grad[:, 5 : 5 + active_lag]) >= 1
    assert net.FC2[-1].weight.grad is not None
    assert torch.count_nonzero(net.FC2[-1].weight.grad) > 0


def test_residual_memory_zero_state_preserves_base_hbv_and_ar2_transition() -> None:
    base, _ = build_padded_routed_system(
        _params().to(NET_DTYPE), maximum_lag=15, dtype=NET_DTYPE
    )
    coefficients = torch.tensor([0.7, -0.2], dtype=NET_DTYPE)
    system = ResidualMemoryHBVSystemModel(base, coefficients)
    initial = system.get_default_initial_state()
    control = _forcing(1)[0:1].to(NET_DTYPE)

    base_next = base.f(initial[:, : base.m], control)
    zero_residual_next = system.f(initial, control)
    assert torch.equal(zero_residual_next[:, : base.m], base_next)
    assert torch.count_nonzero(zero_residual_next[:, base.m :]) == 0
    assert torch.equal(system.h(zero_residual_next), base.h(base_next))

    state = initial.clone()
    state[:, system.residual_current_index] = -2.0
    state[:, system.residual_previous_index] = 1.5
    transitioned = system.f(state, control)
    expected = 0.7 * -2.0 - 0.2 * 1.5
    assert transitioned[0, system.residual_current_index].item() == pytest.approx(expected)
    assert transitioned[0, system.residual_previous_index].item() == pytest.approx(-2.0)


def test_unit_residual_gain_eliminates_signed_same_day_discharge_error() -> None:
    base, active_lag = build_padded_routed_system(
        _params().to(NET_DTYPE), maximum_lag=15, dtype=NET_DTYPE
    )
    system = ResidualMemoryHBVSystemModel(
        base, torch.tensor([0.5, 0.2], dtype=NET_DTYPE)
    )
    mask = torch.zeros(1, system.m, dtype=NET_DTYPE)
    mask[:, system.residual_current_index] = 1.0
    lower = torch.zeros(1, system.m, dtype=NET_DTYPE)
    lower[:, base.m :] = -torch.inf
    net = NativeHBVFullStateKalmanNet(
        system,
        correction_mask=mask,
        state_lower_bound=lower,
        hidden=8,
        correction_cap_in_state_scale_units=3.0,
    ).to(NET_DTYPE)
    with torch.no_grad():
        net.FC2[-1].weight.zero_()
        net.FC2[-1].bias.zero_()
        net.FC2[-1].bias[system.residual_current_index] = 1.0
    net.set_basin_adaptation(
        system=system,
        correction_mask=mask,
        state_lower_bound=lower,
        state_upper_bound=torch.full((1, system.m), torch.inf, dtype=NET_DTYPE),
        observation_feature_scale=torch.ones(1, 1, dtype=NET_DTYPE),
        state_feature_scale=torch.ones(1, system.m, dtype=NET_DTYPE),
        correction_cap_by_state_scale_units=torch.full(
            (1, system.m), 3.0, dtype=NET_DTYPE
        ),
        normalized_feature_guard=10.0,
    )
    initial = system.get_default_initial_state()
    control = _forcing(1)[0:1].to(NET_DTYPE)
    prior = system.f(initial, control)
    prior_discharge = system.h(prior)
    observation = prior_discharge - 0.25
    assert float(observation) > 0.0
    net.initialize_filter(initial, sequence_length=1)
    posterior = net.analysis_step(observation, control)

    assert posterior[0, system.residual_current_index].item() == pytest.approx(-0.25)
    assert torch.allclose(system.h(posterior), observation, atol=1e-6, rtol=0.0)
    assert torch.equal(posterior[:, : base.m], prior[:, : base.m])
    assert isinstance(net, NativeKalmanNet)
