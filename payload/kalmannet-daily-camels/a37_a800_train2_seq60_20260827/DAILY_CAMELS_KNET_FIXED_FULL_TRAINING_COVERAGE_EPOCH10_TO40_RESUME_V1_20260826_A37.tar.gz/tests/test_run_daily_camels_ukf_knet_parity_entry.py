from __future__ import annotations

import ast
import copy
import importlib.util
import json
import math
from pathlib import Path
from types import SimpleNamespace
import subprocess
import sys

import pytest


ROOT = Path(__file__).resolve().parents[1]
ENTRY_PATH = ROOT / "scripts" / "run_daily_camels_ukf_knet_parity.py"
A16_CONFIG = (
    ROOT
    / "configs"
    / "daily_camels_knet_fixed_full_training_coverage_ten_epoch_a16.json"
)
A37_CONFIG = (
    ROOT
    / "configs"
    / "daily_camels_knet_fixed_full_training_coverage_epoch10_to40_resume_a37.json"
)
A37_PORTABILITY_RECEIPT = (
    ROOT
    / "artifacts"
    / "daily_camels_knet_a37_portability_contract"
    / "A37_A800_PORTABILITY_PROBE2_SEQ57_RECEIPT.json"
)
A16_EPOCH_TEN_CHECKPOINT = (
    ROOT
    / "artifacts"
    / "daily_camels_ukf_knet_parity_seq15_failure_evidence"
    / "ff2084c4"
    / "seq15_snapshot_2831"
    / "run"
    / "checkpoints"
    / "epoch_010.pt"
)
RUNNER_PATH = (
    ROOT
    / "src"
    / "global_hydrology"
    / "experiments"
    / "daily_camels_ukf_knet_parity_runner.py"
)
MODULE_NAME = "daily_camels_ukf_knet_parity_entry_standalone"


def _load_entry_module():
    numerical_modules_before = {
        name: name in sys.modules for name in ("numpy", "torch")
    }
    spec = importlib.util.spec_from_file_location(MODULE_NAME, ENTRY_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load standalone daily parity entry")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    numerical_modules_after = {
        name: name in sys.modules for name in ("numpy", "torch")
    }
    assert numerical_modules_after == numerical_modules_before
    return module


ENTRY = _load_entry_module()


def test_entry_requires_explicit_config_identity() -> None:
    action = next(
        item for item in ENTRY.build_parser()._actions if item.dest == "config"
    )
    assert action.required is True
    assert action.default is None


def test_entry_exposes_explicit_optional_resume_checkpoint() -> None:
    action = next(
        item for item in ENTRY.build_parser()._actions if item.dest == "resume"
    )
    assert action.required is False
    assert action.default is None


def test_portability_diagnostic_flag_is_explicit_and_disabled_by_default() -> None:
    action = next(
        item
        for item in ENTRY.build_parser()._actions
        if item.dest == "portability_diagnostic_only"
    )
    assert action.required is False
    assert action.default is False


def test_effective_correction_scope_defaults_to_historical_full_state() -> None:
    assert (
        ENTRY._model_correction_scope({})
        == ENTRY.FULL_EIGHTEEN_DIMENSIONAL_STATE_CORRECTION_SCOPE
    )


def test_effective_correction_scope_accepts_only_two_frozen_values() -> None:
    for value in (
        ENTRY.FULL_EIGHTEEN_DIMENSIONAL_STATE_CORRECTION_SCOPE,
        ENTRY.HBV_LITE_FIVE_STORAGE_STATE_CORRECTION_SCOPE,
    ):
        assert ENTRY._model_correction_scope({"correction_scope": value}) == value

    with pytest.raises(TypeError, match="correction_scope"):
        ENTRY._model_correction_scope({"correction_scope": 5})
    with pytest.raises(ValueError, match="correction_scope"):
        ENTRY._model_correction_scope({"correction_scope": "five_state_network"})


def test_entry_and_numerical_runner_use_identical_correction_scope_values() -> None:
    tree = ast.parse(RUNNER_PATH.read_text(encoding="utf-8"), filename=str(RUNNER_PATH))
    assignments = {
        node.targets[0].id: ast.literal_eval(node.value)
        for node in tree.body
        if isinstance(node, ast.Assign)
        and len(node.targets) == 1
        and isinstance(node.targets[0], ast.Name)
        and node.targets[0].id
        in {
            "FULL_EIGHTEEN_DIMENSIONAL_STATE_CORRECTION_SCOPE",
            "HBV_LITE_FIVE_STORAGE_STATE_CORRECTION_SCOPE",
        }
    }
    assert assignments == {
        "FULL_EIGHTEEN_DIMENSIONAL_STATE_CORRECTION_SCOPE": (
            ENTRY.FULL_EIGHTEEN_DIMENSIONAL_STATE_CORRECTION_SCOPE
        ),
        "HBV_LITE_FIVE_STORAGE_STATE_CORRECTION_SCOPE": (
            ENTRY.HBV_LITE_FIVE_STORAGE_STATE_CORRECTION_SCOPE
        ),
    }


def test_training_entry_passes_effective_correction_scope_to_existing_knet() -> None:
    tree = ast.parse(ENTRY_PATH.read_text(encoding="utf-8"), filename=str(ENTRY_PATH))
    calls = [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "runner"
        and node.func.attr == "build_native_knet"
    ]
    assert len(calls) == 1
    keyword = next(
        item for item in calls[0].keywords if item.arg == "correction_scope"
    )
    assert isinstance(keyword.value, ast.Attribute)
    assert isinstance(keyword.value.value, ast.Name)
    assert keyword.value.value.id == "preflight"
    assert keyword.value.attr == "correction_scope"


def test_entry_imports_without_numerical_modules_in_clean_subprocess() -> None:
    program = f"""
import importlib.util
from pathlib import Path
import sys
path = Path({str(ENTRY_PATH)!r})
spec = importlib.util.spec_from_file_location({MODULE_NAME!r}, path)
assert spec is not None and spec.loader is not None
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
assert 'numpy' not in sys.modules
assert 'torch' not in sys.modules
"""
    completed = subprocess.run(
        [sys.executable, "-I", "-c", program],
        check=False,
        capture_output=True,
        text=True,
    )
    assert completed.returncode == 0, completed.stderr


def test_every_npz_write_call_passes_io_numpy_path_and_arrays() -> None:
    tree = ast.parse(ENTRY_PATH.read_text(encoding="utf-8"), filename=str(ENTRY_PATH))
    calls = [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "_write_npz"
    ]

    assert len(calls) == 5
    assert [len(call.args) for call in calls] == [4, 4, 4, 4, 4]
    assert all(
        isinstance(call.args[0], ast.Name)
        and call.args[0].id == "io_module"
        and isinstance(call.args[1], ast.Name)
        and call.args[1].id == "numpy_module"
        for call in calls
    )


def test_cross_device_difference_requires_exact_targets_indices_and_masks() -> None:
    numpy = pytest.importorskip("numpy")
    reference = {
        "lead_1_prediction": numpy.asarray([1.0, 2.0], dtype=numpy.float64),
        "lead_1_target": numpy.asarray([1.5, 2.5], dtype=numpy.float64),
        "lead_1_issue_index": numpy.asarray([4, 5], dtype=numpy.int64),
        "lead_1_target_index": numpy.asarray([5, 6], dtype=numpy.int64),
        "lead_1_finite_mask": numpy.asarray([True, True], dtype=numpy.bool_),
    }
    actual = {name: value.copy() for name, value in reference.items()}
    actual["lead_1_prediction"][1] += 2.0e-7

    evidence = ENTRY._prediction_numeric_difference_evidence(
        numpy,
        actual_arrays=actual,
        reference_arrays=reference,
    )

    assert evidence["status"] == "MEASURED_NOT_ADMITTED_FOR_TRAINING"
    assert evidence["maximum_absolute_error_all_predictions"] == pytest.approx(
        2.0e-7
    )
    assert evidence["prediction_members"]["lead_1_prediction"][
        "different_value_count"
    ] == 1
    assert evidence["prediction_members"]["lead_1_prediction"][
        "root_mean_square_error"
    ] == pytest.approx(2.0e-7 / math.sqrt(2.0))
    assert set(evidence["exact_non_prediction_members"]) == {
        "lead_1_target",
        "lead_1_issue_index",
        "lead_1_target_index",
        "lead_1_finite_mask",
    }

    changed_target = {name: value.copy() for name, value in actual.items()}
    changed_target["lead_1_target"][0] += 1.0e-12
    with pytest.raises(RuntimeError, match="target, index, or mask changed"):
        ENTRY._prediction_numeric_difference_evidence(
            numpy,
            actual_arrays=changed_target,
            reference_arrays=reference,
        )


def test_a37_portability_references_are_hash_bound_source_predictions() -> None:
    numpy = pytest.importorskip("numpy")
    configuration = json.loads(A37_CONFIG.read_text(encoding="utf-8"))
    continuation = ENTRY._continuation_spec(
        configuration,
        ROOT,
        A16_EPOCH_TEN_CHECKPOINT,
    )

    epoch_zero_path = ENTRY._continuation_prediction_reference_path(
        continuation,
        epoch=0,
    )
    epoch_ten_path = ENTRY._continuation_prediction_reference_path(
        continuation,
        epoch=10,
    )

    assert ENTRY.sha256_file(epoch_zero_path) == (
        "17a6f0dbbe145b0262e0b2c1f426c49f1687a29927e8f8348f6ea293e246d91f"
    )
    assert ENTRY.sha256_file(epoch_ten_path) == (
        "0517d0e6d4fb290e0cfe1f70ca1ed22e87b1c2c63618edf2b67d725445d7b440"
    )
    epoch_zero_arrays = ENTRY._load_npz_arrays(numpy, epoch_zero_path)
    evidence = ENTRY._prediction_numeric_difference_evidence(
        numpy,
        actual_arrays=epoch_zero_arrays,
        reference_arrays=epoch_zero_arrays,
    )
    assert len(evidence["exact_non_prediction_members"]) == 12
    assert evidence["maximum_absolute_error_all_predictions"] == 0.0
    assert evidence["maximum_relative_error_all_predictions"] == 0.0


def test_a37_requires_hash_bound_rtx3090_to_a800_portability_receipt() -> None:
    configuration = json.loads(A37_CONFIG.read_text(encoding="utf-8"))
    declared = configuration["cross_device_portability_receipt"]

    assert set(declared) == {
        "member",
        "sha256",
        "source_device_name",
        "target_device_name",
        "prediction_maximum_absolute_error_limit",
        "prediction_maximum_relative_error_limit",
        "objective_and_metric_absolute_error_limit",
    }
    assert declared["member"] == A37_PORTABILITY_RECEIPT.relative_to(ROOT).as_posix()
    assert declared["sha256"] == ENTRY.sha256_file(A37_PORTABILITY_RECEIPT)
    assert declared["source_device_name"] == "NVIDIA GeForce RTX 3090"
    assert declared["target_device_name"] == "NVIDIA A800-SXM4-80GB"
    assert declared["prediction_maximum_absolute_error_limit"] == 3.0e-7
    assert declared["prediction_maximum_relative_error_limit"] == 3.0e-7
    assert declared["objective_and_metric_absolute_error_limit"] == 3.0e-9

    contract = ENTRY._load_cross_device_portability_contract(
        configuration,
        ROOT,
    )
    assert contract["status"] == "FROZEN_FOR_RTX3090_TO_A800_CONTINUATION"
    assert contract["probe_slurm_job_id"] == "215366"
    assert contract["new_optimizer_steps"] == 0
    assert contract["new_sampled_forecast_events"] == 0
    assert contract["reserved_evaluation_operations"] == 0


def test_cross_device_prediction_limits_are_independent_not_allclose() -> None:
    contract = {
        "prediction_maximum_absolute_error_limit": 3.0e-7,
        "prediction_maximum_relative_error_limit": 3.0e-7,
    }
    measured = {
        "maximum_absolute_error_all_predictions": 3.0e-7,
        "maximum_relative_error_all_predictions": 3.0e-7,
    }
    evidence = ENTRY._assert_prediction_portability(
        measured,
        contract,
        boundary="epoch_010",
    )
    assert evidence["status"] == "CROSS_DEVICE_PORTABILITY_PASS"

    with pytest.raises(RuntimeError, match="maximum absolute prediction error"):
        ENTRY._assert_prediction_portability(
            {
                **measured,
                "maximum_absolute_error_all_predictions": 3.0000001e-7,
            },
            contract,
            boundary="epoch_010",
        )
    with pytest.raises(RuntimeError, match="maximum relative prediction error"):
        ENTRY._assert_prediction_portability(
            {
                **measured,
                "maximum_relative_error_all_predictions": 3.0000001e-7,
            },
            contract,
            boundary="epoch_010",
        )


def test_cross_device_objective_and_metric_limits_fail_closed() -> None:
    contract = {"objective_and_metric_absolute_error_limit": 3.0e-9}
    objective = ENTRY._assert_objective_portability(
        actual=3.0e-9,
        expected=0.0,
        contract=contract,
        boundary="epoch_000",
    )
    assert objective["status"] == "CROSS_DEVICE_PORTABILITY_PASS"

    metric_evidence = {
        "per_lead": {
            "1": {
                "target_count": 712,
                "mse_delta_actual_minus_source": 3.0e-9,
                "nse_delta_actual_minus_source": -3.0e-9,
            },
            "2": {
                "target_count": 712,
                "mse_delta_actual_minus_source": 0.0,
                "nse_delta_actual_minus_source": 0.0,
            },
            "3": {
                "target_count": 712,
                "mse_delta_actual_minus_source": 0.0,
                "nse_delta_actual_minus_source": 0.0,
            },
        }
    }
    assert (
        ENTRY._assert_metric_portability(
            metric_evidence,
            contract,
            boundary="epoch_000",
        )["status"]
        == "CROSS_DEVICE_PORTABILITY_PASS"
    )
    with pytest.raises(RuntimeError, match="development metric error"):
        changed = copy.deepcopy(metric_evidence)
        changed["per_lead"]["3"]["nse_delta_actual_minus_source"] = 3.0000001e-9
        ENTRY._assert_metric_portability(
            changed,
            contract,
            boundary="epoch_000",
        )


def test_optimizer_restore_evidence_proves_state_load_without_new_step() -> None:
    torch = pytest.importorskip("torch")
    source_model = torch.nn.Linear(2, 1)
    source_optimizer = torch.optim.Adam(source_model.parameters(), lr=1.0e-3)
    source_model(torch.ones((1, 2))).sum().backward()
    source_optimizer.step()
    source_state = copy.deepcopy(source_optimizer.state_dict())

    restored_model = torch.nn.Linear(2, 1)
    restored_optimizer = torch.optim.Adam(restored_model.parameters(), lr=1.0e-3)
    restored_optimizer.load_state_dict(copy.deepcopy(source_state))
    evidence = ENTRY._optimizer_restore_evidence(
        restored_optimizer,
        source_state,
        torch,
    )

    assert evidence["loaded_state_entry_count"] == 2
    assert evidence["source_state_entry_count"] == 2
    assert evidence["loaded_state_tensor_count"] == 6
    assert evidence["nonfinite_floating_tensor_count"] == 0
    assert evidence["optimizer_step_invocation_count"] == 0
    assert evidence["source_state_exact_after_device_normalization"] is True

    first_parameter_state = next(iter(restored_optimizer.state.values()))
    first_parameter_state["exp_avg"].add_(123.0)
    with pytest.raises(RuntimeError, match="tensor value changed"):
        ENTRY._optimizer_restore_evidence(
            restored_optimizer,
            source_state,
            torch,
        )


def test_portability_diagnostic_returns_before_every_optimizer_step_call() -> None:
    tree = ast.parse(ENTRY_PATH.read_text(encoding="utf-8"), filename=str(ENTRY_PATH))
    diagnostic_return_lines = [
        node.lineno
        for node in ast.walk(tree)
        if isinstance(node, ast.Return)
        and isinstance(node.value, ast.Dict)
        and any(
            isinstance(key, ast.Constant)
            and key.value == "status"
            and isinstance(value, ast.Constant)
            and value.value == "CROSS_DEVICE_PORTABILITY_DIAGNOSTIC_COMPLETE"
            for key, value in zip(node.value.keys, node.value.values)
        )
    ]
    optimizer_step_lines = [
        node.lineno
        for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "optimizer"
        and node.func.attr == "step"
    ]
    random_restore_lines = [
        node.lineno
        for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "_restore_checkpoint_random_states"
    ]

    assert len(diagnostic_return_lines) == 1
    assert optimizer_step_lines
    assert any(line < diagnostic_return_lines[0] for line in random_restore_lines)
    assert diagnostic_return_lines[0] < min(optimizer_step_lines)


def test_cross_device_diagnostic_records_per_lead_development_metric_deltas() -> None:
    source = {
        "mse_by_lead_after_warmup": {1: 6.9, 2: 7.8, 3: 8.9},
        "nse_by_lead_after_warmup": {1: 0.71, 2: 0.66, 3: 0.62},
        "target_count_by_lead_after_warmup": {1: 712, 2: 712, 3: 712},
    }

    evidence = ENTRY._development_metric_difference_evidence(
        _validation(),
        source,
        (1, 2, 3),
    )

    assert evidence["per_lead"]["1"]["mse_delta_actual_minus_source"] == (
        pytest.approx(0.1)
    )
    assert evidence["per_lead"]["3"]["nse_delta_actual_minus_source"] == (
        pytest.approx(-0.01)
    )
    changed_count = copy.deepcopy(source)
    changed_count["target_count_by_lead_after_warmup"][2] = 711
    with pytest.raises(RuntimeError, match="target count changed"):
        ENTRY._development_metric_difference_evidence(
            _validation(),
            changed_count,
            (1, 2, 3),
        )


def _validation() -> SimpleNamespace:
    return SimpleNamespace(
        full_objective_without_warmup=10.0,
        objective=8.0,
        mse_by_lead={1: 7.0, 2: 8.0, 3: 9.0},
        nse_by_lead={1: 0.7, 2: 0.65, 3: 0.61},
        target_count_by_lead={1: 712, 2: 712, 3: 712},
        full_target_count_by_lead_without_warmup={1: 728, 2: 728, 3: 728},
    )


def _same_segment_replay(
    before: float,
    after: float,
    *,
    step: int,
) -> dict[str, object]:
    return {
        "optimizer_step": step,
        "before_step_objective_physical_unit_multilead_mse": before,
        "after_step_objective_physical_unit_multilead_mse": after,
        "objective_improvement_before_minus_after": before - after,
        "strict_objective_decrease": after < before,
        "identical_target_geometry_before_after": True,
    }


def test_strict_zero_gain_comparison_has_explicit_per_lead_signs() -> None:
    strict_zero = SimpleNamespace(
        full_objective_without_warmup=12.0,
        mse_by_lead={1: 8.0, 2: 9.0, 3: 10.0},
        nse_by_lead={1: 0.60, 2: 0.55, 3: 0.50},
    )

    comparison = ENTRY._compare_score_to_strict_zero_gain(
        _validation(), strict_zero, (1, 2, 3)
    )

    assert comparison["checkpoint_objective_improvement_zero_minus_candidate"] == 2.0
    assert comparison["by_lead_712"][1][
        "mse_improvement_zero_minus_candidate"
    ] == 1.0
    assert comparison["by_lead_712"][1][
        "nse_delta_candidate_minus_zero"
    ] == pytest.approx(0.1)
    assert comparison["candidate_better_than_strict_zero_gain_each_lead"] is True

    degraded = _validation()
    degraded.mse_by_lead = {1: 7.0, 2: 8.0, 3: 11.0}
    degraded.nse_by_lead = {1: 0.70, 2: 0.65, 3: 0.49}
    degraded_comparison = ENTRY._compare_score_to_strict_zero_gain(
        degraded, strict_zero, (1, 2, 3)
    )
    assert degraded_comparison["by_lead_712"][3]["candidate_better"] is False
    assert (
        degraded_comparison["candidate_better_than_strict_zero_gain_each_lead"]
        is False
    )


def test_epoch_diagnostics_preserve_equal_lead_training_weights() -> None:
    diagnostics = ENTRY._summarize_epoch_training_diagnostics(
        {1: [1.0, 3.0], 2: [2.0, 6.0], 3: [4.0, 8.0]},
        {1: 204, 2: 200, 3: 190},
        gradient_clipped_optimizer_step_count=1,
        optimizer_step_count=2,
        same_segment_step_replays=(
            _same_segment_replay(4.0, 3.5, step=1),
            _same_segment_replay(8.0, 8.5, step=2),
        ),
    )

    assert diagnostics[
        "training_mse_by_lead_physical_unit_mean_over_optimizer_steps"
    ] == {1: 2.0, 2: 4.0, 3: 6.0}
    assert diagnostics["training_sampled_finite_target_event_count_by_lead"] == {
        1: 204,
        2: 200,
        3: 190,
    }
    assert diagnostics["epoch_optimizer_step_count"] == 2
    assert diagnostics["gradient_clipped_optimizer_step_count"] == 1
    assert diagnostics["gradient_clipped_optimizer_step_fraction"] == 0.5
    assert diagnostics["same_segment_post_step_replay_count"] == 2
    assert diagnostics["same_segment_strict_objective_decrease_count"] == 1
    assert diagnostics["same_segment_every_optimizer_step_strictly_decreased"] is False
    assert diagnostics["same_segment_before_step_objective_mean"] == 6.0
    assert diagnostics["same_segment_after_step_objective_mean"] == 6.0
    reconstructed = math.fsum(
        diagnostics[
            "training_mse_by_lead_physical_unit_mean_over_optimizer_steps"
        ].values()
    ) / 3
    assert reconstructed == 4.0


def test_epoch_zero_uses_explicit_no_training_sentinels() -> None:
    diagnostics = ENTRY._summarize_epoch_training_diagnostics(
        {1: (), 2: (), 3: ()},
        {1: 0, 2: 0, 3: 0},
        gradient_clipped_optimizer_step_count=0,
        optimizer_step_count=0,
    )

    assert diagnostics[
        "training_mse_by_lead_physical_unit_mean_over_optimizer_steps"
    ] is None
    assert diagnostics["training_sampled_finite_target_event_count_by_lead"] == {
        1: 0,
        2: 0,
        3: 0,
    }
    assert diagnostics["epoch_optimizer_step_count"] == 0
    assert diagnostics["gradient_clipped_optimizer_step_count"] == 0
    assert diagnostics["gradient_clipped_optimizer_step_fraction"] is None
    assert diagnostics["same_segment_post_step_replay_count"] == 0
    assert diagnostics["same_segment_every_optimizer_step_strictly_decreased"] is None
    assert diagnostics["same_segment_before_step_objective_mean"] is None
    assert diagnostics["same_segment_after_step_objective_mean"] is None

    row = ENTRY._history_row(
        epoch=0,
        training_objective=None,
        validation=_validation(),
        parameter_sha256="0" * 64,
        optimizer_steps=0,
        forecast_events=0,
        gradient_names=(),
        maximum_gradient_norm_before_clip=None,
        training_diagnostics=diagnostics,
        prediction_sha256="1" * 64,
    )
    assert row["training_objective_physical_unit_multilead_mse"] is None
    assert row[
        "training_mse_by_lead_physical_unit_mean_over_optimizer_steps"
    ] is None
    assert row["training_sampled_finite_target_event_count_by_lead"] == {
        1: 0,
        2: 0,
        3: 0,
    }
    assert row["epoch_optimizer_step_count"] == 0
    assert row["finite_gradients"] is None

    event = ENTRY._epoch_completed_event(
        epoch=0,
        training_objective=None,
        checkpoint_selection_objective=10.0,
        gate_objective=8.0,
        checkpoint_sha256="4" * 64,
        parameter_sha256="0" * 64,
        optimizer_steps=0,
        sampled_forecast_events=0,
        training_diagnostics=diagnostics,
    )
    assert event["training_objective"] is None
    assert event["optimizer_steps"] == 0
    assert event["sampled_forecast_events"] == 0
    assert event["epoch_optimizer_step_count"] == 0


@pytest.mark.parametrize(
    ("mse_by_lead", "counts", "clipped", "steps", "expected_exception"),
    [
        ({1: [float("nan")], 2: [1.0], 3: [1.0]}, {1: 1, 2: 1, 3: 1}, 0, 1, ValueError),
        ({1: [1.0], 2: [1.0], 3: [1.0]}, {1: -1, 2: 1, 3: 1}, 0, 1, ValueError),
        ({1: [1.0], 2: [1.0], 3: [1.0]}, {1: 1, 2: 1, 3: 1}, 2, 1, ValueError),
        ({1: [1.0], 2: [1.0], 3: []}, {1: 1, 2: 1, 3: 1}, 0, 1, ValueError),
    ],
)
def test_epoch_diagnostics_reject_invalid_evidence(
    mse_by_lead: dict[int, list[float]],
    counts: dict[int, int],
    clipped: int,
    steps: int,
    expected_exception: type[Exception],
) -> None:
    with pytest.raises(expected_exception):
        ENTRY._summarize_epoch_training_diagnostics(
            mse_by_lead,
            counts,
            gradient_clipped_optimizer_step_count=clipped,
            optimizer_step_count=steps,
        )


def test_history_row_records_complete_training_diagnostics() -> None:
    diagnostics = ENTRY._summarize_epoch_training_diagnostics(
        {1: [1.0, 5.0], 2: [2.0, 4.0], 3: [3.0, 3.0]},
        {1: 204, 2: 204, 3: 204},
        gradient_clipped_optimizer_step_count=1,
        optimizer_step_count=2,
        same_segment_step_replays=(
            _same_segment_replay(3.0, 2.0, step=1),
            _same_segment_replay(4.0, 3.0, step=2),
        ),
    )
    row = ENTRY._history_row(
        epoch=1,
        training_objective=3.0,
        validation=_validation(),
        parameter_sha256="2" * 64,
        optimizer_steps=2,
        forecast_events=612,
        gradient_names=("gain.weight",),
        maximum_gradient_norm_before_clip=12.0,
        training_diagnostics=diagnostics,
        prediction_sha256="3" * 64,
    )

    assert row[
        "training_mse_by_lead_physical_unit_mean_over_optimizer_steps"
    ] == {1: 3.0, 2: 3.0, 3: 3.0}
    assert row["training_sampled_finite_target_event_count_by_lead"] == {
        1: 204,
        2: 204,
        3: 204,
    }
    assert row["epoch_optimizer_step_count"] == 2
    assert row["gradient_clipped_optimizer_step_count"] == 1
    assert row["gradient_clipped_optimizer_step_fraction"] == 0.5
    assert row["optimizer_steps"] == 2
    assert row["sampled_forecast_events"] == 612

    event = ENTRY._epoch_completed_event(
        epoch=1,
        training_objective=3.0,
        checkpoint_selection_objective=9.0,
        gate_objective=7.0,
        checkpoint_sha256="5" * 64,
        parameter_sha256="2" * 64,
        optimizer_steps=2,
        sampled_forecast_events=612,
        training_diagnostics=diagnostics,
    )
    assert set(event) == {
        "event_type",
        "epoch",
        "training_objective",
        "checkpoint_selection_objective_728",
        "gate_objective_712",
        "checkpoint_sha256",
        "parameter_sha256",
        "optimizer_steps",
        "sampled_forecast_events",
        "training_mse_by_lead_physical_unit_mean_over_optimizer_steps",
        "training_sampled_finite_target_event_count_by_lead",
        "epoch_optimizer_step_count",
        "gradient_clipped_optimizer_step_count",
        "gradient_clipped_optimizer_step_fraction",
        "same_segment_post_step_replay_count",
        "same_segment_strict_objective_decrease_count",
        "same_segment_every_optimizer_step_strictly_decreased",
        "same_segment_before_step_objective_mean",
        "same_segment_after_step_objective_mean",
        "same_segment_objective_improvement_mean_before_minus_after",
        "same_segment_step_replays",
    }


def test_same_segment_post_step_evidence_uses_identical_forecast_targets() -> None:
    class FakeObservations:
        def __getitem__(self, key):
            indices, column = key
            assert column == 0
            return list(indices)

    class FakeFinite:
        def __init__(self, count: int) -> None:
            self.count = count

        def detach(self):
            return self

        def cpu(self):
            return self

        def tolist(self):
            return [True] * self.count

    fake_torch = SimpleNamespace(isfinite=lambda values: FakeFinite(len(values)))
    runtime = SimpleNamespace(
        training_days=2557,
        observations=FakeObservations(),
        dates=[f"day-{index}" for index in range(2557)],
    )
    before = SimpleNamespace(
        objective=4.0,
        mse_by_lead={1: 3.0, 2: 4.0, 3: 5.0},
        target_count_by_lead={1: 102, 2: 102, 3: 102},
    )
    after = SimpleNamespace(
        objective=3.0,
        mse_by_lead={1: 2.0, 2: 3.0, 3: 4.0},
        target_count_by_lead={1: 102, 2: 102, 3: 102},
    )

    evidence = ENTRY._same_segment_step_replay_evidence(
        before_step=before,
        after_step=after,
        runtime=runtime,
        start=1849,
        segment_days=150,
        filter_warmup_days=45,
        leads=(1, 2, 3),
        optimizer_step=1,
        torch_module=fake_torch,
    )

    assert evidence["segment_start_index_global_inclusive"] == 1849
    assert evidence["segment_end_index_global_exclusive"] == 1999
    assert evidence["scored_issue_first_date"] == "day-1894"
    assert evidence["scored_issue_last_date"] == "day-1995"
    assert evidence["strict_objective_decrease"] is True
    assert evidence["objective_improvement_before_minus_after"] == 1.0
    assert evidence["target_count_by_lead_before_step"] == {1: 102, 2: 102, 3: 102}
    assert evidence["target_count_by_lead_after_step"] == {1: 102, 2: 102, 3: 102}
    assert evidence["after_step_was_recomputed"] is True
    assert evidence["after_step_recomputed_under_no_grad"] is True
    assert evidence["reserved_evaluation_values_used"] == 0
    assert len(
        evidence["target_geometry_by_lead"][1]["target_index_sha256"]
    ) == 64


@pytest.mark.parametrize(
    ("key", "value", "expected_exception"),
    [
        ("training_epochs", 0, ValueError),
        ("training_epochs", True, ValueError),
        ("steps_per_epoch", 0, ValueError),
        ("learning_rate", 0.0, ValueError),
        ("learning_rate", float("nan"), ValueError),
        ("gradient_maximum_norm", 0.0, ValueError),
        ("gradient_maximum_norm", float("inf"), ValueError),
        ("gradient_maximum_norm", "10", TypeError),
    ],
)
def test_training_hyperparameters_fail_closed_before_numerical_imports(
    key: str,
    value: object,
    expected_exception: type[Exception],
) -> None:
    optimization: dict[str, object] = {
        "training_epochs": 2,
        "steps_per_epoch": 32,
        "learning_rate": 0.01,
        "gradient_maximum_norm": 10.0,
    }
    optimization[key] = value

    with pytest.raises(expected_exception):
        ENTRY._validate_training_hyperparameters(optimization)


def test_training_hyperparameters_accept_positive_finite_values() -> None:
    ENTRY._validate_training_hyperparameters(
        {
            "training_epochs": 2,
            "steps_per_epoch": 32,
            "learning_rate": 0.01,
            "gradient_maximum_norm": 10.0,
        }
    )


def test_fixed_full_training_coverage_plan_is_exact_and_complete() -> None:
    config = json.loads(
        (
            ROOT
            / "configs"
            / "daily_camels_knet_fixed_full_training_coverage_accumulation_a15.json"
        ).read_text(encoding="utf-8")
    )

    plan = ENTRY._configured_training_segment_plan(
        config["optimization"],
        training_days=2557,
        leads=(1, 2, 3),
    )

    assert plan["fixed_training_segment_start_indices"] == [
        0,
        100,
        201,
        301,
        401,
        501,
        602,
        702,
        802,
        903,
        1003,
        1103,
        1204,
        1304,
        1404,
        1504,
        1605,
        1705,
        1805,
        1906,
        2006,
        2106,
        2206,
        2307,
        2407,
    ]
    assert plan["minimum_segment_count_for_complete_coverage"] == 25
    assert plan["complete_eligible_issue_coverage"] is True
    assert plan["candidate_issue_count"] == 2550
    assert plan["unique_covered_issue_count"] == 2509
    assert plan["duplicate_issue_count"] == 41
    assert plan["uncovered_issue_count"] == 0
    assert plan["candidate_forecast_target_event_count_all_leads"] == 7650
    assert plan["total_candidate_forecast_target_event_count_all_epochs"] == 7650
    assert plan["expected_optimizer_step_count"] == 1
    assert plan["maximum_issue_multiplicity"] == 2
    assert len(plan["fixed_training_segment_start_indices_sha256"]) == 64
    assert len(plan["issue_multiplicity_sha256"]) == 64


@pytest.mark.parametrize(
    ("mutation", "expected_exception"),
    [
        ({"segments_per_optimizer_step": 24}, ValueError),
        ({"steps_per_epoch": 2}, ValueError),
        ({"fixed_training_segment_start_indices": [0, 1]}, ValueError),
        ({"training_segment_sampling": "unsupported"}, ValueError),
    ],
)
def test_fixed_training_coverage_contract_fails_closed(
    mutation: dict[str, object],
    expected_exception: type[Exception],
) -> None:
    config = json.loads(
        (
            ROOT
            / "configs"
            / "daily_camels_knet_fixed_full_training_coverage_accumulation_a15.json"
        ).read_text(encoding="utf-8")
    )
    config["optimization"].update(mutation)

    with pytest.raises(expected_exception):
        ENTRY._configured_training_segment_plan(
            config["optimization"],
            training_days=2557,
            leads=(1, 2, 3),
        )


def test_fixed_full_training_coverage_repeats_one_averaged_update_per_epoch() -> None:
    config = json.loads(
        (
            ROOT
            / "configs"
            / "daily_camels_knet_fixed_full_training_coverage_accumulation_a15.json"
        ).read_text(encoding="utf-8")
    )
    config["optimization"]["training_epochs"] = 10

    plan = ENTRY._configured_training_segment_plan(
        config["optimization"],
        training_days=2557,
        leads=(1, 2, 3),
    )

    assert plan["training_epochs"] == 10
    assert plan["steps_per_epoch"] == 1
    assert plan["expected_optimizer_step_count"] == 10
    assert plan["candidate_forecast_target_event_count_all_leads"] == 7650
    assert plan["total_candidate_forecast_target_event_count_all_epochs"] == 76500
    assert plan["complete_eligible_issue_coverage"] is True


def _training_segment_replay(
    *,
    start: int,
    before: float,
    after: float,
) -> dict[str, object]:
    return {
        "optimizer_step": 1,
        "segment_start_index_global_inclusive": start,
        "before_step_objective_physical_unit_multilead_mse": before,
        "after_step_objective_physical_unit_multilead_mse": after,
        "objective_improvement_before_minus_after": before - after,
        "strict_objective_decrease": after < before,
        "mse_by_lead_before_step": {
            1: before - 1.0,
            2: before,
            3: before + 1.0,
        },
        "mse_by_lead_after_step": {
            1: after - 1.0,
            2: after,
            3: after + 1.0,
        },
        "target_count_by_lead_before_step": {1: 102, 2: 102, 3: 102},
        "target_count_by_lead_after_step": {1: 102, 2: 102, 3: 102},
        "target_geometry_by_lead": {
            lead: {"start": start, "lead": lead} for lead in (1, 2, 3)
        },
        "identical_target_geometry_before_after": True,
        "after_step_was_recomputed": True,
        "after_step_recomputed_under_no_grad": True,
        "reserved_evaluation_values_used": 0,
    }


def test_multi_segment_replay_is_one_optimizer_step_with_aggregate_gate() -> None:
    evidence = ENTRY._same_training_batch_step_replay_evidence(
        (
            _training_segment_replay(start=0, before=4.0, after=3.0),
            _training_segment_replay(start=100, before=6.0, after=7.0),
        ),
        optimizer_step=1,
    )

    assert evidence["optimizer_step"] == 1
    assert evidence["training_segment_count"] == 2
    assert evidence["training_segment_start_indices"] == [0, 100]
    assert evidence["before_step_objective_physical_unit_multilead_mse"] == 5.0
    assert evidence["after_step_objective_physical_unit_multilead_mse"] == 5.0
    assert evidence["strict_objective_decrease"] is False
    assert evidence["training_segment_strict_objective_decrease_count"] == 1
    assert evidence["every_training_segment_strictly_decreased"] is False
    assert evidence["target_count_by_lead_before_step"] == {
        1: 204,
        2: 204,
        3: 204,
    }
    assert len(evidence["training_segment_replays"]) == 2

    diagnostics = ENTRY._summarize_epoch_training_diagnostics(
        {1: [4.0], 2: [5.0], 3: [6.0]},
        {1: 204, 2: 204, 3: 204},
        gradient_clipped_optimizer_step_count=0,
        optimizer_step_count=1,
        same_segment_step_replays=(evidence,),
    )
    assert diagnostics["same_segment_post_step_replay_count"] == 1
    assert diagnostics["epoch_optimizer_step_count"] == 1


def test_epoch_zero_reproducibility_anchor_fails_closed() -> None:
    configuration = {
        "epoch_zero_reproducibility": {
            "checkpoint_objective_728": 0.4,
            "parameter_sha256": "a" * 64,
            "prediction_sha256": "b" * 64,
        }
    }
    evidence = ENTRY._epoch_zero_reproducibility_evidence(
        configuration,
        objective=0.4,
        parameter_sha256="a" * 64,
        prediction_sha256="b" * 64,
    )
    assert evidence["status"] == "PASS"

    with pytest.raises(RuntimeError, match="objective"):
        ENTRY._epoch_zero_reproducibility_evidence(
            configuration,
            objective=0.41,
            parameter_sha256="a" * 64,
            prediction_sha256="b" * 64,
        )
    with pytest.raises(RuntimeError, match="parameter_sha256"):
        ENTRY._epoch_zero_reproducibility_evidence(
            configuration,
            objective=0.4,
            parameter_sha256="c" * 64,
            prediction_sha256="b" * 64,
        )


def test_epoch_zero_reproducibility_failure_preserves_all_actual_values() -> None:
    configuration = {
        "epoch_zero_reproducibility": {
            "checkpoint_objective_728": 0.4,
            "parameter_sha256": "a" * 64,
            "prediction_sha256": "b" * 64,
        }
    }

    with pytest.raises(RuntimeError) as captured:
        ENTRY._epoch_zero_reproducibility_evidence(
            configuration,
            objective=0.400000000002,
            parameter_sha256="c" * 64,
            prediction_sha256="d" * 64,
        )

    message = str(captured.value)
    assert '"actual_objective":0.400000000002' in message
    assert '"expected_objective":0.4' in message
    assert '"absolute_objective_delta":' in message
    assert f'"actual_parameter_sha256":"{"c" * 64}"' in message
    assert f'"expected_parameter_sha256":"{"a" * 64}"' in message
    assert f'"actual_prediction_sha256":"{"d" * 64}"' in message
    assert f'"expected_prediction_sha256":"{"b" * 64}"' in message


def test_a37_continuation_is_one_factor_extension_of_a16() -> None:
    source = json.loads(A16_CONFIG.read_text(encoding="utf-8"))
    continuation = json.loads(A37_CONFIG.read_text(encoding="utf-8"))

    ENTRY._assert_one_factor_continuation(source, continuation)

    changed = json.loads(json.dumps(continuation))
    changed["optimization"]["learning_rate"] = 0.0004
    with pytest.raises(ValueError, match="one-factor"):
        ENTRY._assert_one_factor_continuation(source, changed)


def test_a37_requires_the_explicit_pinned_epoch_ten_checkpoint() -> None:
    configuration = json.loads(A37_CONFIG.read_text(encoding="utf-8"))

    with pytest.raises(ValueError, match="--resume"):
        ENTRY._continuation_spec(configuration, ROOT, None)

    spec = ENTRY._continuation_spec(
        configuration,
        ROOT,
        A16_EPOCH_TEN_CHECKPOINT,
    )
    assert spec is not None
    assert spec.completed_epoch == 10
    assert spec.optimizer_steps == 10
    assert spec.sampled_forecast_events == 76_500
    assert spec.checkpoint_sha256 == (
        "b2b93f531c7ad4922e14d5479564e82e5a6dca553835bbc8cc8af61db4a8d81e"
    )

    with pytest.raises(ValueError, match="pinned path"):
        ENTRY._continuation_spec(configuration, ROOT, A16_CONFIG)


def test_a37_standard_library_probe_records_exact_continuation(
    tmp_path: Path,
) -> None:
    completed = subprocess.run(
        [
            sys.executable,
            str(ENTRY_PATH),
            "--phase",
            "probe",
            "--config",
            str(A37_CONFIG),
            "--resume",
            str(A16_EPOCH_TEN_CHECKPOINT),
            "--run-parent",
            str(tmp_path),
            "--device",
            "cpu",
        ],
        check=False,
        capture_output=True,
        text=True,
    )
    assert completed.returncode == 0, completed.stderr
    preflight = json.loads(completed.stdout)

    assert preflight["continuation"]["completed_epoch"] == 10
    assert preflight["continuation"]["source_device"] == "cuda"
    assert preflight["continuation"]["checkpoint_sha256"] == (
        "b2b93f531c7ad4922e14d5479564e82e5a6dca553835bbc8cc8af61db4a8d81e"
    )
    assert "checkpoint_path" in preflight["continuation"]
    assert not Path(preflight["continuation"]["checkpoint_path"]).is_absolute()


def test_a37_actual_checkpoint_payload_passes_validation_in_cpu_subprocess() -> None:
    program = f"""
import importlib.util
import json
from pathlib import Path
import sys

root = Path({str(ROOT)!r})
entry_path = Path({str(ENTRY_PATH)!r})
specification = importlib.util.spec_from_file_location('a37_payload_audit', entry_path)
assert specification is not None and specification.loader is not None
entry = importlib.util.module_from_spec(specification)
sys.modules[specification.name] = entry
specification.loader.exec_module(entry)
import torch
configuration = json.loads(Path({str(A37_CONFIG)!r}).read_text(encoding='utf-8'))
checkpoint = Path({str(A16_EPOCH_TEN_CHECKPOINT)!r})
continuation = entry._continuation_spec(configuration, root, checkpoint)
payload = torch.load(checkpoint, map_location='cpu', weights_only=False)
entry._validate_continuation_payload(payload, continuation)
assert len(payload['history']) == 11
assert payload['best_epoch'] == 10
"""
    completed = subprocess.run(
        [sys.executable, "-I", "-c", program],
        check=False,
        capture_output=True,
        text=True,
    )
    assert completed.returncode == 0, completed.stderr


def test_continuation_training_path_restores_state_and_skips_completed_epochs() -> None:
    tree = ast.parse(ENTRY_PATH.read_text(encoding="utf-8"), filename=str(ENTRY_PATH))
    function = next(
        node
        for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "execute_training"
    )
    called_names = {
        node.func.id
        for node in ast.walk(function)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
    }
    called_attributes = {
        (
            node.func.value.id,
            node.func.attr,
        )
        for node in ast.walk(function)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and isinstance(node.func.value, ast.Name)
    }

    assert {
        "_load_continuation_payload",
        "_restore_checkpoint_random_states",
        "_continuation_epoch_range",
    }.issubset(called_names)
    assert ("net", "load_state_dict") in called_attributes
    assert ("optimizer", "load_state_dict") in called_attributes


def test_continuation_execution_rejects_a_device_change_before_output() -> None:
    preflight = SimpleNamespace(
        continuation=SimpleNamespace(source_device="cuda"),
    )
    with pytest.raises(ValueError, match="source_device"):
        ENTRY._execute_numerical(preflight, {}, device="cpu")


def _valid_continuation_payload() -> tuple[dict[str, object], object]:
    identity = {
        "schema_version": "daily_camels_ukf_knet_parity_run_identity_v1",
        "experiment_id": (
            "DAILY_CAMELS_KNET_FIXED_FULL_TRAINING_COVERAGE_TEN_EPOCH_"
            "V1_20260825_A16"
        ),
        "configuration_sha256": (
            "d8d3bf5275c1c509ce6591cd1c6d8c164e512f81e04d9ed1916262a2f3a5f22a"
        ),
        "source_sha256": {},
        "input_sha256": {},
        "initialization_mode": "causal_shared_spinup",
        "gain_initialization": "near_zero_fc2_head",
        "correction_scope": "full_eighteen_dimensional_state_correction",
        "phase": "train",
    }
    identity_sha256 = ENTRY.sha256(ENTRY.canonical_json_bytes(identity)).hexdigest()
    history = []
    for epoch in range(11):
        history.append(
            {
                "epoch": epoch,
                "optimizer_steps": epoch,
                "sampled_forecast_events": epoch * 7_650,
                "parameter_sha256": (
                    "c1597f7f1c5c30a6c12ce05e27dc6a45d0b9dd330422fed07a3346b0430cfbca"
                    if epoch == 10
                    else f"{epoch:x}" * 64
                ),
                "checkpoint_selection_objective_728_origins_without_warmup": (
                    0.07951907715501967 if epoch == 10 else 0.4 - epoch * 0.02
                ),
                "same_segment_step_replays": (
                    [] if epoch == 0 else [{"strict_objective_decrease": True}]
                ),
            }
        )
    payload: dict[str, object] = {
        "schema_version": "daily_camels_ukf_knet_parity_checkpoint_v1",
        "identity": identity,
        "identity_sha256": identity_sha256,
        "gain_initialization": "near_zero_fc2_head",
        "correction_scope": "full_eighteen_dimensional_state_correction",
        "completed_epoch": 10,
        "model_state": {},
        "optimizer_state": {},
        "history": history,
        "best_epoch": 10,
        "best_checkpoint_selection_objective": 0.07951907715501967,
        "best_model_state": {},
        "optimizer_steps": 10,
        "sampled_forecast_events": 76_500,
        "nonzero_gradient_parameter_names": ["FC1.0.weight"],
        "python_random_state": object(),
        "numpy_random_state": object(),
        "torch_cpu_random_state": object(),
        "torch_cuda_random_states": [],
        "sampler_generator_state": object(),
        "access_ledger": {"evaluation_array_reads": 0},
        "previous_checkpoint_sha256": "f" * 64,
    }
    spec = SimpleNamespace(
        source_experiment_id=identity["experiment_id"],
        source_identity_sha256=identity_sha256,
        source_configuration_sha256=identity["configuration_sha256"],
        completed_epoch=10,
        optimizer_steps=10,
        sampled_forecast_events=76_500,
        parameter_sha256=history[-1]["parameter_sha256"],
    )
    return payload, spec


@pytest.mark.parametrize(
    ("field", "changed"),
    [
        ("identity_sha256", "1" * 64),
        ("completed_epoch", 9),
        ("optimizer_steps", 9),
        ("sampled_forecast_events", 70_000),
    ],
)
def test_continuation_payload_identity_and_progress_fail_closed(
    field: str,
    changed: object,
) -> None:
    payload, spec = _valid_continuation_payload()
    ENTRY._validate_continuation_payload(payload, spec)

    payload[field] = changed
    with pytest.raises((ValueError, RuntimeError), match=field):
        ENTRY._validate_continuation_payload(payload, spec)


def test_continuation_payload_last_parameter_hash_fails_closed() -> None:
    payload, spec = _valid_continuation_payload()
    payload["history"][-1]["parameter_sha256"] = "2" * 64

    with pytest.raises(RuntimeError, match="parameter_sha256"):
        ENTRY._validate_continuation_payload(payload, spec)


def test_continuation_payload_requires_best_checkpoint_at_source_boundary() -> None:
    payload, spec = _valid_continuation_payload()
    payload["best_epoch"] = 9

    with pytest.raises(RuntimeError, match="best_epoch"):
        ENTRY._validate_continuation_payload(payload, spec)


def test_continuation_epoch_range_begins_after_the_source_checkpoint() -> None:
    assert list(ENTRY._continuation_epoch_range(10, 40)) == list(range(11, 41))
    with pytest.raises(ValueError, match="greater"):
        ENTRY._continuation_epoch_range(10, 10)
