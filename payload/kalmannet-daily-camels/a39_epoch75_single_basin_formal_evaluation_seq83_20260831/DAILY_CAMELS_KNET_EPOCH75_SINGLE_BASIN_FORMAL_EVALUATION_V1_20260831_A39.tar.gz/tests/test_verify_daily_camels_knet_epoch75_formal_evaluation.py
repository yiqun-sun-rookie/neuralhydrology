from __future__ import annotations

from hashlib import sha256
import importlib.util
import json
import math
from pathlib import Path
import sys
from typing import Any

import numpy as np
import pytest


ROOT = Path(__file__).resolve().parents[1]
VERIFIER_PATH = (
    ROOT / "scripts" / "verify_daily_camels_knet_epoch75_formal_evaluation.py"
)
FROZEN_CONFIG_PATH = (
    ROOT / "configs" / "daily_camels_knet_epoch75_formal_evaluation_a39.json"
)


def _load_verifier():
    spec = importlib.util.spec_from_file_location("a39_independent_verifier", VERIFIER_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load A39 independent verifier")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


VERIFY = _load_verifier()


def _json_bytes(payload: Any) -> bytes:
    return (
        json.dumps(
            payload,
            indent=2,
            sort_keys=True,
            ensure_ascii=False,
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")


def _write_json(path: Path, payload: Any) -> None:
    path.write_bytes(_json_bytes(payload))


def _file_sha256(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def _semantic_sha256(arrays: dict[str, np.ndarray]) -> str:
    digest = sha256()
    for name in sorted(arrays):
        array = np.ascontiguousarray(np.asarray(arrays[name]))
        digest.update(name.encode("utf-8"))
        digest.update(str(array.dtype).encode("ascii"))
        digest.update(np.asarray(array.shape, dtype=np.int64).tobytes())
        digest.update(array.tobytes())
    return digest.hexdigest()


def _nse(prediction: np.ndarray, target: np.ndarray, mask: np.ndarray) -> float:
    error = prediction[mask] - target[mask]
    return 1.0 - float(np.mean(np.square(error))) / float(
        np.var(target[mask], ddof=0)
    )


def _synthetic_arrays(*, candidate_offset: float = 0.20) -> dict[str, np.ndarray]:
    count = 3652
    dates = np.datetime64("1989-10-01", "ns") + np.arange(count).astype(
        "timedelta64[D]"
    )
    target = 3.0 + np.sin(np.arange(count, dtype=np.float64) / 19.0)
    forcing = np.column_stack(
        (
            np.arange(count, dtype=np.float64),
            np.ones(count, dtype=np.float64),
            np.full(count, 2.0, dtype=np.float64),
        )
    )
    offsets = {
        "knet_epoch75": candidate_offset,
        "strict_zero_gain_knet": 0.50,
        "same_forcing_open_loop": 0.50,
        "default_noise_ukf": 0.25,
        "sampled_search_ukf": 0.24,
        "backpropagation_selected_ukf": 0.23,
        "persistence": 0.70,
        "second_order_autoregression": 0.60,
    }
    arrays: dict[str, np.ndarray] = {
        "dates_ns": dates.astype(np.int64),
        "target": target,
        "forcing": forcing,
    }
    for lead in VERIFY.LEADS:
        for system, offset in offsets.items():
            arrays[f"{system}_lead_{lead}"] = target + offset * lead
        arrays[f"common_mask_lead_{lead}"] = np.ones(count, dtype=bool)
        target_start = VERIFY.WARMUP_DAYS + lead
        target_end = count - max(VERIFY.LEADS) + lead
        arrays[f"common_mask_lead_{lead}"][:target_start] = False
        arrays[f"common_mask_lead_{lead}"][target_end:] = False
    return arrays


def _test_config() -> dict[str, Any]:
    return json.loads(FROZEN_CONFIG_PATH.read_text(encoding="utf-8"))


def _reported_payloads(
    config_path: Path,
    output_root: Path,
    arrays: dict[str, np.ndarray],
) -> tuple[dict[str, Any], dict[str, Any]]:
    recomputed = VERIFY.recompute_from_arrays(arrays)
    prediction_path = output_root / VERIFY.PREDICTIONS_FILE
    np.savez(prediction_path, **arrays)
    ledger = {
        "schema_version": VERIFY.ACCESS_LEDGER_SCHEMA_VERSION,
        "experiment_id": VERIFY.EXPERIMENT_ID,
        "evaluation_archive": {
            "open_count": 1,
            "authorized_read_count": 1,
            "array_reads": {"dates_ns": 1, "forcing": 1, "target": 1},
        },
        "stored_baseline_prediction_reads": 0,
        "optimizer_steps": 0,
        "training_events": 0,
        "checkpoint_writes": 0,
        "parameter_sha256_before": VERIFY.PARAMETER_SHA256,
        "parameter_sha256_after": VERIFY.PARAMETER_SHA256,
    }
    ledger_path = output_root / VERIFY.ACCESS_LEDGER_FILE
    _write_json(ledger_path, ledger)
    config = json.loads(config_path.read_text(encoding="utf-8"))
    summary = {
        "schema_version": VERIFY.RESULT_SCHEMA_VERSION,
        "experiment_id": VERIFY.EXPERIMENT_ID,
        "status": VERIFY.RESULT_STATUS,
        "scientific_role": VERIFY.SCIENTIFIC_ROLE,
        "basin_id": VERIFY.BASIN_ID,
        "evaluation_period_role": VERIFY.EVALUATION_PERIOD_ROLE,
        "evaluation_period": list(VERIFY.EVALUATION_PERIOD),
        "warmup_days": VERIFY.WARMUP_DAYS,
        "leads_days": list(VERIFY.LEADS),
        "systems": list(VERIFY.SYSTEMS),
        "checkpoint": {
            "path": VERIFY.CHECKPOINT_PATH,
            "epoch": VERIFY.CHECKPOINT_EPOCH,
            "file_sha256": VERIFY.CHECKPOINT_SHA256,
            "parameter_sha256": VERIFY.PARAMETER_SHA256,
        },
        "configuration": {
            "path": str(config_path),
            "sha256": _file_sha256(config_path),
        },
        "inputs": config["inputs"],
        "predictions": {
            "path": VERIFY.PREDICTIONS_FILE,
            "file_sha256": _file_sha256(prediction_path),
            "semantic_sha256": _semantic_sha256(arrays),
        },
        "metrics": recomputed["metrics"],
        "comparisons": recomputed["comparisons"],
        "decisions": recomputed["decisions"],
        "access_ledger_sha256": _file_sha256(ledger_path),
        "manifest_members_expected": list(VERIFY.MANIFEST_MEMBER_FILES),
    }
    return summary, ledger


def _make_synthetic_run(
    tmp_path: Path, *, candidate_offset: float = 0.20
) -> tuple[Path, Path, Path]:
    config_path = tmp_path / "config.json"
    _write_json(config_path, _test_config())
    output_root = tmp_path / "evaluation"
    output_root.mkdir()
    arrays = _synthetic_arrays(candidate_offset=candidate_offset)
    summary, _ = _reported_payloads(config_path, output_root, arrays)
    summary_path = output_root / VERIFY.RESULT_SUMMARY_FILE
    _write_json(summary_path, summary)
    manifest = {
        "schema_version": VERIFY.MANIFEST_SCHEMA_VERSION,
        "experiment_id": VERIFY.EXPERIMENT_ID,
        "status": VERIFY.RESULT_STATUS,
        "configuration_sha256": _file_sha256(config_path),
        "files": {
            name: _file_sha256(output_root / name)
            for name in VERIFY.MANIFEST_MEMBER_FILES
        },
    }
    _write_json(output_root / VERIFY.MANIFEST_FILE, manifest)
    verification_output = tmp_path / "verification" / "independent_verification.json"
    return config_path, output_root, verification_output


def test_recompute_rebuilds_one_common_mask_and_population_nse() -> None:
    arrays = _synthetic_arrays()
    excluded = VERIFY.WARMUP_DAYS + 7
    arrays["target"][excluded] = np.nan
    arrays["sampled_search_ukf_lead_1"][excluded + 1] = np.nan
    for lead in VERIFY.LEADS:
        arrays[f"common_mask_lead_{lead}"][excluded] = False
    arrays["common_mask_lead_1"][excluded + 1] = False

    result = VERIFY.recompute_from_arrays(arrays)

    expected_mask = arrays["common_mask_lead_1"]
    expected_nse = _nse(arrays["knet_epoch75_lead_1"], arrays["target"], expected_mask)
    assert result["metrics"]["target_count_by_lead"]["1"] == int(
        expected_mask.sum()
    )
    assert result["metrics"]["nse_by_system_and_lead"]["knet_epoch75"][
        "1"
    ] == pytest.approx(expected_nse, abs=1e-15)
    assert result["metrics"]["mse_by_system_and_lead"]["knet_epoch75"][
        "1"
    ] == pytest.approx(0.20**2, abs=1e-15)


def test_recompute_uses_one_common_issue_window_for_all_leads() -> None:
    arrays = _synthetic_arrays()
    result = VERIFY.recompute_from_arrays(arrays)

    assert result["metrics"]["target_count_by_lead"] == {
        "1": VERIFY.NOMINAL_COMMON_ISSUE_COUNT,
        "2": VERIFY.NOMINAL_COMMON_ISSUE_COUNT,
        "3": VERIFY.NOMINAL_COMMON_ISSUE_COUNT,
    }
    geometry = result["metrics"]["common_issue_geometry"]
    assert geometry["issue_start_index_inclusive"] == VERIFY.WARMUP_DAYS
    assert geometry["issue_end_index_exclusive"] == VERIFY.EXPECTED_DAYS - 3
    assert geometry["target_index_interval_by_lead"] == {
        "1": {"start_inclusive": 366, "end_exclusive": 3650},
        "2": {"start_inclusive": 367, "end_exclusive": 3651},
        "3": {"start_inclusive": 368, "end_exclusive": 3652},
    }


def test_independent_verifier_rejects_prediction_changing_config_drift() -> None:
    config = _test_config()
    config["model"]["normalized_feature_guard"] = 9.0
    with pytest.raises(RuntimeError, match="model.normalized_feature_guard"):
        VERIFY._validate_frozen_config(config)

    config = _test_config()
    config["ukf"]["default_noise"]["r_b"] = 0.03
    with pytest.raises(RuntimeError, match="ukf.default_noise.r_b"):
        VERIFY._validate_frozen_config(config)


def test_independent_verification_accepts_scientific_hold_with_exit_success(
    tmp_path: Path,
) -> None:
    config_path, output_root, verification_output = _make_synthetic_run(
        tmp_path, candidate_offset=0.80
    )

    report = VERIFY.verify_run(config_path, output_root, verification_output)

    assert report["technical_verification"] == "PASS"
    assert report["scientific_capability_gate"] == "HOLD"
    assert verification_output.is_file()


def test_independent_verification_refuses_reported_metric_tamper(
    tmp_path: Path,
) -> None:
    config_path, output_root, verification_output = _make_synthetic_run(tmp_path)
    summary_path = output_root / VERIFY.RESULT_SUMMARY_FILE
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    summary["metrics"]["nse_by_system_and_lead"]["knet_epoch75"]["2"] += 1e-6
    _write_json(summary_path, summary)
    manifest_path = output_root / VERIFY.MANIFEST_FILE
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["files"][VERIFY.RESULT_SUMMARY_FILE] = _file_sha256(summary_path)
    _write_json(manifest_path, manifest)

    with pytest.raises(RuntimeError, match="nse_by_system_and_lead"):
        VERIFY.verify_run(config_path, output_root, verification_output)

    assert not verification_output.exists()


def test_independent_verification_refuses_training_or_parameter_change(
    tmp_path: Path,
) -> None:
    config_path, output_root, verification_output = _make_synthetic_run(tmp_path)
    ledger_path = output_root / VERIFY.ACCESS_LEDGER_FILE
    ledger = json.loads(ledger_path.read_text(encoding="utf-8"))
    ledger["optimizer_steps"] = 1
    ledger["parameter_sha256_after"] = "f" * 64
    _write_json(ledger_path, ledger)
    summary_path = output_root / VERIFY.RESULT_SUMMARY_FILE
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    summary["access_ledger_sha256"] = _file_sha256(ledger_path)
    _write_json(summary_path, summary)
    manifest_path = output_root / VERIFY.MANIFEST_FILE
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["files"][VERIFY.ACCESS_LEDGER_FILE] = _file_sha256(ledger_path)
    manifest["files"][VERIFY.RESULT_SUMMARY_FILE] = _file_sha256(summary_path)
    _write_json(manifest_path, manifest)

    with pytest.raises(RuntimeError, match="optimizer_steps"):
        VERIFY.verify_run(config_path, output_root, verification_output)


def test_independent_verification_refuses_unregistered_output(tmp_path: Path) -> None:
    config_path, output_root, verification_output = _make_synthetic_run(tmp_path)
    (output_root / "unregistered.txt").write_text("unexpected", encoding="utf-8")

    with pytest.raises(RuntimeError, match="unregistered output"):
        VERIFY.verify_run(config_path, output_root, verification_output)


def test_config_identity_failure_happens_before_prediction_archive_read(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    config_path, output_root, verification_output = _make_synthetic_run(tmp_path)
    config = json.loads(config_path.read_text(encoding="utf-8"))
    config["candidate"]["checkpoint_sha256"] = "0" * 64
    _write_json(config_path, config)
    monkeypatch.setattr(
        VERIFY,
        "_load_prediction_archive",
        lambda _: pytest.fail("prediction archive was read before config identity passed"),
    )

    with pytest.raises(RuntimeError, match="candidate.checkpoint_sha256"):
        VERIFY.verify_run(config_path, output_root, verification_output)


def test_manifest_hash_failure_happens_before_prediction_archive_read(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    config_path, output_root, verification_output = _make_synthetic_run(tmp_path)
    manifest_path = output_root / VERIFY.MANIFEST_FILE
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["files"][VERIFY.PREDICTIONS_FILE] = "0" * 64
    _write_json(manifest_path, manifest)
    monkeypatch.setattr(
        VERIFY,
        "_load_prediction_archive",
        lambda _: pytest.fail("prediction archive was read before manifest hashes passed"),
    )

    with pytest.raises(RuntimeError, match="manifest member hash mismatch"):
        VERIFY.verify_run(config_path, output_root, verification_output)


def test_independent_verification_refuses_wrong_checkpoint_summary(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    config_path, output_root, verification_output = _make_synthetic_run(tmp_path)
    summary_path = output_root / VERIFY.RESULT_SUMMARY_FILE
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    summary["checkpoint"]["epoch"] = 74
    _write_json(summary_path, summary)
    manifest_path = output_root / VERIFY.MANIFEST_FILE
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["files"][VERIFY.RESULT_SUMMARY_FILE] = _file_sha256(summary_path)
    _write_json(manifest_path, manifest)
    monkeypatch.setattr(
        VERIFY,
        "_load_prediction_archive",
        lambda _: pytest.fail("prediction archive was read before checkpoint identity passed"),
    )

    with pytest.raises(RuntimeError, match="summary.checkpoint.epoch"):
        VERIFY.verify_run(config_path, output_root, verification_output)


def test_verifier_source_does_not_import_formal_evaluator_or_torch() -> None:
    source = VERIFIER_PATH.read_text(encoding="utf-8")
    assert "run_daily_camels_knet_epoch75_formal_evaluation" not in source
    assert "import torch" not in source
    assert "from torch" not in source
    assert "np.load" in source
