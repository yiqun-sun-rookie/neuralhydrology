from __future__ import annotations

from copy import deepcopy
import importlib.util
import inspect
import json
from pathlib import Path
import sys
from typing import Any

import numpy as np
import pytest


ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = ROOT / "scripts" / "run_daily_camels_knet_epoch75_formal_evaluation.py"
CONFIG_PATH = ROOT / "configs" / "daily_camels_knet_epoch75_formal_evaluation_a39.json"


def _load_module():
    specification = importlib.util.spec_from_file_location(
        "a39_formal_evaluator", SCRIPT_PATH
    )
    if specification is None or specification.loader is None:
        raise RuntimeError("cannot load A39 formal evaluator")
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


EVALUATOR = _load_module()


def _synthetic_predictions(
    *, count: int = 500, candidate_offset: float = 0.05
) -> tuple[np.ndarray, np.ndarray, np.ndarray, dict[str, dict[int, np.ndarray]]]:
    dates = np.datetime64("2000-01-01", "ns") + np.arange(count).astype(
        "timedelta64[D]"
    )
    target = 5.0 + np.sin(np.arange(count, dtype=np.float64) / 9.0)
    forcing = np.column_stack(
        [
            np.linspace(0.0, 1.0, count, dtype=np.float64),
            np.ones(count, dtype=np.float64),
            np.full(count, 2.0, dtype=np.float64),
        ]
    )
    offsets = {
        "knet_epoch75": candidate_offset,
        "strict_zero_gain_knet": 0.20,
        "same_forcing_open_loop": 0.20,
        "default_noise_ukf": 0.10,
        "sampled_search_ukf": 0.09,
        "backpropagation_selected_ukf": 0.08,
        "persistence": 0.30,
        "second_order_autoregression": 0.25,
    }
    predictions = {
        system: {
            lead: target + offset * lead for lead in EVALUATOR.LEADS
        }
        for system, offset in offsets.items()
    }
    for lead in EVALUATOR.LEADS:
        predictions["strict_zero_gain_knet"][lead][:lead] = np.nan
        predictions["same_forcing_open_loop"][lead][:lead] = np.nan
        target_end = count - max(EVALUATOR.LEADS) + lead
        predictions["strict_zero_gain_knet"][lead][target_end:] = np.nan
        predictions["same_forcing_open_loop"][lead][target_end:] = np.nan
    return dates.astype(np.int64), forcing, target, predictions


def _expanded_config(tmp_path: Path) -> tuple[Path, dict[str, Any]]:
    config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    config["evaluation"]["period"] = ["2000-01-01", "2001-05-14"]
    config["evaluation"]["expected_days"] = 500
    config["evaluation_period"] = list(config["evaluation"]["period"])
    config["expected_evaluation_days"] = 500
    path = tmp_path / "config.json"
    path.write_text(json.dumps(config), encoding="utf-8")
    return path, config


def test_frozen_config_is_evaluation_only_and_authorized() -> None:
    config = EVALUATOR.load_and_validate_config(CONFIG_PATH)

    assert config["experiment_id"] == EVALUATOR.EXPERIMENT_ID
    assert config["authorization"]["user_instruction_utf8_sha256"] == (
        "57c0dad7188249e27bcf585f0f452f617554a083e79ea2589ff61cbcabedd231"
    )
    assert config["authorization"]["user_instruction_utf8_size_bytes"] == 111
    assert config["execution_policy"]["allow_training"] is False
    assert config["execution_policy"]["allow_optimizer_updates"] is False
    assert config["execution_policy"]["allow_checkpoint_writes"] is False
    assert config["execution_policy"]["allowed_evaluation_array_members"] == [
        "dates_ns",
        "forcing",
        "target",
    ]
    assert len(config["inputs"]["evaluation_archive"]["expected_archive_members"]) == 24
    assert config["initialization"]["archived_selection_initial_storage_allowed"] is False


@pytest.mark.parametrize(
    ("path", "value", "message"),
    [
        (("model", "normalized_feature_guard"), 9.0, "model contract"),
        (("ukf", "default_noise", "r_b"), 0.03, "UKF baseline contract"),
    ],
)
def test_frozen_config_rejects_prediction_changing_drift(
    tmp_path: Path, path: tuple[str, ...], value: Any, message: str
) -> None:
    config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    destination: dict[str, Any] = config
    for key in path[:-1]:
        destination = destination[key]
    destination[path[-1]] = value
    candidate = tmp_path / "drifted.json"
    candidate.write_text(json.dumps(config), encoding="utf-8")

    with pytest.raises(RuntimeError, match=message):
        EVALUATOR.load_and_validate_config(candidate)


def test_common_mask_population_scores_and_decisions_use_all_eight_systems() -> None:
    dates, forcing, target, predictions = _synthetic_predictions()
    predictions["sampled_search_ukf"][1][EVALUATOR.WARMUP_DAYS + 7] = np.nan

    arrays = EVALUATOR.build_prediction_arrays(
        dates_ns=dates,
        forcing=forcing,
        target=target,
        predictions=predictions,
        warmup_days=EVALUATOR.WARMUP_DAYS,
    )
    scored = EVALUATOR.score_prediction_arrays(arrays)

    lead_one_mask = arrays["common_mask_lead_1"]
    assert not lead_one_mask[EVALUATOR.WARMUP_DAYS + 7]
    assert scored["metrics"]["target_count_by_lead"]["1"] == int(
        lead_one_mask.sum()
    )
    expected_mse = float(
        np.mean(
            np.square(arrays["knet_epoch75_lead_1"][lead_one_mask] - target[lead_one_mask])
        )
    )
    expected_nse = 1.0 - expected_mse / float(np.var(target[lead_one_mask], ddof=0))
    assert scored["metrics"]["mse_by_system_and_lead"]["knet_epoch75"][
        "1"
    ] == pytest.approx(expected_mse, abs=1e-15)
    assert scored["metrics"]["nse_by_system_and_lead"]["knet_epoch75"][
        "1"
    ] == pytest.approx(expected_nse, abs=1e-15)
    assert scored["decisions"]["capability_gate"]["status"] == "PASS"
    assert scored["decisions"]["convergence_status"] == (
        "UNKNOWN_NOT_ESTABLISHED_BY_SINGLE_CHECKPOINT_FORMAL_EVALUATION"
    )


def test_warmup_is_applied_to_common_issue_dates_for_every_lead() -> None:
    dates, forcing, target, predictions = _synthetic_predictions()
    arrays = EVALUATOR.build_prediction_arrays(
        dates_ns=dates,
        forcing=forcing,
        target=target,
        predictions=predictions,
        warmup_days=EVALUATOR.WARMUP_DAYS,
    )
    expected_issue_count = len(target) - max(EVALUATOR.LEADS) - EVALUATOR.WARMUP_DAYS

    for lead in EVALUATOR.LEADS:
        mask = arrays[f"common_mask_lead_{lead}"]
        expected_start = EVALUATOR.WARMUP_DAYS + lead
        expected_end = len(target) - max(EVALUATOR.LEADS) + lead
        assert int(mask.sum()) == expected_issue_count
        assert np.flatnonzero(mask)[0] == expected_start
        assert np.flatnonzero(mask)[-1] == expected_end - 1


def test_strict_zero_gain_must_equal_regenerated_open_loop_pointwise() -> None:
    dates, forcing, target, predictions = _synthetic_predictions()
    predictions["strict_zero_gain_knet"][2][400] += 1e-15

    with pytest.raises(RuntimeError, match="strict zero-gain"):
        EVALUATOR.build_prediction_arrays(
            dates_ns=dates,
            forcing=forcing,
            target=target,
            predictions=predictions,
            warmup_days=EVALUATOR.WARMUP_DAYS,
        )


def test_scientific_hold_is_complete_technical_output_and_exit_zero(
    tmp_path: Path,
) -> None:
    dates, forcing, target, predictions = _synthetic_predictions(candidate_offset=0.80)
    arrays = EVALUATOR.build_prediction_arrays(
        dates_ns=dates,
        forcing=forcing,
        target=target,
        predictions=predictions,
        warmup_days=EVALUATOR.WARMUP_DAYS,
    )
    scored = EVALUATOR.score_prediction_arrays(arrays)

    assert scored["decisions"]["capability_gate"]["status"] == "HOLD"
    assert EVALUATOR.exit_code_for_completed_science(scored) == 0


def test_evaluation_archive_loader_reads_only_three_authorized_arrays_once(
    tmp_path: Path,
) -> None:
    dates, forcing, target, _ = _synthetic_predictions()
    archive_path = tmp_path / "evaluation.npz"
    np.savez(archive_path, dates_ns=dates, forcing=forcing, target=target)
    expected_hash = EVALUATOR.sha256_file(archive_path)
    ledger = EVALUATOR.new_access_ledger(EVALUATOR.PARAMETER_SHA256)

    loaded = EVALUATOR.load_evaluation_archive_once(
        archive_path,
        expected_sha256=expected_hash,
        expected_size_bytes=archive_path.stat().st_size,
        expected_archive_members=("dates_ns", "forcing", "target"),
        allowed_array_reads=("dates_ns", "forcing", "target"),
        expected_days=500,
        expected_period=("2000-01-01", "2001-05-14"),
        ledger=ledger,
    )

    assert set(loaded) == {"dates_ns", "forcing", "target"}
    assert ledger["evaluation_archive"] == {
        "open_count": 1,
        "authorized_read_count": 1,
        "array_reads": {"dates_ns": 1, "forcing": 1, "target": 1},
    }


def test_evaluation_archive_loader_lists_but_does_not_read_stored_prediction_member(
    tmp_path: Path,
) -> None:
    dates, forcing, target, _ = _synthetic_predictions()
    archive_path = tmp_path / "evaluation_with_prediction.npz"
    np.savez(
        archive_path,
        dates_ns=dates,
        forcing=forcing,
        target=target,
        old_tukf06_prediction=target,
    )
    ledger = EVALUATOR.new_access_ledger(EVALUATOR.PARAMETER_SHA256)

    loaded = EVALUATOR.load_evaluation_archive_once(
        archive_path,
        expected_sha256=EVALUATOR.sha256_file(archive_path),
        expected_size_bytes=archive_path.stat().st_size,
        expected_archive_members=(
            "dates_ns",
            "forcing",
            "target",
            "old_tukf06_prediction",
        ),
        allowed_array_reads=("dates_ns", "forcing", "target"),
        expected_days=500,
        expected_period=("2000-01-01", "2001-05-14"),
        ledger=ledger,
    )

    assert set(loaded) == {"dates_ns", "forcing", "target"}
    assert ledger["evaluation_archive"]["open_count"] == 1
    assert ledger["evaluation_archive"]["array_reads"] == {
        "dates_ns": 1,
        "forcing": 1,
        "target": 1,
    }
    assert ledger["stored_baseline_prediction_reads"] == 0


def test_atomic_publish_refuses_existing_output_root(tmp_path: Path) -> None:
    dates, forcing, target, predictions = _synthetic_predictions()
    arrays = EVALUATOR.build_prediction_arrays(
        dates_ns=dates,
        forcing=forcing,
        target=target,
        predictions=predictions,
        warmup_days=EVALUATOR.WARMUP_DAYS,
    )
    config_path, config = _expanded_config(tmp_path)
    ledger = EVALUATOR.new_access_ledger(EVALUATOR.PARAMETER_SHA256)
    ledger["evaluation_archive"] = {
        "open_count": 1,
        "authorized_read_count": 1,
        "array_reads": {"dates_ns": 1, "forcing": 1, "target": 1},
    }
    output_root = tmp_path / "evaluation"

    summary = EVALUATOR.publish_results_atomically(
        output_root=output_root,
        config_path=config_path,
        config=config,
        arrays=arrays,
        ledger=ledger,
    )

    assert summary["status"] == "FORMAL_EVALUATION_COMPLETE"
    assert {path.name for path in output_root.iterdir()} == {
        "predictions.npz",
        "result_summary.json",
        "access_ledger.json",
        "manifest.sha256.json",
    }
    with pytest.raises(FileExistsError, match="will not be overwritten"):
        EVALUATOR.publish_results_atomically(
            output_root=output_root,
            config_path=config_path,
            config=config,
            arrays=arrays,
            ledger=ledger,
        )


def test_evaluator_source_contains_no_training_entrypoint_or_update_call() -> None:
    source = SCRIPT_PATH.read_text(encoding="utf-8")
    config = EVALUATOR.load_and_validate_config(CONFIG_PATH)
    assert EVALUATOR.FORBIDDEN_TRAINING_ENTRY not in config["source_files"]
    assert "train_short_knet" not in source
    assert ".backward(" not in source
    assert "torch.optim" not in source

    injected = deepcopy(config)
    injected["source_files"][EVALUATOR.FORBIDDEN_TRAINING_ENTRY] = "0" * 64
    with pytest.raises(RuntimeError, match="forbids the legacy training entry"):
        EVALUATOR._validate_sources(injected)


def test_all_nonprotected_gates_precede_the_one_shot_array_read() -> None:
    execute_source = inspect.getsource(EVALUATOR.execute)

    assert execute_source.index("_validate_sources") < execute_source.index(
        "_prepare_regeneration"
    )
    assert execute_source.index("_prepare_regeneration") < execute_source.index(
        "load_evaluation_archive_once"
    )


def test_prepared_regeneration_carries_the_frozen_parity_contract() -> None:
    prepare_source = inspect.getsource(EVALUATOR._prepare_regeneration)
    regenerate_source = inspect.getsource(EVALUATOR._regenerate_all_predictions)

    assert '"parity_contract": parity_contract' in prepare_source
    assert 'parity_contract = prepared["parity_contract"]' in regenerate_source
    assert "contract=parity_contract" in regenerate_source
