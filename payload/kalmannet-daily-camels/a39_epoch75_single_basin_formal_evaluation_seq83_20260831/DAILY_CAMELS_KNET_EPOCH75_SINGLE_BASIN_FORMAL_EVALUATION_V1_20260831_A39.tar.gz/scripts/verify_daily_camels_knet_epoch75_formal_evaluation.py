"""Independent artifact-only verification for the A39 formal evaluation.

The verifier deliberately does not import the evaluator, its scoring helpers, the
model, PyTorch, or the protected evaluation input.  It reads only the evaluator's
sealed prediction archive after the JSON identities and manifest hashes have
passed, then independently reconstructs masks, scores, comparisons, and gates.
"""
from __future__ import annotations

import argparse
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import sys
from typing import Any, Mapping, NoReturn, Sequence

import numpy as np


CONFIG_SCHEMA_VERSION = "daily_camels_knet_epoch75_formal_evaluation_v1"
RESULT_SCHEMA_VERSION = "daily_camels_knet_epoch75_formal_evaluation_result_v1"
ACCESS_LEDGER_SCHEMA_VERSION = (
    "daily_camels_knet_epoch75_formal_evaluation_access_ledger_v1"
)
MANIFEST_SCHEMA_VERSION = "daily_camels_knet_epoch75_formal_evaluation_manifest_v1"
VERIFICATION_SCHEMA_VERSION = (
    "daily_camels_knet_epoch75_formal_evaluation_independent_verification_v1"
)

EXPERIMENT_ID = (
    "DAILY_CAMELS_KNET_EPOCH75_SINGLE_BASIN_FORMAL_EVALUATION_V1_20260831_A39"
)
SOURCE_EXPERIMENT_ID = (
    "DAILY_CAMELS_KNET_FIXED_FULL_TRAINING_COVERAGE_EPOCH40_TO80_RESUME_"
    "STEP_MONOTONICITY_DIAGNOSTIC_V1_20260828_A38"
)
SCIENTIFIC_ROLE = "single_basin_formal_evaluation_reused_historical_benchmark"
BASIN_ID = "09035800"
EVALUATION_PERIOD_ROLE = "reused_historical_benchmark"
EVALUATION_PERIOD = ("1989-10-01", "1999-09-30")
EXPECTED_DAYS = 3652
WARMUP_DAYS = 365
LEADS = (1, 2, 3)
ISSUE_START_INDEX_INCLUSIVE = WARMUP_DAYS
ISSUE_END_INDEX_EXCLUSIVE = EXPECTED_DAYS - max(LEADS)
NOMINAL_COMMON_ISSUE_COUNT = ISSUE_END_INDEX_EXCLUSIVE - ISSUE_START_INDEX_INCLUSIVE
SYSTEMS = (
    "knet_epoch75",
    "strict_zero_gain_knet",
    "same_forcing_open_loop",
    "default_noise_ukf",
    "sampled_search_ukf",
    "backpropagation_selected_ukf",
    "persistence",
    "second_order_autoregression",
)
HISTORICAL_ARCHIVE_MEMBERS = (
    "dates_ns",
    "target",
    "forcing",
    "common_mask_lead_1",
    "same_forcing_open_loop_lead_1",
    "default_noise_filter_lead_1",
    "sampling_search_filter_lead_1",
    "backpropagation_filter_lead_1",
    "persistence_lead_1",
    "second_order_autoregression_lead_1",
    "common_mask_lead_2",
    "same_forcing_open_loop_lead_2",
    "default_noise_filter_lead_2",
    "sampling_search_filter_lead_2",
    "backpropagation_filter_lead_2",
    "persistence_lead_2",
    "second_order_autoregression_lead_2",
    "common_mask_lead_3",
    "same_forcing_open_loop_lead_3",
    "default_noise_filter_lead_3",
    "sampling_search_filter_lead_3",
    "backpropagation_filter_lead_3",
    "persistence_lead_3",
    "second_order_autoregression_lead_3",
)
CANDIDATE_SYSTEM = "knet_epoch75"
STRICT_ZERO_SYSTEM = "strict_zero_gain_knet"
OPEN_LOOP_SYSTEM = "same_forcing_open_loop"
SELECTED_UKF_SYSTEM = "backpropagation_selected_ukf"

CHECKPOINT_PATH = (
    "/data1/home/sunyiq/kalmannet_daily_camels_knet_a38_a800_train1_20260828/"
    "runs/DAILY_CAMELS_KNET_FIXED_FULL_TRAINING_COVERAGE_EPOCH40_TO80_RESUME_"
    "STEP_MONOTONICITY_DIAGNOSTIC_V1_20260828_A38/checkpoints/epoch_075.pt"
)
CHECKPOINT_SHA256 = (
    "7cc97138669531688dcd65d606d154330f260346c7c9c6e704cb1be5307a241b"
)
PARAMETER_SHA256 = (
    "5a288a2ac6d2985253b37616d983d6dfaf0638b18169bba8fcd0439e5b922fce"
)
CHECKPOINT_EPOCH = 75
A38_EXECUTION_ID = "DAILY_CAMELS_KNET_FIXED_FULL_TRAINING_COVERAGE_A38_A800_TRAIN1_SEQ70"
A38_SLURM_JOB_ID = "215801"
A38_TERMINAL_EVIDENCE_ARCHIVE_SHA256 = (
    "72feda409ea3490ccd9a289b1313c9beb276c1cc267a15111dc19e63d5815317"
)
AUTHORIZATION_INSTRUCTION_SHA256 = (
    "57c0dad7188249e27bcf585f0f452f617554a083e79ea2589ff61cbcabedd231"
)
DEVELOPMENT_ARCHIVE_SHA256 = (
    "71e6d163507ae405204bedf63d2c6c06e2c3ea303cea1a0481cfa4d5f280f5fd"
)
SELECTION_SHA256 = "8b4888a62052f8d9f0018e907c665d30a72c4c7c29081763db0f4d46904ec3a2"
EVALUATION_ARCHIVE_SHA256 = (
    "59c0acc1afce14da7fe479fc5cdb6c6c4d2b18758d076c32950c5f2b3cfd3596"
)

MINIMUM_NSE_EXCLUSIVE = 0.6
PRACTICAL_EQUIVALENCE_NSE = 0.01
MAXIMUM_LEAD1_NSE_DEFICIT_VS_SELECTED_UKF = 0.10
MODEL_CONTRACT = {
    "state_dimension": 18,
    "gain_network_numeric_dtype": "float32",
    "physical_numeric_dtype": "float64",
    "seed": 20260824,
    "hidden": 24,
    "input_multiplier": 10,
    "output_multiplier": 10,
    "feature_scale_floor": 0.1,
    "normalized_feature_guard": 10.0,
    "correction_scope": "full_eighteen_dimensional_state_correction",
    "checkpoint_state_member": "model_state",
}
DEFAULT_UKF_PROCESS_DIAGONAL = [0.001] * 18
DEFAULT_UKF_OBSERVATION_NOISE_MULTIPLIER = 0.02
SCALAR_RELATIVE_TOLERANCE = 1e-12
SCALAR_ABSOLUTE_TOLERANCE = 1e-12

PREDICTIONS_FILE = "predictions.npz"
RESULT_SUMMARY_FILE = "result_summary.json"
ACCESS_LEDGER_FILE = "access_ledger.json"
MANIFEST_FILE = "manifest.sha256.json"
MANIFEST_MEMBER_FILES = (
    PREDICTIONS_FILE,
    RESULT_SUMMARY_FILE,
    ACCESS_LEDGER_FILE,
)
OUTPUT_FILES = frozenset((*MANIFEST_MEMBER_FILES, MANIFEST_FILE))
RESULT_STATUS = "FORMAL_EVALUATION_COMPLETE"
CONVERGENCE_STATUS = "UNKNOWN_NOT_ESTABLISHED_BY_SINGLE_CHECKPOINT_FORMAL_EVALUATION"

_HEX_DIGITS = frozenset("0123456789abcdef")


class VerificationError(RuntimeError):
    """A fail-closed independent-verification error."""


def _fail(message: str) -> NoReturn:
    raise VerificationError(message)


def _reject_json_constant(value: str) -> NoReturn:
    _fail(f"non-finite JSON constant is forbidden: {value}")


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            _fail(f"duplicate JSON key is forbidden: {key}")
        result[key] = value
    return result


def _require_regular_file(path: Path, *, label: str) -> Path:
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        _fail(f"{label} must be a regular non-symbolic-link file: {path}")
    return path


def _read_json(path: Path, *, label: str) -> dict[str, Any]:
    path = _require_regular_file(path, label=label)
    try:
        payload = json.loads(
            path.read_text(encoding="utf-8"),
            object_pairs_hook=_unique_object,
            parse_constant=_reject_json_constant,
        )
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise VerificationError(f"cannot read {label}: {exc}") from exc
    if not isinstance(payload, dict):
        _fail(f"{label} must contain one JSON object")
    return payload


def _sha256_file(path: Path) -> str:
    digest = sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _sha256_arrays(arrays: Mapping[str, np.ndarray]) -> str:
    digest = sha256()
    for name in sorted(arrays):
        array = np.ascontiguousarray(np.asarray(arrays[name]))
        digest.update(name.encode("utf-8"))
        digest.update(str(array.dtype).encode("ascii"))
        digest.update(np.asarray(array.shape, dtype=np.int64).tobytes())
        digest.update(array.tobytes())
    return digest.hexdigest()


def _require_sha256(value: Any, *, label: str) -> str:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in _HEX_DIGITS for character in value)
    ):
        _fail(f"{label} must be one lowercase SHA-256 hexadecimal string")
    return value


def _require_mapping(value: Any, *, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        _fail(f"{label} must be a mapping")
    return value


def _require_exact_keys(
    value: Mapping[str, Any], expected: Sequence[str] | set[str] | frozenset[str], *, label: str
) -> None:
    actual = set(value)
    wanted = set(expected)
    if actual != wanted:
        _fail(
            f"{label} keys differ: actual={sorted(actual)!r} expected={sorted(wanted)!r}"
        )


def _require_exact(value: Any, expected: Any, *, label: str) -> None:
    if value != expected:
        _fail(f"{label} differs: actual={value!r} expected={expected!r}")


def _require_zero_integer(value: Any, *, label: str) -> None:
    if isinstance(value, bool) or not isinstance(value, int) or value != 0:
        _fail(f"{label} must be integer zero; actual={value!r}")


def _validate_frozen_config(config: Mapping[str, Any]) -> None:
    _require_exact(config.get("schema_version"), CONFIG_SCHEMA_VERSION, label="config schema")
    _require_exact(config.get("experiment_id"), EXPERIMENT_ID, label="config experiment")
    _require_exact(config.get("basin_id"), BASIN_ID, label="config basin")
    _require_exact(
        config.get("scientific_role"), SCIENTIFIC_ROLE, label="config scientific role"
    )
    _require_exact(config.get("cadence"), "daily", label="config cadence")
    _require_exact(config.get("forecast_leads"), list(LEADS), label="config forecast_leads")
    _require_exact(
        config.get("evaluation_period"),
        list(EVALUATION_PERIOD),
        label="config evaluation_period",
    )
    _require_exact(
        config.get("evaluation_period_role"),
        EVALUATION_PERIOD_ROLE,
        label="config evaluation_period_role",
    )
    _require_exact(
        config.get("expected_evaluation_days"),
        EXPECTED_DAYS,
        label="config expected_evaluation_days",
    )
    _require_exact(config.get("warmup_days"), WARMUP_DAYS, label="config warmup_days")
    _require_exact(config.get("systems"), list(SYSTEMS), label="config systems")

    authorization = _require_mapping(config.get("authorization"), label="authorization")
    _compare_reported(
        authorization,
        {
            "status": "EXPLICITLY_AUTHORIZED",
            "authorized_at": "2026-08-31",
            "scope": "one_shot_epoch75_single_basin_formal_evaluation",
            "user_instruction_utf8_sha256": AUTHORIZATION_INSTRUCTION_SHA256,
            "user_instruction_utf8_size_bytes": 111,
        },
        path="authorization",
    )

    policy = _require_mapping(config.get("execution_policy"), label="execution_policy")
    _compare_reported(
        policy,
        {
            "evaluation_only": True,
            "one_shot_evaluation": True,
            "allow_training": False,
            "allow_optimizer_updates": False,
            "allow_checkpoint_writes": False,
            "allow_checkpoint_selection": False,
            "allow_hyperparameter_tuning": False,
            "allow_stored_baseline_prediction_reads": False,
            "evaluation_archive_open_count": 1,
            "allowed_evaluation_array_members": ["dates_ns", "forcing", "target"],
            "require_absent_output_root": True,
            "scientific_hold_is_technical_success": True,
        },
        path="execution_policy",
    )

    evaluation = _require_mapping(config.get("evaluation"), label="evaluation")
    _require_exact(evaluation.get("period"), list(EVALUATION_PERIOD), label="evaluation.period")
    _require_exact(evaluation.get("role"), EVALUATION_PERIOD_ROLE, label="evaluation.role")
    _require_exact(evaluation.get("expected_days"), EXPECTED_DAYS, label="evaluation.expected_days")
    _require_exact(
        evaluation.get("warmup_days_excluded"),
        WARMUP_DAYS,
        label="evaluation.warmup_days_excluded",
    )
    _require_exact(
        evaluation.get("warmup_applies_to_issue_dates"),
        True,
        label="evaluation.warmup_applies_to_issue_dates",
    )
    _require_exact(
        evaluation.get("issue_start_index_inclusive"),
        ISSUE_START_INDEX_INCLUSIVE,
        label="evaluation.issue_start_index_inclusive",
    )
    _require_exact(
        evaluation.get("issue_end_index_exclusive"),
        ISSUE_END_INDEX_EXCLUSIVE,
        label="evaluation.issue_end_index_exclusive",
    )
    _require_exact(
        evaluation.get("nominal_common_issue_count"),
        NOMINAL_COMMON_ISSUE_COUNT,
        label="evaluation.nominal_common_issue_count",
    )
    _require_exact(evaluation.get("leads_days"), list(LEADS), label="evaluation.leads_days")
    _require_exact(evaluation.get("systems"), list(SYSTEMS), label="evaluation.systems")

    candidate = _require_mapping(config.get("candidate"), label="candidate")
    expected_candidate = {
        "source_experiment_id": SOURCE_EXPERIMENT_ID,
        "checkpoint_path": CHECKPOINT_PATH,
        "checkpoint_sha256": CHECKPOINT_SHA256,
        "completed_epoch": CHECKPOINT_EPOCH,
        "parameter_sha256": PARAMETER_SHA256,
        "source_execution_id": A38_EXECUTION_ID,
        "source_slurm_job_id": A38_SLURM_JOB_ID,
        "source_terminal_evidence_archive_sha256": A38_TERMINAL_EVIDENCE_ARCHIVE_SHA256,
    }
    _compare_reported(candidate, expected_candidate, path="candidate")

    checkpoint = _require_mapping(config.get("checkpoint"), label="checkpoint")
    _compare_reported(
        checkpoint,
        {
            "path": CHECKPOINT_PATH,
            "sha256": CHECKPOINT_SHA256,
            "size_bytes": 4260296,
            "completed_epoch": CHECKPOINT_EPOCH,
            "parameter_sha256": PARAMETER_SHA256,
        },
        path="checkpoint",
    )

    inputs = _require_mapping(config.get("inputs"), label="inputs")
    for input_name in ("development_archive", "selection", "evaluation_archive"):
        item = _require_mapping(inputs.get(input_name), label=f"inputs.{input_name}")
        if not isinstance(item.get("path"), str) or not item["path"]:
            _fail(f"inputs.{input_name}.path must be a nonempty string")
        _require_sha256(item.get("sha256"), label=f"inputs.{input_name}.sha256")
    _require_exact(
        inputs["development_archive"]["sha256"],
        DEVELOPMENT_ARCHIVE_SHA256,
        label="inputs.development_archive.sha256",
    )
    _require_exact(
        inputs["selection"]["sha256"], SELECTION_SHA256, label="inputs.selection.sha256"
    )
    _require_exact(
        inputs["evaluation_archive"]["sha256"],
        EVALUATION_ARCHIVE_SHA256,
        label="inputs.evaluation_archive.sha256",
    )
    _require_exact(
        inputs["evaluation_archive"].get("expected_archive_members"),
        list(HISTORICAL_ARCHIVE_MEMBERS),
        label="inputs.evaluation_archive.expected_archive_members",
    )
    _require_exact(
        inputs["evaluation_archive"].get("stored_baseline_prediction_reads"),
        0,
        label="inputs.evaluation_archive.stored_baseline_prediction_reads",
    )

    model = _require_mapping(config.get("model"), label="model")
    _compare_reported(model, MODEL_CONTRACT, path="model")
    ukf = _require_mapping(config.get("ukf"), label="ukf")
    _compare_reported(
        ukf,
        {
            "default_noise": {
                "process_diagonal": DEFAULT_UKF_PROCESS_DIAGONAL,
                "r_b": DEFAULT_UKF_OBSERVATION_NOISE_MULTIPLIER,
            },
            "sampled_search": {"selection_method": "sampling_search"},
            "backpropagation_selected": {
                "selection_method": "backpropagation"
            },
        },
        path="ukf",
    )

    metrics = _require_mapping(config.get("metrics"), label="metrics")
    _require_exact(
        metrics.get("primary"),
        "population_variance_nash_sutcliffe_efficiency",
        label="metrics.primary",
    )
    _require_exact(
        metrics.get("physical_error"),
        "mean_squared_error_in_discharge_units",
        label="metrics.physical_error",
    )
    _require_exact(
        metrics.get("allowed"),
        [
            "population_variance_nash_sutcliffe_efficiency",
            "mean_squared_error_in_discharge_units",
        ],
        label="metrics.allowed",
    )
    _require_exact(
        metrics.get("common_finite_mask_across_all_systems_per_lead"),
        True,
        label="metrics.common_finite_mask_across_all_systems_per_lead",
    )
    _require_exact(
        metrics.get("same_nominal_issue_window_across_leads"),
        True,
        label="metrics.same_nominal_issue_window_across_leads",
    )
    _require_exact(metrics.get("equal_lead_mean"), True, label="metrics.equal_lead_mean")
    _require_exact(
        metrics.get("sample_variance_allowed"),
        False,
        label="metrics.sample_variance_allowed",
    )

    gates = _require_mapping(config.get("gates"), label="gates")
    frozen_gates = {
        "minimum_nse_exclusive": MINIMUM_NSE_EXCLUSIVE,
        "require_each_lead": True,
        "require_better_than_strict_zero_gain_each_lead": True,
        "require_better_than_same_forcing_open_loop_each_lead": True,
        "selected_ukf_practical_equivalence_nse": PRACTICAL_EQUIVALENCE_NSE,
        "maximum_lead1_nse_deficit_vs_selected_ukf": (
            MAXIMUM_LEAD1_NSE_DEFICIT_VS_SELECTED_UKF
        ),
    }
    for key, expected in frozen_gates.items():
        _require_exact(gates.get(key), expected, label=f"gates.{key}")

    output_contract = _require_mapping(
        config.get("output_contract"), label="output_contract"
    )
    _compare_reported(
        output_contract,
        {
            "result_summary": RESULT_SUMMARY_FILE,
            "predictions": PREDICTIONS_FILE,
            "access_ledger": ACCESS_LEDGER_FILE,
            "manifest": MANIFEST_FILE,
            "atomic_directory_publish": True,
            "refuse_overwrite": True,
            "manifest_members": list(MANIFEST_MEMBER_FILES),
        },
        path="output_contract",
    )
    status_vocabulary = _require_mapping(
        config.get("status_vocabulary"), label="status_vocabulary"
    )
    _compare_reported(
        status_vocabulary,
        {
            "technical_success": RESULT_STATUS,
            "scientific_capability_pass": "PASS",
            "scientific_capability_hold": "HOLD",
            "scale_up_go": "GO",
            "scale_up_hold": "HOLD",
            "convergence": CONVERGENCE_STATUS,
        },
        path="status_vocabulary",
    )
    source_files = _require_mapping(config.get("source_files"), label="source_files")
    _require_exact(
        source_files.get("configs/daily_camels_knet_epoch40_to80_resume_a38.json"),
        "05bace055154c9e88124f81434fc76a4e7a0e73d1ef4b8bf2635d7507b5d7d82",
        label="source A38 configuration hash",
    )


def _load_prediction_archive(path: Path) -> dict[str, np.ndarray]:
    path = _require_regular_file(path, label="prediction archive")
    try:
        with np.load(path, allow_pickle=False) as archive:
            arrays = {name: archive[name] for name in archive.files}
    except (OSError, ValueError, KeyError) as exc:
        raise VerificationError(f"cannot load prediction archive: {exc}") from exc
    return arrays


def _expected_prediction_members() -> set[str]:
    names = {"dates_ns", "target", "forcing"}
    for lead in LEADS:
        names.add(f"common_mask_lead_{lead}")
        names.update(f"{system}_lead_{lead}" for system in SYSTEMS)
    return names


def _validate_array_geometry(arrays: Mapping[str, np.ndarray]) -> None:
    expected_members = _expected_prediction_members()
    if set(arrays) != expected_members:
        _fail(
            "prediction archive members differ: "
            f"actual={sorted(arrays)!r} expected={sorted(expected_members)!r}"
        )
    dates = np.asarray(arrays["dates_ns"])
    target = np.asarray(arrays["target"])
    forcing = np.asarray(arrays["forcing"])
    if dates.dtype != np.dtype("int64") or dates.shape != (EXPECTED_DAYS,):
        _fail("dates_ns must be int64 with exact shape (3652,)")
    expected_start = int(np.datetime64(EVALUATION_PERIOD[0], "ns").astype(np.int64))
    expected_end = int(np.datetime64(EVALUATION_PERIOD[1], "ns").astype(np.int64))
    if int(dates[0]) != expected_start or int(dates[-1]) != expected_end:
        _fail("dates_ns endpoints differ from the frozen evaluation period")
    one_day_ns = 86_400_000_000_000
    if not np.all(np.diff(dates) == one_day_ns):
        _fail("dates_ns must be strictly increasing daily dates without gaps")
    if target.shape != (EXPECTED_DAYS,) or target.dtype != np.dtype("float64"):
        _fail("target must be float64 with exact shape (3652,)")
    if (
        forcing.shape != (EXPECTED_DAYS, 3)
        or forcing.dtype != np.dtype("float64")
    ):
        _fail("forcing must be float64 with exact shape (3652, 3)")
    if not np.isfinite(forcing).all():
        _fail("forcing contains a non-finite value")
    for lead in LEADS:
        mask = np.asarray(arrays[f"common_mask_lead_{lead}"])
        if mask.dtype != np.dtype("bool") or mask.shape != (EXPECTED_DAYS,):
            _fail(f"common_mask_lead_{lead} must be bool with exact shape (3652,)")
        for system in SYSTEMS:
            prediction = np.asarray(arrays[f"{system}_lead_{lead}"])
            if prediction.shape != (EXPECTED_DAYS,) or prediction.dtype != np.dtype(
                "float64"
            ):
                _fail(
                    f"{system}_lead_{lead} must be float64 with exact shape (3652,)"
                )
            if np.isinf(prediction).any():
                _fail(f"{system}_lead_{lead} contains an infinite forecast")


def _mse_and_population_nse(
    prediction: np.ndarray, target: np.ndarray, mask: np.ndarray
) -> tuple[float, float]:
    selected = np.asarray(mask, dtype=bool)
    prediction64 = np.asarray(prediction, dtype=np.float64)[selected]
    target64 = np.asarray(target, dtype=np.float64)[selected]
    if prediction64.size == 0:
        _fail("common finite mask contains no scored target")
    squared_error = np.square(prediction64 - target64)
    mse = float(np.mean(squared_error, dtype=np.float64))
    target_variance = float(np.var(target64, ddof=0, dtype=np.float64))
    if not math.isfinite(mse) or not math.isfinite(target_variance) or target_variance <= 0.0:
        _fail("independent score has non-finite error or non-positive target variance")
    nse = 1.0 - mse / target_variance
    if not math.isfinite(nse):
        _fail("independent population Nash-Sutcliffe efficiency is non-finite")
    return mse, nse


def _comparison_status(equal_lead_mean_delta: float) -> str:
    if equal_lead_mean_delta >= PRACTICAL_EQUIVALENCE_NSE:
        return "KALMANNET_ADVANTAGE"
    if equal_lead_mean_delta <= -PRACTICAL_EQUIVALENCE_NSE:
        return "BACKPROPAGATION_SELECTED_UKF_ADVANTAGE"
    return "NO_DISCERNIBLE_ADVANTAGE"


def recompute_from_arrays(arrays: Mapping[str, np.ndarray]) -> dict[str, Any]:
    """Independently rebuild masks, scalar metrics, comparisons, and decisions."""
    _validate_array_geometry(arrays)
    target = np.asarray(arrays["target"], dtype=np.float64)
    nse: dict[str, dict[str, float]] = {system: {} for system in SYSTEMS}
    mse: dict[str, dict[str, float]] = {system: {} for system in SYSTEMS}
    target_counts: dict[str, int] = {}
    issue_geometry: dict[str, Any] = {
        "issue_start_index_inclusive": WARMUP_DAYS,
        "issue_end_index_exclusive": EXPECTED_DAYS - max(LEADS),
        "nominal_common_issue_count": EXPECTED_DAYS - max(LEADS) - WARMUP_DAYS,
        "target_index_interval_by_lead": {},
    }

    for lead in LEADS:
        lead_key = str(lead)
        expected_mask = np.isfinite(target)
        for system in SYSTEMS:
            expected_mask &= np.isfinite(
                np.asarray(arrays[f"{system}_lead_{lead}"], dtype=np.float64)
            )
        target_start = WARMUP_DAYS + lead
        target_end = EXPECTED_DAYS - max(LEADS) + lead
        expected_mask[:target_start] = False
        expected_mask[target_end:] = False
        issue_geometry["target_index_interval_by_lead"][lead_key] = {
            "start_inclusive": target_start,
            "end_exclusive": target_end,
        }
        stored_mask = np.asarray(arrays[f"common_mask_lead_{lead}"], dtype=bool)
        if not np.array_equal(stored_mask, expected_mask):
            _fail(f"common_mask_lead_{lead} differs from the independently rebuilt mask")
        target_counts[lead_key] = int(expected_mask.sum())
        for system in SYSTEMS:
            system_mse, system_nse = _mse_and_population_nse(
                np.asarray(arrays[f"{system}_lead_{lead}"], dtype=np.float64),
                target,
                expected_mask,
            )
            mse[system][lead_key] = system_mse
            nse[system][lead_key] = system_nse

    for lead in LEADS:
        zero = np.asarray(arrays[f"{STRICT_ZERO_SYSTEM}_lead_{lead}"])
        open_loop = np.asarray(arrays[f"{OPEN_LOOP_SYSTEM}_lead_{lead}"])
        if not np.array_equal(zero, open_loop, equal_nan=True):
            _fail(
                f"strict zero-gain KalmanNet and same-forcing open loop differ at lead {lead}"
            )

    mean_nse = {
        system: float(np.mean([nse[system][str(lead)] for lead in LEADS], dtype=np.float64))
        for system in SYSTEMS
    }
    mean_mse = {
        system: float(np.mean([mse[system][str(lead)] for lead in LEADS], dtype=np.float64))
        for system in SYSTEMS
    }
    candidate_minus_selected = {
        str(lead): nse[CANDIDATE_SYSTEM][str(lead)]
        - nse[SELECTED_UKF_SYSTEM][str(lead)]
        for lead in LEADS
    }
    candidate_minus_zero = {
        str(lead): nse[CANDIDATE_SYSTEM][str(lead)]
        - nse[STRICT_ZERO_SYSTEM][str(lead)]
        for lead in LEADS
    }
    candidate_minus_open = {
        str(lead): nse[CANDIDATE_SYSTEM][str(lead)]
        - nse[OPEN_LOOP_SYSTEM][str(lead)]
        for lead in LEADS
    }
    selected_mean_delta = float(
        np.mean(list(candidate_minus_selected.values()), dtype=np.float64)
    )

    failed_conditions: list[str] = []
    for lead in LEADS:
        key = str(lead)
        if not nse[CANDIDATE_SYSTEM][key] > MINIMUM_NSE_EXCLUSIVE:
            failed_conditions.append(
                f"lead_{lead}_candidate_nse_not_strictly_above_{MINIMUM_NSE_EXCLUSIVE}"
            )
        if not candidate_minus_zero[key] > 0.0:
            failed_conditions.append(
                f"lead_{lead}_candidate_not_better_than_strict_zero_gain"
            )
        if not candidate_minus_open[key] > 0.0:
            failed_conditions.append(
                f"lead_{lead}_candidate_not_better_than_same_forcing_open_loop"
            )
    capability_status = "PASS" if not failed_conditions else "HOLD"
    lead1_not_catastrophic = (
        candidate_minus_selected["1"]
        >= -MAXIMUM_LEAD1_NSE_DEFICIT_VS_SELECTED_UKF
    )
    scale_up_readiness = (
        "GO" if capability_status == "PASS" and lead1_not_catastrophic else "HOLD"
    )
    return {
        "metrics": {
            "target_count_by_lead": target_counts,
            "common_issue_geometry": issue_geometry,
            "nse_by_system_and_lead": nse,
            "mse_by_system_and_lead": mse,
            "equal_lead_mean_nse_by_system": mean_nse,
            "equal_lead_mean_mse_by_system": mean_mse,
        },
        "comparisons": {
            "candidate_minus_backpropagation_selected_ukf_nse_by_lead": (
                candidate_minus_selected
            ),
            "candidate_minus_backpropagation_selected_ukf_nse_equal_lead_mean": (
                selected_mean_delta
            ),
            "candidate_minus_strict_zero_gain_nse_by_lead": candidate_minus_zero,
            "candidate_minus_same_forcing_open_loop_nse_by_lead": candidate_minus_open,
        },
        "decisions": {
            "capability_gate": {
                "status": capability_status,
                "failed_conditions": failed_conditions,
            },
            "comparison_status": _comparison_status(selected_mean_delta),
            "scale_up_readiness": scale_up_readiness,
            "convergence_status": CONVERGENCE_STATUS,
        },
    }


def _compare_reported(actual: Any, expected: Any, *, path: str) -> None:
    if isinstance(expected, Mapping):
        if not isinstance(actual, Mapping):
            _fail(f"{path} must be a mapping")
        if set(actual) != set(expected):
            _fail(
                f"{path} keys differ: actual={sorted(actual)!r} "
                f"expected={sorted(expected)!r}"
            )
        for key in expected:
            _compare_reported(actual[key], expected[key], path=f"{path}.{key}")
        return
    if isinstance(expected, list):
        if not isinstance(actual, list) or len(actual) != len(expected):
            _fail(f"{path} list shape differs")
        for index, (actual_item, expected_item) in enumerate(zip(actual, expected)):
            _compare_reported(actual_item, expected_item, path=f"{path}[{index}]")
        return
    if isinstance(expected, bool):
        if actual is not expected:
            _fail(f"{path} differs: actual={actual!r} expected={expected!r}")
        return
    if isinstance(expected, int):
        if isinstance(actual, bool) or not isinstance(actual, int) or actual != expected:
            _fail(f"{path} differs: actual={actual!r} expected={expected!r}")
        return
    if isinstance(expected, float):
        if (
            isinstance(actual, bool)
            or not isinstance(actual, (int, float))
            or not math.isfinite(float(actual))
            or not math.isclose(
                float(actual),
                expected,
                rel_tol=SCALAR_RELATIVE_TOLERANCE,
                abs_tol=SCALAR_ABSOLUTE_TOLERANCE,
            )
        ):
            _fail(f"{path} differs: actual={actual!r} expected={expected!r}")
        return
    if actual != expected:
        _fail(f"{path} differs: actual={actual!r} expected={expected!r}")


def _verify_manifest(output_root: Path, config_sha256: str) -> dict[str, Any]:
    manifest = _read_json(output_root / MANIFEST_FILE, label="evaluation manifest")
    _require_exact_keys(
        manifest,
        {"schema_version", "experiment_id", "status", "configuration_sha256", "files"},
        label="evaluation manifest",
    )
    _require_exact(
        manifest["schema_version"], MANIFEST_SCHEMA_VERSION, label="manifest schema"
    )
    _require_exact(manifest["experiment_id"], EXPERIMENT_ID, label="manifest experiment")
    _require_exact(manifest["status"], RESULT_STATUS, label="manifest status")
    _require_exact(
        manifest["configuration_sha256"], config_sha256, label="manifest config hash"
    )
    files = _require_mapping(manifest["files"], label="manifest.files")
    _require_exact_keys(files, MANIFEST_MEMBER_FILES, label="manifest.files")
    for name in MANIFEST_MEMBER_FILES:
        expected_hash = _require_sha256(files[name], label=f"manifest.files.{name}")
        path = _require_regular_file(output_root / name, label=f"manifest member {name}")
        actual_hash = _sha256_file(path)
        if actual_hash != expected_hash:
            _fail(
                f"manifest member hash mismatch for {name}: "
                f"actual={actual_hash} expected={expected_hash}"
            )
    return manifest


def _verify_summary_identity(
    summary: Mapping[str, Any], config: Mapping[str, Any], config_path: Path
) -> None:
    expected_keys = {
        "schema_version",
        "experiment_id",
        "status",
        "scientific_role",
        "basin_id",
        "evaluation_period_role",
        "evaluation_period",
        "warmup_days",
        "leads_days",
        "systems",
        "checkpoint",
        "configuration",
        "inputs",
        "predictions",
        "metrics",
        "comparisons",
        "decisions",
        "access_ledger_sha256",
        "manifest_members_expected",
    }
    _require_exact_keys(summary, expected_keys, label="result summary")
    frozen_values = {
        "schema_version": RESULT_SCHEMA_VERSION,
        "experiment_id": EXPERIMENT_ID,
        "status": RESULT_STATUS,
        "scientific_role": SCIENTIFIC_ROLE,
        "basin_id": BASIN_ID,
        "evaluation_period_role": EVALUATION_PERIOD_ROLE,
        "evaluation_period": list(EVALUATION_PERIOD),
        "warmup_days": WARMUP_DAYS,
        "leads_days": list(LEADS),
        "systems": list(SYSTEMS),
    }
    for key, expected in frozen_values.items():
        _require_exact(summary[key], expected, label=f"result_summary.{key}")

    checkpoint = _require_mapping(summary["checkpoint"], label="summary.checkpoint")
    _require_exact_keys(
        checkpoint,
        {"path", "epoch", "file_sha256", "parameter_sha256"},
        label="summary.checkpoint",
    )
    expected_checkpoint = {
        "path": CHECKPOINT_PATH,
        "epoch": CHECKPOINT_EPOCH,
        "file_sha256": CHECKPOINT_SHA256,
        "parameter_sha256": PARAMETER_SHA256,
    }
    _compare_reported(checkpoint, expected_checkpoint, path="summary.checkpoint")

    configuration = _require_mapping(
        summary["configuration"], label="summary.configuration"
    )
    _require_exact_keys(configuration, {"path", "sha256"}, label="summary.configuration")
    if not isinstance(configuration["path"], str) or not configuration["path"]:
        _fail("summary.configuration.path must be a nonempty string")
    _require_exact(
        configuration["sha256"],
        _sha256_file(config_path),
        label="summary.configuration.sha256",
    )
    _compare_reported(summary["inputs"], config["inputs"], path="summary.inputs")
    expected_manifest_members = list(MANIFEST_MEMBER_FILES)
    _require_exact(
        summary["manifest_members_expected"],
        expected_manifest_members,
        label="summary.manifest_members_expected",
    )


def _verify_access_ledger(
    ledger: Mapping[str, Any], summary: Mapping[str, Any], ledger_path: Path
) -> None:
    expected_keys = {
        "schema_version",
        "experiment_id",
        "evaluation_archive",
        "stored_baseline_prediction_reads",
        "optimizer_steps",
        "training_events",
        "checkpoint_writes",
        "parameter_sha256_before",
        "parameter_sha256_after",
    }
    _require_exact_keys(ledger, expected_keys, label="access ledger")
    _require_exact(
        ledger["schema_version"], ACCESS_LEDGER_SCHEMA_VERSION, label="ledger schema"
    )
    _require_exact(ledger["experiment_id"], EXPERIMENT_ID, label="ledger experiment")
    evaluation = _require_mapping(
        ledger["evaluation_archive"], label="ledger.evaluation_archive"
    )
    _require_exact_keys(
        evaluation,
        {"open_count", "authorized_read_count", "array_reads"},
        label="ledger.evaluation_archive",
    )
    _require_exact(evaluation["open_count"], 1, label="ledger evaluation open_count")
    _require_exact(
        evaluation["authorized_read_count"],
        1,
        label="ledger evaluation authorized_read_count",
    )
    reads = _require_mapping(
        evaluation["array_reads"], label="ledger.evaluation_archive.array_reads"
    )
    _compare_reported(
        reads,
        {"dates_ns": 1, "forcing": 1, "target": 1},
        path="ledger.evaluation_archive.array_reads",
    )
    for key in (
        "stored_baseline_prediction_reads",
        "optimizer_steps",
        "training_events",
        "checkpoint_writes",
    ):
        _require_zero_integer(ledger[key], label=f"ledger.{key}")
    _require_exact(
        ledger["parameter_sha256_before"],
        PARAMETER_SHA256,
        label="ledger.parameter_sha256_before",
    )
    _require_exact(
        ledger["parameter_sha256_after"],
        PARAMETER_SHA256,
        label="ledger.parameter_sha256_after",
    )
    actual_hash = _sha256_file(ledger_path)
    _require_exact(
        summary["access_ledger_sha256"], actual_hash, label="summary access-ledger hash"
    )


def _verify_prediction_identity(
    summary: Mapping[str, Any], prediction_path: Path, arrays: Mapping[str, np.ndarray]
) -> None:
    predictions = _require_mapping(summary["predictions"], label="summary.predictions")
    _require_exact_keys(
        predictions,
        {"path", "file_sha256", "semantic_sha256"},
        label="summary.predictions",
    )
    _require_exact(predictions["path"], PREDICTIONS_FILE, label="summary predictions path")
    _require_exact(
        predictions["file_sha256"],
        _sha256_file(prediction_path),
        label="summary prediction file hash",
    )
    _require_exact(
        predictions["semantic_sha256"],
        _sha256_arrays(arrays),
        label="summary prediction semantic hash",
    )


def _atomic_json_no_replace(path: Path, payload: Mapping[str, Any]) -> None:
    path = Path(path)
    if path.exists() or path.is_symlink():
        _fail(f"verification output already exists and will not be overwritten: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.parent.is_symlink() or not path.parent.is_dir():
        _fail("verification output parent must be a regular directory")
    content = (
        json.dumps(
            payload,
            indent=2,
            sort_keys=True,
            ensure_ascii=False,
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")
    temporary = path.with_name(f".{path.name}.pending-{os.getpid()}")
    try:
        with temporary.open("xb") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        try:
            os.link(temporary, path)
        except FileExistsError as exc:
            raise VerificationError(
                f"verification output appeared concurrently and was not overwritten: {path}"
            ) from exc
    finally:
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass


def verify_run(
    config_path: Path, output_root: Path, verification_output: Path
) -> dict[str, Any]:
    """Verify one sealed run and atomically write a separate immutable report."""
    config_path = _require_regular_file(Path(config_path), label="formal config")
    config = _read_json(config_path, label="formal config")
    _validate_frozen_config(config)
    config_sha256 = _sha256_file(config_path)

    output_root = Path(output_root)
    if output_root.is_symlink() or not output_root.is_dir():
        _fail(f"evaluation output root must be a regular directory: {output_root}")
    actual_names = {path.name for path in output_root.iterdir()}
    if actual_names != OUTPUT_FILES:
        _fail(
            "unregistered output or missing registered output: "
            f"actual={sorted(actual_names)!r} expected={sorted(OUTPUT_FILES)!r}"
        )
    for path in output_root.iterdir():
        _require_regular_file(path, label=f"evaluation output {path.name}")
    verification_output = Path(verification_output)
    try:
        verification_output.resolve().relative_to(output_root.resolve())
    except ValueError:
        pass
    else:
        _fail("verification output must be outside the sealed evaluation output root")
    if verification_output.exists() or verification_output.is_symlink():
        _fail(
            "verification output already exists and will not be overwritten: "
            f"{verification_output}"
        )

    manifest = _verify_manifest(output_root, config_sha256)
    summary_path = output_root / RESULT_SUMMARY_FILE
    ledger_path = output_root / ACCESS_LEDGER_FILE
    prediction_path = output_root / PREDICTIONS_FILE
    summary = _read_json(summary_path, label="result summary")
    ledger = _read_json(ledger_path, label="access ledger")
    _verify_summary_identity(summary, config, config_path)
    _verify_access_ledger(ledger, summary, ledger_path)

    # The produced prediction archive is opened only after every available JSON
    # identity, access, and file-hash check has passed.
    arrays = _load_prediction_archive(prediction_path)
    _verify_prediction_identity(summary, prediction_path, arrays)
    recomputed = recompute_from_arrays(arrays)
    _compare_reported(summary["metrics"], recomputed["metrics"], path="metrics")
    _compare_reported(
        summary["comparisons"], recomputed["comparisons"], path="comparisons"
    )
    _compare_reported(summary["decisions"], recomputed["decisions"], path="decisions")

    report = {
        "schema_version": VERIFICATION_SCHEMA_VERSION,
        "experiment_id": EXPERIMENT_ID,
        "basin_id": BASIN_ID,
        "technical_verification": "PASS",
        "scientific_capability_gate": recomputed["decisions"]["capability_gate"][
            "status"
        ],
        "comparison_status": recomputed["decisions"]["comparison_status"],
        "scale_up_readiness": recomputed["decisions"]["scale_up_readiness"],
        "convergence_status": recomputed["decisions"]["convergence_status"],
        "evaluation_period_role": EVALUATION_PERIOD_ROLE,
        "checkpoint": dict(summary["checkpoint"]),
        "configuration": dict(summary["configuration"]),
        "inputs": dict(summary["inputs"]),
        "access_ledger": dict(ledger),
        "configuration_sha256": config_sha256,
        "prediction_archive_sha256": _sha256_file(prediction_path),
        "prediction_semantic_sha256": _sha256_arrays(arrays),
        "result_summary_sha256": _sha256_file(summary_path),
        "access_ledger_sha256": _sha256_file(ledger_path),
        "evaluation_manifest_sha256": _sha256_file(output_root / MANIFEST_FILE),
        "manifest_member_count": len(manifest["files"]),
        "recomputed": recomputed,
    }
    _atomic_json_no_replace(verification_output, report)
    return report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Independently verify the sealed A39 epoch-75 formal evaluation"
    )
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--output-root", required=True, type=Path)
    parser.add_argument("--verification-output", required=True, type=Path)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        report = verify_run(args.config, args.output_root, args.verification_output)
    except Exception as exc:  # one fail-closed command-line boundary
        print(f"INDEPENDENT_VERIFICATION_FAIL: {exc}", file=sys.stderr, flush=True)
        return 2
    print(
        "INDEPENDENT_VERIFICATION_PASS "
        f"capability={report['scientific_capability_gate']} "
        f"comparison={report['comparison_status']} "
        f"scale_up={report['scale_up_readiness']}",
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
