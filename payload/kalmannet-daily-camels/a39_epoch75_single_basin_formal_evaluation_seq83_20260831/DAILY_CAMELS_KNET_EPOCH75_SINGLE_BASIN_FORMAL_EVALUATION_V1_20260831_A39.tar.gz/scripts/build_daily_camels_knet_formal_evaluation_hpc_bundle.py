#!/usr/bin/env python3
"""Build the deterministic, evaluation-only A39 HPC bundle.

Only a development archive is copied into the bundle.  The historical
evaluation NPZ and the epoch-75 checkpoint remain external read-only
artifacts whose absolute paths and identities are recorded in the manifest.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import gzip
from hashlib import sha256
from io import BytesIO
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import tarfile
from typing import Any, Mapping
import uuid


ROOT = Path(__file__).resolve().parents[1]
SCHEMA_VERSION = "daily_camels_knet_formal_evaluation_hpc_bundle_v1"
ARCHIVE_SCHEMA_VERSION = "daily_camels_knet_formal_evaluation_hpc_archive_v1"
EXPERIMENT_ID = (
    "DAILY_CAMELS_KNET_EPOCH75_SINGLE_BASIN_FORMAL_EVALUATION_V1_20260831_A39"
)
CONFIG_MEMBER = "configs/daily_camels_knet_epoch75_formal_evaluation_a39.json"
REGISTRY_MEMBER = (
    "artifacts/daily_camels_knet_a39_formal_evaluation_bundle/"
    "A39_BUILD_20260831_01/experiment_registry.json"
)
FORMAL_PLAN_MEMBER = (
    "docs/superpowers/plans/"
    "2026-08-31-daily-camels-knet-epoch75-formal-evaluation.md"
)
FORMAL_PLAN_SHA256 = (
    "00ee29f683a41692f31ddfd5537d68150cf6a462b1fe8783e32d2fcffbfaa559"
)
NEXT_STAGE_PLAN_MEMBER = (
    "docs/superpowers/plans/2026-08-31-daily-camels-knet-21-basin-development.md"
)
NEXT_STAGE_PLAN_SHA256 = (
    "28fd091091deef2e81e242e5f9c5eed81e8ee8f94337c752e265dad3cd48e760"
)
EXECUTION_ID = (
    "DAILY_CAMELS_KNET_EPOCH75_SINGLE_BASIN_FORMAL_EVALUATION_"
    "A39_A800_EVAL1_SEQ83"
)
DEVELOPMENT_ARCHIVE_MEMBER = (
    "results/tukf06_full_diagonal_search_head_to_head_v1/"
    "selection_inputs/basin_09035800.npz"
)
DEVELOPMENT_ARCHIVE_SHA256 = (
    "71e6d163507ae405204bedf63d2c6c06e2c3ea303cea1a0481cfa4d5f280f5fd"
)
SELECTION_MEMBER = (
    "results/tukf06_full_diagonal_search_head_to_head_v1/"
    "selection/basin_09035800.json"
)
SELECTION_SHA256 = (
    "8b4888a62052f8d9f0018e907c665d30a72c4c7c29081763db0f4d46904ec3a2"
)
A38_SOURCE_MANIFEST_SHA256 = (
    "71edb4381b81d426f2e2128bf5588a52e7c3ed0e2ba3687974e8f1de669789da"
)
A38_SOURCE_EXPERIMENT_ID = (
    "DAILY_CAMELS_KNET_FIXED_FULL_TRAINING_COVERAGE_"
    "EPOCH40_TO80_RESUME_STEP_MONOTONICITY_DIAGNOSTIC_V1_20260828_A38"
)
CHECKPOINT_PATH = (
    "/data1/home/sunyiq/kalmannet_daily_camels_knet_a38_a800_train1_20260828/"
    "runs/DAILY_CAMELS_KNET_FIXED_FULL_TRAINING_COVERAGE_"
    "EPOCH40_TO80_RESUME_STEP_MONOTONICITY_DIAGNOSTIC_V1_20260828_A38/"
    "checkpoints/epoch_075.pt"
)
CHECKPOINT_SHA256 = (
    "7cc97138669531688dcd65d606d154330f260346c7c9c6e704cb1be5307a241b"
)
CHECKPOINT_SIZE = 4_260_296
EVALUATION_ARCHIVE_PATH = (
    "/data1/home/sunyiq/kalmannet_tukf06_20260809/retry2/results/"
    "tukf06_full_diagonal_search_head_to_head_v1/evaluation/"
    "basin_09035800.npz"
)
EVALUATION_ARCHIVE_SHA256 = (
    "59c0acc1afce14da7fe479fc5cdb6c6c4d2b18758d076c32950c5f2b3cfd3596"
)
EVALUATION_ARCHIVE_SIZE = 444_684
A38_TERMINAL_ARCHIVE_PATH = (
    "/data1/home/sunyiq/hpc_mailbox/outbox/kalmannet-daily-camels/"
    "DAILY_CAMELS_KNET_A38_JOB215801_TERMINAL_EVIDENCE_SEQ82.tar.gz"
)
A38_TERMINAL_ARCHIVE_SHA256 = (
    "72feda409ea3490ccd9a289b1313c9beb276c1cc267a15111dc19e63d5815317"
)
A38_TERMINAL_ARCHIVE_SIZE = 13_900_887


# Archive member -> source path relative to the isolated A38 snapshot root.
# The terminal checkpoint and historical evaluation archive are intentionally
# absent.  Additions must be explicit so an unrelated local file cannot leak.
FIXED_SOURCE_MEMBER_PATHS: dict[str, str] = {
    CONFIG_MEMBER: CONFIG_MEMBER,
    REGISTRY_MEMBER: REGISTRY_MEMBER,
    "artifacts/daily_camels_knet_a39_formal_evaluation_bundle/"
    "A39_BUILD_20260831_01/a38_source_bundle_manifest.json": "bundle_manifest.json",
    "configs/daily_camels_knet_epoch40_to80_resume_a38.json": (
        "configs/daily_camels_knet_epoch40_to80_resume_a38.json"
    ),
    "configs/tukf06_full_diagonal_search_head_to_head_v1.json": (
        "configs/tukf06_full_diagonal_search_head_to_head_v1.json"
    ),
    NEXT_STAGE_PLAN_MEMBER: NEXT_STAGE_PLAN_MEMBER,
    FORMAL_PLAN_MEMBER: FORMAL_PLAN_MEMBER,
    DEVELOPMENT_ARCHIVE_MEMBER: DEVELOPMENT_ARCHIVE_MEMBER,
    SELECTION_MEMBER: SELECTION_MEMBER,
    "hpc/daily_camels_knet_formal_evaluation/preflight.py": (
        "hpc/daily_camels_knet_formal_evaluation/preflight.py"
    ),
    "hpc/daily_camels_knet_formal_evaluation/submit_evaluation_gpu.slurm": (
        "hpc/daily_camels_knet_formal_evaluation/submit_evaluation_gpu.slurm"
    ),
    "knet/__init__.py": "knet/__init__.py",
    "knet/dl/__init__.py": "knet/dl/__init__.py",
    "knet/dl/nn_kalman_clamp_5.py": "knet/dl/nn_kalman_clamp_5.py",
    "scripts/__init__.py": "scripts/__init__.py",
    "scripts/build_daily_camels_knet_formal_evaluation_hpc_bundle.py": (
        "scripts/build_daily_camels_knet_formal_evaluation_hpc_bundle.py"
    ),
    "scripts/differentiable_ukf_hbvlite.py": (
        "scripts/differentiable_ukf_hbvlite.py"
    ),
    "scripts/run_aligned_gr4j_da.py": "scripts/run_aligned_gr4j_da.py",
    "scripts/run_aligned_gr4j_differentiable_ukf.py": (
        "scripts/run_aligned_gr4j_differentiable_ukf.py"
    ),
    "scripts/run_daily_camels_knet_epoch75_formal_evaluation.py": (
        "scripts/run_daily_camels_knet_epoch75_formal_evaluation.py"
    ),
    "scripts/tukf06_full_diagonal_common.py": (
        "scripts/tukf06_full_diagonal_common.py"
    ),
    "scripts/verify_daily_camels_knet_epoch75_formal_evaluation.py": (
        "scripts/verify_daily_camels_knet_epoch75_formal_evaluation.py"
    ),
    "src/global_hydrology/__init__.py": "src/global_hydrology/__init__.py",
    "src/global_hydrology/assimilation/__init__.py": (
        "src/global_hydrology/assimilation/__init__.py"
    ),
    "src/global_hydrology/assimilation/conventional_ukf.py": (
        "src/global_hydrology/assimilation/conventional_ukf.py"
    ),
    "src/global_hydrology/experiments/__init__.py": (
        "src/global_hydrology/experiments/__init__.py"
    ),
    "src/global_hydrology/experiments/daily_camels_native_knet_io.py": (
        "src/global_hydrology/experiments/daily_camels_native_knet_io.py"
    ),
    "src/global_hydrology/experiments/daily_camels_ukf_knet_parity_contract.py": (
        "src/global_hydrology/experiments/daily_camels_ukf_knet_parity_contract.py"
    ),
    "src/global_hydrology/experiments/daily_camels_ukf_knet_parity_runner.py": (
        "src/global_hydrology/experiments/daily_camels_ukf_knet_parity_runner.py"
    ),
    "src/global_hydrology/models/__init__.py": (
        "src/global_hydrology/models/__init__.py"
    ),
    "src/global_hydrology/models/differentiable_hbv_lite.py": (
        "src/global_hydrology/models/differentiable_hbv_lite.py"
    ),
    "src/global_hydrology/models/hbvlite_system_model.py": (
        "src/global_hydrology/models/hbvlite_system_model.py"
    ),
    "src/global_hydrology/models/hbvlite_ukf_adapter.py": (
        "src/global_hydrology/models/hbvlite_ukf_adapter.py"
    ),
    "src/global_hydrology/models/knet_native_hbvlite_full_state.py": (
        "src/global_hydrology/models/knet_native_hbvlite_full_state.py"
    ),
    "tests/conftest.py": "tests/conftest.py",
    "tests/test_daily_camels_knet_epoch75_formal_evaluation.py": (
        "tests/test_daily_camels_knet_epoch75_formal_evaluation.py"
    ),
    "tests/test_daily_camels_knet_formal_evaluation_hpc.py": (
        "tests/test_daily_camels_knet_formal_evaluation_hpc.py"
    ),
    "tests/test_verify_daily_camels_knet_epoch75_formal_evaluation.py": (
        "tests/test_verify_daily_camels_knet_epoch75_formal_evaluation.py"
    ),
}
FIXED_SOURCE_MEMBERS = frozenset(FIXED_SOURCE_MEMBER_PATHS)
EMPTY_PACKAGE_MEMBERS = frozenset(
    {
        "knet/__init__.py",
        "knet/dl/__init__.py",
        "scripts/__init__.py",
        "src/global_hydrology/__init__.py",
        "src/global_hydrology/assimilation/__init__.py",
        "src/global_hydrology/experiments/__init__.py",
        "src/global_hydrology/models/__init__.py",
    }
)
TEXT_SUFFIXES = frozenset({".json", ".py", ".sh", ".slurm", ".txt", ".csv"})


@dataclass(frozen=True)
class BundleManifest:
    archive_path: Path
    archive_sha256: str
    archive_size: int
    manifest_path: Path
    member_count: int
    member_sha256: dict[str, str]


@dataclass(frozen=True)
class ArchiveInspection:
    payloads: dict[str, bytes]
    manifest: dict[str, Any]


def _json_bytes(payload: Mapping[str, Any]) -> bytes:
    return (
        json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False)
        + "\n"
    ).encode("utf-8")


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_member_name(name: str) -> PurePosixPath:
    if not isinstance(name, str) or not name or "\\" in name:
        raise ValueError(f"unsafe bundle member: {name!r}")
    member = PurePosixPath(name)
    if member.is_absolute() or ".." in member.parts or ".git" in member.parts:
        raise ValueError(f"unsafe bundle member: {name}")
    lowered = tuple(part.lower() for part in member.parts)
    if member.suffix.lower() == ".pt":
        raise ValueError(f"checkpoint may not be packaged: {name}")
    if member.suffix.lower() == ".npz" and (
        "evaluation" in lowered
        or any("heldout" in part or "reserved" in part for part in lowered)
    ):
        raise ValueError(f"historical evaluation array may not be packaged: {name}")
    return member


def _load_json(path: Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return payload


def _validate_source_manifest(root: Path) -> dict[str, Any]:
    path = Path(root) / "bundle_manifest.json"
    if not path.is_file() or path.is_symlink():
        raise FileNotFoundError("the isolated A38 source manifest is absent")
    actual = sha256_file(path)
    if actual != A38_SOURCE_MANIFEST_SHA256:
        raise RuntimeError(
            "A38 source manifest SHA-256 differs: "
            f"expected {A38_SOURCE_MANIFEST_SHA256}, got {actual}"
        )
    payload = _load_json(path)
    if payload.get("experiment_id") != A38_SOURCE_EXPERIMENT_ID:
        raise RuntimeError("A38 source experiment identity differs")
    hashes = payload.get("member_sha256")
    sizes = payload.get("member_size")
    if not isinstance(hashes, Mapping) or not isinstance(sizes, Mapping):
        raise RuntimeError("A38 source manifest inventory is absent")
    return payload


def bundle_member_sources(root: Path = ROOT) -> dict[str, Path]:
    project_root = Path(root)
    source_manifest = _validate_source_manifest(project_root)
    old_hashes = source_manifest["member_sha256"]
    old_sizes = source_manifest["member_size"]
    sources: dict[str, Path] = {}
    for member, relative in sorted(FIXED_SOURCE_MEMBER_PATHS.items()):
        validate_member_name(member)
        source = project_root / relative
        if not source.is_file() or source.is_symlink():
            raise FileNotFoundError(f"bundle source is absent, non-regular, or symbolic: {source}")
        if relative == "bundle_manifest.json":
            expected_hash = A38_SOURCE_MANIFEST_SHA256
            expected_size = source.stat().st_size
        elif relative in old_hashes:
            expected_hash = old_hashes[relative]
            expected_size = old_sizes[relative]
        else:
            expected_hash = None
            expected_size = None
        actual_size = source.stat().st_size
        actual_hash = sha256_file(source)
        if expected_hash is not None and actual_hash != expected_hash:
            raise RuntimeError(f"frozen A38 source SHA-256 differs: {relative}")
        if expected_size is not None and actual_size != expected_size:
            raise RuntimeError(f"frozen A38 source size differs: {relative}")
        sources[member] = source
    return sources


def _validate_payload_contract(payloads: Mapping[str, bytes]) -> None:
    if set(payloads) != set(FIXED_SOURCE_MEMBERS):
        raise RuntimeError("bundle payload inventory differs from the explicit allowlist")
    npz_members = sorted(name for name in payloads if name.lower().endswith(".npz"))
    if npz_members != [DEVELOPMENT_ARCHIVE_MEMBER]:
        raise RuntimeError("bundle must contain exactly one development-only NPZ")
    if sha256(payloads[DEVELOPMENT_ARCHIVE_MEMBER]).hexdigest() != DEVELOPMENT_ARCHIVE_SHA256:
        raise RuntimeError("development archive SHA-256 differs")
    if sha256(payloads[SELECTION_MEMBER]).hexdigest() != SELECTION_SHA256:
        raise RuntimeError("selection evidence SHA-256 differs")
    if any(name.lower().endswith(".pt") for name in payloads):
        raise RuntimeError("a checkpoint entered the A39 bundle")
    for member in EMPTY_PACKAGE_MEMBERS:
        if payloads[member] != b"":
            raise RuntimeError(f"package initializer is not empty: {member}")
    config = json.loads(payloads[CONFIG_MEMBER].decode("utf-8"))
    registry = json.loads(payloads[REGISTRY_MEMBER].decode("utf-8"))
    if not isinstance(config, dict) or not isinstance(registry, dict):
        raise RuntimeError("A39 config or registry root is not an object")
    if config.get("experiment_id") != EXPERIMENT_ID:
        raise RuntimeError("A39 config experiment identity differs")
    policy = config.get("execution_policy")
    if not isinstance(policy, Mapping) or any(
        policy.get(field) is not False
        for field in (
            "allow_training",
            "allow_optimizer_updates",
            "allow_checkpoint_writes",
            "allow_checkpoint_selection",
            "allow_hyperparameter_tuning",
        )
    ):
        raise RuntimeError("A39 config permits training, writing, selection, or tuning")
    source_files = config.get("source_files")
    if not isinstance(source_files, Mapping) or not source_files:
        raise RuntimeError("A39 config source inventory is absent")
    if "scripts/run_daily_camels_ukf_knet_parity.py" in source_files:
        raise RuntimeError("old training entry re-entered the A39 source inventory")
    for member, expected in source_files.items():
        if member not in payloads or sha256(payloads[member]).hexdigest() != expected:
            raise RuntimeError(f"A39 declared source identity differs: {member}")
    if (
        registry.get("experiment_id") != EXPERIMENT_ID
        or registry.get("execution_attempt_id") != EXECUTION_ID
    ):
        raise RuntimeError("A39 registry identity differs")
    plans = registry.get("frozen_documents")
    if not isinstance(plans, Mapping):
        raise RuntimeError("A39 registry plans are absent")
    expected_plan_bindings = {
        "formal_evaluation_plan": FORMAL_PLAN_MEMBER,
        "formal_evaluation_plan_sha256": FORMAL_PLAN_SHA256,
        "next_stage_plan": NEXT_STAGE_PLAN_MEMBER,
        "next_stage_plan_sha256": NEXT_STAGE_PLAN_SHA256,
        "active_configuration": CONFIG_MEMBER,
        "active_configuration_sha256": sha256(payloads[CONFIG_MEMBER]).hexdigest(),
    }
    for field, expected in expected_plan_bindings.items():
        if plans.get(field) != expected:
            raise RuntimeError(f"A39 registry binding differs: {field}")
    if sha256(payloads[FORMAL_PLAN_MEMBER]).hexdigest() != FORMAL_PLAN_SHA256:
        raise RuntimeError("formal evaluation plan SHA-256 differs")
    if sha256(payloads[NEXT_STAGE_PLAN_MEMBER]).hexdigest() != NEXT_STAGE_PLAN_SHA256:
        raise RuntimeError("next-stage plan SHA-256 differs")
    slurm = payloads[
        "hpc/daily_camels_knet_formal_evaluation/submit_evaluation_gpu.slurm"
    ].decode("utf-8")
    lowered = "\n".join(
        line for line in slurm.lower().splitlines() if not line.lstrip().startswith("#")
    )
    for forbidden in (
        "sbatch ",
        "scancel ",
        "scontrol update",
        "optimizer.step",
        ".backward(",
        "submit_train",
        "run_training",
    ):
        if forbidden in lowered:
            raise RuntimeError(f"Slurm entry contains forbidden operation: {forbidden}")


def build_internal_manifest(payloads: Mapping[str, bytes]) -> dict[str, Any]:
    _validate_payload_contract(payloads)
    member_sha256 = {
        name: sha256(content).hexdigest() for name, content in sorted(payloads.items())
    }
    member_size = {name: len(content) for name, content in sorted(payloads.items())}
    return {
        "schema_version": SCHEMA_VERSION,
        "experiment_id": EXPERIMENT_ID,
        "purpose": "single_basin_epoch75_formal_evaluation_only",
        "active_config_member": CONFIG_MEMBER,
        "experiment_registry_member": REGISTRY_MEMBER,
        "member_count": len(payloads),
        "member_sha256": member_sha256,
        "member_size": member_size,
        "npz_members": [DEVELOPMENT_ARCHIVE_MEMBER],
        "development_archive_count": 1,
        "historical_evaluation_array_member_count": 0,
        "checkpoint_member_count": 0,
        "training_entry_count": 0,
        "array_members_materialized_during_build": 0,
        "source_a38_bundle_manifest_sha256": A38_SOURCE_MANIFEST_SHA256,
        "external_artifacts": {
            "checkpoint": {
                "path": CHECKPOINT_PATH,
                "sha256": CHECKPOINT_SHA256,
                "size": CHECKPOINT_SIZE,
            },
            "evaluation_archive": {
                "path": EVALUATION_ARCHIVE_PATH,
                "sha256": EVALUATION_ARCHIVE_SHA256,
                "size": EVALUATION_ARCHIVE_SIZE,
                "packaged": False,
            },
            "a38_terminal_evidence_archive": {
                "path": A38_TERMINAL_ARCHIVE_PATH,
                "sha256": A38_TERMINAL_ARCHIVE_SHA256,
                "size": A38_TERMINAL_ARCHIVE_SIZE,
                "packaged": False,
                "opened_as": "opaque_bytes_only",
            },
        },
        "resource_admission": {
            "host_memory_min_bytes": 2_800_353_280,
            "gpu_free_memory_min_mib": 4_584,
        },
    }


def deterministic_archive_bytes(
    payloads: Mapping[str, bytes], manifest: Mapping[str, Any]
) -> bytes:
    complete = dict(payloads)
    if "bundle_manifest.json" in complete:
        raise ValueError("payloads may not predefine bundle_manifest.json")
    complete["bundle_manifest.json"] = _json_bytes(manifest)
    compressed = BytesIO()
    with gzip.GzipFile(fileobj=compressed, mode="wb", filename="", mtime=0) as gzip_file:
        with tarfile.open(fileobj=gzip_file, mode="w", format=tarfile.PAX_FORMAT) as archive:
            for name in sorted(complete, key=lambda item: (item == "bundle_manifest.json", item)):
                validate_member_name(name)
                content = complete[name]
                info = tarfile.TarInfo(name=name)
                info.size = len(content)
                info.mode = 0o644
                info.uid = 0
                info.gid = 0
                info.uname = ""
                info.gname = ""
                info.mtime = 0
                info.pax_headers = {}
                archive.addfile(info, BytesIO(content))
    return compressed.getvalue()


def inspect_archive(path: Path) -> ArchiveInspection:
    payloads: dict[str, bytes] = {}
    with tarfile.open(Path(path), mode="r:gz") as archive:
        members = archive.getmembers()
        names = [member.name for member in members]
        if len(names) != len(set(names)):
            raise RuntimeError("archive contains duplicate members")
        expected_order = sorted(names, key=lambda item: (item == "bundle_manifest.json", item))
        if names != expected_order:
            raise RuntimeError("archive member order is not deterministic")
        for member in members:
            validate_member_name(member.name)
            if (
                not member.isfile()
                or member.mtime != 0
                or member.uid != 0
                or member.gid != 0
                or member.mode != 0o644
            ):
                raise RuntimeError(f"archive metadata is not normalized: {member.name}")
            handle = archive.extractfile(member)
            if handle is None:
                raise RuntimeError(f"archive member cannot be read: {member.name}")
            payloads[member.name] = handle.read()
    raw_manifest = payloads.pop("bundle_manifest.json", None)
    if raw_manifest is None:
        raise RuntimeError("archive internal manifest is absent")
    manifest = json.loads(raw_manifest.decode("utf-8"))
    if not isinstance(manifest, dict):
        raise RuntimeError("archive internal manifest root differs")
    if manifest.get("schema_version") != SCHEMA_VERSION:
        raise RuntimeError("archive schema differs")
    if manifest.get("member_sha256") != {
        name: sha256(content).hexdigest() for name, content in sorted(payloads.items())
    }:
        raise RuntimeError("archive member hashes differ")
    if manifest.get("member_size") != {
        name: len(content) for name, content in sorted(payloads.items())
    }:
        raise RuntimeError("archive member sizes differ")
    _validate_payload_contract(payloads)
    return ArchiveInspection(payloads=payloads, manifest=manifest)


def _write_new(path: Path, content: bytes) -> None:
    with Path(path).open("xb") as handle:
        handle.write(content)
        handle.flush()
        os.fsync(handle.fileno())


def build_bundle(destination: Path, *, root: Path = ROOT) -> BundleManifest:
    destination = Path(destination)
    if destination.exists() or destination.is_symlink():
        raise FileExistsError(f"refusing to replace bundle destination: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    sources = bundle_member_sources(root)
    payloads = {name: source.read_bytes() for name, source in sorted(sources.items())}
    manifest = build_internal_manifest(payloads)
    archive_content = deterministic_archive_bytes(payloads, manifest)
    archive_name = f"{EXPERIMENT_ID}.tar.gz"
    outer_manifest = {
        "schema_version": ARCHIVE_SCHEMA_VERSION,
        "experiment_id": EXPERIMENT_ID,
        "archive_name": archive_name,
        "archive_sha256": sha256(archive_content).hexdigest(),
        "archive_size": len(archive_content),
        "member_count": len(payloads),
        "internal_manifest_sha256": sha256(_json_bytes(manifest)).hexdigest(),
        "external_artifacts": manifest["external_artifacts"],
        "historical_evaluation_array_member_count": 0,
        "checkpoint_member_count": 0,
    }
    manifest_content = _json_bytes(outer_manifest)
    staging = destination.parent / f".{destination.name}.pending-{uuid.uuid4().hex}"
    if staging.exists() or staging.is_symlink():
        raise FileExistsError(f"unexpected bundle staging collision: {staging}")
    try:
        staging.mkdir(mode=0o700)
        archive_path = staging / archive_name
        manifest_path = staging / "bundle_manifest.sha256.json"
        _write_new(archive_path, archive_content)
        _write_new(manifest_path, manifest_content)
        inspection = inspect_archive(archive_path)
        if inspection.manifest != manifest:
            raise RuntimeError("archive round-trip manifest differs")
        if destination.exists() or destination.is_symlink():
            raise FileExistsError(f"refusing to replace bundle destination: {destination}")
        os.replace(staging, destination)
    finally:
        if staging.exists():
            shutil.rmtree(staging)
    return BundleManifest(
        archive_path=destination / archive_name,
        archive_sha256=outer_manifest["archive_sha256"],
        archive_size=outer_manifest["archive_size"],
        manifest_path=destination / "bundle_manifest.sha256.json",
        member_count=len(payloads),
        member_sha256=dict(manifest["member_sha256"]),
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--destination", type=Path, required=True)
    parser.add_argument("--root", type=Path, default=ROOT)
    return parser


def main(argv: list[str] | None = None) -> int:
    arguments = build_parser().parse_args(argv)
    result = build_bundle(arguments.destination, root=arguments.root)
    print(
        json.dumps(
            {
                "archive_path": str(result.archive_path),
                "archive_sha256": result.archive_sha256,
                "archive_size": result.archive_size,
                "manifest_path": str(result.manifest_path),
                "member_count": result.member_count,
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
