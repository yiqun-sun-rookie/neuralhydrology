# Daily CAMELS KalmanNet 21-Basin Development Stage Implementation Plan

> **For Codex:** This plan is frozen before opening the A39 single-basin historical evaluation values. Do not revise basin membership, model-selection rules, or thresholds in response to A39 results. Preserve the dirty main worktree and all historical outputs.

**Goal:** Extend the existing daily KalmanNet scientific question from the completed 18-state basin 09035800 route to the already frozen 21-basin TUKF06 set using development data only, while keeping each basin's state geometry, causal information timing, loss, and baseline comparison auditable.

**Architecture:** Use one independently trained KalmanNet per basin because the frozen set contains 7-, 11-, and 18-state HBV routes. Establish dimension support with one representative basin per state dimension, then train all 21 basins with the same development-only schedule and seal all checkpoints before any aggregate historical evaluation. Do not transfer the 18-state checkpoint to another state dimension and do not use A39 evaluation values to choose architecture or basin membership.

**Tech Stack:** Python 3.11, NumPy, PyTorch, pytest, JSON/NPZ evidence, SHA-256 manifests, Slurm, A800 GPUs, and `hpc-mailbox`.

---

## Frozen scope

- Basins, in fixed order: `04105700`, `08190500`, `02102908`, `12447390`, `01487000`, `02178400`, `08070200`, `09513780`, `06803510`, `03076600`, `12175500`, `09035800`, `04027000`, `08109700`, `08086290`, `01440400`, `05503800`, `03049000`, `01435000`, `02092500`, `14185900`.
- State dimensions: sixteen 7-state basins, four 11-state basins, and one 18-state basin.
- Training period: `1999-10-01` through `2006-09-30`.
- Development validation period: `2006-10-01` through `2008-09-30`.
- Forecast leads: 1, 2, and 3 days with perfect future meteorological forcing, as in A38.
- Training/checkpoint objective: equal-lead physical-unit mean squared error.
- Development metrics: physical-unit mean squared error and population Nash-Sutcliffe efficiency on the existing common 16-day filter warm-up geometry.
- Random seed, optimizer family, learning rate, weight decay, gradient clipping, feature scaling, segment sampling, epoch ceiling 80, and gate logic are inherited from A38 unless a dimension-support test proves a purely structural incompatibility before any new basin training.
- Historical evaluation data may not be used during this stage. Basin inclusion, adapter rules, epoch ceiling, checkpoint selection, and failure handling are fixed before A39 values are read.

## Task 1: Recover exact A38 implementation evidence

1. Start from the A38 terminal source snapshot and pin the A38 configuration, source hashes, epoch history, and result summary.
2. Separate dimension-independent architecture rules from the hard-coded 18-state assertions.
3. Do not edit the A38 experiment or reclassify its result.

## Task 2: Add dimension-geometry tests first

1. Add synthetic 7-, 11-, and 18-state tests for correction masks, inactive routing coordinates, feature scaling, forecast alignment, checkpoint serialization, and continuation identity.
2. Reject padding that permits inactive routed states to change; each basin uses its exact active state dimension.
3. Reject loading a checkpoint from another basin or another state dimension.

## Task 3: Run three development-only technical pilots

1. Choose representatives by the frozen basin order, not performance: first 7-state basin `04105700`, first 11-state basin `08070200`, and the existing 18-state basin `09035800` as a replay control.
2. Use new identifiers and isolated outputs; never overwrite A38.
3. Require finite forward/backward execution, exact event counts, parameter changes after epoch zero, independent verification, and zero historical-evaluation access.
4. A technical failure may receive a minimal structural repair that applies uniformly to all basins of that state dimension; a scientific failure is reported without tuning.

## Task 4: Freeze and train all 21 development models

1. Create one immutable configuration and output root per basin under one registered experiment family.
2. Train each basin independently to the fixed epoch-80 ceiling; select its checkpoint only by the frozen development objective.
3. Save atomic checkpoints, epoch histories, predictions, resource peaks, access ledgers, and manifests.
4. Resume only from the last verified atomic checkpoint without repeating optimizer-step or forecast-event counts.
5. Seal every basin before aggregate analysis; partial completion cannot be reported as a 21-basin result.

## Task 5: Development-only aggregate decision

1. Independently recompute every basin's lead-wise mean squared error and Nash-Sutcliffe efficiency from raw aligned predictions.
2. Report failures and all basins in the frozen order; do not discard difficult basins.
3. Separate technical completion, per-basin candidate capability, KalmanNet-versus-UKF comparison, and convergence state.
4. If all 21 models are sealed, prepare a one-shot historical evaluation contract using the same 365-day warm-up and common masks. The A39 basin 09035800 result must be labelled previously exposed for KalmanNet; it cannot be described as a fresh confirmation.

## Task 6: Formal multi-basin evaluation boundary

1. Do not open historical arrays until all 21 models, baseline parameters, masks, thresholds, bootstrap seed, and output identities are sealed.
2. Primary aggregate: for each basin, average the three lead-wise `KalmanNet NSE - causal selected-UKF NSE` differences; then take the median across the fixed basin set.
3. Practical thresholds are fixed before access: at least `+0.01` indicates a KalmanNet advantage, at most `-0.01` indicates a UKF advantage, and the interval between them indicates no discernible advantage.
4. Report a paired 10,000-resample bootstrap interval with seed `20260809`, the number of negative-gain basins, and lead-1 catastrophic regressions below `-0.10`; these do not change the threshold after the fact.

## Unique next action after A39

Implement only the dimension-geometry tests and three development-only pilots. Do not submit the 21-basin campaign or historical evaluation until those pilots are independently verified.
