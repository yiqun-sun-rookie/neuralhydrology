from __future__ import annotations

import dataclasses
from datetime import date, timedelta
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[1]
CONTRACT_PATH = (
    ROOT
    / "src"
    / "global_hydrology"
    / "experiments"
    / "daily_camels_ukf_knet_parity_contract.py"
)
_SPEC = importlib.util.spec_from_file_location(
    "daily_camels_ukf_knet_parity_contract_standalone", CONTRACT_PATH
)
if _SPEC is None or _SPEC.loader is None:
    raise RuntimeError("cannot load standalone daily parity contract")
_CONTRACT = importlib.util.module_from_spec(_SPEC)
sys.modules[_SPEC.name] = _CONTRACT
_SPEC.loader.exec_module(_CONTRACT)

ALLOWED_ARCHIVE_MEMBERS = _CONTRACT.ALLOWED_ARCHIVE_MEMBERS
CAUSAL_SHARED_SPINUP_MODE = _CONTRACT.CAUSAL_SHARED_SPINUP_MODE
EXACT_TUKF06_DIAGNOSTIC_MODE = _CONTRACT.EXACT_TUKF06_DIAGNOSTIC_MODE
AccessLedger = _CONTRACT.AccessLedger
ParityContract = _CONTRACT.ParityContract
fixed_scoring_window = _CONTRACT.fixed_scoring_window
performance_gate = _CONTRACT.performance_gate
validate_initialization_usage = _CONTRACT.validate_initialization_usage


def valid_payload() -> dict[str, object]:
    return {
        "schema_version": "daily_camels_ukf_knet_parity_v1",
        "experiment_family": "DAILY_CAMELS_UKF_KNET_PARITY_V1",
        "basin_id": "09035800",
        "data": {
            "cadence": "daily",
            "development_period": ["1999-10-01", "2008-09-30"],
            "expected_days": 3288,
            "archive_sha256": (
                "71e6d163507ae405204bedf63d2c6c06e2c3ea303cea1a0481cfa4d5f280f5fd"
            ),
            "archive_members": sorted(ALLOWED_ARCHIVE_MEMBERS),
        },
        "forecast": {
            "leads_days": [1, 2, 3],
            "information_timing": "perfect_future_meteorological_forcing",
            "diagnostic_window_days": 128,
            "recovery_window_days": 731,
            "filter_warmup_days": 16,
            "expected_diagnostic_target_count_per_lead": 109,
            "expected_recovery_target_count_per_lead": 712,
        },
        "model": {
            "state_dimension": 18,
            "official_knet_source": "knet/dl/nn_kalman_clamp_5.py",
            "official_knet_sha256": (
                "934570d3c840e9d57b8fbddf3a018dc29e190cdd712fc9daaf442e383f74d843"
            ),
            "full_state_adapter": (
                "src/global_hydrology/models/knet_native_hbvlite_full_state.py"
            ),
            "numeric_dtype": "float64",
            "gain_network_numeric_dtype": "float32",
            "residual_memory_order": 0,
            "preset_residual_gain_enabled": False,
            "static_attributes_enabled": False,
            "learned_physical_parameters_enabled": False,
            "correction_cap_enabled": False,
        },
        "initialization": {
            "allowed_modes": [
                EXACT_TUKF06_DIAGNOSTIC_MODE,
                CAUSAL_SHARED_SPINUP_MODE,
            ],
            "scientific_mode": CAUSAL_SHARED_SPINUP_MODE,
        },
        "optimization": {
            "training_objective": "physical_unit_multilead_mse",
            "checkpoint_objective": "physical_unit_multilead_mse",
            "nonfinite_forecast_policy": (
                "hard_fail_before_target_missingness_mask"
            ),
            "minimum_post_zero_improvement": 1e-6,
        },
        "gate": {
            "minimum_nse_exclusive": 0.6,
            "require_each_lead": True,
            "require_post_epoch_zero_improvement": True,
        },
    }


def test_contract_freezes_same_basin_full_state_official_knet_and_objective() -> None:
    contract = ParityContract.from_dict(valid_payload())

    assert contract.basin_id == "09035800"
    assert contract.leads == (1, 2, 3)
    assert contract.state_dimension == 18
    assert contract.official_knet_source == "knet/dl/nn_kalman_clamp_5.py"
    assert contract.full_state_adapter.endswith("knet_native_hbvlite_full_state.py")
    assert contract.physical_numeric_dtype == "float64"
    assert contract.gain_network_numeric_dtype == "float32"
    assert contract.training_objective == contract.checkpoint_objective
    assert contract.nonfinite_forecast_policy == (
        "hard_fail_before_target_missingness_mask"
    )
    assert contract.minimum_nse_exclusive == pytest.approx(0.6)
    with pytest.raises(dataclasses.FrozenInstanceError):
        contract.state_dimension = 5  # type: ignore[misc]


def test_repository_config_pins_native_default_full_state_and_current_sources() -> None:
    root = Path(__file__).resolve().parents[1]
    payload = json.loads(
        (
            root
            / "configs/daily_camels_ukf_knet_parity_exact_replay_dtype_repair_v3.json"
        ).read_text(
            encoding="utf-8"
        )
    )

    contract = ParityContract.from_dict(payload)

    assert contract.state_dimension == 18
    assert payload["model"]["gain_initialization"] == "native_default"
    assert payload["model"]["numeric_dtype"] == "float64"
    assert payload["model"]["gain_network_numeric_dtype"] == "float32"
    assert payload["model"]["projection"] == (
        "tukf06_nonnegative_with_soil_field_capacity_only"
    )
    assert payload["initialization"]["execution_mode"] == (
        EXACT_TUKF06_DIAGNOSTIC_MODE
    )
    for relative, expected in payload["source_sha256"].items():
        assert sha256((root / relative).read_bytes()).hexdigest() == expected


@pytest.mark.parametrize(
    ("section", "key", "value", "message"),
    [
        ("", "basin_id", "04105700", "09035800"),
        ("data", "cadence", "hourly", "daily"),
        ("data", "expected_days", 3287, "3,288"),
        ("forecast", "leads_days", [1, 2], "1, 2, and 3"),
        ("forecast", "diagnostic_window_days", 127, "128-day"),
        ("forecast", "recovery_window_days", 730, "731-day"),
        ("forecast", "filter_warmup_days", 15, "16-day"),
        (
            "forecast",
            "expected_diagnostic_target_count_per_lead",
            108,
            "109",
        ),
        (
            "forecast",
            "expected_recovery_target_count_per_lead",
            711,
            "712",
        ),
        ("model", "state_dimension", 5, "18"),
        ("model", "numeric_dtype", "float32", "physical runtime.*float64"),
        (
            "model",
            "gain_network_numeric_dtype",
            "float64",
            "gain core.*float32",
        ),
        ("model", "residual_memory_order", 2, "residual memory"),
        ("model", "preset_residual_gain_enabled", True, "preset residual gain"),
        ("model", "static_attributes_enabled", True, "static attributes"),
        ("model", "learned_physical_parameters_enabled", True, "physical parameters"),
        ("model", "correction_cap_enabled", True, "correction cap"),
        (
            "optimization",
            "checkpoint_objective",
            "gain_over_ar2",
            "same physical-unit",
        ),
        (
            "optimization",
            "nonfinite_forecast_policy",
            "mask_nonfinite_forecasts",
            "hard-fail",
        ),
        ("gate", "minimum_nse_exclusive", 0.59, "0.6"),
    ],
)
def test_contract_rejects_unfair_or_weakened_comparison(
    section: str, key: str, value: object, message: str
) -> None:
    payload = valid_payload()
    destination = payload if not section else payload[section]
    assert isinstance(destination, dict)
    destination[key] = value

    with pytest.raises(ValueError, match=message):
        ParityContract.from_dict(payload)


def test_archive_contract_restores_all_tukf06_state_evidence() -> None:
    contract = ParityContract.from_dict(valid_payload())

    assert set(contract.archive_members) == {
        "dates_ns",
        "forcing",
        "observations",
        "parameters",
        "initial_storage_state",
        "initial_state",
        "initial_covariance",
        "base_observation_variance",
        "state_dimension",
    }

    payload = valid_payload()
    payload["data"]["archive_members"] = [  # type: ignore[index]
        member
        for member in sorted(ALLOWED_ARCHIVE_MEMBERS)
        if member != "initial_state"
    ]
    with pytest.raises(ValueError, match="archive members"):
        ParityContract.from_dict(payload)


def test_diagnostic_window_matches_failed_smoke_dates_and_target_counts() -> None:
    contract = ParityContract.from_dict(valid_payload())
    window = fixed_scoring_window(contract, purpose="diagnostic")
    start = date.fromisoformat(contract.development_start)

    assert window.window_start_index == 2557
    assert window.window_end_exclusive == 2685
    assert start + timedelta(days=window.window_start_index) == date(2006, 10, 1)
    assert window.issue_start_index == 2573
    assert window.issue_end_exclusive == 2682
    assert start + timedelta(days=window.issue_start_index) == date(2006, 10, 17)
    assert start + timedelta(days=window.issue_end_exclusive - 1) == date(2007, 2, 2)
    assert window.target_count_by_lead == {1: 109, 2: 109, 3: 109}
    assert window.first_target_index_by_lead == {1: 2574, 2: 2575, 3: 2576}
    assert window.last_target_index_by_lead == {1: 2682, 2: 2683, 3: 2684}
    assert start + timedelta(days=window.last_target_index_by_lead[3]) == date(2007, 2, 5)


def test_recovery_window_uses_complete_existing_development_validation_period() -> None:
    contract = ParityContract.from_dict(valid_payload())
    window = fixed_scoring_window(contract, purpose="recovery")
    start = date.fromisoformat(contract.development_start)

    assert window.window_start_index == 2557
    assert window.window_end_exclusive == 3288
    assert start + timedelta(days=window.window_start_index) == date(2006, 10, 1)
    assert start + timedelta(days=window.window_end_exclusive - 1) == date(2008, 9, 30)
    assert window.issue_start_index == 2573
    assert window.issue_end_exclusive == 3285
    assert window.target_count_by_lead == {1: 712, 2: 712, 3: 712}
    assert window.first_target_index_by_lead == {1: 2574, 2: 2575, 3: 2576}
    assert window.last_target_index_by_lead == {1: 3285, 2: 3286, 3: 3287}


def test_initialization_modes_separate_reproduction_from_scientific_claim() -> None:
    diagnostic = validate_initialization_usage(
        EXACT_TUKF06_DIAGNOSTIC_MODE,
        used_archive_members={
            "initial_storage_state",
            "initial_state",
            "initial_covariance",
        },
    )
    assert diagnostic.scientific_claim_allowed is False
    assert diagnostic.backward_time_leakage is True

    causal = validate_initialization_usage(
        CAUSAL_SHARED_SPINUP_MODE,
        used_archive_members=set(),
    )
    assert causal.scientific_claim_allowed is True
    assert causal.backward_time_leakage is False

    with pytest.raises(ValueError, match="requires archived"):
        validate_initialization_usage(
            EXACT_TUKF06_DIAGNOSTIC_MODE,
            used_archive_members={"initial_state"},
        )
    with pytest.raises(ValueError, match="causal mode forbids"):
        validate_initialization_usage(
            CAUSAL_SHARED_SPINUP_MODE,
            used_archive_members={"initial_state"},
        )


def test_access_ledger_allows_development_archive_but_refuses_reserved_evaluation() -> None:
    ledger = AccessLedger()
    for member in ALLOWED_ARCHIVE_MEMBERS:
        ledger.record_archive_member(member)

    assert ledger.archive_member_reads == {
        member: 1 for member in ALLOWED_ARCHIVE_MEMBERS
    }
    assert ledger.evaluation_array_reads == 0
    assert ledger.evaluation_prediction_count == 0
    assert ledger.evaluation_metric_count == 0
    assert ledger.evaluation_output_count == 0

    with pytest.raises(PermissionError, match="reserved evaluation"):
        ledger.record_date_request("1989-10-01", "1999-09-30")
    with pytest.raises(PermissionError, match="reserved evaluation"):
        ledger.record_evaluation_operation("metric")
    with pytest.raises(PermissionError, match="not allowlisted"):
        ledger.record_archive_member("evaluation_observations")


def test_performance_gate_requires_every_lead_and_real_post_zero_improvement() -> None:
    passing = performance_gate(
        epoch_zero_objective=10.0,
        best_objective=9.0,
        best_epoch=2,
        nse_by_lead={1: 0.61, 2: 0.70, 3: 0.6001},
        target_count_by_lead={1: 712, 2: 712, 3: 712},
        contract=ParityContract.from_dict(valid_payload()),
    )
    assert passing.passed is True

    epoch_zero_best = performance_gate(
        epoch_zero_objective=10.0,
        best_objective=10.0,
        best_epoch=0,
        nse_by_lead={1: 0.9, 2: 0.9, 3: 0.9},
        target_count_by_lead={1: 712, 2: 712, 3: 712},
        contract=ParityContract.from_dict(valid_payload()),
    )
    assert epoch_zero_best.passed is False
    assert "post_epoch_zero_improvement" in epoch_zero_best.failed_gates

    one_lead_at_threshold = performance_gate(
        epoch_zero_objective=10.0,
        best_objective=9.0,
        best_epoch=2,
        nse_by_lead={1: 0.9, 2: 0.6, 3: 0.9},
        target_count_by_lead={1: 712, 2: 712, 3: 712},
        contract=ParityContract.from_dict(valid_payload()),
    )
    assert one_lead_at_threshold.passed is False
    assert "nse_above_0.6_each_lead" in one_lead_at_threshold.failed_gates
