from __future__ import annotations

import importlib.util
import math
from pathlib import Path
from types import SimpleNamespace
import subprocess
import sys

import pytest


ROOT = Path(__file__).resolve().parents[1]
ENTRY_PATH = ROOT / "scripts" / "run_daily_camels_ukf_knet_parity.py"
MODULE_NAME = "daily_camels_ukf_knet_parity_entry_standalone"


def _load_entry_module():
    numerical_modules_before = {
        name: name in sys.modules for name in ("numpy", "torch")
    }
    spec = importlib.util.spec_from_file_location(MODULE_NAME, ENTRY_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load standalone daily parity entry")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    numerical_modules_after = {
        name: name in sys.modules for name in ("numpy", "torch")
    }
    assert numerical_modules_after == numerical_modules_before
    return module


ENTRY = _load_entry_module()


def test_entry_imports_without_numerical_modules_in_clean_subprocess() -> None:
    program = f"""
import importlib.util
from pathlib import Path
import sys
path = Path({str(ENTRY_PATH)!r})
spec = importlib.util.spec_from_file_location({MODULE_NAME!r}, path)
assert spec is not None and spec.loader is not None
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
assert 'numpy' not in sys.modules
assert 'torch' not in sys.modules
"""
    completed = subprocess.run(
        [sys.executable, "-I", "-c", program],
        check=False,
        capture_output=True,
        text=True,
    )
    assert completed.returncode == 0, completed.stderr


def _validation() -> SimpleNamespace:
    return SimpleNamespace(
        full_objective_without_warmup=10.0,
        objective=8.0,
        mse_by_lead={1: 7.0, 2: 8.0, 3: 9.0},
        nse_by_lead={1: 0.7, 2: 0.65, 3: 0.61},
        target_count_by_lead={1: 712, 2: 712, 3: 712},
        full_target_count_by_lead_without_warmup={1: 728, 2: 728, 3: 728},
    )


def test_epoch_diagnostics_preserve_equal_lead_training_weights() -> None:
    diagnostics = ENTRY._summarize_epoch_training_diagnostics(
        {1: [1.0, 3.0], 2: [2.0, 6.0], 3: [4.0, 8.0]},
        {1: 204, 2: 200, 3: 190},
        gradient_clipped_optimizer_step_count=1,
        optimizer_step_count=2,
    )

    assert diagnostics[
        "training_mse_by_lead_physical_unit_mean_over_optimizer_steps"
    ] == {1: 2.0, 2: 4.0, 3: 6.0}
    assert diagnostics["training_sampled_finite_target_event_count_by_lead"] == {
        1: 204,
        2: 200,
        3: 190,
    }
    assert diagnostics["epoch_optimizer_step_count"] == 2
    assert diagnostics["gradient_clipped_optimizer_step_count"] == 1
    assert diagnostics["gradient_clipped_optimizer_step_fraction"] == 0.5
    reconstructed = math.fsum(
        diagnostics[
            "training_mse_by_lead_physical_unit_mean_over_optimizer_steps"
        ].values()
    ) / 3
    assert reconstructed == 4.0


def test_epoch_zero_uses_explicit_no_training_sentinels() -> None:
    diagnostics = ENTRY._summarize_epoch_training_diagnostics(
        {1: (), 2: (), 3: ()},
        {1: 0, 2: 0, 3: 0},
        gradient_clipped_optimizer_step_count=0,
        optimizer_step_count=0,
    )

    assert diagnostics[
        "training_mse_by_lead_physical_unit_mean_over_optimizer_steps"
    ] is None
    assert diagnostics["training_sampled_finite_target_event_count_by_lead"] == {
        1: 0,
        2: 0,
        3: 0,
    }
    assert diagnostics["epoch_optimizer_step_count"] == 0
    assert diagnostics["gradient_clipped_optimizer_step_count"] == 0
    assert diagnostics["gradient_clipped_optimizer_step_fraction"] is None

    row = ENTRY._history_row(
        epoch=0,
        training_objective=None,
        validation=_validation(),
        parameter_sha256="0" * 64,
        optimizer_steps=0,
        forecast_events=0,
        gradient_names=(),
        maximum_gradient_norm_before_clip=None,
        training_diagnostics=diagnostics,
        prediction_sha256="1" * 64,
    )
    assert row["training_objective_physical_unit_multilead_mse"] is None
    assert row[
        "training_mse_by_lead_physical_unit_mean_over_optimizer_steps"
    ] is None
    assert row["training_sampled_finite_target_event_count_by_lead"] == {
        1: 0,
        2: 0,
        3: 0,
    }
    assert row["epoch_optimizer_step_count"] == 0
    assert row["finite_gradients"] is None

    event = ENTRY._epoch_completed_event(
        epoch=0,
        training_objective=None,
        checkpoint_selection_objective=10.0,
        gate_objective=8.0,
        checkpoint_sha256="4" * 64,
        parameter_sha256="0" * 64,
        optimizer_steps=0,
        sampled_forecast_events=0,
        training_diagnostics=diagnostics,
    )
    assert event["training_objective"] is None
    assert event["optimizer_steps"] == 0
    assert event["sampled_forecast_events"] == 0
    assert event["epoch_optimizer_step_count"] == 0


@pytest.mark.parametrize(
    ("mse_by_lead", "counts", "clipped", "steps", "expected_exception"),
    [
        ({1: [float("nan")], 2: [1.0], 3: [1.0]}, {1: 1, 2: 1, 3: 1}, 0, 1, ValueError),
        ({1: [1.0], 2: [1.0], 3: [1.0]}, {1: -1, 2: 1, 3: 1}, 0, 1, ValueError),
        ({1: [1.0], 2: [1.0], 3: [1.0]}, {1: 1, 2: 1, 3: 1}, 2, 1, ValueError),
        ({1: [1.0], 2: [1.0], 3: []}, {1: 1, 2: 1, 3: 1}, 0, 1, ValueError),
    ],
)
def test_epoch_diagnostics_reject_invalid_evidence(
    mse_by_lead: dict[int, list[float]],
    counts: dict[int, int],
    clipped: int,
    steps: int,
    expected_exception: type[Exception],
) -> None:
    with pytest.raises(expected_exception):
        ENTRY._summarize_epoch_training_diagnostics(
            mse_by_lead,
            counts,
            gradient_clipped_optimizer_step_count=clipped,
            optimizer_step_count=steps,
        )


def test_history_row_records_complete_training_diagnostics() -> None:
    diagnostics = ENTRY._summarize_epoch_training_diagnostics(
        {1: [1.0, 5.0], 2: [2.0, 4.0], 3: [3.0, 3.0]},
        {1: 204, 2: 204, 3: 204},
        gradient_clipped_optimizer_step_count=1,
        optimizer_step_count=2,
    )
    row = ENTRY._history_row(
        epoch=1,
        training_objective=3.0,
        validation=_validation(),
        parameter_sha256="2" * 64,
        optimizer_steps=2,
        forecast_events=612,
        gradient_names=("gain.weight",),
        maximum_gradient_norm_before_clip=12.0,
        training_diagnostics=diagnostics,
        prediction_sha256="3" * 64,
    )

    assert row[
        "training_mse_by_lead_physical_unit_mean_over_optimizer_steps"
    ] == {1: 3.0, 2: 3.0, 3: 3.0}
    assert row["training_sampled_finite_target_event_count_by_lead"] == {
        1: 204,
        2: 204,
        3: 204,
    }
    assert row["epoch_optimizer_step_count"] == 2
    assert row["gradient_clipped_optimizer_step_count"] == 1
    assert row["gradient_clipped_optimizer_step_fraction"] == 0.5
    assert row["optimizer_steps"] == 2
    assert row["sampled_forecast_events"] == 612

    event = ENTRY._epoch_completed_event(
        epoch=1,
        training_objective=3.0,
        checkpoint_selection_objective=9.0,
        gate_objective=7.0,
        checkpoint_sha256="5" * 64,
        parameter_sha256="2" * 64,
        optimizer_steps=2,
        sampled_forecast_events=612,
        training_diagnostics=diagnostics,
    )
    assert set(event) == {
        "event_type",
        "epoch",
        "training_objective",
        "checkpoint_selection_objective_728",
        "gate_objective_712",
        "checkpoint_sha256",
        "parameter_sha256",
        "optimizer_steps",
        "sampled_forecast_events",
        "training_mse_by_lead_physical_unit_mean_over_optimizer_steps",
        "training_sampled_finite_target_event_count_by_lead",
        "epoch_optimizer_step_count",
        "gradient_clipped_optimizer_step_count",
        "gradient_clipped_optimizer_step_fraction",
    }


@pytest.mark.parametrize(
    ("key", "value", "expected_exception"),
    [
        ("training_epochs", 0, ValueError),
        ("training_epochs", True, ValueError),
        ("steps_per_epoch", 0, ValueError),
        ("learning_rate", 0.0, ValueError),
        ("learning_rate", float("nan"), ValueError),
        ("gradient_maximum_norm", 0.0, ValueError),
        ("gradient_maximum_norm", float("inf"), ValueError),
        ("gradient_maximum_norm", "10", TypeError),
    ],
)
def test_training_hyperparameters_fail_closed_before_numerical_imports(
    key: str,
    value: object,
    expected_exception: type[Exception],
) -> None:
    optimization: dict[str, object] = {
        "training_epochs": 2,
        "steps_per_epoch": 32,
        "learning_rate": 0.01,
        "gradient_maximum_norm": 10.0,
    }
    optimization[key] = value

    with pytest.raises(expected_exception):
        ENTRY._validate_training_hyperparameters(optimization)


def test_training_hyperparameters_accept_positive_finite_values() -> None:
    ENTRY._validate_training_hyperparameters(
        {
            "training_epochs": 2,
            "steps_per_epoch": 32,
            "learning_rate": 0.01,
            "gradient_maximum_norm": 10.0,
        }
    )
