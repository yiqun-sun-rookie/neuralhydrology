from __future__ import annotations

from hashlib import sha256
import importlib.util
import io
import json
from pathlib import Path
import sys
import tarfile
from types import SimpleNamespace
from unittest.mock import patch

import pytest


ROOT = Path(__file__).resolve().parents[1]
PREFLIGHT_PATH = (
    ROOT / "hpc" / "daily_camels_knet_formal_evaluation" / "preflight.py"
)
SLURM_PATH = (
    ROOT
    / "hpc"
    / "daily_camels_knet_formal_evaluation"
    / "submit_evaluation_gpu.slurm"
)
BUILDER_PATH = (
    ROOT / "scripts" / "build_daily_camels_knet_formal_evaluation_hpc_bundle.py"
)

EXPERIMENT_ID = (
    "DAILY_CAMELS_KNET_EPOCH75_SINGLE_BASIN_FORMAL_EVALUATION_V1_20260831_A39"
)
CHECKPOINT = Path(
    "/data1/home/sunyiq/kalmannet_daily_camels_knet_a38_a800_train1_20260828/"
    "runs/DAILY_CAMELS_KNET_FIXED_FULL_TRAINING_COVERAGE_"
    "EPOCH40_TO80_RESUME_STEP_MONOTONICITY_DIAGNOSTIC_V1_20260828_A38/"
    "checkpoints/epoch_075.pt"
)
CHECKPOINT_TEXT = (
    "/data1/home/sunyiq/kalmannet_daily_camels_knet_a38_a800_train1_20260828/"
    "runs/DAILY_CAMELS_KNET_FIXED_FULL_TRAINING_COVERAGE_"
    "EPOCH40_TO80_RESUME_STEP_MONOTONICITY_DIAGNOSTIC_V1_20260828_A38/"
    "checkpoints/epoch_075.pt"
)
CHECKPOINT_SHA256 = (
    "7cc97138669531688dcd65d606d154330f260346c7c9c6e704cb1be5307a241b"
)
EVALUATION_ARCHIVE = Path(
    "/data1/home/sunyiq/kalmannet_tukf06_20260809/retry2/results/"
    "tukf06_full_diagonal_search_head_to_head_v1/evaluation/"
    "basin_09035800.npz"
)
EVALUATION_ARCHIVE_TEXT = (
    "/data1/home/sunyiq/kalmannet_tukf06_20260809/retry2/results/"
    "tukf06_full_diagonal_search_head_to_head_v1/evaluation/"
    "basin_09035800.npz"
)
EVALUATION_ARCHIVE_SHA256 = (
    "59c0acc1afce14da7fe479fc5cdb6c6c4d2b18758d076c32950c5f2b3cfd3596"
)


def _load(path: Path, name: str):
    before = {package: package in sys.modules for package in ("numpy", "torch")}
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    after = {package: package in sys.modules for package in ("numpy", "torch")}
    assert after == before
    return module


PREFLIGHT = _load(PREFLIGHT_PATH, "a39_formal_evaluation_preflight_test")
BUILDER = _load(BUILDER_PATH, "a39_formal_evaluation_builder_test")


def _valid_config() -> dict[str, object]:
    return {
        "schema_version": "daily_camels_knet_epoch75_formal_evaluation_v1",
        "experiment_id": EXPERIMENT_ID,
        "basin_id": "09035800",
        "cadence": "daily",
        "forecast_leads": [1, 2, 3],
        "evaluation_period": ["1989-10-01", "1999-09-30"],
        "evaluation_period_role": "reused_historical_benchmark",
        "expected_evaluation_days": 3652,
        "warmup_days": 365,
        "evaluation": {
            "warmup_applies_to_issue_dates": True,
            "issue_start_index_inclusive": 365,
            "issue_end_index_exclusive": 3649,
            "nominal_common_issue_count": 3284,
        },
        "execution_policy": {
            "allow_training": False,
            "allow_optimizer_updates": False,
            "allow_checkpoint_selection": False,
            "allow_checkpoint_writes": False,
            "allow_hyperparameter_tuning": False,
            "allow_stored_baseline_prediction_reads": False,
            "evaluation_only": True,
            "one_shot_evaluation": True,
            "require_absent_output_root": True,
            "scientific_hold_is_technical_success": True,
            "evaluation_archive_open_count": 1,
            "allowed_evaluation_array_members": ["dates_ns", "forcing", "target"],
        },
        "checkpoint": {
            "path": CHECKPOINT_TEXT,
            "sha256": CHECKPOINT_SHA256,
            "size_bytes": 4_260_296,
            "completed_epoch": 75,
            "parameter_sha256": (
                "5a288a2ac6d2985253b37616d983d6dfaf0638b18169bba8fcd0439e5b922fce"
            ),
        },
        "candidate": {
            "source_experiment_id": (
                "DAILY_CAMELS_KNET_FIXED_FULL_TRAINING_COVERAGE_"
                "EPOCH40_TO80_RESUME_STEP_MONOTONICITY_DIAGNOSTIC_V1_20260828_A38"
            ),
            "source_terminal_evidence_archive_sha256": (
                "72feda409ea3490ccd9a289b1313c9beb276c1cc267a15111dc19e63d5815317"
            ),
        },
        "model": dict(PREFLIGHT.MODEL_CONTRACT),
        "ukf": {
            "default_noise": {
                "process_diagonal": [0.001] * 18,
                "r_b": 0.02,
            },
            "sampled_search": {"selection_method": "sampling_search"},
            "backpropagation_selected": {
                "selection_method": "backpropagation"
            },
        },
        "metrics": {"same_nominal_issue_window_across_leads": True},
        "inputs": {
            "evaluation_archive": {
                "path": EVALUATION_ARCHIVE_TEXT,
                "sha256": EVALUATION_ARCHIVE_SHA256,
                "size_bytes": 444_684,
                "expected_archive_members": [
                    "dates_ns",
                    "target",
                    "forcing",
                    *[
                        f"{system}_lead_{lead}"
                        for lead in (1, 2, 3)
                        for system in (
                            "common_mask",
                            "same_forcing_open_loop",
                            "default_noise_filter",
                            "sampling_search_filter",
                            "backpropagation_filter",
                            "persistence",
                            "second_order_autoregression",
                        )
                    ],
                ],
                "stored_baseline_prediction_reads": 0,
            },
        },
        "output_root": (
            "/data1/home/sunyiq/"
            "kalmannet_daily_camels_knet_a39_formal_evaluation5_20260831/evaluation"
        ),
        "resource_admission": {
            "host_memory_min_bytes": 2_800_353_280,
            "gpu_free_memory_min_mib": 4_584,
            "a38_measured_host_peak_bytes": 1_405_100_032,
            "a38_slurm_max_rss_bytes": 1_394_536_448,
            "a38_measured_gpu_peak_used_mib": 3_820,
        },
    }


def test_preflight_import_is_standard_library_only() -> None:
    source = PREFLIGHT_PATH.read_text(encoding="utf-8")
    tree = __import__("ast").parse(source)
    imported = {
        alias.name.split(".", 1)[0]
        for node in __import__("ast").walk(tree)
        if isinstance(node, (__import__("ast").Import, __import__("ast").ImportFrom))
        for alias in node.names
    }
    assert "numpy" not in imported
    assert "torch" not in imported


def test_frozen_external_identities_and_resource_thresholds() -> None:
    assert PREFLIGHT.EXPERIMENT_ID == EXPERIMENT_ID
    assert PREFLIGHT.CHECKPOINT_PATH == CHECKPOINT
    assert PREFLIGHT.CHECKPOINT_SHA256 == CHECKPOINT_SHA256
    assert PREFLIGHT.CHECKPOINT_SIZE == 4_260_296
    assert PREFLIGHT.EVALUATION_ARCHIVE_PATH == EVALUATION_ARCHIVE
    assert PREFLIGHT.EVALUATION_ARCHIVE_SHA256 == EVALUATION_ARCHIVE_SHA256
    assert PREFLIGHT.EXECUTION_ID.endswith("_A39_A800_EVAL5_SEQ98")
    assert PREFLIGHT.A38_ORIGINAL_TERMINAL_ARCHIVE_SHA256 == (
        "72feda409ea3490ccd9a289b1313c9beb276c1cc267a15111dc19e63d5815317"
    )
    assert PREFLIGHT.A38_RECONSTRUCTED_TERMINAL_ARCHIVE_SHA256 == (
        "89975d9d69d477d625ae11713a96edf618cb6189284e280f3008bfe0f785676d"
    )
    assert (
        PREFLIGHT.A38_ORIGINAL_TERMINAL_ARCHIVE_SHA256
        != PREFLIGHT.A38_RECONSTRUCTED_TERMINAL_ARCHIVE_SHA256
    )
    assert PREFLIGHT.A38_RECONSTRUCTED_TERMINAL_ARCHIVE_SIZE == 13_900_887
    assert PREFLIGHT.A38_MEMBER_IDENTITY_RECEIPT_SHA256 == (
        "ac2fc24c15edb7b9d5e22ced035141c4fa256e79f8067ea9225be9613abe8f56"
    )
    assert PREFLIGHT.A38_MEMBER_IDENTITY_RECEIPT_SIZE == 1_278
    assert PREFLIGHT.A38_CANONICAL_MEMBER_INVENTORY_SHA256 == (
        "e6af63ceb2c40f932afd295651104b3268f80ac41ccbccb95f7a0de240a55fe6"
    )
    assert PREFLIGHT.MIN_HOST_MEMORY_BYTES == 2_800_353_280
    assert PREFLIGHT.MIN_GPU_FREE_MIB == 4_584
    assert PREFLIGHT.ALLOWED_HOSTS == frozenset({"ngu202", "ngu203"})


def test_original_source_identity_is_distinct_from_reconstructed_transport() -> None:
    config = json.loads(
        (ROOT / "configs" / "daily_camels_knet_epoch75_formal_evaluation_a39.json")
        .read_text(encoding="utf-8")
    )
    assert config["candidate"]["source_terminal_evidence_archive_sha256"] == (
        PREFLIGHT.A38_ORIGINAL_TERMINAL_ARCHIVE_SHA256
    )
    assert BUILDER.A38_ORIGINAL_TERMINAL_ARCHIVE_SHA256 == (
        PREFLIGHT.A38_ORIGINAL_TERMINAL_ARCHIVE_SHA256
    )
    assert BUILDER.A38_RECONSTRUCTED_TERMINAL_ARCHIVE_SHA256 == (
        PREFLIGHT.A38_RECONSTRUCTED_TERMINAL_ARCHIVE_SHA256
    )
    assert BUILDER.A38_MEMBER_IDENTITY_RECEIPT_SHA256 == (
        PREFLIGHT.A38_MEMBER_IDENTITY_RECEIPT_SHA256
    )
    assert BUILDER.A38_CANONICAL_MEMBER_INVENTORY_SHA256 == (
        PREFLIGHT.A38_CANONICAL_MEMBER_INVENTORY_SHA256
    )


def test_preflight_cli_requires_reconstruction_receipt() -> None:
    action = next(
        item
        for item in PREFLIGHT.build_parser()._actions
        if item.dest == "a38_reconstruction_receipt"
    )
    assert action.required is True
    assert action.default is None


def test_config_contract_rejects_training_and_external_identity_drift() -> None:
    assert PREFLIGHT.validate_config(_valid_config())["completed_epoch"] == 75

    for mutation in (
        lambda value: value["execution_policy"].__setitem__("allow_training", True),
        lambda value: value["execution_policy"].__setitem__(
            "allow_optimizer_updates", True
        ),
        lambda value: value["checkpoint"].__setitem__("completed_epoch", 80),
        lambda value: value["checkpoint"].__setitem__("path", "/tmp/epoch_075.pt"),
        lambda value: value["inputs"]["evaluation_archive"].__setitem__(
            "sha256", "0" * 64
        ),
        lambda value: value["inputs"]["evaluation_archive"][
            "expected_archive_members"
        ].__setitem__(3, "unexpected_prediction_lead_1"),
        lambda value: value.__setitem__("warmup_days", 364),
        lambda value: value["model"].__setitem__("normalized_feature_guard", 9.0),
        lambda value: value["ukf"]["default_noise"].__setitem__("r_b", 0.03),
    ):
        changed = json.loads(json.dumps(_valid_config()))
        mutation(changed)
        with pytest.raises(RuntimeError):
            PREFLIGHT.validate_config(changed)


def test_external_artifact_gate_binds_regular_file_size_and_hash(
    tmp_path: Path,
) -> None:
    artifact = tmp_path / "artifact.bin"
    artifact.write_bytes(b"frozen")
    expected = sha256(b"frozen").hexdigest()
    evidence = PREFLIGHT.verify_external_artifact(
        artifact,
        expected_path=artifact,
        expected_sha256=expected,
        expected_size=6,
        label="synthetic artifact",
    )
    assert evidence["size"] == 6
    assert evidence["sha256"] == expected

    link = tmp_path / "link.bin"
    try:
        link.symlink_to(artifact)
    except OSError:
        pytest.skip("symbolic links are unavailable")
    with pytest.raises(RuntimeError, match="symbolic"):
        PREFLIGHT.verify_external_artifact(
            link,
            expected_path=link,
            expected_sha256=expected,
            expected_size=6,
            label="synthetic artifact",
        )


def test_resource_gate_requires_hgpu8_allowed_host_one_a800_and_headroom() -> None:
    env = {
        "SLURM_JOB_ID": "123",
        "SLURM_JOB_PARTITION": "hgpu8",
        "SLURM_NNODES": "1",
        "SLURM_NTASKS": "1",
        "SLURM_GPUS_ON_NODE": "1",
        "CUDA_VISIBLE_DEVICES": "0",
    }
    gpu = {
        "name": "NVIDIA A800-SXM4-80GB",
        "total_mib": 81_240,
        "free_mib": 78_000,
        "visible_device": "0",
    }
    evidence = PREFLIGHT.validate_resource_admission(
        env,
        hostname="ngu202",
        available_host_memory_bytes=10_000_000_000,
        gpu=gpu,
    )
    assert evidence["status"] == "PASS"
    assert evidence["gpu_count_evidence"] == {
        "fixed_slurm_request": "--gres=gpu:1",
        "cuda_visible_devices": "0",
        "nvidia_smi_visible_row_count": 1,
        "slurm_gpus_on_node_raw": "1",
        "slurm_gpus_on_node_parsed_count": 1,
        "slurm_gpus_on_node_required": False,
    }

    cluster_env_without_optional_gpu_count = dict(env)
    cluster_env_without_optional_gpu_count.pop("SLURM_GPUS_ON_NODE")
    cluster_evidence = PREFLIGHT.validate_resource_admission(
        cluster_env_without_optional_gpu_count,
        hostname="ngu202",
        available_host_memory_bytes=10_000_000_000,
        gpu=gpu,
    )
    assert cluster_evidence["gpu_count"] == 1
    assert cluster_evidence["gpu_count_evidence"]["slurm_gpus_on_node_raw"] is None
    assert (
        cluster_evidence["gpu_count_evidence"]["slurm_gpus_on_node_parsed_count"]
        is None
    )

    unrecognized_scheduler_format = PREFLIGHT.validate_resource_admission(
        {**env, "SLURM_GPUS_ON_NODE": "gpu(IDX:0)"},
        hostname="ngu202",
        available_host_memory_bytes=10_000_000_000,
        gpu=gpu,
    )
    assert unrecognized_scheduler_format["gpu_count"] == 1
    assert unrecognized_scheduler_format["gpu_count_evidence"] == {
        "fixed_slurm_request": "--gres=gpu:1",
        "cuda_visible_devices": "0",
        "nvidia_smi_visible_row_count": 1,
        "slurm_gpus_on_node_raw": "gpu(IDX:0)",
        "slurm_gpus_on_node_parsed_count": None,
        "slurm_gpus_on_node_required": False,
    }

    with pytest.raises(RuntimeError, match="non-single GPU"):
        PREFLIGHT.validate_resource_admission(
            {**env, "SLURM_GPUS_ON_NODE": "2"},
            hostname="ngu202",
            available_host_memory_bytes=10_000_000_000,
            gpu=gpu,
        )

    with pytest.raises(RuntimeError, match="GPU free memory"):
        PREFLIGHT.validate_resource_admission(
            env,
            hostname="ngu202",
            available_host_memory_bytes=10_000_000_000,
            gpu={**gpu, "free_mib": 4_583},
        )
    with pytest.raises(RuntimeError, match="allocated host"):
        PREFLIGHT.validate_resource_admission(
            env,
            hostname="ngu201",
            available_host_memory_bytes=10_000_000_000,
            gpu=gpu,
        )


def test_gpu_probe_rejects_multiple_visible_or_queried_devices(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    with pytest.raises(RuntimeError, match="exactly one CUDA device"):
        PREFLIGHT.probe_gpu({"CUDA_VISIBLE_DEVICES": "0,1"})

    monkeypatch.setattr(
        PREFLIGHT.subprocess,
        "run",
        lambda *args, **kwargs: SimpleNamespace(
            returncode=0,
            stdout=(
                "NVIDIA A800-SXM4-80GB, 81240, 78000\n"
                "NVIDIA A800-SXM4-80GB, 81240, 77900\n"
            ),
            stderr="",
        ),
    )
    with pytest.raises(RuntimeError, match="exactly one device"):
        PREFLIGHT.probe_gpu({"CUDA_VISIBLE_DEVICES": "0"})


def test_builder_allowlist_excludes_checkpoint_and_historical_evaluation_npz() -> None:
    names = set(BUILDER.FIXED_SOURCE_MEMBERS)
    npz_members = sorted(name for name in names if name.endswith(".npz"))
    assert npz_members == [
        "results/tukf06_full_diagonal_search_head_to_head_v1/"
        "selection_inputs/basin_09035800.npz"
    ]
    assert not any(name.endswith(".pt") for name in names)
    assert not any("/evaluation/" in name for name in names)
    assert "scripts/run_daily_camels_knet_epoch75_formal_evaluation.py" in names
    assert "scripts/verify_daily_camels_knet_epoch75_formal_evaluation.py" in names
    assert "scripts/run_daily_camels_ukf_knet_parity.py" not in names
    assert BUILDER.FORMAL_PLAN_MEMBER in names
    assert BUILDER.NEXT_STAGE_PLAN_MEMBER in names
    assert not any("RECONSTRUCT_SEQ89.tar.gz" in name for name in names)
    assert not any("member_identity_verification.json" in name for name in names)
    assert (
        "hpc/daily_camels_knet_formal_evaluation/submit_evaluation_gpu.slurm"
        in names
    )


def test_member_name_gate_rejects_unsafe_or_reserved_array_members() -> None:
    for name in (
        "../escape.py",
        "/absolute.py",
        "results/x/evaluation/basin_09035800.npz",
        "results/x/heldout_values.npz",
        "results/x/reserved_period.npz",
        ".git/config",
    ):
        with pytest.raises(ValueError):
            BUILDER.validate_member_name(name)


def test_deterministic_archive_has_normalized_metadata() -> None:
    payloads = {"b.txt": b"b\n", "a.txt": b"a\n"}
    manifest = {"schema_version": "synthetic", "member_sha256": {}}
    first = BUILDER.deterministic_archive_bytes(payloads, manifest)
    second = BUILDER.deterministic_archive_bytes(payloads, manifest)
    assert first == second
    with tarfile.open(fileobj=io.BytesIO(first), mode="r:gz") as archive:
        members = archive.getmembers()
        assert [member.name for member in members] == [
            "a.txt",
            "b.txt",
            "bundle_manifest.json",
        ]
        assert all(member.mtime == 0 for member in members)
        assert all(member.uid == 0 and member.gid == 0 for member in members)
        assert all(member.isfile() for member in members)


def test_slurm_entry_is_one_gpu_evaluation_only_and_ordered() -> None:
    source = SLURM_PATH.read_text(encoding="utf-8")
    assert "#SBATCH -p hgpu8" in source
    assert "#SBATCH -N 1" in source
    assert "#SBATCH -n 1" in source
    assert "#SBATCH --gres=gpu:1" in source
    assert "#SBATCH --exclude=ngu201" in source
    assert "#SBATCH --nodelist=" not in source
    assert "NVIDIA A800-SXM4-80GB" in source
    assert CHECKPOINT_TEXT in source
    assert CHECKPOINT_SHA256 in source
    assert EVALUATION_ARCHIVE_TEXT in source
    assert EVALUATION_ARCHIVE_SHA256 in source
    assert "DAILY_CAMELS_KNET_A38_JOB215801_TERMINAL_EVIDENCE_RECONSTRUCT_SEQ89.tar.gz" in source
    assert "89975d9d69d477d625ae11713a96edf618cb6189284e280f3008bfe0f785676d" in source
    assert "ac2fc24c15edb7b9d5e22ced035141c4fa256e79f8067ea9225be9613abe8f56" in source
    assert "DAILY_CAMELS_KNET_EPOCH75_SINGLE_BASIN_FORMAL_EVALUATION_A39_A800_EVAL5_SEQ98" in source
    assert "A39_HOST_ADMISSION_MIN_BYTES=2800353280" in source
    assert "A39_GPU_ADMISSION_MIN_FREE_MIB=4584" in source
    assert 'BUNDLE_ROOT="${A39_BUNDLE_ROOT:-${SLURM_SUBMIT_DIR:-}}"' in source
    assert 'if [[ "${BUNDLE_ROOT}" != "${EXPECTED_BUNDLE_ROOT}" ]]' in source
    assert "source_A39_formal_evaluation_seq98" in source
    assert 'A38_TERMINAL_EVIDENCE="${A39_A38_TERMINAL_EVIDENCE:-}"' in source
    assert 'A38_RECONSTRUCTION_RECEIPT="${A39_A38_RECONSTRUCTION_RECEIPT:-}"' in source
    assert "hpc_mailbox/outbox/kalmannet-daily-camels" not in source
    assert 'export PYTHONPATH="${BUNDLE_ROOT}/src:${BUNDLE_ROOT}"' in source

    preflight = source.index(
        "hpc/daily_camels_knet_formal_evaluation/preflight.py"
    )
    evaluator = source.index(
        "scripts/run_daily_camels_knet_epoch75_formal_evaluation.py"
    )
    verifier = source.index(
        "scripts/verify_daily_camels_knet_epoch75_formal_evaluation.py"
    )
    assert preflight < evaluator < verifier
    lowered = "\n".join(
        line for line in source.lower().splitlines() if not line.lstrip().startswith("#")
    )
    for forbidden in (
        "sbatch ",
        "scancel ",
        "scontrol update",
        "optimizer.step",
        ".backward(",
        "submit_train",
        "run_training",
    ):
        assert forbidden not in lowered


def test_slurm_entry_preserves_submission_lock_and_clears_only_runtime_lock() -> None:
    source = SLURM_PATH.read_text(encoding="utf-8")
    assert ".submission.lock" in source
    assert ".evaluation.lock" in source
    assert 'rmdir "${RUNTIME_LOCK}"' in source
    assert 'rmdir "${SUBMISSION_LOCK}"' not in source
    assert 'mkdir "${SUBMISSION_LOCK}"' not in source
    assert '"state": "PREPARED"' in source
    assert '"state": "BOUND"' in source
    assert "os.fsync(handle.fileno())" in source
    assert PREFLIGHT.SUBMISSION_TOKEN in source
    assert "#SBATCH --no-requeue" in source
    assert "gpu-resource" in source.lower()
    assert "cgroup-resource" in source.lower()
    assert "resource-summary" in source.lower()


def test_prepared_submission_lock_binds_exactly_one_slurm_job(tmp_path: Path) -> None:
    submission = tmp_path / "submission.lock"
    submission.mkdir()
    owner = {
        "experiment_id": PREFLIGHT.EXPERIMENT_ID,
        "execution_id": PREFLIGHT.EXECUTION_ID,
        "submission_token": PREFLIGHT.SUBMISSION_TOKEN,
        "state": "PREPARED",
        "persistent": True,
        "evaluation_only": True,
    }
    bound = {
        **owner,
        "state": "BOUND",
        "slurm_job_id": "123",
    }
    (submission / "owner.json").write_text(json.dumps(owner), encoding="utf-8")
    (submission / "bound.json").write_text(json.dumps(bound), encoding="utf-8")

    evidence = PREFLIGHT._verify_submission_lock(submission, job_id="123")
    assert evidence["owner"]["state"] == "PREPARED"
    assert evidence["bound"]["slurm_job_id"] == "123"

    with pytest.raises(RuntimeError, match="submission bound job"):
        PREFLIGHT._verify_submission_lock(submission, job_id="124")


def test_builder_cli_requires_a_new_destination() -> None:
    action = next(
        item for item in BUILDER.build_parser()._actions if item.dest == "destination"
    )
    assert action.required is True
    assert action.default is None
