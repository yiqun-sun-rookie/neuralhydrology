#!/usr/bin/env python3
"""One-shot formal evaluation of the frozen epoch-75 daily CAMELS KalmanNet.

The module imports numerical frameworks only after the command-line preflight has
verified the frozen configuration, sources, development evidence, selection, and
checkpoint.  The protected archive is opened through one file handle and only its
``dates_ns``, ``forcing``, and ``target`` members are materialized.  Every model
prediction is regenerated; no stored baseline prediction is accepted.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from hashlib import sha256
import importlib
import io
import json
import math
import os
from pathlib import Path
import sys
from types import SimpleNamespace
from typing import Any, Mapping, MutableMapping, NoReturn, Sequence
from uuid import uuid4
from zipfile import BadZipFile, ZipFile


ROOT = Path(__file__).resolve().parents[1]

CONFIG_SCHEMA_VERSION = "daily_camels_knet_epoch75_formal_evaluation_v1"
RESULT_SCHEMA_VERSION = "daily_camels_knet_epoch75_formal_evaluation_result_v1"
ACCESS_LEDGER_SCHEMA_VERSION = (
    "daily_camels_knet_epoch75_formal_evaluation_access_ledger_v1"
)
MANIFEST_SCHEMA_VERSION = "daily_camels_knet_epoch75_formal_evaluation_manifest_v1"

EXPERIMENT_ID = (
    "DAILY_CAMELS_KNET_EPOCH75_SINGLE_BASIN_FORMAL_EVALUATION_V1_20260831_A39"
)
SOURCE_EXPERIMENT_ID = (
    "DAILY_CAMELS_KNET_FIXED_FULL_TRAINING_COVERAGE_EPOCH40_TO80_RESUME_"
    "STEP_MONOTONICITY_DIAGNOSTIC_V1_20260828_A38"
)
SCIENTIFIC_ROLE = "single_basin_formal_evaluation_reused_historical_benchmark"
BASIN_ID = "09035800"
EVALUATION_PERIOD = ("1989-10-01", "1999-09-30")
EVALUATION_PERIOD_ROLE = "reused_historical_benchmark"
EXPECTED_DAYS = 3652
WARMUP_DAYS = 365
LEADS = (1, 2, 3)
ISSUE_START_INDEX_INCLUSIVE = WARMUP_DAYS
ISSUE_END_INDEX_EXCLUSIVE = EXPECTED_DAYS - max(LEADS)
NOMINAL_COMMON_ISSUE_COUNT = ISSUE_END_INDEX_EXCLUSIVE - ISSUE_START_INDEX_INCLUSIVE
SYSTEMS = (
    "knet_epoch75",
    "strict_zero_gain_knet",
    "same_forcing_open_loop",
    "default_noise_ukf",
    "sampled_search_ukf",
    "backpropagation_selected_ukf",
    "persistence",
    "second_order_autoregression",
)
EVALUATION_ARCHIVE_MEMBERS = (
    "dates_ns",
    "target",
    "forcing",
    "common_mask_lead_1",
    "same_forcing_open_loop_lead_1",
    "default_noise_filter_lead_1",
    "sampling_search_filter_lead_1",
    "backpropagation_filter_lead_1",
    "persistence_lead_1",
    "second_order_autoregression_lead_1",
    "common_mask_lead_2",
    "same_forcing_open_loop_lead_2",
    "default_noise_filter_lead_2",
    "sampling_search_filter_lead_2",
    "backpropagation_filter_lead_2",
    "persistence_lead_2",
    "second_order_autoregression_lead_2",
    "common_mask_lead_3",
    "same_forcing_open_loop_lead_3",
    "default_noise_filter_lead_3",
    "sampling_search_filter_lead_3",
    "backpropagation_filter_lead_3",
    "persistence_lead_3",
    "second_order_autoregression_lead_3",
)
ALLOWED_EVALUATION_ARRAY_READS = ("dates_ns", "forcing", "target")

CHECKPOINT_PATH = (
    "/data1/home/sunyiq/kalmannet_daily_camels_knet_a38_a800_train1_20260828/"
    "runs/DAILY_CAMELS_KNET_FIXED_FULL_TRAINING_COVERAGE_EPOCH40_TO80_RESUME_"
    "STEP_MONOTONICITY_DIAGNOSTIC_V1_20260828_A38/checkpoints/epoch_075.pt"
)
CHECKPOINT_SHA256 = (
    "7cc97138669531688dcd65d606d154330f260346c7c9c6e704cb1be5307a241b"
)
CHECKPOINT_SIZE_BYTES = 4_260_296
CHECKPOINT_EPOCH = 75
PARAMETER_SHA256 = (
    "5a288a2ac6d2985253b37616d983d6dfaf0638b18169bba8fcd0439e5b922fce"
)
SOURCE_CONFIGURATION_SHA256 = (
    "05bace055154c9e88124f81434fc76a4e7a0e73d1ef4b8bf2635d7507b5d7d82"
)

AUTHORIZATION_SHA256 = (
    "57c0dad7188249e27bcf585f0f452f617554a083e79ea2589ff61cbcabedd231"
)
AUTHORIZATION_SIZE_BYTES = 111
MINIMUM_NSE_EXCLUSIVE = 0.6
PRACTICAL_EQUIVALENCE_NSE = 0.01
MAXIMUM_LEAD1_NSE_DEFICIT_VS_SELECTED_UKF = 0.10
MODEL_CONTRACT = {
    "state_dimension": 18,
    "gain_network_numeric_dtype": "float32",
    "physical_numeric_dtype": "float64",
    "seed": 20260824,
    "hidden": 24,
    "input_multiplier": 10,
    "output_multiplier": 10,
    "feature_scale_floor": 0.1,
    "normalized_feature_guard": 10.0,
    "correction_scope": "full_eighteen_dimensional_state_correction",
    "checkpoint_state_member": "model_state",
}
DEFAULT_UKF_PROCESS_DIAGONAL = [0.001] * 18
DEFAULT_UKF_OBSERVATION_NOISE_MULTIPLIER = 0.02
GAIN_INITIALIZATION = "near_zero_fc2_head"
RESULT_STATUS = "FORMAL_EVALUATION_COMPLETE"
CONVERGENCE_STATUS = (
    "UNKNOWN_NOT_ESTABLISHED_BY_SINGLE_CHECKPOINT_FORMAL_EVALUATION"
)

PREDICTIONS_FILE = "predictions.npz"
RESULT_SUMMARY_FILE = "result_summary.json"
ACCESS_LEDGER_FILE = "access_ledger.json"
MANIFEST_FILE = "manifest.sha256.json"
MANIFEST_MEMBER_FILES = (
    PREDICTIONS_FILE,
    RESULT_SUMMARY_FILE,
    ACCESS_LEDGER_FILE,
)
FORBIDDEN_TRAINING_ENTRY = "scripts/run_daily_camels_ukf_knet_parity.py"


class FormalEvaluationError(RuntimeError):
    """A fail-closed technical or evidence error."""


def _fail(message: str) -> NoReturn:
    raise FormalEvaluationError(message)


def _require_mapping(value: Any, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        _fail(f"{label} must be a JSON object")
    return value


def _require_exact(value: Any, expected: Any, label: str) -> None:
    if value != expected:
        _fail(f"{label} differs: actual={value!r} expected={expected!r}")


def _reject_json_constant(value: str) -> NoReturn:
    _fail(f"non-finite JSON constant is forbidden: {value}")


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            _fail(f"duplicate JSON key is forbidden: {key}")
        result[key] = value
    return result


def _read_json(path: Path, *, label: str) -> dict[str, Any]:
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        _fail(f"{label} must be a regular non-symbolic-link file: {path}")
    try:
        payload = json.loads(
            path.read_text(encoding="utf-8"),
            object_pairs_hook=_unique_object,
            parse_constant=_reject_json_constant,
        )
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise FormalEvaluationError(f"cannot read {label}: {exc}") from exc
    if not isinstance(payload, dict):
        _fail(f"{label} root must be a JSON object")
    return payload


def canonical_json_bytes(payload: Any) -> bytes:
    return (
        json.dumps(
            payload,
            indent=2,
            sort_keys=True,
            ensure_ascii=False,
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")


def _checkpoint_identity_jsonable(value: Any) -> Any:
    """Mirror the frozen trainer's JSON normalization for checkpoint identity."""

    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("checkpoint identity contains a non-finite float")
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {
            str(key): _checkpoint_identity_jsonable(member)
            for key, member in value.items()
        }
    if isinstance(value, (list, tuple, set, frozenset)):
        return [_checkpoint_identity_jsonable(member) for member in value]
    if hasattr(value, "item"):
        try:
            return _checkpoint_identity_jsonable(value.item())
        except (TypeError, ValueError):
            pass
    raise TypeError(
        f"checkpoint identity value of type {type(value).__name__} is not JSON evidence"
    )


def checkpoint_identity_json_bytes(payload: Any) -> bytes:
    """Return the exact compact bytes used when A38 created its identity hash."""

    return (
        json.dumps(
            _checkpoint_identity_jsonable(payload),
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
        + b"\n"
    )


def sha256_file(path: Path) -> str:
    digest = sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _require_sha256(value: Any, label: str) -> str:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        _fail(f"{label} must be one lowercase SHA-256 value")
    return value


def _validate_file(
    path: Path,
    *,
    expected_sha256: str,
    expected_size_bytes: int | None,
    label: str,
) -> Path:
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        _fail(f"{label} must be a regular non-symbolic-link file: {path}")
    if expected_size_bytes is not None and path.stat().st_size != int(expected_size_bytes):
        _fail(
            f"{label} size differs: actual={path.stat().st_size} "
            f"expected={expected_size_bytes}"
        )
    actual = sha256_file(path)
    if actual != expected_sha256:
        _fail(f"{label} SHA-256 differs: actual={actual} expected={expected_sha256}")
    return path


def load_and_validate_config(path: Path) -> dict[str, Any]:
    """Read and strictly validate the frozen A39 configuration without NumPy."""

    config = _read_json(Path(path), label="formal evaluation configuration")
    frozen_top = {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "experiment_id": EXPERIMENT_ID,
        "scientific_role": SCIENTIFIC_ROLE,
        "basin_id": BASIN_ID,
        "cadence": "daily",
        "forecast_leads": list(LEADS),
        "evaluation_period": list(EVALUATION_PERIOD),
        "evaluation_period_role": EVALUATION_PERIOD_ROLE,
        "expected_evaluation_days": EXPECTED_DAYS,
        "warmup_days": WARMUP_DAYS,
        "systems": list(SYSTEMS),
    }
    for key, expected in frozen_top.items():
        _require_exact(config.get(key), expected, f"configuration.{key}")

    evaluation = _require_mapping(config.get("evaluation"), "evaluation")
    expected_evaluation = {
        "period": list(EVALUATION_PERIOD),
        "role": EVALUATION_PERIOD_ROLE,
        "expected_days": EXPECTED_DAYS,
        "warmup_days_excluded": WARMUP_DAYS,
        "warmup_applies_to_issue_dates": True,
        "issue_start_index_inclusive": ISSUE_START_INDEX_INCLUSIVE,
        "issue_end_index_exclusive": ISSUE_END_INDEX_EXCLUSIVE,
        "nominal_common_issue_count": NOMINAL_COMMON_ISSUE_COUNT,
        "leads_days": list(LEADS),
        "systems": list(SYSTEMS),
    }
    for key, expected in expected_evaluation.items():
        _require_exact(evaluation.get(key), expected, f"evaluation.{key}")

    authorization = _require_mapping(config.get("authorization"), "authorization")
    _require_exact(authorization.get("status"), "EXPLICITLY_AUTHORIZED", "authorization.status")
    _require_exact(
        authorization.get("user_instruction_utf8_sha256"),
        AUTHORIZATION_SHA256,
        "authorization user instruction SHA-256",
    )
    _require_exact(
        authorization.get("user_instruction_utf8_size_bytes"),
        AUTHORIZATION_SIZE_BYTES,
        "authorization user instruction byte count",
    )

    policy = _require_mapping(config.get("execution_policy"), "execution_policy")
    for key in (
        "allow_training",
        "allow_optimizer_updates",
        "allow_checkpoint_writes",
        "allow_checkpoint_selection",
        "allow_hyperparameter_tuning",
        "allow_stored_baseline_prediction_reads",
    ):
        _require_exact(policy.get(key), False, f"execution_policy.{key}")
    for key in (
        "evaluation_only",
        "one_shot_evaluation",
        "require_absent_output_root",
        "scientific_hold_is_technical_success",
    ):
        _require_exact(policy.get(key), True, f"execution_policy.{key}")
    _require_exact(policy.get("evaluation_archive_open_count"), 1, "evaluation archive open count")
    _require_exact(
        policy.get("allowed_evaluation_array_members"),
        ["dates_ns", "forcing", "target"],
        "allowed evaluation arrays",
    )

    candidate = _require_mapping(config.get("candidate"), "candidate")
    candidate_frozen = {
        "source_experiment_id": SOURCE_EXPERIMENT_ID,
        "checkpoint_path": CHECKPOINT_PATH,
        "checkpoint_sha256": CHECKPOINT_SHA256,
        "completed_epoch": CHECKPOINT_EPOCH,
        "parameter_sha256": PARAMETER_SHA256,
    }
    for key, expected in candidate_frozen.items():
        _require_exact(candidate.get(key), expected, f"candidate.{key}")

    checkpoint = _require_mapping(config.get("checkpoint"), "checkpoint")
    checkpoint_frozen = {
        "path": CHECKPOINT_PATH,
        "sha256": CHECKPOINT_SHA256,
        "size_bytes": CHECKPOINT_SIZE_BYTES,
        "completed_epoch": CHECKPOINT_EPOCH,
        "parameter_sha256": PARAMETER_SHA256,
    }
    for key, expected in checkpoint_frozen.items():
        _require_exact(checkpoint.get(key), expected, f"checkpoint.{key}")

    inputs = _require_mapping(config.get("inputs"), "inputs")
    for name in ("development_archive", "selection", "evaluation_archive"):
        item = _require_mapping(inputs.get(name), f"inputs.{name}")
        if not isinstance(item.get("path"), str) or not item["path"]:
            _fail(f"inputs.{name}.path must be a nonempty string")
        _require_sha256(item.get("sha256"), f"inputs.{name}.sha256")
        size = item.get("size_bytes")
        if isinstance(size, bool) or not isinstance(size, int) or size <= 0:
            _fail(f"inputs.{name}.size_bytes must be a positive integer")
    evaluation_input = _require_mapping(inputs["evaluation_archive"], "evaluation archive")
    _require_exact(
        evaluation_input.get("expected_archive_members"),
        list(EVALUATION_ARCHIVE_MEMBERS),
        "evaluation archive registered member inventory",
    )
    _require_exact(
        evaluation_input.get("stored_baseline_prediction_reads"),
        0,
        "evaluation archive stored prediction reads",
    )

    initialization = _require_mapping(config.get("initialization"), "initialization")
    _require_exact(initialization.get("mode"), "a38_causal_default_storage", "initialization mode")
    _require_exact(
        initialization.get("storage_expression"),
        ["0", "0", "0.3 * parFC", "5", "10"],
        "causal default storage expression",
    )
    _require_exact(
        initialization.get("archived_selection_initial_storage_allowed"),
        False,
        "archived selection storage permission",
    )
    _require_exact(
        initialization.get("regenerate_with_same_context"),
        [
            "knet_epoch75",
            "strict_zero_gain_knet",
            "same_forcing_open_loop",
            "default_noise_ukf",
            "sampled_search_ukf",
            "backpropagation_selected_ukf",
        ],
        "same-context regeneration inventory",
    )

    model = _require_mapping(config.get("model"), "model")
    _require_exact(dict(model), MODEL_CONTRACT, "model contract")

    ukf = _require_mapping(config.get("ukf"), "ukf")
    _require_exact(
        dict(ukf),
        {
            "default_noise": {
                "process_diagonal": DEFAULT_UKF_PROCESS_DIAGONAL,
                "r_b": DEFAULT_UKF_OBSERVATION_NOISE_MULTIPLIER,
            },
            "sampled_search": {"selection_method": "sampling_search"},
            "backpropagation_selected": {
                "selection_method": "backpropagation"
            },
        },
        "UKF baseline contract",
    )

    metrics = _require_mapping(config.get("metrics"), "metrics")
    _require_exact(
        metrics.get("primary"),
        "population_variance_nash_sutcliffe_efficiency",
        "primary metric",
    )
    _require_exact(
        metrics.get("physical_error"),
        "mean_squared_error_in_discharge_units",
        "physical error metric",
    )
    _require_exact(
        metrics.get("common_finite_mask_across_all_systems_per_lead"),
        True,
        "common mask policy",
    )
    _require_exact(
        metrics.get("same_nominal_issue_window_across_leads"),
        True,
        "common issue-window policy",
    )
    _require_exact(metrics.get("sample_variance_allowed"), False, "sample variance policy")

    gates = _require_mapping(config.get("gates"), "gates")
    frozen_gates = {
        "minimum_nse_exclusive": MINIMUM_NSE_EXCLUSIVE,
        "require_each_lead": True,
        "require_better_than_strict_zero_gain_each_lead": True,
        "require_better_than_same_forcing_open_loop_each_lead": True,
        "selected_ukf_practical_equivalence_nse": PRACTICAL_EQUIVALENCE_NSE,
        "maximum_lead1_nse_deficit_vs_selected_ukf": (
            MAXIMUM_LEAD1_NSE_DEFICIT_VS_SELECTED_UKF
        ),
    }
    for key, expected in frozen_gates.items():
        _require_exact(gates.get(key), expected, f"gates.{key}")

    output = _require_mapping(config.get("output_contract"), "output_contract")
    expected_output = {
        "result_summary": RESULT_SUMMARY_FILE,
        "predictions": PREDICTIONS_FILE,
        "access_ledger": ACCESS_LEDGER_FILE,
        "manifest": MANIFEST_FILE,
        "atomic_directory_publish": True,
        "refuse_overwrite": True,
        "manifest_members": list(MANIFEST_MEMBER_FILES),
    }
    for key, expected in expected_output.items():
        _require_exact(output.get(key), expected, f"output_contract.{key}")

    source_files = _require_mapping(config.get("source_files"), "source_files")
    if not source_files:
        _fail("source_files cannot be empty")
    for name, value in source_files.items():
        if name == FORBIDDEN_TRAINING_ENTRY:
            _fail("formal evaluation source inventory forbids the legacy training entry")
        if not isinstance(name, str) or Path(name).is_absolute() or ".." in Path(name).parts:
            _fail(f"source file path is not a fixed repository-relative path: {name!r}")
        _require_sha256(value, f"source_files.{name}")
    return config


def _np():
    return importlib.import_module("numpy")


def new_access_ledger(parameter_sha256: str) -> dict[str, Any]:
    _require_sha256(parameter_sha256, "parameter SHA-256")
    return {
        "schema_version": ACCESS_LEDGER_SCHEMA_VERSION,
        "experiment_id": EXPERIMENT_ID,
        "evaluation_archive": {
            "open_count": 0,
            "authorized_read_count": 0,
            "array_reads": {"dates_ns": 0, "forcing": 0, "target": 0},
        },
        "stored_baseline_prediction_reads": 0,
        "optimizer_steps": 0,
        "training_events": 0,
        "checkpoint_writes": 0,
        "parameter_sha256_before": parameter_sha256,
        "parameter_sha256_after": parameter_sha256,
    }


def load_evaluation_archive_once(
    path: Path,
    *,
    expected_sha256: str,
    expected_size_bytes: int,
    expected_archive_members: Sequence[str],
    allowed_array_reads: Sequence[str],
    expected_days: int,
    expected_period: Sequence[str],
    ledger: MutableMapping[str, Any],
) -> dict[str, Any]:
    """Hash and materialize the three protected arrays from one disk open."""

    np = _np()
    archive_path = Path(path)
    if archive_path.is_symlink() or not archive_path.is_file():
        _fail(f"evaluation archive must be a regular non-symbolic-link file: {archive_path}")
    expected = tuple(str(name) for name in expected_archive_members)
    allowed = tuple(str(name) for name in allowed_array_reads)
    if allowed != ALLOWED_EVALUATION_ARRAY_READS:
        _fail("evaluation archive array-read allowlist must be exactly dates_ns, forcing, target")
    if not set(allowed).issubset(expected) or len(expected) != len(set(expected)):
        _fail("registered evaluation archive members are incomplete or duplicated")
    access = _require_mapping(ledger.get("evaluation_archive"), "ledger evaluation archive")
    if access.get("open_count") != 0 or access.get("authorized_read_count") != 0:
        _fail("evaluation archive has already been opened or authorized")
    access["open_count"] = 1
    try:
        with archive_path.open("rb") as stream:
            content = stream.read()
    except OSError as exc:
        raise FormalEvaluationError(f"cannot read evaluation archive: {exc}") from exc
    if len(content) != int(expected_size_bytes):
        _fail(
            f"evaluation archive size differs: actual={len(content)} "
            f"expected={expected_size_bytes}"
        )
    actual_hash = sha256(content).hexdigest()
    if actual_hash != _require_sha256(expected_sha256, "evaluation archive SHA-256"):
        _fail(
            f"evaluation archive SHA-256 differs: actual={actual_hash} "
            f"expected={expected_sha256}"
        )
    try:
        with ZipFile(io.BytesIO(content), mode="r") as archive_zip:
            member_files = archive_zip.namelist()
    except (BadZipFile, OSError) as exc:
        raise FormalEvaluationError(f"cannot list evaluation archive members: {exc}") from exc
    expected_files = [f"{name}.npy" for name in expected]
    if member_files != expected_files:
        _fail(
            "evaluation archive registered member inventory differs: "
            f"actual={member_files!r} expected={expected_files!r}"
        )

    arrays: dict[str, Any] = {}
    try:
        with np.load(io.BytesIO(content), allow_pickle=False) as archive:
            if tuple(archive.files) != expected:
                _fail(
                    "evaluation archive member set differs: "
                    f"actual={archive.files!r} expected={list(expected)!r}"
                )
            for name in allowed:
                arrays[name] = np.asarray(archive[name]).copy()
                access["array_reads"][name] += 1
    except FormalEvaluationError:
        raise
    except (OSError, ValueError, KeyError) as exc:
        raise FormalEvaluationError(f"cannot materialize evaluation arrays: {exc}") from exc
    access["authorized_read_count"] = 1

    dates = np.asarray(arrays["dates_ns"])
    forcing = np.asarray(arrays["forcing"])
    target = np.asarray(arrays["target"])
    if dates.dtype != np.dtype("int64") or dates.shape != (int(expected_days),):
        _fail("evaluation dates_ns must be int64 with the frozen one-dimensional shape")
    if forcing.shape != (int(expected_days), 3) or not np.issubdtype(
        forcing.dtype, np.floating
    ):
        _fail("evaluation forcing must be floating with exact shape (days, 3)")
    if target.shape != (int(expected_days),) or not np.issubdtype(
        target.dtype, np.floating
    ):
        _fail("evaluation target must be floating with exact shape (days,)")
    if not np.isfinite(forcing).all():
        _fail("evaluation forcing contains a non-finite value")
    if len(expected_period) != 2:
        _fail("evaluation period requires two endpoints")
    expected_start = int(np.datetime64(str(expected_period[0]), "ns").astype(np.int64))
    expected_end = int(np.datetime64(str(expected_period[1]), "ns").astype(np.int64))
    if int(dates[0]) != expected_start or int(dates[-1]) != expected_end:
        _fail("evaluation date endpoints differ from the frozen period")
    if not np.all(np.diff(dates) == 86_400_000_000_000):
        _fail("evaluation dates must be strictly increasing daily dates without gaps")
    return arrays


def _prediction_member_names() -> set[str]:
    members = {"dates_ns", "forcing", "target"}
    for lead in LEADS:
        members.add(f"common_mask_lead_{lead}")
        members.update(f"{system}_lead_{lead}" for system in SYSTEMS)
    return members


def _issue_aligned_target_bounds(
    *, count: int, lead: int, warmup_days: int
) -> tuple[int, int]:
    """Map the common issue window to one lead's target-index interval."""

    if int(lead) not in LEADS:
        _fail(f"unsupported forecast lead for issue alignment: {lead}")
    issue_start = int(warmup_days)
    issue_end = int(count) - max(LEADS)
    if not 0 <= issue_start < issue_end:
        _fail("common issue window is empty or reversed")
    return issue_start + int(lead), issue_end + int(lead)


def build_prediction_arrays(
    *,
    dates_ns: Any,
    forcing: Any,
    target: Any,
    predictions: Mapping[str, Mapping[int, Any]],
    warmup_days: int = WARMUP_DAYS,
) -> dict[str, Any]:
    """Build the sealed prediction arrays and one common mask for each lead."""

    np = _np()
    dates = np.asarray(dates_ns)
    forcing_array = np.asarray(forcing)
    target_array = np.asarray(target, dtype=np.float64)
    if dates.dtype != np.dtype("int64") or dates.ndim != 1:
        _fail("dates_ns must be one int64 array")
    count = int(dates.shape[0])
    if forcing_array.ndim != 2 or forcing_array.shape[0] != count:
        _fail("forcing must be two-dimensional and aligned with dates")
    if target_array.shape != (count,):
        _fail("target must be one-dimensional and aligned with dates")
    if not np.isfinite(forcing_array).all():
        _fail("forcing contains a non-finite value")
    if set(predictions) != set(SYSTEMS):
        _fail(
            "prediction systems differ: "
            f"actual={sorted(predictions)!r} expected={sorted(SYSTEMS)!r}"
        )
    if not 0 <= int(warmup_days) < count:
        _fail("warm-up must be nonnegative and shorter than the record")

    arrays: dict[str, Any] = {
        "dates_ns": np.asarray(dates, dtype=np.int64).copy(),
        "forcing": np.asarray(forcing_array, dtype=np.float64).copy(),
        "target": target_array.copy(),
    }
    for system in SYSTEMS:
        by_lead = predictions[system]
        if set(int(value) for value in by_lead) != set(LEADS):
            _fail(f"{system} does not contain exactly leads 1, 2, and 3")
        for lead in LEADS:
            prediction = np.asarray(by_lead[lead], dtype=np.float64)
            if prediction.shape != (count,):
                _fail(f"{system} lead {lead} is not aligned to the evaluation record")
            if np.isinf(prediction).any():
                _fail(f"{system} lead {lead} contains an infinite forecast")
            arrays[f"{system}_lead_{lead}"] = prediction.copy()

    for lead in LEADS:
        zero = arrays[f"strict_zero_gain_knet_lead_{lead}"]
        open_loop = arrays[f"same_forcing_open_loop_lead_{lead}"]
        if not np.array_equal(zero, open_loop, equal_nan=True):
            _fail(
                f"strict zero-gain KalmanNet differs pointwise from regenerated "
                f"same-forcing open loop at lead {lead}"
            )
        common = np.isfinite(target_array)
        for system in SYSTEMS:
            common &= np.isfinite(arrays[f"{system}_lead_{lead}"])
        target_start, target_end = _issue_aligned_target_bounds(
            count=count, lead=lead, warmup_days=int(warmup_days)
        )
        common[:target_start] = False
        common[target_end:] = False
        if int(common.sum()) < 2:
            _fail(f"lead {lead} common mask contains fewer than two targets")
        if float(np.var(target_array[common], ddof=0)) <= 0.0:
            _fail(f"lead {lead} common target variance is not positive")
        arrays[f"common_mask_lead_{lead}"] = common
    if set(arrays) != _prediction_member_names():
        _fail("internal prediction archive member inventory changed")
    return arrays


def _mse_and_population_nse(prediction: Any, target: Any, mask: Any) -> tuple[float, float]:
    np = _np()
    selected = np.asarray(mask, dtype=bool)
    predicted = np.asarray(prediction, dtype=np.float64)[selected]
    observed = np.asarray(target, dtype=np.float64)[selected]
    mse = float(np.mean(np.square(predicted - observed), dtype=np.float64))
    variance = float(np.var(observed, ddof=0, dtype=np.float64))
    if not math.isfinite(mse) or not math.isfinite(variance) or variance <= 0.0:
        _fail("score contains non-finite error or non-positive target variance")
    nse = 1.0 - mse / variance
    if not math.isfinite(nse):
        _fail("population Nash-Sutcliffe efficiency is non-finite")
    return mse, nse


def _comparison_status(delta: float) -> str:
    if delta >= PRACTICAL_EQUIVALENCE_NSE:
        return "KALMANNET_ADVANTAGE"
    if delta <= -PRACTICAL_EQUIVALENCE_NSE:
        return "BACKPROPAGATION_SELECTED_UKF_ADVANTAGE"
    return "NO_DISCERNIBLE_ADVANTAGE"


def score_prediction_arrays(arrays: Mapping[str, Any]) -> dict[str, Any]:
    """Compute only population NSE and physical-unit MSE from common masks."""

    np = _np()
    if set(arrays) != _prediction_member_names():
        _fail("prediction array member inventory differs from the frozen contract")
    target = np.asarray(arrays["target"], dtype=np.float64)
    nse: dict[str, dict[str, float]] = {system: {} for system in SYSTEMS}
    mse: dict[str, dict[str, float]] = {system: {} for system in SYSTEMS}
    target_counts: dict[str, int] = {}
    issue_geometry: dict[str, Any] = {
        "issue_start_index_inclusive": WARMUP_DAYS,
        "issue_end_index_exclusive": len(target) - max(LEADS),
        "nominal_common_issue_count": len(target) - max(LEADS) - WARMUP_DAYS,
        "target_index_interval_by_lead": {},
    }
    for lead in LEADS:
        key = str(lead)
        expected_mask = np.isfinite(target)
        for system in SYSTEMS:
            expected_mask &= np.isfinite(
                np.asarray(arrays[f"{system}_lead_{lead}"], dtype=np.float64)
            )
        target_start, target_end = _issue_aligned_target_bounds(
            count=len(target), lead=lead, warmup_days=WARMUP_DAYS
        )
        expected_mask[:target_start] = False
        expected_mask[target_end:] = False
        issue_geometry["target_index_interval_by_lead"][key] = {
            "start_inclusive": target_start,
            "end_exclusive": target_end,
        }
        stored_mask = np.asarray(arrays[f"common_mask_lead_{lead}"], dtype=bool)
        if not np.array_equal(stored_mask, expected_mask):
            _fail(f"common mask for lead {lead} differs from all-system finite mask")
        target_counts[key] = int(expected_mask.sum())
        for system in SYSTEMS:
            system_mse, system_nse = _mse_and_population_nse(
                arrays[f"{system}_lead_{lead}"], target, expected_mask
            )
            mse[system][key] = system_mse
            nse[system][key] = system_nse

    for lead in LEADS:
        if not np.array_equal(
            arrays[f"strict_zero_gain_knet_lead_{lead}"],
            arrays[f"same_forcing_open_loop_lead_{lead}"],
            equal_nan=True,
        ):
            _fail(f"strict zero-gain and open-loop arrays differ at lead {lead}")

    mean_nse = {
        system: float(np.mean([nse[system][str(lead)] for lead in LEADS], dtype=np.float64))
        for system in SYSTEMS
    }
    mean_mse = {
        system: float(np.mean([mse[system][str(lead)] for lead in LEADS], dtype=np.float64))
        for system in SYSTEMS
    }
    candidate_minus_selected = {
        str(lead): nse["knet_epoch75"][str(lead)]
        - nse["backpropagation_selected_ukf"][str(lead)]
        for lead in LEADS
    }
    candidate_minus_zero = {
        str(lead): nse["knet_epoch75"][str(lead)]
        - nse["strict_zero_gain_knet"][str(lead)]
        for lead in LEADS
    }
    candidate_minus_open = {
        str(lead): nse["knet_epoch75"][str(lead)]
        - nse["same_forcing_open_loop"][str(lead)]
        for lead in LEADS
    }
    mean_delta = float(np.mean(list(candidate_minus_selected.values()), dtype=np.float64))

    failed: list[str] = []
    for lead in LEADS:
        key = str(lead)
        if not nse["knet_epoch75"][key] > MINIMUM_NSE_EXCLUSIVE:
            failed.append(
                f"lead_{lead}_candidate_nse_not_strictly_above_{MINIMUM_NSE_EXCLUSIVE}"
            )
        if not candidate_minus_zero[key] > 0.0:
            failed.append(f"lead_{lead}_candidate_not_better_than_strict_zero_gain")
        if not candidate_minus_open[key] > 0.0:
            failed.append(f"lead_{lead}_candidate_not_better_than_same_forcing_open_loop")
    capability = "PASS" if not failed else "HOLD"
    scale_up = (
        "GO"
        if capability == "PASS"
        and candidate_minus_selected["1"] >= -MAXIMUM_LEAD1_NSE_DEFICIT_VS_SELECTED_UKF
        else "HOLD"
    )
    return {
        "metrics": {
            "target_count_by_lead": target_counts,
            "common_issue_geometry": issue_geometry,
            "nse_by_system_and_lead": nse,
            "mse_by_system_and_lead": mse,
            "equal_lead_mean_nse_by_system": mean_nse,
            "equal_lead_mean_mse_by_system": mean_mse,
        },
        "comparisons": {
            "candidate_minus_backpropagation_selected_ukf_nse_by_lead": (
                candidate_minus_selected
            ),
            "candidate_minus_backpropagation_selected_ukf_nse_equal_lead_mean": (
                mean_delta
            ),
            "candidate_minus_strict_zero_gain_nse_by_lead": candidate_minus_zero,
            "candidate_minus_same_forcing_open_loop_nse_by_lead": candidate_minus_open,
        },
        "decisions": {
            "capability_gate": {"status": capability, "failed_conditions": failed},
            "comparison_status": _comparison_status(mean_delta),
            "scale_up_readiness": scale_up,
            "convergence_status": CONVERGENCE_STATUS,
        },
    }


def semantic_sha256_arrays(arrays: Mapping[str, Any]) -> str:
    np = _np()
    digest = sha256()
    for name in sorted(arrays):
        array = np.ascontiguousarray(np.asarray(arrays[name]))
        digest.update(name.encode("utf-8"))
        digest.update(str(array.dtype).encode("ascii"))
        digest.update(np.asarray(array.shape, dtype=np.int64).tobytes())
        digest.update(array.tobytes())
    return digest.hexdigest()


def _write_exclusive_bytes(path: Path, content: bytes) -> None:
    with Path(path).open("xb") as stream:
        stream.write(content)
        stream.flush()
        os.fsync(stream.fileno())


def _write_exclusive_json(path: Path, payload: Any) -> None:
    _write_exclusive_bytes(path, canonical_json_bytes(payload))


def _validate_ledger_for_publish(ledger: Mapping[str, Any]) -> None:
    expected_keys = {
        "schema_version",
        "experiment_id",
        "evaluation_archive",
        "stored_baseline_prediction_reads",
        "optimizer_steps",
        "training_events",
        "checkpoint_writes",
        "parameter_sha256_before",
        "parameter_sha256_after",
    }
    if set(ledger) != expected_keys:
        _fail("access ledger keys differ from the frozen contract")
    _require_exact(ledger["schema_version"], ACCESS_LEDGER_SCHEMA_VERSION, "ledger schema")
    _require_exact(ledger["experiment_id"], EXPERIMENT_ID, "ledger experiment")
    access = _require_mapping(ledger["evaluation_archive"], "ledger evaluation archive")
    _require_exact(
        access,
        {
            "open_count": 1,
            "authorized_read_count": 1,
            "array_reads": {"dates_ns": 1, "forcing": 1, "target": 1},
        },
        "ledger evaluation access",
    )
    for key in (
        "stored_baseline_prediction_reads",
        "optimizer_steps",
        "training_events",
        "checkpoint_writes",
    ):
        _require_exact(ledger[key], 0, f"ledger.{key}")
    _require_exact(ledger["parameter_sha256_before"], PARAMETER_SHA256, "parameter hash before")
    _require_exact(ledger["parameter_sha256_after"], PARAMETER_SHA256, "parameter hash after")


def publish_results_atomically(
    *,
    output_root: Path,
    config_path: Path,
    config: Mapping[str, Any],
    arrays: Mapping[str, Any],
    ledger: Mapping[str, Any],
) -> dict[str, Any]:
    """Publish four immutable files through a sibling pending directory."""

    np = _np()
    output_root = Path(output_root)
    if output_root.exists() or output_root.is_symlink():
        raise FileExistsError(f"output root already exists and will not be overwritten: {output_root}")
    parent = output_root.parent
    if parent.is_symlink() or not parent.is_dir():
        _fail(f"output parent must be one existing regular directory: {parent}")
    _validate_ledger_for_publish(ledger)
    scored = score_prediction_arrays(arrays)
    pending = parent / f".{output_root.name}.pending-{os.getpid()}-{uuid4().hex}"
    pending.mkdir(mode=0o700)
    try:
        prediction_path = pending / PREDICTIONS_FILE
        with prediction_path.open("xb") as stream:
            np.savez(stream, **arrays)
            stream.flush()
            os.fsync(stream.fileno())
        ledger_path = pending / ACCESS_LEDGER_FILE
        _write_exclusive_json(ledger_path, ledger)
        summary = {
            "schema_version": RESULT_SCHEMA_VERSION,
            "experiment_id": EXPERIMENT_ID,
            "status": RESULT_STATUS,
            "scientific_role": SCIENTIFIC_ROLE,
            "basin_id": BASIN_ID,
            "evaluation_period_role": EVALUATION_PERIOD_ROLE,
            "evaluation_period": list(config["evaluation"]["period"]),
            "warmup_days": int(config["evaluation"]["warmup_days_excluded"]),
            "leads_days": list(LEADS),
            "systems": list(SYSTEMS),
            "checkpoint": {
                "path": str(config["checkpoint"]["path"]),
                "epoch": int(config["checkpoint"]["completed_epoch"]),
                "file_sha256": str(config["checkpoint"]["sha256"]),
                "parameter_sha256": str(config["checkpoint"]["parameter_sha256"]),
            },
            "configuration": {
                "path": str(Path(config_path).resolve()),
                "sha256": sha256_file(Path(config_path)),
            },
            "inputs": deepcopy(config["inputs"]),
            "predictions": {
                "path": PREDICTIONS_FILE,
                "file_sha256": sha256_file(prediction_path),
                "semantic_sha256": semantic_sha256_arrays(arrays),
            },
            "metrics": scored["metrics"],
            "comparisons": scored["comparisons"],
            "decisions": scored["decisions"],
            "access_ledger_sha256": sha256_file(ledger_path),
            "manifest_members_expected": list(MANIFEST_MEMBER_FILES),
        }
        summary_path = pending / RESULT_SUMMARY_FILE
        _write_exclusive_json(summary_path, summary)
        manifest = {
            "schema_version": MANIFEST_SCHEMA_VERSION,
            "experiment_id": EXPERIMENT_ID,
            "status": RESULT_STATUS,
            "configuration_sha256": sha256_file(Path(config_path)),
            "files": {
                name: sha256_file(pending / name) for name in MANIFEST_MEMBER_FILES
            },
        }
        _write_exclusive_json(pending / MANIFEST_FILE, manifest)
        if output_root.exists() or output_root.is_symlink():
            raise FileExistsError(
                f"output root appeared concurrently and will not be overwritten: {output_root}"
            )
        pending.rename(output_root)
        return summary
    except Exception as exc:
        raise type(exc)(f"{exc}; incomplete evidence retained at {pending}") from exc


def exit_code_for_completed_science(scored: Mapping[str, Any]) -> int:
    decisions = _require_mapping(scored.get("decisions"), "completed science decisions")
    capability = _require_mapping(decisions.get("capability_gate"), "capability gate")
    if capability.get("status") not in {"PASS", "HOLD"}:
        _fail("completed science capability status must be PASS or HOLD")
    return 0


def _load_selection(path: Path) -> dict[str, Any]:
    selection = _read_json(path, label="frozen TUKF06 selection")
    _require_exact(selection.get("experiment_id"), "TUKF06_FULL_DIAGONAL_SEARCH_HEAD_TO_HEAD_V1", "selection experiment")
    _require_exact(selection.get("basin_id"), BASIN_ID, "selection basin")
    _require_exact(selection.get("evaluation_period_read"), False, "selection evaluation access")
    _require_exact(selection.get("training_days"), 2557, "selection training days")
    _require_exact(selection.get("state_dimension"), 18, "selection state dimension")
    return selection


def _validate_checkpoint_payload(payload: Any) -> Mapping[str, Any]:
    checkpoint = _require_mapping(payload, "checkpoint payload")
    _require_exact(
        checkpoint.get("schema_version"),
        "daily_camels_ukf_knet_parity_checkpoint_v1",
        "checkpoint schema",
    )
    _require_exact(checkpoint.get("completed_epoch"), CHECKPOINT_EPOCH, "checkpoint epoch")
    identity = _require_mapping(checkpoint.get("identity"), "checkpoint identity")
    actual_identity_hash = sha256(checkpoint_identity_json_bytes(identity)).hexdigest()
    _require_exact(
        checkpoint.get("identity_sha256"), actual_identity_hash, "checkpoint identity hash"
    )
    _require_exact(identity.get("experiment_id"), SOURCE_EXPERIMENT_ID, "checkpoint source experiment")
    _require_exact(identity.get("configuration_sha256"), SOURCE_CONFIGURATION_SHA256, "checkpoint source configuration")
    _require_exact(identity.get("phase"), "train", "checkpoint source phase")
    _require_exact(
        checkpoint.get("gain_initialization"),
        identity.get("gain_initialization"),
        "checkpoint gain initialization",
    )
    _require_exact(
        checkpoint.get("gain_initialization"),
        GAIN_INITIALIZATION,
        "checkpoint frozen gain initialization",
    )
    _require_exact(
        checkpoint.get("correction_scope"),
        identity.get("correction_scope"),
        "checkpoint correction scope",
    )
    history = checkpoint.get("history")
    if not isinstance(history, Sequence) or isinstance(history, (str, bytes)):
        _fail("checkpoint history must be one sequence")
    epochs = [row.get("epoch") if isinstance(row, Mapping) else None for row in history]
    if epochs != list(range(CHECKPOINT_EPOCH + 1)):
        _fail("checkpoint history must contain contiguous epochs 0 through 75")
    _require_exact(history[-1].get("parameter_sha256"), PARAMETER_SHA256, "checkpoint parameter hash evidence")
    if not isinstance(checkpoint.get("model_state"), Mapping):
        _fail("checkpoint model_state must be a mapping")
    return checkpoint


def _theta_from_selection(selection: Mapping[str, Any], method: str, np: Any) -> Any:
    if method not in {"sampling_search", "backpropagation"}:
        _fail(f"unsupported selected filter method: {method}")
    record = _require_mapping(selection.get(method), f"selection.{method}")
    selected = _require_mapping(record.get("selected"), f"selection.{method}.selected")
    theta = np.asarray(selected.get("theta_log"), dtype=np.float64)
    if theta.shape != (19,) or not np.isfinite(theta).all():
        _fail(f"selection.{method}.selected.theta_log must contain 19 finite values")
    return theta


def _prepare_regeneration(
    *,
    config: Mapping[str, Any],
    development_archive: Path,
    selection_path: Path,
    checkpoint_path: Path,
    device: str,
) -> dict[str, Any]:
    """Validate and build every non-protected dependency before the one-shot read."""

    np = _np()
    torch = importlib.import_module("torch")
    if device == "cuda":
        if not torch.cuda.is_available() or int(torch.cuda.device_count()) != 1:
            _fail("formal CUDA evaluation requires exactly one visible GPU")
        if str(torch.cuda.get_device_name(0)) != "NVIDIA A800-SXM4-80GB":
            _fail("formal evaluation GPU must be NVIDIA A800-SXM4-80GB")
    parity_runner = importlib.import_module(
        "global_hydrology.experiments.daily_camels_ukf_knet_parity_runner"
    )
    parity_contract_module = importlib.import_module(
        "global_hydrology.experiments.daily_camels_ukf_knet_parity_contract"
    )
    common = importlib.import_module("scripts.tukf06_full_diagonal_common")
    hbv = importlib.import_module("global_hydrology.models.differentiable_hbv_lite")

    a38_config = _read_json(
        ROOT / "configs" / "daily_camels_knet_epoch40_to80_resume_a38.json",
        label="A38 source configuration",
    )
    parity_contract = parity_contract_module.ParityContract.from_dict(a38_config)
    development_ledger = parity_contract_module.AccessLedger()
    development_runtime = parity_runner.load_archive_context(
        development_archive,
        parity_contract,
        development_ledger,
        initialization_mode=parity_contract_module.CAUSAL_SHARED_SPINUP_MODE,
        device=device,
    )
    expected_development_reads = {
        "dates_ns": 1,
        "forcing": 1,
        "observations": 1,
        "parameters": 1,
        "base_observation_variance": 1,
        "state_dimension": 1,
    }
    _require_exact(
        development_ledger.archive_member_reads,
        expected_development_reads,
        "development archive member reads",
    )
    _require_exact(
        development_ledger.date_requests,
        1,
        "development archive date requests",
    )
    for name in (
        "evaluation_array_reads",
        "evaluation_prediction_count",
        "evaluation_metric_count",
        "evaluation_output_count",
    ):
        _require_exact(
            getattr(development_ledger, name), 0, f"development ledger {name}"
        )
    forbidden = {"initial_storage_state", "initial_state", "initial_covariance"}
    if forbidden.intersection(development_ledger.archive_member_reads):
        _fail("A38 causal runtime read an archived development initialization member")

    selection = _load_selection(selection_path)
    checkpoint_bytes_hash = sha256_file(checkpoint_path)
    _require_exact(checkpoint_bytes_hash, CHECKPOINT_SHA256, "checkpoint second SHA-256")
    checkpoint_payload = _validate_checkpoint_payload(
        torch.load(checkpoint_path, map_location=device, weights_only=False)
    )

    parameters = development_runtime.context.parameters.clone().to(
        device=device, dtype=torch.float64
    )
    field_capacity_index = list(hbv.PARAM_NAMES).index("parFC")
    field_capacity = parameters[:, field_capacity_index : field_capacity_index + 1]
    zero = torch.zeros((1, 1), dtype=torch.float64, device=device)
    initial_storage = torch.cat(
        [
            zero,
            zero,
            0.3 * field_capacity,
            torch.full_like(zero, 5.0),
            torch.full_like(zero, 10.0),
        ],
        dim=-1,
    )
    prior = SimpleNamespace(
        basin_ids=[BASIN_ID], param_table=parameters, x0_table=initial_storage
    )
    evaluation_context = common.build_basin_context(
        prior,
        BASIN_ID,
        development_runtime.observations[: development_runtime.training_days],
        development_runtime.tukf06_contract,
        device=device,
    )
    if not bool(torch.equal(evaluation_context.initial_storage_state, initial_storage)):
        _fail("evaluation context does not retain the A38 causal default storage exactly")

    model = _require_mapping(config["model"], "model")
    candidate = parity_runner.build_native_knet(
        development_runtime,
        zero_gain=False,
        gain_initialization=str(checkpoint_payload["gain_initialization"]),
        seed=int(model["seed"]),
        correction_scope=str(checkpoint_payload["correction_scope"]),
        hidden=int(model["hidden"]),
        in_mult=int(model["input_multiplier"]),
        out_mult=int(model["output_multiplier"]),
        feature_scale_floor=float(model["feature_scale_floor"]),
        normalized_feature_guard=float(model["normalized_feature_guard"]),
    )
    candidate.load_state_dict(checkpoint_payload["model_state"], strict=True)
    before_hash = parity_runner.parameter_sha256(candidate)
    _require_exact(before_hash, PARAMETER_SHA256, "loaded candidate parameter SHA-256")
    candidate.eval()

    strict_zero = parity_runner.build_native_knet(
        development_runtime,
        zero_gain=True,
        gain_initialization=parity_contract_module.NATIVE_DEFAULT_GAIN_INITIALIZATION,
        seed=int(model["seed"]),
        correction_scope=str(model["correction_scope"]),
        hidden=int(model["hidden"]),
        in_mult=int(model["input_multiplier"]),
        out_mult=int(model["output_multiplier"]),
        feature_scale_floor=float(model["feature_scale_floor"]),
        normalized_feature_guard=float(model["normalized_feature_guard"]),
    )
    strict_zero.eval()

    default = _require_mapping(config["ukf"]["default_noise"], "default UKF")
    default_vector = np.asarray(
        list(default["process_diagonal"]) + [float(default["r_b"])],
        dtype=np.float64,
    )
    if (
        default_vector.shape != (19,)
        or not np.isfinite(default_vector).all()
        or np.any(default_vector <= 0)
    ):
        _fail("default UKF noise vector must contain 19 finite positive values")
    default_theta_log = np.log(default_vector)
    sampling_theta_log = _theta_from_selection(selection, "sampling_search", np)
    backpropagation_theta_log = _theta_from_selection(
        selection, "backpropagation", np
    )
    for label, theta_log in (
        ("default", default_theta_log),
        ("sampling_search", sampling_theta_log),
        ("backpropagation", backpropagation_theta_log),
    ):
        try:
            common.decode_theta(
                torch.as_tensor(
                    theta_log,
                    dtype=evaluation_context.dtype,
                    device=evaluation_context.device,
                ),
                evaluation_context.dimension,
                development_runtime.tukf06_contract,
            )
        except Exception as exc:
            raise FormalEvaluationError(
                f"{label} UKF noise vector fails the frozen bounds before evaluation access"
            ) from exc
    return {
        "config": config,
        "device": device,
        "np": np,
        "torch": torch,
        "parity_runner": parity_runner,
        "parity_contract_module": parity_contract_module,
        "parity_contract": parity_contract,
        "common": common,
        "development_runtime": development_runtime,
        "selection": selection,
        "evaluation_context": evaluation_context,
        "candidate": candidate,
        "strict_zero": strict_zero,
        "candidate_parameter_sha256_before": before_hash,
        "default_theta_log": default_theta_log,
        "sampling_theta_log": sampling_theta_log,
        "backpropagation_theta_log": backpropagation_theta_log,
    }


def _regenerate_all_predictions(
    *,
    prepared: Mapping[str, Any],
    evaluation_arrays: Mapping[str, Any],
) -> tuple[dict[str, dict[int, Any]], str]:
    """Regenerate all eight systems after the sole protected-array read."""

    config = _require_mapping(prepared["config"], "prepared configuration")
    device = str(prepared["device"])
    np = prepared["np"]
    torch = prepared["torch"]
    parity_runner = prepared["parity_runner"]
    parity_contract_module = prepared["parity_contract_module"]
    parity_contract = prepared["parity_contract"]
    common = prepared["common"]
    development_runtime = prepared["development_runtime"]
    selection = prepared["selection"]
    evaluation_context = prepared["evaluation_context"]
    candidate = prepared["candidate"]
    strict_zero = prepared["strict_zero"]
    before_hash = str(prepared["candidate_parameter_sha256_before"])

    forcing = torch.as_tensor(
        np.asarray(evaluation_arrays["forcing"], dtype=np.float64),
        dtype=torch.float64,
        device=device,
    ).unsqueeze(1)
    observations = torch.as_tensor(
        np.asarray(evaluation_arrays["target"], dtype=np.float64),
        dtype=torch.float64,
        device=device,
    ).unsqueeze(1)
    dates = np.asarray(evaluation_arrays["dates_ns"], dtype=np.int64).astype(
        "datetime64[ns]"
    )
    initialization_evidence = parity_contract_module.InitializationEvidence(
        mode=parity_contract_module.CAUSAL_SHARED_SPINUP_MODE,
        used_archive_members=(),
        scientific_claim_allowed=True,
        backward_time_leakage=False,
    )
    evaluation_runtime = parity_runner.ParityRuntime(
        contract=parity_contract,
        tukf06_contract=development_runtime.tukf06_contract,
        context=evaluation_context,
        forcing=forcing,
        observations=observations,
        dates=dates,
        training_days=len(dates),
        initialization_evidence=initialization_evidence,
        ledger=parity_contract_module.AccessLedger(),
        archive_path=Path(config["inputs"]["evaluation_archive"]["path"]),
        archive_sha256=str(config["inputs"]["evaluation_archive"]["sha256"]),
        tukf06_module=common,
    )
    window = parity_runner.WindowBatch(
        purpose="formal_evaluation",
        global_start=0,
        global_end_exclusive=len(dates),
        context=evaluation_context,
        forcing=forcing,
        observations=observations,
        dates=dates,
        initial_state=evaluation_context.initial_state.clone(),
        issue_start_local=WARMUP_DAYS,
        issue_end_local=len(dates) - max(LEADS),
    )

    with torch.no_grad():
        candidate_trace = parity_runner.run_knet_filter(candidate, window)
        candidate_predictions = parity_runner.aligned_forecasts_from_posterior(
            evaluation_runtime, window, candidate_trace.posterior_states
        )
    after_hash = parity_runner.parameter_sha256(candidate)
    _require_exact(after_hash, before_hash, "candidate parameter SHA-256 after evaluation")

    with torch.no_grad():
        zero_trace = parity_runner.run_knet_filter(strict_zero, window)
        zero_predictions = parity_runner.aligned_forecasts_from_posterior(
            evaluation_runtime, window, zero_trace.posterior_states
        )

    open_daily = common.open_loop_prediction(evaluation_context, forcing)
    open_predictions: dict[int, Any] = {}
    for lead in LEADS:
        aligned = np.full(len(dates), np.nan, dtype=np.float64)
        target_end = len(dates) - max(LEADS) + lead
        aligned[lead:target_end] = open_daily[lead:target_end]
        open_predictions[lead] = aligned
        if not np.array_equal(zero_predictions[lead], aligned, equal_nan=True):
            _fail(
                f"strict zero-gain KalmanNet differs from regenerated open loop at lead {lead}"
            )

    default_predictions = common.filter_forecasts(
        evaluation_context,
        forcing,
        observations,
        prepared["default_theta_log"],
        development_runtime.tukf06_contract,
    )
    sampling_predictions = common.filter_forecasts(
        evaluation_context,
        forcing,
        observations,
        prepared["sampling_theta_log"],
        development_runtime.tukf06_contract,
    )
    backpropagation_predictions = common.filter_forecasts(
        evaluation_context,
        forcing,
        observations,
        prepared["backpropagation_theta_log"],
        development_runtime.tukf06_contract,
    )
    target = np.asarray(evaluation_arrays["target"], dtype=np.float64)
    persistence = common.persistence_predictions(target)
    development_target = (
        development_runtime.observations[: development_runtime.training_days, 0]
        .detach()
        .cpu()
        .numpy()
    )
    autoregression = common.second_order_autoregression_predictions(
        development_target, target
    )
    return (
        {
            "knet_epoch75": candidate_predictions,
            "strict_zero_gain_knet": zero_predictions,
            "same_forcing_open_loop": open_predictions,
            "default_noise_ukf": default_predictions,
            "sampled_search_ukf": sampling_predictions,
            "backpropagation_selected_ukf": backpropagation_predictions,
            "persistence": persistence,
            "second_order_autoregression": autoregression,
        },
        after_hash,
    )


def _validate_sources(config: Mapping[str, Any]) -> None:
    source_files = _require_mapping(config["source_files"], "source_files")
    for relative, expected in source_files.items():
        if relative == FORBIDDEN_TRAINING_ENTRY:
            _fail("formal evaluation source inventory forbids the legacy training entry")
        candidate = (ROOT / str(relative)).resolve()
        try:
            candidate.relative_to(ROOT.resolve())
        except ValueError as exc:
            raise FormalEvaluationError(f"source path escapes repository root: {relative}") from exc
        _validate_file(
            candidate,
            expected_sha256=str(expected),
            expected_size_bytes=None,
            label=f"frozen source {relative}",
        )


def execute(arguments: argparse.Namespace) -> dict[str, Any]:
    """Execute one hash-bound formal evaluation; scientific HOLD still completes."""

    config_path = Path(arguments.config).resolve()
    config = load_and_validate_config(config_path)
    _validate_sources(config)
    output_root = Path(arguments.output_root).resolve()
    if output_root != Path(str(config["output_root"])).resolve():
        _fail("command-line output root differs from the frozen configuration")
    if output_root.exists() or output_root.is_symlink():
        raise FileExistsError(f"output root already exists and will not be overwritten: {output_root}")
    if arguments.device != "cuda":
        _fail("formal execution device must be cuda")

    inputs = _require_mapping(config["inputs"], "inputs")
    development = _require_mapping(inputs["development_archive"], "development archive")
    selection = _require_mapping(inputs["selection"], "selection")
    evaluation = _require_mapping(inputs["evaluation_archive"], "evaluation archive")
    development_path = _validate_file(
        Path(arguments.development_archive).resolve(),
        expected_sha256=str(development["sha256"]),
        expected_size_bytes=int(development["size_bytes"]),
        label="development archive",
    )
    selection_path = _validate_file(
        Path(arguments.selection).resolve(),
        expected_sha256=str(selection["sha256"]),
        expected_size_bytes=int(selection["size_bytes"]),
        label="selection",
    )
    checkpoint_path = Path(arguments.checkpoint).resolve()
    if checkpoint_path != Path(CHECKPOINT_PATH).resolve():
        _fail("command-line checkpoint path differs from the frozen checkpoint path")
    _validate_file(
        checkpoint_path,
        expected_sha256=CHECKPOINT_SHA256,
        expected_size_bytes=CHECKPOINT_SIZE_BYTES,
        label="epoch-75 checkpoint",
    )
    evaluation_path = Path(arguments.evaluation_archive).resolve()
    if evaluation_path != Path(str(evaluation["path"])).resolve():
        _fail("command-line evaluation archive differs from the frozen path")

    prepared = _prepare_regeneration(
        config=config,
        development_archive=development_path,
        selection_path=selection_path,
        checkpoint_path=checkpoint_path,
        device=str(arguments.device),
    )
    ledger = new_access_ledger(PARAMETER_SHA256)
    evaluation_arrays = load_evaluation_archive_once(
        evaluation_path,
        expected_sha256=str(evaluation["sha256"]),
        expected_size_bytes=int(evaluation["size_bytes"]),
        expected_archive_members=tuple(evaluation["expected_archive_members"]),
        allowed_array_reads=tuple(config["execution_policy"]["allowed_evaluation_array_members"]),
        expected_days=EXPECTED_DAYS,
        expected_period=EVALUATION_PERIOD,
        ledger=ledger,
    )
    predictions, parameter_hash_after = _regenerate_all_predictions(
        prepared=prepared,
        evaluation_arrays=evaluation_arrays,
    )
    _require_exact(parameter_hash_after, PARAMETER_SHA256, "final parameter SHA-256")
    ledger["parameter_sha256_after"] = parameter_hash_after
    arrays = build_prediction_arrays(
        dates_ns=evaluation_arrays["dates_ns"],
        forcing=evaluation_arrays["forcing"],
        target=evaluation_arrays["target"],
        predictions=predictions,
        warmup_days=WARMUP_DAYS,
    )
    return publish_results_atomically(
        output_root=output_root,
        config_path=config_path,
        config=config,
        arrays=arrays,
        ledger=ledger,
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--development-archive", type=Path, required=True)
    parser.add_argument("--selection", type=Path, required=True)
    parser.add_argument("--evaluation-archive", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--device", choices=("cpu", "cuda"), required=True)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    arguments = build_parser().parse_args(argv)
    try:
        summary = execute(arguments)
    except Exception as exc:
        print(f"A39_FORMAL_EVALUATION_TECHNICAL_ERROR: {exc}", file=sys.stderr)
        return 2
    decisions = summary["decisions"]
    print(
        "A39_FORMAL_EVALUATION_COMPLETE "
        f"capability={decisions['capability_gate']['status']} "
        f"comparison={decisions['comparison_status']} "
        f"scale_up={decisions['scale_up_readiness']} "
        f"convergence={decisions['convergence_status']}"
    )
    return exit_code_for_completed_science(summary)


if __name__ == "__main__":
    raise SystemExit(main())
