"""Build the deterministic daily CAMELS native KalmanNet HPC smoke bundle.

The command has a fixed file allowlist.  It never imports the experiment entry,
PyTorch, NumPy, or a CAMELS loader, and it treats the two already-frozen
development archives as opaque bytes.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import gzip
from hashlib import sha256
from io import BytesIO
import json
import os
from pathlib import Path, PurePosixPath
import re
import tarfile
from typing import Any, Mapping
import uuid


ROOT = Path(__file__).resolve().parents[1]
EXPERIMENT_ID = "DAILY_CAMELS_NATIVE_KALMANNET_SMOKE_V1_20260824_A01"
ARCHIVE_NAME = f"{EXPERIMENT_ID}.tar.gz"
DEFAULT_OUTPUT = ROOT / "artifacts" / "daily_camels_native_knet_hpc_bundle_v1"


# Archive member -> repository-relative source path.  The two archives are
# deliberately renamed below ``inputs/`` so no historical result tree is
# reproduced on the cluster.
SOURCE_MEMBER_PATHS: dict[str, str] = {
    "configs/daily_camels_native_kalmannet_smoke_v1.json": (
        "configs/daily_camels_native_kalmannet_smoke_v1.json"
    ),
    "hpc/daily_camels_native_kalmannet/preflight.py": (
        "hpc/daily_camels_native_kalmannet/preflight.py"
    ),
    "hpc/daily_camels_native_kalmannet/submit_probe_gpu.slurm": (
        "hpc/daily_camels_native_kalmannet/submit_probe_gpu.slurm"
    ),
    "hpc/daily_camels_native_kalmannet/submit_smoke_gpu.slurm": (
        "hpc/daily_camels_native_kalmannet/submit_smoke_gpu.slurm"
    ),
    "inputs/basin_04105700.npz": (
        "results/tukf06_full_diagonal_search_head_to_head_v1/selection_inputs/"
        "basin_04105700.npz"
    ),
    "inputs/basin_09035800.npz": (
        "results/tukf06_full_diagonal_search_head_to_head_v1/selection_inputs/"
        "basin_09035800.npz"
    ),
    "knet/dl/nn_kalman_clamp_5.py": "knet/dl/nn_kalman_clamp_5.py",
    "scripts/build_daily_camels_native_kalmannet_hpc_bundle.py": (
        "scripts/build_daily_camels_native_kalmannet_hpc_bundle.py"
    ),
    "scripts/run_daily_camels_native_kalmannet.py": (
        "scripts/run_daily_camels_native_kalmannet.py"
    ),
    "src/global_hydrology/experiments/daily_camels_native_knet_contract.py": (
        "src/global_hydrology/experiments/daily_camels_native_knet_contract.py"
    ),
    "src/global_hydrology/experiments/daily_camels_native_knet_data.py": (
        "src/global_hydrology/experiments/daily_camels_native_knet_data.py"
    ),
    "src/global_hydrology/experiments/daily_camels_native_knet_io.py": (
        "src/global_hydrology/experiments/daily_camels_native_knet_io.py"
    ),
    "src/global_hydrology/experiments/daily_camels_native_knet_training.py": (
        "src/global_hydrology/experiments/daily_camels_native_knet_training.py"
    ),
    "src/global_hydrology/models/differentiable_hbv_lite.py": (
        "src/global_hydrology/models/differentiable_hbv_lite.py"
    ),
    "src/global_hydrology/models/hbvlite_system_model.py": (
        "src/global_hydrology/models/hbvlite_system_model.py"
    ),
    "src/global_hydrology/models/knet_native_hbvlite.py": (
        "src/global_hydrology/models/knet_native_hbvlite.py"
    ),
}

EMPTY_PACKAGE_MEMBERS = (
    "knet/__init__.py",
    "knet/dl/__init__.py",
    "scripts/__init__.py",
    "src/global_hydrology/__init__.py",
    "src/global_hydrology/experiments/__init__.py",
    "src/global_hydrology/models/__init__.py",
)

FROZEN_INPUT_HASHES = {
    "inputs/basin_04105700.npz": (
        "08d7e8930cd4df624efaf578bedd9615d238f51901ee2a1054bd0e8503e0f82e"
    ),
    "inputs/basin_09035800.npz": (
        "71e6d163507ae405204bedf63d2c6c06e2c3ea303cea1a0481cfa4d5f280f5fd"
    ),
}

FROZEN_SOURCE_HASHES = {
    "knet/dl/nn_kalman_clamp_5.py": (
        "934570d3c840e9d57b8fbddf3a018dc29e190cdd712fc9daaf442e383f74d843"
    ),
    "src/global_hydrology/models/knet_native_hbvlite.py": (
        "df0ccc3249022cafddb2048a97d5198f32569a58a7d4e43029a9514cc340208b"
    ),
    "src/global_hydrology/models/hbvlite_system_model.py": (
        "0d32d0f8dc656bdfbea81ba9f61eba0775ecc770d4466ff0442597d7c8d7a597"
    ),
    "src/global_hydrology/models/differentiable_hbv_lite.py": (
        "d7a04be86f19cddd8b9703e432fafb999a38215cb85de8983fe39a40bda0d6ea"
    ),
}

TEXT_SUFFIXES = frozenset({".json", ".py", ".slurm", ".sh", ".txt"})
WINDOWS_ABSOLUTE_PATH = re.compile(rb"(?i)(?:^|[\"'\s(])[a-z]:[\\/]")


@dataclass(frozen=True)
class BundleManifest:
    archive_path: Path
    archive_sha256: str
    archive_size: int
    manifest_path: Path
    member_sha256: dict[str, str]
    member_size: dict[str, int]


@dataclass(frozen=True)
class ArchiveInspection:
    payloads: dict[str, bytes]
    manifest: dict[str, Any]


def _json_bytes(payload: Mapping[str, Any]) -> bytes:
    return (
        json.dumps(
            payload,
            allow_nan=False,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        + "\n"
    ).encode("utf-8")


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _validate_digest(value: str, label: str) -> None:
    if len(value) != 64 or any(character not in "0123456789abcdef" for character in value):
        raise ValueError(f"invalid lowercase SHA-256 for {label}")


def _validate_member_name(name: str) -> None:
    if "\\" in name:
        raise ValueError(f"bundle member must use forward slashes: {name}")
    path = PurePosixPath(name)
    if path.is_absolute() or not path.parts or ".." in path.parts:
        raise ValueError(f"unsafe bundle member name: {name}")
    lowered = tuple(part.lower() for part in path.parts)
    if (
        any("hourly" in part for part in lowered)
        or any(part == "evaluation" or part.startswith("evaluation_") for part in lowered)
        or ".git" in lowered
        or "__pycache__" in lowered
    ):
        raise ValueError(f"forbidden bundle member name: {name}")


def bundle_member_sources(root: Path = ROOT) -> dict[str, Path]:
    project_root = Path(root)
    sources = {
        member: project_root / relative
        for member, relative in SOURCE_MEMBER_PATHS.items()
    }
    _validate_source_inventory(sources)
    return dict(sorted(sources.items()))


def _validate_source_inventory(source_paths: Mapping[str, Path]) -> None:
    expected = set(SOURCE_MEMBER_PATHS)
    actual = set(source_paths)
    if actual != expected:
        missing = sorted(expected - actual)
        extra = sorted(actual - expected)
        raise ValueError(f"bundle source allowlist differs; missing={missing}, extra={extra}")
    for name, source in source_paths.items():
        _validate_member_name(name)
        path = Path(source)
        if not path.is_file():
            raise FileNotFoundError(f"bundle source is absent: {name} <- {path}")
        if path.is_symlink():
            raise RuntimeError(f"bundle source may not be a symbolic link: {name}")


def _verify_expected_hashes(
    source_paths: Mapping[str, Path],
    expected_hashes: Mapping[str, str],
    required_names: set[str],
    label: str,
) -> None:
    if set(expected_hashes) != required_names:
        raise ValueError(f"{label} hash inventory differs from its frozen names")
    for name in sorted(required_names):
        expected = str(expected_hashes[name])
        _validate_digest(expected, name)
        actual = sha256_file(Path(source_paths[name]))
        if actual != expected:
            raise RuntimeError(
                f"{label} SHA-256 mismatch for {name}: expected {expected}, got {actual}"
            )


def _validate_text_payload(name: str, content: bytes) -> None:
    if PurePosixPath(name).suffix.lower() not in TEXT_SUFFIXES:
        return
    if b"\x00" in content:
        raise RuntimeError(f"text bundle member contains a null byte: {name}")
    if WINDOWS_ABSOLUTE_PATH.search(content):
        raise RuntimeError(f"text bundle member contains a Windows absolute path: {name}")
    # Guard modules and packaging tools must name forbidden concepts in order to
    # reject them.  Runtime science modules may not depend on the old hourly path.
    if name not in {
        "scripts/build_daily_camels_native_kalmannet_hpc_bundle.py",
        "hpc/daily_camels_native_kalmannet/preflight.py",
    } and b"hourly_camels" in content.lower():
        raise RuntimeError(f"runtime bundle member references the hourly data path: {name}")
    # The contract itself contains the two dates only as a fail-closed guard.
    if name not in {
        "src/global_hydrology/experiments/daily_camels_native_knet_contract.py",
        "scripts/build_daily_camels_native_kalmannet_hpc_bundle.py",
    }:
        for forbidden_date in (b"1989-10-01", b"1999-09-30"):
            if forbidden_date in content:
                raise RuntimeError(
                    f"runtime bundle member references a reserved date: {name}"
                )


def _payloads(
    source_paths: Mapping[str, Path],
    expected_input_hashes: Mapping[str, str],
    expected_source_hashes: Mapping[str, str],
) -> tuple[dict[str, bytes], dict[str, Any]]:
    _validate_source_inventory(source_paths)
    _verify_expected_hashes(
        source_paths,
        expected_input_hashes,
        set(FROZEN_INPUT_HASHES),
        "input",
    )
    _verify_expected_hashes(
        source_paths,
        expected_source_hashes,
        set(FROZEN_SOURCE_HASHES),
        "source",
    )
    payloads = {
        name: Path(source_paths[name]).read_bytes() for name in sorted(source_paths)
    }
    payloads.update({name: b"" for name in EMPTY_PACKAGE_MEMBERS})
    for name, content in payloads.items():
        _validate_member_name(name)
        _validate_text_payload(name, content)
    member_sha256 = {
        name: sha256(content).hexdigest() for name, content in sorted(payloads.items())
    }
    member_size = {
        name: len(content) for name, content in sorted(payloads.items())
    }
    manifest = {
        "schema_version": "daily_camels_native_kalmannet_hpc_bundle_v1",
        "experiment_id": EXPERIMENT_ID,
        "purpose": "daily_development_smoke_only",
        "member_count": len(payloads),
        "input_archive_count": 2,
        "reserved_data_member_count": 0,
        "member_sha256": member_sha256,
        "member_size": member_size,
        "frozen_input_sha256": dict(sorted(expected_input_hashes.items())),
        "pinned_source_sha256": dict(sorted(expected_source_hashes.items())),
        "package_initializers": list(EMPTY_PACKAGE_MEMBERS),
    }
    return dict(sorted(payloads.items())), manifest


def _archive_bytes(payloads: Mapping[str, bytes], manifest: Mapping[str, Any]) -> bytes:
    archive_payloads = dict(payloads)
    archive_payloads["bundle_manifest.json"] = _json_bytes(manifest)
    raw = BytesIO()
    with gzip.GzipFile(
        fileobj=raw,
        mode="wb",
        filename="",
        mtime=0,
        compresslevel=9,
    ) as compressed:
        with tarfile.open(
            fileobj=compressed,
            mode="w",
            format=tarfile.USTAR_FORMAT,
        ) as archive:
            for name in sorted(archive_payloads):
                content = archive_payloads[name]
                information = tarfile.TarInfo(name=name)
                information.size = len(content)
                information.mtime = 0
                information.uid = 0
                information.gid = 0
                information.uname = ""
                information.gname = ""
                information.mode = (
                    0o755 if name.endswith((".slurm", ".sh")) else 0o644
                )
                archive.addfile(information, BytesIO(content))
    return raw.getvalue()


def inspect_archive(archive_path: Path) -> ArchiveInspection:
    payloads: dict[str, bytes] = {}
    with tarfile.open(Path(archive_path), "r:gz") as archive:
        members = archive.getmembers()
        names = [member.name for member in members]
        if names != sorted(names) or len(names) != len(set(names)):
            raise RuntimeError("archive member order or uniqueness differs")
        for member in members:
            _validate_member_name(member.name)
            if (
                not member.isfile()
                or member.issym()
                or member.islnk()
                or member.uid != 0
                or member.gid != 0
                or member.uname != ""
                or member.gname != ""
                or member.mtime != 0
            ):
                raise RuntimeError(f"archive member metadata differs: {member.name}")
            stream = archive.extractfile(member)
            if stream is None:
                raise RuntimeError(f"archive member cannot be read: {member.name}")
            payloads[member.name] = stream.read()

    manifest_content = payloads.get("bundle_manifest.json")
    if manifest_content is None:
        raise RuntimeError("archive internal manifest is absent")
    manifest = json.loads(manifest_content.decode("utf-8"))
    if not isinstance(manifest, dict):
        raise RuntimeError("archive internal manifest must be a JSON object")
    expected_payload_names = set(manifest.get("member_sha256", {}))
    if set(payloads) != expected_payload_names | {"bundle_manifest.json"}:
        raise RuntimeError("archive inventory differs from internal manifest")
    if (
        manifest.get("schema_version")
        != "daily_camels_native_kalmannet_hpc_bundle_v1"
        or manifest.get("experiment_id") != EXPERIMENT_ID
        or manifest.get("input_archive_count") != 2
        or manifest.get("reserved_data_member_count") != 0
    ):
        raise RuntimeError("archive internal identity or data policy differs")
    input_names = sorted(name for name in expected_payload_names if name.endswith(".npz"))
    if input_names != sorted(FROZEN_INPUT_HASHES):
        raise RuntimeError("archive must contain exactly the two allowlisted input archives")
    for name in sorted(expected_payload_names):
        content = payloads[name]
        if sha256(content).hexdigest() != manifest["member_sha256"][name]:
            raise RuntimeError(f"archive member SHA-256 mismatch: {name}")
        if len(content) != int(manifest["member_size"][name]):
            raise RuntimeError(f"archive member size mismatch: {name}")
        _validate_text_payload(name, content)
    for name in EMPTY_PACKAGE_MEMBERS:
        if payloads.get(name) != b"":
            raise RuntimeError(f"isolated package initializer is not empty: {name}")
    return ArchiveInspection(payloads=payloads, manifest=manifest)


def _write_new_file(path: Path, content: bytes) -> None:
    with Path(path).open("xb") as handle:
        handle.write(content)
        handle.flush()
        os.fsync(handle.fileno())


def _existing_bundle(
    destination: Path, archive_bytes: bytes, manifest_bytes: bytes
) -> BundleManifest | None:
    if not destination.exists():
        return None
    archive_path = destination / ARCHIVE_NAME
    manifest_path = destination / "bundle_manifest.sha256.json"
    if (
        not destination.is_dir()
        or not archive_path.is_file()
        or not manifest_path.is_file()
        or archive_path.read_bytes() != archive_bytes
        or manifest_path.read_bytes() != manifest_bytes
        or len(list(destination.iterdir())) != 2
    ):
        raise FileExistsError(f"refusing to replace a different bundle directory: {destination}")
    inspection = inspect_archive(archive_path)
    return BundleManifest(
        archive_path=archive_path,
        archive_sha256=sha256(archive_bytes).hexdigest(),
        archive_size=len(archive_bytes),
        manifest_path=manifest_path,
        member_sha256=dict(inspection.manifest["member_sha256"]),
        member_size={
            name: int(size)
            for name, size in inspection.manifest["member_size"].items()
        },
    )


def build_bundle(
    destination: Path = DEFAULT_OUTPUT,
    *,
    source_paths: Mapping[str, Path] | None = None,
    expected_input_hashes: Mapping[str, str] | None = None,
    expected_source_hashes: Mapping[str, str] | None = None,
) -> BundleManifest:
    """Create or byte-verify one fixed, deterministic bundle directory."""

    sources = (
        bundle_member_sources(ROOT)
        if source_paths is None
        else {name: Path(path) for name, path in source_paths.items()}
    )
    input_hashes = (
        FROZEN_INPUT_HASHES
        if expected_input_hashes is None
        else dict(expected_input_hashes)
    )
    source_hashes = (
        FROZEN_SOURCE_HASHES
        if expected_source_hashes is None
        else dict(expected_source_hashes)
    )
    payloads, internal_manifest = _payloads(
        sources,
        input_hashes,
        source_hashes,
    )
    archive_bytes = _archive_bytes(payloads, internal_manifest)
    internal_manifest_bytes = _json_bytes(internal_manifest)
    outer_manifest = {
        "schema_version": "daily_camels_native_kalmannet_hpc_archive_v1",
        "experiment_id": EXPERIMENT_ID,
        "archive_name": ARCHIVE_NAME,
        "archive_sha256": sha256(archive_bytes).hexdigest(),
        "archive_size": len(archive_bytes),
        "internal_manifest_sha256": sha256(internal_manifest_bytes).hexdigest(),
        "member_count": len(payloads),
        "input_archive_count": 2,
        "reserved_data_member_count": 0,
        "member_sha256": internal_manifest["member_sha256"],
        "member_size": internal_manifest["member_size"],
    }
    outer_manifest_bytes = _json_bytes(outer_manifest)

    target = Path(destination)
    existing = _existing_bundle(target, archive_bytes, outer_manifest_bytes)
    if existing is not None:
        return existing

    target.parent.mkdir(parents=True, exist_ok=True)
    pending = target.with_name(target.name + f".pending-{uuid.uuid4().hex}")
    pending.mkdir(parents=False, exist_ok=False)
    pending_archive = pending / ARCHIVE_NAME
    pending_manifest = pending / "bundle_manifest.sha256.json"
    try:
        _write_new_file(pending_archive, archive_bytes)
        _write_new_file(pending_manifest, outer_manifest_bytes)
        inspection = inspect_archive(pending_archive)
        if (
            inspection.manifest != internal_manifest
            or sha256(pending_archive.read_bytes()).hexdigest()
            != outer_manifest["archive_sha256"]
        ):
            raise RuntimeError("pending bundle verification differs")
        if target.exists():
            raise FileExistsError(
                f"refusing to replace a different bundle directory: {target}"
            )
        os.replace(pending, target)
    finally:
        if pending.exists():
            for file_path in (pending_archive, pending_manifest):
                if file_path.exists():
                    file_path.unlink()
            pending.rmdir()

    return BundleManifest(
        archive_path=target / ARCHIVE_NAME,
        archive_sha256=str(outer_manifest["archive_sha256"]),
        archive_size=len(archive_bytes),
        manifest_path=target / "bundle_manifest.sha256.json",
        member_sha256=dict(internal_manifest["member_sha256"]),
        member_size=dict(internal_manifest["member_size"]),
    )


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build the deterministic daily CAMELS KalmanNet HPC smoke bundle."
    )
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    arguments = parser.parse_args()
    result = build_bundle(arguments.output)
    print(
        json.dumps(
            {
                "archive": str(result.archive_path),
                "archive_sha256": result.archive_sha256,
                "archive_size": result.archive_size,
                "manifest": str(result.manifest_path),
                "member_count": len(result.member_sha256),
                "input_archive_count": 2,
                "submitted": False,
            },
            indent=2,
            sort_keys=True,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
