"""Daily-only CAMELS development data for the native KalmanNet rebuild.

This module has one narrow input boundary: a frozen development archive.  It
materializes only the four members admitted by the daily experiment contract.
The saved end-of-period hydrological states are deliberately neither named nor
looked up here; HBV-light always starts from its parameter-derived default
storage and an empty routing queue.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import math
from pathlib import Path
from typing import Any

import numpy as np
import torch

from global_hydrology.experiments.daily_camels_native_knet_contract import (
    ALLOWED_ARCHIVE_MEMBERS,
    AccessLedger,
    DailyKNetContract,
    validate_daily_dates,
)
from global_hydrology.models.differentiable_hbv_lite import (
    PARAM_NAMES,
    recession_half_weights,
)
from global_hydrology.models.hbvlite_system_model import HBVLiteSystemModel


EXPECTED_DAYS = 3_288
EXPECTED_FORCING_CHANNELS = 3
EXPECTED_PARAMETERS = len(PARAM_NAMES)
STORAGE_DIMENSION = 5
SCALE_MARGIN = 1.2
SCALE_FLOOR = 1.0e-6
STATE_BOUND_FLOOR = 1.0
STATE_UPPER_BOUND_MULTIPLIER = 2.0


@dataclass(frozen=True)
class DailyBasinArrays:
    """Copied NumPy arrays from one frozen daily development archive."""

    basin_id: str
    dates_ns: np.ndarray
    forcing: np.ndarray
    observations: np.ndarray
    parameters: np.ndarray
    source_sha256: str


@dataclass(frozen=True)
class PreparedDailyBasin:
    """Causal tensors and training-only statistics for one daily basin."""

    basin_id: str
    training_start_index: int
    validation_start_index: int
    system: HBVLiteSystemModel
    initial_state: torch.Tensor
    forcing: torch.Tensor
    observations: torch.Tensor
    valid_observations: torch.Tensor
    open_loop_discharge: torch.Tensor
    open_loop_states: torch.Tensor
    observation_diff_scale: torch.Tensor
    storage_diff_scale: torch.Tensor
    state_upper_bound: torch.Tensor
    field_capacity: torch.Tensor
    parameters: torch.Tensor
    dates_ns: np.ndarray
    ar2_coefficients: torch.Tensor
    training_observation_variance: float
    normalized_feature_guard: float

    def state_immediately_before(self, index: int) -> torch.Tensor:
        """Return the causal open-loop state immediately before ``index``.

        The open-loop trajectory stores post-transition states, so the state
        before day ``index`` is row ``index - 1``.  Day zero alone uses the
        parameter-derived default state.
        """

        if index < 0 or index > len(self.open_loop_states):
            raise ValueError("state index is outside the daily trajectory")
        if index == 0:
            return self.initial_state.clone()
        return self.open_loop_states[index - 1].clone()


def sha256_file(path: Path) -> str:
    """Return the complete-file SHA-256 without opening it as an array archive."""

    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _copy_member(archive: Any, ledger: AccessLedger, name: str) -> np.ndarray:
    """Record the access immediately before indexing one allowlisted member."""

    ledger.record("archive_member", name)
    return np.asarray(archive[name]).copy()


def _validate_archive_arrays(
    dates_ns: np.ndarray,
    forcing: np.ndarray,
    observations: np.ndarray,
    parameters: np.ndarray,
    contract: DailyKNetContract,
) -> None:
    if dates_ns.ndim != 1 or dates_ns.shape != (EXPECTED_DAYS,):
        raise ValueError(f"dates_ns must have shape ({EXPECTED_DAYS},)")
    validate_daily_dates(dates_ns, contract)
    if forcing.shape != (EXPECTED_DAYS, EXPECTED_FORCING_CHANNELS):
        raise ValueError(
            f"forcing must have shape ({EXPECTED_DAYS}, {EXPECTED_FORCING_CHANNELS})"
        )
    if observations.shape != (EXPECTED_DAYS,):
        raise ValueError(f"observations must have shape ({EXPECTED_DAYS},)")
    if parameters.shape != (1, EXPECTED_PARAMETERS):
        raise ValueError(f"parameters must have shape (1, {EXPECTED_PARAMETERS})")
    if not np.issubdtype(forcing.dtype, np.number) or not bool(np.isfinite(forcing).all()):
        raise ValueError("forcing must be numeric and finite")
    if not np.issubdtype(parameters.dtype, np.number) or not bool(
        np.isfinite(parameters).all()
    ):
        raise ValueError("parameters must be numeric and finite")
    if not np.issubdtype(observations.dtype, np.number):
        raise ValueError("observations must be numeric")
    if not bool((np.isfinite(observations) | np.isnan(observations)).all()):
        raise ValueError("observations may contain only finite values or NaN")


def load_daily_selection_archive(
    path: Path,
    expected_sha256: str,
    contract: DailyKNetContract,
    ledger: AccessLedger,
) -> DailyBasinArrays:
    """Verify and materialize exactly four allowlisted development arrays.

    Extra members may remain in a historical archive, but they are never
    indexed.  This is why the member access ledger, rather than archive
    presence alone, is the evidence of semantic isolation.
    """

    path = Path(path)
    expected = str(expected_sha256).lower()
    if len(expected) != 64 or any(character not in "0123456789abcdef" for character in expected):
        raise ValueError("expected SHA-256 must be 64 lowercase hexadecimal characters")
    actual = sha256_file(path)
    if actual.lower() != expected:
        raise ValueError(
            f"archive SHA-256 mismatch for {path.name}: expected {expected}, got {actual}"
        )

    member_order = ("dates_ns", "forcing", "observations", "parameters")
    if set(member_order) != set(ALLOWED_ARCHIVE_MEMBERS):
        raise RuntimeError("data reader and contract archive allowlist disagree")
    with np.load(path, allow_pickle=False) as archive:
        available = set(archive.files)
        missing = [name for name in member_order if name not in available]
        if missing:
            raise ValueError(f"archive is missing required members: {missing}")
        copied = {
            name: _copy_member(archive, ledger, name)
            for name in member_order
        }

    _validate_archive_arrays(
        copied["dates_ns"],
        copied["forcing"],
        copied["observations"],
        copied["parameters"],
        contract,
    )
    basin_id = path.stem.removeprefix("basin_")
    if len(basin_id) != 8 or not basin_id.isdigit():
        raise ValueError("daily archive name must be basin_ followed by eight digits")
    return DailyBasinArrays(
        basin_id=basin_id,
        dates_ns=copied["dates_ns"],
        forcing=copied["forcing"],
        observations=copied["observations"],
        parameters=copied["parameters"],
        source_sha256=actual.lower(),
    )


def _simulate_open_loop(
    system: HBVLiteSystemModel,
    initial_state: torch.Tensor,
    forcing: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor]:
    discharge: list[torch.Tensor] = []
    states: list[torch.Tensor] = []
    state = initial_state.clone()
    with torch.no_grad():
        for index in range(len(forcing)):
            state = system.f(state, forcing[index : index + 1])
            flow = system.h(state).reshape(())
            if not bool(torch.isfinite(state).all()) or not bool(torch.isfinite(flow)):
                raise FloatingPointError(f"nonfinite open-loop value at daily index {index}")
            states.append(state.clone())
            discharge.append(flow.clone())
    return torch.stack(discharge), torch.stack(states)


def _finite_max_abs_difference(values: torch.Tensor, *, floor: float) -> torch.Tensor:
    if values.shape[0] < 2:
        raise ValueError("at least two training rows are required to compute differences")
    differences = values[1:] - values[:-1]
    finite = torch.isfinite(values[1:]) & torch.isfinite(values[:-1])
    if differences.ndim == 1:
        valid_values = differences[finite].abs()
        maximum = valid_values.max() if valid_values.numel() else differences.new_tensor(0.0)
        return torch.clamp(maximum, min=floor)
    safe = torch.where(finite, differences.abs(), torch.zeros_like(differences))
    maximum = safe.max(dim=0).values
    return torch.clamp(maximum, min=floor)


def _normalise_training_slice(length: int, training_slice: slice) -> tuple[int, int]:
    if training_slice.step not in (None, 1):
        raise ValueError("training slice must be contiguous")
    start = 0 if training_slice.start is None else int(training_slice.start)
    stop = length if training_slice.stop is None else int(training_slice.stop)
    if start < 0 or stop > length or stop - start < 3:
        raise ValueError("training slice must contain at least three in-range rows")
    return start, stop


def fit_training_ar2(
    open_loop: np.ndarray,
    observations: np.ndarray,
    training_slice: slice,
) -> np.ndarray:
    """Fit a no-intercept second-order autoregression on training residuals only."""

    simulated = np.asarray(open_loop, dtype=np.float64).reshape(-1)
    observed = np.asarray(observations, dtype=np.float64).reshape(-1)
    if simulated.shape != observed.shape:
        raise ValueError("open-loop and observation arrays must have the same length")
    start, stop = _normalise_training_slice(len(simulated), training_slice)
    residual = observed[start:stop] - simulated[start:stop]
    target = residual[2:]
    design = np.column_stack([residual[1:-1], residual[:-2]])
    valid = np.isfinite(target) & np.isfinite(design).all(axis=1)
    if int(valid.sum()) < 3:
        raise ValueError("too few finite training residual triples to fit AR(2)")
    coefficients = np.linalg.lstsq(design[valid], target[valid], rcond=None)[0]
    if coefficients.shape != (2,) or not bool(np.isfinite(coefficients).all()):
        raise FloatingPointError("nonfinite AR(2) coefficients")
    return coefficients.astype(np.float64, copy=False)


def prepare_daily_basin(
    arrays: DailyBasinArrays,
    contract: DailyKNetContract,
    device: torch.device,
) -> PreparedDailyBasin:
    """Build a routed HBV-light trajectory from a causal default state.

    Validation observations may update the filter only at or before each
    forecast origin; later discharge is used only as a target.  All scales,
    physical storage limits, and the second-order autoregression are fitted on
    the post-spin-up training interval.
    """

    device = torch.device(device)
    _validate_archive_arrays(
        np.asarray(arrays.dates_ns),
        np.asarray(arrays.forcing),
        np.asarray(arrays.observations),
        np.asarray(arrays.parameters),
        contract,
    )
    parameters = torch.as_tensor(arrays.parameters, dtype=torch.float32, device=device)
    forcing = torch.as_tensor(arrays.forcing, dtype=torch.float32, device=device)
    observations = torch.as_tensor(arrays.observations, dtype=torch.float32, device=device)
    dates_ns = np.asarray(arrays.dates_ns).copy()
    if parameters.shape != (1, EXPECTED_PARAMETERS):
        raise ValueError(f"parameters must have shape (1, {EXPECTED_PARAMETERS})")
    if forcing.shape != (EXPECTED_DAYS, EXPECTED_FORCING_CHANNELS):
        raise ValueError(
            f"forcing must have shape ({EXPECTED_DAYS}, {EXPECTED_FORCING_CHANNELS})"
        )
    if observations.shape != (EXPECTED_DAYS,):
        raise ValueError(f"observations must have shape ({EXPECTED_DAYS},)")

    training_start = int(contract.spinup_days)
    validation_start = int(contract.validation_start_index)
    if not (0 < training_start < validation_start < EXPECTED_DAYS):
        raise ValueError("daily training and validation indices are inconsistent")
    expected_columns = (
        "precipitation_mm_per_day",
        "mean_temperature_degrees_celsius",
        "oudin_potential_evapotranspiration_mm_per_day",
    )
    forcing_columns = tuple(contract.forcing_columns)
    if forcing_columns != expected_columns:
        raise ValueError("daily forcing columns must be precipitation, temperature, and PET")

    routing_length = max(1, int(math.ceil(float(parameters[0, -1].item()))))
    lag_weights = recession_half_weights(parameters[:, -1:], routing_length)
    system = HBVLiteSystemModel(
        parameters,
        x0=None,
        emission="routed",
        lag_weights=lag_weights,
        device=device,
        dtype=torch.float32,
    )
    initial_state = system.get_default_initial_state()
    open_loop_discharge, open_loop_states = _simulate_open_loop(
        system, initial_state, forcing
    )

    training_slice = slice(training_start, validation_start)
    training_observations = observations[training_slice]
    finite_training_observations = training_observations[
        torch.isfinite(training_observations)
    ]
    if finite_training_observations.numel() < 2:
        raise ValueError("at least two finite training observations are required")
    centered_training_observations = (
        finite_training_observations - finite_training_observations.mean()
    )
    training_observation_variance = float(
        torch.clamp(
            centered_training_observations.square().mean(), min=SCALE_FLOOR
        ).detach().cpu()
    )
    observation_diff_scale = (
        SCALE_MARGIN
        * _finite_max_abs_difference(training_observations, floor=SCALE_FLOOR)
    ).reshape(1, 1)
    training_storages = open_loop_states[training_slice, 0, :STORAGE_DIMENSION]
    storage_diff_scale = (
        SCALE_MARGIN
        * _finite_max_abs_difference(training_storages, floor=SCALE_FLOOR)
    ).reshape(1, STORAGE_DIMENSION)

    storage_upper = torch.clamp(
        contract.state_upper_bound_multiplier
        * training_storages.max(dim=0).values,
        min=STATE_BOUND_FLOOR,
    )
    field_capacity = parameters[:, PARAM_NAMES.index("parFC") : PARAM_NAMES.index("parFC") + 1]
    storage_upper[2] = torch.minimum(storage_upper[2], field_capacity.reshape(()))
    routed_upper = torch.full(
        (system.m - STORAGE_DIMENSION,),
        torch.inf,
        dtype=torch.float32,
        device=device,
    )
    state_upper_bound = torch.cat([storage_upper, routed_upper]).reshape(1, system.m)

    ar2 = fit_training_ar2(
        open_loop_discharge.detach().cpu().numpy(),
        observations.detach().cpu().numpy(),
        training_slice,
    )
    ar2_coefficients = torch.as_tensor(ar2, dtype=torch.float32, device=device)

    return PreparedDailyBasin(
        basin_id=arrays.basin_id,
        training_start_index=training_start,
        validation_start_index=validation_start,
        system=system,
        initial_state=initial_state,
        forcing=forcing,
        observations=observations,
        valid_observations=torch.isfinite(observations),
        open_loop_discharge=open_loop_discharge,
        open_loop_states=open_loop_states,
        observation_diff_scale=observation_diff_scale,
        storage_diff_scale=storage_diff_scale,
        state_upper_bound=state_upper_bound,
        field_capacity=field_capacity,
        parameters=parameters,
        dates_ns=dates_ns,
        ar2_coefficients=ar2_coefficients,
        training_observation_variance=training_observation_variance,
        normalized_feature_guard=contract.normalized_feature_guard,
    )


__all__ = [
    "DailyBasinArrays",
    "PreparedDailyBasin",
    "fit_training_ar2",
    "load_daily_selection_archive",
    "prepare_daily_basin",
    "sha256_file",
]
