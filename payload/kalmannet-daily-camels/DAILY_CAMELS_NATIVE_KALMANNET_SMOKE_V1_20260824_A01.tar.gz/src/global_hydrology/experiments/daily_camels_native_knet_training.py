"""Daily, storage-only native KalmanNet training for frozen CAMELS development data.

The physical HBV-light state includes the basin-specific routed queue.  The
original KalmanNet core is deliberately built at ``m=5`` and can therefore
change only the five storages.  This module has no raw-data or formal-evaluation
loader and never imports the historical shared-training commands.
"""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import copy
import math
import random
import time
from typing import Any, Callable, Mapping, Sequence

import numpy as np
import torch


N_STORAGE = 5


@dataclass(frozen=True)
class ForecastRecord:
    """One causal forecast issued after assimilating the origin observation."""

    prediction: torch.Tensor
    forcing_indices: tuple[int, ...]
    target_index: int


@dataclass
class FilterTrace:
    """Differentiable filter trajectory and update diagnostics."""

    start: int
    end: int
    prior_states: torch.Tensor
    posterior_states: torch.Tensor
    gains: torch.Tensor
    requested_storage_corrections: torch.Tensor
    realized_storage_corrections: torch.Tensor
    routed_queue_corrections: torch.Tensor
    innovations: torch.Tensor
    valid_updates: torch.Tensor
    projected_storage_fraction: torch.Tensor


@dataclass
class TrainingResult:
    """In-memory result needed by the atomic persistence layer."""

    network: torch.nn.Module
    optimizer: torch.optim.Optimizer
    scheduler: Any | None
    current_model_state: dict[str, torch.Tensor]
    current_optimizer_state: dict[str, Any]
    completed_epoch: int
    history: list[dict[str, Any]]
    epoch_zero: dict[str, Any]
    best_epoch: int
    best_selection_score: float
    best_model_state: dict[str, torch.Tensor]
    sampler_generator_state: torch.Tensor
    cumulative_optimizer_steps: int
    sampled_forecast_events: int
    nonzero_gradient_parameter_names: tuple[str, ...]


def _as_device_tensor(value: Any, reference: torch.Tensor) -> torch.Tensor:
    return torch.as_tensor(value, device=reference.device, dtype=reference.dtype)


def _initial_state_before(basin: Any, start: int) -> torch.Tensor:
    if start < 0 or start > len(basin.forcing):
        raise ValueError("segment start is outside the daily record")
    if start == 0:
        return basin.initial_state.clone()
    return basin.open_loop_states[start - 1].clone()


def _project_storage_update(basin: Any, prior: torch.Tensor, proposed: torch.Tensor) -> torch.Tensor:
    """Project storages while copying the routed queue exactly from the prior."""

    if prior.ndim != 2 or prior.shape[0] != 1 or prior.shape[1] < N_STORAGE:
        raise ValueError("routed HBV state must have shape [1, m>=5]")
    if proposed.shape != prior[:, :N_STORAGE].shape:
        raise ValueError("proposed storage shape differs from the five-storage state")
    frozen_upper = _as_device_tensor(basin.state_upper_bound, prior).reshape(1, -1)[
        :, :N_STORAGE
    ]
    # The training-only upper bound limits a learned positive correction; it
    # must never alter an already-physical HBV prior when the learned gain is
    # zero.  This preserves the epoch-zero/open-loop identity even if a
    # validation snow or groundwater prior exceeds the training maximum.
    effective_upper = torch.maximum(frozen_upper, prior[:, :N_STORAGE])
    storage = torch.maximum(
        torch.minimum(proposed, effective_upper), torch.zeros_like(proposed)
    )
    field_capacity = _as_device_tensor(basin.field_capacity, prior).reshape(1, 1)
    storage = torch.cat(
        [storage[:, :2], torch.minimum(storage[:, 2:3], field_capacity), storage[:, 3:]],
        dim=1,
    )
    return torch.cat([storage, prior[:, N_STORAGE:]], dim=1)


def _finite_previous_observation(basin: Any, start: int, initial_state: torch.Tensor) -> torch.Tensor:
    observations = basin.observations
    for index in range(start - 1, -1, -1):
        value = observations[index]
        if bool(torch.isfinite(value)):
            return value.reshape(1, 1)
    return basin.system.h(initial_state).reshape(1, 1)


def run_storage_filter(net: Any, basin: Any, start: int, end: int) -> FilterTrace:
    """Filter ``[start, end)`` with a five-storage gain and a physical routed queue."""

    if not (0 <= start < end <= len(basin.forcing)):
        raise ValueError("invalid daily filter interval")
    if int(getattr(net, "m", N_STORAGE)) != N_STORAGE or int(getattr(net, "n", 1)) != 1:
        raise ValueError("native daily KalmanNet must have m=5 and n=1")
    initial = _initial_state_before(basin, start).to(basin.forcing)
    net.init_hidden(1)
    x_post = initial
    x_post_previous = initial
    x_prior_previous = initial
    y_previous = _finite_previous_observation(basin, start, initial).to(initial)
    observation_scale = _as_device_tensor(basin.observation_diff_scale, initial).reshape(1, 1)
    storage_scale = _as_device_tensor(basin.storage_diff_scale, initial).reshape(1, N_STORAGE)
    guard = float(getattr(basin, "normalized_feature_guard", 10.0))

    priors: list[torch.Tensor] = []
    posteriors: list[torch.Tensor] = []
    gains: list[torch.Tensor] = []
    requested: list[torch.Tensor] = []
    realized: list[torch.Tensor] = []
    queue_changes: list[torch.Tensor] = []
    innovations: list[torch.Tensor] = []
    valid_updates: list[bool] = []
    projected_fractions: list[torch.Tensor] = []

    for day in range(start, end):
        prior = basin.system.f(x_post, basin.forcing[day : day + 1])
        if not bool(torch.isfinite(prior).all()):
            raise FloatingPointError(f"nonfinite HBV prior on daily index {day}")
        y_prior = basin.system.h(prior).reshape(1, 1)
        posterior = prior
        gain = torch.zeros(1, N_STORAGE, 1, device=prior.device, dtype=prior.dtype)
        requested_correction = torch.zeros(1, N_STORAGE, device=prior.device, dtype=prior.dtype)
        innovation = torch.full((1, 1), torch.nan, device=prior.device, dtype=prior.dtype)
        projected_fraction = torch.zeros((), device=prior.device, dtype=prior.dtype)
        valid = bool(torch.isfinite(basin.observations[day]))
        if valid:
            observation = basin.observations[day].reshape(1, 1).to(prior)
            innovation = observation - y_prior
            observation_difference = (observation - y_previous) / observation_scale
            normalized_innovation = innovation / observation_scale
            forward_evolution = (
                x_post[:, :N_STORAGE] - x_post_previous[:, :N_STORAGE]
            ) / storage_scale
            forward_update = (
                x_post[:, :N_STORAGE] - x_prior_previous[:, :N_STORAGE]
            ) / storage_scale
            gain = net.compute_gain_native(
                observation_difference,
                normalized_innovation,
                forward_evolution,
                forward_update,
                guard=guard,
            )
            if gain.shape != (1, N_STORAGE, 1) or not bool(torch.isfinite(gain).all()):
                raise FloatingPointError("native KalmanNet returned an invalid five-storage gain")
            requested_correction = gain.squeeze(-1) * normalized_innovation * storage_scale
            posterior = _project_storage_update(
                basin, prior, prior[:, :N_STORAGE] + requested_correction
            )
            realized_correction = posterior[:, :N_STORAGE] - prior[:, :N_STORAGE]
            projected_fraction = (
                (realized_correction - requested_correction).abs() > 1e-10
            ).to(prior.dtype).mean()
            x_post_previous = x_post
            x_prior_previous = prior
            x_post = posterior
            y_previous = observation
        else:
            realized_correction = torch.zeros_like(requested_correction)
            x_post_previous = x_post
            x_prior_previous = prior
            x_post = prior
        queue_correction = posterior[:, N_STORAGE:] - prior[:, N_STORAGE:]
        if queue_correction.numel() and bool(torch.count_nonzero(queue_correction)):
            raise RuntimeError("routed queue correction must remain zero")
        priors.append(prior)
        posteriors.append(posterior)
        gains.append(gain)
        requested.append(requested_correction)
        realized.append(realized_correction)
        queue_changes.append(queue_correction)
        innovations.append(innovation)
        valid_updates.append(valid)
        projected_fractions.append(projected_fraction)

    queue_width = basin.initial_state.shape[-1] - N_STORAGE
    routed = (
        torch.stack(queue_changes)
        if queue_width
        else torch.empty(end - start, 1, 0, device=initial.device, dtype=initial.dtype)
    )
    return FilterTrace(
        start=start,
        end=end,
        prior_states=torch.stack(priors),
        posterior_states=torch.stack(posteriors),
        gains=torch.stack(gains),
        requested_storage_corrections=torch.stack(requested),
        realized_storage_corrections=torch.stack(realized),
        routed_queue_corrections=routed,
        innovations=torch.stack(innovations),
        valid_updates=torch.tensor(valid_updates, device=initial.device, dtype=torch.bool),
        projected_storage_fraction=torch.stack(projected_fractions),
    )


def forecast_from_analysis(
    basin: Any,
    analysis_state: torch.Tensor,
    origin: int,
    leads: tuple[int, ...] = (1, 2, 3),
) -> dict[int, ForecastRecord]:
    """Use only target-day meteorological forcing after the analysis origin."""

    if tuple(sorted(set(leads))) != tuple(leads) or not leads or min(leads) < 1:
        raise ValueError("forecast leads must be unique, increasing positive integers")
    if origin < 0 or origin + max(leads) >= len(basin.forcing):
        raise ValueError("forecast origin does not have all requested daily leads")
    state = analysis_state
    output: dict[int, ForecastRecord] = {}
    forcing_indices: list[int] = []
    for step in range(1, max(leads) + 1):
        target = origin + step
        forcing_indices.append(target)
        state = basin.system.f(state, basin.forcing[target : target + 1])
        if step in leads:
            output[step] = ForecastRecord(
                prediction=basin.system.h(state).reshape(()),
                forcing_indices=tuple(forcing_indices),
                target_index=target,
            )
    return output


def nash_sutcliffe_efficiency(targets: Sequence[float], predictions: Sequence[float]) -> float:
    targets_array = np.asarray(targets, dtype=float)
    predictions_array = np.asarray(predictions, dtype=float)
    common = np.isfinite(targets_array) & np.isfinite(predictions_array)
    if int(common.sum()) < 2:
        return float("nan")
    selected = targets_array[common]
    denominator = float(np.mean((selected - float(np.mean(selected))) ** 2))
    if denominator <= 0.0 or not math.isfinite(denominator):
        return float("nan")
    return 1.0 - float(np.mean((predictions_array[common] - selected) ** 2)) / denominator


def selection_score(knet_nse: Mapping[int, float], ar2_nse: Mapping[int, float]) -> float:
    if set(knet_nse) != {1, 2, 3} or set(ar2_nse) != {1, 2, 3}:
        raise ValueError("selection metrics must contain daily leads 1, 2, and 3")
    gains = [float(knet_nse[lead]) - float(ar2_nse[lead]) for lead in (1, 2, 3)]
    if not all(math.isfinite(value) for value in gains):
        return float("-inf")
    return float(np.mean(gains))


def _ar2_prediction(basin: Any, origin: int, lead: int) -> float:
    coefficient_source = basin.ar2_coefficients
    if torch.is_tensor(coefficient_source):
        coefficient_source = coefficient_source.detach().cpu().numpy()
    coefficients = np.asarray(coefficient_source, dtype=float).reshape(2)
    open_loop = np.asarray(
        basin.open_loop_discharge.detach().cpu().numpy(), dtype=float
    ).reshape(-1)
    observations = np.asarray(basin.observations.detach().cpu().numpy(), dtype=float).reshape(-1)
    first = observations[origin] - open_loop[origin]
    second = observations[origin - 1] - open_loop[origin - 1]
    if not math.isfinite(first):
        first = 0.0
    if not math.isfinite(second):
        second = first
    for _ in range(lead):
        predicted = float(coefficients[0] * first + coefficients[1] * second)
        second, first = first, predicted
    return float(open_loop[origin + lead] + first)


def multilead_segment_loss(
    basin: Any,
    trace: FilterTrace,
    *,
    filter_warmup_days: int,
    leads: tuple[int, ...] = (1, 2, 3),
) -> tuple[torch.Tensor, int]:
    """Return training-only normalized MSE and the number of forecast targets."""

    if filter_warmup_days < 0:
        raise ValueError("filter warm-up must be nonnegative")
    variance = float(getattr(basin, "training_observation_variance", 1.0))
    if not math.isfinite(variance) or variance <= 0.0:
        raise ValueError("training observation variance must be positive")
    terms: list[torch.Tensor] = []
    for offset, analysis in enumerate(trace.posterior_states):
        origin = trace.start + offset
        if origin < trace.start + filter_warmup_days or origin + max(leads) >= trace.end:
            continue
        forecasts = forecast_from_analysis(basin, analysis, origin, leads)
        for lead in leads:
            target = basin.observations[forecasts[lead].target_index]
            if bool(torch.isfinite(target)):
                terms.append((forecasts[lead].prediction - target).square() / variance)
    if not terms:
        raise ValueError("training segment has no finite forecast targets")
    return torch.stack(terms).mean(), len(terms)


def validation_metrics(
    net: Any,
    basins: Sequence[Any],
    *,
    validation_window_days: int,
    filter_warmup_days: int,
) -> dict[str, Any]:
    """Score each basin first, then aggregate basins with equal weight."""

    routed_max = 0.0
    projected: list[float] = []
    per_basin: dict[str, dict[str, Any]] = {}
    for basin_index, basin in enumerate(basins):
        basin_id = str(getattr(basin, "basin_id", basin_index))
        if basin_id in per_basin:
            raise ValueError(f"duplicate validation basin identity: {basin_id}")
        targets: dict[int, list[float]] = {lead: [] for lead in (1, 2, 3)}
        knet_predictions: dict[int, list[float]] = {
            lead: [] for lead in (1, 2, 3)
        }
        ar2_predictions: dict[int, list[float]] = {
            lead: [] for lead in (1, 2, 3)
        }
        open_loop_predictions: dict[int, list[float]] = {
            lead: [] for lead in (1, 2, 3)
        }
        persistence_predictions: dict[int, list[float]] = {
            lead: [] for lead in (1, 2, 3)
        }
        basin_normalized_errors: list[float] = []
        start = int(basin.validation_start_index)
        end = min(len(basin.forcing), start + int(validation_window_days))
        if end - start <= filter_warmup_days + 3:
            raise ValueError("fixed validation window is too short")
        trace = run_storage_filter(net, basin, start, end)
        gain_abs_by_storage = (
            trace.gains.squeeze(-1).abs().mean(dim=(0, 1)).detach().cpu().tolist()
        )
        requested_abs_by_storage = (
            trace.requested_storage_corrections.abs()
            .mean(dim=(0, 1))
            .detach()
            .cpu()
            .tolist()
        )
        realized_abs_by_storage = (
            trace.realized_storage_corrections.abs()
            .mean(dim=(0, 1))
            .detach()
            .cpu()
            .tolist()
        )
        projected_by_storage = (
            (
                trace.realized_storage_corrections
                - trace.requested_storage_corrections
            )
            .abs()
            .gt(1e-10)
            .to(trace.realized_storage_corrections.dtype)
            .mean(dim=(0, 1))
            .detach()
            .cpu()
            .tolist()
        )
        basin_routed_max = 0.0
        if trace.routed_queue_corrections.numel():
            basin_routed_max = float(
                trace.routed_queue_corrections.abs().max().detach().cpu()
            )
            routed_max = max(routed_max, basin_routed_max)
        basin_projected = trace.projected_storage_fraction.detach().cpu().tolist()
        projected.extend(basin_projected)
        for offset, analysis in enumerate(trace.posterior_states):
            origin = start + offset
            if origin < start + filter_warmup_days or origin + 3 >= end or origin < 1:
                continue
            forecasts = forecast_from_analysis(basin, analysis, origin)
            for lead, record in forecasts.items():
                target = float(basin.observations[record.target_index].detach().cpu())
                if math.isfinite(target):
                    prediction = float(record.prediction.detach().cpu())
                    targets[lead].append(target)
                    knet_predictions[lead].append(prediction)
                    ar2_predictions[lead].append(
                        _ar2_prediction(basin, origin, lead)
                    )
                    open_loop_predictions[lead].append(
                        float(basin.open_loop_discharge[record.target_index].detach().cpu())
                    )
                    origin_observation = float(
                        basin.observations[origin].detach().cpu()
                    )
                    persistence_predictions[lead].append(origin_observation)
                    variance = float(
                        getattr(basin, "training_observation_variance", 1.0)
                    )
                    if not math.isfinite(variance) or variance <= 0.0:
                        raise ValueError(
                            "training observation variance must be finite and positive"
                        )
                    basin_normalized_errors.append(
                        (prediction - target) ** 2 / variance
                    )

        basin_knet = {
            lead: nash_sutcliffe_efficiency(
                targets[lead], knet_predictions[lead]
            )
            for lead in (1, 2, 3)
        }
        basin_ar2 = {
            lead: nash_sutcliffe_efficiency(targets[lead], ar2_predictions[lead])
            for lead in (1, 2, 3)
        }
        basin_open_loop = {
            lead: nash_sutcliffe_efficiency(
                targets[lead], open_loop_predictions[lead]
            )
            for lead in (1, 2, 3)
        }
        basin_persistence = {
            lead: nash_sutcliffe_efficiency(
                targets[lead], persistence_predictions[lead]
            )
            for lead in (1, 2, 3)
        }
        basin_gain_over_ar2 = {
            lead: basin_knet[lead] - basin_ar2[lead] for lead in (1, 2, 3)
        }
        per_basin[basin_id] = {
            "knet_nse": basin_knet,
            "ar2_nse": basin_ar2,
            "open_loop_nse": basin_open_loop,
            "persistence_nse": basin_persistence,
            "gain_over_ar2": basin_gain_over_ar2,
            "selection_score": selection_score(basin_knet, basin_ar2),
            "worst_lead_gain_over_ar2": min(basin_gain_over_ar2.values()),
            "validation_loss": (
                float(np.mean(basin_normalized_errors))
                if basin_normalized_errors
                else float("nan")
            ),
            "target_count_by_lead": {
                lead: len(targets[lead]) for lead in (1, 2, 3)
            },
            "routed_queue_correction_abs_max": basin_routed_max,
            "projected_storage_fraction_mean": (
                float(np.mean(basin_projected)) if basin_projected else 0.0
            ),
            "gain_abs_mean_by_storage": gain_abs_by_storage,
            "requested_storage_correction_abs_mean_by_storage": (
                requested_abs_by_storage
            ),
            "realized_storage_correction_abs_mean_by_storage": (
                realized_abs_by_storage
            ),
            "projected_fraction_by_storage": projected_by_storage,
        }

    knet: dict[int, float] = {}
    ar2: dict[int, float] = {}
    gain_over_ar2: dict[int, float] = {}
    open_loop: dict[int, float] = {}
    persistence: dict[int, float] = {}
    for lead in (1, 2, 3):
        eligible_pairs = [
            (float(metrics["knet_nse"][lead]), float(metrics["ar2_nse"][lead]))
            for metrics in per_basin.values()
            if math.isfinite(float(metrics["knet_nse"][lead]))
            and math.isfinite(float(metrics["ar2_nse"][lead]))
        ]
        if not eligible_pairs:
            knet[lead] = ar2[lead] = gain_over_ar2[lead] = float("nan")
        else:
            knet[lead] = float(np.mean([pair[0] for pair in eligible_pairs]))
            ar2[lead] = float(np.mean([pair[1] for pair in eligible_pairs]))
            gain_over_ar2[lead] = float(
                np.mean([pair[0] - pair[1] for pair in eligible_pairs])
            )
        for destination, key in (
            (open_loop, "open_loop_nse"),
            (persistence, "persistence_nse"),
        ):
            values = [
                float(metrics[key][lead])
                for metrics in per_basin.values()
                if math.isfinite(float(metrics[key][lead]))
            ]
            destination[lead] = float(np.mean(values)) if values else float("nan")

    basin_losses = [
        float(metrics["validation_loss"])
        for metrics in per_basin.values()
        if math.isfinite(float(metrics["validation_loss"]))
    ]
    storage_diagnostics = {
        key: np.mean(
            np.asarray([metrics[key] for metrics in per_basin.values()], dtype=float),
            axis=0,
        ).tolist()
        for key in (
            "gain_abs_mean_by_storage",
            "requested_storage_correction_abs_mean_by_storage",
            "realized_storage_correction_abs_mean_by_storage",
            "projected_fraction_by_storage",
        )
    }
    return {
        "knet_nse": knet,
        "ar2_nse": ar2,
        "open_loop_nse": open_loop,
        "persistence_nse": persistence,
        "gain_over_ar2": gain_over_ar2,
        "selection_score": (
            float(np.mean(list(gain_over_ar2.values())))
            if all(math.isfinite(value) for value in gain_over_ar2.values())
            else float("-inf")
        ),
        "worst_lead_gain_over_ar2": min(gain_over_ar2.values()),
        "validation_loss": (
            float(np.mean(basin_losses))
            if basin_losses
            else float("nan")
        ),
        "target_count_by_lead": {
            lead: sum(
                int(metrics["target_count_by_lead"][lead])
                for metrics in per_basin.values()
            )
            for lead in (1, 2, 3)
        },
        "routed_queue_correction_abs_max": routed_max,
        "projected_storage_fraction_mean": float(np.mean(projected)) if projected else 0.0,
        "basin_aggregation": "equal_weight_mean_of_per_basin_metrics",
        "per_basin": per_basin,
        **storage_diagnostics,
    }


def parameter_sha256(module: torch.nn.Module) -> str:
    digest = sha256()
    for name, tensor in sorted(module.state_dict().items()):
        array = tensor.detach().cpu().contiguous().numpy()
        digest.update(name.encode("utf-8"))
        digest.update(str(array.dtype).encode("ascii"))
        digest.update(np.asarray(array.shape, dtype=np.int64).tobytes())
        digest.update(array.tobytes())
    return digest.hexdigest()


def _memory_snapshot(device: torch.device) -> tuple[int | None, int]:
    host = None
    try:
        import psutil

        host = int(psutil.Process().memory_info().rss)
    except (ImportError, OSError):
        pass
    gpu = int(torch.cuda.max_memory_allocated(device)) if device.type == "cuda" else 0
    return host, gpu


def _resume_attribute(state: Any, name: str) -> Any:
    if isinstance(state, Mapping):
        if name not in state:
            raise ValueError(f"resume state is missing {name}")
        return state[name]
    if not hasattr(state, name):
        raise ValueError(f"resume state is missing {name}")
    return getattr(state, name)


def _restore_random_states(state: Any, device: torch.device) -> None:
    random.setstate(_resume_attribute(state, "python_random_state"))
    numpy_state = _resume_attribute(state, "numpy_bit_generator_state")
    if not isinstance(numpy_state, tuple):
        raise TypeError("resume NumPy random state must come from numpy.random.get_state()")
    np.random.set_state(numpy_state)
    cpu_state = _resume_attribute(state, "torch_cpu_random_state")
    torch.set_rng_state(torch.as_tensor(cpu_state, device="cpu", dtype=torch.uint8))
    cuda_states = list(_resume_attribute(state, "torch_cuda_random_states"))
    if device.type == "cuda":
        if not cuda_states:
            raise ValueError("CUDA resume requires saved CUDA random states")
        torch.cuda.set_rng_state_all(
            [torch.as_tensor(value, device="cpu", dtype=torch.uint8) for value in cuda_states]
        )
    elif cuda_states:
        raise ValueError("CPU resume may not contain CUDA random states")


def _training_snapshot(
    *,
    network: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    scheduler: Any | None,
    completed_epoch: int,
    history: list[dict[str, Any]],
    epoch_zero: dict[str, Any],
    best_epoch: int,
    best_score: float,
    best_state: dict[str, torch.Tensor],
    sampler: torch.Generator,
    cumulative_steps: int,
    event_count: int,
    nonzero_names: set[str],
) -> TrainingResult:
    return TrainingResult(
        network=network,
        optimizer=optimizer,
        scheduler=scheduler,
        current_model_state=copy.deepcopy(network.state_dict()),
        current_optimizer_state=copy.deepcopy(optimizer.state_dict()),
        completed_epoch=int(completed_epoch),
        history=list(history),
        epoch_zero=dict(epoch_zero),
        best_epoch=int(best_epoch),
        best_selection_score=float(best_score),
        best_model_state=copy.deepcopy(best_state),
        sampler_generator_state=sampler.get_state().clone(),
        cumulative_optimizer_steps=int(cumulative_steps),
        sampled_forecast_events=int(event_count),
        nonzero_gradient_parameter_names=tuple(sorted(nonzero_names)),
    )


def train_daily_native_knet(
    basins: Sequence[Any],
    settings: Mapping[str, Any],
    *,
    device: torch.device,
    resume_state: Any | None = None,
    checkpoint_callback: Callable[[TrainingResult], None] | None = None,
    network_factory: Callable[..., torch.nn.Module] | None = None,
) -> TrainingResult:
    """Train one shared five-storage native KalmanNet under the frozen smoke budget."""

    if not basins:
        raise ValueError("daily training basins are empty")
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")
    seed = int(settings["seed"])
    if resume_state is None:
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        if device.type == "cuda":
            torch.cuda.manual_seed_all(seed)
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    if network_factory is None:
        from global_hydrology.models.knet_native_hbvlite import build_storage_net

        network_factory = build_storage_net

    net = network_factory(
        device=device,
        dtype=torch.float32,
        n_storage=N_STORAGE,
        zero_gain_init=bool(settings["zero_gain_initialization"]),
        hidden=int(settings["hidden_dimension"]),
        in_mult=int(settings["input_multiplier"]),
        out_mult=int(settings["output_multiplier"]),
    ).to(device)
    optimizer = torch.optim.Adam(
        net.parameters(),
        lr=float(settings["learning_rate"]),
        weight_decay=float(settings["weight_decay"]),
    )
    scheduler = None
    sampler = torch.Generator(device="cpu").manual_seed(seed + 1)
    validation_days = int(settings["validation_window_days"])
    filter_warmup = int(settings["filter_warmup_days"])
    segment_days = int(settings["segment_days"])
    start_clock = time.perf_counter()

    if resume_state is None:
        net.eval()
        with torch.no_grad():
            initial_metrics = validation_metrics(
                net,
                basins,
                validation_window_days=validation_days,
                filter_warmup_days=filter_warmup,
            )
        host_peak, gpu_peak = _memory_snapshot(device)
        epoch_zero = {
            "epoch": 0,
            "optimizer_steps": 0,
            "sampled_forecast_events": 0,
            "training_loss": None,
            **initial_metrics,
            "parameter_sha256": parameter_sha256(net),
            "finite_gradients": None,
            "nonzero_gradient_parameter_tensor_count": 0,
            "nonzero_gradient_parameter_names": [],
            "training_units": [],
            "elapsed_seconds": time.perf_counter() - start_clock,
            "host_resident_memory_bytes": host_peak,
            "gpu_peak_memory_bytes": gpu_peak,
        }
        history: list[dict[str, Any]] = [epoch_zero]
        best_epoch = 0
        best_score = float(epoch_zero["selection_score"])
        best_state = copy.deepcopy(net.state_dict())
        cumulative_steps = 0
        event_count = 0
        nonzero_names: set[str] = set()
        completed_epoch = 0
        if checkpoint_callback is not None:
            checkpoint_callback(
                _training_snapshot(
                    network=net,
                    optimizer=optimizer,
                    scheduler=scheduler,
                    completed_epoch=completed_epoch,
                    history=history,
                    epoch_zero=epoch_zero,
                    best_epoch=best_epoch,
                    best_score=best_score,
                    best_state=best_state,
                    sampler=sampler,
                    cumulative_steps=cumulative_steps,
                    event_count=event_count,
                    nonzero_names=nonzero_names,
                )
            )
    else:
        completed_epoch = int(_resume_attribute(resume_state, "completed_epoch"))
        history = [dict(row) for row in _resume_attribute(resume_state, "history")]
        epoch_zero = dict(_resume_attribute(resume_state, "epoch_zero_record"))
        if not history or int(history[0].get("epoch", -1)) != 0:
            raise ValueError("resume history must begin with epoch zero")
        if int(history[-1].get("epoch", -1)) != completed_epoch:
            raise ValueError("resume history does not end at completed_epoch")
        net.load_state_dict(_resume_attribute(resume_state, "model_state"), strict=True)
        optimizer.load_state_dict(_resume_attribute(resume_state, "optimizer_state"))
        if _resume_attribute(resume_state, "scheduler_state") is not None:
            raise ValueError("the frozen daily smoke has no scheduler state")
        sampler.set_state(
            torch.as_tensor(
                _resume_attribute(resume_state, "sampler_generator_state"),
                device="cpu",
                dtype=torch.uint8,
            )
        )
        best_payload = _resume_attribute(
            resume_state, "best_post_zero_checkpoint"
        )
        if not isinstance(best_payload, Mapping):
            raise TypeError("resume best checkpoint metadata must be a mapping")
        required_best = {"epoch", "selection_score", "model_state"}
        if not required_best.issubset(best_payload):
            raise ValueError("resume best checkpoint metadata is incomplete")
        best_epoch = int(best_payload["epoch"])
        best_score = float(best_payload["selection_score"])
        best_state = copy.deepcopy(best_payload["model_state"])
        cumulative_steps = int(
            _resume_attribute(resume_state, "cumulative_optimizer_steps")
        )
        event_count = int(_resume_attribute(resume_state, "sampled_forecast_events"))
        nonzero_names = set(
            str(name)
            for name in _resume_attribute(
                resume_state, "nonzero_gradient_parameter_names"
            )
        )
        if int(history[-1].get("optimizer_steps", -1)) != cumulative_steps:
            raise ValueError("resume optimizer step count differs from history")
        if int(history[-1].get("sampled_forecast_events", -1)) != event_count:
            raise ValueError("resume forecast event count differs from history")
        history_nonzero_names = {
            str(name)
            for row in history
            for name in row.get("nonzero_gradient_parameter_names", [])
        }
        if history_nonzero_names != nonzero_names:
            raise ValueError("resume nonzero gradient names differ from history")
        _restore_random_states(resume_state, device)

    target_epochs = int(settings["epochs"])
    if target_epochs < completed_epoch:
        raise ValueError("configured epoch budget is below the resumed epoch")

    for epoch in range(completed_epoch + 1, target_epochs + 1):
        net.train()
        losses: list[float] = []
        finite_gradients = True
        training_units: list[dict[str, Any]] = []
        for step_in_epoch in range(int(settings["steps_per_epoch"])):
            basin_index = int(torch.randint(len(basins), (1,), generator=sampler).item())
            basin = basins[basin_index]
            lower = int(basin.training_start_index)
            upper = int(basin.validation_start_index) - segment_days
            if upper < lower:
                raise ValueError("daily training interval cannot fit one segment")
            start = int(torch.randint(lower, upper + 1, (1,), generator=sampler).item())
            trace = run_storage_filter(net, basin, start, start + segment_days)
            loss, events = multilead_segment_loss(
                basin, trace, filter_warmup_days=filter_warmup
            )
            if not bool(torch.isfinite(loss)):
                raise FloatingPointError("daily KalmanNet training loss is nonfinite")
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            for name, parameter in net.named_parameters():
                if parameter.grad is None:
                    continue
                if not bool(torch.isfinite(parameter.grad).all()):
                    finite_gradients = False
                elif bool(torch.count_nonzero(parameter.grad)):
                    nonzero_names.add(name)
            if not finite_gradients:
                raise FloatingPointError("daily KalmanNet gradient is nonfinite")
            gradient_norm = torch.nn.utils.clip_grad_norm_(
                net.parameters(), float(settings.get("gradient_maximum_norm", 10.0))
            )
            if not bool(torch.isfinite(gradient_norm)):
                raise FloatingPointError("daily KalmanNet gradient norm is nonfinite")
            optimizer.step()
            cumulative_steps += 1
            event_count += events
            losses.append(float(loss.detach().cpu()))
            training_units.append(
                {
                    "step_in_epoch": step_in_epoch,
                    "basin_index": basin_index,
                    "basin_id": str(getattr(basin, "basin_id", basin_index)),
                    "start_index": start,
                    "end_index_exclusive": start + segment_days,
                    "forecast_target_count": events,
                }
            )

        net.eval()
        with torch.no_grad():
            metrics = validation_metrics(
                net,
                basins,
                validation_window_days=validation_days,
                filter_warmup_days=filter_warmup,
            )
        score = float(metrics["selection_score"])
        if score > best_score:
            best_score = score
            best_epoch = epoch
            best_state = copy.deepcopy(net.state_dict())
        host_memory, gpu_memory = _memory_snapshot(device)
        record = {
            "epoch": epoch,
            "optimizer_steps": cumulative_steps,
            "sampled_forecast_events": event_count,
            "training_loss": float(np.mean(losses)),
            **metrics,
            "parameter_sha256": parameter_sha256(net),
            "finite_gradients": finite_gradients,
            "nonzero_gradient_parameter_tensor_count": len(nonzero_names),
            "nonzero_gradient_parameter_names": sorted(nonzero_names),
            "training_units": training_units,
            "elapsed_seconds": time.perf_counter() - start_clock,
            "host_resident_memory_bytes": host_memory,
            "gpu_peak_memory_bytes": gpu_memory,
        }
        history.append(record)
        if checkpoint_callback is not None:
            checkpoint_callback(
                _training_snapshot(
                    network=net,
                    optimizer=optimizer,
                    scheduler=scheduler,
                    completed_epoch=epoch,
                    history=history,
                    epoch_zero=epoch_zero,
                    best_epoch=best_epoch,
                    best_score=best_score,
                    best_state=best_state,
                    sampler=sampler,
                    cumulative_steps=cumulative_steps,
                    event_count=event_count,
                    nonzero_names=nonzero_names,
                )
            )

    return _training_snapshot(
        network=net,
        optimizer=optimizer,
        scheduler=scheduler,
        completed_epoch=target_epochs,
        history=history,
        epoch_zero=epoch_zero,
        best_epoch=best_epoch,
        best_score=best_score,
        best_state=best_state,
        sampler=sampler,
        cumulative_steps=cumulative_steps,
        event_count=event_count,
        nonzero_names=nonzero_names,
    )
