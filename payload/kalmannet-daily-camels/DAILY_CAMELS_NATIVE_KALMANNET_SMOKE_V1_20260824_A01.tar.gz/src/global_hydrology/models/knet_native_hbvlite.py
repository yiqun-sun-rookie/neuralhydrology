"""HBVLiteKalmanNet — USE the user's mature KalmanNet (knet/dl/nn_kalman_clamp_5.py) on the
HBV-lite routed system model, via SUBCLASS.

Rationale (2026-06-30, user's 3rd correction): "porting the guardrails into the migrated
rewrite" is NOT using the user's network. This subclass USES the mature network itself.
`knet/` is read-only (CLAUDE.md), so we inherit the class and override the single piece that
is WALRUS-specific. We get, unchanged, from the mature `KalmanNet`:
  - the three LSTMs (Q / Sigma / S paths), FC1-FC7, residual connections, init_hidden_KNet;
  - `estimate_gain` with the canonical 4 diffs + `apply_clamp_scale_to_diffs` (the NATIVE
    unconditional obs±100 / state±5000 input guard — i.e. G1 comes free, it is his code);
  - `KGain_step` (the full forward/backward gain computation).

We override ONLY:
  - `step_prior` — clamp the HBV-lite prior to >=0 (storages are non-negative; the mature
    WALRUS f kept states positive internally, HBV-lite needs the explicit clamp);
  - `knet_step` — replace the mature hardcoded 5-state WALRUS clamp (dv/dg/hq/hs/q, lines
    360-367) with HBV-lite routed clamp [0, state_ub] + optional storage-only correction
    (freeze the gain on the routing FIFO [5:]; the iter3 fix for the transient-buffer-cheat
    lead-1 spike);
and ADD:
  - `predict_step` — for NaN-observation days (the mature knet_step always assimilates).

The mature network is loaded via importlib from its absolute path so this module does not
depend on `knet` being an importable package.
"""
import importlib.util
from pathlib import Path

import torch
import torch.nn as nn

# --- load the user's mature network class from its file (knet/ is read-only) ---
_KN_ROOT = Path(__file__).resolve().parents[3]            # repo root .../kalmannet
_NN_PATH = _KN_ROOT / "knet" / "dl" / "nn_kalman_clamp_5.py"
_spec = importlib.util.spec_from_file_location("nn_kalman_clamp_5_native", _NN_PATH)
_mod = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_mod)
NativeKalmanNet = _mod.KalmanNet                          # the user's class


class _Args:
    """Duck-typed args namespace that the mature build_nn / init_kgain_net read."""
    def __init__(self, device, **kw):
        self.device = device
        self.activation_function = kw.get("activation_function", "relu")
        self.in_mult_KNet = kw.get("in_mult", 10)
        self.out_mult_KNet = kw.get("out_mult", 10)
        h = kw.get("hidden", 24)
        self.d_hidden_Q = h
        self.d_hidden_Sigma = h
        self.d_hidden_S = h
        self.num_layers_GRU_Q = 1
        self.num_layers_GRU_Sigma = 1
        self.num_layers_GRU_S = 1
        self.dropout_prob = kw.get("dropout_prob", 0.0)
        self.n_batch = kw.get("n_batch", 1)
        self.state_bounds = {}     # WALRUS bounds unused; HBV-lite clamp is in knet_step below


class _WidenedLinear(nn.Module):
    """Input-widened drop-in for the first Linear of FC5/FC6/FC7 (attr conditioning, iter17):
    forward(x) = base(x[..., :in0]) + ext(x[..., in0:]). `base` is the ORIGINAL Linear module,
    weights untouched (same tensor, same gemm as the unconditioned net); `ext` is a bias-free
    Linear over the appended embedding, ZERO-initialized -> its output is an exact 0 matrix and
    adding it is an IEEE no-op => bit-identical forward at init. Together they equal one Linear
    with in0+d_emb input columns (block-partitioned), so expressivity is the standard
    'concatenate static attributes to the features' conditioning."""

    def __init__(self, orig, d_emb):
        super().__init__()
        self.in0 = orig.in_features
        self.base = orig
        self.ext = nn.Linear(d_emb, orig.out_features, bias=False)
        with torch.no_grad():
            self.ext.weight.zero_()

    def forward(self, x):
        return self.base(x[..., :self.in0]) + self.ext(x[..., self.in0:])


class HBVLiteKalmanNet(NativeKalmanNet):
    """The user's mature KalmanNet, adapted to HBV-lite routed state by overriding only the
    state-update clamp. m = 5 storages (+ L routing-FIFO channels)."""

    N_STORAGE = 5

    def __init__(self, sys_model, device, freeze_buffer=True, state_ub=None,
                 zero_gain_init=False, **kw):
        super().__init__()
        self._args = _Args(device, **kw)
        # mature setup: builds the 3 LSTMs / FC1-7 / prior projectors, stores f,h,m,n
        self.build_nn(sys_model, self._args)
        self.freeze_buffer = freeze_buffer
        self.state_ub = state_ub                 # [m] per-basin anti-runaway upper bound
        if zero_gain_init:
            # OFF by default. Empirically (2026-06-30) near-zero gain-head init HURT the mature
            # network (02149000 +0.715 -> +0.122) and did NOT fix the 13235000 short-lead blowup
            # (-195 either way) -> that blowup is a converged-solution over-correction, not an
            # init-magnitude issue. Kept as a flag but disabled; do not enable without evidence.
            with torch.no_grad():
                self.FC2[-1].weight.mul_(0.01)
                self.FC2[-1].bias.zero_()

    # ------------------------------------------------------------------ helpers
    def set_state_ub(self, ub):
        self.state_ub = ub

    def init_hidden(self, batch_size):
        """Convenience: set batch + (re)seed the 3 LSTM hidden states from sys-model priors."""
        self.batch_size = batch_size
        self.init_hidden_KNet()

    def _clamp_state(self, x):
        x = x.clamp(min=0.0)                       # HBV-lite physicality: every channel >= 0
        return x if self.state_ub is None else torch.minimum(x, self.state_ub)

    # ----------------------------------------------------- overrides (HBV-lite)
    def step_prior(self, controls):
        # mature step_prior does NOT clamp; HBV-lite storages must stay >=0 (matches the
        # explicit clampx the working filter applies after every f).
        self.m1x_prior = self._clamp_state(self.f(self.m1x_posterior, controls))
        self.m1y = self.h(self.m1x_prior)

    def knet_step(self, y, controls):
        # EXACT mirror of mature knet_step (nn_kalman_clamp_5.py:344-380) except the final
        # state clamp, which the mature version hardcodes to the 5 WALRUS bounds.
        self.step_prior(controls)
        y = torch.unsqueeze(y, 2)
        self.estimate_gain(y)                      # native 4-diff + clamp guard + KGain_step
        dy = y - self.m1y.unsqueeze(-1)
        INOV = torch.bmm(self.KGain, dy).squeeze(-1)        # [B, m]
        if self.freeze_buffer and self.m > self.N_STORAGE:
            # storage-only correction: zero the gain on the directly-observed routing FIFO [5:]
            # (the iter3 fix). The buffer evolves deterministically via f from corrected storages.
            INOV = torch.cat(
                [INOV[:, :self.N_STORAGE], torch.zeros_like(INOV[:, self.N_STORAGE:])], dim=1)
        updated_state = self._clamp_state(self.m1x_prior + INOV)
        self.m1x_posterior_previous = self.m1x_posterior
        self.m1x_posterior = updated_state
        self.m1x_prior_previous = self.m1x_prior
        self.y_previous = y.squeeze(-1)
        return self.m1x_posterior

    def predict_step(self, controls):
        """NaN-observation day: advance the prior, no gain (mature knet_step always updates)."""
        self.step_prior(controls)
        x_prior = self.m1x_prior                   # already clamped in step_prior
        self.m1x_posterior_previous = self.m1x_posterior
        self.m1x_prior_previous = self.m1x_prior
        self.m1x_posterior = x_prior
        self.y_previous = self.h(x_prior).reshape(self.batch_size, self.n)
        return self.m1x_posterior

    # -------------------------------------------- static-attribute conditioning (iter17)
    def enable_attr_conditioning(self, n_attrs, d_emb=8, enc_hidden=16):
        """Condition the gain on static catchment attributes (2026-07-07): widen the INPUT side
        of FC5/FC6/FC7 by d_emb columns and add a small attr-encoder MLP. The embedding is
        appended per-timestep to the diffs inside compute_gain_native, AFTER the guard/clamp
        path, so KGain_step / the 3 LSTMs run UNCHANGED (the forward never hardcodes input
        dims). The widening is a _WidenedLinear wrapper: the ORIGINAL Linear survives untouched
        (same weight tensor, same gemm -> bit-identical), the extra columns live in a separate
        ZERO-initialized bias-free Linear whose output is added — an exactly-zero matrix product
        is an IEEE no-op, so at init the forward is BIT-identical to the unconditioned net
        REGARDLESS of the attr values (a plain widened-matrix rebuild is only mathematically
        identical: the wider gemm changes summation order -> ~1e-16 drift; verified 2026-07-07).
        Conditioning only wakes up as training moves the extension weights off zero. The final
        Tanh bounds the embedding O(1), consistent with the normalized-diff feature scale."""
        self.attr_encoder = nn.Sequential(
            nn.Linear(n_attrs, enc_hidden), nn.Tanh(),
            nn.Linear(enc_hidden, d_emb), nn.Tanh()).to(self.device)
        self.d_attr_emb = d_emb
        self._basin_attrs = None
        for name in ("FC5", "FC6", "FC7"):
            seq = getattr(self, name)
            seq[0] = _WidenedLinear(seq[0], d_emb).to(self.device)

    def set_basin_attrs(self, attrs):
        """Per-basin z-scored attribute vector [1, n_attrs]; set once per filter window."""
        self._basin_attrs = attrs

    # -------------------------------------------------- SHARED (storage-only) gain path
    def compute_gain_native(self, obs_diff, obs_innov, fw_evol, fw_update, guard=None):
        """The user's `estimate_gain` MINUS the internal diff computation: the shared filter
        supplies the four diffs ALREADY normalized per-basin (obs diffs / obs_scale, state diffs
        / state_scale), so the learned gain is dimensionless and transferable to held-out basins.
        Everything that touches the network — `apply_clamp_scale_to_diffs` (his native input
        guard) and `KGain_step` (his 3 LSTMs / FC1-7 / residuals) — is his code, unchanged.

        `guard` is an O(1) pre-clamp on the NORMALIZED diffs (the scale-normalized analogue of his
        raw-WALRUS ±100/±5000 guard, whose magnitudes are inert for O(1) features). It mirrors the
        rewrite's `diff_guard_*` and runs BEFORE his guard, matching the documented ordering. The
        clamp returns copies, so the filter's own (unclamped) obs_innov is still used to rescale.

        Returns the gain reshaped to [B, m, n] (m = N_STORAGE here)."""
        if guard is not None:
            obs_diff = obs_diff.clamp(-guard, guard)
            obs_innov = obs_innov.clamp(-guard, guard)
            fw_evol = fw_evol.clamp(-guard, guard)
            fw_update = fw_update.clamp(-guard, guard)
        obs_diff, obs_innov, fw_evol, fw_update = self.apply_clamp_scale_to_diffs(
            obs_diff, obs_innov, fw_evol, fw_update)
        if getattr(self, "attr_encoder", None) is not None:
            if self._basin_attrs is None:
                raise RuntimeError("attr conditioning enabled but set_basin_attrs() not called")
            emb = self.attr_encoder(self._basin_attrs)         # [1, d_emb], tanh-bounded O(1)
            fw_update = torch.cat([fw_update, emb], dim=1)     # -> FC5 input (m + d_emb)
            fw_evol = torch.cat([fw_evol, emb], dim=1)         # -> FC6 input (m + d_emb)
            obs_innov = torch.cat([obs_innov, emb], dim=1)     # -> FC7 in cat(obs_diff, .) (2n + d_emb)
        KG = self.KGain_step(obs_diff, obs_innov, fw_evol, fw_update)
        return torch.reshape(KG, (self.batch_size, self.m, self.n))


class _StorageNetSpec:
    """Minimal duck-typed sys-model so `build_nn` can size the user's network at m=N_STORAGE
    (storage-only shared gain), INDEPENDENT of each basin's routing length L -> a single net
    drives every basin. f/h are never called on the shared path (the filter calls the real
    routed sm.f/sm.h); only m / n / the noise-covariance priors size the net and seed the LSTM
    hidden states. This is the §72 "m=5, buffer evolved by f outside the loop" resolution."""

    def __init__(self, n_storage, device, dtype):
        self.m = int(n_storage)
        self.n = 1
        self.f = None
        self.h = None
        self.prior_q = torch.eye(self.m, device=device, dtype=dtype)
        self.prior_state_cov = torch.eye(self.m, device=device, dtype=dtype) * 10.0
        self.prior_r = torch.eye(self.n, device=device, dtype=dtype)


def build_storage_net(device, dtype=torch.float32, n_storage=5, zero_gain_init=False,
                      n_attrs=0, d_attr_emb=8, attr_enc_hidden=16, **netkw):
    """Build the user's mature KalmanNet at m=N_STORAGE for the regional SHARED (storage-only)
    gain. `zero_gain_init` defaults OFF: near-zero gain-head init HURT the mature network in the
    per-basin tests (02149000 +0.715 -> +0.122) and the G2/G3 guardrails handle the early blowup
    instead; exposed as a flag so the shared gate can A/B it if needed.

    `n_attrs>0` enables static-attribute conditioning (enable_attr_conditioning). The surgery
    runs AFTER all base-weight draws, so for a given torch seed the base weights are identical
    to the n_attrs=0 build (the widened columns start at zero -> bit-identical forward at init)."""
    spec = _StorageNetSpec(n_storage, device, dtype)
    net = HBVLiteKalmanNet(spec, device=device, freeze_buffer=False, state_ub=None,
                           zero_gain_init=zero_gain_init, **netkw)
    if n_attrs > 0:
        net.enable_attr_conditioning(n_attrs, d_emb=d_attr_emb, enc_hidden=attr_enc_hidden)
    return net.to(dtype)
