"""Daily CAMELS UKF/KalmanNet parity primitives for basin 09035800.

This module is intentionally a thin integration layer.  It reuses the frozen
TUKF06 HBV-light context, filter, forecast, and objective implementation and
the repository's existing full-state adapter around the original KalmanNet.
It never loads the reserved 1989-10-01 through 1999-09-30 evaluation period.

Two initialization modes are deliberately kept separate:

* ``exact_tukf06_backward_time_diagnostic`` reproduces the archived TUKF06
  reset and is diagnostic only because the stored state came from 2008.
* ``causal_shared_spinup`` constructs the parameter-only warm state in 1999
  and advances it with meteorological forcing only before validation.

The public functions do not write artifacts.  A command-line entry point may
serialize their results only under a new experiment identifier and output
root after its own admission and locking checks.
"""

from __future__ import annotations

import copy
from dataclasses import dataclass, replace
from hashlib import sha256
import json
import math
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Mapping, Sequence

import numpy as np
import torch

import scripts.tukf06_full_diagonal_common as _tukf06_common
from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import (
    ALLOWED_ARCHIVE_MEMBERS,
    BASIN_ID,
    CAUSAL_SHARED_SPINUP_MODE,
    DEVELOPMENT_END,
    DEVELOPMENT_START,
    EXACT_TUKF06_DIAGNOSTIC_MODE,
    EXPECTED_STATE_DIMENSION,
    NATIVE_DEFAULT_GAIN_INITIALIZATION,
    NEAR_ZERO_FC2_HEAD_GAIN_INITIALIZATION,
    AccessLedger,
    InitializationEvidence,
    ParityContract,
    fixed_scoring_window,
    validate_initialization_usage,
)
from global_hydrology.models.differentiable_hbv_lite import PARAM_NAMES
from global_hydrology.models.knet_native_hbvlite_full_state import (
    NativeHBVFullStateKalmanNet,
)


ROOT = Path(__file__).resolve().parents[3]
DEFAULT_ARCHIVE = (
    ROOT
    / "results"
    / "tukf06_full_diagonal_search_head_to_head_v1"
    / "selection_inputs"
    / "basin_09035800.npz"
)
DEFAULT_SELECTION = (
    ROOT
    / "results"
    / "tukf06_full_diagonal_search_head_to_head_v1"
    / "selection"
    / "basin_09035800.json"
)
TRAINING_DAYS = 2557
LEADS = (1, 2, 3)


@dataclass(frozen=True)
class ParityRuntime:
    """Verified development-only arrays and their shared physical context."""

    contract: ParityContract
    tukf06_contract: Mapping[str, Any]
    context: Any
    forcing: torch.Tensor
    observations: torch.Tensor
    dates: np.ndarray
    training_days: int
    initialization_evidence: InitializationEvidence
    ledger: AccessLedger
    archive_path: Path
    archive_sha256: str
    tukf06_module: Any


@dataclass(frozen=True)
class WindowBatch:
    """One fixed diagnostic, recovery, or training window."""

    purpose: str
    global_start: int
    global_end_exclusive: int
    context: Any
    forcing: torch.Tensor
    observations: torch.Tensor
    dates: np.ndarray
    initial_state: torch.Tensor
    issue_start_local: int
    issue_end_local: int


@dataclass(frozen=True)
class FeatureScales:
    """Difference root-mean-square scales fitted before validation only."""

    observation_feature_scale: torch.Tensor
    state_feature_scale: torch.Tensor
    fit_start_index: int
    fit_end_exclusive: int
    floor: float


@dataclass(frozen=True)
class KNetTrace:
    """Full routed-state filtering trace without detached training graphs."""

    prior_states: torch.Tensor
    posterior_states: torch.Tensor
    requested_corrections: torch.Tensor
    corrections: torch.Tensor
    valid_updates: torch.Tensor


@dataclass(frozen=True)
class ForecastPairs:
    """Explicit issue/target pairs used by every compared method."""

    predictions: Mapping[int, np.ndarray]
    targets: Mapping[int, np.ndarray]
    issue_indices: Mapping[int, np.ndarray]
    target_indices: Mapping[int, np.ndarray]
    finite_masks: Mapping[int, np.ndarray]


@dataclass(frozen=True)
class ScoreSummary:
    """Physical-unit objective and per-lead Nash-Sutcliffe efficiencies."""

    objective: float
    mse_by_lead: Mapping[int, float]
    nse_by_lead: Mapping[int, float]
    target_count_by_lead: Mapping[int, int]
    predictions: Mapping[int, np.ndarray]
    targets: Mapping[int, np.ndarray]
    issue_indices: Mapping[int, np.ndarray]
    target_indices: Mapping[int, np.ndarray]
    finite_masks: Mapping[int, np.ndarray]
    full_objective_without_warmup: float | None = None
    full_target_count_by_lead_without_warmup: Mapping[int, int] | None = None
    posterior_states: np.ndarray | None = None
    open_loop: np.ndarray | None = None
    maximum_open_loop_difference: float | None = None
    metadata: Mapping[str, Any] | None = None


@dataclass(frozen=True)
class SegmentLoss:
    """Differentiable physical-unit multi-lead segment objective."""

    objective: torch.Tensor
    mse_by_lead: Mapping[int, torch.Tensor]
    target_count_by_lead: Mapping[int, int]


@dataclass(frozen=True)
class EpochRecord:
    epoch: int
    training_objective: float | None
    checkpoint_objective_without_warmup: float
    gate_objective_after_warmup: float
    nse_by_lead: Mapping[int, float]
    target_count_by_lead: Mapping[int, int]
    parameter_sha256: str
    optimizer_steps: int
    nonzero_gradient_tensors: int
    parameter_tensors_with_gradients: int


@dataclass(frozen=True)
class TrainingResult:
    net: NativeHBVFullStateKalmanNet
    history: tuple[EpochRecord, ...]
    epoch_zero_checkpoint_objective: float
    best_epoch: int
    best_checkpoint_objective: float
    best_parameter_sha256: str
    last_parameter_sha256: str
    optimizer_steps: int
    best_state_dict: Mapping[str, torch.Tensor]


def _sha256_file(path: Path) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _require_shape(array: np.ndarray, shape: tuple[int, ...], name: str) -> None:
    if tuple(array.shape) != shape:
        raise ValueError(f"{name} shape {tuple(array.shape)} does not match {shape}")


def _causal_default_storage(parameters: torch.Tensor) -> torch.Tensor:
    field_capacity = parameters[:, PARAM_NAMES.index("parFC") : PARAM_NAMES.index("parFC") + 1]
    zeros = torch.zeros(1, 1, device=parameters.device, dtype=parameters.dtype)
    return torch.cat(
        [
            zeros,
            zeros,
            0.3 * field_capacity,
            torch.full_like(zeros, 5.0),
            torch.full_like(zeros, 10.0),
        ],
        dim=-1,
    )


def _context_with_initial_state(context: Any, initial_state: torch.Tensor) -> Any:
    try:
        return replace(context, initial_state=initial_state)
    except TypeError:  # permit a lightweight injected context in unit tests
        cloned = copy.copy(context)
        cloned.initial_state = initial_state
        return cloned


def load_archive_context(
    path: Path,
    contract: ParityContract,
    ledger: AccessLedger,
    *,
    initialization_mode: str,
    device: str | torch.device = "cpu",
    tukf06_module: Any | None = None,
) -> ParityRuntime:
    """Load the frozen development archive and rebuild the TUKF06 context.

    The causal mode intentionally does not materialize the three archived
    future-derived initialization arrays.  The exact diagnostic mode reads and
    verifies all three against the rebuilt context.
    """

    module = _tukf06_common if tukf06_module is None else tukf06_module
    selected_device = torch.device(device)
    archive_path = Path(path).resolve()
    if not archive_path.is_file():
        raise FileNotFoundError(archive_path)
    archive_hash = _sha256_file(archive_path)
    if archive_hash != contract.archive_sha256:
        raise RuntimeError("development archive SHA-256 differs from the frozen contract")

    common_members = {
        "dates_ns",
        "forcing",
        "observations",
        "parameters",
        "base_observation_variance",
        "state_dimension",
    }
    if initialization_mode == EXACT_TUKF06_DIAGNOSTIC_MODE:
        members_to_read = set(ALLOWED_ARCHIVE_MEMBERS)
    elif initialization_mode == CAUSAL_SHARED_SPINUP_MODE:
        members_to_read = common_members
    else:
        raise ValueError(f"unknown initialization mode: {initialization_mode}")

    arrays: dict[str, np.ndarray] = {}
    with np.load(archive_path, allow_pickle=False) as archive:
        if set(archive.files) != set(contract.archive_members):
            raise RuntimeError("development archive member set differs from the contract")
        for name in sorted(members_to_read):
            ledger.record_archive_member(name)
            arrays[name] = np.asarray(archive[name]).copy()

    dates_ns = np.asarray(arrays["dates_ns"], dtype=np.int64)
    forcing_array = np.asarray(arrays["forcing"], dtype=np.float64)
    observation_array = np.asarray(arrays["observations"], dtype=np.float64)
    parameter_array = np.asarray(arrays["parameters"], dtype=np.float64)
    base_variance_array = np.asarray(
        arrays["base_observation_variance"], dtype=np.float64
    )
    dimension_array = np.asarray(arrays["state_dimension"], dtype=np.int64)
    _require_shape(dates_ns, (contract.expected_days,), "dates_ns")
    _require_shape(forcing_array, (contract.expected_days, 3), "forcing")
    _require_shape(observation_array, (contract.expected_days,), "observations")
    _require_shape(parameter_array, (1, len(PARAM_NAMES)), "parameters")
    _require_shape(base_variance_array, (1,), "base_observation_variance")
    _require_shape(dimension_array, (1,), "state_dimension")
    if int(dimension_array[0]) != contract.state_dimension:
        raise RuntimeError("archive state dimension differs from the parity contract")
    if not np.isfinite(forcing_array).all() or not np.isfinite(parameter_array).all():
        raise FloatingPointError("archive forcing and parameters must be finite")
    if not np.isfinite(base_variance_array).all() or float(base_variance_array[0]) <= 0.0:
        raise FloatingPointError("archive observation variance must be finite and positive")

    dates = dates_ns.astype("datetime64[ns]")
    if len(dates) == 0 or np.any(dates[1:] <= dates[:-1]):
        raise ValueError("development dates must be strictly increasing")
    if str(dates[0].astype("datetime64[D]")) != DEVELOPMENT_START:
        raise RuntimeError("development archive start date changed")
    if str(dates[-1].astype("datetime64[D]")) != DEVELOPMENT_END:
        raise RuntimeError("development archive end date changed")
    if str(dates[TRAINING_DAYS].astype("datetime64[D]")) != "2006-10-01":
        raise RuntimeError("training/validation boundary changed")
    ledger.record_date_request(DEVELOPMENT_START, DEVELOPMENT_END)

    forcing = torch.as_tensor(
        forcing_array, dtype=torch.float64, device=selected_device
    ).unsqueeze(1)
    observations = torch.as_tensor(
        observation_array, dtype=torch.float64, device=selected_device
    ).unsqueeze(1)
    parameters = torch.as_tensor(
        parameter_array, dtype=torch.float64, device=selected_device
    )
    if initialization_mode == EXACT_TUKF06_DIAGNOSTIC_MODE:
        archived_storage = np.asarray(arrays["initial_storage_state"], dtype=np.float64)
        _require_shape(archived_storage, (1, 5), "initial_storage_state")
        x0_table = torch.as_tensor(
            archived_storage, dtype=torch.float64, device=selected_device
        )
    else:
        x0_table = _causal_default_storage(parameters)

    prior = SimpleNamespace(
        basin_ids=[BASIN_ID],
        param_table=parameters,
        x0_table=x0_table,
    )
    tukf06_contract = module.load_contract()
    context = module.build_basin_context(
        prior,
        BASIN_ID,
        observations[:TRAINING_DAYS],
        tukf06_contract,
        device=selected_device,
    )
    if int(context.dimension) != EXPECTED_STATE_DIMENSION:
        raise RuntimeError("rebuilt TUKF06 context is not 18-dimensional")

    comparisons = {
        "parameters": context.parameters.detach().cpu().numpy(),
        "base_observation_variance": np.asarray(
            [context.base_observation_variance], dtype=np.float64
        ),
        "state_dimension": np.asarray([context.dimension], dtype=np.int64),
    }
    if initialization_mode == EXACT_TUKF06_DIAGNOSTIC_MODE:
        comparisons.update(
            {
                "initial_storage_state": context.initial_storage_state.detach()
                .cpu()
                .numpy(),
                "initial_state": context.initial_state.detach().cpu().numpy(),
                "initial_covariance": context.initial_covariance.detach()
                .cpu()
                .numpy(),
            }
        )
    for name, rebuilt in comparisons.items():
        if not np.array_equal(np.asarray(arrays[name]), rebuilt):
            raise RuntimeError(f"rebuilt TUKF06 context differs from archive member {name}")

    evidence = validate_initialization_usage(
        initialization_mode, used_archive_members=set(members_to_read)
    )
    return ParityRuntime(
        contract=contract,
        tukf06_contract=tukf06_contract,
        context=context,
        forcing=forcing,
        observations=observations,
        dates=dates,
        training_days=TRAINING_DAYS,
        initialization_evidence=evidence,
        ledger=ledger,
        archive_path=archive_path,
        archive_sha256=archive_hash,
        tukf06_module=module,
    )


def _advance_open_loop(
    context: Any, forcing: torch.Tensor, *, end_exclusive: int
) -> torch.Tensor:
    if not 0 <= int(end_exclusive) <= len(forcing):
        raise ValueError("open-loop spin-up boundary is outside the forcing record")
    state = context.initial_state.clone()
    with torch.no_grad():
        for day in range(int(end_exclusive)):
            state = context.plain_model.f(state, forcing[day, 0, :].reshape(1, 3))
    return state


def select_window(runtime: ParityRuntime, purpose: str) -> WindowBatch:
    """Select the 128-day diagnostic or complete 731-day recovery window."""

    scoring = fixed_scoring_window(runtime.contract, purpose=purpose)
    start = scoring.window_start_index
    end = scoring.window_end_exclusive
    if runtime.initialization_evidence.mode == EXACT_TUKF06_DIAGNOSTIC_MODE:
        initial_state = runtime.context.initial_state.clone()
    elif runtime.initialization_evidence.mode == CAUSAL_SHARED_SPINUP_MODE:
        initial_state = _advance_open_loop(
            runtime.context, runtime.forcing, end_exclusive=start
        )
    else:  # pragma: no cover - load_archive_context already rejects this
        raise ValueError("runtime has an unknown initialization mode")
    local_issue_start = scoring.issue_start_index - start
    local_issue_end = scoring.issue_end_exclusive - start
    if local_issue_start != runtime.contract.filter_warmup_days:
        raise RuntimeError("window warm-up geometry changed")
    if local_issue_end != (end - start) - max(runtime.contract.leads):
        raise RuntimeError("window issue boundary changed")
    context = _context_with_initial_state(runtime.context, initial_state)
    return WindowBatch(
        purpose=purpose,
        global_start=start,
        global_end_exclusive=end,
        context=context,
        forcing=runtime.forcing[start:end],
        observations=runtime.observations[start:end],
        dates=runtime.dates[start:end],
        initial_state=initial_state,
        issue_start_local=local_issue_start,
        issue_end_local=local_issue_end,
    )


def full_state_correction_mask(
    state_dimension: int,
    *,
    dtype: torch.dtype = torch.float64,
    device: str | torch.device = "cpu",
) -> torch.Tensor:
    """Authorize the full 18-dimensional physical and routed state."""

    if int(state_dimension) != EXPECTED_STATE_DIMENSION:
        raise ValueError("basin 09035800 requires exactly 18 corrected state coordinates")
    return torch.ones(1, int(state_dimension), dtype=dtype, device=device)


def _difference_root_mean_square(
    values: torch.Tensor, *, floor: float
) -> torch.Tensor:
    if not math.isfinite(float(floor)) or float(floor) <= 0.0:
        raise ValueError("feature scale floor must be finite and positive")
    if len(values) < 2:
        raise ValueError("feature scales require at least two training days")
    differences = values[1:] - values[:-1]
    valid = torch.isfinite(differences)
    if differences.ndim == 1:
        if not bool(valid.any()):
            raise FloatingPointError("training differences contain no finite value")
        scale = torch.sqrt(torch.mean(differences[valid].square()))
    else:
        counts = valid.sum(dim=0)
        if bool((counts == 0).any()):
            raise FloatingPointError("a training feature has no finite difference")
        squared = torch.where(valid, differences.square(), torch.zeros_like(differences))
        scale = torch.sqrt(squared.sum(dim=0) / counts)
    scale = torch.clamp(scale, min=float(floor))
    if not bool(torch.isfinite(scale).all()) or bool((scale <= 0.0).any()):
        raise FloatingPointError("training feature scales are invalid")
    return scale


def training_open_loop_states(runtime: ParityRuntime) -> torch.Tensor:
    """Return post-transition states using only the pre-validation forcing."""

    states: list[torch.Tensor] = []
    state = runtime.context.initial_state.clone()
    with torch.no_grad():
        for day in range(runtime.training_days):
            state = runtime.context.plain_model.f(
                state, runtime.forcing[day, 0, :].reshape(1, 3)
            )
            if not bool(torch.isfinite(state).all()):
                raise FloatingPointError(f"non-finite training open-loop state at day {day}")
            states.append(state)
    return torch.stack(states)


def fit_training_feature_scales(
    runtime: ParityRuntime, *, floor: float = 0.1
) -> FeatureScales:
    """Fit all KalmanNet normalization scales before 2006-10-01."""

    training_observations = runtime.observations[: runtime.training_days, 0]
    states = training_open_loop_states(runtime)[:, 0, :]
    observation_scale = _difference_root_mean_square(
        training_observations, floor=floor
    ).reshape(1, 1)
    state_scale = _difference_root_mean_square(states, floor=floor).reshape(
        1, runtime.context.dimension
    )
    return FeatureScales(
        observation_feature_scale=observation_scale,
        state_feature_scale=state_scale,
        fit_start_index=0,
        fit_end_exclusive=runtime.training_days,
        floor=float(floor),
    )


def _state_bounds(runtime: ParityRuntime) -> tuple[torch.Tensor, torch.Tensor]:
    dimension = runtime.context.dimension
    lower = torch.zeros(
        1,
        dimension,
        dtype=runtime.context.dtype,
        device=runtime.context.device,
    )
    upper = torch.full_like(lower, torch.inf)
    field_capacity = runtime.context.parameters[
        :, PARAM_NAMES.index("parFC") : PARAM_NAMES.index("parFC") + 1
    ]
    upper[:, 2:3] = field_capacity
    return lower, upper


def apply_gain_initialization(
    net: NativeHBVFullStateKalmanNet,
    mode: str,
) -> None:
    """Apply one frozen training-only gain-head initialization policy."""

    if mode == NATIVE_DEFAULT_GAIN_INITIALIZATION:
        return
    if mode != NEAR_ZERO_FC2_HEAD_GAIN_INITIALIZATION:
        raise ValueError(
            "gain initialization must be native_default or near_zero_fc2_head"
        )
    head = net.FC2[-1]
    if not isinstance(head, torch.nn.Linear):
        raise TypeError("the original KalmanNet FC2 output head must remain linear")
    if head.bias is None or int(head.out_features) != int(net.m * net.n):
        raise RuntimeError("the original KalmanNet FC2 output head geometry changed")
    with torch.no_grad():
        head.weight.mul_(0.01)
        head.bias.zero_()


def build_native_knet(
    runtime: ParityRuntime,
    *,
    zero_gain: bool,
    gain_initialization: str,
    seed: int,
    hidden: int = 24,
    in_mult: int = 10,
    out_mult: int = 10,
    feature_scale_floor: float = 0.1,
    normalized_feature_guard: float | None = 10.0,
) -> NativeHBVFullStateKalmanNet:
    """Bind the existing original-gain KalmanNet to the shared HBV context."""

    torch.manual_seed(int(seed))
    if runtime.context.device.type == "cuda":
        torch.cuda.manual_seed_all(int(seed))
    scales = fit_training_feature_scales(runtime, floor=feature_scale_floor)
    mask = full_state_correction_mask(
        runtime.context.dimension,
        dtype=runtime.context.dtype,
        device=runtime.context.device,
    )
    lower, upper = _state_bounds(runtime)
    net = NativeHBVFullStateKalmanNet(
        runtime.context.plain_model,
        correction_mask=mask,
        state_lower_bound=lower,
        state_upper_bound=upper,
        device=runtime.context.device,
        hidden=int(hidden),
        in_mult=int(in_mult),
        out_mult=int(out_mult),
        correction_cap_in_state_scale_units=None,
    ).to(device=runtime.context.device)
    if {parameter.dtype for parameter in net.parameters()} != {torch.float32}:
        raise RuntimeError("the archived original KalmanNet gain core must remain float32")
    net.set_basin_adaptation(
        system=runtime.context.plain_model,
        correction_mask=mask,
        state_lower_bound=lower,
        state_upper_bound=upper,
        observation_feature_scale=scales.observation_feature_scale,
        state_feature_scale=scales.state_feature_scale,
        correction_cap_by_state_scale_units=None,
        normalized_feature_guard=normalized_feature_guard,
    )
    if zero_gain:
        if gain_initialization != NATIVE_DEFAULT_GAIN_INITIALIZATION:
            raise ValueError(
                "strict zero-gain replay cannot be combined with a training initialization"
            )
        with torch.no_grad():
            net.FC2[-1].weight.zero_()
            net.FC2[-1].bias.zero_()
    else:
        apply_gain_initialization(net, gain_initialization)
    return net


def run_knet_filter(
    net: NativeHBVFullStateKalmanNet,
    window: WindowBatch,
    *,
    previous_observation: torch.Tensor | None = None,
) -> KNetTrace:
    """Run the existing KalmanNet gain on the shared point-state HBV transition.

    The underlying HBV transition, forcing, observation operator, and physical
    projection are shared with the UKF route.  The prior operators are not
    numerically identical: KalmanNet propagates one posterior state whereas the
    UKF propagates sigma points and process covariance.
    """

    length = len(window.observations)
    if length <= max(LEADS):
        raise ValueError("filter window is too short for three-day forecasts")
    net.initialize_filter(
        window.initial_state,
        sequence_length=length,
        previous_observation=previous_observation,
    )
    priors: list[torch.Tensor] = []
    posteriors: list[torch.Tensor] = []
    requested_corrections: list[torch.Tensor] = []
    realized_corrections: list[torch.Tensor] = []
    valid_updates: list[bool] = []
    for day in range(length):
        controls = window.forcing[day, 0, :].reshape(1, 3)
        observation = window.observations[day, 0].reshape(1, 1)
        valid = bool(torch.isfinite(observation).all())
        if valid:
            posterior = net.analysis_step(observation, controls)
        else:
            posterior = net.predict_step(controls)
        if not bool(torch.isfinite(net.m1x_prior).all()) or not bool(
            torch.isfinite(posterior).all()
        ):
            raise FloatingPointError(f"non-finite KalmanNet state at local day {day}")
        priors.append(net.m1x_prior.clone())
        posteriors.append(posterior.clone())
        requested_corrections.append(net.last_correction.clone())
        realized_corrections.append((posterior - net.m1x_prior).clone())
        valid_updates.append(valid)
    return KNetTrace(
        prior_states=torch.stack(priors),
        posterior_states=torch.stack(posteriors),
        requested_corrections=torch.stack(requested_corrections),
        corrections=torch.stack(realized_corrections),
        valid_updates=torch.tensor(
            valid_updates, dtype=torch.bool, device=window.observations.device
        ),
    )


def previous_observation_before_window(
    runtime: ParityRuntime,
    window: WindowBatch,
) -> torch.Tensor | None:
    """Return the causal observation immediately before a sliced window."""

    start = int(window.global_start)
    if start <= 0:
        return None
    if start > len(runtime.observations):
        raise ValueError("window starts beyond the observation record")
    previous = runtime.observations[start - 1 : start]
    if previous.shape != (1, 1):
        raise ValueError("previous observation slice has the wrong shape")
    if not bool(torch.isfinite(previous).all()):
        return None
    return previous


def aligned_forecasts_from_posterior(
    runtime: ParityRuntime,
    window: WindowBatch,
    posterior_states: torch.Tensor,
) -> dict[int, np.ndarray]:
    """Use the exact TUKF06 multi-lead forecast propagation and alignment."""

    if posterior_states.shape != (
        len(window.observations),
        1,
        runtime.context.dimension,
    ):
        raise ValueError("posterior state trace has the wrong time or state dimensions")
    raw = runtime.tukf06_module.multilead_torch(
        window.context.plain_model,
        posterior_states[:, 0, :],
        window.forcing,
    )
    aligned: dict[int, np.ndarray] = {}
    for lead, (forecast, target_indices) in raw.items():
        values = np.full(len(window.observations), np.nan, dtype=np.float64)
        values[target_indices.detach().cpu().numpy()] = (
            forecast.detach().cpu().numpy()
        )
        aligned[int(lead)] = values
    if set(aligned) != set(LEADS):
        raise RuntimeError("TUKF06 forecast propagation did not return leads 1, 2, and 3")
    return aligned


def forecast_pairs(
    observations: Sequence[float] | np.ndarray | torch.Tensor,
    predictions: Mapping[int, Sequence[float] | np.ndarray],
    *,
    issue_start: int,
    issue_end: int,
    leads: Sequence[int] = LEADS,
) -> ForecastPairs:
    """Pair aligned forecasts with fixed issues and their target dates."""

    if torch.is_tensor(observations):
        target_array = observations.detach().cpu().numpy()
    else:
        target_array = np.asarray(observations)
    target_array = np.asarray(target_array, dtype=np.float64).reshape(-1)
    ordered_leads = tuple(int(value) for value in leads)
    if ordered_leads != tuple(sorted(set(ordered_leads))) or not ordered_leads:
        raise ValueError("forecast leads must be unique increasing integers")
    if min(ordered_leads) < 1:
        raise ValueError("forecast leads must be positive")
    if not 0 <= int(issue_start) < int(issue_end):
        raise ValueError("issue interval is empty or reversed")
    if int(issue_end) + max(ordered_leads) > len(target_array):
        raise ValueError("forecast targets extend beyond the observation record")
    if set(int(value) for value in predictions) != set(ordered_leads):
        raise ValueError("prediction leads differ from the requested leads")

    selected_predictions: dict[int, np.ndarray] = {}
    selected_targets: dict[int, np.ndarray] = {}
    issue_indices: dict[int, np.ndarray] = {}
    target_indices: dict[int, np.ndarray] = {}
    masks: dict[int, np.ndarray] = {}
    common_issues = np.arange(int(issue_start), int(issue_end), dtype=np.int64)
    for lead in ordered_leads:
        aligned = np.asarray(predictions[lead], dtype=np.float64).reshape(-1)
        if aligned.shape != target_array.shape:
            raise ValueError("every aligned prediction must match the observation length")
        indices = common_issues + lead
        predicted = aligned[indices]
        targets = target_array[indices]
        if not bool(np.isfinite(predicted).all()):
            raise FloatingPointError(
                f"forecast pairing contains a non-finite lead-{lead} prediction"
            )
        finite = np.isfinite(targets)
        selected_predictions[lead] = predicted
        selected_targets[lead] = targets
        issue_indices[lead] = common_issues.copy()
        target_indices[lead] = indices
        masks[lead] = finite
    return ForecastPairs(
        predictions=selected_predictions,
        targets=selected_targets,
        issue_indices=issue_indices,
        target_indices=target_indices,
        finite_masks=masks,
    )


def assert_identical_forecast_geometry(
    reference: ForecastPairs, candidate: ForecastPairs
) -> None:
    """Fail closed unless methods use identical issues, targets, and masks."""

    fields = (
        "issue_indices",
        "target_indices",
        "finite_masks",
        "targets",
    )
    for field in fields:
        expected = getattr(reference, field)
        actual = getattr(candidate, field)
        label = field.replace("_", " ")
        if set(expected) != set(actual):
            raise ValueError(f"forecast {label} leads differ")
        for lead in sorted(expected):
            equal_nan = field == "targets"
            if not np.array_equal(
                np.asarray(expected[lead]), np.asarray(actual[lead]), equal_nan=equal_nan
            ):
                raise ValueError(f"forecast {label} differs at lead {lead}")


def physical_multilead_mse(pairs: ForecastPairs) -> float:
    """Equal-lead physical-unit mean squared error; no variance normalization."""

    losses: list[float] = []
    for lead in sorted(pairs.predictions):
        mask = np.asarray(pairs.finite_masks[lead], dtype=bool)
        if int(mask.sum()) < 1:
            raise ValueError(f"lead {lead} has no finite forecast target")
        error = np.asarray(pairs.predictions[lead])[mask] - np.asarray(
            pairs.targets[lead]
        )[mask]
        value = float(np.mean(np.square(error)))
        if not math.isfinite(value):
            raise FloatingPointError(f"lead {lead} physical-unit MSE is non-finite")
        losses.append(value)
    result = float(np.mean(losses))
    if not math.isfinite(result):
        raise FloatingPointError("physical-unit multi-lead MSE is non-finite")
    return result


def score_forecast_pairs(pairs: ForecastPairs) -> ScoreSummary:
    """Recompute physical MSE and population NSE from explicit pairs."""

    mse: dict[int, float] = {}
    nse: dict[int, float] = {}
    counts: dict[int, int] = {}
    for lead in sorted(pairs.predictions):
        prediction = np.asarray(pairs.predictions[lead], dtype=np.float64)
        target = np.asarray(pairs.targets[lead], dtype=np.float64)
        mask = np.asarray(pairs.finite_masks[lead], dtype=bool)
        counts[lead] = int(mask.sum())
        if counts[lead] < 2:
            raise ValueError(f"lead {lead} has fewer than two finite targets")
        error = prediction[mask] - target[mask]
        mse[lead] = float(np.mean(np.square(error)))
        nse[lead] = _tukf06_common.nse_population(prediction, target, mask)
    return ScoreSummary(
        objective=float(np.mean([mse[lead] for lead in sorted(mse)])),
        mse_by_lead=mse,
        nse_by_lead=nse,
        target_count_by_lead=counts,
        predictions=pairs.predictions,
        targets=pairs.targets,
        issue_indices=pairs.issue_indices,
        target_indices=pairs.target_indices,
        finite_masks=pairs.finite_masks,
    )


def _require_window_target_count(
    runtime: ParityRuntime, window: WindowBatch, score: ScoreSummary
) -> None:
    expected = (
        runtime.contract.expected_diagnostic_target_count_per_lead
        if window.purpose == "diagnostic"
        else runtime.contract.expected_recovery_target_count_per_lead
    )
    if any(score.target_count_by_lead.get(lead) != expected for lead in LEADS):
        raise RuntimeError(
            f"{window.purpose} must retain exactly {expected} finite targets per lead"
        )


def _load_selected_theta(path: Path, method: str) -> tuple[np.ndarray, Mapping[str, Any]]:
    selection_path = Path(path).resolve()
    record = json.loads(selection_path.read_text(encoding="utf-8"))
    if record.get("experiment_id") != _tukf06_common.EXPERIMENT_ID:
        raise RuntimeError("selection file is not the frozen TUKF06 experiment")
    if record.get("basin_id") != BASIN_ID:
        raise RuntimeError("selection file is not for basin 09035800")
    if record.get("evaluation_period_read") is not False:
        raise RuntimeError("TUKF06 selection unexpectedly reports evaluation-period access")
    if int(record.get("training_days", -1)) != TRAINING_DAYS:
        raise RuntimeError("TUKF06 selection training length changed")
    if int(record.get("state_dimension", -1)) != EXPECTED_STATE_DIMENSION:
        raise RuntimeError("TUKF06 selection state dimension changed")
    if method not in {"backpropagation", "sampling_search"}:
        raise ValueError("TUKF06 method must be backpropagation or sampling_search")
    theta = np.asarray(record[method]["selected"]["theta_log"], dtype=np.float64)
    if theta.shape != (EXPECTED_STATE_DIMENSION + 1,) or not np.isfinite(theta).all():
        raise ValueError("selected TUKF06 theta is invalid")
    return theta, record


def replay_tukf06_ukf(
    runtime: ParityRuntime,
    window: WindowBatch,
    *,
    selection_path: Path = DEFAULT_SELECTION,
    method: str = "backpropagation",
) -> ScoreSummary:
    """Replay the selected TUKF06 filter on exactly the requested window."""

    theta, selection = _load_selected_theta(selection_path, method)
    forecasts = runtime.tukf06_module.filter_forecasts(
        window.context,
        window.forcing,
        window.observations,
        theta,
        runtime.tukf06_contract,
    )
    pairs = forecast_pairs(
        window.observations,
        forecasts,
        issue_start=window.issue_start_local,
        issue_end=window.issue_end_local,
        leads=runtime.contract.leads,
    )
    score = score_forecast_pairs(pairs)
    _require_window_target_count(runtime, window, score)
    theta_tensor = torch.as_tensor(
        theta, dtype=window.context.dtype, device=window.context.device
    )
    no_warmup = runtime.tukf06_module.multilead_objective(
        window.context,
        window.forcing,
        window.observations,
        theta_tensor,
        False,
        runtime.tukf06_contract,
    )
    no_warmup_pairs = forecast_pairs(
        window.observations,
        forecasts,
        issue_start=0,
        issue_end=len(window.observations) - max(LEADS),
        leads=runtime.contract.leads,
    )
    no_warmup_score = score_forecast_pairs(no_warmup_pairs)
    no_warmup_value = float(no_warmup.detach().cpu())
    if not math.isclose(
        no_warmup_value,
        no_warmup_score.objective,
        rel_tol=0.0,
        abs_tol=1e-12,
    ):
        raise RuntimeError("TUKF06 no-warmup objective differs from explicit forecast pairs")
    return replace(
        score,
        full_objective_without_warmup=no_warmup_value,
        full_target_count_by_lead_without_warmup=dict(
            no_warmup_score.target_count_by_lead
        ),
        metadata={
            "method": method,
            "theta_log": theta.tolist(),
            "selection_path": str(Path(selection_path).resolve()),
            "selection_validation_objective": float(
                selection[method]["selected"]["validation_objective"]
            ),
            "initialization_mode": runtime.initialization_evidence.mode,
        },
    )


def _score_aligned_predictions(
    runtime: ParityRuntime,
    window: WindowBatch,
    predictions: Mapping[int, np.ndarray],
) -> tuple[ScoreSummary, ForecastPairs]:
    pairs = forecast_pairs(
        window.observations,
        predictions,
        issue_start=window.issue_start_local,
        issue_end=window.issue_end_local,
        leads=runtime.contract.leads,
    )
    score = score_forecast_pairs(pairs)
    _require_window_target_count(runtime, window, score)
    return score, pairs


def replay_zero_gain_open_loop(
    runtime: ParityRuntime,
    window: WindowBatch,
    *,
    seed: int = 20260824,
    hidden: int = 24,
    in_mult: int = 10,
    out_mult: int = 10,
    feature_scale_floor: float = 0.1,
    normalized_feature_guard: float | None = 10.0,
) -> ScoreSummary:
    """Prove that a zero-gain full-state KalmanNet is the shared open loop."""

    net = build_native_knet(
        runtime,
        zero_gain=True,
        gain_initialization=NATIVE_DEFAULT_GAIN_INITIALIZATION,
        seed=seed,
        hidden=hidden,
        in_mult=in_mult,
        out_mult=out_mult,
        feature_scale_floor=feature_scale_floor,
        normalized_feature_guard=normalized_feature_guard,
    )
    net.eval()
    with torch.no_grad():
        trace = run_knet_filter(
            net,
            window,
            previous_observation=previous_observation_before_window(runtime, window),
        )
        predictions = aligned_forecasts_from_posterior(
            runtime, window, trace.posterior_states
        )
        open_loop = runtime.tukf06_module.open_loop_prediction(
            window.context, window.forcing
        )
    score, _ = _score_aligned_predictions(runtime, window, predictions)
    no_warmup_pairs = forecast_pairs(
        window.observations,
        predictions,
        issue_start=0,
        issue_end=len(window.observations) - max(LEADS),
        leads=runtime.contract.leads,
    )
    no_warmup = physical_multilead_mse(no_warmup_pairs)
    no_warmup_score = score_forecast_pairs(no_warmup_pairs)
    differences: list[float] = []
    for lead in LEADS:
        target_indices = np.arange(
            lead, len(window.observations) - max(LEADS) + lead, dtype=np.int64
        )
        differences.extend(
            np.abs(predictions[lead][target_indices] - open_loop[target_indices]).tolist()
        )
    maximum_difference = float(np.max(differences)) if differences else 0.0
    if maximum_difference != 0.0:
        raise RuntimeError(
            "zero-gain KalmanNet does not reproduce the shared HBV open loop exactly"
        )
    return replace(
        score,
        full_objective_without_warmup=no_warmup,
        full_target_count_by_lead_without_warmup=dict(
            no_warmup_score.target_count_by_lead
        ),
        posterior_states=trace.posterior_states.detach().cpu().numpy(),
        open_loop=open_loop,
        maximum_open_loop_difference=maximum_difference,
        metadata={
            "zero_gain": True,
            "state_dimension": runtime.context.dimension,
            "initialization_mode": runtime.initialization_evidence.mode,
        },
    )


def evaluate_knet(
    net: NativeHBVFullStateKalmanNet,
    runtime: ParityRuntime,
    window: WindowBatch,
) -> ScoreSummary:
    """Evaluate a checkpoint with the same fixed geometry and physical score."""

    net.eval()
    with torch.no_grad():
        trace = run_knet_filter(
            net,
            window,
            previous_observation=previous_observation_before_window(runtime, window),
        )
        predictions = aligned_forecasts_from_posterior(
            runtime, window, trace.posterior_states
        )
    score, _ = _score_aligned_predictions(runtime, window, predictions)
    no_warmup_pairs = forecast_pairs(
        window.observations,
        predictions,
        issue_start=0,
        issue_end=len(window.observations) - max(LEADS),
        leads=runtime.contract.leads,
    )
    no_warmup_score = score_forecast_pairs(no_warmup_pairs)
    return replace(
        score,
        full_objective_without_warmup=no_warmup_score.objective,
        full_target_count_by_lead_without_warmup=dict(
            no_warmup_score.target_count_by_lead
        ),
        posterior_states=trace.posterior_states.detach().cpu().numpy(),
        metadata={
            "zero_gain": False,
            "state_dimension": runtime.context.dimension,
            "initialization_mode": runtime.initialization_evidence.mode,
        },
    )


def _physical_state_before_segment(
    runtime: ParityRuntime,
    open_loop_states: torch.Tensor,
    start: int,
) -> torch.Tensor:
    if not 0 <= int(start) < runtime.training_days:
        raise ValueError("training segment start is outside the training period")
    if int(start) == 0:
        return runtime.context.initial_state.clone()
    return open_loop_states[int(start) - 1].clone()


def segment_multilead_mse(
    net: NativeHBVFullStateKalmanNet,
    runtime: ParityRuntime,
    *,
    start: int,
    segment_days: int,
    filter_warmup_days: int,
    open_loop_states: torch.Tensor | None = None,
) -> SegmentLoss:
    """Compute differentiable 1--3 day physical-unit MSE on one segment."""

    start = int(start)
    segment_days = int(segment_days)
    warmup = int(filter_warmup_days)
    end = start + segment_days
    if segment_days <= warmup + max(LEADS):
        raise ValueError("training segment is too short after filter warm-up")
    if not 0 <= start < end <= runtime.training_days:
        raise ValueError("training segment extends beyond the pre-validation period")
    if open_loop_states is None:
        open_loop_states = training_open_loop_states(runtime)
    expected_shape = (
        runtime.training_days,
        1,
        runtime.context.dimension,
    )
    if tuple(open_loop_states.shape) != expected_shape:
        raise ValueError("training open-loop state cache has the wrong shape")
    initial = _physical_state_before_segment(runtime, open_loop_states, start)
    segment_context = _context_with_initial_state(runtime.context, initial)
    window = WindowBatch(
        purpose="training_segment",
        global_start=start,
        global_end_exclusive=end,
        context=segment_context,
        forcing=runtime.forcing[start:end],
        observations=runtime.observations[start:end],
        dates=runtime.dates[start:end],
        initial_state=initial,
        issue_start_local=warmup,
        issue_end_local=segment_days - max(LEADS),
    )
    previous = previous_observation_before_window(runtime, window)
    trace = run_knet_filter(net, window, previous_observation=previous)
    raw = runtime.tukf06_module.multilead_torch(
        window.context.plain_model,
        trace.posterior_states[:, 0, :],
        window.forcing,
    )
    losses: dict[int, torch.Tensor] = {}
    counts: dict[int, int] = {}
    for lead in LEADS:
        forecast, indices = raw[lead]
        forecast = forecast[warmup : window.issue_end_local]
        target_indices = indices[warmup : window.issue_end_local]
        target = window.observations[target_indices, 0]
        if not bool(torch.isfinite(forecast).all()):
            raise FloatingPointError(
                f"training segment contains a non-finite lead-{lead} forecast"
            )
        finite = torch.isfinite(target)
        counts[lead] = int(finite.sum().detach().cpu())
        if counts[lead] < 1:
            raise ValueError(f"training segment has no finite lead-{lead} target")
        losses[lead] = torch.mean((forecast[finite] - target[finite]).square())
    objective = torch.stack([losses[lead] for lead in LEADS]).mean()
    if not bool(torch.isfinite(objective)):
        raise FloatingPointError("training segment objective is non-finite")
    return SegmentLoss(
        objective=objective,
        mse_by_lead=losses,
        target_count_by_lead=counts,
    )


def parameter_sha256(net: torch.nn.Module) -> str:
    """Hash trainable parameters only, excluding adaptation buffers."""

    digest = sha256()
    for name, parameter in sorted(net.named_parameters()):
        array = parameter.detach().cpu().contiguous().numpy()
        digest.update(name.encode("utf-8"))
        digest.update(str(array.dtype).encode("ascii"))
        digest.update(np.asarray(array.shape, dtype=np.int64).tobytes())
        digest.update(array.tobytes())
    return digest.hexdigest()


def train_short_knet(
    runtime: ParityRuntime,
    *,
    gain_initialization: str,
    epochs: int = 20,
    steps_per_epoch: int = 32,
    segment_days: int = 150,
    segment_filter_warmup_days: int = 45,
    learning_rate: float = 0.01,
    weight_decay: float = 0.0,
    gradient_maximum_norm: float = 10.0,
    seed: int = 20260824,
    validation_purpose: str = "recovery",
    hidden: int = 24,
    in_mult: int = 10,
    out_mult: int = 10,
    feature_scale_floor: float = 0.1,
    normalized_feature_guard: float | None = 10.0,
) -> TrainingResult:
    """Run causal development-only optimization with a frozen epoch-zero record.

    Checkpoints use all 728 issue times in the original TUKF06 physical-unit
    objective.  The common 16-day warm-up geometry (712 issue times) is kept
    separate and is used only for per-lead performance reporting and gates.
    """

    if (
        runtime.initialization_evidence.mode
        != runtime.contract.scientific_initialization_mode
        or not runtime.initialization_evidence.scientific_claim_allowed
    ):
        raise PermissionError(
            "KalmanNet training requires causal_shared_spinup; the exact TUKF06 "
            "backward-time initialization is replay-only"
        )
    if validation_purpose != "recovery":
        raise ValueError("KalmanNet checkpoint selection requires the 731-day recovery window")
    if int(epochs) < 1 or int(steps_per_epoch) < 1:
        raise ValueError("training requires at least one epoch and optimizer step")
    if not math.isfinite(float(learning_rate)) or float(learning_rate) <= 0.0:
        raise ValueError("learning rate must be finite and positive")
    if not math.isfinite(float(gradient_maximum_norm)) or float(
        gradient_maximum_norm
    ) <= 0.0:
        raise ValueError("gradient norm cap must be finite and positive")
    maximum_start = runtime.training_days - int(segment_days)
    if maximum_start < 0:
        raise ValueError("training segment is longer than the training period")

    net = build_native_knet(
        runtime,
        zero_gain=False,
        gain_initialization=gain_initialization,
        seed=seed,
        hidden=hidden,
        in_mult=in_mult,
        out_mult=out_mult,
        feature_scale_floor=feature_scale_floor,
        normalized_feature_guard=normalized_feature_guard,
    )
    optimizer = torch.optim.Adam(
        net.parameters(),
        lr=float(learning_rate),
        weight_decay=float(weight_decay),
    )
    validation_window = select_window(runtime, validation_purpose)
    open_loop_states = training_open_loop_states(runtime)
    generator = torch.Generator(device="cpu")
    generator.manual_seed(int(seed))

    epoch_zero = evaluate_knet(net, runtime, validation_window)
    if epoch_zero.full_objective_without_warmup is None:
        raise RuntimeError("epoch-zero checkpoint objective is absent")
    if epoch_zero.full_target_count_by_lead_without_warmup != {
        lead: len(validation_window.observations) - max(LEADS) for lead in LEADS
    }:
        raise RuntimeError("epoch-zero checkpoint objective must retain 728 targets per lead")
    epoch_zero_checkpoint = float(epoch_zero.full_objective_without_warmup)
    initial_hash = parameter_sha256(net)
    history: list[EpochRecord] = [
        EpochRecord(
            epoch=0,
            training_objective=None,
            checkpoint_objective_without_warmup=epoch_zero_checkpoint,
            gate_objective_after_warmup=epoch_zero.objective,
            nse_by_lead=dict(epoch_zero.nse_by_lead),
            target_count_by_lead=dict(epoch_zero.target_count_by_lead),
            parameter_sha256=initial_hash,
            optimizer_steps=0,
            nonzero_gradient_tensors=0,
            parameter_tensors_with_gradients=0,
        )
    ]
    best_epoch = 0
    best_checkpoint_objective = epoch_zero_checkpoint
    best_hash = initial_hash
    best_state = copy.deepcopy(net.state_dict())
    optimizer_steps = 0

    for epoch in range(1, int(epochs) + 1):
        net.train()
        training_values: list[float] = []
        nonzero_gradient_tensors = 0
        parameter_tensors_with_gradients = 0
        for _ in range(int(steps_per_epoch)):
            start = int(
                torch.randint(
                    0,
                    maximum_start + 1,
                    (1,),
                    generator=generator,
                    device="cpu",
                ).item()
            )
            optimizer.zero_grad(set_to_none=True)
            segment = segment_multilead_mse(
                net,
                runtime,
                start=start,
                segment_days=segment_days,
                filter_warmup_days=segment_filter_warmup_days,
                open_loop_states=open_loop_states,
            )
            segment.objective.backward()
            current_with_gradients = 0
            current_nonzero = 0
            for parameter in net.parameters():
                if parameter.grad is not None:
                    current_with_gradients += 1
                    if not bool(torch.isfinite(parameter.grad).all()):
                        raise FloatingPointError("KalmanNet gradient is non-finite")
                    if bool(torch.count_nonzero(parameter.grad)):
                        current_nonzero += 1
            parameter_tensors_with_gradients = max(
                parameter_tensors_with_gradients, current_with_gradients
            )
            nonzero_gradient_tensors = max(
                nonzero_gradient_tensors, current_nonzero
            )
            torch.nn.utils.clip_grad_norm_(
                net.parameters(), float(gradient_maximum_norm), error_if_nonfinite=True
            )
            optimizer.step()
            optimizer_steps += 1
            training_values.append(float(segment.objective.detach().cpu()))

        validation = evaluate_knet(net, runtime, validation_window)
        if validation.full_objective_without_warmup is None:
            raise RuntimeError("checkpoint objective is absent")
        if validation.full_target_count_by_lead_without_warmup != {
            lead: len(validation_window.observations) - max(LEADS) for lead in LEADS
        }:
            raise RuntimeError("checkpoint objective must retain 728 targets per lead")
        checkpoint_objective = float(validation.full_objective_without_warmup)
        current_hash = parameter_sha256(net)
        record = EpochRecord(
            epoch=epoch,
            training_objective=float(np.mean(training_values)),
            checkpoint_objective_without_warmup=checkpoint_objective,
            gate_objective_after_warmup=validation.objective,
            nse_by_lead=dict(validation.nse_by_lead),
            target_count_by_lead=dict(validation.target_count_by_lead),
            parameter_sha256=current_hash,
            optimizer_steps=optimizer_steps,
            nonzero_gradient_tensors=nonzero_gradient_tensors,
            parameter_tensors_with_gradients=parameter_tensors_with_gradients,
        )
        history.append(record)
        if checkpoint_objective < best_checkpoint_objective:
            best_epoch = epoch
            best_checkpoint_objective = checkpoint_objective
            best_hash = current_hash
            best_state = copy.deepcopy(net.state_dict())

    last_hash = parameter_sha256(net)
    net.load_state_dict(best_state)
    return TrainingResult(
        net=net,
        history=tuple(history),
        epoch_zero_checkpoint_objective=epoch_zero_checkpoint,
        best_epoch=best_epoch,
        best_checkpoint_objective=best_checkpoint_objective,
        best_parameter_sha256=best_hash,
        last_parameter_sha256=last_hash,
        optimizer_steps=optimizer_steps,
        best_state_dict=best_state,
    )


__all__ = [
    "DEFAULT_ARCHIVE",
    "DEFAULT_SELECTION",
    "EpochRecord",
    "FeatureScales",
    "ForecastPairs",
    "KNetTrace",
    "ParityRuntime",
    "ScoreSummary",
    "SegmentLoss",
    "TrainingResult",
    "WindowBatch",
    "aligned_forecasts_from_posterior",
    "apply_gain_initialization",
    "assert_identical_forecast_geometry",
    "build_native_knet",
    "evaluate_knet",
    "fit_training_feature_scales",
    "forecast_pairs",
    "full_state_correction_mask",
    "load_archive_context",
    "parameter_sha256",
    "physical_multilead_mse",
    "previous_observation_before_window",
    "replay_tukf06_ukf",
    "replay_zero_gain_open_loop",
    "run_knet_filter",
    "score_forecast_pairs",
    "segment_multilead_mse",
    "select_window",
    "train_short_knet",
    "training_open_loop_states",
]
