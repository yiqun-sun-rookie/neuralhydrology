# Daily CAMELS Native Full-State KalmanNet A20-Contract Smoke Plan

> **Execution rule:** Implement and execute only this daily development smoke. Hourly work and reserved evaluation data remain untouched.

**Goal:** Test whether changing only the learned correction scope from the five HBV storages to the complete common 18-dimensional routed HBV state repairs the two-basin daily KalmanNet route under the exact A20 loss, dates, basins, initialization behavior, validation window, seed, and event budget.

**Architecture:** Keep the A20 equal-basin training engine, physical loss implementation, atomic checkpoint format, owner lock, and access ledger. Add a narrow full-state data/filter strategy that pads both basins to the maximum active routing lag of 13 days, uses the repository-native KalmanNet core at state dimension 18, and preserves A20's actual near-zero gain-head initialization. Use a new immutable experiment identity and output root. Save a validation prediction artifact for every epoch so all post-zero claims can be independently recomputed.

**Experiment identity:** `DAILY_CAMELS_NATIVE_KALMANNET_FULL_STATE_MASKED_NSE_SMOKE_V1_20260825_A34`

## Frozen scientific contract

- Cadence: daily only.
- Development data: 1999-10-01 through 2008-09-30 only.
- Training observations used for loss scales: indices `[0, 2557)` only.
- Validation: the first 128 days beginning 2006-10-01; 16 filter warm-up days; 109 issue times for each of the 1-, 2-, and 3-day leads.
- Basins and order: `04105700`, `09035800`.
- Input archive SHA-256 values: retain the exact A20 hashes.
- Forecast information: discharge through the issue day and meteorological forcing through the target day; no future discharge.
- Loss:

  \[
  L=\frac{1}{2}\sum_b\frac{1}{3}\sum_{h=1}^{3}
  \operatorname{mean}_i\left[
  \frac{(\hat Q_{bhi}-Q_{bhi})^2}{(\sigma_{b,\mathrm{train}}+0.1)^2}
  \right].
  \]

- Weighting: exact equal basins within every optimizer step, exact equal leads, equal finite events within a basin-lead cell.
- Training budget: seed `20260825`, 4 epochs, 2 optimizer steps per epoch, 64-day segments, 16-day filter warm-up, 45 targets per basin and lead per step, 2,160 forecast-error events total.
- Optimizer: Adam, learning rate `0.0005`, weight decay `0.00001`, maximum gradient norm `10.0`.
- Network: repository-native `knet/dl/nn_kalman_clamp_5.py`, hidden dimension 32, input/output multipliers 10, float32 physical and network tensors.
- Initialization: match A20's actual code, not its misleading label: multiply the final gain-head weight by `0.01` and set its bias to zero. Also save a separate strict-zero-gain open-loop control. Do not use the strict-zero control as epoch zero.
- Feature scales: retain A20's training-only `1.2 * maximum absolute adjacent difference`, with the same floors and observation/state unit conversion.
- State bounds: retain A20's training-only two-times storage upper bounds and soil field-capacity bound; padded inactive routing channels remain exactly zero; active routing channels are nonnegative and may be corrected.
- Single changed scientific factor: correction authority and gain output dimension change from five storages to all 18 common active/padded state coordinates. No official-upstream GRU backend, 21-basin population, continuous 731-day selector, or variance-only denominator is admitted.
- Formal evaluation is disabled. Reserved evaluation arrays, predictions, metrics, and outputs must all have access count zero.

## Required gates

Technical evidence requires:

1. epoch checkpoints `000` through `004`, saved atomically with a complete predecessor hash chain and resumable optimizer/random states;
2. a saved validation-prediction artifact bound to every epoch checkpoint;
3. 8 successful optimizer steps, 2,160 forecast-error events, finite gradients, and nonzero gradients for every trainable tensor group;
4. a selected epoch greater than zero and a lower exact frozen validation loss than epoch zero;
5. lower loss for each basin and lower physical mean squared error for all six basin-lead cells than epoch zero;
6. all six selected physical mean squared errors lower than the corresponding A20 epoch-four values;
7. strict-zero control predictions equal the routed HBV open loop within the declared numerical tolerance;
8. zero hourly or reserved-evaluation payload files, zero reads of the five embedded historical/prior-state archive members, and zero evaluation access counters. The two A20-hash-identical input archives retain those five unused members so that input identity and the one-factor comparison are not changed.

Passing these gates authorizes only a larger daily development experiment. It is not a large-sample or formal-evaluation result. Failure of either item 5 or 6 closes the shared full-state recovery branch under this budget.

## Implementation tasks

### Task 1: Freeze the new contract and regression tests

**Files:**

- Create `configs/daily_camels_native_kalmannet_full_state_masked_nse_smoke_v1.json`.
- Create `src/global_hydrology/experiments/daily_camels_native_knet_full_state_masked_nse_contract.py`.
- Create `tests/test_daily_camels_native_knet_full_state_masked_nse_contract.py`.

- [ ] Reject any cadence, basin, hash, date, lead, loss denominator, initialization scale, state dimension, optimizer budget, or evaluation-access drift.
- [ ] Record the exact A20 cell-level reference values used by gate 6 with their source artifact hash.
- [ ] Test that `sigma^2` and `(sigma + 0.1)^2` are distinguishable and only the latter is admitted.

### Task 2: Add a full-state strategy without changing A20 defaults

**Files:**

- Create `src/global_hydrology/experiments/daily_camels_native_knet_full_state_masked_nse_data.py`.
- Create `src/global_hydrology/experiments/daily_camels_native_knet_full_state_masked_nse_training.py`.
- Create `tests/test_daily_camels_native_knet_full_state_masked_nse_training.py`.

- [ ] Pad both routed systems to dimension 18 while preserving each basin's active lag and zero inactive tail.
- [ ] Fit every normalization scale and bound from training data only.
- [ ] Prove that all 18 output coordinates have correction authority only where physically active.
- [ ] Prove exact equal-basin/equal-lead loss construction and 45 targets per cell per step.
- [ ] Prove the near-zero `0.01` initialization differs from and coexists with the strict-zero open-loop control.
- [ ] Import the frozen A20 loss/batch/result helpers where their interfaces are state-agnostic, but keep the historical A20 source file byte-identical.
- [ ] Preserve A20's effective-upper-bound projection for the first five stores; constrain active routing slots only to nonnegative values and keep the inactive padded tail exactly zero.

### Task 3: Build a unique resumable entry and independent verifier

**Files:**

- Create `scripts/run_daily_camels_native_kalmannet_full_state_masked_nse.py`.
- Create `hpc/daily_camels_native_kalmannet_full_state_masked_nse/preflight.py`.
- Create `hpc/daily_camels_native_kalmannet_full_state_masked_nse/verify_result.py`.
- Create `tests/test_daily_camels_native_knet_full_state_result_verifier.py`.

- [ ] Refuse an existing output directory or active owner lock; resume only from an explicitly named, identity-matched, complete epoch unit.
- [ ] Persist the checkpoint and its validation predictions atomically and bind both hashes in the event ledger.
- [ ] Select only by the exact frozen shared validation loss; do not combine efficiency gain with degraded-basin fraction.
- [ ] Independently reload every epoch checkpoint, regenerate predictions, and recompute loss, physical mean squared error, Nash-Sutcliffe efficiency, persistence, second-order autoregression, and the same-window unscented Kalman filter comparison when an already-frozen comparison artifact is available.
- [ ] Fail closed on epoch zero selection, any missing cell improvement, any failure against A20, any hash/target-count mismatch, or any forbidden access.

### Task 4: Package and execute on the supercomputer

**Files:**

- Create `scripts/build_daily_camels_native_kalmannet_full_state_masked_nse_hpc_bundle.py`.
- Create `hpc/daily_camels_native_kalmannet_full_state_masked_nse/submit_smoke_gpu.slurm`.
- Create `tests/test_daily_camels_native_knet_full_state_hpc_bundle.py`.

- [ ] Build twice and require byte-identical deterministic archives and manifests.
- [ ] Package only the two daily calibration/development archives and the exact source closure; member names containing hourly or reserved evaluation evidence are forbidden.
- [ ] Use a new remote root and one top-level scheduled entry with an owner lock and existing-directory refusal.
- [ ] Admit the initial smoke using headroom derived from measured A20/A33 peaks, then record A34's own host and graphics-memory peaks for any future run.
- [ ] Run all numerical tests and the two-basin training on the supercomputer; do not start local training while the protected formal unscented Kalman filter processes are active.

### Task 5: Classify the result

- [ ] Recover evidence only after the scheduler reaches a terminal state.
- [ ] Verify archive, config, source, data, checkpoint chain, per-epoch predictions, progress counters, resource peaks, and access ledger independently.
- [ ] Report technical success separately from model ability and large-sample readiness.
- [ ] Give exactly one next action: proceed to a larger daily development run only if every required gate passes; otherwise close this shared full-state recovery branch under the frozen budget.
