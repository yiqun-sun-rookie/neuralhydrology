"""Scheduled-node bundle, isolation, identity, and resource admission for A34."""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from typing import Any, Mapping, Sequence
import zipfile


EXPERIMENT_ID = (
    "DAILY_CAMELS_NATIVE_KALMANNET_FULL_STATE_MASKED_NSE_SMOKE_V1_20260825_A34"
)
MINIMUM_FREE_HOST_MEMORY_BYTES = 5_734_154_240
MINIMUM_FREE_CUDA_MEMORY_BYTES = 738_197_504
FORBIDDEN_MEMBER_TOKENS = (
    "hourly",
    "reserved_evaluation",
    "evaluation_input",
    "evaluation_data",
    "future_state",
    "initial_state",
    "initial_storage_state",
    "initial_covariance",
)
EXPECTED_NPZ_MEMBERS = (
    "dates_ns",
    "forcing",
    "observations",
    "parameters",
    "initial_storage_state",
    "initial_state",
    "initial_covariance",
    "base_observation_variance",
    "state_dimension",
)


def canonical_json_bytes(value: object) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
        + b"\n"
    )


def sha256_file(path: Path) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _json(path: Path) -> Mapping[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, Mapping):
        raise TypeError(f"JSON document is not an object: {path}")
    return value


def _npz_member_names(path: Path) -> tuple[str, ...]:
    with zipfile.ZipFile(path, "r") as archive:
        filenames = tuple(info.filename for info in archive.infolist() if not info.is_dir())
    if len(filenames) != len(set(filenames)) or any(
        "/" in name or "\\" in name or not name.endswith(".npy") for name in filenames
    ):
        raise ValueError("NPZ archive member names are unsafe or duplicated")
    return tuple(name[:-4] for name in filenames)


def free_host_memory_bytes() -> int:
    try:
        import psutil

        return int(psutil.virtual_memory().available)
    except ImportError:
        page_size = int(os.sysconf("SC_PAGE_SIZE"))
        available_pages = int(os.sysconf("SC_AVPHYS_PAGES"))
        return page_size * available_pages


def visible_cuda_device_id() -> str:
    value = os.environ.get("CUDA_VISIBLE_DEVICES", "").strip()
    devices = [item.strip() for item in value.split(",") if item.strip()]
    if len(devices) != 1 or devices[0] in {"-1", "NoDevFiles"}:
        raise RuntimeError("A34 requires exactly one scheduler-visible CUDA device")
    return devices[0]


def free_cuda_memory_bytes(device_id: str) -> int:
    completed = subprocess.run(
        [
            "nvidia-smi",
            "--id",
            str(device_id),
            "--query-gpu=memory.free",
            "--format=csv,noheader,nounits",
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    rows = [line.strip() for line in completed.stdout.splitlines() if line.strip()]
    if len(rows) != 1:
        raise RuntimeError("scheduled CUDA device query did not return exactly one row")
    return int(rows[0]) * 1024 * 1024


def verify_bundle(bundle_root: Path) -> Mapping[str, Any]:
    bundle_root = Path(bundle_root).resolve(strict=True)
    manifest = _json(bundle_root / "bundle_manifest.json")
    if manifest.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("bundle experiment identity changed")
    files = manifest.get("files")
    if not isinstance(files, Mapping) or int(manifest.get("file_count", -1)) != len(files):
        raise ValueError("bundle file count changed")
    actual_files: set[str] = set()
    for path in bundle_root.rglob("*"):
        relative_path = path.relative_to(bundle_root)
        if path.is_symlink():
            raise ValueError(f"symbolic links are forbidden in the bundle: {relative_path}")
        if path.is_file() and path.name != "bundle_manifest.json":
            actual_files.add(relative_path.as_posix())
    if set(str(relative) for relative in files) != actual_files:
        raise ValueError("bundle manifest does not equal the complete bundle file closure")
    forbidden: list[str] = []
    for relative, record in files.items():
        normalized = str(relative).replace("\\", "/").lower()
        if any(token in normalized for token in FORBIDDEN_MEMBER_TOKENS):
            forbidden.append(str(relative))
        path = bundle_root / str(relative)
        try:
            path.resolve(strict=True).relative_to(bundle_root)
        except ValueError as exc:
            raise ValueError(f"bundle member escapes the bundle root: {relative}") from exc
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(f"bundle member is absent: {relative}")
        if sha256_file(path) != str(record["sha256"]):
            raise ValueError(f"bundle member hash changed: {relative}")
        if path.stat().st_size != int(record["size_bytes"]):
            raise ValueError(f"bundle member size changed: {relative}")
    if forbidden:
        raise PermissionError(f"forbidden bundle members: {forbidden}")
    input_members = sorted(
        relative for relative in files if str(relative).startswith("inputs/")
    )
    if input_members != ["inputs/basin_04105700.npz", "inputs/basin_09035800.npz"]:
        raise ValueError("bundle must contain exactly the two daily development inputs")
    for relative in input_members:
        if _npz_member_names(bundle_root / relative) != EXPECTED_NPZ_MEMBERS:
            raise ValueError(f"frozen NPZ member closure changed: {relative}")
    return manifest


def preflight(
    bundle_root: Path, run_root: Path, resume_checkpoint: Path | None = None
) -> Mapping[str, Any]:
    bundle_root = Path(bundle_root).resolve(strict=True)
    run_root = Path(run_root).resolve(strict=False)
    manifest = verify_bundle(bundle_root)
    run_directory = run_root / EXPERIMENT_ID
    if resume_checkpoint is None:
        if run_directory.exists():
            raise FileExistsError(f"A34 run directory already exists: {run_directory}")
        run_directory_previously_absent = True
    else:
        if not run_directory.is_dir() or run_directory.is_symlink():
            raise FileNotFoundError("resume A34 run directory is absent or symbolic")
        run_directory = run_directory.resolve(strict=True)
        checkpoint = Path(resume_checkpoint).resolve(strict=True)
        try:
            relative_checkpoint = checkpoint.relative_to(run_directory / "epoch_units")
        except ValueError as exc:
            raise ValueError("resume checkpoint is outside the A34 epoch units") from exc
        if (
            len(relative_checkpoint.parts) != 2
            or relative_checkpoint.name != "checkpoint.pt"
            or not (checkpoint.parent / "unit_complete.json").is_file()
        ):
            raise ValueError("resume requires one complete epoch_NNN/checkpoint.pt")
        if (run_directory / ".owner.lock").exists():
            raise FileExistsError("A34 Python owner lock still exists; global audit is required")
        if (run_directory / "completion.marker.json").exists():
            raise FileExistsError("completed A34 run cannot resume")
        run_directory_previously_absent = False
    host_free = free_host_memory_bytes()
    cuda_device_id = visible_cuda_device_id()
    cuda_free = free_cuda_memory_bytes(cuda_device_id)
    if host_free < MINIMUM_FREE_HOST_MEMORY_BYTES:
        raise MemoryError(
            f"host admission failed: {host_free} < {MINIMUM_FREE_HOST_MEMORY_BYTES}"
        )
    if cuda_free < MINIMUM_FREE_CUDA_MEMORY_BYTES:
        raise MemoryError(
            f"CUDA admission failed: {cuda_free} < {MINIMUM_FREE_CUDA_MEMORY_BYTES}"
        )
    return {
        "status": "BUNDLE_AND_RESOURCE_ADMISSION_VERIFIED",
        "experiment_id": EXPERIMENT_ID,
        "bundle_root": str(bundle_root),
        "bundle_file_count": int(manifest["file_count"]),
        "run_directory": str(run_directory),
        "run_directory_previously_absent": run_directory_previously_absent,
        "resume_checkpoint": str(resume_checkpoint) if resume_checkpoint else None,
        "host_free_memory_bytes": host_free,
        "minimum_host_free_memory_bytes": MINIMUM_FREE_HOST_MEMORY_BYTES,
        "cuda_free_memory_bytes": cuda_free,
        "scheduler_visible_cuda_device_id": cuda_device_id,
        "minimum_cuda_free_memory_bytes": MINIMUM_FREE_CUDA_MEMORY_BYTES,
        "resource_threshold_provenance": {
            "host": "four_times_A33_measured_process_peak_1433538560_bytes",
            "cuda": "four_times_A32_measured_reserved_peak_184549376_bytes",
            "future_runs_must_use_fresh_A34_peak": True,
        },
        "daily_input_member_count": 2,
        "hourly_member_count": 0,
        "reserved_evaluation_member_count": 0,
        "forbidden_bundle_path_member_count": 0,
        "embedded_prior_state_arrays_are_present_in_the_frozen_npz_but_forbidden_from_materialization": True,
        "formal_evaluation_enabled": False,
    }


def atomic_write(path: Path, content: bytes) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_name, path)
    finally:
        if os.path.exists(temporary_name):
            os.unlink(temporary_name)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="A34 scheduled-node preflight")
    parser.add_argument("--bundle-root", type=Path, required=True)
    parser.add_argument("--run-root", type=Path, required=True)
    parser.add_argument("--resume-checkpoint", type=Path, default=None)
    parser.add_argument("--output", type=Path, required=True)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    arguments = build_parser().parse_args(argv)
    try:
        report = preflight(
            arguments.bundle_root, arguments.run_root, arguments.resume_checkpoint
        )
        atomic_write(arguments.output, canonical_json_bytes(report))
        print(canonical_json_bytes(report).decode("utf-8"), end="")
        return 0
    except Exception as exc:
        report = {
            "status": "HARD_STOP",
            "error_type": type(exc).__name__,
            "message": str(exc),
        }
        atomic_write(arguments.output, canonical_json_bytes(report))
        print(canonical_json_bytes(report).decode("utf-8"), file=sys.stderr, end="")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
