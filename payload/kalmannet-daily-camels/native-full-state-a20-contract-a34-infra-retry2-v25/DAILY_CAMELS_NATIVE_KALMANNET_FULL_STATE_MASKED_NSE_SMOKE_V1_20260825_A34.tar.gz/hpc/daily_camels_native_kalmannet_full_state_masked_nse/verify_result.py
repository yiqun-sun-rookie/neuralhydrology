"""Independent result and raw-prediction verifier for the A34 daily smoke."""

from __future__ import annotations

import argparse
from dataclasses import asdict
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import sys
import tempfile
from typing import Any, Mapping, Sequence
import zipfile

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "src"
for _path in (ROOT, SRC):
    if str(_path) not in sys.path:
        sys.path.insert(0, str(_path))

from global_hydrology.experiments.daily_camels_masked_nse_loss_contract import (  # noqa: E402
    fit_shared_training_discharge_scales,
    training_scale_evidence_sha256,
)
from global_hydrology.experiments.daily_camels_native_knet_full_state_masked_nse_contract import (  # noqa: E402
    A20_PHYSICAL_MSE,
    A20_RESULT_PATH,
    A20_RESULT_SHA256,
    AccessLedger,
    BASIN_IDS,
    DailyFullStateKNetContract,
    EXPERIMENT_ID,
    INPUT_SHA256,
    a20_training_unit_geometry,
    validate_a20_reference_summary,
    validate_exact_configuration,
)
from global_hydrology.experiments.daily_camels_native_knet_full_state_masked_nse_data import (  # noqa: E402
    load_daily_selection_archive,
    prepare_full_state_daily_basin,
)
from global_hydrology.experiments.daily_camels_native_knet_full_state_masked_nse_training import (  # noqa: E402
    build_a20_full_state_network,
    full_state_validation_artifact,
)
from global_hydrology.experiments.daily_camels_native_knet_io import (  # noqa: E402
    RunIdentity,
    load_resume_checkpoint,
)


EXPECTED_ARRAY_KEYS = {
    "basin_ids",
    "leads_days",
    "origin_indices",
    "prediction",
    "target",
    "open_loop",
    "persistence",
    "ar2",
}


def canonical_json_bytes(value: object) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
        + b"\n"
    )


def sha256_file(path: Path) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _npz_member_names(path: Path) -> tuple[str, ...]:
    with zipfile.ZipFile(path, "r") as archive:
        filenames = tuple(info.filename for info in archive.infolist() if not info.is_dir())
    if len(filenames) != len(set(filenames)) or any(
        "/" in name or "\\" in name or not name.endswith(".npy") for name in filenames
    ):
        raise ValueError("NPZ archive member names are unsafe or duplicated")
    return tuple(name[:-4] for name in filenames)


def _json(path: Path) -> Mapping[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, Mapping):
        raise TypeError(f"JSON document is not an object: {path}")
    return value


def _close(actual: float, expected: float, label: str, tolerance: float = 2.0e-6) -> None:
    if not math.isfinite(float(actual)) or not math.isclose(
        float(actual), float(expected), rel_tol=0.0, abs_tol=tolerance
    ):
        raise ValueError(f"{label} differs: {actual!r} versus {expected!r}")


def _state_sha256(state: Mapping[str, torch.Tensor]) -> str:
    digest = sha256()
    for name, tensor in sorted(state.items()):
        array = tensor.detach().cpu().contiguous().numpy()
        digest.update(name.encode("utf-8"))
        digest.update(str(array.dtype).encode("ascii"))
        digest.update(np.asarray(array.shape, dtype=np.int64).tobytes())
        digest.update(array.tobytes())
    return digest.hexdigest()


def _json_normalized(value: object) -> object:
    return json.loads(
        json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False)
    )


def _load_arrays(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as archive:
        if set(archive.files) != EXPECTED_ARRAY_KEYS:
            raise ValueError(f"validation array member set changed: {path}")
        arrays = {name: np.asarray(archive[name]).copy() for name in archive.files}
    if tuple(arrays["basin_ids"].tolist()) != BASIN_IDS:
        raise ValueError("validation basin order changed")
    if tuple(arrays["leads_days"].tolist()) != (1, 2, 3):
        raise ValueError("validation lead order changed")
    if arrays["origin_indices"].shape != (2, 109):
        raise ValueError("validation origin geometry changed")
    for name in ("prediction", "target", "open_loop", "persistence", "ar2"):
        if arrays[name].shape != (2, 3, 109) or not np.isfinite(arrays[name]).all():
            raise ValueError(f"validation array {name} is invalid")
    return arrays


def _independent_metrics(
    arrays: Mapping[str, np.ndarray], standard_deviations: Sequence[float]
) -> dict[str, Any]:
    error = np.asarray(arrays["prediction"], dtype=np.float64) - np.asarray(
        arrays["target"], dtype=np.float64
    )
    physical_mse = np.mean(error * error, axis=2)
    scales = np.asarray(standard_deviations, dtype=np.float64).reshape(2, 1)
    cell_loss = physical_mse / ((scales + 0.1) ** 2)

    def nse(target: np.ndarray, prediction: np.ndarray) -> float:
        denominator = float(np.mean((target - float(np.mean(target))) ** 2))
        if denominator <= 0.0:
            raise ValueError("validation target variance is not positive")
        return 1.0 - float(np.mean((prediction - target) ** 2)) / denominator

    method_nse: dict[str, dict[int, float]] = {}
    for basin_index, basin_id in enumerate(BASIN_IDS):
        method_nse[basin_id] = {
            lead: nse(
                arrays["target"][basin_index, lead - 1],
                arrays["prediction"][basin_index, lead - 1],
            )
            for lead in (1, 2, 3)
        }
    return {
        "shared_loss": float(np.mean(cell_loss)),
        "per_basin_loss": {
            basin_id: float(np.mean(cell_loss[index]))
            for index, basin_id in enumerate(BASIN_IDS)
        },
        "cell_loss": {
            basin_id: {lead: float(cell_loss[index, lead - 1]) for lead in (1, 2, 3)}
            for index, basin_id in enumerate(BASIN_IDS)
        },
        "physical_mse": {
            basin_id: {
                lead: float(physical_mse[index, lead - 1]) for lead in (1, 2, 3)
            }
            for index, basin_id in enumerate(BASIN_IDS)
        },
        "method_nse": method_nse,
    }


def _verify_manifest(run_directory: Path, completion: Mapping[str, Any] | None) -> int:
    manifest_path = run_directory / "manifest.sha256.json"
    manifest = _json(manifest_path)
    if manifest.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("result manifest experiment identity changed")
    files = manifest.get("files")
    if not isinstance(files, Mapping) or int(manifest.get("file_count", -1)) != len(files):
        raise ValueError("result manifest file count changed")
    actual_files: set[str] = set()
    for path in run_directory.rglob("*"):
        relative_path = path.relative_to(run_directory)
        if ".owner.lock" in relative_path.parts or path.name in {
            "manifest.sha256.json",
            "completion.marker.json",
        }:
            continue
        if path.is_symlink():
            raise ValueError(f"symbolic links are forbidden in results: {relative_path}")
        if path.is_file():
            actual_files.add(relative_path.as_posix())
    if set(str(relative) for relative in files) != actual_files:
        raise ValueError("result manifest does not equal the complete result file closure")
    for relative, record in files.items():
        path = run_directory / str(relative)
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(f"manifest member is absent: {relative}")
        if sha256_file(path) != str(record["sha256"]):
            raise ValueError(f"manifest member hash changed: {relative}")
        if path.stat().st_size != int(record["size_bytes"]):
            raise ValueError(f"manifest member size changed: {relative}")
    if completion is not None and completion.get("manifest_sha256") != sha256_file(manifest_path):
        raise ValueError("completion marker does not bind the result manifest")
    return len(files)


def _verify_completion_bindings(
    run_directory: Path,
    completion: Mapping[str, Any],
    *,
    selected_epoch: int,
    selected_checkpoint: Path,
    selected_predictions: Path,
) -> None:
    expected_completion_keys = {
        "schema_version",
        "experiment_id",
        "status",
        "manifest_sha256",
        "summary_sha256",
        "selected_epoch",
        "selected_checkpoint_sha256",
        "selected_validation_predictions_sha256",
    }
    if set(completion) != expected_completion_keys:
        raise ValueError("completion marker members changed")
    if (
        completion.get("schema_version")
        != "daily_camels_native_full_state_completion_v1"
        or completion.get("experiment_id") != EXPERIMENT_ID
        or completion.get("status") != "COMPLETED"
    ):
        raise ValueError("completion marker identity changed")
    if completion.get("summary_sha256") != sha256_file(
        run_directory / "result_summary.json"
    ):
        raise ValueError("completion marker summary hash changed")
    if int(completion.get("selected_epoch", -1)) != int(selected_epoch):
        raise ValueError("completion marker selected epoch changed")
    if completion.get("selected_checkpoint_sha256") != sha256_file(
        selected_checkpoint
    ):
        raise ValueError("completion marker selected checkpoint hash changed")
    if completion.get("selected_validation_predictions_sha256") != sha256_file(
        selected_predictions
    ):
        raise ValueError("completion marker selected predictions hash changed")


def verify(
    run_directory: Path,
    config_path: Path,
    inputs_root: Path,
    *,
    device_name: str,
) -> tuple[dict[str, Any], int]:
    run_directory = Path(run_directory).resolve(strict=True)
    config_path = Path(config_path).resolve(strict=True)
    inputs_root = Path(inputs_root).resolve(strict=True)
    config = _json(config_path)
    validate_exact_configuration(config)
    contract = DailyFullStateKNetContract.from_dict(config)
    reference_path = ROOT / A20_RESULT_PATH
    if sha256_file(reference_path) != A20_RESULT_SHA256:
        raise ValueError("A20 reference result hash changed")
    a20_summary = _json(reference_path)
    validate_a20_reference_summary(a20_summary)
    identity_document = _json(run_directory / "experiment_identity.json")
    if identity_document.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("run identity changed")
    if identity_document.get("configuration_sha256") != sha256_file(config_path):
        raise ValueError("run configuration hash changed")
    source_hashes = identity_document.get("source_sha256")
    if not isinstance(source_hashes, Mapping):
        raise TypeError("run source hashes are absent")
    for relative, expected in source_hashes.items():
        path = ROOT / str(relative)
        if sha256_file(path) != str(expected):
            raise ValueError(f"run source changed: {relative}")
    input_hashes = identity_document.get("input_archive_sha256")
    if not isinstance(input_hashes, Mapping) or tuple(input_hashes) != BASIN_IDS:
        raise ValueError("run input identity changed")
    input_paths = {
        basin_id: inputs_root / f"basin_{basin_id}.npz" for basin_id in BASIN_IDS
    }
    for basin_id, path in input_paths.items():
        if sha256_file(path) != INPUT_SHA256[basin_id]:
            raise ValueError(f"verification input hash changed: {basin_id}")
        members = _npz_member_names(path)
        if members != tuple(config["data"]["archive_members_present"]):
            raise ValueError(f"input archive member closure changed: {basin_id}")
        identity_members = identity_document.get("input_archive_members", {}).get(basin_id)
        if tuple(identity_members or ()) != members:
            raise ValueError(f"run identity input members changed: {basin_id}")

    run_identity = RunIdentity(
        experiment_id=EXPERIMENT_ID,
        configuration_sha256=str(identity_document["configuration_sha256"]),
        source_sha256={str(key): str(value) for key, value in source_hashes.items()},
        input_archive_sha256={str(key): str(value) for key, value in input_hashes.items()},
    )
    summary = _json(run_directory / "result_summary.json")
    if summary.get("a20_reference_sha256") != A20_RESULT_SHA256:
        raise ValueError("result summary does not bind the A20 reference")
    if _json_normalized(summary.get("scientific_limitations")) != _json_normalized(
        config.get("scientific_limitations")
    ):
        raise ValueError("result summary scientific limitations differ from the config")
    history = summary.get("history")
    if not isinstance(history, list) or tuple(int(row["epoch"]) for row in history) != (0, 1, 2, 3, 4):
        raise ValueError("result history is not epochs zero through four")
    expected_sampling = a20_training_unit_geometry(a20_summary)
    actual_sampling = []
    for epoch in range(1, 5):
        units = history[epoch].get("training_units")
        if not isinstance(units, list):
            raise TypeError(f"epoch {epoch} training units are absent")
        actual_sampling.append(
            tuple(
                (
                    epoch,
                    int(unit["step_in_epoch"]),
                    str(unit["basin_id"]),
                    int(unit["start_index"]),
                    int(unit["end_index_exclusive"]),
                )
                for unit in units
            )
        )
    if tuple(actual_sampling) != expected_sampling:
        raise ValueError("A34 training segments differ from the archived A20 sampling geometry")
    access = _json(run_directory / "access_ledger.json")
    materialized_reads = access.get("archive_member_reads")
    allowed_members = set(config["data"]["materialized_archive_members"])
    sessions = int(access.get("archive_materialization_sessions", -1))
    if not isinstance(materialized_reads, Mapping) or set(materialized_reads) != allowed_members:
        raise ValueError("archive materialization member closure changed")
    if sessions < 1 or any(int(value) != 2 * sessions for value in materialized_reads.values()):
        raise ValueError("archive materialization counts do not match two basins per session")
    for key in (
        "evaluation_array_reads",
        "evaluation_predictions",
        "evaluation_metrics",
        "evaluation_outputs",
    ):
        if int(access.get(key, -1)) != 0:
            raise ValueError(f"forbidden access counter is nonzero: {key}")
    scale_evidence = _json(run_directory / "training_scale_evidence.json")
    scales = scale_evidence.get("scales")
    if not isinstance(scales, Mapping):
        raise TypeError("training scale evidence is incomplete")
    per_basin_scale = scales.get("per_basin")
    if not isinstance(per_basin_scale, Mapping):
        raise TypeError("per-basin training scales are absent")
    standard_deviations = [
        float(per_basin_scale[basin_id]["population_std_original_discharge_units"])
        for basin_id in BASIN_IDS
    ]

    ledger = AccessLedger()
    ledger.begin_materialization_session()
    basin_arrays = [
        load_daily_selection_archive(
            input_paths[basin_id], INPUT_SHA256[basin_id], contract, ledger
        )
        for basin_id in BASIN_IDS
    ]
    independent_scales = fit_shared_training_discharge_scales(
        {arrays.basin_id: arrays.observations for arrays in basin_arrays},
        training_start_index=0,
        validation_start_index=2557,
    )
    if training_scale_evidence_sha256(independent_scales) != str(
        scale_evidence["training_scale_evidence_sha256"]
    ):
        raise ValueError("training scale evidence does not recompute")
    if _json_normalized(scales) != _json_normalized(asdict(independent_scales)):
        raise ValueError("saved training scale values differ from independent recomputation")
    device = torch.device(device_name)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA verification requested but unavailable")
    basins = [prepare_full_state_daily_basin(arrays, contract, device) for arrays in basin_arrays]
    model = config["model"]
    training = config["training"]
    settings = {
        **training,
        "hidden_dimension": model["hidden_dimension"],
        "input_multiplier": model["input_multiplier"],
        "output_multiplier": model["output_multiplier"],
        "gain_head_weight_multiplier": model["gain_head_initialization"]["final_weight_multiplier"],
    }
    network = build_a20_full_state_network(basins[0], settings, device=device)
    trainable_names = tuple(
        name for name, parameter in network.named_parameters() if parameter.requires_grad
    )

    previous_checkpoint_sha256 = None
    losses: list[float] = []
    independent_by_epoch: dict[int, Mapping[str, Any]] = {}
    checkpoint_hashes: dict[int, str] = {}
    strict_zero_difference: float | None = None
    for epoch in range(5):
        unit = run_directory / "epoch_units" / f"epoch_{epoch:03d}"
        checkpoint = unit / "checkpoint.pt"
        predictions = unit / "validation_predictions.npz"
        marker = _json(unit / "unit_complete.json")
        checkpoint_hash = sha256_file(checkpoint)
        prediction_hash = sha256_file(predictions)
        if marker.get("checkpoint_sha256") != checkpoint_hash:
            raise ValueError(f"epoch {epoch} checkpoint marker hash changed")
        if marker.get("validation_predictions_sha256") != prediction_hash:
            raise ValueError(f"epoch {epoch} prediction marker hash changed")
        if epoch == 0:
            strict_arrays_path = unit / "strict_zero_open_loop_control.npz"
            strict_metrics_path = unit / "strict_zero_open_loop_control.json"
            if marker.get("strict_zero_arrays_sha256") != sha256_file(strict_arrays_path):
                raise ValueError("epoch zero strict-zero array marker hash changed")
            if marker.get("strict_zero_metrics_sha256") != sha256_file(strict_metrics_path):
                raise ValueError("epoch zero strict-zero metrics marker hash changed")
            strict_arrays = _load_arrays(strict_arrays_path)
            strict_zero_difference = float(
                np.max(np.abs(strict_arrays["prediction"] - strict_arrays["open_loop"]))
            )
            strict_metrics = _json(strict_metrics_path)
            if strict_metrics.get("experiment_id") != EXPERIMENT_ID:
                raise ValueError("strict-zero metrics experiment changed")
            _close(
                strict_metrics.get("open_loop_max_abs_difference", math.inf),
                strict_zero_difference,
                "strict-zero reported difference",
                tolerance=1.0e-15,
            )
        elif any(
            key in marker
            for key in ("strict_zero_arrays_sha256", "strict_zero_metrics_sha256")
        ):
            raise ValueError("strict-zero hashes are only permitted in epoch zero")
        checkpoint_state = load_resume_checkpoint(checkpoint, run_identity)
        if int(checkpoint_state.completed_epoch) != epoch:
            raise ValueError(f"epoch {epoch} checkpoint identity changed")
        if checkpoint_state.previous_checkpoint_sha256 != previous_checkpoint_sha256:
            raise ValueError(f"epoch {epoch} predecessor hash changed")
        if _json_normalized([dict(row) for row in checkpoint_state.history]) != [
            dict(row) for row in history[: epoch + 1]
        ]:
            raise ValueError(f"epoch {epoch} checkpoint history changed")
        if _state_sha256(checkpoint_state.model_state) != str(history[epoch]["parameter_sha256"]):
            raise ValueError(f"epoch {epoch} parameter hash changed")
        saved_arrays = _load_arrays(predictions)
        independent = _independent_metrics(saved_arrays, standard_deviations)
        independent_by_epoch[epoch] = independent
        losses.append(float(independent["shared_loss"]))
        _close(independent["shared_loss"], history[epoch]["validation_loss"], f"epoch {epoch} loss")
        for basin_id in BASIN_IDS:
            _close(
                independent["per_basin_loss"][basin_id],
                history[epoch]["per_basin"][basin_id]["validation_loss"],
                f"epoch {epoch} {basin_id} loss",
            )
            for lead in (1, 2, 3):
                reported_cell = history[epoch]["per_basin"][basin_id][
                    "per_lead_loss_evidence"
                ][str(lead)]
                _close(
                    independent["physical_mse"][basin_id][lead],
                    reported_cell["physical_mse"],
                    f"epoch {epoch} {basin_id} lead {lead} MSE",
                )
        network.load_state_dict(checkpoint_state.model_state, strict=True)
        network.eval()
        with torch.no_grad():
            regenerated_metrics, regenerated_arrays = full_state_validation_artifact(
                network,
                basins,
                training_loss_scales=independent_scales,
                validation_window_days=128,
                filter_warmup_days=16,
            )
        for name in EXPECTED_ARRAY_KEYS - {"basin_ids", "leads_days"}:
            np.testing.assert_allclose(
                regenerated_arrays[name], saved_arrays[name], rtol=0.0, atol=2.0e-6
            )
        _close(regenerated_metrics["validation_loss"], independent["shared_loss"], f"epoch {epoch} regeneration")
        checkpoint_hashes[epoch] = checkpoint_hash
        previous_checkpoint_sha256 = checkpoint_hash

    selected_epoch = min(range(5), key=lambda epoch: (losses[epoch], epoch))
    if int(summary.get("science_gate", {}).get("selected_epoch", -1)) != selected_epoch:
        raise ValueError("selected checkpoint is not the earliest minimum frozen loss")
    selected_checkpoint = (
        run_directory / "epoch_units" / f"epoch_{selected_epoch:03d}" / "checkpoint.pt"
    )
    selected_predictions = (
        run_directory
        / "epoch_units"
        / f"epoch_{selected_epoch:03d}"
        / "validation_predictions.npz"
    )
    if summary.get("selected_checkpoint") != selected_checkpoint.relative_to(
        run_directory
    ).as_posix():
        raise ValueError("result summary selected checkpoint path changed")
    if summary.get("selected_validation_predictions") != selected_predictions.relative_to(
        run_directory
    ).as_posix():
        raise ValueError("result summary selected prediction path changed")
    selected = independent_by_epoch[selected_epoch]
    zero = independent_by_epoch[0]
    reasons: list[str] = []
    if selected_epoch <= 0:
        reasons.append("selected checkpoint is epoch zero")
    if not losses[selected_epoch] < losses[0] - 1.0e-6:
        reasons.append("shared validation loss did not improve")
    for basin_id in BASIN_IDS:
        if not selected["per_basin_loss"][basin_id] < zero["per_basin_loss"][basin_id]:
            reasons.append(f"{basin_id} basin loss did not improve")
        for lead in (1, 2, 3):
            selected_mse = selected["physical_mse"][basin_id][lead]
            if not selected_mse < zero["physical_mse"][basin_id][lead]:
                reasons.append(f"{basin_id} lead {lead} did not improve from epoch zero")
            if not selected_mse < A20_PHYSICAL_MSE[basin_id][lead]:
                reasons.append(f"{basin_id} lead {lead} did not beat A20")
    if tuple(int(row["optimizer_steps"]) for row in history) != (0, 2, 4, 6, 8):
        raise ValueError("optimizer-step growth changed")
    if tuple(int(row["sampled_forecast_events"]) for row in history) != (
        0,
        540,
        1080,
        1620,
        2160,
    ):
        raise ValueError("forecast-event growth changed")
    if set(history[-1]["nonzero_gradient_parameter_names"]) != set(trainable_names):
        reasons.append("not every trainable tensor had a nonzero gradient")
    if strict_zero_difference is None:
        raise ValueError("strict-zero evidence was not independently recomputed")
    if strict_zero_difference > 1.0e-7:
        reasons.append("strict-zero control differs from open loop")

    completion_path = run_directory / "completion.marker.json"
    completion = _json(completion_path) if completion_path.exists() else None
    manifest_member_count = _verify_manifest(run_directory, completion)
    scientific_passed = not reasons
    if bool(summary.get("science_gate", {}).get("passed")) != scientific_passed:
        raise ValueError("reported and independently recomputed science gates differ")
    if scientific_passed and completion is None:
        raise ValueError("passing result lacks a completion marker")
    if not scientific_passed and completion is not None:
        raise ValueError("failed result must not have a completion marker")
    if completion is not None:
        _verify_completion_bindings(
            run_directory,
            completion,
            selected_epoch=selected_epoch,
            selected_checkpoint=selected_checkpoint,
            selected_predictions=selected_predictions,
        )
    report = {
        "status": "VERIFIED_PASS" if scientific_passed else "VERIFIED_HARD_STOP",
        "experiment_id": EXPERIMENT_ID,
        "scientific_passed": scientific_passed,
        "reasons": reasons,
        "selected_epoch": selected_epoch,
        "epoch_validation_losses": losses,
        "selected_independent_metrics": selected,
        "epoch_zero_independent_metrics": zero,
        "strict_zero_open_loop_max_abs_difference": strict_zero_difference,
        "optimizer_steps": 8,
        "forecast_error_events": 2160,
        "checkpoint_hashes": checkpoint_hashes,
        "checkpoint_chain_verified": True,
        "all_epoch_predictions_regenerated": True,
        "manifest_member_count": manifest_member_count,
        "reserved_evaluation_accessed": False,
        "daily_only": True,
        "formal_evaluation": False,
        "verification_device": str(device),
    }
    return report, 0 if scientific_passed else 2


def atomic_write(path: Path, content: bytes) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_name, path)
    finally:
        if os.path.exists(temporary_name):
            os.unlink(temporary_name)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Verify the A34 daily full-state result")
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--inputs-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", choices=("cuda", "cpu"), default="cuda")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    arguments = build_parser().parse_args(argv)
    try:
        report, code = verify(
            arguments.run_dir,
            arguments.config,
            arguments.inputs_root,
            device_name=arguments.device,
        )
        atomic_write(arguments.output, canonical_json_bytes(report))
        print(canonical_json_bytes(report).decode("utf-8"), end="")
        return code
    except Exception as exc:
        report = {
            "status": "VERIFICATION_FAILURE",
            "error_type": type(exc).__name__,
            "message": str(exc),
        }
        atomic_write(arguments.output, canonical_json_bytes(report))
        print(canonical_json_bytes(report).decode("utf-8"), file=sys.stderr, end="")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
