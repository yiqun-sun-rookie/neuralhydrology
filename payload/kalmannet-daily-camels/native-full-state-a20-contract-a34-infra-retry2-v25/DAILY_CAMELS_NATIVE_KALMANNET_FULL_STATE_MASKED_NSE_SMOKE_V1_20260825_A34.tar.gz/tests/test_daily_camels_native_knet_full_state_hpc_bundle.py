from __future__ import annotations

import os
from pathlib import Path
import subprocess
import sys
import tarfile

from hpc.daily_camels_native_kalmannet_full_state_masked_nse import preflight
from scripts import build_daily_camels_native_kalmannet_full_state_masked_nse_hpc_bundle as builder


ROOT = Path(__file__).resolve().parents[1]


def test_bundle_is_deterministic_closed_and_uses_inert_initializers(
    tmp_path: Path,
) -> None:
    members, manifest = builder.build_members()
    assert int(manifest["file_count"]) == len(members)
    assert set(manifest["files"]) == set(members)
    assert manifest["daily_only"] is True
    assert manifest["formal_evaluation_enabled"] is False
    assert all(members[path] == b"" for path in builder.PACKAGE_INITIALIZERS)
    forbidden = ("hourly", "reserved_evaluation", "evaluation_input", "evaluation_data")
    assert not any(token in name.lower() for name in members for token in forbidden)

    first = tmp_path / "first.tar.gz"
    second = tmp_path / "second.tar.gz"
    builder.write_deterministic_archive(first, members, manifest)
    builder.write_deterministic_archive(second, members, manifest)
    assert first.read_bytes() == second.read_bytes()
    builder.verify_archive(first, manifest)
    builder.verify_archive(second, manifest)
    with tarfile.open(first, mode="r:gz") as archive:
        assert set(archive.getnames()) == set(members) | {"bundle_manifest.json"}
        for relative in builder.PACKAGE_INITIALIZERS:
            assert archive.extractfile(relative).read() == b""


def test_bundle_entrypoints_import_only_the_extracted_source_closure(
    tmp_path: Path,
) -> None:
    members, _ = builder.build_members()
    bundle = tmp_path / "bundle"
    # Help-path imports do not need data archives or the archived A20 result.
    # Omitting those long evidence paths also avoids the legacy Windows path limit.
    for relative, content in members.items():
        if relative.startswith("inputs/") or relative == builder.A20_RESULT_PATH:
            continue
        destination = bundle / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(content)
    environment = dict(os.environ)
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    environment["PYTHONPATH"] = os.pathsep.join((str(bundle / "src"), str(bundle)))
    commands = (
        bundle / "scripts" / "run_daily_camels_native_kalmannet_full_state_masked_nse.py",
        bundle
        / "hpc"
        / "daily_camels_native_kalmannet_full_state_masked_nse"
        / "preflight.py",
        bundle
        / "hpc"
        / "daily_camels_native_kalmannet_full_state_masked_nse"
        / "verify_result.py",
    )
    for script in commands:
        completed = subprocess.run(
            [sys.executable, "-B", str(script), "--help"],
            cwd=bundle,
            env=environment,
            check=False,
            capture_output=True,
            text=True,
        )
        assert completed.returncode == 0, completed.stderr


def test_scheduled_wrapper_pins_runtime_selfcheck_and_all_regression_tests() -> None:
    wrapper = (
        ROOT
        / "hpc"
        / "daily_camels_native_kalmannet_full_state_masked_nse"
        / "submit_smoke_gpu.slurm"
    ).read_text(encoding="utf-8")
    assert "#SBATCH --signal=B:TERM@120" in wrapper
    assert "#SBATCH --mem=" not in wrapper
    assert "DAILY_CAMELS_NATIVE_KALMANNET_FULL_STATE_A34_INFRA_RETRY2_SEQ25" in wrapper
    assert 'scancel --signal=TERM "${SLURM_JOB_ID}"' in wrapper
    assert 'kill -TERM "${TRAIN_LAUNCH_PID}"' not in wrapper
    assert 'export PYTHONPATH="${BUNDLE_ROOT}/src:${BUNDLE_ROOT}' in wrapper
    assert "attempt-stop-baseline-${SLURM_JOB_ID}.json" in wrapper
    assert "this job did not append exactly one new attempt stop record" in wrapper
    assert "python -B -m pytest" not in wrapper
    assert "RUNTIME_IMPORT_CUDA_AND_LOSS_SELFCHECK_PASSED" in wrapper
    assert '"pytest_required_on_compute_node": False' in wrapper
    for name in (
        "test_daily_camels_native_knet_full_state_masked_nse_contract.py",
        "test_daily_camels_native_knet_full_state_masked_nse_training.py",
        "test_daily_camels_native_knet_full_state_result_verifier.py",
        "test_daily_camels_native_knet_full_state_hpc_bundle.py",
    ):
        assert any(path.endswith(name) for path in builder.SUPPORT_PATHS)


def test_bundle_verifier_rejects_an_unlisted_file(tmp_path: Path) -> None:
    member = tmp_path / "kept.txt"
    member.write_bytes(b"kept")
    manifest = {
        "experiment_id": preflight.EXPERIMENT_ID,
        "file_count": 1,
        "files": {
            "kept.txt": {
                "sha256": preflight.sha256_file(member),
                "size_bytes": member.stat().st_size,
            }
        },
    }
    (tmp_path / "bundle_manifest.json").write_bytes(
        preflight.canonical_json_bytes(manifest)
    )
    extra = tmp_path / "unlisted.txt"
    extra.write_text("unexpected", encoding="utf-8")
    try:
        preflight.verify_bundle(tmp_path)
    except ValueError as exc:
        assert "complete bundle file closure" in str(exc)
    else:  # pragma: no cover - failure branch is the assertion
        raise AssertionError("unlisted bundle file was accepted")
