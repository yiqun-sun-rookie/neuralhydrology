from __future__ import annotations

from hashlib import sha256
import json
from pathlib import Path

import pytest

from hpc.daily_camels_native_kalmannet_full_state_masked_nse import verify_result


def _digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def _write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(verify_result.canonical_json_bytes(value))


def _manifest_record(path: Path) -> dict[str, object]:
    return {"sha256": _digest(path), "size_bytes": path.stat().st_size}


def _result_shell(tmp_path: Path) -> tuple[Path, Path, Path, dict[str, object]]:
    run = tmp_path / "run"
    unit = run / "epoch_units" / "epoch_002"
    unit.mkdir(parents=True)
    summary = run / "result_summary.json"
    checkpoint = unit / "checkpoint.pt"
    predictions = unit / "validation_predictions.npz"
    _write_json(summary, {"selected_epoch": 2})
    checkpoint.write_bytes(b"checkpoint-evidence")
    predictions.write_bytes(b"prediction-evidence")
    files = {
        path.relative_to(run).as_posix(): _manifest_record(path)
        for path in (summary, checkpoint, predictions)
    }
    manifest = {
        "experiment_id": verify_result.EXPERIMENT_ID,
        "file_count": len(files),
        "files": files,
    }
    manifest_path = run / "manifest.sha256.json"
    _write_json(manifest_path, manifest)
    completion = {
        "schema_version": "daily_camels_native_full_state_completion_v1",
        "experiment_id": verify_result.EXPERIMENT_ID,
        "status": "COMPLETED",
        "manifest_sha256": _digest(manifest_path),
        "summary_sha256": _digest(summary),
        "selected_epoch": 2,
        "selected_checkpoint_sha256": _digest(checkpoint),
        "selected_validation_predictions_sha256": _digest(predictions),
    }
    return run, checkpoint, predictions, completion


def test_result_manifest_requires_exact_file_closure_and_hashes(tmp_path: Path) -> None:
    run, _, _, completion = _result_shell(tmp_path)
    assert verify_result._verify_manifest(run, completion) == 3

    unlisted = run / "unlisted.txt"
    unlisted.write_text("not declared", encoding="utf-8")
    with pytest.raises(ValueError, match="complete result file closure"):
        verify_result._verify_manifest(run, completion)
    unlisted.unlink()

    checkpoint = run / "epoch_units" / "epoch_002" / "checkpoint.pt"
    checkpoint.write_bytes(b"tampered")
    with pytest.raises(ValueError, match="manifest member hash changed"):
        verify_result._verify_manifest(run, completion)


def test_completion_marker_binds_summary_epoch_checkpoint_and_predictions(
    tmp_path: Path,
) -> None:
    run, checkpoint, predictions, completion = _result_shell(tmp_path)
    verify_result._verify_completion_bindings(
        run,
        completion,
        selected_epoch=2,
        selected_checkpoint=checkpoint,
        selected_predictions=predictions,
    )

    changed = dict(completion)
    changed["selected_epoch"] = 1
    with pytest.raises(ValueError, match="selected epoch"):
        verify_result._verify_completion_bindings(
            run,
            changed,
            selected_epoch=2,
            selected_checkpoint=checkpoint,
            selected_predictions=predictions,
        )

    changed = dict(completion)
    changed["selected_checkpoint_sha256"] = "0" * 64
    with pytest.raises(ValueError, match="checkpoint hash"):
        verify_result._verify_completion_bindings(
            run,
            changed,
            selected_epoch=2,
            selected_checkpoint=checkpoint,
            selected_predictions=predictions,
        )

    changed = dict(completion)
    changed["selected_validation_predictions_sha256"] = "0" * 64
    with pytest.raises(ValueError, match="predictions hash"):
        verify_result._verify_completion_bindings(
            run,
            changed,
            selected_epoch=2,
            selected_checkpoint=checkpoint,
            selected_predictions=predictions,
        )


def test_completion_marker_rejects_summary_or_schema_drift(tmp_path: Path) -> None:
    run, checkpoint, predictions, completion = _result_shell(tmp_path)
    (run / "result_summary.json").write_text("{}\n", encoding="utf-8")
    with pytest.raises(ValueError, match="summary hash"):
        verify_result._verify_completion_bindings(
            run,
            completion,
            selected_epoch=2,
            selected_checkpoint=checkpoint,
            selected_predictions=predictions,
        )

    run, checkpoint, predictions, completion = _result_shell(tmp_path / "second")
    completion["schema_version"] = "wrong"
    with pytest.raises(ValueError, match="identity"):
        verify_result._verify_completion_bindings(
            run,
            completion,
            selected_epoch=2,
            selected_checkpoint=checkpoint,
            selected_predictions=predictions,
        )
