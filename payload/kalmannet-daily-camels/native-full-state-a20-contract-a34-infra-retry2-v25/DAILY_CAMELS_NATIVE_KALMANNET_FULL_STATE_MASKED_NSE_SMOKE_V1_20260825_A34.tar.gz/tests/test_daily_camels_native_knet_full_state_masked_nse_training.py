from __future__ import annotations

from hashlib import sha256
from pathlib import Path

import torch

from global_hydrology.experiments.daily_camels_native_knet_full_state_masked_nse_training import (
    A20ProjectionNativeHBVFullStateKalmanNet,
    initialize_a20_gain_head,
)
from global_hydrology.models.differentiable_hbv_lite import PARAM_BOUNDS, PARAM_NAMES
from global_hydrology.models.knet_native_hbvlite_full_state import (
    build_padded_routed_system,
    correction_mask_for_active_lag,
)


ROOT = Path(__file__).resolve().parents[1]
A20_TRAINING = (
    ROOT
    / "src"
    / "global_hydrology"
    / "experiments"
    / "daily_camels_native_knet_masked_nse_training.py"
)


def test_historical_a20_training_source_remains_byte_identical() -> None:
    assert sha256(A20_TRAINING.read_bytes()).hexdigest() == (
        "41e7dbc801fb5b46583b2951d79f89cfc68a69dc557fc3daf1ccfc9d9d42ac79"
    )


def projection_shell(active_lag: int) -> A20ProjectionNativeHBVFullStateKalmanNet:
    net = object.__new__(A20ProjectionNativeHBVFullStateKalmanNet)
    torch.nn.Module.__init__(net)
    net.m = 18
    mask = torch.zeros(1, 18)
    mask[:, : 5 + active_lag] = 1.0
    net.register_buffer("correction_mask", mask)
    upper = torch.full((1, 18), torch.inf)
    upper[:, :5] = 1.0
    net.register_buffer("state_upper_bound", upper)
    return net


def test_projection_preserves_physical_prior_above_training_storage_bound() -> None:
    net = projection_shell(active_lag=2)
    prior = torch.zeros(1, 18)
    prior[:, :5] = torch.tensor([3.0, 2.0, 4.0, 5.0, 6.0])
    proposed = prior.clone()
    actual = net._project_analysis(proposed, prior)
    torch.testing.assert_close(actual[:, :5], prior[:, :5], rtol=0.0, atol=0.0)


def test_projection_allows_active_route_but_zeros_inactive_tail() -> None:
    net = projection_shell(active_lag=2)
    prior = torch.zeros(1, 18)
    proposed = torch.arange(18, dtype=torch.float32).reshape(1, 18)
    proposed[:, 5] = -2.0
    proposed[:, 6] = 7.0
    proposed[:, 7:] = 99.0
    actual = net._project_analysis(proposed, prior)
    assert actual[0, 5].item() == 0.0
    assert actual[0, 6].item() == 7.0
    assert torch.count_nonzero(actual[:, 7:]).item() == 0


class TinyGainHead(torch.nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.FC2 = torch.nn.Sequential(
            torch.nn.Linear(3, 4), torch.nn.ReLU(), torch.nn.Linear(4, 2)
        )


def test_a20_near_zero_initialization_is_not_strict_zero() -> None:
    torch.manual_seed(7)
    net = TinyGainHead()
    before = net.FC2[-1].weight.detach().clone()
    initialize_a20_gain_head(net, weight_multiplier=0.01, strict_zero=False)
    torch.testing.assert_close(
        net.FC2[-1].weight,
        before * 0.01,
        rtol=0.0,
        atol=0.0,
    )
    assert torch.count_nonzero(net.FC2[-1].weight).item() > 0
    assert torch.count_nonzero(net.FC2[-1].bias).item() == 0


def test_strict_zero_control_is_distinct_and_exact() -> None:
    torch.manual_seed(7)
    net = TinyGainHead()
    initialize_a20_gain_head(net, weight_multiplier=0.01, strict_zero=True)
    assert torch.count_nonzero(net.FC2[-1].weight).item() == 0
    assert torch.count_nonzero(net.FC2[-1].bias).item() == 0


def _parameters(lag_time: float, k2: float | None = None) -> torch.Tensor:
    values = []
    for name in PARAM_NAMES:
        lower, upper = PARAM_BOUNDS[name]
        if name == "lag_time":
            value = lag_time
        elif name == "parK2" and k2 is not None:
            value = k2
        else:
            value = (lower + upper) / 2.0
        values.append(value)
    return torch.tensor([values], dtype=torch.float32)


def _adaptation_tensors(system: object, active_lag: int, scale: float) -> dict[str, object]:
    state_dimension = int(system.m)
    upper = torch.full((1, state_dimension), torch.inf, dtype=torch.float32)
    upper[:, :5] = 1000.0
    return {
        "system": system,
        "correction_mask": correction_mask_for_active_lag(
            state_dimension, active_lag, dtype=torch.float32
        ),
        "state_lower_bound": torch.zeros(1, state_dimension, dtype=torch.float32),
        "state_upper_bound": upper,
        "observation_feature_scale": torch.full((1, 1), scale, dtype=torch.float32),
        "state_feature_scale": torch.full(
            (1, state_dimension), scale + 0.5, dtype=torch.float32
        ),
        "normalized_feature_guard": 10.0,
    }


def test_two_basin_graphs_share_parameters_without_mutating_saved_buffers() -> None:
    torch.manual_seed(11)
    system_a, active_a = build_padded_routed_system(
        _parameters(1.2), maximum_lag=13, dtype=torch.float32
    )
    system_b, active_b = build_padded_routed_system(
        _parameters(12.0, k2=0.19), maximum_lag=13, dtype=torch.float32
    )
    adaptation_a = _adaptation_tensors(system_a, active_a, 1.0)
    adaptation_b = _adaptation_tensors(system_b, active_b, 2.0)
    net = A20ProjectionNativeHBVFullStateKalmanNet(
        system_a,
        correction_mask=adaptation_a["correction_mask"],
        state_lower_bound=adaptation_a["state_lower_bound"],
        state_upper_bound=adaptation_a["state_upper_bound"],
        hidden=8,
    ).to(dtype=torch.float32)
    initialize_a20_gain_head(net, weight_multiplier=0.01)

    losses = []
    for adaptation in (adaptation_a, adaptation_b):
        system = adaptation["system"]
        net.set_basin_adaptation(**adaptation)
        initial = system.get_default_initial_state()
        control = torch.tensor([[2.0, 4.0, 1.0]], dtype=torch.float32)
        prior = system.f(initial, control)
        observation = system.h(prior).reshape(1, 1) + 0.25
        net.initialize_filter(initial, sequence_length=1)
        posterior = net.analysis_step(observation, control)
        losses.append(system.h(posterior).square().mean())

    torch.stack(losses).mean().backward()
    gradients = [parameter.grad for parameter in net.parameters() if parameter.requires_grad]
    assert gradients
    observed = [gradient for gradient in gradients if gradient is not None]
    assert observed
    assert all(bool(torch.isfinite(gradient).all()) for gradient in observed)
    assert any(bool(torch.count_nonzero(gradient)) for gradient in observed)
