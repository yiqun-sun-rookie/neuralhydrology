from __future__ import annotations

import copy
import json
from pathlib import Path

import pytest

from global_hydrology.experiments.daily_camels_native_knet_full_state_masked_nse_contract import (
    A20_PHYSICAL_MSE,
    BASIN_IDS,
    DailyFullStateKNetContract,
    EXPERIMENT_ID,
    validate_exact_configuration,
)


ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "configs" / "daily_camels_native_kalmannet_full_state_masked_nse_smoke_v1.json"


def payload() -> dict:
    return json.loads(CONFIG.read_text(encoding="utf-8"))


def test_exact_daily_two_basin_full_state_contract_loads() -> None:
    value = payload()
    validate_exact_configuration(value)
    contract = DailyFullStateKNetContract.from_dict(value)
    assert contract.experiment_id == EXPERIMENT_ID
    assert contract.validation_start_index == 2557
    assert contract.state_dimension == 18
    assert contract.maximum_routing_lag == 13
    assert contract.gain_head_weight_multiplier == pytest.approx(0.01)
    assert tuple(row["basin_id"] for row in value["data"]["input_archives"]) == BASIN_IDS
    assert set(A20_PHYSICAL_MSE) == set(BASIN_IDS)


@pytest.mark.parametrize(
    ("section", "key", "changed"),
    [
        ("data", "cadence", "hourly"),
        ("periods", "validation_start", "2006-10-02"),
        ("forecast", "leads_days", [1, 2]),
        ("model", "state_dimension", 17),
        ("model", "maximum_routing_lag", 12),
        ("training", "steps_per_epoch", 3),
        ("training", "validation_window_days", 731),
        ("checkpoint_selection", "metric", "nash_sutcliffe_efficiency_gain"),
    ],
)
def test_contract_rejects_scientific_factor_drift(
    section: str, key: str, changed: object
) -> None:
    value = payload()
    value[section][key] = changed
    with pytest.raises((TypeError, ValueError)):
        validate_exact_configuration(value)


def test_contract_rejects_variance_only_denominator() -> None:
    value = payload()
    value["loss_contract"]["formula"] = (
        "mean_equal_complete_basin_lead_events((prediction-target)^2/"
        "basin_training_population_variance)"
    )
    with pytest.raises(ValueError, match="loss formula"):
        validate_exact_configuration(value)


def test_contract_rejects_strict_zero_substitution_for_a20_near_zero() -> None:
    value = payload()
    value["model"]["gain_head_initialization"]["final_weight_multiplier"] = 0.0
    with pytest.raises(ValueError, match="weight scale"):
        validate_exact_configuration(value)


def test_contract_rejects_a20_cell_threshold_drift() -> None:
    value = payload()
    changed = copy.deepcopy(value)
    changed["a20_reference"]["selected_physical_mse_by_basin_and_lead"][
        "09035800"
    ]["3"] += 1.0e-6
    with pytest.raises(ValueError, match="A20 09035800 lead 3"):
        validate_exact_configuration(changed)


def test_contract_rejects_any_named_evaluation_period() -> None:
    value = payload()
    value["periods"]["formal_evaluation"] = ["1989-10-01", "1999-09-30"]
    with pytest.raises(ValueError, match="evaluation period"):
        validate_exact_configuration(value)
