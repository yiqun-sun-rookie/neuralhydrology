"""Sole resumable entry for the A34 daily two-basin full-state smoke."""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from hashlib import sha256
import io
import json
import math
import os
from pathlib import Path
import random
import signal
import socket
import sys
import threading
import time
from typing import Any, Mapping, Sequence
import zipfile


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
for _path in (ROOT, SRC):
    if str(_path) not in sys.path:
        sys.path.insert(0, str(_path))

from global_hydrology.experiments.daily_camels_native_knet_full_state_masked_nse_contract import (  # noqa: E402
    A20_PHYSICAL_MSE,
    A20_RESULT_PATH,
    A20_RESULT_SHA256,
    AccessLedger,
    BASIN_IDS,
    DailyFullStateKNetContract,
    EXPERIMENT_ID,
    EXPECTED_SOURCE_PATHS,
    INPUT_SHA256,
    SCHEMA_VERSION,
    a20_training_unit_geometry,
    validate_a20_reference_summary,
    validate_exact_configuration,
)


CONFIGURATION_NAME = "daily_camels_native_kalmannet_full_state_masked_nse_smoke_v1.json"
IDENTITY_FILE = "experiment_identity.json"
ACCESS_LEDGER_FILE = "access_ledger.json"
TRAINING_SCALE_FILE = "training_scale_evidence.json"
EVENT_FILE = "events.jsonl"
EPOCH_UNIT_DIRECTORY = "epoch_units"
STRICT_ZERO_ARRAY_FILE = "strict_zero_open_loop_control.npz"
STRICT_ZERO_METRICS_FILE = "strict_zero_open_loop_control.json"
SUMMARY_FILE = "result_summary.json"
MANIFEST_FILE = "manifest.sha256.json"
COMPLETION_FILE = "completion.marker.json"
ATTEMPT_STOP_DIRECTORY = "attempt_stops"
OWNER_LOCK_DIRECTORY = ".owner.lock"

SOURCE_PATHS = EXPECTED_SOURCE_PATHS


@dataclass(frozen=True)
class Preflight:
    config_path: Path
    run_root: Path
    run_directory: Path
    resume_checkpoint: Path | None
    configuration: Mapping[str, Any]
    configuration_sha256: str
    source_sha256: Mapping[str, str]
    input_paths: Mapping[str, Path]
    input_sha256: Mapping[str, str]
    input_archive_members: Mapping[str, tuple[str, ...]]
    a20_reference_path: Path
    a20_reference_sha256: str
    a20_reference_summary: Mapping[str, Any]
    identity: Mapping[str, Any]
    identity_sha256: str


def canonical_json_bytes(value: object) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
        + b"\n"
    )


def sha256_bytes(value: bytes) -> str:
    return sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _regular(path: Path, label: str) -> Path:
    path = Path(path)
    if not path.is_file() or path.is_symlink() or path.stat().st_nlink != 1:
        raise FileNotFoundError(f"{label} must be one regular single-link file: {path}")
    return path


def _inside(path: Path, root: Path, label: str) -> Path:
    resolved = Path(path).resolve(strict=False)
    base = Path(root).resolve(strict=True)
    try:
        resolved.relative_to(base)
    except ValueError as exc:
        raise ValueError(f"{label} must stay below {base}") from exc
    return resolved


def _npz_member_names(path: Path) -> tuple[str, ...]:
    with zipfile.ZipFile(_regular(path, "NPZ archive"), "r") as archive:
        filenames = tuple(info.filename for info in archive.infolist() if not info.is_dir())
    if len(filenames) != len(set(filenames)) or any(
        "/" in name or "\\" in name or not name.endswith(".npy") for name in filenames
    ):
        raise ValueError("NPZ archive member names are unsafe or duplicated")
    return tuple(name[:-4] for name in filenames)


def _load_json(path: Path) -> Mapping[str, Any]:
    def reject(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        output: dict[str, Any] = {}
        for key, value in pairs:
            if key in output:
                raise ValueError(f"duplicate JSON member: {key}")
            output[key] = value
        return output

    value = json.loads(
        _regular(path, "configuration").read_text(encoding="utf-8"),
        object_pairs_hook=reject,
    )
    if not isinstance(value, Mapping):
        raise TypeError("configuration must be a JSON object")
    return value


def preflight(config_path: Path, run_root: Path, resume: Path | None) -> Preflight:
    config_path = _regular(Path(config_path).resolve(strict=True), "configuration")
    if config_path.name != CONFIGURATION_NAME:
        raise ValueError(f"configuration name must remain {CONFIGURATION_NAME}")
    configuration = _load_json(config_path)
    validate_exact_configuration(configuration)
    DailyFullStateKNetContract.from_dict(configuration)

    source_sha256: dict[str, str] = {}
    for relative in SOURCE_PATHS:
        path = _regular(ROOT / relative, f"source {relative}")
        source_sha256[relative] = sha256_file(path)
    configured_sources = configuration["source_sha256"]
    if not isinstance(configured_sources, Mapping):
        raise TypeError("source_sha256 must be a JSON object")
    for relative, expected in configured_sources.items():
        if source_sha256.get(str(relative)) != str(expected):
            raise ValueError(f"frozen source hash differs for {relative}")

    input_paths: dict[str, Path] = {}
    input_sha256: dict[str, str] = {}
    input_archive_members: dict[str, tuple[str, ...]] = {}
    for archive in configuration["data"]["input_archives"]:
        basin_id = str(archive["basin_id"])
        candidate = config_path.parent.parent / str(archive["path"])
        if not candidate.exists():
            candidate = ROOT / str(archive["local_evidence_path"])
        path = _regular(candidate.resolve(strict=True), f"input {basin_id}")
        actual = sha256_file(path)
        if actual != INPUT_SHA256[basin_id]:
            raise ValueError(f"input archive hash differs for {basin_id}")
        input_paths[basin_id] = path
        input_sha256[basin_id] = actual
        members = _npz_member_names(path)
        expected_members = tuple(configuration["data"]["archive_members_present"])
        if members != expected_members:
            raise ValueError(f"input archive member closure differs for {basin_id}")
        input_archive_members[basin_id] = members

    a20_reference_path = _regular(
        (ROOT / A20_RESULT_PATH).resolve(strict=True), "A20 reference result"
    )
    a20_reference_sha256 = sha256_file(a20_reference_path)
    if a20_reference_sha256 != A20_RESULT_SHA256:
        raise ValueError("A20 reference result hash changed")
    a20_reference_summary = _load_json(a20_reference_path)
    validate_a20_reference_summary(a20_reference_summary)

    run_root = Path(run_root).resolve(strict=False)
    run_root.mkdir(parents=True, exist_ok=True)
    run_directory = _inside(run_root / EXPERIMENT_ID, run_root, "run directory")
    resume_checkpoint: Path | None = None
    if resume is None:
        if run_directory.exists():
            raise FileExistsError(f"new run directory already exists: {run_directory}")
    else:
        if not run_directory.is_dir() or run_directory.is_symlink():
            raise FileNotFoundError("resume run directory is absent or unsafe")
        if (run_directory / OWNER_LOCK_DIRECTORY).exists():
            raise FileExistsError("resume run still has an owner lock")
        if (run_directory / COMPLETION_FILE).exists():
            raise FileExistsError("a completion-marked run cannot resume")
        resume_checkpoint = _regular(Path(resume).resolve(strict=True), "resume checkpoint")
        unit_root = (run_directory / EPOCH_UNIT_DIRECTORY).resolve(strict=True)
        try:
            relative_resume = resume_checkpoint.relative_to(unit_root)
        except ValueError as exc:
            raise ValueError("resume checkpoint must be inside a complete epoch unit") from exc
        if len(relative_resume.parts) != 2 or relative_resume.name != "checkpoint.pt":
            raise ValueError("resume checkpoint must be epoch_NNN/checkpoint.pt")
        if not (resume_checkpoint.parent / "unit_complete.json").is_file():
            raise ValueError("resume checkpoint epoch unit is incomplete")

    configuration_sha256 = sha256_file(config_path)
    identity = {
        "schema_version": "daily_camels_native_full_state_run_identity_v1",
        "experiment_id": EXPERIMENT_ID,
        "scientific_schema_version": SCHEMA_VERSION,
        "configuration_sha256": configuration_sha256,
        "source_sha256": source_sha256,
        "input_archive_sha256": input_sha256,
        "input_archive_members": input_archive_members,
        "a20_reference_sha256": a20_reference_sha256,
        "daily_only": True,
        "formal_evaluation_enabled": False,
    }
    identity_sha256 = sha256_bytes(canonical_json_bytes(identity))
    return Preflight(
        config_path=config_path,
        run_root=run_root,
        run_directory=run_directory,
        resume_checkpoint=resume_checkpoint,
        configuration=configuration,
        configuration_sha256=configuration_sha256,
        source_sha256=source_sha256,
        input_paths=input_paths,
        input_sha256=input_sha256,
        input_archive_members=input_archive_members,
        a20_reference_path=a20_reference_path,
        a20_reference_sha256=a20_reference_sha256,
        a20_reference_summary=a20_reference_summary,
        identity=identity,
        identity_sha256=identity_sha256,
    )


def _read_events(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    output: list[dict[str, Any]] = []
    for index, line in enumerate(path.read_text(encoding="utf-8").splitlines()):
        row = json.loads(line)
        if not isinstance(row, dict) or int(row.get("sequence", -1)) != index:
            raise ValueError("event ledger sequence is invalid")
        output.append(row)
    return output


def _append_event(io_module: Any, path: Path, events: list[dict[str, Any]], row: Mapping[str, Any]) -> None:
    value = dict(row)
    value["sequence"] = len(events)
    value["recorded_at_utc"] = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    events.append(value)
    content = b"".join(canonical_json_bytes(event) for event in events)
    io_module.atomic_write_bytes(path, content, replace=path.exists())


def _npz_bytes(np_module: Any, arrays: Mapping[str, Any]) -> bytes:
    stream = io.BytesIO()
    np_module.savez_compressed(stream, **arrays)
    return stream.getvalue()


def _strict_zero_difference(
    np_module: Any, array_path: Path, metrics_path: Path
) -> float:
    expected = {
        "basin_ids",
        "leads_days",
        "origin_indices",
        "prediction",
        "target",
        "open_loop",
        "persistence",
        "ar2",
    }
    with np_module.load(_regular(array_path, "strict-zero arrays"), allow_pickle=False) as archive:
        if set(archive.files) != expected:
            raise ValueError("strict-zero array member set changed")
        prediction = np_module.asarray(archive["prediction"], dtype=np_module.float64)
        open_loop = np_module.asarray(archive["open_loop"], dtype=np_module.float64)
    if prediction.shape != (2, 3, 109) or open_loop.shape != prediction.shape:
        raise ValueError("strict-zero validation geometry changed")
    if not np_module.isfinite(prediction).all() or not np_module.isfinite(open_loop).all():
        raise ValueError("strict-zero validation arrays are nonfinite")
    difference = float(np_module.max(np_module.abs(prediction - open_loop)))
    metrics = _load_json(_regular(metrics_path, "strict-zero metrics"))
    if metrics.get("schema_version") != "daily_camels_strict_zero_control_v1":
        raise ValueError("strict-zero metrics schema changed")
    if metrics.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("strict-zero metrics experiment changed")
    reported = float(metrics.get("open_loop_max_abs_difference", math.inf))
    if not math.isclose(reported, difference, rel_tol=0.0, abs_tol=1.0e-15):
        raise ValueError("strict-zero reported difference does not match its arrays")
    return difference


def _checkpoint_path(run_directory: Path, epoch: int) -> Path:
    return (
        run_directory
        / EPOCH_UNIT_DIRECTORY
        / f"epoch_{epoch:03d}"
        / "checkpoint.pt"
    )


def _validation_path(run_directory: Path, epoch: int) -> Path:
    return (
        run_directory
        / EPOCH_UNIT_DIRECTORY
        / f"epoch_{epoch:03d}"
        / "validation_predictions.npz"
    )


def _latest_complete_checkpoint(run_directory: Path) -> Path:
    candidates: list[tuple[int, Path]] = []
    unit_root = run_directory / EPOCH_UNIT_DIRECTORY
    if not unit_root.is_dir() or unit_root.is_symlink():
        raise FileNotFoundError("no complete epoch-unit directory exists")
    for unit in unit_root.iterdir():
        if not unit.is_dir() or unit.is_symlink() or not unit.name.startswith("epoch_"):
            continue
        try:
            epoch = int(unit.name.removeprefix("epoch_"))
        except ValueError:
            continue
        marker = _load_json(_regular(unit / "unit_complete.json", "epoch unit marker"))
        checkpoint = _regular(unit / "checkpoint.pt", "epoch checkpoint")
        if int(marker.get("epoch", -1)) != epoch:
            raise ValueError("epoch unit marker identity changed")
        if marker.get("checkpoint_sha256") != sha256_file(checkpoint):
            raise ValueError("epoch unit checkpoint hash changed")
        candidates.append((epoch, checkpoint))
    if not candidates:
        raise FileNotFoundError("no complete epoch checkpoint exists")
    return max(candidates, key=lambda item: item[0])[1]


def _save_checkpoint(
    io_module: Any,
    np_module: Any,
    torch_module: Any,
    *,
    state: Preflight,
    training_result: Any,
    access_ledger: Mapping[str, Any],
    training_scale_sha256: str,
    previous_sha256: str | None,
    checkpoint_path: Path,
) -> tuple[Path, str]:
    epoch = int(training_result.completed_epoch)
    history = [dict(row) for row in training_result.history]
    if not history or int(history[-1]["epoch"]) != epoch:
        raise ValueError("checkpoint history does not end at its epoch")
    resume_state = io_module.ResumeState(
        experiment_id=EXPERIMENT_ID,
        model_state=training_result.current_model_state,
        optimizer_state=training_result.current_optimizer_state,
        scheduler_state=None,
        completed_epoch=epoch,
        cumulative_optimizer_steps=int(training_result.cumulative_optimizer_steps),
        sampled_forecast_events=int(training_result.sampled_forecast_events),
        nonzero_gradient_parameter_names=list(training_result.nonzero_gradient_parameter_names),
        best_post_zero_checkpoint={
            "epoch": int(training_result.best_epoch),
            "selection_score": float(training_result.best_selection_score),
            "model_state": training_result.best_model_state,
        },
        epoch_zero_record=history[0],
        history=history,
        python_random_state=random.getstate(),
        numpy_bit_generator_state=np_module.random.get_state(),
        torch_cpu_random_state=torch_module.random.get_rng_state(),
        torch_cuda_random_states=list(torch_module.cuda.get_rng_state_all()),
        sampler_generator_state=training_result.sampler_generator_state,
        configuration_sha256=state.configuration_sha256,
        source_sha256=state.source_sha256,
        input_archive_sha256=state.input_sha256,
        access_ledger=dict(access_ledger),
        previous_checkpoint_sha256=previous_sha256,
    )
    path = Path(checkpoint_path)
    return path, io_module.save_resume_checkpoint(path, resume_state)


def _independent_gate(
    history: Sequence[Mapping[str, Any]],
    access_ledger: Mapping[str, Any],
    *,
    a20_reference_summary: Mapping[str, Any],
    selected_epoch: int,
    trainable_names: Sequence[str],
    strict_zero_max_abs_difference: float,
) -> Mapping[str, Any]:
    reasons: list[str] = []
    if len(history) != 5 or tuple(int(row["epoch"]) for row in history) != (0, 1, 2, 3, 4):
        reasons.append("history is not the exact five-epoch sequence")
    by_epoch = {int(row["epoch"]): row for row in history}
    zero = by_epoch.get(0, {})
    selected = by_epoch.get(int(selected_epoch), {})
    if selected_epoch <= 0:
        reasons.append("selected checkpoint is epoch zero")
    if int(history[-1].get("optimizer_steps", -1)) != 8:
        reasons.append("optimizer-step count differs from eight")
    if int(history[-1].get("sampled_forecast_events", -1)) != 2160:
        reasons.append("forecast-error event count differs from 2160")
    actual_sampling = []
    for epoch in range(1, 5):
        units = history[epoch].get("training_units", []) if len(history) > epoch else []
        actual_sampling.append(
            tuple(
                (
                    epoch,
                    int(unit["step_in_epoch"]),
                    str(unit["basin_id"]),
                    int(unit["start_index"]),
                    int(unit["end_index_exclusive"]),
                )
                for unit in units
            )
        )
    if tuple(actual_sampling) != a20_training_unit_geometry(a20_reference_summary):
        reasons.append("training segments differ from the archived A20 sample geometry")
    zero_loss = float(zero.get("validation_loss", math.inf))
    selected_loss = float(selected.get("validation_loss", math.inf))
    if not selected_loss < zero_loss - 1.0e-6:
        reasons.append("selected frozen validation loss did not improve after epoch zero")
    for basin_id in BASIN_IDS:
        zero_basin = zero.get("per_basin", {}).get(basin_id, {})
        selected_basin = selected.get("per_basin", {}).get(basin_id, {})
        if not float(selected_basin.get("validation_loss", math.inf)) < float(
            zero_basin.get("validation_loss", -math.inf)
        ):
            reasons.append(f"basin {basin_id} loss did not improve")
        for lead in (1, 2, 3):
            zero_cell = zero_basin.get("per_lead_loss_evidence", {}).get(lead)
            if zero_cell is None:
                zero_cell = zero_basin.get("per_lead_loss_evidence", {}).get(str(lead), {})
            selected_cell = selected_basin.get("per_lead_loss_evidence", {}).get(lead)
            if selected_cell is None:
                selected_cell = selected_basin.get("per_lead_loss_evidence", {}).get(str(lead), {})
            selected_mse = float(selected_cell.get("physical_mse", math.inf))
            if not selected_mse < float(zero_cell.get("physical_mse", -math.inf)):
                reasons.append(f"{basin_id} lead {lead} did not improve from epoch zero")
            if not selected_mse < float(A20_PHYSICAL_MSE[basin_id][lead]):
                reasons.append(f"{basin_id} lead {lead} did not beat A20")
    observed_names = set(str(name) for name in history[-1].get("nonzero_gradient_parameter_names", []))
    if observed_names != set(trainable_names):
        reasons.append("not every trainable tensor had a nonzero finite gradient")
    if not bool(history[-1].get("finite_gradients")):
        reasons.append("final training record does not prove finite gradients")
    if any(
        float(row.get("inactive_padded_tail_correction_abs_max", math.inf)) != 0.0
        for row in history
    ):
        reasons.append("inactive padded routing tail changed")
    for key in (
        "evaluation_array_reads",
        "evaluation_predictions",
        "evaluation_metrics",
        "evaluation_outputs",
    ):
        if int(access_ledger.get(key, -1)) != 0:
            reasons.append(f"forbidden access counter {key} is nonzero")
    if (
        not math.isfinite(strict_zero_max_abs_difference)
        or strict_zero_max_abs_difference > 1.0e-7
    ):
        reasons.append("strict-zero control differs from the routed HBV open loop")
    return {
        "passed": not reasons,
        "reasons": reasons,
        "selected_epoch": int(selected_epoch),
        "epoch_zero_validation_loss": zero_loss,
        "selected_validation_loss": selected_loss,
        "validation_loss_improvement": zero_loss - selected_loss,
        "strict_zero_open_loop_max_abs_difference": strict_zero_max_abs_difference,
        "trainable_tensor_count": len(trainable_names),
        "nonzero_gradient_tensor_count": len(observed_names),
    }


def _manifest(run_directory: Path) -> Mapping[str, Any]:
    files: dict[str, Any] = {}
    for path in sorted(run_directory.rglob("*")):
        relative = path.relative_to(run_directory)
        if OWNER_LOCK_DIRECTORY in relative.parts or path.name in {MANIFEST_FILE, COMPLETION_FILE}:
            continue
        if path.is_symlink():
            raise ValueError(f"symbolic links are forbidden in results: {relative}")
        if path.is_file():
            files[relative.as_posix()] = {
                "sha256": sha256_file(path),
                "size_bytes": path.stat().st_size,
            }
    return {
        "schema_version": "daily_camels_native_full_state_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "file_count": len(files),
        "files": files,
    }


def execute(arguments: argparse.Namespace) -> int:
    state = preflight(arguments.config, arguments.run_root, arguments.resume)
    if arguments.preflight_only:
        print(
            canonical_json_bytes(
                {
                    "status": "PREFLIGHT_VERIFIED",
                    "experiment_id": EXPERIMENT_ID,
                    "configuration": str(state.config_path),
                    "configuration_sha256": state.configuration_sha256,
                    "run_directory": str(state.run_directory),
                    "resume_checkpoint": (
                        str(state.resume_checkpoint) if state.resume_checkpoint else None
                    ),
                    "source_sha256": dict(state.source_sha256),
                    "input_archive_sha256": dict(state.input_sha256),
                    "identity_sha256": state.identity_sha256,
                    "array_members_materialized": 0,
                }
            ).decode("utf-8"),
            end="",
        )
        return 0

    import numpy as np
    import torch

    from global_hydrology.experiments import daily_camels_native_knet_io as run_io
    from global_hydrology.experiments.daily_camels_masked_nse_loss_contract import (
        fit_shared_training_discharge_scales,
        training_scale_evidence_sha256,
    )
    from global_hydrology.experiments.daily_camels_native_knet_full_state_masked_nse_data import (
        load_daily_selection_archive,
        prepare_full_state_daily_basin,
    )
    from global_hydrology.experiments.daily_camels_native_knet_full_state_masked_nse_training import (
        RecoverableTrainingStop,
        full_state_validation_artifact,
        strict_zero_control_network,
        train_daily_native_full_state_knet,
    )

    if arguments.device != "cuda" or not torch.cuda.is_available():
        raise RuntimeError("A34 requires one CUDA device; CPU fallback is forbidden")
    device = torch.device("cuda")
    identity = run_io.RunIdentity(
        experiment_id=EXPERIMENT_ID,
        configuration_sha256=state.configuration_sha256,
        source_sha256=state.source_sha256,
        input_archive_sha256=state.input_sha256,
    )
    if state.resume_checkpoint is None:
        run_io.create_new_run(state.run_directory)
    owner = run_io.OwnerLock.acquire(
        state.run_directory / OWNER_LOCK_DIRECTORY,
        {
            "experiment_id": EXPERIMENT_ID,
            "identity_sha256": state.identity_sha256,
            "pid": os.getpid(),
            "hostname": socket.gethostname(),
            "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
            "device": arguments.device,
            "resume_checkpoint": str(state.resume_checkpoint) if state.resume_checkpoint else None,
        },
    )
    events_path = state.run_directory / EVENT_FILE
    events = _read_events(events_path) if state.resume_checkpoint else []
    termination_requested = threading.Event()
    termination_metadata: dict[str, Any] = {}

    def request_recoverable_stop(signum: int, _frame: Any) -> None:
        if not termination_requested.is_set():
            termination_metadata.update(
                {
                    "signal_number": int(signum),
                    "signal_name": signal.Signals(signum).name,
                    "received_at_utc": datetime.now(timezone.utc)
                    .isoformat()
                    .replace("+00:00", "Z"),
                }
            )
        termination_requested.set()

    previous_sigterm_handler = signal.signal(signal.SIGTERM, request_recoverable_stop)
    try:
        identity_path = state.run_directory / IDENTITY_FILE
        identity_bytes = canonical_json_bytes({**state.identity, "identity_sha256": state.identity_sha256})
        if state.resume_checkpoint is None:
            run_io.atomic_write_bytes(identity_path, identity_bytes, replace=False)
        elif identity_path.read_bytes() != identity_bytes:
            raise ValueError("resume identity changed")
        _append_event(run_io, events_path, events, {"event_type": "preflight_completed"})

        resume_state = None
        if state.resume_checkpoint is None:
            ledger = AccessLedger()
        else:
            resume_state = run_io.load_resume_checkpoint(state.resume_checkpoint, identity)
            saved = dict(resume_state.access_ledger)
            ledger = AccessLedger(
                raw_source_byte_reads=int(saved["raw_source_byte_reads"]),
                archive_materialization_sessions=int(saved["archive_materialization_sessions"]),
                archive_member_reads=dict(saved["archive_member_reads"]),
                evaluation_array_reads=int(saved["evaluation_array_reads"]),
                evaluation_predictions=int(saved["evaluation_predictions"]),
                evaluation_metrics=int(saved["evaluation_metrics"]),
                evaluation_outputs=int(saved["evaluation_outputs"]),
            )
            _append_event(
                run_io,
                events_path,
                events,
                {
                    "event_type": "resume_checkpoint_loaded",
                    "epoch": int(resume_state.completed_epoch),
                    "checkpoint_sha256": sha256_file(state.resume_checkpoint),
                },
            )
        ledger.begin_materialization_session()
        contract = DailyFullStateKNetContract.from_dict(state.configuration)
        basin_arrays = []
        for basin_id in BASIN_IDS:
            basin_arrays.append(
                load_daily_selection_archive(
                    state.input_paths[basin_id], INPUT_SHA256[basin_id], contract, ledger
                )
            )
        scales = fit_shared_training_discharge_scales(
            {arrays.basin_id: arrays.observations for arrays in basin_arrays},
            training_start_index=0,
            validation_start_index=2557,
        )
        scale_sha256 = training_scale_evidence_sha256(scales)
        scale_payload = {
            "schema_version": "daily_camels_training_scale_evidence_v1",
            "experiment_id": EXPERIMENT_ID,
            "training_scale_evidence_sha256": scale_sha256,
            "scales": asdict(scales),
        }
        scale_path = state.run_directory / TRAINING_SCALE_FILE
        scale_bytes = canonical_json_bytes(scale_payload)
        if state.resume_checkpoint is None:
            run_io.atomic_write_bytes(scale_path, scale_bytes, replace=False)
        elif scale_path.read_bytes() != scale_bytes:
            raise ValueError("resume training scales changed")
        basins = [prepare_full_state_daily_basin(arrays, contract, device) for arrays in basin_arrays]
        if tuple(basin.active_lag for basin in basins) != (2, 13):
            raise ValueError("the two frozen basin routing lags must remain 2 and 13")

        settings = dict(state.configuration["training"])
        model = state.configuration["model"]
        settings.update(
            {
                "hidden_dimension": model["hidden_dimension"],
                "input_multiplier": model["input_multiplier"],
                "output_multiplier": model["output_multiplier"],
                "gain_head_weight_multiplier": model["gain_head_initialization"]["final_weight_multiplier"],
            }
        )
        previous_sha256 = None
        checkpoint_records: dict[int, tuple[Path, str]] = {}
        strict_zero_max_abs = math.nan
        if resume_state is not None and state.resume_checkpoint is not None:
            completed_resume_epoch = int(resume_state.completed_epoch)
            for prior_epoch in range(completed_resume_epoch + 1):
                prior_checkpoint = _regular(
                    _checkpoint_path(state.run_directory, prior_epoch),
                    f"epoch {prior_epoch} checkpoint",
                )
                prior_validation = _regular(
                    _validation_path(state.run_directory, prior_epoch),
                    f"epoch {prior_epoch} validation predictions",
                )
                unit_complete = _regular(
                    prior_checkpoint.parent / "unit_complete.json",
                    f"epoch {prior_epoch} unit marker",
                )
                unit_payload = json.loads(unit_complete.read_text(encoding="utf-8"))
                if int(unit_payload.get("epoch", -1)) != prior_epoch:
                    raise ValueError("resume epoch-unit identity changed")
                if unit_payload.get("checkpoint_sha256") != sha256_file(prior_checkpoint):
                    raise ValueError("resume epoch-unit checkpoint hash changed")
                if unit_payload.get("validation_predictions_sha256") != sha256_file(prior_validation):
                    raise ValueError("resume epoch-unit prediction hash changed")
                if prior_epoch == 0:
                    strict_arrays = _regular(
                        prior_checkpoint.parent / STRICT_ZERO_ARRAY_FILE,
                        "strict-zero arrays",
                    )
                    strict_metrics = _regular(
                        prior_checkpoint.parent / STRICT_ZERO_METRICS_FILE,
                        "strict-zero metrics",
                    )
                    if unit_payload.get("strict_zero_arrays_sha256") != sha256_file(
                        strict_arrays
                    ):
                        raise ValueError("resume strict-zero array hash changed")
                    if unit_payload.get("strict_zero_metrics_sha256") != sha256_file(
                        strict_metrics
                    ):
                        raise ValueError("resume strict-zero metrics hash changed")
                    strict_zero_max_abs = _strict_zero_difference(
                        np, strict_arrays, strict_metrics
                    )
                elif any(
                    key in unit_payload
                    for key in ("strict_zero_arrays_sha256", "strict_zero_metrics_sha256")
                ):
                    raise ValueError("strict-zero evidence is only permitted in epoch zero")
                loaded_prior = run_io.load_resume_checkpoint(prior_checkpoint, identity)
                if int(loaded_prior.completed_epoch) != prior_epoch:
                    raise ValueError("resume checkpoint epoch changed")
                if loaded_prior.previous_checkpoint_sha256 != previous_sha256:
                    raise ValueError("resume checkpoint predecessor chain changed")
                prior_sha256 = sha256_file(prior_checkpoint)
                checkpoint_records[prior_epoch] = (prior_checkpoint, prior_sha256)
                previous_sha256 = prior_sha256
            if state.resume_checkpoint != _checkpoint_path(
                state.run_directory, completed_resume_epoch
            ):
                raise ValueError("resume checkpoint is not the latest complete epoch unit")

        strict_metrics_path = (
            state.run_directory
            / EPOCH_UNIT_DIRECTORY
            / "epoch_000"
            / STRICT_ZERO_METRICS_FILE
        )
        strict_arrays_path = strict_metrics_path.with_name(STRICT_ZERO_ARRAY_FILE)
        if strict_metrics_path.exists() or strict_arrays_path.exists():
            if resume_state is None:
                raise FileExistsError("strict-zero evidence exists before epoch-zero publication")
            strict_zero_max_abs = _strict_zero_difference(
                np, strict_arrays_path, strict_metrics_path
            )

        def checkpoint_callback(training_result: Any) -> None:
            nonlocal previous_sha256, strict_zero_max_abs
            epoch = int(training_result.completed_epoch)
            unit_root = state.run_directory / EPOCH_UNIT_DIRECTORY
            unit_root.mkdir(parents=True, exist_ok=True)
            final_unit = unit_root / f"epoch_{epoch:03d}"
            if final_unit.exists():
                raise FileExistsError(f"epoch unit already exists: {final_unit}")
            staging_unit = unit_root / (
                f".epoch_{epoch:03d}.staging_{os.getpid()}_{time.time_ns()}"
            )
            staging_unit.mkdir(parents=False, exist_ok=False)
            staging_checkpoint = staging_unit / "checkpoint.pt"
            checkpoint, checkpoint_sha256 = _save_checkpoint(
                run_io,
                np,
                torch,
                state=state,
                training_result=training_result,
                access_ledger=asdict(ledger),
                training_scale_sha256=scale_sha256,
                previous_sha256=previous_sha256,
                checkpoint_path=staging_checkpoint,
            )
            with torch.no_grad():
                metrics, arrays = full_state_validation_artifact(
                    training_result.network,
                    basins,
                    training_loss_scales=scales,
                    validation_window_days=128,
                    filter_warmup_days=16,
                )
            validation_path = staging_unit / "validation_predictions.npz"
            validation_sha256 = run_io.atomic_write_bytes(
                validation_path,
                _npz_bytes(np, arrays),
                replace=False,
            )
            strict_arrays_sha256 = None
            strict_metrics_sha256 = None
            if epoch == 0 and not strict_metrics_path.exists():
                control = strict_zero_control_network(training_result.network)
                control.eval()
                with torch.no_grad():
                    control_metrics, control_arrays = full_state_validation_artifact(
                        control,
                        basins,
                        training_loss_scales=scales,
                        validation_window_days=128,
                        filter_warmup_days=16,
                    )
                strict_zero_max_abs = float(
                    np.max(np.abs(control_arrays["prediction"] - control_arrays["open_loop"]))
                )
                strict_payload = {
                    "schema_version": "daily_camels_strict_zero_control_v1",
                    "experiment_id": EXPERIMENT_ID,
                    "open_loop_max_abs_difference": strict_zero_max_abs,
                    "metrics": control_metrics,
                }
                strict_arrays_sha256 = run_io.atomic_write_bytes(
                    staging_unit / STRICT_ZERO_ARRAY_FILE,
                    _npz_bytes(np, control_arrays),
                    replace=False,
                )
                strict_metrics_sha256 = run_io.atomic_write_bytes(
                    staging_unit / STRICT_ZERO_METRICS_FILE,
                    canonical_json_bytes(strict_payload),
                    replace=False,
                )
            unit_payload = {
                "schema_version": "daily_camels_native_full_state_epoch_unit_v1",
                "experiment_id": EXPERIMENT_ID,
                "identity_sha256": state.identity_sha256,
                "epoch": epoch,
                "previous_checkpoint_sha256": previous_sha256,
                "checkpoint_sha256": checkpoint_sha256,
                "validation_predictions_sha256": validation_sha256,
                "validation_loss": float(metrics["validation_loss"]),
            }
            if epoch == 0:
                if strict_arrays_sha256 is None or strict_metrics_sha256 is None:
                    raise RuntimeError("epoch zero lacks strict-zero evidence hashes")
                unit_payload["strict_zero_arrays_sha256"] = strict_arrays_sha256
                unit_payload["strict_zero_metrics_sha256"] = strict_metrics_sha256
            run_io.atomic_write_bytes(
                staging_unit / "unit_complete.json",
                canonical_json_bytes(unit_payload),
                replace=False,
            )
            os.replace(staging_unit, final_unit)
            final_checkpoint = final_unit / "checkpoint.pt"
            final_validation = final_unit / "validation_predictions.npz"
            previous_sha256 = checkpoint_sha256
            checkpoint_records[epoch] = (final_checkpoint, checkpoint_sha256)
            _append_event(
                run_io,
                events_path,
                events,
                {
                    "event_type": "epoch_unit_completed",
                    "epoch": epoch,
                    "checkpoint": final_checkpoint.relative_to(state.run_directory).as_posix(),
                    "checkpoint_sha256": checkpoint_sha256,
                    "validation_predictions": final_validation.relative_to(state.run_directory).as_posix(),
                    "validation_predictions_sha256": validation_sha256,
                    "training_record": dict(training_result.history[-1]),
                    "recomputed_validation_loss": float(metrics["validation_loss"]),
                },
            )

        training_result = train_daily_native_full_state_knet(
            basins,
            settings,
            device=device,
            training_loss_scales=scales,
            training_scale_evidence_sha256=scale_sha256,
            resume_state=resume_state,
            checkpoint_callback=checkpoint_callback,
            stop_requested=termination_requested.is_set,
        )
        if termination_requested.is_set():
            raise RecoverableTrainingStop("scheduler termination requested after training")
        if set(checkpoint_records) != set(range(0, 5)):
            raise RuntimeError("all five epoch checkpoints are required")
        selected_epoch = int(training_result.best_epoch)
        selected_checkpoint = _checkpoint_path(state.run_directory, selected_epoch)
        trainable_names = tuple(name for name, parameter in training_result.network.named_parameters() if parameter.requires_grad)
        gate = _independent_gate(
            training_result.history,
            asdict(ledger),
            a20_reference_summary=state.a20_reference_summary,
            selected_epoch=selected_epoch,
            trainable_names=trainable_names,
            strict_zero_max_abs_difference=strict_zero_max_abs,
        )
        access_path = state.run_directory / ACCESS_LEDGER_FILE
        run_io.atomic_write_bytes(access_path, canonical_json_bytes(asdict(ledger)), replace=access_path.exists())
        summary = {
            "schema_version": "daily_camels_native_full_state_result_v1",
            "experiment_id": EXPERIMENT_ID,
            "status": "COMPLETED" if gate["passed"] else "HARD_STOP",
            "science_gate": gate,
            "selected_checkpoint": selected_checkpoint.relative_to(state.run_directory).as_posix(),
            "selected_validation_predictions": _validation_path(state.run_directory, selected_epoch).relative_to(state.run_directory).as_posix(),
            "training_scale_evidence_sha256": scale_sha256,
            "a20_reference_sha256": state.a20_reference_sha256,
            "scientific_limitations": dict(state.configuration["scientific_limitations"]),
            "recoverable_stop_attempt_count": len(
                list((state.run_directory / ATTEMPT_STOP_DIRECTORY).glob("attempt_*.json"))
            ),
            "all_recoverable_stop_attempts_resolved": True,
            "history": [dict(row) for row in training_result.history],
        }
        summary_path = state.run_directory / SUMMARY_FILE
        run_io.atomic_write_bytes(summary_path, canonical_json_bytes(summary), replace=summary_path.exists())
        _append_event(
            run_io,
            events_path,
            events,
            {"event_type": "completed" if gate["passed"] else "hard_stop", "reasons": gate["reasons"]},
        )
        manifest = _manifest(state.run_directory)
        manifest_path = state.run_directory / MANIFEST_FILE
        manifest_sha256 = run_io.atomic_write_bytes(
            manifest_path, canonical_json_bytes(manifest), replace=manifest_path.exists()
        )
        if not gate["passed"]:
            return 3
        completion = {
            "schema_version": "daily_camels_native_full_state_completion_v1",
            "experiment_id": EXPERIMENT_ID,
            "status": "COMPLETED",
            "manifest_sha256": manifest_sha256,
            "summary_sha256": sha256_file(summary_path),
            "selected_epoch": selected_epoch,
            "selected_checkpoint_sha256": sha256_file(selected_checkpoint),
            "selected_validation_predictions_sha256": sha256_file(
                _validation_path(state.run_directory, selected_epoch)
            ),
        }
        run_io.atomic_write_bytes(
            state.run_directory / COMPLETION_FILE,
            canonical_json_bytes(completion),
            replace=False,
        )
        return 0
    except RecoverableTrainingStop as exc:
        latest_checkpoint = _latest_complete_checkpoint(state.run_directory)
        _append_event(
            run_io,
            events_path,
            events,
            {
                "event_type": "sigterm",
                "stop_classification": "RECOVERABLE_STOP",
                "message": str(exc),
                "latest_complete_checkpoint": latest_checkpoint.relative_to(
                    state.run_directory
                ).as_posix(),
                "latest_complete_checkpoint_sha256": sha256_file(latest_checkpoint),
                **termination_metadata,
            },
        )
        classification = run_io.classify_stop(events, latest_checkpoint)
        if classification != run_io.RECOVERABLE_STOP:
            raise RuntimeError(
                f"recoverable-stop evidence classified as {classification}"
            ) from exc
        stop_payload = {
            "schema_version": "daily_camels_native_full_state_stop_v1",
            "experiment_id": EXPERIMENT_ID,
            "scope": "one_interrupted_process_attempt",
            "status": classification,
            "latest_complete_checkpoint": latest_checkpoint.relative_to(
                state.run_directory
            ).as_posix(),
            "latest_complete_checkpoint_sha256": sha256_file(latest_checkpoint),
            "resume_required_for_this_attempt": True,
            **termination_metadata,
        }
        stop_directory = state.run_directory / ATTEMPT_STOP_DIRECTORY
        stop_directory.mkdir(parents=True, exist_ok=True)
        stop_path = stop_directory / f"attempt_{len(list(stop_directory.glob('attempt_*.json'))):03d}.json"
        run_io.atomic_write_bytes(
            stop_path,
            canonical_json_bytes(stop_payload),
            replace=False,
        )
        return 75
    except Exception as exc:
        try:
            _append_event(
                run_io,
                events_path,
                events,
                {
                    "event_type": "failure",
                    "stop_classification": "HARD_STOP",
                    "exception_type": type(exc).__name__,
                    "message": str(exc),
                },
            )
        except Exception:
            pass
        raise
    finally:
        signal.signal(signal.SIGTERM, previous_sigterm_handler)
        owner.release()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run the frozen A34 daily full-state smoke")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--run-root", type=Path, required=True)
    parser.add_argument("--resume", type=Path, default=None)
    parser.add_argument("--device", choices=("cuda",), default="cuda")
    parser.add_argument("--preflight-only", action="store_true")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    try:
        return execute(build_parser().parse_args(argv))
    except Exception as exc:
        print(
            canonical_json_bytes(
                {"status": "HARD_STOP", "error_type": type(exc).__name__, "message": str(exc)}
            ).decode("utf-8"),
            file=sys.stderr,
            end="",
        )
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
