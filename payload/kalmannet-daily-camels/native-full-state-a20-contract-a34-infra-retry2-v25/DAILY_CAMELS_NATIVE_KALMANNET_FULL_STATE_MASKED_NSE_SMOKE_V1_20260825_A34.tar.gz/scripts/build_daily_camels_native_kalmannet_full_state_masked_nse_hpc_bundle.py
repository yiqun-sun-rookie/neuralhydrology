"""Build one deterministic daily A34 KalmanNet high-performance-computing bundle."""

from __future__ import annotations

import argparse
import gzip
from hashlib import sha256
import io
import json
from pathlib import Path, PurePosixPath
import sys
import tarfile
from typing import Any, Mapping


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from global_hydrology.experiments.daily_camels_native_knet_full_state_masked_nse_contract import (  # noqa: E402
    A20_RESULT_PATH,
    A20_RESULT_SHA256,
    BASIN_IDS,
    EXPERIMENT_ID,
    EXPECTED_SOURCE_PATHS,
    INPUT_SHA256,
    validate_a20_reference_summary,
    validate_exact_configuration,
)


SCHEMA_VERSION = "daily_camels_native_full_state_hpc_bundle_v1"
CONFIG_RELATIVE = (
    "configs/daily_camels_native_kalmannet_full_state_masked_nse_smoke_v1.json"
)
SUPPORT_PATHS = (
    "hpc/daily_camels_native_kalmannet_full_state_masked_nse/preflight.py",
    "hpc/daily_camels_native_kalmannet_full_state_masked_nse/submit_smoke_gpu.slurm",
    "hpc/daily_camels_native_kalmannet_full_state_masked_nse/verify_result.py",
    "scripts/build_daily_camels_native_kalmannet_full_state_masked_nse_hpc_bundle.py",
    "tests/test_daily_camels_native_knet_full_state_masked_nse_contract.py",
    "tests/test_daily_camels_native_knet_full_state_masked_nse_training.py",
    "tests/test_daily_camels_native_knet_full_state_result_verifier.py",
    "tests/test_daily_camels_native_knet_full_state_hpc_bundle.py",
    "docs/superpowers/plans/2026-08-25-daily-camels-native-full-state-a20-contract-smoke.md",
    "docs/plans/2026-08-25-daily-camels-physical-loss-a20-handoff.md",
)
PACKAGE_INITIALIZERS = (
    "scripts/__init__.py",
    "knet/__init__.py",
    "knet/dl/__init__.py",
    "src/global_hydrology/__init__.py",
    "src/global_hydrology/experiments/__init__.py",
    "src/global_hydrology/models/__init__.py",
)


def canonical_json_bytes(value: object) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
        + b"\n"
    )


def sha256_bytes(value: bytes) -> str:
    return sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path: Path) -> Mapping[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, Mapping):
        raise TypeError(f"JSON root is not an object: {path}")
    return value


def safe_member_name(name: str) -> None:
    path = PurePosixPath(name)
    lowered = tuple(part.lower() for part in path.parts)
    if "\\" in name or path.is_absolute() or not path.parts or ".." in path.parts:
        raise ValueError(f"unsafe bundle member name: {name}")
    if ".git" in lowered or "__pycache__" in lowered or any(
        token in name.lower()
        for token in ("hourly", "reserved_evaluation", "evaluation_input", "evaluation_data")
    ):
        raise ValueError(f"forbidden bundle member name: {name}")


def source_members(configuration: Mapping[str, Any]) -> dict[str, bytes]:
    configured_sources = configuration["source_sha256"]
    if tuple(configured_sources) != EXPECTED_SOURCE_PATHS:
        raise ValueError("configuration source closure differs from the frozen contract")
    members: dict[str, bytes] = {}
    for relative in EXPECTED_SOURCE_PATHS:
        path = ROOT / relative
        content = path.read_bytes()
        if sha256_bytes(content) != configured_sources[relative]:
            raise ValueError(f"configured source SHA-256 differs: {relative}")
        members[relative] = content
    return members


def build_members() -> tuple[dict[str, bytes], Mapping[str, Any]]:
    config_path = ROOT / CONFIG_RELATIVE
    configuration = load_json(config_path)
    validate_exact_configuration(configuration)
    members = source_members(configuration)
    members[CONFIG_RELATIVE] = config_path.read_bytes()

    for relative in SUPPORT_PATHS:
        path = ROOT / relative
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(f"bundle support source is absent: {relative}")
        members[relative] = path.read_bytes()
    for relative in PACKAGE_INITIALIZERS:
        # The repository initializers import the full development tree.  The
        # bundle deliberately contains only the frozen A34 dependency closure,
        # so its package initializers must remain inert and cannot widen that
        # closure through environment-dependent imports.
        members[relative] = b""

    a20_path = ROOT / A20_RESULT_PATH
    if sha256_file(a20_path) != A20_RESULT_SHA256:
        raise ValueError("A20 reference result SHA-256 differs")
    validate_a20_reference_summary(load_json(a20_path))
    members[A20_RESULT_PATH] = a20_path.read_bytes()

    for archive in configuration["data"]["input_archives"]:
        basin_id = str(archive["basin_id"])
        if basin_id not in BASIN_IDS:
            raise ValueError(f"unexpected basin in A34 config: {basin_id}")
        source = ROOT / str(archive["local_evidence_path"])
        bundled_source = ROOT / "inputs" / f"basin_{basin_id}.npz"
        if not source.is_file() and bundled_source.is_file():
            source = bundled_source
        if sha256_file(source) != INPUT_SHA256[basin_id]:
            raise ValueError(f"A34 input archive SHA-256 differs: {basin_id}")
        members[f"inputs/basin_{basin_id}.npz"] = source.read_bytes()

    for name in members:
        safe_member_name(name)
    files = {
        name: {"sha256": sha256_bytes(content), "size_bytes": len(content)}
        for name, content in sorted(members.items())
    }
    manifest = {
        "schema_version": SCHEMA_VERSION,
        "experiment_id": EXPERIMENT_ID,
        "purpose": "daily_two_basin_full_state_development_smoke_only",
        "file_count": len(files),
        "files": files,
        "configuration_member": CONFIG_RELATIVE,
        "configuration_sha256": sha256_file(config_path),
        "source_sha256": dict(configuration["source_sha256"]),
        "input_archive_sha256": dict(INPUT_SHA256),
        "a20_reference_member": A20_RESULT_PATH,
        "a20_reference_sha256": A20_RESULT_SHA256,
        "daily_only": True,
        "formal_evaluation_enabled": False,
        "hourly_payload_member_count": 0,
        "reserved_evaluation_payload_member_count": 0,
        "embedded_prior_state_members_retained_but_forbidden_from_materialization": True,
        "resource_admission": {
            "provisional_host_free_threshold_bytes": 5_734_154_240,
            "provisional_cuda_free_threshold_bytes": 738_197_504,
            "threshold_basis": "four_times_measured_A33_host_RSS_and_A32_reserved_CUDA_peaks",
            "fresh_A34_cgroup_and_GPU_peak_evidence_required_before_expansion": True,
        },
    }
    return members, manifest


def write_deterministic_archive(
    path: Path, members: Mapping[str, bytes], manifest: Mapping[str, Any]
) -> None:
    complete = {**members, "bundle_manifest.json": canonical_json_bytes(manifest)}
    temporary = path.with_name(path.name + ".partial")
    with temporary.open("xb") as raw:
        with gzip.GzipFile(
            fileobj=raw, mode="wb", filename="", mtime=0, compresslevel=9
        ) as compressed:
            with tarfile.open(
                fileobj=compressed, mode="w", format=tarfile.USTAR_FORMAT
            ) as archive:
                for name in sorted(complete):
                    content = complete[name]
                    information = tarfile.TarInfo(name=name)
                    information.size = len(content)
                    information.mtime = 0
                    information.uid = 0
                    information.gid = 0
                    information.uname = ""
                    information.gname = ""
                    information.mode = 0o700 if name.endswith(".slurm") else 0o600
                    archive.addfile(information, io.BytesIO(content))
    temporary.replace(path)


def verify_archive(path: Path, manifest: Mapping[str, Any]) -> None:
    with tarfile.open(path, mode="r:gz") as archive:
        records = archive.getmembers()
        names = {record.name for record in records}
        expected = set(manifest["files"]) | {"bundle_manifest.json"}
        if names != expected or any(not record.isfile() for record in records):
            raise ValueError("deterministic archive file closure changed")
        internal = json.loads(archive.extractfile("bundle_manifest.json").read())
        if internal != manifest:
            raise ValueError("archive manifest content changed")
        for name, record in manifest["files"].items():
            safe_member_name(name)
            if sha256_bytes(archive.extractfile(name).read()) != record["sha256"]:
                raise ValueError(f"archive member SHA-256 changed: {name}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-directory", type=Path, required=True)
    arguments = parser.parse_args()
    output = arguments.output_directory.resolve()
    if output.exists():
        raise FileExistsError(f"bundle output directory already exists: {output}")
    output.mkdir(parents=True, exist_ok=False)
    members, manifest = build_members()
    archive_name = f"{EXPERIMENT_ID}.tar.gz"
    archive_path = output / archive_name
    write_deterministic_archive(archive_path, members, manifest)
    verify_archive(archive_path, manifest)
    outer = {
        "schema_version": "daily_camels_native_full_state_outer_bundle_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "archive_name": archive_name,
        "archive_sha256": sha256_file(archive_path),
        "archive_size_bytes": archive_path.stat().st_size,
        "internal_manifest_sha256": sha256_bytes(canonical_json_bytes(manifest)),
        "file_count": manifest["file_count"],
        "daily_only": True,
        "formal_evaluation_enabled": False,
    }
    (output / "bundle_manifest.sha256.json").write_bytes(canonical_json_bytes(outer))
    print(canonical_json_bytes(outer).decode("utf-8"), end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
