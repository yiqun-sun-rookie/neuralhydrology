"""Daily, equal-basin native KalmanNet training with the formal shared loss.

The physical HBV-light state includes the basin-specific routed queue.  The
original KalmanNet core is deliberately built at ``m=5`` and can therefore
change only the five storages.  Every optimizer step contains one equal-length
segment from every configured basin.  Training and checkpoint selection both
use the same frozen daily shared MaskedNSELoss numerical contract.
"""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import copy
import math
import random
import time
from typing import Any, Callable, Mapping, Sequence

import numpy as np
import torch

from global_hydrology.experiments.daily_camels_masked_nse_loss_contract import (
    CONTRACT_NAME as MASKED_NSE_CONTRACT_NAME,
    SharedTrainingDischargeScales,
    training_scale_evidence_sha256 as compute_training_scale_evidence_sha256,
)
from global_hydrology.experiments.daily_camels_masked_nse_loss_torch import (
    daily_camels_masked_nse_tensor_loss,
)


N_STORAGE = 5


@dataclass(frozen=True)
class ForecastRecord:
    """One causal forecast issued after assimilating the origin observation."""

    prediction: torch.Tensor
    forcing_indices: tuple[int, ...]
    target_index: int


@dataclass
class FilterTrace:
    """Differentiable filter trajectory and update diagnostics."""

    start: int
    end: int
    prior_states: torch.Tensor
    posterior_states: torch.Tensor
    gains: torch.Tensor
    requested_storage_corrections: torch.Tensor
    realized_storage_corrections: torch.Tensor
    routed_queue_corrections: torch.Tensor
    innovations: torch.Tensor
    valid_updates: torch.Tensor
    projected_storage_fraction: torch.Tensor


@dataclass
class TrainingResult:
    """In-memory result needed by the atomic persistence layer."""

    network: torch.nn.Module
    optimizer: torch.optim.Optimizer
    scheduler: Any | None
    current_model_state: dict[str, torch.Tensor]
    current_optimizer_state: dict[str, Any]
    completed_epoch: int
    history: list[dict[str, Any]]
    epoch_zero: dict[str, Any]
    best_epoch: int
    best_selection_score: float
    best_model_state: dict[str, torch.Tensor]
    sampler_generator_state: torch.Tensor
    cumulative_optimizer_steps: int
    sampled_forecast_events: int
    nonzero_gradient_parameter_names: tuple[str, ...]
    training_scale_evidence_sha256: str


@dataclass(frozen=True)
class MultiBasinMaskedNSEBatch:
    """One differentiable equal-basin, equal-lead optimizer objective."""

    loss: torch.Tensor
    basin_ids: tuple[str, ...]
    events_per_basin_lead: int
    forecast_target_count: int
    per_basin_loss: Mapping[str, torch.Tensor]
    per_basin_lead_loss: Mapping[str, Mapping[int, torch.Tensor]]
    per_basin_lead_physical_mse: Mapping[
        str, Mapping[int, torch.Tensor]
    ]


def _as_device_tensor(value: Any, reference: torch.Tensor) -> torch.Tensor:
    return torch.as_tensor(value, device=reference.device, dtype=reference.dtype)


def _initial_state_before(basin: Any, start: int) -> torch.Tensor:
    if start < 0 or start > len(basin.forcing):
        raise ValueError("segment start is outside the daily record")
    if start == 0:
        return basin.initial_state.clone()
    return basin.open_loop_states[start - 1].clone()


def _project_storage_update(basin: Any, prior: torch.Tensor, proposed: torch.Tensor) -> torch.Tensor:
    """Project storages while copying the routed queue exactly from the prior."""

    if prior.ndim != 2 or prior.shape[0] != 1 or prior.shape[1] < N_STORAGE:
        raise ValueError("routed HBV state must have shape [1, m>=5]")
    if proposed.shape != prior[:, :N_STORAGE].shape:
        raise ValueError("proposed storage shape differs from the five-storage state")
    frozen_upper = _as_device_tensor(basin.state_upper_bound, prior).reshape(1, -1)[
        :, :N_STORAGE
    ]
    # The training-only upper bound limits a learned positive correction; it
    # must never alter an already-physical HBV prior when the learned gain is
    # zero.  This preserves the epoch-zero/open-loop identity even if a
    # validation snow or groundwater prior exceeds the training maximum.
    effective_upper = torch.maximum(frozen_upper, prior[:, :N_STORAGE])
    storage = torch.maximum(
        torch.minimum(proposed, effective_upper), torch.zeros_like(proposed)
    )
    field_capacity = _as_device_tensor(basin.field_capacity, prior).reshape(1, 1)
    storage = torch.cat(
        [storage[:, :2], torch.minimum(storage[:, 2:3], field_capacity), storage[:, 3:]],
        dim=1,
    )
    return torch.cat([storage, prior[:, N_STORAGE:]], dim=1)


def _finite_previous_observation(basin: Any, start: int, initial_state: torch.Tensor) -> torch.Tensor:
    observations = basin.observations
    for index in range(start - 1, -1, -1):
        value = observations[index]
        if bool(torch.isfinite(value)):
            return value.reshape(1, 1)
    return basin.system.h(initial_state).reshape(1, 1)


def run_storage_filter(net: Any, basin: Any, start: int, end: int) -> FilterTrace:
    """Filter ``[start, end)`` with a five-storage gain and a physical routed queue."""

    if not (0 <= start < end <= len(basin.forcing)):
        raise ValueError("invalid daily filter interval")
    if int(getattr(net, "m", N_STORAGE)) != N_STORAGE or int(getattr(net, "n", 1)) != 1:
        raise ValueError("native daily KalmanNet must have m=5 and n=1")
    initial = _initial_state_before(basin, start).to(basin.forcing)
    net.init_hidden(1)
    x_post = initial
    x_post_previous = initial
    x_prior_previous = initial
    y_previous = _finite_previous_observation(basin, start, initial).to(initial)
    observation_scale = _as_device_tensor(basin.observation_diff_scale, initial).reshape(1, 1)
    storage_scale = _as_device_tensor(basin.storage_diff_scale, initial).reshape(1, N_STORAGE)
    guard = float(getattr(basin, "normalized_feature_guard", 10.0))

    priors: list[torch.Tensor] = []
    posteriors: list[torch.Tensor] = []
    gains: list[torch.Tensor] = []
    requested: list[torch.Tensor] = []
    realized: list[torch.Tensor] = []
    queue_changes: list[torch.Tensor] = []
    innovations: list[torch.Tensor] = []
    valid_updates: list[bool] = []
    projected_fractions: list[torch.Tensor] = []

    for day in range(start, end):
        prior = basin.system.f(x_post, basin.forcing[day : day + 1])
        if not bool(torch.isfinite(prior).all()):
            raise FloatingPointError(f"nonfinite HBV prior on daily index {day}")
        y_prior = basin.system.h(prior).reshape(1, 1)
        posterior = prior
        gain = torch.zeros(1, N_STORAGE, 1, device=prior.device, dtype=prior.dtype)
        requested_correction = torch.zeros(1, N_STORAGE, device=prior.device, dtype=prior.dtype)
        innovation = torch.full((1, 1), torch.nan, device=prior.device, dtype=prior.dtype)
        projected_fraction = torch.zeros((), device=prior.device, dtype=prior.dtype)
        valid = bool(torch.isfinite(basin.observations[day]))
        if valid:
            observation = basin.observations[day].reshape(1, 1).to(prior)
            innovation = observation - y_prior
            observation_difference = (observation - y_previous) / observation_scale
            normalized_innovation = innovation / observation_scale
            forward_evolution = (
                x_post[:, :N_STORAGE] - x_post_previous[:, :N_STORAGE]
            ) / storage_scale
            forward_update = (
                x_post[:, :N_STORAGE] - x_prior_previous[:, :N_STORAGE]
            ) / storage_scale
            gain = net.compute_gain_native(
                observation_difference,
                normalized_innovation,
                forward_evolution,
                forward_update,
                guard=guard,
            )
            if gain.shape != (1, N_STORAGE, 1) or not bool(torch.isfinite(gain).all()):
                raise FloatingPointError("native KalmanNet returned an invalid five-storage gain")
            requested_correction = gain.squeeze(-1) * normalized_innovation * storage_scale
            posterior = _project_storage_update(
                basin, prior, prior[:, :N_STORAGE] + requested_correction
            )
            realized_correction = posterior[:, :N_STORAGE] - prior[:, :N_STORAGE]
            projected_fraction = (
                (realized_correction - requested_correction).abs() > 1e-10
            ).to(prior.dtype).mean()
            x_post_previous = x_post
            x_prior_previous = prior
            x_post = posterior
            y_previous = observation
        else:
            realized_correction = torch.zeros_like(requested_correction)
            x_post_previous = x_post
            x_prior_previous = prior
            x_post = prior
        queue_correction = posterior[:, N_STORAGE:] - prior[:, N_STORAGE:]
        if queue_correction.numel() and bool(torch.count_nonzero(queue_correction)):
            raise RuntimeError("routed queue correction must remain zero")
        priors.append(prior)
        posteriors.append(posterior)
        gains.append(gain)
        requested.append(requested_correction)
        realized.append(realized_correction)
        queue_changes.append(queue_correction)
        innovations.append(innovation)
        valid_updates.append(valid)
        projected_fractions.append(projected_fraction)

    queue_width = basin.initial_state.shape[-1] - N_STORAGE
    routed = (
        torch.stack(queue_changes)
        if queue_width
        else torch.empty(end - start, 1, 0, device=initial.device, dtype=initial.dtype)
    )
    return FilterTrace(
        start=start,
        end=end,
        prior_states=torch.stack(priors),
        posterior_states=torch.stack(posteriors),
        gains=torch.stack(gains),
        requested_storage_corrections=torch.stack(requested),
        realized_storage_corrections=torch.stack(realized),
        routed_queue_corrections=routed,
        innovations=torch.stack(innovations),
        valid_updates=torch.tensor(valid_updates, device=initial.device, dtype=torch.bool),
        projected_storage_fraction=torch.stack(projected_fractions),
    )


def forecast_from_analysis(
    basin: Any,
    analysis_state: torch.Tensor,
    origin: int,
    leads: tuple[int, ...] = (1, 2, 3),
) -> dict[int, ForecastRecord]:
    """Use only target-day meteorological forcing after the analysis origin."""

    if tuple(sorted(set(leads))) != tuple(leads) or not leads or min(leads) < 1:
        raise ValueError("forecast leads must be unique, increasing positive integers")
    if origin < 0 or origin + max(leads) >= len(basin.forcing):
        raise ValueError("forecast origin does not have all requested daily leads")
    state = analysis_state
    output: dict[int, ForecastRecord] = {}
    forcing_indices: list[int] = []
    for step in range(1, max(leads) + 1):
        target = origin + step
        forcing_indices.append(target)
        state = basin.system.f(state, basin.forcing[target : target + 1])
        if step in leads:
            output[step] = ForecastRecord(
                prediction=basin.system.h(state).reshape(()),
                forcing_indices=tuple(forcing_indices),
                target_index=target,
            )
    return output


def nash_sutcliffe_efficiency(targets: Sequence[float], predictions: Sequence[float]) -> float:
    targets_array = np.asarray(targets, dtype=float)
    predictions_array = np.asarray(predictions, dtype=float)
    common = np.isfinite(targets_array) & np.isfinite(predictions_array)
    if int(common.sum()) < 2:
        return float("nan")
    selected = targets_array[common]
    denominator = float(np.mean((selected - float(np.mean(selected))) ** 2))
    if denominator <= 0.0 or not math.isfinite(denominator):
        return float("nan")
    return 1.0 - float(np.mean((predictions_array[common] - selected) ** 2)) / denominator


def selection_score(knet_nse: Mapping[int, float], ar2_nse: Mapping[int, float]) -> float:
    if set(knet_nse) != {1, 2, 3} or set(ar2_nse) != {1, 2, 3}:
        raise ValueError("selection metrics must contain daily leads 1, 2, and 3")
    gains = [float(knet_nse[lead]) - float(ar2_nse[lead]) for lead in (1, 2, 3)]
    if not all(math.isfinite(value) for value in gains):
        return float("-inf")
    return float(np.mean(gains))


def _ar2_prediction(basin: Any, origin: int, lead: int) -> float:
    coefficient_source = basin.ar2_coefficients
    if torch.is_tensor(coefficient_source):
        coefficient_source = coefficient_source.detach().cpu().numpy()
    coefficients = np.asarray(coefficient_source, dtype=float).reshape(2)
    open_loop = np.asarray(
        basin.open_loop_discharge.detach().cpu().numpy(), dtype=float
    ).reshape(-1)
    observations = np.asarray(basin.observations.detach().cpu().numpy(), dtype=float).reshape(-1)
    first = observations[origin] - open_loop[origin]
    second = observations[origin - 1] - open_loop[origin - 1]
    if not math.isfinite(first):
        first = 0.0
    if not math.isfinite(second):
        second = first
    for _ in range(lead):
        predicted = float(coefficients[0] * first + coefficients[1] * second)
        second, first = first, predicted
    return float(open_loop[origin + lead] + first)


def masked_nse_multilead_segment_pairs(
    basin: Any,
    trace: FilterTrace,
    *,
    filter_warmup_days: int,
    leads: tuple[int, ...] = (1, 2, 3),
) -> tuple[torch.Tensor, torch.Tensor]:
    """Return complete physical-unit forecast pairs shaped ``[3, event]``."""

    if filter_warmup_days < 0:
        raise ValueError("filter warm-up must be nonnegative")
    if tuple(leads) != (1, 2, 3):
        raise ValueError("the shared daily loss requires leads one, two, and three")
    predictions: dict[int, list[torch.Tensor]] = {lead: [] for lead in leads}
    targets: dict[int, list[torch.Tensor]] = {lead: [] for lead in leads}
    for offset, analysis in enumerate(trace.posterior_states):
        origin = trace.start + offset
        if origin < trace.start + filter_warmup_days or origin + max(leads) >= trace.end:
            continue
        forecasts = forecast_from_analysis(basin, analysis, origin, leads)
        for lead in leads:
            prediction = forecasts[lead].prediction
            target = basin.observations[forecasts[lead].target_index]
            if not bool(torch.isfinite(prediction)):
                raise FloatingPointError("daily forecast prediction is nonfinite")
            if not bool(torch.isfinite(target)):
                raise FloatingPointError(
                    "complete-record daily forecast target is nonfinite"
                )
            predictions[lead].append(prediction)
            targets[lead].append(target)
    counts = {lead: len(values) for lead, values in predictions.items()}
    if not counts or min(counts.values()) < 1 or len(set(counts.values())) != 1:
        raise ValueError("every daily lead must contain the same positive event count")
    return (
        torch.stack([torch.stack(predictions[lead]) for lead in leads]),
        torch.stack([torch.stack(targets[lead]) for lead in leads]),
    )


def multibasin_masked_nse_step_loss(
    basins: Sequence[Any],
    traces: Sequence[FilterTrace],
    scales: SharedTrainingDischargeScales,
    *,
    filter_warmup_days: int,
    leads: tuple[int, ...] = (1, 2, 3),
) -> MultiBasinMaskedNSEBatch:
    """Build one strict equal-basin objective before an optimizer update."""

    if not basins or len(basins) != len(traces):
        raise ValueError("one filter trace is required for every training basin")
    basin_ids = tuple(str(getattr(basin, "basin_id", "")) for basin in basins)
    if not all(basin_ids) or len(set(basin_ids)) != len(basin_ids):
        raise ValueError("training basin identifiers must be unique and non-empty")
    if basin_ids != tuple(scales.basin_ids):
        raise ValueError("training basin order differs from the frozen scale order")

    prediction_rows: list[torch.Tensor] = []
    target_rows: list[torch.Tensor] = []
    for basin, trace in zip(basins, traces, strict=True):
        prediction, target = masked_nse_multilead_segment_pairs(
            basin,
            trace,
            filter_warmup_days=filter_warmup_days,
            leads=leads,
        )
        prediction_rows.append(prediction)
        target_rows.append(target)
    geometries = {tuple(value.shape) for value in prediction_rows}
    if len(geometries) != 1:
        raise ValueError("all basin segments must have identical forecast geometry")

    prediction_tensor = torch.stack(prediction_rows)
    target_tensor = torch.stack(target_rows)
    basin_standard_deviation = prediction_tensor.new_tensor(
        [
            scales.per_basin[basin_id].population_std_original_discharge_units
            for basin_id in basin_ids
        ]
    )
    result = daily_camels_masked_nse_tensor_loss(
        prediction_tensor,
        target_tensor,
        basin_standard_deviation,
    )
    per_basin_loss = {
        basin_id: result.per_basin_lead_loss[index].mean()
        for index, basin_id in enumerate(basin_ids)
    }
    per_basin_lead_loss = {
        basin_id: {
            lead: result.per_basin_lead_loss[basin_index, lead_index]
            for lead_index, lead in enumerate(leads)
        }
        for basin_index, basin_id in enumerate(basin_ids)
    }
    physical_mse_tensor = (prediction_tensor - target_tensor).square().mean(dim=2)
    if not bool(torch.isfinite(physical_mse_tensor).all()):
        raise FloatingPointError("per-basin and per-lead physical MSE is nonfinite")
    per_basin_lead_physical_mse = {
        basin_id: {
            lead: physical_mse_tensor[basin_index, lead_index]
            for lead_index, lead in enumerate(leads)
        }
        for basin_index, basin_id in enumerate(basin_ids)
    }
    events_per_cell = int(prediction_tensor.shape[2])
    return MultiBasinMaskedNSEBatch(
        loss=result.total_loss,
        basin_ids=basin_ids,
        events_per_basin_lead=events_per_cell,
        forecast_target_count=len(basin_ids) * len(leads) * events_per_cell,
        per_basin_loss=per_basin_loss,
        per_basin_lead_loss=per_basin_lead_loss,
        per_basin_lead_physical_mse=per_basin_lead_physical_mse,
    )


def validation_metrics(
    net: Any,
    basins: Sequence[Any],
    *,
    training_loss_scales: SharedTrainingDischargeScales,
    validation_window_days: int,
    filter_warmup_days: int,
) -> dict[str, Any]:
    """Score and select checkpoints with the same frozen shared loss."""

    basin_order = tuple(str(getattr(basin, "basin_id", "")) for basin in basins)
    if basin_order != tuple(training_loss_scales.basin_ids):
        raise ValueError("validation basin order differs from training scale order")
    routed_max = 0.0
    projected: list[float] = []
    per_basin: dict[str, dict[str, Any]] = {}
    for basin_index, basin in enumerate(basins):
        basin_id = str(getattr(basin, "basin_id", basin_index))
        if basin_id in per_basin:
            raise ValueError(f"duplicate validation basin identity: {basin_id}")
        targets: dict[int, list[float]] = {lead: [] for lead in (1, 2, 3)}
        knet_predictions: dict[int, list[float]] = {
            lead: [] for lead in (1, 2, 3)
        }
        ar2_predictions: dict[int, list[float]] = {
            lead: [] for lead in (1, 2, 3)
        }
        open_loop_predictions: dict[int, list[float]] = {
            lead: [] for lead in (1, 2, 3)
        }
        persistence_predictions: dict[int, list[float]] = {
            lead: [] for lead in (1, 2, 3)
        }
        start = int(basin.validation_start_index)
        end = min(len(basin.forcing), start + int(validation_window_days))
        if end - start <= filter_warmup_days + 3:
            raise ValueError("fixed validation window is too short")
        trace = run_storage_filter(net, basin, start, end)
        gain_abs_by_storage = (
            trace.gains.squeeze(-1).abs().mean(dim=(0, 1)).detach().cpu().tolist()
        )
        requested_abs_by_storage = (
            trace.requested_storage_corrections.abs()
            .mean(dim=(0, 1))
            .detach()
            .cpu()
            .tolist()
        )
        realized_abs_by_storage = (
            trace.realized_storage_corrections.abs()
            .mean(dim=(0, 1))
            .detach()
            .cpu()
            .tolist()
        )
        projected_by_storage = (
            (
                trace.realized_storage_corrections
                - trace.requested_storage_corrections
            )
            .abs()
            .gt(1e-10)
            .to(trace.realized_storage_corrections.dtype)
            .mean(dim=(0, 1))
            .detach()
            .cpu()
            .tolist()
        )
        basin_routed_max = 0.0
        if trace.routed_queue_corrections.numel():
            basin_routed_max = float(
                trace.routed_queue_corrections.abs().max().detach().cpu()
            )
            routed_max = max(routed_max, basin_routed_max)
        basin_projected = trace.projected_storage_fraction.detach().cpu().tolist()
        projected.extend(basin_projected)
        for offset, analysis in enumerate(trace.posterior_states):
            origin = start + offset
            if origin < start + filter_warmup_days or origin + 3 >= end or origin < 1:
                continue
            forecasts = forecast_from_analysis(basin, analysis, origin)
            for lead, record in forecasts.items():
                target = float(basin.observations[record.target_index].detach().cpu())
                prediction = float(record.prediction.detach().cpu())
                if not math.isfinite(prediction):
                    raise FloatingPointError("validation forecast prediction is nonfinite")
                if not math.isfinite(target):
                    raise FloatingPointError(
                        "complete-record validation target is nonfinite"
                    )
                targets[lead].append(target)
                knet_predictions[lead].append(prediction)
                ar2_predictions[lead].append(
                    _ar2_prediction(basin, origin, lead)
                )
                open_loop_predictions[lead].append(
                    float(basin.open_loop_discharge[record.target_index].detach().cpu())
                )
                origin_observation = float(
                    basin.observations[origin].detach().cpu()
                )
                persistence_predictions[lead].append(origin_observation)

        target_counts = {lead: len(targets[lead]) for lead in (1, 2, 3)}
        if min(target_counts.values(), default=0) < 1 or len(
            set(target_counts.values())
        ) != 1:
            raise ValueError("validation requires equal positive target counts by lead")
        prediction_tensor = basin.observations.new_tensor(
            [[knet_predictions[lead] for lead in (1, 2, 3)]]
        )
        target_tensor = basin.observations.new_tensor(
            [[targets[lead] for lead in (1, 2, 3)]]
        )
        loss_result = daily_camels_masked_nse_tensor_loss(
            prediction_tensor,
            target_tensor,
            basin.observations.new_tensor(
                [
                    training_loss_scales.per_basin[
                        basin_id
                    ].population_std_original_discharge_units
                ]
            ),
        )
        basin_validation_loss = float(loss_result.total_loss.detach().cpu())
        physical_mse_tensor = (prediction_tensor - target_tensor).square().mean(dim=2)
        if not bool(torch.isfinite(physical_mse_tensor).all()):
            raise FloatingPointError(
                "validation per-basin and per-lead physical MSE is nonfinite"
            )
        basin_loss_by_lead = {
            lead: float(loss_result.per_basin_lead_loss[0, index].detach().cpu())
            for index, lead in enumerate((1, 2, 3))
        }
        basin_physical_mse_by_lead = {
            lead: float(physical_mse_tensor[0, index].detach().cpu())
            for index, lead in enumerate((1, 2, 3))
        }
        per_lead_loss_evidence = {
            lead: {
                "event_count": int(target_counts[lead]),
                "physical_mse": basin_physical_mse_by_lead[lead],
                "primary_loss": basin_loss_by_lead[lead],
            }
            for lead in (1, 2, 3)
        }
        if not all(
            math.isfinite(float(value[key]))
            for value in per_lead_loss_evidence.values()
            for key in ("physical_mse", "primary_loss")
        ):
            raise FloatingPointError("validation loss evidence is nonfinite")

        basin_knet = {
            lead: nash_sutcliffe_efficiency(
                targets[lead], knet_predictions[lead]
            )
            for lead in (1, 2, 3)
        }
        basin_ar2 = {
            lead: nash_sutcliffe_efficiency(targets[lead], ar2_predictions[lead])
            for lead in (1, 2, 3)
        }
        basin_open_loop = {
            lead: nash_sutcliffe_efficiency(
                targets[lead], open_loop_predictions[lead]
            )
            for lead in (1, 2, 3)
        }
        basin_persistence = {
            lead: nash_sutcliffe_efficiency(
                targets[lead], persistence_predictions[lead]
            )
            for lead in (1, 2, 3)
        }
        basin_gain_over_ar2 = {
            lead: basin_knet[lead] - basin_ar2[lead] for lead in (1, 2, 3)
        }
        per_basin[basin_id] = {
            "knet_nse": basin_knet,
            "ar2_nse": basin_ar2,
            "open_loop_nse": basin_open_loop,
            "persistence_nse": basin_persistence,
            "gain_over_ar2": basin_gain_over_ar2,
            "selection_score": -basin_validation_loss,
            "worst_lead_gain_over_ar2": min(basin_gain_over_ar2.values()),
            "validation_loss": basin_validation_loss,
            "primary_loss": basin_validation_loss,
            "masked_nse_loss_by_lead": basin_loss_by_lead,
            "per_lead_loss_evidence": per_lead_loss_evidence,
            "target_count_by_lead": target_counts,
            "routed_queue_correction_abs_max": basin_routed_max,
            "projected_storage_fraction_mean": (
                float(np.mean(basin_projected)) if basin_projected else 0.0
            ),
            "gain_abs_mean_by_storage": gain_abs_by_storage,
            "requested_storage_correction_abs_mean_by_storage": (
                requested_abs_by_storage
            ),
            "realized_storage_correction_abs_mean_by_storage": (
                realized_abs_by_storage
            ),
            "projected_fraction_by_storage": projected_by_storage,
        }

    knet: dict[int, float] = {}
    ar2: dict[int, float] = {}
    gain_over_ar2: dict[int, float] = {}
    open_loop: dict[int, float] = {}
    persistence: dict[int, float] = {}
    for lead in (1, 2, 3):
        eligible_pairs = [
            (float(metrics["knet_nse"][lead]), float(metrics["ar2_nse"][lead]))
            for metrics in per_basin.values()
            if math.isfinite(float(metrics["knet_nse"][lead]))
            and math.isfinite(float(metrics["ar2_nse"][lead]))
        ]
        if not eligible_pairs:
            knet[lead] = ar2[lead] = gain_over_ar2[lead] = float("nan")
        else:
            knet[lead] = float(np.mean([pair[0] for pair in eligible_pairs]))
            ar2[lead] = float(np.mean([pair[1] for pair in eligible_pairs]))
            gain_over_ar2[lead] = float(
                np.mean([pair[0] - pair[1] for pair in eligible_pairs])
            )
        for destination, key in (
            (open_loop, "open_loop_nse"),
            (persistence, "persistence_nse"),
        ):
            values = [
                float(metrics[key][lead])
                for metrics in per_basin.values()
                if math.isfinite(float(metrics[key][lead]))
            ]
            destination[lead] = float(np.mean(values)) if values else float("nan")

    basin_losses = [
        float(metrics["validation_loss"]) for metrics in per_basin.values()
    ]
    if len(basin_losses) != len(per_basin) or not basin_losses or not all(
        math.isfinite(value) for value in basin_losses
    ):
        raise FloatingPointError("validation basin primary loss is nonfinite")
    shared_validation_loss = float(np.mean(basin_losses))
    storage_diagnostics = {
        key: np.mean(
            np.asarray([metrics[key] for metrics in per_basin.values()], dtype=float),
            axis=0,
        ).tolist()
        for key in (
            "gain_abs_mean_by_storage",
            "requested_storage_correction_abs_mean_by_storage",
            "realized_storage_correction_abs_mean_by_storage",
            "projected_fraction_by_storage",
        )
    }
    return {
        "knet_nse": knet,
        "ar2_nse": ar2,
        "open_loop_nse": open_loop,
        "persistence_nse": persistence,
        "gain_over_ar2": gain_over_ar2,
        "selection_score": -shared_validation_loss,
        "worst_lead_gain_over_ar2": min(gain_over_ar2.values()),
        "validation_loss": shared_validation_loss,
        "primary_loss": shared_validation_loss,
        "target_count_by_lead": {
            lead: sum(
                int(metrics["target_count_by_lead"][lead])
                for metrics in per_basin.values()
            )
            for lead in (1, 2, 3)
        },
        "routed_queue_correction_abs_max": routed_max,
        "projected_storage_fraction_mean": float(np.mean(projected)) if projected else 0.0,
        "basin_aggregation": "equal_weight_mean_of_per_basin_metrics",
        "per_basin": per_basin,
        **storage_diagnostics,
    }


def parameter_sha256(module: torch.nn.Module) -> str:
    digest = sha256()
    for name, tensor in sorted(module.state_dict().items()):
        array = tensor.detach().cpu().contiguous().numpy()
        digest.update(name.encode("utf-8"))
        digest.update(str(array.dtype).encode("ascii"))
        digest.update(np.asarray(array.shape, dtype=np.int64).tobytes())
        digest.update(array.tobytes())
    return digest.hexdigest()


def _memory_snapshot(device: torch.device) -> tuple[int | None, int]:
    host = None
    try:
        import psutil

        host = int(psutil.Process().memory_info().rss)
    except (ImportError, OSError):
        pass
    gpu = int(torch.cuda.max_memory_allocated(device)) if device.type == "cuda" else 0
    return host, gpu


def _resume_attribute(state: Any, name: str) -> Any:
    if isinstance(state, Mapping):
        if name not in state:
            raise ValueError(f"resume state is missing {name}")
        return state[name]
    if not hasattr(state, name):
        raise ValueError(f"resume state is missing {name}")
    return getattr(state, name)


def _restore_random_states(state: Any, device: torch.device) -> None:
    random.setstate(_resume_attribute(state, "python_random_state"))
    numpy_state = _resume_attribute(state, "numpy_bit_generator_state")
    if not isinstance(numpy_state, tuple):
        raise TypeError("resume NumPy random state must come from numpy.random.get_state()")
    np.random.set_state(numpy_state)
    cpu_state = _resume_attribute(state, "torch_cpu_random_state")
    torch.set_rng_state(torch.as_tensor(cpu_state, device="cpu", dtype=torch.uint8))
    cuda_states = list(_resume_attribute(state, "torch_cuda_random_states"))
    if device.type == "cuda":
        if not cuda_states:
            raise ValueError("CUDA resume requires saved CUDA random states")
        torch.cuda.set_rng_state_all(
            [torch.as_tensor(value, device="cpu", dtype=torch.uint8) for value in cuda_states]
        )
    elif cuda_states:
        raise ValueError("CPU resume may not contain CUDA random states")


def _training_snapshot(
    *,
    network: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    scheduler: Any | None,
    completed_epoch: int,
    history: list[dict[str, Any]],
    epoch_zero: dict[str, Any],
    best_epoch: int,
    best_score: float,
    best_state: dict[str, torch.Tensor],
    sampler: torch.Generator,
    cumulative_steps: int,
    event_count: int,
    nonzero_names: set[str],
    training_scale_evidence_sha256: str,
) -> TrainingResult:
    return TrainingResult(
        network=network,
        optimizer=optimizer,
        scheduler=scheduler,
        current_model_state=copy.deepcopy(network.state_dict()),
        current_optimizer_state=copy.deepcopy(optimizer.state_dict()),
        completed_epoch=int(completed_epoch),
        history=list(history),
        epoch_zero=dict(epoch_zero),
        best_epoch=int(best_epoch),
        best_selection_score=float(best_score),
        best_model_state=copy.deepcopy(best_state),
        sampler_generator_state=sampler.get_state().clone(),
        cumulative_optimizer_steps=int(cumulative_steps),
        sampled_forecast_events=int(event_count),
        nonzero_gradient_parameter_names=tuple(sorted(nonzero_names)),
        training_scale_evidence_sha256=training_scale_evidence_sha256,
    )


def train_daily_native_knet(
    basins: Sequence[Any],
    settings: Mapping[str, Any],
    *,
    device: torch.device,
    training_loss_scales: SharedTrainingDischargeScales,
    training_scale_evidence_sha256: str,
    resume_state: Any | None = None,
    checkpoint_callback: Callable[[TrainingResult], None] | None = None,
    network_factory: Callable[..., torch.nn.Module] | None = None,
) -> TrainingResult:
    """Train one shared five-storage native KalmanNet under the frozen smoke budget."""

    if not basins:
        raise ValueError("daily training basins are empty")
    if not isinstance(training_loss_scales, SharedTrainingDischargeScales):
        raise TypeError("training loss scales use an unexpected contract type")
    if training_loss_scales.contract_name != MASKED_NSE_CONTRACT_NAME:
        raise ValueError("training loss scale contract name changed")
    basin_ids = tuple(str(getattr(basin, "basin_id", "")) for basin in basins)
    if basin_ids != tuple(training_loss_scales.basin_ids):
        raise ValueError("training basin order differs from training scale order")
    evidence_sha256 = str(training_scale_evidence_sha256).lower()
    if len(evidence_sha256) != 64 or any(
        value not in "0123456789abcdef" for value in evidence_sha256
    ):
        raise ValueError("training scale evidence SHA-256 is invalid")
    if evidence_sha256 != compute_training_scale_evidence_sha256(
        training_loss_scales
    ):
        raise ValueError("training scale evidence SHA-256 does not match its scales")
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")
    seed = int(settings["seed"])
    if resume_state is None:
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        if device.type == "cuda":
            torch.cuda.manual_seed_all(seed)
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    if network_factory is None:
        from global_hydrology.models.knet_native_hbvlite import build_storage_net

        network_factory = build_storage_net

    net = network_factory(
        device=device,
        dtype=torch.float32,
        n_storage=N_STORAGE,
        zero_gain_init=bool(settings["zero_gain_initialization"]),
        hidden=int(settings["hidden_dimension"]),
        in_mult=int(settings["input_multiplier"]),
        out_mult=int(settings["output_multiplier"]),
    ).to(device)
    optimizer = torch.optim.Adam(
        net.parameters(),
        lr=float(settings["learning_rate"]),
        weight_decay=float(settings["weight_decay"]),
    )
    scheduler = None
    sampler = torch.Generator(device="cpu").manual_seed(seed + 1)
    validation_days = int(settings["validation_window_days"])
    filter_warmup = int(settings["filter_warmup_days"])
    segment_days = int(settings["segment_days"])
    start_clock = time.perf_counter()

    if resume_state is None:
        net.eval()
        with torch.no_grad():
            initial_metrics = validation_metrics(
                net,
                basins,
                training_loss_scales=training_loss_scales,
                validation_window_days=validation_days,
                filter_warmup_days=filter_warmup,
            )
        host_peak, gpu_peak = _memory_snapshot(device)
        epoch_zero = {
            "epoch": 0,
            "optimizer_steps": 0,
            "sampled_forecast_events": 0,
            "training_loss": None,
            "training_scale_evidence_sha256": evidence_sha256,
            **initial_metrics,
            "parameter_sha256": parameter_sha256(net),
            "finite_gradients": None,
            "nonzero_gradient_parameter_tensor_count": 0,
            "nonzero_gradient_parameter_names": [],
            "training_units": [],
            "elapsed_seconds": time.perf_counter() - start_clock,
            "host_resident_memory_bytes": host_peak,
            "gpu_peak_memory_bytes": gpu_peak,
        }
        history: list[dict[str, Any]] = [epoch_zero]
        best_epoch = 0
        best_score = float(epoch_zero["selection_score"])
        best_state = copy.deepcopy(net.state_dict())
        cumulative_steps = 0
        event_count = 0
        nonzero_names: set[str] = set()
        completed_epoch = 0
        if checkpoint_callback is not None:
            checkpoint_callback(
                _training_snapshot(
                    network=net,
                    optimizer=optimizer,
                    scheduler=scheduler,
                    completed_epoch=completed_epoch,
                    history=history,
                    epoch_zero=epoch_zero,
                    best_epoch=best_epoch,
                    best_score=best_score,
                    best_state=best_state,
                    sampler=sampler,
                    cumulative_steps=cumulative_steps,
                    event_count=event_count,
                    nonzero_names=nonzero_names,
                    training_scale_evidence_sha256=evidence_sha256,
                )
            )
    else:
        completed_epoch = int(_resume_attribute(resume_state, "completed_epoch"))
        history = [dict(row) for row in _resume_attribute(resume_state, "history")]
        epoch_zero = dict(_resume_attribute(resume_state, "epoch_zero_record"))
        if not history or int(history[0].get("epoch", -1)) != 0:
            raise ValueError("resume history must begin with epoch zero")
        if int(history[-1].get("epoch", -1)) != completed_epoch:
            raise ValueError("resume history does not end at completed_epoch")
        net.load_state_dict(_resume_attribute(resume_state, "model_state"), strict=True)
        optimizer.load_state_dict(_resume_attribute(resume_state, "optimizer_state"))
        if _resume_attribute(resume_state, "scheduler_state") is not None:
            raise ValueError("the frozen daily smoke has no scheduler state")
        sampler.set_state(
            torch.as_tensor(
                _resume_attribute(resume_state, "sampler_generator_state"),
                device="cpu",
                dtype=torch.uint8,
            )
        )
        best_payload = _resume_attribute(
            resume_state, "best_post_zero_checkpoint"
        )
        if not isinstance(best_payload, Mapping):
            raise TypeError("resume best checkpoint metadata must be a mapping")
        required_best = {"epoch", "selection_score", "model_state"}
        if not required_best.issubset(best_payload):
            raise ValueError("resume best checkpoint metadata is incomplete")
        best_epoch = int(best_payload["epoch"])
        best_score = float(best_payload["selection_score"])
        best_state = copy.deepcopy(best_payload["model_state"])
        cumulative_steps = int(
            _resume_attribute(resume_state, "cumulative_optimizer_steps")
        )
        event_count = int(_resume_attribute(resume_state, "sampled_forecast_events"))
        nonzero_names = set(
            str(name)
            for name in _resume_attribute(
                resume_state, "nonzero_gradient_parameter_names"
            )
        )
        if int(history[-1].get("optimizer_steps", -1)) != cumulative_steps:
            raise ValueError("resume optimizer step count differs from history")
        if int(history[-1].get("sampled_forecast_events", -1)) != event_count:
            raise ValueError("resume forecast event count differs from history")
        history_nonzero_names = {
            str(name)
            for row in history
            for name in row.get("nonzero_gradient_parameter_names", [])
        }
        if history_nonzero_names != nonzero_names:
            raise ValueError("resume nonzero gradient names differ from history")
        history_scale_hashes = {
            str(row.get("training_scale_evidence_sha256", "")) for row in history
        }
        if history_scale_hashes != {evidence_sha256}:
            raise ValueError("resume training scale evidence SHA-256 changed")
        _restore_random_states(resume_state, device)

    target_epochs = int(settings["epochs"])
    if target_epochs < completed_epoch:
        raise ValueError("configured epoch budget is below the resumed epoch")

    for epoch in range(completed_epoch + 1, target_epochs + 1):
        net.train()
        losses: list[float] = []
        finite_gradients = True
        training_units: list[dict[str, Any]] = []
        for step_in_epoch in range(int(settings["steps_per_epoch"])):
            traces: list[FilterTrace] = []
            step_units: list[dict[str, Any]] = []
            for basin_index, basin in enumerate(basins):
                lower = int(basin.training_start_index)
                upper = int(basin.validation_start_index) - segment_days
                if upper < lower:
                    raise ValueError("daily training interval cannot fit one segment")
                start = int(
                    torch.randint(lower, upper + 1, (1,), generator=sampler).item()
                )
                end = start + segment_days
                if not (
                    0
                    <= start
                    < end
                    <= int(training_loss_scales.validation_start_index)
                ):
                    raise ValueError(
                        "training segment must satisfy 0 <= start < end <= "
                        "the frozen validation boundary"
                    )
                traces.append(run_storage_filter(net, basin, start, end))
                step_units.append(
                    {
                        "step_in_epoch": step_in_epoch,
                        "basin_index": basin_index,
                        "basin_id": str(getattr(basin, "basin_id", basin_index)),
                        "start_index": start,
                        "end_index_exclusive": end,
                    }
                )
            batch = multibasin_masked_nse_step_loss(
                basins,
                traces,
                training_loss_scales,
                filter_warmup_days=filter_warmup,
            )
            loss = batch.loss
            if not bool(torch.isfinite(loss)):
                raise FloatingPointError("daily KalmanNet training loss is nonfinite")
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            for name, parameter in net.named_parameters():
                if parameter.grad is None:
                    continue
                if not bool(torch.isfinite(parameter.grad).all()):
                    finite_gradients = False
                elif bool(torch.count_nonzero(parameter.grad)):
                    nonzero_names.add(name)
            if not finite_gradients:
                raise FloatingPointError("daily KalmanNet gradient is nonfinite")
            gradient_norm = torch.nn.utils.clip_grad_norm_(
                net.parameters(), float(settings.get("gradient_maximum_norm", 10.0))
            )
            if not bool(torch.isfinite(gradient_norm)):
                raise FloatingPointError("daily KalmanNet gradient norm is nonfinite")
            optimizer.step()
            cumulative_steps += 1
            event_count += batch.forecast_target_count
            losses.append(float(loss.detach().cpu()))
            per_basin_event_count = 3 * batch.events_per_basin_lead
            for unit in step_units:
                basin_id = str(unit["basin_id"])
                per_lead_loss_evidence = {
                    lead: {
                        "event_count": batch.events_per_basin_lead,
                        "physical_mse": float(
                            batch.per_basin_lead_physical_mse[basin_id][lead]
                            .detach()
                            .cpu()
                        ),
                        "primary_loss": float(
                            batch.per_basin_lead_loss[basin_id][lead]
                            .detach()
                            .cpu()
                        ),
                    }
                    for lead in (1, 2, 3)
                }
                if not all(
                    math.isfinite(float(value[key]))
                    for value in per_lead_loss_evidence.values()
                    for key in ("physical_mse", "primary_loss")
                ):
                    raise FloatingPointError("training loss evidence is nonfinite")
                basin_primary_loss = float(
                    batch.per_basin_loss[basin_id].detach().cpu()
                )
                if not math.isfinite(basin_primary_loss):
                    raise FloatingPointError("training basin primary loss is nonfinite")
                unit["forecast_target_count"] = per_basin_event_count
                unit["masked_nse_loss"] = basin_primary_loss
                unit["primary_loss"] = basin_primary_loss
                unit["per_lead_loss_evidence"] = per_lead_loss_evidence
            training_units.extend(step_units)

        net.eval()
        with torch.no_grad():
            metrics = validation_metrics(
                net,
                basins,
                training_loss_scales=training_loss_scales,
                validation_window_days=validation_days,
                filter_warmup_days=filter_warmup,
            )
        score = float(metrics["selection_score"])
        if score > best_score:
            best_score = score
            best_epoch = epoch
            best_state = copy.deepcopy(net.state_dict())
        host_memory, gpu_memory = _memory_snapshot(device)
        record = {
            "epoch": epoch,
            "optimizer_steps": cumulative_steps,
            "sampled_forecast_events": event_count,
            "training_loss": float(np.mean(losses)),
            "training_scale_evidence_sha256": evidence_sha256,
            **metrics,
            "parameter_sha256": parameter_sha256(net),
            "finite_gradients": finite_gradients,
            "nonzero_gradient_parameter_tensor_count": len(nonzero_names),
            "nonzero_gradient_parameter_names": sorted(nonzero_names),
            "training_units": training_units,
            "elapsed_seconds": time.perf_counter() - start_clock,
            "host_resident_memory_bytes": host_memory,
            "gpu_peak_memory_bytes": gpu_memory,
        }
        history.append(record)
        if checkpoint_callback is not None:
            checkpoint_callback(
                _training_snapshot(
                    network=net,
                    optimizer=optimizer,
                    scheduler=scheduler,
                    completed_epoch=epoch,
                    history=history,
                    epoch_zero=epoch_zero,
                    best_epoch=best_epoch,
                    best_score=best_score,
                    best_state=best_state,
                    sampler=sampler,
                    cumulative_steps=cumulative_steps,
                    event_count=event_count,
                    nonzero_names=nonzero_names,
                    training_scale_evidence_sha256=evidence_sha256,
                )
            )

    return _training_snapshot(
        network=net,
        optimizer=optimizer,
        scheduler=scheduler,
        completed_epoch=target_epochs,
        history=history,
        epoch_zero=epoch_zero,
        best_epoch=best_epoch,
        best_score=best_score,
        best_state=best_state,
        sampler=sampler,
        cumulative_steps=cumulative_steps,
        event_count=event_count,
        nonzero_names=nonzero_names,
        training_scale_evidence_sha256=evidence_sha256,
    )
