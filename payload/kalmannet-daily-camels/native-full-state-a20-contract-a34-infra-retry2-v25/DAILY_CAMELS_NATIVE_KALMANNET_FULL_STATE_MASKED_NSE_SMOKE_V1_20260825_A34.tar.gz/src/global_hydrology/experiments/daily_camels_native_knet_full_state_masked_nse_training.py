"""A20-contract training with a complete common routed HBV state correction."""

from __future__ import annotations

import copy
import math
import random
import time
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Sequence

import numpy as np
import torch

from global_hydrology.experiments.daily_camels_masked_nse_loss_contract import (
    CONTRACT_NAME as MASKED_NSE_CONTRACT_NAME,
    SharedTrainingDischargeScales,
    training_scale_evidence_sha256 as compute_training_scale_evidence_sha256,
)
from global_hydrology.experiments.daily_camels_masked_nse_loss_torch import (
    daily_camels_masked_nse_tensor_loss,
)
from global_hydrology.experiments.daily_camels_native_knet_masked_nse_training import (
    TrainingResult,
    _ar2_prediction,
    _finite_previous_observation,
    _memory_snapshot,
    _restore_random_states,
    _resume_attribute,
    _training_snapshot,
    forecast_from_analysis,
    multibasin_masked_nse_step_loss,
    nash_sutcliffe_efficiency,
    parameter_sha256,
)
from global_hydrology.models.knet_native_hbvlite_full_state import (
    NativeHBVFullStateKalmanNet,
)


N_STORAGE = 5


class RecoverableTrainingStop(RuntimeError):
    """Requested scheduler stop after at least one atomic epoch checkpoint."""


class A20ProjectionNativeHBVFullStateKalmanNet(NativeHBVFullStateKalmanNet):
    """Full-state gain core with the historical A20 physical projection semantics."""

    def set_basin_adaptation(
        self,
        *,
        system: Any,
        correction_mask: torch.Tensor,
        state_lower_bound: torch.Tensor,
        state_upper_bound: torch.Tensor,
        observation_feature_scale: torch.Tensor,
        state_feature_scale: torch.Tensor,
        correction_cap_by_state_scale_units: torch.Tensor | None = None,
        normalized_feature_guard: float | None = 10.0,
    ) -> None:
        """Install immutable per-basin buffers without mutating an existing graph.

        One optimizer step sums both basin losses before calling ``backward``.
        Replacing registered buffers with detached clones keeps the first basin's
        graph valid while the shared recurrent parameters are reused for the
        second basin.
        """

        if int(system.m) != int(self.m) or int(system.n) != int(self.n):
            raise ValueError("basin system dimensions do not match the shared KalmanNet")
        self.f = system.f
        self.h = system.h

        def fresh(value: torch.Tensor, reference: torch.Tensor, shape: tuple[int, int]) -> torch.Tensor:
            return value.detach().to(reference).reshape(shape).clone()

        mask = fresh(correction_mask, self.correction_mask, (1, self.m))
        lower = fresh(state_lower_bound, self.state_lower_bound, (1, self.m))
        upper = fresh(state_upper_bound, self.state_upper_bound, (1, self.m))
        obs_scale = fresh(
            observation_feature_scale, self.observation_feature_scale, (1, self.n)
        )
        state_scale = fresh(state_feature_scale, self.state_feature_scale, (1, self.m))
        if correction_cap_by_state_scale_units is None:
            initial_cap = (
                torch.inf
                if self.correction_cap_in_state_scale_units is None
                else float(self.correction_cap_in_state_scale_units)
            )
            cap = torch.full_like(self.correction_cap_by_state_scale_units, initial_cap)
        else:
            cap = fresh(
                correction_cap_by_state_scale_units,
                self.correction_cap_by_state_scale_units,
                (1, self.m),
            )
        if bool(torch.isnan(lower).any()) or bool(torch.isnan(upper).any()):
            raise ValueError("state bounds must not contain NaN")
        if bool((lower >= upper).any()):
            raise ValueError("every state lower bound must be smaller than its upper bound")
        if not bool(torch.isfinite(obs_scale).all()) or bool((obs_scale <= 0.0).any()):
            raise ValueError("observation feature scales must be positive and finite")
        if not bool(torch.isfinite(state_scale).all()) or bool((state_scale <= 0.0).any()):
            raise ValueError("state feature scales must be positive and finite")
        if bool(torch.isnan(cap).any()) or bool((cap <= 0.0).any()):
            raise ValueError("correction caps must be positive and not NaN")

        self.correction_mask = mask
        self.state_lower_bound = lower
        self.state_upper_bound = upper
        self.observation_feature_scale = obs_scale
        self.state_feature_scale = state_scale
        self.correction_cap_by_state_scale_units = cap
        self.normalized_features_enabled = True
        self.normalized_feature_guard = normalized_feature_guard

    def _active_state_end(self) -> int:
        active = torch.nonzero(self.correction_mask.reshape(-1) > 0.0).reshape(-1)
        if active.numel() < N_STORAGE:
            raise ValueError("the full-state mask must authorize all five HBV storages")
        return int(active.max().item()) + 1

    def _physical_prior(self, state: torch.Tensor) -> torch.Tensor:
        state = torch.clamp(state, min=0.0)
        active_end = self._active_state_end()
        if active_end < self.m:
            state = torch.cat(
                [state[:, :active_end], torch.zeros_like(state[:, active_end:])],
                dim=1,
            )
        return state

    def _project_analysis(
        self, proposed: torch.Tensor, prior: torch.Tensor
    ) -> torch.Tensor:
        fixed_storage_upper = self.state_upper_bound[:, :N_STORAGE]
        effective_storage_upper = torch.maximum(fixed_storage_upper, prior[:, :N_STORAGE])
        storage = torch.maximum(
            torch.minimum(proposed[:, :N_STORAGE], effective_storage_upper),
            torch.zeros_like(proposed[:, :N_STORAGE]),
        )
        active_end = self._active_state_end()
        active_route = torch.clamp(proposed[:, N_STORAGE:active_end], min=0.0)
        inactive_tail = torch.zeros_like(proposed[:, active_end:])
        return torch.cat([storage, active_route, inactive_tail], dim=1)

    def step_prior(self, controls: torch.Tensor) -> None:
        self.m1x_prior = self._physical_prior(self.f(self.m1x_posterior, controls))
        self.m1y = self.h(self.m1x_prior)

    def predict_step(self, controls: torch.Tensor) -> torch.Tensor:
        """Match A20 missing-observation timing by retaining the last real discharge."""

        self.step_prior(controls)
        posterior = self.m1x_prior
        self.m1x_posterior_previous = self.m1x_posterior
        self.m1x_posterior = posterior
        self.m1x_prior_previous = self.m1x_prior
        self.last_correction = torch.zeros_like(posterior)
        self.last_gain = None
        return posterior

    def analysis_step(
        self, observation: torch.Tensor, controls: torch.Tensor
    ) -> torch.Tensor:
        self.step_prior(controls)
        observation = observation.reshape(self.batch_size, self.n)
        observation_3d = observation.unsqueeze(-1)
        if self.normalized_features_enabled:
            normalized_innovation = self._estimate_normalized_gain(observation)
            correction_in_scale_units = self.KGain.squeeze(-1) * normalized_innovation
            cap = self.correction_cap_by_state_scale_units
            correction_in_scale_units = torch.maximum(
                torch.minimum(correction_in_scale_units, cap), -cap
            )
            requested_correction = (
                correction_in_scale_units * self.state_feature_scale
            )
        else:
            self.estimate_gain(observation_3d)
            innovation = observation_3d - self.m1y.unsqueeze(-1)
            requested_correction = torch.bmm(self.KGain, innovation).squeeze(-1)
        requested_correction = requested_correction * self.correction_mask
        posterior = self._project_analysis(
            self.m1x_prior + requested_correction, self.m1x_prior
        )

        self.m1x_posterior_previous = self.m1x_posterior
        self.m1x_posterior = posterior
        self.m1x_prior_previous = self.m1x_prior
        self.y_previous = observation
        self.last_correction = requested_correction
        self.last_requested_correction = requested_correction
        self.last_realized_correction = posterior - self.m1x_prior
        self.last_gain = self.KGain
        return posterior


@dataclass
class FullStateFilterTrace:
    start: int
    end: int
    prior_states: torch.Tensor
    posterior_states: torch.Tensor
    gains: torch.Tensor
    requested_state_corrections: torch.Tensor
    realized_state_corrections: torch.Tensor
    innovations: torch.Tensor
    valid_updates: torch.Tensor
    projected_state_fraction: torch.Tensor


def initialize_a20_gain_head(
    net: A20ProjectionNativeHBVFullStateKalmanNet,
    *,
    weight_multiplier: float,
    strict_zero: bool = False,
) -> None:
    """Apply A20's actual near-zero initialization or the separate zero control."""

    if not math.isfinite(float(weight_multiplier)) or weight_multiplier <= 0.0:
        raise ValueError("gain-head weight multiplier must be positive and finite")
    head = net.FC2[-1]
    if not isinstance(head, torch.nn.Linear):
        raise TypeError("the native final gain head must remain a linear layer")
    with torch.no_grad():
        if strict_zero:
            head.weight.zero_()
        else:
            head.weight.mul_(float(weight_multiplier))
        head.bias.zero_()


def build_a20_full_state_network(
    reference: Any,
    settings: Mapping[str, Any],
    *,
    device: torch.device,
    strict_zero: bool = False,
) -> A20ProjectionNativeHBVFullStateKalmanNet:
    net = A20ProjectionNativeHBVFullStateKalmanNet(
        reference.system,
        correction_mask=reference.correction_mask,
        state_lower_bound=reference.state_lower_bound,
        state_upper_bound=reference.state_upper_bound,
        device=device,
        hidden=int(settings["hidden_dimension"]),
        in_mult=int(settings["input_multiplier"]),
        out_mult=int(settings["output_multiplier"]),
        correction_cap_in_state_scale_units=None,
    ).to(device=device, dtype=torch.float32)
    initialize_a20_gain_head(
        net,
        weight_multiplier=float(settings["gain_head_weight_multiplier"]),
        strict_zero=strict_zero,
    )
    return net


def _adapt_network(net: Any, basin: Any) -> None:
    net.set_basin_adaptation(
        system=basin.system,
        correction_mask=basin.correction_mask,
        state_lower_bound=basin.state_lower_bound,
        state_upper_bound=basin.state_upper_bound,
        observation_feature_scale=basin.observation_diff_scale,
        state_feature_scale=basin.state_diff_scale,
        correction_cap_by_state_scale_units=None,
        normalized_feature_guard=float(basin.normalized_feature_guard),
    )


def run_full_state_filter(
    net: Any, basin: Any, start: int, end: int
) -> FullStateFilterTrace:
    """Filter one daily interval with complete active-state correction authority."""

    if not (0 <= start < end <= len(basin.forcing)):
        raise ValueError("invalid daily filter interval")
    if int(getattr(net, "m", -1)) != int(basin.system.m) or int(net.n) != 1:
        raise ValueError("shared full-state KalmanNet dimensions differ from the basin")
    _adapt_network(net, basin)
    initial = basin.state_immediately_before(start).to(basin.forcing)
    previous = _finite_previous_observation(basin, start, initial).to(initial)
    net.initialize_filter(initial, end - start, previous_observation=previous)

    priors: list[torch.Tensor] = []
    posteriors: list[torch.Tensor] = []
    gains: list[torch.Tensor] = []
    requested: list[torch.Tensor] = []
    realized: list[torch.Tensor] = []
    innovations: list[torch.Tensor] = []
    valid_updates: list[bool] = []
    projected_fractions: list[torch.Tensor] = []
    for day in range(start, end):
        controls = basin.forcing[day : day + 1]
        valid = bool(torch.isfinite(basin.observations[day]))
        if valid:
            observation = basin.observations[day : day + 1].reshape(1, 1)
            posterior = net.analysis_step(observation, controls)
            prior = net.m1x_prior
            requested_correction = net.last_requested_correction
            realized_correction = net.last_realized_correction
            innovation = observation - net.m1y.reshape(1, 1)
            gain = net.last_gain
            projected = (
                (realized_correction - requested_correction).abs() > 1.0e-10
            ).to(prior.dtype).mean()
        else:
            posterior = net.predict_step(controls)
            prior = net.m1x_prior
            requested_correction = torch.zeros_like(prior)
            realized_correction = torch.zeros_like(prior)
            innovation = torch.full(
                (1, 1), torch.nan, dtype=prior.dtype, device=prior.device
            )
            gain = torch.zeros(
                (1, net.m, 1), dtype=prior.dtype, device=prior.device
            )
            projected = torch.zeros((), dtype=prior.dtype, device=prior.device)
        if not bool(torch.isfinite(posterior).all()):
            raise FloatingPointError(f"nonfinite full-state posterior on daily index {day}")
        active_end = N_STORAGE + int(basin.active_lag)
        if active_end < posterior.shape[1] and bool(
            torch.count_nonzero(posterior[:, active_end:])
        ):
            raise RuntimeError("inactive padded routing state must remain exactly zero")
        priors.append(prior)
        posteriors.append(posterior)
        gains.append(gain)
        requested.append(requested_correction)
        realized.append(realized_correction)
        innovations.append(innovation)
        valid_updates.append(valid)
        projected_fractions.append(projected)
    return FullStateFilterTrace(
        start=start,
        end=end,
        prior_states=torch.stack(priors),
        posterior_states=torch.stack(posteriors),
        gains=torch.stack(gains),
        requested_state_corrections=torch.stack(requested),
        realized_state_corrections=torch.stack(realized),
        innovations=torch.stack(innovations),
        valid_updates=torch.as_tensor(
            valid_updates, device=initial.device, dtype=torch.bool
        ),
        projected_state_fraction=torch.stack(projected_fractions),
    )


def full_state_validation_artifact(
    net: Any,
    basins: Sequence[Any],
    *,
    training_loss_scales: SharedTrainingDischargeScales,
    validation_window_days: int,
    filter_warmup_days: int,
) -> tuple[dict[str, Any], dict[str, np.ndarray]]:
    """Return JSON metrics and raw arrays for the first frozen validation window."""

    basin_ids = tuple(str(basin.basin_id) for basin in basins)
    if basin_ids != tuple(training_loss_scales.basin_ids):
        raise ValueError("validation basin order differs from the training scales")
    prediction_rows: list[torch.Tensor] = []
    target_rows: list[torch.Tensor] = []
    open_loop_rows: list[torch.Tensor] = []
    persistence_rows: list[torch.Tensor] = []
    ar2_rows: list[torch.Tensor] = []
    origin_rows: list[np.ndarray] = []
    trace_by_basin: dict[str, FullStateFilterTrace] = {}
    leads = (1, 2, 3)
    for basin in basins:
        start = int(basin.validation_start_index)
        end = start + int(validation_window_days)
        if end > len(basin.forcing):
            raise ValueError("the frozen validation window exceeds the daily record")
        trace = run_full_state_filter(net, basin, start, end)
        trace_by_basin[basin.basin_id] = trace
        predictions: dict[int, list[torch.Tensor]] = {lead: [] for lead in leads}
        targets: dict[int, list[torch.Tensor]] = {lead: [] for lead in leads}
        open_loop: dict[int, list[torch.Tensor]] = {lead: [] for lead in leads}
        persistence: dict[int, list[torch.Tensor]] = {lead: [] for lead in leads}
        ar2: dict[int, list[torch.Tensor]] = {lead: [] for lead in leads}
        origins: list[int] = []
        for offset, analysis in enumerate(trace.posterior_states):
            origin = start + offset
            if origin < start + filter_warmup_days or origin + max(leads) >= end:
                continue
            forecasts = forecast_from_analysis(basin, analysis, origin, leads)
            origins.append(origin)
            for lead in leads:
                target_index = forecasts[lead].target_index
                prediction = forecasts[lead].prediction
                target = basin.observations[target_index]
                if not bool(torch.isfinite(prediction)) or not bool(torch.isfinite(target)):
                    raise FloatingPointError("validation forecast pair is nonfinite")
                predictions[lead].append(prediction)
                targets[lead].append(target)
                open_loop[lead].append(basin.open_loop_discharge[target_index])
                persistence[lead].append(basin.observations[origin])
                ar2[lead].append(
                    prediction.new_tensor(_ar2_prediction(basin, origin, lead))
                )
        counts = {lead: len(predictions[lead]) for lead in leads}
        if set(counts.values()) != {109}:
            raise ValueError("each validation basin-lead cell must contain 109 targets")
        prediction_rows.append(
            torch.stack([torch.stack(predictions[lead]) for lead in leads])
        )
        target_rows.append(torch.stack([torch.stack(targets[lead]) for lead in leads]))
        open_loop_rows.append(
            torch.stack([torch.stack(open_loop[lead]) for lead in leads])
        )
        persistence_rows.append(
            torch.stack([torch.stack(persistence[lead]) for lead in leads])
        )
        ar2_rows.append(torch.stack([torch.stack(ar2[lead]) for lead in leads]))
        origin_rows.append(np.asarray(origins, dtype=np.int64))

    prediction_tensor = torch.stack(prediction_rows)
    target_tensor = torch.stack(target_rows)
    open_loop_tensor = torch.stack(open_loop_rows)
    persistence_tensor = torch.stack(persistence_rows)
    ar2_tensor = torch.stack(ar2_rows)
    basin_standard_deviation = prediction_tensor.new_tensor(
        [
            training_loss_scales.per_basin[basin_id].population_std_original_discharge_units
            for basin_id in basin_ids
        ]
    )
    loss_result = daily_camels_masked_nse_tensor_loss(
        prediction_tensor, target_tensor, basin_standard_deviation
    )
    physical_mse = (prediction_tensor - target_tensor).square().mean(dim=2)
    per_basin: dict[str, dict[str, Any]] = {}
    for basin_index, basin in enumerate(basins):
        basin_id = basin.basin_id
        trace = trace_by_basin[basin_id]
        knet_nse: dict[int, float] = {}
        open_nse: dict[int, float] = {}
        persistence_nse: dict[int, float] = {}
        ar2_nse: dict[int, float] = {}
        for lead_index, lead in enumerate(leads):
            target = target_tensor[basin_index, lead_index].detach().cpu().numpy()
            knet_nse[lead] = nash_sutcliffe_efficiency(
                target,
                prediction_tensor[basin_index, lead_index].detach().cpu().numpy(),
            )
            open_nse[lead] = nash_sutcliffe_efficiency(
                target,
                open_loop_tensor[basin_index, lead_index].detach().cpu().numpy(),
            )
            persistence_nse[lead] = nash_sutcliffe_efficiency(
                target,
                persistence_tensor[basin_index, lead_index].detach().cpu().numpy(),
            )
            ar2_nse[lead] = nash_sutcliffe_efficiency(
                target,
                ar2_tensor[basin_index, lead_index].detach().cpu().numpy(),
            )
        active_end = N_STORAGE + int(basin.active_lag)
        active_route = trace.realized_state_corrections[..., N_STORAGE:active_end]
        inactive_tail = trace.realized_state_corrections[..., active_end:]
        cell_loss = {
            lead: float(loss_result.per_basin_lead_loss[basin_index, lead_index])
            for lead_index, lead in enumerate(leads)
        }
        cell_mse = {
            lead: float(physical_mse[basin_index, lead_index])
            for lead_index, lead in enumerate(leads)
        }
        per_basin[basin_id] = {
            "validation_loss": float(loss_result.per_basin_lead_loss[basin_index].mean()),
            "primary_loss": float(loss_result.per_basin_lead_loss[basin_index].mean()),
            "selection_score": -float(
                loss_result.per_basin_lead_loss[basin_index].mean()
            ),
            "masked_nse_loss_by_lead": cell_loss,
            "per_lead_loss_evidence": {
                lead: {
                    "event_count": 109,
                    "physical_mse": cell_mse[lead],
                    "primary_loss": cell_loss[lead],
                }
                for lead in leads
            },
            "target_count_by_lead": {lead: 109 for lead in leads},
            "knet_nse": knet_nse,
            "open_loop_nse": open_nse,
            "persistence_nse": persistence_nse,
            "ar2_nse": ar2_nse,
            "active_lag": int(basin.active_lag),
            "active_routing_correction_abs_max": (
                float(active_route.abs().max()) if active_route.numel() else 0.0
            ),
            "inactive_padded_tail_correction_abs_max": (
                float(inactive_tail.abs().max()) if inactive_tail.numel() else 0.0
            ),
            "requested_state_correction_abs_mean": trace.requested_state_corrections.abs()
            .mean(dim=(0, 1))
            .detach()
            .cpu()
            .tolist(),
            "realized_state_correction_abs_mean": trace.realized_state_corrections.abs()
            .mean(dim=(0, 1))
            .detach()
            .cpu()
            .tolist(),
            "projected_state_fraction_mean": float(
                trace.projected_state_fraction.mean()
            ),
        }
    shared_loss = float(loss_result.total_loss)
    metrics = {
        "selection_score": -shared_loss,
        "validation_loss": shared_loss,
        "primary_loss": shared_loss,
        "basin_aggregation": "equal_weight_mean_of_per_basin_metrics",
        "target_count_by_lead": {lead: len(basins) * 109 for lead in leads},
        "per_basin": per_basin,
        "knet_nse": {
            lead: float(np.mean([per_basin[b]["knet_nse"][lead] for b in basin_ids]))
            for lead in leads
        },
        "open_loop_nse": {
            lead: float(
                np.mean([per_basin[b]["open_loop_nse"][lead] for b in basin_ids])
            )
            for lead in leads
        },
        "persistence_nse": {
            lead: float(
                np.mean([per_basin[b]["persistence_nse"][lead] for b in basin_ids])
            )
            for lead in leads
        },
        "ar2_nse": {
            lead: float(np.mean([per_basin[b]["ar2_nse"][lead] for b in basin_ids]))
            for lead in leads
        },
        "inactive_padded_tail_correction_abs_max": max(
            float(per_basin[b]["inactive_padded_tail_correction_abs_max"])
            for b in basin_ids
        ),
    }
    arrays = {
        "basin_ids": np.asarray(basin_ids, dtype="U8"),
        "leads_days": np.asarray(leads, dtype=np.int64),
        "origin_indices": np.stack(origin_rows),
        "prediction": prediction_tensor.detach().cpu().numpy(),
        "target": target_tensor.detach().cpu().numpy(),
        "open_loop": open_loop_tensor.detach().cpu().numpy(),
        "persistence": persistence_tensor.detach().cpu().numpy(),
        "ar2": ar2_tensor.detach().cpu().numpy(),
    }
    return metrics, arrays


def full_state_validation_metrics(
    net: Any,
    basins: Sequence[Any],
    *,
    training_loss_scales: SharedTrainingDischargeScales,
    validation_window_days: int,
    filter_warmup_days: int,
) -> dict[str, Any]:
    return full_state_validation_artifact(
        net,
        basins,
        training_loss_scales=training_loss_scales,
        validation_window_days=validation_window_days,
        filter_warmup_days=filter_warmup_days,
    )[0]


def strict_zero_control_network(net: Any) -> Any:
    control = copy.deepcopy(net)
    head = control.FC2[-1]
    with torch.no_grad():
        head.weight.zero_()
        head.bias.zero_()
    return control


def _gpu_peak_reserved_memory_bytes(device: torch.device) -> int:
    if device.type != "cuda":
        return 0
    return int(torch.cuda.max_memory_reserved(device))


def train_daily_native_full_state_knet(
    basins: Sequence[Any],
    settings: Mapping[str, Any],
    *,
    device: torch.device,
    training_loss_scales: SharedTrainingDischargeScales,
    training_scale_evidence_sha256: str,
    resume_state: Any | None = None,
    checkpoint_callback: Callable[[TrainingResult], None] | None = None,
    stop_requested: Callable[[], bool] | None = None,
) -> TrainingResult:
    """Train one shared 18-state network with the exact A20 optimizer geometry."""

    if not basins:
        raise ValueError("daily full-state training basins are empty")
    basin_ids = tuple(str(basin.basin_id) for basin in basins)
    if basin_ids != tuple(training_loss_scales.basin_ids):
        raise ValueError("training basin order differs from the frozen scale order")
    if training_loss_scales.contract_name != MASKED_NSE_CONTRACT_NAME:
        raise ValueError("training loss scale contract changed")
    scale_hash = str(training_scale_evidence_sha256).lower()
    if scale_hash != compute_training_scale_evidence_sha256(training_loss_scales):
        raise ValueError("training scale evidence SHA-256 does not match its scales")
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")
    seed = int(settings["seed"])
    if resume_state is None:
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        if device.type == "cuda":
            torch.cuda.manual_seed_all(seed)
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)

    net = build_a20_full_state_network(
        basins[0], settings, device=device, strict_zero=False
    )
    optimizer = torch.optim.Adam(
        net.parameters(),
        lr=float(settings["learning_rate"]),
        weight_decay=float(settings["weight_decay"]),
    )
    scheduler = None
    sampler = torch.Generator(device="cpu").manual_seed(seed + 1)
    validation_days = int(settings["validation_window_days"])
    filter_warmup = int(settings["filter_warmup_days"])
    segment_days = int(settings["segment_days"])
    start_clock = time.perf_counter()

    if resume_state is None:
        net.eval()
        with torch.no_grad():
            initial_metrics = full_state_validation_metrics(
                net,
                basins,
                training_loss_scales=training_loss_scales,
                validation_window_days=validation_days,
                filter_warmup_days=filter_warmup,
            )
        host_peak, gpu_peak = _memory_snapshot(device)
        gpu_reserved_peak = _gpu_peak_reserved_memory_bytes(device)
        epoch_zero = {
            "epoch": 0,
            "optimizer_steps": 0,
            "sampled_forecast_events": 0,
            "training_loss": None,
            "training_scale_evidence_sha256": scale_hash,
            **initial_metrics,
            "parameter_sha256": parameter_sha256(net),
            "finite_gradients": None,
            "nonzero_gradient_parameter_tensor_count": 0,
            "nonzero_gradient_parameter_names": [],
            "training_units": [],
            "elapsed_seconds": time.perf_counter() - start_clock,
            "host_resident_memory_bytes": host_peak,
            "gpu_peak_memory_bytes": gpu_peak,
            "gpu_peak_reserved_memory_bytes": gpu_reserved_peak,
        }
        history: list[dict[str, Any]] = [epoch_zero]
        best_epoch = 0
        best_score = float(epoch_zero["selection_score"])
        best_state = copy.deepcopy(net.state_dict())
        cumulative_steps = 0
        event_count = 0
        nonzero_names: set[str] = set()
        completed_epoch = 0
        if checkpoint_callback is not None:
            checkpoint_callback(
                _training_snapshot(
                    network=net,
                    optimizer=optimizer,
                    scheduler=scheduler,
                    completed_epoch=0,
                    history=history,
                    epoch_zero=epoch_zero,
                    best_epoch=best_epoch,
                    best_score=best_score,
                    best_state=best_state,
                    sampler=sampler,
                    cumulative_steps=0,
                    event_count=0,
                    nonzero_names=nonzero_names,
                    training_scale_evidence_sha256=scale_hash,
                )
            )
        if stop_requested is not None and stop_requested():
            raise RecoverableTrainingStop("scheduler termination requested after epoch zero")
    else:
        completed_epoch = int(_resume_attribute(resume_state, "completed_epoch"))
        history = [dict(row) for row in _resume_attribute(resume_state, "history")]
        epoch_zero = dict(_resume_attribute(resume_state, "epoch_zero_record"))
        if not history or int(history[0].get("epoch", -1)) != 0:
            raise ValueError("resume history must begin with epoch zero")
        if int(history[-1].get("epoch", -1)) != completed_epoch:
            raise ValueError("resume history does not end at completed_epoch")
        net.load_state_dict(_resume_attribute(resume_state, "model_state"), strict=True)
        optimizer.load_state_dict(_resume_attribute(resume_state, "optimizer_state"))
        if _resume_attribute(resume_state, "scheduler_state") is not None:
            raise ValueError("the frozen daily smoke has no scheduler state")
        sampler.set_state(
            torch.as_tensor(
                _resume_attribute(resume_state, "sampler_generator_state"),
                device="cpu",
                dtype=torch.uint8,
            )
        )
        best_payload = _resume_attribute(resume_state, "best_post_zero_checkpoint")
        if not isinstance(best_payload, Mapping):
            raise TypeError("resume best checkpoint metadata must be a mapping")
        best_epoch = int(best_payload["epoch"])
        best_score = float(best_payload["selection_score"])
        best_state = copy.deepcopy(best_payload["model_state"])
        cumulative_steps = int(
            _resume_attribute(resume_state, "cumulative_optimizer_steps")
        )
        event_count = int(_resume_attribute(resume_state, "sampled_forecast_events"))
        nonzero_names = set(
            str(name)
            for name in _resume_attribute(
                resume_state, "nonzero_gradient_parameter_names"
            )
        )
        _restore_random_states(resume_state, device)

    target_epochs = int(settings["epochs"])
    if target_epochs < completed_epoch:
        raise ValueError("configured epoch budget is below the resumed epoch")
    for epoch in range(completed_epoch + 1, target_epochs + 1):
        if stop_requested is not None and stop_requested():
            raise RecoverableTrainingStop(
                f"scheduler termination requested before epoch {epoch}"
            )
        net.train()
        losses: list[float] = []
        finite_gradients = True
        training_units: list[dict[str, Any]] = []
        for step_in_epoch in range(int(settings["steps_per_epoch"])):
            traces: list[FullStateFilterTrace] = []
            step_units: list[dict[str, Any]] = []
            for basin_index, basin in enumerate(basins):
                lower = int(basin.training_start_index)
                upper = int(basin.validation_start_index) - segment_days
                if upper < lower:
                    raise ValueError("daily training interval cannot fit one segment")
                start = int(
                    torch.randint(lower, upper + 1, (1,), generator=sampler).item()
                )
                end = start + segment_days
                if end > int(training_loss_scales.validation_start_index):
                    raise ValueError("training segment crosses the frozen validation boundary")
                traces.append(run_full_state_filter(net, basin, start, end))
                step_units.append(
                    {
                        "step_in_epoch": step_in_epoch,
                        "basin_index": basin_index,
                        "basin_id": basin.basin_id,
                        "start_index": start,
                        "end_index_exclusive": end,
                    }
                )
            batch = multibasin_masked_nse_step_loss(
                basins,
                traces,
                training_loss_scales,
                filter_warmup_days=filter_warmup,
            )
            loss = batch.loss
            if not bool(torch.isfinite(loss)):
                raise FloatingPointError("daily full-state KalmanNet loss is nonfinite")
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            for name, parameter in net.named_parameters():
                if parameter.grad is None:
                    continue
                if not bool(torch.isfinite(parameter.grad).all()):
                    finite_gradients = False
                elif bool(torch.count_nonzero(parameter.grad)):
                    nonzero_names.add(name)
            if not finite_gradients:
                raise FloatingPointError("daily full-state KalmanNet gradient is nonfinite")
            gradient_norm = torch.nn.utils.clip_grad_norm_(
                net.parameters(), float(settings["gradient_maximum_norm"])
            )
            if not bool(torch.isfinite(gradient_norm)):
                raise FloatingPointError("daily full-state gradient norm is nonfinite")
            optimizer.step()
            cumulative_steps += 1
            event_count += int(batch.forecast_target_count)
            losses.append(float(loss.detach().cpu()))
            for unit in step_units:
                basin_id = unit["basin_id"]
                unit["forecast_target_count"] = 3 * batch.events_per_basin_lead
                unit["primary_loss"] = float(batch.per_basin_loss[basin_id])
                unit["per_lead_loss_evidence"] = {
                    lead: {
                        "event_count": batch.events_per_basin_lead,
                        "physical_mse": float(
                            batch.per_basin_lead_physical_mse[basin_id][lead]
                        ),
                        "primary_loss": float(
                            batch.per_basin_lead_loss[basin_id][lead]
                        ),
                    }
                    for lead in (1, 2, 3)
                }
            training_units.extend(step_units)
            if stop_requested is not None and stop_requested():
                raise RecoverableTrainingStop(
                    f"scheduler termination requested during epoch {epoch}; "
                    "resume from the preceding complete epoch"
                )

        net.eval()
        with torch.no_grad():
            metrics = full_state_validation_metrics(
                net,
                basins,
                training_loss_scales=training_loss_scales,
                validation_window_days=validation_days,
                filter_warmup_days=filter_warmup,
            )
        score = float(metrics["selection_score"])
        if score > best_score:
            best_score = score
            best_epoch = epoch
            best_state = copy.deepcopy(net.state_dict())
        host_peak, gpu_peak = _memory_snapshot(device)
        gpu_reserved_peak = _gpu_peak_reserved_memory_bytes(device)
        record = {
            "epoch": epoch,
            "optimizer_steps": cumulative_steps,
            "sampled_forecast_events": event_count,
            "training_loss": float(np.mean(losses)),
            "training_scale_evidence_sha256": scale_hash,
            **metrics,
            "parameter_sha256": parameter_sha256(net),
            "finite_gradients": finite_gradients,
            "nonzero_gradient_parameter_tensor_count": len(nonzero_names),
            "nonzero_gradient_parameter_names": sorted(nonzero_names),
            "training_units": training_units,
            "elapsed_seconds": time.perf_counter() - start_clock,
            "host_resident_memory_bytes": host_peak,
            "gpu_peak_memory_bytes": gpu_peak,
            "gpu_peak_reserved_memory_bytes": gpu_reserved_peak,
        }
        history.append(record)
        if checkpoint_callback is not None:
            checkpoint_callback(
                _training_snapshot(
                    network=net,
                    optimizer=optimizer,
                    scheduler=scheduler,
                    completed_epoch=epoch,
                    history=history,
                    epoch_zero=epoch_zero,
                    best_epoch=best_epoch,
                    best_score=best_score,
                    best_state=best_state,
                    sampler=sampler,
                    cumulative_steps=cumulative_steps,
                    event_count=event_count,
                    nonzero_names=nonzero_names,
                    training_scale_evidence_sha256=scale_hash,
                )
            )
        if stop_requested is not None and stop_requested():
            raise RecoverableTrainingStop(
                f"scheduler termination requested after epoch {epoch}"
            )
    return _training_snapshot(
        network=net,
        optimizer=optimizer,
        scheduler=scheduler,
        completed_epoch=target_epochs,
        history=history,
        epoch_zero=epoch_zero,
        best_epoch=best_epoch,
        best_score=best_score,
        best_state=best_state,
        sampler=sampler,
        cumulative_steps=cumulative_steps,
        event_count=event_count,
        nonzero_names=nonzero_names,
        training_scale_evidence_sha256=scale_hash,
    )


__all__ = [
    "A20ProjectionNativeHBVFullStateKalmanNet",
    "RecoverableTrainingStop",
    "FullStateFilterTrace",
    "build_a20_full_state_network",
    "full_state_validation_artifact",
    "full_state_validation_metrics",
    "initialize_a20_gain_head",
    "run_full_state_filter",
    "strict_zero_control_network",
    "train_daily_native_full_state_knet",
]
