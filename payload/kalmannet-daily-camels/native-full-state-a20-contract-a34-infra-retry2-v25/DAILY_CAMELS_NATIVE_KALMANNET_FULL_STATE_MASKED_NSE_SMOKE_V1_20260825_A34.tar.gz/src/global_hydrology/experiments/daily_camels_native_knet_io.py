"""Evidence-preserving persistence for daily native KalmanNet development runs.

This module deliberately uses only the Python standard library.  Model and random
states are opaque pickle-compatible values, so importing the persistence surface
does not import NumPy or PyTorch during command preflight.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import pickle
import socket
import struct
import uuid
from contextlib import AbstractContextManager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence


COMPLETED = "COMPLETED"
RECOVERABLE_STOP = "RECOVERABLE_STOP"
HARD_STOP = "HARD_STOP"

_LOCK_SCHEMA = "daily_camels_native_knet_owner_v1"
_CHECKPOINT_SCHEMA = "daily_camels_native_knet_resume_v1"
_CHECKPOINT_MAGIC = b"DAILY_CAMELS_NATIVE_KNET_RESUME_V1\n"
_HEADER_LENGTH = struct.Struct(">Q")
_MAX_HEADER_BYTES = 1024 * 1024


def _canonical_json_bytes(value: object) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def _sha256_bytes(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def _normalize_sha256(value: object, *, label: str) -> str:
    if not isinstance(value, str):
        raise TypeError(f"{label} must be a SHA-256 string")
    normalized = value.lower()
    if len(normalized) != 64 or any(character not in "0123456789abcdef" for character in normalized):
        raise ValueError(f"{label} must contain exactly 64 hexadecimal characters")
    return normalized


def _normalize_hash_mapping(value: Mapping[str, str], *, label: str) -> tuple[tuple[str, str], ...]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{label} must be a mapping")
    normalized: list[tuple[str, str]] = []
    for name, digest in value.items():
        if not isinstance(name, str) or not name:
            raise ValueError(f"{label} contains an empty or non-string name")
        normalized.append((name, _normalize_sha256(digest, label=f"{label}[{name!r}]")))
    if not normalized:
        raise ValueError(f"{label} must not be empty")
    return tuple(sorted(normalized))


@dataclass(frozen=True, init=False)
class RunIdentity:
    """Immutable hashes that must match before a checkpoint is deserialized."""

    experiment_id: str
    configuration_sha256: str
    _source_sha256_items: tuple[tuple[str, str], ...]
    _input_archive_sha256_items: tuple[tuple[str, str], ...]

    def __init__(
        self,
        *,
        experiment_id: str,
        configuration_sha256: str,
        source_sha256: Mapping[str, str],
        input_archive_sha256: Mapping[str, str],
    ) -> None:
        if not isinstance(experiment_id, str) or not experiment_id.strip():
            raise ValueError("experiment_id must be a non-empty string")
        object.__setattr__(self, "experiment_id", experiment_id)
        object.__setattr__(
            self,
            "configuration_sha256",
            _normalize_sha256(configuration_sha256, label="configuration_sha256"),
        )
        object.__setattr__(
            self,
            "_source_sha256_items",
            _normalize_hash_mapping(source_sha256, label="source_sha256"),
        )
        object.__setattr__(
            self,
            "_input_archive_sha256_items",
            _normalize_hash_mapping(input_archive_sha256, label="input_archive_sha256"),
        )

    @property
    def source_sha256(self) -> dict[str, str]:
        return dict(self._source_sha256_items)

    @property
    def input_archive_sha256(self) -> dict[str, str]:
        return dict(self._input_archive_sha256_items)

    def to_dict(self) -> dict[str, object]:
        return {
            "experiment_id": self.experiment_id,
            "configuration_sha256": self.configuration_sha256,
            "source_sha256": self.source_sha256,
            "input_archive_sha256": self.input_archive_sha256,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, object]) -> "RunIdentity":
        required = {
            "experiment_id",
            "configuration_sha256",
            "source_sha256",
            "input_archive_sha256",
        }
        if not isinstance(value, Mapping) or set(value) != required:
            raise ValueError("run identity member set changed")
        source = value["source_sha256"]
        archives = value["input_archive_sha256"]
        if not isinstance(source, Mapping) or not isinstance(archives, Mapping):
            raise TypeError("run identity hash collections must be mappings")
        return cls(
            experiment_id=value["experiment_id"],
            configuration_sha256=value["configuration_sha256"],
            source_sha256=source,
            input_archive_sha256=archives,
        )

    @property
    def identity_sha256(self) -> str:
        return _sha256_bytes(_canonical_json_bytes(self.to_dict()))


@dataclass
class ResumeState:
    """All mutable state required to continue a training run exactly."""

    experiment_id: str
    model_state: Any
    optimizer_state: Any
    scheduler_state: Any
    completed_epoch: int
    cumulative_optimizer_steps: int
    sampled_forecast_events: int
    nonzero_gradient_parameter_names: Sequence[str]
    best_post_zero_checkpoint: Any
    epoch_zero_record: Mapping[str, Any]
    history: Sequence[Mapping[str, Any]]
    python_random_state: Any
    numpy_bit_generator_state: Any
    torch_cpu_random_state: Any
    torch_cuda_random_states: Sequence[Any]
    sampler_generator_state: Any
    configuration_sha256: str
    source_sha256: Mapping[str, str]
    input_archive_sha256: Mapping[str, str]
    access_ledger: Any
    previous_checkpoint_sha256: str | None = None

    def __post_init__(self) -> None:
        self.configuration_sha256 = _normalize_sha256(
            self.configuration_sha256,
            label="configuration_sha256",
        )
        self.source_sha256 = dict(
            _normalize_hash_mapping(self.source_sha256, label="source_sha256")
        )
        self.input_archive_sha256 = dict(
            _normalize_hash_mapping(self.input_archive_sha256, label="input_archive_sha256")
        )
        self.history = list(self.history)
        self.nonzero_gradient_parameter_names = list(
            self.nonzero_gradient_parameter_names
        )
        self.torch_cuda_random_states = list(self.torch_cuda_random_states)
        if self.previous_checkpoint_sha256 is not None:
            self.previous_checkpoint_sha256 = _normalize_sha256(
                self.previous_checkpoint_sha256,
                label="previous_checkpoint_sha256",
            )
        _validate_resume_state(self)

    @property
    def run_identity(self) -> RunIdentity:
        return RunIdentity(
            experiment_id=self.experiment_id,
            configuration_sha256=self.configuration_sha256,
            source_sha256=self.source_sha256,
            input_archive_sha256=self.input_archive_sha256,
        )


def _validate_resume_state(state: ResumeState) -> None:
    if not isinstance(state.experiment_id, str) or not state.experiment_id.strip():
        raise ValueError("resume experiment_id must be a non-empty string")
    for name in (
        "completed_epoch",
        "cumulative_optimizer_steps",
        "sampled_forecast_events",
    ):
        value = getattr(state, name)
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError(f"{name} must be a non-negative integer")
    if not isinstance(state.model_state, Mapping):
        raise TypeError("model_state must be a mapping")
    if not isinstance(state.optimizer_state, Mapping):
        raise TypeError("optimizer_state must be a mapping")
    if state.scheduler_state is not None:
        raise ValueError("the frozen daily smoke does not use a scheduler")
    if not isinstance(state.epoch_zero_record, Mapping):
        raise TypeError("epoch_zero_record must be a mapping")
    if not isinstance(state.history, Sequence):
        raise TypeError("history must be a sequence")
    if not isinstance(state.torch_cuda_random_states, Sequence):
        raise TypeError("torch_cuda_random_states must be a sequence")
    if not isinstance(state.python_random_state, tuple):
        raise TypeError("python_random_state must be a tuple")
    if (
        not isinstance(state.numpy_bit_generator_state, tuple)
        or len(state.numpy_bit_generator_state) != 5
        or not isinstance(state.numpy_bit_generator_state[0], str)
    ):
        raise TypeError(
            "numpy_bit_generator_state must be a numpy.random.get_state() tuple"
        )
    if state.torch_cpu_random_state is None or state.sampler_generator_state is None:
        raise ValueError("PyTorch and sampler random states must be present")
    if (
        not isinstance(state.nonzero_gradient_parameter_names, Sequence)
        or isinstance(state.nonzero_gradient_parameter_names, (str, bytes))
        or any(
            not isinstance(name, str) or not name
            for name in state.nonzero_gradient_parameter_names
        )
    ):
        raise TypeError("nonzero gradient parameter names must be non-empty strings")
    if len(set(state.nonzero_gradient_parameter_names)) != len(
        state.nonzero_gradient_parameter_names
    ):
        raise ValueError("nonzero gradient parameter names must be unique")

    expected_epochs = list(range(state.completed_epoch + 1))
    if len(state.history) != len(expected_epochs):
        raise ValueError("history must contain exactly one row for every completed epoch")
    actual_epochs: list[int] = []
    previous_steps = -1
    previous_events = -1
    for row in state.history:
        if not isinstance(row, Mapping):
            raise TypeError("every history row must be a mapping")
        epoch = row.get("epoch")
        steps = row.get("optimizer_steps")
        events = row.get("sampled_forecast_events")
        if any(isinstance(value, bool) or not isinstance(value, int) for value in (epoch, steps, events)):
            raise TypeError("history epoch, optimizer steps, and events must be integers")
        if steps < previous_steps or events < previous_events:
            raise ValueError("history optimizer steps and events must be monotonic")
        actual_epochs.append(epoch)
        previous_steps = steps
        previous_events = events
    if actual_epochs != expected_epochs:
        raise ValueError("history epochs must be contiguous from zero")
    if dict(state.history[0]) != dict(state.epoch_zero_record):
        raise ValueError("epoch_zero_record must equal the first history row")
    if previous_steps != state.cumulative_optimizer_steps:
        raise ValueError("history and cumulative optimizer step count differ")
    if previous_events != state.sampled_forecast_events:
        raise ValueError("history and sampled forecast event count differ")

    best = state.best_post_zero_checkpoint
    if not isinstance(best, Mapping) or set(best) != {
        "epoch",
        "selection_score",
        "model_state",
    }:
        raise ValueError("best checkpoint metadata member set changed")
    best_epoch = best["epoch"]
    best_score = best["selection_score"]
    if (
        isinstance(best_epoch, bool)
        or not isinstance(best_epoch, int)
        or not 0 <= best_epoch <= state.completed_epoch
    ):
        raise ValueError("best checkpoint epoch is outside completed history")
    if not isinstance(best_score, (int, float)) or not math.isfinite(float(best_score)):
        raise ValueError("best checkpoint selection score must be finite")
    if not isinstance(best["model_state"], Mapping):
        raise TypeError("best checkpoint model state must be a mapping")

    if not isinstance(state.access_ledger, Mapping):
        raise TypeError("access_ledger must be a mapping")
    ledger_keys = {
        "raw_source_byte_reads",
        "archive_materialization_sessions",
        "archive_member_reads",
        "evaluation_array_reads",
        "evaluation_predictions",
        "evaluation_metrics",
        "evaluation_outputs",
    }
    if set(state.access_ledger) != ledger_keys:
        raise ValueError("access ledger member set changed")
    members = state.access_ledger["archive_member_reads"]
    if not isinstance(members, Mapping):
        raise TypeError("archive member reads must be a mapping")
    counters = [
        state.access_ledger[key]
        for key in ledger_keys - {"archive_member_reads"}
    ] + list(members.values())
    if any(isinstance(value, bool) or not isinstance(value, int) or value < 0 for value in counters):
        raise ValueError("access ledger counters must be nonnegative integers")
    sessions = state.access_ledger["archive_materialization_sessions"]
    if sessions < 1:
        raise ValueError("checkpoint access ledger requires a materialization session")
    expected_member_reads = {
        name: 2 * sessions
        for name in ("dates_ns", "forcing", "observations", "parameters")
    }
    if dict(members) != expected_member_reads:
        raise ValueError("checkpoint archive reads differ from two basins per session")
    state.run_identity
    if state.previous_checkpoint_sha256 is not None:
        _normalize_sha256(state.previous_checkpoint_sha256, label="previous_checkpoint_sha256")


def _fsync_directory(path: Path) -> None:
    if os.name == "nt":
        return
    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
    descriptor = os.open(path, flags)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def create_new_run(path: Path) -> Path:
    """Create a previously absent run directory without reusing any history."""

    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.mkdir(parents=False, exist_ok=False)
    _fsync_directory(destination.parent)
    return destination


class OwnerLock(AbstractContextManager["OwnerLock"]):
    """Fail-closed directory lock whose exact owner record is never replaced."""

    def __init__(self, path: Path, owner_bytes: bytes) -> None:
        self.path = Path(path)
        self._owner_bytes = bytes(owner_bytes)
        self._released = False

    @classmethod
    def acquire(cls, path: Path, identity: Mapping[str, object]) -> "OwnerLock":
        lock_path = Path(path)
        if isinstance(identity, RunIdentity):
            identity_payload: Mapping[str, object] = identity.to_dict()
        elif isinstance(identity, Mapping):
            identity_payload = dict(identity)
        else:
            raise TypeError("owner identity must be a mapping")
        if not identity_payload:
            raise ValueError("owner identity must not be empty")

        owner = {
            "schema_version": _LOCK_SCHEMA,
            "process_id": os.getpid(),
            "host_name": socket.gethostname(),
            "owner_token": uuid.uuid4().hex,
            "acquired_at_utc": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "identity": dict(identity_payload),
        }
        owner_bytes = _canonical_json_bytes(owner)
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            lock_path.mkdir(parents=False, exist_ok=False)
        except FileExistsError as exc:
            raise FileExistsError(f"owner lock already exists: {lock_path}") from exc

        owner_path = lock_path / "owner.json"
        try:
            with owner_path.open("xb") as handle:
                handle.write(owner_bytes)
                handle.flush()
                os.fsync(handle.fileno())
            _fsync_directory(lock_path)
            _fsync_directory(lock_path.parent)
        except Exception:
            if owner_path.exists():
                owner_path.unlink()
            if lock_path.is_dir() and not any(lock_path.iterdir()):
                lock_path.rmdir()
            raise
        return cls(lock_path, owner_bytes)

    def release(self) -> None:
        if self._released:
            raise RuntimeError("owner lock was already released")
        if not self.path.is_dir():
            raise RuntimeError("owner lock directory disappeared")
        members = {member.name for member in self.path.iterdir()}
        if members != {"owner.json"}:
            raise RuntimeError("owner lock member set changed")
        owner_path = self.path / "owner.json"
        if not owner_path.is_file() or owner_path.is_symlink():
            raise RuntimeError("owner identity changed")
        if owner_path.read_bytes() != self._owner_bytes:
            raise RuntimeError("owner identity changed")
        owner_path.unlink()
        self.path.rmdir()
        _fsync_directory(self.path.parent)
        self._released = True

    def __enter__(self) -> "OwnerLock":
        return self

    def __exit__(self, exc_type, exc_value, traceback_value) -> None:
        self.release()


def atomic_write_bytes(path: Path, content: bytes, replace: bool) -> str:
    """Publish complete bytes from a flushed same-directory temporary file."""

    if not isinstance(content, (bytes, bytearray, memoryview)):
        raise TypeError("atomic content must be bytes-like")
    payload = bytes(content)
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(f".{destination.name}.{uuid.uuid4().hex}.tmp")
    try:
        with temporary.open("xb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        if replace:
            os.replace(temporary, destination)
        else:
            os.link(temporary, destination)
            temporary.unlink()
        _fsync_directory(destination.parent)
    finally:
        if temporary.exists():
            temporary.unlink()
    return _sha256_bytes(payload)


def _checkpoint_bytes(state: ResumeState) -> bytes:
    if not isinstance(state, ResumeState):
        raise TypeError("checkpoint state must be ResumeState")
    _validate_resume_state(state)
    payload = pickle.dumps(state, protocol=pickle.HIGHEST_PROTOCOL)
    identity = state.run_identity
    header = {
        "schema_version": _CHECKPOINT_SCHEMA,
        "identity": identity.to_dict(),
        "identity_sha256": identity.identity_sha256,
        "payload_sha256": _sha256_bytes(payload),
        "previous_checkpoint_sha256": state.previous_checkpoint_sha256,
    }
    header_bytes = _canonical_json_bytes(header)
    return _CHECKPOINT_MAGIC + _HEADER_LENGTH.pack(len(header_bytes)) + header_bytes + payload


def save_resume_checkpoint(path: Path, state: ResumeState) -> str:
    """Save one immutable epoch checkpoint and return its complete-file SHA-256."""

    content = _checkpoint_bytes(state)
    return atomic_write_bytes(Path(path), content, replace=False)


def _decode_checkpoint(content: bytes, expected_identity: RunIdentity | None) -> ResumeState:
    minimum = len(_CHECKPOINT_MAGIC) + _HEADER_LENGTH.size
    if len(content) < minimum or not content.startswith(_CHECKPOINT_MAGIC):
        raise ValueError("checkpoint magic is invalid")
    length_start = len(_CHECKPOINT_MAGIC)
    length_end = length_start + _HEADER_LENGTH.size
    header_length = _HEADER_LENGTH.unpack(content[length_start:length_end])[0]
    if header_length <= 0 or header_length > _MAX_HEADER_BYTES:
        raise ValueError("checkpoint header length is invalid")
    header_end = length_end + header_length
    if header_end >= len(content):
        raise ValueError("checkpoint header or payload is truncated")
    header_bytes = content[length_end:header_end]
    try:
        header = json.loads(header_bytes.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("checkpoint header is invalid JSON") from exc
    if not isinstance(header, dict) or header_bytes != _canonical_json_bytes(header):
        raise ValueError("checkpoint header is not canonical")
    required = {
        "schema_version",
        "identity",
        "identity_sha256",
        "payload_sha256",
        "previous_checkpoint_sha256",
    }
    if set(header) != required or header.get("schema_version") != _CHECKPOINT_SCHEMA:
        raise ValueError("checkpoint header member set or schema changed")
    identity_payload = header["identity"]
    if not isinstance(identity_payload, Mapping):
        raise ValueError("checkpoint identity is invalid")
    stored_identity = RunIdentity.from_dict(identity_payload)
    stored_identity_hash = _normalize_sha256(
        header["identity_sha256"],
        label="checkpoint identity hash",
    )
    if stored_identity.identity_sha256 != stored_identity_hash:
        raise ValueError("checkpoint identity hash does not match its members")
    if expected_identity is not None and stored_identity_hash != expected_identity.identity_sha256:
        raise ValueError("checkpoint identity hash differs from the expected run")

    payload = content[header_end:]
    expected_payload_hash = _normalize_sha256(
        header["payload_sha256"],
        label="checkpoint payload SHA-256",
    )
    if _sha256_bytes(payload) != expected_payload_hash:
        raise ValueError("checkpoint payload SHA-256 mismatch")
    try:
        state = pickle.loads(payload)
    except Exception as exc:
        raise ValueError("checkpoint payload cannot be deserialized") from exc
    if not isinstance(state, ResumeState):
        raise ValueError("checkpoint payload is not ResumeState")
    _validate_resume_state(state)
    if state.run_identity.identity_sha256 != stored_identity_hash:
        raise ValueError("checkpoint payload identity hash differs from its header")
    if state.previous_checkpoint_sha256 != header["previous_checkpoint_sha256"]:
        raise ValueError("checkpoint previous hash differs from its header")
    return state


def load_resume_checkpoint(path: Path, expected_identity: RunIdentity) -> ResumeState:
    """Validate identity and integrity before returning a complete resume state."""

    if not isinstance(expected_identity, RunIdentity):
        raise TypeError("expected_identity must be RunIdentity")
    checkpoint = Path(path)
    if not checkpoint.is_file() or checkpoint.is_symlink():
        raise FileNotFoundError(f"resume checkpoint is missing or not a regular file: {checkpoint}")
    if checkpoint.stat().st_nlink != 1:
        raise ValueError("resume checkpoint must have exactly one hard link")
    return _decode_checkpoint(checkpoint.read_bytes(), expected_identity)


_COMPLETED_LABELS = {"completed", "complete", "success", "succeeded", "finished"}
_RECOVERABLE_LABELS = {
    "time_limit",
    "timed_out",
    "timeout",
    "preempted",
    "interrupted",
    "sigterm",
    "terminated",
    "killed",
    "cancelled",
    "canceled",
    "recoverable_stop",
    "graceful_stop",
}
_HARD_LABELS = {
    "dependency_failure",
    "import_failure",
    "cuda_failure",
    "hash_mismatch",
    "identity_mismatch",
    "preflight_failure",
    "hard_stop",
    "failed",
    "failure",
}
_TERMINAL_KEYS = (
    "status",
    "stop_reason",
    "reason",
    "error_type",
    "event_type",
    "event",
    "type",
    "category",
)


def _normalize_event_label(value: object) -> str:
    return str(value).strip().lower().replace("-", "_").replace(" ", "_")


def _terminal_category(events: Iterable[Mapping[str, object]]) -> str | None:
    rows = list(events)
    for event in reversed(rows):
        if not isinstance(event, Mapping):
            continue
        for key in _TERMINAL_KEYS:
            if key not in event:
                continue
            label = _normalize_event_label(event[key])
            if label in _HARD_LABELS:
                return HARD_STOP
            if label in _COMPLETED_LABELS:
                return COMPLETED
            if label in _RECOVERABLE_LABELS:
                return RECOVERABLE_STOP
    return None


def _valid_checkpoint_state(path: Path) -> ResumeState | None:
    checkpoint = Path(path)
    if not checkpoint.is_file() or checkpoint.is_symlink():
        return None
    try:
        if checkpoint.stat().st_nlink != 1:
            return None
        state = _decode_checkpoint(checkpoint.read_bytes(), expected_identity=None)
    except (OSError, TypeError, ValueError):
        return None
    return state


def scientific_gate_evidence(
    rows: Sequence[Mapping[str, object]],
    access_ledger: Mapping[str, object],
    *,
    minimum_improvement: float,
    expected_completed_epoch: int = 4,
) -> Mapping[str, object]:
    """Authoritative post-zero learning and data-isolation gate."""

    reasons: list[str] = []
    actual_epochs = [int(row.get("epoch", -1)) for row in rows]
    if actual_epochs != list(range(expected_completed_epoch + 1)):
        reasons.append("training history is not contiguous through the frozen epoch budget")
    epoch_zero_rows = [row for row in rows if int(row.get("epoch", -1)) == 0]
    post_zero_rows = [row for row in rows if int(row.get("epoch", -1)) > 0]
    if len(epoch_zero_rows) != 1:
        reasons.append("exactly one epoch-zero record is required")
        epoch_zero_score = float("nan")
    else:
        epoch_zero_score = float(epoch_zero_rows[0].get("selection_score", float("nan")))
    finite_post = [
        row
        for row in post_zero_rows
        if math.isfinite(float(row.get("selection_score", float("nan"))))
    ]
    if not math.isfinite(epoch_zero_score):
        reasons.append("epoch-zero selection score is nonfinite")
    if not finite_post:
        reasons.append("no finite post-zero selection score exists")
        best_row: Mapping[str, object] | None = None
        best_score = float("-inf")
    else:
        best_row = max(finite_post, key=lambda row: float(row["selection_score"]))
        best_score = float(best_row["selection_score"])
    if not (best_score > epoch_zero_score + float(minimum_improvement)):
        reasons.append("post-zero selection score did not exceed epoch zero by the frozen margin")
    optimizer_steps = max(
        (int(row.get("optimizer_steps", 0)) for row in post_zero_rows), default=0
    )
    if optimizer_steps <= 0:
        reasons.append("optimizer step count is zero")
    if not post_zero_rows or not all(
        int(row.get("sampled_forecast_events", 0)) > 0 for row in post_zero_rows
    ):
        reasons.append("sampled forecast event evidence is incomplete")
    if not post_zero_rows or not all(
        row.get("finite_gradients") is True for row in post_zero_rows
    ):
        reasons.append("finite-gradient evidence is incomplete")
    if not post_zero_rows or not all(
        int(row.get("nonzero_gradient_parameter_tensor_count", 0)) > 0
        for row in post_zero_rows
    ):
        reasons.append("a post-zero epoch lacks a nonzero parameter gradient")

    def valid_hash(value: object) -> bool:
        return (
            isinstance(value, str)
            and len(value) == 64
            and all(character in "0123456789abcdef" for character in value.lower())
        )

    initial_parameter_hash = (
        epoch_zero_rows[0].get("parameter_sha256")
        if len(epoch_zero_rows) == 1
        else None
    )
    trained_parameter_hashes = [row.get("parameter_sha256") for row in post_zero_rows]
    if (
        not valid_hash(initial_parameter_hash)
        or not trained_parameter_hashes
        or not all(valid_hash(value) for value in trained_parameter_hashes)
        or not any(value != initial_parameter_hash for value in trained_parameter_hashes)
    ):
        reasons.append("parameter hashes do not prove a post-zero model change")
    routed_values = [
        float(row.get("routed_queue_correction_abs_max", float("nan")))
        for row in post_zero_rows
    ]
    if not routed_values or not all(
        math.isfinite(value) and value == 0.0 for value in routed_values
    ):
        reasons.append("routed queue correction is not exactly zero")

    if epoch_zero_rows:
        reference_targets = epoch_zero_rows[0].get("target_count_by_lead")
        reference_basins = epoch_zero_rows[0].get("per_basin")
        if not isinstance(reference_targets, Mapping) or not reference_targets:
            reasons.append("epoch-zero validation target counts are absent")
        elif any(row.get("target_count_by_lead") != reference_targets for row in post_zero_rows):
            reasons.append("validation target counts changed after epoch zero")
        if not isinstance(reference_basins, Mapping) or len(reference_basins) != 2:
            reasons.append("epoch-zero per-basin validation evidence is incomplete")
        elif any(set(row.get("per_basin", {})) != set(reference_basins) for row in post_zero_rows):
            reasons.append("per-basin validation identities changed after epoch zero")

    isolation_counters = (
        "raw_source_byte_reads",
        "evaluation_array_reads",
        "evaluation_predictions",
        "evaluation_metrics",
        "evaluation_outputs",
    )
    if any(int(access_ledger.get(name, -1)) != 0 for name in isolation_counters):
        reasons.append("reserved-data access counters are not all zero")
    sessions = int(access_ledger.get("archive_materialization_sessions", -1))
    if sessions < 1:
        reasons.append("archive materialization session count is absent")
    expected_member_reads = {
        name: 2 * sessions
        for name in ("dates_ns", "forcing", "observations", "parameters")
    }
    if dict(access_ledger.get("archive_member_reads", {})) != expected_member_reads:
        reasons.append("archive member counts differ from two basins per session")
    return {
        "passed": not reasons,
        "epoch_zero_selection_score": epoch_zero_score,
        "best_post_zero_selection_score": best_score,
        "best_epoch": int(best_row["epoch"]) if best_row is not None else None,
        "optimizer_steps": optimizer_steps,
        "nonzero_gradient_parameter_tensor_count": max(
            (
                int(row.get("nonzero_gradient_parameter_tensor_count", 0))
                for row in post_zero_rows
            ),
            default=0,
        ),
        "archive_materialization_sessions": sessions,
        "reasons": reasons,
    }


def _completion_evidence_passes(state: ResumeState) -> bool:
    if state.completed_epoch != 4:
        return False
    if state.cumulative_optimizer_steps <= 0 or state.sampled_forecast_events <= 0:
        return False
    if not state.nonzero_gradient_parameter_names:
        return False
    if state.previous_checkpoint_sha256 is None:
        return False

    history = list(state.history)
    gate = scientific_gate_evidence(
        history,
        state.access_ledger,
        minimum_improvement=1.0e-6,
        expected_completed_epoch=4,
    )
    if not gate["passed"]:
        return False
    try:
        best_epoch = int(state.best_post_zero_checkpoint["epoch"])
        best_score = float(state.best_post_zero_checkpoint["selection_score"])
    except (KeyError, TypeError, ValueError):
        return False
    if (
        best_epoch != gate["best_epoch"]
        or best_score != gate["best_post_zero_selection_score"]
    ):
        return False
    return True


def _completion_marker_passes(
    checkpoint_path: Path, marker_path: Path, expected_experiment_id: str
) -> bool:
    """Require the last-written marker and every hash it binds."""

    marker = Path(marker_path)
    checkpoint = Path(checkpoint_path)
    if (
        not marker.is_file()
        or marker.is_symlink()
        or marker.stat().st_nlink != 1
    ):
        return False
    try:
        payload = json.loads(marker.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return False
    expected_keys = {
        "schema_version",
        "experiment_id",
        "status",
        "training_scale_evidence_sha256",
        "manifest_file",
        "manifest_sha256",
        "summary_file",
        "summary_sha256",
        "selected_checkpoint",
        "selected_checkpoint_sha256",
        "final_checkpoint",
        "final_checkpoint_sha256",
    }
    if not isinstance(payload, Mapping) or set(payload) != expected_keys:
        return False
    if (
        payload["schema_version"] != "daily_camels_native_knet_completion_v1"
        or payload["experiment_id"] != expected_experiment_id
        or payload["status"] != COMPLETED
    ):
        return False
    run_directory = marker.parent.resolve()

    def admitted_path(relative: object) -> Path | None:
        if not isinstance(relative, str) or not relative or "\\" in relative:
            return None
        candidate = run_directory.joinpath(*relative.split("/")).resolve()
        if run_directory not in candidate.parents or not candidate.is_file():
            return None
        if candidate.is_symlink() or candidate.stat().st_nlink != 1:
            return None
        return candidate

    manifest = admitted_path(payload["manifest_file"])
    summary = admitted_path(payload["summary_file"])
    selected = admitted_path(payload["selected_checkpoint"])
    final = admitted_path(payload["final_checkpoint"])
    if None in (manifest, summary, selected, final):
        return False
    try:
        expected_hashes = {
            manifest: _normalize_sha256(
                payload["manifest_sha256"], label="completion manifest hash"
            ),
            summary: _normalize_sha256(
                payload["summary_sha256"], label="completion summary hash"
            ),
            selected: _normalize_sha256(
                payload["selected_checkpoint_sha256"],
                label="completion selected checkpoint hash",
            ),
            final: _normalize_sha256(
                payload["final_checkpoint_sha256"],
                label="completion final checkpoint hash",
            ),
        }
    except (TypeError, ValueError):
        return False
    if any(_sha256_bytes(path.read_bytes()) != digest for path, digest in expected_hashes.items()):
        return False
    try:
        if final.resolve() != checkpoint.resolve():
            return False
        manifest_payload = json.loads(manifest.read_text(encoding="utf-8"))
        if (
            manifest_payload.get("schema_version")
            != "daily_camels_native_knet_manifest_v1"
            or manifest_payload.get("experiment_id") != expected_experiment_id
        ):
            return False
        files = manifest_payload["files"]
        if not isinstance(files, Mapping):
            return False
        for path in (summary, selected, final):
            relative = path.relative_to(run_directory).as_posix()
            if files.get(relative, {}).get("sha256") != _sha256_bytes(path.read_bytes()):
                return False
    except (KeyError, OSError, TypeError, ValueError, json.JSONDecodeError):
        return False
    return True


def classify_stop(
    events: Iterable[Mapping[str, object]],
    checkpoint_path: Path,
    completion_marker_path: Path | None = None,
) -> str:
    """Classify terminal evidence without treating process launch as completion."""

    category = _terminal_category(events)
    if category == HARD_STOP:
        return HARD_STOP
    state = _valid_checkpoint_state(Path(checkpoint_path))
    if state is None:
        return HARD_STOP
    if category == COMPLETED:
        marker = (
            Path(completion_marker_path)
            if completion_marker_path is not None
            else Path(checkpoint_path).parent.parent / "completion.marker.json"
        )
        return (
            COMPLETED
            if _completion_evidence_passes(state)
            and _completion_marker_passes(
                Path(checkpoint_path), marker, state.experiment_id
            )
            else HARD_STOP
        )
    return RECOVERABLE_STOP


__all__ = [
    "COMPLETED",
    "HARD_STOP",
    "RECOVERABLE_STOP",
    "OwnerLock",
    "ResumeState",
    "RunIdentity",
    "atomic_write_bytes",
    "classify_stop",
    "create_new_run",
    "load_resume_checkpoint",
    "save_resume_checkpoint",
    "scientific_gate_evidence",
]
