"""Frozen daily CAMELS KalmanNet MaskedNSELoss smoke contract.

This module intentionally depends only on the Python standard library and
NumPy.  In particular, importing the scientific contract must not initialize
PyTorch or open any CAMELS archive.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import json
import math
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np


SCHEMA_VERSION = "daily_camels_native_kalmannet_masked_nse_smoke_v3"
EXPERIMENT_ID = (
    "DAILY_CAMELS_NATIVE_KALMANNET_MASKED_NSE_SMOKE_V3_20260825_A20"
)

ALLOWED_ARCHIVE_MEMBERS = frozenset(
    {"dates_ns", "forcing", "observations", "parameters"}
)
FORBIDDEN_ARCHIVE_MEMBERS = frozenset(
    {"initial_storage_state", "initial_state"}
)

EXPECTED_FORCING_COLUMNS = (
    "precipitation_mm_per_day",
    "mean_temperature_degrees_celsius",
    "oudin_potential_evapotranspiration_mm_per_day",
)
EXPECTED_STORAGE_NAMES = (
    "snow",
    "meltwater",
    "soil_water",
    "upper_groundwater",
    "lower_groundwater",
)
DEVELOPMENT_START = "1999-10-01"
DEVELOPMENT_END = "2008-09-30"
TRAINING_END = "2006-09-30"
VALIDATION_START = "2006-10-01"
EXPECTED_DAYS = 3288
EXPECTED_DAILY_STEP_NS = 86_400_000_000_000

FORBIDDEN_PERIOD_START = np.datetime64("1989-10-01", "ns").astype(np.int64)
FORBIDDEN_PERIOD_END = np.datetime64("1999-09-30", "ns").astype(np.int64)


def _mapping(value: object, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{name} must be a JSON object")
    return value


def _boolean(value: object, name: str) -> bool:
    if not isinstance(value, bool):
        raise TypeError(f"{name} must be a JSON boolean")
    return value


@dataclass(frozen=True)
class DailyKNetContract:
    """Immutable scientific and data-access contract for the daily smoke run."""

    schema_version: str
    experiment_id: str
    cadence: str
    forcing_columns: tuple[str, ...]
    archive_members: tuple[str, ...]
    expected_days: int
    development_start: str
    development_end: str
    training_end: str
    validation_start: str
    leads: tuple[int, ...]
    information_timing: str
    output_dimension: int
    corrected_storage_names: tuple[str, ...]
    static_attributes_enabled: bool
    residual_memory_order: int
    preset_residual_gain_enabled: bool
    evaluation_buffer_correction_enabled: bool
    correction_cap_enabled: bool
    learned_physical_parameters_enabled: bool
    zero_gain_initialization: bool
    normalized_feature_guard: float
    state_upper_bound_multiplier: float
    spinup_days: int
    minimum_post_zero_improvement: float

    @classmethod
    def from_json(cls, path: Path) -> "DailyKNetContract":
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls.from_dict(_mapping(payload, "contract"))

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "DailyKNetContract":
        data = _mapping(payload["data"], "data")
        periods = _mapping(payload["periods"], "periods")
        forecast = _mapping(payload["forecast"], "forecast")
        model = _mapping(payload["model"], "model")
        training = _mapping(payload["training"], "training")
        gates = _mapping(payload["gates"], "gates")

        evaluation_keys = [key for key in periods if "evaluation" in str(key).lower()]
        if evaluation_keys:
            raise ValueError(
                "an evaluation period is forbidden in the daily development contract"
            )

        development = periods["development"]
        if not isinstance(development, (list, tuple)) or len(development) != 2:
            raise ValueError("development period requires exactly a start and end date")

        contract = cls(
            schema_version=str(payload["schema_version"]),
            experiment_id=str(payload["experiment_id"]),
            cadence=str(data["cadence"]),
            forcing_columns=tuple(str(value) for value in data["forcing_columns"]),
            archive_members=tuple(str(value) for value in data["archive_members"]),
            expected_days=int(data["expected_days"]),
            development_start=str(development[0]),
            development_end=str(development[1]),
            training_end=str(periods["training_end"]),
            validation_start=str(periods["validation_start"]),
            leads=tuple(int(value) for value in forecast["leads_days"]),
            information_timing=str(forecast["information_timing"]),
            output_dimension=int(model["output_dimension"]),
            corrected_storage_names=tuple(
                str(value) for value in model["corrected_storage_names"]
            ),
            static_attributes_enabled=_boolean(
                model["static_attributes_enabled"], "static_attributes_enabled"
            ),
            residual_memory_order=int(model["residual_memory_order"]),
            preset_residual_gain_enabled=_boolean(
                model["preset_residual_gain_enabled"],
                "preset_residual_gain_enabled",
            ),
            evaluation_buffer_correction_enabled=False,
            correction_cap_enabled=_boolean(
                model["correction_cap_enabled"], "correction_cap_enabled"
            ),
            learned_physical_parameters_enabled=_boolean(
                model["learned_physical_parameters_enabled"],
                "learned_physical_parameters_enabled",
            ),
            zero_gain_initialization=_boolean(
                model["zero_gain_initialization"], "zero_gain_initialization"
            ),
            normalized_feature_guard=float(model["normalized_feature_guard"]),
            state_upper_bound_multiplier=float(
                model["state_upper_bound_multiplier"]
            ),
            spinup_days=int(training["spinup_days"]),
            minimum_post_zero_improvement=float(
                gates["minimum_post_zero_improvement"]
            ),
        )
        contract.validate()
        return contract

    @property
    def validation_start_index(self) -> int:
        start = np.datetime64(self.development_start, "D")
        validation = np.datetime64(self.validation_start, "D")
        return int((validation - start) / np.timedelta64(1, "D"))

    def validate(self) -> None:
        if self.schema_version != SCHEMA_VERSION:
            raise ValueError(f"schema version must remain {SCHEMA_VERSION}")
        if self.experiment_id != EXPERIMENT_ID:
            raise ValueError(f"experiment identity must remain {EXPERIMENT_ID}")
        if self.cadence != "daily":
            raise ValueError("data must use daily cadence")
        if self.forcing_columns != EXPECTED_FORCING_COLUMNS:
            raise ValueError(
                "daily forcing columns must be precipitation, mean temperature, "
                "and Oudin potential evapotranspiration in that order"
            )
        if (
            len(self.archive_members) != len(ALLOWED_ARCHIVE_MEMBERS)
            or frozenset(self.archive_members) != ALLOWED_ARCHIVE_MEMBERS
        ):
            raise ValueError(
                "archive members must be exactly dates_ns, forcing, observations, "
                "and parameters"
            )
        if self.expected_days != EXPECTED_DAYS:
            raise ValueError("daily development period must contain exactly 3,288 dates")
        if (self.development_start, self.development_end) != (
            DEVELOPMENT_START,
            DEVELOPMENT_END,
        ):
            raise ValueError(
                "development period must remain 1999-10-01 through 2008-09-30"
            )
        if (self.training_end, self.validation_start) != (
            TRAINING_END,
            VALIDATION_START,
        ):
            raise ValueError(
                "training must end 2006-09-30 and validation must start 2006-10-01"
            )
        if self.validation_start_index != 2557:
            raise ValueError("validation start index must remain 2,557")
        if self.leads != (1, 2, 3):
            raise ValueError("forecast leads must be exactly 1, 2, and 3 days")
        if self.information_timing != "perfect_future_meteorological_forcing":
            raise ValueError(
                "information timing must remain perfect future meteorological forcing"
            )
        if self.output_dimension != 5:
            raise ValueError("KalmanNet output dimension must remain exactly five")
        if self.corrected_storage_names != EXPECTED_STORAGE_NAMES:
            raise ValueError("corrected storage names and order must remain frozen")
        if self.static_attributes_enabled:
            raise ValueError("static attributes must remain disabled")
        if self.residual_memory_order != 0:
            raise ValueError("residual memory order must remain zero")
        if self.preset_residual_gain_enabled:
            raise ValueError("preset residual gain must remain disabled")
        if self.evaluation_buffer_correction_enabled:
            raise ValueError("evaluation buffer correction must remain disabled")
        if self.correction_cap_enabled:
            raise ValueError("correction cap must remain disabled")
        if self.learned_physical_parameters_enabled:
            raise ValueError("learned physical parameters must remain disabled")
        if not self.zero_gain_initialization:
            raise ValueError("the daily smoke must retain near-zero gain initialization")
        if not math.isclose(
            self.normalized_feature_guard, 10.0, rel_tol=0.0, abs_tol=1e-15
        ):
            raise ValueError("normalized feature guard must remain 10.0")
        if not math.isclose(
            self.state_upper_bound_multiplier, 2.0, rel_tol=0.0, abs_tol=1e-15
        ):
            raise ValueError(
                "training-only state upper bounds must remain two times the open-loop maximum"
            )
        if self.spinup_days != 365:
            raise ValueError("a 365-day spin-up is required")
        if not math.isclose(
            self.minimum_post_zero_improvement, 1e-6, rel_tol=0.0, abs_tol=1e-15
        ):
            raise ValueError("minimum post-epoch-zero improvement must remain 0.000001")


@dataclass
class AccessLedger:
    """Count data access while refusing forbidden members and evaluation work."""

    raw_source_byte_reads: int = 0
    archive_materialization_sessions: int = 0
    archive_member_reads: dict[str, int] = field(default_factory=dict)
    evaluation_array_reads: int = 0
    evaluation_predictions: int = 0
    evaluation_metrics: int = 0
    evaluation_outputs: int = 0

    def __post_init__(self) -> None:
        counters = (
            self.raw_source_byte_reads,
            self.archive_materialization_sessions,
            self.evaluation_array_reads,
            self.evaluation_predictions,
            self.evaluation_metrics,
            self.evaluation_outputs,
            *self.archive_member_reads.values(),
        )
        if any(not isinstance(value, int) or value < 0 for value in counters):
            raise ValueError("access counters must be nonnegative integers")
        invalid_members = set(self.archive_member_reads) - ALLOWED_ARCHIVE_MEMBERS
        if invalid_members:
            raise ValueError(
                f"access ledger contains non-allowlisted members: {sorted(invalid_members)}"
            )

    def begin_materialization_session(self) -> None:
        """Record one process-level reload of both frozen basin archives."""

        expected_previous = 2 * self.archive_materialization_sessions
        expected_members = {
            name: expected_previous for name in sorted(ALLOWED_ARCHIVE_MEMBERS)
        }
        if self.archive_member_reads not in ({}, expected_members):
            raise ValueError(
                "a new archive session requires a complete previous two-basin ledger"
            )
        self.archive_materialization_sessions += 1

    def record(self, kind: str, name: str) -> None:
        if name in FORBIDDEN_ARCHIVE_MEMBERS:
            raise PermissionError(f"forbidden member: {name}")
        if kind.startswith("evaluation"):
            raise PermissionError(f"evaluation access is forbidden: {kind}")
        if kind == "archive_member":
            if name not in ALLOWED_ARCHIVE_MEMBERS:
                raise PermissionError(f"archive member is not allowlisted: {name}")
            self.archive_member_reads[name] = self.archive_member_reads.get(name, 0) + 1
        elif kind == "raw_source_byte":
            self.raw_source_byte_reads += 1
        else:
            raise ValueError(f"unknown access kind: {kind}")


def _timestamps_as_nanoseconds(dates_ns: np.ndarray) -> np.ndarray:
    dates = np.asarray(dates_ns)
    if dates.ndim != 1:
        raise ValueError("daily dates must be a one-dimensional array")
    if np.issubdtype(dates.dtype, np.datetime64):
        if np.any(np.isnat(dates)):
            raise ValueError("daily dates may not contain missing timestamps")
        return dates.astype("datetime64[ns]").astype(np.int64)
    if np.issubdtype(dates.dtype, np.integer):
        return dates.astype(np.int64, copy=False)
    raise TypeError("daily dates must contain datetime64 values or integer nanoseconds")


def validate_daily_dates(
    dates_ns: np.ndarray, contract: DailyKNetContract
) -> None:
    """Require the exact daily development axis and reject evaluation timestamps."""

    timestamps = _timestamps_as_nanoseconds(dates_ns)
    if timestamps.size > 1 and not np.all(
        np.diff(timestamps) == EXPECTED_DAILY_STEP_NS
    ):
        raise ValueError("daily dates must use exact 86400 seconds between entries")

    forbidden = (timestamps >= FORBIDDEN_PERIOD_START) & (
        timestamps <= FORBIDDEN_PERIOD_END
    )
    if np.any(forbidden):
        raise ValueError("dates overlap the forbidden evaluation period")

    if timestamps.size != contract.expected_days:
        raise ValueError("daily development period must contain exactly 3,288 dates")

    expected_first = np.datetime64(contract.development_start, "ns").astype(np.int64)
    expected_last = np.datetime64(contract.development_end, "ns").astype(np.int64)
    if timestamps[0] != expected_first or timestamps[-1] != expected_last:
        raise ValueError(
            "daily dates must span exactly 1999-10-01 through 2008-09-30"
        )


def smoke_gate(
    epoch_zero: float,
    rows: Sequence[Mapping[str, object]],
    ledger: AccessLedger,
) -> Mapping[str, object]:
    """Return the minimum evidence gate for a technically valid smoke run."""

    from global_hydrology.experiments.daily_camels_native_knet_io import (
        scientific_gate_evidence,
    )

    baseline = float(epoch_zero)
    gate = scientific_gate_evidence(
        rows,
        {
            "raw_source_byte_reads": ledger.raw_source_byte_reads,
            "archive_materialization_sessions": (
                ledger.archive_materialization_sessions
            ),
            "archive_member_reads": dict(ledger.archive_member_reads),
            "evaluation_array_reads": ledger.evaluation_array_reads,
            "evaluation_predictions": ledger.evaluation_predictions,
            "evaluation_metrics": ledger.evaluation_metrics,
            "evaluation_outputs": ledger.evaluation_outputs,
        },
        minimum_improvement=1.0e-6,
        expected_completed_epoch=max((int(row["epoch"]) for row in rows), default=0),
    )
    return {
        "passed": bool(gate["passed"]),
        "epoch_zero": baseline,
        "best_post_update": float(gate["best_post_zero_selection_score"]),
    }
