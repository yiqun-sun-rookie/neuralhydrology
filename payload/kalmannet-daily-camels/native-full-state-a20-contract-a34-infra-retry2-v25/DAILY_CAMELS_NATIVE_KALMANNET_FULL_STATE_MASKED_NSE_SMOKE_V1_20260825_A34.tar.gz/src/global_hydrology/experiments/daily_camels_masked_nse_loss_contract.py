"""Auditable physical-unit daily CAMELS loss for shared KalmanNet training.

This standard-library-only module freezes the primary recovered daily loss.  It performs
no data access and imports no numerical framework.  The global training
discharge standard deviation remains in the scale evidence only, so the older
TUKF09 standardized-target loss can be reconstructed as a diagnostic; it is
not part of the primary training or checkpoint objective.

For basin ``b``, daily lead ``h`` in ``{1, 2, 3}``, and forecast event ``t``:

    physical_error = prediction[b,h,t] - target[b,h,t]
    event_loss = physical_error**2 / (basin_train_std[b] + 0.1)**2
    L = mean(event_loss)

Per-basin and global evidence standard deviations use population statistics
(``ddof=0``) from the half-open training slice only.  The complete-record
shared route requires the same number of finite forecast events in every
basin/lead cell, so the event mean is also an equal basin mean and an equal
1/2/3-day lead mean.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from hashlib import sha256
import json
import math
from typing import Iterable, Mapping, Sequence


CONTRACT_NAME = "daily_camels_physical_masked_nse_equal_basin_lead_v2"
DAILY_FORECAST_LEADS = (1, 2, 3)
LOSS_EPSILON_ORIGINAL_DISCHARGE_UNITS = 0.1

SOURCE_SHA256 = {
    "scripts/tukf07_information_matched_common.py": (
        "ca09c9e6c7bb9602721aabc68467c71a873c74f8b1fe74c1a8d1604ea6f97fc1"
    ),
    "neuralhydrology/training/loss.py": (
        "b27f46fbaf128b85b93c2fe0d206e5e109bfa2fb7140f05aac179714f54371fb"
    ),
}


@dataclass(frozen=True)
class BasinTrainingDischargeScale:
    """Training-only original-unit discharge scale for one basin."""

    contract_name: str
    basin_id: str
    training_start_index: int
    validation_start_index: int
    finite_observation_count: int
    population_mean_original_discharge_units: float
    population_std_original_discharge_units: float


@dataclass(frozen=True)
class SharedTrainingDischargeScales:
    """Global and per-basin scales fitted from the same training slice."""

    contract_name: str
    basin_ids: tuple[str, ...]
    training_start_index: int
    validation_start_index: int
    training_rows_per_basin: int
    training_row_count: int
    global_discharge_mean: float
    global_discharge_population_std: float
    population_standard_deviation_ddof: int
    per_basin: Mapping[str, BasinTrainingDischargeScale]


@dataclass(frozen=True)
class BasinLeadLossEvidence:
    """One equally sized basin/lead cell in the shared objective."""

    basin_id: str
    lead_days: int
    event_count: int
    physical_mean_squared_error: float
    physical_masked_nse_loss: float
    physical_squared_error_objective_weight_per_event: float


@dataclass(frozen=True)
class SharedMaskedNSELossReference:
    """Standard-library reconstruction of the complete shared loss."""

    contract_name: str
    objective: float
    basin_count: int
    leads: tuple[int, ...]
    events_per_basin_lead: int
    event_count: int
    per_basin_objective: Mapping[str, float]
    cells: tuple[BasinLeadLossEvidence, ...]
    training_scale_evidence_sha256: str


def _finite_float(value: object, *, label: str) -> float:
    try:
        converted = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"{label} must be convertible to a finite float") from exc
    if not math.isfinite(converted):
        raise ValueError(f"{label} must be finite")
    return converted


def _population_mean_and_std(
    values: Iterable[object], *, label: str
) -> tuple[int, float, float]:
    count = 0
    mean = 0.0
    second_central_moment_sum = 0.0
    for index, raw_value in enumerate(values):
        value = _finite_float(raw_value, label=f"{label} value {index}")
        count += 1
        delta = value - mean
        mean += delta / count
        second_central_moment_sum += delta * (value - mean)
    if count < 2:
        raise ValueError(f"{label} needs at least two training observations")
    variance = max(second_central_moment_sum / count, 0.0)
    standard_deviation = math.sqrt(variance)
    if not math.isfinite(standard_deviation) or standard_deviation <= 0.0:
        raise ValueError(f"{label} population standard deviation must be positive")
    return count, mean, standard_deviation


def fit_shared_training_discharge_scales(
    observations_by_basin: Mapping[str, Sequence[object]],
    *,
    training_start_index: int,
    validation_start_index: int,
) -> SharedTrainingDischargeScales:
    """Fit exact formal-loss scales without reading outside the training slice."""

    if not observations_by_basin:
        raise ValueError("shared training scales require at least one basin")
    basin_ids = tuple(sorted(str(value) for value in observations_by_basin))
    if len(set(basin_ids)) != len(basin_ids) or set(basin_ids) != set(
        observations_by_basin
    ):
        raise ValueError("basin identifiers must be unique non-normalized strings")
    if any(not basin_id.strip() for basin_id in basin_ids):
        raise ValueError("basin identifiers must be non-empty")

    start = int(training_start_index)
    stop = int(validation_start_index)
    if start < 0 or stop <= start:
        raise ValueError("training scales require 0 <= start < validation start")
    rows_per_basin = stop - start

    per_basin: dict[str, BasinTrainingDischargeScale] = {}
    global_training_values: list[float] = []
    for basin_id in basin_ids:
        observations = observations_by_basin[basin_id]
        if stop > len(observations):
            raise ValueError(f"training slice exceeds observations for basin {basin_id}")
        values: list[float] = []
        for index in range(start, stop):
            try:
                value = float(observations[index])
            except (TypeError, ValueError, OverflowError) as exc:
                raise ValueError(
                    f"training discharge is not numeric for basin {basin_id} index {index}"
                ) from exc
            if not math.isfinite(value):
                raise FloatingPointError(
                    f"training discharge is non-finite for basin {basin_id} index {index}"
                )
            values.append(value)
        count, mean, standard_deviation = _population_mean_and_std(
            values, label=f"basin {basin_id} training discharge"
        )
        if count != rows_per_basin:
            raise RuntimeError("training scale count differs from the fixed slice")
        per_basin[basin_id] = BasinTrainingDischargeScale(
            contract_name=CONTRACT_NAME,
            basin_id=basin_id,
            training_start_index=start,
            validation_start_index=stop,
            finite_observation_count=count,
            population_mean_original_discharge_units=mean,
            population_std_original_discharge_units=standard_deviation,
        )
        global_training_values.extend(values)

    total_count, global_mean, global_standard_deviation = _population_mean_and_std(
        global_training_values, label="shared training discharge"
    )
    expected_total = rows_per_basin * len(basin_ids)
    if total_count != expected_total:
        raise RuntimeError("global training scale count differs from basin geometry")
    return SharedTrainingDischargeScales(
        contract_name=CONTRACT_NAME,
        basin_ids=basin_ids,
        training_start_index=start,
        validation_start_index=stop,
        training_rows_per_basin=rows_per_basin,
        training_row_count=total_count,
        global_discharge_mean=global_mean,
        global_discharge_population_std=global_standard_deviation,
        population_standard_deviation_ddof=0,
        per_basin=per_basin,
    )


def _validated_scales(
    scales: SharedTrainingDischargeScales,
) -> SharedTrainingDischargeScales:
    if not isinstance(scales, SharedTrainingDischargeScales):
        raise TypeError("training scales must be SharedTrainingDischargeScales")
    if scales.contract_name != CONTRACT_NAME:
        raise ValueError("training scales belong to another loss contract")
    if scales.population_standard_deviation_ddof != 0:
        raise ValueError("training standard deviations must use ddof zero")
    if tuple(sorted(scales.basin_ids)) != scales.basin_ids:
        raise ValueError("training scale basin identifiers are not canonical")
    if set(scales.per_basin) != set(scales.basin_ids):
        raise ValueError("per-basin scales do not match the shared basin population")
    if scales.training_rows_per_basin < 2 or scales.training_row_count != (
        scales.training_rows_per_basin * len(scales.basin_ids)
    ):
        raise ValueError("training scale counts are internally inconsistent")
    _finite_float(scales.global_discharge_mean, label="global training mean")
    global_standard_deviation = _finite_float(
        scales.global_discharge_population_std,
        label="global training standard deviation",
    )
    if global_standard_deviation <= 0.0:
        raise ValueError("global training standard deviation must be positive")
    for basin_id in scales.basin_ids:
        value = scales.per_basin[basin_id]
        if value.contract_name != CONTRACT_NAME or value.basin_id != basin_id:
            raise ValueError("per-basin training scale identity differs")
        if (
            value.training_start_index != scales.training_start_index
            or value.validation_start_index != scales.validation_start_index
            or value.finite_observation_count != scales.training_rows_per_basin
        ):
            raise ValueError("per-basin training scale geometry differs")
        _finite_float(
            value.population_mean_original_discharge_units,
            label=f"training mean for basin {basin_id}",
        )
        standard_deviation = _finite_float(
            value.population_std_original_discharge_units,
            label=f"training standard deviation for basin {basin_id}",
        )
        if standard_deviation <= 0.0:
            raise ValueError("per-basin training standard deviation must be positive")
    return scales


def training_scale_evidence_sha256(scales: SharedTrainingDischargeScales) -> str:
    """Hash the canonical training-only scale evidence."""

    validated = _validated_scales(scales)
    payload = asdict(validated)
    payload["per_basin"] = {
        basin_id: asdict(validated.per_basin[basin_id])
        for basin_id in validated.basin_ids
    }
    encoded = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("utf-8")
    return sha256(encoded).hexdigest()


def shared_masked_nse_reference_loss(
    pairs_by_basin: Mapping[
        str,
        Mapping[int, Iterable[tuple[object, object]]],
    ],
    scales: SharedTrainingDischargeScales,
    *,
    leads: tuple[int, ...] = DAILY_FORECAST_LEADS,
) -> SharedMaskedNSELossReference:
    """Recompute the complete-record physical-unit loss from forecast pairs."""

    validated = _validated_scales(scales)
    requested_leads = tuple(int(value) for value in leads)
    if requested_leads != DAILY_FORECAST_LEADS:
        raise ValueError("the daily shared loss requires exactly leads one, two, and three")
    if set(pairs_by_basin) != set(validated.basin_ids):
        raise ValueError("forecast-pair basins differ from training scale basins")

    cell_event_count: int | None = None
    total_weighted_squared_error = 0.0
    cells: list[BasinLeadLossEvidence] = []
    per_basin_values: dict[str, list[float]] = {}
    for basin_id in validated.basin_ids:
        lead_pairs = pairs_by_basin[basin_id]
        if set(lead_pairs) != set(requested_leads):
            raise ValueError(f"basin {basin_id} must contain exactly leads one, two, three")
        basin_standard_deviation = validated.per_basin[
            basin_id
        ].population_std_original_discharge_units
        denominator = (
            basin_standard_deviation + LOSS_EPSILON_ORIGINAL_DISCHARGE_UNITS
        ) ** 2
        basin_cells: list[float] = []
        for lead in requested_leads:
            pairs = tuple(lead_pairs[lead])
            if not pairs:
                raise ValueError(f"basin {basin_id} lead {lead} has no forecast events")
            if cell_event_count is None:
                cell_event_count = len(pairs)
            elif len(pairs) != cell_event_count:
                raise ValueError("all basin and lead cells must have equal event counts")
            physical_squared_error_sum = 0.0
            for pair_index, pair in enumerate(pairs):
                try:
                    prediction_raw, target_raw = pair
                except (TypeError, ValueError) as exc:
                    raise ValueError(
                        f"basin {basin_id} lead {lead} pair {pair_index} is malformed"
                    ) from exc
                prediction = _finite_float(
                    prediction_raw,
                    label=f"basin {basin_id} lead {lead} prediction {pair_index}",
                )
                target = _finite_float(
                    target_raw,
                    label=f"basin {basin_id} lead {lead} target {pair_index}",
                )
                error = prediction - target
                squared_error = error * error
                if not math.isfinite(squared_error):
                    raise FloatingPointError("physical squared forecast error is non-finite")
                physical_squared_error_sum += squared_error
            physical_mse = physical_squared_error_sum / len(pairs)
            physical_masked_nse_value = physical_mse / denominator
            if not math.isfinite(physical_masked_nse_value):
                raise FloatingPointError("physical masked NSE loss is non-finite")
            basin_cells.append(physical_masked_nse_value)
            total_weighted_squared_error += physical_squared_error_sum / denominator
            cells.append(
                BasinLeadLossEvidence(
                    basin_id=basin_id,
                    lead_days=lead,
                    event_count=len(pairs),
                    physical_mean_squared_error=physical_mse,
                    physical_masked_nse_loss=physical_masked_nse_value,
                    physical_squared_error_objective_weight_per_event=(
                        1.0
                        / (
                            len(validated.basin_ids)
                            * len(requested_leads)
                            * len(pairs)
                            * denominator
                        )
                    ),
                )
            )
        per_basin_values[basin_id] = basin_cells

    if cell_event_count is None:
        raise RuntimeError("shared loss did not encounter forecast events")
    event_count = len(validated.basin_ids) * len(requested_leads) * cell_event_count
    objective = total_weighted_squared_error / event_count
    per_basin_objective = {
        basin_id: math.fsum(per_basin_values[basin_id]) / len(requested_leads)
        for basin_id in validated.basin_ids
    }
    equal_basin_reconstruction = math.fsum(per_basin_objective.values()) / len(
        per_basin_objective
    )
    if not math.isclose(
        objective,
        equal_basin_reconstruction,
        rel_tol=1.0e-15,
        abs_tol=1.0e-15,
    ):
        raise RuntimeError("event mean does not reconstruct as an equal basin/lead mean")
    return SharedMaskedNSELossReference(
        contract_name=CONTRACT_NAME,
        objective=objective,
        basin_count=len(validated.basin_ids),
        leads=requested_leads,
        events_per_basin_lead=cell_event_count,
        event_count=event_count,
        per_basin_objective=per_basin_objective,
        cells=tuple(cells),
        training_scale_evidence_sha256=training_scale_evidence_sha256(validated),
    )


def contract_manifest() -> dict[str, object]:
    """Return JSON-safe frozen semantics for configs, bundles, and receipts."""

    return {
        "contract_name": CONTRACT_NAME,
        "forecast_leads_days": list(DAILY_FORECAST_LEADS),
        "formula": (
            "mean_equal_complete_basin_lead_events((prediction_physical-"
            "target_physical)^2/"
            "(basin_training_population_std_original_units+0.1)^2)"
        ),
        "training_statistics_window": (
            "half_open_[training_start_index,validation_start_index)"
        ),
        "population_standard_deviation_ddof": 0,
        "loss_epsilon_original_discharge_units": (
            LOSS_EPSILON_ORIGINAL_DISCHARGE_UNITS
        ),
        "complete_record_policy": (
            "all_training_values_and_forecast_pairs_finite;equal_event_count_"
            "for_every_basin_and_lead;otherwise_hard_stop"
        ),
        "weighting_order": [
            "equal_events_within_each_basin_and_lead",
            "equal_leads_1_2_3_within_each_basin",
            "equal_basins",
        ],
        "target_noise": "none_for_kalmannet_filter_training",
        "source_sha256": dict(SOURCE_SHA256),
        "tukf09_compatibility_diagnostic": {
            "formula": (
                "compatibility_loss=primary_loss/"
                "global_training_population_std^2"
            ),
            "global_training_population_std_role": (
                "scale_evidence_and_diagnostic_only_not_primary_loss"
            ),
            "used_for_training_or_checkpoint_selection": False,
        },
        "compatibility": (
            "physical_unit_primary_loss_for_new_shared_daily_route;the_"
            "tukf09_standardized_target_scale_is_diagnostic_only"
        ),
    }


__all__ = [
    "BasinLeadLossEvidence",
    "BasinTrainingDischargeScale",
    "CONTRACT_NAME",
    "DAILY_FORECAST_LEADS",
    "LOSS_EPSILON_ORIGINAL_DISCHARGE_UNITS",
    "SharedMaskedNSELossReference",
    "SharedTrainingDischargeScales",
    "contract_manifest",
    "fit_shared_training_discharge_scales",
    "shared_masked_nse_reference_loss",
    "training_scale_evidence_sha256",
]
