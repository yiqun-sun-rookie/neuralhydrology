"""A20-compatible daily data preparation for a common 18-state KalmanNet."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import torch

from global_hydrology.experiments.daily_camels_native_knet_full_state_masked_nse_contract import (
    DailyFullStateKNetContract,
    MAXIMUM_ROUTING_LAG,
    STATE_DIMENSION,
)
from global_hydrology.experiments.daily_camels_native_knet_masked_nse_data import (
    DailyBasinArrays,
    SCALE_FLOOR,
    SCALE_MARGIN,
    STATE_BOUND_FLOOR,
    _finite_max_abs_difference,
    _simulate_open_loop,
    _validate_archive_arrays,
    fit_training_ar2,
    load_daily_selection_archive,
    sha256_file,
)
from global_hydrology.models.differentiable_hbv_lite import PARAM_NAMES
from global_hydrology.models.knet_native_hbvlite_full_state import (
    PaddedRoutedHBVSystemModel,
    build_padded_routed_system,
    correction_mask_for_active_lag,
)


STORAGE_DIMENSION = 5


@dataclass(frozen=True)
class PreparedFullStateDailyBasin:
    """Causal tensors and training-only statistics for one padded daily basin."""

    basin_id: str
    training_start_index: int
    validation_start_index: int
    system: PaddedRoutedHBVSystemModel
    active_lag: int
    initial_state: torch.Tensor
    forcing: torch.Tensor
    observations: torch.Tensor
    valid_observations: torch.Tensor
    open_loop_discharge: torch.Tensor
    open_loop_states: torch.Tensor
    observation_diff_scale: torch.Tensor
    state_diff_scale: torch.Tensor
    correction_mask: torch.Tensor
    state_lower_bound: torch.Tensor
    state_upper_bound: torch.Tensor
    parameters: torch.Tensor
    dates_ns: np.ndarray
    ar2_coefficients: torch.Tensor
    training_observation_variance: float
    normalized_feature_guard: float

    def state_immediately_before(self, index: int) -> torch.Tensor:
        if index < 0 or index > len(self.open_loop_states):
            raise ValueError("state index is outside the daily trajectory")
        if index == 0:
            return self.initial_state.clone()
        return self.open_loop_states[index - 1].clone()


def prepare_full_state_daily_basin(
    arrays: DailyBasinArrays,
    contract: DailyFullStateKNetContract,
    device: torch.device,
) -> PreparedFullStateDailyBasin:
    """Prepare the exact A20 geometry with a shared padded state dimension."""

    device = torch.device(device)
    _validate_archive_arrays(
        np.asarray(arrays.dates_ns),
        np.asarray(arrays.forcing),
        np.asarray(arrays.observations),
        np.asarray(arrays.parameters),
        contract,
    )
    parameters = torch.as_tensor(
        arrays.parameters, dtype=torch.float32, device=device
    )
    forcing = torch.as_tensor(arrays.forcing, dtype=torch.float32, device=device)
    observations = torch.as_tensor(
        arrays.observations, dtype=torch.float32, device=device
    )
    system, active_lag = build_padded_routed_system(
        parameters,
        maximum_lag=MAXIMUM_ROUTING_LAG,
        x0=None,
        dtype=torch.float32,
        device=device,
    )
    if system.m != STATE_DIMENSION or contract.state_dimension != STATE_DIMENSION:
        raise ValueError("the shared routed HBV state must contain exactly 18 coordinates")
    initial_state = system.get_default_initial_state()
    open_loop_discharge, open_loop_states = _simulate_open_loop(
        system, initial_state, forcing
    )

    training_start = int(contract.spinup_days)
    validation_start = int(contract.validation_start_index)
    if not (0 < training_start < validation_start < len(forcing)):
        raise ValueError("daily training and validation indices are inconsistent")
    training_slice = slice(training_start, validation_start)
    training_observations = observations[training_slice]
    finite_training_observations = training_observations[
        torch.isfinite(training_observations)
    ]
    if finite_training_observations.numel() < 2:
        raise ValueError("at least two finite training observations are required")
    centered = finite_training_observations - finite_training_observations.mean()
    training_observation_variance = float(
        torch.clamp(centered.square().mean(), min=SCALE_FLOOR).detach().cpu()
    )
    observation_diff_scale = (
        SCALE_MARGIN
        * _finite_max_abs_difference(training_observations, floor=SCALE_FLOOR)
    ).reshape(1, 1)
    training_states = open_loop_states[training_slice, 0, :]
    state_diff_scale = (
        SCALE_MARGIN
        * _finite_max_abs_difference(training_states, floor=SCALE_FLOOR)
    ).reshape(1, STATE_DIMENSION)
    inactive_start = STORAGE_DIMENSION + active_lag
    if inactive_start < STATE_DIMENSION:
        state_diff_scale[:, inactive_start:] = 1.0

    storage_upper = torch.clamp(
        contract.state_upper_bound_multiplier
        * training_states[:, :STORAGE_DIMENSION].max(dim=0).values,
        min=STATE_BOUND_FLOOR,
    )
    field_capacity = parameters[0, PARAM_NAMES.index("parFC")]
    storage_upper[2] = torch.minimum(storage_upper[2], field_capacity)
    state_upper_bound = torch.full(
        (1, STATE_DIMENSION),
        torch.inf,
        dtype=torch.float32,
        device=device,
    )
    state_upper_bound[:, :STORAGE_DIMENSION] = storage_upper.reshape(1, -1)
    state_lower_bound = torch.zeros(
        (1, STATE_DIMENSION), dtype=torch.float32, device=device
    )
    correction_mask = correction_mask_for_active_lag(
        STATE_DIMENSION,
        active_lag,
        storage_dimension=STORAGE_DIMENSION,
        dtype=torch.float32,
        device=device,
    )

    ar2_coefficients = torch.as_tensor(
        fit_training_ar2(
            open_loop_discharge.detach().cpu().numpy(),
            observations.detach().cpu().numpy(),
            training_slice,
        ),
        dtype=torch.float32,
        device=device,
    )
    return PreparedFullStateDailyBasin(
        basin_id=arrays.basin_id,
        training_start_index=training_start,
        validation_start_index=validation_start,
        system=system,
        active_lag=active_lag,
        initial_state=initial_state,
        forcing=forcing,
        observations=observations,
        valid_observations=torch.isfinite(observations),
        open_loop_discharge=open_loop_discharge,
        open_loop_states=open_loop_states,
        observation_diff_scale=observation_diff_scale,
        state_diff_scale=state_diff_scale,
        correction_mask=correction_mask,
        state_lower_bound=state_lower_bound,
        state_upper_bound=state_upper_bound,
        parameters=parameters,
        dates_ns=np.asarray(arrays.dates_ns).copy(),
        ar2_coefficients=ar2_coefficients,
        training_observation_variance=training_observation_variance,
        normalized_feature_guard=contract.normalized_feature_guard,
    )


__all__ = [
    "DailyBasinArrays",
    "PreparedFullStateDailyBasin",
    "load_daily_selection_archive",
    "prepare_full_state_daily_basin",
    "sha256_file",
]
