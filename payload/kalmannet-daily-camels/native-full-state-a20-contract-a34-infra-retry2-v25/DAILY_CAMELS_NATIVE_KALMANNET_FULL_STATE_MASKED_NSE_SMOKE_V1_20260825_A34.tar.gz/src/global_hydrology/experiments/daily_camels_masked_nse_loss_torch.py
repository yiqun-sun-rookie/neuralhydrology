"""PyTorch bridge for the frozen daily CAMELS shared loss contract.

All forecast values are in physical discharge units.  The dense tensor shape
``[basin, lead, event]`` makes every basin/lead cell contain the same number of
complete events.  For basin ``b``, lead ``h``, and event ``t`` the bridge uses
the exact frozen formula::

    (prediction[b, h, t] - target[b, h, t]) ** 2
    / (basin_train_std[b] + 0.1) ** 2

The reported basin/lead component is the event mean.  The total loss is the
mean of that component matrix, hence weights basins and the three daily leads
equally while retaining prediction gradients.
"""

from __future__ import annotations

from typing import NamedTuple

import torch
from torch import Tensor

from global_hydrology.experiments.daily_camels_masked_nse_loss_contract import (
    DAILY_FORECAST_LEADS,
    LOSS_EPSILON_ORIGINAL_DISCHARGE_UNITS,
)


class DailyCamelsMaskedNSETensorLoss(NamedTuple):
    """Differentiable total loss and auditable ``[basin, lead]`` components."""

    total_loss: Tensor
    per_basin_lead_loss: Tensor


def _require_tensor(value: object, *, name: str) -> Tensor:
    if not isinstance(value, Tensor):
        raise TypeError(f"{name} must be a torch.Tensor")
    if not torch.is_floating_point(value):
        raise TypeError(f"{name} must have a real floating-point dtype")
    if value.layout != torch.strided:
        raise TypeError(f"{name} must be a dense strided tensor")
    return value


def _require_finite(value: Tensor, *, name: str) -> None:
    if not bool(torch.isfinite(value).all()):
        raise FloatingPointError(f"{name} must contain only finite values")


def daily_camels_masked_nse_tensor_loss(
    prediction: Tensor,
    target: Tensor,
    basin_training_population_std_original_units: Tensor,
) -> DailyCamelsMaskedNSETensorLoss:
    """Apply the frozen complete-record loss to dense physical-unit tensors.

    Args:
        prediction: Forecast discharge with shape ``[basin, 3, event]``.
        target: Observed discharge with exactly the same shape.
        basin_training_population_std_original_units: One positive training-only
            population standard deviation per basin, shape ``[basin]``.

    Returns:
        A named tuple whose scalar ``total_loss`` equals the arithmetic mean of
        ``per_basin_lead_loss``.  The component tensor has shape ``[basin, 3]``.

    Raises:
        TypeError: An input is not a compatible dense floating-point tensor.
        ValueError: Tensor geometry, devices, dtypes, or scales are invalid.
        FloatingPointError: Any input or computed loss is non-finite.
    """

    prediction = _require_tensor(prediction, name="prediction")
    target = _require_tensor(target, name="target")
    basin_standard_deviation = _require_tensor(
        basin_training_population_std_original_units,
        name="basin training population standard deviation",
    )
    if prediction.shape != target.shape:
        raise ValueError("prediction and target must have identical shapes")
    if prediction.ndim != 3:
        raise ValueError("prediction and target must be three-dimensional")
    basin_count, lead_count, event_count = prediction.shape
    if basin_count < 1:
        raise ValueError("the shared loss requires at least one basin")
    if lead_count != len(DAILY_FORECAST_LEADS):
        raise ValueError("the shared loss requires exactly three daily leads")
    if event_count < 1:
        raise ValueError("each basin and lead requires at least one event")
    if basin_standard_deviation.shape != (basin_count,):
        raise ValueError(
            "basin training population standard deviation requires one value per basin"
        )
    inputs = (
        (target, "target"),
        (basin_standard_deviation, "basin training population standard deviation"),
    )
    for value, name in inputs:
        if value.device != prediction.device:
            raise ValueError(f"{name} must be on the prediction device")
        if value.dtype != prediction.dtype:
            raise ValueError(f"{name} must have the prediction dtype")

    _require_finite(prediction, name="prediction")
    _require_finite(target, name="target")
    _require_finite(
        basin_standard_deviation,
        name="basin training population standard deviation",
    )
    if bool((basin_standard_deviation <= 0.0).any()):
        raise ValueError(
            "basin training population standard deviations must be positive"
        )
    physical_error = prediction - target
    basin_denominator = (
        basin_standard_deviation + LOSS_EPSILON_ORIGINAL_DISCHARGE_UNITS
    ).square()
    event_loss = physical_error.square() / basin_denominator[:, None, None]
    per_basin_lead_loss = event_loss.mean(dim=2)
    total_loss = per_basin_lead_loss.mean()

    _require_finite(per_basin_lead_loss, name="per-basin and per-lead loss")
    _require_finite(total_loss, name="total loss")
    return DailyCamelsMaskedNSETensorLoss(
        total_loss=total_loss,
        per_basin_lead_loss=per_basin_lead_loss,
    )


__all__ = [
    "DailyCamelsMaskedNSETensorLoss",
    "daily_camels_masked_nse_tensor_loss",
]
