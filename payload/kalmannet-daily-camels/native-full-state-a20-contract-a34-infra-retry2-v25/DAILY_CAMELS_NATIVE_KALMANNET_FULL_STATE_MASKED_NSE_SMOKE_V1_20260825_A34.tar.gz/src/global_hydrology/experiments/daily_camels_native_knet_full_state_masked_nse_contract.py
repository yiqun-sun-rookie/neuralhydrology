"""Frozen daily two-basin full-state KalmanNet development-smoke contract.

The contract imports NumPy but not PyTorch and never opens an array archive.
It is intentionally separate from the immutable five-storage A20 contract.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
import math
from pathlib import Path
from typing import Any, Mapping

import numpy as np

from global_hydrology.experiments.daily_camels_native_knet_masked_nse_contract import (
    AccessLedger,
    validate_daily_dates,
)


SCHEMA_VERSION = "daily_camels_native_kalmannet_full_state_masked_nse_smoke_v1"
EXPERIMENT_ID = (
    "DAILY_CAMELS_NATIVE_KALMANNET_FULL_STATE_MASKED_NSE_SMOKE_V1_20260825_A34"
)
BASIN_IDS = ("04105700", "09035800")
INPUT_SHA256 = {
    "04105700": "08d7e8930cd4df624efaf578bedd9615d238f51901ee2a1054bd0e8503e0f82e",
    "09035800": "71e6d163507ae405204bedf63d2c6c06e2c3ea303cea1a0481cfa4d5f280f5fd",
}
EXPECTED_FORCING_COLUMNS = (
    "precipitation_mm_per_day",
    "mean_temperature_degrees_celsius",
    "oudin_potential_evapotranspiration_mm_per_day",
)
EXPECTED_ARCHIVE_MEMBERS = (
    "dates_ns",
    "forcing",
    "observations",
    "parameters",
)
ARCHIVE_MEMBERS_PRESENT = EXPECTED_ARCHIVE_MEMBERS + (
    "initial_storage_state",
    "initial_state",
    "initial_covariance",
    "base_observation_variance",
    "state_dimension",
)
FORBIDDEN_MATERIALIZED_MEMBERS = ARCHIVE_MEMBERS_PRESENT[4:]
EXPECTED_SOURCE_PATHS = (
    "scripts/run_daily_camels_native_kalmannet_full_state_masked_nse.py",
    "src/global_hydrology/experiments/daily_camels_native_knet_full_state_masked_nse_contract.py",
    "src/global_hydrology/experiments/daily_camels_native_knet_full_state_masked_nse_data.py",
    "src/global_hydrology/experiments/daily_camels_native_knet_full_state_masked_nse_training.py",
    "src/global_hydrology/experiments/daily_camels_native_knet_masked_nse_contract.py",
    "src/global_hydrology/experiments/daily_camels_native_knet_masked_nse_data.py",
    "src/global_hydrology/experiments/daily_camels_native_knet_masked_nse_training.py",
    "src/global_hydrology/experiments/daily_camels_masked_nse_loss_contract.py",
    "src/global_hydrology/experiments/daily_camels_masked_nse_loss_torch.py",
    "src/global_hydrology/experiments/daily_camels_native_knet_io.py",
    "src/global_hydrology/models/knet_native_hbvlite_full_state.py",
    "src/global_hydrology/models/hbvlite_system_model.py",
    "src/global_hydrology/models/differentiable_hbv_lite.py",
    "knet/dl/nn_kalman_clamp_5.py",
)
DEVELOPMENT_START = "1999-10-01"
DEVELOPMENT_END = "2008-09-30"
TRAINING_END = "2006-09-30"
VALIDATION_START = "2006-10-01"
EXPECTED_DAYS = 3_288
VALIDATION_START_INDEX = 2_557
STATE_DIMENSION = 18
MAXIMUM_ROUTING_LAG = 13
LOSS_CONTRACT_NAME = "daily_camels_physical_masked_nse_equal_basin_lead_v2"
A20_RESULT_SHA256 = (
    "4eb75db3470785069837c464ccc1fd5e13502122ee8f67478710c2d78aa5a1f3"
)
A20_EXPERIMENT_ID = "DAILY_CAMELS_NATIVE_KALMANNET_MASKED_NSE_SMOKE_V3_20260825_A20"
A20_RESULT_PATH = (
    "artifacts/a20_seq16_hpc_result_20260825/extracted/"
    "DAILY_CAMELS_NATIVE_KALMANNET_MASKED_NSE_SMOKE_V3_20260825_A20/"
    "result_summary.json"
)
A20_PHYSICAL_MSE = {
    "04105700": {
        1: 0.10303141921758652,
        2: 0.1077389270067215,
        3: 0.11234349757432938,
    },
    "09035800": {
        1: 0.060118891298770905,
        2: 0.05926883593201637,
        3: 0.05844101682305336,
    },
}


def _mapping(value: object, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{label} must be a JSON object")
    return value


def _exact(value: object, expected: object, label: str) -> None:
    if value != expected:
        raise ValueError(f"{label} must remain {expected!r}; received {value!r}")


def _exact_keys(value: Mapping[str, Any], expected: tuple[str, ...], label: str) -> None:
    if set(value) != set(expected):
        raise ValueError(
            f"{label} members changed; expected {sorted(expected)!r}, "
            f"received {sorted(str(key) for key in value)!r}"
        )


def _finite_close(value: object, expected: float, label: str) -> None:
    number = float(value)
    if not math.isfinite(number) or not math.isclose(
        number, expected, rel_tol=0.0, abs_tol=1.0e-15
    ):
        raise ValueError(f"{label} must remain {expected!r}; received {value!r}")


@dataclass(frozen=True)
class DailyFullStateKNetContract:
    """Immutable values used by the data and training strategies."""

    schema_version: str
    experiment_id: str
    cadence: str
    forcing_columns: tuple[str, ...]
    archive_members: tuple[str, ...]
    expected_days: int
    development_start: str
    development_end: str
    training_end: str
    validation_start: str
    leads: tuple[int, ...]
    information_timing: str
    state_dimension: int
    maximum_routing_lag: int
    spinup_days: int
    normalized_feature_guard: float
    state_upper_bound_multiplier: float
    gain_head_weight_multiplier: float
    minimum_post_zero_improvement: float

    @property
    def validation_start_index(self) -> int:
        start = np.datetime64(self.development_start, "D")
        validation = np.datetime64(self.validation_start, "D")
        return int((validation - start) / np.timedelta64(1, "D"))

    @classmethod
    def from_json(cls, path: Path) -> "DailyFullStateKNetContract":
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls.from_dict(_mapping(payload, "configuration"))

    @classmethod
    def from_dict(
        cls, payload: Mapping[str, Any]
    ) -> "DailyFullStateKNetContract":
        validate_exact_configuration(payload)
        data = _mapping(payload["data"], "data")
        periods = _mapping(payload["periods"], "periods")
        forecast = _mapping(payload["forecast"], "forecast")
        model = _mapping(payload["model"], "model")
        training = _mapping(payload["training"], "training")
        gates = _mapping(payload["gates"], "gates")
        initialization = _mapping(
            model["gain_head_initialization"], "gain_head_initialization"
        )
        development = periods["development"]
        contract = cls(
            schema_version=str(payload["schema_version"]),
            experiment_id=str(payload["experiment_id"]),
            cadence=str(data["cadence"]),
            forcing_columns=tuple(str(value) for value in data["forcing_columns"]),
            archive_members=tuple(
                str(value) for value in data["materialized_archive_members"]
            ),
            expected_days=int(data["expected_days"]),
            development_start=str(development[0]),
            development_end=str(development[1]),
            training_end=str(periods["training_end"]),
            validation_start=str(periods["validation_start"]),
            leads=tuple(int(value) for value in forecast["leads_days"]),
            information_timing=str(forecast["information_timing"]),
            state_dimension=int(model["state_dimension"]),
            maximum_routing_lag=int(model["maximum_routing_lag"]),
            spinup_days=int(training["spinup_days"]),
            normalized_feature_guard=float(model["normalized_feature_guard"]),
            state_upper_bound_multiplier=float(
                model["state_upper_bound_multiplier"]
            ),
            gain_head_weight_multiplier=float(
                initialization["final_weight_multiplier"]
            ),
            minimum_post_zero_improvement=float(
                gates["minimum_post_zero_improvement"]
            ),
        )
        contract.validate()
        return contract

    def validate(self) -> None:
        _exact(self.schema_version, SCHEMA_VERSION, "schema_version")
        _exact(self.experiment_id, EXPERIMENT_ID, "experiment_id")
        _exact(self.cadence, "daily", "cadence")
        _exact(self.forcing_columns, EXPECTED_FORCING_COLUMNS, "forcing_columns")
        _exact(self.archive_members, EXPECTED_ARCHIVE_MEMBERS, "archive_members")
        _exact(self.expected_days, EXPECTED_DAYS, "expected_days")
        _exact(
            (self.development_start, self.development_end),
            (DEVELOPMENT_START, DEVELOPMENT_END),
            "development period",
        )
        _exact(
            (self.training_end, self.validation_start),
            (TRAINING_END, VALIDATION_START),
            "training/validation boundary",
        )
        _exact(
            self.validation_start_index,
            VALIDATION_START_INDEX,
            "validation_start_index",
        )
        _exact(self.leads, (1, 2, 3), "forecast leads")
        _exact(
            self.information_timing,
            "discharge_through_issue_day_and_meteorological_forcing_through_target_day",
            "information_timing",
        )
        _exact(self.state_dimension, STATE_DIMENSION, "state_dimension")
        _exact(
            self.maximum_routing_lag,
            MAXIMUM_ROUTING_LAG,
            "maximum_routing_lag",
        )
        _exact(self.spinup_days, 365, "spinup_days")
        _finite_close(self.normalized_feature_guard, 10.0, "normalized_feature_guard")
        _finite_close(
            self.state_upper_bound_multiplier, 2.0, "state_upper_bound_multiplier"
        )
        _finite_close(
            self.gain_head_weight_multiplier, 0.01, "gain_head_weight_multiplier"
        )
        _finite_close(
            self.minimum_post_zero_improvement,
            1.0e-6,
            "minimum_post_zero_improvement",
        )


def validate_exact_configuration(payload: Mapping[str, Any]) -> None:
    """Fail closed on every scientific factor used by the A34 smoke."""

    _exact_keys(
        payload,
        (
            "schema_version",
            "experiment_id",
            "data",
            "periods",
            "forecast",
            "scientific_limitations",
            "model",
            "loss_contract",
            "checkpoint_selection",
            "training",
            "gates",
            "a20_reference",
            "protected_formal_training",
            "source_sha256",
        ),
        "configuration",
    )
    _exact(payload.get("schema_version"), SCHEMA_VERSION, "schema_version")
    _exact(payload.get("experiment_id"), EXPERIMENT_ID, "experiment_id")
    forbidden_top = [key for key in payload if "evaluation" in str(key).lower()]
    if forbidden_top:
        raise ValueError(f"formal evaluation configuration is forbidden: {forbidden_top}")

    data = _mapping(payload.get("data"), "data")
    _exact_keys(
        data,
        (
            "cadence",
            "forcing_columns",
            "materialized_archive_members",
            "archive_members_present",
            "members_forbidden_from_materialization",
            "expected_days",
            "input_archives",
        ),
        "data",
    )
    _exact(data.get("cadence"), "daily", "data.cadence")
    _exact(tuple(data.get("forcing_columns", ())), EXPECTED_FORCING_COLUMNS, "forcing")
    _exact(
        tuple(data.get("materialized_archive_members", ())),
        EXPECTED_ARCHIVE_MEMBERS,
        "materialized members",
    )
    _exact(
        tuple(data.get("archive_members_present", ())),
        ARCHIVE_MEMBERS_PRESENT,
        "archive members present",
    )
    _exact(
        tuple(data.get("members_forbidden_from_materialization", ())),
        FORBIDDEN_MATERIALIZED_MEMBERS,
        "members forbidden from materialization",
    )
    _exact(data.get("expected_days"), EXPECTED_DAYS, "expected_days")
    archives = data.get("input_archives")
    if not isinstance(archives, list) or len(archives) != 2:
        raise ValueError("exactly two input archives are required")
    archive_ids = tuple(str(_mapping(row, "input archive").get("basin_id")) for row in archives)
    _exact(archive_ids, BASIN_IDS, "basin order")
    for row in archives:
        archive = _mapping(row, "input archive")
        _exact_keys(
            archive,
            ("basin_id", "path", "local_evidence_path", "sha256"),
            "input archive",
        )
        basin_id = str(archive["basin_id"])
        _exact(archive.get("sha256"), INPUT_SHA256[basin_id], f"{basin_id} input hash")
        _exact(archive.get("path"), f"inputs/basin_{basin_id}.npz", f"{basin_id} path")

    periods = _mapping(payload.get("periods"), "periods")
    if any("evaluation" in str(key).lower() for key in periods):
        raise ValueError("an evaluation period is forbidden")
    _exact_keys(periods, ("development", "training_end", "validation_start"), "periods")
    _exact(
        tuple(periods.get("development", ())),
        (DEVELOPMENT_START, DEVELOPMENT_END),
        "development period",
    )
    _exact(periods.get("training_end"), TRAINING_END, "training_end")
    _exact(periods.get("validation_start"), VALIDATION_START, "validation_start")

    forecast = _mapping(payload.get("forecast"), "forecast")
    _exact_keys(forecast, ("leads_days", "information_timing"), "forecast")
    _exact(tuple(forecast.get("leads_days", ())), (1, 2, 3), "forecast leads")
    _exact(
        forecast.get("information_timing"),
        "discharge_through_issue_day_and_meteorological_forcing_through_target_day",
        "information timing",
    )

    limitations = _mapping(payload.get("scientific_limitations"), "scientific_limitations")
    _exact_keys(
        limitations,
        (
            "physical_parameter_provenance",
            "validation_interpretation",
            "forecast_interpretation",
        ),
        "scientific_limitations",
    )
    _exact(
        limitations.get("physical_parameter_provenance"),
        "frozen_hbv_parameters_previously_calibrated_using_the_full_1999_10_01_to_2008_09_30_development_period",
        "physical parameter provenance",
    )
    _exact(
        limitations.get("validation_interpretation"),
        "the_2006_10_01_onward_window_is_isolated_from_kalmannet_training_and_training_scale_statistics_but_not_from_prior_hbv_parameter_calibration",
        "validation interpretation",
    )
    _exact(
        limitations.get("forecast_interpretation"),
        "retrospective_perfect_future_meteorological_forcing_not_operational_forecasting",
        "forecast interpretation",
    )

    model = _mapping(payload.get("model"), "model")
    _exact_keys(
        model,
        (
            "backend",
            "state_dimension",
            "maximum_routing_lag",
            "corrected_state_scope",
            "inactive_padded_routing_tail_correction",
            "static_attributes_enabled",
            "residual_memory_order",
            "correction_cap_enabled",
            "learned_physical_parameters_enabled",
            "hidden_dimension",
            "input_multiplier",
            "output_multiplier",
            "physical_dtype",
            "gain_network_dtype",
            "normalized_feature_guard",
            "feature_scale",
            "state_upper_bound_multiplier",
            "soil_field_capacity_upper_bound",
            "gain_head_initialization",
            "strict_zero_gain_open_loop_control_saved_separately",
        ),
        "model",
    )
    exact_model = {
        "backend": "repository_native_kalmannet_lstm",
        "state_dimension": STATE_DIMENSION,
        "maximum_routing_lag": MAXIMUM_ROUTING_LAG,
        "corrected_state_scope": "five_hbv_storages_and_complete_physically_active_routing_fifo",
        "inactive_padded_routing_tail_correction": False,
        "static_attributes_enabled": False,
        "residual_memory_order": 0,
        "correction_cap_enabled": False,
        "learned_physical_parameters_enabled": False,
        "hidden_dimension": 32,
        "input_multiplier": 10,
        "output_multiplier": 10,
        "physical_dtype": "float32",
        "gain_network_dtype": "float32",
        "normalized_feature_guard": 10.0,
        "feature_scale": "1.2_times_training_maximum_absolute_adjacent_difference",
        "state_upper_bound_multiplier": 2.0,
        "soil_field_capacity_upper_bound": True,
        "strict_zero_gain_open_loop_control_saved_separately": True,
    }
    for key, expected in exact_model.items():
        _exact(model.get(key), expected, f"model.{key}")
    initialization = _mapping(
        model.get("gain_head_initialization"), "gain_head_initialization"
    )
    _exact_keys(initialization, ("mode", "final_weight_multiplier", "final_bias"), "initialization")
    _exact(initialization.get("mode"), "a20_actual_near_zero", "initialization mode")
    _finite_close(initialization.get("final_weight_multiplier"), 0.01, "weight scale")
    _finite_close(initialization.get("final_bias"), 0.0, "final bias")

    loss = _mapping(payload.get("loss_contract"), "loss_contract")
    _exact_keys(
        loss,
        (
            "contract_name",
            "formula",
            "training_statistics_start_index",
            "training_statistics_stop_index_exclusive",
            "population_standard_deviation_ddof",
            "loss_epsilon_original_discharge_units",
            "weighting_order",
            "target_noise",
            "training_events_per_basin_lead",
            "validation_events_per_basin_lead",
        ),
        "loss_contract",
    )
    _exact(loss.get("contract_name"), LOSS_CONTRACT_NAME, "loss contract")
    _exact(
        loss.get("formula"),
        "mean_equal_complete_basin_lead_events((prediction_physical-target_physical)^2/(basin_training_population_std_original_units+0.1)^2)",
        "loss formula",
    )
    _exact(loss.get("training_statistics_start_index"), 0, "training scale start")
    _exact(
        loss.get("training_statistics_stop_index_exclusive"),
        VALIDATION_START_INDEX,
        "training scale stop",
    )
    _exact(loss.get("population_standard_deviation_ddof"), 0, "loss ddof")
    _finite_close(loss.get("loss_epsilon_original_discharge_units"), 0.1, "loss epsilon")
    _exact(
        tuple(loss.get("weighting_order", ())),
        (
            "equal_events_within_each_basin_and_lead",
            "equal_leads_1_2_3_within_each_basin",
            "equal_basins_within_every_optimizer_step",
        ),
        "loss weighting",
    )
    _exact(loss.get("training_events_per_basin_lead"), 45, "training events")
    _exact(loss.get("validation_events_per_basin_lead"), 109, "validation events")
    _exact(loss.get("target_noise"), "none_for_kalmannet_filter_training", "target noise")

    selection = _mapping(payload.get("checkpoint_selection"), "checkpoint_selection")
    _exact_keys(
        selection,
        ("metric", "direction", "tie_break", "forbidden_components"),
        "checkpoint_selection",
    )
    _exact(selection.get("metric"), "negative_shared_frozen_validation_loss", "selection")
    _exact(selection.get("direction"), "maximize", "selection direction")
    _exact(selection.get("tie_break"), "earliest_epoch", "selection tie break")
    _exact(
        tuple(selection.get("forbidden_components", ())),
        ("nash_sutcliffe_efficiency_gain", "catastrophic_degradation_fraction"),
        "selection forbidden components",
    )

    training = _mapping(payload.get("training"), "training")
    expected_training = {
        "spinup_days": 365,
        "segment_days": 64,
        "filter_warmup_days": 16,
        "validation_window_days": 128,
        "epochs": 4,
        "steps_per_epoch": 2,
        "seed": 20260825,
        "optimizer": "Adam",
        "learning_rate": 0.0005,
        "weight_decay": 0.00001,
        "gradient_maximum_norm": 10.0,
        "expected_optimizer_steps": 8,
        "expected_forecast_error_events": 2160,
    }
    _exact_keys(training, tuple(expected_training), "training")
    for key, expected in expected_training.items():
        value = training.get(key)
        if isinstance(expected, float):
            _finite_close(value, expected, f"training.{key}")
        else:
            _exact(value, expected, f"training.{key}")

    gates = _mapping(payload.get("gates"), "gates")
    _exact_keys(
        gates,
        (
            "minimum_post_zero_improvement",
            "require_selected_epoch_after_zero",
            "require_each_basin_loss_improvement",
            "require_all_six_cell_physical_mse_improvements",
            "require_all_six_cells_better_than_a20",
            "require_finite_nonzero_gradients_for_every_trainable_tensor",
            "strict_zero_open_loop_absolute_tolerance",
            "require_zero_reserved_data_access",
        ),
        "gates",
    )
    _finite_close(gates.get("minimum_post_zero_improvement"), 1.0e-6, "gate")
    for key in (
        "require_selected_epoch_after_zero",
        "require_each_basin_loss_improvement",
        "require_all_six_cell_physical_mse_improvements",
        "require_all_six_cells_better_than_a20",
        "require_finite_nonzero_gradients_for_every_trainable_tensor",
        "require_zero_reserved_data_access",
    ):
        _exact(gates.get(key), True, f"gates.{key}")
    _finite_close(
        gates.get("strict_zero_open_loop_absolute_tolerance"),
        1.0e-7,
        "strict-zero tolerance",
    )

    reference = _mapping(payload.get("a20_reference"), "a20_reference")
    _exact_keys(
        reference,
        (
            "experiment_id",
            "result_summary_path",
            "result_summary_sha256",
            "selected_epoch",
            "selected_physical_mse_by_basin_and_lead",
        ),
        "a20_reference",
    )
    _exact(reference.get("experiment_id"), A20_EXPERIMENT_ID, "A20 experiment")
    _exact(reference.get("result_summary_path"), A20_RESULT_PATH, "A20 path")
    _exact(reference.get("result_summary_sha256"), A20_RESULT_SHA256, "A20 hash")
    _exact(reference.get("selected_epoch"), 4, "A20 selected epoch")
    raw_cells = _mapping(
        reference.get("selected_physical_mse_by_basin_and_lead"),
        "A20 cell evidence",
    )
    for basin_id, expected_by_lead in A20_PHYSICAL_MSE.items():
        row = _mapping(raw_cells.get(basin_id), f"A20 {basin_id}")
        for lead, expected in expected_by_lead.items():
            _finite_close(row.get(str(lead)), expected, f"A20 {basin_id} lead {lead}")

    protected = _mapping(payload.get("protected_formal_training"), "protected formal training")
    _exact_keys(protected, ("owner_paths",), "protected formal training")
    _exact(
        tuple(protected.get("owner_paths", ())),
        (
            "results/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1/control/.sequence_controller.lock/owner.json",
            "results/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1/control/.training_phase.lock/owner.json",
            "results/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1/control/.filter_controller.lock/owner.json",
        ),
        "protected formal owner paths",
    )
    sources = _mapping(payload.get("source_sha256"), "source_sha256")
    _exact(tuple(sources), EXPECTED_SOURCE_PATHS, "source closure order")
    for relative, digest in sources.items():
        if not isinstance(digest, str) or len(digest) != 64 or any(
            character not in "0123456789abcdef" for character in digest
        ):
            raise ValueError(f"source SHA-256 is invalid for {relative}")


def validate_a20_reference_summary(payload: Mapping[str, Any]) -> None:
    """Bind the six comparison thresholds to the archived A20 result itself."""

    _exact(payload.get("experiment_id"), A20_EXPERIMENT_ID, "A20 result experiment")
    _exact(payload.get("status"), "COMPLETED", "A20 result status")
    gate = _mapping(payload.get("science_gate"), "A20 science gate")
    _exact(gate.get("best_epoch"), 4, "A20 result selected epoch")
    history = payload.get("history")
    if not isinstance(history, list) or tuple(
        int(_mapping(row, "A20 history row").get("epoch", -1)) for row in history
    ) != (0, 1, 2, 3, 4):
        raise ValueError("A20 result history must contain epochs zero through four")
    selected = _mapping(history[4], "A20 selected history record")
    per_basin = _mapping(selected.get("per_basin"), "A20 selected per-basin evidence")
    for basin_id, expected_by_lead in A20_PHYSICAL_MSE.items():
        basin = _mapping(per_basin.get(basin_id), f"A20 result basin {basin_id}")
        per_lead = _mapping(
            basin.get("per_lead_loss_evidence"),
            f"A20 result basin {basin_id} per-lead evidence",
        )
        for lead, expected in expected_by_lead.items():
            cell = per_lead.get(str(lead), per_lead.get(lead))
            cell = _mapping(cell, f"A20 result basin {basin_id} lead {lead}")
            _finite_close(
                cell.get("physical_mse"),
                expected,
                f"A20 result basin {basin_id} lead {lead} physical MSE",
            )


def a20_training_unit_geometry(
    payload: Mapping[str, Any],
) -> tuple[tuple[tuple[int, int, str, int, int], ...], ...]:
    """Return the archived A20 epoch/step/basin/start/end sampling geometry."""

    validate_a20_reference_summary(payload)
    history = payload["history"]
    epochs: list[tuple[tuple[int, int, str, int, int], ...]] = []
    for epoch in range(1, 5):
        record = _mapping(history[epoch], f"A20 epoch {epoch}")
        units = record.get("training_units")
        if not isinstance(units, list) or len(units) != 4:
            raise ValueError(f"A20 epoch {epoch} must contain four basin training units")
        geometry = tuple(
            (
                epoch,
                int(_mapping(unit, "A20 training unit")["step_in_epoch"]),
                str(_mapping(unit, "A20 training unit")["basin_id"]),
                int(_mapping(unit, "A20 training unit")["start_index"]),
                int(_mapping(unit, "A20 training unit")["end_index_exclusive"]),
            )
            for unit in units
        )
        expected_order = (
            (epoch, 0, BASIN_IDS[0]),
            (epoch, 0, BASIN_IDS[1]),
            (epoch, 1, BASIN_IDS[0]),
            (epoch, 1, BASIN_IDS[1]),
        )
        if tuple(row[:3] for row in geometry) != expected_order:
            raise ValueError(f"A20 epoch {epoch} sampling order changed")
        if any(row[4] - row[3] != 64 for row in geometry):
            raise ValueError(f"A20 epoch {epoch} segment length changed")
        epochs.append(geometry)
    return tuple(epochs)


__all__ = [
    "A20_EXPERIMENT_ID",
    "A20_PHYSICAL_MSE",
    "A20_RESULT_PATH",
    "A20_RESULT_SHA256",
    "AccessLedger",
    "BASIN_IDS",
    "DailyFullStateKNetContract",
    "EXPERIMENT_ID",
    "EXPECTED_SOURCE_PATHS",
    "INPUT_SHA256",
    "MAXIMUM_ROUTING_LAG",
    "SCHEMA_VERSION",
    "STATE_DIMENSION",
    "a20_training_unit_geometry",
    "validate_daily_dates",
    "validate_a20_reference_summary",
    "validate_exact_configuration",
]
