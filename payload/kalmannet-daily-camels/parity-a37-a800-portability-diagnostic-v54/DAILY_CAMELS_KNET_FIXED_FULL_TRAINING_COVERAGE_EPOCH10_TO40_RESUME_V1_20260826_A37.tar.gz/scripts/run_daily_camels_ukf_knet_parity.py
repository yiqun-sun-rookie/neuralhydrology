"""Sole fail-closed entry for daily CAMELS UKF/KalmanNet parity runs.

The module imports only the Python standard library at import time.  The
configuration contract, every pinned byte source, the development archive,
the TUKF06 selection record, the output target, and the initialization role
are checked before NumPy, PyTorch, or the numerical runner is imported.

``probe`` is read-only.  ``replay`` creates one new evidence directory and
executes only the UKF and zero-gain controls.  ``train`` creates one new
directory, repeats those controls, and is admitted only for causal shared
spin-up with an independently frozen 728-origin UKF reference objective.
"""

from __future__ import annotations

import argparse
import ast
import copy
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from hashlib import sha256
import importlib
import importlib.util
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import random
import re
import shutil
import socket
import subprocess
import sys
from types import ModuleType, SimpleNamespace
from typing import Any, Iterable, Mapping, Sequence


CONTRACT_RELATIVE = (
    "src/global_hydrology/experiments/"
    "daily_camels_ukf_knet_parity_contract.py"
)
RUNNER_RELATIVE = (
    "src/global_hydrology/experiments/"
    "daily_camels_ukf_knet_parity_runner.py"
)
IO_RELATIVE = (
    "src/global_hydrology/experiments/daily_camels_native_knet_io.py"
)

# These two integration files are not part of the older TUKF06 source map, so
# this entry pins them explicitly.  Update only through a new reviewed run
# family when either byte stream changes.
EXPECTED_CONTRACT_SHA256 = (
    "bd70eadf8d2be311b5e623517e75f7d7b815dbde18603a219f6b1e3085223d52"
)
EXPECTED_RUNNER_SHA256 = (
    "2fd983a4af52ee02fd677e8ee51894d8208b836d6e9759b3ff2ac3a82c89ea69"
)
EXPECTED_IO_SHA256 = (
    "2db6c61276b4d2900321e58d04d639fecaf3957d557c4c5b5b4121fd01c3e918"
)

NATIVE_DEFAULT_GAIN_INITIALIZATION = "native_default"
NEAR_ZERO_FC2_HEAD_GAIN_INITIALIZATION = "near_zero_fc2_head"
ALLOWED_GAIN_INITIALIZATIONS = (
    NATIVE_DEFAULT_GAIN_INITIALIZATION,
    NEAR_ZERO_FC2_HEAD_GAIN_INITIALIZATION,
)
PHASES = ("probe", "replay", "train")
OWNER_LOCK_DIRECTORY = ".owner.lock"
IDENTITY_FILE = "experiment_identity.json"
PREFLIGHT_FILE = "preflight.json"
EVENT_FILE = "events.jsonl"
REPLAY_FILE = "replay_evidence.json"
REPLAY_PREDICTIONS_FILE = "replay_predictions.npz"
FEATURE_FILE = "feature_diagnostics.json"
HISTORY_FILE = "epoch_history.json"
SUMMARY_FILE = "result_summary.json"
MANIFEST_FILE = "manifest.sha256.json"
COMPLETION_FILE = "completion.marker.json"
FAILURE_FILE = "failure.json"
CHECKPOINT_DIRECTORY = "checkpoints"
PREDICTION_DIRECTORY = "predictions"
CAUSAL_REFERENCE_KEY = (
    "causal_tukf06_complete_validation_objective_no_warmup"
)
CAUSAL_NSE_REFERENCE_KEY = "causal_tukf06_recovery_731_day_nse"
REFERENCE_ABSOLUTE_TOLERANCE = 1e-12
CONTRACT_MODULE_ALIAS = "_daily_camels_parity_contract_preflight"
IO_MODULE_ALIAS = "_daily_camels_parity_io_preflight"
EXPERIMENT_ID_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{7,127}\Z")
SEEDED_UNIFORM_SINGLE_SEGMENT = "seeded_uniform_single_segment_per_optimizer_step"
FIXED_FULL_TRAINING_COVERAGE = "fixed_full_training_coverage_round_half_up"
ALLOWED_TRAINING_SEGMENT_SAMPLING = (
    SEEDED_UNIFORM_SINGLE_SEGMENT,
    FIXED_FULL_TRAINING_COVERAGE,
)
FULL_EIGHTEEN_DIMENSIONAL_STATE_CORRECTION_SCOPE = (
    "full_eighteen_dimensional_state_correction"
)
HBV_LITE_FIVE_STORAGE_STATE_CORRECTION_SCOPE = (
    "hbv_lite_five_storage_state_correction"
)
ALLOWED_CORRECTION_SCOPES = (
    FULL_EIGHTEEN_DIMENSIONAL_STATE_CORRECTION_SCOPE,
    HBV_LITE_FIVE_STORAGE_STATE_CORRECTION_SCOPE,
)
CONTINUATION_SCHEMA_VERSION = "daily_camels_ukf_knet_parity_continuation_v1"
CHECKPOINT_SCHEMA_VERSION = "daily_camels_ukf_knet_parity_checkpoint_v1"


@dataclass(frozen=True)
class ContinuationSpec:
    source_configuration_path: Path
    source_configuration_relative: str
    source_configuration_sha256: str
    source_experiment_id: str
    source_identity_sha256: str
    source_device: str
    checkpoint_path: Path
    checkpoint_relative: str
    checkpoint_sha256: str
    checkpoint_schema_version: str
    completed_epoch: int
    optimizer_steps: int
    sampled_forecast_events: int
    parameter_sha256: str
    source_epoch_history_sha256: str
    source_result_summary_sha256: str
    source_evidence_archive_sha256: str


@dataclass(frozen=True)
class PreflightResult:
    repository_root: Path
    configuration_path: Path
    configuration: Mapping[str, Any]
    configuration_sha256: str
    contract: Any
    declared_source_sha256: Mapping[str, str]
    integration_source_sha256: Mapping[str, str]
    input_sha256: Mapping[str, str]
    input_paths: Mapping[str, Path]
    experiment_id: str
    initialization_mode: str
    gain_initialization: str
    correction_scope: str
    scientific_claim_allowed: bool
    phase: str
    run_parent: Path
    run_directory: Path
    identity: Mapping[str, Any]
    identity_sha256: str
    continuation: ContinuationSpec | None


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def canonical_json_bytes(value: object) -> bytes:
    return (
        json.dumps(
            _jsonable(value),
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
        + b"\n"
    )


def _model_correction_scope(model: Mapping[str, Any]) -> str:
    """Return one explicit effective physical-update scope.

    Historical configurations predate this single-factor diagnostic and retain
    their exact full-state behavior.  New configurations may restrict only the
    *effective physical correction* while leaving the archived 18-dimensional
    KalmanNet core and its recurrent features unchanged.
    """

    value = model.get(
        "correction_scope", FULL_EIGHTEEN_DIMENSIONAL_STATE_CORRECTION_SCOPE
    )
    if not isinstance(value, str):
        raise TypeError("model.correction_scope must be a string")
    if value not in ALLOWED_CORRECTION_SCOPES:
        raise ValueError(
            "model.correction_scope must be full_eighteen_dimensional_state_correction "
            "or hbv_lite_five_storage_state_correction"
        )
    return value


def _jsonable(value: object) -> object:
    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("JSON evidence contains a non-finite float")
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(key): _jsonable(member) for key, member in value.items()}
    if isinstance(value, (list, tuple, set, frozenset)):
        return [_jsonable(member) for member in value]
    if hasattr(value, "item"):
        try:
            return _jsonable(value.item())
        except (TypeError, ValueError):
            pass
    raise TypeError(f"value of type {type(value).__name__} is not JSON evidence")


def _reject_duplicate_members(pairs: Sequence[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON member: {key}")
        result[key] = value
    return result


def _read_json(path: Path) -> Mapping[str, Any]:
    try:
        value = json.loads(
            path.read_text(encoding="utf-8"),
            object_pairs_hook=_reject_duplicate_members,
            parse_constant=lambda token: (_ for _ in ()).throw(
                ValueError(f"non-finite JSON constant: {token}")
            ),
        )
    except UnicodeDecodeError as exc:
        raise ValueError(f"JSON is not UTF-8: {path}") from exc
    if not isinstance(value, Mapping):
        raise TypeError(f"JSON root must be an object: {path}")
    return value


def sha256_file(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _regular_file(path: Path, label: str) -> Path:
    candidate = Path(path)
    if not candidate.is_file() or candidate.is_symlink():
        raise FileNotFoundError(f"{label} must be a regular non-symlink file: {candidate}")
    return candidate


def _relative_path(value: object, label: str) -> str:
    if not isinstance(value, str) or not value or "\\" in value:
        raise ValueError(f"{label} must be a non-empty forward-slash relative path")
    path = PurePosixPath(value)
    if path.is_absolute() or ".." in path.parts or not path.parts:
        raise ValueError(f"{label} must remain below the repository root")
    return path.as_posix()


def _sha256(value: object, label: str) -> str:
    if not isinstance(value, str):
        raise TypeError(f"{label} must be a SHA-256 string")
    lowered = value.lower()
    if len(lowered) != 64 or any(c not in "0123456789abcdef" for c in lowered):
        raise ValueError(f"{label} must contain 64 hexadecimal characters")
    return lowered


def _normalize_nse_reference(
    value: object, leads: Sequence[int]
) -> dict[int, float]:
    ordered = tuple(int(lead) for lead in leads)
    if isinstance(value, Mapping):
        try:
            normalized = {lead: float(value.get(str(lead), value.get(lead))) for lead in ordered}
        except (TypeError, ValueError) as exc:
            raise ValueError("causal UKF NSE reference is invalid") from exc
    elif isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        if len(value) != len(ordered):
            raise ValueError("causal UKF NSE reference length differs from the lead count")
        try:
            normalized = {lead: float(member) for lead, member in zip(ordered, value)}
        except (TypeError, ValueError) as exc:
            raise ValueError("causal UKF NSE reference is invalid") from exc
    else:
        raise ValueError("causal training requires a per-lead UKF NSE reference")
    if any(not math.isfinite(member) for member in normalized.values()):
        raise ValueError("causal UKF NSE reference contains a non-finite value")
    return normalized


def _load_standard_library_module(alias: str, path: Path) -> ModuleType:
    existing = sys.modules.get(alias)
    if isinstance(existing, ModuleType):
        return existing
    specification = importlib.util.spec_from_file_location(alias, path)
    if specification is None or specification.loader is None:
        raise ImportError(f"cannot load module specification for {path}")
    module = importlib.util.module_from_spec(specification)
    sys.modules[alias] = module
    try:
        specification.loader.exec_module(module)
    except Exception:
        sys.modules.pop(alias, None)
        raise
    return module


def _resolved_child(root: Path, relative: str, label: str) -> Path:
    path = (root / Path(*PurePosixPath(relative).parts)).resolve()
    try:
        path.relative_to(root.resolve())
    except ValueError as exc:
        raise ValueError(f"{label} escapes the repository root") from exc
    return _regular_file(path, label)


def _assert_hash(path: Path, expected: str, label: str) -> str:
    actual = sha256_file(path)
    if actual != expected:
        raise RuntimeError(
            f"{label} SHA-256 changed: expected {expected}, received {actual}"
        )
    return actual


def _assert_one_factor_continuation(
    source: Mapping[str, Any],
    target: Mapping[str, Any],
) -> None:
    """Require a continuation to change only identity and the epoch ceiling."""

    if not isinstance(source, Mapping) or not isinstance(target, Mapping):
        raise TypeError("one-factor continuation inputs must be JSON objects")
    source_copy = copy.deepcopy(dict(source))
    target_copy = copy.deepcopy(dict(target))
    continuation = target_copy.pop("continuation", None)
    if not isinstance(continuation, Mapping):
        raise ValueError("one-factor continuation requires a continuation object")

    for name, configuration in (("source", source_copy), ("target", target_copy)):
        optimization = configuration.get("optimization")
        if not isinstance(optimization, Mapping):
            raise TypeError(f"{name} optimization must be a JSON object")
        configuration["optimization"] = dict(optimization)

    source_epochs = source_copy["optimization"].get("training_epochs")
    target_epochs = target_copy["optimization"].get("training_epochs")
    for name, value in (("source", source_epochs), ("target", target_epochs)):
        if isinstance(value, bool) or not isinstance(value, int) or value < 1:
            raise ValueError(f"{name} training_epochs must be a positive integer")
    if target_epochs <= source_epochs:
        raise ValueError(
            "one-factor continuation target training_epochs must be greater than source"
        )

    source_experiment_id = source_copy.get("experiment_id")
    target_experiment_id = target_copy.get("experiment_id")
    source_role = source_copy.get("scientific_role")
    target_role = target_copy.get("scientific_role")
    if not all(
        isinstance(value, str) and value
        for value in (
            source_experiment_id,
            target_experiment_id,
            source_role,
            target_role,
        )
    ):
        raise ValueError("one-factor continuation identities and roles must be strings")
    if target_experiment_id == source_experiment_id:
        raise ValueError("one-factor continuation requires a new experiment_id")

    target_copy["experiment_id"] = source_experiment_id
    target_copy["scientific_role"] = source_role
    target_copy["optimization"]["training_epochs"] = source_epochs
    if canonical_json_bytes(target_copy) != canonical_json_bytes(source_copy):
        raise ValueError(
            "one-factor continuation changed a field other than experiment identity, "
            "scientific role, training_epochs, or continuation provenance"
        )


def _required_nonempty_string(value: object, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise ValueError(f"{label} must be a non-empty string")
    return value


def _required_nonnegative_integer(value: object, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{label} must be a nonnegative integer")
    return value


def _continuation_identity(spec: ContinuationSpec) -> Mapping[str, Any]:
    return {
        "schema_version": CONTINUATION_SCHEMA_VERSION,
        "source_configuration_path": spec.source_configuration_relative,
        "source_configuration_sha256": spec.source_configuration_sha256,
        "source_experiment_id": spec.source_experiment_id,
        "source_identity_sha256": spec.source_identity_sha256,
        "source_device": spec.source_device,
        "checkpoint_path": spec.checkpoint_relative,
        "checkpoint_sha256": spec.checkpoint_sha256,
        "checkpoint_schema_version": spec.checkpoint_schema_version,
        "completed_epoch": spec.completed_epoch,
        "optimizer_steps": spec.optimizer_steps,
        "sampled_forecast_events": spec.sampled_forecast_events,
        "parameter_sha256": spec.parameter_sha256,
        "source_epoch_history_sha256": spec.source_epoch_history_sha256,
        "source_result_summary_sha256": spec.source_result_summary_sha256,
        "source_evidence_archive_sha256": spec.source_evidence_archive_sha256,
    }


def _continuation_spec(
    configuration: Mapping[str, Any],
    root: Path,
    resume: Path | None,
) -> ContinuationSpec | None:
    declared = configuration.get("continuation")
    if declared is None:
        if resume is not None:
            raise ValueError("--resume is forbidden when continuation is not declared")
        return None
    if not isinstance(declared, Mapping):
        raise TypeError("continuation must be a JSON object")
    if resume is None:
        raise ValueError("continuation requires an explicit --resume checkpoint")

    required = {
        "schema_version",
        "source_configuration_path",
        "source_configuration_sha256",
        "source_experiment_id",
        "source_identity_sha256",
        "source_device",
        "checkpoint_path",
        "checkpoint_sha256",
        "checkpoint_schema_version",
        "completed_epoch",
        "optimizer_steps",
        "sampled_forecast_events",
        "parameter_sha256",
        "source_epoch_history_sha256",
        "source_result_summary_sha256",
        "source_evidence_archive_sha256",
    }
    if set(declared) != required:
        raise ValueError("continuation keys are incomplete or unexpected")
    if declared["schema_version"] != CONTINUATION_SCHEMA_VERSION:
        raise ValueError("continuation.schema_version is unsupported")
    if declared["checkpoint_schema_version"] != CHECKPOINT_SCHEMA_VERSION:
        raise ValueError("continuation.checkpoint_schema_version is unsupported")
    if declared["source_device"] not in {"cpu", "cuda"}:
        raise ValueError("continuation.source_device must be cpu or cuda")

    source_relative = _relative_path(
        declared["source_configuration_path"],
        "continuation.source_configuration_path",
    )
    checkpoint_relative = _relative_path(
        declared["checkpoint_path"],
        "continuation.checkpoint_path",
    )
    source_path = _resolved_child(
        root, source_relative, "continuation source configuration"
    )
    checkpoint_path = _resolved_child(
        root, checkpoint_relative, "continuation checkpoint"
    )
    source_configuration_sha256 = _sha256(
        declared["source_configuration_sha256"],
        "continuation.source_configuration_sha256",
    )
    checkpoint_sha256 = _sha256(
        declared["checkpoint_sha256"], "continuation.checkpoint_sha256"
    )
    _assert_hash(
        source_path,
        source_configuration_sha256,
        "continuation source configuration",
    )
    _assert_hash(checkpoint_path, checkpoint_sha256, "continuation checkpoint")

    resume_path = _regular_file(
        Path(resume).expanduser().resolve(), "--resume checkpoint"
    )
    if resume_path != checkpoint_path:
        raise ValueError(
            f"--resume must equal the pinned path {checkpoint_path}; received {resume_path}"
        )

    source_configuration = _read_json(source_path)
    _assert_one_factor_continuation(source_configuration, configuration)
    source_experiment_id = _required_nonempty_string(
        declared["source_experiment_id"], "continuation.source_experiment_id"
    )
    if source_configuration.get("experiment_id") != source_experiment_id:
        raise RuntimeError("continuation source_experiment_id differs from source config")

    completed_epoch = _required_nonnegative_integer(
        declared["completed_epoch"], "continuation.completed_epoch"
    )
    optimizer_steps = _required_nonnegative_integer(
        declared["optimizer_steps"], "continuation.optimizer_steps"
    )
    sampled_forecast_events = _required_nonnegative_integer(
        declared["sampled_forecast_events"],
        "continuation.sampled_forecast_events",
    )
    source_optimization = source_configuration.get("optimization")
    target_optimization = configuration.get("optimization")
    if not isinstance(source_optimization, Mapping) or not isinstance(
        target_optimization, Mapping
    ):
        raise TypeError("continuation optimization blocks must be JSON objects")
    if source_optimization.get("training_epochs") != completed_epoch:
        raise RuntimeError("continuation completed_epoch differs from source budget")
    target_epochs = target_optimization.get("training_epochs")
    if isinstance(target_epochs, bool) or not isinstance(target_epochs, int):
        raise ValueError("continuation target training_epochs must be an integer")
    if target_epochs <= completed_epoch:
        raise ValueError(
            "continuation target training_epochs must be greater than completed_epoch"
        )
    source_steps_per_epoch = source_optimization.get("steps_per_epoch")
    if (
        isinstance(source_steps_per_epoch, bool)
        or not isinstance(source_steps_per_epoch, int)
        or source_steps_per_epoch < 1
    ):
        raise ValueError("source steps_per_epoch must be a positive integer")
    if optimizer_steps != completed_epoch * source_steps_per_epoch:
        raise RuntimeError("continuation optimizer_steps differs from source contract")
    if completed_epoch == 0 or sampled_forecast_events == 0:
        raise ValueError("continuation must resume after observed training progress")

    return ContinuationSpec(
        source_configuration_path=source_path,
        source_configuration_relative=source_relative,
        source_configuration_sha256=source_configuration_sha256,
        source_experiment_id=source_experiment_id,
        source_identity_sha256=_sha256(
            declared["source_identity_sha256"],
            "continuation.source_identity_sha256",
        ),
        source_device=str(declared["source_device"]),
        checkpoint_path=checkpoint_path,
        checkpoint_relative=checkpoint_relative,
        checkpoint_sha256=checkpoint_sha256,
        checkpoint_schema_version=CHECKPOINT_SCHEMA_VERSION,
        completed_epoch=completed_epoch,
        optimizer_steps=optimizer_steps,
        sampled_forecast_events=sampled_forecast_events,
        parameter_sha256=_sha256(
            declared["parameter_sha256"], "continuation.parameter_sha256"
        ),
        source_epoch_history_sha256=_sha256(
            declared["source_epoch_history_sha256"],
            "continuation.source_epoch_history_sha256",
        ),
        source_result_summary_sha256=_sha256(
            declared["source_result_summary_sha256"],
            "continuation.source_result_summary_sha256",
        ),
        source_evidence_archive_sha256=_sha256(
            declared["source_evidence_archive_sha256"],
            "continuation.source_evidence_archive_sha256",
        ),
    )


def _validate_continuation_payload(
    payload: Mapping[str, Any],
    spec: ContinuationSpec | Any,
) -> None:
    """Validate checkpoint identity and resumable state before mutating a model."""

    if not isinstance(payload, Mapping):
        raise TypeError("continuation checkpoint payload must be a mapping")
    expected_schema = getattr(spec, "checkpoint_schema_version", CHECKPOINT_SCHEMA_VERSION)
    if payload.get("schema_version") != expected_schema:
        raise ValueError("checkpoint schema_version differs from continuation contract")

    identity = payload.get("identity")
    if not isinstance(identity, Mapping):
        raise TypeError("checkpoint identity must be a mapping")
    computed_identity_sha256 = sha256(canonical_json_bytes(identity)).hexdigest()
    payload_identity_sha256 = payload.get("identity_sha256")
    if payload_identity_sha256 != computed_identity_sha256:
        raise RuntimeError("checkpoint identity_sha256 does not match identity bytes")
    if payload_identity_sha256 != spec.source_identity_sha256:
        raise RuntimeError("checkpoint identity_sha256 differs from continuation source")
    if identity.get("experiment_id") != spec.source_experiment_id:
        raise RuntimeError("checkpoint source_experiment_id differs from continuation source")
    if identity.get("configuration_sha256") != spec.source_configuration_sha256:
        raise RuntimeError(
            "checkpoint source configuration_sha256 differs from continuation source"
        )
    if identity.get("phase") != "train":
        raise RuntimeError("continuation checkpoint identity phase is not train")
    if payload.get("gain_initialization") != identity.get("gain_initialization"):
        raise RuntimeError("checkpoint gain_initialization differs from identity")
    if payload.get("correction_scope") != identity.get("correction_scope"):
        raise RuntimeError("checkpoint correction_scope differs from identity")

    for field in ("completed_epoch", "optimizer_steps", "sampled_forecast_events"):
        value = payload.get(field)
        if value != getattr(spec, field):
            raise RuntimeError(f"checkpoint {field} differs from continuation contract")

    history = payload.get("history")
    if not isinstance(history, Sequence) or isinstance(history, (str, bytes)) or not history:
        raise TypeError("checkpoint history must be a non-empty sequence")
    first = history[0]
    last = history[-1]
    if not isinstance(first, Mapping) or not isinstance(last, Mapping):
        raise TypeError("checkpoint history rows must be mappings")
    if first.get("epoch") != 0 or last.get("epoch") != spec.completed_epoch:
        raise RuntimeError("checkpoint history epoch boundary differs from completed_epoch")
    observed_epochs = [
        row.get("epoch") if isinstance(row, Mapping) else None for row in history
    ]
    if observed_epochs != list(range(spec.completed_epoch + 1)):
        raise RuntimeError("checkpoint history epochs are not complete and contiguous")
    if last.get("optimizer_steps") != spec.optimizer_steps:
        raise RuntimeError("checkpoint history optimizer_steps differs from continuation")
    if last.get("sampled_forecast_events") != spec.sampled_forecast_events:
        raise RuntimeError(
            "checkpoint history sampled_forecast_events differs from continuation"
        )
    if last.get("parameter_sha256") != spec.parameter_sha256:
        raise RuntimeError("checkpoint history parameter_sha256 differs from continuation")

    source_history_sha256 = getattr(spec, "source_epoch_history_sha256", None)
    if source_history_sha256 is not None:
        actual_history_sha256 = sha256(canonical_json_bytes(history)).hexdigest()
        if actual_history_sha256 != source_history_sha256:
            raise RuntimeError("checkpoint source_epoch_history_sha256 differs")

    required_resume_state = {
        "model_state",
        "optimizer_state",
        "best_epoch",
        "best_checkpoint_selection_objective",
        "best_model_state",
        "nonzero_gradient_parameter_names",
        "python_random_state",
        "numpy_random_state",
        "torch_cpu_random_state",
        "torch_cuda_random_states",
        "sampler_generator_state",
        "access_ledger",
        "previous_checkpoint_sha256",
    }
    missing = sorted(required_resume_state.difference(payload))
    if missing:
        raise ValueError(f"checkpoint resumable state is incomplete: {missing}")
    for field in ("model_state", "optimizer_state", "best_model_state", "access_ledger"):
        if not isinstance(payload[field], Mapping):
            raise TypeError(f"checkpoint {field} must be a mapping")
    gradient_names = payload["nonzero_gradient_parameter_names"]
    if (
        not isinstance(gradient_names, Sequence)
        or isinstance(gradient_names, (str, bytes))
        or any(not isinstance(name, str) or not name for name in gradient_names)
        or len(set(gradient_names)) != len(gradient_names)
    ):
        raise TypeError(
            "checkpoint nonzero_gradient_parameter_names must be unique strings"
        )
    best_epoch = payload["best_epoch"]
    if (
        isinstance(best_epoch, bool)
        or not isinstance(best_epoch, int)
        or best_epoch < 0
        or best_epoch > spec.completed_epoch
    ):
        raise ValueError("checkpoint best_epoch is outside completed history")
    if best_epoch != spec.completed_epoch:
        raise RuntimeError(
            "checkpoint best_epoch must equal the pinned source completed_epoch"
        )
    best_objective = payload["best_checkpoint_selection_objective"]
    if isinstance(best_objective, bool) or not isinstance(best_objective, (int, float)):
        raise TypeError("checkpoint best objective must be numeric")
    if not math.isfinite(float(best_objective)) or float(best_objective) < 0.0:
        raise ValueError("checkpoint best objective must be finite and nonnegative")
    history_best_objective = last.get(
        "checkpoint_selection_objective_728_origins_without_warmup"
    )
    if (
        isinstance(history_best_objective, bool)
        or not isinstance(history_best_objective, (int, float))
        or not math.isclose(
            float(history_best_objective),
            float(best_objective),
            rel_tol=0.0,
            abs_tol=1.0e-15,
        )
    ):
        raise RuntimeError("checkpoint best objective differs from best history row")
    ledger = payload["access_ledger"]
    for key in (
        "evaluation_array_reads",
        "evaluation_prediction_count",
        "evaluation_metric_count",
        "evaluation_output_count",
    ):
        if int(ledger.get(key, 0)) != 0:
            raise PermissionError(f"checkpoint access_ledger {key} is nonzero")


def _continuation_epoch_range(completed_epoch: int, target_epoch: int) -> range:
    for label, value in (
        ("completed_epoch", completed_epoch),
        ("target_epoch", target_epoch),
    ):
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError(f"{label} must be a nonnegative integer")
    if target_epoch <= completed_epoch:
        raise ValueError("target_epoch must be greater than completed_epoch")
    return range(completed_epoch + 1, target_epoch + 1)


def _experiment_directory(run_parent: Path, experiment_id: str) -> tuple[Path, Path]:
    if not EXPERIMENT_ID_PATTERN.fullmatch(experiment_id):
        raise ValueError("experiment_id is not a safe stable directory name")
    parent = Path(run_parent).expanduser().resolve()
    destination = (parent / experiment_id).resolve()
    if destination.parent != parent:
        raise ValueError("experiment output must be one direct child of run-parent")
    return parent, destination


def _validate_training_hyperparameters(optimization: Mapping[str, Any]) -> None:
    for key in ("training_epochs", "steps_per_epoch"):
        value = optimization.get(key)
        if isinstance(value, bool) or not isinstance(value, int) or value < 1:
            raise ValueError(f"optimization.{key} must be a positive integer")
    for key in ("learning_rate", "gradient_maximum_norm"):
        value = optimization.get(key)
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError(f"optimization.{key} must be numeric")
        if not math.isfinite(float(value)) or float(value) <= 0.0:
            raise ValueError(f"optimization.{key} must be finite and positive")

    segments_per_step = optimization.get("segments_per_optimizer_step", 1)
    if (
        isinstance(segments_per_step, bool)
        or not isinstance(segments_per_step, int)
        or segments_per_step < 1
    ):
        raise ValueError(
            "optimization.segments_per_optimizer_step must be a positive integer"
        )
    sampling = optimization.get(
        "training_segment_sampling", SEEDED_UNIFORM_SINGLE_SEGMENT
    )
    if not isinstance(sampling, str):
        raise TypeError("optimization.training_segment_sampling must be a string")
    if sampling not in ALLOWED_TRAINING_SEGMENT_SAMPLING:
        raise ValueError("optimization.training_segment_sampling is unsupported")

    fixed_starts = optimization.get("fixed_training_segment_start_indices")
    if sampling == SEEDED_UNIFORM_SINGLE_SEGMENT:
        if segments_per_step != 1:
            raise ValueError(
                "seeded uniform sampling requires one segment per optimizer step"
            )
        if fixed_starts is not None:
            raise ValueError(
                "seeded uniform sampling cannot declare fixed segment starts"
            )
        return

    if int(optimization["steps_per_epoch"]) != 1:
        raise ValueError(
            "fixed full training coverage requires exactly one averaged update per epoch"
        )
    if segments_per_step < 2:
        raise ValueError("fixed full training coverage requires multiple segments")
    if not isinstance(fixed_starts, list):
        raise TypeError("fixed training segment starts must be a JSON array")
    if len(fixed_starts) != segments_per_step:
        raise ValueError("fixed training segment count differs from its declaration")
    for value in fixed_starts:
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError(
                "fixed training segment starts must be nonnegative integers"
            )


def _round_half_up_evenly_spaced_starts(
    maximum_start: int,
    segment_count: int,
) -> tuple[int, ...]:
    """Return deterministic endpoints-inclusive starts without float rounding."""

    if isinstance(maximum_start, bool) or not isinstance(maximum_start, int):
        raise TypeError("maximum training segment start must be an integer")
    if maximum_start < 1:
        raise ValueError("full-coverage spacing requires a positive maximum start")
    if isinstance(segment_count, bool) or not isinstance(segment_count, int):
        raise TypeError("training segment count must be an integer")
    if segment_count < 2:
        raise ValueError("full-coverage spacing requires at least two segments")
    denominator = 2 * (segment_count - 1)
    return tuple(
        (2 * index * maximum_start + (segment_count - 1)) // denominator
        for index in range(segment_count)
    )


def _configured_training_segment_plan(
    optimization: Mapping[str, Any],
    *,
    training_days: int,
    leads: Sequence[int],
) -> Mapping[str, Any]:
    """Validate and describe the immutable segment geometry before PyTorch work."""

    _validate_training_hyperparameters(optimization)
    if isinstance(training_days, bool) or not isinstance(training_days, int):
        raise TypeError("training day count must be an integer")
    ordered_leads = tuple(int(value) for value in leads)
    if ordered_leads != tuple(sorted(set(ordered_leads))) or not ordered_leads:
        raise ValueError("training leads must be unique increasing integers")
    segment_days = int(optimization["segment_days"])
    warmup = int(optimization["segment_filter_warmup_days"])
    maximum_lead = max(ordered_leads)
    maximum_start = training_days - segment_days
    scored_issue_count_per_segment = segment_days - warmup - maximum_lead
    eligible_issue_count = training_days - warmup - maximum_lead
    if maximum_start < 0:
        raise ValueError("training segment exceeds the training period")
    if scored_issue_count_per_segment < 1 or eligible_issue_count < 1:
        raise ValueError("training segment geometry has no scored forecast issues")

    sampling = optimization.get(
        "training_segment_sampling", SEEDED_UNIFORM_SINGLE_SEGMENT
    )
    segments_per_step = int(optimization.get("segments_per_optimizer_step", 1))
    base = {
        "sampling": sampling,
        "segments_per_optimizer_step": segments_per_step,
        "training_epochs": int(optimization["training_epochs"]),
        "steps_per_epoch": int(optimization["steps_per_epoch"]),
        "expected_optimizer_step_count": int(optimization["training_epochs"])
        * int(optimization["steps_per_epoch"]),
        "training_days": training_days,
        "segment_days": segment_days,
        "filter_warmup_days": warmup,
        "maximum_lead_days": maximum_lead,
        "maximum_segment_start_index": maximum_start,
        "eligible_issue_start_index_inclusive": warmup,
        "eligible_issue_end_index_exclusive": training_days - maximum_lead,
        "eligible_unique_issue_count": eligible_issue_count,
        "scored_issue_count_per_segment": scored_issue_count_per_segment,
    }
    if sampling == SEEDED_UNIFORM_SINGLE_SEGMENT:
        return {
            **base,
            "fixed_training_segment_start_indices": None,
            "complete_eligible_issue_coverage": False,
            "candidate_issue_count": None,
            "duplicate_issue_count": None,
            "uncovered_issue_count": None,
        }

    minimum_segment_count = math.ceil(
        eligible_issue_count / scored_issue_count_per_segment
    )
    if segments_per_step != minimum_segment_count:
        raise ValueError(
            "fixed full coverage must use the mathematical minimum segment count"
        )
    expected_starts = _round_half_up_evenly_spaced_starts(
        maximum_start,
        segments_per_step,
    )
    configured_starts = tuple(
        int(value) for value in optimization["fixed_training_segment_start_indices"]
    )
    if configured_starts != expected_starts:
        raise ValueError(
            "fixed training segment starts differ from round-half-up spacing"
        )
    multiplicity = [0] * eligible_issue_count
    eligible_start = warmup
    eligible_end = training_days - maximum_lead
    for start in configured_starts:
        issue_start = start + warmup
        issue_end = start + segment_days - maximum_lead
        if issue_start < eligible_start or issue_end > eligible_end:
            raise ValueError("a fixed training segment leaves the eligible period")
        for issue_index in range(issue_start, issue_end):
            multiplicity[issue_index - eligible_start] += 1
    uncovered = sum(value == 0 for value in multiplicity)
    candidate = math.fsum(multiplicity)
    if uncovered != 0:
        raise ValueError("fixed training segments do not cover every eligible issue")
    if int(candidate) != segments_per_step * scored_issue_count_per_segment:
        raise RuntimeError("fixed training coverage count does not reconstruct")
    duplicate = int(candidate) - eligible_issue_count
    return {
        **base,
        "fixed_training_segment_start_indices": list(configured_starts),
        "fixed_training_segment_start_indices_sha256": sha256(
            canonical_json_bytes(list(configured_starts))
        ).hexdigest(),
        "minimum_segment_count_for_complete_coverage": minimum_segment_count,
        "complete_eligible_issue_coverage": True,
        "candidate_issue_count": int(candidate),
        "unique_covered_issue_count": eligible_issue_count,
        "duplicate_issue_count": duplicate,
        "uncovered_issue_count": uncovered,
        "candidate_forecast_target_event_count_all_leads": (
            int(candidate) * len(ordered_leads)
        ),
        "total_candidate_forecast_target_event_count_all_epochs": (
            int(candidate)
            * len(ordered_leads)
            * int(optimization["training_epochs"])
        ),
        "maximum_issue_multiplicity": max(multiplicity),
        "issue_multiplicity_sha256": sha256(bytes(multiplicity)).hexdigest(),
    }


def _epoch_zero_reproducibility_evidence(
    configuration: Mapping[str, Any],
    *,
    objective: float,
    parameter_sha256: str,
    prediction_sha256: str,
) -> Mapping[str, Any]:
    """Fail closed when a diagnostic claims to differ only after epoch zero."""

    declared = configuration.get("epoch_zero_reproducibility")
    if declared is None:
        return {"required": False, "status": "NOT_DECLARED"}
    if not isinstance(declared, Mapping):
        raise TypeError("epoch_zero_reproducibility must be a JSON object")
    required_keys = {
        "checkpoint_objective_728",
        "parameter_sha256",
        "prediction_sha256",
    }
    if set(declared) != required_keys:
        raise ValueError("epoch-zero reproducibility keys are incomplete or unexpected")
    expected_objective = declared["checkpoint_objective_728"]
    if isinstance(expected_objective, bool) or not isinstance(
        expected_objective, (int, float)
    ):
        raise TypeError("epoch-zero objective anchor must be numeric")
    expected_objective = float(expected_objective)
    if not math.isfinite(expected_objective) or expected_objective < 0.0:
        raise ValueError("epoch-zero objective anchor must be finite and nonnegative")
    actual_hashes = {
        "parameter_sha256": str(parameter_sha256),
        "prediction_sha256": str(prediction_sha256),
    }
    expected_hashes: dict[str, str] = {}
    for key, actual in actual_hashes.items():
        expected = declared[key]
        if not isinstance(expected, str) or not re.fullmatch(r"[0-9a-f]{64}", expected):
            raise ValueError(f"epoch-zero {key} anchor must be lowercase SHA-256")
        expected_hashes[key] = expected

    objective_matches = math.isclose(
        float(objective),
        expected_objective,
        rel_tol=0.0,
        abs_tol=1.0e-12,
    )
    mismatched_fields = []
    if not objective_matches:
        mismatched_fields.append("objective")
    mismatched_fields.extend(
        key for key, actual in actual_hashes.items() if actual != expected_hashes[key]
    )
    if mismatched_fields:
        mismatch_evidence = {
            "absolute_objective_delta": abs(float(objective) - expected_objective),
            "actual_objective": float(objective),
            "actual_parameter_sha256": actual_hashes["parameter_sha256"],
            "actual_prediction_sha256": actual_hashes["prediction_sha256"],
            "expected_objective": expected_objective,
            "expected_parameter_sha256": expected_hashes["parameter_sha256"],
            "expected_prediction_sha256": expected_hashes["prediction_sha256"],
            "mismatched_fields": mismatched_fields,
            "objective_absolute_tolerance": 1.0e-12,
        }
        raise RuntimeError(
            "epoch-zero reproducibility mismatch: "
            + canonical_json_bytes(mismatch_evidence).decode("utf-8")
        )
    return {
        "required": True,
        "status": "PASS",
        "checkpoint_objective_728": float(objective),
        **actual_hashes,
    }


def standard_preflight(
    config_path: Path,
    run_parent: Path,
    *,
    phase: str,
    resume: Path | None = None,
) -> PreflightResult:
    """Verify every frozen byte and output invariant without numerical imports."""

    if "torch" in sys.modules:
        raise RuntimeError("PyTorch was imported before the standard-library preflight")
    if phase not in PHASES:
        raise ValueError(f"phase must be one of {PHASES}")
    root = Path(__file__).resolve().parents[1]
    configuration_path = _regular_file(Path(config_path).resolve(), "configuration")
    configuration = _read_json(configuration_path)
    configuration_hash = sha256_file(configuration_path)
    continuation = _continuation_spec(configuration, root, resume)
    if continuation is not None and phase == "replay":
        raise PermissionError(
            "checkpoint continuation supports read-only probe or train, not replay"
        )

    contract_path = _resolved_child(root, CONTRACT_RELATIVE, "parity contract")
    runner_path = _resolved_child(root, RUNNER_RELATIVE, "parity runner")
    io_path = _resolved_child(root, IO_RELATIVE, "atomic persistence module")
    integration_hashes = {
        CONTRACT_RELATIVE: _assert_hash(
            contract_path, EXPECTED_CONTRACT_SHA256, "parity contract"
        ),
        RUNNER_RELATIVE: _assert_hash(
            runner_path, EXPECTED_RUNNER_SHA256, "parity runner"
        ),
        IO_RELATIVE: _assert_hash(io_path, EXPECTED_IO_SHA256, "persistence module"),
    }

    contract_module = _load_standard_library_module(CONTRACT_MODULE_ALIAS, contract_path)
    contract = contract_module.ParityContract.from_dict(configuration)

    declared = configuration.get("source_sha256")
    if not isinstance(declared, Mapping) or not declared:
        raise ValueError("source_sha256 must be a non-empty mapping")
    declared_hashes: dict[str, str] = {}
    for untrusted_relative, untrusted_digest in declared.items():
        relative = _relative_path(untrusted_relative, "source_sha256 path")
        expected = _sha256(untrusted_digest, f"source_sha256[{relative}]")
        source_path = _resolved_child(root, relative, f"frozen source {relative}")
        declared_hashes[relative] = _assert_hash(source_path, expected, relative)

    data = configuration.get("data")
    if not isinstance(data, Mapping):
        raise TypeError("data must be a JSON object")
    input_specs = (
        ("development_archive", "archive_path", "archive_sha256"),
        ("tukf06_selection", "tukf06_selection_path", "tukf06_selection_sha256"),
        ("tukf06_contract", "tukf06_contract_path", "tukf06_contract_sha256"),
    )
    input_hashes: dict[str, str] = {}
    input_paths: dict[str, Path] = {}
    for name, path_key, hash_key in input_specs:
        relative = _relative_path(data.get(path_key), f"data.{path_key}")
        expected = _sha256(data.get(hash_key), f"data.{hash_key}")
        input_path = _resolved_child(root, relative, name)
        input_paths[name] = input_path
        input_hashes[relative] = _assert_hash(input_path, expected, name)

    archive_relative = _relative_path(data.get("archive_path"), "data.archive_path")
    if input_hashes[archive_relative] != contract.archive_sha256:
        raise RuntimeError("archive hash differs between ParityContract and data block")

    model = configuration.get("model")
    if not isinstance(model, Mapping):
        raise TypeError("model must be a JSON object")
    if (
        model.get("numeric_dtype") != "float64"
        or model.get("gain_network_numeric_dtype") != "float32"
    ):
        raise ValueError(
            "the daily parity route requires float64 physical dynamics and the "
            "archived float32 KalmanNet gain core"
        )
    gain_initialization = model.get("gain_initialization")
    if not isinstance(gain_initialization, str):
        raise TypeError("model.gain_initialization must be a string")
    if gain_initialization not in ALLOWED_GAIN_INITIALIZATIONS:
        raise ValueError(
            "model.gain_initialization must be native_default or near_zero_fc2_head"
        )
    correction_scope = _model_correction_scope(model)

    initialization = configuration.get("initialization")
    if not isinstance(initialization, Mapping):
        raise TypeError("initialization must be a JSON object")
    initialization_mode = str(initialization.get("execution_mode"))
    if initialization_mode not in contract.allowed_initialization_modes:
        raise ValueError("execution initialization mode is not allowlisted")
    scientific_claim_allowed = initialization_mode == contract.scientific_initialization_mode

    experiment_id = configuration.get("experiment_id")
    if not isinstance(experiment_id, str):
        raise TypeError("experiment_id must be a string")
    parent, run_directory = _experiment_directory(run_parent, experiment_id)
    if run_directory.exists() or run_directory.is_symlink():
        raise FileExistsError(f"final run directory already exists: {run_directory}")

    policy = configuration.get("execution_policy")
    if policy is not None:
        if not isinstance(policy, Mapping):
            raise TypeError("execution_policy must be a JSON object")
        permission_key = {
            "probe": "allow_probe",
            "replay": "allow_replay",
            "train": "allow_training",
        }[phase]
        if policy.get(permission_key) is not True:
            raise PermissionError(
                f"execution_policy.{permission_key} does not authorize this phase"
            )

    reference = configuration.get("reference")
    if not isinstance(reference, Mapping):
        raise TypeError("reference must be a JSON object")
    exact_archived_value = reference.get(
        "tukf06_complete_validation_objective_no_warmup",
        reference.get("exact_tukf06_complete_validation_objective_no_warmup"),
    )
    if (
        isinstance(exact_archived_value, bool)
        or not isinstance(exact_archived_value, (int, float))
        or not math.isfinite(float(exact_archived_value))
    ):
        raise ValueError("the exact TUKF06 728-origin reference is missing or non-finite")
    independent_exact = reference.get(
        "independent_replay_complete_validation_objective_no_warmup"
    )
    if independent_exact is not None and (
        isinstance(independent_exact, bool)
        or not isinstance(independent_exact, (int, float))
        or not math.isfinite(float(independent_exact))
        or abs(float(exact_archived_value) - float(independent_exact))
        > REFERENCE_ABSOLUTE_TOLERANCE
    ):
        raise ValueError("the two frozen exact TUKF06 reference objectives disagree")

    if phase == "train":
        optimization = configuration.get("optimization")
        if not isinstance(optimization, Mapping):
            raise TypeError("optimization must be a JSON object")
        _validate_training_hyperparameters(optimization)
        if not scientific_claim_allowed:
            raise PermissionError(
                "train is forbidden for backward-time diagnostic initialization; "
                "use replay only and create a causal configuration for training"
            )
        causal_reference = reference.get(CAUSAL_REFERENCE_KEY)
        if (
            isinstance(causal_reference, bool)
            or not isinstance(causal_reference, (int, float))
            or not math.isfinite(float(causal_reference))
            or float(causal_reference) <= 0.0
        ):
            raise PermissionError(
                "causal training requires an independently frozen 728-origin UKF "
                f"reference at reference.{CAUSAL_REFERENCE_KEY}"
            )
        _normalize_nse_reference(
            reference.get(CAUSAL_NSE_REFERENCE_KEY), contract.leads
        )

    identity_sources = {**declared_hashes, **integration_hashes}
    identity = {
        "schema_version": "daily_camels_ukf_knet_parity_run_identity_v1",
        "experiment_id": experiment_id,
        "configuration_sha256": configuration_hash,
        "source_sha256": identity_sources,
        "input_sha256": input_hashes,
        "initialization_mode": initialization_mode,
        "gain_initialization": gain_initialization,
        "correction_scope": correction_scope,
        "phase": phase,
    }
    if continuation is not None:
        identity["continuation"] = dict(_continuation_identity(continuation))
    identity_hash = sha256(canonical_json_bytes(identity)).hexdigest()
    return PreflightResult(
        repository_root=root,
        configuration_path=configuration_path,
        configuration=configuration,
        configuration_sha256=configuration_hash,
        contract=contract,
        declared_source_sha256=declared_hashes,
        integration_source_sha256=integration_hashes,
        input_sha256=input_hashes,
        input_paths=input_paths,
        experiment_id=experiment_id,
        initialization_mode=initialization_mode,
        gain_initialization=gain_initialization,
        correction_scope=correction_scope,
        scientific_claim_allowed=scientific_claim_allowed,
        phase=phase,
        run_parent=parent,
        run_directory=run_directory,
        identity=identity,
        identity_sha256=identity_hash,
        continuation=continuation,
    )


def _host_resource_snapshot(path: Path | None = None) -> Mapping[str, Any]:
    target = Path.cwd() if path is None else Path(path)
    disk = shutil.disk_usage(target if target.exists() else target.parent)
    result: dict[str, Any] = {
        "disk_free_bytes": int(disk.free),
        "disk_total_bytes": int(disk.total),
    }
    meminfo = Path("/proc/meminfo")
    if meminfo.is_file():
        values: dict[str, int] = {}
        for line in meminfo.read_text(encoding="utf-8").splitlines():
            parts = line.replace(":", "").split()
            if len(parts) >= 2 and parts[0] in {"MemTotal", "MemAvailable"}:
                values[parts[0]] = int(parts[1]) * 1024
        result.update(
            {
                "host_memory_total_bytes": values.get("MemTotal"),
                "host_memory_available_bytes": values.get("MemAvailable"),
            }
        )
    return result


def _nvidia_smi_probe() -> Mapping[str, Any]:
    executable = shutil.which("nvidia-smi")
    if executable is None:
        return {"available": False, "error": "nvidia-smi_not_found", "devices": []}
    completed = subprocess.run(
        [
            executable,
            "--query-gpu=index,name,memory.total,memory.free",
            "--format=csv,noheader,nounits",
        ],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=15,
        check=False,
    )
    devices: list[dict[str, Any]] = []
    if completed.returncode == 0:
        for line in completed.stdout.splitlines():
            fields = [field.strip() for field in line.split(",")]
            if len(fields) == 4:
                devices.append(
                    {
                        "index": int(fields[0]),
                        "name": fields[1],
                        "memory_total_mib": int(fields[2]),
                        "memory_free_mib": int(fields[3]),
                    }
                )
    return {
        "available": completed.returncode == 0 and bool(devices),
        "returncode": completed.returncode,
        "stderr": completed.stderr.strip(),
        "devices": devices,
    }


def preflight_report(preflight: PreflightResult, *, device: str) -> Mapping[str, Any]:
    gpu = _nvidia_smi_probe()
    if device == "cuda" and not gpu["available"]:
        raise RuntimeError("CUDA phase requested but the standard-library GPU probe failed")
    return {
        "schema_version": "daily_camels_ukf_knet_parity_preflight_v1",
        "status": "PREFLIGHT_PASS",
        "recorded_at_utc": _utc_now(),
        "host_name": socket.gethostname(),
        "process_id": os.getpid(),
        "python_version": sys.version,
        "phase": preflight.phase,
        "device_requested": device,
        "experiment_id": preflight.experiment_id,
        "identity_sha256": preflight.identity_sha256,
        "configuration_path": str(preflight.configuration_path),
        "configuration_sha256": preflight.configuration_sha256,
        "declared_source_sha256": dict(preflight.declared_source_sha256),
        "integration_source_sha256": dict(preflight.integration_source_sha256),
        "input_sha256": dict(preflight.input_sha256),
        "run_parent": str(preflight.run_parent),
        "run_directory": str(preflight.run_directory),
        "run_directory_absent": True,
        "initialization_mode": preflight.initialization_mode,
        "gain_initialization": preflight.gain_initialization,
        "correction_scope": preflight.correction_scope,
        "continuation": (
            None
            if preflight.continuation is None
            else dict(_continuation_identity(preflight.continuation))
        ),
        "scientific_claim_allowed": preflight.scientific_claim_allowed,
        "reserved_evaluation_period_access_authorized": False,
        "array_members_materialized": 0,
        "numerical_frameworks_imported_by_entry": 0,
        "host_resources": _host_resource_snapshot(preflight.run_parent),
        "graphics_driver_probe": gpu,
    }


def _load_io(preflight: PreflightResult) -> ModuleType:
    return _load_standard_library_module(
        IO_MODULE_ALIAS, preflight.repository_root / IO_RELATIVE
    )


def _load_numerical_runtime(preflight: PreflightResult) -> tuple[ModuleType, ModuleType, ModuleType]:
    for path in (preflight.repository_root, preflight.repository_root / "src"):
        text = str(path)
        if text not in sys.path:
            sys.path.insert(0, text)
    numpy_module = importlib.import_module("numpy")
    torch_module = importlib.import_module("torch")
    runner_module = importlib.import_module(
        "global_hydrology.experiments.daily_camels_ukf_knet_parity_runner"
    )
    return numpy_module, torch_module, runner_module


def _write_json(io_module: ModuleType, path: Path, value: object, *, replace: bool) -> str:
    return io_module.atomic_write_bytes(path, canonical_json_bytes(value), replace=replace)


def _write_npz(
    io_module: ModuleType,
    numpy_module: ModuleType,
    path: Path,
    arrays: Mapping[str, Any],
    *,
    replace: bool = False,
) -> str:
    return io_module.atomic_write_bytes(
        path,
        _npz_bytes(numpy_module, arrays),
        replace=replace,
    )


def _npz_bytes(
    numpy_module: ModuleType,
    arrays: Mapping[str, Any],
) -> bytes:
    buffer = io.BytesIO()
    numpy_module.savez_compressed(buffer, **dict(arrays))
    return buffer.getvalue()


def _append_event(
    io_module: ModuleType,
    path: Path,
    events: list[dict[str, Any]],
    value: Mapping[str, Any],
) -> str:
    row = dict(value)
    row["sequence"] = len(events)
    row["recorded_at_utc"] = _utc_now()
    events.append(row)
    content = b"".join(canonical_json_bytes(event) for event in events)
    return io_module.atomic_write_bytes(path, content, replace=path.exists())


def _ledger_dict(ledger: Any) -> Mapping[str, Any]:
    return {
        "archive_member_reads": dict(ledger.archive_member_reads),
        "date_requests": int(ledger.date_requests),
        "evaluation_array_reads": int(ledger.evaluation_array_reads),
        "evaluation_prediction_count": int(ledger.evaluation_prediction_count),
        "evaluation_metric_count": int(ledger.evaluation_metric_count),
        "evaluation_output_count": int(ledger.evaluation_output_count),
    }


def _assert_zero_reserved_access(ledger: Any) -> None:
    counters = (
        ledger.evaluation_array_reads,
        ledger.evaluation_prediction_count,
        ledger.evaluation_metric_count,
        ledger.evaluation_output_count,
    )
    if any(int(value) != 0 for value in counters):
        raise PermissionError("reserved evaluation access ledger is nonzero")


def _score_pairs(runner: ModuleType, score: Any) -> Any:
    return runner.ForecastPairs(
        predictions=score.predictions,
        targets=score.targets,
        issue_indices=score.issue_indices,
        target_indices=score.target_indices,
        finite_masks=score.finite_masks,
    )


def _compare_score_to_strict_zero_gain(
    candidate: Any,
    strict_zero_gain: Any,
    leads: Sequence[int],
) -> Mapping[str, Any]:
    """Report whether a checkpoint improves on the exact shared open loop."""

    if candidate.full_objective_without_warmup is None:
        raise ValueError("candidate checkpoint objective is absent")
    if strict_zero_gain.full_objective_without_warmup is None:
        raise ValueError("strict zero-gain checkpoint objective is absent")
    rows: dict[int, Mapping[str, Any]] = {}
    for lead in leads:
        zero_mse = float(strict_zero_gain.mse_by_lead[lead])
        candidate_mse = float(candidate.mse_by_lead[lead])
        zero_nse = float(strict_zero_gain.nse_by_lead[lead])
        candidate_nse = float(candidate.nse_by_lead[lead])
        values = (zero_mse, candidate_mse, zero_nse, candidate_nse)
        if not all(math.isfinite(value) for value in values):
            raise FloatingPointError(
                f"lead-{lead} strict-zero comparison contains a non-finite value"
            )
        mse_improvement = zero_mse - candidate_mse
        nse_delta = candidate_nse - zero_nse
        rows[int(lead)] = {
            "strict_zero_gain_mse": zero_mse,
            "candidate_mse": candidate_mse,
            "mse_improvement_zero_minus_candidate": mse_improvement,
            "strict_zero_gain_nse": zero_nse,
            "candidate_nse": candidate_nse,
            "nse_delta_candidate_minus_zero": nse_delta,
            "candidate_better": mse_improvement > 0.0 and nse_delta > 0.0,
        }
    return {
        "strict_zero_gain_checkpoint_objective_728": float(
            strict_zero_gain.full_objective_without_warmup
        ),
        "candidate_checkpoint_objective_728": float(
            candidate.full_objective_without_warmup
        ),
        "checkpoint_objective_improvement_zero_minus_candidate": float(
            strict_zero_gain.full_objective_without_warmup
            - candidate.full_objective_without_warmup
        ),
        "by_lead_712": rows,
        "candidate_better_than_strict_zero_gain_each_lead": all(
            bool(row["candidate_better"]) for row in rows.values()
        ),
    }


def _array_digest(numpy_module: ModuleType, values: Any) -> str:
    array = numpy_module.ascontiguousarray(numpy_module.asarray(values))
    digest = sha256()
    digest.update(str(array.dtype).encode("ascii"))
    digest.update(numpy_module.asarray(array.shape, dtype=numpy_module.int64).tobytes())
    digest.update(array.tobytes())
    return digest.hexdigest()


def _score_evidence(
    numpy_module: ModuleType,
    score: Any,
    *,
    global_start: int,
) -> Mapping[str, Any]:
    geometry: dict[str, Any] = {}
    for lead in sorted(score.target_indices):
        issue = numpy_module.asarray(score.issue_indices[lead], dtype=numpy_module.int64)
        target = numpy_module.asarray(score.target_indices[lead], dtype=numpy_module.int64)
        finite = numpy_module.asarray(score.finite_masks[lead], dtype=bool)
        geometry[str(lead)] = {
            "issue_indices_local": issue.tolist(),
            "issue_indices_global": (issue + int(global_start)).tolist(),
            "target_indices_local": target.tolist(),
            "target_indices_global": (target + int(global_start)).tolist(),
            "finite_mask_sha256": _array_digest(numpy_module, finite),
            "finite_target_count": int(finite.sum()),
        }
    return {
        "gate_objective_after_16_day_warmup": float(score.objective),
        "checkpoint_objective_without_warmup": float(
            score.full_objective_without_warmup
        ),
        "mse_by_lead_after_warmup": dict(score.mse_by_lead),
        "nse_by_lead_after_warmup": dict(score.nse_by_lead),
        "target_count_by_lead_after_warmup": dict(score.target_count_by_lead),
        "target_count_by_lead_without_warmup": dict(
            score.full_target_count_by_lead_without_warmup
        ),
        "geometry": geometry,
        "maximum_open_loop_difference": score.maximum_open_loop_difference,
        "metadata": dict(score.metadata or {}),
    }


def _replay_predictions(numpy_module: ModuleType, results: Mapping[str, Any]) -> Mapping[str, Any]:
    arrays: dict[str, Any] = {}
    for purpose, methods in results.items():
        for method, score in methods.items():
            for lead, values in score.predictions.items():
                arrays[f"{purpose}__{method}__lead_{lead}__prediction"] = values
            for lead, values in score.targets.items():
                arrays[f"{purpose}__{method}__lead_{lead}__target"] = values
            for lead, values in score.target_indices.items():
                arrays[f"{purpose}__{method}__lead_{lead}__target_index"] = values
    return arrays


def _expected_ukf_reference(preflight: PreflightResult) -> float | None:
    reference = preflight.configuration["reference"]
    if preflight.scientific_claim_allowed:
        value = reference.get(CAUSAL_REFERENCE_KEY)
        return None if value is None else float(value)
    value = reference.get(
        "independent_replay_complete_validation_objective_no_warmup",
        reference.get(
            "tukf06_complete_validation_objective_no_warmup",
            reference.get("exact_tukf06_complete_validation_objective_no_warmup"),
        ),
    )
    return float(value)


def execute_replay(
    preflight: PreflightResult,
    numpy_module: ModuleType,
    torch_module: ModuleType,
    runner: ModuleType,
    ledger: Any,
    *,
    device: str,
) -> tuple[Any, Mapping[str, Any], Mapping[str, Any]]:
    """Replay both fixed windows before any optimization is admitted."""

    model = preflight.configuration["model"]
    optimization = preflight.configuration["optimization"]
    runtime = runner.load_archive_context(
        preflight.input_paths["development_archive"],
        preflight.contract,
        ledger,
        initialization_mode=preflight.initialization_mode,
        device=device,
    )
    results: dict[str, dict[str, Any]] = {}
    evidence: dict[str, Any] = {
        "schema_version": "daily_camels_ukf_knet_parity_replay_v1",
        "experiment_id": preflight.experiment_id,
        "identity_sha256": preflight.identity_sha256,
        "initialization": asdict(runtime.initialization_evidence),
        "scientific_claim_allowed": runtime.initialization_evidence.scientific_claim_allowed,
        "diagnostic_limitation": preflight.configuration["initialization"][
            "diagnostic_limitation"
        ],
        "covariance_roles": {
            "ukf_initial_covariance_diagonal": runtime.context.initial_covariance[
                0
            ].diagonal().detach().cpu().tolist(),
            "knet_hidden_prior_state_covariance_diagonal": runtime.context.plain_model.prior_state_cov.diagonal().detach().cpu().tolist(),
            "covariances_are_identical": False,
            "interpretation": (
                "UKF initial state uncertainty and KalmanNet recurrent hidden-state "
                "prior are model-specific quantities; parity does not require equality"
            ),
        },
        "windows": {},
    }
    for purpose in ("diagnostic", "recovery"):
        window = runner.select_window(runtime, purpose)
        ukf = runner.replay_tukf06_ukf(
            runtime,
            window,
            selection_path=preflight.input_paths["tukf06_selection"],
        )
        zero = runner.replay_zero_gain_open_loop(
            runtime,
            window,
            seed=int(optimization["seed"]),
            hidden=int(model["hidden_dimension"]),
            in_mult=int(model["input_multiplier"]),
            out_mult=int(model["output_multiplier"]),
            feature_scale_floor=float(model["feature_scale_floor"]),
            normalized_feature_guard=float(model["normalized_feature_guard"]),
        )
        runner.assert_identical_forecast_geometry(
            _score_pairs(runner, ukf), _score_pairs(runner, zero)
        )
        if zero.maximum_open_loop_difference != 0.0:
            raise RuntimeError("zero-gain KalmanNet is not the exact shared open loop")
        expected_after = (
            preflight.contract.expected_diagnostic_target_count_per_lead
            if purpose == "diagnostic"
            else preflight.contract.expected_recovery_target_count_per_lead
        )
        if dict(ukf.target_count_by_lead) != {
            lead: expected_after for lead in preflight.contract.leads
        }:
            raise RuntimeError(f"{purpose} UKF target count changed")
        if dict(zero.target_count_by_lead) != dict(ukf.target_count_by_lead):
            raise RuntimeError(f"{purpose} zero-gain target count differs from UKF")
        if purpose == "recovery":
            expected_full = len(window.observations) - max(preflight.contract.leads)
            required = {lead: expected_full for lead in preflight.contract.leads}
            if dict(ukf.full_target_count_by_lead_without_warmup) != required:
                raise RuntimeError("recovery UKF does not use 728 no-warmup origins")
            if dict(zero.full_target_count_by_lead_without_warmup) != required:
                raise RuntimeError("zero-gain replay does not use 728 no-warmup origins")
            expected_reference = _expected_ukf_reference(preflight)
            actual_reference = float(ukf.full_objective_without_warmup)
            if expected_reference is not None and abs(
                actual_reference - expected_reference
            ) > REFERENCE_ABSOLUTE_TOLERANCE:
                raise RuntimeError(
                    "complete-window UKF 728-origin physical objective differs from "
                    f"the frozen reference: expected {expected_reference}, got {actual_reference}"
                )
            expected_nse = None
            if preflight.scientific_claim_allowed:
                raw_nse = preflight.configuration["reference"].get(
                    CAUSAL_NSE_REFERENCE_KEY
                )
                if raw_nse is not None:
                    expected_nse = _normalize_nse_reference(
                        raw_nse, preflight.contract.leads
                    )
                    for lead in preflight.contract.leads:
                        actual_nse = float(ukf.nse_by_lead[lead])
                        if abs(actual_nse - expected_nse[lead]) > REFERENCE_ABSOLUTE_TOLERANCE:
                            raise RuntimeError(
                                f"causal UKF lead-{lead} NSE differs from the frozen reference"
                            )
            evidence["recovery_reference"] = {
                "reference_was_frozen_before_replay": expected_reference is not None,
                "expected_checkpoint_objective_728": expected_reference,
                "actual_checkpoint_objective_728": actual_reference,
                "objective_match": (
                    None
                    if expected_reference is None
                    else abs(actual_reference - expected_reference)
                    <= REFERENCE_ABSOLUTE_TOLERANCE
                ),
                "expected_nse_by_lead_712": expected_nse,
                "actual_nse_by_lead_712": dict(ukf.nse_by_lead),
                "candidate_for_new_frozen_causal_config": expected_reference is None,
            }
        results[purpose] = {"ukf": ukf, "zero_gain_knet": zero}
        evidence["windows"][purpose] = {
            "global_start_index": int(window.global_start),
            "global_end_exclusive": int(window.global_end_exclusive),
            "first_date": str(window.dates[0].astype("datetime64[D]")),
            "last_date": str(window.dates[-1].astype("datetime64[D]")),
            "ukf": _score_evidence(
                numpy_module, ukf, global_start=window.global_start
            ),
            "zero_gain_knet": _score_evidence(
                numpy_module, zero, global_start=window.global_start
            ),
            "identical_ukf_knet_geometry": True,
        }
    _assert_zero_reserved_access(ledger)
    evidence["access_ledger"] = _ledger_dict(ledger)
    return runtime, results, evidence


def _quantiles(numpy_module: ModuleType, values: Any) -> Mapping[str, float]:
    array = numpy_module.asarray(values, dtype=numpy_module.float64).reshape(-1)
    array = array[numpy_module.isfinite(array)]
    if array.size == 0:
        raise ValueError("feature diagnostic has no finite values")
    probabilities = (0.0, 0.01, 0.05, 0.5, 0.95, 0.99, 1.0)
    calculated = numpy_module.quantile(array, probabilities)
    return {f"q{int(probability * 100):02d}": float(value) for probability, value in zip(probabilities, calculated)}


def training_scale_diagnostics(
    runtime: Any,
    runner: ModuleType,
    numpy_module: ModuleType,
    *,
    floor: float,
    guard: float,
) -> Mapping[str, Any]:
    states = runner.training_open_loop_states(runtime)[:, 0, :].detach().cpu().numpy()
    observations = runtime.observations[: runtime.training_days, 0].detach().cpu().numpy()
    observation_difference = numpy_module.diff(observations)
    state_difference = numpy_module.diff(states, axis=0)
    finite_observation = numpy_module.isfinite(observation_difference)
    observation_rms_raw = float(
        numpy_module.sqrt(numpy_module.mean(observation_difference[finite_observation] ** 2))
    )
    valid_state = numpy_module.isfinite(state_difference)
    state_counts = valid_state.sum(axis=0)
    if bool((state_counts == 0).any()):
        raise ValueError("a state feature has no finite training differences")
    state_rms_raw = numpy_module.sqrt(
        numpy_module.where(valid_state, state_difference ** 2, 0.0).sum(axis=0)
        / state_counts
    )
    observation_scale = max(observation_rms_raw, float(floor))
    state_scale = numpy_module.maximum(state_rms_raw, float(floor))
    normalized_observation = observation_difference[finite_observation] / observation_scale
    normalized_state = state_difference / state_scale.reshape(1, -1)
    return {
        "fit_start_index": 0,
        "fit_end_exclusive": int(runtime.training_days),
        "fit_last_date": str(runtime.dates[runtime.training_days - 1].astype("datetime64[D]")),
        "validation_or_evaluation_values_used": 0,
        "floor": float(floor),
        "guard": float(guard),
        "observation_scale": float(observation_scale),
        "state_scales": state_scale.tolist(),
        "observation_raw_rms_before_floor": observation_rms_raw,
        "state_raw_rms_before_floor": state_rms_raw.tolist(),
        "observation_scale_hit_floor": observation_rms_raw < float(floor),
        "state_scale_floor_hit_count": int((state_rms_raw < float(floor)).sum()),
        "raw_observation_difference_quantiles": _quantiles(
            numpy_module, observation_difference
        ),
        "raw_state_difference_quantiles": _quantiles(numpy_module, state_difference),
        "normalized_observation_difference_quantiles": _quantiles(
            numpy_module, normalized_observation
        ),
        "normalized_state_difference_quantiles": _quantiles(
            numpy_module, normalized_state
        ),
        "observation_guard_saturation_fraction": float(
            numpy_module.mean(numpy_module.abs(normalized_observation) > float(guard))
        ),
        "state_guard_saturation_fraction": float(
            numpy_module.mean(numpy_module.abs(normalized_state) > float(guard))
        ),
        "state_guard_saturation_fraction_by_coordinate": numpy_module.mean(
            numpy_module.abs(normalized_state) > float(guard), axis=0
        ).tolist(),
    }


def _dynamic_feature_diagnostics(
    net: Any,
    runtime: Any,
    window: Any,
    runner: ModuleType,
    numpy_module: ModuleType,
    torch_module: ModuleType,
    *,
    guard: float,
) -> Mapping[str, Any]:
    net.eval()
    previous_observation = runner.previous_observation_before_window(runtime, window)
    with torch_module.no_grad():
        trace = runner.run_knet_filter(
            net,
            window,
            previous_observation=previous_observation,
        )
        initial = window.initial_state.detach()
        priors = trace.prior_states.detach()
        posteriors = trace.posterior_states.detach()
        observations = window.observations.detach()
        if previous_observation is None:
            previous_observation = window.context.plain_model.h(initial).reshape(1, 1)
        feature_lists: dict[str, list[Any]] = {
            "observation_difference": [],
            "observation_innovation": [],
            "forward_evolution": [],
            "forward_update": [],
        }
        for day in range(len(observations)):
            current_posterior = initial if day == 0 else posteriors[day - 1]
            previous_posterior = initial if day <= 1 else posteriors[day - 2]
            previous_prior = initial if day == 0 else priors[day - 1]
            observation = observations[day, 0].reshape(1, 1)
            valid = bool(torch_module.isfinite(observation).all())
            if valid:
                feature_lists["observation_difference"].append(
                    (observation - previous_observation) / net.observation_feature_scale
                )
                predicted_observation = window.context.plain_model.h(priors[day])
                feature_lists["observation_innovation"].append(
                    (observation - predicted_observation) / net.observation_feature_scale
                )
                feature_lists["forward_evolution"].append(
                    (current_posterior - previous_posterior) / net.state_feature_scale
                )
                feature_lists["forward_update"].append(
                    (current_posterior - previous_prior) / net.state_feature_scale
                )
                previous_observation = observation
            else:
                previous_observation = window.context.plain_model.h(priors[day]).reshape(1, 1)
    evidence: dict[str, Any] = {
        "window": window.purpose,
        "valid_update_count": int(trace.valid_updates.sum().detach().cpu()),
        "guard": float(guard),
    }
    for name, tensors in feature_lists.items():
        if not tensors:
            raise ValueError(f"no dynamic {name} features were observed")
        array = torch_module.cat(tensors, dim=0).detach().cpu().numpy()
        evidence[name] = {
            "normalized_quantiles": _quantiles(numpy_module, array),
            "guard_saturation_fraction": float(
                numpy_module.mean(numpy_module.abs(array) > float(guard))
            ),
            "maximum_absolute_value_before_guard": float(
                numpy_module.max(numpy_module.abs(array))
            ),
            "value_count": int(array.size),
        }
    return evidence


def _resource_peaks(torch_module: ModuleType, *, device: str) -> Mapping[str, Any]:
    result: dict[str, Any] = {}
    status = Path("/proc/self/status")
    if status.is_file():
        values: dict[str, int] = {}
        for line in status.read_text(encoding="utf-8").splitlines():
            fields = line.replace(":", "").split()
            if len(fields) >= 2 and fields[0] in {"VmRSS", "VmHWM"}:
                values[fields[0]] = int(fields[1]) * 1024
        result["host_current_rss_bytes"] = values.get("VmRSS")
        result["host_peak_rss_bytes"] = values.get("VmHWM")
        result["host_peak_measurement"] = "linux_proc_self_status_VmHWM"
    else:
        try:
            import resource  # standard library, unavailable on Windows

            peak = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
            result["host_peak_rss_platform_units"] = peak
            result["host_peak_measurement"] = "resource_ru_maxrss_platform_units"
        except ImportError:
            result["host_peak_measurement"] = "unavailable_on_platform"
    if device == "cuda":
        result.update(
            {
                "graphics_peak_allocated_bytes": int(
                    torch_module.cuda.max_memory_allocated()
                ),
                "graphics_peak_reserved_bytes": int(
                    torch_module.cuda.max_memory_reserved()
                ),
                "graphics_peak_measurement": "pytorch_process_allocator",
            }
        )
        free_bytes, total_bytes = torch_module.cuda.mem_get_info()
        result["graphics_free_bytes_at_snapshot"] = int(free_bytes)
        result["graphics_total_bytes"] = int(total_bytes)
    else:
        result["graphics_peak_allocated_bytes"] = 0
        result["graphics_peak_reserved_bytes"] = 0
        result["graphics_peak_measurement"] = "not_applicable_cpu_execution"
    return result


def _cpu_clone(value: Any, torch_module: ModuleType) -> Any:
    if torch_module.is_tensor(value):
        return value.detach().cpu().clone()
    if isinstance(value, Mapping):
        return {key: _cpu_clone(member, torch_module) for key, member in value.items()}
    if isinstance(value, tuple):
        return tuple(_cpu_clone(member, torch_module) for member in value)
    if isinstance(value, list):
        return [_cpu_clone(member, torch_module) for member in value]
    return copy.deepcopy(value)


def _checkpoint_bytes(torch_module: ModuleType, payload: Mapping[str, Any]) -> bytes:
    buffer = io.BytesIO()
    torch_module.save(dict(payload), buffer)
    return buffer.getvalue()


def _prediction_arrays(score: Any, numpy_module: ModuleType) -> Mapping[str, Any]:
    arrays: dict[str, Any] = {}
    for lead in sorted(score.predictions):
        arrays[f"lead_{lead}_prediction"] = numpy_module.asarray(score.predictions[lead])
        arrays[f"lead_{lead}_target"] = numpy_module.asarray(score.targets[lead])
        arrays[f"lead_{lead}_issue_index"] = numpy_module.asarray(score.issue_indices[lead])
        arrays[f"lead_{lead}_target_index"] = numpy_module.asarray(score.target_indices[lead])
        arrays[f"lead_{lead}_finite_mask"] = numpy_module.asarray(score.finite_masks[lead])
    return arrays


def _summarize_epoch_training_diagnostics(
    mse_values_by_lead: Mapping[int, Sequence[float]],
    finite_target_count_by_lead: Mapping[int, int],
    *,
    gradient_clipped_optimizer_step_count: int,
    optimizer_step_count: int,
    same_segment_step_replays: Sequence[Mapping[str, Any]] = (),
) -> Mapping[str, Any]:
    """Summarize one epoch without changing the equal-lead training weights."""

    expected_leads = (1, 2, 3)
    if set(mse_values_by_lead) != set(expected_leads) or set(
        finite_target_count_by_lead
    ) != set(expected_leads):
        raise ValueError("epoch training diagnostics require leads 1, 2, and 3")
    if isinstance(optimizer_step_count, bool) or not isinstance(optimizer_step_count, int):
        raise TypeError("optimizer step count must be an integer")
    if optimizer_step_count < 0:
        raise ValueError("optimizer step count cannot be negative")
    clipped = gradient_clipped_optimizer_step_count
    if isinstance(clipped, bool) or not isinstance(clipped, int):
        raise TypeError("gradient-clipped optimizer step count must be an integer")
    if not 0 <= clipped <= optimizer_step_count:
        raise ValueError("gradient-clipped optimizer step count is outside the epoch")
    replays = tuple(copy.deepcopy(dict(value)) for value in same_segment_step_replays)
    if len(replays) != optimizer_step_count:
        raise ValueError("same-segment replay count differs from optimizer steps")

    means: dict[int, float] = {}
    counts: dict[int, int] = {}
    for lead in expected_leads:
        values = tuple(mse_values_by_lead[lead])
        if len(values) != optimizer_step_count:
            raise ValueError(f"lead-{lead} MSE count differs from optimizer steps")
        normalized: list[float] = []
        for value in values:
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise TypeError(f"lead-{lead} MSE must be numeric")
            numeric = float(value)
            if not math.isfinite(numeric) or numeric < 0.0:
                raise ValueError(f"lead-{lead} MSE must be finite and nonnegative")
            normalized.append(numeric)

        count = finite_target_count_by_lead[lead]
        if isinstance(count, bool) or not isinstance(count, int):
            raise TypeError(f"lead-{lead} finite target count must be an integer")
        if count < 0 or (optimizer_step_count == 0 and count != 0):
            raise ValueError(f"lead-{lead} finite target count is invalid")
        if optimizer_step_count > 0 and count < optimizer_step_count:
            raise ValueError(f"lead-{lead} finite target count is below one per step")
        counts[lead] = count
        if normalized:
            means[lead] = math.fsum(normalized) / len(normalized)

    before_objectives: list[float] = []
    after_objectives: list[float] = []
    strict_improvements = 0
    for replay in replays:
        before = float(replay["before_step_objective_physical_unit_multilead_mse"])
        after = float(replay["after_step_objective_physical_unit_multilead_mse"])
        improvement = float(replay["objective_improvement_before_minus_after"])
        if not all(math.isfinite(value) and value >= 0.0 for value in (before, after)):
            raise ValueError("same-segment replay objectives must be finite and nonnegative")
        if not math.isclose(improvement, before - after, rel_tol=0.0, abs_tol=1.0e-15):
            raise ValueError("same-segment replay improvement does not reconstruct")
        if replay.get("identical_target_geometry_before_after") is not True:
            raise ValueError("same-segment replay target geometry changed")
        declared_strict = replay.get("strict_objective_decrease")
        if not isinstance(declared_strict, bool) or declared_strict != (after < before):
            raise ValueError("same-segment replay strict-decrease flag is inconsistent")
        before_objectives.append(before)
        after_objectives.append(after)
        strict_improvements += int(declared_strict)

    return {
        "training_mse_by_lead_physical_unit_mean_over_optimizer_steps": (
            means if optimizer_step_count > 0 else None
        ),
        "training_sampled_finite_target_event_count_by_lead": counts,
        "epoch_optimizer_step_count": optimizer_step_count,
        "gradient_clipped_optimizer_step_count": clipped,
        "gradient_clipped_optimizer_step_fraction": (
            clipped / optimizer_step_count if optimizer_step_count > 0 else None
        ),
        "same_segment_post_step_replay_count": len(replays),
        "same_segment_strict_objective_decrease_count": strict_improvements,
        "same_segment_every_optimizer_step_strictly_decreased": (
            strict_improvements == optimizer_step_count
            if optimizer_step_count > 0
            else None
        ),
        "same_segment_before_step_objective_mean": (
            math.fsum(before_objectives) / len(before_objectives)
            if before_objectives
            else None
        ),
        "same_segment_after_step_objective_mean": (
            math.fsum(after_objectives) / len(after_objectives)
            if after_objectives
            else None
        ),
        "same_segment_objective_improvement_mean_before_minus_after": (
            math.fsum(
                before - after
                for before, after in zip(before_objectives, after_objectives)
            )
            / len(before_objectives)
            if before_objectives
            else None
        ),
        "same_segment_step_replays": list(replays),
    }


def _detached_scalar(value: Any, label: str) -> float:
    """Convert one scalar tensor-like value into finite nonnegative evidence."""

    converted = value
    if hasattr(converted, "detach"):
        converted = converted.detach()
    if hasattr(converted, "cpu"):
        converted = converted.cpu()
    if hasattr(converted, "item"):
        converted = converted.item()
    if isinstance(converted, bool) or not isinstance(converted, (int, float)):
        raise TypeError(f"{label} must be a numeric scalar")
    result = float(converted)
    if not math.isfinite(result) or result < 0.0:
        raise ValueError(f"{label} must be finite and nonnegative")
    return result


def _detached_segment_loss(segment: Any, leads: Sequence[int]) -> Any:
    """Keep scalar evidence while allowing each segment graph to be released."""

    ordered_leads = tuple(int(value) for value in leads)
    if set(segment.mse_by_lead) != set(ordered_leads) or set(
        segment.target_count_by_lead
    ) != set(ordered_leads):
        raise RuntimeError("training segment lead inventory differs")
    return SimpleNamespace(
        objective=_detached_scalar(segment.objective, "training segment objective"),
        mse_by_lead={
            lead: _detached_scalar(
                segment.mse_by_lead[lead], f"training segment lead-{lead} MSE"
            )
            for lead in ordered_leads
        },
        target_count_by_lead={
            lead: int(segment.target_count_by_lead[lead]) for lead in ordered_leads
        },
    )


def _same_training_batch_step_replay_evidence(
    segment_replays: Sequence[Mapping[str, Any]],
    *,
    optimizer_step: int,
) -> Mapping[str, Any]:
    """Aggregate a multi-segment gradient update as exactly one optimizer step."""

    replays = tuple(copy.deepcopy(dict(value)) for value in segment_replays)
    if len(replays) < 2:
        raise ValueError("multi-segment batch evidence requires at least two segments")
    starts = tuple(
        int(value["segment_start_index_global_inclusive"]) for value in replays
    )
    if starts != tuple(sorted(set(starts))):
        raise ValueError("training batch segment starts must be unique and increasing")
    if any(int(value["optimizer_step"]) != int(optimizer_step) for value in replays):
        raise ValueError("training batch constituent optimizer steps differ")
    if any(
        value.get("identical_target_geometry_before_after") is not True
        or value.get("after_step_was_recomputed") is not True
        or value.get("after_step_recomputed_under_no_grad") is not True
        or int(value.get("reserved_evaluation_values_used", -1)) != 0
        for value in replays
    ):
        raise ValueError("training batch constituent replay evidence is incomplete")

    lead_inventory = tuple(
        sorted(int(key) for key in replays[0]["mse_by_lead_before_step"])
    )
    if not lead_inventory:
        raise ValueError("training batch has no forecast leads")
    for value in replays:
        if tuple(sorted(int(key) for key in value["mse_by_lead_before_step"])) != lead_inventory:
            raise ValueError("training batch before-step lead inventories differ")
        if tuple(sorted(int(key) for key in value["mse_by_lead_after_step"])) != lead_inventory:
            raise ValueError("training batch after-step lead inventories differ")

    before_by_lead = {
        lead: math.fsum(float(value["mse_by_lead_before_step"][lead]) for value in replays)
        / len(replays)
        for lead in lead_inventory
    }
    after_by_lead = {
        lead: math.fsum(float(value["mse_by_lead_after_step"][lead]) for value in replays)
        / len(replays)
        for lead in lead_inventory
    }
    before_objective = math.fsum(
        float(value["before_step_objective_physical_unit_multilead_mse"])
        for value in replays
    ) / len(replays)
    after_objective = math.fsum(
        float(value["after_step_objective_physical_unit_multilead_mse"])
        for value in replays
    ) / len(replays)
    for label, objective, by_lead in (
        ("before", before_objective, before_by_lead),
        ("after", after_objective, after_by_lead),
    ):
        reconstructed = math.fsum(by_lead.values()) / len(lead_inventory)
        if not math.isclose(objective, reconstructed, rel_tol=1.0e-6, abs_tol=1.0e-8):
            raise RuntimeError(
                f"training batch {label}-step objective does not reconstruct"
            )
    before_counts = {
        lead: sum(int(value["target_count_by_lead_before_step"][lead]) for value in replays)
        for lead in lead_inventory
    }
    after_counts = {
        lead: sum(int(value["target_count_by_lead_after_step"][lead]) for value in replays)
        for lead in lead_inventory
    }
    if after_counts != before_counts:
        raise RuntimeError("training batch finite target counts changed after the step")
    improvement = before_objective - after_objective
    strict_segment_count = sum(bool(value["strict_objective_decrease"]) for value in replays)
    geometry = [value["target_geometry_by_lead"] for value in replays]
    return {
        "optimizer_step": int(optimizer_step),
        "training_segment_count": len(replays),
        "training_segment_start_indices": list(starts),
        "training_segment_start_indices_sha256": sha256(
            canonical_json_bytes(list(starts))
        ).hexdigest(),
        "before_step_objective_physical_unit_multilead_mse": before_objective,
        "after_step_objective_physical_unit_multilead_mse": after_objective,
        "objective_improvement_before_minus_after": improvement,
        "relative_objective_improvement": (
            improvement / before_objective if before_objective > 0.0 else None
        ),
        "strict_objective_decrease": after_objective < before_objective,
        "mse_by_lead_before_step": before_by_lead,
        "mse_by_lead_after_step": after_by_lead,
        "mse_improvement_by_lead_before_minus_after": {
            lead: before_by_lead[lead] - after_by_lead[lead]
            for lead in lead_inventory
        },
        "target_count_by_lead_before_step": before_counts,
        "target_count_by_lead_after_step": after_counts,
        "training_segment_strict_objective_decrease_count": strict_segment_count,
        "training_segment_strict_objective_decrease_fraction": (
            strict_segment_count / len(replays)
        ),
        "every_training_segment_strictly_decreased": strict_segment_count == len(replays),
        "target_geometry_by_training_segment": geometry,
        "target_geometry_by_training_segment_sha256": sha256(
            canonical_json_bytes(geometry)
        ).hexdigest(),
        "identical_target_geometry_before_after": True,
        "after_step_was_recomputed": True,
        "after_step_recomputed_under_no_grad": True,
        "reserved_evaluation_values_used": 0,
        "training_segment_replays": list(replays),
    }


def _same_segment_step_replay_evidence(
    *,
    before_step: Any,
    after_step: Any,
    runtime: Any,
    start: int,
    segment_days: int,
    filter_warmup_days: int,
    leads: Sequence[int],
    optimizer_step: int,
    torch_module: ModuleType,
) -> Mapping[str, Any]:
    """Prove what one optimizer update did to the exact same forecast targets."""

    ordered_leads = tuple(int(value) for value in leads)
    if ordered_leads != tuple(sorted(set(ordered_leads))) or not ordered_leads:
        raise ValueError("same-segment replay leads must be unique increasing integers")
    start = int(start)
    segment_days = int(segment_days)
    warmup = int(filter_warmup_days)
    issue_start = start + warmup
    issue_end_exclusive = start + segment_days - max(ordered_leads)
    if not 0 <= start < issue_start < issue_end_exclusive <= int(runtime.training_days):
        raise ValueError("same-segment replay geometry leaves the training period")

    before_counts = {int(key): int(value) for key, value in before_step.target_count_by_lead.items()}
    after_counts = {int(key): int(value) for key, value in after_step.target_count_by_lead.items()}
    if set(before_counts) != set(ordered_leads) or after_counts != before_counts:
        raise RuntimeError("same-segment replay finite target counts changed")

    before_by_lead = {
        lead: _detached_scalar(before_step.mse_by_lead[lead], f"before lead-{lead} MSE")
        for lead in ordered_leads
    }
    after_by_lead = {
        lead: _detached_scalar(after_step.mse_by_lead[lead], f"after lead-{lead} MSE")
        for lead in ordered_leads
    }
    before_objective = _detached_scalar(before_step.objective, "before-step objective")
    after_objective = _detached_scalar(after_step.objective, "after-step objective")
    for label, objective, by_lead in (
        ("before", before_objective, before_by_lead),
        ("after", after_objective, after_by_lead),
    ):
        reconstructed = math.fsum(by_lead.values()) / len(ordered_leads)
        if not math.isclose(objective, reconstructed, rel_tol=1.0e-6, abs_tol=1.0e-8):
            raise RuntimeError(f"{label}-step objective does not reconstruct by equal leads")

    geometry: dict[int, Mapping[str, Any]] = {}
    for lead in ordered_leads:
        indices = list(range(issue_start + lead, issue_end_exclusive + lead))
        target = runtime.observations[indices, 0]
        finite_values = torch_module.isfinite(target).detach().cpu().tolist()
        finite_mask = bytes(1 if bool(value) else 0 for value in finite_values)
        if sum(finite_mask) != before_counts[lead]:
            raise RuntimeError(f"lead-{lead} finite target count differs from its mask")
        geometry[lead] = {
            "issue_start_index_global_inclusive": issue_start,
            "issue_end_index_global_exclusive": issue_end_exclusive,
            "target_start_index_global_inclusive": indices[0],
            "target_end_index_global_inclusive": indices[-1],
            "target_index_sha256": sha256(canonical_json_bytes(indices)).hexdigest(),
            "finite_target_mask_sha256": sha256(finite_mask).hexdigest(),
            "finite_target_count": before_counts[lead],
        }

    improvement = before_objective - after_objective
    last_issue_index = issue_end_exclusive - 1
    return {
        "optimizer_step": int(optimizer_step),
        "segment_start_index_global_inclusive": start,
        "segment_end_index_global_exclusive": start + segment_days,
        "segment_first_date": str(runtime.dates[start]),
        "segment_last_date": str(runtime.dates[start + segment_days - 1]),
        "scored_issue_first_date": str(runtime.dates[issue_start]),
        "scored_issue_last_date": str(runtime.dates[last_issue_index]),
        "segment_days": segment_days,
        "filter_warmup_days": warmup,
        "before_step_objective_physical_unit_multilead_mse": before_objective,
        "after_step_objective_physical_unit_multilead_mse": after_objective,
        "objective_improvement_before_minus_after": improvement,
        "relative_objective_improvement": (
            improvement / before_objective if before_objective > 0.0 else None
        ),
        "strict_objective_decrease": after_objective < before_objective,
        "mse_by_lead_before_step": before_by_lead,
        "mse_by_lead_after_step": after_by_lead,
        "mse_improvement_by_lead_before_minus_after": {
            lead: before_by_lead[lead] - after_by_lead[lead]
            for lead in ordered_leads
        },
        "target_count_by_lead_before_step": before_counts,
        "target_count_by_lead_after_step": after_counts,
        "target_geometry_by_lead": geometry,
        "identical_target_geometry_before_after": True,
        "after_step_was_recomputed": True,
        "after_step_recomputed_under_no_grad": True,
        "reserved_evaluation_values_used": 0,
    }


def _history_row(
    *,
    epoch: int,
    training_objective: float | None,
    validation: Any,
    parameter_sha256: str,
    optimizer_steps: int,
    forecast_events: int,
    gradient_names: Sequence[str],
    maximum_gradient_norm_before_clip: float | None,
    training_diagnostics: Mapping[str, Any],
    prediction_sha256: str,
) -> Mapping[str, Any]:
    row = {
        "epoch": int(epoch),
        "training_objective_physical_unit_multilead_mse": training_objective,
        "checkpoint_selection_objective_728_origins_without_warmup": float(
            validation.full_objective_without_warmup
        ),
        "gate_objective_712_origins_after_16_day_warmup": float(validation.objective),
        "mse_by_lead_after_warmup": dict(validation.mse_by_lead),
        "nse_by_lead_after_warmup": dict(validation.nse_by_lead),
        "target_count_by_lead_after_warmup": dict(validation.target_count_by_lead),
        "target_count_by_lead_without_warmup": dict(
            validation.full_target_count_by_lead_without_warmup
        ),
        "parameter_sha256": parameter_sha256,
        "optimizer_steps": int(optimizer_steps),
        "sampled_forecast_events": int(forecast_events),
        "finite_gradients": None if epoch == 0 else bool(gradient_names),
        "nonzero_gradient_parameter_names": list(gradient_names),
        "nonzero_gradient_parameter_tensor_count": len(gradient_names),
        "maximum_gradient_norm_before_clip": maximum_gradient_norm_before_clip,
        "fixed_window_prediction_sha256": prediction_sha256,
    }
    overlap = set(row).intersection(training_diagnostics)
    if overlap:
        raise ValueError(f"training diagnostics overwrite history fields: {sorted(overlap)}")
    row.update(copy.deepcopy(dict(training_diagnostics)))
    return row


def _epoch_completed_event(
    *,
    epoch: int,
    training_objective: float | None,
    checkpoint_selection_objective: float,
    gate_objective: float,
    checkpoint_sha256: str,
    parameter_sha256: str,
    optimizer_steps: int,
    sampled_forecast_events: int,
    training_diagnostics: Mapping[str, Any],
) -> Mapping[str, Any]:
    event = {
        "event_type": "epoch_completed",
        "epoch": int(epoch),
        "training_objective": training_objective,
        "checkpoint_selection_objective_728": float(
            checkpoint_selection_objective
        ),
        "gate_objective_712": float(gate_objective),
        "checkpoint_sha256": checkpoint_sha256,
        "parameter_sha256": parameter_sha256,
        "optimizer_steps": int(optimizer_steps),
        "sampled_forecast_events": int(sampled_forecast_events),
    }
    overlap = set(event).intersection(training_diagnostics)
    if overlap:
        raise ValueError(f"training diagnostics overwrite event fields: {sorted(overlap)}")
    event.update(copy.deepcopy(dict(training_diagnostics)))
    return event


def _checkpoint_payload(
    *,
    preflight: PreflightResult,
    epoch: int,
    net: Any,
    optimizer: Any,
    history: Sequence[Mapping[str, Any]],
    best_epoch: int,
    best_objective: float,
    best_model_state: Any,
    optimizer_steps: int,
    forecast_events: int,
    gradient_names: Iterable[str],
    generator: Any,
    ledger: Any,
    previous_checkpoint_sha256: str | None,
    torch_module: ModuleType,
    numpy_module: ModuleType,
) -> Mapping[str, Any]:
    return {
        "schema_version": "daily_camels_ukf_knet_parity_checkpoint_v1",
        "identity": dict(preflight.identity),
        "identity_sha256": preflight.identity_sha256,
        "gain_initialization": preflight.gain_initialization,
        "correction_scope": preflight.correction_scope,
        "completed_epoch": int(epoch),
        "model_state": _cpu_clone(net.state_dict(), torch_module),
        "optimizer_state": _cpu_clone(optimizer.state_dict(), torch_module),
        "history": copy.deepcopy(list(history)),
        "best_epoch": int(best_epoch),
        "best_checkpoint_selection_objective": float(best_objective),
        "best_model_state": _cpu_clone(best_model_state, torch_module),
        "optimizer_steps": int(optimizer_steps),
        "sampled_forecast_events": int(forecast_events),
        "nonzero_gradient_parameter_names": sorted(set(gradient_names)),
        "python_random_state": random.getstate(),
        "numpy_random_state": numpy_module.random.get_state(),
        "torch_cpu_random_state": torch_module.get_rng_state().cpu(),
        "torch_cuda_random_states": (
            [state.cpu() for state in torch_module.cuda.get_rng_state_all()]
            if torch_module.cuda.is_available()
            else []
        ),
        "sampler_generator_state": generator.get_state().cpu(),
        "access_ledger": dict(_ledger_dict(ledger)),
        "previous_checkpoint_sha256": previous_checkpoint_sha256,
    }


def _load_continuation_payload(
    spec: ContinuationSpec,
    torch_module: ModuleType,
) -> Mapping[str, Any]:
    # torch.load uses pickle for this legacy checkpoint.  Deserialization is
    # allowed only after the regular-file check and a second exact hash check.
    _assert_hash(spec.checkpoint_path, spec.checkpoint_sha256, "continuation checkpoint")
    payload = torch_module.load(
        spec.checkpoint_path,
        map_location="cpu",
        weights_only=False,
    )
    if not isinstance(payload, Mapping):
        raise TypeError("continuation checkpoint root must be a mapping")
    _validate_continuation_payload(payload, spec)
    return payload


def _restore_checkpoint_random_states(
    payload: Mapping[str, Any],
    generator: Any,
    numpy_module: ModuleType,
    torch_module: ModuleType,
    *,
    device: str,
) -> None:
    random.setstate(payload["python_random_state"])
    numpy_module.random.set_state(payload["numpy_random_state"])
    torch_module.set_rng_state(payload["torch_cpu_random_state"])
    cuda_states = payload["torch_cuda_random_states"]
    if not isinstance(cuda_states, Sequence):
        raise TypeError("checkpoint torch_cuda_random_states must be a sequence")
    if device == "cuda":
        if not torch_module.cuda.is_available():
            raise RuntimeError("continuation checkpoint requires CUDA")
        device_count = int(torch_module.cuda.device_count())
        if len(cuda_states) != device_count:
            raise RuntimeError(
                "checkpoint CUDA random-state count differs from visible devices"
            )
        torch_module.cuda.set_rng_state_all(list(cuda_states))
    elif cuda_states:
        raise RuntimeError("CUDA continuation checkpoint cannot resume on CPU")
    generator.set_state(payload["sampler_generator_state"])


def _history_same_segment_replays(
    history: Sequence[Mapping[str, Any]],
) -> list[Mapping[str, Any]]:
    flattened: list[Mapping[str, Any]] = []
    for row in history:
        values = row.get("same_segment_step_replays", [])
        if not isinstance(values, Sequence) or isinstance(values, (str, bytes)):
            raise TypeError("history same_segment_step_replays must be a sequence")
        for value in values:
            if not isinstance(value, Mapping):
                raise TypeError("history same-segment replay must be a mapping")
            flattened.append(copy.deepcopy(dict(value)))
    return flattened


def execute_training(
    preflight: PreflightResult,
    runtime: Any,
    numpy_module: ModuleType,
    torch_module: ModuleType,
    runner: ModuleType,
    io_module: ModuleType,
    ledger: Any,
    events: list[dict[str, Any]],
    strict_zero_gain_reference: Any,
    *,
    device: str,
) -> Mapping[str, Any]:
    if not runtime.initialization_evidence.scientific_claim_allowed:
        raise PermissionError("backward-time diagnostic initialization is replay-only")
    config = preflight.configuration
    model = config["model"]
    optimization = config["optimization"]
    gate_config = config["gate"]
    _validate_training_hyperparameters(optimization)
    if int(optimization["checkpoint_every_epochs"]) != 1:
        raise ValueError("this recovery route requires an immutable checkpoint every epoch")

    seed = int(optimization["seed"])
    torch_module.manual_seed(seed)
    if device == "cuda":
        torch_module.cuda.manual_seed_all(seed)
    random.seed(seed)
    numpy_module.random.seed(seed)
    generator = torch_module.Generator(device="cpu")
    generator.manual_seed(seed)

    net = runner.build_native_knet(
        runtime,
        zero_gain=False,
        gain_initialization=preflight.gain_initialization,
        correction_scope=preflight.correction_scope,
        seed=seed,
        hidden=int(model["hidden_dimension"]),
        in_mult=int(model["input_multiplier"]),
        out_mult=int(model["output_multiplier"]),
        feature_scale_floor=float(model["feature_scale_floor"]),
        normalized_feature_guard=float(model["normalized_feature_guard"]),
    )
    optimizer = torch_module.optim.Adam(
        net.parameters(),
        lr=float(optimization["learning_rate"]),
        weight_decay=float(optimization["weight_decay"]),
    )
    recovery = runner.select_window(runtime, "recovery")
    training_states = runner.training_open_loop_states(runtime)
    maximum_start = runtime.training_days - int(optimization["segment_days"])
    if maximum_start < 0:
        raise ValueError("training segment exceeds the training period")
    training_segment_plan = _configured_training_segment_plan(
        optimization,
        training_days=int(runtime.training_days),
        leads=preflight.contract.leads,
    )
    if int(training_segment_plan["maximum_segment_start_index"]) != maximum_start:
        raise RuntimeError("training segment plan maximum start is inconsistent")
    configured_starts = training_segment_plan[
        "fixed_training_segment_start_indices"
    ]
    fixed_training_segment_starts = (
        None
        if configured_starts is None
        else tuple(int(value) for value in configured_starts)
    )

    checkpoint_dir = preflight.run_directory / CHECKPOINT_DIRECTORY
    prediction_dir = preflight.run_directory / PREDICTION_DIRECTORY
    checkpoint_dir.mkdir(parents=False, exist_ok=False)
    prediction_dir.mkdir(parents=False, exist_ok=False)
    previous_checkpoint_hash: str | None = None
    continuation = preflight.continuation
    optimizer_steps = 0
    forecast_events = 0
    all_gradient_names: set[str] = set()
    all_same_segment_step_replays: list[Mapping[str, Any]] = []
    history: list[Mapping[str, Any]] = []
    source_checkpoint_objective: float | None = None
    source_history_epoch_count = 0
    imported_epoch_checkpoint_count = 0

    epoch_zero = runner.evaluate_knet(net, runtime, recovery)
    runner.assert_identical_forecast_geometry(
        _score_pairs(runner, strict_zero_gain_reference),
        _score_pairs(runner, epoch_zero),
    )
    epoch_zero_vs_strict_zero = _compare_score_to_strict_zero_gain(
        epoch_zero,
        strict_zero_gain_reference,
        preflight.contract.leads,
    )
    if dict(epoch_zero.full_target_count_by_lead_without_warmup) != {
        lead: 728 for lead in preflight.contract.leads
    }:
        raise RuntimeError("epoch zero checkpoint objective must use 728 origins per lead")
    epoch_zero_hash = runner.parameter_sha256(net)
    if continuation is None:
        prediction_hash = _write_npz(
            io_module,
            numpy_module,
            prediction_dir / "epoch_000.npz",
            _prediction_arrays(epoch_zero, numpy_module),
        )
    else:
        prediction_hash = sha256(
            _npz_bytes(
                numpy_module,
                _prediction_arrays(epoch_zero, numpy_module),
            )
        ).hexdigest()
    epoch_zero_reproducibility = _epoch_zero_reproducibility_evidence(
        config,
        objective=float(epoch_zero.full_objective_without_warmup),
        parameter_sha256=epoch_zero_hash,
        prediction_sha256=prediction_hash,
    )
    epoch_zero_training_diagnostics = _summarize_epoch_training_diagnostics(
        {lead: () for lead in preflight.contract.leads},
        {lead: 0 for lead in preflight.contract.leads},
        gradient_clipped_optimizer_step_count=0,
        optimizer_step_count=0,
    )
    fresh_epoch_zero_row = _history_row(
        epoch=0,
        training_objective=None,
        validation=epoch_zero,
        parameter_sha256=epoch_zero_hash,
        optimizer_steps=0,
        forecast_events=0,
        gradient_names=(),
        maximum_gradient_norm_before_clip=None,
        training_diagnostics=epoch_zero_training_diagnostics,
        prediction_sha256=prediction_hash,
    )
    if continuation is None:
        history.append(fresh_epoch_zero_row)
        best_epoch = 0
        best_objective = float(epoch_zero.full_objective_without_warmup)
        best_model_state = _cpu_clone(net.state_dict(), torch_module)
        payload = _checkpoint_payload(
            preflight=preflight,
            epoch=0,
            net=net,
            optimizer=optimizer,
            history=history,
            best_epoch=best_epoch,
            best_objective=best_objective,
            best_model_state=best_model_state,
            optimizer_steps=optimizer_steps,
            forecast_events=forecast_events,
            gradient_names=all_gradient_names,
            generator=generator,
            ledger=ledger,
            previous_checkpoint_sha256=None,
            torch_module=torch_module,
            numpy_module=numpy_module,
        )
        previous_checkpoint_hash = io_module.atomic_write_bytes(
            checkpoint_dir / "epoch_000.pt",
            _checkpoint_bytes(torch_module, payload),
            replace=False,
        )
        best_payload = _cpu_clone(payload, torch_module)
        _write_json(
            io_module,
            preflight.run_directory / HISTORY_FILE,
            history,
            replace=False,
        )
        _append_event(
            io_module,
            preflight.run_directory / EVENT_FILE,
            events,
            _epoch_completed_event(
                epoch=0,
                training_objective=None,
                checkpoint_selection_objective=best_objective,
                gate_objective=float(epoch_zero.objective),
                checkpoint_sha256=previous_checkpoint_hash,
                parameter_sha256=epoch_zero_hash,
                optimizer_steps=0,
                sampled_forecast_events=0,
                training_diagnostics=epoch_zero_training_diagnostics,
            ),
        )
        last_payload = payload
        last_validation = epoch_zero
        epoch_range = range(1, int(optimization["training_epochs"]) + 1)
    else:
        payload = _load_continuation_payload(continuation, torch_module)
        history = copy.deepcopy(list(payload["history"]))
        source_history_epoch_count = len(history)
        source_epoch_zero_row = history[0]
        for key in (
            "parameter_sha256",
            "fixed_window_prediction_sha256",
        ):
            if source_epoch_zero_row.get(key) != fresh_epoch_zero_row.get(key):
                raise RuntimeError(f"continuation source epoch-zero {key} changed")
        source_epoch_zero_objective = source_epoch_zero_row.get(
            "checkpoint_selection_objective_728_origins_without_warmup"
        )
        if not math.isclose(
            float(source_epoch_zero_objective),
            float(epoch_zero.full_objective_without_warmup),
            rel_tol=0.0,
            abs_tol=1.0e-12,
        ):
            raise RuntimeError("continuation source epoch-zero objective changed")

        net.load_state_dict(payload["model_state"])
        optimizer.load_state_dict(payload["optimizer_state"])
        restored_parameter_hash = runner.parameter_sha256(net)
        if restored_parameter_hash != continuation.parameter_sha256:
            raise RuntimeError("restored continuation parameter_sha256 differs")
        restored_validation = runner.evaluate_knet(net, runtime, recovery)
        runner.assert_identical_forecast_geometry(
            _score_pairs(runner, strict_zero_gain_reference),
            _score_pairs(runner, restored_validation),
        )
        if dict(restored_validation.full_target_count_by_lead_without_warmup) != {
            lead: 728 for lead in preflight.contract.leads
        }:
            raise RuntimeError("restored checkpoint selection geometry changed")
        source_checkpoint_objective = float(
            history[-1][
                "checkpoint_selection_objective_728_origins_without_warmup"
            ]
        )
        if not math.isclose(
            float(restored_validation.full_objective_without_warmup),
            source_checkpoint_objective,
            rel_tol=0.0,
            abs_tol=1.0e-15,
        ):
            raise RuntimeError("restored checkpoint objective differs from source history")
        restored_prediction_hash = sha256(
            _npz_bytes(
                numpy_module,
                _prediction_arrays(restored_validation, numpy_module),
            )
        ).hexdigest()
        if restored_prediction_hash != history[-1].get(
            "fixed_window_prediction_sha256"
        ):
            raise RuntimeError("restored checkpoint prediction_sha256 differs")
        if canonical_json_bytes(_ledger_dict(ledger)) != canonical_json_bytes(
            payload["access_ledger"]
        ):
            raise RuntimeError("current access_ledger differs from source checkpoint")

        optimizer_steps = int(payload["optimizer_steps"])
        forecast_events = int(payload["sampled_forecast_events"])
        all_gradient_names = set(payload["nonzero_gradient_parameter_names"])
        all_same_segment_step_replays = _history_same_segment_replays(history)
        best_epoch = int(payload["best_epoch"])
        best_objective = float(payload["best_checkpoint_selection_objective"])
        best_model_state = _cpu_clone(payload["best_model_state"], torch_module)
        best_payload = _cpu_clone(payload, torch_module)
        imported_bytes = continuation.checkpoint_path.read_bytes()
        previous_checkpoint_hash = io_module.atomic_write_bytes(
            checkpoint_dir / f"epoch_{continuation.completed_epoch:03d}.pt",
            imported_bytes,
            replace=False,
        )
        if previous_checkpoint_hash != continuation.checkpoint_sha256:
            raise RuntimeError("imported continuation checkpoint bytes changed")
        imported_epoch_checkpoint_count = 1
        _write_json(
            io_module,
            preflight.run_directory / HISTORY_FILE,
            history,
            replace=False,
        )
        _append_event(
            io_module,
            preflight.run_directory / EVENT_FILE,
            events,
            {
                "event_type": "resume_checkpoint_loaded",
                "source_experiment_id": continuation.source_experiment_id,
                "source_identity_sha256": continuation.source_identity_sha256,
                "source_checkpoint_sha256": continuation.checkpoint_sha256,
                "source_epoch_history_sha256": (
                    continuation.source_epoch_history_sha256
                ),
                "completed_epoch": continuation.completed_epoch,
                "optimizer_steps": optimizer_steps,
                "sampled_forecast_events": forecast_events,
                "parameter_sha256": restored_parameter_hash,
                "checkpoint_selection_objective_728": (
                    source_checkpoint_objective
                ),
                "reserved_evaluation_operations": 0,
            },
        )
        # Evaluation above verifies the exact boundary.  Reload model and
        # optimizer once more, then restore all random streams as the last
        # operations before the first continued optimizer update.
        net.load_state_dict(payload["model_state"])
        optimizer.load_state_dict(payload["optimizer_state"])
        _restore_checkpoint_random_states(
            payload,
            generator,
            numpy_module,
            torch_module,
            device=device,
        )
        last_payload = payload
        last_validation = restored_validation
        epoch_range = _continuation_epoch_range(
            continuation.completed_epoch,
            int(optimization["training_epochs"]),
        )

    for epoch in epoch_range:
        net.train()
        losses: list[float] = []
        lead_training_mse_values: dict[int, list[float]] = {
            lead: [] for lead in preflight.contract.leads
        }
        finite_target_count_by_lead: dict[int, int] = {
            lead: 0 for lead in preflight.contract.leads
        }
        gradient_clipped_optimizer_steps = 0
        same_segment_step_replays: list[Mapping[str, Any]] = []
        epoch_gradient_names: set[str] = set()
        maximum_gradient_norm = 0.0
        for _ in range(int(optimization["steps_per_epoch"])):
            if fixed_training_segment_starts is None:
                starts = (
                    int(
                        torch_module.randint(
                            0,
                            maximum_start + 1,
                            (1,),
                            generator=generator,
                            device="cpu",
                        ).item()
                    ),
                )
            else:
                starts = fixed_training_segment_starts
            segment_count = len(starts)
            optimizer.zero_grad(set_to_none=True)
            before_step_segments: list[Any] = []
            step_loss_values: list[float] = []
            step_mse_values_by_lead: dict[int, list[float]] = {
                lead: [] for lead in preflight.contract.leads
            }
            step_target_count_by_lead: dict[int, int] = {
                lead: 0 for lead in preflight.contract.leads
            }
            for start in starts:
                segment = runner.segment_multilead_mse(
                    net,
                    runtime,
                    start=start,
                    segment_days=int(optimization["segment_days"]),
                    filter_warmup_days=int(
                        optimization["segment_filter_warmup_days"]
                    ),
                    open_loop_states=training_states,
                )
                detached_segment = _detached_segment_loss(
                    segment,
                    preflight.contract.leads,
                )
                before_step_segments.append(detached_segment)
                step_loss_values.append(float(detached_segment.objective))
                for lead in preflight.contract.leads:
                    step_mse_values_by_lead[lead].append(
                        float(detached_segment.mse_by_lead[lead])
                    )
                    step_target_count_by_lead[lead] += int(
                        detached_segment.target_count_by_lead[lead]
                    )
                scaled_segment_objective = segment.objective / segment_count
                scaled_segment_objective.backward()
                forecast_events += sum(
                    int(value)
                    for value in detached_segment.target_count_by_lead.values()
                )
                del scaled_segment_objective
                del segment

            for lead in preflight.contract.leads:
                lead_training_mse_values[lead].append(
                    math.fsum(step_mse_values_by_lead[lead]) / segment_count
                )
                finite_target_count_by_lead[lead] += step_target_count_by_lead[lead]
            step_loss = math.fsum(step_loss_values) / segment_count
            step_gradient_names: set[str] = set()
            for name, parameter in net.named_parameters():
                gradient = parameter.grad
                if gradient is None:
                    continue
                if not bool(torch_module.isfinite(gradient).all()):
                    raise FloatingPointError(f"non-finite gradient in {name}")
                if bool(torch_module.count_nonzero(gradient)):
                    step_gradient_names.add(name)
            if not step_gradient_names:
                raise RuntimeError("an optimizer step has no nonzero parameter gradient")
            epoch_gradient_names.update(step_gradient_names)
            pre_clip_norm_value = torch_module.nn.utils.clip_grad_norm_(
                net.parameters(),
                float(optimization["gradient_maximum_norm"]),
                error_if_nonfinite=True,
            )
            if hasattr(pre_clip_norm_value, "detach"):
                pre_clip_norm_value = pre_clip_norm_value.detach()
            if hasattr(pre_clip_norm_value, "cpu"):
                pre_clip_norm_value = pre_clip_norm_value.cpu()
            if hasattr(pre_clip_norm_value, "item"):
                pre_clip_norm_value = pre_clip_norm_value.item()
            pre_clip_norm = float(pre_clip_norm_value)
            if not math.isfinite(pre_clip_norm):
                raise FloatingPointError("non-finite total gradient norm before clipping")
            maximum_gradient_norm = max(maximum_gradient_norm, pre_clip_norm)
            if pre_clip_norm > float(optimization["gradient_maximum_norm"]):
                gradient_clipped_optimizer_steps += 1
            optimizer.step()
            optimizer_steps += 1
            constituent_replays: list[Mapping[str, Any]] = []
            with torch_module.no_grad():
                for start, before_step_segment in zip(
                    starts,
                    before_step_segments,
                    strict=True,
                ):
                    after_step_segment = runner.segment_multilead_mse(
                        net,
                        runtime,
                        start=start,
                        segment_days=int(optimization["segment_days"]),
                        filter_warmup_days=int(
                            optimization["segment_filter_warmup_days"]
                        ),
                        open_loop_states=training_states,
                    )
                    constituent_replays.append(
                        _same_segment_step_replay_evidence(
                            before_step=before_step_segment,
                            after_step=after_step_segment,
                            runtime=runtime,
                            start=start,
                            segment_days=int(optimization["segment_days"]),
                            filter_warmup_days=int(
                                optimization["segment_filter_warmup_days"]
                            ),
                            leads=preflight.contract.leads,
                            optimizer_step=optimizer_steps,
                            torch_module=torch_module,
                        )
                    )
            if segment_count == 1:
                step_replay = constituent_replays[0]
            else:
                step_replay = _same_training_batch_step_replay_evidence(
                    constituent_replays,
                    optimizer_step=optimizer_steps,
                )
            same_segment_step_replays.append(step_replay)
            losses.append(step_loss)
        all_gradient_names.update(epoch_gradient_names)
        all_same_segment_step_replays.extend(same_segment_step_replays)
        epoch_training_diagnostics = _summarize_epoch_training_diagnostics(
            lead_training_mse_values,
            finite_target_count_by_lead,
            gradient_clipped_optimizer_step_count=gradient_clipped_optimizer_steps,
            optimizer_step_count=len(losses),
            same_segment_step_replays=same_segment_step_replays,
        )
        training_objective = math.fsum(losses) / len(losses)
        reconstructed_training_objective = math.fsum(
            epoch_training_diagnostics[
                "training_mse_by_lead_physical_unit_mean_over_optimizer_steps"
            ].values()
        ) / len(preflight.contract.leads)
        if not math.isclose(
            training_objective,
            reconstructed_training_objective,
            rel_tol=1.0e-6,
            abs_tol=1.0e-8,
        ):
            raise RuntimeError("epoch training objective does not reconstruct by equal leads")

        validation = runner.evaluate_knet(net, runtime, recovery)
        checkpoint_objective = float(validation.full_objective_without_warmup)
        if dict(validation.full_target_count_by_lead_without_warmup) != {
            lead: 728 for lead in preflight.contract.leads
        }:
            raise RuntimeError("checkpoint selection geometry changed from 728 origins")
        parameter_hash = runner.parameter_sha256(net)
        prediction_hash = _write_npz(
            io_module,
            numpy_module,
            prediction_dir / f"epoch_{epoch:03d}.npz",
            _prediction_arrays(validation, numpy_module),
        )
        history.append(
            _history_row(
                epoch=epoch,
                training_objective=training_objective,
                validation=validation,
                parameter_sha256=parameter_hash,
                optimizer_steps=optimizer_steps,
                forecast_events=forecast_events,
                gradient_names=sorted(epoch_gradient_names),
                maximum_gradient_norm_before_clip=maximum_gradient_norm,
                training_diagnostics=epoch_training_diagnostics,
                prediction_sha256=prediction_hash,
            )
        )
        if checkpoint_objective < best_objective:
            best_epoch = epoch
            best_objective = checkpoint_objective
            best_model_state = _cpu_clone(net.state_dict(), torch_module)
        payload = _checkpoint_payload(
            preflight=preflight,
            epoch=epoch,
            net=net,
            optimizer=optimizer,
            history=history,
            best_epoch=best_epoch,
            best_objective=best_objective,
            best_model_state=best_model_state,
            optimizer_steps=optimizer_steps,
            forecast_events=forecast_events,
            gradient_names=all_gradient_names,
            generator=generator,
            ledger=ledger,
            previous_checkpoint_sha256=previous_checkpoint_hash,
            torch_module=torch_module,
            numpy_module=numpy_module,
        )
        checkpoint_path = checkpoint_dir / f"epoch_{epoch:03d}.pt"
        previous_checkpoint_hash = io_module.atomic_write_bytes(
            checkpoint_path,
            _checkpoint_bytes(torch_module, payload),
            replace=False,
        )
        if best_epoch == epoch:
            best_payload = _cpu_clone(payload, torch_module)
        last_payload = payload
        last_validation = validation
        _write_json(
            io_module,
            preflight.run_directory / HISTORY_FILE,
            history,
            replace=True,
        )
        _append_event(
            io_module,
            preflight.run_directory / EVENT_FILE,
            events,
            _epoch_completed_event(
                epoch=epoch,
                training_objective=training_objective,
                checkpoint_selection_objective=checkpoint_objective,
                gate_objective=float(validation.objective),
                checkpoint_sha256=previous_checkpoint_hash,
                parameter_sha256=parameter_hash,
                optimizer_steps=optimizer_steps,
                sampled_forecast_events=forecast_events,
                training_diagnostics=epoch_training_diagnostics,
            ),
        )

    last_checkpoint_hash = io_module.atomic_write_bytes(
        checkpoint_dir / "last.pt",
        _checkpoint_bytes(torch_module, last_payload),
        replace=False,
    )
    best_checkpoint_hash = io_module.atomic_write_bytes(
        checkpoint_dir / "best.pt",
        _checkpoint_bytes(torch_module, best_payload),
        replace=False,
    )
    net.load_state_dict(best_model_state)
    best_validation = runner.evaluate_knet(net, runtime, recovery)
    runner.assert_identical_forecast_geometry(
        _score_pairs(runner, strict_zero_gain_reference),
        _score_pairs(runner, best_validation),
    )
    best_vs_strict_zero = _compare_score_to_strict_zero_gain(
        best_validation,
        strict_zero_gain_reference,
        preflight.contract.leads,
    )
    if not math.isclose(
        float(best_validation.full_objective_without_warmup),
        best_objective,
        rel_tol=0.0,
        abs_tol=1e-15,
    ):
        raise RuntimeError("best checkpoint replay differs from checkpoint selection history")

    performance = sys.modules[CONTRACT_MODULE_ALIAS].performance_gate(
        epoch_zero_objective=float(epoch_zero.full_objective_without_warmup),
        best_objective=best_objective,
        best_epoch=best_epoch,
        nse_by_lead=best_validation.nse_by_lead,
        target_count_by_lead=best_validation.target_count_by_lead,
        better_than_strict_zero_gain_each_lead=bool(
            best_vs_strict_zero[
                "candidate_better_than_strict_zero_gain_each_lead"
            ]
        ),
        contract=preflight.contract,
    )
    failed = list(performance.failed_gates)
    best_parameter_hash = runner.parameter_sha256(net)
    if bool(gate_config["require_parameter_hash_change"]) and best_parameter_hash == epoch_zero_hash:
        failed.append("parameter_hash_change")
    require_same_segment_improvement = gate_config.get(
        "require_same_segment_post_step_improvement", False
    )
    if not isinstance(require_same_segment_improvement, bool):
        raise TypeError("same-segment post-step improvement gate must be a JSON boolean")
    every_same_segment_step_improved = bool(all_same_segment_step_replays) and all(
        replay["strict_objective_decrease"]
        for replay in all_same_segment_step_replays
    )
    if require_same_segment_improvement and not every_same_segment_step_improved:
        failed.append("same_segment_post_step_improvement")
    post_resume_best_epoch: int | None = None
    post_resume_best_objective: float | None = None
    post_resume_objective_improvement: float | None = None
    post_resume_improvement_gate_passed: bool | None = None
    if continuation is not None:
        post_resume_rows = [
            row
            for row in history
            if int(row["epoch"]) > continuation.completed_epoch
        ]
        if not post_resume_rows:
            raise RuntimeError("continuation produced no post-resume epoch")
        post_resume_best_row = min(
            post_resume_rows,
            key=lambda row: float(
                row[
                    "checkpoint_selection_objective_728_origins_without_warmup"
                ]
            ),
        )
        post_resume_best_epoch = int(post_resume_best_row["epoch"])
        post_resume_best_objective = float(
            post_resume_best_row[
                "checkpoint_selection_objective_728_origins_without_warmup"
            ]
        )
        if source_checkpoint_objective is None:
            raise RuntimeError("continuation source checkpoint objective is absent")
        post_resume_objective_improvement = (
            source_checkpoint_objective - post_resume_best_objective
        )
        minimum_improvement = float(optimization["minimum_post_zero_improvement"])
        post_resume_improvement_gate_passed = (
            post_resume_objective_improvement >= minimum_improvement
        )
        if not post_resume_improvement_gate_passed:
            failed.append("post_resume_checkpoint_objective_improvement")
    _assert_zero_reserved_access(ledger)
    if bool(gate_config["require_zero_reserved_data_access"]) is not True:
        raise ValueError("zero reserved-data access gate must remain enabled")
    expected_optimizer_steps = int(
        training_segment_plan["expected_optimizer_step_count"]
    )
    expected_forecast_events = int(
        training_segment_plan[
            "total_candidate_forecast_target_event_count_all_epochs"
        ]
    )
    if optimizer_steps != expected_optimizer_steps:
        raise RuntimeError("cumulative optimizer_steps differ from the training plan")
    if forecast_events != expected_forecast_events:
        raise RuntimeError(
            "cumulative sampled_forecast_events differ from the training plan"
        )
    gate_passed = not failed

    feature_evidence = {
        "schema_version": "daily_camels_ukf_knet_parity_feature_diagnostics_v1",
        "training_scale_fit": training_scale_diagnostics(
            runtime,
            runner,
            numpy_module,
            floor=float(model["feature_scale_floor"]),
            guard=float(model["normalized_feature_guard"]),
        ),
        "best_checkpoint_recovery_features": _dynamic_feature_diagnostics(
            net,
            runtime,
            recovery,
            runner,
            numpy_module,
            torch_module,
            guard=float(model["normalized_feature_guard"]),
        ),
    }
    _write_json(
        io_module,
        preflight.run_directory / FEATURE_FILE,
        feature_evidence,
        replace=False,
    )
    return {
        "status": "TRAINING_COMPLETE_GATE_PASS" if gate_passed else "TRAINING_COMPLETE_GATE_FAIL",
        "scientific_claim_allowed": True,
        "gain_initialization": preflight.gain_initialization,
        "correction_scope": preflight.correction_scope,
        "objective_definition": {
            "optimizer": "equal_weight_1_2_3_day_physical_unit_mse",
            "recorded_training_objective": "before_optimizer_step",
            "gradient_accumulation": (
                "equal_weight_mean_over_training_segments_then_one_optimizer_step"
            ),
            "same_segment_diagnostic": (
                "fresh_no_grad_forward_on_identical_training_forecast_targets_after_step"
            ),
            "checkpoint_selection": "728_origins_without_filter_warmup",
            "nse_gate": "712_origins_after_16_day_filter_warmup",
        },
        "training_segment_plan": copy.deepcopy(dict(training_segment_plan)),
        "continuation": (
            {
                "enabled": False,
                "source_history_epoch_count": 0,
                "imported_epoch_checkpoint_count": 0,
            }
            if continuation is None
            else {
                "enabled": True,
                **dict(_continuation_identity(continuation)),
                "source_checkpoint_objective": source_checkpoint_objective,
                "post_resume_best_epoch": post_resume_best_epoch,
                "post_resume_best_checkpoint_objective": (
                    post_resume_best_objective
                ),
                "post_resume_checkpoint_objective_improvement": (
                    post_resume_objective_improvement
                ),
                "post_resume_improvement_gate_passed": (
                    post_resume_improvement_gate_passed
                ),
                "source_history_epoch_count": source_history_epoch_count,
                "imported_epoch_checkpoint_count": (
                    imported_epoch_checkpoint_count
                ),
                "new_epoch_count": (
                    int(optimization["training_epochs"])
                    - continuation.completed_epoch
                ),
                "new_optimizer_steps": (
                    optimizer_steps - continuation.optimizer_steps
                ),
                "new_sampled_forecast_events": (
                    forecast_events - continuation.sampled_forecast_events
                ),
            }
        ),
        "epoch_zero_reproducibility": copy.deepcopy(
            dict(epoch_zero_reproducibility)
        ),
        "epoch_zero_checkpoint_objective": float(
            epoch_zero.full_objective_without_warmup
        ),
        "best_epoch": int(best_epoch),
        "best_checkpoint_objective": best_objective,
        "objective_improvement": float(performance.objective_improvement),
        "best_gate_objective_after_warmup": float(best_validation.objective),
        "best_nse_by_lead": dict(best_validation.nse_by_lead),
        "best_target_count_by_lead_after_warmup": dict(
            best_validation.target_count_by_lead
        ),
        "best_target_count_by_lead_without_warmup": dict(
            best_validation.full_target_count_by_lead_without_warmup
        ),
        "epoch_zero_vs_strict_zero_gain": epoch_zero_vs_strict_zero,
        "best_vs_strict_zero_gain": best_vs_strict_zero,
        "best_better_than_strict_zero_gain_each_lead": bool(
            best_vs_strict_zero["candidate_better_than_strict_zero_gain_each_lead"]
        ),
        "gate_passed": gate_passed,
        "failed_gates": failed,
        "epoch_zero_parameter_sha256": epoch_zero_hash,
        "best_parameter_sha256": best_parameter_hash,
        "last_parameter_sha256": str(history[-1]["parameter_sha256"]),
        "parameter_hash_changed": best_parameter_hash != epoch_zero_hash,
        "optimizer_steps": optimizer_steps,
        "sampled_forecast_events": forecast_events,
        "same_segment_post_step_replay_count": len(all_same_segment_step_replays),
        "same_segment_every_optimizer_step_strictly_decreased": (
            every_same_segment_step_improved
        ),
        "same_segment_step_replays": list(all_same_segment_step_replays),
        "nonzero_gradient_parameter_names": sorted(all_gradient_names),
        "best_checkpoint_sha256": best_checkpoint_hash,
        "last_checkpoint_sha256": last_checkpoint_hash,
        "epoch_checkpoint_count": (
            len(history)
            if continuation is None
            else imported_epoch_checkpoint_count
            + int(optimization["training_epochs"])
            - continuation.completed_epoch
        ),
        "fixed_window_prediction_artifact_count": (
            len(history)
            if continuation is None
            else int(optimization["training_epochs"])
            - continuation.completed_epoch
        ),
        "cumulative_history_epoch_count": len(history),
        "last_validation_checkpoint_objective": float(
            last_validation.full_objective_without_warmup
        ),
        "access_ledger": _ledger_dict(ledger),
        "feature_diagnostics_file": FEATURE_FILE,
    }


def _manifest(io_module: ModuleType, run_directory: Path) -> Mapping[str, str]:
    excluded = {MANIFEST_FILE, COMPLETION_FILE}
    result: dict[str, str] = {}
    for path in sorted(run_directory.rglob("*")):
        if not path.is_file() or OWNER_LOCK_DIRECTORY in path.parts:
            continue
        relative = path.relative_to(run_directory).as_posix()
        if relative in excluded:
            continue
        result[relative] = sha256_file(path)
    return result


def _seal_completion(
    io_module: ModuleType,
    preflight: PreflightResult,
    summary: Mapping[str, Any],
) -> None:
    summary_hash = _write_json(
        io_module,
        preflight.run_directory / SUMMARY_FILE,
        summary,
        replace=False,
    )
    manifest = {
        "schema_version": "daily_camels_ukf_knet_parity_manifest_v1",
        "experiment_id": preflight.experiment_id,
        "identity_sha256": preflight.identity_sha256,
        "files": _manifest(io_module, preflight.run_directory),
    }
    manifest_hash = _write_json(
        io_module,
        preflight.run_directory / MANIFEST_FILE,
        manifest,
        replace=False,
    )
    completion = {
        "schema_version": "daily_camels_ukf_knet_parity_completion_v1",
        "experiment_id": preflight.experiment_id,
        "identity_sha256": preflight.identity_sha256,
        "phase": preflight.phase,
        "status": summary["status"],
        "summary_sha256": summary_hash,
        "manifest_sha256": manifest_hash,
        "completed_at_utc": _utc_now(),
    }
    _write_json(
        io_module,
        preflight.run_directory / COMPLETION_FILE,
        completion,
        replace=False,
    )


def _execute_numerical(
    preflight: PreflightResult,
    report: Mapping[str, Any],
    *,
    device: str,
) -> int:
    if (
        preflight.continuation is not None
        and device != preflight.continuation.source_device
    ):
        raise ValueError(
            "continuation device must match continuation.source_device "
            f"({preflight.continuation.source_device})"
        )
    io_module = _load_io(preflight)
    io_module.create_new_run(preflight.run_directory)
    owner = io_module.OwnerLock.acquire(
        preflight.run_directory / OWNER_LOCK_DIRECTORY,
        {
            "experiment_id": preflight.experiment_id,
            "identity_sha256": preflight.identity_sha256,
            "phase": preflight.phase,
            "device": device,
        },
    )
    events: list[dict[str, Any]] = []
    try:
        owner_record = _read_json(owner.path / "owner.json")
        _write_json(
            io_module,
            preflight.run_directory / "owner_evidence.json",
            owner_record,
            replace=False,
        )
        _write_json(
            io_module,
            preflight.run_directory / IDENTITY_FILE,
            preflight.identity,
            replace=False,
        )
        _write_json(
            io_module,
            preflight.run_directory / PREFLIGHT_FILE,
            report,
            replace=False,
        )
        _append_event(
            io_module,
            preflight.run_directory / EVENT_FILE,
            events,
            {
                "event_type": "preflight_completed",
                "identity_sha256": preflight.identity_sha256,
                "array_members_materialized": 0,
            },
        )

        numpy_module, torch_module, runner = _load_numerical_runtime(preflight)
        if device == "cuda":
            if not torch_module.cuda.is_available():
                raise RuntimeError("CUDA was requested but PyTorch CUDA is unavailable")
            selected_device = "cuda"
            torch_module.cuda.reset_peak_memory_stats()
        else:
            selected_device = "cpu"
        contract_module = sys.modules[CONTRACT_MODULE_ALIAS]
        ledger = contract_module.AccessLedger()
        runtime, replay_results, replay_evidence = execute_replay(
            preflight,
            numpy_module,
            torch_module,
            runner,
            ledger,
            device=selected_device,
        )
        replay_hash = _write_json(
            io_module,
            preflight.run_directory / REPLAY_FILE,
            replay_evidence,
            replace=False,
        )
        replay_prediction_hash = _write_npz(
            io_module,
            numpy_module,
            preflight.run_directory / REPLAY_PREDICTIONS_FILE,
            _replay_predictions(numpy_module, replay_results),
        )
        _append_event(
            io_module,
            preflight.run_directory / EVENT_FILE,
            events,
            {
                "event_type": "ukf_and_zero_gain_replay_completed",
                "replay_evidence_sha256": replay_hash,
                "replay_predictions_sha256": replay_prediction_hash,
                "recovery_ukf_checkpoint_objective_728": replay_evidence["windows"][
                    "recovery"
                ]["ukf"]["checkpoint_objective_without_warmup"],
                "reserved_evaluation_operations": 0,
            },
        )

        training: Mapping[str, Any] | None = None
        if preflight.phase == "train":
            training = execute_training(
                preflight,
                runtime,
                numpy_module,
                torch_module,
                runner,
                io_module,
                ledger,
                events,
                replay_results["recovery"]["zero_gain_knet"],
                device=selected_device,
            )
        _assert_zero_reserved_access(ledger)
        resources = _resource_peaks(torch_module, device=selected_device)
        summary = {
            "schema_version": "daily_camels_ukf_knet_parity_result_v1",
            "status": (
                "REPLAY_COMPLETE_DIAGNOSTIC_ONLY"
                if preflight.phase == "replay"
                else training["status"]
            ),
            "experiment_id": preflight.experiment_id,
            "identity_sha256": preflight.identity_sha256,
            "phase": preflight.phase,
            "device": selected_device,
            "initialization_mode": preflight.initialization_mode,
            "gain_initialization": preflight.gain_initialization,
            "correction_scope": preflight.correction_scope,
            "scientific_claim_allowed": preflight.scientific_claim_allowed,
            "diagnostic_limitation": preflight.configuration["initialization"][
                "diagnostic_limitation"
            ],
            "ukf_recovery_checkpoint_objective_728": replay_evidence["windows"][
                "recovery"
            ]["ukf"]["checkpoint_objective_without_warmup"],
            "ukf_recovery_nse_by_lead_712": replay_evidence["windows"]["recovery"][
                "ukf"
            ]["nse_by_lead_after_warmup"],
            "zero_gain_maximum_open_loop_difference": replay_evidence["windows"][
                "recovery"
            ]["zero_gain_knet"]["maximum_open_loop_difference"],
            "training": training,
            "access_ledger": _ledger_dict(ledger),
            "resource_peaks": resources,
            "artifacts": {
                "replay_evidence": REPLAY_FILE,
                "replay_predictions": REPLAY_PREDICTIONS_FILE,
                "epoch_history": HISTORY_FILE if training is not None else None,
                "feature_diagnostics": FEATURE_FILE if training is not None else None,
            },
        }
        _append_event(
            io_module,
            preflight.run_directory / EVENT_FILE,
            events,
            {
                "event_type": "run_completed",
                "status": summary["status"],
                "resource_peaks": resources,
            },
        )
        _seal_completion(io_module, preflight, summary)
        print(canonical_json_bytes(summary).decode("utf-8"), end="")
        return 0 if training is None or bool(training["gate_passed"]) else 2
    except BaseException as exc:
        failure = {
            "schema_version": "daily_camels_ukf_knet_parity_failure_v1",
            "status": "FAILED_EVIDENCE_PRESERVED",
            "experiment_id": preflight.experiment_id,
            "identity_sha256": preflight.identity_sha256,
            "phase": preflight.phase,
            "error_type": type(exc).__name__,
            "error_message": str(exc),
            "failed_at_utc": _utc_now(),
        }
        try:
            _write_json(
                io_module,
                preflight.run_directory / FAILURE_FILE,
                failure,
                replace=False,
            )
        except Exception:
            pass
        raise
    finally:
        owner.release()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Run daily CAMELS UKF/KalmanNet parity.  --run-parent is the parent; "
            "the entry appends the exact experiment_id once."
        )
    )
    parser.add_argument(
        "--phase",
        "--stage",
        dest="phase",
        required=True,
        choices=PHASES,
    )
    parser.add_argument(
        "--config",
        type=Path,
        required=True,
    )
    parser.add_argument(
        "--run-parent",
        "--run-root",
        dest="run_parent",
        type=Path,
        required=True,
    )
    parser.add_argument(
        "--resume",
        type=Path,
        default=None,
        help="Exact checkpoint pinned by config.continuation; forbidden otherwise.",
    )
    parser.add_argument("--device", choices=("cuda", "cpu"), default="cuda")
    return parser


def execute(arguments: argparse.Namespace) -> int:
    preflight = standard_preflight(
        arguments.config,
        arguments.run_parent,
        phase=arguments.phase,
        resume=arguments.resume,
    )
    report = preflight_report(preflight, device=arguments.device)
    if arguments.phase == "probe":
        print(canonical_json_bytes(report).decode("utf-8"), end="")
        return 0
    return _execute_numerical(preflight, report, device=arguments.device)


def main(argv: Sequence[str] | None = None) -> int:
    return execute(build_parser().parse_args(argv))


if __name__ == "__main__":
    raise SystemExit(main())
