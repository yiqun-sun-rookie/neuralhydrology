"""Build a deterministic, calibration-only A30 HPC payload."""

from __future__ import annotations

import argparse
from hashlib import sha256
import gzip
import io
import json
from pathlib import Path, PurePosixPath
import sys
import tarfile
from typing import Mapping


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from global_hydrology.experiments.hbv_shortlead_contract import (
    ShortLeadContract,
    sha256_file,
)


EXPERIMENT_ID = (
    "DAILY_CAMELS_OFFICIAL_KALMANNET_TUKF06_CAUSAL_FAIR_"
    "RESOURCE_SMOKE_V2_20260825_A30"
)
SCHEMA_VERSION = "daily_camels_official_kalmannet_causal_fair_hpc_bundle_v1"
DEFAULT_CONFIG = (
    ROOT
    / "configs"
    / "daily_camels_official_kalmannet_tukf06_causal_fair_development_v3.json"
)
DEFAULT_PREPARED_DATA = (
    ROOT
    / "artifacts"
    / "daily_camels_official_kalmannet"
    / "HSR02_PREP_V3_20260825_02"
)


def _sha256_bytes(value: bytes) -> str:
    return sha256(value).hexdigest()


def _load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return value


def _safe_name(name: str) -> None:
    path = PurePosixPath(name)
    lowered = tuple(part.lower() for part in path.parts)
    if "\\" in name or path.is_absolute() or not path.parts or ".." in path.parts:
        raise ValueError(f"unsafe bundle member name: {name}")
    if (
        ".git" in lowered
        or "__pycache__" in lowered
        or any("hourly" in part for part in lowered)
        or any(part == "evaluation" or part.startswith("evaluation_") for part in lowered)
    ):
        raise ValueError(f"forbidden bundle member name: {name}")


def _source_members() -> dict[str, Path]:
    paths = (
        "configs/daily_camels_official_kalmannet_tukf06_causal_fair_development_v3.json",
        "configs/daily_camels_official_kalmannet_tukf06_causal_fair_iterations_v1.json",
        "configs/tukf06_full_diagonal_search_head_to_head_v1.json",
        "results/tukf06_full_diagonal_search_head_to_head_v1/selection_manifest.sha256.json",
        "hpc/daily_camels_official_kalmannet_causal_fair/preflight.py",
        "hpc/daily_camels_official_kalmannet_causal_fair/submit_resource_smoke_gpu.slurm",
        "hpc/daily_camels_official_kalmannet_causal_fair/verify_smoke.py",
        "scripts/build_daily_camels_official_kalmannet_causal_fair_hpc_bundle.py",
        "scripts/prepare_daily_camels_official_kalmannet_data.py",
        "scripts/run_hbv_native_shortlead_recovery.py",
        "knet/dl/nn_kalman_clamp_5.py",
        "src/global_hydrology/data/hbvlite_prior.py",
        "src/global_hydrology/experiments/hbv_shortlead_audit.py",
        "src/global_hydrology/experiments/hbv_shortlead_contract.py",
        "src/global_hydrology/experiments/hbv_shortlead_runner.py",
        "src/global_hydrology/models/differentiable_hbv_lite.py",
        "src/global_hydrology/models/hbvlite_system_model.py",
        "src/global_hydrology/models/knet_native_hbvlite_full_state.py",
        "src/global_hydrology/models/official_kalmannet_tsp_hbvlite.py",
        "third_party/KalmanNet_TSP_828a2cf/KNet/KalmanNet_nn.py",
    )
    return {name: (ROOT / name).resolve() for name in paths}


def _bundle_bytes(prepared_root: Path) -> tuple[dict[str, bytes], dict]:
    configuration = _load_json(DEFAULT_CONFIG)
    contract = ShortLeadContract.from_dict(configuration)
    if contract.verify_hashes(ROOT):
        raise ValueError("trusted runtime source hashes differ before bundle creation")
    prepared_manifest_path = prepared_root / "prepared_manifest.json"
    prepared_manifest = _load_json(prepared_manifest_path)
    if (
        prepared_manifest.get("calibration_only") is not True
        or prepared_manifest.get("evaluation_data_included") is not False
        or prepared_manifest.get("reserved_data_member_count") != 0
        or prepared_manifest.get("future_derived_member_read_count") != 0
        or tuple(prepared_manifest.get("basin_ids", ())) != contract.training_basins
        or prepared_manifest.get("basin_count") != len(contract.training_basins)
        or prepared_manifest.get("producer_sources", {}).get("config", {}).get("sha256")
        != sha256_file(DEFAULT_CONFIG)
    ):
        raise ValueError("prepared data identity or isolation evidence differs")

    members: dict[str, bytes] = {}
    for name, path in _source_members().items():
        if not path.is_file():
            raise FileNotFoundError(f"bundle source is absent: {name}")
        members[name] = path.read_bytes()
    initializers = (
        "scripts/__init__.py",
        "knet/__init__.py",
        "knet/dl/__init__.py",
        "src/global_hydrology/__init__.py",
        "src/global_hydrology/data/__init__.py",
        "src/global_hydrology/experiments/__init__.py",
        "src/global_hydrology/models/__init__.py",
    )
    for name in initializers:
        members[name] = b""
    prepared_members = ["inputs/prepared_manifest.json"]
    members[prepared_members[0]] = prepared_manifest_path.read_bytes()
    declared_files = {
        str(record["basin_id"]): record for record in prepared_manifest["files"]
    }
    for basin_id in contract.training_basins:
        source = prepared_root / f"{basin_id}.npz"
        name = f"inputs/{basin_id}.npz"
        if not source.is_file() or sha256_file(source) != declared_files[basin_id]["sha256"]:
            raise ValueError(f"prepared basin hash differs: {basin_id}")
        members[name] = source.read_bytes()
        prepared_members.append(name)
    for name in members:
        _safe_name(name)

    hashes = {name: _sha256_bytes(value) for name, value in sorted(members.items())}
    sizes = {name: len(value) for name, value in sorted(members.items())}
    manifest = {
        "schema_version": SCHEMA_VERSION,
        "experiment_id": EXPERIMENT_ID,
        "purpose": "daily_development_resource_smoke_only",
        "prepared_basin_count": len(contract.training_basins),
        "prepared_input_members": sorted(prepared_members),
        "reserved_data_member_count": 0,
        "future_derived_member_read_count": 0,
        "hourly_member_count": 0,
        "member_count": len(members),
        "member_sha256": hashes,
        "member_size": sizes,
        "trusted_runtime_sha256": {
            record.path: record.sha256 for record in contract.trusted_files
        },
        "upstream_kalmannet": configuration["upstream_provenance"],
        "configuration_sha256": sha256_file(DEFAULT_CONFIG),
        "prepared_manifest_sha256": sha256_file(prepared_manifest_path),
        "resource_calibration": {
            "role": "new official-GRU task pilot; not a formal or expanded run",
            "related_prior_host_peak_bytes": 1_314_578_432,
            "related_prior_gpu_peak_bytes": 31_475_200,
            "host_admission_multiplier": 4,
            "gpu_admission_multiplier": 16,
            "scheduler_requested_host_memory": "12G",
            "new_task_peak_required_before_expansion": True,
        },
    }
    return members, manifest


def _write_deterministic_archive(
    path: Path, members: Mapping[str, bytes], manifest: Mapping[str, object]
) -> None:
    manifest_bytes = (
        json.dumps(manifest, indent=2, ensure_ascii=False, sort_keys=True) + "\n"
    ).encode("utf-8")
    complete = {**members, "bundle_manifest.json": manifest_bytes}
    temporary = path.with_name(path.name + ".partial")
    with temporary.open("xb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", filename="", mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
                for name in sorted(complete):
                    value = complete[name]
                    record = tarfile.TarInfo(name)
                    record.size = len(value)
                    record.mtime = 0
                    record.uid = 0
                    record.gid = 0
                    record.uname = ""
                    record.gname = ""
                    record.mode = 0o600
                    archive.addfile(record, io.BytesIO(value))
    temporary.replace(path)


def _verify_archive(path: Path, manifest: Mapping[str, object]) -> None:
    with tarfile.open(path, mode="r:gz") as archive:
        records = archive.getmembers()
        names = {record.name for record in records}
        expected = set(manifest["member_sha256"]) | {"bundle_manifest.json"}
        if names != expected or any(not record.isfile() for record in records):
            raise RuntimeError("built archive inventory or member type differs")
        for record in records:
            _safe_name(record.name)
        internal = json.loads(archive.extractfile("bundle_manifest.json").read())
        if internal != manifest:
            raise RuntimeError("built archive internal manifest differs")
        for name, expected_hash in manifest["member_sha256"].items():
            if _sha256_bytes(archive.extractfile(name).read()) != expected_hash:
                raise RuntimeError(f"built archive member hash differs: {name}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--prepared-data-root", type=Path, default=DEFAULT_PREPARED_DATA)
    parser.add_argument("--output-directory", type=Path, required=True)
    arguments = parser.parse_args()
    prepared_root = arguments.prepared_data_root.resolve()
    output = arguments.output_directory.resolve()
    if output.exists():
        raise FileExistsError(f"bundle output directory already exists: {output}")
    output.mkdir(parents=True, exist_ok=False)
    members, manifest = _bundle_bytes(prepared_root)
    archive_name = EXPERIMENT_ID + ".tar.gz"
    archive_path = output / archive_name
    _write_deterministic_archive(archive_path, members, manifest)
    _verify_archive(archive_path, manifest)
    outer = {
        "schema_version": "daily_camels_official_kalmannet_outer_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "archive_name": archive_name,
        "archive_sha256": sha256_file(archive_path),
        "archive_size_bytes": archive_path.stat().st_size,
        "internal_manifest_sha256": _sha256_bytes(
            (
                json.dumps(manifest, indent=2, ensure_ascii=False, sort_keys=True)
                + "\n"
            ).encode("utf-8")
        ),
        "member_count": manifest["member_count"],
        "prepared_basin_count": 21,
        "reserved_data_member_count": 0,
        "future_derived_member_read_count": 0,
    }
    outer_path = output / "bundle_manifest.sha256.json"
    outer_path.write_text(
        json.dumps(outer, indent=2, ensure_ascii=False, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(outer, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
