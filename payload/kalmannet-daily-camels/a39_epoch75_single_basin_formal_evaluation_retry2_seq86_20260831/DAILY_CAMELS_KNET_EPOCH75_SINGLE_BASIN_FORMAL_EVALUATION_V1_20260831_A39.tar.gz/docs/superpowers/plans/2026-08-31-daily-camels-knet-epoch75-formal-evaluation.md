# Daily CAMELS Single-Basin KalmanNet Epoch-75 Formal Evaluation Implementation Plan

> **For Codex:** Execute this plan task by task with tests first. Preserve the dirty main worktree and all historical evidence; do not retrain, tune, overwrite prior outputs, modify the hourly route, or describe this single-basin result as a CAMELS-wide result.

**Goal:** Evaluate the sealed epoch-75 daily KalmanNet checkpoint for basin 09035800 exactly once on the reused 1989-10-01 through 1999-09-30 historical benchmark, use Nash-Sutcliffe efficiency as the primary metric, complete the frozen baseline comparisons and independent recomputation, and prepare—but do not start—the next multi-basin stage.

**Architecture:** Build an evaluation-only package from the exact A38 source snapshot. Verify the remote epoch-75 checkpoint before deserialization, rebuild the model from development-only inputs, then open the historical benchmark once and score KalmanNet plus the frozen UKF/open-loop/statistical baselines on identical lead-wise target masks after the existing 365-day warm-up. Persist raw aligned predictions, masks, metrics, access evidence, and an immutable manifest; a separate verifier independently recomputes every metric without importing the evaluator's scoring functions.

**Tech Stack:** Python 3.11, NumPy, PyTorch, pytest, JSON, NPZ, SHA-256 manifests, Bash, Slurm, one NVIDIA A800 GPU, and the `hpc-mailbox` Git branch.

---

## Frozen scientific boundary

- Basin: `09035800` only.
- Cadence: daily.
- Forecast leads: 1, 2, and 3 days.
- Evaluation period: `1989-10-01` through `1999-09-30`, explicitly labelled `reused_historical_benchmark`.
- The first 365 issue dates are filter warm-up and are excluded from scoring. The common issue window is index 365 inclusive through index 3649 exclusive, yielding 3,284 nominal issue dates for every lead before per-lead finite-value masking.
- Candidate: A38 epoch-75 checkpoint only. No epoch, seed, threshold, hyperparameter, state definition, feature scaling, or model selection may use evaluation values.
- Source checkpoint path: `/data1/home/sunyiq/kalmannet_daily_camels_knet_a38_a800_train1_20260828/runs/DAILY_CAMELS_KNET_FIXED_FULL_TRAINING_COVERAGE_EPOCH40_TO80_RESUME_STEP_MONOTONICITY_DIAGNOSTIC_V1_20260828_A38/checkpoints/epoch_075.pt`.
- Source checkpoint SHA-256: `7cc97138669531688dcd65d606d154330f260346c7c9c6e704cb1be5307a241b`.
- Source model-parameter SHA-256: `5a288a2ac6d2985253b37616d983d6dfaf0638b18169bba8fcd0439e5b922fce`.
- A38 terminal evidence archive SHA-256: `72feda409ea3490ccd9a289b1313c9beb276c1cc267a15111dc19e63d5815317`.
- New scientific experiment identity: `DAILY_CAMELS_KNET_EPOCH75_SINGLE_BASIN_FORMAL_EVALUATION_V1_20260831_A39`.
- Active output root: `/data1/home/sunyiq/kalmannet_daily_camels_knet_a39_formal_evaluation2_20260831`.
- Historical outputs and the A38 run directory are read-only.

### Evidence-preserving infrastructure retry

- The first execution identity `DAILY_CAMELS_KNET_EPOCH75_SINGLE_BASIN_FORMAL_EVALUATION_A39_A800_EVAL1_SEQ83` produced Slurm job 216551, which terminated `FAILED/20:0` before the numerical evaluator or independent verifier started.
- The terminal diagnostic receipt has SHA-256 `a3ef9061e9b9634c10792700407c077d4e34529f58dc6052a68eea5594e10a2a`. It records the exact error: the wrapper resolved `SLURM_SUBMIT_DIR` to `/data1/home/sunyiq/hpc_mailbox`, so `bundle_manifest.json` was sought in the mailbox root. Evaluation and verification output directories were absent, the runtime lock was absent, and no historical evaluation array was read.
- The only repair is to bind the sealed bundle root explicitly through `A39_BUNDLE_ROOT` and also invoke `sbatch` from that source directory. The retry uses execution identity `DAILY_CAMELS_KNET_EPOCH75_SINGLE_BASIN_FORMAL_EVALUATION_A39_A800_EVAL2_SEQ86`, a new submission token, and the new output root above. The scientific experiment, checkpoint, dates, data, systems, metrics, masks, thresholds, and evaluator are unchanged.

## Frozen systems and metrics

All systems use the same forcing, observed targets, common issue window, lead-specific target dates, and per-lead finite mask:

1. epoch-75 KalmanNet candidate;
2. strict zero-gain KalmanNet;
3. same-forcing HBV open loop;
4. frozen default-noise UKF;
5. frozen sampled-search UKF;
6. frozen backpropagation-selected UKF;
7. persistence;
8. second-order autoregression fitted only on the training period.

The existing TUKF06 historical NPZ supplies only the pinned dates, forcing, and target arrays. Its stored baseline predictions are not reused because their historical reset state differs from the A38 causal default state. KalmanNet, strict-zero KalmanNet, open loop, and all three UKF variants are regenerated from the same A38 causal default storage `[0, 0, 0.3 * field_capacity, 5, 10]`; persistence and autoregression are regenerated from the same target/training records.

Primary decision metric: population-variance Nash-Sutcliffe efficiency for each of leads 1, 2, and 3.

Frozen physical error metric: mean squared error in discharge units for each lead and the equal-lead mean. Do not add post-hoc Kling-Gupta efficiency, event subsets, flow-regime subsets, or other unregistered metrics.

The candidate capability gate passes only if every lead has finite Nash-Sutcliffe efficiency strictly greater than 0.6 and strictly exceeds the strict zero-gain/open-loop Nash-Sutcliffe efficiency on the identical mask. Comparison with the frozen backpropagation-selected UKF is reported lead by lead and as an equal-lead mean; it is not silently converted into a new checkpoint-selection rule. Multi-basin scale-up readiness is `GO` only if the capability gate passes and the candidate is not catastrophically worse than the selected UKF by more than 0.10 Nash-Sutcliffe efficiency at lead 1; otherwise it is `HOLD`. Technical success, scientific capability, comparative outcome, and convergence remain separate.

## Task 1: Freeze authorization, source evidence, and one-shot identity

**Files:**

- Create: `configs/daily_camels_knet_epoch75_formal_evaluation_a39.json`
- Create: `artifacts/daily_camels_knet_a39_formal_evaluation_bundle/A39_BUILD_20260831_01/experiment_registry.json`

1. Record the user's explicit 2026-08-31 authorization and its SHA-256 in the new registry.
2. Pin the A38 experiment, job 215801, checkpoint path/hash/epoch/parameter hash, terminal receipt/archive hashes, source/config hashes, data period, basin, leads, warm-up, systems, metrics, and gates.
3. Mark the evaluation period as a reused historical benchmark, not an untouched confirmation period.
4. Refuse an existing output root, existing execution identity, missing source evidence, wrong checkpoint, or any training-enabled configuration.

## Task 2: Add failing tests for the evaluation-only contract

**Files:**

- Create: `tests/test_daily_camels_knet_epoch75_formal_evaluation.py`

1. Test exact schema, identities, dates, basin, checkpoint, one-shot authorization, model architecture, systems, metrics, and gates.
2. Test that training, optimizer updates, checkpoint selection, tuning, multiple basins, another epoch, another seed, a shorter warm-up, or a different period are rejected before any evaluation array read.
3. Test common-mask construction, lead alignment, population Nash-Sutcliffe efficiency, physical-unit mean squared error, strict zero/open-loop equality, candidate capability classification, UKF comparison classification, and scale-up readiness on synthetic arrays.
4. Test atomic output refusal and manifest coverage.
5. Run the narrow test and record the expected failures before implementation.

## Task 3: Implement the one-shot evaluator

**Files:**

- Create: `scripts/run_daily_camels_knet_epoch75_formal_evaluation.py`

1. Verify all development-only source files, selection evidence, data-loader snapshot, prior table, basin list, A38 terminal evidence, and checkpoint hash before importing numerical frameworks or reading the historical period.
2. Load the development archive only to reconstruct the frozen architecture and feature scaling; load `epoch_075.pt` only after exact hash verification, require `completed_epoch=75`, restore `model_state`, and verify the model-parameter hash.
3. Open the pinned TUKF06 historical NPZ once, but read only its dates, forcing, and target members. Require the file SHA-256 `59c0acc1afce14da7fe479fc5cdb6c6c4d2b18758d076c32950c5f2b3cfd3596`, size 444,684 bytes, 3,652 strictly increasing daily dates, and exact endpoints. Do not reuse its stored baseline predictions.
4. Rebuild all eight systems without training or gradient updates. Require strict zero-gain KalmanNet to equal the same-forcing open loop exactly.
5. Apply the 365-day warm-up to issue dates, use common issues 365 through 3648 for every lead, then for each lead construct one finite mask across the target and all eight systems on its shifted target dates and compute the frozen Nash-Sutcliffe efficiency and physical-unit mean squared error.
6. Write raw dates, targets, masks, and eight aligned prediction arrays to a new NPZ; write the result summary, access ledger, resource evidence, and manifest atomically without overwrite.
7. Exit zero whenever the complete evaluation artifact is technically valid, including a scientific `HOLD`; record scientific status in JSON. Use nonzero exit only for technical, contract, or evidence failure so Slurm state is not confused with scientific outcome.

## Task 4: Implement an independent metric verifier

**Files:**

- Create: `scripts/verify_daily_camels_knet_epoch75_formal_evaluation.py`

1. Do not import the evaluator or its metric functions.
2. Verify experiment/checkpoint/config/input/output identities and the immutable manifest.
3. Read only the produced prediction archive, independently rebuild every common mask and recompute every metric and comparison.
4. Require exact counts and arrays and tight numerical agreement with the reported scalar metrics.
5. Verify no optimizer update, no new checkpoint, no training event, one authorized evaluation-period read, and no unregistered output.
6. Produce a separate immutable verification report and exit 0 for technical verification even when the scientific gate is `HOLD`.

## Task 5: Add resource-safe HPC packaging and entry

**Files:**

- Create: `hpc/daily_camels_knet_formal_evaluation/preflight.py`
- Create: `hpc/daily_camels_knet_formal_evaluation/submit_evaluation_gpu.slurm`
- Create: `scripts/build_daily_camels_knet_formal_evaluation_hpc_bundle.py`

1. Vendor only the exact required A38 source, development input, TUKF06 selection/config, new config/evaluator/verifier/tests, and manifests; do not package historical evaluation arrays. Bind the remote read-only TUKF06 historical NPZ by path, file hash, size, and allowed member names.
2. The standard preflight must run before importing NumPy or PyTorch and require the fixed experiment identity, one checkpoint at the remote pinned path, one basin, zero training commands, absent output directory, absent active lock, at least 2,800,353,280 bytes available host memory, and at least 4,584 MiB free GPU memory. The GPU gate is 1.2 times the measured 3,820 MiB A38 peak rather than the older 822 MiB training-smoke threshold.
3. The Slurm entry uses `hgpu8`, one node, one A800, excludes `ngu201`, enforces the actual host as `ngu202` or `ngu203`, records GPU/host resources, and runs evaluation followed by independent verification.
4. The mailbox controller creates a persistent `PREPARED` submission lock before `sbatch`. The Slurm job verifies the fixed token and atomically binds its own job identifier in that lock; it removes only the active runtime lock on exit, while the prepared and bound submission evidence remains permanent.

## Task 6: Verify locally without opening evaluation values

1. Run the new narrow tests and the relevant inherited model/runner tests with synthetic or development-only data.
2. Build twice in two new directories and require identical archive bytes, manifest bytes, member counts, and hashes.
3. Require exactly one external checkpoint reference, zero packaged historical-evaluation arrays, no symbolic links, and no training entry.
4. Run the offline preflight and independent static review before any mailbox submission.

## Task 7: Submit and monitor exactly one formal evaluation

1. Refresh `origin/hpc-mailbox` in a new clean clone and prove `kalmannet-daily-camels` is still at sequence 82 with a matching result.
2. Create one incremented sequence, unique execution identity, unique payload directory, and unique remote output root. Recheck remote uniqueness immediately before push.
3. Submit exactly one Slurm job from the prepared lock. Persist raw `sbatch` output and the job identifier; if the response is missing or malformed, never call `sbatch` again and recover only by read-only `squeue`/`sacct` lookup using the unique job name, token comment, partition, and work directory.
4. Monitor through read-only `squeue` and `sacct` queries; after terminal state, collect only the new evaluation evidence and accounting.

## Task 8: Report and prepare the next stage

Report separately:

- technical execution and independent-verification status;
- lead-1/2/3 Nash-Sutcliffe efficiency and physical-unit mean squared error;
- candidate-versus-zero/open-loop and candidate-versus-each UKF/statistical baseline;
- evaluation-period role, exact target counts, access count, checkpoint identity, resource peaks, and manifest integrity;
- scientific capability gate, comparative outcome, scale-up readiness, and convergence unknown;
- a multi-basin next-stage plan that freezes basin selection without using evaluation scores, uses fresh identities and outputs, and does not start until this evaluation is terminal and verified.

Do not claim a CAMELS-wide result from basin 09035800.
