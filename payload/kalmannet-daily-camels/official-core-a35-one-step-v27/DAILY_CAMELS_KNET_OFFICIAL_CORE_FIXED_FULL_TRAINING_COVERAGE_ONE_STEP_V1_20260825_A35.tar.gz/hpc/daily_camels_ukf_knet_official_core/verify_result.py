#!/usr/bin/env python3
"""Independently verify the A35 one-step official-KalmanNet result.

This verifier does not call the experiment entry or its scoring functions.  It
checks the immutable artifact chain, loads both epoch checkpoints, and
recomputes the 712-origin physical-unit MSE and Nash--Sutcliffe efficiency
directly from the saved prediction arrays.  No reserved evaluation member is
read or accepted.
"""

from __future__ import annotations

import argparse
import csv
from hashlib import sha256
import json
import math
import os
from pathlib import Path, PurePosixPath
from typing import Any, Mapping
import uuid

import numpy as np
import torch


EXPERIMENT_ID = (
    "DAILY_CAMELS_KNET_OFFICIAL_CORE_FIXED_FULL_TRAINING_COVERAGE_"
    "ONE_STEP_V1_20260825_A35"
)
BACKEND_ID = "pinned_upstream_kalmannet_tsp_828a2cf"
UPSTREAM_COMMIT = "828a2cf529bc84f43b37d543d916fe5858054457"
UPSTREAM_MEMBER = "third_party/KalmanNet_TSP_828a2cf/KNet/KalmanNet_nn.py"
UPSTREAM_SHA256 = "0cad52635723eaf8c4bbfc331a2d0614520363c71953f650794b4794d7aab33d"
ADAPTER_MEMBER = "src/global_hydrology/models/official_kalmannet_tsp_hbvlite.py"
ADAPTER_SHA256 = "6b14d927e339e6227cc9df3c1df4c232d4da8d9ba1f3708030b4c1de5e963053"
RUNNER_MEMBER = (
    "src/global_hydrology/experiments/"
    "daily_camels_ukf_knet_official_core_runner.py"
)
RUNNER_SHA256 = "dea40f02d1df23c57304aab22a9860e4658daf035193417ba518e1de52524105"
ENTRY_MEMBER = "scripts/run_daily_camels_ukf_knet_official_core.py"
ENTRY_SHA256 = "3bb5c747423c795e6eb4e0b12655027aee08c784f3306365c13d0ceeda46ea6e"
LEADS = (1, 2, 3)
EXPECTED_TARGETS_AFTER_WARMUP = 712
EXPECTED_TARGETS_WITHOUT_WARMUP = 728
EXPECTED_EVENTS = 7_650
EXPECTED_SEGMENTS = 25
EXPECTED_TARGETS_PER_SEGMENT_AND_LEAD = 102
ABSOLUTE_TOLERANCE = 1.0e-12
TRAINING_STATUSES = {
    "TRAINING_COMPLETE_GATE_PASS",
    "TRAINING_COMPLETE_GATE_FAIL",
}


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_json(path: Path) -> Any:
    with Path(path).open("r", encoding="utf-8") as handle:
        return json.load(handle)


def _mapping(value: Any, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{label} must be a JSON object")
    return value


def _json_equivalent(left: Any, right: Any) -> bool:
    """Compare checkpoint metadata after JSON's integer-key normalization."""

    options = {
        "allow_nan": False,
        "ensure_ascii": False,
        "sort_keys": True,
        "separators": (",", ":"),
    }
    return json.dumps(left, **options) == json.dumps(right, **options)


def _safe_relative(name: str) -> PurePosixPath:
    if "\\" in name:
        raise ValueError(f"run manifest member uses a backslash: {name}")
    relative = PurePosixPath(name)
    if relative.is_absolute() or not relative.parts or ".." in relative.parts:
        raise ValueError(f"unsafe run manifest member: {name}")
    lowered = tuple(part.lower() for part in relative.parts)
    if any("hourly" in part for part in lowered) or any(
        part == "evaluation" or part.startswith("evaluation_") for part in lowered
    ):
        raise PermissionError(f"forbidden run manifest member: {name}")
    return relative


def _atomic_json(path: Path, payload: Mapping[str, Any]) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        raise FileExistsError(f"refusing to replace verification report: {destination}")
    content = (
        json.dumps(
            payload,
            allow_nan=False,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        + "\n"
    ).encode("utf-8")
    pending = destination.with_name(destination.name + f".pending-{uuid.uuid4().hex}")
    try:
        with pending.open("xb") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        if destination.exists():
            raise FileExistsError(f"refusing to replace verification report: {destination}")
        os.replace(pending, destination)
    finally:
        if pending.exists():
            pending.unlink()


def _verify_bundle(bundle_root: Path, config_path: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    root = Path(bundle_root).resolve()
    manifest = _mapping(_read_json(root / "bundle_manifest.json"), "bundle manifest")
    config = _mapping(_read_json(config_path), "configuration")
    members = _mapping(manifest.get("member_sha256"), "bundle member hashes")
    sizes = _mapping(manifest.get("member_size"), "bundle member sizes")
    if (
        manifest.get("schema_version") != "daily_camels_ukf_knet_parity_hpc_bundle_v1"
        or manifest.get("experiment_id") != EXPERIMENT_ID
        or manifest.get("training_entry_member") != ENTRY_MEMBER
        or manifest.get("input_archive_count") != 1
        or manifest.get("reserved_data_member_count") != 0
        or manifest.get("array_members_materialized_during_build") != 0
        or set(members) != set(sizes)
    ):
        raise ValueError("A35 bundle identity or evaluation-isolation policy differs")
    actual_names: set[str] = set()
    for path in root.rglob("*"):
        if path.is_symlink():
            raise RuntimeError(f"bundle contains a symbolic link: {path}")
        if path.is_file():
            actual_names.add(path.relative_to(root).as_posix())
    if actual_names != set(members) | {"bundle_manifest.json"}:
        raise RuntimeError("extracted A35 bundle inventory differs")
    for name, expected in members.items():
        relative = _safe_relative(str(name))
        path = root.joinpath(*relative.parts)
        if path.stat().st_size != int(sizes[name]) or sha256_file(path) != str(expected):
            raise RuntimeError(f"A35 bundle member identity differs: {name}")
    active_member = str(manifest.get("active_config_member"))
    active_path = root.joinpath(*_safe_relative(active_member).parts)
    if Path(config_path).resolve() != active_path.resolve():
        raise ValueError("verifier configuration is not the bundled active configuration")
    if config.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("A35 configuration experiment identity differs")
    model = _mapping(config.get("model"), "model configuration")
    optimization = _mapping(config.get("optimization"), "optimization configuration")
    gate = _mapping(config.get("gate"), "gate configuration")
    sources = _mapping(config.get("source_sha256"), "declared source hashes")
    expected_sources = {
        UPSTREAM_MEMBER: UPSTREAM_SHA256,
        ADAPTER_MEMBER: ADAPTER_SHA256,
        RUNNER_MEMBER: RUNNER_SHA256,
        ENTRY_MEMBER: ENTRY_SHA256,
    }
    for name, expected in expected_sources.items():
        if sources.get(name) != expected or members.get(name) != expected:
            raise RuntimeError(f"A35 selected source identity differs: {name}")
    if (
        model.get("kalmannet_backend") != BACKEND_ID
        or model.get("selected_kalmannet_commit") != UPSTREAM_COMMIT
        or model.get("selected_kalmannet_source") != UPSTREAM_MEMBER
        or model.get("selected_kalmannet_adapter") != ADAPTER_MEMBER
        or model.get("numeric_dtype") != "float64"
        or model.get("gain_network_numeric_dtype") != "float32"
        or model.get("correction_scope") != "full_eighteen_dimensional_state_correction"
        or model.get("correction_cap_enabled") is not False
        or optimization.get("training_objective") != "physical_unit_multilead_mse"
        or optimization.get("checkpoint_objective") != "physical_unit_multilead_mse"
        or optimization.get("training_epochs") != 1
        or optimization.get("steps_per_epoch") != 1
        or optimization.get("segments_per_optimizer_step") != EXPECTED_SEGMENTS
        or optimization.get("lead_weights") != [1.0 / 3.0] * 3
        or gate.get("minimum_nse_exclusive") != 0.6
        or gate.get("require_post_epoch_zero_improvement") is not True
        or gate.get("require_zero_reserved_data_access") is not True
    ):
        raise ValueError("A35 frozen scientific contract differs")
    return dict(manifest), dict(config)


def _verify_run_manifest(run_dir: Path) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    root = Path(run_dir).resolve()
    if not root.is_dir() or root.is_symlink():
        raise FileNotFoundError("A35 run directory is absent or symbolic")
    manifest = _mapping(_read_json(root / "manifest.sha256.json"), "run manifest")
    completion = _mapping(_read_json(root / "completion.marker.json"), "completion marker")
    summary = _mapping(_read_json(root / "result_summary.json"), "result summary")
    files = _mapping(manifest.get("files"), "run file hashes")
    if (
        manifest.get("schema_version") != "daily_camels_ukf_knet_parity_manifest_v1"
        or manifest.get("experiment_id") != EXPERIMENT_ID
        or completion.get("schema_version")
        != "daily_camels_ukf_knet_parity_completion_v1"
        or completion.get("experiment_id") != EXPERIMENT_ID
        or completion.get("phase") != "train"
        or completion.get("status") not in TRAINING_STATUSES
        or summary.get("schema_version") != "daily_camels_ukf_knet_parity_result_v1"
        or summary.get("experiment_id") != EXPERIMENT_ID
        or summary.get("phase") != "train"
        or summary.get("status") != completion.get("status")
    ):
        raise ValueError("A35 completion, manifest, or result identity differs")
    actual_names: set[str] = set()
    for path in root.rglob("*"):
        if path.is_symlink():
            raise RuntimeError(f"A35 run contains a symbolic link: {path}")
        if path.is_file():
            actual_names.add(path.relative_to(root).as_posix())
    expected_names = set(files) | {"manifest.sha256.json", "completion.marker.json"}
    if actual_names != expected_names:
        missing = sorted(expected_names - actual_names)
        extra = sorted(actual_names - expected_names)
        raise RuntimeError(f"A35 run inventory differs; missing={missing}, extra={extra}")
    for name, expected in files.items():
        path = root.joinpath(*_safe_relative(str(name)).parts)
        if sha256_file(path) != str(expected):
            raise RuntimeError(f"A35 run artifact SHA-256 differs: {name}")
    if (
        completion.get("manifest_sha256") != sha256_file(root / "manifest.sha256.json")
        or completion.get("summary_sha256") != sha256_file(root / "result_summary.json")
        or completion.get("identity_sha256") != manifest.get("identity_sha256")
        or summary.get("identity_sha256") != manifest.get("identity_sha256")
    ):
        raise RuntimeError("A35 completion hash chain differs")
    return dict(manifest), dict(completion), dict(summary)


def _zero_evaluation_access(ledger: Mapping[str, Any], label: str) -> None:
    for key in (
        "evaluation_array_reads",
        "evaluation_metric_count",
        "evaluation_output_count",
        "evaluation_prediction_count",
    ):
        if ledger.get(key) != 0:
            raise PermissionError(f"{label} reserved evaluation access is nonzero: {key}")


def _load_prediction(path: Path) -> dict[int, dict[str, np.ndarray]]:
    result: dict[int, dict[str, np.ndarray]] = {}
    expected_keys: set[str] = set()
    with np.load(path, allow_pickle=False) as archive:
        for lead in LEADS:
            names = {
                "prediction": f"lead_{lead}_prediction",
                "target": f"lead_{lead}_target",
                "issue_index": f"lead_{lead}_issue_index",
                "target_index": f"lead_{lead}_target_index",
                "finite_mask": f"lead_{lead}_finite_mask",
            }
            expected_keys.update(names.values())
            result[lead] = {key: np.asarray(archive[name]) for key, name in names.items()}
        if set(archive.files) != expected_keys:
            raise ValueError(f"A35 epoch prediction array inventory differs: {path.name}")
    for lead, arrays in result.items():
        for name, array in arrays.items():
            if array.shape != (EXPECTED_TARGETS_AFTER_WARMUP,):
                raise ValueError(f"A35 lead-{lead} {name} shape differs")
        if arrays["prediction"].dtype != np.float64 or arrays["target"].dtype != np.float64:
            raise TypeError("A35 saved prediction and target precision differs")
        if arrays["issue_index"].dtype != np.int64 or arrays["target_index"].dtype != np.int64:
            raise TypeError("A35 saved forecast index precision differs")
        if arrays["finite_mask"].dtype != np.bool_:
            raise TypeError("A35 saved finite target mask precision differs")
        if not bool(np.isfinite(arrays["prediction"]).all()):
            raise FloatingPointError("A35 saved prediction contains a non-finite value")
        if not np.array_equal(
            arrays["target_index"], arrays["issue_index"] + lead
        ):
            raise ValueError("A35 saved future target indices are misaligned")
        if not np.array_equal(arrays["finite_mask"], np.isfinite(arrays["target"])):
            raise ValueError("A35 saved finite target mask differs from target values")
    return result


def _metrics(arrays: Mapping[str, np.ndarray]) -> tuple[float, float, int]:
    mask = arrays["finite_mask"]
    prediction = arrays["prediction"][mask]
    target = arrays["target"][mask]
    count = int(mask.sum())
    if count != EXPECTED_TARGETS_AFTER_WARMUP:
        raise ValueError("A35 finite target count after warmup differs")
    residual = prediction - target
    mse = float(np.mean(np.square(residual), dtype=np.float64))
    denominator = float(np.sum(np.square(target - np.mean(target)), dtype=np.float64))
    if not math.isfinite(mse) or denominator <= 0.0:
        raise FloatingPointError("A35 metric reconstruction is non-finite or degenerate")
    nse = float(1.0 - np.sum(np.square(residual), dtype=np.float64) / denominator)
    return mse, nse, count


def _close(actual: float, expected: float, label: str) -> None:
    if not math.isclose(float(actual), float(expected), rel_tol=0.0, abs_tol=ABSOLUTE_TOLERANCE):
        raise ValueError(f"{label} differs: actual={actual}, expected={expected}")


def _require_epoch_one_improvement(
    epoch_zero_objective: float,
    epoch_one_objective: float,
    minimum_improvement: float,
) -> None:
    values = (epoch_zero_objective, epoch_one_objective, minimum_improvement)
    if not all(math.isfinite(float(value)) for value in values) or minimum_improvement < 0.0:
        raise ValueError("A35 epoch objective improvement inputs are invalid")
    if not epoch_one_objective < epoch_zero_objective - minimum_improvement:
        raise ValueError("A35 epoch one did not improve beyond the epoch-zero minimum")


def _replay_method_arrays(
    replay_path: Path, method: str, lead: int
) -> dict[str, np.ndarray]:
    prefix = f"recovery__{method}__lead_{lead}__"
    with np.load(replay_path, allow_pickle=False) as archive:
        prediction = np.asarray(archive[prefix + "prediction"])
        target = np.asarray(archive[prefix + "target"])
        target_index = np.asarray(archive[prefix + "target_index"])
    if prediction.shape != (EXPECTED_TARGETS_AFTER_WARMUP,) or target.shape != prediction.shape:
        raise ValueError(f"A35 replay {method} lead-{lead} geometry differs")
    return {
        "prediction": prediction,
        "target": target,
        "issue_index": target_index - lead,
        "target_index": target_index,
        "finite_mask": np.isfinite(target),
    }


def _load_checkpoint(path: Path) -> dict[str, Any]:
    payload = torch.load(path, map_location="cpu", weights_only=False)
    if not isinstance(payload, dict):
        raise TypeError(f"A35 checkpoint root differs: {path.name}")
    return payload


def _verify_checkpoints(
    run_dir: Path,
    history: list[Mapping[str, Any]],
    identity_sha256: str,
    expected_best_epoch: int,
) -> dict[str, Any]:
    checkpoint_dir = Path(run_dir) / "checkpoints"
    epoch_paths = sorted(checkpoint_dir.glob("epoch_*.pt"))
    if [path.name for path in epoch_paths] != ["epoch_000.pt", "epoch_001.pt"]:
        raise ValueError("A35 must contain exactly epoch-zero and epoch-one immutable checkpoints")
    epoch_zero = _load_checkpoint(epoch_paths[0])
    epoch_one = _load_checkpoint(epoch_paths[1])
    for payload, epoch in ((epoch_zero, 0), (epoch_one, 1)):
        if (
            payload.get("schema_version") != "daily_camels_ukf_knet_parity_checkpoint_v1"
            or payload.get("completed_epoch") != epoch
            or payload.get("identity_sha256") != identity_sha256
            or not _json_equivalent(payload.get("history"), history[: epoch + 1])
        ):
            raise ValueError(f"A35 epoch-{epoch} checkpoint identity or history differs")
        _zero_evaluation_access(
            _mapping(payload.get("access_ledger"), f"epoch-{epoch} checkpoint ledger"),
            f"epoch-{epoch} checkpoint",
        )
    if (
        epoch_zero.get("optimizer_steps") != 0
        or epoch_zero.get("sampled_forecast_events") != 0
        or epoch_zero.get("previous_checkpoint_sha256") is not None
        or epoch_one.get("optimizer_steps") != 1
        or epoch_one.get("sampled_forecast_events") != EXPECTED_EVENTS
        or epoch_one.get("previous_checkpoint_sha256") != sha256_file(epoch_paths[0])
        or epoch_one.get("best_epoch") != expected_best_epoch
    ):
        raise ValueError("A35 checkpoint progress or chain differs")
    zero_state = _mapping(epoch_zero.get("model_state"), "epoch-zero model state")
    one_state = _mapping(epoch_one.get("model_state"), "epoch-one model state")
    if set(zero_state) != set(one_state):
        raise ValueError("A35 checkpoint model-state inventories differ")
    official_keys = {
        "GRU_Q.weight_ih_l0",
        "GRU_Sigma.weight_ih_l0",
        "GRU_S.weight_ih_l0",
        "FC2.2.weight",
    }
    if not official_keys.issubset(one_state) or any(name.startswith("LSTM_") for name in one_state):
        raise ValueError("A35 checkpoint does not contain the pinned upstream GRU core")
    for name in official_keys:
        tensor = one_state[name]
        if not torch.is_tensor(tensor) or tensor.dtype != torch.float32:
            raise TypeError(f"A35 official gain parameter precision differs: {name}")
    correction_mask = one_state.get("correction_mask")
    state_scale = one_state.get("state_feature_scale")
    cap = one_state.get("correction_cap_by_state_scale_units")
    if (
        not torch.is_tensor(correction_mask)
        or correction_mask.dtype != torch.float64
        or tuple(correction_mask.shape) != (1, 18)
        or not bool(torch.equal(correction_mask, torch.ones_like(correction_mask)))
        or not torch.is_tensor(state_scale)
        or state_scale.dtype != torch.float64
        or not torch.is_tensor(cap)
        or not bool(torch.isinf(cap).all())
    ):
        raise ValueError("A35 full-state float64 adaptation buffers or uncapped correction differ")
    changed_names = [
        name
        for name in official_keys
        if not torch.equal(zero_state[name], one_state[name])
    ]
    if not changed_names:
        raise ValueError("A35 official gain parameters did not change")
    return {
        "epoch_checkpoint_count": 2,
        "epoch_zero_checkpoint_sha256": sha256_file(epoch_paths[0]),
        "epoch_one_checkpoint_sha256": sha256_file(epoch_paths[1]),
        "official_state_key_count": len(one_state),
        "verified_changed_official_parameter_names": sorted(changed_names),
    }


def _verify_resources(
    summary: Mapping[str, Any], gpu_log: Path, cgroup_log: Path
) -> dict[str, Any]:
    peaks = _mapping(summary.get("resource_peaks"), "result resource peaks")
    host = peaks.get("host_peak_rss_bytes")
    allocated = peaks.get("graphics_peak_allocated_bytes")
    reserved = peaks.get("graphics_peak_reserved_bytes")
    if (
        isinstance(host, bool)
        or not isinstance(host, int)
        or host <= 0
        or isinstance(allocated, bool)
        or not isinstance(allocated, int)
        or allocated <= 0
        or isinstance(reserved, bool)
        or not isinstance(reserved, int)
        or reserved < allocated
    ):
        raise ValueError("A35 process resource peaks are absent or invalid")
    if not Path(gpu_log).is_file() or Path(gpu_log).is_symlink():
        raise FileNotFoundError("A35 external GPU resource log is absent or symbolic")
    with Path(gpu_log).open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.reader(handle))
    if len(rows) < 2 or len(rows[0]) < 7:
        raise ValueError("A35 external GPU resource log is empty or malformed")
    header = [cell.strip() for cell in rows[0]]
    expected_header = [
        "timestamp",
        "uuid",
        "name",
        "memory.total_MiB",
        "memory.used_MiB",
        "memory.free_MiB",
        "utilization.gpu_percent",
    ]
    if header[:7] != expected_header:
        raise ValueError("A35 external GPU resource header is unexpected")
    used_values: list[int] = []
    for row in rows[1:]:
        if len(row) < 7:
            raise ValueError("A35 external GPU resource row is malformed")
        used_values.append(int(row[4].strip()))
    if not used_values or max(used_values) <= 0:
        raise ValueError("A35 external GPU sampler never observed process memory use")
    if not Path(cgroup_log).is_file() or Path(cgroup_log).is_symlink():
        raise FileNotFoundError("A35 cgroup resource log is absent or symbolic")
    cgroup_text = Path(cgroup_log).read_text(encoding="utf-8")
    cgroup_fields: dict[str, str] = {}
    for line in cgroup_text.splitlines():
        if not line or "=" not in line:
            continue
        key, value = line.split("=", 1)
        if key in cgroup_fields:
            raise ValueError("A35 cgroup resource evidence contains a duplicate field")
        cgroup_fields[key] = value
    slurm_job_id = os.environ.get("SLURM_JOB_ID", "").strip()
    if not slurm_job_id or cgroup_fields.get("slurm_job_id") != slurm_job_id:
        raise ValueError("A35 cgroup resource evidence has the wrong Slurm job identity")
    try:
        ambient_cgroup_peak = int(cgroup_fields["current_memory_peak"])
    except (KeyError, TypeError, ValueError) as error:
        raise ValueError("A35 cgroup memory peak is absent or invalid") from error
    if ambient_cgroup_peak <= 0:
        raise ValueError("A35 cgroup memory peak is not positive")
    return {
        "host_peak_rss_bytes": host,
        "cuda_peak_allocated_bytes": allocated,
        "cuda_peak_reserved_bytes": reserved,
        "external_gpu_sample_count": len(used_values),
        "external_gpu_max_used_mib": max(used_values),
        "slurm_job_id": slurm_job_id,
        "ambient_cgroup_peak_bytes": ambient_cgroup_peak,
        "ambient_cgroup_scope": cgroup_fields.get("process_cgroup_relative"),
        "host_task_peak_authority": "result_summary_linux_proc_self_status_VmHWM",
        "gpu_resource_log_sha256": sha256_file(gpu_log),
        "cgroup_resource_log_sha256": sha256_file(cgroup_log),
    }


def verify(
    *,
    run_dir: Path,
    config_path: Path,
    bundle_root: Path,
    gpu_resource_log: Path,
    cgroup_resource_log: Path,
) -> dict[str, Any]:
    bundle_manifest, config = _verify_bundle(bundle_root, config_path)
    run_manifest, _completion, summary = _verify_run_manifest(run_dir)
    training = _mapping(summary.get("training"), "training summary")
    identity = _mapping(
        _read_json(Path(run_dir) / "experiment_identity.json"), "experiment identity"
    )
    configuration_sha256 = sha256_file(config_path)
    if (
        identity.get("experiment_id") != EXPERIMENT_ID
        or identity.get("phase") != "train"
        or identity.get("configuration_sha256") != configuration_sha256
        or run_manifest.get("identity_sha256")
        != sha256_file(Path(run_dir) / "experiment_identity.json")
    ):
        raise ValueError("A35 run identity or configuration hash differs")
    identity_sources = _mapping(identity.get("source_sha256"), "run identity sources")
    for name, expected in {
        UPSTREAM_MEMBER: UPSTREAM_SHA256,
        ADAPTER_MEMBER: ADAPTER_SHA256,
        RUNNER_MEMBER: RUNNER_SHA256,
        ENTRY_MEMBER: ENTRY_SHA256,
    }.items():
        if identity_sources.get(name) != expected:
            raise ValueError(f"A35 runtime source identity differs: {name}")

    history_raw = _read_json(Path(run_dir) / "epoch_history.json")
    if not isinstance(history_raw, list) or len(history_raw) != 2:
        raise ValueError("A35 epoch history must contain exactly epoch zero and epoch one")
    history = [_mapping(item, f"epoch history {index}") for index, item in enumerate(history_raw)]
    epoch_zero, epoch_one = history
    if (
        epoch_zero.get("epoch") != 0
        or epoch_one.get("epoch") != 1
        or epoch_zero.get("optimizer_steps") != 0
        or epoch_one.get("optimizer_steps") != 1
        or epoch_one.get("epoch_optimizer_step_count") != 1
        or epoch_one.get("sampled_forecast_events") != EXPECTED_EVENTS
        or epoch_one.get("finite_gradients") is not True
        or not isinstance(epoch_one.get("nonzero_gradient_parameter_names"), list)
        or not epoch_one["nonzero_gradient_parameter_names"]
        or epoch_one.get("nonzero_gradient_parameter_tensor_count")
        != len(epoch_one["nonzero_gradient_parameter_names"])
    ):
        raise ValueError("A35 epoch-zero/one training progress differs")
    gradient_names = [str(name) for name in epoch_one["nonzero_gradient_parameter_names"]]
    if not any(name.startswith("GRU_") for name in gradient_names) or any(
        name.startswith("LSTM_") for name in gradient_names
    ):
        raise ValueError("A35 gradients do not identify the pinned upstream GRU core")
    for entry in history:
        if entry.get("target_count_by_lead_after_warmup") != {
            str(lead): EXPECTED_TARGETS_AFTER_WARMUP for lead in LEADS
        } or entry.get("target_count_by_lead_without_warmup") != {
            str(lead): EXPECTED_TARGETS_WITHOUT_WARMUP for lead in LEADS
        }:
            raise ValueError("A35 checkpoint or score target count differs")
    zero_objective = float(epoch_zero["checkpoint_selection_objective_728_origins_without_warmup"])
    one_objective = float(epoch_one["checkpoint_selection_objective_728_origins_without_warmup"])
    minimum_improvement = float(config["optimization"]["minimum_post_zero_improvement"])
    if not all(
        math.isfinite(value)
        for value in (zero_objective, one_objective, minimum_improvement)
    ) or minimum_improvement < 0.0:
        raise ValueError("A35 epoch objective improvement inputs are invalid")
    expected_best_epoch = 1 if one_objective < zero_objective else 0
    if training.get("best_epoch") != expected_best_epoch:
        raise ValueError("A35 selected checkpoint does not match the lower objective")
    selected_objective = one_objective if expected_best_epoch == 1 else zero_objective
    objective_improvement = zero_objective - selected_objective
    objective_gate_passed = (
        expected_best_epoch > 0 and objective_improvement > minimum_improvement
    )
    if epoch_zero.get("parameter_sha256") == epoch_one.get("parameter_sha256"):
        raise ValueError("A35 recorded trainable-parameter hash did not change")

    step_replays = epoch_one.get("same_segment_step_replays")
    if not isinstance(step_replays, list) or len(step_replays) != 1:
        raise ValueError("A35 must contain exactly one same-batch post-step replay")
    step = _mapping(step_replays[0], "same-batch post-step replay")
    before = float(step["before_step_objective_physical_unit_multilead_mse"])
    after = float(step["after_step_objective_physical_unit_multilead_mse"])
    same_batch_improved = after < before
    if (
        step.get("optimizer_step") != 1
        or step.get("after_step_was_recomputed") is not True
        or step.get("after_step_recomputed_under_no_grad") is not True
        or step.get("identical_target_geometry_before_after") is not True
        or step.get("strict_objective_decrease") is not same_batch_improved
        or step.get("reserved_evaluation_values_used") != 0
        or step.get("target_count_by_lead_before_step")
        != {str(lead): 2_550 for lead in LEADS}
        or step.get("target_count_by_lead_after_step")
        != {str(lead): 2_550 for lead in LEADS}
    ):
        raise ValueError("A35 identical-batch post-step objective evidence differs")
    _close(
        float(step["objective_improvement_before_minus_after"]),
        before - after,
        "A35 same-batch objective improvement",
    )
    segments = step.get("training_segment_replays")
    geometry = step.get("target_geometry_by_training_segment")
    if not isinstance(segments, list) or len(segments) != EXPECTED_SEGMENTS:
        raise ValueError("A35 same-batch segment replay count differs")
    if not isinstance(geometry, list) or len(geometry) != EXPECTED_SEGMENTS:
        raise ValueError("A35 same-batch target geometry count differs")
    segment_strict_count = 0
    for index, segment in enumerate(segments):
        record = _mapping(segment, f"training segment replay {index}")
        segment_before = float(record["before_step_objective_physical_unit_multilead_mse"])
        segment_after = float(record["after_step_objective_physical_unit_multilead_mse"])
        declared = record.get("strict_objective_decrease")
        if (
            record.get("identical_target_geometry_before_after") is not True
            or record.get("after_step_recomputed_under_no_grad") is not True
            or record.get("reserved_evaluation_values_used") != 0
            or declared != (segment_after < segment_before)
        ):
            raise ValueError("A35 per-segment same-target replay evidence differs")
        segment_strict_count += int(bool(declared))
        lead_geometry = _mapping(geometry[index], f"training segment geometry {index}")
        for lead in LEADS:
            target_geometry = _mapping(
                lead_geometry.get(str(lead)), f"training segment {index} lead {lead}"
            )
            if target_geometry.get("finite_target_count") != EXPECTED_TARGETS_PER_SEGMENT_AND_LEAD:
                raise ValueError("A35 per-segment future target count differs")
    if segment_strict_count != step.get("training_segment_strict_objective_decrease_count"):
        raise ValueError("A35 per-segment strict-decrease count differs")

    epoch_arrays = {
        0: _load_prediction(Path(run_dir) / "predictions" / "epoch_000.npz"),
        1: _load_prediction(Path(run_dir) / "predictions" / "epoch_001.npz"),
    }
    replay_path = Path(run_dir) / "replay_predictions.npz"
    recomputed: dict[str, Any] = {"epoch_zero": {}, "epoch_one": {}, "zero_gain": {}, "ukf": {}}
    target_hashes: dict[str, str] = {}
    for lead in LEADS:
        zero_gain_arrays = _replay_method_arrays(replay_path, "zero_gain_knet", lead)
        ukf_arrays = _replay_method_arrays(replay_path, "ukf", lead)
        for epoch in (0, 1):
            arrays = epoch_arrays[epoch][lead]
            if not (
                np.array_equal(arrays["target"], zero_gain_arrays["target"], equal_nan=True)
                and np.array_equal(arrays["target"], ukf_arrays["target"], equal_nan=True)
                and np.array_equal(arrays["target_index"], zero_gain_arrays["target_index"])
                and np.array_equal(arrays["target_index"], ukf_arrays["target_index"])
            ):
                raise ValueError("A35 KalmanNet and frozen UKF target values or indices differ")
        for label, arrays in (
            ("epoch_zero", epoch_arrays[0][lead]),
            ("epoch_one", epoch_arrays[1][lead]),
            ("zero_gain", zero_gain_arrays),
            ("ukf", ukf_arrays),
        ):
            mse, nse, count = _metrics(arrays)
            recomputed[label][str(lead)] = {
                "mse": mse,
                "nse": nse,
                "target_count": count,
            }
        target_hashes[str(lead)] = sha256(
            epoch_arrays[1][lead]["target"].tobytes()
            + epoch_arrays[1][lead]["target_index"].tobytes()
            + epoch_arrays[1][lead]["finite_mask"].tobytes()
        ).hexdigest()
        _close(
            recomputed["epoch_zero"][str(lead)]["nse"],
            float(epoch_zero["nse_by_lead_after_warmup"][str(lead)]),
            f"A35 epoch-zero lead-{lead} NSE",
        )
        _close(
            recomputed["epoch_one"][str(lead)]["nse"],
            float(epoch_one["nse_by_lead_after_warmup"][str(lead)]),
            f"A35 epoch-one lead-{lead} NSE",
        )
    epoch_zero_gate_objective = math.fsum(
        recomputed["epoch_zero"][str(lead)]["mse"] for lead in LEADS
    ) / len(LEADS)
    epoch_one_gate_objective = math.fsum(
        recomputed["epoch_one"][str(lead)]["mse"] for lead in LEADS
    ) / len(LEADS)
    _close(
        epoch_zero_gate_objective,
        float(epoch_zero["gate_objective_712_origins_after_16_day_warmup"]),
        "A35 epoch-zero 712-origin objective",
    )
    _close(
        epoch_one_gate_objective,
        float(epoch_one["gate_objective_712_origins_after_16_day_warmup"]),
        "A35 epoch-one 712-origin objective",
    )

    selected_label = "epoch_one" if expected_best_epoch == 1 else "epoch_zero"
    nse_gate_passed = all(
        recomputed[selected_label][str(lead)]["nse"] > 0.6 for lead in LEADS
    )
    zero_gain_gate_passed = all(
        recomputed[selected_label][str(lead)]["mse"]
        < recomputed["zero_gain"][str(lead)]["mse"]
        for lead in LEADS
    )
    selected_parameter_changed = (
        epoch_zero.get("parameter_sha256")
        != history[expected_best_epoch].get("parameter_sha256")
    )
    expected_failed_gates: list[str] = []
    if not objective_gate_passed:
        expected_failed_gates.append("post_epoch_zero_improvement")
    if not nse_gate_passed:
        expected_failed_gates.append("nse_above_0.6_each_lead")
    if not zero_gain_gate_passed:
        expected_failed_gates.append("better_than_strict_zero_gain_each_lead")
    if not selected_parameter_changed:
        expected_failed_gates.append("parameter_hash_change")
    if not same_batch_improved:
        expected_failed_gates.append("same_segment_post_step_improvement")
    scientific_passed = not expected_failed_gates
    expected_training_status = (
        "TRAINING_COMPLETE_GATE_PASS"
        if scientific_passed
        else "TRAINING_COMPLETE_GATE_FAIL"
    )
    if (
        training.get("status") != expected_training_status
        or training.get("gate_passed") is not scientific_passed
        or training.get("failed_gates") != expected_failed_gates
        or summary.get("status") != expected_training_status
        or training.get("optimizer_steps") != 1
        or training.get("sampled_forecast_events") != EXPECTED_EVENTS
        or training.get("epoch_checkpoint_count") != 2
        or training.get("fixed_window_prediction_artifact_count") != 2
        or training.get("parameter_hash_changed") is not selected_parameter_changed
        or training.get("best_better_than_strict_zero_gain_each_lead")
        is not zero_gain_gate_passed
        or training.get("same_segment_every_optimizer_step_strictly_decreased")
        is not same_batch_improved
        or training.get("best_target_count_by_lead_without_warmup")
        != {str(lead): EXPECTED_TARGETS_WITHOUT_WARMUP for lead in LEADS}
        or training.get("best_target_count_by_lead_after_warmup")
        != {str(lead): EXPECTED_TARGETS_AFTER_WARMUP for lead in LEADS}
        or summary.get("scientific_claim_allowed") is not True
    ):
        raise ValueError("A35 training summary or performance gate differs")
    _close(
        float(training["epoch_zero_checkpoint_objective"]),
        zero_objective,
        "A35 summary epoch-zero objective",
    )
    _close(
        float(training["best_checkpoint_objective"]),
        selected_objective,
        "A35 summary selected objective",
    )
    for lead in LEADS:
        _close(
            float(training["best_nse_by_lead"][str(lead)]),
            recomputed[selected_label][str(lead)]["nse"],
            f"A35 summary lead-{lead} NSE",
        )
    _zero_evaluation_access(_mapping(summary.get("access_ledger"), "result ledger"), "result")
    _zero_evaluation_access(
        _mapping(training.get("access_ledger"), "training ledger"), "training"
    )
    checkpoint_evidence = _verify_checkpoints(
        run_dir,
        history,
        str(run_manifest["identity_sha256"]),
        expected_best_epoch,
    )
    resource_evidence = _verify_resources(
        summary, gpu_resource_log, cgroup_resource_log
    )
    return {
        "schema_version": "daily_camels_a35_independent_verification_v1",
        "status": (
            "A35_INDEPENDENT_VERIFICATION_PASS"
            if scientific_passed
            else "A35_INDEPENDENT_VERIFICATION_SCIENTIFIC_FAIL"
        ),
        "scientific_passed": scientific_passed,
        "failed_gates": expected_failed_gates,
        "selected_epoch": expected_best_epoch,
        "experiment_id": EXPERIMENT_ID,
        "backend": BACKEND_ID,
        "upstream_commit": UPSTREAM_COMMIT,
        "configuration_sha256": configuration_sha256,
        "bundle_manifest_sha256": sha256_file(Path(bundle_root) / "bundle_manifest.json"),
        "run_manifest_sha256": sha256_file(Path(run_dir) / "manifest.sha256.json"),
        "result_summary_sha256": sha256_file(Path(run_dir) / "result_summary.json"),
        "input_archive_count": bundle_manifest["input_archive_count"],
        "reserved_data_member_count": bundle_manifest["reserved_data_member_count"],
        "reserved_evaluation_access_count": 0,
        "epoch_count_including_zero": 2,
        "optimizer_steps": 1,
        "sampled_forecast_events": EXPECTED_EVENTS,
        "checkpoint_objective_728": {
            "epoch_zero": zero_objective,
            "epoch_one": one_objective,
            "improvement": zero_objective - one_objective,
            "verification_scope": "artifact_and_checkpoint_chain_not_recomputed_from_712_origin_arrays",
        },
        "recomputed_712_origin_metrics": recomputed,
        "target_value_index_mask_sha256_by_lead": target_hashes,
        "same_batch_before_step_objective": before,
        "same_batch_after_step_objective": after,
        "same_batch_improvement": before - after,
        "same_batch_strictly_improved": same_batch_improved,
        "per_segment_strict_decrease_count": segment_strict_count,
        "per_segment_count": EXPECTED_SEGMENTS,
        "checkpoint_evidence": checkpoint_evidence,
        "resource_evidence": resource_evidence,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Independently verify A35 one-step results")
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--bundle-root", type=Path, required=True)
    parser.add_argument("--gpu-resource-log", type=Path, required=True)
    parser.add_argument("--cgroup-resource-log", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    return parser


def main() -> int:
    arguments = build_parser().parse_args()
    try:
        report = verify(
            run_dir=arguments.run_dir,
            config_path=arguments.config,
            bundle_root=arguments.bundle_root,
            gpu_resource_log=arguments.gpu_resource_log,
            cgroup_resource_log=arguments.cgroup_resource_log,
        )
    except Exception as error:
        failure = {
            "schema_version": "daily_camels_a35_independent_verification_v1",
            "status": "A35_INDEPENDENT_VERIFICATION_FAIL",
            "error_type": type(error).__name__,
            "error": str(error),
        }
        try:
            _atomic_json(arguments.report, failure)
        except Exception:
            pass
        print(json.dumps(failure, sort_keys=True), flush=True)
        return 1
    _atomic_json(arguments.report, report)
    print(json.dumps(report, indent=2, sort_keys=True), flush=True)
    return 0 if report.get("scientific_passed") is True else 2


if __name__ == "__main__":
    raise SystemExit(main())
