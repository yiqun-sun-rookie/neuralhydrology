#!/usr/bin/env python3
"""Fail-closed A35 wrapper around the proven daily-parity HPC preflight."""

from __future__ import annotations

import argparse
import importlib.util
from pathlib import Path
import sys
from typing import Any, Mapping


ROOT = Path(__file__).resolve().parents[2]
BASE_PREFLIGHT = ROOT / "hpc" / "daily_camels_ukf_knet_parity" / "preflight.py"
_SPEC = importlib.util.spec_from_file_location(
    "daily_camels_ukf_knet_parity_preflight_a35_base", BASE_PREFLIGHT
)
if _SPEC is None or _SPEC.loader is None:  # pragma: no cover - platform guard
    raise ImportError(f"cannot load frozen parity preflight: {BASE_PREFLIGHT}")
_BASE = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_BASE)

EXPERIMENT_ID = (
    "DAILY_CAMELS_KNET_OFFICIAL_CORE_FIXED_FULL_TRAINING_COVERAGE_"
    "ONE_STEP_V1_20260825_A35"
)
OFFICIAL_BACKEND_ID = "pinned_upstream_kalmannet_tsp_828a2cf"
UPSTREAM_COMMIT = "828a2cf529bc84f43b37d543d916fe5858054457"
UPSTREAM_MEMBER = "third_party/KalmanNet_TSP_828a2cf/KNet/KalmanNet_nn.py"
UPSTREAM_SHA256 = "0cad52635723eaf8c4bbfc331a2d0614520363c71953f650794b4794d7aab33d"
ADAPTER_MEMBER = "src/global_hydrology/models/official_kalmannet_tsp_hbvlite.py"
ADAPTER_SHA256 = "6b14d927e339e6227cc9df3c1df4c232d4da8d9ba1f3708030b4c1de5e963053"
RUNNER_MEMBER = (
    "src/global_hydrology/experiments/"
    "daily_camels_ukf_knet_official_core_runner.py"
)
RUNNER_SHA256 = "dea40f02d1df23c57304aab22a9860e4658daf035193417ba518e1de52524105"
TRAINING_ENTRY_MEMBER = "scripts/run_daily_camels_ukf_knet_official_core.py"
TRAINING_ENTRY_SHA256 = "3bb5c747423c795e6eb4e0b12655027aee08c784f3306365c13d0ceeda46ea6e"
PREFLIGHT_MEMBER = "hpc/daily_camels_ukf_knet_official_core/preflight.py"
VERIFIER_MEMBER = "hpc/daily_camels_ukf_knet_official_core/verify_result.py"
SLURM_MEMBER = "hpc/daily_camels_ukf_knet_official_core/submit_one_step_gpu.slurm"
BUILDER_MEMBER = "scripts/build_daily_camels_ukf_knet_official_core_hpc_bundle.py"
HOST_ADMISSION_MIN_BYTES = 5_156_618_240
GPU_ADMISSION_MIN_FREE_MIB = 704


def assert_official_bundle(
    manifest: Mapping[str, Any], config: Mapping[str, Any]
) -> None:
    members = manifest.get("member_sha256")
    identity = manifest.get("official_core_identity")
    resources = manifest.get("resource_admission_provenance")
    model = config.get("model")
    optimization = config.get("optimization")
    sources = config.get("source_sha256")
    if not all(
        isinstance(value, Mapping)
        for value in (members, identity, resources, model, optimization, sources)
    ):
        raise RuntimeError("A35 official bundle identity sections are incomplete")
    assert isinstance(members, Mapping)
    assert isinstance(identity, Mapping)
    assert isinstance(resources, Mapping)
    assert isinstance(model, Mapping)
    assert isinstance(optimization, Mapping)
    assert isinstance(sources, Mapping)
    if config.get("experiment_id") != EXPERIMENT_ID:
        raise RuntimeError("A35 experiment identity differs")
    operational_members = {
        "training_entry_member": TRAINING_ENTRY_MEMBER,
        "preflight_member": PREFLIGHT_MEMBER,
        "verification_member": VERIFIER_MEMBER,
        "slurm_member": SLURM_MEMBER,
        "builder_member": BUILDER_MEMBER,
    }
    for field, expected in operational_members.items():
        if manifest.get(field) != expected or expected not in members:
            raise RuntimeError(f"A35 operational member differs: {field}")
    expected_identity = {
        "backend": OFFICIAL_BACKEND_ID,
        "upstream_commit": UPSTREAM_COMMIT,
        "upstream_source_member": UPSTREAM_MEMBER,
        "upstream_source_sha256": UPSTREAM_SHA256,
        "adapter_member": ADAPTER_MEMBER,
        "adapter_sha256": ADAPTER_SHA256,
        "runner_member": RUNNER_MEMBER,
        "runner_sha256": RUNNER_SHA256,
        "training_entry_sha256": TRAINING_ENTRY_SHA256,
    }
    if dict(identity) != expected_identity:
        raise RuntimeError("A35 official-core manifest identity differs")
    expected_hashes = {
        UPSTREAM_MEMBER: UPSTREAM_SHA256,
        ADAPTER_MEMBER: ADAPTER_SHA256,
        RUNNER_MEMBER: RUNNER_SHA256,
        TRAINING_ENTRY_MEMBER: TRAINING_ENTRY_SHA256,
    }
    for member, expected in expected_hashes.items():
        if members.get(member) != expected or sources.get(member) != expected:
            raise RuntimeError(f"A35 official-core source hash differs: {member}")
    if (
        model.get("kalmannet_backend") != OFFICIAL_BACKEND_ID
        or model.get("selected_kalmannet_commit") != UPSTREAM_COMMIT
        or model.get("selected_kalmannet_source") != UPSTREAM_MEMBER
        or model.get("selected_kalmannet_adapter") != ADAPTER_MEMBER
        or optimization.get("training_objective") != "physical_unit_multilead_mse"
        or optimization.get("training_epochs") != 1
        or optimization.get("steps_per_epoch") != 1
        or optimization.get("segments_per_optimizer_step") != 25
    ):
        raise RuntimeError("A35 official-core or one-step scientific contract differs")
    if (
        resources.get("reference_experiment")
        != "A32_same_pinned_upstream_official_kalmannet_architecture"
        or resources.get("reference_host_peak_rss_bytes") != 1_289_154_560
        or resources.get("reference_cuda_peak_reserved_bytes") != 184_549_376
        or resources.get("headroom_multiplier") != 4
        or resources.get("host_admission_min_bytes") != HOST_ADMISSION_MIN_BYTES
        or resources.get("gpu_admission_min_free_mib") != GPU_ADMISSION_MIN_FREE_MIB
        or resources.get("a35_must_record_fresh_peaks_before_longer_training") is not True
    ):
        raise RuntimeError("A35 measured-peak resource admission provenance differs")


_ORIGINAL_VERIFY_BUNDLE_ROOT = _BASE.verify_bundle_root


def verify_bundle_root(bundle_root: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    manifest, config = _ORIGINAL_VERIFY_BUNDLE_ROOT(bundle_root)
    assert_official_bundle(manifest, config)
    return manifest, config


def run_official_runtime_probe(bundle_root: Path) -> dict[str, Any]:
    """Import the selected core on the allocated GPU node without reading data."""

    root = Path(bundle_root).resolve()
    manifest, config = verify_bundle_root(root)
    sys.path.insert(0, str(root / "src"))
    sys.path.insert(0, str(root))
    import torch
    from global_hydrology.models import official_kalmannet_tsp_hbvlite as adapter

    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError("A35 runtime probe requires exactly one visible CUDA device")
    actual_adapter = Path(adapter.__file__).resolve()
    actual_upstream = Path(adapter._VENDORED_SOURCE).resolve()
    expected_adapter = (root / ADAPTER_MEMBER).resolve()
    expected_upstream = (root / UPSTREAM_MEMBER).resolve()
    if actual_adapter != expected_adapter or actual_upstream != expected_upstream:
        raise RuntimeError("A35 imported official sources outside the isolated bundle")
    if _BASE.sha256_file(actual_adapter) != ADAPTER_SHA256:
        raise RuntimeError("A35 imported adapter SHA-256 differs")
    if _BASE.sha256_file(actual_upstream) != UPSTREAM_SHA256:
        raise RuntimeError("A35 imported upstream KalmanNet SHA-256 differs")
    cls = adapter.OfficialKalmanNetTSPHBVAdapter
    mro = [f"{item.__module__}.{item.__qualname__}" for item in cls.__mro__]
    if adapter.OfficialKalmanNetNN not in cls.__mro__:
        raise RuntimeError("A35 adapter does not inherit the pinned upstream KalmanNet class")
    probe = torch.tensor([[2.0], [-3.0], [0.0]], dtype=torch.float32)
    normalized = cls.normalize_feature(probe).detach().cpu().reshape(-1).tolist()
    if normalized != [1.0, -1.0, 0.0]:
        raise RuntimeError("A35 scalar upstream Euclidean normalization differs")
    model = config["model"]
    return {
        "status": "A35_OFFICIAL_RUNTIME_PROBE_PASS",
        "experiment_id": EXPERIMENT_ID,
        "bundle_manifest_sha256": _BASE.sha256_file(root / "bundle_manifest.json"),
        "backend": model["kalmannet_backend"],
        "adapter_class": f"{cls.__module__}.{cls.__qualname__}",
        "method_resolution_order": mro,
        "adapter_file": str(actual_adapter),
        "adapter_sha256": ADAPTER_SHA256,
        "upstream_file": str(actual_upstream),
        "upstream_commit": UPSTREAM_COMMIT,
        "upstream_sha256": UPSTREAM_SHA256,
        "feature_normalization": model["selected_kalmannet_feature_normalization"],
        "scalar_normalization_probe": normalized,
        "torch_version": torch.__version__,
        "cuda_version": torch.version.cuda,
        "cuda_device_count": torch.cuda.device_count(),
        "cuda_device_name": torch.cuda.get_device_name(0),
        "input_archive_count": manifest["input_archive_count"],
        "reserved_data_member_count": manifest["reserved_data_member_count"],
        "arrays_materialized": 0,
    }


def runtime_probe_main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Probe the A35 official core on a GPU node")
    parser.add_argument("--bundle-root", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    arguments = parser.parse_args(argv)
    try:
        report = run_official_runtime_probe(arguments.bundle_root)
        _BASE._atomic_json(arguments.report, report)
    except Exception as error:
        failure = {
            "status": "A35_OFFICIAL_RUNTIME_PROBE_FAIL",
            "error_type": type(error).__name__,
            "error": str(error),
        }
        try:
            _BASE._atomic_json(arguments.report, failure)
        except Exception:
            pass
        print(failure, flush=True)
        return 1
    print(report, flush=True)
    return 0


def main() -> int:
    original = _BASE.verify_bundle_root
    _BASE.verify_bundle_root = verify_bundle_root
    try:
        return int(_BASE.main())
    finally:
        _BASE.verify_bundle_root = original


if __name__ == "__main__":
    if "--official-runtime-probe" in sys.argv:
        arguments = [item for item in sys.argv[1:] if item != "--official-runtime-probe"]
        raise SystemExit(runtime_probe_main(arguments))
    raise SystemExit(main())
