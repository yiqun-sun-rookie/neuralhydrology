"""Build the isolated A35 daily CAMELS official-KalmanNet HPC bundle.

The proven A16 builder owns the byte-level archive implementation.  This thin
builder extends only its explicit source inventory and enriches the inner
manifest with the official backend and operational entry identities.  Every
temporary module-level override is restored, including on failure.
"""

from __future__ import annotations

import argparse
import ast
from contextlib import contextmanager
import json
from pathlib import Path
from typing import Any, Iterator, Mapping

import scripts.build_daily_camels_ukf_knet_parity_hpc_bundle as _base


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = (
    ROOT
    / "configs"
    / "daily_camels_knet_official_core_fixed_full_training_coverage_one_step_a35.json"
)
EXPERIMENT_ID = (
    "DAILY_CAMELS_KNET_OFFICIAL_CORE_FIXED_FULL_TRAINING_COVERAGE_"
    "ONE_STEP_V1_20260825_A35"
)
OFFICIAL_BACKEND_ID = "pinned_upstream_kalmannet_tsp_828a2cf"
UPSTREAM_COMMIT = "828a2cf529bc84f43b37d543d916fe5858054457"
UPSTREAM_MEMBER = "third_party/KalmanNet_TSP_828a2cf/KNet/KalmanNet_nn.py"
UPSTREAM_SHA256 = "0cad52635723eaf8c4bbfc331a2d0614520363c71953f650794b4794d7aab33d"
OFFICIAL_ADAPTER_MEMBER = (
    "src/global_hydrology/models/official_kalmannet_tsp_hbvlite.py"
)
OFFICIAL_ADAPTER_SHA256 = (
    "6b14d927e339e6227cc9df3c1df4c232d4da8d9ba1f3708030b4c1de5e963053"
)
OFFICIAL_RUNNER_MEMBER = (
    "src/global_hydrology/experiments/"
    "daily_camels_ukf_knet_official_core_runner.py"
)
OFFICIAL_RUNNER_SHA256 = (
    "dea40f02d1df23c57304aab22a9860e4658daf035193417ba518e1de52524105"
)
TRAINING_ENTRY_MEMBER = "scripts/run_daily_camels_ukf_knet_official_core.py"
TRAINING_ENTRY_SHA256 = (
    "3bb5c747423c795e6eb4e0b12655027aee08c784f3306365c13d0ceeda46ea6e"
)
BUILDER_MEMBER = "scripts/build_daily_camels_ukf_knet_official_core_hpc_bundle.py"
PREFLIGHT_MEMBER = "hpc/daily_camels_ukf_knet_official_core/preflight.py"
SLURM_MEMBER = (
    "hpc/daily_camels_ukf_knet_official_core/submit_one_step_gpu.slurm"
)
VERIFIER_MEMBER = "hpc/daily_camels_ukf_knet_official_core/verify_result.py"
HPC_TEST_MEMBER = "tests/test_daily_camels_ukf_knet_official_core_hpc.py"

# Initial admission is based on the measured A32 run of the same pinned
# upstream architecture, not on a UKF process and not on the A16 native core.
A32_MEASURED_HOST_PEAK_RSS_BYTES = 1_289_154_560
A32_MEASURED_CUDA_PEAK_RESERVED_BYTES = 184_549_376
ADMISSION_MULTIPLIER = 4
HOST_ADMISSION_MIN_BYTES = (
    A32_MEASURED_HOST_PEAK_RSS_BYTES * ADMISSION_MULTIPLIER
)
GPU_ADMISSION_MIN_FREE_MIB = (
    A32_MEASURED_CUDA_PEAK_RESERVED_BYTES * ADMISSION_MULTIPLIER // (1024 * 1024)
)

ADDITIONAL_SOURCE_MEMBER_PATHS: dict[str, str] = {
    UPSTREAM_MEMBER: UPSTREAM_MEMBER,
    OFFICIAL_ADAPTER_MEMBER: OFFICIAL_ADAPTER_MEMBER,
    OFFICIAL_RUNNER_MEMBER: OFFICIAL_RUNNER_MEMBER,
    TRAINING_ENTRY_MEMBER: TRAINING_ENTRY_MEMBER,
    BUILDER_MEMBER: BUILDER_MEMBER,
    PREFLIGHT_MEMBER: PREFLIGHT_MEMBER,
    SLURM_MEMBER: SLURM_MEMBER,
    VERIFIER_MEMBER: VERIFIER_MEMBER,
    HPC_TEST_MEMBER: HPC_TEST_MEMBER,
    "tests/test_daily_camels_ukf_knet_official_core_runner.py": (
        "tests/test_daily_camels_ukf_knet_official_core_runner.py"
    ),
    "tests/test_official_kalmannet_tsp_hbvlite.py": (
        "tests/test_official_kalmannet_tsp_hbvlite.py"
    ),
}


def _read_json(path: Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return payload


def _validate_official_config(config_path: Path) -> None:
    config = _read_json(config_path)
    model = config.get("model")
    optimization = config.get("optimization")
    policy = config.get("epoch_zero_reproducibility_policy")
    sources = config.get("source_sha256")
    if not all(isinstance(value, Mapping) for value in (model, optimization, policy, sources)):
        raise ValueError("A35 official-core configuration sections are incomplete")
    assert isinstance(model, Mapping)
    assert isinstance(optimization, Mapping)
    assert isinstance(policy, Mapping)
    assert isinstance(sources, Mapping)
    required = {
        "experiment_id": EXPERIMENT_ID,
        "schema_version": "daily_camels_ukf_knet_parity_v1",
        "basin_id": "09035800",
    }
    for key, expected in required.items():
        if config.get(key) != expected:
            raise ValueError(f"A35 official-core configuration differs: {key}")
    required_model = {
        "kalmannet_backend": OFFICIAL_BACKEND_ID,
        "selected_kalmannet_source": UPSTREAM_MEMBER,
        "selected_kalmannet_commit": UPSTREAM_COMMIT,
        "selected_kalmannet_sha256": UPSTREAM_SHA256,
        "selected_kalmannet_adapter": OFFICIAL_ADAPTER_MEMBER,
        "selected_kalmannet_adapter_sha256": OFFICIAL_ADAPTER_SHA256,
        "selected_kalmannet_feature_normalization": (
            "pinned_upstream_euclidean_l2_after_frozen_a16_training_scale"
        ),
    }
    for key, expected in required_model.items():
        if model.get(key) != expected:
            raise ValueError(f"A35 official-core model identity differs: {key}")
    if (
        optimization.get("training_objective") != "physical_unit_multilead_mse"
        or optimization.get("training_epochs") != 1
        or optimization.get("steps_per_epoch") != 1
        or optimization.get("segments_per_optimizer_step") != 25
        or optimization.get("lead_weights") != [1.0 / 3.0] * 3
    ):
        raise ValueError("A35 one-step equal-lead physical loss contract differs")
    if policy.get("predeclared_anchor") is not False or config.get(
        "epoch_zero_reproducibility"
    ) is not None:
        raise ValueError("A35 must measure a new official-core epoch zero")
    required_sources = {
        UPSTREAM_MEMBER: UPSTREAM_SHA256,
        OFFICIAL_ADAPTER_MEMBER: OFFICIAL_ADAPTER_SHA256,
        OFFICIAL_RUNNER_MEMBER: OFFICIAL_RUNNER_SHA256,
        TRAINING_ENTRY_MEMBER: TRAINING_ENTRY_SHA256,
    }
    for member, expected in required_sources.items():
        if sources.get(member) != expected:
            raise ValueError(f"A35 declared source identity differs: {member}")
        actual = _base.sha256_file(ROOT / member)
        if actual != expected:
            raise RuntimeError(
                f"A35 source SHA-256 mismatch for {member}: expected {expected}, got {actual}"
            )


def _official_payloads(
    source_paths: Mapping[str, Path],
    *,
    active_config_member: str,
    exact_config_member: str,
    experiment_id: str,
    initialization_mode: str,
) -> tuple[dict[str, bytes], dict[str, Any]]:
    payloads, manifest = _ORIGINAL_PAYLOADS(
        source_paths,
        active_config_member=active_config_member,
        exact_config_member=exact_config_member,
        experiment_id=experiment_id,
        initialization_mode=initialization_mode,
    )
    if experiment_id != EXPERIMENT_ID:
        raise ValueError("official-core builder accepts only the frozen A35 experiment")
    manifest.update(
        {
            "training_entry_member": TRAINING_ENTRY_MEMBER,
            "preflight_member": PREFLIGHT_MEMBER,
            "verification_member": VERIFIER_MEMBER,
            "slurm_member": SLURM_MEMBER,
            "builder_member": BUILDER_MEMBER,
            "official_core_identity": {
                "backend": OFFICIAL_BACKEND_ID,
                "upstream_commit": UPSTREAM_COMMIT,
                "upstream_source_member": UPSTREAM_MEMBER,
                "upstream_source_sha256": UPSTREAM_SHA256,
                "adapter_member": OFFICIAL_ADAPTER_MEMBER,
                "adapter_sha256": OFFICIAL_ADAPTER_SHA256,
                "runner_member": OFFICIAL_RUNNER_MEMBER,
                "runner_sha256": OFFICIAL_RUNNER_SHA256,
                "training_entry_sha256": TRAINING_ENTRY_SHA256,
            },
            "resource_admission_provenance": {
                "reference_experiment": "A32_same_pinned_upstream_official_kalmannet_architecture",
                "reference_host_peak_rss_bytes": A32_MEASURED_HOST_PEAK_RSS_BYTES,
                "reference_cuda_peak_reserved_bytes": A32_MEASURED_CUDA_PEAK_RESERVED_BYTES,
                "headroom_multiplier": ADMISSION_MULTIPLIER,
                "host_admission_min_bytes": HOST_ADMISSION_MIN_BYTES,
                "gpu_admission_min_free_mib": GPU_ADMISSION_MIN_FREE_MIB,
                "a35_must_record_fresh_peaks_before_longer_training": True,
            },
        }
    )
    return payloads, manifest


_ORIGINAL_PAYLOADS = _base._payloads


def _official_entry_integration_hashes(
    source_paths: Mapping[str, Path],
) -> dict[str, str]:
    """Verify the runtime hook identities declared by the official entry.

    The frozen base entry still contains A16's older persistence-module hash.
    The official wrapper intentionally overrides that value to the current
    byte stream inside ``try/finally``.  Therefore the A35 bundle must bind the
    wrapper's integration constants instead of calling the base parser.
    """

    tree = ast.parse(Path(source_paths[TRAINING_ENTRY_MEMBER]).read_text(encoding="utf-8"))
    literals: dict[str, str] = {}
    names = {
        "OFFICIAL_RUNNER_RELATIVE",
        "OFFICIAL_RUNNER_SHA256",
        "UPSTREAM_SOURCE_RELATIVE",
        "UPSTREAM_SOURCE_SHA256",
        "OFFICIAL_ADAPTER_RELATIVE",
        "OFFICIAL_ADAPTER_SHA256",
        "FROZEN_RUNNER_RELATIVE",
        "FROZEN_RUNNER_SHA256",
        "CURRENT_IO_RELATIVE",
        "CURRENT_IO_SHA256",
    }
    for node in tree.body:
        if (
            isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id in names
        ):
            value = ast.literal_eval(node.value)
            if not isinstance(value, str):
                raise ValueError(f"official entry integration constant is not text: {node.targets[0].id}")
            literals[node.targets[0].id] = value
    if set(literals) != names:
        raise ValueError("official entry integration constants are incomplete")
    pairs = (
        ("OFFICIAL_RUNNER_RELATIVE", "OFFICIAL_RUNNER_SHA256"),
        ("UPSTREAM_SOURCE_RELATIVE", "UPSTREAM_SOURCE_SHA256"),
        ("OFFICIAL_ADAPTER_RELATIVE", "OFFICIAL_ADAPTER_SHA256"),
        ("FROZEN_RUNNER_RELATIVE", "FROZEN_RUNNER_SHA256"),
        ("CURRENT_IO_RELATIVE", "CURRENT_IO_SHA256"),
    )
    result: dict[str, str] = {}
    for path_constant, hash_constant in pairs:
        member = literals[path_constant]
        expected = literals[hash_constant]
        _base._validate_digest(expected, hash_constant)
        if member not in source_paths:
            raise ValueError(f"official entry integration source is absent: {member}")
        actual = _base.sha256_file(Path(source_paths[member]))
        if actual != expected:
            raise RuntimeError(
                f"official entry integration SHA-256 mismatch for {member}: "
                f"expected {expected}, got {actual}"
            )
        result[member] = expected
    return dict(sorted(result.items()))


_ORIGINAL_ENTRY_INTEGRATION_HASHES = _base._entry_integration_hashes
OFFICIAL_ENTRY_INTEGRATION_HASH_CONSTANTS = {
    OFFICIAL_RUNNER_MEMBER: "OFFICIAL_RUNNER_SHA256",
    UPSTREAM_MEMBER: "UPSTREAM_SOURCE_SHA256",
    OFFICIAL_ADAPTER_MEMBER: "OFFICIAL_ADAPTER_SHA256",
    "src/global_hydrology/experiments/daily_camels_ukf_knet_parity_runner.py": (
        "FROZEN_RUNNER_SHA256"
    ),
    "src/global_hydrology/experiments/daily_camels_native_knet_io.py": (
        "CURRENT_IO_SHA256"
    ),
}


@contextmanager
def _official_builder_contract() -> Iterator[None]:
    original_sources = _base.FIXED_SOURCE_MEMBER_PATHS
    original_payloads = _base._payloads
    original_entry_integration_hashes = _base._entry_integration_hashes
    original_entry_integration_constants = _base.ENTRY_INTEGRATION_HASH_CONSTANTS
    extended = dict(original_sources)
    overlap = set(extended).intersection(ADDITIONAL_SOURCE_MEMBER_PATHS)
    if overlap:
        raise RuntimeError(f"official-core bundle member collision: {sorted(overlap)}")
    extended.update(ADDITIONAL_SOURCE_MEMBER_PATHS)
    _base.FIXED_SOURCE_MEMBER_PATHS = extended
    _base._payloads = _official_payloads
    _base._entry_integration_hashes = _official_entry_integration_hashes
    _base.ENTRY_INTEGRATION_HASH_CONSTANTS = OFFICIAL_ENTRY_INTEGRATION_HASH_CONSTANTS
    try:
        yield
    finally:
        _base.FIXED_SOURCE_MEMBER_PATHS = original_sources
        _base._payloads = original_payloads
        _base._entry_integration_hashes = original_entry_integration_hashes
        _base.ENTRY_INTEGRATION_HASH_CONSTANTS = original_entry_integration_constants


def inspect_archive(archive_path: Path) -> _base.ArchiveInspection:
    with _official_builder_contract():
        return _base.inspect_archive(archive_path)


def build_bundle(
    destination: Path,
    *,
    config_path: Path = DEFAULT_CONFIG,
    root: Path = ROOT,
) -> _base.BundleManifest:
    resolved_config = Path(config_path).resolve()
    _validate_official_config(resolved_config)
    with _official_builder_contract():
        return _base.build_bundle(
            destination,
            config_path=resolved_config,
            exact_config_path=_base.DEFAULT_EXACT_CONFIG,
            root=root,
        )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Build the deterministic A35 daily official-KalmanNet HPC bundle."
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    return parser


def main() -> int:
    arguments = build_parser().parse_args()
    result = build_bundle(arguments.output_dir, config_path=arguments.config)
    print(
        json.dumps(
            {
                "status": "A35_OFFICIAL_CORE_BUNDLE_READY",
                "experiment_id": result.experiment_id,
                "archive_path": str(result.archive_path),
                "archive_sha256": result.archive_sha256,
                "archive_size": result.archive_size,
                "manifest_path": str(result.manifest_path),
                "member_count": len(result.member_sha256),
                "array_members_materialized": 0,
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
