"""Fail-closed daily parity entry that changes only the KalmanNet gain core."""

from __future__ import annotations

import importlib
from pathlib import Path
import sys
from typing import Any, Mapping, Sequence

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import scripts.run_daily_camels_ukf_knet_parity as _entry


OFFICIAL_RUNNER_RELATIVE = (
    "src/global_hydrology/experiments/"
    "daily_camels_ukf_knet_official_core_runner.py"
)
OFFICIAL_RUNNER_SHA256 = (
    "dea40f02d1df23c57304aab22a9860e4658daf035193417ba518e1de52524105"
)
OFFICIAL_BACKEND_ID = "pinned_upstream_kalmannet_tsp_828a2cf"
UPSTREAM_COMMIT = "828a2cf529bc84f43b37d543d916fe5858054457"
UPSTREAM_SOURCE_RELATIVE = (
    "third_party/KalmanNet_TSP_828a2cf/KNet/KalmanNet_nn.py"
)
UPSTREAM_SOURCE_SHA256 = (
    "0cad52635723eaf8c4bbfc331a2d0614520363c71953f650794b4794d7aab33d"
)
OFFICIAL_ADAPTER_RELATIVE = (
    "src/global_hydrology/models/official_kalmannet_tsp_hbvlite.py"
)
OFFICIAL_ADAPTER_SHA256 = (
    "6b14d927e339e6227cc9df3c1df4c232d4da8d9ba1f3708030b4c1de5e963053"
)
FROZEN_RUNNER_RELATIVE = (
    "src/global_hydrology/experiments/daily_camels_ukf_knet_parity_runner.py"
)
FROZEN_RUNNER_SHA256 = (
    "2fd983a4af52ee02fd677e8ee51894d8208b836d6e9759b3ff2ac3a82c89ea69"
)
CURRENT_IO_RELATIVE = (
    "src/global_hydrology/experiments/daily_camels_native_knet_io.py"
)
CURRENT_IO_SHA256 = (
    "2db6c61276b4d2900321e58d04d639fecaf3957d557c4c5b5b4121fd01c3e918"
)


def _assert_official_contract(preflight: Any) -> None:
    configuration: Mapping[str, Any] = preflight.configuration
    model = configuration.get("model")
    sources = configuration.get("source_sha256")
    if not isinstance(model, Mapping) or not isinstance(sources, Mapping):
        raise TypeError("official-core configuration requires model and source_sha256 objects")
    if model.get("kalmannet_backend") != OFFICIAL_BACKEND_ID:
        raise ValueError("model.kalmannet_backend does not select the pinned upstream core")
    # ``official_knet_source`` and ``full_state_adapter`` are legacy field names
    # byte-frozen by the A16 parity contract.  They continue to identify the
    # repository-native baseline dependencies.  The fields below identify the
    # backend actually selected by this one-factor comparison.
    if model.get("selected_kalmannet_source") != UPSTREAM_SOURCE_RELATIVE:
        raise ValueError("model.selected_kalmannet_source differs")
    if model.get("selected_kalmannet_commit") != UPSTREAM_COMMIT:
        raise ValueError("model.selected_kalmannet_commit differs")
    if model.get("selected_kalmannet_sha256") != UPSTREAM_SOURCE_SHA256:
        raise ValueError("model.selected_kalmannet_sha256 differs")
    if model.get("selected_kalmannet_adapter") != OFFICIAL_ADAPTER_RELATIVE:
        raise ValueError("model.selected_kalmannet_adapter differs")
    if model.get("selected_kalmannet_adapter_sha256") != OFFICIAL_ADAPTER_SHA256:
        raise ValueError("model.selected_kalmannet_adapter_sha256 differs")
    required_model = {
        "numeric_dtype": "float64",
        "gain_network_numeric_dtype": "float32",
        "hidden_dimension": 24,
        "input_multiplier": 10,
        "output_multiplier": 10,
        "feature_scaling": "training_difference_root_mean_square",
        "feature_scale_floor": 0.1,
        "normalized_feature_guard": 10.0,
        "legacy_normalized_feature_guard_record_only": True,
        "legacy_hidden_dimension_record_only": True,
        "selected_kalmannet_feature_normalization": (
            "pinned_upstream_euclidean_l2_after_frozen_a16_training_scale"
        ),
        "selected_kalmannet_recurrent_geometry": (
            "pinned_upstream_dimensions_not_legacy_hidden_dimension_24"
        ),
        "correction_scope": "full_eighteen_dimensional_state_correction",
        "correction_cap_enabled": False,
    }
    for name, expected in required_model.items():
        if model.get(name) != expected:
            raise ValueError(f"official-core A16 comparison differs: model.{name}")
    required_sources = {
        OFFICIAL_RUNNER_RELATIVE: OFFICIAL_RUNNER_SHA256,
        FROZEN_RUNNER_RELATIVE: FROZEN_RUNNER_SHA256,
        CURRENT_IO_RELATIVE: CURRENT_IO_SHA256,
        UPSTREAM_SOURCE_RELATIVE: UPSTREAM_SOURCE_SHA256,
        OFFICIAL_ADAPTER_RELATIVE: OFFICIAL_ADAPTER_SHA256,
    }
    for relative, expected in required_sources.items():
        if not isinstance(expected, str) or len(expected) != 64:
            raise ValueError(f"official-core source hash is missing: {relative}")
        if sources.get(relative) != expected:
            raise ValueError(f"official-core source hash differs: {relative}")
    epoch_zero_policy = configuration.get("epoch_zero_reproducibility_policy")
    expected_epoch_zero_policy = {
        "predeclared_anchor": False,
        "reason": "first_execution_of_a_different_pinned_upstream_core",
        "run_must_record_actual_epoch_zero": True,
        "require_post_epoch_zero_improvement": True,
    }
    if epoch_zero_policy != expected_epoch_zero_policy:
        raise ValueError("official-core epoch-zero reproducibility policy differs")
    if configuration.get("epoch_zero_reproducibility") is not None:
        raise ValueError("official-core first run cannot inherit a native-core epoch-zero anchor")


_original_standard_preflight = _entry.standard_preflight
_original_load_numerical_runtime = _entry._load_numerical_runtime


def standard_preflight(
    config_path: str | Path,
    run_parent: str | Path,
    *,
    phase: str,
) -> Any:
    # The current persistence module differs from A16 by one additional key in
    # an unrelated completion-marker validator.  This parity entry only calls
    # its owner-lock and atomic-write functions.  Pin the current byte stream
    # explicitly without editing or rolling back the shared module.
    original_runner_relative = _entry.RUNNER_RELATIVE
    original_runner_sha256 = _entry.EXPECTED_RUNNER_SHA256
    original_io_sha256 = _entry.EXPECTED_IO_SHA256
    _entry.RUNNER_RELATIVE = OFFICIAL_RUNNER_RELATIVE
    _entry.EXPECTED_RUNNER_SHA256 = OFFICIAL_RUNNER_SHA256
    _entry.EXPECTED_IO_SHA256 = CURRENT_IO_SHA256
    try:
        result = _original_standard_preflight(
            config_path,
            run_parent,
            phase=phase,
        )
    finally:
        _entry.RUNNER_RELATIVE = original_runner_relative
        _entry.EXPECTED_RUNNER_SHA256 = original_runner_sha256
        _entry.EXPECTED_IO_SHA256 = original_io_sha256
    _assert_official_contract(result)
    return result


def _load_official_numerical_runtime(preflight: Any) -> tuple[Any, Any, Any]:
    numpy_module, torch_module, _frozen_runner = _original_load_numerical_runtime(
        preflight
    )
    official_runner = importlib.import_module(
        "global_hydrology.experiments.daily_camels_ukf_knet_official_core_runner"
    )
    if getattr(official_runner, "BACKEND_ID", None) != OFFICIAL_BACKEND_ID:
        raise RuntimeError("the numerical runtime did not load the pinned official backend")
    return numpy_module, torch_module, official_runner


def main(argv: Sequence[str] | None = None) -> int:
    original_runner_relative = _entry.RUNNER_RELATIVE
    original_runner_sha256 = _entry.EXPECTED_RUNNER_SHA256
    original_preflight = _entry.standard_preflight
    original_numerical_loader = _entry._load_numerical_runtime
    _entry.RUNNER_RELATIVE = OFFICIAL_RUNNER_RELATIVE
    _entry.EXPECTED_RUNNER_SHA256 = OFFICIAL_RUNNER_SHA256
    _entry.standard_preflight = standard_preflight
    _entry._load_numerical_runtime = _load_official_numerical_runtime
    try:
        return _entry.main(argv)
    finally:
        _entry.RUNNER_RELATIVE = original_runner_relative
        _entry.EXPECTED_RUNNER_SHA256 = original_runner_sha256
        _entry.standard_preflight = original_preflight
        _entry._load_numerical_runtime = original_numerical_loader


if __name__ == "__main__":
    raise SystemExit(main())
