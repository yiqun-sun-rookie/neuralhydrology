"""Build one deterministic daily CAMELS UKF/KalmanNet parity HPC bundle.

This builder is deliberately standard-library only.  It has an explicit source
allowlist, treats the frozen basin archive as opaque bytes, normalizes every
tar member, and refuses to replace a different destination.  The active
configuration may be the exact TUKF06 replay contract or a later causal
training contract; both use the same fixed implementation and evidence files.
"""

from __future__ import annotations

import argparse
import ast
from dataclasses import dataclass
import gzip
from hashlib import sha256
from io import BytesIO
import json
import os
from pathlib import Path, PurePosixPath
import re
import tarfile
from typing import Any, Mapping
import uuid


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_EXACT_CONFIG_MEMBER = (
    "configs/daily_camels_ukf_knet_parity_exact_replay_dtype_repair_v3.json"
)
DEFAULT_EXACT_CONFIG = ROOT / DEFAULT_EXACT_CONFIG_MEMBER

ARCHIVE_MEMBER = (
    "results/tukf06_full_diagonal_search_head_to_head_v1/"
    "selection_inputs/basin_09035800.npz"
)
SELECTION_MEMBER = (
    "results/tukf06_full_diagonal_search_head_to_head_v1/"
    "selection/basin_09035800.json"
)
TUKF06_CONTRACT_MEMBER = "configs/tukf06_full_diagonal_search_head_to_head_v1.json"
A13_BASELINE_CONFIG_MEMBER = (
    "configs/daily_camels_knet_near_zero_stable_lr_strict_smoke_a13.json"
)


# Archive member -> repository-relative source.  Nothing outside this mapping,
# the one validated active config, and the empty package initializers can enter
# the bundle.
FIXED_SOURCE_MEMBER_PATHS: dict[str, str] = {
    TUKF06_CONTRACT_MEMBER: TUKF06_CONTRACT_MEMBER,
    A13_BASELINE_CONFIG_MEMBER: A13_BASELINE_CONFIG_MEMBER,
    "hpc/daily_camels_ukf_knet_parity/preflight.py": (
        "hpc/daily_camels_ukf_knet_parity/preflight.py"
    ),
    "hpc/daily_camels_ukf_knet_parity/submit_probe_gpu.slurm": (
        "hpc/daily_camels_ukf_knet_parity/submit_probe_gpu.slurm"
    ),
    "hpc/daily_camels_ukf_knet_parity/submit_replay_gpu.slurm": (
        "hpc/daily_camels_ukf_knet_parity/submit_replay_gpu.slurm"
    ),
    "hpc/daily_camels_ukf_knet_parity/submit_train_gpu.slurm": (
        "hpc/daily_camels_ukf_knet_parity/submit_train_gpu.slurm"
    ),
    ARCHIVE_MEMBER: ARCHIVE_MEMBER,
    SELECTION_MEMBER: SELECTION_MEMBER,
    "knet/dl/nn_kalman_clamp_5.py": "knet/dl/nn_kalman_clamp_5.py",
    "scripts/build_daily_camels_ukf_knet_parity_hpc_bundle.py": (
        "scripts/build_daily_camels_ukf_knet_parity_hpc_bundle.py"
    ),
    "scripts/differentiable_ukf_hbvlite.py": (
        "scripts/differentiable_ukf_hbvlite.py"
    ),
    "scripts/run_aligned_gr4j_da.py": "scripts/run_aligned_gr4j_da.py",
    "scripts/run_aligned_gr4j_differentiable_ukf.py": (
        "scripts/run_aligned_gr4j_differentiable_ukf.py"
    ),
    "scripts/run_daily_camels_ukf_knet_parity.py": (
        "scripts/run_daily_camels_ukf_knet_parity.py"
    ),
    "scripts/tukf06_full_diagonal_common.py": (
        "scripts/tukf06_full_diagonal_common.py"
    ),
    "src/global_hydrology/assimilation/conventional_ukf.py": (
        "src/global_hydrology/assimilation/conventional_ukf.py"
    ),
    "src/global_hydrology/experiments/daily_camels_native_knet_io.py": (
        "src/global_hydrology/experiments/daily_camels_native_knet_io.py"
    ),
    "src/global_hydrology/experiments/daily_camels_ukf_knet_parity_contract.py": (
        "src/global_hydrology/experiments/daily_camels_ukf_knet_parity_contract.py"
    ),
    "src/global_hydrology/experiments/daily_camels_ukf_knet_parity_runner.py": (
        "src/global_hydrology/experiments/daily_camels_ukf_knet_parity_runner.py"
    ),
    "src/global_hydrology/models/differentiable_hbv_lite.py": (
        "src/global_hydrology/models/differentiable_hbv_lite.py"
    ),
    "src/global_hydrology/models/hbvlite_system_model.py": (
        "src/global_hydrology/models/hbvlite_system_model.py"
    ),
    "src/global_hydrology/models/hbvlite_ukf_adapter.py": (
        "src/global_hydrology/models/hbvlite_ukf_adapter.py"
    ),
    "src/global_hydrology/models/knet_native_hbvlite_full_state.py": (
        "src/global_hydrology/models/knet_native_hbvlite_full_state.py"
    ),
    "tests/conftest.py": "tests/conftest.py",
    "tests/test_daily_camels_ukf_knet_parity_contract.py": (
        "tests/test_daily_camels_ukf_knet_parity_contract.py"
    ),
    "tests/test_daily_camels_ukf_knet_parity_runner.py": (
        "tests/test_daily_camels_ukf_knet_parity_runner.py"
    ),
    "tests/test_run_daily_camels_ukf_knet_parity_entry.py": (
        "tests/test_run_daily_camels_ukf_knet_parity_entry.py"
    ),
    "tests/test_daily_camels_ukf_knet_parity_hpc_preflight.py": (
        "tests/test_daily_camels_ukf_knet_parity_hpc_preflight.py"
    ),
    "tests/test_differentiable_ukf_hbvlite.py": (
        "tests/test_differentiable_ukf_hbvlite.py"
    ),
    "tests/test_knet_native_hbvlite_full_state.py": (
        "tests/test_knet_native_hbvlite_full_state.py"
    ),
}

EMPTY_PACKAGE_MEMBERS = (
    "knet/__init__.py",
    "knet/dl/__init__.py",
    "scripts/__init__.py",
    "src/global_hydrology/__init__.py",
    "src/global_hydrology/assimilation/__init__.py",
    "src/global_hydrology/experiments/__init__.py",
    "src/global_hydrology/models/__init__.py",
)

FROZEN_EVIDENCE_HASHES = {
    ARCHIVE_MEMBER: "71e6d163507ae405204bedf63d2c6c06e2c3ea303cea1a0481cfa4d5f280f5fd",
    SELECTION_MEMBER: "8b4888a62052f8d9f0018e907c665d30a72c4c7c29081763db0f4d46904ec3a2",
    TUKF06_CONTRACT_MEMBER: "4b19eda7cf4ce7dcd9c0940693577077d6a6faf3b18912b03178164613cac7a3",
    A13_BASELINE_CONFIG_MEMBER: "31b9a4207c483730249bb379f04d113bc0f6459f1390ba90b7a4121b46a65fe1",
}

PINNED_SCIENCE_SOURCE_HASHES = {
    "knet/dl/nn_kalman_clamp_5.py": (
        "934570d3c840e9d57b8fbddf3a018dc29e190cdd712fc9daaf442e383f74d843"
    ),
    "scripts/differentiable_ukf_hbvlite.py": (
        "5d4d0fce3018aef42d6ef81ac32fa97541654f0a878c0508f5594ff2ec73c02d"
    ),
    "scripts/tukf06_full_diagonal_common.py": (
        "2d0ebdae9447ede8873d19032b2c5d497e8f8bff78aab7d92f1c03daa508cf02"
    ),
    "src/global_hydrology/models/differentiable_hbv_lite.py": (
        "d7a04be86f19cddd8b9703e432fafb999a38215cb85de8983fe39a40bda0d6ea"
    ),
    "src/global_hydrology/models/hbvlite_system_model.py": (
        "0d32d0f8dc656bdfbea81ba9f61eba0775ecc770d4466ff0442597d7c8d7a597"
    ),
    "src/global_hydrology/models/knet_native_hbvlite_full_state.py": (
        "3eb80fc1346a3e86170cac28fecad29951fe938193967e6a8cf6ae705edc22da"
    ),
}

ENTRY_INTEGRATION_HASH_CONSTANTS = {
    "src/global_hydrology/experiments/daily_camels_ukf_knet_parity_contract.py": (
        "EXPECTED_CONTRACT_SHA256"
    ),
    "src/global_hydrology/experiments/daily_camels_ukf_knet_parity_runner.py": (
        "EXPECTED_RUNNER_SHA256"
    ),
    "src/global_hydrology/experiments/daily_camels_native_knet_io.py": (
        "EXPECTED_IO_SHA256"
    ),
}

TEXT_SUFFIXES = frozenset({".json", ".py", ".slurm", ".sh", ".txt"})
WINDOWS_ABSOLUTE_PATH = re.compile(rb"(?i)(?:^|[\"'\s(])[a-z]:[\\/]")
WINDOWS_PATH_ALLOWED_MEMBERS = frozenset({"scripts/tukf06_full_diagonal_common.py"})
EXPERIMENT_ID_PATTERN = re.compile(r"^[A-Z0-9][A-Z0-9_-]{15,159}$")


@dataclass(frozen=True)
class BundleManifest:
    archive_path: Path
    archive_sha256: str
    archive_size: int
    manifest_path: Path
    experiment_id: str
    member_sha256: dict[str, str]
    member_size: dict[str, int]


@dataclass(frozen=True)
class ArchiveInspection:
    payloads: dict[str, bytes]
    manifest: dict[str, Any]


def _json_bytes(payload: Mapping[str, Any]) -> bytes:
    return (
        json.dumps(
            payload,
            allow_nan=False,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        + "\n"
    ).encode("utf-8")


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _validate_digest(value: str, label: str) -> None:
    if len(value) != 64 or any(character not in "0123456789abcdef" for character in value):
        raise ValueError(f"invalid lowercase SHA-256 for {label}")


def _validate_member_name(name: str) -> None:
    if "\\" in name:
        raise ValueError(f"bundle member must use forward slashes: {name}")
    path = PurePosixPath(name)
    if path.is_absolute() or not path.parts or ".." in path.parts:
        raise ValueError(f"unsafe bundle member name: {name}")
    lowered = tuple(part.lower() for part in path.parts)
    if (
        any("hourly" in part for part in lowered)
        or any(part == "evaluation" or part.startswith("evaluation_") for part in lowered)
        or ".git" in lowered
        or "__pycache__" in lowered
    ):
        raise ValueError(f"forbidden bundle member name: {name}")


def _relative_config_member(config_path: Path, root: Path) -> str:
    resolved_root = Path(root).resolve()
    resolved = Path(config_path).resolve()
    try:
        member = resolved.relative_to(resolved_root).as_posix()
    except ValueError as error:
        raise ValueError("active config must be inside the repository root") from error
    _validate_member_name(member)
    if not member.startswith("configs/") or not member.endswith(".json"):
        raise ValueError("active config must be one JSON file below configs/")
    return member


def _load_config(path: Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ValueError("parity config root must be a JSON object")
    return payload


def _validate_config(payload: Mapping[str, Any]) -> tuple[str, str]:
    experiment_id = str(payload.get("experiment_id", ""))
    if not EXPERIMENT_ID_PATTERN.fullmatch(experiment_id):
        raise ValueError("active config has an unsafe or missing experiment_id")
    if payload.get("schema_version") != "daily_camels_ukf_knet_parity_v1":
        raise ValueError("active config schema changed")
    data = payload.get("data")
    forecast = payload.get("forecast")
    initialization = payload.get("initialization")
    model = payload.get("model")
    optimization = payload.get("optimization")
    execution_policy = payload.get("execution_policy")
    gate = payload.get("gate")
    if not all(
        isinstance(item, Mapping)
        for item in (
            data,
            forecast,
            initialization,
            model,
            optimization,
            execution_policy,
            gate,
        )
    ):
        raise ValueError("active config sections are incomplete")
    if (
        payload.get("basin_id") != "09035800"
        or data.get("cadence") != "daily"
        or data.get("archive_path") != ARCHIVE_MEMBER
        or data.get("tukf06_selection_path") != SELECTION_MEMBER
        or data.get("tukf06_contract_path") != TUKF06_CONTRACT_MEMBER
        or forecast.get("recovery_window_days") != 731
        or forecast.get("filter_warmup_days") != 16
        or forecast.get("expected_recovery_target_count_per_lead") != 712
        or model.get("state_dimension") != 18
        or model.get("numeric_dtype") != "float64"
        or model.get("gain_network_numeric_dtype") != "float32"
        or model.get("gain_initialization")
        not in {"native_default", "near_zero_fc2_head"}
        or model.get(
            "correction_scope", "full_eighteen_dimensional_state_correction"
        )
        not in {
            "full_eighteen_dimensional_state_correction",
            "hbv_lite_five_storage_state_correction",
        }
        or optimization.get("training_objective") != "physical_unit_multilead_mse"
        or optimization.get("checkpoint_objective") != "physical_unit_multilead_mse"
        or optimization.get("lead_weights") != [1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0]
    ):
        raise ValueError(
            "active config differs from the daily 09035800 parity geometry, "
            "effective correction scope, or equal-lead loss"
        )
    mode = str(initialization.get("execution_mode", ""))
    if mode not in {
        "exact_tukf06_backward_time_diagnostic",
        "causal_shared_spinup",
    }:
        raise ValueError("active config initialization mode is not allowlisted")
    if (
        mode == "causal_shared_spinup"
        and execution_policy.get("allow_training") is True
        and gate.get("require_better_than_strict_zero_gain_each_lead") is not True
    ):
        raise ValueError(
            "causal training must require every lead to beat strict zero gain"
        )
    for path_key, hash_key, expected_member in (
        ("archive_path", "archive_sha256", ARCHIVE_MEMBER),
        ("tukf06_selection_path", "tukf06_selection_sha256", SELECTION_MEMBER),
        ("tukf06_contract_path", "tukf06_contract_sha256", TUKF06_CONTRACT_MEMBER),
    ):
        if data.get(path_key) != expected_member:
            raise ValueError(f"active config path changed: {path_key}")
        expected = FROZEN_EVIDENCE_HASHES[expected_member]
        if data.get(hash_key) != expected:
            raise ValueError(f"active config frozen evidence hash changed: {hash_key}")
    source_hashes = payload.get("source_sha256")
    if not isinstance(source_hashes, Mapping):
        raise ValueError("active config source_sha256 is absent")
    for name, expected in PINNED_SCIENCE_SOURCE_HASHES.items():
        if source_hashes.get(name) != expected:
            raise ValueError(f"active config science source hash changed: {name}")
    return experiment_id, mode


def bundle_member_sources(
    root: Path = ROOT,
    *,
    config_path: Path,
    exact_config_path: Path = DEFAULT_EXACT_CONFIG,
) -> tuple[dict[str, Path], str, str, str, str]:
    project_root = Path(root).resolve()
    active_member = _relative_config_member(config_path, project_root)
    active_payload = _load_config(project_root / active_member)
    experiment_id, mode = _validate_config(active_payload)
    exact_member = _relative_config_member(exact_config_path, project_root)
    exact_payload = _load_config(project_root / exact_member)
    _, exact_mode = _validate_config(exact_payload)
    if exact_mode != "exact_tukf06_backward_time_diagnostic":
        raise ValueError("the selected replay config is not the exact diagnostic")

    mapping = dict(FIXED_SOURCE_MEMBER_PATHS)
    mapping[exact_member] = exact_member
    mapping[active_member] = active_member
    sources = {name: project_root / relative for name, relative in mapping.items()}
    _validate_source_inventory(sources, expected_names=set(mapping))
    return (
        dict(sorted(sources.items())),
        active_member,
        exact_member,
        experiment_id,
        mode,
    )


def _validate_source_inventory(
    source_paths: Mapping[str, Path], *, expected_names: set[str]
) -> None:
    if set(source_paths) != expected_names:
        missing = sorted(expected_names - set(source_paths))
        extra = sorted(set(source_paths) - expected_names)
        raise ValueError(f"bundle source allowlist differs; missing={missing}, extra={extra}")
    for name, source in source_paths.items():
        _validate_member_name(name)
        path = Path(source)
        if not path.is_file():
            raise FileNotFoundError(f"bundle source is absent: {name} <- {path}")
        if path.is_symlink():
            raise RuntimeError(f"bundle source may not be a symbolic link: {name}")


def _verify_frozen_hashes(source_paths: Mapping[str, Path]) -> None:
    for name, expected in sorted(
        {**FROZEN_EVIDENCE_HASHES, **PINNED_SCIENCE_SOURCE_HASHES}.items()
    ):
        _validate_digest(expected, name)
        actual = sha256_file(Path(source_paths[name]))
        if actual != expected:
            raise RuntimeError(
                f"frozen SHA-256 mismatch for {name}: expected {expected}, got {actual}"
            )


def _entry_integration_hashes(source_paths: Mapping[str, Path]) -> dict[str, str]:
    entry_name = "scripts/run_daily_camels_ukf_knet_parity.py"
    tree = ast.parse(Path(source_paths[entry_name]).read_text(encoding="utf-8"))
    literals: dict[str, str] = {}
    required_constants = set(ENTRY_INTEGRATION_HASH_CONSTANTS.values())
    for node in tree.body:
        if (
            isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id in required_constants
        ):
            value = ast.literal_eval(node.value)
            if not isinstance(value, str):
                raise ValueError(f"entry integration hash is not text: {node.targets[0].id}")
            literals[node.targets[0].id] = value
    if set(literals) != required_constants:
        raise ValueError("entry integration hash constants are incomplete")
    result: dict[str, str] = {}
    for name, constant in ENTRY_INTEGRATION_HASH_CONSTANTS.items():
        expected = literals[constant]
        _validate_digest(expected, constant)
        actual = sha256_file(Path(source_paths[name]))
        if actual != expected:
            raise RuntimeError(
                f"entry integration SHA-256 mismatch for {name}: "
                f"expected {expected}, got {actual}"
            )
        result[name] = expected
    return dict(sorted(result.items()))


def _validate_text_payload(name: str, content: bytes) -> None:
    if PurePosixPath(name).suffix.lower() not in TEXT_SUFFIXES:
        return
    if b"\x00" in content:
        raise RuntimeError(f"text bundle member contains a null byte: {name}")
    if WINDOWS_ABSOLUTE_PATH.search(content) and name not in WINDOWS_PATH_ALLOWED_MEMBERS:
        raise RuntimeError(f"text bundle member contains a Windows absolute path: {name}")


def _payloads(
    source_paths: Mapping[str, Path],
    *,
    active_config_member: str,
    exact_config_member: str,
    experiment_id: str,
    initialization_mode: str,
) -> tuple[dict[str, bytes], dict[str, Any]]:
    expected_names = set(FIXED_SOURCE_MEMBER_PATHS) | {
        active_config_member,
        exact_config_member,
    }
    _validate_source_inventory(source_paths, expected_names=expected_names)
    _verify_frozen_hashes(source_paths)
    entry_integration_hashes = _entry_integration_hashes(source_paths)
    active_payload = _load_config(Path(source_paths[active_config_member]))
    declared_source_hashes = active_payload.get("source_sha256")
    if not isinstance(declared_source_hashes, Mapping) or not declared_source_hashes:
        raise ValueError("active config has no declared source hash inventory")
    for name, expected_value in sorted(declared_source_hashes.items()):
        expected = str(expected_value)
        _validate_digest(expected, str(name))
        if name not in source_paths:
            raise ValueError(f"active config source is outside the bundle allowlist: {name}")
        actual = sha256_file(Path(source_paths[name]))
        if actual != expected:
            raise RuntimeError(
                f"active config source SHA-256 mismatch for {name}: "
                f"expected {expected}, got {actual}"
            )
    payloads = {
        name: Path(source_paths[name]).read_bytes() for name in sorted(source_paths)
    }
    payloads.update({name: b"" for name in EMPTY_PACKAGE_MEMBERS})
    for name, content in payloads.items():
        _validate_member_name(name)
        _validate_text_payload(name, content)
    member_sha256 = {
        name: sha256(content).hexdigest() for name, content in sorted(payloads.items())
    }
    member_size = {name: len(content) for name, content in sorted(payloads.items())}
    manifest = {
        "schema_version": "daily_camels_ukf_knet_parity_hpc_bundle_v1",
        "experiment_id": experiment_id,
        "active_config_member": active_config_member,
        "exact_replay_config_member": exact_config_member,
        "initialization_mode": initialization_mode,
        "purpose": "daily_development_parity_replay_or_causal_training",
        "member_count": len(payloads),
        "input_archive_count": 1,
        "reserved_data_member_count": 0,
        "array_members_materialized_during_build": 0,
        "selection_objective": {
            "name": "physical_unit_multilead_mse",
            "filter_warmup_days": 0,
            "common_target_count_per_lead": 728,
        },
        "nse_gate": {
            "filter_warmup_days": 16,
            "common_target_count_per_lead": 712,
            "minimum_exclusive": 0.6,
        },
        "member_sha256": member_sha256,
        "member_size": member_size,
        "frozen_evidence_sha256": dict(sorted(FROZEN_EVIDENCE_HASHES.items())),
        "pinned_science_source_sha256": dict(
            sorted(PINNED_SCIENCE_SOURCE_HASHES.items())
        ),
        "active_config_declared_source_sha256": dict(
            sorted((str(name), str(value)) for name, value in declared_source_hashes.items())
        ),
        "entry_integration_source_sha256": entry_integration_hashes,
        "package_initializers": list(EMPTY_PACKAGE_MEMBERS),
    }
    return dict(sorted(payloads.items())), manifest


def _archive_bytes(payloads: Mapping[str, bytes], manifest: Mapping[str, Any]) -> bytes:
    archive_payloads = dict(payloads)
    archive_payloads["bundle_manifest.json"] = _json_bytes(manifest)
    raw = BytesIO()
    with gzip.GzipFile(
        fileobj=raw,
        mode="wb",
        filename="",
        mtime=0,
        compresslevel=9,
    ) as compressed:
        with tarfile.open(fileobj=compressed, mode="w", format=tarfile.USTAR_FORMAT) as archive:
            for name in sorted(archive_payloads):
                content = archive_payloads[name]
                information = tarfile.TarInfo(name=name)
                information.size = len(content)
                information.mtime = 0
                information.uid = 0
                information.gid = 0
                information.uname = ""
                information.gname = ""
                information.mode = 0o755 if name.endswith((".slurm", ".sh")) else 0o644
                archive.addfile(information, BytesIO(content))
    return raw.getvalue()


def inspect_archive(archive_path: Path) -> ArchiveInspection:
    payloads: dict[str, bytes] = {}
    with tarfile.open(Path(archive_path), "r:gz") as archive:
        members = archive.getmembers()
        names = [member.name for member in members]
        if names != sorted(names) or len(names) != len(set(names)):
            raise RuntimeError("archive member order or uniqueness differs")
        for member in members:
            _validate_member_name(member.name)
            if (
                not member.isfile()
                or member.issym()
                or member.islnk()
                or member.uid != 0
                or member.gid != 0
                or member.uname != ""
                or member.gname != ""
                or member.mtime != 0
            ):
                raise RuntimeError(f"archive member metadata differs: {member.name}")
            stream = archive.extractfile(member)
            if stream is None:
                raise RuntimeError(f"archive member cannot be read: {member.name}")
            payloads[member.name] = stream.read()

    content = payloads.get("bundle_manifest.json")
    if content is None:
        raise RuntimeError("archive internal manifest is absent")
    manifest = json.loads(content.decode("utf-8"))
    if not isinstance(manifest, dict):
        raise RuntimeError("archive internal manifest must be a JSON object")
    expected_names = set(manifest.get("member_sha256", {}))
    if set(payloads) != expected_names | {"bundle_manifest.json"}:
        raise RuntimeError("archive inventory differs from internal manifest")
    if (
        manifest.get("schema_version")
        != "daily_camels_ukf_knet_parity_hpc_bundle_v1"
        or manifest.get("input_archive_count") != 1
        or manifest.get("reserved_data_member_count") != 0
        or manifest.get("array_members_materialized_during_build") != 0
    ):
        raise RuntimeError("archive identity or data policy differs")
    if manifest.get("frozen_evidence_sha256") != FROZEN_EVIDENCE_HASHES:
        raise RuntimeError("archive frozen evidence inventory differs")
    if manifest.get("pinned_science_source_sha256") != PINNED_SCIENCE_SOURCE_HASHES:
        raise RuntimeError("archive pinned source inventory differs")
    declared = manifest.get("active_config_declared_source_sha256")
    if not isinstance(declared, dict) or not declared:
        raise RuntimeError("archive active-config source inventory is absent")
    for name, expected in declared.items():
        if manifest["member_sha256"].get(name) != expected:
            raise RuntimeError(f"archive active-config source hash differs: {name}")
    entry_hashes = manifest.get("entry_integration_source_sha256")
    if not isinstance(entry_hashes, dict) or set(entry_hashes) != set(
        ENTRY_INTEGRATION_HASH_CONSTANTS
    ):
        raise RuntimeError("archive entry integration source inventory differs")
    for name, expected in entry_hashes.items():
        if manifest["member_sha256"].get(name) != expected:
            raise RuntimeError(f"archive entry integration source hash differs: {name}")
    for name in sorted(expected_names):
        member_content = payloads[name]
        if sha256(member_content).hexdigest() != manifest["member_sha256"][name]:
            raise RuntimeError(f"archive member SHA-256 mismatch: {name}")
        if len(member_content) != int(manifest["member_size"][name]):
            raise RuntimeError(f"archive member size mismatch: {name}")
        _validate_text_payload(name, member_content)
    for name in EMPTY_PACKAGE_MEMBERS:
        if payloads.get(name) != b"":
            raise RuntimeError(f"isolated package initializer is not empty: {name}")
    return ArchiveInspection(payloads=payloads, manifest=manifest)


def _write_new_file(path: Path, content: bytes) -> None:
    with Path(path).open("xb") as handle:
        handle.write(content)
        handle.flush()
        os.fsync(handle.fileno())


def _existing_bundle(
    destination: Path,
    *,
    archive_name: str,
    archive_bytes: bytes,
    manifest_bytes: bytes,
) -> BundleManifest | None:
    if not destination.exists():
        return None
    archive_path = destination / archive_name
    manifest_path = destination / "bundle_manifest.sha256.json"
    if (
        not destination.is_dir()
        or not archive_path.is_file()
        or not manifest_path.is_file()
        or archive_path.read_bytes() != archive_bytes
        or manifest_path.read_bytes() != manifest_bytes
        or len(list(destination.iterdir())) != 2
    ):
        raise FileExistsError(f"refusing to replace a different bundle directory: {destination}")
    inspection = inspect_archive(archive_path)
    return BundleManifest(
        archive_path=archive_path,
        archive_sha256=sha256(archive_bytes).hexdigest(),
        archive_size=len(archive_bytes),
        manifest_path=manifest_path,
        experiment_id=str(inspection.manifest["experiment_id"]),
        member_sha256=dict(inspection.manifest["member_sha256"]),
        member_size={
            name: int(size) for name, size in inspection.manifest["member_size"].items()
        },
    )


def build_bundle(
    destination: Path,
    *,
    config_path: Path,
    exact_config_path: Path = DEFAULT_EXACT_CONFIG,
    root: Path = ROOT,
) -> BundleManifest:
    """Create or byte-verify one deterministic bundle in ``destination``."""

    sources, active_member, exact_member, experiment_id, mode = bundle_member_sources(
        root,
        config_path=config_path,
        exact_config_path=exact_config_path,
    )
    payloads, internal_manifest = _payloads(
        sources,
        active_config_member=active_member,
        exact_config_member=exact_member,
        experiment_id=experiment_id,
        initialization_mode=mode,
    )
    archive_name = f"{experiment_id}.tar.gz"
    archive_content = _archive_bytes(payloads, internal_manifest)
    internal_manifest_bytes = _json_bytes(internal_manifest)
    outer_manifest = {
        "schema_version": "daily_camels_ukf_knet_parity_hpc_archive_v1",
        "experiment_id": experiment_id,
        "active_config_member": active_member,
        "exact_replay_config_member": exact_member,
        "initialization_mode": mode,
        "archive_name": archive_name,
        "archive_sha256": sha256(archive_content).hexdigest(),
        "archive_size": len(archive_content),
        "internal_manifest_sha256": sha256(internal_manifest_bytes).hexdigest(),
        "member_count": len(payloads),
        "input_archive_count": 1,
        "reserved_data_member_count": 0,
        "array_members_materialized_during_build": 0,
        "member_sha256": internal_manifest["member_sha256"],
        "member_size": internal_manifest["member_size"],
    }
    outer_bytes = _json_bytes(outer_manifest)

    target = Path(destination)
    existing = _existing_bundle(
        target,
        archive_name=archive_name,
        archive_bytes=archive_content,
        manifest_bytes=outer_bytes,
    )
    if existing is not None:
        return existing

    target.parent.mkdir(parents=True, exist_ok=True)
    pending = target.with_name(target.name + f".pending-{uuid.uuid4().hex}")
    pending.mkdir(parents=False, exist_ok=False)
    pending_archive = pending / archive_name
    pending_manifest = pending / "bundle_manifest.sha256.json"
    try:
        _write_new_file(pending_archive, archive_content)
        _write_new_file(pending_manifest, outer_bytes)
        inspection = inspect_archive(pending_archive)
        if inspection.manifest != internal_manifest:
            raise RuntimeError("pending archive manifest differs")
        if sha256_file(pending_archive) != outer_manifest["archive_sha256"]:
            raise RuntimeError("pending archive SHA-256 differs")
        if target.exists():
            raise FileExistsError(f"refusing to replace an existing bundle: {target}")
        os.replace(pending, target)
    finally:
        if pending.exists():
            for path in (pending_archive, pending_manifest):
                if path.exists():
                    path.unlink()
            pending.rmdir()

    return BundleManifest(
        archive_path=target / archive_name,
        archive_sha256=str(outer_manifest["archive_sha256"]),
        archive_size=len(archive_content),
        manifest_path=target / "bundle_manifest.sha256.json",
        experiment_id=experiment_id,
        member_sha256=dict(internal_manifest["member_sha256"]),
        member_size={name: int(size) for name, size in internal_manifest["member_size"].items()},
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Build a deterministic daily CAMELS UKF/KalmanNet parity HPC bundle."
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument(
        "--exact-config",
        type=Path,
        default=DEFAULT_EXACT_CONFIG,
        help="Exact diagnostic replay config that must accompany the active config.",
    )
    return parser


def main() -> int:
    arguments = build_parser().parse_args()
    result = build_bundle(
        arguments.output_dir,
        config_path=arguments.config,
        exact_config_path=arguments.exact_config,
    )
    print(
        json.dumps(
            {
                "status": "BUNDLE_READY",
                "experiment_id": result.experiment_id,
                "archive_path": str(result.archive_path),
                "archive_sha256": result.archive_sha256,
                "archive_size": result.archive_size,
                "manifest_path": str(result.manifest_path),
                "member_count": len(result.member_sha256),
                "array_members_materialized": 0,
            },
            indent=2,
            sort_keys=True,
        ),
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
