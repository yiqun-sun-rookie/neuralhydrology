"""Pinned-upstream KalmanNet backend over the frozen daily parity primitives.

The historical daily CAMELS parity runner is byte-frozen because its A16
evidence binds that exact source hash.  This module deliberately leaves that
file untouched and re-exports its data, HBV, forecast, loss, checkpoint, and
scoring functions.  Only the function named ``build_native_knet`` is replaced
for compatibility with the existing fail-closed entry: it constructs the
pinned upstream KalmanNet_TSP gain core instead of the repository-native core.
"""

from __future__ import annotations

from threading import RLock
from typing import Any

import torch

from global_hydrology.experiments import daily_camels_ukf_knet_parity_runner as _frozen
from global_hydrology.experiments.daily_camels_ukf_knet_parity_runner import *  # noqa: F403
from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import (
    NATIVE_DEFAULT_GAIN_INITIALIZATION,
)
from global_hydrology.models.official_kalmannet_tsp_hbvlite import (
    OfficialKalmanNetTSPHBVAdapter,
)


BACKEND_ID = "pinned_upstream_kalmannet_tsp_828a2cf"
UPSTREAM_COMMIT = "828a2cf529bc84f43b37d543d916fe5858054457"
UPSTREAM_SOURCE_SHA256 = (
    "0cad52635723eaf8c4bbfc331a2d0614520363c71953f650794b4794d7aab33d"
)
_REPLAY_LOCK = RLock()


def build_native_knet(
    runtime: _frozen.ParityRuntime,
    *,
    zero_gain: bool,
    gain_initialization: str,
    seed: int,
    correction_scope: str = _frozen.FULL_EIGHTEEN_DIMENSIONAL_STATE_CORRECTION_SCOPE,
    hidden: int = 24,
    in_mult: int = 10,
    out_mult: int = 10,
    feature_scale_floor: float = 0.1,
    normalized_feature_guard: float | None = 10.0,
) -> OfficialKalmanNetTSPHBVAdapter:
    """Construct the official gain core with the frozen A16 physical contract.

    The function retains the historical name solely so the existing entry can
    inject this module without duplicating its training loop.  ``hidden`` and
    the guard are checked against A16 for contract drift; the upstream network
    fixes its own recurrent dimensions and performs Euclidean normalization,
    so it does not consume those two native-core controls.
    """

    if int(hidden) != 24:
        raise ValueError("the official-core comparison freezes hidden=24 as provenance")
    if normalized_feature_guard != 10.0:
        raise ValueError(
            "the official-core comparison freezes the A16 normalized feature guard record"
        )
    torch.manual_seed(int(seed))
    if runtime.context.device.type == "cuda":
        torch.cuda.manual_seed_all(int(seed))

    scales = _frozen.fit_training_feature_scales(
        runtime, floor=float(feature_scale_floor)
    )
    mask = _frozen.correction_mask_for_scope(
        runtime.context.dimension,
        correction_scope=correction_scope,
        dtype=runtime.context.dtype,
        device=runtime.context.device,
    )
    lower, upper = _frozen._state_bounds(runtime)
    net = OfficialKalmanNetTSPHBVAdapter(
        runtime.context.plain_model,
        correction_mask=mask,
        state_lower_bound=lower,
        state_upper_bound=upper,
        input_multiplier=int(in_mult),
        output_multiplier=int(out_mult),
        correction_cap_in_state_scale_units=None,
    ).to(device=runtime.context.device)
    if {parameter.dtype for parameter in net.parameters()} != {torch.float32}:
        raise RuntimeError("the pinned upstream KalmanNet gain core must remain float32")
    net.set_basin_adaptation(
        system=runtime.context.plain_model,
        correction_mask=mask,
        state_lower_bound=lower,
        state_upper_bound=upper,
        observation_feature_scale=scales.observation_feature_scale,
        state_feature_scale=scales.state_feature_scale,
        correction_cap_by_state_scale_units=None,
        normalized_feature_guard=None,
    )
    if zero_gain:
        if gain_initialization != NATIVE_DEFAULT_GAIN_INITIALIZATION:
            raise ValueError(
                "strict zero-gain replay cannot be combined with a training initialization"
            )
        net.zero_gain_head()
    else:
        _frozen.apply_gain_initialization(net, gain_initialization)
    return net


def replay_zero_gain_open_loop(
    runtime: _frozen.ParityRuntime,
    window: _frozen.WindowBatch,
    **kwargs: Any,
) -> _frozen.ScoreSummary:
    """Reuse the exact frozen replay while injecting the official zero-gain core."""

    with _REPLAY_LOCK:
        original = _frozen.build_native_knet
        _frozen.build_native_knet = build_native_knet
        try:
            result = _frozen.replay_zero_gain_open_loop(runtime, window, **kwargs)
        finally:
            _frozen.build_native_knet = original
    metadata = dict(result.metadata or {})
    metadata["kalmannet_backend"] = BACKEND_ID
    return _frozen.replace(result, metadata=metadata)


def train_short_knet(*args: Any, **kwargs: Any) -> _frozen.TrainingResult:
    """Reuse the frozen convenience loop without silently selecting its native core."""

    with _REPLAY_LOCK:
        original = _frozen.build_native_knet
        _frozen.build_native_knet = build_native_knet
        try:
            return _frozen.train_short_knet(*args, **kwargs)
        finally:
            _frozen.build_native_knet = original


__all__ = list(_frozen.__all__) + [
    "BACKEND_ID",
    "UPSTREAM_COMMIT",
    "UPSTREAM_SOURCE_SHA256",
]
