from __future__ import annotations

from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
from typing import Any

import pytest
import torch

import global_hydrology.experiments.daily_camels_ukf_knet_official_core_runner as official_runner
import global_hydrology.experiments.daily_camels_ukf_knet_parity_runner as frozen_runner
import scripts.run_daily_camels_ukf_knet_official_core as official_entry
from global_hydrology.experiments.daily_camels_ukf_knet_parity_contract import (
    NATIVE_DEFAULT_GAIN_INITIALIZATION,
)


ROOT = Path(__file__).resolve().parents[1]
FROZEN_RUNNER_SHA256 = (
    "2fd983a4af52ee02fd677e8ee51894d8208b836d6e9759b3ff2ac3a82c89ea69"
)


def _sha256(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def test_official_entry_can_be_invoked_as_a_direct_script() -> None:
    completed = subprocess.run(
        [
            sys.executable,
            "-B",
            str(ROOT / "scripts" / "run_daily_camels_ukf_knet_official_core.py"),
            "--help",
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )

    assert completed.returncode == 0, completed.stderr
    assert "--phase" in completed.stdout


def test_a35_probe_is_read_only_and_selects_the_official_overlay(
    tmp_path: Path,
) -> None:
    completed = subprocess.run(
        [
            sys.executable,
            "-B",
            str(ROOT / "scripts" / "run_daily_camels_ukf_knet_official_core.py"),
            "--phase",
            "probe",
            "--config",
            str(
                ROOT
                / "configs"
                / "daily_camels_knet_official_core_fixed_full_training_coverage_one_step_a35.json"
            ),
            "--run-parent",
            str(tmp_path / "absent_parent"),
            "--device",
            "cpu",
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )

    assert completed.returncode == 0, completed.stderr
    report = json.loads(completed.stdout)
    assert report["status"] == "PREFLIGHT_PASS"
    assert report["array_members_materialized"] == 0
    assert report["run_directory_absent"] is True
    assert report["integration_source_sha256"][
        official_entry.OFFICIAL_RUNNER_RELATIVE
    ] == official_entry.OFFICIAL_RUNNER_SHA256
    assert not (tmp_path / "absent_parent").exists()


def test_direct_standard_preflight_records_the_official_overlay(tmp_path: Path) -> None:
    code = (
        "import json,sys; "
        "import scripts.run_daily_camels_ukf_knet_official_core as entry; "
        "result=entry.standard_preflight(sys.argv[1],sys.argv[2],phase='probe'); "
        "print(json.dumps(dict(result.integration_source_sha256),sort_keys=True))"
    )
    completed = subprocess.run(
        [
            sys.executable,
            "-B",
            "-c",
            code,
            str(
                ROOT
                / "configs"
                / "daily_camels_knet_official_core_fixed_full_training_coverage_one_step_a35.json"
            ),
            str(tmp_path / "absent_parent"),
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )

    assert completed.returncode == 0, completed.stderr
    integration_sources = json.loads(completed.stdout)
    assert integration_sources[
        official_entry.OFFICIAL_RUNNER_RELATIVE
    ] == official_entry.OFFICIAL_RUNNER_SHA256
    assert official_entry.FROZEN_RUNNER_RELATIVE not in integration_sources
    assert not (tmp_path / "absent_parent").exists()


def test_official_overlay_leaves_the_a16_runner_byte_frozen() -> None:
    path = (
        ROOT
        / "src"
        / "global_hydrology"
        / "experiments"
        / "daily_camels_ukf_knet_parity_runner.py"
    )

    assert _sha256(path) == FROZEN_RUNNER_SHA256
    assert official_runner.BACKEND_ID == "pinned_upstream_kalmannet_tsp_828a2cf"
    assert official_runner.UPSTREAM_SOURCE_SHA256 == (
        "0cad52635723eaf8c4bbfc331a2d0614520363c71953f650794b4794d7aab33d"
    )


def test_official_builder_reuses_a16_scales_mask_bounds_and_zero_gain(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    received: dict[str, Any] = {}

    class RecordingOfficialKalmanNet(torch.nn.Module):
        def __init__(self, system: Any, **kwargs: Any) -> None:
            super().__init__()
            self.anchor = torch.nn.Parameter(torch.ones(1, dtype=torch.float32))
            self.FC2 = torch.nn.Sequential(torch.nn.Linear(1, 18))
            received["system"] = system
            received["constructor"] = kwargs

        def set_basin_adaptation(self, **kwargs: Any) -> None:
            received["adaptation"] = kwargs

        def zero_gain_head(self) -> None:
            with torch.no_grad():
                self.FC2[-1].weight.zero_()
                self.FC2[-1].bias.zero_()

    observation_scale = torch.full((1, 1), 2.0, dtype=torch.float64)
    state_scale = torch.full((1, 18), 3.0, dtype=torch.float64)
    mask = torch.ones((1, 18), dtype=torch.float64)
    lower = torch.zeros((1, 18), dtype=torch.float64)
    upper = torch.full((1, 18), torch.inf, dtype=torch.float64)
    system = SimpleNamespace()
    runtime = SimpleNamespace(
        context=SimpleNamespace(
            plain_model=system,
            dimension=18,
            dtype=torch.float64,
            device=torch.device("cpu"),
        )
    )

    monkeypatch.setattr(
        official_runner,
        "OfficialKalmanNetTSPHBVAdapter",
        RecordingOfficialKalmanNet,
    )
    monkeypatch.setattr(
        frozen_runner,
        "fit_training_feature_scales",
        lambda *_args, **_kwargs: SimpleNamespace(
            observation_feature_scale=observation_scale,
            state_feature_scale=state_scale,
        ),
    )
    monkeypatch.setattr(
        frozen_runner,
        "correction_mask_for_scope",
        lambda *_args, **_kwargs: mask,
    )
    monkeypatch.setattr(frozen_runner, "_state_bounds", lambda *_args: (lower, upper))

    net = official_runner.build_native_knet(
        runtime,
        zero_gain=True,
        gain_initialization=NATIVE_DEFAULT_GAIN_INITIALIZATION,
        seed=20260825,
    )

    assert received["system"] is system
    assert received["constructor"]["correction_mask"] is mask
    assert received["constructor"]["state_lower_bound"] is lower
    assert received["constructor"]["state_upper_bound"] is upper
    assert received["adaptation"]["observation_feature_scale"] is observation_scale
    assert received["adaptation"]["state_feature_scale"] is state_scale
    assert received["adaptation"]["normalized_feature_guard"] is None
    assert int(torch.count_nonzero(net.FC2[-1].weight)) == 0
    assert int(torch.count_nonzero(net.FC2[-1].bias)) == 0


def test_official_builder_rejects_unregistered_native_only_controls() -> None:
    runtime = SimpleNamespace(
        context=SimpleNamespace(device=torch.device("cpu"))
    )
    with pytest.raises(ValueError, match="hidden=24"):
        official_runner.build_native_knet(
            runtime,
            zero_gain=False,
            gain_initialization=NATIVE_DEFAULT_GAIN_INITIALIZATION,
            seed=20260825,
            hidden=32,
        )
    with pytest.raises(ValueError, match="feature guard record"):
        official_runner.build_native_knet(
            runtime,
            zero_gain=False,
            gain_initialization=NATIVE_DEFAULT_GAIN_INITIALIZATION,
            seed=20260825,
            normalized_feature_guard=None,
        )


def test_zero_gain_dependency_injection_is_always_restored(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    original_builder = frozen_runner.build_native_knet

    def fail_after_asserting_injection(*_args: Any, **_kwargs: Any) -> Any:
        assert frozen_runner.build_native_knet is official_runner.build_native_knet
        raise RuntimeError("synthetic replay stop")

    monkeypatch.setattr(
        frozen_runner, "replay_zero_gain_open_loop", fail_after_asserting_injection
    )
    with pytest.raises(RuntimeError, match="synthetic replay stop"):
        official_runner.replay_zero_gain_open_loop(object(), object())
    assert frozen_runner.build_native_knet is original_builder


def test_convenience_training_dependency_injection_is_always_restored(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    original_builder = frozen_runner.build_native_knet

    def fail_after_asserting_injection(*_args: Any, **_kwargs: Any) -> Any:
        assert frozen_runner.build_native_knet is official_runner.build_native_knet
        raise RuntimeError("synthetic training stop")

    monkeypatch.setattr(frozen_runner, "train_short_knet", fail_after_asserting_injection)
    with pytest.raises(RuntimeError, match="synthetic training stop"):
        official_runner.train_short_knet(object(), object())
    assert frozen_runner.build_native_knet is original_builder


def test_official_entry_rejects_every_backend_or_source_drift() -> None:
    model = {
        "kalmannet_backend": official_entry.OFFICIAL_BACKEND_ID,
        "selected_kalmannet_source": official_entry.UPSTREAM_SOURCE_RELATIVE,
        "selected_kalmannet_commit": official_entry.UPSTREAM_COMMIT,
        "selected_kalmannet_sha256": official_entry.UPSTREAM_SOURCE_SHA256,
        "selected_kalmannet_adapter": official_entry.OFFICIAL_ADAPTER_RELATIVE,
        "selected_kalmannet_adapter_sha256": official_entry.OFFICIAL_ADAPTER_SHA256,
        "numeric_dtype": "float64",
        "gain_network_numeric_dtype": "float32",
        "hidden_dimension": 24,
        "input_multiplier": 10,
        "output_multiplier": 10,
        "feature_scaling": "training_difference_root_mean_square",
        "feature_scale_floor": 0.1,
        "normalized_feature_guard": 10.0,
        "legacy_normalized_feature_guard_record_only": True,
        "legacy_hidden_dimension_record_only": True,
        "selected_kalmannet_feature_normalization": (
            "pinned_upstream_euclidean_l2_after_frozen_a16_training_scale"
        ),
        "selected_kalmannet_recurrent_geometry": (
            "pinned_upstream_dimensions_not_legacy_hidden_dimension_24"
        ),
        "correction_scope": "full_eighteen_dimensional_state_correction",
        "correction_cap_enabled": False,
    }
    sources = {
        official_entry.OFFICIAL_RUNNER_RELATIVE: official_entry.OFFICIAL_RUNNER_SHA256,
        official_entry.FROZEN_RUNNER_RELATIVE: official_entry.FROZEN_RUNNER_SHA256,
        official_entry.CURRENT_IO_RELATIVE: official_entry.CURRENT_IO_SHA256,
        official_entry.UPSTREAM_SOURCE_RELATIVE: official_entry.UPSTREAM_SOURCE_SHA256,
        official_entry.OFFICIAL_ADAPTER_RELATIVE: official_entry.OFFICIAL_ADAPTER_SHA256,
    }
    official_entry._assert_official_contract(
        SimpleNamespace(
            configuration={
                "model": model,
                "source_sha256": sources,
                "epoch_zero_reproducibility_policy": {
                    "predeclared_anchor": False,
                    "reason": "first_execution_of_a_different_pinned_upstream_core",
                    "run_must_record_actual_epoch_zero": True,
                    "require_post_epoch_zero_improvement": True,
                },
            }
        )
    )

    changed_model = dict(model, kalmannet_backend="repository_native_kalmannet")
    with pytest.raises(ValueError, match="does not select"):
        official_entry._assert_official_contract(
            SimpleNamespace(
                configuration={
                    "model": changed_model,
                    "source_sha256": sources,
                    "epoch_zero_reproducibility_policy": {
                        "predeclared_anchor": False,
                        "reason": "first_execution_of_a_different_pinned_upstream_core",
                        "run_must_record_actual_epoch_zero": True,
                        "require_post_epoch_zero_improvement": True,
                    },
                }
            )
        )

    changed_sources = dict(sources, **{official_entry.UPSTREAM_SOURCE_RELATIVE: "0" * 64})
    with pytest.raises(ValueError, match="source hash differs"):
        official_entry._assert_official_contract(
            SimpleNamespace(
                configuration={
                    "model": model,
                    "source_sha256": changed_sources,
                    "epoch_zero_reproducibility_policy": {
                        "predeclared_anchor": False,
                        "reason": "first_execution_of_a_different_pinned_upstream_core",
                        "run_must_record_actual_epoch_zero": True,
                        "require_post_epoch_zero_improvement": True,
                    },
                }
            )
        )


def test_official_numerical_loader_returns_the_overlay_not_the_frozen_runner() -> None:
    numpy_module, torch_module, runner_module = (
        official_entry._load_official_numerical_runtime(
            SimpleNamespace(repository_root=ROOT)
        )
    )

    assert numpy_module.__name__ == "numpy"
    assert torch_module.__name__ == "torch"
    assert runner_module is official_runner
    assert runner_module is not frozen_runner
    assert runner_module.build_native_knet is official_runner.build_native_knet


def test_official_main_injects_and_restores_every_base_entry_hook(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    original_runner_relative = official_entry._entry.RUNNER_RELATIVE
    original_runner_sha256 = official_entry._entry.EXPECTED_RUNNER_SHA256
    original_preflight = official_entry._entry.standard_preflight
    original_loader = official_entry._entry._load_numerical_runtime

    def inspect_injection(_argv: Any) -> int:
        assert official_entry._entry.RUNNER_RELATIVE == (
            official_entry.OFFICIAL_RUNNER_RELATIVE
        )
        assert official_entry._entry.EXPECTED_RUNNER_SHA256 == (
            official_entry.OFFICIAL_RUNNER_SHA256
        )
        assert official_entry._entry.standard_preflight is official_entry.standard_preflight
        assert official_entry._entry._load_numerical_runtime is (
            official_entry._load_official_numerical_runtime
        )
        return 0

    monkeypatch.setattr(official_entry._entry, "main", inspect_injection)
    assert official_entry.main([]) == 0
    assert official_entry._entry.RUNNER_RELATIVE == original_runner_relative
    assert official_entry._entry.EXPECTED_RUNNER_SHA256 == original_runner_sha256
    assert official_entry._entry.standard_preflight is original_preflight
    assert official_entry._entry._load_numerical_runtime is original_loader
