from __future__ import annotations

import hashlib
from pathlib import Path

import pytest
import torch
from torch import nn

from global_hydrology.models.differentiable_hbv_lite import PARAM_BOUNDS, PARAM_NAMES
from global_hydrology.models.knet_native_hbvlite_full_state import (
    build_padded_routed_system,
    correction_mask_for_active_lag,
)
from global_hydrology.models.official_kalmannet_tsp_hbvlite import (
    SHARED_HYDROLOGY_FEATURE_MODE,
    UPSTREAM_COMMIT,
    UPSTREAM_SOURCE_SHA256,
    OfficialKalmanNetNN,
    OfficialKalmanNetTSPHBVAdapter,
)


DTYPE = torch.float32


def _params(*, lag_time: float = 2.0, par_k2: float | None = None) -> torch.Tensor:
    values = []
    for name in PARAM_NAMES:
        lower, upper = PARAM_BOUNDS[name]
        if name == "lag_time":
            value = lag_time
        elif name == "parK2" and par_k2 is not None:
            value = par_k2
        else:
            value = (lower + upper) / 2.0
        values.append(value)
    return torch.tensor([values], dtype=DTYPE)


def _forcing(days: int = 3) -> torch.Tensor:
    forcing = torch.zeros(days, 3, dtype=DTYPE)
    forcing[:, 0] = torch.linspace(0.5, 2.0, days)
    forcing[:, 1] = torch.linspace(1.0, 5.0, days)
    forcing[:, 2] = 0.5
    return forcing


def _adapter(*, maximum_lag: int = 3, lag_time: float = 2.0):
    system, active_lag = build_padded_routed_system(
        _params(lag_time=lag_time), maximum_lag=maximum_lag, dtype=DTYPE
    )
    mask = correction_mask_for_active_lag(system.m, active_lag, dtype=DTYPE)
    net = OfficialKalmanNetTSPHBVAdapter(
        system,
        correction_mask=mask,
        input_multiplier=2,
        output_multiplier=2,
        feature_mode=SHARED_HYDROLOGY_FEATURE_MODE,
    ).to(DTYPE)
    net.set_basin_adaptation(
        system=system,
        correction_mask=mask,
        state_lower_bound=torch.zeros(1, system.m, dtype=DTYPE),
        state_upper_bound=torch.full((1, system.m), torch.inf, dtype=DTYPE),
        observation_feature_scale=torch.ones(1, 1, dtype=DTYPE),
        state_feature_scale=torch.ones(1, system.m, dtype=DTYPE),
        correction_cap_by_state_scale_units=torch.full(
            (1, system.m), torch.inf, dtype=DTYPE
        ),
        normalized_feature_guard=None,
    )
    return system, active_lag, mask, net


def test_pinned_upstream_architecture_has_three_grus_and_official_dimensions() -> None:
    _, _, _, net = _adapter(maximum_lag=2)
    source = (
        Path(__file__).resolve().parents[1]
        / "third_party"
        / "KalmanNet_TSP_828a2cf"
        / "KNet"
        / "KalmanNet_nn.py"
    )

    assert len(UPSTREAM_COMMIT) == 40
    assert len(UPSTREAM_SOURCE_SHA256) == 64
    assert hashlib.sha256(source.read_bytes()).hexdigest() == UPSTREAM_SOURCE_SHA256
    assert isinstance(net, OfficialKalmanNetNN)
    assert sum(isinstance(module, nn.GRU) for module in net.modules()) == 3
    assert not any(isinstance(module, nn.LSTM) for module in net.modules())
    assert net.GRU_Q.hidden_size == net.m**2
    assert net.GRU_Sigma.hidden_size == net.m**2
    assert net.GRU_S.hidden_size == 1
    assert net.FC2[-1].out_features == net.m


def test_upstream_feature_normalization_is_positive_scale_invariant() -> None:
    value = torch.tensor([[3.0, -4.0, 12.0]], dtype=DTYPE)
    normalized = OfficialKalmanNetTSPHBVAdapter.normalize_feature(value)

    assert torch.allclose(
        normalized,
        OfficialKalmanNetTSPHBVAdapter.normalize_feature(value * 17.0),
        atol=1e-7,
        rtol=0.0,
    )
    assert torch.allclose(torch.linalg.vector_norm(normalized, dim=1), torch.ones(1))


def test_exact_zero_gain_head_reproduces_routed_hbv_open_loop() -> None:
    system, _, _, net = _adapter()
    net.zero_gain_head()
    initial = system.get_default_initial_state()
    control = _forcing(1)
    expected = system.f(initial, control)
    observation = system.h(expected).reshape(1, 1) + 1.0

    net.initialize_filter(initial, sequence_length=1)
    posterior = net.analysis_step(observation, control)

    assert torch.equal(posterior, expected)
    assert torch.count_nonzero(net.last_gain) == 0
    assert torch.count_nonzero(net.last_correction) == 0


def test_standard_forward_requires_controls_and_matches_analysis_step() -> None:
    system, _, _, direct = _adapter()
    _, _, _, through_forward = _adapter()
    through_forward.load_state_dict(direct.state_dict())
    initial = system.get_default_initial_state()
    control = _forcing(1)
    prior = system.f(initial, control)
    observation = system.h(prior).reshape(1, 1) + 0.1
    direct.initialize_filter(initial, sequence_length=1)
    through_forward.initialize_filter(initial, sequence_length=1)

    expected = direct.analysis_step(observation, control)
    actual = through_forward(observation, control)

    assert torch.equal(actual, expected)
    with pytest.raises(TypeError, match="controls"):
        through_forward(observation)


def test_active_routing_state_can_close_same_day_discharge_innovation() -> None:
    system, active_lag, _, net = _adapter(maximum_lag=3, lag_time=2.0)
    with torch.no_grad():
        for parameter in net.parameters():
            parameter.zero_()
        net.FC2[-1].bias[5] = 1.0
        net.FC2[-1].bias[5 + active_lag] = 1.0
    initial = system.get_default_initial_state()
    control = _forcing(1)
    prior = system.f(initial, control)
    prior_discharge = system.h(prior).reshape(1, 1)
    observation = prior_discharge + 0.25

    net.initialize_filter(initial, sequence_length=1)
    posterior = net.analysis_step(observation, control)

    assert net.last_correction[0, 5].item() == 0.25
    assert net.last_correction[0, 5 + active_lag].item() == 0.0
    assert posterior[0, 5].item() == prior[0, 5].item() + 0.25
    assert posterior[0, 5 + active_lag].item() == 0.0
    assert system.h(posterior).item() > prior_discharge.item()


def test_shared_adapter_rebinds_the_current_basins_hbv_dynamics() -> None:
    system_a, active_a = build_padded_routed_system(
        _params(par_k2=0.02), maximum_lag=3, dtype=DTYPE
    )
    system_b, active_b = build_padded_routed_system(
        _params(par_k2=0.19), maximum_lag=3, dtype=DTYPE
    )
    mask_a = correction_mask_for_active_lag(system_a.m, active_a, dtype=DTYPE)
    mask_b = correction_mask_for_active_lag(system_b.m, active_b, dtype=DTYPE)
    lower_a = torch.zeros(1, system_a.m, dtype=DTYPE)
    upper_a = torch.full((1, system_a.m), torch.inf, dtype=DTYPE)
    upper_a[:, 2] = 111.0
    original_mask_a = mask_a.clone()
    original_lower_a = lower_a.clone()
    original_upper_a = upper_a.clone()
    net = OfficialKalmanNetTSPHBVAdapter(
        system_a,
        correction_mask=mask_a,
        state_lower_bound=lower_a,
        state_upper_bound=upper_a,
        input_multiplier=2,
        output_multiplier=2,
    ).to(DTYPE)
    net.zero_gain_head()
    net.set_basin_adaptation(
        system=system_b,
        correction_mask=mask_b,
        state_lower_bound=torch.zeros(1, system_b.m, dtype=DTYPE),
        state_upper_bound=torch.full((1, system_b.m), torch.inf, dtype=DTYPE),
        observation_feature_scale=torch.ones(1, 1, dtype=DTYPE),
        state_feature_scale=torch.ones(1, system_b.m, dtype=DTYPE),
        normalized_feature_guard=None,
    )
    initial = system_b.get_default_initial_state()
    control = _forcing(1)
    expected_b = system_b.f(initial, control)
    expected_a = system_a.f(initial, control)

    net.initialize_filter(initial, sequence_length=1)
    posterior = net.analysis_step(system_b.h(expected_b), control)

    assert torch.equal(posterior, expected_b)
    assert not torch.equal(expected_a, expected_b)
    assert torch.equal(mask_a, original_mask_a)
    assert torch.equal(lower_a, original_lower_a)
    assert torch.equal(upper_a, original_upper_a)


def test_multilead_gradient_reaches_upstream_gain_core_and_active_routing() -> None:
    torch.manual_seed(43)
    system, active_lag, _, net = _adapter()
    initial = system.get_default_initial_state()
    forcing = _forcing(2)
    prior = system.f(initial, forcing[0:1])
    observation = system.h(prior).reshape(1, 1) + 0.2
    net.initialize_filter(initial, sequence_length=2)

    posterior = net.analysis_step(observation, forcing[0:1])
    posterior.retain_grad()
    forecast_state = system.f(posterior, forcing[1:2])
    loss = (system.h(forecast_state) - observation - 0.1).square().mean()
    loss.backward()

    assert net.FC2[-1].weight.grad is not None
    assert torch.count_nonzero(net.FC2[-1].weight.grad) > 0
    assert posterior.grad is not None
    assert torch.count_nonzero(posterior.grad[:, 5 : 5 + active_lag]) > 0


def test_float32_gain_core_preserves_float64_physical_open_loop_exactly() -> None:
    physical_dtype = torch.float64
    parameters = _params().to(physical_dtype)
    system, active_lag = build_padded_routed_system(
        parameters, maximum_lag=3, dtype=physical_dtype
    )
    mask = correction_mask_for_active_lag(
        system.m, active_lag, dtype=physical_dtype
    )
    net = OfficialKalmanNetTSPHBVAdapter(
        system,
        correction_mask=mask,
        state_lower_bound=torch.zeros(1, system.m, dtype=physical_dtype),
        state_upper_bound=torch.full((1, system.m), torch.inf, dtype=physical_dtype),
        input_multiplier=2,
        output_multiplier=2,
    )
    net.set_basin_adaptation(
        system=system,
        correction_mask=mask,
        state_lower_bound=torch.zeros(1, system.m, dtype=physical_dtype),
        state_upper_bound=torch.full((1, system.m), torch.inf, dtype=physical_dtype),
        observation_feature_scale=torch.ones(1, 1, dtype=physical_dtype),
        state_feature_scale=torch.ones(1, system.m, dtype=physical_dtype),
        normalized_feature_guard=None,
    )
    net.zero_gain_head()
    initial = system.get_default_initial_state()
    controls = _forcing(1).to(physical_dtype)
    expected = system.f(initial, controls)
    net.initialize_filter(initial, sequence_length=1)
    posterior = net.analysis_step(system.h(expected), controls)

    assert next(net.parameters()).dtype == torch.float32
    assert posterior.dtype == torch.float64
    assert net.last_correction.dtype == torch.float64
    assert torch.equal(posterior, expected)

    net.zero_grad(set_to_none=True)
    net.initialize_filter(initial, sequence_length=1)
    updated = net.analysis_step(system.h(expected) + 0.25, controls)
    updated[:, 5].sum().backward()
    assert net.FC2[-1].bias.grad is not None
    assert torch.isfinite(net.FC2[-1].bias.grad).all()
    assert torch.count_nonzero(net.FC2[-1].bias.grad) > 0
