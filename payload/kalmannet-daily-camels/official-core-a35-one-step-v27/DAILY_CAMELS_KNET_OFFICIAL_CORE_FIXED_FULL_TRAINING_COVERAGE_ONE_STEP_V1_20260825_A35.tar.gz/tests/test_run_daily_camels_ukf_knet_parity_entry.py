from __future__ import annotations

import ast
import importlib.util
import json
import math
from pathlib import Path
from types import SimpleNamespace
import subprocess
import sys

import pytest


ROOT = Path(__file__).resolve().parents[1]
ENTRY_PATH = ROOT / "scripts" / "run_daily_camels_ukf_knet_parity.py"
RUNNER_PATH = (
    ROOT
    / "src"
    / "global_hydrology"
    / "experiments"
    / "daily_camels_ukf_knet_parity_runner.py"
)
MODULE_NAME = "daily_camels_ukf_knet_parity_entry_standalone"


def _load_entry_module():
    numerical_modules_before = {
        name: name in sys.modules for name in ("numpy", "torch")
    }
    spec = importlib.util.spec_from_file_location(MODULE_NAME, ENTRY_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load standalone daily parity entry")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    numerical_modules_after = {
        name: name in sys.modules for name in ("numpy", "torch")
    }
    assert numerical_modules_after == numerical_modules_before
    return module


ENTRY = _load_entry_module()


def test_entry_requires_explicit_config_identity() -> None:
    action = next(
        item for item in ENTRY.build_parser()._actions if item.dest == "config"
    )
    assert action.required is True
    assert action.default is None


def test_effective_correction_scope_defaults_to_historical_full_state() -> None:
    assert (
        ENTRY._model_correction_scope({})
        == ENTRY.FULL_EIGHTEEN_DIMENSIONAL_STATE_CORRECTION_SCOPE
    )


def test_effective_correction_scope_accepts_only_two_frozen_values() -> None:
    for value in (
        ENTRY.FULL_EIGHTEEN_DIMENSIONAL_STATE_CORRECTION_SCOPE,
        ENTRY.HBV_LITE_FIVE_STORAGE_STATE_CORRECTION_SCOPE,
    ):
        assert ENTRY._model_correction_scope({"correction_scope": value}) == value

    with pytest.raises(TypeError, match="correction_scope"):
        ENTRY._model_correction_scope({"correction_scope": 5})
    with pytest.raises(ValueError, match="correction_scope"):
        ENTRY._model_correction_scope({"correction_scope": "five_state_network"})


def test_entry_and_numerical_runner_use_identical_correction_scope_values() -> None:
    tree = ast.parse(RUNNER_PATH.read_text(encoding="utf-8"), filename=str(RUNNER_PATH))
    assignments = {
        node.targets[0].id: ast.literal_eval(node.value)
        for node in tree.body
        if isinstance(node, ast.Assign)
        and len(node.targets) == 1
        and isinstance(node.targets[0], ast.Name)
        and node.targets[0].id
        in {
            "FULL_EIGHTEEN_DIMENSIONAL_STATE_CORRECTION_SCOPE",
            "HBV_LITE_FIVE_STORAGE_STATE_CORRECTION_SCOPE",
        }
    }
    assert assignments == {
        "FULL_EIGHTEEN_DIMENSIONAL_STATE_CORRECTION_SCOPE": (
            ENTRY.FULL_EIGHTEEN_DIMENSIONAL_STATE_CORRECTION_SCOPE
        ),
        "HBV_LITE_FIVE_STORAGE_STATE_CORRECTION_SCOPE": (
            ENTRY.HBV_LITE_FIVE_STORAGE_STATE_CORRECTION_SCOPE
        ),
    }


def test_training_entry_passes_effective_correction_scope_to_existing_knet() -> None:
    tree = ast.parse(ENTRY_PATH.read_text(encoding="utf-8"), filename=str(ENTRY_PATH))
    calls = [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "runner"
        and node.func.attr == "build_native_knet"
    ]
    assert len(calls) == 1
    keyword = next(
        item for item in calls[0].keywords if item.arg == "correction_scope"
    )
    assert isinstance(keyword.value, ast.Attribute)
    assert isinstance(keyword.value.value, ast.Name)
    assert keyword.value.value.id == "preflight"
    assert keyword.value.attr == "correction_scope"


def test_entry_imports_without_numerical_modules_in_clean_subprocess() -> None:
    program = f"""
import importlib.util
from pathlib import Path
import sys
path = Path({str(ENTRY_PATH)!r})
spec = importlib.util.spec_from_file_location({MODULE_NAME!r}, path)
assert spec is not None and spec.loader is not None
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
assert 'numpy' not in sys.modules
assert 'torch' not in sys.modules
"""
    completed = subprocess.run(
        [sys.executable, "-I", "-c", program],
        check=False,
        capture_output=True,
        text=True,
    )
    assert completed.returncode == 0, completed.stderr


def test_every_npz_write_call_passes_io_numpy_path_and_arrays() -> None:
    tree = ast.parse(ENTRY_PATH.read_text(encoding="utf-8"), filename=str(ENTRY_PATH))
    calls = [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "_write_npz"
    ]

    assert len(calls) == 3
    assert [len(call.args) for call in calls] == [4, 4, 4]
    assert all(
        isinstance(call.args[0], ast.Name)
        and call.args[0].id == "io_module"
        and isinstance(call.args[1], ast.Name)
        and call.args[1].id == "numpy_module"
        for call in calls
    )


def _validation() -> SimpleNamespace:
    return SimpleNamespace(
        full_objective_without_warmup=10.0,
        objective=8.0,
        mse_by_lead={1: 7.0, 2: 8.0, 3: 9.0},
        nse_by_lead={1: 0.7, 2: 0.65, 3: 0.61},
        target_count_by_lead={1: 712, 2: 712, 3: 712},
        full_target_count_by_lead_without_warmup={1: 728, 2: 728, 3: 728},
    )


def _same_segment_replay(
    before: float,
    after: float,
    *,
    step: int,
) -> dict[str, object]:
    return {
        "optimizer_step": step,
        "before_step_objective_physical_unit_multilead_mse": before,
        "after_step_objective_physical_unit_multilead_mse": after,
        "objective_improvement_before_minus_after": before - after,
        "strict_objective_decrease": after < before,
        "identical_target_geometry_before_after": True,
    }


def test_strict_zero_gain_comparison_has_explicit_per_lead_signs() -> None:
    strict_zero = SimpleNamespace(
        full_objective_without_warmup=12.0,
        mse_by_lead={1: 8.0, 2: 9.0, 3: 10.0},
        nse_by_lead={1: 0.60, 2: 0.55, 3: 0.50},
    )

    comparison = ENTRY._compare_score_to_strict_zero_gain(
        _validation(), strict_zero, (1, 2, 3)
    )

    assert comparison["checkpoint_objective_improvement_zero_minus_candidate"] == 2.0
    assert comparison["by_lead_712"][1][
        "mse_improvement_zero_minus_candidate"
    ] == 1.0
    assert comparison["by_lead_712"][1][
        "nse_delta_candidate_minus_zero"
    ] == pytest.approx(0.1)
    assert comparison["candidate_better_than_strict_zero_gain_each_lead"] is True

    degraded = _validation()
    degraded.mse_by_lead = {1: 7.0, 2: 8.0, 3: 11.0}
    degraded.nse_by_lead = {1: 0.70, 2: 0.65, 3: 0.49}
    degraded_comparison = ENTRY._compare_score_to_strict_zero_gain(
        degraded, strict_zero, (1, 2, 3)
    )
    assert degraded_comparison["by_lead_712"][3]["candidate_better"] is False
    assert (
        degraded_comparison["candidate_better_than_strict_zero_gain_each_lead"]
        is False
    )


def test_epoch_diagnostics_preserve_equal_lead_training_weights() -> None:
    diagnostics = ENTRY._summarize_epoch_training_diagnostics(
        {1: [1.0, 3.0], 2: [2.0, 6.0], 3: [4.0, 8.0]},
        {1: 204, 2: 200, 3: 190},
        gradient_clipped_optimizer_step_count=1,
        optimizer_step_count=2,
        same_segment_step_replays=(
            _same_segment_replay(4.0, 3.5, step=1),
            _same_segment_replay(8.0, 8.5, step=2),
        ),
    )

    assert diagnostics[
        "training_mse_by_lead_physical_unit_mean_over_optimizer_steps"
    ] == {1: 2.0, 2: 4.0, 3: 6.0}
    assert diagnostics["training_sampled_finite_target_event_count_by_lead"] == {
        1: 204,
        2: 200,
        3: 190,
    }
    assert diagnostics["epoch_optimizer_step_count"] == 2
    assert diagnostics["gradient_clipped_optimizer_step_count"] == 1
    assert diagnostics["gradient_clipped_optimizer_step_fraction"] == 0.5
    assert diagnostics["same_segment_post_step_replay_count"] == 2
    assert diagnostics["same_segment_strict_objective_decrease_count"] == 1
    assert diagnostics["same_segment_every_optimizer_step_strictly_decreased"] is False
    assert diagnostics["same_segment_before_step_objective_mean"] == 6.0
    assert diagnostics["same_segment_after_step_objective_mean"] == 6.0
    reconstructed = math.fsum(
        diagnostics[
            "training_mse_by_lead_physical_unit_mean_over_optimizer_steps"
        ].values()
    ) / 3
    assert reconstructed == 4.0


def test_epoch_zero_uses_explicit_no_training_sentinels() -> None:
    diagnostics = ENTRY._summarize_epoch_training_diagnostics(
        {1: (), 2: (), 3: ()},
        {1: 0, 2: 0, 3: 0},
        gradient_clipped_optimizer_step_count=0,
        optimizer_step_count=0,
    )

    assert diagnostics[
        "training_mse_by_lead_physical_unit_mean_over_optimizer_steps"
    ] is None
    assert diagnostics["training_sampled_finite_target_event_count_by_lead"] == {
        1: 0,
        2: 0,
        3: 0,
    }
    assert diagnostics["epoch_optimizer_step_count"] == 0
    assert diagnostics["gradient_clipped_optimizer_step_count"] == 0
    assert diagnostics["gradient_clipped_optimizer_step_fraction"] is None
    assert diagnostics["same_segment_post_step_replay_count"] == 0
    assert diagnostics["same_segment_every_optimizer_step_strictly_decreased"] is None
    assert diagnostics["same_segment_before_step_objective_mean"] is None
    assert diagnostics["same_segment_after_step_objective_mean"] is None

    row = ENTRY._history_row(
        epoch=0,
        training_objective=None,
        validation=_validation(),
        parameter_sha256="0" * 64,
        optimizer_steps=0,
        forecast_events=0,
        gradient_names=(),
        maximum_gradient_norm_before_clip=None,
        training_diagnostics=diagnostics,
        prediction_sha256="1" * 64,
    )
    assert row["training_objective_physical_unit_multilead_mse"] is None
    assert row[
        "training_mse_by_lead_physical_unit_mean_over_optimizer_steps"
    ] is None
    assert row["training_sampled_finite_target_event_count_by_lead"] == {
        1: 0,
        2: 0,
        3: 0,
    }
    assert row["epoch_optimizer_step_count"] == 0
    assert row["finite_gradients"] is None

    event = ENTRY._epoch_completed_event(
        epoch=0,
        training_objective=None,
        checkpoint_selection_objective=10.0,
        gate_objective=8.0,
        checkpoint_sha256="4" * 64,
        parameter_sha256="0" * 64,
        optimizer_steps=0,
        sampled_forecast_events=0,
        training_diagnostics=diagnostics,
    )
    assert event["training_objective"] is None
    assert event["optimizer_steps"] == 0
    assert event["sampled_forecast_events"] == 0
    assert event["epoch_optimizer_step_count"] == 0


@pytest.mark.parametrize(
    ("mse_by_lead", "counts", "clipped", "steps", "expected_exception"),
    [
        ({1: [float("nan")], 2: [1.0], 3: [1.0]}, {1: 1, 2: 1, 3: 1}, 0, 1, ValueError),
        ({1: [1.0], 2: [1.0], 3: [1.0]}, {1: -1, 2: 1, 3: 1}, 0, 1, ValueError),
        ({1: [1.0], 2: [1.0], 3: [1.0]}, {1: 1, 2: 1, 3: 1}, 2, 1, ValueError),
        ({1: [1.0], 2: [1.0], 3: []}, {1: 1, 2: 1, 3: 1}, 0, 1, ValueError),
    ],
)
def test_epoch_diagnostics_reject_invalid_evidence(
    mse_by_lead: dict[int, list[float]],
    counts: dict[int, int],
    clipped: int,
    steps: int,
    expected_exception: type[Exception],
) -> None:
    with pytest.raises(expected_exception):
        ENTRY._summarize_epoch_training_diagnostics(
            mse_by_lead,
            counts,
            gradient_clipped_optimizer_step_count=clipped,
            optimizer_step_count=steps,
        )


def test_history_row_records_complete_training_diagnostics() -> None:
    diagnostics = ENTRY._summarize_epoch_training_diagnostics(
        {1: [1.0, 5.0], 2: [2.0, 4.0], 3: [3.0, 3.0]},
        {1: 204, 2: 204, 3: 204},
        gradient_clipped_optimizer_step_count=1,
        optimizer_step_count=2,
        same_segment_step_replays=(
            _same_segment_replay(3.0, 2.0, step=1),
            _same_segment_replay(4.0, 3.0, step=2),
        ),
    )
    row = ENTRY._history_row(
        epoch=1,
        training_objective=3.0,
        validation=_validation(),
        parameter_sha256="2" * 64,
        optimizer_steps=2,
        forecast_events=612,
        gradient_names=("gain.weight",),
        maximum_gradient_norm_before_clip=12.0,
        training_diagnostics=diagnostics,
        prediction_sha256="3" * 64,
    )

    assert row[
        "training_mse_by_lead_physical_unit_mean_over_optimizer_steps"
    ] == {1: 3.0, 2: 3.0, 3: 3.0}
    assert row["training_sampled_finite_target_event_count_by_lead"] == {
        1: 204,
        2: 204,
        3: 204,
    }
    assert row["epoch_optimizer_step_count"] == 2
    assert row["gradient_clipped_optimizer_step_count"] == 1
    assert row["gradient_clipped_optimizer_step_fraction"] == 0.5
    assert row["optimizer_steps"] == 2
    assert row["sampled_forecast_events"] == 612

    event = ENTRY._epoch_completed_event(
        epoch=1,
        training_objective=3.0,
        checkpoint_selection_objective=9.0,
        gate_objective=7.0,
        checkpoint_sha256="5" * 64,
        parameter_sha256="2" * 64,
        optimizer_steps=2,
        sampled_forecast_events=612,
        training_diagnostics=diagnostics,
    )
    assert set(event) == {
        "event_type",
        "epoch",
        "training_objective",
        "checkpoint_selection_objective_728",
        "gate_objective_712",
        "checkpoint_sha256",
        "parameter_sha256",
        "optimizer_steps",
        "sampled_forecast_events",
        "training_mse_by_lead_physical_unit_mean_over_optimizer_steps",
        "training_sampled_finite_target_event_count_by_lead",
        "epoch_optimizer_step_count",
        "gradient_clipped_optimizer_step_count",
        "gradient_clipped_optimizer_step_fraction",
        "same_segment_post_step_replay_count",
        "same_segment_strict_objective_decrease_count",
        "same_segment_every_optimizer_step_strictly_decreased",
        "same_segment_before_step_objective_mean",
        "same_segment_after_step_objective_mean",
        "same_segment_objective_improvement_mean_before_minus_after",
        "same_segment_step_replays",
    }


def test_same_segment_post_step_evidence_uses_identical_forecast_targets() -> None:
    class FakeObservations:
        def __getitem__(self, key):
            indices, column = key
            assert column == 0
            return list(indices)

    class FakeFinite:
        def __init__(self, count: int) -> None:
            self.count = count

        def detach(self):
            return self

        def cpu(self):
            return self

        def tolist(self):
            return [True] * self.count

    fake_torch = SimpleNamespace(isfinite=lambda values: FakeFinite(len(values)))
    runtime = SimpleNamespace(
        training_days=2557,
        observations=FakeObservations(),
        dates=[f"day-{index}" for index in range(2557)],
    )
    before = SimpleNamespace(
        objective=4.0,
        mse_by_lead={1: 3.0, 2: 4.0, 3: 5.0},
        target_count_by_lead={1: 102, 2: 102, 3: 102},
    )
    after = SimpleNamespace(
        objective=3.0,
        mse_by_lead={1: 2.0, 2: 3.0, 3: 4.0},
        target_count_by_lead={1: 102, 2: 102, 3: 102},
    )

    evidence = ENTRY._same_segment_step_replay_evidence(
        before_step=before,
        after_step=after,
        runtime=runtime,
        start=1849,
        segment_days=150,
        filter_warmup_days=45,
        leads=(1, 2, 3),
        optimizer_step=1,
        torch_module=fake_torch,
    )

    assert evidence["segment_start_index_global_inclusive"] == 1849
    assert evidence["segment_end_index_global_exclusive"] == 1999
    assert evidence["scored_issue_first_date"] == "day-1894"
    assert evidence["scored_issue_last_date"] == "day-1995"
    assert evidence["strict_objective_decrease"] is True
    assert evidence["objective_improvement_before_minus_after"] == 1.0
    assert evidence["target_count_by_lead_before_step"] == {1: 102, 2: 102, 3: 102}
    assert evidence["target_count_by_lead_after_step"] == {1: 102, 2: 102, 3: 102}
    assert evidence["after_step_was_recomputed"] is True
    assert evidence["after_step_recomputed_under_no_grad"] is True
    assert evidence["reserved_evaluation_values_used"] == 0
    assert len(
        evidence["target_geometry_by_lead"][1]["target_index_sha256"]
    ) == 64


@pytest.mark.parametrize(
    ("key", "value", "expected_exception"),
    [
        ("training_epochs", 0, ValueError),
        ("training_epochs", True, ValueError),
        ("steps_per_epoch", 0, ValueError),
        ("learning_rate", 0.0, ValueError),
        ("learning_rate", float("nan"), ValueError),
        ("gradient_maximum_norm", 0.0, ValueError),
        ("gradient_maximum_norm", float("inf"), ValueError),
        ("gradient_maximum_norm", "10", TypeError),
    ],
)
def test_training_hyperparameters_fail_closed_before_numerical_imports(
    key: str,
    value: object,
    expected_exception: type[Exception],
) -> None:
    optimization: dict[str, object] = {
        "training_epochs": 2,
        "steps_per_epoch": 32,
        "learning_rate": 0.01,
        "gradient_maximum_norm": 10.0,
    }
    optimization[key] = value

    with pytest.raises(expected_exception):
        ENTRY._validate_training_hyperparameters(optimization)


def test_training_hyperparameters_accept_positive_finite_values() -> None:
    ENTRY._validate_training_hyperparameters(
        {
            "training_epochs": 2,
            "steps_per_epoch": 32,
            "learning_rate": 0.01,
            "gradient_maximum_norm": 10.0,
        }
    )


def test_fixed_full_training_coverage_plan_is_exact_and_complete() -> None:
    config = json.loads(
        (
            ROOT
            / "configs"
            / "daily_camels_knet_fixed_full_training_coverage_accumulation_a15.json"
        ).read_text(encoding="utf-8")
    )

    plan = ENTRY._configured_training_segment_plan(
        config["optimization"],
        training_days=2557,
        leads=(1, 2, 3),
    )

    assert plan["fixed_training_segment_start_indices"] == [
        0,
        100,
        201,
        301,
        401,
        501,
        602,
        702,
        802,
        903,
        1003,
        1103,
        1204,
        1304,
        1404,
        1504,
        1605,
        1705,
        1805,
        1906,
        2006,
        2106,
        2206,
        2307,
        2407,
    ]
    assert plan["minimum_segment_count_for_complete_coverage"] == 25
    assert plan["complete_eligible_issue_coverage"] is True
    assert plan["candidate_issue_count"] == 2550
    assert plan["unique_covered_issue_count"] == 2509
    assert plan["duplicate_issue_count"] == 41
    assert plan["uncovered_issue_count"] == 0
    assert plan["candidate_forecast_target_event_count_all_leads"] == 7650
    assert plan["total_candidate_forecast_target_event_count_all_epochs"] == 7650
    assert plan["expected_optimizer_step_count"] == 1
    assert plan["maximum_issue_multiplicity"] == 2
    assert len(plan["fixed_training_segment_start_indices_sha256"]) == 64
    assert len(plan["issue_multiplicity_sha256"]) == 64


@pytest.mark.parametrize(
    ("mutation", "expected_exception"),
    [
        ({"segments_per_optimizer_step": 24}, ValueError),
        ({"steps_per_epoch": 2}, ValueError),
        ({"fixed_training_segment_start_indices": [0, 1]}, ValueError),
        ({"training_segment_sampling": "unsupported"}, ValueError),
    ],
)
def test_fixed_training_coverage_contract_fails_closed(
    mutation: dict[str, object],
    expected_exception: type[Exception],
) -> None:
    config = json.loads(
        (
            ROOT
            / "configs"
            / "daily_camels_knet_fixed_full_training_coverage_accumulation_a15.json"
        ).read_text(encoding="utf-8")
    )
    config["optimization"].update(mutation)

    with pytest.raises(expected_exception):
        ENTRY._configured_training_segment_plan(
            config["optimization"],
            training_days=2557,
            leads=(1, 2, 3),
        )


def test_fixed_full_training_coverage_repeats_one_averaged_update_per_epoch() -> None:
    config = json.loads(
        (
            ROOT
            / "configs"
            / "daily_camels_knet_fixed_full_training_coverage_accumulation_a15.json"
        ).read_text(encoding="utf-8")
    )
    config["optimization"]["training_epochs"] = 10

    plan = ENTRY._configured_training_segment_plan(
        config["optimization"],
        training_days=2557,
        leads=(1, 2, 3),
    )

    assert plan["training_epochs"] == 10
    assert plan["steps_per_epoch"] == 1
    assert plan["expected_optimizer_step_count"] == 10
    assert plan["candidate_forecast_target_event_count_all_leads"] == 7650
    assert plan["total_candidate_forecast_target_event_count_all_epochs"] == 76500
    assert plan["complete_eligible_issue_coverage"] is True


def _training_segment_replay(
    *,
    start: int,
    before: float,
    after: float,
) -> dict[str, object]:
    return {
        "optimizer_step": 1,
        "segment_start_index_global_inclusive": start,
        "before_step_objective_physical_unit_multilead_mse": before,
        "after_step_objective_physical_unit_multilead_mse": after,
        "objective_improvement_before_minus_after": before - after,
        "strict_objective_decrease": after < before,
        "mse_by_lead_before_step": {
            1: before - 1.0,
            2: before,
            3: before + 1.0,
        },
        "mse_by_lead_after_step": {
            1: after - 1.0,
            2: after,
            3: after + 1.0,
        },
        "target_count_by_lead_before_step": {1: 102, 2: 102, 3: 102},
        "target_count_by_lead_after_step": {1: 102, 2: 102, 3: 102},
        "target_geometry_by_lead": {
            lead: {"start": start, "lead": lead} for lead in (1, 2, 3)
        },
        "identical_target_geometry_before_after": True,
        "after_step_was_recomputed": True,
        "after_step_recomputed_under_no_grad": True,
        "reserved_evaluation_values_used": 0,
    }


def test_multi_segment_replay_is_one_optimizer_step_with_aggregate_gate() -> None:
    evidence = ENTRY._same_training_batch_step_replay_evidence(
        (
            _training_segment_replay(start=0, before=4.0, after=3.0),
            _training_segment_replay(start=100, before=6.0, after=7.0),
        ),
        optimizer_step=1,
    )

    assert evidence["optimizer_step"] == 1
    assert evidence["training_segment_count"] == 2
    assert evidence["training_segment_start_indices"] == [0, 100]
    assert evidence["before_step_objective_physical_unit_multilead_mse"] == 5.0
    assert evidence["after_step_objective_physical_unit_multilead_mse"] == 5.0
    assert evidence["strict_objective_decrease"] is False
    assert evidence["training_segment_strict_objective_decrease_count"] == 1
    assert evidence["every_training_segment_strictly_decreased"] is False
    assert evidence["target_count_by_lead_before_step"] == {
        1: 204,
        2: 204,
        3: 204,
    }
    assert len(evidence["training_segment_replays"]) == 2

    diagnostics = ENTRY._summarize_epoch_training_diagnostics(
        {1: [4.0], 2: [5.0], 3: [6.0]},
        {1: 204, 2: 204, 3: 204},
        gradient_clipped_optimizer_step_count=0,
        optimizer_step_count=1,
        same_segment_step_replays=(evidence,),
    )
    assert diagnostics["same_segment_post_step_replay_count"] == 1
    assert diagnostics["epoch_optimizer_step_count"] == 1


def test_epoch_zero_reproducibility_anchor_fails_closed() -> None:
    configuration = {
        "epoch_zero_reproducibility": {
            "checkpoint_objective_728": 0.4,
            "parameter_sha256": "a" * 64,
            "prediction_sha256": "b" * 64,
        }
    }
    evidence = ENTRY._epoch_zero_reproducibility_evidence(
        configuration,
        objective=0.4,
        parameter_sha256="a" * 64,
        prediction_sha256="b" * 64,
    )
    assert evidence["status"] == "PASS"

    with pytest.raises(RuntimeError, match="objective"):
        ENTRY._epoch_zero_reproducibility_evidence(
            configuration,
            objective=0.41,
            parameter_sha256="a" * 64,
            prediction_sha256="b" * 64,
        )
    with pytest.raises(RuntimeError, match="parameter_sha256"):
        ENTRY._epoch_zero_reproducibility_evidence(
            configuration,
            objective=0.4,
            parameter_sha256="c" * 64,
            prediction_sha256="b" * 64,
        )
