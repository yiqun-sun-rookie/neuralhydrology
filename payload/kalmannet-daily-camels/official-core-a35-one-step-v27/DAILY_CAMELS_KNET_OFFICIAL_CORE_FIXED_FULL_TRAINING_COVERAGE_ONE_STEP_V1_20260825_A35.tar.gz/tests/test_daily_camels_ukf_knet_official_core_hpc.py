from __future__ import annotations

import copy
import importlib.util
import json
from pathlib import Path

import pytest

import scripts.build_daily_camels_ukf_knet_official_core_hpc_bundle as builder
import scripts.build_daily_camels_ukf_knet_parity_hpc_bundle as base_builder


ROOT = Path(__file__).resolve().parents[1]


def _load_preflight():
    path = ROOT / "hpc" / "daily_camels_ukf_knet_official_core" / "preflight.py"
    spec = importlib.util.spec_from_file_location("a35_test_preflight", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _load_verifier():
    path = ROOT / "hpc" / "daily_camels_ukf_knet_official_core" / "verify_result.py"
    spec = importlib.util.spec_from_file_location("a35_test_verifier", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_official_builder_is_deterministic_and_restores_base_globals(tmp_path: Path) -> None:
    original_sources = base_builder.FIXED_SOURCE_MEMBER_PATHS
    original_payloads = base_builder._payloads
    original_entry_integration_hashes = base_builder._entry_integration_hashes
    original_entry_integration_constants = base_builder.ENTRY_INTEGRATION_HASH_CONSTANTS
    first = builder.build_bundle(tmp_path / "first")
    assert base_builder.FIXED_SOURCE_MEMBER_PATHS is original_sources
    assert base_builder._payloads is original_payloads
    assert base_builder._entry_integration_hashes is original_entry_integration_hashes
    assert base_builder.ENTRY_INTEGRATION_HASH_CONSTANTS is original_entry_integration_constants
    second = builder.build_bundle(tmp_path / "second")
    assert first.archive_sha256 == second.archive_sha256
    assert first.archive_size == second.archive_size
    assert first.archive_path.read_bytes() == second.archive_path.read_bytes()


def test_official_bundle_inventory_and_manifest_are_fail_closed(tmp_path: Path) -> None:
    result = builder.build_bundle(tmp_path / "bundle")
    inspection = builder.inspect_archive(result.archive_path)
    manifest = inspection.manifest
    members = set(manifest["member_sha256"])
    required = set(builder.ADDITIONAL_SOURCE_MEMBER_PATHS)
    assert required.issubset(members)
    assert manifest["training_entry_member"] == builder.TRAINING_ENTRY_MEMBER
    assert manifest["official_core_identity"] == {
        "backend": builder.OFFICIAL_BACKEND_ID,
        "upstream_commit": builder.UPSTREAM_COMMIT,
        "upstream_source_member": builder.UPSTREAM_MEMBER,
        "upstream_source_sha256": builder.UPSTREAM_SHA256,
        "adapter_member": builder.OFFICIAL_ADAPTER_MEMBER,
        "adapter_sha256": builder.OFFICIAL_ADAPTER_SHA256,
        "runner_member": builder.OFFICIAL_RUNNER_MEMBER,
        "runner_sha256": builder.OFFICIAL_RUNNER_SHA256,
        "training_entry_sha256": builder.TRAINING_ENTRY_SHA256,
    }
    assert manifest["resource_admission_provenance"]["host_admission_min_bytes"] == 5_156_618_240
    assert manifest["resource_admission_provenance"]["gpu_admission_min_free_mib"] == 704
    assert manifest["input_archive_count"] == 1
    assert manifest["reserved_data_member_count"] == 0
    assert manifest["array_members_materialized_during_build"] == 0
    lowered = [name.lower() for name in members]
    assert not any("hourly" in name for name in lowered)
    assert not any("evaluation" in Path(name).parts for name in lowered)


def test_official_preflight_rejects_native_training_entry(tmp_path: Path) -> None:
    result = builder.build_bundle(tmp_path / "bundle")
    inspection = builder.inspect_archive(result.archive_path)
    preflight = _load_preflight()
    config = json.loads(
        inspection.payloads[inspection.manifest["active_config_member"]].decode("utf-8")
    )
    preflight.assert_official_bundle(inspection.manifest, config)
    changed = copy.deepcopy(inspection.manifest)
    changed["training_entry_member"] = "scripts/run_daily_camels_ukf_knet_parity.py"
    with pytest.raises(RuntimeError, match="operational member"):
        preflight.assert_official_bundle(changed, config)


def test_official_builder_rejects_source_identity_drift(monkeypatch: pytest.MonkeyPatch) -> None:
    payload = json.loads(builder.DEFAULT_CONFIG.read_text(encoding="utf-8"))
    payload["model"]["selected_kalmannet_commit"] = "0" * 40
    monkeypatch.setattr(builder, "_read_json", lambda _path: payload)
    with pytest.raises(ValueError, match="model identity differs"):
        builder._validate_official_config(builder.DEFAULT_CONFIG)


def test_official_builder_refuses_to_replace_different_destination(tmp_path: Path) -> None:
    destination = tmp_path / "bundle"
    destination.mkdir()
    (destination / "unrelated.txt").write_text("preserve me\n", encoding="utf-8")
    with pytest.raises(FileExistsError, match="different bundle directory"):
        builder.build_bundle(destination)
    assert (destination / "unrelated.txt").read_text(encoding="utf-8") == "preserve me\n"


def test_slurm_selects_only_official_entry_and_measured_resource_gate() -> None:
    source = (
        ROOT
        / "hpc"
        / "daily_camels_ukf_knet_official_core"
        / "submit_one_step_gpu.slurm"
    ).read_text(encoding="utf-8")
    assert "scripts/run_daily_camels_ukf_knet_official_core.py" in source
    assert "python -u scripts/run_daily_camels_ukf_knet_parity.py" not in source
    assert 'HOST_ADMISSION_MIN_BYTES="5156618240"' in source
    assert 'GPU_ADMISSION_MIN_FREE_MIB="704"' in source
    assert "--mem" not in source
    assert "--official-runtime-probe" in source
    assert "skipped_pytest_unavailable" not in source
    assert "verify_result.py" in source
    assert "kalmannet_daily_camels_official_core_a35_20260825" in source
    assert "memory.peak" in source
    assert "nvidia-smi" in source
    assert (
        "timestamp,uuid,name,memory.total_MiB,memory.used_MiB,"
        "memory.free_MiB,utilization.gpu_percent"
    ) in source
    assert "interrupted_evidence_preserved_not_resumable" in source
    assert "verified_scientific_fail" in source
    assert '"${TRAINING_EXIT_CODE}" -eq 2 && "${VERIFICATION_EXIT_CODE}" -eq 2' in source
    assert '"${OWNER_FILE}" "${EXPERIMENT_ID}" "$$"' in source
    assert '"shell_pid":os.getpid()' not in source


def test_config_loss_is_true_future_equal_lead_physical_mse() -> None:
    config = json.loads(builder.DEFAULT_CONFIG.read_text(encoding="utf-8"))
    assert config["forecast"]["leads_days"] == [1, 2, 3]
    assert config["optimization"]["training_objective"] == "physical_unit_multilead_mse"
    assert config["optimization"]["lead_weights"] == [1.0 / 3.0] * 3
    assert config["optimization"]["segments_per_optimizer_step"] == 25
    assert config["optimization"]["training_epochs"] == 1
    assert config["optimization"]["steps_per_epoch"] == 1
    assert config["gate"]["require_post_epoch_zero_improvement"] is True
    assert config["gate"]["minimum_nse_exclusive"] == 0.6


def test_verifier_rejects_epoch_zero_as_best() -> None:
    verifier = _load_verifier()
    with pytest.raises(ValueError, match="did not improve"):
        verifier._require_epoch_one_improvement(0.40, 0.40, 1.0e-6)
    with pytest.raises(ValueError, match="did not improve"):
        verifier._require_epoch_one_improvement(0.40, 0.41, 1.0e-6)
    verifier._require_epoch_one_improvement(0.40, 0.39, 1.0e-6)


def test_verifier_reads_external_gpu_used_memory_column(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    verifier = _load_verifier()
    gpu_log = tmp_path / "gpu.csv"
    gpu_log.write_text(
        "timestamp,uuid,name,memory.total_MiB,memory.used_MiB,"
        "memory.free_MiB,utilization.gpu_percent\n"
        "2026-08-25T00:00:00,GPU-1,NVIDIA A100,40960,321,40639,7\n",
        encoding="utf-8",
    )
    cgroup_log = tmp_path / "cgroup.txt"
    cgroup_log.write_text(
        "slurm_job_id=123\n"
        "process_cgroup_relative=/user.slice/example.scope\n"
        "current_memory_peak=123456\n",
        encoding="utf-8",
    )
    monkeypatch.setenv("SLURM_JOB_ID", "123")
    summary = {
        "resource_peaks": {
            "host_peak_rss_bytes": 123456,
            "graphics_peak_allocated_bytes": 1024,
            "graphics_peak_reserved_bytes": 2048,
        }
    }
    evidence = verifier._verify_resources(summary, gpu_log, cgroup_log)
    assert evidence["external_gpu_max_used_mib"] == 321
    assert evidence["ambient_cgroup_peak_bytes"] == 123456


def test_verifier_compares_checkpoint_and_json_history_after_key_normalization() -> None:
    verifier = _load_verifier()
    checkpoint_history = [{"nse_by_lead_after_warmup": {1: 0.7, 2: 0.6}}]
    json_history = [{"nse_by_lead_after_warmup": {"1": 0.7, "2": 0.6}}]
    assert checkpoint_history != json_history
    assert verifier._json_equivalent(checkpoint_history, json_history)
