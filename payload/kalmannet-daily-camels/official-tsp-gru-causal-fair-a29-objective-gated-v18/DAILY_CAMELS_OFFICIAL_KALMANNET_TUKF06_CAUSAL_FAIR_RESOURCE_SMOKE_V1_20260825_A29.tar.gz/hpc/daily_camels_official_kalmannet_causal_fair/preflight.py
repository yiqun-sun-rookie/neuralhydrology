#!/usr/bin/env python3
"""Fail-closed offline and scheduled-node checks for the A29 daily smoke."""

from __future__ import annotations

import argparse
import ctypes
from hashlib import sha256
import importlib
import json
import os
from pathlib import Path, PurePosixPath
import socket
import sys
from types import SimpleNamespace
from typing import Any


EXPERIMENT_ID = (
    "DAILY_CAMELS_OFFICIAL_KALMANNET_TUKF06_CAUSAL_FAIR_"
    "RESOURCE_SMOKE_V1_20260825_A29"
)
SCHEMA_VERSION = "daily_camels_official_kalmannet_causal_fair_hpc_bundle_v1"
RUN_DIRECTORY = Path(
    "/data1/home/sunyiq/"
    "kalmannet_daily_camels_official_tsp_gru_causal_fair_a29_20260825/"
    + EXPERIMENT_ID
)
PRIOR_KNET_HOST_PEAK_BYTES = 1_314_578_432
PRIOR_KNET_GPU_PEAK_BYTES = 31_475_200
MINIMUM_AVAILABLE_HOST_BYTES = 4 * PRIOR_KNET_HOST_PEAK_BYTES
MINIMUM_FREE_GPU_BYTES = 16 * PRIOR_KNET_GPU_PEAK_BYTES


def sha256_file(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_member(name: str) -> PurePosixPath:
    if "\\" in name:
        raise RuntimeError(f"bundle member uses a backslash: {name}")
    path = PurePosixPath(name)
    lowered = tuple(part.lower() for part in path.parts)
    if path.is_absolute() or not path.parts or ".." in path.parts:
        raise RuntimeError(f"unsafe bundle member: {name}")
    if (
        ".git" in lowered
        or "__pycache__" in lowered
        or any("hourly" in part for part in lowered)
        or any(part == "evaluation" or part.startswith("evaluation_") for part in lowered)
    ):
        raise RuntimeError(f"forbidden bundle member: {name}")
    return path


def _load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError(f"JSON root is not an object: {path}")
    return value


def verify_bundle_root(bundle_root: Path) -> dict[str, Any]:
    root = bundle_root.resolve()
    manifest_path = root / "bundle_manifest.json"
    if not root.is_dir() or not manifest_path.is_file():
        raise RuntimeError("bundle root or internal manifest is absent")
    manifest = _load_json(manifest_path)
    if (
        manifest.get("schema_version") != SCHEMA_VERSION
        or manifest.get("experiment_id") != EXPERIMENT_ID
        or manifest.get("purpose") != "daily_development_resource_smoke_only"
        or manifest.get("prepared_basin_count") != 21
        or manifest.get("reserved_data_member_count") != 0
        or manifest.get("future_derived_member_read_count") != 0
    ):
        raise RuntimeError("bundle identity or data-isolation policy differs")
    hashes = manifest.get("member_sha256")
    sizes = manifest.get("member_size")
    if not isinstance(hashes, dict) or not isinstance(sizes, dict) or set(hashes) != set(sizes):
        raise RuntimeError("bundle member hash and size inventories differ")
    actual = set()
    for path in root.rglob("*"):
        if path.is_symlink():
            raise RuntimeError(f"bundle contains a symbolic link: {path}")
        if path.is_file():
            actual.add(path.relative_to(root).as_posix())
    if actual != set(hashes) | {"bundle_manifest.json"}:
        raise RuntimeError("bundle file inventory differs")
    for name in sorted(hashes):
        relative = _safe_member(name)
        path = root.joinpath(*relative.parts)
        if not path.is_file() or path.stat().st_size != int(sizes[name]):
            raise RuntimeError(f"bundle member size differs: {name}")
        if sha256_file(path) != hashes[name]:
            raise RuntimeError(f"bundle member hash differs: {name}")

    prepared_manifest = _load_json(root / "inputs" / "prepared_manifest.json")
    if (
        prepared_manifest.get("calibration_only") is not True
        or prepared_manifest.get("evaluation_data_included") is not False
        or prepared_manifest.get("reserved_data_member_count") != 0
        or prepared_manifest.get("future_derived_member_read_count") != 0
        or prepared_manifest.get("basin_count") != 21
    ):
        raise RuntimeError("prepared input isolation evidence differs")
    expected_inputs = {
        "inputs/prepared_manifest.json",
        *{f"inputs/{basin_id}.npz" for basin_id in prepared_manifest["basin_ids"]},
    }
    if set(manifest.get("prepared_input_members", ())) != expected_inputs:
        raise RuntimeError("prepared input member inventory differs")
    return {
        "status": "BUNDLE_VERIFIED",
        "experiment_id": EXPERIMENT_ID,
        "member_count": len(hashes),
        "prepared_basin_count": 21,
        "reserved_data_member_count": 0,
        "future_derived_member_read_count": 0,
        "array_members_materialized": 0,
    }


def available_host_memory_bytes() -> int | None:
    path = Path("/proc/meminfo")
    if path.is_file():
        for line in path.read_text(encoding="ascii").splitlines():
            if line.startswith("MemAvailable:"):
                return int(line.split()[1]) * 1024
    if sys.platform == "win32":
        class MemoryStatus(ctypes.Structure):
            _fields_ = [
                ("length", ctypes.c_ulong),
                ("memory_load", ctypes.c_ulong),
                ("total_physical", ctypes.c_ulonglong),
                ("available_physical", ctypes.c_ulonglong),
                ("total_page_file", ctypes.c_ulonglong),
                ("available_page_file", ctypes.c_ulonglong),
                ("total_virtual", ctypes.c_ulonglong),
                ("available_virtual", ctypes.c_ulonglong),
                ("available_extended_virtual", ctypes.c_ulonglong),
            ]

        status = MemoryStatus()
        status.length = ctypes.sizeof(MemoryStatus)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            return int(status.available_physical)
    return None


def run_online_preflight(bundle_root: Path, run_directory: Path) -> dict[str, Any]:
    bundle = verify_bundle_root(bundle_root)
    if not os.environ.get("SLURM_JOB_ID"):
        raise RuntimeError("online preflight requires a scheduled Slurm job")
    if sys.version_info[:2] != (3, 11):
        raise RuntimeError(f"Python 3.11 is required, got {sys.version}")
    if run_directory.exists():
        raise FileExistsError(f"unique run directory already exists: {run_directory}")
    host_available = available_host_memory_bytes()
    if host_available is None or host_available < MINIMUM_AVAILABLE_HOST_BYTES:
        raise RuntimeError("host memory admission failed")

    numpy = importlib.import_module("numpy")
    torch = importlib.import_module("torch")
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError("exactly one visible CUDA device is required")
    gpu_free, gpu_total = torch.cuda.mem_get_info(0)
    if int(gpu_free) < MINIMUM_FREE_GPU_BYTES:
        raise RuntimeError("graphics-memory admission failed")

    root = bundle_root.resolve()
    for path in (root / "src", root):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))
    contract_module = importlib.import_module(
        "global_hydrology.experiments.hbv_shortlead_contract"
    )
    runner = importlib.import_module("global_hydrology.experiments.hbv_shortlead_runner")
    entry = importlib.import_module("scripts.run_hbv_native_shortlead_recovery")
    full_state = importlib.import_module(
        "global_hydrology.models.knet_native_hbvlite_full_state"
    )
    config_path = (
        root
        / "configs"
        / "daily_camels_official_kalmannet_tukf06_causal_fair_development_v3.json"
    )
    configuration = _load_json(config_path)
    contract = contract_module.ShortLeadContract.from_dict(configuration)
    if contract.verify_hashes(root):
        raise RuntimeError("trusted runtime source hashes differ")
    prepared = entry._prepared_input_manifest(
        root / "inputs",
        list(contract.training_basins),
        contract=contract,
        config_path=config_path,
    )
    expected_hashes = {
        record["basin_id"]: record["sha256"] for record in prepared["files"]
    }
    runner.configure_runtime_device("cuda")
    first_loaded = None
    for basin_id in contract.training_basins:
        loaded = runner.load_prepared_calibration_input(
            root / "inputs",
            basin_id,
            tuple(contract.periods.calibration),
            dtype=torch.float64,
            expected_sha256=expected_hashes[basin_id],
        )
        if first_loaded is None:
            first_loaded = loaded
    params, initial_storage, forcing, observations = first_loaded[:4]
    system, active_lag = full_state.build_padded_routed_system(
        params,
        maximum_lag=int(configuration["family"]["maximum_routing_lag"]),
        x0=initial_storage,
        dtype=torch.float64,
        device=torch.device("cuda"),
    )
    mask = full_state.correction_mask_for_active_lag(
        system.m, active_lag, dtype=torch.float64, device=torch.device("cuda")
    )
    reference = SimpleNamespace(
        system=system,
        initial_state=system.get_default_initial_state(),
        correction_mask=mask,
        state_lower_bound=torch.zeros(1, system.m, dtype=torch.float64, device="cuda"),
        state_upper_bound=torch.full(
            (1, system.m), torch.inf, dtype=torch.float64, device="cuda"
        ),
    )
    network = runner.build_shared_network(reference, configuration["family"])
    network.initialize_filter(reference.initial_state, 1)
    posterior = network.analysis_step(observations[:1], forcing[:1])
    if (
        posterior.dtype != torch.float64
        or next(network.parameters()).dtype != torch.float32
        or not bool(torch.isfinite(posterior).all())
        or bool(torch.count_nonzero(network.last_correction))
    ):
        raise RuntimeError("mixed-precision strict-zero integration probe differs")
    return {
        **bundle,
        "status": "PREFLIGHT_PASS",
        "python_version": sys.version,
        "numpy_version": numpy.__version__,
        "torch_version": torch.__version__,
        "hostname": socket.gethostname(),
        "slurm_job_id": os.environ["SLURM_JOB_ID"],
        "available_host_memory_bytes": host_available,
        "minimum_available_host_bytes": MINIMUM_AVAILABLE_HOST_BYTES,
        "cuda_device_name": torch.cuda.get_device_name(0),
        "cuda_free_bytes": int(gpu_free),
        "cuda_total_bytes": int(gpu_total),
        "minimum_free_gpu_bytes": MINIMUM_FREE_GPU_BYTES,
        "prior_related_knet_host_peak_bytes": PRIOR_KNET_HOST_PEAK_BYTES,
        "prior_related_knet_gpu_peak_bytes": PRIOR_KNET_GPU_PEAK_BYTES,
        "resource_admission_role": "provisional resource-calibration smoke",
        "prepared_archives_verified": 21,
        "physical_model_dtype": "float64",
        "gain_network_dtype": "float32",
        "strict_zero_probe_passed": True,
        "run_directory_absent": True,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle-root", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--run-directory", type=Path, default=RUN_DIRECTORY)
    parser.add_argument("--offline-bundle-check", action="store_true")
    arguments = parser.parse_args()
    try:
        report = (
            verify_bundle_root(arguments.bundle_root)
            if arguments.offline_bundle_check
            else run_online_preflight(arguments.bundle_root, arguments.run_directory)
        )
    except Exception as error:
        print(
            json.dumps(
                {
                    "status": "PREFLIGHT_FAIL",
                    "error_type": type(error).__name__,
                    "error": str(error),
                },
                sort_keys=True,
            ),
            flush=True,
        )
        return 1
    print(json.dumps(report, indent=2, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
