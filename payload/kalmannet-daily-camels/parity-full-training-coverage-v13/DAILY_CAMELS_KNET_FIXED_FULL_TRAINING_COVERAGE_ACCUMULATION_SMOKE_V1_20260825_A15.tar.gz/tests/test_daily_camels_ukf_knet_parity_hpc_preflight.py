from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import sys
from unittest.mock import patch

import pytest


ROOT = Path(__file__).resolve().parents[1]
PREFLIGHT_PATH = ROOT / "hpc" / "daily_camels_ukf_knet_parity" / "preflight.py"
MODULE_NAME = "daily_camels_ukf_knet_parity_hpc_preflight_standalone"
BUILDER_PATH = ROOT / "scripts" / "build_daily_camels_ukf_knet_parity_hpc_bundle.py"
BUILDER_MODULE_NAME = "daily_camels_ukf_knet_parity_hpc_builder_standalone"
TRAIN_SLURM_PATH = (
    ROOT / "hpc" / "daily_camels_ukf_knet_parity" / "submit_train_gpu.slurm"
)


def _load_preflight_module():
    numerical_before = {name: name in sys.modules for name in ("numpy", "torch")}
    spec = importlib.util.spec_from_file_location(MODULE_NAME, PREFLIGHT_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load daily parity HPC preflight")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    numerical_after = {name: name in sys.modules for name in ("numpy", "torch")}
    assert numerical_after == numerical_before
    return module


PREFLIGHT = _load_preflight_module()


def _load_builder_module():
    numerical_before = {name: name in sys.modules for name in ("numpy", "torch")}
    spec = importlib.util.spec_from_file_location(BUILDER_MODULE_NAME, BUILDER_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load daily parity HPC bundle builder")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    numerical_after = {name: name in sys.modules for name in ("numpy", "torch")}
    assert numerical_after == numerical_before
    return module


BUILDER = _load_builder_module()


def test_bundle_builder_requires_explicit_active_config() -> None:
    action = next(
        item for item in BUILDER.build_parser()._actions if item.dest == "config"
    )
    assert action.required is True
    assert action.default is None


def _training_config_with_replay_identities() -> dict[str, object]:
    path = (
        ROOT
        / "configs/daily_camels_knet_near_zero_strict_smoke_a12.json"
    )
    config = json.loads(path.read_text(encoding="utf-8"))
    config["replay_gate_requirements"] = {
        "exact": {
            "experiment_id": "EXACT_REPLAY_EXPERIMENT",
            "initialization_mode": "exact_tukf06_backward_time_diagnostic",
            "receipt_sha256": "1" * 64,
            "active_config_sha256": "2" * 64,
            "bundle_manifest_sha256": "3" * 64,
        },
        "causal": {
            "experiment_id": "CAUSAL_REPLAY_EXPERIMENT",
            "initialization_mode": "causal_shared_spinup",
            "receipt_sha256": "4" * 64,
            "active_config_sha256": "5" * 64,
            "bundle_manifest_sha256": "6" * 64,
        },
    }
    return config


def test_training_submission_requires_both_current_replay_gate_paths() -> None:
    source = TRAIN_SLURM_PATH.read_text(encoding="utf-8")

    assert source.count("${PARITY_EXACT_REPLAY_GATE") >= 2
    assert source.count("${PARITY_CAUSAL_REPLAY_GATE") >= 2
    assert "replay_gate_DAILY_CAMELS_UKF_PARITY_KNET_FULL_STATE_V1_20260824_A01" not in source
    assert '--exact-replay-gate "${PARITY_EXACT_REPLAY_GATE}"' in source
    assert '--causal-replay-gate "${PARITY_CAUSAL_REPLAY_GATE}"' in source
    assert '["replay_gate_requirements"]["exact"]["receipt_sha256"]' in source
    assert '["replay_gate_requirements"]["causal"]["receipt_sha256"]' in source
    assert 'ACTUAL_EXACT_GATE_SHA256' in source
    assert 'ACTUAL_CAUSAL_GATE_SHA256' in source


def test_training_submission_preserves_gpu_and_cgroup_resource_evidence() -> None:
    source = TRAIN_SLURM_PATH.read_text(encoding="utf-8")

    assert "train-gpu-resources-${EXPERIMENT_ID}-${SLURM_JOB_ID}.csv" in source
    assert "train-cgroup-resources-${EXPERIMENT_ID}-${SLURM_JOB_ID}.txt" in source
    assert "memory.peak" in source
    assert "memory.max" in source
    assert "GPU_RESOURCE_SAMPLER_PID" in source
    assert "nvidia-smi" in source
    assert '--id "${CUDA_VISIBLE_DEVICES}"' in source
    assert "sample_gpu_resources()" in source
    assert "while true; do" in source
    assert "sleep 1" in source
    assert "-lms" not in source


def test_training_submission_checks_resources_inside_allocated_job_before_entry() -> None:
    source = TRAIN_SLURM_PATH.read_text(encoding="utf-8")

    assert source.count("${PARITY_HOST_ADMISSION_MIN_BYTES}") >= 2
    assert source.count("${PARITY_GPU_ADMISSION_MIN_FREE_MIB}") >= 2
    assert '--host-admission-min-bytes "${PARITY_HOST_ADMISSION_MIN_BYTES}"' in source
    assert '--gpu-admission-min-free-mib "${PARITY_GPU_ADMISSION_MIN_FREE_MIB}"' in source
    assert source.index("--host-admission-min-bytes") < source.index(
        "scripts/run_daily_camels_ukf_knet_parity.py"
    )
    assert source.index("--gpu-admission-min-free-mib") < source.index(
        "scripts/run_daily_camels_ukf_knet_parity.py"
    )


def test_training_resource_admission_passes_only_above_both_node_local_thresholds() -> None:
    report = PREFLIGHT._resource_admission(
        phase="train",
        available_host_memory_bytes=2_800_353_280,
        cuda={"memory_free_mib": 822},
        host_admission_min_bytes=2_800_353_280,
        gpu_admission_min_free_mib=822,
    )

    assert report == {
        "required": True,
        "status": "PASS",
        "checked_on_allocated_training_node_before_training": True,
        "available_host_memory_bytes": 2_800_353_280,
        "host_admission_min_bytes": 2_800_353_280,
        "gpu_memory_free_mib": 822,
        "gpu_admission_min_free_mib": 822,
    }


@pytest.mark.parametrize(
    ("available_host", "gpu_free", "message"),
    [
        (2_800_353_279, 822, "host memory is below"),
        (2_800_353_280, 821, "GPU free memory is below"),
    ],
)
def test_training_resource_admission_fails_before_training_below_either_threshold(
    available_host: int,
    gpu_free: int,
    message: str,
) -> None:
    with pytest.raises(MemoryError, match=message):
        PREFLIGHT._resource_admission(
            phase="train",
            available_host_memory_bytes=available_host,
            cuda={"memory_free_mib": gpu_free},
            host_admission_min_bytes=2_800_353_280,
            gpu_admission_min_free_mib=822,
        )


def test_training_resource_admission_fails_closed_without_explicit_thresholds() -> None:
    with pytest.raises(PermissionError, match="explicit integer"):
        PREFLIGHT._resource_admission(
            phase="train",
            available_host_memory_bytes=2_800_353_280,
            cuda={"memory_free_mib": 822},
            host_admission_min_bytes=None,
            gpu_admission_min_free_mib=822,
        )


def test_training_config_requires_frozen_replay_gate_identities() -> None:
    config = _training_config_with_replay_identities()

    geometry = PREFLIGHT._validate_config(config, "train")

    assert set(geometry["replay_gate_requirements"]) == {"exact", "causal"}

    del config["replay_gate_requirements"]
    with pytest.raises(PermissionError, match="frozen exact and causal"):
        PREFLIGHT._validate_config(config, "train")


@pytest.mark.parametrize(
    ("section", "key", "value"),
    [
        ("model", "gain_initialization", "zero_gain"),
        ("optimization", "lead_weights", [0.5, 0.25, 0.25]),
    ],
)
def test_builder_and_node_preflight_reject_changed_gain_or_loss_contract(
    section: str,
    key: str,
    value: object,
) -> None:
    config = _training_config_with_replay_identities()
    target = config[section]
    assert isinstance(target, dict)
    target[key] = value

    with pytest.raises(RuntimeError):
        PREFLIGHT._validate_config(config, "train")
    with pytest.raises(ValueError):
        BUILDER._validate_config(config)


def test_builder_and_node_preflight_require_strict_zero_gain_baseline_gate() -> None:
    config = _training_config_with_replay_identities()
    gate = config["gate"]
    assert isinstance(gate, dict)
    gate["require_better_than_strict_zero_gain_each_lead"] = False

    with pytest.raises(PermissionError, match="every lead.*strict zero gain"):
        PREFLIGHT._validate_config(config, "train")
    with pytest.raises(ValueError, match="every lead.*strict zero gain"):
        BUILDER._validate_config(config)


def test_replay_gate_receipt_and_source_identity_are_verified(tmp_path: Path) -> None:
    gate_path = tmp_path / "replay_gate.json"
    gate = {
        "status": "REPLAY_PASS",
        "experiment_id": "EXACT_REPLAY_EXPERIMENT",
        "initialization_mode": "exact_tukf06_backward_time_diagnostic",
        "active_config_sha256": "2" * 64,
        "bundle_manifest_sha256": "3" * 64,
        "archive_sha256": "7" * 64,
        "selection_objective_target_count_per_lead": 728,
        "nse_gate_target_count_per_lead": 712,
        "pytest_exit_code": 77,
        "remote_test_status": "skipped_pytest_unavailable",
        "entry_exit_code": 0,
        "ukf_replay_contract_passed": True,
        "zero_gain_contract_passed": True,
    }
    gate_path.write_text(json.dumps(gate, sort_keys=True), encoding="utf-8")
    expected = {
        "experiment_id": gate["experiment_id"],
        "initialization_mode": gate["initialization_mode"],
        "receipt_sha256": PREFLIGHT.sha256_file(gate_path),
        "active_config_sha256": gate["active_config_sha256"],
        "bundle_manifest_sha256": gate["bundle_manifest_sha256"],
    }

    verified = PREFLIGHT._validate_replay_gate(
        gate_path,
        required_mode="exact_tukf06_backward_time_diagnostic",
        archive_sha256="7" * 64,
        expected_identity=expected,
    )
    assert verified["experiment_id"] == "EXACT_REPLAY_EXPERIMENT"

    gate["active_config_sha256"] = "8" * 64
    gate_path.write_text(json.dumps(gate, sort_keys=True), encoding="utf-8")
    with pytest.raises(PermissionError, match="not admissible"):
        PREFLIGHT._validate_replay_gate(
            gate_path,
            required_mode="exact_tukf06_backward_time_diagnostic",
            archive_sha256="7" * 64,
            expected_identity=expected,
        )


def test_historical_causal_config_selects_exact_replay_but_cannot_be_rebuilt(
    tmp_path: Path,
) -> None:
    exact = ROOT / "configs/daily_camels_ukf_knet_parity_exact_replay_dtype_repair_v3.json"
    causal = ROOT / "configs/daily_camels_ukf_knet_parity_causal_replay_dtype_repair_v3.json"

    sources, active_member, exact_member, experiment_id, mode = (
        BUILDER.bundle_member_sources(
            ROOT,
            config_path=causal,
            exact_config_path=exact,
        )
    )

    assert active_member == causal.relative_to(ROOT).as_posix()
    assert exact_member == exact.relative_to(ROOT).as_posix()
    assert active_member in sources
    assert exact_member in sources
    assert "configs/daily_camels_ukf_knet_parity_v1.json" not in sources
    assert experiment_id.endswith("20260825_A06")
    assert mode == "causal_shared_spinup"

    with pytest.raises(RuntimeError, match="active config source SHA-256 mismatch"):
        BUILDER.build_bundle(
            tmp_path / "historical_causal_bundle",
            config_path=causal,
            exact_config_path=exact,
            root=ROOT,
        )


def test_same_segment_diagnostic_bundle_uses_new_config_and_current_sources(
    tmp_path: Path,
) -> None:
    exact = ROOT / "configs/daily_camels_ukf_knet_parity_exact_replay_dtype_repair_v3.json"
    same_segment_diagnostic = (
        ROOT
        / "configs/daily_camels_knet_same_segment_post_step_diagnostic_a14.json"
    )

    result = BUILDER.build_bundle(
        tmp_path / "same_segment_diagnostic_bundle",
        config_path=same_segment_diagnostic,
        exact_config_path=exact,
        root=ROOT,
    )
    inspection = BUILDER.inspect_archive(result.archive_path)
    assert inspection.manifest[
        "active_config_member"
    ] == same_segment_diagnostic.relative_to(ROOT).as_posix()
    assert inspection.manifest["exact_replay_config_member"] == exact.relative_to(
        ROOT
    ).as_posix()
    assert inspection.manifest["experiment_id"].endswith("20260825_A14")


def test_a14_changes_only_identity_and_same_segment_diagnostic_evidence() -> None:
    a13_path = ROOT / "configs/daily_camels_knet_near_zero_stable_lr_strict_smoke_a13.json"
    a14_path = ROOT / "configs/daily_camels_knet_same_segment_post_step_diagnostic_a14.json"
    a13 = json.loads(a13_path.read_text(encoding="utf-8"))
    a14 = json.loads(a14_path.read_text(encoding="utf-8"))

    assert a13.pop("experiment_id").endswith("20260825_A13")
    assert a14.pop("experiment_id").endswith("20260825_A14")
    assert "stable_learning_rate" in a13.pop("scientific_role")
    assert "same_segment_post_step" in a14.pop("scientific_role")
    assert a14["optimization"].pop("same_segment_post_step_diagnostic") == (
        "fresh_no_grad_forward_on_identical_training_forecast_targets"
    )
    assert a14["gate"].pop("require_same_segment_post_step_improvement") is True

    assert a14 == a13


def test_full_training_coverage_bundle_uses_new_config_and_current_sources(
    tmp_path: Path,
) -> None:
    exact = ROOT / "configs/daily_camels_ukf_knet_parity_exact_replay_dtype_repair_v3.json"
    full_coverage = (
        ROOT
        / "configs/daily_camels_knet_fixed_full_training_coverage_accumulation_a15.json"
    )

    result = BUILDER.build_bundle(
        tmp_path / "full_training_coverage_bundle",
        config_path=full_coverage,
        exact_config_path=exact,
        root=ROOT,
    )
    inspection = BUILDER.inspect_archive(result.archive_path)
    assert inspection.manifest["active_config_member"] == full_coverage.relative_to(
        ROOT
    ).as_posix()
    assert inspection.manifest["experiment_id"].endswith("20260825_A15")


def test_a15_changes_only_identity_training_coverage_and_epoch_zero_anchor() -> None:
    a14_path = ROOT / "configs/daily_camels_knet_same_segment_post_step_diagnostic_a14.json"
    a15_path = (
        ROOT
        / "configs/daily_camels_knet_fixed_full_training_coverage_accumulation_a15.json"
    )
    a14 = json.loads(a14_path.read_text(encoding="utf-8"))
    a15 = json.loads(a15_path.read_text(encoding="utf-8"))

    assert a14.pop("experiment_id").endswith("20260825_A14")
    assert a15.pop("experiment_id").endswith("20260825_A15")
    assert "same_segment_post_step" in a14.pop("scientific_role")
    assert "fixed_full_training_coverage" in a15.pop("scientific_role")
    assert a15.pop("epoch_zero_reproducibility") == {
        "checkpoint_objective_728": 0.40192019589669764,
        "parameter_sha256": (
            "b4a375c3195cae48c984e9a18cd470746950fda5a5aceec60b6e594f1a352645"
        ),
        "prediction_sha256": (
            "17a6f0dbbe145b0262e0b2c1f426c49f1687a29927e8f8348f6ea293e246d91f"
        ),
    }
    assert a15["optimization"].pop("training_segment_sampling") == (
        "fixed_full_training_coverage_round_half_up"
    )
    assert a15["optimization"].pop("segments_per_optimizer_step") == 25
    assert a15["optimization"].pop("fixed_training_segment_start_indices") == [
        0,
        100,
        201,
        301,
        401,
        501,
        602,
        702,
        802,
        903,
        1003,
        1103,
        1204,
        1304,
        1404,
        1504,
        1605,
        1705,
        1805,
        1906,
        2006,
        2106,
        2206,
        2307,
        2407,
    ]
    assert a15["optimization"].pop("same_training_batch_post_step_diagnostic") == (
        "fresh_no_grad_forward_on_identical_25_segment_aggregate_forecast_targets"
    )

    assert a15 == a14


def test_pytest_is_optional_but_scientific_runtime_packages_are_required() -> None:
    def fake_find_spec(module: str):
        return None if module == "pytest" else object()

    with patch.object(
        PREFLIGHT.importlib.util, "find_spec", side_effect=fake_find_spec
    ), patch.object(
        PREFLIGHT.importlib.metadata,
        "version",
        side_effect=lambda distribution: f"test-{distribution}",
    ):
        report = PREFLIGHT._package_availability()

    assert report["numpy"] == {
        "available": True,
        "required_for_scientific_runtime": True,
        "version": "test-numpy",
    }
    assert report["torch"] == {
        "available": True,
        "required_for_scientific_runtime": True,
        "version": "test-torch",
    }
    assert report["pytest"] == {
        "available": False,
        "required_for_scientific_runtime": False,
        "version": None,
    }


def test_missing_scientific_runtime_package_still_fails_closed() -> None:
    with patch.object(
        PREFLIGHT.importlib.util,
        "find_spec",
        side_effect=lambda module: None if module == "numpy" else object(),
    ):
        with pytest.raises(RuntimeError, match="required package.*numpy"):
            PREFLIGHT._package_availability()


@pytest.mark.parametrize(
    ("exit_code", "available", "expected"),
    [
        (0, True, "passed"),
        (77, False, "skipped_pytest_unavailable"),
    ],
)
def test_remote_test_attestation_is_explicit(
    exit_code: int,
    available: bool,
    expected: str,
) -> None:
    status = PREFLIGHT._remote_test_attestation(
        exit_code,
        {"pytest": {"available": available}},
    )

    assert status == expected


@pytest.mark.parametrize(
    ("exit_code", "available"),
    [(0, False), (77, True), (1, True), (1, False)],
)
def test_remote_test_attestation_rejects_ambiguous_or_failed_states(
    exit_code: int,
    available: bool,
) -> None:
    with pytest.raises(RuntimeError, match="availability disagree"):
        PREFLIGHT._remote_test_attestation(
            exit_code,
            {"pytest": {"available": available}},
        )
