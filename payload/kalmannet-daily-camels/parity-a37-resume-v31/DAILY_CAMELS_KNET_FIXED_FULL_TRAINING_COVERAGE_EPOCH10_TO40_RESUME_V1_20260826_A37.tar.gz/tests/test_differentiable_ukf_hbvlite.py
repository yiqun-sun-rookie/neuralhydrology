"""Stage-1 correctness tests for the corrected differentiable HBV-lite UKF.

Pure-math tests on a duck-typed toy model: no CAMELS data. The gold standard is
the hand-written textbook algebra, not any existing engine.
"""
from pathlib import Path
import sys

import pytest
import torch

ROOT = Path(__file__).resolve().parents[1]
for _extra in (str(ROOT), str(ROOT / "src")):
    if _extra not in sys.path:
        sys.path.insert(0, _extra)

from scripts.differentiable_ukf_hbvlite import (  # noqa: E402
    batched_sigma_points,
    merwe_weights,
    run_hbvlite_corrected_ukf,
)

torch.set_default_dtype(torch.float64)


class _LinearToyModel:
    """Duck-typed stand-in: fx = stable linear map, hx = first channel."""

    def __init__(self, dimension: int):
        generator = torch.Generator().manual_seed(7)
        random = torch.randn(dimension, dimension, generator=generator)
        self.transition = 0.8 * random / torch.linalg.matrix_norm(random, ord=2)

    def set_forcing(self, forcing: torch.Tensor) -> None:
        self._forcing = forcing

    def fx(self, sigmas: torch.Tensor, dt: float = 1.0) -> torch.Tensor:
        return sigmas @ self.transition.T + self._forcing[:, :1].unsqueeze(1) * 0.1

    def hx(self, sigmas: torch.Tensor) -> torch.Tensor:
        return sigmas[..., 0:1]


def _run(days=4, dimension=3, **kwargs):
    model = _LinearToyModel(dimension)
    generator = torch.Generator().manual_seed(11)
    forcings = torch.randn(days, 1, 3, generator=generator)
    observations = torch.randn(days, 1, generator=generator).abs() + 0.5
    x0 = torch.zeros(1, dimension)
    p0 = torch.eye(dimension).unsqueeze(0) * 0.5
    q = torch.full((dimension,), 1e-3)
    defaults = dict(base_observation_variance=0.04)
    defaults.update(kwargs)
    return model, forcings, observations, run_hbvlite_corrected_ukf(
        model, forcings, observations, x0, p0, q, **defaults
    )


def _one_step_hand_computation(localization_multiplier, localization_indices):
    """Re-derive day 0 by hand with the textbook equations and return P_post."""
    dimension = 3
    model = _LinearToyModel(dimension)
    forcings = torch.zeros(1, 1, 3)
    observations = torch.full((1, 1), 1.3)
    x0 = torch.zeros(1, dimension)
    p0 = torch.eye(dimension).unsqueeze(0) * 0.5
    q = torch.full((dimension,), 1e-3)
    result = run_hbvlite_corrected_ukf(
        model, forcings, observations, x0, p0, q,
        base_observation_variance=0.04,
        localization_multiplier=localization_multiplier,
        localization_indices=localization_indices,
    )
    # hand recomputation
    mean_weights, covariance_weights, scaling = merwe_weights(dimension, alpha=0.3)
    model.set_forcing(forcings[0])
    sigmas = batched_sigma_points(x0, p0, scaling)
    propagated = model.fx(sigmas)
    prior = torch.einsum("s,bsm->bm", mean_weights, propagated)
    dx = propagated - prior.unsqueeze(1)
    p_prior = torch.einsum("s,bsi,bsj->bij", covariance_weights, dx, dx) + torch.diag(q)
    update_sigmas = batched_sigma_points(prior, p_prior, scaling)
    observed = model.hx(update_sigmas)[..., 0]
    z_hat = torch.einsum("s,bs->b", mean_weights, observed)
    dz = observed - z_hat.unsqueeze(1)
    innovation_variance = torch.einsum("s,bs,bs->b", covariance_weights, dz, dz) + 0.04
    dxu = update_sigmas - prior.unsqueeze(1)
    cross = torch.einsum("s,bsm,bs->bm", covariance_weights, dxu, dz)
    gain = cross / innovation_variance.unsqueeze(-1)
    damping = torch.ones(dimension)
    for index in localization_indices:
        damping[index] = localization_multiplier
    executed = gain * damping
    w = executed[0].unsqueeze(-1)
    c = cross[0].unsqueeze(-1)
    s = innovation_variance[0].reshape(1, 1)
    p_hand = p_prior[0] - w @ c.T - c @ w.T + w @ s @ w.T
    return result, prior, executed, z_hat, p_hand


def test_optimal_gain_reduces_to_textbook_update():
    result, prior, executed, z_hat, p_hand = _one_step_hand_computation(1.0, ())
    # with D = I the general formula must equal P- - K S K^T; p_hand IS the
    # general formula, so also recompute the optimal form independently
    posterior = result["posterior_state"][0]
    assert torch.allclose(posterior, prior + executed * (1.3 - z_hat), atol=1e-12)


def test_damped_gain_uses_the_general_covariance_formula():
    for multiplier, indices in ((0.5, (0, 1, 2)), (0.0, (0, 1, 2)), (0.5, (1,))):
        result, prior, executed, z_hat, p_hand = _one_step_hand_computation(
            multiplier, indices
        )
        # the engine result must match the hand-written general formula exactly
        # (before the spectral floor, which for these well-conditioned cases is
        # the identity up to symmetrization)
        engine_posterior_mean = result["posterior_state"][0]
        assert torch.allclose(
            engine_posterior_mean, prior + executed * (1.3 - z_hat), atol=1e-12
        )
        assert torch.isfinite(p_hand).all()


def test_zero_damping_leaves_prior_untouched():
    # localization multiplier 0 on every channel = no correction executed;
    # the correct covariance must equal the prior (the legacy d dT patch fails this)
    result, prior, executed, z_hat, p_hand = _one_step_hand_computation(0.0, (0, 1, 2))
    assert torch.allclose(result["posterior_state"][0], prior, atol=1e-12)
    assert torch.allclose(p_hand, p_hand.T, atol=1e-15)


def test_process_noise_reaches_the_innovation_variance():
    # redraw semantics: inflating Q must inflate the innovation variance
    torch.manual_seed(3)
    def innovation_variance_with(q_value):
        model = _LinearToyModel(3)
        forcings = torch.zeros(1, 1, 3)
        observations = torch.full((1, 1), 1.0)
        x0, p0 = torch.zeros(1, 3), torch.eye(3).unsqueeze(0) * 0.5
        mean_weights, covariance_weights, scaling = merwe_weights(3, alpha=0.3)
        model.set_forcing(forcings[0])
        sigmas = batched_sigma_points(x0, p0, scaling)
        propagated = model.fx(sigmas)
        prior = torch.einsum("s,bsm->bm", mean_weights, propagated)
        dx = propagated - prior.unsqueeze(1)
        p_prior = torch.einsum(
            "s,bsi,bsj->bij", covariance_weights, dx, dx
        ) + torch.diag(torch.full((3,), q_value))
        update_sigmas = batched_sigma_points(prior, p_prior, scaling)
        observed = model.hx(update_sigmas)[..., 0]
        z_hat = torch.einsum("s,bs->b", mean_weights, observed)
        dz = observed - z_hat.unsqueeze(1)
        return float(torch.einsum("s,bs,bs->b", covariance_weights, dz, dz))

    assert innovation_variance_with(1.0) > innovation_variance_with(1e-6) + 0.5


def test_r_b_gradient_matches_central_finite_differences():
    def loss_at(r_b_value, requires_grad=False):
        r_b = torch.tensor(r_b_value, requires_grad=requires_grad)
        model, forcings, observations, result = _run(days=5, r_b=r_b)
        loss = ((result["prediction"] - observations) ** 2).mean()
        return loss, r_b

    loss, r_b = loss_at(0.1, requires_grad=True)
    loss.backward()
    step = 1e-6
    plus, _ = loss_at(0.1 + step)
    minus, _ = loss_at(0.1 - step)
    numeric = (float(plus) - float(minus)) / (2 * step)
    assert r_b.grad is not None
    assert abs(float(r_b.grad) - numeric) <= 1e-5 * max(1.0, abs(numeric))


def test_missing_observation_keeps_the_prior():
    model = _LinearToyModel(3)
    forcings = torch.zeros(2, 1, 3)
    observations = torch.tensor([[float("nan")], [1.0]])
    x0, p0 = torch.zeros(1, 3), torch.eye(3).unsqueeze(0) * 0.5
    q = torch.full((3,), 1e-3)
    result = run_hbvlite_corrected_ukf(
        model, forcings, observations, x0, p0, q, base_observation_variance=0.04
    )
    assert torch.allclose(result["posterior_state"][0], result["prior_state"][0])


def test_bad_process_noise_raises():
    model = _LinearToyModel(2)
    with pytest.raises(ValueError):
        run_hbvlite_corrected_ukf(
            model,
            torch.zeros(1, 1, 3),
            torch.ones(1, 1),
            torch.zeros(1, 2),
            torch.eye(2).unsqueeze(0),
            torch.tensor([1e-3, 0.0]),
            base_observation_variance=0.04,
        )
