"""Shared fixtures for latent_da tests."""
import sys
from pathlib import Path

_root = Path(__file__).resolve().parent.parent
# Allow both `from src.global_hydrology...` and `from global_hydrology...`
sys.path.insert(0, str(_root))
sys.path.insert(0, str(_root / "src"))
