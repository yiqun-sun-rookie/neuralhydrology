"""Sole fail-closed command for the daily shared-loss KalmanNet smoke.

Importing this file uses only the Python standard library.  Configuration,
source, input-byte, target, protected-owner, and resume identity checks all run
before any NumPy or PyTorch import.  Any drift in the required training/data
interfaces is detected from source text and stops execution before an array is
opened.
"""

from __future__ import annotations

import argparse
import ast
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from hashlib import sha256
import importlib
import importlib.util
import json
import math
import os
from pathlib import Path, PurePosixPath
import random
import re
import struct
import sys
from types import ModuleType
from typing import Any, Callable, Iterable, Mapping, Sequence


EXPERIMENT_ID = (
    "DAILY_CAMELS_NATIVE_KALMANNET_MASKED_NSE_SMOKE_V3_20260825_A20"
)
SCHEMA_VERSION = "daily_camels_native_kalmannet_masked_nse_smoke_v3"
FROZEN_CONFIGURATION_NAME = (
    "daily_camels_native_kalmannet_masked_nse_smoke_v3.json"
)
CHECKPOINT_MAGIC = b"DAILY_CAMELS_NATIVE_KNET_RESUME_V1\n"
CHECKPOINT_HEADER_LENGTH = struct.Struct(">Q")
MAX_CHECKPOINT_HEADER_BYTES = 1024 * 1024
RUNTIME_IO_ALIAS = "_daily_camels_native_knet_io_preflight"

IDENTITY_FILE = "experiment_identity.json"
ACCESS_LEDGER_FILE = "access_ledger.json"
TRAINING_SCALE_EVIDENCE_FILE = "training_scale_evidence.json"
EVENT_FILE = "events.jsonl"
CHECKPOINT_DIRECTORY = "checkpoints"
EPOCH_ZERO_CHECKPOINT = "epoch_000.pt"
SUMMARY_FILE = "result_summary.json"
MANIFEST_FILE = "manifest.sha256.json"
COMPLETION_FILE = "completion.marker.json"
OWNER_LOCK_DIRECTORY = ".owner.lock"

RESULT_CELL_EVIDENCE_FIELDS = frozenset(
    {"event_count", "physical_mse", "primary_loss"}
)
TRAINING_EVENTS_PER_BASIN_LEAD = 45
VALIDATION_EVENTS_PER_BASIN_LEAD = 109
TRAINING_STATISTICS_STOP_INDEX_EXCLUSIVE = 2557
LOSS_EPSILON_ORIGINAL_DISCHARGE_UNITS = 0.1

EXPECTED_SOURCE_SHA256 = {
    "knet/dl/nn_kalman_clamp_5.py": (
        "934570d3c840e9d57b8fbddf3a018dc29e190cdd712fc9daaf442e383f74d843"
    ),
    "src/global_hydrology/models/knet_native_hbvlite.py": (
        "df0ccc3249022cafddb2048a97d5198f32569a58a7d4e43029a9514cc340208b"
    ),
    "src/global_hydrology/models/hbvlite_system_model.py": (
        "0d32d0f8dc656bdfbea81ba9f61eba0775ecc770d4466ff0442597d7c8d7a597"
    ),
    "src/global_hydrology/models/differentiable_hbv_lite.py": (
        "d7a04be86f19cddd8b9703e432fafb999a38215cb85de8983fe39a40bda0d6ea"
    ),
}

EVIDENCE_SOURCE_PATHS = (
    "scripts/run_daily_camels_native_kalmannet_masked_nse.py",
    "src/global_hydrology/experiments/daily_camels_native_knet_masked_nse_contract.py",
    "src/global_hydrology/experiments/daily_camels_native_knet_masked_nse_data.py",
    "src/global_hydrology/experiments/daily_camels_native_knet_masked_nse_training.py",
    "src/global_hydrology/experiments/daily_camels_masked_nse_loss_contract.py",
    "src/global_hydrology/experiments/daily_camels_masked_nse_loss_torch.py",
    "src/global_hydrology/experiments/daily_camels_native_knet_io.py",
)

EXPECTED_INPUT_ARCHIVES = (
    {
        "basin_id": "04105700",
        "path": "inputs/basin_04105700.npz",
        "local_evidence_path": (
            "results/tukf06_full_diagonal_search_head_to_head_v1/"
            "selection_inputs/basin_04105700.npz"
        ),
        "sha256": (
            "08d7e8930cd4df624efaf578bedd9615d238f51901ee2a1054bd0e8503e0f82e"
        ),
    },
    {
        "basin_id": "09035800",
        "path": "inputs/basin_09035800.npz",
        "local_evidence_path": (
            "results/tukf06_full_diagonal_search_head_to_head_v1/"
            "selection_inputs/basin_09035800.npz"
        ),
        "sha256": (
            "71e6d163507ae405204bedf63d2c6c06e2c3ea303cea1a0481cfa4d5f280f5fd"
        ),
    },
)

EXPECTED_PROTECTED_OWNER_PATHS = (
    "results/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1/"
    "control/.sequence_controller.lock/owner.json",
    "results/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1/"
    "control/.training_phase.lock/owner.json",
    "results/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1/"
    "control/.filter_controller.lock/owner.json",
)

CHECKPOINT_NAME = re.compile(r"epoch_[0-9]{3,}\.pt\Z")


@dataclass(frozen=True)
class PreflightResult:
    configuration_path: Path
    repository_root: Path
    configuration: Mapping[str, object]
    configuration_sha256: str
    source_sha256: Mapping[str, str]
    input_archive_sha256: Mapping[str, str]
    input_paths: Mapping[str, Path]
    run_directory: Path
    resume_checkpoint: Path | None
    identity: Mapping[str, object]
    identity_sha256: str
    protected_owner_records: tuple[Mapping[str, object], ...]
    resource_hold: bool


def canonical_json_bytes(value: object) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
        + b"\n"
    )


def _identity_canonical_bytes(value: object) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def sha256_file(path: Path) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _normalize_sha256(value: object, label: str) -> str:
    if not isinstance(value, str):
        raise TypeError(f"{label} must be a SHA-256 string")
    lowered = value.lower()
    if len(lowered) != 64 or any(character not in "0123456789abcdef" for character in lowered):
        raise ValueError(f"{label} must contain exactly 64 hexadecimal characters")
    return lowered


def _relative_path(value: object, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise TypeError(f"{label} must be a non-empty relative path")
    if "\\" in value:
        raise ValueError(f"{label} must use forward slashes")
    path = PurePosixPath(value)
    if path.is_absolute() or ".." in path.parts or not path.parts:
        raise ValueError(f"{label} must stay below the experiment root")
    return path.as_posix()


def _mapping(value: object, label: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{label} must be a JSON object")
    return value


def _require_exact_members(
    value: Mapping[str, object],
    expected: Iterable[str],
    label: str,
) -> None:
    expected_set = set(expected)
    if set(value) != expected_set:
        missing = sorted(expected_set - set(value))
        extra = sorted(set(value) - expected_set)
        raise ValueError(f"{label} member set changed; missing={missing}, extra={extra}")


def _require_equal(actual: object, expected: object, label: str) -> None:
    if actual != expected:
        raise ValueError(f"{label} must remain {expected!r}; received {actual!r}")


def validate_exact_config(payload: Mapping[str, object]) -> None:
    """Validate every frozen scientific and operational setting exactly."""

    top = _mapping(payload, "configuration")
    _require_exact_members(
        top,
        {
            "schema_version",
            "experiment_id",
            "data",
            "periods",
            "forecast",
            "scientific_limitations",
            "model",
            "loss_contract",
            "checkpoint_selection",
            "training",
            "gates",
            "source_sha256",
            "protected_formal_training",
        },
        "configuration",
    )
    _require_equal(top["schema_version"], SCHEMA_VERSION, "schema_version")
    _require_equal(top["experiment_id"], EXPERIMENT_ID, "experiment_id")

    data = _mapping(top["data"], "data")
    _require_exact_members(
        data,
        {
            "cadence",
            "forcing_columns",
            "archive_members",
            "expected_days",
            "input_archives",
        },
        "data",
    )
    _require_equal(data["cadence"], "daily", "data.cadence")
    _require_equal(
        data["forcing_columns"],
        [
            "precipitation_mm_per_day",
            "mean_temperature_degrees_celsius",
            "oudin_potential_evapotranspiration_mm_per_day",
        ],
        "data.forcing_columns",
    )
    _require_equal(
        data["archive_members"],
        ["dates_ns", "forcing", "observations", "parameters"],
        "data.archive_members",
    )
    _require_equal(data["expected_days"], 3288, "data.expected_days")
    archives = data["input_archives"]
    if not isinstance(archives, list):
        raise TypeError("data.input_archives must be a JSON array")
    _require_equal(archives, list(EXPECTED_INPUT_ARCHIVES), "data.input_archives")
    for index, archive in enumerate(archives):
        item = _mapping(archive, f"data.input_archives[{index}]")
        _require_exact_members(
            item,
            {"basin_id", "path", "local_evidence_path", "sha256"},
            f"data.input_archives[{index}]",
        )
        _relative_path(item["path"], f"data.input_archives[{index}].path")
        _relative_path(
            item["local_evidence_path"],
            f"data.input_archives[{index}].local_evidence_path",
        )
        _normalize_sha256(item["sha256"], f"data.input_archives[{index}].sha256")

    periods = _mapping(top["periods"], "periods")
    _require_equal(
        dict(periods),
        {
            "development": ["1999-10-01", "2008-09-30"],
            "training_end": "2006-09-30",
            "validation_start": "2006-10-01",
        },
        "periods",
    )
    forecast = _mapping(top["forecast"], "forecast")
    _require_equal(
        dict(forecast),
        {
            "leads_days": [1, 2, 3],
            "information_timing": "perfect_future_meteorological_forcing",
        },
        "forecast",
    )
    limitations = _mapping(top["scientific_limitations"], "scientific_limitations")
    _require_equal(
        dict(limitations),
        {
            "physical_parameter_provenance": (
                "frozen_hbv_parameters_previously_calibrated_using_the_full_"
                "development_period"
            ),
            "forecast_interpretation": (
                "retrospective_perfect_future_meteorological_forcing_not_"
                "operational_forecasting"
            ),
        },
        "scientific_limitations",
    )

    model = _mapping(top["model"], "model")
    _require_equal(
        dict(model),
        {
            "output_dimension": 5,
            "corrected_storage_names": [
                "snow",
                "meltwater",
                "soil_water",
                "upper_groundwater",
                "lower_groundwater",
            ],
            "static_attributes_enabled": False,
            "residual_memory_order": 0,
            "preset_residual_gain_enabled": False,
            "correction_cap_enabled": False,
            "learned_physical_parameters_enabled": False,
            "hidden_dimension": 32,
            "input_multiplier": 10,
            "output_multiplier": 10,
            "normalized_feature_guard": 10.0,
            "state_upper_bound_multiplier": 2.0,
            "zero_gain_initialization": True,
        },
        "model",
    )
    loss_contract = _mapping(top["loss_contract"], "loss_contract")
    _require_equal(
        dict(loss_contract),
        {
            "contract_name": (
                "daily_camels_physical_masked_nse_equal_basin_lead_v2"
            ),
            "formula": (
                "mean_equal_complete_basin_lead_events((prediction_physical-"
                "target_physical)^2/"
                "(basin_training_population_std_original_units+0.1)^2)"
            ),
            "training_statistics_start_index": 0,
            "training_statistics_stop_index_exclusive": 2557,
            "population_standard_deviation_ddof": 0,
            "loss_epsilon_original_discharge_units": 0.1,
            "weighting_order": [
                "equal_events_within_each_basin_and_lead",
                "equal_leads_1_2_3_within_each_basin",
                "equal_basins",
            ],
            "target_noise": "none_for_kalmannet_filter_training",
            "tukf09_compatibility_diagnostic": (
                "primary_loss/global_training_population_std^2"
            ),
            "result_cell_evidence": {
                "fields": ["event_count", "physical_mse", "primary_loss"],
                "training_events_per_basin_lead": (
                    TRAINING_EVENTS_PER_BASIN_LEAD
                ),
                "validation_events_per_basin_lead": (
                    VALIDATION_EVENTS_PER_BASIN_LEAD
                ),
            },
        },
        "loss_contract",
    )
    checkpoint_selection = _mapping(
        top["checkpoint_selection"], "checkpoint_selection"
    )
    _require_equal(
        dict(checkpoint_selection),
        {
            "metric": "negative_shared_masked_nse_validation_loss",
            "direction": "maximize",
        },
        "checkpoint_selection",
    )
    training = _mapping(top["training"], "training")
    _require_equal(
        dict(training),
        {
            "spinup_days": 365,
            "segment_days": 64,
            "filter_warmup_days": 16,
            "validation_window_days": 128,
            "epochs": 4,
            "steps_per_epoch": 2,
            "seed": 20260825,
            "optimizer": "Adam",
            "learning_rate": 0.0005,
            "weight_decay": 0.00001,
            "gradient_maximum_norm": 10.0,
        },
        "training",
    )
    gates = _mapping(top["gates"], "gates")
    _require_equal(
        dict(gates),
        {
            "minimum_post_zero_improvement": 0.000001,
            "require_finite_nonzero_gradients": True,
            "maximum_routed_queue_correction_absolute": 0.0,
            "require_zero_reserved_data_access": True,
        },
        "gates",
    )
    source_hashes = _mapping(top["source_sha256"], "source_sha256")
    _require_equal(dict(source_hashes), EXPECTED_SOURCE_SHA256, "source_sha256")
    protected = _mapping(top["protected_formal_training"], "protected_formal_training")
    _require_exact_members(protected, {"owner_paths"}, "protected_formal_training")
    _require_equal(
        protected["owner_paths"],
        list(EXPECTED_PROTECTED_OWNER_PATHS),
        "protected_formal_training.owner_paths",
    )
    for index, relative in enumerate(protected["owner_paths"]):
        _relative_path(relative, f"protected_formal_training.owner_paths[{index}]")


def _reject_duplicate_members(pairs: Sequence[tuple[str, object]]) -> dict[str, object]:
    output: dict[str, object] = {}
    for key, value in pairs:
        if key in output:
            raise ValueError(f"duplicate JSON member: {key}")
        output[key] = value
    return output


def _load_configuration(path: Path) -> tuple[Mapping[str, object], str, Path]:
    configuration_path = Path(path).resolve(strict=True)
    if not configuration_path.is_file() or configuration_path.is_symlink():
        raise FileNotFoundError("configuration must be an unlinked regular file")
    if configuration_path.parent.name != "configs":
        raise ValueError("configuration must remain directly below a configs directory")
    content = configuration_path.read_bytes()
    try:
        payload = json.loads(
            content.decode("utf-8"),
            object_pairs_hook=_reject_duplicate_members,
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("configuration is not strict UTF-8 JSON") from exc
    validate_exact_config(_mapping(payload, "configuration"))
    return payload, sha256(content).hexdigest(), configuration_path.parent.parent


def identity_sha256(identity: Mapping[str, object]) -> str:
    required = {
        "experiment_id",
        "configuration_sha256",
        "source_sha256",
        "input_archive_sha256",
    }
    if set(identity) != required:
        raise ValueError("run identity member set changed")
    return sha256(_identity_canonical_bytes(identity)).hexdigest()


def _regular_file(path: Path, label: str) -> None:
    if not path.is_file() or path.is_symlink():
        raise FileNotFoundError(f"{label} is missing or not an unlinked regular file: {path}")


def _verify_sources(
    root: Path,
    source_hashes: Mapping[str, object],
    hash_reader: Callable[[Path], str],
) -> dict[str, str]:
    verified: dict[str, str] = {}
    for relative, expected_value in sorted(source_hashes.items()):
        safe_relative = _relative_path(relative, "source path")
        expected = _normalize_sha256(expected_value, f"source_sha256[{relative!r}]")
        path = (root / PurePosixPath(safe_relative)).resolve(strict=False)
        _regular_file(path, "pinned source")
        actual = _normalize_sha256(hash_reader(path), f"actual source SHA-256 for {relative}")
        if actual != expected:
            raise ValueError(
                f"source SHA-256 mismatch for {relative}: expected {expected}, got {actual}"
            )
        verified[safe_relative] = actual
    for relative in EVIDENCE_SOURCE_PATHS:
        if relative in verified:
            continue
        path = (root / PurePosixPath(relative)).resolve(strict=False)
        _regular_file(path, "entry evidence source")
        verified[relative] = _normalize_sha256(
            hash_reader(path), f"actual evidence source SHA-256 for {relative}"
        )
    return verified


def _verify_inputs(
    root: Path,
    archives: Sequence[object],
    hash_reader: Callable[[Path], str],
) -> tuple[dict[str, str], dict[str, Path]]:
    hashes: dict[str, str] = {}
    paths: dict[str, Path] = {}
    for index, value in enumerate(archives):
        item = _mapping(value, f"input archive {index}")
        configured = _relative_path(item["path"], f"input archive {index} path")
        local_evidence = _relative_path(
            item["local_evidence_path"],
            f"input archive {index} local evidence path",
        )
        expected = _normalize_sha256(item["sha256"], f"input archive {index} SHA-256")
        candidates = [
            (root / PurePosixPath(configured)).resolve(strict=False),
            (root / PurePosixPath(local_evidence)).resolve(strict=False),
        ]
        existing = [path for path in candidates if path.exists()]
        if not existing:
            raise FileNotFoundError(
                "input archive is absent at both the packaged path and the local "
                f"evidence path: {configured}, {local_evidence}"
            )
        for path in existing:
            _regular_file(path, "input archive")
            actual = _normalize_sha256(hash_reader(path), f"actual input SHA-256 for {path.name}")
            if actual != expected:
                raise ValueError(
                    f"input SHA-256 mismatch for {path.name}: expected {expected}, got {actual}"
                )
        chosen = candidates[0] if candidates[0] in existing else candidates[1]
        hashes[configured] = expected
        paths[str(item["basin_id"])] = chosen
    return hashes, paths


def _inspect_protected_owners(
    root: Path, relative_paths: Sequence[object]
) -> tuple[tuple[Mapping[str, object], ...], bool]:
    records: list[Mapping[str, object]] = []
    hold = False
    for index, value in enumerate(relative_paths):
        relative = _relative_path(value, f"protected owner path {index}")
        owner_path = (root / PurePosixPath(relative)).resolve(strict=False)
        lock_path = owner_path.parent
        if not lock_path.exists():
            continue
        hold = True
        record: dict[str, object] = {
            "owner_path": relative,
            "lock_present": True,
            "owner_present": False,
        }
        if lock_path.is_symlink() or not lock_path.is_dir():
            record["status"] = "lock_path_not_unlinked_directory"
        elif owner_path.is_file() and not owner_path.is_symlink():
            content = owner_path.read_bytes()
            if len(content) > 1024 * 1024:
                raise ValueError("protected owner record exceeds one mebibyte")
            record["owner_present"] = True
            record["owner_sha256"] = sha256(content).hexdigest()
            try:
                owner = json.loads(
                    content.decode("utf-8"), object_pairs_hook=_reject_duplicate_members
                )
            except (UnicodeDecodeError, json.JSONDecodeError, ValueError):
                record["status"] = "owner_record_invalid"
            else:
                record["status"] = "owner_record_present"
                if isinstance(owner, Mapping):
                    for key in ("process_id", "pid", "host_name", "hostname"):
                        if key in owner:
                            record[key] = owner[key]
        else:
            record["status"] = "owner_record_missing"
        records.append(record)
    return tuple(records), hold


def _read_checkpoint_header(
    checkpoint: Path, expected_identity: Mapping[str, object]
) -> Mapping[str, object]:
    _regular_file(checkpoint, "resume checkpoint")
    if checkpoint.stat().st_nlink != 1:
        raise ValueError("resume checkpoint must have exactly one hard link")
    with checkpoint.open("rb") as handle:
        if handle.read(len(CHECKPOINT_MAGIC)) != CHECKPOINT_MAGIC:
            raise ValueError("resume checkpoint magic is invalid")
        packed = handle.read(CHECKPOINT_HEADER_LENGTH.size)
        if len(packed) != CHECKPOINT_HEADER_LENGTH.size:
            raise ValueError("resume checkpoint header length is missing")
        header_length = CHECKPOINT_HEADER_LENGTH.unpack(packed)[0]
        if header_length <= 0 or header_length > MAX_CHECKPOINT_HEADER_BYTES:
            raise ValueError("resume checkpoint header length is invalid")
        header_bytes = handle.read(header_length)
        if len(header_bytes) != header_length:
            raise ValueError("resume checkpoint header is truncated")
        try:
            header = json.loads(
                header_bytes.decode("utf-8"), object_pairs_hook=_reject_duplicate_members
            )
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
            raise ValueError("resume checkpoint header is invalid JSON") from exc
        if header_bytes != _identity_canonical_bytes(header):
            raise ValueError("resume checkpoint header is not canonical")
        payload_digest = sha256()
        payload_size = 0
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            payload_size += len(block)
            payload_digest.update(block)
    if payload_size == 0:
        raise ValueError("resume checkpoint payload is empty")
    required = {
        "schema_version",
        "identity",
        "identity_sha256",
        "payload_sha256",
        "previous_checkpoint_sha256",
    }
    if not isinstance(header, Mapping) or set(header) != required:
        raise ValueError("resume checkpoint header member set changed")
    if header["schema_version"] != "daily_camels_native_knet_resume_v1":
        raise ValueError("resume checkpoint schema changed")
    stored_identity = _mapping(header["identity"], "resume identity")
    stored_hash = _normalize_sha256(header["identity_sha256"], "resume identity SHA-256")
    if identity_sha256(stored_identity) != stored_hash:
        raise ValueError("resume checkpoint identity hash does not match its members")
    if stored_identity != expected_identity or stored_hash != identity_sha256(expected_identity):
        raise ValueError("resume checkpoint RunIdentity differs from the requested run")
    payload_hash = _normalize_sha256(header["payload_sha256"], "resume payload SHA-256")
    if payload_digest.hexdigest() != payload_hash:
        raise ValueError("resume checkpoint payload SHA-256 mismatch")
    previous = header["previous_checkpoint_sha256"]
    if previous is not None:
        _normalize_sha256(previous, "previous checkpoint SHA-256")
    return header


def identity_document_bytes(result: PreflightResult) -> bytes:
    document = {
        "schema_version": "daily_camels_native_knet_identity_v1",
        "identity": dict(result.identity),
        "identity_sha256": result.identity_sha256,
        "logical_input_paths": sorted(result.input_archive_sha256),
        "device_requirement": "cuda",
    }
    return canonical_json_bytes(document)


def standard_preflight(
    configuration_path: Path,
    run_root: Path,
    *,
    resume: Path | None,
    hash_reader: Callable[[Path], str] = sha256_file,
) -> PreflightResult:
    """Verify immutable bytes and targets without importing numerical packages."""

    configuration, configuration_hash, root = _load_configuration(configuration_path)
    source_hashes = _verify_sources(
        root, _mapping(configuration["source_sha256"], "source_sha256"), hash_reader
    )
    data = _mapping(configuration["data"], "data")
    archives = data["input_archives"]
    if not isinstance(archives, list):
        raise TypeError("data.input_archives must be an array")
    input_hashes, input_paths = _verify_inputs(root, archives, hash_reader)
    protected = _mapping(
        configuration["protected_formal_training"], "protected_formal_training"
    )
    owner_paths = protected["owner_paths"]
    if not isinstance(owner_paths, list):
        raise TypeError("protected owner paths must be an array")
    owner_records, resource_hold = _inspect_protected_owners(root, owner_paths)

    identity: dict[str, object] = {
        "experiment_id": EXPERIMENT_ID,
        "configuration_sha256": configuration_hash,
        "source_sha256": source_hashes,
        "input_archive_sha256": input_hashes,
    }
    identity_hash = identity_sha256(identity)
    root_path = Path(run_root).resolve(strict=False)
    if root_path.exists() and (root_path.is_symlink() or not root_path.is_dir()):
        raise ValueError("run root must be an unlinked directory when it exists")
    run_directory = root_path / EXPERIMENT_ID
    resume_checkpoint: Path | None = None
    if resume is None:
        if run_directory.exists():
            raise FileExistsError(f"run directory already exists: {run_directory}")
    else:
        if not run_directory.is_dir() or run_directory.is_symlink():
            raise FileNotFoundError("resume run directory is absent or unsafe")
        if (run_directory / OWNER_LOCK_DIRECTORY).exists():
            raise FileExistsError("resume run still has an owner lock")
        if (run_directory / COMPLETION_FILE).exists():
            raise FileExistsError("a completion-marked run may not be resumed")
        resume_checkpoint = Path(resume).resolve(strict=True)
        expected_parent = (run_directory / CHECKPOINT_DIRECTORY).resolve(strict=False)
        if resume_checkpoint.parent != expected_parent:
            raise ValueError("resume checkpoint must be inside the run checkpoints directory")
        if not CHECKPOINT_NAME.fullmatch(resume_checkpoint.name):
            raise ValueError("resume checkpoint name must be epoch_NNN.pt")
        identity_path = run_directory / IDENTITY_FILE
        if identity_path.read_bytes() != identity_document_bytes(
            PreflightResult(
                configuration_path=Path(configuration_path).resolve(),
                repository_root=root,
                configuration=configuration,
                configuration_sha256=configuration_hash,
                source_sha256=source_hashes,
                input_archive_sha256=input_hashes,
                input_paths=input_paths,
                run_directory=run_directory,
                resume_checkpoint=resume_checkpoint,
                identity=identity,
                identity_sha256=identity_hash,
                protected_owner_records=owner_records,
                resource_hold=resource_hold,
            )
        ):
            raise ValueError("existing experiment identity differs from the requested run")
        _read_checkpoint_header(resume_checkpoint, identity)

    return PreflightResult(
        configuration_path=Path(configuration_path).resolve(),
        repository_root=root,
        configuration=configuration,
        configuration_sha256=configuration_hash,
        source_sha256=source_hashes,
        input_archive_sha256=input_hashes,
        input_paths=input_paths,
        run_directory=run_directory,
        resume_checkpoint=resume_checkpoint,
        identity=identity,
        identity_sha256=identity_hash,
        protected_owner_records=owner_records,
        resource_hold=resource_hold,
    )


def require_execution_admission(result: PreflightResult) -> None:
    if result.resource_hold:
        raise RuntimeError(
            "protected formal training owner is present; daily execution is RESOURCE_HOLD"
        )


def preflight_report(result: PreflightResult) -> Mapping[str, object]:
    return {
        "status": "RESOURCE_HOLD" if result.resource_hold else "PREFLIGHT_PASSED",
        "experiment_id": EXPERIMENT_ID,
        "configuration_sha256": result.configuration_sha256,
        "identity_sha256": result.identity_sha256,
        "source_sha256": dict(result.source_sha256),
        "input_archive_sha256": dict(result.input_archive_sha256),
        "run_directory": str(result.run_directory),
        "resume_checkpoint": (
            str(result.resume_checkpoint) if result.resume_checkpoint is not None else None
        ),
        "protected_owner_records": list(result.protected_owner_records),
        "array_members_materialized": 0,
        "numerical_frameworks_imported": 0,
    }


def runtime_interface_gaps(data_source: str, training_source: str) -> tuple[str, ...]:
    """Report known blockers without importing the runtime modules."""

    gaps: list[str] = []
    training_tree = ast.parse(training_source)
    training_function = next(
        (
            node
            for node in training_tree.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            and node.name == "train_daily_native_knet"
        ),
        None,
    )
    parameter_names: set[str] = set()
    if training_function is not None:
        arguments = training_function.args
        parameter_names = {
            argument.arg
            for argument in (
                *arguments.posonlyargs,
                *arguments.args,
                *arguments.kwonlyargs,
            )
        }
    if "resume_state" not in parameter_names:
        gaps.append("train_daily_native_knet lacks resume_state")
    if "checkpoint_callback" not in parameter_names:
        gaps.append("train_daily_native_knet lacks checkpoint_callback")
    elif (
        training_source.count("checkpoint_callback(") < 2
        or "completed_epoch = 0" not in training_source
    ):
        gaps.append("train_daily_native_knet lacks a proven epoch-zero checkpoint callback")
    for required in (
        "training_loss_scales",
        "training_scale_evidence_sha256",
    ):
        if required not in parameter_names:
            gaps.append(f"train_daily_native_knet lacks {required}")
    for required_function in (
        "masked_nse_multilead_segment_pairs",
        "multibasin_masked_nse_step_loss",
    ):
        if not any(
            isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            and node.name == required_function
            for node in training_tree.body
        ):
            gaps.append(f"training lacks {required_function}")

    data_tree = ast.parse(data_source)
    prepared_fields: set[str] = set()
    for node in data_tree.body:
        if isinstance(node, ast.ClassDef) and node.name == "PreparedDailyBasin":
            prepared_fields = {
                member.target.id
                for member in node.body
                if isinstance(member, ast.AnnAssign)
                and isinstance(member.target, ast.Name)
            }
            break
    for required in ("normalized_feature_guard",):
        if required not in prepared_fields:
            gaps.append(f"PreparedDailyBasin lacks {required}")
    compact_training = "".join(training_source.split())
    if "coefficient_source.detach().cpu().numpy()" not in compact_training:
        gaps.append("training lacks CUDA-safe second-order autoregression conversion")
    return tuple(gaps)


def _finite_gate_float(value: object) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        converted = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return converted if math.isfinite(converted) else None


def _normalized_lead_mapping(value: object) -> dict[int, object] | None:
    if not isinstance(value, Mapping) or len(value) != 3:
        return None
    normalized: dict[int, object] = {}
    for raw_lead, member in value.items():
        if isinstance(raw_lead, bool):
            return None
        if isinstance(raw_lead, int):
            lead = raw_lead
        elif isinstance(raw_lead, str) and raw_lead in {"1", "2", "3"}:
            lead = int(raw_lead)
        else:
            return None
        if lead in normalized:
            return None
        normalized[lead] = member
    return normalized if set(normalized) == {1, 2, 3} else None


def _cell_primary_losses(
    value: object,
    *,
    expected_event_count: int,
    basin_standard_deviation: float,
    label: str,
    reasons: list[str],
) -> dict[int, float] | None:
    cells = _normalized_lead_mapping(value)
    if cells is None:
        reasons.append(f"{label} lead key set is not exactly 1, 2, and 3")
        return None
    denominator = (
        basin_standard_deviation + LOSS_EPSILON_ORIGINAL_DISCHARGE_UNITS
    ) ** 2
    primary_losses: dict[int, float] = {}
    for lead in (1, 2, 3):
        cell = cells[lead]
        if not isinstance(cell, Mapping) or set(cell) != RESULT_CELL_EVIDENCE_FIELDS:
            reasons.append(f"{label} lead {lead} cell field set changed")
            return None
        event_count = cell.get("event_count")
        if type(event_count) is not int or event_count != expected_event_count:
            reasons.append(
                f"{label} lead {lead} event count is not {expected_event_count}"
            )
            return None
        physical_mse = _finite_gate_float(cell.get("physical_mse"))
        primary_loss = _finite_gate_float(cell.get("primary_loss"))
        if (
            physical_mse is None
            or primary_loss is None
            or physical_mse < 0.0
            or primary_loss < 0.0
        ):
            reasons.append(f"{label} lead {lead} cell values are nonfinite or negative")
            return None
        expected_primary_loss = physical_mse / denominator
        if not math.isclose(
            primary_loss,
            expected_primary_loss,
            rel_tol=1.0e-6,
            abs_tol=1.0e-6,
        ):
            reasons.append(f"{label} lead {lead} cell formula does not reconstruct")
            return None
        primary_losses[lead] = primary_loss
    return primary_losses


def _training_scale_gate_context(
    evidence: object,
    reasons: list[str],
) -> tuple[str | None, dict[str, float]]:
    if not isinstance(evidence, Mapping):
        reasons.append("training scale evidence is absent or malformed")
        return None, {}
    try:
        evidence_sha256 = _normalize_sha256(
            evidence.get("training_scale_evidence_sha256"),
            "training scale evidence SHA-256",
        )
    except (TypeError, ValueError):
        reasons.append("training scale evidence SHA-256 is invalid")
        evidence_sha256 = None
    if evidence.get("experiment_id") != EXPERIMENT_ID:
        reasons.append("training scale evidence experiment identity changed")
    scales = evidence.get("scales")
    if not isinstance(scales, Mapping):
        reasons.append("training scale evidence scales are malformed")
        return evidence_sha256, {}
    if (
        scales.get("training_start_index") != 0
        or scales.get("validation_start_index")
        != TRAINING_STATISTICS_STOP_INDEX_EXCLUSIVE
    ):
        reasons.append("training scale evidence slice is not half-open [0,2557)")
    basin_ids = scales.get("basin_ids")
    per_basin = scales.get("per_basin")
    if (
        not isinstance(basin_ids, (list, tuple))
        or not basin_ids
        or not isinstance(per_basin, Mapping)
        or set(str(value) for value in basin_ids) != set(per_basin)
    ):
        reasons.append("training scale basin identities are malformed")
        return evidence_sha256, {}
    standard_deviations: dict[str, float] = {}
    for raw_basin_id in basin_ids:
        basin_id = str(raw_basin_id)
        basin_scale = per_basin.get(basin_id)
        if not isinstance(basin_scale, Mapping):
            reasons.append(f"training scale for basin {basin_id} is malformed")
            continue
        standard_deviation = _finite_gate_float(
            basin_scale.get("population_std_original_discharge_units")
        )
        if standard_deviation is None or standard_deviation <= 0.0:
            reasons.append(
                f"training standard deviation for basin {basin_id} is invalid"
            )
            continue
        standard_deviations[basin_id] = standard_deviation
    return evidence_sha256, standard_deviations


def scientific_gate(
    rows: Sequence[Mapping[str, object]],
    access_ledger: Mapping[str, object],
    *,
    training_scale_evidence: Mapping[str, object],
    minimum_improvement: float,
    expected_completed_epoch: int = 4,
) -> Mapping[str, object]:
    """Require post-zero improvement of the identical frozen validation loss."""

    io_module = _load_preflight_io_module(Path(__file__).resolve().parents[1])
    result = dict(io_module.scientific_gate_evidence(
        rows,
        access_ledger,
        minimum_improvement=minimum_improvement,
        expected_completed_epoch=expected_completed_epoch,
    ))
    reasons = list(result["reasons"])
    evidence_scale_hash, basin_standard_deviations = _training_scale_gate_context(
        training_scale_evidence,
        reasons,
    )
    expected_basins = set(basin_standard_deviations)
    scale_hashes: set[str] = set()
    for row_index, row in enumerate(rows):
        row_label = f"epoch row {row_index}"
        validation_loss = _finite_gate_float(row.get("validation_loss"))
        selection_score = _finite_gate_float(row.get("selection_score"))
        if (
            validation_loss is None
            or selection_score is None
            or not math.isclose(
                selection_score,
                -validation_loss,
                rel_tol=0.0,
                abs_tol=1.0e-12,
            )
        ):
            reasons.append(
                "checkpoint selection score is not the negative frozen validation loss"
            )
        try:
            scale_hashes.add(
                _normalize_sha256(
                    row.get("training_scale_evidence_sha256"),
                    "training scale evidence SHA-256",
                )
            )
        except (TypeError, ValueError):
            reasons.append("training scale evidence SHA-256 is invalid")

        per_basin = row.get("per_basin")
        if (
            not expected_basins
            or not isinstance(per_basin, Mapping)
            or set(per_basin) != expected_basins
        ):
            reasons.append(f"{row_label} validation basin key set changed")
            continue
        validation_basin_losses: list[float] = []
        for basin_id in sorted(expected_basins):
            metrics = per_basin[basin_id]
            if not isinstance(metrics, Mapping):
                reasons.append(f"{row_label} basin {basin_id} metrics are malformed")
                continue
            cell_losses = _cell_primary_losses(
                metrics.get("per_lead_loss_evidence"),
                expected_event_count=VALIDATION_EVENTS_PER_BASIN_LEAD,
                basin_standard_deviation=basin_standard_deviations[basin_id],
                label=f"{row_label} validation basin {basin_id}",
                reasons=reasons,
            )
            if cell_losses is None:
                continue
            equal_lead_loss = math.fsum(cell_losses.values()) / 3
            basin_primary_loss = _finite_gate_float(metrics.get("primary_loss"))
            basin_validation_loss = _finite_gate_float(
                metrics.get("validation_loss")
            )
            if basin_primary_loss is None or basin_validation_loss is None:
                reasons.append(
                    f"{row_label} basin {basin_id} primary loss is nonfinite"
                )
                continue
            if not (
                math.isclose(
                    basin_primary_loss,
                    equal_lead_loss,
                    rel_tol=1.0e-6,
                    abs_tol=1.0e-6,
                )
                and math.isclose(
                    basin_validation_loss,
                    equal_lead_loss,
                    rel_tol=1.0e-6,
                    abs_tol=1.0e-6,
                )
            ):
                reasons.append(
                    f"{row_label} basin {basin_id} equal-lead mean does not reconstruct"
                )
                continue
            legacy_losses = _normalized_lead_mapping(
                metrics.get("masked_nse_loss_by_lead")
            )
            target_counts = _normalized_lead_mapping(
                metrics.get("target_count_by_lead")
            )
            if legacy_losses is None or any(
                _finite_gate_float(legacy_losses[lead]) is None
                or not math.isclose(
                    float(legacy_losses[lead]),
                    cell_losses[lead],
                    rel_tol=1.0e-6,
                    abs_tol=1.0e-6,
                )
                for lead in (1, 2, 3)
            ):
                reasons.append(
                    f"{row_label} basin {basin_id} legacy lead loss differs from cell evidence"
                )
            if target_counts is None or any(
                type(target_counts[lead]) is not int
                or target_counts[lead] != VALIDATION_EVENTS_PER_BASIN_LEAD
                for lead in (1, 2, 3)
            ):
                reasons.append(
                    f"{row_label} basin {basin_id} validation target counts changed"
                )
            validation_basin_losses.append(equal_lead_loss)

        if len(validation_basin_losses) == len(expected_basins):
            equal_basin_loss = math.fsum(validation_basin_losses) / len(
                validation_basin_losses
            )
            row_primary_loss = _finite_gate_float(row.get("primary_loss"))
            if (
                validation_loss is None
                or row_primary_loss is None
                or not math.isclose(
                    validation_loss,
                    equal_basin_loss,
                    rel_tol=1.0e-6,
                    abs_tol=1.0e-6,
                )
                or not math.isclose(
                    row_primary_loss,
                    equal_basin_loss,
                    rel_tol=1.0e-6,
                    abs_tol=1.0e-6,
                )
            ):
                reasons.append(f"{row_label} validation equal-basin mean does not reconstruct")
        row_target_counts = _normalized_lead_mapping(row.get("target_count_by_lead"))
        expected_total_per_lead = (
            len(expected_basins) * VALIDATION_EVENTS_PER_BASIN_LEAD
        )
        if row_target_counts is None or any(
            type(row_target_counts[lead]) is not int
            or row_target_counts[lead] != expected_total_per_lead
            for lead in (1, 2, 3)
        ):
            reasons.append(f"{row_label} aggregate validation target counts changed")

        epoch = row.get("epoch")
        if type(epoch) is not int or epoch <= 0:
            continue
        units = row.get("training_units")
        if not isinstance(units, list) or not units:
            reasons.append("post-zero equal-basin training unit evidence is absent")
            continue
        by_step: dict[int, dict[str, float]] = {}
        for unit_index, unit in enumerate(units):
            unit_label = f"epoch {epoch} training unit {unit_index}"
            if not isinstance(unit, Mapping):
                reasons.append(f"{unit_label} is malformed")
                continue
            basin_id = str(unit.get("basin_id", ""))
            step = unit.get("step_in_epoch")
            start = unit.get("start_index")
            end = unit.get("end_index_exclusive")
            if (
                basin_id not in expected_basins
                or type(step) is not int
                or step < 0
            ):
                reasons.append(f"{unit_label} basin or optimizer step identity changed")
                continue
            if not (
                type(start) is int
                and type(end) is int
                and 0
                <= start
                < end
                <= TRAINING_STATISTICS_STOP_INDEX_EXCLUSIVE
            ):
                reasons.append(f"{unit_label} training segment boundary is invalid")
            cell_losses = _cell_primary_losses(
                unit.get("per_lead_loss_evidence"),
                expected_event_count=TRAINING_EVENTS_PER_BASIN_LEAD,
                basin_standard_deviation=basin_standard_deviations[basin_id],
                label=unit_label,
                reasons=reasons,
            )
            if cell_losses is None:
                continue
            equal_lead_loss = math.fsum(cell_losses.values()) / 3
            unit_primary_loss = _finite_gate_float(unit.get("primary_loss"))
            legacy_unit_loss = _finite_gate_float(unit.get("masked_nse_loss"))
            if (
                unit_primary_loss is None
                or legacy_unit_loss is None
                or not math.isclose(
                    unit_primary_loss,
                    equal_lead_loss,
                    rel_tol=1.0e-6,
                    abs_tol=1.0e-6,
                )
                or not math.isclose(
                    legacy_unit_loss,
                    equal_lead_loss,
                    rel_tol=1.0e-6,
                    abs_tol=1.0e-6,
                )
            ):
                reasons.append(f"{unit_label} equal-lead mean does not reconstruct")
                continue
            if (
                type(unit.get("forecast_target_count")) is not int
                or unit.get("forecast_target_count")
                != 3 * TRAINING_EVENTS_PER_BASIN_LEAD
            ):
                reasons.append(f"{unit_label} forecast target count changed")
            if basin_id in by_step.setdefault(step, {}):
                reasons.append(f"{unit_label} duplicates a basin within one optimizer step")
            by_step[step][basin_id] = equal_lead_loss
        if not by_step or any(
            set(basin_losses) != expected_basins for basin_losses in by_step.values()
        ):
            reasons.append("an optimizer step lacks exactly one unit from every basin")
            continue
        step_losses = [
            math.fsum(basin_losses.values()) / len(basin_losses)
            for _, basin_losses in sorted(by_step.items())
        ]
        expected_training_loss = math.fsum(step_losses) / len(step_losses)
        recorded_training_loss = _finite_gate_float(row.get("training_loss"))
        if recorded_training_loss is None or not math.isclose(
            recorded_training_loss,
            expected_training_loss,
            rel_tol=1.0e-6,
            abs_tol=1.0e-6,
        ):
            reasons.append(f"epoch {epoch} training equal-basin mean does not reconstruct")

    if len(scale_hashes) != 1:
        reasons.append("training scale evidence SHA-256 changed across epochs")
    elif evidence_scale_hash != next(iter(scale_hashes)):
        reasons.append("training scale evidence SHA-256 differs from epoch records")

    epoch_zero_loss = next(
        (
            float(row["validation_loss"])
            for row in rows
            if int(row.get("epoch", -1)) == 0
        ),
        float("nan"),
    )
    best_score = float(result["best_post_zero_selection_score"])
    result["improvement"] = (
        best_score + epoch_zero_loss
        if math.isfinite(best_score) and math.isfinite(epoch_zero_loss)
        else float("nan")
    )
    result["training_scale_evidence_sha256"] = (
        next(iter(scale_hashes)) if len(scale_hashes) == 1 else None
    )
    result["reasons"] = reasons
    result["passed"] = not reasons
    return result


def _load_preflight_io_module(root: Path) -> ModuleType:
    existing = sys.modules.get(RUNTIME_IO_ALIAS)
    if isinstance(existing, ModuleType):
        return existing
    path = root / "src/global_hydrology/experiments/daily_camels_native_knet_io.py"
    _regular_file(path, "persistence module")
    specification = importlib.util.spec_from_file_location(RUNTIME_IO_ALIAS, path)
    if specification is None or specification.loader is None:
        raise ImportError("cannot construct the standard-library persistence loader")
    module = importlib.util.module_from_spec(specification)
    sys.modules[RUNTIME_IO_ALIAS] = module
    try:
        specification.loader.exec_module(module)
    except Exception:
        sys.modules.pop(RUNTIME_IO_ALIAS, None)
        raise
    return module


def load_runtime_modules(root: Path) -> Mapping[str, ModuleType]:
    """Import numerical and training modules only after identity ownership exists."""

    for path in (root, root / "src"):
        text = str(path)
        if text not in sys.path:
            sys.path.insert(0, text)
    return {
        "contract": importlib.import_module(
            "global_hydrology.experiments.daily_camels_native_knet_masked_nse_contract"
        ),
        "data": importlib.import_module(
            "global_hydrology.experiments.daily_camels_native_knet_masked_nse_data"
        ),
        "training": importlib.import_module(
            "global_hydrology.experiments.daily_camels_native_knet_masked_nse_training"
        ),
        "loss_contract": importlib.import_module(
            "global_hydrology.experiments.daily_camels_masked_nse_loss_contract"
        ),
        "io": importlib.import_module(
            "global_hydrology.experiments.daily_camels_native_knet_io"
        ),
    }


def _write_atomic_json(
    io_module: ModuleType,
    path: Path,
    payload: object,
    *,
    replace: bool,
) -> str:
    return io_module.atomic_write_bytes(path, canonical_json_bytes(payload), replace=replace)


def _read_events(path: Path) -> list[dict[str, object]]:
    if not path.exists():
        return []
    events: list[dict[str, object]] = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line:
            raise ValueError(f"empty event line at {line_number}")
        value = json.loads(line, object_pairs_hook=_reject_duplicate_members)
        if not isinstance(value, dict):
            raise ValueError(f"event line {line_number} is not an object")
        if int(value.get("sequence", -1)) != line_number - 1:
            raise ValueError(f"event sequence changed at line {line_number}")
        events.append(value)
    return events


def _write_events(io_module: ModuleType, path: Path, events: Sequence[Mapping[str, object]]) -> str:
    content = b"".join(_identity_canonical_bytes(event) + b"\n" for event in events)
    return io_module.atomic_write_bytes(path, content, replace=path.exists())


def _append_event(
    io_module: ModuleType,
    path: Path,
    events: list[dict[str, object]],
    event: Mapping[str, object],
) -> str:
    row = dict(event)
    row["sequence"] = len(events)
    row["recorded_at_utc"] = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    events.append(row)
    return _write_events(io_module, path, events)


def persist_epoch_checkpoint(
    io_module: ModuleType,
    *,
    run_directory: Path,
    preflight: PreflightResult,
    training_result: Any,
    training_scale_evidence_sha256: str,
    access_ledger: Mapping[str, object],
    previous_checkpoint_sha256: str | None,
    numpy_module: ModuleType,
    torch_module: ModuleType,
) -> tuple[Path, str]:
    """Persist one immutable state supplied by the epoch-zero/per-epoch callback."""

    epoch = int(training_result.completed_epoch)
    history = list(training_result.history)
    if epoch < 0:
        raise ValueError("checkpoint epoch must be nonnegative")
    if not history or int(history[-1]["epoch"]) != epoch:
        raise ValueError("checkpoint epoch differs from the latest training event")
    scale_hash = _normalize_sha256(
        training_scale_evidence_sha256,
        "training scale evidence SHA-256",
    )
    if str(training_result.training_scale_evidence_sha256) != scale_hash:
        raise ValueError("checkpoint training scale evidence SHA-256 changed")
    if {
        str(row.get("training_scale_evidence_sha256", "")) for row in history
    } != {scale_hash}:
        raise ValueError("checkpoint history contains scale evidence drift")
    cuda_states = (
        list(torch_module.cuda.get_rng_state_all())
        if torch_module.cuda.is_available()
        else []
    )
    best_post_zero_checkpoint = {
        "epoch": int(training_result.best_epoch),
        "selection_score": float(training_result.best_selection_score),
        "model_state": training_result.best_model_state,
    }
    state = io_module.ResumeState(
        experiment_id=EXPERIMENT_ID,
        model_state=training_result.current_model_state,
        optimizer_state=training_result.current_optimizer_state,
        scheduler_state=(
            training_result.scheduler.state_dict()
            if training_result.scheduler is not None
            else None
        ),
        completed_epoch=epoch,
        cumulative_optimizer_steps=int(training_result.cumulative_optimizer_steps),
        sampled_forecast_events=int(training_result.sampled_forecast_events),
        nonzero_gradient_parameter_names=list(
            training_result.nonzero_gradient_parameter_names
        ),
        best_post_zero_checkpoint=best_post_zero_checkpoint,
        epoch_zero_record=dict(history[0]),
        history=[dict(row) for row in history],
        python_random_state=random.getstate(),
        numpy_bit_generator_state=numpy_module.random.get_state(),
        torch_cpu_random_state=torch_module.random.get_rng_state(),
        torch_cuda_random_states=cuda_states,
        sampler_generator_state=training_result.sampler_generator_state,
        configuration_sha256=preflight.configuration_sha256,
        source_sha256=preflight.source_sha256,
        input_archive_sha256=preflight.input_archive_sha256,
        access_ledger=dict(access_ledger),
        previous_checkpoint_sha256=previous_checkpoint_sha256,
    )
    checkpoint_name = EPOCH_ZERO_CHECKPOINT if epoch == 0 else f"epoch_{epoch:03d}.pt"
    path = run_directory / CHECKPOINT_DIRECTORY / checkpoint_name
    return path, io_module.save_resume_checkpoint(path, state)


def _file_record(path: Path) -> Mapping[str, object]:
    return {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}


def build_manifest_payload(run_directory: Path) -> Mapping[str, object]:
    files: dict[str, Mapping[str, object]] = {}
    for path in sorted(run_directory.rglob("*")):
        relative_path = path.relative_to(run_directory)
        if (
            OWNER_LOCK_DIRECTORY in relative_path.parts
            or path.name in {MANIFEST_FILE, COMPLETION_FILE}
        ):
            continue
        if path.is_symlink():
            raise ValueError(f"run artifact is a symbolic link: {relative_path.as_posix()}")
        if path.is_dir():
            continue
        if not path.is_file() or path.name.endswith(".tmp"):
            raise ValueError(f"run artifact is not an admitted regular file: {relative_path.as_posix()}")
        files[relative_path.as_posix()] = _file_record(path)
    return {
        "schema_version": "daily_camels_native_knet_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "file_count": len(files),
        "files": files,
    }


def write_final_artifacts(
    io_module: ModuleType,
    *,
    run_directory: Path,
    events: list[dict[str, object]],
    history: Sequence[Mapping[str, object]],
    access_ledger: Mapping[str, object],
    training_scale_evidence: Mapping[str, object],
    training_scale_evidence_sha256: str,
    minimum_improvement: float,
    selected_checkpoint: Path,
    final_checkpoint: Path,
) -> Mapping[str, object]:
    """Apply the science gate and publish the completion marker last."""

    gate = scientific_gate(
        history,
        access_ledger,
        training_scale_evidence=training_scale_evidence,
        minimum_improvement=minimum_improvement,
    )
    _write_atomic_json(
        io_module,
        run_directory / ACCESS_LEDGER_FILE,
        access_ledger,
        replace=(run_directory / ACCESS_LEDGER_FILE).exists(),
    )
    summary = {
        "schema_version": "daily_camels_native_knet_result_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "COMPLETED" if gate["passed"] else "HARD_STOP",
        "training_scale_evidence_sha256": _normalize_sha256(
            training_scale_evidence_sha256,
            "training scale evidence SHA-256",
        ),
        "science_gate": gate,
        "selected_checkpoint": selected_checkpoint.relative_to(run_directory).as_posix(),
        "history": [dict(row) for row in history],
    }
    _write_atomic_json(
        io_module,
        run_directory / SUMMARY_FILE,
        summary,
        replace=(run_directory / SUMMARY_FILE).exists(),
    )
    if gate["passed"]:
        terminal = {"status": "completed", "event_type": "completed"}
    else:
        terminal = {
            "status": "failed",
            "error_type": "hard_stop",
            "reasons": gate["reasons"],
        }
    _append_event(io_module, run_directory / EVENT_FILE, events, terminal)
    manifest = build_manifest_payload(run_directory)
    manifest_sha256 = _write_atomic_json(
        io_module,
        run_directory / MANIFEST_FILE,
        manifest,
        replace=(run_directory / MANIFEST_FILE).exists(),
    )
    if not gate["passed"]:
        raise RuntimeError("daily smoke failed its frozen post-zero or isolation gate")
    completion = {
        "schema_version": "daily_camels_native_knet_completion_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "COMPLETED",
        "training_scale_evidence_sha256": _normalize_sha256(
            training_scale_evidence_sha256,
            "training scale evidence SHA-256",
        ),
        "manifest_file": MANIFEST_FILE,
        "manifest_sha256": manifest_sha256,
        "summary_file": SUMMARY_FILE,
        "summary_sha256": sha256_file(run_directory / SUMMARY_FILE),
        "selected_checkpoint": selected_checkpoint.relative_to(
            run_directory
        ).as_posix(),
        "selected_checkpoint_sha256": sha256_file(selected_checkpoint),
        "final_checkpoint": final_checkpoint.relative_to(run_directory).as_posix(),
        "final_checkpoint_sha256": sha256_file(final_checkpoint),
    }
    _write_atomic_json(
        io_module,
        run_directory / COMPLETION_FILE,
        completion,
        replace=False,
    )
    return summary


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run the frozen daily CAMELS native KalmanNet smoke on CUDA."
    )
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--run-root", type=Path, required=True)
    parser.add_argument("--device", choices=("cuda",), default="cuda")
    parser.add_argument(
        "--resume",
        type=Path,
        default=None,
        help="Explicit immutable epoch checkpoint; omission always means a new run.",
    )
    parser.add_argument("--preflight-only", action="store_true")
    return parser


def execute(arguments: argparse.Namespace) -> int:
    preflight = standard_preflight(
        arguments.config,
        arguments.run_root,
        resume=arguments.resume,
    )
    if arguments.preflight_only:
        print(canonical_json_bytes(preflight_report(preflight)).decode("utf-8"), end="")
        return 0
    require_execution_admission(preflight)

    guard_io = _load_preflight_io_module(preflight.repository_root)
    if preflight.resume_checkpoint is None:
        guard_io.create_new_run(preflight.run_directory)
    owner = guard_io.OwnerLock.acquire(
        preflight.run_directory / OWNER_LOCK_DIRECTORY,
        {
            "experiment_id": EXPERIMENT_ID,
            "identity_sha256": preflight.identity_sha256,
            "device": arguments.device,
            "resume_checkpoint": (
                str(preflight.resume_checkpoint)
                if preflight.resume_checkpoint is not None
                else None
            ),
        },
    )
    events_path = preflight.run_directory / EVENT_FILE
    events = _read_events(events_path) if preflight.resume_checkpoint is not None else []
    try:
        identity_path = preflight.run_directory / IDENTITY_FILE
        identity_bytes = identity_document_bytes(preflight)
        if preflight.resume_checkpoint is None:
            guard_io.atomic_write_bytes(identity_path, identity_bytes, replace=False)
        elif identity_path.read_bytes() != identity_bytes:
            raise ValueError("resume identity changed after owner acquisition")
        _append_event(
            guard_io,
            events_path,
            events,
            {
                "event_type": "preflight_completed",
                "identity_sha256": preflight.identity_sha256,
                "array_members_materialized": 0,
            },
        )

        data_path = (
            preflight.repository_root
            / "src/global_hydrology/experiments/"
            "daily_camels_native_knet_masked_nse_data.py"
        )
        training_path = (
            preflight.repository_root
            / "src/global_hydrology/experiments/"
            "daily_camels_native_knet_masked_nse_training.py"
        )
        gaps = runtime_interface_gaps(
            data_path.read_text(encoding="utf-8"),
            training_path.read_text(encoding="utf-8"),
        )
        if gaps:
            _append_event(
                guard_io,
                events_path,
                events,
                {
                    "status": "failed",
                    "error_type": "dependency_failure",
                    "stop_classification": "HARD_STOP",
                    "runtime_interface_gaps": list(gaps),
                    "array_members_materialized": 0,
                },
            )
            raise RuntimeError(
                "daily training integration is fail-closed: " + "; ".join(gaps)
            )

        runtime_modules = load_runtime_modules(preflight.repository_root)
        contract_module = runtime_modules["contract"]
        data_module = runtime_modules["data"]
        training_module = runtime_modules["training"]
        loss_contract_module = runtime_modules["loss_contract"]
        runtime_io = runtime_modules["io"]
        numpy_module = sys.modules.get("numpy")
        torch_module = sys.modules.get("torch")
        if not isinstance(numpy_module, ModuleType) or not isinstance(torch_module, ModuleType):
            raise ImportError("the delayed numerical runtime did not load completely")
        if arguments.device != "cuda" or not torch_module.cuda.is_available():
            raise RuntimeError("CUDA was requested but is unavailable; CPU fallback is forbidden")
        device = torch_module.device("cuda")
        contract = contract_module.DailyKNetContract.from_dict(preflight.configuration)
        runtime_identity = runtime_io.RunIdentity(
            experiment_id=EXPERIMENT_ID,
            configuration_sha256=preflight.configuration_sha256,
            source_sha256=preflight.source_sha256,
            input_archive_sha256=preflight.input_archive_sha256,
        )
        resume_state = None
        if preflight.resume_checkpoint is None:
            access_ledger = contract_module.AccessLedger()
        else:
            resume_state = runtime_io.load_resume_checkpoint(
                preflight.resume_checkpoint,
                runtime_identity,
            )
            if not isinstance(resume_state.access_ledger, Mapping):
                raise TypeError("resume access ledger must be a mapping")
            saved_ledger = dict(resume_state.access_ledger)
            # The resumed process re-materializes each allowlisted member once;
            # forbidden counters remain cumulative and therefore fail closed.
            access_ledger = contract_module.AccessLedger(
                raw_source_byte_reads=int(saved_ledger["raw_source_byte_reads"]),
                archive_materialization_sessions=int(
                    saved_ledger["archive_materialization_sessions"]
                ),
                archive_member_reads=dict(saved_ledger["archive_member_reads"]),
                evaluation_array_reads=int(saved_ledger["evaluation_array_reads"]),
                evaluation_predictions=int(saved_ledger["evaluation_predictions"]),
                evaluation_metrics=int(saved_ledger["evaluation_metrics"]),
                evaluation_outputs=int(saved_ledger["evaluation_outputs"]),
            )
            _append_event(
                guard_io,
                events_path,
                events,
                {
                    "event_type": "resume_checkpoint_loaded",
                    "epoch": int(resume_state.completed_epoch),
                    "checkpoint": preflight.resume_checkpoint.relative_to(
                        preflight.run_directory
                    ).as_posix(),
                    "checkpoint_sha256": sha256_file(preflight.resume_checkpoint),
                },
            )

        access_ledger.begin_materialization_session()
        data_configuration = _mapping(preflight.configuration["data"], "data")
        archives = data_configuration["input_archives"]
        if not isinstance(archives, list):
            raise TypeError("data.input_archives must be an array")
        basin_arrays: list[Any] = []
        for value in archives:
            archive = _mapping(value, "input archive")
            basin_id = str(archive["basin_id"])
            arrays = data_module.load_daily_selection_archive(
                preflight.input_paths[basin_id],
                str(archive["sha256"]),
                contract,
                access_ledger,
            )
            if arrays.basin_id != basin_id:
                raise ValueError("loaded basin identity differs from the frozen configuration")
            basin_arrays.append(arrays)

        loss_configuration = _mapping(
            preflight.configuration["loss_contract"], "loss_contract"
        )
        training_loss_scales = (
            loss_contract_module.fit_shared_training_discharge_scales(
                {
                    str(arrays.basin_id): arrays.observations
                    for arrays in basin_arrays
                },
                training_start_index=int(
                    loss_configuration["training_statistics_start_index"]
                ),
                validation_start_index=int(
                    loss_configuration[
                        "training_statistics_stop_index_exclusive"
                    ]
                ),
            )
        )
        training_scale_evidence_sha256 = (
            loss_contract_module.training_scale_evidence_sha256(
                training_loss_scales
            )
        )
        training_scale_payload = {
            "schema_version": "daily_camels_training_scale_evidence_v1",
            "experiment_id": EXPERIMENT_ID,
            "training_scale_evidence_sha256": training_scale_evidence_sha256,
            "loss_contract": loss_contract_module.contract_manifest(),
            "scales": asdict(training_loss_scales),
        }
        training_scale_path = (
            preflight.run_directory / TRAINING_SCALE_EVIDENCE_FILE
        )
        training_scale_bytes = canonical_json_bytes(training_scale_payload)
        if preflight.resume_checkpoint is None:
            guard_io.atomic_write_bytes(
                training_scale_path,
                training_scale_bytes,
                replace=False,
            )
        elif training_scale_path.read_bytes() != training_scale_bytes:
            raise ValueError("resume training scale evidence changed")
        _append_event(
            guard_io,
            events_path,
            events,
            {
                "event_type": "training_scales_fitted",
                "training_scale_evidence_sha256": (
                    training_scale_evidence_sha256
                ),
                "training_statistics_start_index": int(
                    loss_configuration["training_statistics_start_index"]
                ),
                "training_statistics_stop_index_exclusive": int(
                    loss_configuration[
                        "training_statistics_stop_index_exclusive"
                    ]
                ),
            },
        )
        basins = [
            data_module.prepare_daily_basin(arrays, contract, device)
            for arrays in basin_arrays
        ]

        model_settings = _mapping(preflight.configuration["model"], "model")
        training_settings = dict(
            _mapping(preflight.configuration["training"], "training")
        )
        training_settings.update(
            {
                "zero_gain_initialization": model_settings["zero_gain_initialization"],
                "hidden_dimension": model_settings["hidden_dimension"],
                "input_multiplier": model_settings["input_multiplier"],
                "output_multiplier": model_settings["output_multiplier"],
            }
        )
        previous_checkpoint_sha256 = (
            sha256_file(preflight.resume_checkpoint)
            if preflight.resume_checkpoint is not None
            else None
        )
        checkpoint_records: dict[int, tuple[Path, str]] = {}
        if resume_state is not None and preflight.resume_checkpoint is not None:
            checkpoint_records[int(resume_state.completed_epoch)] = (
                preflight.resume_checkpoint,
                previous_checkpoint_sha256,
            )

        def checkpoint_callback(training_result: Any) -> None:
            nonlocal previous_checkpoint_sha256
            ledger_payload = asdict(access_ledger)
            checkpoint_path, checkpoint_sha256 = persist_epoch_checkpoint(
                runtime_io,
                run_directory=preflight.run_directory,
                preflight=preflight,
                training_result=training_result,
                training_scale_evidence_sha256=(
                    training_scale_evidence_sha256
                ),
                access_ledger=ledger_payload,
                previous_checkpoint_sha256=previous_checkpoint_sha256,
                numpy_module=numpy_module,
                torch_module=torch_module,
            )
            previous_checkpoint_sha256 = checkpoint_sha256
            completed_epoch = int(training_result.completed_epoch)
            checkpoint_records[completed_epoch] = (
                checkpoint_path,
                checkpoint_sha256,
            )
            _append_event(
                guard_io,
                events_path,
                events,
                {
                    "event_type": "epoch_checkpointed",
                    "epoch": completed_epoch,
                    "checkpoint": checkpoint_path.relative_to(
                        preflight.run_directory
                    ).as_posix(),
                    "checkpoint_sha256": checkpoint_sha256,
                    "training_record": dict(training_result.history[-1]),
                },
            )

        training_result = training_module.train_daily_native_knet(
            basins,
            training_settings,
            device=device,
            training_loss_scales=training_loss_scales,
            training_scale_evidence_sha256=training_scale_evidence_sha256,
            resume_state=resume_state,
            checkpoint_callback=checkpoint_callback,
        )
        completed_epoch = int(training_result.completed_epoch)
        expected_epoch = int(training_settings["epochs"])
        if completed_epoch != expected_epoch or completed_epoch not in checkpoint_records:
            raise RuntimeError("training returned without its final atomic checkpoint")
        best_epoch = int(training_result.best_epoch)
        selected_checkpoint = (
            preflight.run_directory
            / CHECKPOINT_DIRECTORY
            / (EPOCH_ZERO_CHECKPOINT if best_epoch == 0 else f"epoch_{best_epoch:03d}.pt")
        )
        _regular_file(selected_checkpoint, "selected checkpoint")
        gates = _mapping(preflight.configuration["gates"], "gates")
        write_final_artifacts(
            guard_io,
            run_directory=preflight.run_directory,
            events=events,
            history=training_result.history,
            access_ledger=asdict(access_ledger),
            training_scale_evidence=training_scale_payload,
            training_scale_evidence_sha256=training_scale_evidence_sha256,
            minimum_improvement=float(gates["minimum_post_zero_improvement"]),
            selected_checkpoint=selected_checkpoint,
            final_checkpoint=checkpoint_records[completed_epoch][0],
        )
        return 0
    except Exception as exc:
        if not events or events[-1].get("status") not in {"failed", "completed"}:
            try:
                _append_event(
                    guard_io,
                    events_path,
                    events,
                    {
                        "status": "failed",
                        "error_type": (
                            "import_failure" if isinstance(exc, ImportError) else "failure"
                        ),
                        "stop_classification": "HARD_STOP",
                        "exception_type": type(exc).__name__,
                        "message": str(exc),
                    },
                )
            except Exception:
                pass
        raise
    finally:
        owner.release()


def main(argv: Sequence[str] | None = None) -> int:
    arguments = build_parser().parse_args(argv)
    try:
        return execute(arguments)
    except Exception as exc:
        report = {
            "status": "HARD_STOP",
            "error_type": type(exc).__name__,
            "message": str(exc),
        }
        print(canonical_json_bytes(report).decode("utf-8"), file=sys.stderr, end="")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
