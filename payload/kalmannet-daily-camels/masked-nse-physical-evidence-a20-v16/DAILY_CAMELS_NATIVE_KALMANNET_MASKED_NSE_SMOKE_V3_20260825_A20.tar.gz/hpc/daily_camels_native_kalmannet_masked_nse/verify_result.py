#!/usr/bin/env python3
"""Independent standard-library verifier for one completed daily KalmanNet smoke."""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import struct
import sys
import tempfile
from typing import Any, Mapping, Sequence


IDENTITY_FILE = "experiment_identity.json"
TRAINING_SCALE_FILE = "training_scale_evidence.json"
EVENT_FILE = "events.jsonl"
ACCESS_LEDGER_FILE = "access_ledger.json"
SUMMARY_FILE = "result_summary.json"
MANIFEST_FILE = "manifest.sha256.json"
COMPLETION_FILE = "completion.marker.json"
CHECKPOINT_MAGIC = b"DAILY_CAMELS_NATIVE_KNET_RESUME_V1\n"
CHECKPOINT_HEADER_LENGTH = struct.Struct(">Q")
MAX_CHECKPOINT_HEADER_BYTES = 1024 * 1024

EXPECTED_BASINS = ("04105700", "09035800")
EXPECTED_LEADS = (1, 2, 3)
EXPECTED_EPOCHS = tuple(range(5))
TRAINING_START_INDEX = 365
VALIDATION_START_INDEX = 2557
SEGMENT_DAYS = 64
FILTER_WARMUP_DAYS = 16
STEPS_PER_EPOCH = 2
TRAINING_EVENTS_PER_BASIN_LEAD = SEGMENT_DAYS - FILTER_WARMUP_DAYS - 3
VALIDATION_EVENTS_PER_BASIN_LEAD = 128 - FILTER_WARMUP_DAYS - 3
MINIMUM_IMPROVEMENT = 1.0e-6
LOSS_EPSILON = 0.1
LOSS_CONTRACT_NAME = "daily_camels_physical_masked_nse_equal_basin_lead_v2"
SHA256_PATTERN = re.compile(r"[0-9a-f]{64}\Z")

MANIFESTED_FILES = {
    IDENTITY_FILE,
    TRAINING_SCALE_FILE,
    EVENT_FILE,
    ACCESS_LEDGER_FILE,
    SUMMARY_FILE,
    *(f"checkpoints/epoch_{epoch:03d}.pt" for epoch in EXPECTED_EPOCHS),
}
ALL_RUN_FILES = MANIFESTED_FILES | {MANIFEST_FILE, COMPLETION_FILE}


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def _reject_duplicate_members(
    pairs: Sequence[tuple[str, object]],
) -> dict[str, object]:
    payload: dict[str, object] = {}
    for name, value in pairs:
        if name in payload:
            raise ValueError(f"duplicate JSON member: {name}")
        payload[name] = value
    return payload


def _reject_nonfinite_json(value: str) -> None:
    raise ValueError(f"non-finite JSON number is forbidden: {value}")


def _canonical_json_bytes(
    value: object, *, newline: bool, ensure_ascii: bool = False
) -> bytes:
    encoded = json.dumps(
        value,
        ensure_ascii=ensure_ascii,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return encoded + (b"\n" if newline else b"")


def _loads_json(content: bytes, label: str) -> object:
    try:
        return json.loads(
            content.decode("utf-8"),
            object_pairs_hook=_reject_duplicate_members,
            parse_constant=_reject_nonfinite_json,
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ValueError(f"{label} is not strict UTF-8 JSON") from error


def _read_canonical_json(path: Path, label: str) -> Mapping[str, object]:
    content = path.read_bytes()
    payload = _loads_json(content, label)
    _require(isinstance(payload, Mapping), f"{label} root must be an object")
    _require(
        content == _canonical_json_bytes(payload, newline=True),
        f"{label} is not canonical JSON",
    )
    return payload


def _sha256_file(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _normalize_sha256(value: object, label: str) -> str:
    _require(isinstance(value, str), f"{label} must be a SHA-256 string")
    normalized = str(value).lower()
    _require(
        SHA256_PATTERN.fullmatch(normalized) is not None,
        f"{label} must contain 64 hexadecimal characters",
    )
    return normalized


def _mapping(value: object, label: str) -> Mapping[str, object]:
    _require(isinstance(value, Mapping), f"{label} must be an object")
    return value


def _finite(value: object, label: str) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError) as error:
        raise ValueError(f"{label} is not numeric") from error
    _require(math.isfinite(number), f"{label} is non-finite")
    return number


def _close(actual: object, expected: object, label: str, *, tight: bool = False) -> None:
    actual_value = _finite(actual, label)
    expected_value = _finite(expected, f"expected {label}")
    tolerance = 1.0e-12 if tight else 1.0e-6
    _require(
        math.isclose(
            actual_value,
            expected_value,
            rel_tol=0.0 if tight else 1.0e-6,
            abs_tol=tolerance,
        ),
        f"{label} differs: expected {expected_value}, got {actual_value}",
    )


def _safe_relative_name(value: object, label: str) -> str:
    _require(isinstance(value, str) and bool(value), f"{label} must be non-empty")
    name = str(value)
    _require("\\" not in name, f"{label} uses a backslash")
    relative = PurePosixPath(name)
    _require(
        not relative.is_absolute()
        and bool(relative.parts)
        and ".." not in relative.parts
        and relative.as_posix() == name,
        f"{label} is not a normalized safe relative path",
    )
    return name


def _admitted_file(root: Path, relative_value: object, label: str) -> Path:
    relative = _safe_relative_name(relative_value, label)
    path = root.joinpath(*PurePosixPath(relative).parts)
    resolved = path.resolve(strict=True)
    _require(root in resolved.parents, f"{label} escapes the run directory")
    _require(path.is_file() and not path.is_symlink(), f"{label} is not a regular file")
    _require(path.stat().st_nlink == 1, f"{label} must have exactly one hard link")
    return path


def _verify_run_inventory(root: Path) -> None:
    actual_files: set[str] = set()
    actual_directories: set[str] = set()
    for path in root.rglob("*"):
        relative = path.relative_to(root).as_posix()
        _require(not path.is_symlink(), f"run artifact is a symbolic link: {relative}")
        if path.is_dir():
            actual_directories.add(relative)
        else:
            _require(path.is_file(), f"run artifact is a special file: {relative}")
            _require(
                path.stat().st_nlink == 1,
                f"run artifact must have exactly one hard link: {relative}",
            )
            actual_files.add(relative)
    _require(actual_files == ALL_RUN_FILES, "run file inventory differs")
    _require(actual_directories == {"checkpoints"}, "run directory inventory differs")


def _verify_identity(
    root: Path, experiment_id: str, configuration_sha256: str
) -> tuple[Mapping[str, object], str]:
    document = _read_canonical_json(root / IDENTITY_FILE, "experiment identity")
    _require(
        set(document)
        == {
            "schema_version",
            "identity",
            "identity_sha256",
            "logical_input_paths",
            "device_requirement",
        },
        "experiment identity member set differs",
    )
    _require(
        document["schema_version"] == "daily_camels_native_knet_identity_v1",
        "experiment identity schema differs",
    )
    _require(document["device_requirement"] == "cuda", "device requirement differs")
    identity = _mapping(document["identity"], "run identity")
    _require(
        set(identity)
        == {
            "experiment_id",
            "configuration_sha256",
            "source_sha256",
            "input_archive_sha256",
        },
        "run identity member set differs",
    )
    _require(identity["experiment_id"] == experiment_id, "run identity experiment differs")
    _require(
        _normalize_sha256(identity["configuration_sha256"], "identity configuration SHA-256")
        == configuration_sha256,
        "run identity configuration SHA-256 differs",
    )
    source_hashes = _mapping(identity["source_sha256"], "identity source hashes")
    _require(bool(source_hashes), "identity source hash inventory is empty")
    for name, digest in source_hashes.items():
        _safe_relative_name(name, "identity source path")
        _normalize_sha256(digest, f"identity source SHA-256 for {name}")
    input_hashes = _mapping(identity["input_archive_sha256"], "identity input hashes")
    expected_inputs = {f"inputs/basin_{basin_id}.npz" for basin_id in EXPECTED_BASINS}
    _require(set(input_hashes) == expected_inputs, "identity input archive inventory differs")
    for name, digest in input_hashes.items():
        _normalize_sha256(digest, f"identity input SHA-256 for {name}")
    _require(
        document["logical_input_paths"] == sorted(expected_inputs),
        "logical input path inventory differs",
    )
    identity_sha256 = sha256(
        _canonical_json_bytes(identity, newline=False)
    ).hexdigest()
    _require(
        _normalize_sha256(document["identity_sha256"], "identity SHA-256")
        == identity_sha256,
        "experiment identity SHA-256 does not match its canonical identity",
    )
    return identity, identity_sha256


def _verify_loss_contract(contract: Mapping[str, object]) -> None:
    _require(contract.get("contract_name") == LOSS_CONTRACT_NAME, "loss contract differs")
    _require(contract.get("forecast_leads_days") == [1, 2, 3], "loss leads differ")
    _require(
        contract.get("formula")
        == (
            "mean_equal_complete_basin_lead_events((prediction_physical-"
            "target_physical)^2/(basin_training_population_std_original_units+0.1)^2)"
        ),
        "primary loss formula differs",
    )
    _require(contract.get("population_standard_deviation_ddof") == 0, "loss ddof differs")
    _close(
        contract.get("loss_epsilon_original_discharge_units"),
        LOSS_EPSILON,
        "loss epsilon",
        tight=True,
    )
    _require(
        contract.get("weighting_order")
        == [
            "equal_events_within_each_basin_and_lead",
            "equal_leads_1_2_3_within_each_basin",
            "equal_basins",
        ],
        "loss weighting order differs",
    )
    _require(
        contract.get("target_noise") == "none_for_kalmannet_filter_training",
        "training target-noise policy differs",
    )
    diagnostic = _mapping(
        contract.get("tukf09_compatibility_diagnostic"),
        "compatibility diagnostic",
    )
    _require(
        diagnostic.get("used_for_training_or_checkpoint_selection") is False,
        "compatibility diagnostic entered training or selection",
    )
    sources = _mapping(contract.get("source_sha256"), "loss reference source hashes")
    _require(bool(sources), "loss reference source hashes are absent")
    for name, digest in sources.items():
        _safe_relative_name(name, "loss reference source path")
        _normalize_sha256(digest, f"loss reference source SHA-256 for {name}")


def _verify_training_scales(
    root: Path, experiment_id: str
) -> tuple[str, Mapping[str, float]]:
    evidence = _read_canonical_json(root / TRAINING_SCALE_FILE, "training scale evidence")
    _require(
        set(evidence)
        == {
            "schema_version",
            "experiment_id",
            "training_scale_evidence_sha256",
            "loss_contract",
            "scales",
        },
        "training scale evidence member set differs",
    )
    _require(
        evidence["schema_version"] == "daily_camels_training_scale_evidence_v1",
        "training scale evidence schema differs",
    )
    _require(evidence["experiment_id"] == experiment_id, "training scale experiment differs")
    _verify_loss_contract(_mapping(evidence["loss_contract"], "loss contract"))
    scales = _mapping(evidence["scales"], "training scales")
    _require(
        set(scales)
        == {
            "contract_name",
            "basin_ids",
            "training_start_index",
            "validation_start_index",
            "training_rows_per_basin",
            "training_row_count",
            "global_discharge_mean",
            "global_discharge_population_std",
            "population_standard_deviation_ddof",
            "per_basin",
        },
        "training scale member set differs",
    )
    _require(scales["contract_name"] == LOSS_CONTRACT_NAME, "scale contract differs")
    _require(scales["basin_ids"] == list(EXPECTED_BASINS), "scale basin order differs")
    _require(scales["training_start_index"] == 0, "scale start index differs")
    _require(scales["validation_start_index"] == VALIDATION_START_INDEX, "scale stop differs")
    _require(scales["training_rows_per_basin"] == 2557, "scale row count differs")
    _require(scales["training_row_count"] == 5114, "shared scale row count differs")
    _require(scales["population_standard_deviation_ddof"] == 0, "scale ddof differs")
    _finite(scales["global_discharge_mean"], "global training mean")
    _require(
        _finite(scales["global_discharge_population_std"], "global training standard deviation")
        > 0.0,
        "global training standard deviation is not positive",
    )
    per_basin = _mapping(scales["per_basin"], "per-basin training scales")
    _require(set(per_basin) == set(EXPECTED_BASINS), "per-basin scale inventory differs")
    standard_deviations: dict[str, float] = {}
    for basin_id in EXPECTED_BASINS:
        item = _mapping(per_basin[basin_id], f"training scale for {basin_id}")
        _require(item.get("contract_name") == LOSS_CONTRACT_NAME, "basin scale contract differs")
        _require(item.get("basin_id") == basin_id, "basin scale identity differs")
        _require(item.get("training_start_index") == 0, "basin scale start differs")
        _require(
            item.get("validation_start_index") == VALIDATION_START_INDEX,
            "basin scale stop differs",
        )
        _require(item.get("finite_observation_count") == 2557, "basin scale count differs")
        _finite(item.get("population_mean_original_discharge_units"), "basin training mean")
        standard_deviation = _finite(
            item.get("population_std_original_discharge_units"),
            f"training standard deviation for {basin_id}",
        )
        _require(standard_deviation > 0.0, "basin training standard deviation is not positive")
        standard_deviations[basin_id] = standard_deviation
    recomputed = sha256(
        _canonical_json_bytes(scales, newline=False, ensure_ascii=True)
    ).hexdigest()
    claimed = _normalize_sha256(
        evidence["training_scale_evidence_sha256"],
        "training scale evidence SHA-256",
    )
    _require(recomputed == claimed, "training scale evidence SHA-256 differs")
    return claimed, standard_deviations


def _verify_access_ledger(root: Path) -> tuple[Mapping[str, object], int]:
    ledger = _read_canonical_json(root / ACCESS_LEDGER_FILE, "access ledger")
    expected_keys = {
        "raw_source_byte_reads",
        "archive_materialization_sessions",
        "archive_member_reads",
        "evaluation_array_reads",
        "evaluation_predictions",
        "evaluation_metrics",
        "evaluation_outputs",
    }
    _require(set(ledger) == expected_keys, "access ledger member set differs")
    forbidden = (
        "raw_source_byte_reads",
        "evaluation_array_reads",
        "evaluation_predictions",
        "evaluation_metrics",
        "evaluation_outputs",
    )
    _require(
        all(int(ledger[name]) == 0 for name in forbidden),
        "reserved-data access counters are not zero",
    )
    sessions = int(ledger["archive_materialization_sessions"])
    _require(sessions >= 1, "archive materialization session count is absent")
    expected_reads = {
        name: 2 * sessions for name in ("dates_ns", "forcing", "observations", "parameters")
    }
    _require(ledger["archive_member_reads"] == expected_reads, "archive member reads differ")
    return ledger, sessions


def _verify_cell_evidence(
    value: object,
    *,
    standard_deviation: float,
    event_count: int,
    label: str,
) -> float:
    cell = _mapping(value, label)
    _require(
        set(cell) == {"event_count", "physical_mse", "primary_loss"},
        f"{label} member set differs",
    )
    _require(int(cell["event_count"]) == event_count, f"{label} event count differs")
    physical_mse = _finite(cell["physical_mse"], f"{label} physical MSE")
    primary_loss = _finite(cell["primary_loss"], f"{label} primary loss")
    _require(physical_mse >= 0.0 and primary_loss >= 0.0, f"{label} loss is negative")
    _close(
        primary_loss,
        physical_mse / (standard_deviation + LOSS_EPSILON) ** 2,
        f"{label} physical MSE to primary loss formula",
    )
    return primary_loss


def _verify_validation_row(
    row: Mapping[str, object], standard_deviations: Mapping[str, float], epoch: int
) -> float:
    per_basin = _mapping(row.get("per_basin"), f"epoch {epoch} validation basins")
    _require(set(per_basin) == set(EXPECTED_BASINS), "validation basin inventory differs")
    basin_losses: list[float] = []
    for basin_id in EXPECTED_BASINS:
        metrics = _mapping(per_basin[basin_id], f"epoch {epoch} basin {basin_id}")
        cells = _mapping(
            metrics.get("per_lead_loss_evidence"),
            f"epoch {epoch} basin {basin_id} validation cells",
        )
        _require(set(cells) == {"1", "2", "3"}, "validation lead inventory differs")
        lead_losses = [
            _verify_cell_evidence(
                cells[str(lead)],
                standard_deviation=standard_deviations[basin_id],
                event_count=VALIDATION_EVENTS_PER_BASIN_LEAD,
                label=f"epoch {epoch} basin {basin_id} lead {lead} validation cell",
            )
            for lead in EXPECTED_LEADS
        ]
        basin_loss = math.fsum(lead_losses) / len(lead_losses)
        _close(metrics.get("primary_loss"), basin_loss, "validation basin equal-lead mean")
        _close(metrics.get("validation_loss"), basin_loss, "validation basin loss")
        _close(metrics.get("selection_score"), -basin_loss, "validation basin selection", tight=True)
        masked = _mapping(metrics.get("masked_nse_loss_by_lead"), "validation lead losses")
        targets = _mapping(metrics.get("target_count_by_lead"), "validation target counts")
        knet_nse = _mapping(metrics.get("knet_nse"), "validation KalmanNet NSE")
        _require(set(masked) == set(targets) == set(knet_nse) == {"1", "2", "3"}, "validation lead metrics differ")
        for lead, lead_loss in zip(EXPECTED_LEADS, lead_losses, strict=True):
            _close(masked[str(lead)], lead_loss, "validation recorded lead loss")
            _require(
                int(targets[str(lead)]) == VALIDATION_EVENTS_PER_BASIN_LEAD,
                "validation basin target count differs",
            )
            _finite(knet_nse[str(lead)], "validation KalmanNet Nash-Sutcliffe efficiency")
        basin_losses.append(basin_loss)
    shared_loss = math.fsum(basin_losses) / len(basin_losses)
    _close(row.get("primary_loss"), shared_loss, "validation equal-basin mean")
    _close(row.get("validation_loss"), shared_loss, "validation shared loss")
    _close(row.get("selection_score"), -shared_loss, "validation selection score", tight=True)
    targets = _mapping(row.get("target_count_by_lead"), "shared validation target counts")
    _require(
        targets
        == {
            str(lead): len(EXPECTED_BASINS) * VALIDATION_EVENTS_PER_BASIN_LEAD
            for lead in EXPECTED_LEADS
        },
        "shared validation target counts differ",
    )
    _require(
        row.get("basin_aggregation") == "equal_weight_mean_of_per_basin_metrics",
        "validation basin aggregation differs",
    )
    _close(
        row.get("routed_queue_correction_abs_max"),
        0.0,
        "routed queue correction",
        tight=True,
    )
    return shared_loss


def _verify_training_row(
    row: Mapping[str, object], standard_deviations: Mapping[str, float], epoch: int
) -> None:
    _require(int(row.get("optimizer_steps", -1)) == epoch * STEPS_PER_EPOCH, "optimizer step count differs")
    events_per_unit = len(EXPECTED_LEADS) * TRAINING_EVENTS_PER_BASIN_LEAD
    expected_cumulative_events = epoch * STEPS_PER_EPOCH * len(EXPECTED_BASINS) * events_per_unit
    _require(
        int(row.get("sampled_forecast_events", -1)) == expected_cumulative_events,
        "sampled forecast event count differs",
    )
    units = row.get("training_units")
    _require(isinstance(units, list), "training units are absent")
    if epoch == 0:
        _require(units == [], "epoch-zero training units are not empty")
        _require(row.get("training_loss") is None, "epoch-zero training loss must be null")
        _require(row.get("finite_gradients") is None, "epoch-zero gradient flag differs")
        _require(
            int(row.get("nonzero_gradient_parameter_tensor_count", -1)) == 0,
            "epoch-zero nonzero-gradient count differs",
        )
        _require(row.get("nonzero_gradient_parameter_names") == [], "epoch-zero gradient names differ")
        return

    _require(len(units) == STEPS_PER_EPOCH * len(EXPECTED_BASINS), "training unit count differs")
    _require(row.get("finite_gradients") is True, "finite-gradient evidence differs")
    names = row.get("nonzero_gradient_parameter_names")
    _require(isinstance(names, list) and bool(names), "nonzero gradient names are absent")
    _require(
        int(row.get("nonzero_gradient_parameter_tensor_count", 0)) == len(set(names)),
        "nonzero gradient tensor count differs",
    )
    grouped: dict[int, dict[str, Mapping[str, object]]] = {}
    all_unit_losses: list[float] = []
    required_unit_keys = {
        "step_in_epoch",
        "basin_index",
        "basin_id",
        "start_index",
        "end_index_exclusive",
        "forecast_target_count",
        "masked_nse_loss",
        "primary_loss",
        "per_lead_loss_evidence",
    }
    for value in units:
        unit = _mapping(value, f"epoch {epoch} training unit")
        _require(required_unit_keys.issubset(unit), "training unit evidence is incomplete")
        step = int(unit["step_in_epoch"])
        basin_id = str(unit["basin_id"])
        _require(step in range(STEPS_PER_EPOCH), "training step index differs")
        _require(basin_id in EXPECTED_BASINS, "training basin identity differs")
        _require(
            int(unit["basin_index"]) == EXPECTED_BASINS.index(basin_id),
            "training basin index differs",
        )
        by_basin = grouped.setdefault(step, {})
        _require(basin_id not in by_basin, "training step repeats a basin")
        by_basin[basin_id] = unit
        start = int(unit["start_index"])
        end = int(unit["end_index_exclusive"])
        _require(
            TRAINING_START_INDEX <= start <= VALIDATION_START_INDEX - SEGMENT_DAYS
            and end == start + SEGMENT_DAYS,
            "training unit interval differs",
        )
        _require(int(unit["forecast_target_count"]) == events_per_unit, "training unit event count differs")
        cells = _mapping(unit["per_lead_loss_evidence"], "training lead cells")
        _require(set(cells) == {"1", "2", "3"}, "training lead inventory differs")
        lead_losses = [
            _verify_cell_evidence(
                cells[str(lead)],
                standard_deviation=standard_deviations[basin_id],
                event_count=TRAINING_EVENTS_PER_BASIN_LEAD,
                label=f"epoch {epoch} step {step} basin {basin_id} lead {lead} training cell",
            )
            for lead in EXPECTED_LEADS
        ]
        unit_loss = math.fsum(lead_losses) / len(lead_losses)
        _close(unit["primary_loss"], unit_loss, "training unit equal-lead mean")
        _close(unit["masked_nse_loss"], unit_loss, "training unit legacy loss alias")
        all_unit_losses.append(unit_loss)
    _require(set(grouped) == set(range(STEPS_PER_EPOCH)), "training step inventory differs")
    _require(
        all(set(by_basin) == set(EXPECTED_BASINS) for by_basin in grouped.values()),
        "an optimizer step lacks exactly one unit from every basin",
    )
    _close(
        row.get("training_loss"),
        math.fsum(all_unit_losses) / len(all_unit_losses),
        "epoch training equal-step and equal-basin mean",
    )


def _verify_history(
    summary: Mapping[str, object],
    scale_sha256: str,
    standard_deviations: Mapping[str, float],
    sessions: int,
) -> tuple[list[Mapping[str, object]], int, float]:
    raw_history = summary.get("history")
    _require(isinstance(raw_history, list), "training history is absent")
    history = [_mapping(row, "training history row") for row in raw_history]
    _require(
        [int(row.get("epoch", -1)) for row in history] == list(EXPECTED_EPOCHS),
        "training history is not contiguous through epoch four",
    )
    parameter_hashes: list[str] = []
    for epoch, row in enumerate(history):
        _require(
            _normalize_sha256(
                row.get("training_scale_evidence_sha256"),
                f"epoch {epoch} training scale evidence SHA-256",
            )
            == scale_sha256,
            "training scale evidence changed across epochs",
        )
        _verify_validation_row(row, standard_deviations, epoch)
        _verify_training_row(row, standard_deviations, epoch)
        parameter_hashes.append(
            _normalize_sha256(row.get("parameter_sha256"), f"epoch {epoch} parameter SHA-256")
        )
    _require(any(value != parameter_hashes[0] for value in parameter_hashes[1:]), "parameters did not change after epoch zero")

    post_zero = history[1:]
    best_row = max(post_zero, key=lambda row: float(row["selection_score"]))
    best_epoch = int(best_row["epoch"])
    epoch_zero_score = _finite(history[0]["selection_score"], "epoch-zero selection score")
    best_score = _finite(best_row["selection_score"], "best post-zero selection score")
    improvement = best_score - epoch_zero_score
    _require(improvement > MINIMUM_IMPROVEMENT, "post-zero primary loss did not improve")

    gate = _mapping(summary.get("science_gate"), "science gate")
    _require(gate.get("passed") is True and gate.get("reasons") == [], "science gate did not pass")
    _require(int(gate.get("best_epoch", -1)) == best_epoch, "science gate best epoch differs")
    _close(gate.get("epoch_zero_selection_score"), epoch_zero_score, "science gate epoch-zero score", tight=True)
    _close(gate.get("best_post_zero_selection_score"), best_score, "science gate best score", tight=True)
    _close(gate.get("improvement"), improvement, "science gate improvement", tight=True)
    _require(int(gate.get("optimizer_steps", -1)) == 8, "science gate optimizer steps differ")
    _require(
        int(gate.get("nonzero_gradient_parameter_tensor_count", -1))
        == max(
            int(row.get("nonzero_gradient_parameter_tensor_count", 0))
            for row in post_zero
        ),
        "science gate nonzero-gradient count differs",
    )
    _require(
        int(gate.get("archive_materialization_sessions", -1)) == sessions,
        "science gate materialization sessions differ",
    )
    _require(
        _normalize_sha256(gate.get("training_scale_evidence_sha256"), "science gate scale SHA-256")
        == scale_sha256,
        "science gate scale SHA-256 differs",
    )
    return history, best_epoch, improvement


def _read_checkpoint_header(
    path: Path, identity: Mapping[str, object], identity_sha256: str
) -> Mapping[str, object]:
    with path.open("rb") as stream:
        _require(stream.read(len(CHECKPOINT_MAGIC)) == CHECKPOINT_MAGIC, "checkpoint magic differs")
        packed = stream.read(CHECKPOINT_HEADER_LENGTH.size)
        _require(len(packed) == CHECKPOINT_HEADER_LENGTH.size, "checkpoint header length is missing")
        header_length = CHECKPOINT_HEADER_LENGTH.unpack(packed)[0]
        _require(0 < header_length <= MAX_CHECKPOINT_HEADER_BYTES, "checkpoint header length differs")
        header_bytes = stream.read(header_length)
        _require(len(header_bytes) == header_length, "checkpoint header is truncated")
        header = _loads_json(header_bytes, "checkpoint header")
        _require(isinstance(header, Mapping), "checkpoint header root is not an object")
        _require(
            header_bytes == _canonical_json_bytes(header, newline=False),
            "checkpoint header is not canonical JSON",
        )
        payload_digest = sha256()
        payload_size = 0
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            payload_digest.update(block)
            payload_size += len(block)
    _require(payload_size > 0, "checkpoint payload is empty")
    _require(
        set(header)
        == {
            "schema_version",
            "identity",
            "identity_sha256",
            "payload_sha256",
            "previous_checkpoint_sha256",
        },
        "checkpoint header member set differs",
    )
    _require(header["schema_version"] == "daily_camels_native_knet_resume_v1", "checkpoint schema differs")
    _require(header["identity"] == identity, "checkpoint identity differs")
    _require(
        _normalize_sha256(header["identity_sha256"], "checkpoint identity SHA-256")
        == identity_sha256,
        "checkpoint identity SHA-256 differs",
    )
    _require(
        _normalize_sha256(header["payload_sha256"], "checkpoint payload SHA-256")
        == payload_digest.hexdigest(),
        "checkpoint payload SHA-256 differs",
    )
    previous = header["previous_checkpoint_sha256"]
    if previous is not None:
        _normalize_sha256(previous, "checkpoint previous SHA-256")
    return header


def _verify_manifest_and_checkpoints(
    root: Path,
    experiment_id: str,
    identity: Mapping[str, object],
    identity_sha256: str,
    scale_sha256: str,
    summary: Mapping[str, object],
    best_epoch: int,
) -> tuple[str, str, Mapping[int, str]]:
    manifest = _read_canonical_json(root / MANIFEST_FILE, "result manifest")
    _require(
        set(manifest) == {"schema_version", "experiment_id", "file_count", "files"},
        "result manifest member set differs",
    )
    _require(manifest["schema_version"] == "daily_camels_native_knet_manifest_v1", "result manifest schema differs")
    _require(manifest["experiment_id"] == experiment_id, "result manifest experiment differs")
    files = _mapping(manifest["files"], "result manifest files")
    _require(set(files) == MANIFESTED_FILES, "result manifest file coverage differs")
    _require(int(manifest["file_count"]) == len(MANIFESTED_FILES), "result manifest file count differs")
    for relative, value in files.items():
        record = _mapping(value, f"manifest record for {relative}")
        _require(set(record) == {"sha256", "size_bytes"}, "manifest file record differs")
        path = _admitted_file(root, relative, f"manifest file {relative}")
        _require(int(record["size_bytes"]) == path.stat().st_size, f"manifest size differs: {relative}")
        _require(
            _normalize_sha256(record["sha256"], f"manifest SHA-256 for {relative}")
            == _sha256_file(path),
            f"manifest SHA-256 differs: {relative}",
        )

    checkpoint_hashes: dict[int, str] = {}
    previous_hash: str | None = None
    for epoch in EXPECTED_EPOCHS:
        relative = f"checkpoints/epoch_{epoch:03d}.pt"
        path = _admitted_file(root, relative, f"epoch {epoch} checkpoint")
        header = _read_checkpoint_header(path, identity, identity_sha256)
        _require(
            header["previous_checkpoint_sha256"] == previous_hash,
            f"checkpoint chain differs at epoch {epoch}",
        )
        previous_hash = _sha256_file(path)
        checkpoint_hashes[epoch] = previous_hash

    completion = _read_canonical_json(root / COMPLETION_FILE, "completion marker")
    expected_completion_keys = {
        "schema_version",
        "experiment_id",
        "status",
        "training_scale_evidence_sha256",
        "manifest_file",
        "manifest_sha256",
        "summary_file",
        "summary_sha256",
        "selected_checkpoint",
        "selected_checkpoint_sha256",
        "final_checkpoint",
        "final_checkpoint_sha256",
    }
    _require(set(completion) == expected_completion_keys, "completion marker member set differs")
    _require(completion["schema_version"] == "daily_camels_native_knet_completion_v1", "completion schema differs")
    _require(completion["experiment_id"] == experiment_id, "completion experiment differs")
    _require(completion["status"] == "COMPLETED", "completion status differs")
    _require(
        _normalize_sha256(completion["training_scale_evidence_sha256"], "completion scale SHA-256")
        == scale_sha256,
        "completion scale SHA-256 differs",
    )
    _require(completion["manifest_file"] == MANIFEST_FILE, "completion manifest path differs")
    _require(completion["summary_file"] == SUMMARY_FILE, "completion summary path differs")
    _require(
        _normalize_sha256(completion["manifest_sha256"], "completion manifest SHA-256")
        == _sha256_file(root / MANIFEST_FILE),
        "completion manifest SHA-256 differs",
    )
    _require(
        _normalize_sha256(completion["summary_sha256"], "completion summary SHA-256")
        == _sha256_file(root / SUMMARY_FILE),
        "completion summary SHA-256 differs",
    )
    selected_relative = f"checkpoints/epoch_{best_epoch:03d}.pt"
    _require(summary.get("selected_checkpoint") == selected_relative, "summary selected checkpoint differs")
    _require(completion["selected_checkpoint"] == selected_relative, "completion selected checkpoint is not the best epoch")
    _require(
        _normalize_sha256(completion["selected_checkpoint_sha256"], "selected checkpoint SHA-256")
        == checkpoint_hashes[best_epoch],
        "selected checkpoint SHA-256 differs",
    )
    _require(completion["final_checkpoint"] == "checkpoints/epoch_004.pt", "final checkpoint is not epoch four")
    _require(
        _normalize_sha256(completion["final_checkpoint_sha256"], "final checkpoint SHA-256")
        == checkpoint_hashes[4],
        "final checkpoint SHA-256 differs",
    )
    return _sha256_file(root / MANIFEST_FILE), _sha256_file(root / COMPLETION_FILE), checkpoint_hashes


def _read_events(root: Path) -> list[Mapping[str, object]]:
    content = (root / EVENT_FILE).read_bytes()
    _require(content.endswith(b"\n"), "event ledger lacks a final newline")
    lines = content.splitlines()
    _require(bool(lines), "event ledger is empty")
    events: list[Mapping[str, object]] = []
    for index, line in enumerate(lines):
        event = _loads_json(line, f"event {index}")
        _require(isinstance(event, Mapping), f"event {index} is not an object")
        _require(line == _canonical_json_bytes(event, newline=False), f"event {index} is not canonical")
        _require(int(event.get("sequence", -1)) == index, f"event sequence differs at {index}")
        events.append(event)
    return events


def _verify_events(
    root: Path,
    history: Sequence[Mapping[str, object]],
    checkpoint_hashes: Mapping[int, str],
    scale_sha256: str,
    sessions: int,
) -> None:
    events = _read_events(root)
    _require(events[-1].get("event_type") == "completed", "terminal event is not completed")
    _require(str(events[-1].get("status", "")).lower() == "completed", "terminal event status differs")
    _require(
        not any(event.get("status") == "failed" or "error_type" in event for event in events),
        "event ledger contains a failure",
    )
    preflights = [event for event in events if event.get("event_type") == "preflight_completed"]
    scale_events = [event for event in events if event.get("event_type") == "training_scales_fitted"]
    resume_events = [event for event in events if event.get("event_type") == "resume_checkpoint_loaded"]
    _require(len(preflights) == sessions, "preflight event count differs from sessions")
    _require(len(scale_events) == sessions, "scale event count differs from sessions")
    _require(len(resume_events) == sessions - 1, "resume event count differs from sessions")
    for event in scale_events:
        _require(
            _normalize_sha256(event.get("training_scale_evidence_sha256"), "event scale SHA-256")
            == scale_sha256,
            "event scale SHA-256 differs",
        )
    checkpoint_events = [event for event in events if event.get("event_type") == "epoch_checkpointed"]
    _require(len(checkpoint_events) == len(EXPECTED_EPOCHS), "checkpoint event count differs")
    by_epoch = {int(event.get("epoch", -1)): event for event in checkpoint_events}
    _require(set(by_epoch) == set(EXPECTED_EPOCHS), "checkpoint event epoch coverage differs")
    for epoch in EXPECTED_EPOCHS:
        event = by_epoch[epoch]
        _require(event.get("checkpoint") == f"checkpoints/epoch_{epoch:03d}.pt", "checkpoint event path differs")
        _require(
            _normalize_sha256(event.get("checkpoint_sha256"), "checkpoint event SHA-256")
            == checkpoint_hashes[epoch],
            "checkpoint event SHA-256 differs",
        )
        _require(event.get("training_record") == history[epoch], "checkpoint event training record differs")


def _write_report(path: Path, report: Mapping[str, object]) -> None:
    destination = Path(path).resolve(strict=False)
    destination.parent.mkdir(parents=True, exist_ok=True)
    _require(not destination.exists(), "verification output already exists")
    content = _canonical_json_bytes(report, newline=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{destination.name}.", suffix=".tmp", dir=str(destination.parent)
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temporary, destination)
        temporary.unlink()
    finally:
        if temporary.exists():
            temporary.unlink()


def verify_result(
    *,
    run_directory: Path,
    experiment_id: str,
    configuration_sha256: str,
    training_job_id: str,
    output_path: Path,
) -> Mapping[str, object]:
    """Verify immutable result closure and write a last, external receipt."""

    _require(isinstance(experiment_id, str) and bool(experiment_id), "experiment id is empty")
    configuration_hash = _normalize_sha256(configuration_sha256, "configuration SHA-256")
    job_id = str(training_job_id)
    _require(job_id.isdigit() and int(job_id) > 0, "training job id must be a positive integer")
    selected_run = Path(run_directory)
    _require(
        selected_run.is_dir() and not selected_run.is_symlink(),
        "run directory is absent or linked",
    )
    root = selected_run.resolve(strict=True)
    output = Path(output_path).resolve(strict=False)
    _require(root != output and root not in output.parents, "verification output must be outside the run directory")

    _verify_run_inventory(root)
    identity, identity_sha256 = _verify_identity(root, experiment_id, configuration_hash)
    scale_sha256, standard_deviations = _verify_training_scales(root, experiment_id)
    _, sessions = _verify_access_ledger(root)
    summary = _read_canonical_json(root / SUMMARY_FILE, "result summary")
    _require(summary.get("schema_version") == "daily_camels_native_knet_result_v1", "result summary schema differs")
    _require(summary.get("experiment_id") == experiment_id, "result summary experiment differs")
    _require(summary.get("status") == "COMPLETED", "result summary status differs")
    _require(
        _normalize_sha256(summary.get("training_scale_evidence_sha256"), "summary scale SHA-256")
        == scale_sha256,
        "result summary scale SHA-256 differs",
    )
    history, best_epoch, improvement = _verify_history(
        summary, scale_sha256, standard_deviations, sessions
    )
    manifest_sha256, completion_sha256, checkpoint_hashes = _verify_manifest_and_checkpoints(
        root,
        experiment_id,
        identity,
        identity_sha256,
        scale_sha256,
        summary,
        best_epoch,
    )
    _verify_events(root, history, checkpoint_hashes, scale_sha256, sessions)

    final_row = history[-1]
    report: dict[str, object] = {
        "schema_version": "daily_camels_native_knet_result_verification_v1",
        "status": "VERIFIED",
        "experiment_id": experiment_id,
        "training_job_id": job_id,
        "run_directory": str(root),
        "configuration_sha256": configuration_hash,
        "identity_sha256": identity_sha256,
        "training_scale_evidence_sha256": scale_sha256,
        "manifest_sha256": manifest_sha256,
        "completion_sha256": completion_sha256,
        "summary_sha256": _sha256_file(root / SUMMARY_FILE),
        "best_epoch": best_epoch,
        "post_zero_improvement": improvement,
        "optimizer_steps": int(final_row["optimizer_steps"]),
        "sampled_forecast_events": int(final_row["sampled_forecast_events"]),
        "basin_ids": list(EXPECTED_BASINS),
        "forecast_leads_days": list(EXPECTED_LEADS),
        "training_events_per_basin_lead": TRAINING_EVENTS_PER_BASIN_LEAD,
        "validation_events_per_basin_lead": VALIDATION_EVENTS_PER_BASIN_LEAD,
        "reserved_data_access_zero": True,
        "checkpoint_sha256": {
            str(epoch): checkpoint_hashes[epoch] for epoch in EXPECTED_EPOCHS
        },
    }
    _write_report(output, report)
    return report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-directory", type=Path, required=True)
    parser.add_argument("--experiment-id", required=True)
    parser.add_argument("--configuration-sha256", required=True)
    parser.add_argument("--training-job-id", required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    arguments = build_parser().parse_args(argv)
    try:
        report = verify_result(
            run_directory=arguments.run_directory,
            experiment_id=arguments.experiment_id,
            configuration_sha256=arguments.configuration_sha256,
            training_job_id=arguments.training_job_id,
            output_path=arguments.output,
        )
    except Exception as error:
        failure = {
            "status": "VERIFICATION_FAILED",
            "error_type": type(error).__name__,
            "error": str(error),
        }
        print(_canonical_json_bytes(failure, newline=True).decode("utf-8"), end="", file=sys.stderr)
        return 2
    print(_canonical_json_bytes(report, newline=True).decode("utf-8"), end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
