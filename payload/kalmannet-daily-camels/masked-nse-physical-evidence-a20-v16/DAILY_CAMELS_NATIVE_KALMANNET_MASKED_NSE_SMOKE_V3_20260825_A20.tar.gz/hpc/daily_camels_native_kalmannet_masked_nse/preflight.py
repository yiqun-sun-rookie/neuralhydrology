#!/usr/bin/env python3
"""Standard-library-first verifier for the daily CAMELS KalmanNet bundle."""

from __future__ import annotations

import argparse
import ctypes
from hashlib import sha256
import importlib
import json
import os
from pathlib import Path, PurePosixPath
import socket
import sys
from typing import Any, Mapping


EXPERIMENT_ID = "DAILY_CAMELS_NATIVE_KALMANNET_MASKED_NSE_SMOKE_V3_20260825_A20"
SCHEMA_VERSION = "daily_camels_native_kalmannet_masked_nse_hpc_bundle_v3"
EXPECTED_INPUT_NAMES = {
    "inputs/basin_04105700.npz",
    "inputs/basin_09035800.npz",
}
DEFAULT_RUN_ROOT = Path(
    "/data1/home/sunyiq/kalmannet_daily_camels_masked_nse_v3_20260825/"
    "DAILY_CAMELS_NATIVE_KALMANNET_MASKED_NSE_SMOKE_V3_20260825_A20"
)


def _safe_member_name(name: str) -> PurePosixPath:
    if "\\" in name:
        raise RuntimeError(f"manifest member uses a backslash: {name}")
    relative = PurePosixPath(name)
    if relative.is_absolute() or not relative.parts or ".." in relative.parts:
        raise RuntimeError(f"unsafe manifest member: {name}")
    lowered = tuple(part.lower() for part in relative.parts)
    if (
        any("hourly" in part for part in lowered)
        or any(part == "evaluation" or part.startswith("evaluation_") for part in lowered)
        or ".git" in lowered
        or "__pycache__" in lowered
    ):
        raise RuntimeError(f"forbidden manifest member: {name}")
    return relative


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_manifest(path: Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise RuntimeError("bundle manifest root must be a JSON object")
    return payload


def verify_bundle_root(bundle_root: Path) -> dict[str, Any]:
    """Verify bytes and inventory without importing or loading either array archive."""

    root = Path(bundle_root).resolve()
    manifest_path = root / "bundle_manifest.json"
    if not root.is_dir() or not manifest_path.is_file():
        raise RuntimeError("extracted bundle root or internal manifest is absent")
    manifest = _read_manifest(manifest_path)
    if (
        manifest.get("schema_version") != SCHEMA_VERSION
        or manifest.get("experiment_id") != EXPERIMENT_ID
        or manifest.get("purpose") != "daily_development_smoke_only"
        or manifest.get("input_archive_count") != 2
        or manifest.get("reserved_data_member_count") != 0
        or not isinstance(manifest.get("member_sha256"), dict)
        or not isinstance(manifest.get("member_size"), dict)
    ):
        raise RuntimeError("bundle identity or reserved-data policy differs")

    expected_names = set(manifest["member_sha256"])
    if set(manifest["member_size"]) != expected_names:
        raise RuntimeError("bundle size and hash inventories differ")
    actual_names: set[str] = set()
    for path in root.rglob("*"):
        if path.is_symlink():
            raise RuntimeError(f"extracted bundle contains a symbolic link: {path}")
        if path.is_file():
            actual_names.add(path.relative_to(root).as_posix())
    if actual_names != expected_names | {"bundle_manifest.json"}:
        raise RuntimeError("extracted bundle file inventory differs")

    for name in sorted(expected_names):
        relative = _safe_member_name(name)
        path = root.joinpath(*relative.parts)
        resolved = path.resolve()
        if root not in resolved.parents or not path.is_file():
            raise RuntimeError(f"bundle member escapes or is absent: {name}")
        if path.stat().st_size != int(manifest["member_size"][name]):
            raise RuntimeError(f"bundle member size mismatch: {name}")
        if sha256_file(path) != str(manifest["member_sha256"][name]):
            raise RuntimeError(f"bundle member SHA-256 mismatch: {name}")

    input_hashes = manifest.get("frozen_input_sha256")
    source_hashes = manifest.get("pinned_source_sha256")
    if not isinstance(input_hashes, dict) or set(input_hashes) != EXPECTED_INPUT_NAMES:
        raise RuntimeError("frozen input archive inventory differs")
    if not isinstance(source_hashes, dict) or not source_hashes:
        raise RuntimeError("pinned source hash inventory is absent")
    for name, expected in {**input_hashes, **source_hashes}.items():
        if name not in expected_names or manifest["member_sha256"][name] != expected:
            raise RuntimeError(f"frozen evidence hash differs: {name}")

    package_initializers = manifest.get("package_initializers")
    if not isinstance(package_initializers, list) or not package_initializers:
        raise RuntimeError("isolated package initializer inventory is absent")
    for name in package_initializers:
        relative = _safe_member_name(str(name))
        if root.joinpath(*relative.parts).read_bytes() != b"":
            raise RuntimeError(f"package initializer is not empty: {name}")

    return {
        "status": "BUNDLE_VERIFIED",
        "experiment_id": EXPERIMENT_ID,
        "bundle_root": str(root),
        "member_count": len(expected_names),
        "input_archive_count": 2,
        "reserved_data_member_count": 0,
        "array_members_materialized": 0,
        "input_sha256": dict(sorted(input_hashes.items())),
        "source_sha256": dict(sorted(source_hashes.items())),
    }


def available_host_memory_bytes() -> int | None:
    meminfo = Path("/proc/meminfo")
    if meminfo.is_file():
        for line in meminfo.read_text(encoding="ascii").splitlines():
            if line.startswith("MemAvailable:"):
                return int(line.split()[1]) * 1024
    if sys.platform == "win32":
        class MemoryStatus(ctypes.Structure):
            _fields_ = [
                ("length", ctypes.c_ulong),
                ("memory_load", ctypes.c_ulong),
                ("total_physical", ctypes.c_ulonglong),
                ("available_physical", ctypes.c_ulonglong),
                ("total_page_file", ctypes.c_ulonglong),
                ("available_page_file", ctypes.c_ulonglong),
                ("total_virtual", ctypes.c_ulonglong),
                ("available_virtual", ctypes.c_ulonglong),
                ("available_extended_virtual", ctypes.c_ulonglong),
            ]

        status = MemoryStatus()
        status.length = ctypes.sizeof(MemoryStatus)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            return int(status.available_physical)
    return None


def probe_packages_and_cuda() -> dict[str, Any]:
    """Import scientific packages only during the scheduled online probe."""

    numpy = importlib.import_module("numpy")
    torch = importlib.import_module("torch")
    cuda_available = bool(torch.cuda.is_available())
    device_count = int(torch.cuda.device_count()) if cuda_available else 0
    report: dict[str, Any] = {
        "numpy_version": str(numpy.__version__),
        "torch_version": str(torch.__version__),
        "cuda_available": cuda_available,
        "cuda_device_count": device_count,
    }
    if cuda_available and device_count > 0:
        free_bytes, total_bytes = torch.cuda.mem_get_info(0)
        report.update(
            {
                "cuda_device_name": str(torch.cuda.get_device_name(0)),
                "cuda_free_bytes": int(free_bytes),
                "cuda_total_bytes": int(total_bytes),
            }
        )
    return report


def probe_experiment_imports(bundle_root: Path) -> dict[str, Any]:
    """Import every daily runtime module and validate the frozen configuration."""

    root = Path(bundle_root).resolve()
    for path in (root, root / "src"):
        value = str(path)
        if value not in sys.path:
            sys.path.insert(0, value)
    module_names = (
        "global_hydrology.experiments.daily_camels_masked_nse_loss_contract",
        "global_hydrology.experiments.daily_camels_masked_nse_loss_torch",
        "global_hydrology.experiments.daily_camels_native_knet_masked_nse_contract",
        "global_hydrology.experiments.daily_camels_native_knet_masked_nse_data",
        "global_hydrology.experiments.daily_camels_native_knet_io",
        "global_hydrology.experiments.daily_camels_native_knet_masked_nse_training",
        "scripts.run_daily_camels_native_kalmannet_masked_nse",
    )
    modules = {name: importlib.import_module(name) for name in module_names}
    entry = modules["scripts.run_daily_camels_native_kalmannet_masked_nse"]
    configuration_path = root / "configs/daily_camels_native_kalmannet_masked_nse_smoke_v3.json"
    configuration = _read_manifest(configuration_path)
    entry.validate_exact_config(configuration)
    gaps = entry.runtime_interface_gaps(
        (root / "src/global_hydrology/experiments/daily_camels_native_knet_masked_nse_data.py")
        .read_text(encoding="utf-8"),
        (root / "src/global_hydrology/experiments/daily_camels_native_knet_masked_nse_training.py")
        .read_text(encoding="utf-8"),
    )
    if gaps:
        raise RuntimeError("daily runtime interface mismatch: " + "; ".join(gaps))
    return {
        "experiment_modules_imported": list(module_names),
        "configuration_contract_validated": True,
        "runtime_interface_gap_count": 0,
        "array_members_materialized": 0,
    }


def run_online_preflight(
    bundle_root: Path,
    run_root: Path,
    *,
    environment: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    bundle = verify_bundle_root(bundle_root)
    env = dict(os.environ if environment is None else environment)
    slurm = {
        key: env.get(key)
        for key in (
            "SLURM_JOB_ID",
            "SLURM_JOB_NAME",
            "SLURM_JOB_PARTITION",
            "SLURM_JOB_NODELIST",
            "SLURM_CPUS_PER_TASK",
            "CUDA_VISIBLE_DEVICES",
        )
    }
    if not slurm["SLURM_JOB_ID"]:
        raise RuntimeError("online preflight requires a scheduled Slurm job")
    if sys.version_info[:2] != (3, 11):
        raise RuntimeError(f"Python 3.11 is required, got {sys.version}")
    target = Path(run_root)
    if target.exists():
        raise FileExistsError(f"unique run target already exists: {target}")

    runtime = probe_packages_and_cuda()
    if runtime.get("cuda_available") is not True:
        raise RuntimeError("CUDA is unavailable; CPU fallback is forbidden")
    if int(runtime.get("cuda_device_count", 0)) != 1:
        raise RuntimeError("exactly one visible CUDA device is required")
    experiment_runtime = probe_experiment_imports(bundle_root)

    report = {
        **bundle,
        "status": "PREFLIGHT_PASS",
        "python_version": sys.version,
        "hostname": socket.gethostname(),
        "slurm": slurm,
        "available_host_memory_bytes": available_host_memory_bytes(),
        "run_root": str(target),
        "run_root_absent": True,
        **runtime,
        **experiment_runtime,
    }
    return report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Verify one extracted daily CAMELS KalmanNet HPC bundle."
    )
    parser.add_argument(
        "--bundle-root",
        type=Path,
        default=Path(__file__).resolve().parents[2],
    )
    parser.add_argument("--run-root", type=Path, default=DEFAULT_RUN_ROOT)
    parser.add_argument("--offline-bundle-check", action="store_true")
    return parser


def main() -> int:
    arguments = build_parser().parse_args()
    try:
        if arguments.offline_bundle_check:
            report = verify_bundle_root(arguments.bundle_root)
        else:
            report = run_online_preflight(arguments.bundle_root, arguments.run_root)
    except Exception as error:
        print(
            json.dumps(
                {
                    "status": "PREFLIGHT_FAIL",
                    "error_type": type(error).__name__,
                    "error": str(error),
                },
                sort_keys=True,
            ),
            flush=True,
        )
        return 1
    print(json.dumps(report, indent=2, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
