# -*- coding: utf-8 -*-
"""TUKF27 dev-probe worker: isolate parameter learning from assimilation.

Reuses the TUKF26 machinery (same geometry, basins, recipe) and adds an
OPEN-LOOP hydrology-learning mode: identical 12 normalized coordinates,
identical optimizer, but the training rollout has NO daily state update -
gradient-descent calibration, plain and simple. Contract:
docs/plans/2026-09-01-tukf27-openloop-isolation-probe-contract.md

    anchor / anchor_gate            (delegated to the TUKF26 worker stages)
    train   --mode hydrology_only|openloop_hydrology --variant y2|y6
    readout --mode hydrology_only   (DA readout, TUKF26 code path)
    readout --mode openloop_hydrology  (DA readout + open-loop sim readout)
    prior_sim --basin B             (open-loop test baseline, prior params)
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import tukf26_trainlength_probe_worker as w26  # noqa: E402

c23 = w26.c23
c24 = w26.c24
t17 = w26.t17

torch.set_num_threads(1)

EXPERIMENT_ID = "TUKF27_OPENLOOP_ISOLATION_PROBE_DEV_V1"
LEADS = w26.LEADS
DEFAULT_CONFIG = c23.WORKTREE / "configs/tukf27_openloop_isolation_v1.json"


def load_all(config_path: Path | str) -> tuple[dict, dict]:
    config = json.loads(Path(config_path).read_text(encoding="utf-8"))
    if config["experiment_id"] != EXPERIMENT_ID:
        raise ValueError("wrong experiment id")
    for key, entry in config["frozen_input_sha256"].items():
        file_path = c23.ROOTS[entry["root"]] / entry["rel"]
        if c23.sha256_file(file_path) != entry["sha256"]:
            raise ValueError(f"frozen input drifted: {key}")
    contract23 = c23.load_contract(
        c23.WORKTREE / config["predecessor"]["tukf23_config"], verify_hashes=True)
    return config, contract23


def _as_w26_config(config: dict) -> dict:
    """The delegated TUKF26 stages check experiment_id when writing records;
    hand them a view stamped with this experiment's id and geometry."""
    return config


def sim_squared_errors(model, prep: dict, day_lo: int, day_hi: int) -> np.ndarray:
    """No-grad open-loop simulated discharge squared errors on days
    [day_lo, day_hi] inclusive (day d simulated by the state after day d)."""
    with torch.no_grad():
        states = t17.rollout_open_loop_states(
            model, prep["forcing"], prep["x0"], day_hi + 1)
        sim = model.h(states[1:])[:, 0].cpu().numpy()  # sim[d] = discharge day d+1?  no:
    # states[k] = state after processing day k-1; h(states[1:])[d] = discharge of day d
    err = (sim[day_lo:day_hi + 1] - prep["obs"][day_lo:day_hi + 1]) ** 2
    return err.astype(np.float64)


def stage_train_openloop(config: dict, contract23: dict, basin_id: str,
                         variant: str, out_root: Path,
                         updates_override: int | None = None) -> dict:
    t0 = time.perf_counter()
    cell = f"{basin_id}_openloop_hydrology_{variant}"
    out = out_root / "train" / f"{cell}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists() and updates_override is None:
        return json.loads(out.read_text(encoding="utf-8"))
    w26.require_anchor_gate(config, out_root, basin_id)

    prep = c23.prepare_basin(contract23, basin_id)
    model = c23.build_mode_model(contract23, prep)
    hyd, fil = c23.mode_groups(contract23, model, "hydrology_only")  # h free, noise frozen

    seg = config["segments_day_index"]
    train_origins = w26.train_origins_of(config, variant)
    target_lo = train_origins[0] + 1
    target_hi = max(train_origins) + max(LEADS)          # 2538
    if target_hi + 1 > int(seg["selection_origins"][0]):
        raise ValueError("open-loop train targets would cross into selection")
    sel_lo = int(seg["selection_origins"][0]) + 1
    sel_hi = int(seg["selection_origins"][1]) + max(LEADS)
    if sel_hi + 1 > int(seg["test_origins"][0]):
        raise ValueError("open-loop selection targets would cross into test")

    forcing_t = torch.as_tensor(prep["forcing"], dtype=model.dtype)
    obs_t = torch.as_tensor(prep["obs"], dtype=model.dtype)
    target_obs = obs_t[target_lo:target_hi + 1]
    spec = contract23["optimizer"]
    optimizer = torch.optim.Adam(
        [{"params": hyd, "lr": float(spec["hydrology_learning_rate"])}])
    clip = float(spec["group_gradient_norm"])
    step = int(spec["selection_interval"])
    total = int(spec["updates"]) if updates_override is None else updates_override
    queries = tuple(range(0, total + 1, step))
    query_trace: list[list[float]] = []
    train_trace: list[float] = []
    timing: dict = {}

    def sel_score() -> float:
        err = sim_squared_errors(model, prep, sel_lo, sel_hi)
        return float(err.mean())

    def open_loop_loss() -> torch.Tensor:
        state = torch.as_tensor(prep["x0"], dtype=model.dtype)
        if state.ndim == 1:
            state = state.unsqueeze(0)
        state = model.project_mean(state)
        losses = []
        for day in range(target_hi + 1):
            state = model.f(state, forcing_t[day:day + 1])
            state = model.project_mean(state)
            if day >= target_lo:
                sim = model.h(state)[0, 0]
                losses.append((sim - obs_t[day]) ** 2)
        return torch.stack(losses).mean()

    tq = time.perf_counter()
    score0 = sel_score()
    timing["selection_query_s"] = time.perf_counter() - tq
    query_trace.append([0, score0])
    best = {"score": score0, "update": 0, "snap": c23.snapshot(model)}

    for update in range(1, total + 1):
        tu = time.perf_counter()
        optimizer.zero_grad(set_to_none=True)
        loss = open_loop_loss()
        if not bool(torch.isfinite(loss)):
            raise FloatingPointError("open-loop loss is non-finite")
        loss.backward()
        torch.nn.utils.clip_grad_norm_(hyd, clip)
        optimizer.step()
        projector = getattr(model, "project_trainable_coordinates_", None)
        if callable(projector):
            projector()
        train_trace.append(float(loss))
        timing["update_s"] = time.perf_counter() - tu
        if update in queries:
            score = sel_score()
            query_trace.append([update, score])
            if score < best["score"]:
                best = {"score": score, "update": update, "snap": c23.snapshot(model)}

    c23.restore_(model, best["snap"])
    snap_lists = c23.snapshot_to_lists(best["snap"])
    tail = train_trace[-16:] if len(train_trace) >= 32 else []
    tail_drop = ((tail[0] - tail[-1]) / abs(tail[0])) if tail and tail[0] else None
    record = {
        "stage": "train", "experiment_id": config["experiment_id"],
        "grade": "development_probe", "basin_id": basin_id,
        "mode": "openloop_hydrology", "variant": variant,
        "assimilation_during_training": "none (pure open loop)",
        "objective": "daily open-loop simulation MSE on train-era target days "
                     f"[{target_lo},{target_hi}], full-rollout gradient from day 0",
        "train_origin_count": len(train_origins),
        "segments_day_index": seg, "dim_x": prep["dim_x"],
        "anchor_delta": prep["anchor_delta"],
        "selected_update": best["update"],
        "selection_score_at_checkpoint": best["score"],
        "selection_metric": f"open-loop sim MSE on days [{sel_lo},{sel_hi}]",
        "selection_query_trace": query_trace,
        "train_loss_trace": train_trace,
        "budget_tail16_relative_drop": tail_drop,
        "checkpoint_snapshot": snap_lists,
        "checkpoint_sha256": w26.canonical_snapshot_sha(snap_lists),
        "peak_rss_mb": w26.peak_rss_mb(),
        "timing_probe": timing, "updates_override": updates_override,
        "environment": c23.environment_stamp(),
        "seconds": time.perf_counter() - t0,
        "ran_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    if updates_override is None:
        w26.write_json(out, record)
    return record


def stage_sim_readout(config: dict, contract23: dict, basin_id: str,
                      variant: str, out_root: Path, train_root: Path) -> dict:
    """Open-loop simulation scoring on the test-era target days."""
    t0 = time.perf_counter()
    cell = f"{basin_id}_openloop_hydrology_{variant}"
    out_dir = out_root / "sim_readout"
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = out_dir / f"{cell}.json"
    npz_path = out_dir / f"{cell}.npz"
    if json_path.exists() and npz_path.exists():
        return json.loads(json_path.read_text(encoding="utf-8"))
    train_record = json.loads(
        (train_root / "train" / f"{cell}.json").read_text(encoding="utf-8"))
    snap = train_record["checkpoint_snapshot"]
    prep = c23.prepare_basin(contract23, basin_id)
    model = c23.build_mode_model(contract23, prep)
    c23.restore_(model, c23.snapshot_from_lists(model, snap))
    seg = config["segments_day_index"]
    lo = int(seg["test_origins"][0]) + 1
    hi = int(seg["last_test_target_index"])
    err = sim_squared_errors(model, prep, lo, hi)
    np.savez_compressed(npz_path, day_lo=lo, day_hi=hi, sq_err=err)
    record = {
        "stage": "sim_readout", "experiment_id": config["experiment_id"],
        "grade": "development_probe", "basin_id": basin_id,
        "mode": "openloop_hydrology", "variant": variant,
        "test_day_range": [lo, hi], "sim_test_mse": float(err.mean()),
        "in_sample_train_mse": None,
        "errors_npz": npz_path.name,
        "seconds": time.perf_counter() - t0,
        "ran_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    # in-sample check on the variant's train-era target days
    tro = w26.train_origins_of(config, variant)
    err_in = sim_squared_errors(model, prep, tro[0] + 1, max(tro) + max(LEADS))
    record["in_sample_train_mse"] = float(err_in.mean())
    w26.write_json(json_path, record)
    return record


def stage_prior_sim(config: dict, contract23: dict, basin_id: str,
                    out_root: Path) -> dict:
    """Open-loop test + train-era baselines with the UNLEARNED prior params."""
    t0 = time.perf_counter()
    out_dir = out_root / "prior_sim"
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = out_dir / f"{basin_id}.json"
    npz_path = out_dir / f"{basin_id}.npz"
    if json_path.exists() and npz_path.exists():
        return json.loads(json_path.read_text(encoding="utf-8"))
    prep = c23.prepare_basin(contract23, basin_id)
    model = c23.build_mode_model(contract23, prep)
    seg = config["segments_day_index"]
    lo = int(seg["test_origins"][0]) + 1
    hi = int(seg["last_test_target_index"])
    err = sim_squared_errors(model, prep, lo, hi)
    np.savez_compressed(npz_path, day_lo=lo, day_hi=hi, sq_err=err)
    record = {
        "stage": "prior_sim", "experiment_id": config["experiment_id"],
        "basin_id": basin_id, "test_day_range": [lo, hi],
        "sim_test_mse": float(err.mean()),
        "in_sample_train_mse_by_variant": {},
        "obs_test_var": float(np.var(prep["obs"][lo:hi + 1])),
        "seconds": time.perf_counter() - t0,
        "ran_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    for v in ("y2", "y6"):
        tro = w26.train_origins_of(config, v)
        err_in = sim_squared_errors(model, prep, tro[0] + 1, max(tro) + max(LEADS))
        record["in_sample_train_mse_by_variant"][v] = float(err_in.mean())
    w26.write_json(json_path, record)
    return record


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", required=True,
                    choices=["anchor", "anchor_gate", "train", "readout",
                             "sim_readout", "prior_sim"])
    ap.add_argument("--basin", default=None)
    ap.add_argument("--mode", default=None,
                    choices=["hydrology_only", "openloop_hydrology"])
    ap.add_argument("--variant", default=None, choices=["y2", "y6"])
    ap.add_argument("--config", default=str(DEFAULT_CONFIG))
    ap.add_argument("--out-root", required=True)
    ap.add_argument("--train-root", default=None)
    ap.add_argument("--updates-override", type=int, default=None)
    a = ap.parse_args()

    config, contract23 = load_all(a.config)
    out_root = Path(a.out_root)
    train_root = Path(a.train_root or a.out_root)

    if a.stage == "anchor":
        record = w26.stage_anchor(config, contract23, a.basin, out_root)
        print(json.dumps({k: record[k] for k in
                          ("basin_id", "anchor_delta", "passed", "seconds")}))
        return 0
    if a.stage == "anchor_gate":
        verdict = w26.stage_anchor_gate(config, contract23, out_root)
        print(json.dumps({k: verdict[k] for k in
                          ("passed_count", "required", "pass", "missing")}))
        return 0 if verdict["pass"] else 1
    if a.stage == "prior_sim":
        record = stage_prior_sim(config, contract23, a.basin, out_root)
        print(json.dumps({k: record[k] for k in
                          ("basin_id", "sim_test_mse", "seconds")}))
        return 0
    if not a.basin or not a.mode or not a.variant:
        raise SystemExit("--basin, --mode, --variant required")
    if a.stage == "train":
        if a.mode == "openloop_hydrology":
            record = stage_train_openloop(config, contract23, a.basin,
                                          a.variant, out_root, a.updates_override)
        else:
            record = w26.stage_train(config, contract23, a.basin, a.mode,
                                     a.variant, out_root, a.updates_override)
        print(json.dumps({k: record[k] for k in
                          ("basin_id", "mode", "variant", "selected_update",
                           "peak_rss_mb", "seconds")} |
                         ({"timing_probe": record["timing_probe"]}
                          if a.updates_override else {})))
        return 0
    if a.stage == "sim_readout":
        record = stage_sim_readout(config, contract23, a.basin, a.variant,
                                   out_root, train_root)
        print(json.dumps({k: record[k] for k in
                          ("basin_id", "variant", "sim_test_mse",
                           "in_sample_train_mse", "seconds")}))
        return 0
    # DA readout (works for both modes; cell naming matches the train record)
    record = w26.stage_readout(config, contract23, a.basin, a.mode,
                               a.variant, out_root, train_root)
    print(json.dumps({k: record[k] for k in
                      ("basin_id", "mode", "variant", "test_pooled_mse",
                       "seconds")}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
