# Normalization Identity Diagnostic Evidence

## Source

- High-performance-computing mailbox channel: `zhenjiang-d32-diff-ukf`
- Sequence: `27`
- Result commit: `d5459ca155`
- Result file: `outbox/zhenjiang-d32-diff-ukf/result_27.txt`
- Result byte count: `6280`
- Result SHA-256: `50c7907399a6f7addfb2a2df08a75a6f22ce432d0717ad3f9a8da74d04141d1c`
- Remote host: `login4`
- Started: `2026-08-31T14:45:52+08:00`
- Finished: `2026-08-31T14:46:23+08:00`
- Exit code: `0`

## Frozen training identities

All three training attempts, for seeds 17, 29, and 43, reported the same data-identity SHA-256:

```text
d8491b3e9a61a6c6102f14a15401e1e4d2e8078d3c553c46fb008c6f929eb74f
```

Each identity had exactly these top-level keys:

```text
astronomical_dependency_identities
input_content_identities
input_directory
last_loaded_target_time_beijing
schema_version
target_standard_deviation_m
test_target_counters
tide_model_path
training_base_sample_count
validation_base_sample_count
```

`target_mean_m` was absent for all three seeds. It was not present with a null value.

Each training run recorded Python `3.11.13` and NumPy `2.3.3`. The failed revision-two evaluation worker recorded the same versions.

## Same-code, same-input replay

The registered training-root loader replay reported:

```text
CURRENT_INPUT_IDENTITIES_EQUAL_TRAINING=True
CURRENT_ASTRONOMICAL_IDENTITIES_EQUAL_TRAINING=True
CURRENT_TARGET_SCALE_EQUALS_TRAINING=True
```

Target mean values after the loader's float32 conversion:

```text
[8.603047370910645, 5.2991557121276855, 4.558730125427246,
 3.29065203666687, 2.747354745864868, 2.236428737640381]
```

Unsigned float32 bit patterns for the target means:

```text
[1091151381, 1084854959, 1083302174, 1079155211, 1076876457, 1074733478]
```

Target standard deviations after float32 conversion:

```text
[2.8172526359558105, 1.5940370559692383, 1.2461224794387817,
 0.8721858859062195, 0.8888617753982544, 0.8898535370826721]
```

Unsigned float32 bit patterns for the target standard deviations:

```text
[1077169630, 1070336360, 1067417841, 1063208851, 1063488626, 1063505265]
```

## Evidence boundary

This evidence proves that the revision-two failure was caused by a producer-consumer schema mismatch: the training producer omitted `target_mean_m`, while the evaluation consumer treated absence as a changed value. It does not by itself establish forecast skill or authorize formal evaluation without a new three-seed smoke gate.
