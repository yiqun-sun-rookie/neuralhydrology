# 2023 Development Evaluation Technical Repair, Revision 3

## Status and scope

- This is a technical compatibility repair for the frozen 2023 development evaluation only.
- It does not change training data, evaluation data, model parameters, learned noise values, station conditions, lead hours, block construction, bootstrap settings, or decision thresholds.
- It does not authorize training, access to 2024-or-later targets, held-out evaluation, additional baselines, or a scientific conclusion.
- Failed job `216818` and its partial output under the revision-two root remain immutable evidence. Revision three uses a new evaluation root and never overwrites revision one or revision two.

## Observed failure

Revision-two smoke job `216818` ran on `ngu001` for 55 seconds and passed the registered common-runtime, bundle/training identity, astronomical-tide, and graphics-processor gates. It then stopped before batch evaluation with:

```text
RuntimeError: target normalization mean changed
```

The revision-two registry SHA-256 is `446db662812f1b7bf83c095dc5f279566a7b4ddfd3e7549acdabd76ceb9cbed3`.

## Root-cause evidence

Mailbox diagnostic sequence 27 completed successfully in commit `d5459ca155`; the result file has 6,280 bytes and SHA-256 `50c7907399a6f7addfb2a2df08a75a6f22ce432d0717ad3f9a8da74d04141d1c`.

The diagnostic established all of the following:

1. All three frozen training attempts have the same `data_identity.json` SHA-256, `d8491b3e9a61a6c6102f14a15401e1e4d2e8078d3c553c46fb008c6f929eb74f`.
2. That registered schema is version `1.0` and contains `target_standard_deviation_m`, but it does not contain a `target_mean_m` key.
3. The evaluator used `source_data_identity.get("target_mean_m")`; therefore it compared a six-value current vector with `None` and failed unconditionally. The failure was not evidence of numeric drift.
4. Current input-content identities and astronomical-dependency identities equal the frozen training identities exactly.
5. Current Python `3.11.13` and NumPy `2.3.3` equal the frozen training runtime versions exactly.
6. Current target standard deviations equal the frozen training values exactly after conversion to the float32 values actually used by the training dataset.

The replayed target means are:

```text
[8.603047370910645, 5.2991557121276855, 4.558730125427246,
 3.29065203666687, 2.747354745864868, 2.236428737640381]
```

Their unsigned float32 bit patterns are:

```text
[1091151381, 1084854959, 1083302174, 1079155211, 1076876457, 1074733478]
```

The target-standard-deviation unsigned float32 bit patterns are:

```text
[1077169630, 1070336360, 1067417841, 1063208851, 1063488626, 1063505265]
```

## Narrow compatibility rule

The repair must fail closed:

1. The training attempt and its complete artifact set must first pass the existing registered byte-count and SHA-256 checks.
2. Input-content and astronomical-dependency identities must remain exact.
3. The target standard deviations must match the registered source by exact float32 bit pattern.
4. Python and NumPy versions must match the frozen training runtime exactly.
5. If a source identity contains `target_mean_m`, the means must match by exact float32 bit pattern.
6. If and only if `target_mean_m` is absent, compatibility is allowed only for schema `1.0` with the registered legacy data-identity SHA-256 above, and the replayed means must match the diagnostic float32 bit patterns exactly.
7. A present null mean, an unknown schema or identity hash, a one-bit mean or standard-deviation change, or a Python/NumPy version change must be rejected.
8. Each completed worker must record the replay method, source identity hash, runtime match, and both float32 bit-pattern vectors. The independent audit must verify them without importing the evaluator.

## Revision-three isolation

- Evaluation root: `/data1/home/sunyiq/zhenjiang_d32_differentiable_ukf_dev_eval_20260831_r3`
- Training root remains: `/data1/home/sunyiq/zhenjiang_d32_differentiable_ukf_20260828_r2`
- Maximum job concurrency remains one.
- Node `ngu002` remains excluded.
- A new three-seed, two-batch smoke run is required before any formal array submission.
