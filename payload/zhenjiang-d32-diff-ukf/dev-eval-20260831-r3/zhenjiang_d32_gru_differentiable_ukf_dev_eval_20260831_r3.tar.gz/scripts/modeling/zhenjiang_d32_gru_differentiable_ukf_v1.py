#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Differentiable unscented filtering for the frozen D32 six-station model.

This module contains only filter mathematics and a registry-bound model
adapter.  It does not load water-level data, train parameters, score a year,
or import code from a sibling repository.
"""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, Mapping, Optional, Tuple

import torch
from torch import nn
from torch.nn import functional as F

from zhenjiang_d32_gru_kalmannet_online_v1 import (
    FrozenD32BackboneBundle,
    load_registered_d32_backbone,
)


STATE_DIMENSION = 32
OBSERVATION_DIMENSION = 6
SIGMA_POINT_COUNT = 65
MERWE_ALPHA = 1.0
MERWE_BETA = 2.0
MERWE_KAPPA = 0.0
MERWE_LAMBDA = 0.0
MERWE_SCALING = 32.0
INITIAL_STATE_VARIANCE = 0.001
PROCESS_INITIAL_VARIANCE = 0.001
OBSERVATION_INITIAL_VARIANCE = 0.01
MINIMUM_NOISE_STANDARD_DEVIATION = 0.0001
RELATIVE_SPECTRAL_FLOOR = 1e-12
MAXIMUM_INPUT_ASYMMETRY = 1e-10
MINIMUM_ALLOWED_INPUT_EIGENVALUE_RELATIVE = -1e-10
MAXIMUM_OUTPUT_ASYMMETRY = 1e-12
MINIMUM_OUTPUT_EIGENVALUE_FRACTION = 0.99


@dataclass(frozen=True)
class GaussianState:
    """One batch of Gaussian state means and covariance matrices."""

    mean: torch.Tensor
    covariance: torch.Tensor


class PositiveDiagonalCovariance(nn.Module):
    """Train positive diagonal variances through softplus standard deviations."""

    def __init__(self, dimension: int, initial_variance: float) -> None:
        super().__init__()
        if type(dimension) is not int or dimension < 1:
            raise ValueError("dimension must be a positive integer")
        if (
            not isinstance(initial_variance, (int, float))
            or not math.isfinite(float(initial_variance))
            or float(initial_variance) <= MINIMUM_NOISE_STANDARD_DEVIATION ** 2
        ):
            raise ValueError(
                "initial_variance must be finite and exceed the variance floor"
            )
        initial_standard_deviation = math.sqrt(float(initial_variance))
        shifted = initial_standard_deviation - MINIMUM_NOISE_STANDARD_DEVIATION
        raw = math.log(math.expm1(shifted))
        self.raw_standard_deviation = nn.Parameter(
            torch.full((dimension,), raw, dtype=torch.float64)
        )

    def standard_deviation(self) -> torch.Tensor:
        """Return the positive standard deviations."""

        return MINIMUM_NOISE_STANDARD_DEVIATION + torch.nn.functional.softplus(
            self.raw_standard_deviation
        )

    def variance(self) -> torch.Tensor:
        """Return the positive diagonal variances."""

        return self.standard_deviation().square()

    def forward(self) -> torch.Tensor:
        """Return one diagonal covariance matrix."""

        return torch.diag(self.variance())


def _require_float64_square_covariance(covariance: torch.Tensor) -> None:
    if not isinstance(covariance, torch.Tensor):
        raise ValueError("covariance must be a torch tensor")
    if covariance.ndim < 2 or covariance.shape[-2:] != (
        STATE_DIMENSION,
        STATE_DIMENSION,
    ):
        raise ValueError("covariance must end with shape [32, 32]")
    if covariance.dtype != torch.float64:
        raise ValueError("covariance must use torch.float64")


def stabilize_covariance(
    covariance: torch.Tensor,
) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
    """Apply the frozen spectral covariance checks and floor without jitter."""

    _require_float64_square_covariance(covariance)
    if not bool(torch.isfinite(covariance).all()):
        raise ValueError("covariance contains a nonfinite element")
    transpose = covariance.transpose(-1, -2)
    symmetric = (covariance + transpose) * 0.5
    diagonal_scale = torch.diagonal(symmetric, dim1=-2, dim2=-1).abs().amax(
        dim=-1
    )
    scale = torch.maximum(diagonal_scale, torch.ones_like(diagonal_scale))
    input_asymmetry = (covariance - transpose).abs().amax(dim=(-2, -1))
    if bool((input_asymmetry > MAXIMUM_INPUT_ASYMMETRY * scale).any()):
        raise ValueError("covariance input asymmetry exceeds the frozen limit")

    eigenvalues, eigenvectors = torch.linalg.eigh(symmetric)
    pre_floor_minimum = eigenvalues[..., 0]
    if bool(
        (
            pre_floor_minimum
            < MINIMUM_ALLOWED_INPUT_EIGENVALUE_RELATIVE * scale
        ).any()
    ):
        raise ValueError("covariance has a clearly negative eigenvalue")
    floor = RELATIVE_SPECTRAL_FLOOR * scale
    clipped_eigenvalues = torch.maximum(eigenvalues, floor.unsqueeze(-1))
    clipped_matrix = (eigenvalues < floor.unsqueeze(-1)).any(dim=-1)
    if bool(clipped_matrix.any()):
        stabilized = (
            eigenvectors
            @ torch.diag_embed(clipped_eigenvalues)
            @ eigenvectors.transpose(-1, -2)
        )
        stabilized = (stabilized + stabilized.transpose(-1, -2)) * 0.5
    else:
        # This is mathematically identical to an eigendecomposition
        # reconstruction, but avoids undefined eigenvector derivatives at a
        # repeated positive spectrum such as the fixed initial covariance.
        stabilized = symmetric
    output_asymmetry = (
        stabilized - stabilized.transpose(-1, -2)
    ).abs().amax(dim=(-2, -1))
    if bool((output_asymmetry > MAXIMUM_OUTPUT_ASYMMETRY * scale).any()):
        raise RuntimeError("stabilized covariance remains too asymmetric")
    post_floor_minimum = torch.linalg.eigvalsh(stabilized)[..., 0]
    if bool(
        (
            post_floor_minimum
            < MINIMUM_OUTPUT_EIGENVALUE_FRACTION * floor
        ).any()
    ):
        raise RuntimeError("stabilized covariance misses the spectral floor")
    diagnostics = {
        "scale": scale,
        "spectral_floor": floor,
        "input_asymmetry": input_asymmetry,
        "output_asymmetry": output_asymmetry,
        "pre_floor_minimum_eigenvalue": pre_floor_minimum,
        "post_floor_minimum_eigenvalue": post_floor_minimum,
        "clipped_matrix": clipped_matrix,
    }
    return stabilized, diagnostics


class DifferentiableMerweUnscentedTransform(nn.Module):
    """The fixed 65-point Merwe transform for a 32-dimensional state."""

    def __init__(self) -> None:
        super().__init__()
        mean_weights = torch.full(
            (SIGMA_POINT_COUNT,), 1.0 / (2.0 * MERWE_SCALING), dtype=torch.float64
        )
        covariance_weights = mean_weights.clone()
        mean_weights[0] = MERWE_LAMBDA / MERWE_SCALING
        covariance_weights[0] = (
            mean_weights[0] + (1.0 - MERWE_ALPHA ** 2 + MERWE_BETA)
        )
        self.register_buffer("mean_weights", mean_weights)
        self.register_buffer("covariance_weights", covariance_weights)
        self.scaling = MERWE_SCALING

    def sigma_points(self, state: GaussianState) -> torch.Tensor:
        """Return center, positive-column, and negative-column sigma points."""

        if not isinstance(state, GaussianState):
            raise ValueError("state must be a GaussianState")
        if state.mean.ndim != 2 or state.mean.shape[1] != STATE_DIMENSION:
            raise ValueError("state mean must have shape [batch, 32]")
        if state.mean.dtype != torch.float64:
            raise ValueError("state mean must use torch.float64")
        if state.covariance.shape != (
            state.mean.shape[0],
            STATE_DIMENSION,
            STATE_DIMENSION,
        ):
            raise ValueError("state covariance must have shape [batch, 32, 32]")
        covariance, _ = stabilize_covariance(state.covariance)
        factor, information = torch.linalg.cholesky_ex(
            covariance * self.scaling,
            check_errors=False,
        )
        if bool((information != 0).any()):
            raise RuntimeError("covariance Cholesky decomposition failed")
        columns = factor.transpose(-1, -2)
        center = state.mean.unsqueeze(1)
        return torch.cat(
            (center, center + columns, center - columns),
            dim=1,
        )

    def predict(
        self,
        state: GaussianState,
        tide: torch.Tensor,
        transition: Callable[[torch.Tensor, torch.Tensor], torch.Tensor],
        process_covariance: torch.Tensor,
        *,
        transition_dtype: torch.dtype = torch.float32,
    ) -> Tuple[GaussianState, Dict[str, torch.Tensor]]:
        """Propagate all sigma points and add process covariance exactly once."""

        points = self.sigma_points(state)
        batch_size = int(points.shape[0])
        if not isinstance(tide, torch.Tensor) or tide.shape != (batch_size,):
            raise ValueError("tide must have shape [batch]")
        if not tide.dtype.is_floating_point or not bool(torch.isfinite(tide).all()):
            raise ValueError("tide must be finite and floating point")
        if tide.device != state.mean.device:
            raise ValueError("tide device differs from the state")
        if not callable(transition):
            raise ValueError("transition must be callable")
        if not isinstance(process_covariance, torch.Tensor):
            raise ValueError("process_covariance must be a torch tensor")
        if process_covariance.dtype != torch.float64:
            raise ValueError("process_covariance must use torch.float64")
        if process_covariance.device != state.mean.device:
            raise ValueError("process_covariance device differs from the state")
        if process_covariance.shape == (STATE_DIMENSION, STATE_DIMENSION):
            expanded_process = process_covariance.unsqueeze(0)
        elif process_covariance.shape == (
            batch_size,
            STATE_DIMENSION,
            STATE_DIMENSION,
        ):
            expanded_process = process_covariance
        else:
            raise ValueError("process_covariance has an invalid shape")

        flat_points = points.reshape(-1, STATE_DIMENSION).to(transition_dtype)
        repeated_tide = (
            tide[:, None]
            .expand(batch_size, SIGMA_POINT_COUNT)
            .reshape(-1)
            .to(dtype=transition_dtype)
        )
        propagated = transition(flat_points, repeated_tide)
        if not isinstance(propagated, torch.Tensor) or propagated.shape != (
            batch_size * SIGMA_POINT_COUNT,
            STATE_DIMENSION,
        ):
            raise ValueError("transition output must have shape [batch*65, 32]")
        if not bool(torch.isfinite(propagated).all()):
            raise ValueError("transition output contains a nonfinite value")
        propagated = propagated.reshape(
            batch_size, SIGMA_POINT_COUNT, STATE_DIMENSION
        ).to(torch.float64)
        mean_weights = self.mean_weights.to(device=propagated.device)
        covariance_weights = self.covariance_weights.to(device=propagated.device)
        predicted_mean = torch.einsum("s,bsi->bi", mean_weights, propagated)
        deviations = propagated - predicted_mean.unsqueeze(1)
        predicted_covariance = torch.einsum(
            "s,bsi,bsj->bij", covariance_weights, deviations, deviations
        )
        predicted_covariance = predicted_covariance + expanded_process
        predicted_covariance, diagnostics = stabilize_covariance(
            predicted_covariance
        )
        if not bool(torch.isfinite(predicted_mean).all()):
            raise ValueError("predicted mean contains a nonfinite value")
        return GaussianState(predicted_mean, predicted_covariance), diagnostics


class D32GRUDifferentiableUnscentedKalmanFilter(nn.Module):
    """Pair an unscented open loop with one analysis-time station update."""

    def __init__(self, bundle: FrozenD32BackboneBundle) -> None:
        super().__init__()
        if not isinstance(bundle, FrozenD32BackboneBundle):
            raise ValueError("bundle must be a FrozenD32BackboneBundle")
        if getattr(bundle.model, "state_size", None) != STATE_DIMENSION:
            raise ValueError("backbone must use a 32-dimensional state")
        decoder = getattr(bundle.model, "observation_decoder", None)
        if not isinstance(decoder, nn.Linear) or decoder.weight.shape != (
            OBSERVATION_DIMENSION,
            STATE_DIMENSION,
        ):
            raise ValueError("backbone decoder must map 32 states to six stations")
        self.backbone = bundle.model
        self.backbone_experiment_id = bundle.experiment_id
        self.backbone_seed = bundle.seed
        self.backbone_checkpoint_sha256 = bundle.checkpoint_sha256
        self.backbone.requires_grad_(False)
        self.backbone.eval()
        self.unscented_transform = DifferentiableMerweUnscentedTransform()
        self.process_noise = PositiveDiagonalCovariance(
            STATE_DIMENSION, PROCESS_INITIAL_VARIANCE
        )
        self.observation_noise = PositiveDiagonalCovariance(
            OBSERVATION_DIMENSION, OBSERVATION_INITIAL_VARIANCE
        )
        self.register_buffer(
            "initial_covariance",
            torch.eye(STATE_DIMENSION, dtype=torch.float64)
            * INITIAL_STATE_VARIANCE,
        )

    def train(self, mode: bool = True):
        """Change adapter mode while keeping the frozen backbone in evaluation."""

        super().train(mode)
        self.backbone.eval()
        return self

    def _reference(self) -> torch.Tensor:
        return self.backbone.observation_decoder.weight

    def _validate_forward_inputs(
        self,
        history: torch.Tensor,
        future_tide: torch.Tensor,
        analysis_observation: torch.Tensor,
        analysis_availability: torch.Tensor,
    ) -> int:
        reference = self._reference()
        if not isinstance(history, torch.Tensor) or history.ndim != 3:
            raise ValueError("history must have shape [batch, 24, 6]")
        batch_size = int(history.shape[0])
        if batch_size < 1 or history.shape != (
            batch_size,
            24,
            OBSERVATION_DIMENSION,
        ):
            raise ValueError("history must have shape [batch, 24, 6]")
        if (
            history.dtype != reference.dtype
            or history.device != reference.device
            or not bool(torch.isfinite(history).all())
        ):
            raise ValueError("history must be finite and match the backbone")
        if not isinstance(future_tide, torch.Tensor) or future_tide.shape != (
            batch_size,
            24,
        ):
            raise ValueError("future_tide must have shape [batch, 24]")
        if (
            future_tide.dtype != reference.dtype
            or future_tide.device != reference.device
            or not bool(torch.isfinite(future_tide).all())
        ):
            raise ValueError("future_tide must be finite and match the backbone")
        self._validate_update_inputs(
            batch_size, analysis_observation, analysis_availability, reference.device
        )
        return batch_size

    @staticmethod
    def _validate_update_inputs(
        batch_size: int,
        observation: torch.Tensor,
        availability: torch.Tensor,
        device: torch.device,
    ) -> None:
        if not isinstance(observation, torch.Tensor) or observation.shape != (
            batch_size,
            OBSERVATION_DIMENSION,
        ):
            raise ValueError("analysis_observation must have shape [batch, 6]")
        if not observation.dtype.is_floating_point or observation.device != device:
            raise ValueError("analysis_observation must be floating and colocated")
        if not isinstance(availability, torch.Tensor) or availability.shape != (
            batch_size,
            OBSERVATION_DIMENSION,
        ):
            raise ValueError("analysis_availability must have shape [batch, 6]")
        if availability.dtype != torch.bool or availability.device != device:
            raise ValueError("analysis_availability must be Boolean and colocated")
        counts = availability.sum(dim=1)
        if bool((counts > 1).any()):
            raise ValueError("each sample may make at most one station available")
        selected = observation.masked_select(availability)
        if selected.numel() and not bool(torch.isfinite(selected).all()):
            raise ValueError("available observation contains a nonfinite value")

    def predict_state(
        self, state: GaussianState, tide: torch.Tensor
    ) -> Tuple[GaussianState, Dict[str, torch.Tensor]]:
        """Advance one Gaussian state by one hour with the frozen transition."""

        return self.unscented_transform.predict(
            state,
            tide,
            self.backbone.transition_step,
            self.process_noise(),
            transition_dtype=self._reference().dtype,
        )

    def update_one_station(
        self,
        prior: GaussianState,
        analysis_observation: torch.Tensor,
        analysis_availability: torch.Tensor,
    ) -> Dict[str, object]:
        """Apply zero or one exact scalar linear observation update per sample."""

        if not isinstance(prior, GaussianState):
            raise ValueError("prior must be a GaussianState")
        if prior.mean.ndim != 2 or prior.mean.shape[1] != STATE_DIMENSION:
            raise ValueError("prior mean must have shape [batch, 32]")
        batch_size = int(prior.mean.shape[0])
        if prior.mean.dtype != torch.float64:
            raise ValueError("prior mean must use torch.float64")
        if prior.covariance.shape != (
            batch_size,
            STATE_DIMENSION,
            STATE_DIMENSION,
        ) or prior.covariance.dtype != torch.float64:
            raise ValueError("prior covariance must be float64 [batch, 32, 32]")
        if prior.mean.device != prior.covariance.device:
            raise ValueError("prior mean and covariance devices differ")
        if not bool(torch.isfinite(prior.mean).all()) or not bool(
            torch.isfinite(prior.covariance).all()
        ):
            raise ValueError("prior contains a nonfinite value")
        self._validate_update_inputs(
            batch_size,
            analysis_observation,
            analysis_availability,
            prior.mean.device,
        )
        innovation = torch.zeros(
            batch_size,
            OBSERVATION_DIMENSION,
            dtype=torch.float64,
            device=prior.mean.device,
        )
        gain = torch.zeros(
            batch_size,
            STATE_DIMENSION,
            OBSERVATION_DIMENSION,
            dtype=torch.float64,
            device=prior.mean.device,
        )
        innovation_variance = torch.zeros_like(innovation)
        predicted_observation = torch.zeros_like(innovation)
        update_performed = analysis_availability.any(dim=1)
        if not bool(update_performed.any()):
            return {
                "posterior_state": prior,
                "innovation": innovation,
                "kalman_gain": gain,
                "innovation_variance": innovation_variance,
                "predicted_observation": predicted_observation,
                "update_performed": update_performed,
                "clipped_matrix": torch.zeros_like(update_performed),
            }

        decoder_weight = self.backbone.observation_decoder.weight.to(torch.float64)
        decoder_bias = self.backbone.observation_decoder.bias.to(torch.float64)
        observation_variance = self.observation_noise.variance()
        identity = torch.eye(
            STATE_DIMENSION, dtype=torch.float64, device=prior.mean.device
        )
        posterior_means = []
        posterior_covariances = []
        clipped_rows = []
        for row_index in range(batch_size):
            if not bool(update_performed[row_index]):
                posterior_means.append(prior.mean[row_index])
                posterior_covariances.append(prior.covariance[row_index])
                clipped_rows.append(
                    torch.zeros((), dtype=torch.bool, device=prior.mean.device)
                )
                continue
            station_index = int(
                torch.nonzero(analysis_availability[row_index], as_tuple=False)[
                    0, 0
                ].item()
            )
            h = decoder_weight[station_index]
            bias = decoder_bias[station_index]
            covariance = prior.covariance[row_index]
            cross_covariance = covariance @ h
            scalar_variance = (
                h @ cross_covariance + observation_variance[station_index]
            )
            if not bool(torch.isfinite(scalar_variance)) or not bool(
                scalar_variance > 0
            ):
                raise ValueError("innovation variance must be finite and positive")
            row_gain = cross_covariance / scalar_variance
            row_prediction = h @ prior.mean[row_index] + bias
            row_innovation = (
                analysis_observation[row_index, station_index].to(torch.float64)
                - row_prediction
            )
            posterior_mean = prior.mean[row_index] + row_gain * row_innovation
            joseph_factor = identity - torch.outer(row_gain, h)
            posterior_covariance = (
                joseph_factor @ covariance @ joseph_factor.transpose(0, 1)
                + torch.outer(row_gain, row_gain)
                * observation_variance[station_index]
            )
            posterior_covariance, diagnostics = stabilize_covariance(
                posterior_covariance.unsqueeze(0)
            )
            posterior_means.append(posterior_mean)
            posterior_covariances.append(posterior_covariance[0])
            clipped_rows.append(diagnostics["clipped_matrix"][0])
            innovation[row_index, station_index] = row_innovation
            gain[row_index, :, station_index] = row_gain
            innovation_variance[row_index, station_index] = scalar_variance
            predicted_observation[row_index, station_index] = row_prediction

        posterior = GaussianState(
            torch.stack(posterior_means, dim=0),
            torch.stack(posterior_covariances, dim=0),
        )
        if not bool(torch.isfinite(posterior.mean).all()) or not bool(
            torch.isfinite(posterior.covariance).all()
        ):
            raise ValueError("posterior contains a nonfinite value")
        return {
            "posterior_state": posterior,
            "innovation": innovation,
            "kalman_gain": gain,
            "innovation_variance": innovation_variance,
            "predicted_observation": predicted_observation,
            "update_performed": update_performed,
            "clipped_matrix": torch.stack(clipped_rows),
        }

    def _decode_mean(self, mean: torch.Tensor) -> torch.Tensor:
        return F.linear(
            mean,
            self.backbone.observation_decoder.weight.to(torch.float64),
            self.backbone.observation_decoder.bias.to(torch.float64),
        )

    @staticmethod
    def _merge_missing_rows(
        open_state: GaussianState,
        assimilation_state: GaussianState,
        missing_rows: torch.Tensor,
    ) -> GaussianState:
        return GaussianState(
            torch.where(
                missing_rows[:, None], open_state.mean, assimilation_state.mean
            ),
            torch.where(
                missing_rows[:, None, None],
                open_state.covariance,
                assimilation_state.covariance,
            ),
        )

    def forward(
        self,
        history: torch.Tensor,
        future_tide: torch.Tensor,
        analysis_observation: torch.Tensor,
        analysis_availability: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        """Return paired forecasts for leads one through twenty-three."""

        batch_size = self._validate_forward_inputs(
            history,
            future_tide,
            analysis_observation,
            analysis_availability,
        )
        encoded = self.backbone.encode_history(history).to(torch.float64)
        encoded_state = GaussianState(
            encoded,
            self.initial_covariance.expand(batch_size, -1, -1),
        )
        analysis_prior, _ = self.predict_state(encoded_state, future_tide[:, 0])
        analysis_update = self.update_one_station(
            analysis_prior,
            analysis_observation,
            analysis_availability,
        )
        analysis_posterior = analysis_update["posterior_state"]
        if not isinstance(analysis_posterior, GaussianState):
            raise RuntimeError("internal posterior state is invalid")
        open_state = analysis_prior
        assimilation_state = analysis_posterior
        missing_rows = ~analysis_availability.any(dim=1)
        all_missing = bool(missing_rows.all())
        open_states = []
        assimilation_states = []
        for hour_index in range(1, 24):
            open_state, _ = self.predict_state(
                open_state, future_tide[:, hour_index]
            )
            if all_missing:
                assimilation_state = open_state
            else:
                assimilation_state, _ = self.predict_state(
                    assimilation_state, future_tide[:, hour_index]
                )
                if bool(missing_rows.any()):
                    assimilation_state = self._merge_missing_rows(
                        open_state, assimilation_state, missing_rows
                    )
            open_states.append(open_state)
            assimilation_states.append(assimilation_state)

        open_mean = torch.stack([state.mean for state in open_states], dim=1)
        assimilation_mean = torch.stack(
            [state.mean for state in assimilation_states], dim=1
        )
        open_covariance = torch.stack(
            [state.covariance for state in open_states], dim=1
        )
        assimilation_covariance = torch.stack(
            [state.covariance for state in assimilation_states], dim=1
        )
        open_forecast = self._decode_mean(open_mean)
        assimilation_forecast = self._decode_mean(assimilation_mean)
        if not all(
            bool(torch.isfinite(value).all())
            for value in (
                open_mean,
                assimilation_mean,
                open_covariance,
                assimilation_covariance,
                open_forecast,
                assimilation_forecast,
            )
        ):
            raise ValueError("forward output contains a nonfinite value")
        return {
            "open_loop_forecast": open_forecast,
            "assimilation_forecast": assimilation_forecast,
            "open_loop_state_mean": open_mean,
            "assimilation_state_mean": assimilation_mean,
            "open_loop_state_covariance": open_covariance,
            "assimilation_state_covariance": assimilation_covariance,
            "analysis_prior_state_mean": analysis_prior.mean,
            "analysis_prior_state_covariance": analysis_prior.covariance,
            "analysis_posterior_state_mean": analysis_posterior.mean,
            "analysis_posterior_state_covariance": analysis_posterior.covariance,
            "analysis_prior_observation": self._decode_mean(analysis_prior.mean),
            "analysis_posterior_observation": self._decode_mean(
                analysis_posterior.mean
            ),
            "analysis_innovation": analysis_update["innovation"],
            "analysis_kalman_gain": analysis_update["kalman_gain"],
            "analysis_innovation_variance": analysis_update[
                "innovation_variance"
            ],
            "analysis_update_performed": analysis_update["update_performed"],
        }


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _resolve_project_file(project_root: Path, relative_path: str) -> Path:
    if not isinstance(relative_path, str) or not relative_path:
        raise ValueError("registered path must be a nonempty string")
    candidate = Path(relative_path)
    if candidate.is_absolute():
        raise ValueError("registered current-project path must be relative")
    root = project_root.resolve()
    resolved = (root / candidate).resolve()
    try:
        resolved.relative_to(root)
    except ValueError as error:
        raise ValueError("registered path escapes the project root") from error
    if not resolved.is_file():
        raise ValueError("registered project file does not exist")
    return resolved


def _expected_authorization() -> Dict[str, bool]:
    return {
        "technical_implementation_authorized": True,
        "synthetic_cpu_audit_authorized": True,
        "real_data_loading_authorized": False,
        "formal_training_authorized": False,
        "validation_2023_scoring_authorized": False,
        "held_out_target_access_authorized": False,
        "gpu_authorized": False,
        "paid_compute_authorized": False,
        "scientific_conclusion_authorized": False,
    }


def _expected_method_contract() -> Dict[str, object]:
    return {
        "state_dimension": STATE_DIMENSION,
        "observation_dimension": OBSERVATION_DIMENSION,
        "sigma_point_count": SIGMA_POINT_COUNT,
        "merwe": {
            "alpha": MERWE_ALPHA,
            "beta": MERWE_BETA,
            "kappa": MERWE_KAPPA,
            "lambda": MERWE_LAMBDA,
            "scaling": MERWE_SCALING,
            "center_mean_weight": 0.0,
            "center_covariance_weight": 2.0,
            "off_center_weight": 0.015625,
        },
        "initial_covariance": {
            "type": "fixed_diagonal",
            "variance": INITIAL_STATE_VARIANCE,
            "trainable": False,
        },
        "noise": {
            "process_dimension": STATE_DIMENSION,
            "observation_dimension": OBSERVATION_DIMENSION,
            "shared_across_observed_station_conditions": True,
            "trainable_scalar_count": 38,
            "minimum_standard_deviation": MINIMUM_NOISE_STANDARD_DEVIATION,
            "process_initial_variance": PROCESS_INITIAL_VARIANCE,
            "observation_initial_variance": OBSERVATION_INITIAL_VARIANCE,
        },
        "rolling_forecast": {
            "analysis_transition_index": 0,
            "forecast_transition_indices": list(range(1, 24)),
            "forecast_lead_hours": list(range(1, 24)),
            "forecast_lead_count": 23,
            "primary_lead_hours": list(range(1, 7)),
            "secondary_lead_hours": list(range(1, 13)),
            "full_persistence_lead_hours": list(range(1, 24)),
            "formal_branch_names": ["open_loop", "assimilation"],
            "later_observation_allowed": False,
        },
        "numerics": {
            "covariance_dtype": "torch.float64",
            "transition_dtype": "torch.float32",
            "relative_spectral_floor": RELATIVE_SPECTRAL_FLOOR,
            "maximum_input_asymmetry": MAXIMUM_INPUT_ASYMMETRY,
            "minimum_allowed_input_eigenvalue_relative": (
                MINIMUM_ALLOWED_INPUT_EIGENVALUE_RELATIVE
            ),
            "cholesky_jitter": 0.0,
            "cholesky_retry_count": 0,
            "update_covariance_form": "joseph",
        },
    }


def _validate_registry_document(
    document: Mapping[str, object], project_root: Path
) -> None:
    if document.get("registry_name") != (
        "zhenjiang_d32_gru_differentiable_ukf_v1"
    ):
        raise ValueError("differentiable UKF registry name is invalid")
    if document.get("registry_status") not in {
        "preregistered_technical_only",
        "completed_pass_technical_only",
    }:
        raise ValueError("differentiable UKF registry status is invalid")
    if document.get("authorization") != _expected_authorization():
        raise ValueError("differentiable UKF registry authorization drift")
    if document.get("experiments") != []:
        raise ValueError("differentiable UKF registry experiments must be empty")
    if document.get("method_contract") != _expected_method_contract():
        raise ValueError("differentiable UKF method contract drift")

    contract_path_value = document.get("method_contract_path")
    contract_path = _resolve_project_file(project_root, contract_path_value)
    registered_contract_hash = document.get("method_contract_sha256")
    if (
        not isinstance(registered_contract_hash, str)
        or _sha256(contract_path) != registered_contract_hash
    ):
        raise ValueError("method contract SHA-256 mismatch")

    expected_data_access = {
        "water_level_data_loader_allowed": False,
        "training_target_access_count": 0,
        "validation_2023_target_access_count": 0,
        "held_out_2024_and_later_target_access_count": 0,
    }
    if document.get("data_access_contract") != expected_data_access:
        raise ValueError("data-access contract drift")

    protected_sources = document.get("protected_sources")
    if not isinstance(protected_sources, list) or len(protected_sources) != 8:
        raise ValueError("protected source registry is incomplete")
    for row in protected_sources:
        if not isinstance(row, Mapping):
            raise ValueError("protected source row must be a mapping")
        scope = row.get("scope")
        if scope == "current_project_frozen_source":
            path = _resolve_project_file(project_root, row.get("path"))
            if row.get("sha256") != _sha256(path):
                raise ValueError("protected current-project source SHA-256 mismatch")
        elif scope == "read_only_reference_not_runtime_dependency":
            if not isinstance(row.get("path"), str) or not isinstance(
                row.get("sha256"), str
            ):
                raise ValueError("read-only reference identity is invalid")
        else:
            raise ValueError("protected source scope is invalid")

    backbone_contract = document.get("frozen_backbone_contract")
    if not isinstance(backbone_contract, Mapping):
        raise ValueError("frozen backbone contract is missing")
    expected_backbone_fields = {
        "state_dimension": STATE_DIMENSION,
        "station_weight_profile": "equal",
        "station_loss_weights": [1.0] * OBSERVATION_DIMENSION,
        "trainable_parameter_count": 19462,
        "parameters_frozen": True,
    }
    for key, value in expected_backbone_fields.items():
        if backbone_contract.get(key) != value:
            raise ValueError("frozen backbone contract drift")
    backbones = document.get("backbones")
    checkpoint_rows = document.get("backbone_checkpoints")
    if (
        not isinstance(backbones, list)
        or len(backbones) != 3
        or checkpoint_rows != backbones
    ):
        raise ValueError("backbone checkpoint registry drift")


def build_registered_d32_differentiable_unscented_kalman_filter(
    registry_path: Path,
    backbone_experiment_id: str,
    device: torch.device,
    *,
    project_root: Optional[Path] = None,
) -> D32GRUDifferentiableUnscentedKalmanFilter:
    """Validate the new route registry before opening one frozen checkpoint."""

    if not isinstance(backbone_experiment_id, str) or not backbone_experiment_id:
        raise ValueError("backbone experiment identifier must be nonempty")
    if not isinstance(device, torch.device):
        raise ValueError("device must be a torch.device")
    resolved_project_root = (
        Path(__file__).resolve().parents[2]
        if project_root is None
        else Path(project_root).resolve()
    )
    try:
        document = json.loads(Path(registry_path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise ValueError("differentiable UKF registry cannot be read") from error
    if not isinstance(document, Mapping):
        raise ValueError("differentiable UKF registry root must be a mapping")
    _validate_registry_document(document, resolved_project_root)
    bundle = load_registered_d32_backbone(
        Path(registry_path),
        backbone_experiment_id,
        device,
        project_root=resolved_project_root,
    )
    adapter = D32GRUDifferentiableUnscentedKalmanFilter(bundle)
    if (
        sum(
            parameter.numel()
            for parameter in adapter.parameters()
            if parameter.requires_grad
        )
        != 38
    ):
        raise RuntimeError("adapter trainable scalar count differs from 38")
    return adapter
