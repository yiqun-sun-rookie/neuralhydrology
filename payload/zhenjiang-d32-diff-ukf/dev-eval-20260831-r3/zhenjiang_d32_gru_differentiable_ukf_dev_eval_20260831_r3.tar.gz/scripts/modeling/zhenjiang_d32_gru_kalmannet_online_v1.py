#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Provenance-locked D32 backbone and one-time ``t+1`` online update.

Inputs:
    ``load_registered_d32_backbone`` accepts an experiment registry, one exact
    experiment identifier, and a target device.  ``D32GRUKalmanNetOnline``
    accepts standardized history ``[batch,24,6]``, known future astronomical
    tide ``[batch,24]``, one optional observation at ``t+1`` ``[batch,6]``, and
    its station availability mask ``[batch,6]``.

Outputs:
    The loader returns a frozen 32-dimensional backbone bundle.  The online
    wrapper returns the ``t+1`` prior, masked innovation and gain, ``t+1``
    posterior, and corrected forecasts for ``t+2`` through ``t+24``.

The wrapper cannot accept observations after ``t+1``.  It never forms an
issue-time innovation from ``decode_state(encode_history(history))``.  This
module trains no model, reads no water-level data, and imports no retired
sixteen-dimensional KalmanNet implementation.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from typing import Dict, Mapping, Optional, Protocol

import torch
from torch import nn

from zhenjiang_pure_gru_encoder_decoder_v1 import PureGRUEncoderDecoder


PROJECT_ROOT = Path(__file__).resolve().parents[2]
STATE_SIZE = 32
STATION_COUNT = 6
HISTORY_LENGTH_HOURS = 24
FORECAST_LENGTH_HOURS = 24


@dataclass(frozen=True)
class FrozenD32BackboneBundle:
    """One exact registered and frozen open-loop backbone."""

    model: PureGRUEncoderDecoder
    experiment_id: str
    seed: int
    checkpoint_sha256: str


class GainModuleProtocol(Protocol):
    """Minimal learned-gain interface consumed by the online wrapper."""

    state_dimension: int
    observation_dimension: int

    def reset(
        self,
        batch_size: int,
        *,
        device: torch.device,
        dtype: torch.dtype,
    ) -> None:
        ...

    def gain_step(
        self,
        observation_difference: torch.Tensor,
        observation_innovation: torch.Tensor,
        state_evolution: torch.Tensor,
        previous_state_update: torch.Tensor,
        availability: torch.Tensor,
    ) -> torch.Tensor:
        ...


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _required(mapping: Mapping, name: str, context: str):
    if name not in mapping:
        raise ValueError(f"{context} registry field is missing: {name}")
    return mapping[name]


def _require_mapping(value, context: str) -> Mapping:
    if not isinstance(value, Mapping):
        raise ValueError(f"{context} must be a mapping")
    return value


def _resolve_registered_file(
    project_root: Path,
    relative_path,
    *,
    context: str,
) -> Path:
    if not isinstance(relative_path, str) or not relative_path:
        raise ValueError(f"{context} registry path must be a nonempty string")
    candidate = Path(relative_path)
    if candidate.is_absolute():
        raise ValueError(f"{context} registry path must be project-relative")
    resolved_root = Path(project_root).resolve()
    resolved = (resolved_root / candidate).resolve()
    try:
        resolved.relative_to(resolved_root)
    except ValueError as error:
        raise ValueError(f"{context} registry path escapes project root") from error
    if not resolved.is_file():
        raise ValueError(f"{context} registered file does not exist")
    return resolved


def _is_six_unit_weights(value) -> bool:
    if not isinstance(value, (list, tuple)) or len(value) != STATION_COUNT:
        return False
    return all(
        not isinstance(weight, bool)
        and isinstance(weight, (int, float))
        and float(weight) == 1.0
        for weight in value
    )


def load_registered_d32_backbone(
    registry_path: Path,
    experiment_id: str,
    device: torch.device,
    *,
    project_root: Optional[Path] = None,
) -> FrozenD32BackboneBundle:
    """Verify provenance, strictly load one D32 checkpoint, and freeze it."""

    if not isinstance(experiment_id, str) or not experiment_id:
        raise ValueError("backbone experiment identifier must be nonempty")
    if not isinstance(device, torch.device):
        raise ValueError("device must be a torch.device")
    resolved_project_root = (
        PROJECT_ROOT if project_root is None else Path(project_root)
    ).resolve()
    try:
        registry_document = json.loads(
            Path(registry_path).read_text(encoding="utf-8")
        )
    except (OSError, json.JSONDecodeError) as error:
        raise ValueError("backbone registry cannot be read") from error
    registry = _require_mapping(registry_document, "backbone registry")
    contract = _require_mapping(
        _required(registry, "frozen_backbone_contract", "backbone"),
        "frozen backbone contract",
    )
    if _required(contract, "state_dimension", "backbone") != STATE_SIZE:
        raise ValueError("backbone registry requires a 32-dimensional state")
    if _required(contract, "station_weight_profile", "backbone") != "equal":
        raise ValueError("backbone registry station-weight profile must be equal")
    if not _is_six_unit_weights(
        _required(contract, "station_loss_weights", "backbone")
    ):
        raise ValueError("backbone registry must require six unit weights")

    model_source_path = _resolve_registered_file(
        resolved_project_root,
        _required(contract, "model_source_path", "backbone"),
        context="model source",
    )
    expected_model_source_sha256 = _required(
        contract, "model_source_sha256", "backbone"
    )
    if (
        not isinstance(expected_model_source_sha256, str)
        or _sha256(model_source_path) != expected_model_source_sha256
    ):
        raise ValueError("registered backbone model source SHA-256 mismatch")

    rows = _required(registry, "backbones", "backbone")
    if not isinstance(rows, list):
        raise ValueError("backbone registry backbones must be a list")
    matches = [
        row
        for row in rows
        if isinstance(row, Mapping) and row.get("experiment_id") == experiment_id
    ]
    if len(matches) != 1:
        raise ValueError(
            "backbone experiment identifier is not registered exactly once"
        )
    row = matches[0]
    registered_seed = _required(row, "seed", "backbone")
    if type(registered_seed) is not int:
        raise ValueError("backbone registry seed must be an integer")
    checkpoint_path = _resolve_registered_file(
        resolved_project_root,
        _required(row, "checkpoint_path", "backbone"),
        context="checkpoint",
    )
    expected_checkpoint_sha256 = _required(
        row, "checkpoint_sha256", "backbone"
    )
    if (
        not isinstance(expected_checkpoint_sha256, str)
        or _sha256(checkpoint_path) != expected_checkpoint_sha256
    ):
        raise ValueError("registered backbone checkpoint SHA-256 mismatch")

    try:
        checkpoint_document = torch.load(
            checkpoint_path,
            map_location="cpu",
            weights_only=False,
        )
    except Exception as error:
        raise ValueError("registered backbone checkpoint cannot be loaded") from error
    checkpoint = _require_mapping(checkpoint_document, "backbone checkpoint")
    checkpoint_experiment_id = _required(
        checkpoint, "experiment_id", "checkpoint"
    )
    if checkpoint_experiment_id != experiment_id:
        raise ValueError("checkpoint experiment identifier mismatch")
    configuration = _require_mapping(
        _required(checkpoint, "configuration", "checkpoint"),
        "checkpoint configuration",
    )
    if _required(configuration, "experiment_id", "checkpoint") != experiment_id:
        raise ValueError("checkpoint configuration experiment identifier mismatch")
    if _required(configuration, "state_size", "checkpoint") != STATE_SIZE:
        raise ValueError("only a 32-dimensional backbone is compatible")
    checkpoint_seed = _required(configuration, "seed", "checkpoint")
    if type(checkpoint_seed) is not int or checkpoint_seed != registered_seed:
        raise ValueError("checkpoint seed differs from the registry")
    if _required(configuration, "station_weight_profile", "checkpoint") != "equal":
        raise ValueError("backbone station-weight profile must be equal")
    if not _is_six_unit_weights(
        _required(configuration, "station_loss_weights", "checkpoint")
    ):
        raise ValueError("backbone station-loss weights must be six unit weights")

    model_state = _require_mapping(
        _required(checkpoint, "model_state", "checkpoint"),
        "checkpoint model state",
    )
    model = PureGRUEncoderDecoder(state_size=STATE_SIZE)
    try:
        model.load_state_dict(model_state, strict=True)
    except RuntimeError as error:
        raise ValueError("backbone strict state-dictionary loading failed") from error
    if not all(
        isinstance(value, torch.Tensor) and bool(torch.isfinite(value).all())
        for value in model.state_dict().values()
    ):
        raise ValueError("backbone checkpoint contains a nonfinite parameter")
    model.to(device=device)
    model.requires_grad_(False)
    model.eval()
    return FrozenD32BackboneBundle(
        model=model,
        experiment_id=experiment_id,
        seed=registered_seed,
        checkpoint_sha256=expected_checkpoint_sha256,
    )


def _validate_float_tensor(
    value: torch.Tensor,
    *,
    name: str,
    expected_shape: tuple,
    reference: torch.Tensor,
    require_finite: bool,
) -> None:
    if not isinstance(value, torch.Tensor):
        raise ValueError(f"{name} must be a torch tensor")
    if tuple(value.shape) != tuple(expected_shape):
        raise ValueError(
            f"{name} must have shape {expected_shape}, received {tuple(value.shape)}"
        )
    if not value.dtype.is_floating_point:
        raise ValueError(f"{name} must use a floating-point dtype")
    if value.dtype != reference.dtype:
        raise ValueError(f"{name} dtype differs from the backbone")
    if value.device != reference.device:
        raise ValueError(f"{name} device differs from the backbone")
    if require_finite and not bool(torch.isfinite(value).all()):
        raise ValueError(f"{name} contains a nonfinite value")


class D32GRUKalmanNetOnline(nn.Module):
    """Apply one masked learned-gain update at ``t+1`` and forecast onward."""

    def __init__(
        self,
        bundle: FrozenD32BackboneBundle,
        gain_module: nn.Module,
    ) -> None:
        super().__init__()
        if not isinstance(bundle, FrozenD32BackboneBundle):
            raise ValueError("bundle must be FrozenD32BackboneBundle")
        if (
            not isinstance(bundle.model, PureGRUEncoderDecoder)
            or bundle.model.state_size != STATE_SIZE
        ):
            raise ValueError(f"backbone state_size must be exactly {STATE_SIZE}")
        if (
            not isinstance(gain_module, nn.Module)
            or not callable(getattr(gain_module, "reset", None))
            or not callable(getattr(gain_module, "gain_step", None))
        ):
            raise ValueError("gain module must provide reset and gain_step")
        if (
            type(getattr(gain_module, "state_dimension", None)) is not int
            or gain_module.state_dimension != STATE_SIZE
        ):
            raise ValueError("gain module state_dimension must be exactly 32")
        if (
            type(getattr(gain_module, "observation_dimension", None)) is not int
            or gain_module.observation_dimension != STATION_COUNT
        ):
            raise ValueError(
                "gain module observation_dimension must be exactly 6"
            )
        bundle.model.requires_grad_(False)
        bundle.model.eval()
        self.bundle = bundle
        self.backbone = bundle.model
        self.gain_module = gain_module

    def train(self, mode: bool = True):
        """Change gain-module mode while keeping the frozen backbone in eval."""

        super().train(mode)
        self.backbone.eval()
        return self

    def _reference(self) -> torch.Tensor:
        return self.backbone.observation_decoder.weight

    def _validate_inputs(
        self,
        history: torch.Tensor,
        future_tide: torch.Tensor,
        observation_t_plus_1: torch.Tensor,
        availability: torch.Tensor,
    ) -> int:
        if not isinstance(history, torch.Tensor) or history.ndim != 3:
            raise ValueError("history must have shape [batch,24,6]")
        batch_size = int(history.shape[0])
        if batch_size < 1:
            raise ValueError("history must contain at least one sample")
        reference = self._reference()
        _validate_float_tensor(
            history,
            name="history",
            expected_shape=(batch_size, HISTORY_LENGTH_HOURS, STATION_COUNT),
            reference=reference,
            require_finite=True,
        )
        _validate_float_tensor(
            future_tide,
            name="future_tide",
            expected_shape=(batch_size, FORECAST_LENGTH_HOURS),
            reference=reference,
            require_finite=True,
        )
        _validate_float_tensor(
            observation_t_plus_1,
            name="observation_t_plus_1",
            expected_shape=(batch_size, STATION_COUNT),
            reference=reference,
            require_finite=False,
        )
        if not isinstance(availability, torch.Tensor):
            raise ValueError("availability must be a torch tensor")
        if tuple(availability.shape) != (batch_size, STATION_COUNT):
            raise ValueError(
                "availability must have shape (%d, %d), received %s"
                % (batch_size, STATION_COUNT, tuple(availability.shape))
            )
        if availability.dtype != torch.bool:
            raise ValueError("availability must use a boolean dtype")
        if availability.device != reference.device:
            raise ValueError("availability device differs from the backbone")
        if not bool(torch.isfinite(observation_t_plus_1[availability]).all()):
            raise ValueError("available observation contains a nonfinite value")
        return batch_size

    def _validate_gain(self, gain: torch.Tensor, *, batch_size: int) -> None:
        reference = self._reference()
        if not isinstance(gain, torch.Tensor) or tuple(gain.shape) != (
            batch_size,
            STATE_SIZE,
            STATION_COUNT,
        ):
            raise ValueError("gain module must return [batch,32,6]")
        if gain.dtype != reference.dtype:
            raise ValueError("gain dtype differs from the backbone")
        if gain.device != reference.device:
            raise ValueError("gain device differs from the backbone")
        if not bool(torch.isfinite(gain).all()):
            raise ValueError("gain contains a nonfinite value")

    def forward(
        self,
        history: torch.Tensor,
        future_tide: torch.Tensor,
        observation_t_plus_1: torch.Tensor,
        availability: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        """Update only at ``t+1``; later observations cannot enter the model."""

        batch_size = self._validate_inputs(
            history,
            future_tide,
            observation_t_plus_1,
            availability,
        )
        reference = self._reference()
        self.gain_module.reset(
            batch_size, device=reference.device, dtype=reference.dtype
        )
        state_t = self.backbone.encode_history(history)
        prior_state = self.backbone.transition_step(state_t, future_tide[:, 0])
        prior_observation = self.backbone.decode_state(prior_state)
        safe_observation = torch.where(
            availability,
            observation_t_plus_1,
            prior_observation,
        )
        innovation = torch.where(
            availability,
            safe_observation - prior_observation,
            torch.zeros_like(prior_observation),
        )

        if bool(availability.any()):
            raw_gain = self.gain_module.gain_step(
                torch.zeros_like(prior_observation),
                innovation,
                prior_state - state_t,
                torch.zeros_like(state_t),
                availability,
            )
            self._validate_gain(raw_gain, batch_size=batch_size)
            masked_gain = torch.where(
                availability[:, None, :],
                raw_gain,
                torch.zeros_like(raw_gain),
            )
            correction = torch.bmm(
                masked_gain, innovation.unsqueeze(-1)
            ).squeeze(-1)
            candidate = prior_state + correction
            posterior_state = torch.where(
                availability.any(dim=1, keepdim=True), candidate, prior_state
            )
        else:
            masked_gain = torch.zeros(
                batch_size,
                STATE_SIZE,
                STATION_COUNT,
                device=reference.device,
                dtype=reference.dtype,
            )
            posterior_state = prior_state

        posterior_observation = self.backbone.decode_state(posterior_state)
        forecasts = []
        current_state = posterior_state
        for horizon_index in range(1, FORECAST_LENGTH_HOURS):
            current_state = self.backbone.transition_step(
                current_state, future_tide[:, horizon_index]
            )
            forecasts.append(self.backbone.decode_state(current_state))
        return {
            "prior_state_t_plus_1": prior_state,
            "prior_observation_t_plus_1": prior_observation,
            "innovation_t_plus_1": innovation,
            "gain_t_plus_1": masked_gain,
            "posterior_state_t_plus_1": posterior_state,
            "posterior_observation_t_plus_1": posterior_observation,
            "forecasts_t_plus_2_to_t_plus_24": torch.stack(forecasts, dim=1),
        }
