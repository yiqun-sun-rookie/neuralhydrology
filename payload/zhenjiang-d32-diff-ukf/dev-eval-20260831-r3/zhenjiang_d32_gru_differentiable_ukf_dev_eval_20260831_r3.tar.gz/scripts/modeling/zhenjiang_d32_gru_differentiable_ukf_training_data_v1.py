"""Leakage-safe base-origin data for differentiable filter training.

The adapter consumes an already loaded six-station joint data object.  It
never opens a data file and has no held-out-record interface.  Each item keeps
one rolling origin intact so the training layer can share its history encoding
and unscented prior across all six single-station observation conditions.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Sequence, Tuple

import numpy as np
import torch
from torch.utils.data import Dataset

from water_level_joint_encoder_decoder_v2 import (
    FORECAST_LENGTH_HOURS,
    INPUT_LENGTH_HOURS,
    STATION_ORDER,
    TEST_START,
    JointWaterLevelData,
    SampleRecord,
)


STATION_COUNT = len(STATION_ORDER)
HISTORY_HOURS = INPUT_LENGTH_HOURS
FUTURE_TIDE_HOURS = FORECAST_LENGTH_HOURS
FUTURE_SUPERVISION_HOURS = FORECAST_LENGTH_HOURS - 1

_TEST_TARGET_COUNTER_NAMES = (
    "test_target_rows_read",
    "test_target_values_parsed",
    "test_target_values_loaded",
)


def _require_zero_test_target_counters(data: JointWaterLevelData) -> None:
    """Reject data objects that have read, parsed, or loaded test targets."""

    for name in _TEST_TARGET_COUNTER_NAMES:
        value = getattr(data, name, None)
        if (
            isinstance(value, (bool, np.bool_))
            or not isinstance(value, (int, np.integer))
            or int(value) != 0
        ):
            raise RuntimeError(
                "test-target counter must exist as integer zero: "
                f"{name}={value!r}"
            )


def _station_vector(value: Any, name: str) -> np.ndarray:
    """Return one validated six-station normalization vector."""

    try:
        array = np.asarray(value, dtype=np.float64)
    except (TypeError, ValueError) as error:
        raise ValueError(f"normalization {name} must be numeric") from error
    if array.shape != (STATION_COUNT,) or not np.isfinite(array).all():
        raise ValueError(
            f"normalization {name} must contain {STATION_COUNT} finite values"
        )
    return array.copy()


def _scalar(value: Any, name: str) -> float:
    """Return one validated scalar normalization statistic."""

    try:
        array = np.asarray(value, dtype=np.float64)
    except (TypeError, ValueError) as error:
        raise ValueError(f"normalization {name} must be numeric") from error
    if array.shape != () or not np.isfinite(array).all():
        raise ValueError(f"normalization {name} must be one finite scalar")
    return float(array)


def _float32_tensor(value: np.ndarray, name: str) -> torch.Tensor:
    """Copy one finite numeric window into an independent float32 tensor."""

    array = np.asarray(value).astype(np.float32, copy=True)
    if not np.isfinite(array).all():
        raise ValueError(f"normalized {name} is nonfinite")
    return torch.from_numpy(array)


class D32GRUDifferentiableUKFBaseDataset(Dataset):
    """Return one complete base origin without sixfold scenario duplication."""

    def __init__(
        self,
        data: JointWaterLevelData,
        base_records: Sequence[SampleRecord],
    ) -> None:
        _require_zero_test_target_counters(data)

        self.data = data
        self.base_records = tuple(base_records)
        if not self.base_records:
            raise ValueError("base records must not be empty")

        try:
            self._times = np.asarray(data.times_beijing, dtype=object)
            self._stages = np.asarray(data.stages_m)
            self._targets = np.asarray(data.targets_m)
            self._tide = np.asarray(data.astronomical_tide_m)
        except (AttributeError, TypeError, ValueError) as error:
            raise ValueError("data shape inputs must be numeric arrays") from error

        if self._times.ndim != 1 or self._times.shape[0] == 0:
            raise ValueError("data shape for times must be one nonempty axis")
        hour_count = self._times.shape[0]
        if (
            self._stages.shape != (hour_count, STATION_COUNT)
            or self._targets.shape != (hour_count, STATION_COUNT)
            or self._tide.shape != (hour_count,)
            or not np.issubdtype(self._stages.dtype, np.floating)
            or not np.issubdtype(self._targets.dtype, np.floating)
            or not np.issubdtype(self._tide.dtype, np.floating)
        ):
            raise ValueError(
                "data shape must align times, six-station stages and targets, "
                "and one-dimensional tide"
            )

        try:
            statistics = data.normalization
            self._input_mean = _station_vector(
                statistics.input_mean_m, "input_mean_m"
            )
            self._input_scale = _station_vector(
                statistics.input_standard_deviation_m,
                "input_standard_deviation_m",
            )
            self._target_mean = _station_vector(
                statistics.target_mean_m, "target_mean_m"
            )
            self._target_scale = _station_vector(
                statistics.target_standard_deviation_m,
                "target_standard_deviation_m",
            )
            self._tide_mean = _scalar(statistics.tide_mean_m, "tide_mean_m")
            self._tide_scale = _scalar(
                statistics.tide_standard_deviation_m,
                "tide_standard_deviation_m",
            )
        except AttributeError as error:
            raise ValueError("normalization attributes are incomplete") from error
        if (
            np.any(self._input_scale <= 0.0)
            or np.any(self._target_scale <= 0.0)
            or self._tide_scale <= 0.0
        ):
            raise ValueError("normalization standard deviations must be positive")

        try:
            registered_sequence = tuple(data.training_records) + tuple(
                data.validation_records
            )
        except (AttributeError, TypeError) as error:
            raise ValueError(
                "registered training or validation records are required"
            ) from error
        if any(
            not isinstance(record, SampleRecord)
            for record in registered_sequence
        ):
            raise ValueError(
                "registered training or validation records must be "
                "SampleRecord values"
            )
        registered_records = frozenset(registered_sequence)

        for record in self.base_records:
            if not isinstance(record, SampleRecord):
                raise ValueError("base record must be a SampleRecord")
            if record not in registered_records:
                raise ValueError(
                    "base record is not in registered training or validation "
                    "records"
                )
            position = record.issue_position
            if (
                isinstance(position, (bool, np.bool_))
                or not isinstance(position, (int, np.integer))
                or int(position) - HISTORY_HOURS + 1 < 0
                or int(position) + FUTURE_TIDE_HOURS >= hour_count
            ):
                raise ValueError("base record violates issue window bounds")
            position = int(position)
            if self._times[position] != record.issue_time_beijing:
                raise ValueError(
                    "base record issue time does not match its issue position"
                )
            if not isinstance(record.issue_time_beijing, datetime):
                raise ValueError("base record issue time must be a datetime")
            supervision_times = self._times[
                position + 2 : position + 1 + FUTURE_TIDE_HOURS
            ]
            try:
                reaches_test_period = (
                    record.issue_time_beijing >= TEST_START
                    or any(time_value >= TEST_START for time_value in supervision_times)
                )
            except TypeError as error:
                raise ValueError(
                    "base record issue time has an incompatible timezone"
                ) from error
            if reaches_test_period:
                raise ValueError(
                    "base record reaches the held-out test period"
                )

    def __len__(self) -> int:
        """Return the number of accepted base origins."""

        return len(self.base_records)

    def __getitem__(self, index: int) -> Dict[str, Any]:
        """Build one base-origin training item on demand."""

        if type(index) is not int or index < 0 or index >= len(self):
            raise IndexError("base-origin index must be an in-range integer")
        _require_zero_test_target_counters(self.data)

        record = self.base_records[index]
        position = int(record.issue_position)
        history = self._stages[position + 1 - HISTORY_HOURS : position + 1]
        future_tide = self._tide[
            position + 1 : position + 1 + FUTURE_TIDE_HOURS
        ]
        analysis_observations = self._stages[position + 1]
        future_supervision = self._targets[
            position + 2 : position + 1 + FUTURE_TIDE_HOURS
        ]

        if (
            history.shape != (HISTORY_HOURS, STATION_COUNT)
            or not np.isfinite(history).all()
        ):
            raise ValueError("history window is incomplete or nonfinite")
        if (
            future_tide.shape != (FUTURE_TIDE_HOURS,)
            or not np.isfinite(future_tide).all()
        ):
            raise ValueError("future tide window is incomplete or nonfinite")
        if (
            analysis_observations.shape != (STATION_COUNT,)
            or not np.isfinite(analysis_observations).all()
        ):
            raise ValueError(
                "analysis observation row is incomplete or nonfinite"
            )
        if (
            future_supervision.shape
            != (FUTURE_SUPERVISION_HOURS, STATION_COUNT)
            or not np.isfinite(future_supervision).all()
        ):
            raise ValueError(
                "future supervision window is incomplete or nonfinite"
            )

        normalized_history = (
            history - self._input_mean[None, :]
        ) / self._input_scale[None, :]
        normalized_tide = (
            future_tide - self._tide_mean
        ) / self._tide_scale
        normalized_analysis = (
            analysis_observations - self._target_mean
        ) / self._target_scale
        normalized_supervision = (
            future_supervision - self._target_mean[None, :]
        ) / self._target_scale[None, :]

        return {
            "history": _float32_tensor(normalized_history, "history"),
            "future_tide": _float32_tensor(normalized_tide, "future tide"),
            "analysis_observations": _float32_tensor(
                normalized_analysis, "analysis observations"
            ),
            "targets_t_plus_2_to_t_plus_24": _float32_tensor(
                normalized_supervision, "future supervision"
            ),
            "base_record_index": index,
            "issue_position": position,
            "issue_time_beijing": record.issue_time_beijing.isoformat(),
        }


def build_registered_training_base_datasets(
    data: JointWaterLevelData,
) -> Tuple[
    D32GRUDifferentiableUKFBaseDataset,
    D32GRUDifferentiableUKFBaseDataset,
]:
    """Build base-origin training and development-validation datasets."""

    training_dataset = D32GRUDifferentiableUKFBaseDataset(
        data, data.training_records
    )
    validation_dataset = D32GRUDifferentiableUKFBaseDataset(
        data, data.validation_records
    )
    return training_dataset, validation_dataset
