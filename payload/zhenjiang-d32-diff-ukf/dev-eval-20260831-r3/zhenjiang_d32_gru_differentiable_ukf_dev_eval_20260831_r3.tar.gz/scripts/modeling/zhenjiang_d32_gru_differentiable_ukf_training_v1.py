#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Vectorized training mathematics for the six-scenario differentiable UKF.

This module does not load data, optimize parameters, select a checkpoint, or
write results.  It leaves the stage-A implementation byte-for-byte unchanged
and supplies a training-only batch path with a repeated-eigenvalue-safe
spectral-floor backward.
"""

from __future__ import annotations

import math
from pathlib import Path
from typing import Dict, Optional, Tuple

import torch
from torch.nn import functional as F

from zhenjiang_d32_gru_differentiable_ukf_v1 import (
    MAXIMUM_INPUT_ASYMMETRY,
    MAXIMUM_OUTPUT_ASYMMETRY,
    MINIMUM_ALLOWED_INPUT_EIGENVALUE_RELATIVE,
    MINIMUM_OUTPUT_EIGENVALUE_FRACTION,
    RELATIVE_SPECTRAL_FLOOR,
    SIGMA_POINT_COUNT,
    STATE_DIMENSION,
    GaussianState,
    D32GRUDifferentiableUnscentedKalmanFilter,
    build_registered_d32_differentiable_unscented_kalman_filter,
)


STATION_COUNT = 6
FORECAST_LEAD_COUNT = 23


class _BatchedSymmetricEigenvalueFloor(torch.autograd.Function):
    """Exact batched spectral floor with a divided-difference backward.

    PyTorch's generic symmetric-eigendecomposition backward differentiates
    eigenvectors and is undefined for repeated eigenvalues.  A spectral matrix
    function has a well-defined divided-difference derivative, which is used
    here for both repeated and distinct eigenvalue blocks.
    """

    @staticmethod
    def forward(ctx, symmetric: torch.Tensor, threshold: torch.Tensor):
        if symmetric.ndim != 3 or symmetric.shape[-1] != symmetric.shape[-2]:
            raise ValueError("symmetric input must have shape [batch,n,n]")
        if threshold.shape != (symmetric.shape[0],):
            raise ValueError("threshold must have shape [batch]")
        eigenvalues, eigenvectors = torch.linalg.eigh(symmetric)
        floored = torch.maximum(eigenvalues, threshold[:, None])
        reconstructed = (
            eigenvectors * floored.unsqueeze(-2)
        ) @ eigenvectors.transpose(-1, -2)
        ctx.save_for_backward(eigenvalues, eigenvectors, threshold, floored)
        return 0.5 * (reconstructed + reconstructed.transpose(-1, -2))

    @staticmethod
    def backward(ctx, output_gradient: torch.Tensor):
        eigenvalues, eigenvectors, threshold, floored = ctx.saved_tensors
        symmetric_gradient = 0.5 * (
            output_gradient + output_gradient.transpose(-1, -2)
        )
        eigen_gradient = (
            eigenvectors.transpose(-1, -2)
            @ symmetric_gradient
            @ eigenvectors
        )
        denominator = eigenvalues[:, :, None] - eigenvalues[:, None, :]
        numerator = floored[:, :, None] - floored[:, None, :]
        comparison_scale = torch.maximum(
            eigenvalues.abs().amax(dim=1), threshold.abs()
        ).clamp(min=1.0)
        repeated = denominator.abs() <= (
            8.0
            * torch.finfo(eigenvalues.dtype).eps
            * comparison_scale[:, None, None]
        )
        active = eigenvalues > threshold[:, None]
        repeated_factor = (
            active[:, :, None] & active[:, None, :]
        ).to(eigenvalues.dtype)
        safe_denominator = torch.where(
            repeated, torch.ones_like(denominator), denominator
        )
        factor = torch.where(
            repeated,
            repeated_factor,
            numerator / safe_denominator,
        )
        input_gradient = (
            eigenvectors
            @ (factor * eigen_gradient)
            @ eigenvectors.transpose(-1, -2)
        )
        input_gradient = 0.5 * (
            input_gradient + input_gradient.transpose(-1, -2)
        )
        diagonal_gradient = torch.diagonal(
            eigen_gradient, dim1=-2, dim2=-1
        )
        threshold_gradient = (
            diagonal_gradient * (~active).to(diagonal_gradient.dtype)
        ).sum(dim=1)
        return input_gradient, threshold_gradient


def training_stabilize_covariance(
    covariance: torch.Tensor,
) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
    """Apply the frozen floor with a repeated-spectrum-safe training gradient."""

    if not isinstance(covariance, torch.Tensor):
        raise ValueError("covariance must be a torch tensor")
    if covariance.ndim < 2 or covariance.shape[-2:] != (
        STATE_DIMENSION,
        STATE_DIMENSION,
    ):
        raise ValueError("covariance must end with shape [32, 32]")
    if covariance.dtype != torch.float64:
        raise ValueError("covariance must use torch.float64")
    if not bool(torch.isfinite(covariance).all()):
        raise ValueError("covariance contains a nonfinite element")

    transpose = covariance.transpose(-1, -2)
    symmetric = 0.5 * (covariance + transpose)
    diagonal_scale = torch.diagonal(
        symmetric, dim1=-2, dim2=-1
    ).abs().amax(dim=-1)
    scale = torch.maximum(diagonal_scale, torch.ones_like(diagonal_scale))
    input_asymmetry = (covariance - transpose).abs().amax(dim=(-2, -1))
    if bool((input_asymmetry > MAXIMUM_INPUT_ASYMMETRY * scale).any()):
        raise ValueError("covariance input asymmetry exceeds the frozen limit")

    # Diagnostic eigenvalues never participate in the loss graph.  The custom
    # spectral function below supplies the only eigendecomposition backward.
    eigenvalues = torch.linalg.eigvalsh(symmetric.detach())
    pre_floor_minimum = eigenvalues[..., 0]
    if bool(
        (
            pre_floor_minimum
            < MINIMUM_ALLOWED_INPUT_EIGENVALUE_RELATIVE * scale.detach()
        ).any()
    ):
        raise ValueError("covariance has a clearly negative eigenvalue")
    floor = RELATIVE_SPECTRAL_FLOOR * scale
    clipped_matrix = (
        eigenvalues < floor.detach().unsqueeze(-1)
    ).any(dim=-1)

    if bool(clipped_matrix.any()):
        leading_shape = symmetric.shape[:-2]
        flat_symmetric = symmetric.reshape(-1, STATE_DIMENSION, STATE_DIMENSION)
        flat_floor = floor.reshape(-1)
        flat_clipped = clipped_matrix.reshape(-1)
        indices = torch.nonzero(flat_clipped, as_tuple=False).reshape(-1)
        selected = _BatchedSymmetricEigenvalueFloor.apply(
            flat_symmetric.index_select(0, indices),
            flat_floor.index_select(0, indices),
        )
        stabilized = flat_symmetric.index_copy(0, indices, selected).reshape(
            *leading_shape, STATE_DIMENSION, STATE_DIMENSION
        )
    else:
        stabilized = symmetric
    stabilized = 0.5 * (stabilized + stabilized.transpose(-1, -2))

    output_asymmetry = (
        stabilized.detach() - stabilized.detach().transpose(-1, -2)
    ).abs().amax(dim=(-2, -1))
    if bool((output_asymmetry > MAXIMUM_OUTPUT_ASYMMETRY * scale.detach()).any()):
        raise RuntimeError("stabilized covariance remains too asymmetric")
    post_floor_minimum = torch.linalg.eigvalsh(stabilized.detach())[..., 0]
    if bool(
        (
            post_floor_minimum
            < MINIMUM_OUTPUT_EIGENVALUE_FRACTION * floor.detach()
        ).any()
    ):
        raise RuntimeError("stabilized covariance misses the spectral floor")
    diagnostics = {
        "scale": scale.detach(),
        "spectral_floor": floor.detach(),
        "input_asymmetry": input_asymmetry.detach(),
        "output_asymmetry": output_asymmetry,
        "pre_floor_minimum_eigenvalue": pre_floor_minimum,
        "post_floor_minimum_eigenvalue": post_floor_minimum,
        "clipped_matrix": clipped_matrix,
    }
    return stabilized, diagnostics


def prepare_adapter_for_training(
    adapter: D32GRUDifferentiableUnscentedKalmanFilter,
    device: torch.device,
) -> D32GRUDifferentiableUnscentedKalmanFilter:
    """Move every adapter value to one device and reassert the frozen backbone."""

    if not isinstance(adapter, D32GRUDifferentiableUnscentedKalmanFilter):
        raise ValueError("adapter has the wrong type")
    if not isinstance(device, torch.device):
        raise ValueError("device must be a torch.device")
    adapter = adapter.to(device)
    adapter.backbone.requires_grad_(False)
    adapter.train(True)
    adapter.backbone.eval()
    trainable_count = sum(
        parameter.numel()
        for parameter in adapter.parameters()
        if parameter.requires_grad
    )
    frozen_count = sum(parameter.numel() for parameter in adapter.backbone.parameters())
    if trainable_count != 38:
        raise RuntimeError("adapter trainable scalar count differs from 38")
    if frozen_count != 19462:
        raise RuntimeError("backbone parameter count differs from 19462")
    if any(parameter.device != device for parameter in adapter.parameters()):
        raise RuntimeError("adapter parameter device mismatch")
    if any(buffer.device != device for buffer in adapter.buffers()):
        raise RuntimeError("adapter buffer device mismatch")
    if any(parameter.requires_grad for parameter in adapter.backbone.parameters()):
        raise RuntimeError("backbone parameter unexpectedly trainable")
    if adapter.backbone.training:
        raise RuntimeError("backbone must remain in evaluation mode")
    return adapter


def build_registered_training_adapter(
    technical_registry_path: Path,
    backbone_experiment_id: str,
    device: torch.device,
    *,
    project_root: Optional[Path] = None,
) -> D32GRUDifferentiableUnscentedKalmanFilter:
    """Build through the stage-A registry, then close its device-placement gap."""

    adapter = build_registered_d32_differentiable_unscented_kalman_filter(
        technical_registry_path,
        backbone_experiment_id,
        device,
        project_root=project_root,
    )
    return prepare_adapter_for_training(adapter, device)


def _sigma_points(state: GaussianState) -> torch.Tensor:
    if state.mean.ndim != 2 or state.mean.shape[1] != STATE_DIMENSION:
        raise ValueError("state mean must have shape [batch,32]")
    if state.mean.dtype != torch.float64:
        raise ValueError("state mean must use torch.float64")
    if state.covariance.shape != (
        state.mean.shape[0],
        STATE_DIMENSION,
        STATE_DIMENSION,
    ) or state.covariance.dtype != torch.float64:
        raise ValueError("state covariance must be float64 [batch,32,32]")
    if state.mean.device != state.covariance.device:
        raise ValueError("state mean and covariance devices differ")
    if not bool(torch.isfinite(state.mean).all()) or not bool(
        torch.isfinite(state.covariance).all()
    ):
        raise ValueError("state contains a nonfinite value")
    factor, information = torch.linalg.cholesky_ex(
        state.covariance * float(STATE_DIMENSION), check_errors=False
    )
    if bool((information != 0).any()):
        raise RuntimeError("covariance Cholesky decomposition failed")
    columns = factor.transpose(-1, -2)
    center = state.mean.unsqueeze(1)
    return torch.cat((center, center + columns, center - columns), dim=1)


def _predict_state(
    adapter: D32GRUDifferentiableUnscentedKalmanFilter,
    state: GaussianState,
    tide: torch.Tensor,
) -> Tuple[GaussianState, Dict[str, torch.Tensor]]:
    points = _sigma_points(state)
    batch_size = int(points.shape[0])
    reference = adapter.backbone.observation_decoder.weight
    if (
        not isinstance(tide, torch.Tensor)
        or tide.shape != (batch_size,)
        or tide.dtype != reference.dtype
        or tide.device != reference.device
        or not bool(torch.isfinite(tide).all())
    ):
        raise ValueError("tide must be finite [batch] and match the backbone")
    flat_points = points.reshape(-1, STATE_DIMENSION).to(reference.dtype)
    repeated_tide = (
        tide[:, None]
        .expand(batch_size, SIGMA_POINT_COUNT)
        .reshape(-1)
    )
    propagated = adapter.backbone.transition_step(flat_points, repeated_tide)
    if propagated.shape != (batch_size * SIGMA_POINT_COUNT, STATE_DIMENSION):
        raise RuntimeError("transition output shape changed")
    if not bool(torch.isfinite(propagated).all()):
        raise ValueError("transition output contains a nonfinite value")
    propagated = propagated.reshape(
        batch_size, SIGMA_POINT_COUNT, STATE_DIMENSION
    ).to(torch.float64)
    mean_weights = adapter.unscented_transform.mean_weights.to(
        device=propagated.device
    )
    covariance_weights = adapter.unscented_transform.covariance_weights.to(
        device=propagated.device
    )
    predicted_mean = torch.einsum("s,bsi->bi", mean_weights, propagated)
    deviations = propagated - predicted_mean.unsqueeze(1)
    predicted_covariance = torch.einsum(
        "s,bsi,bsj->bij", covariance_weights, deviations, deviations
    ) + adapter.process_noise().unsqueeze(0)
    predicted_covariance, diagnostics = training_stabilize_covariance(
        predicted_covariance
    )
    if not bool(torch.isfinite(predicted_mean).all()):
        raise ValueError("predicted mean contains a nonfinite value")
    return GaussianState(predicted_mean, predicted_covariance), diagnostics


def _update_all_stations(
    adapter: D32GRUDifferentiableUnscentedKalmanFilter,
    prior: GaussianState,
    observations: torch.Tensor,
) -> Tuple[GaussianState, Dict[str, torch.Tensor]]:
    batch_size = int(prior.mean.shape[0])
    reference = adapter.backbone.observation_decoder.weight
    if (
        not isinstance(observations, torch.Tensor)
        or observations.shape != (batch_size, STATION_COUNT)
        or observations.dtype != reference.dtype
        or observations.device != reference.device
        or not bool(torch.isfinite(observations).all())
    ):
        raise ValueError("analysis observations must be finite [batch,6]")
    decoder_weight = adapter.backbone.observation_decoder.weight.to(torch.float64)
    decoder_bias = adapter.backbone.observation_decoder.bias.to(torch.float64)
    observation_variance = adapter.observation_noise.variance()
    cross_covariance = torch.einsum(
        "bij,sj->bsi", prior.covariance, decoder_weight
    )
    innovation_variance = torch.einsum(
        "si,bsi->bs", decoder_weight, cross_covariance
    ) + observation_variance.unsqueeze(0)
    if not bool(torch.isfinite(innovation_variance).all()) or bool(
        (innovation_variance <= 0.0).any()
    ):
        raise ValueError("innovation variance must be finite and positive")
    gain = cross_covariance / innovation_variance.unsqueeze(-1)
    predicted_observation = torch.einsum(
        "bi,si->bs", prior.mean, decoder_weight
    ) + decoder_bias.unsqueeze(0)
    innovation = observations.to(torch.float64) - predicted_observation
    posterior_mean = prior.mean[:, None, :] + gain * innovation.unsqueeze(-1)
    identity = torch.eye(
        STATE_DIMENSION, dtype=torch.float64, device=prior.mean.device
    )
    joseph_factor = identity[None, None, :, :] - torch.einsum(
        "bsi,sj->bsij", gain, decoder_weight
    )
    posterior_covariance = (
        joseph_factor
        @ prior.covariance[:, None, :, :]
        @ joseph_factor.transpose(-1, -2)
        + torch.einsum("bsi,bsj,s->bsij", gain, gain, observation_variance)
    )
    flat_covariance, floor_diagnostics = training_stabilize_covariance(
        posterior_covariance.reshape(-1, STATE_DIMENSION, STATE_DIMENSION)
    )
    posterior = GaussianState(
        posterior_mean.reshape(-1, STATE_DIMENSION),
        flat_covariance,
    )
    return posterior, {
        "innovation": innovation,
        "innovation_variance": innovation_variance,
        "kalman_gain": gain,
        "clipped_matrix": floor_diagnostics["clipped_matrix"].reshape(
            batch_size, STATION_COUNT
        ),
    }


def _decode(
    adapter: D32GRUDifferentiableUnscentedKalmanFilter,
    mean: torch.Tensor,
) -> torch.Tensor:
    return F.linear(
        mean,
        adapter.backbone.observation_decoder.weight.to(torch.float64),
        adapter.backbone.observation_decoder.bias.to(torch.float64),
    )


def forward_all_station_training_scenarios(
    adapter: D32GRUDifferentiableUnscentedKalmanFilter,
    history: torch.Tensor,
    future_tide: torch.Tensor,
    analysis_observations: torch.Tensor,
    *,
    include_open_loop: bool = False,
) -> Dict[str, torch.Tensor]:
    """Return six independent single-station forecasts from one shared prior."""

    if not isinstance(include_open_loop, bool):
        raise ValueError("include_open_loop must be Boolean")
    reference = adapter.backbone.observation_decoder.weight
    if not isinstance(history, torch.Tensor) or history.ndim != 3:
        raise ValueError("history must have shape [batch,24,6]")
    batch_size = int(history.shape[0])
    if batch_size < 1 or history.shape != (batch_size, 24, STATION_COUNT):
        raise ValueError("history must have shape [batch,24,6]")
    if (
        history.dtype != reference.dtype
        or history.device != reference.device
        or not bool(torch.isfinite(history).all())
    ):
        raise ValueError("history must be finite and match the backbone")
    if (
        not isinstance(future_tide, torch.Tensor)
        or future_tide.shape != (batch_size, 24)
        or future_tide.dtype != reference.dtype
        or future_tide.device != reference.device
        or not bool(torch.isfinite(future_tide).all())
    ):
        raise ValueError("future tide must be finite [batch,24]")

    # History encoding is frozen and has no dependency on the 38 fitted values.
    with torch.no_grad():
        encoded = adapter.backbone.encode_history(history).to(torch.float64)
    encoded_state = GaussianState(
        encoded,
        adapter.initial_covariance.expand(batch_size, -1, -1),
    )
    analysis_prior, prior_diagnostics = _predict_state(
        adapter, encoded_state, future_tide[:, 0]
    )
    assimilation_state, update_diagnostics = _update_all_stations(
        adapter, analysis_prior, analysis_observations
    )
    analysis_posterior = assimilation_state
    open_state = analysis_prior
    assimilation_forecasts = []
    open_forecasts = []
    clipped_count = int(prior_diagnostics["clipped_matrix"].sum().item())
    clipped_count += int(update_diagnostics["clipped_matrix"].sum().item())
    for hour_index in range(1, 24):
        scenario_tide = (
            future_tide[:, hour_index, None]
            .expand(batch_size, STATION_COUNT)
            .reshape(-1)
        )
        assimilation_state, diagnostics = _predict_state(
            adapter, assimilation_state, scenario_tide
        )
        clipped_count += int(diagnostics["clipped_matrix"].sum().item())
        decoded = _decode(adapter, assimilation_state.mean).reshape(
            batch_size, STATION_COUNT, STATION_COUNT
        )
        assimilation_forecasts.append(decoded)
        if include_open_loop:
            open_state, open_diagnostics = _predict_state(
                adapter, open_state, future_tide[:, hour_index]
            )
            clipped_count += int(
                open_diagnostics["clipped_matrix"].sum().item()
            )
            open_forecasts.append(_decode(adapter, open_state.mean))

    result = {
        "assimilation_forecast": torch.stack(
            assimilation_forecasts, dim=2
        ),
        "analysis_prior_state_mean": analysis_prior.mean,
        "analysis_prior_state_covariance": analysis_prior.covariance,
        "analysis_posterior_state_mean": analysis_posterior.mean.reshape(
            batch_size, STATION_COUNT, STATE_DIMENSION
        ),
        "analysis_posterior_state_covariance": (
            analysis_posterior.covariance.reshape(
                batch_size,
                STATION_COUNT,
                STATE_DIMENSION,
                STATE_DIMENSION,
            )
        ),
        "analysis_innovation": update_diagnostics["innovation"],
        "analysis_innovation_variance": update_diagnostics[
            "innovation_variance"
        ],
        "analysis_kalman_gain": update_diagnostics["kalman_gain"],
        "spectral_floor_matrix_count": torch.tensor(
            clipped_count,
            dtype=torch.int64,
            device=history.device,
        ),
    }
    if include_open_loop:
        result["open_loop_forecast"] = torch.stack(open_forecasts, dim=1)
    return result


def other_station_metre_absolute_error_sum(
    prediction: torch.Tensor,
    targets: torch.Tensor,
    target_standard_deviation_m: torch.Tensor,
) -> Tuple[torch.Tensor, int]:
    """Return the equal-cell metre error sum and its exact denominator."""

    if not isinstance(prediction, torch.Tensor) or prediction.ndim != 4:
        raise ValueError("prediction must have shape [batch,6,23,6]")
    batch_size = int(prediction.shape[0])
    if prediction.shape != (
        batch_size,
        STATION_COUNT,
        FORECAST_LEAD_COUNT,
        STATION_COUNT,
    ):
        raise ValueError("prediction must have shape [batch,6,23,6]")
    if not prediction.dtype.is_floating_point or not bool(
        torch.isfinite(prediction).all()
    ):
        raise ValueError("prediction must be finite and floating point")
    if (
        not isinstance(targets, torch.Tensor)
        or targets.shape != (batch_size, FORECAST_LEAD_COUNT, STATION_COUNT)
        or not targets.dtype.is_floating_point
        or targets.device != prediction.device
        or not bool(torch.isfinite(targets).all())
    ):
        raise ValueError("targets must be finite [batch,23,6]")
    if (
        not isinstance(target_standard_deviation_m, torch.Tensor)
        or target_standard_deviation_m.shape != (STATION_COUNT,)
        or not target_standard_deviation_m.dtype.is_floating_point
        or target_standard_deviation_m.device != prediction.device
        or not bool(torch.isfinite(target_standard_deviation_m).all())
        or bool((target_standard_deviation_m <= 0.0).any())
    ):
        raise ValueError("target standard deviations must be six positive values")
    difference_m = (
        prediction - targets.to(prediction.dtype)[:, None, :, :]
    ) * target_standard_deviation_m.to(prediction.dtype)[None, None, None, :]
    off_diagonal = ~torch.eye(
        STATION_COUNT, dtype=torch.bool, device=prediction.device
    )
    absolute_error_sum = difference_m.abs().masked_select(
        off_diagonal[None, :, None, :]
    ).sum()
    valid_cell_count = (
        batch_size
        * STATION_COUNT
        * FORECAST_LEAD_COUNT
        * (STATION_COUNT - 1)
    )
    if not bool(torch.isfinite(absolute_error_sum)):
        raise ValueError("metre-space absolute error is nonfinite")
    return absolute_error_sum, valid_cell_count
