#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Pure shared-state gated recurrent unit encoder-decoder.

Inputs:
    ``history`` contains standardized six-station water levels for the previous
    twenty-four hours with shape ``[batch, 24, 6]``.  Availability masking is
    performed before this model is called.  ``future_tide`` contains only the
    standardized astronomical tide for the next twenty-four hours with shape
    ``[batch, 24]``.

Outputs:
    ``PureGRUEncoderDecoder`` returns standardized forecasts for all six
    stations and all twenty-four forecast hours with shape ``[batch, 24, 6]``.
    Its shared state is an abstract learned vector; no state coordinate is
    assigned to a station water level.

This module defines the model and explicit state-space interfaces only.  It
does not load data, train a model, run data assimilation, or write files.
"""

from __future__ import annotations

from typing import Tuple

import torch
from torch import nn


STATION_ORDER = (
    "datong",
    "nanjing",
    "zhenjiang",
    "jiangyin",
    "xuliujing",
    "wusongkou",
)
STATION_COUNT = len(STATION_ORDER)
HISTORY_LENGTH_HOURS = 24
FORECAST_LENGTH_HOURS = 24
ENCODER_HIDDEN_SIZE = 64
SUPPORTED_STATE_SIZES = (16, 32, 64)


def trainable_parameter_count(model: nn.Module) -> int:
    """Return the exact number of trainable scalar parameters."""

    return sum(
        parameter.numel()
        for parameter in model.parameters()
        if parameter.requires_grad
    )


def _validate_floating_tensor(
    value: torch.Tensor,
    *,
    name: str,
    expected_shape: Tuple[int, ...],
    reference: torch.Tensor,
) -> None:
    """Require one finite floating tensor with an exact model-compatible shape."""

    if not isinstance(value, torch.Tensor):
        raise ValueError(f"{name} must be a torch tensor")
    if tuple(value.shape) != tuple(expected_shape):
        raise ValueError(
            f"{name} must have shape {expected_shape}, received {tuple(value.shape)}"
        )
    if not value.dtype.is_floating_point:
        raise ValueError(f"{name} must use a floating-point dtype")
    if value.device != reference.device:
        raise ValueError(f"{name} device differs from the model")
    if value.dtype != reference.dtype:
        raise ValueError(f"{name} dtype differs from the model")
    if not bool(torch.isfinite(value).all()):
        raise ValueError(f"{name} contains a nonfinite value")


def _validate_history(history: torch.Tensor, reference: torch.Tensor) -> int:
    """Validate a standardized twenty-four-hour six-station history."""

    if not isinstance(history, torch.Tensor) or history.ndim != 3:
        raise ValueError("history must have shape [batch, 24, 6]")
    batch_size = int(history.shape[0])
    if batch_size < 1:
        raise ValueError("history must contain at least one sample")
    _validate_floating_tensor(
        history,
        name="history",
        expected_shape=(batch_size, HISTORY_LENGTH_HOURS, STATION_COUNT),
        reference=reference,
    )
    return batch_size


def _validate_future_tide(
    future_tide: torch.Tensor,
    *,
    batch_size: int,
    reference: torch.Tensor,
) -> None:
    """Validate the sole twenty-four-hour future control."""

    if not isinstance(future_tide, torch.Tensor) or future_tide.ndim != 2:
        raise ValueError("future_tide must have shape [batch, 24]")
    _validate_floating_tensor(
        future_tide,
        name="future_tide",
        expected_shape=(batch_size, FORECAST_LENGTH_HOURS),
        reference=reference,
    )


def _validate_state(
    state: torch.Tensor,
    *,
    state_size: int,
    reference: torch.Tensor,
) -> int:
    """Validate one batch of shared abstract states."""

    if not isinstance(state, torch.Tensor) or state.ndim != 2:
        raise ValueError(f"state must have shape [batch, {state_size}]")
    batch_size = int(state.shape[0])
    if batch_size < 1:
        raise ValueError("state must contain at least one sample")
    _validate_floating_tensor(
        state,
        name="state",
        expected_shape=(batch_size, state_size),
        reference=reference,
    )
    return batch_size


def _validate_tide_step(
    tide: torch.Tensor,
    *,
    batch_size: int,
    reference: torch.Tensor,
) -> None:
    """Validate one causal astronomical-tide value per sample."""

    if not isinstance(tide, torch.Tensor) or tide.ndim != 1:
        raise ValueError("tide must have shape [batch]")
    _validate_floating_tensor(
        tide,
        name="tide",
        expected_shape=(batch_size,),
        reference=reference,
    )


class PureGRUEncoderDecoder(nn.Module):
    """Forecast six stations through one shared abstract recurrent state."""

    def __init__(
        self,
        encoder_hidden_size: int = ENCODER_HIDDEN_SIZE,
        state_size: int = 16,
    ) -> None:
        super().__init__()
        if type(encoder_hidden_size) is not int or (
            encoder_hidden_size != ENCODER_HIDDEN_SIZE
        ):
            raise ValueError(
                f"encoder_hidden_size must be exactly {ENCODER_HIDDEN_SIZE}"
            )
        if type(state_size) is not int or state_size not in SUPPORTED_STATE_SIZES:
            raise ValueError(
                "state_size must be one of %s" % (SUPPORTED_STATE_SIZES,)
            )

        self.encoder_hidden_size = encoder_hidden_size
        self.state_size = state_size
        self.history_encoder = nn.GRU(
            input_size=STATION_COUNT,
            hidden_size=self.encoder_hidden_size,
            batch_first=True,
        )
        self.state_projection = nn.Linear(
            self.encoder_hidden_size,
            self.state_size,
        )
        self.process_cell = nn.GRUCell(
            input_size=1,
            hidden_size=self.state_size,
        )
        self.observation_decoder = nn.Linear(
            self.state_size,
            STATION_COUNT,
        )

    def _reference(self) -> torch.Tensor:
        """Return a parameter that fixes the accepted device and data type."""

        return self.observation_decoder.weight

    def encode_history(self, history: torch.Tensor) -> torch.Tensor:
        """Compress ``[batch,24,6]`` history into one abstract shared state."""

        _validate_history(history, self._reference())
        _, hidden = self.history_encoder(history)
        return torch.tanh(self.state_projection(hidden[-1]))

    def transition_step(
        self,
        state: torch.Tensor,
        tide: torch.Tensor,
    ) -> torch.Tensor:
        """Advance the abstract state by one hour using only astronomical tide."""

        batch_size = _validate_state(
            state,
            state_size=self.state_size,
            reference=self._reference(),
        )
        _validate_tide_step(
            tide,
            batch_size=batch_size,
            reference=self._reference(),
        )
        return self.process_cell(tide.reshape(batch_size, 1), state)

    def decode_state(self, state: torch.Tensor) -> torch.Tensor:
        """Map an abstract shared state to six standardized station levels."""

        _validate_state(
            state,
            state_size=self.state_size,
            reference=self._reference(),
        )
        return self.observation_decoder(state)

    def forward(
        self,
        history: torch.Tensor,
        future_tide: torch.Tensor,
    ) -> torch.Tensor:
        """Return causal forecasts with shape ``[batch,24,6]``."""

        batch_size = _validate_history(history, self._reference())
        _validate_future_tide(
            future_tide,
            batch_size=batch_size,
            reference=self._reference(),
        )
        state = self.encode_history(history)
        forecasts = []
        for hour_index in range(FORECAST_LENGTH_HOURS):
            state = self.transition_step(state, future_tide[:, hour_index])
            forecasts.append(self.decode_state(state))
        return torch.stack(forecasts, dim=1)
