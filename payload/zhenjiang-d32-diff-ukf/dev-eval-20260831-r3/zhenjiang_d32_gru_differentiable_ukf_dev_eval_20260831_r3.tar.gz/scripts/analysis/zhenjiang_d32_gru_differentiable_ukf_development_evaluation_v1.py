#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Evaluate three frozen differentiable-filter checkpoints on 2023 only.

Run from the deployed project root on a compute node.  One invocation evaluates
one registered frozen checkpoint.  It never trains, resumes, changes noise, or
accepts a held-out-target argument.

Example:
    python -u scripts/analysis/zhenjiang_d32_gru_differentiable_ukf_development_evaluation_v1.py \
      --config docs/records/zhenjiang_d32_gru_differentiable_ukf_s17_v1.json \
      --registry docs/records/ZHENJIANG_D32_GRU_DIFFERENTIABLE_UKF_V1_DEVELOPMENT_EVALUATION_REGISTRY.json \
      --input-dir /absolute/pre2024-v1 \
      --training-attempt /absolute/training/attempt_001 \
      --training-project-root /absolute/training/run \
      --loader-tide-model /absolute/training/run/results/modeling/wusongkou_astronomical_tide_v1_validation/tide_model.json \
      --output-root /absolute/development-evaluation \
      --device cuda:0 --allow-paid-evaluation
"""

from __future__ import annotations

import argparse
import csv
from dataclasses import asdict, is_dataclass
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import sys
import traceback
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import torch
from torch.utils.data import DataLoader

from water_level_joint_encoder_decoder_v2 import (
    EXPECTED_VALIDATION_SAMPLES,
    STATION_ORDER,
    load_joint_water_level_data,
)
from zhenjiang_d32_gru_differentiable_ukf_training_data_v1 import (
    D32GRUDifferentiableUKFBaseDataset,
)
from zhenjiang_d32_gru_differentiable_ukf_training_v1 import (
    FORECAST_LEAD_COUNT,
    STATION_COUNT,
    _decode,
    _predict_state,
    _update_all_stations,
    build_registered_training_adapter,
)
from zhenjiang_d32_gru_differentiable_ukf_v1 import (
    STATE_DIMENSION,
    GaussianState,
)
from zhenjiang_d32_gru_differentiable_ukf_development_metrics_v1 import (
    bootstrap_primary_gains,
    decide_development_gate,
    summarize_point_metrics,
    validate_block_error_rows,
)


REGISTRY_NAME = (
    "zhenjiang_d32_gru_differentiable_ukf_2023_development_evaluation_v1"
)
TEST_TARGET_COUNTER_NAMES = (
    "test_target_rows_read",
    "test_target_values_loaded",
    "test_target_values_parsed",
)
ZERO_TARGET_COUNTERS = {name: 0 for name in TEST_TARGET_COUNTER_NAMES}
REGISTERED_LEGACY_TRAINING_DATA_IDENTITY_SHA256 = (
    "d8491b3e9a61a6c6102f14a15401e1e4d2e8078d3c553c46fb008c6f929eb74f"
)
REGISTERED_LEGACY_TARGET_MEAN_FLOAT32_BITS = (
    1091151381,
    1084854959,
    1083302174,
    1079155211,
    1076876457,
    1074733478,
)
REGISTERED_LEGACY_TARGET_SCALE_FLOAT32_BITS = (
    1077169630,
    1070336360,
    1067417841,
    1063208851,
    1063488626,
    1063505265,
)
NORMALIZATION_REPLAY_RUNTIME_KEYS = ("python", "numpy")
REGISTERED_STATION_ORDER = (
    "datong",
    "nanjing",
    "zhenjiang",
    "jiangyin",
    "xuliujing",
    "wusongkou",
)
REGISTERED_TRAINING_RUN_IDENTITY_SHA256_BY_SEED = {
    17: "ee28f4edade42deb612a3c6a32ec703cb9521f7565f0ef68f3e68b5014c7c312",
    29: "ffc2eac67bc32f3df43cda6e598f9c24e8dac8edc95b9c9b0ddcb4f6fb6873e1",
    43: "9acae724e1cb3e7071b1f6f33c3e317df16ff9f318144b834f43fd91ea8f3ee3",
}
WORKER_ARTIFACT_NAMES = (
    "run_identity.json",
    "frozen_evaluation_config.json",
    "checkpoint_identity.json",
    "data_identity.json",
    "block_error_statistics.csv",
    "block_analysis_diagnostics.csv",
    "block_state_decay_statistics.csv",
    "worker_summary.json",
)
SUMMARY_ARTIFACT_NAMES = (
    "run_identity.json",
    "worker_identity_audit.json",
    "lead_condition_seed_metrics.csv",
    "window_condition_seed_metrics.csv",
    "target_station_lead_metrics.csv",
    "analysis_diagnostics.csv",
    "state_decay_diagnostics.csv",
    "bootstrap_condition_summary.csv",
    "holm_primary_family.csv",
    "development_gate.json",
)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _read_json(path: Path) -> Mapping[str, Any]:
    try:
        value = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise ValueError("JSON file cannot be read: %s" % path) from error
    if not isinstance(value, Mapping):
        raise ValueError("JSON root must be an object: %s" % path)
    return value


def _write_json(path: Path, value: Any) -> None:
    path = Path(path)
    if path.exists():
        raise FileExistsError("refusing to overwrite output: %s" % path)
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, sort_keys=False) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def _write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    path = Path(path)
    if path.exists():
        raise FileExistsError("refusing to overwrite output: %s" % path)
    if not rows:
        raise ValueError("CSV output rows must not be empty: %s" % path)
    fieldnames = list(rows[0])
    if any(list(row) != fieldnames for row in rows):
        raise ValueError("CSV row field order drift: %s" % path)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def _read_csv(path: Path) -> List[Dict[str, str]]:
    with Path(path).open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def _jsonable_dataclass_sequence(values: Iterable[Any]) -> List[Mapping[str, Any]]:
    result = []
    for value in values:
        row = asdict(value) if is_dataclass(value) else dict(value)
        for key, item in list(row.items()):
            if hasattr(item, "isoformat"):
                row[key] = item.isoformat()
        result.append(row)
    return result


def _float32_vector_identity(value: Any, name: str) -> Tuple[List[float], List[int]]:
    """Return one finite station vector and its exact float32 bit pattern."""

    try:
        array = np.asarray(value, dtype=np.float32)
    except (TypeError, ValueError, OverflowError) as error:
        raise RuntimeError("%s is not a numeric station vector" % name) from error
    if array.shape != (STATION_COUNT,) or not np.isfinite(array).all():
        raise RuntimeError("%s is not a finite six-station vector" % name)
    values = array.astype(np.float64).tolist()
    bits = [int(item) for item in array.view(np.uint32).tolist()]
    return values, bits


def _current_float32_vector_identity(
    value: Any, name: str
) -> Tuple[List[float], List[int]]:
    """Reject implicit dtype conversion for a current normalization vector."""

    array = np.asarray(value)
    if array.dtype != np.dtype(np.float32):
        raise RuntimeError("%s dtype is not float32" % name)
    return _float32_vector_identity(array, name)


def _verify_target_normalization_identity(
    *,
    source_data_identity: Mapping[str, Any],
    source_data_identity_sha256: str,
    source_run_identity_sha256: str,
    source_environment: Mapping[str, Any],
    current_environment: Mapping[str, Any],
    target_mean_m: Any,
    target_standard_deviation_m: Any,
) -> Mapping[str, Any]:
    """Verify target normalization under the registered legacy identity schema."""

    if tuple(STATION_ORDER) != REGISTERED_STATION_ORDER:
        raise RuntimeError("registered station order changed")
    if source_data_identity.get("schema_version") != "1.0":
        raise RuntimeError("training data identity schema is not registered")
    if (
        not isinstance(source_data_identity_sha256, str)
        or len(source_data_identity_sha256) != 64
        or not isinstance(source_run_identity_sha256, str)
        or len(source_run_identity_sha256) != 64
    ):
        raise RuntimeError("source training identity hash is invalid")
    _, current_mean_bits = _current_float32_vector_identity(
        target_mean_m, "current target normalization mean"
    )
    current_scale_values, current_scale_bits = _current_float32_vector_identity(
        target_standard_deviation_m,
        "current target normalization scale",
    )
    if any(value <= 0.0 for value in current_scale_values):
        raise RuntimeError("current target normalization scale is not positive")
    if "target_standard_deviation_m" not in source_data_identity:
        raise RuntimeError("source target normalization scale is missing")
    source_scale_values, source_scale_bits = _float32_vector_identity(
        source_data_identity["target_standard_deviation_m"],
        "source target normalization scale",
    )
    if any(value <= 0.0 for value in source_scale_values):
        raise RuntimeError("source target normalization scale is not positive")
    if current_scale_bits != source_scale_bits:
        raise RuntimeError("target normalization scale changed")

    if not isinstance(source_environment, Mapping) or not isinstance(
        current_environment, Mapping
    ):
        raise RuntimeError("normalization replay runtime identity is missing")
    runtime_identity: Dict[str, Any] = {}
    for key in NORMALIZATION_REPLAY_RUNTIME_KEYS:
        source_value = source_environment.get(key)
        current_value = current_environment.get(key)
        if (
            not isinstance(source_value, str)
            or not source_value
            or current_value != source_value
        ):
            raise RuntimeError("normalization replay runtime changed: %s" % key)
        runtime_identity[key] = current_value
    runtime_match_keys = list(NORMALIZATION_REPLAY_RUNTIME_KEYS)

    source_mean_present = "target_mean_m" in source_data_identity
    if source_mean_present:
        _, source_mean_bits = _float32_vector_identity(
            source_data_identity["target_mean_m"],
            "source target normalization mean",
        )
        if current_mean_bits != source_mean_bits:
            raise RuntimeError("target normalization mean changed")
        verification_method = "source_training_float32_bits"
    else:
        if (
            source_data_identity_sha256
            != REGISTERED_LEGACY_TRAINING_DATA_IDENTITY_SHA256
        ):
            raise RuntimeError("legacy training data identity hash is not registered")
        if current_mean_bits != list(REGISTERED_LEGACY_TARGET_MEAN_FLOAT32_BITS):
            raise RuntimeError("replayed target normalization mean changed")
        if current_scale_bits != list(
            REGISTERED_LEGACY_TARGET_SCALE_FLOAT32_BITS
        ):
            raise RuntimeError("replayed target normalization scale changed")
        verification_method = (
            "hash_verified_input_replay_under_matching_python_numpy"
        )

    return {
        "schema_version": "1.0",
        "verification_method": verification_method,
        "source_training_target_mean_present": source_mean_present,
        "source_training_data_identity_sha256": source_data_identity_sha256,
        "source_training_run_identity_sha256": source_run_identity_sha256,
        "runtime_match_keys": runtime_match_keys,
        "source_runtime_identity": dict(runtime_identity),
        "evaluation_runtime_identity": dict(runtime_identity),
        "station_order": list(REGISTERED_STATION_ORDER),
        "target_mean_float32_bits": current_mean_bits,
        "target_standard_deviation_float32_bits": current_scale_bits,
    }


def _validate_recorded_target_normalization_identity(
    data_identity: Mapping[str, Any],
    run_identity: Mapping[str, Any],
) -> Mapping[str, Any]:
    """Validate one completed worker's recorded normalization evidence."""

    normalization = data_identity.get("target_normalization_identity")
    environment = run_identity.get("environment")
    seed = run_identity.get("seed")
    if (
        not isinstance(normalization, Mapping)
        or not isinstance(environment, Mapping)
        or seed not in REGISTERED_TRAINING_RUN_IDENTITY_SHA256_BY_SEED
    ):
        raise RuntimeError("worker target normalization identity is missing")
    expected_runtime = {
        key: environment.get(key) for key in NORMALIZATION_REPLAY_RUNTIME_KEYS
    }
    _, mean_bits = _float32_vector_identity(
        data_identity.get("target_mean_m"), "recorded target normalization mean"
    )
    scale_values, scale_bits = _float32_vector_identity(
        data_identity.get("target_standard_deviation_m"),
        "recorded target normalization scale",
    )
    expected_run_sha256 = REGISTERED_TRAINING_RUN_IDENTITY_SHA256_BY_SEED[seed]
    if (
        any(value <= 0.0 for value in scale_values)
        or data_identity.get("validation_base_sample_count") != 8046
        or data_identity.get("last_loaded_target_time_beijing")
        != "2023-12-31T23:00:00+08:00"
        or data_identity.get("source_training_data_identity_sha256")
        != REGISTERED_LEGACY_TRAINING_DATA_IDENTITY_SHA256
        or data_identity.get("source_training_run_identity_sha256")
        != expected_run_sha256
        or normalization.get("schema_version") != "1.0"
        or normalization.get("verification_method")
        != "hash_verified_input_replay_under_matching_python_numpy"
        or normalization.get("source_training_target_mean_present") is not False
        or normalization.get("source_training_data_identity_sha256")
        != data_identity.get("source_training_data_identity_sha256")
        or normalization.get("source_training_run_identity_sha256")
        != data_identity.get("source_training_run_identity_sha256")
        or normalization.get("runtime_match_keys")
        != list(NORMALIZATION_REPLAY_RUNTIME_KEYS)
        or normalization.get("source_runtime_identity") != expected_runtime
        or normalization.get("evaluation_runtime_identity") != expected_runtime
        or normalization.get("station_order") != list(REGISTERED_STATION_ORDER)
        or normalization.get("target_mean_float32_bits")
        != list(REGISTERED_LEGACY_TARGET_MEAN_FLOAT32_BITS)
        or normalization.get("target_standard_deviation_float32_bits")
        != list(REGISTERED_LEGACY_TARGET_SCALE_FLOAT32_BITS)
        or mean_bits != list(REGISTERED_LEGACY_TARGET_MEAN_FLOAT32_BITS)
        or scale_bits != list(REGISTERED_LEGACY_TARGET_SCALE_FLOAT32_BITS)
    ):
        raise RuntimeError("worker target normalization identity mismatch")
    return dict(normalization)


def _state_dict_sha256(module: torch.nn.Module) -> str:
    digest = hashlib.sha256()
    for name, value in sorted(module.state_dict().items()):
        tensor = value.detach().cpu().contiguous()
        digest.update(name.encode("utf-8"))
        digest.update(str(tensor.dtype).encode("ascii"))
        digest.update(str(tuple(tensor.shape)).encode("ascii"))
        digest.update(tensor.numpy().tobytes())
    return digest.hexdigest()


def _environment_identity(device: torch.device) -> Mapping[str, Any]:
    value = {
        "python": sys.version,
        "platform": platform.platform(),
        "torch": torch.__version__,
        "numpy": np.__version__,
        "device": str(device),
        "cuda_available": torch.cuda.is_available(),
        "cuda_runtime": torch.version.cuda,
        "deterministic_algorithms_enabled": (
            torch.are_deterministic_algorithms_enabled()
        ),
        "cudnn_benchmark": torch.backends.cudnn.benchmark,
        "cudnn_deterministic": torch.backends.cudnn.deterministic,
        "cuda_matmul_allow_tf32": torch.backends.cuda.matmul.allow_tf32,
        "cudnn_allow_tf32": torch.backends.cudnn.allow_tf32,
    }
    if device.type == "cuda" and torch.cuda.is_available():
        value["cuda_device_name"] = torch.cuda.get_device_name(device)
        value["cuda_device_capability"] = list(
            torch.cuda.get_device_capability(device)
        )
    return value


def forward_evaluation_scenarios(
    adapter: torch.nn.Module,
    history: torch.Tensor,
    future_tide: torch.Tensor,
    analysis_observations: torch.Tensor,
) -> Dict[str, torch.Tensor]:
    """Match the frozen paired training forward and retain diagnostics."""

    reference = adapter.backbone.observation_decoder.weight
    if not isinstance(history, torch.Tensor) or history.ndim != 3:
        raise ValueError("history must have shape [batch,24,6]")
    batch_size = int(history.shape[0])
    if batch_size < 1 or history.shape != (batch_size, 24, STATION_COUNT):
        raise ValueError("history must have shape [batch,24,6]")
    if (
        history.dtype != reference.dtype
        or history.device != reference.device
        or not bool(torch.isfinite(history).all())
    ):
        raise ValueError("history must be finite and match the backbone")
    if (
        not isinstance(future_tide, torch.Tensor)
        or future_tide.shape != (batch_size, 24)
        or future_tide.dtype != reference.dtype
        or future_tide.device != reference.device
        or not bool(torch.isfinite(future_tide).all())
    ):
        raise ValueError("future tide must be finite [batch,24]")
    if (
        not isinstance(analysis_observations, torch.Tensor)
        or analysis_observations.shape != (batch_size, STATION_COUNT)
        or analysis_observations.dtype != reference.dtype
        or analysis_observations.device != reference.device
        or not bool(torch.isfinite(analysis_observations).all())
    ):
        raise ValueError("analysis observations must be finite [batch,6]")

    with torch.no_grad():
        encoded = adapter.backbone.encode_history(history).to(torch.float64)
    encoded_state = GaussianState(
        encoded,
        adapter.initial_covariance.expand(batch_size, -1, -1),
    )
    analysis_prior, prior_diagnostics = _predict_state(
        adapter, encoded_state, future_tide[:, 0]
    )
    assimilation_state, update_diagnostics = _update_all_stations(
        adapter, analysis_prior, analysis_observations
    )
    analysis_posterior = assimilation_state
    open_state = analysis_prior
    assimilation_forecasts = []
    open_forecasts = []
    state_differences = []
    clipped_count = int(prior_diagnostics["clipped_matrix"].sum().item())
    clipped_count += int(update_diagnostics["clipped_matrix"].sum().item())
    for hour_index in range(1, 24):
        scenario_tide = (
            future_tide[:, hour_index, None]
            .expand(batch_size, STATION_COUNT)
            .reshape(-1)
        )
        assimilation_state, diagnostics = _predict_state(
            adapter, assimilation_state, scenario_tide
        )
        clipped_count += int(diagnostics["clipped_matrix"].sum().item())
        assimilation_mean = assimilation_state.mean.reshape(
            batch_size, STATION_COUNT, STATE_DIMENSION
        )
        assimilation_forecasts.append(
            _decode(adapter, assimilation_state.mean).reshape(
                batch_size, STATION_COUNT, STATION_COUNT
            )
        )
        open_state, open_diagnostics = _predict_state(
            adapter, open_state, future_tide[:, hour_index]
        )
        clipped_count += int(open_diagnostics["clipped_matrix"].sum().item())
        open_forecasts.append(_decode(adapter, open_state.mean))
        state_differences.append(
            torch.linalg.vector_norm(
                assimilation_mean - open_state.mean[:, None, :], dim=-1
            )
        )

    posterior_mean = analysis_posterior.mean.reshape(
        batch_size, STATION_COUNT, STATE_DIMENSION
    )
    return {
        "assimilation_forecast": torch.stack(assimilation_forecasts, dim=2),
        "open_loop_forecast": torch.stack(open_forecasts, dim=1),
        "analysis_prior_state_mean": analysis_prior.mean,
        "analysis_prior_state_covariance": analysis_prior.covariance,
        "analysis_posterior_state_mean": posterior_mean,
        "analysis_posterior_state_covariance": (
            analysis_posterior.covariance.reshape(
                batch_size,
                STATION_COUNT,
                STATE_DIMENSION,
                STATE_DIMENSION,
            )
        ),
        "analysis_prior_observation": _decode(adapter, analysis_prior.mean),
        "analysis_posterior_observation": _decode(
            adapter, analysis_posterior.mean
        ).reshape(batch_size, STATION_COUNT, STATION_COUNT),
        "analysis_innovation": update_diagnostics["innovation"],
        "analysis_innovation_variance": update_diagnostics[
            "innovation_variance"
        ],
        "analysis_kalman_gain": update_diagnostics["kalman_gain"],
        "state_mean_difference_l2": torch.stack(state_differences, dim=2),
        "spectral_floor_matrix_count": torch.tensor(
            clipped_count, dtype=torch.int64, device=history.device
        ),
    }


def _to_numpy_float64(value: torch.Tensor, name: str) -> np.ndarray:
    if not isinstance(value, torch.Tensor) or not bool(torch.isfinite(value).all()):
        raise ValueError("%s must be a finite tensor" % name)
    return value.detach().cpu().to(torch.float64).numpy()


def accumulate_block_statistics(
    *,
    result: Mapping[str, torch.Tensor],
    normalized_targets: torch.Tensor,
    normalized_analysis_observations: torch.Tensor,
    base_record_indices: torch.Tensor,
    target_mean_m: torch.Tensor,
    target_standard_deviation_m: torch.Tensor,
    experiment_id: str,
    seed: int,
) -> Tuple[List[Mapping[str, Any]], List[Mapping[str, Any]], List[Mapping[str, Any]]]:
    """Convert one batch into block sufficient statistics without raw values."""

    assimilation = _to_numpy_float64(
        result["assimilation_forecast"], "assimilation forecast"
    )
    open_loop = _to_numpy_float64(
        result["open_loop_forecast"], "open-loop forecast"
    )
    targets = _to_numpy_float64(normalized_targets, "normalized targets")
    observations = _to_numpy_float64(
        normalized_analysis_observations, "analysis observations"
    )
    prior_observation = _to_numpy_float64(
        result["analysis_prior_observation"], "analysis prior observation"
    )
    posterior_observation = _to_numpy_float64(
        result["analysis_posterior_observation"],
        "analysis posterior observation",
    )
    innovation = _to_numpy_float64(
        result["analysis_innovation"], "analysis innovation"
    )
    gain = _to_numpy_float64(
        result["analysis_kalman_gain"], "analysis Kalman gain"
    )
    decay = _to_numpy_float64(
        result["state_mean_difference_l2"], "state mean difference"
    )
    if not isinstance(base_record_indices, torch.Tensor):
        raise ValueError("base record indices must be a tensor")
    indices = base_record_indices.detach().cpu().numpy()
    means = _to_numpy_float64(target_mean_m, "target means")
    scales = _to_numpy_float64(
        target_standard_deviation_m, "target standard deviations"
    )
    batch_size = int(targets.shape[0])
    if assimilation.shape != (batch_size, 6, 23, 6):
        raise ValueError("assimilation forecast shape drift")
    if open_loop.shape != (batch_size, 23, 6):
        raise ValueError("open-loop forecast shape drift")
    if targets.shape != (batch_size, 23, 6):
        raise ValueError("target shape drift")
    if observations.shape != (batch_size, 6):
        raise ValueError("analysis observation shape drift")
    if prior_observation.shape != (batch_size, 6):
        raise ValueError("analysis prior observation shape drift")
    if posterior_observation.shape != (batch_size, 6, 6):
        raise ValueError("analysis posterior observation shape drift")
    if innovation.shape != (batch_size, 6) or gain.shape != (batch_size, 6, 32):
        raise ValueError("analysis diagnostic shape drift")
    if decay.shape != (batch_size, 6, 23):
        raise ValueError("state decay shape drift")
    if indices.shape != (batch_size,) or means.shape != (6,) or scales.shape != (6,):
        raise ValueError("batch identity or normalization shape drift")
    if not np.issubdtype(indices.dtype, np.integer) or np.any(indices < 0):
        raise ValueError("base record indices must be nonnegative integers")
    if np.any(scales <= 0.0):
        raise ValueError("target standard deviations must be positive")
    if seed not in (17, 29, 43):
        raise ValueError("seed is outside the frozen set")
    if experiment_id != "ZHD32-DUKF-DEV-EVAL-S%d-V1" % seed:
        raise ValueError("evaluation experiment and seed differ")

    assimilation_difference_m = (
        assimilation - targets[:, None, :, :]
    ) * scales[None, None, None, :]
    open_difference_m = (
        open_loop - targets
    ) * scales[None, None, :]
    targets_m = targets * scales[None, None, :] + means[None, None, :]
    block_ids = indices // 168
    error_rows = []
    analysis_rows = []
    decay_rows = []
    for block_id in sorted(int(value) for value in np.unique(block_ids)):
        selected = block_ids == block_id
        block_count = int(np.count_nonzero(selected))
        for observed in range(6):
            for target in range(6):
                for lead_index in range(23):
                    assimilation_error = assimilation_difference_m[
                        selected, observed, lead_index, target
                    ]
                    open_error = open_difference_m[
                        selected, lead_index, target
                    ]
                    target_values = targets_m[selected, lead_index, target]
                    error_rows.append(
                        {
                            "schema_version": "1.0",
                            "experiment_id": experiment_id,
                            "seed": seed,
                            "block_id": block_id,
                            "block_origin_count": block_count,
                            "observed_station_index": observed,
                            "observed_station": STATION_ORDER[observed],
                            "target_station_index": target,
                            "target_station": STATION_ORDER[target],
                            "is_observed_target": observed == target,
                            "lead_hour": lead_index + 1,
                            "cell_count": block_count,
                            "assimilation_absolute_error_sum_m": float(
                                np.abs(assimilation_error).sum()
                            ),
                            "open_loop_absolute_error_sum_m": float(
                                np.abs(open_error).sum()
                            ),
                            "assimilation_squared_error_sum_m2": float(
                                np.square(assimilation_error).sum()
                            ),
                            "open_loop_squared_error_sum_m2": float(
                                np.square(open_error).sum()
                            ),
                            "target_sum_m": float(target_values.sum()),
                            "target_squared_sum_m2": float(
                                np.square(target_values).sum()
                            ),
                        }
                    )
            prior_error = (
                prior_observation[selected, observed]
                - observations[selected, observed]
            ) * scales[observed]
            posterior_error = (
                posterior_observation[selected, observed, observed]
                - observations[selected, observed]
            ) * scales[observed]
            innovation_m = innovation[selected, observed] * scales[observed]
            gain_l2 = np.linalg.norm(gain[selected, observed, :], axis=1)
            analysis_rows.append(
                {
                    "schema_version": "1.0",
                    "experiment_id": experiment_id,
                    "seed": seed,
                    "block_id": block_id,
                    "block_origin_count": block_count,
                    "observed_station_index": observed,
                    "observed_station": STATION_ORDER[observed],
                    "analysis_prior_error_sum_m": float(prior_error.sum()),
                    "analysis_prior_absolute_error_sum_m": float(
                        np.abs(prior_error).sum()
                    ),
                    "analysis_prior_squared_error_sum_m2": float(
                        np.square(prior_error).sum()
                    ),
                    "analysis_posterior_error_sum_m": float(
                        posterior_error.sum()
                    ),
                    "analysis_posterior_absolute_error_sum_m": float(
                        np.abs(posterior_error).sum()
                    ),
                    "analysis_posterior_squared_error_sum_m2": float(
                        np.square(posterior_error).sum()
                    ),
                    "innovation_sum_m": float(innovation_m.sum()),
                    "innovation_absolute_sum_m": float(np.abs(innovation_m).sum()),
                    "innovation_squared_sum_m2": float(
                        np.square(innovation_m).sum()
                    ),
                    "kalman_gain_l2_sum": float(gain_l2.sum()),
                    "kalman_gain_l2_squared_sum": float(np.square(gain_l2).sum()),
                    "count": block_count,
                }
            )
            for lead_index in range(23):
                values = decay[selected, observed, lead_index]
                decay_rows.append(
                    {
                        "schema_version": "1.0",
                        "experiment_id": experiment_id,
                        "seed": seed,
                        "block_id": block_id,
                        "block_origin_count": block_count,
                        "observed_station_index": observed,
                        "observed_station": STATION_ORDER[observed],
                        "lead_hour": lead_index + 1,
                        "state_mean_difference_l2_sum": float(values.sum()),
                        "state_mean_difference_l2_squared_sum": float(
                            np.square(values).sum()
                        ),
                        "count": block_count,
                    }
                )
    return error_rows, analysis_rows, decay_rows


def _combine_sufficient_rows(
    rows: Sequence[Mapping[str, Any]],
    key_fields: Sequence[str],
    sum_fields: Sequence[str],
) -> List[Mapping[str, Any]]:
    if not rows:
        raise ValueError("sufficient statistic rows must not be empty")
    grouped = {}
    for source in rows:
        row = dict(source)
        key = tuple(row[name] for name in key_fields)
        if key not in grouped:
            grouped[key] = row
            continue
        target = grouped[key]
        for name in sum_fields:
            target[name] = target[name] + row[name]
        for name, value in row.items():
            if name not in sum_fields and target[name] != value:
                raise RuntimeError("sufficient statistic identity drift: %s" % name)
    return [grouped[key] for key in sorted(grouped)]


def write_completion_manifest(
    output_directory: Path,
    *,
    status: str,
    expected_artifact_names: Sequence[str],
) -> Path:
    """Write a direct-file completion identity after the exact artifact set."""

    output_directory = Path(output_directory)
    manifest_path = output_directory / "completion_manifest.json"
    if manifest_path.exists():
        raise FileExistsError("completion manifest already exists")
    expected = set(expected_artifact_names)
    actual = {
        path.name
        for path in output_directory.iterdir()
        if path.is_file() and path.name != manifest_path.name
    }
    if actual != expected:
        raise RuntimeError("completion artifact set differs from the contract")
    rows = []
    for name in expected_artifact_names:
        path = output_directory / name
        if not path.is_file() or path.is_symlink():
            raise RuntimeError("completion artifact is absent or symbolic")
        rows.append(
            {
                "path": name,
                "byte_count": path.stat().st_size,
                "sha256": _sha256(path),
            }
        )
    manifest = {
        "schema_version": "1.0",
        "status": status,
        "created_utc": _utc_now(),
        "file_count": len(rows),
        "files": rows,
    }
    _write_json(manifest_path, manifest)
    return manifest_path


def _verify_completed_output(
    output_directory: Path,
    *,
    expected_artifact_names: Sequence[str],
    allowed_statuses: Sequence[str],
) -> Mapping[str, Any]:
    output_directory = Path(output_directory)
    manifest_path = output_directory / "completion_manifest.json"
    manifest = _read_json(manifest_path)
    if manifest.get("status") not in set(allowed_statuses):
        raise RuntimeError("completion status is invalid")
    rows = manifest.get("files")
    if not isinstance(rows, list) or manifest.get("file_count") != len(rows):
        raise RuntimeError("completion manifest schema changed")
    if [row.get("path") for row in rows] != list(expected_artifact_names):
        raise RuntimeError("completion artifact order or set changed")
    for row in rows:
        path = output_directory / str(row.get("path", ""))
        if (
            not path.is_file()
            or path.is_symlink()
            or path.stat().st_size != row.get("byte_count")
            or _sha256(path) != row.get("sha256")
        ):
            raise RuntimeError("completion artifact identity mismatch")
    actual = {
        path.name for path in output_directory.iterdir() if path.is_file()
    }
    if actual != set(expected_artifact_names) | {"completion_manifest.json"}:
        raise RuntimeError("completion artifact set identity mismatch")
    return {
        "status": manifest["status"],
        "verified_file_count": len(rows),
        "completion_manifest_sha256": _sha256(manifest_path),
    }


def verify_worker_output(output_directory: Path) -> Mapping[str, Any]:
    """Recompute the exact worker artifact identities."""

    return _verify_completed_output(
        output_directory,
        expected_artifact_names=WORKER_ARTIFACT_NAMES,
        allowed_statuses=(
            "completed_2023_development_worker",
            "completed_2023_development_smoke",
        ),
    )


def verify_summary_output(output_directory: Path) -> Mapping[str, Any]:
    """Recompute the exact summary artifact identities."""

    return _verify_completed_output(
        output_directory,
        expected_artifact_names=SUMMARY_ARTIFACT_NAMES,
        allowed_statuses=("completed_2023_development_summary",),
    )


def _resolve_attempt(output_root: Path, relative_text: str) -> Tuple[Path, Path]:
    root = Path(output_root).resolve()
    relative = Path(relative_text)
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError("attempt relative path is invalid")
    final = (root / relative).resolve()
    try:
        final.relative_to(root)
    except ValueError as error:
        raise ValueError("attempt output escapes the output root") from error
    partial = final.with_name(final.name + ".partial")
    if final.exists() or partial.exists():
        raise FileExistsError("attempt output already exists")
    return partial, final


def _verify_zero_target_counters(value: Mapping[str, Any], context: str) -> None:
    actual = value.get("test_target_counters")
    if not isinstance(actual, Mapping) or actual != ZERO_TARGET_COUNTERS or any(
        type(item) is not int for item in actual.values()
    ):
        raise RuntimeError("%s target counters are not integer zero" % context)


def _verify_training_attempt_identity(
    training_attempt: Path,
    expected: Mapping[str, Any],
) -> Mapping[str, Any]:
    attempt = Path(training_attempt).resolve()
    if str(attempt) != expected.get("attempt_directory"):
        raise ValueError("training attempt path differs from the frozen identity")
    required = expected.get("required_file_identities")
    if not isinstance(required, Mapping):
        raise ValueError("training output identity file map is missing")
    for name, identity in required.items():
        path = attempt / str(name)
        if (
            not path.is_file()
            or path.is_symlink()
            or path.stat().st_size != identity.get("byte_count")
            or _sha256(path) != identity.get("sha256")
        ):
            raise RuntimeError("training output identity mismatch: %s" % name)
    manifest = _read_json(attempt / "completion_manifest.json")
    if (
        manifest.get("status") != expected.get("completion_status")
        or manifest.get("file_count") != expected.get("manifest_file_count")
    ):
        raise RuntimeError("training completion manifest status drift")
    manifest_rows = manifest.get("files")
    if not isinstance(manifest_rows, list) or len(manifest_rows) != 12:
        raise RuntimeError("training completion manifest file count drift")
    for row in manifest_rows:
        relative = Path(str(row.get("path", "")))
        if relative.is_absolute() or ".." in relative.parts:
            raise RuntimeError("training completion path is invalid")
        path = (attempt / relative).resolve()
        try:
            path.relative_to(attempt)
        except ValueError as error:
            raise RuntimeError("training completion path escapes attempt") from error
        if (
            not path.is_file()
            or path.is_symlink()
            or path.stat().st_size != row.get("byte_count")
            or _sha256(path) != row.get("sha256")
        ):
            raise RuntimeError("training completion artifact identity mismatch")
    selection = _read_json(attempt / "selection_validation_summary.json")
    data_identity = _read_json(attempt / "data_identity.json")
    run_identity = _read_json(attempt / "run_identity.json")
    best_noise = _read_json(attempt / "best_noise_parameters.json")
    _verify_zero_target_counters(selection, "training selection")
    _verify_zero_target_counters(data_identity, "training data")
    if data_identity.get("last_loaded_target_time_beijing") != (
        "2023-12-31T23:00:00+08:00"
    ):
        raise RuntimeError("training target boundary changed")
    if (
        data_identity.get("schema_version") != "1.0"
        or data_identity.get("training_base_sample_count") != 46182
        or data_identity.get("validation_base_sample_count") != 8046
    ):
        raise RuntimeError("training data sample identity changed")
    if selection.get("best_epoch") != expected.get("best_epoch"):
        raise RuntimeError("training best epoch changed")
    if selection.get("completed_epoch") != expected.get("completed_epoch"):
        raise RuntimeError("training completed epoch changed")
    if float(selection.get("best_validation_mae_m")) != float(
        expected.get("selected_validation_assimilation_mae_m")
    ):
        raise RuntimeError("training selected metric changed")
    if run_identity.get("experiment_id") != selection.get("experiment_id"):
        raise RuntimeError("training run and selection identities differ")
    if best_noise.get("experiment_id") != selection.get("experiment_id"):
        raise RuntimeError("training noise and selection identities differ")
    return {
        "selection": selection,
        "data_identity": data_identity,
        "run_identity": run_identity,
        "best_noise": best_noise,
        "best_checkpoint_path": attempt / "best_checkpoint.pt",
        "best_checkpoint_sha256": required["best_checkpoint.pt"]["sha256"],
        "completion_manifest_sha256": required["completion_manifest.json"][
            "sha256"
        ],
    }


def _load_checkpoint_adapter(
    *,
    config: Mapping[str, Any],
    expected: Mapping[str, Any],
    verified_attempt: Mapping[str, Any],
    training_project_root: Path,
    technical_registry_path: Path,
    device: torch.device,
) -> Tuple[torch.nn.Module, Mapping[str, Any]]:
    expected_identities = expected.get("expected_checkpoint_payload_identities")
    if not isinstance(expected_identities, Mapping):
        raise ValueError("expected checkpoint payload identities are missing")
    if _sha256(technical_registry_path) != expected_identities.get(
        "technical_registry_sha256"
    ):
        raise RuntimeError("technical registry identity changed")
    adapter = build_registered_training_adapter(
        technical_registry_path,
        str(config["backbone_experiment_id"]),
        device,
        project_root=training_project_root,
    )
    checkpoint_path = verified_attempt["best_checkpoint_path"]
    try:
        checkpoint = torch.load(
            checkpoint_path, map_location=device, weights_only=True
        )
    except TypeError:
        checkpoint = torch.load(checkpoint_path, map_location=device)
    required_keys = {
        "schema_version",
        "experiment_id",
        "attempt_id",
        "best_epoch",
        "best_validation_mae_m",
        "adapter_state_dict",
        "identities",
        "test_target_counters",
    }
    if not isinstance(checkpoint, Mapping) or set(checkpoint) != required_keys:
        raise RuntimeError("best checkpoint schema changed")
    if checkpoint.get("experiment_id") != verified_attempt["selection"].get(
        "experiment_id"
    ):
        raise RuntimeError("best checkpoint experiment identity changed")
    if checkpoint.get("best_epoch") != expected.get("best_epoch"):
        raise RuntimeError("best checkpoint epoch changed")
    if dict(checkpoint.get("identities", {})) != dict(expected_identities):
        raise RuntimeError("best checkpoint source identities changed")
    if checkpoint.get("test_target_counters") != ZERO_TARGET_COUNTERS:
        raise RuntimeError("best checkpoint target counters changed")
    adapter.load_state_dict(checkpoint["adapter_state_dict"], strict=True)
    adapter.eval()
    adapter.backbone.eval()
    adapter.backbone.requires_grad_(False)
    backbone_hash = _state_dict_sha256(adapter.backbone)
    if backbone_hash != expected_identities["backbone_state_sha256"]:
        raise RuntimeError("loaded backbone state identity changed")
    best_noise = verified_attempt["best_noise"]
    process = adapter.process_noise.variance().detach().cpu().tolist()
    observation = adapter.observation_noise.variance().detach().cpu().tolist()
    if process != best_noise.get("process_variances"):
        raise RuntimeError("loaded process-noise values changed")
    if observation != best_noise.get("observation_variances"):
        raise RuntimeError("loaded observation-noise values changed")
    return adapter, {
        "schema_version": "1.0",
        "training_experiment_id": checkpoint["experiment_id"],
        "best_epoch": checkpoint["best_epoch"],
        "best_validation_mae_m": checkpoint["best_validation_mae_m"],
        "best_checkpoint_path": str(Path(checkpoint_path).resolve()),
        "best_checkpoint_sha256": verified_attempt["best_checkpoint_sha256"],
        "checkpoint_payload_identities": dict(checkpoint["identities"]),
        "backbone_state_sha256": backbone_hash,
        "process_variance_count": len(process),
        "observation_variance_count": len(observation),
        "only_adapter_state_dict_loaded": True,
        "optimizer_state_loaded": False,
        "random_state_loaded": False,
    }


def _validate_registry_and_select(
    registry_path: Path,
    config_path: Path,
    training_attempt: Path,
    project_root: Path,
) -> Tuple[Mapping[str, Any], Mapping[str, Any], Mapping[str, Any]]:
    registry = _read_json(registry_path)
    if registry.get("registry_name") != REGISTRY_NAME:
        raise ValueError("development evaluation registry name changed")
    authorization = registry.get("authorization")
    if authorization != {
        "development_2023_target_scoring": True,
        "held_out_target_access": False,
        "training": False,
        "parameter_change": False,
        "paid_hpc_evaluation": True,
        "scientific_conclusion": False,
    }:
        raise ValueError("development evaluation authorization drift")
    config = _read_json(config_path)
    seed = config.get("seed")
    experiment_id = "ZHD32-DUKF-DEV-EVAL-S%d-V1" % seed
    experiments = registry.get("experiments")
    if not isinstance(experiments, Mapping) or experiment_id not in experiments:
        raise ValueError("evaluation experiment is not registered")
    row = experiments[experiment_id]
    try:
        relative_config = Path(config_path).resolve().relative_to(
            Path(project_root).resolve()
        ).as_posix()
    except ValueError as error:
        raise ValueError("evaluation config escapes project root") from error
    if (
        row.get("experiment_id") != experiment_id
        or row.get("seed") != seed
        or row.get("training_experiment_id") != config.get("experiment_id")
        or row.get("config_path") != relative_config
        or row.get("config_sha256") != _sha256(config_path)
        or row.get("training_attempt") != str(Path(training_attempt).resolve())
    ):
        raise ValueError("registered evaluation identity drift")
    identities_path = Path(project_root) / str(
        registry.get("training_output_identities", {}).get("path", "")
    )
    identities_expected_sha = registry.get("training_output_identities", {}).get(
        "sha256"
    )
    if (
        not identities_path.is_file()
        or _sha256(identities_path) != identities_expected_sha
    ):
        raise RuntimeError("training output identity registry changed")
    identities = _read_json(identities_path)
    training_expected = identities.get("experiments", {}).get(
        config["experiment_id"]
    )
    if not isinstance(training_expected, Mapping):
        raise ValueError("training output identity row is missing")
    return config, row, training_expected


def _move_batch(batch: Mapping[str, Any], device: torch.device) -> Dict[str, Any]:
    moved = dict(batch)
    for name in (
        "history",
        "future_tide",
        "analysis_observations",
        "targets_t_plus_2_to_t_plus_24",
    ):
        value = batch.get(name)
        if not isinstance(value, torch.Tensor):
            raise ValueError("batch field is not a tensor: %s" % name)
        moved[name] = value.to(device)
    indices = batch.get("base_record_index")
    if not isinstance(indices, torch.Tensor):
        raise ValueError("base record index batch is not a tensor")
    moved["base_record_index"] = indices
    return moved


def execute_seed_evaluation(
    *,
    config_path: Path,
    registry_path: Path,
    input_dir: Path,
    training_attempt: Path,
    training_project_root: Path,
    tide_model_path: Path,
    output_root: Path,
    device: torch.device,
    allow_paid_evaluation: bool,
    maximum_batches: Optional[int] = None,
    smoke: bool = False,
) -> Path:
    """Execute one immutable 2023-only worker from one frozen checkpoint."""

    if not allow_paid_evaluation:
        raise PermissionError("paid evaluation requires --allow-paid-evaluation")
    if device.type != "cuda" or not torch.cuda.is_available():
        raise RuntimeError("registered evaluation requires a CUDA graphics processor")
    if smoke:
        if maximum_batches != 2:
            raise ValueError("smoke evaluation must use exactly two batches")
        completion_status = "completed_2023_development_smoke"
    else:
        if maximum_batches is not None:
            raise ValueError("formal evaluation cannot limit validation batches")
        completion_status = "completed_2023_development_worker"
    project_root = Path(__file__).resolve().parents[2]
    config_path = Path(config_path).resolve()
    registry_path = Path(registry_path).resolve()
    input_dir = Path(input_dir).resolve()
    training_attempt = Path(training_attempt).resolve()
    training_project_root = Path(training_project_root).resolve()
    tide_model_path = Path(tide_model_path).resolve()
    output_root = Path(output_root).resolve()
    config, registry_row, training_expected = _validate_registry_and_select(
        registry_path,
        config_path,
        training_attempt,
        project_root,
    )
    expected_training_root = Path(
        str(training_expected["attempt_directory"])
    ).parents[3]
    if training_project_root != expected_training_root / "run":
        raise ValueError("training project root differs from frozen training root")
    expected_input = expected_training_root / "inputs" / "pre2024-v1"
    if input_dir != expected_input or input_dir.is_symlink():
        raise ValueError("input directory is not the physical pre-2024 input")
    if tide_model_path != (
        training_project_root
        / "results"
        / "modeling"
        / "wusongkou_astronomical_tide_v1_validation"
        / "tide_model.json"
    ):
        raise ValueError("astronomical tide model path changed")
    relative_output = (
        registry_row["smoke_output_relative_path"]
        if smoke
        else registry_row["output_relative_path"]
    )
    partial, final = _resolve_attempt(output_root, str(relative_output))
    partial.parent.mkdir(parents=True, exist_ok=True)
    partial.mkdir()
    try:
        torch.use_deterministic_algorithms(True)
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        verified_attempt = _verify_training_attempt_identity(
            training_attempt, training_expected
        )
        technical_relative = str(registry_row["technical_registry_path"])
        technical_registry_path = training_project_root / technical_relative
        adapter, checkpoint_identity = _load_checkpoint_adapter(
            config=config,
            expected=training_expected,
            verified_attempt=verified_attempt,
            training_project_root=training_project_root,
            technical_registry_path=technical_registry_path,
            device=device,
        )
        current_environment = _environment_identity(device)
        run_identity = {
            "schema_version": "1.0",
            "experiment_id": registry_row["experiment_id"],
            "attempt_id": "attempt_001",
            "seed": config["seed"],
            "started_utc": _utc_now(),
            "run_type": "2023_development_smoke" if smoke else "2023_development_worker",
            "registry_path": str(registry_path),
            "registry_sha256": _sha256(registry_path),
            "source_training_experiment_id": config["experiment_id"],
            "training_attempt": str(training_attempt),
            "training_completion_manifest_sha256": verified_attempt[
                "completion_manifest_sha256"
            ],
            "environment": current_environment,
            "authorization": {
                "development_2023_target_scoring": True,
                "held_out_target_access": False,
                "training": False,
                "parameter_change": False,
                "scientific_conclusion": False,
            },
        }
        _write_json(partial / "run_identity.json", run_identity)
        frozen_evaluation_config = {
            "schema_version": "1.0",
            "experiment_id": registry_row["experiment_id"],
            "seed": config["seed"],
            "source_training_config_path": registry_row["config_path"],
            "source_training_config_sha256": registry_row["config_sha256"],
            "source_training_config": config,
            "observed_station_condition_indices": list(range(6)),
            "lead_hours": list(range(1, 24)),
            "block_length_origins": 168,
            "maximum_batches": maximum_batches,
            "smoke": smoke,
            "training_enabled": False,
            "held_out_target_access": False,
        }
        _write_json(
            partial / "frozen_evaluation_config.json", frozen_evaluation_config
        )
        _write_json(partial / "checkpoint_identity.json", checkpoint_identity)

        data = load_joint_water_level_data(
            input_dir=input_dir, tide_model_path=tide_model_path
        )
        counters = {
            name: getattr(data, name, None) for name in TEST_TARGET_COUNTER_NAMES
        }
        if counters != ZERO_TARGET_COUNTERS or any(
            type(value) is not int for value in counters.values()
        ):
            raise RuntimeError("evaluation target counters are not integer zero")
        if (
            len(data.training_records) != 46182
            or len(data.validation_records) != EXPECTED_VALIDATION_SAMPLES
        ):
            raise RuntimeError("training or 2023 validation base sample count changed")
        source_data_identity = verified_attempt["data_identity"]
        current_content = _jsonable_dataclass_sequence(data.input_content_identities)
        current_astronomical = _jsonable_dataclass_sequence(
            data.astronomical_dependency_identities
        )
        target_mean_values = (
            data.normalization.target_mean_m.astype(np.float64).tolist()
        )
        target_scale_values = (
            data.normalization.target_standard_deviation_m.astype(np.float64).tolist()
        )
        if current_content != source_data_identity.get("input_content_identities"):
            raise RuntimeError("evaluation input content identity changed")
        if current_astronomical != source_data_identity.get(
            "astronomical_dependency_identities"
        ):
            raise RuntimeError("astronomical dependency identity changed")
        normalization_identity = _verify_target_normalization_identity(
            source_data_identity=source_data_identity,
            source_data_identity_sha256=training_expected[
                "required_file_identities"
            ]["data_identity.json"]["sha256"],
            source_run_identity_sha256=training_expected[
                "required_file_identities"
            ]["run_identity.json"]["sha256"],
            source_environment=verified_attempt["run_identity"].get(
                "environment", {}
            ),
            current_environment=current_environment,
            target_mean_m=data.normalization.target_mean_m,
            target_standard_deviation_m=(
                data.normalization.target_standard_deviation_m
            ),
        )
        data_identity = {
            "schema_version": "1.0",
            "input_directory": str(input_dir),
            "tide_model_path": str(tide_model_path),
            "validation_base_sample_count": len(data.validation_records),
            "processed_base_sample_count": None,
            "last_loaded_target_time_beijing": max(
                audit.last_target_time_beijing for audit in data.station_read_audits
            ).isoformat(),
            "test_target_counters": counters,
            "source_training_data_identity_sha256": training_expected[
                "required_file_identities"
            ]["data_identity.json"]["sha256"],
            "source_training_run_identity_sha256": training_expected[
                "required_file_identities"
            ]["run_identity.json"]["sha256"],
            "input_content_identities": current_content,
            "astronomical_dependency_identities": current_astronomical,
            "target_mean_m": target_mean_values,
            "target_standard_deviation_m": target_scale_values,
            "target_normalization_identity": normalization_identity,
        }
        dataset = D32GRUDifferentiableUKFBaseDataset(
            data, data.validation_records
        )
        loader = DataLoader(
            dataset,
            batch_size=32,
            shuffle=False,
            drop_last=False,
            num_workers=0,
        )
        target_mean = torch.as_tensor(
            data.normalization.target_mean_m,
            dtype=torch.float64,
            device=device,
        )
        target_scale = torch.as_tensor(
            data.normalization.target_standard_deviation_m,
            dtype=torch.float64,
            device=device,
        )
        all_errors = []
        all_analysis = []
        all_decay = []
        processed_samples = 0
        completed_batches = 0
        spectral_floor_count = 0
        with torch.no_grad():
            for batch_index, batch in enumerate(loader):
                if maximum_batches is not None and batch_index >= maximum_batches:
                    break
                moved = _move_batch(batch, device)
                result = forward_evaluation_scenarios(
                    adapter,
                    moved["history"],
                    moved["future_tide"],
                    moved["analysis_observations"],
                )
                current = accumulate_block_statistics(
                    result=result,
                    normalized_targets=moved[
                        "targets_t_plus_2_to_t_plus_24"
                    ],
                    normalized_analysis_observations=moved[
                        "analysis_observations"
                    ],
                    base_record_indices=moved["base_record_index"],
                    target_mean_m=target_mean,
                    target_standard_deviation_m=target_scale,
                    experiment_id=registry_row["experiment_id"],
                    seed=int(config["seed"]),
                )
                all_errors.extend(current[0])
                all_analysis.extend(current[1])
                all_decay.extend(current[2])
                processed_samples += int(moved["history"].shape[0])
                completed_batches += 1
                spectral_floor_count += int(
                    result["spectral_floor_matrix_count"].item()
                )
        if completed_batches < 1 or processed_samples < 1:
            raise RuntimeError("evaluation completed no validation batches")
        error_rows = _combine_sufficient_rows(
            all_errors,
            (
                "seed",
                "block_id",
                "observed_station_index",
                "target_station_index",
                "lead_hour",
            ),
            (
                "block_origin_count",
                "cell_count",
                "assimilation_absolute_error_sum_m",
                "open_loop_absolute_error_sum_m",
                "assimilation_squared_error_sum_m2",
                "open_loop_squared_error_sum_m2",
                "target_sum_m",
                "target_squared_sum_m2",
            ),
        )
        analysis_rows = _combine_sufficient_rows(
            all_analysis,
            ("seed", "block_id", "observed_station_index"),
            (
                "block_origin_count",
                "analysis_prior_error_sum_m",
                "analysis_prior_absolute_error_sum_m",
                "analysis_prior_squared_error_sum_m2",
                "analysis_posterior_error_sum_m",
                "analysis_posterior_absolute_error_sum_m",
                "analysis_posterior_squared_error_sum_m2",
                "innovation_sum_m",
                "innovation_absolute_sum_m",
                "innovation_squared_sum_m2",
                "kalman_gain_l2_sum",
                "kalman_gain_l2_squared_sum",
                "count",
            ),
        )
        decay_rows = _combine_sufficient_rows(
            all_decay,
            ("seed", "block_id", "observed_station_index", "lead_hour"),
            (
                "block_origin_count",
                "state_mean_difference_l2_sum",
                "state_mean_difference_l2_squared_sum",
                "count",
            ),
        )
        data_identity["processed_base_sample_count"] = processed_samples
        _write_json(partial / "data_identity.json", data_identity)
        _write_csv(partial / "block_error_statistics.csv", error_rows)
        _write_csv(partial / "block_analysis_diagnostics.csv", analysis_rows)
        _write_csv(partial / "block_state_decay_statistics.csv", decay_rows)
        block_count = len({int(row["block_id"]) for row in error_rows})
        if not smoke:
            if processed_samples != 8046 or block_count != 48:
                raise RuntimeError("formal evaluation sample or block count changed")
            if len(error_rows) != 39744:
                raise RuntimeError("formal block error row count changed")
            if len(analysis_rows) != 288 or len(decay_rows) != 6624:
                raise RuntimeError("formal diagnostic row count changed")
        worker_summary = {
            "schema_version": "1.0",
            "status": completion_status,
            "experiment_id": registry_row["experiment_id"],
            "seed": config["seed"],
            "completed_utc": _utc_now(),
            "completed_batches": completed_batches,
            "processed_base_sample_count": processed_samples,
            "block_count": block_count,
            "block_error_row_count": len(error_rows),
            "block_analysis_row_count": len(analysis_rows),
            "block_state_decay_row_count": len(decay_rows),
            "observed_station_condition_count": 6,
            "target_station_count": 6,
            "lead_hour_count": 23,
            "spectral_floor_matrix_count": spectral_floor_count,
            "test_target_counters": counters,
            "backbone_state_sha256": _state_dict_sha256(adapter.backbone),
            "training_completion_manifest_sha256": verified_attempt[
                "completion_manifest_sha256"
            ],
            "best_checkpoint_sha256": verified_attempt[
                "best_checkpoint_sha256"
            ],
            "scientific_conclusion_authorized": False,
        }
        _write_json(partial / "worker_summary.json", worker_summary)
        run_identity["completed_utc"] = _utc_now()
        run_identity["completion_status"] = completion_status
        (partial / "run_identity.json").unlink()
        _write_json(partial / "run_identity.json", run_identity)
        write_completion_manifest(
            partial,
            status=completion_status,
            expected_artifact_names=WORKER_ARTIFACT_NAMES,
        )
        verification = verify_worker_output(partial)
        if verification["status"] != completion_status:
            raise RuntimeError("worker completion verification status changed")
        os.replace(str(partial), str(final))
        return final
    except Exception as error:
        failure = {
            "schema_version": "1.0",
            "status": "failed_incomplete",
            "failed_utc": _utc_now(),
            "error_type": type(error).__name__,
            "error": str(error),
            "traceback": traceback.format_exc(),
            "completion_manifest_written": False,
        }
        if partial.is_dir() and not (partial / "failure.json").exists():
            _write_json(partial / "failure.json", failure)
        raise


def _diagnostic_float(row: Mapping[str, Any], name: str) -> float:
    try:
        value = float(row[name])
    except (KeyError, TypeError, ValueError) as error:
        raise ValueError("diagnostic field is not numeric: %s" % name) from error
    if not math.isfinite(value):
        raise ValueError("diagnostic field is nonfinite: %s" % name)
    return value


def _diagnostic_int(row: Mapping[str, Any], name: str) -> int:
    try:
        value = int(row[name])
    except (KeyError, TypeError, ValueError) as error:
        raise ValueError("diagnostic field is not integer: %s" % name) from error
    if isinstance(row[name], str) and str(value) != row[name].strip():
        raise ValueError("diagnostic integer text is not canonical: %s" % name)
    return value


def _summarize_analysis_diagnostics(
    rows: Sequence[Mapping[str, Any]],
) -> List[Mapping[str, Any]]:
    groups = {}
    seen = set()
    sum_fields = (
        "analysis_prior_error_sum_m",
        "analysis_prior_absolute_error_sum_m",
        "analysis_prior_squared_error_sum_m2",
        "analysis_posterior_error_sum_m",
        "analysis_posterior_absolute_error_sum_m",
        "analysis_posterior_squared_error_sum_m2",
        "innovation_sum_m",
        "innovation_absolute_sum_m",
        "innovation_squared_sum_m2",
        "kalman_gain_l2_sum",
        "kalman_gain_l2_squared_sum",
    )
    for row in rows:
        seed = _diagnostic_int(row, "seed")
        block = _diagnostic_int(row, "block_id")
        observed = _diagnostic_int(row, "observed_station_index")
        count = _diagnostic_int(row, "count")
        if seed not in (17, 29, 43) or observed not in range(6) or count < 1:
            raise ValueError("analysis diagnostic identity is invalid")
        if row.get("observed_station") != STATION_ORDER[observed]:
            raise ValueError("analysis diagnostic station identity changed")
        unique = (seed, block, observed)
        if unique in seen:
            raise ValueError("duplicate analysis diagnostic block row")
        seen.add(unique)
        key = (seed, observed)
        if key not in groups:
            groups[key] = {name: 0.0 for name in sum_fields}
            groups[key]["count"] = 0
        groups[key]["count"] += count
        for name in sum_fields:
            groups[key][name] += _diagnostic_float(row, name)
    result = []
    for (seed, observed), values in sorted(groups.items()):
        count = values["count"]
        result.append(
            {
                "seed": seed,
                "observed_station_index": observed,
                "observed_station": STATION_ORDER[observed],
                "count": count,
                "analysis_prior_mean_error_m": values[
                    "analysis_prior_error_sum_m"
                ]
                / count,
                "analysis_prior_mae_m": values[
                    "analysis_prior_absolute_error_sum_m"
                ]
                / count,
                "analysis_prior_rmse_m": math.sqrt(
                    values["analysis_prior_squared_error_sum_m2"] / count
                ),
                "analysis_posterior_mean_error_m": values[
                    "analysis_posterior_error_sum_m"
                ]
                / count,
                "analysis_posterior_mae_m": values[
                    "analysis_posterior_absolute_error_sum_m"
                ]
                / count,
                "analysis_posterior_rmse_m": math.sqrt(
                    values["analysis_posterior_squared_error_sum_m2"] / count
                ),
                "innovation_mean_m": values["innovation_sum_m"] / count,
                "innovation_mae_m": values["innovation_absolute_sum_m"] / count,
                "innovation_rmse_m": math.sqrt(
                    values["innovation_squared_sum_m2"] / count
                ),
                "kalman_gain_l2_mean": values["kalman_gain_l2_sum"] / count,
                "kalman_gain_l2_rms": math.sqrt(
                    values["kalman_gain_l2_squared_sum"] / count
                ),
            }
        )
    return result


def _summarize_state_decay(
    rows: Sequence[Mapping[str, Any]],
) -> List[Mapping[str, Any]]:
    groups = {}
    seen = set()
    for row in rows:
        seed = _diagnostic_int(row, "seed")
        block = _diagnostic_int(row, "block_id")
        observed = _diagnostic_int(row, "observed_station_index")
        lead = _diagnostic_int(row, "lead_hour")
        count = _diagnostic_int(row, "count")
        if (
            seed not in (17, 29, 43)
            or observed not in range(6)
            or lead not in range(1, 24)
            or count < 1
        ):
            raise ValueError("state decay identity is invalid")
        if row.get("observed_station") != STATION_ORDER[observed]:
            raise ValueError("state decay station identity changed")
        unique = (seed, block, observed, lead)
        if unique in seen:
            raise ValueError("duplicate state decay block row")
        seen.add(unique)
        key = (seed, observed, lead)
        if key not in groups:
            groups[key] = {"sum": 0.0, "squared": 0.0, "count": 0}
        groups[key]["sum"] += _diagnostic_float(
            row, "state_mean_difference_l2_sum"
        )
        groups[key]["squared"] += _diagnostic_float(
            row, "state_mean_difference_l2_squared_sum"
        )
        groups[key]["count"] += count
    result = []
    for (seed, observed, lead), values in sorted(groups.items()):
        count = values["count"]
        result.append(
            {
                "seed": seed,
                "observed_station_index": observed,
                "observed_station": STATION_ORDER[observed],
                "lead_hour": lead,
                "count": count,
                "state_mean_difference_l2_mean": values["sum"] / count,
                "state_mean_difference_l2_rms": math.sqrt(
                    values["squared"] / count
                ),
            }
        )
    return result


def aggregate_completed_workers(
    *,
    worker_directories: Sequence[Path],
    output_root: Path,
    repeat_count: int = 20000,
    bootstrap_seed: int = 20260828,
    require_formal: bool = True,
    registry_path: Optional[Path] = None,
) -> Path:
    """Aggregate three immutable workers into one immutable summary."""

    if require_formal and (repeat_count != 20000 or bootstrap_seed != 20260828):
        raise ValueError("formal aggregation must use the frozen bootstrap")
    if len(worker_directories) != 3:
        raise ValueError("aggregation requires exactly three worker directories")
    registered_experiments = None
    registry_sha256 = None
    if registry_path is not None:
        registry_path = Path(registry_path).resolve()
        registry = _read_json(registry_path)
        if (
            registry.get("registry_name") != REGISTRY_NAME
            or registry.get("authorization")
            != {
                "development_2023_target_scoring": True,
                "held_out_target_access": False,
                "training": False,
                "parameter_change": False,
                "paid_hpc_evaluation": True,
                "scientific_conclusion": False,
            }
            or not isinstance(registry.get("experiments"), Mapping)
        ):
            raise RuntimeError("aggregation registry identity changed")
        registered_experiments = registry["experiments"]
        registry_sha256 = _sha256(registry_path)
    elif require_formal:
        raise ValueError("formal aggregation requires the frozen registry")
    final = (
        Path(output_root).resolve()
        / "ZHD32-DUKF-DEV-EVAL-SUMMARY-V1"
        / "attempt_001"
    )
    partial = final.with_name(final.name + ".partial")
    if final.exists() or partial.exists():
        raise FileExistsError("summary output already exists")
    partial.parent.mkdir(parents=True, exist_ok=True)
    partial.mkdir()
    try:
        worker_audit = []
        all_error_rows = []
        all_analysis_rows = []
        all_decay_rows = []
        seen_seeds = set()
        identity_details = {
            "three_worker_completion_manifests_verified": True,
            "worker_seed_set_exact": True,
            "paired_block_rows_valid": True,
            "zero_target_access_all_workers": True,
            "source_checkpoint_identities_present": True,
            "target_normalization_identity_verified_all_workers": True,
            "registered_worker_identities_match": (
                registered_experiments is not None or not require_formal
            ),
        }
        for directory in worker_directories:
            worker = Path(directory).resolve()
            verification = verify_worker_output(worker)
            if verification["status"] != "completed_2023_development_worker":
                raise RuntimeError("aggregation requires formal completed workers")
            summary = _read_json(worker / "worker_summary.json")
            run_identity = _read_json(worker / "run_identity.json")
            data_identity = _read_json(worker / "data_identity.json")
            checkpoint_identity = _read_json(worker / "checkpoint_identity.json")
            frozen_config = _read_json(worker / "frozen_evaluation_config.json")
            seed = summary.get("seed")
            expected_experiment = "ZHD32-DUKF-DEV-EVAL-S%d-V1" % seed
            if (
                seed not in (17, 29, 43)
                or seed in seen_seeds
                or summary.get("experiment_id") != expected_experiment
                or run_identity.get("experiment_id") != expected_experiment
            ):
                raise RuntimeError("worker seed or experiment identity changed")
            seen_seeds.add(seed)
            if registered_experiments is not None:
                registered = registered_experiments.get(expected_experiment)
                if (
                    not isinstance(registered, Mapping)
                    or registered.get("experiment_id") != expected_experiment
                    or registered.get("seed") != seed
                    or registered.get("best_checkpoint_sha256")
                    != checkpoint_identity.get("best_checkpoint_sha256")
                    or registered.get("training_experiment_id")
                    != checkpoint_identity.get("training_experiment_id")
                    or run_identity.get("registry_sha256") != registry_sha256
                    or frozen_config.get("source_training_config_sha256")
                    != registered.get("config_sha256")
                ):
                    raise RuntimeError("worker registry or checkpoint identity changed")
            _verify_zero_target_counters(summary, "worker summary")
            _verify_zero_target_counters(data_identity, "worker data")
            if data_identity.get("last_loaded_target_time_beijing") != (
                "2023-12-31T23:00:00+08:00"
            ):
                raise RuntimeError("worker target boundary changed")
            normalization_identity = _validate_recorded_target_normalization_identity(
                data_identity, run_identity
            )
            if (
                checkpoint_identity.get("only_adapter_state_dict_loaded") is not True
                or checkpoint_identity.get("optimizer_state_loaded") is not False
                or checkpoint_identity.get("random_state_loaded") is not False
                or not isinstance(
                    checkpoint_identity.get("best_checkpoint_sha256"), str
                )
            ):
                raise RuntimeError("worker checkpoint loading identity changed")
            error_rows = _read_csv(worker / "block_error_statistics.csv")
            analysis_rows = _read_csv(worker / "block_analysis_diagnostics.csv")
            decay_rows = _read_csv(worker / "block_state_decay_statistics.csv")
            typed_errors = validate_block_error_rows(error_rows)
            if {row["seed"] for row in typed_errors} != {seed}:
                raise RuntimeError("worker block error seed changed")
            blocks = {row["block_id"] for row in typed_errors}
            if require_formal:
                if (
                    summary.get("processed_base_sample_count") != 8046
                    or summary.get("block_count") != 48
                    or blocks != set(range(48))
                    or len(typed_errors) != 39744
                    or len(analysis_rows) != 288
                    or len(decay_rows) != 6624
                ):
                    raise RuntimeError("formal worker coverage changed")
            all_error_rows.extend(typed_errors)
            all_analysis_rows.extend(analysis_rows)
            all_decay_rows.extend(decay_rows)
            manifest = _read_json(worker / "completion_manifest.json")
            worker_audit.append(
                {
                    "seed": seed,
                    "experiment_id": expected_experiment,
                    "worker_directory": str(worker),
                    "completion_manifest_sha256": verification[
                        "completion_manifest_sha256"
                    ],
                    "completion_manifest_file_count": verification[
                        "verified_file_count"
                    ],
                    "best_checkpoint_sha256": checkpoint_identity[
                        "best_checkpoint_sha256"
                    ],
                    "processed_base_sample_count": summary.get(
                        "processed_base_sample_count"
                    ),
                    "block_count": summary.get("block_count"),
                    "manifest_files": manifest["files"],
                    "test_target_counters": data_identity[
                        "test_target_counters"
                    ],
                    "target_normalization_identity": normalization_identity,
                }
            )
        if seen_seeds != {17, 29, 43}:
            raise RuntimeError("worker seed set differs from 17, 29, and 43")

        point_metrics = summarize_point_metrics(all_error_rows)
        if require_formal:
            if len(point_metrics["lead_condition_seed_metrics"]) != 414:
                raise RuntimeError("lead-condition-seed metric coverage changed")
            if len(point_metrics["window_condition_seed_metrics"]) != 54:
                raise RuntimeError("window-condition-seed metric coverage changed")
            if len(point_metrics["target_station_lead_metrics"]) != 2484:
                raise RuntimeError("target-station-lead metric coverage changed")
        bootstrap = bootstrap_primary_gains(
            all_error_rows,
            repeat_count=repeat_count,
            seed=bootstrap_seed,
        )
        gate = decide_development_gate(
            point_metrics, bootstrap, identity_gate=identity_details
        )
        analysis_summary = _summarize_analysis_diagnostics(all_analysis_rows)
        decay_summary = _summarize_state_decay(all_decay_rows)
        if require_formal and (
            len(analysis_summary) != 18 or len(decay_summary) != 414
        ):
            raise RuntimeError("summary diagnostic coverage changed")

        registry_identity = None
        if registry_path is not None:
            registry_identity = {
                "path": str(registry_path),
                "sha256": registry_sha256,
            }
        run_identity = {
            "schema_version": "1.0",
            "experiment_id": "ZHD32-DUKF-DEV-EVAL-SUMMARY-V1",
            "attempt_id": "attempt_001",
            "started_utc": _utc_now(),
            "worker_count": 3,
            "worker_seeds": [17, 29, 43],
            "registry_identity": registry_identity,
            "bootstrap": bootstrap["sampling"],
            "require_formal": require_formal,
            "authorization": {
                "development_2023_target_scoring": True,
                "held_out_target_access": False,
                "training": False,
                "parameter_change": False,
                "scientific_conclusion": False,
            },
        }
        _write_json(partial / "run_identity.json", run_identity)
        _write_json(
            partial / "worker_identity_audit.json",
            {
                "schema_version": "1.0",
                "status": "verified",
                "workers": sorted(worker_audit, key=lambda row: row["seed"]),
                "identity_gate_details": identity_details,
            },
        )
        _write_csv(
            partial / "lead_condition_seed_metrics.csv",
            point_metrics["lead_condition_seed_metrics"],
        )
        _write_csv(
            partial / "window_condition_seed_metrics.csv",
            point_metrics["window_condition_seed_metrics"],
        )
        _write_csv(
            partial / "target_station_lead_metrics.csv",
            point_metrics["target_station_lead_metrics"],
        )
        _write_csv(partial / "analysis_diagnostics.csv", analysis_summary)
        _write_csv(partial / "state_decay_diagnostics.csv", decay_summary)
        bootstrap_rows = []
        for row in bootstrap["condition_summaries"]:
            bootstrap_rows.append(
                {
                    "row_type": "condition",
                    "observed_station_index": row["observed_station_index"],
                    "observed_station": row["observed_station"],
                    "condition_count": 1,
                    "point_gain_open_loop_minus_assimilation_m": row[
                        "point_gain_open_loop_minus_assimilation_m"
                    ],
                    "point_delta_assimilation_minus_open_loop_m": row[
                        "point_delta_assimilation_minus_open_loop_m"
                    ],
                    "bootstrap_gain_mean_m": row["bootstrap_gain_mean_m"],
                    "gain_two_sided_95_lower_m": row[
                        "gain_two_sided_95_lower_m"
                    ],
                    "gain_two_sided_95_upper_m": row[
                        "gain_two_sided_95_upper_m"
                    ],
                    "delta_one_sided_95_upper_m": row[
                        "delta_one_sided_95_upper_m"
                    ],
                    "gain_one_sided_p_value": row[
                        "gain_one_sided_p_value"
                    ],
                }
            )
        macro = bootstrap["macro_summary"]
        bootstrap_rows.append(
            {
                "row_type": "macro",
                "observed_station_index": "",
                "observed_station": "six_condition_macro",
                "condition_count": macro["condition_count"],
                "point_gain_open_loop_minus_assimilation_m": macro[
                    "point_gain_open_loop_minus_assimilation_m"
                ],
                "point_delta_assimilation_minus_open_loop_m": macro[
                    "point_delta_assimilation_minus_open_loop_m"
                ],
                "bootstrap_gain_mean_m": macro["bootstrap_gain_mean_m"],
                "gain_two_sided_95_lower_m": macro[
                    "gain_two_sided_95_lower_m"
                ],
                "gain_two_sided_95_upper_m": macro[
                    "gain_two_sided_95_upper_m"
                ],
                "delta_one_sided_95_upper_m": macro[
                    "delta_one_sided_95_upper_m"
                ],
                "gain_one_sided_p_value": macro["gain_one_sided_p_value"],
            }
        )
        _write_csv(
            partial / "bootstrap_condition_summary.csv", bootstrap_rows
        )
        _write_csv(
            partial / "holm_primary_family.csv", gate["holm_primary_family"]
        )
        _write_json(partial / "development_gate.json", gate)
        run_identity["completed_utc"] = _utc_now()
        run_identity["machine_status"] = gate["status"]
        (partial / "run_identity.json").unlink()
        _write_json(partial / "run_identity.json", run_identity)
        write_completion_manifest(
            partial,
            status="completed_2023_development_summary",
            expected_artifact_names=SUMMARY_ARTIFACT_NAMES,
        )
        verify_summary_output(partial)
        os.replace(str(partial), str(final))
        return final
    except Exception:
        raise


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--registry", type=Path)
    parser.add_argument("--input-dir", type=Path)
    parser.add_argument("--training-attempt", type=Path)
    parser.add_argument("--training-project-root", type=Path)
    parser.add_argument("--loader-tide-model", type=Path)
    parser.add_argument("--output-root", type=Path)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--maximum-batches", type=int)
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--allow-paid-evaluation", action="store_true")
    parser.add_argument("--verify-output", type=Path)
    parser.add_argument("--aggregate", action="store_true")
    parser.add_argument("--workers-root", type=Path)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    arguments = _build_parser().parse_args(argv)
    if arguments.verify_output is not None:
        forbidden = (
            arguments.config,
            arguments.registry,
            arguments.input_dir,
            arguments.training_attempt,
            arguments.training_project_root,
            arguments.loader_tide_model,
            arguments.output_root,
            arguments.workers_root,
        )
        if any(value is not None for value in forbidden) or any(
            (
                arguments.aggregate,
                arguments.smoke,
                arguments.allow_paid_evaluation,
                arguments.maximum_batches is not None,
            )
        ):
            raise SystemExit("--verify-output must be used alone")
        print(json.dumps(verify_worker_output(arguments.verify_output), indent=2))
        return 0
    if arguments.aggregate:
        forbidden = (
            arguments.config,
            arguments.input_dir,
            arguments.training_attempt,
            arguments.training_project_root,
            arguments.loader_tide_model,
        )
        if any(value is not None for value in forbidden) or any(
            (
                arguments.smoke,
                arguments.allow_paid_evaluation,
                arguments.maximum_batches is not None,
            )
        ):
            raise SystemExit(
                "--aggregate accepts only --registry, --workers-root, and "
                "--output-root"
            )
        required = {
            "registry": arguments.registry,
            "workers_root": arguments.workers_root,
            "output_root": arguments.output_root,
        }
        missing = [name for name, value in required.items() if value is None]
        if missing:
            raise SystemExit("missing required arguments: " + ", ".join(missing))
        worker_directories = [
            arguments.workers_root
            / f"ZHD32-DUKF-DEV-EVAL-S{seed}-V1"
            / "attempt_001"
            for seed in (17, 29, 43)
        ]
        output = aggregate_completed_workers(
            worker_directories=worker_directories,
            output_root=arguments.output_root,
            registry_path=arguments.registry,
        )
        print(json.dumps({"status": "complete", "output": str(output)}, indent=2))
        return 0
    required = {
        "config": arguments.config,
        "registry": arguments.registry,
        "input_dir": arguments.input_dir,
        "training_attempt": arguments.training_attempt,
        "training_project_root": arguments.training_project_root,
        "loader_tide_model": arguments.loader_tide_model,
        "output_root": arguments.output_root,
    }
    missing = [name for name, value in required.items() if value is None]
    if missing:
        raise SystemExit("missing required arguments: " + ", ".join(missing))
    output = execute_seed_evaluation(
        config_path=arguments.config,
        registry_path=arguments.registry,
        input_dir=arguments.input_dir,
        training_attempt=arguments.training_attempt,
        training_project_root=arguments.training_project_root,
        tide_model_path=arguments.loader_tide_model,
        output_root=arguments.output_root,
        device=torch.device(arguments.device),
        allow_paid_evaluation=arguments.allow_paid_evaluation,
        maximum_batches=arguments.maximum_batches,
        smoke=arguments.smoke,
    )
    print(json.dumps({"status": "complete", "output": str(output)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
