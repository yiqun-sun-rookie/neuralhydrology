#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Pure statistics for the frozen 2023 development evaluation.

Inputs are block-level sufficient statistics only.  This module does not load
models or water-level data and has no interface for held-out targets.

Example:
    python -m pytest -p no:cacheprovider \
      tests/test_zhenjiang_d32_gru_differentiable_ukf_development_metrics_v1.py
"""

from __future__ import annotations

from collections import defaultdict
import math
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np


STATION_ORDER = (
    "datong",
    "nanjing",
    "zhenjiang",
    "jiangyin",
    "xuliujing",
    "wusongkou",
)
SEEDS = (17, 29, 43)
LEAD_HOURS = tuple(range(1, 24))
WINDOWS = {
    "primary_1_to_6": tuple(range(1, 7)),
    "secondary_1_to_12": tuple(range(1, 13)),
    "full_1_to_23": tuple(range(1, 24)),
}
BLOCK_ERROR_FIELDS = (
    "schema_version",
    "experiment_id",
    "seed",
    "block_id",
    "block_origin_count",
    "observed_station_index",
    "observed_station",
    "target_station_index",
    "target_station",
    "is_observed_target",
    "lead_hour",
    "cell_count",
    "assimilation_absolute_error_sum_m",
    "open_loop_absolute_error_sum_m",
    "assimilation_squared_error_sum_m2",
    "open_loop_squared_error_sum_m2",
    "target_sum_m",
    "target_squared_sum_m2",
)


def _as_bool(value: Any, name: str) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str) and value.lower() in {"true", "false"}:
        return value.lower() == "true"
    raise ValueError("%s must be Boolean" % name)


def _as_int(value: Any, name: str) -> int:
    if isinstance(value, bool):
        raise ValueError("%s must be an integer" % name)
    try:
        converted = int(value)
    except (TypeError, ValueError) as error:
        raise ValueError("%s must be an integer" % name) from error
    if isinstance(value, float) and value != converted:
        raise ValueError("%s must be an integer" % name)
    if isinstance(value, str) and str(converted) != value.strip():
        raise ValueError("%s must use canonical integer text" % name)
    return converted


def _as_float(value: Any, name: str) -> float:
    try:
        converted = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError("%s must be numeric" % name) from error
    if not math.isfinite(converted):
        raise ValueError("%s must be finite" % name)
    return converted


def _normalize_row(row: Mapping[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, Mapping) or set(row) != set(BLOCK_ERROR_FIELDS):
        raise ValueError("block error row schema drift")
    normalized = dict(row)
    if normalized["schema_version"] != "1.0":
        raise ValueError("block error schema version drift")
    experiment_id = normalized["experiment_id"]
    if not isinstance(experiment_id, str) or not experiment_id:
        raise ValueError("experiment identity is invalid")
    for name in (
        "seed",
        "block_id",
        "block_origin_count",
        "observed_station_index",
        "target_station_index",
        "lead_hour",
        "cell_count",
    ):
        normalized[name] = _as_int(normalized[name], name)
    normalized["is_observed_target"] = _as_bool(
        normalized["is_observed_target"], "is_observed_target"
    )
    for name in (
        "assimilation_absolute_error_sum_m",
        "open_loop_absolute_error_sum_m",
        "assimilation_squared_error_sum_m2",
        "open_loop_squared_error_sum_m2",
        "target_sum_m",
        "target_squared_sum_m2",
    ):
        normalized[name] = _as_float(normalized[name], name)

    seed = normalized["seed"]
    observed = normalized["observed_station_index"]
    target = normalized["target_station_index"]
    if seed not in SEEDS:
        raise ValueError("seed is outside the frozen set")
    if observed not in range(6) or target not in range(6):
        raise ValueError("station index is outside the frozen set")
    if (
        normalized["observed_station"] != STATION_ORDER[observed]
        or normalized["target_station"] != STATION_ORDER[target]
    ):
        raise ValueError("station identity does not match its index")
    if normalized["is_observed_target"] != (observed == target):
        raise ValueError("observed-target flag does not match station indices")
    if normalized["lead_hour"] not in LEAD_HOURS:
        raise ValueError("lead hour is outside 1 through 23")
    if normalized["block_id"] < 0:
        raise ValueError("block identifier must be nonnegative")
    if normalized["block_origin_count"] < 1 or normalized[
        "block_origin_count"
    ] > 168:
        raise ValueError("block origin count is outside 1 through 168")
    if normalized["cell_count"] != normalized["block_origin_count"]:
        raise ValueError("each block row must contain one cell per origin")
    for name in (
        "assimilation_absolute_error_sum_m",
        "open_loop_absolute_error_sum_m",
        "assimilation_squared_error_sum_m2",
        "open_loop_squared_error_sum_m2",
        "target_squared_sum_m2",
    ):
        if normalized[name] < 0.0:
            raise ValueError("nonnegative sufficient statistic is negative")
    cells = normalized["cell_count"]
    minimum_target_square = normalized["target_sum_m"] ** 2 / cells
    tolerance = 1e-10 * max(1.0, normalized["target_squared_sum_m2"])
    if normalized["target_squared_sum_m2"] + tolerance < minimum_target_square:
        raise ValueError("target sufficient statistics violate Cauchy inequality")
    return normalized


def validate_block_error_rows(
    rows: Iterable[Mapping[str, Any]],
) -> List[Dict[str, Any]]:
    """Return typed rows after strict schema, identity, and uniqueness checks."""

    normalized_rows = []
    seen = set()
    for source in rows:
        row = _normalize_row(source)
        key = (
            row["seed"],
            row["block_id"],
            row["observed_station_index"],
            row["target_station_index"],
            row["lead_hour"],
        )
        if key in seen:
            raise ValueError("duplicate block error row")
        seen.add(key)
        normalized_rows.append(row)
    if not normalized_rows:
        raise ValueError("block error rows must not be empty")
    return normalized_rows


def _sum_metrics(rows: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
    cells = sum(int(row["cell_count"]) for row in rows)
    if cells <= 0:
        raise ValueError("selected rows contain no cells")
    assimilation_absolute = sum(
        float(row["assimilation_absolute_error_sum_m"]) for row in rows
    )
    open_absolute = sum(
        float(row["open_loop_absolute_error_sum_m"]) for row in rows
    )
    assimilation_squared = sum(
        float(row["assimilation_squared_error_sum_m2"]) for row in rows
    )
    open_squared = sum(
        float(row["open_loop_squared_error_sum_m2"]) for row in rows
    )
    return {
        "cell_count": cells,
        "assimilation_absolute_error_sum_m": assimilation_absolute,
        "open_loop_absolute_error_sum_m": open_absolute,
        "assimilation_squared_error_sum_m2": assimilation_squared,
        "open_loop_squared_error_sum_m2": open_squared,
        "assimilation_mae_m": assimilation_absolute / cells,
        "open_loop_mae_m": open_absolute / cells,
        "assimilation_rmse_m": math.sqrt(assimilation_squared / cells),
        "open_loop_rmse_m": math.sqrt(open_squared / cells),
        "delta_assimilation_minus_open_loop_m": (
            assimilation_absolute - open_absolute
        )
        / cells,
        "gain_open_loop_minus_assimilation_m": (
            open_absolute - assimilation_absolute
        )
        / cells,
    }


def window_delta_from_rows(
    rows: Iterable[Mapping[str, Any]],
    lead_hours: Sequence[int],
    observed_station_index: int,
    seed: Optional[int] = None,
) -> Dict[str, Any]:
    """Compute a paired window result from total errors and total cells."""

    normalized = validate_block_error_rows(rows)
    lead_set = set(int(value) for value in lead_hours)
    selected = [
        row
        for row in normalized
        if row["observed_station_index"] == observed_station_index
        and row["lead_hour"] in lead_set
        and not row["is_observed_target"]
        and (seed is None or row["seed"] == seed)
    ]
    if not selected:
        raise ValueError("window contains no unobserved target cells")
    return _sum_metrics(selected)


def _group_rows(
    rows: Sequence[Mapping[str, Any]], names: Sequence[str]
) -> Mapping[Tuple[Any, ...], List[Mapping[str, Any]]]:
    groups = defaultdict(list)
    for row in rows:
        groups[tuple(row[name] for name in names)].append(row)
    return groups


def _target_metrics(rows: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
    result = _sum_metrics(rows)
    target_sum = sum(float(row["target_sum_m"]) for row in rows)
    target_squared = sum(float(row["target_squared_sum_m2"]) for row in rows)
    cells = result["cell_count"]
    target_sst = target_squared - target_sum * target_sum / cells
    tolerance = 1e-10 * max(1.0, target_squared)
    if target_sst < -tolerance:
        raise ValueError("aggregated target sufficient statistics are invalid")
    target_sst = max(0.0, target_sst)
    result.update(
        {
            "target_sum_m": target_sum,
            "target_squared_sum_m2": target_squared,
            "target_sst_m2": target_sst,
            "assimilation_nse": (
                1.0 - result["assimilation_squared_error_sum_m2"] / target_sst
                if target_sst > 0.0
                else None
            ),
            "open_loop_nse": (
                1.0 - result["open_loop_squared_error_sum_m2"] / target_sst
                if target_sst > 0.0
                else None
            ),
        }
    )
    return result


def summarize_point_metrics(
    rows: Iterable[Mapping[str, Any]],
    windows: Optional[Mapping[str, Sequence[int]]] = None,
) -> Dict[str, List[Dict[str, Any]]]:
    """Summarize every lead, preregistered window, condition, seed, and target."""

    normalized = validate_block_error_rows(rows)
    selected_windows = WINDOWS if windows is None else windows
    lead_rows = []
    unobserved = [row for row in normalized if not row["is_observed_target"]]
    for key, group in sorted(
        _group_rows(
            unobserved,
            ("seed", "observed_station_index", "lead_hour"),
        ).items()
    ):
        seed, observed, lead = key
        lead_rows.append(
            {
                "seed": seed,
                "observed_station_index": observed,
                "observed_station": STATION_ORDER[observed],
                "lead_hour": lead,
                **_sum_metrics(group),
            }
        )

    window_rows = []
    available_seeds = sorted({row["seed"] for row in normalized})
    available_conditions = sorted(
        {row["observed_station_index"] for row in normalized}
    )
    for seed in available_seeds:
        for observed in available_conditions:
            for window_name, lead_hours in selected_windows.items():
                lead_set = set(int(value) for value in lead_hours)
                group = [
                    row
                    for row in unobserved
                    if row["seed"] == seed
                    and row["observed_station_index"] == observed
                    and row["lead_hour"] in lead_set
                ]
                if not group:
                    continue
                window_rows.append(
                    {
                        "seed": seed,
                        "observed_station_index": observed,
                        "observed_station": STATION_ORDER[observed],
                        "window_name": window_name,
                        "lead_hour_start": min(lead_set),
                        "lead_hour_end": max(lead_set),
                        **_sum_metrics(group),
                    }
                )

    target_rows = []
    for key, group in sorted(
        _group_rows(
            normalized,
            (
                "seed",
                "observed_station_index",
                "target_station_index",
                "lead_hour",
            ),
        ).items()
    ):
        seed, observed, target, lead = key
        target_rows.append(
            {
                "seed": seed,
                "observed_station_index": observed,
                "observed_station": STATION_ORDER[observed],
                "target_station_index": target,
                "target_station": STATION_ORDER[target],
                "is_observed_target": target == observed,
                "lead_hour": lead,
                **_target_metrics(group),
            }
        )
    return {
        "lead_condition_seed_metrics": lead_rows,
        "window_condition_seed_metrics": window_rows,
        "target_station_lead_metrics": target_rows,
    }


def bootstrap_primary_gains(
    rows: Iterable[Mapping[str, Any]],
    repeat_count: int = 20000,
    seed: int = 20260828,
) -> Dict[str, Any]:
    """Run the frozen crossed seed/block paired bootstrap for six conditions."""

    if isinstance(repeat_count, bool) or not isinstance(repeat_count, int):
        raise ValueError("repeat count must be an integer")
    if repeat_count < 1:
        raise ValueError("repeat count must be positive")
    normalized = validate_block_error_rows(rows)
    primary = [
        row
        for row in normalized
        if not row["is_observed_target"] and row["lead_hour"] in range(1, 7)
    ]
    seeds = sorted({row["seed"] for row in primary})
    blocks = sorted({row["block_id"] for row in primary})
    conditions = sorted({row["observed_station_index"] for row in primary})
    if seeds != list(SEEDS):
        raise ValueError("bootstrap requires the three frozen seeds")
    if conditions != list(range(6)):
        raise ValueError("bootstrap requires all six observed-station conditions")
    if not blocks:
        raise ValueError("bootstrap requires at least one block")
    seed_position = {value: index for index, value in enumerate(seeds)}
    block_position = {value: index for index, value in enumerate(blocks)}
    shape = (len(seeds), len(blocks), 6)
    assimilation = np.zeros(shape, dtype=np.float64)
    open_loop = np.zeros(shape, dtype=np.float64)
    cells = np.zeros(shape, dtype=np.int64)
    present = np.zeros(shape, dtype=np.bool_)
    for row in primary:
        index = (
            seed_position[row["seed"]],
            block_position[row["block_id"]],
            row["observed_station_index"],
        )
        assimilation[index] += row["assimilation_absolute_error_sum_m"]
        open_loop[index] += row["open_loop_absolute_error_sum_m"]
        cells[index] += row["cell_count"]
        present[index] = True
    if not bool(present.all()) or bool((cells <= 0).any()):
        raise ValueError("primary bootstrap seed-block-condition grid is incomplete")

    generator = np.random.Generator(np.random.PCG64(seed))
    seed_draws = generator.integers(
        0, len(seeds), size=(repeat_count, len(seeds)), endpoint=False
    )
    block_draws = generator.integers(
        0, len(blocks), size=(repeat_count, len(blocks)), endpoint=False
    )
    condition_summaries = []
    condition_gain_arrays = []
    for condition in range(6):
        chosen_assimilation = assimilation[
            seed_draws[:, :, None], block_draws[:, None, :], condition
        ]
        chosen_open = open_loop[
            seed_draws[:, :, None], block_draws[:, None, :], condition
        ]
        chosen_cells = cells[
            seed_draws[:, :, None], block_draws[:, None, :], condition
        ]
        gains = (
            chosen_open.sum(axis=(1, 2))
            - chosen_assimilation.sum(axis=(1, 2))
        ) / chosen_cells.sum(axis=(1, 2))
        condition_gain_arrays.append(gains)
        point_gain = float(
            (open_loop[:, :, condition].sum() - assimilation[:, :, condition].sum())
            / cells[:, :, condition].sum()
        )
        lower, upper = np.quantile(gains, (0.025, 0.975))
        delta_upper = np.quantile(-gains, 0.95)
        condition_summaries.append(
            {
                "observed_station_index": condition,
                "observed_station": STATION_ORDER[condition],
                "point_gain_open_loop_minus_assimilation_m": point_gain,
                "point_delta_assimilation_minus_open_loop_m": -point_gain,
                "bootstrap_gain_mean_m": float(gains.mean()),
                "gain_two_sided_95_lower_m": float(lower),
                "gain_two_sided_95_upper_m": float(upper),
                "delta_one_sided_95_upper_m": float(delta_upper),
                "gain_one_sided_p_value": float(
                    (1 + np.count_nonzero(gains <= 0.0))
                    / (repeat_count + 1)
                ),
            }
        )

    stacked = np.stack(condition_gain_arrays, axis=1)
    macro_gains = stacked.mean(axis=1)
    macro_lower, macro_upper = np.quantile(macro_gains, (0.025, 0.975))
    point_macro_gain = float(
        np.mean(
            [
                row["point_gain_open_loop_minus_assimilation_m"]
                for row in condition_summaries
            ]
        )
    )
    return {
        "schema_version": "1.0",
        "sampling": {
            "repeat_count": repeat_count,
            "bit_generator": "PCG64",
            "seed": seed,
            "seed_draw_count": len(seeds),
            "block_draw_count": len(blocks),
            "shared_indices_across_conditions": True,
            "shared_indices_across_branches": True,
            "seed_values": seeds,
            "block_ids": blocks,
        },
        "condition_summaries": condition_summaries,
        "macro_summary": {
            "condition_count": 6,
            "point_gain_open_loop_minus_assimilation_m": point_macro_gain,
            "point_delta_assimilation_minus_open_loop_m": -point_macro_gain,
            "bootstrap_gain_mean_m": float(macro_gains.mean()),
            "gain_two_sided_95_lower_m": float(macro_lower),
            "gain_two_sided_95_upper_m": float(macro_upper),
            "delta_one_sided_95_upper_m": float(
                np.quantile(-macro_gains, 0.95)
            ),
            "gain_one_sided_p_value": float(
                (1 + np.count_nonzero(macro_gains <= 0.0))
                / (repeat_count + 1)
            ),
        },
    }


def holm_adjust_one_sided(
    p_values: Sequence[float], alpha: float = 0.05
) -> Tuple[List[float], List[bool]]:
    """Return Holm adjusted probabilities and step-down decisions."""

    if not p_values:
        raise ValueError("Holm family must not be empty")
    values = [_as_float(value, "p_value") for value in p_values]
    if any(value < 0.0 or value > 1.0 for value in values):
        raise ValueError("probability value is outside zero through one")
    if not math.isfinite(alpha) or alpha <= 0.0 or alpha >= 1.0:
        raise ValueError("alpha must be strictly between zero and one")
    order = sorted(range(len(values)), key=lambda index: (values[index], index))
    adjusted = [0.0] * len(values)
    running = 0.0
    for rank, original_index in enumerate(order):
        candidate = (len(values) - rank) * values[original_index]
        running = max(running, candidate)
        adjusted[original_index] = min(1.0, running)
    rejected = [False] * len(values)
    continue_rejecting = True
    for rank, original_index in enumerate(order):
        threshold = alpha / (len(values) - rank)
        current = continue_rejecting and values[original_index] <= threshold
        rejected[original_index] = current
        if not current:
            continue_rejecting = False
    return adjusted, rejected


def _holm_rows(
    condition_summaries: Sequence[Mapping[str, Any]], alpha: float = 0.05
) -> List[Dict[str, Any]]:
    p_values = [float(row["gain_one_sided_p_value"]) for row in condition_summaries]
    adjusted, rejected = holm_adjust_one_sided(p_values, alpha=alpha)
    order = sorted(range(len(p_values)), key=lambda index: (p_values[index], index))
    ranks = {original: rank + 1 for rank, original in enumerate(order)}
    result = []
    for condition, row in enumerate(condition_summaries):
        rank = ranks[condition]
        result.append(
            {
                "observed_station_index": condition,
                "observed_station": STATION_ORDER[condition],
                "family_order": condition + 1,
                "holm_rank": rank,
                "raw_one_sided_p_value": p_values[condition],
                "holm_threshold": alpha / (len(p_values) - rank + 1),
                "holm_adjusted_p_value": adjusted[condition],
                "holm_reject_no_improvement": rejected[condition],
            }
        )
    return result


def decide_development_gate(
    point_metrics: Mapping[str, Sequence[Mapping[str, Any]]],
    bootstrap_metrics: Mapping[str, Any],
    identity_gate: Any,
) -> Dict[str, Any]:
    """Apply the five frozen 2023 development gates mechanically."""

    window_rows = point_metrics.get("window_condition_seed_metrics", [])
    primary_rows = [
        row for row in window_rows if row.get("window_name") == "primary_1_to_6"
    ]
    if len(primary_rows) != 18:
        raise ValueError("development gate requires 18 primary condition-seed rows")
    keys = {
        (int(row["observed_station_index"]), int(row["seed"]))
        for row in primary_rows
    }
    if keys != {(condition, seed) for condition in range(6) for seed in SEEDS}:
        raise ValueError("primary condition-seed identity grid is incomplete")
    all_18 = all(
        float(row["delta_assimilation_minus_open_loop_m"]) < 0.0
        for row in primary_rows
    )
    condition_means = []
    for condition in range(6):
        values = [
            float(row["delta_assimilation_minus_open_loop_m"])
            for row in primary_rows
            if int(row["observed_station_index"]) == condition
        ]
        condition_means.append(
            {
                "observed_station_index": condition,
                "observed_station": STATION_ORDER[condition],
                "seed_count": len(values),
                "mean_delta_assimilation_minus_open_loop_m": float(
                    np.mean(values)
                ),
            }
        )
    all_6_means = all(
        row["mean_delta_assimilation_minus_open_loop_m"] < 0.0
        for row in condition_means
    )
    condition_bootstrap = bootstrap_metrics.get("condition_summaries", [])
    if len(condition_bootstrap) != 6 or [
        int(row.get("observed_station_index", -1)) for row in condition_bootstrap
    ] != list(range(6)):
        raise ValueError("bootstrap condition order is not the frozen order")
    holm_rows = _holm_rows(condition_bootstrap)
    all_holm = all(row["holm_reject_no_improvement"] for row in holm_rows)
    macro = bootstrap_metrics.get("macro_summary")
    if not isinstance(macro, Mapping):
        raise ValueError("bootstrap macro summary is missing")
    macro_upper = _as_float(
        macro.get("delta_one_sided_95_upper_m"),
        "macro delta one-sided upper",
    )
    macro_pass = macro_upper < 0.0
    if isinstance(identity_gate, Mapping):
        identity_details = {str(key): bool(value) for key, value in identity_gate.items()}
        identity_pass = bool(identity_details) and all(identity_details.values())
    else:
        identity_pass = bool(identity_gate)
        identity_details = {"identity_and_zero_target_access": identity_pass}
    gates = {
        "all_18_condition_seed_deltas_strictly_negative": all_18,
        "all_6_condition_seed_mean_deltas_strictly_negative": all_6_means,
        "all_6_holm_adjusted_one_sided_tests_reject_at_0_05": all_holm,
        "six_condition_macro_delta_one_sided_95_upper_strictly_negative": (
            macro_pass
        ),
        "identity_and_zero_target_access_gates_required": identity_pass,
    }
    if not identity_pass:
        status = "invalid_identity_or_target_access_stop"
    elif all(gates.values()):
        status = "pass_2023_development_candidate_for_test_contract"
    else:
        status = "fail_2023_primary_gate_stop_current_family"
    return {
        "schema_version": "1.0",
        "status": status,
        "primary_delta_definition": "assimilation_mae_m_minus_open_loop_mae_m",
        "primary_condition_seed_count": len(primary_rows),
        "primary_condition_means": condition_means,
        "holm_primary_family": holm_rows,
        "macro_delta_one_sided_95_upper_m": macro_upper,
        "identity_gate_details": identity_details,
        "gates": gates,
    }
