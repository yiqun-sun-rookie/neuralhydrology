# 镇江六站抽象状态数据同化路线：上下文重置交接

## 0. 文件身份

- 快照时间：`2026-08-28T11:24:31+08:00`。
- 项目根目录：`G:\github\pycharm\projects\zhenjiang_stage_forecast`。
- 本文件用途：为新任务提供唯一的上下文交接；它不是实验登记、运行授权或科学结论。
- 重置依据：`D:\obsidian\project_xibei\0 prompt\常用\重置上下文.md`，本次写入前重新计算的 SHA-256 为 `c90bd7532347a9c248f3b8d92efecee4cdd247d0ecc5cbc8e96458a427808c7`，与本轮首次读取一致。
- 判断：需要重置。原对话混合了文献创新、模型选择、门控循环单元基线、KalmanNet、可微无迹卡尔曼滤波、本地与集群计算等多条路线；继续依赖聊天记忆容易混淆“技术可运行”和“科学有效”。

## 1. 当前目标和阶段

### 1.1 总目标

建立一个六站联合的24小时水位预报系统：先由神经状态空间模型产生开放环预报，再只使用某一个站在预报后第1小时的实测水位，更新六站共享的32维抽象状态；随后第2至第24小时不再使用任何水位观测，检验这一次更新能否改善另外五个未被同化站的预报。

“一个站的观测改善其他站”可以成为论文贡献的一部分，但只有在严格无信息泄漏、与两个必要对照公平比较、多个站和多个随机种子稳定成立后，才是科学结果。当前没有这类效果证据。

### 1.2 当前阶段

- 已完成：确定并复核32维门控循环单元编码器—解码器基础模型；三个随机种子的2023年内部验证结果可追溯。
- 已选择的首个数据同化方向：可微无迹卡尔曼滤波（通过可微的无迹变换传播状态均值和协方差）。
- 尚未完成：32维可微无迹卡尔曼滤波适配器、专用实验登记、正式技术测试、真实数据训练、效果评价。
- 当前唯一合理推进动作：先冻结可复用数学来源和完整方法合同，再决定是否授权编写本地适配器。不能直接开始训练。

## 2. 已冻结的基础神经状态空间模型

### 2.1 模型接口

基础模型为 `PureGRUEncoderDecoder`，其中门控循环单元是一种带记忆的循环神经网络。它具有明确的一步状态转移接口，适合接入滤波器：

| 项目 | 已确认值 |
|---|---:|
| 历史输入 | 过去24小时 × 六站水位，形状 `[批量, 24, 6]` |
| 编码器隐藏维数 | 64 |
| 共享抽象状态维数 | 32 |
| 每一步过程控制 | 1个标准化天文潮值 |
| 状态转移 | 32维状态和1维控制映射到下一时刻32维状态 |
| 观测映射 | 32维抽象状态线性映射到六站水位 |
| 预报长度 | 24小时 |
| 已训练参数总数 | 19,462 |
| 32维无迹变换的 sigma 点数 | 65 |

这里的32维状态是由历史六站序列编码得到的共享抽象变量，不是六个站水位的直接拼接，也没有规定每一维具有物理含义。

站点固定顺序为：大通、南京、镇江、江阴、徐六泾、吴淞口；代码标识依次为 `datong, nanjing, zhenjiang, jiangyin, xuliujing, wusongkou`。

### 2.2 为什么当前选门控循环单元，而不是 Transformer、长短期记忆网络或 Mamba

- 事实：当前门控循环单元模型已经给出明确的“编码历史—一步受控状态转移—六站观测解码”接口，并在2023年内部验证上达到现有历史 Transformer 参照水平。
- 推断：这使门控循环单元成为当前最小、最可审计的数据同化基础，而不是证明它在所有模型中最好。
- Transformer 仍是历史性能参照；它不是“不能用”，但现有实现没有同样清楚的一步32维马尔可夫状态接口，改造会同时改变基础模型和数据同化方法，破坏首轮单变量比较。
- 长短期记忆网络可以提供显式隐藏状态，但当前没有证据表明它会优于已经合格且更小的门控循环单元；重训会增加无关变量。
- Mamba 是选择性状态空间序列模型，但本项目尚无同数据、同预算的基础结果和已验证的一步受控接口；当前切换没有证据收益。

## 3. 首个可微无迹卡尔曼滤波合同

### 3.1 唯一方法变量

首轮只改变“是否在预报后第1小时用一个站的观测更新共享抽象状态”。基础模型、输入、数据划分、检查点、未来天文潮控制和第2至第24小时的开环传播均保持不变。

必须同时包含三个分支：

1. 确定性开放环：直接传播状态均值，不建立 sigma 点，不使用第1小时观测。
2. 无迹先验对照：使用65个 sigma 点经过非线性门控循环单元状态转移并重组均值和协方差，但不使用第1小时观测。
3. 可微无迹卡尔曼更新：与第2项具有同一个无迹先验，再用一个指定站第1小时的标量观测更新32维共享状态。

第2项不能省略。非线性状态转移一般满足“sigma 点传播后的加权均值不等于状态均值直接传播”；如果只比较第1项和第3项，无法把无迹传播本身的差异与观测更新的差异分开。

### 3.2 首版拟定结构

- 冻结19,462个基础模型参数。
- 初始状态协方差 `P0` 固定；具体数值尚未冻结。
- 过程噪声协方差 `Q` 先限制为32维对角阵，共32个待学习正值。
- 观测噪声协方差 `R` 先使用六个站各自的标量正值，共6个待学习值。
- 数据同化新增待学习参数合计38个；该数值仅在上述对角合同不变时成立。
- 状态转移使用65个 sigma 点经过现有门控循环单元过程映射。
- 六站观测解码器是线性的；首版应选取被观测站对应的权重行做精确线性观测更新，不需要再对观测映射做一次无迹变换。
- 每个样本显式输入并返回状态均值和协方差；一个样本的缺测值不能污染同批次其他样本。
- 数值实现候选为 `torch.linalg.solve`、Joseph 形式协方差更新和可微谱下限；具体稳定化阈值尚未冻结。
- 只在第1小时更新一次；第2至第24小时严格开放环。不得在后续时刻偷偷使用真实水位。

### 3.3 尚未冻结，禁止擅自补设

- `P0` 的数值或估计方法。
- 无迹变换的 `alpha`、`beta`、`kappa`。
- 协方差谱下限、抖动量和数值失败规则。
- 38个参数是联合训练、分阶段训练还是校准。
- 优化器、学习率、批量大小、训练轮数、早停条件和随机种子。
- 训练损失按站、按预报时刻如何聚合。
- 六种“被观测站”条件是共享一套参数还是分别标定。
- 科学成功所需的最小改善幅度、统计检验和多随机种子通过门槛。
- 正式实验标识。

这些选择会改变实验含义，必须先登记并由用户明确批准。

## 4. 数据、划分和禁止信息泄漏边界

### 4.1 当前数据合同

- 输入数据目录：`G:\github\pycharm\projects\zhenjiang_stage_forecast\data\processed\water_level_model_input_v7_beijing_realtime_verified`。
- 训练年份：2017—2022年，共46,182个样本。
- 内部验证年份：2023年，共8,046个样本。
- 2024年及以后为保留目标；当前三个基础运行的保留目标读取、解析和载入计数均为0。
- 六站训练损失当前完全等权：`1, 1, 1, 1, 1, 1`，没有给镇江站双倍权重。
- 输入使用原始实时观测，目标使用回溯质量控制序列，不使用天气变量。

### 4.2 已知数据限制

- 文件时区按用户说明视为北京时间，但现有文件没有逐文件时区证据。
- 历史数据是否在相应预报时刻已经发布到分钟级，尚未验证。
- 第1小时同化观测在真实业务中的到达时间、质量控制状态和缺测规则尚未形成冻结合同。

### 4.3 严格禁区

- 在正式解封前不得读取、解析、载入或评价2024年及以后目标。
- 不得用第2至第24小时真实水位构造状态、选择参数、早停或筛选事件。
- 2023年已经参与模型和最佳轮次选择，只能称内部验证，不能称独立测试。
- 若以后端到端微调基础模型，必须另设同信息、同训练预算的重新训练对照；不能与冻结基础模型的开放环结果直接混比。

## 5. 当前有效结果

### 5.1 三个基础检查点

三个检查点均已在中央处理器上通过登记加载器严格加载；状态维数32、控制维数1、观测维数6和参数总数19,462一致，未读取水位数据，也未训练。

| 随机种子 | 最佳轮次 | 2023年平均绝对误差（米） | 六站平均纳什—萨特克利夫效率系数 | 最差站效率系数 |
|---:|---:|---:|---:|---:|
| 17 | 33 | 0.07434232367447623 | 0.9852644266912459 | 0.9723503367785107 |
| 29 | 35 | 0.07387378959296310 | 0.9852044026980726 | 0.9716550214033673 |
| 43 | 36 | 0.07243462732244876 | 0.9860176032763511 | 0.9730389173231855 |

三随机种子汇总：

- 平均绝对误差均值 `0.07355024686329603` 米，样本标准差 `0.000994151027925354` 米。
- 六站平均纳什—萨特克利夫效率系数均值 `0.9854954775552232`，样本标准差 `0.00045316903185965246`。
- 最差站效率系数均值 `0.9723480918350211`；跨随机种子的最低最差站效率系数为 `0.9716550214033673`。

历史固定六站河道顺序注意力模型在同一2023年验证资料上的参照是平均绝对误差 `0.0787320739401316` 米、六站平均纳什—萨特克利夫效率系数 `0.984192691450888`。当前门控循环单元汇总相对它的差值是平均绝对误差降低 `0.005181827076835566` 米、效率系数提高 `0.0013027861043352074`。这只是内部验证比较，不是独立测试结论。

已知报告问题：三个摘要中的 `equal_station_hour_rmse_m` 是144个“站点 × 预报时刻”分组均方根误差的算术平均，不是全部误差的总体均方根。由现有明细重构的总体均方根误差依次为 `0.108003503986610`、`0.108144621254418`、`0.105849726645168` 米。当前权威基础门槛以平均绝对误差和纳什—萨特克利夫效率系数为准。

### 5.2 这些结果不证明什么

它们不证明可微无迹卡尔曼滤波有效，不证明同化一个站可以改善其他五站，不证明极端水位、独立年份或业务预报有改善，也不支持论文创新或发表结论。

## 6. 已暂停、否决或仅供参考的路线

### 6.1 32维 KalmanNet 学习增益网络

KalmanNet 是用大型循环网络直接学习滤波增益的模型。当前技术包装器只完成过接口验证：核心新增可训练参数为27,110,748，是19,462参数基础模型的 `1393.00935155688` 倍，而且只服务一次第1小时更新。现有登记状态仅为 `technical_interface_only`，正式训练、保留测试评价、科学结论和付费计算均未授权。

结论：保留现有产物，不删除；暂停为首个数据同化路线。其技术通过不等于效果通过。

### 6.2 历史12维神经状态空间数据同化模型

`zhenjiang_neural_state_space_da_v1.py` 的总体模型把部分状态坐标直接绑定到站点水位，不符合当前“共享抽象状态”的要求；不能把它作为当前基础模型。文件中的通用无迹预测矩、动态缺测掩码、线性求解和 Joseph 协方差代码可以在来源冻结后按隔离模块审查，但现有元数据明确表示无迹组件未接入默认模型。

### 6.3 sibling 仓库的可微无迹卡尔曼滤波桥接器

`kalmannet` 仓库的通用桥接器能处理可配置状态和观测维数，但不能直接作为正式依赖：

- 控制输入只能由闭包捕获，没有明确接口。
- 没有按样本的部分缺测掩码；一个 `NaN` 观测会使该样本状态变为非有限值。
- `adapter` 参数未实际参与计算，现场反向传播得到其参数梯度数为0。
- 它依赖另一个具有未提交修改的 `filters` 工作树。
- 外部“full”协方差选项实际仍产生对角阵；批量核心使用显式逆矩阵，且更新后没有强制对称或正定。

结论：可以作为阅读参考，不能直接导入或宣称复现。

## 7. 精确证据和 SHA-256

### 7.1 当前项目基础代码与登记

| 文件 | SHA-256 |
|---|---|
| `G:\github\pycharm\projects\zhenjiang_stage_forecast\scripts\modeling\zhenjiang_pure_gru_encoder_decoder_v1.py` | `d1156e5f964dafa2c97f2fb649bb0b040364323dca00fab4774b390a182f3f1c` |
| `G:\github\pycharm\projects\zhenjiang_stage_forecast\scripts\modeling\train_zhenjiang_pure_gru_encoder_decoder_v1.py` | `cedbb6aa9779150d4ac2e764f10d1d9ca0e4b14a5332f691415f1842497eaa7f` |
| `G:\github\pycharm\projects\zhenjiang_stage_forecast\docs\records\ZHENJIANG_PURE_GRU_EQUAL_STATION_V1_EXPERIMENT_REGISTRY.json` | `f1a8285ed308be036cccb1a68a78d147a3ce0e814be1500b139fae4a5b476b6a` |
| `G:\github\pycharm\projects\zhenjiang_stage_forecast\docs\records\ZHENJIANG_PURE_GRU_EQUAL_STATION_V1_RESULT_2026-08-27.md` | `4e3a589bfa022afd32178da96a6d7f1373f971d16bacce4f9df6a35b3694bfef` |
| `G:\github\pycharm\projects\zhenjiang_stage_forecast\results\modeling\zhenjiang_pure_gru_equal_station_v1_multiseed_confirmation_20260827\multiseed_confirmation.json` | `26243454d0ee0c1a49030292bbdb67c14c7bc2e1116fff104c44490c4bdc5a01` |
| `G:\github\pycharm\projects\zhenjiang_stage_forecast\results\modeling\zhenjiang_pure_gru_equal_station_v1_multiseed_confirmation_20260827\multiseed_confirmation.csv` | `9c3ab6b749b80f565f6c9c1bf219a675f87122b7ff5922e4a6196dfe9d55bf65` |
| `G:\github\pycharm\projects\zhenjiang_stage_forecast\data\processed\water_level_model_input_v7_beijing_realtime_verified\dataset_config.json` | `63b2d3a33b249e1f598db2a1ffb2096c9d9006b366e4e913d594f74a6881d492` |

### 7.2 三个基础检查点

| 随机种子 | 检查点 | SHA-256 |
|---:|---|---|
| 17 | `G:\github\pycharm\projects\zhenjiang_stage_forecast\results\modeling\zhenjiang_pure_gru_equal_station_v1\ZPGRU-EQUAL-S17-D32\best_checkpoint.pt` | `f2bdb6b32a9a5f7bcee312591d4bd832df1f19140d9b0b49775ef5d7db71e670` |
| 29 | `G:\github\pycharm\projects\zhenjiang_stage_forecast\results\modeling\zhenjiang_pure_gru_equal_station_v1\ZPGRU-EQUAL-S29-D32\best_checkpoint.pt` | `ac3c02b46f2a810ac68cf194c87a9088abd2619bfbb50a9dfd1d93a4d68f3172` |
| 43 | `G:\github\pycharm\projects\zhenjiang_stage_forecast\results\modeling\zhenjiang_pure_gru_equal_station_v1\ZPGRU-EQUAL-S43-D32\best_checkpoint.pt` | `d63194dc2c9ad3a7279c586a3ef69cac58bfb1210457578750b86a466dc3ae6a` |

### 7.3 当前项目的数据同化参考代码

| 文件 | 身份 | SHA-256 |
|---|---|---|
| `G:\github\pycharm\projects\zhenjiang_stage_forecast\scripts\modeling\zhenjiang_neural_state_space_da_v1.py` | 历史12维模型；只可隔离参考数学模块 | `449e1903c83def4b44e1fa10f279f1c74d04ff7632864047ddc1921c2b5a221d` |
| `G:\github\pycharm\projects\zhenjiang_stage_forecast\tests\test_zhenjiang_neural_state_space_da_v1.py` | 历史12维模型测试 | `a87276e1c70823403bce21741ebb89b1b9772f8f97d756aedc4d781aea8c1fc4` |
| `G:\github\pycharm\projects\zhenjiang_stage_forecast\scripts\modeling\zhenjiang_d32_gru_kalmannet_online_v1.py` | 32维 KalmanNet 包装器，不是无迹滤波器 | `6a08a4ee18066d7873e483e129b97f777701cad6d19d4d098c1d2d3b859fb0d5` |
| `G:\github\pycharm\projects\zhenjiang_stage_forecast\scripts\modeling\zhenjiang_d32_gru_kalmannet_online_data_v1.py` | 32维 KalmanNet 在线数据接口 | `091ed9444e6286c3e26cfdcbea6ab23281831c8badf7287e2beca0915b9f3a05` |
| `G:\github\pycharm\projects\zhenjiang_stage_forecast\docs\records\ZHENJIANG_D32_GRU_KALMANNET_ONLINE_V1_EXPERIMENT_REGISTRY.json` | 仅技术接口登记，不授权新滤波器训练 | `0d251b7deb5566039a67e4b6b99622441cce3c6b74e789ee3dbdcd4114d85793` |
| `G:\github\pycharm\projects\zhenjiang_stage_forecast\docs\records\ZHENJIANG_D32_GRU_KALMANNET_ONLINE_V1_TECHNICAL_INTERFACE_RESULT_2026-08-27.md` | KalmanNet 技术接口结果 | `c5b08e7d026c163ac2a02f476e1576a34e1176b53fb4bea0c104e2c83aec95aa` |

现有32维 KalmanNet 技术审计 `attempt_002` 的审计和完成清单哈希分别为 `523d97efbcdb1b2d89e366e78ef291cfe447dca46e3bf1d513ecc546a4dcac4f` 与 `7c7f27cc4d41cc804a7f92a4e420d755ab7ee64d63abb16e71545f251920c744`。它通过的是283项接口测试，未运行正式训练、未调用数据加载器、保留目标读取为0；不能当作数据同化有效性证据。

### 7.4 只读 sibling 参考来源

| 文件 | 状态与限制 | SHA-256 |
|---|---|---|
| `G:\github\pycharm\projects\kalmannet\src\latent_da\da\ukf_bridge.py` | 通用桥接器；目标路径相对索引干净，但接口和缺测处理不满足本项目 | `69e620673cbe0369bb6bc9c09f7eb97ba9654f863ed5b778583a0e0812d0bd7f` |
| `G:\github\pycharm\projects\kalmannet\scripts\differentiable_ukf_hbvlite.py` | 可微 sigma 点和谱稳定参考；硬编码三维水文控制、标量观测 | `5d4d0fce3018aef42d6ef81ac32fa97541654f0a878c0508f5594ff2ec73c02d` |
| `G:\github\pycharm\projects\filters\filters\adapt_trainable_kf\adaptive_cov.py` | Git 状态 `A`，不能作为冻结依赖 | `861caf655a8bb7c5c6ce12c4345c69cabd6ad2a984a80f5be6789de98703f712` |
| `G:\github\pycharm\projects\filters\filters\adapt_trainable_kf\adaptive_ukf.py` | Git 状态 `AM`，不能作为冻结依赖 | `17d10d8f250de694f5fcd4f68a65b6fb803c921f2838b7165f95b3abfc3d3c8f` |
| `G:\github\pycharm\projects\filters\filters\filter\batch\my_version\batch_unscentedkalmanfilter_gpu.py` | Git 状态 `AM`，不能作为冻结依赖 | `05a9475262dca35db50a071a252024f25606585db79a5d165a28f4a11962a78b` |

`kalmannet` 当时的 Git 提交为 `07f44006947284fb4b2891345e2f7b28a4d428f7`，仓库整体存在其他改动；`filters` 当时的 Git 提交为 `d491ef1c617a4bd82c8d04346d6e4d6d6f26d599`，上述关键实现有新增或未暂存改动。所有 sibling 仓库只读，禁止修改。

## 8. 现场技术检查的证据等级

本轮曾执行不训练的终端级检查：历史12维原型测试为21项通过，sibling 校正数学核心为8项通过，通用桥接器为5项通过并有2个警告；合成32维状态能够生成65个 sigma 点并产生有限输出和梯度。另一次合成检查发现通用桥接器遇到单个 `NaN` 观测会污染对应样本。

这些检查没有写入当前项目的正式日志或完成清单，因此只能用于确定下一步设计，不能在论文、登记结果或正式“通过”判断中引用。以后若获准实现，必须在当前项目内用固定脚本、固定配置、日志和清单重新运行。

## 9. 权限、成功标准和停止条件

### 9.1 当前权限

- 允许：新任务首轮只读核对本文件与现场状态的差异。
- 当前不允许：修改代码或配置、建立正式实验、运行训练、评价保留目标、使用付费集群、写科学结论。
- 现有 KalmanNet 登记不能授权可微无迹卡尔曼滤波，也不能分配其正式实验标识；若继续，必须新建独立登记并获得用户明确批准。

### 9.2 技术通过的最低条件

技术通过必须至少同时满足：

1. 三个登记检查点仍按哈希严格加载，且基础模型参数全程冻结、文件哈希不变。
2. 32维均值、32×32协方差、1维控制、六站观测和六站可用性掩码的批量形状均有测试。
3. 每个时刻生成65个 sigma 点；正向、反向、状态均值和协方差均为有限值。
4. 协方差在更新后保持对称，并达到预先登记的最小特征值标准。
5. 六种单站观测选择逐一通过；缺测和 `NaN` 被掩码隔离，不能污染其他样本。
6. 禁用观测更新时与无迹先验对照完全一致；不能拿它冒充确定性开放环。
7. 第2至第24小时没有任何真实水位访问；2024年及以后目标访问计数保持0。
8. 技术日志、配置、环境、哈希和完成清单均写入隔离输出目录。

技术通过只表示实现符合合同，不表示预报改善。

### 9.3 科学成功目前无法确定

主要科学评价对象应是：在给定一个站第1小时观测后，另外五站第2至第24小时相对两个对照的误差变化。被同化站自身的改善只能作为次要结果。

目前没有冻结最小效果阈值、统计检验或允许退化范围，因此无法判定未来多大的改善才算科学成功。正式运行前必须先登记这些门槛；不得看完结果后补写。

### 9.4 立即停止条件

- 任何保留目标被读取、解析、载入或用于决策。
- 基础检查点、数据配置或来源文件哈希与本文件不符且原因未查明。
- 依赖未冻结的 sibling 工作树或隐藏可变滤波状态。
- 后续时刻真实水位进入第2至第24小时传播。
- 出现非有限值、非对称协方差、未处理的非正定协方差或梯度断裂。
- 尝试把技术通过、单站自身改善或2023年内部验证写成科学成功。
- 未授权地启动正式训练、扩大实验范围或使用付费集群。

## 10. 仓库、环境和运行状态

- 当前项目目录没有 `.git`，`git rev-parse` 和 `git status` 均返回 `fatal: not a git repository`。因此不能依靠 Git 回退，也不能区分已提交与未提交文件；所有现有文件都按用户文件保护，不覆盖、不清理。
- 本轮环境：Python `3.11.5`、PyTorch `2.2.2`、CUDA `12.1`，一张 NVIDIA GeForce RTX 4070 Ti 可见。这只是当前终端环境，不是未来可微无迹卡尔曼滤波的冻结环境。
- 进程快照中没有属于 `zhenjiang_stage_forecast` 的 Python 进程。
- 同一台本机当时有4个属于 `G:\github\pycharm\projects\kalmannet` 的正式训练相关进程，涉及进程号38476、38972、21728、37252。机器已被其他研究训练占用；不要启动本地训练或重计算。
- 用户曾提供集群说明：`G:\github\pycharm\projects\neuralhydrology\docs\hpc\HPC\_AGENT_GUIDE.md` 和 `G:\github\pycharm\projects\neuralhydrology\docs\hpc\HPC\_PLAYBOOK.md`。只有用户以后明确授权正式训练和付费计算时才可读取并按其执行；当前不得把集群当作默认后备。

## 11. 事实、推断和未知汇总

### 已确认事实

- 基础模型是32维共享抽象状态、1维天文潮控制、六维水位输出的门控循环单元编码器—解码器。
- 三个基础检查点存在、哈希匹配、能够严格加载；2023年内部验证结果可追溯。
- 当前项目没有32维可微无迹卡尔曼滤波正式适配器或登记。
- 32维状态对应65个 sigma 点。
- 现有32维数据同化包装器是 KalmanNet 学习增益，不是无迹卡尔曼滤波。
- 当前项目不是 Git 仓库；关键 sibling 滤波器来源不是可直接信任的干净冻结依赖。

### 有证据支持的推断

- 当前门控循环单元比重新训练长短期记忆网络、改造 Transformer 或引入 Mamba 更适合作为首轮最小变量基础。
- 最安全的实现路线是在当前项目本地组合经过审查的无迹数学、动态缺测掩码和线性观测更新，而不是直接导入 sibling 桥接器。
- 必须增加“无迹先验但不观测”的对照，才能分离无迹传播和观测更新的贡献。

### 当前未知

- 可微无迹卡尔曼滤波是否比开放环或无迹先验对照更准确。
- 同化任意一个站是否能稳定改善其他五站，以及改善在哪些站、时刻和事件成立。
- 32维抽象状态的可同化性、协方差可识别性和数值稳定范围。
- 最优或可接受的 `P0/Q/R`、无迹参数、训练方案和科学门槛。
- 2024年及以后独立表现、极端过程表现、统计显著性和论文创新性。

## 12. 唯一下一步和新任务首查

### 12.1 唯一下一步

先做一次只读差异审计：复核本文件列出的当前项目关键哈希、sibling 来源身份、进程和权限是否仍然成立。若无差异，向用户报告“没有差异”，并等待用户决定是否授权建立独立的可微无迹卡尔曼滤波登记和技术适配器。首轮不得写代码、改配置或运行实验。

### 12.2 首先完整阅读的文件

1. 本文件。
2. `G:\github\pycharm\projects\zhenjiang_stage_forecast\AGENTS.md`（若存在）。
3. `G:\github\pycharm\projects\zhenjiang_stage_forecast\docs\records\ZHENJIANG_PURE_GRU_EQUAL_STATION_V1_EXPERIMENT_REGISTRY.json`。
4. `G:\github\pycharm\projects\zhenjiang_stage_forecast\docs\records\ZHENJIANG_PURE_GRU_EQUAL_STATION_V1_RESULT_2026-08-27.md`。
5. `G:\github\pycharm\projects\zhenjiang_stage_forecast\scripts\modeling\zhenjiang_pure_gru_encoder_decoder_v1.py`。
6. `G:\github\pycharm\projects\zhenjiang_stage_forecast\scripts\modeling\zhenjiang_neural_state_space_da_v1.py`，只核对可复用数学模块和已拒绝的12维总体设计边界。
7. `G:\github\pycharm\projects\kalmannet\src\latent_da\da\ukf_bridge.py` 和 `G:\github\pycharm\projects\kalmannet\scripts\differentiable_ukf_hbvlite.py`，严格只读。

### 12.3 首轮允许的只读命令

```powershell
Get-FileHash -Algorithm SHA256 -LiteralPath <本文件列出的关键路径>
Get-Content -Raw -LiteralPath <待核对的文本文件>
rg -n "unscented|sigma|covariance|KalmanNet|connected_to_default_model" scripts/modeling tests docs/records
git -C G:\github\pycharm\projects\kalmannet status --short -- <精确目标路径>
git -C G:\github\pycharm\projects\filters status --short -- <精确目标路径>
Get-CimInstance Win32_Process
```

不得把仓库范围的全量未跟踪文件扫描当作必要首查；路径过长会产生噪声。只检查本文件列出的精确路径。
