#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Materialize only the registered 2017--2023 byte prefixes for HPC use.

The source may contain later rows, but this program never requests a byte past
the frozen prefix length.  It never discovers target files dynamically.  The
destination and its ``.partial`` staging directory must both be absent.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
from typing import Mapping, Optional, Sequence, Tuple


PROJECT_ROOT = Path(__file__).resolve().parents[2]
MODELING_DIR = PROJECT_ROOT / "scripts" / "modeling"
if str(MODELING_DIR) not in sys.path:
    sys.path.insert(0, str(MODELING_DIR))

from water_level_joint_encoder_decoder_v2 import (  # noqa: E402
    EXPECTED_INPUT_CONTENT_IDENTITIES,
)


MAXIMUM_TARGET_TIME_BEIJING = "2023-12-31T23:00:00+08:00"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb", buffering=0) as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def copy_exact_registered_bytes(
    source: Path,
    destination: Path,
    expected_byte_count: int,
    expected_sha256: str,
) -> Mapping[str, object]:
    """Copy exactly ``expected_byte_count`` bytes and publish after hashing."""

    source = Path(source)
    destination = Path(destination)
    partial = destination.with_name(destination.name + ".partial")
    if not source.is_file() or source.is_symlink():
        raise ValueError(f"source must be a regular file: {source}")
    if destination.exists() or partial.exists():
        raise FileExistsError(f"destination or partial already exists: {destination}")
    if (
        type(expected_byte_count) is not int
        or expected_byte_count < 1
        or not isinstance(expected_sha256, str)
        or len(expected_sha256) != 64
    ):
        raise ValueError("registered byte identity is invalid")
    destination.parent.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256()
    remaining = expected_byte_count
    with source.open("rb", buffering=0) as source_handle, partial.open(
        "xb", buffering=0
    ) as destination_handle:
        while remaining:
            block = source_handle.read(min(1024 * 1024, remaining))
            if not block:
                raise RuntimeError("source ended before the registered prefix")
            destination_handle.write(block)
            digest.update(block)
            remaining -= len(block)
        destination_handle.flush()
        os.fsync(destination_handle.fileno())
    observed_sha256 = digest.hexdigest()
    if observed_sha256 != expected_sha256:
        raise RuntimeError("registered prefix identity mismatch")
    os.replace(str(partial), str(destination))
    return {
        "byte_count": expected_byte_count,
        "sha256": observed_sha256,
    }


def _safe_relative_path(value: str) -> Path:
    relative = Path(value)
    if relative.is_absolute() or ".." in relative.parts or not relative.parts:
        raise ValueError(f"registered relative path is invalid: {value}")
    return relative


def materialize_pre2024_input(
    source_input_directory: Path,
    destination_input_directory: Path,
    *,
    expected_identities: Optional[
        Mapping[str, Tuple[str, int, str]]
    ] = None,
) -> Path:
    """Build one physically isolated input directory and immutable manifest."""

    source_root = Path(source_input_directory).resolve()
    destination = Path(destination_input_directory).resolve()
    partial = destination.with_name(destination.name + ".partial")
    if not source_root.is_dir() or source_root.is_symlink():
        raise ValueError("source input directory must be a regular directory")
    if destination.exists() or partial.exists():
        raise FileExistsError("destination or partial input directory exists")
    identities = (
        EXPECTED_INPUT_CONTENT_IDENTITIES
        if expected_identities is None
        else expected_identities
    )
    if not isinstance(identities, Mapping) or not identities:
        raise ValueError("expected input identities are empty")
    partial.mkdir(parents=True)
    rows = []
    try:
        for relative_text, identity in identities.items():
            relative = _safe_relative_path(relative_text)
            if not isinstance(identity, tuple) or len(identity) != 3:
                raise ValueError("registered input identity row is invalid")
            scope, expected_bytes, expected_hash = identity
            if scope not in {"full_file", "header_plus_61344_rows"}:
                raise ValueError("registered verification scope is invalid")
            source = source_root / relative
            if scope == "full_file" and source.stat().st_size != expected_bytes:
                raise RuntimeError("registered full-file byte count mismatch")
            copied = copy_exact_registered_bytes(
                source,
                partial / relative,
                expected_bytes,
                expected_hash,
            )
            if scope == "header_plus_61344_rows":
                final_line = (partial / relative).read_bytes().splitlines()[-1]
                if not final_line.startswith(
                    MAXIMUM_TARGET_TIME_BEIJING.encode("ascii") + b","
                ):
                    raise RuntimeError("registered prefix does not end in 2023")
            rows.append(
                {
                    "path": relative.as_posix(),
                    "verification_scope": scope,
                    "byte_count": copied["byte_count"],
                    "sha256": copied["sha256"],
                }
            )
        manifest = {
            "schema_version": "1.0",
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "source_input_directory": str(source_root),
            "destination_input_directory": str(destination),
            "maximum_target_time_beijing": MAXIMUM_TARGET_TIME_BEIJING,
            "later_target_bytes_requested": 0,
            "file_count": len(rows),
            "files": rows,
        }
        manifest_path = partial / "pre2024_input_manifest.json"
        manifest_path.write_text(
            json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
            newline="\n",
        )
        os.replace(str(partial), str(destination))
    except Exception:
        failure_path = partial / "materialization_failure.json"
        if partial.is_dir() and not failure_path.exists():
            failure_path.write_text(
                json.dumps(
                    {
                        "status": "failed_incomplete",
                        "maximum_target_time_beijing": (
                            MAXIMUM_TARGET_TIME_BEIJING
                        ),
                        "later_target_bytes_requested": 0,
                    },
                    indent=2,
                )
                + "\n",
                encoding="utf-8",
                newline="\n",
            )
        raise
    verify_materialized_input(destination)
    return destination


def verify_materialized_input(destination_input_directory: Path):
    """Recompute the explicit manifest without discovering extra data files."""

    destination = Path(destination_input_directory).resolve()
    manifest_path = destination / "pre2024_input_manifest.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise RuntimeError("pre-2024 input manifest cannot be read") from error
    if (
        manifest.get("maximum_target_time_beijing")
        != MAXIMUM_TARGET_TIME_BEIJING
        or manifest.get("later_target_bytes_requested") != 0
        or manifest.get("file_count") != len(manifest.get("files", []))
    ):
        raise RuntimeError("pre-2024 input manifest contract changed")
    for row in manifest["files"]:
        relative = _safe_relative_path(row.get("path", ""))
        path = destination / relative
        if (
            not path.is_file()
            or path.is_symlink()
            or path.stat().st_size != row.get("byte_count")
            or _sha256(path) != row.get("sha256")
        ):
            raise RuntimeError("materialized input identity mismatch")
    return {
        "status": "verified_pre2024_only",
        "verified_file_count": manifest["file_count"],
        "manifest_sha256": _sha256(manifest_path),
    }


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-input-dir", type=Path)
    parser.add_argument("--destination-input-dir", type=Path)
    parser.add_argument("--verify-output", type=Path)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    arguments = _parser().parse_args(argv)
    if arguments.verify_output is not None:
        if (
            arguments.source_input_dir is not None
            or arguments.destination_input_dir is not None
        ):
            raise SystemExit("--verify-output must be used alone")
        print(
            json.dumps(
                verify_materialized_input(arguments.verify_output), indent=2
            )
        )
        return 0
    if arguments.source_input_dir is None or arguments.destination_input_dir is None:
        raise SystemExit("source and destination input directories are required")
    output = materialize_pre2024_input(
        arguments.source_input_dir, arguments.destination_input_dir
    )
    print(json.dumps({"status": "complete", "output": str(output)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

