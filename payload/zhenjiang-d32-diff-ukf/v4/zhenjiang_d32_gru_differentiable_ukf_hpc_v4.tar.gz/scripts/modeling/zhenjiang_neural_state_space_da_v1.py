#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Explicit neural state-space data assimilation for the six gauges.

Inputs:
    Standardized hourly levels ``[batch, history_hour, 6]``, a matching
    observation-availability mask, known historical forcing, and forcing known
    for the 1--24 hour forecast horizon.  The intended forcing is astronomical
    tide and its one-hour change; no future measured water level is accepted.

Outputs:
    Posterior 12-dimensional state means/covariances through the history and
    open-loop six-station forecast means/covariances after the issue time.

State contract:
    Coordinates 0--5 are the standardized latent true levels in fixed river
    order.  Coordinates 6--11 are unobserved station-local trend-like
    propagation-memory coordinates; the code does not identify them as physical
    velocity or as an exact one-hour level difference.
    Missing observations remove rows from the update; they are never replaced
    by zero, interpolation, or a pseudo-observation.

Example:
    python scripts/modeling/zhenjiang_neural_state_space_da_v1.py --describe

This is an isolated architecture prototype.  It does not load data, train a
model, or modify the frozen six-station experiment route.
"""

from __future__ import annotations

import argparse
import json
import math
from typing import Dict

import torch
from torch import nn


STATION_ORDER = (
    "datong",
    "nanjing",
    "zhenjiang",
    "jiangyin",
    "xuliujing",
    "wusongkou",
)
STATION_COUNT = len(STATION_ORDER)
STATE_DIMENSION = 2 * STATION_COUNT
LEVEL_STATE_SLICE = slice(0, STATION_COUNT)
PROPAGATION_MEMORY_STATE_SLICE = slice(STATION_COUNT, STATE_DIMENSION)
FORECAST_LENGTH_HOURS = 24
CAUSAL_FORCING_NAMES = (
    "standardized_astronomical_tide",
    "standardized_one_hour_astronomical_tide_change",
)


def _inverse_softplus(value: float) -> float:
    if not math.isfinite(value) or value <= 0.0:
        raise ValueError("inverse-softplus input must be finite and positive")
    return math.log(math.expm1(value))


def _logit(probability: float) -> float:
    if not 0.0 < probability < 1.0:
        raise ValueError("logit probability must lie strictly inside (0, 1)")
    return math.log(probability / (1.0 - probability))


class PositiveDefiniteCovariance(nn.Module):
    """Learn a diagonal or full covariance through a Cholesky factor."""

    def __init__(
        self,
        dimension: int,
        initial_variance: float,
        *,
        full: bool,
        minimum_standard_deviation: float = 1.0e-4,
    ) -> None:
        super().__init__()
        if dimension < 1:
            raise ValueError("covariance dimension must be positive")
        if not math.isfinite(initial_variance) or initial_variance <= 0.0:
            raise ValueError("initial variance must be finite and positive")
        if (
            not math.isfinite(minimum_standard_deviation)
            or minimum_standard_deviation <= 0.0
            or minimum_standard_deviation >= math.sqrt(initial_variance)
        ):
            raise ValueError(
                "minimum standard deviation must be positive and smaller than "
                "the initial standard deviation"
            )
        self.dimension = int(dimension)
        self.full = bool(full)
        self.minimum_standard_deviation = float(minimum_standard_deviation)
        raw_initial = _inverse_softplus(
            math.sqrt(initial_variance) - minimum_standard_deviation
        )
        if self.full:
            lower_indices = torch.tril_indices(self.dimension, self.dimension)
            diagonal_positions = torch.nonzero(
                lower_indices[0] == lower_indices[1], as_tuple=False
            ).reshape(-1)
            raw = torch.zeros(lower_indices.shape[1], dtype=torch.float32)
            raw[diagonal_positions] = raw_initial
            self.raw_lower_triangle = nn.Parameter(raw)
            self.register_buffer("lower_rows", lower_indices[0])
            self.register_buffer("lower_columns", lower_indices[1])
            self.register_buffer("diagonal_positions", diagonal_positions)
            self.register_parameter("raw_diagonal", None)
        else:
            self.raw_diagonal = nn.Parameter(
                torch.full((self.dimension,), raw_initial, dtype=torch.float32)
            )
            self.register_parameter("raw_lower_triangle", None)
            self.register_buffer("lower_rows", torch.empty(0, dtype=torch.long))
            self.register_buffer("lower_columns", torch.empty(0, dtype=torch.long))
            self.register_buffer(
                "diagonal_positions", torch.empty(0, dtype=torch.long)
            )

    def standard_deviation(self) -> torch.Tensor:
        raw = (
            self.raw_lower_triangle[self.diagonal_positions]
            if self.raw_lower_triangle is not None
            else self.raw_diagonal
        )
        return self.minimum_standard_deviation + torch.nn.functional.softplus(raw)

    def forward(self) -> torch.Tensor:
        diagonal = self.standard_deviation()
        if self.raw_lower_triangle is None:
            return torch.diag(diagonal.square())
        values = self.raw_lower_triangle.index_copy(
            0, self.diagonal_positions, diagonal
        )
        lower = torch.zeros(
            self.dimension,
            self.dimension,
            dtype=values.dtype,
            device=values.device,
        ).index_put((self.lower_rows, self.lower_columns), values)
        return lower @ lower.transpose(-1, -2)


class ConditionallyLinearRiverTransition(nn.Module):
    """Forcing-conditioned neural transition that is linear in uncertain state.

    The small neural network changes trend persistence, level/trend coupling,
    and upstream/downstream exchange using forcing already known at issue time.
    Conditional linearity permits an exact covariance propagation; a nonlinear
    transition can later use ``DifferentiableUnscentedTransitionMoments`` under
    the same state and observation contract.
    """

    def __init__(
        self,
        forcing_dimension: int,
        *,
        hidden_dimension: int = 24,
        maximum_neighbor_coupling: float = 0.20,
        maximum_forcing_increment: float = 0.25,
    ) -> None:
        super().__init__()
        if forcing_dimension < 1 or hidden_dimension < 1:
            raise ValueError("forcing and hidden dimensions must be positive")
        if not 0.0 < maximum_neighbor_coupling < 0.5:
            raise ValueError("maximum neighbor coupling must lie inside (0, 0.5)")
        if not 0.0 < maximum_forcing_increment <= 1.0:
            raise ValueError("maximum forcing increment must lie inside (0, 1]")
        self.forcing_dimension = int(forcing_dimension)
        self.maximum_neighbor_coupling = float(maximum_neighbor_coupling)
        self.maximum_forcing_increment = float(maximum_forcing_increment)

        valid_neighbor_count = STATION_COUNT - 1
        output_dimension = (
            2 * STATION_COUNT + 2 * valid_neighbor_count + STATE_DIMENSION
        )
        self.conditioner = nn.Sequential(
            nn.Linear(self.forcing_dimension, hidden_dimension),
            nn.Tanh(),
            nn.Linear(hidden_dimension, output_dimension),
        )
        final_layer = self.conditioner[-1]
        nn.init.normal_(final_layer.weight, mean=0.0, std=1.0e-3)
        with torch.no_grad():
            final_layer.bias[:STATION_COUNT].fill_(_logit(0.80))
            final_layer.bias[STATION_COUNT : 2 * STATION_COUNT].fill_(
                _logit(0.80 / 0.99)
            )
            neighbor_start = 2 * STATION_COUNT
            neighbor_stop = neighbor_start + 2 * valid_neighbor_count
            final_layer.bias[neighbor_start:neighbor_stop].fill_(
                _logit(0.10)
            )
            final_layer.bias[neighbor_stop:].zero_()

        level_identity = torch.zeros(STATE_DIMENSION, STATE_DIMENSION)
        level_identity[:STATION_COUNT, :STATION_COUNT] = torch.eye(STATION_COUNT)
        trend_injection = torch.zeros(
            STATION_COUNT, STATE_DIMENSION, STATE_DIMENSION
        )
        trend_persistence = torch.zeros_like(trend_injection)
        upstream_exchange = torch.zeros_like(trend_injection)
        downstream_exchange = torch.zeros_like(trend_injection)
        for station_index in range(STATION_COUNT):
            trend_index = STATION_COUNT + station_index
            trend_injection[station_index, station_index, trend_index] = 1.0
            trend_persistence[station_index, trend_index, trend_index] = 1.0
            if station_index > 0:
                upstream_exchange[
                    station_index, station_index, station_index - 1
                ] = 1.0
                upstream_exchange[
                    station_index, station_index, station_index
                ] = -1.0
            if station_index + 1 < STATION_COUNT:
                downstream_exchange[
                    station_index, station_index, station_index + 1
                ] = 1.0
                downstream_exchange[
                    station_index, station_index, station_index
                ] = -1.0
        self.register_buffer("level_identity", level_identity)
        self.register_buffer("trend_injection_basis", trend_injection)
        self.register_buffer("trend_persistence_basis", trend_persistence)
        self.register_buffer("upstream_exchange_basis", upstream_exchange)
        self.register_buffer("downstream_exchange_basis", downstream_exchange)

    def matrices(self, forcing: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        if forcing.ndim != 2 or forcing.shape[1] != self.forcing_dimension:
            raise ValueError(
                f"forcing shape must be [batch,{self.forcing_dimension}]"
            )
        if not bool(torch.isfinite(forcing).all()):
            raise ValueError("forcing contains a nonfinite value")
        raw = self.conditioner(forcing)
        neighbor_count = STATION_COUNT - 1
        trend_injection = torch.sigmoid(raw[:, :STATION_COUNT])
        trend_persistence = 0.99 * torch.sigmoid(
            raw[:, STATION_COUNT : 2 * STATION_COUNT]
        )
        upstream_start = 2 * STATION_COUNT
        downstream_start = upstream_start + neighbor_count
        increment_start = downstream_start + neighbor_count
        upstream_valid = self.maximum_neighbor_coupling * torch.sigmoid(
            raw[:, upstream_start:downstream_start]
        )
        downstream_valid = self.maximum_neighbor_coupling * torch.sigmoid(
            raw[:, downstream_start:increment_start]
        )
        upstream = torch.nn.functional.pad(upstream_valid, (1, 0))
        downstream = torch.nn.functional.pad(downstream_valid, (0, 1))
        forcing_increment = self.maximum_forcing_increment * torch.tanh(
            raw[:, increment_start:]
        )
        batch_size = forcing.shape[0]
        transition = self.level_identity.unsqueeze(0).expand(batch_size, -1, -1)
        transition = transition + torch.einsum(
            "bi,ijk->bjk", trend_injection, self.trend_injection_basis
        )
        transition = transition + torch.einsum(
            "bi,ijk->bjk", trend_persistence, self.trend_persistence_basis
        )
        transition = transition + torch.einsum(
            "bi,ijk->bjk", upstream, self.upstream_exchange_basis
        )
        transition = transition + torch.einsum(
            "bi,ijk->bjk", downstream, self.downstream_exchange_basis
        )
        return transition, forcing_increment

    def forward(self, state: torch.Tensor, forcing: torch.Tensor) -> torch.Tensor:
        if state.ndim != 2 or state.shape[1] != STATE_DIMENSION:
            raise ValueError(f"state shape must be [batch,{STATE_DIMENSION}]")
        transition, increment = self.matrices(forcing)
        return torch.bmm(transition, state.unsqueeze(-1)).squeeze(-1) + increment

    def propagate_sigma_points(
        self, sigma_points: torch.Tensor, forcing: torch.Tensor
    ) -> torch.Tensor:
        if sigma_points.ndim != 3 or sigma_points.shape[2] != STATE_DIMENSION:
            raise ValueError(
                f"sigma points must be [batch,point,{STATE_DIMENSION}]"
            )
        transition, increment = self.matrices(forcing)
        return (
            torch.einsum("bij,bsj->bsi", transition, sigma_points)
            + increment.unsqueeze(1)
        )


class DifferentiableUnscentedTransitionMoments(nn.Module):
    """Optional Merwe sigma-point propagation for a nonlinear transition."""

    def __init__(
        self,
        state_dimension: int = STATE_DIMENSION,
        *,
        alpha: float = 1.0,
        beta: float = 2.0,
        kappa: float = 0.0,
        covariance_jitter: float = 1.0e-8,
    ) -> None:
        super().__init__()
        if (
            state_dimension < 1
            or not all(
                math.isfinite(value)
                for value in (alpha, beta, kappa, covariance_jitter)
            )
            or alpha <= 0.0
            or beta < 0.0
            or covariance_jitter <= 0.0
        ):
            raise ValueError("invalid unscented-transform configuration")
        scaling = alpha**2 * (state_dimension + kappa)
        if scaling <= 0.0:
            raise ValueError("sigma-point scaling must be positive")
        lambda_value = scaling - state_dimension
        mean_weights = torch.full(
            (2 * state_dimension + 1,), 1.0 / (2.0 * scaling)
        )
        covariance_weights = mean_weights.clone()
        mean_weights[0] = lambda_value / scaling
        covariance_weights[0] = (
            lambda_value / scaling + (1.0 - alpha**2 + beta)
        )
        self.state_dimension = int(state_dimension)
        self.scaling = float(scaling)
        self.covariance_jitter = float(covariance_jitter)
        self.register_buffer("mean_weights", mean_weights)
        self.register_buffer("covariance_weights", covariance_weights)

    @property
    def sigma_point_count(self) -> int:
        return 2 * self.state_dimension + 1

    def sigma_points(
        self, mean: torch.Tensor, covariance: torch.Tensor
    ) -> torch.Tensor:
        expected_covariance = (
            mean.shape[0], self.state_dimension, self.state_dimension
        )
        if mean.ndim != 2 or mean.shape[1] != self.state_dimension:
            raise ValueError("mean has the wrong state dimension")
        if covariance.shape != expected_covariance:
            raise ValueError("covariance has the wrong shape")
        identity = torch.eye(
            self.state_dimension, dtype=mean.dtype, device=mean.device
        ).unsqueeze(0)
        symmetric = 0.5 * (covariance + covariance.transpose(-1, -2))
        root = torch.linalg.cholesky(
            self.scaling * symmetric + self.covariance_jitter * identity
        )
        offsets = root.transpose(1, 2)
        center = mean.unsqueeze(1)
        return torch.cat([center, center + offsets, center - offsets], dim=1)

    def predict(
        self,
        mean: torch.Tensor,
        covariance: torch.Tensor,
        forcing: torch.Tensor,
        process_covariance: torch.Tensor,
        transition: ConditionallyLinearRiverTransition,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        points = self.sigma_points(mean, covariance)
        propagated = transition.propagate_sigma_points(points, forcing)
        mean_weights = self.mean_weights.to(dtype=mean.dtype, device=mean.device)
        covariance_weights = self.covariance_weights.to(
            dtype=mean.dtype, device=mean.device
        )
        predicted_mean = torch.einsum("s,bsi->bi", mean_weights, propagated)
        deviations = propagated - predicted_mean.unsqueeze(1)
        predicted_covariance = torch.einsum(
            "s,bsi,bsj->bij", covariance_weights, deviations, deviations
        )
        if process_covariance.ndim == 2:
            process_covariance = process_covariance.unsqueeze(0).expand(
                mean.shape[0], -1, -1
            )
        if process_covariance.shape != covariance.shape:
            raise ValueError("process covariance has the wrong shape")
        predicted_covariance = predicted_covariance + process_covariance
        predicted_covariance = 0.5 * (
            predicted_covariance + predicted_covariance.transpose(-1, -2)
        )
        return predicted_mean, predicted_covariance


class SixStationNeuralStateSpaceDataAssimilator(nn.Module):
    """Differentiable masked filter plus strict post-issue open-loop forecast."""

    def __init__(
        self,
        *,
        process_initial_variance: float = 1.0e-3,
        observation_initial_variance: float = 1.0e-2,
        initial_state_variance: float = 1.0e-1,
    ) -> None:
        super().__init__()
        self.transition = ConditionallyLinearRiverTransition(
            len(CAUSAL_FORCING_NAMES)
        )
        self.process_covariance = PositiveDefiniteCovariance(
            STATE_DIMENSION, process_initial_variance, full=True
        )
        self.observation_covariance = PositiveDefiniteCovariance(
            STATION_COUNT, observation_initial_variance, full=False
        )
        self.initial_covariance = PositiveDefiniteCovariance(
            STATE_DIMENSION, initial_state_variance, full=False
        )
        self.initial_mean = nn.Parameter(torch.zeros(STATE_DIMENSION))
        observation_matrix = torch.zeros(STATION_COUNT, STATE_DIMENSION)
        observation_matrix[:, :STATION_COUNT] = torch.eye(STATION_COUNT)
        self.register_buffer("observation_matrix", observation_matrix)

    @property
    def forcing_dimension(self) -> int:
        return self.transition.forcing_dimension

    def _validate_inputs(
        self,
        observations: torch.Tensor,
        availability: torch.Tensor,
        history_forcing: torch.Tensor,
        future_forcing: torch.Tensor,
    ) -> torch.Tensor:
        if observations.ndim != 3 or observations.shape[2] != STATION_COUNT:
            raise ValueError("observations must be [batch,history_hour,6]")
        if observations.shape[:2] != availability.shape[:2] or (
            availability.ndim != 3 or availability.shape[2] != STATION_COUNT
        ):
            raise ValueError("availability shape must match observations")
        batch_size, history_length, _ = observations.shape
        if batch_size < 1 or history_length < 1:
            raise ValueError("history must contain at least one batch and hour")
        if history_forcing.shape != (
            batch_size,
            history_length,
            self.forcing_dimension,
        ):
            raise ValueError("history forcing has the wrong shape")
        if (
            future_forcing.ndim != 3
            or future_forcing.shape[0] != batch_size
            or future_forcing.shape[1] != FORECAST_LENGTH_HOURS
            or future_forcing.shape[2] != self.forcing_dimension
        ):
            raise ValueError("future forcing must be [batch,24,2]")
        if not observations.dtype.is_floating_point:
            raise ValueError("observations must use a floating-point dtype")
        model_parameter = self.initial_mean
        for name, value in (
            ("observations", observations),
            ("history forcing", history_forcing),
            ("future forcing", future_forcing),
        ):
            if (
                value.dtype != model_parameter.dtype
                or value.device != model_parameter.device
            ):
                raise ValueError(f"{name} dtype/device differs from the model")
        if availability.dtype == torch.bool:
            availability_boolean = availability
        else:
            if not bool(torch.isfinite(availability).all()) or not bool(
                ((availability == 0) | (availability == 1)).all()
            ):
                raise ValueError("availability must contain only zero or one")
            availability_boolean = availability.to(dtype=torch.bool)
        if availability_boolean.device != observations.device:
            raise ValueError("availability device differs from observations")
        if not bool(torch.isfinite(history_forcing).all()) or not bool(
            torch.isfinite(future_forcing).all()
        ):
            raise ValueError("forcing contains a nonfinite value")
        if not bool(torch.isfinite(observations[availability_boolean]).all()):
            raise ValueError("an available observation is nonfinite")
        return availability_boolean

    def predict_step(
        self,
        mean: torch.Tensor,
        covariance: torch.Tensor,
        forcing: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        batch_size = mean.shape[0] if mean.ndim == 2 else -1
        if mean.shape != (batch_size, STATE_DIMENSION):
            raise ValueError("mean must be [batch,12]")
        if covariance.shape != (batch_size, STATE_DIMENSION, STATE_DIMENSION):
            raise ValueError("covariance must be [batch,12,12]")
        if forcing.shape != (batch_size, self.forcing_dimension):
            raise ValueError("forcing must be [batch,2]")
        for name, value in (
            ("mean", mean),
            ("covariance", covariance),
            ("forcing", forcing),
        ):
            if value.dtype != self.initial_mean.dtype or value.device != self.initial_mean.device:
                raise ValueError(f"{name} dtype/device differs from the model")
            if not bool(torch.isfinite(value).all()):
                raise ValueError(f"{name} contains a nonfinite value")
        transition, increment = self.transition.matrices(forcing)
        predicted_mean = (
            torch.bmm(transition, mean.unsqueeze(-1)).squeeze(-1) + increment
        )
        process = self.process_covariance().unsqueeze(0).expand(
            mean.shape[0], -1, -1
        )
        predicted_covariance = (
            transition @ covariance @ transition.transpose(-1, -2) + process
        )
        predicted_covariance = 0.5 * (
            predicted_covariance + predicted_covariance.transpose(-1, -2)
        )
        return predicted_mean, predicted_covariance

    def measurement_update(
        self,
        prior_mean: torch.Tensor,
        prior_covariance: torch.Tensor,
        observation: torch.Tensor,
        availability: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if prior_mean.ndim != 2 or prior_mean.shape[1] != STATE_DIMENSION:
            raise ValueError("prior mean has the wrong shape")
        expected_covariance = (
            prior_mean.shape[0], STATE_DIMENSION, STATE_DIMENSION
        )
        if prior_covariance.shape != expected_covariance:
            raise ValueError("prior covariance has the wrong shape")
        if observation.shape != (prior_mean.shape[0], STATION_COUNT):
            raise ValueError("observation has the wrong shape")
        if (
            availability.shape != observation.shape
            or availability.dtype != torch.bool
        ):
            raise ValueError("availability must be a Boolean [batch,6] tensor")
        for name, value in (
            ("prior mean", prior_mean),
            ("prior covariance", prior_covariance),
            ("observation", observation),
        ):
            if value.dtype != self.initial_mean.dtype or value.device != self.initial_mean.device:
                raise ValueError(f"{name} dtype/device differs from the model")
        if availability.device != prior_mean.device:
            raise ValueError("availability device differs from the model")
        if not bool(torch.isfinite(prior_mean).all()) or not bool(
            torch.isfinite(prior_covariance).all()
        ):
            raise ValueError("prior state contains a nonfinite value")
        if not bool(torch.isfinite(observation[availability]).all()):
            raise ValueError("an available observation is nonfinite")
        full_observation_covariance = self.observation_covariance()
        identity = torch.eye(
            STATE_DIMENSION, dtype=prior_mean.dtype, device=prior_mean.device
        )
        posterior_means = []
        posterior_covariances = []
        for batch_index in range(prior_mean.shape[0]):
            active = availability[batch_index]
            if not bool(active.any()):
                posterior_means.append(prior_mean[batch_index])
                posterior_covariances.append(prior_covariance[batch_index])
                continue
            active_observation_matrix = self.observation_matrix[active]
            active_observation_covariance = full_observation_covariance[active][:, active]
            covariance = prior_covariance[batch_index]
            observation_covariance = (
                active_observation_matrix
                @ covariance
                @ active_observation_matrix.transpose(-1, -2)
                + active_observation_covariance
            )
            state_observation_covariance = (
                covariance @ active_observation_matrix.transpose(-1, -2)
            )
            gain = torch.linalg.solve(
                observation_covariance,
                state_observation_covariance.transpose(-1, -2),
            ).transpose(-1, -2)
            predicted_observation = active_observation_matrix @ prior_mean[batch_index]
            innovation = observation[batch_index, active] - predicted_observation
            posterior_mean = prior_mean[batch_index] + gain @ innovation
            residual_map = identity - gain @ active_observation_matrix
            posterior_covariance = (
                residual_map @ covariance @ residual_map.transpose(-1, -2)
                + gain
                @ active_observation_covariance
                @ gain.transpose(-1, -2)
            )
            posterior_covariance = 0.5 * (
                posterior_covariance + posterior_covariance.transpose(-1, -2)
            )
            posterior_means.append(posterior_mean)
            posterior_covariances.append(posterior_covariance)
        return torch.stack(posterior_means), torch.stack(posterior_covariances)

    def forward(
        self,
        observations: torch.Tensor,
        availability: torch.Tensor,
        history_forcing: torch.Tensor,
        future_forcing: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        availability_boolean = self._validate_inputs(
            observations, availability, history_forcing, future_forcing
        )
        batch_size, history_length, _ = observations.shape
        mean = self.initial_mean.unsqueeze(0).expand(batch_size, -1)
        covariance = self.initial_covariance().unsqueeze(0).expand(
            batch_size, -1, -1
        )
        history_means = []
        history_covariances = []
        for hour_index in range(history_length):
            mean, covariance = self.predict_step(
                mean, covariance, history_forcing[:, hour_index, :]
            )
            mean, covariance = self.measurement_update(
                mean,
                covariance,
                observations[:, hour_index, :],
                availability_boolean[:, hour_index, :],
            )
            history_means.append(mean)
            history_covariances.append(covariance)

        forecast_means = []
        forecast_covariances = []
        for lead_index in range(future_forcing.shape[1]):
            mean, covariance = self.predict_step(
                mean, covariance, future_forcing[:, lead_index, :]
            )
            forecast_means.append(mean[:, LEVEL_STATE_SLICE])
            forecast_covariances.append(
                covariance[:, LEVEL_STATE_SLICE, LEVEL_STATE_SLICE]
            )
        forecast_mean = torch.stack(forecast_means, dim=1)
        forecast_covariance = torch.stack(forecast_covariances, dim=1)
        return {
            "history_posterior_mean": torch.stack(history_means, dim=1),
            "history_posterior_covariance": torch.stack(
                history_covariances, dim=1
            ),
            "issue_posterior_mean": history_means[-1],
            "issue_posterior_covariance": history_covariances[-1],
            "forecast_mean": forecast_mean,
            "forecast_covariance": forecast_covariance,
            "forecast_standard_deviation": torch.sqrt(
                torch.clamp(
                    torch.diagonal(forecast_covariance, dim1=-2, dim2=-1),
                    min=0.0,
                )
            ),
        }


def architecture_description() -> dict[str, object]:
    return {
        "station_order": list(STATION_ORDER),
        "state_dimension": STATE_DIMENSION,
        "state_coordinates": {
            "0_to_5": "standardized latent true water levels",
            "6_to_11": (
                "unobserved station-local trend-like propagation memory; "
                "not an identified physical velocity or exact level difference"
            ),
        },
        "observation_dimension": STATION_COUNT,
        "observation_operator": "first six state coordinates selected by availability",
        "causal_forcing_names": list(CAUSAL_FORCING_NAMES),
        "forecast_length_hours": FORECAST_LENGTH_HOURS,
        "default_filter": "differentiable conditionally linear Kalman filter",
        "nonlinear_fallback": {
            "method": "standalone differentiable unscented transition-moment prototype",
            "connected_to_default_model": False,
            "sigma_point_count": 2 * STATE_DIMENSION + 1,
        },
        "future_observation_input": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--describe",
        action="store_true",
        help="print the frozen prototype interface without running training",
    )
    arguments = parser.parse_args()
    if not arguments.describe:
        parser.error("this prototype only supports --describe")
    print(json.dumps(architecture_description(), indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
