#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Registered real-data runner for differentiable-UKF development training.

Run from the project root.  The only accepted target horizon ends in 2023;
the underlying loader reads exact registered byte prefixes ending at that
boundary.  Output attempts are immutable and publish a completion manifest
last.

Example:
    python -u scripts/modeling/zhenjiang_d32_gru_differentiable_ukf_runner_v1.py \
      --config docs/records/zhenjiang_d32_gru_differentiable_ukf_hpc_smoke_v1.json \
      --registry docs/records/ZHENJIANG_D32_GRU_DIFFERENTIABLE_UKF_V1_TRAINING_REGISTRY.json \
      --technical-registry docs/records/ZHENJIANG_D32_GRU_DIFFERENTIABLE_UKF_V1_EXPERIMENT_REGISTRY.json \
      --input-dir /absolute/pre2024/input \
      --loader-tide-model results/modeling/wusongkou_astronomical_tide_v1_validation/tide_model.json \
      --output-root /absolute/results --device cuda:0 --allow-paid-smoke
"""

from __future__ import annotations

import argparse
import csv
from dataclasses import asdict, is_dataclass
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import random
import sys
import time
import traceback
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import torch
from torch.utils.data import DataLoader

from water_level_joint_encoder_decoder_v2 import (
    EXPECTED_TRAINING_SAMPLES,
    EXPECTED_VALIDATION_SAMPLES,
    load_joint_water_level_data,
)
from zhenjiang_d32_gru_differentiable_ukf_training_data_v1 import (
    build_registered_training_base_datasets,
)
from zhenjiang_d32_gru_differentiable_ukf_training_v1 import (
    build_registered_training_adapter,
    forward_all_station_training_scenarios,
    other_station_metre_absolute_error_sum,
    training_stabilize_covariance,
)


REGISTRY_NAME = "zhenjiang_d32_gru_differentiable_ukf_training_v1"
TECHNICAL_REGISTRY_NAME = "zhenjiang_d32_gru_differentiable_ukf_v1"
TEST_TARGET_COUNTER_NAMES = (
    "test_target_rows_read",
    "test_target_values_parsed",
    "test_target_values_loaded",
)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _read_json(path: Path) -> Mapping[str, Any]:
    try:
        value = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise ValueError(f"JSON file cannot be read: {path}") from error
    if not isinstance(value, Mapping):
        raise ValueError(f"JSON root must be an object: {path}")
    return value


def _atomic_write_text(path: Path, text: str) -> None:
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    if path.exists() or temporary.exists():
        raise FileExistsError(f"refusing to overwrite output: {path}")
    temporary.write_text(text, encoding="utf-8", newline="\n")
    os.replace(str(temporary), str(path))


def _replace_json(path: Path, value: Any) -> None:
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    if temporary.exists():
        raise FileExistsError(f"temporary output already exists: {temporary}")
    temporary.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, sort_keys=False) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    os.replace(str(temporary), str(path))


def _replace_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    if temporary.exists():
        raise FileExistsError(f"temporary output already exists: {temporary}")
    fieldnames = list(rows[0].keys()) if rows else ["empty"]
    with temporary.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    os.replace(str(temporary), str(path))


def _atomic_torch_save(path: Path, value: Any) -> None:
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    if temporary.exists():
        raise FileExistsError(f"temporary checkpoint already exists: {temporary}")
    torch.save(value, temporary)
    os.replace(str(temporary), str(path))


def _require_exact_mapping(
    actual: Mapping[str, Any], expected: Mapping[str, Any], context: str
) -> None:
    if dict(actual) != dict(expected):
        raise ValueError(f"{context} contract drift")


def validate_configuration_document(config: Mapping[str, Any]) -> None:
    """Reject any scientific, data, optimizer, or timing drift."""

    required = {
        "schema_version",
        "experiment_id",
        "run_type",
        "backbone_experiment_id",
        "seed",
        "output_relative_path",
        "forecast",
        "data",
        "optimization",
        "selection",
        "execution",
    }
    if set(config) != required or config.get("schema_version") != "1.0":
        raise ValueError("configuration schema drift")
    experiment_id = config.get("experiment_id")
    if not isinstance(experiment_id, str) or not experiment_id:
        raise ValueError("experiment identifier is invalid")
    run_type = config.get("run_type")
    if run_type not in {"technical_hpc_smoke", "formal_development_training"}:
        raise ValueError("run type is invalid")
    if config.get("seed") not in {17, 29, 43}:
        raise ValueError("seed is invalid")
    expected_backbone = f"ZPGRU-EQUAL-S{config['seed']}-D32"
    if config.get("backbone_experiment_id") != expected_backbone:
        raise ValueError("backbone and seed differ")

    _require_exact_mapping(
        config.get("forecast", {}),
        {
            "analysis_observation_hour": 1,
            "target_hours_after_issue": list(range(2, 25)),
            "lead_hours_after_analysis": list(range(1, 24)),
        },
        "forecast lead",
    )
    _require_exact_mapping(
        config.get("data", {}),
        {
            "training_period": (
                "2017-01-01T00:00:00+08:00/2022-12-31T23:00:00+08:00"
            ),
            "development_validation_period": (
                "2023-01-01T00:00:00+08:00/2023-12-31T23:00:00+08:00"
            ),
            "expected_training_base_samples": EXPECTED_TRAINING_SAMPLES,
            "expected_validation_base_samples": EXPECTED_VALIDATION_SAMPLES,
            "held_out_2024_and_later_target_access_expected": 0,
        },
        "held-out data",
    )
    expected_optimization = {
        "optimizer": "Adam",
        "learning_rate": 0.001,
        "betas": [0.9, 0.999],
        "epsilon": 1e-8,
        "weight_decay": 0.0,
        "amsgrad": False,
        "gradient_clip_l2": 1.0,
        "base_batch_size": 32,
        "num_workers": 0,
        "drop_last": False,
        "maximum_epochs": 1 if run_type == "technical_hpc_smoke" else 20,
        "minimum_epochs": 1 if run_type == "technical_hpc_smoke" else 5,
        "early_stopping_patience": 1 if run_type == "technical_hpc_smoke" else 4,
        "minimum_improvement_m": 0.0001,
        "maximum_training_batches": 2 if run_type == "technical_hpc_smoke" else None,
        "maximum_validation_batches": 2 if run_type == "technical_hpc_smoke" else None,
    }
    if config.get("optimization", {}).get("base_batch_size") != 32:
        raise ValueError("base batch size contract drift")
    _require_exact_mapping(
        config.get("optimization", {}), expected_optimization, "optimization"
    )
    _require_exact_mapping(
        config.get("selection", {}),
        {
            "split": "2023_development_validation",
            "metric": "other_five_station_mae_m_leads_1_to_23",
            "lower_is_better": True,
            "tie_policy": "retain_earlier_epoch",
        },
        "selection",
    )
    _require_exact_mapping(
        config.get("execution", {}),
        {
            "device_type": "cuda",
            "paid_compute": True,
            "formal_scientific_result": False,
            "resume_allowed": False,
        },
        "scientific execution",
    )
    relative = Path(str(config.get("output_relative_path", "")))
    if relative.is_absolute() or ".." in relative.parts or len(relative.parts) != 3:
        raise ValueError("output path is invalid")
    expected_scope = "smoke" if run_type == "technical_hpc_smoke" else "formal"
    if tuple(relative.parts) != (expected_scope, experiment_id, "attempt_001"):
        raise ValueError("output path does not match the experiment")


def _validate_registry_document(
    registry: Mapping[str, Any], project_root: Path
) -> None:
    if registry.get("registry_name") != REGISTRY_NAME:
        raise ValueError("training registry name is invalid")
    _require_exact_mapping(
        registry.get("authorization", {}),
        {
            "real_data_loading_authorized": True,
            "training_2017_2022_authorized": True,
            "validation_2023_scoring_authorized": True,
            "gpu_authorized": True,
            "paid_compute_authorized": True,
            "held_out_target_access_authorized": False,
            "scientific_conclusion_authorized": False,
        },
        "training authorization",
    )
    technical = registry.get("technical_registry", {})
    technical_path = project_root / str(technical.get("path", ""))
    if (
        not technical_path.is_file()
        or _sha256(technical_path) != technical.get("sha256")
    ):
        raise ValueError("technical registry identity drift")
    technical_document = _read_json(technical_path)
    if technical_document.get("registry_name") != TECHNICAL_REGISTRY_NAME:
        raise ValueError("technical registry route drift")
    experiments = registry.get("experiments")
    if not isinstance(experiments, Mapping) or len(experiments) != 4:
        raise ValueError("registered experiment set is invalid")


def load_registered_training_configuration(
    config_path: Path,
    registry_path: Path,
    *,
    project_root: Optional[Path] = None,
) -> Mapping[str, Any]:
    """Load one configuration only after registry identity validation."""

    root = (
        Path(__file__).resolve().parents[2]
        if project_root is None
        else Path(project_root).resolve()
    )
    registry = _read_json(Path(registry_path))
    _validate_registry_document(registry, root)
    config_path = Path(config_path).resolve()
    try:
        relative_config = config_path.relative_to(root).as_posix()
    except ValueError as error:
        raise ValueError("configuration escapes the project root") from error
    config = _read_json(config_path)
    validate_configuration_document(config)
    row = registry["experiments"].get(config["experiment_id"])
    if not isinstance(row, Mapping):
        raise ValueError("configuration experiment is not registered")
    if (
        row.get("config_path") != relative_config
        or row.get("config_sha256") != _sha256(config_path)
        or row.get("run_type") != config["run_type"]
        or row.get("backbone_experiment_id")
        != config["backbone_experiment_id"]
        or row.get("seed") != config["seed"]
        or row.get("output_relative_path") != config["output_relative_path"]
    ):
        raise ValueError("registered configuration identity drift")
    return config


def _maximum_batches_reached(index: int, maximum_batches: Optional[int]) -> bool:
    return maximum_batches is not None and index >= maximum_batches


def _move_batch(batch: Mapping[str, Any], device: torch.device) -> Dict[str, Any]:
    moved = dict(batch)
    for name in (
        "history",
        "future_tide",
        "analysis_observations",
        "targets_t_plus_2_to_t_plus_24",
    ):
        value = batch.get(name)
        if not isinstance(value, torch.Tensor):
            raise ValueError(f"batch field is not a tensor: {name}")
        moved[name] = value.to(device)
    return moved


def _gradient_row(adapter, batch_index: int) -> Tuple[Dict[str, Any], torch.Tensor]:
    process = adapter.process_noise.raw_standard_deviation.grad
    observation = adapter.observation_noise.raw_standard_deviation.grad
    if process is None or observation is None:
        raise RuntimeError("one or more trainable noise gradients are absent")
    flat = torch.cat((process.reshape(-1), observation.reshape(-1)))
    nonfinite_count = int((~torch.isfinite(flat)).sum().item())
    if nonfinite_count:
        raise RuntimeError("trainable noise gradient is nonfinite")
    if flat.numel() != 38:
        raise RuntimeError("gradient scalar count differs from 38")
    if any(parameter.grad is not None for parameter in adapter.backbone.parameters()):
        raise RuntimeError("frozen backbone received a gradient")
    row = {
        "batch_index": batch_index,
        "gradient_scalar_count": int(flat.numel()),
        "nonfinite_gradient_count": nonfinite_count,
        "zero_gradient_count": int((flat == 0.0).sum().item()),
        "gradient_l2_before_clip": float(torch.linalg.vector_norm(flat).item()),
        "gradient_max_abs_before_clip": float(flat.abs().max().item()),
        "process_gradient_l2_before_clip": float(
            torch.linalg.vector_norm(process).item()
        ),
        "observation_gradient_l2_before_clip": float(
            torch.linalg.vector_norm(observation).item()
        ),
    }
    return row, flat


def run_training_epoch(
    adapter,
    loader: Iterable[Mapping[str, Any]],
    optimizer: torch.optim.Optimizer,
    target_standard_deviation_m: torch.Tensor,
    device: torch.device,
    *,
    maximum_batches: Optional[int],
    gradient_clip_l2: float,
) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    """Run one fitting epoch and aggregate error by exact cell count."""

    adapter.train(True)
    adapter.backbone.eval()
    total_error = 0.0
    total_cells = 0
    base_samples = 0
    spectral_floor_count = 0
    gradient_rows: List[Dict[str, Any]] = []
    completed_batches = 0
    for batch_index, batch in enumerate(loader):
        if _maximum_batches_reached(batch_index, maximum_batches):
            break
        tensors = _move_batch(batch, device)
        optimizer.zero_grad(set_to_none=True)
        result = forward_all_station_training_scenarios(
            adapter,
            tensors["history"],
            tensors["future_tide"],
            tensors["analysis_observations"],
            include_open_loop=False,
        )
        error_sum, cell_count = other_station_metre_absolute_error_sum(
            result["assimilation_forecast"],
            tensors["targets_t_plus_2_to_t_plus_24"],
            target_standard_deviation_m,
        )
        loss = error_sum / cell_count
        if not bool(torch.isfinite(loss)):
            raise RuntimeError("training loss is nonfinite")
        loss.backward()
        gradient_row, _ = _gradient_row(adapter, batch_index + 1)
        norm = torch.nn.utils.clip_grad_norm_(
            [
                parameter
                for parameter in adapter.parameters()
                if parameter.requires_grad
            ],
            max_norm=gradient_clip_l2,
            norm_type=2.0,
            error_if_nonfinite=True,
        )
        gradient_row["clip_returned_l2"] = float(norm.item())
        optimizer.step()
        if any(
            not bool(torch.isfinite(parameter).all())
            for parameter in adapter.parameters()
            if parameter.requires_grad
        ):
            raise RuntimeError("optimizer produced a nonfinite parameter")
        completed_batches += 1
        current_batch = int(tensors["history"].shape[0])
        base_samples += current_batch
        total_error += float(error_sum.detach().item())
        total_cells += int(cell_count)
        spectral_floor_count += int(
            result["spectral_floor_matrix_count"].item()
        )
        gradient_rows.append(gradient_row)
    optimizer.zero_grad(set_to_none=True)
    if completed_batches < 1 or total_cells < 1:
        raise RuntimeError("training epoch completed no batches")
    return {
        "completed_batches": completed_batches,
        "base_sample_count": base_samples,
        "valid_cell_count": total_cells,
        "absolute_error_sum_m": total_error,
        "mae_m": total_error / total_cells,
        "spectral_floor_matrix_count": spectral_floor_count,
    }, gradient_rows


def run_validation_epoch(
    adapter,
    loader: Iterable[Mapping[str, Any]],
    target_standard_deviation_m: torch.Tensor,
    device: torch.device,
    *,
    maximum_batches: Optional[int],
) -> Dict[str, Any]:
    """Evaluate paired assimilation/open-loop forecasts without gradients."""

    adapter.eval()
    adapter.backbone.eval()
    assimilation_error = 0.0
    open_error = 0.0
    total_cells = 0
    base_samples = 0
    completed_batches = 0
    spectral_floor_count = 0
    with torch.no_grad():
        for batch_index, batch in enumerate(loader):
            if _maximum_batches_reached(batch_index, maximum_batches):
                break
            tensors = _move_batch(batch, device)
            result = forward_all_station_training_scenarios(
                adapter,
                tensors["history"],
                tensors["future_tide"],
                tensors["analysis_observations"],
                include_open_loop=True,
            )
            current_assimilation, cell_count = (
                other_station_metre_absolute_error_sum(
                    result["assimilation_forecast"],
                    tensors["targets_t_plus_2_to_t_plus_24"],
                    target_standard_deviation_m,
                )
            )
            open_scenarios = result["open_loop_forecast"][:, None, :, :].expand(
                -1, 6, -1, -1
            )
            current_open, open_count = other_station_metre_absolute_error_sum(
                open_scenarios,
                tensors["targets_t_plus_2_to_t_plus_24"],
                target_standard_deviation_m,
            )
            if open_count != cell_count:
                raise RuntimeError("paired validation cell counts differ")
            assimilation_error += float(current_assimilation.item())
            open_error += float(current_open.item())
            total_cells += int(cell_count)
            current_batch = int(tensors["history"].shape[0])
            base_samples += current_batch
            completed_batches += 1
            spectral_floor_count += int(
                result["spectral_floor_matrix_count"].item()
            )
    if completed_batches < 1 or total_cells < 1:
        raise RuntimeError("validation epoch completed no batches")
    return {
        "completed_batches": completed_batches,
        "base_sample_count": base_samples,
        "valid_cell_count": total_cells,
        "assimilation_absolute_error_sum_m": assimilation_error,
        "assimilation_mae_m": assimilation_error / total_cells,
        "open_loop_absolute_error_sum_m": open_error,
        "open_loop_mae_m": open_error / total_cells,
        "spectral_floor_matrix_count": spectral_floor_count,
    }


def _state_dict_sha256(module: torch.nn.Module) -> str:
    digest = hashlib.sha256()
    for name, value in sorted(module.state_dict().items()):
        tensor = value.detach().cpu().contiguous()
        digest.update(name.encode("utf-8"))
        digest.update(str(tensor.dtype).encode("ascii"))
        digest.update(str(tuple(tensor.shape)).encode("ascii"))
        digest.update(tensor.numpy().tobytes())
    return digest.hexdigest()


def _gpu_technical_preflight(adapter, device: torch.device, batch_size: int):
    if device.type != "cuda" or not torch.cuda.is_available():
        raise RuntimeError("a visible CUDA graphics processor is required")
    torch.cuda.reset_peak_memory_stats(device)
    history = torch.linspace(
        -0.05,
        0.05,
        batch_size * 24 * 6,
        device=device,
        dtype=torch.float32,
    ).reshape(batch_size, 24, 6)
    tide = torch.linspace(
        -0.03,
        0.03,
        batch_size * 24,
        device=device,
        dtype=torch.float32,
    ).reshape(batch_size, 24)
    observations = torch.linspace(
        -0.02,
        0.02,
        batch_size * 6,
        device=device,
        dtype=torch.float32,
    ).reshape(batch_size, 6)
    targets = torch.zeros(batch_size, 23, 6, device=device, dtype=torch.float32)
    scales = torch.ones(6, device=device, dtype=torch.float64)
    adapter.zero_grad(set_to_none=True)
    torch.cuda.synchronize(device)
    started = time.perf_counter()
    result = forward_all_station_training_scenarios(
        adapter, history, tide, observations, include_open_loop=False
    )
    error_sum, cell_count = other_station_metre_absolute_error_sum(
        result["assimilation_forecast"], targets, scales
    )
    (error_sum / cell_count).backward()
    _, gradient = _gradient_row(adapter, 0)
    torch.cuda.synchronize(device)
    elapsed = time.perf_counter() - started

    repeated = torch.eye(32, dtype=torch.float64, device=device) * 2.0
    clipped = torch.diag(
        torch.tensor(
            [-0.5e-10] + [1.0] * 31,
            dtype=torch.float64,
            device=device,
        )
    )
    covariance = torch.stack((repeated, clipped)).requires_grad_(True)
    stabilized, diagnostics = training_stabilize_covariance(covariance)
    stabilized.sum().backward()
    if covariance.grad is None or not bool(torch.isfinite(covariance.grad).all()):
        raise RuntimeError("spectral-floor graphics-processor gradient failed")
    if diagnostics["clipped_matrix"].detach().cpu().tolist() != [False, True]:
        raise RuntimeError("spectral-floor graphics-processor mask changed")
    adapter.zero_grad(set_to_none=True)
    return {
        "device": str(device),
        "device_name": torch.cuda.get_device_name(device),
        "device_capability": list(torch.cuda.get_device_capability(device)),
        "torch_cuda_version": torch.version.cuda,
        "base_batch_size": batch_size,
        "forward_backward_seconds": elapsed,
        "peak_allocated_bytes": int(torch.cuda.max_memory_allocated(device)),
        "gradient_scalar_count": int(gradient.numel()),
        "nonfinite_gradient_count": int((~torch.isfinite(gradient)).sum().item()),
        "zero_gradient_count": int((gradient == 0.0).sum().item()),
        "spectral_floor_mask": [False, True],
        "status": "pass_technical_only",
    }


def _jsonable_dataclass_sequence(values) -> List[Mapping[str, Any]]:
    result = []
    for value in values:
        if is_dataclass(value):
            row = asdict(value)
        else:
            row = dict(value)
        for key, item in list(row.items()):
            if hasattr(item, "isoformat"):
                row[key] = item.isoformat()
        result.append(row)
    return result


def _capture_random_state(generator: torch.Generator) -> Mapping[str, Any]:
    return {
        "python": random.getstate(),
        "numpy": np.random.get_state(),
        "torch_cpu": torch.get_rng_state(),
        "torch_cuda": torch.cuda.get_rng_state_all(),
        "data_loader_generator": generator.get_state(),
    }


def _checkpoint_payload(
    *,
    config: Mapping[str, Any],
    epoch: int,
    adapter,
    optimizer,
    best_metric: float,
    best_epoch: int,
    no_improvement_count: int,
    generator: torch.Generator,
    identities: Mapping[str, Any],
) -> Mapping[str, Any]:
    return {
        "schema_version": "1.0",
        "experiment_id": config["experiment_id"],
        "attempt_id": "attempt_001",
        "seed": config["seed"],
        "completed_epoch": epoch,
        "adapter_state_dict": adapter.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "best_validation_mae_m": best_metric,
        "best_epoch": best_epoch,
        "no_improvement_count": no_improvement_count,
        "random_state": _capture_random_state(generator),
        "identities": dict(identities),
        "test_target_counters": {
            name: 0 for name in TEST_TARGET_COUNTER_NAMES
        },
    }


def _noise_parameter_rows(adapter, epoch: int) -> List[Mapping[str, Any]]:
    process_raw = (
        adapter.process_noise.raw_standard_deviation.detach().cpu().tolist()
    )
    process_variance = adapter.process_noise.variance().detach().cpu().tolist()
    observation_raw = (
        adapter.observation_noise.raw_standard_deviation.detach().cpu().tolist()
    )
    observation_variance = (
        adapter.observation_noise.variance().detach().cpu().tolist()
    )
    rows = []
    for index, (raw, variance) in enumerate(zip(process_raw, process_variance)):
        rows.append(
            {
                "epoch": epoch,
                "group": "process",
                "index": index,
                "raw_standard_deviation": raw,
                "variance": variance,
            }
        )
    for index, (raw, variance) in enumerate(
        zip(observation_raw, observation_variance)
    ):
        rows.append(
            {
                "epoch": epoch,
                "group": "observation",
                "index": index,
                "raw_standard_deviation": raw,
                "variance": variance,
            }
        )
    return rows


def write_completion_manifest(output_directory: Path, *, status: str) -> Path:
    """Write the immutable identity list after every other output exists."""

    output_directory = Path(output_directory)
    manifest_path = output_directory / "completion_manifest.json"
    if manifest_path.exists():
        raise FileExistsError("completion manifest already exists")
    rows = []
    for path in sorted(output_directory.rglob("*")):
        if path == manifest_path:
            continue
        if path.is_symlink():
            raise RuntimeError("output contains a symbolic link")
        if path.is_file():
            rows.append(
                {
                    "path": path.relative_to(output_directory).as_posix(),
                    "byte_count": path.stat().st_size,
                    "sha256": _sha256(path),
                }
            )
    manifest = {
        "schema_version": "1.0",
        "status": status,
        "created_utc": _utc_now(),
        "file_count": len(rows),
        "files": rows,
    }
    _atomic_write_text(
        manifest_path,
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
    )
    return manifest_path


def verify_output_directory(output_directory: Path) -> Mapping[str, Any]:
    """Recompute every completion-manifest identity without importing a run."""

    output_directory = Path(output_directory)
    manifest_path = output_directory / "completion_manifest.json"
    manifest = _read_json(manifest_path)
    rows = manifest.get("files")
    if not isinstance(rows, list) or manifest.get("file_count") != len(rows):
        raise RuntimeError("completion manifest schema changed")
    expected_paths = set()
    for row in rows:
        if not isinstance(row, Mapping):
            raise RuntimeError("completion identity row is invalid")
        relative = Path(str(row.get("path", "")))
        if relative.is_absolute() or ".." in relative.parts:
            raise RuntimeError("completion identity path is invalid")
        path = output_directory / relative
        expected_paths.add(relative.as_posix())
        if (
            not path.is_file()
            or path.is_symlink()
            or path.stat().st_size != row.get("byte_count")
            or _sha256(path) != row.get("sha256")
        ):
            raise RuntimeError("completion artifact identity mismatch")
    actual_paths = {
        path.relative_to(output_directory).as_posix()
        for path in output_directory.rglob("*")
        if path.is_file() and path != manifest_path
    }
    if actual_paths != expected_paths:
        raise RuntimeError("completion artifact set identity mismatch")
    return {
        "status": manifest.get("status"),
        "verified_file_count": len(rows),
        "completion_manifest_sha256": _sha256(manifest_path),
    }


def _resolve_attempt(output_root: Path, relative_text: str) -> Tuple[Path, Path]:
    root = Path(output_root).resolve()
    relative = Path(relative_text)
    final = (root / relative).resolve()
    try:
        final.relative_to(root)
    except ValueError as error:
        raise ValueError("attempt output escapes the output root") from error
    partial = final.with_name(final.name + ".partial")
    if final.exists() or partial.exists():
        raise FileExistsError("attempt output already exists")
    return partial, final


def _environment_identity(device: torch.device) -> Mapping[str, Any]:
    identity = {
        "python": sys.version,
        "platform": platform.platform(),
        "processor": platform.processor(),
        "torch": torch.__version__,
        "numpy": np.__version__,
        "device": str(device),
        "cuda_available": torch.cuda.is_available(),
        "cuda_runtime": torch.version.cuda,
        "deterministic_algorithms_enabled": (
            torch.are_deterministic_algorithms_enabled()
        ),
        "cudnn_benchmark": torch.backends.cudnn.benchmark,
        "cudnn_deterministic": torch.backends.cudnn.deterministic,
        "cuda_matmul_allow_tf32": torch.backends.cuda.matmul.allow_tf32,
        "cudnn_allow_tf32": torch.backends.cudnn.allow_tf32,
    }
    if device.type == "cuda" and torch.cuda.is_available():
        identity["cuda_device_name"] = torch.cuda.get_device_name(device)
        identity["cuda_device_capability"] = list(
            torch.cuda.get_device_capability(device)
        )
    return identity


def execute_training_run(
    *,
    config_path: Path,
    registry_path: Path,
    technical_registry_path: Path,
    input_dir: Path,
    tide_model_path: Path,
    output_root: Path,
    device: torch.device,
    allow_paid_smoke: bool,
    allow_paid_formal: bool,
) -> Path:
    """Execute one registered immutable smoke or formal development run."""

    project_root = Path(__file__).resolve().parents[2]
    config_path = Path(config_path).resolve()
    registry_path = Path(registry_path).resolve()
    technical_registry_path = Path(technical_registry_path).resolve()
    input_dir = Path(input_dir).resolve()
    tide_model_path = Path(tide_model_path).resolve()
    output_root = Path(output_root).resolve()
    config = load_registered_training_configuration(
        config_path, registry_path, project_root=project_root
    )
    if config["run_type"] == "technical_hpc_smoke":
        if not allow_paid_smoke or allow_paid_formal:
            raise PermissionError("paid smoke requires only --allow-paid-smoke")
        completion_status = "technical_pass"
    else:
        if not allow_paid_formal or allow_paid_smoke:
            raise PermissionError("formal training requires only --allow-paid-formal")
        completion_status = "completed_development_training"
    if device.type != "cuda" or not torch.cuda.is_available():
        raise RuntimeError("registered execution requires a CUDA graphics processor")
    if str(config["execution"]["device_type"]) != device.type:
        raise ValueError("configuration and requested device differ")
    if _sha256(Path(technical_registry_path)) != _read_json(registry_path)[
        "technical_registry"
    ]["sha256"]:
        raise ValueError("requested technical registry identity drift")
    partial, final = _resolve_attempt(
        Path(output_root), str(config["output_relative_path"])
    )
    partial.parent.mkdir(parents=True, exist_ok=True)
    partial.mkdir()

    try:
        seed = int(config["seed"])
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.use_deterministic_algorithms(True)
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False

        config_hash = _sha256(Path(config_path))
        registry_hash = _sha256(Path(registry_path))
        technical_registry_hash = _sha256(Path(technical_registry_path))
        _atomic_write_text(
            partial / "frozen_config.json",
            json.dumps(config, indent=2, ensure_ascii=False) + "\n",
        )
        run_identity = {
            "schema_version": "1.0",
            "experiment_id": config["experiment_id"],
            "attempt_id": "attempt_001",
            "run_type": config["run_type"],
            "seed": seed,
            "started_utc": _utc_now(),
            "config_path": Path(config_path).relative_to(project_root).as_posix(),
            "config_sha256": config_hash,
            "training_registry_path": Path(registry_path).relative_to(
                project_root
            ).as_posix(),
            "training_registry_sha256": registry_hash,
            "technical_registry_path": Path(technical_registry_path).relative_to(
                project_root
            ).as_posix(),
            "technical_registry_sha256": technical_registry_hash,
            "environment": _environment_identity(device),
            "authorization": {
                "held_out_target_access": False,
                "scientific_conclusion": False,
                "paid_compute": True,
            },
        }
        _replace_json(partial / "run_identity.json", run_identity)

        data = load_joint_water_level_data(
            input_dir=input_dir, tide_model_path=tide_model_path
        )
        counters = {
            name: getattr(data, name, None) for name in TEST_TARGET_COUNTER_NAMES
        }
        if counters != {name: 0 for name in TEST_TARGET_COUNTER_NAMES}:
            raise RuntimeError("held-out target counter is not integer zero")
        if len(data.training_records) != EXPECTED_TRAINING_SAMPLES or len(
            data.validation_records
        ) != EXPECTED_VALIDATION_SAMPLES:
            raise RuntimeError("registered base sample count changed")
        training_dataset, validation_dataset = (
            build_registered_training_base_datasets(data)
        )
        data_identity = {
            "schema_version": "1.0",
            "input_directory": str(Path(input_dir).resolve()),
            "tide_model_path": str(Path(tide_model_path).resolve()),
            "training_base_sample_count": len(training_dataset),
            "validation_base_sample_count": len(validation_dataset),
            "last_loaded_target_time_beijing": max(
                audit.last_target_time_beijing
                for audit in data.station_read_audits
            ).isoformat(),
            "test_target_counters": counters,
            "input_content_identities": _jsonable_dataclass_sequence(
                data.input_content_identities
            ),
            "astronomical_dependency_identities": (
                _jsonable_dataclass_sequence(data.astronomical_dependency_identities)
            ),
            "target_standard_deviation_m": (
                data.normalization.target_standard_deviation_m.astype(
                    np.float64
                ).tolist()
            ),
        }
        _replace_json(partial / "data_identity.json", data_identity)

        optimization = config["optimization"]
        loader_generator = torch.Generator().manual_seed(seed)
        training_loader = DataLoader(
            training_dataset,
            batch_size=optimization["base_batch_size"],
            shuffle=True,
            generator=loader_generator,
            drop_last=False,
            num_workers=0,
        )
        validation_loader = DataLoader(
            validation_dataset,
            batch_size=optimization["base_batch_size"],
            shuffle=False,
            drop_last=False,
            num_workers=0,
        )
        adapter = build_registered_training_adapter(
            Path(technical_registry_path),
            config["backbone_experiment_id"],
            device,
            project_root=project_root,
        )
        backbone_before = _state_dict_sha256(adapter.backbone)
        preflight = _gpu_technical_preflight(
            adapter, device, optimization["base_batch_size"]
        )
        preflight["backbone_state_sha256_before"] = backbone_before
        preflight["backbone_state_sha256_after"] = _state_dict_sha256(
            adapter.backbone
        )
        if (
            preflight["backbone_state_sha256_before"]
            != preflight["backbone_state_sha256_after"]
        ):
            raise RuntimeError("graphics-processor preflight changed the backbone")
        _replace_json(partial / "gpu_technical_preflight.json", preflight)

        trainable_parameters = [
            parameter
            for parameter in adapter.parameters()
            if parameter.requires_grad
        ]
        optimizer = torch.optim.Adam(
            trainable_parameters,
            lr=optimization["learning_rate"],
            betas=tuple(optimization["betas"]),
            eps=optimization["epsilon"],
            weight_decay=optimization["weight_decay"],
            amsgrad=optimization["amsgrad"],
        )
        target_scale = torch.as_tensor(
            data.normalization.target_standard_deviation_m,
            dtype=torch.float64,
            device=device,
        )
        identities = {
            "config_sha256": config_hash,
            "training_registry_sha256": registry_hash,
            "technical_registry_sha256": technical_registry_hash,
            "backbone_checkpoint_sha256": adapter.backbone_checkpoint_sha256,
            "backbone_state_sha256": backbone_before,
            "data_identity_sha256": _sha256(partial / "data_identity.json"),
        }
        training_history: List[Mapping[str, Any]] = []
        gradient_history: List[Mapping[str, Any]] = []
        noise_history: List[Mapping[str, Any]] = []
        best_metric = math.inf
        best_epoch = 0
        no_improvement_count = 0
        stopped_early = False
        maximum_epochs = int(optimization["maximum_epochs"])
        for epoch in range(1, maximum_epochs + 1):
            epoch_started = time.perf_counter()
            training_metrics, epoch_gradients = run_training_epoch(
                adapter,
                training_loader,
                optimizer,
                target_scale,
                device,
                maximum_batches=optimization["maximum_training_batches"],
                gradient_clip_l2=optimization["gradient_clip_l2"],
            )
            validation_metrics = run_validation_epoch(
                adapter,
                validation_loader,
                target_scale,
                device,
                maximum_batches=optimization["maximum_validation_batches"],
            )
            metric = float(validation_metrics["assimilation_mae_m"])
            improved = best_epoch == 0 or metric < (
                best_metric - optimization["minimum_improvement_m"]
            )
            if improved:
                best_metric = metric
                best_epoch = epoch
                no_improvement_count = 0
            else:
                no_improvement_count += 1
            elapsed = time.perf_counter() - epoch_started
            training_history.append(
                {
                    "epoch": epoch,
                    "training_mae_m": training_metrics["mae_m"],
                    "training_base_sample_count": training_metrics[
                        "base_sample_count"
                    ],
                    "training_valid_cell_count": training_metrics[
                        "valid_cell_count"
                    ],
                    "validation_assimilation_mae_m": metric,
                    "validation_open_loop_mae_m": validation_metrics[
                        "open_loop_mae_m"
                    ],
                    "validation_base_sample_count": validation_metrics[
                        "base_sample_count"
                    ],
                    "validation_valid_cell_count": validation_metrics[
                        "valid_cell_count"
                    ],
                    "material_improvement": improved,
                    "best_epoch_after": best_epoch,
                    "best_validation_mae_m_after": best_metric,
                    "no_improvement_count_after": no_improvement_count,
                    "spectral_floor_matrix_count": (
                        training_metrics["spectral_floor_matrix_count"]
                        + validation_metrics["spectral_floor_matrix_count"]
                    ),
                    "epoch_seconds": elapsed,
                }
            )
            for row in epoch_gradients:
                gradient_history.append({"epoch": epoch, **row})
            noise_history.extend(_noise_parameter_rows(adapter, epoch))
            checkpoint = _checkpoint_payload(
                config=config,
                epoch=epoch,
                adapter=adapter,
                optimizer=optimizer,
                best_metric=best_metric,
                best_epoch=best_epoch,
                no_improvement_count=no_improvement_count,
                generator=loader_generator,
                identities=identities,
            )
            _atomic_torch_save(partial / "last_checkpoint.pt", checkpoint)
            if improved:
                _atomic_torch_save(
                    partial / "best_checkpoint.pt",
                    {
                        "schema_version": "1.0",
                        "experiment_id": config["experiment_id"],
                        "attempt_id": "attempt_001",
                        "best_epoch": best_epoch,
                        "best_validation_mae_m": best_metric,
                        "adapter_state_dict": adapter.state_dict(),
                        "identities": identities,
                        "test_target_counters": counters,
                    },
                )
            _replace_csv(partial / "training_history.csv", training_history)
            _replace_csv(partial / "gradient_history.csv", gradient_history)
            _replace_csv(partial / "noise_parameter_history.csv", noise_history)
            if (
                epoch >= optimization["minimum_epochs"]
                and no_improvement_count >= optimization["early_stopping_patience"]
            ):
                stopped_early = True
                break

        completed_epoch = int(training_history[-1]["epoch"])
        if best_epoch < 1 or not math.isfinite(best_metric):
            raise RuntimeError("no finite best development checkpoint was selected")
        if config["run_type"] == "formal_development_training":
            if stopped_early:
                completion_status = "early_stopped_development_training"
            elif completed_epoch == maximum_epochs and (
                completed_epoch - best_epoch
                < optimization["early_stopping_patience"]
            ):
                completion_status = "budget_exhausted_not_converged"
            else:
                completion_status = "completed_development_training"
        if _state_dict_sha256(adapter.backbone) != backbone_before:
            raise RuntimeError("training changed the frozen backbone")
        best_checkpoint_path = partial / "best_checkpoint.pt"
        try:
            best_checkpoint = torch.load(
                best_checkpoint_path, map_location=device, weights_only=False
            )
        except TypeError:
            best_checkpoint = torch.load(best_checkpoint_path, map_location=device)
        adapter.load_state_dict(best_checkpoint["adapter_state_dict"])
        best_noise = {
            "schema_version": "1.0",
            "experiment_id": config["experiment_id"],
            "best_epoch": best_epoch,
            "best_validation_mae_m": best_metric,
            "process_variances": adapter.process_noise.variance().detach().cpu().tolist(),
            "observation_variances": (
                adapter.observation_noise.variance().detach().cpu().tolist()
            ),
        }
        _replace_json(partial / "best_noise_parameters.json", best_noise)
        best_noise_rows = []
        for group, values in (
            ("process", best_noise["process_variances"]),
            ("observation", best_noise["observation_variances"]),
        ):
            for index, variance in enumerate(values):
                best_noise_rows.append(
                    {"group": group, "index": index, "variance": variance}
                )
        _replace_csv(partial / "best_noise_parameters.csv", best_noise_rows)
        selection = {
            "schema_version": "1.0",
            "experiment_id": config["experiment_id"],
            "status": completion_status,
            "best_epoch": best_epoch,
            "best_validation_mae_m": best_metric,
            "selection_split": "2023_development_validation",
            "selection_metric": (
                "other_five_station_mae_m_leads_1_to_23"
            ),
            "development_selection_not_held_out": True,
            "held_out_target_access": False,
            "scientific_conclusion_authorized": False,
            "completed_epoch": completed_epoch,
            "test_target_counters": counters,
            "backbone_state_sha256_before": backbone_before,
            "backbone_state_sha256_after": _state_dict_sha256(adapter.backbone),
        }
        _replace_json(partial / "selection_validation_summary.json", selection)
        run_identity["completed_utc"] = _utc_now()
        run_identity["completion_status"] = completion_status
        run_identity["backbone_state_sha256_before"] = backbone_before
        run_identity["backbone_state_sha256_after"] = _state_dict_sha256(
            adapter.backbone
        )
        _replace_json(partial / "run_identity.json", run_identity)
        write_completion_manifest(partial, status=completion_status)
        verification = verify_output_directory(partial)
        if verification["status"] != completion_status:
            raise RuntimeError("completion verification status changed")
        os.replace(str(partial), str(final))
        return final
    except Exception as error:
        failure = {
            "schema_version": "1.0",
            "status": "failed_incomplete",
            "failed_utc": _utc_now(),
            "error_type": type(error).__name__,
            "error": str(error),
            "traceback": traceback.format_exc(),
            "completion_manifest_written": False,
        }
        failure_path = partial / "failure.json"
        if partial.is_dir() and not failure_path.exists():
            _replace_json(failure_path, failure)
        raise


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--registry", type=Path)
    parser.add_argument("--technical-registry", type=Path)
    parser.add_argument("--input-dir", type=Path)
    parser.add_argument("--loader-tide-model", type=Path)
    parser.add_argument("--output-root", type=Path)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--allow-paid-smoke", action="store_true")
    parser.add_argument("--allow-paid-formal", action="store_true")
    parser.add_argument("--verify-output", type=Path)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    arguments = _build_parser().parse_args(argv)
    if arguments.verify_output is not None:
        forbidden = (
            arguments.config,
            arguments.registry,
            arguments.technical_registry,
            arguments.input_dir,
            arguments.loader_tide_model,
            arguments.output_root,
        )
        if any(value is not None for value in forbidden) or (
            arguments.allow_paid_smoke or arguments.allow_paid_formal
        ):
            raise SystemExit("--verify-output must be used alone")
        print(json.dumps(verify_output_directory(arguments.verify_output), indent=2))
        return 0
    required = {
        "config": arguments.config,
        "registry": arguments.registry,
        "technical_registry": arguments.technical_registry,
        "input_dir": arguments.input_dir,
        "loader_tide_model": arguments.loader_tide_model,
        "output_root": arguments.output_root,
    }
    missing = [name for name, value in required.items() if value is None]
    if missing:
        raise SystemExit("missing required arguments: " + ", ".join(missing))
    output = execute_training_run(
        config_path=arguments.config,
        registry_path=arguments.registry,
        technical_registry_path=arguments.technical_registry,
        input_dir=arguments.input_dir,
        tide_model_path=arguments.loader_tide_model,
        output_root=arguments.output_root,
        device=torch.device(arguments.device),
        allow_paid_smoke=arguments.allow_paid_smoke,
        allow_paid_formal=arguments.allow_paid_formal,
    )
    print(json.dumps({"status": "complete", "output": str(output)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
