#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Independent audit for completed 2023 development evaluation outputs.

This module intentionally does not import the formal metrics or aggregation
module.  It recomputes identities, point estimates, the crossed block
bootstrap, Holm decisions, and the machine gate from CSV sufficient statistics.

Example:
    python -u scripts/analysis/audit_zhenjiang_d32_gru_differentiable_ukf_development_evaluation_v1.py \
      --summary /absolute/summary/ZHD32-DUKF-DEV-EVAL-SUMMARY-V1/attempt_001 \
      --workers-root /absolute/workers
"""

from __future__ import annotations

import argparse
from collections import defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np


STATIONS = (
    "datong",
    "nanjing",
    "zhenjiang",
    "jiangyin",
    "xuliujing",
    "wusongkou",
)
SEEDS = (17, 29, 43)
WORKER_FILES = (
    "run_identity.json",
    "frozen_evaluation_config.json",
    "checkpoint_identity.json",
    "data_identity.json",
    "block_error_statistics.csv",
    "block_analysis_diagnostics.csv",
    "block_state_decay_statistics.csv",
    "worker_summary.json",
)
SUMMARY_FILES = (
    "run_identity.json",
    "worker_identity_audit.json",
    "lead_condition_seed_metrics.csv",
    "window_condition_seed_metrics.csv",
    "target_station_lead_metrics.csv",
    "analysis_diagnostics.csv",
    "state_decay_diagnostics.csv",
    "bootstrap_condition_summary.csv",
    "holm_primary_family.csv",
    "development_gate.json",
)
ERROR_FIELDS = (
    "schema_version",
    "experiment_id",
    "seed",
    "block_id",
    "block_origin_count",
    "observed_station_index",
    "observed_station",
    "target_station_index",
    "target_station",
    "is_observed_target",
    "lead_hour",
    "cell_count",
    "assimilation_absolute_error_sum_m",
    "open_loop_absolute_error_sum_m",
    "assimilation_squared_error_sum_m2",
    "open_loop_squared_error_sum_m2",
    "target_sum_m",
    "target_squared_sum_m2",
)
ANALYSIS_FIELDS = (
    "schema_version",
    "experiment_id",
    "seed",
    "block_id",
    "block_origin_count",
    "observed_station_index",
    "observed_station",
    "analysis_prior_error_sum_m",
    "analysis_prior_absolute_error_sum_m",
    "analysis_prior_squared_error_sum_m2",
    "analysis_posterior_error_sum_m",
    "analysis_posterior_absolute_error_sum_m",
    "analysis_posterior_squared_error_sum_m2",
    "innovation_sum_m",
    "innovation_absolute_sum_m",
    "innovation_squared_sum_m2",
    "kalman_gain_l2_sum",
    "kalman_gain_l2_squared_sum",
    "count",
)
DECAY_FIELDS = (
    "schema_version",
    "experiment_id",
    "seed",
    "block_id",
    "block_origin_count",
    "observed_station_index",
    "observed_station",
    "lead_hour",
    "state_mean_difference_l2_sum",
    "state_mean_difference_l2_squared_sum",
    "count",
)
ZERO_COUNTERS = {
    "test_target_rows_read": 0,
    "test_target_values_loaded": 0,
    "test_target_values_parsed": 0,
}


def _sha(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _json(path: Path) -> Mapping[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, Mapping):
        raise RuntimeError("audit JSON root is not an object")
    return value


def _csv(path: Path) -> List[Dict[str, str]]:
    with Path(path).open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def _verify_manifest(
    directory: Path,
    expected_names: Sequence[str],
    expected_status: str,
    mismatch_message: str,
) -> Mapping[str, Any]:
    directory = Path(directory).resolve()
    manifest_path = directory / "completion_manifest.json"
    try:
        manifest = _json(manifest_path)
        rows = manifest["files"]
        if (
            manifest.get("status") != expected_status
            or manifest.get("file_count") != len(expected_names)
            or not isinstance(rows, list)
            or [row.get("path") for row in rows] != list(expected_names)
        ):
            raise RuntimeError(mismatch_message)
        for row in rows:
            path = directory / str(row["path"])
            if (
                not path.is_file()
                or path.is_symlink()
                or path.stat().st_size != row["byte_count"]
                or _sha(path) != row["sha256"]
            ):
                raise RuntimeError(mismatch_message)
        actual = {path.name for path in directory.iterdir() if path.is_file()}
        if actual != set(expected_names) | {"completion_manifest.json"}:
            raise RuntimeError(mismatch_message)
    except (KeyError, OSError, TypeError, ValueError) as error:
        raise RuntimeError(mismatch_message) from error
    return {
        "directory": str(directory),
        "completion_manifest_sha256": _sha(manifest_path),
        "file_count": len(expected_names),
    }


def _int(value: Any, name: str) -> int:
    if isinstance(value, bool):
        raise ValueError("audit integer is Boolean: %s" % name)
    converted = int(value)
    if isinstance(value, str) and str(converted) != value.strip():
        raise ValueError("audit integer text is not canonical: %s" % name)
    return converted


def _float(value: Any, name: str) -> float:
    converted = float(value)
    if not math.isfinite(converted):
        raise ValueError("audit numeric value is nonfinite: %s" % name)
    return converted


def _bool(value: Any, name: str) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str) and value.lower() in {"true", "false"}:
        return value.lower() == "true"
    raise ValueError("audit Boolean is invalid: %s" % name)


def _typed_error_rows(rows: Iterable[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    result = []
    seen = set()
    for source in rows:
        if set(source) != set(ERROR_FIELDS):
            raise RuntimeError("worker block error schema drift")
        row = dict(source)
        for name in (
            "seed",
            "block_id",
            "block_origin_count",
            "observed_station_index",
            "target_station_index",
            "lead_hour",
            "cell_count",
        ):
            row[name] = _int(row[name], name)
        row["is_observed_target"] = _bool(
            row["is_observed_target"], "is_observed_target"
        )
        for name in ERROR_FIELDS[12:]:
            row[name] = _float(row[name], name)
        seed = row["seed"]
        observed = row["observed_station_index"]
        target = row["target_station_index"]
        lead = row["lead_hour"]
        if (
            seed not in SEEDS
            or observed not in range(6)
            or target not in range(6)
            or lead not in range(1, 24)
            or row["observed_station"] != STATIONS[observed]
            or row["target_station"] != STATIONS[target]
            or row["is_observed_target"] != (observed == target)
            or row["cell_count"] != row["block_origin_count"]
            or row["cell_count"] < 1
            or row["block_origin_count"] > 168
        ):
            raise RuntimeError("worker block error identity drift")
        nonnegative = (
            "assimilation_absolute_error_sum_m",
            "open_loop_absolute_error_sum_m",
            "assimilation_squared_error_sum_m2",
            "open_loop_squared_error_sum_m2",
            "target_squared_sum_m2",
        )
        if any(row[name] < 0.0 for name in nonnegative):
            raise RuntimeError("worker block error statistic is negative")
        minimum_square = row["target_sum_m"] ** 2 / row["cell_count"]
        tolerance = 1e-10 * max(1.0, row["target_squared_sum_m2"])
        if row["target_squared_sum_m2"] + tolerance < minimum_square:
            raise RuntimeError("worker target sufficient statistics are invalid")
        key = (seed, row["block_id"], observed, target, lead)
        if key in seen:
            raise RuntimeError("duplicate worker block error row")
        seen.add(key)
        result.append(row)
    return result


def _verify_formal_diagnostic_grid(
    analysis: Sequence[Mapping[str, Any]],
    decay: Sequence[Mapping[str, Any]],
    seed: int,
    experiment_id: str,
) -> None:
    analysis_keys = set()
    for row in analysis:
        if set(row) != set(ANALYSIS_FIELDS):
            raise RuntimeError("worker analysis diagnostic schema drift")
        block = _int(row["block_id"], "analysis block")
        observed = _int(row["observed_station_index"], "analysis condition")
        expected_count = 168 if block < 47 else 150
        if (
            row["schema_version"] != "1.0"
            or row["experiment_id"] != experiment_id
            or _int(row["seed"], "analysis seed") != seed
            or block not in range(48)
            or observed not in range(6)
            or row["observed_station"] != STATIONS[observed]
            or _int(row["block_origin_count"], "analysis block count")
            != expected_count
            or _int(row["count"], "analysis count") != expected_count
        ):
            raise RuntimeError("worker analysis diagnostic identity drift")
        analysis_keys.add((block, observed))
        for name in ANALYSIS_FIELDS[7:-1]:
            _float(row[name], name)
    if analysis_keys != {
        (block, observed)
        for block in range(48)
        for observed in range(6)
    }:
        raise RuntimeError("worker analysis diagnostic Cartesian grid drift")

    decay_keys = set()
    for row in decay:
        if set(row) != set(DECAY_FIELDS):
            raise RuntimeError("worker state-decay diagnostic schema drift")
        block = _int(row["block_id"], "decay block")
        observed = _int(row["observed_station_index"], "decay condition")
        lead = _int(row["lead_hour"], "decay lead")
        expected_count = 168 if block < 47 else 150
        decay_sum = _float(row["state_mean_difference_l2_sum"], "decay sum")
        decay_square = _float(
            row["state_mean_difference_l2_squared_sum"], "decay square"
        )
        if (
            row["schema_version"] != "1.0"
            or row["experiment_id"] != experiment_id
            or _int(row["seed"], "decay seed") != seed
            or block not in range(48)
            or observed not in range(6)
            or lead not in range(1, 24)
            or row["observed_station"] != STATIONS[observed]
            or _int(row["block_origin_count"], "decay block count")
            != expected_count
            or _int(row["count"], "decay count") != expected_count
            or decay_sum < 0.0
            or decay_square < 0.0
        ):
            raise RuntimeError("worker state-decay diagnostic identity drift")
        decay_keys.add((block, observed, lead))
    if decay_keys != {
        (block, observed, lead)
        for block in range(48)
        for observed in range(6)
        for lead in range(1, 24)
    }:
        raise RuntimeError("worker state-decay diagnostic Cartesian grid drift")


def _sum(rows: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
    cells = sum(row["cell_count"] for row in rows)
    assimilation_absolute = sum(
        row["assimilation_absolute_error_sum_m"] for row in rows
    )
    open_absolute = sum(row["open_loop_absolute_error_sum_m"] for row in rows)
    assimilation_squared = sum(
        row["assimilation_squared_error_sum_m2"] for row in rows
    )
    open_squared = sum(row["open_loop_squared_error_sum_m2"] for row in rows)
    return {
        "cell_count": cells,
        "assimilation_absolute_error_sum_m": assimilation_absolute,
        "open_loop_absolute_error_sum_m": open_absolute,
        "assimilation_squared_error_sum_m2": assimilation_squared,
        "open_loop_squared_error_sum_m2": open_squared,
        "assimilation_mae_m": assimilation_absolute / cells,
        "open_loop_mae_m": open_absolute / cells,
        "assimilation_rmse_m": math.sqrt(assimilation_squared / cells),
        "open_loop_rmse_m": math.sqrt(open_squared / cells),
        "delta_assimilation_minus_open_loop_m": (
            assimilation_absolute - open_absolute
        )
        / cells,
        "gain_open_loop_minus_assimilation_m": (
            open_absolute - assimilation_absolute
        )
        / cells,
    }


def _groups(rows: Sequence[Mapping[str, Any]], names: Sequence[str]):
    value = defaultdict(list)
    for row in rows:
        value[tuple(row[name] for name in names)].append(row)
    return value


def _point_tables(rows: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    unobserved = [row for row in rows if not row["is_observed_target"]]
    lead_table = []
    for (seed, observed, lead), group in sorted(
        _groups(unobserved, ("seed", "observed_station_index", "lead_hour")).items()
    ):
        lead_table.append(
            {
                "seed": seed,
                "observed_station_index": observed,
                "observed_station": STATIONS[observed],
                "lead_hour": lead,
                **_sum(group),
            }
        )
    windows = (
        ("primary_1_to_6", 1, 6),
        ("secondary_1_to_12", 1, 12),
        ("full_1_to_23", 1, 23),
    )
    window_table = []
    for seed in SEEDS:
        for observed in range(6):
            for name, start, end in windows:
                selected = [
                    row
                    for row in unobserved
                    if row["seed"] == seed
                    and row["observed_station_index"] == observed
                    and start <= row["lead_hour"] <= end
                ]
                window_table.append(
                    {
                        "seed": seed,
                        "observed_station_index": observed,
                        "observed_station": STATIONS[observed],
                        "window_name": name,
                        "lead_hour_start": start,
                        "lead_hour_end": end,
                        **_sum(selected),
                    }
                )
    target_table = []
    for (seed, observed, target, lead), group in sorted(
        _groups(
            rows,
            (
                "seed",
                "observed_station_index",
                "target_station_index",
                "lead_hour",
            ),
        ).items()
    ):
        metrics = _sum(group)
        target_sum = sum(row["target_sum_m"] for row in group)
        target_squared = sum(row["target_squared_sum_m2"] for row in group)
        sst = max(0.0, target_squared - target_sum * target_sum / metrics["cell_count"])
        metrics.update(
            {
                "target_sum_m": target_sum,
                "target_squared_sum_m2": target_squared,
                "target_sst_m2": sst,
                "assimilation_nse": (
                    1.0 - metrics["assimilation_squared_error_sum_m2"] / sst
                    if sst > 0.0
                    else None
                ),
                "open_loop_nse": (
                    1.0 - metrics["open_loop_squared_error_sum_m2"] / sst
                    if sst > 0.0
                    else None
                ),
            }
        )
        target_table.append(
            {
                "seed": seed,
                "observed_station_index": observed,
                "observed_station": STATIONS[observed],
                "target_station_index": target,
                "target_station": STATIONS[target],
                "is_observed_target": target == observed,
                "lead_hour": lead,
                **metrics,
            }
        )
    return {"lead": lead_table, "window": window_table, "target": target_table}


def _bootstrap(rows, repeat_count, bootstrap_seed):
    primary = [
        row
        for row in rows
        if not row["is_observed_target"] and row["lead_hour"] <= 6
    ]
    blocks = sorted({row["block_id"] for row in primary})
    block_position = {block: index for index, block in enumerate(blocks)}
    seed_position = {seed: index for index, seed in enumerate(SEEDS)}
    shape = (3, len(blocks), 6)
    assimilation = np.zeros(shape, dtype=np.float64)
    open_loop = np.zeros(shape, dtype=np.float64)
    cells = np.zeros(shape, dtype=np.int64)
    present = np.zeros(shape, dtype=np.bool_)
    for row in primary:
        key = (
            seed_position[row["seed"]],
            block_position[row["block_id"]],
            row["observed_station_index"],
        )
        assimilation[key] += row["assimilation_absolute_error_sum_m"]
        open_loop[key] += row["open_loop_absolute_error_sum_m"]
        cells[key] += row["cell_count"]
        present[key] = True
    if not bool(present.all()) or bool((cells <= 0).any()):
        raise RuntimeError("audit bootstrap grid is incomplete")
    generator = np.random.Generator(np.random.PCG64(bootstrap_seed))
    seed_draws = generator.integers(0, 3, size=(repeat_count, 3), endpoint=False)
    block_draws = generator.integers(
        0, len(blocks), size=(repeat_count, len(blocks)), endpoint=False
    )
    summaries = []
    arrays = []
    for condition in range(6):
        selected_assimilation = assimilation[
            seed_draws[:, :, None], block_draws[:, None, :], condition
        ]
        selected_open = open_loop[
            seed_draws[:, :, None], block_draws[:, None, :], condition
        ]
        selected_cells = cells[
            seed_draws[:, :, None], block_draws[:, None, :], condition
        ]
        gain = (
            selected_open.sum(axis=(1, 2))
            - selected_assimilation.sum(axis=(1, 2))
        ) / selected_cells.sum(axis=(1, 2))
        arrays.append(gain)
        point = float(
            (open_loop[:, :, condition].sum() - assimilation[:, :, condition].sum())
            / cells[:, :, condition].sum()
        )
        lower, upper = np.quantile(gain, (0.025, 0.975))
        summaries.append(
            {
                "observed_station_index": condition,
                "observed_station": STATIONS[condition],
                "point_gain_open_loop_minus_assimilation_m": point,
                "point_delta_assimilation_minus_open_loop_m": -point,
                "bootstrap_gain_mean_m": float(gain.mean()),
                "gain_two_sided_95_lower_m": float(lower),
                "gain_two_sided_95_upper_m": float(upper),
                "delta_one_sided_95_upper_m": float(np.quantile(-gain, 0.95)),
                "gain_one_sided_p_value": float(
                    (1 + np.count_nonzero(gain <= 0.0)) / (repeat_count + 1)
                ),
            }
        )
    macro_array = np.stack(arrays, axis=1).mean(axis=1)
    lower, upper = np.quantile(macro_array, (0.025, 0.975))
    point_macro = float(
        np.mean(
            [row["point_gain_open_loop_minus_assimilation_m"] for row in summaries]
        )
    )
    macro = {
        "condition_count": 6,
        "point_gain_open_loop_minus_assimilation_m": point_macro,
        "point_delta_assimilation_minus_open_loop_m": -point_macro,
        "bootstrap_gain_mean_m": float(macro_array.mean()),
        "gain_two_sided_95_lower_m": float(lower),
        "gain_two_sided_95_upper_m": float(upper),
        "delta_one_sided_95_upper_m": float(np.quantile(-macro_array, 0.95)),
        "gain_one_sided_p_value": float(
            (1 + np.count_nonzero(macro_array <= 0.0)) / (repeat_count + 1)
        ),
    }
    return summaries, macro, blocks


def _holm(condition_summaries):
    p_values = [row["gain_one_sided_p_value"] for row in condition_summaries]
    order = sorted(range(6), key=lambda index: (p_values[index], index))
    adjusted = [0.0] * 6
    rejected = [False] * 6
    running = 0.0
    continue_rejecting = True
    for rank_zero, original in enumerate(order):
        running = max(running, (6 - rank_zero) * p_values[original])
        adjusted[original] = min(1.0, running)
        threshold = 0.05 / (6 - rank_zero)
        decision = continue_rejecting and p_values[original] <= threshold
        rejected[original] = decision
        if not decision:
            continue_rejecting = False
    ranks = {original: rank + 1 for rank, original in enumerate(order)}
    return [
        {
            "observed_station_index": condition,
            "observed_station": STATIONS[condition],
            "family_order": condition + 1,
            "holm_rank": ranks[condition],
            "raw_one_sided_p_value": p_values[condition],
            "holm_threshold": 0.05 / (6 - ranks[condition] + 1),
            "holm_adjusted_p_value": adjusted[condition],
            "holm_reject_no_improvement": rejected[condition],
        }
        for condition in range(6)
    ]


def _analysis_table(rows):
    sum_fields = (
        "analysis_prior_error_sum_m",
        "analysis_prior_absolute_error_sum_m",
        "analysis_prior_squared_error_sum_m2",
        "analysis_posterior_error_sum_m",
        "analysis_posterior_absolute_error_sum_m",
        "analysis_posterior_squared_error_sum_m2",
        "innovation_sum_m",
        "innovation_absolute_sum_m",
        "innovation_squared_sum_m2",
        "kalman_gain_l2_sum",
        "kalman_gain_l2_squared_sum",
    )
    grouped = defaultdict(lambda: {"count": 0, **{name: 0.0 for name in sum_fields}})
    seen = set()
    for row in rows:
        seed = _int(row["seed"], "seed")
        block = _int(row["block_id"], "block_id")
        observed = _int(row["observed_station_index"], "observed")
        unique = (seed, block, observed)
        if unique in seen:
            raise RuntimeError("duplicate audit analysis row")
        seen.add(unique)
        values = grouped[(seed, observed)]
        values["count"] += _int(row["count"], "count")
        for name in sum_fields:
            values[name] += _float(row[name], name)
    result = []
    for (seed, observed), values in sorted(grouped.items()):
        count = values["count"]
        result.append(
            {
                "seed": seed,
                "observed_station_index": observed,
                "observed_station": STATIONS[observed],
                "count": count,
                "analysis_prior_mean_error_m": values["analysis_prior_error_sum_m"] / count,
                "analysis_prior_mae_m": values["analysis_prior_absolute_error_sum_m"] / count,
                "analysis_prior_rmse_m": math.sqrt(values["analysis_prior_squared_error_sum_m2"] / count),
                "analysis_posterior_mean_error_m": values["analysis_posterior_error_sum_m"] / count,
                "analysis_posterior_mae_m": values["analysis_posterior_absolute_error_sum_m"] / count,
                "analysis_posterior_rmse_m": math.sqrt(values["analysis_posterior_squared_error_sum_m2"] / count),
                "innovation_mean_m": values["innovation_sum_m"] / count,
                "innovation_mae_m": values["innovation_absolute_sum_m"] / count,
                "innovation_rmse_m": math.sqrt(values["innovation_squared_sum_m2"] / count),
                "kalman_gain_l2_mean": values["kalman_gain_l2_sum"] / count,
                "kalman_gain_l2_rms": math.sqrt(values["kalman_gain_l2_squared_sum"] / count),
            }
        )
    return result


def _decay_table(rows):
    grouped = defaultdict(lambda: {"sum": 0.0, "squared": 0.0, "count": 0})
    seen = set()
    for row in rows:
        seed = _int(row["seed"], "seed")
        block = _int(row["block_id"], "block")
        observed = _int(row["observed_station_index"], "observed")
        lead = _int(row["lead_hour"], "lead")
        unique = (seed, block, observed, lead)
        if unique in seen:
            raise RuntimeError("duplicate audit decay row")
        seen.add(unique)
        values = grouped[(seed, observed, lead)]
        values["sum"] += _float(row["state_mean_difference_l2_sum"], "decay sum")
        values["squared"] += _float(row["state_mean_difference_l2_squared_sum"], "decay squared")
        values["count"] += _int(row["count"], "count")
    result = []
    for (seed, observed, lead), values in sorted(grouped.items()):
        result.append(
            {
                "seed": seed,
                "observed_station_index": observed,
                "observed_station": STATIONS[observed],
                "lead_hour": lead,
                "count": values["count"],
                "state_mean_difference_l2_mean": values["sum"] / values["count"],
                "state_mean_difference_l2_rms": math.sqrt(values["squared"] / values["count"]),
            }
        )
    return result


def _compare_rows(actual_rows, expected_rows, context):
    if len(actual_rows) != len(expected_rows):
        raise RuntimeError("%s row count mismatch" % context)
    for actual, expected in zip(actual_rows, expected_rows):
        if set(actual) != set(expected):
            raise RuntimeError("%s field mismatch" % context)
        for name, expected_value in expected.items():
            actual_value = actual[name]
            if isinstance(expected_value, bool):
                matches = _bool(actual_value, name) == expected_value
            elif isinstance(expected_value, int):
                matches = _int(actual_value, name) == expected_value
            elif isinstance(expected_value, float):
                matches = math.isclose(
                    _float(actual_value, name),
                    expected_value,
                    rel_tol=1e-11,
                    abs_tol=1e-13,
                )
            elif expected_value is None:
                matches = actual_value in {"", None}
            else:
                matches = str(actual_value) == str(expected_value)
            if not matches:
                raise RuntimeError("%s numeric or identity mismatch" % context)


def audit_completed_evaluation(
    summary_directory: Path,
    worker_directories: Sequence[Path],
    *,
    require_formal: bool = True,
) -> Mapping[str, Any]:
    """Independently recompute completed outputs and return audit status."""

    if len(worker_directories) != 3:
        raise ValueError("independent audit requires three workers")
    worker_identities = []
    expected_worker_audit_rows = []
    worker_registry_hashes = set()
    all_errors = []
    all_analysis = []
    all_decay = []
    seen_seeds = set()
    for directory in worker_directories:
        try:
            identity = _verify_manifest(
                directory,
                WORKER_FILES,
                "completed_2023_development_worker",
                "worker completion identity mismatch",
            )
        except RuntimeError as error:
            raise RuntimeError("worker completion identity mismatch") from error
        summary = _json(Path(directory) / "worker_summary.json")
        data = _json(Path(directory) / "data_identity.json")
        checkpoint = _json(Path(directory) / "checkpoint_identity.json")
        run_identity = _json(Path(directory) / "run_identity.json")
        manifest = _json(Path(directory) / "completion_manifest.json")
        seed = summary.get("seed")
        if seed not in SEEDS or seed in seen_seeds:
            raise RuntimeError("worker seed identity mismatch")
        seen_seeds.add(seed)
        expected_experiment = "ZHD32-DUKF-DEV-EVAL-S%d-V1" % seed
        if (
            summary.get("experiment_id") != expected_experiment
            or run_identity.get("experiment_id") != expected_experiment
            or summary.get("test_target_counters") != ZERO_COUNTERS
            or data.get("test_target_counters") != ZERO_COUNTERS
            or data.get("last_loaded_target_time_beijing")
            != "2023-12-31T23:00:00+08:00"
            or checkpoint.get("only_adapter_state_dict_loaded") is not True
            or checkpoint.get("optimizer_state_loaded") is not False
            or checkpoint.get("random_state_loaded") is not False
        ):
            raise RuntimeError("worker identity or target access mismatch")
        errors = _typed_error_rows(
            _csv(Path(directory) / "block_error_statistics.csv")
        )
        analysis = _csv(Path(directory) / "block_analysis_diagnostics.csv")
        decay = _csv(Path(directory) / "block_state_decay_statistics.csv")
        if {row["seed"] for row in errors} != {seed}:
            raise RuntimeError("worker block seed mismatch")
        if any(
            row["schema_version"] != "1.0"
            or row["experiment_id"] != expected_experiment
            for row in errors
        ):
            raise RuntimeError("worker block experiment identity mismatch")
        if require_formal:
            keys = {
                (
                    row["block_id"],
                    row["observed_station_index"],
                    row["target_station_index"],
                    row["lead_hour"],
                )
                for row in errors
            }
            expected_keys = {
                (block, observed, target, lead)
                for block in range(48)
                for observed in range(6)
                for target in range(6)
                for lead in range(1, 24)
            }
            if (
                len(errors) != 39744
                or keys != expected_keys
                or any(
                    row["block_origin_count"]
                    != (168 if row["block_id"] < 47 else 150)
                    for row in errors
                )
                or summary.get("processed_base_sample_count") != 8046
                or len(analysis) != 288
                or len(decay) != 6624
            ):
                raise RuntimeError("formal worker Cartesian coverage mismatch")
            _verify_formal_diagnostic_grid(
                analysis, decay, seed, expected_experiment
            )
        worker_registry_hashes.add(run_identity.get("registry_sha256"))
        all_errors.extend(errors)
        all_analysis.extend(analysis)
        all_decay.extend(decay)
        worker_identities.append({"seed": seed, **identity})
        expected_worker_audit_rows.append(
            {
                "seed": seed,
                "experiment_id": expected_experiment,
                "worker_directory": str(Path(directory).resolve()),
                "completion_manifest_sha256": identity[
                    "completion_manifest_sha256"
                ],
                "completion_manifest_file_count": identity["file_count"],
                "best_checkpoint_sha256": checkpoint[
                    "best_checkpoint_sha256"
                ],
                "processed_base_sample_count": summary.get(
                    "processed_base_sample_count"
                ),
                "block_count": summary.get("block_count"),
                "manifest_files": manifest["files"],
                "test_target_counters": data["test_target_counters"],
            }
        )
    if seen_seeds != set(SEEDS):
        raise RuntimeError("worker seed set mismatch")
    if len(worker_registry_hashes) != 1 or (
        require_formal
        and (
            None in worker_registry_hashes
            or not isinstance(next(iter(worker_registry_hashes)), str)
        )
    ):
        raise RuntimeError("worker registry identity mismatch")

    summary_identity = _verify_manifest(
        summary_directory,
        SUMMARY_FILES,
        "completed_2023_development_summary",
        "summary completion identity mismatch",
    )
    run_identity = _json(Path(summary_directory) / "run_identity.json")
    summary_registry = run_identity.get("registry_identity")
    worker_registry_sha256 = next(iter(worker_registry_hashes))
    if require_formal and (
        not isinstance(summary_registry, Mapping)
        or summary_registry.get("sha256") != worker_registry_sha256
    ):
        raise RuntimeError("summary registry identity mismatch")
    worker_audit = _json(Path(summary_directory) / "worker_identity_audit.json")
    expected_identity_details = {
        "three_worker_completion_manifests_verified": True,
        "worker_seed_set_exact": True,
        "paired_block_rows_valid": True,
        "zero_target_access_all_workers": True,
        "source_checkpoint_identities_present": True,
        "registered_worker_identities_match": True,
    }
    if (
        worker_audit.get("status") != "verified"
        or worker_audit.get("identity_gate_details") != expected_identity_details
        or worker_audit.get("workers")
        != sorted(expected_worker_audit_rows, key=lambda row: row["seed"])
    ):
        raise RuntimeError("summary worker identity audit mismatch")
    sampling = run_identity.get("bootstrap")
    if not isinstance(sampling, Mapping):
        raise RuntimeError("summary bootstrap identity missing")
    repeat_count = _int(sampling.get("repeat_count"), "repeat_count")
    bootstrap_seed = _int(sampling.get("seed"), "bootstrap_seed")
    if require_formal and (repeat_count != 20000 or bootstrap_seed != 20260828):
        raise RuntimeError("formal bootstrap identity mismatch")

    points = _point_tables(all_errors)
    _compare_rows(
        _csv(Path(summary_directory) / "lead_condition_seed_metrics.csv"),
        points["lead"],
        "lead-condition-seed metrics",
    )
    _compare_rows(
        _csv(Path(summary_directory) / "window_condition_seed_metrics.csv"),
        points["window"],
        "window-condition-seed metrics",
    )
    _compare_rows(
        _csv(Path(summary_directory) / "target_station_lead_metrics.csv"),
        points["target"],
        "target-station-lead metrics",
    )
    analysis_table = _analysis_table(all_analysis)
    decay_table = _decay_table(all_decay)
    _compare_rows(
        _csv(Path(summary_directory) / "analysis_diagnostics.csv"),
        analysis_table,
        "analysis diagnostics",
    )
    _compare_rows(
        _csv(Path(summary_directory) / "state_decay_diagnostics.csv"),
        decay_table,
        "state decay diagnostics",
    )

    conditions, macro, blocks = _bootstrap(
        all_errors, repeat_count, bootstrap_seed
    )
    expected_bootstrap = []
    for row in conditions:
        expected_bootstrap.append(
            {
                "row_type": "condition",
                "observed_station_index": row["observed_station_index"],
                "observed_station": row["observed_station"],
                "condition_count": 1,
                "point_gain_open_loop_minus_assimilation_m": row["point_gain_open_loop_minus_assimilation_m"],
                "point_delta_assimilation_minus_open_loop_m": row["point_delta_assimilation_minus_open_loop_m"],
                "bootstrap_gain_mean_m": row["bootstrap_gain_mean_m"],
                "gain_two_sided_95_lower_m": row["gain_two_sided_95_lower_m"],
                "gain_two_sided_95_upper_m": row["gain_two_sided_95_upper_m"],
                "delta_one_sided_95_upper_m": row["delta_one_sided_95_upper_m"],
                "gain_one_sided_p_value": row["gain_one_sided_p_value"],
            }
        )
    expected_bootstrap.append(
        {
            "row_type": "macro",
            "observed_station_index": "",
            "observed_station": "six_condition_macro",
            "condition_count": 6,
            "point_gain_open_loop_minus_assimilation_m": macro["point_gain_open_loop_minus_assimilation_m"],
            "point_delta_assimilation_minus_open_loop_m": macro["point_delta_assimilation_minus_open_loop_m"],
            "bootstrap_gain_mean_m": macro["bootstrap_gain_mean_m"],
            "gain_two_sided_95_lower_m": macro["gain_two_sided_95_lower_m"],
            "gain_two_sided_95_upper_m": macro["gain_two_sided_95_upper_m"],
            "delta_one_sided_95_upper_m": macro["delta_one_sided_95_upper_m"],
            "gain_one_sided_p_value": macro["gain_one_sided_p_value"],
        }
    )
    _compare_rows(
        _csv(Path(summary_directory) / "bootstrap_condition_summary.csv"),
        expected_bootstrap,
        "bootstrap summary",
    )
    holm = _holm(conditions)
    _compare_rows(
        _csv(Path(summary_directory) / "holm_primary_family.csv"),
        holm,
        "Holm primary family",
    )

    primary_rows = [
        row for row in points["window"] if row["window_name"] == "primary_1_to_6"
    ]
    all_18 = all(row["delta_assimilation_minus_open_loop_m"] < 0.0 for row in primary_rows)
    condition_means = []
    for condition in range(6):
        values = [
            row["delta_assimilation_minus_open_loop_m"]
            for row in primary_rows
            if row["observed_station_index"] == condition
        ]
        condition_means.append(float(np.mean(values)))
    gates = {
        "all_18_condition_seed_deltas_strictly_negative": all_18,
        "all_6_condition_seed_mean_deltas_strictly_negative": all(
            value < 0.0 for value in condition_means
        ),
        "all_6_holm_adjusted_one_sided_tests_reject_at_0_05": all(
            row["holm_reject_no_improvement"] for row in holm
        ),
        "six_condition_macro_delta_one_sided_95_upper_strictly_negative": (
            macro["delta_one_sided_95_upper_m"] < 0.0
        ),
        "identity_and_zero_target_access_gates_required": True,
    }
    expected_status = (
        "pass_2023_development_candidate_for_test_contract"
        if all(gates.values())
        else "fail_2023_primary_gate_stop_current_family"
    )
    gate = _json(Path(summary_directory) / "development_gate.json")
    if gate.get("status") != expected_status or gate.get("gates") != gates:
        raise RuntimeError("development gate mismatch")
    if not math.isclose(
        float(gate.get("macro_delta_one_sided_95_upper_m")),
        macro["delta_one_sided_95_upper_m"],
        rel_tol=1e-11,
        abs_tol=1e-13,
    ):
        raise RuntimeError("development macro boundary mismatch")
    return {
        "schema_version": "1.0",
        "status": "reproducible",
        "machine_status": expected_status,
        "worker_count": 3,
        "worker_identities": sorted(worker_identities, key=lambda row: row["seed"]),
        "summary_identity": summary_identity,
        "block_count": len(blocks),
        "bootstrap_repeat_count": repeat_count,
        "bootstrap_seed": bootstrap_seed,
        "primary_condition_seed_count": len(primary_rows),
        "gates": gates,
    }


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--summary", required=True, type=Path)
    parser.add_argument("--workers-root", required=True, type=Path)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    arguments = _build_parser().parse_args(argv)
    workers = [
        arguments.workers_root
        / ("ZHD32-DUKF-DEV-EVAL-S%d-V1" % seed)
        / "attempt_001"
        for seed in SEEDS
    ]
    result = audit_completed_evaluation(
        arguments.summary, workers, require_formal=True
    )
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
