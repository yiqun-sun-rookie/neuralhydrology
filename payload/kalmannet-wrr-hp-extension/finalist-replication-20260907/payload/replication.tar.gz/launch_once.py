"""Single-use entry guard for one frozen WRR validation-replication run."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path


REMOTE_ROOT = Path("/data1/home/sunyiq/kalmannet_wrr_finalist_replication_20260907")
EXPERIMENT_REL = Path("experiments/optimize_hyper_parameters/wrr_hp_extension_20260902")
FULL_RUNTIME_FIELDS = (
    "python_version", "numpy_version", "torch_version", "cuda_version", "cudnn_version", "gpu",
    "deterministic_algorithms", "cudnn_deterministic", "cudnn_benchmark",
)
VERSION_RUNTIME_FIELDS = (
    "python_version", "numpy_version", "torch_version", "cuda_version", "cudnn_version", "gpu",
)
EXPECTED_COMBOS = {
    0: (64, 15, 0.01, 43, 14),
    1: (64, 15, 0.01, 44, 14),
    2: (64, 10, 0.01, 43, 12),
    3: (64, 10, 0.01, 44, 12),
    4: (16, 10, 0.02, 43, 10),
    5: (16, 10, 0.02, 44, 10),
}


def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_index(index: int) -> int:
    if index not in EXPECTED_COMBOS:
        raise ValueError(f"index must be in 0..5, got {index}")
    return index


def verify_remote_root_identity(root: Path, manifest: dict) -> None:
    declared = Path(manifest.get("remote_root", ""))
    if root.resolve() != declared.resolve() or declared != REMOTE_ROOT:
        raise RuntimeError(f"remote root identity mismatch: running {root}, declared {declared}, required {REMOTE_ROOT}")


def verify_static_files(root: Path, manifest: dict) -> None:
    expected = manifest.get("static_files")
    if not isinstance(expected, dict) or not expected:
        raise RuntimeError("PACKAGE_MANIFEST.json has no static_files")
    for rel, expected_hash in expected.items():
        pure = Path(rel)
        if pure.is_absolute() or ".." in pure.parts:
            raise RuntimeError(f"unsafe static path: {rel}")
        path = root / pure
        if not path.is_file():
            raise RuntimeError(f"static file missing: {rel}")
        actual = sha256_path(path)
        if actual.lower() != str(expected_hash).lower():
            raise RuntimeError(f"Static SHA-256 mismatch for {rel}: expected {expected_hash}, got {actual}")


def validate_combo(index: int, combo: dict) -> None:
    hidden, expansion, lr, seed, source_index = EXPECTED_COMBOS[index]
    expected = {
        "index": index,
        "run_id": f"WRR-FINALIST-20260907-I{index:02d}",
        "lr": lr,
        "hidden_size": hidden,
        "num_layers": 1,
        "in_out_mult": expansion,
        "seed": seed,
        "effective_seed": seed,
        "source_seed42_index": source_index,
    }
    for key, value in expected.items():
        if combo.get(key) != value:
            raise RuntimeError(f"protected combo identity mismatch for index {index}, field {key}")


def refuse_existing_output(output: Path) -> None:
    if os.path.lexists(output):
        raise FileExistsError(f"output already exists: {output}")


def claim_once(root: Path, combo: dict) -> Path:
    claims = root / "claims"
    claims.mkdir(parents=True, exist_ok=True)
    path = claims / f"index{int(combo['index']):04d}.json"
    payload = {
        "index": int(combo["index"]),
        "seed": int(combo["seed"]),
        "run_id": combo["run_id"],
        "job_id": os.environ.get("SLURM_JOB_ID"),
        "array_task_id": os.environ.get("SLURM_ARRAY_TASK_ID"),
        "claimed_at": datetime.now(timezone.utc).isoformat(),
    }
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(payload, stream, indent=2, sort_keys=True)
        stream.write("\n")
    return path


def validate_runtime_snapshot(snapshot: dict, expected: dict, fields=FULL_RUNTIME_FIELDS) -> None:
    for field in fields:
        if field not in expected:
            raise RuntimeError(f"expected_runtime.json is missing {field}")
        if snapshot.get(field) != expected[field]:
            raise RuntimeError(f"runtime mismatch for {field}: expected {expected[field]!r}, got {snapshot.get(field)!r}")


def inspect_environment() -> dict:
    import numpy
    import torch

    gpu = torch.cuda.get_device_name(0) if torch.cuda.is_available() else None
    return {
        "python_version": ".".join(str(part) for part in sys.version_info[:3]),
        "numpy_version": numpy.__version__,
        "torch_version": torch.__version__,
        "cuda_version": torch.version.cuda,
        "cudnn_version": torch.backends.cudnn.version(),
        "gpu": gpu,
        "deterministic_algorithms": torch.are_deterministic_algorithms_enabled(),
        "cudnn_deterministic": torch.backends.cudnn.deterministic,
        "cudnn_benchmark": torch.backends.cudnn.benchmark,
    }


def load_original_launcher(path: Path):
    spec = importlib.util.spec_from_file_location("frozen_wrr_original_launcher", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"unable to load original launcher: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _load_controls(root: Path) -> tuple[dict, dict]:
    manifest = json.loads((root / "PACKAGE_MANIFEST.json").read_text(encoding="utf-8"))
    verify_remote_root_identity(root, manifest)
    verify_static_files(root, manifest)
    expected_runtime = json.loads((root / "expected_runtime.json").read_text(encoding="utf-8"))
    if not isinstance(expected_runtime.get("provenance_note"), str) or not expected_runtime["provenance_note"].strip():
        raise RuntimeError("expected_runtime.json is missing provenance_note")
    return manifest, expected_runtime


def run_one(root: Path, index: int) -> None:
    index = validate_index(index)
    _manifest, expected_runtime = _load_controls(root)
    experiment = root / "repo" / EXPERIMENT_REL
    original = load_original_launcher(experiment / "run_one_cell.py")

    combo = original.load_combo(index)
    validate_combo(index, combo)
    original.guard_source_contract()
    original.guard_data_contract()

    out_base = experiment / "runs" / f"formal_seed{int(combo['seed'])}"
    output = original.expected_run_dir(Path(str(out_base) + "_gpu"), combo)
    refuse_existing_output(output)
    claim_once(root, combo)

    unchanged_configure = original.configure_reproducibility

    def configure_and_validate(seed: int) -> dict:
        runtime = unchanged_configure(seed)
        snapshot = dict(runtime)
        snapshot.update(
            {
                "python_version": ".".join(str(part) for part in sys.version_info[:3]),
                "numpy_version": sys.modules["numpy"].__version__,
                "gpu": runtime.get("gpu"),
            }
        )
        validate_runtime_snapshot(snapshot, expected_runtime)
        return runtime

    original.configure_reproducibility = configure_and_validate
    old_argv = sys.argv[:]
    try:
        sys.argv = [str(experiment / "run_one_cell.py"), "--index", str(index)]
        original.main()
    finally:
        sys.argv = old_argv
        original.configure_reproducibility = unchanged_configure


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--index", type=int)
    parser.add_argument("--check-environment", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    _manifest, expected = _load_controls(root)
    if args.check_environment:
        validate_runtime_snapshot(inspect_environment(), expected, VERSION_RUNTIME_FIELDS)
        print("EXPECTED_RUNTIME_MATCH")
        return
    if args.index is None:
        parser.error("--index is required unless --check-environment is used")
    run_one(root, args.index)


if __name__ == "__main__":
    main()
