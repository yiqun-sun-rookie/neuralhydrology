import numpy as np
from data_loader import load_and_filter_data
from params import params
from hydrologic.Walrus import Walrus
from hydrologic.WalrusTorchBatch import WalrusTorchBatch
from datetime import datetime
from hydrologic.utils import plot_batch_time_series
import time
import torch
import os
import matplotlib.pyplot as plt

# 设定一个固定的起始日期
fixed_start_date = datetime(1970, 1, 1, 0, 0, 0)


def merge_batches(*batched_data_groups):
    """
    合并noisy_batches和batches，保持每个数据源的对应关系。

    参数:
    *batched_data_groups (list of torch.Tensor): 数据批次组，输入的是noisy_batches和batches。

    返回:
    list: 每个输入张量列表合并后的单个大张量列表，保持了p、etpot、qobs等数据的对应关系。
    """
    if not batched_data_groups:
        return []

    # 初始化一个空列表来存储合并后的结果
    merged_batches = []

    # 遍历每个数据组
    for batches in zip(*batched_data_groups):
        # 对应维度的数据进行拼接，保持p、etpot、qobs等对应关系
        merged_batch = torch.cat(batches, dim=0)
        merged_batches.append(merged_batch)

    return merged_batches

def shuffle_merged_batches(merged_batches):
    """
    对合并后的批次数据进行随机打乱，保持各列间数据的对应关系。
    参数:
    merged_batches (list of torch.Tensor): 合并后的数据批次组列表。
    返回:
    list: 混洗后的批次数据列表。
    """
    # 获取要混洗的总长度
    batch_size = merged_batches[0].shape[0]

    # 生成随机索引
    indices = torch.randperm(batch_size)

    # 按照随机索引对所有合并后的批次进行混洗
    shuffled_batches = [batch[indices] for batch in merged_batches]

    return shuffled_batches

def plot_data_comparison(original_data, noisy_data, title='数据对比', xlabel='时间步', ylabel='值'):
    """
    绘制原始数据和含噪声数据的对比图。

    参数:
    original_data (torch.Tensor): 原始数据张量。
    noisy_data (torch.Tensor): 含噪声数据张量。
    title (str): 图表标题。
    xlabel (str): x轴标签。
    ylabel (str): y轴标签。
    """
    plt.figure(figsize=(10, 5))

    # 假设数据形状为 [batch_size, 1, window_size]
    # 提取单个批次用于比较
    if len(original_data) > 0:
        original = original_data[0].squeeze().cpu().numpy()
        noisy = noisy_data[0].squeeze().cpu().numpy()

        # 绘图
        plt.plot(original, label='original data')
        plt.plot(noisy, label='noisy data', linestyle='--')
        plt.title(title)
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.legend()
        plt.grid(True)
        plt.show()
def convert_time_to_hours(tm_series, start_date):
    """ Convert datetime series to hours relative to a start date """
    return (tm_series - start_date).dt.total_seconds() / 3600

def add_percentage_noise(data, percentage=5):
    """
    向数据添加基于百分比的随机噪声。

    参数:
        data (np.array): 原始数据数组。
        percentage (float): 要添加的噪声百分比。

    返回:
        np.array: 加入噪声后的数据。
    """
    # 计算噪声的标准差为数据值的百分比
    noise = np.random.normal(0, 1, data.shape) * (data * percentage / 100)
    noisy_data = np.abs(data + noise)
    return torch.tensor(noisy_data, dtype=torch.float32, device=device)

def prepare_noisy_batches(window_size, device, *data_arrays, noise_level=None):
    """
    准备带有噪声的窗口批次。
    """
    batched_data_list = []

    for data in data_arrays:
        all_starts = np.arange(len(data) - window_size + 1)
        # 向数据添加噪声
        if noise_level is not None:
            noisy_data = add_percentage_noise(data, noise_level)
        else:
            noisy_data = data
        # 使用前面定义的函数创建窗口批次
        batched_data = torch.stack([
            torch.tensor(noisy_data[start:start + window_size], dtype=torch.float32)
            for start in all_starts
        ]).unsqueeze(1).to(device)
        batched_data_list.append(batched_data)

    return batched_data_list

def prepare_windowed_batches(window_size, batch_size, device, *data_arrays):
    """Prepare windowed batches for multiple data arrays ensuring the same segmentation,
    with an additional singleton dimension added.

    Args:
    window_size (int): The size of each window.
    batch_size (int): Number of windows in each batch.
    DEVICE (torch.DEVICE): The DEVICE to store the tensor data.
    *data_arrays (np.array): Variable number of numpy arrays containing the data.

    Returns:
    list: A list of tensors, each representing batched data for corresponding input array,
          with an additional middle dimension of size 1.
    """
    # Check if all data arrays have sufficient length
    if any(len(data) < window_size for data in data_arrays):
        raise ValueError("All data arrays must be at least as long as the window size.")

    num_possible_starts = len(data_arrays[0]) - window_size + 1

    # Ensure there are enough possible starts to meet the batch size requirement
    if num_possible_starts < batch_size:
        raise ValueError("Not enough data to fill the batch size with unique windows. Reduce batch size or window size.")

    # Choose random start indices for batch creation
    start_indices = np.random.choice(num_possible_starts, batch_size, replace=False)

    # Create and return batched data for each array
    batched_data_list = []
    for data in data_arrays:
        batched_data = torch.stack([
            torch.tensor(data[start:start + window_size], dtype=torch.float32)
            for start in start_indices
        ]).unsqueeze(1).to(device)
        batched_data_list.append(batched_data)

    return batched_data_list


file_path = r'/data\Hydrologic\PEQ_Regge_hour.txt'

# 加载并筛选数据
data_s = datetime(1999, 1, 1, 1)
data_e = datetime(2010, 1, 3, 1)
data = load_and_filter_data(file_path, data_s, data_e)

# 提取时间序列数据
tm, p, etpot, qobs = data['date'], data['P'], data['ETpot'], data['Q']
# 将时间数据转换为相对于固定起始日期的小时数
tm_hours = convert_time_to_hours(data['date'], fixed_start_date)

# 定义划分比例
train_ratio, val_ratio, test_ration = 0.7, 0.15, 0.15

# 计算划分的索引
n_total = len(p)
n_train = int(n_total * train_ratio)
n_val = int(n_total * val_ratio)

# 划分训练,验证,测试
p_train, etpot_train, qobs_train, tm_hours_train = p[:n_train], etpot[:n_train], qobs[:n_train], tm_hours[:n_train]
p_val, etpot_val, qobs_val, tm_hours_val = (p[n_train:n_train+n_val], etpot[n_train:n_train+n_val],
                                            qobs[n_train:n_train+n_val], tm_hours[n_train:n_train+n_val])
p_test, etpot_test, qobs_test, tm_hours_test = (p[n_train+n_val:], etpot[n_train+n_val:],
                                                qobs[n_train+n_val:], tm_hours[n_train+n_val:])
# 打印划分后的数据集大小
print("Training set size:", len(p_train))
print("Validation set size:", len(p_val))
print("Test set size:", len(p_test))

train_batch_size, val_batch_size, test_batch_size = 200, 50, 1
window_size = 400
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Prepare windowed batches for pipeline data
# train_batch_size = 65000
noisy_batches = prepare_noisy_batches(window_size, device,
                                      p_train.to_numpy(), etpot_train.to_numpy(), qobs_train.to_numpy())
batches = prepare_noisy_batches(window_size, device,
                                      p_train.to_numpy(), etpot_train.to_numpy(), qobs_train.to_numpy())
p_train_noisy_batch, etpot_train_noisy_batch, qobs_train_noisy_batch = noisy_batches
p_train_batch, etpot_train_batch, qobs_train_batch = batches

# # 假设 noisy_batches 和 batches 已经由之前的准备函数生成
# merged_batches = merge_batches(noisy_batches, batches)
# shuffled_batches = shuffle_merged_batches(merged_batches)

plot_data_comparison(qobs_train_batch[1, :, :], qobs_train_noisy_batch[1, :, :])
plot_data_comparison(p_train_batch[1, :, :], p_train_noisy_batch[1, :, :])
plot_data_comparison(etpot_train_noisy_batch[1, :, :], etpot_train_noisy_batch[1, :, :])

# Prepare windowed batches for validation data
val_batch_size = 100
batches = prepare_windowed_batches(window_size, val_batch_size, device, p_val.to_numpy(), etpot_val.to_numpy(), qobs_val.to_numpy(), tm_hours_val.to_numpy())
p_val_batch, etpot_val_batch, qobs_val_batch, tm_val_batch = batches

# Prepare windowed batches for test data
test_batch_size = 100
batches = prepare_windowed_batches(window_size, test_batch_size, device, p_test.to_numpy(), etpot_test.to_numpy(), qobs_test.to_numpy(), tm_hours_test.to_numpy())
p_test_batch, etpot_test_batch, qobs_test_batch, tm_test_batch = batches

# 打印输出以确认形状
print("Training batches shape (P):", p_train_batch.shape)
print("Validation batches shape (P):", p_val_batch.shape)
print("Test batches shape (P):", p_test_batch.shape)

# 设置保存路径
data_save_path = r'/data\Split\split_data_augmented.pt'
# 保存数据
torch.save({
    'p_train': p_train_batch,
    'etpot_train_batch': etpot_train_batch,
    'qobs_train_batch': qobs_train_batch,
    # 'tm_train_batch': tm_train_batch,
    'p_val_batch': p_val_batch,
    'etpot_val_batch': etpot_val_batch,
    'qobs_val_batch': qobs_val_batch,
    'tm_val_batch': tm_val_batch,
    'p_test_batch': p_test_batch,
    'etpot_test_batch': etpot_test_batch,
    'qobs_test_batch': qobs_test_batch,
    'tm_test_batch': tm_test_batch
}, data_save_path)
