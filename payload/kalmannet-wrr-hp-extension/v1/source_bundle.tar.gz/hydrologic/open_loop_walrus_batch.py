import os.path

import numpy as np
from data_loader import load_and_filter_data
from params import params
# from hydrologic.Walrus import Walrus
# from hydrologic.WalrusTorchBatch import WalrusTorchBatch
from filters.modules.pipeline.walrus_batch_speedup import WalrusBatch
from datetime import datetime
from hydrologic.utils import plot_batch_time_series
import time
import torch
def main():
    # 路径
    base_path = r"F:\github\pycharm\projects\kalmannet"
    data_path = os.path.join(base_path, 'data/hydrologic/PEQ_Regge_hour.txt')

    # 加载并筛选数据
    data_s = datetime(1999, 1, 1, 1)
    data_e = datetime(1999, 3, 3, 1)
    data = load_and_filter_data(data_path, data_s, data_e)

    # 提取时间序列数据
    tm = data['date']
    p = data['P']
    etpot = data['ETpot']
    qobs = data['Q']

    # 设置参数
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    T = len(p)
    batch_size = 5000

    # 模型参数和初始状态
    # 创建Tensor，同时增加批次维度
    # [样本数，特征数，时间步数]
    p_tensor = torch.tensor(p, dtype=torch.float32, device=device)  # 转换 p 为张量
    p_tensor = p_tensor.unsqueeze(0).unsqueeze(0)  # 添加两个新维度，变为 (1, 1, args.T_max)
    p_tensor = p_tensor.repeat(batch_size, 1, 1)  # 复制以匹配 (size, self.n, args.T_max)
    etpot_tensor = torch.tensor(etpot, dtype=torch.float32, device=device)  # 转换 etpot 为张量
    etpot_tensor = etpot_tensor.unsqueeze(0).unsqueeze(0)  # 添加两个新维度，变为 (1, 1, args.T_max)
    etpot_tensor = etpot_tensor.repeat(batch_size, 1, 1)  # 复制以匹配 (size, self.n, args.T_max)
    qobs_tensor = torch.tensor(qobs, dtype=torch.float32, device=device)  # 转换 p 为张量
    qobs_tensor = qobs_tensor.unsqueeze(0).unsqueeze(0)  # 添加两个新维度，变为 (1, 1, args.T_max)
    qobs_tensor = qobs_tensor.repeat(batch_size, 1, 1)  # 复制以匹配 (size, self.n, args.T_max)

    # 模型初始状态
    cd0, cs0, cw0, cv0, cg0, cq0 = params['cd'], params['cs'], params['cw'], params['cv'], params['cg'], params['cq']
    state0 = np.array([140, 1080, 4, 1200, 0.1])
    # initial_state_tensor [样本数，特征数]
    initial_state_tensor = torch.tensor(state0, dtype=torch.float32, device=device).repeat(batch_size, 1)
    # states_torch [样本数，特征数，时间步数]
    states_torch = torch.zeros((batch_size, len(state0), len(p)), dtype=torch.float32, device=device)
    states_torch[:, :, 0] = initial_state_tensor  # 设置初始状态

    # 初始化模型
    model_torch = WalrusBatch(cw=cw0, cv=cv0, cg=cg0, cq=cq0, cd=cd0, cs=cs0, initial_state=initial_state_tensor, device=device)

    # 运行torch模型
    start_time = time.time()
    # 一次性处理整个数据集
    x_prev = states_torch[:, :, 0]
    for t in range(1, T):
        states_torch[:, :, t] = model_torch.forward_pure(x=states_torch[:, :, t-1],
            p_t=p_tensor[:, :, t - 1].squeeze(), etpot_t=etpot_tensor[:, :, t - 1].squeeze())

    torch_time = time.time() - start_time
    print(f"Time taken for torch model: {torch_time}")
    # 绘图
    # convert torch data to numpy
    states_torch = states_torch.cpu().detach().numpy()
    plot_batch_time_series(states_torch, ['dv', 'dg', 'hq', 'hs', 'q'])


if __name__ == "__main__":
    main()
