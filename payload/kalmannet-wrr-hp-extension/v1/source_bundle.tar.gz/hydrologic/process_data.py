import numpy as np
from data_loader import load_and_filter_data
from params import params
from hydrologic.Walrus import Walrus
from hydrologic.WalrusTorchBatch import WalrusTorchBatch
from datetime import datetime
from hydrologic.utils import plot_batch_time_series
import time
import torch
import os
import matplotlib.pyplot as plt
from torch.utils.data import Dataset, DataLoader
def convert_time_to_hours(tm_series, start_date):
    """ Convert datetime series to hours relative to a start date """
    return (tm_series - start_date).dt.total_seconds() / 3600
class WindowedTimeSeriesDataset(Dataset):
    def __init__(self, p, etpot, qobs, tm_hours, window_size=400, batch_size=64):
        self.p = torch.tensor(p, dtype=torch.float32).unsqueeze(-1)
        self.etpot = torch.tensor(etpot, dtype=torch.float32).unsqueeze(-1)
        self.qobs = torch.tensor(qobs, dtype=torch.float32).unsqueeze(-1)
        self.tm_hours = torch.tensor(tm_hours, dtype=torch.float32).unsqueeze(-1)
        self.window_size = window_size
        self.batch_size = batch_size

    def __len__(self):
        total_windows = len(self.p) - self.window_size + 1
        return total_windows - (total_windows % self.batch_size)  # Ignore last incomplete batch

    def __getitem__(self, idx):
        start = idx
        end = idx + self.window_size
        return {
            'p': self.p[start:end].transpose(0, 1),  # 交换channels和length的维度
            'etpot': self.etpot[start:end].transpose(0, 1),
            'qobs': self.qobs[start:end].transpose(0, 1),
            'tm_hours': self.tm_hours[start:end].transpose(0, 1)
        }

# 设定一个固定的起始日期
fixed_start_date = datetime(1970, 1, 1, 0, 0, 0)
file_path = r'/data\Hydrologic\PEQ_Regge_hour.txt'

# 加载并筛选数据
data_s = datetime(1999, 1, 1, 1)
data_e = datetime(2010, 1, 3, 1)
data = load_and_filter_data(file_path, data_s, data_e)
# 提取时间序列数据
tm, p, etpot, qobs = data['date'], data['P'], data['ETpot'], data['Q']
# 将时间数据转换为相对于固定起始日期的小时数
tm_hours = convert_time_to_hours(data['date'], fixed_start_date).to_numpy()
p, etpot, qobs = p.to_numpy(), etpot.to_numpy(), qobs.to_numpy()

# 定义划分比例
train_ratio, val_ratio, test_ration = 0.7, 0.15, 0.15
# 计算划分的索引
n_total = len(p)
n_train = int(n_total * train_ratio)
n_val = int(n_total * val_ratio)
# 划分训练,验证,测试
p_train, etpot_train, qobs_train, tm_hours_train = p[:n_train], etpot[:n_train], qobs[:n_train], tm_hours[:n_train]
p_val, etpot_val, qobs_val, tm_hours_val = (p[n_train:n_train+n_val], etpot[n_train:n_train+n_val],
                                            qobs[n_train:n_train+n_val], tm_hours[n_train:n_train+n_val])
p_test, etpot_test, qobs_test, tm_hours_test = (p[n_train+n_val:], etpot[n_train+n_val:],
                                                qobs[n_train+n_val:], tm_hours[n_train+n_val:])
# 打印划分后的数据集大小
print("Training set size:", len(p_train))
print("Validation set size:", len(p_val))
print("Test set size:", len(p_test))

# 创建数据集实例
batch_size, window_size = 64, 400

train_dataset = WindowedTimeSeriesDataset(p_train, etpot_train, qobs_train, tm_hours_train, window_size=window_size, batch_size=batch_size)
val_dataset = WindowedTimeSeriesDataset(p_val, etpot_val, qobs_val, tm_hours_val, window_size=window_size, batch_size=batch_size)
test_dataset = WindowedTimeSeriesDataset(p_test, etpot_test, qobs_test, tm_hours_test, window_size=window_size, batch_size=batch_size)

# 创建 DataLoader
train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=64, shuffle=False)
test_loader = DataLoader(test_dataset, batch_size=64, shuffle=False)

# 用 DataLoader 迭代数据
counter = 0
for batch in train_loader:
    # 此处可以进行训练相关的操作，例如模型前向传播和后向传播
    print(f"Batch {counter}:")
    print("P:", batch['p'].shape)
    print("ETpot:", batch['etpot'].shape)
    print("Qobs:", batch['qobs'].shape)
    print("TM_hours:", batch['tm_hours'].shape)
    counter += 1

print(f"Total number of batches in one epoch: {counter}")
#
# train_batch_size, val_batch_size, test_batch_size = 200, 50, 1
# window_size = 400
# DEVICE = torch.DEVICE("cuda" if torch.cuda.is_available() else "cpu")
#
# # Prepare windowed batches for pipeline data
# # train_batch_size = 65000
# noisy_batches = prepare_noisy_batches(window_size, DEVICE,
#                                       p_train.to_numpy(), etpot_train.to_numpy(), qobs_train.to_numpy(), noise_level=5)
# batches = prepare_noisy_batches(window_size, DEVICE,
#                                       p_train.to_numpy(), etpot_train.to_numpy(), qobs_train.to_numpy())
# p_train_noisy_batch, etpot_train_noisy_batch, qobs_train_noisy_batch = noisy_batches
# p_train, etpot_train_batch, qobs_train_batch = batches
#
# # 假设 noisy_batches 和 batches 已经由之前的准备函数生成
# merged_batches = merge_batches(noisy_batches, batches)
# shuffled_batches = shuffle_merged_batches(merged_batches)
#
# plot_data_comparison(qobs_train_batch[1, :, :], qobs_train_noisy_batch[1, :, :])
# plot_data_comparison(p_train[1, :, :], p_train_noisy_batch[1, :, :])
# plot_data_comparison(etpot_train_noisy_batch[1, :, :], etpot_train_noisy_batch[1, :, :])
# # Prepare windowed batches for validation data
# val_batch_size = 100
# batches = prepare_windowed_batches(window_size, val_batch_size, DEVICE, p_val.to_numpy(), etpot_val.to_numpy(), qobs_val.to_numpy(), tm_val.to_numpy())
# p_val_batch, etpot_val_batch, qobs_val_batch, tm_val_batch = batches
#
# # Prepare windowed batches for test data
# test_batch_size = 100
# batches = prepare_windowed_batches(window_size, test_batch_size, DEVICE, p_test.to_numpy(), etpot_test.to_numpy(), qobs_test.to_numpy(), tm_test.to_numpy())
# p_test_batch, etpot_test_batch, qobs_test_batch, tm_test_batch = batches
#
# # 打印输出以确认形状
# print("Training batches shape (P):", p_train.shape)
# print("Validation batches shape (P):", p_val_batch.shape)
# print("Test batches shape (P):", p_test_batch.shape)
#
# # 设置保存路径
# data_save_path = r'F:\github\pycharm\projects\kalmannet\data\Split\split_data_augmented.pt'
# # 保存数据
# torch.save({
#     'p_train': p_train,
#     'etpot_train_batch': etpot_train_batch,
#     'qobs_train_batch': qobs_train_batch,
#     # 'tm_train_batch': tm_train_batch,
#     'p_val_batch': p_val_batch,
#     'etpot_val_batch': etpot_val_batch,
#     'qobs_val_batch': qobs_val_batch,
#     'tm_val_batch': tm_val_batch,
#     'p_test_batch': p_test_batch,
#     'etpot_test_batch': etpot_test_batch,
#     'qobs_test_batch': qobs_test_batch,
#     'tm_test_batch': tm_test_batch
# }, data_save_path)
