import torch
from torch.utils.data import Dataset

class WindowedTimeSeriesDataset(Dataset):
    def __init__(self, p, etpot, qobs, tm_hours, window_size=400, batch_size=64):
        self.p = torch.tensor(p, dtype=torch.float32).unsqueeze(-1)
        self.etpot = torch.tensor(etpot, dtype=torch.float32).unsqueeze(-1)
        self.qobs = torch.tensor(qobs, dtype=torch.float32).unsqueeze(-1)
        self.tm_hours = torch.tensor(tm_hours, dtype=torch.float32).unsqueeze(-1)
        self.window_size = window_size
        self.batch_size = batch_size

    def __len__(self):
        total_windows = len(self.p) - self.window_size + 1
        return total_windows - (total_windows % self.batch_size)  # Ignore last incomplete batch

    def __getitem__(self, idx):
        start = idx
        end = idx + self.window_size
        return {
            'p': self.p[start:end].transpose(0, 1),  # 交换channels和length的维度
            'etpot': self.etpot[start:end].transpose(0, 1),
            'qobs': self.qobs[start:end].transpose(0, 1),
            'tm_hours': self.tm_hours[start:end].transpose(0, 1)
        }