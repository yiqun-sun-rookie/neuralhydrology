import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import os
import warnings
warnings.filterwarnings("ignore", category=FutureWarning)
class DataHandler:
    def __init__(self, file_path, start_date, end_date):
        self.file_path = file_path
        self.start_date = datetime.strptime(start_date, '%Y-%m-%d %H')
        self.end_date = datetime.strptime(end_date, '%Y-%m-%d %H')

    def load_and_filter_data(self):
        if not os.path.exists(self.file_path):
            raise FileNotFoundError(f"File not found: {self.file_path}")
        # 假设使用pandas读取和筛选数据
        df = pd.read_csv(self.file_path, delim_whitespace=True, parse_dates=['date'], date_parser=self.parse_date)
        df['date'] = pd.to_datetime(df['date'])
        filtered_df = df[(df['date'] >= self.start_date) & (df['date'] <= self.end_date)]
        return filtered_df

    def convert_time_to_hours(self, tm_series):
        # 转换时间为小时数
        return (tm_series - datetime(1970, 1, 1)).dt.total_seconds() / 3600

    def split_data(self, p, etpot, qobs, tm_hours, ratios):
        # 根据给定的比例划分数据
        total_len = len(p)
        train_end = int(total_len * ratios[0])
        val_end = train_end + int(total_len * ratios[1])

        train_data = (p[:train_end], etpot[:train_end], qobs[:train_end], tm_hours[:train_end])
        val_data = (p[train_end:val_end], etpot[train_end:val_end], qobs[train_end:val_end], tm_hours[train_end:val_end])
        test_data = (p[val_end:], etpot[val_end:], qobs[val_end:], tm_hours[val_end:])
        return train_data, val_data, test_data

    def parse_date(self, date_str):
        """解析日期字符串，处理小时为'24'的情况转换为次日的'00'小时。"""
        try:
            return datetime.strptime(date_str, "%Y%m%d%H")
        except ValueError:
            if date_str.endswith("24"):
                date_without_hour = date_str[:-2]
                base_date = datetime.strptime(date_without_hour, "%Y%m%d")
                return base_date + timedelta(days=1)
            else:
                raise