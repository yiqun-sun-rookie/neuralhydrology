import time
import torch
import matplotlib.pyplot as plt
import numpy as np

def clamp_state_tensor(state, bounds):
    clamped_state = state.clone()  # 克隆state以避免原地操作
    for i, (lb, ub) in enumerate(bounds):
        clamped_state[:, i, :] = torch.clamp(clamped_state[:, i, :], lb, ub)
    return clamped_state

@torch.jit.ignore
def check_nan(tensor: torch.Tensor, name: str = "Tensor"):
    if torch.isnan(tensor).any():
        raise ValueError(f"{name} contains NaN values.")

def check_nan_inputs(*inputs):
    for idx, input_tensor in enumerate(inputs):
        if torch.isnan(input_tensor).any():
            raise ValueError(f"NaN detected in input {idx} of the function")
        if torch.isinf(input_tensor).any():
            raise ValueError(f"Inf detected in input {idx} of the function")

def check_nan_parameters(layer, layer_name):
    if torch.isnan(layer.weight).any():
        raise ValueError(f"NaN detected in weights of {layer_name}")
    if torch.isnan(layer.bias).any():
        raise ValueError(f"NaN detected in biases of {layer_name}")

def rearrange_data(p, lead_time=120):
    """
    Rearranges the input tensor `p` to form batches based on the specified lead time.

    Args:
        p (torch.Tensor): Input tensor of shape [1, 1, num_timesteps].
        lead_time (int): The lead time for forming batches.

    Returns:
        torch.Tensor: Rearranged tensor of shape [feasible_timesteps, lead_time].
    """
    num_timesteps = p.size(2)
    feasible_timesteps = num_timesteps - lead_time + 1

    p = p.squeeze(0).squeeze(0)
    p_batches = torch.stack([p[t:t + lead_time] for t in range(feasible_timesteps)], dim=0)

    return p_batches

def compare_q_obs_and_q_sim(y_hat_test_batch, qobs_test_batch):
    num_samples = y_hat_test_batch.shape[0]  # 获取样本数量
    time_steps = y_hat_test_batch.shape[2]  # 获取时间步长

    # 遍历所有样本
    for i in range(num_samples):
        plt.figure(figsize=(12, 4))
        plt.plot(range(time_steps), y_hat_test_batch[i, 0, :], label='Predicted (y_hat)')
        plt.plot(range(time_steps), qobs_test_batch[i, 0, :], label='Observed (qobs)', linestyle='--')
        plt.title(f'Sample {i + 1} Time Series')
        plt.xlabel('Time Step')
        plt.ylabel('Value')
        plt.legend()
        plt.show()
        time.sleep(1)

def plot_batch_time_series(states, labels, title='Time Series of States'):
    """
    Plot the time series data from the states array for each feature across all samples.

    Parameters:
    - states: np.array, containing the state variables over time, shape [num_samples, num_variables, time_steps].
    - labels: list of str, names for each state variable.
    - title: str, the title of the plot.
    """
    # Example usage:
    # 'states' should be an numpy array with shape [num_samples, num_variables, time_steps].
    # 'labels' should be a list of strings corresponding to each state variable.
    num_samples = states.shape[0]
    num_variables = states.shape[1]
    time_steps = np.arange(states.shape[2])

    for i in range(num_variables):
        plt.figure(figsize=(10, 5))
        for j in range(num_samples):
            plt.plot(time_steps, states[j, i, :], label=f'Sample {j+1}')
        plt.title(f'{title} for {labels[i]}')
        plt.xlabel('Time Steps')
        plt.ylabel('Value')
        plt.legend()
        plt.grid(True)
        plt.show()

def plot_time_series(states, labels, title='Time Series of States'):
    """
    Plot the time series data from the states array.

    Parameters:
    - states: np.array, containing the state variables over time.
    - labels: list of str, names for each state variable.
    - title: str, the title of the plot.
    """
    time_steps = np.arange(states.shape[0])
    num_variables = states.shape[1]

    for i in range(num_variables):
        plt.figure(figsize=(10, 5))
        plt.plot(time_steps, states[:, i], label=labels[i])
        plt.title(f'Time Series of {labels[i]}')
        plt.xlabel('Time Steps')
        plt.ylabel('Value')
        plt.legend()
        plt.grid(True)
        plt.show()
