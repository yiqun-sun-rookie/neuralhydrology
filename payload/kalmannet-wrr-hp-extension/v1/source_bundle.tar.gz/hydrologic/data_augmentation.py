import numpy as np
import torch

def prepare_windowed_batches(data, window_size, batch_size, device):
    num_samples = len(data) - window_size + 1
    start_indices = np.random.randint(0, num_samples, batch_size)
    batched_data = torch.stack([torch.tensor(data[start:start+window_size], dtype=torch.float32)
                                for start in start_indices])
    return batched_data.to(device)

# 假设你已经有了以下数据
data = np.random.randn(1000)  # 模拟1000个时间点的数据
window_size = 100  # 定义窗口大小为100个时间点
batch_size = 20   # 定义每个批次20个窗口
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 准备批次数据
batched_data = prepare_windowed_batches(data, window_size, batch_size, device)

print("Batched data shape:", batched_data.shape)  # 应为[20, 100], 表示20个批次，每个批次100个时间点
