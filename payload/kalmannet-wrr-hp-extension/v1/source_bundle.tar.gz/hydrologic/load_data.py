import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os
from params import params
from hydrologic.Walrus import Walrus
import matplotlib.pyplot as plt

# 定义一个日期解析函数
def parse_date(date_str):
    """解析日期字符串，如果发现小时为'24'，则转换为次日的'00'小时。"""
    try:
        # 尝试正常解析日期
        return datetime.strptime(date_str, "%Y%m%d%H")
    except ValueError:
        # 处理小时为'24'的情况
        if date_str.endswith("24"):
            # 除去小时后的日期部分，加一天，小时改为'00'
            date_without_hour = date_str[:-2]  # 获取除去小时的日期部分
            base_date = datetime.strptime(date_without_hour, "%Y%m%d")  # 解析日期部分
            corrected_date = base_date + timedelta(days=1)  # 日期加一天
            return corrected_date
        else:
            # 如果不是因为'24'小时导致的错误，重新抛出异常
            raise



# 定义日期范围
data_s = datetime(1999, 1, 1, 1)
data_e = datetime(2000, 1, 3, 1)

# 读取数据
file_path = r'/data\Hydrologic\PEQ_Regge_hour.txt'
if not os.path.exists(file_path):
    raise FileNotFoundError(f"File not found: {file_path}")

# 使用 date_parser 参数确保日期按照预期格式解析
data = pd.read_csv(file_path, delim_whitespace=True, parse_dates=['date'], date_parser=parse_date)

# 计算日期时间差异
data['date_diff'] = data['date'].diff()

# 定义一小时的时间间隔
one_hour = timedelta(hours=1)

# 检查时间间隔是否为1小时，忽略第一行的NaT
consistent_intervals = all((x == one_hour) for i, x in enumerate(data['date_diff']) if i != 0)

if consistent_intervals:
    print("All time intervals, except the first entry, are one hour.")
else:
    print("Time intervals are not consistently one hour.")
    # 打印不是一小时的时间间隔，并排除第一行
    inconsistent_rows = data[(data['date_diff'] != one_hour) & (data.index != 0)]
    print(inconsistent_rows[['date', 'date_diff']])

# 使用日期范围直接进行筛选
filtered_data = data[(data['date'] >= data_s) & (data['date'] <= data_e)]

# 检查这些列是否存在
if 'P' in filtered_data.columns and 'ETpot' in filtered_data.columns and 'Q' in filtered_data.columns and 'date' in filtered_data.columns:
    tm = filtered_data['date']
    p = filtered_data['P']
    etpot = filtered_data['ETpot']
    qobs = filtered_data['Q']
    temp = filtered_data['train_seq_len']
else:
    raise ValueError("Required columns are missing from the data.")

# 参数及初始状态
cd0, cs0, cw0, cv0, cg0, cq0 = params['cd'], params['cs'], params['cw'], params['cv'], params['cg'], params['cq']
state0 = np.array([140, 1000, 4, 1200, 0.1])
# 初始化模型
model = Walrus(cw=cw0, cv=cv0, cg=cg0, cq=cq0, cd=cd0, cs=cs0, initial_state=state0)

# 初始化状态数组，其中有和 qobs 同样多的时间点，和 state0 同样多的状态变量
states = np.zeros((len(qobs), len(state0)))
states[0, :] = state0

# 通过循环更新状态
for x0 in range(1, len(qobs)):
    states[x0, :] = model.statetran_fcn(dt=1, p_t=p[x0 - 1], etpot_t=etpot[x0 - 1])

# Labels for each state variable
state_labels = ['dv', 'dg', 'hq', 'hs', 'q']

# Call the function to plot the states
plot_time_series(states, state_labels)