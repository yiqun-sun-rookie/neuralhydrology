import pandas as pd
from datetime import datetime, timedelta
import os

def parse_date(date_str):
    """解析日期字符串，处理小时为'24'的情况转换为次日的'00'小时。"""
    try:
        return datetime.strptime(date_str, "%Y%m%d%H")
    except ValueError:
        if date_str.endswith("24"):
            date_without_hour = date_str[:-2]
            base_date = datetime.strptime(date_without_hour, "%Y%m%d")
            return base_date + timedelta(days=1)
        else:
            raise


def load_and_filter_data(file_path, start_date, end_date):
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    data = pd.read_csv(file_path, delim_whitespace=True, parse_dates=['date'], date_parser=parse_date)
    data['date_diff'] = data['date'].diff()
    one_hour = timedelta(hours=1)

    # 确认时间间隔是否为一小时
    if not all(x == one_hour for i, x in enumerate(data['date_diff']) if i != 0):
        print("Time intervals are not consistently one hour.")

    # 筛选指定日期范围内的数据
    return data[(data['date'] >= start_date) & (data['date'] <= end_date)]
