import numpy as np
from data_loader import load_and_filter_data
from params import params
from hydrologic.Walrus import Walrus
from hydrologic.WalrusTorch import WalrusTorch
from datetime import datetime
from hydrologic.utils import plot_time_series
import time
import torch
def main():
    file_path = r'/data\Hydrologic\PEQ_Regge_hour.txt'
    data_s = datetime(1999, 1, 1, 1)
    data_e = datetime(2000, 1, 3, 1)

    # 加载并筛选数据
    data = load_and_filter_data(file_path, data_s, data_e)

    # 确保必要的列存在
    if 'P' not in data or 'ETpot' not in data or 'Q' not in data:
        raise ValueError("Required columns are missing from the data.")

    # 提取时间序列数据
    tm = data['date']
    p = data['P']
    etpot = data['ETpot']
    qobs = data['Q']

    # 模型参数和初始状态
    cd0, cs0, cw0, cv0, cg0, cq0 = params['cd'], params['cs'], params['cw'], params['cv'], params['cg'], params['cq']
    state0 = np.array([140, 1000, 4, 1200, 0.1])
    model = Walrus(cw=cw0, cv=cv0, cg=cg0, cq=cq0, cd=cd0, cs=cs0, initial_state=state0)

    # 运行numpy模型并更新状
    start_time = time.time()
    states = np.zeros((len(qobs), len(state0)))
    states[0, :] = state0
    for x0 in range(1, len(qobs)):
        states[x0, :] = model.statetran_fcn(dt=1, p_t=p[x0 - 1], etpot_t=etpot[x0 - 1])
    numpy_time = time.time() - start_time
    print(f"Time taken for numpy model: {numpy_time}")


    # Convert numpy data to tensors and move to appropriate DEVICE
    model_torch = WalrusTorch(cw=cw0, cv=cv0, cg=cg0, cq=cq0, cd=cd0, cs=cs0, initial_state=state0)
    p_tensor = torch.tensor(p, dtype=torch.float32, device=model_torch.DEVICE)
    etpot_tensor = torch.tensor(etpot, dtype=torch.float32, device=model_torch.DEVICE)

    # 运行torch模型
    start_time = time.time()
    states_torch = torch.zeros((len(qobs), len(state0)), dtype=torch.float32)
    states_torch[0, :] = torch.tensor(state0, dtype=torch.float32, device=model_torch.DEVICE)
    for x0 in range(1, len(qobs)):
        states_torch[x0, :] = model_torch.forward(dt=1, p_t=p_tensor[x0 - 1], etpot_t=etpot_tensor[x0 - 1])

    torch_time = time.time() - start_time
    print(f"Time taken for torch model: {torch_time}")
    # 绘图
    # convert torch data to numpy
    states_torch = states_torch.cpu().detach().numpy()
    plot_time_series(states_torch, ['dv', 'dg', 'hq', 'hs', 'q'])


if __name__ == "__main__":
    main()
