import torch
from pyDOE import lhs
def latin_hypercube_sampling(num_samples, num_dimensions, lower_bounds, upper_bounds):
    # 生成拉丁超立方抽样样本
    lhc_samples = lhs(num_dimensions, samples=num_samples)

    # 将[0, 1]区间的样本映射到实际的参数范围
    range_tensor = upper_bounds - lower_bounds
    scaled_samples = torch.tensor(lhc_samples) * range_tensor + lower_bounds

    return scaled_samples
    # Usage
    # # 初始化状态变量和范围
    # num_loops = 10
    # state0 = torch.tensor([140.0, 1000.0, 4.0, 1200.0, 0.1], dtype=torch.float)
    # range = 0.1
    # lower_bounds = state0 * (1 - range)
    # upper_bounds = state0 * (1 + range)
    #
    # # 生成拉丁超立方采样的初始状态
    # state0_batch = latin_hypercube_sampling(num_loops, state0.size(0), lower_bounds, upper_bounds)
    #
    # print(state0_batch)
