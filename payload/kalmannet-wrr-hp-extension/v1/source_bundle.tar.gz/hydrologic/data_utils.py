import numpy as np
from datetime import datetime

def load_and_filter_data(filepath, start_date, end_date):
    # 模拟加载和筛选数据的过程
    return {'date': np.array([start_date + datetime.timedelta(hours=i) for i in range((end_date - start_date).total_seconds() // 3600 + 1)]),
            'P': np.random.rand(1000), 'ETpot': np.random.rand(1000), 'Q': np.random.rand(1000)}

def convert_time_to_hours(tm_series, start_date):
    return (tm_series - start_date).dt.total_seconds() / 3600
