import subprocess

def run_bottleneck(script_path, output_path):
    # 构建命令行命令
    command = f'python -m torch.utils.bottleneck {script_path}'
    # 使用 subprocess.run 来执行命令
    with open(output_path, "w") as file:
        result = subprocess.run(command, shell=True, stdout=file, text=True)

    # 输出已经保存到文件，也可以在此处处理错误
    if result.stderr:
        print("Errors:", result.stderr)

if __name__ == "__main__":
    # 指定你想要分析的脚本路径
    script_to_analyze = r'F:\github\pycharm\projects\kalmannet\Hydrologic\open_loop_walrus.py'
    output_path = r'F:\github\pycharm\projects\kalmannet\Hydrologic\optimize_torchmodel\bottleneck_results.txt'
    run_bottleneck(script_to_analyze, output_path)
