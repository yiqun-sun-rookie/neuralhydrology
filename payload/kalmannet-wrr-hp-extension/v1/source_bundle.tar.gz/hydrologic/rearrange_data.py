
import torch
def rearrange_data(p, lead_time=3):
    """
    Rearranges the input tensor `p` to form batches based on the specified lead time.

    Args:
        p (torch.Tensor): Input tensor of shape [1, 1, num_timesteps].
        lead_time (int): The lead time for forming batches.

    Returns:
        torch.Tensor: Rearranged tensor of shape [feasible_timesteps, lead_time].
    """
    num_timesteps = p.size(2)
    feasible_timesteps = num_timesteps - lead_time + 1

    p = p.squeeze(0).squeeze(0)
    p_batches = torch.stack([p[t:t+lead_time] for t in range(feasible_timesteps)], dim=0)

    return p_batches

# Example usage
p = torch.arange(1, 11).unsqueeze(0).unsqueeze(0)  # Shape: [1, 1, 10]
p_batches = rearrange_data(p)
print(p)
print(p_batches)
print(p_batches.shape)  # Should be [8, 3]
print(p_batches[1, :].shape)