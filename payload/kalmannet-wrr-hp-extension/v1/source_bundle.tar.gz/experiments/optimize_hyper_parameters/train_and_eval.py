import os, torch, math, optuna, sys
from pathlib import Path

# --- 路径修复: 将项目根目录添加到 sys.path ---
# 这确保无论从哪里调用此脚本，都能找到 knet 模块
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

# Fix for loading legacy modules that reference 'filters' module
filters_path = r"G:\github\pycharm\projects\filters"
if filters_path not in sys.path:
    sys.path.insert(0, filters_path)
# --- 路径修复结束 ---

from torch.utils.data import DataLoader

# 简洁模式：通过环境变量 QUIET=1 控制
_QUIET = os.getenv('QUIET', '0') == '1'
_DBG = os.getenv('KNET_DEBUG', '0') == '1'
def qprint(*a, **kw):
    if not _QUIET:
        print(*a, **kw)
def dprint(*a, **kw):
    if _DBG and not _QUIET:
        print(*a, **kw)

# ---- 全局确保旧路径别名 (供 DataLoader worker 进程 unpickle) ----
try:
    import knet.modules as _km
    sys.modules.setdefault('src.modules', _km)
except Exception:
    pass
from knet.utils.model_initialization_use_script_mdl_1 import initialize_system_model
from knet.dl.nn_kalman_clamp_5 import KalmanNet
from knet.pipelines.pipeline_clean_based_on_11 import Pipeline
from types import SimpleNamespace
# ===============================================================
# filters imports moved to lazy (inside build_trainable_kf) to avoid
# pulling in the broken dapper → patlib/struct_tools import chain
# when only build_args / build_knet are needed.

# ---------------- 新增: clamp 辅助函数 ----------------

def _to_tensor(v, device):
    """将标量 / list / tuple 转为 torch.tensor(float32)."""
    if isinstance(v, (list, tuple)):
        return torch.tensor([float(x) for x in v], dtype=torch.float32, device=device)
    try:
        return torch.tensor(float(v), dtype=torch.float32, device=device)
    except Exception:
        return torch.tensor([], dtype=torch.float32, device=device)


def _normalize_clamp_dict(cs_raw: dict | None, device: str):
    """规范化 clamp_scale 信息。
    预期结构 (可缺省):
      obs_diff_clamp: [lo, hi]
      obs_diff_scale: float
      obs_innov_diff_clamp: [lo, hi]
      obs_innov_diff_scale: float
      fw_update_diff_clamp: [[lo,hi], ...]  (每维一对)
      fw_update_diff_scale: [s1, s2, ...] 或标量
    返回: dict 或 None (若校验失败)
    """
    if not isinstance(cs_raw, dict):
        return None
    out = {}
    try:
        # 单/双端 clamp
        for k in [
            ("obs_diff_clamp", True),
            ("obs_diff_scale", False),
            ("obs_innov_diff_clamp", True),
            ("obs_innov_diff_scale", False),
        ]:
            name, is_pair = k
            if name in cs_raw:
                val = cs_raw[name]
                if is_pair and isinstance(val, (list, tuple)) and len(val) == 2:
                    out[name] = _to_tensor(val, device)
                elif not is_pair:
                    out[name] = _to_tensor(val, device)
        # fw_update (可能为多维)
        if "fw_update_diff_clamp" in cs_raw:
            fw_clamp = cs_raw["fw_update_diff_clamp"]
            if isinstance(fw_clamp, (list, tuple)) and all(isinstance(p, (list, tuple)) and len(p) == 2 for p in fw_clamp):
                out["fw_update_diff_clamp"] = torch.stack([_to_tensor(p, device) for p in fw_clamp])  # [D,2]
        if "fw_update_diff_scale" in cs_raw:
            fw_scale = cs_raw["fw_update_diff_scale"]
            if isinstance(fw_scale, (list, tuple)):
                out["fw_update_diff_scale"] = _to_tensor(fw_scale, device)
            else:
                out["fw_update_diff_scale"] = _to_tensor(fw_scale, device)
    except Exception:
        return None
    return out if out else None


def build_args(cfg, p_train, p_val):
    """
    把 YAML里的所有超参数展开为一个 SimpleNamespace。
    同时兼容KalmanNe和Trainable‑UKF 两种模型类型。
    """
    # ── 1. 数据集派生字段 ───────────────────────────────────────────
    train_seq_len  = p_train.shape[-1]
    seq_len_val    = p_val.shape[-1]
    batch_size     = cfg["dataloader"]["batch_size"]
    steps_per_epoch = max(1, math.ceil(len(p_train) / batch_size))

    # ── 2. YAML别名 ───────────────────────────────────────────────
    train_cfg   = cfg["training"]
    loss_cfg    = cfg["loss"]
    runtime_cfg = cfg["runtime"]
    instr_cfg   = cfg.get("instrumentation", {})

    model_type  = cfg["model"]["type"].lower()

    # KNet 专属
    knet_cfg = cfg["model"].get("knet", {})
    # UKF 专属
    ukf_cfg  = cfg["model"].get("trainable_ukf", {})

    # 读取调试开关：优先 runtime.debug_checks，其次环境变量 KF_DEBUG_CHECKS
    debug_checks = bool(runtime_cfg.get("debug_checks", False)) or (os.getenv("KF_DEBUG_CHECKS", "0") == "1")

    # ── 3. 组装 args ───────────────────────────────────────────────
    # Ensure in_mult_KNet is set for KalmanNet
    if model_type == "knet" and "in_mult_KNet" in knet_cfg:
        in_mult_KNet = knet_cfg.get("in_mult_KNet", 1)
    else:
        in_mult_KNet = 1  # Default value

    # 调试：打印从 cfg 读取的训练轮次
    # (移除冗余 debug: cfg.training.train_epochs)
    # Add in_mult_KNet to the namespace
    args = SimpleNamespace(
        # —— 数据长度 & 运行环境 ——
        train_seq_len   = train_seq_len,
        seq_len_val     = seq_len_val,
        steps_per_epoch = steps_per_epoch,
        n_batch         = batch_size,

        device   = runtime_cfg["device"],
        use_cuda = runtime_cfg["device"] == "cuda",
        use_amp  = runtime_cfg.get("use_amp", False),
        use_torch_compile = runtime_cfg.get("use_torch_compile", False),
        debug_checks = debug_checks,

        # —— 训练超参 ——
        model_type              = model_type,
        train_epochs            = train_cfg["train_epochs"],
        lr                      = train_cfg["learning_rate"],
        wd                      = train_cfg["weight_decay"],
        batch_display_interval  = train_cfg["batch_display_interval"],
        forecast_lead_time      = train_cfg["forecast_lead_time"], # NOTE: Fixed horizon. No dynamic curriculum logic in train loop.
        early_stopping          = train_cfg["early_stopping"],

        # —— Runtime 配置（包括 checkpoint 间隔） ——
    # checkpoint 保存间隔（若 YAML 未给出，则默认 20，而不是之前的 5）
    ckpt_interval           = runtime_cfg.get("ckpt_interval", 20),  # NOTE: will be cleaned to int below if tuple

        # —— 损失函数超参（直接展开 loss_cfg） ——
        **loss_cfg,
    )

    # === 模型专属字段 ===
    if model_type == "knet":
        # 安全获取 clamp 配置（可能旧 trial 缺失）
        clamp_cfg = knet_cfg.get("clamp_scale") or {}
        args.__dict__.update(
            d_hidden_Q           = knet_cfg.get("hidden_size", 32),
            d_hidden_Sigma       = knet_cfg.get("hidden_size", 32),
            num_layers_GRU_Q     = knet_cfg.get("num_layers", 1),
            num_layers_GRU_Sigma = knet_cfg.get("num_layers", 1),
            num_layers_GRU_S     = knet_cfg.get("num_layers", 1),
            dropout_prob         = knet_cfg.get("dropout", 0.0),
            in_mult_KNet         = knet_cfg.get("in_mult", 5),
            out_mult_KNet        = knet_cfg.get("out_mult", 5),
            activation_function  = knet_cfg.get("activation", "relu"),
            enable_clamp_scale   = bool(clamp_cfg.get("enable", False)),
            clamp_scale_info     = clamp_cfg if isinstance(clamp_cfg, dict) else {},
            state_bounds         = knet_cfg.get("state_bounds", {}),
        )
    elif model_type == "trainable_ukf":
        # 直接把 ukf_cfg 整包塞进 args，后面 builder 自行解析
        args.ukf_cfg = ukf_cfg
    else:
        raise ValueError(f"Unknown model.type = {model_type}")

    # 二次调试：构造后再次输出
    # (移除冗余 debug: args.train_epochs)
    # 修复潜在 tuple 形式 (20,) 影响取模：若 ckpt_interval 是长度1元组则取其值
    if isinstance(args.ckpt_interval, tuple) and len(args.ckpt_interval) == 1:
        args.ckpt_interval = args.ckpt_interval[0]

    # ==== 注入 instrumentation 参数 (供训练循环直接使用) ====
    args.perf_interval        = int(instr_cfg.get('perf_interval', 0))
    args.perf_gpu             = bool(instr_cfg.get('perf_gpu', False))
    args.mem_advice           = bool(instr_cfg.get('mem_advice', False))
    args.no_tqdm              = bool(instr_cfg.get('no_tqdm', False))
    args.bottleneck_analysis  = bool(instr_cfg.get('bottleneck_analysis', False))
    args.loader_probe_steps   = int(instr_cfg.get('loader_probe_steps', 0))
    args.metrics_interval     = int(instr_cfg.get('metrics_interval', 1))

    return args


def build_knet(sys_model, args):
    knet = KalmanNet()
    # 兼容旧 args 缺失 clamp 字段
    enable_clamp = bool(getattr(args, 'enable_clamp_scale', False))
    clamp_dict_raw = getattr(args, 'clamp_scale_info', {}) if enable_clamp else {}
    normalized = _normalize_clamp_dict(clamp_dict_raw, getattr(args, 'device', 'cpu')) if enable_clamp else None

    if enable_clamp and normalized is None:
        print('[Warn] clamp_scale 已启用但配置不完整/无效：自动关闭。')
        enable_clamp = False

    knet.debug_enabled = False
    knet.enable_clamp_scale = enable_clamp

    if enable_clamp:
        knet.clamp_scale_info = normalized  # 直接存放规范化后的 tensor 字典

    # KalmanNet 构建完全依赖 args
    knet.build_nn(sys_model, args)
    knet.to(args.device)

    # ========== torch.compile 优化 ==========
    if getattr(args, 'use_torch_compile', False):
        print("[INFO] Applying torch.compile optimization to KNet model...")
        try:
            knet = torch.compile(knet, mode='default')
            print("[INFO] torch.compile applied successfully!")
        except Exception as e:
            print(f"[WARNING] torch.compile failed: {e}. Continuing without compilation.")

    return knet


def _as_diag_tensor(raw, size, device):
    """
    raw: 标量 / list / tuple ；元素可以是 str 或数字
    返回 [size, size] 对角张量
    """
    # 1) 先把 raw → python list[float] 或 float
    if isinstance(raw, str):
        raw = float(raw)
    elif isinstance(raw, (list, tuple)):
        raw = [float(x) for x in raw]

    v = torch.as_tensor(raw, dtype=torch.float32, device=device)
    if v.dim() == 0:
        v = v.repeat(size)

    return torch.diag(v)



def build_trainable_kf(cfg, sys_model, args):
    """构造 Batch‑UKF ➟ (可学习) Trainable‑UKF，并兼容 Pipeline。"""
    # --- lazy imports (avoid dapper chain at module level) ---
    from filters.filter.batch.my_version.batch_unscentedkalmanfilter_gpu import BatchUnscentedKalmanFilterGPU
    from filters.adapt_trainable_kf.adaptive_ukf import TrainableUKF
    from filters.filter.non_batch.kalman import MerweScaledSigmaPoints
    from filters.da_coupler.walrus_batch import fx_walrus_batch, hx_walrus_batch

    dim_x, dim_z = sys_model.m, sys_model.n
    device = args.device

    # 1) 生成 sigma 点权重
    pts = MerweScaledSigmaPoints(n=dim_x, alpha=0.6874, beta=2, kappa=0)
    pts.c = pts.alpha ** 2 * (pts.n + pts.kappa)

    # 2) 基础 UKF（批量）
    base = BatchUnscentedKalmanFilterGPU(
        dim_x=dim_x,
        dim_z=dim_z,
        dt=1.0,
        hx=lambda sig: hx_walrus_batch(sig, sys_model=sys_model),
        fx=lambda sig, dt: fx_walrus_batch(sig, dt, sys_model=sys_model),
        points=pts,
        batch_size=args.n_batch,
        device=device
    )

    # -------- 初值 ----------
    # 2.1 状态
    x0 = torch.tensor(cfg["system_model"]["state0"], device=device)          # [m]
    base.x = x0.unsqueeze(0).repeat(args.n_batch, 1)                        # [B,m]

    # 2.2 协方差 P0
    p0_scale = cfg["system_model"]["p0_scale"]           # 标量或向量
    P0 = _as_diag_tensor(p0_scale, dim_x, device)        # [m,m]
    jitter = 1e-6 * torch.eye(dim_x, device=device)      # 防止奇异
    base.P = (P0 + jitter).unsqueeze(0).repeat(args.n_batch, 1, 1)

    # 2.3 过程/观测噪声
    q_init = args.ukf_cfg.get("q_init", 1e-3)            # 标量或向量
    r_init = args.ukf_cfg.get("r_init", 1e-4)

    # Batch-UKF expects single [dim, dim] covariances; broadcasting is handled internally.
    base.Q = _as_diag_tensor(q_init, dim_x, device)
    base.R = _as_diag_tensor(r_init, dim_z, device)

    # 3) 包装为可训练 UKF
    model = TrainableUKF(
        base_filter   = base,
        system_model  = sys_model,
        learn_q       = args.ukf_cfg.get("learn_q", False),
        learn_r       = args.ukf_cfg.get("learn_r", False),
        cov_type      = args.ukf_cfg.get("cov_type", "diag"),
        adapt_online  = args.ukf_cfg.get("adapt_online", False),
        q_init        = q_init,
        r_init        = r_init,
        p0_scale=cfg["system_model"]["p0_scale"],  # <—— 新增
        device        = device
    )

    # ---- 防止 "无可训练参数" 报错 ----
    if sum(p.numel() for p in model.parameters()) == 0:
        model.dummy = torch.nn.Parameter(torch.zeros(1))

    # ---- 与 Pipeline 对接的小属性 ----
    model.batch_size        = args.n_batch
    model.update_mode       = True
    model.init_hidden_KNet  = lambda: None

    model = model.to(device)

    # ========== torch.compile 优化 ==========
    # Torch.compile currently breaks Trainable-UKF (FakeTensor broadcast). Force disable.
    if getattr(args, 'use_torch_compile', False):
        print("[WARN] torch.compile disabled for Trainable-UKF due to broadcast issues.")
        args.use_torch_compile = False

    return model

def train_and_eval0(
    cfg: dict,
    trial_number: int = -1,
    work_dir: str | None = None,
    resume_checkpoint: str | None = None,
    optuna_trial: optuna.trial.Trial | None = None,
):
    """Run ONE train+val cycle and return *negative* NSE for Optuna."""

    # ---- 0. 路径 & 设备 & 兼容性修复 --------------------------------
    # 动态创建路径别名，解决因项目重构（src->knet）导致 torch.load 失败的问题
    try:
        import knet.modules
        sys.modules['src.modules'] = knet.modules
        # 如果还有更深层的模块找不到，可以继续添加，例如：
        # import knet.modules.utils
        # sys.modules['src.modules.utils'] = knet.modules.utils
    except ImportError:
        print("Warning: Could not create 'src.modules' alias. This is fine if you are not using old data files.")

    base_path = cfg["data"]["base_path"]
    torch.backends.cudnn.benchmark = cfg["runtime"].get("cudnn_benchmark", True)

    # ---- 1. 构造 DataLoader ----------------------------
    loaders = {}
    # ===== batch_size 覆盖逻辑 =====
    try:
        bs_env = os.getenv('BATCH_SIZE', '').strip()
        if bs_env:
            new_bs = int(bs_env)
            old_bs = cfg['dataloader']['batch_size']
            cfg['dataloader']['batch_size'] = new_bs
            print(f"[Override] BATCH_SIZE 环境变量覆盖 batch_size: {old_bs} -> {new_bs}")
        else:
            scale_env = os.getenv('BATCH_SCALE', '').strip()
            if scale_env:
                scale = float(scale_env)
                if scale > 1.01:
                    old_bs = cfg['dataloader']['batch_size']
                    new_bs = int(old_bs * scale)
                    cfg['dataloader']['batch_size'] = new_bs
                    print(f"[Override] BATCH_SCALE={scale} 应用 batch_size: {old_bs} -> {new_bs}")
    except Exception as e:
        print(f"[Override][Warn] 处理 BATCH_SIZE/BATCH_SCALE 失败: {e}")
    for split in ("train", "val"):
        ds_path = cfg["data"]["dataset_path"][split]
        # 一律映射到 CPU，避免在无 GPU 的节点反序列化到 CUDA 导致报错
        ds = torch.load(ds_path, map_location='cpu')
        loaders[split] = DataLoader(
            ds,
            batch_size  = cfg["dataloader"]["batch_size"],
            shuffle     = cfg["dataloader"]["shuffle"][split],
            num_workers = cfg["dataloader"]["num_workers"],
            pin_memory  = cfg["dataloader"]["pin_memory"],
        )

    # ---- 2. args & 模型 -------------------------------
    args = build_args(cfg, loaders["train"].dataset.p, loaders["val"].dataset.p)
    sys_model = initialize_system_model(args.train_seq_len, args.seq_len_val, args.device)

    if cfg["model"]["type"] == "knet":
        update_model = build_knet(sys_model, args)
    elif cfg["model"]["type"] == "trainable_ukf":
        update_model = build_trainable_kf(cfg, sys_model, args)
    else:
        raise ValueError("Unknown model.type")

    # ---- 3. Pipeline ----------------------------------
    if work_dir is None:
        work_dir = os.path.join(base_path, "results_tmp")
    pipe = Pipeline(work_dir)
    pipe.set_sys_model(sys_model)
    pipe.set_knet_model(update_model)
    pipe.set_train_params(args)
    pipe.use_amp = cfg["runtime"].get("use_amp", False)

    # ---- 4. 训练（透传 optuna_trial） -----------------
    _, _, _val_bp_loss, val_disp_loss = pipe.train(
        loaders["train"],
        loaders["val"],
        resume_checkpoint=resume_checkpoint,
        optuna_trial=optuna_trial          # ★ 关键
    )

    # ---- 5. 指标 --------------------------------------
    nse = val_disp_loss.get("nse", 0.0)
    best_model_path = os.path.join(pipe.train_path, "best_model.pt")
    torch.cuda.empty_cache()
    return -float(nse), best_model_path     # Optuna 以最小化为目标

# =========================  核心修改：train_and_eval  =========================

"""加速策略说明 (逐步启用):
1) 数据集缓存 (_DATASET_CACHE): 避免多组合重复 torch.load I/O。
   通过环境变量 DISABLE_DATASET_CACHE=1 可关闭。
后续可按需继续加入: num_workers 动态调优 / model compile 等。
"""

# 简单的进程内数据集缓存
_DATASET_CACHE: dict[str, object] = {}

def _load_dataset_cached(path: str):
    if os.getenv('DISABLE_DATASET_CACHE', '0') == '1':
        # 始终 map 到 CPU，避免在 CPU 机器加载到 CUDA
        return torch.load(path, map_location='cpu', weights_only=False)
    ds = _DATASET_CACHE.get(path)
    if ds is not None:
        return ds
    # 始终 map 到 CPU，避免在 CPU 机器加载到 CUDA
    ds = torch.load(path, map_location='cpu', weights_only=False)
    _DATASET_CACHE[path] = ds
    qprint(f"[Cache] Loaded dataset -> {path} (cached)")
    return ds

def train_and_eval(
    cfg: dict,
    *,
    trial_number: int = -1,
    work_dir: str | None = None,
    resume_checkpoint: str | None = None,
    optuna_trial = None,
    # --- LR‑finder 专用参数 ---
    lr_range_mode: bool = False,
    lr_start: float = 1e-6,
    lr_end: float = 1e-1,
    num_iter: int = 500,
    ds_path: str = None,
    val_ds_path: str = None,
):
    """新增 lr_range_mode：仅跑 num_iter 个 batch，指数增大学习率并记录 loss。
       返回 (losses, lrs)；否则与旧版一致返回 (‑nse, best_model_path)。"""
    # ----------- 0. 兼容旧 pickle 模块路径 ------------
    try:
        import knet.modules
        sys.modules.setdefault('src.modules', knet.modules)
    except ImportError:
        pass

    # ----------- 1. DataLoader 构造 -------------------
    if _DBG:
        try:
            dprint(f"[Debug][train_and_eval] incoming cfg.training.train_epochs={cfg.get('training',{}).get('train_epochs')}")
        except Exception:
            pass
    loaders = {}
    # 自适应 num_workers：若配置为 0/None 且未禁用，则按 CPU 核数一半取 1~8 区间
    import multiprocessing, platform
    base_workers = cfg['dataloader'].get('num_workers', 0)
    if (base_workers in (0, None)) and os.getenv('DISABLE_AUTO_WORKERS','0') != '1':
        try:
            cpu_cnt = multiprocessing.cpu_count()
        except Exception:
            cpu_cnt = 2
        auto_workers = max(1, min(8, cpu_cnt // 2))
    else:
        auto_workers = int(base_workers or 0)
    if base_workers != auto_workers:
        qprint(f"[AutoWorkers] num_workers: {base_workers} -> {auto_workers}")
    pin_mem_cfg = bool(cfg['dataloader'].get('pin_memory', False))
    if pin_mem_cfg is False and torch.cuda.is_available() and os.getenv('DISABLE_PIN_MEMORY','0') != '1':
        # 对 CUDA 场景自动打开 pin_memory (若用户未显式设定并未禁用)
        pin_memory = True
        qprint("[AutoWorkers] pin_memory: False -> True (CUDA detected)")
    else:
        pin_memory = pin_mem_cfg

    # ===== batch_display_interval 覆盖逻辑（减少 batch 级打印频率） =====
    try:
        bdi_env = os.getenv('BATCH_LOG_INTERVAL', os.getenv('BATCH_DISPLAY_INTERVAL', '')).strip()
        if bdi_env:
            new_bdi = max(1, int(bdi_env))
            old_bdi = cfg['training'].get('batch_display_interval')
            cfg['training']['batch_display_interval'] = new_bdi
            qprint(f"[Override] BATCH_LOG_INTERVAL 覆盖 batch_display_interval: {old_bdi} -> {new_bdi}")
    except Exception as e:
        qprint(f"[Override][Warn] 处理 BATCH_LOG_INTERVAL 失败: {e}")

    for split in ("train", "val"):
        ds_path = cfg["data"]["dataset_path"][split]
        ds = _load_dataset_cached(ds_path)
        # 诊断打印：样本键与长度
        first_sample = None
        try:
            first_sample = ds[0]
            if isinstance(first_sample, dict):
                qprint(first_sample.keys())
        except Exception:
            pass
        if _DBG or cfg["runtime"].get("debug_checks", False) or (os.getenv("KF_DEBUG_CHECKS", "0") == "1"):
            try:
                dprint(f"[Debug] {split} dataset length = {len(ds)}")
                if first_sample is not None and isinstance(first_sample, dict):
                    for _k,_v in first_sample.items():
                        if hasattr(_v,'shape'):
                            dprint(f"[Debug] {split} sample[{_k}] device={getattr(_v,'device',None)} shape={getattr(_v,'shape',None)}")
            except Exception as e:
                dprint(f"[Debug] Failed to inspect {split} dataset: {e}")

        # 如果样本里已经是 CUDA Tensor，则禁止 pin_memory 并强制 num_workers=0（避免跨进程 + pin_memory 冲突）
        contains_cuda = False
        try:
            if isinstance(first_sample, dict):
                for _v in first_sample.values():
                    if hasattr(_v, 'is_cuda') and getattr(_v, 'is_cuda', False):
                        contains_cuda = True
                        break
        except Exception:
            pass
        local_pin_memory = pin_memory
        local_workers = auto_workers
        if contains_cuda:
            if pin_memory:
                qprint("[AutoWorkers][PinMemory] 样本已在 CUDA 上，禁用 pin_memory 避免 RuntimeError")
            local_pin_memory = False
            if auto_workers > 0:
                qprint("[AutoWorkers][CUDA Dataset] 将 num_workers 设为 0 以避免多进程处理 GPU 张量")
            local_workers = 0
        # worker init: 确保在子进程内也创建 'src.modules' 别名
        def _worker_init(_):  # noqa: ANN001
            try:
                import types as _types, importlib as _importlib, sys as _sys
                km = _importlib.import_module('knet.modules')
                _sys.modules.setdefault('src', _types.ModuleType('src'))
                _sys.modules.setdefault('src.modules', km)
                # 兼容 data_preprocessor 子模块
                try:
                    _importlib.import_module('src.modules.data_preprocessor.windowed_time_series')
                except Exception:
                    pass
            except Exception:
                pass
        try:
            loaders[split] = DataLoader(
                ds,
                batch_size  = cfg["dataloader"]["batch_size"],
                shuffle     = cfg["dataloader"]["shuffle"][split],
                num_workers = local_workers,
                pin_memory  = local_pin_memory,
                worker_init_fn = _worker_init,
            )
        except ModuleNotFoundError as e:
            # 典型: worker 进程中找不到旧模块路径 ('src.modules')
            print(f"[AutoWorkers][Fallback] DataLoader workers failed ({e}); 回退 num_workers=0")
            loaders[split] = DataLoader(
                ds,
                batch_size  = cfg["dataloader"]["batch_size"],
                shuffle     = cfg["dataloader"]["shuffle"][split],
                num_workers = 0,
                pin_memory  = local_pin_memory,
                worker_init_fn = _worker_init,
            )
            auto_workers = 0

    # ----------- 2.  args & 模型 ----------------------
    args = build_args(cfg, loaders["train"].dataset.p, loaders["val"].dataset.p)
    device = args.device
    sys_model = initialize_system_model(args.train_seq_len, args.seq_len_val, device)

    if cfg["model"]["type"] == "knet":
        update_model = build_knet(sys_model, args)
    elif cfg["model"]["type"] == "trainable_ukf":
        update_model = build_trainable_kf(cfg, sys_model, args)
    else:
        raise ValueError("Unknown model.type")

    # ================== LR‑finder Branch ==================
    if lr_range_mode:
        # 1. 构建 Pipeline
        if work_dir is None:
            work_dir = os.path.join(cfg["data"]["base_path"], "results_tmp_lr_finder")
        pipe = Pipeline(work_dir)
        pipe.set_sys_model(sys_model)
        pipe.set_knet_model(update_model)
        # 在 LR-Finder 模式下，我们手动设置 optimizer 的初始学习率
        args.lr = lr_start
        pipe.set_train_params(args)
        pipe.use_amp = cfg["runtime"].get("use_amp", False)

        # 2. 调用封装好的 LR-Finder 函数
        losses, lrs = pipe.run_lr_finder(
            loaders["train"],
            num_iter=num_iter,
            lr_start=lr_start,
            lr_end=lr_end,
        )
        torch.cuda.empty_cache()
        return losses, lrs

    # ================== 常规训练分支 =====================
    if work_dir is None:
        work_dir = os.path.join(cfg["data"]["base_path"], "results_tmp")
    pipe = Pipeline(work_dir)
    pipe.set_sys_model(sys_model)
    pipe.set_knet_model(update_model)
    pipe.set_train_params(args)
    pipe.use_amp = cfg["runtime"].get("use_amp", False)

    _ , _, val_bp_loss, val_disp_loss = pipe.train(
        loaders["train"],
        loaders["val"],
        resume_checkpoint=resume_checkpoint,
        optuna_trial=optuna_trial,
    )

    # 诊断保护：避免 NoneType 报错
    if val_disp_loss is None:
        dprint("[Debug] val_disp_loss is None; likely no epoch was executed. Returning NaN NSE.")
        nse = float('nan')
    else:
        nse = val_disp_loss.get("nse", 0.0)

    best_model_path = os.path.join(pipe.train_path, "best_model.pt")
    torch.cuda.empty_cache()
    return -float(nse), best_model_path
