import os
import sys
import math
import yaml
import itertools
import argparse
import json
import hashlib
import random
import time
from pathlib import Path
from datetime import datetime

# --- 临时兼容补丁改进版 -------------------------------------------------------
# 目的: 仅在真实 torch.onnx._internal.exporter 存在但缺少特定属性时补齐, 不再提前伪造整个模块,
# 以避免后续官方 torch 导入时出现 ONNXProgram 等符号缺失。
# 若未来升级后官方已提供全部属性, 本块将成为空操作。
try:
    _need_names = ["DiagnosticOptions", "ExportOptions"]
    _patched = []
    try:
        import torch  # noqa: F401
        from torch.onnx._internal import exporter as _real_exporter  # type: ignore
        for _nm in _need_names:
            if not hasattr(_real_exporter, _nm):
                setattr(_real_exporter, _nm, type(_nm, (), {}))
                _patched.append(_nm)
        if _patched:
            try:
                if hasattr(_real_exporter, '__all__'):
                    for _p in _patched:
                        if _p not in _real_exporter.__all__:  # type: ignore[attr-defined]
                            _real_exporter.__all__.append(_p)  # type: ignore[attr-defined]
            except Exception:
                pass
            print(f"[Compat] exporter 补齐缺失符号: {','.join(_patched)}")
    except Exception as _inner_e:
        # 不再伪造模块; 若导入失败交由后续真实 import 再处理, 只打印一次提示即可
        print(f"[Compat] 跳过补丁 (torch.onnx._internal.exporter 导入失败): {_inner_e}")
except Exception as _compat_e:  # 兜底, 不影响后续流程
    print("[Compat] 兼容补丁执行异常:", _compat_e)
# ------------------------------------------------------------------------------

# 允许 OpenMP 多次加载（若环境里已有类似设置可去掉）
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ.setdefault("PYTHONUTF8", "1")

# 保障项目根路径在 sys.path
PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# 兼容外部 filters 路径（与 optuna 脚本一致的最小版本）
def _add_ext_paths():
    ext_filters = Path(r"F:\\github\\pycharm\\projects\\filters")
    if ext_filters.is_dir() and str(ext_filters) not in sys.path:
        sys.path.insert(0, str(ext_filters))
    nested = ext_filters / 'filters'
    if nested.is_dir() and str(nested) not in sys.path:
        sys.path.insert(0, str(nested))
    shim_dir = PROJECT_ROOT / 'filter'
    if shim_dir.is_dir() and str(PROJECT_ROOT) not in sys.path:
        sys.path.insert(0, str(PROJECT_ROOT))
    # silent alias
    if 'filter' not in sys.modules:
        try:
            import filters.filter  # noqa
            import types
            sys.modules['filter'] = sys.modules.get('filters.filter', types.ModuleType('filter'))
        except Exception:
            pass
_add_ext_paths()

# ---- 兼容旧 pickle: 提供 'src.modules' 别名 (Windows 多进程 DataLoader unpickle 需要) ----
try:
    import knet.modules as _km
    import types as _types, sys as _sys
    # 确保 'src' 是一个包占位
    if 'src' not in _sys.modules:
        _sys.modules['src'] = _types.ModuleType('src')
    _sys.modules.setdefault('src.modules', _km)
except Exception:
    pass

# (已迁移) 强制运行索引改由配置文件 kalman_hybrid_config.yaml -> grid.force_run_indices 提供
FORCE_RUN_INDICES: list[int] = []  # 这里保留占位; 实际会在 main() 里从 cfg 读取覆盖

# 延迟导入 train_and_eval，避免仅 --show-space / --export-* 时要求安装 torch

# ---------------------- 工具函数 ----------------------

def logspace_list(low: float, high: float, num: int):
    if num <= 1:
        return [low]
    log_low, log_high = math.log10(low), math.log10(high)
    return [10 ** (log_low + i * (log_high - log_low) / (num - 1)) for i in range(num)]

def hash_params(d: dict) -> str:
    return hashlib.md5(json.dumps(d, sort_keys=True).encode()).hexdigest()[:8]

def _fmt_lr(lr: float) -> str:
    """将学习率格式化为紧凑字符串: 0.001 -> 1e-3, 0.01 -> 0p01, 0.000056 -> 5p6e-5"""
    if lr >= 1e-2:  # 用小数形式, 替换小数点
        s = f"{lr:.4f}".rstrip('0').rstrip('.')
        return s.replace('.', 'p')
    # 科学计数法
    s = f"{lr:.0e}"  # 1e-3  或 6e-5
    # 拆分基数和指数
    base, exp = s.split('e')
    if '.' in base:
        base = base.rstrip('0').rstrip('.')
    base = base.replace('.', 'p')
    return f"{base}e{exp}"  # 1e-3 / 6e-5 / 5p6e-5

def build_run_dir_name(index: int, params: dict, uid: str) -> str:
    """生成更直观的目录名: idx0003_lr1e-3_hs64_nl2_mult5
    去掉hash码，简化目录名。"""
    lr_s = _fmt_lr(params['lr'])
    hs = params['hidden_size']
    nl = params['num_layers']
    mult = params['in_out_mult']
    return f"idx{index:04d}_lr{lr_s}_hs{hs}_nl{nl}_mult{mult}"

# ---------------------- 主函数 ----------------------

def parse_args():
    p = argparse.ArgumentParser(
        description="KNet 网格搜索 (不使用 Optuna)，支持分片以便 CPU/GPU 并行"
    )
    p.add_argument('--config', type=str, default=str(Path(__file__).with_name('kalman_hybrid_config.yaml')),
                   help='基础配置 YAML')
    p.add_argument('--outdir', type=str, default='grid_knet', help='结果基目录')
    p.add_argument('--device', type=str, default=None, help='覆盖 config.runtime.device (cpu/cuda)')
    p.add_argument('--epochs', type=int, default=None, help='覆盖 config.training.train_epochs')
    p.add_argument('--lr-list', type=str, default=None,
                   help='逗号分隔的学习率列表; 若未给且 search_space.lr 为范围则自动对数取 5 点')
    p.add_argument('--lr-num', type=int, default=5, help='当需要从范围生成学习率网格时的点数')
    p.add_argument('--lr-sampling', type=str, default='logspace', choices=['logspace','lhs'],
                   help='当 lr 使用 low/high 范围时的取点策略: logspace = 等距对数; lhs = 拉丁超立方(对数坐标分层随机)')
    p.add_argument('--seed', type=int, default=None, help='可选: 当使用 lhs 采样时设定随机种子以复现')
    p.add_argument('--shard-index', type=int, default=0, help='当前分片索引')
    p.add_argument('--num-shards', type=int, default=1, help='总分片数')
    p.add_argument('--resume', action='store_true', help='已完成(有 best_model.pt 且有 metrics.json)则跳过')
    p.add_argument('--no-resume', action='store_true', help='不从 checkpoint 恢复，始终从头开始')
    p.add_argument('--show-space', action='store_true', help='打印参数轴取值后直接退出 (不生成组合列表)')
    p.add_argument('--list-combos', action='store_true', help='打印所有组合(全局索引与参数)后退出')
    p.add_argument('--export-space', type=str, default=None,
                   help='将参数轴信息写入指定文件后退出 (例如 axes.txt)')
    p.add_argument('--export-combos', type=str, default=None,
                   help='将全部组合写入指定文件后退出 (支持 .txt 或 .jsonl)')
    p.add_argument('--debug-train-epochs', action='store_true', help='打印 train_epochs 相关调试信息 (文件行/哈希)')
    p.add_argument('--include', type=str, default=None,
                   help='仅运行指定全局索引集合, 语法: 1,5,8-12,20 (在分片过滤之后再次过滤)')
    p.add_argument('--include-file', type=str, default=None,
                   help='文本文件, 每行一个索引或区间 (如 3 或 10-15); 与 --include 合并取并集')
    p.add_argument('--auto-suffix-outdir', action='store_true',
                   help='根据 device 自动给 outdir 添加 _cpu 或 _gpu 以避免 CPU/GPU 进程写同一目录')
    p.add_argument('--alias-file', type=str, default=None,
                   help='可选: 自定义索引别名文件, 每行: <index> <alias> (空白分隔, 支持#注释)')
    p.add_argument('--alias-mode', type=str, default='alias+auto', choices=['alias','alias+auto','auto'],
                   help='alias: 仅使用别名作为目录名; alias+auto: 别名前缀 + 原有自动命名; auto: (默认) 不使用别名')
    p.add_argument('--combos-file', type=str, default=None,
                   help='从先前导出的组合文件( all_combos.txt 或 .jsonl )加载固定组合, 忽略当前 search_space。')
    p.add_argument('--groups', type=str, default=None,
                   help='语法同 --include, 只是更语义化别名；若同时提供 --include 与 --groups 取并集')
    p.add_argument('--simple-two-way-split', action='store_true',
                   help='简化模式: 若未显式设置 num-shards>1 则根据 device 自动使用 2 路切片: cuda->(2,0) cpu->(2,1)')
    p.add_argument('--ignore-shards', action='store_true',
                   help='忽略分片过滤，直接使用全部组合，再应用 include/groups 过滤 (或环境变量 IGNORE_SHARDS=1)')
    p.add_argument('--ckpt-interval', type=int, default=None,
                   help='覆盖 runtime.ckpt_interval (仅在 YAML 未显式设置或想临时调整时)')
    p.add_argument('--onnx-stub', action='store_true',
                   help='在导入 torch.onnx 前强制注入 exporter.DiagnosticOptions 占位符 (旧版本 torch 兼容调试)')
    p.add_argument('--quiet', action='store_true',
                   help='简洁日志：仅输出关键进度与告警/错误')
    p.add_argument('--debug-verbose', action='store_true',
                   help='强制开启详细调试输出(等价设置环境变量 KNET_DEBUG=1)，优先于 --quiet')
    p.add_argument('--minimal', action='store_true',
                   help='超简日志：仅打印起始、每个组合 Done/Fail、最终汇总')
    p.add_argument('--log-level', type=str, default=None, 
                   choices=['verbose', 'normal', 'compact', 'minimal', 'ultra_quiet'],
                   help='日志级别控制')
    p.add_argument('--require-gpu', action='store_true',
                   help='若最终 device 解析为 cpu 则报错退出 (防止意外 CPU 回退创建 _cpu 目录)')
    # --- 分段训练方案A (简单按固定块续跑) ---
    return p.parse_args()


def lhs_log_list(low: float, high: float, num: int, seed: int | None = None):
    """在 log10 空间做拉丁超立方分层抽样。返回升序列表。"""
    if num <= 1:
        return [low]
    if seed is not None:
        rnd_state = random.Random(seed)
    else:
        rnd_state = random
    log_low, log_high = math.log10(low), math.log10(high)
    step = (log_high - log_low) / num
    samples = []
    for i in range(num):
        a = log_low + i * step
        b = log_low + (i + 1) * step
        v = 10 ** (rnd_state.uniform(a, b))
        samples.append(v)
    samples.sort()
    return samples

def build_grid(cfg, args):
    # 优先使用专用 grid 空间；兼容旧字段 'search_space'
    sp = cfg.get('search_space_grid') or cfg.get('search_space', {})

    # learning rate 处理
    if args.lr_list:
        lr_values = [float(x) for x in args.lr_list.split(',') if x.strip()]
    else:
        lr_sp = sp.get('lr', {})
        # 1) 明确给定离散值
        if 'values' in lr_sp and isinstance(lr_sp['values'], (list, tuple)):
            lr_values = [float(x) for x in lr_sp['values']]
        else:
            # 2) 范围模式 (low/high) + 采样策略 (logspace / lhs)
            low = float(lr_sp.get('low', 1e-5))
            high = float(lr_sp.get('high', 1e-3))
            sampling = lr_sp.get('sampling', args.lr_sampling)  # YAML 可覆盖 CLI
            if sampling == 'lhs':
                lr_values = lhs_log_list(low, high, args.lr_num, seed=args.seed)
            else:  # 默认 logspace
                lr_values = logspace_list(low, high, args.lr_num)
    # 其它离散网格
    hidden_sizes = sp.get('hidden_size', {}).get('values', [cfg['model']['knet']['hidden_size']])
    num_layers_list = sp.get('num_layers', {}).get('values', [cfg['model']['knet']['num_layers']])
    in_out_mult_list = sp.get('in_out_mult', {}).get('values', [cfg['model']['knet']['in_mult']])

    axes = {
        'lr': [float(x) for x in lr_values],
        'hidden_size': [int(x) for x in hidden_sizes],
        'num_layers': [int(x) for x in num_layers_list],
        'in_out_mult': [int(x) for x in in_out_mult_list],
    }
    grid = [
        {
            'lr': float(lr),
            'hidden_size': int(hs),
            'num_layers': int(nl),
            'in_out_mult': int(mult),
        }
        for lr, hs, nl, mult in itertools.product(
            axes['lr'], axes['hidden_size'], axes['num_layers'], axes['in_out_mult']
        )
    ]
    return grid, axes

def _parse_index_spec(text: str):
    """解析形如 '1,5,7-10' 的索引说明, 返回集合(int)。非法片段忽略。"""
    out = set()
    if not text:
        return out
    for part in text.split(','):
        part = part.strip()
        if not part:
            continue
        if '-' in part:
            a,b = part.split('-',1)
            try:
                a_i = int(a); b_i = int(b)
                if a_i <= b_i:
                    out.update(range(a_i, b_i+1))
                else:
                    out.update(range(b_i, a_i+1))
            except ValueError:
                continue
        else:
            try:
                out.add(int(part))
            except ValueError:
                continue
    return out

def _load_include_file(path: str | None):
    if not path:
        return set()
    p = Path(path)
    if not p.is_file():
        print(f"[Warn] include-file 不存在: {path}")
        return set()
    items = []
    for line in p.read_text(encoding='utf-8').splitlines():
        line=line.strip()
        if not line or line.startswith('#'):
            continue
        items.append(line)
    return _parse_index_spec(','.join(items))


def _load_aliases(path: str | None):
    if not path:
        return {}
    p = Path(path)
    if not p.is_file():
        print(f"[Warn] alias-file 不存在: {path}")
        return {}
    aliases = {}
    for ln, line in enumerate(p.read_text(encoding='utf-8').splitlines(), start=1):
        raw = line.strip()
        if not raw or raw.startswith('#'):
            continue
        parts = raw.split()
        if len(parts) < 2:
            print(f"[alias-file] 忽略格式不完整行 {ln}: {raw}")
            continue
        try:
            idx = int(parts[0])
        except ValueError:
            print(f"[alias-file] 索引非整数, 行 {ln}: {parts[0]}")
            continue
        alias = parts[1]
        # 清理别名为安全子集
        import re
        alias_clean = re.sub(r'[^A-Za-z0-9._-]', '_', alias)
        if not alias_clean:
            print(f"[alias-file] 清理后别名为空, 行 {ln}: {alias}")
            continue
        aliases[idx] = alias_clean
    print(f"[alias-file] 已加载 {len(aliases)} 个别名")
    return aliases


def _load_combos_file(path: str):
    """支持两种格式:
    1) 文本: 行形如 #0007: {'lr': 1e-05, 'hidden_size': 16, 'num_layers': 2, 'in_out_mult': 5}
    2) JSONL: 每行 {"index":7, "lr":..., "hidden_size":...}
    返回 (indices, params_list)
    """
    import json, re, ast
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(f"combos-file 不存在: {path}")
    indices = []
    params_list = []
    if p.suffix.lower() == '.jsonl':
        for ln, line in enumerate(p.read_text(encoding='utf-8').splitlines(), start=1):
            raw = line.strip()
            if not raw:
                continue
            try:
                obj = json.loads(raw)
            except Exception as e:
                raise ValueError(f"JSONL 解析失败 行{ln}: {e}")
            if 'index' in obj:
                idx = int(obj.pop('index'))
            else:
                idx = len(indices)
            indices.append(idx)
            params = {k: obj[k] for k in ('lr','hidden_size','num_layers','in_out_mult') if k in obj}
            params_list.append(params)
    else:  # 文本格式
        pat = re.compile(r'^#(\d{4,}):\s*(\{.*\})$')
        for ln, line in enumerate(p.read_text(encoding='utf-8').splitlines(), start=1):
            raw = line.strip()
            if not raw or raw.startswith('# 全部组合列表'):
                continue
            m = pat.match(raw)
            if not m:
                continue
            idx = int(m.group(1))
            dict_str = m.group(2)
            try:
                params = ast.literal_eval(dict_str)
            except Exception as e:
                raise ValueError(f"行{ln} 参数字典解析失败: {e}\n内容: {dict_str}")
            indices.append(idx)
            params_list.append({k: params[k] for k in ('lr','hidden_size','num_layers','in_out_mult')})
    if not indices:
        raise ValueError("combos-file 中未解析到任何组合")
    # 验证索引连续性（提示，不强制）
    sorted_idx = sorted(indices)
    expected = list(range(sorted_idx[0], sorted_idx[0] + len(sorted_idx)))
    if sorted_idx != expected:
        print(f"[combos-file][warn] 索引不连续或有缺口 (最小 {sorted_idx[0]} 最大 {sorted_idx[-1]} 个数 {len(sorted_idx)})")
    print(f"[combos-file] 已加载 {len(indices)} 个组合")
    return indices, params_list


def load_done_metrics(summary_csv: Path):
    done = set()
    if summary_csv.is_file():
        try:
            import csv
            with open(summary_csv, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    done.add(row.get('uid'))
        except Exception:
            pass
    return done


def append_row(summary_csv: Path, header: list, row: dict):
    import csv
    file_exists = summary_csv.is_file()
    with open(summary_csv, 'a', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=header)
        if not file_exists:
            writer.writeheader()
        writer.writerow(row)


def main():
    # --- 诊断: 解析参数前打印原始 sys.argv，方便定位未知参数导致的 SystemExit(2) ---
    try:
        print(f"[ArgvDebug] raw_argv={sys.argv}")
    except Exception:
        pass
    try:
        args = parse_args()
    except SystemExit as se:
        # argparse 遇到错误参数会 SystemExit(code=2)
        code = getattr(se, 'code', None)
        if code == 2:
            print('[ArgvDebug][Fatal] 参数解析失败 (SystemExit=2)。可能原因: 未知参数 / 参数值格式错误 / 脚本版本不匹配。')
            print('[ArgvDebug] 请检查是否传递了当前版本不支持的参数 (例如 --require-gpu 在旧版本缺失)。')
            try:
                print(f"[ArgvDebug] CWD={os.getcwd()} __file__={__file__}")
            except Exception:
                pass
        raise
    # 允许通过环境变量强制关闭恢复：RESUME=0/false/no
    try:
        _resume_env = os.environ.get('RESUME')
        if _resume_env is not None and str(_resume_env).strip().lower() in ('0','false','no'):
            if not args.no_resume:
                args.no_resume = True
                print('[Resume] disabled by env RESUME=0')
    except Exception:
        pass
    if args.onnx_stub:
        # 仅在需要时构造占位 exporter 模块，避免过早 import torch.onnx 失败
        import sys as _sys, types as _types
        if 'torch.onnx._internal.exporter' not in _sys.modules:
            # 构造层级父模块
            if 'torch' not in _sys.modules:
                import torch  # noqa: F401
            # 确保 torch.onnx._internal 存在
            try:
                import importlib as _il
                try:
                    _il.import_module('torch.onnx._internal')
                except Exception:
                    # 手动补建层级 (极端情况)
                    onnx_mod = _types.ModuleType('torch.onnx')
                    internal_mod = _types.ModuleType('torch.onnx._internal')
                    _sys.modules.setdefault('torch.onnx', onnx_mod)
                    _sys.modules.setdefault('torch.onnx._internal', internal_mod)
                internal_mod = _sys.modules.get('torch.onnx._internal')
                exp_mod = _types.ModuleType('torch.onnx._internal.exporter')
                class DiagnosticOptions:  # minimal stub
                    def __init__(self, *a, **kw): self.options = dict(kw)
                    def __repr__(self): return f"<Stub DiagnosticOptions {self.options}>"
                exp_mod.DiagnosticOptions = DiagnosticOptions
                exp_mod.__all__ = ['DiagnosticOptions']
                _sys.modules['torch.onnx._internal.exporter'] = exp_mod
                print('[ONNX-Stub] Injected torch.onnx._internal.exporter with DiagnosticOptions')
            except Exception as _ie:
                print('[ONNX-Stub][fail]', _ie)
    config_path = Path(args.config).resolve()
    print(f"[Config] 使用配置文件: {config_path}")
    raw_text = open(config_path, 'r', encoding='utf-8').read()
    cfg = yaml.safe_load(raw_text)
    # 记录来源路径，后面保存到每个 run 的 config_used.yaml
    cfg['__config_file__'] = str(config_path)
    if args.device:
        cfg.setdefault('runtime', {})['device'] = args.device
    # ---- 基础 epochs 覆盖 (优先于方案A 动态逻辑) ----
    if args.epochs is not None:
        cfg.setdefault('training', {})['train_epochs'] = int(args.epochs)
    if args.ckpt_interval is not None:
        cfg.setdefault('runtime', {})['ckpt_interval'] = int(args.ckpt_interval)

    # ---- 路径自适应修正（兼容本机 Windows 绝对路径与 HPC/Linux） ----
    # 规则：
    # 1) 若设置了环境变量 DATA_BASE/KALMANNET_BASE/KNET_BASE，则优先作为 data.base_path。
    # 2) 若 YAML 的 data.base_path 是无效路径，则回退到 PROJECT_ROOT。
    # 3) 展开字符串中的 ${data.base_path} 占位符；相对路径自动拼到 base_path 下。
    # 4) 若 dataset_path.* 是绝对路径但不存在，尝试从其中的 'data' 段起构造相对路径并拼到 base_path。
    try:
        data_cfg = cfg.setdefault('data', {})
        env_base = os.environ.get('DATA_BASE') or os.environ.get('KALMANNET_BASE') or os.environ.get('KNET_BASE')
        base_candidate = Path(env_base) if env_base else Path(str(data_cfg.get('base_path', '')))
        base_dir = base_candidate.expanduser()
        if not base_dir.is_dir():
            base_dir = PROJECT_ROOT
        data_cfg['base_path'] = str(base_dir)

        import re
        def _is_win_abs(s: str) -> bool:
            return bool(re.match(r'^[A-Za-z]:[\\/]', s))

        def _expand_path(p: str | None) -> str | None:
            if not p:
                return p
            s = str(p).replace('${data.base_path}', str(base_dir))
            q = Path(s)
            # 在 Linux 上 'F:/...' 不是绝对路径，需要单独识别
            if not q.is_absolute() and not _is_win_abs(s):
                q = base_dir / q
            return str(q)

        # inputs/results 统一展开
        for k in ('inputs_path', 'results_path'):
            if k in data_cfg:
                data_cfg[k] = _expand_path(data_cfg[k])

        # dataset_path 修正
        if isinstance(data_cfg.get('dataset_path'), dict):
            ds_map = data_cfg['dataset_path']
            for split, p in list(ds_map.items()):
                orig = str(p)
                s = orig.replace('${data.base_path}', str(base_dir))
                q = Path(s)
                win_abs = _is_win_abs(s)
                if q.is_absolute() or win_abs:
                    if win_abs or not q.exists():
                        # Windows 风格或绝对但不存在：尝试从 'data' 段起重建
                        parts = re.split(r'[\\/]+', s)
                        if 'data' in parts:
                            try:
                                idx = parts.index('data')
                                candidate = base_dir / Path(*parts[idx:])
                                ds_map[split] = str(candidate)
                                print(f"[PathFix] dataset_path[{split}] {orig} -> {ds_map[split]}")
                            except Exception:
                                ds_map[split] = str(q)
                        else:
                            ds_map[split] = str(q)
                    else:
                        ds_map[split] = str(q)
                else:
                    ds_map[split] = str(base_dir / q)
    except Exception as _e:
        print('[PathFix][warn] 配置路径自适应失败:', _e)

    # 环境变量可禁用 simple-two-way-split
    if os.environ.get('DISABLE_SIMPLE_SPLIT','0').lower() in ('1','true','yes'):
        args.simple_two_way_split = False
    # 简化两路切片逻辑（可被禁用）
    if args.simple_two_way_split and args.num_shards == 1:  # 仅在用户未显式设置时改写
        dev_auto = (args.device or cfg.get('runtime',{}).get('device','cuda')).lower()
        if dev_auto.startswith('cuda'):
            args.num_shards = 2
            args.shard_index = 0
            print('[SimpleSplit] device=cuda -> 使用 num_shards=2 shard_index=0')
        elif dev_auto == 'cpu':
            args.num_shards = 2
            args.shard_index = 1
            print('[SimpleSplit] device=cpu -> 使用 num_shards=2 shard_index=1')
        else:
            print(f'[SimpleSplit] 未识别设备 {dev_auto}, 保持单分片')

    outdir = Path(args.outdir)
    # 若启用自动后缀并指定设备，避免 CPU/GPU 共享同一 outdir
    if args.auto_suffix_outdir:
        dev = (args.device or cfg.get('runtime',{}).get('device','cuda')).lower()
        if args.require_gpu and not dev.startswith('cuda'):
            print(f"[RequireGPU][FATAL] 当前解析到 device={dev} 但启用了 --require-gpu，退出以避免生成 *_cpu 目录。")
            sys.exit(5)
        if dev.startswith('cuda'):
            suffix = '_gpu'
        elif dev == 'cpu':
            suffix = '_cpu'
        else:
            suffix = f'_{dev}'
        outdir = Path(str(outdir) + suffix)
        print(f"[Info] auto-suffix-outdir 启用 → 使用目录: {outdir}")
    outdir.mkdir(parents=True, exist_ok=True)
    summary_csv = outdir / 'summary.csv'
    done_uids = load_done_metrics(summary_csv) if args.resume else set()

    # 若指定 combos-file 则忽略动态 search_space，直接使用文件
    index_override = None
    # 若未显式给 combos-file, 自动查找脚本目录下默认 all_combos.txt
    if not args.combos_file:
        default_combos = Path(__file__).resolve().parent / 'all_combos.txt'
        if default_combos.is_file():
            args.combos_file = str(default_combos)
            print(f"[Info] 检测到默认组合文件 {default_combos} -> 自动启用 --combos-file")

    combos_hash = None  # 标识本次组合空间版本 (不同机器合并时校验)
    if args.combos_file:
        idxs, plist = _load_combos_file(args.combos_file)
        grid = plist
        index_override = idxs
        # 从文件推导轴 (保持排序)
        from collections import OrderedDict
        def uniq(seq):
            seen = OrderedDict()
            for x in seq:
                seen[x] = None
            return list(seen.keys())
        axes = {
            'lr': uniq([p['lr'] for p in plist]),
            'hidden_size': uniq([p['hidden_size'] for p in plist]),
            'num_layers': uniq([p['num_layers'] for p in plist]),
            'in_out_mult': uniq([p['in_out_mult'] for p in plist]),
        }
        # 计算 combos 文件内容哈希 (前 12 位)
        try:
            import hashlib as _hashlib
            combos_bytes = Path(args.combos_file).read_bytes()
            combos_hash = _hashlib.sha1(combos_bytes).hexdigest()[:12]
        except Exception:
            combos_hash = 'unknown'
        print(f"[Info] 使用 combos-file: {args.combos_file}")
    else:
        grid, axes = build_grid(cfg, args)
        # 轴定义哈希 (若各机器 search_space 一致, 应得相同哈希)
        try:
            import hashlib as _hashlib, json as _json
            combos_hash = _hashlib.sha1(_json.dumps(axes, sort_keys=True).encode()).hexdigest()[:12]
        except Exception:
            combos_hash = 'unknown'

    # 打印轴信息（quiet 模式下压缩）
    if not args.quiet:
        print("=== 参数轴取值 ===")
        for k, v in axes.items():
            print(f"{k}: {v} (共 {len(v)})")
    else:
        axes_brief = {k: len(v) for k, v in axes.items()}
        print(f"[Axes] {axes_brief}")
    total_est = 1
    for v in axes.values():
        total_est *= len(v)
    if not args.quiet:
        if index_override is not None:
            print(f"总组合数: {len(grid)} (来自 combos-file)")
        else:
            print(f"总组合数: {total_est}")
        te_loaded = cfg.get('training',{}).get('train_epochs')
        print(f"训练轮次: {te_loaded} (可用 --epochs 覆盖)")
    if args.debug_train_epochs:
        import hashlib, re
        sha = hashlib.sha1(raw_text.encode()).hexdigest()[:12]
        line_match = None
        for ln, line in enumerate(raw_text.splitlines(), start=1):
            if re.search(r'\btrain_epochs\b', line):
                line_match = f"L{ln}: {line.strip()}"
        print("[debug-train-epochs] config path=", args.config)
        print("[debug-train-epochs] file sha1=", sha)
        print("[debug-train-epochs] line with train_epochs=", line_match)
        print("[debug-train-epochs] parsed value=", te_loaded, type(te_loaded))

    # 如果需要导出参数轴
    if args.export_space:
        out_path = Path(args.export_space)
        # 若仅给出纯文件名(不含路径)且为相对路径，则放到脚本同目录，避免脏污项目根目录
        if not out_path.is_absolute() and out_path.parent == Path('.'):
            out_path = Path(__file__).resolve().parent / out_path
        with open(out_path, 'w', encoding='utf-8') as f:
            f.write("# 参数轴取值\n")
            for k, v in axes.items():
                f.write(f"{k}: {v} (count={len(v)})\n")
            f.write(f"total_combinations={len(grid)}\n")
        print(f"[Export] 已写入参数轴信息 -> {out_path}")
        return

    if args.show_space:
        print("--show-space 指定 -> 仅展示参数轴后退出")
        return

    # 导出全部组合
    if args.export_combos:
        out_path = Path(args.export_combos)
        if not out_path.is_absolute() and out_path.parent == Path('.'):
            out_path = Path(__file__).resolve().parent / out_path
        if out_path.suffix.lower() == '.jsonl':
            with open(out_path, 'w', encoding='utf-8') as f:
                for i, params in enumerate(grid):
                    rec = {"index": i, **params}
                    f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            print(f"[Export] 组合已写入 JSONL -> {out_path}")
        else:
            with open(out_path, 'w', encoding='utf-8') as f:
                f.write("# 全部组合列表\n")
                for i, params in enumerate(grid):
                    f.write(f"#{i:04d}: {params}\n")
            print(f"[Export] 组合已写入文本 -> {out_path}")
        return

    if args.list_combos:
        if not args.quiet:
            print("=== 全部组合列表 ===")
            for i, params in enumerate(grid):
                print(f"#{i:04d}: {params}")
            print(f"共 {len(grid)} 个组合; 已打印全部，退出。")
        else:
            print(f"[List] combos={len(grid)} (quiet mode; 内容省略)")
        return
    total = len(grid)
    if index_override is None:
        enumerated = list(enumerate(grid))
    else:
        # 保持文件中顺序, 使用提供的原始索引
        enumerated = list(zip(index_override, grid))
    # 分片过滤（若未忽略）；已去除 force/include/include-file 复杂过滤。
    shard_disabled = args.ignore_shards or os.environ.get('IGNORE_SHARDS','0').lower() in ('1','true','yes')
    if shard_disabled:
        selected = list(enumerated)
        if not args.quiet:
            print('[Shard] 已忽略分片过滤 (ignore-shards)')
    else:
        selected = [(idx, params) for idx, params in enumerated if (idx % args.num_shards) == args.shard_index]
        if not args.quiet:
            print(f"[Shard] 分片过滤后剩余 {len(selected)} 组 (shard {args.shard_index}/{args.num_shards})")
    # 最小 groups 过滤：只保留用户明确指定的索引集合（支持逗号/范围）
    if args.groups:
        def _parse_simple(spec: str):
            out = set()
            for part in spec.split(','):
                part = part.strip()
                if not part:
                    continue
                if '-' in part:
                    a,b = part.split('-',1)
                    if a.isdigit() and b.isdigit():
                        a_i=int(a); b_i=int(b)
                        if a_i<=b_i:
                            out.update(range(a_i,b_i+1))
                        continue
                if part.isdigit():
                    out.add(int(part))
            return out
        grp_set = _parse_simple(args.groups)
        before_len = len(selected)
        if grp_set:
            selected = [(i,p) for (i,p) in selected if i in grp_set]
            if not args.quiet:
                print(f"[Groups] 仅保留用户指定索引: {sorted(grp_set)} (原 {before_len} -> {len(selected)})")
        else:
            if not args.quiet:
                print(f"[Groups][warn] 无法解析 --groups={args.groups!r}, 保留全部 {before_len} 组")

    # 加载别名
    aliases = _load_aliases(args.alias_file)
    if aliases and args.alias_mode == 'auto':
        print("[alias-file][note] 已提供别名文件但 alias-mode=auto -> 不启用别名")

    print(f"总组合: {total} | 分片 {args.shard_index}/{args.num_shards}{' (ignored)' if shard_disabled else ''} → 本分片 {len(selected)} 组")
    if not selected:
        print('[Warn] 分片结果为空。若你只想跑某些索引请检查 --groups 是否被上层脚本正确传递。')
    if not args.quiet:
        for idx, p in selected[:10]:
            print(f"  idx={idx} params={p}")

    header = ['global_index', 'uid', 'lr', 'hidden_size', 'num_layers', 'in_out_mult', 'neg_nse', 'nse', 'model_path', 'config_path', 'trained_epochs', 'best_epoch', 'duration_sec', 'config_hash', 'combos_hash', 'status', 'time']

    # 只有真正要训练时才导入 torch 相关依赖，避免纯导出模式报 ModuleNotFoundError
    try:
        from experiments.optimize_hyper_parameters.train_and_eval import train_and_eval  # noqa
    except ModuleNotFoundError as e:
        print(f"[ImportWarn] 训练所需模块缺失: {e}. 如果你只是在导出/查看组合，可忽略。若要训练请先安装依赖 (pip install -r requirements.txt 或 conda 环境)。")
        raise

    # 在 quiet/minimal 模式下，通知下游训练过程（通过环境变量）
    if args.minimal:
        os.environ['KNET_MINIMAL'] = '1'
        os.environ['QUIET'] = '1'
        os.environ['NO_TQDM'] = '1'   # 关闭进度条，避免噪声
        # 保留每轮汇总，便于日志推断完成度；如需更静默可在外部设 EPOCH_SUMMARY=0
    if args.debug_verbose:
        os.environ['KNET_DEBUG'] = '1'
        # debug 时禁用 quiet 标志
        if 'QUIET' in os.environ:
            os.environ.pop('QUIET')
    elif args.quiet:
        os.environ['QUIET'] = '1'
        os.environ['NO_TQDM'] = '1'

    for global_idx, params in selected:
        # 更新 cfg 深拷贝
        import copy
        run_cfg = copy.deepcopy(cfg)
        run_cfg['training']['learning_rate'] = params['lr']
        run_cfg['model']['knet']['hidden_size'] = params['hidden_size']
        run_cfg['model']['knet']['num_layers'] = params['num_layers']
        run_cfg['model']['knet']['in_mult'] = params['in_out_mult']
        run_cfg['model']['knet']['out_mult'] = params['in_out_mult']

        uid = hash_params(params)
        # 新的可读目录名（不兼容旧 gXXXX_<hash> 格式）
        base_name = build_run_dir_name(global_idx, params, uid)
        if aliases and global_idx in aliases and args.alias_mode in ('alias','alias+auto'):
            if args.alias_mode == 'alias':
                run_dir_name = aliases[global_idx]
            else:  # alias+auto
                run_dir_name = f"{aliases[global_idx]}__{base_name}"
        else:
            run_dir_name = base_name
        run_dir = outdir / run_dir_name
        run_dir.mkdir(parents=True, exist_ok=True)
        cfg_path = run_dir / 'config_used.yaml'

        # 生成 config_hash（包含用于训练的子配置，过滤掉运行时非决定性字段）
        import hashlib as _hashlib, json as _json
        hash_basis = {
            'training': run_cfg.get('training', {}),
            'model': run_cfg.get('model', {}),
            'loss': run_cfg.get('loss', {}),
            'system_model': run_cfg.get('system_model', {}),
            'runtime': run_cfg.get('runtime', {}),
            'instrumentation': run_cfg.get('instrumentation', {}),
        }
        config_hash = _hashlib.sha1(_json.dumps(hash_basis, sort_keys=True).encode()).hexdigest()[:12]

        # 跳过逻辑 (严格匹配 config_hash 才跳)
        metrics_file = run_dir / 'metrics.json'
        resume_strict = bool(cfg.get('grid', {}).get('resume_strict_config_hash', True))
        if args.resume and metrics_file.is_file():
            try:
                old = json.load(open(metrics_file, 'r', encoding='utf-8'))
                if (not resume_strict and uid in done_uids) or (resume_strict and old.get('config_hash') == config_hash):
                    print(f"[Skip] idx={global_idx} uid={uid} (resume={'strict' if resume_strict else 'uid'})")
                    continue
                else:
                    print(f"[ReRun] idx={global_idx} 配置发生变化: old_hash={old.get('config_hash')} new_hash={config_hash}")
            except Exception:
                pass

        with open(cfg_path, 'w', encoding='utf-8') as f:
            yaml.safe_dump(run_cfg, f, sort_keys=False)

        # checkpoint 恢复：查找最后一个 checkpoint_epoch_*.pt
        # 兼容两种布局：
        # 1) run_dir/checkpoints/checkpoint_epoch_*.pt (旧)
        # 2) run_dir/results/<timestamp>/checkpoints/checkpoint_epoch_*.pt (新)
        def _epoch_of(p):
            try:
                return int(p.stem.split('_')[-1])
            except Exception:
                return -1
        candidates = []
        # 旧布局
        ckpt_dir_legacy = run_dir / 'checkpoints'
        if ckpt_dir_legacy.is_dir():
            candidates.extend(ckpt_dir_legacy.glob('checkpoint_epoch_*.pt'))
        # 新布局1：results/checkpoints/ (扁平)
        results_dir = run_dir / 'results'
        if results_dir.is_dir():
            ck_flat = results_dir / 'checkpoints'
            if ck_flat.is_dir():
                candidates.extend(ck_flat.glob('checkpoint_epoch_*.pt'))
            # 新布局2：results/*/checkpoints/ (带时间戳子目录)
            for sub in results_dir.iterdir():
                ck = sub / 'checkpoints'
                if ck.is_dir():
                    candidates.extend(ck.glob('checkpoint_epoch_*.pt'))
        resume_ckpt = None
        if candidates:
            # 优先按解析到的 epoch 排序，若相同则按 mtime
            try:
                candidates.sort(key=lambda p: (_epoch_of(p), p.stat().st_mtime))
            except Exception:
                candidates.sort(key=lambda p: _epoch_of(p))
            resume_ckpt = str(candidates[-1])
        else:
            # 兼容旧目录命名：尝试在同 outdir 下查找以当前 base_name 开头的其他目录（例如旧版带 uid 后缀）
            try:
                base_name = run_dir_name  # 当前的基础命名（不含 uid）
                alt_dirs = []
                for alt in outdir.glob(base_name + '*'):
                    if alt.is_dir() and alt.name != base_name:
                        alt_dirs.append(alt)
                if alt_dirs:
                    alt_candidates = []
                    for alt in alt_dirs:
                        # 同样检查旧/新布局
                        alt_legacy = alt / 'checkpoints'
                        if alt_legacy.is_dir():
                            alt_candidates.extend(alt_legacy.glob('checkpoint_epoch_*.pt'))
                        alt_results = alt / 'results'
                        if alt_results.is_dir():
                            # 扁平: results/checkpoints
                            alt_ck_flat = alt_results / 'checkpoints'
                            if alt_ck_flat.is_dir():
                                alt_candidates.extend(alt_ck_flat.glob('checkpoint_epoch_*.pt'))
                            # 带子目录: results/*/checkpoints
                            for sub in alt_results.iterdir():
                                ck = sub / 'checkpoints'
                                if ck.is_dir():
                                    alt_candidates.extend(ck.glob('checkpoint_epoch_*.pt'))
                    if alt_candidates:
                        try:
                            alt_candidates.sort(key=lambda p: (_epoch_of(p), p.stat().st_mtime))
                        except Exception:
                            alt_candidates.sort(key=lambda p: _epoch_of(p))
                        resume_ckpt = str(alt_candidates[-1])
                        print(f"[ResumeCompat] 在其他同名前缀目录中找到历史 checkpoint -> {resume_ckpt}")
            except Exception as _alt_e:
                print('[ResumeCompat][warn] 查找旧目录命名的断点失败:', _alt_e)
        # 若显式要求 no-resume，则强制清空恢复点
        if args.no_resume:
            resume_ckpt = None
        # 可选：当显式 no-resume 或设置 PURGE_CKPTS=1 时，清理历史断点以确保不意外续跑
        try:
            if args.no_resume or os.environ.get('PURGE_CKPTS','0') == '1':
                import shutil
                # 旧布局
                if ckpt_dir_legacy.is_dir():
                    shutil.rmtree(ckpt_dir_legacy, ignore_errors=True)
                # 新布局（直接移除整个 results 目录，避免残留状态）
                if results_dir.is_dir():
                    shutil.rmtree(results_dir, ignore_errors=True)
                resume_ckpt = None
                print('[NoResume] 已清理历史 checkpoints/results，确保从头开始。')
        except Exception as _pe:
            print('[NoResume][warn] 清理断点目录失败:', _pe)

        print(f"[Run] idx={global_idx} uid={uid} params={params} resume={bool(resume_ckpt)} config_hash={config_hash}")
        try:
            t_start = time.time()
            val_metric, best_model_path = train_and_eval(
                run_cfg,
                trial_number=global_idx,
                work_dir=str(run_dir),
                resume_checkpoint=resume_ckpt,
                optuna_trial=None
            )
            duration = time.time() - t_start
            neg_nse = val_metric  # 保留变量名语义: 仍然是 train_and_eval 返回的 "-nse"
            nse = -float(neg_nse) if neg_nse is not None else float('nan')
            # 读取训练记录中的 epoch / best_epoch (若存在)
            trained_epochs = None
            best_epoch = None
            try:
                # 尝试从 best_model 或 metrics.json (旧) 中恢复 epoch 信息
                import torch as _torch
                if best_model_path and os.path.isfile(best_model_path):
                    # 使用更安全的加载策略：优先 weights_only=True；若旧版本 torch 不支持则回退。
                    bm = None
                    try:
                        bm = _torch.load(best_model_path, map_location='cpu', weights_only=True)  # type: ignore[call-arg]
                    except TypeError:
                        # 旧版本 torch (无 weights_only 参数)
                        bm = _torch.load(best_model_path, map_location='cpu')
                    except Exception as _e_load:
                        print(f"[warn] 加载 best_model 失败: {_e_load}")
                        bm = None
                    if isinstance(bm, dict):
                        try:
                            best_epoch = int(bm.get('epoch', -1))
                        except Exception:
                            pass
                # 训练日志可用 pipeline.loss_train 长度，但此处不直接访问内部对象
            except Exception:
                pass
            trained_epochs = cfg.get('training', {}).get('train_epochs')
            row = {
                'global_index': global_idx,
                'uid': uid,
                **params,
                'neg_nse': neg_nse,
                'nse': nse,
                'model_path': best_model_path,
                'config_path': str(cfg_path),
                'trained_epochs': trained_epochs,
                'best_epoch': best_epoch,
                'duration_sec': round(duration, 2),
                'config_hash': config_hash,
                'combos_hash': combos_hash,
                'status': 'ok',
                'time': datetime.now().isoformat(timespec='seconds')
            }
            # 写 metrics.json
            with open(metrics_file, 'w', encoding='utf-8') as mf:
                json.dump(row, mf, ensure_ascii=False, indent=2)
            append_row(summary_csv, header, row)
            
            # 创建成功标签文件
            success_tag_file = run_dir / 'SUCCESS'
            with open(success_tag_file, 'w', encoding='utf-8') as sf:
                sf.write(f"[SUCCESS] 训练成功完成\n")
                sf.write(f"索引: {global_idx}\n")
                sf.write(f"NSE: {nse:.6f}\n")
                sf.write(f"训练轮次: {trained_epochs}\n")
                sf.write(f"最佳轮次: {best_epoch}\n")
                sf.write(f"耗时: {duration:.1f}秒\n")
                sf.write(f"完成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                sf.write(f"状态: 成功\n")
            
            print(f"[Done] idx={global_idx} nse={nse:.6f} [SUCCESS]")
        except KeyboardInterrupt:
            print("收到 Ctrl-C, 结束当前脚本。")
            raise
        except Exception as e:
            err_path = run_dir / 'error.txt'
            import traceback
            tb_lines = traceback.format_exception(type(e), e, e.__traceback__)
            full_tb = ''.join(tb_lines)
            with open(err_path, 'w', encoding='utf-8') as ef:
                ef.write(full_tb)
            # 详细 traceback，定位真正触发 DiagnosticOptions import 的包 (打印到 stdout)
            print(f"[Fail] idx={global_idx} uid={uid} 错误: {e}")
            print("[Traceback]\n" + full_tb.rstrip())
            # 如果是 DiagnosticOptions 相关，打印已加载的相关 torch.onnx 模块
            if 'DiagnosticOptions' in str(e):
                for mod_name in list(sys.modules.keys()):
                    if mod_name.startswith('torch.onnx'):
                        mod = sys.modules.get(mod_name)
                        origin = getattr(getattr(mod, '__spec__', None), 'origin', None)
                        print(f"[Diag][Module] {mod_name} origin={origin} has_DiagnosticOptions={hasattr(mod,'DiagnosticOptions')}")
                # 尝试显式 from-import 观察行为
                try:
                    from torch.onnx._internal.exporter import DiagnosticOptions as _DTest
                    print('[Diag] from-import succeeded after failure, _DTest=', _DTest)
                except Exception as _ie:
                    print('[Diag] from-import still failing:', _ie)
            # 记录失败行，便于回顾
            duration = time.time() - t_start if 't_start' in locals() else None
            fail_row = {
                'global_index': global_idx,
                'uid': uid,
                **params,
                'neg_nse': None,
                'nse': None,
                'model_path': None,
                'config_path': str(cfg_path),
                'trained_epochs': None,
                'best_epoch': None,
                'duration_sec': round(duration,2) if duration else None,
                'config_hash': config_hash,
                'combos_hash': combos_hash,
                'status': 'fail',
                'time': datetime.now().isoformat(timespec='seconds')
            }
            append_row(summary_csv, header, fail_row)
            
            # 创建失败标签文件
            fail_tag_file = run_dir / 'FAILED'
            with open(fail_tag_file, 'w', encoding='utf-8') as ff:
                ff.write(f"[FAILED] 训练失败\n")
                ff.write(f"索引: {global_idx}\n")
                ff.write(f"错误: {str(e)}\n")
                ff.write(f"耗时: {duration:.1f}秒\n" if duration else "耗时: 未知\n")
                ff.write(f"失败时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                ff.write(f"状态: 失败\n")
                ff.write(f"详细错误信息请查看: error.txt\n")

    print("\n=== 网格搜索结束 ===")
    print(f"结果汇总: {summary_csv}")


if __name__ == '__main__':
    print(f"[HB] grid_search_knet.py start @ {time.strftime('%H:%M:%S')}", flush=True)
    main()
