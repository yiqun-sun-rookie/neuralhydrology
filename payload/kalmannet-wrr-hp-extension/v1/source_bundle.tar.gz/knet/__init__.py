# Make knet a proper package so that 'import knet' works.
# Optionally expose high-level symbols here if needed.
