
import configs.config as config

def set_train_params(p_train, p_test, batch_size=128):
    """
    Sets and returns the pipeline parameters.
    """
    args = config.general_settings()
    args.train_seq_len = p_train.shape[-1]  # 训练和验证数据集中每个序列的长度
    args.seq_len_test = p_test.shape[-1]  # 测试数据集中每个序列的长度


    args.steps_per_epoch = max(1, len(p_train) // batch_size)

    # settings for KalmanNet
    args.in_mult_KNet = 5
    args.out_mult_KNet = 5

    # minimum of 100 and p_test.shape[0]
    # args.N_B = min(args.n_train, 1000)  # 每次训练放多少个数据进去
    args.n_epochs_train = 200  # 训练过程中的迭代次数
    args.batch_size = batch_size  # 每次训练放多少个数据进去
    args.lr = 3. * 1e-6 # Base learning rate for batch_size=128
    args.lr = 9. * 1e-6 # for batch size = 1024
    args.wd = 2. * 1e-6
    args.activation_function = 'relu'
    args.num_layers_GRU_Q = 1
    args.num_layers_GRU_Sigma = 1
    args.num_layers_GRU_S = 1

    args.d_hidden_Q = 16
    args.d_hidden_Sigma = 16
    args.dim_hidden_r_lstm = 8
    args.dim_out_state_to_obs_cov_projector = 8

    args.train_loss_metric = 'mse'
    args.display_loss_metric = 'nse'
    args.dropout_prob = 0.1

    args.composite_loss = True
    args.use_log = False
    # high_flow_thr: 0.0863
    # alpha_hf: 3.0
    # delta_thr: 0.002
    # beta_rise: 3.0
    # lambda_upd: 0.2
    # gamma_slope: 0.05
    args.high_flow_thr = 0.06
    args.alpha_hf = 1.5
    args.delta_thr = 0.002
    args.beta_rise = 1.0
    args.lambda_upd = 0.05
    args.gamma_slope = 0.0
    def print_model_settings(args):
        print("in_mult_KNet:", args.in_mult_KNet)
        print("out_mult_KNet:", args.out_mult_KNet)
        print("num_layers_GRU_Q:", args.num_layers_GRU_Q)
        print("num_layers_GRU_Sigma:", args.num_layers_GRU_Sigma)
        print("num_layers_GRU_S:", args.num_layers_GRU_S)

    print_model_settings(args)

    return args
