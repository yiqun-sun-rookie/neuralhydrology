# model_initialization.py
import torch
from knet.modules.pipeline.walrus_batch_speedup import WalrusBatch
from knet.modules.pipeline.system_model import SystemModel
from hydrologic.params import params
def initialize_system_model(T, T_test, device=None, coeffs=None):
    """
    Initialize the system hydro_model with given parameters and DEVICE.
    """
    if device is None:
        device = 'cuda' if torch.cuda.is_available() else 'cpu'

    # 初始状态、协方差、过程噪声、观测噪声
    state0 = torch.tensor([140.0, 1000.0, 4.0, 1200.0, 0.1], device=device)
    p0 = torch.diag(0.001 * state0).to(device)
    q_diag = torch.tensor([140.0, 1000.0, 4.0, 1200.0, 0], device=device)
    q = 1e-3 * torch.diag(q_diag).to(device)
    r = torch.tensor(1.5e-4, device=device)

    # System Model
    # 1) 默认系数=1
    if coeffs is None: coeffs = dict(cw=1,cv=1,cg=1,cq=1,cd=1,cs=1)

    # 2) 参数乘系数
    cw_val = float(params["cw"]) * coeffs["cw"]
    cv_val = float(params["cv"]) * coeffs["cv"]
    cg_val = float(params["cg"]) * coeffs["cg"]
    cq_val = float(params["cq"]) * coeffs["cq"]
    cd_val = float(params["cd"])
    cs_val = float(params["cs"])

    model = WalrusBatch(cw=cw_val, cv=cv_val, cg=cg_val, cq=cq_val, cd=cd_val, cs=cs_val, initial_state=state0, device=device)

    # 3) 用 torch.jit.script 进行脚本化
    scripted_model = torch.jit.script(model.to(device))

    # 获取方法 f 和 h 的引用
    f_func = scripted_model.f  # type: torch.jit.ScriptFunction
    h_func = scripted_model.h
    sys_model = SystemModel(f=f_func, q=q, h=h_func, r=r, seq_len=T, seq_len_test=T_test,
                            m=model.m, n=model.n, prior_q=q, prior_state_cov=p0, prior_r=r)
    sys_model.InitSequence(state0, p0)  # Initialize x0 and P0
    
    return sys_model
