import os
import torch
from torch.optim import AdamW
from torch.optim.lr_scheduler import ReduceLROnPlateau
from .train_clean_based_on_11 import train_nn
from .test_update_save_8 import test_nn
from .test_kf import test_kf
from  .openloop import openloop
class Pipeline:
    def __init__(self, base_path):
        super().__init__()
        self.base_path = base_path
        self.best_nn_model_path = os.path.join(base_path, 'results', 'saved_models', 'best_model.pt')
        self.pipeline_path = os.path.join(base_path, 'results', 'saved_pipelines', 'pipeline.pt')

        # 初始化 metric
        self.train_loss_metric = "mse"
        self.display_metrics_list = ["nse"]

        # 添加状态保存属性
        self.current_phase_idx = 0
        self.no_improve_epochs = 0
        self.best_val_bp_loss = float('inf')
        self.loss_train = None
        self.loss_cv = None

        # 添加结果保存
        self.save_predictions = True

        # 添加 run_one_epoch 需要的内部属性（用于 test 模式）
        self._report_this_epoch = True
        self._epoch_report_every = 1
        self._log_mode = "normal"
        self._debug_stats = {}
        self._last_mem_cls = None

    def train(
            self,
            train_loader,
            val_loader,
            resume_checkpoint=None,
            optuna_trial=None,  # ★ 新增
    ):
        return train_nn(
            self,
            train_loader,
            val_loader,
            resume_checkpoint=resume_checkpoint,
            optuna_trial=optuna_trial,  # ★ 透传
        )

    def test(self, dataloader, results_path):
        return test_nn(self, dataloader, results_path)

    def test_kf(self, data_loader, results_path):
        return test_kf(self, data_loader, results_path)

    def openloop(self, data_loader, results_path):
        return openloop(self, data_loader, results_path)

    def save(self):
        torch.save(self, self.pipeline_path)

    def set_sys_model(self, sys_model):
        self.sys_model = sys_model

    def set_knet_model(self, knet_model):
        self.knet_model = knet_model


    def set_train_params(self, args):
        self.args = args
        self.optimizer = AdamW(self.knet_model.parameters(), lr=args.lr, weight_decay=args.wd)
        self.scheduler = ReduceLROnPlateau(
            self.optimizer,
            mode='min',
            factor=0.5,
            patience=5,
            threshold=1e-3,
            threshold_mode='rel',
            cooldown=1,
            min_lr=1e-6
        )

    def run_lr_finder(self, train_loader, num_iter: int, lr_start: float, lr_end: float):
        """
        专用于学习率范围测试 (LR Range Test) 的函数。
        """
        # 动态导入，避免循环依赖
        from .train_clean_based_on_11 import run_one_epoch, MAX_NAN_RESETS

        # 1. 设置模型为训练模式
        self.knet_model.train()

        # 1.5 初始化必要的训练状态（避免 lr_finder 模式缺失属性）
        try:
            self.sys_model.train_seq_len = train_loader.dataset[0]['p'].shape[-1]
            self.sys_model.val_seq_len = train_loader.dataset[0]['p'].shape[-1]
        except Exception:
            pass
        if not hasattr(self, "nan_resets_left"):
            self.nan_resets_left = MAX_NAN_RESETS

        # 2. 定义学习率更新的回调函数
        gamma = (lr_end / lr_start) ** (1 / num_iter)
        def lr_finder_callback(optimizer):
            """每个 batch 后指数增加学习率"""
            # 更新之前，先记录当前的 lr
            current_lr = optimizer.param_groups[0]['lr']
            # 然后再应用更新
            for g in optimizer.param_groups:
                g['lr'] *= gamma
            return current_lr

        # 3. 调用 run_one_epoch 进入学习率查找模式
        losses, lrs = run_one_epoch(
            self,
            train_loader,
            epoch=0,
            is_training=True,
            lr_finder_mode=True,
            num_iter=num_iter,
            lr_finder_callback=lr_finder_callback,
        )
        return losses, lrs
