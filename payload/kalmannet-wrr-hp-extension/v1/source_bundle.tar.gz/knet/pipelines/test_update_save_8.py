import torch
from knet.pipelines.train_clean_based_on_11 import initialize_training, run_one_epoch
def test_nn(pipeline, test_loader, results_path):
    # 初始化相关参数
    initialize_training(pipeline, test_loader, test_loader)
    pipeline.save_predictions = True
    epoch = 0
    # ---------- Validation ----------
    val_avg_bp_loss, val_avg_display_loss = run_one_epoch(pipeline, test_loader, epoch, is_training=False)
    # 3) 如有需要，则保存 predictions
    # 获取best_model.pt所在的目录
    # model_dir = os.path.dirname(best_model_path)
    # predictions_out_path = os.path.join(model_dir, f"{loader_name}_predictions.pt")

    if getattr(pipeline, 'save_predictions', False):
        # 存储 pipeline.predictions 到同目录
        torch.save(pipeline.predictions, results_path)
        print(f"[INFO] Test predictions saved => {results_path}")
    return None, None, val_avg_bp_loss, val_avg_display_loss

# def test_nn(pipeline, test_loader, best_model_path, loader_name):
#     # 初始化相关参数
#     initialize_training(pipeline, test_loader, test_loader)
#     pipeline.save_predictions = True
#     epoch = 0
#     # ---------- Validation ----------
#     val_avg_bp_loss, val_avg_display_loss = run_one_epoch(pipeline, test_loader, epoch, is_training=False)
#     # 3) 如有需要，则保存 predictions
#     # 获取best_model.pt所在的目录
#     model_dir = os.path.dirname(best_model_path)
#     predictions_out_path = os.path.join(model_dir, f"{loader_name}_predictions.pt")
#
#     if getattr(pipeline, 'save_predictions', False):
#         # 存储 pipeline.predictions 到同目录
#         torch.save(pipeline.predictions, predictions_out_path)
#         print(f"[INFO] Test predictions saved => {predictions_out_path}")
#     return None, None, val_avg_bp_loss, val_avg_display_loss

