from tqdm import tqdm
import torch
import os
from collections import defaultdict
from knet.modules.pipeline.utils import prepare_batch_data
from knet.modules.pipeline.core_fun import system_model_forecast
from knet.modules.pipeline.core_fun import rearrange_data_unfold
from knet.modules.utils.metrics import compute_train_loss, compute_display_metrics

def test_kf(self, test_loader, results_path):
    """Test the pipeline using UKF instead of KalmanNet."""
    # Lazy imports to avoid dependency issues when filters package is missing
    try:
        from filters.filter.non_batch.kalman import MerweScaledSigmaPoints
        from filters.filter.batch.my_version.batch_unscentedkalmanfilter_gpu import BatchUnscentedKalmanFilterGPU
        from filters.da_coupler.walrus_batch import fx_walrus_batch, hx_walrus_batch
    except ImportError:
        print("[Warning] 'filters' package not found. test_kf/ukf_filter will not work.")
        # Define dummy placeholders if needed, or just let it fail when called
        pass

    total_bp_loss = 0.0
    total_display_loss = defaultdict(float)
    total_samples = 0
    # ⚡️——— 可选：准备保存区域 —��—
    if getattr(self, "save_predictions", False):
        self.predictions = []          # 清空／新建容器

    with torch.no_grad():
        for batch in tqdm(test_loader, desc="UKF Testing", unit='batch'):
            p, ep, y_obs, state0, tm_hours = prepare_batch_data(batch, self.device)
            control = torch.cat((p, ep), dim=1)  # [B, 2, T]

            # Run UKF filtering
            states_upd, outputs_upd = ukf_filter(y_obs, control, state0, self.sys_model, self.device)

            # Compute forecasts
            states_forecast_flat, outputs_forecast_flat = system_model_forecast(
                sys_model=self.sys_model,
                p=p, etpot=ep,
                states_updated=states_upd,
                lead_time=self.args.forecast_lead_time
            )

            # Compute losses
            # 计算损失
            if self.sys_model.n == 1:
                outputs_forecast_flat = outputs_forecast_flat.squeeze(1)
            y_obs_rearranged = rearrange_data_unfold(y_obs, self.args.forecast_lead_time).reshape(-1,
                                                                                             self.args.forecast_lead_time)
            bp_loss = compute_train_loss(outputs_forecast_flat, y_obs_rearranged, lead_times=None, reduction='mean')
            display_loss = compute_display_metrics(outputs_forecast_flat, y_obs_rearranged,
                                                   metrics=self.display_metrics_list, lead_times=None)

            batch_size = p.size(0)
            total_bp_loss += bp_loss.item() * batch_size
            for key, value in display_loss.items():
                total_display_loss[key] += value * batch_size
            total_samples += batch_size

            # ⚡️——— 追加保存预测（可选）———
            if getattr(self, "save_predictions", False):
                # ① 将驱动 / 观测窗展开成 [B, T-L+1, L]
                p_win  = rearrange_data_unfold(p,  self.args.forecast_lead_time).squeeze(2)
                ep_win = rearrange_data_unfold(ep, self.args.forecast_lead_time).squeeze(2)
                y_win  = rearrange_data_unfold(y_obs, self.args.forecast_lead_time).squeeze(2)

                # ② 时间戳窗口
                tm_raw = tm_hours.squeeze(1) if tm_hours.dim() == 3 else tm_hours   # [B, T]
                tm_win = tm_raw.unfold(1, self.args.forecast_lead_time, 1)               # [B, T-L+1, L]

                # ③ 将预测重新 reshape 为窗口格式
                states_fc_win = states_forecast_flat.view(
                    batch_size, -1, self.sys_model.m, self.args.forecast_lead_time
                )                                                                    # [B, T-L+1, m, L]
                outputs_fc_win = outputs_forecast_flat.view(
                    batch_size, -1, self.args.forecast_lead_time
                )                                                                    # [B, T-L+1, L]

                # ④ 追加
                self.predictions.append({
                    # —— 原始序列（可按需保留） ——
                    "p_raw":  p.detach().cpu(),
                    "ep_raw": ep.detach().cpu(),
                    "y_obs_raw": y_obs.detach().cpu(),
                    "tm_hours_raw": tm_raw.detach().cpu(),

                    # —— 与预测严格对齐的窗口化张量 ——
                    "p_win":  p_win.detach().cpu(),
                    "ep_win": ep_win.detach().cpu(),
                    "y_obs_win": y_win.detach().cpu(),
                    "tm_hours_win": tm_win.detach().cpu(),

                    # —— UKF 中间量 / 结果 ——
                    "outputs_upd": outputs_upd.detach().cpu(),
                    "states_upd":  states_upd.detach().cpu(),
                    "states_fc_win":   states_fc_win.detach().cpu(),
                    "outputs_fc_win":  outputs_fc_win.detach().cpu(),
                })
    test_bp_loss = total_bp_loss / total_samples
    test_display_loss = {key: val / total_samples for key, val in total_display_loss.items()}

    print(f"UKF Test Results - BP Loss: {test_bp_loss:.5f}")
    for metric, value in test_display_loss.items():
        print(f"  {metric.upper()}: {value:.5f}")

    if getattr(self, 'save_predictions', False):
        # 存储 pipeline.predictions 到同目录
        torch.save(self.predictions, results_path)
        print(f"[INFO] kf test predictions saved => {results_path}")

    return test_bp_loss, test_display_loss


def ukf_filter(y_obs, control, state0, sys_model, device, q_diag=None, r_diag=None):
    """
    Apply UKF filtering to a batch of sequences.

    Args:
        y_obs (torch.Tensor): Observations [B, T, n]
        control (torch.Tensor): Control inputs [B, 2, T]
        state0 (torch.Tensor): Initial states [B, m]
        sys_model: System model with f and h functions
        device: PyTorch DEVICE

    Returns:
        states_upd (torch.Tensor): Filtered states [B, T, m]
        outputs_upd (torch.Tensor): Filtered outputs [B, T, n]
    """
    # Lazy imports
    from filters.filter.non_batch.kalman import MerweScaledSigmaPoints
    from filters.filter.batch.my_version.batch_unscentedkalmanfilter_gpu import BatchUnscentedKalmanFilterGPU
    from filters.da_coupler.walrus_batch import fx_walrus_batch, hx_walrus_batch

    B, n, T = y_obs.shape
    # 处理 state0 形状: 可能 [B, m] / [B, m, 1] / [B, m, T]
    if state0.dim() == 3:
        if state0.size(-1) == 1:
            state0_first = state0.squeeze(-1)  # [B,m]
        else:
            # 取第一个时间步 (假定后续步只是重复或未用)
            state0_first = state0[:, :, 0]
    elif state0.dim() == 2:
        state0_first = state0
    else:
        raise ValueError(f"Unsupported state0 shape: {tuple(state0.shape)}")

    dim_x = state0_first.shape[1]

    # Initialize UKF
    points = MerweScaledSigmaPoints(n=dim_x, alpha=0.6874, beta=2., kappa=-2.0)
    points.c = points.alpha ** 2 * (points.n + points.kappa)
    ukf = BatchUnscentedKalmanFilterGPU(
        dim_x=dim_x,
        dim_z=n,
        dt=1.0,
        hx=lambda sigmas: hx_walrus_batch(sigmas, sys_model=sys_model, device=device),
        fx=lambda sigmas, dt: fx_walrus_batch(sigmas, dt, sys_model=sys_model, controls=None),
        points=points,
        batch_size=B
    )

    # 初始状态
    ukf.x = state0_first.clone()  # [B, m]

    # 构造初始协方差 P (对角)
    base_state = state0_first.clone()
    tmp = base_state.clone()
    # 保持与原逻辑一致: 最后一维置 0 (若需要)
    if tmp.size(1) > 0:
        tmp[:, -1] = 0.0
    # P: [B, m, m]
    ukf.P = torch.diag_embed(0.1 * base_state)

    # Q
    if q_diag is None:
        ukf.Q = torch.diag_embed(1e-3 * tmp).to(device)
    else:
        # q_diag shape [m] 或兼容
        if q_diag.numel() != dim_x:
            print(f"[Warn] q_diag size {q_diag.numel()} != state dim {dim_x}, 将广播或截断/填充")
            if q_diag.numel() < dim_x:
                pad = torch.zeros(dim_x - q_diag.numel(), device=q_diag.device, dtype=q_diag.dtype)
                q_use = torch.cat([q_diag, pad], dim=0)
            else:
                q_use = q_diag[:dim_x]
        else:
            q_use = q_diag
        ukf.Q = torch.diag_embed(q_use.to(device)).unsqueeze(0).repeat(B,1,1)

    # R
    if r_diag is None:
        ukf.R = torch.diag_embed(torch.full((n,), 1.5e-5, device=device))
    else:
        if r_diag.numel() != n:
            print(f"[Warn] r_diag size {r_diag.numel()} != obs dim {n}, 进行适配")
            if r_diag.numel() < n:
                pad = torch.zeros(n - r_diag.numel(), device=r_diag.device, dtype=r_diag.dtype)
                r_use = torch.cat([r_diag, pad], dim=0)
            else:
                r_use = r_diag[:n]
        else:
            r_use = r_diag
        ukf.R = torch.diag_embed(r_use.to(device)).unsqueeze(0).repeat(B,1,1)

    # Storage for results
    states_upd = torch.zeros(B, dim_x, T, device=device)
    outputs_upd = torch.zeros(B, n, T, device=device)

    # 调试输出（仅一次）
    if os.getenv('KF_DEBUG_SHAPES', '0') == '1':
        print(f"[UKF][Shape] x={ukf.x.shape} P={ukf.P.shape} Q={ukf.Q.shape} R={ukf.R.shape} y_obs={y_obs.shape}")

    # Process sequence
    for t in range(T):
        controls_t = control[:, :, t]  # [B, 2]
        ukf.fx = lambda sigmas, dt, controls_t=controls_t: fx_walrus_batch(sigmas, dt, sys_model=sys_model, controls=controls_t, device=device)
        ukf.predict()
        z_t = y_obs[:, :, t]  # [B, n]
        ukf.update(z_t)
        states_upd[:, :, t] = ukf.x.clone()
        outputs_upd[:, :, t] = sys_model.h(ukf.x)

    return states_upd, outputs_upd