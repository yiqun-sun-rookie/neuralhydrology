import torch
import torch.nn as nn
import torch.nn.functional as func
import os
import csv
from hydrologic.utils import clamp_state_tensor, check_nan_parameters
from filters.modules.nn.utils import set_state_bounds


class KalmanNet(nn.Module):
    """
    KalmanNetNN类通过一个神经网络结构来近似传统的卡尔曼滤波过程。
    它使用GRU和全连接层来估计状态和观测的不确定性，并动态调整卡尔曼增益。
    """

    def __init__(self):
        super().__init__()

        # 状态约束
        # 新增一个开关，默认=False，训练时可以手动启用
        self.debug_enabled = False

        # 新增一个字典，用来收集差值分布信息
        self.debug_stats = {
            "obs_diff_pre_norm": [],
            "obs_diff_post_norm": [],
            "obs_innov_diff_pre_norm": [],
            "obs_innov_diff_post_norm": [],
            "fw_evol_diff_pre_norm": [],
            "fw_evol_diff_post_norm": [],
            "fw_update_diff_pre_norm": [],
            "fw_update_diff_post_norm": []
        }

        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.dv_lb = torch.tensor(50.0, dtype=torch.float32, device=device)
        self.dv_ub = torch.tensor(500.0, dtype=torch.float32, device=device)
        self.dg_lb = torch.tensor(50.0, dtype=torch.float32, device=device)
        self.dg_ub = torch.tensor(2450.0, dtype=torch.float32, device=device)
        self.hq_lb = torch.tensor(0.0, dtype=torch.float32, device=device)
        self.hq_ub = torch.tensor(20.0, dtype=torch.float32, device=device)
        self.hs_lb = torch.tensor(5.0, dtype=torch.float32, device=device)
        self.hs_ub = torch.tensor(5000.0, dtype=torch.float32, device=device)
        self.q_lb = torch.tensor(0.0, dtype=torch.float32, device=device)
        self.q_ub = torch.tensor(5.0, dtype=torch.float32, device=device)

        #
        self.update_mode = True

        # 激活函数映射
        self.activation_functions = {
            'relu': nn.ReLU(),
            'tanh': nn.Tanh(),
            'leaky_relu': nn.LeakyReLU(negative_slope=0.01),
            'softplus': nn.Softplus(),
            'Swish': nn.SiLU(),
            'none': nn.Identity()
        }

        # 新增1) 开关：是否启用 clamp+scale
        self.enable_clamp_scale = False
        self.clamp_scale_info = None

    def build_nn(self, sys_model, args):
        """
        根据系统模型和参数构建卡尔曼网络。
        Args:
            sys_model (object): 系统模型，提供状态和观测方程。
            args (object): 配置参数，包括是否使用CUDA等。
        """
        # 设定计算设备
        self.device = torch.device('cuda') if args.use_cuda else torch.device('cpu')

        # 获取所选的激活函数，默认为 nn.ReLU()
        self.activation_function = self.activation_functions.get(args.activation_function)

        # 初始化系统动力学参数
        self.init_system_models(sys_model.f, sys_model.h, sys_model.m, sys_model.n)

        # 初始化卡尔曼增益网络
        self.init_kgain_net(sys_model.prior_q, sys_model.prior_state_cov, sys_model.prior_r, args)

    ######################################
    ### Initialize Kalman Gain Network ###
    ######################################
    def init_kgain_net(self, prior_q, prior_state_cov, prior_r, args):
        """
        初始化卡尔曼增益网络，设置GRU网络和全连接层来处理和估计状态和观测的不确定性。

        Args:
            prior_q (torch.Tensor): Q矩阵的先验值，表示过程噪声的协方差。
            prior_state_cov (torch.Tensor): Sigma矩阵的先验值，用于追踪状态协方差。
            prior_r (torch.Tensor): S矩阵的先验值，表示观测噪声的协方差。
            args (object): 包含各种配置的参数对象。
        """

        self.args = args

        # 设置序列长度和批处理大小：确定网络每次处理的时间步长（这里为1，表示逐步处理）和批处理大小（由args.n_batch指定）。
        self.seq_len_input = 1  # core_modules calculates time-step by time-step
        self.batch_size = args.n_batch  # Batch size

        # 初始化先验知识：将先验知识（prior_q，prior_state_cov，prior_r）转移到指定的计算设备上（CPU或GPU），这些先验知识用于后续的卡尔曼增益计算
        self.prior_q = prior_q.to(self.device)
        self.prior_state_cov = prior_state_cov.to(self.device)
        self.prior_r = prior_r.to(self.device)

        # 构建GRU网络：为系统的不同部分（q，state_cov，r）构建GRU（门控循环单元）网络。这些GRU网络用于跟踪和更新系统状态的不同方面。
        # 初始化GRU网络来追踪Q矩阵的变化
        self.d_input_Q = self.m * args.in_mult_KNet  # 输入维度，扩增维度可以增加网络处理的数据量，从而提升网络的学习能力和表达能力

        # self.d_hidden_Q = self.m ** 2  # 隐藏状态维度
        self.d_hidden_Q = args.d_hidden_Q
        self.LSTM_Q = nn.LSTM(self.d_input_Q, self.d_hidden_Q, num_layers=args.num_layers_GRU_Q,
                              dropout=args.dropout_prob).to(self.device)
        # self.GRU_Q = nn.GRU(self.d_input_Q, self.d_hidden_Q, num_layers=args.num_layers_GRU_Q).to(self.DEVICE)

        # GRU to track Sigma 状态协方差
        self.d_input_Sigma = self.d_hidden_Q + self.m * args.in_mult_KNet
        # self.d_hidden_Sigma = self.m ** 2
        self.d_hidden_Sigma = args.d_hidden_Sigma
        # self.GRU_Sigma = nn.GRU(self.d_input_Sigma, self.d_hidden_Sigma, num_layers=args.num_layers_GRU_Sigma).to(
        #     self.DEVICE)
        self.LSTM_Sigma = nn.LSTM(self.d_input_Sigma, self.d_hidden_Sigma, num_layers=args.num_layers_GRU_Sigma,
                                  dropout=args.dropout_prob).to(
            self.device)

        # Fully connected 1：处理从Sigma状态协方差GRU（GRU_Sigma）输出的特征。cov(x, x) ---> cov(y, y)
        self.d_input_FC1 = self.d_hidden_Sigma
        self.d_output_FC1 = self.n ** 2
        # self.d_output_FC1 = args.d_output_FC1
        self.FC1 = nn.Sequential(
            nn.Linear(self.d_input_FC1, self.d_output_FC1),
            self.activation_function).to(self.device)

        # Fully connected 7
        self.d_input_FC7 = 2 * self.n
        self.d_output_FC7 = 2 * self.n * args.in_mult_KNet
        self.FC7 = nn.Sequential(
            nn.Linear(self.d_input_FC7, self.d_output_FC7),
            self.activation_function).to(self.device)

        # GRU to track S 观测噪声的协方差。
        # self.d_input_S = self.n ** 2 + 2 * self.n * args.in_mult_KNet
        self.d_hidden_S = self.n ** 2
        self.d_input_S = self.d_output_FC1 + self.d_output_FC7
        # self.d_hidden_S = args.d_hidden_S
        # self.GRU_S = nn.GRU(self.d_input_S, self.d_hidden_S, num_layers=args.num_layers_GRU_S).to(self.DEVICE)
        self.LSTM_S = nn.LSTM(self.d_input_S, self.d_hidden_S, num_layers=args.num_layers_GRU_S,
                              dropout=args.dropout_prob).to(self.device)

        # Fully connected 2：整合从Sigma状态协方差GRU和状态S GRU的输出，类似cov(x,y)
        self.d_input_FC2 = self.d_hidden_S + self.d_hidden_Sigma
        self.d_output_FC2 = self.n * self.m
        self.d_hidden_FC2 = self.d_input_FC2 * args.out_mult_KNet
        self.FC2 = nn.Sequential(
            nn.Linear(self.d_input_FC2, self.d_hidden_FC2),
            self.activation_function,
            nn.Linear(self.d_hidden_FC2, self.d_output_FC2)).to(self.device)

        # Fully connected 3
        self.d_input_FC3 = self.d_hidden_S + self.d_output_FC2
        self.d_output_FC3 = self.m ** 2
        self.FC3 = nn.Sequential(
            nn.Linear(self.d_input_FC3, self.d_output_FC3),
            self.activation_function).to(self.device)

        # Fully connected 4
        self.d_input_FC4 = self.d_hidden_Sigma + self.d_output_FC3
        self.d_output_FC4 = self.d_hidden_Sigma
        self.FC4 = nn.Sequential(
            nn.Linear(self.d_input_FC4, self.d_output_FC4),
            self.activation_function).to(self.device)

        # Fully connected 5
        self.d_input_FC5 = self.m
        self.d_output_FC5 = self.m * args.in_mult_KNet
        self.FC5 = nn.Sequential(
            nn.Linear(self.d_input_FC5, self.d_output_FC5),
            self.activation_function).to(self.device)

        # Fully connected 6
        self.d_input_FC6 = self.m
        self.d_output_FC6 = self.m * args.in_mult_KNet
        self.FC6 = nn.Sequential(
            nn.Linear(self.d_input_FC6, self.d_output_FC6),
            self.activation_function).to(self.device)

        # 调整残差维度
        # self.d_input_FC3 = self.d_hidden_S + self.d_output_FC2
        # self.d_output_FC3 = self.m ** 2
        # self.FC3 = nn.Sequential(
        #         nn.Linear(self.d_input_FC3, self.d_output_FC3),
        #         self.activation_function).to(self.DEVICE)
        # self.d_input_Q = self.m * args.in_mult_KNet
        self.fc_inQ_to_outQ = nn.Linear(self.d_input_Q, self.d_hidden_Q).to(self.device)

        self.fc_in_Sigma_to_out_Sigma = nn.Linear(self.d_input_Sigma, self.d_hidden_Sigma).to(self.device)
        self.fc_in_S_to_out_S = nn.Linear(self.d_input_S, self.d_hidden_S).to(self.device)

        # 初始化GRU的隐藏状态
        self.q_prior_to_hidden_state = nn.Linear(self.prior_q.numel(), self.d_hidden_Q).to(self.device)
        self.q_prior_to_cell_state = nn.Linear(self.prior_q.numel(), self.d_hidden_Q).to(self.device)
        self.sigma_prior_to_hidden_state = nn.Linear(self.prior_state_cov.numel(), self.d_hidden_Sigma).to(self.device)
        self.sigma_prior_to_cell_state = nn.Linear(self.prior_state_cov.numel(), self.d_hidden_Sigma).to(self.device)
        self.r_prior_to_hidden_state = nn.Linear(self.prior_r.numel(), self.d_hidden_S).to(self.device)
        self.r_prior_to_cell_state = nn.Linear(self.prior_r.numel(), self.d_hidden_S).to(self.device)

    ##################################
    ### Initialize System Dynamics ###
    ##################################
    def init_system_models(self, f, h, m, n):
        """
        初始化系统动力学。
        Args:
            f (function): 状态转移函数。
            h (function): 观测函数。
            m (int): 状态向量的维度。
            n (int): 观测向量的维度。
        """
        self.f, self.m, self.h, self.n = f, m, h, n

    ###########################
    ### Initialize Sequence ###
    ###########################
    def init_sequence(self, M1_0, T):
        """
        初始化序列的第一时刻状态。

        Args:
            M1_0 (torch.tensor): 时间0的均值
            T (int): 序列总长度。
        """
        self.T = T
        self.m1x_posterior = M1_0.to(self.device)
        self.m1x_posterior_previous = self.m1x_posterior
        self.m1x_prior_previous = self.m1x_posterior
        self.y_previous = self.h(self.m1x_posterior)

    ######################
    ### Compute Priors ###
    ######################
    def step_prior(self, controls):
        # Predict the 1-st moment of x
        self.m1x_prior = self.f(self.m1x_posterior, controls)

        # Predict the 1-st moment of y
        self.m1y = self.h(self.m1x_prior)

    ##############################
    ### Kalman Gain Estimation ###
    ##############################
    def estimate_gain(self, y):
        """
        计算和更新卡尔曼增益。

        Args:
            y (torch.Tensor): 当前时刻的观测值，形状为 [batch_size, n, 1]。
        """
        # 检查输入维度
        assert y.ndim == 3 and y.shape[0] == self.batch_size and y.shape[1] == self.n and y.shape[2] == 1, \
            f"Expected y to have shape [batch_size, n, 1], got {y.shape}"
        assert (self.y_previous.ndim == 2 and self.y_previous.shape[0] == self.batch_size
                and self.y_previous.shape[-1] == self.n), \
            f"Expected self.y_previous to have shape [batch_size, n], got {self.y_previous.shape}"
        assert self.m1y.ndim == 2 and self.m1y.shape[0] == self.batch_size and self.m1y.shape[-1] == self.n, \
            f"Expected self.m1y to have shape [batch_size, n], got {self.m1y.shape}"

        # 计算观测差异和观测创新异
        # 当前观测与上一观测的差异差
        obs_diff = torch.squeeze(y, 2) - self.y_previous
        obs_innov_diff = torch.squeeze(y, 2) - self.m1y
        # 计算前向演化差异和前向更新差异
        # 后验状态的演化差异
        fw_evol_diff = self.m1x_posterior - self.m1x_posterior_previous
        # 后验状态的演化差异
        # 后验状态与先验状态的更新差异
        fw_update_diff = self.m1x_posterior - self.m1x_prior_previous  # 后验状态与先验状态的更新差异

        if self.enable_clamp_scale and self.clamp_scale_info is not None:
            # 注意：直接传入配置中的 Tensor
            obs_diff = self.clamp_scale_multiDim(
                obs_diff,
                self.clamp_scale_info["obs_diff_clamp"],  # Tensor shape [2]
                self.clamp_scale_info["obs_diff_scale"]  # Tensor标量
            )
            obs_innov_diff = self.clamp_scale_multiDim(
                obs_innov_diff,
                self.clamp_scale_info["obs_diff_clamp"],
                self.clamp_scale_info["obs_diff_scale"]
            )
            # 对于 fw_evol_diff 和 fw_update_diff（假设这两个均与 fw_update_diff_clamp、fw_update_diff_scale 对应）
            fw_evol_diff = self.clamp_scale_multiDim(
                fw_evol_diff,
                self.clamp_scale_info["fw_update_diff_clamp"],  # Tensor shape [5, 2]
                self.clamp_scale_info["fw_update_diff_scale"]  # Tensor shape [5]
            )
            fw_update_diff = self.clamp_scale_multiDim(
                fw_update_diff,
                self.clamp_scale_info["fw_update_diff_clamp"],
                self.clamp_scale_info["fw_update_diff_scale"]
            )

        # 使用卡尔曼增益网络计算当前的卡尔曼增益
        KG = self.KGain_step(obs_diff, obs_innov_diff, fw_evol_diff, fw_update_diff)

        # 将卡尔曼增益的输出向量重新塑形为矩阵形式，以便与创新向量进行矩阵乘法
        self.KGain = torch.reshape(KG, (self.batch_size, self.m, self.n))

    #######################
    ### Kalman Net Step ###
    #######################
    def knet_step(self, y, controls):
        """
        执行一步卡尔曼滤波，包括计算先验、估计卡尔曼增益、更新状态估计。
        可以选择是否更新状态估计。
        self.update_mode = True 时更新状态估计，否则不更新。
        Args:
            y, p, etpot (torch.Tensor): 当前时刻的观测数据/雨量/蒸发，形状为 [batch_size, n, 1]，其中 n 是观测向量的维数。

        Returns:
            torch.Tensor: 更新后的状态估计，形状为 [batch_size, m, 1]，其中 m 是状态向量的维数。
        """

        # 计算先验估计，更新内部的 m1x_prior 和 m1y
        self.step_prior(controls)

        # 如果更新模式为真，则计算卡尔曼增益并更新状态估计
        # 根据当前观测 y 计算卡尔曼增益
        y = torch.unsqueeze(y, 2)
        self.estimate_gain(y)
        # assert self.m1y.ndim == 1 and self.m1y.shape[0] == self.batch_size, \
        #     f"Expected self.m1y to have shape [batch_size], got {self.m1y.shape}"
        # m1y = torch.unsqueeze(self.m1y, -1).unsqueeze(-1)
        dy = y - self.m1y.unsqueeze(-1)  # Innovation vector
        # 使用卡尔曼增益更新状态估计更新量
        INOV_raw = torch.bmm(self.KGain, dy).squeeze(-1)
        # 原始先验状态
        x_prior = self.m1x_prior  # [B, m]
        # 3️⃣ —— 在“缩放空间”做更新 ——
        if self.enable_clamp_scale and self.clamp_scale_info is not None:
            # 假设 clamp_scale_info 中新增了：
            #   "state_clamp": Tensor([m,2]), "state_scale": Tensor([m])
            state_clamp = self.clamp_scale_info["state_clamp"]  # [m,2]
            state_scale = self.clamp_scale_info["state_scale"]  # [m]

            # ➊ 对先验和创新量各自 clamp & scale → [-1,1] 或类似范围
            x_n = self.clamp_scale_multiDim(x_prior, state_clamp, state_scale)  # [B, m]
            inov_n = self.clamp_scale_multiDim(INOV_raw, state_clamp, state_scale)  # [B, m]

            # ➋ 在缩放空间直接相加
            x_post_n = x_n + inov_n  # [B, m]

            # ➌ 反缩放回原量纲
            updated_state = x_post_n * state_scale  # [B, m]
        else:
            # 不做缩放，回到原逻辑
            updated_state = x_prior + INOV_raw  # [B, m]

        # updated_state = self.m1x_prior.unsqueeze(-1) + INOV
        updated_state = torch.squeeze(updated_state, -1)

        # 确保状态估计在约束范围内
        updated_state = torch.stack([
            torch.clamp(updated_state[:, 0], self.dv_lb, self.dv_ub),
            torch.clamp(updated_state[:, 1], self.dg_lb, self.dg_ub),
            torch.clamp(updated_state[:, 2], self.hq_lb, self.hq_ub),
            torch.clamp(updated_state[:, 3], self.hs_lb, self.hs_ub),
            torch.clamp(updated_state[:, 4], self.q_lb, self.q_ub)
        ], dim=1)

        # 更新
        self.m1x_posterior_previous = self.m1x_posterior  # 保存上一时刻的后验估计
        self.m1x_posterior = updated_state

        # 更新先验状态为当前的后验状态，为下一步计算做准备
        self.m1x_prior_previous = self.m1x_prior

        # 更新之前的观测为当前观测
        self.y_previous = y.squeeze(-1)

        # 返回更新后的状态估计
        return self.m1x_posterior

    ########################
    ### Kalman Gain Step ###
    ########################
    def KGain_step(self, obs_diff, obs_innov_diff, fw_evol_diff, fw_update_diff):
        """
        执行卡尔曼增益计算的一系列神经网络操作。
        Args:
            obs_diff (Tensor): 观测差异。
            obs_innov_diff (Tensor): 观测创新差异。
            fw_evol_diff (Tensor): 前向演化差异。
            fw_update_diff (Tensor): 前向更新差异。
        Returns:
            Tensor: 更新后的卡尔曼增益。
        """

        # 扩展维度以符合GRU输入要求
        def expand_dim(x):
            expanded = torch.empty(self.seq_len_input, self.batch_size, x.shape[-1]).to(self.device)
            expanded[0, :, :] = x
            return expanded

        # 在[batchsize, dim]前面加一个维度，适配lstm默认batch_first=False的输入要求
        obs_diff = expand_dim(obs_diff)
        obs_innov_diff = expand_dim(obs_innov_diff)
        fw_evol_diff = expand_dim(fw_evol_diff)
        fw_update_diff = expand_dim(fw_update_diff)

        ### Forward Flow
        # 全连接层5：处理前向更新差异
        # fw_update_diff = x^ - x^-
        in_FC5 = fw_update_diff
        if torch.isnan(in_FC5).any():
            raise ValueError("NaN detected in output of in_FC5")

        # self.d_input_FC5 = self.m
        # self.d_output_FC5 = self.m * args.in_mult_KNet
        # self.FC5 = nn.Sequential(
        #     nn.Linear(self.d_input_FC5, self.d_output_FC5),
        #     self.activation_function).to(self.DEVICE)

        out_FC5 = self.FC5(in_FC5)
        if torch.isnan(out_FC5).any():
            raise ValueError("NaN detected in output of out_FC5")

        # Q-GRU：处理来自FC5的输出
        # q is function of x^ - x^- and q
        in_Q = out_FC5
        # out_Q, self.h_Q = self.GRU_Q(in_Q, self.h_Q)
        out_Q, (self.h_Q, self.c_Q) = self.LSTM_Q(in_Q, (self.h_Q, self.c_Q))  # LSTM替代GRU

        # 调整 in_Q 的维度以匹配 out_Q
        adjusted_in_Q = self.fc_inQ_to_outQ(in_Q.squeeze(0)).unsqueeze(0)
        out_Q = out_Q + adjusted_in_Q  # 添加残差连接
        if torch.isnan(adjusted_in_Q).any():
            raise ValueError("NaN detected in output of adjusted_in_Q")
        if torch.isnan(out_Q).any():
            raise ValueError("NaN detected in output of out_Q")

        # 全连接层6：处理前向演化差异
        # fw_evol_diff = x^t - x^t-1
        in_FC6 = fw_evol_diff
        out_FC6 = self.FC6(in_FC6)
        if torch.isnan(out_FC6).any():
            raise ValueError("NaN detected in output of out_FC6")

        # Sigma-GRU：整合来自Q-GRU和FC6的输出
        # x_cov = cov(x, x) + q
        in_Sigma = torch.cat((out_Q, out_FC6), 2)
        if torch.isnan(in_Sigma).any():
            raise ValueError("NaN detected in output of in_Sigma")

        # out_Sigma, self.h_Sigma = self.GRU_Sigma(in_Sigma, self.h_Sigma)
        out_Sigma, (self.h_Sigma, self.c_Sigma) = self.LSTM_Sigma(in_Sigma, (self.h_Sigma, self.c_Sigma))  # LSTM替代GRU
        if torch.isnan(out_Sigma).any():
            raise ValueError("NaN detected in output of out_Sigma")

        # 添加残差连接
        adjusted_in_Sigma = self.fc_in_Sigma_to_out_Sigma(in_Sigma.squeeze(0)).unsqueeze(0)
        if torch.isnan(adjusted_in_Sigma).any():
            raise ValueError("NaN detected in output of adjusted_in_Sigma")

        out_Sigma = out_Sigma + adjusted_in_Sigma  # 添加残差连接
        if torch.isnan(out_Sigma).any():
            raise ValueError("NaN detected in output of out_Sigma")

        # 全连接层1：进一步处理来自Sigma-GRU的输出
        in_FC1 = out_Sigma
        out_FC1 = self.FC1(in_FC1)
        if torch.isnan(out_FC1).any():
            raise ValueError("NaN detected in output of out_FC1")
        if torch.isnan(in_FC1).any():
            raise ValueError("NaN detected in output of in_FC1")

        # 全连接层7：整合观测差异和观测创新差异，然后进行升维，提升表达能力
        # obs_diff = yt - yt-1
        # self.d_input_FC7 = 2 * self.n
        # self.d_output_FC7 = 2 * self.n * args.in_mult_KNet
        # self.FC7 = nn.Sequential(
        #         nn.Linear(self.d_input_FC7, self.d_output_FC7),
        #         self.activation_function).to(self.DEVICE)
        in_FC7 = torch.cat((obs_diff, obs_innov_diff), 2)
        out_FC7 = self.FC7(in_FC7)
        if torch.isnan(out_FC7).any():
            raise ValueError("NaN detected in output of adjusted_in_S")

        # S-GRU：整合来自FC1和FC7的输出
        in_S = torch.cat((out_FC1, out_FC7), 2)
        # out_S, self.h_S = self.GRU_S(in_S, self.h_S)
        out_S, (self.h_S, self.c_S) = self.LSTM_S(in_S, (self.h_S, self.c_S))  # LSTM替代GRU
        if torch.isnan(in_S).any():
            raise ValueError("NaN detected in output of adjusted_in_S")
        # 添加残差连接
        adjusted_in_S = self.fc_in_S_to_out_S(in_S.squeeze(0)).unsqueeze(0)
        out_S = out_S + adjusted_in_S  # 添加残余连接
        if torch.isnan(adjusted_in_S).any():
            raise ValueError("NaN detected in output of adjusted_in_S")
        if torch.isnan(out_S).any():
            raise ValueError("NaN detected in output of out_S")

        # 全连接层2：整合来自Sigma-GRU和S-GRU的输出 得到gain
        # gain is a function of y_cov and x_y_cov
        in_FC2 = torch.cat((out_Sigma, out_S), 2)

        # 检查输入是否含有 NaN
        if torch.isnan(in_FC2).any():
            raise ValueError("NaN detected in input to the linear layer")
        if torch.isinf(in_FC2).any():
            raise ValueError(f"in_FC2 contains Inf values.")

        # 在执行前添加小的正值
        # in_FC2 = in_FC2 + 1e-8
        out_FC2 = self.FC2(in_FC2)

        ### Backward Flow
        # x_cov = x_cov - gain * y_cov * gain^train_seq_len
        in_FC3 = torch.cat((out_S, out_FC2), 2)
        out_FC3 = self.FC3(in_FC3)
        in_FC4 = torch.cat((out_Sigma, out_FC3), 2)
        out_FC4 = self.FC4(in_FC4)

        # 更新Sigma-GRU的隐藏状态
        if self.args.num_layers_GRU_Sigma == 1:
            self.h_Sigma = out_FC4
        else:
            expanded_out_FC4 = out_FC4.repeat(self.args.num_layers_GRU_Sigma, 1, 1)
            self.h_Sigma = expanded_out_FC4

        # 返回计算得到的卡尔曼增益
        return out_FC2

    ###############
    ### Forward ###
    ###############
    def forward(self, y, controls):
        y = y.to(self.device)
        return self.knet_step(y, controls)

    def init_weights(self, m):
        if isinstance(m, nn.Linear):
            if self.args.activation_function in ['relu', 'leaky_relu', 'softplus']:
                nn.init.kaiming_uniform_(m.weight, nonlinearity='relu')
            elif self.args.activation_function == 'tanh':
                nn.init.xavier_uniform_(m.weight)
            else:
                nn.init.xavier_uniform_(m.weight)
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.GRU):
            for name, param in m.named_parameters():
                if 'weight_ih' in name:
                    nn.init.xavier_uniform_(param.data)
                elif 'weight_hh' in name:
                    nn.init.orthogonal_(param.data)
                elif 'bias' in name:
                    nn.init.zeros_(param.data)

    #########################
    ### Init Hidden State ###
    #########################
    def init_hidden_state(self, prior, num_layers, mapping_layer=None):
        # # 检查 prior 的大小是否与 hidden_dim 一致
        # if prior.numel() != hidden_dim:
        #     raise ValueError(f"Prior size {prior.numel()} does not match hidden_dim {hidden_dim}")
        # 展平先验张量，重塑为需要的形状，然后扩展以填充隐藏状态的批次、层数和序列长度需求
        # 假设 prior 是 [25]
        # 扁平化先验矩阵
        prior_flat = prior.view(1, -1)  # [1, m*m]

        if mapping_layer:
            mapped_prior = mapping_layer(prior_flat)  # [1, hidden_dim]
        else:
            mapped_prior = prior_flat  # 如果没有映射层，直接使用扁平化后的先验

        # 重塑为 [num_layers, batch_size, hidden_dim]
        expanded_prior = mapped_prior.unsqueeze(0).repeat(num_layers, self.batch_size,
                                                          1)  # [num_layers, batch_size, hidden_dim]
        return expanded_prior

    def init_hidden_KNet(self):
        self.h_Q = self.init_hidden_state(self.prior_q, num_layers=self.args.num_layers_GRU_Q,
                                          mapping_layer=self.q_prior_to_hidden_state)
        self.c_Q = self.init_hidden_state(self.prior_q, num_layers=self.args.num_layers_GRU_Q,
                                          mapping_layer=self.q_prior_to_cell_state)
        self.h_Sigma = self.init_hidden_state(self.prior_state_cov,
                                              num_layers=self.args.num_layers_GRU_Sigma,
                                              mapping_layer=self.sigma_prior_to_hidden_state)
        self.c_Sigma = self.init_hidden_state(self.prior_state_cov,
                                              num_layers=self.args.num_layers_GRU_Sigma,
                                              mapping_layer=self.sigma_prior_to_cell_state)
        self.h_S = self.init_hidden_state(self.prior_r, num_layers=self.args.num_layers_GRU_S,
                                          mapping_layer=self.r_prior_to_hidden_state)
        self.c_S = self.init_hidden_state(self.prior_r, num_layers=self.args.num_layers_GRU_S,
                                          mapping_layer=self.r_prior_to_cell_state)

    def record_diff_stats(self, diff_tensor: torch.Tensor, tag: str):
        """
        统计给定 diff_tensor 的均值/标准差/最小值/最大值，并存到 self.debug_stats[tag]。
        """
        if not self.debug_enabled:
            return  # 如果 debug 关闭，则直接返回

        with torch.no_grad():
            # 分别对每一维特征(列)做统计
            diff_mean = diff_tensor.mean(dim=0)  # shape=[feature_dim]
            diff_std = diff_tensor.std(dim=0)  # shape=[feature_dim]
            diff_min = diff_tensor.min(dim=0).values  # shape=[feature_dim]
            diff_max = diff_tensor.max(dim=0).values  # shape=[feature_dim]

        # 如果要存入 debug_stats[tag]，可以把它们变成 Python list 或 numpy
        diff_mean_list = diff_mean.cpu().numpy().tolist()
        diff_std_list = diff_std.cpu().numpy().tolist()
        diff_min_list = diff_min.cpu().numpy().tolist()
        diff_max_list = diff_max.cpu().numpy().tolist()

        self.debug_stats[tag].append({
            "mean": diff_mean_list,
            "std": diff_std_list,
            "min": diff_min_list,
            "max": diff_max_list
        })

    def save_debug_stats_to_csv(self, output_dir: str):
        """
        对于分特征统计的模式，将 self.debug_stats[tag] 写到 CSV。
        这里假设 self.debug_stats[tag] 的每个元素是:
        {
          "mean": [...],  # (feature_dim,)
          "std":  [...],
          "min":  [...],
          "max":  [...]
        }
        """
        import os
        import csv

        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        for tag, data_list in self.debug_stats.items():
            # data_list 可能是 [{mean:[], std:[], min:[], max:[]}, {mean:[], ...}, ...]
            csv_path = os.path.join(output_dir, f"{tag}.csv")
            with open(csv_path, "w", newline="") as f:
                writer = csv.writer(f)
                # 写表头: 我们让行的格式 = [call_idx, dim_idx, mean, std, min, max]
                writer.writerow(["call_idx", "dim_idx", "mean", "std", "min", "max"])

                for call_idx, stats_dict in enumerate(data_list):
                    # stats_dict["mean"]是一个列表, 比如 5 维
                    mean_list = stats_dict["mean"]
                    std_list = stats_dict["std"]
                    min_list = stats_dict["min"]
                    max_list = stats_dict["max"]

                    feature_dim = len(mean_list)  # 假设 mean/std/min/max长度相同
                    for i in range(feature_dim):
                        row = [
                            call_idx,
                            i,
                            mean_list[i],
                            std_list[i],
                            min_list[i],
                            max_list[i]
                        ]
                        writer.writerow(row)

            print(f"[DebugStats] Saved {tag} to {csv_path}")

    @torch.jit.script
    def clamp_scale_multiDim(tensor: torch.Tensor, clamp_info: torch.Tensor, scale_info: torch.Tensor) -> torch.Tensor:
        """
        对2D张量（形状为 [B, D]）的每一列进行 clamp 和 scale 操作。

        要求：
          - clamp_info：可以是标量 clamp 范围（形状 [2]），表示所有列使用相同的 (min, max)；
            或者是形状为 [D, 2]，表示每一列独自设置 (min, max)。
          - scale_info：可以是标量（0-dim Tensor）或 1D Tensor（长度 D）。

        返回：
          处理后的张量，形状为 [B, D]。
        """
        B, D = tensor.shape

        # 处理 clamp_info
        if clamp_info.dim() == 1 and clamp_info.numel() == 2:
            # 表示所有列使用相同的 clamp 范围
            clamp_min = clamp_info[0].repeat(D)
            clamp_max = clamp_info[1].repeat(D)
        elif clamp_info.dim() == 2 and clamp_info.shape[0] == D and clamp_info.shape[1] == 2:
            # 每一列各自的 clamp 范围
            clamp_min = clamp_info[:, 0]
            clamp_max = clamp_info[:, 1]
        else:
            raise ValueError("clamp_info must have shape [2] or [D, 2].")

        # 处理 scale_info
        if scale_info.dim() == 0:
            # 标量扩展为 [D]
            scale_val = scale_info.repeat(D)
        elif scale_info.dim() == 1 and scale_info.numel() == D:
            scale_val = scale_info
        else:
            raise ValueError("scale_info must be a scalar or a 1D tensor of length D.")

        # 调整形状为 [1, D] 以便广播
        clamp_min = clamp_min.unsqueeze(0)  # [1, D]
        clamp_max = clamp_max.unsqueeze(0)  # [1, D]
        scale_val = scale_val.unsqueeze(0)  # [1, D]

        return torch.clamp(tensor, min=clamp_min, max=clamp_max) / scale_val





