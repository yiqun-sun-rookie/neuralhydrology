import torch
def set_state_bounds(nn, device):
    nn.dv_lb = torch.tensor(50.0, dtype=torch.float32, device=device)
    nn.dv_ub = torch.tensor(500.0, dtype=torch.float32, device=device)
    nn.dg_lb = torch.tensor(50.0, dtype=torch.float32, device=device)
    nn.dg_ub = torch.tensor(2450.0, dtype=torch.float32, device=device)
    nn.hq_lb = torch.tensor(0.0, dtype=torch.float32, device=device)
    nn.hq_ub = torch.tensor(20.0, dtype=torch.float32, device=device)
    nn.hs_lb = torch.tensor(5.0, dtype=torch.float32, device=device)
    nn.hs_ub = torch.tensor(5000.0, dtype=torch.float32, device=device)
    nn.q_lb = torch.tensor(0.0, dtype=torch.float32, device=device)
    nn.q_ub = torch.tensor(5.0, dtype=torch.float32, device=device)
    return nn