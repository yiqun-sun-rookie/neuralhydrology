import numpy as np
import torch
from tqdm import tqdm
import matplotlib.pyplot as plt
from core_modules.walrus_batch import WalrusBatch

def add_gaussian_noise(arr, noise_level=0.05, seed=33, ensure_non_negative=True):
    """
    对数组 arr 添加加性高斯噪声，噪声标准差 = noise_level * arr.std()。
    """
    rng = np.random.RandomState(seed)
    arr_std = arr.std() if arr.std() > 1e-8 else 1.0
    noise = rng.normal(loc=0.0, scale=noise_level * arr_std, size=arr.shape)
    arr_noisy = arr + noise
    if ensure_non_negative:
        arr_noisy = np.clip(arr_noisy, 0, None)
    return arr_noisy

# 定义一个函数，用于给定p, etpot, qobs运行模型得到states_all，并绘图保存
def run_model_and_save_states(p_array, etpot_array, qobs_array, sim_len, state0, params, filename_prefix):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 转化为Torch张量
    p_tensor = torch.tensor(p_array, dtype=torch.float32, device=device).unsqueeze(0)      # [1, sim_len]
    etpot_tensor = torch.tensor(etpot_array, dtype=torch.float32, device=device).unsqueeze(0) # [1, sim_len]
    qobs_tensor = torch.tensor(qobs_array, dtype=torch.float32, device=device).unsqueeze(0)   # [1, sim_len]

    hydro_model = WalrusBatch(cw=params["cw"], cv=params["cv"], cg=params["cg"], cq=params["cq"], cd=params["cd"],
                              cs=params["cs"], initial_state=state0)
    hydro_model.set_state(state0)

    m = hydro_model.m

    states_all = torch.zeros((sim_len, m), dtype=torch.float32, device=device)
    states_all[0, :] = state0

    with tqdm(range(1, sim_len), desc=f"Running Walrus Model {filename_prefix}", unit="step") as pbar:
        for t in pbar:
            controls_t = torch.cat((p_tensor[:, t], etpot_tensor[:, t]), dim=-1).unsqueeze(0)  # [1, 2]
            x_prev = states_all[t - 1, :].unsqueeze(0)  # 上一时刻的状态 [1, m]
            x_next = hydro_model.f(x_prev, controls_t)  # [1, m]
            states_all[t, :] = x_next.squeeze(0)

    # 绘图对比
    q_state = states_all[:, -1].detach().cpu().numpy()  # 转成numpy方便绘图
    q_obs_plot = qobs_tensor[0, 0:sim_len].squeeze(0).detach().cpu().numpy()  # [sim_len]
    # 计算MSE
    mse = np.mean((q_obs_plot - q_state) ** 2)
    print(f"MSE between q_obs_plot and q_state for {filename_prefix}: {mse}")
    plt.figure(figsize=(10, 6))
    plt.plot(q_obs_plot, label='Observed Q', alpha=0.7)
    plt.plot(q_state, label='Modeled Q (states_all last dim)', alpha=0.7)
    plt.title(f'Comparison of Modeled Q and Observed Q - {filename_prefix}')
    plt.xlabel('Time step')
    plt.ylabel('Q')
    plt.legend()
    plt.grid(True)
    plt.show()

    # 保存状态
    torch.save(states_all, f"F:\github\pycharm\projects\kalmannet\data/processed/{filename_prefix}_states_all.pt")
    return states_all
