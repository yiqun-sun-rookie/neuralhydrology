import torch
def check_data_loader(data_loader, data_name):

    print(f"Checking data in {data_name}...")
    for i, batch in enumerate(data_loader):
        p = batch['p']
        etpot = batch['etpot']
        qobs = batch['qobs']
        state0 = batch['state0']
        tm_hours = batch['tm_hours']

        # 检查是否存在NaN或Inf
        if torch.isnan(p).any() or torch.isnan(etpot).any() or torch.isnan(qobs).any() or torch.isnan(state0).any() or torch.isnan(tm_hours).any():
            print(f"NaN detected in {data_name} at batch {i}")
        if torch.isinf(p).any() or torch.isinf(etpot).any() or torch.isinf(qobs).any() or torch.isinf(state0).any() or torch.isinf(tm_hours).any():
            print(f"Inf detected in {data_name} at batch {i}")