import torch
import numpy as np
from torch.utils.data import DataLoader
from hydrologic.data_handler import DataHandler
# 设置随机种子
initialize_seed(3)

# 路径信息
data_file_path = r'F:\github\pycharm\projects\kalmannet\data\hydrologic\PEQ_Regge_hour.txt'
saved_models_path = r'/results/saved_models/'
results_path = r'F:/github/pycharm/projects/kalmannet/results'
logs_writer_path = r'logs/train'

# 使用DataHandler
data_handler = DataHandler(data_file_path, '1999-01-01 01', '2011-01-01 01')
data = data_handler.load_and_filter_data()
tm_hours = data_handler.convert_time_to_hours(data['date']).to_numpy()
p, etpot, qobs = data['P'].to_numpy(), data['ETpot'].to_numpy(), data['Q'].to_numpy()
train_data, val_data, test_data = data_handler.split_data(p, etpot, qobs, tm_hours, [0.7, 0.15, 0.15])
p_train, etpot_train, qobs_train, tm_train = train_data
p_val, etpot_val, qobs_val, tm_val = val_data
p_test, etpot_test, qobs_test, tm_test = test_data
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def add_gaussian_noise(arr, noise_level=0.05, seed=33, ensure_non_negative=True):
    """
    对数组 arr 添加加性高斯噪声，噪声标准差 = noise_level * arr.std()。
    """
    rng = np.random.RandomState(seed)
    arr_std = arr.std() if arr.std() > 1e-8 else 1.0
    noise = rng.normal(loc=0.0, scale=noise_level * arr_std, size=arr.shape)
    arr_noisy = arr + noise
    if ensure_non_negative:
        arr_noisy = np.clip(arr_noisy, 0, None)
    return arr_noisy

# 定义一个函数，用于给定p, etpot, qobs运行模型得到states_all，并绘图保存
def run_model_and_save_states(p_array, etpot_array, qobs_array, sim_len, state0, params, filename_prefix):
    # 转化为Torch张量
    p_tensor = torch.tensor(p_array, dtype=torch.float32, device=device).unsqueeze(0)      # [1, sim_len]
    etpot_tensor = torch.tensor(etpot_array, dtype=torch.float32, device=device).unsqueeze(0) # [1, sim_len]
    qobs_tensor = torch.tensor(qobs_array, dtype=torch.float32, device=device).unsqueeze(0)   # [1, sim_len]

    hydro_model = WalrusBatch(cw=params["cw"], cv=params["cv"], cg=params["cg"], cq=params["cq"], cd=params["cd"],
                              cs=params["cs"], initial_state=state0)
    hydro_model.set_state(state0)

    m = hydro_model.m

    states_all = torch.zeros((sim_len, m), dtype=torch.float32, device=device)
    states_all[0, :] = state0

    with tqdm(range(1, sim_len), desc=f"Running Walrus Model {filename_prefix}", unit="step") as pbar:
        for t in pbar:
            controls_t = torch.cat((p_tensor[:, t], etpot_tensor[:, t]), dim=-1).unsqueeze(0)  # [1, 2]
            x_prev = states_all[t - 1, :].unsqueeze(0)  # 上一时刻的状态 [1, m]
            x_next = hydro_model.f(x_prev, controls_t)  # [1, m]
            states_all[t, :] = x_next.squeeze(0)

    # 绘图对比
    q_state = states_all[:, -1].detach().cpu().numpy()  # 转成numpy方便绘图
    q_obs_plot = qobs_tensor[0, 0:sim_len].squeeze(0).detach().cpu().numpy()  # [sim_len]
    # 计算MSE
    mse = np.mean((q_obs_plot - q_state) ** 2)
    print(f"MSE between q_obs_plot and q_state for {filename_prefix}: {mse}")
    plt.figure(figsize=(10, 6))
    plt.plot(q_obs_plot, label='Observed Q', alpha=0.7)
    plt.plot(q_state, label='Modeled Q (states_all last dim)', alpha=0.7)
    plt.title(f'Comparison of Modeled Q and Observed Q - {filename_prefix}')
    plt.xlabel('Time step')
    plt.ylabel('Q')
    plt.legend()
    plt.grid(True)
    plt.show()

    # 保存状态
    torch.save(states_all, f"F:/github/pycharm/projects/kalmannet/data/processed/{filename_prefix}_states_all.pt")
    return states_all


# ========== 第三步：对训练数据加噪并组合(数据增广) ==========
noise_level_p, noise_level_ep, noise_level_q = 0.05, 0.05, 0.03   # 的噪声强度
p_train_noisy = add_gaussian_noise(p_train, noise_level=noise_level_p, seed=1)
etpot_train_noisy = add_gaussian_noise(etpot_train, noise_level=noise_level_ep, seed=2)
qobs_train_noisy = add_gaussian_noise(qobs_train, noise_level=noise_level_q, seed=3)

# 拼接原数据与加噪数据
p_train_aug = np.concatenate([p_train, p_train_noisy], axis=0)
etpot_train_aug = np.concatenate([etpot_train, etpot_train_noisy], axis=0)
qobs_train_aug = np.concatenate([qobs_train, qobs_train_noisy], axis=0)
tm_train_aug = np.concatenate([tm_train, tm_train], axis=0)  # 时间序列重复
print("原训练集大小:", p_train.shape, etpot_train.shape, qobs_train.shape)
print("增广后训练集大小:", p_train_aug.shape, etpot_train_aug.shape, qobs_train_aug.shape)

state0_train = torch.tensor([140.0, 1000.0, 4.0, 1200.0, 0.1])
state0_val = torch.tensor([140.0, 1000.0, 4.0, 1200.0, 0.1])
state0_test = torch.tensor([140.0, 1000.0, 4.0, 1200.0, 0.1])
window_size = 800
# 分别运行模型得到train, val, test 的 states_all
sim_len_train, sim_len_val, sim_len_test = p_train_aug.shape[0], p_val.shape[0], p_test.shape[0]
states_all_train = run_model_and_save_states(p_train_aug, etpot_train_aug, qobs_train_aug, sim_len_train, state0_train, params, f"window_size_{window_size}_train")
states_all_val = run_model_and_save_states(p_val, etpot_val, qobs_val, sim_len_val, state0_val, params, f"window_size_{window_size}_val")
states_all_test = run_model_and_save_states(p_test, etpot_test, qobs_test, sim_len_test, state0_test, params, f"window_size_{window_size}_test")


# 使用对应的 states_all 文件构建数据集和DataLoader


train_dataset = WindowedTimeSeriesDataset(p_train_aug[:sim_len_train], etpot_train_aug[:sim_len_train], qobs_train_aug[:sim_len_train], tm_train_aug[:sim_len_train],
                                          f"F:/github/pycharm/projects/kalmannet/data/processed/window_size_{window_size}_train_states_all.pt", window_size=window_size)
val_dataset = WindowedTimeSeriesDataset(p_val[:sim_len_val], etpot_val[:sim_len_val], qobs_val[:sim_len_val], tm_val[:sim_len_val],
                                         f"F:/github/pycharm/projects/kalmannet/data/processed/window_size_{window_size}_val_states_all.pt", window_size=window_size)
test_dataset = WindowedTimeSeriesDataset(p_test[:sim_len_test], etpot_test[:sim_len_test], qobs_test[:sim_len_test], tm_test[:sim_len_test],
                                          f"F:/github/pycharm/projects/kalmannet/data/processed/window_size_{window_size}_test_states_all.pt", window_size=window_size)

# 直接保存数据集对象
torch.save(train_dataset,  f"F:/github/pycharm/projects/kalmannet/data/processed/window_size_{window_size}_train_dataset.pt")
torch.save(val_dataset,  f"F:/github/pycharm/projects/kalmannet/data/processed/window_size_{window_size}_val_dataset.pt")
torch.save(test_dataset, f"F:/github/pycharm/projects/kalmannet/data/processed/window_size_{window_size}_test_dataset.pt")

# 然后创建DataLoader：
batch_size = 32
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

# 检查加载的数据
check_data_loader(train_loader, "Training Data")
check_data_loader(val_loader, "Validation Data")
check_data_loader(test_loader, "Test Data")
