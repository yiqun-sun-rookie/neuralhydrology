"""
NOTE (2026-02-18): This script was used for exploratory analysis only.
The final training configurations (idx0057 for LSTM-NGF, idx0007 for
Trainable-UKF) use **manually specified** clamp/scale values based on
open-loop state ranges plus a safety margin — NOT the output of this
script.  See trainable_kf_config.yaml → model.knet.clamp_scale.

The function below merges train/val/test data to compute statistics,
which would constitute information leakage if used for training.
Since it was NOT used for the final experiments, no leakage occurred.
"""
import os
import torch
import numpy as np
from hydrologic.data_handler import DataHandler


def compute_clamp_and_scale_for_states_qobs_diff(
        states_all_train, states_all_val, states_all_test,
        qobs_train, qobs_val, qobs_test,
        margin_ratio=0.2
):
    """
    根据三段(train/val/test)的数据，统计“相邻时刻”差值的 min/max，并留一定安全余量，
    从而生成 clamp区间(clamp_min, clamp_max) 和 scale 值。

    - 前两个( obs_diff, obs_innov_diff )的范围 => 用 qobs(t+1)-qobs(t)
    - 后两个( fw_evol_diff, fw_update_diff )的范围 => 用 states_all(t+1)-states_all(t) for each dimension
      (这里 states_all shape=[N,5])

    参数:
        states_all_*: shape=[N, 5] 的状态张量 (dv, dg, hq, hs, q)
        qobs_*: 1D数组 (或list, shape=[N_q])
        margin_ratio (float): 安全余量比例, 默认0.2 => 在统计到的min/max基础上扩展20%

    返回:
        {
           "obs_diff_clamp": (clamp_min_obs, clamp_max_obs),
           "obs_diff_scale": scale_obs,

           "fw_diff_clamp": [ (clamp_min_dim0, clamp_max_dim0), ..., (clamp_min_dim4, clamp_max_dim4) ],
           "fw_diff_scale": [ scale0, scale1, scale2, scale3, scale4 ]
        }
    """

    # ========== 1) 若是Tensor, 转成np ==========

    def maybe_to_numpy(arr):
        if isinstance(arr, torch.Tensor):
            arr = arr.cpu().numpy()
        return arr

    states_all_train = maybe_to_numpy(states_all_train)
    states_all_val = maybe_to_numpy(states_all_val)
    states_all_test = maybe_to_numpy(states_all_test)

    qobs_train = maybe_to_numpy(qobs_train)
    qobs_val = maybe_to_numpy(qobs_val)
    qobs_test = maybe_to_numpy(qobs_test)

    # ========== 2) 合并三段 ==========

    # states_all => shape=[N,5], 先合并
    states_all = np.concatenate([states_all_train, states_all_val, states_all_test], axis=0)
    # qobs => 1D
    qobs_all = np.concatenate([qobs_train, qobs_val, qobs_test], axis=0)

    # ========== 3) 计算 "相邻差值" for qobs ==========

    # qobs_all shape=[M], => consecutive diff => shape=[M-1]
    if len(qobs_all) > 1:
        diff_qobs = qobs_all[1:] - qobs_all[:-1]
    else:
        # 万一只有一个点, 就造个0
        diff_qobs = np.array([0.0])

    q_min_val = diff_qobs.min()
    q_max_val = diff_qobs.max()
    q_span = q_max_val - q_min_val
    # 留安全余量
    q_clamp_min = q_min_val - margin_ratio * q_span
    q_clamp_max = q_max_val + margin_ratio * q_span
    if abs(q_clamp_max) < 1e-9:
        q_scale = 1e-6
    else:
        q_scale = q_clamp_max

    # ========== 4) 计算 "相邻差值" for states_all ==========

    # states_all shape=[N,5], => consecutive diff => shape=[N-1, 5]
    if states_all.shape[0] > 1:
        diff_states = states_all[1:, :] - states_all[:-1, :]  # shape=[N-1, 5]
    else:
        # 万一只有一条, 就造一个 [1,5] 全0
        diff_states = np.zeros((1, 5), dtype=np.float32)

    n_dim = diff_states.shape[1]  # 5
    fw_clamp_min_list = []
    fw_clamp_max_list = []
    fw_scale_list = []

    for i in range(n_dim):
        col_data = diff_states[:, i]
        min_val = col_data.min()
        max_val = col_data.max()

        span = max_val - min_val
        clamp_min = min_val - margin_ratio * span
        clamp_max = max_val + margin_ratio * span

        if abs(clamp_max) < 1e-9:
            scale_i = 1e-6
        else:
            scale_i = clamp_max

        fw_clamp_min_list.append(clamp_min)
        fw_clamp_max_list.append(clamp_max)
        fw_scale_list.append(scale_i)

    # ========== 5) 打印结果 ==========

    print("\n===== Proposed clamp+scale for obs_diff (and obs_innov_diff) =====")
    print(f"obs_diff_clamp=({q_clamp_min:.4f}, {q_clamp_max:.4f}), obs_diff_scale={q_scale:.4f}")

    print("\n===== Proposed clamp+scale for fw_evol_diff (and fw_update_diff) =====")
    for i in range(n_dim):
        print(
            f"dim={i}, clamp_min={fw_clamp_min_list[i]:.4f}, clamp_max={fw_clamp_max_list[i]:.4f}, scale={fw_scale_list[i]:.4f}")

    # ========== 6) 返回字典 ==========

    result_dict = {
        "obs_diff_clamp": (q_clamp_min, q_clamp_max),
        "obs_diff_scale": q_scale,

        "fw_diff_clamp": list(zip(fw_clamp_min_list, fw_clamp_max_list)),
        "fw_diff_scale": fw_scale_list
    }
    return result_dict


if __name__ == "__main__":

    ### 1) 从文件中读取保存好的 states_all (train/val/test) ###

    # 你贴出的脚本里保存了类似:
    # "F:/github/pycharm/projects/kalmannet/data/processed/window_size_800_train_states_all.pt"
    # 这里我们硬编码一下, 你可根据实际路径修改:
    base_path = r"F:/github/pycharm/projects/kalmannet/data/processed"
    train_states_path = os.path.join(base_path, "window_size_800_train_states_all.pt")
    val_states_path   = os.path.join(base_path, "window_size_800_val_states_all.pt")
    test_states_path  = os.path.join(base_path, "window_size_800_test_states_all.pt")

    # 加载
    states_all_train = torch.load(train_states_path, weights_only=True)  # shape=[sim_len_train, 5], Tensor
    states_all_val   = torch.load(val_states_path, weights_only=True)
    states_all_test  = torch.load(test_states_path, weights_only=True)

    print("Loaded states_all shapes:",
          states_all_train.shape, states_all_val.shape, states_all_test.shape)

    ### 2) 同理, 我们假设你在脚本中已经有 p_train, qobs_train, p_val, qobs_val, p_test, qobs_test 等.
    #     如果此脚本独立运行, 也可以手动 load 你的 train_data/val_data/test_data 进行拆分:
    #     例如 torch.save(...) 之后, or 直接用numpy保存. 这里直接模拟你脚本里已有的:
    #     from your_script import p_train, etpot_train, qobs_train, p_val, etpot_val, qobs_val, p_test, etpot_test, qobs_test
    #     - 假设你现在只是演示:
    #        p_train, etpot_train, qobs_train = ...
    #        p_val,   etpot_val,   qobs_val   = ...
    #        p_test,  etpot_test,  qobs_test  = ...

    # 如果你在当前脚本就有 p_train, etpot_train, qobs_train..., 那就直接引用:
    # (这里我们先假设是numpy array):
    # from your_data_splitting_script import p_train, qobs_train, p_val, qobs_val, p_test, qobs_test
    # For demonstration, I'll just define them as empty for now:


    # ========== 1) 从文件读取原始数据并拆分为 train/val/test ==========

    data_file_path = r'F:\github\pycharm\projects\kalmannet\data\hydrologic\PEQ_Regge_hour.txt'
    saved_models_path = r'/results/saved_models/'
    results_path = r'F:/github/pycharm/projects/kalmannet/results'
    logs_writer_path = r'logs/train'

    # 初始化 DataHandler, 这里示例是 '1999-01-01 01' ~ '2000-01-01 01' 的时间段
    data_handler = DataHandler(data_file_path, '1999-01-01 01', '2000-01-01 01')

    data = data_handler.load_and_filter_data()  # 得到一个 pandas DataFrame
    tm_hours = data_handler.convert_time_to_hours(data['date']).to_numpy()

    p = data['P'].to_numpy()  # 降雨
    etpot = data['ETpot'].to_numpy()  # 潜在蒸发
    qobs = data['Q'].to_numpy()  # 流量 (观测)

    # 按 70% / 15% / 15% 划分成 train_data, val_data, test_data
    train_data, val_data, test_data = data_handler.split_data(
        p, etpot, qobs, tm_hours, [0.7, 0.15, 0.15])
    # train_data, val_data, test_data 各返回 (p, etpot, qobs, tm_hours) 四个数组

    p_train, etpot_train, qobs_train, tm_train = train_data
    p_val, etpot_val, qobs_val, tm_val = val_data
    p_test, etpot_test, qobs_test, tm_test = test_data

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print("=== Loaded data shapes ===")
    print("p_train:", p_train.shape, "qobs_train:", qobs_train.shape)
    print("p_val:  ", p_val.shape, "qobs_val:  ", qobs_val.shape)
    print("p_test: ", p_test.shape, "qobs_test: ", qobs_test.shape)

    # ========== 2) 如果你后面还要使用 states_all_xxx.pt 就直接加 ==========

    # 例如你有:
    # train_states_path = "F:/github/pycharm/projects/kalmannet/data/processed/window_size_800_train_states_all.pt"
    # states_train = torch.load(train_states_path)
    # ...

    # ========== 3) 之后, 你就可以把 qobs_train/val/test 传给后面函数, 取代 dummy 值 ==========

    # 例如:
    # clamp_scale_info = compute_clamp_and_scale_for_states_qobs(
    #     states_train=states_train,
    #     states_val=states_val,
    #     states_test=states_test,
    #     qobs_train=qobs_train,
    #     qobs_val=qobs_val,
    #     qobs_test=qobs_test,
    #     margin_ratio=0.2
    # )

    # 后续即可使用 clamp_scale_info 等

    # 在实际中, 你要用 你的 train_data, val_data, test_data 里的 qobs.

    ### 3) 调用函数来生成 clamp & scale 配置 ###

    clamp_scale_info = compute_clamp_and_scale_for_states_qobs_diff(
        states_all_train=states_all_train,  # 这几个是Tensor
        states_all_val=states_all_val,
        states_all_test=states_all_test,
        qobs_train=qobs_train,              # 这几个是numpy array
        qobs_val=qobs_val,
        qobs_test=qobs_test,
        margin_ratio=0.2
    )

    ### 4) 你可以打印或保存 clamp_scale_info ###
    print("\n=== clamp & scale info ===")
    print(clamp_scale_info)

    # 如果想保存到json/pickle, 也可以:
    # import json
    # with open("clamp_scale_info.json","w") as f:
    #     json.dump(clamp_scale_info, f, indent=2)

    # Done!
