# print_utils.py
def print_dataset_sizes(p_train, p_val, p_test):
    print("trainset size:", p_train.size())
    print("cvset size:", p_val.size())
    print("testset size:", p_test.size())

