import torch
import numpy as np
import random
def initialize_seed(seed_value):
    """
    Initialize random seeds to ensure reproducibility.
    """
    torch.manual_seed(seed_value)
    np.random.seed(seed_value)
    random.seed(seed_value)
