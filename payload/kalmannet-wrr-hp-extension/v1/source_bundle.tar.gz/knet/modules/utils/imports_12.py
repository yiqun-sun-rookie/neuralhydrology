from filters.modules.utils.initializations import initialize_seed
import torch
from datetime import datetime
import os
from hydrologic.utils import plot_batch_time_series, compare_q_obs_and_q_sim
from filters.modules.pipeline.system_model import SystemModel
import configs.config as config
from tqdm import tqdm
import matplotlib.pyplot as plt
from filters.modules.pipeline.walrus_batch_speedup import WalrusBatch
import random
import numpy as np
from filters.modules.utils.model_initialization_use_script_mdl_1 import initialize_system_model
from hydrologic.dataset import WindowedTimeSeriesDataset
from torch.utils.data import DataLoader
from hydrologic.data_handler import DataHandler
from filters.modules.utils.check_data_loader import check_data_loader
from filters.modules.data_preprocessor.windowed_time_series import WindowedTimeSeriesDataset
from torch.utils.data import DataLoader
from hydrologic.data_handler import DataHandler
from filters.modules.utils.check_data_loader import check_data_loader
from hydrologic.params import params
from configs.train_config_8 import set_train_params
from filters.modules.nn.nn_state_scale_12 import KalmanNet
from filters.modules.pipeline.pipeline_update_save_8 import Pipeline
import tqdm
# 设置随机种子
initialize_seed(3)