# -*- coding: utf-8 -*-
"""metrics_v2.py  — Display-only evaluation utilities

* Adds **nse_high**, **mse_high**, etc. to separately monitor high‑flow performance.
* Supports additional metrics: **rmse**, **bias**, **kge** (and *_high variants).
* Keeps API similar to original `compute_display_metrics`.

Example
-------
# >>> from filters.modules.utils.metrics_v2 import compute_display_metrics
# >>> compute_display_metrics(pred, obs, metrics=("mse", "rmse", "kge", "nse_high"), high_flow_thr=0.0863)
"""
from __future__ import annotations

from typing import Iterable, Dict
import torch

def _masked_average(t: torch.Tensor, mask: torch.Tensor, reduction: str = "mean") -> torch.Tensor:
    if mask.sum() == 0:
        return torch.tensor(0.0, device=t.device)
    if reduction == "mean":
        return (t * mask).sum() / mask.sum()
    return (t * mask).sum()

def _kge(pred: torch.Tensor, obs: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    """Compute KGE on flattened tensors, returns scalar tensor."""
    pred_flat = pred.reshape(-1)
    obs_flat = obs.reshape(-1)
    if pred_flat.numel() == 0:
        return torch.tensor(0.0, device=pred.device)

    pred_mean = pred_flat.mean()
    obs_mean = obs_flat.mean()
    pred_std = pred_flat.std()
    obs_std = obs_flat.std() + eps

    centered_pred = pred_flat - pred_mean
    centered_obs = obs_flat - obs_mean
    covariance = (centered_pred * centered_obs).mean()
    r = covariance / (pred_std * obs_std + eps)

    alpha = pred_std / obs_std
    beta = pred_mean / (obs_mean + eps)

    kge = 1.0 - torch.sqrt((r - 1.0) ** 2 + (alpha - 1.0) ** 2 + (beta - 1.0) ** 2 + eps)
    return kge

def compute_display_metrics(
    pred: torch.Tensor,
    obs: torch.Tensor,
    *,
    metrics: Iterable[str] = ("mse", "nse"),
    lead_times: Iterable[int] | None = None,
    high_flow_thr: float | None = None,
) -> Dict[str, float]:
    """Display‑only metrics without gradient.

    Parameters
    ----------
    pred, obs : shape [N, L]
    metrics   : tuple of metric names (supports 'mse', 'rmse', 'l1', 'bias', 'kge', 'nse',
                plus *_high variants for high-flow subsets)
    lead_times: optional sub‑set indices
    high_flow_thr : threshold for high‑flow masks; required if *_high metrics present
    """
    results: Dict[str, float] = {}

    if lead_times is not None:
        pred = pred[:, lead_times]
        obs  = obs[:, lead_times]

    if high_flow_thr is None and any(m.endswith("_high") for m in metrics):
        raise ValueError("high_flow_thr must be provided when requesting *_high metrics")

    mse_map = (pred - obs) ** 2               # [N, L]
    l1_map  = torch.abs(pred - obs)           # [N, L]
    bias_map = (pred - obs)                   # [N, L]

    # ---- base metrics ----
    if "mse" in metrics:
        results["mse"] = mse_map.mean().item()
    if "rmse" in metrics:
        results["rmse"] = torch.sqrt(mse_map.mean()).item()
    if "l1" in metrics:
        results["l1"] = l1_map.mean().item()
    if "bias" in metrics:
        results["bias"] = bias_map.mean().item()
    if "nse" in metrics:
        with torch.no_grad():
            obs_mean = obs.mean(dim=0, keepdim=True)
            nse_lt = 1.0 - ((obs - pred) ** 2).sum(dim=0) / (
                ((obs - obs_mean) ** 2).sum(dim=0) + 1e-8
            )
            results["nse"] = nse_lt.mean().item()
    if "kge" in metrics:
        with torch.no_grad():
            results["kge"] = _kge(pred, obs).item()

    # ---- high‑flow mask ----
    if any(m.endswith("_high") for m in metrics):
        mask = (obs > high_flow_thr).float()  # [N, L]
        if "mse_high" in metrics:
            results["mse_high"] = _masked_average(mse_map, mask).item()
        if "rmse_high" in metrics:
            rmse_high = torch.sqrt(_masked_average(mse_map, mask))
            results["rmse_high"] = rmse_high.item()
        if "bias_high" in metrics:
            results["bias_high"] = _masked_average(bias_map, mask).item()
        if "nse_high" in metrics:
            with torch.no_grad():
                if mask.sum() == 0:
                    results["nse_high"] = 0.0
                else:
                    pred_h = pred[mask.bool()]
                    obs_h  = obs[mask.bool()]
                    obs_h_mean = obs_h.mean()
                    nse_h = 1 - ((obs_h - pred_h) ** 2).sum() / (
                        ((obs_h - obs_h_mean) ** 2).sum() + 1e-8
                    )
                    results["nse_high"] = nse_h.item()
        if "kge_high" in metrics:
            with torch.no_grad():
                if mask.sum() == 0:
                    results["kge_high"] = 0.0
                else:
                    pred_h = pred[mask.bool()]
                    obs_h  = obs[mask.bool()]
                    results["kge_high"] = _kge(pred_h, obs_h).item()
    return results
