from __future__ import annotations
import torch
from typing import Dict, Tuple
import numpy as np
# ----------------------------
# 1) 逐元素(逐 lead_time)误差计算
# ----------------------------
def mse_map(pred, obs):
    """(pred - obs)^2, shape同 pred,obs => [batch_size, lead_time]."""
    return (pred - obs) ** 2


def l1_map(pred, obs):
    """|pred - obs|, shape同 pred,obs => [batch_size, lead_time]."""
    return torch.abs(pred - obs)

def nse_global_map(pred, obs, eps=1e-8):
    """
    计算(1 - NSE)，把 pred, obs 所有维度 (batch_size x lead_time) 展开后整体计算。
    返回 shape=[batch_size, lead_time]，其中每个元素都相同(=标量)，
    以便与 reduce_loss_map 保持一致 (它期望 [batch_size, lead_time] 形状)。
    """
    # 1) 展开到一维
    #    pred, obs => [batch_size, lead_time]
    pred_flat = pred.reshape(-1)  # => [B*L]
    obs_flat  = obs.reshape(-1)   # => [B*L]

    # 2) 全局 mean(obs)
    obs_mean = obs_flat.mean()

    # 3) (1-NSE) = numerator/denominator
    numerator   = torch.sum((obs_flat - pred_flat)**2)
    denominator = torch.sum((obs_flat - obs_mean)**2) + eps
    nse_global  = numerator / denominator  # => 标量 (1-NSE)

    # 4) 为了后续能用 reduce_loss_map，返回与 pred 同形状 [batch_size, lead_time]。
    #    大小相同的每个元素都= nse_global
    return nse_global.unsqueeze(0).expand_as(pred)

def nse_map(pred, obs, eps=1e-8):
    """
    计算(1-NSE)的逐 lead_time 误差图。最终返回 shape = [batch_size, lead_time]。
    """
    # obs_mean => [1, lead_time]
    obs_mean = obs.mean(dim=0, keepdim=True)
    # numerator => sum_{batch}((obs - pred)^2) => shape=[lead_time]
    numerator = ((obs - pred) ** 2).sum(dim=0)
    # denominator => sum_{batch}((obs - obs_mean)^2) => shape=[lead_time]
    denominator = ((obs - obs_mean) ** 2).sum(dim=0) + eps
    # nse_loss_lt => numerator / denominator => shape=[lead_time]
    nse_loss_lt = numerator / denominator  # 这是(1 - NSE)数值

    # 将 [lead_time] 广播回 [batch_size, lead_time]
    return nse_loss_lt.unsqueeze(0).expand_as(obs)

def reduce_loss_map(loss_map, lead_times=None, reduction='mean'):
    """
    选择性只对特定 lead_times 的误差做统计，并最终聚合成标量。

    lead_times: None 或 list[int]
      - None 表示使用全部列
      - list 表示按列索引取
    reduction: 'mean' or 'sum'
    """
    if lead_times is not None:
        # 注意是否0-based索引
        loss_map = loss_map[:, lead_times]

    if reduction == 'mean':
        return loss_map.mean()
    elif reduction == 'sum':
        return loss_map.sum()
    else:
        raise ValueError(f"Unsupported reduction mode: {reduction}")

# -------------------------------------
# 3) 训练时调用的主函数
# -------------------------------------
def compute_train_loss(pred, obs, metric='mse', lead_times=None, reduction='mean'):
    """
    返回一个标量，用于 backward().
    metric: 'mse'/'l1'/'nse'/'nse_global'
    lead_times: None 或 list[int]
    reduction: 'mean'/'sum'
    """
    if metric.lower() == 'mse':
        loss_map = mse_map(pred, obs)
    elif metric.lower() == 'l1':
        loss_map = l1_map(pred, obs)
    elif metric.lower() == 'nse':
        # 逐 lead_time (1-NSE) => shape=[batch_size, lead_time]
        loss_map = nse_map(pred, obs)
    elif metric.lower() == 'nse_global':
        # 整体 (1-NSE)，把所有 (batch x lead_time) 展开
        loss_map = nse_global_map(pred, obs)
    elif metric.lower() == 'kge':
        # KGE loss (1 - KGE) 全局标量，扩展为与 pred 同形状
        kge_loss = differentiable_kge_loss(pred, obs)
        loss_map = kge_loss.unsqueeze(0).expand_as(pred)
    else:
        raise ValueError(f"不支持的训练损失类型: {metric}")

    # 最后对 loss_map 做 reduce
    return reduce_loss_map(loss_map, lead_times=lead_times, reduction=reduction)


# -------------------------------------
# 4) 只用于显示的指标计算
# -------------------------------------
def compute_display_metrics(pred, obs, metrics=('mse', 'nse'), lead_times=None):
    """
    返回一个 dict，如 {"mse": <value>, "nse": <value>}。
    这里仅做统计用，不回传梯度。
    """
    results = {}

    # 先截取要用的 lead_time
    if lead_times is not None:
        pred = pred[:, lead_times]
        obs = obs[:, lead_times]

    # MSE
    if 'mse' in metrics:
        mse_val = (pred - obs).pow(2).mean().item()
        results['mse'] = mse_val

    # L1
    if 'l1' in metrics:
        l1_val = torch.abs(pred - obs).mean().item()
        results['l1'] = l1_val

    # NSE
    if 'nse' in metrics:
        with torch.no_grad():
            obs_mean = obs.mean(dim=0, keepdim=True)
            numerator = ((obs - pred) ** 2).sum(dim=0)
            denominator = ((obs - obs_mean) ** 2).sum(dim=0) + 1e-8
            # 这里是 nse(t) = 1 - numerator/denominator, shape=[lead_time]
            nse_lt = 1.0 - numerator / denominator
            nse_avg = nse_lt.mean().item()  # lead_time 再平均
        results['nse'] = nse_avg

    # KGE
    if 'kge' in metrics:
        with torch.no_grad():
            kge_loss = differentiable_kge_loss(pred, obs)
            kge_val = (1.0 - kge_loss).item()
        results['kge'] = kge_val

    return results

# -*- coding: utf-8 -*-
"""losses_composite.py

A drop‑in replacement for the original ``compute_train_loss`` that :
1. **Jointly** optimises updated output (lead‑time 0) and future forecasts.
2. Adds **high‑flow** and **rising‑limb** weighting to emphasise flood periods.
3. Optionally uses log‑MSE and a slope (dQ/dt) regulariser.

Import and call ``composite_loss`` *instead* of ``compute_train_loss`` inside
``run_one_batch``. The function returns a **scalar** suitable for ``backward``
*plus* a dict of diagnostic terms for logging.
"""

import torch.nn.functional as F

def composite_loss(
    outputs_fc: torch.Tensor,      # [B*T, lead_time]  —— future forecast
    y_future: torch.Tensor,       # same shape as outputs_fc
    outputs_upd: torch.Tensor,    # [B*T] or [B]     —— lead‑time 0 output
    y_now: torch.Tensor,          # same shape as outputs_upd
    *,
    lambda_upd: float = 0.2,
    high_flow_thr: float = 500.0,
    alpha_hf: float = 3.0,
    delta_thr: float = 20.0,
    beta_rise: float = 3.0,
    use_log: bool = False,
    gamma_slope: float = 0.0,
    reduction: str = "mean",
    loss_type: str = "mse",  # 'mse', 'nse', 'kge'
) -> Tuple[torch.Tensor, Dict[str, float]]:
    """Compute **future‑forecast + λ·update** composite loss.

    Parameters
    ----------
    outputs_fc : forecast for lead_time>0, flattened as [N, L]
    y_future   : observations for the same horizon and shape
    outputs_upd: updated output at lead_time=0  [N]
    y_now      : observation at lead_time=0     [N]
    lambda_upd : weight of update‑term in total loss
    high_flow_thr, alpha_hf : high‑flow mask & multiplier
    delta_thr, beta_rise    : rising‑limb mask & multiplier
    use_log     : if True uses log1p before MSE
    gamma_slope : additional weight for slope loss (dQ/dt)
    reduction   : 'mean' or 'sum'
    loss_type   : 'mse', 'nse', or 'kge' - the base loss function to use

    Returns
    -------
    total_loss : scalar tensor for backward()
    metrics    : dict of sub‑loss values (for logging)
    """

    device = outputs_fc.device
    loss_type = loss_type.lower()

    # ---- helper for MSE-based losses (with optional weighting) ---------
    def _base_loss(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
        """Compute base loss (MSE, NSE, or KGE) between predictions and observations."""
        if loss_type == "mse":
            if use_log:
                a, b = torch.log1p(a), torch.log1p(b)
            return (a - b) ** 2
        elif loss_type == "nse":
            # For NSE, we compute it globally (flattened)
            return differentiable_nse_loss(a, b)
        elif loss_type == "kge":
            # For KGE, we compute it globally (flattened)
            return differentiable_kge_loss(a, b)
        else:
            raise ValueError(f"Unsupported loss_type: {loss_type}. Must be 'mse', 'nse', or 'kge'.")

    # ---- helper for weighted MSE (used for high-flow and rising-limb) --
    def _mse(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
        if use_log:
            a, b = torch.log1p(a), torch.log1p(b)
        return (a - b) ** 2

    # ---------------------------------------------------------------------
    # 1)  FUTURE ‑ horizon > 0
    # ---------------------------------------------------------------------
    if loss_type == "mse":
        # For MSE, apply high-flow and rising-limb weighting
        mse_future = _mse(outputs_fc, y_future)  # [N, L]
        
        # — High‑flow mask —
        hf_mask = (y_future > high_flow_thr).float()
        mse_future = mse_future * (1.0 + hf_mask * (alpha_hf - 1.0))
        
        # — Rising‑limb mask (ΔQ > delta_thr) —
        rising = torch.cat(
            (
                torch.zeros_like(y_future[:, :1]),
                (y_future[:, 1:] - y_future[:, :-1]) > delta_thr,
            ),
            dim=1,
        ).float()
        mse_future = mse_future * (1.0 + rising * (beta_rise - 1.0))
        
        # Aggregate
        loss_future = mse_future.mean() if reduction == "mean" else mse_future.sum()
    else:
        # For NSE/KGE, compute globally (no per-timestep weighting)
        # Note: High-flow and rising-limb weighting is less meaningful for global metrics
        loss_future = _base_loss(outputs_fc, y_future)

    # Optional slope regulariser (only for MSE-based)
    loss_slope = torch.tensor(0.0, device=device)
    if gamma_slope > 0.0 and y_future.size(1) > 1 and loss_type == "mse":
        dq_dt_pred = outputs_fc[:, 1:] - outputs_fc[:, :-1]
        dq_dt_obs = y_future[:, 1:] - y_future[:, :-1]
        loss_slope = _mse(dq_dt_pred, dq_dt_obs).mean()

    # ---------------------------------------------------------------------
    # 2)  UPDATE ‑ lead_time == 0
    # ---------------------------------------------------------------------
    if loss_type == "mse":
        mse_upd = _mse(outputs_upd, y_now)
        hf_mask0 = (y_now > high_flow_thr).float()
        mse_upd = mse_upd * (1.0 + hf_mask0 * (alpha_hf - 1.0))
        loss_upd = mse_upd.mean() if reduction == "mean" else mse_upd.sum()
    else:
        # For NSE/KGE, compute globally
        loss_upd = _base_loss(outputs_upd, y_now)

    # ---------------------------------------------------------------------
    total = loss_future + lambda_upd * loss_upd + gamma_slope * loss_slope

    metrics = {
        "loss_total": total.item(),
        "loss_future": loss_future.item(),
        "loss_upd": loss_upd.item(),
        "loss_slope": loss_slope.item(),
    }
    return total, metrics


def cal_nse_vector(observed, simulated):
    """
    Calculate Nash-Sutcliffe Efficiency coefficient
    NSE = 1 - [sum(observed - simulated)^2] / [sum(observed - mean(observed))^2]
    NSE ranges from -inf to 1, with 1 being perfect match
    """
    if len(observed) != len(simulated):
        raise ValueError("Observed and simulated arrays must be the same length")

    # Calculate the numerator (sum of squared residuals)
    numerator = np.sum((observed - simulated) ** 2)

    # Calculate the denominator (sum of squared deviations from mean observed)
    obs_mean = np.mean(observed)
    denominator = np.sum((observed - obs_mean) ** 2)

    # Calculate NSE
    if denominator == 0:
        return float('nan')  # Handle division by zero

    nse = 1 - (numerator / denominator)
    return nse


# ============================================================
# Differentiable Loss Functions for End-to-End Training
# ============================================================

def differentiable_nse_loss(pred: torch.Tensor, obs: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    """
    Differentiable NSE loss: returns (1 - NSE) as a scalar tensor.
    
    This is designed to be used as a training loss. The loss is computed globally
    across all samples (batch x lead_time flattened).
    
    Parameters
    ----------
    pred : torch.Tensor
        Predictions, shape [N, L] or [N] where N = batch*time, L = lead_time
    obs : torch.Tensor
        Observations, same shape as pred
    eps : float
        Small epsilon to prevent division by zero
        
    Returns
    -------
    loss : torch.Tensor
        Scalar tensor: (1 - NSE), suitable for backward()
    """
    # Flatten to 1D
    pred_flat = pred.reshape(-1)
    obs_flat = obs.reshape(-1)
    
    # Compute NSE components
    obs_mean = obs_flat.mean()
    numerator = torch.sum((obs_flat - pred_flat) ** 2)
    denominator = torch.sum((obs_flat - obs_mean) ** 2) + eps
    
    # Return (1 - NSE) as loss
    nse_loss = numerator / denominator
    return nse_loss


def differentiable_kge_loss(pred: torch.Tensor, obs: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    """
    Differentiable KGE (Kling-Gupta Efficiency) loss: returns (1 - KGE) as a scalar tensor.
    
    KGE = 1 - sqrt((r-1)^2 + (alpha-1)^2 + (beta-1)^2)
    where:
        r = correlation coefficient
        alpha = std(pred) / std(obs)
        beta = mean(pred) / mean(obs)
    
    Parameters
    ----------
    pred : torch.Tensor
        Predictions, shape [N, L] or [N] where N = batch*time, L = lead_time
    obs : torch.Tensor
        Observations, same shape as pred
    eps : float
        Small epsilon to prevent division by zero
        
    Returns
    -------
    loss : torch.Tensor
        Scalar tensor: (1 - KGE), suitable for backward()
    """
    # Flatten to 1D
    pred_flat = pred.reshape(-1)
    obs_flat = obs.reshape(-1)
    
    # Compute means and standard deviations
    pred_mean = pred_flat.mean()
    obs_mean = obs_flat.mean()
    pred_std = pred_flat.std()
    obs_std = obs_flat.std() + eps
    
    # Correlation coefficient (r)
    # r = E[(X - E[X])(Y - E[Y])] / (std(X) * std(Y))
    centered_pred = pred_flat - pred_mean
    centered_obs = obs_flat - obs_mean
    covariance = (centered_pred * centered_obs).mean()
    r = covariance / (pred_std * obs_std + eps)
    
    # Alpha and Beta
    alpha = pred_std / obs_std
    beta = pred_mean / (obs_mean + eps)
    
    # KGE components
    r_term = (r - 1.0) ** 2
    alpha_term = (alpha - 1.0) ** 2
    beta_term = (beta - 1.0) ** 2
    
    # KGE = 1 - sqrt(r_term + alpha_term + beta_term)
    kge = 1.0 - torch.sqrt(r_term + alpha_term + beta_term + eps)
    
    # Return (1 - KGE) as loss
    kge_loss = 1.0 - kge
    return kge_loss
