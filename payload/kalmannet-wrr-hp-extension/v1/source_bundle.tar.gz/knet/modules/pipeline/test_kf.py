from tqdm import tqdm
import torch
from collections import defaultdict
from filters.modules.pipeline.utils import prepare_batch_data
from filters.modules.pipeline.core_fun import system_model_forecast
from filters.modules.pipeline.core_fun import rearrange_data_unfold
from filters.modules.utils.metrics import compute_train_loss, compute_display_metrics
from filter.non_batch.kalman import MerweScaledSigmaPoints
from filter.batch.my_version.batch_unscentedkalmanfilter_gpu import BatchUnscentedKalmanFilterGPU
from da_coupler.walrus_batch import fx_walrus_batch, hx_walrus_batch
def test_kf(self, test_loader, results_path):
    """Test the pipeline using UKF instead of KalmanNet."""
    total_bp_loss = 0.0
    total_display_loss = defaultdict(float)
    total_samples = 0
    # ⚡️——— 可选：准备保存区域 ———
    if getattr(self, "save_predictions", False):
        self.predictions = []          # 清空／新建容器

    with torch.no_grad():
        for batch in tqdm(test_loader, desc="UKF Testing", unit='batch'):
            p, ep, y_obs, state0, tm_hours = prepare_batch_data(batch, self.device)
            control = torch.cat((p, ep), dim=1)  # [B, 2, T]

            # Run UKF filtering
            states_upd, outputs_upd = ukf_filter(y_obs, control, state0, self.sys_model, self.device)

            # Compute forecasts
            states_forecast_flat, outputs_forecast_flat = system_model_forecast(
                sys_model=self.sys_model,
                p=p, etpot=ep,
                states_updated=states_upd,
                lead_time=self.forecast_lead_time
            )

            # Compute losses
            # 计算损失
            if self.sys_model.n == 1:
                outputs_forecast_flat = outputs_forecast_flat.squeeze(1)
            y_obs_rearranged = rearrange_data_unfold(y_obs, self.forecast_lead_time).reshape(-1,
                                                                                             self.forecast_lead_time)
            bp_loss = compute_train_loss(outputs_forecast_flat, y_obs_rearranged, lead_times=None, reduction='mean')
            display_loss = compute_display_metrics(outputs_forecast_flat, y_obs_rearranged,
                                                   metrics=self.display_metrics_list, lead_times=None)

            batch_size = p.size(0)
            total_bp_loss += bp_loss.item() * batch_size
            for key, value in display_loss.items():
                total_display_loss[key] += value * batch_size
            total_samples += batch_size

            # ⚡️——— 追加保存预测（可选）———
            if getattr(self, "save_predictions", False):
                # ① 将驱动 / 观测窗展开成 [B, T-L+1, L]
                p_win  = rearrange_data_unfold(p,  self.forecast_lead_time).squeeze(2)
                ep_win = rearrange_data_unfold(ep, self.forecast_lead_time).squeeze(2)
                y_win  = rearrange_data_unfold(y_obs, self.forecast_lead_time).squeeze(2)

                # ② 时间戳窗口
                tm_raw = tm_hours.squeeze(1) if tm_hours.dim() == 3 else tm_hours   # [B, T]
                tm_win = tm_raw.unfold(1, self.forecast_lead_time, 1)               # [B, T-L+1, L]

                # ③ 将预测重新 reshape 为窗口格式
                states_fc_win = states_forecast_flat.view(
                    batch_size, -1, self.sys_model.m, self.forecast_lead_time
                )                                                                    # [B, T-L+1, m, L]
                outputs_fc_win = outputs_forecast_flat.view(
                    batch_size, -1, self.forecast_lead_time
                )                                                                    # [B, T-L+1, L]

                # ④ 追加
                self.predictions.append({
                    # —— 原始序列（可按需保留） ——
                    "p_raw":  p.detach().cpu(),
                    "ep_raw": ep.detach().cpu(),
                    "y_obs_raw": y_obs.detach().cpu(),
                    "tm_hours_raw": tm_raw.detach().cpu(),

                    # —— 与预测严格对齐的窗口化张量 ——
                    "p_win":  p_win.detach().cpu(),
                    "ep_win": ep_win.detach().cpu(),
                    "y_obs_win": y_win.detach().cpu(),
                    "tm_hours_win": tm_win.detach().cpu(),

                    # —— UKF 中间量 / 结果 ——
                    "outputs_upd": outputs_upd.detach().cpu(),
                    "states_upd":  states_upd.detach().cpu(),
                    "states_fc_win":   states_fc_win.detach().cpu(),
                    "outputs_fc_win":  outputs_fc_win.detach().cpu(),
                })
    test_bp_loss = total_bp_loss / total_samples
    test_display_loss = {key: val / total_samples for key, val in total_display_loss.items()}

    print(f"UKF Test Results - BP Loss: {test_bp_loss:.5f}")
    for metric, value in test_display_loss.items():
        print(f"  {metric.upper()}: {value:.5f}")

    if getattr(self, 'save_predictions', False):
        # 存储 pipeline.predictions 到同目录
        torch.save(self.predictions, results_path)
        print(f"[INFO] kf test predictions saved => {results_path}")

    return test_bp_loss, test_display_loss


def ukf_filter(y_obs, control, state0, sys_model, device, q_diag=None, r_diag=None):
    """
    Apply UKF filtering to a batch of sequences.

    Args:
        y_obs (torch.Tensor): Observations [B, T, n]
        control (torch.Tensor): Control inputs [B, 2, T]
        state0 (torch.Tensor): Initial states [B, m]
        sys_model: System model with f and h functions
        device: PyTorch DEVICE

    Returns:
        states_upd (torch.Tensor): Filtered states [B, T, m]
        outputs_upd (torch.Tensor): Filtered outputs [B, T, n]
    """
    B, n, T = y_obs.shape
    dim_x = state0.shape[1]

    # Initialize UKF
    points = MerweScaledSigmaPoints(n=dim_x, alpha=0.6874, beta=2., kappa=-2.0)
    points.c = points.alpha ** 2 * (points.n + points.kappa)
    ukf = BatchUnscentedKalmanFilterGPU(
        dim_x=dim_x,
        dim_z=n,
        dt=1.0,
        hx=lambda sigmas: hx_walrus_batch(sigmas, sys_model=sys_model, device=device),
        fx=lambda sigmas, dt: fx_walrus_batch(sigmas, dt, sys_model=sys_model, controls=None),
        points=points,
        batch_size=B
    )

    # Set initial state and covariances
    # state0 = torch.tensor([140.0, 1000.0, 4.0, 1200.0, 0.1])
    # p0 = torch.diag(0.1 * state0)
    # tmp = state0.clone()
    # # tmp[-1] = 0  # 设置最后一个元素为0
    # q = 1e-3 * torch.diag(tmp)
    # r = torch.tensor(1.5e-3)
    ukf.x = state0[:, :, 0].clone()
    # vec.shape == (batch, state_dim)
    # 结果形状: (batch_size, state_dim, state_dim)
    tmp = state0.clone().squeeze(-1) # 设置最后一个元素为0
    tmp[:, -1] = 0.0
    ukf.P = torch.diag_embed(0.1 * state0.clone().squeeze(-1))

    # Q
    if q_diag is None:
        ukf.Q = torch.diag_embed(1e-3 * tmp).to(device)
    else:
        ukf.Q = torch.diag_embed(q_diag.to(device)).unsqueeze(0).repeat(B,1,1)

    # R
    if r_diag is None:
        ukf.R = torch.diag_embed(torch.full((n,), 1.5e-5, device=device))
    else:
        ukf.R = torch.diag_embed(r_diag.to(device)).unsqueeze(0).repeat(B,1,1)

    # Storage for results
    states_upd = torch.zeros(B, dim_x, T, device=device)
    outputs_upd = torch.zeros(B, n, T, device=device)

    # Process sequence
    for t in range(T):
        controls_t = control[:, :, t]  # [B, 2]
        ukf.fx = lambda sigmas, dt: fx_walrus_batch(sigmas, dt, sys_model=sys_model, controls=controls_t, device=device)
        ukf.predict()
        z_t = y_obs[:, :, t]  # [B, n]
        ukf.update(z_t)
        states_upd[:, :, t] = ukf.x.clone()
        outputs_upd[:, :, t] = sys_model.h(ukf.x)  # Assuming sys_model.h can handle [B, m] -> [B, n]

    return states_upd, outputs_upd