import torch
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns  # 导入 Seaborn

# --- LHS 依赖的鲁棒导入策略 -----------------------------------------------
# 优先使用 pyDOE2 (维护更活跃)；若不可用则尝试旧 pyDOE；都不存在则使用内置纯 numpy 回退实现。
_lhs_callable = None
_lhs_backend = None
try:  # pyDOE2
    from pyDOE2 import lhs as _lhs_callable  # type: ignore
    _lhs_backend = "pyDOE2"
except Exception:  # noqa: E722
    try:  # 旧 pyDOE
        from pyDOE import lhs as _lhs_callable  # type: ignore
        _lhs_backend = "pyDOE"
    except Exception:  # noqa: E722
        _lhs_backend = "fallback"


def _lhs_fallback(n_dim: int, samples: int, rng: np.random.Generator) -> np.ndarray:
    """最简 Latin Hypercube 生成 (无优化准则)。

    原理: 对每个维度分成 samples 个等距小区间, 在各区间随机采 1 个点, 再随机打乱顺序。
    该实现满足 LHS 分层覆盖特性; 不做 maximin / correlation 优化, 但避免外部依赖。
    """
    cut_edges = np.linspace(0.0, 1.0, samples + 1)
    out = np.empty((samples, n_dim), dtype=float)
    for j in range(n_dim):
        u = rng.random(samples)
        # 在每个区间内部随机
        pts = cut_edges[:-1] + u * (cut_edges[1:] - cut_edges[:-1])
        rng.shuffle(pts)  # 打乱各层与样本行映射
        out[:, j] = pts
    return out


def _generate_lhs(n_dim: int, samples: int, seed: int | None = None, criterion: str | None = None) -> np.ndarray:
    """统一入口: 后端优先 pyDOE2 -> pyDOE -> 纯 numpy。

    参数
    -----
    n_dim : 维度数
    samples : 样本数
    seed : 可选随机种子 (所有后端尽量遵守)
    criterion : 仅在 pyDOE2/pyDOE 可用时传递 (如 'maximin','center')
    """
    if seed is not None:
        np.random.seed(seed)  # 与 pyDOE2/pyDOE 行为对齐 (它们使用全局 RNG)
    if _lhs_callable is not None:  # 第三方后端
        try:
            if criterion:
                return _lhs_callable(n_dim, samples=samples, criterion=criterion)
            return _lhs_callable(n_dim, samples=samples)
        except Exception:  # 回退到纯 numpy
            pass
    # 纯 numpy 回退 (使用独立 rng 防止污染全局状态)
    rng = np.random.default_rng(seed)
    return _lhs_fallback(n_dim, samples, rng)


sns.set_style("darkgrid")




def plot_comparison(y_obs, sequences, batch_i):
    """
    绘制特定批次中 y_obs 和多个 sequences 的对比图，并在图例中显示 NSE。

    参数:
    - y_obs (torch.Tensor): 真实观测值，形状为 (batch_size, num_features, seq_len)
    - sequences (dict or list of torch.Tensor): 包含多个序列的字典或列表
        - 如果是字典，键为序列名称，值为对应的张量
        - 如果是列表，函数将自动生成序列名称
    - batch_i (int): 要比较的批次索引
    """
    # 确保 batch_i 在有效范围内
    assert 0 <= batch_i < y_obs.shape[0], "batch_i 超出范围"

    # 提取特定批次的 y_obs 数据
    y_obs_batch = y_obs[batch_i]  # 形状: (num_features, seq_len)

    # 初始化序列数据字典
    sequences_data = {}

    if isinstance(sequences, dict):
        # 序列为字典，键为名称
        for name, tensor in sequences.items():
            assert tensor.shape[0] == y_obs.shape[0], f"序列 '{name}' 的 batch_size 不匹配 y_obs"
            sequences_data[name] = tensor[batch_i]
    elif isinstance(sequences, list):
        # 序列为列表，自动生成序列名称
        for idx, tensor in enumerate(sequences, start=1):
            name = f'Sequence {idx}'
            assert tensor.shape[0] == y_obs.shape[0], f"序列 '{name}' 的 batch_size 不匹配 y_obs"
            sequences_data[name] = tensor[batch_i]
    else:
        raise TypeError("sequences 参数必须是字典或列表")

    # 转换数据为 NumPy
    y_obs_batch = y_obs_batch.cpu() if y_obs_batch.is_cuda else y_obs_batch
    sequences_np = {name: (tensor.cpu().detach().numpy() if tensor.is_cuda else tensor.detach().numpy())
                   for name, tensor in sequences_data.items()}
    y_obs_np = y_obs_batch.detach().numpy()

    num_features, seq_len = y_obs_np.shape
    time_steps = np.arange(seq_len)

    # 设置绘图风格
    try:
        sns.set_style("darkgrid")  # 使用 Seaborn 样式
    except Exception as e:
        print(f"警告：无法设置 Seaborn 样式，使用默认 Matplotlib 样式。错误信息：{e}")

    fig, axs = plt.subplots(num_features, 1, figsize=(12, 4 * num_features), sharex=True)

    # 如果只有一个特征，axs 不是列表，需要转换为列表
    if num_features == 1:
        axs = [axs]

    # 定义颜色和标记列表
    colors = plt.cm.get_cmap('tab10').colors  # 使用 Tab10 颜色映射
    markers = ['o', 'x', '^', 's', 'D', 'v', '*', 'P', 'h', '+']  # 定义标记样式

    # 计算 NSE 并存储
    nse_values = {}

    # 计算所有序列的 NSE
    for name, data in sequences_np.items():
        nse_per_feature = []
        for f in range(num_features):
            nse = calculate_nse(y_obs_np[f], data[f])
            nse_per_feature.append(nse)
        # 取平均 NSE，忽略 NaN 值
        average_nse = np.nanmean(nse_per_feature)
        nse_values[name] = average_nse

    # 绘制 y_obs
    for f in range(num_features):
        axs[f].plot(time_steps, y_obs_np[f], label='y_obs', marker='o', linestyle='-', color='black')

    # 绘制所有其他序列，并在标签中包含 NSE
    for idx, (name, data) in enumerate(sequences_np.items()):
        color = colors[idx % len(colors)]
        marker = markers[idx % len(markers)]
        nse = nse_values[name]
        label_with_nse = f"{name} (NSE: {nse:.3f})"
        for f in range(num_features):
            axs[f].plot(time_steps, data[f], label=label_with_nse, marker=marker, linestyle='--', color=color)
        # To avoid duplicate labels in legend, we break after the first feature
        if num_features > 1:
            axs[0].plot([], [], label=label_with_nse, color=color, linestyle='--', marker=marker)

    # 添加图例、标签和标题
    for f in range(num_features):
        axs[f].set_ylabel(f'Feature {f + 1}')
        axs[f].legend(loc='upper right')
        axs[f].set_title(f'Batch {batch_i}, Feature {f + 1} Comparison')

    axs[-1].set_xlabel('Time Step')
    plt.tight_layout()
    plt.show()

    # 打印 NSE 值
    print(f"NSE Values for Batch {batch_i}:")
    for name, nse in nse_values.items():
        print(f" - {name}: NSE = {nse:.3f}")

def calculate_nse(observed, predicted):
    """
    计算 Nash-Sutcliffe Efficiency (NSE)。

    参数:
    - observed (np.ndarray): 观测值数组。
    - predicted (np.ndarray): 预测值数组。

    返回:
    - float: 计算得到的 NSE 值。
    """
    observed = np.array(observed)
    predicted = np.array(predicted)

    numerator = np.sum((observed - predicted) ** 2)
    denominator = np.sum((observed - np.mean(observed)) ** 2)

    nse = 1 - (numerator / denominator)
    return nse


def prepare_batch_data(batch, device):
    p = batch['p'].to(device)
    ep = batch['etpot'].to(device)
    y_obs = batch['qobs'].to(device)
    state0 = batch['state0'].to(device)
    tm_hours = batch['tm_hours'].to(device)
    return p, ep, y_obs, state0, tm_hours

def get_randomized_initial_state(self, sys_model, batch_size):
        # 返回随机的初始状态
        lower_bounds = torch.tensor([5.0, 5.0, 0.0, 5.0, 0.0])
        upper_bounds = torch.tensor([500.0, 2450.0, 20.0, 5000.0, 5.0])
        state0_tmp = sys_model.m1x_0.reshape(1, sys_model.m, 1).repeat(batch_size, 1, 1)
        return latin_hypercube_sampling(batch_size, sys_model.m1x_0.size(0), lower_bounds, upper_bounds).to(state0_tmp.dtype).squeeze(-1)

def get_fixed_initial_state(self, sys_model, batch_size):
    """
    使用 sys_model.m1x_0 初始化状态，对所有样本都是相同的初始值。
    假设 sys_model.m1x_0 的形状是 [m, 1]。
    通过 repeat 扩展到 [batch_size, m, 1]，然后再 squeeze 得到 [batch_size, m]。
    """
    state0_tmp = sys_model.m1x_0.reshape(1, sys_model.m, 1).repeat(batch_size, 1, 1)
    state0_batch = state0_tmp.squeeze(-1)  # 得到 [batch_size, m]
    return state0_batch

def latin_hypercube_sampling(num_samples, num_dimensions, lower_bounds, upper_bounds, seed: int | None = None, criterion: str | None = None):
    """生成 Latin Hypercube 样本 (带多后端与可复现实验支持)。

    参数
    -----
    num_samples : 样本数
    num_dimensions : 维度数 (需与 bounds 长度一致)
    lower_bounds / upper_bounds : torch.Tensor or array-like, shape [num_dimensions]
    seed : 可选随机种子; 便于复现实验
    criterion : (可选) pyDOE2/pyDOE 支持的优化策略, 如 'maximin'; 纯 numpy 回退时忽略

    返回
    -----
    torch.Tensor, shape [num_samples, num_dimensions]
    """
    assert num_dimensions == len(lower_bounds) == len(upper_bounds), "维度与边界长度不一致"
    lhs_unit = _generate_lhs(num_dimensions, num_samples, seed=seed, criterion=criterion)
    # 映射到实际范围
    lower = torch.as_tensor(lower_bounds, dtype=torch.float32)
    upper = torch.as_tensor(upper_bounds, dtype=torch.float32)
    range_tensor = upper - lower
    scaled = torch.from_numpy(lhs_unit).float() * range_tensor + lower
    return scaled

# 便于外部调试查看使用哪种后端
LHS_BACKEND = _lhs_backend