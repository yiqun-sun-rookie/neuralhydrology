import os.path
import time, torch
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm
from collections import defaultdict
from filters.modules.pipeline.utils import prepare_batch_data
from filters.modules.pipeline.core_fun import forward_sequence, system_model_forecast, rearrange_data_unfold
# from filters.modules.utils.metrics import compute_train_loss, compute_display_metrics, composite_loss
from filters.modules.utils.metrics import compute_train_loss, composite_loss
from filters.modules.utils.metricsV2 import compute_display_metrics  # NEW
def train_nn(pipeline, train_loader, val_loader, resume_checkpoint=None):
    # 1) 生成训练用文件夹
    train_path, checkpoints_path, logs_path = create_training_directory(
        base_results_path=os.path.join(pipeline.base_path, 'results'))

    # 2) 保存到 pipeline 属性，方便其他函数使用
    pipeline.train_path = train_path
    pipeline.checkpoints_path = checkpoints_path
    pipeline.logs_path = logs_path

    # 3) 初始化训练参数
    initialize_training(pipeline, train_loader, val_loader)

    # 4) 如果用户指定了 checkpoint, 则加载恢复
    if resume_checkpoint:
        checkpoint = torch.load(resume_checkpoint, weights_only=False)
        pipeline.knet_model.load_state_dict(checkpoint['model_state_dict'])
        pipeline.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        pipeline.scheduler.load_state_dict(checkpoint['scheduler'])
        pipeline.best_val_bp_loss = checkpoint['best_val_bp_loss']
        pipeline.current_phase_idx = checkpoint['current_phase_idx']
        pipeline.no_improve_epochs = checkpoint['no_improve_epochs']
        start_epoch = checkpoint['epoch'] + 1
        print(f"[INFO] Resume from checkpoint: {resume_checkpoint}")
    else:
        start_epoch = 0

    # 5) 创建 TensorBoard 日志记录器
    pipeline.writer = SummaryWriter(pipeline.logs_path)

    # 6) 主训练循环
    for epoch in range(start_epoch, pipeline.n_epochs_train):
        # ---------- Training ----------
        train_avg_bp_loss, train_avg_display_loss = run_one_epoch(pipeline, train_loader, epoch, is_training=True)
        # ---------- Validation ----------
        val_avg_bp_loss, val_avg_display_loss = run_one_epoch(pipeline, val_loader, epoch, is_training=False)
        # 7) 每个 epoch 结束后的一些操作 (保存模型、调度器、打印日志、早停等)
        post_epoch_operations(pipeline, epoch, train_avg_bp_loss, val_avg_bp_loss, train_avg_display_loss, val_avg_display_loss) ######
        # 8) 早停检查
        if pipeline.no_improve_epochs >= pipeline.early_stopping_patience:
            print(f"[INFO] Early stopping triggered at epoch {epoch}.")
            break
        pipeline.loss_train[epoch], pipeline.loss_cv[epoch] = train_avg_bp_loss, val_avg_bp_loss
        torch.cuda.empty_cache()

    # 9) 训练结束，关闭 Writer
    pipeline.writer.close()

    return train_avg_bp_loss, train_avg_display_loss, val_avg_bp_loss, val_avg_display_loss

def run_one_epoch(pipeline, data_loader, epoch, is_training=True):
    if is_training:
        pipeline.knet_model.train()
        desc = f"[Train] Epoch {epoch + 1}/{pipeline.n_epochs_train}"
    else:
        pipeline.knet_model.eval()
        desc = f"[Validate] Epoch {epoch + 1}/{pipeline.n_epochs_train}"

    total_bp_loss, total_display_loss, total_samples, main_display_metric_avg = 0.0, defaultdict(float), 0, None
    if len(pipeline.display_metrics_list) > 0:
        main_display_metric = pipeline.display_metrics_list[0]  # 'mse' or 'nse'

    # ===== [新增] 如果是验证/测试阶段、且打算保存预测，则清空 pipeline.predictions =====
    if (not is_training) and getattr(pipeline, 'save_predictions', False):
        pipeline.predictions = []  # 准备存放所有batch的预测结果

    with torch.set_grad_enabled(is_training):
        with tqdm(data_loader, desc=desc, unit='batch') as bar:
            for i, batch in enumerate(bar):
                bp_loss, display_loss, batch_size = run_one_batch(pipeline, batch, is_training, epoch)

                total_bp_loss += bp_loss
                total_samples += batch_size
                # 累加各指标
                for key, value in display_loss.items():
                    total_display_loss[key] += value
                # 计算当前的 epoch平均 loss
                avg_bp_loss = total_bp_loss / total_samples

                # 如果只想在进度条显示 main_display_metric
                if main_display_metric in display_loss and total_samples > 0:
                    main_display_metric_avg = total_display_loss[main_display_metric] / total_samples

                # 每隔一定 batch 显示一次信息
                if (i + 1) % pipeline.batch_display_interval == 0 or i == len(bar) - 1:
                    # 构造日志信息字符串
                    msg = f"Batch {i + 1}: mse: {avg_bp_loss:.5f}"
                    if main_display_metric_avg is not None:
                        msg += f", {main_display_metric}: {main_display_metric_avg:.5f}"
                    msg += f", LR: {pipeline.optimizer.param_groups[0]['lr']}"
                    msg += f", Lead Time: {pipeline.forecast_lead_time}"
                    # 使用 tqdm.write 输出信息，不会被进度条覆盖
                    bar.write(msg)

                # # 提前结束测试保存是否可用
                # if i == 0:
                #     break

    # epoch结束，计算最终平均
    final_avg_bp_loss = total_bp_loss / total_samples
    final_avg_display_loss = {
        metric_name: (val_sum / total_samples)
        for metric_name, val_sum in total_display_loss.items()
    }
    return final_avg_bp_loss, final_avg_display_loss
def run_one_batch(pipeline, batch, is_training, epoch):
    p, ep, y_obs, state0, tm_hours = prepare_batch_data(batch, pipeline.DEVICE)
    control = torch.cat((p, ep), dim=1)
    current_batch_size = p.size(0)
    # 初始化knet_model
    pipeline.knet_model.batch_size = current_batch_size
    pipeline.knet_model.init_hidden_KNet()
    pipeline.knet_model.update_mode = True
    pipeline.knet_model.init_sequence(state0[:, :, 0], pipeline.sys_model.train_seq_len)

    # 前向update计算
    states_upd, outputs_upd = forward_sequence(pipeline, y_obs, control)

    # 预报计算
    states_forecast_flat, outputs_forecast_flat = system_model_forecast(sys_model=pipeline.sys_model,
                                                                        p=p, etpot=ep, states_updated=states_upd,
                                                                        lead_time=pipeline.forecast_lead_time)
    # 计算损失
    if pipeline.sys_model.n == 1:
        outputs_forecast_flat = outputs_forecast_flat.squeeze(1)
    y_future = rearrange_data_unfold(y_obs, pipeline.forecast_lead_time).reshape(-1, pipeline.forecast_lead_time)

    # 用来反向传播的损失
    # bp_loss = compute_train_loss(outputs_forecast_flat, y_future, lead_times=None, reduction='mean')
    # B) 计算 feasible_timesteps 与 total_samples —— 与 system_model_forecast 中一致
    num_timesteps = y_obs.size(-1)
    feas_T = num_timesteps - pipeline.forecast_lead_time + 1
    total_samples = current_batch_size * feas_T  # N

    # C) t = 0 的预测 / 观测
    #    outputs_upd: [B, n, T]  →  取观测窗口起点  →  flatten
    upd_now = outputs_upd[:, 0, :feas_T].reshape(-1)  # [N]
    y_now = y_obs[:, 0, :feas_T].reshape(-1)  # [N]

    # ---------- 3. 组合损失 ----------
    bp_loss, loss_dict = composite_loss(
        outputs_fc=outputs_forecast_flat,  # [N, L]
        y_future=y_future,  # [N, L]
        outputs_upd=upd_now,  # [N]
        y_now=y_now,  # [N]
        lambda_upd=pipeline.args.lambda_upd,
        high_flow_thr=pipeline.args.high_flow_thr,
        alpha_hf=pipeline.args.alpha_hf,
        delta_thr=pipeline.args.delta_thr,
        beta_rise=pipeline.args.beta_rise,
        use_log=pipeline.args.use_log,
        gamma_slope=pipeline.args.gamma_slope,
    )
    # 计算显示的损失
    # display_loss = compute_display_metrics(outputs_forecast_flat, y_future, metrics=pipeline.display_metrics_list, lead_times=None)


    # … 省略前面部分 …

    # ---------- 4. display metrics ----------
    display_loss = compute_display_metrics(
        outputs_forecast_flat,  # pred  [N, L]
        y_future,  # obs   [N, L]
        metrics=pipeline.display_metrics_list + ['nse_high'],
        lead_times=None,
        high_flow_thr=pipeline.args.high_flow_thr
    )

    # 如果是训练模式，则反向传播、优化
    if is_training:
        pipeline.optimizer.zero_grad()
        bp_loss.backward()
        pipeline.optimizer.step()
        # 梯度裁剪
        grad_norm = torch.nn.utils.clip_grad_norm_(pipeline.knet_model.parameters(), max_norm=1.0)
        if grad_norm > 1:
            print(f"Warning: high gradient norm {grad_norm} detected at epoch {epoch}")

    # ========== [新增] 如果是测试/验证模式且需要保存结果，追加到 pipeline.predictions ==========
    # ========= 仅在验证/测试且要求保存预测时，做额外变换 =========
    if (not is_training) and getattr(pipeline, 'save_predictions', False):
        # ---------- 1. 窗口化驱动/观测 ----------
        p_win = rearrange_data_unfold(p, pipeline.forecast_lead_time).squeeze(2)  # [B,T-L+1,L]
        ep_win = rearrange_data_unfold(ep, pipeline.forecast_lead_time).squeeze(2)
        y_win = rearrange_data_unfold(y_obs, pipeline.forecast_lead_time).squeeze(2)

        # ---------- 2. 窗口化时间戳 ----------
        tm_raw = tm_hours.squeeze(1) if tm_hours.dim() == 3 else tm_hours  # [B,T]
        tm_win = tm_raw.unfold(1, pipeline.forecast_lead_time, 1)  # [B,T-L+1,L]

        # ---------- 3. 预测结果 reshape 成窗口格式 ----------
        states_fc_win = states_forecast_flat.view(
            current_batch_size, -1, pipeline.sys_model.m, pipeline.forecast_lead_time
        )  # [B,T-L+1,m,L]
        outputs_fc_win = outputs_forecast_flat.view(
            current_batch_size, -1, pipeline.forecast_lead_time
        )  # [B,T-L+1,L]

        # ---------- 4. 追加到 predictions ----------
        pipeline.predictions.append({
            # === 原始序列（可选保留） ===
            "p_raw": p.detach().cpu(),
            "ep_raw": ep.detach().cpu(),
            "y_obs_raw": y_obs.detach().cpu(),
            "tm_hours_raw": tm_raw.detach().cpu(),

            # === 窗口化张量（与预测严格对齐） ===
            "p_win": p_win.detach().cpu(),
            "ep_win": ep_win.detach().cpu(),
            "y_obs_win": y_win.detach().cpu(),
            "tm_hours_win": tm_win.detach().cpu(),

            "outputs_upd": outputs_upd.detach().cpu(),
            "states_upd": states_upd.detach().cpu(),
            "states_fc_win": states_fc_win.detach().cpu(),
            "outputs_fc_win": outputs_fc_win.detach().cpu(),
        })

     # 统一返回“批次总和”
    # bp_loss_batch_sum = bp_loss.item() * current_batch_size
    # 结尾 batch_sum 同理改用 loss_dict['loss_total']
    bp_loss_batch_sum = loss_dict['loss_total'] * current_batch_size
    # 对显示指标(此处只有 'nse')也做 batch_size 加权
    display_metrics_batch_sum = {}
    for k, v in display_loss.items():
        display_metrics_batch_sum[k] = v * current_batch_size  # => “该batch总和”

    return bp_loss_batch_sum, display_metrics_batch_sum, current_batch_size

def initialize_training(pipeline, train_loader, val_loader):
    pipeline.n_train = len(train_loader.dataset)  # 训练数据集的样本总数
    pipeline.n_val = len(val_loader.dataset)  # 验证数据集的样本总数
    pipeline.loss_cv = torch.zeros([pipeline.n_epochs_train])  # 循环n_epochs次
    pipeline.loss_train = torch.zeros([pipeline.n_epochs_train])
    pipeline.best_val_bp_loss_idx = 0

    pipeline.sys_model.train_seq_len = train_loader.dataset[0]['p'].shape[-1]  # train_seq_len is the maximum length of the pipeline sequences
    pipeline.sys_model.val_seq_len = val_loader.dataset[0]['p'].shape[-1]  # val_seq_len is the maximum length of the CV sequences

###########################
# post_epoch_operations
###########################
def post_epoch_operations(
    pipeline,
    epoch,
    train_avg_bp_loss,
    val_avg_bp_loss,
    train_avg_display_loss,
    val_avg_display_loss
):
    # ========== 1. 记录最优模型 ==========
    min_delta = 1e-6

    if pipeline.best_val_bp_loss - val_avg_bp_loss > min_delta:
        pipeline.best_val_bp_loss = val_avg_bp_loss
        pipeline.no_improve_epochs = 0
        pipeline.best_val_bp_loss_idx = epoch

        # 保存最佳模型
        best_model_path = os.path.join(pipeline.train_path, 'best_model.pt')
        torch.save({
            'epoch': epoch,
            'model_state_dict': pipeline.knet_model.state_dict(),
            'optimizer_state_dict': pipeline.optimizer.state_dict(),
            'scheduler': pipeline.scheduler.state_dict(),
            'best_val_bp_loss': pipeline.best_val_bp_loss,
            'current_phase_idx': pipeline.current_phase_idx,
            'no_improve_epochs': pipeline.no_improve_epochs,
        }, best_model_path)

        print(f"[INFO] Best model updated. Train loss = {train_avg_display_loss['nse']:.5f}. Val loss = {val_avg_display_loss['nse']:.5f}")
    else:
        pipeline.no_improve_epochs += 1

    # ========== 2. 定期保存 checkpoint ==========
    if epoch % 1 == 0 or epoch == pipeline.n_epochs_train - 1:
        checkpoint_path = os.path.join(pipeline.checkpoints_path, f'checkpoint_epoch_{epoch}.pt')
        torch.save({
            'epoch': epoch,
            'model_state_dict': pipeline.knet_model.state_dict(),
            'optimizer_state_dict': pipeline.optimizer.state_dict(),
            'scheduler': pipeline.scheduler.state_dict(),
            'best_val_bp_loss': pipeline.best_val_bp_loss,
            'current_phase_idx': pipeline.current_phase_idx,
            'no_improve_epochs': pipeline.no_improve_epochs,
            'loss_train': pipeline.loss_train,
            'loss_cv': pipeline.loss_cv,
        }, checkpoint_path)
        print(f"[INFO] Checkpoint saved => {checkpoint_path}")

    # ========== 3. 更新预报阶段 (lead_time) ==========
    maybe_update_lead_time_phase(pipeline, epoch, val_avg_display_loss)

    # ========== 4. TensorBoard 日志写入 ==========
    writer = pipeline.writer  # 直接从 pipeline 里取

    writer.add_scalar('Loss/Train', train_avg_bp_loss, epoch)
    writer.add_scalar('Loss/Validation', val_avg_bp_loss, epoch)

    # 确保 nse_high / mse_high 被写入
    base_metrics = pipeline.display_metrics_list + ["nse_high", "mse_high"]
    for m in base_metrics:
        writer.add_scalar(f"Metrics/Train_{m}", train_avg_display_loss.get(m, 0), epoch)
        writer.add_scalar(f"Metrics/Val_{m}",   val_avg_display_loss.get(m, 0),   epoch)

    writer.add_scalar("HP/LR",         pipeline.optimizer.param_groups[0]["lr"], epoch)
    writer.add_scalar("HP/LeadTime",   pipeline.forecast_lead_time, epoch)
    writer.add_scalar("Stage/Phase",   pipeline.current_phase_idx,  epoch)

def maybe_update_lead_time_phase(pipeline, epoch, val_loss):
    # 边界检查：已经是最后阶段则不处理
    if pipeline.current_phase_idx >= len(pipeline.lead_time_phases) - 1:
        return

    phase_info = pipeline.lead_time_phases[pipeline.current_phase_idx]

    # 条件1：必须满足最小epoch要求
    if epoch < phase_info["min_epoch"]:
        return

    # 条件2：性能达到阈值
    val_threshold = phase_info["val_improve_threshold"]
    nse = val_loss.get("nse")

    if nse >= val_threshold:  # ✅ 修正判断方向
        # 切换阶段
        pipeline.current_phase_idx += 1
        new_idx = pipeline.current_phase_idx
        new_phase = pipeline.lead_time_phases[new_idx]

        # 更新预报提前期
        pipeline.forecast_lead_time = new_phase["lead_time"]
        # ✅ 重置早停计数器
        pipeline.no_improve_epochs = 0

        print(f"[Phase Update] Epoch {epoch}: NSE {nse:.4f} ≥ {val_threshold}, "
              f"new lead_time: {pipeline.forecast_lead_time}")

def create_training_directory(base_results_path):
    # 直接使用base_results_path，不创建时间戳子目录
    train_path = base_results_path
    checkpoints_path = os.path.join(train_path, "checkpoints")
    logs_path = os.path.join(train_path, "logs", "train")

    os.makedirs(checkpoints_path, exist_ok=True)
    os.makedirs(logs_path, exist_ok=True)

    return train_path, checkpoints_path, logs_path

