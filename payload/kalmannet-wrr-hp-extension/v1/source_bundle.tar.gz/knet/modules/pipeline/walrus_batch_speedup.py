import numpy as np
import torch
import torch.nn as nn
# from hydrologic.utils import check_nan
class WalrusBatch(nn.Module):
    def __init__(self, *, cw, cv, cg, cq, cd, cs, as_=0.01, m=5, n=1, initial_state, device=None):
        """
        初始化水文模型参数和初始状态。
        Parameters:
        cw, cv, cg, cq, cd, cs : float
        as_ : float, optional 表面区域比例，默认为0.01。
        ag_ : float, optional 地下区域比例，如果未提供，则自动计算为1-as_。
        initial_state : numpy array初始状态向量。
        m : int, optional 状态向量的行维度，如果未提供，则自动从 initial_state 计算。
        n : int, optional 观测向量维度，如果未提供，默认为1。
        device : str or torch.device, optional 设备类型，如果未提供，则自动检测
        """
        super(WalrusBatch, self).__init__()

        # 智能设备选择：优先使用传入的设备，否则自动检测
        if device is None:
            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            device = torch.device(device)
        
        self.device = device
        print(f"Walrus Using device: {self.device}")

        # 状态和观测维度
        self.m, self.n = m, n

        # 模型参数、默认值和约束
        self.set_paramters_defaults_bounds_state_names(cw=cw, cv=cv, cg=cg, cq=cq, cd=cd, cs=cs, as_=as_)

        # 初始状态
        self.register_buffer('init_state',
                             initial_state.to(self.device) if not initial_state.is_cuda else initial_state)


    def set_paramters_defaults_bounds_state_names(self, *, cw, cv, cg, cq, cd, cs, as_):
        # 模型参数
        self.register_buffer("cw", torch.tensor(cw, dtype=torch.float32, device=self.device))
        self.register_buffer("cv", torch.tensor(cv, dtype=torch.float32, device=self.device))
        self.register_buffer("cg", torch.tensor(cg, dtype=torch.float32, device=self.device))
        self.register_buffer("cq", torch.tensor(cq, dtype=torch.float32, device=self.device))
        self.register_buffer("cd", torch.tensor(cd, dtype=torch.float32, device=self.device))
        self.register_buffer("cs", torch.tensor(cs, dtype=torch.float32, device=self.device))
        self.register_buffer("as_", torch.tensor(as_, dtype=torch.float32, device=self.device))
        self.register_buffer("ag_", torch.tensor(1 - as_, dtype=torch.float32, device=self.device))
        self.register_buffer("b", torch.tensor(4.38, dtype=torch.float32, device=self.device))
        self.register_buffer("psi_ae", torch.tensor(90.0, dtype=torch.float32, device=self.device))
        self.register_buffer("theta_s", torch.tensor(0.41, dtype=torch.float32, device=self.device))
        self.register_buffer("zeta1", torch.tensor(0.02, dtype=torch.float32, device=self.device))
        self.register_buffer("zeta2", torch.tensor(400.0, dtype=torch.float32, device=self.device))
        self.register_buffer("min_h", torch.tensor(0.001, dtype=torch.float32, device=self.device))
        self.register_buffer("hs_min", torch.tensor(0.0, dtype=torch.float32, device=self.device))
        self.register_buffer("exps", torch.tensor(1.5, dtype=torch.float32, device=self.device))
        # 默认值
        self.register_buffer("default_fxg_t", torch.tensor(0, dtype=torch.float32, device=self.device))
        self.register_buffer("default_fxs_t", torch.tensor(0, dtype=torch.float32, device=self.device))
        self.register_buffer("default_hs_min_t", torch.tensor(0, dtype=torch.float32, device=self.device))
        # 状态约束
        self.register_buffer("dv_lb", torch.tensor(5.0, dtype=torch.float32, device=self.device))
        self.register_buffer("dv_ub", torch.tensor(500.0, dtype=torch.float32, device=self.device))
        self.register_buffer("dg_lb", torch.tensor(5.0, dtype=torch.float32, device=self.device))
        self.register_buffer("dg_ub", self.cd.clone().detach())
        self.register_buffer("hq_lb", torch.tensor(0.0, dtype=torch.float32, device=self.device))
        self.register_buffer("hq_ub", torch.tensor(20.0, dtype=torch.float32, device=self.device))
        self.register_buffer("hs_lb", torch.tensor(5.0, dtype=torch.float32, device=self.device))
        self.register_buffer("hs_ub", torch.tensor(5000.0, dtype=torch.float32, device=self.device))
        self.register_buffer("q_lb", torch.tensor(0.0, dtype=torch.float32, device=self.device))
        self.register_buffer("q_ub", torch.tensor(5.0, dtype=torch.float32, device=self.device))

        # 状态名称
        self.state_names = ['dv', 'dg', 'hq', 'hs', 'q']
        self.observed_state_names = ['q']

    @torch.jit.export
    def f(self, x, controls):
        # 处理、检查输入
        assert controls.ndim == 2 and controls.shape[1] == 2, f"Expected controls to have shape [batch_size, 2], got {controls.shape}"
        p_t, etpot_t = controls[:, 0], controls[:, 1]
        assert p_t.ndim == 1, f"Expected p_t to have 1 dimension, got {p_t.ndim}"
        assert etpot_t.ndim == 1, f"Expected etpot_t to have 1 dimension, got {etpot_t.ndim}"

        # 处理、检查状态
        # check_nan(x, "Input x to f")
        assert x.ndim == 2 and x.shape[1] == self.m, f"Expected x to have shape [batch_size, state_dim], got {x.shape}"

        # 2) 先对输入 x 做约束
        x_constrained = self.apply_state_constraints_pure(x)

        # 前向传播更新状态
        # 3) 做 forward 计算, 返回新的状态 next_state
        next_state = self.forward_pure(x_constrained, p_t, etpot_t)
        # check_nan(next_state, "Output next_state from f")
        assert next_state.ndim == 2 and next_state.shape[1] == self.m, f"Expected state to have shape [batch_size, state_dim], got {next_state.shape}"

        return next_state

    @torch.jit.export
    def h(self, x):
        # check_nan(x, "Input x to h")
        # 检查x是否为三维并且最后一个维度为1
        if x.ndim == 3 and x.shape[2] == 1:
            # 正确的维度，直接返回
            result = x[:, -1, :].unsqueeze(-1)
        elif x.ndim == 2:
            # 如果x是二维的，假定它的形状为[batch_size, state_dim]，我们添加一个新维度
            result = x[:, -1].unsqueeze(-1)
        else:
            raise ValueError(
                f"Invalid input shape {x.shape} for h(). "
                f"Expected (batch,5) or (batch,5,1), got {x.shape}")
        return result

    # 导出状态维度 m
    def forward_pure(
            self, x: torch.Tensor, p_t: torch.Tensor, etpot_t: torch.Tensor
    ) -> torch.Tensor:
        """
        不使用 self.state, 而是接收当前状态 x 和输入 (p_t, etpot_t, noise)，
        返回下一步状态。
        """
        # check_nan(p_t, "Input p_t to forward_pure")
        # check_nan(etpot_t, "Input etpot_t to forward_pure")

        # 1) 调用 walrus_st_sp_pure (下文重写) 做核心水文更新
        next_x = self.walrus_st_sp_pure(x, p_t, etpot_t)

        # 3) 做一些小范围裁剪
        #    next_x[:, 3], next_x[:, 2] 分别对应 hs 和 hq? (需根据你原先的状态顺序确认)
        hs_val = torch.where(next_x[:, 3] < -0.001, 0.1, next_x[:, 3])
        hq_val = torch.where(next_x[:, 2] < -0.001, 0.001, next_x[:, 2])

        # 用 torch.cat 或 stack 重组成新的 state
        # 先拆开 next_x
        dv, dg, hq, hs, q = next_x.split(1, dim=1)
        # 覆盖 hq, hs
        hq = hq_val.unsqueeze(1)
        hs = hs_val.unsqueeze(1)
        # 拼回 (batch_size,5)
        new_x = torch.cat([dv, dg, hq, hs, q], dim=1)

        # check_nan(new_x, "Output new_x from forward_pure")
        return new_x

    def apply_state_constraints_pure(self, x: torch.Tensor) -> torch.Tensor:
        """
        纯函数版本: 对 x 的各维度进行 clamp 后返回, 不改 self.state。
        """
        dv = torch.clamp(x[:, 0], self.dv_lb, self.dv_ub)
        dg = torch.clamp(x[:, 1], self.dg_lb, self.dg_ub)
        hq = torch.clamp(x[:, 2], self.hq_lb, self.hq_ub)
        hs = torch.clamp(x[:, 3], self.hs_lb, self.hs_ub)
        q = torch.clamp(x[:, 4], self.q_lb, self.q_ub)

        x_constrained = torch.stack([dv, dg, hq, hs, q], dim=1)
        # check_nan(x_constrained, "Output x_constrained from apply_state_constraints_pure")
        return x_constrained


    def walrus_st_sp_pure(
            self,
            x: torch.Tensor,
            p_t: torch.Tensor,
            etpot_t: torch.Tensor
    ) -> torch.Tensor:
        """
        纯函数水文更新: 输入 (x, p_t, etpot_t, optional fxg_t/fxs_t/hs_min_t),
        返回更新后的状态 next_x。不会修改 self.state。
        """
        # check_nan(p_t, "Input p_t to walrus_st_sp_pure")
        # check_nan(etpot_t, "Input etpot_t to walrus_st_sp_pure")

        # 如果 None，就用默认 buffer
        fxg_t = self.default_fxg_t
        fxs_t = self.default_fxs_t

        # 分解 x
        dv0 = torch.clamp(x[:, 0], min=0.0)
        dg0 = torch.clamp(x[:, 1], min=0.0)
        hq0 = torch.clamp(x[:, 2], min=0.0)
        hs0 = x[:, 3]
        q0 = torch.clamp(x[:, 4], min=0.0)

        w0 = self.func_w_dv_def(dv0, self.cw)
        dveq0 = self.func_dveq_dg_def(dg0)

        pq, pv, ps = self.func_walrus_get_pq_pv_ps(p_t, w0)
        etv, ets, _ = self.func_walrus_get_etv_ets_etact(etpot_t, dv0, hs0)
        fqs = hq0 / self.cq

        if self.cg == 0:
            raise ValueError("self.cg must not be zero to avoid division by zero.")

        fgs = (self.cd - dg0 - hs0) * torch.max((self.cd - dg0), hs0) / self.cg
        dv = dv0 - (fxg_t + pv - etv - fgs) / self.ag_
        dg = dg0 + (dv0 - dveq0) / self.cv
        hq = hq0 + (pq - fqs) / self.ag_
        hs = hs0 + (fxs_t + ps - ets + fgs + fqs - q0) / self.as_
        q = self.func_q_hs_def(hs)

        dv, hs, dg = self.func_walrus_pond_flood(dv, hs, dg)

        hs = torch.clamp(hs, min=0.001)
        hq = torch.clamp(hq, min=0.001)
        q = torch.clamp(q, min=0.0)

        next_x = torch.stack([dv, dg, hq, hs, q], dim=1)
        # print(self.cw)
        # check_nan(next_x, "Output next_x from walrus_st_sp_pure")
        return next_x

    # 内部辅助函数
    # @torch.jit.script
    def func_w_dv_def(self, dv, cw):
        # check_nan(dv, "Input dv to func_w_dv_def")
        # check_nan(cw, "Input cw to func_w_dv_def")

        result = 0.5 * torch.cos(torch.clamp(dv, min=0, max=cw) * torch.pi / cw) + 0.5

        # check_nan(result, "Output result from func_w_dv_def")
        return result

    # @torch.jit.script
    def func_dveq_dg_def(self, dg):
        # check_nan(dg, "Input dg to func_dveq_dg_def")
        dg = torch.clamp(dg, self.dg_lb, self.dg_ub)  # dv
        psi_ae, b, theta_s = self.psi_ae, self.b, self.theta_s
        dveq = torch.where(dg > psi_ae,
                           (dg - (psi_ae / (1 - b)) - (dg ** (1 - 1 / b)) * (psi_ae ** (1 / b)) / (1 - 1 / b)) * theta_s,
                           torch.where(dg < 0.0, dg, torch.zeros_like(dg)))

        # check_nan(dveq, "Output dveq from func_dveq_dg_def")
        return dveq

    # @torch.jit.script
    def func_walrus_get_pq_pv_ps(self, p_t, w):
        """
        根据降水量 p_t，权重 w 以及地下和表面的区域系数 ag_ 和 as，计算 pq, pv, ps。
        """
        # check_nan(p_t, "Input p_t to func_walrus_get_pq_pv_ps")
        # check_nan(w, "Input w to func_walrus_get_pq_pv_ps")
        ag_, as_ = self.ag_, self.as_
        pq = p_t * w * ag_
        pv = p_t * (1 - w) * ag_
        ps = p_t * as_

        # check_nan(pq, "Output pq from func_walrus_get_pq_pv_ps")
        # check_nan(pv, "Output pv from func_walrus_get_pq_pv_ps")
        # check_nan(ps, "Output ps from func_walrus_get_pq_pv_ps")
        return pq, pv, ps

    # @torch.jit.script
    def func_walrus_get_etv_ets_etact(self, etpot_t, dv, hs):

        # 检查输入是否为空
        # check_nan(etpot_t, "Input etpot_t to func_walrus_get_etv_ets_etact")
        # check_nan(dv, "Input dv to func_walrus_get_etv_ets_etact")
        # check_nan(hs, "Input hs to func_walrus_get_etv_ets_etact")

        zeta1, zeta2, min_h = self.zeta1, self.zeta2, self.min_h
        as_ = self.as_
        ag_ = self.ag_
        etv = etpot_t * self.func_beta_dv_def(dv) * ag_
        ets = etpot_t * as_
        ets = torch.where(hs < min_h, 0.0, ets)
        etact = etv + ets

        # check_nan(etv, "Output etv from func_walrus_get_etv_ets_etact")
        # check_nan(ets, "Output ets from func_walrus_get_etv_ets_etact")
        # check_nan(etact, "Output etact from func_walrus_get_etv_ets_etact")

        return etv, ets, etact

    # @torch.jit.script
    def func_q_hs_def(self, hs):
        # check_nan(hs, "Input hs to func_q_hs_def")
        hs = torch.clamp(hs, self.hs_lb, self.hs_ub)
        hs_min, exps, cd, cs = self.hs_min, self.exps, self.cd, self.cs

        # 使用 torch.where 替代 if-else 来保持可微分性
        normal_flow = (hs > hs_min) & (hs <= cd)
        overflow = hs > cd + 1.0

        # 使用张量操作计算流量 q
        q = torch.zeros_like(hs)
        q = torch.where(normal_flow, cs * ((hs - hs_min) / (cd - hs_min)) ** exps, q)
        # q = torch.where(overflow, cs + cs * ((hs - cd) / (cd - hs_min)) ** exps, q)

        # 添加打印语句以监控变量
        denom = torch.clamp(cd - hs_min, min=0.01)
        base = torch.clamp(hs - cd, min=0.01)

        q = torch.where(overflow, cs + cs * (base / denom) ** exps, q)

        # check_nan(q, "Output q from func_q_hs_def")
        return q
    # @torch.jit.script
    def func_walrus_pond_flood(self, dv, hs, dg):
        """
        调整水面高于设计容量或储水深度为负的情况。
        """
        # check_nan(dv, "Input dv to func_walrus_pond_flood")
        # check_nan(hs, "Input hs to func_walrus_pond_flood")
        # check_nan(dg, "Input dg to func_walrus_pond_flood")

        as_, ag_, cd = self.as_, self.ag_, self.cd

        # Check conditions and adjust using torch.where
        condition1 = (dv < 0.0) & (hs <= cd)
        condition2 = (dv >= 0.0) & (hs > cd)
        condition3 = (dv <= 0.0) & (hs >= cd)
        condition4 = dv < 0.0

        # Apply adjustments based on conditions
        hs = torch.where(condition1, hs - (dv * ag_ / as_), hs)
        dv = torch.where(condition1, torch.zeros_like(dv), dv)

        dv = torch.where(condition2, dv - (hs - cd) * as_ / ag_, dv)
        hs = torch.where(condition2, cd * torch.ones_like(hs), hs)

        adjustment = dv * ag_ - (hs - cd) * as_
        hs = torch.where(condition3, cd - adjustment, hs)
        dv = torch.where(condition3, adjustment, dv)
        dg = torch.where(condition4, dv, dg)

        # check_nan(dv, "Output dv from func_walrus_pond_flood")
        # check_nan(hs, "Output hs from func_walrus_pond_flood")
        # check_nan(dg, "Output dg from func_walrus_pond_flood")
        return dv, hs, dg

    # @torch.jit.script
    def func_beta_dv_def(self, dv):
        """
        计算根据土壤水分深度 dv 调整的系数 beta。

        Parameters:
        dv : float 土壤水分深度。
        zeta1 : float, optional 调整因子1。
        zeta2 : float, optional 调整因子2。

        Returns:
            计算后的 beta 值。
        """
        # check_nan(dv, "Input dv to func_beta_dv_def")

        # 使用 PyTorch 的 exp 函数来计算 e 的指数
        zeta1 = self.zeta1
        zeta2 = self.zeta2
        exp_term = torch.exp(zeta1 * (dv - zeta2))
        beta = (1 - exp_term) / (1 + exp_term) * 0.5 + 0.5
        beta = torch.where(torch.isnan(beta), torch.zeros_like(beta), beta)
        return beta