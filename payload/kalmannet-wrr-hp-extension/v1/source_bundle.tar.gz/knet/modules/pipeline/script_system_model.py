import torch
from torch import Tensor
from torch.jit import ScriptModule, script_method

class ScriptSystemModel(ScriptModule):
    def __init__(
        self,
        walrus_module: torch.jit.ScriptModule,
        q: Tensor,
        r: Tensor,
        seq_len: int,
        seq_len_test: int,
        m: int,
        n: int,
        prior_q: Tensor,
        prior_state_cov: Tensor,
        prior_r: Tensor
    ):
        super(ScriptSystemModel, self).__init__()
        # 保存脚本化的 Walrus 模型（它包含 f 和 h 方法）
        self.walrus_module = walrus_module

        # 保存 SystemModel 所需的其他属性
        self.q = q
        self.r = r
        self.seq_len = seq_len
        self.seq_len_test = seq_len_test
        self.m = m
        self.n = n
        self.prior_q = prior_q
        self.prior_state_cov = prior_state_cov
        self.prior_r = prior_r

        # 如果需要，可以在 __init__ 中同时初始化其它状态属性
        self.m1x_0 = torch.tensor(0.0)  # 或者指定合适的初始值
        self.m2x_0 = torch.tensor(0.0)

    @script_method
    def f(self, x: Tensor, control: Tensor) -> Tensor:
        # 转发调用脚本化的 walrus_module 的 f 方法
        return self.walrus_module.f(x, control)

    @script_method
    def h(self, x: Tensor) -> Tensor:
        # 转发调用脚本化的 walrus_module 的 h 方法
        return self.walrus_module.h(x)

    @script_method
    def InitSequence(self, m1x_0: Tensor, m2x_0: Tensor) -> None:
        # 设置初始状态
        self.m1x_0 = m1x_0
        self.m2x_0 = m2x_0

    @script_method
    def Init_batched_sequence(self, m1x_0_batch: Tensor, m2x_0_batch: Tensor) -> None:
        self.m1x_0_batch = m1x_0_batch
        self.x_prev = m1x_0_batch
        self.m2x_0_batch = m2x_0_batch

    @script_method
    def UpdateCovariance_Matrix(self, Q: Tensor, R: Tensor) -> None:
        self.Q = Q
        self.R = R

    @script_method
    def get_m(self) -> int:
        return self.m
