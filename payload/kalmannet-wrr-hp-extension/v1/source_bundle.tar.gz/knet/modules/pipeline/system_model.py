"""# **Class: System Model for Non-linear Cases**

1 Store system hydro_model parameters:
    state transition function f, 
    observation function h, 
    process noise Q, 
    observation noise R, 
    train&CV dataset sequence length train_seq_len,
    test dataset sequence length seq_len_test,
    state dimension m,
    observation dimension n, etc.

2 Generate datasets for non-linear cases
"""

import torch
class SystemModel:

    def __init__(self, f, q, h, r, seq_len, seq_len_test, m, n, prior_q=None, prior_state_cov=None, prior_r=None):

        # state transition hydro_model
        self.f, self.m, self.q = f, m, q

        # measurement hydro_model
        self.h, self.n, self.r = h, n, r

        # Assign train and test sequence lengths
        self.seq_len, self.seq_len_test = seq_len, seq_len_test

        # prior for Q, R, state covariance, and measurement covariance
        if prior_q is None:
            self.prior_q = torch.eye(self.m)
        else:
            self.prior_q = prior_q

        if prior_state_cov is None:
            self.prior_state_cov = torch.zeros((self.m, self.m))
        else:
            self.prior_state_cov = prior_state_cov

        if prior_r is None:
            self.prior_r = torch.eye(self.n)
        else:
            self.prior_r = prior_r

    #####################
    ### Init Sequence ###
    #####################
    def InitSequence(self, m1x_0, m2x_0):
        self.m1x_0 = m1x_0
        self.m2x_0 = m2x_0

    def Init_batched_sequence(self, m1x_0_batch, m2x_0_batch):

        self.m1x_0_batch = m1x_0_batch
        self.x_prev = m1x_0_batch
        self.m2x_0_batch = m2x_0_batch

    #########################
    ### Update Covariance ###
    #########################
    def UpdateCovariance_Matrix(self, Q, R):

        self.Q = Q
        self.R = R
