import os
import torch
import torch.nn as nn
from torch.optim import AdamW
from torch.optim.lr_scheduler import ReduceLROnPlateau, OneCycleLR
from .train_update_save_8 import train_nn
from .test_update_save_8 import test_nn

class Pipeline:
    def __init__(self, base_path):
        super().__init__()
        self.base_path = base_path
        self.best_nn_model_path = os.path.join(base_path, 'results', 'saved_models', 'best_model.pt')
        self.pipeline_path = os.path.join(base_path, 'results', 'saved_pipelines', 'pipeline.pt')

        # 初始化 metric
        self.train_loss_metric = "mse"
        self.display_metrics_list = ["nse"]

        # 添加状态保存属性
        self.current_phase_idx = 0
        self.no_improve_epochs = 0
        self.best_val_bp_loss = float('inf')
        self.loss_train = None
        self.loss_cv = None

        # 添加结果保存
        self.save_predicitons = True

    def train(self, train_loader, val_loader, resume_checkpoint=None):
        return train_nn(self, train_loader, val_loader, resume_checkpoint)

    def test(self, dataloader, best_model_path, loader_name):
        return test_nn(self, dataloader, best_model_path, loader_name)

    def save(self):
        torch.save(self, self.pipeline_path)

    def set_sys_model(self, sys_model):
        self.sys_model = sys_model
    def set_knet_model(self, knet_model):
        self.knet_model = knet_model
        # self.knet_model = torch.compile(self.knet_model, mode="default")

    def set_train_params(self, args):
        self.batch_display_interval = 50 ########################

        self.args = args
        self.device = torch.device('cuda' if args.use_cuda and torch.cuda.is_available() else 'cpu')
        self.n_epochs_train = args.n_epochs_train  # Number of Training Steps
        # self.N_B = args.n_batch  # Number of Samples in Batch
        self.lr = args.lr  # Learning Rate
        self.wd = args.wd  # L2 Weight Regularization - Weight Decay
        self.alpha = args.alpha  # Composition loss factor
        # 是否使用预报结果作为误差函数
        self.use_forecast_as_loss = True
        self.forecast_lead_time = 12

        # 使用AdamW优化器
        self.optimizer = AdamW(self.knet_model.parameters(), lr=self.lr, weight_decay=self.wd)

        ### 新增 1) 用户配置一个 scheduler 切换 epoch (例如 10)
        # 可以在 args 中加: args.scheduler_switch_epoch = 10
        if not hasattr(self.args, 'scheduler_switch_epoch'):
            self.args.scheduler_switch_epoch = 2  #

        ### 新增 2) 创建两个 scheduler
        #   a) OneCycleLR (建议每个 batch 调用 step)
        # self.scheduler_onecycle = OneCycleLR(
        #     self.optimizer,
        #     max_lr=5e-5,
        #     total_steps=None,
        #     epochs=self.args.scheduler_switch_epoch,
        #     div_factor=20,
        #     steps_per_epoch=args.steps_per_epoch,
        #     # 其他 OneCycleLR 参数可根据需要再加
        # )

        #   b) ReduceLROnPlateau (建议每个 epoch 根据 val_loss 调用 step)
        self.scheduler_plateau = ReduceLROnPlateau(
            self.optimizer,
            mode='min',
            factor=0.5,
            patience=3,
            threshold=1e-4,
            cooldown=0,
            min_lr=1e-8
        )

        # 早停参数
        self.early_stopping_patience = 20
        self.no_improve_epochs = 0
        self.best_val_bp_loss = float('inf')

        self.lead_time_phases = [
            {
                "lead_time": 3,
                "min_epoch": 5,
                "val_improve_threshold": 0.7  # 比如如果验证集NSE > 0.50 就可以准备切下一个
            },
            {
                "lead_time": 6,
                "min_epoch": 10,
                "val_improve_threshold": 0.6
            },
            {
                "lead_time": 12,
                "min_epoch": 99999,  # 最后一个阶段没有上限，或者随便给个大数
                "val_improve_threshold": 1.00  # 理论上不会再变
            }
        ]
        self.current_phase_idx = 0




