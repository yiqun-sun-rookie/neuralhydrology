"""Launcher for ONE cell of the WRR hyperparameter-extension grid (2026-09-02).

Runs from a deployed repository tree (source bundle + overlay), never from the live working tree:
    <repo>/experiments/optimize_hyper_parameters/wrr_hp_extension_20260902/run_one_cell.py --index N

Guarantees
  * data contract: only the train and val splits, both SHA-256 verified; any torch.load of a test split is blocked
  * source contract: every file listed in source_manifest.json must match its SHA-256 (bundle + overlay)
  * seed per cell (Python / NumPy / PyTorch / CUDA); cudnn.benchmark stays on (same-seed, not bitwise)
  * forecast slots = lead 1..12 h (overlay switch KNET_FORECAST_LEADS_START_AT_ONE=1)
  * after training, the best checkpoint is scored on the validation set with 13 slots (0..12) so that both the
    corrected definition (slots 1..12) and the current-code definition (slots 0..11) are on file
Outputs (all under this directory): runs/seed<seed>_gpu/<cell>/, logs/, audits/, registry.csv
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import runpy
import sys
import time
from contextlib import redirect_stderr, redirect_stdout
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
CONFIG = HERE / "base_config.yaml"
COMBOS = HERE / "combos.jsonl"
REGISTRY = HERE / "registry.csv"
MANIFEST = HERE / "source_manifest.json"
GRID_RUNNER = REPO / "experiments" / "optimize_hyper_parameters" / "grid_search_knet.py"
EVAL_LEAD = 13   # slots 0..12 for the post-training validation scoring

EXPECTED_DATA = {
    "train": (REPO / "data/processed/high_flow_aug/train_win800_19990101_01-20070527_03.pt",
              "3a4f94a2562278f09b67853ac77e060766296007cb8f8a762756ffe792792440"),
    "val": (REPO / "data/processed/high_flow_aug/val_win800_20070527_04-20090314_13.pt",
            "2e195fc974b5cc8cdb35df3cb7fd72a202af033ecc415acc03a87020b00bd403"),
}


class Tee:
    def __init__(self, *streams):
        self.streams = streams

    def write(self, text):
        for s in self.streams:
            s.write(text); s.flush()
        return len(text)

    def flush(self):
        for s in self.streams:
            s.flush()


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load_combos() -> list[dict]:
    items = []
    for line in COMBOS.read_text(encoding="utf-8").splitlines():
        if line.strip():
            items.append(json.loads(line))
    return items


def load_combo(index: int) -> dict:
    for it in load_combos():
        if int(it["index"]) == index:
            return it
    raise ValueError(f"Unknown combination index: {index}")


def guard_data_contract() -> dict:
    import yaml
    cfg = yaml.safe_load(CONFIG.read_text(encoding="utf-8"))
    paths = cfg.get("data", {}).get("dataset_path", {})
    if set(paths) != {"train", "val"}:
        raise RuntimeError(f"Dataset split guard failed: expected train/val only, got {sorted(paths)}")
    verified = {}
    for split, (expected_path, expected_hash) in EXPECTED_DATA.items():
        configured = Path(str(paths[split]).replace("${data.base_path}", str(REPO))).resolve()
        if configured != expected_path.resolve():
            raise RuntimeError(f"Unexpected {split} path: {configured}")
        if "test" in configured.name.lower():
            raise RuntimeError(f"Held-out test guard failed for {configured}")
        actual = sha256(configured)
        if actual != expected_hash:
            raise RuntimeError(f"{split} SHA-256 mismatch: expected {expected_hash}, got {actual}")
        verified[split] = {"path": str(configured), "sha256": actual}
    return verified


def guard_source_contract() -> dict:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    expected = manifest.get("source_sha256", {})
    if not expected:
        raise RuntimeError("source_manifest.json has no source_sha256 entries")
    verified = {}
    for rel, exp in expected.items():
        p = REPO / rel
        act = sha256(p)
        if act.lower() != exp.lower():
            raise RuntimeError(f"Source SHA-256 mismatch for {rel}: expected {exp}, got {act}")
        verified[rel] = act
    return verified


def configure_reproducibility(seed: int) -> dict:
    for name in ("BATCH_SIZE", "BATCH_SCALE", "MAX_TRAIN_BATCHES", "MAX_VAL_BATCHES", "MAX_BATCHES", "ONE_BATCH",
                 "TEST_ABORT_AFTER_EPOCH", "RESUME", "PURGE_CKPTS"):
        os.environ.pop(name, None)
    os.environ["PYTHONHASHSEED"] = str(seed)
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    os.environ["DATA_BASE"] = str(REPO)
    os.environ["DISABLE_AUTO_WORKERS"] = "1"
    os.environ["DISABLE_PIN_MEMORY"] = "1"
    os.environ["DISABLE_DATASET_CACHE"] = "1"
    os.environ["NO_TQDM"] = "1"
    os.environ["VALIDATION_QUIET"] = "1"
    os.environ["LOG_MODE"] = "compact"
    os.environ["PERF_INTERVAL"] = "0"
    os.environ["EPOCH_REPORT_EVERY"] = "1"
    os.environ["KNET_FORECAST_LEADS_START_AT_ONE"] = "1"

    import random
    import numpy as np
    import torch

    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = False
    torch.backends.cudnn.benchmark = True
    torch.use_deterministic_algorithms(False)
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable; formal CPU fallback is forbidden")

    original_load = torch.load

    def guarded_load(file, *a, **k):
        try:
            name = Path(os.fspath(file)).name.lower()
        except TypeError:
            name = ""
        if name.startswith("test_") or "held_out_test" in name:
            raise RuntimeError(f"Held-out test load blocked by launcher: {file}")
        return original_load(file, *a, **k)

    torch.load = guarded_load
    return {
        "seed": seed,
        "reproducibility_mode": "seeded_standard_backend",
        "deterministic_algorithms": torch.are_deterministic_algorithms_enabled(),
        "cudnn_deterministic": torch.backends.cudnn.deterministic,
        "cudnn_benchmark": torch.backends.cudnn.benchmark,
        "torch_version": torch.__version__,
        "cuda_version": torch.version.cuda,
        "cudnn_version": torch.backends.cudnn.version(),
        "gpu": torch.cuda.get_device_name(0),
        "forecast_leads_start_at_one": True,
        "held_out_torch_load_guard": True,
    }


def lr_label(lr: float) -> str:
    if lr >= 1e-2:
        return f"{lr:.4f}".rstrip("0").rstrip(".").replace(".", "p")
    return f"{lr:.0e}"


def expected_run_dir(out_base_gpu: Path, combo: dict) -> Path:
    return out_base_gpu / (f"idx{int(combo['index']):04d}_lr{lr_label(float(combo['lr']))}_hs{int(combo['hidden_size'])}"
                           f"_nl{int(combo['num_layers'])}_mult{int(combo['in_out_mult'])}")


# ----------------------------------------------------------------------------------------------
# post-training validation scoring of the best checkpoint (13 slots, both definitions)
# ----------------------------------------------------------------------------------------------
def score_best_checkpoint(combo: dict, run_dir: Path) -> dict:
    import numpy as np
    import torch
    import yaml
    from torch.utils.data import DataLoader
    sys.path.insert(0, str(REPO))
    from experiments.optimize_hyper_parameters.train_and_eval import build_args, build_knet
    import knet.utils.model_initialization_use_script_mdl_1 as init_mod
    from knet.pipelines.pipeline_clean_based_on_11 import Pipeline
    from knet.pipelines.train_clean_based_on_11 import initialize_training, run_one_epoch

    os.environ["KNET_FORECAST_LEADS_START_AT_ONE"] = "0"   # 13 slots = leads 0..12 in one pass
    L = EVAL_LEAD

    class Acc:
        def __init__(self):
            self.n = np.zeros(L); self.sy = np.zeros(L); self.sy2 = np.zeros(L); self.sse = np.zeros(L)
            self.bw_num = np.zeros(L); self.bw_den = 0.0; self.n_windows = 0

        def update(self, d):
            fc = d["outputs_fc_win"].numpy().astype(np.float64).reshape(-1, L)
            ob = d["y_obs_win"].numpy().astype(np.float64).reshape(-1, L)
            nb = fc.shape[0]
            for lt in range(L):
                o = ob[:, lt]; s = fc[:, lt]
                self.n[lt] += len(o); self.sy[lt] += o.sum(); self.sy2[lt] += (o * o).sum(); self.sse[lt] += ((o - s) ** 2).sum()
                self.bw_num[lt] += (1.0 - ((o - s) ** 2).sum() / (((o - o.mean()) ** 2).sum() + 1e-8)) * nb
            self.bw_den += nb; self.n_windows += nb

        def results(self):
            nse, rmse = [], []
            for lt in range(L):
                mean = self.sy[lt] / self.n[lt]; sst = self.sy2[lt] - self.n[lt] * mean ** 2
                nse.append(float(1.0 - self.sse[lt] / sst)); rmse.append(float(np.sqrt(self.sse[lt] / self.n[lt])))
            return nse, rmse, [float(x / self.bw_den) for x in self.bw_num]

    class SP(list):
        def __init__(self, acc):
            super().__init__(); self.acc = acc

        def append(self, d):
            self.acc.update(d)

    class StreamingPipeline(Pipeline):
        def __init__(self, *a, **k):
            super().__init__(*a, **k); self._sp = None

        def set_streaming(self, sp):
            self._sp = sp; self.predictions = sp

        def __setattr__(self, name, value):
            if name == "predictions" and getattr(self, "_sp", None) is not None and isinstance(value, list) and not isinstance(value, SP):
                return
            super().__setattr__(name, value)

    cfg = yaml.safe_load(CONFIG.read_text(encoding="utf-8"))
    val_path = EXPECTED_DATA["val"][0]
    cfg["data"]["dataset_path"] = {"val": str(val_path)}
    cfg["training"]["forecast_lead_time"] = L
    k = cfg["model"]["knet"]
    k["hidden_size"] = int(combo["hidden_size"]); k["num_layers"] = int(combo["num_layers"])
    k["in_mult"] = int(combo["in_out_mult"]); k["out_mult"] = int(combo["in_out_mult"])
    cfg["runtime"]["device"] = "cuda"

    val_ds = torch.load(val_path, map_location="cpu", weights_only=False)
    loader = DataLoader(val_ds, batch_size=int(cfg["dataloader"]["batch_size"]), shuffle=False, num_workers=0)
    sample_p = val_ds[0]["p"]
    if sample_p.ndim > 1:
        sample_p = sample_p.squeeze()
    args = build_args(cfg, sample_p, sample_p); args.device = "cuda"
    sys_model = init_mod.initialize_system_model(args.train_seq_len, args.seq_len_val, device="cuda")
    knet = build_knet(sys_model, args).to("cuda")
    best_path = run_dir / "results" / "best_model.pt"
    ck = torch.load(best_path, map_location="cuda", weights_only=False)
    knet.load_state_dict(ck["model_state_dict"], strict=True)
    pipe = StreamingPipeline(str(run_dir / "results" / "score_tmp"))
    pipe.set_sys_model(sys_model); pipe.set_knet_model(knet); pipe.set_train_params(args)
    pipe.save_predictions = True; pipe.display_metrics_list = ["nse"]
    initialize_training(pipe, loader, loader)
    acc = Acc(); pipe.set_streaming(SP(acc))
    t0 = time.time()
    with torch.no_grad():
        avg_bp, avg_disp = run_one_epoch(pipe, loader, 0, is_training=False)
    nse, rmse, bw = acc.results()
    out = {
        "best_checkpoint": str(best_path),
        "best_checkpoint_sha256": sha256(best_path),
        "best_epoch_zero_based": int(ck.get("epoch", -1)),
        "eval_lead_time": L,
        "eval_seconds": round(time.time() - t0, 1),
        "n_windows": acc.n_windows,
        "pooled_nse_slot_0_to_12": [round(x, 6) for x in nse],
        "pooled_rmse_slot_0_to_12": [round(x, 6) for x in rmse],
        "batchweighted_nse_slot_0_to_12": [round(x, 6) for x in bw],
        "pooled_mean_leads_1_12_corrected_def": round(float(np.mean(nse[1:13])), 6),
        "pooled_mean_slots_0_11_current_def": round(float(np.mean(nse[0:12])), 6),
        "screening_bw_leads_1_12_corrected_def": round(float(np.mean(bw[1:13])), 6),
        "screening_bw_slots_0_11_current_def": round(float(np.mean(bw[0:12])), 6),
    }
    os.environ["KNET_FORECAST_LEADS_START_AT_ONE"] = "1"
    del knet, sys_model, pipe
    torch.cuda.empty_cache()
    return out


def summarize_epoch_log(run_dir: Path) -> dict:
    path = run_dir / "results" / "epoch_log.jsonl"
    if not path.is_file():
        return {"epoch_log": None}
    recs = [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]
    if not recs:
        return {"epoch_log": None}
    best = max((r for r in recs if r.get("improved")), key=lambda r: r["epoch_zero_based"], default=None)
    return {
        "epochs_run": len(recs),
        "stop_epoch_zero_based": recs[-1]["epoch_zero_based"],
        "best_epoch_zero_based_from_log": best["epoch_zero_based"] if best else None,
        "lr_at_best_epoch": best["lr_used_this_epoch"] if best else None,
        "lr_at_stop": recs[-1]["lr_used_this_epoch"],
        "grad_explosion_rollbacks_total": int(sum(r.get("grad_explosion_rollbacks", 0) for r in recs)),
        "nan_inf_skips_total": int(sum(r.get("nan_inf_skips", 0) for r in recs)),
        "first_epoch_with_rollback": next((r["epoch_zero_based"] for r in recs if r.get("grad_explosion_rollbacks", 0) > 0), None),
        "final_epoch_screening_nse": recs[-1].get("val_screening_nse"),
        "max_epoch_screening_nse": max((r.get("val_screening_nse") or float("-inf")) for r in recs),
    }


def update_registry(index: int, row_update: dict):
    rows = []
    with REGISTRY.open("r", encoding="utf-8", newline="") as fh:
        reader = csv.DictReader(fh); fieldnames = reader.fieldnames; rows.extend(reader)
    for row in rows:
        if int(row["index"]) == index:
            row.update({k: v for k, v in row_update.items() if k in fieldnames})
            break
    with REGISTRY.open("w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fieldnames); w.writeheader(); w.writerows(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--index", type=int, required=True)
    parser.add_argument("--smoke", action="store_true", help="1 epoch, 1 batch per phase; results are not comparable")
    args = parser.parse_args()

    combo = load_combo(args.index)
    seed = int(combo.get("seed", 42))
    run_id = combo.get("run_id", f"WRR-HPEXT-20260902-I{args.index:02d}")
    verified_source = guard_source_contract()
    verified_data = guard_data_contract()
    runtime = configure_reproducibility(seed)

    mode = "smoke" if args.smoke else "formal"
    out_base = HERE / "runs" / f"{mode}_seed{seed}"
    out_base_gpu = Path(str(out_base) + "_gpu")
    run_dir = expected_run_dir(out_base_gpu, combo)
    (HERE / "logs").mkdir(parents=True, exist_ok=True)
    (HERE / "audits").mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%dT%H%M%S")
    log_path = HERE / "logs" / f"{run_id}_{mode}.stdout.log"
    audit_path = HERE / "audits" / f"{run_id}_{mode}_{stamp}.json"   # one file per launch, never overwritten

    audit = {
        "run_id": run_id, "mode": mode, "started_at": datetime.now().isoformat(timespec="seconds"),
        "combo": combo, "config_sha256": sha256(CONFIG), "combos_sha256": sha256(COMBOS),
        "verified_data": verified_data, "verified_source": verified_source, "runtime": runtime,
        "held_out_test_loaded": False, "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
        "slurm_array_task_id": os.environ.get("SLURM_ARRAY_TASK_ID"), "hostname": os.uname().nodename if hasattr(os, "uname") else os.environ.get("COMPUTERNAME"),
    }
    audit_path.write_text(json.dumps(audit, indent=2, default=str), encoding="utf-8")

    runner_args = [str(GRID_RUNNER), "--config", str(CONFIG), "--combos-file", str(COMBOS), "--outdir", str(out_base),
                   "--device", "cuda", "--groups", str(args.index), "--ignore-shards", "--auto-suffix-outdir",
                   "--require-gpu", "--resume", "--minimal"]
    if args.smoke:
        os.environ["MAX_TRAIN_BATCHES"] = "1"; os.environ["MAX_VAL_BATCHES"] = "1"
        runner_args.extend(["--epochs", "1"])

    old_argv = sys.argv[:]
    status = "unknown"
    try:
        with log_path.open("a", encoding="utf-8", buffering=1) as lh:
            tee_out = Tee(sys.stdout, lh); tee_err = Tee(sys.stderr, lh)
            with redirect_stdout(tee_out), redirect_stderr(tee_err):
                print(f"[Launcher] run_id={run_id} mode={mode} seed={seed} combo={combo}")
                print(f"[Launcher] repo={REPO} data_guard=train+val only; source manifest verified ({len(verified_source)} files)")
                sys.argv = runner_args
                t0 = time.time()
                runpy.run_path(str(GRID_RUNNER), run_name="__main__")
                train_seconds = time.time() - t0
                metrics_path = run_dir / "metrics.json"
                if not metrics_path.is_file():
                    raise RuntimeError(f"Run returned without metrics.json: {metrics_path}")
                metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
                cell = {"run_id": run_id, "index": args.index, "seed": seed, "combo": combo, "mode": mode,
                        "train_seconds": round(train_seconds, 1), "grid_metrics": metrics,
                        "epoch_log_summary": summarize_epoch_log(run_dir)}
                if not args.smoke:
                    cell["validation_scoring"] = score_best_checkpoint(combo, run_dir)
                cell["finished_at"] = datetime.now().isoformat(timespec="seconds")
                (run_dir / "cell_metrics.json").write_text(json.dumps(cell, indent=2, default=str), encoding="utf-8")
                print(f"[Launcher] cell_metrics written -> {run_dir / 'cell_metrics.json'}")
                # registry.csv is a static plan table; parallel array tasks never rewrite it (race-free).
                # summarize.py aggregates the per-cell cell_metrics.json files instead.
                if not args.smoke:
                    vs = cell["validation_scoring"]
                    print(f"[Launcher] M(leads 1-12)={vs['pooled_mean_leads_1_12_corrected_def']} "
                          f"M(slots 0-11)={vs['pooled_mean_slots_0_11_current_def']} best_epoch={vs['best_epoch_zero_based']} "
                          f"lr_at_best={cell['epoch_log_summary'].get('lr_at_best_epoch')} rollbacks={cell['epoch_log_summary'].get('grad_explosion_rollbacks_total')}")
        status = "ok"
    except BaseException as exc:
        status = f"failed: {type(exc).__name__}: {exc}"
        raise
    finally:
        sys.argv = old_argv
        audit["finished_at"] = datetime.now().isoformat(timespec="seconds")
        audit["launcher_status"] = status
        audit["log_path"] = str(log_path); audit["expected_run_dir"] = str(run_dir)
        audit_path.write_text(json.dumps(audit, indent=2, default=str), encoding="utf-8")


if __name__ == "__main__":
    main()
