"""Step 1 of the WRR hyperparameter-extension plan: re-score existing checkpoints under ONE code snapshot.

Validation set only. No training. The held-out test split is never loaded (hard guard below).

For every checkpoint we run one validation pass with lead_time = 13 and record
  * pooled per-slot NSE / RMSE for slots 0..12   (slot k == forecast lead k hours; slot 0 == analysis)
  * pooled mean over slots 0..11  -> matches the current code's "H1-12" definition
  * pooled mean over slots 1..12  -> corrected definition (true 1..12 h forecasts, no analysis slot)
  * batch-weighted screening NSE over slots 0..11 and over slots 1..12
Outputs: rescoring/rescore_results.json and rescoring/rescore_results.csv (this directory).
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

os.environ.setdefault("NO_TQDM", "1")
os.environ.setdefault("VALIDATION_QUIET", "1")
os.environ.setdefault("PERF_INTERVAL", "0")
os.environ.setdefault("EPOCH_SUMMARY", "0")
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[2]
sys.path.insert(0, str(PROJECT))

import numpy as np
import torch
import yaml
from torch.utils.data import DataLoader

# ---- hard guard: never load a test split ------------------------------------------------------
_orig_load = torch.load


def _guarded_load(f, *a, **k):
    try:
        name = Path(os.fspath(f)).name.lower()
    except TypeError:
        name = ""
    if name.startswith("test_") or "held_out_test" in name:
        raise RuntimeError(f"BLOCKED test-set load: {f}")
    return _orig_load(f, *a, **k)


torch.load = _guarded_load

from experiments.optimize_hyper_parameters.train_and_eval import build_args, build_knet  # noqa: E402
import knet.utils.model_initialization_use_script_mdl_1 as _init_mod  # noqa: E402
from knet.pipelines.pipeline_clean_based_on_11 import Pipeline  # noqa: E402
from knet.pipelines.train_clean_based_on_11 import initialize_training, run_one_epoch  # noqa: E402

VAL_PT = PROJECT / "data/processed/high_flow_aug/val_win800_20070527_04-20090314_13.pt"
VAL_SHA = "2e195fc974b5cc8cdb35df3cb7fd72a202af033ecc415acc03a87020b00bd403"
BASE_CFG = PROJECT / "experiments/optimize_hyper_parameters/kalman_hybrid_config.yaml"
V2_CFG = PROJECT / "experiments/optimize_hyper_parameters/kalman_hybrid_config_v2.yaml"
ARCHIVE = PROJECT / "archive/full_cleanup_2025_12_21/grid_search_results/grid_knet_hpc_gpu"
LOCAL2026 = PROJECT / "experiments/optimize_hyper_parameters/validation_lr_boundary_20260831/runs/formal_gpu"
PAPER_V2 = PROJECT / "retrain_v2_fixed_bounds/results/best_model.pt"
OUT_DIR = HERE / "rescoring"
LEAD = 13          # slots 0..12 -> leads 0..12 h
BATCH = 2048


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


class Acc:
    """Pooled per-slot sufficient statistics + batch-weighted per-slot NSE."""

    def __init__(self, L):
        self.L = L
        self.n = np.zeros(L); self.sy = np.zeros(L); self.sy2 = np.zeros(L); self.sse = np.zeros(L)
        self.bw_num = np.zeros(L)   # sum over batches of (batch NSE_slot * batch windows)
        self.bw_den = 0.0
        self.n_batches = 0
        self.n_windows = 0

    def update(self, d):
        fc = d["outputs_fc_win"].numpy().astype(np.float64).reshape(-1, self.L)
        ob = d["y_obs_win"].numpy().astype(np.float64).reshape(-1, self.L)
        nb = fc.shape[0]
        for lt in range(self.L):
            o = ob[:, lt]; s = fc[:, lt]
            self.n[lt] += len(o); self.sy[lt] += o.sum(); self.sy2[lt] += (o * o).sum(); self.sse[lt] += ((o - s) ** 2).sum()
            om = o.mean()
            sst_b = ((o - om) ** 2).sum() + 1e-8
            self.bw_num[lt] += (1.0 - ((o - s) ** 2).sum() / sst_b) * nb
        self.bw_den += nb
        self.n_batches += 1
        self.n_windows += nb

    def results(self):
        nse, rmse = [], []
        for lt in range(self.L):
            mean = self.sy[lt] / self.n[lt]
            sst = self.sy2[lt] - self.n[lt] * mean ** 2
            nse.append(float(1.0 - self.sse[lt] / sst))
            rmse.append(float(np.sqrt(self.sse[lt] / self.n[lt])))
        bw = [float(x / self.bw_den) for x in self.bw_num]
        return nse, rmse, bw


class StreamingPredictions(list):
    def __init__(self, acc):
        super().__init__(); self.acc = acc

    def append(self, d):
        self.acc.update(d)


class StreamingPipeline(Pipeline):
    def __init__(self, *a, **k):
        super().__init__(*a, **k); self._sp = None

    def set_streaming(self, sp):
        self._sp = sp; self.predictions = sp

    def __setattr__(self, name, value):
        if name == "predictions" and getattr(self, "_sp", None) is not None and isinstance(value, list) and not isinstance(value, StreamingPredictions):
            return
        super().__setattr__(name, value)


def make_cfg(hidden, layers, mult, bounds):
    cfg = yaml.safe_load(BASE_CFG.read_text(encoding="utf-8"))
    cfg["data"]["dataset_path"] = {"val": str(VAL_PT)}
    cfg["training"]["forecast_lead_time"] = LEAD
    cfg["dataloader"]["batch_size"] = BATCH
    k = cfg["model"]["knet"]
    k["hidden_size"] = int(hidden); k["num_layers"] = int(layers); k["in_mult"] = int(mult); k["out_mult"] = int(mult)
    k["activation"] = "relu"; k["dropout"] = 0.0
    if bounds == "v2":
        v2 = yaml.safe_load(V2_CFG.read_text(encoding="utf-8"))["model"]["knet"]
        k["state_bounds"] = v2["state_bounds"]; k["clamp_scale"] = v2["clamp_scale"]
    cfg["runtime"]["device"] = "cuda"
    return cfg


def evaluate(entry, val_ds, loader):
    cfg = make_cfg(entry["hidden_size"], entry["num_layers"], entry["in_out_mult"], entry["bounds"])
    sample_p = val_ds[0]["p"]
    if sample_p.ndim > 1:
        sample_p = sample_p.squeeze()
    args = build_args(cfg, sample_p, sample_p); args.device = "cuda"
    sys_model = _init_mod.initialize_system_model(args.train_seq_len, args.seq_len_val, device="cuda")
    knet = build_knet(sys_model, args).to("cuda")
    ck = torch.load(entry["path"], map_location="cuda", weights_only=False)
    sd = ck["model_state_dict"] if isinstance(ck, dict) and "model_state_dict" in ck else ck
    knet.load_state_dict(sd, strict=True)
    pipe = StreamingPipeline(str(OUT_DIR / "pipe_tmp"))
    pipe.set_sys_model(sys_model); pipe.set_knet_model(knet); pipe.set_train_params(args)
    pipe.save_predictions = True; pipe.display_metrics_list = ["nse"]
    initialize_training(pipe, loader, loader)
    acc = Acc(LEAD); pipe.set_streaming(StreamingPredictions(acc))
    t0 = time.time()
    with torch.no_grad():
        avg_bp, avg_disp = run_one_epoch(pipe, loader, 0, is_training=False)
    dt = time.time() - t0
    nse, rmse, bw = acc.results()
    out = dict(entry)
    out.update({
        "path": str(entry["path"]),
        "checkpoint_sha256": sha256(Path(entry["path"])),
        "checkpoint_epoch_field": int(ck.get("epoch", -1)) if isinstance(ck, dict) else None,
        "seconds": round(dt, 1),
        "n_windows": acc.n_windows,
        "val_bp_loss_L13": float(avg_bp),
        "pooled_nse_slot": [round(x, 6) for x in nse],
        "pooled_rmse_slot": [round(x, 6) for x in rmse],
        "batchweighted_nse_slot": [round(x, 6) for x in bw],
        "pooled_mean_slots_0_11_current_def": round(float(np.mean(nse[0:12])), 6),
        "pooled_mean_slots_1_12_corrected_def": round(float(np.mean(nse[1:13])), 6),
        "screening_bw_slots_0_11_current_def": round(float(np.mean(bw[0:12])), 6),
        "screening_bw_slots_1_12_corrected_def": round(float(np.mean(bw[1:13])), 6),
    })
    del knet, sys_model, pipe
    torch.cuda.empty_cache()
    return out


def read_json_lenient(path: Path) -> dict:
    """Four archived metrics.json files carry one stray trailing character; parse the first object only."""
    text = path.read_text(encoding="utf-8")
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        obj, _ = json.JSONDecoder().raw_decode(text)
        return obj


def collect_entries():
    entries = []
    for d in sorted(ARCHIVE.glob("idx*")):
        m = d / "metrics.json"; p = d / "results" / "best_model.pt"
        if not p.is_file():
            continue
        meta = read_json_lenient(m) if m.is_file() else {}
        entries.append({
            "group": "grid2025", "name": d.name, "path": p,
            "lr": float(meta.get("lr", float("nan"))), "hidden_size": int(meta.get("hidden_size", 0)),
            "num_layers": int(meta.get("num_layers", 0)), "in_out_mult": int(meta.get("in_out_mult", 0)),
            "recorded_2025_score": meta.get("nse"), "recorded_2025_status": meta.get("status"),
            "recorded_best_epoch": meta.get("best_epoch"), "bounds": "default",
        })
    for d in sorted(LOCAL2026.glob("idx*")):
        m = d / "metrics.json"; p = d / "results" / "best_model.pt"
        if not p.is_file():
            continue
        meta = read_json_lenient(m) if m.is_file() else {}
        entries.append({
            "group": "local2026", "name": d.name, "path": p,
            "lr": float(meta.get("lr", float("nan"))), "hidden_size": int(meta.get("hidden_size", 0)),
            "num_layers": int(meta.get("num_layers", 0)), "in_out_mult": int(meta.get("in_out_mult", 0)),
            "recorded_2025_score": meta.get("nse"), "recorded_2025_status": meta.get("status"),
            "recorded_best_epoch": meta.get("best_epoch"), "bounds": "default",
        })
    if PAPER_V2.is_file():
        entries.append({
            "group": "paper_v2", "name": "retrain_v2_fixed_bounds", "path": PAPER_V2,
            "lr": 0.01, "hidden_size": 32, "num_layers": 1, "in_out_mult": 10,
            "recorded_2025_score": None, "recorded_2025_status": "paper", "recorded_best_epoch": 40, "bounds": "v2",
        })
    return entries


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    torch.manual_seed(42)
    assert sha256(VAL_PT) == VAL_SHA, "validation file hash mismatch"
    val_ds = torch.load(VAL_PT, map_location="cpu", weights_only=False)
    loader = DataLoader(val_ds, batch_size=BATCH, shuffle=False, num_workers=0)
    entries = collect_entries()
    print(f"[rescore] {len(entries)} checkpoints; lead_time={LEAD}; device={torch.cuda.get_device_name(0)}", flush=True)
    json_path = OUT_DIR / "rescore_results.json"
    done = {}
    if json_path.is_file():
        try:
            done = {r["name"]: r for r in json.loads(json_path.read_text(encoding="utf-8"))["results"]}
        except Exception:
            done = {}
    results = []
    for i, e in enumerate(entries, 1):
        if e["name"] in done:
            results.append(done[e["name"]]); print(f"[skip] {e['name']} (already scored)", flush=True); continue
        try:
            r = evaluate(e, val_ds, loader)
        except Exception as exc:  # keep going, record the failure
            r = dict(e); r["path"] = str(e["path"]); r["error"] = f"{type(exc).__name__}: {exc}"
        results.append(r)
        print(f"[{i}/{len(entries)}] {e['name']} cur={r.get('pooled_mean_slots_0_11_current_def')} corr={r.get('pooled_mean_slots_1_12_corrected_def')} bw_cur={r.get('screening_bw_slots_0_11_current_def')} err={r.get('error')}", flush=True)
        json_path.write_text(json.dumps({
            "generated_at": datetime.now().isoformat(timespec="seconds"),
            "validation_sha256": VAL_SHA, "lead_time": LEAD, "batch_size": BATCH,
            "device": torch.cuda.get_device_name(0), "torch": torch.__version__,
            "results": results,
        }, indent=2), encoding="utf-8")
    cols = ["group", "name", "lr", "hidden_size", "num_layers", "in_out_mult", "recorded_2025_score", "recorded_best_epoch",
            "checkpoint_epoch_field", "pooled_mean_slots_0_11_current_def", "pooled_mean_slots_1_12_corrected_def",
            "screening_bw_slots_0_11_current_def", "screening_bw_slots_1_12_corrected_def", "val_bp_loss_L13", "error"]
    with (OUT_DIR / "rescore_results.csv").open("w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols, extrasaction="ignore"); w.writeheader()
        for r in results:
            w.writerow({c: r.get(c) for c in cols})
    print("[done]", json_path, flush=True)


if __name__ == "__main__":
    main()
