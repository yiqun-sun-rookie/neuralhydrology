"""Collect cell_metrics.json of every formal cell and apply the pre-registered decision rules.

Rules (frozen 2026-09-02, see README.md):
  metric M = pooled validation NSE averaged over leads 1..12 h (corrected definition), best checkpoint per cell
  delta    = max(range of M over the retained-configuration seeds 42/43/44, 0.005)
  LR bound closed  : no cell with lr > 0.01 exceeds its same-architecture lr = 0.01 anchor by more than delta
  probes closed    : no probe cell (hidden 64 / expansion 15) exceeds the retained configuration (seed 42) by more than delta
  challenger       : any cell violating the above -> needs seeds 43/44 before any configuration change is considered
  0.1 extension    : only if the best cell of an architecture is its lr = 0.05 cell AND it is a challenger
Writes summary.csv and decision.json next to this file. Never reads the held-out test split.
"""
from __future__ import annotations

import csv
import json
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
FLOOR = 0.005


def load_cells():
    cells = []
    for p in sorted(HERE.glob("runs/formal_seed*_gpu/idx*/cell_metrics.json")):
        c = json.loads(p.read_text(encoding="utf-8"))
        if "validation_scoring" not in c:
            continue
        combo = c["combo"]; vs = c["validation_scoring"]; el = c.get("epoch_log_summary", {}) or {}
        cells.append({
            "index": int(c["index"]), "run_id": c["run_id"], "role": combo.get("role"), "seed": int(c["seed"]),
            "lr": float(combo["lr"]), "hidden_size": int(combo["hidden_size"]), "num_layers": int(combo["num_layers"]),
            "in_out_mult": int(combo["in_out_mult"]),
            "M_leads_1_12": vs["pooled_mean_leads_1_12_corrected_def"],
            "M_slots_0_11_current_def": vs["pooled_mean_slots_0_11_current_def"],
            "screening_bw_leads_1_12": vs["screening_bw_leads_1_12_corrected_def"],
            "best_epoch": vs["best_epoch_zero_based"], "lr_at_best_epoch": el.get("lr_at_best_epoch"),
            "rollbacks": el.get("grad_explosion_rollbacks_total"), "first_rollback_epoch": el.get("first_epoch_with_rollback"),
            "stop_epoch": el.get("stop_epoch_zero_based"), "train_seconds": c.get("train_seconds"),
            "path": str(p.relative_to(HERE)).replace("\\", "/"),
        })
    return cells


def arch(c):
    return (c["hidden_size"], c["num_layers"], c["in_out_mult"])


def main():
    cells = load_cells()
    if not cells:
        print("no formal cells found"); return
    retained = [c for c in cells if arch(c) == (32, 1, 10) and c["lr"] == 0.01]
    seeds = sorted({c["seed"] for c in retained})
    if len(retained) >= 2:
        vals = [c["M_leads_1_12"] for c in retained]
        delta = max(max(vals) - min(vals), FLOOR)
    else:
        delta = FLOOR
    ret42 = next((c for c in retained if c["seed"] == 42), None)

    challengers, lr_rows, probe_rows = [], [], []
    for a in sorted({arch(c) for c in cells}):
        anchor = next((c for c in cells if arch(c) == a and c["lr"] == 0.01 and c["seed"] == 42), None)
        for c in sorted((x for x in cells if arch(x) == a and x["seed"] == 42), key=lambda x: x["lr"]):
            if c["lr"] <= 0.01:
                continue
            margin = (c["M_leads_1_12"] - anchor["M_leads_1_12"]) if anchor else None
            beats = (margin is not None) and (margin > delta)
            lr_rows.append({"arch": a, "lr": c["lr"], "M": c["M_leads_1_12"], "anchor_M": anchor["M_leads_1_12"] if anchor else None,
                            "margin": margin, "beats_anchor_by_more_than_delta": beats})
            if beats:
                challengers.append({"reason": "lr_above_0.01_beats_anchor", **lr_rows[-1]})
    for c in cells:
        if str(c.get("role", "")).startswith("probe") and ret42 is not None:
            margin = c["M_leads_1_12"] - ret42["M_leads_1_12"]
            beats = margin > delta
            probe_rows.append({"role": c["role"], "arch": arch(c), "lr": c["lr"], "M": c["M_leads_1_12"],
                               "retained_M": ret42["M_leads_1_12"], "margin": margin, "beats_retained_by_more_than_delta": beats})
            if beats:
                challengers.append({"reason": "probe_beats_retained", **probe_rows[-1]})
    ext_01 = [r for r in lr_rows if r["lr"] == 0.05 and r["beats_anchor_by_more_than_delta"]]

    decision = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "metric": "pooled validation NSE, mean over leads 1..12 h, best checkpoint (validation composite loss)",
        "retained_config_seeds_available": seeds,
        "retained_config_values": {str(c["seed"]): c["M_leads_1_12"] for c in retained},
        "delta": delta, "delta_floor": FLOOR,
        "lr_rows": lr_rows, "probe_rows": probe_rows, "challengers": challengers,
        "lr_upper_bound_closed": not any(r["beats_anchor_by_more_than_delta"] for r in lr_rows),
        "probes_closed": not any(r["beats_retained_by_more_than_delta"] for r in probe_rows),
        "lr_0p1_extension_required_for": [r["arch"] for r in ext_01],
        "n_cells": len(cells),
    }
    (HERE / "decision.json").write_text(json.dumps(decision, indent=2, default=str), encoding="utf-8")
    cols = ["index", "run_id", "role", "seed", "lr", "hidden_size", "num_layers", "in_out_mult", "M_leads_1_12",
            "M_slots_0_11_current_def", "screening_bw_leads_1_12", "best_epoch", "lr_at_best_epoch", "rollbacks",
            "first_rollback_epoch", "stop_epoch", "train_seconds", "path"]
    with (HERE / "summary.csv").open("w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols); w.writeheader()
        for c in sorted(cells, key=lambda x: x["index"]):
            w.writerow({k: c.get(k) for k in cols})
    print(json.dumps({k: decision[k] for k in ("delta", "lr_upper_bound_closed", "probes_closed", "challengers", "n_cells")}, indent=2, default=str))


if __name__ == "__main__":
    main()
