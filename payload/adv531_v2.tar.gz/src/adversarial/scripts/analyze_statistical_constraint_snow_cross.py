"""Cross-analyze persisted forcing-constraint losses against basin snow influence.

This script does not train a model or regenerate forcing errors. It joins the
existing 107-basin constraint-ablation output to the existing hydrological
attribute table and evaluates a prespecified snow-versus-low-snow contrast.

Usage:
    python src/adversarial/scripts/analyze_statistical_constraint_snow_cross.py
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import scipy
from scipy.stats import pearsonr, rankdata, t as student_t

REPO = Path(__file__).resolve().parents[3]
RESULT_ROOT = REPO / "results" / "05_adversarial_robustness" / "id18_s100"
DEFAULT_EXP2 = RESULT_ROOT / "exp2_constraint_ablation.json"
DEFAULT_HYDRO = RESULT_ROOT / "hydro_vulnerability_summary.csv"
DEFAULT_OUTPUT = RESULT_ROOT / "statistical_constraint_snow_cross_v01"

ANALYSIS_ID = "statistical_constraint_snow_cross_v01"
SNOW_THRESHOLD = 0.2
FORCING_ERROR_LIMIT = 0.1
DEFAULT_BOOTSTRAP_SEED = 20260730
DEFAULT_BOOTSTRAP_SAMPLES = 20_000

LEVEL_COLUMNS = {
    "maximum_size_only": "D_lp_0.1",
    "physical_ranges": "D_physical_0.1",
    "statistical": "D_statistical_0.1",
}


def sha256_file(path: Path) -> str:
    """Return the SHA-256 digest of a file."""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _normalize_basin_ids(values: pd.Series) -> pd.Series:
    return values.astype(str).str.strip().str.zfill(8)


def _require_columns(frame: pd.DataFrame, required: set[str], label: str) -> None:
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"{label} is missing required columns: {', '.join(missing)}")


def load_and_validate_inputs(exp2_path: Path, hydro_path: Path) -> pd.DataFrame:
    """Load, join, and validate the two persisted source artifacts."""
    exp2_path = Path(exp2_path)
    hydro_path = Path(hydro_path)
    if not exp2_path.is_file():
        raise FileNotFoundError(f"constraint-ablation input does not exist: {exp2_path}")
    if not hydro_path.is_file():
        raise FileNotFoundError(f"hydrological-attribute input does not exist: {hydro_path}")

    exp2 = pd.DataFrame(json.loads(exp2_path.read_text(encoding="utf-8")))
    hydro = pd.read_csv(hydro_path, dtype={"basin": str})

    exp2_required = {"basin", "nse_clean", *LEVEL_COLUMNS.values()}
    _require_columns(exp2, exp2_required, "constraint-ablation input")
    _require_columns(hydro, {"basin", "frac_snow"}, "hydrological-attribute input")

    exp2 = exp2[list(exp2_required)].copy()
    hydro = hydro[["basin", "frac_snow"]].copy()
    exp2["basin"] = _normalize_basin_ids(exp2["basin"])
    hydro["basin"] = _normalize_basin_ids(hydro["basin"])

    if exp2["basin"].duplicated().any():
        duplicates = sorted(exp2.loc[exp2["basin"].duplicated(keep=False), "basin"].unique())
        raise ValueError(f"constraint-ablation input has duplicate basin identifiers: {duplicates}")
    if hydro["basin"].duplicated().any():
        duplicates = sorted(hydro.loc[hydro["basin"].duplicated(keep=False), "basin"].unique())
        raise ValueError(f"hydrological-attribute input has duplicate basin identifiers: {duplicates}")

    joined = exp2.merge(hydro, on="basin", how="left", validate="one_to_one", sort=False)
    missing_snow = joined.loc[joined["frac_snow"].isna(), "basin"].tolist()
    if missing_snow:
        raise ValueError(f"missing snow attributes for basin identifiers: {missing_snow}")

    numeric_columns = ["nse_clean", "frac_snow", *LEVEL_COLUMNS.values()]
    joined[numeric_columns] = joined[numeric_columns].apply(pd.to_numeric, errors="coerce")
    nonfinite = ~np.isfinite(joined[numeric_columns].to_numpy(dtype=float))
    if nonfinite.any():
        bad_rows, bad_columns = np.where(nonfinite)
        examples = [
            f"{joined.iloc[row]['basin']}:{numeric_columns[column]}" for row, column in zip(bad_rows, bad_columns)
        ]
        raise ValueError(f"non-finite analysis values found: {examples[:10]}")
    if (joined[list(LEVEL_COLUMNS.values())] < 0).any().any():
        raise ValueError("prediction-loss columns must be non-negative")
    if (joined["D_lp_0.1"] <= 0).any():
        raise ValueError("maximum-size-only prediction loss must be positive for retention ratios")

    joined["snow_influenced"] = joined["frac_snow"] > SNOW_THRESHOLD
    n_snow = int(joined["snow_influenced"].sum())
    n_low_snow = int((~joined["snow_influenced"]).sum())
    if min(n_snow, n_low_snow) < 2:
        raise ValueError(f"both snow groups require at least two basins; found snow={n_snow}, low-snow={n_low_snow}")

    joined["snow_group"] = np.where(joined["snow_influenced"], "snow_influenced", "low_snow")
    joined["retention_physical_over_maximum"] = joined["D_physical_0.1"] / joined["D_lp_0.1"]
    joined["retention_statistical_over_maximum"] = joined["D_statistical_0.1"] / joined["D_lp_0.1"]
    return joined


def _partial_spearman(x: np.ndarray, y: np.ndarray, control: np.ndarray) -> dict[str, float]:
    """Partial Spearman correlation using the manuscript's rank-residual method."""
    ranked_x = rankdata(np.asarray(x, dtype=float))
    ranked_y = rankdata(np.asarray(y, dtype=float))
    ranked_control = rankdata(np.asarray(control, dtype=float))
    design = np.column_stack([ranked_control, np.ones(len(ranked_control))])

    def residual(values: np.ndarray) -> np.ndarray:
        coefficients, *_ = np.linalg.lstsq(design, values, rcond=None)
        return values - design @ coefficients

    rho = float(pearsonr(residual(ranked_x), residual(ranked_y)).statistic)
    degrees_of_freedom = len(ranked_x) - 3  # one control: n - k - 2
    if degrees_of_freedom <= 0:
        raise ValueError("partial Spearman correlation requires at least four observations")
    denominator = max(1.0 - rho**2, np.finfo(float).eps)
    statistic = rho * np.sqrt(degrees_of_freedom / denominator)
    p_value = float(2.0 * student_t.sf(abs(statistic), degrees_of_freedom))
    return {
        "rho": rho,
        "p_value": p_value,
        "degrees_of_freedom": int(degrees_of_freedom),
        "n_controls": 1,
    }


def _bootstrap_median_difference(snow_values: np.ndarray,
                                 low_snow_values: np.ndarray,
                                 rng: np.random.Generator,
                                 samples: int) -> list[float]:
    if samples <= 0:
        raise ValueError("bootstrap_samples must be positive")
    snow_indices = rng.integers(0, len(snow_values), size=(samples, len(snow_values)))
    low_indices = rng.integers(0, len(low_snow_values), size=(samples, len(low_snow_values)))
    differences = np.median(snow_values[snow_indices], axis=1) - np.median(low_snow_values[low_indices], axis=1)
    return [float(value) for value in np.quantile(differences, [0.025, 0.975])]


def _summarize_metric(joined: pd.DataFrame,
                      column: str,
                      rng: np.random.Generator,
                      bootstrap_samples: int) -> dict[str, Any]:
    snow_values = joined.loc[joined["snow_influenced"], column].to_numpy(dtype=float)
    low_snow_values = joined.loc[~joined["snow_influenced"], column].to_numpy(dtype=float)
    median_snow = float(np.median(snow_values))
    median_low_snow = float(np.median(low_snow_values))
    return {
        "median_snow": median_snow,
        "median_low_snow": median_low_snow,
        "median_difference_snow_minus_low": median_snow - median_low_snow,
        "bootstrap_95ci_median_difference": _bootstrap_median_difference(snow_values, low_snow_values, rng,
                                                                        bootstrap_samples),
    }


def compute_cross_analysis(joined: pd.DataFrame,
                           bootstrap_seed: int = DEFAULT_BOOTSTRAP_SEED,
                           bootstrap_samples: int = DEFAULT_BOOTSTRAP_SAMPLES) -> dict[str, Any]:
    """Compute all prespecified cross-analysis statistics."""
    rng = np.random.default_rng(bootstrap_seed)
    level_results: dict[str, Any] = {}
    for level_name, column in LEVEL_COLUMNS.items():
        summary = _summarize_metric(joined, column, rng, bootstrap_samples)
        summary["partial_spearman_controlling_clean_nse"] = _partial_spearman(
            joined["frac_snow"].to_numpy(dtype=float),
            joined[column].to_numpy(dtype=float),
            joined["nse_clean"].to_numpy(dtype=float),
        )
        level_results[level_name] = summary

    retention_results = {
        "physical_over_maximum": _summarize_metric(joined, "retention_physical_over_maximum", rng,
                                                   bootstrap_samples),
        "statistical_over_maximum": _summarize_metric(joined, "retention_statistical_over_maximum", rng,
                                                      bootstrap_samples),
    }

    primary = level_results["statistical"]
    primary_ci = primary["bootstrap_95ci_median_difference"]
    primary_partial = primary["partial_spearman_controlling_clean_nse"]
    absolute_snow_gap_persists = bool(primary["median_difference_snow_minus_low"] > 0 and primary_ci[0] > 0
                                      and primary_partial["rho"] > 0 and primary_partial["p_value"] < 0.05)

    retention_ci = retention_results["statistical_over_maximum"]["bootstrap_95ci_median_difference"]
    differential_retention_supported = bool(retention_ci[0] > 0 or retention_ci[1] < 0)
    permitted_claim = (
        "Prediction loss remains greater in the evaluated snow-influenced basins under the nested physical-range "
        "and whole-period-statistics condition."
        if absolute_snow_gap_persists else
        "The prespecified analysis does not support a persistent absolute snow gap."
    )

    return {
        "analysis_id": ANALYSIS_ID,
        "status": "PASS" if absolute_snow_gap_persists else "HOLD",
        "protocol": {
            "analysis_type": "registered post-hoc existing-artifact analysis",
            "selection_timing": (
                "The same persisted artifacts were inspected exploratorily before this formal protocol was frozen; "
                "this is not a prospective preregistration."
            ),
            "forcing_error_limit": FORCING_ERROR_LIMIT,
            "snow_threshold": SNOW_THRESHOLD,
            "snow_definition": "frac_snow > 0.2",
            "bootstrap_seed": int(bootstrap_seed),
            "bootstrap_samples": int(bootstrap_samples),
            "bootstrap_interval": "stratified percentile 95%",
            "partial_correlation": (
                "rank-transform, regress original NSE ranks from both variables, Pearson residual correlation; "
                "two-sided t-test uses n-k-2 degrees of freedom for k controls"
            ),
            "primary_endpoint": "snow-minus-low-snow median D_statistical_0.1",
        },
        "population": {
            "n_total": int(len(joined)),
            "n_snow": int(joined["snow_influenced"].sum()),
            "n_low_snow": int((~joined["snow_influenced"]).sum()),
        },
        "constraint_levels": level_results,
        "retention": retention_results,
        "claim_gates": {
            "absolute_snow_gap_persists": absolute_snow_gap_persists,
            "differential_retention_supported": differential_retention_supported,
            "permitted_claim": permitted_claim,
            "prohibited_claim": (
                "Do not claim that the statistical constraint retains a disproportionately larger fraction of loss in "
                "snow-influenced basins unless differential_retention_supported is true."
            ),
        },
    }


def _atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(text, encoding="utf-8", newline="\n")
    temporary.replace(path)


def _build_summary(result: dict[str, Any]) -> str:
    lines = [
        f"analysis_id: {result['analysis_id']}",
        f"status: {result['status']}",
        (f"population: total={result['population']['n_total']} snow={result['population']['n_snow']} "
         f"low_snow={result['population']['n_low_snow']}"),
        "",
        "constraint_level_medians:",
    ]
    for level_name, statistics in result["constraint_levels"].items():
        correlation = statistics["partial_spearman_controlling_clean_nse"]
        interval = statistics["bootstrap_95ci_median_difference"]
        lines.append(
            f"  {level_name}: snow={statistics['median_snow']:.6f} low_snow={statistics['median_low_snow']:.6f} "
            f"difference={statistics['median_difference_snow_minus_low']:.6f} "
            f"bootstrap95=[{interval[0]:.6f}, {interval[1]:.6f}] "
            f"partial_rho={correlation['rho']:.6f} p={correlation['p_value']:.6e}")
    retention = result["retention"]["statistical_over_maximum"]
    interval = retention["bootstrap_95ci_median_difference"]
    lines.extend([
        "",
        ("statistical_retention_over_maximum: "
         f"snow={retention['median_snow']:.6f} low_snow={retention['median_low_snow']:.6f} "
         f"difference={retention['median_difference_snow_minus_low']:.6f} "
         f"bootstrap95=[{interval[0]:.6f}, {interval[1]:.6f}]"),
        "",
        f"permitted_claim: {result['claim_gates']['permitted_claim']}",
        f"prohibited_claim: {result['claim_gates']['prohibited_claim']}",
    ])
    return "\n".join(lines) + "\n"


def write_outputs(output_dir: Path, joined: pd.DataFrame, result: dict[str, Any]) -> None:
    """Write the isolated analysis package."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    columns = [
        "basin",
        "nse_clean",
        "frac_snow",
        "snow_influenced",
        "snow_group",
        "D_lp_0.1",
        "D_physical_0.1",
        "D_statistical_0.1",
        "retention_physical_over_maximum",
        "retention_statistical_over_maximum",
    ]
    csv_text = joined[columns].to_csv(index=False, lineterminator="\n")
    _atomic_write_text(output_dir / "basin_metrics.csv", csv_text)
    _atomic_write_text(output_dir / "analysis.json", json.dumps(result, indent=2, sort_keys=True) + "\n")
    _atomic_write_text(output_dir / "summary.txt", _build_summary(result))


def run_analysis(exp2_path: Path,
                 hydro_path: Path,
                 output_dir: Path,
                 bootstrap_seed: int = DEFAULT_BOOTSTRAP_SEED,
                 bootstrap_samples: int = DEFAULT_BOOTSTRAP_SAMPLES) -> dict[str, Any]:
    """Run the cross-analysis from immutable persisted inputs."""
    exp2_path = Path(exp2_path).resolve()
    hydro_path = Path(hydro_path).resolve()
    output_dir = Path(output_dir).resolve()
    joined = load_and_validate_inputs(exp2_path, hydro_path)
    result = compute_cross_analysis(joined, bootstrap_seed, bootstrap_samples)
    result["generated_at_utc"] = datetime.now(timezone.utc).isoformat()
    result["inputs"] = {
        "constraint_ablation": {
            "path": str(exp2_path),
            "sha256": sha256_file(exp2_path),
        },
        "hydrological_attributes": {
            "path": str(hydro_path),
            "sha256": sha256_file(hydro_path),
        },
    }
    result["implementation"] = {
        "script": str(Path(__file__).resolve()),
        "script_sha256": sha256_file(Path(__file__).resolve()),
        "python": platform.python_version(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "scipy": scipy.__version__,
    }
    write_outputs(output_dir, joined, result)
    return result


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--exp2", type=Path, default=DEFAULT_EXP2)
    parser.add_argument("--hydro", type=Path, default=DEFAULT_HYDRO)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--bootstrap-seed", type=int, default=DEFAULT_BOOTSTRAP_SEED)
    parser.add_argument("--bootstrap-samples", type=int, default=DEFAULT_BOOTSTRAP_SAMPLES)
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    result = run_analysis(args.exp2, args.hydro, args.output_dir, args.bootstrap_seed, args.bootstrap_samples)
    print(_build_summary(result), end="")
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
