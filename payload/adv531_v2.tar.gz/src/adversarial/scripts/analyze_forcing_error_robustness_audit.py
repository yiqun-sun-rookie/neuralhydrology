"""Deterministic post-hoc robustness checks for the forcing-error manuscript.

This script reads persisted experiment artifacts and CAMELS-US inputs. It does
not train a model or regenerate forcing-error trajectories. It records the
spatial-cluster, snow-threshold, local-scale, attribution-additivity, and
diagnostic-scope checks introduced by the 2026-08-01 manuscript audit.

Run from the repository root:
    python src/adversarial/scripts/analyze_forcing_error_robustness_audit.py
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.stats import pearsonr, rankdata, t as student_t

from neuralhydrology.datasetzoo.camelsus import load_camels_us_attributes, load_camels_us_forcings

REPO = Path(__file__).resolve().parents[3]
RESULT_ROOT = REPO / "results" / "05_adversarial_robustness" / "id18_s100"
RUN_DIR = REPO / "results" / "18_lstm_fair_531" / "lstm_cudalstm_maurer_s100_2026_0616_1513_ep30"
DATA_DIR = REPO / "data" / "camels_us"
OUTPUT_DIR = RESULT_ROOT / "forcing_error_robustness_audit_v01"

HYDRO_PATH = RESULT_ROOT / "hydro_vulnerability_summary.csv"
EXP2_PATH = RESULT_ROOT / "exp2_constraint_ablation.json"
L1_PATH = RESULT_ROOT / "exp_l1l2_summary_eps0.1.json"
OCCLUSION_PATH = RESULT_ROOT / "occlusion_importance_shuffle.csv"
MOMENT_PATH = RESULT_ROOT / "statistical_structure_summary_eps0.1.csv"
L3_PATH = RESULT_ROOT / "l3_realism_summary.csv"
BASIN_FILE = REPO / "src" / "adversarial" / "data" / "531_basins.txt"

TEST_START = "1989-10-01"
TEST_END = "1999-09-30"
SNOW_THRESHOLD = 0.2
BOOTSTRAP_SEED = 20260801
BOOTSTRAP_SAMPLES = 20_000
GLOBAL_SCALES = {
    "precip": 6.955404281616211,
    "temp": 10.73293399810791,
    "srad": 131.17544555664062,
    "vp": 631.7147827148438,
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def partial_spearman(x: np.ndarray, y: np.ndarray, controls: np.ndarray) -> dict[str, float | int]:
    """Rank-residual partial correlation with the correct n-k-2 degrees of freedom."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    controls = np.asarray(controls, dtype=float)
    if controls.ndim == 1:
        controls = controls[:, None]
    if x.ndim != 1 or y.ndim != 1 or controls.ndim != 2:
        raise ValueError("x and y must be one-dimensional and controls two-dimensional")
    if len(x) != len(y) or len(x) != controls.shape[0]:
        raise ValueError("x, y, and controls must have the same number of observations")
    matrix = np.column_stack([np.column_stack([rankdata(column) for column in controls.T]), np.ones(len(x))])

    def residual(values: np.ndarray) -> np.ndarray:
        ranked = rankdata(values)
        coefficients, *_ = np.linalg.lstsq(matrix, ranked, rcond=None)
        return ranked - matrix @ coefficients

    rho = float(pearsonr(residual(x), residual(y)).statistic)
    n_controls = int(controls.shape[1])
    degrees_of_freedom = int(len(x) - n_controls - 2)
    if degrees_of_freedom <= 0:
        raise ValueError("partial correlation has non-positive degrees of freedom")
    denominator = max(1.0 - rho**2, np.finfo(float).eps)
    statistic = float(rho * np.sqrt(degrees_of_freedom / denominator))
    p_value = float(2.0 * student_t.sf(abs(statistic), degrees_of_freedom))
    return {
        "rho": rho,
        "p_value": p_value,
        "degrees_of_freedom": degrees_of_freedom,
        "n_controls": n_controls,
        "n": int(len(x)),
    }


def cluster_bootstrap_median_difference(values: np.ndarray,
                                        snow: np.ndarray,
                                        clusters: np.ndarray,
                                        seed: int = BOOTSTRAP_SEED,
                                        samples: int = BOOTSTRAP_SAMPLES) -> dict[str, Any]:
    """Resample complete HUC2 regions and compare snow-minus-low-snow medians."""
    values = np.asarray(values, dtype=float)
    snow = np.asarray(snow, dtype=bool)
    clusters = np.asarray(clusters).astype(str)
    unique_clusters = np.unique(clusters)
    if len(values) != len(snow) or len(values) != len(clusters):
        raise ValueError("values, snow labels, and clusters must have equal length")
    if len(unique_clusters) < 2:
        raise ValueError("at least two clusters are required")
    indices = {cluster: np.flatnonzero(clusters == cluster) for cluster in unique_clusters}
    rng = np.random.default_rng(seed)
    differences = []
    for _ in range(samples):
        selected = rng.choice(unique_clusters, size=len(unique_clusters), replace=True)
        draw = np.concatenate([indices[cluster] for cluster in selected])
        if snow[draw].any() and (~snow[draw]).any():
            differences.append(float(np.median(values[draw][snow[draw]]) - np.median(values[draw][~snow[draw]])))
    if len(differences) < int(0.95 * samples):
        raise RuntimeError("too many cluster-bootstrap draws lack one snow group")
    interval = np.quantile(np.asarray(differences), [0.025, 0.975])
    return {
        "n_clusters": int(len(unique_clusters)),
        "samples_requested": int(samples),
        "samples_retained": int(len(differences)),
        "seed": int(seed),
        "median_difference": float(np.median(values[snow]) - np.median(values[~snow])),
        "bootstrap_95ci": [float(interval[0]), float(interval[1])],
        "fraction_nonpositive": float(np.mean(np.asarray(differences) <= 0.0)),
    }


def threshold_sensitivity(frac_snow: np.ndarray,
                          values: np.ndarray,
                          thresholds: np.ndarray | None = None) -> list[dict[str, float | int]]:
    thresholds = np.arange(0.05, 0.55, 0.05) if thresholds is None else np.asarray(thresholds, dtype=float)
    rows = []
    for threshold in thresholds:
        snow = frac_snow > threshold
        if not snow.any() or snow.all():
            continue
        median_snow = float(np.median(values[snow]))
        median_low = float(np.median(values[~snow]))
        rows.append({
            "threshold": float(threshold),
            "n_snow": int(snow.sum()),
            "n_low_snow": int((~snow).sum()),
            "median_snow": median_snow,
            "median_low_snow": median_low,
            "difference_snow_minus_low": median_snow - median_low,
        })
    return rows


def attribution_nonadditivity(summary: dict[str, dict[str, Any]]) -> dict[str, Any]:
    rows = []
    for basin, record in summary.items():
        total = float(record["D_nse"])
        attribution_sum = float(sum(float(record[f"{name}_att"]) for name in ("precip", "temp", "srad", "vp")))
        rows.append((str(basin).zfill(8), total, attribution_sum, attribution_sum / total))
    frame = pd.DataFrame(rows, columns=["basin", "total_loss", "attribution_sum", "sum_over_total"])
    quantiles = frame["sum_over_total"].quantile([0.0, 0.1, 0.25, 0.5, 0.75, 0.9, 1.0])
    return {
        "n": int(len(frame)),
        "n_sum_exceeds_total": int((frame["sum_over_total"] > 1.0).sum()),
        "sum_over_total_quantiles": {str(index): float(value) for index, value in quantiles.items()},
    }


def _find_column(frame: pd.DataFrame, token: str) -> str:
    matches = [column for column in frame.columns if token in column.casefold()]
    if not matches:
        raise KeyError(f"forcing column containing {token!r} was not found")
    return matches[0]


def compute_local_scales(basins: list[str]) -> pd.DataFrame:
    rows = []
    for basin in basins:
        forcing, _ = load_camels_us_forcings(DATA_DIR, basin, "maurer")
        forcing = forcing.loc[TEST_START:TEST_END]
        columns = {
            "precip": _find_column(forcing, "prcp"),
            "temp": _find_column(forcing, "tmin"),
            "srad": _find_column(forcing, "srad"),
            "vp": _find_column(forcing, "vp"),
        }
        row: dict[str, Any] = {"basin": basin}
        for name, column in columns.items():
            values = forcing[column].to_numpy(dtype=float)
            values = values[np.isfinite(values)]
            local_scale = float(np.std(values, ddof=0))
            if local_scale <= 0:
                raise ValueError(f"non-positive local scale for {basin}:{column}")
            row[f"local_sd_{name}"] = local_scale
            row[f"global_over_local_{name}"] = float(GLOBAL_SCALES[name] / local_scale)
        rows.append(row)
    return pd.DataFrame(rows)


def _load_inputs() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    hydro = pd.read_csv(HYDRO_PATH, dtype={"basin": str})
    hydro["basin"] = hydro["basin"].str.zfill(8)
    exp2 = pd.DataFrame(json.loads(EXP2_PATH.read_text(encoding="utf-8")))
    exp2["basin"] = exp2["basin"].astype(str).str.zfill(8)
    cross = exp2.merge(hydro[["basin", "frac_snow"]], on="basin", how="left", validate="one_to_one")
    attributes = load_camels_us_attributes(DATA_DIR, basins=cross["basin"].tolist())
    attributes.index = attributes.index.astype(str).str.zfill(8)
    huc = attributes[["huc"]].reset_index().rename(columns={attributes.index.name or "index": "basin"})
    huc["basin"] = huc["basin"].astype(str).str.zfill(8)
    cross = cross.merge(huc, on="basin", how="left", validate="one_to_one")
    return hydro, exp2, cross


def run(output_dir: Path = OUTPUT_DIR) -> dict[str, Any]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    hydro, _, cross = _load_inputs()
    snow = cross["frac_snow"].to_numpy(dtype=float) > SNOW_THRESHOLD
    statistical_loss = cross["D_statistical_0.1"].to_numpy(dtype=float)

    spatial = cluster_bootstrap_median_difference(
        statistical_loss,
        snow,
        cross["huc"].to_numpy(),
    )
    leave_one_huc = []
    for huc in sorted(cross["huc"].astype(str).unique()):
        keep = cross["huc"].astype(str).to_numpy() != huc
        kept_snow = snow[keep]
        difference = float(np.median(statistical_loss[keep][kept_snow])
                           - np.median(statistical_loss[keep][~kept_snow]))
        leave_one_huc.append({"omitted_huc": huc, "difference_snow_minus_low": difference})

    local_scale_path = output_dir / "basin_local_forcing_scales.csv"
    basins = hydro["basin"].tolist()
    local_scales = compute_local_scales(basins)
    local_scales.to_csv(local_scale_path, index=False, lineterminator="\n")
    scale_columns = [f"global_over_local_{name}" for name in ("precip", "temp", "srad", "vp")]
    hydro_scale = hydro.merge(local_scales, on="basin", validate="one_to_one")
    cross_scale = cross.merge(local_scales, on="basin", validate="one_to_one")

    local_scale_sensitivity = {
        "maximum_size_only_531": partial_spearman(
            hydro_scale["frac_snow"].to_numpy(),
            hydro_scale["D_APGD"].to_numpy(),
            hydro_scale[["nse_clean", *scale_columns]].to_numpy(),
        ),
        "whole_period_statistics_107": partial_spearman(
            cross_scale["frac_snow"].to_numpy(),
            cross_scale["D_statistical_0.1"].to_numpy(),
            cross_scale[["nse_clean", *scale_columns]].to_numpy(),
        ),
        "group_medians_global_over_local": {
            name: {
                "snow": float(hydro_scale.loc[hydro_scale["frac_snow"] > SNOW_THRESHOLD, name].median()),
                "low_snow": float(hydro_scale.loc[hydro_scale["frac_snow"] <= SNOW_THRESHOLD, name].median()),
            } for name in scale_columns
        },
    }

    l1 = json.loads(L1_PATH.read_text(encoding="utf-8"))
    occlusion = pd.read_csv(OCCLUSION_PATH)
    moment = pd.read_csv(MOMENT_PATH, dtype={"basin": str})
    moment["basin"] = moment["basin"].str.zfill(8)
    moment_groups = moment.merge(hydro[["basin", "frac_snow"]], on="basin", validate="one_to_one")
    l3 = pd.read_csv(L3_PATH)

    result = {
        "analysis_id": "forcing_error_robustness_audit_v01",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "protocol": {
            "analysis_type": "post-hoc deterministic audit of persisted artifacts",
            "snow_threshold": SNOW_THRESHOLD,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "bootstrap_samples": BOOTSTRAP_SAMPLES,
            "local_scale_period": [TEST_START, TEST_END],
            "local_scale_definition": "global training standard deviation divided by basin test-period standard deviation",
        },
        "spatial_sensitivity": {
            "huc2_cluster_bootstrap": spatial,
            "leave_one_huc_range": [
                float(min(row["difference_snow_minus_low"] for row in leave_one_huc)),
                float(max(row["difference_snow_minus_low"] for row in leave_one_huc)),
            ],
            "leave_one_huc": leave_one_huc,
        },
        "snow_threshold_sensitivity": threshold_sensitivity(
            cross["frac_snow"].to_numpy(dtype=float),
            statistical_loss,
        ),
        "local_scale_sensitivity": local_scale_sensitivity,
        "leave_one_variable_out": attribution_nonadditivity(l1),
        "permutation_diagnostics": {
            "permutations_per_basin": 3,
            "negative_raw_nse_decrease_counts": {
                name: int((occlusion[f"imp_{name}"] < 0).sum()) for name in ("precip", "temp", "srad", "vp")
            },
            "normalization": "negative raw decreases are clipped to zero before the positive scores are normalized",
        },
        "moment_audit_scope": {
            "n": int(len(moment_groups)),
            "n_snow": int((moment_groups["frac_snow"] > SNOW_THRESHOLD).sum()),
            "n_low_snow": int((moment_groups["frac_snow"] <= SNOW_THRESHOLD).sum()),
            "basins": moment_groups["basin"].tolist(),
            "selection_status": "available recorded basins; no representative-sampling rule was prespecified",
        },
        "three_product_diagnostics": {
            "median_basin_mean_daily_three_product_standard_deviation": {
                "precip_mm_per_day": float(l3["prcp_spread"].median()),
                "temperature_c": float(l3["temp_spread"].median()),
            },
            "median_fraction_days_three_product_range_exceeds_error_limit": {
                "precip": float(l3["prcp_exceed"].median()),
                "temperature": float(l3["temp_exceed"].median()),
            },
        },
        "inputs": {
            str(path.relative_to(REPO)): sha256_file(path) for path in (
                HYDRO_PATH,
                EXP2_PATH,
                L1_PATH,
                OCCLUSION_PATH,
                MOMENT_PATH,
                L3_PATH,
                BASIN_FILE,
                RUN_DIR / "train_data" / "train_data_scaler.yml",
            )
        },
    }

    (output_dir / "analysis.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    summary_lines = [
        f"analysis_id: {result['analysis_id']}",
        ("HUC2 cluster bootstrap 95% CI: "
         f"{spatial['bootstrap_95ci'][0]:.6f} to {spatial['bootstrap_95ci'][1]:.6f}"),
        ("leave-one-HUC difference range: "
         f"{result['spatial_sensitivity']['leave_one_huc_range'][0]:.6f} to "
         f"{result['spatial_sensitivity']['leave_one_huc_range'][1]:.6f}"),
        ("local-scale partial rho, maximum-size-only: "
         f"{local_scale_sensitivity['maximum_size_only_531']['rho']:.6f}"),
        ("local-scale partial rho, whole-period-statistics: "
         f"{local_scale_sensitivity['whole_period_statistics_107']['rho']:.6f}"),
        ("leave-one-variable-out sum exceeds total: "
         f"{result['leave_one_variable_out']['n_sum_exceeds_total']}/"
         f"{result['leave_one_variable_out']['n']}"),
    ]
    (output_dir / "summary.txt").write_text("\n".join(summary_lines) + "\n", encoding="utf-8")
    return result


if __name__ == "__main__":
    analysis = run()
    print((OUTPUT_DIR / "summary.txt").read_text(encoding="utf-8"), end="")
