"""Is the elevated adversarial damage in snow basins a gradient-specific fragility,
or just a larger overall input sensitivity?

The main text downgrades the damage *magnitude* in snow catchments ("we do not read it
as a distinct fragility mechanism"). That downgrade needs a number. The test here:

  * If snow basins were specifically fragile to *gradient* attacks, the per-basin
    amplification amp = D_APGD / D_rs100 (gradient damage over best-of-100 random-sign
    damage) would rise with snow fraction.
  * If instead the model is simply more sensitive overall where discharge integrates
    more forcing, then BOTH D_APGD and D_rs100 rise with snow fraction while their
    ratio does not.

Same partial-Spearman machinery as analyze_drought_mechanism.py (rank-transform, OLS
out the controls, Pearson on the residuals, df = N - k - 2 for k controls).

Usage:
    python src/adversarial/scripts/analyze_snow_amplification.py
"""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import spearmanr, pearsonr, rankdata, t as student_t

REPO = Path(__file__).resolve().parents[3]
RES = REPO / "results" / "05_adversarial_robustness" / "id18_s100"


def partial_spearman(x, y, Z):
    """Spearman(x, y) after regressing the (rank-transformed) covariate matrix Z out of both."""
    x, y, Z = np.asarray(x, float), np.asarray(y, float), np.asarray(Z, float)
    rx, ry = rankdata(x), rankdata(y)
    B = np.column_stack([np.column_stack([rankdata(z) for z in Z.T]), np.ones(len(rx))])

    def resid(a):
        c, *_ = np.linalg.lstsq(B, a, rcond=None)
        return a - B @ c

    rho = float(pearsonr(resid(rx), resid(ry)).statistic)
    df = len(rx) - Z.shape[1] - 2
    statistic = rho * np.sqrt(df / max(1.0 - rho**2, np.finfo(float).eps))
    return rho, float(2.0 * student_t.sf(abs(statistic), df))


def report(df, ycol, xcol, zcols, label=None):
    d = df[[ycol, xcol] + zcols].dropna()
    r_raw, p_raw = spearmanr(d[xcol], d[ycol])
    r_par, p_par = partial_spearman(d[xcol].values, d[ycol].values, d[zcols].values)
    print(f"{label or ycol + ' vs ' + xcol:46s}: Spearman {r_raw:+.3f} (p={p_raw:.1e}) | "
          f"partial|{'+'.join(zcols)} {r_par:+.3f} (p={p_par:.1e})  [n={len(d)}]")


df = pd.read_csv(RES / "hydro_vulnerability_summary.csv", dtype={"basin": str})
df["basin"] = df["basin"].str.zfill(8)
SNOW_THR = 0.2
snow = df["frac_snow"] > SNOW_THR

print(f"=== snow amplification check | 531 basins, snow(n={int(snow.sum())}) "
      f"non-snow(n={int((~snow).sum())}) ===")

# 1. both damages rise with snow fraction
report(df, "D_APGD", "frac_snow", ["nse_clean"], "gradient damage D_APGD vs frac_snow")
report(df, "D_rs100", "frac_snow", ["nse_clean"], "random damage  D_rs100 vs frac_snow")

# 2. but the ratio does not
report(df, "amp", "frac_snow", ["nse_clean"], "amp (=D_APGD/D_rs100) vs frac_snow")

print("\nmedians                 snow      non-snow")
for col in ["D_APGD", "D_rs100", "amp", "nse_clean"]:
    print(f"  {col:10s} {df.loc[snow, col].median():>9.3f} {df.loc[~snow, col].median():>13.3f}")

# 3. sanity: amp identity (median of ratios vs ratio of medians)
print(f"\nmedian-of-ratios  amp = {df['amp'].median():.2f}   "
      f"ratio-of-medians = {df['D_APGD'].median() / df['D_rs100'].median():.2f}")
