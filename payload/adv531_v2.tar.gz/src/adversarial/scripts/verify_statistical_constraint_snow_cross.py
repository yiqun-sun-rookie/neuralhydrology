"""Independently verify the statistical-constraint snow cross-analysis.

The verifier intentionally does not import the analysis implementation. It
reloads the two source artifacts and recomputes the registered statistics.

Usage:
    python src/adversarial/scripts/verify_statistical_constraint_snow_cross.py
    python src/adversarial/scripts/verify_statistical_constraint_snow_cross.py --check-only
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import platform
from datetime import datetime, timezone
from pathlib import Path
from statistics import median
from typing import Any

import numpy as np
import scipy
from scipy.stats import pearsonr, rankdata, t as student_t

REPO = Path(__file__).resolve().parents[3]
RESULT_ROOT = REPO / "results" / "05_adversarial_robustness" / "id18_s100"
DEFAULT_EXP2 = RESULT_ROOT / "exp2_constraint_ablation.json"
DEFAULT_HYDRO = RESULT_ROOT / "hydro_vulnerability_summary.csv"
DEFAULT_ANALYSIS = RESULT_ROOT / "statistical_constraint_snow_cross_v01" / "analysis.json"
DEFAULT_OUTPUT = RESULT_ROOT / "statistical_constraint_snow_cross_v01" / "verification.json"

LEVEL_COLUMNS = [
    ("maximum_size_only", "D_lp_0.1"),
    ("physical_ranges", "D_physical_0.1"),
    ("statistical", "D_statistical_0.1"),
]
ABSOLUTE_TOLERANCE = 1e-12


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _load_rows(exp2_path: Path, hydro_path: Path, snow_threshold: float) -> list[dict[str, Any]]:
    exp2 = json.loads(exp2_path.read_text(encoding="utf-8"))
    with hydro_path.open("r", encoding="utf-8-sig", newline="") as handle:
        hydro = {str(row["basin"]).strip().zfill(8): float(row["frac_snow"]) for row in csv.DictReader(handle)}

    rows = []
    seen = set()
    for source in exp2:
        basin = str(source["basin"]).strip().zfill(8)
        if basin in seen:
            raise ValueError(f"duplicate constraint-ablation basin: {basin}")
        seen.add(basin)
        if basin not in hydro:
            raise ValueError(f"missing snow attribute for basin: {basin}")
        row = {
            "basin": basin,
            "nse_clean": float(source["nse_clean"]),
            "frac_snow": hydro[basin],
            "snow": hydro[basin] > snow_threshold,
        }
        for _, column in LEVEL_COLUMNS:
            row[column] = float(source[column])
        row["retention_physical_over_maximum"] = row["D_physical_0.1"] / row["D_lp_0.1"]
        row["retention_statistical_over_maximum"] = row["D_statistical_0.1"] / row["D_lp_0.1"]
        rows.append(row)
    return rows


def _partial_spearman(rows: list[dict[str, Any]], value_column: str) -> dict[str, float]:
    x = rankdata(np.asarray([row["frac_snow"] for row in rows], dtype=float))
    y = rankdata(np.asarray([row[value_column] for row in rows], dtype=float))
    control = rankdata(np.asarray([row["nse_clean"] for row in rows], dtype=float))
    design = np.column_stack([np.ones(len(rows)), control])
    x_coefficients = np.linalg.lstsq(design, x, rcond=None)[0]
    y_coefficients = np.linalg.lstsq(design, y, rcond=None)[0]
    rho = float(pearsonr(x - design @ x_coefficients, y - design @ y_coefficients).statistic)
    degrees_of_freedom = len(rows) - 3  # one control: n - k - 2
    if degrees_of_freedom <= 0:
        raise ValueError("partial Spearman correlation requires at least four observations")
    denominator = max(1.0 - rho**2, np.finfo(float).eps)
    statistic = rho * np.sqrt(degrees_of_freedom / denominator)
    p_value = float(2.0 * student_t.sf(abs(statistic), degrees_of_freedom))
    return {
        "rho": rho,
        "p_value": p_value,
        "degrees_of_freedom": int(degrees_of_freedom),
        "n_controls": 1,
    }


def _bootstrap_interval(snow: np.ndarray,
                        low_snow: np.ndarray,
                        rng: np.random.Generator,
                        samples: int) -> list[float]:
    snow_draws = rng.integers(low=0, high=len(snow), size=(samples, len(snow)))
    low_snow_draws = rng.integers(low=0, high=len(low_snow), size=(samples, len(low_snow)))
    differences = np.median(snow[snow_draws], axis=1) - np.median(low_snow[low_snow_draws], axis=1)
    return [float(value) for value in np.percentile(differences, [2.5, 97.5])]


def _summarize(rows: list[dict[str, Any]],
               column: str,
               rng: np.random.Generator,
               bootstrap_samples: int) -> dict[str, Any]:
    snow = np.asarray([row[column] for row in rows if row["snow"]], dtype=float)
    low_snow = np.asarray([row[column] for row in rows if not row["snow"]], dtype=float)
    median_snow = float(median(snow.tolist()))
    median_low_snow = float(median(low_snow.tolist()))
    return {
        "median_snow": median_snow,
        "median_low_snow": median_low_snow,
        "median_difference_snow_minus_low": median_snow - median_low_snow,
        "bootstrap_95ci_median_difference": _bootstrap_interval(snow, low_snow, rng, bootstrap_samples),
    }


def recompute_registered_statistics(exp2_path: Path,
                                    hydro_path: Path,
                                    protocol: dict[str, Any]) -> dict[str, Any]:
    """Recompute all registered values without importing the analyzer."""
    rows = _load_rows(exp2_path, hydro_path, float(protocol["snow_threshold"]))
    rng = np.random.default_rng(int(protocol["bootstrap_seed"]))
    bootstrap_samples = int(protocol["bootstrap_samples"])

    levels = {}
    for level_name, column in LEVEL_COLUMNS:
        result = _summarize(rows, column, rng, bootstrap_samples)
        result["partial_spearman_controlling_clean_nse"] = _partial_spearman(rows, column)
        levels[level_name] = result

    retention = {
        "physical_over_maximum": _summarize(rows, "retention_physical_over_maximum", rng, bootstrap_samples),
        "statistical_over_maximum": _summarize(rows, "retention_statistical_over_maximum", rng, bootstrap_samples),
    }
    primary = levels["statistical"]
    primary_ci = primary["bootstrap_95ci_median_difference"]
    primary_partial = primary["partial_spearman_controlling_clean_nse"]
    absolute_snow_gap_persists = bool(primary["median_difference_snow_minus_low"] > 0 and primary_ci[0] > 0
                                      and primary_partial["rho"] > 0 and primary_partial["p_value"] < 0.05)
    retention_ci = retention["statistical_over_maximum"]["bootstrap_95ci_median_difference"]
    differential_retention_supported = bool(retention_ci[0] > 0 or retention_ci[1] < 0)
    return {
        "population": {
            "n_total": len(rows),
            "n_snow": sum(row["snow"] for row in rows),
            "n_low_snow": sum(not row["snow"] for row in rows),
        },
        "constraint_levels": levels,
        "retention": retention,
        "claim_gates": {
            "absolute_snow_gap_persists": absolute_snow_gap_persists,
            "differential_retention_supported": differential_retention_supported,
        },
    }


def _compare_numbers(expected: Any, observed: Any, path: str, differences: dict[str, float]) -> bool:
    if isinstance(expected, dict):
        if not isinstance(observed, dict) or set(expected) != set(observed):
            differences[path] = math.inf
            return False
        return all(_compare_numbers(expected[key], observed[key], f"{path}.{key}", differences) for key in expected)
    if isinstance(expected, list):
        if not isinstance(observed, list) or len(expected) != len(observed):
            differences[path] = math.inf
            return False
        return all(
            _compare_numbers(expected[index], observed[index], f"{path}[{index}]", differences)
            for index in range(len(expected)))
    if isinstance(expected, bool) or isinstance(observed, bool):
        match = expected is observed
        if not match:
            differences[path] = math.inf
        return match
    if isinstance(expected, (int, float)) and isinstance(observed, (int, float)):
        difference = abs(float(expected) - float(observed))
        differences[path] = difference
        return difference <= ABSOLUTE_TOLERANCE
    match = expected == observed
    if not match:
        differences[path] = math.inf
    return match


def verify(exp2_path: Path,
           hydro_path: Path,
           analysis_path: Path,
           output_path: Path | None = None) -> dict[str, Any]:
    """Independently recompute and compare the formal analysis."""
    exp2_path = Path(exp2_path).resolve()
    hydro_path = Path(hydro_path).resolve()
    analysis_path = Path(analysis_path).resolve()
    expected = json.loads(analysis_path.read_text(encoding="utf-8"))
    observed = recompute_registered_statistics(exp2_path, hydro_path, expected["protocol"])

    checks = {
        "constraint_ablation_sha256_matches":
            _sha256(exp2_path) == expected["inputs"]["constraint_ablation"]["sha256"],
        "hydrological_attributes_sha256_matches":
            _sha256(hydro_path) == expected["inputs"]["hydrological_attributes"]["sha256"],
        "population_matches":
            observed["population"] == expected["population"],
    }
    differences: dict[str, float] = {}
    checks["constraint_statistics_match"] = _compare_numbers(expected["constraint_levels"],
                                                              observed["constraint_levels"],
                                                              "constraint_levels",
                                                              differences)
    checks["retention_statistics_match"] = _compare_numbers(expected["retention"], observed["retention"], "retention",
                                                             differences)
    expected_gates = {
        "absolute_snow_gap_persists": expected["claim_gates"]["absolute_snow_gap_persists"],
        "differential_retention_supported": expected["claim_gates"]["differential_retention_supported"],
    }
    checks["claim_gates_match"] = observed["claim_gates"] == expected_gates
    finite_differences = [difference for difference in differences.values() if math.isfinite(difference)]
    verification = {
        "analysis_id": expected["analysis_id"],
        "status": "PASS" if all(checks.values()) else "FAIL",
        "verified_at_utc": datetime.now(timezone.utc).isoformat(),
        "analysis": {
            "path": str(analysis_path),
            "sha256": _sha256(analysis_path),
        },
        "source_inputs": {
            "constraint_ablation": {
                "path": str(exp2_path),
                "sha256": _sha256(exp2_path),
            },
            "hydrological_attributes": {
                "path": str(hydro_path),
                "sha256": _sha256(hydro_path),
            },
        },
        "checks": checks,
        "absolute_tolerance": ABSOLUTE_TOLERANCE,
        "maximum_absolute_numeric_difference": max(finite_differences, default=0.0),
        "verification_implementation": {
            "script": str(Path(__file__).resolve()),
            "script_sha256": _sha256(Path(__file__).resolve()),
            "python": platform.python_version(),
            "numpy": np.__version__,
            "scipy": scipy.__version__,
        },
        "independently_recomputed": observed,
    }
    if output_path is not None:
        output_path = Path(output_path).resolve()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = output_path.with_name(f".{output_path.name}.tmp")
        temporary.write_text(json.dumps(verification, indent=2, sort_keys=True) + "\n",
                             encoding="utf-8",
                             newline="\n")
        temporary.replace(output_path)
    return verification


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--exp2", type=Path, default=DEFAULT_EXP2)
    parser.add_argument("--hydro", type=Path, default=DEFAULT_HYDRO)
    parser.add_argument("--analysis", type=Path, default=DEFAULT_ANALYSIS)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--check-only", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    result = verify(args.exp2, args.hydro, args.analysis, None if args.check_only else args.output)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
