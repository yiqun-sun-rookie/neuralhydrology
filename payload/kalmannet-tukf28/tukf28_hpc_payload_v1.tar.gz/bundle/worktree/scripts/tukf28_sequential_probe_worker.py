# -*- coding: utf-8 -*-
"""TUKF28 dev-probe worker: learn the noise first, freeze it, then the parameters.

Contract: docs/plans/2026-09-02-tukf28-sequential-learning-probe-contract.md

Geometry, recipe and basins are TUKF26 forward y6 verbatim (via c23/c24/w26).
Every arm starts from a frozen TUKF26/27 checkpoint carried in `sources/`
and pinned byte-for-byte in the config.

    train arms (192 Adam updates on the 12 hydrology coordinates, noise frozen)
        sequential_leash  ball projection ||h - h_prior||_2 <= rho after each step
        sequential_free   no projection

    derived arms (no training; the record is assembled from sources)
        splice             h from TUKF27 hydrology_only_y6, q/r from TUKF26 filter_only_y6
        ref_filter_only    TUKF26 filter_only_y6      (re-read in this environment)
        ref_joint          TUKF26 joint_y6
        ref_hydrology_only TUKF27 hydrology_only_y6
        ref_all_frozen     TUKF26 all_frozen_base

    anchor       --stage anchor --basin B
    anchor_gate  --stage anchor_gate
    train        --stage train --basin B --mode M --variant y6
    readout      --stage readout --basin B --mode M --variant y6|base
    --sources-root DIR    where the pinned source train json live (default: worktree rels)
    --updates-override N  dev timing probe only (record not written to train/)
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import tukf26_trainlength_probe_worker as w26  # noqa: E402

c24 = w26.c24
c23 = w26.c23
t17 = w26.t17

torch.set_num_threads(1)

EXPERIMENT_ID = "TUKF28_SEQUENTIAL_LEARNING_PROBE_DEV_V1"
LEADS = w26.LEADS
DEFAULT_CONFIG = c23.WORKTREE / "configs/tukf28_sequential_learning_probe_v1.json"

TRAIN_MODES = ("sequential_leash", "sequential_free")
DERIVED_MODES = ("splice", "ref_filter_only", "ref_joint",
                 "ref_hydrology_only", "ref_all_frozen")
ALL_MODES = TRAIN_MODES + DERIVED_MODES

# mode -> (snapshot source key for h, snapshot source key for q/r)
DERIVED_SOURCES = {
    "splice": ("hydrology_only_y6", "filter_only_y6"),
    "ref_filter_only": ("filter_only_y6", "filter_only_y6"),
    "ref_joint": ("joint_y6", "joint_y6"),
    "ref_hydrology_only": ("hydrology_only_y6", "hydrology_only_y6"),
    "ref_all_frozen": ("all_frozen_base", "all_frozen_base"),
}

REPRO_BITWISE = 1e-9   # <= : bitwise reproduction
REPRO_LIMIT = 1e-6     # >  : refuse, environment drift


def load_all(config_path: Path | str) -> tuple[dict, dict]:
    config = json.loads(Path(config_path).read_text(encoding="utf-8"))
    if config["experiment_id"] != EXPERIMENT_ID:
        raise ValueError("wrong experiment id")
    for key, entry in config["frozen_input_sha256"].items():
        path = c23.ROOTS[entry["root"]] / entry["rel"]
        if c23.sha256_file(path) != entry["sha256"]:
            raise ValueError(f"frozen input drifted: {key}")
    c24.load_config(c23.WORKTREE / config["predecessor"]["tukf24_config"],
                    verify_hashes=True)
    contract23 = c23.load_contract(
        c23.WORKTREE / config["predecessor"]["tukf23_config"], verify_hashes=True)
    return config, contract23


def source_record(config: dict, basin_id: str, key: str,
                  sources_root: Path | None) -> dict:
    """Load one pinned source train json and verify it byte-for-byte."""
    entry = config["source_records"][f"{basin_id}_{key}"]
    path = (Path(sources_root) / entry["name"] if sources_root
            else c23.WORKTREE / entry["rel_worktree"])
    actual = c23.sha256_file(path)
    if actual != entry["sha256"]:
        raise ValueError(f"source drifted: {entry['name']} {actual}")
    record = json.loads(path.read_text(encoding="utf-8"))
    lists = record["checkpoint_snapshot"]
    if w26.canonical_snapshot_sha(lists) != record["checkpoint_sha256"]:
        raise ValueError(f"source self-hash mismatch: {entry['name']}")
    return record


def relative_deviation(a: float, b: float) -> float:
    scale = max(abs(a), abs(b))
    return 0.0 if scale == 0.0 else abs(a - b) / scale


def repro_verdict(deviation: float, what: str) -> str:
    if deviation > REPRO_LIMIT:
        raise RuntimeError(
            f"{what}: relative deviation {deviation:.3e} > {REPRO_LIMIT:.0e}; "
            "environment drift, refusing")
    return "bitwise" if deviation <= REPRO_BITWISE else "comparable_not_bitwise"


def leash_project_(model, h_prior: torch.Tensor, rho: float) -> float:
    """Pull h back onto the ball ||h - h_prior||_2 <= rho. Returns ||h - h_prior||
    AFTER projection. h_prior and h are both inside [0,1]^12, so the scaled point
    is a convex combination of the two and stays in the box (no re-clamp needed)."""
    with torch.no_grad():
        delta = model.hydrology_coordinates - h_prior
        norm = float(torch.linalg.vector_norm(delta))
        if norm > rho > 0.0:
            model.hydrology_coordinates.copy_(h_prior + delta * (rho / norm))
            return rho
        return norm


def stage_train(config: dict, contract23: dict, basin_id: str, mode: str,
                variant: str, out_root: Path, sources_root: Path | None,
                updates_override: int | None = None) -> dict:
    t0 = time.perf_counter()
    if mode not in TRAIN_MODES:
        raise ValueError(f"{mode} is a derived arm; it is built by the readout stage")
    cell = f"{basin_id}_{mode}_{variant}"
    out = out_root / "train" / f"{cell}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists() and updates_override is None:
        return json.loads(out.read_text(encoding="utf-8"))
    w26.require_anchor_gate(config, out_root, basin_id)

    seg = config["segments_day_index"]
    train_origins = w26.train_origins_of(config, variant)
    warmup_end = train_origins[0]
    train_hi = max(train_origins) + max(LEADS) + 1
    if train_hi > int(seg["selection_origins"][0]):
        raise ValueError("train targets would cross into the selection segment")
    if warmup_end < int(seg["warmup"][1]) + 1:
        raise ValueError("train slice would start inside the warmup segment")

    prep = c23.prepare_basin(contract23, basin_id)
    model = c23.build_mode_model(contract23, prep)
    h_prior = model.hydrology_coordinates.detach().clone()

    # ---- start self-check (contract section 3) -------------------------------
    start = source_record(config, basin_id, "filter_only_y6", sources_root)
    prior_list = [float(v) for v in h_prior.reshape(-1)]
    if start["checkpoint_snapshot"]["h"] != prior_list:
        raise RuntimeError(f"{cell}: start checkpoint h differs from the calibrated prior")
    c23.restore_(model, c23.snapshot_from_lists(model, start["checkpoint_snapshot"]))
    start_score = w26.selection_score(config, model, prep)
    start_dev = relative_deviation(start_score, start["selection_score_at_checkpoint"])
    start_repro = repro_verdict(start_dev, f"{cell} start selection score")

    hyd, fil = c23.mode_groups(contract23, model, "hydrology_only")  # h free, noise frozen
    frozen_q = model.log_process_diagonal.detach().clone()
    frozen_r = model.log_observation_ratio.detach().clone()

    spec = contract23["optimizer"]
    rho = float(config["leash"]["rho"]) if mode == "sequential_leash" else None
    optimizer = torch.optim.Adam(
        [{"params": hyd, "lr": float(spec["hydrology_learning_rate"])}])
    clip = float(spec["group_gradient_norm"])
    step = int(spec["selection_interval"])
    total = int(spec["updates"]) if updates_override is None else updates_override
    queries = tuple(range(0, total + 1, step))

    train_forcing = torch.as_tensor(prep["forcing"][warmup_end:train_hi])
    train_obs = torch.as_tensor(prep["obs"][warmup_end:train_hi])
    shifted = tuple(o - warmup_end for o in train_origins)
    cov0 = prep["noise"]["initial_covariance"]
    base_var = prep["noise"]["base_observation_variance"]

    def warm_start():
        with torch.no_grad():
            tr = t17.rollout_state_update_trace(
                model, prep["forcing"][:warmup_end], prep["obs"][:warmup_end],
                prep["x0"], cov0, base_observation_variance=base_var)
            return (tr["posterior_state"][-1].detach().clone(),
                    tr["posterior_covariance"][-1].detach().clone())

    query_trace: list[list[float]] = [[0, start_score]]
    train_trace: list[float] = []
    drift_trace: list[float] = []
    leash_hits = 0
    timing: dict = {}
    best = {"score": start_score, "update": 0, "snap": c23.snapshot(model)}

    for update in range(1, total + 1):
        tu = time.perf_counter()
        optimizer.zero_grad(set_to_none=True)
        warm_state, warm_cov = warm_start()
        loss, _ = c24.extended_rolling_objective(
            model, train_forcing, train_obs, warm_state, warm_cov,
            shifted, leads=LEADS, base_observation_variance=base_var)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(hyd, clip)
        optimizer.step()
        model.project_trainable_coordinates_()
        if rho is not None:
            before = float(torch.linalg.vector_norm(
                model.hydrology_coordinates.detach() - h_prior))
            drift = leash_project_(model, h_prior, rho)
            if before > rho:
                leash_hits += 1
        else:
            drift = float(torch.linalg.vector_norm(
                model.hydrology_coordinates.detach() - h_prior))
        drift_trace.append(drift)
        train_trace.append(float(loss))
        timing["update_s"] = time.perf_counter() - tu
        if update in queries:
            score = w26.selection_score(config, model, prep)
            query_trace.append([update, score])
            if score < best["score"]:
                best = {"score": score, "update": update, "snap": c23.snapshot(model)}

    c23.restore_(model, best["snap"])
    if not torch.equal(model.log_process_diagonal, frozen_q) or \
            not torch.equal(model.log_observation_ratio, frozen_r):
        raise RuntimeError(f"{cell}: frozen noise moved during training")

    snap_lists = c23.snapshot_to_lists(best["snap"])
    chosen_drift = (drift_trace[best["update"] - 1] if best["update"] > 0 else 0.0)
    tail = train_trace[-16:] if len(train_trace) >= 32 else []
    tail_drop = ((tail[0] - tail[-1]) / abs(tail[0])) if tail and tail[0] else None
    record = {
        "stage": "train", "experiment_id": config["experiment_id"],
        "grade": "development_probe", "basin_id": basin_id, "mode": mode,
        "variant": variant, "leads_days": list(LEADS),
        "train_origin_count": len(train_origins),
        "segments_day_index": seg, "dim_x": prep["dim_x"],
        "anchor_delta": prep["anchor_delta"],
        "base_observation_variance": base_var,
        "start_source": f"{basin_id}_filter_only_y6",
        "start_source_sha256": start["checkpoint_sha256"],
        "start_selection_score_recomputed": start_score,
        "start_selection_score_recorded": start["selection_score_at_checkpoint"],
        "start_selection_relative_deviation": start_dev,
        "start_reproduction": start_repro,
        "start_h_equals_prior": True,
        "noise_frozen_verified": True,
        "leash_rho": rho,
        "leash_hits": leash_hits if rho is not None else None,
        "drift_trace": drift_trace,
        "drift_at_checkpoint": chosen_drift,
        "selected_update": best["update"],
        "selection_score_at_checkpoint": best["score"],
        "selection_query_trace": query_trace,
        "train_loss_trace": train_trace,
        "budget_tail16_relative_drop": tail_drop,
        "checkpoint_snapshot": snap_lists,
        "checkpoint_sha256": w26.canonical_snapshot_sha(snap_lists),
        "learned_observation_ratio": float(model.observation_ratio()),
        "learned_process_diagonal": [float(v) for v in
                                     model.process_diagonal().reshape(-1)],
        "peak_rss_mb": w26.peak_rss_mb(),
        "timing_probe": timing, "updates_override": updates_override,
        "environment": c23.environment_stamp(),
        "seconds": time.perf_counter() - t0,
        "ran_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    if updates_override is None:
        w26.write_json(out, record)
    return record


def build_derived_record(config: dict, basin_id: str, mode: str, variant: str,
                         out_root: Path, sources_root: Path | None) -> dict:
    """Assemble a train-format record for an arm that needs no training."""
    h_key, noise_key = DERIVED_SOURCES[mode]
    h_src = source_record(config, basin_id, h_key, sources_root)
    n_src = h_src if noise_key == h_key else source_record(
        config, basin_id, noise_key, sources_root)
    snap_lists = {
        "h": list(h_src["checkpoint_snapshot"]["h"]),
        "q": list(n_src["checkpoint_snapshot"]["q"]),
        "r": list(n_src["checkpoint_snapshot"]["r"]),
    }
    record = {
        "stage": "derived", "experiment_id": config["experiment_id"],
        "grade": "development_probe", "basin_id": basin_id, "mode": mode,
        "variant": variant, "leads_days": list(LEADS),
        "hydrology_source": f"{basin_id}_{h_key}",
        "hydrology_source_sha256": h_src["checkpoint_sha256"],
        "noise_source": f"{basin_id}_{noise_key}",
        "noise_source_sha256": n_src["checkpoint_sha256"],
        "source_test_pooled_mse_recorded": None,
        "selected_update": None,
        "checkpoint_snapshot": snap_lists,
        "checkpoint_sha256": w26.canonical_snapshot_sha(snap_lists),
        "environment": c23.environment_stamp(),
        "ran_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    if mode != "splice":  # a ref arm reproduces one source cell exactly
        if snap_lists != h_src["checkpoint_snapshot"]:
            raise RuntimeError(f"{basin_id} {mode}: ref snapshot is not the source")
    w26.write_json(out_root / "train" / f"{basin_id}_{mode}_{variant}.json", record)
    return record


def stage_readout(config: dict, contract23: dict, basin_id: str, mode: str,
                  variant: str, out_root: Path, train_root: Path,
                  sources_root: Path | None) -> dict:
    t0 = time.perf_counter()
    cell = f"{basin_id}_{mode}_{variant}"
    out_dir = out_root / "readout"
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = out_dir / f"{cell}.json"
    npz_path = out_dir / f"{cell}.npz"
    if json_path.exists() and npz_path.exists():
        return json.loads(json_path.read_text(encoding="utf-8"))

    train_path = train_root / "train" / f"{cell}.json"
    if mode in DERIVED_MODES and not train_path.exists():
        build_derived_record(config, basin_id, mode, variant, train_root, sources_root)
    train_record = json.loads(train_path.read_text(encoding="utf-8"))
    snap_lists = train_record["checkpoint_snapshot"]
    if w26.canonical_snapshot_sha(snap_lists) != train_record["checkpoint_sha256"]:
        raise ValueError(f"{cell}: train record self-hash mismatch")

    prep = c23.prepare_basin(contract23, basin_id)
    model = c23.build_mode_model(contract23, prep)
    c23.restore_(model, c23.snapshot_from_lists(model, snap_lists))

    test_origins = w26.fixed_origins(config, "test")
    with torch.no_grad():
        loss, details = c24.extended_rolling_objective(
            model, prep["forcing"], prep["obs"], prep["x0"],
            prep["noise"]["initial_covariance"], test_origins, leads=LEADS,
            base_observation_variance=prep["noise"]["base_observation_variance"])
        errors = c24.extended_forecast_errors(
            model, details["origin_states"], prep["forcing"], prep["obs"],
            test_origins, LEADS)

    np.savez_compressed(
        npz_path, origins=np.asarray(test_origins, dtype=np.int64),
        **{f"lead_{lead}": errors[lead] for lead in LEADS})
    record = {
        "stage": "readout", "experiment_id": config["experiment_id"],
        "grade": "development_probe", "basin_id": basin_id, "mode": mode,
        "variant": variant,
        "checkpoint_sha256": train_record["checkpoint_sha256"],
        "test_pooled_mse": float(loss),
        "test_mse_by_lead": {str(L): float(errors[L].mean()) for L in LEADS},
        "test_origin_count": len(test_origins),
        "errors_npz": npz_path.name,
        "errors_npz_sha256": c24.sha256_file(npz_path),
        "environment": c23.environment_stamp(),
        "seconds": time.perf_counter() - t0,
        "ran_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    # baseline re-read self-check: a ref arm must reproduce its source readout
    ref = config.get("baseline_recorded_mse", {}).get(cell)
    if ref is not None:
        dev = relative_deviation(record["test_pooled_mse"], float(ref))
        record["baseline_recorded_mse"] = float(ref)
        record["baseline_relative_deviation"] = dev
        record["baseline_reproduction"] = repro_verdict(dev, f"{cell} baseline re-read")
    w26.write_json(json_path, record)
    return record


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", required=True,
                    choices=["anchor", "anchor_gate", "train", "readout"])
    ap.add_argument("--basin", default=None)
    ap.add_argument("--mode", default=None, choices=list(ALL_MODES))
    ap.add_argument("--variant", default=None, choices=["y6", "base"])
    ap.add_argument("--config", default=str(DEFAULT_CONFIG))
    ap.add_argument("--out-root", required=True)
    ap.add_argument("--train-root", default=None)
    ap.add_argument("--sources-root", default=None)
    ap.add_argument("--updates-override", type=int, default=None)
    a = ap.parse_args()

    config, contract23 = load_all(a.config)
    out_root = Path(a.out_root)
    train_root = Path(a.train_root or a.out_root)
    sources_root = Path(a.sources_root) if a.sources_root else None

    if a.stage == "anchor":
        record = w26.stage_anchor(config, contract23, a.basin, out_root)
        print(json.dumps({k: record[k] for k in
                          ("basin_id", "anchor_delta", "passed", "seconds")}))
        return 0
    if a.stage == "anchor_gate":
        verdict = w26.stage_anchor_gate(config, contract23, out_root)
        print(json.dumps({k: verdict[k] for k in
                          ("passed_count", "required", "pass", "missing")}))
        return 0 if verdict["pass"] else 1
    if not a.basin or not a.mode or not a.variant:
        raise SystemExit("--basin, --mode, --variant required")
    if (a.mode == "ref_all_frozen") != (a.variant == "base"):
        raise SystemExit("ref_all_frozen uses --variant base; every other arm y6")

    if a.stage == "train":
        record = stage_train(config, contract23, a.basin, a.mode, a.variant,
                             out_root, sources_root, a.updates_override)
        print(json.dumps({k: record[k] for k in
                          ("basin_id", "mode", "variant", "selected_update",
                           "drift_at_checkpoint", "leash_hits", "start_reproduction",
                           "peak_rss_mb", "seconds")} |
                         ({"timing_probe": record["timing_probe"]}
                          if a.updates_override else {})))
        return 0

    record = stage_readout(config, contract23, a.basin, a.mode, a.variant,
                           out_root, train_root, sources_root)
    print(json.dumps({k: record[k] for k in
                      ("basin_id", "mode", "variant", "test_pooled_mse", "seconds")} |
                     ({"baseline_reproduction": record["baseline_reproduction"],
                       "baseline_relative_deviation":
                           record["baseline_relative_deviation"]}
                      if "baseline_reproduction" in record else {})))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
