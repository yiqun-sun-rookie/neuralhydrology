# TUKF28 开发探针合同：先学噪声、锁死、再学参数（顺序 vs 同时）

- 日期：2026-09-02；等级：**开发探针（dev）**。材料沿用 TUKF26/27（27 新流域、正向几何、y6 训练段、测试段已开封），数字永不对外引用，只用于决定要不要做正式版。
- 用户假设（2026-09-02 原话大意）："水文模型结构、过程、输入误差都大。让滤波器先通过学过程噪声把一部分误差认领走，参数只学剩下的，就不会像单独学参数或同时学那样过拟合。"
- 文献锚点：SODA（Vrugt 等 2005，WRR）的结构就是"噪声先离线定死、再优化参数"，并报告了"允许状态更新后参数变得更不明确"（第 65 段）但没有测样本外代价。本探针是 SODA 顺序的可微版本，对照的是 SODA 没做过的"同时学"。

## 一、要回答的唯一问题

**把"学噪声"和"学参数"按先后分开，是否消除同时学（joint）对只学噪声（filter_only）的劣势？**

已知（同几何 y6、同测试段、同 27 流域，TUKF26/27 存档）：

| 对比 | 胜场 | 中位 MSE 比 |
|---|---|---|
| filter_only vs all_frozen | 22/27 | 0.931 |
| hydrology_only vs all_frozen | 18/27 | 0.9805 |
| joint vs filter_only | 13/27 | 1.0129 |
| hydrology_only vs filter_only | 9/27 | 1.048 |

已诊断的机制（本会话从存档拆出）：joint 的噪声只做了 filter_only 18–55% 的动作；joint 的参数比 hydrology_only 多挪 1.8 倍（0.262 vs 0.143，单位坐标 L2 中位），方向余弦 0.89；多挪的部分 95% 是流域特异方向，与泛化落差相关（rho 0.44，p=0.021）。

## 二、几何与材料（全部沿用，零改动）

- 几何 = TUKF26 正向 y6 原样：热身 [0,179]；训练 origins [180,2528]（2349 个）；缓冲 10；选择 origins [2539,2900]（362 个）；缓冲 10；测试 origins [2911,3640]（730 个）；lead 1–10。
- 只做 y6，不做 y2。理由：问题是"先后 vs 同时"，不是数据量；y6 是参数有信号的那档（hydrology_only 18/27），且 filter_only-y6 零更新 0/27（起点干净）。省一半算力。
- 配方 = TUKF23 冻结原样（噪声统计窗 [0,1462)、锚点 1e-6、Adam、裁剪 1.0、192 步、每 4 步查询、平局取早、1–10 日等权 rolling-origin 损失、每日状态更新）。
- 锚点门 27/27 前置照旧。

## 三、臂与格

**训练臂（2 × 27 = 54 格）**，起点都是 TUKF26 `{basin}_filter_only_y6` 的选中检查点（噪声已学好、参数仍在率定值）：

| 臂 | 学什么 | 锁什么 | 拴绳 |
|---|---|---|---|
| sequential_leash | 12 个水文坐标（lr 0.005） | q、r 逐位锁死在 filter_only 学出的值 | 有：ρ = 0.15 |
| sequential_free | 同上 | 同上 | 无 |

拴绳定义（单位坐标 [0,1]^12，L2）：每步 `optimizer.step()` 与既有 `project_trainable_coordinates_()` 之后，令 d = h − h_prior；若 ‖d‖₂ > ρ 则 h ← h_prior + d·ρ/‖d‖₂，再 clamp 到 [0,1]。h_prior = 率定值（= 全冻结臂的 h；filter_only 从不动 h，故与其检查点里的 h 逐位相同，训练前断言）。ρ = 0.15 取自 TUKF27 hydrology_only-y6 参数移动量中位 0.143（同流域 dev 数字，正式版须先验固定不再重推）。

优化器：新建 Adam（不继承 filter_only 的 Adam 状态），仅水文组，裁剪仅作用于水文组；噪声两组 `requires_grad=False`。选择段、查询节奏、平局规则与 TUKF26 逐字相同。

**拼接臂（只读出，0 训练格，27 读出格）**：`splice_y6`，h ← TUKF27 `{basin}_hydrology_only_y6` 检查点的 h；q、r ← TUKF26 `{basin}_filter_only_y6` 检查点的 q、r。以 train 记录格式落盘（stage = "splice"，两份来源的 checkpoint_sha256 一并记入），走标准读出。它是"两半能否相加"的下界，不是主判读。**上限披露**：hydrology_only-y6 有 5/27 流域零更新（01552500、02342933、07145700、09065500、14309500），这 5 个流域的拼接臂与 filter_only 逐位相同 → 平局计输，拼接臂最多赢 22/27。

**基线（四个，全部在本探针环境里重读，108 读出格）**：TUKF26 的 filter_only-y6、joint-y6、all_frozen-base，TUKF27 的 hydrology_only-y6，各 27 个检查点按标准读出重新跑一遍。**判读一律用重读数字**，使所有比较落在同一环境；重读与存档 `test_pooled_mse` 的逐流域相对偏差作为诊断量记录：≤ 1e-9 记"逐位复现"，(1e-9, 1e-6] 记"环境非逐位但可比"并继续，> 1e-6 即停，报环境漂移，不做判读。（依据：TUKF26 与 TUKF27 分别跑在 icn270/276 与 icn274/275 节点上，27 个流域的 anchor_delta 逐位相同，跨节点逐位复现有先例。）

**起点自检（每个训练格开跑前）**：① 来源记录自校验：检查点快照的规范散列 == 记录里的 `checkpoint_sha256`（filter_only 与 hydrology_only 两份来源都查）；② 载入的 filter_only 检查点 h 与率定值逐位相等（2026-09-02 已在 27 个存档上核实为真）；③ 用本环境重算该检查点的选择分，与 TUKF26 记录的 `selection_score_at_checkpoint` 比对：相对偏差 ≤ 1e-9 记逐位复现，> 1e-6 即该格拒跑。

**构造性质（判读时须记住）**：顺序臂的第 0 步选择分就是 filter_only 检查点的选择分，早停只接受更好的检查点，所以**顺序臂在选择段上不可能差于 filter_only**；它在测试段若输，全部是"选择段 → 测试段"的泛化落差，不是拟合能力问题。

## 四、预先写死的判读（开跑前定案）

测试段 730 起报日 × lead 1–10 合并均方误差；逐流域比值 = 臂 / 对照；胜 = 比值 < 1；平局按输计。

- **S0 训练成功前置门**（用户铁律）：任一顺序臂零更新（selected_update = 0）> 9/27，或"损失不降"（第 192 步损失 ≥ 第 1 步损失）的流域 > 9/27 → 先报机制问题，S1–S4 只报事实不下结论。
- **S1 主判读：sequential_leash vs filter_only-y6**
  - 值得正式化：胜场 ≥ 17/27 且中位比 ≤ 0.99
  - 顺序无效：胜场 ≤ 13/27 或中位比 ≥ 1.00
  - 中间：报事实，等用户拍板
- **S2 假设直检：sequential_leash vs joint-y6**（先后 vs 同时，同起点同预算）。假设成立应 ≥ 19/27；≤ 13/27 则"先后顺序"不是病根。
- **S3 绳子：sequential_leash vs sequential_free**，附两臂 ‖Δh‖ 分布、顶到 ρ 边界的流域数。若 free 显著优于 leash（≥ 19/27），报"绳子太紧"，不擅自改 ρ 重跑。
- **S4 拼接：splice vs filter_only-y6；sequential_leash vs splice。** 后者回答"噪声学完再学参数"是否优于"各学各的再拼"。
- **S5 机制量（不设门）**：逐流域 ‖Δh‖、顶到 ρ 边界的流域数（投影式 Adam 会沿球面滑动，顶边界是预期行为不是故障）、selected_update、零更新数、训练末损失降幅、泛化落差（测试比 ÷ 训练比，对照 joint-y6 的 1.21）、噪声逐位不变的断言结果；上下文数：sequential_leash vs all_frozen 胜场与中位比。
- **组合预案**：
  - S1 值得 且 S2 ≥ 17 → 顺序有效，进入正式合同（第三批新抽 27 流域、正向、预注册门 19/27、ρ 先验固定 0.15、joint 对照给 384 步对齐预算）
  - **无害但无益**：S1 胜场 12–16 且中位比在 [0.99, 1.01]，且 S2 ≥ 15 → 顺序把参数学习从"有害"变成"无害"，但本设定下参数没有可学的增益；参数学习线维持关闭，"先噪声后参数"可作为安全做法写入论文方法讨论
  - S1 无效 且 S2 ≤ 13 → 先后顺序不是病根，参数学习线维持关闭；剩余抓手只有噪声模型本身（随流量变的噪声，另立合同）
  - S1 无效 但 S3 free 显著优于 leash（≥ 19/27）→ 绳子设错，报幅度，等拍板
  - 其他 → 报事实

## 五、披露

1. **选择段二次使用**：起点检查点已在选择段上挑过一次（TUKF26），本探针在同一选择段上再挑一次。选择偏乐观会叠加，但不触及测试段；joint 只挑一次，对比时须提这一点。
2. **跨实验基线**：filter_only / joint / hydrology_only / all_frozen 的读出来自 TUKF26/27 的 HPC 运行；本探针以锚点门 + 基线重读自检保证可比。
3. **ρ 来源**：同流域 dev 数字推得，本探针内不算独立；正式版须先验固定。
4. **测试段已开封**（TUKF26/27），全部数字 dev 级。
5. **预算不对等**：顺序臂累计 384 步（噪声 192 + 参数 192），joint 只有 192 步。依据 TUKF26 实测 joint-y6 预算受限 0/27（末 16 步降幅均 ≤ 2%，选中步中位 52），额外预算对 joint 无实质影响；正式版仍应给 joint 384 步对齐。
6. **未跑的变体**（本探针不做，留作后续）：第二段噪声不锁死、以 lr 0.005 与参数同调；只放开 FC/BETA/PERC 三坐标；ρ 扫描。任何一个都须另立合同。

## 六、执行

- 平台 HPC hcpu48y；落点 `/data1/home/sunyiq/kalmannet_tukf28_20260902`；信箱 channel `kalmannet-tukf28`；管线照抄 TUKF27 链：bundle 字节级封运 + frozen-pin 自检 → 锚点门 27/27 → 训练阵列 54（`--cpus-per-task=2`）→ 读出阵列 189（54 顺序臂 + 27 拼接 + 108 基线重读）→ 取回 → 本地读出脚本。
- 成本实测依据：hydrology_only-y6 每步中位 24.9 s、峰值内存中位 2255 MB（TUKF27）；54 格 × 192 步 ≈ 80 分钟/格，阵列墙钟 ≈ 1.5–3 小时视排队；读出 189 单元 × 约 11 s ≈ 35 分钟 CPU（阵列并行后几分钟）。
- 新文件（全部全新路径）：`scripts/tukf28_sequential_probe_worker.py`、`scripts/build_tukf28_config.py`、`configs/tukf28_sequential_learning_probe_v1.json`、`scripts/build_tukf28_hpc_bundle.py`、`scripts/tukf28_probe_readout.py`（本地读出：产出 `artifacts/tukf28_sequential_learning_probe_v1/probe_readout.txt` 与 `per_basin.csv`，S0–S5 按第四节顺序逐条打印）、`results/tukf28_sequential_learning_probe_v1/`。
- 配置冻结钉子：本合同、TUKF23/24/26/27 配置、TUKF26/27 worker、新 worker、**TUKF26 filter_only-y6 与 TUKF27 hydrology_only-y6 各 27 个 train json 的 SHA-256**（起点与拼接来源逐文件钉死，随 bundle 封运）。
- 红线照旧：TUKF17–27 冻结产物只读；全部新文件新路径；不 scancel、不进 `~/neuralhydrology`、只写自己落点；开跑前查目标主机资源。
