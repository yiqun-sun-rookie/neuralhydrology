"""Dense causal Transformer over forcing-driven variable-length hydrological tokens."""

import hashlib
import math
from typing import Dict, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as functional

from neuralhydrology.modelzoo.basemodel import BaseModel
from neuralhydrology.modelzoo.head import get_head
from neuralhydrology.modelzoo.hydrologic_dynamic_tokenizer import HydrologicDynamicTokenizer
from neuralhydrology.modelzoo.inputlayer import InputLayer
from neuralhydrology.modelzoo.modern_causal_transformer import GatedFeedForward, RMSNorm
from neuralhydrology.utils.config import Config


class ElapsedTimeRotaryEmbedding(nn.Module):
    """Rotate queries and keys using each token's actual center day."""

    def __init__(self, head_dimension: int, base: float = 10_000.0):
        super().__init__()
        if head_dimension % 2 != 0:
            raise ValueError("Elapsed-time rotary encoding requires an even attention-head dimension.")
        inverse_frequency = 1.0 / (base**(torch.arange(0, head_dimension, 2, dtype=torch.float32) / head_dimension))
        self.register_buffer("inverse_frequency", inverse_frequency, persistent=False)
        self.head_dimension = head_dimension

    @staticmethod
    def _rotate(x: torch.Tensor, cosine: torch.Tensor, sine: torch.Tensor) -> torch.Tensor:
        even = x[..., 0::2]
        odd = x[..., 1::2]
        rotated = torch.stack((even * cosine - odd * sine, even * sine + odd * cosine), dim=-1)
        return rotated.flatten(start_dim=-2)

    def forward(self, query: torch.Tensor, key: torch.Tensor,
                elapsed_positions: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        if query.shape != key.shape:
            raise ValueError("Query and key tensors must have identical shapes.")
        if query.shape[-1] != self.head_dimension:
            raise ValueError("Query and key widths must match the configured head dimension.")
        if elapsed_positions.shape != (query.shape[0], query.shape[-2]):
            raise ValueError("elapsed_positions must have shape [batch, tokens].")
        angles = elapsed_positions.to(self.inverse_frequency.dtype).unsqueeze(-1) * self.inverse_frequency
        cosine = angles.cos().to(query.dtype).unsqueeze(1)
        sine = angles.sin().to(query.dtype).unsqueeze(1)
        return self._rotate(query, cosine, sine), self._rotate(key, cosine.to(key.dtype), sine.to(key.dtype))


class ElapsedTimeCausalSelfAttention(nn.Module):
    """Causal self-attention whose rotary coordinates are elapsed days."""

    def __init__(self, model_width: int, num_heads: int, dropout: float):
        super().__init__()
        if model_width % num_heads != 0:
            raise ValueError(f"Model width {model_width} must be divisible by {num_heads} attention heads.")
        head_dimension = model_width // num_heads
        if head_dimension % 2 != 0:
            raise ValueError("Elapsed-time rotary encoding requires an even attention-head dimension.")
        self.model_width = model_width
        self.num_heads = num_heads
        self.head_dimension = head_dimension
        self.dropout = float(dropout)
        self.query_projection = nn.Linear(model_width, model_width, bias=False)
        self.key_projection = nn.Linear(model_width, model_width, bias=False)
        self.value_projection = nn.Linear(model_width, model_width, bias=False)
        self.output_projection = nn.Linear(model_width, model_width, bias=False)
        self.rotary_embedding = ElapsedTimeRotaryEmbedding(head_dimension)
        self.residual_dropout = nn.Dropout(dropout)

    def _split_heads(self, x: torch.Tensor) -> torch.Tensor:
        batch_size, token_count, _ = x.shape
        return x.view(batch_size, token_count, self.num_heads, self.head_dimension).transpose(1, 2)

    def forward(self, x: torch.Tensor, elapsed_positions: torch.Tensor) -> torch.Tensor:
        query = self._split_heads(self.query_projection(x))
        key = self._split_heads(self.key_projection(x))
        value = self._split_heads(self.value_projection(x))
        query, key = self.rotary_embedding(query, key, elapsed_positions)
        attended = functional.scaled_dot_product_attention(query,
                                                           key,
                                                           value,
                                                           dropout_p=self.dropout if self.training else 0.0,
                                                           is_causal=True)
        attended = attended.transpose(1, 2).contiguous().view(x.shape)
        return self.residual_dropout(self.output_projection(attended))


class ElapsedTimeTransformerBlock(nn.Module):
    """Pre-normalized dense Transformer block for hydrological tokens."""

    def __init__(self, model_width: int, num_heads: int, intermediate_width: int, dropout: float):
        super().__init__()
        self.attention_norm = RMSNorm(model_width)
        self.attention = ElapsedTimeCausalSelfAttention(model_width, num_heads, dropout)
        self.feed_forward_norm = RMSNorm(model_width)
        self.feed_forward = GatedFeedForward(model_width, intermediate_width, dropout=dropout)

    def forward(self, x: torch.Tensor, elapsed_positions: torch.Tensor) -> torch.Tensor:
        x = x + self.attention(self.attention_norm(x), elapsed_positions)
        return x + self.feed_forward(self.feed_forward_norm(x))


class HydrologicDynamicTokenTransformer(BaseModel):
    """Predict final-day discharge from causal, forcing-driven variable-length tokens."""

    module_parts = ["embedding_net", "tokenizer", "token_projection", "blocks", "final_norm", "head"]

    def __init__(self, cfg: Config):
        self._validate_configuration(cfg)
        super().__init__(cfg=cfg)
        self.embedding_net = InputLayer(cfg)
        model_width = self.embedding_net.output_size
        if model_width % cfg.transformer_nheads != 0:
            raise ValueError(f"Embedding dimension {model_width} must be divisible by {cfg.transformer_nheads} heads.")
        if (model_width // cfg.transformer_nheads) % 2 != 0:
            raise ValueError("Elapsed-time rotary encoding requires an even attention-head dimension.")
        self.dynamic_input_names = list(cfg.dynamic_inputs_flattened)
        self.sum_input_names = list(cfg.dynamic_token_sum_inputs)
        self.sum_raw_indices = [self.dynamic_input_names.index(name) for name in self.sum_input_names]

        dynamic_width = self.embedding_net.dynamics_output_size
        static_width = self.embedding_net.statics_output_size
        raw_static_width = len(cfg.static_attributes + cfg.hydroatlas_attributes + cfg.evolving_attributes)
        if cfg.use_basin_id_encoding:
            raw_static_width += cfg.number_of_basins
        pool_input_width = dynamic_width + len(self.dynamic_input_names) + len(self.sum_raw_indices)
        extensive_indices = tuple(range(dynamic_width + len(self.dynamic_input_names), pool_input_width))
        self.model_width = self.embedding_net.output_size
        token_feature_width = pool_input_width + 3 + static_width
        initial_rate = min(cfg.dynamic_token_target_count / float(cfg.seq_length), 1.0 - 1e-6)
        self.tokenizer = HydrologicDynamicTokenizer(
            dynamic_input_size=len(self.dynamic_input_names),
            static_input_size=raw_static_width,
            hidden_size=cfg.dynamic_token_boundary_hidden_size,
            num_rate_layers=2,
            rate_kernel_size=cfg.dynamic_token_boundary_kernel_size,
            min_token_length=cfg.dynamic_token_min_length,
            max_token_length=cfg.dynamic_token_max_length,
            temperature=cfg.dynamic_token_boundary_temperature,
            sum_input_indices=extensive_indices,
            target_token_count=cfg.dynamic_token_target_count,
            mode=cfg.dynamic_token_mode,
            fixed_token_length=cfg.dynamic_token_fixed_length,
            detach_boundary_gradient=cfg.dynamic_token_detach_boundary_gradient,
            initial_rate=initial_rate)
        self.token_projection = nn.Linear(token_feature_width, self.model_width, bias=False)
        self.blocks = nn.ModuleList([
            ElapsedTimeTransformerBlock(self.model_width, cfg.transformer_nheads,
                                        cfg.transformer_dim_feedforward, cfg.transformer_dropout)
            for _ in range(cfg.transformer_nlayers)
        ])
        self.final_norm = RMSNorm(self.model_width)
        self.output_dropout = nn.Dropout(cfg.output_dropout)
        self.head = get_head(cfg=cfg, n_in=self.model_width, n_out=self.output_size)
        self._initial_boundary_rate = initial_rate
        if cfg.seed is None:
            self.apply(self._initialize_module)
        else:
            self._initialize_named_parameters(cfg.seed)
        self._restore_boundary_rate_bias()

    @staticmethod
    def _validate_configuration(cfg: Config):
        if not isinstance(cfg.seq_length, int) or cfg.seq_length < 1:
            raise ValueError("hydrologic dynamic tokens require one positive integer seq_length.")
        if not isinstance(cfg.predict_last_n, int) or cfg.predict_last_n != 1:
            raise ValueError("hydrologic dynamic tokens require predict_last_n to equal 1.")
        if cfg.head.lower() != "regression":
            raise ValueError("hydrologic dynamic tokens currently support only the regression head.")
        if cfg.nan_handling_method is not None:
            raise ValueError("hydrologic dynamic tokens do not yet support a nan_handling_method.")
        if cfg.timestep_counter:
            raise ValueError("hydrologic dynamic tokens use elapsed-day positions and do not accept timestep_counter.")
        mode = cfg.dynamic_token_mode.lower()
        if mode not in {"fixed", "learned"}:
            raise ValueError("dynamic_token_mode must be either 'fixed' or 'learned'.")
        minimum = cfg.dynamic_token_min_length
        maximum = cfg.dynamic_token_max_length
        if (not isinstance(minimum, int) or isinstance(minimum, bool)
                or not isinstance(maximum, int) or isinstance(maximum, bool)):
            raise TypeError("dynamic token minimum and maximum lengths must be integers.")
        if minimum < 1 or maximum < minimum:
            raise ValueError("dynamic token lengths require 1 <= minimum <= maximum.")
        if mode == "learned" and minimum < 2:
            raise ValueError("learned dynamic tokens require dynamic_token_min_length to be at least 2.")
        if cfg.dynamic_token_fixed_length is None:
            raise ValueError("dynamic_token_fixed_length must be supplied as the fixed control and initialization scale.")
        if not isinstance(cfg.dynamic_token_fixed_length, int) or isinstance(cfg.dynamic_token_fixed_length, bool):
            raise TypeError("dynamic_token_fixed_length must be an integer.")
        if not minimum <= cfg.dynamic_token_fixed_length <= maximum:
            raise ValueError("dynamic_token_fixed_length must lie between the minimum and maximum lengths.")
        minimum_count = math.ceil(cfg.seq_length / maximum)
        maximum_count = math.ceil(cfg.seq_length / minimum)
        if not isinstance(cfg.dynamic_token_target_count, int) or isinstance(cfg.dynamic_token_target_count, bool):
            raise TypeError("dynamic_token_target_count must be an integer.")
        if not minimum_count <= cfg.dynamic_token_target_count <= maximum_count:
            raise ValueError(
                f"dynamic_token_target_count must be in the feasible range [{minimum_count}, {maximum_count}].")
        kernel_size = cfg.dynamic_token_boundary_kernel_size
        if not isinstance(kernel_size, int) or isinstance(kernel_size, bool):
            raise TypeError("dynamic_token_boundary_kernel_size must be an integer.")
        if kernel_size < 1 or kernel_size % 2 == 0:
            raise ValueError("dynamic_token_boundary_kernel_size must be a positive odd integer.")
        if (not isinstance(cfg.dynamic_token_boundary_hidden_size, int)
                or isinstance(cfg.dynamic_token_boundary_hidden_size, bool)):
            raise TypeError("dynamic_token_boundary_hidden_size must be an integer.")
        if cfg.dynamic_token_boundary_hidden_size < 1:
            raise ValueError("dynamic_token_boundary_hidden_size must be positive.")
        if cfg.dynamic_token_boundary_temperature <= 0.0:
            raise ValueError("dynamic_token_boundary_temperature must be positive.")
        unknown_sum_inputs = sorted(set(cfg.dynamic_token_sum_inputs) - set(cfg.dynamic_inputs_flattened))
        if unknown_sum_inputs:
            raise ValueError(f"dynamic_token_sum_inputs are not configured dynamic inputs: {unknown_sum_inputs}.")

    @staticmethod
    def _initialize_module(module: nn.Module):
        if isinstance(module, (nn.Linear, nn.Conv1d)):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, RMSNorm):
            nn.init.ones_(module.weight)

    @staticmethod
    def _derive_parameter_seed(base_seed: int, parameter_name: str) -> int:
        material = f"{int(base_seed)}\0{parameter_name}".encode("utf-8")
        return int.from_bytes(hashlib.sha256(material).digest()[:8], byteorder="big") % (2**63 - 1)

    @staticmethod
    def _normal_initialize(parameter: nn.Parameter, seed: int):
        generator = torch.Generator(device=parameter.device)
        generator.manual_seed(seed)
        with torch.no_grad():
            parameter.normal_(mean=0.0, std=0.02, generator=generator)

    def _initialize_named_parameters(self, base_seed: int):
        for module_name, module in self.named_modules():
            prefix = f"{module_name}." if module_name else ""
            if isinstance(module, (nn.Linear, nn.Conv1d)):
                self._normal_initialize(module.weight,
                                        self._derive_parameter_seed(base_seed, f"{prefix}weight"))
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
            elif isinstance(module, RMSNorm):
                nn.init.ones_(module.weight)

    def _restore_boundary_rate_bias(self):
        logit = math.log(self._initial_boundary_rate / (1.0 - self._initial_boundary_rate))
        nn.init.constant_(self.tokenizer.boundary_network.rate_projection.bias, logit)

    def parameter_counts(self) -> Dict[str, int]:
        return {"total_parameters": sum(parameter.numel() for parameter in self.parameters()),
                "boundary_parameters": sum(parameter.numel()
                                           for parameter in self.tokenizer.boundary_network.parameters())}

    def _forcing_inputs(self, data: dict[str, torch.Tensor | dict[str, torch.Tensor]]) -> torch.Tensor:
        dynamic_data = data["x_d"]
        if not isinstance(dynamic_data, dict):
            raise ValueError("Hydrologic dynamic tokens require dictionary-form x_d inputs.")
        return torch.cat([dynamic_data[name] for name in self.dynamic_input_names], dim=-1)

    @staticmethod
    def _static_inputs(data: dict[str, torch.Tensor | dict[str, torch.Tensor]],
                       reference: torch.Tensor) -> torch.Tensor:
        static_parts = []
        if "x_s" in data:
            static_parts.append(data["x_s"])
        if "x_one_hot" in data:
            static_parts.append(data["x_one_hot"])
        if not static_parts:
            return reference.new_zeros((reference.shape[0], 0))
        return torch.cat(static_parts, dim=-1)

    def forward(self, data: dict[str, torch.Tensor | dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        dynamic_embedding, static_embedding = self.embedding_net(data, concatenate_output=False)
        dynamic_embedding = dynamic_embedding.transpose(0, 1)
        if static_embedding is None:
            static_embedding = dynamic_embedding.new_zeros((dynamic_embedding.shape[0], 0))
        forcing_inputs = self._forcing_inputs(data)
        static_inputs = self._static_inputs(data, forcing_inputs)
        sum_inputs = forcing_inputs[:, :, self.sum_raw_indices] if self.sum_raw_indices else forcing_inputs.new_zeros(
            (*forcing_inputs.shape[:2], 0))
        pool_inputs = torch.cat((dynamic_embedding, forcing_inputs, sum_inputs), dim=-1)
        tokenized = self.tokenizer(forcing_inputs,
                                   static_inputs,
                                   pool_inputs=pool_inputs,
                                   pool_static_inputs=static_embedding)

        hidden = self.token_projection(tokenized.tokens)
        for block in self.blocks:
            hidden = block(hidden, tokenized.token_positions)
        hidden = self.final_norm(hidden)
        final_context = torch.einsum("bk,bkd->bd", tokenized.assignments[:, -1, :], hidden)
        prediction = self.head(self.output_dropout(final_context.unsqueeze(1)))

        count_loss = tokenized.count_loss
        if not self.training:
            count_loss = count_loss.reshape(1)
        active_lengths = tokenized.token_lengths * tokenized.token_mask.to(tokenized.token_lengths.dtype)
        prediction["dynamic_token_count_loss"] = count_loss
        prediction["dynamic_token_count"] = tokenized.token_count
        prediction["dynamic_token_boundaries"] = tokenized.hard_boundaries
        prediction["dynamic_token_boundary_rates"] = tokenized.boundary_rates
        prediction["dynamic_token_mean_length"] = active_lengths.sum(dim=-1) / tokenized.token_count.clamp_min(1)
        prediction["dynamic_token_max_length"] = active_lengths.max(dim=-1).values
        return prediction
