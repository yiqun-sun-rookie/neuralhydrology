"""Causal, differentiable variable-length tokenization for hydrological time series.

The forward pass uses hard, contiguous segments. A straight-through estimator keeps
the hard segmentation numerically unchanged while allowing downstream losses to
update the boundary-rate network.
"""

from dataclasses import dataclass
import math
from typing import Optional, Sequence

import torch
import torch.nn as nn
import torch.nn.functional as functional


@dataclass
class SegmentationOutput:
    """Outputs of :class:`StraightThroughSegmenter`."""

    assignments: torch.Tensor
    hard_assignments: torch.Tensor
    token_mask: torch.Tensor
    token_lengths: torch.Tensor
    hard_boundaries: torch.Tensor
    token_count: torch.Tensor
    count_loss: torch.Tensor


@dataclass
class TokenPoolOutput:
    """Pooled token features and their real elapsed-time coordinates."""

    tokens: torch.Tensor
    token_mask: torch.Tensor
    token_lengths: torch.Tensor
    token_positions: torch.Tensor
    token_end_positions: torch.Tensor


@dataclass
class HydrologicTokenOutput:
    """Complete learned-token output used by the Transformer and diagnostics."""

    boundary_rates: torch.Tensor
    assignments: torch.Tensor
    hard_assignments: torch.Tensor
    token_mask: torch.Tensor
    token_lengths: torch.Tensor
    token_positions: torch.Tensor
    token_end_positions: torch.Tensor
    hard_boundaries: torch.Tensor
    token_count: torch.Tensor
    count_loss: torch.Tensor
    tokens: torch.Tensor


class CausalBoundaryRateNetwork(nn.Module):
    """Predict a boundary accumulation rate using only present and past inputs."""

    def __init__(self,
                 dynamic_input_size: int,
                 static_input_size: int,
                 hidden_size: int,
                 num_layers: int,
                 kernel_size: int,
                 initial_rate: float = 0.125):
        super().__init__()
        if dynamic_input_size < 1:
            raise ValueError("dynamic_input_size must be positive.")
        if static_input_size < 0:
            raise ValueError("static_input_size must be non-negative.")
        if hidden_size < 1:
            raise ValueError("hidden_size must be positive.")
        if num_layers < 1:
            raise ValueError("num_layers must be positive.")
        if kernel_size < 1 or kernel_size % 2 == 0:
            raise ValueError("kernel_size must be a positive odd integer.")
        if not 0.0 < initial_rate < 1.0:
            raise ValueError("initial_rate must be strictly between zero and one.")

        self.kernel_size = kernel_size
        convolutions = []
        input_size = dynamic_input_size + static_input_size
        for _ in range(num_layers):
            convolutions.append(nn.Conv1d(input_size, hidden_size, kernel_size=kernel_size, padding=0))
            input_size = hidden_size
        self.convolutions = nn.ModuleList(convolutions)
        self.rate_projection = nn.Conv1d(hidden_size, 1, kernel_size=1)
        self.initial_rate = float(initial_rate)
        self.reset_parameters()

    def reset_parameters(self):
        for convolution in self.convolutions:
            nn.init.normal_(convolution.weight, mean=0.0, std=0.02)
            nn.init.zeros_(convolution.bias)
        nn.init.normal_(self.rate_projection.weight, mean=0.0, std=0.02)
        initial_logit = math.log(self.initial_rate / (1.0 - self.initial_rate))
        nn.init.constant_(self.rate_projection.bias, initial_logit)

    def forward(self, dynamic_inputs: torch.Tensor, static_inputs: Optional[torch.Tensor] = None) -> torch.Tensor:
        if dynamic_inputs.ndim != 3:
            raise ValueError("dynamic_inputs must have shape [batch, days, features].")
        batch_size, sequence_length, _ = dynamic_inputs.shape
        if static_inputs is None:
            combined = dynamic_inputs
        else:
            if static_inputs.ndim != 2 or static_inputs.shape[0] != batch_size:
                raise ValueError("static_inputs must have shape [batch, features].")
            expanded_static = static_inputs.unsqueeze(1).expand(-1, sequence_length, -1)
            combined = torch.cat((dynamic_inputs, expanded_static), dim=-1)

        hidden = combined.transpose(1, 2)
        for convolution in self.convolutions:
            # PyTorch's symmetric convolution padding would expose future days. Explicit left padding keeps every
            # boundary rate causal, including in deeper convolution stacks.
            hidden = functional.pad(hidden, (self.kernel_size - 1, 0))
            hidden = functional.silu(convolution(hidden))
        return torch.sigmoid(self.rate_projection(hidden)).squeeze(1)


class StraightThroughSegmenter(nn.Module):
    """Create hard contiguous tokens with a differentiable boundary path."""

    def __init__(self,
                 min_token_length: int,
                 max_token_length: int,
                 temperature: float,
                 target_token_count: Optional[int] = None):
        super().__init__()
        if (not isinstance(min_token_length, int) or isinstance(min_token_length, bool)
                or not isinstance(max_token_length, int) or isinstance(max_token_length, bool)):
            raise TypeError("Token lengths must be integers.")
        if min_token_length < 1:
            raise ValueError("min_token_length must be at least one.")
        if max_token_length < min_token_length:
            raise ValueError("max_token_length must be at least min_token_length.")
        if temperature <= 0.0:
            raise ValueError("temperature must be positive.")
        if target_token_count is not None:
            if not isinstance(target_token_count, int) or isinstance(target_token_count, bool):
                raise TypeError("target_token_count must be an integer when supplied.")
            if target_token_count < 1:
                raise ValueError("target_token_count must be positive when supplied.")
        self.min_token_length = int(min_token_length)
        self.max_token_length = int(max_token_length)
        self.temperature = float(temperature)
        self.target_token_count = target_token_count

    @staticmethod
    def _assignment_from_starts(starts: Sequence[torch.Tensor], max_tokens: int) -> torch.Tensor:
        batch_size = starts[0].shape[0]
        first = starts[0].new_zeros((batch_size, max_tokens))
        first[:, 0] = 1.0
        rows = [first]
        for start in starts[1:]:
            previous = rows[-1]
            shifted = functional.pad(previous[:, :-1], (1, 0))
            rows.append(previous * (1.0 - start.unsqueeze(-1)) + shifted * start.unsqueeze(-1))
        return torch.stack(rows, dim=1)

    def _fixed(self, boundary_rates: torch.Tensor, fixed_token_length: int) -> SegmentationOutput:
        if not isinstance(fixed_token_length, int) or isinstance(fixed_token_length, bool):
            raise TypeError("fixed_token_length must be an integer.")
        if not self.min_token_length <= fixed_token_length <= self.max_token_length:
            raise ValueError("fixed_token_length must be within the configured token-length bounds.")
        batch_size, sequence_length = boundary_rates.shape
        max_tokens = math.ceil(sequence_length / self.min_token_length)
        day_indices = torch.arange(sequence_length, device=boundary_rates.device)
        hard_boundaries = (day_indices % fixed_token_length == 0).unsqueeze(0).expand(batch_size, -1)
        hard_starts = [hard_boundaries[:, index].to(boundary_rates.dtype) for index in range(sequence_length)]
        hard_assignments = self._assignment_from_starts(hard_starts, max_tokens)
        token_lengths = hard_assignments.sum(dim=1)
        token_mask = token_lengths > 0.0
        token_count = token_mask.sum(dim=-1)
        count_loss = boundary_rates.new_zeros(())
        return SegmentationOutput(assignments=hard_assignments,
                                  hard_assignments=hard_assignments,
                                  token_mask=token_mask,
                                  token_lengths=token_lengths,
                                  hard_boundaries=hard_boundaries,
                                  token_count=token_count,
                                  count_loss=count_loss)

    def forward(self, boundary_rates: torch.Tensor, fixed_token_length: Optional[int] = None) -> SegmentationOutput:
        if boundary_rates.ndim != 2:
            raise ValueError("boundary_rates must have shape [batch, days].")
        if boundary_rates.shape[1] < 1:
            raise ValueError("boundary_rates must contain at least one day.")
        if fixed_token_length is not None:
            return self._fixed(boundary_rates, fixed_token_length)

        batch_size, sequence_length = boundary_rates.shape
        max_tokens = math.ceil(sequence_length / self.min_token_length)
        hard_first = torch.ones(batch_size, dtype=torch.bool, device=boundary_rates.device)
        straight_through_starts = [hard_first.to(boundary_rates.dtype)]
        hard_starts = [hard_first]
        accumulated_rate = boundary_rates.new_zeros(batch_size)
        hard_age = torch.ones(batch_size, dtype=torch.long, device=boundary_rates.device)

        for day_index in range(1, sequence_length):
            candidate_rate = accumulated_rate + boundary_rates[:, day_index]
            can_split = hard_age >= self.min_token_length
            must_split = hard_age >= self.max_token_length
            hard_crossing = candidate_rate >= 1.0
            hard_start = must_split | (can_split & hard_crossing)
            trainable_crossing = can_split & ~must_split
            soft_start = torch.sigmoid((candidate_rate - 1.0) / self.temperature)
            straight_through_start = hard_start.to(boundary_rates.dtype)
            straight_through_start = straight_through_start + trainable_crossing.to(boundary_rates.dtype) * (
                soft_start - soft_start.detach())

            straight_through_starts.append(straight_through_start)
            hard_starts.append(hard_start)
            accumulated_rate = (1.0 - straight_through_start) * candidate_rate
            hard_age = torch.where(hard_start, torch.ones_like(hard_age), hard_age + 1)

        assignments = self._assignment_from_starts(straight_through_starts, max_tokens)
        hard_start_tensor = torch.stack(hard_starts, dim=1)
        hard_start_values = [start.to(boundary_rates.dtype) for start in hard_starts]
        hard_assignments = self._assignment_from_starts(hard_start_values, max_tokens)
        token_lengths = hard_assignments.sum(dim=1)
        token_mask = token_lengths > 0.0
        token_count = token_mask.sum(dim=-1)
        if self.target_token_count is None:
            count_loss = boundary_rates.new_zeros(())
        else:
            differentiable_count = torch.stack(straight_through_starts, dim=1).sum(dim=1)
            normalizer = float(self.target_token_count)
            count_loss = torch.mean(((differentiable_count - normalizer) / normalizer)**2)
        return SegmentationOutput(assignments=assignments,
                                  hard_assignments=hard_assignments,
                                  token_mask=token_mask,
                                  token_lengths=token_lengths,
                                  hard_boundaries=hard_start_tensor,
                                  token_count=token_count,
                                  count_loss=count_loss)


class ConservativeTokenPooler(nn.Module):
    """Pool daily values while preserving configured sums in standardized model-input space."""

    def __init__(self, sum_input_indices: Sequence[int] = ()):
        super().__init__()
        self.sum_input_indices = tuple(int(index) for index in sum_input_indices)
        if any(index < 0 for index in self.sum_input_indices):
            raise ValueError("sum_input_indices must be non-negative.")

    def forward(self,
                inputs: torch.Tensor,
                segmentation: SegmentationOutput,
                static_inputs: Optional[torch.Tensor] = None) -> TokenPoolOutput:
        if inputs.ndim != 3:
            raise ValueError("inputs must have shape [batch, days, features].")
        if inputs.shape[:2] != segmentation.assignments.shape[:2]:
            raise ValueError("inputs and assignments must share batch and day dimensions.")
        if any(index >= inputs.shape[-1] for index in self.sum_input_indices):
            raise ValueError("sum_input_indices contains an index outside the input feature dimension.")

        assignments = segmentation.assignments
        token_sums = torch.einsum("btk,btf->bkf", assignments, inputs)
        differentiable_lengths = assignments.sum(dim=1)
        denominator = differentiable_lengths.clamp_min(1.0).unsqueeze(-1)
        token_means = token_sums / denominator
        if self.sum_input_indices:
            extensive_mask = torch.zeros(inputs.shape[-1], dtype=inputs.dtype, device=inputs.device)
            extensive_mask[list(self.sum_input_indices)] = 1.0
            pooled_values = token_means * (1.0 - extensive_mask) + token_sums * extensive_mask
        else:
            pooled_values = token_means

        day_positions = torch.arange(inputs.shape[1], dtype=inputs.dtype, device=inputs.device)
        centers = torch.einsum("btk,t->bk", assignments, day_positions) / differentiable_lengths.clamp_min(1.0)
        hard_activity = segmentation.token_mask.to(inputs.dtype)
        soft_activity = 1.0 - torch.exp(-differentiable_lengths)
        activity = hard_activity + soft_activity - soft_activity.detach()
        end_positions = centers + 0.5 * (differentiable_lengths - activity)
        scale = float(max(inputs.shape[1] - 1, 1))
        metadata = torch.stack((differentiable_lengths / float(inputs.shape[1]), centers / scale,
                                end_positions / scale),
                               dim=-1)
        token_parts = [pooled_values, metadata]
        if static_inputs is not None:
            if static_inputs.ndim != 2 or static_inputs.shape[0] != inputs.shape[0]:
                raise ValueError("static_inputs must have shape [batch, features].")
            expanded_static = static_inputs.unsqueeze(1).expand(-1, assignments.shape[-1], -1)
            token_parts.append(expanded_static * activity.unsqueeze(-1))
        tokens = torch.cat(token_parts, dim=-1)
        # Pooled values are already exactly zero in inactive slots. Leaving them unmasked preserves the assignment
        # partition identity in both passes: an extensive sum across all token slots is boundary-invariant and has
        # zero boundary gradient, while a currently empty next slot still carries a hypothetical activation gradient.
        return TokenPoolOutput(tokens=tokens,
                               token_mask=segmentation.token_mask,
                               token_lengths=segmentation.token_lengths,
                               token_positions=centers,
                               token_end_positions=end_positions)


class HydrologicDynamicTokenizer(nn.Module):
    """Combine causal boundary scoring, hard segmentation, and conservative pooling."""

    def __init__(self,
                 dynamic_input_size: int,
                 static_input_size: int,
                 hidden_size: int,
                 num_rate_layers: int,
                 rate_kernel_size: int,
                 min_token_length: int,
                 max_token_length: int,
                 temperature: float,
                 sum_input_indices: Sequence[int] = (),
                 target_token_count: Optional[int] = None,
                 mode: str = "learned",
                 fixed_token_length: Optional[int] = None,
                 detach_boundary_gradient: bool = False,
                 initial_rate: Optional[float] = None):
        super().__init__()
        mode = mode.lower()
        if mode not in {"learned", "fixed"}:
            raise ValueError("mode must be either 'learned' or 'fixed'.")
        if mode == "fixed" and fixed_token_length is None:
            raise ValueError("fixed_token_length is required in fixed mode.")
        if initial_rate is None:
            initial_rate = 1.0 / float(fixed_token_length or max_token_length)
        # A one-day fixed control ignores learned rates, but its matched boundary network still requires a finite
        # sigmoid logit for deterministic initialization.
        initial_rate = min(float(initial_rate), 1.0 - 1e-6)
        self.mode = mode
        self.fixed_token_length = fixed_token_length
        self.detach_boundary_gradient = bool(detach_boundary_gradient)
        self.boundary_network = CausalBoundaryRateNetwork(dynamic_input_size=dynamic_input_size,
                                                          static_input_size=static_input_size,
                                                          hidden_size=hidden_size,
                                                          num_layers=num_rate_layers,
                                                          kernel_size=rate_kernel_size,
                                                          initial_rate=initial_rate)
        self.segmenter = StraightThroughSegmenter(min_token_length=min_token_length,
                                                  max_token_length=max_token_length,
                                                  temperature=temperature,
                                                  target_token_count=target_token_count)
        self.pooler = ConservativeTokenPooler(sum_input_indices=sum_input_indices)

    def forward(self,
                dynamic_inputs: torch.Tensor,
                static_inputs: Optional[torch.Tensor] = None,
                pool_inputs: Optional[torch.Tensor] = None,
                pool_static_inputs: Optional[torch.Tensor] = None) -> HydrologicTokenOutput:
        boundary_rates = self.boundary_network(dynamic_inputs, static_inputs)
        if self.mode == "fixed":
            segmentation = self.segmenter(boundary_rates, fixed_token_length=self.fixed_token_length)
            count_loss = segmentation.count_loss
        else:
            count_segmentation = self.segmenter(boundary_rates)
            count_loss = count_segmentation.count_loss
            # The detached control removes only the discharge-loss path. Its boundary network can still learn the
            # preregistered token-count constraint, which keeps it a meaningful control rather than a frozen random
            # segmentation. Running the lightweight segmenter twice preserves identical hard forward boundaries.
            segmentation = self.segmenter(boundary_rates.detach()) if self.detach_boundary_gradient else count_segmentation
        if pool_inputs is None:
            pool_inputs = dynamic_inputs
        if pool_static_inputs is None:
            pool_static_inputs = static_inputs
        pooled = self.pooler(pool_inputs, segmentation, static_inputs=pool_static_inputs)
        return HydrologicTokenOutput(boundary_rates=boundary_rates,
                                     assignments=segmentation.assignments,
                                     hard_assignments=segmentation.hard_assignments,
                                     token_mask=pooled.token_mask,
                                     token_lengths=pooled.token_lengths,
                                     token_positions=pooled.token_positions,
                                     token_end_positions=pooled.token_end_positions,
                                     hard_boundaries=segmentation.hard_boundaries,
                                     token_count=segmentation.token_count,
                                     count_loss=count_loss,
                                     tokens=pooled.tokens)
