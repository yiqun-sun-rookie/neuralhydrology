"""Static, data-free audit for the hydrologic dynamic-token experiment family."""

from __future__ import annotations

import csv
import hashlib
from pathlib import Path
from typing import Any

from ruamel.yaml import YAML


REPO_ROOT = Path(__file__).resolve().parents[3]
IDEA_DIR = Path("src/hydrologic_dynamic_tokens")
CONFIG_DIR = IDEA_DIR / "configs"
REGISTRY_PATH = IDEA_DIR / "registry/experiments.csv"
BASE_CONFIG_FILE = "base_development.yml"
RUN_CONFIG_FILES = (
    "fixed_04_s100.yml",
    "fixed_08_s100.yml",
    "fixed_16_s100.yml",
    "learned_detached_s100.yml",
    "learned_end_to_end_s100.yml",
)
EXPECTED_REGISTRY_IDS = ["DT00", "DT04", "DT08", "DT16", "DR01", "DL00", "DL01"]
REGISTRY_COLUMNS = [
    "experiment_id",
    "treatment",
    "hypothesis",
    "changed_factor",
    "fixed_factors",
    "seed",
    "config_path",
    "config_sha256",
    "run_dir",
    "status",
    "source_artifact",
    "source_artifact_sha256",
    "validation_median_nse",
    "notes",
]
FORBIDDEN_TEXT = (
    "usgs_streamflow",
    "camels_hydro",
    "_obs_eval.parquet",
    "obs_eval.parquet",
    "mixture_of_experts",
    "moe_router",
    "transformer_moe",
)
SEALED_DATE_TOKENS = {str(year) for year in range(1989, 1999)}
SEALED_DATE_STRINGS = tuple(
    date
    for year in range(1989, 1999)
    for date in (str(year), f"01/10/{year}", f"30/09/{year}")
)
BASE_INHERITED_FIELDS = (
    "dataset",
    "data_dir",
    "track0_supervision_dir",
    "number_of_basins",
    "train_basin_file",
    "validation_basin_file",
    "train_start_date",
    "train_end_date",
    "validation_start_date",
    "validation_end_date",
    "device",
    "head",
    "output_activation",
    "loss",
    "epochs",
    "seq_length",
    "predict_last_n",
    "clip_gradient_norm",
    "seed",
    "forcings",
    "dynamic_inputs",
    "target_variables",
    "static_attributes",
    "validate_every",
    "validate_n_random_basins",
    "cache_validation_data",
    "metrics",
    "num_workers",
    "log_interval",
    "log_tensorboard",
    "log_n_figures",
    "save_weights_every",
    "save_validation_results",
    "save_all_output",
    "save_train_data",
)

COMMON_CONTRACT = {
    "dataset": "camels_us_track0_bundle",
    "data_dir": "data/camels_us_track0_development_forcing_v01",
    "track0_supervision_dir": "data/camels_us_track0_supervision_v01",
    "number_of_basins": 531,
    "train_basin_file": "src/fair_benchmark/frozen/track0_forcing_only_basins.txt",
    "validation_basin_file": "src/fair_benchmark/frozen/track0_forcing_only_basins.txt",
    "train_start_date": "01/10/1999",
    "train_end_date": "30/09/2006",
    "validation_start_date": "01/10/2006",
    "validation_end_date": "30/09/2008",
    "device": "cuda:0",
    "model": "hydrologic_dynamic_token_transformer",
    "head": "regression",
    "output_dropout": 0.0,
    "output_activation": "linear",
    "transformer_nheads": 4,
    "transformer_nlayers": 4,
    "transformer_dim_feedforward": 512,
    "transformer_dropout": 0.1,
    "optimizer": "AdamW",
    "loss": "NSE",
    "learning_rate": {0: 3e-4, 11: 1e-4, 21: 3e-5},
    "batch_size": 64,
    "epochs": 30,
    "seq_length": 270,
    "predict_last_n": 1,
    "clip_gradient_norm": 1.0,
    "seed": 100,
    "forcings": ["maurer"],
    "dynamic_inputs": ["PRCP(mm/day)", "Tmin(C)", "Tmax(C)", "SRAD(W/m2)", "Vp(Pa)"],
    "target_variables": ["QObs(mm/d)"],
    "validate_every": 1,
    "validate_n_random_basins": 531,
    "cache_validation_data": True,
    "metrics": ["NSE"],
    "num_workers": 4,
    "log_interval": 5,
    "log_tensorboard": False,
    "log_n_figures": 0,
    "save_weights_every": 10,
    "save_validation_results": True,
    "save_all_output": False,
    "save_train_data": False,
}


def load_yaml(path: Path) -> dict[str, Any]:
    yaml = YAML(typ="safe")
    value = yaml.load(path)
    if not isinstance(value, dict):
        raise ValueError(f"configuration must be a mapping: {path}")
    return value


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def embedding_width(config: dict[str, Any]) -> int:
    dynamic_width = int(config["dynamics_embedding"]["hiddens"][-1])
    static_width = int(config["statics_embedding"]["hiddens"][-1])
    return dynamic_width + static_width


def unexpected_pair_differences(
    left: dict[str, Any], right: dict[str, Any], allowed: set[str]
) -> dict[str, tuple[Any, Any]]:
    differences: dict[str, tuple[Any, Any]] = {}
    for key in sorted(set(left) | set(right)):
        if key not in allowed and left.get(key) != right.get(key):
            differences[key] = (left.get(key), right.get(key))
    return differences


def _audit_text(path: Path) -> list[str]:
    issues: list[str] = []
    text = path.read_text(encoding="utf-8").lower()
    for forbidden in FORBIDDEN_TEXT:
        if forbidden in text:
            issues.append(f"{path.name}: forbidden Track-0 or mixture-of-experts text {forbidden!r}")
    for date in SEALED_DATE_STRINGS:
        if date in text:
            issues.append(f"{path.name}: sealed evaluation date token {date!r}")
    return issues


def _audit_common_config(filename: str, config: dict[str, Any]) -> list[str]:
    issues: list[str] = []
    for key, expected in COMMON_CONTRACT.items():
        if config.get(key) != expected:
            issues.append(f"{filename}: {key}={config.get(key)!r}, expected {expected!r}")
    if len(config.get("static_attributes", [])) != 27:
        issues.append(f"{filename}: exactly 27 static attributes are required")
    if embedding_width(config) != 128:
        issues.append(f"{filename}: total input embedding width must be 128")
    if config.get("dynamic_token_sum_inputs") != ["PRCP(mm/day)"]:
        issues.append(f"{filename}: standardized precipitation must be the sole summed model input")
    if config.get("dynamic_token_min_length") != 2:
        issues.append(f"{filename}: dynamic_token_min_length must be 2")
    if config.get("dynamic_token_max_length") != 30:
        issues.append(f"{filename}: dynamic_token_max_length must be 30")
    if config.get("dynamic_token_target_count") != 34:
        issues.append(f"{filename}: dynamic_token_target_count must be 34")
    if config.get("dynamic_token_boundary_hidden_size") != 64:
        issues.append(f"{filename}: boundary hidden size must be 64")
    if config.get("dynamic_token_boundary_kernel_size") != 15:
        issues.append(f"{filename}: boundary convolution kernel must be 15")
    if config.get("dynamic_token_boundary_temperature") != 0.25:
        issues.append(f"{filename}: straight-through temperature must be 0.25")
    return issues


def _audit_candidate_configs(configs: dict[str, dict[str, Any]]) -> list[str]:
    issues: list[str] = []
    expected_fixed = {
        "fixed_04_s100.yml": 4,
        "fixed_08_s100.yml": 8,
        "fixed_16_s100.yml": 16,
    }
    fixed_reference = configs["fixed_04_s100.yml"]
    for filename, length in expected_fixed.items():
        config = configs[filename]
        if config.get("dynamic_token_mode") != "fixed":
            issues.append(f"{filename}: dynamic_token_mode must be fixed")
        if config.get("dynamic_token_fixed_length") != length:
            issues.append(f"{filename}: fixed token length must be {length}")
        if config.get("dynamic_token_detach_boundary_gradient") is not False:
            issues.append(f"{filename}: unused boundary detachment sentinel must be false")
        if config.get("regularization") != []:
            issues.append(f"{filename}: fixed controls must not use token-count regularization")
        drift = unexpected_pair_differences(
            fixed_reference,
            config,
            allowed={"experiment_name", "run_dir", "dynamic_token_fixed_length"},
        )
        if drift:
            issues.append(f"{filename}: unintended fixed-control differences {sorted(drift)}")

    detached = configs["learned_detached_s100.yml"]
    end_to_end = configs["learned_end_to_end_s100.yml"]
    for filename, config, detach in (
        ("learned_detached_s100.yml", detached, True),
        ("learned_end_to_end_s100.yml", end_to_end, False),
    ):
        if config.get("dynamic_token_mode") != "learned":
            issues.append(f"{filename}: dynamic_token_mode must be learned")
        if config.get("dynamic_token_fixed_length") != 8:
            issues.append(f"{filename}: fixed-length sentinel/initialization reference must be 8")
        if config.get("dynamic_token_detach_boundary_gradient") is not detach:
            issues.append(f"{filename}: boundary-gradient detachment must be {detach}")
        if config.get("regularization") != [["dynamic_token_count", 0.01]]:
            issues.append(f"{filename}: count regularization must be fixed at weight 0.01")
    drift = unexpected_pair_differences(
        detached,
        end_to_end,
        allowed={"experiment_name", "run_dir", "dynamic_token_detach_boundary_gradient"},
    )
    if drift:
        issues.append(f"learned pair has unintended differences {sorted(drift)}")
    fixed_learned_drift = unexpected_pair_differences(
        configs["fixed_08_s100.yml"],
        end_to_end,
        allowed={
            "experiment_name",
            "run_dir",
            "dynamic_token_mode",
            "dynamic_token_detach_boundary_gradient",
            "regularization",
        },
    )
    if fixed_learned_drift:
        issues.append(
            "DL01 and DT08 have unintended non-treatment differences "
            f"{sorted(fixed_learned_drift)}"
        )
    return issues


def _audit_registry(path: Path, repo_root: Path) -> list[str]:
    issues: list[str] = []
    with path.open("r", encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        rows = list(reader)
        if reader.fieldnames != REGISTRY_COLUMNS:
            issues.append(f"registry columns are {reader.fieldnames!r}, expected {REGISTRY_COLUMNS!r}")
            return issues
    ids = [row.get("experiment_id", "") for row in rows]
    if ids != EXPECTED_REGISTRY_IDS:
        issues.append(f"registry identifiers are {ids!r}, expected {EXPECTED_REGISTRY_IDS!r}")
        return issues
    if len({row["run_dir"] for row in rows}) != len(rows):
        issues.append("registry run directories must be unique")
    by_id = {row["experiment_id"]: row for row in rows}
    expected_paths = {
        "DT04": "src/hydrologic_dynamic_tokens/configs/fixed_04_s100.yml",
        "DT08": "src/hydrologic_dynamic_tokens/configs/fixed_08_s100.yml",
        "DT16": "src/hydrologic_dynamic_tokens/configs/fixed_16_s100.yml",
        "DL00": "src/hydrologic_dynamic_tokens/configs/learned_detached_s100.yml",
        "DL01": "src/hydrologic_dynamic_tokens/configs/learned_end_to_end_s100.yml",
    }
    for experiment_id, relative_path in expected_paths.items():
        row = by_id[experiment_id]
        if row["config_path"] != relative_path:
            issues.append(f"{experiment_id}: config_path must be {relative_path}")
            continue
        config_path = repo_root / relative_path
        if not config_path.is_file():
            issues.append(f"{experiment_id}: registered configuration does not exist")
        elif row["config_sha256"] != sha256_file(config_path):
            issues.append(f"{experiment_id}: configuration SHA-256 mismatch")
        if row["seed"] != "100" or row["status"] != "planned":
            issues.append(f"{experiment_id}: must remain a seed-100 planned experiment")
        if row["validation_median_nse"] != "not_run":
            issues.append(f"{experiment_id}: cannot claim a validation result before training")
    if by_id["DR01"]["config_path"] != "not_materialized":
        issues.append("DR01: rule-boundary control must not have a materialized configuration yet")
    if by_id["DR01"]["status"] != "planned_not_materialized":
        issues.append("DR01: status must be planned_not_materialized")
    if by_id["DT00"]["status"] != "external_control_pending_artifact_binding":
        issues.append("DT00: the ID30 daily-token control is not locally artifact-bound")
    return issues


def audit_repository(repo_root: Path = REPO_ROOT) -> list[str]:
    issues: list[str] = []
    idea_dir = repo_root / IDEA_DIR
    expected_files = {BASE_CONFIG_FILE, *RUN_CONFIG_FILES}
    actual_files = {path.name for path in (idea_dir / "configs").glob("*.yml")}
    if actual_files != expected_files:
        issues.append(f"configuration files are {sorted(actual_files)!r}, expected {sorted(expected_files)!r}")
        return issues

    configs: dict[str, dict[str, Any]] = {}
    for filename in RUN_CONFIG_FILES:
        path = idea_dir / "configs" / filename
        issues.extend(_audit_text(path))
        try:
            config = load_yaml(path)
        except (OSError, ValueError) as error:
            issues.append(f"{filename}: cannot load YAML: {error}")
            continue
        configs[filename] = config
        issues.extend(_audit_common_config(filename, config))
    base_path = idea_dir / "configs" / BASE_CONFIG_FILE
    issues.extend(_audit_text(base_path))
    source_base_path = repo_root / "src/modern_transformer_moe/configs/base_development.yml"
    if source_base_path.is_file():
        base_config = load_yaml(base_path)
        source_base = load_yaml(source_base_path)
        for key in BASE_INHERITED_FIELDS:
            if base_config.get(key) != source_base.get(key):
                issues.append(f"base_development.yml: inherited ID30 field {key!r} drifted")
    else:
        issues.append("the ID30 base development reference is missing")
    if set(configs) == set(RUN_CONFIG_FILES):
        issues.extend(_audit_candidate_configs(configs))

    registry_path = repo_root / REGISTRY_PATH
    if not registry_path.is_file():
        issues.append("experiment registry is missing")
    else:
        issues.extend(_audit_registry(registry_path, repo_root))
    return issues


def main() -> int:
    issues = audit_repository()
    if issues:
        print("ID31 STATIC CONFIG AUDIT: FAIL")
        for issue in issues:
            print(f"- {issue}")
        return 1
    print("ID31 STATIC CONFIG AUDIT: PASS (five planned runs; no data read; no training launched)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
