"""Audit the ID31 synthetic one-update smoke and write the final report."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import torch
from ruamel.yaml import YAML


REPO_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_REPORT_DIR = REPO_ROOT / "results" / "31_hydrologic_dynamic_tokens" / "_reports"
DEFAULT_RUN_EVIDENCE = DEFAULT_REPORT_DIR / "smoke_run.json"
DEFAULT_REPORT = DEFAULT_REPORT_DIR / "smoke_report.json"
EXPECTED_FIXED_BOUNDARIES = list(range(0, 270, 8))
EXPECTED_FIXED_LENGTHS = [8] * 33 + [6]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _relative(path: Path) -> str:
    try:
        return path.resolve().relative_to(REPO_ROOT.resolve()).as_posix()
    except ValueError:
        return str(path.resolve())


def _repo_path(value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else REPO_ROOT / path


def _load_yaml(path: Path) -> dict[str, Any]:
    yaml = YAML(typ="safe")
    with path.open("r", encoding="utf-8") as stream:
        value = yaml.load(stream)
    if not isinstance(value, dict):
        raise ValueError(f"Configuration must be a mapping: {path}")
    return value


def _load_state(path: Path) -> dict[str, torch.Tensor]:
    try:
        return torch.load(path, map_location="cpu", weights_only=True)
    except TypeError:
        return torch.load(path, map_location="cpu")


def _checkpoint_audit(run: dict[str, Any]) -> dict[str, Any]:
    reload_evidence = run["checkpoint_reload"]
    path = _repo_path(reload_evidence["checkpoint_path"])
    present = path.is_file()
    current_hash = _sha256(path) if present else None
    expected_hash = reload_evidence["checkpoint_sha256"]
    finite = False
    tensor_count = 0
    if present:
        state = _load_state(path)
        tensor_count = len(state)
        finite = bool(state) and all(bool(torch.isfinite(tensor).all().item()) for tensor in state.values())
    return {
        "path": _relative(path),
        "present": present,
        "manifest_sha256": expected_hash,
        "current_sha256": current_hash,
        "sha256_matches": present and current_hash == expected_hash,
        "tensor_count": tensor_count,
        "all_tensors_finite": finite,
    }


def _common_run_gates(run: dict[str, Any], checkpoint: dict[str, Any]) -> dict[str, bool]:
    batch = run["synthetic_batch"]
    loss = run["loss"]
    optimizer = run["optimizer_step"]
    forward = run["forward"]
    reload_evidence = run["checkpoint_reload"]
    resources = run["resources"]
    components = loss["components"]
    return {
        "synthetic_batch_is_4_by_270": batch["batch_size"] == 4 and batch["sequence_length_days"] == 270,
        "five_dynamic_inputs": (
            batch["dynamic_input_count"] == 5
            and all(shape == [4, 270, 1] for shape in batch["dynamic_input_shapes"].values())
        ),
        "twenty_seven_static_attributes": (
            batch["static_attribute_count"] == 27 and batch["static_shape"] == [4, 27]
        ),
        "target_and_basin_stds_present": (
            batch["target_shape"] == [4, 270, 1]
            and batch["per_basin_target_stds_shape"] == [4, 1, 1]
        ),
        "nse_and_total_loss_finite": (
            loss["total_finite"]
            and "loss" in components
            and "total_loss" in components
            and all(math.isfinite(value) for value in components.values())
        ),
        "prediction_shape_is_final_day": forward["prediction_shape"] == [4, 1, 1],
        "forward_outputs_finite": (
            forward["all_output_tensors_finite"] and forward["post_step_all_output_tensors_finite"]
        ),
        "all_present_gradients_finite": run["gradients"]["all_present_gradients_finite"],
        "adamw_completed_exactly_one_step": (
            optimizer["class"] == "AdamW" and optimizer["completed_steps"] == 1
        ),
        "optimizer_changed_parameters": (
            optimizer["changed_parameter_tensor_count"] > 0
            and optimizer["maximum_absolute_parameter_delta"] > 0.0
        ),
        "parameters_finite_after_step": optimizer["parameters_all_finite_after_step"],
        "parameter_count_positive": run["parameter_counts"]["total_parameters"] > 0,
        "checkpoint_present_and_hash_bound": checkpoint["present"] and checkpoint["sha256_matches"],
        "checkpoint_tensors_finite": checkpoint["all_tensors_finite"],
        "strict_reload_reproduces_prediction": (
            reload_evidence["strict_load"]
            and reload_evidence["prediction_shape"] == [4, 1, 1]
            and reload_evidence["prediction_allclose_at_1e_minus_7"]
            and reload_evidence["prediction_maximum_absolute_difference"] <= 1e-7
            and reload_evidence["reloaded_outputs_all_finite"]
        ),
        "strict_reload_reproduces_segmentation": (
            reload_evidence["boundaries_identical"] and reload_evidence["token_counts_identical"]
        ),
        "positive_measured_runtime": (
            resources["forward_and_loss_seconds"] > 0.0
            and resources["backward_and_adamw_step_seconds"] > 0.0
            and resources["reload_pair_forward_seconds"] > 0.0
            and resources["total_wall_seconds"] > 0.0
        ),
    }


def _segment_lengths_valid(lengths: list[int], minimum: int, maximum: int) -> bool:
    if not lengths or any(length < 1 or length > maximum for length in lengths):
        return False
    # The final, right-censored segment may be shorter than the configured minimum.
    return all(length >= minimum for length in lengths[:-1])


def audit(run_evidence_path: Path) -> dict[str, Any]:
    evidence = json.loads(run_evidence_path.read_text(encoding="utf-8"))
    if evidence.get("schema_version") != 1:
        raise ValueError("Unsupported or missing smoke-run evidence schema.")
    if set(evidence.get("runs", {})) != {"fixed_08", "learned_end_to_end"}:
        raise ValueError("Smoke evidence must contain exactly fixed_08 and learned_end_to_end runs.")

    source_audit = {
        "run_evidence_path": _relative(run_evidence_path),
        "run_evidence_sha256": _sha256(run_evidence_path),
        "run_smoke_path": evidence["source"]["run_smoke_path"],
        "run_smoke_manifest_sha256": evidence["source"]["run_smoke_sha256"],
        "run_smoke_current_sha256": _sha256(_repo_path(evidence["source"]["run_smoke_path"])),
        "audit_smoke_path": _relative(Path(__file__)),
        "audit_smoke_sha256": _sha256(Path(__file__)),
    }
    source_audit["run_smoke_unchanged_since_execution"] = (
        source_audit["run_smoke_manifest_sha256"] == source_audit["run_smoke_current_sha256"]
    )
    implementation_files = evidence["source"].get("implementation_files", {})
    source_audit["implementation_files"] = {
        path: {
            "manifest_sha256": manifest_hash,
            "current_sha256": _sha256(_repo_path(path)),
            "matches": manifest_hash == _sha256(_repo_path(path)),
        }
        for path, manifest_hash in implementation_files.items()
    }
    source_audit["implementation_files_present"] = len(implementation_files) == 6
    source_audit["implementation_unchanged_since_execution"] = (
        source_audit["implementation_files_present"]
        and all(item["matches"] for item in source_audit["implementation_files"].values())
    )

    audited_runs: dict[str, Any] = {}
    for label, run in evidence["runs"].items():
        config_path = _repo_path(run["config"]["path"])
        config = _load_yaml(config_path)
        config_hash = _sha256(config_path)
        checkpoint = _checkpoint_audit(run)
        gates = _common_run_gates(run, checkpoint)
        gates.update({
            "configuration_present_and_hash_bound": (
                config_path.is_file() and config_hash == run["config"]["sha256"]
            ),
            "full_configuration_uses_nse_and_adamw": (
                config.get("loss") == "NSE" and config.get("optimizer") == "AdamW"
            ),
            "resource_measurement_matches_device": (
                (evidence["environment"]["cuda_used"] and run["resources"]["peak_cuda_memory_bytes"] is not None
                 and run["resources"]["peak_cuda_memory_bytes"] > 0)
                or (not evidence["environment"]["cuda_used"]
                    and run["resources"]["device"] == "cpu"
                    and run["resources"]["peak_cuda_memory_bytes"] is None)
            ),
        })
        audited_runs[label] = {
            "status": "PASS" if all(gates.values()) else "FAIL",
            "config_path": _relative(config_path),
            "config_sha256": config_hash,
            "checkpoint": checkpoint,
            "evidence": run,
            "gates": gates,
        }

    fixed = audited_runs["fixed_08"]
    fixed_segmentation = fixed["evidence"]["segmentation_after_step"]
    fixed_specific = {
        "fixed_mode_and_length_eight": (
            fixed["evidence"]["config"]["mode"] == "fixed"
            and fixed_segmentation["fixed_length"] == 8
        ),
        "fixed_token_count_is_ceil_270_over_8": fixed_segmentation["token_counts"] == [34] * 4,
        "fixed_boundary_indices_exact": (
            fixed_segmentation["boundary_indices"] == [EXPECTED_FIXED_BOUNDARIES] * 4
        ),
        "fixed_segment_lengths_exact": fixed_segmentation["segment_lengths"] == [EXPECTED_FIXED_LENGTHS] * 4,
        "fixed_first_day_is_boundary": all(fixed_segmentation["first_day_is_boundary"]),
    }
    fixed["gates"].update(fixed_specific)
    fixed["status"] = "PASS" if all(fixed["gates"].values()) else "FAIL"

    learned = audited_runs["learned_end_to_end"]
    learned_segmentation = learned["evidence"]["segmentation_after_step"]
    learned_gradient = learned["evidence"]["gradients"]["boundary_network"]
    learned_counts_match = all(count == len(indices) == len(lengths)
                               for count, indices, lengths in zip(learned_segmentation["token_counts"],
                                                                  learned_segmentation["boundary_indices"],
                                                                  learned_segmentation["segment_lengths"]))
    learned_lengths_valid = all(
        _segment_lengths_valid(lengths, learned_segmentation["minimum_length"],
                               learned_segmentation["maximum_length"])
        for lengths in learned_segmentation["segment_lengths"]
    )
    learned_specific = {
        "learned_end_to_end_configuration": (
            learned["evidence"]["config"]["mode"] == "learned"
            and not learned["evidence"]["config"]["detach_boundary_gradient"]
        ),
        "configured_count_regularization_was_applied": (
            learned["evidence"]["config"]["regularization"] == [["dynamic_token_count", 0.01]]
            and learned["evidence"]["loss"]["configured_regularizers"] == ["dynamic_token_count"]
            and "dynamic_token_count" in learned["evidence"]["loss"]["components"]
        ),
        "discharge_plus_regularization_gradient_reaches_boundary_network": (
            learned_gradient["gradient_tensor_count"] > 0
            and learned_gradient["nonzero_gradient_tensor_count"] > 0
            and learned_gradient["gradient_l2_norm"] > 0.0
            and learned_gradient["all_present_gradients_finite"]
        ),
        "learned_first_day_is_boundary": all(learned_segmentation["first_day_is_boundary"]),
        "learned_counts_match_boundaries_and_lengths": learned_counts_match,
        "learned_boundary_length_constraints_hold": learned_lengths_valid,
        "learned_boundary_rates_are_finite_probabilities": (
            learned_segmentation["boundary_rates_all_finite"]
            and 0.0 < learned_segmentation["boundary_rate_minimum"]
            and learned_segmentation["boundary_rate_maximum"] < 1.0
        ),
    }
    learned["gates"].update(learned_specific)
    learned["status"] = "PASS" if all(learned["gates"].values()) else "FAIL"

    pair_gates = {
        "same_total_parameter_count": (
            fixed["evidence"]["parameter_counts"]["total_parameters"]
            == learned["evidence"]["parameter_counts"]["total_parameters"]
        ),
        "same_boundary_parameter_count": (
            fixed["evidence"]["parameter_counts"]["boundary_parameters"]
            == learned["evidence"]["parameter_counts"]["boundary_parameters"]
        ),
        "same_synthetic_shape_contract": (
            fixed["evidence"]["synthetic_batch"] == learned["evidence"]["synthetic_batch"]
        ),
    }
    overall_pass = (
        source_audit["run_smoke_unchanged_since_execution"]
        and source_audit["implementation_unchanged_since_execution"]
        and all(item["status"] == "PASS" for item in audited_runs.values())
        and all(pair_gates.values())
    )
    return {
        "schema_version": 1,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "overall_status": "TECHNICAL_PASS" if overall_pass else "TECHNICAL_FAIL",
        "technical_gate": {
            "passed": overall_pass,
            "meaning": (
                "Synthetic forward, NSE plus configured regularization backward, one AdamW update, "
                "segmentation constraints, and checkpoint reload were audited. Technical PASS does not "
                "establish hydrological performance."
            ),
            "hydrological_performance_assessed": False,
        },
        "scope": evidence["scope"],
        "environment": evidence["environment"],
        "source_audit": source_audit,
        "pair_gates": pair_gates,
        "runs": audited_runs,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-evidence", type=Path, default=DEFAULT_RUN_EVIDENCE)
    parser.add_argument("--report", type=Path, default=DEFAULT_REPORT)
    args = parser.parse_args()

    os.chdir(REPO_ROOT)
    run_evidence_path = args.run_evidence if args.run_evidence.is_absolute() else REPO_ROOT / args.run_evidence
    report_path = args.report if args.report.is_absolute() else REPO_ROOT / args.report
    if report_path.exists():
        raise FileExistsError(f"Refusing to overwrite existing smoke report: {report_path}")
    report = audit(run_evidence_path)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    with report_path.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")
    print(json.dumps({
        "overall_status": report["overall_status"],
        "report": _relative(report_path),
        "hydrological_performance_assessed": False,
    }, indent=2))
    return 0 if report["technical_gate"]["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
