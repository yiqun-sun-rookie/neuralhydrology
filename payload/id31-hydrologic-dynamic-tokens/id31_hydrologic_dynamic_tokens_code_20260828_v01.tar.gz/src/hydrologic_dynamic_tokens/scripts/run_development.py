"""Run one hash-bound ID31 development experiment on candidate-safe data.

The default mode is a read-only plan.  Real training requires both execution
flags, writes only below ``results/31_hydrologic_dynamic_tokens``, and never
invokes the sealed scoring service.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import statistics
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ruamel.yaml import YAML

from src.hydrologic_dynamic_tokens.scripts import audit_configs
from src.modern_transformer_moe.scripts.candidate_safe_data import (
    assert_safe_data_unchanged,
    audit_access_log,
    capture_safe_data_snapshot,
)


REPO_ROOT = Path(__file__).resolve().parents[3]
RESULT_ROOT = Path("results/31_hydrologic_dynamic_tokens")
INVOCATION_ROOT = RESULT_ROOT / "_invocations"
CONFIG_BY_ID = {
    "DT04": Path("src/hydrologic_dynamic_tokens/configs/fixed_04_s100.yml"),
    "DT08": Path("src/hydrologic_dynamic_tokens/configs/fixed_08_s100.yml"),
    "DT16": Path("src/hydrologic_dynamic_tokens/configs/fixed_16_s100.yml"),
    "DL00": Path("src/hydrologic_dynamic_tokens/configs/learned_detached_s100.yml"),
    "DL01": Path("src/hydrologic_dynamic_tokens/configs/learned_end_to_end_s100.yml"),
}
IMPLEMENTATION_RELATIVE_PATHS = (
    Path("neuralhydrology/modelzoo/__init__.py"),
    Path("neuralhydrology/modelzoo/hydrologic_dynamic_token_transformer.py"),
    Path("neuralhydrology/modelzoo/hydrologic_dynamic_tokenizer.py"),
    Path("neuralhydrology/modelzoo/modern_causal_transformer.py"),
    Path("neuralhydrology/training/__init__.py"),
    Path("neuralhydrology/training/regularization.py"),
    Path("neuralhydrology/utils/config.py"),
    Path("src/hydrologic_dynamic_tokens/hpc/submit_development_experiment.slurm"),
    Path("src/hydrologic_dynamic_tokens/hpc/submit_gpu_resource_probe.slurm"),
    Path("src/hydrologic_dynamic_tokens/registry/experiments.csv"),
    Path("src/hydrologic_dynamic_tokens/scripts/audit_configs.py"),
    Path("src/hydrologic_dynamic_tokens/scripts/run_development.py"),
)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _relative(path: Path) -> str:
    return path.resolve().relative_to(REPO_ROOT.resolve()).as_posix()


def capture_source_integrity(experiment_id: str) -> dict[str, Any]:
    """Hash the registered source configuration and every ID31 implementation integration point."""
    if experiment_id not in CONFIG_BY_ID:
        raise ValueError(f"Unknown ID31 experiment identifier: {experiment_id}")
    config_path = (REPO_ROOT / CONFIG_BY_ID[experiment_id]).resolve()
    implementation_files: dict[str, str] = {}
    for relative_path in IMPLEMENTATION_RELATIVE_PATHS:
        path = (REPO_ROOT / relative_path).resolve()
        if not path.is_file():
            raise FileNotFoundError(f"Required ID31 source file is missing: {path}")
        implementation_files[relative_path.as_posix()] = _sha256(path)
    return {
        "schema_version": 1,
        "experiment_id": experiment_id,
        "source_config_path": _relative(config_path),
        "source_config_sha256": _sha256(config_path),
        "implementation_files": implementation_files,
    }


def _load_yaml(path: Path) -> dict[str, Any]:
    value = YAML(typ="safe").load(path)
    if not isinstance(value, dict):
        raise ValueError(f"Configuration must contain a mapping: {path}")
    return value


def _atomic_json(path: Path, value: dict[str, Any], *, create: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(value, indent=2, sort_keys=True, default=str, allow_nan=False) + "\n"
    if create:
        with path.open("x", encoding="utf-8") as stream:
            stream.write(text)
        return
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        with temporary.open("x", encoding="utf-8") as stream:
            stream.write(text)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _registered_hash(experiment_id: str) -> str:
    registry = REPO_ROOT / "src/hydrologic_dynamic_tokens/registry/experiments.csv"
    with registry.open("r", encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    matches = [row for row in rows if row["experiment_id"] == experiment_id]
    if len(matches) != 1:
        raise ValueError(f"Expected one registry row for {experiment_id}, found {len(matches)}")
    return matches[0]["config_sha256"]


def plan(experiment_id: str, gpu: int, run_id: str) -> dict[str, Any]:
    if re.fullmatch(r"[A-Za-z0-9_.-]+", run_id) is None:
        raise ValueError("run_id may contain only letters, digits, dot, underscore, and hyphen")
    issues = audit_configs.audit_repository(REPO_ROOT)
    if issues:
        raise ValueError("ID31 static audit failed: " + "; ".join(issues))
    config_path = (REPO_ROOT / CONFIG_BY_ID[experiment_id]).resolve()
    config = _load_yaml(config_path)
    config_hash = _sha256(config_path)
    if config_hash != _registered_hash(experiment_id):
        raise ValueError(f"{experiment_id} config hash differs from the preregistered value")
    return {
        "mode": "plan",
        "experiment_id": experiment_id,
        "seed": int(config["seed"]),
        "gpu": gpu,
        "run_id": run_id,
        "config_path": _relative(config_path),
        "config_sha256": config_hash,
        "run_root": str(config["run_dir"]),
        "date_contract": {
            "train_start_date": config["train_start_date"],
            "train_end_date": config["train_end_date"],
            "validation_start_date": config["validation_start_date"],
            "validation_end_date": config["validation_end_date"],
        },
        "command": [
            sys.executable,
            "-u",
            "-m",
            "neuralhydrology.nh_run",
            "train",
            "--config-file",
            _relative(config_path),
            "--gpu",
            str(gpu),
        ],
        "required_flags": ["--execute", "--operator-approved-heavy-compute"],
        "formal_evaluation_authorized": False,
    }


def _new_run_dir(run_root: Path, before: set[Path]) -> Path:
    after = {path.resolve() for path in run_root.iterdir() if path.is_dir()} if run_root.is_dir() else set()
    created = sorted(after - before)
    if len(created) != 1:
        raise RuntimeError(f"Expected exactly one new run below {run_root}, found {created}")
    return created[0]


def _build_metrics_artifact(experiment_id: str, source_config: Path, run_dir: Path) -> Path:
    # Reuse the already audited validation readers; do not reuse ID30 lifecycle state.
    from src.modern_transformer_moe.scripts import audit_configs as id30_audit

    checkpoint = run_dir / "model_epoch030.pt"
    run_config = run_dir / "config.yml"
    metrics = run_dir / "validation/model_epoch030/validation_metrics.csv"
    results = run_dir / "validation/model_epoch030/validation_results.p"
    for path in (checkpoint, run_config, metrics, results):
        if not path.is_file():
            raise FileNotFoundError(f"Required epoch-30 product is missing: {path}")
    source_config_values = _load_yaml(source_config)
    run_config_values = _load_yaml(run_config)
    snapshot_issues = id30_audit.audit_run_config_snapshot(
        source_config_values,
        run_config_values,
        run_dir,
        REPO_ROOT,
    )
    if snapshot_issues:
        raise ValueError("Run configuration snapshot drifted from the registered source: " + "; ".join(snapshot_issues))
    csv_nse = id30_audit.load_validation_nse_csv(metrics, REPO_ROOT)
    recomputed_nse = id30_audit.load_validation_results_nse(results, REPO_ROOT)
    if set(csv_nse) != set(recomputed_nse) or len(csv_nse) != 531:
        raise ValueError("Validation products must cover the same 531 basins")
    mismatches = [basin for basin in csv_nse if abs(csv_nse[basin] - recomputed_nse[basin]) > 1e-12]
    if mismatches:
        raise ValueError(f"CSV and recomputed validation NSE differ for {len(mismatches)} basins")
    artifact_path = run_dir / "epoch030_metrics.json"
    artifact = {
        "schema_version": 1,
        "experiment_family": "ID31_hydrologic_dynamic_tokens",
        "experiment_id": experiment_id,
        "epoch": 30,
        "metric": "NSE",
        "period": {"start": "2006-10-01", "end": "2008-09-30", "purpose": "internal_validation"},
        "source_config_path": _relative(source_config),
        "source_config_sha256": _sha256(source_config),
        "run_config_path": _relative(run_config),
        "run_config_sha256": _sha256(run_config),
        "checkpoint_path": _relative(checkpoint),
        "checkpoint_sha256": _sha256(checkpoint),
        "validation_metrics_path": _relative(metrics),
        "validation_metrics_sha256": _sha256(metrics),
        "validation_results_path": _relative(results),
        "validation_results_sha256": _sha256(results),
        "basin_count": len(recomputed_nse),
        "basin_nse": recomputed_nse,
        "median_nse": float(statistics.median(recomputed_nse.values())),
        "sealed_evaluation_accessed": False,
    }
    _atomic_json(artifact_path, artifact, create=True)
    return artifact_path


def execute(experiment_id: str, gpu: int, run_id: str) -> dict[str, Any]:
    execution_plan = plan(experiment_id, gpu, run_id)
    source_integrity_before = capture_source_integrity(experiment_id)
    if source_integrity_before["source_config_sha256"] != execution_plan["config_sha256"]:
        raise RuntimeError("Source-integrity snapshot disagrees with the registered execution plan")
    config_path = REPO_ROOT / execution_plan["config_path"]
    config = _load_yaml(config_path)
    invocation_dir = REPO_ROOT / INVOCATION_ROOT / run_id
    invocation_dir.mkdir(parents=True, exist_ok=False)
    manifest_path = invocation_dir / "run_manifest.json"
    access_log = invocation_dir / "data_access.jsonl"
    safe_before = capture_safe_data_snapshot(REPO_ROOT, config)
    run_root = (REPO_ROOT / str(config["run_dir"])).resolve()
    before = {path.resolve() for path in run_root.iterdir() if path.is_dir()} if run_root.is_dir() else set()
    manifest: dict[str, Any] = {
        **execution_plan,
        "mode": "execute",
        "status": "RUNNING",
        "started_at_utc": _utc_now(),
        "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
        "source_integrity_before": source_integrity_before,
        "candidate_safe_data_before": safe_before,
        "data_access_log": _relative(access_log),
    }
    _atomic_json(manifest_path, manifest, create=True)
    environment = os.environ.copy()
    environment["NEURALHYDROLOGY_DATA_ACCESS_LOG"] = str(access_log)
    try:
        completed = subprocess.run(execution_plan["command"], cwd=REPO_ROOT, env=environment, check=False)
        manifest["training_return_code"] = completed.returncode
        if completed.returncode != 0:
            raise RuntimeError(f"NeuralHydrology training returned {completed.returncode}")
        run_dir = _new_run_dir(run_root, before)
        source_integrity_after = capture_source_integrity(experiment_id)
        if source_integrity_after != source_integrity_before:
            raise RuntimeError("ID31 source configuration or implementation changed during training")
        artifact_path = _build_metrics_artifact(experiment_id, config_path, run_dir)
        safe_after = assert_safe_data_unchanged(safe_before, REPO_ROOT, config)
        data_access = audit_access_log(access_log, Path(safe_before["forcing_dir"]),
                                       Path(safe_before["supervision_dir"]))
        manifest.update({
            "status": "COMPLETE",
            "completed_at_utc": _utc_now(),
            "run_dir": _relative(run_dir),
            "metrics_artifact_path": _relative(artifact_path),
            "metrics_artifact_sha256": _sha256(artifact_path),
            "source_integrity_after": source_integrity_after,
            "candidate_safe_data_after": safe_after,
            "data_access": data_access,
        })
    except Exception as error:
        manifest.update({
            "status": "FAILED",
            "failed_at_utc": _utc_now(),
            "error_type": type(error).__name__,
            "error": str(error),
        })
        _atomic_json(manifest_path, manifest)
        raise
    _atomic_json(manifest_path, manifest)
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("experiment_id", choices=sorted(CONFIG_BY_ID))
    parser.add_argument("--seed", type=int, default=100)
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--operator-approved-heavy-compute", action="store_true")
    args = parser.parse_args()
    if args.seed != 100:
        raise ValueError("ID31 currently registers only random seed 100")
    if args.execute != args.operator_approved_heavy_compute:
        raise PermissionError("Real training requires both execution flags")
    result = execute(args.experiment_id, args.gpu, args.run_id) if args.execute else plan(
        args.experiment_id, args.gpu, args.run_id
    )
    print(json.dumps(result, indent=2, sort_keys=True, default=str, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
