"""Run the data-free ID31 fixed/learned dynamic-token technical smoke.

This script never opens CAMELS files.  It constructs one deterministic synthetic
batch with the full development shape, executes exactly one AdamW update for the
fixed eight-day control and the end-to-end learned tokenizer, and records raw
evidence for :mod:`audit_smoke`.  A successful run is only a software check; it
does not measure hydrological skill.
"""

from __future__ import annotations

import argparse
import gc
import hashlib
import json
import math
import os
import platform
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import torch

from neuralhydrology.modelzoo import get_model
from neuralhydrology.training import get_loss_obj, get_optimizer, get_regularization_obj
from neuralhydrology.utils.config import Config


REPO_ROOT = Path(__file__).resolve().parents[3]
CONFIGS = {
    "fixed_08": REPO_ROOT / "src" / "hydrologic_dynamic_tokens" / "configs" / "fixed_08_s100.yml",
    "learned_end_to_end": (
        REPO_ROOT / "src" / "hydrologic_dynamic_tokens" / "configs" / "learned_end_to_end_s100.yml"
    ),
}
DEFAULT_OUTPUT_DIR = REPO_ROOT / "results" / "31_hydrologic_dynamic_tokens" / "_reports"
DEFAULT_RUN_EVIDENCE = DEFAULT_OUTPUT_DIR / "smoke_run.json"
DEFAULT_ARTIFACT_DIR = DEFAULT_OUTPUT_DIR / "smoke_artifacts"
BATCH_SIZE = 4
SEQUENCE_LENGTH = 270
SYNTHETIC_SEED = 31_100
IMPLEMENTATION_FILES = (
    REPO_ROOT / "neuralhydrology" / "modelzoo" / "hydrologic_dynamic_tokenizer.py",
    REPO_ROOT / "neuralhydrology" / "modelzoo" / "hydrologic_dynamic_token_transformer.py",
    REPO_ROOT / "neuralhydrology" / "modelzoo" / "__init__.py",
    REPO_ROOT / "neuralhydrology" / "utils" / "config.py",
    REPO_ROOT / "neuralhydrology" / "training" / "regularization.py",
    REPO_ROOT / "neuralhydrology" / "training" / "__init__.py",
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _relative(path: Path) -> str:
    try:
        return path.resolve().relative_to(REPO_ROOT.resolve()).as_posix()
    except ValueError:
        return str(path.resolve())


def _write_json_exclusive(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")


def _load_state(path: Path, device: torch.device) -> dict[str, torch.Tensor]:
    try:
        return torch.load(path, map_location=device, weights_only=True)
    except TypeError:
        return torch.load(path, map_location=device)


def _synchronize(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize(device)


def _all_tensors_finite(value: dict[str, torch.Tensor]) -> bool:
    for tensor in value.values():
        if isinstance(tensor, torch.Tensor) and not bool(torch.isfinite(tensor).all().item()):
            return False
    return True


def _scalar_components(components: dict[str, torch.Tensor]) -> dict[str, float]:
    return {name: float(value.detach().cpu().reshape(-1)[0].item()) for name, value in components.items()}


def _synthetic_batch(config: Config, device: torch.device) -> tuple[dict[str, Any], dict[str, Any]]:
    """Create one deterministic, full-shape Track-0-compatible synthetic batch."""
    generator = torch.Generator(device="cpu").manual_seed(SYNTHETIC_SEED)
    dynamic_names = list(config.dynamic_inputs_flattened)
    static_count = len(config.static_attributes)
    if len(dynamic_names) != 5 or static_count != 27:
        raise ValueError("The ID31 smoke requires exactly five dynamic inputs and 27 static attributes.")

    dynamic: dict[str, torch.Tensor] = {}
    for index, name in enumerate(dynamic_names):
        values = torch.randn(BATCH_SIZE, SEQUENCE_LENGTH, 1, generator=generator)
        if index == 0:
            # Keep the declared precipitation-like extensive input non-negative.
            values = values.abs()
        dynamic[name] = values.to(device)

    static = torch.randn(BATCH_SIZE, static_count, generator=generator).to(device)
    target = torch.randn(BATCH_SIZE, SEQUENCE_LENGTH, 1, generator=generator).to(device)
    target_stds = (0.5 + torch.rand(BATCH_SIZE, 1, 1, generator=generator)).to(device)
    data: dict[str, Any] = {
        "x_d": dynamic,
        "x_s": static,
        "y": target,
        "per_basin_target_stds": target_stds,
    }
    shape_contract = {
        "batch_size": BATCH_SIZE,
        "sequence_length_days": SEQUENCE_LENGTH,
        "dynamic_input_count": len(dynamic),
        "dynamic_input_shapes": {name: list(tensor.shape) for name, tensor in dynamic.items()},
        "static_attribute_count": static_count,
        "static_shape": list(static.shape),
        "target_shape": list(target.shape),
        "per_basin_target_stds_shape": list(target_stds.shape),
    }
    return data, shape_contract


def _boundary_gradient_evidence(model: torch.nn.Module) -> dict[str, Any]:
    parameters = list(model.tokenizer.boundary_network.named_parameters())
    gradient_tensors = [(name, parameter.grad) for name, parameter in parameters if parameter.grad is not None]
    nonzero = [(name, gradient) for name, gradient in gradient_tensors if torch.count_nonzero(gradient).item() > 0]
    squared_norm = sum(float(torch.sum(gradient.detach().float()**2).cpu().item())
                       for _, gradient in gradient_tensors)
    return {
        "parameter_tensor_count": len(parameters),
        "gradient_tensor_count": len(gradient_tensors),
        "nonzero_gradient_tensor_count": len(nonzero),
        "nonzero_gradient_parameter_names": [name for name, _ in nonzero],
        "all_present_gradients_finite": all(bool(torch.isfinite(gradient).all().item())
                                            for _, gradient in gradient_tensors),
        "gradient_l2_norm": math.sqrt(squared_norm),
    }


def _parameter_update_evidence(before: dict[str, torch.Tensor], model: torch.nn.Module) -> dict[str, Any]:
    changed_names = []
    maximum_delta = 0.0
    for name, parameter in model.named_parameters():
        delta = (parameter.detach().cpu() - before[name]).abs()
        if torch.count_nonzero(delta).item() > 0:
            changed_names.append(name)
            maximum_delta = max(maximum_delta, float(delta.max().item()))
    return {
        "changed_parameter_tensor_count": len(changed_names),
        "changed_parameter_examples": changed_names[:20],
        "maximum_absolute_parameter_delta": maximum_delta,
    }


def _segmentation_evidence(output: dict[str, torch.Tensor], config: Config) -> dict[str, Any]:
    boundaries = output["dynamic_token_boundaries"].detach().cpu().to(torch.bool)
    counts = output["dynamic_token_count"].detach().cpu().to(torch.long)
    rates = output["dynamic_token_boundary_rates"].detach().cpu()
    boundary_indices: list[list[int]] = []
    segment_lengths: list[list[int]] = []
    for row in boundaries:
        starts = torch.nonzero(row, as_tuple=False).flatten().tolist()
        lengths = [right - left for left, right in zip(starts, starts[1:] + [SEQUENCE_LENGTH])]
        boundary_indices.append(starts)
        segment_lengths.append(lengths)
    return {
        "mode": config.dynamic_token_mode,
        "fixed_length": int(config.dynamic_token_fixed_length),
        "minimum_length": int(config.dynamic_token_min_length),
        "maximum_length": int(config.dynamic_token_max_length),
        "target_count": int(config.dynamic_token_target_count),
        "token_counts": counts.tolist(),
        "boundary_indices": boundary_indices,
        "segment_lengths": segment_lengths,
        "first_day_is_boundary": [bool(row[0].item()) for row in boundaries],
        "boundary_rate_minimum": float(rates.min().item()),
        "boundary_rate_maximum": float(rates.max().item()),
        "boundary_rates_all_finite": bool(torch.isfinite(rates).all().item()),
        "reported_mean_lengths": output["dynamic_token_mean_length"].detach().cpu().tolist(),
        "reported_max_lengths": output["dynamic_token_max_length"].detach().cpu().tolist(),
    }


def _run_one(label: str, config_path: Path, artifact_dir: Path, device: torch.device) -> dict[str, Any]:
    config = Config(config_path)
    if config.seq_length != SEQUENCE_LENGTH or config.predict_last_n != 1:
        raise ValueError(f"{label} must retain seq_length=270 and predict_last_n=1.")
    data, shape_contract = _synthetic_batch(config, device)

    if device.type == "cuda":
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats(device)
    _synchronize(device)
    run_started = time.perf_counter()

    model = get_model(config).to(device)
    model.train()
    loss_object = get_loss_obj(config).to(device)
    regularizers = get_regularization_obj(config)
    loss_object.set_regularization_terms(regularizers)
    optimizer = get_optimizer(model, config)
    initial_parameters = {name: parameter.detach().cpu().clone() for name, parameter in model.named_parameters()}

    _synchronize(device)
    forward_started = time.perf_counter()
    output = model(data)
    total_loss, components = loss_object(output, data)
    _synchronize(device)
    forward_seconds = time.perf_counter() - forward_started

    backward_started = time.perf_counter()
    optimizer.zero_grad(set_to_none=True)
    total_loss.backward()
    boundary_gradients = _boundary_gradient_evidence(model)
    all_gradients_finite = all(parameter.grad is None or bool(torch.isfinite(parameter.grad).all().item())
                               for parameter in model.parameters())
    optimizer.step()
    _synchronize(device)
    backward_and_step_seconds = time.perf_counter() - backward_started
    update_evidence = _parameter_update_evidence(initial_parameters, model)
    parameters_all_finite = all(bool(torch.isfinite(parameter).all().item()) for parameter in model.parameters())

    artifact_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_path = artifact_dir / f"{label}_after_one_step.pt"
    if checkpoint_path.exists():
        raise FileExistsError(f"Refusing to overwrite smoke checkpoint: {checkpoint_path}")
    torch.save(model.state_dict(), checkpoint_path)

    model.eval()
    reloaded = get_model(config).to(device)
    reloaded.load_state_dict(_load_state(checkpoint_path, device), strict=True)
    reloaded.eval()
    _synchronize(device)
    reload_started = time.perf_counter()
    with torch.no_grad():
        post_step_output = model(data)
        reloaded_output = reloaded(data)
    _synchronize(device)
    reload_forward_seconds = time.perf_counter() - reload_started
    prediction_delta = (post_step_output["y_hat"] - reloaded_output["y_hat"]).abs()
    boundary_equal = torch.equal(post_step_output["dynamic_token_boundaries"],
                                 reloaded_output["dynamic_token_boundaries"])
    count_equal = torch.equal(post_step_output["dynamic_token_count"], reloaded_output["dynamic_token_count"])
    segmentation = _segmentation_evidence(reloaded_output, config)
    _synchronize(device)
    wall_seconds = time.perf_counter() - run_started
    peak_cuda_memory = torch.cuda.max_memory_allocated(device) if device.type == "cuda" else None

    parameter_counts = model.parameter_counts() if hasattr(model, "parameter_counts") else {
        "total_parameters": sum(parameter.numel() for parameter in model.parameters())
    }
    report = {
        "label": label,
        "config": {
            "path": _relative(config_path),
            "sha256": _sha256(config_path),
            "mode": config.dynamic_token_mode,
            "regularization": config.regularization,
            "optimizer": config.optimizer,
            "learning_rate_step_0": float(config.learning_rate[0]),
            "detach_boundary_gradient": bool(config.dynamic_token_detach_boundary_gradient),
        },
        "synthetic_batch": shape_contract,
        "parameter_counts": {name: int(value) for name, value in parameter_counts.items()},
        "loss": {
            "components": _scalar_components(components),
            "total_finite": bool(torch.isfinite(total_loss).item()),
            "configured_regularizers": [module.name for module in regularizers],
        },
        "gradients": {
            "all_present_gradients_finite": all_gradients_finite,
            "boundary_network": boundary_gradients,
        },
        "optimizer_step": {
            "class": optimizer.__class__.__name__,
            "completed_steps": 1,
            **update_evidence,
            "parameters_all_finite_after_step": parameters_all_finite,
        },
        "forward": {
            "prediction_shape": list(output["y_hat"].shape),
            "all_output_tensors_finite": _all_tensors_finite(output),
            "post_step_all_output_tensors_finite": _all_tensors_finite(post_step_output),
        },
        "segmentation_after_step": segmentation,
        "checkpoint_reload": {
            "checkpoint_path": _relative(checkpoint_path),
            "checkpoint_sha256": _sha256(checkpoint_path),
            "strict_load": True,
            "prediction_shape": list(reloaded_output["y_hat"].shape),
            "prediction_maximum_absolute_difference": float(prediction_delta.max().item()),
            "prediction_allclose_at_1e_minus_7": bool(torch.allclose(post_step_output["y_hat"],
                                                                      reloaded_output["y_hat"],
                                                                      atol=1e-7,
                                                                      rtol=0.0)),
            "boundaries_identical": boundary_equal,
            "token_counts_identical": count_equal,
            "reloaded_outputs_all_finite": _all_tensors_finite(reloaded_output),
        },
        "resources": {
            "device": str(device),
            "forward_and_loss_seconds": forward_seconds,
            "backward_and_adamw_step_seconds": backward_and_step_seconds,
            "reload_pair_forward_seconds": reload_forward_seconds,
            "total_wall_seconds": wall_seconds,
            "peak_cuda_memory_bytes": peak_cuda_memory,
        },
    }
    del reloaded, model, optimizer, loss_object, output, post_step_output, reloaded_output
    gc.collect()
    if device.type == "cuda":
        torch.cuda.empty_cache()
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-evidence", type=Path, default=DEFAULT_RUN_EVIDENCE)
    parser.add_argument("--artifact-dir", type=Path, default=DEFAULT_ARTIFACT_DIR)
    parser.add_argument("--cpu", action="store_true", help="Force CPU even when CUDA is available.")
    args = parser.parse_args()

    os.chdir(REPO_ROOT)
    torch.set_num_threads(1)
    torch.manual_seed(SYNTHETIC_SEED)
    cuda_available = torch.cuda.is_available() and not args.cpu
    device = torch.device("cuda:0" if cuda_available else "cpu")
    if cuda_available:
        torch.cuda.manual_seed_all(SYNTHETIC_SEED)

    run_evidence = args.run_evidence if args.run_evidence.is_absolute() else REPO_ROOT / args.run_evidence
    artifact_dir = args.artifact_dir if args.artifact_dir.is_absolute() else REPO_ROOT / args.artifact_dir
    if run_evidence.exists():
        raise FileExistsError(f"Refusing to overwrite existing smoke evidence: {run_evidence}")
    if artifact_dir.exists():
        raise FileExistsError(f"Refusing to overwrite existing smoke artifact directory: {artifact_dir}")

    reports = {
        label: _run_one(label, config_path, artifact_dir, device) for label, config_path in CONFIGS.items()
    }
    evidence = {
        "schema_version": 1,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "scope": {
            "experiment_family": "ID31 hydrologic dynamic tokens",
            "data_source": "deterministic synthetic tensors only",
            "camels_files_read": False,
            "hydrological_performance_assessed": False,
            "meaning": "Technical smoke only; PASS does not imply hydrological skill.",
        },
        "environment": {
            "platform": platform.platform(),
            "python": platform.python_version(),
            "torch": torch.__version__,
            "cuda_available": torch.cuda.is_available(),
            "cuda_used": cuda_available,
            "cuda_device_name": torch.cuda.get_device_name(device) if cuda_available else None,
            "device": str(device),
            "torch_num_threads": torch.get_num_threads(),
        },
        "source": {
            "run_smoke_path": _relative(Path(__file__)),
            "run_smoke_sha256": _sha256(Path(__file__)),
            "audit_smoke_path": "src/hydrologic_dynamic_tokens/scripts/audit_smoke.py",
            "implementation_files": {_relative(path): _sha256(path) for path in IMPLEMENTATION_FILES},
        },
        "runs": reports,
    }
    _write_json_exclusive(run_evidence, evidence)
    print(json.dumps({
        "status": "RUN_COMPLETE_AUDIT_REQUIRED",
        "device": str(device),
        "run_evidence": _relative(run_evidence),
        "hydrological_performance_assessed": False,
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
