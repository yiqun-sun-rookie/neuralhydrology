# Hydrologic Dynamic Time-Token Experiment

This experiment family tests one question: can a causal Transformer improve
regional rainfall-runoff prediction by learning **real variable-length time-token
boundaries** from allowed meteorological forcing and static catchment attributes?

The treatment changes which contiguous days form a token. It is not a
mixture-of-experts experiment, an attention-weighting experiment over unchanged
daily tokens, or an event label added after tokenization.

## Claims that are not authorized

A technically working implementation does not establish that learned boundaries
improve hydrological accuracy. A development-period improvement does not establish
formal benchmark superiority. This family does not claim automatic computational
savings, physically correct event boundaries, or better scaling behavior. No formal
evaluation-period predictions or scoring are authorized by this experiment contract.

## Fixed information and training contract

Every runnable candidate uses exactly:

- 531 Catchment Attributes and Meteorology for Large-sample Studies basins in the
  existing forcing-only basin file;
- the five Maurer meteorological forcing variables and 27 allowed static catchment
  attributes;
- training from 1 October 1999 through 30 September 2006;
- internal validation from 1 October 2006 through 30 September 2008;
- a 270-day input history and one final-day discharge prediction;
- a dense causal Transformer with width 128, four layers, four attention heads,
  feed-forward width 512, and the same AdamW learning-rate schedule;
- 30 epochs and random seed 100.

Observed discharge is supervision only. It is not an input to the boundary network,
token pooling, Transformer, static attributes, or any autoregressive channel.

## Stable experiment identifiers

| Identifier | Treatment | Materialized now |
|---|---|---:|
| `DT00` | Existing one-day-token dense Transformer control | external control only |
| `DT04` | Fixed four-day tokens | yes |
| `DT08` | Fixed eight-day tokens | yes |
| `DT16` | Fixed sixteen-day tokens | yes |
| `DR01` | Forcing-only rule boundary control | no; registered before rule design |
| `DL00` | Learned boundaries with discharge gradient detached at the boundary assignment | yes |
| `DL01` | Learned boundaries with end-to-end discharge gradient | yes |

The fixed controls share the same tokenizer output and pooling interface as the
learned candidates. The learned pair differs only in whether the discharge loss can
update the boundary assignment. Both learned candidates retain the same token-count
regularization, so `DL00` learns boundaries from that constraint but receives no
direct or shared-embedding discharge supervision.

Learned candidates start from the preregistered eight-day reference: target token
count 34 over 270 days, minimum token length 2 days, maximum token length 30 days,
boundary hidden width 64, causal convolution kernel 15, and straight-through
temperature 0.25. The standardized precipitation model input is summed within each
token; the standardized forcing values are also pooled as means. This is exact
conservation in model-input space, not a claim that the stored feature is a physical
millimetre accumulation.

The boundary accumulation is a renewal trigger: it resets after each new token and
discards any threshold overshoot on the triggering day. It is not a continuously
advancing clock coordinate.

## Existing control values and evidence boundary

The current planning record reports an internal-validation median
Nash-Sutcliffe efficiency of `0.70540` for the protocol-matched long short-term
memory network and `0.67103` for the one-day-token Transformer. Their machine-readable
remote metrics artifacts are not present in this local worktree. Therefore these
numbers are recorded only as **unverified remote report values** and cannot be used as
audited evidence until the exact artifact paths and SHA-256 hashes are copied and
checked. The `DT00` registry row makes this missing binding explicit.

## Static audit

Run only the data-free audit with:

```powershell
python -m src.hydrologic_dynamic_tokens.scripts.audit_configs
pytest test/test_hydrologic_dynamic_token_configs.py -v
```

The audit reads YAML, the experiment registry, and configuration hashes. It does not
load hydrological data, launch a model, submit a remote job, inspect the formal
evaluation period, or call the scoring service.

The current hash-bound synthetic full-configuration smoke report is
`results/31_hydrologic_dynamic_tokens/_reports/smoke_report_v03.json`. Its
`TECHNICAL_PASS` verifies execution and gradients only; all four learned examples
still had the initialized 34 regular eight-day tokens after one update.

## Decision sequence

1. Pass the local tokenizer, model, gradient, checkpoint, and configuration tests.
2. Train `DT04`, `DT08`, and `DT16` under the fixed internal-validation contract.
3. Use `DT08` as the preregistered one-factor causal control for `DL00` and `DL01`;
   use the best of all three fixed lengths only as a separate performance reference.
4. Train `DL00` and `DL01` at the fixed target of 34 tokens with unchanged
   Transformer and optimization fields.
5. Report the primary paired `DL01` minus `DT08` validation difference. If `DT04` or
   `DT16` is the best fixed model, a token-count-matched learned candidate requires a
   new prospective configuration before making a dynamic-versus-fixed attribution.
6. Do not create formal
   evaluation-period predictions without a separately frozen continuation decision.

Long-lived outputs belong under `results/31_hydrologic_dynamic_tokens/`. This
directory and contract are independent of the existing modern Transformer and
mixture-of-experts experiment family and must not overwrite its code or evidence.
