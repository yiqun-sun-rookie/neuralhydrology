import csv
from pathlib import Path

from neuralhydrology.utils.config import Config
from src.hydrologic_dynamic_tokens.scripts import audit_configs
from src.hydrologic_dynamic_tokens.scripts import run_development


REPO_ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = REPO_ROOT / "src" / "hydrologic_dynamic_tokens" / "configs"
REGISTRY_PATH = REPO_ROOT / "src" / "hydrologic_dynamic_tokens" / "registry" / "experiments.csv"
HPC_DIR = REPO_ROOT / "src" / "hydrologic_dynamic_tokens" / "hpc"


def _configs() -> dict[str, dict]:
    return {name: audit_configs.load_yaml(CONFIG_DIR / name) for name in audit_configs.RUN_CONFIG_FILES}


def test_repository_static_contract_is_complete() -> None:
    assert audit_configs.audit_repository(REPO_ROOT) == []


def test_base_reference_preserves_the_existing_development_information_contract() -> None:
    reference = audit_configs.load_yaml(CONFIG_DIR / "base_development.yml")
    source = audit_configs.load_yaml(REPO_ROOT / "src/modern_transformer_moe/configs/base_development.yml")
    for key in audit_configs.BASE_INHERITED_FIELDS:
        assert reference[key] == source[key]


def test_all_runnable_files_pass_the_strict_config_parser() -> None:
    for filename in audit_configs.RUN_CONFIG_FILES:
        config = Config(CONFIG_DIR / filename)
        assert config.model == "hydrologic_dynamic_token_transformer"
        assert config.predict_last_n == 1


def test_all_runnable_configs_share_the_track0_development_contract() -> None:
    configs = _configs()
    reference = configs["fixed_04_s100.yml"]

    assert set(configs) == set(audit_configs.RUN_CONFIG_FILES)
    for filename, config in configs.items():
        assert config["dataset"] == "camels_us_track0_bundle"
        assert config["number_of_basins"] == 531
        assert config["forcings"] == ["maurer"]
        assert len(config["dynamic_inputs"]) == 5
        assert len(config["static_attributes"]) == 27
        assert config["train_start_date"] == "01/10/1999"
        assert config["train_end_date"] == "30/09/2006"
        assert config["validation_start_date"] == "01/10/2006"
        assert config["validation_end_date"] == "30/09/2008"
        assert config["seq_length"] == 270
        assert config["predict_last_n"] == 1
        assert config["seed"] == 100
        assert config["model"] == "hydrologic_dynamic_token_transformer"
        assert config["transformer_nheads"] == reference["transformer_nheads"] == 4
        assert config["transformer_nlayers"] == reference["transformer_nlayers"] == 4
        assert config["transformer_dim_feedforward"] == reference["transformer_dim_feedforward"] == 512
        assert audit_configs.embedding_width(config) == audit_configs.embedding_width(reference) == 128


def test_fixed_length_controls_are_exact_one_factor_variants() -> None:
    configs = _configs()
    expected_lengths = {
        "fixed_04_s100.yml": 4,
        "fixed_08_s100.yml": 8,
        "fixed_16_s100.yml": 16,
    }
    reference = configs["fixed_04_s100.yml"]

    for filename, expected_length in expected_lengths.items():
        config = configs[filename]
        assert config["dynamic_token_mode"] == "fixed"
        assert config["dynamic_token_fixed_length"] == expected_length
        assert config["regularization"] == []
        assert audit_configs.unexpected_pair_differences(
            reference,
            config,
            allowed={"experiment_name", "run_dir", "dynamic_token_fixed_length"},
        ) == {}


def test_detached_and_end_to_end_learned_candidates_differ_only_by_gradient_path() -> None:
    configs = _configs()
    detached = configs["learned_detached_s100.yml"]
    end_to_end = configs["learned_end_to_end_s100.yml"]

    for config in (detached, end_to_end):
        assert config["dynamic_token_mode"] == "learned"
        assert config["dynamic_token_min_length"] == 2
        assert config["dynamic_token_max_length"] == 30
        assert config["dynamic_token_target_count"] == 34
        assert config["dynamic_token_boundary_hidden_size"] == 64
        assert config["dynamic_token_boundary_kernel_size"] == 15
        assert config["dynamic_token_boundary_temperature"] == 0.25
        assert config["dynamic_token_sum_inputs"] == ["PRCP(mm/day)"]
        assert config["regularization"] == [["dynamic_token_count", 0.01]]

    assert detached["dynamic_token_detach_boundary_gradient"] is True
    assert end_to_end["dynamic_token_detach_boundary_gradient"] is False
    assert audit_configs.unexpected_pair_differences(
        detached,
        end_to_end,
        allowed={"experiment_name", "run_dir", "dynamic_token_detach_boundary_gradient"},
    ) == {}


def test_end_to_end_candidate_and_eight_day_control_keep_all_token_shapes_fixed() -> None:
    configs = _configs()
    fixed = configs["fixed_08_s100.yml"]
    learned = configs["learned_end_to_end_s100.yml"]

    assert audit_configs.unexpected_pair_differences(
        fixed,
        learned,
        allowed={
            "experiment_name",
            "run_dir",
            "dynamic_token_mode",
            "dynamic_token_detach_boundary_gradient",
            "regularization",
        },
    ) == {}


def test_no_config_can_access_sealed_evaluation_or_forbidden_track0_inputs() -> None:
    for path in sorted(CONFIG_DIR.glob("*.yml")):
        text = path.read_text(encoding="utf-8").lower()
        assert not (set(text.split()) & audit_configs.SEALED_DATE_TOKENS)
        for forbidden in audit_configs.FORBIDDEN_TEXT:
            assert forbidden not in text


def test_registry_has_stable_ids_isolated_outputs_and_no_unearned_results() -> None:
    with REGISTRY_PATH.open("r", encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))

    assert [row["experiment_id"] for row in rows] == audit_configs.EXPECTED_REGISTRY_IDS
    assert len({row["run_dir"] for row in rows}) == len(rows)
    by_id = {row["experiment_id"]: row for row in rows}
    assert by_id["DR01"]["status"] == "planned_not_materialized"
    assert by_id["DR01"]["config_path"] == "not_materialized"
    for experiment_id in ("DT04", "DT08", "DT16", "DL00", "DL01"):
        row = by_id[experiment_id]
        assert row["status"] == "planned"
        assert row["validation_median_nse"] == "not_run"
        assert (REPO_ROOT / row["config_path"]).is_file()
    assert by_id["DT00"]["status"] == "external_control_pending_artifact_binding"
    assert by_id["DT00"]["validation_median_nse"] == "0.67103_unverified_remote_report"


def test_remote_development_plan_is_read_only_and_hash_bound() -> None:
    plan = run_development.plan("DT08", gpu=0, run_id="test_read_only_plan")

    assert plan["mode"] == "plan"
    assert plan["formal_evaluation_authorized"] is False
    assert plan["config_sha256"] == audit_configs.sha256_file(CONFIG_DIR / "fixed_08_s100.yml")
    assert plan["required_flags"] == ["--execute", "--operator-approved-heavy-compute"]
    assert "score.py" not in " ".join(plan["command"])


def test_remote_slurm_contract_and_gpu_probe_observe_a_real_update() -> None:
    probe = (HPC_DIR / "submit_gpu_resource_probe.slurm").read_text(encoding="utf-8")
    development = (HPC_DIR / "submit_development_experiment.slurm").read_text(encoding="utf-8")

    for script in (probe, development):
        assert "#SBATCH --partition=hgpu2p" in script
        assert "#SBATCH --gres=gpu:1" in script
        assert "#SBATCH --exclude=ngu002" in script
        assert "#SBATCH --mem" not in script
        assert "set -eo pipefail" in script
        assert "set -u" not in script
        assert "srun" not in script
        assert "RTX 3090" in script

    for required_check in (
        '"one_model_forward_call"',
        '"actual_full_batch_and_context_observed"',
        '"gradients_are_finite"',
        '"gradient_is_nonzero"',
        '"optimizer_step_is_exactly_one"',
        'audit_access_log',
        'assert_safe_data_unchanged',
    ):
        assert required_check in probe
