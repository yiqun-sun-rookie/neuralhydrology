"""Contract tests for causal, variable-length hydrological tokenization.

The public return contract is intentionally explicit without requiring concrete
dataclass names. ``StraightThroughSegmenter`` returns an object with
``assignments``, ``hard_assignments``, ``token_mask`` and ``token_lengths``.
``ConservativeTokenPooler`` returns an object with ``tokens``, ``token_mask``
and ``token_lengths``. ``HydrologicDynamicTokenizer`` returns the union of
those fields plus ``boundary_rates``.
"""

import pytest
import torch

from neuralhydrology.modelzoo.hydrologic_dynamic_tokenizer import (CausalBoundaryRateNetwork,
                                                                   ConservativeTokenPooler,
                                                                   HydrologicDynamicTokenizer,
                                                                   StraightThroughSegmenter)


def _segmenter(min_token_length: int = 2, max_token_length: int = 4) -> StraightThroughSegmenter:
    return StraightThroughSegmenter(min_token_length=min_token_length,
                                    max_token_length=max_token_length,
                                    temperature=0.25)


def _active_lengths(segmentation) -> torch.Tensor:
    return segmentation.token_lengths[segmentation.token_mask]


def test_equal_minimum_and_maximum_length_produces_fixed_cut_points():
    segmenter = _segmenter(min_token_length=3, max_token_length=3)
    rates = torch.tensor([[0.1, 0.9, 0.2, 0.8, 0.3, 0.7, 0.4, 0.6, 0.5]])

    segmentation = segmenter(rates)
    token_indices = segmentation.hard_assignments.argmax(dim=-1)

    assert token_indices.tolist() == [[0, 0, 0, 1, 1, 1, 2, 2, 2]]
    assert _active_lengths(segmentation).tolist() == [3, 3, 3]


def test_fractional_token_lengths_are_rejected_instead_of_silently_truncated():
    with pytest.raises(TypeError, match="integers"):
        StraightThroughSegmenter(min_token_length=1.5, max_token_length=4, temperature=0.25)


def test_each_day_has_exactly_one_hard_assignment():
    rates = torch.tensor([[0.0, 0.3, 0.6, 1.0, 0.2, 0.8, 0.4],
                          [1.0, 0.7, 0.4, 0.0, 0.8, 0.2, 0.6]])

    segmentation = _segmenter()(rates)

    torch.testing.assert_close(segmentation.hard_assignments.sum(dim=-1), torch.ones_like(rates))
    torch.testing.assert_close(segmentation.assignments, segmentation.hard_assignments)


def test_active_token_slots_form_a_prefix_and_match_hard_occupancy():
    rates = torch.tensor([[0.0] * 12, [1.0] * 12])

    segmentation = _segmenter()(rates)
    occupied = segmentation.hard_assignments.sum(dim=1) > 0

    assert segmentation.token_mask.dtype == torch.bool
    assert torch.equal(segmentation.token_mask, occupied)
    assert torch.all(segmentation.token_mask[:, 1:].to(torch.int8) <=
                     segmentation.token_mask[:, :-1].to(torch.int8))


def test_complete_token_lengths_respect_bounds_and_window_truncation_stays_positive():
    rates = torch.tensor([[0.0, 0.2, 0.4, 0.6, 0.8, 1.0] * 4,
                          [1.0, 0.8, 0.6, 0.4, 0.2, 0.0] * 4])

    segmentation = _segmenter(min_token_length=2, max_token_length=4)(rates)
    complete_token_mask = segmentation.token_mask.clone()
    batch_indices = torch.arange(complete_token_mask.shape[0])
    last_token_indices = segmentation.token_mask.sum(dim=-1) - 1
    complete_token_mask[batch_indices, last_token_indices] = False
    complete_lengths = segmentation.token_lengths[complete_token_mask]
    all_active_lengths = _active_lengths(segmentation)

    assert torch.all(complete_lengths >= 2)
    assert torch.all(all_active_lengths > 0)
    assert torch.all(all_active_lengths <= 4)
    torch.testing.assert_close(segmentation.token_lengths.sum(dim=-1), torch.full((2,), 24.0))


def test_low_and_high_boundary_rates_select_maximum_and_minimum_lengths():
    segmenter = _segmenter(min_token_length=2, max_token_length=4)

    low_rate = segmenter(torch.zeros(1, 12))
    high_rate = segmenter(torch.ones(1, 12))

    assert _active_lengths(low_rate).tolist() == [4, 4, 4]
    assert _active_lengths(high_rate).tolist() == [2, 2, 2, 2, 2, 2]


def test_boundary_accumulator_is_a_resetting_renewal_trigger():
    segmenter = _segmenter(min_token_length=1, max_token_length=12)

    segmentation = segmenter(torch.full((1, 6), 0.6))

    # Crossing every second day resets the accumulator; the 0.2 overshoot is intentionally not carried forward.
    assert _active_lengths(segmentation).tolist() == [2, 2, 2]


def test_boundary_rate_network_is_causal():
    torch.manual_seed(17)
    network = CausalBoundaryRateNetwork(dynamic_input_size=3,
                                        static_input_size=2,
                                        hidden_size=8,
                                        num_layers=2,
                                        kernel_size=3)
    network.eval()
    dynamic_inputs = torch.randn(2, 16, 3)
    static_inputs = torch.randn(2, 2)
    perturbed = dynamic_inputs.clone()
    last_unchanged_index = 8
    perturbed[:, last_unchanged_index + 1:] += 50.0 * torch.randn_like(perturbed[:, last_unchanged_index + 1:])

    with torch.no_grad():
        expected = network(dynamic_inputs, static_inputs)
        actual = network(perturbed, static_inputs)

    torch.testing.assert_close(actual[:, :last_unchanged_index + 1],
                               expected[:, :last_unchanged_index + 1],
                               atol=1e-7,
                               rtol=0.0)
    assert (actual[:, last_unchanged_index + 1:] - expected[:, last_unchanged_index + 1:]).abs().max() > 0
    assert torch.all((expected >= 0.0) & (expected <= 1.0))


def test_sum_inputs_are_conserved_by_token_pooling_to_one_part_per_million():
    torch.manual_seed(23)
    dynamic_inputs = torch.rand(3, 24, 4)
    segmentation = _segmenter()(torch.rand(3, 24))
    pooler = ConservativeTokenPooler(sum_input_indices=(0, 2))

    pooled = pooler(dynamic_inputs, segmentation)

    expected = dynamic_inputs[:, :, (0, 2)].sum(dim=1)
    actual = pooled.tokens[:, :, (0, 2)].sum(dim=1)
    torch.testing.assert_close(actual, expected, atol=1e-6, rtol=1e-6)


def test_conserved_sum_has_zero_boundary_gradient_across_all_token_slots():
    torch.manual_seed(24)
    rates = torch.zeros(1, 6, requires_grad=True)
    dynamic_inputs = torch.randn(1, 6, 2)
    segmentation = _segmenter(min_token_length=2, max_token_length=6)(rates)
    pooled = ConservativeTokenPooler(sum_input_indices=(0,))(dynamic_inputs, segmentation)

    gradient = torch.autograd.grad(pooled.tokens[:, :, 0].sum(), rates)[0]

    torch.testing.assert_close(gradient, torch.zeros_like(gradient), atol=1e-7, rtol=0.0)


def test_next_inactive_slot_retains_hypothetical_boundary_content_gradient():
    torch.manual_seed(25)
    rates = torch.zeros(1, 6, requires_grad=True)
    dynamic_inputs = torch.randn(1, 6, 2)
    segmentation = _segmenter(min_token_length=2, max_token_length=6)(rates)
    assert segmentation.token_mask.tolist() == [[True, False, False]]
    pooled = ConservativeTokenPooler()(dynamic_inputs, segmentation)

    gradient = torch.autograd.grad(pooled.tokens[:, 1, 0].sum(), rates)[0]

    assert torch.isfinite(gradient).all()
    assert torch.count_nonzero(gradient).item() > 0


def test_pooled_token_scalar_backpropagates_into_boundary_rate_network():
    torch.manual_seed(29)
    network = CausalBoundaryRateNetwork(dynamic_input_size=3,
                                        static_input_size=1,
                                        hidden_size=8,
                                        num_layers=2,
                                        kernel_size=3)
    dynamic_inputs = torch.randn(2, 20, 3)
    static_inputs = torch.randn(2, 1)
    rates = network(dynamic_inputs, static_inputs)
    segmentation = _segmenter()(rates)
    pooled = ConservativeTokenPooler()(dynamic_inputs, segmentation)

    pooled.tokens[:, 0, 0].sum().backward()

    gradients = [parameter.grad for parameter in network.parameters()
                 if parameter.requires_grad and parameter.grad is not None]
    assert gradients
    assert sum(gradient.abs().sum().item() for gradient in gradients) > 0.0


def test_seeded_tokenizer_initialization_and_outputs_are_reproducible():
    arguments = {
        "dynamic_input_size": 4,
        "static_input_size": 2,
        "hidden_size": 8,
        "num_rate_layers": 2,
        "rate_kernel_size": 3,
        "min_token_length": 2,
        "max_token_length": 4,
        "temperature": 0.25,
        "sum_input_indices": (0, 2),
    }
    torch.manual_seed(31)
    first = HydrologicDynamicTokenizer(**arguments)
    torch.manual_seed(31)
    second = HydrologicDynamicTokenizer(**arguments)
    dynamic_inputs = torch.randn(2, 18, 4)
    static_inputs = torch.randn(2, 2)

    first_output = first(dynamic_inputs, static_inputs)
    second_output = second(dynamic_inputs, static_inputs)

    for field in ("boundary_rates", "assignments", "hard_assignments", "tokens", "token_lengths"):
        torch.testing.assert_close(getattr(first_output, field), getattr(second_output, field), atol=0.0, rtol=0.0)
    assert torch.equal(first_output.token_mask, second_output.token_mask)
