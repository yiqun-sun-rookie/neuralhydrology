"""Contract tests for the forcing-driven hydrologic dynamic-token Transformer."""

from copy import deepcopy

import pytest
import torch

from neuralhydrology.modelzoo import get_model
from neuralhydrology.training import get_loss_obj, get_regularization_obj
from neuralhydrology.utils.config import Config


def _config(**updates) -> Config:
    values = {
        "model": "hydrologic_dynamic_token_transformer",
        "head": "regression",
        "target_variables": ["q"],
        "dynamic_inputs": ["precipitation", "temperature"],
        "static_attributes": ["area", "slope"],
        "dynamics_embedding": {
            "type": "fc",
            "hiddens": [8],
            "activation": "linear",
            "dropout": 0.0,
        },
        "statics_embedding": {
            "type": "fc",
            "hiddens": [8],
            "activation": "linear",
            "dropout": 0.0,
        },
        "seq_length": 12,
        "predict_last_n": 1,
        "transformer_nheads": 4,
        "transformer_dim_feedforward": 32,
        "transformer_dropout": 0.0,
        "transformer_nlayers": 2,
        "output_dropout": 0.0,
        "loss": "mse",
        "regularization": [],
        "seed": 37,
        "dynamic_token_mode": "learned",
        "dynamic_token_fixed_length": 4,
        "dynamic_token_min_length": 2,
        "dynamic_token_max_length": 6,
        "dynamic_token_target_count": 3,
        "dynamic_token_boundary_hidden_size": 8,
        "dynamic_token_boundary_kernel_size": 3,
        "dynamic_token_boundary_temperature": 1.0,
        "dynamic_token_sum_inputs": ["precipitation"],
        "dynamic_token_detach_boundary_gradient": False,
    }
    values.update(updates)
    return Config(values)


def _data(batch_size: int = 3, sequence_length: int = 12, seed: int = 101) -> dict:
    generator = torch.Generator().manual_seed(seed)
    return {
        "x_d": {
            "precipitation": torch.randn(batch_size, sequence_length, 1, generator=generator),
            "temperature": torch.randn(batch_size, sequence_length, 1, generator=generator),
        },
        "x_s": torch.randn(batch_size, 2, generator=generator),
        "y": torch.randn(batch_size, sequence_length, 1, generator=generator),
    }


def _boundary_parameters(model) -> list[tuple[str, torch.nn.Parameter]]:
    assert hasattr(model, "tokenizer")
    assert hasattr(model.tokenizer, "boundary_network")
    parameters = list(model.tokenizer.boundary_network.named_parameters())
    assert parameters
    return parameters


def test_factory_builds_dynamic_token_transformer_with_final_day_output_and_diagnostics():
    model = get_model(_config())

    output = model(_data())

    assert model.__class__.__name__ == "HydrologicDynamicTokenTransformer"
    assert output["y_hat"].shape == (3, 1, 1)
    assert output["dynamic_token_count_loss"].ndim == 0
    assert output["dynamic_token_count"].shape == (3, )
    assert output["dynamic_token_boundaries"].shape == (3, 12)
    assert output["dynamic_token_boundaries"].dtype == torch.bool


def test_predict_last_n_other_than_one_is_rejected():
    with pytest.raises(ValueError, match=r"predict_last_n.*1"):
        get_model(_config(predict_last_n=2))


def test_learned_one_day_minimum_is_rejected_but_fixed_one_day_control_is_supported():
    with pytest.raises(ValueError, match=r"min_length.*at least 2"):
        get_model(_config(dynamic_token_min_length=1,
                          dynamic_token_fixed_length=1,
                          dynamic_token_target_count=12))

    fixed = get_model(_config(dynamic_token_mode="fixed",
                              dynamic_token_min_length=1,
                              dynamic_token_fixed_length=1,
                              dynamic_token_target_count=12))
    output = fixed(_data())
    assert output["dynamic_token_count"].tolist() == [12, 12, 12]


def test_targets_are_supervision_only_and_cannot_change_boundaries_or_predictions():
    model = get_model(_config())
    model.eval()
    original = _data()
    changed_target = deepcopy(original)
    changed_target["y"] = original["y"] + 1000.0

    with torch.no_grad():
        original_output = model(original)
        changed_output = model(changed_target)

    assert torch.equal(original_output["dynamic_token_boundaries"], changed_output["dynamic_token_boundaries"])
    assert torch.equal(original_output["dynamic_token_count"], changed_output["dynamic_token_count"])
    assert torch.equal(original_output["y_hat"], changed_output["y_hat"])


def test_named_seed_repeats_boundaries_and_predictions_without_resetting_global_rng():
    data = _data(seed=211)
    torch.manual_seed(1)
    first = get_model(_config(seed=73))
    torch.manual_seed(999)
    second = get_model(_config(seed=73))
    first.eval()
    second.eval()

    with torch.no_grad():
        first_output = first(data)
        second_output = second(data)

    assert torch.equal(first_output["dynamic_token_boundaries"], second_output["dynamic_token_boundaries"])
    assert torch.equal(first_output["dynamic_token_count"], second_output["dynamic_token_count"])
    assert torch.equal(first_output["y_hat"], second_output["y_hat"])


def test_prediction_error_alone_reaches_every_boundary_network_parameter():
    config = _config(regularization=[])
    model = get_model(config)
    data = _data(seed=307)
    loss = get_loss_obj(config)

    output = model(data)
    total_loss, components = loss(output, data)
    total_loss.backward()

    assert total_loss.ndim == 0
    assert torch.isfinite(total_loss)
    assert set(components) >= {"loss", "total_loss"}
    assert torch.equal(components["loss"], components["total_loss"])
    for name, parameter in _boundary_parameters(model):
        assert parameter.grad is not None, name
        assert torch.isfinite(parameter.grad).all(), name
        assert torch.count_nonzero(parameter.grad).item() > 0, name


def test_masked_mse_uses_only_the_final_target_for_single_step_prediction():
    config = _config()
    model = get_model(config)
    data = _data(seed=401)
    loss = get_loss_obj(config)

    output = model(data)
    total_loss, components = loss(output, data)
    # NeuralHydrology's established ``MaskedMSELoss`` includes the conventional one-half factor.
    expected = 0.5 * torch.mean((output["y_hat"] - data["y"][:, -1:])**2)

    assert output["y_hat"].shape == data["y"][:, -1:].shape
    assert torch.allclose(components["loss"], expected)
    assert torch.allclose(total_loss, expected)


def test_dynamic_token_count_regularization_is_registered_and_added_to_prediction_loss():
    config = _config(regularization=[["dynamic_token_count", 0.01]])
    model = get_model(config)
    data = _data(seed=503)
    regularizers = get_regularization_obj(config)
    loss = get_loss_obj(config)
    loss.set_regularization_terms(regularizers)

    output = model(data)
    regularization_value = regularizers[0]({}, {}, output)
    total_loss, components = loss(output, data)

    assert len(regularizers) == 1
    assert regularizers[0].name == "dynamic_token_count"
    assert regularizers[0].weight == 0.01
    assert torch.equal(regularization_value, output["dynamic_token_count_loss"])
    assert set(components) >= {"loss", "dynamic_token_count", "total_loss"}
    assert torch.allclose(components["dynamic_token_count"], output["dynamic_token_count_loss"])
    assert torch.allclose(total_loss,
                          components["loss"] + 0.01 * components["dynamic_token_count"],
                          atol=1e-7,
                          rtol=0.0)


def test_dynamic_token_count_regularization_remains_scalar_during_evaluation():
    config = _config(regularization=[["dynamic_token_count", 0.01]])
    model = get_model(config)
    model.eval()
    data = _data(seed=557)
    regularizers = get_regularization_obj(config)
    loss = get_loss_obj(config)
    loss.set_regularization_terms(regularizers)

    with torch.no_grad():
        output = model(data)
        regularization_value = regularizers[0]({}, {}, output)
        total_loss, components = loss(output, data)

    # Evaluation keeps a length-one diagnostic so the tester can concatenate model outputs,
    # but a regularization term must be a scalar before it is added to the scalar prediction loss.
    assert output["dynamic_token_count_loss"].shape == (1, )
    assert regularization_value.ndim == 0
    assert components["dynamic_token_count"].ndim == 0
    assert total_loss.ndim == 0
    assert torch.isfinite(total_loss)


def test_detached_control_keeps_count_gradient_but_blocks_prediction_gradient():
    config = _config(dynamic_token_detach_boundary_gradient=True)
    model = get_model(config)
    data = _data(seed=607)
    prediction_loss = get_loss_obj(config)
    optimizer = torch.optim.SGD(model.parameters(), lr=0.05)

    output = model(data)
    rates_before_step = output["dynamic_token_boundary_rates"].detach().clone()
    loss_value, _ = prediction_loss(output, data)
    loss_value.backward()
    assert all(parameter.grad is None or torch.count_nonzero(parameter.grad).item() == 0
               for _, parameter in _boundary_parameters(model))
    optimizer.step()
    with torch.no_grad():
        rates_after_step = model(data)["dynamic_token_boundary_rates"]
    assert torch.equal(rates_before_step, rates_after_step)

    model.zero_grad(set_to_none=True)
    # Move the learned rate away from the target-count initialization so the squared count penalty is nonzero.
    with torch.no_grad():
        model.tokenizer.boundary_network.rate_projection.weight.zero_()
        model.tokenizer.boundary_network.rate_projection.bias.fill_(-4.0)
    output = model(data)
    output["dynamic_token_count_loss"].backward()
    gradients = [parameter.grad for _, parameter in _boundary_parameters(model)]
    assert all(gradient is not None and torch.isfinite(gradient).all() for gradient in gradients)
    assert sum(torch.count_nonzero(gradient).item() for gradient in gradients) > 0


def test_end_to_end_boundary_rates_change_after_prediction_only_step():
    config = _config(dynamic_token_detach_boundary_gradient=False)
    model = get_model(config)
    data = _data(seed=709)
    loss = get_loss_obj(config)
    optimizer = torch.optim.SGD(model.parameters(), lr=0.05)

    output = model(data)
    rates_before_step = output["dynamic_token_boundary_rates"].detach().clone()
    loss_value, _ = loss(output, data)
    loss_value.backward()
    optimizer.step()

    with torch.no_grad():
        rates_after_step = model(data)["dynamic_token_boundary_rates"]
    assert not torch.equal(rates_before_step, rates_after_step)
