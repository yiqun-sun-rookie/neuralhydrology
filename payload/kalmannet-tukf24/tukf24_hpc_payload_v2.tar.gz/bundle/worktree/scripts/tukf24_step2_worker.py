"""TUKF24 step-2 per-cell worker: anchor | train | readout_new | readout_old.

Retraining with the 1-10 day equal-weight loss. The basin preparation
(anchor gate, constructed noise, starting point) is bitwise the TUKF23
recipe via the frozen TUKF23 config; only the segment boundaries (buffers
widened 3->10 days) and the lead set of the loss change, exactly as the
TUKF24 contract freezes them.

The train stage never touches the test segment (arrays are hard-sliced at
the first test day). Readout stages refuse to run without a sealed
checkpoint manifest.

    anchor       python tukf24_step2_worker.py --stage anchor --basin B --out-root R
    train        python tukf24_step2_worker.py --stage train --basin B --mode M --out-root R
    readout_new  ... --stage readout_new --basin B --mode M --out-root R --train-root R --seal PATH
    readout_old  ... --stage readout_old --basin B --mode M --out-root R
                 (old = TUKF23 checkpoints, scored on the identical TUKF24 test grid;
                  verified against the TUKF23 seal recorded in the frozen config)
"""
from __future__ import annotations

import argparse
import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path
import sys

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import tukf24_lead_extension_common as c24  # noqa: E402

c23 = c24.c23
t17 = c24.t17

torch.set_num_threads(1)

LEADS = c24.LEADS_EXTENDED


def canonical_snapshot_sha(lists: dict) -> str:
    payload = json.dumps(lists, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode()).hexdigest()


def load_both(config_path: str) -> tuple[dict, dict]:
    config = c24.load_config(config_path, verify_hashes=True)
    contract23 = c23.load_contract(
        c24.WORKTREE / config["predecessor"]["tukf23_config"], verify_hashes=True)
    return config, contract23


def selection_score(config: dict, contract23: dict, model, prep: dict) -> float:
    sel = c24.step2_segment_origins(config, "selection")
    hi = max(sel) + max(LEADS) + 1
    first_test = int(config["step2_retrain"]["segments_day_index"]["test_origins"][0])
    if hi > first_test:
        raise ValueError("selection scoring would read a test day")
    with torch.no_grad():
        loss, _ = c24.extended_rolling_objective(
            model, prep["forcing"][:hi], prep["obs"][:hi], prep["x0"],
            prep["noise"]["initial_covariance"], sel, leads=LEADS,
            base_observation_variance=prep["noise"]["base_observation_variance"])
    return float(loss)


def stage_anchor(config: dict, contract23: dict, basin_id: str, out_root: Path) -> dict:
    t0 = time.perf_counter()
    prep = c23.prepare_basin(contract23, basin_id)
    record = {
        "stage": "anchor",
        "experiment_id": config["experiment_id"],
        "basin_id": basin_id,
        "dim_x": prep["dim_x"],
        "anchor_delta": prep["anchor_delta"],
        "published_nse": prep["published_nse"],
        "tolerance": float(contract23["anchor_gate"]["tolerance"]),
        "passed": True,
        "environment": c23.environment_stamp(),
        "seconds": time.perf_counter() - t0,
        "ran_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    c24.write_json(out_root / "anchor" / f"{basin_id}.json", record)
    return record


def stage_train(config: dict, contract23: dict, basin_id: str, mode: str,
                out_root: Path) -> dict:
    t0 = time.perf_counter()
    out = out_root / "train" / f"{basin_id}_{mode}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        return json.loads(out.read_text(encoding="utf-8"))

    prep = c23.prepare_basin(contract23, basin_id)
    model = c23.build_mode_model(contract23, prep)
    hyd, fil = c23.mode_groups(contract23, model, mode)
    mask = contract23["modes"]["masks"][mode]

    seg = config["step2_retrain"]["segments_day_index"]
    warmup_end = int(seg["warmup"][1]) + 1
    train_origins = c24.step2_segment_origins(config, "train")
    train_hi = max(train_origins) + max(LEADS) + 1
    if train_hi > int(seg["selection_origins"][0]):
        raise ValueError("train slice would cross into the selection segment")
    forcing, obs = prep["forcing"], prep["obs"]
    cov0 = prep["noise"]["initial_covariance"]
    base_var = prep["noise"]["base_observation_variance"]
    optimizer_spec = contract23["optimizer"]

    trainable_groups = []
    if mask["hydrology"]:
        trainable_groups.append(
            {"params": hyd, "lr": float(optimizer_spec["hydrology_learning_rate"])})
    if mask["filter"]:
        trainable_groups.append(
            {"params": fil, "lr": float(optimizer_spec["filter_learning_rate"])})

    step = int(optimizer_spec["selection_interval"])
    total = int(optimizer_spec["updates"])
    queries = tuple(range(0, total + 1, step))
    query_trace: list[list[float]] = []
    train_trace: list[float] = []

    if not trainable_groups:
        best = {"score": None, "update": 0, "snap": c23.snapshot(model)}
    else:
        optimizer = torch.optim.Adam(trainable_groups)
        clip = float(optimizer_spec["group_gradient_norm"])
        train_forcing = torch.as_tensor(forcing[warmup_end:train_hi])
        train_obs = torch.as_tensor(obs[warmup_end:train_hi])
        shifted_origins = tuple(o - warmup_end for o in train_origins)

        def warm_start():
            with torch.no_grad():
                trace = t17.rollout_state_update_trace(
                    model, forcing[:warmup_end], obs[:warmup_end], prep["x0"], cov0,
                    base_observation_variance=base_var)
                return (trace["posterior_state"][-1].detach().clone(),
                        trace["posterior_covariance"][-1].detach().clone())

        score0 = selection_score(config, contract23, model, prep)
        query_trace.append([0, score0])
        best = {"score": score0, "update": 0, "snap": c23.snapshot(model)}

        for update in range(1, total + 1):
            optimizer.zero_grad(set_to_none=True)
            warm_state, warm_cov = warm_start()
            loss, _ = c24.extended_rolling_objective(
                model, train_forcing, train_obs, warm_state, warm_cov,
                shifted_origins, leads=LEADS,
                base_observation_variance=base_var)
            loss.backward()
            if mask["hydrology"]:
                torch.nn.utils.clip_grad_norm_(hyd, clip)
            if mask["filter"]:
                torch.nn.utils.clip_grad_norm_(fil, clip)
            optimizer.step()
            projector = getattr(model, "project_trainable_coordinates_", None)
            if callable(projector):
                projector()
            train_trace.append(float(loss))
            if update in queries:
                score = selection_score(config, contract23, model, prep)
                query_trace.append([update, score])
                if score < best["score"]:  # strict: tie keeps the earlier update
                    best = {"score": score, "update": update, "snap": c23.snapshot(model)}

    c23.restore_(model, best["snap"])
    snap_lists = c23.snapshot_to_lists(best["snap"])
    record = {
        "stage": "train",
        "experiment_id": config["experiment_id"],
        "basin_id": basin_id,
        "mode": mode,
        "leads_days": list(LEADS),
        "dim_x": prep["dim_x"],
        "anchor_delta": prep["anchor_delta"],
        "base_observation_variance": base_var,
        "selected_update": best["update"],
        "selection_score_at_checkpoint": best["score"],
        "selection_query_trace": query_trace,
        "train_loss_trace": train_trace,
        "checkpoint_snapshot": snap_lists,
        "checkpoint_sha256": canonical_snapshot_sha(snap_lists),
        "learned_observation_ratio": float(model.observation_ratio()),
        "learned_process_diagonal": [float(v) for v in model.process_diagonal().reshape(-1)],
        "test_segment_contact": "none",
        "environment": c23.environment_stamp(),
        "seconds": time.perf_counter() - t0,
        "ran_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    c24.write_json(out, record)
    return record


def _readout(config: dict, contract23: dict, basin_id: str, mode: str,
             snap_lists: dict, expected_sha: str, seal_sha: str,
             out_root: Path, flavor: str) -> dict:
    """Score one checkpoint on the TUKF24 test grid (origins x leads 1-10)."""
    t0 = time.perf_counter()
    out_dir = out_root / flavor
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = out_dir / f"{basin_id}_{mode}.json"
    npz_path = out_dir / f"{basin_id}_{mode}.npz"
    if json_path.exists() and npz_path.exists():
        return json.loads(json_path.read_text(encoding="utf-8"))

    if canonical_snapshot_sha(snap_lists) != expected_sha:
        raise ValueError(f"{basin_id}_{mode} [{flavor}]: checkpoint drifted from the seal")

    prep = c23.prepare_basin(contract23, basin_id)
    model = c23.build_mode_model(contract23, prep)
    c23.restore_(model, c23.snapshot_from_lists(model, snap_lists))

    test_origins = c24.step2_segment_origins(config, "test")
    with torch.no_grad():
        loss, details = c24.extended_rolling_objective(
            model, prep["forcing"], prep["obs"], prep["x0"],
            prep["noise"]["initial_covariance"], test_origins, leads=LEADS,
            base_observation_variance=prep["noise"]["base_observation_variance"])
        errors = c24.extended_forecast_errors(
            model, details["origin_states"], prep["forcing"], prep["obs"],
            test_origins, LEADS)

    mse_by_lead = {str(lead): float(errors[lead].mean()) for lead in LEADS}
    np.savez_compressed(
        npz_path, origins=np.asarray(test_origins, dtype=np.int64),
        **{f"lead_{lead}": errors[lead] for lead in LEADS})

    record = {
        "stage": f"readout_{flavor}",
        "experiment_id": config["experiment_id"],
        "basin_id": basin_id,
        "mode": mode,
        "checkpoint_sha256": expected_sha,
        "seal_sha256": seal_sha,
        "test_pooled_mse": float(loss),
        "test_mse_by_lead": mse_by_lead,
        "test_origin_count": len(test_origins),
        "errors_npz": npz_path.name,
        "errors_npz_sha256": c24.sha256_file(npz_path),
        "environment": c23.environment_stamp(),
        "seconds": time.perf_counter() - t0,
        "ran_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    c24.write_json(json_path, record)
    return record


def stage_readout_new(config: dict, contract23: dict, basin_id: str, mode: str,
                      out_root: Path, train_root: Path, seal_path: Path) -> dict:
    seal = json.loads(Path(seal_path).read_text(encoding="utf-8"))
    if seal["experiment_id"] != config["experiment_id"]:
        raise ValueError("seal belongs to a different experiment")
    cell_key = f"{basin_id}_{mode}"
    if cell_key not in seal["cells"]:
        raise ValueError(f"cell {cell_key} is not sealed")
    train_record = json.loads(
        (train_root / "train" / f"{cell_key}.json").read_text(encoding="utf-8"))
    return _readout(config, contract23, basin_id, mode,
                    train_record["checkpoint_snapshot"],
                    seal["cells"][cell_key]["checkpoint_sha256"],
                    seal["seal_sha256"], out_root, "readout_new")


def stage_readout_old(config: dict, contract23: dict, basin_id: str, mode: str,
                      out_root: Path, tukf24_seal_path: Path) -> dict:
    """TUKF23 checkpoints on the TUKF24 test grid (joint readout clause 5.4).

    Test contact is test contact: this stage demands the TUKF24 training
    seal so the old-checkpoint readout cannot precede the single unsealing.
    """
    tukf24_seal = json.loads(Path(tukf24_seal_path).read_text(encoding="utf-8"))
    if tukf24_seal["experiment_id"] != config["experiment_id"]:
        raise ValueError("readout_old requires the TUKF24 training seal")
    if tukf24_seal.get("cell_count") != 108:
        raise ValueError("readout_old refused: TUKF24 training is not fully sealed")
    seal_path = c24.WORKTREE / config["predecessor"]["checkpoint_seal"]
    if c24.sha256_file(seal_path) != \
            config["frozen_input_sha256"]["tukf23_checkpoint_seal"]["sha256"]:
        raise ValueError("TUKF23 seal drifted from the frozen TUKF24 config")
    seal = json.loads(seal_path.read_text(encoding="utf-8"))
    cell_key = f"{basin_id}_{mode}"
    train_record = json.loads(
        (c24.WORKTREE / config["predecessor"]["tukf23_train_records"]
         / f"{cell_key}.json").read_text(encoding="utf-8"))
    return _readout(config, contract23, basin_id, mode,
                    train_record["checkpoint_snapshot"],
                    seal["cells"][cell_key]["checkpoint_sha256"],
                    seal["seal_sha256"], out_root, "readout_old")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", required=True,
                    choices=["anchor", "train", "readout_new", "readout_old"])
    ap.add_argument("--basin", required=True)
    ap.add_argument("--mode", default=None, choices=list(c23.MODES))
    ap.add_argument("--config", default=str(c24.DEFAULT_CONFIG))
    ap.add_argument("--out-root", required=True)
    ap.add_argument("--train-root", default=None)
    ap.add_argument("--seal", default=None)
    a = ap.parse_args()

    config, contract23 = load_both(a.config)
    out_root = Path(a.out_root)

    if a.stage == "anchor":
        record = stage_anchor(config, contract23, a.basin, out_root)
        print(json.dumps({k: record[k] for k in
                          ("basin_id", "anchor_delta", "passed", "seconds")}))
        return 0
    if a.mode is None:
        raise SystemExit("--mode is required beyond the anchor stage")
    if a.stage == "train":
        record = stage_train(config, contract23, a.basin, a.mode, out_root)
        print(json.dumps({k: record[k] for k in
                          ("basin_id", "mode", "selected_update",
                           "selection_score_at_checkpoint", "seconds")}))
        return 0
    if a.stage == "readout_new":
        if not a.train_root or not a.seal:
            raise SystemExit("--train-root and --seal are required for readout_new")
        record = stage_readout_new(config, contract23, a.basin, a.mode, out_root,
                                   Path(a.train_root), Path(a.seal))
    else:
        if not a.seal:
            raise SystemExit("--seal (the TUKF24 training seal) is required for readout_old")
        record = stage_readout_old(config, contract23, a.basin, a.mode, out_root,
                                   Path(a.seal))
    print(json.dumps({k: record[k] for k in
                      ("basin_id", "mode", "test_pooled_mse", "seconds")}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
