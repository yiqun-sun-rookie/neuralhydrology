"""Per-event one-to-one flood-peak evaluation for hourly forecast series.

Replaces two evaluation habits that mask phase errors:

1. the whole-series best correlation lag, which reports 0 when one event is
   early and another is late by the same amount;
2. the signed median of argmax-in-window peak offsets, which cancels early
   against late and lets a taller later peak shadow the temporally
   corresponding local peak (peak-order inversion), and lets one forecast peak
   be counted by two neighbouring events.

Design decisions (thresholds, windows, matching rule) were fixed on the
2020-2021 development period only; see
laos_forecast/basins/namou_kuwei/dl/highflow_2026_06_17/results/
da_eval_framework_2026_07_13/design_log.json.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.signal import find_peaks

_MINIMUM_PROMINENCE = 1e-9


def _continuous_segments(positions: np.ndarray, times: pd.DatetimeIndex) -> list[np.ndarray]:
    """Split selected positions into hourly-continuous runs."""
    if positions.size == 0:
        return []
    breaks = np.where(
        (np.diff(positions) != 1)
        | (np.diff(times[positions].values) != np.timedelta64(1, "h"))
    )[0] + 1
    return np.split(positions, breaks)


def detect_observed_events(
    observed,
    valid_times,
    scope_mask,
    *,
    height: float | None = None,
    min_separation_hours: int = 72,
    window_hours: int = 36,
) -> tuple[list[dict], float]:
    """Detect separated observed high-flow events whose window stays in scope."""
    target = np.asarray(observed, dtype=float)
    times = pd.DatetimeIndex(valid_times)
    selected = np.asarray(scope_mask, dtype=bool) & np.isfinite(target)
    if int(selected.sum()) == 0:
        return [], float("nan")
    if height is None:
        height = float(np.percentile(target[selected], 95))
    events: list[dict] = []
    for segment in _continuous_segments(np.flatnonzero(selected), times):
        if segment.size < 2 * window_hours + 1:
            continue
        peaks, _ = find_peaks(
            target[segment], height=float(height), distance=int(min_separation_hours)
        )
        for local_position in peaks:
            position = int(segment[local_position])
            if (
                position - window_hours < int(segment[0])
                or position + window_hours > int(segment[-1])
            ):
                continue
            events.append({
                "position": position,
                "time": times[position],
                "peak_m3s": float(target[position]),
            })
    return events, float(height)


def detect_forecast_candidates(
    forecast,
    valid_times,
    scope_mask,
    *,
    prominence_fraction: float = 0.10,
) -> list[int]:
    """Detect forecast local peaks; prominence scales with the forecast itself.

    The prominence floor is ``prominence_fraction`` of the forecast's own
    p95-p50 spread inside each continuous scope segment, so a uniformly
    under-predicting model keeps its genuine local peaks.
    """
    prediction = np.asarray(forecast, dtype=float)
    times = pd.DatetimeIndex(valid_times)
    selected = np.asarray(scope_mask, dtype=bool) & np.isfinite(prediction)
    candidates: list[int] = []
    for segment in _continuous_segments(np.flatnonzero(selected), times):
        if segment.size < 3:
            continue
        values = prediction[segment]
        scale = float(np.percentile(values, 95) - np.percentile(values, 50))
        prominence = max(prominence_fraction * scale, _MINIMUM_PROMINENCE)
        peaks, _ = find_peaks(values, prominence=prominence)
        candidates.extend(int(segment[p]) for p in peaks)
    return sorted(candidates)


def match_peaks_one_to_one(
    obs_positions,
    candidate_positions,
    *,
    window_hours: int = 36,
) -> list[tuple[int, int | None]]:
    """Order-preserving one-to-one matching of observed peaks to candidates.

    Positions must be in a common numeric time coordinate (hours). Maximizes
    the number of matched pairs with ``|dt| <= window_hours`` and, among
    those, minimizes the total absolute time difference. Returns one
    ``(obs_index, candidate_index_or_None)`` entry per observed peak, in order.
    """
    obs = list(obs_positions)
    cand = list(candidate_positions)
    n, m = len(obs), len(cand)
    # dp[i][j] = best (matches, -cost) achievable for obs[i:], cand[j:]
    dp = [[(0, 0)] * (m + 1) for _ in range(n + 1)]
    for i in range(n - 1, -1, -1):
        for j in range(m - 1, -1, -1):
            best = dp[i + 1][j]  # leave obs[i] unmatched
            skip_candidate = dp[i][j + 1]
            if skip_candidate > best:
                best = skip_candidate
            if abs(obs[i] - cand[j]) <= window_hours:
                matches, negative_cost = dp[i + 1][j + 1]
                paired = (matches + 1, negative_cost - abs(obs[i] - cand[j]))
                if paired > best:
                    best = paired
            dp[i][j] = best
    matches: list[tuple[int, int | None]] = []
    i = j = 0
    while i < n:
        if j < m and abs(obs[i] - cand[j]) <= window_hours:
            paired = (
                dp[i + 1][j + 1][0] + 1,
                dp[i + 1][j + 1][1] - abs(obs[i] - cand[j]),
            )
            if paired == dp[i][j]:
                matches.append((i, j))
                i += 1
                j += 1
                continue
        if j < m and dp[i][j + 1] == dp[i][j]:
            j += 1
            continue
        matches.append((i, None))
        i += 1
    return matches


def _rise_start_position(
    values: np.ndarray,
    allowed: np.ndarray,
    hours: np.ndarray,
    peak_position: int,
    *,
    window_hours: int,
    rise_fraction: float,
) -> float:
    """Last position at or below base + rise_fraction * amplitude before the peak.

    The lookback is restricted to the contiguous run of allowed (in-scope,
    finite) positions ending at the peak and to ``window_hours`` real hours,
    so it can never read values across an excluded window or a data gap.
    """
    start = peak_position
    while (
        start > 0
        and allowed[start - 1]
        and hours[peak_position] - hours[start - 1] <= window_hours
    ):
        start -= 1
    window = values[start:peak_position + 1]
    if not np.isfinite(window).any():
        return float("nan")
    base = float(np.nanmin(window))
    level = base + rise_fraction * (float(values[peak_position]) - base)
    below = np.flatnonzero(window <= level)
    if below.size == 0:
        return float("nan")
    return float(start + below[-1])


def evaluate_event_peaks(
    forecast,
    observed,
    valid_times,
    scope_mask,
    *,
    height: float | None = None,
    min_separation_hours: int = 72,
    window_hours: int = 36,
    prominence_fraction: float = 0.10,
    rise_fraction: float = 0.10,
    high_flow_quantile: float = 0.95,
) -> dict:
    """Per-event one-to-one peak evaluation of one forecast series.

    Returns ``{"events": [...], "summary": {...}}``. Uncaptured events count
    as misses in the capture rate and the +/-6 h hit rate, so dropping peaks
    is never rewarded.
    """
    prediction = np.asarray(forecast, dtype=float)
    target = np.asarray(observed, dtype=float)
    times = pd.DatetimeIndex(valid_times)
    selected = np.asarray(scope_mask, dtype=bool)
    if not (prediction.size == target.size == times.size == selected.size):
        raise ValueError("forecast, observed, valid_times, and scope_mask must align")

    events, event_height = detect_observed_events(
        target,
        times,
        selected,
        height=height,
        min_separation_hours=min_separation_hours,
        window_hours=window_hours,
    )
    candidates = detect_forecast_candidates(
        prediction, times, selected, prominence_fraction=prominence_fraction
    )
    # match in real-hour coordinates so a data gap between segments can never
    # make two distant peaks look adjacent through their array positions
    hours = np.asarray((times - times[0]) / pd.Timedelta(hours=1), dtype=float)
    matches = match_peaks_one_to_one(
        [hours[event["position"]] for event in events],
        [hours[position] for position in candidates],
        window_hours=window_hours,
    )
    observed_allowed = selected & np.isfinite(target)
    forecast_allowed = selected & np.isfinite(prediction)

    event_rows: list[dict] = []
    for (event_index, candidate_index), event in zip(matches, events):
        row = {
            "obs_peak_time": event["time"],
            "obs_peak_m3s": event["peak_m3s"],
            "captured": candidate_index is not None,
            "forecast_peak_time": pd.NaT,
            "forecast_peak_m3s": float("nan"),
            "peak_time_error_h": float("nan"),
            "abs_peak_time_error_h": float("nan"),
            "peak_flow_error_m3s": float("nan"),
            "rise_start_error_h": float("nan"),
        }
        if candidate_index is not None:
            forecast_position = candidates[candidate_index]
            delta = int(round(hours[forecast_position] - hours[event["position"]]))
            observed_rise = _rise_start_position(
                target,
                observed_allowed,
                hours,
                event["position"],
                window_hours=window_hours,
                rise_fraction=rise_fraction,
            )
            forecast_rise = _rise_start_position(
                prediction,
                forecast_allowed,
                hours,
                forecast_position,
                window_hours=window_hours,
                rise_fraction=rise_fraction,
            )
            row.update({
                "forecast_peak_time": times[forecast_position],
                "forecast_peak_m3s": float(prediction[forecast_position]),
                "peak_time_error_h": delta,
                "abs_peak_time_error_h": abs(delta),
                "peak_flow_error_m3s": float(
                    prediction[forecast_position] - event["peak_m3s"]
                ),
                "rise_start_error_h": (
                    int(round(hours[int(forecast_rise)] - hours[int(observed_rise)]))
                    if np.isfinite(forecast_rise) and np.isfinite(observed_rise)
                    else float("nan")
                ),
            })
        event_rows.append(row)

    captured = [row for row in event_rows if row["captured"]]
    abs_errors = np.asarray(
        [row["abs_peak_time_error_h"] for row in captured], dtype=float
    )
    n_events = len(event_rows)
    high_flow = (
        selected
        & np.isfinite(target)
        & np.isfinite(prediction)
    )
    finite_target = target[np.asarray(scope_mask, dtype=bool) & np.isfinite(target)]
    high_flow_threshold = (
        float(np.quantile(finite_target, high_flow_quantile))
        if finite_target.size
        else float("nan")
    )
    high_flow &= target > high_flow_threshold
    high_flow_residual = prediction[high_flow] - target[high_flow]

    summary = {
        "n_events": n_events,
        "n_captured": len(captured),
        "capture_rate": (len(captured) / n_events) if n_events else float("nan"),
        "hit_rate_within_6h": (
            float(np.sum(abs_errors <= 6.0) / n_events) if n_events else float("nan")
        ),
        "mean_abs_peak_time_error_h": (
            float(np.mean(abs_errors)) if captured else float("nan")
        ),
        "median_abs_peak_time_error_h": (
            float(np.median(abs_errors)) if captured else float("nan")
        ),
        "peak_time_errors_h": [row["peak_time_error_h"] for row in event_rows],
        "mean_peak_flow_error_m3s": (
            float(np.mean([row["peak_flow_error_m3s"] for row in captured]))
            if captured
            else float("nan")
        ),
        "mean_abs_peak_flow_error_m3s": (
            float(np.mean([abs(row["peak_flow_error_m3s"]) for row in captured]))
            if captured
            else float("nan")
        ),
        "mean_abs_rise_start_error_h": (
            float(np.nanmean(np.abs([row["rise_start_error_h"] for row in captured])))
            if captured
            and np.isfinite([row["rise_start_error_h"] for row in captured]).any()
            else float("nan")
        ),
        "event_height_threshold_m3s": event_height,
        "high_flow_threshold_m3s": high_flow_threshold,
        "n_high_flow": int(high_flow.sum()),
        "high_flow_mae_m3s": (
            float(np.mean(np.abs(high_flow_residual)))
            if high_flow_residual.size
            else float("nan")
        ),
        "high_flow_bias_m3s": (
            float(np.mean(high_flow_residual))
            if high_flow_residual.size
            else float("nan")
        ),
    }
    return {"events": event_rows, "summary": summary}


def alignment_errors(
    valid_times,
    issue_times,
    lead_hours: int,
    observed_at_valid,
    reference_times,
    reference_observed,
) -> dict:
    """Check valid-time bookkeeping and observation alignment.

    ``max_valid_time_error_seconds`` is the worst |valid - (issue + lead)|.
    ``max_observation_alignment_error_m3s`` re-indexes an independent reference
    observation series at the valid times and compares it with the observation
    values the evaluation actually used.
    """
    valid = pd.DatetimeIndex(valid_times)
    issue = pd.DatetimeIndex(issue_times)
    expected = issue + pd.to_timedelta(int(lead_hours), unit="h")
    time_errors = np.abs((valid - expected) / pd.Timedelta(seconds=1))
    reference = pd.Series(
        np.asarray(reference_observed, dtype=float),
        index=pd.DatetimeIndex(reference_times),
    )
    re_indexed = reference.reindex(valid).to_numpy()
    used = np.asarray(observed_at_valid, dtype=float)
    finite = np.isfinite(re_indexed) & np.isfinite(used)
    observation_errors = (
        np.abs(re_indexed[finite] - used[finite]) if finite.any() else np.asarray([0.0])
    )
    return {
        "max_valid_time_error_seconds": float(np.max(time_errors)),
        "max_observation_alignment_error_m3s": float(np.max(observation_errors)),
    }
