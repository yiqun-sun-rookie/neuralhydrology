"""run_calibration.py

主入口: 半分布式水文模型参数优化/评价 (统一模式)
- 单一配置源: 使用 run_config.yml；其它 CLI 仅保留 --run-config。
"""
from __future__ import annotations
import sys
from pathlib import Path

# 先将工程根目录加入 sys.path，避免直接以路径运行时包导入失败
# Script lives at scripts/core_optimization/namou_kuwei/run_calibration.py — repo root is parents[3]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.runtime.semi_distributed.entry_points import run_optimization_cli

if __name__ == '__main__':
    run_optimization_cli()
