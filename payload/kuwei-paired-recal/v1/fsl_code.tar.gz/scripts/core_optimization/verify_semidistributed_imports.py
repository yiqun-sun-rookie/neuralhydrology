from __future__ import annotations

import re
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]


OLD_IMPORT_RE = re.compile(
    r"experiments\.semi_distributed\.da\."
    r"(xaj_backend|streaming_backend|simulate_series|hydro_types|"
    r"da_config_utils|snowmelt_controls|snowmelt_service|adapters)"
)


SCAN_ROOTS = (
    "experiments",
    "src",
    "scripts",
    "basins",
    "tests",
)


ALLOW_SUBPATHS = (
    # no allow-list: legacy imports are fully forbidden now
)


def _should_skip(path: Path) -> bool:
    rel = path.relative_to(PROJECT_ROOT)
    rel_posix = rel.as_posix()
    if "/__pycache__/" in f"/{rel_posix}/":
        return True
    for allowed in ALLOW_SUBPATHS:
        if rel == allowed or allowed in rel.parents:
            return True
    return False


def main() -> int:
    offenders: list[str] = []
    for root in SCAN_ROOTS:
        base = PROJECT_ROOT / root
        if not base.exists():
            continue
        for py in base.rglob("*.py"):
            if _should_skip(py):
                continue
            text = py.read_text(encoding="utf-8", errors="replace")
            for lineno, line in enumerate(text.splitlines(), start=1):
                if OLD_IMPORT_RE.search(line):
                    offenders.append(f"{py.relative_to(PROJECT_ROOT)}:{lineno}: {line.strip()}")

    if offenders:
        print("[FAIL] Found forbidden legacy semi_distributed imports:")
        for row in offenders:
            print(f"  - {row}")
        return 1

    print("[PASS] semi_distributed import verification passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
