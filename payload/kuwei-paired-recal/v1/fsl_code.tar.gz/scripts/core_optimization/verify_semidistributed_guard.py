from __future__ import annotations

import subprocess
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]


CHECKS: list[list[str]] = [
    [sys.executable, "scripts/verify_semidistributed_imports.py"],
    [sys.executable, "scripts/verify_results_layout.py"],
    [
        sys.executable,
        "-m",
        "pytest",
        "-q",
        "tests/smoke/test_semidistributed_imports.py",
        "tests/smoke/test_snowmelt_controls.py",
        "tests/smoke/test_hydro_forcing_controls.py",
        "tests/unit/da/test_streaming_backend.py",
    ],
]


def run(cmd: list[str]) -> None:
    print(f"[RUN] {' '.join(cmd)}")
    completed = subprocess.run(cmd, cwd=PROJECT_ROOT)
    if completed.returncode != 0:
        raise SystemExit(completed.returncode)


def main() -> int:
    for cmd in CHECKS:
        run(cmd)
    print("[PASS] semi_distributed guard checks passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
