import os
import pandas as pd

import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import os
import pandas as pd


def plot_meteo_time_series(flood_event, var_columns, time_col='time', save_dir=None):
    """
    为每个气象要素绘制时间序列图，横坐标为时间（年月日），纵坐标为要素值。

    参数:
    -------
    flood_event : pd.DataFrame
        包含 'time' 列和各个要素列的 DataFrame。
    var_columns : list of str
        要绘制的要素列名列表，例如 ['temperature', 'p_1', 'evap']。
    time_col : str, optional
        时间列的名称，默认为 'time'。
    save_dir : str, optional
        如果提供，将图表保存到该目录；否则，仅显示图表。
    """

    # 确保 'time' 列是 datetime 类型
    if not pd.api.types.is_datetime64_any_dtype(flood_event[time_col]):
        flood_event[time_col] = pd.to_datetime(flood_event[time_col])

    # 为每个要素绘制图表
    for var in var_columns:
        if var not in flood_event.columns:
            print(f"警告: 列 '{var}' 不存在于 flood_event 中，跳过。")
            continue

        # 创建一个新的图表
        plt.figure(figsize=(12, 6))

        # 绘制折线图
        plt.plot(flood_event[time_col], flood_event[var], label=var)

        # 设置标题和标签
        plt.title(f'Time Series of {var}')
        plt.xlabel('时间 (年-月-日)')
        plt.ylabel(var)

        # 设置横坐标格式为年月日
        plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
        plt.gca().xaxis.set_major_locator(mdates.AutoDateLocator())

        # 旋转日期标签以避免重叠
        plt.gcf().autofmt_xdate()

        # 显示图例
        plt.legend()

        # 如果提供了 save_dir，则保存图表
        if save_dir:
            os.makedirs(save_dir, exist_ok=True)
            save_path = os.path.join(save_dir, f'{var}_time_series.png')
            plt.savefig(save_path)
            print(f"图表已保存到: {save_path}")
        else:
            # 否则，显示图表
            plt.show()

        # 关闭当前图表以释放内存
        plt.close()

def collect_meteo_csvs(base_dir, var_folders, start_year=2006, end_year=2020):
    """
    根据 var_folders 和指定年份范围，自动收集每个 (var_folder, year, month) 对应的
    CSV 文件路径。假设文件命名符合:
       yingluoxia_mean_{var_folder}_{yyyyMM}.csv
    并存放于:
       {base_dir}/{var_folder}/mean/

    若任意一个目标文件不存在，则立刻 raise FileNotFoundError。

    返回:
    -------
    meteo_csvs : dict
        字典形式: {var_folder: [文件路径1, 文件路径2, ...], ...}
        每个 var_folder 对应它在整个年份范围内的所有 CSV 路径。
    """

    meteo_csvs = {}
    for var_folder in var_folders:
        file_list = []
        for year in range(start_year, end_year + 1):
            for month in range(1, 13):
                ym = f"{year}{month:02d}"
                # 假设文件名形如 yingluoxia_mean_{var_folder}_{yyyyMM}.csv
                if var_folder == "derived_rain":
                    fname = f"yingluoxia_mean_rain_{ym}.csv"
                elif var_folder == "derived_snow":
                    fname = f"yingluoxia_mean_snow_{ym}.csv"
                elif var_folder == "pet_hargreaves":
                    fname = f"yingluoxia_mean_pet_{ym}.csv"
                elif var_folder == "precipitation":
                    fname = f"yingluoxia_mean_prec_{ym}.csv"
                else:
                    fname = f"yingluoxia_mean_{var_folder}_{ym}.csv"

                full_path = os.path.join(base_dir, var_folder, "mean", fname)

                if not os.path.exists(full_path):
                    raise FileNotFoundError(f"未找到文件: {full_path}")
                file_list.append(full_path)
        meteo_csvs[var_folder] = file_list
    return meteo_csvs


def combine_collected_meteo_csvs(meteo_csvs, var_mapping=None):
    """
    将 collect_meteo_csvs 返回的结果(多要素多文件) 合并到一个 DataFrame。
    每个文件都包含列 [time, basin_mean_value]，其中:
      - time: 3小时或其他时间分辨率
      - basin_mean_value: 不同要素的数值

    合并逻辑:
      1) 对于同一要素var_folder的所有文件(多月份), 先纵向concat (行拼接)
      2) 重命名 "basin_mean_value" => var_mapping里配置的列名, 如 'temperature','p_1','evap' 等
      3) 将此要素对应的DataFrame与全局flood_event做一次 outer merge(on='time')

    参数:
    -------
    meteo_csvs : dict
        由 collect_meteo_csvs 返回, 如 {var_folder: [csv1, csv2, ...], ...}
    var_mapping : dict or None
        用于将 var_folder 映射到 simulate_flood 需要的列名, 例如:
          {
            'temp': 'temperature',
            'precipitation': 'p_1',
            'evap': 'evap',
            ...
          }
        若未提供或某个var_folder不在此字典里, 将默认列名 "{var_folder}_value"

    返回:
    -------
    flood_event : pd.DataFrame
        列至少包含: 'time', 以及相应的要素列('p_1','temperature','evap',...).
        若后面要给 simulate_flood 用, 还需把 'floods_discharge' 列加上(可自行添加).
    """

    if var_mapping is None:
        var_mapping = {}

    flood_event = None  # 全局合并结果

    for var_folder, file_list in meteo_csvs.items():
        # 对同一要素的所有月度CSV进行"行拼接" (concat)
        df_all = []
        for csv_path in file_list:
            df_ = pd.read_csv(csv_path, parse_dates=['time'])
            # 排序 + 重置index
            df_.sort_values('time', inplace=True)
            df_.reset_index(drop=True, inplace=True)
            df_all.append(df_)

        # 将此要素所有月份合并
        if len(df_all) > 0:
            combined_df = pd.concat(df_all, axis=0, ignore_index=True)
        else:
            # 不太可能出现, 因为若 var_folder 有文件就会append
            continue

        # 重命名列
        # 若 var_folder 在 var_mapping里, 用指定列名; 否则默认 "{var_folder}_value"
        col_name = var_mapping.get(var_folder, f"{var_folder}_value")
        combined_df.rename(columns={'basin_mean_value': col_name}, inplace=True)

        # merge到全局flood_event
        if flood_event is None:
            flood_event = combined_df
        else:
            flood_event = pd.merge(
                flood_event, combined_df,
                on='time', how='outer'
            )

    # 整理最终结果
    if flood_event is not None:
        flood_event.sort_values('time', inplace=True)
        flood_event.reset_index(drop=True, inplace=True)

    return flood_event


if __name__ == "__main__":

    # 1) 收集多要素多个年份的文件列表
    # base_dir = r"C:\Users\yiqun\PycharmProjects\forecast_system_lite\data\processed\yingluoxia"

    base_dir = r"F:\github\pycharm\projects\forecast_system_lite\data\processed\yingluoxia"
    var_folders = ["temp", "derived_rain", "derived_snow", "pet_hargreaves", "precipitation"]  # 测试: 只收集temp; 或加 "precipitation","evap"等
    collected = collect_meteo_csvs(
        base_dir=base_dir,
        var_folders=var_folders,
        start_year=2006,
        end_year=2020
    )
    print("已收集文件(分要素):")
    for vf, paths in collected.items():
        print(f"  {vf}: {len(paths)} 文件")

    # 2) 合并各要素到一个 DF, 映射到 simulate_flood 需要的列名
    var_mapping = {
        'temp': 'temperature',         # temp -> temperature
        'derived_rain': 'rain',        # 降水 -> p_1
        'derived_snow': 'snow',                 # 蒸发 -> evap
        "pet_hargreaves": "pet",
        'precipitation': 'prec',  #
        # 如果还有 'derived_snow' => 'p_2' 或其他, 可继续添加
    }
    flood_event = combine_collected_meteo_csvs(collected, var_mapping=var_mapping)
    print("合并后flood_event列:", flood_event.columns.tolist())
    print("flood_event前5行:\n", flood_event.head(5))

    # # 3) 若后续给 simulate_flood 用, 需要 'floods_discharge' 列; 这里示例设为 0
    # if flood_event is not None:
    #     if 'floods_discharge' not in flood_event.columns:
    #         flood_event['floods_discharge'] = 0.0
    #
    #     print("最终可给simulate_flood使用的 flood_event 已准备完毕.")
    #
    # else:
    #     print("警告: flood_event为空, 无可用数据.")

    var_columns = list(var_mapping.values())  # 例如 ['temperature', 'p_1', 'evap']
    # 新增保存代码
    output_csv_path = os.path.join(base_dir, "meteo_data.csv")
    flood_event.to_csv(output_csv_path, index=False, encoding='utf-8-sig')
    print(f"成功保存合并后的气象数据到: {output_csv_path}")

    # # 调用绘图函数，显示图表
    # save_dir = r"C:\Users\yiqun\PycharmProjects\forecast_system_lite\data\processed\yingluoxia\temp\mean"
    # plot_meteo_time_series(flood_event, var_columns, save_dir=save_dir)  # 添加 save_dir= 指定参数名

