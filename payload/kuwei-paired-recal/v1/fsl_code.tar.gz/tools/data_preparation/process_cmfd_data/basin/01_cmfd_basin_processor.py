import os
import numpy as np
import pandas as pd
import netCDF4 as nc
import geopandas as gpd
from shapely.geometry import box
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import cartopy.crs as ccrs
import cartopy.feature as cfeature

# ======= 配置中文显示 =======
plt.rcParams['font.sans-serif'] = ['SimHei']  # 显示中文
plt.rcParams['axes.unicode_minus'] = False    # 正确显示负号

# ---------------------------------------------------------------------------
# 1) 下面是你已有的函数, 我们只做了少量改�����以支持循环批量处理
# ---------------------------------------------------------------------------

def read_cmfd_single_var(file_path):
    """
    读取CMFD单变量数据，并返回:
    - data_dict: 包含 time, lon, lat, var_name(数组) 的字典
    - var_name:  变量名(从文件名推断)
    - year, month: 年和月(从文件名解析得到)
    """
    dataset = nc.Dataset(file_path, mode='r')
    data_dict = {}

    file_name = os.path.basename(file_path)
    var_name = file_name.split('_')[0]  # 例如 'prec'
    date_str = file_name.split('_')[-1].split('.')[0]  # 例如 '202006'
    year, month = date_str[:4], date_str[4:6]

    time_var = dataset.variables['time']
    # 将时间转为 Python datetime
    times = nc.num2date(time_var[:], units=time_var.units, only_use_cftime_datetimes=False)
    data_dict['time'] = pd.to_datetime(times)

    data_dict['lon'] = dataset.variables['lon'][:]
    data_dict['lat'] = dataset.variables['lat'][:]

    var_data = np.array(dataset.variables[var_name][:])
    # 处理缺失值
    if '_FillValue' in dataset.variables[var_name].ncattrs():
        fill_value = dataset.variables[var_name]._FillValue
        var_data = np.where(var_data == fill_value, np.nan, var_data)
    elif 'missing_value' in dataset.variables[var_name].ncattrs():
        fill_value = dataset.variables[var_name].missing_value
        var_data = np.where(var_data == fill_value, np.nan, var_data)
    data_dict[var_name] = var_data

    dataset.close()

    # 如果 lat 是从高到低排序，则翻转
    if data_dict['lat'][0] > data_dict['lat'][-1]:
        data_dict['lat'] = data_dict['lat'][::-1]
        data_dict[var_name] = data_dict[var_name][:, ::-1, :]

    return data_dict, var_name, year, month


def generate_mask(shapefile, lon, lat, mask_path=None, buffer_degree=0.2):
    """
    生成或加载流域掩膜（空间范围优化版）。
    若 mask_path 存在且文件可读，则直接加载已有掩膜；否则重新计算并保存。
    返回:
     - mask: (lat, lon)形状的布尔数组，True表示落在流域内
     - basin_bbox: 流域边界(最小x, 最小y, 最大x, 最大y)
    """
    # 如果已经有计算好的 mask 文件，则直接加载
    if mask_path and os.path.exists(mask_path):
        mask = np.load(mask_path)
        basin = gpd.read_file(shapefile).to_crs(epsg=4326)
        basin_bbox = basin.total_bounds
        return mask, basin_bbox

    # 否则重新生成
    basin = gpd.read_file(shapefile).to_crs(epsg=4326)
    basin.geometry = basin.geometry.buffer(0)  # 修复可能的几何问题
    basin_bbox = basin.total_bounds
    print(f"流域边界范围: {basin_bbox}")

    res_lon = abs(np.mean(np.diff(lon)))
    res_lat = abs(np.mean(np.diff(lat)))
    print(f"经度分辨率: {res_lon:.4f}°, 纬度分辨率: {res_lat:.4f}°")

    mask = np.zeros((len(lat), len(lon)), dtype=bool)

    # 利用边界范围 + buffer 来减少遍历范围
    lon_indices = np.where((lon >= basin_bbox[0] - buffer_degree) & (lon <= basin_bbox[2] + buffer_degree))[0]
    lat_indices = np.where((lat >= basin_bbox[1] - buffer_degree) & (lat <= basin_bbox[3] + buffer_degree))[0]
    print(f"需要遍历的经度索引数量: {len(lon_indices)}, 纬度索引数量: {len(lat_indices)}")

    # 建立空间索引，加速多边形碰撞检测
    basin_sindex = basin.sindex

    for i in lat_indices:
        for j in lon_indices:
            cell = box(lon[j] - res_lon / 2, lat[i] - res_lat / 2,
                       lon[j] + res_lon / 2, lat[i] + res_lat / 2)
            possible_matches = list(basin_sindex.intersection(cell.bounds))
            if len(possible_matches) > 0:
                if cell.intersects(basin.unary_union):
                    mask[i, j] = True

    # 可视化检查(可选)
    fig, ax = plt.subplots(figsize=(10, 8))
    basin.plot(ax=ax, color='blue', alpha=0.5, label='流域边界')
    yy, xx = np.where(mask)
    for y, x in zip(yy, xx):
        cell = box(lon[x] - res_lon / 2, lat[y] - res_lat / 2,
                   lon[x] + res_lon / 2, lat[y] + res_lat / 2)
        gpd.GeoSeries([cell]).boundary.plot(ax=ax, color='red', linewidth=0.5)

    plt.title("掩膜生成结果验证（红色网格为激活区域）")
    plt.xlabel("经度")
    plt.ylabel("纬度")
    plt.legend()
    plt.savefig('mask_verification.png')
    plt.close()

    # 将掩膜保存为npy文件，便于下次直接读取
    if mask_path:
        np.save(mask_path, mask)

    return mask, basin_bbox


def plot_basin_mean_precipitation(cmfd_data, mask, var_name):
    """
    绘制流域平均要素的时间序列图，并返回该时序数组。
    - 若是prec(降水)，自动乘以10800 (kg m^-2 s^-1 -> mm/3h)
    - 若是temp(温度)，从K转到°C (减去273.15)
    - 否则保持原单位不变
    """
    if var_name.startswith('prec'):
        data_converted = cmfd_data[var_name] * 10800  # kg m^-2 s^-1 -> mm/3h
        ylabel_txt = '降水量 (mm/3h)'
        title_txt = '流域平均降水'
    elif var_name.startswith('derived_snow'):
        data_converted = cmfd_data[var_name]  * 10800  # kg m^-2 s^-1 -> mm/3h
        ylabel_txt = '雪深 (mm/3h)'
        title_txt = '流域平均雪深'
    elif var_name.startswith('snow'):
        data_converted = cmfd_data[var_name]  * 10800
        ylabel_txt = 'snow_avg (mm/3h)'
        title_txt = '流域平均 snow'
    elif var_name.startswith('rain'):
        data_converted = cmfd_data[var_name]  * 10800
        ylabel_txt = 'rain_avg (mm/3h)'
        title_txt = '流域平均 rain'
    elif var_name.startswith('temp'):
        data_converted = cmfd_data[var_name] - 273.15  # K -> °C
        ylabel_txt = '温度 (°C)'
        title_txt = '流域平均温度'
    else:
        data_converted = cmfd_data[var_name]
        ylabel_txt = f'{var_name} (原单位)'
        title_txt = f'流域平均 {var_name}'

    masked_data = np.where(mask, data_converted, np.nan)
    basin_mean_data = np.nanmean(masked_data, axis=(1, 2))  # 对空间维度(1,2)取��均

    # 绘图
    fig, ax = plt.subplots(figsize=(15, 5))
    ax.plot(cmfd_data['time'], basin_mean_data, 'b-', label=f'{title_txt}')
    ax.set_xlabel('时间 (年-月-日 时)')
    ax.set_ylabel(ylabel_txt)
    ax.set_title(f'{title_txt} - {cmfd_data["time"][0].strftime("%Y-%m")}')
    ax.grid(True)
    ax.legend()
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d %H:%M'))
    plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
    plt.tight_layout()
    # 输出图文件名中也可包含 var_name
    plt.savefig(f'basin_mean_{var_name}.png', dpi=300)
    plt.close()

    return basin_mean_data


def plot_grid_precipitation(cmfd_data, mask, var_name, basin_bbox, num_time_steps=5):
    """
    按给定时间步数，绘制被掩膜后的要素在空间上的分布(网格图)。
    - 若是prec(降水)，自动乘以10800 (kg m^-2 s^-1 -> mm/3h)
    - 若是temp(温度)，从K转到°C (减去273.15)
    - 否则保持原单位不变
    """
    if var_name.startswith('prec'):
        data_converted = cmfd_data[var_name] * 10800
        cbar_label = '降水量 (mm/3h)'
    elif var_name.startswith('derived_snow'):
        data_converted = cmfd_data[var_name] * 10800
        cbar_label = 'derived_snow (mm)'
    elif var_name.startswith('snow'):
        data_converted = cmfd_data[var_name] * 10800
        cbar_label = 'snow (mm)'
    elif var_name.startswith('rain'):
        data_converted = cmfd_data[var_name] * 10800
        cbar_label = 'rain (mm)'
    elif var_name.startswith('temp'):
        data_converted = cmfd_data[var_name] - 273.15
        cbar_label = '温度 (°C)'
    else:
        data_converted = cmfd_data[var_name]
        cbar_label = f'{var_name} (原单位)'

    lon, lat = np.meshgrid(cmfd_data['lon'], cmfd_data['lat'])
    time_indices = np.linspace(0, len(cmfd_data['time']) - 1, num_time_steps, dtype=int)

    minx, miny, maxx, maxy = basin_bbox
    buffer = 0.5
    extent = [minx - buffer, maxx + buffer, miny - buffer, maxy + buffer]

    for t_idx in time_indices:
        fig, ax = plt.subplots(figsize=(10, 8), subplot_kw={'projection': ccrs.PlateCarree()})
        data_t = data_converted[t_idx, :, :]
        data_masked = np.where(mask, data_t, np.nan)

        im = ax.pcolormesh(lon, lat, data_masked, cmap='Blues', transform=ccrs.PlateCarree())
        ax.coastlines()
        ax.add_feature(cfeature.BORDERS, linestyle=':')
        plt.colorbar(im, ax=ax, label=cbar_label)

        ax.set_extent(extent, crs=ccrs.PlateCarree())
        time_str = cmfd_data["time"][t_idx].strftime("%Y-%m-%d %H:%M")
        ax.set_title(f'{var_name} 空间分布 - {time_str}')
        plt.tight_layout()

        # 输出文件名也可包含 var_name
        filename = f'grid_{var_name}_{cmfd_data["time"][t_idx].strftime("%Y%m%d_%H%M")}.png'
        # 注意：这里的 save_path 是硬编码的，更好��做法是在主程序中定义
        save_path = os.path.join(r"C:\Users\yiqun\PycharmProjects\forecast_system_lite\results\figures", filename)

        # 在保存前确保目录存在
        os.makedirs(os.path.dirname(save_path), exist_ok=True)

        plt.savefig(save_path, dpi=600)
        plt.close()

    return time_indices


def save_masked_to_netcdf(cmfd_data, mask, var_name, out_path):
    """
    将掩膜后的单要素月度数据保存为 NetCDF 文件(存于 out_path)。
    注意：若是prec等，需要在外部决定是否做单位转换，这里只做掩膜操作。
    """
    lat = cmfd_data['lat']
    lon = cmfd_data['lon']
    times = cmfd_data['time']
    data_var = cmfd_data[var_name]

    times_pydatetime = times.to_pydatetime()

    # 掩膜操作
    masked_data = np.where(mask, data_var, np.nan)

    with nc.Dataset(out_path, 'w', format='NETCDF4') as ds:
        ds.createDimension('time', len(times_pydatetime))
        ds.createDimension('lat', len(lat))
        ds.createDimension('lon', len(lon))

        time_var = ds.createVariable('time', 'f8', ('time',))
        lat_var = ds.createVariable('lat', 'f4', ('lat',))
        lon_var = ds.createVariable('lon', 'f4', ('lon',))

        masked_var = ds.createVariable(
            var_name, 'f4',
            ('time', 'lat', 'lon'),
            fill_value=np.nan,
            zlib=True
        )

        # 写入坐标
        time_var.units = 'seconds since 1970-01-01 00:00:00'
        time_var.calendar = 'gregorian'

        time_var[:] = nc.date2num(times_pydatetime, units=time_var.units, calendar=time_var.calendar)
        lat_var[:] = lat
        lon_var[:] = lon

        masked_var[:] = masked_data
        masked_var.long_name = f"Masked {var_name}"
        masked_var.units = '原单位(kg m^-2 s^-1 或其他)'  # 根据具体要素修改

        ds.description = f"Masked CMFD data for {var_name}"
        ds.history = f"Created by save_masked_to_netcdf on {pd.to_datetime('now')}"
        ds.source_file = os.path.basename(cmfd_data.get('source_file', 'unknown'))

    print(f"掩膜后数据已保存至: {out_path}")


def save_basin_mean_to_csv(times, basin_mean_data, out_path):
    """
    将流域平均要素时序保存为CSV文件。
    - times: 时间序列 (pd.DatetimeIndex)
    - basin_mean_data: 对应每个时间步的���域平均值
    - out_path: CSV 文件路径
    """
    df = pd.DataFrame({
        'time': times,
        'basin_mean_value': basin_mean_data
    })
    df.to_csv(out_path, index=False, date_format="%Y-%m-%d %H:%M")
    print(f"流域平均时序已保存至: {out_path}")

def plot_grid_precipitation_with_basin_new(cmfd_data, mask, var_name, basin_bbox, shapefile, output_dir, num_time_steps=5):
    import geopandas as gpd
    from cartopy.mpl.patch import geos_to_path
    import matplotlib.pyplot as plt
    import cartopy.crs as ccrs
    import cartopy.feature as cfeature
    import numpy as np
    import os

    # 读取流域 shapefile
    basin_geom = gpd.read_file(shapefile).to_crs(epsg=4326)

    # 获取流域的边界盒 (minx, miny, maxx, maxy)
    minx, miny, maxx, maxy = basin_geom.total_bounds

    # 计算流域的宽高比
    lon_range = maxx - minx
    lat_range = maxy - miny
    aspect_ratio = lon_range / lat_range if lat_range != 0 else 1.0

    # 设置图像的宽高比，基础宽度为10英寸
    base_width = 10
    fig_height = base_width / aspect_ratio

    if var_name.startswith('prec'):
        data_converted = cmfd_data[var_name] * 10800
        cbar_label = '降水量 (mm/3h)'
    elif var_name.startswith('derived_snow'):
        data_converted = cmfd_data[var_name] * 10800
        cbar_label = 'derived_snow (mm)'
    elif var_name.startswith('snow'):
        data_converted = cmfd_data[var_name] * 10800
        cbar_label = 'snow (mm)'
    elif var_name.startswith('rain'):
        data_converted = cmfd_data[var_name] * 10800
        cbar_label = 'rain (mm)'
    elif var_name.startswith('temp'):
        data_converted = cmfd_data[var_name] - 273.15
        cbar_label = '温度 (°C)'
    else:
        data_converted = cmfd_data[var_name]
        cbar_label = f'{var_name} (原单位)'

    # 创建网格坐标
    lon, lat = np.meshgrid(cmfd_data['lon'], cmfd_data['lat'])
    time_indices = np.linspace(0, len(cmfd_data['time']) - 1, num_time_steps, dtype=int)

    # 循环绘制每个时间步的图像
    for t_idx in time_indices:
        # 创建图像，设置 figsize 基于流域的宽高比
        fig, ax = plt.subplots(figsize=(base_width, fig_height), subplot_kw={'projection': ccrs.PlateCarree()})
        data_t = data_converted[t_idx, :, :]
        data_masked = np.where(mask, data_t, np.nan)

        # 设置绘图边界为流��形状
        boundary = basin_geom.unary_union
        path = geos_to_path([boundary])[0]
        ax.set_boundary(path, transform=ccrs.PlateCarree())

        # 设置绘图范围为流域的边界盒
        ax.set_extent([minx, maxx, miny, maxy], crs=ccrs.PlateCarree())

        # 绘制网格数据
        im = ax.pcolormesh(lon, lat, data_masked, cmap='Blues', transform=ccrs.PlateCarree())

        # 添加海岸线和国境线
        ax.coastlines()
        ax.add_feature(cfeature.BORDERS, linestyle=':')

        # 叠加流域边界
        basin_geom.boundary.plot(ax=ax, color='black', linewidth=1, transform=ccrs.PlateCarree())

        # 添加颜色条
        plt.colorbar(im, ax=ax, label=cbar_label)

        # 设置标题并保存图像
        time_str = cmfd_data["time"][t_idx].strftime("%Y-%m-%d %H:%M")
        ax.set_title(f'{var_name} 空间分布 - {time_str}')
        plt.tight_layout()

        filename = f'grid_{var_name}_{cmfd_data["time"][t_idx].strftime("%Y%m%d_%H%M")}.png'
        # 使用传入的 output_dir 构建保存路径
        save_path = os.path.join(output_dir, filename)

        # 在保存前确保目录存在 (虽然主程序已经创建，但函数内多一层保险更好)
        os.makedirs(os.path.dirname(save_path), exist_ok=True)

        plt.savefig(save_path, dpi=600)
        plt.close()

    return time_indices
def plot_grid_precipitation_with_basin(cmfd_data, mask, var_name, basin_bbox, shapefile, num_time_steps=5):
    """
    与原先 plot_grid_precipitation 功能相同，但额外叠加流域边界(黑色)。

    参数说明：
    ----------
    cmfd_data : dict
        包含 'time','lon','lat','var_name' 等键值的字典
    mask : np.ndarray
        shape=(len(lat), len(lon))的布尔数组, True表示落在流域内
    var_name : str
        CMFD变量名，如 'prec'/'temp'/'derived_snow'...
    basin_bbox : tuple
        (minx, miny, maxx, maxy) 流域的边界范围
    shapefile_path : str
        流域 shp 文件路径。函数内将读取后绘制黑色边界。
    num_time_steps : int
        需要绘图的时间步数量(从整段时序里等间隔抽取)
    """
    import geopandas as gpd

    # 1) 读取流域shp
    basin_geom = gpd.read_file(shapefile).to_crs(epsg=4326)

    # 2) 根据变量名，选择是否做单位转换
    if var_name.startswith('prec'):
        data_converted = cmfd_data[var_name] * 10800
        cbar_label = '降水量 (mm/3h)'
    elif var_name.startswith('derived_snow'):
        data_converted = cmfd_data[var_name] * 10800
        cbar_label = 'derived_snow (mm)'
    elif var_name.startswith('snow'):
        data_converted = cmfd_data[var_name] * 10800
        cbar_label = 'snow (mm)'
    elif var_name.startswith('rain'):
        data_converted = cmfd_data[var_name] * 10800
        cbar_label = 'rain (mm)'
    elif var_name.startswith('temp'):
        data_converted = cmfd_data[var_name] - 273.15
        cbar_label = '温度 (°C)'
    else:
        data_converted = cmfd_data[var_name]
        cbar_label = f'{var_name} (原单位)'

    lon, lat = np.meshgrid(cmfd_data['lon'], cmfd_data['lat'])
    time_indices = np.linspace(0, len(cmfd_data['time']) - 1, num_time_steps, dtype=int)

    minx, miny, maxx, maxy = basin_bbox
    buffer = 0.5  # 让地图四周留出一些空白，可按需调整
    extent = [minx - buffer, maxx + buffer, miny - buffer, maxy + buffer]

    for t_idx in time_indices:
        fig, ax = plt.subplots(figsize=(10, 8), subplot_kw={'projection': ccrs.PlateCarree()})
        data_t = data_converted[t_idx, :, :]
        data_masked = np.where(mask, data_t, np.nan)

        # 使用 pcolormesh 绘制网格
        im = ax.pcolormesh(lon, lat, data_masked, cmap='Blues', transform=ccrs.PlateCarree())

        # 加上海岸线和国境线等背景
        ax.coastlines()
        ax.add_feature(cfeature.BORDERS, linestyle=':')

        # 叠加流域shp边界：用黑色边线，不填充
        basin_geom.boundary.plot(
            ax=ax,
            color='black',  # 边界线颜色
            linewidth=1,  # 边界线宽
            transform=ccrs.PlateCarree()
        )

        # 加上颜色条
        plt.colorbar(im, ax=ax, label=cbar_label)

        # 设置地图范围
        ax.set_extent(extent, crs=ccrs.PlateCarree())

        # 设置标题并保存
        time_str = cmfd_data["time"][t_idx].strftime("%Y-%m-%d %H:%M")
        ax.set_title(f'{var_name} 空间分布 - {time_str}')
        plt.tight_layout()

        filename = f'grid_{var_name}_{cmfd_data["time"][t_idx].strftime("%Y%m%d_%H%M")}.png'
        save_path = os.path.join(r"C:\Users\yiqun\PycharmProjects\forecast_system_lite\results\figures", filename)

        # 在保存前确保目录存在
        os.makedirs(os.path.dirname(save_path), exist_ok=True)

        plt.savefig(save_path, dpi=600)
        plt.close()

    return time_indices


# ---------------------------------------------------------------------------
# 2) 主程序：遍历要素文件夹 & 每个月 *.nc 文件，分别处理
# ---------------------------------------------------------------------------
if __name__ == '__main__':
    # =========== 1. 动态路径配置 ===========
    # 获取项目根目录 (F:\github\pycharm\projects\forecast_system_lite)
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))

    basin_name = 'yingluoxia'

    # 使用 project_root 构建动态、跨平台的路径
    shapefile_path = os.path.join(project_root, 'data', 'raw', 'gis', 'yingluoxia', 'yingluoxia.shp')
    raw_data_root = os.path.join(project_root, 'data', 'raw', 'cmfd')
    processed_root = os.path.join(project_root, 'data', 'processed')
    figure_output_root = os.path.join(project_root, 'results', 'figures') # 新增：图片输出根目录

    # 确保输出目录存在
    os.makedirs(os.path.join(processed_root, basin_name), exist_ok=True)
    os.makedirs(figure_output_root, exist_ok=True)

    mask_output = os.path.join(processed_root, basin_name, f'{basin_name}_mask.npy')

    variable_folders = [
        # 'precipitation',  # 存放降水 nc 文件
        # 'temp',           # 存放温度 nc 文件
        # 'pres',         # 气压 ...
        # 'shum',         # 比湿 ...
        # 'rhum',         # 相对湿度 ...
        # 'wind',         # 风速 ...
        # 'srad',         # 短波辐射 ...
        # 'lrad',         # 长波辐射 ...
        # 'derived_snow',  # 衍生的雪深数据
        'derived_rain'
    ]

    # =========== 2. 生成(或加载)掩膜 ===========
    # 注意：我们假设所有要素的网格经纬度一致，因此只需从某个子文件夹里
    # 随便找一个 .nc 文件读取 lat/lon 即可。
    example_var = variable_folders[0]  # 第一个要素，例如 precipitation
    example_var_path = os.path.join(raw_data_root, example_var)
    example_file = None

    # 找到第一个nc当示例
    for f in sorted(os.listdir(example_var_path)):
        if f.endswith('.nc'):
            example_file = os.path.join(example_var_path, f)
            break

    if example_file is None:
        raise FileNotFoundError(f"在 {example_var_path} 下未找到任何nc文件，请检查。")

    # 读取该示例文件以获取lat/lon，用于生成或加载掩膜
    example_data, example_varname, _, _ = read_cmfd_single_var(example_file)
    example_lon = example_data['lon']
    example_lat = example_data['lat']

    # 生成或加载流域掩膜
    mask, basin_bbox = generate_mask(shapefile_path, example_lon, example_lat, mask_path=mask_output)

    # =========== 3. 遍历要素文件夹 & 内部每个月份 .nc文件，逐个处理 ===========
    for var_folder in variable_folders:
        print(f"\n=== 开始处理要素文件夹: {var_folder} ===")

        # 构造输出目录: .../processed/{basin_name}/{var_folder}/grid 和 /mean
        out_grid_dir = os.path.join(processed_root, basin_name, var_folder, 'grid')
        out_mean_dir = os.path.join(processed_root, basin_name, var_folder, 'mean')
        os.makedirs(out_grid_dir, exist_ok=True)
        os.makedirs(out_mean_dir, exist_ok=True)

        var_path = os.path.join(raw_data_root, var_folder)
        nc_files = [f for f in sorted(os.listdir(var_path)) if f.endswith('.nc')]
        if not nc_files:
            print(f"  * 未发现任何 .nc 文件于 {var_path}，跳过。")
            continue

        # 遍历该要素下的每个月份 .nc
        for nc_file in nc_files:
            nc_path = os.path.join(var_path, nc_file)
            print(f"  --> 正在处理: {nc_path}")
            cmfd_data, var_name, year, month = read_cmfd_single_var(nc_path)
            cmfd_data['source_file'] = nc_path  # 保留源文件信息

            # ---------- (a) 计算流域平均 & 绘制时序图 ----------
            basin_mean_data = plot_basin_mean_precipitation(cmfd_data, mask, var_name)

            # ---------- (b) 绘制若干时间步的空间分布图 ----------
            # (c) 绘制空间分布图
            # 注意：这里我们将图片输出根目录作为参数传递进去
            plot_grid_precipitation_with_basin_new(
                cmfd_data=cmfd_data,
                mask=mask,
                var_name=var_name,
                basin_bbox=basin_bbox,
                shapefile=shapefile_path,
                output_dir=figure_output_root, # 使用新定义的图片输出路径
                num_time_steps=3
            )

            # (d) 保存掩膜后的NetCDF
            out_nc_name = f"{var_name}_masked_{year}{month}.nc"
            out_nc_path = os.path.join(out_grid_dir, out_nc_name)
            save_masked_to_netcdf(cmfd_data, mask, var_name, out_path=out_nc_path)

            # ---------- (d) 保存流域平均序列到 mean 子目录 ----------
            # 文件名示例: {basin_name}_mean_{var_name}_{year}{month}.csv
            out_csv_name = f"{basin_name}_mean_{var_name}_{year}{month}.csv"
            out_csv_path = os.path.join(out_mean_dir, out_csv_name)
            save_basin_mean_to_csv(cmfd_data['time'], basin_mean_data, out_csv_path)

        print(f"=== 要素 {var_folder} 处理完毕 ===")

    print("\n所有要素的处理流程已完成。")

