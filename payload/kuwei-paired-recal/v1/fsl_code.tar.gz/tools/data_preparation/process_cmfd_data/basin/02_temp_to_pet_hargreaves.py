import os
import glob
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from src.kernels.core.hydro_model.process_model.evap.pyet.pyet.radiation import hargreaves

if __name__ == "__main__":
    # 0) 设置输入输出路径
    dir_in = r"C:\Users\yiqun\PycharmProjects\forecast_system_lite\data\processed\yingluoxia\temp\mean"
    dir_out = r"C:\Users\yiqun\PycharmProjects\forecast_system_lite\data\processed\yingluoxia\pet_hargreaves\mean"  # 输出目录

    # 1) 遍历目录中所有 CSV（假设文件名类似 "xxx_mean_temp_YYYYMM.csv"）
    file_list = glob.glob(os.path.join(dir_in, "*.csv"))
    file_list.sort()  # 可选，按名称排序

    # 2) 设置流域中心纬度(度)，并转成弧度
    lat_deg = 38.2
    lat_rad = lat_deg * np.pi / 180.0

    # 3) 循环处理每一个文件
    for fpath in file_list:
        print(f"\n正在处理: {fpath}")

        # (a) 读取 3 小时温度序列
        df_3h = pd.read_csv(fpath, parse_dates=['time'])
        df_3h.set_index('time', inplace=True)

        # 假设 'basin_mean_value' 列就是 3小时温度(°C)
        t3h = df_3h['basin_mean_value']

        # (b) 计算日均温、日最高温、日最低温
        tmean_daily = t3h.resample('D').mean()
        tmax_daily = t3h.resample('D').max()
        tmin_daily = t3h.resample('D').min()

        # (c) 调用 Hargreaves 计算日PET (mm/day)
        pet_daily = hargreaves(
            tmean_daily,  # 日均温(°C)
            tmax_daily,   # 日最高(°C)
            tmin_daily,   # 日最低(°C)
            lat=lat_rad,
            k=0.0135,
            method=0,     # or 1
            clip_zero=True
        )

        # (d) 将 "日PET" 分配到 3 小时
        df_daily_pet = pd.DataFrame({'PET_daily': pet_daily})

        # 把 3 小时温度 (Series) 做成 DataFrame
        df_3h_pet = t3h.to_frame(name='temp')  # shape: (N,1)

        # 先保存原3小时的时间戳一列 (后续merge后要恢复原索引)
        df_3h_pet['time_original'] = df_3h_pet.index

        # 方便与日数据合并，这里加一个 'date' 列表示当天
        df_3h_pet['date'] = df_3h_pet.index.floor('D')
        # 也可以用 df_3h_pet.index.date，但最好用 floor('D') 保持 datetime 类型

        # (e) 日PET也加一列 'date' 以便 merge
        #     注意：如果 pet_daily 的索引是 DatetimeIndex，其日期部分要和 3小时对齐
        df_daily_pet['date'] = df_daily_pet.index.floor('D')

        # (f) 温度为负时是否截断，这里用 clip(0)；可自行调整
        df_3h_pet['weight'] = df_3h_pet['temp'].clip(lower=0)

        # 每天温度权重之和
        daily_weight_sum = df_3h_pet.groupby('date')['weight'].transform('sum')
        daily_weight_sum = daily_weight_sum.replace(0, np.nan)  # 避免除零

        df_3h_pet['weight_norm'] = df_3h_pet['weight'] / daily_weight_sum

        # 合并日PET到 df_3h_pet
        df_3h_pet = df_3h_pet.merge(df_daily_pet[['date', 'PET_daily']], on='date', how='left')

        # 计算 3 小时PET
        df_3h_pet['PET_3h'] = df_3h_pet['PET_daily'] * df_3h_pet['weight_norm']
        df_3h_pet['PET_3h'] = df_3h_pet['PET_3h'].fillna(0)

        # 恢复原来的 3 小时时间作为索引
        df_3h_pet.set_index('time_original', inplace=True)
        df_3h_pet.index.name = 'time'  # 给索引命名为 'time'

        # (g) 整理输出格式 -> 保留 3 小时 PET 那一列
        out_3h = df_3h_pet[['PET_3h']].copy()
        out_3h.rename(columns={'PET_3h': 'basin_mean_value'}, inplace=True)

        # (h) 保存结果到 CSV；带有 "time" 这一列
        fname = os.path.basename(fpath)  # 原文件名
        out_name = fname.replace('_mean_temp_', '_mean_pet_')
        out_path = os.path.join(dir_out, out_name)

        # 这里 index_label='time' 就会把 index 当作第一列列名为 time
        out_3h.to_csv(out_path, index_label='time', float_format='%.4f')
        print(f"  -> 3小时PET结果已保存: {out_path}")

