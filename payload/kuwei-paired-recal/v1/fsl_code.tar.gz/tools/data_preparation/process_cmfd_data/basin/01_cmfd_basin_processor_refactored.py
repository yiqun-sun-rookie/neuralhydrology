import pandas as pd
import netCDF4 as nc
import geopandas as gpd
from shapely.geometry import box
import matplotlib.dates as mdates
import geopandas as gpd
from cartopy.mpl.patch import geos_to_path
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import numpy as np
import os
from dataclasses import dataclass, field
from typing import List

# ======= 配置中文显示 =======
plt.rcParams['font.sans-serif'] = ['SimHei']  # 显示中文
plt.rcParams['axes.unicode_minus'] = False    # 正确显示负号

# ---------------------------------------------------------------------------
# 1) 下面是你已有的函数, 我们只做了少量改动以支持循环批量处理
# ---------------------------------------------------------------------------

def _convert_units_and_get_labels(var_name, data_array):
    """
    根据变量名转换单位并返回绘图用的标签。
    这是一个内部辅助函数，用于统一处理单位转换逻辑。
    """
    if var_name.startswith('prec') or 'rain' in var_name:
        # kg m^-2 s^-1 -> mm/3h
        converted_data = data_array * 10800
        cbar_label = '降水量 (mm/3h)'
        title_txt = '流域平均降水'
    elif 'snow' in var_name:
        # kg m^-2 s^-1 -> mm/3h
        converted_data = data_array * 10800
        cbar_label = '雪深 (mm/3h)'
        title_txt = '流域平均雪深'
    elif var_name.startswith('temp'):
        # K -> °C
        converted_data = data_array - 273.15
        cbar_label = '温度 (°C)'
        title_txt = '流域平均温度'
    else:
        converted_data = data_array
        cbar_label = f'{var_name} (原单位)'
        title_txt = f'流域平均 {var_name}'
    return converted_data, cbar_label, title_txt


def read_cmfd_single_var(file_path):
    """
    读取CMFD单变量数据，并返回:
    - data_dict: 包含 time, lon, lat, var_name(数组) 的字典
    - var_name:  变量名(从文件名推断)
    - year, month: 年和月(从文件名解析得到)
    """
    dataset = nc.Dataset(file_path, mode='r')
    data_dict = {}

    file_name = os.path.basename(file_path)
    var_name = file_name.split('_')[0]  # 例如 'prec'
    date_str = file_name.split('_')[-1].split('.')[0]  # 例如 '202006'
    year, month = date_str[:4], date_str[4:6]

    time_var = dataset.variables['time']
    # 将时间转为 Python datetime
    times = nc.num2date(time_var[:], units=time_var.units, only_use_cftime_datetimes=False)
    data_dict['time'] = pd.to_datetime(times)

    data_dict['lon'] = dataset.variables['lon'][:]
    data_dict['lat'] = dataset.variables['lat'][:]

    var_data = np.array(dataset.variables[var_name][:])
    # 处理缺失值
    if '_FillValue' in dataset.variables[var_name].ncattrs():
        fill_value = dataset.variables[var_name]._FillValue
        var_data = np.where(var_data == fill_value, np.nan, var_data)
    elif 'missing_value' in dataset.variables[var_name].ncattrs():
        fill_value = dataset.variables[var_name].missing_value
        var_data = np.where(var_data == fill_value, np.nan, var_data)
    data_dict[var_name] = var_data

    dataset.close()

    # 如果 lat 是从高到低排序，则翻转
    if data_dict['lat'][0] > data_dict['lat'][-1]:
        data_dict['lat'] = data_dict['lat'][::-1]
        data_dict[var_name] = data_dict[var_name][:, ::-1, :]

    return data_dict, var_name, year, month


def generate_mask(shapefile, lon, lat, mask_path=None, buffer_degree=0.2, debug_plot=False):
    """
    生成或加载流域掩膜（空间范围优化版）。
    若 mask_path 存在且文件可读，则直接加载已有掩膜；否则重新计算并保存。
    返回:
     - mask: (lat, lon)形状的布尔数组，True表示落在流域内
     - basin_bbox: 流域边界(最小x, 最小y, 最大x, 最大y)
    """
    # 如果已经有计算好的 mask 文件，则直接加载
    if mask_path and os.path.exists(mask_path):
        print(f"正在加载已有掩膜文件: {mask_path}")
        mask = np.load(mask_path)
        basin = gpd.read_file(shapefile).to_crs(epsg=4326)
        basin_bbox = basin.total_bounds

        # 添加掩膜统计信息
        total_cells = mask.size
        active_cells = np.sum(mask)
        print(f"掩膜统计: 总网格数={total_cells}, 激活网格数={active_cells}, 激活比例={active_cells/total_cells:.4f}")

        return mask, basin_bbox

    # 否则重新生成
    basin = gpd.read_file(shapefile).to_crs(epsg=4326)
    basin.geometry = basin.geometry.buffer(0)  # 修复可能的几何问题
    basin_bbox = basin.total_bounds
    print(f"流域边界范围: {basin_bbox}")
    print(f"流域中心点: ({(basin_bbox[0]+basin_bbox[2])/2:.4f}, {(basin_bbox[1]+basin_bbox[3])/2:.4f})")

    # 输出CMFD网格信息
    print(f"CMFD经度范围: {lon.min():.4f} ~ {lon.max():.4f}")
    print(f"CMFD纬度范围: {lat.min():.4f} ~ {lat.max():.4f}")

    res_lon = abs(np.mean(np.diff(lon)))
    res_lat = abs(np.mean(np.diff(lat)))
    print(f"经度分辨率: {res_lon:.4f}°, 纬度分辨率: {res_lat:.4f}°")

    # 检查流域是否在CMFD覆盖范围内
    if (basin_bbox[0] > lon.max() or basin_bbox[2] < lon.min() or
        basin_bbox[1] > lat.max() or basin_bbox[3] < lat.min()):
        print("⚠️  警告: 流域边界完全超出CMFD数据覆盖范围！")
        print(f"   流域经度: {basin_bbox[0]:.4f} ~ {basin_bbox[2]:.4f}")
        print(f"   流域纬度: {basin_bbox[1]:.4f} ~ {basin_bbox[3]:.4f}")
        print(f"   CMFD经度: {lon.min():.4f} ~ {lon.max():.4f}")
        print(f"   CMFD纬度: {lat.min():.4f} ~ {lat.max():.4f}")

    mask = np.zeros((len(lat), len(lon)), dtype=bool)

    # 利用边界范围 + buffer 来减少遍历范围
    lon_indices = np.where((lon >= basin_bbox[0] - buffer_degree) & (lon <= basin_bbox[2] + buffer_degree))[0]
    lat_indices = np.where((lat >= basin_bbox[1] - buffer_degree) & (lat <= basin_bbox[3] + buffer_degree))[0]
    print(f"需要遍历的经度索引数量: {len(lon_indices)}, 纬度索引数量: {len(lat_indices)}")

    if len(lon_indices) == 0 or len(lat_indices) == 0:
        print("⚠️  警告: 没有找到与流域边界相交的CMFD网格点！")
        return mask, basin_bbox

    # 建立空间索引，加速多边形碰撞检测
    basin_sindex = basin.sindex

    processed_count = 0
    for i in lat_indices:
        for j in lon_indices:
            cell = box(lon[j] - res_lon / 2, lat[i] - res_lat / 2,
                       lon[j] + res_lon / 2, lat[i] + res_lat / 2)
            possible_matches = list(basin_sindex.intersection(cell.bounds))
            if len(possible_matches) > 0:
                if cell.intersects(basin.unary_union):
                    mask[i, j] = True
            processed_count += 1

    # 统计结果
    total_cells = mask.size
    active_cells = np.sum(mask)
    print(f"掩膜生成完成:")
    print(f"  - 总网格数: {total_cells}")
    print(f"  - 激活网格数: {active_cells}")
    print(f"  - 激活比例: {active_cells/total_cells:.4f}")
    print(f"  - 处理的候选网格数: {processed_count}")

    # 可视化检查(可选)
    if debug_plot:
        fig, ax = plt.subplots(figsize=(12, 10))

        # 绘制流域边界
        basin.plot(ax=ax, color='blue', alpha=0.3, label='流域边界')

        # 绘制激活的网格
        yy, xx = np.where(mask)
        print(f"绘制 {len(yy)} 个激活网格...")

        for y, x in zip(yy, xx):
            cell = box(lon[x] - res_lon / 2, lat[y] - res_lat / 2,
                       lon[x] + res_lon / 2, lat[y] + res_lat / 2)
            gpd.GeoSeries([cell]).boundary.plot(ax=ax, color='red', linewidth=0.5, alpha=0.7)

        # 绘制CMFD网格范围
        cmfd_bounds = box(lon.min(), lat.min(), lon.max(), lat.max())
        gpd.GeoSeries([cmfd_bounds]).boundary.plot(ax=ax, color='green', linewidth=2, label='CMFD覆盖范围')

        plt.title("掩膜生成结果验证")
        plt.xlabel("经度")
        plt.ylabel("纬度")
        plt.legend()
        plt.grid(True, alpha=0.3)

        # 保存验证图到输出目录
        verification_path = os.path.join(os.path.dirname(mask_path) if mask_path else '.', 'mask_verification.png')
        plt.savefig(verification_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"掩膜验证图已保存: {verification_path}")

    # 将掩膜保存为npy文件，便于下次直接读取
    if mask_path:
        np.save(mask_path, mask)
        print(f"掩膜已保存: {mask_path}")

    return mask, basin_bbox


def diagnose_mask_and_data(cmfd_data, mask, var_name):
    """
    诊断掩膜和CMFD数据的匹配情况
    """
    print(f"\n=== 诊断 {var_name} 数据和掩膜匹配情况 ===")

    # 数据基本信息
    data_var = cmfd_data[var_name]
    print(f"CMFD数据形状: {data_var.shape}")
    print(f"掩膜形状: {mask.shape}")
    print(f"时间步数: {len(cmfd_data['time'])}")

    # 检查数据范围
    print(f"原始数据范围: {np.nanmin(data_var):.4f} ~ {np.nanmax(data_var):.4f}")
    print(f"原始数据中NaN比例: {np.isnan(data_var).sum() / data_var.size:.4f}")

    # 检查掩膜
    mask_active = np.sum(mask)
    print(f"掩膜激活网格数: {mask_active}")

    if mask_active == 0:
        print("❌ 错误: 掩膜中没有激活的网格点！")
        return False

    # 应用掩膜后的数据
    masked_data = np.where(mask, data_var, np.nan)
    valid_masked_data = masked_data[~np.isnan(masked_data)]

    print(f"掩膜后有效数据点数: {len(valid_masked_data)}")

    if len(valid_masked_data) == 0:
        print("❌ 错误: 应用掩膜后没有有效数据！")

        # 进一步诊断
        print("\n详细诊断:")
        print(f"  - 原始数据在掩膜区域是否为NaN:")
        for t in range(min(3, data_var.shape[0])):  # 检查前3个时间步
            masked_at_t = data_var[t][mask]
            nan_count = np.isnan(masked_at_t).sum()
            print(f"    时间步 {t}: {nan_count}/{len(masked_at_t)} 为NaN")

        return False

    print(f"掩膜后数据范围: {np.nanmin(valid_masked_data):.4f} ~ {np.nanmax(valid_masked_data):.4f}")

    # 计算一些时间步的流域平均值
    basin_means = []
    for t in range(min(5, data_var.shape[0])):
        mean_val = np.nanmean(masked_data[t])
        basin_means.append(mean_val)
        print(f"时间步 {t} 流域平均值: {mean_val:.4f}")

    if all(np.isnan(m) for m in basin_means):
        print("❌ 错误: 所有时间步的流域平均值都是NaN！")
        return False

    print("✅ 掩膜和数据匹配正常")
    return True


def plot_basin_mean_timeseries(cmfd_data, mask, var_name, output_path):
    """
    绘制流域平均要素的时间序列图，并返回该时序数组。
    """
    data_to_convert = cmfd_data[var_name]
    data_converted, ylabel_txt, title_txt = _convert_units_and_get_labels(var_name, data_to_convert)

    masked_data = np.where(mask, data_converted, np.nan)
    basin_mean_data = np.nanmean(masked_data, axis=(1, 2))  # 对空间维度(1,2)取平均

    # 绘图
    fig, ax = plt.subplots(figsize=(15, 5))
    ax.plot(cmfd_data['time'], basin_mean_data, 'b-', label=f'{title_txt}')
    ax.set_xlabel('时间 (年-月-日 时)')
    ax.set_ylabel(ylabel_txt)
    ax.set_title(f'{title_txt} - {cmfd_data["time"][0].strftime("%Y-%m")}')
    ax.grid(True)
    ax.legend()
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d %H:%M'))
    plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
    plt.tight_layout()
    # 输出图文件名中也可包含 var_name
    plt.savefig(output_path, dpi=300)
    plt.close()

    return basin_mean_data


def plot_grid_data_with_basin(cmfd_data,
                              mask,
                              var_name,
                              shapefile,
                              output_dir,
                              num_time_steps=5,
                              use_boundary_clip=False,
                              force_clip=False):
    """
    根据掩膜绘制要素空间分布；若裁剪导致空白，则自动回退到完整显示。
    """
    print(f"\n=== 开始绘制 {var_name} 空间分布图 ===")

    # ---------- 0. 基本诊断 ----------
    if np.sum(mask) == 0:
        print("❌ 掩膜为空，跳过绘图。")
        return
    if not diagnose_mask_and_data(cmfd_data, mask, var_name):
        print("❌ 数据/掩膜诊断失败，跳过绘图。")
        return

    # ---------- 1. 读取流域边界 ----------
    basin_geom = gpd.read_file(shapefile).to_crs(epsg=4326)
    minx, miny, maxx, maxy = basin_geom.total_bounds
    lon_range, lat_range = maxx - minx, maxy - miny
    aspect_ratio = lon_range / lat_range if lat_range else 1.0

    # ---------- 2. 流域大小判定 ----------
    active_cells = int(np.sum(mask))
    basin_area = lon_range * lat_range
    if use_boundary_clip and not force_clip and (active_cells < 50 or basin_area < 0.5):
        print(f"⚠️ 流域过小（网格:{active_cells}, 面积:{basin_area:.3f}°²），自动关闭裁剪")
        use_boundary_clip = False

    # ---------- 3. 公共准备 ----------
    base_width = 10
    fig_height = base_width / aspect_ratio
    lon, lat = np.meshgrid(cmfd_data['lon'], cmfd_data['lat'])
    time_indices = np.linspace(0, len(cmfd_data['time']) - 1,
                               num_time_steps, dtype=int)

    # 单独转换单位
    data_converted, cbar_label, _ = _convert_units_and_get_labels(
        var_name, cmfd_data[var_name])

    # ---------- 4. 主循环 ----------
    for t_idx in time_indices:
        data_t = data_converted[t_idx]
        data_masked = np.where(mask, data_t, np.nan)
        valid_data_count = int(np.sum(~np.isnan(data_masked)))

        print(f"时间步 {t_idx}: 有效数据={valid_data_count}")
        if valid_data_count == 0:
            print(f"⚠️  时间步 {t_idx} 无有效数据，跳过")
            continue

        # 先尝试裁剪模式；如失败再 fallback
        tried_clip = False
        while True:
            if use_boundary_clip and not tried_clip:
                tried_clip = True
                clip_mode = "边界裁剪"
                fig, ax = plt.subplots(figsize=(base_width, fig_height),
                                       subplot_kw={'projection': ccrs.PlateCarree()})

                # 计算带缓冲的 bbox
                buf = max(0.1, min(lon_range, lat_range) * 0.5)
                ax.set_extent([minx - buf, maxx + buf, miny - buf, maxy + buf],
                              crs=ccrs.PlateCarree())

                im = ax.pcolormesh(lon, lat, data_masked,
                                   cmap='Blues', transform=ccrs.PlateCarree())

                # ---------- 关键：set_boundary 可能失败 ----------
                try:
                    boundary = basin_geom.unary_union
                    ax.set_boundary(geos_to_path([boundary])[0],
                                    transform=ccrs.PlateCarree())
                except Exception as e:
                    print(f"⚠️  set_boundary 失败: {e}. 自动回退到完整显示模式。")
                    use_boundary_clip = False
                    plt.close(fig)
                    continue  # 重新绘图
            else:
                clip_mode = "完整显示"
                fig, ax = plt.subplots(figsize=(base_width, fig_height))
                # 背景浅灰
                ax.pcolormesh(lon, lat,
                              np.where(np.isnan(data_t), np.nan, 0),
                              cmap='Greys', alpha=0.1, vmin=-1, vmax=1)

                # 真正的数据
                vmin, vmax = np.nanpercentile(data_masked[~np.isnan(data_masked)],
                                              [2, 98])
                im = ax.pcolormesh(lon, lat, data_masked,
                                   cmap='Blues', vmin=vmin, vmax=vmax)
                basin_geom.boundary.plot(ax=ax, color='red',
                                         linewidth=2, alpha=0.8)
                # 适当缓冲
                buf = max(0.5, lon_range * 3, lat_range * 3)
                ax.set_xlim(minx - buf, maxx + buf)
                ax.set_ylim(miny - buf, maxy + buf)

            break  # 成功绘制后跳出 while

        # ---------- 5. 其余装饰 ----------
        plt.colorbar(im, ax=ax, label=cbar_label, shrink=0.8)
        time_str = cmfd_data["time"][t_idx].strftime("%Y-%m-%d %H:%M")
        basin_name = os.path.basename(shapefile).replace(".shp", "")
        ax.set_title(f"{basin_name} - {var_name} - {time_str}\n"
                     f"({clip_mode}, valid: {valid_data_count})", pad=15)
        ax.grid(True, alpha=0.3)
        ax.set_xlabel("经度")
        ax.set_ylabel("纬度")

        clip_suffix = "_clipped" if clip_mode == "边界裁剪" else "_full"
        filename = (f"grid_{var_name}_"
                    f"{cmfd_data['time'][t_idx].strftime('%Y%m%d_%H%M')}"
                    f"{clip_suffix}.png")
        save_path = os.path.join(output_dir, filename)
        plt.tight_layout()
        plt.savefig(save_path, dpi=600, bbox_inches="tight")
        plt.close()
        print(f"✅ 已保存: {save_path}")

    print(f"🎉 {var_name} 空间分布图绘制完成，共生成 {len(time_indices)} 张。")



def save_masked_to_netcdf(cmfd_data, mask, var_name, out_path):
    """
    将掩膜后的单要素月度数据保存为 NetCDF 文件(存于 out_path)。
    注意：若是prec等，需要在外部决定是否做单位转换，这里只做掩膜操作。
    """
    lat = cmfd_data['lat']
    lon = cmfd_data['lon']
    times = cmfd_data['time']
    data_var = cmfd_data[var_name]

    times_pydatetime = times.to_pydatetime()

    # 掩膜操作
    masked_data = np.where(mask, data_var, np.nan)

    with nc.Dataset(out_path, 'w', format='NETCDF4') as ds:
        ds.createDimension('time', len(times_pydatetime))
        ds.createDimension('lat', len(lat))
        ds.createDimension('lon', len(lon))

        time_var = ds.createVariable('time', 'f8', ('time',))
        lat_var = ds.createVariable('lat', 'f4', ('lat',))
        lon_var = ds.createVariable('lon', 'f4', ('lon',))

        masked_var = ds.createVariable(
            var_name, 'f4',
            ('time', 'lat', 'lon'),
            fill_value=np.nan,
            zlib=True
        )

        # 写入坐标
        time_var.units = 'seconds since 1970-01-01 00:00:00'
        time_var.calendar = 'gregorian'

        time_var[:] = nc.date2num(times_pydatetime, units=time_var.units, calendar=time_var.calendar)
        lat_var[:] = lat
        lon_var[:] = lon

        masked_var[:] = masked_data
        masked_var.long_name = f"Masked {var_name}"
        masked_var.units = '原���位(kg m^-2 s^-1 或其他)'  # 根据具体要素修改

        ds.description = f"Masked CMFD data for {var_name}"
        ds.history = f"Created by save_masked_to_netcdf on {pd.to_datetime('now')}"
        ds.source_file = os.path.basename(cmfd_data.get('source_file', 'unknown'))

    print(f"掩膜后数据已保存至: {out_path}")


def save_basin_mean_to_csv(times, basin_mean_data, out_path):
    """
    将流域平均要素时序保存为CSV文件。
    - times: 时间序列 (pd.DatetimeIndex)
    - basin_mean_data: 对应每个时间步的流域平均值
    - out_path: CSV 文件路径
    """
    df = pd.DataFrame({
        'time': times,
        'basin_mean_value': basin_mean_data
    })
    df.to_csv(out_path, index=False, date_format="%Y-%m-%d %H:%M")
    print(f"流域平均时序已保存至: {out_path}")


# ---------------------------------------------------------------------------
# 2) 重构后的主程序：配置与逻辑分离
# ---------------------------------------------------------------------------

@dataclass
class Config:
    """用于存放所有配置项的数据类"""
    basin_name: str
    shapefile_path: str
    raw_data_root: str
    processed_root: str
    variable_folders: List[str] = field(default_factory=list)
    figure_root: str = ''
    sub_path: str = ''  # 新增: 用于定义输出的子路径嵌套
    use_boundary_clip: bool = False  # 新增: 是否使用流域边界裁剪
    force_boundary_clip: bool = False  # 新增: 强制使用边界裁剪，忽略流域大小检查

    def __post_init__(self):
        """在初始化后自动创建必要的输出目录"""
        # 如果提供了sub_path，则将其用于构建基础输出路径，否则回退到使用basin_name
        output_rel_path = self.sub_path if self.sub_path else self.basin_name

        base_processed_path = os.path.join(self.processed_root, output_rel_path)
        self.mask_output_path = os.path.join(base_processed_path, f'{self.basin_name}_mask.npy')

        # 为 figure_root 也创建同样的子目录结构
        self.figure_output_path = os.path.join(self.figure_root, output_rel_path)

        os.makedirs(base_processed_path, exist_ok=True)
        os.makedirs(self.figure_output_path, exist_ok=True)


def process_cmfd_data(config: Config):
    """
    CMFD数据处理的主函数。

    :param config: 包含所有路径和参数的Config对象。
    """
    # =========== 1. 生成(或加载)掩膜 ===========
    # 注意：我们假设所有要素的网格经纬度一致，因此只需从某个子文件夹里
    # 随便找一个 .nc 文件读取 lat/lon 即可。
    example_var = config.variable_folders[0]
    example_var_path = os.path.join(config.raw_data_root, example_var)

    example_file = None
    for f in sorted(os.listdir(example_var_path)):
        if f.endswith('.nc'):
            example_file = os.path.join(example_var_path, f)
            break

    if example_file is None:
        raise FileNotFoundError(f"在 {example_var_path} 下未找到任何nc文件，请检查。")

    # 读取该示例文件以获取lat/lon
    example_data, _, _, _ = read_cmfd_single_var(example_file)

    # 生成或加载流域掩膜
    print("正在生成或加载掩膜...")
    mask, _ = generate_mask(
        config.shapefile_path,
        example_data['lon'],
        example_data['lat'],
        mask_path=config.mask_output_path,
        debug_plot=True  # 如果需要生成验证图，设为True
    )
    print("掩膜处理完成。")

    # =========== 2. 遍历各要素文件夹，逐个处理 ===========
    for var_folder in config.variable_folders:
        print(f"\n=== 开始处理要素文件夹: {var_folder} ===")

        # 构造输出目录，使用Config中已经计算好的路径
        output_rel_path = config.sub_path if config.sub_path else config.basin_name
        base_processed_path = os.path.join(config.processed_root, output_rel_path)

        out_grid_dir = os.path.join(base_processed_path, var_folder, 'grid')
        out_mean_dir = os.path.join(base_processed_path, var_folder, 'mean')
        out_fig_dir = os.path.join(config.figure_output_path, var_folder)
        os.makedirs(out_grid_dir, exist_ok=True)
        os.makedirs(out_mean_dir, exist_ok=True)
        os.makedirs(out_fig_dir, exist_ok=True)

        var_path = os.path.join(config.raw_data_root, var_folder)
        nc_files = [f for f in sorted(os.listdir(var_path)) if f.endswith('.nc')]

        if not nc_files:
            print(f"  * 在 {var_path} 中未发现任何 .nc 文件，跳过。")
            continue

        # 遍历该要素下的每个月份 .nc
        for nc_file in nc_files:
            nc_path = os.path.join(var_path, nc_file)
            print(f"  --> 正在处理: {nc_path}")
            cmfd_data, var_name, year, month = read_cmfd_single_var(nc_path)
            cmfd_data['source_file'] = nc_path  # 保留源文件信息

            # (a) 计算流域平均 & 绘制时序图
            mean_fig_path = os.path.join(out_fig_dir, f"{config.basin_name}_mean_{var_name}_{year}{month}.png")
            basin_mean_data = plot_basin_mean_timeseries(cmfd_data, mask, var_name, output_path=mean_fig_path)

            # (b) 绘制空间分布图（传递边界裁剪选项）
            plot_grid_data_with_basin(
                cmfd_data=cmfd_data,
                mask=mask,
                var_name=var_name,
                shapefile=config.shapefile_path,
                output_dir=out_fig_dir,
                num_time_steps=3,
                use_boundary_clip=config.use_boundary_clip,  # 新增参数
                force_clip=config.force_boundary_clip  # 新增参数
            )

            # (c) 保存掩膜后的NetCDF
            out_nc_name = f"{var_name}_masked_{year}{month}.nc"
            out_nc_path = os.path.join(out_grid_dir, out_nc_name)
            save_masked_to_netcdf(cmfd_data, mask, var_name, out_path=out_nc_path)

            # (d) 保存流域平均值序列
            out_csv_name = f"{config.basin_name}_mean_{var_name}_{year}{month}.csv"
            out_csv_path = os.path.join(out_mean_dir, out_csv_name)
            save_basin_mean_to_csv(cmfd_data['time'], basin_mean_data, out_csv_path)

        print(f"=== 要素 {var_folder} 处理完毕 ===")

    print("\n所有要素的处理流程已完成。")


# ---------------------------------------------------------------------------
# 3) 主程序入口：在这里配置并运行
# ---------------------------------------------------------------------------
if __name__ == '__main__':
    # --- 用户配置区 ---
    # 你只需要修改这里的内容就可以为不同的流域或数据运行脚本

    # 获取项目根目录的绝对路径
    # __file__ 是当前脚本的路径, os.path.dirname() 可以获取其所在目录
    # 我们需要向上回溯几层来到达项目根目录
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))

    # --- 示例：处理嵌套流域 'shiyanghe/xiyinghe' ---
    main_basin = 'shiyanghe'
    sub_basin_name = 'subbasins'

    cfg = Config(
        basin_name=sub_basin_name,
        # 新增: 定义与GIS结构对应的嵌套输出路径
        sub_path=os.path.join(main_basin, sub_basin_name),
        # 使用 os.path.join 构造跨平台兼容的路径
        shapefile_path=os.path.join(project_root, 'data', 'raw', 'gis', main_basin, sub_basin_name, 'xiyinghe.shp'),
        raw_data_root=os.path.join(project_root, 'data', 'raw', 'cmfd'),
        processed_root=os.path.join(project_root, 'data', 'processed'),
        figure_root=os.path.join(project_root, 'results', 'figures'),
        variable_folders=[
            # 'prec',         # CMFD v2.1 原始降水
            'temp',         # 温度
            # 'pres',       # 气压
            # 'shum',       # 比湿
            # 'rhum',       # 相对湿度
            # 'wind',       # 风速
            # 'srad',       # 短波辐射
            # 'lrad',       # 长波辐射
            'derived_snow', # 额外计算的雪
            'derived_rain'  # 额外计算的雨
        ],
        use_boundary_clip = True,
        # force_boundary_clip=True
    )

    # --- 如果要处理单层流域（如旧版的 'yingluoxia'），可以这样配置：---
    # cfg_single = Config(
    #     basin_name='yingluoxia',
    #     # sub_path留空即可
    #     shapefile_path=os.path.join(project_root, 'data', 'raw', 'gis', 'yingluoxia', 'yingluoxia.shp'),
    #     raw_data_root=os.path.join(project_root, 'data', 'raw', 'cmfd'),
    #     processed_root=os.path.join(project_root, 'data', 'processed'),
    #     figure_root=os.path.join(project_root, 'results', 'figures'),
    #     use_boundary_clip=True  # 启用边界裁剪功能，生成_clipp.nc文件，减小文件体积
    #     variable_folders=['prec', 'temp']
    # )

    # --- 执行处理 ---
    process_cmfd_data(cfg)

