import os
import glob
import numpy as np
import pandas as pd
import logging
from src.kernels.core.hydro_model.process_model.evap.pyet.pyet import pm_fao56

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

if __name__ == "__main__":
    # 0) 设置输入输出路径
    dir_in_base = r"C:\Users\yiqun\PycharmProjects\forecast_system_lite\data\processed\yingluoxia"
    dir_out = r"C:\Users\yiqun\PycharmProjects\forecast_system_lite\data\processed\yingluoxia\pet_fao56\mean"

    # 输入变量的子目录
    var_dirs = {
        'temp': 'temp\\mean',           # 温度 (°C)
        'wind': 'wind\\mean',           # 风速 (m/s)
        'rh': 'rh\\mean',               # 相对湿度 (%)
        'rs': 'rs\\mean',               # 短波辐射 (MJ/m²/day)
        'pressure': 'pressure\\mean',   # 气压 (kPa)
    }

    # 验证输出目录并创建
    try:
        os.makedirs(dir_out, exist_ok=True)
        logger.info(f"输出目录已创建或存在: {dir_out}")
    except Exception as e:
        logger.error(f"无法创建输出目录 {dir_out}: {e}")
        raise

    # 1) 获取温度文件列表
    temp_dir = os.path.join(dir_in_base, var_dirs['temp'])
    file_list = glob.glob(os.path.join(temp_dir, "*.csv"))
    file_list.sort()

    if not file_list:
        logger.error(f"未找到温度文件: {temp_dir}\*.csv")
        raise FileNotFoundError(f"未找到温度文件: {temp_dir}\*.csv")

    logger.info(f"找到 {len(file_list)} 个温度文件: {file_list}")

    # 2) 设置流域中心纬度(度)，并转成弧度
    lat_deg = 38.2
    lat_rad = lat_deg * np.pi / 180.0

    # 3) 设置海拔（单位：米）
    elevation = 2000  # 请替换为流域实际平均海拔

    # 4) 循环处理每一个文件
    for fpath in file_list:
        logger.info(f"正在处理: {fpath}")

        # (a) 读取 3 小时温度序列
        try:
            df_3h_temp = pd.read_csv(fpath, parse_dates=['time'])
            df_3h_temp.set_index('time', inplace=True)
            t3h = df_3h_temp['basin_mean_value']
        except Exception as e:
            logger.error(f"读取温度文件失败 {fpath}: {e}")
            continue

        # (b) 读取其他 3 小时气象数据
        fname = os.path.basename(fpath)
        paths = {
            'wind': os.path.join(dir_in_base, var_dirs['wind'], fname.replace('_mean_temp_', '_mean_wind_')),
            'rh': os.path.join(dir_in_base, var_dirs['rh'], fname.replace('_mean_temp_', '_mean_rh_')),
            'rs': os.path.join(dir_in_base, var_dirs['rs'], fname.replace('_mean_temp_', '_mean_rs_')),
            'pressure': os.path.join(dir_in_base, var_dirs['pressure'], fname.replace('_mean_temp_', '_mean_pressure_')),
        }

        # 读取数据并检查
        try:
            df_3h_wind = pd.read_csv(paths['wind'], parse_dates=['time']).set_index('time')
            df_3h_rh = pd.read_csv(paths['rh'], parse_dates=['time']).set_index('time')
            df_3h_rs = pd.read_csv(paths['rs'], parse_dates=['time']).set_index('time')
            df_3h_pressure = pd.read_csv(paths['pressure'], parse_dates=['time']).set_index('time')

            wind_3h = df_3h_wind['basin_mean_value']
            rh_3h = df_3h_rh['basin_mean_value']
            rs_3h = df_3h_rs['basin_mean_value']
            pressure_3h = df_3h_pressure['basin_mean_value']
        except Exception as e:
            logger.error(f"读取其他气象数据失败: {e}")
            continue

        # 验证时间戳对齐
        if not (df_3h_temp.index.equals(df_3h_wind.index) and
                df_3h_temp.index.equals(df_3h_rh.index) and
                df_3h_temp.index.equals(df_3h_rs.index) and
                df_3h_temp.index.equals(df_3h_pressure.index)):
            logger.warning(f"文件 {fname} 的时间戳不一致，跳过")
            continue

        # (c) 计算日均值、日最大值、日最小值
        tmean_daily = t3h.resample('D').mean()
        tmax_daily = t3h.resample('D').max()
        tmin_daily = t3h.resample('D').min()
        wind_daily = wind_3h.resample('D').mean()
        rh_daily = rh_3h.resample('D').mean()
        rs_daily = rs_3h.resample('D').sum()  # 辐射按天求和
        pressure_daily = pressure_3h.resample('D').mean()

        # (d) 调用 pm_fao56 计算日 PET (mm/day)
        try:
            pet_daily = pm_fao56(
                tmean=tmean_daily,
                wind=wind_daily,
                rs=rs_daily,
                tmax=tmax_daily,
                tmin=tmin_daily,
                rh=rh_daily,
                pressure=pressure_daily,
                elevation=elevation,
                lat=lat_rad,
                clip_zero=True
            )
        except Exception as e:
            logger.error(f"计算 PET 失败 {fname}: {e}")
            continue

        # (e) 可选：引入作物系数（KC）
        KC = 1.0  # 示例值，可替换为动态 KC
        pet_daily = pet_daily * KC

        # (f) 将 "日PET" 分配到 3 小时
        df_daily_pet = pd.DataFrame({'PET_daily': pet_daily})
        df_3h_pet = t3h.to_frame(name='temp')
        df_3h_pet['time_original'] = df_3h_pet.index
        df_3h_pet['date'] = df_3h_pet.index.floor('D')
        df_daily_pet['date'] = df_daily_pet.index.floor('D')

        # 使用温度权重分配 PET
        df_3h_pet['weight'] = df_3h_pet['temp'].clip(lower=0)
        daily_weight_sum = df_3h_pet.groupby('date')['weight'].transform('sum')
        daily_weight_sum = daily_weight_sum.replace(0, np.nan)
        df_3h_pet['weight_norm'] = df_3h_pet['weight'] / daily_weight_sum

        # 合并日 PET
        df_3h_pet = df_3h_pet.merge(df_daily_pet[['date', 'PET_daily']], on='date', how='left')
        df_3h_pet['PET_3h'] = df_3h_pet['PET_daily'] * df_3h_pet['weight_norm']
        df_3h_pet['PET_3h'] = df_3h_pet['PET_3h'].fillna(0)

        # 恢复 3 小时时间索引
        df_3h_pet.set_index('time_original', inplace=True)
        df_3h_pet.index.name = 'time'

        # (g) 整理输出格式
        out_3h = df_3h_pet[['PET_3h']].copy()
        out_3h.rename(columns={'PET_3h': 'basin_mean_value'}, inplace=True)

        # (h) 保存结果到 CSV
        out_name = fname.replace('_mean_temp_', '_mean_pet_')
        out_path = os.path.join(dir_out, out_name)
        try:
            out_3h.to_csv(out_path, index_label='time', float_format='%.4f')
            logger.info(f"3小时PET结果已保存: {out_path}")
        except Exception as e:
            logger.error(f"保存文件失败 {out_path}: {e}")
