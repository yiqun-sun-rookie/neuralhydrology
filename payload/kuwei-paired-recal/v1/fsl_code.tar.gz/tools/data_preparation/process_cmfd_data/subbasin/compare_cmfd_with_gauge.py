import os
import glob
import pandas as pd
import numpy as np
import xarray as xr
from scipy.spatial import cKDTree
import matplotlib.pyplot as plt
from src.utils.eval import eval_simulation
from dataclasses import dataclass, field
from typing import Dict, Tuple, List

# ======= 配置中文显示 =======
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# ─── 配置类 ───────────────────────────────────────────────────
@dataclass
class Config:
    """存放项目级的根目录配置"""
    cmfd_root: str
    station_data_root: str
    output_root: str

@dataclass
class BasinInfo:
    """存放单个流域的特定信息"""
    name: str
    var: str
    station_lonlat: Dict[str, Tuple[float, float]]
    time_slice: slice = slice('2012-01-01', '2020-12-31')
    scale_3h_to_mm: float = 10800.0  # 默认是降水转换系数

def process_basin_comparison(config: Config, basin_info: BasinInfo):
    """
    处理单个流域的 CMFD 与站点数据对比。
    """
    print("="*50)
    print(f"开始处理流域: {basin_info.name}")

    # --- 动态生成路径和参数 ---
    output_dir = os.path.join(config.output_root, basin_info.name)
    os.makedirs(output_dir, exist_ok=True)

    station_root = os.path.join(config.station_data_root, basin_info.name)
    cmfd_pattern = os.path.join(config.cmfd_root, basin_info.var, '*.nc')

    # ─── 1. 读取站点观测数据 ──────────────────────────────────
    print("--> 正在读取站点观测数据...")
    site_series = {}
    for site, (lon_s, lat_s) in basin_info.station_lonlat.items():
        # 假设站点数据在以流域名命名的文件夹下
        site_dir = os.path.join(station_root, f'{basin_info.name}_precipitation_daily', site)
        if not os.path.exists(site_dir):
            print(f"  - 警告: 站点目录不存在，跳过: {site_dir}")
            continue

        years = []
        for year_dir in os.listdir(site_dir):
            if not year_dir.endswith('.xlsx'):
                continue
            fp = os.path.join(site_dir, year_dir)
            df = pd.read_excel(fp)
            if 'P' not in df or df['P'].isna().all():
                print(f'  - 跳过 {site} {year_dir}: P 列全空')
                continue
            years.append(pd.Series(df['P'].values,
                                   index=pd.to_datetime(df['Time']),
                                   name=site))
        if years:
            site_series[site] = pd.concat(years).sort_index()
            print(f"  - 成功读取站点: {site}, 数据条数: {len(site_series[site])}")

    if not site_series:
        print(f"错误: 流域 {basin_info.name} 未能读取到任何有效的站点数据，处理终止。")
        return

    # ─── 2. 读取CMFD数据 ───────────────────────────────────────
    print(f"--> 正在读取 CMFD {basin_info.var} 数据...")
    nc_files = glob.glob(cmfd_pattern)
    if not nc_files:
        print(f"错误: 在 {cmfd_pattern} 未找到任何 CMFD 文件，处理终止。")
        return

    with xr.open_mfdataset(nc_files) as ds:
        # 确保维度顺序是 (time, lat, lon)
        ds = ds.transpose('time', 'lat', 'lon')
        # 翻转 lat 轴，使其从南到北递增
        if ds['lat'].values[0] > ds['lat'].values[-1]:
            ds = ds.reindex(lat=ds['lat'][::-1])

        cmfd_lon = ds['lon'].values
        cmfd_lat = ds['lat'].values
        cmfd_time = ds['time'].values

        # 建立 k-d tree 用于快速查找最近邻
        lon_grid, lat_grid = np.meshgrid(cmfd_lon, cmfd_lat)
        points = np.vstack([lon_grid.ravel(), lat_grid.ravel()]).T
        tree = cKDTree(points)

        # ─── 3. 为每个站点提取CMFD数据并对比 ──────────────────
        all_metrics = []
        for site, (lon_s, lat_s) in basin_info.station_lonlat.items():
            if site not in site_series:
                print(f"--> 站点 {site} 无有效观测数据，跳过对比。")
                continue

            print(f"--> 正在处理站点: {site}")

            # 找到最近的CMFD格点
            dist, idx = tree.query([lon_s, lat_s], k=1)
            lat_idx, lon_idx = np.unravel_index(idx, lon_grid.shape)

            print(f"  - 站点 ({lon_s:.4f}, {lat_s:.4f}) -> 最近CMFD格点 ({points[idx][0]:.4f}, {points[idx][1]:.4f})")

            # 提取该格点的CMFD时间序列
            cmfd_series = ds[basin_info.var].isel(lat=lat_idx, lon=lon_idx).to_series() * basin_info.scale_3h_to_mm
            cmfd_series.name = f'cmfd_{site}'

            # ─── 4. 数据对齐与评估 ─────────────────────────────
            gauge_series = site_series[site]

            # 将3小时CMFD聚合到日���度与站点对比
            cmfd_daily = cmfd_series.resample('D').sum()

            # 合并数据并选取时间范围
            df_compare = pd.concat([gauge_series, cmfd_daily], axis=1).dropna()
            df_compare = df_compare[basin_info.time_slice]
            df_compare.columns = ['gauge', 'cmfd']

            if df_compare.empty:
                print(f"  - 警告: 站点 {site} 在时间范围 {basin_info.time_slice} 内无重合数据。")
                continue

            # 计算评估指标
            metrics = eval_simulation(df_compare['cmfd'], df_compare['gauge'])
            metrics['station'] = site
            all_metrics.append(metrics)
            print(f"  - 评估指标: NSE={metrics['NSE']:.3f}, KGE={metrics['KGE']:.3f}, R2={metrics['R2']:.3f}, PBIAS={metrics['PBIAS']:.2f}%")

            # ─── 5. 绘图 ───────────────────────────────────────
            fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(15, 10), gridspec_kw={'height_ratios': [2, 1]})

            # 时间序列图
            df_compare.plot(ax=ax1, style=['-', '--'], grid=True)
            ax1.set_title(f'{basin_info.name} 流域 - {site} 站点\nCMFD vs. 站点观测 ({basin_info.var})')
            ax1.set_ylabel('降水量 (mm/d)')

            # 散点图
            max_val = df_compare.max().max()
            ax2.scatter(df_compare['gauge'], df_compare['cmfd'], alpha=0.5)
            ax2.plot([0, max_val], [0, max_val], 'r--', label='1:1线')
            ax2.set_xlabel('站点观测 (mm/d)')
            ax2.set_ylabel('CMFD (mm/d)')
            ax2.grid(True)
            ax2.legend()

            # 添加指标文本
            stats_text = (f"NSE: {metrics['NSE']:.3f}\n"
                          f"KGE: {metrics['KGE']:.3f}\n"
                          f"R²: {metrics['R2']:.3f}\n"
                          f"PBIAS: {metrics['PBIAS']:.2f}%\n"
                          f"RMSE: {metrics['RMSE']:.3f}")
            ax2.text(0.05, 0.95, stats_text, transform=ax2.transAxes,
                     fontsize=10, verticalalignment='top', bbox=dict(boxstyle='round,pad=0.5', fc='yellow', alpha=0.5))

            plt.tight_layout()
            fig_path = os.path.join(output_dir, f'comparison_{site}.png')
            print(f"  - 正在保存对比图至: {fig_path}")
            plt.savefig(fig_path, dpi=300)
            plt.close()
            print(f"  - 对比图已保存: {fig_path}")

        if all_metrics:
            df_metrics = pd.DataFrame(all_metrics).set_index('station')
            csv_path = os.path.join(output_dir, 'evaluation_metrics.csv')
            print(f"--> 正在保存全站点评估指标至: {csv_path}")
            df_metrics.to_csv(csv_path)
            print(f"--> 全站点评估指标已保存: {csv_path}")

        print(f"流域 {basin_info.name} 处理完成。")
        print("="*50 + "\n")


if __name__ == '__main__':
    # --- 1. 用户配置区：根目录 ---
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))

    config = Config(
        cmfd_root=os.path.join(project_root, 'data', 'raw', 'cmfd'),
        station_data_root=os.path.join(project_root, 'data', 'raw'),
        output_root=os.path.join(project_root, 'results', 'experiments', 'cmfd_vs_gauge_comparison')
    )

    # --- 2. 用户配置区：要处理的流域列表 ---
    basins_to_process = [
        BasinInfo(
            name='yingluoxia',
            var='precipitation',
            station_lonlat={
                'ylx': (100.183333, 38.816667),
                'zmsk': (100.116667, 38.216667),
                'ql': (100.233333, 38.216667)
            }
        ),
        BasinInfo(
            name='shiyanghe',
            var='precipitation',
            # scale_3h_to_mm=1.0, # 温度不需要转换
            station_lonlat={
                'wsw': (102.88, 37.9),
                # 在此添加石羊河的其他站点
            },
            time_slice=slice('2006-01-01', '2010-12-31')
        ),
        # 在此添加更多 BasinInfo 对象来处理其他流域
    ]

    # --- 3. 执行处理 ---
    for basin_info in basins_to_process:
        process_basin_comparison(config, basin_info)

    print("所有流域处理完毕。")

