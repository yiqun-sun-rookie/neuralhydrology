import glob
import os
import numpy as np
try:  # 可选依赖，优化运行阶段若未安装 matplotlib 不应阻塞
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates
    _HAS_MPL = True
except Exception:  # ImportError 或其他后端错误
    _HAS_MPL = False
import pandas as pd
from pathlib import Path
from typing import List, Dict, Union

def merge_station_flows(
        sources: Union[List[pd.DataFrame], Dict[str, Path], List[Path]],
        time_col: str = "time",
        discharge_col: str = "discharge",
        how: str = "outer"
) -> pd.DataFrame:
    """
    将多个站点流量表合并成宽表:
    --------------------------------------------------------------
    time | STATION_A | STATION_B | ... | STATION_N
    --------------------------------------------------------------

    Parameters
    ----------
    sources :
        • List[pd.DataFrame]               —— 每个 DF 必须含 [time_col, discharge_col]，
                                             且已知各自站点名（.name 或 columns）。
        • Dict[str, Path] / List[Path]     —— 路径指向 CSV；若用 List，需要
                                             文件名(无扩展名) 作为站点名。
    time_col : str
        时间列名（所有 DF 必须一致）。
    discharge_col : str
        流量列名（所有 DF 必须一致）。
    how : str
        合并方式：'outer' ∣ 'inner' ∣ 'left' … 传给 `pd.merge`.

    Returns
    -------
    pd.DataFrame
        列顺序：time, <station1>, <station2>, ...
    """
    dfs = []

    # 1) 统一读取 / 标记站点名
    if isinstance(sources, dict):  # {station: Path}
        iterable = sources.items()
    else:
        iterable = sources

    for item in iterable:
        if isinstance(item, tuple):  # 来自 dict
            station, fp = item
        elif isinstance(item, pd.DataFrame):
            df = item.copy()
            # 尝试从属性或第一列名推断 station
            if getattr(df, "station_name", None):
                station = df.station_name
            else:
                station = df.columns.difference([time_col])[0]
        else:  # Path-like
            fp = item
            station = Path(fp).stem.split("_")[0]

        # 读文件时
        if not isinstance(item, pd.DataFrame):
            df = pd.read_csv(fp, parse_dates=[time_col])

        df = df[[time_col, discharge_col]].copy()
        df.rename(columns={discharge_col: station}, inplace=True)
        dfs.append(df)

    # 2) 逐个 merge
    base = dfs[0]
    for df in dfs[1:]:
        base = pd.merge(base, df, on=time_col, how=how)

    # 3) 排序列顺序: time + 站点
    station_cols = sorted([c for c in base.columns if c != time_col])
    return base[[time_col] + station_cols]


def read_observed_discharge(excel_dir, start_year=None, end_year=None):
    all_files = glob.glob(os.path.join(excel_dir, "*.xlsx"))
    discharge_df_list = []
    available_years = []

    for file in all_files:
        year = os.path.splitext(os.path.basename(file))[0]  # 获取年份
        try:
            df = pd.read_excel(file)
            if df.empty:
                print(f"文件 {file} 为空，跳过此文件。")
                continue

            # 更灵活的列数检查和处理
            if df.shape[1] < 2:
                print(f"文件 {file} 列数少于2列，跳过此文件。")
                continue
            elif df.shape[1] > 2:
                print(f"文件 {file} 有{df.shape[1]}列，只使用前两列。")
                df = df.iloc[:, :2]  # 只取前两列

            # 检查是否有有效数据行
            if len(df.dropna()) == 0:
                print(f"文件 {file} 没有有效数据行，跳过此文件。")
                continue

            available_years.append(int(year))

            if not pd.api.types.is_datetime64_any_dtype(df.iloc[:, 0]):
                df.iloc[:, 0] = pd.to_datetime(df.iloc[:, 0], errors='coerce')

            # 删除时间列为NaT的行
            df = df.dropna(subset=[df.columns[0]])

            if df.empty:
                print(f"文件 {file} 时间列无法解析，跳过此文件。")
                continue

            df.columns = ['time', 'discharge']
            discharge_df_list.append(df)
            print(f"成功读取文件 {file}，包含 {len(df)} 条记录")

        except Exception as e:
            print(f"读取文件 {file} 时出错: {e}")

    if discharge_df_list:
        discharge_df = pd.concat(discharge_df_list, ignore_index=True)
        discharge_df.sort_values('time', inplace=True)
        discharge_df.reset_index(drop=True, inplace=True)

        # 自动确定起止年份（若未指定）
        if start_year is None:
            start_year = discharge_df['time'].dt.year.min()
        if end_year is None:
            end_year = discharge_df['time'].dt.year.max()

        # 构建完整的日尺度时间序列索引
        full_date_range = pd.date_range(start=f"{start_year}-01-01", end=f"{end_year}-12-31", freq='D')
        full_df = pd.DataFrame({'time': full_date_range})

        # 合并数据，缺失值自动变为NaN
        merged_df = pd.merge(full_df, discharge_df, on='time', how='left')

        return merged_df
    else:
        print("没有有效的流量数据文件。")
        return pd.DataFrame(columns=['time', 'discharge'])


def clean_discharge_data(df, discharge_col='discharge', treat_zero_as_missing=False):
    df[discharge_col] = pd.to_numeric(df[discharge_col].astype(str).str.replace('[^0-9.]', '', regex=True),
                                      errors='coerce')

    if treat_zero_as_missing:
        df[discharge_col] = df[discharge_col].replace(0, np.nan)

    return df


def plot_observed_discharge(df, time_col='time', discharge_col='discharge', figsize=(14, 6),
                            treat_zero_as_missing=False, station_name=""):
    if not _HAS_MPL:
        print(f"[INFO] 未安装 matplotlib，跳过绘图 station={station_name}")
        return
    df = clean_discharge_data(df, discharge_col, treat_zero_as_missing)
    df_sorted = df.sort_values(by=time_col)

    plt.figure(figsize=figsize)
    plt.plot(df_sorted[time_col], df_sorted[discharge_col], linewidth=0.8, label='Observed Discharge')

    plt.xlabel('Time', fontsize=12)
    plt.ylabel('Discharge', fontsize=12)
    plt.title(f'Observed Daily Discharge - {station_name} (Including Missing Years)', fontsize=14)

    plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
    plt.gca().xaxis.set_major_locator(mdates.YearLocator())

    plt.grid(True, linestyle='--', alpha=0.5)
    plt.legend()
    plt.tight_layout()

    plt.gcf().autofmt_xdate()
    plt.show()


def read_obs_discharge_csv(csv_path, missing_value=None):
    obs_discharge_df = pd.read_csv(csv_path, parse_dates=['time'], na_values=missing_value)
    # 强制将 discharge 转换为数值类型，空值自动为NaN
    obs_discharge_df['discharge'] = pd.to_numeric(obs_discharge_df['discharge'], errors='coerce')
    return obs_discharge_df


def process_single_station(station_nm, base_raw_dir, base_processed_dir, plot_data=True):
    """处理单个站点的数据"""
    print(f"\n正在处理站点: {station_nm}")

    # 读取Excel并自动填充缺失年份为NaN
    excel_dir = rf"{base_raw_dir}\{station_nm}_discharge_daily"

    # 检查文件夹是否存在
    if not os.path.exists(excel_dir):
        print(f"警告: 站点 {station_nm} 的数据文件夹不存在: {excel_dir}")
        return None

    obs_discharge_df = read_observed_discharge(excel_dir)

    if obs_discharge_df.empty:
        print(f"站点 {station_nm} 没有有效数据")
        return None

    # 绘制数据（NaN值绘制为空白）
    if plot_data and _HAS_MPL:
        plot_observed_discharge(obs_discharge_df, time_col='time',
                                treat_zero_as_missing=True, station_name=station_nm)

    # 保存到 CSV
    processed_path = rf"{base_processed_dir}\{station_nm}_discharge_daily"
    os.makedirs(processed_path, exist_ok=True)  # 确保文件夹存在
    output_path = os.path.join(processed_path, "obs_discharge_daily.csv")
    obs_discharge_df.to_csv(output_path, index=False)
    print(f"站点 {station_nm} 数据已保存到: {output_path}")

    # 读取CSV并再次绘图检查（可选）
    if plot_data and _HAS_MPL:
        obs_discharge_df1 = read_obs_discharge_csv(output_path)
        plot_observed_discharge(obs_discharge_df1, time_col='time',
                                treat_zero_as_missing=True, station_name=f"{station_nm} (from CSV)")

    return obs_discharge_df

if __name__ == "__main__":
    # --- 批量处理多个站点 ---
    # 定义站点列表
    station_list = ["zmsk", "ql"]  # 根据实际情况修改

    # 定义基础路径
    base_raw_dir = r"F:\github\pycharm\projects\forecast_system_lite\data\raw\yingluoxia"
    base_processed_dir = r"F:\github\pycharm\projects\forecast_system_lite\data\processed\yingluoxia"

    # 存储所有处理结果
    processed_results = {}

    # 循环处理每个站点
    for station_nm in station_list:
        try:
            result = process_single_station(
                station_nm=station_nm,
                base_raw_dir=base_raw_dir,
                base_processed_dir=base_processed_dir,
                plot_data=True  # 设为False可跳过绘图加快处理速度
            )
            if result is not None:
                processed_results[station_nm] = result
                print(f"站点 {station_nm} 处理完成")
            else:
                print(f"站点 {station_nm} 处理失败")
        except Exception as e:
            print(f"处理站点 {station_nm} 时发生错误: {e}")

    print(f"\n批量处理完成！成功处理 {len(processed_results)} 个站点")
    print(f"成功处理的站点: {list(processed_results.keys())}")

    # 可选: 查看每个站点的数据概况
    print("\n各站点数据概况:")
    for station, df in processed_results.items():
        print(f"{station}: {len(df)} 条记录, 时间范围: {df['time'].min()} 到 {df['time'].max()}")

    csv_dir = Path(r"F:\github\pycharm\projects\forecast_system_lite\data\processed\yingluoxia")
    csv_map = {
        "zmsk": csv_dir / "zmsk_discharge_daily" / "obs_discharge_daily.csv",
        "ql"  : csv_dir / "ql_discharge_daily"  / "obs_discharge_daily.csv",
    }

    merged_df = merge_station_flows(csv_map, how="outer")
    merged_df.to_csv(csv_dir / "reach_inflow.csv", index=False)

