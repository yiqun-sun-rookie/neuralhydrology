import os
import glob
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from src.kernels.core.hydro_model.process_model.evap.pyet.pyet.radiation import hargreaves
from dataclasses import dataclass
from typing import List

@dataclass
class AppConfig:
    """应用级配置，存放根目录等"""
    processed_data_root: str

@dataclass
class SubBasinConfig:
    """子流域专属配置"""
    total_basin_name: str
    sub_basin_name: str
    latitude: float

def process_sub_basin_pet(app_config: AppConfig, basin_config: SubBasinConfig):
    """为单个子流域处理温度到PET的转换"""
    print("-" * 50)
    print(f"开始处理子流域: {basin_config.total_basin_name} - {basin_config.sub_basin_name}")

    # 0) 根据配置动态生成输入输出路径
    dir_in = os.path.join(app_config.processed_data_root, basin_config.total_basin_name, 'subbasins', basin_config.sub_basin_name, 'temp', 'mean')
    dir_out = os.path.join(app_config.processed_data_root, basin_config.total_basin_name, 'subbasins', basin_config.sub_basin_name, 'pet_hargreaves', 'mean')
    os.makedirs(dir_out, exist_ok=True)

    # 1) 遍历目录中所有 CSV
    file_list = glob.glob(os.path.join(dir_in, "*.csv"))
    if not file_list:
        print(f"警告: 在 {dir_in} 中未找到任何CSV文件，跳过。")
        return
    file_list.sort()

    # 2) 获取纬度
    lat_rad = basin_config.latitude * np.pi / 180.0

    # 3) 循环处理每一个文件
    for fpath in file_list:
        print(f"\n正在处理: {fpath}")

        # (a) 读取 3 小时温度序列
        df_3h = pd.read_csv(fpath, parse_dates=['time'])
        df_3h.set_index('time', inplace=True)

        # 假设 'basin_mean_value' 列就是 3小时温度(°C)
        t3h = df_3h['basin_mean_value']

        # (b) 计算日均温、日最高温、日最低温
        tmean_daily = t3h.resample('D').mean()
        tmax_daily = t3h.resample('D').max()
        tmin_daily = t3h.resample('D').min()

        # (c) 调用 Hargreaves 计算日PET (mm/day)
        pet_daily = hargreaves(
            tmean_daily,  # 日均温(°C)
            tmax_daily,   # 日最高(°C)
            tmin_daily,   # 日最低(°C)
            lat=lat_rad,
            k=0.0135,
            method=0,     # or 1
            clip_zero=True
        )

        # (d) 将 "日PET" 分配到 3 小时
        df_daily_pet = pd.DataFrame({'PET_daily': pet_daily})

        # 把 3 小时温度 (Series) 做成 DataFrame
        df_3h_pet = t3h.to_frame(name='temp')  # shape: (N,1)

        # 先保存原3小时的时间戳一列 (后续merge后要恢复原索引)
        df_3h_pet['time_original'] = df_3h_pet.index

        # 方便与日数据合并，这里加一个 'date' 列表示当天
        df_3h_pet['date'] = df_3h_pet.index.floor('D')
        # 也可以用 df_3h_pet.index.date，但最好用 floor('D') 保持 datetime 类型

        # (e) 日PET也加一列 'date' 以便 merge
        #     注意：如果 pet_daily 的索引是 DatetimeIndex，其日期部分要和 3小时对齐
        df_daily_pet['date'] = df_daily_pet.index.floor('D')

        # (f) 温度为负时是否截断，这里用 clip(0)；可自行调整
        df_3h_pet['weight'] = df_3h_pet['temp'].clip(lower=0)

        # 每天温度权重之和
        daily_weight_sum = df_3h_pet.groupby('date')['weight'].transform('sum')
        daily_weight_sum = daily_weight_sum.replace(0, np.nan)  # 避免除零

        df_3h_pet['weight_norm'] = df_3h_pet['weight'] / daily_weight_sum

        # 合并日PET到 df_3h_pet
        df_3h_pet = df_3h_pet.merge(df_daily_pet[['date', 'PET_daily']], on='date', how='left')

        # 计算 3 小时PET
        df_3h_pet['PET_3h'] = df_3h_pet['PET_daily'] * df_3h_pet['weight_norm']
        df_3h_pet['PET_3h'] = df_3h_pet['PET_3h'].fillna(0)

        # 恢复原来的 3 小时时间作为索引
        df_3h_pet.set_index('time_original', inplace=True)
        df_3h_pet.index.name = 'time'  # 给索引命名为 'time'

        # (g) 整理输出格式 -> 保留 3 小时 PET 那一列
        out_3h = df_3h_pet[['PET_3h']].copy()
        out_3h.rename(columns={'PET_3h': 'basin_mean_value'}, inplace=True)

        # (h) 保存结果到 CSV；带有 "time" 这一列
        fname = os.path.basename(fpath)  # 原文件名
        out_name = fname.replace('_mean_temp_', '_mean_pet_')
        out_path = os.path.join(dir_out, out_name)

        # 这里 index_label='time' 就会把 index 当作第一列列名为 time
        print(f"  -> 正在保存3小时PET结果至: {out_path}")
        out_3h.to_csv(out_path, index_label='time', float_format='%.4f')
        print(f"  -> 3小时PET结果已保存: {out_path}")

if __name__ == "__main__":
    # --- 1. 用户配置区 ---
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))

    app_config = AppConfig(
        processed_data_root=os.path.join(project_root, 'data', 'processed')
    )

    # --- 2. 在这里配置所有需要处理的子流域 ---
    sub_basins_to_process: List[SubBasinConfig] = [
        # SubBasinConfig(total_basin_name='yingluoxia', sub_basin_name='zmsk', latitude=38.43),
        # SubBasinConfig(total_basin_name='yingluoxia', sub_basin_name='ql', latitude=38.02),
        # 在此添加更多子流域配置
        SubBasinConfig(total_basin_name='shiyanghe', sub_basin_name='xiyinghe', latitude=37.52),
    ]

    # --- 3. 执行处理 ---
    for basin_cfg in sub_basins_to_process:
        process_sub_basin_pet(app_config, basin_cfg)

    print("\n所有配置的子流域均已处理完毕。")

