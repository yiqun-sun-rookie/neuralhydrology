import os
import pandas as pd
from dataclasses import dataclass, field
from typing import List, Dict

import matplotlib.pyplot as plt
import matplotlib.dates as mdates


def plot_meteo_time_series(flood_event, var_columns, time_col='time', save_dir=None):
    """
    为每个气象要素绘制时间序列图，横坐标为时间（年月日），纵坐标为要素值。

    参数:
    -------
    flood_event : pd.DataFrame
        包含 'time' 列和各个要素列的 DataFrame。
    var_columns : list of str
        要绘制的要素列名列表，例如 ['temperature', 'p_1', 'evap']。
    time_col : str, optional
        时间列的名称，默认为 'time'。
    save_dir : str, optional
        如果提供，将图表保存到该目录；否则，仅显示图表。
    """

    # 确保 'time' 列是 datetime 类型
    if not pd.api.types.is_datetime64_any_dtype(flood_event[time_col]):
        flood_event[time_col] = pd.to_datetime(flood_event[time_col])

    # 为每个要素绘制图表
    for var in var_columns:
        if var not in flood_event.columns:
            print(f"警告: 列 '{var}' 不存在于 flood_event 中，跳过。")
            continue

        # 创建一个新的图表
        plt.figure(figsize=(12, 6))

        # 绘制�����线图
        plt.plot(flood_event[time_col], flood_event[var], label=var)

        # 设置标题和标签
        plt.title(f'Time Series of {var}')
        plt.xlabel('时间 (年-月-日)')
        plt.ylabel(var)

        # 设置横坐标格式为年月日
        plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
        plt.gca().xaxis.set_major_locator(mdates.AutoDateLocator())

        # 旋转日期标签以避免重叠
        plt.gcf().autofmt_xdate()

        # 显示图例
        plt.legend()

        # 如果提供了 save_dir，则保存图表
        if save_dir:
            os.makedirs(save_dir, exist_ok=True)
            save_path = os.path.join(save_dir, f'{var}_time_series.png')
            plt.savefig(save_path)
            print(f"图表已保存到: {save_path}")
        else:
            # 否则，显示图表
            plt.show()

        # 关闭当前图表以释放内存
        plt.close()

def collect_meteo_csvs(base_dir, var_folders, start_year=2006, end_year=2020, basin_name="yingluoxia"):
    """
    根据 var_folders 和指定年份范围，自动收集每个 (var_folder, year, month) 对应的
    CSV 文件路径。假设文件命名符合:
       yingluoxia_mean_{var_folder}_{yyyyMM}.csv
    并存放于:
       {base_dir}/{var_folder}/mean/

    若任意一个目标文件不存在，则立刻 raise FileNotFoundError。

    返回:
    -------
    meteo_csvs : dict
        字典形式: {var_folder: [文件路径1, 文件路径2, ...], ...}
        每个 var_folder 对应它在整个年份范围内的所有 CSV 路径。
    """

    meteo_csvs = {}
    for var_folder in var_folders:
        file_list = []
        for year in range(start_year, end_year + 1):
            for month in range(1, 13):
                ym = f"{year}{month:02d}"
                # 假设文件名形如 yingluoxia_mean_{var_folder}_{yyyyMM}.csv
                if var_folder == "derived_rain":
                    fname = f"{basin_name}_mean_rain_{ym}.csv"
                elif var_folder == "derived_snow":
                    fname = f"{basin_name}_mean_snow_{ym}.csv"
                elif var_folder == "pet_hargreaves":
                    fname = f"{basin_name}_mean_pet_{ym}.csv"
                elif var_folder == "precipitation":
                    fname = f"{basin_name}_mean_prec_{ym}.csv"
                else:
                    fname = f"{basin_name}_mean_{var_folder}_{ym}.csv"

                full_path = os.path.join(base_dir, var_folder, "mean", fname)

                if not os.path.exists(full_path):
                    raise FileNotFoundError(f"未找到文件: {full_path}")
                file_list.append(full_path)
        meteo_csvs[var_folder] = file_list
    return meteo_csvs


def combine_collected_meteo_csvs(meteo_csvs, var_mapping=None):
    """
    将 collect_meteo_csvs 返回的结果(多要素多文件) 合并到一个 DataFrame。
    每个文件都包含列 [time, basin_mean_value]，其中:
      - time: 3小时或其他时间分辨率
      - basin_mean_value: 不同要素的数值

    合并逻辑:
      1) 对于同一要素var_folder的所有文件(多月份), 先纵向concat (行拼接)
      2) 重命名 "basin_mean_value" => var_mapping里配置的列名, 如 'temperature','p_1','evap' 等
      3) 将此要素对应的DataFrame与全局flood_event做一次 outer merge(on='time')

    参数:
    -------
    meteo_csvs : dict
        由 collect_meteo_csvs 返回, 如 {var_folder: [csv1, csv2, ...], ...}
    var_mapping : dict or None
        用于将 var_folder 映射到 simulate_flood 需要的列名, 例如:
          {
            'temp': 'temperature',
            'precipitation': 'p_1',
            'evap': 'evap',
            ...
          }
        若未提供或某个var_folder不在此字典里, 将默认列名 "{var_folder}_value"

    返回:
    -------
    flood_event : pd.DataFrame
        列至少包含: 'time', 以及相应的要素列('p_1','temperature','evap',...).
        若后面要给 simulate_flood 用, 还需把 'floods_discharge' 列加上(可自行添加).
    """

    if var_mapping is None:
        var_mapping = {}

    flood_event = None  # 全局合���结果

    for var_folder, file_list in meteo_csvs.items():
        # 对同一要素的所有月度CSV进行"行拼接" (concat)
        df_all = []
        for csv_path in file_list:
            df_ = pd.read_csv(csv_path, parse_dates=['time'])
            # 排序 + 重置index
            df_.sort_values('time', inplace=True)
            df_.reset_index(drop=True, inplace=True)
            df_all.append(df_)

        # 将此要素所有月份合并
        if len(df_all) > 0:
            combined_df = pd.concat(df_all, axis=0, ignore_index=True)
        else:
            # 不太可能出现, 因为若 var_folder 有文件就会append
            continue

        # 重命名列
        # 若 var_folder 在 var_mapping里, 用指定列名; 否则默认 "{var_folder}_value"
        col_name = var_mapping.get(var_folder, f"{var_folder}_value")
        combined_df.rename(columns={'basin_mean_value': col_name}, inplace=True)

        # merge到全局flood_event
        if flood_event is None:
            flood_event = combined_df
        else:
            flood_event = pd.merge(
                flood_event, combined_df,
                on='time', how='outer'
            )

    # 整理最终结果
    if flood_event is not None:
        flood_event.sort_values('time', inplace=True)
        flood_event.reset_index(drop=True, inplace=True)

    return flood_event

@dataclass
class AppConfig:
    """应用级配置，存放根目录等"""
    processed_data_root: str

@dataclass
class CombineConfig:
    """单个子流域合并任务的配置"""
    total_basin_name: str
    sub_basin_name: str
    var_folders: List[str]
    var_mapping: Dict[str, str]
    start_year: int
    end_year: int

def run_combination(app_cfg: AppConfig, combine_cfg: CombineConfig):
    """根据配置执行单个子流域的气象数据合并"""
    print("=" * 60)
    print(f"开始合并 {combine_cfg.total_basin_name} - {combine_cfg.sub_basin_name} 的气象数据")

    base_dir = os.path.join(app_cfg.processed_data_root, combine_cfg.total_basin_name, 'subbasins', f'{combine_cfg.sub_basin_name}')

    try:
        collected = collect_meteo_csvs(
            base_dir=base_dir,
            var_folders=combine_cfg.var_folders,
            start_year=combine_cfg.start_year,
            end_year=combine_cfg.end_year,
            basin_name=combine_cfg.sub_basin_name
        )
        print("已收集文件(分要素):")
        for vf, paths in collected.items():
            print(f"  {vf}: {len(paths)} ��件")
    except FileNotFoundError as e:
        print(f"错误: {e}")
        print(f"跳过 {combine_cfg.sub_basin_name} 的处理。")
        return

    flood_event = combine_collected_meteo_csvs(collected, var_mapping=combine_cfg.var_mapping)
    if flood_event is None or flood_event.empty:
        print(f"警告: {combine_cfg.sub_basin_name} 的数据合并结果为空。")
        return

    print("合并后flood_event列:", flood_event.columns.tolist())
    print("flood_event前5行:\n", flood_event.head(5))

    output_csv_path = os.path.join(base_dir, "meteo_data.csv")
    print(f"正在保存合并后的气象数据到: {output_csv_path}")
    flood_event.to_csv(output_csv_path, index=False, encoding='utf-8-sig')
    print(f"成功保存合并后的气象数据到: {output_csv_path}")

    # 可选：绘图检查
    # plot_save_dir = os.path.join(base_dir, 'plots')
    # var_columns_to_plot = list(combine_cfg.var_mapping.values())
    # plot_meteo_time_series(flood_event, var_columns_to_plot, save_dir=plot_save_dir)


if __name__ == "__main__":
    # --- 1. 用户配置区：应用根目录 ---
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
    app_config = AppConfig(
        processed_data_root=os.path.join(project_root, 'data', 'processed')
    )

    # --- 2. 用户配置区：要处理的合并任务列表 ---
    tasks_to_run = [
        # CombineConfig(
        #     total_basin_name="yingluoxia",
        #     sub_basin_name="sub_zmsk",
        #     var_folders=["temp", "derived_rain", "derived_snow", "pet_hargreaves", "precipitation"],
        #     start_year=2006,
        #     end_year=2020,
        #     var_mapping={
        #         'temp': 'temperature',
        #         'derived_rain': 'rain',
        #         'derived_snow': 'snow',
        #         "pet_hargreaves": "pet",
        #         'precipitation': 'prec',
        #     }
        # ),
        # CombineConfig(
        #     total_basin_name="yingluoxia",
        #     sub_basin_name="sub_ql",
        #     var_folders=["temp", "derived_rain", "derived_snow", "pet_hargreaves", "precipitation"],
        #     start_year=2006,
        #     end_year=2020,
        #     var_mapping={
        #         'temp': 'temperature',
        #         'derived_rain': 'rain',
        #         'derived_snow': 'snow',
        #         "pet_hargreaves": "pet",
        #         'precipitation': 'prec',
        #     }
        # ),
        # CombineConfig(
        #     total_basin_name="yingluoxia",
        #     sub_basin_name="sub_zmsk",
        #     var_folders=["temp", "derived_rain", "derived_snow", "pet_hargreaves", "precipitation"],
        #     start_year=2006,
        #     end_year=2020,
        #     var_mapping={
        #         'temp': 'temperature',
        #         'derived_rain': 'rain',
        #         'derived_snow': 'snow',
        #         "pet_hargreaves": "pet",
        #         'precipitation': 'prec',
        #     }
        # ),
        CombineConfig(
            total_basin_name="shiyanghe",
            sub_basin_name="xiyinghe",
            var_folders=["temp", "derived_rain", "derived_snow", "pet_hargreaves", "precipitation"],
            start_year=2006,
            end_year=2020,
            var_mapping={
                'temp': 'temperature',
                'derived_rain': 'rain',
                'derived_snow': 'snow',
                "pet_hargreaves": "pet",
                'precipitation': 'prec',
            }
        ),
        # 在此添加更多子流域的合并任务
        # CombineConfig(
        #     total_basin_name="shiyanghe",
        #     sub_basin_name="sub_xxx",
        #     ...
        # ),
    ]

    # --- 3. 执行处理 ---
    for task in tasks_to_run:
        run_combination(app_config, task)

    print("\n所有配置的合并任务均已处理完毕。")

