import os
import numpy as np
import pandas as pd
import netCDF4 as nc
import geopandas as gpd
from shapely.geometry import box
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from dataclasses import dataclass, field
from typing import List

# ======= 配置中文显示 =======
plt.rcParams['font.sans-serif'] = ['SimHei']  # 显示中文
plt.rcParams['axes.unicode_minus'] = False  # 正确显示负号


# ---------------------------------------------------------------------------
# 1) 下面是你已有的函数, 我们只做了少量改动以支持循环批量处理
# ---------------------------------------------------------------------------

def read_cmfd_single_var(file_path):
    """
    读取CMFD单变量数据，并返回:
    - data_dict: 包含 time, lon, lat, var_name(数组) 的字典
    - var_name:  变量名(从文件名推断)
    - year, month: 年和月(从文件名解析得到)
    """
    dataset = nc.Dataset(file_path, mode='r')
    data_dict = {}

    file_name = os.path.basename(file_path)
    var_name = file_name.split('_')[0]  # 例如 'prec'
    date_str = file_name.split('_')[-1].split('.')[0]  # 例如 '202006'
    year, month = date_str[:4], date_str[4:6]

    time_var = dataset.variables['time']
    # 将时间转为 Python datetime
    times = nc.num2date(time_var[:], units=time_var.units, only_use_cftime_datetimes=False)
    data_dict['time'] = pd.to_datetime(times)

    data_dict['lon'] = dataset.variables['lon'][:]
    data_dict['lat'] = dataset.variables['lat'][:]

    var_data = np.array(dataset.variables[var_name][:])
    # 处理缺失值
    if '_FillValue' in dataset.variables[var_name].ncattrs():
        fill_value = dataset.variables[var_name]._FillValue
        var_data = np.where(var_data == fill_value, np.nan, var_data)
    elif 'missing_value' in dataset.variables[var_name].ncattrs():
        fill_value = dataset.variables[var_name].missing_value
        var_data = np.where(var_data == fill_value, np.nan, var_data)
    data_dict[var_name] = var_data

    dataset.close()

    # 如果 lat 是从高到低排序，则翻转
    if data_dict['lat'][0] > data_dict['lat'][-1]:
        data_dict['lat'] = data_dict['lat'][::-1]
        data_dict[var_name] = data_dict[var_name][:, ::-1, :]

    return data_dict, var_name, year, month


def generate_mask(shapefile, lon, lat, mask_path=None, buffer_degree=0.2):
    """
    生成或加载流域掩膜（空间范围优化版）。
    若 mask_path 存在且文件可读，则直接加载已有掩膜；否则重新计算并保存。
    返回:
     - mask: (lat, lon)形状的布尔数组，True表示落在流域内
     - basin_bbox: 流域边界(最小x, 最小y, 最大x, 最大y)
    """
    # 如果已经有计算好的 mask 文件，则直接加载
    if mask_path and os.path.exists(mask_path):
        mask = np.load(mask_path)
        basin = gpd.read_file(shapefile).to_crs(epsg=4326)
        basin_bbox = basin.total_bounds
        return mask, basin_bbox

    # 否则重新生成
    basin = gpd.read_file(shapefile).to_crs(epsg=4326)
    basin.geometry = basin.geometry.buffer(0)  # 修复可能的几何问题
    basin_bbox = basin.total_bounds
    print(f"流域边界范围: {basin_bbox}")

    res_lon = abs(np.mean(np.diff(lon)))
    res_lat = abs(np.mean(np.diff(lat)))
    print(f"经度分辨率: {res_lon:.4f}°, 纬度分辨率: {res_lat:.4f}°")

    mask = np.zeros((len(lat), len(lon)), dtype=bool)

    # 利用��界范围 + buffer 来减少遍历范围
    lon_indices = np.where((lon >= basin_bbox[0] - buffer_degree) & (lon <= basin_bbox[2] + buffer_degree))[0]
    lat_indices = np.where((lat >= basin_bbox[1] - buffer_degree) & (lat <= basin_bbox[3] + buffer_degree))[0]
    print(f"需要遍历的经度索引数量: {len(lon_indices)}, 纬度索引数量: {len(lat_indices)}")

    # 建立空间索引，加速多边形碰撞检测
    basin_sindex = basin.sindex

    for i in lat_indices:
        for j in lon_indices:
            cell = box(lon[j] - res_lon / 2, lat[i] - res_lat / 2,
                       lon[j] + res_lon / 2, lat[i] + res_lat / 2)
            possible_matches = list(basin_sindex.intersection(cell.bounds))
            if len(possible_matches) > 0:
                if cell.intersects(basin.unary_union):
                    mask[i, j] = True

    # 可视化检查(可选) - 为每个子流域生成独立的掩膜验证图
    fig, ax = plt.subplots(figsize=(10, 8))
    basin.plot(ax=ax, color='blue', alpha=0.5, label='流域边界')
    yy, xx = np.where(mask)
    for y, x in zip(yy, xx):
        cell = box(lon[x] - res_lon / 2, lat[y] - res_lat / 2,
                   lon[x] + res_lon / 2, lat[y] + res_lat / 2)
        gpd.GeoSeries([cell]).boundary.plot(ax=ax, color='red', linewidth=0.5)

    basin_name = os.path.splitext(os.path.basename(shapefile))[0]
    plt.title(f"掩膜生成结果验证 - {basin_name}（红色网格为激活区域）")
    plt.xlabel("经度")
    plt.ylabel("纬度")
    plt.legend()

    # 保存掩膜验证图到与mask同一目录
    if mask_path:
        mask_dir = os.path.dirname(mask_path)
        os.makedirs(mask_dir, exist_ok=True)  # 先创建目录
        verification_path = os.path.join(mask_dir, f'{basin_name}_mask_verification.png')
        plt.savefig(verification_path)
    else:
        plt.savefig(f'{basin_name}_mask_verification.png')
    plt.close()

    # 将掩膜保存为npy文件，便于下次直接读取
    if mask_path:
        os.makedirs(os.path.dirname(mask_path), exist_ok=True)
        np.save(mask_path, mask)

    return mask, basin_bbox


def plot_basin_mean_precipitation(cmfd_data, mask, var_name, basin_name, output_dir):
    """
    绘制流域平均要素的时间序列图，并返回该时序数组。
    - 若是prec(降水)，自动乘以10800 (kg m^-2 s^-1 -> mm/3h)
    - 若是temp(温度)，从K转到°C (减去273.15)
    - 否则保持原单位不变
    """
    if var_name.startswith('prec'):
        data_converted = cmfd_data[var_name] * 10800  # kg m^-2 s^-1 -> mm/3h
        ylabel_txt = '降水量 (mm/3h)'
        title_txt = '流域平均降水'
    elif var_name.startswith('derived_snow'):
        data_converted = cmfd_data[var_name] * 10800  # kg m^-2 s^-1 -> mm/3h
        ylabel_txt = '雪深 (mm/3h)'
        title_txt = '流域平均雪深'
    elif var_name.startswith('snow'):
        data_converted = cmfd_data[var_name] * 10800
        ylabel_txt = 'snow_avg (mm/3h)'
        title_txt = '流域平均 snow'
    elif var_name.startswith('rain'):
        data_converted = cmfd_data[var_name] * 10800
        ylabel_txt = 'rain_avg (mm/3h)'
        title_txt = '流域平均 rain'
    elif var_name.startswith('temp'):
        data_converted = cmfd_data[var_name] - 273.15  # K -> °C
        ylabel_txt = '温度 (°C)'
        title_txt = '流域平均温度'
    else:
        data_converted = cmfd_data[var_name]
        ylabel_txt = f'{var_name} (原单位)'
        title_txt = f'流域平均 {var_name}'

    masked_data = np.where(mask, data_converted, np.nan)
    basin_mean_data = np.nanmean(masked_data, axis=(1, 2))  # 对空间维度(1,2)取平均

    # 绘图
    fig, ax = plt.subplots(figsize=(15, 5))
    ax.plot(cmfd_data['time'], basin_mean_data, 'b-', label=f'{title_txt}')
    ax.set_xlabel('时间 (年-月-日 时)')
    ax.set_ylabel(ylabel_txt)
    ax.set_title(f'{basin_name} - {title_txt} - {cmfd_data["time"][0].strftime("%Y-%m")}')
    ax.grid(True)
    ax.legend()
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d %H:%M'))
    plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
    plt.tight_layout()

    # 保存到指定目录
    filename = f'{basin_name}_mean_{var_name}_{cmfd_data["time"][0].strftime("%Y%m")}.png'
    save_path = os.path.join(output_dir, filename)
    plt.savefig(save_path, dpi=300)
    plt.close()

    return basin_mean_data


def plot_grid_precipitation_with_basin_new(cmfd_data, mask, var_name, basin_bbox, shapefile, basin_name, output_dir,
                                           num_time_steps=5):
    import geopandas as gpd
    from cartopy.mpl.patch import geos_to_path
    import matplotlib.pyplot as plt
    import cartopy.crs as ccrs
    import cartopy.feature as cfeature
    import numpy as np
    import os

    # 读取流域 shapefile
    basin_geom = gpd.read_file(shapefile).to_crs(epsg=4326)

    # 获取流域的边界盒 (minx, miny, maxx, maxy)
    minx, miny, maxx, maxy = basin_geom.total_bounds

    # 添加缓冲区，确保能看到流域周围的区域
    # 缓冲区大小基于流域边界的比例
    buffer_ratio = 0.1  # 10%的缓冲区
    lon_buffer = (maxx - minx) * buffer_ratio
    lat_buffer = (maxy - miny) * buffer_ratio
    plot_minx = minx - lon_buffer
    plot_miny = miny - lat_buffer
    plot_maxx = maxx + lon_buffer
    plot_maxy = maxy + lat_buffer

    # 计算流域的宽高比
    lon_range = plot_maxx - plot_minx
    lat_range = plot_maxy - plot_miny
    aspect_ratio = lon_range / lat_range if lat_range != 0 else 1.0

    # 设置图像的宽高比，基础宽度为10英寸
    base_width = 10
    fig_height = base_width / aspect_ratio

    if var_name.startswith('prec'):
        data_converted = cmfd_data[var_name] * 10800
        cbar_label = '降水量 (mm/3h)'
    elif var_name.startswith('derived_snow'):
        data_converted = cmfd_data[var_name] * 10800
        cbar_label = 'derived_snow (mm)'
    elif var_name.startswith('snow'):
        data_converted = cmfd_data[var_name] * 10800
        cbar_label = 'snow (mm)'
    elif var_name.startswith('rain'):
        data_converted = cmfd_data[var_name] * 10800
        cbar_label = 'rain (mm)'
    elif var_name.startswith('temp'):
        data_converted = cmfd_data[var_name] - 273.15
        cbar_label = '温度 (°C)'
    else:
        data_converted = cmfd_data[var_name]
        cbar_label = f'{var_name} (原单位)'

    # 创建网格坐标
    lon, lat = np.meshgrid(cmfd_data['lon'], cmfd_data['lat'])
    time_indices = np.linspace(0, len(cmfd_data['time']) - 1, num_time_steps, dtype=int)

    # 循环绘制每个时间步的图像
    for t_idx in time_indices:
        # 创建图像，设置 figsize 基于流域的宽高比
        fig, ax = plt.subplots(figsize=(base_width, fig_height), subplot_kw={'projection': ccrs.PlateCarree()})
        data_t = data_converted[t_idx, :, :]
        data_masked = np.where(mask, data_t, np.nan)

        # 不再严格设置绘图边界为流域形状，而是使用更宽松的���界盒以便看到周围区域
        # boundary = basin_geom.unary_union
        # path = geos_to_path([boundary])[0]
        # ax.set_boundary(path, transform=ccrs.PlateCarree())

        # 设置绘图范围为流域的边界盒加缓冲区
        ax.set_extent([plot_minx, plot_maxx, plot_miny, plot_maxy], crs=ccrs.PlateCarree())

        # 绘制背景底图用淡色表示非流域区域
        ax.pcolormesh(lon, lat, np.ma.masked_where(~np.isnan(data_masked), np.ones_like(data_masked)), 
                    cmap='Greys', alpha=0.2, transform=ccrs.PlateCarree())

        # 绘制网格数据，���用更鲜明的颜色方案
        if var_name.startswith('prec') or var_name.startswith('rain') or var_name.startswith('derived_rain'):
            cmap = 'Blues'
        elif var_name.startswith('snow') or var_name.startswith('derived_snow'):
            cmap = 'cool'
        elif var_name.startswith('temp'):
            cmap = 'RdYlBu_r'
        else:
            cmap = 'viridis'

        im = ax.pcolormesh(lon, lat, data_masked, cmap=cmap, transform=ccrs.PlateCarree())

        # 添加海岸线和国境线
        ax.coastlines()
        ax.add_feature(cfeature.BORDERS, linestyle=':')

        # 叠加流域边界
        basin_geom.boundary.plot(ax=ax, color='black', linewidth=1, transform=ccrs.PlateCarree())

        # 添加颜色条
        plt.colorbar(im, ax=ax, label=cbar_label)

        # 设置标题并保存图像
        time_str = cmfd_data["time"][t_idx].strftime("%Y-%m-%d %H:%M")
        ax.set_title(f'{basin_name} - {var_name} 空间分布 - {time_str}')
        plt.tight_layout()

        filename = f'{basin_name}_grid_{var_name}_{cmfd_data["time"][t_idx].strftime("%Y%m%d_%H%M")}.png'
        save_path = os.path.join(output_dir, filename)
        plt.savefig(save_path, dpi=600)
        plt.close()

    return time_indices


def save_masked_to_netcdf(cmfd_data, mask, var_name, out_path, use_boundary_clip=False, force_boundary_clip=False):
    """
    将掩膜后的单要素月度数据保存为 NetCDF 文件(存于 out_path)。
    注意：若是prec等，需要在外部决定是否做单���转换，这里只做掩膜操作。

    参数：
    - use_boundary_clip: 是否只保存流域边界内的数据，减小文件体积
    - force_boundary_clip: 强制使用边界裁剪，同时保存完整版本和裁剪版本
    """
    lat = cmfd_data['lat']
    lon = cmfd_data['lon']
    times = cmfd_data['time']
    data_var = cmfd_data[var_name]

    times_pydatetime = times.to_pydatetime()

    # 掩膜操作
    masked_data = np.where(mask, data_var, np.nan)

    # 确保输出目录存在
    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    # 如果force_boundary_clip为True，首先保存完整版本
    if force_boundary_clip:
        # 保存完整版本
        print(f"正在保存完整掩膜数据至: {out_path}")
        with nc.Dataset(out_path, 'w', format='NETCDF4') as ds:
            ds.createDimension('time', len(times_pydatetime))
            ds.createDimension('lat', len(lat))
            ds.createDimension('lon', len(lon))

            time_var = ds.createVariable('time', 'f8', ('time',))
            lat_var = ds.createVariable('lat', 'f4', ('lat',))
            lon_var = ds.createVariable('lon', 'f4', ('lon',))

            masked_var = ds.createVariable(
                var_name, 'f4',
                ('time', 'lat', 'lon'),
                fill_value=np.nan,
                zlib=True
            )

            # 写入坐标
            time_var.units = 'seconds since 1970-01-01 00:00:00'
            time_var.calendar = 'gregorian'

            time_var[:] = nc.date2num(times_pydatetime, units=time_var.units, calendar=time_var.calendar)
            lat_var[:] = lat
            lon_var[:] = lon

            masked_var[:] = masked_data
            masked_var.long_name = f"Masked {var_name}"
            masked_var.units = '原单位(kg m^-2 s^-1 或其他)'  # 根据具体要素修改

            ds.description = f"Masked CMFD data for {var_name}"
            ds.history = f"Created by save_masked_to_netcdf on {pd.to_datetime('now')}"
            ds.source_file = os.path.basename(cmfd_data.get('source_file', 'unknown'))

        print(f"完整掩膜数据已保存至: {out_path}")

        # 继续裁剪处理
        use_boundary_clip = True

    # 边界裁剪处理 - 只保留掩膜区域及其周边，减小文件体积
    if use_boundary_clip:
        # 找出mask中所有True值的行列索引
        rows, cols = np.where(mask)
        if len(rows) > 0 and len(cols) > 0:
            # 确定边界
            min_row, max_row = rows.min(), rows.max()
            min_col, max_col = cols.min(), cols.max()

            # 添加更大的缓冲区，确保可视化时能看到足够的上下文
            buffer = 5  # 增加缓冲区大小
            min_row = max(0, min_row - buffer)
            max_row = min(len(lat) - 1, max_row + buffer)
            min_col = max(0, min_col - buffer)
            max_col = min(len(lon) - 1, max_col + buffer)

            # 裁剪数据
            clipped_lat = lat[min_row:max_row+1]
            clipped_lon = lon[min_col:max_col+1]
            clipped_data = masked_data[:, min_row:max_row+1, min_col:max_col+1]
            clipped_mask = mask[min_row:max_row+1, min_col:max_col+1]

            # 修改输出路径为 clipp 文件
            base_path = os.path.splitext(out_path)[0]
            clip_out_path = f"{base_path}_clipp.nc"

            # 使用裁剪后的数据
            print(f"正在保存裁剪后的掩膜数据至: {clip_out_path}")
            with nc.Dataset(clip_out_path, 'w', format='NETCDF4') as ds:
                ds.createDimension('time', len(times_pydatetime))
                ds.createDimension('lat', len(clipped_lat))
                ds.createDimension('lon', len(clipped_lon))

                time_var = ds.createVariable('time', 'f8', ('time',))
                lat_var = ds.createVariable('lat', 'f4', ('lat',))
                lon_var = ds.createVariable('lon', 'f4', ('lon',))

                masked_var = ds.createVariable(
                    var_name, 'f4',
                    ('time', 'lat', 'lon'),
                    fill_value=np.nan,
                    zlib=True
                )

                # 创建掩膜变量以便于可视化
                mask_var = ds.createVariable('mask', 'i1', ('lat', 'lon'))

                # 写入坐标
                time_var.units = 'seconds since 1970-01-01 00:00:00'
                time_var.calendar = 'gregorian'

                time_var[:] = nc.date2num(times_pydatetime, units=time_var.units, calendar=time_var.calendar)
                lat_var[:] = clipped_lat
                lon_var[:] = clipped_lon

                masked_var[:] = clipped_data
                mask_var[:] = clipped_mask.astype(np.int8)  # 保存掩膜便于可视化

                masked_var.long_name = f"Masked {var_name}"
                masked_var.units = '原单位(kg m^-2 s^-1 或其他)'  # 根据具体要素修改
                mask_var.long_name = "Basin Mask"
                mask_var.description = "1=basin area, 0=outside basin"

                ds.description = f"Clipped and Masked CMFD data for {var_name}"
                ds.history = f"Created by save_masked_to_netcdf on {pd.to_datetime('now')}"
                ds.source_file = os.path.basename(cmfd_data.get('source_file', 'unknown'))
                ds.boundary_clipped = "True"
                ds.buffer_size = buffer

            print(f"裁剪后的掩膜数据已保存至: {clip_out_path}")
            return

    # 如果没有执行裁剪或force_boundary_clip为False且use_boundary_clip为False
    # 则保存完整的数据文件
    print(f"正在保存掩膜后数据至: {out_path}")
    with nc.Dataset(out_path, 'w', format='NETCDF4') as ds:
        ds.createDimension('time', len(times_pydatetime))
        ds.createDimension('lat', len(lat))
        ds.createDimension('lon', len(lon))

        time_var = ds.createVariable('time', 'f8', ('time',))
        lat_var = ds.createVariable('lat', 'f4', ('lat',))
        lon_var = ds.createVariable('lon', 'f4', ('lon',))

        masked_var = ds.createVariable(
            var_name, 'f4',
            ('time', 'lat', 'lon'),
            fill_value=np.nan,
            zlib=True
        )

        # 添加掩膜变量便于可视化
        mask_var = ds.createVariable('mask', 'i1', ('lat', 'lon'))

        # 写入坐标
        time_var.units = 'seconds since 1970-01-01 00:00:00'
        time_var.calendar = 'gregorian'

        time_var[:] = nc.date2num(times_pydatetime, units=time_var.units, calendar=time_var.calendar)
        lat_var[:] = lat
        lon_var[:] = lon

        masked_var[:] = masked_data
        mask_var[:] = mask.astype(np.int8)  # 保存掩膜便于可视化

        masked_var.long_name = f"Masked {var_name}"
        masked_var.units = '原单位(kg m^-2 s^-1 或其他)'  # 根据具体要素修改
        mask_var.long_name = "Basin Mask"
        mask_var.description = "1=basin area, 0=outside basin"

        ds.description = f"Masked CMFD data for {var_name}"
        ds.history = f"Created by save_masked_to_netcdf on {pd.to_datetime('now')}"
        ds.source_file = os.path.basename(cmfd_data.get('source_file', 'unknown'))

    print(f"掩膜后数据已保存至: {out_path}")



def save_basin_mean_to_csv(times, basin_mean_data, out_path):
    """
    将流域平均要素时序保存为CSV文件。
    - times: 时间序列 (pd.DatetimeIndex)
    - basin_mean_data: 对应每个时间步的流域平均值
    - out_path: CSV 文件路径
    """
    # 确保输出目录存在
    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    df = pd.DataFrame({
        'time': times,
        'basin_mean_value': basin_mean_data
    })
    print(f"正在保存流域平均时序至: {out_path}")
    df.to_csv(out_path, index=False, date_format="%Y-%m-%d %H:%M")
    print(f"流域平均时序已保存至: {out_path}")


def get_basin_shapefiles(basin_folder):
    """
    获取流域文件夹���所有的shapefile路径和对应的流域名称

    参数:
    basin_folder: 包含多个子流域shapefile的文件夹路径

    返回:
    basin_info: [(basin_name, shapefile_path), ...] 的列表
    """
    basin_info = []

    if not os.path.exists(basin_folder):
        raise FileNotFoundError(f"流域文件夹不存在: {basin_folder}")

    for file in os.listdir(basin_folder):
        if file.endswith('.shp'):
            basin_name = os.path.splitext(file)[0]
            shapefile_path = os.path.join(basin_folder, file)
            basin_info.append((basin_name, shapefile_path))

    basin_info.sort()  # 按流域名称排序
    return basin_info


# ---------------------------------------------------------------------------
# 2) 主程序：遍历多个子流域 & 要素文件夹 & 每个月 *.nc 文件，分别处理
# ---------------------------------------------------------------------------
@dataclass
class Config:
    """用于存放所有路径配置的数据类"""
    raw_data_root: str
    processed_root: str
    figures_root: str
    gis_root: str
    variable_folders: List[str] = field(default_factory=list)

def process_basin(config: Config, total_basin_name: str):
    """
    处理单个总流域及其所有子流域的主函数。
    """
    # =========== 1. 根据配置和流域名生成动态路径 ===========
    basin_folder = os.path.join(config.gis_root, total_basin_name, 'subbasins')

    # =========== 2. 获取所有子流域信息 ===========
    try:
        basin_info = get_basin_shapefiles(basin_folder)
        print(f"在 '{total_basin_name}' 中发现 {len(basin_info)} 个子流域:")
        for basin_name, shapefile_path in basin_info:
            print(f"  - {basin_name}: {shapefile_path}")
    except FileNotFoundError as e:
        print(f"警告: {e}。跳过流域 '{total_basin_name}'。")
        return

    if not basin_info:
        print(f"警告: 在 {basin_folder} 中未找到任何shapefile文件。跳过流域 '{total_basin_name}'。")
        return

    # =========== 3. 获取示例文件用于确定网格信息 ===========
    if not config.variable_folders:
        print("警告: 配置中未提供任何 variable_folders，无法继续。")
        return

    example_var = config.variable_folders[0]
    example_var_path = os.path.join(config.raw_data_root, example_var)
    example_file = None

    for f in sorted(os.listdir(example_var_path)):
        if f.endswith('.nc'):
            example_file = os.path.join(example_var_path, f)
            break

    if example_file is None:
        print(f"警告: 在 {example_var_path} 下未找到任何nc文件，无法继续。")
        return

    # 读取示例文件以获取lat/lon
    example_data, _, _, _ = read_cmfd_single_var(example_file)
    example_lon = example_data['lon']
    example_lat = example_data['lat']

    # =========== 4. 为每个子流域生成掩膜 ===========
    basin_masks = {}
    basin_bboxes = {}

    print(f"\n=== 开始为 '{total_basin_name}' 的子流域生成掩膜 ===")
    for basin_name, shapefile_path in basin_info:
        print(f"\n处理子流域: {basin_name}")

        # 每个子流域的掩膜保存路径
        mask_output = os.path.join(config.processed_root, total_basin_name, 'subbasins', basin_name, f'{basin_name}_mask.npy')

        # 生成或加载掩膜
        mask, basin_bbox = generate_mask(shapefile_path, example_lon, example_lat, mask_path=mask_output)

        basin_masks[basin_name] = mask
        basin_bboxes[basin_name] = basin_bbox

        print(f"子流域 {basin_name} 掩膜生成完成")

    # =========== 5. 遍历要素文件夹 & 内部每个月的nc文件，为每个子流域处理 ===========
    for var_folder in config.variable_folders:
        print(f"\n=== 开始处理要素文件夹: {var_folder} ===")

        var_path = os.path.join(config.raw_data_root, var_folder)
        nc_files = [f for f in sorted(os.listdir(var_path)) if f.endswith('.nc')]
        if not nc_files:
            print(f"  * 未发现任何 .nc 文件于 {var_path}，跳过。")
            continue

        # 遍历该要素下的每个月份 .nc
        for nc_file in nc_files:
            nc_path = os.path.join(var_path, nc_file)
            print(f"  --> 正在处理: {nc_path}")
            cmfd_data, var_name, year, month = read_cmfd_single_var(nc_path)
            cmfd_data['source_file'] = nc_path

            # 为每个子流域处理当前的nc文件
            for basin_name, shapefile_path in basin_info:
                print(f"    --> 处理子流域: {basin_name}")

                # 获取该子流域的掩膜和边界
                mask = basin_masks[basin_name]
                basin_bbox = basin_bboxes[basin_name]

                # 构造该子流域的输出目录
                out_grid_dir = os.path.join(config.processed_root, total_basin_name, 'subbasins', basin_name, var_folder, 'grid')
                out_mean_dir = os.path.join(config.processed_root, total_basin_name, 'subbasins', basin_name, var_folder, 'mean')
                out_figures_dir = os.path.join(config.figures_root, total_basin_name, 'subbasins', basin_name, var_folder)

                os.makedirs(out_grid_dir, exist_ok=True)
                os.makedirs(out_mean_dir, exist_ok=True)
                os.makedirs(out_figures_dir, exist_ok=True)

                # ---------- (a) 计算流域平均 & 绘制时序图 ----------
                basin_mean_data = plot_basin_mean_precipitation(
                    cmfd_data, mask, var_name, basin_name, out_figures_dir
                )

                # ---------- (b) 绘制若干时间步的空间分布图 ----------
                plot_grid_precipitation_with_basin_new(
                    cmfd_data=cmfd_data,
                    mask=mask,
                    var_name=var_name,
                    basin_bbox=basin_bbox,
                    shapefile=shapefile_path,
                    basin_name=basin_name,
                    output_dir=out_figures_dir,
                    num_time_steps=3
                )

                # ---------- (c) 保��掩膜后 NetCDF 到 grid 子目录 ----------
                out_nc_name = f"{basin_name}_{var_name}_masked_{year}{month}.nc"
                out_nc_path = os.path.join(out_grid_dir, out_nc_name)
                save_masked_to_netcdf(cmfd_data, mask, var_name, out_path=out_nc_path, use_boundary_clip=True, force_boundary_clip=True)

                # ---------- (d) 保存流域平均序列到 mean 子目录 ----------
                out_csv_name = f"{basin_name}_mean_{var_name}_{year}{month}.csv"
                out_csv_path = os.path.join(out_mean_dir, out_csv_name)
                save_basin_mean_to_csv(cmfd_data['time'], basin_mean_data, out_csv_path)

        print(f"=== 要素 {var_folder} 处理完毕 ===")

    print(f"\n流域 '{total_basin_name}' 的所有子流域和要素的处理流程已完成。")


if __name__ == '__main__':
    # --- 1. 用户配置区 ---
    # 获取项目根目录 (F:\github\pycharm\projects\forecast_system_lite)
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))

    # 在这里配置你的项目根路径
    cfg = Config(
        raw_data_root=os.path.join(project_root, 'external', 'data', 'raw', 'cmfd'),  # data -> external/data
        processed_root=os.path.join(project_root, 'external', 'data', 'processed'),    # data -> external/data
        figures_root=os.path.join(project_root, 'experiments', 'figures', 'cmfd_subbasin_processor'), # results -> experiments
        gis_root=os.path.join(project_root, 'external', 'data', 'raw', 'gis'),         # data -> external/data
        variable_folders=[
            # 'precipitation',  # 存放降水 nc 文件
            'temp',           # 存放温度 nc 文件
            # 'pres',         # 气压 ...
            # 'shum',         # 比湿 ...
            # 'rhum',         # 相对湿度 ...
            # 'wind',         # 风速 ...
            # 'srad',         # 短波辐射 ...
            # 'lrad',         # 长波辐射 ...
            'derived_snow',  # 衍生的雪深数据
            'derived_rain'
        ]
    )

    # --- 2. 在这里列出所有需要处理的流域名称 ---
    basins_to_process = [
        "shiyanghe",
        # "yingluoxia",
        # 在这里添加更多流域名称, 例如 "weishui"
    ]

    # --- 3. 执行处理 ---
    for basin in basins_to_process:
        print("=" * 60)
        print(f"开始处理总流域: {basin}")
        print("=" * 60)
        process_basin(cfg, basin)

    print("\n所有配置的流域均已处理完毕。")
