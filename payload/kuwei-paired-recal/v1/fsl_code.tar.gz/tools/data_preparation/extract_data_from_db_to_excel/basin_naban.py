from imports import *

def main():
    # 1. 指定项目根目录、流域名称
    project_root = "C:/Users/yiqun/PycharmProjects/forecast_system_lite"
    basin_name = "naban"
    section_code = "42101"
    evap_code = None

    # 2. 读取配置,每个流域不一样
    config = load_configurations(basin_name, project_root)
    # 从配置中获取字段映射和文件路径
    field_mapping, file_path, simulation_config, db_config = (
        config['field_mapping'], config['file_paths'], config['simulation'], config['db_config'])
    # 读取洪水时段
    flood_times = fetch_flood_times(db_config)
    # 读取断面包含哪些雨量站、流量站、入流站等
    section_station_mapping = fetch_section_station_mapping(db_config)
    # 从net_station 里选一个
    # 遍历flood_times，处理每个洪水场次
    if flood_times.empty:
        print("未在数据库中检索到任何洪水时段信息。")
        return
    else:
        for idx, flood_row in flood_times.iterrows():
            start_time = flood_row['start_time']  # 例如 '2020-01-01 00:00'
            end_time = flood_row['end_time']  # 例如 '2020-01-02 00:00'
            flood_id = flood_row['flood_id']  # 如果你有 flood_id 之类字段
            print(f"处理洪水场次 flood_id={flood_id}, 时间：{start_time} ~ {end_time}")

            # a) 调用 extract_flood_data_for_section 获取(雨量、流量/水位、入流等)原始数据
            result_data = extract_flood_data_for_section(
                section_code=section_code,
                evap_code= evap_code,
                start_time=start_time,
                end_time=end_time,
                section_station_mapping=section_station_mapping,
                db_config=db_config
            )
            rainfall_df, evap_df, stage_flow_df, inflow_df = result_data["rainfall_df"], result_data['evaporation_df'], \
                                                             result_data["stage_flow_df"], result_data["inflow_df"]

            # b) 对数据做重采样+插值
            processed_rainfall, processed_evaporation, processed_stage_flow, processed_inflow = None, None, None, None
            # 雨量
            if rainfall_df is not None and not rainfall_df.empty:
                processed_rainfall = process_time_series_data(df=rainfall_df, data_type='rainfall', start_time=start_time, end_time=end_time,
                                                              time_col='time', id_col='rainfall_station_code', freq='1H')
            # 蒸发(如果有)
            if evap_df is not None and not evap_df.empty:
                processed_evaporation = process_time_series_data(df=evap_df, data_type='evap', start_time=start_time, end_time=end_time,
                                                                 time_col='time', id_col='evaporation_station_code', freq='1H')
            # 水位/流量
            if stage_flow_df is not None and not stage_flow_df.empty:
                processed_stage_flow = process_time_series_data(df=stage_flow_df, data_type='flow', start_time=start_time, end_time=end_time,
                                                                time_col='time', id_col='hydrologic_station_code', freq='1H')
            # 入流(如果有)
            if inflow_df is not None and not inflow_df.empty:
                processed_inflow = process_time_series_data(df=inflow_df, data_type='flow', start_time=start_time, end_time=end_time,
                                                            time_col='time', id_col='hydrologic_station_code', freq='1H')

            # c) 将这些处理后的数据，导出到 Excel
            flood_event = export_flood_data_to_excel(section_code=section_code, start_time=str(start_time),
                                                     end_time=str(end_time), rainfall_df=processed_rainfall,
                                                     evaporation_df=processed_evaporation, inflow_df=processed_inflow,
                                                     stage_flow_df=processed_stage_flow,
                                                     output_dir=os.path.join(project_root, "data", "processed",
                                                                             f"{basin_name}", "flood_events",
                                                                             'all_in_one'))

        print("所有洪水场次处理完毕。")

if __name__ == '__main__':
    main()

