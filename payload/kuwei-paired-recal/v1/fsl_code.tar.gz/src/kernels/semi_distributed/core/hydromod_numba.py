import os as _os
try:
    if _os.environ.get("DISABLE_NUMBA") == "1":
        raise ImportError("Disabled via env")
    from numba import njit  # type: ignore
    _HAS_NUMBA = True
except Exception:  # ModuleNotFoundError or disabled
    _HAS_NUMBA = False
    def njit(*args, **kwargs):  # fallback no-op decorator
        def wrap(func):
            return func
        return wrap
import numpy as np
from typing import Tuple, Optional
if not _HAS_NUMBA:
    print("[WARN] numba 未安装，使用纯 Python 版本 hydromod，可能会变慢。建议安装 numba 以加速。")
@njit(cache=True, fastmath=True)
def coupled_pdd_xaj_step_vec_numba(
        joint_state,  # (N, 11)  前一时刻状态
        temp, rain, snow, pet,  # (N,)     强制量
        pdd_pars,  # tuple 4  (fsnow, fice, rfsnow, rfice)
        xaj_pars  # tuple 17 (kc, ki, kg, cs, ci, cg, wum, wlm, wdm, sm, imp, c, b, ex, uf, wmm, ms)
):
    """
    Numba nopython 版本的一步耦合 PDD + XAJ。
    返回 (new_state, runoff)，其中 new_state 仍为 (N,11)。

    状态向量定义：
        0  snow_depth   (mm)
        1  ice_depth    (mm)
        2  last_temp    (°C)   —— 这里直接用当前温度覆盖
        3  grid_to_subbasin_map            (mm)
        4  WU           (mm)
        5  WL           (mm)
        6  WD           (mm)
        7  S            (mm)
        8  QS           (m³/s·km⁻²)  (快速出流)
        9  QI           (……)
        10 QG           (……)
    """

    # 1. 拆分参数
    fsnow, fice, rfsnow, rfice = pdd_pars
    kc, ki, kg, cs, ci_, cg_, wum, wlm, wdm, sm, imp, cpar, b, ex, uf, wmm, ms = xaj_pars

    # 2. 拆分状态
    pdd_state = joint_state[:, :3]  # snow_depth, ice_depth, last_temp
    W = joint_state[:, 3]
    WU = joint_state[:, 4]
    WL = joint_state[:, 5]
    WD = joint_state[:, 6]
    S = joint_state[:, 7]
    QS = joint_state[:, 8]
    QI = joint_state[:, 9]
    QG = joint_state[:, 10]

    # 3. PDD 步骤
    # Debug (仅在 Python / 非 numba 模式下输出一次)
    if not _HAS_NUMBA and hasattr(coupled_pdd_xaj_step_vec_numba, "_dbg_flag") is False:
        print("[DBG] coupled_pdd_xaj_step: shapes",
              "pdd_state", pdd_state.shape,
              "temp", getattr(temp, 'shape', None),
              "rain", getattr(rain, 'shape', None),
              "snow", getattr(snow, 'shape', None),
              "pet", getattr(pet, 'shape', None),
              "fsnow", getattr(fsnow, 'shape', None))
        coupled_pdd_xaj_step_vec_numba._dbg_flag = True  # type: ignore
    new_pdd_state, runoff_pdd = pdd_step_numba(
        pdd_state, temp, rain, snow, fsnow, fice, rfsnow, rfice
    )

    # 4. XAJ 步骤
    # 4.1 土壤水分重分布
    wm = wum + wlm + wdm  # 总土壤水分容量
    W_adj, WU_adj, WL_adj, WD_adj = redistribute_soil_water_numba(
        W, WU, WL, WD, wm, wum, wlm, wdm
    )

    # 4.2 计算有效降水和蒸散发
    ep = pet * kc  # 假设 kc 是蒸散发调整系数
    pe = runoff_pdd - ep  # 有效降水

    # 4.3 计算土壤径流
    runoff_soil = calc_runoff_numba(W_adj, wmm, wm, b, pe)

    # 4.4 更新土壤层
    W_new, WU_new, WL_new, WD_new, evap = update_soil_layers_numba(
        WU_adj, WL_adj, WD_adj, runoff_soil, runoff_pdd, ep, wum, wlm, wdm, cpar
    )

    # 4.5 更新自由水储量
    S_new, RS, RI, RG, fr = free_water_numba(
        S, runoff_soil, pe, ki, kg, ms, sm, ex)

    # 4.6 更新流量状态
    QS_new, QI_new, QG_new = update_q_numba(
        QS, QI, QG, RS, RI, RG, cs, ci_, cg_, uf)

    # 5. 组装新状态
    new_state = np.empty_like(joint_state)
    new_state[:, 0] = new_pdd_state[:, 0]  # snow_depth
    new_state[:, 1] = new_pdd_state[:, 1]  # ice_depth
    new_state[:, 2] = new_pdd_state[:, 2]  # last_temp (temp)
    new_state[:, 3] = W_new
    new_state[:, 4] = WU_new
    new_state[:, 5] = WL_new
    new_state[:, 6] = WD_new
    new_state[:, 7] = S_new
    new_state[:, 8] = QS_new
    new_state[:, 9] = QI_new
    new_state[:, 10] = QG_new

    # 6. 返回结果
    return new_state, runoff_pdd


@njit(cache=True, fastmath=True)
def xaj_step_with_liquid_numba(
        joint_state,
        liquid_precip,
        pet,
        xaj_pars,
        snow_depth_snapshot,
        ice_depth_snapshot,
        last_temp_snapshot,
):
    """
    仅执行 XAJ 步骤，液态降水已由外部融雪模块提供。
    snow_depth/ice_depth/last_temp 由外部快照注入，以保持 STATE_INDEX 中的雪状态可观测。
    """

    kc, ki, kg, cs, ci_, cg_, wum, wlm, wdm, sm, imp, cpar, b, ex, uf, wmm, ms = xaj_pars

    W = joint_state[:, 3]
    WU = joint_state[:, 4]
    WL = joint_state[:, 5]
    WD = joint_state[:, 6]
    S = joint_state[:, 7]
    QS = joint_state[:, 8]
    QI = joint_state[:, 9]
    QG = joint_state[:, 10]

    runoff_pdd = liquid_precip

    wm = wum + wlm + wdm
    W_adj, WU_adj, WL_adj, WD_adj = redistribute_soil_water_numba(
        W, WU, WL, WD, wm, wum, wlm, wdm
    )

    ep = pet * kc
    pe = runoff_pdd - ep
    runoff_soil = calc_runoff_numba(W_adj, wmm, wm, b, pe)
    W_new, WU_new, WL_new, WD_new, _ = update_soil_layers_numba(
        WU_adj, WL_adj, WD_adj, runoff_soil, runoff_pdd, ep, wum, wlm, wdm, cpar
    )

    S_new, RS, RI, RG, _ = free_water_numba(
        S, runoff_soil, pe, ki, kg, ms, sm, ex
    )

    QS_new, QI_new, QG_new = update_q_numba(
        QS, QI, QG, RS, RI, RG, cs, ci_, cg_, uf
    )

    new_state = np.empty_like(joint_state)
    new_state[:, 0] = snow_depth_snapshot
    new_state[:, 1] = ice_depth_snapshot
    new_state[:, 2] = last_temp_snapshot
    new_state[:, 3] = W_new
    new_state[:, 4] = WU_new
    new_state[:, 5] = WL_new
    new_state[:, 6] = WD_new
    new_state[:, 7] = S_new
    new_state[:, 8] = QS_new
    new_state[:, 9] = QI_new
    new_state[:, 10] = QG_new

    return new_state, runoff_pdd

@njit(cache=True, fastmath=True)
def pdd_step_numba(
    state: np.ndarray,              # (N, 3)  float32
    temp:  np.ndarray,              # (N,)
    rain:  np.ndarray,
    snow:  np.ndarray,
    pdd_factor_snow: np.ndarray,    # (N,)  已广播
    pdd_factor_ice:  np.ndarray,
    refreeze_snow:   np.ndarray,
    refreeze_ice:    np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Return:
        new_state (N, 3), runoff (N,)
    """
    # ------- 拆分状态 ----------------------------------------------------
    snow_depth = state[:, 0].copy()
    ice_depth  = state[:, 1].copy()

    # 1. 新雪
    snow_depth += snow

    # 2. 正积温
    pdd = np.maximum(temp, 0.0)

    # 3. 严格模式：假设上游已完成参数合法性校验，不在此处做运行期裁剪
    tiny = np.float32(1e-12)
    fsnow = pdd_factor_snow
    fice  = pdd_factor_ice
    rfs   = refreeze_snow
    rfi   = refreeze_ice

    # 4. 潜在雪融
    pot_snow_melt = fsnow * pdd
    act_snow_melt = np.minimum(snow_depth, pot_snow_melt)

    # 5. 冰融（能量剩余 → 冰；当 fsnow≈0 时，直接使用 fice*pdd 避免 0*inf）
    remaining_e = pot_snow_melt - act_snow_melt
    ice_melt = np.where(fsnow > tiny, remaining_e * (fice / fsnow), fice * pdd)
    act_ice_melt = np.minimum(ice_depth, ice_melt)

    # 6. 再冻结
    ref_snow = act_snow_melt * rfs
    ref_ice  = act_ice_melt  * rfi

    # 7. 更新雪/冰深（确保不为负）
    snow_depth = snow_depth - act_snow_melt + ref_snow
    ice_depth  = ice_depth  - act_ice_melt  + ref_ice

    # 8. 径流
    runoff = act_snow_melt + act_ice_melt - ref_snow - ref_ice + rain

    # 9. 组装新状态
    new_state = np.empty_like(state)
    new_state[:, 0] = np.maximum(snow_depth, 0.0)
    new_state[:, 1] = np.maximum(ice_depth, 0.0)
    new_state[:, 2] = temp         # 最新温度

    return new_state, runoff


@njit(cache=True, fastmath=True)
def pdd_step_hbv_numba(
    state: np.ndarray,              # (N, 4)  [snow_depth, liquid_water, last_temp, _placeholder]
    temp:  np.ndarray,              # (N,)
    rain:  np.ndarray,
    snow:  np.ndarray,
    pdd_factor_snow: np.ndarray,    # (N,)  度日因子 (mm/°C/day)
    cfr:             np.ndarray,    # (N,)  再冻结系数 (dimensionless)
    cwh:             np.ndarray,    # (N,)  持水系数 (fraction of SWE)
) -> Tuple[np.ndarray, np.ndarray]:
    """HBV 风格的融雪步骤（Bergström 1976 / Lindström et al. 1997）。

    状态向量定义 (N, 4)：
        0  snow_depth       (mm)  雪水当量 SWE
        1  liquid_water     (mm)  雪内液态水
        2  last_temp        (°C)  上一步温度（用于诊断，本步更新为当前温度）
        3  _placeholder           预留位

    与 V1 (pdd_step_numba) 的关键差异：
        - 再冻结由负积温驱动：pot_refreeze = cfr × fsnow × max(-T, 0)
        - 融雪水和降雨先进入雪内液态水库，超过 cwh × snow_depth 的部分才成为径流
        - 不单独建模冰层（简化 HBV 方案）

    Return:
        new_state (N, 4), runoff (N,)
    """
    snow_depth    = state[:, 0].copy()
    liquid_water  = state[:, 1].copy()

    # 1. 新降雪累加
    snow_depth += snow

    # 2. 融雪 / 再冻结（互斥）
    melt     = np.zeros_like(temp)
    refreeze = np.zeros_like(temp)

    for i in range(temp.size):
        if temp[i] > 0.0:
            # 融雪：正积温驱动
            pot_melt = pdd_factor_snow[i] * temp[i]
            act_melt = min(snow_depth[i], pot_melt)
            melt[i] = act_melt
            snow_depth[i] -= act_melt
            liquid_water[i] += act_melt
        else:
            # 再冻结：负积温驱动
            pot_refreeze = cfr[i] * pdd_factor_snow[i] * (-temp[i])
            act_refreeze = min(liquid_water[i], pot_refreeze)
            refreeze[i] = act_refreeze
            liquid_water[i] -= act_refreeze
            snow_depth[i] += act_refreeze

    # 3. 降雨进入雪层 or 直接成为径流
    runoff = np.zeros_like(temp)
    for i in range(temp.size):
        if snow_depth[i] > 1e-6:
            # 有雪覆盖：降雨进入液态水库
            liquid_water[i] += rain[i]
            # 超过持水能力的部分释放为径流
            max_lw = cwh[i] * snow_depth[i]
            excess = liquid_water[i] - max_lw
            if excess > 0.0:
                runoff[i] = excess
                liquid_water[i] = max_lw
            # else: runoff[i] = 0, 降雨和融雪水都被雪层吸收
        else:
            # 无雪覆盖：降雨直接成为径流，液态水也全部释放
            runoff[i] = rain[i] + liquid_water[i]
            liquid_water[i] = 0.0

    # 4. 组装新状态
    new_state = np.empty_like(state)
    new_state[:, 0] = np.maximum(snow_depth, 0.0)
    new_state[:, 1] = np.maximum(liquid_water, 0.0)
    new_state[:, 2] = temp
    new_state[:, 3] = 0.0  # placeholder

    return new_state, runoff


@njit(cache=True, fastmath=True)
def coupled_pdd_xaj_step_vec_hbv_numba(
        joint_state,  # (N, 11)  前一时刻状态
        temp, rain, snow, pet,  # (N,)     强制量
        pdd_pars,  # tuple 6  (fsnow, fice_unused, cfr, cwh, _r1, _r2) -- 见下述映射
        xaj_pars  # tuple 17
):
    """
    HBV 版本的一步耦合 PDD + XAJ。

    joint_state 列定义（与 V1 保持一致的 11 列，语义微调）：
        0  snow_depth   (mm)
        1  liquid_water (mm)  ← V1 中为 ice_depth，V2 中复用为液态水
        2  last_temp    (°C)
        3  W            (mm)
        4-10  同 V1 (WU, WL, WD, S, QS, QI, QG)

    pdd_pars 映射（6 元素 tuple）：
        0: pdd_factor_snow (fsnow)
        1: pdd_factor_ice  (V2 中未使用，保持接口兼容)
        2: refreeze_snow   (V2 中重新解释为 cfr)
        3: refreeze_ice    (V2 中未使用)
        4: cfr             (再冻结系数)
        5: cwh             (持水系数)
    """
    # 1. 拆分参数
    fsnow = pdd_pars[0]
    # pdd_pars[1] = fice (unused in HBV)
    # pdd_pars[2], pdd_pars[3] = rfsnow, rfice (unused in HBV)
    cfr = pdd_pars[4]
    cwh = pdd_pars[5]

    kc, ki, kg, cs, ci_, cg_, wum, wlm, wdm, sm, imp, cpar, b, ex, uf, wmm, ms = xaj_pars

    # 2. 拆分状态 — PDD 部分用 4 列
    pdd_state = np.empty((joint_state.shape[0], 4), dtype=np.float32)
    pdd_state[:, 0] = joint_state[:, 0]  # snow_depth
    pdd_state[:, 1] = joint_state[:, 1]  # liquid_water (was ice_depth)
    pdd_state[:, 2] = joint_state[:, 2]  # last_temp
    pdd_state[:, 3] = 0.0               # placeholder

    W  = joint_state[:, 3]
    WU = joint_state[:, 4]
    WL = joint_state[:, 5]
    WD = joint_state[:, 6]
    S  = joint_state[:, 7]
    QS = joint_state[:, 8]
    QI = joint_state[:, 9]
    QG = joint_state[:, 10]

    # 3. HBV PDD 步骤
    new_pdd_state, runoff_pdd = pdd_step_hbv_numba(
        pdd_state, temp, rain, snow, fsnow, cfr, cwh
    )

    # 4. XAJ 步骤 (与 V1 完全相同)
    wm = wum + wlm + wdm
    W_adj, WU_adj, WL_adj, WD_adj = redistribute_soil_water_numba(
        W, WU, WL, WD, wm, wum, wlm, wdm
    )

    ep = pet * kc
    pe = runoff_pdd - ep

    runoff_soil = calc_runoff_numba(W_adj, wmm, wm, b, pe)
    W_new, WU_new, WL_new, WD_new, evap = update_soil_layers_numba(
        WU_adj, WL_adj, WD_adj, runoff_soil, runoff_pdd, ep, wum, wlm, wdm, cpar
    )
    S_new, RS, RI, RG, fr = free_water_numba(
        S, runoff_soil, pe, ki, kg, ms, sm, ex)
    QS_new, QI_new, QG_new = update_q_numba(
        QS, QI, QG, RS, RI, RG, cs, ci_, cg_, uf)

    # 5. 组装新状态
    new_state = np.empty_like(joint_state)
    new_state[:, 0] = new_pdd_state[:, 0]   # snow_depth
    new_state[:, 1] = new_pdd_state[:, 1]   # liquid_water
    new_state[:, 2] = new_pdd_state[:, 2]   # last_temp
    new_state[:, 3] = W_new
    new_state[:, 4] = WU_new
    new_state[:, 5] = WL_new
    new_state[:, 6] = WD_new
    new_state[:, 7] = S_new
    new_state[:, 8] = QS_new
    new_state[:, 9] = QI_new
    new_state[:, 10] = QG_new

    return new_state, runoff_pdd


@njit(cache=True, fastmath=True)
def pdd_step_v3_numba(
    state: np.ndarray,              # (N, 3)  [snow_depth, ice_depth, liquid_water]
    temp:  np.ndarray,              # (N,)
    rain:  np.ndarray,
    snow:  np.ndarray,
    pdd_factor_snow: np.ndarray,    # (N,)  度日因子-雪 (mm/°C/day)
    pdd_factor_ice:  np.ndarray,    # (N,)  度日因子-冰 (mm/°C/day)
    cfr:             np.ndarray,    # (N,)  再冻结系数 (dimensionless)
    cwh:             np.ndarray,    # (N,)  持水系数 (fraction of SWE)
    rfice:           np.ndarray,    # (N,)  冰融再冻结分数 (0-1), V1 遗传
) -> Tuple[np.ndarray, np.ndarray]:
    """V3 PDD: HBV 标准雪物理 + V1 冰川能量级联 + 冰融衰减。

    状态向量定义 (N, 3)：
        0  snow_depth       (mm)  雪水当量 SWE
        1  ice_depth        (mm)  冰层深度
        2  liquid_water     (mm)  雪/冰内液态水

    与 V1/V2 的关键差异：
        - 融雪 + 能量级联融冰（V1 特性）：正温先融雪，剩余能量按 fice/fsnow 融冰
        - 液态水池 + cwh 持水（V2/HBV 特性）：融水和降雨先进入液态水池
        - 再冻结由负积温驱动（V2/HBV 特性）：cfr × fsnow × max(-T, 0)
        - 冰融衰减（V1 rfice 特性）：只有 (1-rfice) 的冰融水进入径流过程

    Return:
        new_state (N, 3), runoff (N,)
    """
    snow_depth   = state[:, 0].copy()
    ice_depth    = state[:, 1].copy()
    liquid_water = state[:, 2].copy()

    tiny = np.float32(1e-12)

    # 1. 新降雪累加
    snow_depth += snow

    # 2. 融雪/融冰 或 再冻结（互斥）
    for i in range(temp.size):
        if temp[i] > 0.0:
            # --- 正温：融雪 + 能量级联融冰 ---
            pot_snow_melt = pdd_factor_snow[i] * temp[i]
            act_snow_melt = min(snow_depth[i], pot_snow_melt)
            snow_depth[i] -= act_snow_melt

            # 剩余能量 → 融冰（V1 能量级联）
            remaining_e = pot_snow_melt - act_snow_melt
            if pdd_factor_snow[i] > tiny:
                ice_melt = remaining_e * (pdd_factor_ice[i] / pdd_factor_snow[i])
            else:
                ice_melt = pdd_factor_ice[i] * temp[i]
            act_ice_melt = min(ice_depth[i], ice_melt)
            ice_depth[i] -= act_ice_melt

            # 冰融水衰减：rfice 的部分"再冻结"回冰层（V1 特性）
            # 只有 (1-rfice) 的冰融水真正进入液态水池
            ice_refreeze = act_ice_melt * rfice[i]
            ice_depth[i] += ice_refreeze
            ice_melt_net = act_ice_melt - ice_refreeze

            # 融水进入液态水池（雪融全部 + 冰融净值）
            liquid_water[i] += act_snow_melt + ice_melt_net
        else:
            # --- 负温：再冻结（HBV 方式）---
            pot_refreeze = cfr[i] * pdd_factor_snow[i] * (-temp[i])
            act_refreeze = min(liquid_water[i], pot_refreeze)
            liquid_water[i] -= act_refreeze
            snow_depth[i] += act_refreeze

    # 3. 降雨进入雪层 or 直接成为径流（HBV 持水机制）
    runoff = np.zeros_like(temp)
    for i in range(temp.size):
        if snow_depth[i] > 1e-6 or ice_depth[i] > 1e-6:
            # 有雪/冰覆盖：降雨进入液态水库
            liquid_water[i] += rain[i]
            # 持水能力仅基于雪深（标准 HBV），冰面不持水
            max_lw = cwh[i] * snow_depth[i]
            excess = liquid_water[i] - max_lw
            if excess > 0.0:
                runoff[i] = excess
                liquid_water[i] = max_lw
        else:
            # 无雪/冰覆盖：降雨 + 液态水全部释放
            runoff[i] = rain[i] + liquid_water[i]
            liquid_water[i] = 0.0

    # 4. 组装新状态
    new_state = np.empty_like(state)
    new_state[:, 0] = np.maximum(snow_depth, 0.0)
    new_state[:, 1] = np.maximum(ice_depth, 0.0)
    new_state[:, 2] = np.maximum(liquid_water, 0.0)

    return new_state, runoff


@njit(cache=True, fastmath=True)
def coupled_pdd_xaj_step_vec_v3_numba(
        joint_state,  # (N, 11)  前一时刻状态
        temp, rain, snow, pet,  # (N,)     强制量
        pdd_pars,  # tuple 4  (fsnow, fice, cfr, cwh)
        xaj_pars  # tuple 17
):
    """
    V3 版本的一步耦合 PDD + XAJ（HBV 雪物理 + 冰川能量级联）。

    joint_state 列定义（11 列）：
        0  snow_depth   (mm)
        1  ice_depth    (mm)   ← V3 保留冰层（与 V1 相同）
        2  liquid_water (mm)   ← V3 液态水池（V2/HBV 特性）
        3  W            (mm)
        4-10  同 V1 (WU, WL, WD, S, QS, QI, QG)

    pdd_pars 映射（5 元素 tuple）：
        0: pdd_factor_snow (fsnow)
        1: pdd_factor_ice  (fice)
        2: cfr             (再冻结系数)
        3: cwh             (持水系数)
        4: rfice           (冰融再冻结分数)
    """
    # 1. 拆分参数
    fsnow = pdd_pars[0]
    fice  = pdd_pars[1]
    cfr   = pdd_pars[2]
    cwh   = pdd_pars[3]
    rfice = pdd_pars[4]

    kc, ki, kg, cs, ci_, cg_, wum, wlm, wdm, sm, imp, cpar, b, ex, uf, wmm, ms = xaj_pars

    # 2. 拆分状态 — PDD 部分用 3 列
    pdd_state = np.empty((joint_state.shape[0], 3), dtype=np.float32)
    pdd_state[:, 0] = joint_state[:, 0]  # snow_depth
    pdd_state[:, 1] = joint_state[:, 1]  # ice_depth
    pdd_state[:, 2] = joint_state[:, 2]  # liquid_water

    W  = joint_state[:, 3]
    WU = joint_state[:, 4]
    WL = joint_state[:, 5]
    WD = joint_state[:, 6]
    S  = joint_state[:, 7]
    QS = joint_state[:, 8]
    QI = joint_state[:, 9]
    QG = joint_state[:, 10]

    # 3. V3 PDD 步骤
    new_pdd_state, runoff_pdd = pdd_step_v3_numba(
        pdd_state, temp, rain, snow, fsnow, fice, cfr, cwh, rfice
    )

    # 4. XAJ 步骤 (与 V1/V2 完全相同)
    wm = wum + wlm + wdm
    W_adj, WU_adj, WL_adj, WD_adj = redistribute_soil_water_numba(
        W, WU, WL, WD, wm, wum, wlm, wdm
    )

    ep = pet * kc
    pe = runoff_pdd - ep

    runoff_soil = calc_runoff_numba(W_adj, wmm, wm, b, pe)
    W_new, WU_new, WL_new, WD_new, evap = update_soil_layers_numba(
        WU_adj, WL_adj, WD_adj, runoff_soil, runoff_pdd, ep, wum, wlm, wdm, cpar
    )
    S_new, RS, RI, RG, fr = free_water_numba(
        S, runoff_soil, pe, ki, kg, ms, sm, ex)
    QS_new, QI_new, QG_new = update_q_numba(
        QS, QI, QG, RS, RI, RG, cs, ci_, cg_, uf)

    # 5. 组装新状态
    new_state = np.empty_like(joint_state)
    new_state[:, 0] = new_pdd_state[:, 0]   # snow_depth
    new_state[:, 1] = new_pdd_state[:, 1]   # ice_depth
    new_state[:, 2] = new_pdd_state[:, 2]   # liquid_water
    new_state[:, 3] = W_new
    new_state[:, 4] = WU_new
    new_state[:, 5] = WL_new
    new_state[:, 6] = WD_new
    new_state[:, 7] = S_new
    new_state[:, 8] = QS_new
    new_state[:, 9] = QI_new
    new_state[:, 10] = QG_new

    return new_state, runoff_pdd


@njit(cache=True, fastmath=True)
def update_q_numba(qs, qi, qg, rs, ri, rg, cs, ci_, cg_, uf):
    qs_new = cs*qs + (1-cs)*rs*uf
    qi_new = ci_*qi + (1-ci_)*ri*uf
    qg_new = cg_*qg + (1-cg_)*rg*uf
    return qs_new, qi_new, qg_new

@njit(fastmath=True, cache=True)
def redistribute_soil_water_numba(w, wu, wl, wd,
                                  wm, wum, wlm, wdm):
    # 先按上限裁剪总土壤水
    w = np.clip(w, 0.0, wm)
    extra = w - (wu + wl + wd)

    for i in range(w.size):
        # ---- 正值：向各层填充 -----------------------------------------
        if extra[i] > 1e-4:                                # ★ 保留阈值
            take = min(extra[i], wum[i] - wu[i]); wu[i] += take; extra[i] -= take
            take = min(extra[i], wlm[i] - wl[i]); wl[i] += take; extra[i] -= take
            take = min(extra[i], wdm[i] - wd[i]); wd[i] += take; extra[i] -= take

        # ---- 负值：从各层回补 -----------------------------------------
        elif extra[i] < -1e-4:
            take = min(-extra[i], wu[i]); wu[i] -= take; extra[i] += take
            take = min(-extra[i], wl[i]); wl[i] -= take; extra[i] += take
            take = min(-extra[i], wd[i]); wd[i] -= take; extra[i] += take

    # clip 各层
    wu = np.clip(wu, 0.0, wum)
    wl = np.clip(wl, 0.0, wlm)
    wd = np.clip(wd, 0.0, wdm)

    # ★ 不再把 w 改成各层之和
    return w, wu, wl, wd

@njit(fastmath=True, cache=True)
def calc_runoff_numba(w, wmm, wm, b, pe):
    N = w.size
    out = np.zeros_like(pe)
    wm_safe = np.maximum(wm, 1e-12)
    frac = np.maximum(0.0, np.minimum(1.0, 1 - w / wm_safe))
    w_temp = wmm * (1 - np.power(frac, 1.0 / (1.0 + b)))
    # 把 for-loop 里的 pow 换成矢量化
    tmp = w_temp + pe
    cond = tmp <= wmm
    out = np.where(
        (pe > 0) & cond,
        pe + w - wm + wm * np.power(1 - tmp / wmm, 1 + b),
        np.where((pe > 0) & (~cond), pe + w - wm, 0.0)
    )
    return out.astype(pe.dtype)


@njit(cache=True, fastmath=True)
def update_soil_layers_numba(
    wu: np.ndarray, wl: np.ndarray, wd: np.ndarray,
    runoff: np.ndarray, rain: np.ndarray, ep: np.ndarray,
    wum: np.ndarray, wlm: np.ndarray, wdm: np.ndarray,
    cpar: np.ndarray
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    **逐行等价**于 pdd_xaj_backend.update_soil_layers_backend，
    只是把 xp → np，并放进 Numba。
    返回 (w_total, new_wu, new_wl, new_wd, evap_total)
    """
    pe = rain - ep
    water_extra = np.maximum(pe - runoff, 0.0)

    eu = np.zeros_like(pe)
    el = np.zeros_like(pe)
    ed = np.zeros_like(pe)

    new_wu = wu.copy()
    new_wl = wl.copy()
    new_wd = wd.copy()

    # ---------------- pe > 0 -----------------
    mask_pos = pe > 0.0
    if mask_pos.any():
        idx = np.where(mask_pos)
        eu[idx] = ep[idx]

        wu_plus = new_wu[idx] + water_extra[idx]
        over1   = wu_plus > wum[idx]
        new_wu[idx]      = np.where(over1, wum[idx], wu_plus)
        water_extra1     = np.where(over1, wu_plus - wum[idx], 0.0)

        wl_plus = new_wl[idx] + water_extra1
        over2   = wl_plus > wlm[idx]
        new_wl[idx]      = np.where(over2, wlm[idx], wl_plus)
        water_extra2     = np.where(over2, wl_plus - wlm[idx], 0.0)

        wd_plus = new_wd[idx] + water_extra2
        over3   = wd_plus > wdm[idx]
        new_wd[idx]      = np.where(over3, wdm[idx], wd_plus)

    # ---------------- pe <= 0 ----------------
    mask_neg = pe <= 0.0
    if mask_neg.any():
        idx = np.where(mask_neg)[0]

        cond_A = (new_wu[idx] + rain[idx]) > ep[idx]
        # Branch-A
        if cond_A.any():
            ia = idx[cond_A]
            eu[ia]    = ep[ia]
            new_wu[ia] += pe[ia]

        # Branch-B
        if (~cond_A).any():
            ib = idx[~cond_A]
            eu[ib]    = new_wu[ib] + rain[ib]
            remainder = ep[ib] - eu[ib]          # < 0
            new_wu[ib] = 0.0

            cond1 = new_wl[ib] >= cpar[ib] * wlm[ib]
            # (a)
            ia2 = ib[cond1]
            if ia2.size:
                el_a = np.abs(remainder[cond1] * new_wl[ia2] / wlm[ia2])
                new_wl[ia2] -= el_a
                el[ia2]      = el_a
            # (b)
            cond2 = ~cond1 & (new_wl[ib] >= cpar[ib] * np.abs(remainder))
            ib2 = ib[cond2]
            if ib2.size:
                el_b = cpar[ib2] * np.abs(remainder[cond2])
                new_wl[ib2] -= el_b
                el[ib2]      = el_b
            # (c)
            ic2 = ib[~cond1 & ~cond2]
            if ic2.size:
                el[ic2]      = new_wl[ic2]
                new_wl[ic2]  = 0.0
                ed_c = np.abs(cpar[ic2] * remainder[~cond1 & ~cond2] - el[ic2])
                new_wd[ic2] -= ed_c
                ed[ic2]      = ed_c

    # clip & aggregate
    new_wu = np.clip(new_wu, 0.0, wum)
    new_wl = np.clip(new_wl, 0.0, wlm)
    new_wd = np.clip(new_wd, 0.0, wdm)

    w_total = new_wu + new_wl + new_wd
    evap    = eu + el + ed
    return w_total, new_wu, new_wl, new_wd, evap

@njit(cache=True, fastmath=True)
def free_water_numba(
    s: np.ndarray, runoff: np.ndarray, pe: np.ndarray,
    ki: np.ndarray, kg: np.ndarray,
    ms: np.ndarray, sm: np.ndarray, ex: np.ndarray
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    # ---- 统一 dtype ---------------------------------------------------
    s = s.astype(np.float32)
    runoff = runoff.astype(np.float32)
    pe = pe.astype(np.float32)
    ki = ki.astype(np.float32)
    kg = kg.astype(np.float32)
    ms = ms.astype(np.float32)
    sm = sm.astype(np.float32)
    ex = ex.astype(np.float32)

    zero     = np.float32(0.0)
    one      = np.float32(1.0)
    tiny     = np.float32(1e-12)

    # 1) 初步更新自由水储量
    s_new = np.minimum(sm, s) * (one - ki - kg)

    sm_safe = np.maximum(sm, tiny)
    frac    = np.clip(one - s_new / sm_safe, zero, one)
    s_temp  = ms * (one - np.power(frac, one / (one + ex)))

    # 2) fr
    fr = np.zeros_like(pe)
    mask = (runoff > zero) & (pe > tiny)
    fr[mask] = np.minimum(one, runoff[mask] / pe[mask])

    # 3) RS
    RS = np.zeros_like(pe)
    cond1 = (runoff > zero) & ((pe + s_temp) < ms)
    RS[cond1] = fr[cond1] * (
        pe[cond1] + s_new[cond1] - sm[cond1] +
        sm[cond1] * np.power(one - (pe[cond1] + s_temp[cond1]) / ms[cond1], one + ex[cond1])
    )
    cond2 = (runoff > zero) & (~cond1)
    RS[cond2] = fr[cond2] * (pe[cond2] + s_new[cond2] - sm[cond2])

    # 4) 把 RS/fr 扣回 s_new
    ratio_rs = np.zeros_like(RS)
    nz = fr > tiny
    ratio_rs[nz] = RS[nz] / fr[nz]
    s_new = np.where(runoff > zero,
                     np.clip(s_new + pe - ratio_rs, zero, sm),
                     np.minimum(sm, s_new))

    # 5) RI / RG
    RI = ki * s_new * fr
    RG = kg * s_new * fr
    return s_new, RS, RI, RG, fr

@njit(cache=True, fastmath=True)
def _muskingum_step(
    msk_state_last: np.ndarray,
    q_grid_dis: np.ndarray,
    c0: np.ndarray, c1: np.ndarray, c2: np.ndarray,
    n_sub: np.ndarray
) -> Tuple[np.ndarray, float]:
    msk_state_now = muskingum_subreach_step_vec_numba(msk_state_last, q_grid_dis, c0, c1, c2, n_sub)
    # —— 关键：逐行取 “n_sub[i]-1” 列并求和 —— #
    Ns = n_sub.size
    q_sub_out = np.empty(Ns, np.float32) # 每条流域自己的msk演算结果
    for i in range(Ns):
        q_sub_out[i] = msk_state_now[i, n_sub[i] - 1] # 为了方便计算取的最大的n_sub，但n_sub[i] - 1是实际的最后一个有效、即出口位置
    return msk_state_now, q_sub_out

# --- Muskingum Numba 版本 ----------------------------------------------------
@njit(cache=True, fastmath=True)
def muskingum_subreach_step_vec_numba(q_last, q_in, c0, c1, c2, n_sub):
    Ns, max_n = q_last.shape
    # -----[维度安全检查]-----
    # 确保所有输入向量长度与 q_last 的第一维 (Ns) 匹配
    if not (q_in.shape[0] == Ns and
            c0.shape[0] == Ns and
            c1.shape[0] == Ns and
            c2.shape[0] == Ns):
        # Numba 中无法打印字符串，但 assert 会在维度不匹配时中断执行
        raise AssertionError("Muskingum input dimension mismatch")

    q_next = np.empty_like(q_last)
    # 预留最后一列用于存储“上一时刻入口流量”以支撑标准 Muskingum I_t 项
    last_in_col = max_n - 1
    for i in range(Ns):
        nseg = int(n_sub[i])
        if nseg < 1:
            nseg = 1

        # 默认先拷贝，避免 padding 区域被非预期覆盖
        for j in range(max_n):
            q_next[i, j] = q_last[i, j]

        # --- 子段 0：使用当前入流 q_in、上一时刻入流(存于 last_in_col)与上一时刻出流(q_last[i,0])
        I_prev = q_last[i, last_in_col]
        O_prev = q_last[i, 0]
        O_next = c0[i] * q_in[i] + c1[i] * I_prev + c2[i] * O_prev
        q_next[i, 0] = O_next

        # --- 其余子段：入流为上一子段本时刻出流，I_prev 为上一时刻该子段入流(上游出流的滞后)，O_prev 为该子段上一时刻出流
        inflow_now = O_next
        for j in range(1, nseg):
            I_prev_seg = q_last[i, j - 1]  # 上一时刻本段入流 == 上游段上一时刻出流
            O_prev_seg = q_last[i, j]      # 本段上一时刻出流
            O_next_seg = c0[i] * inflow_now + c1[i] * I_prev_seg + c2[i] * O_prev_seg
            q_next[i, j] = O_next_seg
            inflow_now = O_next_seg

        # --- 更新上一时刻入口记录，供下一步的 I_t 使用
        q_next[i, last_in_col] = q_in[i]

    return q_next

# ---------------------------------------------------------------------------
# High-level layered Muskingum routing (Python, not jitted)
# ---------------------------------------------------------------------------
def _route_msk_layers_step(
    q_layer_in: np.ndarray,
    msk_states: list,
    msk_layers_params: list,
    C_mats: list,  # 2025-10: 将逐步重命名为 layer_connect_mats；此处保留旧名以避免大量外部调用同时破坏。
    *,
    obs_row: Optional[np.ndarray] = None,   # shape (N_sta,) or None
    sta_reach_idx: Optional[np.ndarray] = None,
):
    """执行单个时间步的分层 Muskingum 路由。

    返回: (msk_states, layer_outputs_t, next_input, last_layer_out)
        - msk_states         : 各层更新后的状态列表（就地修改后同名返回）
        - layer_outputs_t    : 长度 = num_layers；第 L 项为该层所有 reach 出口流量向量
        - next_input         : 最后一层“传递出去”的输入（通常无后继层仅用于兼容旧接口）
        - last_layer_out     : 与 layer_outputs_t[-1] 相同的引用（兼容外部旧解包逻辑）

    C_mats 语义（修订 & 明确） / layer_connect_mats 重命名计划
    ------------------------------------------------------------------
    C_mats[L] (即 layer_connect_mats[L]) 是一个 2-D 矩阵，其形状应为:
        (#reaches_in_next_layer, #reaches_in_current_layer)
    作用：将当前层的出口流量向量 q_out^(L) 映射/聚合/分配到下一层各 reach 的“入流”向量：
        q_in^(L+1) = C_mats[L] @ q_out^(L)
    注意：
      1) 对最后一层 (L = num_layers-1) 不使用 C_mats。
      2) 若存在某层后仍需要保留到“更大域”或“全局”空间，请在外部构造相应映射矩阵；
         本函数只假定逐层点对点或聚合/分配映射。
      3) 第一层输入 q_layer_in 可能是“全局（subbasin 或单元汇流）”向量，其长度 >= 第一层
         reach 数；通过 idx 选择出属于该层的那部分作为 q_in^(0)。后续层输入长度即与该层
         reach 数一致，无需再次使用 idx 切片（若仍给出 idx，保持一致性做安全校验）。

    统一输入处理（本次改动要点）
    ------------------------------------------------------------------
    旧实现对 L=0 做了特殊下标切片，后续层直接使用更新后的 q_in。为便于理解与避免
    误用，这里显式：
        - 规范化 first layer 输入：q_in = q_layer_in[idx0] （若长度已匹配则跳过切片）
        - 每层循环内 q_in_L = q_in（不再区分 L=0 逻辑）
        - 每层完成后若有下一层：验证 C_mats[L] 形状并计算 q_in = C_mats[L] @ q_out
          同时校验结果长度与下一层 reach 数一致；否则抛出 ValueError 便于快速定位配置错误。

    观测覆写 (use_obs=True)
    ------------------------------------------------------------------
    逻辑保持：若某观测 reach 位于该层 idx 内，则覆写对应出口流量并同步写回该 reach 状态
    的最后一个有效子段列 (n_sub[k]-1)。

    复杂度与副作用
    ------------------------------------------------------------------
    时间复杂度 O( Σ L (#reach_L * n_sub_mean_L) + Σ L 矩阵乘 @ )；C_mats (layer_connect_mats) 通常稀疏时可在
    
    重命名兼容说明
    ------------------------------------------------------------------
    2025-10: 核心 state-space 文件已使用 layer_connect_mats；本函数仍保持 C_mats 形参以维持
    现有 Numba 以外 Python 调用不受影响。后续步骤：
        1) 在调用方预先统一变量名 layer_connect_mats，再以 C_mats 作为别名传入。
        2) 最终阶段（若需要）提供一个轻量 wrapper: _route_msk_layers_step_renamed(..., layer_connect_mats).
    未来替换为显式稀疏乘法以进一步加速。
    """
    num_layers = len(msk_layers_params)
    use_obs = (obs_row is not None) and (sta_reach_idx is not None)
    outs_t = []
    # ---- 预处理第一层输入 ----
    if num_layers == 0:
        return msk_states, outs_t, q_layer_in, None

    first_idx = msk_layers_params[0][0]
    # 如果初始输入长度大于第一层 reach 数，切片；若等于则直接使用
    if q_layer_in.shape[0] == len(first_idx):
        q_in = q_layer_in
    elif q_layer_in.shape[0] > len(first_idx):
        q_in = q_layer_in[first_idx]
    else:
        raise ValueError(
            f"第一层输入长度 {q_layer_in.shape[0]} 小于第一层 reach 数 {len(first_idx)}，无法路由")
    last_layer_out = None

    for L_idx in range(num_layers):
        idx, c0, c1, c2, n_sub = msk_layers_params[L_idx]
        # ---- 安全校验：当前输入长度需与当前层 reach 数一致 ----
        if q_in.shape[0] != len(idx):
            raise ValueError(
                f"第 {L_idx} 层输入长度={q_in.shape[0]} 与该层 reach 数={len(idx)} 不一致")
        q_in_L = q_in  # 统一处理，不区分 L=0
        # ② Muskingum 计算
        cur_state, q_out = _muskingum_step(msk_states[L_idx], q_in_L, c0, c1, c2, n_sub)
        msk_states[L_idx] = cur_state
        # ③ 覆写观测：对所有层生效，并保持 Muskingum 状态与覆写后一致
        if use_obs:
            for j, reach in enumerate(sta_reach_idx):
                # 仅处理落在本层的测站
                if reach in idx:
                    k = np.where(idx == reach)[0][0]
                    q_obs = obs_row[j]
                    if np.isfinite(q_obs):
                        # 覆写本层该条河段的出口流量
                        q_out[k] = q_obs
                        # 同步覆写至状态的“最后一个有效子河段”位置，保持时序链一致
                        last_col = int(n_sub[k] - 1)
                        if 0 <= last_col < msk_states[L_idx].shape[1]:
                            msk_states[L_idx][k, last_col] = q_obs
        # 记录
        outs_t.append(q_out)
        # 下一层输入
        if L_idx < num_layers - 1:
            if L_idx >= len(C_mats):
                raise ValueError(f"缺少 C_mats[{L_idx}]，共有层数={num_layers}")
            C = C_mats[L_idx]
            # 期望形状: (next_reaches, current_reaches)
            next_idx = msk_layers_params[L_idx + 1][0]
            expected_shape = (len(next_idx), q_out.shape[0])
            if C.shape != expected_shape:
                raise ValueError(
                    f"C_mats[{L_idx}] 形状 {C.shape} 与期望 {expected_shape} 不符 (next, current)")
            q_in_upstream = C @ q_out
            
            # [FIX] 加上下一层的区间产流 (Lateral Inflow)
            # q_layer_in 包含全局所有子流域产流；next_idx 是下一层的全局ID
            if q_layer_in.shape[0] > len(first_idx):  # 确认为全量子流域模式
                q_in_local = q_layer_in[next_idx]
                q_in = q_in_upstream + q_in_local
            else:
                # 兼容旧逻辑（若输入仅含第一层），则无区间产流
                q_in = q_in_upstream
        else:
            last_layer_out = q_out

    return msk_states, outs_t, q_in, last_layer_out

