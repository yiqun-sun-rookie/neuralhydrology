"""
Generic simulate_core with pluggable production model.

Replaces the Numba-coupled PDD+XAJ kernel with:
  Python PDD (dict-based) + any step_vec function + existing Muskingum routing.

Only depends on existing modules — no modifications to existing code.
"""
from __future__ import annotations

from typing import Callable

import numpy as np

from src.kernels.core.hydro_model.process_model.positive_degree_day.pdd_fixed import (
    simulate_pdd_step_fixed as simulate_pdd_step_parallel,
)
from src.kernels.semi_distributed.core.hydromod_numba import (
    _route_msk_layers_step,
)


def simulate_core_generic(
    rain: np.ndarray,           # (T, Ng) mm
    temp: np.ndarray,           # (T, Ng) degC
    snow: np.ndarray,           # (T, Ng) mm (solid precip)
    pet: np.ndarray,            # (T, Ng) mm
    pdd_params: dict,           # PDD param_dict (keys: pdd_factor_snow, etc.)
    prod_params: dict,          # Production model param_dict
    grid2sub: np.ndarray,       # (Ng, Ns) float32
    init_state: np.ndarray,     # (Ng, 11) — [PDD(3) + production(8)]
    msk_layers_params: list,    # [(idx, c0, c1, c2, n_sub), ...]
    C_mats: list,               # aggregation matrices between layers
    *,
    prod_step_fn: Callable,     # vm_step_vec or sb_step_vec
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Generic forward model: PDD -> pluggable production -> Muskingum routing.

    Returns
    -------
    q_grid   : (T, Ng) per-cell discharge (m3/s)
    q_subs   : (T, Ns_layer0) subbasin outflows from first Muskingum layer
    q_outlet : (T,) total outlet discharge
    """
    T, Ng = rain.shape
    Ns = grid2sub.shape[1]

    # Split init state
    pdd_state = init_state[:, :3].copy().astype(np.float64)
    prod_state = init_state[:, 3:].copy().astype(np.float64)

    # Muskingum state init
    q0 = np.maximum(prod_state[:, -3:].sum(axis=1), 0.0)
    q0_scalar = float(q0.mean()) if q0.mean() > 0 else 0.0
    msk_states = []
    for idx, c0, c1, c2, n_sub in msk_layers_params:
        max_n = int(n_sub.max()) + 1
        msk_states.append(np.full((len(idx), max_n), q0_scalar, np.float32))

    # Output arrays
    q_grid = np.zeros((T, Ng), np.float32)
    q_outlet = np.zeros(T, np.float32)
    n_layer0 = len(msk_layers_params[0][0]) if msk_layers_params else Ns
    layer_outputs = [np.zeros((T, len(L[0])), np.float32) for L in msk_layers_params]

    for t in range(T):
        # 1. PDD step: total precip (mm) -> runoff (m)
        total_prec = rain[t] + snow[t]
        pdd_state, pdd_runoff_m = simulate_pdd_step_parallel(
            pdd_state, temp[t].astype(np.float64),
            total_prec.astype(np.float64), pdd_params,
        )
        rain_to_prod = np.maximum(pdd_runoff_m * 1000.0, 0.0)  # m -> mm

        # 2. Production model step
        prod_state = prod_step_fn(
            prod_state, rain_to_prod, pet[t].astype(np.float64), prod_params,
        )

        # 3. Grid discharge
        q_dis = prod_state[:, -3:].sum(axis=1).astype(np.float32)
        q_grid[t] = q_dis

        # 4. Aggregate to subbasins
        q_layer_in = grid2sub.astype(np.float32).T @ q_dis

        # 5. Muskingum routing (reuse existing implementation)
        msk_states, outs_t, _, _ = _route_msk_layers_step(
            q_layer_in, msk_states, msk_layers_params, C_mats,
        )
        for L_idx, q_out in enumerate(outs_t):
            layer_outputs[L_idx][t] = q_out

        q_outlet[t] = layer_outputs[-1][t].sum()

    q_subs = layer_outputs[0]
    return q_grid, q_subs, q_outlet
