# ==================================================================
#   simulation_utils.py
#   ———— 模型参数处理相关的工具函数
# ==================================================================
from __future__ import annotations
from copy import deepcopy
from typing import Dict, Any, Optional, Tuple
import numpy as np

def update_model_params(
    model_params_template: Dict[str, Any],
    param_dict: Dict[str, Any],
    calibration_config: Dict[str, Any]
) -> Dict[str, Any]:
    """
    根据校准配置和给定的参数字典，更新模型参数模板。
    """
    params = deepcopy(model_params_template)
    calib_map = {p["name"]: p for p in calibration_config["calibrate_params"]}

    for key, value in param_dict.items():
        if key not in calib_map:
            continue

        param_info = calib_map[key]
        param_type = param_info["type"]

        if param_type in params:
            if isinstance(params[param_type], dict):
                params[param_type][key] = value
            elif isinstance(params[param_type], list):
                # 假设列���中的字典需要更新
                for item in params[param_type]:
                    if key in item:
                        item[key] = value
                        break
    return params

def broadcast_model_params(
    model_params: Dict[str, Any],
    param_mode: Dict[str, Dict[str, str]],
    grid2sub: np.ndarray,
    sub_area: np.ndarray
) -> Tuple[Dict[str, np.ndarray], Dict[str, np.ndarray], Dict[str, np.ndarray]]:
    """
    将集总或分区的参数广播到网格或子流域尺度。

    新增: 若某 XAJ / PDD 参数长度 == Ns (子流域数) 而需要广播到 Ng(网格数)，
          使用 grid2sub (Ng,Ns) 行向量进行线性组合 (通常为 one-hot 或权重)。
          解决 uf 等参数给成子流域尺度时出现 shape (Ns,) 无法与 (Ng,) 对齐的问题。
    """
    Ng, Ns = grid2sub.shape

    xaj_params = model_params["xaj_params"]
    pdd_params = model_params["pdd_params"]
    msk_params = model_params["msk_params"]

    def _broadcast(value, target_size, *, allow_sub=False, name=""):
        arr = np.asarray(value, dtype=np.float32).ravel()
        sz = arr.size
        if sz == 1:               # 标量
            return np.full(target_size, float(arr[0]), dtype=np.float32)
        if sz == target_size:     # 已是目标尺度
            return arr.astype(np.float32, copy=False)
        if allow_sub and sz == Ns and target_size == Ng:  # 子流域 → 网格
            # grid2sub: (Ng,Ns) @ (Ns,) -> (Ng,)
            mapped = grid2sub @ arr.astype(np.float32, copy=False)
            return mapped.astype(np.float32, copy=False)
        # 不满足广播要求
        raise ValueError(f"参数 '{name}' 尺寸 {sz} 既不是 1 也不是 {target_size} (也非可从 Ns={Ns} 广播到 Ng={Ng})")

    # 对 XAJ / PDD 允许 Ns→Ng 广播
    xaj_g = {k: _broadcast(v, Ng, allow_sub=True, name=k) for k, v in xaj_params.items()}
    pdd_g = {k: _broadcast(v, Ng, allow_sub=True, name=k) for k, v in pdd_params.items()}
    # Muskingum 仍保持子流域尺度，不做 Ns→Ng
    def _broadcast_msk(v, name):
        arr = np.asarray(v, dtype=np.float32).ravel()
        if arr.size == 1:
            return np.full(Ns, float(arr[0]), dtype=np.float32)
        if arr.size == Ns:
            return arr.astype(np.float32, copy=False)
        raise ValueError(f"msk 参数 '{name}' 尺寸 {arr.size} 既不是 1 也不是 Ns={Ns}")
    msk_s = {k: _broadcast_msk(v, k) for k, v in msk_params.items()}

    # --- 确保 uf 参数存在 ---
    # 注意：不能因为 Ng==1 && Ns==1 就强制 uf=1.0
    # uf 应从 sub_area / (3.6 * dt_hours) 正确计算，即使是单栅格也需要正确的单位换算
    if "uf" not in xaj_g:
        xaj_g["uf"] = np.ones(Ng, dtype=np.float32)
        print(f"[WARN] uf 参数缺失，使用默认值 1.0 (可能导致流量单位错误)")

    return xaj_g, pdd_g, msk_s

