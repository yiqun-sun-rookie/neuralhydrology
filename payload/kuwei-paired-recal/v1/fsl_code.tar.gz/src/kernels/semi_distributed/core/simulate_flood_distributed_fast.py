# ---------------------------------------------------------------------------
# simulate_flood_distributed_fast.py  ——  *替换整个文件体*
# ---------------------------------------------------------------------------
from __future__ import annotations
from typing import Dict, Any, Optional, Tuple
import numpy as np
import pandas as pd
import os
from src.kernels.semi_distributed.core.hydromod_numba import (
    coupled_pdd_xaj_step_vec_numba,
    coupled_pdd_xaj_step_vec_hbv_numba,
    coupled_pdd_xaj_step_vec_v3_numba,
    _route_msk_layers_step,  # 低层函数，不修改其签名
)
from src.kernels.core.hydro_model.process_model.muskingum.msk_fcns import (
    muskingum_subreach_step_vec as _msk_subreach_step_vec,
)
def muskingum_subreach_step_vec(
    q_msk_last_sub: np.ndarray,
    q_in_current: np.ndarray,
    c0: np.ndarray,
    c1: np.ndarray,
    c2: np.ndarray,
) -> np.ndarray:
    """暴露 Muskingum 子河段演算函数（兼容旧接口）。

    直接委托给 `src.kernels.core.hydro_model.process_model.muskingum.msk_fcns`
    中的实现，供历史脚本（旧路径现已移除）继续通过该模块导入。
    """

    return _msk_subreach_step_vec(q_msk_last_sub, q_in_current, c0, c1, c2)
from src.runtime.semi_distributed.params import prepare_initial_state as _prepare_initial_state

# Step0 调试输出控制: 环境变量 STEP0_DEBUG_MODE = off | once | each (默认 once)
_STEP0_PRINTED = False
_STEP0_MODE = os.environ.get("STEP0_DEBUG_MODE", "off").lower()
if _STEP0_MODE not in {"off", "once", "each"}:
    _STEP0_MODE = "off"
# 主进程限制: 若 STEP0_MASTER_ONLY=1 且设定 MAIN_PID, 仅主进程打印
_STEP0_MASTER_ONLY = os.environ.get("STEP0_MASTER_ONLY", "0") == "1"
_MAIN_PID = os.environ.get("MAIN_PID")


def prepare_initial_conditions(
    initial_conditions: Dict[str, Any],
    Ng: int,
    enable_snowmelt: bool = False
) -> np.ndarray:
    """向后兼容的封装：委托给 optimization.params.prepare_initial_state。"""
    return _prepare_initial_state(initial_conditions, Ng, enable_snowmelt)


# ---------------------------------------------------------------------------
# 2. 核心时间循环 (Numba)  ——  带“外接实测流量”覆写版本
# ---------------------------------------------------------------------------
# @njit(cache=True, fastmath=True) # C_mats is a list of arrays, not supported by Numba's jit
def _simulate_core(
    rain, temp, snow, pet,                # (T, Ng)
    pdd_pars,                             # tuple 4 × (Ng,)
    xaj_pars,                             # tuple 17 × (Ng,)
    grid2sub,                             # (Ng, Ns)
    init_state,                           # (Ng, 11)
    # --- Muskingum 参数 (分层) ---
    msk_layers_params: list,              # [(idx, c0, c1, c2, n_sub), ...]
    C_mats: list,                         # List[np.ndarray]
    *,
    pdd_version: str = "auto",            # "auto" | "v1" | "v2" | "v3"
    obs_station=None,                     # (T, N_sta) or None
    sta_reach_idx=None,                   # (N_sta,)    or None
    return_state_grid: bool = False,
    return_last_layer: bool = False,
    return_station_outputs: bool = False,
):
    """
    Parameters
    ----------
    msk_layers_params : list
        每层一个 5-tuple： (idx, c0, c1, c2, n_sub)
        • idx  : np.ndarray[int]，本层包含的 reach 索引
        • c0,c1,c2,n_sub 与 idx 等长
    C_mats : list
        C_mats[L] 形状 = (N_{L+1}, N_L)，把第 L 层输出聚合到第 L+1 层入口
    """
    # ---------- 基本维度 & 输入广播 ----------
    # 允许旧调用传入 (T,1) 单列强制对所有格点广播；与早期实现保持兼容。
    def _maybe_broadcast(arr, name):
        if arr.ndim != 2:
            raise ValueError(f"{name} 期望二维 (T,Ng) 或 (T,1), got shape={arr.shape}")
        Tn, Cn = arr.shape
        if Cn == 1:
            return np.repeat(arr, init_state.shape[0], axis=1)
        return arr

    rain = _maybe_broadcast(rain, 'rain')
    temp = _maybe_broadcast(temp, 'temp')
    snow = _maybe_broadcast(snow, 'snow')
    pet  = _maybe_broadcast(pet,  'pet')

    # ---------- NaN / Inf input guard ----------
    # fastmath=True in downstream Numba kernels silently propagates NaN.
    # Catch non-finite inputs here, before any computation.
    for _arr, _name in [(rain, 'rain'), (temp, 'temp'), (snow, 'snow'), (pet, 'pet')]:
        if not np.all(np.isfinite(_arr)):
            raise ValueError(f"Non-finite values in {_name} at _simulate_core entry")

    T, Ng = rain.shape

    # ---------- 0) 结果数组 ----------
    q_grid      = np.zeros((T, Ng), np.float32)
    q_basin_out = np.zeros((T,),    np.float32)

    # layer_outputs[L] : shape (T, len(idx_L))
    layer_outputs = [np.zeros((T, len(L[0])), np.float32)
                     for L in msk_layers_params]

    # ---------- 1) 初始状态 ----------
    state_grid  = init_state.copy()
    if return_state_grid:
        states_grid = np.zeros((T, Ng, init_state.shape[1]), np.float32)
        states_grid[0] = state_grid

    # 初始流量
    q0         = init_state[:, -3:].sum(axis=1)
    q0_scalar  = float(q0[0])
    q_grid[0]  = q0

    # ---------- 2) Muskingum 状态初始化 ----------
    msk_states = []
    for idx, c0, _, _, n_sub in msk_layers_params:
        max_n = int(n_sub.max()) + 1
        msk_states.append(np.full((len(idx), max_n), q0_scalar, np.float32))

    # ---------- 3) 观测流量覆写准备 ----------
    use_obs = (obs_station is not None) and (sta_reach_idx is not None)
    if use_obs:
        sta_reach_idx = sta_reach_idx.astype(np.int32)

    # ---------- 3.1 测站映射（可选） ----------
    station_map = None
    station_outputs = None
    if return_station_outputs and sta_reach_idx is not None:
        # 为每个测站 reach 找到其所在层及该层内的位置
        station_map = []  # 列表[(layer_idx, pos_in_layer)]
        # 预构建层内索引的查找字典以加速
        layer_idx_maps = []
        for L in msk_layers_params:
            idx = L[0]
            d = {int(val): i for i, val in enumerate(idx)}
            layer_idx_maps.append(d)
        for r in sta_reach_idx:
            found = False
            for Lid, d in enumerate(layer_idx_maps):
                if int(r) in d:
                    station_map.append((Lid, d[int(r)]))
                    found = True
                    break
            if not found:
                station_map.append((-1, -1))  # 未找到则占位

    # ---------- 工具函数：路由与结果写入 ----------
    def _route_and_collect(q_layer_in, msk_states, obs_row):
        """封装 _route_msk_layers_step，忽略未使用的 q_in / last_layer_out 返回。

        与旧实现相比：
        1) 原返回 (msk_states, outs_t, q_in_next, last_layer_out)
        2) 这里仅使用前两项，减少上层函数不必要的变量名噪声。
        3) 若后续需要 last_layer_out，可在此处恢复，但默认由 layer_outputs[-1] 派生即可。

        Parameters
        ----------
        q_layer_in : np.ndarray
            本层入口流量 (Ns,)
        msk_states : list[np.ndarray]
            Muskingum 各层状态
        obs_row : np.ndarray | None
            当前时刻观测（可选）
        """
        msk_states, outs_t, _, _ = _route_msk_layers_step(
            q_layer_in, msk_states, msk_layers_params, C_mats,
            obs_row=obs_row, sta_reach_idx=sta_reach_idx,
        )
        return msk_states, outs_t

    def _update_layer_outputs(layer_outputs, outs_t, t):
        """把当前时间步各层输出写入结果数组。

        layer_outputs: List[np.ndarray[T, n_layer_nodes]]
        outs_t:       List[np.ndarray[n_layer_nodes]]
        t:            当前时间索引
        """
        for L_idx, q_out in enumerate(outs_t):
            layer_outputs[L_idx][t] = q_out

    def _update_station_outputs(station_outputs, station_map, outs_t, t):
        """根据 station_map 提取当前时间步测站所在节点输出。

        station_map: List[(layer_id, pos_in_layer)] 预先构造；值为 (-1,-1) 表示该测站不在路由集合中。
        若首次调用且 station_outputs 为 None，将初始化 (T, N_sta) 数组。
        """
        if station_map is None:
            return station_outputs
        if station_outputs is None:
            N_sta = len(station_map)
            station_outputs = np.zeros((T, N_sta), np.float32)
        for j, (Lid, pos) in enumerate(station_map):
            if Lid >= 0 and pos >= 0:
                station_outputs[t, j] = outs_t[Lid][pos]
        return station_outputs

    # ---------- 4) 时间循环 ----------
    for t in range(T):

        # 4-1 产流（PDD-XAJ）
        Ng_local = state_grid.shape[0]
        def _vec(v):
            vt = v[t]
            shp = getattr(vt, 'shape', ())
            # 认为标量或长度为1的一维数组都需要广播
            if isinstance(vt, (float, int)) or shp == () or shp == (1,):
                return np.full(Ng_local, float(np.asarray(vt).ravel()[0]), np.float32)
            # 若长度不等于 Ng，尝试广播或报错
            arr = np.asarray(vt, np.float32).ravel()
            if arr.size == Ng_local:
                return arr
            if arr.size == 1:
                return np.full(Ng_local, float(arr[0]), np.float32)
            raise ValueError(f"气象强制量长度不匹配: got {arr.size}, expected {Ng_local}")
        temp_t = _vec(temp)
        rain_t = _vec(rain)
        snow_t = _vec(snow)
        pet_t  = _vec(pet)
        if t == 0 and _STEP0_MODE != 'off':  # 受控一次/每次
            global _STEP0_PRINTED
            if _STEP0_MODE == 'each' or (_STEP0_MODE == 'once' and not _STEP0_PRINTED):
                # 主进程限制判断
                if _STEP0_MASTER_ONLY and _MAIN_PID and str(os.getpid()) != _MAIN_PID:
                    _STEP0_PRINTED = True  # 标记以避免后续判定耗时
                else:
                    print(f"[DEBUG] step0 shapes: state_grid={state_grid.shape} temp={getattr(temp_t,'shape',None)} rain={getattr(rain_t,'shape',None)} snow={getattr(snow_t,'shape',None)} pet={getattr(pet_t,'shape',None)}")
                    print(f"[DEBUG] step0 samples: temp[:3]={temp_t[:3]} rain[:3]={rain_t[:3]} pet[:3]={pet_t[:3]}")
                    # 形状一致性检查
                    try:
                        for i, arr in enumerate(pdd_pars):
                            if getattr(arr, 'shape', None) is None:
                                continue
                            if arr.shape[0] != Ng_local:
                                print(f"[WARN] pdd_pars[{i}] shape={arr.shape} != ({Ng_local},) 可能导致广播错误")
                        for i, arr in enumerate(xaj_pars):
                            if getattr(arr, 'shape', None) is None:
                                continue
                            if arr.shape[0] != Ng_local:
                                print(f"[WARN] xaj_pars[{i}] shape={arr.shape} != ({Ng_local},) 可能导致广播错误")
                    except Exception as _e:  # noqa: BLE001
                        print(f"[WARN] 形状检查失败: {_e}")
                    _STEP0_PRINTED = True
        # PDD 版本分派: 显式 pdd_version 优先；auto 按 tuple 长度推断（向后兼容）
        if pdd_version == "v3":
            _coupled_step_fn = coupled_pdd_xaj_step_vec_v3_numba
        elif pdd_version == "v2":
            _coupled_step_fn = coupled_pdd_xaj_step_vec_hbv_numba
        elif pdd_version == "v1":
            _coupled_step_fn = coupled_pdd_xaj_step_vec_numba
        else:  # auto
            if len(pdd_pars) == 6:
                _coupled_step_fn = coupled_pdd_xaj_step_vec_hbv_numba
                _pdd_label = "v2(HBV)"
            else:
                _coupled_step_fn = coupled_pdd_xaj_step_vec_numba
                _pdd_label = "v1"
            if t == 0:
                print(f"[PDD] auto-selected {_pdd_label} based on pdd_pars length={len(pdd_pars)}")
        try:
            state_grid, _ = _coupled_step_fn(
                state_grid,
                temp_t, rain_t, snow_t, pet_t,
                pdd_pars, xaj_pars
            )
        except ValueError as e:
            # 捕获 numba 广播错误，补充上下文后再抛出
            if 'broadcast' in str(e).lower():
                shapes_pdd = [getattr(a, 'shape', None) for a in pdd_pars]
                shapes_xaj = [getattr(a, 'shape', None) for a in xaj_pars]
                raise ValueError(
                    f"[ShapeDebug] Numba广播错误 t={t} Ng={Ng_local} "
                    f"state_grid={state_grid.shape} temp={temp_t.shape} rain={rain_t.shape} snow={snow_t.shape} pet={pet_t.shape} "
                    f"pdd_pars_shapes={shapes_pdd} xaj_pars_shapes={shapes_xaj} 原始错误: {e}"
                ) from e
            raise

        q_dis       = state_grid[:, -3:].sum(axis=1)   # (Ng,)
        q_grid[t]   = q_dis
        q_layer_in  = grid2sub.T @ q_dis               # (Ns,)

        # 4-2 分层 Muskingum（封装）
        msk_states, outs_t = _route_and_collect(
            q_layer_in, msk_states, (obs_station[t] if use_obs else None)
        )
        _update_layer_outputs(layer_outputs, outs_t, t)
        if return_station_outputs:
            station_outputs = _update_station_outputs(station_outputs, station_map, outs_t, t)

        # 4-3 汇总出口
        q_basin_out[t] = layer_outputs[-1][t].sum()

        # 4-4 可选：存回 states
        if return_state_grid:
            states_grid[t] = state_grid

    # ---------- 5) Output clipping ----------
    # Numerical errors or extreme parameters can produce negative discharge.
    # Clip all output discharge arrays to non-negative values.
    q_basin_out = np.maximum(q_basin_out, 0.0)
    q_grid      = np.maximum(q_grid, 0.0)

    # ---------- 6) 返回 ----------
    q_subbasin_out = np.maximum(layer_outputs[0], 0.0)   # 第 0 层各子流域出流
    q_last_layer = layer_outputs[-1]       # 最后一层（出口级）逐节点出流，形状 (T, N_last)

    # 组合返回：保持兼容，同时在需要时返回最后一层逐出口序列
    if return_state_grid and return_last_layer and return_station_outputs:
        return q_grid, q_subbasin_out, q_basin_out, q_last_layer, states_grid, station_outputs
    if return_state_grid and return_last_layer and not return_station_outputs:
        return q_grid, q_subbasin_out, q_basin_out, q_last_layer, states_grid
    if return_state_grid and (not return_last_layer) and return_station_outputs:
        return q_grid, q_subbasin_out, q_basin_out, states_grid, station_outputs
    if return_state_grid and (not return_last_layer) and (not return_station_outputs):
        return q_grid, q_subbasin_out, q_basin_out, states_grid
    if (not return_state_grid) and return_last_layer and return_station_outputs:
        return q_grid, q_subbasin_out, q_basin_out, q_last_layer, station_outputs
    if (not return_state_grid) and return_last_layer and (not return_station_outputs):
        return q_grid, q_subbasin_out, q_basin_out, q_last_layer
    if (not return_state_grid) and (not return_last_layer) and return_station_outputs:
        return q_grid, q_subbasin_out, q_basin_out, station_outputs
    return q_grid, q_subbasin_out, q_basin_out



def simulate_flood_distributed_fast(
    # a. Meteo (pre-processed)
    rain: np.ndarray,
    temp: np.ndarray,
    snow: np.ndarray,
    pet: np.ndarray,
    time_index: pd.DatetimeIndex,
    # b. External flow (pre-processed)
    obs_station_arr: Optional[np.ndarray],
    sta_reach_idx: Optional[np.ndarray],
    # c. Initial conditions
    initial_state: np.ndarray,
    # d. Processed params
    model_params: Dict[str, Any],
    pdd_tuple: tuple,
    xaj_tuple: tuple,
    msk_s: Dict[str, Any],
    core_args: Dict[str, Any],
    # e. Geo info
    grid2sub: np.ndarray,
    # connection_matrices is now inside core_args
    # Other options
    *,
    enable_snowmelt: bool = False,
    return_state_grid: bool = False,
    return_last_layer: bool = False,
):
    """
    使用预处理好的参数和输入，运行分布式洪水模拟。

    Parameters
    ----------
    rain : np.ndarray
        处理后的降雨数据。
    temp : np.ndarray
        处理后的温度数���。
    snow : np.ndarray
        处理后的雪深数据。
    pet : np.ndarray
        处理后的蒸发蒸散数据。
    time_index : pd.DatetimeIndex
        时间索引。
    obs_station_arr : np.ndarray, optional
        外接观测站流量（已处理），必须是时间索引的。
    sta_reach_idx : np.ndarray, optional
        观测站到河段索引的映射（已处理）。
    initial_state : np.ndarray
        模型初始状态数组 (Ng, 11)。
    model_params : dict
        完整的、已处理的模型参数字典，包含 `msk_layers`。
    pdd_tuple : tuple
        广播到格网的PDD参数元组。
    xaj_tuple : tuple
        广播到格网的XAJ参数元组。
    msk_s : dict
        广播到子流域的Muskingum参数。
    core_args : dict
        包含 Muskingum 参数元组和连接矩阵的核心参数字典。
    grid2sub : np.ndarray
        格网到子流域的映射矩阵。
    enable_snowmelt : bool, optional
        是否启用融雪模块。
    return_state_grid : bool, optional
        是否返回格网状态变量。
    """
    Ng, Ns = grid2sub.shape

    # ---------- 2) initial state -----------------------------------
    # (已在外部通过 prepare_initial_conditions 预处理)
    state0 = initial_state

    # ---------- 3) meteorological array ----------------------------
    # (已在外部预处理)


    if return_state_grid and return_last_layer:
        q_grid, q_subbasin_out, q_basin_out, q_last_layer, states_grid = _simulate_core(
            rain, temp, snow, pet, pdd_tuple, xaj_tuple, grid2sub.astype(np.float32),
            state0,
            obs_station=obs_station_arr,
            sta_reach_idx=sta_reach_idx,
            return_state_grid=return_state_grid,
            return_last_layer=return_last_layer,
            **core_args
        )
        return q_grid, q_subbasin_out, q_basin_out, q_last_layer, states_grid

    if return_state_grid and not return_last_layer:
        q_grid, q_subbasin_out, q_basin_out, states_grid = _simulate_core(
            rain, temp, snow, pet, pdd_tuple, xaj_tuple, grid2sub.astype(np.float32),
            state0,
            obs_station=obs_station_arr,
            sta_reach_idx=sta_reach_idx,
            return_state_grid=return_state_grid,
            return_last_layer=return_last_layer,
            **core_args
        )
        return q_grid, q_subbasin_out, q_basin_out, states_grid

    if (not return_state_grid) and return_last_layer:
        q_grid, q_subbasin_out, q_basin_out, q_last_layer = _simulate_core(
            rain, temp, snow, pet, pdd_tuple, xaj_tuple, grid2sub.astype(np.float32),
            state0,
            obs_station=obs_station_arr,
            sta_reach_idx=sta_reach_idx,
            return_last_layer=return_last_layer,
            **core_args
        )
        return q_grid, q_subbasin_out, q_basin_out, q_last_layer

    # 默认：两者都不需要
    q_grid, q_subbasin_out, q_basin_out = _simulate_core(
        rain, temp, snow, pet, pdd_tuple, xaj_tuple, grid2sub.astype(np.float32),
        state0,
        obs_station=obs_station_arr,
        sta_reach_idx=sta_reach_idx,
        return_last_layer=return_last_layer,
        **core_args
    )
    return q_grid, q_subbasin_out, q_basin_out

