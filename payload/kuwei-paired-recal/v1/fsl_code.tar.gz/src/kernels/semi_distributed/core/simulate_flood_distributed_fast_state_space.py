# DEV_NOTE: 修改本文件(状态空间核心)后必须运行下列两个 smoke 测试以验证数值一致性:
#   1) tests_smoke/test_state_space_step_and_drift.py
#   2) tests_smoke/test_optimize_state_space_monkeypatch.py
# 策略说明: 见 tests_smoke/README_SELECTED_TESTS.md 与 config/policies/assistant_test_policy.yml
# 若仅改注释/打印，可酌情跳过，但涉及状态转移/路由/参数形状务必执行。
# 2025-10: 已移除 enable_snowmelt 参数（签名清理，无行为变化）。
# ---------------------------------------------------------------------------
# simulate_flood_distributed_fast_state_space.py  ——  状态空间版本
# ---------------------------------------------------------------------------
from __future__ import annotations
from typing import Dict, Any, Optional, Tuple, List
import warnings
import numpy as np
import pandas as pd
import os
from .hydromod_numba import (
    _route_msk_layers_step,  # 保留低层函数
    coupled_pdd_xaj_step_vec_numba,
    xaj_step_with_liquid_numba,
)
from src.runtime.semi_distributed.core.params import prepare_initial_state as _prepare_initial_state

# Step0 调试输出控制: 环境变量 STEP0_DEBUG_MODE = off | once | each (默认 once)
_STEP0_PRINTED = False
_STEP0_MODE = os.environ.get("STEP0_DEBUG_MODE", "off").lower()
if _STEP0_MODE not in {"off", "once", "each"}:
    _STEP0_MODE = "off"
# 主进程限制: 若 STEP0_MASTER_ONLY=1 且设定 MAIN_PID, 仅主进程打印
_STEP0_MASTER_ONLY = os.environ.get("STEP0_MASTER_ONLY", "0") == "1"
_MAIN_PID = os.environ.get("MAIN_PID")


def prepare_initial_conditions(
    initial_conditions: Dict[str, Any],
    Ng: int,
) -> np.ndarray:
    """封装 initial state 生成（已移除 enable_snowmelt 参数）。

    说明:
        2025-10: enable_snowmelt 逻辑在 state-space 版本中不再通过显式 flag 控制，
        若需要融雪，直接在 initial_conditions 中提供相应初始雪/冰字段，否则置 0。
    """
    return _prepare_initial_state(initial_conditions, Ng, enable_snowmelt=False)

def _ensure_unit_vector(v, n_units: int, name: str = "var") -> np.ndarray:
    """将标量/长度1数组/长度n_units数组规范化为长度 n_units 的一维 float32 向量。

    允许输入:
      - 标量 (int/float)
      - 0/1 维数组 (shape == (), (1,))
      - 一维数组 (size == n_units)
      - 若 size == 1 同样广播
    其它尺寸报错，避免静默广播错误。
    """
    if isinstance(v, (int, float)):
        return np.full(n_units, float(v), np.float32)
    arr = np.asarray(v, np.float32).ravel()
    if arr.size == n_units:
        return arr
    if arr.size == 1:
        return np.full(n_units, float(arr[0]), np.float32)
    raise ValueError(f"{name} 长度不匹配: got {arr.size}, expected {n_units}")


def _prepare_liquid_controls(control_dict, n_units: int):
    """解析液态降水控制字典，返回广播后的 5 元组."""

    def _get(key: str, *aliases: str) -> np.ndarray:
        keys = (key,) + aliases
        for k in keys:
            if k in control_dict:
                return _ensure_unit_vector(control_dict[k], n_units, name=key)
        raise KeyError(f"液态控制缺少字段: {key} (可选别名: {aliases})")

    liquid = _get("liquid", "liquid_precip", "precip")
    pet = _get("pet")
    snow_depth = _get("snow_depth")
    ice_depth = _get("ice_depth")
    last_temp = _get("last_temp")
    return liquid, pet, snow_depth, ice_depth, last_temp


# ---------------------------------------------------------------------------
# 状态转移函数 - 单步状态更新
# ---------------------------------------------------------------------------
def state_transition_step(
    state_units: np.ndarray,                # (n_units, 11) - 当前状态 (原 state_grid)
    msk_states: List[np.ndarray],           # Muskingum状态列表
    controls: np.ndarray,                   # (4,) - 控制输入 [rain, temp, snow, pet]
    pdd_pars: Tuple[np.ndarray, ...],       # tuple 4 × (n_units,)
    xaj_pars: Tuple[np.ndarray, ...],       # tuple 17 × (n_units,)
    grid2sub: np.ndarray,                   # (n_units, Ns)
    msk_layers_params: List[Tuple],         # [(idx, c0, c1, c2, n_sub), ...]
    layer_connect_mats: List[np.ndarray],   # 层间连接矩阵列表 (原 C_mats)
    obs_station: Optional[np.ndarray] = None,     # (1, N_sta) or None
    sta_reach_idx: Optional[np.ndarray] = None,   # (N_sta,) or None
) -> Tuple[np.ndarray, List[np.ndarray], np.ndarray, List[np.ndarray]]:
    """
    状态转移函数 - 单步状态更新
    
    Parameters
    ----------
    state_units : np.ndarray
        当前状态，形状为 (n_units, 11)
    msk_states : List[np.ndarray]
        Muskingum状态列表
    controls : np.ndarray
        控制输入，形状为 (4,)，包含 [rain, temp, snow, pet]
    其他参数与原始_simulate_core相同
    
    Returns
    -------
    next_state_grid : np.ndarray
        下一状态，形状为 (n_units, 11)
    next_msk_states : List[np.ndarray]
        下一Muskingum状态列表
    q_dis : np.ndarray
        网格流量，形状为 (n_units,)
    outs_t : List[np.ndarray]
        各层输出流量
    """
    
    # 单元数量 (原 Ng)
    n_units_local = state_units.shape[0]
    
    use_liquid_controls = isinstance(controls, dict)
    if use_liquid_controls:
        mode = str(controls.get("mode", "liquid_pet")).lower()
        if mode not in {"liquid_pet", "liquid"}:
            raise ValueError(f"未知控制模式: {mode}")
        liquid_t, pet_t, snow_depth_t, ice_depth_t, last_temp_t = _prepare_liquid_controls(controls, n_units_local)
        next_state_units, _ = xaj_step_with_liquid_numba(
            state_units,
            liquid_t,
            pet_t,
            xaj_pars,
            snow_depth_t,
            ice_depth_t,
            last_temp_t,
        )
    else:
        rain, temp, snow, pet = controls[0], controls[1], controls[2], controls[3]

        temp_t = _ensure_unit_vector(temp, n_units_local, name="temp")
        rain_t = _ensure_unit_vector(rain, n_units_local, name="rain")
        snow_t = _ensure_unit_vector(snow, n_units_local, name="snow")
        pet_t = _ensure_unit_vector(pet, n_units_local, name="pet")

        if _STEP0_MODE != 'off':
            global _STEP0_PRINTED
            if _STEP0_MODE == 'each' or (_STEP0_MODE == 'once' and not _STEP0_PRINTED):
                if _STEP0_MASTER_ONLY and _MAIN_PID and str(os.getpid()) != _MAIN_PID:
                    _STEP0_PRINTED = True
                else:
                    print(f"[DEBUG] state_transition_step shapes: state_units={state_units.shape} temp={getattr(temp_t,'shape',None)} rain={getattr(rain_t,'shape',None)}")
                    _STEP0_PRINTED = True

        try:
            next_state_units, _ = coupled_pdd_xaj_step_vec_numba(
                state_units,
                temp_t, rain_t, snow_t, pet_t,
                pdd_pars, xaj_pars
            )
        except ValueError as e:
            if 'broadcast' in str(e).lower():
                shapes_pdd = [getattr(a, 'shape', None) for a in pdd_pars]
                shapes_xaj = [getattr(a, 'shape', None) for a in xaj_pars]
                raise ValueError(
                    f"[ShapeDebug] Numba广播错误 n_units={n_units_local} "
                    f"state_units={state_units.shape} temp={temp_t.shape} rain={rain_t.shape} snow={snow_t.shape} pet={pet_t.shape} "
                    f"pdd_pars_shapes={shapes_pdd} xaj_pars_shapes={shapes_xaj} 原始错误: {e}"
                ) from e
            raise
    
    # 2. 计算网格流量
    q_dis = next_state_units[:, -3:].sum(axis=1)   # (n_units,)
    q_layer_in = grid2sub.T @ q_dis               # (Ns,)
    
    # 3. 分层 Muskingum（封装）
    next_msk_states, outs_t, _, _ = _route_msk_layers_step(
        q_layer_in, msk_states, msk_layers_params, layer_connect_mats,
        obs_row=(obs_station[0] if obs_station is not None else None),
        sta_reach_idx=sta_reach_idx,
    )
    
    return next_state_units, next_msk_states, q_dis, outs_t


# ---------------------------------------------------------------------------
# 提取工具函数：从 Muskingum 状态获取出口流量
# ---------------------------------------------------------------------------
def extract_layer_out(msk_state_layer: np.ndarray, n_sub: np.ndarray) -> np.ndarray:
    """提取某一层每条河段出口流量。

    注意：不能直接用 msk_state_layer[:, -1]，因为使用了统一的 max_n 填充，真实出口列为 n_sub[i]-1。
    """
    out = np.empty(n_sub.size, dtype=msk_state_layer.dtype)
    for i in range(n_sub.size):
        out[i] = msk_state_layer[i, n_sub[i] - 1]
    return out


def extract_all_layers(msk_states: List[np.ndarray], msk_layers_params: List[Tuple]) -> List[np.ndarray]:
    """提取所有层的出口流量列表，等价原 outs_t。"""
    outs = []
    for (idx, c0, c1, c2, n_sub), layer_state in zip(msk_layers_params, msk_states):  # noqa: E501
        outs.append(extract_layer_out(layer_state, n_sub))
    return outs


def extract_basin_out(msk_states: List[np.ndarray], msk_layers_params: List[Tuple]) -> np.ndarray:
    """提取最后一层各出口节点流量向量。"""
    last_params = msk_layers_params[-1]
    n_sub_last = last_params[-1]
    return extract_layer_out(msk_states[-1], n_sub_last)


# ---------------------------------------------------------------------------
# 测站映射 & 写入辅助函数（模块级，避免在核心循环或函数内重复定义）
# ---------------------------------------------------------------------------
def build_station_map(msk_layers_params: List[Tuple], sta_reach_idx: Optional[np.ndarray]):
    """根据层次参数与测站对应的 reach ID 构建 (layer_id, local_index) 列表。

    未找到的站点标记为 (-1, -1)。
    """
    if sta_reach_idx is None:
        return None
    layer_idx_maps = []
    for L in msk_layers_params:
        idx = L[0]
        d = {int(val): i for i, val in enumerate(idx)}
        layer_idx_maps.append(d)
    station_map = []
    for r in sta_reach_idx:
        found = False
        r_int = int(r)
        for Lid, d in enumerate(layer_idx_maps):
            if r_int in d:
                station_map.append((Lid, d[r_int]))
                found = True
                break
        if not found:
            station_map.append((-1, -1))
    return station_map


def update_layer_outputs(layer_outputs: List[np.ndarray], outs_t: List[np.ndarray], t: int):
    """写入各层输出。"""
    for L_idx, q_out in enumerate(outs_t):
        layer_outputs[L_idx][t] = q_out


def update_station_outputs(station_outputs: Optional[np.ndarray], station_map, outs_t, t: int, T: int):
    """写入测站输出（必要时初始化）。"""
    if station_map is None:
        return station_outputs
    if station_outputs is None:
        N_sta = len(station_map)
        station_outputs = np.zeros((T, N_sta), np.float32)
    for j, (Lid, pos) in enumerate(station_map):
        if Lid >= 0 and pos >= 0:
            station_outputs[t, j] = outs_t[Lid][pos]
    return station_outputs


# ---------------------------------------------------------------------------
# 统一状态：组合 XAJ + Muskingum 状态
# ---------------------------------------------------------------------------
"""组合状态转移曾作为 state_transition_step 的薄封装，现已内联至主循环以减少函数层次。"""


# ---------------------------------------------------------------------------
# 量测方程 - 从状态中提取观测值
# ---------------------------------------------------------------------------
# NOTE: 2025-10 统一量测接口命名: 使用 observation_function (原 observation_function_pure)。
# 为向后兼容，底部保留别名 observation_function_pure = observation_function。
def observation_function(
    msk_states: List[np.ndarray],
    msk_layers_params: List[Tuple],
) -> Tuple[float, List[np.ndarray]]:
    """纯量测函数：从已经更新后的 Muskingum 状态直接提取观测量。

    不再调用 `_route_msk_layers_step`，无副作用；适合作为 DA / 滤波框架的 H(x)。

    返回
    ----
    basin_out : float  流域出口总流量（最后一层所有节点之和）
    outs      : List[np.ndarray] 各层出口节点流量

     术语与实现说明（防遗忘 / 设计动机）
     ------------------------------------------------------------------
     1. 层次路由一次完成：在 `state_transition_step` 中调用 `_route_msk_layers_step` 时，
         按拓扑层 (layer0 -> layer1 -> ... -> last) 顺序逐层推进 Muskingum；每层的
         输入是上一层（或最初的 grid 汇流向量）经拓扑矩阵聚合后的结果。整个网络
         的一次时间步路由只执行这一遍，不会为单个节点重复“自上而下全路径”仿真。

     2. msk_states 结构：`msk_states[L]` 是第 L 层所有河段的二维状态矩阵，形状
         (N_reach_L, max_n_L)。其中真实的下游出口位置为列索引 `n_sub[i]-1`；由于各
         河段离散子段数不同，用最大值补齐。我们在提取出口时不能直接取最后一列，
         必须针对每条河段单独用它的 n_sub[i]-1。

     3. outs 列表：`outs[L]` 是第 L 层“每条河段的出口流量”组成的一维向量；
         仅做提取，不含任何再路由或再计算。它与 `_route_msk_layers_step` 中生成的
         临时 q_out 一一对应。outs[-1] 就是最末层的所有终端（或下游可观测）节点。

     4. basin_out 计算：`basin_out = outs[-1].sum()` 是把最后一层所有节点简单求和。
         如果未来需要单一主出口，可以：
             - 只选择 outs[-1][main_idx]
             - 或引入一个自定义聚合函数 aggregator(outs[-1])。
         当前用求和是为了保持与旧版本“末层所有 reach 汇总 = 流域出口” 的兼容。

     5. 与旧 observation_function 的区别：旧实现里会再次调用路由函数，导致同一
         时间步重复计算（副作用 + 低效）。现在把数值推进和观测分离：
            - 数值推进：state_transition_step / combined_state_transition
            - 观测提取：observation_function_pure (纯函数，无副作用)

     6. 数据同化 / 滤波场景：滤波循环 H(x) 调用只需传入 msk_states & 拓扑参数，
         不需要再提供强制量或参数，也不会改变状态，可安全多次调用。

     7. 常见误解澄清：outs 不是“对每个节点再单独贯穿所有下游层级路由一遍”的结果，
         而是“单次分层路由后，各层出口直接原样收集”的快照。basin_out 只是最后一层
         节点向量求和；没有多余的重复路径演算。

     8. 公式化简：
            q^(0) = grid2sub^T · q_dis
            q^(l) = Muskingum_l( q^(l-1) )
            outs[l] = q^(l)（第 l 层各河段出口）
            basin_out = Σ_i outs[-1][i]

     修改/维护指引：
        - 若要支持多出口分别输出，可把当前返回的 basin_out 改成 outs[-1]，或增加
          参数 `return_last_layer_vector=True`（外部再自行聚合）。
        - 若引入 gauge/station 选择，可在外层直接索引 outs[-1] 对应位置；避免在此
          函数加入站点过滤逻辑保持纯度。
     ------------------------------------------------------------------
    """
    outs = extract_all_layers(msk_states, msk_layers_params)
    basin_out = float(outs[-1].sum()) if outs else 0.0
    return basin_out, outs

# Backward compatibility alias (deprecated). TODO: remove after downstream refactors.
observation_function_pure = observation_function


# ---------------------------------------------------------------------------
# 新的_simulate_core版本 - 使用状态转移和量测方程
# ---------------------------------------------------------------------------
def _maybe_broadcast(arr: np.ndarray, name: str, n_units: int) -> np.ndarray:
    """将形状 (T,1) 的二维数组广播为 (T,n_units)；若已是 (T,n_units) 直接返回。

    约束 / 假设:
    - 输入必须是二维: (T, C)
    - C 只能是 1 或 n_units
    - 不在此处验证时间长度一致性（由上层逻辑保证）
    """
    if arr.ndim != 2:
        raise ValueError(f"{name} 期望二维 (T,n_units) 或 (T,1), got shape={arr.shape}")
    _, Cn = arr.shape
    if Cn == 1:
        return np.repeat(arr, n_units, axis=1)
    if Cn != n_units:
        raise ValueError(f"{name} 第二维需为 1 或 {n_units}, 当前 {Cn}")
    return arr


def _simulate_core_state_space(
    rain, temp, snow, pet,                # (T, n_units)
    pdd_pars,                             # tuple 4 × (n_units,)
    xaj_pars,                             # tuple 17 × (n_units,)
    grid2sub,                             # (n_units, Ns)
    init_state,                           # (n_units, 11)
    # --- Muskingum 参数 (分层) ---
    msk_layers_params: list,              # [(idx, c0, c1, c2, n_sub), ...]
    layer_connect_mats: list | None = None,  # List[np.ndarray] 层间连接矩阵 (原 C_mats)
    *,
    obs_station=None,                     # (T, N_sta) or None
    sta_reach_idx=None,                   # (N_sta,)    or None
    return_state_grid: bool = False,
    return_last_layer: bool = False,
    return_station_outputs: bool = False,
    return_msk_states: bool = False,
    minimal_return: bool = False,          # True: 仅按需返回（基础只给 q_basin_out）
):
    """
    状态空间版本的_simulate_core函数
    
    使用状态转移和量测方程进行时间步内的封装
    
    Parameters
    ----------
    与原始_simulate_core函数相同的参数
    
    命名变更说明
    ------------
    2025-10: 原参数 C_mats 已完成重命名并彻底移除，仅保留 layer_connect_mats。
             若仍有旧调用路径，请在上层适配后再调用本函数；本函数不再接受 C_mats。

    Returns
    -------
    默认（minimal_return=False）返回顺序：
        q_grid, q_subbasin_out, q_basin_out
        可选附加按以下顺序 append：q_last_layer, states_grid, msk_states_traj, station_outputs

    当 minimal_return=True 时：
        基础只返回 [q_basin_out]，再按标志追加 (q_last_layer, states_grid, station_outputs)

    这样可在仅关心汇出口序列的场景（例如优化目标或 DA 观测运算）减少不必要数组构造与传输。
    内部实现已使用统一的 measurement/transition 句柄模式，但不对外暴露（后续若需要可在更高层封装）。
    """
    # ---------- layer_connect_mats 正规化 ----------
    if layer_connect_mats is None:
        layer_connect_mats = []

    # ---------- layer_connect_mats 基本结构与长度校验 ----------
    # 约定：len(layer_connect_mats) 可以是 0（无跨层聚合）或 等于 len(msk_layers_params)-1。
    # 解释：若有 L 层 Muskingum，则存在 L-1 个“上一层 -> 下一层”聚合矩阵；第一层输入来自 grid2sub。
    n_layers = len(msk_layers_params)
    expected_connect_len = max(0, n_layers - 1)
    if len(layer_connect_mats) not in {0, expected_connect_len}:
        raise ValueError(
            f"layer_connect_mats 数量应为 0 或 {expected_connect_len} (对应 {n_layers} 层), 当前为 {len(layer_connect_mats)}"
        )

    # 对每个矩阵做基本形状验证：
    # 假设 msk_layers_params[i][0] = idx_i (可迭代，长度为该层河段数)，矩阵 M_i 的形状应为 (n_reach_{i+1}, n_reach_{i})
    # 即把第 i 层各 reach 的出口聚合为第 i+1 层各 reach 的入流。
    for k, M in enumerate(layer_connect_mats):
        if not isinstance(M, np.ndarray):
            raise TypeError(f"layer_connect_mats[{k}] 不是 numpy.ndarray: {type(M)}")
        if M.ndim != 2:
            raise ValueError(f"layer_connect_mats[{k}] 应为二维矩阵，得到 shape={M.shape}")
        # 第 k 层 -> 第 k+1 层
        try:
            idx_src = msk_layers_params[k][0]
            idx_dst = msk_layers_params[k+1][0]
        except IndexError as e:
            raise ValueError("layer_connect_mats 与 msk_layers_params 层数不一致 (索引越界)") from e
        n_src = len(idx_src)
        n_dst = len(idx_dst)
        if M.shape[0] != n_dst or M.shape[1] != n_src:
            raise ValueError(
                f"layer_connect_mats[{k}] 形状应为 ({n_dst}, {n_src}) 对应 第{k}层->{k+1}层, 实际 {M.shape}"
            )
        # 可选：检查是否含有 NaN / Inf
        if not np.isfinite(M).all():
            raise ValueError(f"layer_connect_mats[{k}] 含有非有限值 (NaN/Inf)")

    # ---------- 基本维度 & 输入广播兼容 (模块级函数) ----------
    # n_units: 模型离散单元数量（原代码多处用 Ng 表示 grid 数量，这里用更通用的 unit 概念）
    n_units = init_state.shape[0]
    rain = _maybe_broadcast(rain, 'rain', n_units)
    temp = _maybe_broadcast(temp, 'temp', n_units)
    snow = _maybe_broadcast(snow, 'snow', n_units)
    pet  = _maybe_broadcast(pet,  'pet', n_units)

    T, n_units_from_forcing = rain.shape
    if n_units_from_forcing != n_units:
        raise ValueError(f"强制量列数 {n_units_from_forcing} 与初始状态单元数 {n_units} 不一致")
    
    # ---------- 0) 结果数组 ----------
    q_units = np.zeros((T, n_units), np.float32)
    q_basin_out = np.zeros((T,), np.float32)
    
    # layer_outputs[L] : shape (T, len(idx_L))
    layer_outputs = [np.zeros((T, len(L[0])), np.float32)
                     for L in msk_layers_params]
    
    # ---------- 1) 初始状态 ----------
    state_units = init_state.copy()
    if return_state_grid:
        states_units = np.zeros((T, n_units, init_state.shape[1]), np.float32)
        states_units[0] = state_units
    
    # 初始流量
    q0 = init_state[:, -3:].sum(axis=1)
    q0_scalar = float(q0[0])
    q_units[0] = q0
    
    # ---------- 2) Muskingum 状态初始化 ----------
    msk_states = []
    for idx, c0, _, _, n_sub in msk_layers_params:
        max_n = int(n_sub.max()) + 1
        msk_states.append(np.full((len(idx), max_n), q0_scalar, np.float32))

    # 若需要记录 Muskingum 分层状态轨迹（每层二维矩阵），创建缓冲
    if return_msk_states:
        msk_states_traj = [
            np.zeros((T, layer_state.shape[0], layer_state.shape[1]), np.float32)
            for layer_state in msk_states
        ]
    else:
        msk_states_traj = None

    combined_state = {'units': state_units, 'msk': msk_states}
    
    # ---------- 3) 观测流量覆写准备 ----------
    use_obs = (obs_station is not None) and (sta_reach_idx is not None)
    if use_obs:
        sta_reach_idx = sta_reach_idx.astype(np.int32)
    
    # ---------- 3.1 测站映射（可选，函数级，仅构建一次） ----------
    station_map = build_station_map(msk_layers_params, sta_reach_idx) if (return_station_outputs and sta_reach_idx is not None) else None
    station_outputs = None

    # ---------- 4) 时间循环 - 使用状态转移和量测方程 ----------
    # 若未来需要完全跳过层输出写入，可根据标志裁剪（此处保持与旧逻辑一致始终生成）
    need_layer_outputs = True

    for t in range(T):
        controls = np.array([rain[t], temp[t], snow[t], pet[t]], dtype=np.float32)
        obs_station_t = obs_station[t:t+1] if use_obs else None

        # --- 直接调用底层单步推进（内联原 combined_state_transition 逻辑） ---
        unit_state = combined_state['units']
        msk_states_loop = combined_state['msk']
        obs_row = (obs_station_t[0] if obs_station_t is not None else None)
        next_unit_state, next_msk_states, q_dis, outs_current = state_transition_step(
            unit_state, msk_states_loop, controls,
            pdd_pars, xaj_pars, grid2sub,
            msk_layers_params, layer_connect_mats,
            obs_station=(None if obs_row is None else obs_row[None, :]),
            sta_reach_idx=sta_reach_idx,
        )
        combined_state['units'] = next_unit_state
        combined_state['msk'] = next_msk_states
        state_units = next_unit_state
        q_units[t] = q_dis

        # 使用统一量测函数提取观测（便于 DA 框架 H(x) 一致复用）
        basin_out_t, outs_from_measure = observation_function(next_msk_states, msk_layers_params)

        # outs_current 与 outs_from_measure 语义一致；若未来 observation_function 更改聚合逻辑，
        # layer_outputs / station_outputs 即自动保持一致。
        update_layer_outputs(layer_outputs, outs_from_measure, t)

        if return_station_outputs:
            station_outputs = update_station_outputs(station_outputs, station_map, outs_from_measure, t, T)

        q_basin_out[t] = basin_out_t

        if return_state_grid:
            states_units[t] = state_units
        if return_msk_states:
            for L, layer_state in enumerate(next_msk_states):
                msk_states_traj[L][t] = layer_state

    
    # ---------- 5) 返回 ----------
    q_subbasin_out = layer_outputs[0]      # 第 0 层各子流域出流
    q_last_layer = layer_outputs[-1]       # 最后一层（出口级）逐节点出流，形状 (T, N_last)
    
    # 组合返回
    # minimal_return=False 保持向后兼容：先返回 q_grid, q_subbasin_out, q_basin_out
    # minimal_return=True 仅返回 q_basin_out（再按需附加）
    if minimal_return:
        ret = [q_basin_out]
    else:
        ret = [q_units, q_subbasin_out, q_basin_out]
    if return_last_layer:
        ret.append(q_last_layer)
    if return_state_grid:
        ret.append(states_units)
    if return_msk_states:
        ret.append(msk_states_traj)
    if return_station_outputs:
        ret.append(station_outputs)

    return tuple(ret)


# ---------------------------------------------------------------------------
# 向后兼容的封装函数
# ---------------------------------------------------------------------------
def simulate_flood_distributed_fast_state_space(
    # a. Meteo (pre-processed)
    rain: np.ndarray,
    temp: np.ndarray,
    snow: np.ndarray,
    pet: np.ndarray,
    time_index: pd.DatetimeIndex,
    # b. External flow (pre-processed)
    obs_station_arr: Optional[np.ndarray],
    sta_reach_idx: Optional[np.ndarray],
    # c. Initial conditions
    initial_state: np.ndarray,
    # d. Processed params
    model_params: Dict[str, Any],
    pdd_tuple: tuple,
    xaj_tuple: tuple,
    msk_s: Dict[str, Any],
    # e. Geo info
    grid2sub: np.ndarray,
    # Other options
    *,
    # 2025-10: enable_snowmelt 参数已移除（此前未生效，仅造成误导）。
    return_state_grid: bool = False,
    return_last_layer: bool = False,
):
    """状态空间版本的分布式洪水模拟函数

    使用状态转移和量测方程进行封装。

    变更记录:
        2025-10: 移除 enable_snowmelt 参数（无实际逻辑分支，保留会造成误导）。
    """
    Ng, Ns = grid2sub.shape
    
    # 初始状态
    state0 = initial_state

    # ---- Muskingum 分层参数提取（兼容旧 core_args 方案）----
    # 现在不再从显式 core_args 传入；转为从 msk_s 或 model_params 中自动获取。
    # 优先顺序：msk_s > model_params > 默认空列表（表示无分层路由，仅使用格点出流聚合）
    msk_layers_params = None
    layer_connect_mats = None  # 原 C_mats
    if isinstance(msk_s, dict):
        msk_layers_params = msk_s.get('msk_layers_params')
    layer_connect_mats = msk_s.get('C_mats')
    if (msk_layers_params is None) and isinstance(model_params, dict):
        msk_layers_params = model_params.get('msk_layers_params')
    if (layer_connect_mats is None) and isinstance(model_params, dict):
        layer_connect_mats = model_params.get('C_mats')
    if msk_layers_params is None:
        msk_layers_params = []
    if layer_connect_mats is None:
        layer_connect_mats = []
    
    if return_state_grid and return_last_layer:
        q_units, q_subbasin_out, q_basin_out, q_last_layer, states_units = _simulate_core_state_space(
            rain, temp, snow, pet, pdd_tuple, xaj_tuple, grid2sub.astype(np.float32),
            state0, msk_layers_params, layer_connect_mats,
            obs_station=obs_station_arr,
            sta_reach_idx=sta_reach_idx,
            return_state_grid=return_state_grid,
            return_last_layer=return_last_layer,
        )
        return q_units, q_subbasin_out, q_basin_out, q_last_layer, states_units
    
    if return_state_grid and not return_last_layer:
        q_units, q_subbasin_out, q_basin_out, states_units = _simulate_core_state_space(
            rain, temp, snow, pet, pdd_tuple, xaj_tuple, grid2sub.astype(np.float32),
            state0, msk_layers_params, layer_connect_mats,
            obs_station=obs_station_arr,
            sta_reach_idx=sta_reach_idx,
            return_state_grid=return_state_grid,
            return_last_layer=return_last_layer,
        )
        return q_units, q_subbasin_out, q_basin_out, states_units
    
    if (not return_state_grid) and return_last_layer:
        q_units, q_subbasin_out, q_basin_out, q_last_layer = _simulate_core_state_space(
            rain, temp, snow, pet, pdd_tuple, xaj_tuple, grid2sub.astype(np.float32),
            state0, msk_layers_params, layer_connect_mats,
            obs_station=obs_station_arr,
            sta_reach_idx=sta_reach_idx,
            return_last_layer=return_last_layer,
        )
        return q_units, q_subbasin_out, q_basin_out, q_last_layer
    
    # 默认：两者都不需要
    q_units, q_subbasin_out, q_basin_out = _simulate_core_state_space(
        rain, temp, snow, pet, pdd_tuple, xaj_tuple, grid2sub.astype(np.float32),
    state0, msk_layers_params, layer_connect_mats,
        obs_station=obs_station_arr,
        sta_reach_idx=sta_reach_idx,
        return_last_layer=return_last_layer,
    )
    return q_units, q_subbasin_out, q_basin_out

