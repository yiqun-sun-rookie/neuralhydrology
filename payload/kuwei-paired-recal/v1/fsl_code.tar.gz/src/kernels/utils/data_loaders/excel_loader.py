import os
import pandas as pd


def read_data_from_excel(flood_file_path: str, init_file_path: str = None) -> dict:

    # 1) 读取洪水事件数据
    all_sheets = pd.read_excel(flood_file_path, sheet_name=None)
    flood_events = {}

    for sheet_name, df_sheet in all_sheets.items():
        if 'time' not in df_sheet.columns:
            print(f"警告: 工作表 '{sheet_name}' 没有 'time' 列，跳过该工作表。")
            continue  # 跳过没有 'time' 列的工作表

        # (a) 将 time 列转换为 datetime 格式
        df_sheet['time'] = pd.to_datetime(df_sheet['time'])

        # 获取以 'e_' 开头的列名并重命名为 'pet' 开头
        e_columns = [col for col in df_sheet.columns if col.startswith('e_')]
        rename_dict = {col: 'pet' for col in e_columns}

        # 获取以 'z_' 开头的列名并重命名为 'water_level' 开头
        z_columns = [col for col in df_sheet.columns if col.startswith('z_')]
        rename_dict.update({col: 'water_level' for col in z_columns})

        # 获取以 'q_' 开头的列名并重命名为 'floods_discharge' 开头
        q_columns = [col for col in df_sheet.columns if col.startswith('q_')]
        rename_dict.update({col: 'floods_discharge' for col in q_columns})

        # 执行重命名
        df_sheet.rename(columns=rename_dict, inplace=True)

        # (c) 提取需要的列
        precip_cols = [col for col in df_sheet.columns if col.startswith('rain_')]
        needed_cols = ['time'] + precip_cols + ['pet', 'water_level', 'floods_discharge']
        existing_cols = [col for col in needed_cols if col in df_sheet.columns]
        df_sheet = df_sheet[existing_cols]

        # (d) 保存处理后的数据
        flood_events[sheet_name] = df_sheet

    # 2) 读取初始条件数据（如果提供了路径）
    initial_conditions = None
    if init_file_path is not None and os.path.isfile(init_file_path):
        try:
            initial_conditions = pd.read_excel(init_file_path, sheet_name="initial_conditions")
            initial_conditions['time'] = pd.to_datetime(initial_conditions['time'])
        except Exception as e:
            print(f"读取初始条件数据失败: {e}")

    return flood_events, initial_conditions


# ======= 使用示例 =======
if __name__ == "__main__":
    # 洪水事件文件路径
    data_path = (
        r"C:/Users/yiqun/PycharmProjects/forecast_system_lite/data/processed/naban/flood_events"
        r"/all_in_one"
    )
    # 初始条件文件路径（存放在 output_dir 的 "initial_conditions" 子目录下）
    # output_dir = os.path.dirname(data_path)
    init_file_path = os.path.join(data_path, "42101_initial_conditions.xlsx")
    flood_data_path = os.path.join(data_path, "42101.xlsx")
    data_dict = read_data_from_excel(flood_data_path, init_file_path)

    # 输出洪水事件数据的 sheet 名称
    flood_sheet_names = list(data_dict["flood_events"].keys())
    print("读取到的洪水事件 sheet 名称：", flood_sheet_names)

    # 查看洪水事件数据示例
    if flood_sheet_names:
        first_sheet = flood_sheet_names[0]
        print(f"==== 来自 {first_sheet} 的洪水事件数据示例 ====")
        print(data_dict["flood_events"][first_sheet].head())

    # 查看初始条件数据示例
    if data_dict["initial_conditions"] is not None:
        print("==== 初始条件数据示例 ====")
        print(data_dict["initial_conditions"].head())
    else:
        print("初始条件数据不存在！")

