import matplotlib.pyplot as plt
import pandas as pd
def plot_rainfall_comparison(original_df, processed_df, station_code=None):
    """
    对比同一个站点的雨量原始数据 和 重采样+插值后数据。

    参数：
    - original_df: 原始雨量DataFrame，包含 [time, station_code, rainfall]
    - processed_df: 处理后雨量DataFrame，包含 [time, station_code, rainfall]
    - station_code: 如果有多个站点，可传 station_code 来过滤单个站点绘图
    """

    # 如果需要对特定站点绘图
    if station_code is not None:
        original_df = original_df[original_df['rainfall_station_code'] == station_code].copy()
        processed_df = processed_df[processed_df['rainfall_station_code'] == station_code].copy()

    # 确保按照时间排序
    original_df = original_df.sort_values('time')
    processed_df = processed_df.sort_values('time')

    fig, ax = plt.subplots(figsize=(10, 5))

    # 绘制原始雨量，使用散点或折线
    ax.plot(
        original_df['time'],
        original_df['rainfall'],
        'o--',
        color='blue',
        alpha=0.7,
        label='Original Rainfall'
    )

    # 绘制处理后雨量
    ax.plot(
        processed_df['time'],
        processed_df['rainfall'],
        '.-',
        color='red',
        alpha=0.7,
        label='Processed Rainfall (resample+interpolate)'
    )

    ax.set_title(f"Rainfall Comparison: station_code={station_code}")
    ax.set_xlabel("Time")
    ax.set_ylabel("Rainfall (mm)")
    ax.legend()
    ax.grid(True)

    plt.show()


def plot_flow_comparison(original_df, processed_df, station_code=None):
    """
    对比同一个站点的流量(Flow)原始数据 和 重采样+插值后数据。

    参数：
    - original_df: 原始水位/流量DataFrame，包含 [time, station_code, flow]
    - processed_df: 处理后DataFrame，包含 [time, station_code, flow]
    - station_code: 如果有多个站点，可传 station_code 来过滤单个站点绘图
    """

    if station_code is not None:
        original_df = original_df[original_df['hydrologic_station_code'] == station_code].copy()
        processed_df = processed_df[processed_df['hydrologic_station_code'] == station_code].copy()

    original_df = original_df.sort_values('time')
    processed_df = processed_df.sort_values('time')

    fig, ax = plt.subplots(figsize=(10, 5))

    # 绘制原始流量
    ax.plot(
        original_df['time'],
        original_df['flow'],
        'o--',
        color='blue',
        alpha=0.7,
        label='Original Flow'
    )

    # 绘制处理后流量
    ax.plot(
        processed_df['time'],
        processed_df['flow'],
        '.-',
        color='red',
        alpha=0.7,
        label='Processed Flow (resample+interpolate)'
    )

    ax.set_title(f"Flow Comparison: station_code={station_code}")
    ax.set_xlabel("Time")
    ax.set_ylabel("Flow (m^3/s)")
    ax.legend()
    ax.grid(True)

    plt.show()

