import matplotlib.pyplot as plt

def plot_states_subplots(df_sim):
    columns_state = df_sim.columns[:-1].tolist()
    n_vars = len(columns_state)

    # 创建若干子图，这里简单按行列自动分配
    # 比如 4 行 x 2 列 = 8 个子图
    fig, axes = plt.subplots(nrows=4, ncols=2, figsize=(12, 10), sharex=True)

    # 将 2D 数组的 axes 摊平，方便用索引
    axes = axes.flatten()

    for i, col in enumerate(columns_state):
        ax = axes[i]
        ax.plot(df_sim["time"], df_sim[col], label=col)
        ax.set_title(col)
        ax.grid(True)
        # 如果时间轴是 datetime，最好让 X 轴旋转下标签
        # plt.setp(ax.get_xticklabels(), rotation=30, ha="right")

    fig.suptitle("XAJ 各状态随时间变化 - 分子图", fontsize=16)
    fig.tight_layout()
    plt.show()
