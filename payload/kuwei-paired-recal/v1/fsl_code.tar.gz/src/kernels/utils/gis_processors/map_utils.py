# gis_processors/map_utils.py
import geopandas as gpd
import folium
import streamlit as st
from folium.plugins import MarkerCluster
from config.deprecated.base_config import SHAPEFILE_CONFIG
import numpy as np
from branca.element import Template, MacroElement

def add_legend(m):
    """
    添加自定义图例到Folium地图。
    """
    template = """
    {% macro html(this, kwargs) %}
    <div style="position: fixed; 
                bottom: 50px; left: 50px; width: 180px; height: 130px; 
                border:2px solid grey; z-index:9999; font-size:14px;
                background: white; padding: 10px;
                box-shadow: 3px 3px 3px rgba(0,0,0,0.5);
                ">&nbsp; Rain Legend <br>
      &nbsp; <i style="background:gray; width:20px; height:10px; display:inline-block;"></i> No Rain <br>
      &nbsp; <i style="background:blue; width:20px; height:10px; display:inline-block;"></i> 0-10 mm <br>
      &nbsp; <i style="background:green; width:20px; height:10px; display:inline-block;"></i> 10-25 mm <br>
      &nbsp; <i style="background:orange; width:20px; height:10px; display:inline-block;"></i> 25-50 mm <br>
      &nbsp; <i style="background:red; width:20px; height:10px; display:inline-block;"></i> > 50 mm <br>
    </div>
    {% endmacro %}
    """
    macro = MacroElement()
    macro._template = Template(template)

    m.get_root().add_child(macro)
def load_gis_map():
    """
    加载GIS地图并返回Folium地图对象。
    此函数负责读取地理数据，添加地图图层，以及配置和显示站点标记。
    """

    st.markdown("""
    <style>
    .reportview-container .main .block-container {
        padding-top: 0rem;
        padding-right: 0rem;
        padding-left: 5rem;
        padding-bottom: 0rem;
    }
    </style>
    """, unsafe_allow_html=True)

    # 读取流域边界的 shapefile_path
    basin_gdf = gpd.read_file(SHAPEFILE_CONFIG['basin_boundary_path'])
    # 读取雨量站点的 shapefile_path
    rain_station_gdf = gpd.read_file(SHAPEFILE_CONFIG['rain_station_path'])
    # 提取经纬度信息
    rain_station_gdf['latitude'] = rain_station_gdf['geometry'].y
    rain_station_gdf['longitude'] = rain_station_gdf['geometry'].x
    # 移除原始的 geometry 列 (否则画图会报错)
    rain_station_gdf = rain_station_gdf.drop(columns=['geometry'])

    # 为雨量站点添加随机雨量数据，以后需要从数据库中读取
    np.random.seed(42)  # 设置随机种子，保证每次生成的随机数相同，便于测试
    rain_station_gdf['rainfall'] = np.random.uniform(0, 50, size=len(rain_station_gdf))  # 生成 0 到 50 mm 的随机雨量值

    # 初始化地图，设置中心位置和缩放级别
    m = folium.Map(location=[basin_gdf.geometry.centroid.y.mean(), basin_gdf.geometry.centroid.x.mean()], zoom_start=8.5)

    # 添加底图选项
    folium.TileLayer('OpenStreetMap').add_to(m)
    folium.TileLayer(
        tiles='https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
        attr='© OpenTopoMap contributors',
        name='Topographic Map'
    ).add_to(m)

    # 添加雨量站点图层
    # 创建一个 MarkerCluster 对象来管理大量标记
    marker_cluster = MarkerCluster(name="Rainfall Stations").add_to(m)
    # 遍历雨量站点数据，添加标记到地图
    for idx, row in rain_station_gdf.iterrows():
        # 获取站点的经纬度坐标
        lon, lat = row['latitude'], row['longitude']
        # st.write(f'Longitude: {lon}, Latitude: {lat}')
        # 获取随机生成的雨量值
        rainfall = row['rainfall']
        # st.write(f'Rainfall: {rainfall}')
        # 根据雨量值设置标记颜色
        if rainfall == 0:
            marker_color = 'gray'  # 无雨
        elif rainfall < 10:
            marker_color = 'blue'  # 小雨
        elif rainfall < 25:
            marker_color = 'green'  # 中雨
        elif rainfall < 50:
            marker_color = 'orange'  # 大雨
        else:
            marker_color = 'red'  # 暴雨

        # 创建弹出信息，显示站点名称和雨量值
        popup_content = folium.Popup(f"""
              <b>站点名称：</b>{row['站名']}<br>
              <b>雨量值：</b>{rainfall:.2f} mm
              """, max_width=250)

        # 创建标记并添加到 MarkerCluster
        folium.Marker(
            location=[lon, lat],
            popup=popup_content,
            icon=folium.Icon(color=marker_color, icon='tint')
        ).add_to(marker_cluster)

        folium.Marker(
            location=[29.22138888888889, 118.70444444444445],  # 使用您提供的一个坐标点
            popup="Test Marker",
            icon=folium.Icon(color='red', icon='info-sign')
        ).add_to(m)

    # 在 Streamlit 中显示对应雨量数据
    st.dataframe(rain_station_gdf[['站名', 'rainfall', 'latitude', 'longitude']])

    # st.dataframe(rain_station_gdf)

    # 添加流域图
    folium.GeoJson(basin_gdf, name="Basin Boundary").add_to(m)

    # add legend
    add_legend(m)

    # 添加图层控制器
    folium.LayerControl().add_to(m)

    return m
