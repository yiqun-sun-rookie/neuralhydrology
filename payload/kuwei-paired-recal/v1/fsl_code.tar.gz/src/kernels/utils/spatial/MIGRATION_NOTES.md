# 空间工具模块迁移说明

**迁移时间**: 2025-11-23  
**源项目**: `distributed_hydrological_model`  
**目标位置**: `src/modules/utils/spatial/`

---

## ✅ 已迁移组件

### 1. 格点裁剪工具 (`grid_clip.py`)

**源文件**: `distributed_hydrological_model/clip_grid_by_subbasin.py` (104 行)  
**新文件**: `src/modules/utils/spatial/grid_clip.py` (400+ 行)

**主要改进**:
- ✅ 脚本 → 模块化函数（3个核心函数 + 1个完整流程函数）
- ✅ 硬编码路径 → 参数化接口
- ✅ 无类型提示 → 完整类型注解
- ✅ 无文档 → 详细 docstring + 使用示例
- ✅ 无错误处理 → 添加文件存在性检查、CRS 警告等
- ✅ 单脚本 → 支持 CLI 和 Python API 双模式

**核心函数**:
```python
# 1. 从 NetCDF 创建格点多边形
grid_gdf = create_grid_polygons_from_netcdf('precip.nc')

# 2. 裁剪格点并计算空间关系
filtered, intersections, simple = clip_grids_by_subbasins(grid_gdf, subbasins)

# 3. 完整处理流程（一键式）
results = process_netcdf_and_subbasins(
    'precip.nc', 
    'subbasins.shp', 
    output_dir='output/gis'
)
```

**使用场景**:
- 分布式/半分布式水文模型的数据预处理
- 计算格点在子流域中的权重和面积
- 生成格点-子流域对应关系表

---

### 2. GIS 工具函数 (`gis_utils.py`)

**源文件**: `distributed_hydrological_model/src/utils/gis_utils.py` (17 行)  
**新文件**: `src/modules/utils/spatial/gis_utils.py` (200+ 行)

**主要改进**:
- ✅ 单函数 → 扩展为工具集（4个函数）
- ✅ 添加矢量化版本（支持批量计算）
- ✅ 扩展功能（格点分辨率、面积计算）
- ✅ 详细文档 + 学术引用

**核心函数**:
```python
# 1. Haversine 距离（单点）
dist = haversine(116.4, 39.9, 121.5, 31.2)  # 北京到上海

# 2. Haversine 距离（矢量化）
dists = haversine_vectorized(beijing_lon, beijing_lat, cities_lon, cities_lat)

# 3. 计算格点分辨率
dlon, dlat = calculate_grid_resolution(lons, lats)

# 4. 计算格点面积（考虑纬度）
area = grid_cell_area(lon=120, lat=30, dlon=0.25, dlat=0.25)
```

---

## 📝 使用文档

### 快速开始

#### 方式 1: Python API

```python
from src.modules.utils.spatial import grid_clip

# 完整处理流程
results = grid_clip.process_netcdf_and_subbasins(
    netcdf_path='data/2020357.06.nc',
    shapefile_path='data/gis/subwatershed_with_in_out_relation.shp',
    output_dir='output/gis',
    lon_var='lon',  # NetCDF 中的经度变量名
    lat_var='lat'   # NetCDF 中的纬度变量名
)

# 访问结果
grid_filtered = results['grid_filtered']
intersections = results['intersections']
print(f"找到 {len(intersections)} 个格点-子流域交集")
```

#### 方式 2: 命令行

```bash
cd F:\github\pycharm\projects\forecast_system_lite

python src/modules/utils/spatial/grid_clip.py \
    --netcdf data/2020357.06.nc \
    --shapefile data/gis/subwatershed.shp \
    --output output/gis \
    --lon-var lon \
    --lat-var lat
```

#### 方式 3: 分步调用（高级用法）

```python
from src.modules.utils.spatial import grid_clip
import geopandas as gpd

# 步骤 1: 创建格点多边形
grid_gdf = grid_clip.create_grid_polygons_from_netcdf('precip.nc')

# 步骤 2: 读取子流域
subbasins = gpd.read_file('subbasins.shp')

# 步骤 3: 裁剪和计算
filtered, intersections, simple = grid_clip.clip_grids_by_subbasins(
    grid_gdf, 
    subbasins,
    compute_intersection_area=True,
    area_crs=6933  # 等面积投影
)

# 步骤 4: 自定义处理
intersections['weight'] = (
    intersections['intersection_area_km2'] / 
    intersections.groupby('Subbasin_Id')['intersection_area_km2'].transform('sum')
)
```

---

## 🔄 与原代码的对应关系

| 原代码行 | 新代码位置 | 说明 |
|---------|-----------|------|
| 11-45 | `create_grid_polygons_from_netcdf()` | 格点创建逻辑 |
| 47-63 | `clip_grids_by_subbasins()` 前半部分 | CRS 检查和外接矩形筛选 |
| 65-82 | `clip_grids_by_subbasins()` 后半部分 | 交集计算和面积统计 |
| 89-98 | `clip_grids_by_subbasins()` 返回值 | 简单空间连接 |
| 100-104 | `process_netcdf_and_subbasins()` | 保存输出逻辑 |

---

## ⚠️ 兼容性说明

### 与原代码的差异

1. **列命名**:
   - 原代码硬编码了列重命名（92-98行）
   - 新代码通过 `rename_columns` 参数可选重命名

2. **输出文件名**:
   - 原代码: `grid_tif.shp`, `intersections.shp`, `intersected_grids_with_subbasins1.shp`
   - 新代码: `grid_full.shp`, `grid_filtered.shp`, `intersections.shp`, `grid_subbasin_relation.shp`

3. **返回值**:
   - 原代码: 无返回值（仅保存文件）
   - 新代码: 返回字典包含所有中间结果

### 如果需要完全兼容原脚本

```python
from src.modules.utils.spatial import process_netcdf_and_subbasins

results = process_netcdf_and_subbasins(
    netcdf_path='data/2020357.06.nc',
    shapefile_path='data/gis/subwatershed_with_in_out_relation.shp',
    output_dir='output/gis',
    rename_columns={
        'gridcode': 'Subbasin_Id',
        'S_ORDER': 'S_Order',
        'from_node': 'From_Node',
        'to_node': 'To_Node',
        'index_righ': 'All_Index'
    }
)

# 手动保存为原文件名（如需要）
results['grid_full'].to_file('output/gis/grid_tif.shp')
results['intersects_simple'].to_file('output/gis/intersected_grids_with_subbasins1.shp')
```

---

## 🧪 测试建议

### 单元测试

建议在 `tests_smoke/` 或新建 `tests/modules/utils/spatial/` 创建测试：

```python
# tests/modules/utils/spatial/test_grid_clip.py
import pytest
from src.modules.utils.spatial import grid_clip

def test_create_grid_polygons():
    """测试格点创建"""
    grid_gdf = grid_clip.create_grid_polygons_from_netcdf(
        'test_data/sample.nc'
    )
    assert len(grid_gdf) > 0
    assert 'geometry' in grid_gdf.columns
    assert grid_gdf.crs.to_string() == 'EPSG:4326'

def test_clip_grids_by_subbasins():
    """测试裁剪功能"""
    # ... 测试代码
```

### 集成测试

使用实际的 Kuwei 站点数据测试：

```python
results = process_netcdf_and_subbasins(
    netcdf_path='data/namou/grid_meteo_pet_hourly.nc',  # 实际数据
    shapefile_path='data/namou/subbasins.shp',
    output_dir='test_output'
)
assert len(results['intersections']) > 0
```

---

## 📚 依赖项

新增依赖（如果尚未安装）：
- `netCDF4`: 读取 NetCDF 文件
- `geopandas`: 空间数据处理
- `shapely`: 几何图形操作

在 `requirements.txt` 或 `pyproject.toml` 中确保包含：
```
netCDF4>=1.5.0
geopandas>=0.10.0
shapely>=1.8.0
```

---

## 🚀 后续优化建议

1. **性能优化**:
   - 对于大规模格点（>10万个），考虑使用空间索引（`.sindex`）
   - 可以添加并行处理选项（`multiprocessing` 或 `dask`）

2. **功能扩展**:
   - 支持多时间步 NetCDF（当前只处理空间维度）
   - 添加格点数据可视化函数（matplotlib/plotly）
   - 支持更多投影系统的自动选择

3. **文档完善**:
   - 在 FSL 的 `README.md` 中添加本模块的使用说明
   - 创建 Jupyter Notebook 示例教程

---

**维护者**: Antigravity AI Agent  
**最后更新**: 2025-11-23
