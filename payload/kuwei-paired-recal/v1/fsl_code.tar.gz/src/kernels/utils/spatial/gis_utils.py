"""
GIS 工具函数集合

提供常用的地理空间计算工具函数。

作者: 基于 distributed_hydrological_model 迁移
迁移时间: 2025-11-23
"""

from math import radians, cos, sin, asin, sqrt
from typing import Union, Tuple
import numpy as np


def haversine(
    lon1: float,
    lat1: float,
    lon2: float,
    lat2: float,
    unit: str = 'km'
) -> float:
    """
    使用 Haversine 公式计算地球表面两点间的大圆距离。
    
    Parameters
    ----------
    lon1, lat1 : float
        起点的经度和纬度（十进制度数）
    lon2, lat2 : float
        终点的经度和纬度（十进制度数）
    unit : {'km', 'miles', 'm'}, default='km'
        返回距离的单位
        - 'km': 千米（默认）
        - 'miles': 英里
        - 'm': 米
        
    Returns
    -------
    distance : float
        两点间的大圆距离
        
    Notes
    -----
    该方法假设地球为完美球体，半径取 6371 km。
    对于高精度应用（如大地测量），建议使用 WGS84 椭球体模型。
    
    References
    ----------
    .. [1] https://en.wikipedia.org/wiki/Haversine_formula
    
    Examples
    --------
    >>> # 北京到上海的距离
    >>> beijing = (116.4074, 39.9042)
    >>> shanghai = (121.4737, 31.2304)
    >>> dist = haversine(*beijing, *shanghai)
    >>> print(f"{dist:.1f} km")
    1067.5 km
    
    >>> # 使用英里单位
    >>> dist_miles = haversine(*beijing, *shanghai, unit='miles')
    >>> print(f"{dist_miles:.1f} miles")
    663.4 miles
    """
    # 转换为弧度
    lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])
    
    # Haversine 公式
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * asin(sqrt(a))
    
    # 地球半径（根据单位选择）
    if unit == 'km':
        r = 6371  # 千米
    elif unit == 'miles':
        r = 3956  # 英里
    elif unit == 'm':
        r = 6371000  # 米
    else:
        raise ValueError(f"Invalid unit: {unit}. Choose from 'km', 'miles', or 'm'")
    
    return c * r


def haversine_vectorized(
    lon1: Union[float, np.ndarray],
    lat1: Union[float, np.ndarray],
    lon2: Union[float, np.ndarray],
    lat2: Union[float, np.ndarray],
    unit: str = 'km'
) -> Union[float, np.ndarray]:
    """
    Haversine 公式的矢量化版本，支持批量计算。
    
    Parameters
    ----------
    lon1, lat1 : float or np.ndarray
        起点的经度和纬度（可以是数组）
    lon2, lat2 : float or np.ndarray
        终点的经度和纬度（可以是数组）
    unit : {'km', 'miles', 'm'}, default='km'
        返回距离的单位
        
    Returns
    -------
    distance : float or np.ndarray
        距离（如果输入是数组则返回数组）
        
    Examples
    --------
    >>> # 批量计算多个点到北京的距离
    >>> beijing_lon, beijing_lat = 116.4074, 39.9042
    >>> cities_lon = np.array([121.4737, 113.2644, 104.0668])  # 上海、南京、成都
    >>> cities_lat = np.array([31.2304, 23.1291, 30.5728])
    >>> distances = haversine_vectorized(
    ...     beijing_lon, beijing_lat,
    ...     cities_lon, cities_lat
    ... )
    >>> print(distances)  # [1067.5, 1956.2, 1489.3] km (approximate)
    """
    # 确保是 numpy 数组
    lon1 = np.asarray(lon1)
    lat1 = np.asarray(lat1)
    lon2 = np.asarray(lon2)
    lat2 = np.asarray(lat2)
    
    # 转换为弧度
    lon1, lat1, lon2, lat2 = map(np.radians, [lon1, lat1, lon2, lat2])
    
    # Haversine 公式（矢量化）
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = np.sin(dlat/2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2)**2
    c = 2 * np.arcsin(np.sqrt(a))
    
    # 地球半径
    if unit == 'km':
        r = 6371
    elif unit == 'miles':
        r = 3956
    elif unit == 'm':
        r = 6371000
    else:
        raise ValueError(f"Invalid unit: {unit}. Choose from 'km', 'miles', or 'm'")
    
    return c * r


def calculate_grid_resolution(
    lons: np.ndarray,
    lats: np.ndarray
) -> Tuple[float, float]:
    """
    计算均匀格点的分辨率（经纬度间隔）。
    
    Parameters
    ----------
    lons : np.ndarray
        经度数组（一维）
    lats : np.ndarray
        纬度数组（一维）
        
    Returns
    -------
    dlon, dlat : tuple of float
        经度和纬度分辨率（度数）
        
    Examples
    --------
    >>> lons = np.arange(100, 120, 0.25)
    >>> lats = np.arange(20, 40, 0.25)
    >>> dlon, dlat = calculate_grid_resolution(lons, lats)
    >>> print(f"Resolution: {dlon}° × {dlat}°")
    Resolution: 0.25° × 0.25°
    """
    dlon = np.abs(lons[1] - lons[0]) if len(lons) > 1 else 0.0
    dlat = np.abs(lats[1] - lats[0]) if len(lats) > 1 else 0.0
    return dlon, dlat


def grid_cell_area(
    lon: Union[float, np.ndarray],
    lat: Union[float, np.ndarray],
    dlon: float,
    dlat: float,
    unit: str = 'km2'
) -> Union[float, np.ndarray]:
    """
    计算经纬度格点的面积（考虑纬度影响）。
    
    Parameters
    ----------
    lon : float or np.ndarray
        格点中心经度
    lat : float or np.ndarray
        格点中心纬度
    dlon : float
        经度分辨率（度）
    dlat : float
        纬度分辨率（度）
    unit : {'km2', 'm2'}, default='km2'
        面积单位
        
    Returns
    -------
    area : float or np.ndarray
        格点面积
        
    Notes
    -----
    使用简化公式，假设格点为矩形且地球为球体。
    对于高纬度地区，经度方向的实际距离会随纬度减小。
    
    Examples
    --------
    >>> # 赤道附近的 0.25° × 0.25° 格点
    >>> area_eq = grid_cell_area(120, 0, 0.25, 0.25)
    >>> print(f"Equator: {area_eq:.1f} km²")
    
    >>> # 北纬 60° 的 0.25° × 0.25° 格点
    >>> area_60n = grid_cell_area(120, 60, 0.25, 0.25)
    >>> print(f"60°N: {area_60n:.1f} km²")
    """
    # 地球半径
    if unit == 'km2':
        R = 6371.0  # km
    elif unit == 'm2':
        R = 6371000.0  # m
    else:
        raise ValueError(f"Invalid unit: {unit}. Choose 'km2' or 'm2'")
    
    # 转换为弧度
    lat_rad = np.radians(lat)
    dlon_rad = np.radians(dlon)
    dlat_rad = np.radians(dlat)
    
    # 简化面积公式（矩形近似）
    # Area = R² * |dlon| * |sin(lat + dlat/2) - sin(lat - dlat/2)|
    area = R**2 * np.abs(dlon_rad) * np.abs(
        np.sin(lat_rad + dlat_rad/2) - np.sin(lat_rad - dlat_rad/2)
    )
    
    return area

