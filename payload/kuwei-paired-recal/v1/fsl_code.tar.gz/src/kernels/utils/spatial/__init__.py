"""
空间处理工具模块

提供网格数据处理、GIS 计算等空间分析功能。

主要功能
--------
- 格点裁剪: 从 NetCDF 格点数据中提取子流域相关格点
- GIS 计算: Haversine 距离、格点面积等地理计算
- 空间关系: 格点-子流域空间关系分析

模块来源
--------
本模块部分代码迁移自 distributed_hydrological_model 项目（2025-11-23）

Examples
--------
>>> from src.kernels.utils.spatial import grid_clip, gis_utils
>>> 
>>> # 处理 NetCDF 和 Shapefile
>>> results = grid_clip.process_netcdf_and_subbasins(
...     'data/precip.nc',
...     'data/subbasins.shp',
...     output_dir='output/gis'
... )
>>> 
>>> # 计算距离
>>> dist = gis_utils.haversine(116.4, 39.9, 121.5, 31.2)
>>> print(f"Distance: {dist:.1f} km")
"""

from .grid_clip import (
    create_grid_polygons_from_netcdf,
    clip_grids_by_subbasins,
    process_netcdf_and_subbasins
)

from .gis_utils import (
    haversine,
    haversine_vectorized,
    calculate_grid_resolution,
    grid_cell_area
)

__all__ = [
    # 格点裁剪
    'create_grid_polygons_from_netcdf',
    'clip_grids_by_subbasins',
    'process_netcdf_and_subbasins',
    # GIS 工具
    'haversine',
    'haversine_vectorized',
    'calculate_grid_resolution',
    'grid_cell_area',
]

