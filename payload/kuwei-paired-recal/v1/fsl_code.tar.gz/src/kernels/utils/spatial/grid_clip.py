"""
网格-子流域空间关系处理工具

本模块提供从 NetCDF 格点数据中裁剪子流域相关格点并计算空间关系的功能。
主要用于分布式/半分布式水文模型的数据预处理。

作者: 基于 distributed_hydrological_model 迁移并重构
迁移时间: 2025-11-23
"""

import netCDF4 as nc
import numpy as np
import geopandas as gpd
import pandas as pd
from pathlib import Path
from typing import Tuple, Dict, Optional, Union
from shapely.geometry import Polygon
import warnings


def create_grid_polygons_from_netcdf(
    netcdf_path: Union[str, Path],
    lon_var: str = 'lon',
    lat_var: str = 'lat',
    crs: str = "EPSG:4326"
) -> gpd.GeoDataFrame:
    """
    从 NetCDF 文件中提取经纬度格点并创建多边形 GeoDataFrame。
    
    Parameters
    ----------
    netcdf_path : str or Path
        NetCDF 文件路径
    lon_var : str, default='lon'
        NetCDF 中经度变量名
    lat_var : str, default='lat'
        NetCDF 中纬度变量名
    crs : str, default="EPSG:4326"
        坐标参考系统
        
    Returns
    -------
    grid_gdf : gpd.GeoDataFrame
        格点多边形数据，包含以下列：
        - Row_Index: 格点行索引
        - Col_Index: 格点列索引
        - Longitude: 格点中心经度
        - Latitude: 格点中心纬度
        - geometry: 格点多边形
        
    Notes
    -----
    假设经纬度为一维数组，格点均匀分布。
    多边形边界为格点中心点向四周扩展半个格距。
    
    Examples
    --------
    >>> grid_gdf = create_grid_polygons_from_netcdf('precip.nc')
    >>> print(grid_gdf.shape)
    (1000, 5)
    """
    netcdf_path = Path(netcdf_path)
    if not netcdf_path.exists():
        raise FileNotFoundError(f"NetCDF file not found: {netcdf_path}")
    
    # 打开 NetCDF 文件
    with nc.Dataset(netcdf_path, 'r') as ds:
        # 读取经纬度
        if lon_var not in ds.variables:
            raise ValueError(f"Longitude variable '{lon_var}' not found in NetCDF")
        if lat_var not in ds.variables:
            raise ValueError(f"Latitude variable '{lat_var}' not found in NetCDF")
            
        lons = ds.variables[lon_var][:]
        lats = ds.variables[lat_var][:]
    
    # 生成网格坐标
    lon_grid, lat_grid = np.meshgrid(lons, lats)
    
    # 扁平化网格坐标数组
    lon_coords = lon_grid.flatten()
    lat_coords = lat_grid.flatten()
    
    # 生成行索引和列索引
    row_indices = np.repeat(np.arange(lat_grid.shape[0]), lon_grid.shape[1])
    col_indices = np.tile(np.arange(lon_grid.shape[1]), lat_grid.shape[0])
    
    # 计算格距（假设均匀分布）
    delta_lon = np.abs(lons[1] - lons[0]) if len(lons) > 1 else 0.1
    delta_lat = np.abs(lats[1] - lats[0]) if len(lats) > 1 else 0.1
    
    # 创建多边形（每个格点中心向外扩展半个格距）
    polygons = [
        Polygon([
            (lon - delta_lon / 2, lat - delta_lat / 2),
            (lon + delta_lon / 2, lat - delta_lat / 2),
            (lon + delta_lon / 2, lat + delta_lat / 2),
            (lon - delta_lon / 2, lat + delta_lat / 2)
        ]) for lon, lat in zip(lon_coords, lat_coords)
    ]
    
    # 创建 GeoDataFrame
    grid_gdf = gpd.GeoDataFrame({
        'Row_Index': row_indices,
        'Col_Index': col_indices,
        'Longitude': lon_coords,
        'Latitude': lat_coords,
        'geometry': polygons
    }, crs=crs)
    
    return grid_gdf


def clip_grids_by_subbasins(
    grid_gdf: gpd.GeoDataFrame,
    subbasins_gdf: gpd.GeoDataFrame,
    compute_intersection_area: bool = True,
    area_crs: int = 6933
) -> Tuple[gpd.GeoDataFrame, gpd.GeoDataFrame, gpd.GeoDataFrame]:
    """
    根据子流域边界裁剪格点数据并计算空间关系。
    
    Parameters
    ----------
    grid_gdf : gpd.GeoDataFrame
        格点多边形数据（来自 create_grid_polygons_from_netcdf）
    subbasins_gdf : gpd.GeoDataFrame
        子流域多边形数据（从 Shapefile 读取）
    compute_intersection_area : bool, default=True
        是否计算交集面积（需要投影转换）
    area_crs : int, default=6933
        用于面积计算的投影坐标系 EPSG 代码
        默认 6933 是等面积投影（适合全球尺度）
        
    Returns
    -------
    grid_filtered : gpd.GeoDataFrame
        与子流域外接矩形相交的格点
    intersections : gpd.GeoDataFrame
        格点与子流域的精确交集多边形（包含面积信息）
    intersects_simple : gpd.GeoDataFrame
        格点与子流域的简单连接关系（用于快速查询）
        
    Notes
    -----
    - 会自动处理 CRS 不一致的情况
    - 面积计算使用等面积投影（EPSG:6933），结果单位为平方公里
    
    Examples
    --------
    >>> grid_gdf = create_grid_polygons_from_netcdf('precip.nc')
    >>> subbasins = gpd.read_file('subbasins.shp')
    >>> filtered, intersections, simple = clip_grids_by_subbasins(grid_gdf, subbasins)
    >>> print(f"Found {len(intersections)} grid-subbasin intersections")
    """
    # 检查并统一 CRS
    if grid_gdf.crs != subbasins_gdf.crs:
        warnings.warn(
            f"CRS mismatch: grid ({grid_gdf.crs}) != subbasins ({subbasins_gdf.crs}). "
            f"Converting grid to match subbasins.",
            UserWarning
        )
        grid_gdf = grid_gdf.to_crs(subbasins_gdf.crs)
    
    # 使用子流域外接矩形快速筛选格点
    subbasins_bounds = subbasins_gdf.total_bounds  # [minx, miny, maxx, maxy]
    grid_filtered = grid_gdf.cx[
        subbasins_bounds[0]:subbasins_bounds[2],
        subbasins_bounds[1]:subbasins_bounds[3]
    ]
    
    if len(grid_filtered) == 0:
        warnings.warn(
            "No grids found within subbasin bounds. "
            "Check if NetCDF and Shapefile cover the same geographic area.",
            UserWarning
        )
    
    # 计算精确交集
    intersections = gpd.overlay(grid_filtered, subbasins_gdf, how='intersection')
    
    # 计算交集面积
    if compute_intersection_area and len(intersections) > 0:
        # 转换到等面积投影
        intersections_proj = intersections.to_crs(epsg=area_crs)
        
        # 计算面积（单位：平方米）
        intersections['intersection_area_m2'] = intersections_proj.geometry.area
        
        # 转换为平方公里
        intersections['intersection_area_km2'] = intersections['intersection_area_m2'] / 1e6
    
    # 简单空间连接（用于快速查询哪些格点在哪个子流域）
    intersects_simple = gpd.sjoin(
        subbasins_gdf,
        grid_filtered,
        how="inner",
        predicate="intersects"
    )
    
    return grid_filtered, intersections, intersects_simple


def process_netcdf_and_subbasins(
    netcdf_path: Union[str, Path],
    shapefile_path: Union[str, Path],
    output_dir: Optional[Union[str, Path]] = None,
    lon_var: str = 'lon',
    lat_var: str = 'lat',
    save_outputs: bool = True,
    rename_columns: Optional[Dict[str, str]] = None
) -> Dict[str, gpd.GeoDataFrame]:
    """
    完整处理流程：从 NetCDF 和 Shapefile 生成格点-子流域空间关系。
    
    Parameters
    ----------
    netcdf_path : str or Path
        NetCDF 格点数据文件路径
    shapefile_path : str or Path
        子流域 Shapefile 路径
    output_dir : str or Path, optional
        输出目录，如果为 None 则不保存文件（仅返回数据）
    lon_var : str, default='lon'
        NetCDF 经度变量名
    lat_var : str, default='lat'
        NetCDF 纬度变量名
    save_outputs : bool, default=True
        是否保存输出文件（需要指定 output_dir）
    rename_columns : dict, optional
        对 intersects_simple 结果进行列重命名的映射
        例如: {'gridcode': 'Subbasin_Id', 'S_ORDER': 'S_Order'}
        
    Returns
    -------
    results : dict
        包含以下键值对:
        - 'grid_full': 完整格点数据
        - 'grid_filtered': 裁剪后的格点
        - 'intersections': 交集多边形（含面积）
        - 'intersects_simple': 简单连接关系
        - 'subbasins': 子流域数据
        
    Examples
    --------
    >>> results = process_netcdf_and_subbasins(
    ...     'precip.nc',
    ...     'subbasins.shp',
    ...     output_dir='output/gis'
    ... )
    >>> print(results['intersections'].head())
    """
    netcdf_path = Path(netcdf_path)
    shapefile_path = Path(shapefile_path)
    
    # 1. 创建格点多边形
    print(f"[1/4] Reading NetCDF: {netcdf_path.name}")
    grid_gdf = create_grid_polygons_from_netcdf(
        netcdf_path,
        lon_var=lon_var,
        lat_var=lat_var
    )
    print(f"      Created {len(grid_gdf)} grid cells")
    
    # 2. 读取子流域
    print(f"[2/4] Reading Shapefile: {shapefile_path.name}")
    subbasins_gdf = gpd.read_file(shapefile_path)
    print(f"      Loaded {len(subbasins_gdf)} subbasins")
    
    # 3. 裁剪和计算交集
    print(f"[3/4] Computing spatial intersections...")
    grid_filtered, intersections, intersects_simple = clip_grids_by_subbasins(
        grid_gdf, subbasins_gdf
    )
    print(f"      Filtered grids: {len(grid_filtered)}")
    print(f"      Intersections: {len(intersections)}")
    print(f"      Simple joins: {len(intersects_simple)}")
    
    # 4. 列重命名（可选）
    if rename_columns:
        intersects_simple = intersects_simple.rename(columns=rename_columns)
    
    # 5. 保存输出（可选）
    if save_outputs and output_dir:
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        print(f"[4/4] Saving outputs to: {output_dir}")
        grid_gdf.to_file(output_dir / "grid_full.shp")
        grid_filtered.to_file(output_dir / "grid_filtered.shp")
        intersections.to_file(output_dir / "intersections.shp")
        intersects_simple.to_file(output_dir / "grid_subbasin_relation.shp")
        intersects_simple.to_csv(
            output_dir / "grid_subbasin_relation.csv",
            index=False
        )
        print(f"      Saved 5 files")
    
    return {
        'grid_full': grid_gdf,
        'grid_filtered': grid_filtered,
        'intersections': intersections,
        'intersects_simple': intersects_simple,
        'subbasins': subbasins_gdf
    }


# ==================== CLI 接口（可选） ====================
if __name__ == "__main__":
    """
    命令行使用示例:
    python grid_clip.py --netcdf data/precip.nc --shapefile data/subbasins.shp --output output/gis
    """
    import argparse
    
    parser = argparse.ArgumentParser(
        description="从 NetCDF 格点数据中裁剪子流域格点并计算空间关系"
    )
    parser.add_argument(
        '--netcdf', '-n',
        required=True,
        help='NetCDF 文件路径'
    )
    parser.add_argument(
        '--shapefile', '-s',
        required=True,
        help='子流域 Shapefile 路径'
    )
    parser.add_argument(
        '--output', '-o',
        default='output/gis',
        help='输出目录（默认: output/gis）'
    )
    parser.add_argument(
        '--lon-var',
        default='lon',
        help='经度变量名（默认: lon）'
    )
    parser.add_argument(
        '--lat-var',
        default='lat',
        help='纬度变量名（默认: lat）'
    )
    
    args = parser.parse_args()
    
    results = process_netcdf_and_subbasins(
        netcdf_path=args.netcdf,
        shapefile_path=args.shapefile,
        output_dir=args.output,
        lon_var=args.lon_var,
        lat_var=args.lat_var
    )
    
    print("\n✅ Processing completed!")
    print(f"   Results saved to: {args.output}")

