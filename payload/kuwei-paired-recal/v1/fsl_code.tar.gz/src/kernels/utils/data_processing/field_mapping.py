import pandas as pd
import geopandas as gpd
def validate_and_convert(df):
    if 'time' in df.columns:
        df['time'] = pd.to_datetime(df['time'], errors='coerce')
    if 'rainfall' in df.columns:
        df['rainfall'] = pd.to_numeric(df['rainfall'], errors='coerce').fillna(0)
    if 'longitude' in df.columns:
        df['longitude'] = pd.to_numeric(df['longitude'], errors='coerce')
    if 'latitude' in df.columns:
        df['latitude'] = pd.to_numeric(df['latitude'], errors='coerce')
    return df

def standardize_fields(df, field_mapping):
    new_columns = {}
    for standard_field, possible_fields in field_mapping.items():
        found = False
        for field in possible_fields:
            if field in df.columns:
                new_columns[field] = standard_field
                found = True
                break
        if not found:
            print(f"警告：未找到字段 {standard_field} 的对应列")
    df = df.rename(columns=new_columns)
    return df

def load_and_standardize_shapefile(filepath, field_mapping):
    df = gpd.read_file(filepath)
    df = standardize_fields(df, field_mapping)
    df = validate_and_convert(df)
    return df
def load_and_standardize_csv(filepath, field_mapping):
    df = pd.read_csv(filepath)
    df = standardize_fields(df, field_mapping)
    df = validate_and_convert(df)
    return df

