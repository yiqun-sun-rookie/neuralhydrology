import matplotlib.pyplot as plt
import numpy as np
import matplotlib.colors as colors
import pandas as pd
from datetime import datetime
# data_processing/plots.py

import matplotlib.pyplot as plt
import numpy as np
import matplotlib.colors as colors
from datetime import datetime
import os
import networkx as nx

def visualize_section_station_relationship(section_station_df):
    """
    可视化水文断面与雨量站的对应关系及断面之间的流入流出关系。

    参数：
    - section_station_df: DataFrame，包含hydro_section_code, precipitation_code, input_area_code等列。
    """

    # 创建有向图
    G = nx.DiGraph()

    # 提取所有断面代码和雨量站代码
    hs_codes = section_station_df['hydro_section_code'].unique()

    # 1. 添加断面节点
    for _, row in section_station_df.iterrows():
        hs_code = row['hydro_section_code']
        G.add_node(hs_code, node_type='section')

    # 2. 为每个断面添加对应的雨量站节点，并连接雨量站到断面
    for _, row in section_station_df.iterrows():
        hs_code = row['hydro_section_code']
        p_code = row['rainfall_station_code']

        # 如果有雨量站代码，则添加雨量站节点并连接到对应断面
        if pd.notnull(p_code):
            G.add_node(p_code, node_type='precipitation')
            # 将雨量站节点指向断面节点，表明该雨量站为该断面提供信息
            G.add_edge(p_code, hs_code)

    # 3. 根据 input_area_code 建立断面间的拓扑关系
    # 如果 input_area_code 对应的断面存在，则从 input_area_code 指向当前 hydro_section_code
    # 假设 input_area_code 是另一个 hydro_section_code 的值
    hs_code_set = set(hs_codes)
    for _, row in section_station_df.iterrows():
        hs_code = row['hydro_section_code']
        inp_code = row['input_section_code']
        if pd.notnull(inp_code) and inp_code in hs_code_set:
            # input_area_code -> hydro_section_code
            G.add_edge(inp_code, hs_code)

    # 布局
    pos = nx.spring_layout(G, k=0.5, seed=42)

    # 根据节点类型区分绘制颜色
    section_nodes = [n for n, d in G.nodes(data=True) if d.get('node_type') == 'section']
    precip_nodes = [n for n, d in G.nodes(data=True) if d.get('node_type') == 'precipitation']

    # 绘制节点
    nx.draw_networkx_nodes(G, pos, nodelist=section_nodes, node_color='lightblue', node_size=800, label='Sections')
    nx.draw_networkx_nodes(G, pos, nodelist=precip_nodes, node_color='lightcoral', node_size=500,
                           label='Precipitation Stations')

    # 绘制边
    nx.draw_networkx_edges(G, pos, arrows=True, arrowstyle='->', arrowsize=10)

    # 节点标签使用节点本身作为名称
    labels = {n: n for n in G.nodes()}
    nx.draw_networkx_labels(G, pos, labels, font_size=8)

    plt.title("Section-Station Inflow-Outflow Relationship")
    plt.legend(scatterpoints=1)
    plt.axis('off')
    plt.show()

def plot_interpolation_results(xi, yi, zi, df_time, time_point, method='Interpolation'):
    """
    绘制插值结果。

    参数：
    - xi: ndarray，插值点的经度坐标。
    - yi: ndarray，插值点的纬度坐标。
    - zi: ndarray，插值点的雨量值。
    - df_time: DataFrame，当前时间点的观测数据。
    - time_point: datetime，时间点。
    - method: str，插值方法名称，用于保存文件和标题。
    """
    # 检查 zi 是否为空
    if zi is None or len(zi) == 0:
        print(f"时间点 {time_point} 的插值结果为空，跳过绘图。")
        return

    # 确保 xi、yi、zi 为一维数组
    xi = np.asarray(xi)
    yi = np.asarray(yi)
    zi = np.asarray(zi)

    # 定义颜色映射和归一化
    vmin = np.nanmin(zi)
    vmax = np.nanmax(zi)
    if vmin == vmax:
        vmax = vmin + 1e-6  # 避免 vmax 等于 vmin

    cmap = plt.cm.jet
    norm = colors.Normalize(vmin=vmin, vmax=vmax)

    # 创建绘图
    plt.figure(figsize=(10, 8))

    # 绘制插值结果
    scatter = plt.scatter(xi, yi, c=zi, cmap=cmap, norm=norm, marker='s', s=40, edgecolor='none')
    plt.colorbar(scatter, label='Rainfall (mm)')

    # 绘制观测点
    plt.scatter(
        df_time['longitude'],
        df_time['latitude'],
        c=df_time['rainfall'],
        edgecolor='k',
        cmap=cmap,
        norm=norm,
        s=60,
        label='Observation'
    )

    plt.title(f"{method} Interpolation - Time {time_point}")
    plt.xlabel('Longitude')
    plt.ylabel('Latitude')
    plt.legend()

    # 处理时间格式
    if isinstance(time_point, str):
        time_point_dt = datetime.strptime(time_point, '%Y-%m-%d %H:%M:%S')
    else:
        time_point_dt = time_point

    # 将 numpy.datetime64 转换为 datetime.datetime 对象
    time_point_dt = pd.to_datetime(time_point_dt)
    time_str = time_point_dt.strftime('%Y-%m-%d_%H-%M-%S')

    # 创建保存目录（如果不存在）
    save_dir = f'../figures/{method}'
    os.makedirs(save_dir, exist_ok=True)

    plt.savefig(f'{save_dir}/{time_str}.png')
    plt.close()

def plot_interpolation_results0(xi, yi, zi, filled_df_cleaned, time_point):
    # 检查 zi 的最小值和最大值
    print("zi 的最小值：", np.nanmin(zi))
    print("zi 的最大值：", np.nanmax(zi))
    print("zi 中 NaN 的数量：", np.isnan(zi).sum())
    print("zi 中零值的数量：", np.sum(zi == 0))
    print("zi 的总元素数量：", zi.size)

    vmin = np.nanmin(zi)
    vmax = np.nanmax(zi)
    if vmin == vmax:
        vmax = vmin + 1e-6  # 避免 vmax 等于 vmin
    cmap = plt.cm.jet
    norm = colors.Normalize(vmin=vmin, vmax=vmax)
    # 使用 pcolormesh 绘制插值结果
    mesh = plt.pcolormesh(xi, yi, zi, cmap=cmap, norm=norm, shading='auto')
    # 添加颜色条
    plt.colorbar(mesh, label='Rain (mm)')

    # 绘制原始数据点
    plt.scatter(
        filled_df_cleaned[filled_df_cleaned['Time'] == time_point]['longitude'],
        filled_df_cleaned[filled_df_cleaned['Time'] == time_point]['latitude'],
        c=filled_df_cleaned[filled_df_cleaned['Time'] == time_point]['Rain'],
        edgecolor='k',
        cmap=cmap,
        norm=norm
    )

    plt.title(f"interpolate - Time {time_point}")
    plt.xlabel('Longitude')
    plt.ylabel('Latitude')

    # 如果 time_point 是字符串
    if isinstance(time_point, str):
        time_point_dt = datetime.strptime(time_point, '%Y-%m-%d %H:%M:%S')
    else:
        time_point_dt = time_point

    # 使用下划线替换非法字符
    time_str = time_point_dt.strftime('%Y-%m-%d_%H-%M-%S')

    plt.savefig(f'../figures/krig/{time_str}.png')
    plt.close()
    # plt.show()

