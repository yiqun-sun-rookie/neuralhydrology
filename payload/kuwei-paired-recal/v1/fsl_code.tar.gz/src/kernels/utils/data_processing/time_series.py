import pandas as pd

import pandas as pd


def is_exact_hour(dt):
    """判断一个时间戳是否为整点(分钟和秒为0)"""
    return (dt.minute == 0) and (dt.second == 0) and (dt.microsecond == 0)

import pandas as pd

def conditional_resample_by_station(df, time_col='time', id_col='station_code', freq='1H', agg='mean', value_cols=None):
    """
    对包含多个站点的DataFrame进行条件性重采样。
    对每个站点（由id_col分组）进行以下操作：
    - 保留原本在整点上的数据点（无需重采样）
    - 对非整点的数据点按freq重采样，并使用agg对指定的value_cols进行聚合
    最终将各站点的结果合并。

    参数：
    - df: 原始DataFrame，包含 time_col 和 id_col。
    - time_col (str): 时间列列名。
    - id_col (str): 用于分组的ID列名（如 'station_code'）。
    - freq (str): 重采样频率，如 '1H'。
    - agg: 聚合函数或函数名，如 'mean'、'sum'等，或字典 {col: func, ...}。
    - value_cols (list或None): 需要重采样的列名列表。如果为None则对所有数值列进行重采样。

    返回：
    - combined_all: 将所有站点重采样后的结果合并的 DataFrame，
      包含 time_col、id_col 和需要重采样的 value_cols。
    """

    if not pd.api.types.is_datetime64_any_dtype(df[time_col]):
        df[time_col] = pd.to_datetime(df[time_col])

    # 如果用户未指定 value_cols，则默认对数值列进行处理
    if value_cols is None:
        # 排除 time_col 和 id_col 后，对数值列进行识别
        numeric_cols = df.select_dtypes(include=[float, int]).columns.tolist()
        # 移除id_col和time_col，剩下的就都是可重采样的数值列
        value_cols = [c for c in numeric_cols if c not in [time_col, id_col]]

    def is_exact_hour(dt):
        return (dt.minute == 0) and (dt.second == 0) and (dt.microsecond == 0)

    group_results = []

    # 按id_col分组，对每个站点独立处理
    for g_id, df_group in df.groupby(id_col):
        df_group = df_group.sort_values(time_col).copy()
        df_group.set_index(time_col, inplace=True)

        exact_hour_mask = df_group.index.map(is_exact_hour)
        df_exact = df_group[exact_hour_mask].copy()
        df_non_exact = df_group[~exact_hour_mask].copy()

        if not df_non_exact.empty:
            df_resampled = df_non_exact[value_cols].resample(freq).agg(agg)
        else:
            df_resampled = pd.DataFrame(columns=value_cols)

        # 对整点数据，仅保留需要的列
        # 但我们还需要在结果中保留id_col信息，所以在恢复时手动加回去
        df_exact_val = df_exact[value_cols]

        # 合并整点数据和重采样数据
        combined = pd.concat([df_exact_val, df_resampled])
        combined = combined[~combined.index.duplicated(keep='first')]
        combined = combined.sort_index().reset_index().rename(columns={'index': time_col})

        # 给合并后的数据加上id_col
        combined[id_col] = g_id

        # 将列顺序整理一下，将id_col和time_col放前面
        ordered_cols = [id_col, time_col] + [col for col in combined.columns if col not in [id_col, time_col]]
        combined = combined[ordered_cols]

        group_results.append(combined)

    # 合并所有站点的结果
    combined_all = pd.concat(group_results, ignore_index=True)
    return combined_all

# 使用示例：
# final_df = conditional_resample_by_station(df, time_col='time', id_col='station_code', freq='1H', agg='mean', value_cols=['stage','flow'])



# 假设有一个 DataFrame df 原始数据包含 time, stage, flow 等列
# 条件重采样
# combined_df = conditional_resample(df, time_col='time', freq='1H', agg='mean')

# 此时 combined_df 包含整点数据(原始准确的)和不在整点上的数据重采样结果
# 对 combined_df 中仍可能有 NaN 的位置进行插值
def interpolate_missing_data(df, time_col='time', id_col='station_code', value_cols=['stage', 'flow'], method='linear'):
    if not pd.api.types.is_datetime64_any_dtype(df[time_col]):
        df[time_col] = pd.to_datetime(df[time_col])
    df = df.sort_values([id_col, time_col])

    # 首先检查是否有缺失值
    if not df[value_cols].isnull().any().any():
        # 如果没有空值，则直接返回 df，不进行插值
        return df

    # 如果仍有空值，才进行插值
    df = df.groupby(id_col, group_keys=False).apply(
        lambda g: g.set_index(time_col)[value_cols].interpolate(method=method, limit_direction='both').reset_index()
    )

    return df

def generate_time_points(start_time_str, end_time_str, time_interval_str='1H'):
    """
    根据开始时间、结束时间和时间间隔生成时间点序列。

    参数:
    - start_time_str (str): 开始时间字符串，例如 '2013-06-01 00:00'
    - end_time_str (str): 结束时间字符串，例如 '2013-06-10 00:00'
    - time_interval_str (str): 时间间隔字符串，例如 '1H' 表示 1 小时，'30min' 表示 30 分钟

    返回:
    - time_points (DatetimeIndex): 生成的时间点序列
    """
    # 输入检查
    try:
        start_time = pd.to_datetime(start_time_str)
    except ValueError:
        raise ValueError(f"无法解析开始时间字符串: {start_time_str}")

    try:
        end_time = pd.to_datetime(end_time_str)
    except ValueError:
        raise ValueError(f"无法解析结束时间字符串: {end_time_str}")

    if start_time > end_time:
        raise ValueError("开始时间必须早于或等于结束时间。")

    try:
        time_interval = pd.to_timedelta(time_interval_str)
    except ValueError:
        raise ValueError(f"无法解析时间间隔字符串: {time_interval_str}")

    if time_interval <= pd.Timedelta(0):
        raise ValueError("时间间隔必须是正数。")

    # 生成时间点序列
    time_points = pd.date_range(start=start_time, end=end_time, freq=time_interval)
    return time_points

import pandas as pd

def interpolate_time_series_data(
    df,
    time_points,
    time_col='time',
    id_col='station_code',
    value_cols=['stage', 'flow'],
    min_data_points=10,
    method_less_data='linear',
    method_more_data='spline',
    fallback_method='linear',
    order=3
):
    """
    对时间序列数据进行插值。

    参数：
    - df: 输入数据的DataFrame，包含时间列、分组标识列和数值列。
    - time_points: 统一的时间索引（pd.DatetimeIndex或可转换为datetime的序列）。
    - time_col (str): 表示时间戳的列名。
    - id_col (str): 用于分组的ID列名（如站点编码）。
    - value_cols (list): 需要插值的数值列列表。
    - min_data_points (int): 判断数据点多少以决定插值策略的阈值。
    - method_less_data (str): 当数据点较少时使用的插值方法（如 'linear', 'time'）。
    - method_more_data (str): 当数据点较多时使用的插值方法（如 'spline'）。
    - fallback_method (str): 当样条插值失败时的备选插值方法。
    - order (int): 样条插值的阶数。

    返回：
    - result_df: 插值后的 DataFrame，与原 df 列类似，但确保在 time_points 对应的时间上都有插值完成的数据。
    """

    # 确保 time_col 为datetime类型
    if not pd.api.types.is_datetime64_any_dtype(df[time_col]):
        df[time_col] = pd.to_datetime(df[time_col])

    # 按 id_col 分组
    grouped = df.groupby(id_col, group_keys=False)

    interpolated_dfs = []
    for g_id, df_group in grouped:
        # 按时间排序并设置索引
        df_group = df_group.sort_values(time_col).set_index(time_col)
        # 对齐统一的时间点
        df_group = df_group.reindex(time_points)

        # 统计有效数据点数量（使用需要插值的列之一作为参考，也可以使用更多逻辑）
        valid_data_points = df_group[value_cols[0]].count()

        # 根据有效数据点数量选择插值策略
        if valid_data_points < min_data_points:
            # 数据点较少，使用简单插值
            df_group[value_cols] = df_group[value_cols].interpolate(method=method_less_data, limit_direction='both')
        else:
            # 数据点较多，尝试使用样条插值
            # 样条插值需要数值索引，将时间转换为数值型索引（秒数）
            numeric_index = (df_group.index - df_group.index[0]).total_seconds()
            df_tmp = df_group.copy()
            df_tmp['numeric_index'] = numeric_index
            df_tmp = df_tmp.reset_index().set_index('numeric_index')

            for col in value_cols:
                try:
                    df_tmp[col] = df_tmp[col].interpolate(method=method_more_data, order=order)
                except:
                    # 如果样条插值失败，回退到fallback_method
                    df_tmp[col] = df_tmp[col].interpolate(method=fallback_method)

            # 恢复时间索引
            df_tmp[time_col] = df_group.index[0] + pd.to_timedelta(df_tmp.index, unit='s')
            df_tmp = df_tmp.set_index(time_col)
            df_tmp = df_tmp.drop(columns='numeric_index')
            df_group = df_tmp

        # 恢复 id_col 列值
        df_group[id_col] = g_id
        interpolated_dfs.append(df_group)

    # 合并所有站点结果
    result_df = pd.concat(interpolated_dfs)
    result_df = result_df.reset_index()

    # 确保列顺序，将 time_col, id_col 放前面
    cols = [id_col, time_col] + [c for c in df.columns if c not in [id_col, time_col]]
    # 这里确保 value_cols 在原有列序中也存在
    # 如果需要严格控制列顺序，可以手动指定
    result_df = result_df[[col for col in cols if col in result_df.columns]]

    return result_df

    # 合并所有站点插值结果
    result_df = pd.concat(interpolated_dfs)
    result_df = result_df.reset_index().rename(columns={'index': 'time'})

    # 确保列的顺序统一
    result_df = result_df[['station_code', 'time', 'stage', 'flow']]

    return result_df


def fill_missing_data_with_given_values(merged_df, time_points, fill_value=0):
    """
    对每个站点在指定的时间序列内，填充缺失的雨量数据为指定的值（默认为 0）。

    参数：
    - merged_df: DataFrame，包含合并后的站点信息和雨量数据
    - time_points: DatetimeIndex，预先生成的时间点序列
    - fill_value: 要填充的缺失值，默认为 0

    返回：
    - filled_df: DataFrame，填充缺失数据后的完整数据
    """
    # 确保 'time' 列是 datetime 类型
    merged_df['time'] = pd.to_datetime(merged_df['time'])

    # 获取所有站点编码
    station_codes = merged_df['p_station_id'].unique()

    # 创建站点和时间的笛卡尔积
    full_index = pd.MultiIndex.from_product([station_codes, time_points],
                                            names=['p_station_id', 'time'])

    # 创建完整的框架 DataFrame
    full_df = pd.DataFrame(index=full_index).reset_index()

    # 将实际的雨量数据与完整框架合并
    data_df = merged_df[['p_station_id', 'time', 'rainfall']]
    filled_df = pd.merge(full_df, data_df, on=['p_station_id', 'time'], how='left')

    # 填充缺失的雨量值为指定的值
    if fill_value is not None:
        filled_df['rainfall'] = filled_df['rainfall'].fillna(fill_value)

    # 将站点的其他信息合并进来
    station_info = merged_df[['p_station_id', 'p_station_name', 'longitude', 'latitude']].drop_duplicates()
    filled_df = pd.merge(filled_df, station_info, on='p_station_id', how='left')

    return filled_df

