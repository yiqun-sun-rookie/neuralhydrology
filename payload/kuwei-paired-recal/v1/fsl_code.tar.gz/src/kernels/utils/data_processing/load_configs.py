import yaml

def load_configurations():
    """
    统一读取所有的配置文件，包括字段映射、文件路径和模型参数等。

    返回：
    - config: 字典，包含所有的配置项。
    """
    config = {}

    # 读取字段映射配置
    field_mapping_path = "../../../../config/deprecated/field_mapping.yml"
    with open(field_mapping_path, 'r', encoding='utf-8') as file:
        config['field_mapping'] = yaml.safe_load(file)

    # 读取文件路径配置
    file_path_config_path = "../../../../config/deprecated/file_path.yml"
    with open(file_path_config_path, 'r', encoding='utf-8') as file:
        config['file_paths'] = yaml.safe_load(file)

    # 读取水文模型配置
    hydro_model_config_path = "../../../../config/deprecated/hydro_model.yml"
    with open(hydro_model_config_path, 'r', encoding='utf-8') as file:
        config['hydro_model'] = yaml.safe_load(file)

    # 读取数据库配置
    db_config_path = "../../../../config/deprecated/database.yml"
    with open(db_config_path, 'r', encoding='utf-8') as file:
        config['db_config'] = yaml.safe_load(file)

    return config

