import yaml
def load_yaml_configs(config_path):
    with open(config_path, 'r') as file:
        return yaml.safe_load(file)
