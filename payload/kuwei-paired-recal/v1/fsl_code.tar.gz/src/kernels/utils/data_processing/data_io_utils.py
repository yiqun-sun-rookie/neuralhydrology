from netCDF4 import Dataset  # 添加此行，导入 netCDF4 库
import numpy as np
import pandas as pd
import os
def read_state_from_netcdf(time_point, state_names, state_output_dir):
    """
    从给定时间点的 NetCDF 文件中读取模型状态数据。

    参数:
    - time_point: 时间点（字符串或 datetime 对象）
    - state_names: 列表，需要读取的状态变量名称
    - state_output_dir: 状态输出目录，由配置文件提供

    返回:
    - state_df: 包含指定时间点状态数据的 DataFrame，包含 'id', 'longitude', 'latitude' 以及 state_names 中的变量列
    """
    input_filepath = construct_state_output_filepath(time_point, state_output_dir)

    if not os.path.exists(input_filepath):
        raise FileNotFoundError(f"状态文件 {input_filepath} 不存在。")

    # 打开 NetCDF 文件
    with Dataset(input_filepath, 'r') as ncfile:
        # 读取坐标和索引信息
        times_var = ncfile.variables['time']
        ids_var = ncfile.variables['id'][:]
        lons_var = ncfile.variables['longitude'][:]
        lats_var = ncfile.variables['latitude'][:]

        # 将时间转换为 datetime 对象，找到对应时间索引
        times = pd.to_datetime(times_var[:], unit='s', origin=pd.Timestamp('1970-01-01'))
        time_point = pd.to_datetime(time_point)
        time_indices = np.where(times == time_point)[0]
        if len(time_indices) == 0:
            raise ValueError(f"时间点 {time_point} 在文件 {input_filepath} 中不存在。")
        time_index = time_indices[0]

        # 构建 DataFrame
        state_df = pd.DataFrame({
            'id': ids_var,
            'longitude': lons_var,
            'latitude': lats_var
        })

        # 读取每个状态变量的数据
        for var_name in state_names:
            if var_name not in ncfile.variables:
                raise ValueError(f"文件 {input_filepath} 中不存在变量 {var_name}")
            var_data = ncfile.variables[var_name][time_index, :]
            state_df[var_name] = var_data

        # 添加时间列
        state_df['time'] = time_point

    return state_df
def save_state_to_netcdf(state_df, time_point, variable_names, units_dict, long_names_dict, state_output_dir):
    """
    保存模型在每个时间步的状态到 NetCDF 文件。

    参数:
    - state_df: DataFrame，包含模型状态的各个变量
    - time_point: 当前时间点
    - variable_names: 列表，包含需要保存的变量名称
    - units_dict: 字典，键为变量名称，值为单位
    - long_names_dict: 字典，键为变量名称，值为变量的长名称（描述）
    - state_output_dir: 从配置文件读取的状态输出目录
    """
    output_filepath = construct_state_output_filepath(time_point, state_output_dir)

    num_points = state_df['id'].nunique()

    ncfile = Dataset(output_filepath, 'w', format='NETCDF4')

    # 定义维度
    ncfile.createDimension('time', None)
    ncfile.createDimension('points', num_points)

    # 创建坐标变量
    times_var = ncfile.createVariable('time', 'f8', ('time',))
    fid_var = ncfile.createVariable('id', 'i4', ('points',))
    lon_var = ncfile.createVariable('longitude', 'f8', ('points',))
    lat_var = ncfile.createVariable('latitude', 'f8', ('points',))

    # 为每个变量创建数据变量
    data_vars = {}
    for var_name in variable_names:
        data_vars[var_name] = ncfile.createVariable(var_name, 'f8', ('time', 'points'))
        data_vars[var_name].units = units_dict.get(var_name, '')
        data_vars[var_name].long_name = long_names_dict.get(var_name, var_name)

    # 写入时间变量
    times_var[0] = pd.Timestamp(time_point).timestamp()

    # 写入坐标信息
    grid_info = state_df[['id', 'longitude', 'latitude']].drop_duplicates().sort_values('id')
    fid_var[:] = grid_info['id'].values
    lon_var[:] = grid_info['longitude'].values
    lat_var[:] = grid_info['latitude'].values

    # 排序状态数据
    state_df = state_df.sort_values('id').reset_index(drop=True)

    # 写入数据变量
    for var_name in variable_names:
        data_vars[var_name][0, :] = state_df[var_name].values

    # 添加元数据
    times_var.units = 'seconds since 1970-01-01 00:00:00'
    times_var.calendar = 'standard'
    lon_var.units = 'degrees_east'
    lat_var.units = 'degrees_north'

    ncfile.close()
    print(f"State data saved as {output_filepath}")

def construct_state_output_filepath(time_point, state_output_dir):
    """
    构造保存模型状态的文件路径。

    参数:
    - time_point: 时间点
    - state_output_dir: 状态输出目录（来自配置文件）

    返回:
    - 文件路径
    """
    time_point = pd.to_datetime(time_point)
    os.makedirs(state_output_dir, exist_ok=True)

    time_str = time_point.strftime('%Y%m%d%H%M%S')
    output_filename = f'state_{time_str}.nc'
    return os.path.join(state_output_dir, output_filename)

def save_interp_features_to_netcdf(interpolated_results, time_point, variable_name, units, variable_long_name, interpolation_output_dir):
    """
    保存插值结果到 NetCDF 文件。

    参数:
    - interpolated_results: DataFrame，包含插值结果
    - time_point: 时间点
    - variable_name: 数据变量名称
    - units: 数据的单位
    - variable_long_name: 变量的长名称
    - interpolation_output_dir: 插值结果输出目录（来自配置文件）
    """
    output_filepath = construct_interp_features_filepath(time_point, variable_name, interpolation_output_dir)

    times = sorted(interpolated_results['time'].unique())
    num_points = interpolated_results['id'].nunique()

    ncfile = Dataset(output_filepath, 'w', format='NETCDF4')

    # 定义维度
    ncfile.createDimension('time', len(times))
    ncfile.createDimension('points', num_points)

    # 创建变量
    times_var = ncfile.createVariable('time', 'f8', ('time',))
    fid_var = ncfile.createVariable('id', 'i4', ('points',))
    lon_var = ncfile.createVariable('longitude', 'f8', ('points',))
    lat_var = ncfile.createVariable('latitude', 'f8', ('points',))
    data_var = ncfile.createVariable(variable_name, 'f8', ('time', 'points'))

    # 写入数据
    times_var[:] = np.array([pd.Timestamp(t).timestamp() for t in times])
    grid_info = interpolated_results.drop_duplicates('id')[['id', 'longitude', 'latitude']].sort_values('id')
    fid_var[:] = grid_info['id'].values
    lon_var[:] = grid_info['longitude'].values
    lat_var[:] = grid_info['latitude'].values

    data_array = np.zeros((len(times), num_points))
    for idx, tp in enumerate(times):
        time_data = interpolated_results[interpolated_results['time'] == tp].sort_values('id')
        data_array[idx, :] = time_data['target'].values

    data_var[:, :] = data_array

    # 添加元数据
    times_var.units = 'seconds since 1970-01-01 00:00:00'
    times_var.calendar = 'standard'
    lon_var.units = 'degrees_east'
    lat_var.units = 'degrees_north'
    data_var.units = units
    data_var.long_name = variable_long_name

    ncfile.close()
    print(f"Data saved as {output_filepath}")

def read_interp_data_from_netcdf(time_point, variable_name, interp_output_dir):
    """
    读取指定时间点的 NetCDF 文件中的插值数据。

    参数:
    - time_point: 时间点
    - variable_name: 数据变量名称
    - interpolation_output_dir: 插值结果输出目录

    返回:
    - data_df: DataFrame
    """
    input_filepath = construct_interp_features_filepath(time_point, variable_name, interp_output_dir)

    if not os.path.exists(input_filepath):
        raise FileNotFoundError(f"文件 {input_filepath} 不存在。")

    with Dataset(input_filepath, 'r') as ncfile:
        times_var = ncfile.variables['time']
        ids_var = ncfile.variables['id'][:]
        lons_var = ncfile.variables['longitude'][:]
        lats_var = ncfile.variables['latitude'][:]
        data_var = ncfile.variables[variable_name][:]

        times = pd.to_datetime(times_var[:], unit='s', origin=pd.Timestamp('1970-01-01'))
        time_point = pd.to_datetime(time_point)
        time_indices = np.where(times == time_point)[0]

        if len(time_indices) == 0:
            raise ValueError(f"时间点 {time_point} 在文件 {input_filepath} 中不存在。")

        time_index = time_indices[0]
        data_values = data_var[time_index, :]

        data_df = pd.DataFrame({
            'time': time_point,
            'id': ids_var,
            'longitude': lons_var,
            'latitude': lats_var,
            variable_name: data_values
        })

    return data_df

def construct_interp_features_filepath(time_point, feature_name, interpolation_output_dir):
    """
    根据给定的时间点和特征名以及配置中的输出目录构造输出文件路径。

    参数:
    - time_point: 时间点
    - feature_name: 特征名称
    - interpolation_output_dir: 插值结果输出目录（来自配置文件）

    返回:
    - 文件路径
    """
    time_point = pd.to_datetime(time_point)
    date = time_point.date()
    year, month, day = date.strftime('%Y'), date.strftime('%m'), date.strftime('%d')
    output_dir = os.path.join(interpolation_output_dir, feature_name, year, month, day)
    os.makedirs(output_dir, exist_ok=True)

    time_str = time_point.strftime('%Y%m%d%H%M%S')
    output_filename = f'{feature_name}_{time_str}.nc'
    return os.path.join(output_dir, output_filename)
