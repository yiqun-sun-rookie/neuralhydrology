import pandas as pd
import numpy as np
from scipy.spatial.distance import cdist
import geopandas as gpd
import os

def prepare_grid_data(file_path):
    # 读取网格多边形数据
    grids = gpd.read_file(file_path)
    grids['centroid'] = grids.geometry.centroid
    grids['longitude'] = grids['centroid'].x
    grids['latitude'] = grids['centroid'].y
    # 提取格点的唯一标识符和坐标
    if 'id' not in grids.columns:
        grids['id'] = grids.index
    id, xi, yi = grids.index, grids['longitude'].values, grids['latitude'].values
    grids_to_interp = pd.DataFrame({'id': id, 'longitude': xi, 'latitude': yi})
    return grids_to_interp

def spatial_feature_interpolation(observed_points, grids_to_interp, times_to_interp, method='idw', **kwargs):
    """
    Perform spatial feature interpolation using specified method.

    Parameters:
    - observed_points: DataFrame containing the observed data points with coordinates and target values
    - grids_to_interp: DataFrame defining the grid points where interpolation should be performed
    - times_to_interp: Time point for which interpolation is performed
    - method: The interpolation method to use ('idw' for Inverse Distance Weighting initially)
    - kwargs: Additional keyword arguments for the interpolation method

    Returns:
    - results: DataFrame containing interpolated spatial data
    """
    x_obs, y_obs, target_obs = observed_points[['longitude', 'latitude', 'target']].values.T
    id_interp, x_interp, y_interp = grids_to_interp[['id', 'longitude', 'latitude']].values.T

    if method == 'idw':
        targets_interp = idw_interpolation(x_obs, y_obs, target_obs, x_interp, y_interp, **kwargs)
    else:
        raise ValueError(f"Interpolation method '{method}' is not supported.")

    # Create interpolated DataFrame
    results = pd.DataFrame({
        'id': id_interp,
        'longitude': x_interp,
        'latitude': y_interp,
        'target': targets_interp
    })
    results['time'] = times_to_interp
    return results

def interpolate_rainfall_at_time_point(observed_points, grids_to_interp, times_to_interp):
    """
    Perform IDW interpolation for a given time point.

    Returns:
    - results: DataFrame containing interpolated rainfall data
    """
    x_obs, y_obs, targets_obs = observed_points[['longitude', 'latitude', 'targets']].values.T
    id_interp, x_interp, y_interp = grids_to_interp[['id', 'longitude', 'latitude']].values.T
    targets_interp = idw_interpolation(x_obs, y_obs, targets_obs, x_interp, y_interp, power=2)
    # Create interpolated DataFrame
    results = pd.DataFrame({'id': id_interp, 'longitude': x_interp, 'latitude': y_interp, 'targets': targets_interp})
    results['time'] = times_to_interp

    return results
def idw_interpolation(x_obs, y_obs, z_obs, xi, yi, power=2):
    """
    使用反距离加权（IDW）方法进行插值。

    参数：
    - x_obs: ndarray，观测点的经度坐标。
    - y_obs: ndarray，观测点的纬度坐标。
    - z_obs: ndarray，观测点的雨量值。
    - xi: ndarray，插值点的经度坐标。
    - yi: ndarray，插值点的纬度坐标。
    - power: float，IDW 的幂参数。

    返回：
    - zi: ndarray，插值点的雨量值。
    """
    assert len(x_obs) == len(y_obs) == len(z_obs), "观测点的坐标和值数量不一致。"
    assert len(xi) == len(yi), "插值点的坐标数量不一致。"

    # 将坐标组合成数组
    obs_points = np.vstack((x_obs, y_obs)).T
    grid_points = np.vstack((xi, yi)).T

    # 计算距离矩阵
    distances = cdist(grid_points, obs_points, metric='euclidean')

    # 防止距离为零
    distances[distances == 0] = 1e-10

    # 计算权重
    weights = 1 / distances**power
    weights /= weights.sum(axis=1, keepdims=True)

    # 计算插值结果
    zi = np.dot(weights, z_obs)
    return zi

from pykrige.ok import OrdinaryKriging

def kriging_interpolation(x_obs, y_obs, z_obs, xi, yi, variogram_model='linear'):
    """
    使用普通克里金法进行插值。

    参数：
    - x_obs: ndarray，观测点的经度坐标。
    - y_obs: ndarray，观测点的纬度坐标。
    - z_obs: ndarray，观测点的雨量值。
    - xi: ndarray，插值点的经度坐标。
    - yi: ndarray，插值点的纬度坐标。
    - variogram_model: str，变差函数模型。

    返回：
    - zi: ndarray，插值点的雨量值。
    """
    if len(x_obs) < 3:
        print("有效数据点少于 3 个，无法进行克里金插值。")
        return np.full_like(xi, np.nan)

    try:
        # 创建克里金模型
        OK = OrdinaryKriging(
            x_obs, y_obs, z_obs,
            variogram_model=variogram_model,
            verbose=False,
            enable_plotting=False
        )

        # 执行插值
        zi, ss = OK.execute('points', xi, yi)
        zi[zi < 0] = 0
        return zi
    except Exception as e:
        print(f"克里金插值失败：{e}")
        return np.full_like(xi, np.nan)

