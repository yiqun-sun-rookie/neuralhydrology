import numpy as np
def calc_nse(obs, sim):
    mask = ~np.isnan(obs) & ~np.isnan(sim)
    if not np.any(mask):
        return np.nan
    obs_v = obs[mask]
    sim_v = sim[mask]
    denom = np.sum((obs_v - obs_v.mean()) ** 2)
    if denom < 1e-12:
        return np.nan
    numer = np.sum((obs_v - sim_v) ** 2)
    return 1 - numer / denom
