import pyodbc

# 数据库连接信息
server = 'YS-G15'  # 将 YOUR_INSTANCE_NAME 替换为实际的实例名
database = 'xinaj'
driver = 'ODBC Driver 17 for SQL Server'

connection_string = (
    f'DRIVER={{{driver}}};'
    f'SERVER={server};'
    f'DATABASE={database};'
    'Trusted_Connection=yes;'
)
try:
    conn = pyodbc.connect(connection_string)
    print("成功连接到数据库！")
except Exception as e:
    print(f"连接失败: {e}")

