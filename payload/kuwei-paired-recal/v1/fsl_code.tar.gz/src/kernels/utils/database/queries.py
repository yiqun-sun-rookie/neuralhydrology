from src.kernels.database.db_connector import create_database_connection
from config.deprecated.base_config import SHAPEFILE_CONFIG
import pandas as pd
import geopandas as gpd
import os
import logging


def read_section_station_map(db_config, db=None):
    """
    从数据库读取 section_station_map_table 表的信息。
    该表描述了每一个断面（hydro_section_code）对应的水文站点和所使用的雨量站之间的关系。

    参数：
    - db_config: 包含数据库和表配置信息的字典
    - db: 可选的数据库连接对象，如果未提供则内部建立连接。

    返回：
    - DataFrame：包含 hydro_section_code, precipitation_code, precipitation_station_count, hydro_station_code,
      flow_station_code, file_relation, input_area_code, lateral_interval, calculation_method 等列。
    """
    db_info = db_config['database']
    table_info = db_config['section_station_map_table']

    table_name = table_info['table_name']
    field_map = table_info['columns']

    # 如果未传入 db 则创建新连接
    if db is None:
        db = create_database_connection(db_info)

    # 构建查询SQL
    original_cols = list(field_map.values())  # 使用物理列名
    select_clause = ", ".join(original_cols)
    query = f"SELECT {select_clause} FROM {table_name}"

    # 执行查询
    df = db.fetch_data(query)
    db.disconnect()

    # 使用逻辑名重命名
    reverse_map = {v: k for k, v in field_map.items()}
    df = df.rename(columns=reverse_map)

    return df
def read_flood_times_from_db(db_config, db=None):
    """
    从数据库读取洪水时段信息，包括流域代码、洪水编号、开始时间和结束时间。

    参数：
    - db_config: 已加载的配置字典，包含数据库和表的相关信息
    - db: （可选）数据库连接对象。如果未提供，则根据 db_config 创建新的连接。

    返回：
    - DataFrame: 包含 [basin_code, flood_id, start_time, end_time] 列
    """
    db_info = db_config['database']
    table_info = db_config['flood_time_table']

    table_name = table_info['table_name']
    columns_map = table_info['columns']
    # 例如 columns_map = {'basin_code': 'b_code', 'flood_id': 'flcd', 'start_time': 's_dt', 'end_time': 'e_dt'}

    # 如果未传入 db 则创建连接
    if db is None:
        db = create_database_connection(db_info)

    # 使用实际列名构建查询SQL
    original_cols = list(columns_map.values())
    select_clause = ", ".join(original_cols)
    query = f"SELECT {select_clause} FROM {table_name}"

    # 执行查询
    df = db.fetch_data(query)
    db.disconnect()

    # 使用逻辑名重命名
    reverse_map = {v: k for k, v in columns_map.items()}
    df = df.rename(columns=reverse_map)

    return df

def read_stations_from_db(db_config, station_type, db=None):
    """
    从数据库读取雨量站点的名称和编码信息。
    使用 db_config.yml 中的表名和列名信息构建查询，
    并在查询结果中将实际列名重命名为逻辑列名。
    """
    # 1. 加载数据库配置
    db_info = db_config['database']
    # 假设 create_database_connection 函数可接受 db_info 作为参数，具体实现需根据您的代码调整
    if db is None:
        db = create_database_connection(db_info)

    # 判断输入station_type属[于rainfall, hydrologic, evap]中的一个，否则报错
    assert station_type in db_config['station_type'], f"station_type {station_type} 不在配置文件中。"

    station_table_info = db_config['station_info_table'][station_type]
    table_name = station_table_info['table_name']
    columns_map = station_table_info['columns']
    # columns_map 示例: {'station_name': 'p_name', 'station_code': 'out_pcode'}

    # 3. 使用实际数据库列名构建 SQL 查询
    original_cols = list(columns_map.values())
    select_clause = ", ".join(original_cols)
    query = f"SELECT {select_clause} FROM {table_name}"

    # 4. 执行查询
    df_db = db.fetch_data(query)
    db.disconnect()

    # 5. 使用逻辑列名重命名 DataFrame 列
    # 构建 {实际列名: 逻辑列名} 的反向映射
    rename_map = {v: k for k, v in columns_map.items()}
    # 示例: {'p_name': 'station_name', 'out_pcode': 'station_code'}
    df_db = df_db.rename(columns=rename_map)

    return df_db


def fetch_stage_and_flow_from_db(
        start_time,
        end_time,
        station_codes,
        db_config,
        db=None
):
    """
    根据指定的开始和结束时间，获取指定站点的水位(Z)和流量(Q)数据。
    如果查询结果为空，则查询该表的时间覆盖范围，并抛出异常。

    参数：
    - start_time: 开始时间，字符串格式 (例如：'2020-01-01 00:00')
    - end_time: 结束时间，字符串格式 (例如：'2020-01-02 00:00')
    - station_codes: 站点编码列表 (如 ['ST001', 'ST002'])
    - db_config: 数据库配置信息（一个字典），其中：
        * db_config['values_table']['hydrologic'] 中定义了 hydrologic 表相关配置
        * db_config['database'] 中定义了数据库连接信息
    - db: 数据库连接对象（可选）。如果不传，则根据 db_config 创建新连接

    返回：
    - df: pandas.DataFrame，包含列 ['station_code', 'time', 'stage', 'flow']
    """
    # 1. 读取 hydrologic 表配置信息
    hydrologic_config = db_config['values_table']['hydrologic']

    table_name = hydrologic_config['table_name']
    columns_info = hydrologic_config['columns']

    station_code_col = columns_info['station_code']  # 'stcd'
    time_col = columns_info['time']  # 'ymdhm'
    stage_col = columns_info['stage']  # 'z'
    flow_col = columns_info['flow']  # 'q'

    # 如果没有传 db，使用配置创建一个新的数据库连接
    if db is None:
        db_info = db_config['database']  # 假设配置文件中有 'database' 字段存储连接信息
        db = create_database_connection(db_info)

    # 确保 station_codes 非空
    if not station_codes:
        raise ValueError("station_codes should not be empty。")

    # 将 station_codes 转换为适合 SQL IN 的列表字符串
    station_codes_str = ', '.join([f"'{code}'" for code in station_codes])

    # 构建查询语句
    query = f"""
    SELECT 
        {station_code_col} AS station_code,
        {time_col} AS time,
        {stage_col} AS stage,
        {flow_col} AS flow
    FROM {table_name}
    WHERE {time_col} >= '{start_time}'
      AND {time_col} <= '{end_time}'
      AND {station_code_col} IN ({station_codes_str})
    """

    # 执行查询
    df = db.fetch_data(query)

    # 如果查询结果为空，则去数据库中检查该表的整体时间覆盖范围
    if df.empty:
        coverage_query = f"""
        SELECT 
            MIN({time_col}) AS min_time, 
            MAX({time_col}) AS max_time
        FROM {table_name}
        """
        coverage_df = db.fetch_data(coverage_query)

        # 理论上 coverage_df 应该只返回一行，包含 min_time 和 max_time
        if not coverage_df.empty:
            min_time_in_db = coverage_df['min_time'].iloc[0]
            max_time_in_db = coverage_df['max_time'].iloc[0]
            db.disconnect()

            raise ValueError(
                f"在表 {table_name} 中，"
                f"从 '{start_time}' 到 '{end_time}' 之间无数据。\n"
                f"该表的时间覆盖范围为：{min_time_in_db} 至 {max_time_in_db}。"
            )
        else:
            # 如果 coverage_df 也为空，表示这个表本身就没有任何数据
            db.disconnect()
            raise ValueError(f"表 {table_name} 中没有任何记录，请检查数据源。")

    # 若 df 不为空，最后断开连接并返回结果
    db.disconnect()
    return df


def read_rain_gauge_from_db(db_config, db=None):
    """
    从数据库读取雨量站点的名称和编码信息。

    参数：
    - db: 数据库连接对象（可选，如果不提供则函数内部创建连接）

    返回：
    - df_db: DataFrame，包含 'p_name' 和 'out_pcode' 列
    """
    db_info = db_config['database']
    if db is None:
        db = create_database_connection(db_info)
    query = "SELECT p_name, out_pcode FROM dbo.rain_gauge"
    df_db = db.fetch_data(query)
    db.disconnect()
    return df_db

def read_rain_gauge_from_shapefile():
    """
    从 Shapefile 中读取雨量站点的位置信息（longitude, latitude）。

    返回：
    - station_gdf: GeoDataFrame，至少包含 'out_pcode', 'longitude', 'latitude' 列
    """
    current_dir = os.path.dirname(os.path.abspath(__file__))  # 当前脚本目录
    project_root = os.path.dirname(current_dir)  # 项目根目录
    station_shapefile_path = os.path.join(project_root, SHAPEFILE_CONFIG['rain_station_path'])
    station_gdf = gpd.read_file(station_shapefile_path)

    if 'out_pcode' not in station_gdf.columns:
        raise ValueError("Shapefile 缺少 'out_pcode' 字段，无法与数据库数据合并。")

    # 提取经纬度
    station_gdf['longitude'] = station_gdf.geometry.x
    station_gdf['latitude'] = station_gdf.geometry.y

    # 保留必要列
    station_gdf = station_gdf[['out_pcode', 'longitude', 'latitude']]
    return station_gdf

def merge_and_validate_rain_gauges(df_db, station_gdf):
    """
    将数据库中雨量站点的信息与 Shapefile 中的位置信息进行匹配、标准化和验证。
    如果发现不匹配的站点，记录到日志中，并仅保留公共部分。

    参数：
    - df_db: 来自数据库的站点信息 DataFrame，包含 'p_name', 'out_pcode'
    - station_gdf: 来自 Shapefile 的站点信息 GeoDataFrame，包含 'out_pcode', 'longitude', 'latitude'

    返回：
    - df: DataFrame，包含最终匹配成功的站点信息，列有 'p_name', 'out_pcode', 'longitude', 'latitude'
    """
    # 设置日志记录
    logging.basicConfig(filename='data_mismatch.log', level=logging.INFO,
                        format='%(asctime)s - %(levelname)s - %(message)s')

    # 标准化 out_pcode
    df_db['out_pcode'] = df_db['out_pcode'].astype(str).str.strip().str.upper()
    station_gdf['out_pcode'] = station_gdf['out_pcode'].astype(str).str.strip().str.upper()

    # 对比
    db_station_codes = set(df_db['out_pcode'])
    gis_station_codes = set(station_gdf['out_pcode'])

    db_not_in_gis = db_station_codes - gis_station_codes
    if db_not_in_gis:
        logging.info(f"以下站点在数据库中存在，但在 GIS 数据中缺失：{db_not_in_gis}")

    gis_not_in_db = gis_station_codes - db_station_codes
    if gis_not_in_db:
        logging.info(f"以下站点在 GIS 数据中存在，但在数据库中缺失：{gis_not_in_db}")

    # 保留公共部分
    common_station_codes = db_station_codes & gis_station_codes
    df_db = df_db[df_db['out_pcode'].isin(common_station_codes)].reset_index(drop=True)
    station_gdf = station_gdf[station_gdf['out_pcode'].isin(common_station_codes)].reset_index(drop=True)

    # 合并数据库与GIS信息
    df = pd.merge(df_db, station_gdf, on='out_pcode', how='inner')

    # 检查是否有未匹配位置信息的站点
    missing_location = df[df['longitude'].isnull() | df['latitude'].isnull()]
    if not missing_location.empty:
        logging.warning("以下站点未匹配到位置信息：")
        logging.warning(missing_location[['p_name', 'out_pcode']])

    logging.info("雨量站点信息获取成功！")
    return df

# 使用示例
def fetch_rain_gauge_infor_from_db(db_config, db=None):
    """
    原函数拆分后的整合函数：
    - 调用 read_rain_gauge_from_db 获取数据库信息
    - 调用 read_rain_gauge_from_shapefile 获取 shapefile_path 位置信息
    - 调用 merge_and_validate_rain_gauges 进行数据匹配和验证
    """
    df_db = read_rain_gauge_from_db(db_config)
    station_gdf = read_rain_gauge_from_shapefile()
    df = merge_and_validate_rain_gauges(df_db, station_gdf)
    return df


def fetch_real_time_rainfall(start_time, end_time, station_codes, db=None):
    """
    根据指定的开始和结束时间，获取指定站点的实时雨量数据。

    参数：
    - start_time: 开始时间，字符串格式
    - end_time: 结束时间，字符串格式
    - station_codes: 站点编码列表（来自 rain_stations['rain_station_id']）
    - db: 数据库连接对象（可选）

    返回：
    - DataFrame，包含站点编码、雨量值和时间
    """
    if db is None:
        db = create_database_connection()

    # 确保站点编码列表不为空，直接报错
    if not station_codes:
        raise ValueError("station_codes should not be empty。")

    # 将站点编码列表转换为字符串，用于 SQL 查询
    # 注意，这里直接拼接字符串存在 SQL 注入风险，后续版本应使用参数化查询
    station_codes_str = ', '.join([f"'{code}'" for code in station_codes])

    # 构建查询语句
    query = f"""
    SELECT STCD, DTRN, YMDHM
    FROM dbo.st_rnfl_r
    WHERE YMDHM >= '{start_time}' AND YMDHM <= '{end_time}'
      AND STCD IN ({station_codes_str})
    """

    df = db.fetch_data(query)
    db.disconnect()
    return df


# gis_processors/data_processing.py

def merge_rainfall_with_stations(rain_gauge_df, rainfall_df):
    """
    将雨量站点信息与雨量数据合并。

    参数：
    - rain_gauge_df: DataFrame，站点信息，包括'out_pcode'等字段
    - rainfall_df: DataFrame，雨量数据，包括'STCD'等字段

    返回：
    - merged_df: DataFrame，合并后的数据
    """
    # 从 rain_gauge_df 中选择左边的列
    left_df = rain_gauge_df[['p_station_name', 'p_station_id', 'longitude', 'latitude']].copy()

    # 从 rainfall_df 中选择右边的列
    right_df = rainfall_df[['time', 'p_station_id', 'rainfall']].copy()

    # 2. 确保合并键的一致性
    # 去除空格，统一大小写，转换为字符串类型
    left_df['p_station_id'] = left_df['p_station_id'].astype(str).str.strip().str.upper()
    right_df['p_station_id'] = right_df['p_station_id'].astype(str).str.strip().str.upper()

    # 3. 执行合并
    merged_df = pd.merge(left_df, right_df, on='p_station_id', how='left')

    # 4. 识别没有雨量数据的站点
    missing_stations = merged_df[merged_df['rainfall'].isnull()]

    # 5. 打印缺失数据的站点信息
    if not missing_stations.empty:
        print("以下站点在指定时间范围内没有雨量数据：")
        print(missing_stations[['p_station_name', 'p_station_id']])
    else:
        print("所有站点在指定时间范围内都有雨量数据。")

    return merged_df


