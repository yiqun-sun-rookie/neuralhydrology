import pyodbc
import pymysql
import psycopg2
import pandas as pd
class DatabaseConnector:
    def __init__(self, db_type, server, database, username=None, password=None, driver=None):
        """
        初始化数据库连接器。

        参数：
        - db_type: 数据库类型，如 'sqlserver', 'mysql', 'postgresql'
        - server: 服务器地址
        - database: 数据库名称
        - username: 用户名（可选）
        - password: 密码（可选）
        - driver: 驱动名称（可选，仅用于 SQL Server）
        """
        self.db_type = db_type.lower()
        self.server = server
        self.database = database
        self.username = username
        self.password = password
        self.driver = driver
        self.conn = None  # 数据库连接对象

    def connect(self):
        """建立数据库连接。"""
        try:
            if self.db_type == 'sqlserver':
                if self.driver is None:
                    self.driver = 'ODBC Driver 17 for SQL Server'
                if self.username and self.password:
                    # 使用 SQL Server 身份验证
                    connection_string = (
                        f'DRIVER={{{self.driver}}};'
                        f'SERVER={self.server};'
                        f'DATABASE={self.database};'
                        f'UID={self.username};'
                        f'PWD={self.password};'
                    )
                else:
                    # 使用 Windows 身份验证
                    connection_string = (
                        f'DRIVER={{{self.driver}}};'
                        f'SERVER={self.server};'
                        f'DATABASE={self.database};'
                        'Trusted_Connection=yes;'
                    )
                self.conn = pyodbc.connect(connection_string)
            elif self.db_type == 'mysql':
                self.conn = pymysql.connect(
                    host=self.server,
                    user=self.username,
                    password=self.password,
                    database=self.database
                )
            elif self.db_type == 'postgresql':
                self.conn = psycopg2.connect(
                    host=self.server,
                    user=self.username,
                    password=self.password,
                    database=self.database
                )
            else:
                raise ValueError("Unsupported database type")
            print("Successfully connected to the database!")
        except Exception as e:
            print("Connection failed:", e)

    def disconnect(self):
        """关闭数据库连接。"""
        if self.conn:
            self.conn.close()
            print("Database connection has been closed.")

    def fetch_data(self, query):
        """
        执行查询并返回数据。

        参数：
        - query: SQL 查询语句

        返回：
        - DataFrame，查询结果
        """
        try:
            df = pd.read_sql(query, self.conn)
            return df
        except Exception as e:
            print("查询失败:", e)
            return pd.DataFrame()


def create_database_connection(db_config):
    """
    从 db_config 字典中提取连接信息创建连接对象。
    """
    db = DatabaseConnector(
        db_type=db_config['db_type'],
        server=db_config['server'],
        database=db_config['database'],
        driver=db_config.get('driver'),
        username=db_config.get('username'),
        password=db_config.get('password')
    )
    db.connect()
    return db
