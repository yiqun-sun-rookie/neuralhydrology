import pandas as pd
def conditional_resample_by_station(df, time_col='time', id_col='station_code', freq='1H', agg='mean', value_cols=None):
    """
    对包含多个站点的DataFrame进行条件性重采样。
    对每个站点（由id_col分组）进行以下操作：
    - 保留原本在整点上的数据点（无需重采样）
    - 对非整点的数据点按freq重采样，并使用agg对指定的value_cols进行聚合
    最终将各站点的结果合并。

    参数：
    - df: 原始DataFrame，包含 time_col 和 id_col。
    - time_col (str): 时间列列名。
    - id_col (str): 用于分组的ID列名（如 'station_code'）。
    - freq (str): 重采样频率，如 '1H'。
    - agg: 聚合函数或函数名，如 'mean'、'sum'等，或字典 {col: func, ...}。
    - value_cols (list或None): 需要重采样的列名列表。如果为None则对所有数值列进行重采样。

    返回：
    - combined_all: 将所有站点重采样后的结果合并的 DataFrame，
      包含 time_col、id_col 和需要重采样的 value_cols。
    """

    if not pd.api.types.is_datetime64_any_dtype(df[time_col]):
        df[time_col] = pd.to_datetime(df[time_col])

    # 如果用户未指定 value_cols，则默认对数值列进行处理
    if value_cols is None:
        # 排除 time_col 和 id_col 后，对数值列进行识别
        numeric_cols = df.select_dtypes(include=[float, int]).columns.tolist()
        # 移除id_col和time_col，剩下的就都是可重采样的数值列
        value_cols = [c for c in numeric_cols if c not in [time_col, id_col]]

    def is_exact_hour(dt):
        return (dt.minute == 0) and (dt.second == 0) and (dt.microsecond == 0)

    group_results = []

    # 按id_col分组，对每个站点独立处理
    for g_id, df_group in df.groupby(id_col):
        df_group = df_group.sort_values(time_col).copy()
        df_group.set_index(time_col, inplace=True)

        exact_hour_mask = df_group.index.map(is_exact_hour)
        df_exact = df_group[exact_hour_mask].copy()
        df_non_exact = df_group[~exact_hour_mask].copy()

        if not df_non_exact.empty:
            df_resampled = df_non_exact[value_cols].resample(freq).agg(agg)
        else:
            df_resampled = pd.DataFrame(columns=value_cols)

        # 对整点数据，仅保留需要的列
        # 但我们还需要在结果中保留id_col信息，所以在恢复时手动加回去
        df_exact_val = df_exact[value_cols]

        # 合并整点数据和重采样数据
        combined = pd.concat([df_exact_val, df_resampled])
        combined = combined[~combined.index.duplicated(keep='first')]
        combined = combined.sort_index().reset_index().rename(columns={'index': time_col})

        # 给合并后的数据加上id_col
        combined[id_col] = g_id

        # 将列顺序整理一下，将id_col和time_col放前面
        ordered_cols = [id_col, time_col] + [col for col in combined.columns if col not in [id_col, time_col]]
        combined = combined[ordered_cols]

        group_results.append(combined)

    # 合并所有站点的结果
    combined_all = pd.concat(group_results, ignore_index=True)
    return combined_all
