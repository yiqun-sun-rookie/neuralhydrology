from src.kernels.utils.data_preprocessors.time_series_resampler import conditional_resample_by_station
from src.kernels.utils.data_preprocessors.time_series_interpolator import interpolate_missing_data
from src.kernels.utils.data_preprocessors.time_series_resampler import conditional_resample_by_station
from src.kernels.utils.data_preprocessors.time_series_interpolator import interpolate_missing_data
import pandas as pd

def process_time_series_data(
        df,
        data_type,
        start_time=None,       # <-- 新增，可指定开始、结束时间
        end_time=None,         # <-- 如果不传，就从 df 中自动推断
        time_col='time',
        id_col='station_code',
        freq='1H'
):
    """
    根据 data_type (如 'rainfall', 'evap', 'flow', 'stage') 决定重采样聚合函数，
    并对重采样后数据进行相应插值或填充。相比原版，新增逻辑：先生成完整时间轴并合并。

    参数:
    - df: 原始数据 DataFrame，至少包含 time_col, id_col, 以及待重采样的数值列
    - data_type: 字符串，表示数据类型，比如 'rainfall', 'evap', 'flow', 'stage' 等
    - start_time: (可选) 字符串或 datetime，处理数据的开始时间
    - end_time: (可选) 字符串或 datetime，处理数据的结束时间
    - time_col: 时间列列名
    - id_col: 分组列名 (站点、断面等)
    - freq: 重采样频率，如 '1H'

    返回:
    - proc_df: 处理后的 DataFrame，已经在 [start_time, end_time] 上对齐到 freq 频率，并插值/填充完毕
    """

    # 0) 若 time_col 非 datetime，先转为 datetime
    if not pd.api.types.is_datetime64_any_dtype(df[time_col]):
        df[time_col] = pd.to_datetime(df[time_col])

    # 若未指定 start_time, end_time，则从 df 中推断最小、最大时间
    if start_time is None:
        start_time = df[time_col].min()
    if end_time is None:
        end_time = df[time_col].max()

    # 将其转为 Timestamp，若已是 datetime 则无影响
    start_time = pd.to_datetime(start_time)
    end_time = pd.to_datetime(end_time)

    # 1) 根据 data_type 决定聚合函数 aggregator
    if data_type in ['rainfall', 'evap']:
        aggregator = 'sum'
    else:
        # 默认对 flow, stage 等用 mean
        aggregator = 'mean'

    # 2) 先为每个 station_code + [start_time, end_time] 之间 freq 步长，生成完整时间点
    #    确保每个站点、每个时刻(整点)都有一条记录。
    station_codes = df[id_col].unique().tolist()
    time_index = pd.date_range(start_time, end_time, freq=freq)

    # 用 MultiIndex.from_product 生成 (station_code, time) 笛卡尔积
    full_idx = pd.MultiIndex.from_product(
        [station_codes, time_index],
        names=[id_col, time_col]
    )
    df_full = pd.DataFrame(index=full_idx).reset_index()
    # 结果 df_full 会有列 [id_col, time_col]，每个站点在每个时间点一行

    # 与原始数据 df 做合并（left merge），确保所有时间点都出现
    # 原 df 里没有值的时刻 => NaN
    df_merged = pd.merge(df_full, df, on=[id_col, time_col], how='left')

    # 3) 调用条件性重采样
    #    注意：df_merged 里已经保证每个时刻都有1行，但可能有 NaN
    #    conditional_resample_by_station 内部会对“非整点”再进行聚合
    resampled_df = conditional_resample_by_station(
        df_merged,
        time_col=time_col,
        id_col=id_col,
        freq=freq,
        agg=aggregator
        # value_cols=... # 若要指定特定列
    )

    # 4) 最后对重采样后的结果做插值或填充
    if data_type == 'rainfall':
        # 对雨量或蒸发数据，用 fillna(0) 代表无雨量 / 无蒸发
        for col in resampled_df.columns:
            if col not in [time_col, id_col]:
                resampled_df[col] = resampled_df[col].fillna(0)
        proc_df = resampled_df
    elif data_type == 'evap':
        # 对蒸发数据，假设每日蒸发量均匀分配到24小时
        # 需要先将数据按日汇总，然后除以24，赋值给每个小时
        resampled_df = resampled_df.sort_values([id_col, time_col])

        # 提取日期部分
        resampled_df['date'] = resampled_df[time_col].dt.floor('D')

        # 按站点和日期分组，计算每日蒸发量
        # 假设每日只有一个蒸发值，因此使用 first() 提取
        evap_cols = [c for c in resampled_df.columns if c not in [time_col, id_col, 'date']]
        daily_evap = resampled_df.groupby([id_col, 'date'])[evap_cols].first().reset_index()

        # 确保蒸发量列为 float 类型并进行均分
        daily_evap[evap_cols] = daily_evap[evap_cols].astype(float).div(24.0)

        # Merge back到原始的 resampled_df
        evap_hourly = pd.merge(
            resampled_df[[id_col, time_col, 'date']],
            daily_evap,
            on=[id_col, 'date'],
            how='left'
        ).drop(columns='date')

        # 替换原有的 evap 列
        for col in evap_cols:
            resampled_df[col] = evap_hourly[col]

        # 填充开始和结束的缺失值，使用 transform 代替 apply
        resampled_df = resampled_df.sort_values([id_col, time_col])
        for col in evap_cols:
            resampled_df[col] = resampled_df.groupby(id_col)[col].transform(
                lambda group: group.fillna(method='ffill').fillna(method='bfill')
            )

        # 如果仍有缺失值（例如整个时间序列都缺失），可以选择填充为0或其他值
        resampled_df[evap_cols] = resampled_df[evap_cols].fillna(0)

        # 移除临时的 'date' 列
        resampled_df = resampled_df.drop(columns=['date'])

        proc_df = resampled_df
    else:
        # 对 flow 或 stage 等，用 linear 插值
        value_cols = [c for c in resampled_df.columns if c not in [time_col, id_col]]
        proc_df = interpolate_missing_data(
            resampled_df,
            time_col=time_col,
            id_col=id_col,
            value_cols=value_cols,
            method='linear'
        )

    return proc_df

