import pandas as pd
def interpolate_missing_data(df, time_col, id_col, value_cols, method='linear'):
    if not pd.api.types.is_datetime64_any_dtype(df[time_col]):
        df[time_col] = pd.to_datetime(df[time_col])
    df = df.sort_values([id_col, time_col])

    # 先将 value_cols 中的列强制转为数值，如果有无法解析的，设为 NaN
    df[value_cols] = df[value_cols].apply(pd.to_numeric, errors='coerce')

    # 首先检查是否有缺失值
    if not df[value_cols].isnull().any().any():
        # 如果没有空值，则直接返回 df，不进行插值
        return df

    # 如果仍有空值，才进行插值
    df = df.groupby(id_col, group_keys=False).apply(
        lambda g: g.set_index(time_col)[value_cols].interpolate(method=method, limit_direction='both').reset_index()
    )

    return df
