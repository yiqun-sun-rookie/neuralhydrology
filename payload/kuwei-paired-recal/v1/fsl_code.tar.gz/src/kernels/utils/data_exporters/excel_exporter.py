import os
import pandas as pd
from datetime import datetime
def export_flood_data_to_excel(
        section_code: str,
        start_time: str,
        end_time: str,
        rainfall_df: pd.DataFrame,
        evaporation_df: pd.DataFrame,
        inflow_df: pd.DataFrame,
        stage_flow_df: pd.DataFrame,
        output_dir: str = ".",
        initial_conditions_df: pd.DataFrame = None
):
    """
    将同一个断面、同一个洪水场次(start_time ~ end_time)下的所有数据
    (雨量、蒸发、入流、水位、流量) 按照要求合并成一个 DataFrame，并写入 Excel。

    - Excel 文件名： <section_code>.xlsx
    - Sheet 名： 由 start_time 与 end_time 的日期(去掉冒号等不合法字符)拼成
    - 数据列顺序： time -> p_xxx -> e_xxx -> inflow_xxx -> z_xxx -> q_xxx

    参数：
    - section_code: 断面代号，如 "42101"
    - start_time, end_time: 洪水场次起止时间(字符串，如 '2020-01-01 00:00')
    - rainfall_df: 雨量数据，需包含列 ['time', 'station_code'(或别名), 'rainfall']。
    - evaporation_df: 蒸发数据(如果有)，包含 ['time', 'station_code', 'evap']。
    - inflow_df: 入流数据(如果有)，包含 ['time', 'station_code', 'flow'] 或命名类似。
    - stage_flow_df: 水位/流量数据，包含 ['time', 'station_code', 'stage', 'flow']。
    - output_dir: 输出目录，默认为当前目录 "."

    返回：
    - 无返回，直接写出 Excel 文件：
        <output_dir>/<section_code>.xlsx
      并新增/覆盖一个 Sheet(名称形如 '2020-01-01_00_00_2020-01-02_00_00')。
    """

    # 0. 构建 Sheet 名（去掉冒号、空格等不合法字符）
    #    比如 "2020-01-01 00:00" -> "2020-01-01_00_00"
    def sanitize_time_str(t_str):
        return t_str.replace(":", "_").replace(" ", "_").replace("-", "_")

    start_dt = pd.to_datetime(start_time).strftime('%Y_%m_%d')
    end_dt = pd.to_datetime(end_time).strftime('%Y_%m_%d')
    sheet_name = f"{sanitize_time_str(start_dt)}_{sanitize_time_str(end_dt)}"
    #
    # sheet_name = f"{sanitize_time_str(start_time)}_{sanitize_time_str(end_time)}"

    # 1. 收集所有时间点，以免有的 df 没有某些时刻
    #    做一个时间的 “并集” 或 “全连接”。
    #    先把所有 df 统一一下列名再合并更方便
    #    但这里演示用拼接 approach

    all_time_sets = []
    for df_temp in [rainfall_df, evaporation_df, inflow_df, stage_flow_df]:
        if df_temp is not None and not df_temp.empty:
            all_time_sets.append(pd.to_datetime(df_temp['time']).unique())

    if not all_time_sets:
        print(f"[export_flood_data_by_section] 所有数据都为空，跳过断面：{section_code}")
        return

    # 取并集
    unified_times = pd.to_datetime(sorted(set().union(*all_time_sets)))

    # 构建一个初始 DataFrame，以 time 为索引或列
    final_df = pd.DataFrame({"time": unified_times})

    # 2. 处理雨量 (rainfall_df)
    #    - 每个 station_code 对应一列 p_<station_code>
    #    - 按 time 对齐
    if rainfall_df is not None and not rainfall_df.empty:
        # 确保 time 为 datetime
        rainfall_df['time'] = pd.to_datetime(rainfall_df['time'])
        for st_code in rainfall_df['rainfall_station_code'].unique():
            df_st = rainfall_df[rainfall_df['rainfall_station_code'] == st_code].copy()
            df_st = df_st[['time', 'rainfall']].drop_duplicates(subset='time')
            df_st.set_index('time', inplace=True)
            col_name = f"rain_{st_code}"
            final_df = pd.merge(
                final_df,
                df_st.rename(columns={'rainfall': col_name}),
                how='left',
                left_on='time',
                right_index=True
            )

    # 3. 处理蒸发 (evaporation_df)
    #    - 每个 station_code 对应一列 e_<station_code>
    if evaporation_df is not None and not evaporation_df.empty:
        evaporation_df['time'] = pd.to_datetime(evaporation_df['time'])
        for st_code in evaporation_df['evaporation_station_code'].unique():
            df_st = evaporation_df[evaporation_df['evaporation_station_code'] == st_code].copy()
            df_st = df_st[['time', 'evap']].drop_duplicates(subset='time')
            df_st.set_index('time', inplace=True)
            col_name = f"e_{st_code}"
            final_df = pd.merge(
                final_df,
                df_st.rename(columns={'evap': col_name}),
                how='left',
                left_on='time',
                right_index=True
            )

    # 4. 处理入流 inflow_df
    #    - 每个 station_code 对应一列 inflow_<station_code>
    if inflow_df is not None and not inflow_df.empty:
        inflow_df['time'] = pd.to_datetime(inflow_df['time'])
        for st_code in inflow_df['station_code'].unique():
            df_st = inflow_df[inflow_df['station_code'] == st_code].copy()
            # 假设入流数据列名是 'flow'，如 fetch_stage_and_flow 取回的
            df_st = df_st[['time', 'flow']].drop_duplicates(subset='time')
            df_st.set_index('time', inplace=True)
            col_name = f"inflow_{st_code}"
            final_df = pd.merge(
                final_df,
                df_st.rename(columns={'flow': col_name}),
                how='left',
                left_on='time',
                right_index=True
            )

    # 5. 处理水位/流量 (stage_flow_df)
    #    - stage 对应 z_<station_code>
    #    - flow  对应 q_<station_code>
    if stage_flow_df is not None and not stage_flow_df.empty:
        stage_flow_df['time'] = pd.to_datetime(stage_flow_df['time'])
        ##############
        if 'hydrologic_station_code' not in stage_flow_df.columns:
            # 这里可以直接抛出 KeyError 或其它异常类型
            raise KeyError(
                f"[export_flood_data_by_section] "
                f"断面 {section_code} 的 stage_flow_df 不包含 'hydrologic_station_code' 列，无法后续处理。"
            )
        for st_code in stage_flow_df['hydrologic_station_code'].unique():
            df_st = stage_flow_df[stage_flow_df['hydrologic_station_code'] == st_code].copy()
            df_st = df_st[['time', 'stage', 'flow']].drop_duplicates(subset='time')
            df_st.set_index('time', inplace=True)

            col_stage = f"z_{st_code}"
            col_flow = f"q_{st_code}"

            df_st.rename(columns={
                'stage': col_stage,
                'flow': col_flow
            }, inplace=True)

            final_df = pd.merge(
                final_df,
                df_st[[col_stage, col_flow]],
                how='left',
                left_on='time',
                right_index=True
            )

    # 6. 写出到 Excel
    excel_path = os.path.join(output_dir, f"{section_code}.xlsx")

    # 最后 sort_values，以防时间打乱
    final_df = final_df.sort_values('time').reset_index(drop=True)

    # 将 'time' 列放在第一列(保留现在即可，一般它已在第一列)
    # 你也可对其他列顺序做精细化，如果有强需求的话
    # 检查文件是否存在，决定使用 'w' 还是 'a'
    file_exists = os.path.isfile(excel_path)
    if not file_exists:
        mode = 'w'
        with pd.ExcelWriter(excel_path, engine='openpyxl', mode=mode) as writer:
            final_df.to_excel(writer, sheet_name=sheet_name, index=False)
    else:
        mode = 'a'
        with pd.ExcelWriter(excel_path, engine='openpyxl', mode=mode, if_sheet_exists='replace') as writer:
            final_df.to_excel(writer, sheet_name=sheet_name, index=False)

    print(f"[export_flood_data_by_section] 写出到: {excel_path}, Sheet: {sheet_name}, mode={mode}")
    # 7. 如果提供了初始条件数据，则写入单独的 Excel 文件 (<section_code>_initial_conditions.xlsx)
    if initial_conditions_df is not None and not initial_conditions_df.empty:
        # 为初始条件数据增加洪水场次标识（例如 start_time 与 end_time）
        initial_conditions_df = initial_conditions_df.copy()
        initial_conditions_df['start_time'] = start_time
        initial_conditions_df['end_time'] = end_time

        init_excel_path = os.path.join(output_dir, f"{section_code}_initial_conditions.xlsx")
        sheet_init = "initial_conditions"

        # 如果文件存在，则读取已有数据并追加
        if os.path.isfile(init_excel_path):
            try:
                existing_init = pd.read_excel(init_excel_path, sheet_name=sheet_init)
                combined_init = pd.concat([existing_init, initial_conditions_df], ignore_index=True)
            except Exception as e:
                print(f"[export_flood_data_by_section] 读取已有初始条件数据失败: {e}")
                combined_init = initial_conditions_df
        else:
            combined_init = initial_conditions_df

        # 写出（覆盖）整个初始条件 sheet
        with pd.ExcelWriter(init_excel_path, engine='openpyxl', mode='w') as writer:
            combined_init.to_excel(writer, sheet_name=sheet_init, index=False)
        print(f"[export_flood_data_by_section] 初始条件数据写出到: {init_excel_path}, Sheet: {sheet_init}")


    return final_df

