from src.kernels.utils.db_data_fetchers.rainfall_fetcher import fetch_rainfall
from src.kernels.utils.db_data_fetchers.evap_fetcher import fetch_evap
from src.kernels.utils.db_data_fetchers.stage_flow_fetcher import fetch_stage_and_flow
from src.kernels.utils.db_data_fetchers.station_code_mapping import map_station_code
from src.kernels.utils.db_data_fetchers.initial_conditions_fetcher import fetch_initial_values
import pandas as pd
def extract_flood_data_for_section(section_code, evap_code, start_time, end_time,
                                  section_station_mapping, db_config):
    """
    根据断面ID、时间范围，自动获取雨量站、观测流量/水位站、入流站等编码，
    分别调用 fetch_rainfall 和 fetch_stage_and_flow 获取数据并整合。

    参数：
    - hs_code: str，需要预报的断面ID（如 'HS001'）
    - start_time: str，开始时间 (例如 '2020-01-01 00:00')
    - end_time: str，结束时间   (例如 '2020-01-02 00:00')
    - section_station_mapping: DataFrame，断面与站点对应表，至少包含
         ['hydro_section_code', 'rainfall_station_code', 'hydrologic_station_code', 'hydrologic_station_code', 'inp_code']
    - db_config: dict，数据库连接和表配置信息

    返回：
    - result_dict: dict，包含雨量、观测流量/水位、入流等多个 DataFrame，
                   形如 {
                     "rainfall_df": <DataFrame>,
                     "stage_flow_df": <DataFrame>,
                     "stage_obs_df": <DataFrame>,
                     "inflow_df": <DataFrame>
                   }
    """

    # 1. 找到该断面的映射行。如果一个断面对应多行(多套站点)，可自行决定用哪一条或合并。
    # section_station_mapping['hydro_section_code']
    subset = section_station_mapping[
        section_station_mapping['hydro_section_code'].astype(str) == section_code
        ]
    if subset.empty:
        raise ValueError(f"在 section_station_mapping 中未找到断面 {section_code} 的映射信息。")

    # -- (A) 多个雨量站处理 --
    # 收集所有行里的 rainfall_station_code，并去重
    rainfall_codes_raw = subset['rainfall_station_code'].dropna().unique().tolist()
    rainfall_dfs = []
    for raw_code in rainfall_codes_raw:
        raw_str = str(raw_code).strip()
        if not raw_str:
            continue
        # 如果某些流域需要映射雨量站码，就用 map_station_code(station_type='rainfall')
        real_rain_code = map_station_code(raw_str, station_type='rainfall', db_config=db_config)
        # 调 fetch_rainfall 读出此雨量站的数据
        df_rain = fetch_rainfall(start_time, end_time, [real_rain_code], db_config)
        if df_rain is not None and not df_rain.empty:
            # 也可以加一列标识该站点
            df_rain['rainfall_station_code'] = real_rain_code
            rainfall_dfs.append(df_rain)

    # 合并所有雨量站的数据
    if rainfall_dfs:
        rainfall_df = pd.concat(rainfall_dfs, ignore_index=True)
    else:
        rainfall_df = None
        print(f"断面 {section_code} 未找到任何有效的雨量站数据。")

    # -- (B) 观测水位流量站 (这里假设只有一个，取 p_number 最大的行)
    subset_for_flow = subset.dropna(subset=['rainfall_station_count'], how='any', axis=0)
    if subset_for_flow.empty:
        raise ValueError(f"断面 {section_code} 的 rainfall_station_count 数据为空，无法选择流量站。")
    # 找到 p_number 最大的行
    max_p_row = subset_for_flow.loc[subset_for_flow['rainfall_station_count'].idxmax()]
    hydrologic_station_code = str(max_p_row['hydrologic_station_code']).strip()
    if not hydrologic_station_code:
        raise ValueError(f"断面 {section_code} 未配置 hydrologic_station_code，无法读取观测流量数据。")
    #

    real_hydrologic_station_code = map_station_code(hydrologic_station_code, station_type='hydrologic', db_config=db_config)
    stage_flow_df = fetch_stage_and_flow(start_time, end_time, [real_hydrologic_station_code], db_config)

    # -- (D) 多个入流站处理 --
    inp_codes_raw = subset['input_section_code'].dropna().unique().tolist()
    inflow_dfs = []
    for raw_inp in inp_codes_raw:
        inp_str = str(raw_inp).strip()
        # 如果 inp_code 为 '0' 或空，则跳过 (视你的业务需求而定)
        if not inp_str or inp_str == '0':
            continue
        # 如果入流也使用 hydrologic 的映射规则，可以写 station_type='hydrologic'
        real_inp_code = map_station_code(inp_str, station_type='hydrologic', db_config=db_config)
        df_inp = fetch_stage_and_flow(start_time, end_time, [real_inp_code], db_config)
        if df_inp is not None and not df_inp.empty:
            df_inp['input_station_code'] = real_inp_code
            inflow_dfs.append(df_inp)

    if inflow_dfs:
        inflow_df = pd.concat(inflow_dfs, ignore_index=True)
    else:
        inflow_df = None
        print(f"断面 {section_code} 未找到任何有效的入流站数据。")

    # 读取蒸发站数据
    if evap_code:
        evaporation_df = fetch_evap(start_time, end_time, evap_code, db_config)
    else:
        evaporation_df = None

    # 读取初始值
    initial_values = fetch_initial_values(section_code, start_time, db_config)
    # -- (E) 最后整合结果
    result_dict = {
        "rainfall_df":  rainfall_df,
        "evaporation_df": evaporation_df,
        "stage_flow_df":  stage_flow_df,
        "inflow_df":    inflow_df,
        "initial_values": initial_values
    }

    return result_dict
