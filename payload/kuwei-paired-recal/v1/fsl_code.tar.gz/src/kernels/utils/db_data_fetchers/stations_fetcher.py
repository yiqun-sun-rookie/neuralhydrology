from src.kernels.utils.db_data_fetchers.db_connector import create_database_connection
def fetch_stations(db_config, station_type, db=None):
    """
    从数据库读取雨量站点的名称和编码信息。
    使用 db_config.yml 中的表名和列名信息构建查询，
    并在查询结果中将实际列名重命名为逻辑列名。
    """
    # 1. 加载数据库配置
    db_info = db_config['database']
    # 假设 create_database_connection 函数可接受 db_info 作为参数，具体实现需根据您的代码调整
    if db is None:
        db = create_database_connection(db_info)

    # 判断输入station_type属[于rainfall, hydrologic, evap]中的一个，否则报错
    assert station_type in db_config['station_type'], f"station_type {station_type} 不在配置文件中。"

    station_table_info = db_config['station_info_table'][station_type]
    table_name = station_table_info['table_name']
    columns_map = station_table_info['columns']
    # columns_map 示例: {'station_name': 'p_name', 'station_code': 'out_pcode'}

    # 3. 使用实际数据库列名构建 SQL 查询
    original_cols = list(columns_map.values())
    select_clause = ", ".join(original_cols)
    query = f"SELECT {select_clause} FROM {table_name}"

    # 4. 执行查询
    df_db = db.fetch_data(query)
    db.disconnect()

    # 5. 使用逻辑列名重命名 DataFrame 列
    # 构建 {实际列名: 逻辑列名} 的反向映射
    rename_map = {v: k for k, v in columns_map.items()}
    # 示例: {'p_name': 'station_name', 'out_pcode': 'station_code'}
    df_db = df_db.rename(columns=rename_map)

    return df_db
