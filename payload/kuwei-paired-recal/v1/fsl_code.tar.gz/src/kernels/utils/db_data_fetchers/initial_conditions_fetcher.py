from src.kernels.utils.db_data_fetchers.db_connector import create_database_connection
import logging
import pandas as pd

def fetch_initial_values(station_codes, start_time, db_config, db=None):
    """
    从 [naban].[dbo].[slopmidvalue] 表中，为每个站点在 start_time 前最多7天的范围内，
    找到距离 start_time 最近(且不晚于 start_time) 的一条记录，
    读取 MVal2 (WU), MVal3 (WL), MVal4 (WD) 三列数据。

    - start_time: 字符串，如 '2020-01-01 00:00'
    - station_codes: 站点编码列表
    - db_config:   数据库配置信息
    - db: 可选数据库连接对象，如果不传则根据 db_config 创建新连接

    返回：
    - df_final: pandas.DataFrame，每个 station_code 对应一行，包含 [station_code, time, WU, WL, WD]。
      如果某个站找不到记录，则自动填入默认值(并在 time 列写 None 或其它标识)。
    """
    # 若传进来的是一个字符串，就包裹成列表
    if isinstance(station_codes, str):
        station_codes = [station_codes]
    # 1) 准备表名和列名（可改为从 db_config 读取）
    table_name = 'slopmidvalue'  # [naban].[dbo].[slopmidvalue]
    station_code_col = 'HS_Code'
    time_col = 'YMDHM'
    wum_col = 'MVal2'
    wlm_col = 'MVal3'
    wdm_col = 'MVal4'

    # 2) 如果没有传入 db，则根据 db_config 创建一个新的数据库连接
    if db is None:
        db_info = db_config['database']
        db = create_database_connection(db_info)

    if not station_codes:
        raise ValueError("station_codes should not be empty。")

    # 将 station_codes 列表转换为 SQL IN 需要的字符串形式
    station_codes_str = ', '.join([f"'{code}'" for code in station_codes])

    # 3) 构建查询语句
    #    - 只取 <= start_time 的记录
    #    - 如果需要限制“近7天”窗口，可加  AND {time_col} >= DATEADD(DAY, -7, '{start_time}')
    query = f"""
    SELECT
        {station_code_col} AS station_code,
        {time_col} AS time,
        {wum_col} AS WU,
        {wlm_col} AS WL,
        {wdm_col} AS WD
    FROM {table_name}
    WHERE {time_col} <= '{start_time}'
      AND {station_code_col} IN ({station_codes_str})
      AND {time_col} >= DATEADD(DAY, -7, '{start_time}')  -- 限定在 start_time 往前7天
    ORDER BY station_code, {time_col} DESC
    """

    df = db.fetch_data(query)

    db.disconnect()  # 查询完就断开连接

    if df.empty:
        logging.warning(
            f"[fetch_initial_values] 在 {table_name} 表中，"
            f"从 {start_time} 往前7天找不到任何记录，将使用默认初始值。"
        )
        # 对所有站都返回默认值
        return _build_default_init_df(station_codes)

    # 4) 按 station_code 分组，并取各组 time 最大的一条记录(即最接近 start_time)
    #    因为上面 ORDER BY station_code, time DESC，所以 groupby(...).head(1) 就能取到最近一条
    df_sorted = df.sort_values(["station_code", "time"], ascending=[True, False])
    df_top = df_sorted.groupby("station_code", as_index=False).head(1)

    return df_top


def _build_default_init_df(station_codes, default_wu=30.0, default_wl=80.0, default_wd=20.0):
    """
    辅助函数：对给定的 station_codes 构造一个使用默认值的 DataFrame。
    """
    data = []
    for code in station_codes:
        data.append({
            'station_code': code,
            'time': None,  # 标识此处是没有查到数据
            'WU': default_wu,
            'WL': default_wl,
            'WD': default_wd
        })
    return pd.DataFrame(data, columns=['station_code', 'time', 'WU', 'WL', 'WD'])

def _build_default_init_df(station_codes, default_wu=30.0, default_wl=80.0, default_wd=20.0):
    """
    辅助函数：对给定的 station_codes 构造一个使用默认值的 DataFrame。
    """
    data = []
    for code in station_codes:
        data.append({
            'station_code': code,
            'time': None,   # 标识此处是没有查到数据
            'WU': default_wu,
            'WL': default_wl,
            'WD': default_wd
        })
    return pd.DataFrame(data, columns=['station_code', 'time', 'WU', 'WL', 'WD'])
