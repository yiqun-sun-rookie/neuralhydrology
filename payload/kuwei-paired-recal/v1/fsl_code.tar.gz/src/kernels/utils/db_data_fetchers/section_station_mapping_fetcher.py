from src.kernels.utils.db_data_fetchers.db_connector import create_database_connection
def fetch_section_station_mapping(db_config, db=None):
    """
    从数据库读取 section_station_map_table 表的信息。
    该表描述了每一个断面（hydro_section_code）对应的水文站点和所使用的雨量站之间的关系。

    参数：
    - db_config: 包含数据库和表配置信息的字典
    - db: 可选的数据库连接对象，如果未提供则内部建立连接。

    返回：
    - DataFrame
    """
    db_info = db_config['database']
    table_info = db_config['section_station_map_table']

    table_name = table_info['table_name']
    field_map = table_info['columns']

    # 如果未传入 db 则创建新连接
    if db is None:
        db = create_database_connection(db_info)

    # 构建查询SQL
    original_cols = list(field_map.values())  # 使用物理列名
    select_clause = ", ".join(original_cols)
    query = f"SELECT {select_clause} FROM {table_name}"

    # 执行查询
    df = db.fetch_data(query)
    db.disconnect()

    # 使用逻辑名重命名
    reverse_map = {v: k for k, v in field_map.items()}
    df = df.rename(columns=reverse_map)

    return df
