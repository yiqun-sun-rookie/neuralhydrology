from src.kernels.utils.db_data_fetchers.db_connector import create_database_connection


def fetch_stage_and_flow(
        start_time,
        end_time,
        station_codes,
        db_config,
        db=None
):
    """
    根据指定的开始和结束时间，获取指定站点的水位(Z)和流量(Q)数据。
    如果查询结果为空，则查询该表的时间覆盖范围，并抛出异常。

    参数：
    - start_time: 开始时间，字符串格式 (例如：'2020-01-01 00:00')
    - end_time: 结束时间，字符串格式 (例如：'2020-01-02 00:00')
    - station_codes: 站点编码列表 (如 ['ST001', 'ST002'])
    - db_config: 数据库配置信息（一个字典），其中：
        * db_config['values_table']['hydrologic'] 中定义了 hydrologic 表相关配置
        * db_config['database'] 中定义了数据库连接信息
    - db: 数据库连接对象（可选）。如果不传，则根据 db_config 创建新连接

    返回：
    - df: pandas.DataFrame，包含列 ['station_code', 'time', 'stage', 'flow']
    """
    # start_time_str = '2012-05-15 10:00:00'
    # # start_time_str to timestamp start_time
    # start_time = pd.to_datetime(start_time_str)
    # end_time_str = '2012-05-15 11:00:00'
    # end_time = pd.to_datetime(end_time_str)
    # 1. 读取 hydrologic 表配置信息
    hydrologic_config = db_config['values_table']['hydrologic']

    table_name = hydrologic_config['table_name']
    columns_info = hydrologic_config['columns']

    station_code_col = columns_info['station_code']  # 'stcd'
    time_col = columns_info['time']  # 'ymdhm'
    stage_col = columns_info['stage']  # 'z'
    flow_col = columns_info['flow']  # 'q'

    # 如果没有传 db，使用配置创建一个新的数据库连接
    if db is None:
        db_info = db_config['database']  # 假设配置文件中有 'database' 字段存储连接信息
        db = create_database_connection(db_info)

    # 确保 station_codes 非空
    if not station_codes:
        raise ValueError("station_codes should not be empty。")

    # 将 station_codes 转换为适合 SQL IN 的列表字符串
    station_codes_str = ', '.join([f"'{code}'" for code in station_codes])

    # 构建查询语句
    query = f"""
    SELECT 
        {station_code_col} AS hydrologic_station_code,
        {time_col} AS time,
        {stage_col} AS stage,
        {flow_col} AS flow
    FROM {table_name}
    WHERE {time_col} >= '{start_time}'
      AND {time_col} <= '{end_time}'
      AND {station_code_col} IN ({station_codes_str})
    """

    # 执行查询
    df = db.fetch_data(query)

    # 如果列名不包含 'hydrologic_station_code'，尝试手动重命名
    if 'hydrologic_station_code' not in df.columns:
        if station_code_col in df.columns:
            df.rename(columns={station_code_col: 'hydrologic_station_code'}, inplace=True)
            print("Renamed columns to include 'hydrologic_station_code'")
        else:
            raise ValueError(f"查询结果中缺少 '{station_code_col}' 列。")

    # 如果查询结果为空，则去数据库中检查该表的整体时间覆盖范围
    if df.empty:
        coverage_query = f"""
        SELECT 
            MIN({time_col}) AS min_time, 
            MAX({time_col}) AS max_time
        FROM {table_name}
        """
        coverage_df = db.fetch_data(coverage_query)

        # 理论上 coverage_df 应该只返回一行，包含 min_time 和 max_time
        if not coverage_df.empty:
            min_time_in_db = coverage_df['min_time'].iloc[0]
            max_time_in_db = coverage_df['max_time'].iloc[0]
            db.disconnect()

            raise ValueError(
                f"在表 {table_name} 中，"
                f"从 '{start_time}' 到 '{end_time}' 之间无数据。\n"
                f"该表的时间覆盖范围为：{min_time_in_db} 至 {max_time_in_db}。"
            )
        else:
            # 如果 coverage_df 也为空，表示这个表本身就没有任何数据
            db.disconnect()
            raise ValueError(f"表 {table_name} 中没有任何记录，请检查数据源。")

    # 若 df 不为空，最后断开连接并返回结果
    db.disconnect()
    return df
