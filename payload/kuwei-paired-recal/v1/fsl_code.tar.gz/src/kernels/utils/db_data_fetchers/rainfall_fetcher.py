from src.kernels.utils.db_data_fetchers.db_connector import create_database_connection
def fetch_rainfall(start_time, end_time, station_codes, db_config, db=None):
    """
    根据指定的开始和结束时间，获取指定站点的实时雨量数据。
    当查询结果为空时，自动去数据库中检查该表的时间覆盖范围，并抛出异常或提示。

    参数：
    - start_time: 开始时间，字符串格式 (例如 '2020-01-01 00:00')
    - end_time:   结束时间，字符串格式 (例如 '2020-01-02 00:00')
    - station_codes: 站点编码列表（来自 rain_stations['p_station_id']）
    - db_config:   数据库配置信息的字典
    - db: 可选的数据库连接对象，如果不传则根据 db_config 创建新连接

    返回：
    - df: pandas.DataFrame，包含 ['station_code', 'time', 'rainfall'] 列
    """

    # 1. 从 db_config 读取“雨量”表的配置信息
    rainfall_config = db_config['values_table']['rainfall']
    table_name = rainfall_config['table_name']
    columns_info = rainfall_config['columns']

    station_code_col = columns_info['station_code']  # 比如 'STCD'
    time_col = columns_info['time']  # 比如 'YMDHM'
    rainfall_col = columns_info['rainfall']  # 比如 'DTRN'

    # 2. 如果没有传入 db，则根据 db_config 创建一个新的数据库连接
    if db is None:
        db_info = db_config['database']  # 假设这里存有连接必须的信息
        db = create_database_connection(db_info)  # 你需要在项目中实现此函数

    # 3. 确保 station_codes 列表不为空
    if not station_codes:
        raise ValueError("station_codes should not be empty。")

    # 将 station_codes 列表转换为 SQL IN 需要的字符串形式
    station_codes_str = ', '.join([f"'{code}'" for code in station_codes])

    # 4. 构建查询语句
    query = f"""
    SELECT
        {station_code_col} AS rainfall_station_code,
        {time_col} AS time,
        {rainfall_col} AS rainfall
    FROM {table_name}
    WHERE {time_col} >= '{start_time}'
      AND {time_col} <= '{end_time}'
      AND {station_code_col} IN ({station_codes_str})
    """

    # 5. 执行查询
    df = db.fetch_data(query)

    # 6. 如果查询结果为空，则再去数据库查询该表的时间覆盖范围
    if df.empty:
        coverage_query = f"""
        SELECT
            MIN({time_col}) AS min_time,
            MAX({time_col}) AS max_time
        FROM {table_name}
        WHERE {station_code_col} IN ({station_codes_str})
        """
        coverage_df = db.fetch_data(coverage_query)

        if not coverage_df.empty:
            min_time_in_db = coverage_df['min_time'].iloc[0]
            max_time_in_db = coverage_df['max_time'].iloc[0]
            db.disconnect()

            # 不抛出异常，不logging，改为print到控制台
            print(
                f"在表 {table_name} 中，从 '{start_time}' 到 '{end_time}' "
                f"之间无雨量数据。\n该表的时间覆盖范围：{min_time_in_db} ~ {max_time_in_db}。"
            )
            return None

        else:
            # 如果 coverage_df 也为空，说明表里根本没有数据
            db.disconnect()
            raise ValueError(f"表 {table_name} 中没有任何雨量记录，请检查数据源。")


        if not coverage_df.empty:
            min_time_in_db = coverage_df['min_time'].iloc[0]
            max_time_in_db = coverage_df['max_time'].iloc[0]
            logging.info(
                f"在表 {table_name} 中，从 '{start_time}' 到 '{end_time}' "
                f"之间无雨量数据。该表的时间覆盖范围：{min_time_in_db} ~ {max_time_in_db}。"
            )
        else:
            # 如果 coverage_df 也为空，说明表里根本没有数据
            logging.info(
                f"表 {table_name} 中没有任何雨量记录，请检查数据源。"
            )

        # 这里改为仅记录日志，不抛异常，返回 None
        return None

    # 如果有数据，正常返回
    db.disconnect()
    return df

