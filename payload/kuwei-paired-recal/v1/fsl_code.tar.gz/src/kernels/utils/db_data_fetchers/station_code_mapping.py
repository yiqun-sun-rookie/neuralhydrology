from src.kernels.utils.db_data_fetchers.db_connector import create_database_connection
def map_station_code(original_code: str, station_type: str, db_config: dict) -> str:
    """
    根据配置，判断要不要映射站码。
    如果 need_mapping = True，就到 station_info_table[station_type] 中
    用 net_code_field = original_code 做查询，拿到 out_code_field 做为外部站码。
    如果 need_mapping = False，就直接返回 original_code。

    参数:
      - original_code: net_station 中的码，如 q_code, h_code 等
      - station_type: 比如 'hydrologic' 或 'rainfall'
      - db_config: 配置信息，包括 station_mapping, station_info_table, database 等

    返回:
      - real_code: str, 最终可在 st_river_r (或 ReFactorDT) 中使用的站码
    """
    # 0. 先从 station_mapping 里读到这个 station_type 的配置
    mapping_config = db_config['station_mapping'][station_type]
    need_mapping = mapping_config['need_mapping']

    # 1. 如果不需要映射，直接返回原始码
    if not need_mapping:
        return str(original_code).strip()

    # 2. 如果需要映射，则到 station_info_table[station_type] 里找对应记录
    net_code_field = mapping_config['net_code_field']  # e.g. "h_code"
    out_code_field = mapping_config['out_code_field']  # e.g. "out_hcode"

    # 3. 获取 station_info_table 的信息，如表名、列名映射
    info_config = db_config['station_info_table'][station_type]
    info_table_name = info_config['table_name']

    # 4. 构建 SQL，根据 net_code_field 与 original_code 匹配，选出 out_code_field
    query = f"""
    SELECT {out_code_field} AS mapped_code
    FROM {info_table_name}
    WHERE {net_code_field} = '{original_code}'
    """

    # 5. 执行查询
    db_info = db_config['database']
    db = create_database_connection(db_info)
    df_map = db.fetch_data(query)
    db.disconnect()

    # 6. 如果查不到，抛异常
    if df_map.empty:
        raise ValueError(
            f"无法在表 {info_table_name} 中找到 {net_code_field} = {original_code}，"
            f"无法获取 {out_code_field} 作为外部站码。"
        )

    # 7. 取第一行的mapped_code
    real_code = df_map['mapped_code'].iloc[0]
    return str(real_code).strip()

