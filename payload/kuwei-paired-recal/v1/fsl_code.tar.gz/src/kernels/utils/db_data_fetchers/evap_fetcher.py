from src.kernels.utils.db_data_fetchers.db_connector import create_database_connection

def fetch_evap(start_time, end_time, station_code, db_config, db=None):
    """
    根据指定的开始和结束时间，获取指定站点的蒸发量 (evap) 数据。
    当查询结果为空时，自动去数据库中检查该表的时间覆盖范围，并抛出异常或提示。

    参数：
    - start_time:   开始时间，字符串格式 (例如 '2020-01-01 00:00')
    - end_time:     结束时间，字符串格式 (例如 '2020-01-02 00:00')
    - station_code: 站点编码（单个字符串）
    - db_config:    数据库配置信息的字典
    - db:           可选的数据库连接对象，如果不传则根据 db_config 创建新连接

    返回：
    - df: pandas.DataFrame，包含 ['station_code', 'time', 'evap'] 列
          若无数据，则返回 None，并在日志或异常中说明。
    """

    # 1. 从 db_config 中读取 “蒸发 (evap)” 表的配置信息
    evap_config = db_config['values_table']['evaporation']
    table_name = evap_config['table_name']
    columns_info = evap_config['columns']

    station_code_col = columns_info['station_code']  # 例如 'STCD'
    time_col = columns_info['time']                  # 例如 'YMDHM'
    evap_col = columns_info['evap']                  # 例如 'EVP'

    # 2. 如果没有传入 db，则根据 db_config 创建一个新的数据库连接
    if db is None:
        db_info = db_config['database']
        db = create_database_connection(db_info)

    # 3. 检查 station_code 是否为空
    if not station_code:
        raise ValueError("station_code should not be empty。")

    # 4. 构建查询语句
    query = f"""
    SELECT
        {station_code_col} AS evaporation_station_code,
        {time_col} AS time,
        {evap_col} AS evap
    FROM {table_name}
    WHERE {time_col} >= '{start_time}'
      AND {time_col} <= '{end_time}'
      AND {station_code_col} = '{station_code}'
    """

    # 5. 执行查询
    df = db.fetch_data(query)

    # 6. 如果查询结果为空，则再去数据库查询该表的时间覆盖范围
    if df.empty:
        coverage_query = f"""
        SELECT
            MIN({time_col}) AS min_time,
            MAX({time_col}) AS max_time
        FROM {table_name}
        WHERE {station_code_col} = '{station_code}'
        """
        coverage_df = db.fetch_data(coverage_query)

        if not coverage_df.empty:
            min_time_in_db = coverage_df['min_time'].iloc[0]
            max_time_in_db = coverage_df['max_time'].iloc[0]
            db.disconnect()

            # 抛出异常或进行日志记录
            raise ValueError(
                f"在表 {table_name} 中，从 '{start_time}' 到 '{end_time}' "
                f"之间无蒸发数据。\n该表的时间覆盖范围：{min_time_in_db} ~ {max_time_in_db}。"
            )
        else:
            # 如果 coverage_df 也为空，说明表里根本没有数据
            db.disconnect()
            raise ValueError(f"表 {table_name} 中没有任何蒸发记录，请检查数据源或 ETL 流程。")

    # 7. 如果有数据，正常返回
    db.disconnect()
    return df

