from src.kernels.utils.db_data_fetchers.db_connector import create_database_connection
def fetch_flood_times(db_config, db=None):
    """
    从数据库读取洪水时段信息，包括流域代码、洪水编号、开始时间和结束时间。

    参数：
    - db_config: 已加载的配置字典，包含数据库和表的相关信息
    - db: （可选）数据库连接对象。如果未提供，则根据 db_config 创建新的连接。

    返回：
    - DataFrame: 包含 [basin_code, flood_id, start_time, end_time] 列
    """
    db_info = db_config['database']
    table_info = db_config['flood_time_table']

    table_name = table_info['table_name']
    columns_map = table_info['columns']
    # 例如 columns_map = {'basin_code': 'b_code', 'flood_id': 'flcd', 'start_time': 's_dt', 'end_time': 'e_dt'}

    # 如果未传入 db 则创建连接
    if db is None:
        db = create_database_connection(db_info)

    # 使用实际列名构建查询SQL
    original_cols = list(columns_map.values())
    select_clause = ", ".join(original_cols)
    query = f"SELECT {select_clause} FROM {table_name}"

    # 执行查询
    df = db.fetch_data(query)
    db.disconnect()

    # 使用逻辑名重命名
    reverse_map = {v: k for k, v in columns_map.items()}
    df = df.rename(columns=reverse_map)

    return df
