import os
import yaml

def load_configurations(basin_name: str, project_root: str) -> dict:
    """
    根据给定的项目根目录和流域名称，读取对应流域的配置文件。

    参数：
    - basin_name: 流域名称，例如 "naban"、"other_basin" 等
    - project_root: 项目的根目录，例如 "C:/Users/yiqun/PycharmProjects/forecast_system_lite"

    返回：
    - config: 包含所有配置项的字典
    """
    # 拼接出目标流域下的配置目录
    config_dir = os.path.join(project_root, 'config/basins/', basin_name)

    config = {}

    # 读取字段映射配置
    field_mapping_path = os.path.join(config_dir, 'field_mapping.yml')
    with open(field_mapping_path, 'r', encoding='utf-8') as file:
        config['field_mapping'] = yaml.safe_load(file)

    # 读取文件路径配置
    file_path_config_path = os.path.join(config_dir, 'file_path.yml')
    with open(file_path_config_path, 'r', encoding='utf-8') as file:
        config['file_paths'] = yaml.safe_load(file)

    # 读取水文模型配置
    hydro_model_config_path = os.path.join(config_dir, 'simulation.yml')
    with open(hydro_model_config_path, 'r', encoding='utf-8') as file:
        config['simulation'] = yaml.safe_load(file)

    # 读取数据库配置
    db_config_path = os.path.join(config_dir, 'database.yml')
    with open(db_config_path, 'r', encoding='utf-8') as file:
        config['db_config'] = yaml.safe_load(file)

    return config
