from __future__ import annotations
from pathlib import Path
import os

# ------------------------------------------------------------
# 项目根定位：向上寻找包含环境定义的目录
# （兼容 root/environment.yml 与 config/environment.yml）
# ------------------------------------------------------------

def _looks_like_project_root(path: Path) -> bool:
    if (path / 'environment.yml').exists():
        return True
    config_env = path / 'config' / 'environment.yml'
    return config_env.exists()


def get_project_root(start: Path | None = None) -> Path:
    if start is None:
        start = Path(__file__).resolve()
    cur = start
    for _ in range(8):  # 限制向上层数，防止意外循环
        if _looks_like_project_root(cur):
            return cur
        if cur.parent == cur:
            break
        cur = cur.parent
    # 回退：使用 4 层父目录（与原逻辑一致）
    return Path(__file__).resolve().parents[4]

# ------------------------------------------------------------
# 目录路径
# ------------------------------------------------------------

def get_basin_config_dir(basin: str) -> Path:
    return get_project_root() / 'basins' / basin / 'config'

def get_optimization_config_dir() -> Path:
    # Deprecated: Optimization configs are now per-basin
    return get_project_root() / 'config' / 'optimization'

def get_scenarios_config_dir() -> Path:
    # Deprecated: Scenarios are now per-basin
    return get_project_root() / 'config' / 'scenarios'

# ------------------------------------------------------------
# 文件路径便捷函数
# ------------------------------------------------------------

def path_topology(basin: str) -> Path:
    return get_basin_config_dir(basin) / 'topology.yml'

def path_profiles(basin: str) -> Path:
    return get_basin_config_dir(basin) / 'profiles.yml'

def path_run_config(basin: str) -> Path:
    return get_basin_config_dir(basin) / 'run_config.yml'

def path_model_params() -> Path:
    return get_optimization_config_dir() / 'pdd_xaj_params.yml'

def path_calibration_params() -> Path:
    return get_optimization_config_dir() / 'calibration_params.yml'

def path_calibration_scenarios() -> Path:
    return get_scenarios_config_dir() / 'calibration_scenarios.yml'

def path_outlet_eval_example(basin: str) -> Path:
    return get_basin_config_dir(basin) / 'outlet_eval.example.yml'

# ------------------------------------------------------------
# 环境变量辅助（可选）
# ------------------------------------------------------------

def resolve_basin_from_env(default: str = 'yingluoxia') -> str:
    return os.environ.get('BASIN_NAME', default)

