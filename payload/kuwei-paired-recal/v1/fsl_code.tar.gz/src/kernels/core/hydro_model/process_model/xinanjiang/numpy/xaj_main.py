from .xaj_fcns import *
import numpy as np
def xaj_step_vec(
        state: np.ndarray,
        rain: np.ndarray,
        pet: np.ndarray,
        param_dict: dict
) -> np.ndarray:
    """
    XAJ 单步计算（矢量化并行版），按名称解包参数。

    state: shape (N, 8)
    rain, em: shape (N,)
    param_dict: 一个包含所有参数的 dict,
                每个键都是 shape (N,) 的数组 (或可广播标量)，
                例如: {
                   "kc": ndarray(N,),
                   "ki": ndarray(N,),
                   ...,
                   "ms": ndarray(N,)
                }
    Returns
    -------
    new_state : shape (N, 8)
        [w, wu, wl, wd, s, qs, qi, qg]
    """
    # 1) 从 state 拆分
    w = state[:, 0]
    wu = state[:, 1]
    wl = state[:, 2]
    wd = state[:, 3]
    s = state[:, 4]
    qs = state[:, 5]
    qi = state[:, 6]
    qg = state[:, 7]

    # 2) 从 param_dict 按名称取
    kc = get_param(param_dict["kc"])
    ki = get_param(param_dict["ki"])
    kg = get_param(param_dict["kg"])
    cs = get_param(param_dict["cs"])
    ci_ = get_param(param_dict["ci"])
    cg_ = get_param(param_dict["cg"])
    wum = get_param(param_dict["wum"])
    wlm = get_param(param_dict["wlm"])
    wdm = get_param(param_dict["wdm"])
    sm = get_param(param_dict["sm"])
    imp = get_param(param_dict["imp"])
    c = get_param(param_dict["c"])
    b = get_param(param_dict["b"])
    ex = get_param(param_dict["ex"])
    uf = get_param(param_dict["uf"])
    wmm = get_param(param_dict["wmm"])
    ms = get_param(param_dict["ms"])
    wm = wum + wlm + wdm

    # 3) 原有计算过程 (保持不变)
    ep = kc * pet  # (N,)
    pe = rain - ep  # (N,)

    w, wu, wl, wd = redistribute_soil_water(w, wu, wl, wd, wm, wum, wlm, wdm)
    w, wu, wl, wd, runoff, e = update_soil_moisture(
        wu, wl, wd, rain, ep, wmm, wm, b, wum, wlm, wdm, c)
    s, rs, ri, rg, fr = update_free_water_storage(
        s, runoff, pe, ki, kg, ms, sm, ex)
    qs, qi, qg = update_qs_qi_qg(qs, qi, qg, rs, ri, rg, cs, ci_, cg_, uf)

    # 4) 拼回状态
    new_state = np.column_stack([w, wu, wl, wd, s, qs, qi, qg])
    return new_state

def get_param(param_value):
    """智能获取numpy数组参数（兼容DataFrame/Series/直接数组）"""
    if isinstance(param_value, np.ndarray):
        return param_value
    elif hasattr(param_value, 'to_numpy'):
        return param_value.to_numpy()
    else:
        return np.array(param_value)  # 兜底处理标量或列表
