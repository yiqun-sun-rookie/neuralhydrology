import numpy as np
import pandas as pd
from src.kernels.core.hydro_model.process_model.xinanjiang.numpy.xaj_main import xaj_step_vec
from src.kernels.core.hydro_model.process_model.positive_degree_day.pdd_use_seperate_rain_snow import pdd_use_seperate_rain_snow
def coupled_pdd_xaj_step_vec(
        joint_state: np.ndarray,
        temp: np.ndarray,
        rain: np.ndarray,
        snow: np.ndarray,
        pet: np.ndarray,
        pdd_params: dict,
        xaj_params: dict
) -> (np.ndarray, np.ndarray):
    """
    耦合 PDD 融雪模型与 XAJ 产流模型的单步计算（矢量化并行版）

    """
    # 确保输入为二维数组（兼容单单元场景）
    joint_state = np.atleast_2d(joint_state)

    # 1. 拆分联合状态
    pdd_state = joint_state[:, :3]  # [snow_depth, ice_depth, last_temp]
    xaj_state = joint_state[:, 3:]  # XAJ的8个状态

    # 2. 执行 PDD 融雪计算（使用“纯雨 + 纯雪”作为输入）
    # print(pdd_params)
    new_pdd_state, pdd_runoff = pdd_use_seperate_rain_snow(
        state=pdd_state,
        temp=temp,
        rain=rain,
        snow=snow,
        param_dict=pdd_params
    )

    # 3. 执行 XAJ 产流计算
    #    注意：XAJ的降雨输入使用 PDD 输出的径流(单位 m)，
    #    部分 XAJ 实现里需要 mm，这里示例是 mm => 需乘以1000
    xaj_params_df = pd.DataFrame({
        k: np.asarray(v).flatten()  # 确保参数为 1D 数组
        for k, v in xaj_params.items()
    })
    # print(xaj_params_df)
    new_xaj_state = xaj_step_vec(
        state=xaj_state,
        rain=pdd_runoff,  # XAJ 若需 mm，则这里乘以 1000
        pet=pet,
        param_dict=xaj_params_df
    )

    # 4. 合并新状态
    new_state = np.hstack([new_pdd_state, new_xaj_state])

    # 如果有需要的话，您也可以把 pdd_runoff 的单位保持为 m，
    # 再在 xaj_step_vec 内部统一转换，这个看自己模型需求

    return new_state, pdd_runoff

