"""
Fixed PDD (Positive Degree Day) snowmelt module.

Corrects the phantom ice melt bug in my_degree_day.py where
    ice_melt_net = np.maximum(ice_melt - ice_depth, 0)
should be
    ice_melt_net = np.minimum(ice_melt, ice_depth)

This file is a NEW file (no modification to existing code).
Signature matches simulate_pdd_step_parallel exactly.
"""
import numpy as np


def _get_param(v):
    if isinstance(v, np.ndarray):
        return v
    elif hasattr(v, "to_numpy"):
        return v.to_numpy()
    return np.array(v)


def simulate_pdd_step_fixed(
    state: np.ndarray,
    temp: np.ndarray,
    prec: np.ndarray,
    param_dict: dict,
) -> tuple[np.ndarray, np.ndarray]:
    """
    PDD single-step (vectorized), with ice melt bug fixed.

    Args:
        state: (N, 3) — [snow_depth, ice_depth, last_temp]
        temp:  (N,)   — daily mean temperature (degC)
        prec:  (N,)   — daily total precipitation (mm)
        param_dict: PDD parameters

    Returns:
        new_state: (N, 3)
        runoff: (N,) in meters
    """
    pdd_factor_snow = _get_param(param_dict["pdd_factor_snow"])
    pdd_factor_ice = _get_param(param_dict["pdd_factor_ice"])
    refreeze_snow = _get_param(param_dict["refreeze_snow"])
    refreeze_ice = _get_param(param_dict["refreeze_ice"])
    temp_snow = _get_param(param_dict["temp_snow"])
    temp_rain = _get_param(param_dict["temp_rain"])

    snow_depth = state[:, 0].copy()
    ice_depth = state[:, 1].copy()

    prec_m = prec / 1000.0  # mm -> m

    # 1. Rain/snow partitioning
    snow_frac = np.clip((temp_rain - temp) / (temp_rain - temp_snow + 1e-12), 0, 1)
    snowfall = snow_frac * prec_m
    rainfall = prec_m - snowfall

    # 2. Snow accumulation
    snow_depth += snowfall

    # 3. Positive degree days
    pdd = np.maximum(temp, 0.0)

    # 4. Snow melt
    pot_snow_melt = pdd_factor_snow * pdd / 1000.0  # m/day
    actual_snow_melt = np.minimum(snow_depth, pot_snow_melt)

    # 5. Ice melt (remaining energy) — FIXED: use min(ice_melt, ice_depth)
    remaining_energy = (pot_snow_melt - actual_snow_melt) * 1000.0  # mm
    ice_melt = remaining_energy * pdd_factor_ice / (pdd_factor_snow + 1e-12) / 1000.0  # m
    ice_melt_net = np.minimum(ice_melt, ice_depth)  # FIX: can't melt more ice than exists

    # 6. Update snow/ice with refreezing
    snow_depth -= actual_snow_melt
    refrozen_snow = actual_snow_melt * refreeze_snow
    snow_depth += refrozen_snow

    ice_depth -= ice_melt_net
    refrozen_ice = ice_melt_net * refreeze_ice
    ice_depth += refrozen_ice

    # 7. Runoff
    total_melt = actual_snow_melt + ice_melt_net
    runoff = total_melt - refrozen_snow - refrozen_ice + rainfall

    # 8. Assemble state
    new_state = np.column_stack([
        np.maximum(snow_depth, 0),
        np.maximum(ice_depth, 0),
        temp,
    ])
    return new_state, runoff
