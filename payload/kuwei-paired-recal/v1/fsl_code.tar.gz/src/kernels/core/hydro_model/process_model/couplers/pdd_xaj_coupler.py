from src.kernels.core.hydro_model.process_model.positive_degree_day.pdd_ys import PDDModel
from src.kernels.core.hydro_model.process_model.xinanjiang.numpy.xaj_main import xaj_step_vec
import numpy as np


def coupled_pdd_xaj_step_vec(
        current_state: np.ndarray,
        temp: float,
        prec: float,
        stdv: float,
        evap: float,
        pdd_params: dict,
        xaj_params: dict
) -> np.ndarray:
    """
    耦合融雪模块(PDD)与产流模型(XAJ)的单步计算

    参数:
        current_state: 当前联合状态向量，结构为
            [snow_depth, ice_depth, XAJ_state(8)]
        temp: 气温 (°C)
        prec: 降水量 (m)
        stdv: 气温标准差 (K)
        evap: 蒸发量 (m)
        pdd_params: PDD模型参数字典
        xaj_params: XAJ模型参数字典

    返回:
        new_state: 下一时刻联合状态，结构同输入
    """
    # 拆分状态
    snow_depth, ice_depth = current_state[0], current_state[1]
    xaj_state = current_state[2:10]

    # 1. 运行PDD融雪模块（处理输入维度）
    # 将标量扩展为三维数组 (time=1, x=1, y=1)
    temp_3d = np.array([[[temp]]])  # shape (1,1,1)
    prec_3d = np.array([[[prec]]])
    stdv_3d = np.array([[[stdv]]])

    # 运行PDD融雪模块
    pdd_model = PDDModel(**pdd_params)
    ds = pdd_model(
        temp=temp_3d,
        prec=prec_3d,
        stdv=stdv_3d
    )

    # 获取径流输出（确保转换为标量）
    runoff = float(ds['runoff_rate'].values[0].squeeze())  # 确保为标量

    # 更新雪冰状态（确保转换为标量）
    new_snow = float(ds['snow_depth'].values[-1].squeeze())
    new_ice = float(ds['ice_depth'].values[-1].squeeze())

    # 2. 准备XAJ输入
    # 确保所有参数都是数组格式，即使只有一个元素
    xaj_state_2d = xaj_state.reshape(1, -1)  # 确保形状为 (1, 8)

    # 关键修改：确保rain和em是形状为(1,)的数组
    rain_array = np.array([runoff])  # shape (1,)
    evap_array = np.array([evap])  # shape (1,)

    # 3. 确保参数字典中的所有参数都是数组
    param_dict_vectorized = {}
    for key, value in xaj_params.items():
        # 确保每个参数都是形状为(1,)的数组
        if np.isscalar(value):
            param_dict_vectorized[key] = np.array([value])
        else:
            # 如果已经是数组，确保形状正确
            param_dict_vectorized[key] = np.atleast_1d(value)

    # 4. 运行XAJ产流模型
    new_xaj = xaj_step_vec(state=xaj_state_2d, rain=rain_array, em=evap_array, param_dict=param_dict_vectorized)[0]  # 取第一个结果

    # 5. 合并新状态
    return np.concatenate([[new_snow, new_ice], new_xaj])
