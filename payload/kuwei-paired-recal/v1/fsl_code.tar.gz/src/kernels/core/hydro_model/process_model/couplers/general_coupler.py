import numpy as np
from typing import Dict, List, Tuple
from scipy import special

class CoupledModel:
    """支持模块间数据流耦合的改进模型"""

    def __init__(self, modules: List[Tuple]):
        """
        modules: (模型实例, 输入配置, 输出配置) 元组列表
        输入配置格式: {'输入名': (源模块索引, 源输出名), ...} 或外部输入
        输出配置格式: {'输出名': 单位}
        """
        self.modules = modules
        self._validate_connections()
        self._build_unit_conversion()

    def _validate_connections(self):
        """验证模块间连接有效性"""
        for idx, (_, inputs, _) in enumerate(self.modules):
            for src in inputs.values():
                if isinstance(src, tuple):
                    src_mod, src_out = src
                    assert src_mod < idx, "只能连接先前模块的输出"
                    assert src_out in self.modules[src_mod][2], f"模块{src_mod}无输出{src_out}"

    def _build_unit_conversion(self):
        """预计算单位转换系数"""
        self.converters = []
        for mod_idx, (_, inputs, _) in enumerate(self.modules):
            mod_convert = {}
            for inp_name, src in inputs.items():
                if isinstance(src, tuple):
                    src_mod, src_out = src
                    src_unit = self.modules[src_mod][2][src_out]
                    tgt_unit = self.modules[mod_idx][0].input_units[inp_name]
                    mod_convert[inp_name] = self._get_converter(src_unit, tgt_unit)
            self.converters.append(mod_convert)

    def _get_converter(self, src_unit: str, tgt_unit: str) -> float:
        """单位转换系数计算"""
        # 示例转换逻辑，需根据实际情况扩展
        if src_unit == "m/year" and tgt_unit == "mm/day":
            return 1000 / 365.25
        elif src_unit == tgt_unit:
            return 1.0
        else:
            raise ValueError(f"未处理的单位转换: {src_unit} -> {tgt_unit}")

    def step(self,
             states: List[np.ndarray],
             external_inputs: Dict[str, np.ndarray],
             params: Dict[str, np.ndarray]) -> List[np.ndarray]:
        """
        执行耦合计算
        states: 各模块的状态数组列表 [mod1_state, mod2_state, ...]
        external_inputs: 外部输入字典 {'input_name': data_array}
        params: 参数字典 {'param_name': data_array}
        返回: 新状态列表
        """
        module_outputs = []
        new_states = []

        for mod_idx, (module, inputs, outputs) in enumerate(self.modules):
            # 准备输入数据
            mod_inputs = {}
            for inp_name, src in inputs.items():
                if isinstance(src, tuple):  # 来自其他模块
                    src_mod, src_out = src
                    raw_value = module_outputs[src_mod][src_out]
                    mod_inputs[inp_name] = raw_value * self.converters[mod_idx][inp_name]
                else:  # 外部输入
                    mod_inputs[inp_name] = external_inputs[src]

            # 执行模块计算
            current_state = states[mod_idx]
            new_state, outputs = module.step(current_state, mod_inputs, params)

            # 保存输出和状态
            module_outputs.append(outputs)
            new_states.append(new_state)

        return new_states


# 模块实现示例 ------------------------------------------------------------

class XAJModule:
    """改进的XAJ模块"""
    input_units = {
        'rain': 'mm/day',
        'em': 'mm/day'
    }

    def step(self, state, inputs, params):
        # 这里调用原始XAJ计算函数
        new_state = simulate_xaj_step_parallel(
            state,
            inputs['rain'],
            inputs['em'],
            params
        )
        # 假设需要输出地表径流
        outputs = {'surface_runoff': new_state[:, 5]}  # qs作为示例输出
        return new_state, outputs


class PDDModule:
    """改进的PDD模块"""
    input_units = {
        'temp': 'degC',
        'prec': 'm/year',
        'stdv': 'K'
    }

    def step(self, state, inputs, params):
        # 调用改进的PDD单步计算
        new_state = simulate_pdd_step_parallel(
            state,
            inputs['temp'],
            inputs['prec'],
            inputs['stdv'],
            params
        )
        # 输出融雪径流 (示例)
        snow_depth = new_state[:, 0]
        outputs = {
            'melt_runoff': snow_depth * 0.8  # 简化示例，实际应根据模型计算
        }
        return new_state, outputs


# 初始化耦合模型 ---------------------------------------------------------

# 配置连接关系：XAJ的降水输入 = 外部降水 + PDD的融雪径流
coupled_system = CoupledModel([
    (PDDModule(),  # 模块0: PDD
     {'temp': 'external_temp',  # 外部温度输入
      'prec': 'external_prec',  # 外部降水输入
      'stdv': 'external_stdv'},
     {'melt_runoff': 'm/year'}),  # 输出定义

    (XAJModule(),  # 模块1: XAJ
     {'rain': (0, 'melt_runoff'),  # 来自PDD的输出
      'em': 'external_em'},  # 外部蒸发输入
     {'surface_runoff': 'mm/day'})  # 输出定义
])

# 使用示例 --------------------------------------------------------------

# 初始状态
pdd_state = np.zeros((100, 2))  # 100个样本，PDD两个状态变量
xaj_state = np.zeros((100, 8))  # XAJ八个状态变量
states = [pdd_state, xaj_state]

# 外部输入
external_inputs = {
    'external_temp': np.random.rand(100) * 10,  # degC
    'external_prec': np.random.rand(100) * 2,  # m/year
    'external_stdv': np.random.rand(100) * 1.5,  # K
    'external_em': np.random.rand(100) * 5  # mm/day
}

# 参数
params = {
    'xaj_kc': np.full(100, 0.8),
    'pdd_factor': np.full(100, 0.003),
    # ...其他参数
}

# 执行耦合计算
new_states = coupled_system.step(states, external_inputs, params)

# 结果验证
print("PDD新状态形状:", new_states[0].shape)  # 应保持(100, 2)
print("XAJ新状态形状:", new_states[1].shape)  # 应保持(100, 8)

