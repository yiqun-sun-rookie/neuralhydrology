import numpy as np

def redistribute_soil_water(
    w: np.ndarray,
    wu: np.ndarray,
    wl: np.ndarray,
    wd: np.ndarray,
    wm: np.ndarray,
    wum: np.ndarray,
    wlm: np.ndarray,
    wdm: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    将多余水量 water_extra 在三层土壤含水量 wu、wl、wd 之间重新分配（矢量化版本）。
    适配批量/并行计算，即 w、wu、wl、wd 等均可为 shape=(N,) 的数组。

    Parameters
    ----------
    w, wu, wl, wd : np.ndarray
        当前各成员的 w(总土壤水量)、wu(上层)、wl(中层)、wd(深层)。
        形状应相同，比如 (N_ensemble,).
    wm, wum, wlm, wdm : np.ndarray
        对应的容量上限：wm(总容量)，wum(上层容量)，wlm(中层容量)，wdm(深层容量)。
        与上述数组形状相同。

    Returns
    -------
    w, wu, wl, wd : np.ndarray
        更新后的各层含水量。
    """

    # 1) 将 w 限制在 [0, wm] 内
    w = np.clip(w, 0.0, wm)

    # 2) 计算剩余水量 (可能为正，也可能为负)
    water_extra = w - (wu + wl + wd)

    # 3) 针对 water_extra > 1e-4 的成员，依次向 wu, wl, wd 填充
    mask_pos = (water_extra > 1e-4)
    if np.any(mask_pos):
        # 3.1 填充上层
        possible = (wum[mask_pos] - wu[mask_pos])     # 上层剩余可填
        take = np.minimum(water_extra[mask_pos], possible)
        wu[mask_pos] += take
        water_extra[mask_pos] -= take

        # 3.2 填充中层
        possible = (wlm[mask_pos] - wl[mask_pos])
        take = np.minimum(water_extra[mask_pos], possible)
        wl[mask_pos] += take
        water_extra[mask_pos] -= take

        # 3.3 填充深层
        possible = (wdm[mask_pos] - wd[mask_pos])
        take = np.minimum(water_extra[mask_pos], possible)
        wd[mask_pos] += take
        water_extra[mask_pos] -= take

    # 4) 针对 water_extra < -1e-4 的成员，需要从 wu, wl, wd 中依次“回补”
    mask_neg = (water_extra < -1e-4)
    if np.any(mask_neg):
        # 4.1 从上层 (wu) 回补
        possible = wu[mask_neg]  # 上层中可被消耗的量
        take = np.minimum(-water_extra[mask_neg], possible)
        wu[mask_neg] -= take
        water_extra[mask_neg] += take

        # 4.2 从中层 (wl) 回补
        possible = wl[mask_neg]
        take = np.minimum(-water_extra[mask_neg], possible)
        wl[mask_neg] -= take
        water_extra[mask_neg] += take

        # 4.3 从深层 (wd) 回补
        possible = wd[mask_neg]
        take = np.minimum(-water_extra[mask_neg], possible)
        wd[mask_neg] -= take
        water_extra[mask_neg] += take

    # 5) 为安全起见，再次将三层含水量限制在 [0, 各自容量] 内
    wu = np.clip(wu, 0.0, wum)
    wl = np.clip(wl, 0.0, wlm)
    wd = np.clip(wd, 0.0, wdm)

    return w, wu, wl, wd

def calc_runoff(
    w: np.ndarray,
    wmm: np.ndarray,
    wm: np.ndarray,
    b: np.ndarray,
    pe: np.ndarray
) -> np.ndarray:
    """
    计算产流 (runoff)。

    NOTE: In this implementation, imp (impervious area fraction) does NOT generate
    direct runoff. It only modulates wmm = wm * (1 + b) / (1 - imp), affecting
    the storage capacity curve. For urban basins with significant impervious areas,
    consider using the ShanBei (Horton infiltration) model instead.

    Parameters
    ----------
    w : np.ndarray
        土壤水总量 (wu + wl + wd) (N,)
    wmm, wm, b : np.ndarray
        一些模型参数 (N,); wmm is pre-computed as wm*(1+b)/(1-imp)
    pe : np.ndarray
        有效降雨 (rain - ep) (N,)

    Returns
    -------
    runoff : np.ndarray
        产流 (N,)
    """
    wm_safe = np.clip(wm, 1e-12, None)
    frac = np.clip(1 - w / wm_safe, 0.0, 1.0)
    # w_temp 只是中间变量，无需返回
    w_temp = wmm * (1 - frac ** (1 / (1 + b)))

    runoff = np.zeros_like(pe)
    mask_pe_pos = (pe > 0)
    if np.any(mask_pe_pos):
        mask1 = mask_pe_pos & ((w_temp + pe) <= wmm)
        if np.any(mask1):
            runoff[mask1] = (
                pe[mask1]
                + w[mask1]
                - wm[mask1]
                + wm[mask1] * (
                    1 - (pe[mask1] + w_temp[mask1]) / wmm[mask1]
                ) ** (1 + b[mask1])
            )
        mask2 = mask_pe_pos & (~mask1)
        if np.any(mask2):
            runoff[mask2] = pe[mask2] + w[mask2] - wm[mask2]

    return runoff

def update_soil_layers(
    wu: np.ndarray,
    wl: np.ndarray,
    wd: np.ndarray,
    runoff: np.ndarray,
    rain: np.ndarray,
    ep: np.ndarray,
    wum: np.ndarray,
    wlm: np.ndarray,
    wdm: np.ndarray,
    c: np.ndarray
) -> tuple[
    np.ndarray,  # w
    np.ndarray,  # new_wu
    np.ndarray,  # new_wl
    np.ndarray,  # new_wd
    np.ndarray,  # e
    np.ndarray,  # eu
    np.ndarray   # el
    , np.ndarray # ed
]:
    """
    参数
    ----
    wu, wl, wd: 各层初始土壤水量
    runoff:     地表产流（扣减有效入渗）
    rain:       降雨量
    ep:         蒸发力
    wum, wlm, wdm: 上/中/深三层最大容量
    c:          土壤蒸发折减系数
    返回
    ----
    w:          总土壤水量(new_wu+new_wl+new_wd)
    new_wu, new_wl, new_wd: 更新后的各层水量
    e:          总蒸发量(eu+el+ed)
    eu, el, ed: 分层蒸发量
    """
    pe = rain - ep  # 有效降雨(可正可负)
    # water_extra: 可分配到土壤层的剩余水量(扣减产流后)
    water_extra = np.maximum(pe - runoff, 0.0)

    N = len(pe)  # 假设输入长度一致
    eu = np.zeros(N, dtype=pe.dtype)
    el = np.zeros(N, dtype=pe.dtype)
    ed = np.zeros(N, dtype=pe.dtype)

    # 拷贝初始土壤水量，后续逐步更新
    new_wu = np.copy(wu)
    new_wl = np.copy(wl)
    new_wd = np.copy(wd)

    # --------------------
    # 分支1：pe > 0  (净入水)
    # --------------------
    mask_pos = (pe > 0)
    if np.any(mask_pos):
        # 找到所有满足 pe>0 的全局下标:
        idx_pos = np.where(mask_pos)[0]

        # eu = ep, el=0, ed=0
        eu[idx_pos] = ep[idx_pos]

        # STEP1: 上层分配
        wu_plus = new_wu[idx_pos] + water_extra[idx_pos]  # 给上层的潜在水量
        over_mask_1 = (wu_plus > wum[idx_pos])            # 是否超过上层容量
        idx_over1 = idx_pos[over_mask_1]                 # 全局下标(上层超)
        idx_noover1 = idx_pos[~over_mask_1]              # 全局下标(上层没超)

        # 超量部分 -> 上层设为容量上限
        new_wu[idx_over1] = wum[idx_over1]
        # 没超量部分 -> 直接更新
        new_wu[idx_noover1] = wu_plus[~over_mask_1]

        # 计算"真正下渗到中层"的水量 water_extra_1
        water_extra_1 = np.zeros_like(wu_plus)
        # 对那些上层超量的元素，water_extra_1 = 超过量
        water_extra_1[over_mask_1] = wu_plus[over_mask_1] - wum[idx_pos][over_mask_1]

        # STEP2: 中层分配
        wl_plus = new_wl[idx_pos] + water_extra_1
        over_mask_2 = (wl_plus > wlm[idx_pos])
        idx_over2 = idx_pos[over_mask_2]
        idx_noover2 = idx_pos[~over_mask_2]

        new_wl[idx_over2] = wlm[idx_over2]
        new_wl[idx_noover2] = wl_plus[~over_mask_2]

        # 计算"真正能下渗到深层"的水量 water_extra_2
        water_extra_2 = np.zeros_like(wl_plus)
        water_extra_2[over_mask_2] = wl_plus[over_mask_2] - wlm[idx_pos][over_mask_2]

        # STEP3: 深层分配
        wd_plus = new_wd[idx_pos] + water_extra_2
        over_mask_3 = (wd_plus > wdm[idx_pos])
        idx_over3 = idx_pos[over_mask_3]
        idx_noover3 = idx_pos[~over_mask_3]

        new_wd[idx_over3] = wdm[idx_over3]
        new_wd[idx_noover3] = wd_plus[~over_mask_3]
        # 额外超出的 over_amt_3 在这里就相当于下渗深层也超了容量，按原逻辑可能是多余出流

    # --------------------
    # 分支2：pe <= 0 (净蒸发消耗)
    # --------------------
    mask_neg = (pe <= 0)
    if np.any(mask_neg):
        # 2.1) 子分支: if wu + rain > ep
        cond = (new_wu[mask_neg] + rain[mask_neg]) > ep[mask_neg]
        idxA = np.where(mask_neg & cond)[0]  # 满足 wu+rain>ep 的全局下标
        if idxA.size > 0:
            # eu=ep, el=0, ed=0
            eu[idxA] = ep[idxA]
            # 更新 wu = wu + pe (pe<0 代表抽走水)
            new_wu[idxA] = new_wu[idxA] + pe[idxA]
            # wl, wd 不变; el, ed=0

        # 2.2) 子分支: else (wu+rain <= ep)
        idxB = np.where(mask_neg & ~cond)[0]
        if idxB.size > 0:
            # eu = wu + rain
            eu[idxB] = new_wu[idxB] + rain[idxB]
            new_wu[idxB] = 0.0

            # 继续看中层和深层的情况
            remainder = ep[idxB] - eu[idxB]  # 还差多少蒸发量(>0 或 =0)

            # (a) wl >= c.*wlm
            condA = (new_wl[idxB] >= c[idxB] * wlm[idxB])
            idxA2 = idxB[condA]
            if idxA2.size > 0:
                el[idxA2] = np.abs(remainder[idxA2] * new_wl[idxA2] / wlm[idxA2])
                new_wl[idxA2] = new_wl[idxA2] - el[idxA2]

            # (b) wl >= c .* (ep-eu)
            condB = ~condA & (new_wl[idxB] >= c[idxB] * np.abs(remainder))
            idxB2 = idxB[condB]
            if idxB2.size > 0:
                el[idxB2] = c[idxB2] * np.abs(remainder[idxB2])
                new_wl[idxB2] = new_wl[idxB2] - el[idxB2]

            # (c) 否则 => el=wl, ed=abs(c.*(ep-eu)-el), wl=0, wd=wd-ed
            idxC2 = idxB[~condA & ~condB]
            if idxC2.size > 0:
                el[idxC2] = new_wl[idxC2]
                new_wl[idxC2] = 0.0
                ed[idxC2] = np.abs(c[idxC2] * remainder[idxC2] - el[idxC2])
                new_wd[idxC2] = new_wd[idxC2] - ed[idxC2]

    # 最后 clip 避免负水量或超上限
    new_wu = np.clip(new_wu, 0, wum)
    new_wl = np.clip(new_wl, 0, wlm)
    new_wd = np.clip(new_wd, 0, wdm)

    # 重新计算总土壤水量 w 和总蒸发量 e
    w = new_wu + new_wl + new_wd
    e = eu + el + ed

    return w, new_wu, new_wl, new_wd, e

def update_soil_moisture(
    wu: np.ndarray,
    wl: np.ndarray,
    wd: np.ndarray,
    rain: np.ndarray,
    ep: np.ndarray,
    wmm: np.ndarray,
    wm:  np.ndarray,
    b:   np.ndarray,
    wum: np.ndarray,
    wlm: np.ndarray,
    wdm: np.ndarray,
    c:   np.ndarray
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    主函数：相当于将原 get_next_wu_wl_wd_r_eu_el_ed 拆分为两步:
      1) 先调用 calc_runoff
      2) 再调用 update_soil_layers
      3) 最后组合输出

    输出参数顺序与原 MATLAB 版本不一致:
      [w, wu, wl, wd, runoff, e]
    """
    # 3) 有效降雨
    pe = rain - ep
    # (A) 先产流
    runoff = calc_runoff(wu + wl + wd, wmm, wm, b, pe)
    # (B) 再更新土壤水层 + 各层蒸发
    w_new, wu_new, wl_new, wd_new, e = update_soil_layers(
        wu, wl, wd, runoff, rain, ep, wum, wlm, wdm, c)
    # 组合输出
    return w_new, wu_new, wl_new, wd_new, runoff, e

def update_free_water_storage(
        s: np.ndarray,
        runoff: np.ndarray,
        pe: np.ndarray,
        ki: np.ndarray,
        kg: np.ndarray,
        ms: np.ndarray,
        sm: np.ndarray,
        ex: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    矢量化版本的 get_next_s_rs_ri_rg_fr，
    计算下一时刻的自由水储量 s 及其分流 rs, ri, rg, fr。

    Parameters
    ----------
    s : np.ndarray
        当前时刻的自由水储量 (N,)。
    runoff : np.ndarray
        当前时刻总产流量 (N,)。
    pe : np.ndarray
        有效降水 (rain - ep) 或类似量 (N,)。
    ki, kg : np.ndarray
        分流系数 (N,)。
    ms : np.ndarray
        参数 ms (N,)。
    sm : np.ndarray
        自由水储量上限 (N,)。
    ex : np.ndarray
        指数参数 (N,)。

    Returns
    -------
    s : np.ndarray
        更新后的自由水储量 (N,)。
    rs : np.ndarray
        表面流 (N,)。
    ri : np.ndarray
        中速流 (N,)。
    rg : np.ndarray
        慢速流 (N,)。
    fr : np.ndarray
        比例因子 (N,)。
    """
    # 0) 先拷贝 s，以免修改原数组
    s_new = np.copy(s)

    # 1) 限制 s 不超过 sm
    s_new = np.minimum(sm, s_new)
    #    s = s .* (1 - ki - kg)
    s_new = s_new * (1 - ki - kg)

    # 2) s_temp = ms * (1 - (1 - s_new/sm)^(1/(1+ex)))
    #    (注意下，这里可能后面还要跟 pe 一起计算 rs，但先把 s_temp 算好)
    #    但从你后面逻辑看，好像只是用来跟 pe 做比较?
    sm_safe = np.clip(sm, 1e-12, None)
    frac = np.clip(1 - s_new / sm_safe, 0.0, 1.0)  # 避免负数
    s_temp = ms * (1 - frac ** (1 / (1 + ex)))

    # 3) fr = min(1, runoff/pe) if runoff>0, else 0
    #    这里需要针对向量：若 runoff[i]>0 则 fr[i] = min(1, runoff[i]/pe[i])，否则=0
    fr = np.zeros_like(pe)
    mask_runoff_pos = (runoff > 0)
    if np.any(mask_runoff_pos):
        # 对于 pe <= 0 的情况，如果 runoff>0 但 pe<=0，会出现负除法;
        # 可能需要你根据实际机理判断，这里与原文一致 => fr = min(1, runoff/pe)?
        # 先用 safe_division
        ratio = np.zeros_like(pe)
        mask_pe_pos = (pe > 1e-12)  # 避免除0
        valid_mask = mask_runoff_pos & mask_pe_pos
        ratio[valid_mask] = runoff[valid_mask] / pe[valid_mask]

        # fr = min(1, ratio)
        fr[valid_mask] = np.minimum(1.0, ratio[valid_mask])

        # 对于 runoff>0 & pe<=0 的成员 => fr=0 (可视情况调整)
        # 原 MATLAB 里是 if runoff>0 => fr= min(1, runoff/pe), else fr=0
        # 若 pe<=0 => runoff/pe 负 => min(1,负) => 负 => 还是0?
        # 这里就按照
        #   if pe>0 => fr=...
        #   else => fr=0
        # 这样
        fr[mask_runoff_pos & (~mask_pe_pos)] = 0

    # 4) 计算表面流 rs
    #    if runoff>0 ...
    rs = np.zeros_like(pe)
    if np.any(mask_runoff_pos):
        # 4.1) if (pe + s_temp) < ms =>
        #         rs = fr * (pe + s_new - sm + sm*((1 - (pe + s_temp)/ms)^(1+ex)))
        mask_cond1 = mask_runoff_pos & ((pe + s_temp) < ms)
        if np.any(mask_cond1):
            rs[mask_cond1] = (
                    fr[mask_cond1]
                    * (
                            (pe[mask_cond1] + s_new[mask_cond1])
                            - sm[mask_cond1]
                            + sm[mask_cond1]
                            * (
                                    1 - ((pe[mask_cond1] + s_temp[mask_cond1]) / ms[mask_cond1])
                            ) ** (1 + ex[mask_cond1])
                    )
            )
        # 4.2) else => rs = fr * (pe + s_new - sm)
        mask_cond2 = mask_runoff_pos & (~mask_cond1)
        if np.any(mask_cond2):
            rs[mask_cond2] = fr[mask_cond2] * (pe[mask_cond2] + s_new[mask_cond2] - sm[mask_cond2])

        # (检查是否是实数, np.isreal(rs) 返回 True/False 数组)
        # if isreal(rs) else error
        if not np.all(np.isreal(rs)):
            raise ValueError("r_surface is not real")

        # 4.3) 更新 s: s = min(s + pe - rs/fr, sm)
        #      并保证 s >= 0
        #      只有当 fr>0 才能做 rs/fr, 否则要避免除零
        s_add = np.copy(s_new)
        mask_fr_positive = (fr > 1e-12)
        # safe_division
        ratio_rs = np.zeros_like(rs)
        valid_fr_mask = mask_fr_positive & mask_runoff_pos
        ratio_rs[valid_fr_mask] = rs[valid_fr_mask] / fr[valid_fr_mask]

        s_add[mask_runoff_pos] = s_new[mask_runoff_pos] + pe[mask_runoff_pos] - ratio_rs[mask_runoff_pos]
        # s = min(..., sm), max(...,0)
        s_add = np.clip(s_add, 0, sm)
        s_new = s_add
    else:
        # if runoff <= 0 => rs=0, s = min(sm,s), s=max(0,s)
        rs[:] = 0
        s_new = np.minimum(sm, s_new)
        s_new = np.maximum(0, s_new)

    # 5) ri = ki*s*fr, rg= kg*s*fr
    ri = ki * s_new * fr
    rg = kg * s_new * fr

    return s_new, rs, ri, rg, fr

def update_qs_qi_qg(
        qs: np.ndarray,
        qi: np.ndarray,
        qg: np.ndarray,
        rs: np.ndarray,
        ri: np.ndarray,
        rg: np.ndarray,
        cs: np.ndarray,
        ci: np.ndarray,
        cg: np.ndarray,
        uf: np.ndarray
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    矢量化版本的 get_next_qs_qi_qg。
    用于将表面流 rs、中速流 ri、慢速流 rg 转化为各汇流分量 qs, qi, qg。

    Parameters
    ----------
    qs, qi, qg : np.ndarray
        上一步的快速流、中速流、慢速流储量
    rs, ri, rg : np.ndarray
        这一时刻的表面流、中速流、慢速流输入
    cs, ci, cg : np.ndarray
        模型参数
    uf : np.ndarray
        传输系数 (或缩放因子)

    Returns
    -------
    qs_new, qi_new, qg_new : np.ndarray
        更新后的快速流、中速流、慢速流储量
    """
    # 拷贝以免修改原数组
    qs_new = cs * qs + (1 - cs) * rs * uf
    qi_new = ci * qi + (1 - ci) * ri * uf
    qg_new = cg * qg + (1 - cg) * rg * uf

    return qs_new, qi_new, qg_new


