import numpy as np
from src.kernels.core.hydro_model.process_model.positive_degree_day.my_degree_day import simulate_pdd_step_parallel
from src.kernels.core.hydro_model.process_model.xinanjiang.numpy.xaj_main import xaj_step_vec
import pandas as pd
def coupled_pdd_xaj_step_vec(
        joint_state: np.ndarray,
        temp: np.ndarray,
        prec: np.ndarray,
        em: np.ndarray,
        pdd_params: dict,
        xaj_params: dict
) -> np.ndarray:
    """
    耦合PDD融雪模型与XAJ产流模型的单步计算（矢量化并行版）

    Args:
        joint_state: shape (N, 11) 联合状态向量
            [snow_depth, ice_depth, last_temp（PDD部分）, XAJ的8个状态]
        temp: shape (N,) 日平均气温 (°C)
        prec: shape (N,) 日降水 (m/day)
        em: shape (N,) 日蒸发能力 (m/day)
        pdd_params: PDD模型参数字典，参数为shape (N,)的数组
        xaj_params: XAJ模型参数字典，参数为shape (N,)的数组

    Returns:
        new_state: shape (N, 11) 更新后的联合状态
        total_runoff: shape (N,) 总径流量 (m)
    """
    # 确保输入为二维数组（兼容单单元场景）
    joint_state = np.atleast_2d(joint_state)

    # --- 拆分联合状态 ---
    pdd_state = joint_state[:, :3]  # (N, 3)
    xaj_state = joint_state[:, 3:]  # (N, 8)

    # --- 执行PDD融雪计算 ---
    new_pdd_state, pdd_runoff = simulate_pdd_step_parallel(
        state=pdd_state,
        temp=temp,
        prec=prec,
        param_dict=pdd_params
    )

    xaj_params_df = pd.DataFrame({
        k: np.asarray(v).flatten()  # 确保参数为1D数组
        for k, v in xaj_params.items()
    })

    # --- 执行XAJ产流计算 ---
    # 注意：XAJ的降雨输入使用PDD计算的径流，单位为m
    new_xaj_state = xaj_step_vec(state=xaj_state, rain=pdd_runoff * 1000, em=em, param_dict=xaj_params_df)

    # --- 合并新状态 ---
    new_state = np.hstack([new_pdd_state, new_xaj_state])

    return new_state

