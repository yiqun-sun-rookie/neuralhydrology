import numpy as np
def simulate_pdd_step_parallel(
        state: np.ndarray,
        temp: np.ndarray,
        prec: np.ndarray,
        param_dict: dict
) -> np.ndarray:
    """
    PDD 单步计算（矢量化并行版），输入为日尺度

    Args:
        state: shape (N, 3) 联合状态向量 [snow_depth, ice_depth, last_temp]
        temp: shape (N,) 日平均气温 (°C)
        prec_m: shape (N,) 日降水 (mm/)
        param_dict: 包含PDD参数的字典，每个参数为shape (N,)的数组

    Returns:
        new_state: shape (N, 3) 更新后的状态
        runoff: shape (N,) 日径流量 (m)
    """
    # 解包参数
    pdd_factor_snow = get_param(param_dict["pdd_factor_snow"])  # mm/°C/day
    pdd_factor_ice = get_param(param_dict["pdd_factor_ice"])  # mm/°C/day
    refreeze_snow = get_param(param_dict["refreeze_snow"])  # 无量纲 [0-1]
    refreeze_ice = get_param(param_dict["refreeze_ice"])  # 无量纲 [0-1]
    temp_snow = get_param(param_dict["temp_snow"])  # °C
    temp_rain = get_param(param_dict["temp_rain"])  # °C

    # 拆分状态
    snow_depth, ice_depth, last_temp = state[:, 0], state[:, 1], state[:, 2]

    # --- 核心计算步骤 ---
    prec_m = prec / 1000  # mm -> m

    # 1. 计算降雪比例（温度相关）
    snow_frac = np.clip((temp_rain - temp) / (temp_rain - temp_snow), 0, 1)
    snowfall = snow_frac * prec_m  # 降雪量 (m)

    rainfall = prec_m - snowfall  # 降雨量 (m)

    # 2. 积雪积累（转换为m water equivalent）
    snow_depth += snowfall

    # 3. 计算正积温（简化版，忽略温度标准差）
    pdd = np.maximum(temp, 0.0)  # 日正积温 (°C·day)

    # 4. 融雪计算（mm转换为m）
    pot_snow_melt = pdd_factor_snow * pdd / 1000  # m/day
    actual_snow_melt = np.minimum(snow_depth, pot_snow_melt)

    # 5. 融冰计算（剩余能量）
    remaining_energy = (pot_snow_melt - actual_snow_melt) * 1000  # mm
    ice_melt = remaining_energy * pdd_factor_ice / pdd_factor_snow / 1000  # m

    # 6. 更新雪冰状态（考虑再冻结）
    snow_depth -= actual_snow_melt
    refrozen_snow = actual_snow_melt * refreeze_snow
    snow_depth += refrozen_snow

    ice_melt_net = np.maximum(ice_melt - ice_depth, 0)  # 不能融化超过现有冰量
    ice_depth -= ice_melt_net
    refrozen_ice = ice_melt_net * refreeze_ice
    ice_depth += refrozen_ice

    # 7. 计算径流（总融化量 - 再冻结量）
    total_melt = actual_snow_melt + ice_melt_net
    runoff = total_melt - refrozen_snow - refrozen_ice + rainfall

    # 8. 更新状态（记录当日温度供次日使用）
    new_state = np.column_stack([
        np.maximum(snow_depth, 0),
        np.maximum(ice_depth, 0),
        temp  # 记录当日温度
    ])

    return new_state, runoff


def daily_to_hourly_runoff(daily_runoff, hourly_temp):
    """
    将日径流分配为小时尺度（考虑日温度波动）

    Args:
        daily_runoff: 日总径流量 (m)
        hourly_temp: 当日24小时温度序列 (°C)

    Returns:
        hourly_runoff: 小时径流分配 (m)
    """
    # 生成权重：按小时温度正比例分配
    temp_pos = np.maximum(hourly_temp, 0)
    weights = temp_pos / np.sum(temp_pos)

    # 处理零权重情况（均匀分配）
    if np.any(np.isnan(weights)):
        weights = np.ones_like(weights) / len(weights)

    return daily_runoff * weights


def get_param(param_value):
    """参数获取统一函数（与XAJ兼容）"""
    if isinstance(param_value, np.ndarray):
        return param_value
    elif hasattr(param_value, 'to_numpy'):
        return param_value.to_numpy()
    else:
        return np.array(param_value)

