"""
Vectorized VerticallyMixed production model step function.
Signature aligned with xaj_step_vec for drop-in replacement.

Pipeline: VM production → shared free water storage → shared linear reservoir.
"""
import numpy as np

from src.kernels.core.hydro_model.process_model.xinanjiang.numpy.xaj_fcns import (
    update_free_water_storage,
    update_qs_qi_qg,
)


def _get_param(v):
    if isinstance(v, np.ndarray):
        return v
    elif hasattr(v, "to_numpy"):
        return v.to_numpy()
    return np.asarray(v)


def vm_step_vec(
    state: np.ndarray,
    rain: np.ndarray,
    pet: np.ndarray,
    param_dict: dict,
) -> np.ndarray:
    """
    VerticallyMixed single-step vectorized.

    Parameters
    ----------
    state : (N, 8)  -- [W, (unused x3), S, QS, QI, QG]
    rain  : (N,)    -- rainfall from PDD (mm)
    pet   : (N,)    -- potential ET (mm)
    param_dict : dict with keys kc, fc, kf, wm, bf, b, sm, ex, cs, ci, cg, ki, kg, uf

    Returns
    -------
    new_state : (N, 8)
    """
    # Unpack state
    w = state[:, 0].copy()
    s = state[:, 4].copy()  # free water storage
    qs = state[:, 5].copy()
    qi = state[:, 6].copy()
    qg = state[:, 7].copy()

    # Unpack params
    kc = _get_param(param_dict["kc"])
    fc = _get_param(param_dict["fc"])
    kf = _get_param(param_dict["kf"])
    wm = _get_param(param_dict["wm"])
    bf = _get_param(param_dict["bf"])
    b = _get_param(param_dict["b"])
    sm = _get_param(param_dict["sm"])
    ex = _get_param(param_dict["ex"])
    cs = _get_param(param_dict["cs"])
    ci = _get_param(param_dict["ci"])
    cg = _get_param(param_dict["cg"])
    ki = _get_param(param_dict["ki"])
    kg = _get_param(param_dict["kg"])
    uf = _get_param(param_dict["uf"])

    wmm = wm * (1 + b)
    ms = sm * (1 + ex)

    # --- VM Production (different from XAJ) ---

    # 1. Evaporation: E = KC * PET * (W / WM)
    w_safe = np.maximum(w, 0.0)
    wm_safe = np.maximum(wm, 1e-12)
    evap = np.where(w_safe > 0, kc * pet * (w_safe / wm_safe), 0.0)
    evap = np.minimum(evap, w_safe)

    # 2. Net rainfall
    pe = np.maximum(rain - evap, 0.0)

    # 3. Infiltration-excess (parabolic infiltration distribution curve)
    fm = fc * (1 + kf * (wm - w_safe) / wm_safe)
    fmm = fm * (1 + bf)
    fmm_safe = np.maximum(fmm, 1e-12)

    ratio_f = np.clip(pe / fmm_safe, 0.0, 1.0)
    fa = np.where(pe < fmm, fm * (1 - (1 - ratio_f) ** (1 + bf)), fm)
    rs_infil = pe - fa  # infiltration excess surface runoff

    # 4. Saturation-excess (tension water storage capacity curve)
    wmm_safe = np.maximum(wmm, 1e-12)
    frac_w = np.clip(w_safe / wm_safe, 0.0, 1.0)
    w_point = wmm * (1 - (1 - frac_w) ** (1 / (1 + b)))

    cond = (fa + w_point) < wmm
    rr = np.where(
        cond,
        fa - wm + w_safe + wm * np.maximum(1 - (w_point + fa) / wmm_safe, 0.0) ** (1 + b),
        fa - wm + w_safe,
    )
    rr = np.maximum(rr, 0.0)

    # 5. Total production runoff
    runoff = rs_infil + rr

    # 6. Update soil moisture
    w_new = np.clip(w_safe + pe - runoff, 0.0, wm)

    # --- Shared: free water storage + linear reservoir (same as XAJ) ---

    # 7. Free water storage splits runoff into RS, RI, RG
    s_new, rs, ri, rg, _fr = update_free_water_storage(
        s, runoff, pe, ki, kg, ms, sm, ex,
    )

    # 8. Linear reservoir routing
    qs_new, qi_new, qg_new = update_qs_qi_qg(
        qs, qi, qg, rs, ri, rg, cs, ci, cg, uf,
    )

    # 9. Assemble state
    new_state = np.column_stack([
        w_new,
        np.zeros_like(w),  # WU placeholder
        np.zeros_like(w),  # WL placeholder
        np.zeros_like(w),  # WD placeholder
        s_new,
        qs_new, qi_new, qg_new,
    ])
    return new_state
