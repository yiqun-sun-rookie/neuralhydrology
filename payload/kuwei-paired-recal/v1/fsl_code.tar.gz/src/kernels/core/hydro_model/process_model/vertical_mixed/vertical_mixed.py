"""
竖向混合产流模型 (Vertically Mixed Runoff Model)

超渗产流（下渗分布曲线）+ 蓄满产流（张力水蓄水容量曲线）的竖向混合方案。
先用下渗能力分布分离地面径流，再用蓄水容量曲线分离壤中流/地下径流。
"""
import numpy as np


class VerticallyMixedModel:
    def __init__(self, kc: float, fc: float, kf: float, wm: float, bf: float, b: float,
                 cs: float, ci: float, cg: float, ki: float, kg: float, ke: float, xe: float):
        # --- 蒸发 ---
        self.kc = kc    # 蒸散发折算系数
        # --- 下渗 ---
        self.fc = fc    # 稳定下渗率
        self.kf = kf    # 渗透系数（控制下渗率随土含变化）
        # --- 蓄水容量曲线 ---
        self.wm = wm    # 最大土壤含水量
        self.b = b      # 蓄水容量曲线指数
        self.wmm = self.wm * (1 + self.b)   # 单点最大蓄水容量
        # --- 下渗分布曲线 ---
        self.bf = bf    # 下渗分布曲线指数
        # --- 水源划分 ---
        self.ki = ki    # 壤中流出流系数
        self.kg = kg    # 地下径流出流系数
        # --- 汇流（线性水库） ---
        self.cs = cs    # 地面径流消退系数
        self.ci = ci    # 壤中流消退系数
        self.cg = cg    # 地下径流消退系数
        # --- 马斯京根 ---
        self.ke = ke    # 河段传播时间 K
        self.xe = xe    # 流量比重系数 x

        # ---- FIX-6: ki+kg 约束检查 ----
        if ki + kg > 1.0 + 1e-9:
            raise ValueError(f"ki + kg = {ki + kg:.4f} > 1.0, 水量不守恒")

    # ------------------------------------------------------------------ #
    #  蒸发计算
    # ------------------------------------------------------------------ #
    def evaporation_cal(self, water_storage: float, evap_water: float) -> float:
        """
        单层蒸发：E_actual = KC * E_pan * (W / WM)

        :param water_storage: 前一时刻土壤含水量 W (mm)
        :param evap_water: 水面蒸发 / 潜在蒸散发 (mm)
        :return: 实际蒸发 (mm)
        """
        # FIX-5: 浮点安全比较
        if water_storage <= 0:
            return 0.0
        evap_actual = self.kc * evap_water * (water_storage / self.wm)
        return min(evap_actual, water_storage)

    # ------------------------------------------------------------------ #
    #  产流计算
    # ------------------------------------------------------------------ #
    def runoff_cal(self, rainfall: float, evap_actual: float, water_storage: float):
        """
        竖向混合产流：
        1) 超渗 → 地面径流 rs
        2) 蓄满 → 壤中流 ri + 地下径流 rg

        :param rainfall: 本时刻降雨量 (mm)
        :param evap_actual: 本时刻实际蒸发量 (mm)
        :param water_storage: 前一时刻土壤含水量 W (mm)
        :return: (rs, ri, rg, water_storage_new)
        """
        pe = max(rainfall - evap_actual, 0.0)

        # --- 1. 超渗产流（下渗能力抛物线分布）---
        fm = self.fc * (1 + self.kf * (self.wm - water_storage) / self.wm)
        fmm = fm * (1 + self.bf)

        if pe < fmm:
            fa = fm * (1 - (1 - pe / fmm) ** (1 + self.bf))
        else:
            fa = fm
        rs = pe - fa   # 地面径流

        # --- 2. 蓄满产流（张力水蓄水容量曲线）---
        w__ = self.wmm * (1 - (1 - water_storage / self.wm) ** (1 / (1 + self.b)))

        if fa + w__ < self.wmm:
            rr = fa - self.wm + water_storage + self.wm * (1 - (w__ + fa) / self.wmm) ** (1 + self.b)
        else:
            rr = fa - self.wm + water_storage

        ri = max(rr * self.ki, 0.0)
        rg = max(rr * self.kg, 0.0)

        # FIX-4: 加下界保护
        water_storage_new = max(0.0, min(self.wm, water_storage + pe - rs - rr))

        return rs, ri, rg, water_storage_new

    # ------------------------------------------------------------------ #
    #  马斯京根河道汇流
    # ------------------------------------------------------------------ #
    @staticmethod
    def _muskingum_coeffs(ke: float, xe: float, t_delta: float):
        """
        标准马斯京根系数 c0, c1, c2

        FIX-6: 引入 t_delta，不再隐含 Δt = K
        """
        denom = 0.5 * t_delta + ke * (1 - xe)
        c0 = (0.5 * t_delta - ke * xe) / denom
        c1 = (0.5 * t_delta + ke * xe) / denom
        c2 = (ke * (1 - xe) - 0.5 * t_delta) / denom
        return c0, c1, c2

    def maskingen_cal(self, q_0: float, i_0: float, i_1: float, t_delta: float = None):
        """
        单步马斯京根演算

        :param q_0: 前一时刻出流
        :param i_0: 前一时刻入流
        :param i_1: 本时刻入流
        :param t_delta: 计算步长 (h)；默认 None 时使用 ke（兼容旧行为）
        :return: 本时刻出流
        """
        dt = t_delta if t_delta is not None else self.ke
        c0, c1, c2 = self._muskingum_coeffs(self.ke, self.xe, dt)
        return c0 * i_1 + c1 * i_0 + c2 * q_0

    def single_maskingen(self, q_input_arr: np.ndarray, q_input0: float,
                         t_confluence: float, t_delta: float = None):
        """
        多河段马斯京根汇流演算

        :param q_input_arr: 入流过程 (1-D array)
        :param q_input0: 初始出流
        :param t_confluence: 河道汇流时间
        :param t_delta: 计算步长 (h)
        :return: 出流过程 (1-D array)
        """
        dt = t_delta if t_delta is not None else self.ke
        c0, c1, c2 = self._muskingum_coeffs(self.ke, self.xe, dt)

        q_output = np.zeros_like(q_input_arr)
        q_output[0] = q_input0
        n = max(1, int(t_confluence / self.ke))
        length = len(q_input_arr)

        q_in = q_input_arr.copy()
        for _ in range(n):
            for i in range(length - 1):
                q_output[i + 1] = c0 * q_in[i + 1] + c1 * q_in[i] + c2 * q_output[i]
            q_in = q_output.copy()

        return q_output


def confluence_cal(q_0, i_1, c, drainage_area=1, t_delta=1):
    """
    线性水库单元面积汇流

    :param q_0: 前一时刻出流 (m³/s)
    :param i_1: 本时刻入流 (产流深 mm 或流量 m³/s)
    :param c: 消退系数 (CS / CI / CG)
    :param drainage_area: 流域面积 (km²)，当 i_1 为流量时传 1
    :param t_delta: 计算步长 (h)
    :return: 汇流结果 (m³/s)
    """
    u = 1.0 if drainage_area == 1 else drainage_area / (3.6 * t_delta)
    return c * q_0 + (1 - c) * i_1 * u
