"""
Vectorized ShanBei production model step function.
Signature aligned with xaj_step_vec for drop-in replacement.

Pipeline: SB production (Horton) → shared free water storage → shared linear reservoir.
"""
import numpy as np

from src.kernels.core.hydro_model.process_model.xinanjiang.numpy.xaj_fcns import (
    update_free_water_storage,
    update_qs_qi_qg,
)


def _get_param(v):
    if isinstance(v, np.ndarray):
        return v
    elif hasattr(v, "to_numpy"):
        return v.to_numpy()
    return np.asarray(v)


def _build_horton_table(fc_s, f0_s, k_s, dt=0.5, error=0.001):
    """Pre-compute Horton t-theta-f table (scalar params, shared across cells)."""
    t_list, theta_list, f_list = [], [], []
    t = 0.0
    for _ in range(200000):
        theta = fc_s * t + (f0_s - fc_s) / k_s * (1 - np.exp(-k_s * t))
        f = fc_s + (f0_s - fc_s) * np.exp(-k_s * t)
        t_list.append(t)
        theta_list.append(theta)
        f_list.append(f)
        if f - fc_s <= error:
            break
        t += dt
    return np.array(t_list), np.array(theta_list), np.array(f_list)


def _horton_theta_t(t, fc, f0, k):
    """Cumulative infiltration F(t) -- vectorized."""
    return fc * t + (f0 - fc) / k * (1 - np.exp(-k * t))


def sb_step_vec(
    state: np.ndarray,
    rain: np.ndarray,
    pet: np.ndarray,
    param_dict: dict,
) -> np.ndarray:
    """
    ShanBei single-step vectorized.

    Parameters
    ----------
    state : (N, 8) -- [theta, (unused x3), S, QS, QI, QG]
    rain  : (N,)   -- rainfall from PDD (mm)
    pet   : (N,)   -- potential ET (mm)
    param_dict : dict with keys kc, wm, fb, fc, f0, horton_k, sm, ex, cs, ci, cg, ki, kg, uf

    Returns
    -------
    new_state : (N, 8)
    """
    N = state.shape[0]

    theta = state[:, 0].copy()
    s = state[:, 4].copy()  # free water storage
    qs = state[:, 5].copy()
    qi = state[:, 6].copy()
    qg = state[:, 7].copy()

    kc = _get_param(param_dict["kc"])
    wm = _get_param(param_dict["wm"])
    fb = _get_param(param_dict["fb"])
    fc = _get_param(param_dict["fc"])
    f0 = _get_param(param_dict["f0"])
    horton_k = _get_param(param_dict["horton_k"])
    sm = _get_param(param_dict["sm"])
    ex = _get_param(param_dict["ex"])
    cs = _get_param(param_dict["cs"])
    ci = _get_param(param_dict["ci"])
    cg = _get_param(param_dict["cg"])
    ki = _get_param(param_dict["ki"])
    kg = _get_param(param_dict["kg"])
    uf = _get_param(param_dict["uf"])

    ms = sm * (1 + ex)

    # 1. Evaporation
    evap = np.where(theta > 0, kc * pet * np.minimum(theta / wm, 1.0), 0.0)
    evap = np.minimum(evap, theta)

    net_rain = np.maximum(rain - evap, 0.0)
    pe = net_rain  # alias for free water storage

    # 2. Horton infiltration (use first cell's params for table -- basin-level)
    fc_s, f0_s, k_s = float(fc[0]), float(f0[0]), float(horton_k[0])
    t_arr, theta_arr, f_arr = _build_horton_table(fc_s, f0_s, k_s)

    # t_delta = 1 time step
    t_delta = 1.0

    # Lookup: theta -> (t1, f1)
    t1 = np.interp(theta, theta_arr, t_arr)
    f1 = np.interp(theta, theta_arr, f_arr)

    # Rainfall intensity
    i_rain = net_rain / t_delta

    # Initialize outputs
    theta_delta = np.zeros(N)
    runoff = np.zeros(N)

    # Case A: saturated soil
    mask_sat = theta >= wm
    runoff[mask_sat] = net_rain[mask_sat]

    # Case B: i >= f1 (supply-sufficient)
    mask_b = (~mask_sat) & (i_rain >= f1)
    if np.any(mask_b):
        td = _horton_theta_t(t1[mask_b] + t_delta, fc_s, f0_s, k_s) - \
             _horton_theta_t(t1[mask_b], fc_s, f0_s, k_s)
        theta_delta[mask_b] = td
        runoff[mask_b] = net_rain[mask_b] - td

    # Case C: i < f1 (supply-insufficient)
    mask_c = (~mask_sat) & (~mask_b)
    if np.any(mask_c):
        # Find transition time t_i where f(t_i) = i
        with np.errstate(divide="ignore", invalid="ignore"):
            ratio = np.clip((i_rain[mask_c] - fc_s) / (f0_s - fc_s), 1e-30, 1.0)
            t_i = np.where(i_rain[mask_c] > fc_s, -1/k_s * np.log(ratio), 1e6)

        dt_avail = t_i - t1[mask_c]

        # C1: entire period supply-insufficient
        mask_c1_local = dt_avail >= t_delta
        mask_c1 = np.zeros(N, dtype=bool)
        mask_c1[mask_c] = mask_c1_local
        theta_delta[mask_c1] = net_rain[mask_c1]

        # C2: partial supply-insufficient
        mask_c2_local = ~mask_c1_local
        mask_c2 = np.zeros(N, dtype=bool)
        mask_c2[mask_c] = mask_c2_local
        if np.any(mask_c2):
            dt_insuf = t_i[mask_c2_local] - t1[mask_c][mask_c2_local]
            td1 = i_rain[mask_c2] * dt_insuf
            theta_mid = theta[mask_c2] + td1
            t_mid = np.interp(theta_mid, theta_arr, t_arr)
            td2 = _horton_theta_t(t_mid + t_delta - dt_insuf, fc_s, f0_s, k_s) - \
                  _horton_theta_t(t_mid, fc_s, f0_s, k_s)
            theta_delta[mask_c2] = td1 + td2
            runoff[mask_c2] = i_rain[mask_c2] * (t_delta - dt_insuf) - td2

    # Update theta
    theta_new = np.clip(theta + theta_delta, 0.0, wm)
    # Account for impervious area
    runoff_total = np.maximum(runoff * (1 - fb) + net_rain * fb, 0.0)

    # Where saturated, theta stays at wm
    theta_new[mask_sat] = wm[mask_sat]

    # --- Shared: free water storage + linear reservoir (same as XAJ) ---

    # 3. Free water storage splits runoff into RS, RI, RG
    s_new, rs, ri, rg, _fr = update_free_water_storage(
        s, runoff_total, pe, ki, kg, ms, sm, ex,
    )

    # 4. Linear reservoir routing
    qs_new, qi_new, qg_new = update_qs_qi_qg(
        qs, qi, qg, rs, ri, rg, cs, ci, cg, uf,
    )

    # 5. Assemble
    new_state = np.column_stack([
        theta_new,
        np.zeros_like(theta),
        np.zeros_like(theta),
        np.zeros_like(theta),
        s_new,
        qs_new, qi_new, qg_new,
    ])
    return new_state
