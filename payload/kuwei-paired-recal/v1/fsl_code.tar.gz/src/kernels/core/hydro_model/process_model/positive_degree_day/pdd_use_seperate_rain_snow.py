import numpy as np
def pdd_use_seperate_rain_snow(
        state: np.ndarray,
        temp: np.ndarray,
        rain: np.ndarray,
        snow: np.ndarray,
        param_dict: dict
):
    """
    PDD 单步计算（矢量化并行版），输入为日尺度，所有量均使用 mm 作为单位。

    Args:
        state: shape (N, 3) 联合状态向量 [snow_depth, ice_depth, last_temp]
               其中 snow_depth、ice_depth 单位为 mm，last_temp 单位为 °C
        temp:  shape (N,)  日平均气温 (°C)
        rain:  shape (N,)  日降雨量 (mm)
        snow:  shape (N,)  日降雪量 (mm)
        param_dict: 包含 PDD 模型参数的字典，每个参数可为 shape (N,) 数组或标量，单位如下：
                    - pdd_factor_snow: mm/°C/day
                    - pdd_factor_ice:  mm/°C/day
                    - refreeze_snow:   [0 ~ 1]
                    - refreeze_ice:    [0 ~ 1]

    Returns:
        new_state: shape (N, 3)
                   [snow_depth(mm), ice_depth(mm), temp(°C)]
        runoff:    shape (N,)  日径流量 (mm)
    """
    # 解包所需参数
    pdd_factor_snow = get_param(param_dict["pdd_factor_snow"])  # mm/°C/day
    pdd_factor_ice = get_param(param_dict["pdd_factor_ice"])  # mm/°C/day
    refreeze_snow = get_param(param_dict["refreeze_snow"])  # [0-1]
    refreeze_ice = get_param(param_dict["refreeze_ice"])  # [0-1]

    # 拆分状态
    snow_depth, ice_depth, last_temp = state[:, 0], state[:, 1], state[:, 2]

    # 1. 将当日新下的雪量 (mm) 加到雪深
    snow_depth += snow

    # 2. 计算日正积温 (°C)，仅当 temp>0 才有融雪/融冰
    pdd = np.maximum(temp, 0.0)

    # 3. 计算潜在雪融量 (mm)
    #    pdd_factor_snow * pdd 即可得到“mm/day”的雪融量
    pot_snow_melt = pdd_factor_snow * pdd  # mm

    # 4. 实际雪融量不能超过当前雪深
    actual_snow_melt = np.minimum(snow_depth, pot_snow_melt)

    # 5. 计算剩余能量，用于融冰
    remaining_energy = pot_snow_melt - actual_snow_melt  # mm
    # 转化为对冰的融化量：以 pdd_factor_snow 为基准，再按比率得到冰融量
    ice_melt = remaining_energy * (pdd_factor_ice / pdd_factor_snow)  # mm

    # 6. 融冰量不能超过冰储量
    actual_ice_melt = np.minimum(ice_depth, ice_melt)

    # 7. 再冻结量计算
    refrozen_snow = actual_snow_melt * refreeze_snow  # mm
    refrozen_ice = actual_ice_melt * refreeze_ice  # mm

    # 8. 更新雪深、冰深
    snow_depth = snow_depth - actual_snow_melt + refrozen_snow
    ice_depth = ice_depth - actual_ice_melt + refrozen_ice

    # 9. 计算日径流 (mm)
    #    总融化量 = 融雪 + 融冰
    #    真正流出的量 = 总融化量 - 再冻结量 + 雨量
    total_melt = actual_snow_melt + actual_ice_melt
    runoff = total_melt - refrozen_snow - refrozen_ice + rain

    # 10. 组织输出新状态
    new_state = np.column_stack([
        np.maximum(snow_depth, 0),
        np.maximum(ice_depth, 0),
        temp  # 存储当日温度以供下个时刻使用
    ])

    return new_state, runoff


def get_param(param_value):
    """与 XAJ 兼容的参数读取小函数。"""
    if isinstance(param_value, np.ndarray):
        return param_value
    elif hasattr(param_value, 'to_numpy'):
        return param_value.to_numpy()
    else:
        return np.array(param_value)

