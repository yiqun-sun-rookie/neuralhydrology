import numpy as np
from src.kernels.core.hydro_model.process_model.xinanjiang.numpy.xaj_main import xaj_step_vec
from src.kernels.core.hydro_model.process_model.muskingum.msk_fcns import (
    muskingum_coefficients,
    muskingum_subreach_step_vec,
    init_subreaches
)

class XAJMskModel:
    def __init__(self, xaj_params, msk_params, num_basins):
        self.xaj_params = xaj_params
        self.msk_params = msk_params
        self.num_basins = num_basins
        self.c0, self.c1, self.c2, self.n_sub = muskingum_coefficients(msk_params)

    def initialize(self, initial_conditions, initial_flow=10.0):
        xaj_init = initial_conditions['xaj_initial']

        wu0 = np.array(xaj_init["WU"], dtype=float)
        wl0 = np.array(xaj_init["WL"], dtype=float)
        wd0 = np.array(xaj_init["WD"], dtype=float)
        w0 = wu0 + wl0 + wd0
        s0 = np.array(xaj_init["S"], dtype=float)
        qs0 = np.array(xaj_init["QS"], dtype=float)
        qi0 = np.array(xaj_init["QI"], dtype=float)
        qg0 = np.array(xaj_init["QG"], dtype=float)

        xaj_state = np.column_stack([w0, wu0, wl0, wd0, s0, qs0, qi0, qg0])

        q_msk = init_subreaches(
            np.full(self.num_basins, initial_flow, dtype=float),
            np.full(self.num_basins, initial_flow, dtype=float),
            self.n_sub
        )

        full_state = np.concatenate([xaj_state, q_msk], axis=1)
        return full_state

    def step(self, state, controls: dict):
        xaj_cols = 8
        xaj_state = state[:, :xaj_cols]
        q_msk_last = state[:, xaj_cols:]

        rain = controls["rain"]
        pet = controls["pet"]

        new_xaj_state = xaj_step_vec(
            state=xaj_state,
            rain=rain,
            pet=pet,
            param_dict=self.xaj_params
        )

        q_total = new_xaj_state[:, -3] + new_xaj_state[:, -2] + new_xaj_state[:, -1]
        q_msk_new = muskingum_subreach_step_vec(q_msk_last, q_total, self.c0, self.c1, self.c2)

        new_state = np.concatenate([new_xaj_state, q_msk_new], axis=1)
        return new_state

    def get_discharge(self, state):
        n_sub_val = self.n_sub
        if hasattr(n_sub_val, '__len__'):
            n_sub_val = int(n_sub_val[0])
            
        q_msk = state[:, -n_sub_val-1:]
        return q_msk[:, -1]

