import numpy as np
from typing import Union, Tuple, Dict
def muskingum_subreach_step_vec(
        q_msk_last_sub: np.ndarray,  # shape: (N_ens, num_sub+1)
        q_in_current: np.ndarray,  # shape: (N_ens,)
        c0: np.ndarray,  # shape: (N_ens,)
        c1: np.ndarray,  # shape: (N_ens,)
        c2: np.ndarray  # shape: (N_ens,)
) -> np.ndarray:
    """
    矢量化马斯京根子河段演算（参数强制向量化版）

    改进说明：
    1. 移除冗余的广播操作
    2. 添加参数形状验证
    3. 显式强制一维向量化
    """
    # 参数维度验证
    N_ens, num_sub_plus1 = q_msk_last_sub.shape
    num_sub = num_sub_plus1 - 1

    # 强制所有参数为一维向量
    def assert_vector_shape(arr, name):
        if arr.ndim != 1 or arr.shape[0] != N_ens:
            raise ValueError(
                f"参数 {name} 形状错误，期望 ({N_ens},)，实际 {arr.shape}"
            )

    assert_vector_shape(q_in_current, "q_in_current")
    assert_vector_shape(c0, "c0")
    assert_vector_shape(c1, "c1")
    assert_vector_shape(c2, "c2")

    # 初始化输出矩阵（预分配内存）
    q_this_sub = np.empty_like(q_msk_last_sub)
    q_this_sub[:, 0] = q_in_current  # 首列为当前入流

    # 创建滑动窗口视图（避免内存复制）
    prev_view = np.lib.stride_tricks.sliding_window_view(q_msk_last_sub, (1, 2))
    prev_view = prev_view.reshape(N_ens, num_sub, 2)

    # 系数矩阵扩展维度用于广播（无需复制数据）
    c0_3d = c0[:, None, None]  # shape (N_ens, 1, 1)
    c1_3d = c1[:, None, None]
    c2_3d = c2[:, None, None]

    # 并行计算所有子河段（向量化操作）
    q_next = (
            c0_3d * q_this_sub[:, :-1, None] +  # 当前入流 (N_ens, num_sub, 1)
            c1_3d * prev_view[:, :, 0, None] +  # 上一时刻入流
            c2_3d * prev_view[:, :, 1, None]  # 上一时刻出流
    )

    # 将结果写入输出矩阵
    q_this_sub[:, 1:] = q_next.squeeze(axis=-1)

    return q_this_sub


def muskingum_subreach_step_vec0(
    q_msk_last_sub: np.ndarray,   # shape: (N_ens, num_subreaches+1)
    q_in_current: np.ndarray,     # shape: (N_ens,) or scalar
    c0: float,                    # scalar or shape: (N_ens,)
    c1: float,                    # scalar or shape: (N_ens,)
    c2: float                     # scalar or shape: (N_ens,)
) -> np.ndarray:
    """
    在单条河道的一次时间步内，以“子段串行接力”的方式计算 Muskingum 出流（并行/矢量化版）。

    Parameters
    ----------
    q_msk_last_sub : np.ndarray, shape (N_ens, num_subreaches+1)
        上一时刻，各集合成员下的子节点流量分布，
        第 0 列是最上游节点流量，第 num_subreaches 列是最下游节点流量。
    q_in_current : np.ndarray or float
        当前时刻，各集合成员的最上游(子节点0)入流；
        若是标量表示对所有成员相同。
    c0, c1, c2 : float or np.ndarray
        Muskingum 系数（可分别为标量或 shape (N_ens,)），
        如果每个集合成员都有独立的 K, X, dt，则会有独立的 c0, c1, c2。

    Returns
    -------
    q_this_sub : np.ndarray, shape (N_ens, num_subreaches+1)
        当前时刻，各集合成员、各子节点流量分布。
        最后一个子节点的列即“最下游出流”。
    """
    # 如果只给了标量 c0, c1, c2，我们转换成 (N_ens,) 方便后续广播
    # 同理对于 q_in_current 也做转换
    if np.isscalar(q_in_current):
        q_in_current = np.array([q_in_current], dtype=float)

    # 让 q_in_current 变成 1D array
    q_in_current = np.atleast_1d(q_in_current)
    N_ens = q_in_current.shape[0] if q_in_current.ndim == 1 else None

    # 判断 q_msk_last_sub 形状
    if q_msk_last_sub.ndim != 2:
        raise ValueError("q_msk_last_sub 必须是2D数组 (N_ens, num_sub+1)")

    # 如果 c0, c1, c2 是标量，就给它们广播成 (N_ens,) 以便后续相乘
    def to_ens_array(x):
        if np.isscalar(x):
            return np.full((N_ens,), float(x), dtype=float)
        return np.atleast_1d(x)

    c0_ens = to_ens_array(c0)
    c1_ens = to_ens_array(c1)
    c2_ens = to_ens_array(c2)

    # 校验 N_ens 一致性
    # q_msk_last_sub.shape[0] 应该 == N_ens
    if q_msk_last_sub.shape[0] != q_in_current.shape[0]:
        raise ValueError(
            f"集合成员数不匹配: q_msk_last_sub.shape[0]={q_msk_last_sub.shape[0]}, "
            f"q_in_current.shape[0]={q_in_current.shape[0]}"
        )
    if c0_ens.shape[0] not in [1, N_ens]:
        raise ValueError(f"c0 长度{c0_ens.shape[0]}与 N_ens={N_ens} 不匹配。")
    # 同理可检查 c1_ens, c2_ens

    # 准备当前时刻的流量数组
    q_this_sub = np.zeros_like(q_msk_last_sub)  # shape=(N_ens, num_subreaches+1)

    # 最上游子节点(子0)，当前时刻流量 = q_in_current (对每个ensemble)
    q_this_sub[:, 0] = q_in_current

    num_subreaches = q_msk_last_sub.shape[1] - 1

    # 逐子段串行推进
    for i in range(num_subreaches):
        # 上一时刻该子段的入流 / 出流
        q_left_prev = q_msk_last_sub[:, i]     # shape (N_ens,)
        q_right_prev = q_msk_last_sub[:, i+1]  # shape (N_ens,)

        # 本时刻该子段的入流(接力传递过来的)
        q_left_m = q_this_sub[:, i]            # shape (N_ens,)

        # 计算本时刻出流(对每个ensemble并行)
        q_right_m = (c0_ens * q_left_m
                     + c1_ens * q_left_prev
                     + c2_ens * q_right_prev)

        # 存入
        q_this_sub[:, i+1] = q_right_m

    return q_this_sub

def muskingum_coefficients(msk_params: Dict[str, np.ndarray]) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    向量化马斯京根参数处理（集成参数提取与系数计算）

    新增功能：
    - 直接从参数字典提取 K/X/dt/num_subreaches
    - 统一参数校验
    - 返回演算系数及子河段数

    参数:
        msk_params: 包含马斯京根参数的字典，必须有以下键：
            K: 蓄量时间参数数组
            X: 权重系数数组
            dt: 时间步长数组
            num_subreaches: 子河段数数组

    返回:
        tuple(c0, c1, c2, n_sub)
        - c0, c1, c2: 演算系数数组，shape=(n,)
        - n_sub: 子河段数数组，shape=(n,)
    """
    # 参数提取与校验
    required_keys = ['K', 'X', 'dt', 'num_subreaches']
    missing = [k for k in required_keys if k not in msk_params]
    if missing:
        raise KeyError(f"缺失必要马斯京根参数: {missing}")

    K = np.asarray(msk_params['K'], dtype=np.float32)
    X = np.asarray(msk_params['X'], dtype=np.float32)
    dt = np.asarray(msk_params['dt'], dtype=np.float32)
    n_sub = np.asarray(msk_params['num_subreaches'], dtype=np.int32)

    # 参数有效性检查
    if (K <= 0).any():
        raise ValueError("K 必须为正值")
    if (X < 0).any() or (X > 0.5).any():
        raise ValueError("X 必须在 [0, 0.5] 范围内")
    if (dt <= 0).any():
        raise ValueError("dt 必须为正值")

    # 核心系数计算
    denominator = K * (1 - X) + 0.5 * dt
    c0 = -(K * X - 0.5 * dt) / denominator
    c1 = (K * X + 0.5 * dt) / denominator
    c2 = (K * (1 - X) - 0.5 * dt) / denominator

    # 系数归一化处理
    s = c0 + c1 + c2
    needs_adjust = np.abs(s - 1.0) > 1e-6
    if np.any(needs_adjust):
        coefs = np.stack([c0, c1, c2], axis=-1)
        adjust_idx = np.where(needs_adjust)[0]
        for i in adjust_idx:
            idx_max = np.argmax(coefs[i])
            coefs[i, idx_max] = 1.0 - (coefs[i].sum() - coefs[i, idx_max])
        c0, c1, c2 = coefs[:, 0], coefs[:, 1], coefs[:, 2]

    return c0, c1, c2, n_sub

#
# def muskingum_coefficients0(K: np.ndarray, X: np.ndarray, dt: np.ndarray) -> tuple:
#     """
#     向量化马斯京根系数计算（支持多组参数）
#
#     参数:
#         K: 蓄量时间参数数组，shape=(n,)
#         X: 权重系数数组，shape=(n,)
#         dt: 时间步长数组，shape=(n,)
#
#     返回:
#         tuple(c0, c1, c2) 三个系数数组，每个shape=(n,)
#     """
#     # 确保输入为numpy数组
#     K = np.asarray(K, dtype=np.float32)
#     X = np.asarray(X, dtype=np.float32)
#     dt = np.asarray(dt, dtype=np.float32)
#
#     # 向量化计算核心系数
#     denominator = K * (1 - X) + 0.5 * dt
#     c0 = -(K * X - 0.5 * dt) / denominator
#     c1 = (K * X + 0.5 * dt) / denominator
#     c2 = (K * (1 - X) - 0.5 * dt) / denominator
#
#     # 向量化归一化处理
#     s = c0 + c1 + c2
#     needs_adjust = np.abs(s - 1.0) > 1e-6
#
#     if np.any(needs_adjust):
#         # 构造系数矩阵 shape=(n,3)
#         coefs = np.stack([c0, c1, c2], axis=-1)
#
#         # 找到需要调整的元素的索引
#         adjust_idx = np.where(needs_adjust)[0]
#
#         # 对每个需要调整的元素处理
#         for i in adjust_idx:
#             # 找到最大系数的位置
#             idx_max = np.argmax(coefs[i])
#
#             # 调整最大系数
#             current_sum = coefs[i].sum()
#             coefs[i, idx_max] = 1.0 - (current_sum - coefs[i, idx_max])
#
#         # 分解回三个数组
#         c0, c1, c2 = coefs[:, 0], coefs[:, 1], coefs[:, 2]
#
#     return c0, c1, c2

#
# def muskingum_coefficients_scalar(K: float, X: float, dt: float):
#     denominator = K * (1 - X) + 0.5 * dt
#     c0 = -(K * X - 0.5 * dt) / denominator
#     c1 = (K * X + 0.5 * dt) / denominator
#     c2 = (K * (1 - X) - 0.5 * dt) / denominator
#
#     # 保证 c0 + c1 + c2 = 1 (若有轻微误差，则调整之)
#     s = c0 + c1 + c2
#     if abs(s - 1.0) > 1e-6:
#         # 简易修正: 调整最大系数
#         arr = np.array([c0, c1, c2])
#         idx_max = np.argmax(arr)
#         arr[idx_max] = 1.0 - (arr.sum() - arr[idx_max])
#         c0, c1, c2 = arr
#
#     return c0, c1, c2


def init_subreaches(
        qA_last: Union[float, np.ndarray],
        qB_last: Union[float, np.ndarray],
        num_subreaches: Union[int, np.ndarray]
) -> np.ndarray:
    """
    向量化初始化 Muskingum 子河段流量（支持多流域并行）

    参数:
        qA_last: 上游端初始流量，标量或shape=(n_basins,)
        qB_last: 下游端初始流量，标量或shape=(n_basins,)
        num_subreaches: 子河段数，标量或shape=(n_basins,)（所有元素必须相同）

    返回:
        ndarray of shape (n_basins, n_sub+1)

    示例:
        >>> init_subreaches([80, 85], [100, 105], 3)
        array([[ 80. ,  90. , 100. ],
               [ 85. ,  95. , 105. ]])
    """
    # 统一转为数组
    qA_arr = np.asarray(qA_last, dtype=np.float32)
    qB_arr = np.asarray(qB_last, dtype=np.float32)
    ns_arr = np.asarray(num_subreaches, dtype=np.int32)

    # 维度校验
    if qA_arr.ndim != 1 or qB_arr.ndim != 1:
        raise ValueError("qA_last 和 qB_last 必须为1D数组")
    if qA_arr.shape != qB_arr.shape:
        raise ValueError(f"qA/qB 形状不匹配: {qA_arr.shape} vs {qB_arr.shape}")

    # 处理子河段数
    if ns_arr.size == 1:
        # 标量扩展为相同长度
        ns_val = int(ns_arr[0])
        ns_arr = np.full_like(qA_arr, ns_val, dtype=np.int32)
    else:
        if ns_arr.shape != qA_arr.shape:
            raise ValueError(f"num_subreaches 形状不匹配: {ns_arr.shape} vs {qA_arr.shape}")
        if not np.all(ns_arr == ns_arr[0]):
            raise ValueError("不同流域的 num_subreaches 必须相同")
        ns_val = ns_arr[0]

    # 创建输出数组
    n_basins = qA_arr.shape[0]
    init_flows = np.zeros((n_basins, ns_val + 1), dtype=np.float32)

    # 向量化插值
    for i in range(n_basins):
        init_flows[i] = np.linspace(qA_arr[i], qB_arr[i], ns_val + 1)

    return init_flows

#
# def muskingum_subreach_step(
#         q_left_m: float,  # 当前时刻该子段的入流
#         q_left_prev: float,  # 上一时刻该子段的入流
#         q_right_prev: float,  # 上一时刻该子段的出流
#         c0: float, c1: float, c2: float
# ) -> float:
#     """
#     对于单个子段，在一个时间步上，根据 Muskingum 公式(简化示例)，
#     计算该子段的“当前时刻出流”。
#
#     这里假设：
#       Q_out(m) = c0 * Q_in(m) + c1 * Q_in(m-1) + c2 * Q_out(m-1)
#
#     Parameters
#     ----------
#     q_left_m : float
#         当前时刻，该子段的入流 (如 q_left_m = q_msk_this_sub[i])
#     q_left_prev : float
#         上一时刻，该子段的入流
#     q_right_prev : float
#         上一时刻，该子段的出流
#     c0, c1, c2 : float
#         已经根据 K, X, dt 算好的 Muskingum 系数
#
#     Returns
#     -------
#     q_right_m : float
#         该子段在本时刻的出流
#     """
#     q_right_m = c0 * q_left_m + c1 * q_left_prev + c2 * q_right_prev
#     return max(q_right_m, 0.0) # 保证非负
#
#
# def muskingum_time_step_subreach_chain(
#         q_msk_last_sub: np.ndarray,  # 上一时刻已细分子节点的流量分布: [q(子0), q(子1), ..., q(子N)]
#         q_in_current: float,  # 本时刻最上游 (子节点 0) 的入流
#         c0: float, c1: float, c2: float
# ) -> np.ndarray:
#     """
#     在单条河道的一次时间步里，采用“子段串行接力”方式计算各子段的出流。
#
#     Parameters
#     ----------
#     q_msk_last_sub : np.ndarray
#         上一时刻，各子节点(子0..子N)的流量分布；
#         其中 i=0 是上游节点，i=N 是下游节点。
#     q_in_current : float
#         当前时刻，上游子节点(即子0)的入流
#     c0, c1, c2 : float
#         Muskingum 系数
#
#     Returns
#     -------
#     q_msk_this_sub : np.ndarray
#         当前时刻，细分子节点(0..N)的流量分布。第 0 个值 = q_in_current，最后一个值就是最下游出流。
#     """
#     num_subreaches = q_msk_last_sub.size - 1  # 一共有 N = num_subreaches
#
#     # 本时刻各子节点流量数组
#     q_msk_this_sub = np.zeros_like(q_msk_last_sub)
#     # 最上游(子节点 0) 在本时刻的流量 = q_in_current
#     q_msk_this_sub[0] = q_in_current
#
#     # 依次计算每个子段
#     for i in range(num_subreaches):
#         # 子段 i 的：
#         q_left_prev = q_msk_last_sub[i]  # 上一时刻，该子段的入流
#         q_right_prev = q_msk_last_sub[i + 1]  # 上一时刻，该子段的出流
#
#         # 本时刻 该子段的 入流
#         q_left_m = q_msk_this_sub[i]
#
#         # 计算 本时刻 该子段的 出流
#         q_right_m = muskingum_subreach_step(q_left_m, q_left_prev, q_right_prev,
#                                             c0, c1, c2)
#         # 存入数组
#         q_msk_this_sub[i + 1] = q_right_m
#
#     return q_msk_this_sub

#
# def run_muskingum_single_case(
#         K: float,
#         X: float,
#         dt: float,
#         num_subreaches: int,
#         qA_last: float,
#         qB_last: float,
#         upstream_inflows: list
# ) -> np.ndarray:
#     """
#     针对单条河道(从 A->B)，给定 Muskingum 参数 (K, X, dt, num_subreaches)，
#     以及上一时刻 A,B 流量 (qA_last, qB_last) 和一个序列的上游入流(多时间步) upstream_inflows，
#     进行 Muskingum 推演，返回多时间步的【子节点流量分布】。
#
#     Returns
#     -------
#     results : ndarray of shape (num_time_steps, num_subreaches+1)
#         - results[t, :] 为第 t 个时间步从子0..子N 的流量
#     """
#     # 1) 初始化上一时刻的子节点流量分布
#     q_msk_last_sub = init_subreaches(qA_last, qB_last, num_subreaches)
#
#     # 2) 预分配输出
#     num_steps = len(upstream_inflows)
#     results = np.zeros((num_steps, num_subreaches + 1), dtype=float)
#
#     # 3) 时间步循环
#     for t in range(num_steps):
#         q_in_cur = upstream_inflows[t]
#
#         # 3.1 计算 Muskingum 系数
#         c0, c1, c2 = muskingum_coefficients(K, X, dt)
#
#         # 3.2 本时刻子段计算
#         q_msk_this_sub = muskingum_time_step_subreach_chain(
#             q_msk_last_sub, q_in_cur, c0, c1, c2
#         )
#
#         # 3.3 保存结果
#         results[t, :] = q_msk_this_sub
#
#         # 3.4 用当前时刻的结果，准备下一时刻
#         q_msk_last_sub = q_msk_this_sub
#
#     return results
#
#
# def muskingum_subreach_step(
#         q_left_m: float,
#         q_left_prev: float,
#         q_right_prev: float,
#         c0: float, c1: float, c2: float
# ) -> float:
#     """
#     对单个子段，在一次时间步中，根据 Muskingum 公式（示例版）,
#     计算当前时刻该子段的出流。
#     假设公式： Q_out(m) = c0*Q_in(m) + c1*Q_in(m-1) + c2*Q_out(m-1)
#     """
#     return c0 * q_left_m + c1 * q_left_prev + c2 * q_right_prev



# def muskingum_time_step_subreach_chain(
#         q_msk_last_sub: np.ndarray,
#         q_in_current: float,
#         c0: float, c1: float, c2: float
# ) -> np.ndarray:
#     """
#     在单条河道的一次时间步内，采用“子段串行接力”的方式
#     计算每个子段的出流(当前时刻)，并返回整条河的子节点流量分布。
#
#     q_msk_last_sub: 上一时刻子节点流量分布(长度 = num_subreaches+1)
#     q_in_current   : 本时刻最上游(子0)的入流
#     c0, c1, c2     : Muskingum 系数
#     """
#     num_subreaches = q_msk_last_sub.size - 1
#     q_this_sub = np.zeros_like(q_msk_last_sub)
#
#     # 最上游子节点(子0)当前时刻流量 = q_in_current
#     q_this_sub[0] = q_in_current
#
#     # 顺序计算子段 i (从上游到下游)
#     for i in range(num_subreaches):
#         q_left_prev = q_msk_last_sub[i]  # 上一时刻 该子段的入流
#         q_right_prev = q_msk_last_sub[i + 1]  # 上一时刻 该子段的出流
#         q_left_m = q_this_sub[i]  # 本时刻 该子段的入流(接力传递)
#
#         q_right_m = muskingum_subreach_step(
#             q_left_m, q_left_prev, q_right_prev, c0, c1, c2
#         )
#         q_this_sub[i + 1] = q_right_m
#
#     return q_this_sub

#
# def run_muskingum_single_case(
#         K: float,
#         X: float,
#         dt: float,
#         num_subreaches: int,
#         qA_last: float,
#         qB_last: float,
#         upstream_inflows: list
# ) -> np.ndarray:
#     """
#     针对单条河道(从 A->B)，给定 Muskingum 参数 (K, X, dt, num_subreaches)，
#     以及上一时刻 A,B 流量 (qA_last, qB_last) 和一个序列的上游入流(多时间步) upstream_inflows，
#     进行 Muskingum 推演，返回多时间步的【子节点流量分布】。
#
#     Returns
#     -------
#     results : ndarray of shape (num_time_steps, num_subreaches+1)
#         - results[t, :] 为第 t 个时间步从子0..子N 的流量
#     """
#     # 1) 初始化上一时刻的子节点流量分布
#     q_msk_last_sub = init_subreaches(qA_last, qB_last, num_subreaches)
#
#     # 2) 预分配输出
#     num_steps = len(upstream_inflows)
#     results = np.zeros((num_steps, num_subreaches + 1), dtype=float)
#
#     # 3) 时间步循环
#     for t in range(num_steps):
#         q_in_cur = upstream_inflows[t]
#
#         # 3.1 计算 Muskingum 系数
#         c0, c1, c2 = muskingum_coefficients(K, X, dt)
#
#         # 3.2 本时刻子段计算
#         q_msk_this_sub = muskingum_time_step_subreach_chain(
#             q_msk_last_sub, q_in_cur, c0, c1, c2
#         )
#
#         # 3.3 保存结果
#         results[t, :] = q_msk_this_sub
#
#         # 3.4 用当前时刻的结果，准备下一时刻
#         q_msk_last_sub = q_msk_this_sub
#
#     return results

#
# def run_multiple_muskingum_cases_in_parallel(case_list, n_jobs=2):
#     """
#     并行运行多个不相关的 Muskingum 模拟场景。
#
#     Parameters
#     ----------
#     case_list : list
#         每个元素是一个 dict，包含一组 Muskingum 模拟的所有必要输入:
#           {
#             "K": float,
#             "X": float,
#             "dt": float,
#             "num_subreaches": int,
#             "qA_last": float,
#             "qB_last": float,
#             "upstream_inflows": list or array
#           }
#     n_jobs : int
#         并行使用的CPU核心数
#
#     Returns
#     -------
#     results_list : list of np.ndarray
#         与 case_list 等长的列表，每个元素是本场景的输出数组，
#         形状 (num_time_steps, num_subreaches+1)。
#     """
#
#     def run_one_case(case):
#         return run_muskingum_single_case(
#             K=case["K"],
#             X=case["X"],
#             dt=case["dt"],
#             num_subreaches=case["num_subreaches"],
#             qA_last=case["qA_last"],
#             qB_last=case["qB_last"],
#             upstream_inflows=case["upstream_inflows"]
#         )
#
#     # 使用 joblib 并行执行
#     results_list = Parallel(n_jobs=n_jobs)(
#         delayed(run_one_case)(c) for c in case_list
#     )
#     return results_list
#
#
# if __name__ == "__main__":
#
#     # =============== 示例场景 1 ===============
#     case1 = {
#         "K": 10.0,
#         "X": 0.2,
#         "dt": 1.0,
#         "num_subreaches": 3,
#         "qA_last": 100.0,  # 上一时刻, A 点流量
#         "qB_last": 80.0,  # 上一时刻, B 点流量
#         "upstream_inflows": [90.0, 95.0, 110.0, 105.0]  # 4 个时间步
#     }
#
#     # =============== 示例场景 2 ===============
#     case2 = {
#         "K": 8.0,
#         "X": 0.3,
#         "dt": 2.0,
#         "num_subreaches": 2,
#         "qA_last": 50.0,
#         "qB_last": 40.0,
#         "upstream_inflows": [60.0, 65.0, 70.0, 68.0, 72.0]  # 5 个时间步
#     }
#
#     # 还可以添加更多 caseN ...
#
#     # 组织成一个列表
#     case_list = [case1, case2]
#
#     # 并行运行
#     # n_jobs=2 表示使用 2 个并行进程；根据你电脑 CPU 核数可调整
#     results_all = run_multiple_muskingum_cases_in_parallel(case_list, n_jobs=2)
#
#     # results_all 是一个列表, 长度与 case_list 相同
#     # results_all[0] 对应 case1 的计算结果
#     # results_all[1] 对应 case2 的计算结果
#     print("并行执行完毕，共得到 {} 组结果:".format(len(results_all)))
#
#     for i, res in enumerate(results_all):
#         print(f"\n---Case {i}---")
#         print(f"Input scenario: {case_list[i]}")
#         print("Output shape:", res.shape, "(time_steps, num_subreaches+1)")
#         print("Output array:\n", res)
