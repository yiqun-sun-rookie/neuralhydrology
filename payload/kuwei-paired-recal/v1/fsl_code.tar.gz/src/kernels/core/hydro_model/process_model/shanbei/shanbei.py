"""
陕北模型 (ShaanBei Model)

基于 Horton 超渗产流机制 + 时间压缩法。
用累积下渗量 θ 作为状态变量，通过 Horton 曲线反查等效时间 t，
再根据供水条件（充分/不充分）计算产流量。
"""
import numpy as np


class ShanBeiModel:
    def __init__(self, kc, wm, fb, b, fc, f0, k, ke, xe, l, error=0.001):
        self.kc = kc    # 流域蒸散发折算系数
        self.wm = wm    # 流域平均张力水容量
        self.fb = fb    # 不透水面积占比
        self.b = b      # 蓄水容量-面积分布曲线方次
        self.fc = fc    # Horton 稳定下渗率
        self.f0 = f0    # Horton 初始下渗率
        self.k = k      # Horton 指数（与土质有关）
        self.ke = ke    # 马斯京根河段传播时间 K
        self.xe = xe    # 流量比重系数 x
        self.l = l      # 滞时
        self.error = error

        # ---- FIX-1/2: 内存预计算查找表，替代文件 I/O ----
        self._build_theta_table()

    # ------------------------------------------------------------------ #
    #  Horton 曲线
    # ------------------------------------------------------------------ #
    def _theta_t(self, t):
        """累积下渗量 F(t) = fc*t + (f0-fc)/k * (1 - e^{-kt})"""
        return self.fc * t + (self.f0 - self.fc) / self.k * (1 - np.exp(-self.k * t))

    def _f_t(self, t):
        """瞬时下渗率 f(t) = fc + (f0-fc) * e^{-kt}"""
        return self.fc + (self.f0 - self.fc) * np.exp(-self.k * t)

    # ------------------------------------------------------------------ #
    #  FIX-1: 内存查找表（替代 CSV 文件 I/O）
    # ------------------------------------------------------------------ #
    def _build_theta_table(self):
        """在内存中预计算 t-θ-f 查找表"""
        t_list, theta_list, f_list = [], [], []
        t = 0.0
        max_iter = 100000  # FIX-4: 防止无限循环
        for _ in range(max_iter):
            theta = self._theta_t(t)
            f = self._f_t(t)
            t_list.append(t)
            theta_list.append(theta)
            f_list.append(f)
            if f - self.fc <= self.error:
                break
            t += 0.5

        self._t_arr = np.array(t_list)
        self._theta_arr = np.array(theta_list)
        self._f_arr = np.array(f_list)

    def query_f_t_by_theta(self, theta1):
        """
        根据累积下渗量 θ₁ 插值查询对应的等效时间 t 和瞬时下渗率 f

        FIX-1: 使用 np.interp 替代二分 + CSV 读取
        FIX-3: 修复原始二分查找方向错误和 t 恒等于 theta1 的 bug
        """
        # θ 单调递增 → np.interp 直接可用
        t = np.interp(theta1, self._theta_arr, self._t_arr)
        f = np.interp(theta1, self._theta_arr, self._f_arr)
        return float(t), float(f)

    # ------------------------------------------------------------------ #
    #  蒸发计算
    # ------------------------------------------------------------------ #
    def evaporation_cal(self, water_storage: float, evap_water: float) -> float:
        """
        单层蒸发：E_actual = KC * E_pan * (W / WM)

        :param water_storage: 前一时刻土壤含水量 W (mm)
        :param evap_water: 水面蒸发 / 潜在蒸散发 (mm)
        :return: 实际蒸发 (mm)
        """
        # FIX-5: 浮点安全比较
        if water_storage <= 0:
            return 0.0
        evap_actual = self.kc * evap_water * (water_storage / self.wm)
        return min(evap_actual, water_storage)

    # ------------------------------------------------------------------ #
    #  产流计算（Horton 超渗 + 时间压缩法）
    # ------------------------------------------------------------------ #
    def runoff_cal(self, rainfall: float, t_delta: float, theta1: float):
        """
        Horton 超渗产流 + 时间压缩法

        :param rainfall: 本时刻降雨量 (mm)
        :param t_delta: 计算时段长 (h 或 min，与 Horton 参数时间单位一致)
        :param theta1: 前一时刻累积下渗量 / 土含 (mm)
        :return: (theta_new, runoff)
            theta_new: 更新后的土含 (mm)
            runoff: 产流量 (mm)，已考虑不透水面积
        """
        rainfall = max(0.0, rainfall)
        if theta1 >= self.wm:
            return self.wm, rainfall

        i = rainfall / t_delta   # 雨强 (mm/h 或 mm/min)
        t1, f1 = self.query_f_t_by_theta(theta1)

        if i >= f1:
            # 全时段供水充分：下渗沿 Horton 曲线推进
            theta_delta = self._theta_t(t1 + t_delta) - self._theta_t(t1)
            r = rainfall - theta_delta
        else:
            # 供水不足 → 找转换点 f(t_i) = i
            if i > self.fc:
                t_i = -1 / self.k * np.log((i - self.fc) / (self.f0 - self.fc))
            else:
                t_i = float('inf')

            if t_i - t1 >= t_delta:
                # 全时段供水不充分：全部入渗，无产流
                theta_delta, r = rainfall, 0.0
            else:
                # 前段供水不足，后段供水充分
                theta_delta1 = i * (t_i - t1)
                t_mid, _ = self.query_f_t_by_theta(theta1 + theta_delta1)
                theta_delta2 = self._theta_t(t_mid + t_delta - (t_i - t1)) - self._theta_t(t_mid)
                theta_delta = theta_delta1 + theta_delta2
                r = i * (t_delta - (t_i - t1)) - theta_delta2

        theta_new = min(self.wm, theta1 + theta_delta)
        runoff = max(0.0, r * (1 - self.fb) + rainfall * self.fb)
        return theta_new, runoff

    # ------------------------------------------------------------------ #
    #  马斯京根河道汇流
    # ------------------------------------------------------------------ #
    @staticmethod
    def _muskingum_coeffs(ke: float, xe: float, t_delta: float):
        """
        标准马斯京根系数

        FIX-6: 引入 t_delta，不再隐含 Δt = K
        """
        denom = 0.5 * t_delta + ke * (1 - xe)
        c0 = (0.5 * t_delta - ke * xe) / denom
        c1 = (0.5 * t_delta + ke * xe) / denom
        c2 = (ke * (1 - xe) - 0.5 * t_delta) / denom
        return c0, c1, c2

    def maskingen_cal(self, q_0: float, i_0: float, i_1: float, t_delta: float = None):
        """
        单步马斯京根演算

        :param q_0: 前一时刻出流
        :param i_0: 前一时刻入流
        :param i_1: 本时刻入流
        :param t_delta: 计算步长；默认 None 时使用 ke（兼容旧行为）
        :return: 本时刻出流
        """
        dt = t_delta if t_delta is not None else self.ke
        c0, c1, c2 = self._muskingum_coeffs(self.ke, self.xe, dt)
        return c0 * i_1 + c1 * i_0 + c2 * q_0

    def single_maskingen(self, q_input_arr: np.ndarray, q_input0: float,
                         t_confluence: float, t_delta: float = None):
        """
        多河段马斯京根汇流演算

        :param q_input_arr: 入流过程 (1-D array)
        :param q_input0: 初始出流
        :param t_confluence: 河道汇流时间
        :param t_delta: 计算步长
        :return: 出流过程 (1-D array)
        """
        dt = t_delta if t_delta is not None else self.ke
        c0, c1, c2 = self._muskingum_coeffs(self.ke, self.xe, dt)

        q_output = np.zeros_like(q_input_arr)
        q_output[0] = q_input0
        n = max(1, int(t_confluence / self.ke))
        length = len(q_input_arr)

        q_in = q_input_arr.copy()
        for _ in range(n):
            for i in range(length - 1):
                q_output[i + 1] = c0 * q_in[i + 1] + c1 * q_in[i] + c2 * q_output[i]
            q_in = q_output.copy()

        return q_output


def confluence_cal(q_0, i_1, c, drainage_area=1, t_delta=1):
    """
    线性水库单元面积汇流

    :param q_0: 前一时刻出流 (m³/s)
    :param i_1: 本时刻入流 (产流深 mm 或流量 m³/s)
    :param c: 消退系数
    :param drainage_area: 流域面积 (km²)，当 i_1 为流量时传 1
    :param t_delta: 计算步长 (h)
    :return: 汇流结果 (m³/s)
    """
    u = 1.0 if drainage_area == 1 else drainage_area / (3.6 * t_delta)
    return c * q_0 + (1 - c) * i_1 * u
