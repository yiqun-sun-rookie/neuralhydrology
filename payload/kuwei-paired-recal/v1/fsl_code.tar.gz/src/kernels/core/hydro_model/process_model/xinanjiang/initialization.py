from src.kernels.data_processing.data_io_utils import read_state_from_netcdf
import pandas as pd
def initialize_state(grids_to_interp, state_names, hydro_model_config, state_output_dir):
    """
    根据用户选择的 warm_start 或 cold_start 来初始化状态。

    参数:
    - grids_to_interp: 包含网格信息的 DataFrame，至少包含 'id'、'longitude'、'latitude'
    - state_names: 列表，需要初始化的状态变量名称
    - hydro_model_config: 从配置文件读取的水文模型配置
      其中应包含 initial_conditions 字段，例如：
      initial_conditions:
        mode: 'cold_start' 或 'warm_start'
        warm_start_time: '2013-06-05 00:00' (如果是 warm_start 时需要)
    - state_output_dir: 状态输出目录

    返回:
    - state: 初始化后的状态 DataFrame
    """
    initial_conditions = hydro_model_config.get('initial_conditions', {})
    mode = initial_conditions.get('mode', 'cold_start')

    # cold_start：从配置中默认值初始化
    # warm_start：从指定时间点读取之前保存的状态文件
    if mode == 'warm_start':
        warm_start_time = initial_conditions.get('warm_start_time')
        if warm_start_time is None:
            raise ValueError("在 warm_start 模式下，必须指定 warm_start_time")
        # 从指定时间点读取状态
        state = read_state_from_netcdf(warm_start_time, state_names, state_output_dir)
    else:
        # cold_start 模式下，从默认值初始化
        state = grids_to_interp.copy()

        # 从 hydro_model_config['state_variables'] 中获取初始值
        state_variables = hydro_model_config['state_variables']
        for var_name in state_names:
            initial_val = state_variables[var_name].get('default', 0.0)
            state[var_name] = initial_val

        # 对于 cold_start，可以为初始状态设置统一的时间（可选）
        # 这里假设初始状态对应于 start_time
        start_time = hydro_model_config['simulation_settings']['start_time']
        state['time'] = pd.to_datetime(start_time)

    return state
