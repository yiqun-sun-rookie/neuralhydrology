
import yaml
import pandas as pd

def load_params_xaj_from_yaml(yaml_path: str, basin_area: float) -> pd.DataFrame:
    """
    从给定的 YAML 文件中读取 XAJ 模型的初始参数，并根据流域面积或其他条件
    生成衍生参数，返回单行 DataFrame。
    """
    with open(yaml_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)

    xaj_params = config.get("xaj_params", {})
    if not xaj_params:
        raise ValueError(f"YAML 文件 {yaml_path} 中没有发现 'xaj_params' 字段。")

    # 将 dict 转为单行 DataFrame
    tbl_pars = pd.DataFrame([xaj_params], index=[0])

    # 覆盖 uf (若跟 basin_area 相关)：
    tbl_pars['uf'] = basin_area / 3.6

    # 计算衍生参数
    if not all(col in tbl_pars.columns for col in ["wm", "b", "imp", "sm", "ex"]):
        raise ValueError("需要 wm, b, imp, sm, ex，无法计算衍生参数 wmm, ms。")

    wm_val  = tbl_pars["wm"].iloc[0]
    b_val   = tbl_pars["b"].iloc[0]
    imp_val = tbl_pars["imp"].iloc[0]
    sm_val  = tbl_pars["sm"].iloc[0]
    ex_val  = tbl_pars["ex"].iloc[0]

    tbl_pars["wmm"] = wm_val * (1 + b_val) / (1 - imp_val)
    tbl_pars["ms"]  = sm_val * (1 + ex_val)

    return tbl_pars


import yaml
import pandas as pd


def load_model_params_from_yaml(yaml_path: str, basin_area) -> pd.DataFrame:
    """
    从同一个 YAML 文件读取 XAJ 与 MSK 的参数，返回一个合并后的 DataFrame。

    1) 支持单值或多值(列表)：
       - 若某参数是单值 => 变成长度=1的列表；
       - 若是多值 => 直接使用。
    2) 同一部分（XAJ 内/ MSK 内）多值的长度必须一致，否则报错；单值自动广播。
    3) 如果 XAJ 与 MSK 都有多值，则最终的行数必须相同，否则报错；
       如果只有一方多值，另一方单值 => 广播单值方。
    4) XAJ 还要计算衍生量(uf, wmm, ms)。MSK 暂无额外计算，需要可自行添加。
    5) 最终给 MSK 的列名前加 "msk_" 前缀，以免与 XAJ 名字冲突。
    """

    with open(yaml_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)

    # ========== Part A. 提取 xaj_params =============
    xaj_dict = config.get("xaj_params", {})
    if not isinstance(xaj_dict, dict):
        raise ValueError("YAML 中的 xaj_params 字段不存在或不是 dict。")

    # 把 xaj_params 的每个参数解析成列表
    xaj_lists = {}
    for pname, pval in xaj_dict.items():
        if isinstance(pval, (float, int)):
            xaj_lists[pname] = [float(pval)]
        elif isinstance(pval, list):
            xaj_lists[pname] = [float(x) for x in pval]
        else:
            raise ValueError(f"XAJ参数 {pname} 的值必须是数字或数字列表，当前: {pval}")

    # 检查多值长度是否一致
    xaj_lengths = [len(lst) for lst in xaj_lists.values()]
    xaj_max_len = max(xaj_lengths) if xaj_lengths else 1  # 防空
    for pname, lst in xaj_lists.items():
        if len(lst) not in [1, xaj_max_len]:
            raise ValueError(
                f"XAJ参数 '{pname}' 列表长度 = {len(lst)}，"
                f"无法与其他多值对齐 (xaj_max_len={xaj_max_len})"
            )
    # 单值广播
    for pname, lst in xaj_lists.items():
        if len(lst) == 1 and xaj_max_len > 1:
            xaj_lists[pname] = lst * xaj_max_len

    # ========== Part B. 提取 msk_params =============
    msk_dict = config.get("msk_params", {})
    if not isinstance(msk_dict, dict):
        raise ValueError("YAML 中的 msk_params 字段不存在或不是 dict。")

    msk_lists = {}
    for pname, pval in msk_dict.items():
        if isinstance(pval, (float, int)):
            msk_lists[pname] = [float(pval)]
        elif isinstance(pval, list):
            msk_lists[pname] = [float(x) for x in pval]
        else:
            raise ValueError(f"MSK参数 {pname} 的值必须是数字或数字列表，当前: {pval}")

    msk_lengths = [len(lst) for lst in msk_lists.values()]
    msk_max_len = max(msk_lengths) if msk_lengths else 1
    for pname, lst in msk_lists.items():
        if len(lst) not in [1, msk_max_len]:
            raise ValueError(
                f"MSK参数 '{pname}' 列表长度 = {len(lst)}，"
                f"无法与其他多值对齐 (msk_max_len={msk_max_len})"
            )
    # 单值广播
    for pname, lst in msk_lists.items():
        if len(lst) == 1 and msk_max_len > 1:
            msk_lists[pname] = lst * msk_max_len

    # ========== Part C. 统一合并 XAJ + MSK =============
    # 最终行数 = max(xaj_max_len, msk_max_len)
    final_len = max(xaj_max_len, msk_max_len)

    # 如果 XAJ 或 MSK 部分都各自只有一行 => 直接广播
    # 如果两边都多于1行 => 必须保证 xaj_max_len == msk_max_len
    if xaj_max_len > 1 and msk_max_len > 1 and xaj_max_len != msk_max_len:
        raise ValueError(
            f"XAJ 有 {xaj_max_len} 套多值，MSK 有 {msk_max_len} 套多值，二者不相等，无法对齐!"
        )

    # 对 XAJ 再次检查广播
    if xaj_max_len == 1 and final_len > 1:
        for pname in xaj_lists.keys():
            xaj_lists[pname] = xaj_lists[pname] * final_len

    # 对 MSK 再次检查广播
    if msk_max_len == 1 and final_len > 1:
        for pname in msk_lists.keys():
            msk_lists[pname] = msk_lists[pname] * final_len

    # 现在 XAJ、MSK 都应当是 final_len 行
    # 合并成一个大的 param_lists
    # 同时给 MSK 的字段加个前缀 "msk_"
    param_lists = {}
    # 先加 XAJ
    for pname, lst in xaj_lists.items():
        param_lists[pname] = lst
    # 再加 MSK(加前缀)
    for pname, lst in msk_lists.items():
        param_lists[f"msk_{pname}"] = lst

    # ========== Part D. 组装 DataFrame + 计算衍生量 ==========
    df = pd.DataFrame(param_lists)

    # 1) uf (与 basin_area 相关)
    df["uf"] = basin_area / 3.6

    # 2) wmm, ms => 需要 wm, b, imp, sm, ex(这些列在 XAJ部分)
    df["wm"] = df["wum"] + df["wlm"] + df["wdm"]
    required_cols = ["b", "imp", "sm", "ex"]
    missing = [col for col in required_cols if col not in df.columns]
    if not missing:
        df["wmm"] = df["wm"] * (1 + df["b"]) / (1 - df["imp"])
        df["ms"] = df["sm"] * (1 + df["ex"])
    else:
        print(f"警告：缺少 {missing}，无法计算 wmm, ms，跳过。")

    return df

