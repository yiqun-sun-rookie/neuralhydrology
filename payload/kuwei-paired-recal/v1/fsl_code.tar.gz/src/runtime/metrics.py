"""Optimization metrics utilities (NSE, KGE, RMSE, MAE, etc.).

All metrics accept an optional `eval_mask` parameter (bool array, same length as
sim/obs). When provided, only positions where eval_mask is True contribute to
the metric. This enables time-aware exclusion (e.g., exclude_years='mask' mode)
without breaking physical continuity of the underlying simulation.

历史教训 (2026-05-27):
exclude_years 之前的实现是从数据 SQL 层 drop 行 + 前后相接 → numba kernel
state 跨年跳跃 → 物理 broken。现在 dataio 加载完整序列,把"哪些时刻不算 loss"
通过 eval_mask 传到指标函数,模型 forward 仍然连续。
"""

from __future__ import annotations

import numpy as np

__all__ = ["nse", "kge", "rmse_score", "mae_score", "nse_peak"]


def _apply_mask(
    sim: np.ndarray,
    obs: np.ndarray,
    eval_mask: np.ndarray | None,
) -> tuple[np.ndarray, np.ndarray]:
    """Combine NaN/Inf mask with optional caller-supplied eval_mask.

    Returns (s, o) filtered to finite positions where eval_mask is True (or all
    finite if eval_mask is None).
    """
    finite = np.isfinite(obs) & np.isfinite(sim)
    if eval_mask is not None:
        if eval_mask.shape != sim.shape:
            raise ValueError(
                f"eval_mask shape {eval_mask.shape} must match sim/obs shape {sim.shape}"
            )
        finite = finite & eval_mask.astype(bool)
    return sim[finite], obs[finite]


def nse(sim: np.ndarray, obs: np.ndarray, *, eval_mask: np.ndarray | None = None) -> float:
    """Compute Nash-Sutcliffe Efficiency (higher is better).

    eval_mask: optional bool array, True = include in loss.
    """
    s, o = _apply_mask(sim, obs, eval_mask)
    if s.size < 2:
        return float("nan")
    denom = np.sum((o - o.mean()) ** 2)
    if denom <= 0:
        return float("nan")
    return 1.0 - float(np.sum((s - o) ** 2) / denom)


def kge(sim: np.ndarray, obs: np.ndarray, *, eval_mask: np.ndarray | None = None) -> float:
    """Compute Kling-Gupta Efficiency (higher is better)."""
    s, o = _apply_mask(sim, obs, eval_mask)
    if s.size < 2:
        return float("nan")
    o = o.astype(float)
    s = s.astype(float)
    try:
        r = float(np.corrcoef(s, o)[0, 1])
    except Exception:
        r = float("nan")
    so = float(np.std(o))
    ss = float(np.std(s))
    mo = float(np.mean(o))
    ms = float(np.mean(s))
    if not np.isfinite(r) or so == 0.0 or not np.isfinite(so):
        return float("nan")
    alpha = ss / so if so != 0 else float("nan")
    beta = ms / mo if mo != 0 else float("nan")
    if not (np.isfinite(alpha) and np.isfinite(beta)):
        return float("nan")
    return 1.0 - float(np.sqrt((r - 1.0) ** 2 + (alpha - 1.0) ** 2 + (beta - 1.0) ** 2))


def rmse_score(sim: np.ndarray, obs: np.ndarray, *, eval_mask: np.ndarray | None = None) -> float:
    """Return negative RMSE so that larger is better."""
    s, o = _apply_mask(sim, obs, eval_mask)
    if s.size < 1:
        return float("nan")
    rmse = float(np.sqrt(np.mean((s - o) ** 2)))
    return -rmse


def mae_score(sim: np.ndarray, obs: np.ndarray, *, eval_mask: np.ndarray | None = None) -> float:
    """Return negative MAE so that larger is better."""
    s, o = _apply_mask(sim, obs, eval_mask)
    if s.size < 1:
        return float("nan")
    mae = float(np.mean(np.abs(s - o)))
    return -mae


def nse_peak(
    sim: np.ndarray,
    obs: np.ndarray,
    *,
    frac: float = 0.9,
    eval_mask: np.ndarray | None = None,
) -> float:
    """Compute NSE on flow above the given quantile (default top 10%)."""
    s, o = _apply_mask(sim, obs, eval_mask)
    if s.size < 2:
        return float("nan")
    try:
        q = float(np.clip(frac, 0.0, 1.0))
        if not (0.0 < q < 1.0):
            q = 0.9
    except Exception:
        q = 0.9
    thr = np.quantile(o, q)
    sel = o >= thr
    if np.sum(sel) < 2:
        return float("nan")
    # already masked; recursion no longer needs eval_mask
    return nse(s[sel], o[sel])
