"""Lead-time stratified forecast verification.

Pure statistical evaluation — takes pre-computed forecast and observation
matrices and computes NSE/KGE/RMSE per lead time.  Does NOT run any model.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import List

import numpy as np

from src.runtime.metrics import nse, kge


@dataclass
class LeadTimeReport:
    """Verification metrics stratified by forecast lead time."""

    lead_times_h: List[int]   # [1, 2, ..., horizon]
    nse: List[float]          # NSE per lead time
    kge: List[float]          # KGE per lead time
    rmse: List[float]         # RMSE per lead time (positive, lower is better)
    n_samples: List[int]      # valid sample count per lead time
    method: str               # "ukf", "enkf", "openloop", etc.

    def to_dict(self) -> dict:
        return asdict(self)


def compute_leadtime_metrics(
    forecasts: np.ndarray,
    obs_matrix: np.ndarray,
    method: str = "da",
) -> LeadTimeReport:
    """Compute verification metrics for each lead time.

    Args:
        forecasts: (n_issues, horizon) predicted discharge values.
        obs_matrix: (n_issues, horizon) observed discharge (may contain NaN).
        method: Label for the report (e.g. "ukf", "openloop").

    Returns:
        LeadTimeReport with per-lead-time NSE, KGE, RMSE.

    Raises:
        ValueError: If inputs have mismatched shapes or zero columns.
    """
    if forecasts.shape != obs_matrix.shape:
        raise ValueError(
            f"Shape mismatch: forecasts {forecasts.shape} != obs {obs_matrix.shape}"
        )
    if forecasts.ndim != 2 or forecasts.shape[1] == 0:
        raise ValueError(
            f"Expected 2D array with >= 1 column, got shape {forecasts.shape}"
        )

    horizon = forecasts.shape[1]

    nse_vals: List[float] = []
    kge_vals: List[float] = []
    rmse_vals: List[float] = []
    n_samples: List[int] = []

    for lt in range(horizon):
        p = forecasts[:, lt]
        o = obs_matrix[:, lt]

        mask = np.isfinite(o) & np.isfinite(p)
        n = int(mask.sum())
        n_samples.append(n)

        if n < 2:
            nse_vals.append(float("nan"))
            kge_vals.append(float("nan"))
            rmse_vals.append(float("nan"))
            continue

        nse_vals.append(nse(p[mask], o[mask]))
        kge_vals.append(kge(p[mask], o[mask]))
        rmse_vals.append(float(np.sqrt(np.mean((p[mask] - o[mask]) ** 2))))

    return LeadTimeReport(
        lead_times_h=list(range(1, horizon + 1)),
        nse=nse_vals,
        kge=kge_vals,
        rmse=rmse_vals,
        n_samples=n_samples,
        method=method,
    )
