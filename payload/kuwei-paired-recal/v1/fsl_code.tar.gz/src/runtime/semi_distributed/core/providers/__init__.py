"""Forecast meteo providers."""
from src.runtime.semi_distributed.core.providers.open_meteo import OpenMeteoProvider
from src.runtime.semi_distributed.core.providers.legacy import PersistenceProvider, ZeroRainProvider
