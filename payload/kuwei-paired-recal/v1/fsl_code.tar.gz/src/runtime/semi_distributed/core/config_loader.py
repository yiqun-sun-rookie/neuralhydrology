"""config_loader.py

Shared configuration loader for optimization tools.
Extracts load_run_config_internal from scripts/run_calibration.py.
"""
from __future__ import annotations
import sys
from pathlib import Path
from typing import Any, Dict, Optional

# Import _load_yaml_with_include
from src.runtime.semi_distributed.tools.eval_with_params import (
    load_yaml_with_include as _load_yaml_with_include,
)

RUN_CONFIG_FILE: Optional[Path] = None
_LAST_RUN_CONFIG_PATH: Optional[str] = None

def set_run_config_path(path: Path) -> None:
    global RUN_CONFIG_FILE
    RUN_CONFIG_FILE = path

def load_run_config_internal() -> Dict[str, Any]:
    global RUN_CONFIG_FILE, _LAST_RUN_CONFIG_PATH
    if RUN_CONFIG_FILE is None or not RUN_CONFIG_FILE.exists():
        raise FileNotFoundError(
            f'未找到 run_config 文件: {RUN_CONFIG_FILE}. 请使用 --run-config 显式指定路径。'
        )
    try:
        data = _load_yaml_with_include(RUN_CONFIG_FILE.resolve(), set())
        _LAST_RUN_CONFIG_PATH = str(RUN_CONFIG_FILE)
        if getattr(load_run_config_internal, '_printed', None) != _LAST_RUN_CONFIG_PATH:
            print(f'[RUNCFG] loaded: {_LAST_RUN_CONFIG_PATH}')
            load_run_config_internal._printed = _LAST_RUN_CONFIG_PATH  # type: ignore
    except Exception as e:
        raise RuntimeError(f'[CRITICAL] 读取 run_config 失败: {RUN_CONFIG_FILE} -> {e}')

    # 展平常见分组：scene/optimizer/diagnostics/time/meta 到顶层键，便于下游统一读取
    if isinstance(data, dict) and any(k in data for k in ('scene', 'optimizer', 'diagnostics', 'time', 'meta')):
        flat: Dict[str, Any] = {}
        for grp in ('scene', 'optimizer', 'diagnostics', 'time', 'meta'):
            g = data.get(grp)
            if isinstance(g, dict):
                for k, v in g.items():
                    if k in flat:
                        raise ValueError(
                            f"Config key collision: '{k}' appears in multiple groups"
                        )
                    flat[k] = v
        for k, v in data.items():
            if k in ('scene', 'optimizer', 'diagnostics', 'time', 'meta', 'include', 'includes'):
                continue
            flat[k] = v
        data = flat

    # Validate required keys
    required_keys = {"basin_name"}
    missing = required_keys - set(data.keys())
    if missing:
        raise ValueError(f"run_config missing required keys: {sorted(missing)}")

    return data

