import sys
from pathlib import Path as _Path

# 确保项目根目录在 Python 路径中
_PROJECT_ROOT = _Path(__file__).resolve().parents[4]
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from src.runtime.semi_distributed.core.optimization_config import OptimizationConfig
from tools.data_preparation.process_cmfd_data.subbasin.step04_read_observed_discharge import (
    read_obs_discharge_csv,
)
import numpy as np
import pandas as pd
import warnings
from typing import Tuple, Optional, Dict, List
from pathlib import Path
import os

# ---------------------------------------------------------------------------
# Module-level CSV cache: avoid re-parsing large meteo/discharge files on
# every API call.  Keyed by (resolved_path, file_mtime).
# ---------------------------------------------------------------------------
_csv_cache: Dict[str, Tuple[float, pd.DataFrame]] = {}


def _read_csv_cached(path: Path, **read_kwargs) -> pd.DataFrame:
    """Read a CSV with per-file mtime cache. Invalidates on file change."""
    key = str(path)
    mtime = path.stat().st_mtime
    if key in _csv_cache:
        cached_mtime, cached_df = _csv_cache[key]
        if cached_mtime == mtime:
            return cached_df.copy()
    df = pd.read_csv(path, **read_kwargs)
    _csv_cache[key] = (mtime, df)
    return df.copy()


def _resolve_exclude_config(cfg) -> tuple[List[int], str]:
    """解析 exclude_years + exclude_mode,返回 (exclude_years_list, effective_mode)。

    Modes:
      - 'mask' (推荐): 加载完整序列, q_obs 在 exclude 年份设 NaN, 模型物理连续 simulate, NSE 自动忽略。
      - 'drop' (legacy, 物理 broken): 数据 SQL 层 drop 行 + 前后相接, state 跨年跳跃。
        仅为 reproduce 历史 ylx run 保留, 不推荐新流程使用。
      - None (exclude_years 空时): 不做任何 exclude。

    Fail-fast: exclude_years 非空 + exclude_mode 缺失 → raise ValueError。
    """
    _ex = cfg.EXCLUDE_YEARS if hasattr(cfg, 'EXCLUDE_YEARS') else None
    if _ex is None:
        exclude_years: List[int] = []
    elif isinstance(_ex, (list, tuple, set)):
        try:
            exclude_years = [int(x) for x in _ex]
        except Exception:
            exclude_years = []
    elif isinstance(_ex, (int, np.integer)):
        exclude_years = [int(_ex)]
    elif isinstance(_ex, str):
        parts = [p.strip() for p in _ex.split(',') if p.strip()]
        try:
            exclude_years = [int(p) for p in parts]
        except Exception:
            exclude_years = []
    else:
        exclude_years = []

    if not exclude_years:
        return [], 'none'

    mode = getattr(cfg, 'EXCLUDE_MODE', None)
    if mode is None or not isinstance(mode, str) or not mode.strip():
        raise ValueError(
            f"[STRICT] exclude_years={exclude_years} 非空,但 exclude_mode 未指定。\n"
            f"请在 run_config.yml 的 time 段显式设置:\n"
            f"  exclude_mode: 'mask'   # 推荐: 加载完整序列, exclude 年 q_obs 设 NaN, 物理连续\n"
            f"  exclude_mode: 'drop'   # legacy: SQL drop 行+前后相接, state 跨年跳跃 (物理 broken, 仅 reproduce 历史)"
        )
    mode = mode.strip().lower()
    if mode not in ('mask', 'drop'):
        raise ValueError(f"[STRICT] exclude_mode 必须是 'mask' 或 'drop',got {mode!r}")
    if mode == 'drop':
        print(
            f"[WARN] exclude_mode='drop' is LEGACY (physically broken: state propagates across year boundary). "
            f"exclude_years={exclude_years} are dropped from SQL and rows are concatenated. "
            f"Consider switching to 'mask' mode for new runs."
        )
    return exclude_years, mode


def _try_load_from_db(cfg, *, max_gap_hours: int = 168):
    """Attempt to load meteo + discharge from timeseries.db.

    Returns (meteo, discharge_series, station_df) or None if DB not found.

    exclude_years 处理:
      - mode='mask': 加载完整数据, q_obs 在 exclude 年设 NaN (下游 NSE 自动忽略)
      - mode='drop': SQL drop 行 (legacy, state 不连续)
    详见 _resolve_exclude_config 文档。
    """
    db_path = Path(getattr(cfg, "DATA_DIR", "") or "") / "timeseries.db"
    if not db_path.exists():
        return None

    from src.data.tsdb import open_db, query_meteo, query_discharge

    conn = open_db(db_path)

    exclude_years, exclude_mode = _resolve_exclude_config(cfg)
    # 仅 drop 模式才传 exclude_years 到 SQL 层做物理 drop;mask 模式保留完整序列
    sql_exclude_years = exclude_years if exclude_mode == 'drop' else []

    # --- Meteo ---
    meteo = query_meteo(conn, cfg.START_TIME, cfg.END_TIME, exclude_years=sql_exclude_years)
    if meteo.empty:
        conn.close()
        return None  # fall back to CSV

    # Rename columns to match CSV format (rain -> rain_g0, etc.) for downstream compat
    rename_map = {}
    for col in ("rain", "temp", "pet", "snow"):
        if col in meteo.columns:
            rename_map[col] = f"{col}_g0"
    meteo = meteo.rename(columns=rename_map)

    meteo_time = pd.DatetimeIndex(meteo["time"])

    # --- Discharge ---
    discharge_series = query_discharge(
        conn, cfg.START_TIME, cfg.END_TIME, exclude_years=sql_exclude_years,
    )
    # Reindex to meteo time and interpolate (same logic as CSV path)
    discharge_series = discharge_series.reindex(meteo_time)
    _dt_hours = max(1, int(round(
        meteo_time.to_series().diff().median().total_seconds() / 3600
    ))) if len(meteo_time) > 1 else 1
    _interp_limit = max(1, int(max_gap_hours / _dt_hours))
    discharge_series = (
        discharge_series
        .interpolate(method="time", limit=_interp_limit)
        .ffill().bfill()
        .astype(np.float32)
    )
    discharge_series.index = meteo_time

    # Validate discharge (在 mask NaN-out 之前, 确保原始数据完整)
    _vals = discharge_series.to_numpy(np.float32)
    if not np.isfinite(_vals).all():
        bad_mask = ~np.isfinite(_vals)
        bad_times = discharge_series.index[bad_mask]
        samples = [str(ts) for ts in bad_times[:1]]
        raise ValueError(
            f"[FATAL] DB discharge contains NaN/Inf after interpolation. "
            f"Samples: {samples[0] if samples else 'N/A'}"
        )

    # mask 模式: 把 exclude 年的 q_obs 设 NaN,模型仍然 forward simulate 全段 (state 连续),
    # 但 NSE 因 NaN-mask 自动跳过这些时刻。
    if exclude_mode == 'mask' and exclude_years:
        _yr = discharge_series.index.year
        _mask = np.isin(_yr.values, list(exclude_years))
        if _mask.any():
            arr = discharge_series.to_numpy(copy=True).astype(np.float32)
            arr[_mask] = np.nan
            discharge_series = pd.Series(arr, index=discharge_series.index, name='discharge', dtype=np.float32)
            print(f"[EXCLUDE/mask] q_obs at exclude_years={list(exclude_years)} set to NaN: {_mask.sum()} hours skipped from NSE loss (sim runs continuously)")

    conn.close()

    # --- Station inflow (ylx only, still from CSV) ---
    station_df: Optional[pd.DataFrame] = None
    if getattr(cfg, 'SECTION_NAME', None) == "ylx":
        inflow_path = cfg.DATA_DIR / "reach_inflow.csv"
        if inflow_path.exists():
            station_df = (
                pd.read_csv(inflow_path, parse_dates=["time"])
                .set_index("time")
                .reindex(meteo["time"])
                .astype(np.float32)
            )

    print(f"[FILES] meteo=timeseries.db discharge=timeseries.db")
    return meteo, discharge_series, station_df


def _resolve_discharge_path(cfg: OptimizationConfig) -> Path:
    section = getattr(cfg, 'SECTION_NAME', 'ylx')
    custom = getattr(cfg, 'OBS_DISCHARGE_FILE', None)
    candidates: List[Path] = []
    if custom:
        p = Path(str(custom))
        if not p.is_absolute():
            p = cfg.PROJECT_ROOT / p
        candidates.append(p)
    data_dir = getattr(cfg, 'DATA_DIR', None)
    if data_dir is None:
        basin = getattr(cfg, 'BASIN_NAME', None) or ''
        data_dir = cfg.PROJECT_ROOT / "data/processed" / basin
    if data_dir:
        base = Path(data_dir)
        candidates.append(base / f"{section}_discharge_hourly" / "obs_discharge_hourly.csv")
        candidates.append(base / f"{section}_discharge_daily" / "obs_discharge_daily.csv")
    
    print(f"[DEBUG_DATAIO] section={section}")
    print(f"[DEBUG_DATAIO] data_dir={data_dir}")
    print(f"[DEBUG_DATAIO] candidates={[str(c) for c in candidates]}")

    for cand in candidates:
        if cand.exists():
            print(f"[DEBUG_DATAIO] Found: {cand}")
            return cand
    
    print(f"[DEBUG_DATAIO] NOT FOUND any candidate.")
    raise FileNotFoundError(f"未找到观测流量文件。请在 DATA_DIR 下提供 {section}_discharge_hourly/obs_discharge_hourly.csv "
                            f"或 {section}_discharge_daily/obs_discharge_daily.csv，或通过 OBS_DISCHARGE_FILE 显式指定。")


def _resolve_meteo_path(c) -> Path:
    explicit = getattr(c, 'METEO_FILE', None) or os.environ.get('METEO_FILE')
    candidates: List[Path] = []
    if explicit:
        p = Path(str(explicit))
        if p.is_absolute():
            candidates.append(p)
        else:
            candidates.append(c.SEMI_DISTRIBUTED_ROOT / p)
            candidates.append(c.PROJECT_ROOT / p)
    
    # 1. 优先查找当前 BASIN/SECTION 下的数据 (Standard Basin Structure)
    section = getattr(c, 'SECTION_NAME', 'ylx')
    candidates.append(c.PROJECT_ROOT / 'basins' / section / 'data' / 'inputs' / 'grid_meteo_pet_daily.csv')
    
    # 2. 兼容旧位置 (Legacy)
    candidates.append(c.SEMI_DISTRIBUTED_ROOT / 'data' / 'grid_meteo_pet_daily.csv')
    candidates.append(c.SEMI_DISTRIBUTED_ROOT / 'grid_meteo_pet_daily.csv')
    
    for cp in candidates:
        if cp.exists():
            return cp
    
    raise FileNotFoundError(
        "未找到气象输入 CSV。请设置 cfg.METEO_FILE 或 METEO_FILE 环境变量，"
        f"或确保文件位于 basins/{section}/data/inputs/grid_meteo_pet_daily.csv。"
    )


def load_data(cfg: OptimizationConfig, *, max_gap_hours: int = 168) -> Tuple[pd.DataFrame, pd.Series, Optional[pd.DataFrame]]:
    """加载气象、流量和外接测站数据

    Parameters
    ----------
    max_gap_hours : int
        Maximum gap (in hours) that time-interpolation is allowed to fill.
        Gaps larger than this are filled with ffill/bfill instead, and a
        warning is emitted.  Default 168 (7 days).
    """
    # --- Try SQLite DB first (Phase 1 migration) ---
    db_result = _try_load_from_db(cfg, max_gap_hours=max_gap_hours)
    if db_result is not None:
        return db_result
    # --- Fall back to CSV ---

    # exclude_years + exclude_mode: 见 _resolve_exclude_config 文档
    exclude_years, exclude_mode = _resolve_exclude_config(cfg)
    # 仅 drop 模式才在数据加载时物理 drop 行;mask 模式保留完整序列, 后续 q_obs NaN-out
    csv_exclude_years = exclude_years if exclude_mode == 'drop' else []

    # --- 气象数据 ---
    # 允许灵活位置：优先 METEO_FILE（cfg 属性或环境变量），否则依次尝试
    #   1) experiments/semi_distributed/data/grid_meteo_pet_daily.csv
    #   2) experiments/semi_distributed/grid_meteo_pet_daily.csv（旧位置）


    meteo_path = _resolve_meteo_path(cfg)
    meteo = (
        _read_csv_cached(meteo_path, parse_dates=["time"])
        .query(f"'{cfg.START_TIME}' <= time <= '{cfg.END_TIME}'")
        .loc[lambda df: ~df["time"].dt.year.isin(csv_exclude_years)]
        .sort_values("time")
        .reset_index(drop=True)
    )
    meteo_time = pd.DatetimeIndex(meteo["time"])

    # --- 最下游流量（与气象时间轴对齐，优先逐小时） ---
    discharge_path = _resolve_discharge_path(cfg)
    _dk = str(discharge_path)
    _dm = discharge_path.stat().st_mtime
    if _dk in _csv_cache and _csv_cache[_dk][0] == _dm:
        discharge_df = _csv_cache[_dk][1].copy()
    else:
        discharge_df = read_obs_discharge_csv(str(discharge_path), missing_value=np.nan)
        _csv_cache[_dk] = (_dm, discharge_df)
        discharge_df = discharge_df.copy()
    discharge_df = (
        discharge_df
        .dropna(subset=["time"])
        .sort_values("time")
    )
    discharge_df = discharge_df.loc[
        (discharge_df["time"] >= pd.to_datetime(cfg.START_TIME))
        & (discharge_df["time"] <= pd.to_datetime(cfg.END_TIME))
    ]
    if csv_exclude_years:
        discharge_df = discharge_df.loc[~discharge_df["time"].dt.year.isin(csv_exclude_years)]
    discharge_series = discharge_df.set_index("time")["discharge"]
    discharge_series = discharge_series[~discharge_series.index.duplicated(keep="first")]
    discharge_series = discharge_series.reindex(meteo_time)
    # Infer timestep from meteo index to compute interpolation limit
    _dt_hours = max(1, int(round(meteo_time.to_series().diff().median().total_seconds() / 3600))) if len(meteo_time) > 1 else 1
    _interp_limit = max(1, int(max_gap_hours / _dt_hours))
    discharge_series = discharge_series.interpolate(method="time", limit=_interp_limit).ffill().bfill().astype(np.float32)
    # Warn if there were large gaps that interpolation could not fill
    _gap_mask = discharge_series.reindex(meteo_time).isna()
    if _gap_mask.any():
        warnings.warn(
            f"[WARN] 流量数据存在超过 {max_gap_hours}h 的间隙，已用前后填充代替插值",
            RuntimeWarning,
        )
    discharge_series.index = meteo_time

    # 缺失处理：先警告(可抑制)，再尝试时间插值 + 前后填充；若仍有缺失则报错
    _vals = discharge_series.to_numpy(np.float32)
    if not np.isfinite(_vals).all():
        bad_mask = ~np.isfinite(_vals)
        bad_times = discharge_series.index[bad_mask]
        samples = [str(ts) for ts in bad_times[:1]]
        if os.environ.get('SUPPRESS_DISCHARGE_WARN', '0') != '1':
            warnings.warn(f"[WARN] 下游流量存在缺失/非法值: {bad_mask.sum()} 个；将执行时间插值+前后填充；示例: {samples[0] if samples else 'N/A'}", RuntimeWarning)
        discharge_series = (
            discharge_series
            .interpolate(method="time", limit=_interp_limit)
            .ffill()
            .bfill()
            .astype(np.float32)
        )
        _vals2 = discharge_series.to_numpy(np.float32)
        if not np.isfinite(_vals2).all():
            bad2 = ~np.isfinite(_vals2)
            bad_times2 = discharge_series.index[bad2]
            samples2 = [str(ts) for ts in bad_times2[:10]]
            raise ValueError(
                f"[FATAL] 下游流量在插值与前后填充后仍含 NaN/Inf。示例时间点: {samples2}.\n"
                f"请清洗 {discharge_path} 或调整时间窗。"
            )

    # --- 外接区间入流 (仅 ylx 需要) ---
    station_df: Optional[pd.DataFrame] = None
    if cfg.SECTION_NAME == "ylx":
        inflow_path = cfg.DATA_DIR / "reach_inflow.csv"
        station_df = (
            pd.read_csv(inflow_path, parse_dates=["time"])  # type: ignore[arg-type]
            .set_index("time")
            .reindex(meteo["time"])  # 与过滤后的 meteo 时间轴严格对齐
            .astype(np.float32)
        )
        # 简洁列名提示（候选列），避免冗长输出
        try:
            cols = station_df.columns.tolist()
            summary = ", ".join(map(str, cols[:3])) + (", ..." if len(cols) > 3 else "")
            print(f"[FILES] inflow={inflow_path} (cols: {summary})")
        except Exception:
            pass

        # 严格校验：外接测站不得含 NaN/Inf
        _arr = station_df.to_numpy(np.float32)
        if (~np.isfinite(_arr)).any():
            bad_positions = np.argwhere(~np.isfinite(_arr))[:10]
            samples = [
                (str(station_df.index[i]), str(station_df.columns[j]))
                for i, j in bad_positions
            ]
            raise ValueError(
                f"[FATAL] 外接测站流量含 NaN/Inf。示例(时间, 站点): {samples}.\n"
                f"请清洗 {inflow_path} 或与气象时间轴对齐。"
            )

    # mask 模式: 把 exclude 年的 q_obs 设 NaN, 模型仍然 forward simulate 全段 (state 连续),
    # 但 NSE 因 NaN-mask 自动跳过这些时刻。
    if exclude_mode == 'mask' and exclude_years:
        _yr = discharge_series.index.year
        _mask = np.isin(_yr.values, list(exclude_years))
        if _mask.any():
            arr = discharge_series.to_numpy(copy=True).astype(np.float32)
            arr[_mask] = np.nan
            discharge_series = pd.Series(arr, index=discharge_series.index, name='discharge', dtype=np.float32)
            print(f"[EXCLUDE/mask] q_obs at exclude_years={list(exclude_years)} set to NaN: {_mask.sum()} hours skipped from NSE loss (sim runs continuously)")

    # 文件使用摘要（单行）
    try:
        print(f"[FILES] meteo={meteo_path} discharge={discharge_path}")
    except Exception:
        pass

    return meteo, discharge_series, station_df


def prepare_meteo_inputs(
    flood_meteo: pd.DataFrame,
    Ng: int,
    *,
    t_snow: Optional[float] = None,
    t_rain: Optional[float] = None,
    precip_mode: Optional[str] = None,
    rain_cols: Optional[List[str]] = None,
    snow_cols: Optional[List[str]] = None,
    total_precip_col: Optional[str] = None,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, pd.DatetimeIndex]:
    """
    将气象 DataFrame 转换为模型所需的 NumPy 数组。
    返回 (rain, temp, snow, pet, time_index)
    """
    m = flood_meteo

    # 规范化配置
    def _norm_cols(cols: Optional[List[str]]) -> Optional[List[str]]:
        if cols is None:
            return None
        if isinstance(cols, (list, tuple)):
            return [str(c) for c in cols if str(c)]
        return None

    mode = (precip_mode or '').strip().lower() if isinstance(precip_mode, str) else None
    rain_cols = _norm_cols(rain_cols)
    snow_cols = _norm_cols(snow_cols)
    total_precip_col = (str(total_precip_col) if total_precip_col else None)

    # 小工具：按列名后缀对齐 rain_gN / snow_gN 的顺序，确保与 Ng 一致
    import re as _re
    def _align_by_suffix(df_in: pd.DataFrame, prefix: str, Ng_expect: int) -> pd.DataFrame:
        cols = list(df_in.columns)
        pattern = _re.compile(rf"^{prefix}(\d+)$", _re.IGNORECASE)
        idx_pairs = []
        for c in cols:
            m = pattern.match(str(c))
            if not m:
                return df_in  # 含有非标准列名，保持原序
            idx_pairs.append((int(m.group(1)), c))
        idxs = [i for i, _ in idx_pairs]
        # 仅当严格覆盖 [0..Ng-1] 时才重排；否则保持原序并给出提示
        if len(idxs) == Ng_expect and sorted(idxs) == list(range(Ng_expect)):
            idx_pairs.sort(key=lambda x: x[0])
            ordered_cols = [c for _, c in idx_pairs]
            return df_in[ordered_cols]
        else:
            try:
                print(f"[WARN] {prefix} 列数量/索引与 Ng 不一致: Ng={Ng_expect}, 列数={len(cols)}, 索引范围={min(idxs) if idxs else 'NA'}~{max(idxs) if idxs else 'NA'}；保持文件原序")
            except Exception:
                pass
            return df_in

    # 气温与潜在蒸散
    temp_g_df = m.filter(like="temp_g")
    if temp_g_df.shape[1] == 0:
        temp_g_df = m.filter(regex=r"(?i)\btemp\b")
    temp = (
        np.repeat(temp_g_df.to_numpy(np.float32), Ng, axis=1)
        if temp_g_df.shape[1] == 1
        else temp_g_df.to_numpy(np.float32)
    )
    pet_g_df = m.filter(like="pet_g")
    if pet_g_df.shape[1] == 0:
        pet_g_df = m.filter(regex=r"(?i)\bpet\b")
    pet = (
        np.repeat(pet_g_df.to_numpy(np.float32), Ng, axis=1)
        if pet_g_df.shape[1] == 1
        else pet_g_df.to_numpy(np.float32)
    )

    if mode in ("columns", "use_columns", "explicit"):
        # 明确使用给定列名
        if rain_cols:
            missing = [c for c in rain_cols if c not in m.columns]
            if missing:
                raise ValueError(f"[FATAL] 配置的 rain_cols 缺失列: {missing}")
            rain_df = m[rain_cols]
        else:
            rain_df = m.filter(like="rain_g")
            if rain_df.shape[1] == 0:
                raise ValueError("[FATAL] precip.mode=columns 但未提供 rain_cols，且未找到 rain_g* 列")
        # 若命名规范为 rain_gN，尝试按数字后缀与 Ng 对齐
        if rain_df.shape[1] > 1:
            rain_df = _align_by_suffix(rain_df, 'rain_g', Ng)
        rain = rain_df.to_numpy(np.float32)
        if rain_df.shape[1] == 1:
            rain = np.repeat(rain, Ng, axis=1)

        if snow_cols:
            missing = [c for c in snow_cols if c not in m.columns]
            if missing:
                raise ValueError(f"[FATAL] 配置的 snow_cols 缺失列: {missing}")
            snow_df = m[snow_cols]
        else:
            snow_df = m.filter(like="snow_g")
            if snow_df.shape[1] == 0:
                raise ValueError("[FATAL] precip.mode=columns 但未提供 snow_cols，且未找到 snow_g* 列")
        if snow_df.shape[1] > 1:
            snow_df = _align_by_suffix(snow_df, 'snow_g', Ng)
        snow = snow_df.to_numpy(np.float32)
        if snow_df.shape[1] == 1:
            snow = np.repeat(snow, Ng, axis=1)
        print(f"[METEO] 使用显式降水列: rain={list(rain_df.columns)}, snow={list(snow_df.columns)}")

    elif mode in ("split", "temperature_split", "temp_split"):
        # 强制按温度划分
        if not total_precip_col or total_precip_col not in m.columns:
            raise ValueError("[FATAL] precip.mode=split 需要明确 total_precip_col 且该列必须存在于气象表")
        total_df = m[[total_precip_col]]
        total = total_df.to_numpy(np.float32)
        if total.shape[1] == 1:
            total = np.repeat(total, Ng, axis=1)
        T_snow = 0.0 if (t_snow is None) else float(t_snow)
        T_rain = 2.0 if (t_rain is None) else float(t_rain)
        if not np.isfinite(T_snow):
            T_snow = 0.0
        if not np.isfinite(T_rain):
            T_rain = 2.0
        T_snow = float(np.clip(T_snow, -10.0, 10.0))
        T_rain = float(np.clip(T_rain, -10.0, 10.0))
        if T_rain <= T_snow:
            T_rain = T_snow + 0.5
        frac_snow = np.clip((T_rain - temp) / max(T_rain - T_snow, 1e-6), 0.0, 1.0).astype(np.float32)
        snow = (total * frac_snow).astype(np.float32)
        rain = (total - snow).astype(np.float32)
        snow = np.maximum(snow, 0.0).astype(np.float32)
        rain = np.maximum(rain, 0.0).astype(np.float32)
        try:
            total_p = float(np.nansum(total))
            total_s = float(np.nansum(snow))
            snow_share = (total_s / total_p) if (np.isfinite(total_p) and total_p > 0) else float('nan')
            print(f"[METEO] 按温度划分降水: total='{total_precip_col}', T_snow={T_snow}, T_rain={T_rain}, 雪占比≈{snow_share:.2%}")
        except Exception:
            pass

    else:
        # 历史自动检测兼容
        rain_df = m.filter(like="rain_g")
        if rain_df.shape[1] == 0:
            alt_rain_df = m.filter(regex=r"(?i)\brain(?!_depth)\b|(?i)\bprecip_?liquid\b")
            if alt_rain_df.shape[1] > 0:
                print(f"[INFO] 未发现 rain_g 列，改用备选液态雨列: {alt_rain_df.columns.tolist()}")
                rain_df = alt_rain_df
        if rain_df.shape[1] == 0:
            raise ValueError("[FATAL] 未找到液态降雨列 rain_g 或常见备选名(rain, precip_liquid)。")
        if rain_df.shape[1] > 1 and all(str(c).lower().startswith('rain_g') for c in rain_df.columns):
            rain_df = _align_by_suffix(rain_df, 'rain_g', Ng)
        rain = (
            np.repeat(rain_df.to_numpy(np.float32), Ng, axis=1)
            if rain_df.shape[1] == 1
            else rain_df.to_numpy(np.float32)
        )

        snowg_df = m.filter(like="snow_g")
        if snowg_df.shape[1] > 0:
            if snowg_df.shape[1] > 1:
                snowg_df = _align_by_suffix(snowg_df, 'snow_g', Ng)
            snow = snowg_df.to_numpy(np.float32)
            if snow.shape[1] == 1:
                snow = np.repeat(snow, Ng, axis=1)
        else:
            snow_alt = m.filter(regex=r"(?i)\bsnow(?!_depth)\b|(?i)\bprsn\b|(?i)\bprecip_?solid\b")
            if snow_alt.shape[1] > 0:
                print(f"[INFO] 未发现 snow_g 列，改用备选固态降水列: {snow_alt.columns.tolist()}")
                snow = snow_alt.to_numpy(np.float32)
                if snow.shape[1] == 1:
                    snow = np.repeat(snow, Ng, axis=1)
            else:
                # 简单线性相态划分
                T_snow = 0.0 if (t_snow is None) else float(t_snow)
                T_rain = 2.0 if (t_rain is None) else float(t_rain)
                if not np.isfinite(T_snow):
                    T_snow = 0.0
                if not np.isfinite(T_rain):
                    T_rain = 2.0
                T_snow = float(np.clip(T_snow, -10.0, 10.0))
                T_rain = float(np.clip(T_rain, -10.0, 10.0))
                if T_rain <= T_snow:
                    T_rain = T_snow + 0.5
                frac_snow = np.clip((T_rain - temp) / max(T_rain - T_snow, 1e-6), 0.0, 1.0).astype(np.float32)
                total_precip = rain.astype(np.float32)
                snow = (total_precip * frac_snow).astype(np.float32)
                rain = (total_precip - snow).astype(np.float32)
                snow = np.maximum(snow, 0.0).astype(np.float32)
                rain = np.maximum(rain, 0.0).astype(np.float32)
                try:
                    total_p = float(np.nansum(total_precip))
                    total_s = float(np.nansum(snow))
                    snow_share = (total_s / total_p) if (np.isfinite(total_p) and total_p > 0) else float('nan')
                    warnings.warn(
                        f"[INFO] 未检测到 snow_g 列，已按温度阈值(T_snow={T_snow},T_rain={T_rain})从降水推断固态； 雪占比≈{snow_share:.2%}。若 rain_g 已是'仅液态'，请提供总降水或关闭该推断。",
                        RuntimeWarning,
                    )
                except Exception:
                    pass

    # 严格检验：若有空值立即报错
    for arr_name, arr in [( 'rain', rain), ('snow', snow), ('temp', temp), ('pet', pet)]:
        if not np.isfinite(arr).all():
            bad_idx = np.argwhere(~np.isfinite(arr))[:10]
            raise ValueError(
                f"[FATAL] {arr_name} 包含 NaN/Inf，样例位置: {bad_idx}. 请先清洗源 CSV，再运行模型。"
            )

    return rain, temp, snow, pet, m["time"]


def prepare_external_flow_inputs(
    observed_station_flow: Optional[pd.DataFrame],
    station_reach_map: Optional[Dict[str, int]],
    time_index: pd.DatetimeIndex,
    override_stations: Optional[List[str]] = None,
) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
    """
    预处理外接流量数据。
    返回 (obs_station_arr, sta_reach_idx)
    """
    if observed_station_flow is None or station_reach_map is None:
        return None, None

    # 1. 对齐时间
    if "time" in observed_station_flow.columns:
        observed_station_flow = observed_station_flow.set_index("time")
    obs_aligned = observed_station_flow.reindex(time_index, fill_value=np.nan)

    # 2. 站点列筛选：可选 override_stations
    station_ids_all = list(station_reach_map.keys())
    station_ids = station_ids_all if override_stations is None else [sid for sid in station_ids_all if sid in override_stations]
    if not station_ids:
        print("[INFO] 外接测站覆写被禁用：override_stations 空或无匹配 (available=", station_ids_all, ")")
        return None, None

    # 3. 转换为数组并校验
    obs_station_arr = obs_aligned[station_ids].to_numpy(np.float32)
    sta_reach_idx = np.array([station_reach_map[sid] for sid in station_ids], np.int32)
    if obs_station_arr is not None and (~np.isfinite(obs_station_arr)).any():
        bad_idx = np.argwhere(~np.isfinite(obs_station_arr))[:10]
        raise ValueError(
            f"[FATAL] 外接测站流量含 NaN/Inf，样例位置: {bad_idx}. 请检查 reach_inflow.csv。"
        )

    if override_stations is None:
        print(f"[INFO] 覆写模式=全部可用测站 (使用 {station_ids})")
    else:
        excluded = [sid for sid in station_ids_all if sid not in station_ids]
        if excluded:
            print(f"[INFO] 实际用于覆写的测站: {station_ids}; 已忽略(未列在 override_stations): {excluded}")
        else:
            print(f"[INFO] 实际用于覆写的测站: {station_ids}")
    return obs_station_arr, sta_reach_idx


def prepare_forecast_meteo(
    rain: np.ndarray,
    temp: np.ndarray,
    snow: np.ndarray,
    pet: np.ndarray,
    time_index: pd.DatetimeIndex,
    forecast_steps: int,
    dt_hours: float,
    method: str,
    *,
    obs_station: Optional[np.ndarray] = None,
    basin_coords: Optional[list] = None,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, pd.DatetimeIndex, Optional[np.ndarray], np.ndarray]:
    """Extend meteorological arrays with naive forecast beyond the observation period.

    Parameters
    ----------
    rain, temp, snow, pet : (T, Ng) float32
    time_index : (T,)
    forecast_steps : number of steps to extend
    dt_hours : timestep in hours
    method : "persistence" | "zero_rain" | NWP provider name (e.g. "ecmwf_ifs", "gfs", "auto")
    obs_station : (T, N_sta) optional external station inflow
    basin_coords : list of (lat, lon) tuples for NWP forecast queries

    Returns
    -------
    (rain_ext, temp_ext, snow_ext, pet_ext, time_ext, obs_station_ext, forecast_rain_input)
    """
    _LEGACY_METHODS = {"persistence", "zero_rain"}

    if forecast_steps <= 0:
        raise ValueError(f"forecast_steps must be > 0, got {forecast_steps}")

    T, Ng = rain.shape

    if method in _LEGACY_METHODS:
        # --- Legacy code path (unchanged) ---
        # Build forecast arrays
        if method == "persistence":
            fc_rain = np.tile(rain[-1:], (forecast_steps, 1)).astype(np.float32)
            fc_temp = np.tile(temp[-1:], (forecast_steps, 1)).astype(np.float32)
            fc_snow = np.tile(snow[-1:], (forecast_steps, 1)).astype(np.float32)
            fc_pet = np.tile(pet[-1:], (forecast_steps, 1)).astype(np.float32)
        else:  # zero_rain
            fc_rain = np.zeros((forecast_steps, Ng), dtype=np.float32)
            fc_snow = np.zeros((forecast_steps, Ng), dtype=np.float32)
            fc_temp = np.tile(temp[-1:], (forecast_steps, 1)).astype(np.float32)
            fc_pet = np.tile(pet[-1:], (forecast_steps, 1)).astype(np.float32)
    else:
        # --- NWP provider code path ---
        from src.runtime.semi_distributed.core.forecast_meteo_provider import get_provider

        provider = get_provider(method)

        # For legacy providers that need last observation values
        if hasattr(provider, "last_rain"):
            provider.last_rain = rain[-1]
            provider.last_temp = temp[-1]
            provider.last_snow = snow[-1]
            provider.last_pet = pet[-1]

        coords = basin_coords or [(20.5, 102.1)]  # Nam Ou default centroid
        start_time = time_index[-1].to_pydatetime()
        if start_time.tzinfo is None:
            from datetime import timezone
            start_time = start_time.replace(tzinfo=timezone.utc)

        result = provider.fetch(coords, start_time, forecast_steps, dt_hours)

        fc_rain = result.rain
        fc_temp = result.temp
        fc_snow = result.snow
        fc_pet = result.pet

    forecast_rain_input = fc_rain.copy()

    # Concatenate
    rain_ext = np.concatenate([rain, fc_rain], axis=0)
    temp_ext = np.concatenate([temp, fc_temp], axis=0)
    snow_ext = np.concatenate([snow, fc_snow], axis=0)
    pet_ext = np.concatenate([pet, fc_pet], axis=0)

    # Extend time index
    last_time = time_index[-1]
    dt = pd.Timedelta(hours=dt_hours)
    fc_times = pd.date_range(last_time + dt, periods=forecast_steps, freq=dt)
    time_ext = time_index.append(fc_times)

    # Extend obs_station if present
    obs_station_ext = None
    if obs_station is not None:
        fc_obs = np.tile(obs_station[-1:], (forecast_steps, 1)).astype(np.float32)
        obs_station_ext = np.concatenate([obs_station, fc_obs], axis=0)

    return rain_ext, temp_ext, snow_ext, pet_ext, time_ext, obs_station_ext, forecast_rain_input


def aggregate_meteo_by_sub(
    rain: np.ndarray,
    temp: np.ndarray,
    snow: np.ndarray,
    pet: np.ndarray,
    grid2sub: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """将 (T, Ng) 的格点气象强制量按 grid2sub 列归一聚合到 (T, Ns)。

    规则：对每个子流域 j，令权重 w[:, j] = grid2sub[:, j] / sum(grid2sub[:, j])。
    若发现某列和为 0（异常数据），直接报错，禁止隐式回退。
    """
    if rain.ndim != 2 or temp.ndim != 2 or snow.ndim != 2 or pet.ndim != 2:
        raise ValueError("aggregate_meteo_by_sub 期望二维数组 (T, Ng)")
    Ng2, Ns = grid2sub.shape
    if rain.shape[1] != Ng2 or temp.shape[1] != Ng2 or snow.shape[1] != Ng2 or pet.shape[1] != Ng2:
        raise ValueError("aggregate_meteo_by_sub: 输入列数必须等于 grid2sub 的 Ng")
    g2s = np.asarray(grid2sub, dtype=np.float32)
    col_sum = g2s.sum(axis=0).astype(np.float32)
    if np.any(col_sum == 0):
        bad_cols = np.where(col_sum == 0)[0].tolist()
        raise ValueError(f"[STRICT] grid2sub 存在列和为 0 的子流域: {bad_cols}，无法进行权重归一聚合。请修正矩阵或选择 grid 模式。")
    W = g2s / col_sum  # (Ng,Ns)
    # 聚合 (T,Ng) @ (Ng,Ns) -> (T,Ns)
    rain_s = rain @ W
    temp_s = temp @ W
    snow_s = snow @ W
    pet_s  = pet  @ W
    return rain_s.astype(np.float32), temp_s.astype(np.float32), snow_s.astype(np.float32), pet_s.astype(np.float32)

