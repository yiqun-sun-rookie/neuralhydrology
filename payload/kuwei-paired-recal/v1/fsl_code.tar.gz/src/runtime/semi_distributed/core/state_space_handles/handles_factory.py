"""Factory for full-state transition & observation handles (state-space hydrologic model).

This module provides state-space handles for optimization workflows.

Naming:
  - state_transition_function: pure physical step (no observation aggregation)
  - observation_function: pure extraction from routed Muskingum states
  - state_layout: static shapes / offsets / layer topology / flatten spec

This MVP reuses existing low level functions in
`src.kernels.semi_distributed.core.simulate_flood_distributed_fast_state_space`:
  - state_transition_step
  - observation_function (renamed pure version)

It builds a structured state container:
  state_struct = {
      'units': np.ndarray (n_units, n_state_unit),
      'msk':   List[np.ndarray]  # per-layer Muskingum state matrices
  }

Flatten / unflatten spec is stored in state_layout['flatten_spec'] and will be
implemented later (task #23). For now we return placeholder helpers that raise
if called to avoid silent misuse.
"""
from __future__ import annotations
from typing import Dict, Any, List, Tuple, Callable
import numpy as np

# Import required primitives from the existing core module
from src.kernels.semi_distributed.core.simulate_flood_distributed_fast_state_space import (
    state_transition_step as _state_transition_step,
    observation_function as _observation_function,
)


def _init_msk_states(msk_layers_params: List[Tuple], init_flow_scalar: float) -> List[np.ndarray]:
    """Create initial Muskingum layer states filled with a scalar initial discharge.

    Each layer matrix shape: (n_reach_layer, max_n_layer)
    """
    msk_states: List[np.ndarray] = []
    for idx, c0, c1, c2, n_sub in msk_layers_params:
        max_n = int(n_sub.max()) + 1
        msk_states.append(np.full((len(idx), max_n), init_flow_scalar, np.float32))
    return msk_states


def build_full_state_handles(
    *,
    init_units_state: np.ndarray,              # (n_units, n_state_unit)
    msk_layers_params: List[Tuple],            # [(idx, c0, c1, c2, n_sub), ...]
    layer_connect_mats: List[np.ndarray] | None,
    grid2sub: np.ndarray,                      # (n_units, Ns)
    pdd_pars: Tuple[np.ndarray, ...],          # tuple 4 × (n_units,)
    xaj_pars: Tuple[np.ndarray, ...],          # tuple 17 × (n_units,)
    state_layout_name: str = "full",
) -> Dict[str, Any]:
    """Build handles for full hydrologic state transition & observation.

    Returns dict keys:
      - state_transition_function(state_struct, forcings_vec) -> next_state_struct
          forcings_vec shape (4, n_units) or (4,) broadcasting per variable supported.
      - observation_function(state_struct, *, mode='basin_sum') -> y
          mode in {'basin_sum','last_layer_vector'}
      - init_state_struct: initial structured state (deep copy safe for external use)
      - state_layout: static info (sizes, layer shapes, flatten_spec placeholder)

    Notes:
      * NO process noise injection (slot can be added later).
      * The internal low-level routing logic is reused via `_state_transition_step`.
    """
    if layer_connect_mats is None:
        layer_connect_mats = []

    # Basic shape guards
    if init_units_state.ndim != 2:
        raise ValueError("init_units_state must be 2D (n_units, n_state_unit)")
    n_units, n_state_unit = init_units_state.shape

    # Derive initial discharge scalar from last 3 columns (consistent with core)
    q0 = init_units_state[:, -3:].sum(axis=1)
    q0_scalar = float(q0[0]) if q0.size else 0.0

    # Build Muskingum initial states
    msk_states0 = _init_msk_states(msk_layers_params, q0_scalar)

    init_state_struct = {
        'units': init_units_state.copy().astype(np.float32, copy=False),
        'msk': [m.copy() for m in msk_states0],
    }

    # ----- Build state_layout (static description) -----
    layer_reach_counts = [len(p[0]) for p in msk_layers_params]
    msk_shapes = [s.shape for s in msk_states0]
    flatten_spec = {
        'order': ['units'] + [f'msk_{i}' for i in range(len(msk_states0))],
        'shapes': {
            'units': init_units_state.shape,
            **{f'msk_{i}': shape for i, shape in enumerate(msk_shapes)}
        },
        # slices: dict name -> (start, end)
        # total_dim: int
        'slices': {},
        'total_dim': 0,
    }
    # Build slices
    cursor = 0
    for name in flatten_spec['order']:
        shape = flatten_spec['shapes'][name]
        size = int(np.prod(shape))
        flatten_spec['slices'][name] = (cursor, cursor + size)
        cursor += size
    flatten_spec['total_dim'] = cursor
    # Build Muskingum state naming (flatten index mapping)
    msk_state_index: Dict[str, int] = {}
    msk_state_meta: Dict[str, Dict[str, int]] = {}
    for layer_idx, params in enumerate(msk_layers_params):
        try:
            reach_ids, *_rest, n_sub = params
        except ValueError as exc:
            raise ValueError(
                f"msk_layers_params[{layer_idx}] 结构不符合预期，应为 (idx, c0, c1, c2, n_sub)"
            ) from exc
        reach_ids_arr = np.asarray(reach_ids, dtype=np.int32).ravel()
        n_sub_arr = np.asarray(n_sub, dtype=np.int32).ravel()
        if reach_ids_arr.size != n_sub_arr.size:
            raise ValueError(
                f"msk_layers_params[{layer_idx}] 中 idx 与 n_sub 长度不一致："
                f"{reach_ids_arr.size} vs {n_sub_arr.size}"
            )
        slice_name = f'msk_{layer_idx}'
        start, end = flatten_spec['slices'][slice_name]
        shape = flatten_spec['shapes'][slice_name]
        if len(shape) != 2:
            raise ValueError(
                f"flatten_spec['shapes']['{slice_name}'] 期望二维 (n_reach, max_n)，当前 {shape}"
            )
        n_reach, max_n = shape
        if n_reach != reach_ids_arr.size:
            raise ValueError(
                f"flatten_spec['shapes']['{slice_name}'][0]={n_reach} 与 reach_ids 数量 "
                f"{reach_ids_arr.size} 不一致"
            )
        for local_pos, reach_id in enumerate(reach_ids_arr):
            valid_cols = int(n_sub_arr[local_pos])
            if valid_cols < 1:
                continue
            for seg_idx in range(valid_cols):
                column_offset = local_pos * max_n + seg_idx
                vector_idx = start + column_offset
                name = f"mskL{layer_idx}_reach{int(reach_id)}_seg{seg_idx}"
                msk_state_index[name] = vector_idx
                msk_state_meta[name] = {
                    'layer': int(layer_idx),
                    'reach_position': int(local_pos),
                    'reach_index': int(reach_id),
                    'segment': int(seg_idx),
                }

    state_layout = {
        'name': state_layout_name,
        'n_units': n_units,
        'n_state_unit': n_state_unit,
        'n_layers': len(msk_layers_params),
        'layer_reach_counts': layer_reach_counts,
        'msk_layers_params': msk_layers_params,
        'layer_connect_shapes': [m.shape for m in layer_connect_mats],
        'observation_modes_supported': ['basin_sum', 'last_layer_vector'],
        'default_observation_mode': 'basin_sum',
        'flatten_spec': flatten_spec,
        'dtype': str(init_units_state.dtype),
        'version': 1,
        # 暴露单元状态索引的语义映射，便于上层（优化/同化/可视化）按名称访问
        # 说明：snow_storage = snow_depth + ice_depth（不单独占列）
        'unit_state_index': {
            'snow_depth': 0,
            'ice_depth': 1,
            'last_temp': 2,
            'soil_total': 3,
            'soil_upper': 4,
            'soil_lower': 5,
            'soil_deep': 6,
            'free_water': 7,
            'q_surface': 8,
            'q_interflow': 9,
            'q_baseflow': 10,
        },
        # 容量类"上限曲线"导出名（用于和状态量对齐对比）
        'cap_state_names': {
            'soil_upper_cap': 'wum',
            'soil_lower_cap': 'wlm',
            'soil_deep_cap':  'wdm',
            'soil_total_cap': 'wmm',
            'free_water_cap': 'sm',
        },
        'msk_state_index': msk_state_index,
        'msk_state_meta': msk_state_meta,
    }

    # ----- Helper: broadcast forcings -----
    def _broadcast_forcings(forcings_vec: np.ndarray) -> np.ndarray:
        """Ensure forcings_vec -> shape (4, n_units).
        Accepts shape (4,), (4,1) or (4,n_units)."""
        if forcings_vec.ndim == 1:
            if forcings_vec.size != 4:
                raise ValueError("forcings_vec 1D must have length 4")
            return np.repeat(forcings_vec.reshape(4, 1), n_units, axis=1)
        if forcings_vec.ndim == 2:
            a, b = forcings_vec.shape
            if a != 4:
                raise ValueError("forcings_vec first dim must be 4")
            if b == 1:
                return np.repeat(forcings_vec, n_units, axis=1)
            if b != n_units:
                raise ValueError(f"forcings_vec second dim must be 1 or n_units ({n_units}), got {b}")
            return forcings_vec
        raise ValueError("forcings_vec must be 1D or 2D array")

    def _normalize_liquid_forcings(forcings_dict):
        """Normalize dict-based液态控制输入."""

        def _get(key: str, *aliases: str):
            keys = (key,) + aliases
            for k in keys:
                if k in forcings_dict:
                    return np.asarray(forcings_dict[k], dtype=np.float32)
            raise KeyError(f"液态控制缺少字段: {key}")

        return {
            "mode": str(forcings_dict.get("mode", "liquid_pet")).lower(),
            "liquid": _get("liquid", "liquid_precip", "precip"),
            "pet": _get("pet"),
            "snow_depth": _get("snow_depth"),
            "ice_depth": _get("ice_depth"),
            "last_temp": _get("last_temp"),
        }

    # ----- state_transition_function -----
    def state_transition_function(
        state_struct: Dict[str, Any],
        forcings_vec,
        obs_row: np.ndarray | None = None,
        sta_reach_idx: np.ndarray | None = None,
    ) -> Dict[str, Any]:
        """Advance one time step.

        Parameters
        ----------
        state_struct : dict with 'units' and 'msk'
        forcings_vec : array-like shape (4,), (4,1) or (4,n_units)
            Order: [rain, temp, snow, pet]
        """
        if isinstance(forcings_vec, dict):
            controls = _normalize_liquid_forcings(forcings_vec)
        else:
            f = _broadcast_forcings(np.asarray(forcings_vec))
            rain, temp, snow, pet = f[0], f[1], f[2], f[3]
            controls = np.array([rain, temp, snow, pet], dtype=object)
        # 外接来水覆写：若提供 obs_row 与 sta_reach_idx，则作为单步观测注入
        obs_station_arg = None
        sta_reach_idx_arg = None
        if obs_row is not None and sta_reach_idx is not None:
            obs_row_arr = np.asarray(obs_row, dtype=np.float32).ravel()
            if obs_row_arr.size != sta_reach_idx.size:
                raise ValueError(f"obs_row 长度 {obs_row_arr.size} 与 sta_reach_idx {sta_reach_idx.size} 不一致")
            obs_station_arg = obs_row_arr.reshape(1, -1)  # (1, N_sta)
            sta_reach_idx_arg = np.asarray(sta_reach_idx, dtype=np.int32).ravel()

        next_units, next_msk, _, _ = _state_transition_step(
            state_struct['units'],
            state_struct['msk'],
            controls,
            pdd_pars,
            xaj_pars,
            grid2sub,
            msk_layers_params,
            layer_connect_mats,
            obs_station=obs_station_arg,
            sta_reach_idx=sta_reach_idx_arg,
        )
        return {'units': next_units, 'msk': next_msk}

    # ----- observation_function wrapper (mode) -----
    def observation_function(state_struct: Dict[str, Any], *, mode: str = 'basin_sum'):
        basin_out, outs = _observation_function(state_struct['msk'], msk_layers_params)
        if mode == 'basin_sum':
            return basin_out
        if mode == 'last_layer_vector':
            return outs[-1]
        raise ValueError(f"Unsupported observation mode: {mode}")

    # ----- Placeholder flatten/unflatten (task #23) -----
    def flatten_state(_state_struct):
        spec = state_layout['flatten_spec']
        vec = np.empty(spec['total_dim'], dtype=np.float32)
        # units
        start, end = spec['slices']['units']
        block = _state_struct['units'].astype(np.float32, copy=False).ravel()
        if block.size != (end - start):
            raise ValueError("units block size mismatch during flatten")
        vec[start:end] = block
        # msk layers
        for i in range(len(_state_struct['msk'])):
            name = f'msk_{i}'
            start, end = spec['slices'][name]
            block = _state_struct['msk'][i].astype(np.float32, copy=False).ravel()
            if block.size != (end - start):
                raise ValueError(f"{name} block size mismatch during flatten")
            vec[start:end] = block
        return vec

    def unflatten_state(_vec):
        spec = state_layout['flatten_spec']
        if _vec.ndim != 1:
            raise ValueError("unflatten_state expects 1D vector")
        if _vec.size != spec['total_dim']:
            raise ValueError("vector length mismatch")
        units_start, units_end = spec['slices']['units']
        units = _vec[units_start:units_end].reshape(spec['shapes']['units'])
        msk_list: List[np.ndarray] = []
        for i in range(len(state_layout['layer_reach_counts'])):
            name = f'msk_{i}'
            s, e = spec['slices'][name]
            shape = spec['shapes'][name]
            msk_list.append(_vec[s:e].reshape(shape))
        return {'units': units.copy(), 'msk': [m.copy() for m in msk_list]}

    def project_state_struct(_state_struct):
        """Project a hydrologic state onto its physical storage constraints."""
        projected_units = np.asarray(_state_struct['units'], dtype=float).copy()
        if projected_units.shape != init_units_state.shape:
            raise ValueError(
                f"units shape {projected_units.shape} does not match {init_units_state.shape}"
            )
        wum = np.asarray(xaj_pars[6], dtype=float).reshape(-1)
        wlm = np.asarray(xaj_pars[7], dtype=float).reshape(-1)
        wdm = np.asarray(xaj_pars[8], dtype=float).reshape(-1)
        sm = np.asarray(xaj_pars[9], dtype=float).reshape(-1)
        if not all(values.size in (1, n_units) for values in (wum, wlm, wdm, sm)):
            raise ValueError("Xinanjiang storage-capacity arrays must be scalar or per unit")
        wum = np.broadcast_to(wum, (n_units,))
        wlm = np.broadcast_to(wlm, (n_units,))
        wdm = np.broadcast_to(wdm, (n_units,))
        sm = np.broadcast_to(sm, (n_units,))

        projected_units[:, 0:2] = np.maximum(projected_units[:, 0:2], 0.0)
        projected_units[:, 4] = np.clip(projected_units[:, 4], 0.0, wum)
        projected_units[:, 5] = np.clip(projected_units[:, 5], 0.0, wlm)
        projected_units[:, 6] = np.clip(projected_units[:, 6], 0.0, wdm)
        projected_units[:, 3] = projected_units[:, 4:7].sum(axis=1)
        projected_units[:, 7] = np.clip(projected_units[:, 7], 0.0, sm)
        projected_units[:, 8:11] = np.maximum(projected_units[:, 8:11], 0.0)
        projected_msk = [
            np.maximum(np.asarray(layer, dtype=float), 0.0)
            for layer in _state_struct['msk']
        ]
        return {'units': projected_units, 'msk': projected_msk}

    def project_flat_state(_vec):
        projected = project_state_struct(unflatten_state(np.asarray(_vec)))
        return flatten_state(projected).astype(np.asarray(_vec).dtype, copy=False)

    return {
        'state_transition_function': state_transition_function,
        'observation_function': observation_function,
        'init_state_struct': init_state_struct,
        'state_layout': state_layout,
        'flatten_state': flatten_state,
        'unflatten_state': unflatten_state,
        'project_state_struct': project_state_struct,
        'project_flat_state': project_flat_state,
    }










