"""param_utils.py

参数更新工具函数
从 experiments.parameter_optimization.sim_with_enable_option 迁移而来
"""
from __future__ import annotations
from copy import deepcopy
from typing import Dict, Any
import numpy as np


def update_model_params(
    template_params: Dict[str, Any],
    new_params_sparse: Dict[str, Any],
    calibration_config: Dict[str, Any]
) -> Dict[str, Any]:
    """
    使用稀疏参数字典更新模型参数模板。
    
    从 experiments.parameter_optimization.sim_with_enable_option 迁移而来。
    支持处理 msk_layers 的特殊更新逻辑（list of dicts 的按元素掩码合并）。
    
    参数:
        template_params: 参数模板字典
        new_params_sparse: 待更新的稀疏参数字典
        calibration_config: 校准配置字典（当前未使用，保留以保持接口兼容性）
    
    返回:
        更新后的参数模板
    """
    new_template = deepcopy(template_params)

    # msk_layers is a list of dicts — extract separately without mutating input.
    # BUG FIX: .pop() was mutating the caller's param_dict, causing the second
    # call to run_simulation() to lose msk_layers (355 m³/s discrepancy).
    msk_layers_update = new_params_sparse.get("msk_layers", None)

    # Iterate only dict-like groups, skipping msk_layers
    for group_name, group_dict in new_params_sparse.items():
        if group_name == "msk_layers":
            continue
        if group_name not in new_template:
            new_template[group_name] = {}

        # BUG 修复：确保 group_dict 是字典
        if not isinstance(group_dict, dict):
            # 根据之前的分析，这里不应该再出现 list 了。
            # 但为保险起见，如果不是字典就跳过。
            continue

        for param_name, param_values in group_dict.items():
            if isinstance(param_values, np.ndarray):
                new_template[group_name][param_name] = param_values
            else:
                new_template[group_name][param_name] = param_values

    # 如果弹出了 msk_layers_update，在这里执行它的更新逻辑（按元素掩码合并）
    if msk_layers_update and "msk_layers" in new_template:
        
        # Handle wildcard broadcast or dict-based update
        if isinstance(msk_layers_update, dict):
            if '*' in msk_layers_update:
                # Broadcast to all layers
                wildcard_val = msk_layers_update['*']
                n_layers = len(new_template["msk_layers"])
                msk_layers_update = [wildcard_val] * n_layers

        for li, update_dict in enumerate(msk_layers_update):
            if li >= len(new_template["msk_layers"]) or not isinstance(update_dict, dict):
                continue
            base_layer = new_template["msk_layers"][li]
            for key, upd_val in update_dict.items():
                # 若基础层没有该字段，直接赋值（首次创建的完整数组）
                if key not in base_layer:
                    base_layer[key] = upd_val
                    continue
                base_val = base_layer[key]
                # 仅针对 ndarray 做按位合并；否则直接覆盖
                # 基础值为 ndarray：执行更细致的合并/广播
                if isinstance(base_val, np.ndarray):
                    # 目标长度优先从 index 推断，其次从 base/upd 推断
                    def _infer_target_len() -> int:
                        if isinstance(base_layer.get("index"), np.ndarray) and base_layer["index"].ndim == 1:
                            return int(base_layer["index"].shape[0])
                        if isinstance(base_val, np.ndarray) and base_val.ndim > 0:
                            return int(base_val.shape[0])
                        if isinstance(upd_val, np.ndarray) and upd_val.ndim > 0:
                            return int(upd_val.shape[0])
                        return 1

                    if base_val.ndim == 0:
                        # 将 0 维标量参数广播为 1D 数组，避免 shape[0] 异常
                        tgt = _infer_target_len()
                        fill = int(base_val) if base_val.dtype.kind in ("i", "u") else float(base_val)
                        merged = np.full(tgt, fill, dtype=base_val.dtype)
                    else:
                        merged = base_val.copy()
                    target_len = int(merged.shape[0]) if merged.ndim > 0 else 1
                    # 情况 A：更新值是 ndarray
                    if isinstance(upd_val, np.ndarray):
                        if upd_val.ndim == 0:
                            # 0 维数组（标量）→ 全量广播覆盖
                            if merged.dtype.kind in ("i", "u"):
                                merged[:] = int(upd_val)
                            else:
                                merged[:] = float(upd_val)
                        else:
                            n = min(target_len, int(upd_val.shape[0]))
                            if upd_val.dtype.kind in ("f", "c"):  # 浮点：c0/c1
                                mask = np.isfinite(upd_val[:n])
                                merged[:n][mask] = upd_val[:n][mask]
                            elif upd_val.dtype.kind in ("i", "u"):  # 整型：n_sub；>=1 生效
                                mask = upd_val[:n] >= 1
                                merged[:n][mask] = upd_val[:n][mask]
                            else:
                                merged[:n] = upd_val[:n]
                    else:
                        # 情况 B：更新值为 Python 标量或 list-like
                        if np.isscalar(upd_val):
                            if merged.dtype.kind in ("i", "u"):
                                merged[:] = int(upd_val)
                            else:
                                merged[:] = float(upd_val)
                        else:
                            arr = np.asarray(upd_val)
                            if arr.ndim == 0:
                                if merged.dtype.kind in ("i", "u"):
                                    merged[:] = int(arr)
                                else:
                                    merged[:] = float(arr)
                            else:
                                n = min(target_len, int(arr.shape[0]))
                                merged[:n] = arr[:n]
                    base_layer[key] = merged
                else:
                    # 基础值非 ndarray，直接覆盖即可
                    base_layer[key] = upd_val

    return new_template


