from __future__ import annotations
from typing import Tuple, Dict, Any
import numpy as np
import pandas as pd
from pathlib import Path
import hashlib
import os
from datetime import datetime

from src.runtime.semi_distributed.core.optimization_config import OptimizationConfig
from src.runtime.semi_distributed.core.dataio import load_data, prepare_meteo_inputs, prepare_external_flow_inputs
from src.runtime.semi_distributed.core.topology import build_msk_layers_and_connect_mat
from src.runtime.semi_distributed.core.params import setup_model_and_config, prepare_model_params
from src.runtime.semi_distributed.core.optimize import optimize_parameters_distributed
from src.runtime.semi_distributed.core.saveout import save_results
from src.runtime.semi_distributed.core.visualize_topology import (
    plot_connection_matrix, plot_msk_layers_summary,
)
from src.runtime.semi_distributed.core.optimize_eval import optimize_parameters_distributed_eval  # type: ignore
from src.runtime.semi_distributed.core.validation import (
    collect_context, run_validations, write_validation_report, prune_calibration,
)
from src.runtime.semi_distributed.core.broadcast_api import make_fixed_broadcaster  # 新增
from src.runtime.semi_distributed.core.fixed_broadcast_io import load_fixed_broadcast  # 新增
from src.runtime.semi_distributed.core.fixed_broadcast_io import save_fixed_broadcast  # 新增导入
import json as _json
from src.runtime.semi_distributed.core.dataio import aggregate_meteo_by_sub
from src.kernels.semi_distributed.core.simulate_flood_distributed_fast import _simulate_core, prepare_initial_conditions


def validate_grid2sub(grid2sub: np.ndarray) -> None:
    """Validate grid-to-subbasin transfer matrix."""
    if grid2sub.ndim != 2 or grid2sub.shape[0] == 0 or grid2sub.shape[1] == 0:
        raise ValueError(f"Invalid grid2sub shape: {grid2sub.shape}")
    if np.any(grid2sub < -1e-6) or np.any(grid2sub > 1 + 1e-6):
        raise ValueError(
            f"grid2sub values outside [0, 1]: "
            f"min={grid2sub.min():.6f}, max={grid2sub.max():.6f}"
        )
    row_sums = grid2sub.sum(axis=1)
    if not np.allclose(row_sums, 1.0, atol=0.01):
        raise ValueError(
            f"grid2sub rows must sum to 1.0, "
            f"got min={row_sums.min():.4f} max={row_sums.max():.4f}"
        )


def pre_validation_phase(cfg, msk_layers, connection_matrices, calib_cfg, eval_station, override_stations, tag: str = ''):
    """执行 Phase6/7: 校验 + 可选裁剪。返回 (calib_cfg, aborted:boolean).
    tag: '' 或 '(eval)' 用于区分打印前缀。
    """
    ctx = collect_context(cfg, msk_layers, connection_matrices, calib_cfg, eval_station, override_stations)
    issues = run_validations(ctx)
    write_validation_report(cfg, issues)
    n_err = sum(1 for i in issues if i.level == 'ERROR')
    n_warn = sum(1 for i in issues if i.level == 'WARN')
    if n_warn or n_err:
        print(f"[VALIDATION]{' ' + tag if tag else ''} ERROR={n_err} WARN={n_warn}")
    if n_err > 0:
        print(f"[VALIDATION]{' ' + tag if tag else ''} 存在 ERROR, 终止优化并返回空结果。")
        return calib_cfg, True
    changed, pr_report = prune_calibration(ctx, calib_cfg)
    if changed:
        if os.environ.get('STRICT_NO_PRUNE','0') == '1':
            raise RuntimeError('[STRICT] 检测到将被裁剪的参数, 严格模式禁止自动裁剪: 请移除无关 layer_node 参数后重试')
        if os.environ.get('NO_PRUNE','0') != '1':
            print(f"[PRUNE]{' ' + tag if tag else ''} 移除 {pr_report['removed_count']} 条 layer_node 率定参数 -> 剩余 {pr_report['remaining']}")
    return calib_cfg, False


def scatter_coverage(cfg, grid2sub, sub_names, meta, Ng, basin_dir: Path):
    """覆盖散点诊断: 对 calib_nodes(names:...) 中每个子流域绘制覆盖散点。

    规则:
      - 仅在 cfg.DIAG_SCATTER(True) 或 旧字段 DIAG_QL_SCATTER(True, 兼容) 且 calib_selector 为 names: 列表 时执行。
      - 若 names 数量 > 8 跳过以免过多图; 可按需调整。
      - 每个子流域输出一张: 覆盖(红) vs 其它(灰)。
    """
    if not (getattr(cfg, 'DIAG_SCATTER', False) or getattr(cfg, 'DIAG_QL_SCATTER', False)):
        return
    calib_selector = getattr(cfg, 'CALIB_NODE_SELECTOR', None)
    if not (isinstance(calib_selector, dict) and isinstance(calib_selector.get('names'), list)):
        return
    target_names = calib_selector['names']
    if not target_names:
        return
    if len(target_names) > 8:
        print(f"[WARN] SCATTER_COVERAGE 目标数量 {len(target_names)} > 8, 为避免生成过多图已跳过。可改小 calib_nodes 或调阈值。")
        return
    # 坐标准备 (一次读取)
    lons = lats = None
    if isinstance(meta, dict) and 'grid_lon' in meta and 'grid_lat' in meta:
        try:
            lons = np.asarray(meta['grid_lon'], dtype=float)
            lats = np.asarray(meta['grid_lat'], dtype=float)
        except Exception:
            lons = lats = None
    if (lons is None or lats is None) and (basin_dir / 'source_csv' / 'grid_sub.csv').exists():
        try:
            df_gs = pd.read_csv(basin_dir / 'source_csv' / 'grid_sub.csv')
            if df_gs.shape[0] >= Ng and df_gs.shape[1] >= 4:
                lons = df_gs.iloc[:Ng, -2].to_numpy(dtype=float)
                lats = df_gs.iloc[:Ng, -1].to_numpy(dtype=float)
        except Exception as e:
            print(f"[WARN] 读取 grid_sub.csv 失败: {e}")
    # 若无坐标，仅输出统计
    coord_ready = not (lons is None or lats is None or lons.size != Ng or lats.size != Ng)
    try:
        try:
            import matplotlib  # type: ignore
            import matplotlib.pyplot as plt  # type: ignore
        except Exception:
            if coord_ready:
                print('[WARN] 未安装 matplotlib, 跳过覆盖散点绘制。')
            coord_ready = False
        # 字体一次性
        if coord_ready and not matplotlib.rcParams.get('_cjk_font_patched', False):
            try:
                from matplotlib import font_manager
                preferred = [
                    'Microsoft YaHei','SimHei','Microsoft JhengHei','STHeiti','Songti SC',
                    'Noto Sans CJK SC','Noto Sans CJK','WenQuanYi Micro Hei','Arial Unicode MS'
                ]
                available = {f.name for f in font_manager.fontManager.ttflist}
                for name in preferred:
                    if name in available:
                        matplotlib.rcParams['font.sans-serif'] = [name] + matplotlib.rcParams.get('font.sans-serif', [])
                        matplotlib.rcParams['axes.unicode_minus'] = False
                        print(f"[DIAG] 已设置中文字体: {name}")
                        break
                matplotlib.rcParams['_cjk_font_patched'] = True
            except Exception as fe:
                print(f"[WARN] 自动设置中文字体失败: {fe}")
        out_dir = Path('experiments') / 'figures' / 'diagnose'
        if coord_ready:
            out_dir.mkdir(parents=True, exist_ok=True)
        for nm in target_names:
            if nm not in sub_names:
                print(f"[WARN] SCATTER_COVERAGE: sub_names 不含 {nm}, 跳过该节点绘图。")
                continue
            col = sub_names.index(nm)
            mask = (grid2sub[:, col] > 0.5)
            sel = np.where(mask)[0]
            ratio = sel.size / Ng if Ng else 0
            if not coord_ready:
                print(f"[DIAG] {nm} col={col} cells={sel.size}/{Ng} ({ratio:.2%}) (无坐标, 仅文本统计)")
                continue
            fig, ax = plt.subplots(figsize=(5,5))
            ax.scatter(lons[~mask], lats[~mask], s=6, c='#cccccc', alpha=0.35, label='other')
            ax.scatter(lons[mask], lats[mask], s=10, alpha=0.85, label=nm)
            ax.set_title(f"{nm} 覆盖 {sel.size}/{Ng} ({ratio:.1%})")
            ax.legend(frameon=False, fontsize=8)
            fig.tight_layout()
            out_path = out_dir / f'optimize_params_hydromod_{nm}_grid_scatter.png'
            fig.savefig(out_path, dpi=150)
            plt.close(fig)
            print(f"[DIAG] {nm} 覆盖散点输出: {out_path}")
    except Exception as e:
        print(f"[WARN] SCATTER_COVERAGE 绘图失败: {e}")


def select_floods_series(cfg: OptimizationConfig, discharge_outlet, discharge_inflow, eval_station: str | None, msk_layers) -> tuple[Any, bool]:
    """根据配置选择目标函数使用的流量时间序列.
    返回 (series, abort_flag). abort_flag=True 表示应终止。
    规则:
      1) 若 FLOW_SOURCE_STATION 指定且不为 'from_anchor':
           - 'outlet' 或 'outlet_series' => 使用出口流量
           - 其它 => 在 discharge_inflow 中查找对应列
           - 下游评价站禁止使用上游站; 上游评价站使用下游流量仅打印提示;
      2) 否则('from_anchor' 或 未指定): 若有评价锚点自身列 => 用自身; 否则回退出口; 若都无 => 错误。
    """
    last_layer_names = []
    if msk_layers and isinstance(msk_layers[-1], dict):
        last_layer_names = list(msk_layers[-1].get('names') or [])
    flow_source_cfg = getattr(cfg, 'FLOW_SOURCE_STATION', None)

    def _col_exists(name: str):
        return (discharge_inflow is not None and name in discharge_inflow.columns)

    def _get_col(name: str):
        return discharge_inflow[name] if _col_exists(name) else None

    # 1) 显式指定（排除 'from_anchor' 语义占位符）
    if isinstance(flow_source_cfg, str) and flow_source_cfg.strip() and flow_source_cfg.strip().lower() not in ('from_anchor',):
        if flow_source_cfg in ('outlet','outlet_series'):
            if discharge_outlet is None:
                print(f"[ERROR] 指定 flow_source={flow_source_cfg} 但无出口流量")
                return None, True
            return discharge_outlet, False
        # 新增：若 flow_source_cfg 是下游评价站，也应使用出口流量
        if eval_station and eval_station in last_layer_names and flow_source_cfg == eval_station:
            if discharge_outlet is None:
                print(f"[ERROR] 指定 flow_source={flow_source_cfg} (下游站), 但无出口流量")
                return None, True
            print(f"[FLOW] flow_source={flow_source_cfg} 为下游站, 使用出口流量作为目标")
            return discharge_outlet, False
        series = _get_col(flow_source_cfg)
        if series is None:
            print(f"[ERROR] flow_source={flow_source_cfg} 不存在于观测流量列中")
            return None, True
        if eval_station in last_layer_names and flow_source_cfg not in last_layer_names:
            print(f"[ERROR] 下游评价站 {eval_station} 不允许使用上游站 {flow_source_cfg} 作为目标流量")
            return None, True
        if eval_station and eval_station not in last_layer_names and flow_source_cfg in last_layer_names:
            print(f"[FLOW] 上游评价站 {eval_station} 使用下游站 {flow_source_cfg} 作为目标 (包含聚合信息)")
        return series, False

    # 2) 未显式指定或为 from_anchor：若有自身站
    if eval_station and _col_exists(eval_station):
        return _get_col(eval_station), False

    # 3) 回退出口
    if discharge_outlet is not None:
        # 严格无回退：禁止因评价站无自身观测而回退出口
        if os.environ.get('STRICT_NO_FALLBACK','0') == '1':
            print(f"[ERROR] STRICT_NO_FALLBACK: 评价站 {eval_station} 无自身观测列，且禁止回退出口。请显式设置 objective_flow 或提供该列。")
            return None, True
        if eval_station and eval_station not in last_layer_names:
            print(f"[FLOW] 上游评价站 {eval_station} 无自身观测, 回退使用出口流量")
        return discharge_outlet, False
    print('[ERROR] 无可用目标流量 (未找到评价站自身列且无出口)')
    return None, True


def prepare_calibration_session(cfg: OptimizationConfig):
    """抽取出的准备函数: 读取矩阵/元数据/气象/拓扑/初始参数, 返回 dict."""
    prefix = cfg.MATRIX_PREFIX
    basin_dir = cfg.BASIN_DIR
    std_dir = basin_dir / prefix
    g2s_path_csv = std_dir / 'grid_to_subbasin_map.csv'
    sarea_path_csv = std_dir / 'sub_area.csv'
    if getattr(cfg, "DEBUG_MATRIX_PATHS", False):
        print(f"[DEBUG] 期望标准目录: {std_dir}")
    if not g2s_path_csv.exists() or not sarea_path_csv.exists():
        raise FileNotFoundError(f"缺少标准矩阵: {g2s_path_csv} / {sarea_path_csv}")
    grid2sub = pd.read_csv(g2s_path_csv).to_numpy(dtype=np.float32)
    validate_grid2sub(grid2sub)
    sub_area_df = pd.read_csv(sarea_path_csv)
    sub_area = sub_area_df[sub_area_df.columns[0]].to_numpy(dtype=np.float32)
    Ng, Ns = grid2sub.shape
    if getattr(cfg, "DEBUG_MATRIX_PATHS", False):
        print(f"[DEBUG] grid2sub shape={grid2sub.shape} sub_area_len={sub_area.shape}")
    # meta
    meta = None
    sub_names: list[str] = []
    meta_path = g2s_path_csv.parent / 'meta.json'
    if meta_path.exists():
        try:
            with open(meta_path, 'r', encoding='utf-8') as fp:
                meta = _json.load(fp)
            if isinstance(meta, dict) and 'sub_names' in meta:
                sub_names = list(meta.get('sub_names') or [])
        except Exception as e:
            print(f"[WARN] 读取 meta.json 失败: {e}")
    # 数据
    meteo, discharge_outlet, discharge_inflow = load_data(cfg)
    rain, temp, snow, pet, time_index = prepare_meteo_inputs(
        meteo,
        Ng,
        t_snow=getattr(cfg, 'T_SNOW', None),
        t_rain=getattr(cfg, 'T_RAIN', None),
        precip_mode=getattr(cfg, 'PRECIP_MODE', None),
        rain_cols=getattr(cfg, 'RAIN_COLUMNS', None),
        snow_cols=getattr(cfg, 'SNOW_COLUMNS', None),
        total_precip_col=getattr(cfg, 'TOTAL_PRECIP_COL', None),
    )

    # 严格：SIM_UNIT 必须显式为 'grid' 或 'subbasin'
    sim_unit = getattr(cfg, 'SIM_UNIT', None)
    if sim_unit not in ('grid', 'subbasin'):
        raise ValueError("[STRICT] SIM_UNIT 未设置或非法。请在 run_config.yml 中显式设置 sim_unit: 'grid' 或 'subbasin'.")
    if sim_unit == 'subbasin':
        rain, temp, snow, pet = aggregate_meteo_by_sub(rain, temp, snow, pet, grid2sub)
        grid2sub = np.eye(Ns, dtype=np.float32)
        Ng = Ns
        if getattr(cfg, 'MATRIX_SUMMARY', False):
            print('[INFO] SIM_UNIT=subbasin: 已将气象聚合到子流域尺度，并使用单位 grid2sub。')

    # 拓扑
    msk_layers, connection_matrices = build_msk_layers_and_connect_mat(cfg)
    default_params, calib_cfg, init_cond = setup_model_and_config(cfg, Ns, msk_layers, Ng)
    # 覆盖面积 & uf 使用 sub_area.csv 真实值 (严格模式: 成功静默, 失败抛错)
    if 'basin_params' not in default_params:
        default_params['basin_params'] = {}
    default_params['basin_params']['area'] = [float(x) for x in sub_area.tolist()]
    if 'xaj_params' not in default_params:
        default_params['xaj_params'] = {}
    # 动态时间步换算: uf = area / (3.6 * dt_hours)，需与配置 dt_hours 保持一致
    import pandas as _pd  # 已在顶部导入, 此处仅确保可用
    cfg_dt_hours = getattr(cfg, 'DT_HOURS', None)
    if cfg_dt_hours is None:
        raise ValueError('[STRICT] 优化配置缺少 DT_HOURS；请在 run_config.yml 的 time 段落显式设置 dt_hours。')
    try:
        cfg_dt_hours = float(cfg_dt_hours)
    except (ValueError, TypeError):
        raise ValueError(f'[STRICT] 非法的 dt_hours 值: {cfg_dt_hours!r}')
    if cfg_dt_hours <= 0:
        raise ValueError('[STRICT] dt_hours 必须为正数。')

    # 估算时间步长(小时): 使用中位数以增强稳健性
    dt_sec = None
    if time_index is not None:
        try:
            dt_sec = float(_pd.Series(time_index).diff().dt.total_seconds().median())
        except Exception:
            dt_sec = None
    if dt_sec is None or not np.isfinite(dt_sec) or dt_sec <= 0:
        raise ValueError('[STRICT] 无法从 time_index 推断时间步长；请确保时间索引等间隔且有效。')
    dt_hours_data = max(dt_sec / 3600.0, 1e-6)
    
    # Debug info for time step mismatch
    if abs(dt_hours_data - cfg_dt_hours) > max(1e-6, 0.05 * cfg_dt_hours):
        try:
            print(f"[DEBUG] Time Index Head: {time_index[:5]}")
            print(f"[DEBUG] Time Index Diff Head: {pd.Series(time_index).diff().head()}")
            print(f"[DEBUG] Time Index Diff Value Counts: {pd.Series(time_index).diff().dt.total_seconds().value_counts().head()}")
        except Exception as e:
            print(f"[DEBUG] Failed to print time index info: {e}")

    tol = max(1e-6, 0.05 * cfg_dt_hours)
    if abs(dt_hours_data - cfg_dt_hours) > tol:
        raise ValueError(
            f'[STRICT] 配置的 dt_hours={cfg_dt_hours} 与数据推断的 dt_hours={dt_hours_data:.6f} 不一致，'
            '请检查 time.dt_hours 设置与气象时间索引是否匹配。'
        )

    uf_arr = (sub_area / (3.6 * cfg_dt_hours)).astype(np.float32)
    default_params['xaj_params']['uf'] = [float(x) for x in uf_arr.tolist()]
    try:
        print(f"[UF] sub_area={float(sub_area.sum()):.2f}km2, dt={cfg_dt_hours}h, uf={float(uf_arr.mean()):.2f}")
    except Exception:
        pass
    if len(default_params['basin_params']['area']) != Ns or len(default_params['xaj_params']['uf']) != Ns:
        raise ValueError('[STRICT] sub_area 覆盖后 area/uf 长度与 Ns 不一致')

    # 新增：按名称过滤 sub 级率定参数（spec.sub_names）
    try:
        if isinstance(calib_cfg, dict) and 'index_map' in calib_cfg and isinstance(sub_names, list) and sub_names:
            name_to_id = {n: i for i, n in enumerate(sub_names)}
            kept = []
            removed = 0
            for spec, idx in calib_cfg['index_map']:
                if not isinstance(spec, dict):
                    kept.append((spec, idx)); continue
                if spec.get('level','basin') != 'sub':
                    kept.append((spec, idx)); continue
                target_names = spec.get('sub_names')
                if not target_names:
                    kept.append((spec, idx)); continue
                # 若提供 sub_names, 仅保留这些名字对应的索引
                valid_ids = {name_to_id[nm] for nm in target_names if nm in name_to_id}
                if idx in valid_ids:
                    kept.append((spec, idx))
                else:
                    removed += 1
            if removed:
                calib_cfg['index_map'] = kept
                calib_cfg['vector_size'] = len(kept)
                print(f"[CALMAP] sub_names 过滤: 移除 {removed} 项 → 保留 {len(kept)}")
    except Exception as fe:
        print(f"[WARN] sub_names 过滤失败: {fe}")

    return {
        'grid2sub': grid2sub,
        'sub_area': sub_area,
        'Ng': Ng,
        'Ns': Ns,
        'meta': meta,
        'sub_names': sub_names,
        'meteo_inputs': (rain, temp, snow, pet),
        'time_index': time_index,
        'discharge_outlet': discharge_outlet,
        'discharge_inflow': discharge_inflow,
        'msk_layers': msk_layers,
        'connection_matrices': connection_matrices,
        'default_params': default_params,
        'calib_cfg': calib_cfg,
        'init_cond': init_cond,
        'basin_dir': basin_dir,
    }


def run_optimization_eval(cfg: 'OptimizationConfig') -> Tuple[Dict[str, Any], float]:
    """统一的优化/评价入口。
    - cfg.EVAL_STATION 为空: 使用出口(outlet)流量作为目标函数 (旧 full)
    - cfg.EVAL_STATION 有值: 单站/上游节点优化 (旧 eval)
    返回 (best_params, best_score)
    若前置校验失败或无可用流量返回 ({} , nan)
    """
    prefix = cfg.MATRIX_PREFIX
    basin_dir = cfg.BASIN_DIR
    std_dir = basin_dir / prefix
    g2s_path_csv = std_dir / 'grid_to_subbasin_map.csv'
    sarea_path_csv = std_dir / 'sub_area.csv'
    if not g2s_path_csv.exists() or not sarea_path_csv.exists():
        raise FileNotFoundError('缺少标准矩阵文件 (grid_to_subbasin_map.csv / sub_area.csv)')

    grid2sub = pd.read_csv(g2s_path_csv).to_numpy(dtype=np.float32)
    validate_grid2sub(grid2sub)
    sub_area_df = pd.read_csv(sarea_path_csv)
    sub_area = sub_area_df[sub_area_df.columns[0]].to_numpy(dtype=np.float32)
    Ng, Ns = grid2sub.shape

    # meta (可选)
    sub_names: list[str] = []
    meta_path = g2s_path_csv.parent / 'meta.json'
    if meta_path.exists():
        try:
            import json as _json
            with open(meta_path, 'r', encoding='utf-8') as fp:
                meta_eval = _json.load(fp)
            if isinstance(meta_eval, dict) and 'sub_names' in meta_eval:
                sub_names = list(meta_eval.get('sub_names') or [])
        except Exception:
            pass

    # 读取数据
    from src.runtime.semi_distributed.core.dataio import load_data, prepare_meteo_inputs, prepare_external_flow_inputs
    from src.runtime.semi_distributed.core.topology import build_msk_layers_and_connect_mat
    from src.runtime.semi_distributed.core.params import setup_model_and_config, prepare_model_params
    from src.runtime.semi_distributed.core.optimize_eval import optimize_parameters_distributed_eval  # type: ignore
    from src.runtime.semi_distributed.core.validation import (
        collect_context, run_validations, write_validation_report, prune_calibration,
    )
    from src.runtime.semi_distributed.core.saveout import save_results

    meteo, discharge_outlet, discharge_inflow = load_data(cfg)
    eval_station = getattr(cfg, 'EVAL_STATION', None)
    rain, temp, snow, pet, time_index = prepare_meteo_inputs(
        meteo,
        Ng,
        t_snow=getattr(cfg, 'T_SNOW', None),
        t_rain=getattr(cfg, 'T_RAIN', None),
        precip_mode=getattr(cfg, 'PRECIP_MODE', None),
        rain_cols=getattr(cfg, 'RAIN_COLUMNS', None),
        snow_cols=getattr(cfg, 'SNOW_COLUMNS', None),
        total_precip_col=getattr(cfg, 'TOTAL_PRECIP_COL', None),
    )

    # 严格：SIM_UNIT 必须显式为 'grid' 或 'subbasin'
    sim_unit = getattr(cfg, 'SIM_UNIT', None)
    if sim_unit not in ('grid', 'subbasin'):
        raise ValueError("[STRICT] SIM_UNIT 未设置或非法。请在 run_config.yml 中显式设置 sim_unit: 'grid' 或 'subbasin'.")
    if sim_unit == 'subbasin':
        rain, temp, snow, pet = aggregate_meteo_by_sub(rain, temp, snow, pet, grid2sub)
        grid2sub = np.eye(Ns, dtype=np.float32)
        Ng = Ns
        print('[INFO] SIM_UNIT=subbasin: 使用子流域平均强制量 + 单位 grid2sub 进行模拟。')

    msk_layers, connection_matrices = build_msk_layers_and_connect_mat(cfg)
    last_names = []
    if msk_layers and isinstance(msk_layers[-1], dict):
        last_names = list(msk_layers[-1].get('names', []))
    eval_is_last_layer_node = bool(eval_station and eval_station in last_names)

    default_params, calib_cfg, init_cond = setup_model_and_config(cfg, Ns, msk_layers, Ng)
    # 覆盖面积 & uf 使用 sub_area.csv 真实值 (严格模式: 成功静默, 失败抛错)
    if 'basin_params' not in default_params:
        default_params['basin_params'] = {}
    default_params['basin_params']['area'] = [float(x) for x in sub_area.tolist()]
    if 'xaj_params' not in default_params:
        default_params['xaj_params'] = {}
    # 动态时间步换算: uf = area / (3.6 * dt_hours)（严格：必须可由 time_index 推断，禁止回退）
    import pandas as _pd  # 已在顶部导入, 此处仅确保可用
    dt_sec = None
    try:
        dt_sec = float(_pd.Series(time_index).diff().dt.total_seconds().median())
    except Exception:
        dt_sec = None
    if dt_sec is None or not np.isfinite(dt_sec) or dt_sec <= 0:
        raise ValueError('[STRICT] 无法从 time_index 推断时间步长(eval)；请确保时间索引等间隔且有效。')
    dt_hours = max(dt_sec / 3600.0, 1e-6)
    uf_arr = (sub_area / (3.6 * dt_hours)).astype(np.float32)
    default_params['xaj_params']['uf'] = [float(x) for x in uf_arr.tolist()]
    try:
        print(f"[UF] 覆盖 uf 按时间步(eval): dt_hours={dt_hours:.3f}, uf_min={float(uf_arr.min()):.4g}, uf_max={float(uf_arr.max()):.4g}")
    except Exception:
        pass
    if len(default_params['basin_params']['area']) != Ns or len(default_params['xaj_params']['uf']) != Ns:
        raise ValueError('[STRICT] sub_area 覆盖后 area/uf 长度与 Ns 不一致')

    # 新增：按名称过滤 sub 级率定参数（spec.sub_names）
    try:
        if isinstance(calib_cfg, dict) and 'index_map' in calib_cfg and isinstance(sub_names, list) and sub_names:
            name_to_id = {n: i for i, n in enumerate(sub_names)}
            kept = []
            removed = 0
            for spec, idx in calib_cfg['index_map']:
                if not isinstance(spec, dict):
                    kept.append((spec, idx)); continue
                if spec.get('level','basin') != 'sub':
                    kept.append((spec, idx)); continue
                target_names = spec.get('sub_names')
                if not target_names:
                    kept.append((spec, idx)); continue
                # 若提供 sub_names, 仅保留这些名字对应的索引
                valid_ids = {name_to_id[nm] for nm in target_names if nm in name_to_id}
                if idx in valid_ids:
                    kept.append((spec, idx))
                else:
                    removed += 1
            if removed:
                calib_cfg['index_map'] = kept
                calib_cfg['vector_size'] = len(kept)
                print(f"[CALMAP] sub_names 过滤: 移除 {removed} 项 → 保留 {len(kept)}")
    except Exception as fe:
        print(f"[WARN] sub_names 过滤失败: {fe}")

    # ==== 预检查：仅参数广播 + 短模拟 (不进入优化) ====
    if os.environ.get('PRECHECK_PARAMS_ONLY', '0') == '1':
        print('[PRECHECK] 启动参数广播与短模拟预检查 (不执行优化)。')
        try:
            # from src.runtime.semi_distributed.core.params import prepare_model_params
            # from src.kernels.semi_distributed.core.simulate_flood_distributed_fast import prepare_initial_conditions, _simulate_core
            merged_model, pdd_tuple, xaj_tuple, msk_layers_params_tuples, core_args = prepare_model_params(
                param_dict=None,
                model_params_template=default_params,
                calibration_config=calib_cfg,
                grid2sub=grid2sub,
                sub_area=sub_area,
                connection_matrices=connection_matrices,
                param_mode={
                    'msk_params': {'*': 'sub'},
                    'xaj_params': {'*': 'basin'},
                    'pdd_params': {'*': 'basin'},
                },
            )
            print(f"[PRECHECK] pdd_tuple_len={len(pdd_tuple)} (v1=4/v2=6/v3=5) xaj_tuple_len={len(xaj_tuple)} (期望17) msk_layers={len(msk_layers_params_tuples)}")
            print(f"[PRECHECK] grid2sub shape={grid2sub.shape} sub_area shape={sub_area.shape}")
            # 初始状态
            init_state_arr = prepare_initial_conditions(init_cond, Ng, enable_snowmelt=False)
            print(f"[PRECHECK] init_state shape={init_state_arr.shape}")
            # 取前 T_preview 步模拟
            T_preview = min(5, rain.shape[0])
            sim_ret = _simulate_core(
                rain[:T_preview], temp[:T_preview], snow[:T_preview], pet[:T_preview],
                pdd_tuple, xaj_tuple,
                grid2sub.astype(np.float32),
                init_state_arr,
                return_last_layer=True,
                **core_args,
            )
            if len(sim_ret) == 4:
                q_grid, q_subs, q_outlet, q_last_layer = sim_ret
            else:
                q_grid, q_subs, q_outlet = sim_ret[:3]
                q_last_layer = None
            print(f"[PRECHECK] q_grid shape={q_grid.shape} q_subs shape={q_subs.shape} q_outlet shape={q_outlet.shape} last_layer={'None' if q_last_layer is None else q_last_layer.shape}")
            dump_path = os.environ.get('DUMP_BROADCAST_FILE') or os.environ.get('FIXED_BROADCAST_FILE')
            if dump_path:
                save_fixed_broadcast(
                    dump_path,
                    pdd_tuple=pdd_tuple,
                    xaj_tuple=xaj_tuple,
                    msk_layers_params=msk_layers_params_tuples,
                    C_mats=core_args.get('C_mats', []),
                    merged_model=merged_model,
                )
                print(f"[PRECHECK] 已保存广播结果到 {dump_path}")
            print('[PRECHECK] 成功：参数广播与短模拟无异常。设置 PRECHECK_PARAMS_ONLY=0 后再运行优化。')
        except Exception as e:
            import traceback
            print(f"[PRECHECK][ERROR] 预检查失败: {e}")
            traceback.print_exc()
        return default_params, float('nan')
    # ==== 预检查结束 ====

    # 外部观测站点映射 (示例映射逻辑，可保持旧行为)
    station_reach_map = {"zmsk": 0, "ql": 1} if cfg.SECTION_NAME == "ylx" else None
    override_stations = getattr(cfg, "OVERRIDE_STATIONS", None)
    obs_station_arr, sta_reach_idx = prepare_external_flow_inputs(
        observed_station_flow=discharge_inflow,
        station_reach_map=station_reach_map,
        time_index=time_index,
        override_stations=override_stations,
    )

    floods_target, abort_flow = select_floods_series(cfg, discharge_outlet, discharge_inflow, eval_station, msk_layers)
    if abort_flow:
        return {}, float('nan')

    # Spinup: trim evaluation target to eval_start_date (simulation still runs from start_date)
    _eval_start = getattr(cfg, 'EVAL_START_DATE', None)
    if _eval_start and floods_target is not None:
        _eval_ts = pd.to_datetime(_eval_start)
        _n_before = len(floods_target)
        if isinstance(floods_target, pd.Series):
            floods_target = floods_target[floods_target.index >= _eval_ts]
        elif isinstance(floods_target, pd.DataFrame):
            floods_target = floods_target[floods_target.index >= _eval_ts]
        _n_after = len(floods_target)
        if _n_after < _n_before:
            print(f"[SPINUP] eval_start_date={_eval_start}: 目标流量从 {_n_before} 步裁剪到 {_n_after} 步 (预热 {_n_before - _n_after} 步)")

    # [2026-07-06] Drop bad-data windows from the calibration target (sub-year, e.g. the
    # 2022-09~10 reservoir-pool phantom-flow window). Timesteps removed here vanish from
    # the objective via index.intersection in optimize_eval; NOT zero-filled. Config-driven,
    # default no-op. Format: exclude_windows: [["2022-09-01","2022-10-31"], ...]
    _excl = getattr(cfg, 'EXCLUDE_WINDOWS', None)
    if _excl and floods_target is not None:
        _n0 = len(floods_target)
        for _w in _excl:
            _w0, _w1 = pd.to_datetime(_w[0]), pd.to_datetime(_w[1]) + pd.Timedelta(hours=23, minutes=59)
            _keep = ~((floods_target.index >= _w0) & (floods_target.index <= _w1))
            floods_target = floods_target[_keep]
        print(f"[EXCLUDE_WINDOWS] {_excl}: 目标流量从 {_n0} 步剔除到 {len(floods_target)} 步 (删 {_n0 - len(floods_target)} 步)")

    # 冲突: 同时覆写与作为目标
    if eval_station and discharge_inflow is not None and eval_station in discharge_inflow.columns:
        try:
            if floods_target.equals(discharge_inflow[eval_station]):
                ov_stations = getattr(cfg, 'OVERRIDE_STATIONS', None)
                if ov_stations is None or (ov_stations is not None and eval_station in ov_stations):
                    raise ValueError(f"[CONFLICT] eval_station={eval_station} 被覆写且同时作为目标流量, 目标函数无意义")
        except Exception:
            pass

    # 简化输出: 仅展示评价锚点，不再标注模式
    print(f"[EVAL] EvalStation={eval_station}")

    # 校验 + 剪枝
    ctx = collect_context(cfg, msk_layers, connection_matrices, calib_cfg, eval_station, override_stations)
    issues = run_validations(ctx)
    write_validation_report(cfg, issues)
    n_err = sum(1 for i in issues if i.level == 'ERROR')
    n_warn = sum(1 for i in issues if i.level == 'WARN')
    if n_warn or n_err:
        print(f"[VALIDATION] ERROR={n_err} WARN={n_warn}")
    if n_err > 0:
        print('[VALIDATION] 存在 ERROR, 终止优化')
        return {}, float('nan')
    changed, pr_report = prune_calibration(ctx, calib_cfg)
    if changed:
        if os.environ.get('STRICT_NO_PRUNE','0') == '1':
            raise RuntimeError('[STRICT] 检测到将被裁剪的参数, 严格模式禁止自动裁剪: 请移除无关 layer_node 参数后重试')
        if os.environ.get('NO_PRUNE','0') != '1':
            print(f"[PRUNE] 移除 {pr_report['removed_count']} 条率定参数 -> 剩余 {pr_report['remaining']}")

    geo_info = (grid2sub, sub_area, connection_matrices, msk_layers)
    meteo_inputs = (rain, temp, snow, pet)
    external_flow_inputs = (obs_station_arr, sta_reach_idx)

    best_params, best_nse = optimize_parameters_distributed_eval(
        meteo_inputs=meteo_inputs,
        external_flow_inputs=external_flow_inputs,
        time_index=time_index,
        floods_discharge=floods_target,
        default_params=default_params,
        init_cond=init_cond,
        calib_cfg=calib_cfg,
        geo_info=geo_info,
        cfg=cfg,
        eval_station=eval_station,
        eval_is_last_layer_node=eval_is_last_layer_node,
        broadcaster=(
            (lambda _p: make_fixed_broadcaster(
                merged_model=_p[0],
                pdd_tuple=_p[1],
                xaj_tuple=_p[2],
                core_args=_p[3],
            ))(load_fixed_broadcast(os.environ['FIXED_BROADCAST_FILE']))
            if os.environ.get('FIXED_BROADCAST_FILE') else None
        ),
    )

    full_params_for_save, pdd_tuple, xaj_tuple, msk_layers_params, core_args_ret = prepare_model_params(
        param_dict=best_params,
        model_params_template=default_params,
        calibration_config=calib_cfg,
        grid2sub=grid2sub,
        sub_area=sub_area,
        connection_matrices=connection_matrices,
        param_mode={
            "msk_params": {"*": "sub"},
            "xaj_params": {"*": "basin"},
            "pdd_params": {"*": "basin"},
        },
    )

    # Re-run simulation to save best series
    try:
        init_state_arr = prepare_initial_conditions(init_cond, Ng, enable_snowmelt=False)
        # TEMP: dump params for external sensitivity analysis
        _dump_path = os.environ.get('DUMP_SIM_PARAMS')
        if _dump_path:
            np.savez(_dump_path,
                     rain=rain, temp=temp, snow=snow, pet=pet,
                     pdd_tuple=pdd_tuple, xaj_tuple=xaj_tuple,
                     grid2sub=grid2sub.astype(np.float32),
                     init_state=init_state_arr,
                     pdd_version=core_args_ret.get("pdd_version", "auto"))
            # Save msk_layers_params as separate arrays
            for i, lp in enumerate(msk_layers_params):
                np.savez(f"{_dump_path}_msk{i}.npz",
                         idx=lp[0], c0=lp[1], c1=lp[2], c2=lp[3], n_sub=lp[4])
            print(f"[DUMP] Saved sim params to {_dump_path}")
        sim_ret = _simulate_core(
            rain, temp, snow, pet,
            pdd_tuple, xaj_tuple,
            grid2sub.astype(np.float32),
            init_state_arr,
            return_last_layer=True,
            msk_layers_params=msk_layers_params,
            C_mats=connection_matrices,
            pdd_version=core_args_ret.get("pdd_version", "auto"),
        )
        if len(sim_ret) == 4:
            q_grid, q_subs, q_outlet, q_last_layer = sim_ret
        else:
            q_grid, q_subs, q_outlet = sim_ret[:3]
            q_last_layer = None
            
        # Save series
        out_dir = cfg.OUTPUT_DIR
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Use q_outlet by default
        series_to_save = q_outlet
        
        # If eval_station is specified and it's in the last layer, we might want that specific column?
        # But usually q_outlet is what we want for "sim vs obs" at the outlet.
        # If eval_station is upstream, q_outlet is still the basin outlet.
        
        series_path = out_dir / f"best_series_{cfg.SECTION_NAME}_{ts}.npy"
        np.save(series_path, series_to_save)
        
        # Also save as 'best_series.npy' for easy access (overwrite)
        np.save(out_dir / "best_series.npy", series_to_save)
        
        print(f"[SAVE] Best series saved to {series_path}")

        # Auto-plot
        try:
            import subprocess
            import sys
            
            # Try to find run-config from sys.argv
            run_config_path = None
            if '--run-config' in sys.argv:
                idx = sys.argv.index('--run-config')
                if idx + 1 < len(sys.argv):
                    run_config_path = sys.argv[idx+1]
            
            if run_config_path:
                png_path = out_dir / f"sim_vs_obs_{ts}.png"
                cmd = [
                    sys.executable, "-m", "src.runtime.semi_distributed.tools.plot_sim_vs_obs",
                    "--run-config", run_config_path,
                    "--series", str(series_path),
                    "--out", str(png_path)
                ]
                print(f"[PLOT] Auto-generating plot: {png_path}")
                subprocess.run(cmd, check=False)
        except Exception as e:
            print(f"[WARN] Auto-plot failed: {e}")

    except Exception as e:
        print(f"[WARN] Failed to save best series: {e}")
        import traceback
        traceback.print_exc()

    save_results(full_params_for_save, best_nse, cfg, init_cond)
    return best_params, best_nse

