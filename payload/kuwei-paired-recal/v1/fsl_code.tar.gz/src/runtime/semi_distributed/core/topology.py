from __future__ import annotations

import numpy as np
from pathlib import Path
from typing import Any, Sequence, List, Dict, Tuple, Optional
from src.runtime.semi_distributed.core.optimization_config import OptimizationConfig
import yaml


def _collect_topology_candidates(cfg: OptimizationConfig) -> list[Path]:
    """按优先级收集可能的 topology.yml 路径。"""
    candidates: list[Path] = []
    cfg_dir = getattr(cfg, "CONFIG_DIR", None)
    if cfg_dir:
        candidates.append(Path(cfg_dir) / "topology.yml")

    basin_name = getattr(cfg, "BASIN_NAME", None) or None
    project_root = getattr(cfg, "PROJECT_ROOT", None) or Path(__file__).resolve().parents[4]
    fallback_pairs = [
        ("config/basin", False),
        ("config/basins", False),
        ("config/basins", True),  # semi_distributed 子目录
    ]
    if basin_name:
        for rel_path, with_subdir in fallback_pairs:
            base = project_root / rel_path
            if with_subdir:
                candidates.append(base / basin_name / "semi_distributed" / "topology.yml")
            else:
                candidates.append(base / basin_name / "topology.yml")

    unique: list[Path] = []
    seen = set()
    for path in candidates:
        if path is None:
            continue
        if path in seen:
            continue
        seen.add(path)
        unique.append(path)
    return unique


def build_msk_layers_and_connect_mat(cfg: OptimizationConfig) -> tuple[list[dict], list[np.ndarray]]:
    """
    从基于名称的拓扑 YAML 文件加载并智能构造 Muskingum 拓扑。
      支持内联：若 cfg.INLINE_TOPOLOGY 为 dict，则直接使用它。
    """
    topo_config: Dict[str, Any] | None = getattr(cfg, 'INLINE_TOPOLOGY', None)
    if topo_config is None:
        tried_paths = _collect_topology_candidates(cfg)
        topology_path = None
        for candidate in tried_paths:
            if candidate.exists():
                topology_path = candidate
                break
        if topology_path is None:
            tried = ", ".join(str(p) for p in tried_paths) or "<未提供候选路径>"
            raise FileNotFoundError(f"拓扑配置文件未找到；已尝试: {tried}")
        with open(topology_path, "r", encoding="utf-8") as f:
            topo_config = yaml.safe_load(f)

    nodes = topo_config.get("nodes", {})
    connections = topo_config.get("connections", [])
    if not nodes:
        raise ValueError("拓扑配置必须包含 'nodes' 部分。")

    name_to_id = {name: data['id'] for name, data in nodes.items()}
    all_node_names = set(name_to_id.keys())

    # --- 1. 计算每个节点的拓扑层级 (Topological Sort) ---
    from collections import defaultdict
    downstream_map = {name: conn['to'] for conn in connections for name in conn['from']}
    upstream_map = defaultdict(list)
    for conn in connections:
        for from_node in conn['from']:
            upstream_map[conn['to']].append(from_node)

    source_nodes = all_node_names - set(upstream_map.keys())
    if not source_nodes:
        raise ValueError("拓扑结构中没有找到源头节点（入度为0的节点），可能存在循环。")

    node_levels = {}
    level_nodes = defaultdict(list)
    queue = list(source_nodes)
    for node in queue:
        node_levels[node] = 0
        level_nodes[0].append(node)

    head = 0
    while head < len(queue):
        u = queue[head]
        head += 1
        if u in downstream_map:
            v = downstream_map[u]
            # 只有当 v 的所有上游节点都已被处理，才处理 v
            if all(up_node in node_levels for up_node in upstream_map[v]):
                if v not in node_levels:
                    max_level = max(node_levels[up_node] for up_node in upstream_map[v])
                    node_levels[v] = max_level + 1
                    level_nodes[max_level + 1].append(v)
                    queue.append(v)

    if len(node_levels) != len(all_node_names):
        unprocessed = all_node_names - set(node_levels.keys())
        raise ValueError(f"拓扑结构无法解析，可能存在循环或孤立节点: {unprocessed}")

    # --- 2. 构建模型所需的 `layers` ---
    layers = []
    sorted_levels = sorted(level_nodes.keys())
    for level in sorted_levels:
        # 按 ID 排序以确保一致性
        level_node_names = sorted(level_nodes[level], key=lambda name: name_to_id[name])
        indices = [name_to_id[name] for name in level_node_names]
        # 附带名称，便于可视化标注（保持兼容性：新增键）
        layers.append({
            "index": np.array(indices, dtype=np.int32),
            "names": np.array(level_node_names, dtype=object),
        })

    # --- 3. 构建连接矩阵 `C_mats` ---
    c_mats = []
    for i in range(len(sorted_levels) - 1):
        from_level = sorted_levels[i]
        to_level = sorted_levels[i+1]

        from_nodes = sorted(level_nodes[from_level], key=lambda name: name_to_id[name])
        to_nodes = sorted(level_nodes[to_level], key=lambda name: name_to_id[name])

        c_matrix = np.zeros((len(to_nodes), len(from_nodes)), dtype=np.float32)
        for to_idx, to_name in enumerate(to_nodes):
            for from_idx, from_name in enumerate(from_nodes):
                if from_name in upstream_map.get(to_name, []):
                    c_matrix[to_idx, from_idx] = 1.0  # 默认权重为1.0
        c_mats.append(c_matrix)

    return layers, c_mats

# -*- coding: utf-8 -*-
"""topology.py

统一的 Muskingum 层级路由工具集。
———————————————————————————————————————————————————————
本版本 **仅支持基于 `msk_layers` 的参数组织方式**。
旧版依赖 `msk_params`（子流域级 c0/c1/num_subreaches）的逻辑已被移除。

配置示例（pdd_xaj_params.yml）::

    msk_layers:
      - index: [0, 1]      # 第一层包含子流域 zmsk、ql
        c0: 0.20
        c1: 0.60
        n_sub: 8
      - index: [2]         # 第二层（流域出口 ylx）
        c0: 0.20
        c1: 0.60
        n_sub: 3

API
---
prepare_layered_msk(Ns, msk_s, *, muskingum_layers, connection_matrices=None)
    生成各层 Muskingum 参数数组以及层间连接矩阵。
    `msk_s` 参数仅为兼容旧调用签名，函数内部不再使用。
"""


__all__ = [
    "build_msk_layers_and_connect_mat",
    "prepare_layered_msk",
]

# -----------------------------------------------------------------------------
# Helper utilities
# -----------------------------------------------------------------------------

def _as_1d_array(value: Any, dtype, size: int) -> np.ndarray:
    """Broadcast *value* to length *size* and cast to *dtype*.

    *value* 可以是标量 (int/float)、list、tuple 或 ndarray。
    如果长度已经匹配，则直接返回拷贝；否则将标量或长度为1的数组扩展。"""
    arr = np.asarray(value, dtype=dtype)
    # 兼容：长度为1的一维数组也视作标量进行广播
    if arr.ndim == 0 or arr.size == 1:
        return np.full(size, np.asarray(arr).ravel()[0], dtype=dtype)
    if arr.size == size:
        return arr.astype(dtype, copy=False)
    raise ValueError(
        f"无法将输入广播到长度 {size}: current size = {arr.size}")


def _build_identity_chain(muskingum_layers: Sequence[Dict[str, Any]]) -> List[np.ndarray]:
    """若用户未提供 connection_matrices，则按 *索引相同* 的规则自动构造。

    规则：下游层中的每一个单元，寻找其 *index* 在上游层中的位置，若能找到
    则用单位矩阵，把对应列置 1；否则对上游所有单元等权平均。"""
    mats: List[np.ndarray] = []
    for up, down in zip(muskingum_layers[:-1], muskingum_layers[1:]):
        up_idx = list(up["index"])
        down_idx = list(down["index"])

        C = np.zeros((len(down_idx), len(up_idx)), dtype=np.float32)
        for r, did in enumerate(down_idx):
            if did in up_idx:
                c = up_idx.index(did)
                C[r, c] = 1.0
            else:
                C[r, :] = 1.0 / len(up_idx)
        mats.append(C)
    return mats


# -----------------------------------------------------------------------------
# Core public function
# -----------------------------------------------------------------------------

def prepare_layered_msk(
    Ns: int,
    msk_s: Optional[Dict[str, np.ndarray]] | None,  # 未使用，仅保留位置
    *,
    muskingum_layers: Sequence[Dict[str, Any]],
    connection_matrices: Optional[Sequence[np.ndarray]] = None,
    segmented_default: bool = False,
) -> Tuple[List[Dict[str, np.ndarray]], List[np.ndarray]]:
    """将 YAML 中的 ``msk_layers`` 转换为 NumPy-friendly 结构。

    Parameters
    ----------
    Ns : int
        子流域（或最小单元）数量，用于校验 ``index`` 合法性。
    msk_s : dict | None
        **已弃用**。仅为了兼容旧调用保持参数位次，不作任何操作。
    muskingum_layers : list[dict]
        来自配置文件的层级 Muskingum 参数列表；每个元素需包含：

            * ``index``: List[int] —— 该层包含的子流域/单元索引
            * ``c0``   : float | List[float]
            * ``c1``   : float | List[float]
            * ``n_sub``: int   | List[int]

        其中 ``c0/c1/n_sub`` 可以给标量，函数会自动扩展到与 ``index``
        等长的 ndarray。
    connection_matrices : list[np.ndarray] | None, optional
        手动给定的层间连接矩阵 ``C_{i,i+1}``，数量应为 ``n_layers-1``，
        形状为 ``[n_dst, n_src]``。若为 *None*，函数采用 *index 相同 →
        单位映射* 的简单策略自动生成。

    Returns
    -------
    msk_layers_params : list[dict]
        长度 = ``n_layers``；其中每个元素包含：

        * ``index``  : ndarray[int]  (#subunits,)
        * ``c0``     : ndarray[float32]  (#subunits,)
        * ``c1``     : ndarray[float32]  (#subunits,)
        * ``n_sub``  : ndarray[int32]    (#subunits,)
    C_mats : list[np.ndarray]
        层间连接矩阵链表；``len = n_layers - 1``。
    """

    # —— 0. 基本校验 ——
    n_layers = len(muskingum_layers)
    if n_layers < 1:
        raise ValueError("muskingum_layers 至少需要一个元素！")

    # —— 1. 解析各层参数 ——
    msk_layers_params: List[Dict[str, np.ndarray]] = []
    for li, layer in enumerate(muskingum_layers):
        if "index" not in layer:
            raise KeyError(f"layer-{li} 缺少必需字段 'index'")
        idx: np.ndarray = np.asarray(layer["index"], dtype=int)
        if idx.ndim != 1:
            raise ValueError(f"layer-{li} 'index' 应为 1-D 序列")
        if np.any(idx < 0) or np.any(idx >= Ns):
            raise ValueError(
                f"layer-{li} 'index' 超出范围 [0, {Ns - 1}] -> {idx}")

        size = len(idx)
        
        # 支持两种模式：K/X 或 c0/c1/n_sub；segmented 可由层内 segmented 覆盖或使用全局默认
        segmented_layer = bool(layer.get("segmented", segmented_default))

        # 支持两种模式：K/X 或 c0/c1/n_sub
        if "K" in layer and "X" in layer:
            # K/X 模式：动态计算 c0, c1, n_sub
            from src.runtime.semi_distributed.core.params import (
                compute_muskingum_coefficients, compute_n_sub_from_K
            )
            K_arr = _as_1d_array(layer["K"], np.float32, size)
            X_arr = _as_1d_array(layer["X"], np.float32, size)
            dt_hours = float(layer.get("dt_hours", 24.0))
            
            c0 = np.empty(size, dtype=np.float32)
            c1 = np.empty(size, dtype=np.float32)
            n_sub = np.empty(size, dtype=np.int32)
            
            for i in range(size):
                K_i, X_i = float(K_arr[i]), float(X_arr[i])
                # 1) 先确定 n_sub
                if "n_sub" in layer:
                    n_sub[i] = int(round(float(_as_1d_array(layer["n_sub"], np.float32, size)[i])))
                else:
                    n_sub[i] = compute_n_sub_from_K(K_i, dt_hours)
                n_seg = max(1, int(n_sub[i]))
                # 2) 用分段后的 K_seg 计算系数，确保真正分段 Muskingum（或保持旧逻辑 K_i）
                K_eff = K_i / float(n_seg) if segmented_layer else K_i
                c0_i, c1_i, _ = compute_muskingum_coefficients(K_eff, X_i, dt_hours)
                c0[i] = c0_i
                c1[i] = c1_i
        elif "c0" in layer and "c1" in layer and "n_sub" in layer:
            # c0/c1/n_sub 模式
            try:
                c0 = _as_1d_array(layer["c0"], np.float32, size)
                c1 = _as_1d_array(layer["c1"], np.float32, size)
                n_sub = _as_1d_array(layer["n_sub"], np.int32, size)
            except KeyError as e:
                raise KeyError(
                    f"layer-{li} 缺少字段 {str(e)}；必须包含 'c0', 'c1', 'n_sub'")
        else:
            raise KeyError(
                f"layer-{li} 缺少必要字段；必须包含 'K', 'X' 或 'c0', 'c1', 'n_sub'")

        msk_layers_params.append({
            "index": idx,
            "c0": c0,
            "c1": c1,
            "n_sub": n_sub,
        })

    # —— 2. 连接矩阵 ——
    if connection_matrices is None:
        C_mats = _build_identity_chain(muskingum_layers)
    else:
        if len(connection_matrices) != n_layers - 1:
            raise ValueError(
                "connection_matrices 数量必须等于 n_layers-1, "
                f"收到 {len(connection_matrices)} vs {n_layers-1}")
        C_mats = [np.asarray(C, dtype=np.float32) for C in connection_matrices]

    return msk_layers_params, C_mats

