from src.runtime.semi_distributed.core.optimization_config import OptimizationConfig
import os
import pickle
import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple, Optional
from functools import partial
from scipy.optimize import differential_evolution
from src.runtime.semi_distributed.core.optimizer_facade import run_de
import json, time
from src.kernels.semi_distributed.core.simulate_flood_distributed_fast import _simulate_core
from src.runtime.semi_distributed.core.params import prepare_model_params, vector_to_params
from src.runtime.semi_distributed.core.constraints import make_combined_constraints, prepare_bounds
from src.runtime.semi_distributed.core.checkpoint import handle_resume
import copy

# ---- EVALCHK 日志追加工具 ----
_evalchk_seq = 0
def _append_evalchk(out_dir, record: Dict[str, Any]):  # type: ignore
    global _evalchk_seq
    try:
        import csv
        os.makedirs(out_dir, exist_ok=True)
        path = out_dir / "evalchk_log.csv"
        write_header = not path.exists()
        _evalchk_seq += 1
        record = {**record, "seq": _evalchk_seq, "time": time.strftime("%H:%M:%S")}
        cols = ["seq","time","mode","overlap_days","var_obs","var_sim","n_outlets_used","var_obs_mean"]
        with open(path, "a", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=cols, extrasaction='ignore')
            if write_header:
                w.writeheader()
            w.writerow(record)
    except Exception as e:  # noqa: BLE001
        print(f"[WARN] 书写 evalchk_log 失败: {e}")

# ---- 全局最近一次 EVALCHK 结果缓存，用于输出 calibration_report.json ----
_last_evalchk: Dict[str, Any] = {}

# 全局迭代计数器
iteration_count = 0
def checkpoint_callback(x: np.ndarray, convergence: float, cfg: "OptimizationConfig"):
    """
    DE 优化过程的回调函数。
    用于保存中间结果，以便在中断后可以恢复。
    """
    global iteration_count
    iteration_count += 1

    # 注意：旧版 scipy 的 callback 签名不提供 fun 值。
    # 我们只保存最优参数矢量 x 和随机状态。
    os.makedirs(os.path.dirname(cfg.CHECKPOINT_FILE), exist_ok=True)
    payload = {
        "iteration_offset": iteration_count,
        "x_best": x,
        "rng_state": np.random.get_state(),
    }
    # Windows 偶发 Errno 22 / 文件锁：重试写入
    import time, tempfile
    last_err = None
    for attempt in range(3):
        try:
            tmp_fd, tmp_path = tempfile.mkstemp(prefix="ckpt_", suffix=".tmp", dir=os.path.dirname(cfg.CHECKPOINT_FILE))
            with os.fdopen(tmp_fd, "wb") as f:
                pickle.dump(payload, f)
            # 原子替换
            try:
                os.replace(tmp_path, cfg.CHECKPOINT_FILE)
            except Exception:
                # 若替换失败，退回直接写
                with open(cfg.CHECKPOINT_FILE, "wb") as f2:
                    pickle.dump(payload, f2)
            last_err = None
            break
        except OSError as e:
            last_err = e
            time.sleep(0.25 * (attempt + 1))
    if last_err is not None:
        print(f"[WARN] Checkpoint 写入连续失败（忽略继续优化）: {last_err}")
    print(f"[Callback] Iteration={iteration_count}, Convergence={convergence:.6f}")
    return False

# ==================================================================
#   核心功能 (Core Functions)
# ==================================================================
def objective_function(
        param_vec: np.ndarray,
        # --- 预处理的气象和流量数据 ---
        meteo_inputs: tuple,
        external_flow_inputs: tuple,
        time_index: pd.DatetimeIndex,
        # --- 其他 ---
    floods_discharge: pd.Series | pd.DataFrame,
        model_tpl: Dict[str, Any],
        init_cond: Dict[str, Any],
        calib_cfg: Dict[str, Any],
        geo_info: tuple,
    cfg: OptimizationConfig,
    mean_flow_penalty_lambda: float = 0.0,
    obs_mean: Optional[float] = None,
) -> float:
    """
    目标函数：返回 **负 NSE**（差分进化求最小）。
    """
    # ── 1. 向量 → 参数字典 → 模型输入元组 ──────────────────
    param_dict = vector_to_params(param_vec, calib_cfg, calib_cfg['n_basins'])
    merged_model, pdd_tuple, xaj_tuple, _, core_args = prepare_model_params(
        param_dict=param_dict,
        model_params_template=model_tpl,
        calibration_config=calib_cfg,
        grid2sub=geo_info[0],
        sub_area=geo_info[1],
        connection_matrices=geo_info[2],
        param_mode={
            "msk_params": {"*": "sub"},
            "xaj_params": {"*": "basin"},
            "pdd_params": {"*": "basin"},
        },
    )

    # ── 可选：调试参数流校验（仅首轮或开启 debug 时） ─────────────
    debug_flag = bool(calib_cfg.get("debug_param_flow", False)) or (os.environ.get("DEBUG_PARAM_FLOW") == "1")
    if debug_flag and iteration_count <= 1:
        try:
            _debug_validate_param_flow(
                param_dict=param_dict,
                merged_model=merged_model,
                pdd_tuple=pdd_tuple,
                xaj_tuple=xaj_tuple,
                core_args=core_args,
                grid2sub=geo_info[0],
            )
        except AssertionError as e:
            raise RuntimeError(f"参数流校验失败: {e}")

    # ▶▶ 关键：直接调用核心模拟函数，简化调用链
    # 同时请求最后一层逐出口序列，用于多出口评估
    sim_ret = _simulate_core(
        meteo_inputs[0],        # rain
        meteo_inputs[1],        # temp
        meteo_inputs[2],        # snow
        meteo_inputs[3],        # pet
        pdd_tuple,
        xaj_tuple,
        geo_info[0].astype(np.float32),  # grid2sub
        init_cond,                        # initial state
        obs_station=external_flow_inputs[0],
        sta_reach_idx=external_flow_inputs[1],
        return_state_grid=False,
        return_last_layer=True,
        **core_args,
    )
    # 解包：兼容性考虑（可能返回 3 或 4 个）
    if len(sim_ret) == 3:
        q_grid, q_subs, q_outlet = sim_ret
        q_last_layer = None
    else:
        q_grid, q_subs, q_outlet, q_last_layer = sim_ret

    q_basin = q_outlet
    if q_basin is None or len(q_basin) == 0:
        raise ValueError("模拟结果 `q_outlet` 为空，优化无法继续。")
    if np.all(q_basin <= 0):
        # 直接报错，不做容错
        raise ValueError("模拟结果 `q_outlet` 全为非正值，视为无效输出。")
    if not np.isfinite(q_basin).all():
        raise ValueError("模拟结果 `q_outlet` 含 NaN/Inf，视为无效输出。")

    # 根据观测类型选择评估方式
    if isinstance(floods_discharge, pd.Series):
        # 单出口：使用总出口流量 q_basin（逐小时）
        sim_series_full = pd.Series(q_basin, index=time_index)
        idx = floods_discharge.index.intersection(sim_series_full.index)
        if len(idx) < 10:
            raise ValueError(
                f"观测和模拟数据重叠时段过短 (n={len(idx)})，无法计算有效的目标函数。"
                "请检查流量数据的时间范围。"
            )
        obs_series = floods_discharge.loc[idx]
        sim_series = sim_series_full.loc[idx]
        obs = obs_series.to_numpy()
        sim = sim_series.to_numpy()
        bad_obs = ~np.isfinite(obs)
        bad_sim = ~np.isfinite(sim)
        if bad_obs.any() or bad_sim.any():
            bad_times = []
            if bad_obs.any():
                bad_times.extend([f"obs@{t}" for t in obs_series.index[bad_obs][:10]])
            if bad_sim.any():
                bad_times.extend([f"sim@{t}" for t in sim_series.index[bad_sim][:10]])
            raise ValueError(
                "观测或模拟序列包含 NaN/Inf，无法计算目标函数。示例位置: " + ", ".join(map(str, bad_times))
            )
        if len(obs) < 10:
            raise ValueError(
                f"有效观测和模拟数据对不足 (n={len(obs)})，无法计算可靠的目标函数。"
                "可能由观测数据缺失或模拟失败导致。"
            )
        denom = ((obs - obs.mean()) ** 2).sum()
        if denom <= 0:
            raise ValueError("观测序列方差为 0，无法计算 NSE。")
        var_obs = float(np.var(obs, ddof=0))
        var_sim = float(np.var(sim, ddof=0))
        # 记录 EVALCHK
        rec = {
            "mode": "outlet",
            "overlap_steps": int(len(idx)),
            "var_obs": var_obs,
            "var_sim": var_sim,
        }
        _last_evalchk.update(rec)
        _append_evalchk(cfg.OUTPUT_DIR, rec)
        # 受环境变量 EVALCHK_MODE 控制
        _m = os.environ.get('EVALCHK_MODE','all')
        _flag = True
        if not hasattr(globals(), '_EVALCHK_PRINTED'):
            globals()['_EVALCHK_PRINTED'] = 0
        if _m == 'off':
            _flag = False
        elif _m == 'once' and globals()['_EVALCHK_PRINTED'] >= 1:
            _flag = False
        if _flag:
            # 跨进程一次性控制: 若配置 once 则使用输出目录内标记文件
            _m2 = os.environ.get('EVALCHK_MODE','all')
            if _m2 == 'once':
                marker = cfg.OUTPUT_DIR / '.evalchk_once.marker'
                try:
                    if marker.exists():
                        _flag = False
                    else:
                        marker.parent.mkdir(parents=True, exist_ok=True)
                        marker.write_text('1', encoding='utf-8')
                except Exception:
                    pass
            if _flag:
                print(f"[EVALCHK] mode=outlet overlap_steps={len(idx)} var_obs={var_obs:.4g} var_sim={var_sim:.4g}")
                globals()['_EVALCHK_PRINTED'] += 1
        nse = 1.0 - ((obs - sim) ** 2).sum() / denom
        # 流量均值偏差惩罚：若 mean(q_sim) 偏离 mean(q_obs) 则扣分
        if mean_flow_penalty_lambda > 0 and obs_mean is not None and obs_mean > 1e-6:
            sim_mean = float(np.nanmean(sim))
            rel_err = (sim_mean - obs_mean) / obs_mean
            penalty = mean_flow_penalty_lambda * (rel_err ** 2)
            nse = nse - penalty
        return -float(nse)

    elif isinstance(floods_discharge, pd.DataFrame):
        # 多出口：要求拿到最后一层逐出口时间序列
        if q_last_layer is None:
            raise RuntimeError("需要 return_last_layer=True 以获取逐出口序列用于多出口评估。")
        # 模拟逐出口逐小时
        sim_last_df = pd.DataFrame(q_last_layer, index=time_index)

        # 选择匹配方式：优先按列名匹配；若无交集，则按位置对齐（前 K 列）
        common_cols = [c for c in floods_discharge.columns if c in sim_last_df.columns]
        use_positional = False
        if not common_cols:
            use_positional = True
            k = min(floods_discharge.shape[1], sim_last_df.shape[1])
            if k == 0:
                raise ValueError("多出口评估无法进行：观测或模拟出口列数为 0。")

        nse_list = []
        if use_positional:
            for j in range(k):
                obs_col = floods_discharge.iloc[:, j]
                sim_col = sim_last_df.iloc[:, j]
                idx = obs_col.index.intersection(sim_col.index)
                if len(idx) < 10:
                    continue
                o = obs_col.loc[idx].to_numpy()
                s = sim_col.loc[idx].to_numpy()
                bad_o = ~np.isfinite(o)
                bad_s = ~np.isfinite(s)
                if bad_o.any() or bad_s.any():
                    continue
                denom = ((o - o.mean()) ** 2).sum()
                if denom <= 0:
                    continue
                nse_i = 1.0 - ((o - s) ** 2).sum() / denom
                nse_list.append(float(nse_i))
        else:
            for col in common_cols:
                obs_col = floods_discharge[col]
                sim_col = sim_last_df[col]
                idx = obs_col.index.intersection(sim_col.index)
                if len(idx) < 10:
                    continue  # 太短则跳过该出口
                o = obs_col.loc[idx].to_numpy()
                s = sim_col.loc[idx].to_numpy()
                bad_o = ~np.isfinite(o)
                bad_s = ~np.isfinite(s)
                if bad_o.any() or bad_s.any():
                    continue  # 严格：含坏值则忽略该出口
                denom = ((o - o.mean()) ** 2).sum()
                if denom <= 0:
                    continue
                nse_i = 1.0 - ((o - s) ** 2).sum() / denom
                nse_list.append(float(nse_i))

        if not nse_list:
            raise ValueError("多出口评估中，没有任何一个出口满足有效性条件（长度/方差/无NaN）。")

        # 目标：简单平均的负值
        nse_avg = float(np.mean(nse_list))
        # 记录多出口平均方差（粗略）
        var_list = []
        if isinstance(floods_discharge, pd.DataFrame):
            for col in floods_discharge.columns:
                try:
                    o = floods_discharge[col].dropna().to_numpy()
                    if o.size:
                        var_list.append(float(np.var(o, ddof=0)))
                except Exception:
                    pass
        var_obs_mean = float(np.mean(var_list)) if var_list else float('nan')
        rec = {
            "mode": "multi-outlet",
            "n_outlets_used": len(nse_list),
            "var_obs_mean": var_obs_mean,
        }
        _last_evalchk.update(rec)
        _append_evalchk(cfg.OUTPUT_DIR, rec)
        _m = os.environ.get('EVALCHK_MODE','all')
        _flag = True
        if not hasattr(globals(), '_EVALCHK_PRINTED'):
            globals()['_EVALCHK_PRINTED'] = 0
        if _m == 'off':
            _flag = False
        elif _m == 'once' and globals()['_EVALCHK_PRINTED'] >= 1:
            _flag = False
        if _flag:
            _m2 = os.environ.get('EVALCHK_MODE','all')
            if _m2 == 'once':
                marker = cfg.OUTPUT_DIR / '.evalchk_once.marker'
                try:
                    if marker.exists():
                        _flag = False
                    else:
                        marker.parent.mkdir(parents=True, exist_ok=True)
                        marker.write_text('1', encoding='utf-8')
                except Exception:
                    pass
            if _flag:
                print(f"[EVALCHK] mode=multi-outlet used={len(nse_list)} var_obs_mean={var_obs_mean:.4g}")
                globals()['_EVALCHK_PRINTED'] += 1
        return -nse_avg

    else:
        raise TypeError("floods_discharge 必须是 Series 或 DataFrame。")


# ==================================================================
#   调试辅助：参数流校验
# ==================================================================
def _debug_validate_param_flow(
    *,
    param_dict: Dict[str, Any],
    merged_model: Dict[str, Any],
    pdd_tuple: tuple,
    xaj_tuple: tuple,
    core_args: Dict[str, Any],
    grid2sub: np.ndarray,
):
    Ng, Ns = grid2sub.shape

    # 1) 形状与数值范围基础检查
    # 按 pdd_version 选择参数名映射
    _pdd_ver = core_args.get("pdd_version", "auto")
    if _pdd_ver == "v3":
        pdd_names = ("pdd_factor_snow", "pdd_factor_ice", "cfr", "cwh", "rfice")
    elif _pdd_ver == "v2" or len(pdd_tuple) == 6:
        pdd_names = ("pdd_factor_snow", "pdd_factor_ice", "refreeze_snow", "refreeze_ice", "cfr", "cwh")
    else:
        pdd_names = ("pdd_factor_snow", "pdd_factor_ice", "refreeze_snow", "refreeze_ice")
    xaj_names = ("kc","ki","kg","cs","ci","cg","wum","wlm","wdm","sm","imp","c","b","ex","uf","wmm","ms")
    pdd_map = {name: arr for name, arr in zip(pdd_names, pdd_tuple)}
    xaj_map = {name: arr for name, arr in zip(xaj_names, xaj_tuple)}

    for k, v in pdd_map.items():
        assert isinstance(v, np.ndarray) and v.shape == (Ng,), f"PDD参数 {k} 形状异常: {getattr(v,'shape',None)}"
        assert np.isfinite(v).all(), f"PDD参数 {k} 含 NaN/Inf"
    for k, v in xaj_map.items():
        assert isinstance(v, np.ndarray) and v.shape == (Ng,), f"XAJ参数 {k} 形状异常: {getattr(v,'shape',None)}"
        assert np.isfinite(v).all(), f"XAJ参数 {k} 含 NaN/Inf"

    msk_layers = core_args.get("msk_layers_params", [])
    assert isinstance(msk_layers, list) and len(msk_layers) >= 1, "msk_layers_params 为空"
    for li, L in enumerate(msk_layers):
        idx, c0, c1, c2, n_sub = L
        # 基础形状
        assert idx.dtype.kind in ("i","u"), f"第{li}层 idx 应为整数"
        n = len(idx)
        for name, arr in (("c0", c0), ("c1", c1), ("c2", c2), ("n_sub", n_sub)):
            assert len(arr) == n, f"第{li}层 {name} 长度应为 {n}, 实际 {len(arr)}"
        # 索引与参数取值
        assert (idx >= 0).all() and (idx < Ns).all(), f"第{li}层 idx 含越界值 (Ns={Ns})"
        assert (c0 >= -1e-6).all() and (c1 >= -1e-6).all(), f"第{li}层 c0/c1 有负值"
        s = c0 + c1 + c2
        assert np.allclose(s, 1.0, atol=1e-4), f"第{li}层 c0+c1+c2 不为 1, 最大偏差 {np.max(np.abs(s-1)):.3e}"
        assert (n_sub.astype(np.int32) == n_sub).all() and (n_sub >= 1).all(), f"第{li}层 n_sub 非法"

    # 2) 若 param_dict 包含 msk_layers 定向修改，抽样比对 merged_model 与 core_args
    if "msk_layers" in param_dict and isinstance(param_dict["msk_layers"], list):
        mm_layers = merged_model.get("msk_layers", [])
        for li, patch in enumerate(param_dict["msk_layers"]):
            if not patch:  # 可能为空字典
                continue
            src = mm_layers[li] if li < len(mm_layers) else {}
            # 仅抽样首个存在同时出现在 core_args 中的节点进行对齐检查
            if "index" in src and ("c0" in src and "c1" in src and "n_sub" in src):
                idx = np.asarray(src["index"])  # node ids 此层
                # 取第一个节点位置进行校验
                if idx.size:
                    j = 0
                    c0_m = float(src["c0"][j])
                    c1_m = float(src["c1"][j])
                    # 在 core_args 第 li 层相同位置
                    _, c0_a, c1_a, c2_a, _ = msk_layers[li]
                    assert abs(c0_a[j] - c0_m) < 1e-6 and abs(c1_a[j] - c1_m) < 1e-6, (
                        f"第{li}层第{j}节点 c0/c1 传递不一致: merged={c0_m:.6g}/{c1_m:.6g}, core={c0_a[j]:.6g}/{c1_a[j]:.6g}")

    # 3) 简短打印摘要（不刷屏）
    print("[ParamFlow] Ng=", Ng, "Ns=", Ns,
          "| PDD/XAJ ok | layers=", len(msk_layers),
          "| c0,c1,c2 sum≈1 & idx in-range & n_sub≥1 ✔")


def optimize_parameters_distributed(
        # --- 预处理的数据 ---
        meteo_inputs: tuple,
        external_flow_inputs: tuple,
        time_index: pd.DatetimeIndex,
        # --- 其他 ---
    floods_discharge: pd.Series,
        default_params: Dict[str, Any],
        init_cond: Dict[str, Any],
        calib_cfg: Dict[str, Any],
        geo_info: tuple,
        cfg: OptimizationConfig,
) -> Tuple[Dict[str, Any], float]:
    """
    驱动参数优化的主函数。
    """
    global iteration_count
    grid2sub, sub_area, C_mats, msk_layers = geo_info
    Ns = sub_area.shape[0]
    N_layer = len(msk_layers)
    calib_cfg['n_basins'] = Ns # 临时注入

    # --- 1. 生成参数边界 (Bounds) & 构建率定映射 ---
    def _build_calib_map(calib_cfg_local, Ns_local, N_layer_local):
        m = {
            "vector_size": int(calib_cfg_local.get("vector_size", 0)),
            "active_count": 0,
            "msk_layers": {},
            "xaj": {},
            "pdd": {},
        }
        idx_map = calib_cfg_local.get("index_map")
        if isinstance(idx_map, list):
            active_list = []
            for spec, idx in idx_map:
                path = spec.get("path", [])
                lvl = spec.get("level", "basin")
                param_name = path[-1] if path else "?"
                if lvl == "layer_node" and isinstance(idx, tuple):
                    layer_i, node_j = idx
                    layer_key = str(layer_i)
                    m["msk_layers"].setdefault(layer_key, []).append({
                        "param": param_name,
                        "node": int(node_j)
                    })
                elif path and path[0] == "xaj_params":
                    m["xaj"].setdefault(param_name, 0)
                    m["xaj"][param_name] += 1
                elif path and path[0] == "pdd_params":
                    m["pdd"].setdefault(param_name, 0)
                    m["pdd"][param_name] += 1
                active_list.append((param_name, lvl, idx if not isinstance(idx, np.ndarray) else "bulk"))
            m["active_list"] = active_list
            m["active_count"] = len(active_list)
        else:
            m["legacy_mode"] = True
        return m

    def _write_report(out_dir, *, calib_map=None, best_nse=None, skip_reason=None, evalchk=None):
        try:
            os.makedirs(out_dir, exist_ok=True)
            report = {
                "mode": "outlet",
                "skip_reason": skip_reason,
                "best_nse": best_nse,
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                "calibration_mapping": calib_map,
                "evalchk": evalchk if evalchk is not None else (_last_evalchk if _last_evalchk else None),
            }
            with open(out_dir / "calibration_report.json", "w", encoding="utf-8") as fp:
                json.dump(report, fp, ensure_ascii=False, indent=2)
        except Exception as e:  # noqa: BLE001
            print(f"[WARN] 写 calibration_report.json 失败: {e}")

    # ---- Step6 扩展：显式 none 选择直接跳过 ----
    if getattr(cfg, 'CALIB_NODE_SELECTOR', None) == 'none':
        print("[CALMAP] CALIB_NODE_SELECTOR=none → 跳过差分进化 (原出口模式)。")
        try:
            os.makedirs(cfg.OUTPUT_DIR, exist_ok=True)
            with open(cfg.OUTPUT_DIR / "skipped_optimization.flag", "w", encoding="utf-8") as f:
                f.write(time.strftime("%Y-%m-%d %H:%M:%S") + " selector-none\n")
        except Exception:
            pass
        _write_report(cfg.OUTPUT_DIR, calib_map=None, best_nse=None, skip_reason="selector-none", evalchk=None)
        return {}, float('nan')

    bounds = prepare_bounds(calib_cfg, Ns, N_layer)
    calib_map = _build_calib_map(calib_cfg, Ns, N_layer)
    if len(bounds) != calib_map.get("active_count", len(bounds)):
        print(f"[CALMAP] bounds={len(bounds)} active={calib_map.get('active_count')} vector_size={calib_cfg.get('vector_size')} (legacy={calib_map.get('legacy_mode', False)})")
    else:
        print(f"[CALMAP] active_params={calib_map.get('active_count', len(bounds))} vector_size={calib_cfg.get('vector_size')} bounds={len(bounds)}")
    try:
        os.makedirs(cfg.OUTPUT_DIR, exist_ok=True)
        with open(cfg.OUTPUT_DIR / "calibration_mapping.json", "w", encoding="utf-8") as fp:
            json.dump(calib_map, fp, ensure_ascii=False, indent=2)
    except Exception as _e:  # noqa: BLE001
        print(f"[WARN] 写 calibration_mapping.json 失败: {_e}")
    # Step6: 若经展开后仍无参数
    if len(bounds) == 0:
        print("[CALMAP] 无可率定参数(bounds=0)，跳过差分进化 (原出口模式)。")
        try:
            os.makedirs(cfg.OUTPUT_DIR, exist_ok=True)
            with open(cfg.OUTPUT_DIR / "skipped_optimization.flag", "w", encoding="utf-8") as f:
                f.write(time.strftime("%Y-%m-%d %H:%M:%S") + " empty-bounds\n")
        except Exception:
            pass
        _write_report(cfg.OUTPUT_DIR, calib_map=calib_map, best_nse=None, skip_reason="empty-bounds", evalchk=None)
        return {}, float('nan')
    # --- 2. 设置参数约束 ---
    constraints = make_combined_constraints(
        calib_cfg=calib_cfg,
        n_basins=Ns,
        n_layers=N_layer,
        c01_sum_ub=0.8,  # 如需改上限，在此调整
    )

    # --- 3. 断点恢复 ---
    iteration_count, actual_iter, init_pop = handle_resume(cfg, calib_cfg, Ns)

    # 检查是否已经完成
    if isinstance(init_pop, tuple) and init_pop[0] == "completed":
        best_params = init_pop[1]
        return best_params, -9999.0  # 返回占位符 NSE

    # --- 流量均值偏差惩罚配置 ---
    _mfp = getattr(cfg, 'MEAN_FLOW_PENALTY', 0.0)
    _obs_mean = None
    if _mfp > 0 and isinstance(floods_discharge, pd.Series):
        _obs_mean = float(floods_discharge.mean())
        print(f"[OPT] mean_flow_penalty={_mfp}, obs_mean={_obs_mean:.4g}")

    # --- 差分进化目标函数包装 ---
    de_obj = partial(
        objective_function,
        meteo_inputs=meteo_inputs,
        external_flow_inputs=external_flow_inputs,
        time_index=time_index,
        floods_discharge=floods_discharge,
        model_tpl=default_params,
        init_cond=init_cond,
        calib_cfg=calib_cfg,
        geo_info=geo_info,
    cfg=cfg,
    mean_flow_penalty_lambda=_mfp,
    obs_mean=_obs_mean,
    )

    # --- 额外 Step3: 参数微扰敏感性 (可选) ---
    if os.environ.get("DEBUG_PARAM_SENS") == "1" and len(bounds) > 0:
        print("[SENS] 开始快速参数敏感性 (±1% span, 前3个参数)")
        mids = np.array([(lo + hi) / 2 for lo, hi in bounds], dtype=float)
        try:
            base_obj = de_obj(mids)
            base_nse = -float(base_obj)
            active_list = calib_map.get("active_list") if isinstance(calib_map, dict) else None
            for i in range(min(3, len(bounds))):
                lo, hi = bounds[i]
                span = hi - lo
                if span <= 0:
                    continue
                delta = 0.01 * span
                name = None
                if active_list and i < len(active_list):
                    name = active_list[i][0]
                name = name or f"p{i}"
                for sign in (+1, -1):
                    vec = mids.copy()
                    vec[i] = np.clip(vec[i] + sign * delta, lo, hi)
                    obj = de_obj(vec)
                    nse = -float(obj)
                    print(f"[SENS] idx={i} name={name} sign={'+ ' if sign>0 else '-'} delta={delta:.3g} baseNSE={base_nse:.4g} newNSE={nse:.4g} dNSE={nse-base_nse:.3g}")
        except Exception as e:
            print(f"[SENS] 敏感性计算失败: {e}")

    result = run_de(
        de_obj,
        bounds,
        constraints=constraints,
        strategy="best1bin",
        maxiter=actual_iter,
        popsize=cfg.POP_SIZE,
        workers=cfg.WORKERS,
        updating="deferred",
        init=init_pop,
        callback=partial(checkpoint_callback, cfg=cfg),
        disp=True,
        polish=False,
    )

    best_params = vector_to_params(result.x, calib_cfg, Ns)
    best_nse = -float(result.fun)
    # 主进程重新计算一次 EVALCHK 以便写入报告（避免并行 worker 中的全局字典不可见）
    evalchk_main = None
    try:
        # 复用 objective 内逻辑：直接模拟一遍
        param_dict = best_params
        merged_model, pdd_tuple, xaj_tuple, _, core_args = prepare_model_params(
            param_dict=param_dict,
            model_params_template=default_params,
            calibration_config=calib_cfg,
            grid2sub=geo_info[0],
            sub_area=geo_info[1],
            connection_matrices=geo_info[2],
            param_mode={
                "msk_params": {"*": "sub"},
                "xaj_params": {"*": "basin"},
                "pdd_params": {"*": "basin"},
            },
        )
        sim_ret = _simulate_core(
            meteo_inputs[0], meteo_inputs[1], meteo_inputs[2], meteo_inputs[3],
            pdd_tuple, xaj_tuple,
            geo_info[0].astype(np.float32),
            init_cond,
            obs_station=external_flow_inputs[0],
            sta_reach_idx=external_flow_inputs[1],
            return_state_grid=False,
            return_last_layer=True,
            **core_args,
        )
        if len(sim_ret) == 3:
            _, _, q_outlet = sim_ret
            q_last_layer = None
        else:
            _, _, q_outlet, q_last_layer = sim_ret
        if isinstance(floods_discharge, pd.Series):
            sim_series = pd.Series(q_outlet, index=time_index)
            idx = floods_discharge.index.intersection(sim_series.index)
            if len(idx) >= 1:
                obs = floods_discharge.loc[idx].to_numpy()
                sim = sim_series.loc[idx].to_numpy()
                evalchk_main = {
                    "mode": "outlet",
                    "overlap_days": int(len(idx)),
                    "var_obs": float(np.var(obs, ddof=0)),
                    "var_sim": float(np.var(sim, ddof=0)),
                }
        elif isinstance(floods_discharge, pd.DataFrame) and q_last_layer is not None:
            sim_last_df = pd.DataFrame(q_last_layer, index=time_index)
            nse_list = []
            for col in floods_discharge.columns:
                if col in sim_last_df.columns:
                    obs_col = floods_discharge[col]
                    sim_col = sim_last_df[col]
                    idx = obs_col.index.intersection(sim_col.index)
                    if len(idx) < 1:
                        continue
                    o = obs_col.loc[idx].to_numpy()
                    nse_list.append(float(np.var(o, ddof=0)))
            if nse_list:
                evalchk_main = {
                    "mode": "multi-outlet",
                    "n_outlets_used": len(nse_list),
                    "var_obs_mean": float(np.mean(nse_list)),
                }
    except Exception as e:  # noqa: BLE001
        print(f"[WARN] 重新计算 EVALCHK 失败: {e}")
    # 写报告
    _write_report(cfg.OUTPUT_DIR, calib_map=calib_map, best_nse=best_nse, skip_reason=None, evalchk=evalchk_main)
    return best_params, best_nse

