"""Open-Meteo API forecast provider."""
from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta
from math import ceil
from urllib.request import Request, urlopen

import numpy as np
import pandas as pd

from src.runtime.semi_distributed.core.forecast_meteo_provider import (
    ForecastMeteoProvider,
    ForecastMeteoResult,
)

logger = logging.getLogger(__name__)

# Open-Meteo model endpoints
_MODEL_URLS = {
    "ecmwf_ifs": "https://api.open-meteo.com/v1/ecmwf",
    "gfs": "https://api.open-meteo.com/v1/gfs",
}

# Variables to request
_HOURLY_VARS = "precipitation,temperature_2m,et0_fao_evapotranspiration,snowfall"


class OpenMeteoProvider(ForecastMeteoProvider):
    """Fetch hourly forecast from Open-Meteo API (no API key needed)."""

    def __init__(self, model: str = "ecmwf_ifs", timeout: float = 30.0):
        if model not in _MODEL_URLS:
            raise ValueError(
                f"Unknown model '{model}'. Available: {list(_MODEL_URLS.keys())}"
            )
        self.model = model
        self.base_url = _MODEL_URLS[model]
        self.timeout = timeout

    def fetch(self, coords, start, forecast_steps, dt_hours) -> ForecastMeteoResult:
        if not coords:
            raise ValueError("coords must not be empty")

        Ng = len(coords)
        forecast_hours = int(forecast_steps * dt_hours)
        forecast_days = max(1, ceil(forecast_hours / 24))

        # Build time range
        start_date = start.strftime("%Y-%m-%d")
        end_date = (start + timedelta(hours=forecast_hours)).strftime("%Y-%m-%d")

        all_rain = []
        all_temp = []
        all_snow = []
        all_pet = []
        times = None

        for lat, lon in coords:
            url = (
                f"{self.base_url}"
                f"?latitude={lat}&longitude={lon}"
                f"&hourly={_HOURLY_VARS}"
                f"&start_date={start_date}&end_date={end_date}"
                f"&timezone=UTC"
            )
            logger.info(
                "Fetching Open-Meteo %s: lat=%.2f lon=%.2f [%s -> %s]",
                self.model, lat, lon, start_date, end_date,
            )

            req = Request(url, headers={"User-Agent": "forecast-system-lite/1.0"})
            with urlopen(req, timeout=self.timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))

            if "hourly" not in data:
                raise ValueError(
                    f"Open-Meteo returned no hourly data: {data.get('reason', 'unknown')}"
                )

            hourly = data["hourly"]
            raw_times = hourly["time"]  # list of ISO strings
            raw_rain = hourly.get("precipitation", [])
            raw_temp = hourly.get("temperature_2m", [])
            raw_snow = hourly.get("snowfall", [])
            raw_pet = hourly.get("et0_fao_evapotranspiration", [])

            # Parse times
            if times is None:
                times = pd.to_datetime(raw_times, utc=True)

            # Convert to numpy, handle None values
            rain_arr = np.array(
                [v if v is not None else 0.0 for v in raw_rain], dtype=np.float32,
            )
            temp_arr = np.array(
                [v if v is not None else np.nan for v in raw_temp], dtype=np.float32,
            )
            snow_arr = np.array(
                [v if v is not None else 0.0 for v in raw_snow], dtype=np.float32,
            )
            pet_arr = np.array(
                [v if v is not None else 0.0 for v in raw_pet], dtype=np.float32,
            )

            # Snowfall from Open-Meteo is in cm, convert to mm
            snow_arr *= 10.0

            all_rain.append(rain_arr)
            all_temp.append(temp_arr)
            all_snow.append(snow_arr)
            all_pet.append(pet_arr)

        # Stack to (T_api, Ng)
        rain = np.column_stack(all_rain)
        temp = np.column_stack(all_temp)
        snow = np.column_stack(all_snow)
        pet = np.column_stack(all_pet)

        # Filter to only times >= start and take forecast_steps
        # Open-Meteo may return full day, we need exact slice
        start_ts = pd.Timestamp(start, tz="UTC")
        mask = times >= start_ts
        rain = rain[mask]
        temp = temp[mask]
        snow = snow[mask]
        pet = pet[mask]
        times = times[mask]

        # Resample if dt_hours != 1
        if dt_hours != 1.0:
            step = int(dt_hours)
            # Aggregate rain/snow (sum), average temp/pet
            n_out = min(forecast_steps, len(rain) // step)
            rain_r = np.zeros((n_out, Ng), dtype=np.float32)
            temp_r = np.zeros((n_out, Ng), dtype=np.float32)
            snow_r = np.zeros((n_out, Ng), dtype=np.float32)
            pet_r = np.zeros((n_out, Ng), dtype=np.float32)
            for i in range(n_out):
                s, e = i * step, (i + 1) * step
                rain_r[i] = rain[s:e].sum(axis=0)
                temp_r[i] = temp[s:e].mean(axis=0)
                snow_r[i] = snow[s:e].sum(axis=0)
                pet_r[i] = pet[s:e].sum(axis=0)
            rain, temp, snow, pet = rain_r, temp_r, snow_r, pet_r
            times = times[::step][:n_out]
        else:
            rain = rain[:forecast_steps]
            temp = temp[:forecast_steps]
            snow = snow[:forecast_steps]
            pet = pet[:forecast_steps]
            times = times[:forecast_steps]

        # Pad if API returned fewer steps than requested
        actual_steps = rain.shape[0]
        if actual_steps < forecast_steps:
            pad = forecast_steps - actual_steps
            logger.warning(
                "Open-Meteo returned %d steps, padding %d with last value",
                actual_steps, pad,
            )
            rain = np.concatenate([rain, np.tile(rain[-1:], (pad, 1))])
            temp = np.concatenate([temp, np.tile(temp[-1:], (pad, 1))])
            snow = np.concatenate([snow, np.tile(snow[-1:], (pad, 1))])
            pet = np.concatenate([pet, np.tile(pet[-1:], (pad, 1))])
            dt = pd.Timedelta(hours=dt_hours)
            extra_times = pd.date_range(times[-1] + dt, periods=pad, freq=dt)
            times = times.append(extra_times)

        # Validate
        if (rain < 0).any():
            rain = np.maximum(rain, 0.0)
            logger.warning("Clipped negative rain values to 0")
        if not np.isfinite(temp).all():
            # Fill NaN temp with mean of valid values
            col_mean = np.nanmean(temp, axis=0)
            for j in range(Ng):
                nan_mask = ~np.isfinite(temp[:, j])
                if nan_mask.any():
                    temp[nan_mask, j] = col_mean[j] if np.isfinite(col_mean[j]) else 20.0
            logger.warning("Filled NaN temperature values")
        if (rain > 200).any():
            logger.warning("Extreme rain value detected: %.1f mm/h", rain.max())

        return ForecastMeteoResult(
            rain=rain.astype(np.float32),
            temp=temp.astype(np.float32),
            snow=snow.astype(np.float32),
            pet=pet.astype(np.float32),
            time_index=times[:forecast_steps],
            source=self.model,
            metadata={
                "api": "open-meteo",
                "model": self.model,
                "forecast_days": forecast_days,
            },
        )
