from __future__ import annotations
"""optimize_eval.py (moved to core)

Phase-1: 基于 eval_station 的单站评价版本（不改动原 optimize.py）。

扩展: 允许评估第 0 层(子流域层) 节点或最后一层出口节点。其它中间层暂不支持。
若 eval_station 属于第0层: 使用 q_subs 对应列日尺度聚合评估。
若属于最后一层: 使用 q_last_layer 对应列评估。
否则报错并提示限制。

新增: 列越界自适应 (单子流域 / 过滤后层缩减) -> 回退使用第0列并给出一次性警告。
"""
from functools import partial
from pathlib import Path
from typing import Dict, Any, Tuple
# 修改: 增加 Union 以兼容旧版本 Python 类型提示
from typing import Union
import json, os, time
import numpy as np
import pandas as pd
from scipy.optimize import differential_evolution
from src.runtime.semi_distributed.core.optimizer_facade import run_de, run_cmaes, run_optuna

from src.runtime.semi_distributed.core.optimization_config import OptimizationConfig
from src.runtime.semi_distributed.core.params import prepare_model_params, vector_to_params  # type: ignore
from src.runtime.semi_distributed.core.constraints import make_combined_constraints, prepare_bounds  # type: ignore
from src.runtime.semi_distributed.core.checkpoint import handle_resume  # type: ignore
from src.kernels.semi_distributed.core.simulate_flood_distributed_fast import _simulate_core, prepare_initial_conditions
from src.runtime.semi_distributed.core.broadcast_api import Broadcaster, make_default_broadcaster

# 复用全局迭代计数（不与原 optimize.py 混用以免冲突）
_iteration_eval = 0
_last_evalchk_eval: Dict[str, Any] = {}

_WARNED_FALLBACK_COL = False
# 进度打印节流: 环境变量 EVALOPT_PRINT_FREQ (默认 20), 主进程限制 MAIN_PID / EVALOPT_MASTER_ONLY
_EVALOPT_FREQ = int(os.environ.get('EVALOPT_PRINT_FREQ', '20') or '20')
if _EVALOPT_FREQ <= 0:
    _EVALOPT_FREQ = 20
_EVALOPT_MASTER_ONLY = os.environ.get('EVALOPT_MASTER_ONLY', '1') == '1'
_MAIN_PID = os.environ.get('MAIN_PID')
# 目标函数调试采样
_EVALOBJ_SAMPLES = []  # 存储前若干 nse
_EVALOBJ_SUMMARY_PRINTED = False
_EVALOBJ_SAMPLE_LIMIT = 50

# 在全局增加当前与最佳 NSE 记录
_LAST_NSE = None  # 最近一次评估得到的 NSE (越大越好)
_BEST_NSE = None  # 迄今为止最佳 NSE

# ---- 并行包装器 (模块级，便于 Windows spawn 可 pickling) ----
from functools import partial as _fpartial

def _parallel_wrapper(vec, *, base_obj, shared_stats):
    val = base_obj(vec)
    try:
        nse = -float(val)
        shared_stats['last'] = nse
        best_v = shared_stats.get('best')
        if best_v is None or nse > best_v:
            shared_stats['best'] = nse
    except Exception:
        pass
    return val


def _record_nse(val: float):
    """记录最近与最佳 NSE (线程/进程内)."""
    global _LAST_NSE, _BEST_NSE
    _LAST_NSE = float(val)
    if _BEST_NSE is None or val > _BEST_NSE:
        _BEST_NSE = float(val)


def _checkpoint_cb_eval(x: np.ndarray, convergence: float, cfg: OptimizationConfig, shared_stats=None):
    """差分进化回调：节流打印进度 + 合并并行 worker 的 NSE 统计。

    shared_stats: multiprocessing.Manager().dict()，键: 'last','best'.
    """
    global _iteration_eval, _LAST_NSE, _BEST_NSE
    _iteration_eval += 1

    # 合并并行 worker 统计
    if shared_stats is not None:
        try:
            last_v = shared_stats.get('last')
            best_v = shared_stats.get('best')
            if last_v is not None:
                _LAST_NSE = float(last_v)
            if best_v is not None and ( _BEST_NSE is None or best_v > _BEST_NSE):
                _BEST_NSE = float(best_v)
        except Exception:
            pass

    # 仅主进程（若开启） + 按频率打印
    if _EVALOPT_MASTER_ONLY and _MAIN_PID and str(os.getpid()) != _MAIN_PID:
        return False
    if _iteration_eval == 1 or (_iteration_eval % _EVALOPT_FREQ == 0):
        if _LAST_NSE is None:
            last_txt = 'NA'
        else:
            last_txt = f"{_LAST_NSE:.4f}"
        if _BEST_NSE is None:
            best_txt = 'NA'
        else:
            best_txt = f"{_BEST_NSE:.4f}"
        print(f"[EvalOpt] Iter={_iteration_eval} Convergence={convergence:.6f} LastNSE={last_txt} BestNSE={best_txt}")
        if os.environ.get('EVALOPT_DEBUG') == '1' and _EVALOBJ_SAMPLES:
            from statistics import mean, pstdev
            try:
                ucnt = len(set(round(v,6) for v in _EVALOBJ_SAMPLES))
                print(f"[EvalOptDebug] early_nse_samples={len(_EVALOBJ_SAMPLES)} unique6={ucnt} min={min(_EVALOBJ_SAMPLES):.4f} max={max(_EVALOBJ_SAMPLES):.4f} mean={mean(_EVALOBJ_SAMPLES):.4f} std={pstdev(_EVALOBJ_SAMPLES):.4f}")
            except Exception:
                pass
    return False


def _safe_pick_col(arr, col, label: str):
    global _WARNED_FALLBACK_COL
    if col >= arr.shape[1]:
        if not _WARNED_FALLBACK_COL:
            print(f"[WARN] {label} 目标列 {col} 超出宽度 {arr.shape[1]}，回退 col=0")
            _WARNED_FALLBACK_COL = True
        return 0
    return col


def _water_balance_penalty(sim_full, obs_full, years, lam: float) -> float:
    """Water-balance penalty on the PRE-mask full scored window.

    A masked-subset simulated mean compared against the whole-window observed
    mean is a unit mismatch once objective_mask keeps only peaks, so callers
    must pass the arrays captured BEFORE objective_mask. With ``years`` given,
    charges the mean squared relative ANNUAL volume error, so dry-year
    over-production cannot hide behind a pooled mean dominated by wet years.
    lam <= 0 (the wired default) is an exact no-op.
    """
    if lam <= 0 or len(sim_full) == 0:
        return 0.0
    sim_arr = np.asarray(sim_full, dtype=float)
    obs_arr = np.asarray(obs_full, dtype=float)
    if years is None:
        if not np.isfinite(obs_arr).any():
            return 0.0
        obs_mean = float(np.nanmean(obs_arr))
        if not np.isfinite(obs_mean) or obs_mean <= 1e-6:
            return 0.0
        rel = (float(np.nanmean(sim_arr)) - obs_mean) / obs_mean
        return float(lam * rel * rel) if np.isfinite(rel) else 0.0
    years_arr = np.asarray(years)
    total, count = 0.0, 0
    for year in np.unique(years_arr):
        sel = years_arr == year
        if not np.isfinite(obs_arr[sel]).any():
            continue
        obs_mean = float(np.nanmean(obs_arr[sel]))
        if not np.isfinite(obs_mean) or obs_mean <= 1e-6:
            continue
        rel = (float(np.nanmean(sim_arr[sel])) - obs_mean) / obs_mean
        if np.isfinite(rel):
            total += rel * rel
            count += 1
    return float(lam * total / count) if count else 0.0


def _objective_function_eval(
    param_vec: np.ndarray,
    *,
    meteo_inputs: tuple,
    external_flow_inputs: tuple,
    time_index: pd.DatetimeIndex,
    floods_discharge: Union[pd.Series, pd.DataFrame],
    model_tpl: Dict[str, Any],
    init_cond: Dict[str, Any],
    calib_cfg: Dict[str, Any],
    geo_info: tuple,
    cfg: OptimizationConfig,
    eval_station: str | None,
    eval_is_last_layer_node: bool,
    broadcaster: Broadcaster,
    mean_flow_penalty_lambda: float = 0.0,
    mean_flow_penalty_yearly: bool = False,
    obs_mean: float | None = None,
    objective_mask_query: str | None = None,
    objective_weight_strategy: str | None = None,
    objective_type: str = "nse",
) -> float:
    """目标函数：通过可注入的 broadcaster 构造 (pdd/xaj/core_args)，再调用模拟并计算 NSE。"""
    try:
        return _objective_function_eval_inner(
            param_vec,
            meteo_inputs=meteo_inputs,
            external_flow_inputs=external_flow_inputs,
            time_index=time_index,
            floods_discharge=floods_discharge,
            model_tpl=model_tpl,
            init_cond=init_cond,
            calib_cfg=calib_cfg,
            geo_info=geo_info,
            cfg=cfg,
            eval_station=eval_station,
            eval_is_last_layer_node=eval_is_last_layer_node,
            broadcaster=broadcaster,
            mean_flow_penalty_lambda=mean_flow_penalty_lambda,
            mean_flow_penalty_yearly=mean_flow_penalty_yearly,
            obs_mean=obs_mean,
            objective_mask_query=objective_mask_query,
            objective_weight_strategy=objective_weight_strategy,
            objective_type=objective_type,
        )
    except Exception:
        return 9999.0


def _objective_function_eval_inner(
    param_vec: np.ndarray,
    *,
    meteo_inputs: tuple,
    external_flow_inputs: tuple,
    time_index: pd.DatetimeIndex,
    floods_discharge: Union[pd.Series, pd.DataFrame],
    model_tpl: Dict[str, Any],
    init_cond: Dict[str, Any],
    calib_cfg: Dict[str, Any],
    geo_info: tuple,
    cfg: OptimizationConfig,
    eval_station: str | None,
    eval_is_last_layer_node: bool,
    broadcaster: Broadcaster,
    mean_flow_penalty_lambda: float = 0.0,
    mean_flow_penalty_yearly: bool = False,
    obs_mean: float | None = None,
    objective_mask_query: str | None = None,
    objective_weight_strategy: str | None = None,
    objective_type: str = "nse",
) -> float:
    """Inner objective: does actual simulation and metric computation (may raise)."""
    # 使用广播器将向量映射为模拟所需结构
    merged_model, pdd_tuple, xaj_tuple, core_args = broadcaster(
        param_vec, calib_cfg, model_tpl, geo_info
    )

    # 准备初始状态数组 (Ng,11)
    grid2sub = geo_info[0]
    Ng = int(getattr(grid2sub, 'shape', (0, 0))[0])
    init_state_arr = prepare_initial_conditions(init_cond, Ng, enable_snowmelt=False)

    # 调用核心模拟，确保拿到最后一层逐节点输出
    sim_ret = _simulate_core(
        meteo_inputs[0], meteo_inputs[1], meteo_inputs[2], meteo_inputs[3],
        pdd_tuple, xaj_tuple,
        grid2sub.astype(np.float32),
        init_state_arr,
        obs_station=external_flow_inputs[0],
        sta_reach_idx=external_flow_inputs[1],
        return_state_grid=False,
        return_last_layer=True,
        **core_args,
    )
    if len(sim_ret) == 3:
        q_grid, q_subs, q_outlet = sim_ret
        q_last_layer = None
    else:
        q_grid, q_subs, q_outlet, q_last_layer = sim_ret

    # --- Helper: Weighted NSE Calculation ---
    def _calc_weighted_nse(obs_arr, sim_arr, weight_strategy: str | None = None):
        if len(obs_arr) == 0:
            return -9999.0
            
        # 1. 计算权重向量
        weights = np.ones_like(obs_arr)
        
        if weight_strategy == "pow2":
             # 简单平方加权：权重 = 观测流量的平方
             weights = obs_arr ** 2
        elif weight_strategy == "linear":
             # 线性加权：权重 = 观测流量
             weights = np.abs(obs_arr)
        elif weight_strategy == "rising_priority":
             # [DEPRECATED] 旧的涨水优先 (叠加了线性权重)
             weights = np.abs(obs_arr).copy()
             diff = np.diff(obs_arr, prepend=obs_arr[0])
             rising_mask = diff > 0.01
             weights[rising_mask] *= 3.0

        elif weight_strategy == "limb_shape":
             # 纯涨落形态加权 (不乘流量大小，纯粹关注波形)
             weights = np.ones_like(obs_arr)
             
             # 计算梯度
             diff = np.diff(obs_arr, prepend=obs_arr[0])
             
             # 定义阈值 (日尺度 > 1.0 m3/s 视为显著变化)
             THRESHOLD = 0.5
             rising_mask = diff > THRESHOLD
             falling_mask = diff < -THRESHOLD
             
             # 赋予高权重以锁定波形
             # 涨落同等重要，都要抓准
             weights[rising_mask] = 5.0
             weights[falling_mask] = 5.0
             # 平稳期维持 1.0

        elif weight_strategy == "rising_only":
             # [NEW] 极端专注涨水 (用于 IMM 模型 Training A)
             # 背景给予非零低权重 (0.1) 保持数值稳定，但由涨水 (10.0) 主导
             weights = np.full_like(obs_arr, 0.1)
             
             diff = np.diff(obs_arr, prepend=obs_arr[0])
             THRESHOLD = 0.5
             rising_mask = diff > THRESHOLD
             
             weights[rising_mask] = 10.0

        elif weight_strategy == "falling_only":
             # [NEW] 极端专注落水 (用于 IMM 模型 Training B)
             weights = np.full_like(obs_arr, 0.1)
             
             diff = np.diff(obs_arr, prepend=obs_arr[0])
             THRESHOLD = 0.5
             falling_mask = diff < -THRESHOLD
             
             weights[falling_mask] = 10.0
             
        # 2. 计算 NSE
        # 注意：对于加权 NSE，均值通常也应是加权均值
        denom_sum = np.sum(weights)
        if denom_sum == 0:
            return -9999.0
            
        w_mean = np.sum(weights * obs_arr) / denom_sum
        
        numerator = np.sum(weights * ((obs_arr - sim_arr) ** 2))
        denominator = np.sum(weights * ((obs_arr - w_mean) ** 2))
        
        if denominator == 0:
            return -9999.0
            
        return 1.0 - (numerator / denominator)

    # --- Helper: Log-NSE Calculation ---
    def _calc_log_nse(obs_arr, sim_arr, eps=0.01):
        """Log-NSE: equalizes dynamic range for low-flow calibration (Pushpalatha 2012)."""
        if len(obs_arr) == 0:
            return -9999.0
        # Clip sim to eps to avoid log(negative) from bad DE parameter combos
        sim_safe = np.maximum(sim_arr, eps)
        log_obs = np.log(obs_arr + eps)
        log_sim = np.log(sim_safe)
        mean_log_obs = np.mean(log_obs)
        ss_res = np.sum((log_obs - log_sim) ** 2)
        ss_tot = np.sum((log_obs - mean_log_obs) ** 2)
        if ss_tot == 0:
            return -9999.0
        return 1.0 - ss_res / ss_tot

    # --- Helper: KGE Calculation ---
    def _calc_kge(obs_arr, sim_arr):
        """Kling-Gupta Efficiency (Gupta et al. 2009)."""
        if len(obs_arr) < 10:
            return -9999.0
        r = np.corrcoef(obs_arr, sim_arr)[0, 1]
        std_o = np.std(obs_arr)
        alpha = np.std(sim_arr) / std_o if std_o > 0 else -9999.0
        mean_o = np.mean(obs_arr)
        beta = np.mean(sim_arr) / mean_o if mean_o > 0 else -9999.0
        if alpha < -9000 or beta < -9000:
            return -9999.0
        return 1.0 - np.sqrt((r - 1) ** 2 + (alpha - 1) ** 2 + (beta - 1) ** 2)

    # --- Helper: Unified Objective Computation ---
    def _calc_objective(obs_arr, sim_arr, obj_type, weight_strategy=None):
        """Dispatch to appropriate objective function based on obj_type."""
        if obj_type == "log_nse":
            return _calc_log_nse(obs_arr, sim_arr)
        elif obj_type == "kge":
            return _calc_kge(obs_arr, sim_arr)
        else:  # default: "nse"
            return _calc_weighted_nse(obs_arr, sim_arr, weight_strategy)

    # --- Helper: Mask Application ---
    def _apply_mask(obs_arr, sim_arr, query_str):
        if not query_str or len(obs_arr) == 0:
            return obs_arr, sim_arr
        
        # [Fix] Pre-clean NaNs from observation data before quantile calculation
        # This prevents NaN propagation into thresholds (q80 -> NaN)
        valid_mask = ~np.isnan(obs_arr)
        if not np.any(valid_mask): # All NaNs
             return np.array([]), np.array([])
        
        obs_clean = obs_arr[valid_mask]
        
        # Parse quantiles relative to the CURRENT observed window
        # (Standard practice: define flood/dry based on the calibration period statistics)
        import re
        parsed_query = query_str
        q_matches = re.findall(r'q(\d+)', query_str)
        # Unique matches to avoid replacement issues
        for q_val_str in set(q_matches): 
            q_float = float(q_val_str)
            threshold = np.percentile(obs_clean, q_float)
            # Use regex word boundary to replace q80 but not q800
            # Simplify: just replace qXX with value.
            # Warning: simple replace might be dangerous if multiple qs.
            # But q(\d+) is specific enough for now.
            parsed_query = re.sub(rf"\bq{q_val_str}\b", str(threshold), parsed_query)
        
        # Execute query using temporary DataFrame
        df_tmp = pd.DataFrame({'obs': obs_arr, 'sim': sim_arr})
        
        # [Fix] Explicitly drop NaNs before query to ensure stability
        # rows with NaN in obs are invalid for masking logic (e.g. NaN >= 100 is False/Ambiguous)
        df_tmp = df_tmp.dropna(subset=['obs'])
        
        try:
            df_filtered = df_tmp.query(parsed_query)
            return df_filtered['obs'].to_numpy(), df_filtered['sim'].to_numpy()
        except Exception as e:
            print(f"[WARN] objective_mask_query error: {e}")
            return obs_arr, sim_arr

    # 情况1：未指定 eval_station → 出口评价
    if eval_station is None:
        if not isinstance(floods_discharge, pd.Series):
            raise TypeError("未指定 eval_station 时需要出口观测 Series。")
        sim_series = pd.Series(q_outlet, index=time_index)
        idx = floods_discharge.index.intersection(sim_series.index)
        if len(idx) < 10:
            raise ValueError("出口评价重叠步数 <10")
        obs = floods_discharge.loc[idx].to_numpy()
        sim = sim_series.loc[idx].to_numpy()
        # Pre-mask full-window arrays: the water-balance penalty must see the
        # whole scored window even when the objective is masked to peaks.
        obs_full, sim_full = obs, sim

        # NEW: Apply Mask
        if objective_mask_query:
            len_before = len(obs)
            obs, sim = _apply_mask(obs, sim, objective_mask_query)
            if len(obs) < 5:
                 # Penalty for too few points
                 return 9999.0
        
        # Step5: 记录重叠/方差
        var_obs = float(np.var(obs, ddof=0))
        var_sim = float(np.var(sim, ddof=0))
        _last_evalchk_eval.update({"mode": "outlet", "overlap_steps": int(len(idx)), "var_obs": var_obs, "var_sim": var_sim})
        _m = os.environ.get('EVALCHK_MODE','all')
        _flag = True
        _m2 = os.environ.get('EVALCHK_MODE','all')
        if not hasattr(globals(), '_EVALCHK_PRINTED'):
            globals()['_EVALCHK_PRINTED'] = 0
        if _m == 'off':
            _flag = False
        elif _m == 'once' and globals()['_EVALCHK_PRINTED'] >= 1:
            _flag = False
        if _flag:
                _m2 = os.environ.get('EVALCHK_MODE','all')
                if _m2 == 'once':
                    marker = cfg.OUTPUT_DIR / '.evalchk_once.marker'
                    try:
                        if marker.exists():
                            _flag = False
                        else:
                            marker.parent.mkdir(parents=True, exist_ok=True)
                            marker.write_text('1', encoding='utf-8')
                    except Exception:
                        pass
                if _flag:
                    print(f"[EVALCHK] mode=outlet overlap_steps={len(idx)} var_obs={var_obs:.4g} var_sim={var_sim:.4g}")
                    globals()['_EVALCHK_PRINTED'] += 1
        
        # Use helper for NSE (supports weighted)
        nse = _calc_objective(obs, sim, objective_type, objective_weight_strategy)
        # Fallback check for variances if helper returned error signal (though helper returns -9999)
        if nse < -9000 and ((obs - obs.mean()) ** 2).sum() <= 0:
            raise ValueError("出口观测方差=0")

        # 流量均值偏差惩罚 (2026-07-14: pre-mask full window; optional yearly
        # mode so dry-year over-production cannot hide in the pooled mean)
        if mean_flow_penalty_lambda > 0:
            years_full = idx.year.to_numpy() if mean_flow_penalty_yearly else None
            nse = nse - _water_balance_penalty(
                sim_full, obs_full, years_full, mean_flow_penalty_lambda
            )
        if os.environ.get('EVALOPT_DEBUG') == '1' and len(_EVALOBJ_SAMPLES) < _EVALOBJ_SAMPLE_LIMIT:
            _EVALOBJ_SAMPLES.append(float(nse))
        _record_nse(nse)
        return -float(nse)

    # 情况2：指定了 eval_station，但不合法（安全双重防御）
    if not eval_is_last_layer_node:
        if eval_station is None:
            raise ValueError("内部错误: eval_station 标记不一致")
        msk_layers = geo_info[3]
        # 查找所在层
        target_layer_idx = -1
        target_names = []
        for li, layer in enumerate(msk_layers):
            names = list(layer.get('names', [])) if isinstance(layer, dict) else []
            if eval_station in names:
                target_layer_idx = li
                target_names = names
                break
        if target_layer_idx == 0:
            # 使用 q_subs (第0层输出)；确保 floods_discharge 为 Series
            if not isinstance(floods_discharge, pd.Series):
                raise TypeError("第0层单站评价要求 floods_discharge 为该站观测 Series")
            col = target_names.index(eval_station)
            col = _safe_pick_col(q_subs, col, 'layer0')
            sim_series_full = pd.Series(q_subs[:, col], index=time_index)
            obs_series = floods_discharge
            idx = obs_series.index.intersection(sim_series_full.index)
            if len(idx) < 10:
                raise ValueError("单站评价有效步数 <10 (第0层)")
            obs = obs_series.loc[idx].to_numpy()
            sim = sim_series_full.loc[idx].to_numpy()
            # Pre-mask full-window arrays for the water-balance penalty (2026-07-14)
            obs_full, sim_full = obs, sim

            if objective_mask_query:
                obs, sim = _apply_mask(obs, sim, objective_mask_query)
                if len(obs) < 5:
                     return 9999.0

            if (~np.isfinite(obs)).any() or (~np.isfinite(sim)).any():
                return 9999.0  # penalty for NaN/Inf in simulation (layer 0)

            # Use unified objective (supports nse/log_nse/kge)
            nse = _calc_objective(obs, sim, objective_type, objective_weight_strategy)
            if nse < -9000 and ((obs - obs.mean()) ** 2).sum() <= 0:
                raise ValueError("单站观测方差=0 (第0层)")
            if mean_flow_penalty_lambda > 0:
                years_full = idx.year.to_numpy() if mean_flow_penalty_yearly else None
                nse = nse - _water_balance_penalty(
                    sim_full, obs_full, years_full, mean_flow_penalty_lambda
                )
            if os.environ.get('EVALOPT_DEBUG') == '1' and len(_EVALOBJ_SAMPLES) < _EVALOBJ_SAMPLE_LIMIT:
                _EVALOBJ_SAMPLES.append(float(nse))
            _record_nse(nse)
            return -float(nse)
        else:
            raise ValueError(f"eval_station={eval_station} 不是最后一层节点且不在第0层 (发现于层 {target_layer_idx})，当前仅支持第0层或最后一层评价")

    # ---- 单站（最后一层节点）评价逻辑 ----
    if q_last_layer is None:
        raise RuntimeError("需要 q_last_layer 获得逐节点模拟输出。")
    msk_layers = geo_info[3]
    last_layer = msk_layers[-1] if msk_layers else None
    last_names = list(last_layer.get('names', [])) if isinstance(last_layer, dict) else []
    if eval_station not in last_names:
        raise ValueError(f"eval_station={eval_station} 不在最后一层节点名称集合 {last_names}")
    col = last_names.index(eval_station)
    col = _safe_pick_col(q_last_layer, col, 'last_layer')
    sim_series_full = pd.Series(q_last_layer[:, col], index=time_index)

    if not isinstance(floods_discharge, pd.Series):
        raise TypeError("单站评价要求 floods_discharge 为该站观测 Series。")

    obs_series = floods_discharge
    idx = obs_series.index.intersection(sim_series_full.index)
    if len(idx) < 10:
        raise ValueError("单站评价有效步数 <10")
    obs = obs_series.loc[idx].to_numpy()
    sim = sim_series_full.loc[idx].to_numpy()
    # Pre-mask full-window arrays for the water-balance penalty (2026-07-14):
    # this last-layer single-station branch is the one namou_kuwei calibration
    # actually takes (eval_station='kuwei'), NOT the outlet branch.
    obs_full, sim_full = obs, sim

    if objective_mask_query:
        obs, sim = _apply_mask(obs, sim, objective_mask_query)
        if len(obs) < 5:
                return 9999.0

    if (~np.isfinite(obs)).any() or (~np.isfinite(sim)).any():
        return 9999.0  # penalty for NaN/Inf in simulation
    # Step5: 单站 overlap & variance log
    var_obs = float(np.var(obs, ddof=0))
    var_sim = float(np.var(sim, ddof=0))
    _last_evalchk_eval.update({"mode": "single-station", "station": eval_station, "overlap_steps": int(len(idx)), "var_obs": var_obs, "var_sim": var_sim})
    _m = os.environ.get('EVALCHK_MODE','all')
    _flag = True
    _m2 = os.environ.get('EVALCHK_MODE','all')
    if not hasattr(globals(), '_EVALCHK_PRINTED'):
        globals()['_EVALCHK_PRINTED'] = 0
    if _m == 'off':
        _flag = False
    elif _m == 'once' and globals()['_EVALCHK_PRINTED'] >= 1:
        _flag = False
    if _flag:
            _m2 = os.environ.get('EVALCHK_MODE','all')
            if _m2 == 'once':
                marker = cfg.OUTPUT_DIR / '.evalchk_once.marker'
                try:
                    if marker.exists():
                        _flag = False
                    else:
                        marker.parent.mkdir(parents=True, exist_ok=True)
                        marker.write_text('1', encoding='utf-8')
                except Exception:
                    pass
            if _flag:
                pass
    
    # Use unified objective (supports nse/log_nse/kge)
    nse = _calc_objective(obs, sim, objective_type, objective_weight_strategy)
    if nse < -9000 and ((obs - obs.mean()) ** 2).sum() <= 0:
        raise ValueError("单站观测方差=0")
    # 流量均值偏差惩罚 (2026-07-14: pre-mask full window; optional yearly mode)
    if mean_flow_penalty_lambda > 0:
        years_full = idx.year.to_numpy() if mean_flow_penalty_yearly else None
        nse = nse - _water_balance_penalty(
            sim_full, obs_full, years_full, mean_flow_penalty_lambda
        )
    if os.environ.get('EVALOPT_DEBUG') == '1' and len(_EVALOBJ_SAMPLES) < _EVALOBJ_SAMPLE_LIMIT:
        _EVALOBJ_SAMPLES.append(float(nse))
    _record_nse(nse)
    return -float(nse)


# ---- initial_params → DE seed vector ----
def _try_build_seed_vector(cfg, calib_cfg, bounds):
    """
    Try to build a DE seed vector from cfg.INLINE_CALIB['initial_params'].

    This loads the best_params YAML and maps each calibrated parameter
    to its position in the DE vector. For MSK K/X parameters, if the
    YAML only has c0/c1, reverse-computes K and X from the Muskingum
    coefficient equations.

    Returns the seed vector (ndarray) or None if not applicable.
    """
    inline_calib = getattr(cfg, 'INLINE_CALIB', None)
    if not isinstance(inline_calib, dict):
        return None
    ip_path_str = inline_calib.get('initial_params')
    if not ip_path_str:
        return None

    ip_path = Path(ip_path_str)
    if not ip_path.is_absolute():
        ip_path = Path.cwd() / ip_path
    if not ip_path.exists():
        print(f"[InitParams] WARNING: file not found: {ip_path}")
        return None

    import yaml
    with open(ip_path, 'r', encoding='utf-8') as f:
        ip_data = yaml.safe_load(f)

    # Unwrap single basin key (e.g., {namou_kuwei: {xaj_params: ...}} → {xaj_params: ...})
    if isinstance(ip_data, dict) and len(ip_data) == 1:
        first_val = next(iter(ip_data.values()))
        if isinstance(first_val, dict):
            ip_data = first_val

    index_map = calib_cfg.get('index_map', [])
    if not index_map:
        return None

    vec = np.full(len(bounds), np.nan)
    n_found = 0

    # Pre-extract msk_layers c0/c1 for K/X reverse computation
    msk_layers_data = ip_data.get('msk_layers', [])

    for i, (p_cfg, idx_info) in enumerate(index_map):
        if i >= len(bounds):
            break
        path = p_cfg.get('path', [])
        lo, hi = bounds[i]

        val = None
        # Case 1: xaj_params / pdd_params (direct path lookup)
        if len(path) >= 2 and path[0] in ('xaj_params', 'pdd_params'):
            section = ip_data.get(path[0], {})
            key = path[-1]
            if key in section:
                raw = section[key]
                if isinstance(raw, (list, np.ndarray)):
                    raw = raw[0] if len(raw) > 0 else None
                val = raw

        # Case 2: msk_layers K/X → reverse from c0/c1
        elif len(path) >= 2 and path[0] == 'msk_layers':
            last_key = path[-1]
            layer_idx = 0
            if isinstance(idx_info, (list, tuple)) and len(idx_info) >= 1:
                layer_idx = idx_info[0]
            if layer_idx < len(msk_layers_data):
                layer_data = msk_layers_data[layer_idx]
                if last_key in ('K', 'X'):
                    # Reverse-compute from c0, c1 using Muskingum equations
                    c0_raw = layer_data.get('c0')
                    c1_raw = layer_data.get('c1')
                    if c0_raw is not None and c1_raw is not None:
                        c0_v = c0_raw[0] if isinstance(c0_raw, (list, np.ndarray)) else float(c0_raw)
                        c1_v = c1_raw[0] if isinstance(c1_raw, (list, np.ndarray)) else float(c1_raw)
                        dt_hours = ip_data.get('xaj_params', {}).get('dt', 1.0)
                        if dt_hours < 1.0:
                            dt_hours = dt_hours * 24  # convert fraction-of-day to hours
                        denom = c0_v + c1_v
                        if abs(denom) > 1e-12:
                            K_rev = dt_hours * (1.0 - c0_v) / denom
                            X_rev = (c1_v - c0_v) / (2.0 * (1.0 - c0_v)) if abs(1.0 - c0_v) > 1e-12 else 0.2
                            if last_key == 'K':
                                val = K_rev
                            else:
                                val = X_rev
                elif last_key in layer_data:
                    raw = layer_data[last_key]
                    if isinstance(raw, (list, np.ndarray)):
                        node_idx = 0
                        if isinstance(idx_info, (list, tuple)) and len(idx_info) >= 2:
                            node_idx = idx_info[1]
                        raw = raw[node_idx] if node_idx < len(raw) else raw[0]
                    val = raw

        if val is not None:
            vec[i] = np.clip(float(val), lo, hi)
            n_found += 1

    # Fill any remaining NaN with bound midpoints
    nan_mask = np.isnan(vec)
    n_nan = int(nan_mask.sum())
    if n_nan > 0:
        for j in range(len(vec)):
            if np.isnan(vec[j]):
                lo, hi = bounds[j]
                vec[j] = (lo + hi) / 2.0
        print(f"[InitParams] {n_nan}/{len(vec)} params not found in YAML, using midpoints")

    print(f"[InitParams] Loaded {n_found}/{len(vec)} params from {ip_path.name}")
    return vec


def _load_seed_vector(yaml_path: str, calib_cfg: dict, n_basins: int) -> np.ndarray | None:
    """Load a best-params YAML and convert to parameter vector for warm-starting CMA-ES."""
    import yaml
    p = Path(yaml_path)
    if not p.is_absolute():
        p = OptimizationConfig.PROJECT_ROOT / p
    if not p.exists():
        print(f"[WARN] seed_from file not found: {p}, using default x0")
        return None
    try:
        with open(p) as f:
            data = yaml.safe_load(f)
        # Extract the basin params dict (first key is basin name)
        basin_key = next(iter(data))
        param_dict = data[basin_key]
        # Rebuild vector from index_map
        if 'index_map' not in calib_cfg:
            print("[WARN] seed_from requires index_map in calib_cfg, skipping")
            return None
        vec = np.zeros(len(calib_cfg['index_map']))
        for i, (spec, _idx) in enumerate(calib_cfg['index_map']):
            path = spec['path']
            # Navigate param_dict by path
            val = param_dict
            for key in path:
                if key == '*':
                    break
                if isinstance(val, dict):
                    val = val.get(key, spec.get('initial', (spec['bounds'][0] + spec['bounds'][1]) / 2))
                else:
                    val = spec.get('initial', (spec['bounds'][0] + spec['bounds'][1]) / 2)
                    break
            if isinstance(val, (int, float)):
                vec[i] = float(val)
            else:
                vec[i] = spec.get('initial', (spec['bounds'][0] + spec['bounds'][1]) / 2)
        print(f"[CMA-ES] Loaded seed from {p.name}, vector dim={len(vec)}")
        return vec
    except Exception as e:
        print(f"[WARN] Failed to load seed_from {p}: {e}")
        return None


def optimize_parameters_distributed_eval(
    *,
    meteo_inputs: tuple,
    external_flow_inputs: tuple,
    time_index: pd.DatetimeIndex,
    floods_discharge: Union[pd.Series, pd.DataFrame],
    default_params: Dict[str, Any],
    init_cond: Dict[str, Any],
    calib_cfg: Dict[str, Any],
    geo_info: tuple,
    cfg: OptimizationConfig,
    eval_station: str | None,
    eval_is_last_layer_node: bool,
    broadcaster: Broadcaster | None = None,
) -> Tuple[Dict[str, Any], float]:
    """差分进化优化（eval 单站版本）。
    broadcaster 可注入，实现“参数广播/结构构造”与“优化器”解耦；
    None 时使用 make_default_broadcaster()。
    """
    grid2sub, sub_area, C_mats, msk_layers = geo_info
    Ns = sub_area.shape[0]
    N_layer = len(msk_layers)
    calib_cfg['n_basins'] = Ns

    # 注入/默认广播器
    used_broadcaster = broadcaster or make_default_broadcaster()

    # ---------- Step2: 构建 & 输出率定映射 (基于 index_map) ----------
    def _build_calib_map(calib_cfg_local, Ns_local, N_layer_local):
        m = {
            "vector_size": int(calib_cfg_local.get("vector_size", 0)),
            "active_count": 0,
            "msk_layers": {},  # 每层: list[{param,node}] (layer_node 级别)
            "xaj": {},         # basin 级聚合计数
            "pdd": {},         # basin 级聚合计数
        }
        idx_map = calib_cfg_local.get("index_map")
        if isinstance(idx_map, list):
            active_list = []
            for spec, idx in idx_map:
                path = spec.get("path", [])
                lvl = spec.get("level", "basin")
                param_name = path[-1] if path else "?"
                if lvl == "layer_node" and isinstance(idx, tuple):
                    layer_i, node_j = idx
                    layer_key = str(layer_i)
                    m["msk_layers"].setdefault(layer_key, []).append({
                        "param": param_name,
                        "node": int(node_j)
                    })
                elif path and path[0] == "xaj_params":
                    m["xaj"].setdefault(param_name, 0)
                    m["xaj"][param_name] += 1
                elif path and path[0] == "pdd_params":
                    m["pdd"].setdefault(param_name, 0)
                    m["pdd"][param_name] += 1
                active_list.append((param_name, lvl, idx if not isinstance(idx, np.ndarray) else "bulk"))
            m["active_list"] = active_list  # type: ignore  # 动态构造: list 便于调试输出
            m["active_count"] = len(active_list)
        else:
            m["legacy_mode"] = True
        return m

    def _write_report(out_dir, *, calib_map=None, best_nse=None, skip_reason=None):
        try:
            os.makedirs(out_dir, exist_ok=True)
            rep = {
                "mode": "eval",
                "eval_station": eval_station,
                "skip_reason": skip_reason,
                "best_nse": best_nse,
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                "calibration_mapping": calib_map,
                "evalchk": _last_evalchk_eval if _last_evalchk_eval else None,
            }
            with open(out_dir / "calibration_report.json", "w", encoding="utf-8") as fp:
                json.dump(rep, fp, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[WARN] 写 calibration_report.json 失败: {e}")

    # selector=none 时直接跳过（保持与原 optimize 一致的行为语义）
    if getattr(cfg, 'CALIB_NODE_SELECTOR', None) == 'none':
        print("[CALMAP] CALIB_NODE_SELECTOR=none → 跳过差分进化 (eval 模式)。")
        try:
            os.makedirs(cfg.OUTPUT_DIR, exist_ok=True)
            with open(cfg.OUTPUT_DIR / "skipped_optimization.flag", "w", encoding="utf-8") as f:
                f.write(time.strftime("%Y-%m-%d %H:%M:%S") + " selector-none\n")
        except Exception:
            pass
        _write_report(cfg.OUTPUT_DIR, calib_map=None, best_nse=None, skip_reason="selector-none")
        return default_params, float('nan')

    calib_map = _build_calib_map(calib_cfg, Ns, N_layer)
    bounds = prepare_bounds(calib_cfg, Ns, N_layer)
    if len(bounds) != calib_map.get("active_count", len(bounds)):
        print(f"[CALMAP] bounds={len(bounds)} active={calib_map.get('active_count')} vector_size={calib_cfg.get('vector_size')} (legacy={calib_map.get('legacy_mode', False)})")
    else:
        print(f"[CALMAP] active_params={calib_map.get('active_count', len(bounds))} vector_size={calib_cfg.get('vector_size')} bounds={len(bounds)}")
    if os.environ.get('EVALOPT_DEBUG') == '1':
        zero_span = [(i, lo, hi) for i,(lo,hi) in enumerate(bounds) if hi - lo == 0]
        if zero_span:
            print(f"[EvalOptDebug] zero_width_bounds={len(zero_span)} indices={[i for i,_,_ in zero_span][:10]} (show first 10)")
        else:
            # 打印前5个跨度概要
            spans = [hi-lo for (lo,hi) in bounds]
            print(f"[EvalOptDebug] first_spans={[round(s,4) for s in spans[:5]]} median_span={np.median(spans):.4g}")

    try:
        out_dir = cfg.OUTPUT_DIR
        os.makedirs(out_dir, exist_ok=True)
        with open(out_dir / "calibration_mapping.json", "w", encoding="utf-8") as fp:
            json.dump(calib_map, fp, ensure_ascii=False, indent=2)
    except Exception as _e:  # noqa: BLE001
        print(f"[WARN] 写 calibration_mapping.json 失败: {_e}")
    constraints = make_combined_constraints(
        calib_cfg=calib_cfg,
        n_basins=Ns,
        n_layers=N_layer,
        c01_sum_ub=0.8,
    )

    iteration_count, actual_iter, init_pop = handle_resume(cfg, calib_cfg, Ns)
    if isinstance(init_pop, tuple) and init_pop[0] == "completed":
        best_params = init_pop[1]
        return best_params, -9999.0

    # ---- Inject initial_params as DE seed if no checkpoint resume ----
    if isinstance(init_pop, str) and init_pop == "latinhypercube" and len(bounds) > 0:
        _seed_vec = _try_build_seed_vector(cfg, calib_cfg, bounds)
        if _seed_vec is not None:
            pop_size = max(2, int(getattr(cfg, 'POP_SIZE', 10)))
            init_arr = np.empty((pop_size, len(bounds)), dtype=float)
            init_arr[0] = _seed_vec
            for r in range(1, pop_size):
                for j, (lo, hi) in enumerate(bounds):
                    init_arr[r, j] = lo + np.random.rand() * (hi - lo)
            init_pop = init_arr
            print(f'[InitParams] Seeded DE population row 0 with initial_params')

    # ---------- Step6: 无可率定参数 -> 跳过 DE ----------
    if len(bounds) == 0:
        print("[CALMAP] 无可率定参数(bounds=0)，跳过差分进化，返回默认参数。")
        try:
            with open(cfg.OUTPUT_DIR / "skipped_optimization.flag", "w", encoding="utf-8") as f:
                f.write(time.strftime("%Y-%m-%d %H:%M:%S") + " no-params\n")
        except Exception:  # noqa: BLE001
            pass
        _write_report(cfg.OUTPUT_DIR, calib_map=calib_map, best_nse=None, skip_reason="empty-bounds")
        return default_params, float('nan')

    # --- 流量均值偏差惩罚配置 ---
    _mfp = getattr(cfg, 'MEAN_FLOW_PENALTY', 0.0)
    _mfp_yearly = bool(getattr(cfg, 'MEAN_FLOW_PENALTY_YEARLY', False))
    _obs_mean = None
    if _mfp > 0 and isinstance(floods_discharge, pd.Series):
        _obs_mean = float(floods_discharge.mean())
        print(f"[EvalOpt] mean_flow_penalty={_mfp}, yearly={_mfp_yearly}, obs_mean={_obs_mean:.4g}")

    # --- Objective Mask ---
    _obj_mask = None
    # Method 1: from calib_cfg['optimization']['objective_mask']
    if 'optimization' in calib_cfg and isinstance(calib_cfg['optimization'], dict):
        _obj_mask = calib_cfg['optimization'].get('objective_mask')
    # Method 2: from cfg attribute (if passed via CLI/Config object)
    if not _obj_mask and hasattr(cfg, 'OBJECTIVE_MASK'):
        _obj_mask = cfg.OBJECTIVE_MASK

    if _obj_mask:
        print(f"[EvalOpt] Objective Mask Active: {_obj_mask}")
# --- Objective Weight Strategy ---
    _obj_weight = None
    # Method 1: from calib_cfg['optimization']['objective_weight']
    if 'optimization' in calib_cfg and isinstance(calib_cfg['optimization'], dict):
        _obj_weight = calib_cfg['optimization'].get('objective_weight')
    # Method 2: from cfg attribute (if passed via CLI/Config object)
    if not _obj_weight and hasattr(cfg, 'OBJECTIVE_WEIGHT'):
        _obj_weight = cfg.OBJECTIVE_WEIGHT

    if _obj_weight:
        print(f"[EvalOpt] Objective Weight Strategy: {_obj_weight}")

    # --- Objective Type (nse / log_nse / kge) ---
    _obj_type = getattr(cfg, 'OBJECTIVE_TYPE', 'nse') or 'nse'
    # Also check calib_cfg for inline override
    if 'optimization' in calib_cfg and isinstance(calib_cfg['optimization'], dict):
        _ot = calib_cfg['optimization'].get('objective')
        if _ot:
            _obj_type = str(_ot).strip().lower()
    if _obj_type != 'nse':
        print(f"[EvalOpt] Objective Type: {_obj_type}")

    de_obj = partial(
        _objective_function_eval,
        meteo_inputs=meteo_inputs,
        external_flow_inputs=external_flow_inputs,
        objective_weight_strategy=_obj_weight,
        objective_type=_obj_type,
        time_index=time_index,
        floods_discharge=floods_discharge,
        model_tpl=default_params,
        init_cond=init_cond,
        calib_cfg=calib_cfg,
        geo_info=geo_info,
        cfg=cfg,
        eval_station=eval_station,
        eval_is_last_layer_node=eval_is_last_layer_node,
        broadcaster=used_broadcaster,
        mean_flow_penalty_lambda=_mfp,
        mean_flow_penalty_yearly=_mfp_yearly,
        obs_mean=_obs_mean,
        objective_mask_query=_obj_mask,
    )

    # ---- 预检查：单进程短迭代预热 (仅在并行且未恢复时执行) ----
    # 已按需求禁用预检查 (可通过设置 EVALOPT_PRECHECK_FORCE=1 再启用)
    precheck_enabled = os.environ.get('EVALOPT_PRECHECK_FORCE','0') == '1'
    precheck_result = None
    force_serial_main = False
    if False and precheck_enabled:  # 显式关闭
        pass  # 预检查代码已禁用
    # 并行 shared_stats 封装 (只有 workers>1 才需要，且未强制降级)
    shared_stats = None
    used_obj = de_obj
    main_workers = getattr(cfg, 'WORKERS', 1)
    if force_serial_main:
        main_workers = 1
    if main_workers != 1:
        try:
            from multiprocessing import Manager
            _mgr = Manager()
            shared_stats = _mgr.dict()
            shared_stats['last'] = None
            shared_stats['best'] = None
            used_obj = _fpartial(_parallel_wrapper, base_obj=de_obj, shared_stats=shared_stats)
            print("[EvalOpt] 启用并行共享 NSE 跟踪 (picklable wrapper)")
        except Exception as e:
            print(f"[EvalOpt] 并行初始化失败, 回退单进程: {e}")
            main_workers = 1
            used_obj = de_obj
            shared_stats = None

    # 若有预检查结果且主运行允许自定义 init_pop，则构造带预检查 best 个体的初始种群
    if precheck_result is not None and not (isinstance(init_pop, np.ndarray)) and len(bounds) > 0:
        try:
            vec_len = len(bounds)
            popsize_main = getattr(cfg, 'POP_SIZE', 10)
            popsize_main = max(2, int(popsize_main))
            init_arr = np.empty((popsize_main, vec_len), dtype=float)
            # 第一行：预检查最优
            init_arr[0] = precheck_result.x
            # 其余：随机均匀采样
            for r in range(1, popsize_main):
                for j,(lo,hi) in enumerate(bounds):
                    if hi <= lo:
                        init_arr[r,j] = lo
                    else:
                        init_arr[r,j] = lo + np.random.rand() * (hi - lo)
            init_pop = init_arr
            print('[EvalOpt] 已将预检查最优解注入主迭代初始种群。')
        except Exception as e:
            print(f"[EvalOpt] 构造预检查初始种群失败: {e}")

    # Step3: 可选快速敏感性 (用未包装的 de_obj 以避免多进程开销)
    if os.environ.get("DEBUG_PARAM_SENS") == "1" and len(bounds) > 0:
        print("[SENS] (eval) 开始快速参数敏感性 (±1% span, 前3个参数)")
        mids = np.array([(lo + hi) / 2 for lo, hi in bounds], dtype=float)
        try:
            base_obj_val = de_obj(mids)
            base_nse = -float(base_obj_val)
            active_list = calib_map.get("active_list") if isinstance(calib_map, dict) else None
            for i in range(min(3, len(bounds))):
                lo, hi = bounds[i]
                span = hi - lo
                if span <= 0:
                    continue
                delta = 0.01 * span
                name = None
                if active_list and i < len(active_list):
                    name = active_list[i][0]
                name = name or f"p{i}"
                for sign in (+1, -1):
                    vec = mids.copy()
                    vec[i] = np.clip(vec[i] + sign * delta, lo, hi)
                    obj_v = de_obj(vec)
                    nse = -float(obj_v)
                    print(f"[SENS] (eval) idx={i} name={name} sign={'+ ' if sign>0 else '-'} delta={delta:.3g} baseNSE={base_nse:.4g} newNSE={nse:.4f} dNSE={nse-base_nse:.3g}")
        except Exception as e:
            print(f"[SENS] (eval) 敏感性计算失败: {e}")

    algorithm = getattr(cfg, 'ALGORITHM', 'de').lower()

    if algorithm == 'cmaes':
        # Load initial seed if configured
        x0 = None
        seed_path = getattr(cfg, 'SEED_FROM', None)
        if seed_path:
            x0 = _load_seed_vector(seed_path, calib_cfg, Ns)

        sigma0 = getattr(cfg, 'CMAES_SIGMA0', 0.3)

        def _cmaes_callback(xbest, fbest, iteration):
            best_nse = -float(fbest)
            print(f"[CMA-ES] Iter={iteration} BestNSE={best_nse:.4f}")
            try:
                _checkpoint_cb_eval(
                    xbest, convergence=fbest, cfg=cfg, shared_stats=shared_stats
                )
            except Exception:
                pass

        result = run_cmaes(
            used_obj,
            bounds,
            maxiter=actual_iter,
            popsize=cfg.POP_SIZE if cfg.POP_SIZE != 100 else None,
            x0=x0,
            sigma0=sigma0,
            constraints=constraints,
            callback=_cmaes_callback,
        )
    elif algorithm == 'optuna':
        n_trials = getattr(cfg, 'OPTUNA_N_TRIALS', 200)

        def _optuna_callback(xbest, fbest, trial_num):
            best_nse = -float(fbest)
            if trial_num % 10 == 0 or trial_num <= 5:
                print(f"[Optuna] Trial={trial_num} BestNSE={best_nse:.4f}")
            try:
                _checkpoint_cb_eval(
                    xbest, convergence=fbest, cfg=cfg, shared_stats=shared_stats
                )
            except Exception:
                pass

        result = run_optuna(
            used_obj,
            bounds,
            n_trials=n_trials,
            constraints=constraints,
            callback=_optuna_callback,
        )
    else:
        result = run_de(
            used_obj,
            bounds,
            constraints=constraints,  # type: ignore[arg-type]
            strategy="best1bin",
            maxiter=actual_iter,
            popsize=cfg.POP_SIZE,
            workers=main_workers,
            updating="deferred",
            init=init_pop,
            callback=partial(_checkpoint_cb_eval, cfg=cfg, shared_stats=shared_stats),
            disp=False,
            polish=False,
        )

    best_params = vector_to_params(result.x, calib_cfg, Ns)
    best_nse = -float(result.fun)
    try:
        _record_nse(best_nse)
    except Exception:
        pass
    _write_report(cfg.OUTPUT_DIR, calib_map=calib_map, best_nse=best_nse, skip_reason=None)
    return best_params, best_nse

