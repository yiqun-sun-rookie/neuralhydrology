"""State-space handles for parameter optimization.

This module provides state-space handles for parameter optimization workflows.
These are NOT DA (Data Assimilation) utilities - they are optimization components.

For DA utilities, see experiments.streaming_da.ylx.

Exports
-------
- build_full_state_handles: factory producing state_transition_function, observation_function,
  init_state_struct, state_layout, flatten_state, unflatten_state.
- get_da_handles: State-space handles adapter exposing f/h/step_and_measure in structured and flat forms.
  Note: Despite the name "da_handles", this is for optimization workflows, not DA.
"""
from .handles_factory import build_full_state_handles  # noqa: F401
from .handles_adapter import get_da_handles  # noqa: F401

__all__ = [
    'build_full_state_handles',
    'get_da_handles',
]
















