"""optimizer_facade — pluggable optimizer backends.

Supports: DE (scipy), CMA-ES (pycma), Optuna-TPE (optuna).
"""
from __future__ import annotations
from typing import Any, Callable, Iterable
import numpy as np
from scipy.optimize import differential_evolution, OptimizeResult, NonlinearConstraint

def run_de(
    objective: Callable[[Iterable[float]], float],
    bounds: list[tuple[float, float]] | tuple,
    *,
    constraints: Any | None = None,
    strategy: str = "best1bin",
    maxiter: int = 100,
    popsize: int = 10,
    workers: int = 1,
    updating: str = "deferred",
    init: str | Any = "latinhypercube",
    callback: Any | None = None,
    disp: bool = False,
    polish: bool = False,
    tol: float | None = None,
):
    _constraints = constraints if constraints is not None else ()
    _kwargs = dict(
        constraints=_constraints,
        strategy=strategy,
        maxiter=maxiter,
        popsize=popsize,
        workers=workers,
        updating=updating,
        init=init,
        callback=callback,
        disp=disp,
        polish=polish,
    )
    if tol is not None:
        _kwargs["tol"] = tol
    return differential_evolution(objective, bounds, **_kwargs)


def run_cmaes(
    objective: Callable[[Iterable[float]], float],
    bounds: list[tuple[float, float]],
    *,
    maxiter: int = 200,
    popsize: int | None = None,
    x0: np.ndarray | list | None = None,
    sigma0: float = 0.3,
    constraints: list[NonlinearConstraint] | None = None,
    callback: Any | None = None,
    seed: int | None = None,
) -> OptimizeResult:
    """CMA-ES optimizer via pycma.

    Args:
        objective: f(x) -> float, to minimize.
        bounds: [(lo, hi), ...] per dimension.
        maxiter: Maximum number of CMA-ES generations.
        popsize: Population size (None = pycma default: 4+3*ln(N)).
        x0: Initial guess. If None, uses midpoint of bounds.
        sigma0: Initial step size as fraction of average bound range.
        constraints: List of scipy NonlinearConstraint. Handled via penalty.
        callback: Called each iteration with (best_x, best_f, iteration).
        seed: Random seed for reproducibility.

    Returns:
        scipy.optimize.OptimizeResult with .x, .fun, .nfev, .nit, .success
    """
    import cma

    bounds_arr = np.array(bounds)
    lo = bounds_arr[:, 0]
    hi = bounds_arr[:, 1]

    # Initial point
    if x0 is None:
        x0_vec = (lo + hi) / 2.0
    else:
        x0_vec = np.asarray(x0, dtype=float)

    # Sigma: scale by average range
    avg_range = np.mean(hi - lo)
    sigma_abs = sigma0 * avg_range

    # Build penalized objective if constraints present
    if constraints:
        raw_obj = objective
        objective = _make_penalized(raw_obj, constraints)

    # CMA-ES options
    opts = {
        'bounds': [lo.tolist(), hi.tolist()],
        'maxiter': maxiter,
        'verbose': -9,
        'tolfun': 1e-11,
        'tolx': 1e-11,
    }
    if popsize is not None:
        opts['popsize'] = popsize
    if seed is not None:
        opts['seed'] = seed

    es = cma.CMAEvolutionStrategy(x0_vec.tolist(), sigma_abs, opts)

    iteration = 0
    while not es.stop():
        solutions = es.ask()
        fitnesses = [objective(x) for x in solutions]
        es.tell(solutions, fitnesses)
        iteration += 1

        if callback is not None:
            try:
                callback(es.result.xbest, es.result.fbest, iteration)
            except Exception:
                pass

    res = es.result
    return OptimizeResult(
        x=np.array(res.xbest),
        fun=float(res.fbest),
        nfev=int(res.evaluations),
        nit=int(res.iterations),
        success=res.fbest < 1e6,
        message=str(es.stop()),
    )


def _make_penalized(
    raw_objective: Callable,
    constraints: list[NonlinearConstraint],
    penalty_weight: float = 1e4,
) -> Callable:
    """Wrap objective with quadratic penalty for constraint violations."""
    def penalized(x):
        val = raw_objective(x)
        total_penalty = 0.0
        for con in constraints:
            g = np.asarray(con.fun(x), dtype=float).ravel()
            lb = np.asarray(con.lb, dtype=float).ravel()
            ub = np.asarray(con.ub, dtype=float).ravel()
            lower_viol = np.maximum(0.0, lb - g)
            upper_viol = np.maximum(0.0, g - ub)
            total_penalty += np.sum(lower_viol ** 2) + np.sum(upper_viol ** 2)
        return val + penalty_weight * total_penalty
    return penalized


def run_optuna(
    objective: Callable[[Iterable[float]], float],
    bounds: list[tuple[float, float]],
    *,
    n_trials: int = 200,
    constraints: list[NonlinearConstraint] | None = None,
    callback: Any | None = None,
    seed: int | None = None,
) -> OptimizeResult:
    """Optuna TPE optimizer.

    Args:
        objective: f(x) -> float, to minimize. Takes a numpy-like array.
        bounds: [(lo, hi), ...] per dimension.
        n_trials: Number of Optuna trials.
        constraints: List of scipy NonlinearConstraint. Handled via penalty.
        callback: Called each trial with (best_x, best_f, trial_number).
        seed: Random seed for TPE sampler reproducibility.

    Returns:
        scipy.optimize.OptimizeResult with .x, .fun, .nfev, .nit, .success
    """
    import optuna

    optuna.logging.set_verbosity(optuna.logging.WARNING)

    ndim = len(bounds)

    # Build penalized objective if constraints present
    raw_obj = objective
    if constraints:
        raw_obj = _make_penalized(objective, constraints)

    best_x = None
    best_f = float('inf')
    trial_count = 0

    def optuna_objective(trial):
        nonlocal best_x, best_f, trial_count
        x = np.array([
            trial.suggest_float(f"x{i}", bounds[i][0], bounds[i][1])
            for i in range(ndim)
        ])
        val = float(raw_obj(x))
        trial_count += 1

        if val < best_f:
            best_f = val
            best_x = x.copy()

        if callback is not None:
            try:
                callback(best_x, best_f, trial_count)
            except Exception:
                pass

        return val

    sampler = optuna.samplers.TPESampler(seed=seed)
    study = optuna.create_study(sampler=sampler, direction="minimize")
    study.optimize(optuna_objective, n_trials=n_trials, show_progress_bar=False)

    # Extract best
    best_trial = study.best_trial
    result_x = np.array([best_trial.params[f"x{i}"] for i in range(ndim)])

    return OptimizeResult(
        x=result_x,
        fun=float(best_trial.value),
        nfev=len(study.trials),
        nit=len(study.trials),
        success=True,
        message=f"Optuna TPE completed {len(study.trials)} trials",
    )

