"""Forecast meteorological data provider framework.

Provides an abstract interface for fetching forecast precipitation/temperature
from various sources (NWP models, satellite products, local files).
"""
from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


@dataclass
class ForecastMeteoResult:
    """Standardized output from any forecast provider."""
    rain: np.ndarray          # (forecast_steps, Ng) mm per timestep
    temp: np.ndarray          # (forecast_steps, Ng) degC
    snow: np.ndarray          # (forecast_steps, Ng) mm per timestep
    pet: np.ndarray           # (forecast_steps, Ng) mm per timestep
    time_index: pd.DatetimeIndex  # (forecast_steps,)
    source: str               # e.g. "ecmwf_ifs", "gfs"
    metadata: dict = field(default_factory=dict)


class ForecastMeteoProvider(ABC):
    """Abstract base for all forecast meteo data sources."""

    @abstractmethod
    def fetch(
        self,
        coords: list[tuple[float, float]],
        start: datetime,
        forecast_steps: int,
        dt_hours: float,
    ) -> ForecastMeteoResult:
        ...


class FallbackProvider(ForecastMeteoProvider):
    """Try primary provider, fall back to secondary on failure."""

    def __init__(self, primary: ForecastMeteoProvider, fallback: ForecastMeteoProvider):
        self.primary = primary
        self.fallback = fallback

    def fetch(self, coords, start, forecast_steps, dt_hours) -> ForecastMeteoResult:
        try:
            result = self.primary.fetch(coords, start, forecast_steps, dt_hours)
            return result
        except Exception as exc:
            logger.warning(
                "Primary provider failed (%s), using fallback: %s",
                type(self.primary).__name__, exc,
            )
            return self.fallback.fetch(coords, start, forecast_steps, dt_hours)


# --- Provider Registry ---
_providers: dict[str, Callable[..., ForecastMeteoProvider]] = {}


def register_provider(name: str, factory: Callable[..., ForecastMeteoProvider]) -> None:
    _providers[name] = factory


def get_provider(name: str, **kwargs) -> ForecastMeteoProvider:
    if name not in _providers:
        raise ValueError(
            f"Unknown forecast provider: '{name}'. Available: {list(_providers.keys())}"
        )
    return _providers[name](**kwargs)


def list_providers() -> list[str]:
    return list(_providers.keys())


# --- Register built-in providers ---
def _register_defaults():
    from src.runtime.semi_distributed.core.providers.legacy import (
        PersistenceProvider,
        ZeroRainProvider,
    )
    register_provider("persistence", PersistenceProvider)
    register_provider("zero_rain", ZeroRainProvider)
    try:
        from src.runtime.semi_distributed.core.providers.open_meteo import OpenMeteoProvider
        register_provider("ecmwf_ifs", lambda **kw: OpenMeteoProvider(model="ecmwf_ifs", **kw))
        register_provider("gfs", lambda **kw: OpenMeteoProvider(model="gfs", **kw))

        def _auto_provider(**kw):
            return FallbackProvider(
                OpenMeteoProvider(model="ecmwf_ifs", **kw),
                FallbackProvider(
                    OpenMeteoProvider(model="gfs", **kw),
                    PersistenceProvider(),
                ),
            )
        register_provider("auto", _auto_provider)
    except ImportError:
        pass


_register_defaults()
