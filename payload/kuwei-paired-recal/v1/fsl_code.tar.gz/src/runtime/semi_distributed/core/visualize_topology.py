"""
Quick visualization helpers for Muskingum layers (msk_layers) and connection matrices.

Usage (example):

from src.runtime.semi_distributed.core.visualize_topology import (
    plot_connection_matrix, plot_msk_layers_summary
)

plot_connection_matrix(connection_matrices[0], title="Layer 0 connection matrix")
plot_msk_layers_summary(msk_layers)

These helpers are lightweight and safe to import without heavy deps beyond matplotlib & numpy.
"""
from __future__ import annotations
from typing import List, Tuple, Optional, Sequence, Union, Dict, Any
import numpy as np
import matplotlib.pyplot as plt

Array = np.ndarray


def _as_np(a) -> Array:
    return np.asarray(a)


def plot_connection_matrix(
    conn: Array,
    title: str = "Connection matrix",
    cmap: str = "viridis",
    x_labels: Optional[Sequence[str]] = None,
    y_labels: Optional[Sequence[str]] = None,
) -> None:
    """
    Visualize a connection/transition matrix (e.g., reach routing matrix) as heatmap.
    - conn: 2D array-like, shape (N, N) or (N_out, N_in)
    """
    C = _as_np(conn)
    if C.ndim != 2:
        raise ValueError("conn must be 2D")
    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(C, aspect="auto", interpolation="nearest", cmap=cmap)
    ax.set_title(title)
    ax.set_xlabel("in (upstream)")
    ax.set_ylabel("out (downstream)")
    # axis labels
    if x_labels is not None and len(x_labels) == C.shape[1]:
        ax.set_xticks(range(C.shape[1]))
        ax.set_xticklabels(list(x_labels), rotation=45, ha="right")
    if y_labels is not None and len(y_labels) == C.shape[0]:
        ax.set_yticks(range(C.shape[0]))
        ax.set_yticklabels(list(y_labels))
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="weight")
    # simple sparsity stat
    nz = np.count_nonzero(np.abs(C) > 1e-12)
    ax.text(0.01, 0.99, f"nonzeros={nz}/{C.size}", transform=ax.transAxes,
            va="top", ha="left", fontsize=9, color="w",
            bbox=dict(facecolor="k", alpha=0.3, pad=2))
    # optional arrows for strong links
    try:
        thresh = np.nanmax(np.abs(C)) * 0.8 if np.isfinite(C).any() else 1.0
        rows, cols = np.where(C >= thresh)
        for r, c in zip(rows, cols):
            ax.plot([c, c], [r-0.4, r+0.4], color="w", lw=1.5, alpha=0.8)
    except Exception:
        pass
    plt.tight_layout()
    plt.show()


def plot_msk_layers_summary(
    msk_layers: Sequence[Union[Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray], Dict[str, Any]]],
    titles: Optional[List[str]] = None
) -> None:
    """
    Summarize Muskingum layer parameters:
    - Accepts either tuple form (index, c0, c1, c2, n_sub) or dict form
      with keys {index, c0?, c1?, n_sub?}. If c0/c1 missing, only show layer size.
    """
    L = len(msk_layers)
    if L == 0:
        raise ValueError("msk_layers is empty")

    ncols = 4
    nrows = L
    fig, axes = plt.subplots(nrows=nrows, ncols=ncols, figsize=(4*ncols, 3*nrows))
    if nrows == 1:
        axes = np.atleast_2d(axes)

    def _extract(layer):
        if isinstance(layer, (tuple, list)) and len(layer) == 5:
            idx, c0, c1, c2, n_sub = layer
            return _as_np(idx), _as_np(c0), _as_np(c1), _as_np(c2), _as_np(n_sub)
        if isinstance(layer, dict):
            idx = _as_np(layer.get("index", []))
            c0 = layer.get("c0", None)
            c1 = layer.get("c1", None)
            n_sub = layer.get("n_sub", None)
            c0 = _as_np(c0) if c0 is not None else None
            c1 = _as_np(c1) if c1 is not None else None
            n_sub = _as_np(n_sub) if n_sub is not None else None
            c2 = (1.0 - c0 - c1) if (c0 is not None and c1 is not None) else None
            return _as_np(idx), c0, c1, c2, n_sub
        # Fallback: treat as empty
        return _as_np([]), None, None, None, None

    for i, layer in enumerate(msk_layers):
        idx, c0, c1, c2, n_sub = _extract(layer)

        # c0
        ax = axes[i, 0]
        if c0 is not None:
            ax.hist(c0, bins=20, color="#4e79a7")
            ax.set_xlim(0, 1)
            ax.set_title(f"Layer {i} - c0")
        else:
            ax.axis("off")
            ax.text(0.5, 0.5, f"Layer {i}\nno c0/c1 params", ha="center", va="center")

        # c1
        ax = axes[i, 1]
        if c1 is not None:
            ax.hist(c1, bins=20, color="#f28e2b")
            ax.set_xlim(0, 1)
            ax.set_title(f"Layer {i} - c1")
        else:
            ax.axis("off")

        # c2
        ax = axes[i, 2]
        if c2 is not None:
            ax.hist(c2, bins=20, color="#e15759")
            ax.set_xlim(0, 1)
            ax.set_title(f"Layer {i} - c2")
        else:
            ax.axis("off")

        # n_sub
        ax = axes[i, 3]
        if n_sub is not None and n_sub.size > 0:
            bins = np.arange(n_sub.min(), n_sub.max()+2) - 0.5
            ax.hist(n_sub.astype(float), bins=bins, color="#76b7b2")
            ax.set_title(f"Layer {i} - n_sub")
        else:
            ax.axis("off")
            # show layer size at least
            ax.text(0.5, 0.5, f"Layer {i} size = {idx.size}", ha="center", va="center")

        # validity overlay if c0/c1/c2 available
        if c0 is not None and c1 is not None and c2 is not None:
            s = c0 + c1 + c2
            invalid = np.where(~np.isfinite(s) | (np.abs(s - 1.0) > 1e-4))[0]
            if invalid.size:
                axes[i, 2].text(0.95, 0.9, f"sum(c)!=1: {invalid.size}",
                                 transform=axes[i, 2].transAxes, ha="right", va="top", color="r")

    if titles is not None:
        for r in range(nrows):
            for c in range(ncols):
                if axes[r, c].has_data():
                    axes[r, c].set_title(titles[r] if c == 0 else axes[r, c].get_title())

    plt.tight_layout()
    plt.show()


__all__ = [
    "plot_connection_matrix",
    "plot_msk_layers_summary",
]

