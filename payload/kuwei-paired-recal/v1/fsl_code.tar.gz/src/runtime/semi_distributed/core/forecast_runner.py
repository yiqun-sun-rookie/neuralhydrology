"""forecast_runner: shared simulation + DA workflow.

Consolidates config loading, parameter resolution, simulation execution, and
DA adapter construction previously duplicated across run_once.py,
eval_with_params.py, and test_da_ukf.py.

Public API
----------
- build_cfg_from_run_config(path, strict=False) -> (cfg, raw, flat)
- find_best_params(cfg, run_config_path, ...) -> Path
- load_params(path, section=None) -> dict
- run_simulation(cfg, param_dict, ...) -> SimulationResult
- build_da_covariance(raw_cfg, state_dim, ...) -> (P0, Q, R, ensemble_size)
- build_da_setup(da_handles, raw_cfg, state_dim) -> da_setup
- build_da_backend(controls, qobs, hx) -> backend
- run_simulation_with_da(sim_result, ...) -> DAResult
- generate_leadtime_forecasts(f_flat, h_flat, ...) -> (forecasts, obs_matrix, issue_indices)
- build_leadtime_report(sim_result, da_result, obs, ...) -> dict | None
"""
from __future__ import annotations

import os
import pickle
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from src.runtime.semi_distributed.core.optimization_config import OptimizationConfig

PROJECT_ROOT = Path(__file__).resolve().parents[4]
STATION_LOCAL_TIMEZONE = "Asia/Vientiane"


def _station_time_to_utc_iso(value: Any) -> str:
    """Convert a station timestamp from Laos local time to a UTC ISO string."""
    timestamp = pd.Timestamp(value)
    if timestamp.tzinfo is None:
        timestamp = timestamp.tz_localize(STATION_LOCAL_TIMEZONE)
    timestamp = timestamp.tz_convert("UTC")
    return timestamp.isoformat().replace("+00:00", "Z")


# ---------------------------------------------------------------------------
# YAML & config helpers
# ---------------------------------------------------------------------------

def load_yaml_with_include(path: Path, _visited: set | None = None):
    """Load YAML with shallow include support."""
    try:
        import yaml
    except Exception as e:
        raise RuntimeError(f"PyYAML required: {e}")
    if _visited is None:
        _visited = set()
    p = Path(path).resolve()
    if not p.exists():
        raise FileNotFoundError(f"YAML file not found: {p}")
    if p in _visited:
        raise RuntimeError(f"Circular include detected: {p}")
    _visited.add(p)
    with open(p, "r", encoding="utf-8") as fp:
        data = yaml.safe_load(fp) or {}
    inc = None
    if isinstance(data, dict):
        inc = data.get("include") or data.get("includes")
    if inc:
        inc_list = inc if isinstance(inc, (list, tuple)) else [inc]
        merged: dict = {}
        for item in inc_list:
            inc_path = (p.parent / str(item)).resolve()
            sub = load_yaml_with_include(inc_path, _visited)
            if isinstance(sub, dict):
                merged.update(sub)
        if isinstance(data, dict):
            merged.update({k: v for k, v in data.items() if k not in ("include", "includes")})
        data = merged
    return data


def _flatten_config(data: dict[str, Any]) -> dict[str, Any]:
    """Flatten grouped run_config into a flat dict."""
    if any(k in data for k in ("scene", "optimizer", "diagnostics", "time", "meta")):
        flat: dict[str, Any] = {}
        for grp in ("scene", "optimizer", "diagnostics", "time", "meta"):
            g = data.get(grp)
            if isinstance(g, dict):
                for k, v in g.items():
                    if k in flat:
                        raise ValueError(
                            f"Config key collision: '{k}' appears in multiple groups"
                        )
                    flat[k] = v
        for k, v in data.items():
            if k in ("scene", "optimizer", "diagnostics", "time", "meta", "include", "includes"):
                continue
            flat[k] = v
        return flat
    return data


def _resolve_path(path_value: str | None, base_dir: Path) -> Path | None:
    """Resolve a relative path against base_dir then project root."""
    if not path_value:
        return None
    p = Path(path_value)
    candidates: list[Path] = []
    if p.is_absolute():
        candidates.append(p)
    else:
        candidates.append((base_dir / p).resolve())
        candidates.append((PROJECT_ROOT / p).resolve())
    for cand in candidates:
        if cand.exists():
            return cand
    return candidates[0] if candidates else None


# ---------------------------------------------------------------------------
# Config builder
# ---------------------------------------------------------------------------

def build_cfg_from_run_config(
    path: Path,
    *,
    strict: bool = False,
) -> tuple[OptimizationConfig, dict[str, Any], dict[str, Any]]:
    """Build OptimizationConfig from a run_config YAML file.

    Parameters
    ----------
    path : Path
        Path to run_config.yml.
    strict : bool
        If True, raise on missing calib_anchor / objective_flow (eval mode).
        If False, tolerate missing fields (forecast mode).

    Returns
    -------
    (cfg, raw_dict, flat_dict)
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"run_config not found: {path}")

    raw = load_yaml_with_include(path, set())
    if not isinstance(raw, dict):
        raise TypeError(f"run_config must be a dict, got {type(raw).__name__}")
    flat = _flatten_config(raw)

    cfg = OptimizationConfig()
    cfg.CONFIG_DIR = path.parent

    # -- scene --
    basin_name = flat.get("basin_name")
    if isinstance(basin_name, str) and basin_name.strip():
        cfg.set_basin_name(basin_name.strip())

    section = flat.get("section")
    if isinstance(section, str) and section.strip():
        cfg.set_section(section.strip())

    sim_unit = flat.get("sim_unit")
    if isinstance(sim_unit, str) and sim_unit.strip():
        if strict and sim_unit.strip().lower() not in ("grid", "subbasin"):
            raise SystemExit("run_config: invalid sim_unit")
        cfg.set_sim_unit(sim_unit.strip())

    matrix_prefix = flat.get("matrix_prefix")
    if isinstance(matrix_prefix, str) and matrix_prefix.strip():
        cfg.set_matrix_prefix(matrix_prefix.strip())

    calib_anchor = flat.get("calib_anchor")
    if isinstance(calib_anchor, str) and calib_anchor.strip():
        cfg.set_calib_anchor(calib_anchor.strip())
    elif strict:
        raise SystemExit("run_config missing calib_anchor")

    objective_flow = flat.get("objective_flow")
    if isinstance(objective_flow, str) and objective_flow.strip():
        if strict and objective_flow.strip().lower() == "from_anchor":
            raise SystemExit("run_config: objective_flow must not be from_anchor")
        cfg.set_objective_flow(objective_flow.strip())
    elif strict:
        raise SystemExit("run_config missing objective_flow")

    if "calib_nodes" in flat:
        cfg.select_calib_nodes(flat["calib_nodes"])
    if "verify" in flat:
        cfg.set_verify_nodes(flat["verify"])

    # override stations
    ov = flat.get("override")
    if ov is not None:
        if isinstance(ov, str):
            if ov.strip() == "*":
                cfg.set_override_stations(None)
            elif ov.strip() in ("", "none", "null"):
                cfg.set_override_stations([])
            else:
                cfg.set_override_stations([s for s in ov.split(",") if s])
        elif isinstance(ov, (list, tuple)):
            cfg.set_override_stations(list(ov))

    # -- time --
    start_date = flat.get("start_date")
    if isinstance(start_date, str) and start_date.strip():
        cfg.START_TIME = start_date.strip()
    end_date = flat.get("end_date")
    if isinstance(end_date, str) and end_date.strip():
        cfg.END_TIME = end_date.strip()

    dt_hours = flat.get("dt_hours") or flat.get("DT_HOURS")
    if dt_hours is not None:
        dt_hours = float(dt_hours)
        if not (0.25 <= dt_hours <= 24):
            raise ValueError(f"DT_HOURS must be 0.25-24, got {dt_hours}")
        cfg.set_time_step_hours(dt_hours)

    # eval_start_date (spinup: simulate from start_date, evaluate NSE from eval_start_date)
    eval_start = flat.get("eval_start_date")
    if isinstance(eval_start, str) and eval_start.strip():
        cfg.EVAL_START_DATE = eval_start.strip()

    # exclude_years + exclude_mode (2026-05-27): 详见 dataio._resolve_exclude_config
    ex = flat.get("exclude_years")
    try:
        if ex is None:
            cfg.EXCLUDE_YEARS = set()
        elif isinstance(ex, (list, tuple, set)):
            cfg.EXCLUDE_YEARS = {int(x) for x in ex}
        else:
            cfg.EXCLUDE_YEARS = {int(x) for x in str(ex).split(",") if str(x).strip()}
    except Exception:
        cfg.EXCLUDE_YEARS = set()
    _em = flat.get("exclude_mode")
    cfg.EXCLUDE_MODE = (str(_em).strip().lower() if isinstance(_em, str) and _em.strip() else None)

    # -- meteo --
    meteo_file = flat.get("meteo_file")
    if isinstance(meteo_file, str) and meteo_file.strip():
        cfg.set_meteo_file(meteo_file.strip())

    data_dir = flat.get("data_dir")
    if isinstance(data_dir, str) and data_dir.strip():
        resolved_data_dir = _resolve_path(data_dir.strip(), path.parent)
        if resolved_data_dir is not None:
            cfg.DATA_DIR = resolved_data_dir

    # -- inline model --
    model_block = raw.get("model")
    if isinstance(model_block, dict):
        if "msk_segmented" in model_block:
            cfg.MSK_SEGMENTED = bool(model_block.get("msk_segmented"))
        if str(model_block.get("mode", "")).lower() == "inline":
            data_blk = model_block.get("data", {})
            if isinstance(data_blk, dict):
                cfg.INLINE_TOPOLOGY = data_blk.get("topology")
                cfg.INLINE_CALIB = data_blk.get("calibration")
                cfg.INLINE_PDD_XAJ = data_blk.get("pdd_xaj")
                ic_inline = data_blk.get("initial_conditions")
                if ic_inline is None:
                    ic_inline = data_blk.get("initial_conditions_file")
                if isinstance(ic_inline, (dict, str)):
                    cfg.INLINE_INITIAL_CONDITIONS = ic_inline

    # -- eval/flow anchors --
    cfg.EVAL_STATION = getattr(cfg, "CALIB_ANCHOR", None)
    cfg.FLOW_SOURCE_STATION = getattr(cfg, "OBJECTIVE_FLOW", None)

    # strict_no_fallback (eval compatibility)
    if strict:
        os.environ["STRICT_SINGLE_CONFIG"] = "1"
        try:
            snf = bool(flat.get("strict_no_fallback", False))
            if snf:
                os.environ["STRICT_NO_FALLBACK"] = "1"
        except Exception:
            pass

    return cfg, raw, flat


# ---------------------------------------------------------------------------
# Parameter loading
# ---------------------------------------------------------------------------

def find_best_params(
    cfg: OptimizationConfig,
    run_config_path: Path,
    *,
    raw_cfg: dict[str, Any] | None = None,
    explicit_path: str | None = None,
) -> Path:
    """Find the best parameter file for a given config.

    Search order:
    1. explicit_path / RUN_ONCE_PARAMS env
    2. model.data.calibration.initial_params in raw_cfg
    3. basins/<basin>/config/best_params.yml
    4. results/experiments/<section>/best_params*.pkl (newest)
    """
    run_config_path = Path(run_config_path)
    raw_cfg = raw_cfg or {}

    params_path = (explicit_path or "").strip() or os.getenv("RUN_ONCE_PARAMS")
    if params_path:
        resolved = _resolve_path(params_path, run_config_path.parent)
        if resolved and resolved.exists():
            return resolved

    model_block = raw_cfg.get("model") if isinstance(raw_cfg, dict) else None
    if isinstance(model_block, dict) and str(model_block.get("mode", "")).lower() == "inline":
        data_blk = model_block.get("data", {})
        if isinstance(data_blk, dict):
            calib_blk = data_blk.get("calibration", {})
            if isinstance(calib_blk, dict):
                initial_params = calib_blk.get("initial_params")
                resolved = _resolve_path(str(initial_params) if initial_params else None, run_config_path.parent)
                if resolved and resolved.exists():
                    return resolved

    section = getattr(cfg, "SECTION_NAME", None)
    basin = getattr(cfg, "BASIN_NAME", None) or section
    candidates: list[Path] = []
    if basin:
        candidates.append(PROJECT_ROOT / "basins" / str(basin) / "config" / "best_params.yml")
    if section:
        candidates.append(PROJECT_ROOT / "results" / "experiments" / str(section) / "best_params.yml")
        pkl_dir = PROJECT_ROOT / "results" / "experiments" / str(section)
        if pkl_dir.exists():
            cands = sorted(
                pkl_dir.glob(f"best_params_{section}_nse*.pkl"),
                key=lambda p: p.stat().st_mtime,
                reverse=True,
            )
            if cands:
                candidates.append(cands[0])

    for cand in candidates:
        if cand.exists():
            return cand

    raise FileNotFoundError(
        "failed to locate params file; checked RUN_ONCE_PARAMS, run_config initial_params, and basin defaults"
    )


def load_params(path: Path, section: str | None = None) -> dict[str, Any]:
    """Load parameters from a file (YAML, JSON, or pickle).

    Handles 'best_params' wrapper and optional section extraction.
    """
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix in {".yml", ".yaml"}:
        try:
            import yaml
        except Exception as exc:
            raise RuntimeError(f"PyYAML unavailable: {exc}") from exc
        with path.open("r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
    elif suffix == ".json":
        import json
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
    elif suffix == ".pkl":
        with path.open("rb") as f:
            data = pickle.load(f)
    else:
        raise ValueError(f"unsupported params file suffix: {path.suffix}")

    if isinstance(data, dict) and "best_params" in data and isinstance(data["best_params"], dict):
        data = data["best_params"]

    if section and isinstance(data, dict) and section in data and isinstance(data[section], dict):
        data = data[section]

    if not isinstance(data, dict):
        raise TypeError(f"params payload must be a dict, got {type(data).__name__}")
    return data


# ---------------------------------------------------------------------------
# Input validation
# ---------------------------------------------------------------------------


def validate_meteo_inputs(
    rain: np.ndarray,
    temp: np.ndarray,
    snow: np.ndarray,
    pet: np.ndarray,
) -> None:
    """Validate meteo input arrays before simulation. Raises ValueError on invalid data."""
    for arr, name in [(rain, "rain"), (temp, "temp"), (snow, "snow"), (pet, "pet")]:
        if arr.ndim != 2:
            raise ValueError(f"{name} must be 2D (T, Ng), got shape {arr.shape}")
        if np.any(np.isnan(arr)):
            nan_pct = np.isnan(arr).mean() * 100
            raise ValueError(
                f"{name} contains NaN ({nan_pct:.1f}% of values)"
            )
    shapes = {
        name: a.shape
        for name, a in [("rain", rain), ("temp", temp), ("snow", snow), ("pet", pet)]
    }
    if len(set(shapes.values())) > 1:
        raise ValueError(f"Meteo input shape mismatch: {shapes}")
    if np.any(rain < 0):
        raise ValueError(f"Negative values in rain (min={rain.min():.4f})")
    if np.any(pet < 0):
        raise ValueError(f"Negative values in pet (min={pet.min():.4f})")


# ---------------------------------------------------------------------------
# Simulation
# ---------------------------------------------------------------------------

@dataclass
class SimulationResult:
    """Result of a single forward simulation."""
    q_outlet: np.ndarray           # (T,) basin outlet discharge
    time_index: pd.DatetimeIndex   # (T,) timestamps
    sim_ret: tuple                 # raw _simulate_core return
    session: dict                  # prepare_calibration_session output
    cfg: OptimizationConfig
    core_args: dict
    pdd_tuple: tuple
    xaj_tuple: tuple
    init_state_arr: np.ndarray     # (Ng, 11)
    grid2sub: np.ndarray
    meteo_inputs: tuple            # (rain, temp, snow, pet)
    forecast_rain_input: np.ndarray | None = None  # (T_fc, Ng) forecast rain for display
    forecast_start_idx: int | None = None          # index where forecast period begins


def run_simulation(
    cfg: OptimizationConfig,
    param_dict: dict[str, Any],
    *,
    init_state_override: np.ndarray | None = None,
    return_state_grid: bool = True,
    return_last_layer: bool = True,
    forecast_meteo_method: str | None = None,
    forecast_steps: int = 0,
    basin_coords: list[tuple[float, float]] | None = None,
) -> SimulationResult:
    """Run a single forward simulation.

    Merges the duplicate simulation pipeline from run_once.run_once()
    and eval_with_params.recompute_nse_with_params().
    """
    from src.runtime.semi_distributed.core.pipeline import prepare_calibration_session
    from src.runtime.semi_distributed.core.params import prepare_model_params
    from src.runtime.semi_distributed.core.dataio import prepare_external_flow_inputs
    from src.kernels.semi_distributed.core.simulate_flood_distributed_fast import (
        _simulate_core, prepare_initial_conditions,
    )

    session = prepare_calibration_session(cfg)
    grid2sub = session["grid2sub"]
    sub_area = session["sub_area"]
    connection_matrices = session["connection_matrices"]
    default_params = session["default_params"]
    calib_cfg = session["calib_cfg"]
    init_cond = session["init_cond"]
    meteo_inputs = session["meteo_inputs"]
    time_index = pd.DatetimeIndex(session["time_index"])
    discharge_inflow = session.get("discharge_inflow")

    _, pdd_tuple, xaj_tuple, _, core_args = prepare_model_params(
        param_dict=param_dict,
        model_params_template=default_params,
        calibration_config=calib_cfg,
        grid2sub=grid2sub,
        sub_area=sub_area,
        connection_matrices=connection_matrices,
        param_mode={
            "msk_params": {"*": "sub"},
            "xaj_params": {"*": "basin"},
            "pdd_params": {"*": "basin"},
        },
    )

    ng = int(getattr(grid2sub, "shape", (0, 0))[0])
    if init_state_override is not None and init_state_override.shape == (ng, 11):
        init_state_arr = init_state_override
    else:
        init_state_arr = prepare_initial_conditions(init_cond, ng, enable_snowmelt=False)

        # Enhance flow states with observed discharge at simulation start,
        # but ONLY when init_cond does not already contain explicit Q values
        # (YAML initial_conditions with QS/QI/QG reflect calibrated equilibrium
        # and must not be overridden for calibration-period evaluations).
        has_explicit_q = all(k in init_cond for k in ("QS", "QI", "QG"))
        if not has_explicit_q:
            discharge_outlet = session.get("discharge_outlet")
            if discharge_outlet is not None and hasattr(discharge_outlet, "iloc") and len(discharge_outlet) > 0:
                q0 = None
                for val in discharge_outlet.iloc[:48]:
                    if np.isfinite(val) and val > 0:
                        q0 = float(val)
                        break
                if q0 is not None:
                    q_per_cell = q0 / max(ng, 1)
                    init_state_arr[:, 8] = q_per_cell * 0.1    # QS (surface)
                    init_state_arr[:, 9] = q_per_cell * 0.2    # QI (interflow)
                    init_state_arr[:, 10] = q_per_cell * 0.7   # QG (groundwater)
                else:
                    import warnings as _warnings
                    _warnings.warn(
                        "All first 48 observed discharge values are NaN or ≤0. "
                        "QS/QI/QG initialized to zero — forecast quality may be degraded.",
                        stacklevel=2,
                    )

    # External flow override (YLX-specific)
    obs_station_arr = None
    sta_reach_idx = None
    section_name = str(getattr(cfg, "SECTION_NAME", "")).lower()
    if section_name == "ylx":
        station_reach_map = {"zmsk": 0, "ql": 1}
        obs_station_arr, sta_reach_idx = prepare_external_flow_inputs(
            observed_station_flow=discharge_inflow,
            station_reach_map=station_reach_map,
            time_index=time_index,
            override_stations=getattr(cfg, "OVERRIDE_STATIONS", None),
        )

    rain, temp, snow, pet = meteo_inputs
    validate_meteo_inputs(rain, temp, snow, pet)

    # --- Forecast meteo extension (naive forecast beyond observation period) ---
    forecast_rain_input = None
    forecast_start_idx = None
    if forecast_meteo_method and forecast_steps > 0:
        from src.runtime.semi_distributed.core.dataio import prepare_forecast_meteo
        dt_hours = float(getattr(cfg, "DT_HOURS", 1.0) or 1.0)
        forecast_start_idx = rain.shape[0]
        rain, temp, snow, pet, time_index, obs_station_ext, forecast_rain_input = \
            prepare_forecast_meteo(
                rain, temp, snow, pet, time_index,
                forecast_steps, dt_hours, forecast_meteo_method,
                obs_station=obs_station_arr,
                basin_coords=basin_coords,
            )
        if obs_station_ext is not None:
            obs_station_arr = obs_station_ext

    sim_kwargs: dict[str, Any] = {
        "return_state_grid": return_state_grid,
        "return_last_layer": return_last_layer,
        **core_args,
    }
    if obs_station_arr is not None and sta_reach_idx is not None:
        sim_kwargs["obs_station"] = obs_station_arr
        sim_kwargs["sta_reach_idx"] = sta_reach_idx

    sim_ret = _simulate_core(
        rain, temp, snow, pet,
        pdd_tuple, xaj_tuple,
        grid2sub.astype(np.float32),
        init_state_arr,
        **sim_kwargs,
    )
    q_outlet = np.asarray(sim_ret[2], dtype=np.float64)
    n_steps = min(len(time_index), q_outlet.shape[0])

    return SimulationResult(
        q_outlet=q_outlet[:n_steps],
        time_index=time_index[:n_steps],
        sim_ret=sim_ret,
        session=session,
        cfg=cfg,
        core_args=core_args,
        pdd_tuple=pdd_tuple,
        xaj_tuple=xaj_tuple,
        init_state_arr=init_state_arr,
        grid2sub=grid2sub,
        meteo_inputs=(rain, temp, snow, pet),
        forecast_rain_input=forecast_rain_input,
        forecast_start_idx=forecast_start_idx,
    )


# ---------------------------------------------------------------------------
# DA utilities
# ---------------------------------------------------------------------------

@dataclass
class DAResult:
    """Result of data assimilation correction."""
    q_da: np.ndarray             # (T,) DA-corrected discharge
    q_openloop: np.ndarray       # (T,) open-loop discharge
    time_index: pd.DatetimeIndex
    da_method: str
    x_means: np.ndarray | None = None  # (T, state_dim) posterior state means
    y_pred_stds: np.ndarray | None = None  # (T,) posterior prediction std
    diagnostics: dict | None = None  # DA diagnostic bundle (optional)


def build_da_covariance(
    raw_cfg: dict[str, Any],
    state_dim: int,
    n_state_per_unit: int = 11,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, int]:
    """Build P0/Q/R matrices from run_config DA section.

    Handles per-unit diagonal values (11-dim) tiled to full state_dim,
    with Muskingum states padded using small default values.

    Returns (P0, Q, R, ensemble_size).

    Raises:
        ValueError: If ``da.covariance`` section is missing or incomplete.
    """
    import logging
    logger = logging.getLogger(__name__)

    da_cfg = (raw_cfg.get("da") or {}) if isinstance(raw_cfg, dict) else {}
    if not da_cfg:
        raise ValueError(
            "run_config missing 'da' section. DA covariance (P0/Q/R) must be "
            "explicitly defined in run_config.yml — no silent defaults allowed."
        )
    cov_cfg = da_cfg.get("covariance", {}) if isinstance(da_cfg, dict) else {}
    if not cov_cfg:
        raise ValueError(
            "run_config 'da' section missing 'covariance' block. "
            "P0/Q/R must be explicitly defined."
        )
    ensemble_cfg = da_cfg.get("ensemble", {}) if isinstance(da_cfg, dict) else {}
    ensemble_size = int(ensemble_cfg.get("size", 50)) if isinstance(ensemble_cfg, dict) else 50

    def _build_diag_matrix(entry: Any, dim: int, name: str) -> np.ndarray:
        if not isinstance(entry, dict):
            raise ValueError(
                f"DA covariance '{name}' not defined in run_config. "
                f"Add '{name}: {{diag: [...]}}' or '{name}: {{scale: ...}}' "
                f"to da.covariance section."
            )
        diag_vals = entry.get("diag")
        if diag_vals is None:
            if "scale" not in entry:
                raise ValueError(
                    f"DA covariance '{name}' has neither 'diag' nor 'scale'. "
                    f"Provide one explicitly."
                )
            scale = float(entry["scale"])
            return np.eye(dim, dtype=np.float64) * scale
        arr = np.asarray(diag_vals, dtype=np.float64).ravel()
        if arr.size == dim:
            return np.diag(arr)
        if arr.size == n_state_per_unit and dim > n_state_per_unit:
            n_units = (dim - 1) // n_state_per_unit + 1
            tiled = np.tile(arr, n_units)[:dim]
            n_xaj = (dim // n_state_per_unit) * n_state_per_unit
            if n_xaj < dim:
                msk_default = float(np.median(arr)) * 0.1
                tiled[n_xaj:] = msk_default
            return np.diag(tiled)
        raise ValueError(
            f"P0/Q diag length ({arr.size}) != state_dim ({dim}) and "
            f"!= n_state_per_unit ({n_state_per_unit}). Provide a {dim}-dim "
            f"or {n_state_per_unit}-dim diagonal vector."
        )

    P0 = _build_diag_matrix(cov_cfg.get("p0"), state_dim, "p0")
    Q = _build_diag_matrix(cov_cfg.get("q"), state_dim, "q")

    r_entry = cov_cfg.get("r")
    if not isinstance(r_entry, dict):
        raise ValueError(
            "DA covariance 'r' not defined in run_config. "
            "Add 'r: {scale: ...}' or 'r: {diag: [...]}' to da.covariance section."
        )
    r_diag = r_entry.get("diag")
    if r_diag is not None:
        r_arr = np.asarray(r_diag, dtype=np.float64).ravel()
        R = np.diag(r_arr) if r_arr.size > 1 else np.array([[float(r_arr[0])]])
    elif "scale" in r_entry:
        R = np.array([[float(r_entry["scale"])]])
    else:
        raise ValueError(
            "DA covariance 'r' has neither 'diag' nor 'scale'. "
            "Provide one explicitly."
        )

    logger.info(
        "DA covariance loaded: P0 diag=[%.3f..%.3f], Q diag=[%.4f..%.4f], "
        "R=%.4f, state_dim=%d",
        np.diag(P0).min(), np.diag(P0).max(),
        np.diag(Q).min(), np.diag(Q).max(),
        R[0, 0], state_dim,
    )

    return P0, Q, R, ensemble_size


def build_da_setup(da_handles: dict, raw_cfg: dict, state_dim: int) -> Any:
    """Build a DA setup object with all attributes required by run_assimilation.

    Includes float64<->float32 wrapping for Numba compatibility.
    """
    raw_f_flat = da_handles["f_flat"]
    raw_h_flat = da_handles["h_flat"]
    x0_flat = da_handles["x0_flat"].astype(np.float64)

    def f_flat(x, u_t):
        x_f32 = np.asarray(x, dtype=np.float32)
        u_f32 = np.asarray(u_t, dtype=np.float32) if isinstance(u_t, np.ndarray) else u_t
        return np.asarray(raw_f_flat(x_f32, u_f32), dtype=np.float64)

    def h_flat(x):
        x_f32 = np.asarray(x, dtype=np.float32)
        return np.asarray(raw_h_flat(x_f32), dtype=np.float64)

    P0, Q, R, ensemble_size = build_da_covariance(raw_cfg, state_dim)

    class _DASetup:
        pass

    da_setup = _DASetup()
    da_setup.fx = lambda x, dt, controls=None: f_flat(x, controls)
    da_setup.hx = lambda x: h_flat(x).ravel()
    da_setup.x0_flat = x0_flat.copy()
    da_setup.dim_x = state_dim
    da_setup.dim_z = 1
    da_setup.P0 = P0
    da_setup.Q = Q
    da_setup.R = R
    da_setup.ensemble_size = ensemble_size
    da_setup.da_config = raw_cfg.get("da", {})
    state_projection = raw_cfg.get("da", {}).get("state_projection", {})
    if not isinstance(state_projection, dict):
        raise ValueError("da.state_projection must be a mapping")
    if bool(state_projection.get("enabled", False)):
        projector = da_handles.get("project_flat_state")
        if not callable(projector):
            raise ValueError("enabled state projection requires project_flat_state")
        da_setup.state_projector = projector
    gain_mask = raw_cfg.get("da", {}).get("gain_mask")
    if gain_mask is not None:
        gain_mask_values = np.asarray(gain_mask, dtype=float).reshape(-1)
        if gain_mask_values.size != state_dim:
            raise ValueError(
                f"da.gain_mask length {gain_mask_values.size} does not match state dimension {state_dim}"
            )
        if not np.isfinite(gain_mask_values).all() or np.any(
            (gain_mask_values < 0.0) | (gain_mask_values > 1.0)
        ):
            raise ValueError("da.gain_mask values must be finite and between zero and one")
        da_setup.gain_mask = gain_mask_values.reshape(state_dim, 1)
    return da_setup


def build_da_backend(controls: np.ndarray, qobs: np.ndarray, hx) -> Any:
    """Build a hydro backend object required by run_assimilation."""
    T = controls.shape[0]

    class _HydroBackend:
        pass

    class _Forcings:
        pass

    backend = _HydroBackend()
    backend.forcings = _Forcings()
    backend.forcings.steps = T
    backend.forcings.qobs = qobs
    backend.hx = hx
    backend.get_controls = lambda t: controls[t]
    return backend


def run_simulation_with_da(
    sim_result: SimulationResult,
    *,
    da_method: str,
    obs_discharge: np.ndarray,
    raw_cfg: dict[str, Any],
    collect_diagnostics: bool = False,
) -> DAResult:
    """Run DA correction on a completed simulation.

    Args:
        raw_cfg: Raw run_config dict. MUST contain ``da.covariance`` section
            with P0/Q/R definitions. Passing empty dict will raise ValueError.
    """
    from src.runtime.semi_distributed.core.state_space_handles.handles_adapter import get_da_handles
    from src.da.workflows.fh import run_assimilation

    rain, temp, snow, pet = sim_result.meteo_inputs
    T = rain.shape[0]

    da_handles = get_da_handles(
        init_units_state=sim_result.init_state_arr,
        msk_layers_params=sim_result.core_args["msk_layers_params"],
        layer_connect_mats=sim_result.core_args.get("C_mats"),
        grid2sub=sim_result.grid2sub,
        pdd_pars=sim_result.pdd_tuple,
        xaj_pars=sim_result.xaj_tuple,
        observation_mode_default="basin_sum",
    )

    state_dim = da_handles["state_dim"]
    if not raw_cfg or "da" not in raw_cfg:
        raise ValueError(
            "raw_cfg must contain 'da.covariance' section with P0/Q/R. "
            "Check that run_config.yml is loaded and passed correctly."
        )
    da_setup = build_da_setup(da_handles, raw_cfg, state_dim)

    controls = np.stack([rain, temp, snow, pet], axis=1).astype(np.float32)
    observations = np.asarray(obs_discharge, dtype=np.float64)
    if observations.ndim != 1:
        raise ValueError(
            f"obs_discharge must be one-dimensional, got shape {observations.shape}"
        )
    qobs = np.full(T, np.nan, dtype=np.float64)
    observed_steps = min(T, observations.size)
    qobs[:observed_steps] = observations[:observed_steps]

    backend = build_da_backend(controls, qobs, da_setup.hx)

    results, ran, failed = run_assimilation(
        da_list=[da_method],
        hydro_backend=backend,
        da_setup=da_setup,
        collect_diagnostics=collect_diagnostics,
    )

    if failed:
        raise RuntimeError(f"DA method {da_method} failed: {failed}")

    return DAResult(
        q_da=results[da_method]["y_preds"],
        q_openloop=sim_result.q_outlet,
        time_index=sim_result.time_index,
        da_method=da_method,
        x_means=results[da_method].get("x_means"),
        y_pred_stds=results[da_method].get("y_pred_stds"),
        diagnostics=results[da_method].get("diagnostics"),
    )


def generate_leadtime_forecasts(
    f_flat,
    h_flat,
    history_states: np.ndarray,
    forcings: np.ndarray,
    obs: np.ndarray,
    horizon: int = 24,
    issue_interval: int = 1,
    min_warmup: int = 100,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Generate forecasts at multiple issue times for lead-time verification.

    For each issue_time t, loads state from history_states[t] and runs the
    model forward (predict only, no DA update) for ``horizon`` steps.

    Args:
        f_flat: State transition ``(x, u) -> x_next`` (float64).
        h_flat: Observation function ``(x) -> y_pred`` (float64, 1-element).
        history_states: (T, state_dim) assimilated or open-loop state history.
        forcings: (T, n_forcing) control inputs per timestep.
        obs: (T,) observed discharge (NaN for missing).
        horizon: Number of forecast steps from each issue time.
        issue_interval: Sample every N steps as a forecast origin.
        min_warmup: Skip the first N steps (model spinup).

    Returns:
        (forecasts, obs_matrix, issue_indices) where:
        - forecasts: (n_issues, horizon) predicted discharge
        - obs_matrix: (n_issues, horizon) observed discharge (may contain NaN)
        - issue_indices: (n_issues,) integer indices of issue times

    Raises:
        ValueError: If data too short for horizon + warmup.
    """
    history_states = np.asarray(history_states)
    forcings = np.asarray(forcings)
    obs = np.asarray(obs)
    if history_states.ndim != 2:
        raise ValueError(f"history_states must be two-dimensional, got shape {history_states.shape}")
    if forcings.ndim < 2:
        raise ValueError(f"forcings must have time and forcing dimensions, got shape {forcings.shape}")
    if obs.ndim != 1:
        raise ValueError(f"obs must be one-dimensional, got shape {obs.shape}")
    if not (history_states.shape[0] == forcings.shape[0] == obs.shape[0]):
        raise ValueError(
            "history_states, forcings, and obs must have the same number of timesteps; "
            f"got {history_states.shape[0]}, {forcings.shape[0]}, and {obs.shape[0]}"
        )
    if horizon <= 0:
        raise ValueError(f"horizon must be positive, got {horizon}")
    if issue_interval <= 0:
        raise ValueError(f"issue_interval must be positive, got {issue_interval}")
    if min_warmup < 0:
        raise ValueError(f"min_warmup must be non-negative, got {min_warmup}")

    T = history_states.shape[0]
    max_start = T - horizon

    if max_start <= min_warmup:
        raise ValueError(
            f"Not enough data: T={T}, horizon={horizon}, min_warmup={min_warmup}. "
            f"Need T > {min_warmup + horizon}."
        )

    issue_indices = np.arange(min_warmup, max_start, issue_interval)
    n_issues = len(issue_indices)

    forecasts = np.full((n_issues, horizon), np.nan, dtype=np.float64)
    obs_matrix = np.full((n_issues, horizon), np.nan, dtype=np.float64)

    for i, t in enumerate(issue_indices):
        x = history_states[t].copy().astype(np.float64)
        for lt in range(horizon):
            t_future = t + lt + 1
            if t_future >= T:
                break
            x = f_flat(x, forcings[t_future])
            forecasts[i, lt] = float(np.asarray(h_flat(x)).ravel()[0])
            obs_matrix[i, lt] = obs[t_future]

    return forecasts, obs_matrix, issue_indices


def build_leadtime_report(
    sim_result: SimulationResult,
    da_result: DAResult,
    obs_discharge: np.ndarray,
    *,
    horizon: int = 24,
    issue_interval: int = 1,
    min_warmup: int = 100,
) -> dict | None:
    """Build lead-time verification report from DA results.

    Convenience function that wires up DA handles, generates forecasts, and
    computes per-lead-time metrics in one call.

    Returns None if DA didn't produce state history (x_means) or if the
    simulation is too short for the requested horizon.
    """
    if da_result.x_means is None:
        return None

    from src.runtime.semi_distributed.core.state_space_handles.handles_adapter import get_da_handles
    from src.runtime.verification import compute_leadtime_metrics

    da_handles = get_da_handles(
        init_units_state=sim_result.init_state_arr,
        msk_layers_params=sim_result.core_args["msk_layers_params"],
        layer_connect_mats=sim_result.core_args.get("C_mats"),
        grid2sub=sim_result.grid2sub,
        pdd_pars=sim_result.pdd_tuple,
        xaj_pars=sim_result.xaj_tuple,
        observation_mode_default="basin_sum",
    )

    raw_f = da_handles["f_flat"]
    raw_h = da_handles["h_flat"]

    def f64_f(x, u):
        return np.asarray(raw_f(np.asarray(x, np.float32), np.asarray(u, np.float32)), np.float64)

    def f64_h(x):
        return np.asarray(raw_h(np.asarray(x, np.float32)), np.float64)

    rain, temp, snow, pet = sim_result.meteo_inputs
    controls = np.stack([rain, temp, snow, pet], axis=1).astype(np.float32)

    try:
        forecasts, obs_matrix, issue_indices = generate_leadtime_forecasts(
            f64_f, f64_h, da_result.x_means, controls, obs_discharge,
            horizon=horizon, issue_interval=issue_interval, min_warmup=min_warmup,
        )
        report = compute_leadtime_metrics(forecasts, obs_matrix, method=da_result.da_method)
        result = report.to_dict()

        # Extract k-step-ahead time series for chart display.
        # Each line shows: at verification time t, the prediction made
        # k steps earlier (from the DA state at t-k).
        # Downsample to ~max_chart_pts points per line for browser perf.
        selected_leads = [k for k in [1, 3, 6, 12, 24] if k <= horizon]
        time_index = sim_result.time_index
        T = len(time_index)
        n_issues = len(issue_indices)
        max_chart_pts = 800
        sample_step = max(1, n_issues // max_chart_pts)
        forecast_lines: dict[str, list[list]] = {}

        for k in selected_leads:
            line: list[list] = []
            for i in range(0, n_issues, sample_step):
                t_verify = issue_indices[i] + k
                if t_verify >= T:
                    continue
                pred_val = float(forecasts[i, k - 1])
                if not np.isfinite(pred_val):
                    continue
                iso = _station_time_to_utc_iso(time_index[t_verify])
                line.append([iso, pred_val])
            forecast_lines[f"{k}h"] = line

        result["forecast_lines"] = forecast_lines
        return result
    except ValueError:
        return None
