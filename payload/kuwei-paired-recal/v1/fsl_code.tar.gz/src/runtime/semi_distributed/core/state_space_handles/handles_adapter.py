"""State-space handles adapter: provide step_and_measure and flat wrappers for optimization.

This wraps the factory handles into an optimization-ready interface:
  - f_struct(state, u_t) -> next_state
    - h_struct(state, mode='basin_sum'|'last_layer_vector'|'unit_discharge_vector', indices=None) -> y
  - step_and_measure_struct(state, u_t, mode=..., indices=None) -> (next_state, y)
  - f_flat(x_flat, u_t) -> x_flat'
  - h_flat(x_flat, mode=..., indices=None) -> y
  - step_and_measure_flat(x_flat, u_t, mode=..., indices=None) -> (x_flat', y)

Notes
-----
Observation modes:
    - basin_sum: scalar = sum(last_layer_vector)
    - last_layer_vector: vector of the final layer reach outlets
    - unit_discharge_vector: per-unit discharge, derived as sum of last 3 state columns
indices (optional):
  - If provided (1D int array/list), will select a subset from last_layer_vector
    for h_* when mode == 'last_layer_vector'. Ignored for basin_sum.

Note: This module is for optimization workflows, not DA (Data Assimilation).
Despite the function name "get_da_handles", these are state-space handles for optimization.
"""
from __future__ import annotations
from typing import Dict, Any, List, Tuple, Optional
import numpy as np

from .handles_factory import build_full_state_handles


def get_da_handles(
    *,
    init_units_state: np.ndarray,
    msk_layers_params: List[Tuple],
    layer_connect_mats: List[np.ndarray] | None,
    grid2sub: np.ndarray,
    pdd_pars: Tuple[np.ndarray, ...],
    xaj_pars: Tuple[np.ndarray, ...],
    observation_mode_default: str = 'basin_sum',
) -> Dict[str, Any]:
    """Construct state-space handles and metadata for optimization workflows.

    Returns
    -------
        dict with keys:
      - f_struct(state, u_t) -> next_state
            - h_struct(state, mode='basin_sum'|'last_layer_vector'|'unit_discharge_vector', indices=None) -> y
      - step_and_measure_struct(state, u_t, mode=..., indices=None) -> (next_state, y)
      - f_flat(x, u_t) -> x'
      - h_flat(x, mode=..., indices=None) -> y
      - step_and_measure_flat(x, u_t, mode=..., indices=None) -> (x', y)
      - x0_struct, x0_flat, state_dim, state_layout, flatten_state, unflatten_state
    
    Note: Despite the name "get_da_handles", this is for optimization workflows, not DA.
    """
    handles = build_full_state_handles(
        init_units_state=init_units_state,
        msk_layers_params=msk_layers_params,
        layer_connect_mats=layer_connect_mats,
        grid2sub=grid2sub,
        pdd_pars=pdd_pars,
        xaj_pars=xaj_pars,
    )

    f_struct = handles['state_transition_function']
    h_core = handles['observation_function']
    flatten_state = handles['flatten_state']
    unflatten_state = handles['unflatten_state']
    project_state_struct = handles['project_state_struct']
    project_flat_state = handles['project_flat_state']
    state_layout = handles['state_layout']
    x0_struct = handles['init_state_struct']

    # ---- observation wrapper with subset selection ----
    def h_struct(state_struct: Dict[str, Any], *, mode: str = observation_mode_default, indices: Optional[np.ndarray] = None):
        if mode == 'unit_discharge_vector':
            # 原实现：返回每个单元的产流（用于某些场景）
            units = state_struct['units']
            q_dis = units[:, -3:].sum(axis=1)
            if indices is not None:
                idx = np.asarray(indices, dtype=int)
                return q_dis[idx]
            return q_dis
        if mode == 'all_reach_outflows':
            # 新模式：返回所有层所有 reach 的 Muskingum 出流
            # 用于多断面 DA，返回 [zmsk, ql, ylx] 的出流
            msk = state_struct['msk']  # list of layers
            reach_outflows = []
            for layer in msk:
                # layer shape: (n_reaches, n_segments+1)
                # 最后一列是各 reach 的出流
                for reach_idx in range(layer.shape[0]):
                    reach_outflows.append(float(layer[reach_idx, -1]))
            if indices is not None:
                idx = np.asarray(indices, dtype=int)
                return np.array([reach_outflows[i] for i in idx])
            return np.array(reach_outflows)
        # default: use core observation from Muskingum states
        y = h_core(state_struct, mode=mode)
        if mode == 'last_layer_vector' and indices is not None:
            idx = np.asarray(indices, dtype=int)
            return y[idx]
        return y

    def f_flat(x_flat: np.ndarray, u_t: np.ndarray, **kwargs) -> np.ndarray:
        state = unflatten_state(x_flat)
        next_state = f_struct(state, u_t, **kwargs)
        return flatten_state(next_state)

    def h_flat(x_flat: np.ndarray, *, mode: str = observation_mode_default, indices: Optional[np.ndarray] = None):
        state = unflatten_state(x_flat)
        return h_struct(state, mode=mode, indices=indices)

    def step_and_measure_struct(state_struct: Dict[str, Any], u_t: np.ndarray, *, mode: str = observation_mode_default, indices: Optional[np.ndarray] = None):
        next_state = f_struct(state_struct, u_t)
        y = h_struct(next_state, mode=mode, indices=indices)
        return next_state, y

    def step_and_measure_flat(x_flat: np.ndarray, u_t: np.ndarray, *, mode: str = observation_mode_default, indices: Optional[np.ndarray] = None):
        x_next = f_flat(x_flat, u_t)
        y = h_flat(x_next, mode=mode, indices=indices)
        return x_next, y

    x0_flat = flatten_state(x0_struct)
    # 透出状态索引与可用状态名，便于上层以模型无关的方式访问
    _idx_map = state_layout.get('unit_state_index', {}) if isinstance(state_layout, dict) else {}
    _cap_names = state_layout.get('cap_state_names', {}) if isinstance(state_layout, dict) else {}
    _msk_idx_map = state_layout.get('msk_state_index', {}) if isinstance(state_layout, dict) else {}
    try:
        _avail = sorted(list(_idx_map.keys()) + ['snow_storage'] + list(_cap_names.keys()))
    except Exception:
        _avail = None
    return {
        'f_struct': f_struct,
        'h_struct': h_struct,
        'step_and_measure_struct': step_and_measure_struct,
        'f_flat': f_flat,
        'h_flat': h_flat,
        'step_and_measure_flat': step_and_measure_flat,
        'x0_struct': x0_struct,
        'x0_flat': x0_flat,
        'state_dim': x0_flat.size,
        'state_layout': state_layout,
        'flatten_state': flatten_state,
        'unflatten_state': unflatten_state,
        'project_state_struct': project_state_struct,
        'project_flat_state': project_flat_state,
        # 新增：模型语义
        'STATE_INDEX': _idx_map,
        'MSK_STATE_INDEX': _msk_idx_map,
        'CAP_STATE_NAMES': _cap_names,
        'AVAILABLE_STATE_NAMES': _avail,
    }
















