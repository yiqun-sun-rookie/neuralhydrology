from __future__ import annotations
from typing import Any, Dict, Tuple, List, Optional
import warnings
import numpy as np

# File format: NPZ with keys:
#   pdd0,pdd1,pdd2,pdd3  -> 4 arrays (Ng,)
#   xaj0..xaj16          -> 17 arrays (Ng,)
#   msk_layers_params    -> object array of per-layer tuples (idx,c0,c1,c2,n_sub)
#   C_mats               -> object array of connection matrices per layer
#   merged_model_json    -> optional (ignored by simulator, kept for reference)


def save_fixed_broadcast(
    path: str,
    *,
    pdd_tuple: Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray],
    xaj_tuple: Tuple[np.ndarray, ...],
    msk_layers_params: List[Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]],
    C_mats: List[np.ndarray],
    merged_model: Optional[Dict[str, Any]] = None,
) -> None:
    warnings.warn(
        "fixed_broadcast_io is deprecated; use broadcast_api.save_fixed_broadcast/load_fixed_broadcast",
        DeprecationWarning,
        stacklevel=2,
    )
    arrs = {f"pdd{i}": np.asarray(a, dtype=np.float32) for i, a in enumerate(pdd_tuple)}
    for i, a in enumerate(xaj_tuple):
        arrs[f"xaj{i}"] = np.asarray(a, dtype=np.float32)
    arrs["msk_layers_params"] = np.array(msk_layers_params, dtype=object)
    arrs["C_mats"] = np.array(C_mats, dtype=object)
    if merged_model is not None:
        import json
        arrs["merged_model_json"] = np.array([json.dumps(merged_model, ensure_ascii=False)], dtype=object)
    np.savez(path, **arrs)


def load_fixed_broadcast(path: str):
    warnings.warn(
        "fixed_broadcast_io is deprecated; use broadcast_api.save_fixed_broadcast/load_fixed_broadcast",
        DeprecationWarning,
        stacklevel=2,
    )
    data = np.load(path, allow_pickle=True)
    pdd_tuple = tuple(data[f"pdd{i}"] for i in range(4))  # type: ignore
    xaj_tuple = tuple(data[f"xaj{i}"] for i in range(17))  # type: ignore
    msk_layers_params = list(data["msk_layers_params"].tolist())
    C_mats = list(data["C_mats"].tolist())
    merged_model = None
    if "merged_model_json" in data.files:
        import json
        merged_model = json.loads(data["merged_model_json"].tolist()[0])
    return merged_model, pdd_tuple, xaj_tuple, {"msk_layers_params": msk_layers_params, "C_mats": C_mats}

