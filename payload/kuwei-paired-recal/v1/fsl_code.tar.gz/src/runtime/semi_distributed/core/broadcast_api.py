from __future__ import annotations
from typing import Callable, Dict, Any, Tuple, Optional
import numpy as np

from src.runtime.semi_distributed.core.params import (
    prepare_model_params,
    vector_to_params,
)
try:
    # Re-export IO helpers so callers can use a single entry (recommended)
    from src.runtime.semi_distributed.core.fixed_broadcast_io import save_fixed_broadcast, load_fixed_broadcast  # noqa: F401
except Exception:
    # Optional: if IO helpers are unavailable, skip silently.
    pass

Broadcaster = Callable[[np.ndarray, Dict[str, Any], Dict[str, Any], tuple], Tuple[Dict[str, Any], tuple, tuple, Dict[str, Any]]]
# 返回: (merged_model, pdd_tuple, xaj_tuple, core_args)


class DefaultBroadcaster:
    def __call__(
        self,
        vec: np.ndarray,
        calib_cfg: Dict[str, Any],
        model_tpl: Dict[str, Any],
        geo_info: tuple,
    ) -> Tuple[Dict[str, Any], tuple, tuple, Dict[str, Any]]:
        grid2sub, sub_area, connection_matrices, _ = geo_info
        Ns = int(sub_area.shape[0])
        param_dict = vector_to_params(vec, calib_cfg, Ns)
        merged_model, pdd_tuple, xaj_tuple, _msk_layers_params, core_args = prepare_model_params(
            param_dict=param_dict,
            model_params_template=model_tpl,
            calibration_config=calib_cfg,
            grid2sub=grid2sub,
            sub_area=sub_area,
            connection_matrices=connection_matrices,
            param_mode={
                "msk_params": {"*": "sub"},
                "xaj_params": {"*": "basin"},
                "pdd_params": {"*": "basin"},
            },
        )
        return merged_model, pdd_tuple, xaj_tuple, core_args

def make_default_broadcaster() -> Broadcaster:
    """构建默认广播器：vec -> param_dict -> prepare_model_params。"""
    return DefaultBroadcaster()


class FixedBroadcaster:
    def __init__(self, merged_model: Optional[Dict[str, Any]], pdd_tuple: tuple, xaj_tuple: tuple, core_args: Dict[str, Any]):
        self.merged_model = merged_model
        self.pdd_tuple = pdd_tuple
        self.xaj_tuple = xaj_tuple
        self.core_args = core_args

    def __call__(
        self,
        vec: np.ndarray,
        calib_cfg: Dict[str, Any],
        model_tpl: Dict[str, Any],
        geo_info: tuple,
    ) -> Tuple[Dict[str, Any], tuple, tuple, Dict[str, Any]]:
        return (self.merged_model or model_tpl), self.pdd_tuple, self.xaj_tuple, self.core_args

def make_fixed_broadcaster(
    *,
    merged_model: Optional[Dict[str, Any]] = None,
    pdd_tuple: tuple,
    xaj_tuple: tuple,
    core_args: Dict[str, Any],
) -> Broadcaster:
    """构建固定广播器：忽略 vec，直接回传给定的 (pdd_tuple, xaj_tuple, core_args)。"""
    return FixedBroadcaster(merged_model, pdd_tuple, xaj_tuple, core_args)

