from __future__ import annotations
from typing import Dict, Any, Tuple, List, Optional
import numpy as np
import yaml
import pandas as pd
from pathlib import Path

from src.runtime.semi_distributed.core.optimization_config import OptimizationConfig
from src.runtime.semi_distributed.params import (
    prepare_model_params, 
    prepare_initial_state, 
    vector_to_params,
    compute_muskingum_coefficients,
    compute_n_sub_from_K
)

# Import read_obs_discharge_csv from tools
try:
    from tools.data_preparation.process_cmfd_data.subbasin.step04_read_observed_discharge import read_obs_discharge_csv
except ImportError:
    # Fallback or mock if tool is not in python path
    def read_obs_discharge_csv(path):
        return pd.read_csv(path)

def parse_model_params_dict(config: Dict, num_units: int, param_levels: Dict[str, Dict[str, str]]) -> Dict[str, Dict[str, np.ndarray]]:
    param_dict = {
        'basin_params': {},
        'xaj_params': {},
        'msk_params': {},
        'pdd_params': {}
    }

    for module in param_dict.keys():
        if module not in config:
            continue
        module_dict = {}
        for param, value in config[module].items():
            # 跳过非数值元数据字段（如 pdd_version）
            if isinstance(value, str) and not value.replace('.', '', 1).replace('-', '', 1).isdigit():
                module_dict[param] = value
                continue
            # 获取参数级别，默认 "basin"
            module_map = param_levels.get(module, {})
            level = module_map.get(param, module_map.get("*", "basin"))
            if not isinstance(value, list):
                value = [value]
            if level == "sub":
                if len(value) == 1:
                    value = value * num_units  # 单值扩展到 Ns
                elif len(value) != num_units:
                    raise ValueError(f"子流域级参数 {module}.{param} 长度必须为 {num_units}，实际为 {len(value)}")
                module_dict[param] = np.array(value, dtype=np.float32)
            else:  # 流域级
                if len(value) != 1:
                    raise ValueError(f"流域级参数 {module}.{param} 必须为单值，实际为 {len(value)}")
                module_dict[param] = np.float32(value[0])
            # 特殊处理 num_subreaches
            if param == "num_subreaches":
                module_dict[param] = np.array(value, dtype=np.int32)
        param_dict[module] = module_dict

    # XAJ 衍生参数（保持不变）
    if 'xaj_params' in param_dict and 'basin_params' in param_dict:
        xaj = param_dict['xaj_params']
        basin = param_dict['basin_params']
        required_params = ['wum', 'wlm', 'wdm', 'b', 'imp', 'sm', 'ex']
        if missing := [p for p in required_params if p not in xaj]:
            pass
        
        # 如果有 area，计算 uf
        if 'area' in basin:
            xaj['uf'] = basin['area'] / 3.6
        
        # 计算 wm, wmm, ms 如果相关参数存在
        if all(k in xaj for k in ['wum', 'wlm', 'wdm']):
            xaj['wm'] = xaj['wum'] + xaj['wlm'] + xaj['wdm']
            if all(k in xaj for k in ['b', 'imp']):
                xaj['wmm'] = xaj['wm'] * (1 + xaj['b']) / (1 - xaj['imp'])
        
        if all(k in xaj for k in ['sm', 'ex']):
            xaj['ms'] = xaj['sm'] * (1 + xaj['ex'])

    # Load msk_layers if present (raw list of dicts)
    if 'msk_layers' in config:
        param_dict['msk_layers'] = config['msk_layers']

    return param_dict

def load_model_params_from_yaml(yaml_path: str, num_units: int, param_levels: Dict[str, Dict[str, str]]) -> Dict[str, Dict[str, np.ndarray]]:
    """
    从 YAML 文件加载模型参数，支持流域级和子流域级。
    """
    with open(yaml_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)

    return parse_model_params_dict(config, num_units, param_levels)


def parse_calibration_config_dict(cfg: Dict, num_basins: int | None = None) -> Dict:
    # 向后兼容：如果外部没传 num_basins，就直接返回旧结构
    if num_basins is None:
        return cfg

    # ---------- 生成 index_map ----------
    index_map = []
    if "calibrate_params" in cfg:
        for p in cfg["calibrate_params"]:
            lvl = p.get("level", "basin")
            if lvl == "sub":
                if "index" in p:                       # 只调一个子流域
                    index_map.append((p, p["index"]))
                else:                                  # 调整全部 Ns
                    index_map.extend([(p, i) for i in range(num_basins)])
            else:                                      # basin / grid
                index_map.append((p, None))

        cfg["index_map"]   = index_map
        cfg["vector_size"] = len(index_map)
    return cfg

def load_calibration_config(
        yaml_path: str,
        num_basins: int | None = None
) -> Dict:
    """
    读取校准 YAML，并生成:
      - cfg["index_map"] : [(param_dict, idx), ...]
      - cfg["vector_size"] : 待优化向量长度
    若 num_basins=None → 不生成 index_map（保持旧行为）
    """
    with open(yaml_path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    return parse_calibration_config_dict(cfg, num_basins)


def setup_model_and_config(
    cfg: OptimizationConfig, 
    Ns: int, 
    msk_layers: List[Dict], 
    Ng: int
) -> Tuple[Dict, Dict, Dict]:
    """
    加载模型参数模板、校准配置和初始状态。
    
    Args:
        cfg: 优化配置对象
        Ns: 子流域数量
        msk_layers: Muskingum 分层拓扑结构
        Ng: 网格单元数量
        
    Returns:
        (model_params, calib_cfg, init_cond)
    """
    # --- 模型参数模板 ---
    # 定义参数级别
    param_levels = {
        # ───────── Muskingum ──────────
        "msk_params": {
            "*": "sub",               # 默认仍是子流域级
            "c0_outlet": "basin",     # ★ 指明出口层 3 个是 basin 级
            "c1_outlet": "basin",
            "num_subreaches_outlet": "basin",
        },
        # ───────── 其它保持不变 ────────
        "xaj_params": {"*": "basin"},
        "pdd_params": {"*": "basin"},
        "basin_params": {"area": "sub"},
    }
    
    # Resolve pdd_xaj_params.yml — deterministic search, NO cross-basin fallback.
    basin = getattr(cfg, "BASIN_NAME", None) or getattr(cfg, "SECTION_NAME", None)
    
    inline_pdd = getattr(cfg, "INLINE_PDD_XAJ", None)
    if inline_pdd is not None:
        model_params = parse_model_params_dict(
            inline_pdd,
            num_units=Ns,
            param_levels=param_levels,
        )
    else:
        _pdd_candidates = [
            cfg.CONFIG_DIR / "pdd_xaj_params.yml",
            cfg.CONFIG_DIR / "basin_params" / "semi_distributed" / "pdd_xaj_params.yml",
        ]
        if basin:
            _pdd_candidates.append(cfg.PROJECT_ROOT / f"basins/{basin}/config/basin_params/semi_distributed/pdd_xaj_params.yml")
            _pdd_candidates.append(cfg.PROJECT_ROOT / f"basins/{basin}/config/pdd_xaj_params.yml")
        pdd_xaj_path = None
        for _p in _pdd_candidates:
            if _p.exists():
                pdd_xaj_path = _p
                break
        if pdd_xaj_path is None:
            raise FileNotFoundError(
                f"pdd_xaj_params.yml not found. basin={basin}, CONFIG_DIR={cfg.CONFIG_DIR}\n"
                f"Searched: {[str(p) for p in _pdd_candidates]}"
            )
    
        model_params = load_model_params_from_yaml(
            str(pdd_xaj_path),
            num_units=Ns,
            param_levels=param_levels,
        )
    
    # Merge msk_layers from topology and params
    topo_layers = msk_layers
    param_layers = model_params.get('msk_layers', [])
    
    merged_layers = []
    for t_layer in topo_layers:
        # Find matching p_layer
        # Match by index equality?
        t_idx = set(t_layer['index'])
        matched = False
        for p_layer in param_layers:
            p_idx = set(p_layer.get('index', []))
            if t_idx == p_idx:
                # Merge
                merged = t_layer.copy()
                merged.update(p_layer) # Params overwrite topology (except index which is same)
                merged_layers.append(merged)
                matched = True
                break
        if not matched:
            print(f"[DEBUG] No matching params for layer index {t_idx}. Available: {[p.get('index') for p in param_layers]}")
            # Use topology layer (missing params will be NaN or default)
            merged_layers.append(t_layer)
            
    model_params['msk_layers'] = merged_layers
    
    # Debug check
    for layer in model_params['msk_layers']:
        if 'K' in layer:
            k_val = layer['K']
            if np.any(np.isnan(np.array(k_val, dtype=np.float32))):
                 print(f"[DEBUG] NaN in default params K: {k_val}")

    # --- 校准配置 ---

    # --- 校准配置 ---
    inline_calib = getattr(cfg, "INLINE_CALIB", None)
    if inline_calib is not None:
        calib_cfg = parse_calibration_config_dict(
            inline_calib,
            num_basins=Ns
        )
    else:
        # Resolve calibration_params — deterministic search, NO cross-basin fallback.
        _calib_candidates = [
            cfg.CONFIG_DIR / "calibration_params_hourly.yml",
            cfg.CONFIG_DIR / "basin_params" / "semi_distributed" / "calibration_params_hourly.yml",
        ]
        if basin:
            _calib_candidates.append(cfg.PROJECT_ROOT / f"basins/{basin}/config/basin_params/semi_distributed/calibration_params_hourly.yml")
            _calib_candidates.append(cfg.PROJECT_ROOT / f"basins/{basin}/config/calibration_params.yml")
        calib_path = None
        for _c in _calib_candidates:
            if _c.exists():
                calib_path = _c
                break
        if calib_path is None:
            raise FileNotFoundError(
                f"calibration_params not found. basin={basin}, CONFIG_DIR={cfg.CONFIG_DIR}\n"
                f"Searched: {[str(p) for p in _calib_candidates]}"
            )
    
        calib_cfg = load_calibration_config(
            str(calib_path),
            num_basins=Ns
        )

    # --- 初始状态 ---
    # Priority: YAML initial_conditions > model-param-derived 50% capacity > small defaults
    init_cond: Dict[str, Any] = {}

    # 1. Use YAML initial_conditions if available
    inline_ic = getattr(cfg, "INLINE_INITIAL_CONDITIONS", None)
    if isinstance(inline_ic, dict):
        xaj_init = inline_ic.get("xaj_initial", inline_ic)
        if isinstance(xaj_init, dict):
            init_cond.update(xaj_init)

    # 2. Fill soil moisture gaps with 50% of model capacity
    xaj_defaults = model_params.get("xaj_params", {})
    capacity_defaults = {
        "WU": float(xaj_defaults.get("wum", 30)) * 0.5,
        "WL": float(xaj_defaults.get("wlm", 60)) * 0.5,
        "WD": float(xaj_defaults.get("wdm", 20)) * 0.5,
        "S": float(xaj_defaults.get("sm", 20)) * 0.2,
    }
    for key, default_val in capacity_defaults.items():
        if key not in init_cond:
            init_cond[key] = default_val

    # 3. Small non-zero defaults for flow states (overridden by observed Q in forecast_runner)
    flow_defaults = {"QS": 0.1, "QI": 0.5, "QG": 2.0}
    for key, default_val in flow_defaults.items():
        if key not in init_cond:
            init_cond[key] = default_val

    return model_params, calib_cfg, init_cond

