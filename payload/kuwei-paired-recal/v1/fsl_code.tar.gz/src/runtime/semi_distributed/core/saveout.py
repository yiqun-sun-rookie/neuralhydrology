from src.runtime.semi_distributed.core.optimization_config import OptimizationConfig
import os
import json
import csv
import pickle
import yaml
import numpy as np
from typing import Dict, Any, List
from src.runtime.semi_distributed.core.topology import build_msk_layers_and_connect_mat
from src.runtime.semi_distributed.core.params import (
    compute_muskingum_coefficients,
    compute_n_sub_from_K,
)
from datetime import datetime

def save_results(best_params: Dict, best_nse: float, cfg: "OptimizationConfig", init_cond: Dict[str, Any] = None):
    """保存最优参数到 Pickle 和 YAML 文件 + 扩展面积统计输出"""
    print("\n================= Optimization DONE =================")
    print(f"最优 NSE: {best_nse:.4f}")
    print("最优参数字典:")
    for k, v in best_params.items():
        # 打印时对长数组进行截断，避免刷屏
        v_repr = repr(v)
        if len(v_repr) > 100:
            v_repr = v_repr[:100] + "..."
        print(f"  {k}: {v_repr}")

    # --- 面积统计 (若存在) ---
    area_info: Dict[str, Any] | None = None
    try:
        areas = np.asarray(best_params.get('basin_params', {}).get('area', []), dtype=float)
        if areas.size > 0:
            uf_vals = np.asarray(best_params.get('xaj_params', {}).get('uf', []), dtype=float)
            area_info = {
                'source': 'sub_area.csv',  # 现已唯一来源
                'n_sub': int(areas.size),
                'sum_area': float(areas.sum()),
                'mean_area': float(areas.mean()),
                'min_area': float(areas.min()),
                'max_area': float(areas.max()),
                'uf_rule': 'uf = area / 3.6',
                'has_uf': bool(uf_vals.size == areas.size),
            }
            if uf_vals.size == areas.size:
                area_info['mean_uf'] = float(uf_vals.mean())
            print(f"[AREA] sum={area_info['sum_area']:.3f} mean={area_info['mean_area']:.3f} min={area_info['min_area']:.3f} max={area_info['max_area']:.3f}")
    except Exception as e:
        print(f"[WARN] 面积统计失败: {e}")

    # --- 统一输出目录与文件名（包含 NSE） ---
    out_dir = cfg.OUTPUT_DIR
    os.makedirs(out_dir, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    nse_str = f"{best_nse:.4f}" if np.isfinite(best_nse) else "nan"
    base = f"best_params_{cfg.SECTION_NAME}_nse{nse_str}"

    # --- 保存为 Pickle（只保存带时间戳的版本，避免重复） ---
    pkl_path = os.path.join(out_dir, base + f"_{ts}.pkl")
    
    # 创建包含参数和初始条件的完整数据包
    complete_data = {
        'best_params': best_params,
        'init_cond': init_cond,
        'metadata': {
            'nse': float(best_nse) if np.isfinite(best_nse) else None,
            'timestamp': ts,
            'section': cfg.SECTION_NAME,
            'area_info': area_info
        }
    }
    
    with open(pkl_path, "wb") as f:
        pickle.dump(complete_data, f)
    print(f"\n[SAVE] 参数和初始条件已保存到 {pkl_path}")

    # --- 保存为 YAML (只保存一个版本，避免重复) ---
    yml_path = os.path.join(out_dir, base + f"_{ts}.yml")
    try:
        params_to_dump = best_params.copy()
        # 规范化 msk_layers
        if "msk_layers" in params_to_dump:
            layers = params_to_dump["msk_layers"]
            needs_inject = any("index" not in layer for layer in layers)
            if needs_inject:
                layers_with_idx, _ = build_msk_layers_and_connect_mat(cfg)
            else:
                layers_with_idx = layers
            # 检查全局或各层的 segmented 标志
            msk_segmented = bool(params_to_dump.get("msk_segmented", False))
            dt_hours = float(getattr(cfg, 'DT_HOURS', None) or 24.0)

            normalized_layers = []
            for li, layer in enumerate(layers):
                # 索引
                if "index" in layer:
                    idx = np.asarray(layer["index"], dtype=int)
                else:
                    idx = np.asarray(layers_with_idx[li]["index"], dtype=int)
                size = len(idx)

                # 字段广播辅助函数
                def _as_arr(val, dtype):
                    arr = np.asarray(val, dtype=dtype)
                    if arr.ndim == 0:
                        return np.full(size, arr.item(), dtype=dtype)
                    return arr.astype(dtype, copy=False)

                layer_segmented = bool(layer.get("segmented", msk_segmented))
                layer_dt = float(layer.get("dt_hours", dt_hours))

                # [FIX] 若 c0/c1 已由优化器直接校准, 优先保存校准值
                # 只有在无 c0/c1 时才从 K/X 重新计算
                if "c0" in layer and "c1" in layer:
                    c0 = _as_arr(layer["c0"], np.float32)
                    c1 = _as_arr(layer["c1"], np.float32)
                    nsub = _as_arr(layer.get("n_sub", 1), np.int32)
                elif "K" in layer and "X" in layer:
                    K_arr = _as_arr(layer["K"], np.float32)
                    X_arr = _as_arr(layer["X"], np.float32)
                    c0_list, c1_list, nsub_list = [], [], []
                    for i in range(size):
                        K_i, X_i = float(K_arr[i]), float(X_arr[i])
                        # 计算 n_sub
                        if "n_sub" in layer:
                            n_i = int(round(float(_as_arr(layer["n_sub"], np.float32)[i])))
                        else:
                            n_i = compute_n_sub_from_K(K_i, layer_dt)
                        n_i = max(1, n_i)
                        # 分段系数：K_eff = K / n_sub（若启用分段）
                        K_eff = K_i / float(n_i) if layer_segmented else K_i
                        c0_i, c1_i, _ = compute_muskingum_coefficients(K_eff, X_i, layer_dt)
                        c0_list.append(c0_i)
                        c1_list.append(c1_i)
                        nsub_list.append(n_i)
                    c0 = np.array(c0_list, dtype=np.float32)
                    c1 = np.array(c1_list, dtype=np.float32)
                    nsub = np.array(nsub_list, dtype=np.int32)
                else:
                    # 直接使用 c0/c1/n_sub（若无则用默认值，但这不是推荐做法）
                    c0 = _as_arr(layer.get("c0", 0.2), np.float32)
                    c1 = _as_arr(layer.get("c1", 0.6), np.float32)
                    nsub = _as_arr(layer.get("n_sub", 1), np.int32)

                normalized_layers.append({
                    "index": idx,
                    "c0": c0,
                    "c1": c1,
                    "n_sub": nsub,
                })
            params_to_dump["msk_layers"] = normalized_layers
        # 注入 area_info
        payload_section = to_builtin_types(params_to_dump)
        if area_info is not None:
            payload_section['area_info'] = to_builtin_types(area_info)
        payload = {cfg.SECTION_NAME: payload_section}
        with open(yml_path, "w", encoding="utf-8") as f:
            yaml.safe_dump(payload, f, allow_unicode=True, sort_keys=False)
        print(f"[SAVE] 参数已保存到 {yml_path}")
    except Exception as e:
        print(f"[WARN] 保存到 {yml_path} 失败: {e}")

    # --- 摘要导出（只保存一个版本） ---
    try:
        # 1) summary（json）
        summary = {
            "section": cfg.SECTION_NAME,
            "timestamp": ts,
            "nse": float(best_nse) if np.isfinite(best_nse) else None,
            "xaj_params": {k: float(v) if np.ndim(v) == 0 else to_builtin_types(v) for k, v in best_params.get("xaj_params", {}).items() if k in ("kc", "ki", "kg", "cs", "ci", "cg", "wum", "wlm", "wdm", "b", "sm")},
            "pdd_params": {k: (v if isinstance(v, str) else (float(v) if np.ndim(v) == 0 else to_builtin_types(v))) for k, v in best_params.get("pdd_params", {}).items()},
        }
        if area_info is not None:
            summary['area_info'] = area_info
        # 写 json
        json_path = os.path.join(out_dir, f"summary_{cfg.SECTION_NAME}_{ts}.json")
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        print(f"[SAVE] 摘要已保存到 {json_path}")

        # 面积逐子流域 CSV（只在需要时保存）
        if area_info is not None and areas.size > 0:
            uf_vals = np.asarray(best_params.get('xaj_params', {}).get('uf', []), dtype=float)
            frac = areas / areas.sum() if areas.sum() > 0 else np.zeros_like(areas)
            area_rows = []
            for i in range(areas.size):
                row = [i, float(areas[i])]
                if uf_vals.size == areas.size:
                    row.append(float(uf_vals[i]))
                else:
                    row.append('')
                row.append(float(frac[i]))
                area_rows.append(row)
            cols = ["sub_index", "area", "uf", "area_fraction"]
            area_csv = os.path.join(out_dir, f"areas_{cfg.SECTION_NAME}_{ts}.csv")
            with open(area_csv, 'w', newline='', encoding='utf-8') as f:
                w = csv.writer(f)
                w.writerow(cols)
                w.writerows(area_rows)
            print(f"[SAVE] 面积明细已保存到 {area_csv}")

    except Exception as e:
        print(f"[WARN] 导出摘要失败: {e}")


def to_builtin_types(obj: Any) -> Any:
    """
    递归将 NumPy 类型转换为纯 Python 类型，以便序列化 (如存为 YAML)。
    """
    if isinstance(obj, (np.floating, np.integer)):
        return obj.item()
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, dict):
        return {k: to_builtin_types(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [to_builtin_types(x) for x in obj]
    return obj

