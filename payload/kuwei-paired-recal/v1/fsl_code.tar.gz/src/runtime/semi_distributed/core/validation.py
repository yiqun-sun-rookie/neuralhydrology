from __future__ import annotations
"""validation.py
Phase6: 率定前校验与可达性分析 + Phase7: 可选参数裁剪。

提供功能:
  collect_context(...) -> dict 包含拓扑、可达集合、映射等
  run_validations(ctx) -> list[Issue]
  prune_calibration(ctx, calib_cfg) -> (changed:boolean, report_dict)

Issue taxonomy (更新):
  ERROR:
    E1 eval_station 名称不在拓扑名称集合
    E2 eval_station=outlet_series 但最后一层节点列表为空
    E3 校验到 index_map 中引用的 layer/node 越界
  WARN:
    W_UP 评价站不在最后一层 (允许上游评价)
    W1 评价站不在率定节点集合 (可能导致拟合不到该站)
    W2 存在不可达的 layer_node 参数 (将被裁剪)
    W3 覆写测站包含评价站 (未来冲突提醒)

可达性规则:
  outlet_series: 评价集合为最后一层全部节点 -> 反向 BFS 取得所有上游
  单站: 评价集合为该站节点 -> 反向 BFS 取得上游

参数裁剪 (Phase7): 仅裁剪 Muskingum layer_node 级别参数 (不在可达上游集合)。
"""
from dataclasses import dataclass, asdict
from typing import List, Dict, Any, Set, Tuple
import json, os, time, os as _os
import numpy as np


@dataclass
class Issue:
    code: str
    level: str  # 'ERROR' or 'WARN'
    message: str

    def to_dict(self):
        return asdict(self)


def _build_layer_maps(msk_layers: List[Dict[str, Any]]):
    """Return helper mappings.
    layer_to_global: list[list[int]] where entries are global basin ids per layer position.
    name_to_global: dict[name]->global id (if names present)
    last_layer_names: list[str]
    """
    layer_to_global: List[List[int]] = []
    name_to_global: Dict[str, int] = {}
    last_layer_names: List[str] = []
    for li, layer in enumerate(msk_layers):
        idx = list(map(int, layer.get('index', [])))
        layer_to_global.append(idx)
        # 原实现: names = layer.get('names') or [] 会对 numpy.ndarray 触发模糊布尔 ValueError
        names = layer.get('names')
        if names is None:
            names = []
        elif isinstance(names, np.ndarray):  # 转为 Python 列表
            names = names.tolist()
        # 其余类型若不是 list/tuple，忽略 (保持空列表)
        if not isinstance(names, (list, tuple)):
            names = []
        for pos, nm in enumerate(names):
            if nm is None:
                continue
            if pos < len(idx):
                name_to_global[nm] = idx[pos]
        if li == len(msk_layers) - 1:
            last_layer_names = list(names)
    return layer_to_global, name_to_global, last_layer_names


def _reverse_adjacency(connection_matrices, layer_to_global) -> Dict[int, Set[int]]:
    """Build reverse adjacency: downstream global id -> set(upstream global id).

    兼容两种矩阵布局:
      A) shape == (n_up, n_dn)   行=上游, 列=下游 (旧假设)
      B) shape == (n_dn, n_up)   行=下游, 列=上游 (当前 topology.py 生成)
    任何其它形状将被跳过。
    """
    rev: Dict[int, Set[int]] = {}
    for li, C in enumerate(connection_matrices):
        try:
            arr = np.asarray(C)
        except Exception:
            continue
        if arr.ndim != 2:
            continue
        if li >= len(layer_to_global) - 1:
            break
        up_ids = layer_to_global[li]
        dn_ids = layer_to_global[li + 1]
        n_up_expected = len(up_ids)
        n_dn_expected = len(dn_ids)
        r, c = arr.shape
        # 情况 A: (n_up, n_dn)
        if r == n_up_expected and c == n_dn_expected:
            for uj, up_gid in enumerate(up_ids):
                row = arr[uj]
                for dj, val in enumerate(row):
                    if val > 0:
                        dn_gid = dn_ids[dj]
                        rev.setdefault(dn_gid, set()).add(up_gid)
        # 情况 B: (n_dn, n_up) —— 需要转置解释
        elif r == n_dn_expected and c == n_up_expected:
            for dj, dn_gid in enumerate(dn_ids):
                row = arr[dj]
                for uj, val in enumerate(row):
                    if val > 0:
                        up_gid = up_ids[uj]
                        rev.setdefault(dn_gid, set()).add(up_gid)
        else:
            # 形状不匹配，跳过该矩阵
            continue
    return rev


def _bfs_upstream(target_global_ids: Set[int], rev_adj: Dict[int, Set[int]]) -> Set[int]:
    visited = set(target_global_ids)
    stack = list(target_global_ids)
    while stack:
        cur = stack.pop()
        ups = rev_adj.get(cur)
        if not ups:
            continue
        for u in ups:
            if u not in visited:
                visited.add(u)
                stack.append(u)
    return visited


def collect_context(cfg, msk_layers, connection_matrices, calib_cfg, eval_station: str, override_stations):
    layer_to_global, name_to_global, last_layer_names = _build_layer_maps(msk_layers)
    # target global ids (支持 CALIB_SCOPE_SELECTOR 覆盖)
    target_globals: Set[int] = set()
    scope_sel = getattr(cfg, 'CALIB_SCOPE_SELECTOR', None)
    if isinstance(scope_sel, dict):
        if 'ids' in scope_sel and isinstance(scope_sel['ids'], (list, tuple)):
            try:
                target_globals = {int(x) for x in scope_sel['ids']}
            except Exception:
                target_globals = set()
        elif 'names' in scope_sel and isinstance(scope_sel['names'], (list, tuple)):
            for nm in scope_sel['names']:
                if nm in name_to_global:
                    target_globals.add(name_to_global[nm])
        # 若显式指定后为空，则继续走默认 eval_station 逻辑
    if not target_globals:
        if eval_station == 'outlet_series':
            # 全部最后一层节点
            if layer_to_global:
                target_globals = set(layer_to_global[-1])
        else:
            if eval_station in name_to_global:
                target_globals = {name_to_global[eval_station]}
    rev_adj = _reverse_adjacency(connection_matrices, layer_to_global)
    reachable_upstream = _bfs_upstream(target_globals, rev_adj) if target_globals else set()

    # collect layer_node specs -> list[(layer_i, node_pos, global_id, spec_idx)]
    idx_map = calib_cfg.get('index_map') if isinstance(calib_cfg, dict) else None
    layer_node_specs: List[Tuple[int,int,int,int]] = []
    if isinstance(idx_map, list):
        for si, (spec, idx) in enumerate(idx_map):
            lvl = spec.get('level') if isinstance(spec, dict) else None
            if lvl == 'layer_node' and isinstance(idx, tuple) and len(idx) == 2:
                layer_i, node_j = idx
                try:
                    gid = layer_to_global[layer_i][node_j]
                except Exception:
                    gid = -1
                layer_node_specs.append((layer_i, node_j, gid, si))
    return {
        'layer_to_global': layer_to_global,
        'name_to_global': name_to_global,
        'last_layer_names': last_layer_names,
        'target_globals': target_globals,
        'reachable_upstream_ids': reachable_upstream,
        'layer_node_specs': layer_node_specs,
        'override_stations': override_stations,
        'eval_station': eval_station,
        'calib_idx_map': calib_cfg.get('index_map') if isinstance(calib_cfg, dict) else None,
        'calib_cfg': calib_cfg,
        'cfg': cfg,
    }


def run_validations(ctx) -> List[Issue]:
    issues: List[Issue] = []
    eval_station = ctx['eval_station']
    last_layer_names = ctx['last_layer_names']
    target_globals = ctx['target_globals']
    layer_node_specs = ctx['layer_node_specs']
    reachable = ctx['reachable_upstream_ids']
    override_stations = ctx['override_stations']
    calib_idx_map = ctx['calib_idx_map']
    name_to_global = ctx.get('name_to_global', {})

    # E1/E2 & W_UP: 评价站合法性
    if eval_station != 'outlet_series':
        if eval_station not in name_to_global:
            issues.append(Issue('E1', 'ERROR', f'eval_station={eval_station} 不在拓扑名称集合'))
        else:
            if eval_station not in last_layer_names:
                issues.append(Issue('W_UP','WARN', f'eval_station={eval_station} 非最后一层 (允许上游评价)'))
    else:
        if not last_layer_names:
            issues.append(Issue('E2', 'ERROR', 'outlet_series 模式但最后一层节点列表为空'))

    # W1: 评价站不在率定节点集合 (仅当存在 names 过滤)
    if isinstance(calib_idx_map, list):
        calib_layer_gids = {gid for (_,_,gid,_) in layer_node_specs if gid >=0}
        if eval_station != 'outlet_series' and eval_station in name_to_global:
            egid = name_to_global[eval_station]
            if egid not in calib_layer_gids:
                issues.append(Issue('W1','WARN', f'eval_station {eval_station} 对应节点未出现在率定 layer_node 参数集合中'))

    # E3 / W2: index_map 越界或不可达 (去重同一 gid 的重复 W2)
    seen_w2: Set[int] = set()
    for layer_i, node_j, gid, si in layer_node_specs:
        if gid < 0:
            issues.append(Issue('E3','ERROR', f'index_map 第{si}项 layer_node ({layer_i},{node_j}) 越界'))
        elif eval_station != 'outlet_series' and gid not in reachable:
            if gid not in seen_w2:
                issues.append(Issue('W2','WARN', f'参数 layer_node({layer_i},{node_j}) global={gid} 不在评价站上游可达集合内'))
                seen_w2.add(gid)
        elif eval_station == 'outlet_series' and gid not in reachable:
            if gid not in seen_w2:
                issues.append(Issue('W2','WARN', f'参数 layer_node({layer_i},{node_j}) global={gid} 不在出口聚合可达集合内'))
                seen_w2.add(gid)

    # W3: 覆写站点包含评价站
    if override_stations is not None:
        try:
            _ov_list = list(override_stations)
        except Exception:
            _ov_list = []
        if len(_ov_list) > 0 and eval_station in _ov_list:
            issues.append(Issue('W3','WARN', f'eval_station={eval_station} 同时出现在 override_stations，可能导致评价信号被覆写'))

    # FLOW_SOURCE 与评价站层级冲突 (保留原逻辑，新增 'from_anchor' 忽略)
    flow_source = getattr(ctx['cfg'], 'FLOW_SOURCE_STATION', None)
    if isinstance(flow_source, str):
        fs = flow_source.strip().lower()
        # outlet_series / outlet 是特殊标志（最后一层聚合），不是站点名
        if fs in ('from_anchor', '', 'none', 'null', 'auto', 'outlet', 'outlet_series'):
            flow_source = None
    if flow_source and eval_station and flow_source != eval_station:
        # 下游目标 + 上游 flow_source => ERROR
        if eval_station in last_layer_names and flow_source not in last_layer_names:
            issues.append(Issue('E4','ERROR', f'flow_source={flow_source} 为上游站而 eval_station={eval_station} 在最后一层 (禁止)'))
        # 上游目标 + 下游 flow_source => WARN (聚合评价)
        if eval_station not in last_layer_names and flow_source in last_layer_names:
            issues.append(Issue('W4','WARN', f'上游评价站 {eval_station} 使用下游 flow_source={flow_source} (聚合序列)'))

    return issues


def write_validation_report(cfg, issues: List[Issue]):
    out_dir = cfg.OUTPUT_DIR
    try:
        os.makedirs(out_dir, exist_ok=True)
        rpt = {
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'issues': [i.to_dict() for i in issues],
            'counts': {
                'ERROR': sum(1 for i in issues if i.level=='ERROR'),
                'WARN': sum(1 for i in issues if i.level=='WARN'),
            }
        }
        with open(out_dir / 'validation_report.json','w',encoding='utf-8') as f:
            json.dump(rpt, f, ensure_ascii=False, indent=2)
    except Exception as e:  # noqa: BLE001
        print(f'[WARN] 写 validation_report.json 失败: {e}')


def prune_calibration(ctx, calib_cfg) -> Tuple[bool, Dict[str,Any]]:
    cfg = ctx['cfg']
    if getattr(cfg, 'NO_PRUNE', False) or _os.environ.get('NO_PRUNE') == '1':
        return False, {'skipped': True, 'reason': 'NO_PRUNE set'}
    idx_map = calib_cfg.get('index_map') if isinstance(calib_cfg, dict) else None
    if not isinstance(idx_map, list):
        return False, {'skipped': True, 'reason': 'legacy/no-index-map'}
    reachable = ctx['reachable_upstream_ids']
    eval_station = ctx['eval_station']
    # outlet_series -> reachable 包含全部最后一层及其上游; 若为空则不裁剪
    if not reachable:
        return False, {'skipped': True, 'reason': 'empty-reachable'}
    removed = []
    new_idx_map = []
    for spec, idx in idx_map:
        if spec.get('level') == 'layer_node' and isinstance(idx, tuple) and len(idx)==2:
            layer_i, node_j = idx
            try:
                gid = ctx['layer_to_global'][layer_i][node_j]
            except Exception:
                gid = None
            if gid is not None and gid not in reachable:
                removed.append({'spec': spec, 'idx': idx, 'global_id': gid})
                continue
        new_idx_map.append((spec, idx))
    changed = len(removed) > 0
    if changed:
        calib_cfg['index_map'] = new_idx_map
        calib_cfg['vector_size'] = len(new_idx_map)
    report = {
        'changed': changed,
        'removed_count': len(removed),
        'removed': removed,
        'remaining': len(new_idx_map),
        'reachable_size': len(reachable),
        'eval_station': eval_station,
    }
    if changed:
        try:
            with open(cfg.OUTPUT_DIR / 'pruned_params.json','w',encoding='utf-8') as f:
                json.dump(report, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f'[WARN] 写 pruned_params.json 失败: {e}')
    return changed, report

