"""
Warm-start state cache: full hourly state history from spin-up.

Single file per station: ``{station_id}_states.npz`` containing the
complete (T, Ng, 11) state grid + time index from a long-term spin-up.
Any future simulation loads the exact hourly state for its start time
— zero gap, zero warmup needed.

File format:
  - states:    np.ndarray (T, Ng, 11) float32
  - times_iso: np.ndarray of ISO 8601 strings, length T
  - dt_hours:  float

No fallbacks. No legacy modes. If the file doesn't exist, fail fast.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import numpy as np


# ---------------------------------------------------------------------------
# Save: called once during spin-up (SPINUP_SAVE_SNAPSHOTS=1)
# ---------------------------------------------------------------------------

def save_state_history(
    cache_dir: Path,
    station_id: str,
    states_grid: np.ndarray,
    time_index,
    dt_hours: float,
) -> Path:
    """Save the full hourly state history from a spin-up run.

    Parameters
    ----------
    cache_dir : Path
        Directory for the state file.
    station_id : str
        Station identifier (e.g. ``st001``).
    states_grid : np.ndarray
        Full state history ``(T, Ng, 11)`` from ``_simulate_core``.
    time_index : array-like
        Datetime-like sequence of length ``T``.
    dt_hours : float
        Model timestep in hours.

    Returns
    -------
    Path
        Path to the saved file.
    """
    import pandas as pd

    cache_dir = Path(cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)

    ti = pd.DatetimeIndex(time_index)
    n = min(len(ti), states_grid.shape[0])

    times_iso = np.array([t.isoformat() for t in ti[:n]], dtype="U32")

    out_path = cache_dir / f"{station_id}_states.npz"
    np.savez_compressed(
        out_path,
        states=states_grid[:n].astype(np.float32),
        times_iso=times_iso,
        dt_hours=np.array(dt_hours, dtype=np.float64),
    )
    return out_path


# ---------------------------------------------------------------------------
# Load: called every forecast run
# ---------------------------------------------------------------------------

_HISTORY_CACHE: dict[str, tuple[np.ndarray, np.ndarray]] = {}


def load_state(
    path: Path,
    current_start: datetime,
    dt_hours: float,
    max_gap_hours: float = 2.0,
) -> Optional[np.ndarray]:
    """Load the exact hourly state for *current_start* from spin-up history.

    Parameters
    ----------
    path : Path
        Legacy path (e.g. ``state_cache/st001.npz``). The function looks
        for ``{station_id}_states.npz`` in the same directory.
    current_start : datetime
        Simulation start time.
    dt_hours : float
        Model timestep in hours.
    max_gap_hours : float
        Maximum acceptable gap. Default 2h (rounding tolerance).

    Returns
    -------
    np.ndarray or None
        The (Ng, 11) state array, or None if no matching state found.
    """
    path = Path(path)
    cache_dir = path.parent
    station_id = path.stem
    history_path = cache_dir / f"{station_id}_states.npz"

    if not history_path.exists():
        return None  # Caller (run_once) will raise ValueError

    times, states = _load_history(history_path)
    if times is None:
        return None

    start = current_start
    if start.tzinfo is None:
        start = start.replace(tzinfo=timezone.utc)

    target_ts = start.timestamp()
    cached_ts = np.array([t.timestamp() for t in times])
    idx = np.searchsorted(cached_ts, target_ts, side="right") - 1

    if idx < 0:
        return None

    gap_hours = (target_ts - cached_ts[idx]) / 3600.0
    if gap_hours > max_gap_hours:
        return None

    return states[idx]


def _load_history(history_path: Path) -> tuple[np.ndarray | None, np.ndarray | None]:
    """Load and cache the full state history from disk."""
    key = str(history_path)
    if key in _HISTORY_CACHE:
        return _HISTORY_CACHE[key]

    try:
        data = np.load(history_path, allow_pickle=False)
        times_iso = data["times_iso"]
        states = data["states"]

        times = np.array([
            datetime.fromisoformat(s).replace(tzinfo=timezone.utc)
            if datetime.fromisoformat(s).tzinfo is None
            else datetime.fromisoformat(s)
            for s in times_iso
        ])

        _HISTORY_CACHE[key] = (times, states)
        return times, states
    except Exception:
        return None, None


# ---------------------------------------------------------------------------
# Legacy wrappers (spin-up only, called from run_once.py)
# ---------------------------------------------------------------------------

def save_state(path, state_grid, end_time, dt_hours):
    """No-op. Kept for import compatibility only."""
    pass


def save_snapshots(cache_dir, station_id, states_grid, time_index, dt_hours):
    """Redirect to save_state_history."""
    save_state_history(cache_dir, station_id, states_grid, time_index, dt_hours)
    return 1
