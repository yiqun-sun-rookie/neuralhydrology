"""Legacy forecast methods wrapped as providers."""
from __future__ import annotations

from datetime import datetime

import numpy as np
import pandas as pd

from src.runtime.semi_distributed.core.forecast_meteo_provider import (
    ForecastMeteoProvider,
    ForecastMeteoResult,
)


class PersistenceProvider(ForecastMeteoProvider):
    """Repeat last observed values for all forecast steps."""

    def __init__(self, last_rain=None, last_temp=None, last_snow=None, last_pet=None):
        self.last_rain = last_rain
        self.last_temp = last_temp
        self.last_snow = last_snow
        self.last_pet = last_pet

    def fetch(self, coords, start, forecast_steps, dt_hours) -> ForecastMeteoResult:
        Ng = len(coords)
        # Use stored last values or zeros
        rain_last = self.last_rain if self.last_rain is not None else np.zeros(Ng, dtype=np.float32)
        temp_last = self.last_temp if self.last_temp is not None else np.full(Ng, 20.0, dtype=np.float32)
        snow_last = self.last_snow if self.last_snow is not None else np.zeros(Ng, dtype=np.float32)
        pet_last = self.last_pet if self.last_pet is not None else np.zeros(Ng, dtype=np.float32)

        rain = np.tile(rain_last, (forecast_steps, 1)).astype(np.float32)
        temp = np.tile(temp_last, (forecast_steps, 1)).astype(np.float32)
        snow = np.tile(snow_last, (forecast_steps, 1)).astype(np.float32)
        pet = np.tile(pet_last, (forecast_steps, 1)).astype(np.float32)

        dt = pd.Timedelta(hours=dt_hours)
        times = pd.date_range(start + dt, periods=forecast_steps, freq=dt)

        return ForecastMeteoResult(
            rain=rain, temp=temp, snow=snow, pet=pet,
            time_index=times, source="persistence",
        )


class ZeroRainProvider(ForecastMeteoProvider):
    """Zero rain forecast, persist temperature and PET."""

    def __init__(self, last_temp=None, last_pet=None):
        self.last_temp = last_temp
        self.last_pet = last_pet

    def fetch(self, coords, start, forecast_steps, dt_hours) -> ForecastMeteoResult:
        Ng = len(coords)
        temp_last = self.last_temp if self.last_temp is not None else np.full(Ng, 20.0, dtype=np.float32)
        pet_last = self.last_pet if self.last_pet is not None else np.zeros(Ng, dtype=np.float32)

        rain = np.zeros((forecast_steps, Ng), dtype=np.float32)
        snow = np.zeros((forecast_steps, Ng), dtype=np.float32)
        temp = np.tile(temp_last, (forecast_steps, 1)).astype(np.float32)
        pet = np.tile(pet_last, (forecast_steps, 1)).astype(np.float32)

        dt = pd.Timedelta(hours=dt_hours)
        times = pd.date_range(start + dt, periods=forecast_steps, freq=dt)

        return ForecastMeteoResult(
            rain=rain, temp=temp, snow=snow, pet=pet,
            time_index=times, source="zero_rain",
        )
