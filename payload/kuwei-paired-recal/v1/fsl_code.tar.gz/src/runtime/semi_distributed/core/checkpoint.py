# checkpoint.py (moved to core)
import os, pickle, numpy as np
from typing import Optional, Tuple
from src.runtime.semi_distributed.core.params import vector_to_params

def load_checkpoint(path: str) -> Optional[dict]:
    if not (path and os.path.exists(path)):
        return None
    with open(path, "rb") as f:
        return pickle.load(f)

def resume_state(
    cfg, calib_cfg, n_basins
) -> Tuple[int, int, Optional[tuple], Optional[np.ndarray]]:
    """
    从检查点加载状态。

    返回:
        - iteration_offset: 已完成的迭代次数
        - remaining_iter: 剩余的迭代次数
        - rng_state: NumPy 随机生成器状态
        - x_best: 上次保存的最优参数矢量 (1D array) 或 None
    """
    if not cfg.RESUME_TRAINING:
        return 0, cfg.MAX_ITER, None, None

    ckpt = load_checkpoint(cfg.CHECKPOINT_FILE)
    if ckpt is None:
        return 0, cfg.MAX_ITER, None, None

    iter_offset = ckpt.get("iteration_offset", 0)
    remaining = max(cfg.MAX_ITER - iter_offset, 0)
    rng_state = ckpt.get("rng_state", None)
    x_best = ckpt.get("x_best", None)

    # 若已完成全部迭代，直接抛出异常上层处理
    if remaining <= 0 and x_best is not None:
        best_params = vector_to_params(x_best, calib_cfg, n_basins)
        raise RuntimeError(("Optimization already completed.", best_params))

    return iter_offset, remaining, rng_state, x_best


def handle_resume(cfg, calib_cfg, n_basins):
    """
    处理断点恢复逻辑。

    返回:
        - iteration_count: 已完成的迭代次数
        - actual_iter: 接下来要运行的迭代次数
        - init_pop: 'latinhypercube' 或包含历史最优个体的 ndarray
    """
    if not (cfg.RESUME_TRAINING and os.path.exists(cfg.CHECKPOINT_FILE)):
        return 0, cfg.MAX_ITER, "latinhypercube"

    ckpt = load_checkpoint(cfg.CHECKPOINT_FILE)
    iteration_count = ckpt.get("iteration_offset", 0)
    remaining = cfg.MAX_ITER - iteration_count

    if remaining <= 0:
        print("[Resume] Optimization already completed.")
        best_params = vector_to_params(ckpt["x_best"], calib_cfg, n_basins)
        # 返回一个特殊元组，表示已完成
        return iteration_count, 0, ("completed", best_params)

    if "rng_state" in ckpt:
        np.random.set_state(ckpt["rng_state"])

    print(f"[Resume] Resuming from iteration {iteration_count}. Remaining: {remaining}")

    # --- 构造初始种群 ---
    x_best = ckpt.get("x_best")
    if x_best is not None:
        pop_size = cfg.POP_SIZE
        n_dims = x_best.shape[0]
        init_pop = np.full((pop_size, n_dims), np.nan)
        init_pop[0] = x_best
    else:
        init_pop = "latinhypercube"

    return iteration_count, remaining, init_pop

