from pathlib import Path


class OptimizationConfig:
    """半分布式模型优化参数配置"""

    # --- 1. 项目路径 ---
    PROJECT_ROOT = Path(__file__).resolve().parents[4]
    SEMI_DISTRIBUTED_ROOT = PROJECT_ROOT / "experiments/semi_distributed"
    MATRIX_DIR = PROJECT_ROOT / "data/reference/semi_distributed/matrix"
    CONFIG_DIR = Path(__file__).resolve().parent

    DATA_DIR = None  # Must be set via set_basin_name() or run_config
    BASIN_NAME = None  # Must be set via set_basin_name() or run_config
    CUSTOM_MATRIX_PREFIX = None
    METEO_FILE = None

    # --- 2. 模型结构 ---
    SECTION_NAME = "ylx"  # "zmsk", "ql", "ylx"
    DT_HOURS: float | None = None

    # --- 3. 优化时段与数据过滤 ---
    # WARNING: 不要在 class default 写 basin-specific 值。每个 basin 必须在
    # 自己的 run_config.yml 显式声明 start_date / end_date / exclude_years。
    # 历史教训 (2026-05-26): EXCLUDE_YEARS={2010, 2018} 曾默默将 namou_kuwei 的
    # 2018 整年从训练 + 评估中剔除,产生 buggy NSE。
    START_TIME = "2006-01-01"
    END_TIME = "2007-01-04"
    EVAL_START_DATE: str | None = None  # If set, NSE evaluation starts here (spinup before this)
    EXCLUDE_WINDOWS = None  # list of [start,end] date strings; sub-year windows dropped from calib target (bad data)
    EXCLUDE_YEARS: set[int] = set()  # 空 default;每个 basin 在 run_config 显式声明
    # exclude_mode (2026-05-27): exclude_years 非空时必填,否则 dataio raise。
    #   'mask': 加载完整序列, q_obs 在 exclude 年设 NaN, 物理连续 simulate (推荐, 正解)
    #   'drop': SQL drop 行 + 前后相接, state 跨年跳跃 (legacy, 物理 broken, 仅为
    #            reproduce 历史 ylx run 保留)
    EXCLUDE_MODE: str | None = None

    # --- 4. 优化算法参数 ---
    MAX_ITER = 1000
    POP_SIZE = 100
    WORKERS = -1
    ALGORITHM: str = "de"  # "de" | "cmaes"
    CMAES_SIGMA0: float = 0.3  # CMA-ES initial step size (fraction of range)
    SEED_FROM: str | None = None  # Path to YAML with initial params for warm-start
    OPTUNA_N_TRIALS: int = 200  # Number of Optuna trials
    RESUME_TRAINING = False
    OVERRIDE_STATIONS = None

    # --- 4.1 节点/参数筛选 ---
    CALIB_NODE_SELECTOR = None
    CALIB_PARAM_SCOPE = None

    CALIB_ANCHOR = "ylx"
    OBJECTIVE_FLOW = "ylx"
    SIM_UNIT = "subbasin"
    CALIB_NODES = None
    VERIFY_NODES = None

    # --- 5. 模型结构标志 ---
    MSK_SEGMENTED = False

    # --- 6. 目标函数掩膜 (Regime Mask) ---
    OBJECTIVE_MASK: str | None = None  # e.g., "obs >= q90", "obs <= q50"
    OBJECTIVE_WEIGHT: str | None = None  # e.g., "pow2", "linear"
    OBJECTIVE_TYPE: str = "nse"  # "nse", "log_nse", "kge"

    def set_section(self, section: str) -> None:
        if section:
            self.SECTION_NAME = str(section).strip()

    def set_override_stations(self, stations):
        self.OVERRIDE_STATIONS = stations

    def select_calib_nodes(self, nodes):
        self.CALIB_NODES = nodes

    def set_verify_nodes(self, nodes):
        self.VERIFY_NODES = nodes

    def set_calib_anchor(self, anchor: str) -> None:
        self.CALIB_ANCHOR = str(anchor).strip()

    def set_objective_flow(self, flow: str) -> None:
        self.OBJECTIVE_FLOW = str(flow).strip()

    def set_sim_unit(self, sim_unit: str) -> None:
        if sim_unit:
            self.SIM_UNIT = str(sim_unit).strip()

    def set_time_step_hours(self, hours: float | int | str) -> None:
        try:
            value = float(hours)
        except (TypeError, ValueError):
            raise ValueError(f"无效的 dt_hours: {hours!r}")
        if value <= 0:
            raise ValueError("dt_hours 必须为正数")
        self.DT_HOURS = value

    def set_dt_hours(self, dt: float) -> None:
        if dt is None:
            self.DT_HOURS = None
            return
        val = float(dt)
        if val <= 0:
            raise ValueError("DT_HOURS 必须为正数")
        self.DT_HOURS = val

    def set_basin_name(self, basin: str) -> None:
        if not basin:
            return
        self.BASIN_NAME = basin.strip()

        # Check basins/{basin}/config (canonical structure)
        new_style_config = self.PROJECT_ROOT / "basins" / self.BASIN_NAME / "config"
        if new_style_config.exists():
            self.CONFIG_DIR = new_style_config
        else:
            raise FileNotFoundError(
                f"Basin config directory not found: {new_style_config}\n"
                f"Each basin MUST have basins/{{name}}/config/. No fallback."
            )

        self.DATA_DIR = self.PROJECT_ROOT / "data/processed" / self.BASIN_NAME
        # Allow basins/{name}/data as alternative
        if not self.DATA_DIR.exists():
            alt = self.PROJECT_ROOT / "basins" / self.BASIN_NAME / "data"
            if alt.exists():
                self.DATA_DIR = alt

    def set_matrix_prefix(self, prefix: str) -> None:
        if prefix:
            self.CUSTOM_MATRIX_PREFIX = prefix.strip()

    def set_meteo_file(self, path: str) -> None:
        if path:
            p = Path(path)
            if not p.is_absolute():
                p = self.PROJECT_ROOT / p
            self.METEO_FILE = p

    # --- Dynamic file paths ---
    @property
    def OUTPUT_DIR(self) -> Path:
        forced = getattr(self, '_force_output_dir', None)
        if forced is not None:
            return forced
        return self.PROJECT_ROOT / "results" / "experiments" / self.SECTION_NAME

    @property
    def CHECKPOINT_FILE(self) -> str:
        return str(self.OUTPUT_DIR / f"checkpoint_{self.SECTION_NAME}.pkl")

    @property
    def MATRIX_PREFIX(self) -> str:
        """根据区间名选择对应的矩阵文件前缀"""
        if getattr(self, "CUSTOM_MATRIX_PREFIX", None):
            return self.CUSTOM_MATRIX_PREFIX

        prefix_map = {"zmsk": "sel_1", "ql": "sel_2", "ylx": "full"}
        prefix = prefix_map.get(self.SECTION_NAME)
        if prefix is None:
            raise ValueError(f"unknown section_name: {self.SECTION_NAME}")
        return prefix


    @property
    def BASIN_DIR(self) -> Path:
        """Return the data directory for the basin."""
        return self.DATA_DIR

    def get_matrix_path(self, name: str) -> Path:
        return self.MATRIX_DIR / f"{self.MATRIX_PREFIX}_{name}"
