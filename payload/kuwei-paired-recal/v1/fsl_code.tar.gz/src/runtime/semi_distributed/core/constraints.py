# experiments/semi_distributed/optimization/core/constraints.py
from __future__ import annotations
import numpy as np
from typing import Dict, Any, List
from scipy.optimize import NonlinearConstraint
from src.runtime.semi_distributed.core.params import vector_to_params


def prepare_bounds(calib_cfg: Dict[str, Any], n_basins: int, n_layers: int) -> list[tuple[float, float]]:
    """根据校准配置生成参数边界列表
    
    返回格式：[(lo, hi), ...] 元组列表，符合 scipy.optimize.differential_evolution 的要求。
    
    优先使用新版配置中的 index_map（可支持 sub/layer/layer_node 逐项展开）；
    若无 index_map，则退回旧逻辑（按 level 简单重复）。
    
    严格校验：
    - 检查非有限值（NaN/Inf）
    - 检查 hi < lo（配置错误，直接报错）
    - 处理 hi == lo（添加小差值以避免优化器失败）
    """
    bounds: list[tuple[float, float]] = []

    def _is_int_param(p: Dict[str, Any]) -> bool:
        name = str(p.get("name", "")).lower()
        path = p.get("path", [])
        last_key = path[-1] if path else None
        return (last_key in ("n_sub", "num_subreaches")) or ("nsub" in name)

    def _validate_and_fix_bounds(b: list[float], param_name: str = "") -> tuple[float, float]:
        """验证并修复边界值，返回 (lo, hi) 元组。"""
        if len(b) != 2:
            raise ValueError(f"边界值必须为 [lo, hi] 格式，收到: {b} (参数: {param_name})")
        lo, hi = float(b[0]), float(b[1])
        
        # 检查非有限值
        if not np.isfinite(lo) or not np.isfinite(hi):
            raise ValueError(
                f"边界值包含非有限值: lo={lo}, hi={hi} (参数: {param_name})"
            )
        
        # 检查 hi < lo（配置错误，不应静默修复）
        if hi < lo:
            raise ValueError(
                f"边界值配置错误: hi={hi} < lo={lo} (参数: {param_name})。"
                f"请检查校准配置文件中的 bounds 设置。"
            )
        
        # 处理 hi == lo（优化器无法工作，添加小差值）
        if hi == lo:
            hi = lo + 1e-6
            # 可选：打印警告（在严格模式下可能不需要）
        
        return (lo, hi)

    # ── 新版：存在 index_map 时逐项展开 ─────────────────────────────
    if "index_map" in calib_cfg:
        for p, _idx in calib_cfg["index_map"]:
            b_raw = list(map(float, p["bounds"]))
            if _is_int_param(p):
                b_raw = [int(b_raw[0]), int(b_raw[1])]
            param_name = ".".join(p.get("path", [])) or p.get("name", "unknown")
            bounds.append(_validate_and_fix_bounds(b_raw, param_name))
        return bounds

    # ── 旧版：按 level 重复（不支持 layer_node 精确计数）───────────────
    level_repeat = {"sub": n_basins, "layer": n_layers, "basin": 1, "grid": 1}
    for p in calib_cfg.get("calibrate_params", []):
        b_raw = list(map(float, p["bounds"]))
        lvl = p.get("level", "basin").strip()
        repeat = level_repeat.get(lvl)
        if repeat is None:
            # 兼容意外的 level（如 layer_node）——在无 index_map 情况下无法精确展开，降级为按层计数
            repeat = n_layers
        if _is_int_param(p):
            b_raw = [int(b_raw[0]), int(b_raw[1])]
        param_name = ".".join(p.get("path", [])) or p.get("name", "unknown")
        valid_bound = _validate_and_fix_bounds(b_raw, param_name)
        bounds.extend([valid_bound] * repeat)
    return bounds


def make_combined_constraints(
    calib_cfg: Dict[str, Any],
    n_basins: int,
    n_layers: int,
    *,
    c01_sum_ub: float = 0.8,
    ki_kg_sum_ub: float = 0.95,  # ki + kg 上限，防止自由水蓄量变负
) -> List[NonlinearConstraint]:
    """
        生成一个 NonlinearConstraint，内含四组约束：
      (1) ci - cs ≥ 0      × n_basins
      (2) cg - ci ≥ 0      × n_basins
      (3) c0 + c1 ≤ 上限   × n_layers（对每层"节点内的最大值"生效）
      (4) ki + kg ≤ 上限   × n_basins（防止自由水蓄量变负）
    """

    # 判定是否需要启用 basin 级（cs/ci/cg）的约束：仅当它们在校准清单里
    def _want_basin_constraints(cfg: Dict[str, Any]) -> bool:
        keys = ("cs", "ci", "cg")
        if "index_map" in cfg:
            for p, _ in cfg["index_map"]:
                path = p.get("path", [])
                if len(path) >= 2 and path[0] == "xaj_params" and path[-1] in keys:
                    return True
            return False
        # 旧版配置
        for p in cfg.get("calibrate_params", []):
            path = p.get("path", [])
            if len(path) >= 2 and path[0] == "xaj_params" and path[-1] in keys:
                return True
        return False

    # 判定是否需要启用 ki + kg 约束：仅当它们都在校准清单里
    def _want_ki_kg_constraint(cfg: Dict[str, Any]) -> bool:
        keys_found = set()
        if "index_map" in cfg:
            for p, _ in cfg["index_map"]:
                path = p.get("path", [])
                if len(path) >= 2 and path[0] == "xaj_params" and path[-1] in ("ki", "kg"):
                    keys_found.add(path[-1])
        else:
            for p in cfg.get("calibrate_params", []):
                path = p.get("path", [])
                if len(path) >= 2 and path[0] == "xaj_params" and path[-1] in ("ki", "kg"):
                    keys_found.add(path[-1])
        return "ki" in keys_found and "kg" in keys_found

    enable_basin_cons = _want_basin_constraints(calib_cfg)
    enable_ki_kg_cons = _want_ki_kg_constraint(calib_cfg)

    def _all_constraints(x: np.ndarray) -> np.ndarray:
        p = vector_to_params(x, calib_cfg, n_basins)

        # ---- basin 级 cs/ci/cg（可选） -----------------------------------
        if enable_basin_cons and ("xaj_params" in p):
            cs = _as_1d(p["xaj_params"].get("cs", 0.0), n_basins)
            ci = _as_1d(p["xaj_params"].get("ci", 0.0), n_basins)
            cg = _as_1d(p["xaj_params"].get("cg", 0.0), n_basins)
            cons1 = ci - cs          # ≥ 0
            cons2 = cg - ci          # ≥ 0
        else:
            cons1 = np.zeros(0, np.float32)
            cons2 = np.zeros(0, np.float32)

        # ---- layer 级 Muskingum c0+c1 -----------------------------------
        layers = p.get("msk_layers", [])
        
        # Handle wildcard dict from vector_to_params
        if isinstance(layers, dict) and '*' in layers:
             wildcard_layer = layers['*']
             layers = [wildcard_layer] * n_layers
             
        cons3 = np.empty(n_layers, np.float32)
        for i in range(n_layers):
            if i >= len(layers) or not isinstance(layers[i], dict) or len(layers[i]) == 0:
                cons3[i] = -1e6
                continue
            Li = layers[i]
            c0_arr = np.asarray(Li.get("c0", 0.0), dtype=np.float32).ravel()
            c1_arr = np.asarray(Li.get("c1", 0.0), dtype=np.float32).ravel()
            if c0_arr.size == 0 and c1_arr.size == 0:
                cons3[i] = -1e6
            else:
                s = c0_arr + c1_arr
                s = s[np.isfinite(s)] if s.size else s
                cons3[i] = float(np.max(s)) if s.size else -1e6

        # ---- basin 级 ki + kg（防止自由水蓄量变负）-----------------------
        if enable_ki_kg_cons and ("xaj_params" in p):
            ki = _as_1d(p["xaj_params"].get("ki", 0.0), n_basins)
            kg = _as_1d(p["xaj_params"].get("kg", 0.0), n_basins)
            cons4 = ki + kg          # ≤ ki_kg_sum_ub
        else:
            cons4 = np.zeros(0, np.float32)

        return np.concatenate([cons1, cons2, cons3, cons4], axis=0)

    n_basin_cons = (2 * n_basins) if enable_basin_cons else 0
    n_ki_kg_cons = n_basins if enable_ki_kg_cons else 0
    
    lb = np.concatenate([
        np.zeros(n_basin_cons // 2, np.float32),           # ci - cs >= 0
        np.zeros(n_basin_cons // 2, np.float32),           # cg - ci >= 0
        np.full(n_layers, -np.inf, np.float32),            # c0 + c1 无下限
        np.full(n_ki_kg_cons, -np.inf, np.float32),        # ki + kg 无下限
    ])
    ub = np.concatenate([
        np.full(n_basin_cons // 2, np.inf, np.float32),    # ci - cs 无上限
        np.full(n_basin_cons // 2, np.inf, np.float32),    # cg - ci 无上限
        np.full(n_layers, c01_sum_ub, np.float32),         # c0 + c1 <= 0.8
        np.full(n_ki_kg_cons, ki_kg_sum_ub, np.float32),   # ki + kg <= 0.95
    ])

    return [NonlinearConstraint(_all_constraints, lb, ub)]


def _as_1d(arr_like, length: int) -> np.ndarray:
    a = np.asarray(arr_like, np.float32).ravel()
    if a.size == 1:
        return np.full(length, float(a[0]), np.float32)
    if a.size != length:
        raise ValueError(
            f"参数长度 {a.size} 与 n_basins={length} 不符，"
            "请检查 param_levels 配置是否正确。")
    return a.astype(np.float32, copy=False)


    n_basin_cons = (2 * n_basins) if enable_basin_cons else 0
    n_ki_kg_cons = n_basins if enable_ki_kg_cons else 0
    
    lb = np.concatenate([
        np.zeros(n_basin_cons // 2, np.float32),           # ci - cs >= 0
        np.zeros(n_basin_cons // 2, np.float32),           # cg - ci >= 0
        np.full(n_layers, -np.inf, np.float32),            # c0 + c1 无下限
        np.full(n_ki_kg_cons, -np.inf, np.float32),        # ki + kg 无下限
    ])
    ub = np.concatenate([
        np.full(n_basin_cons // 2, np.inf, np.float32),    # ci - cs 无上限
        np.full(n_basin_cons // 2, np.inf, np.float32),    # cg - ci 无上限
        np.full(n_layers, c01_sum_ub, np.float32),         # c0 + c1 <= 0.8
        np.full(n_ki_kg_cons, ki_kg_sum_ub, np.float32),   # ki + kg <= 0.95
    ])

    return [NonlinearConstraint(_all_constraints, lb, ub)]


def _as_1d(arr_like, length: int) -> np.ndarray:
    a = np.asarray(arr_like, np.float32).ravel()
    if a.size == 1:
        return np.full(length, float(a[0]), np.float32)
    if a.size != length:
        raise ValueError(
            f"参数长度 {a.size} 与 n_basins={length} 不符，"
            "请检查 param_levels 配置是否正确。")
    return a.astype(np.float32, copy=False)


    n_basin_cons = (2 * n_basins) if enable_basin_cons else 0
    n_ki_kg_cons = n_basins if enable_ki_kg_cons else 0
    
    lb = np.concatenate([
        np.zeros(n_basin_cons // 2, np.float32),           # ci - cs >= 0
        np.zeros(n_basin_cons // 2, np.float32),           # cg - ci >= 0
        np.full(n_layers, -np.inf, np.float32),            # c0 + c1 无下限
        np.full(n_ki_kg_cons, -np.inf, np.float32),        # ki + kg 无下限
    ])
    ub = np.concatenate([
        np.full(n_basin_cons // 2, np.inf, np.float32),    # ci - cs 无上限
        np.full(n_basin_cons // 2, np.inf, np.float32),    # cg - ci 无上限
        np.full(n_layers, c01_sum_ub, np.float32),         # c0 + c1 <= 0.8
        np.full(n_ki_kg_cons, ki_kg_sum_ub, np.float32),   # ki + kg <= 0.95
    ])

    return [NonlinearConstraint(_all_constraints, lb, ub)]


def _as_1d(arr_like, length: int) -> np.ndarray:
    a = np.asarray(arr_like, np.float32).ravel()
    if a.size == 1:
        return np.full(length, float(a[0]), np.float32)
    if a.size != length:
        raise ValueError(
            f"参数长度 {a.size} 与 n_basins={length} 不符，"
            "请检查 param_levels 配置是否正确。")
    return a.astype(np.float32, copy=False)


    n_basin_cons = (2 * n_basins) if enable_basin_cons else 0
    n_ki_kg_cons = n_basins if enable_ki_kg_cons else 0
    
    lb = np.concatenate([
        np.zeros(n_basin_cons // 2, np.float32),           # ci - cs >= 0
        np.zeros(n_basin_cons // 2, np.float32),           # cg - ci >= 0
        np.full(n_layers, -np.inf, np.float32),            # c0 + c1 无下限
        np.full(n_ki_kg_cons, -np.inf, np.float32),        # ki + kg 无下限
    ])
    ub = np.concatenate([
        np.full(n_basin_cons // 2, np.inf, np.float32),    # ci - cs 无上限
        np.full(n_basin_cons // 2, np.inf, np.float32),    # cg - ci 无上限
        np.full(n_layers, c01_sum_ub, np.float32),         # c0 + c1 <= 0.8
        np.full(n_ki_kg_cons, ki_kg_sum_ub, np.float32),   # ki + kg <= 0.95
    ])

    return [NonlinearConstraint(_all_constraints, lb, ub)]


def _as_1d(arr_like, length: int) -> np.ndarray:
    a = np.asarray(arr_like, np.float32).ravel()
    if a.size == 1:
        return np.full(length, float(a[0]), np.float32)
    if a.size != length:
        raise ValueError(
            f"参数长度 {a.size} 与 n_basins={length} 不符，"
            "请检查 param_levels 配置是否正确。")
    return a.astype(np.float32, copy=False)


    n_basin_cons = (2 * n_basins) if enable_basin_cons else 0
    n_ki_kg_cons = n_basins if enable_ki_kg_cons else 0
    
    lb = np.concatenate([
        np.zeros(n_basin_cons // 2, np.float32),           # ci - cs >= 0
        np.zeros(n_basin_cons // 2, np.float32),           # cg - ci >= 0
        np.full(n_layers, -np.inf, np.float32),            # c0 + c1 无下限
        np.full(n_ki_kg_cons, -np.inf, np.float32),        # ki + kg 无下限
    ])
    ub = np.concatenate([
        np.full(n_basin_cons // 2, np.inf, np.float32),    # ci - cs 无上限
        np.full(n_basin_cons // 2, np.inf, np.float32),    # cg - ci 无上限
        np.full(n_layers, c01_sum_ub, np.float32),         # c0 + c1 <= 0.8
        np.full(n_ki_kg_cons, ki_kg_sum_ub, np.float32),   # ki + kg <= 0.95
    ])

    return [NonlinearConstraint(_all_constraints, lb, ub)]


def _as_1d(arr_like, length: int) -> np.ndarray:
    a = np.asarray(arr_like, np.float32).ravel()
    if a.size == 1:
        return np.full(length, float(a[0]), np.float32)
    if a.size != length:
        raise ValueError(
            f"参数长度 {a.size} 与 n_basins={length} 不符，"
            "请检查 param_levels 配置是否正确。")
    return a.astype(np.float32, copy=False)

