"""Export optimization results for f/h backend optimization."""
from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, Callable
import numpy as np
import pandas as pd
import yaml

from src.runtime.semi_distributed.core.params import vector_to_params
from src.runtime.semi_distributed.tools.utils import to_py


def export_optimization_results(
    *,
    out_dir: Path,
    x_best: np.ndarray,
    y_best: np.ndarray,
    best_score: float,
    metric_name: str,
    calib_cfg_eff: Dict[str, Any],
    Ns: int,
    cfg: Any,  # OptimizationConfig
    cfg_get: Callable[[str, Any], Any],
    optimizer_params: Dict[str, Any],  # {max_iter: (value, source), ...}
    peak_q: float | None = None,
    state_traces: Dict[str, np.ndarray] | None = None,
    unit_traces: Dict[str, np.ndarray] | None = None,
    time_index: pd.DatetimeIndex | None = None,
    temp: np.ndarray | None = None,
    rain: np.ndarray | None = None,
    snow: np.ndarray | None = None,
    plot_states: bool = False,
    plot_per_unit: bool = False,
    dump_per_unit: bool = False,
    plot_sim_vs_obs: bool = True,
    run_cfg_hint: str | None = None,
) -> None:
    """导出优化结果到文件系统。
    
    Args:
        out_dir: 输出目录
        x_best: 最优参数向量
        y_best: 最优模拟序列
        best_score: 最优分数
        metric_name: 指标名称
        calib_cfg_eff: 有效校准配置
        Ns: 子流域数量
        cfg: OptimizationConfig 实例
        cfg_get: 配置读取函数
        metric_name_source: 参数来源字典
        peak_q: peak_quantile 值（如果适用）
        state_traces: 状态追踪字典（聚合）
        unit_traces: 每单元状态追踪字典
        time_index: 时间索引
        temp, rain, snow: 气象数据（用于诊断列）
        plot_states: 是否绘制状态图
        plot_per_unit: 是否绘制每单元状态图
        dump_per_unit: 是否导出每单元CSV
        plot_sim_vs_obs: 是否绘制 sim vs obs
        run_cfg_hint: 配置文件路径提示
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    
    # 1. 导出生效配置
    _export_effective_config(out_dir, cfg, cfg_get, metric_name, peak_q, optimizer_params)
    
    # 2. 保存核心结果
    np.save(out_dir / 'best_vec.npy', x_best)
    np.save(out_dir / 'best_series.npy', y_best)
    
    # 3. 保存状态追踪
    if state_traces:
        _export_state_traces(
            out_dir, state_traces, unit_traces, time_index,
            temp, rain, snow, plot_states, plot_per_unit, dump_per_unit,
        )
    
    # 4. 绘制 sim vs obs
    if plot_sim_vs_obs:
        _plot_sim_vs_obs(out_dir, run_cfg_hint)
    
    # 5. 保存摘要
    with open(out_dir / 'best_summary.txt', 'w', encoding='utf-8') as f:
        f.write(f"{metric_name.upper()}={best_score}\n")
        f.write(f"vec_dim={x_best.size}\n")
    
    # 6. 保存参数字典
    _export_best_params(out_dir, x_best, calib_cfg_eff, Ns)


def _export_effective_config(
    out_dir: Path,
    cfg: Any,
    cfg_get: Callable[[str, Any], Any],
    metric_name: str,
    peak_q: float | None,
    optimizer_params: Dict[str, Any],
) -> None:
    """导出生效配置 YAML。"""
    try:
        def _src_of(k: str) -> str:
            return 'yaml' if cfg_get(k, None) is not None else 'default'
        
        eff = {
            'scene': {
                'section': getattr(cfg, 'SECTION_NAME', None),
                'sim_unit': getattr(cfg, 'SIM_UNIT', None),
                'override': getattr(cfg, 'OVERRIDE_STATIONS', None),
                'calib_nodes': getattr(cfg, 'CALIB_NODE_SELECTOR', None),
                'verify': getattr(cfg, 'VERIFY_NODE_NAME', None),
                'calib_anchor': getattr(cfg, 'CALIB_ANCHOR', None),
                'objective_flow': getattr(cfg, 'OBJECTIVE_FLOW', None),
            },
            'time': {
                'start': getattr(cfg, 'START_TIME', None),
                'end': getattr(cfg, 'END_TIME', None),
                'exclude_years': sorted(list(getattr(cfg, 'EXCLUDE_YEARS')))
                                  if isinstance(getattr(cfg, 'EXCLUDE_YEARS', None), set) else None,
            },
            'meteo': {
                'snow_partition': {
                    't_snow': getattr(cfg, 'T_SNOW', None),
                    't_rain': getattr(cfg, 'T_RAIN', None),
                },
                'precip': {
                    'mode': getattr(cfg, 'PRECIP_MODE', None),
                    'rain_cols': getattr(cfg, 'RAIN_COLUMNS', None),
                    'snow_cols': getattr(cfg, 'SNOW_COLUMNS', None),
                    'total_precip_col': getattr(cfg, 'TOTAL_PRECIP_COL', None),
                }
            },
            'model': {
                'calibration': {
                    'enable_snowmelt': True
                }
            },
            'optimizer': {
                'max_iter': optimizer_params.get('max_iter', (None, None))[0],
                'pop_size': optimizer_params.get('pop_size', (None, None))[0],
                'workers': optimizer_params.get('workers', (None, None))[0],
                'objective': str(metric_name).lower(),
                'peak_quantile': float(peak_q) if metric_name == 'nse_peak' and peak_q is not None else None,
            },
            'meta': {
                'source': {
                    'section': _src_of('section'),
                    'sim_unit': _src_of('sim_unit'),
                    'override': _src_of('override'),
                    'calib_nodes': _src_of('calib_nodes'),
                    'verify': _src_of('verify'),
                    'calib_anchor': _src_of('calib_anchor'),
                    'objective_flow': _src_of('objective_flow'),
                    'start_date': _src_of('start_date'),
                    'end_date': _src_of('end_date'),
                    'exclude_years': _src_of('exclude_years'),
                    'meteo': {
                        'snow_partition': 'yaml' if (getattr(cfg, 'T_SNOW', None) is not None or getattr(cfg, 'T_RAIN', None) is not None) else 'default',
                        'precip': 'yaml' if (
                            getattr(cfg, 'PRECIP_MODE', None) is not None or
                            getattr(cfg, 'RAIN_COLUMNS', None) is not None or
                            getattr(cfg, 'SNOW_COLUMNS', None) is not None or
                            getattr(cfg, 'TOTAL_PRECIP_COL', None) is not None
                        ) else 'auto-detect'
                    },
                    'model': {
                        'calibration': {
                            'enable_snowmelt': 'forced-true'
                        }
                    },
                    'optimizer': {
                        'max_iter': optimizer_params.get('max_iter', (None, None))[1],
                        'pop_size': optimizer_params.get('pop_size', (None, None))[1],
                        'workers': optimizer_params.get('workers', (None, None))[1],
                    },
                }
            }
        }
        with open(out_dir / 'effective_config.yml', 'w', encoding='utf-8') as fe:
            yaml.safe_dump(eff, fe, allow_unicode=True, sort_keys=False)
    except Exception as e:
        print(f"[WARN] 导出 effective_config.yml 失败: {e}")


def _export_state_traces(
    out_dir: Path,
    state_traces: Dict[str, np.ndarray],
    unit_traces: Dict[str, np.ndarray] | None,
    time_index: pd.DatetimeIndex | None,
    temp: np.ndarray | None,
    rain: np.ndarray | None,
    snow: np.ndarray | None,
    plot_states: bool,
    plot_per_unit: bool,
    dump_per_unit: bool,
) -> None:
    """导出状态追踪数据。"""
    try:
        # 保存为 npz 和 csv
        np.savez(out_dir / 'state_traces.npz', **{k: v for k, v in state_traces.items()})
        
        # CSV 导出
        try:
            df = pd.DataFrame(state_traces)
            # 附加诊断列
            if temp is not None or rain is not None or snow is not None:
                try:
                    if temp is not None:
                        tmean = (np.nanmean(temp, axis=1) if getattr(temp, 'ndim', 1) == 2 else np.asarray(temp).reshape(-1))
                        df['temp_mean'] = np.asarray(tmean, dtype=np.float32)[: len(df)]
                    if rain is not None:
                        rain_sum = (np.nansum(rain, axis=1) if getattr(rain, 'ndim', 1) == 2 else np.asarray(rain).reshape(-1))
                        df['rain_basin_sum'] = np.asarray(rain_sum, dtype=np.float32)[: len(df)]
                    if snow is not None:
                        snow_sum = (np.nansum(snow, axis=1) if getattr(snow, 'ndim', 1) == 2 else np.asarray(snow).reshape(-1))
                        df['snow_basin_sum'] = np.asarray(snow_sum, dtype=np.float32)[: len(df)]
                    if 'temp_mean' in df.columns:
                        df['pdd'] = np.maximum(df['temp_mean'].values, 0.0).astype(np.float32)
                except Exception:
                    pass
            if time_index is not None:
                try:
                    df.index = pd.Index(time_index[:len(df)], name='time')
                except Exception:
                    pass
            df.to_csv(out_dir / 'state_traces.csv', index=bool(time_index is not None), encoding='utf-8')
        except Exception as e_csv:
            print(f"[WARN] 保存 state_traces.csv 失败: {e_csv}")
        
        # 可选绘图
        if plot_states:
            _plot_state_traces(out_dir, state_traces, time_index)
        
        # 每单元导出与绘图
        if (unit_traces is not None) and (dump_per_unit or plot_per_unit):
            _export_unit_traces(out_dir, unit_traces, time_index, dump_per_unit, plot_per_unit)
    except Exception as e_npz:
        print(f"[WARN] 保存 state_traces.npz 失败: {e_npz}")


def _plot_state_traces(
    out_dir: Path,
    state_traces: Dict[str, np.ndarray],
    time_index: pd.DatetimeIndex | None,
) -> None:
    """绘制状态追踪图（分面）。"""
    try:
        import matplotlib.pyplot as plt  # type: ignore
        names = list(state_traces.keys())
        n = len(names)
        if n == 0:
            raise RuntimeError('没有可绘制的状态')
        h = max(2.2*n, 4.0)
        fig, axes = plt.subplots(n, 1, figsize=(10, h), sharex=True)
        if n == 1:
            axes = [axes]
        xlab = 'time' if time_index is not None else 't'
        for i, name in enumerate(names):
            ax = axes[i]
            yv = state_traces[name]
            ax.plot(yv, label=name, linewidth=1.1)
            ax.set_ylabel(name)
            ax.grid(True, alpha=0.3)
            ax.legend(loc='best')
        axes[-1].set_xlabel(xlab)
        fig.suptitle('State traces (separate subplots)', y=0.995)
        fig.tight_layout(rect=(0,0,1,0.98))
        fig.savefig(out_dir / 'state_traces.png', dpi=150)
        plt.close(fig)
        print(f"[VIS] 已保存状态变化图(分面): {out_dir / 'state_traces.png'}")
    except Exception as e_plot:
        print(f"[WARN] 绘制状态图失败（可能缺少 matplotlib）: {e_plot}")


def _export_unit_traces(
    out_dir: Path,
    unit_traces: Dict[str, np.ndarray],
    time_index: pd.DatetimeIndex | None,
    dump_per_unit: bool,
    plot_per_unit: bool,
) -> None:
    """导出每单元状态追踪。"""
    try:
        # 保存 NPZ
        np.savez(out_dir / 'state_traces_per_unit.npz', **{k: v for k, v in unit_traces.items() if isinstance(v, np.ndarray)})
    except Exception as e_npz_u:
        print(f"[WARN] 保存 state_traces_per_unit.npz 失败: {e_npz_u}")
    
    # CSV 导出
    if dump_per_unit:
        try:
            keys = [k for k in unit_traces.keys() if isinstance(unit_traces.get(k), np.ndarray)]
            if keys:
                nT, nU = unit_traces[keys[0]].shape
                frames = []
                for u in range(nU):
                    d = {'unit': np.full((nT,), u, dtype=np.int32)}
                    for k in keys:
                        d[k] = unit_traces[k][:, u]
                    dfu = pd.DataFrame(d)
                    if time_index is not None:
                        try:
                            dfu.index = pd.Index(time_index[:nT], name='time')
                        except Exception:
                            pass
                    frames.append(dfu)
                dfu_all = pd.concat(frames, axis=0)
                dfu_all.to_csv(out_dir / 'state_traces_per_unit.csv', index=bool(time_index is not None), encoding='utf-8')
        except Exception as e_csv_u:
            print(f"[WARN] 保存 state_traces_per_unit.csv 失败: {e_csv_u}")
    
    # 绘图
    if plot_per_unit:
        try:
            import matplotlib.pyplot as plt  # type: ignore
            keys = [k for k in unit_traces.keys() if isinstance(unit_traces.get(k), np.ndarray)]
            n = len(keys)
            if n > 0:
                h = max(2.2*n, 4.0)
                fig, axes = plt.subplots(n, 1, figsize=(11, h), sharex=True)
                if n == 1:
                    axes = [axes]
                xlab = 'time' if time_index is not None else 't'
                for i, name in enumerate(keys):
                    ax = axes[i]
                    arr = unit_traces[name]
                    for u in range(arr.shape[1]):
                        ax.plot(arr[:, u], alpha=0.8, linewidth=0.8, label=(name if u == 0 else None))
                    ax.set_ylabel(name)
                    ax.grid(True, alpha=0.3)
                    if arr.shape[1] > 1 and i == 0:
                        ax.legend(loc='best')
                axes[-1].set_xlabel(xlab)
                fig.suptitle('Per-unit state traces (overlay by unit)', y=0.995)
                fig.tight_layout(rect=(0,0,1,0.98))
                fig.savefig(out_dir / 'state_traces_per_unit.png', dpi=150)
                plt.close(fig)
                print(f"[VIS] 已保存每单元状态图: {out_dir / 'state_traces_per_unit.png'}")
        except Exception as e_plot_u:
            print(f"[WARN] 绘制每单元状态图失败（可能缺少 matplotlib）: {e_plot_u}")


def _plot_sim_vs_obs(out_dir: Path, run_cfg_hint: str | None) -> None:
    """绘制 sim vs obs 对比图。"""
    try:
        from src.runtime.semi_distributed.tools import plot_sim_vs_obs as _plot
        _plot.main(run_cfg_hint, str(out_dir / 'best_series.npy'), str(out_dir / 'sim_vs_obs.png'))
    except Exception as e:
        print(f"[WARN] sim_vs_obs 绘图失败: {e}")


def _export_best_params(out_dir: Path, x_best: np.ndarray, calib_cfg_eff: Dict[str, Any], Ns: int) -> None:
    """导出最优参数字典，包含断面名称。"""
    try:
        best_param_dict = vector_to_params(x_best, calib_cfg_eff, Ns)
        best_param_dict = to_py(best_param_dict)
        
        # 从 layers_structure 中提取断面名称并添加到 msk_layers
        layers_structure = calib_cfg_eff.get("layers_structure")
        if layers_structure and "msk_layers" in best_param_dict:
            msk_layers = best_param_dict["msk_layers"]
            for li, layer in enumerate(msk_layers):
                if li < len(layers_structure):
                    src_layer = layers_structure[li]
                    # 提取名称
                    names = src_layer.get("names")
                    if names is not None:
                        if hasattr(names, 'tolist'):
                            names = names.tolist()
                        layer["names"] = names
                    # 提取 index
                    index = src_layer.get("index")
                    if index is not None:
                        if hasattr(index, 'tolist'):
                            index = index.tolist()
                        layer["index"] = index
        
        with open(out_dir / 'best_params.yml', 'w', encoding='utf-8') as fy:
            yaml.safe_dump(best_param_dict, fy, allow_unicode=True, sort_keys=False)
    except Exception as e:
        print(f"[WARN] 保存 best_params.yml 失败: {e}")


def sync_best_vec_to_da(out_dir: Path, target_dir: Path | None = None) -> None:
    """同步 best_vec.npy 到 DA 模块使用的默认位置。
    
    解决问题：优化结果保存在 run_XXXXXX 目录，但 DA 模块使用的是固定路径。
    
    Args:
        out_dir: 优化结果输出目录（包含 best_vec.npy）
        target_dir: 目标目录，默认为 out_dir 的父目录（即 results/fh_optimize/）
    """
    import shutil
    
    src = out_dir / 'best_vec.npy'
    if not src.exists():
        print(f"[WARN] sync_best_vec_to_da: 源文件不存在 {src}")
        return
    
    if target_dir is None:
        target_dir = out_dir.parent
    
    dst = target_dir / 'best_vec.npy'
    
    try:
        # 备份旧文件
        if dst.exists():
            backup = target_dir / f'best_vec_backup_{pd.Timestamp.now().strftime("%Y%m%d_%H%M%S")}.npy'
            shutil.copy2(dst, backup)
            print(f"[SYNC] 已备份旧 best_vec.npy -> {backup.name}")
        
        # 复制新文件
        shutil.copy2(src, dst)
        print(f"[SYNC] 已同步 best_vec.npy -> {dst}")
        
        # 同时复制 best_params.yml
        src_params = out_dir / 'best_params.yml'
        if src_params.exists():
            shutil.copy2(src_params, target_dir / 'best_params.yml')
            print(f"[SYNC] 已同步 best_params.yml -> {target_dir / 'best_params.yml'}")
        
        # 创建验证脚本
        _create_verify_script(out_dir, target_dir)
        
    except Exception as e:
        print(f"[WARN] sync_best_vec_to_da 失败: {e}")


def _create_verify_script(out_dir: Path, target_dir: Path) -> None:
    """创建独立的验证脚本，确保参数可复现。"""
    import subprocess
    
    # 获取 git commit hash
    try:
        result = subprocess.run(
            ['git', 'rev-parse', '--short', 'HEAD'],
            capture_output=True, text=True, cwd=out_dir.parent.parent.parent
        )
        git_hash = result.stdout.strip() if result.returncode == 0 else 'unknown'
    except Exception:
        git_hash = 'unknown'
    
    verify_script = f'''#!/usr/bin/env python
"""验证优化参数是否能复现 NSE。

生成时间: {pd.Timestamp.now().isoformat()}
Git commit: {git_hash}
源目录: {out_dir}

用法:
    python verify_params.py

如果验证失败（NSE 差距 > 0.01），说明参数加载路径有问题。
"""
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[3]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import numpy as np

def main():
    best_vec_path = Path(__file__).parent / 'best_vec.npy'
    best_summary_path = Path(__file__).parent / 'best_summary.txt'
    
    if not best_vec_path.exists():
        print(f"[ERROR] best_vec.npy 不存在: {{best_vec_path}}")
        return 1
    
    # 读取期望的 NSE
    expected_nse = None
    if best_summary_path.exists():
        with open(best_summary_path, 'r') as f:
            for line in f:
                if line.startswith('NSE='):
                    expected_nse = float(line.split('=')[1].strip())
                    break
    
    if expected_nse is None:
        print("[WARN] 无法读取期望 NSE，跳过验证")
        return 0
    
    print(f"[VERIFY] 期望 NSE: {{expected_nse:.6f}}")
    print(f"[VERIFY] best_vec: {{best_vec_path}}")
    
    # 使用 check_openloop.py 验证
    try:
        from experiments.streaming_da.ylx.check_openloop import main as check_main
        # 设置环境变量指向正确的 best_vec
        import os
        os.environ['BEST_VEC_PATH'] = str(best_vec_path)
        actual_nse = check_main()  # 假设返回 NSE
        
        if actual_nse is None:
            print("[WARN] check_openloop 未返回 NSE")
            return 0
        
        diff = abs(actual_nse - expected_nse)
        if diff > 0.01:
            print(f"[FAIL] NSE 差距过大: 期望={{expected_nse:.6f}}, 实际={{actual_nse:.6f}}, 差距={{diff:.6f}}")
            return 1
        else:
            print(f"[PASS] NSE 验证通过: 期望={{expected_nse:.6f}}, 实际={{actual_nse:.6f}}, 差距={{diff:.6f}}")
            return 0
    except Exception as e:
        print(f"[ERROR] 验证失败: {{e}}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
'''
    
    try:
        verify_path = target_dir / 'verify_params.py'
        with open(verify_path, 'w', encoding='utf-8') as f:
            f.write(verify_script)
        print(f"[SYNC] 已创建验证脚本: {verify_path}")
    except Exception as e:
        print(f"[WARN] 创建验证脚本失败: {e}")

