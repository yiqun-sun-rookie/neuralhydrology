"""Utilities for optimizer configuration parsing."""
from __future__ import annotations
from typing import Callable, Tuple, Any
import numpy as np

from src.runtime.metrics import (
    nse as _nse,
    kge as _kge,
    rmse_score as _rmse_score,
    mae_score as _mae_score,
    nse_peak as _nse_peak,
)


def parse_objective_config(
    obj_raw: str | None,
    peak_quantile_cli: float | None,
    cfg_get: Callable[[str, Any], Any],
) -> Tuple[str, Callable, float]:
    """解析目标函数配置，返回 (metric_name, metric_fn, peak_q)。
    
    Args:
        obj_raw: 目标函数名称，可能包含 @ 语法（如 'nse_peak@0.9'）
        peak_quantile_cli: CLI 提供的 peak_quantile
        cfg_get: 配置读取函数，接受 key 返回配置值
        
    Returns:
        (metric_name, metric_fn, peak_q) 元组
    """
    metric_name = 'nse'
    peak_q: float | None = None
    
    # 解析 @ 语法：例如 'nse_peak@0.9'
    if obj_raw is not None:
        obj_str = str(obj_raw).strip()
        if '@' in obj_str:
            base, qpart = obj_str.split('@', 1)
            metric_name = base.strip().lower() or 'nse'
            try:
                peak_q = float(qpart.strip())
            except (ValueError, TypeError):
                # @ 后的值无效，使用默认值
                peak_q = None
        else:
            metric_name = obj_str.lower()
    
    # 再从 YAML 字段读取 peak 分位（若未在 @ 中指定）
    if peak_q is None:
        peak_q_cfg = peak_quantile_cli if peak_quantile_cli is not None else cfg_get('peak_quantile') or cfg_get('objective_peak_q')
        if peak_q_cfg is not None:
            try:
                peak_q = float(peak_q_cfg)
            except (ValueError, TypeError) as e:
                raise ValueError(f"peak_quantile 配置值无效: {peak_q_cfg}, 错误: {e}") from e
        else:
            peak_q = 0.9  # 默认值
    
    # 验证 peak_q 范围
    if not (0.0 < peak_q < 1.0):
        raise ValueError(f"peak_quantile 必须在 (0, 1) 区间内，当前值: {peak_q}")
    
    # 映射指标函数（统一返回"越大越好"的分数）
    if metric_name in ('nse', 'nash', 'nash-sutcliffe'):
        metric_fn = _nse
        metric_name = 'nse'
    elif metric_name in ('kge',):
        metric_fn = _kge
        metric_name = 'kge'
    elif metric_name in ('rmse',):
        metric_fn = _rmse_score
        metric_name = 'rmse'
    elif metric_name in ('mae',):
        metric_fn = _mae_score
        metric_name = 'mae'
    elif metric_name in ('nse_peak', 'nsepeak', 'nse-peak'):
        metric_fn = (lambda s, o: _nse_peak(s, o, frac=float(peak_q)))
        metric_name = 'nse_peak'
    else:
        print(f"[WARN] 未识别的 objective='{metric_name}'，使用默认值 NSE")
        metric_fn = _nse
        metric_name = 'nse'
    
    return metric_name, metric_fn, peak_q


def require_int(value: Any, name: str) -> int:
    """要求值为整数，否则抛出 ValueError。"""
    try:
        return int(value)
    except Exception as e:
        raise ValueError(f"optimizer.{name} 需为整数，当前值: {value}") from e


def pick_required_param(
    name: str,
    cli_val: Any,
    cfg_get: Callable[[str, Any], Any],
    run_cfg_hint: str | None,
) -> Tuple[int, str]:
    """从 CLI 或 YAML 配置中获取必需的整数参数。
    
    Args:
        name: 参数名（如 'max_iter'）
        cli_val: CLI 提供的值（可能为 None）
        cfg_get: 配置读取函数
        run_cfg_hint: 配置文件路径提示（用于错误信息）
        
    Returns:
        (value, source) 元组，source 为 'cli' 或 'yaml'
        
    Raises:
        ValueError: 如果参数缺失或无效
    """
    if cli_val is not None:
        return require_int(cli_val, name), 'cli'
    cfg_val = cfg_get(name, None)
    if cfg_val is not None:
        return require_int(cfg_val, name), 'yaml'
    hint = f"（请在 {run_cfg_hint} 的 optimizer 区块中添加 {name}: <int>）" if run_cfg_hint else ""
    msg = f"缺少 optimizer.{name}，请在 YAML 或命令行显式提供。{hint}"
    raise ValueError(msg)


def prepare_bounds_for_init(bounds: list[tuple[float, float]]) -> Tuple[np.ndarray | None, np.ndarray | None]:
    """准备边界数组用于种群初始化。
    
    Args:
        bounds: 边界列表，格式 [(lo, hi), ...]
        
    Returns:
        (bounds_np, center) 元组，如果转换失败则返回 (None, None)
    """
    try:
        bounds_np = np.array([[float(b[0]), float(b[1])] for b in bounds], dtype=float)
        center = bounds_np.mean(axis=1)
        return bounds_np, center
    except (ValueError, TypeError, IndexError) as e:
        # 如果 bounds 格式异常，应该在校验阶段就发现，这里仅做最后防线
        raise ValueError(f"bounds 格式异常，无法转换为 2D 数组: {e}") from e
    except Exception:
        # 其他未知错误，回退到默认初始化
        return None, None


