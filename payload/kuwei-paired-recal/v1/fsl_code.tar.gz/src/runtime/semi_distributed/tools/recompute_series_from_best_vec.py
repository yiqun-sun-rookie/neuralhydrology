from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np

from src.runtime.semi_distributed.tools.eval_with_params import (
    load_yaml_with_include,
    _flatten_run_config,
)
from src.runtime.semi_distributed.core.pipeline import (
    prepare_calibration_session,
    select_floods_series,
)
from src.runtime.semi_distributed.core.params import (
    prepare_model_params,
    prepare_initial_state,
    vector_to_params,
)
from src.runtime.semi_distributed.core.constraints import (
    prepare_bounds,
)
from src.runtime.semi_distributed.core.dataio import prepare_external_flow_inputs
from src.runtime.semi_distributed.core.state_space_handles import get_da_handles
from src.runtime.semi_distributed.tools.fh_utils import simulate_series_fh
from src.da.xaj_backend import HydroForcing, build_snowmelt_controls


def _build_broadcaster(grid2sub, sub_area, connection_matrices, model_tpl, calib_cfg, Ns: int):
    def _broadcaster(vec: np.ndarray, calib_cfg_in, model_tpl_in, geo_info_in):
        param_dict = vector_to_params(vec, calib_cfg_in, Ns)
        merged_model, pdd_tuple, xaj_tuple, msk_layers_params_tuples, core_args = prepare_model_params(
            param_dict=param_dict,
            model_params_template=model_tpl_in,
            calibration_config=calib_cfg_in,
            grid2sub=geo_info_in[0],
            sub_area=geo_info_in[1],
            connection_matrices=geo_info_in[2],
        )
        return merged_model, pdd_tuple, xaj_tuple, msk_layers_params_tuples, core_args
    return _broadcaster


def main(argv=None):
    ap = argparse.ArgumentParser(description="Recompute y series from best_vec.npy using optimizer's simulate function")
    ap.add_argument('--run-config', type=str, required=True, help='run_config.yml 路径')
    ap.add_argument('--vec', type=str, default=None, help='best_vec.npy 路径（默认 results/fh_optimize/best_vec.npy）')
    ap.add_argument('--out-dir', type=str, default=None, help='输出目录（默认与 vec 同级）')
    args = ap.parse_args(argv)

    # 读取 run_config（与 optimize_semidistributed 一致）
    from src.runtime.semi_distributed import optimize_semidistributed as _opt_sem
    _opt_sem.RUN_CONFIG_FILE = Path(args.run_config)
    # Load raw dict to support legacy dict-based access in this script
    raw_data = load_yaml_with_include(Path(args.run_config), set())
    file_cfg = _flatten_run_config(raw_data or {})

    # 会话
    from src.runtime.semi_distributed.core.optimization_config import OptimizationConfig
    cfg = OptimizationConfig()
    # 为 select_floods_series 提供最小必要字段（保持默认：场景块优先）
    def _cfg_get(key, default=None):
        try:
            scene = file_cfg.get('scene') if isinstance(file_cfg, dict) else None
            if isinstance(scene, dict) and key in scene:
                return scene.get(key, default)
            opt = file_cfg.get('optimizer') if isinstance(file_cfg, dict) else None
            if isinstance(opt, dict) and key in opt:
                return opt.get(key, default)
            return file_cfg.get(key, default) if isinstance(file_cfg, dict) else default
        except Exception:
            return default

    _sec = _cfg_get('section'); _simu = _cfg_get('sim_unit'); _anch = _cfg_get('calib_anchor')
    _objf = _cfg_get('objective_flow'); _csel = _cfg_get('calib_nodes'); _veri = _cfg_get('verify')
    _st = _cfg_get('start_date'); _ed = _cfg_get('end_date'); _exy = _cfg_get('exclude_years')
    _basin = _cfg_get('basin_name')
    _dt = _cfg_get('dt_hours') or _cfg_get('DT_HOURS') or _cfg_get('time_step_hours')

    _sec and cfg.set_section(_sec); _simu and cfg.set_sim_unit(_simu); _anch and cfg.set_calib_anchor(_anch)
    _objf and cfg.set_objective_flow(_objf); _csel and cfg.select_calib_nodes(_csel); _veri and cfg.set_verify_nodes(_veri)
    _basin and cfg.set_basin_name(_basin)
    if _dt:
        cfg.set_time_step_hours(_dt)

    (isinstance(_st, str) and _st.strip()) and setattr(cfg, 'START_TIME', _st)
    (isinstance(_ed, str) and _ed.strip()) and setattr(cfg, 'END_TIME', _ed)
    setattr(cfg, 'EXCLUDE_YEARS', list(_exy) if (_exy is not None and not isinstance(_exy, str)) else [])
    
    _ic = _cfg_get('initial_conditions')
    if _ic:
        setattr(cfg, 'INITIAL_CONDITIONS', _ic)

    # === 补全配置加载逻辑 (与 optimize_with_fh.py 保持一致) ===
    model_block = file_cfg.get('model') if isinstance(file_cfg, dict) else None
    
    # 提取 msk_segmented
    if isinstance(model_block, dict) and 'msk_segmented' in model_block:
        cfg.MSK_SEGMENTED = bool(model_block['msk_segmented'])

    if isinstance(model_block, dict) and str(model_block.get('mode','')).lower() == 'inline':
        data_blk = model_block.get('data', {})
        setattr(cfg, 'INLINE_TOPOLOGY', data_blk.get('topology'))
        setattr(cfg, 'INLINE_CALIB', data_blk.get('calibration'))
        setattr(cfg, 'INLINE_PDD_XAJ', data_blk.get('pdd_xaj'))
        # 初始条件
        ic_inline = None
        if isinstance(data_blk, dict):
            if 'initial_conditions' in data_blk:
                ic_inline = data_blk.get('initial_conditions')
            elif 'initial_conditions_file' in data_blk:
                ic_inline = data_blk.get('initial_conditions_file')
        if isinstance(ic_inline, (dict, str)):
            setattr(cfg, 'INLINE_INITIAL_CONDITIONS', ic_inline)
        
        # 雪雨分配控制
        if isinstance(data_blk, dict):
            calib_blk = data_blk.get('calibration', {})
            snow_part = calib_blk.get('snow_partition', {}) if isinstance(calib_blk, dict) else {}
            if isinstance(snow_part, dict):
                t_snow = snow_part.get('t_snow', None)
                t_rain = snow_part.get('t_rain', None)
                if t_snow is not None: setattr(cfg, 'T_SNOW', float(t_snow))
                if t_rain is not None: setattr(cfg, 'T_RAIN', float(t_rain))
                mode = snow_part.get('mode', None)
                if isinstance(mode, str) and mode.strip():
                    m = mode.strip().lower()
                    if m in ('columns','use_columns','explicit','split','temperature_split','temp_split'):
                        setattr(cfg, 'PRECIP_MODE', 'columns' if m in ('columns','use_columns','explicit') else 'split')
                
                def _norm_list(val):
                    if val is None: return None
                    if isinstance(val, (list, tuple)): return [str(x) for x in val if str(x)]
                    if isinstance(val, str): return [s.strip() for s in val.split(',') if s.strip()] or None
                    return None
                
                rc = _norm_list(snow_part.get('rain_cols', None))
                sc = _norm_list(snow_part.get('snow_cols', None))
                tc = snow_part.get('total_precip_col', None)
                if rc is not None: setattr(cfg, 'RAIN_COLUMNS', rc)
                if sc is not None: setattr(cfg, 'SNOW_COLUMNS', sc)
                if isinstance(tc, str) and tc.strip(): setattr(cfg, 'TOTAL_PRECIP_COL', tc.strip())

    # 显式同步 anchor/flow 到旧字段
    setattr(cfg, 'EVAL_STATION', getattr(cfg, 'CALIB_ANCHOR', None))
    setattr(cfg, 'FLOW_SOURCE_STATION', getattr(cfg, 'OBJECTIVE_FLOW', None))

    sess = prepare_calibration_session(cfg)
    grid2sub = sess['grid2sub']; sub_area = sess['sub_area']
    (rain, temp, snow, pet) = sess['meteo_inputs']
    msk_layers = sess['msk_layers']
    connection_matrices = sess['connection_matrices']
    model_tpl = sess['default_params']
    calib_cfg = sess['calib_cfg']
    init_cond = sess['init_cond']
    eval_station = getattr(cfg, 'EVAL_STATION', None)

    # 观测序列（选洪水段以确定时间窗）
    discharge_outlet = sess['discharge_outlet']
    discharge_inflow = sess['discharge_inflow']
    series, abort_flag = select_floods_series(cfg, discharge_outlet, discharge_inflow, eval_station, msk_layers)
    if abort_flag or series is None:
        raise RuntimeError('未找到可用的观测序列。')
    qobs = np.asarray(series.values, dtype=np.float32)

    T = min(qobs.shape[0], rain.shape[0])
    rain, temp, snow, pet = rain[:T], temp[:T], snow[:T], pet[:T]
    qobs = qobs[:T]

    # 外接来水
    time_index = sess.get('time_index')
    station_reach_map = {"zmsk": 0, "ql": 1} if str(getattr(cfg, 'SECTION_NAME', '')).lower() == 'ylx' else None
    obs_station_arr, sta_reach_idx = (None, None)
    if station_reach_map is not None:
        obs_station_arr, sta_reach_idx = prepare_external_flow_inputs(
            observed_station_flow=discharge_inflow,
            station_reach_map=station_reach_map,
            time_index=time_index,
            override_stations=getattr(cfg, 'OVERRIDE_STATIONS', None),
        )
        if obs_station_arr is not None:
            obs_station_arr = obs_station_arr[:T]

    hydro_forcing = HydroForcing(
        rain=rain,
        temp=temp,
        snow=snow,
        pet=pet,
        qobs=qobs,
        steps=T,
        obs_station_arr=obs_station_arr,
        sta_reach_idx=sta_reach_idx,
    )

    # 读取 best_vec
    default_out_dir = Path('results') / 'fh_optimize'
    vec_path = Path(args.vec) if args.vec else (default_out_dir / 'best_vec.npy')
    
    # 确定输出目录：优先使用 --out-dir，其次使用 vec 所在目录，最后回退到 default
    if args.out_dir:
        out_dir = Path(args.out_dir)
    elif args.vec:
        out_dir = vec_path.parent
    else:
        out_dir = default_out_dir
        
    out_dir.mkdir(parents=True, exist_ok=True)
    x_best = np.load(vec_path)

    # 构造参数与句柄
    Ns = grid2sub.shape[1]
    calib_cfg_eff = calib_cfg
    if not isinstance(calib_cfg.get('index_map', None), list) or len(calib_cfg['index_map']) == 0:
        calib_cfg_eff = dict(calib_cfg)
        calib_cfg_eff.pop('index_map', None)
    _ = prepare_bounds(calib_cfg_eff, Ns, len(msk_layers))  # 仅确保校验通过
    broadcaster = _build_broadcaster(grid2sub, sub_area, connection_matrices, model_tpl, calib_cfg_eff, Ns)
    merged_model, pdd_tuple, xaj_tuple, msk_layers_params_tuples, core_args = broadcaster(
        x_best, calib_cfg_eff, model_tpl, (grid2sub, sub_area, connection_matrices)
    )
    Ng = grid2sub.shape[0]
    x0_struct = prepare_initial_state(init_cond, Ng, enable_snowmelt=True)
    da = get_da_handles(
        init_units_state=x0_struct,
        msk_layers_params=msk_layers_params_tuples,
        layer_connect_mats=core_args['C_mats'],
        grid2sub=grid2sub,
        pdd_pars=pdd_tuple,
        xaj_pars=xaj_tuple,
    )

    # 计算 y 并保存
    snowmelt_result = build_snowmelt_controls(hydro_forcing, pdd_tuple, x0_struct)
    y = simulate_series_fh(
        da,
        rain,
        temp,
        snow,
        pet,
        obs_station_arr,
        sta_reach_idx,
        snowmelt=snowmelt_result,
    )
    y = np.asarray(y, dtype=np.float32)
    np.save(out_dir / 'best_series_recalc.npy', y)
    
    # 计算并打印 Open Loop NSE
    def _nse(sim, obs):
        mask = ~(np.isnan(sim) | np.isnan(obs))
        s, o = sim[mask], obs[mask]
        if len(o) == 0:
            return float('nan')
        o_mean = np.mean(o)
        ss_res = np.sum((o - s) ** 2)
        ss_tot = np.sum((o - o_mean) ** 2)
        return 1.0 - ss_res / ss_tot if ss_tot > 1e-10 else float('nan')
    
    ol_nse = _nse(y, qobs)
    print(f"[OL] NSE={ol_nse:.6f}")
    
    # 打印与原 best_series 的对比
    try:
        y0 = np.load(out_dir / 'best_series.npy').astype(np.float32)
        n = min(len(y0), len(y))
        d = np.abs(y0[:n] - y[:n])
        print(f"LEN={n} MAE={float(d.mean()):.8f} MAXABS={float(d.max()):.8f} MINABS={float(d.min()):.8f}")
    except Exception as e:
        print(f"[WARN] 对比现有 best_series 失败: {e}")


if __name__ == '__main__':  # pragma: no cover
    main()

