"""Moved: experiments.core_optimization.shared.optimization.tools.plot_sim_vs_obs
(Original path: experiments.core_optimization.shared.optimization.plot_sim_vs_obs)
"""
from __future__ import annotations
import sys
from pathlib import Path
from typing import Any, Dict
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[4]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.runtime.metrics import nse as _nse
from src.runtime.semi_distributed.core.config_loader import load_run_config_internal as _load_run_config, set_run_config_path  # noqa: E402
from src.runtime.semi_distributed.core.pipeline import prepare_calibration_session, select_floods_series  # noqa: E402


def main(run_config: str | None = None, series_path: str | None = None, out_png: str | None = None):
    # 读取配置
    if run_config:
        set_run_config_path(Path(run_config))
    
    file_cfg: Dict[str, Any] = _load_run_config()

    def _cfg_get(key: str, default=None):
        if not isinstance(file_cfg, dict):
            return default
        if key in file_cfg:
            return file_cfg.get(key, default)
        scene = file_cfg.get('scene')
        if isinstance(scene, dict) and key in scene:
            return scene.get(key, default)
        optimizer_blk = file_cfg.get('optimizer')
        if isinstance(optimizer_blk, dict) and key in optimizer_blk:
            return optimizer_blk.get(key, default)
        time_blk = file_cfg.get('time')
        if isinstance(time_blk, dict) and key in time_blk:
            return time_blk.get(key, default)
        return default

    # 注入内联模型（与优化一致）
    from src.runtime.semi_distributed.core.optimization_config import OptimizationConfig
    cfg = OptimizationConfig()

    # Set CONFIG_DIR from run_config path so calibration YAML can be found
    if run_config:
        cfg.CONFIG_DIR = Path(run_config).resolve().parent

    _basin = _cfg_get('basin_name')
    if _basin:
        cfg.set_basin_name(_basin)
    _section = _cfg_get('section')
    if _section:
        cfg.set_section(_section)
    _sim_unit = _cfg_get('sim_unit')
    if _sim_unit:
        cfg.set_sim_unit(_sim_unit)
    _matrix_prefix = _cfg_get('matrix_prefix')
    if _matrix_prefix:
        cfg.set_matrix_prefix(_matrix_prefix)
    _calib_anchor = _cfg_get('calib_anchor')
    if _calib_anchor:
        cfg.set_calib_anchor(_calib_anchor)
    _objective_flow = _cfg_get('objective_flow')
    if _objective_flow:
        cfg.set_objective_flow(_objective_flow)
    _calib_nodes = _cfg_get('calib_nodes')
    if _calib_nodes:
        cfg.select_calib_nodes(_calib_nodes)
    _verify_nodes = _cfg_get('verify')
    if _verify_nodes:
        cfg.set_verify_nodes(_verify_nodes)
    # 同步旧字段，确保 select_floods_series 不触发严格模式回退
    setattr(cfg, 'EVAL_STATION', getattr(cfg, 'CALIB_ANCHOR', None))
    setattr(cfg, 'FLOW_SOURCE_STATION', getattr(cfg, 'OBJECTIVE_FLOW', None))

    # 与优化保持一致的时段/覆写设置
    override = _cfg_get('override')
    if override is not None:
        if isinstance(override, str):
            stations = [s.strip() for s in override.split(',') if s.strip()]
            cfg.set_override_stations(stations)
        elif isinstance(override, (list, tuple)):
            cfg.set_override_stations([str(s).strip() for s in override if str(s).strip()])
        else:
            cfg.set_override_stations([str(override).strip()])
    _start = _cfg_get('start_date')
    if isinstance(_start, str) and _start.strip():
        cfg.START_TIME = _start
    _end = _cfg_get('end_date')
    if isinstance(_end, str) and _end.strip():
        cfg.END_TIME = _end
    # 注意: 跟 forecast_runner.py 一致 — _exclude 为 None 时也覆盖为空 set,
    # 不要 fallback 到 class default (历史教训: namou_kuwei 因没显式 exclude_years
    # 被 default {2010, 2018} silent 排除 2018 整年)
    _exclude = _cfg_get('exclude_years')
    try:
        if _exclude is None:
            cfg.EXCLUDE_YEARS = set()
        elif isinstance(_exclude, (list, tuple, set)):
            cfg.EXCLUDE_YEARS = set(int(x) for x in _exclude)
        elif isinstance(_exclude, str):
            cfg.EXCLUDE_YEARS = set(int(s.strip()) for s in _exclude.split(',') if s.strip())
        else:
            cfg.EXCLUDE_YEARS = {int(_exclude)}
    except Exception:
        cfg.EXCLUDE_YEARS = set()
    # exclude_mode (2026-05-27): mask / drop / 缺失 raise (在 dataio._resolve_exclude_config)
    _em = _cfg_get('exclude_mode')
    cfg.EXCLUDE_MODE = (str(_em).strip().lower() if isinstance(_em, str) and _em.strip() else None)

    _dt = _cfg_get('dt_hours') or _cfg_get('DT_HOURS') or _cfg_get('time_step_hours')
    if _dt:
        try:
            cfg.set_time_step_hours(_dt)
        except Exception:
            pass

    # 数据路径
    _meteo = _cfg_get('meteo_file')
    if _meteo:
        cfg.set_meteo_file(_meteo)
    _data_dir = _cfg_get('data_dir')
    if _data_dir:
        data_path = Path(_data_dir)
        if not data_path.is_absolute():
            data_path = cfg.PROJECT_ROOT / data_path
        cfg.DATA_DIR = data_path

    model_block = file_cfg.get('model') if isinstance(file_cfg, dict) else None
    if isinstance(model_block, dict) and str(model_block.get('mode','')).lower() == 'inline':
        data_blk = model_block.get('data', {})
        setattr(cfg, 'INLINE_TOPOLOGY', data_blk.get('topology'))
        setattr(cfg, 'INLINE_CALIB', data_blk.get('calibration'))
        setattr(cfg, 'INLINE_PDD_XAJ', data_blk.get('pdd_xaj'))
        try:
            ic_inline = None
            if isinstance(data_blk, dict):
                if 'initial_conditions' in data_blk:
                    ic_inline = data_blk.get('initial_conditions')
                if ic_inline is None and 'initial_conditions_file' in data_blk:
                    ic_inline = data_blk.get('initial_conditions_file')
            if isinstance(ic_inline, (dict, str)):
                setattr(cfg, 'INLINE_INITIAL_CONDITIONS', ic_inline)
        except Exception:
            pass

    # 会话与观测
    sess = prepare_calibration_session(cfg)
    (rain, temp, snow, pet) = sess['meteo_inputs']
    time_index = sess.get('time_index')
    msk_layers = sess['msk_layers']
    discharge_outlet = sess['discharge_outlet']
    discharge_inflow = sess['discharge_inflow']
    eval_station = getattr(cfg, 'EVAL_STATION', None)

    series, abort_flag = select_floods_series(cfg, discharge_outlet, discharge_inflow, eval_station, msk_layers)
    if abort_flag or series is None:
        print('[ERROR] 无可用目标流量，终止。')
        return 2
    qobs = np.asarray(series.values, dtype=np.float32)

    # 读取模拟序列
    if out_png:
        out_dir = Path(out_png).expanduser().resolve().parent
    elif series_path:
        out_dir = Path(series_path).expanduser().resolve().parent
    else:
        out_dir = (Path('results') / 'fh_optimize').resolve()
    if series_path is None:
        series_path = str(out_dir / 'best_series.npy')
    if out_png is None:
        out_png = str(out_dir / 'sim_vs_obs.png')
    sim = np.load(series_path)

    # 对齐长度
    T = min(qobs.shape[0], sim.shape[0])
    qobs = qobs[:T]
    sim = sim[:T]
    if time_index is not None:
        t_index = pd.DatetimeIndex(time_index[:T])
    else:
        t_index = pd.RangeIndex(T)

    nse = _nse(sim, qobs)
    print(f"[PLOT] NSE={nse:.6f}, T={T}")

    # 输出 CSV
    df = pd.DataFrame({'time': t_index, 'q_obs': qobs, 'q_sim': sim})
    csv_path = Path(out_png).with_name('sim_vs_obs.csv')
    df.to_csv(csv_path, index=False)

    # 绘图
    plt.figure(figsize=(10, 4))
    plt.plot(t_index, qobs, label='Observed', lw=1.2)
    plt.plot(t_index, sim, label='Simulated', lw=1.2)
    plt.title(f"Sim vs Obs (NSE={nse:.3f})")
    plt.xlabel('Time')
    plt.ylabel('Discharge')
    plt.legend(frameon=False)
    plt.tight_layout()
    Path(out_png).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_png, dpi=150)
    plt.close()
    print(f"[PLOT] Saved figure: {out_png}")
    print(f"[PLOT] Saved CSV: {csv_path}")
    return 0


if __name__ == '__main__':  # pragma: no cover
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--run-config', help='run_config.yml 路径')
    ap.add_argument('--series', help='best_series.npy 路径')
    ap.add_argument('--out', help='输出 PNG 路径')
    args = ap.parse_args()
    raise SystemExit(main(args.run_config, args.series, args.out))

