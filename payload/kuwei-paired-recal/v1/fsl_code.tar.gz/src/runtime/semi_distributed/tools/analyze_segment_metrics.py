from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd


def _nse(sim: np.ndarray, obs: np.ndarray) -> float:
    mask = np.isfinite(obs) & np.isfinite(sim)
    if mask.sum() < 2:
        return float('nan')
    s = sim[mask]
    o = obs[mask]
    denom = float(np.sum((o - np.mean(o)) ** 2))
    if denom <= 0:
        return float('nan')
    return 1.0 - float(np.sum((s - o) ** 2)) / denom


def _rmse(sim: np.ndarray, obs: np.ndarray) -> float:
    mask = np.isfinite(obs) & np.isfinite(sim)
    if mask.sum() < 1:
        return float('nan')
    s = sim[mask]
    o = obs[mask]
    return float(np.sqrt(np.mean((s - o) ** 2)))


def _mae(sim: np.ndarray, obs: np.ndarray) -> float:
    mask = np.isfinite(obs) & np.isfinite(sim)
    if mask.sum() < 1:
        return float('nan')
    s = sim[mask]
    o = obs[mask]
    return float(np.mean(np.abs(s - o)))


def compute_segment_metrics(csv_path: Path, out_csv: Path) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    if not set(['q_obs','q_sim']).issubset(df.columns):
        raise ValueError(f"CSV 缺少必须列: q_obs, q_sim ({csv_path})")
    o = df['q_obs'].to_numpy(dtype=float)
    s = df['q_sim'].to_numpy(dtype=float)
    # 观测分位阈值
    q80 = float(np.nanquantile(o, 0.8))
    q90 = float(np.nanquantile(o, 0.9))
    bins = [('-inf,0.8)', o < q80), ('[0.8,0.9)', (o >= q80) & (o < q90)), ('[0.9,1.0]', o >= q90)]
    rows = []
    for name, mask in bins:
        seg_o = o[mask]
        seg_s = s[mask]
        rows.append({
            'segment': name,
            'count': int(np.isfinite(seg_o).sum()),
            'nse': _nse(seg_s, seg_o),
            'rmse': _rmse(seg_s, seg_o),
            'mae': _mae(seg_s, seg_o),
            'obs_q_min': float(np.nanmin(seg_o)) if seg_o.size else float('nan'),
            'obs_q_max': float(np.nanmax(seg_o)) if seg_o.size else float('nan'),
        })
    out_df = pd.DataFrame(rows)
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    out_df.to_csv(out_csv, index=False, encoding='utf-8')
    return out_df


def main():
    ap = argparse.ArgumentParser(description='按观测分位段计算分段 NSE/RMSE/MAE')
    ap.add_argument('--csv', type=str, default='results/fh_optimize/sim_vs_obs.csv', help='输入 sim_vs_obs.csv')
    ap.add_argument('--out', type=str, default='results/fh_optimize/segment_metrics.csv', help='输出 CSV 路径')
    args = ap.parse_args()
    out_df = compute_segment_metrics(Path(args.csv), Path(args.out))
    # 控制台摘要
    try:
        top = out_df[out_df['segment'] == '[0.9,1.0]'].iloc[0]
        print(f"[SEG] top10% count={int(top['count'])} NSE={float(top['nse']):.4f} RMSE={float(top['rmse']):.4f} MAE={float(top['mae']):.4f}")
    except Exception:
        pass


if __name__ == '__main__':
    main()

