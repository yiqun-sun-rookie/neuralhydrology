from __future__ import annotations
from src.runtime.semi_distributed.core.optimization_config import OptimizationConfig
from src.runtime.semi_distributed.core.topology import build_msk_layers_and_connect_mat
from src.runtime.semi_distributed.core.visualize_topology import (
    plot_connection_matrix, plot_msk_layers_summary
)


def main():
    cfg = OptimizationConfig()
    msk_layers, connection_matrices = build_msk_layers_and_connect_mat(cfg)
    plot_msk_layers_summary(msk_layers)
    mats = connection_matrices
    if isinstance(mats, (list, tuple)):
        for i, cm in enumerate(mats):
            up_names = msk_layers[i].get("names") if isinstance(msk_layers[i], dict) else None
            dn_names = msk_layers[i+1].get("names") if (i+1) < len(msk_layers) and isinstance(msk_layers[i+1], dict) else None
            plot_connection_matrix(cm, title=f"Connection matrix (layer {i}→{i+1})",
                                   x_labels=up_names, y_labels=dn_names)
    else:
        plot_connection_matrix(mats, title="Connection matrix")


if __name__ == "__main__":
    main()

