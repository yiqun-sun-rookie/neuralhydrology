# Moved: experiments.core_optimization.shared.optimization.tools.validate_and_generate_grid_basin_relation_matrix1
# (Original path: experiments.core_optimization.shared.optimization.validate_and_generate_grid_basin_relation_matrix1)
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import sys, json, os, pathlib

# ========= 0. 用户可修改的参数 =========
GRID_SUB_CSV  = ""
SUB_BASIN_CSV = ""

BASE_OUT_DIR = pathlib.Path(
    rf"F:\\github\\pycharm\\projects\\forecast_system_lite\\experiments\\semi_distributed\\matrix_mutiple_sections"
)
BASIN_NAME = os.environ.get("MATRIX_BASIN_NAME", "yingluoxia")

OUT_DIR = (BASE_OUT_DIR / BASIN_NAME) if BASIN_NAME else BASE_OUT_DIR
OUT_DIR.mkdir(parents=True, exist_ok=True)
print(f"[Info] BASIN_NAME={BASIN_NAME} -> OUT_DIR={OUT_DIR}")

source_csv_dir = OUT_DIR / "source_csv"

def _auto(path_str: str, fname: str) -> pathlib.Path:
    if path_str:
        p = pathlib.Path(path_str)
        if not p.exists():
            sys.exit(f"[ERROR] 指定文件不存在: {p}")
        return p
    candidate = source_csv_dir / fname
    if candidate.exists():
        return candidate
    candidate2 = OUT_DIR / fname
    if candidate2.exists():
        return candidate2
    sys.exit(f"[ERROR] 未找到 {fname}，请检查: {candidate} 或 {candidate2}")

GRID_SUB_PATH  = _auto(GRID_SUB_CSV,  "grid_sub.csv")
SUB_BASIN_PATH = _auto(SUB_BASIN_CSV, "sub_basins.csv")
print(f"[Info] 使用 grid_sub: {GRID_SUB_PATH}")
print(f"[Info] 使用 sub_basins: {SUB_BASIN_PATH}")

SUBSEL_ID  = [2]
SUBSEL_IDX = None

WRITE_STANDARD_TO_SUBDIR = True
GENERATE_EACH_SUBBASIN = True

# ---------- 1. 读取 ----------
g2s   = pd.read_csv(GRID_SUB_PATH)
if 'Sub_Id' not in g2s.columns and 'subbasin_id' in g2s.columns:
    g2s = g2s.rename(columns={'subbasin_id': 'Sub_Id'})
if 'FID' not in g2s.columns and 'grid_id' in g2s.columns:
    g2s = g2s.rename(columns={'grid_id': 'FID'})
sarea = pd.read_csv(SUB_BASIN_PATH)

HAS_CELL_AREA = 'cell_area_km2' in g2s.columns
HAS_SUB_NAME  = 'sub_name' in g2s.columns
HAS_LON_LAT   = {'lon','lat'}.issubset(g2s.columns)
print(f"[Info] grid_sub schema: cell_area={HAS_CELL_AREA}, sub_name={HAS_SUB_NAME}, lonlat={HAS_LON_LAT}")

for need, frame, path in [
    ({'FID','Sub_Id'}, g2s, GRID_SUB_PATH),
    ({'Id','Area_km2'}, sarea, SUB_BASIN_PATH)
]:
    if not need.issubset(frame.columns):
        sys.exit(f"[ERROR] {path} 缺少列 {need} (现有列: {list(frame.columns)})")
Ng_full, Ns_full = len(g2s), len(sarea)
print(f"[Info] Ng={Ng_full}, Ns={Ns_full}")

sub_ids_sorted = sarea.Id.astype(int).sort_values().to_numpy()
sub_id_set = set(sub_ids_sorted)
raw_sub_vals = g2s.Sub_Id.astype(int).to_numpy()
need_fix = not set(raw_sub_vals).issubset(sub_id_set)
fixed_mode = None
if need_fix:
    unique_vals_sorted = sorted(set(raw_sub_vals))
    if unique_vals_sorted == list(range(len(sub_ids_sorted))):
        idx2real = {i: int(sub_ids_sorted[i]) for i in range(len(sub_ids_sorted))}
        g2s['Sub_Id_original'] = g2s['Sub_Id']
        g2s['Sub_Id'] = g2s['Sub_Id'].map(idx2real)
        fixed_mode = "index->Id"
    else:
        shifted = [v+1 for v in raw_sub_vals]
        if set(shifted).issubset(sub_id_set):
            g2s['Sub_Id_original'] = g2s['Sub_Id']
            g2s['Sub_Id'] = g2s['Sub_Id'] + 1
            fixed_mode = "+1 shift"

if fixed_mode:
    print(f"[Info] 检测到 Sub_Id 与 sub_basins Id 不直接匹配，已自动修正模式: {fixed_mode}")
    raw_sub_vals = g2s.Sub_Id.astype(int).to_numpy()
    need_fix = False

if need_fix:
    miss_vals = sorted(v for v in set(raw_sub_vals) if v not in sub_id_set)
    sys.exit(f"[ERROR] Sub_Id {miss_vals} 未在 sub_basins.csv 的 Id 中找到，且无法自动修正")

sid2idx = {sid: i for i, sid in enumerate(sub_ids_sorted)}
g2s['sub_idx'] = g2s.Sub_Id.map(sid2idx)

# ---------- 4. 全流域矩阵 ----------
grid_to_sub_full = np.zeros((Ng_full, Ns_full), np.float32)
grid_to_sub_full[np.arange(Ng_full), g2s['sub_idx']] = 1.0
grid_counts_full = g2s.groupby('sub_idx').size().reindex(range(Ns_full)).to_numpy()

if HAS_CELL_AREA:
    cell_area_full = g2s['cell_area_km2'].astype(np.float32).to_numpy()
    print("[Info] 使用 grid_sub.csv 中的真实 cell_area_km2")
else:
    cell_area_full = (
        sarea.Area_km2.to_numpy()[g2s['sub_idx']] / grid_counts_full[g2s['sub_idx']]
    ).astype(np.float32)
    print("[Info] 未检测到 cell_area_km2 列，采用均分模式估算格点面积")

sub_area_full = sarea.Area_km2.to_numpy().astype(np.float32)

sub_area_from_cells = None
if HAS_CELL_AREA:
    sub_area_from_cells = g2s.groupby('sub_idx')['cell_area_km2'].sum() \
        .reindex(range(Ns_full)).to_numpy(dtype=float)
    area_abs_diff_new = np.abs(sub_area_from_cells - sub_area_full)
    print(
        f"[Info] 子流域面积对比：最大绝对差={area_abs_diff_new.max():.3f} km2; "
        f"最大相对差={(area_abs_diff_new/(sub_area_full+1e-12)).max():.4f}"
    )

DO_VALIDATE_PARTITION = True
PLOT_VALIDATION = True
if DO_VALIDATE_PARTITION:
    row_sum = grid_to_sub_full.sum(axis=1)
    col_sum = grid_to_sub_full.sum(axis=0)
    miss_idx = np.where(row_sum < 0.5)[0]
    overlap_idx = np.where(row_sum > 1.5)[0]
    zero_cols = np.where(col_sum < 0.5)[0]
    report = {
        "Ng": int(Ng_full),
        "Ns": int(Ns_full),
        "row_sum_min": float(row_sum.min()),
        "row_sum_max": float(row_sum.max()),
        "rows_missing_count": int(len(miss_idx)),
        "rows_overlap_count": int(len(overlap_idx)),
        "subbasins_zero_cell_count": int(len(zero_cols)),
        "subbasins_zero_cell_ids": [int(sub_ids_sorted[i]) for i in zero_cols],
    }
    recon_sub_area = []
    for j in range(Ns_full):
        mask = grid_to_sub_full[:, j] > 0.5
        recon_sub_area.append(float(cell_area_full[mask].sum()))
    recon_sub_area = np.array(recon_sub_area, dtype=float)
    area_abs_diff = np.abs(recon_sub_area - sub_area_full)
    report['sub_area_abs_diff_max'] = float(area_abs_diff.max())
    report['sub_area_abs_diff_mean'] = float(area_abs_diff.mean())
    report['sub_area_rel_diff_max'] = float((area_abs_diff / (sub_area_full + 1e-12)).max())
    if sub_area_from_cells is not None:
        area_abs_diff_true = np.abs(sub_area_from_cells - sub_area_full)
        report['sub_area_from_cells_abs_diff_max'] = float(area_abs_diff_true.max())
        report['sub_area_from_cells_abs_diff_mean'] = float(area_abs_diff_true.mean())
        report['sub_area_from_cells_rel_diff_max'] = float((area_abs_diff_true / (sub_area_full + 1e-12)).max())

    with open(OUT_DIR / "partition_validation_report.json", "w", encoding="utf-8") as fp:
        json.dump(report, fp, indent=2, ensure_ascii=False)
    print("[VALIDATE] 分区验证报告:", report)

if PLOT_VALIDATION:
    try:
        plt.figure(figsize=(6, 4))
        plt.hist(grid_to_sub_full.sum(axis=1), bins=50)
        plt.title("Row sum (coverage)")
        plt.tight_layout()
        plt.savefig(OUT_DIR / "row_sum_hist.png", dpi=150)
        plt.close()

        plt.figure(figsize=(6, 4))
        plt.hist(grid_to_sub_full.sum(axis=0), bins=50)
        plt.title("Col sum (grid counts per subbasin)")
        plt.tight_layout()
        plt.savefig(OUT_DIR / "col_sum_hist.png", dpi=150)
        plt.close()

        print("[VALIDATE] 验证直方图输出到 OUT_DIR")
    except Exception as e:
        print(f"[VALIDATE] 画图失败: {e}")

# ... 余下生成标准文件与子集保存的逻辑省略，保持与原脚本一致 ...

