"""Moved: experiments.core_optimization.shared.optimization.tools.precheck_setup
(Original path: experiments.core_optimization.shared.optimization.precheck_setup)
"""
from __future__ import annotations
import argparse
from src.runtime.semi_distributed.core.optimization_config import OptimizationConfig
from src.runtime.semi_distributed.core.topology import build_msk_layers_and_connect_mat
from src.runtime.semi_distributed.core.params import setup_model_and_config
from src.runtime.semi_distributed.core.validation import collect_context, run_validations, write_validation_report
import numpy as np
import pandas as pd
from pathlib import Path


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument('--section', default='ylx')
    ap.add_argument('--eval-station')
    ap.add_argument('--calib-nodes')
    ap.add_argument('--override-stations')
    ap.add_argument('--flow-source', dest='flow_source')
    return ap.parse_args()


def apply_cli(cfg: OptimizationConfig, args):
    cfg.set_section(args.section)
    if args.eval_station:
        cfg.set_eval_station(args.eval_station)
    if args.calib_nodes:
        cfg.select_calib_nodes(args.calib_nodes)
    if args.override_stations:
        if args.override_stations.lower() in ('none','[]'):
            cfg.set_override_stations([])
        else:
            cfg.set_override_stations([s for s in args.override_stations.split(',') if s])
    if args.flow_source:
        cfg.FLOW_SOURCE_STATION = args.flow_source
    return cfg


def main():
    args = parse_args()
    cfg = OptimizationConfig()
    apply_cli(cfg, args)

    # 1. 读取矩阵
    prefix = cfg.MATRIX_PREFIX
    basin_dir = cfg.BASIN_DIR
    std_dir = basin_dir / prefix
    g2s_csv = std_dir / 'grid_to_subbasin_map.csv'
    sarea_csv = std_dir / 'sub_area.csv'
    if not g2s_csv.exists() or not sarea_csv.exists():
        raise FileNotFoundError('缺少矩阵文件')
    grid2sub = pd.read_csv(g2s_csv).to_numpy(dtype=np.float32)
    sub_area_df = pd.read_csv(sarea_csv)
    sub_area = sub_area_df[sub_area_df.columns[0]].to_numpy(dtype=np.float32)
    Ng, Ns = grid2sub.shape

    # 2. 拓扑
    msk_layers, connection_matrices = build_msk_layers_and_connect_mat(cfg)

    # 3. 模型/率定配置 (新版签名: (cfg, n_basins, msk_layers, Ng))
    _, calib_cfg, _ = setup_model_and_config(cfg, Ns, msk_layers, Ng)

    # 4. 上下文 + 验证
    override_stations = getattr(cfg, 'OVERRIDE_STATIONS', None)
    eval_station = getattr(cfg, 'EVAL_STATION', None)
    ctx = collect_context(cfg, msk_layers, connection_matrices, calib_cfg, eval_station, override_stations)
    issues = run_validations(ctx)
    write_validation_report(cfg, issues)
    n_err = sum(1 for i in issues if i.level=='ERROR')
    n_warn = sum(1 for i in issues if i.level=='WARN')
    print(f"[PRECHECK] ERROR={n_err} WARN={n_warn}")
    for it in issues:
        print(f"[{it.level}] {it.code}: {it.message}")
    if n_err>0:
        print('[PRECHECK] 存在 ERROR, 请先修正再进行率定。')
    else:
        print('[PRECHECK] 通过 (可开始率定)。')


if __name__ == '__main__':
    main()

