from __future__ import annotations
import os
from pathlib import Path
from typing import Any, Dict, List, Optional
import sys as _sys

import numpy as np
import pandas as pd
import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[4]
if str(PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(PROJECT_ROOT))

from src.runtime.semi_distributed.core.optimization_config import OptimizationConfig  # noqa: E402
from src.runtime.semi_distributed.core.dataio import load_data  # noqa: E402

DEFAULT_CFG_PATH = PROJECT_ROOT / "config" / "experiments" / "station_total_meteo.yml"


def _read_yaml(path: Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def _cfg_get(file_cfg: Dict[str, Any], key: str, default=None):
    if not isinstance(file_cfg, dict):
        return default
    if key in file_cfg:
        return file_cfg.get(key, default)
    scene = file_cfg.get('scene')
    if isinstance(scene, dict) and key in scene:
        return scene.get(key, default)
    return default


def _apply_base_config_to(cfg: OptimizationConfig, base_cfg: Dict[str, Any], overrides: Dict[str, Any]) -> None:
    _sec = _cfg_get(base_cfg, 'section');            _sec and cfg.set_section(_sec)
    _simu = _cfg_get(base_cfg, 'sim_unit');          _simu and cfg.set_sim_unit(_simu)
    _st = _cfg_get(base_cfg, 'start_date');          (isinstance(_st, str) and _st.strip()) and setattr(cfg, 'START_TIME', _st)
    _ed = _cfg_get(base_cfg, 'end_date');            (isinstance(_ed, str) and _ed.strip()) and setattr(cfg, 'END_TIME', _ed)
    _exy = _cfg_get(base_cfg, 'exclude_years')
    if _exy is not None:
        try:
            if isinstance(_exy, (list, tuple, set)):
                setattr(cfg, 'EXCLUDE_YEARS', set(int(x) for x in _exy))
            elif isinstance(_exy, str):
                years = [int(s.strip()) for s in _exy.split(',') if s.strip()]
                setattr(cfg, 'EXCLUDE_YEARS', set(years))
            else:
                setattr(cfg, 'EXCLUDE_YEARS', {int(_exy)})
        except Exception:
            pass
    time_blk = overrides.get('time') or {}
    if isinstance(time_blk, dict):
        ts = time_blk.get('start_date'); te = time_blk.get('end_date'); ex = time_blk.get('exclude_years')
        (isinstance(ts, str) and ts.strip()) and setattr(cfg, 'START_TIME', ts)
        (isinstance(te, str) and te.strip()) and setattr(cfg, 'END_TIME', te)
        if ex is not None:
            try:
                if isinstance(ex, (list, tuple, set)):
                    setattr(cfg, 'EXCLUDE_YEARS', set(int(x) for x in ex))
                elif isinstance(ex, str):
                    years = [int(s.strip()) for s in ex.split(',') if s.strip()]
                    setattr(cfg, 'EXCLUDE_YEARS', set(years))
                else:
                    setattr(cfg, 'EXCLUDE_YEARS', {int(ex)})
            except Exception:
                pass


def _read_station_daily_precip(station_dir: Path, station_ids: List[str]) -> pd.DataFrame:
    frames: List[pd.Series] = []
    cols: List[str] = []
    for sid in station_ids:
        sid_dir = station_dir / sid
        if not sid_dir.exists():
            continue
        series_list: List[pd.Series] = []
        for fp in sorted(sid_dir.glob("*.xlsx")):
            try:
                df = pd.read_excel(fp)
                if 'P' not in df or 'Time' not in df:
                    continue
                s = pd.Series(df['P'].values, index=pd.to_datetime(df['Time']), name=sid)
                series_list.append(s)
            except Exception:
                continue
        if series_list:
            ser = pd.concat(series_list).sort_index()
            ser.name = sid
            frames.append(ser)
            cols.append(sid)
    if not frames:
        raise FileNotFoundError(f"未在 {station_dir} 读取到任何有效站点降水")
    df_out = pd.concat(frames, axis=1)
    df_out.columns = cols
    return df_out


def _combine_station_total(df: pd.DataFrame, strategy: str, weights: Optional[Dict[str, float]]) -> pd.Series:
    stg = (strategy or 'mean').strip().lower()
    if stg == 'ylx':
        if 'ylx' not in df.columns:
            raise ValueError("strategy=ylx 但未找到 ylx 列")
        out = df['ylx'].astype(np.float32)
    elif stg == 'weighted':
        if not weights:
            raise ValueError("strategy=weighted 需要提供 weights")
        use_cols = [c for c in df.columns if c in weights]
        if not use_cols:
            raise ValueError("weights 与站点列无交集")
        w = np.array([float(weights[c]) for c in use_cols], dtype=np.float64)
        wsum = float(np.sum(w))
        if not np.isfinite(wsum) or wsum <= 0:
            raise ValueError("weights 非法或权重和为0")
        w = w / wsum
        out = (df[use_cols].to_numpy(np.float32) @ w.astype(np.float32)).astype(np.float32)
        out = pd.Series(out, index=df.index, name='station_total')
    else:
        out = df.mean(axis=1).astype(np.float32)
    out.name = 'station_total'
    return out


def main():
    cfg_path = DEFAULT_CFG_PATH
    if not cfg_path.exists():
        raise FileNotFoundError(f"未找到配置: {cfg_path}")
    job_cfg = _read_yaml(cfg_path)

    base_run_cfg_path = str(job_cfg.get('base_run_config') or "basins/ylx/config/run_config_ylx_downstream.yml")
    from src.runtime.semi_distributed.core import config_loader as _config_loader
    _config_loader.set_run_config_path(Path(base_run_cfg_path))
    base_cfg = _config_loader.load_run_config_internal()

    cfg = OptimizationConfig()
    _apply_base_config_to(cfg, base_cfg, job_cfg)

    base_meteo_path = PROJECT_ROOT / str(job_cfg.get('base_meteo_file') or "data/reference/semi_distributed/grid_meteo_pet_daily.csv")
    output_path = PROJECT_ROOT / str(job_cfg.get('output_file') or "data/reference/semi_distributed/grid_meteo_with_station_total.csv")
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # 强制使用指定 meteo 文件
    os.environ['METEO_FILE'] = str(base_meteo_path)

    meteo_df, _, _ = load_data(cfg)
    if 'time' not in meteo_df.columns:
        raise ValueError("基础气象表缺少 time 列")

    sp_blk = job_cfg.get('station_precip') or {}
    _sp_dir = sp_blk.get('dir')
    if not _sp_dir:
        raise ValueError("station_precip.dir is required in run_config. No hardcoded fallback.")
    station_dir = PROJECT_ROOT / str(_sp_dir)
    strategy = str(sp_blk.get('strategy') or 'mean')
    stations = list(sp_blk.get('stations') or ['ylx', 'zmsk', 'ql'])
    weights = sp_blk.get('weights')
    align_method = str(sp_blk.get('align_method') or 'interpolate').lower()

    df_sta = _read_station_daily_precip(station_dir, stations)
    df_sta = df_sta.reindex(meteo_df['time'])
    if align_method == 'interpolate':
        df_sta = df_sta.interpolate(method='time').ffill().bfill()
    else:
        df_sta = df_sta.ffill().bfill()
    df_sta = df_sta.astype(np.float32)
    if (~np.isfinite(df_sta.to_numpy(np.float32))).any():
        raise ValueError("站点降水在对齐/填充后仍存在 NaN/Inf")
    station_total = _combine_station_total(df_sta, strategy, weights)

    meteo_with_total = meteo_df.copy()
    meteo_with_total['station_total'] = np.asarray(station_total.values, dtype=np.float32)
    meteo_with_total.to_csv(output_path, index=False)
    print(f"[OK] 已生成包含 station_total 的气象文件: {output_path}")


if __name__ == '__main__':  # pragma: no cover
    main()



