"""Backward compatibility shim for optimization metrics."""

from src.runtime.metrics import *  # noqa: F401,F403


