#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
绘制 Nam Ou (Kuwei) 模拟 vs 观测对比图

用法:
    python experiments/semi_distributed/optimization/tools/plot_namou_kuwei_result.py
"""
from __future__ import annotations
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[4]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import pickle
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from src.runtime.semi_distributed import optimize_semidistributed as opt
from src.runtime.semi_distributed.core.optimization_config import OptimizationConfig
from src.runtime.semi_distributed.core.pipeline import prepare_calibration_session
from src.runtime.metrics import nse


def find_latest_params(result_dir: Path) -> Path:
    """找到最新的最佳参数文件"""
    pkl_files = list(result_dir.glob("best_params_namou_kuwei_*.pkl"))
    if not pkl_files:
        raise FileNotFoundError(f"No pkl files found in {result_dir}")
    # 按文件名排序，取最新的
    pkl_files.sort(key=lambda x: x.stem, reverse=True)
    return pkl_files[0]


def main():
    # 配置路径
    run_config_path = PROJECT_ROOT / "config/basins/namou_kuwei/run_config_msk_segmented.yml"
    result_dir = PROJECT_ROOT / "results/experiments/namou_kuwei"
    
    # 加载最佳参数
    params_file = find_latest_params(result_dir)
    print(f"[INFO] Loading params from: {params_file}")
    with open(params_file, 'rb') as f:
        best_data = pickle.load(f)
    
    best_params = best_data.get('best_params', best_data)
    
    # 加载配置
    opt.RUN_CONFIG_FILE = run_config_path
    file_cfg = opt.load_run_config_internal()
    
    # 配置对象
    cfg = OptimizationConfig()
    cfg.set_basin_name('namou_kuwei')
    cfg.set_section('namou_kuwei')
    cfg.set_sim_unit('subbasin')
    cfg.set_matrix_prefix('full')
    cfg.set_calib_anchor('kuwei')
    cfg.set_objective_flow('outlet_series')
    cfg.START_TIME = '2020-01-01'
    cfg.END_TIME = '2021-12-31'
    cfg.set_time_step_hours(1)
    cfg.set_meteo_file('data/namou_kuwei/grid_meteo_pet_hourly_rain1.25_pet0.4.csv')
    cfg.DATA_DIR = Path('data/processed/namou_kuwei')
    cfg.EVAL_STATION = 'kuwei'
    cfg.FLOW_SOURCE_STATION = 'outlet_series'
    
    # 注入内联模型
    model_block = file_cfg.get('model', {})
    data_blk = model_block.get('data', {})
    setattr(cfg, 'INLINE_TOPOLOGY', data_blk.get('topology'))
    setattr(cfg, 'INLINE_CALIB', data_blk.get('calibration'))
    setattr(cfg, 'INLINE_PDD_XAJ', data_blk.get('pdd_xaj'))
    setattr(cfg, 'INLINE_INITIAL_CONDITIONS', data_blk.get('initial_conditions'))
    
    # 准备会话
    session = prepare_calibration_session(cfg)
    
    # 获取观测流量
    discharge_outlet = session['discharge_outlet']
    time_index = session['time_index']
    q_obs = discharge_outlet.values
    
    print(f"[INFO] Obs shape: {q_obs.shape}, dates: {len(time_index)}")
    
    # 使用 prepare_model_params 和 _simulate_core 运行模拟
    from src.kernels.semi_distributed.core.simulate_flood_distributed_fast import (
        _simulate_core, prepare_initial_conditions
    )
    from src.runtime.semi_distributed.core.params import prepare_model_params
    
    calib_cfg = session['calib_cfg']
    default_params = session['default_params']
    grid2sub = session['grid2sub']
    sub_area = session['sub_area']
    Ng = session['Ng']
    Ns = session['Ns']
    connection_matrices = session['connection_matrices']
    init_cond = session['init_cond']
    meteo_inputs = session['meteo_inputs']
    
    # 使用 prepare_model_params 构造模拟参数
    merged_model, pdd_tuple, xaj_tuple, msk_layers_params_tuples, core_args = prepare_model_params(
        param_dict=best_params,
        model_params_template=default_params,
        calibration_config=calib_cfg,
        grid2sub=grid2sub,
        sub_area=sub_area,
        connection_matrices=connection_matrices,
        param_mode={
            'msk_params': {'*': 'sub'},
            'xaj_params': {'*': 'basin'},
            'pdd_params': {'*': 'basin'},
        },
    )
    
    # 初始状态
    init_state_arr = prepare_initial_conditions(init_cond, Ng, enable_snowmelt=False)
    
    # 模拟
    rain, temp, snow, pet = meteo_inputs
    sim_ret = _simulate_core(
        rain, temp, snow, pet,
        pdd_tuple, xaj_tuple,
        grid2sub.astype(np.float32),
        init_state_arr,
        return_last_layer=True,
        **core_args,
    )
    
    if len(sim_ret) == 3:
        q_grid, q_subs, q_outlet = sim_ret
    else:
        q_grid, q_subs, q_outlet, q_last_layer = sim_ret
    
    q_sim = q_outlet
    print(f"[INFO] Sim shape: {q_sim.shape}")
    
    # 计算 NSE
    valid_mask = ~np.isnan(q_obs) & ~np.isnan(q_sim)
    nse_val = nse(q_obs[valid_mask], q_sim[valid_mask])
    print(f"[INFO] NSE: {nse_val:.4f}")
    
    # ========== 分年绘图 ==========
    dates = time_index
    df = pd.DataFrame({'date': dates, 'obs': q_obs, 'sim': q_sim})
    df['year'] = pd.to_datetime(df['date']).dt.year
    
    years = sorted(df['year'].unique())
    
    # 1. 按年分开的时间序列对比图
    for year in years:
        df_year = df[df['year'] == year]
        obs_y = df_year['obs'].values
        sim_y = df_year['sim'].values
        dates_y = df_year['date'].values
        
        mask_y = ~np.isnan(obs_y) & ~np.isnan(sim_y)
        nse_y = nse(obs_y[mask_y], sim_y[mask_y]) if mask_y.sum() > 10 else float('nan')
        
        fig, ax = plt.subplots(figsize=(14, 5))
        ax.plot(dates_y, obs_y, 'b-', label='Observed', alpha=0.8, linewidth=1)
        ax.plot(dates_y, sim_y, 'r-', label='Simulated', alpha=0.8, linewidth=1)
        ax.set_ylabel('Discharge (m³/s)')
        ax.set_xlabel('Date')
        ax.legend(loc='upper right')
        ax.set_title(f'Nam Ou (Kuwei) - {year} | NSE = {nse_y:.4f}')
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        out_png = result_dir / f'sim_vs_obs_{year}.png'
        plt.savefig(out_png, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"[SAVED] {out_png}")
    
    # 2. 整体残差图
    fig, ax = plt.subplots(figsize=(14, 4))
    residual = q_sim - q_obs
    ax.fill_between(dates, residual, 0, where=residual >= 0, color='red', alpha=0.5, label='Over-prediction')
    ax.fill_between(dates, residual, 0, where=residual < 0, color='blue', alpha=0.5, label='Under-prediction')
    ax.axhline(0, color='black', linewidth=0.5)
    ax.set_ylabel('Residual (Sim - Obs) m³/s')
    ax.set_xlabel('Date')
    ax.legend(loc='upper right')
    ax.set_title(f'Nam Ou (Kuwei) - Residual | Overall NSE = {nse_val:.4f}')
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    out_png = result_dir / 'sim_vs_obs_residual.png'
    plt.savefig(out_png, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"[SAVED] {out_png}")
    
    # 3. 散点图
    fig, ax = plt.subplots(figsize=(8, 8))
    ax.scatter(q_obs[valid_mask], q_sim[valid_mask], alpha=0.3, s=5, c='blue')
    max_val = max(q_obs[valid_mask].max(), q_sim[valid_mask].max())
    ax.plot([0, max_val], [0, max_val], 'r--', label='1:1 line', linewidth=2)
    ax.set_xlabel('Observed (m³/s)', fontsize=12)
    ax.set_ylabel('Simulated (m³/s)', fontsize=12)
    ax.legend(loc='upper left')
    ax.set_title(f'Nam Ou (Kuwei) - Scatter Plot | NSE = {nse_val:.4f}')
    ax.grid(True, alpha=0.3)
    ax.set_aspect('equal', adjustable='box')
    plt.tight_layout()
    out_png = result_dir / 'sim_vs_obs_scatter.png'
    plt.savefig(out_png, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"[SAVED] {out_png}")
    
    # 4. 按年散点图（诊断 2022 问题）
    fig, axes = plt.subplots(1, len(years), figsize=(5*len(years), 5))
    if len(years) == 1:
        axes = [axes]
    for ax, year in zip(axes, years):
        df_year = df[df['year'] == year]
        obs_y = df_year['obs'].values
        sim_y = df_year['sim'].values
        mask_y = ~np.isnan(obs_y) & ~np.isnan(sim_y)
        nse_y = nse(obs_y[mask_y], sim_y[mask_y]) if mask_y.sum() > 10 else float('nan')
        
        ax.scatter(obs_y[mask_y], sim_y[mask_y], alpha=0.3, s=10)
        max_val = max(obs_y[mask_y].max(), sim_y[mask_y].max()) if mask_y.sum() > 0 else 100
        ax.plot([0, max_val], [0, max_val], 'r--', linewidth=1)
        ax.set_xlabel('Observed (m³/s)')
        ax.set_ylabel('Simulated (m³/s)')
        ax.set_title(f'{year} | NSE={nse_y:.3f}')
        ax.set_aspect('equal', adjustable='box')
        ax.grid(True, alpha=0.3)
    plt.tight_layout()
    out_png = result_dir / 'sim_vs_obs_scatter_by_year.png'
    plt.savefig(out_png, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"[SAVED] {out_png}")
    
    # 保存 CSV
    csv_path = result_dir / 'sim_vs_obs_namou_kuwei.csv'
    df.to_csv(csv_path, index=False)
    print(f"[SAVED] {csv_path}")
    
    # 按年统计
    print("\n" + "="*50)
    print("[统计] 按年 NSE:")
    for year in years:
        df_year = df[df['year'] == year]
        obs_y = df_year['obs'].values
        sim_y = df_year['sim'].values
        mask_y = ~np.isnan(obs_y) & ~np.isnan(sim_y)
        if mask_y.sum() > 10:
            nse_y = nse(obs_y[mask_y], sim_y[mask_y])
            bias = (sim_y[mask_y].mean() - obs_y[mask_y].mean()) / obs_y[mask_y].mean() * 100
            print(f"  {year}: NSE = {nse_y:.4f}, Bias = {bias:+.1f}%")
    print("="*50)
    
    # 5. 分析 2022 年问题
    print("\n[分析] 2022 年数据诊断:")
    df_2022 = df[df['year'] == 2022]
    obs_2022 = df_2022['obs'].values
    sim_2022 = df_2022['sim'].values
    
    # 检查缺测
    nan_obs = np.isnan(obs_2022).sum()
    nan_sim = np.isnan(sim_2022).sum()
    print(f"  - 观测缺测: {nan_obs}/{len(obs_2022)} ({nan_obs/len(obs_2022)*100:.1f}%)")
    print(f"  - 模拟缺测: {nan_sim}/{len(sim_2022)} ({nan_sim/len(sim_2022)*100:.1f}%)")
    
    # 检查异常值
    mask_2022 = ~np.isnan(obs_2022) & ~np.isnan(sim_2022)
    if mask_2022.sum() > 0:
        obs_valid = obs_2022[mask_2022]
        sim_valid = sim_2022[mask_2022]
        
        # 观测统计
        print(f"  - 观测: mean={obs_valid.mean():.1f}, std={obs_valid.std():.1f}, max={obs_valid.max():.1f}")
        print(f"  - 模拟: mean={sim_valid.mean():.1f}, std={sim_valid.std():.1f}, max={sim_valid.max():.1f}")
        
        # 偏差分析
        bias_2022 = (sim_valid.mean() - obs_valid.mean()) / obs_valid.mean() * 100
        print(f"  - 系统偏差: {bias_2022:+.1f}%")
        
        # 峰值分析
        obs_peak = np.percentile(obs_valid, 95)
        sim_at_obs_peak = sim_valid[obs_valid >= obs_peak].mean() if (obs_valid >= obs_peak).sum() > 0 else 0
        print(f"  - 洪峰偏差: 观测95%={obs_peak:.1f}, 对应模拟均值={sim_at_obs_peak:.1f}")


if __name__ == "__main__":
    main()

