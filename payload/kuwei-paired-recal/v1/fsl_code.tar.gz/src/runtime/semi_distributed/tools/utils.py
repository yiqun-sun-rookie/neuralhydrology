"""Utility functions for optimization."""
from __future__ import annotations
import numpy as _np


def to_py(obj):
    """Recursively convert numpy types to Python native types for YAML serialization.
    
    This ensures compatibility with YAML serialization by converting:
    - numpy arrays to lists
    - numpy scalars (int, float, bool) to Python native types
    - Recursively processes dicts and lists
    """
    if isinstance(obj, dict):
        return {k: to_py(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [to_py(v) for v in obj]
    if isinstance(obj, (_np.ndarray,)):
        if obj.dtype.kind in ("i", "u"):
            return obj.astype(int).tolist()
        else:
            return obj.astype(float).tolist()
    if isinstance(obj, (_np.bool_,)):
        return bool(obj)
    if isinstance(obj, (_np.integer,)):
        return int(obj)
    if isinstance(obj, (_np.floating,)):
        return float(obj)
    return obj


