"""Utilities for f/h handle-based simulation and optimization."""
from __future__ import annotations
from typing import Any, Dict, Tuple
import numpy as np

from experiments.core_optimization.shared.snowmelt_controls import (
    SnowmeltResult,
    build_liquid_control_step,
)

# 可选择的单元状态索引（每个单元的 11 维状态向量定义）
# 说明：snow_storage 是一个别名 = snow_depth + ice_depth（不单独占索引）。
SUPPORTED_STATE_INDEX: Dict[str, int] = {
    'snow_depth': 0,
    'ice_depth': 1,
    'last_temp': 2,
    'soil_total': 3,
    'soil_upper': 4,
    'soil_lower': 5,
    'soil_deep': 6,
    'free_water': 7,
    'q_surface': 8,
    'q_interflow': 9,
    'q_baseflow': 10,
}
AVAILABLE_STATE_NAMES = sorted(list(SUPPORTED_STATE_INDEX.keys()) + ['snow_storage'])
# 扩展：容量类"上限曲线"导出名（用于和状态量对齐对比）
CAP_STATE_NAMES = {
    'soil_upper_cap': 'wum',
    'soil_lower_cap': 'wlm',
    'soil_deep_cap':  'wdm',
    'soil_total_cap': 'wmm',
    'free_water_cap': 'sm',
}
AVAILABLE_STATE_NAMES = sorted(list(set(AVAILABLE_STATE_NAMES + list(CAP_STATE_NAMES.keys()))))


def add_caps_to_da(da: Dict[str, Any], xaj_tuple: Tuple[np.ndarray, ...]) -> None:
    """Add CAPS (capacity parameters) to DA handles dict for visualization.
    
    This function modifies da in-place by adding a 'CAPS' key containing
    capacity parameters extracted from xaj_tuple for state visualization.
    
    Args:
        da: Dictionary from get_da_handles (modified in-place)
        xaj_tuple: Tuple of 17 XAJ parameters, where indices 6-9 and 15 are:
            [6] wum, [7] wlm, [8] wdm, [9] sm, [15] wmm
    """
    if len(xaj_tuple) < 16:
        return  # Not enough parameters, skip silently
    try:
        da['CAPS'] = {
            'wum': np.asarray(xaj_tuple[6], dtype=np.float32),
            'wlm': np.asarray(xaj_tuple[7], dtype=np.float32),
            'wdm': np.asarray(xaj_tuple[8], dtype=np.float32),
            'sm':  np.asarray(xaj_tuple[9], dtype=np.float32),
            'wmm': np.asarray(xaj_tuple[15], dtype=np.float32),
        }
    except (IndexError, TypeError, ValueError):
        # Invalid xaj_tuple format, skip silently
        pass


def simulate_series_fh(
    da: Dict[str, Any],
    rain: np.ndarray, temp: np.ndarray, snow: np.ndarray, pet: np.ndarray,
    obs_station_arr: np.ndarray | None = None,
    sta_reach_idx: np.ndarray | None = None,
    *,
    state_names: list[str] | None = None,
    state_agg: str = 'sum',
    per_unit: bool = False,
    snowmelt: SnowmeltResult | None = None,
    liquid_controls: np.ndarray | None = None,
) -> np.ndarray | tuple[np.ndarray, Dict[str, np.ndarray]] | tuple[np.ndarray, Dict[str, np.ndarray], Dict[str, np.ndarray]]:
    """Simulate time series using f/h handles with optional state tracing.
    
    Args:
        da: Dictionary containing f_struct, h_struct, x0_struct, and optionally CAPS
        rain, temp, snow, pet: Meteorological forcings, shape (T, Ng)
        obs_station_arr: Optional observed station flow array
        sta_reach_idx: Optional station-to-reach index mapping
        state_names: Optional list of state names to trace
    state_agg: Aggregation method for states ('sum' or 'mean')
    per_unit: Whether to return per-unit state traces
    snowmelt: Optional per-unit liquid controls based on PDD/XAJ
    liquid_controls: Optional aggregated controls (T, 2) overriding raw forcings
        
    Returns:
        - If state_names is None: flow series array (T,)
        - If state_names provided and per_unit=False: (flow_series, state_traces)
        - If state_names provided and per_unit=True: (flow_series, state_traces, unit_traces)
    """
    T = rain.shape[0]
    if snowmelt is not None:
        T = min(T, snowmelt.steps)
    if liquid_controls is not None:
        T = min(T, np.asarray(liquid_controls).shape[0])
    f = da['f_struct']
    h = da['h_struct']
    state = da['x0_struct']
    y = np.zeros((T,), np.float32)
    # optional state traces collection
    collect = isinstance(state_names, (list, tuple)) and len(state_names) > 0
    traces: Dict[str, np.ndarray] | None = None
    unit_traces: Dict[str, np.ndarray] | None = None
    if collect:
        traces = {str(name): np.zeros((T,), np.float32) for name in state_names}
        # 若需要每单元导出，预先根据初始状态的单元数开辟数组
        if per_unit:
            try:
                n_units = int(np.asarray(state['units']).shape[0])
            except Exception:
                # 若无法读取，延后到首步再判定
                n_units = None  # type: ignore
            unit_traces = {}
            for name in state_names:
                # 容量类同样支持 per-unit（时间上保持常数）
                unit_traces[name] = None  # type: ignore

    def _agg_vals(arr: np.ndarray) -> float:
        if state_agg == 'mean':
            return float(np.nanmean(arr))
        # default sum
        return float(np.nansum(arr))

    # 如果请求了容量曲线导出，准备聚合函数并读取容量数组
    caps = da.get('CAPS', {}) if isinstance(da, dict) else {}
    def _cap_val(name: str) -> float:
        key = CAP_STATE_NAMES.get(name)
        if not key or key not in caps:
            return float('nan')
        arr = np.asarray(caps[key], dtype=np.float32)
        return _agg_vals(arr)

    liquid_controls_arr = None
    if liquid_controls is not None:
        liquid_controls_arr = np.asarray(liquid_controls, dtype=np.float32)

    for t in range(T):
        if liquid_controls_arr is not None:
            u_t = np.asarray(liquid_controls_arr[t], dtype=np.float32)
        elif snowmelt is not None:
            u_t = build_liquid_control_step(snowmelt, t)
        else:
            u_t = np.vstack([
                np.asarray(rain[t], dtype=np.float32),
                np.asarray(temp[t], dtype=np.float32),
                np.asarray(snow[t], dtype=np.float32),
                np.asarray(pet[t],  dtype=np.float32),
            ])
        # 注入外接来水（若提供）
        obs_row = None
        if obs_station_arr is not None and sta_reach_idx is not None:
            obs_row = obs_station_arr[t]
        state = f(state, u_t, obs_row=obs_row, sta_reach_idx=sta_reach_idx)
        y[t] = float(h(state, mode='basin_sum'))
        # collect states if required
        if collect and traces is not None:
            units = state['units']  # (n_units, 11)
            if per_unit and unit_traces is not None:
                # 若尚未分配 per-unit 数组，这里初始化（首步才能确定 n_units）
                for key in unit_traces.keys():
                    if unit_traces[key] is None:
                        try:
                            n_units_local = int(np.asarray(units).shape[0])
                        except Exception:
                            n_units_local = 0
                        unit_traces[key] = np.zeros((T, n_units_local), np.float32)
            for key in traces.keys():
                if key == 'snow_storage':
                    val = _agg_vals(units[:, 0] + units[:, 1])
                    if per_unit and unit_traces is not None and unit_traces.get(key) is not None:
                        unit_traces[key][t, :] = (units[:, 0] + units[:, 1]).astype(np.float32)
                elif key in CAP_STATE_NAMES:
                    # 容量曲线：时间不变（按当前聚合口径聚合一次）
                    val = _cap_val(key)
                    if per_unit and unit_traces is not None and unit_traces.get(key) is not None:
                        # 每单元容量：来自 CAPS 映射，沿时间维复制
                        cap_key = CAP_STATE_NAMES.get(key)
                        if cap_key and cap_key in caps:
                            cap_arr = np.asarray(caps[cap_key], dtype=np.float32).reshape(-1)
                            unit_traces[key][t, :] = cap_arr
                elif key == 'last_temp':
                    # 温度的聚合更适合用均值，避免 state_agg=sum 时出现"温度求和"的不直观现象
                    try:
                        val = float(np.nanmean(units[:, SUPPORTED_STATE_INDEX['last_temp']]))
                    except Exception:
                        val = _agg_vals(units[:, SUPPORTED_STATE_INDEX['last_temp']])
                    if per_unit and unit_traces is not None and unit_traces.get(key) is not None:
                        unit_traces[key][t, :] = units[:, SUPPORTED_STATE_INDEX['last_temp']].astype(np.float32)
                else:
                    idx = SUPPORTED_STATE_INDEX.get(key, None)
                    if idx is None:
                        # unknown key: skip silently to be forgiving
                        continue
                    val = _agg_vals(units[:, idx])
                    if per_unit and unit_traces is not None and unit_traces.get(key) is not None:
                        unit_traces[key][t, :] = units[:, idx].astype(np.float32)
                traces[key][t] = np.float32(val)
    if collect and traces is not None:
        if per_unit and unit_traces is not None:
            return y, traces, unit_traces
        return y, traces
    return y


def build_broadcaster(grid2sub, sub_area, connection_matrices, model_tpl, calib_cfg, Ns: int):
    """Construct broadcaster: vec -> (merged_model, pdd_tuple, xaj_tuple, core_args).
    
    Returns a function that takes a parameter vector and returns model parameters
    in the format expected by the simulation backend.
    """
    from src.runtime.semi_distributed.core.params import vector_to_params, prepare_model_params
    
    def _broadcaster(vec: np.ndarray, calib_cfg_in, model_tpl_in, geo_info_in):
        param_dict = vector_to_params(vec, calib_cfg_in, Ns)
        merged_model, pdd_tuple, xaj_tuple, msk_layers_params_tuples, core_args = prepare_model_params(
            param_dict=param_dict,
            model_params_template=model_tpl_in,
            calibration_config=calib_cfg_in,
            grid2sub=geo_info_in[0],
            sub_area=geo_info_in[1],
            connection_matrices=geo_info_in[2],
        )
        return merged_model, pdd_tuple, xaj_tuple, msk_layers_params_tuples, core_args
    return _broadcaster

