"""Evaluate with calibrated parameters and verify reproducibility.

This script reloads the run_config, loads the latest saved best_params_<section>*.pkl,
reconstructs the exact simulation inputs, runs the hydrologic core, and computes
NSE exactly like the optimization flow. It then compares against the saved NSE
in summary_<section>.json (or filename fallback) and asserts equality.

Usage:
  python experiments/semi_distributed/optimization/eval_with_params.py \
    --run-config path/to/run_config_*.yml [--params-pkl path/to/best_params_*.pkl]

It also exposes a function recompute_nse_with_params(...) for tests.
"""
from __future__ import annotations
from pathlib import Path
import os
import sys
import re
import json
from typing import Any, Dict, Optional, Tuple
import numpy as np
import pandas as pd

# Ensure project root on sys.path
PROJECT_ROOT = Path(__file__).resolve().parents[4]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.runtime.semi_distributed.core.forecast_runner import (
    build_cfg_from_run_config,
    run_simulation,
)
# Re-export for backward compatibility (run_once.py imports this)
from src.runtime.semi_distributed.core.forecast_runner import load_yaml_with_include  # noqa: F401

from src.runtime.semi_distributed.core.optimization_config import OptimizationConfig
from src.runtime.semi_distributed.core.pipeline import (
    prepare_calibration_session, select_floods_series,
)
from src.runtime.semi_distributed.core.pipeline import run_optimization_eval
from src.runtime.semi_distributed.core.dataio import prepare_external_flow_inputs


def _find_latest_params_pkl(out_dir: Path, section: str) -> Path:
    cands = sorted(out_dir.glob(f"best_params_{section}_nse*.pkl"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not cands:
        raise FileNotFoundError(f"未找到 best_params pkl 于 {out_dir}")
    return cands[0]


def _load_complete_data(pkl_path: Path) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any]]:
    """加载完整的优化结果数据（参数、初始条件、元数据）"""
    import pickle
    try:
        with open(pkl_path, 'rb') as fp:
            data = pickle.load(fp)
    except ModuleNotFoundError as e:
        if 'numpy._core' in str(e):
            import pickle5
            with open(pkl_path, 'rb') as fp:
                data = pickle5.load(fp)
        else:
            raise e

    if isinstance(data, dict) and 'best_params' in data:
        best_params = data['best_params']
        init_cond = data.get('init_cond')
        metadata = data.get('metadata', {})
    else:
        best_params = data
        init_cond = None
        metadata = {}

    return best_params, init_cond, metadata


def _read_saved_nse(out_dir: Path, section: str, pkl_name: str) -> Optional[float]:
    js = out_dir / f"summary_{section}.json"
    if js.exists():
        try:
            data = json.loads(js.read_text(encoding='utf-8'))
            nse = data.get('nse')
            if nse is not None:
                return float(nse)
        except Exception:
            pass
    m = re.search(r"_nse(-?\d+(?:\.\d+)?)(?:_|\.pkl)$", pkl_name)
    if m:
        try:
            return float(m.group(1))
        except Exception:
            return None
    return None


def _compute_nse_from_sim(
    cfg: OptimizationConfig,
    geo: Dict[str, Any],
    meteo_inputs: tuple,
    time_index: pd.DatetimeIndex,
    external_flow_inputs: tuple,
    floods_discharge,
    eval_station: Optional[str],
    eval_is_last_layer_node: bool,
    sim_ret: tuple,
) -> float:
    debug = os.environ.get('EVAL_RECHECK_DEBUG','0') == '1'
    if len(sim_ret) == 4:
        q_grid, q_subs, q_outlet, q_last_layer = sim_ret
    else:
        q_grid, q_subs, q_outlet = sim_ret[:3]
        q_last_layer = None

    if eval_station is None:
        if not isinstance(floods_discharge, pd.Series):
            raise TypeError("未指定 eval_station 时需要出口观测 Series")
        sim_series = pd.Series(q_outlet, index=time_index)
        idx = floods_discharge.index.intersection(sim_series.index)
        if debug:
            print(f"[RECHECK] path=outlet steps={len(idx)} eval_station=None")
        if len(idx) < 10:
            raise ValueError("出口评价重叠步数 <10")
        obs = floods_discharge.loc[idx].to_numpy()
        sim = sim_series.loc[idx].to_numpy()
        denom = ((obs - obs.mean()) ** 2).sum()
        if denom <= 0:
            raise ValueError("出口观测方差=0")
        nse = 1.0 - ((obs - sim) ** 2).sum() / denom
        return float(nse)

    msk_layers = geo['msk_layers']
    if not eval_is_last_layer_node:
        if not isinstance(floods_discharge, pd.Series):
            raise TypeError("第0层单站评价要求 floods_discharge 为该站观测 Series")
        layer0_names = list(msk_layers[0].get('names', [])) if msk_layers and isinstance(msk_layers[0], dict) else []
        if eval_station not in layer0_names:
            raise ValueError("eval_station 不在第0层")
        col = layer0_names.index(eval_station)
        col = 0 if col >= q_subs.shape[1] else col
        sim_series = pd.Series(q_subs[:, col], index=time_index)
        obs_series = floods_discharge
        idx = obs_series.index.intersection(sim_series.index)
        if debug:
            print(f"[RECHECK] path=layer0 station={eval_station} col={col} steps={len(idx)}")
        if len(idx) < 10:
            raise ValueError("单站评价有效步数 <10 (第0层)")
        obs = obs_series.loc[idx].to_numpy(); sim = sim_series.loc[idx].to_numpy()
        denom = ((obs - obs.mean()) ** 2).sum()
        if denom <= 0:
            raise ValueError("单站观测方差=0 (第0层)")
        nse = 1.0 - ((obs - sim) ** 2).sum() / denom
        return float(nse)

    if q_last_layer is None:
        raise RuntimeError("需要 q_last_layer 获得逐节点模拟输出")
    last_names = list(msk_layers[-1].get('names', [])) if (msk_layers and isinstance(msk_layers[-1], dict)) else []
    if eval_station not in last_names:
        raise ValueError("eval_station 不在最后一层")
    col = last_names.index(eval_station)
    col = 0 if col >= q_last_layer.shape[1] else col
    sim_series = pd.Series(q_last_layer[:, col], index=time_index)
    obs_series = floods_discharge
    if not isinstance(obs_series, pd.Series):
        raise TypeError("单站评价要求 floods_discharge 为 Series")
    idx = obs_series.index.intersection(sim_series.index)
    if debug:
        print(f"[RECHECK] path=last_layer station={eval_station} col={col} steps={len(idx)}")
    if len(idx) < 10:
        raise ValueError("单站评价有效步数 <10")
    obs = obs_series.loc[idx].to_numpy(); sim = sim_series.loc[idx].to_numpy()
    denom = ((obs - obs.mean()) ** 2).sum()
    if denom <= 0:
        raise ValueError("单站观测方差=0")
    nse = 1.0 - ((obs - sim) ** 2).sum() / denom
    return float(nse)


def recompute_nse_with_params(
    run_config_path: Optional[str | Path] = None,
    params_pkl_path: Optional[str | Path] = None,
    return_saved: bool = False,
) -> Tuple[float, Optional[float]]:
    """Recompute NSE using saved best_params and the same pipeline.

    Returns (computed_nse, saved_nse or None).
    """
    run_config_path = Path(run_config_path) if run_config_path else (
        PROJECT_ROOT / 'experiments/semi_distributed/optimization/config/run_config_ylx_downstream.yml'
    )
    cfg, raw, flat = build_cfg_from_run_config(run_config_path, strict=True)

    # Load complete data (params + initial conditions)
    out_dir = cfg.OUTPUT_DIR
    section = cfg.SECTION_NAME
    if params_pkl_path:
        best_pkl = Path(params_pkl_path)
    else:
        best_pkl = _find_latest_params_pkl(out_dir, section)

    best_params, saved_init_cond, metadata = _load_complete_data(best_pkl)

    # Run simulation via forecast_runner
    result = run_simulation(
        cfg, best_params,
        init_state_override=saved_init_cond,
        return_state_grid=False,
        return_last_layer=True,
    )

    # Compute NSE using eval-specific logic
    sess = result.session
    msk_layers = sess['msk_layers']
    time_index = result.time_index
    discharge_outlet = sess['discharge_outlet']
    discharge_inflow = sess['discharge_inflow']

    floods_target, abort_flow = select_floods_series(cfg, discharge_outlet, discharge_inflow, cfg.EVAL_STATION, msk_layers)
    if abort_flow:
        raise SystemExit('无法选择目标流量序列（flow_source 配置错误或数据缺失）')

    station_reach_map = {"zmsk": 0, "ql": 1} if cfg.SECTION_NAME == "ylx" else None
    obs_station_arr, sta_reach_idx = prepare_external_flow_inputs(
        observed_station_flow=discharge_inflow,
        station_reach_map=station_reach_map,
        time_index=time_index,
        override_stations=getattr(cfg, 'OVERRIDE_STATIONS', None),
    )

    eval_station = cfg.EVAL_STATION
    last_names = []
    if msk_layers and isinstance(msk_layers[-1], dict):
        last_names = list(msk_layers[-1].get('names') or [])
    eval_is_last_layer_node = bool(eval_station and eval_station in last_names)

    computed_nse = _compute_nse_from_sim(
        cfg,
        {"msk_layers": msk_layers},
        result.meteo_inputs,
        time_index,
        (obs_station_arr, sta_reach_idx),
        floods_target,
        eval_station,
        eval_is_last_layer_node,
        result.sim_ret,
    )
    try:
        print(f"[RECHECK] computed_nse={computed_nse:.10f} eval_station={eval_station} last_layer={eval_is_last_layer_node}")
    except Exception:
        pass

    saved_nse = _read_saved_nse(out_dir, section, best_pkl.name)
    if return_saved:
        return computed_nse, saved_nse
    return computed_nse, saved_nse


def calibrate_then_verify(
    run_config_path: Optional[str | Path] = None,
    max_iter: int = 3,
    pop_size: int = 10,
    workers: int = 1,
) -> Tuple[float, float]:
    """Run a short calibration and immediately verify reproducibility."""
    run_config_path = Path(run_config_path) if run_config_path else (
        PROJECT_ROOT / 'experiments/semi_distributed/optimization/config/run_config_ylx_downstream.yml'
    )
    cfg, raw, flat = build_cfg_from_run_config(run_config_path, strict=True)
    os.environ['PRECHECK_PARAMS_ONLY'] = '0'
    cfg.MAX_ITER = int(max_iter)
    cfg.POP_SIZE = int(pop_size)
    cfg.WORKERS = int(workers)

    best_params, best_nse = run_optimization_eval(cfg)

    # Recompute NSE with saved complete params
    out_dir = cfg.OUTPUT_DIR
    section = cfg.SECTION_NAME
    best_pkl = _find_latest_params_pkl(out_dir, section)
    saved_best_params, saved_init_cond, metadata = _load_complete_data(best_pkl)

    result = run_simulation(
        cfg, saved_best_params,
        init_state_override=saved_init_cond,
        return_state_grid=False,
        return_last_layer=True,
    )

    sess = result.session
    msk_layers = sess['msk_layers']
    time_index = result.time_index
    discharge_outlet = sess['discharge_outlet']
    discharge_inflow = sess['discharge_inflow']

    floods_target, abort_flow = select_floods_series(cfg, discharge_outlet, discharge_inflow, cfg.EVAL_STATION, msk_layers)
    if abort_flow:
        raise SystemExit('无法选择目标流量序列（flow_source 配置错误或数据缺失）')

    station_reach_map = {"zmsk": 0, "ql": 1} if cfg.SECTION_NAME == "ylx" else None
    obs_station_arr, sta_reach_idx = prepare_external_flow_inputs(
        observed_station_flow=discharge_inflow,
        station_reach_map=station_reach_map,
        time_index=time_index,
        override_stations=getattr(cfg, 'OVERRIDE_STATIONS', None),
    )

    eval_station = cfg.EVAL_STATION
    last_names = []
    if msk_layers and isinstance(msk_layers[-1], dict):
        last_names = list(msk_layers[-1].get('names') or [])
    eval_is_last_layer_node = bool(eval_station and eval_station in last_names)

    recomputed_nse = _compute_nse_from_sim(
        cfg,
        {"msk_layers": msk_layers},
        result.meteo_inputs,
        time_index,
        (obs_station_arr, sta_reach_idx),
        floods_target,
        eval_station,
        eval_is_last_layer_node,
        result.sim_ret,
    )
    return float(best_nse), float(recomputed_nse)


def _main(argv=None):
    import argparse
    p = argparse.ArgumentParser(description='Re-run simulation with calibrated parameters and verify NSE matches saved value.')
    p.add_argument('--run-config', help='Path to run_config.yml', default=str(PROJECT_ROOT / 'experiments/semi_distributed/optimization/config/run_config_ylx_downstream.yml'))
    p.add_argument('--params-pkl', help='Path to best_params_*.pkl (optional)')
    p.add_argument('--calibrate', action='store_true', help='Run a short calibration first, then verify reproducibility.')
    p.add_argument('--max-iter', type=int, default=3, help='Iterations for quick calibration (used with --calibrate).')
    p.add_argument('--pop-size', type=int, default=10, help='Population size for quick calibration (used with --calibrate).')
    p.add_argument('--workers', type=int, default=1, help='Workers for quick calibration (used with --calibrate).')
    args = p.parse_args(argv)

    if args.calibrate:
        best_nse, recomputed_nse = calibrate_then_verify(args.run_config, args.max_iter, args.pop_size, args.workers)
        print(f"Best NSE (opt):     {best_nse:.10f}")
        print(f"Recomputed NSE:     {recomputed_nse:.10f}")
        diff = abs(best_nse - recomputed_nse)
        print(f"|diff|:             {diff:.3e}")
        if diff > 1e-12:
            raise SystemExit(f"NSE 不匹配: 优化={best_nse} 复算={recomputed_nse} |diff|={diff}")
        print("校准后复算一致 ✅")
        return

    computed, saved = recompute_nse_with_params(args.run_config, args.params_pkl, return_saved=True)
    print(f"Computed NSE: {computed:.10f}")
    if saved is not None:
        print(f"Saved NSE:    {saved:.10f}")
        diff = abs(computed - float(saved))
        print(f"|diff|:       {diff:.3e}")
        if diff > 1e-12:
            raise SystemExit(f"NSE 不匹配: 计算={computed} 保存={saved} |diff|={diff}")
        print("NSE 一致 ✅")
    else:
        print("未找到保存的 NSE（summary 或文件名），仅输出了重新计算的 NSE。")


if __name__ == '__main__':  # pragma: no cover
    _main()
