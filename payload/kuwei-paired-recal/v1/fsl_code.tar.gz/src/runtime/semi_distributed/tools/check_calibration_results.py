import os
import sys
import subprocess
import pandas as pd
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(PROJECT_ROOT))

def main():
    print("Checking calibration results...")
    
    # 1. Run Plotting Script
    plot_script = PROJECT_ROOT / "experiments/semi_distributed/optimization/tools/plot_namou_kuwei_result.py"
    cmd = ["python", str(plot_script)]
    
    print(f"Running: {' '.join(cmd)}")
    try:
        subprocess.run(cmd, check=True)
    except subprocess.CalledProcessError as e:
        print(f"Error running plotting script: {e}")
        return

    print("\nDone. Please check the 'results/experiments/namou_kuwei' folder for plots.")
    print("Look for 'sim_vs_obs_namou_kuwei.png' and 'sim_vs_obs_scatter.png'.")

if __name__ == "__main__":
    main()

