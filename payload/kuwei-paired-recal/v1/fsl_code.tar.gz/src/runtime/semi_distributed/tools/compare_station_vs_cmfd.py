from __future__ import annotations
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import yaml

# Ensure project root in sys.path
import sys as _sys
PROJECT_ROOT = Path(__file__).resolve().parents[4]
if str(PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(PROJECT_ROOT))

# Reuse existing utilities and pipelines
from src.runtime.semi_distributed.core.optimization_config import OptimizationConfig  # noqa: E402
from src.runtime.semi_distributed.core.pipeline import (  # noqa: E402
    prepare_calibration_session,
    select_floods_series,
)
from src.runtime.semi_distributed.core.dataio import (  # noqa: E402
    load_data,
    prepare_meteo_inputs,
    prepare_external_flow_inputs,
    aggregate_meteo_by_sub,
)
from src.runtime.semi_distributed.core.params import (  # noqa: E402
    prepare_initial_state,
    prepare_model_params,
)
from src.runtime.semi_distributed.tools.fh_utils import (  # noqa: E402
    simulate_series_fh as _simulate_series_fh,
    add_caps_to_da,
    build_broadcaster as _build_broadcaster,
)
from src.runtime.semi_distributed.core.state_space_handles import get_da_handles  # noqa: E402
from src.runtime.metrics import (  # noqa: E402
    nse as _nse,
    kge as _kge,
    rmse_score as _rmse,
    mae_score as _mae,
)
from experiments.core_optimization.shared.xaj_backend import HydroForcing, build_snowmelt_controls  # noqa: E402


DEFAULT_CFG_PATH = PROJECT_ROOT / "config" / "experiments" / "compare_station_vs_cmfd.yml"


def _ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def _read_yaml(path: Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def _cfg_get(file_cfg: Dict[str, Any], key: str, default=None):
    if not isinstance(file_cfg, dict):
        return default
    if key in file_cfg:
        return file_cfg.get(key, default)
    scene = file_cfg.get('scene')
    if isinstance(scene, dict) and key in scene:
        return scene.get(key, default)
    opt_blk = file_cfg.get('optimizer')
    if isinstance(opt_blk, dict) and key in opt_blk:
        return opt_blk.get(key, default)
    return default


def _apply_base_config_to(cfg: OptimizationConfig, base_cfg: Dict[str, Any], overrides: Dict[str, Any]) -> None:
    # 映射关键字段（与 optimize_with_fh 基本一致，保持 YAML 优先）
    _sec = _cfg_get(base_cfg, 'section');            _sec and cfg.set_section(_sec)
    _simu = _cfg_get(base_cfg, 'sim_unit');          _simu and cfg.set_sim_unit(_simu)
    _anch = _cfg_get(base_cfg, 'calib_anchor');      _anch and cfg.set_calib_anchor(_anch)
    _objf = _cfg_get(base_cfg, 'objective_flow');    _objf and cfg.set_objective_flow(_objf)
    _csel = _cfg_get(base_cfg, 'calib_nodes');       _csel and cfg.select_calib_nodes(_csel)
    _veri = _cfg_get(base_cfg, 'verify');            _veri and cfg.set_verify_nodes(_veri)
    _st = _cfg_get(base_cfg, 'start_date');          (isinstance(_st, str) and _st.strip()) and setattr(cfg, 'START_TIME', _st)
    _ed = _cfg_get(base_cfg, 'end_date');            (isinstance(_ed, str) and _ed.strip()) and setattr(cfg, 'END_TIME', _ed)
    _exy = _cfg_get(base_cfg, 'exclude_years')
    if _exy is not None:
        try:
            if isinstance(_exy, (list, tuple, set)):
                setattr(cfg, 'EXCLUDE_YEARS', set(int(x) for x in _exy))
            elif isinstance(_exy, str):
                years = [int(s.strip()) for s in _exy.split(',') if s.strip()]
                setattr(cfg, 'EXCLUDE_YEARS', set(years))
            else:
                setattr(cfg, 'EXCLUDE_YEARS', {int(_exy)})
        except Exception:
            pass
    # 应用 compare YAML 的覆盖（time / eval）
    time_blk = overrides.get('time') or {}
    if isinstance(time_blk, dict):
        ts = time_blk.get('start_date'); te = time_blk.get('end_date'); ex = time_blk.get('exclude_years')
        (isinstance(ts, str) and ts.strip()) and setattr(cfg, 'START_TIME', ts)
        (isinstance(te, str) and te.strip()) and setattr(cfg, 'END_TIME', te)
        if ex is not None:
            try:
                if isinstance(ex, (list, tuple, set)):
                    setattr(cfg, 'EXCLUDE_YEARS', set(int(x) for x in ex))
                elif isinstance(ex, str):
                    years = [int(s.strip()) for s in ex.split(',') if s.strip()]
                    setattr(cfg, 'EXCLUDE_YEARS', set(years))
                else:
                    setattr(cfg, 'EXCLUDE_YEARS', {int(ex)})
            except Exception:
                pass
    eval_blk = overrides.get('eval') or {}
    if isinstance(eval_blk, dict):
        anch2 = eval_blk.get('calib_anchor'); obj2 = eval_blk.get('objective_flow')
        anch2 and cfg.set_calib_anchor(anch2)
        obj2 and cfg.set_objective_flow(obj2)


def _read_station_daily_precip(station_dir: Path, station_ids: List[str]) -> pd.DataFrame:
    frames: List[pd.Series] = []
    cols: List[str] = []
    for sid in station_ids:
        sid_dir = station_dir / sid
        if not sid_dir.exists():
            continue
        series_list: List[pd.Series] = []
        for fp in sorted(sid_dir.glob("*.xlsx")):
            try:
                df = pd.read_excel(fp)
                if 'P' not in df or 'Time' not in df:
                    continue
                s = pd.Series(df['P'].values, index=pd.to_datetime(df['Time']), name=sid)
                series_list.append(s)
            except Exception:
                continue
        if series_list:
            ser = pd.concat(series_list).sort_index()
            ser.name = sid
            frames.append(ser)
            cols.append(sid)
    if not frames:
        raise FileNotFoundError(f"未在 {station_dir} 读取到任何有效站点降水")
    df_out = pd.concat(frames, axis=1)
    df_out.columns = cols
    return df_out


def _combine_station_total(df: pd.DataFrame, strategy: str, weights: Optional[Dict[str, float]]) -> pd.Series:
    stg = (strategy or 'mean').strip().lower()
    if stg == 'ylx':
        if 'ylx' not in df.columns:
            raise ValueError("strategy=ylx 但未找到 ylx 列")
        out = df['ylx'].astype(np.float32)
    elif stg == 'weighted':
        if not weights:
            raise ValueError("strategy=weighted 需要提供 weights")
        # 仅使用交集列，并对权重做归一化
        use_cols = [c for c in df.columns if c in weights]
        if not use_cols:
            raise ValueError("weights 与站点列无交集")
        w = np.array([float(weights[c]) for c in use_cols], dtype=np.float64)
        wsum = float(np.sum(w))
        if not np.isfinite(wsum) or wsum <= 0:
            raise ValueError("weights 非法或权重和为0")
        w = w / wsum
        out = (df[use_cols].to_numpy(np.float32) @ w.astype(np.float32)).astype(np.float32)
        out = pd.Series(out, index=df.index, name='station_total')
    else:
        # mean
        out = df.mean(axis=1).astype(np.float32)
    out.name = 'station_total'
    return out


def _plot_series(out_dir: Path, title: str, time_index: pd.DatetimeIndex, y_true: np.ndarray, y_a: np.ndarray, y_b: np.ndarray):
    try:
        import matplotlib.pyplot as plt  # type: ignore
    except Exception:
        print("[WARN] 未安装 matplotlib，跳过绘图。")
        return
    fig, ax = plt.subplots(figsize=(10, 4))
    ax.plot(time_index, y_true, label='Obs', color='black', linewidth=1.0)
    ax.plot(time_index, y_a, label='CMFD', color='#1f77b4', alpha=0.9)
    ax.plot(time_index, y_b, label='StationSplit', color='#ff7f0e', alpha=0.9)
    ax.set_title(title)
    ax.set_ylabel('Discharge')
    ax.legend(frameon=False)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fp = out_dir / "overlay_cmfd_vs_station.png"
    fig.savefig(fp, dpi=150)
    plt.close(fig)


def _plot_scatter(out_dir: Path, y_a: np.ndarray, y_b: np.ndarray):
    try:
        import matplotlib.pyplot as plt  # type: ignore
    except Exception:
        return
    m = min(float(np.nanmin(y_a)), float(np.nanmin(y_b)))
    M = max(float(np.nanmax(y_a)), float(np.nanmax(y_b)))
    rng = (m, M)
    fig, ax = plt.subplots(figsize=(4, 4))
    ax.scatter(y_a, y_b, s=6, alpha=0.5)
    ax.plot(rng, rng, 'r--', linewidth=1.0)
    ax.set_xlabel('CMFD')
    ax.set_ylabel('StationSplit')
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fp = out_dir / "scatter_cmfd_vs_station.png"
    fig.savefig(fp, dpi=150)
    plt.close(fig)


def main():
    # 1) 读取对比配置
    cfg_path = DEFAULT_CFG_PATH
    if not cfg_path.exists():
        raise FileNotFoundError(f"未找到对比配置: {cfg_path}")
    compare_cfg = _read_yaml(cfg_path)

    base_run_cfg_path = compare_cfg.get('base_run_config') or "basins/ylx/config/run_config_ylx_downstream.yml"
    base_run_cfg_path = str(base_run_cfg_path)
    # 读取 base run config（沿用内部装载器）
    from src.runtime.semi_distributed.core import config_loader as _config_loader
    _config_loader.set_run_config_path(Path(base_run_cfg_path))
    base_cfg = _config_loader.load_run_config_internal()

    # 2) 构造 OptimizationConfig（应用 base + compare 覆盖）
    cfg = OptimizationConfig()
    _apply_base_config_to(cfg, base_cfg, compare_cfg)
    # 强化严格模式一致性
    os.environ['STRICT_NO_FALLBACK'] = '1'

    # 3) 预备输出目录
    out_dir = PROJECT_ROOT / str(compare_cfg.get('output_dir') or "results/experiments/station_vs_cmfd")
    _ensure_dir(out_dir)

    # 4) 使用统一会话准备（拓扑/参数/观测）
    sess = prepare_calibration_session(cfg)
    grid2sub = sess['grid2sub']
    sub_area = sess['sub_area']
    connection_matrices = sess['connection_matrices']
    msk_layers = sess['msk_layers']
    default_params = sess['default_params']
    calib_cfg = sess['calib_cfg']
    init_cond = sess['init_cond']
    time_index = sess['time_index']
    discharge_outlet = sess['discharge_outlet']
    discharge_inflow = sess['discharge_inflow']

    # 目标流量序列
    eval_station = getattr(cfg, 'EVAL_STATION', None)
    series, abort_flag = select_floods_series(cfg, discharge_outlet, discharge_inflow, eval_station, msk_layers)
    if abort_flag or series is None:
        print('[ERROR] 无可用目标流量，终止。')
        return
    qobs = np.asarray(series.values, dtype=np.float32)

    # 5) 准备外接来水（与 ylx 映射一致）
    station_reach_map = {"zmsk": 0, "ql": 1} if str(getattr(cfg, 'SECTION_NAME', '')).lower() == 'ylx' else None
    obs_station_arr, sta_reach_idx = prepare_external_flow_inputs(
        observed_station_flow=discharge_inflow,
        station_reach_map=station_reach_map,
        time_index=time_index,
        override_stations=getattr(cfg, 'OVERRIDE_STATIONS', None),
    )

    # 6) 构建模型广播者（固定参数）
    Ns = grid2sub.shape[1]
    Ng = grid2sub.shape[0]
    merged_model, pdd_tuple, xaj_tuple, msk_layers_params_tuples, core_args = prepare_model_params(
        param_dict=None,
        model_params_template=default_params,
        calibration_config=calib_cfg,
        grid2sub=grid2sub,
        sub_area=sub_area,
        connection_matrices=connection_matrices,
        param_mode={
            'msk_params': {'*': 'sub'},
            'xaj_params': {'*': 'basin'},
            'pdd_params': {'*': 'basin'},
        },
    )
    x0_struct = prepare_initial_state(init_cond, Ng, enable_snowmelt=True)
    da = get_da_handles(
        init_units_state=x0_struct,
        msk_layers_params=msk_layers_params_tuples,
        layer_connect_mats=core_args['C_mats'],
        grid2sub=grid2sub,
        pdd_pars=pdd_tuple,
        xaj_pars=xaj_tuple,
    )
    add_caps_to_da(da, xaj_tuple)

    # 7) 场景A：CMFD（沿用会话提供的 meteo_inputs 即可）
    rainA, tempA, snowA, petA = sess['meteo_inputs']

    # 8) 场景B：站点总降水 + split
    # 8.1 读取 base CMFD meteo（用于温度与 PET 以及时间对齐）
    meteo_df, _, _ = load_data(cfg)

    sp_blk = compare_cfg.get('station_precip') or {}
    _sp_dir = sp_blk.get('dir')
    if not _sp_dir:
        raise ValueError("station_precip.dir is required in run_config. No hardcoded fallback.")
    station_dir = PROJECT_ROOT / str(_sp_dir)
    strategy = str(sp_blk.get('strategy') or 'mean')
    stations = list(sp_blk.get('stations') or ['ylx', 'zmsk', 'ql'])
    weights = sp_blk.get('weights')
    t_snow = sp_blk.get('t_snow', None)
    t_rain = sp_blk.get('t_rain', None)
    dump_preview = bool(sp_blk.get('dump_preview', True))

    df_sta = _read_station_daily_precip(station_dir, stations)
    # 对齐到 meteo_df['time']
    meteo_time = meteo_df['time']
    df_sta = df_sta.reindex(meteo_time).interpolate(method='time').ffill().bfill().astype(np.float32)
    if (~np.isfinite(df_sta.to_numpy(np.float32))).any():
        raise ValueError("站点降水在对齐/填充后仍存在 NaN/Inf")
    station_total = _combine_station_total(df_sta, strategy, weights)
    # 插入到 meteo 表
    meteo_with_sta = meteo_df.copy()
    meteo_with_sta['station_total'] = station_total.values

    # 准备 (rainB,tempB,snowB,petB) using split
    rainB, tempB, snowB, petB, _timeB = prepare_meteo_inputs(
        meteo_with_sta,
        Ng,
        t_snow=t_snow,
        t_rain=t_rain,
        precip_mode='split',
        total_precip_col='station_total',
    )
    # 若 sim_unit=subbasin，需要聚合
    if getattr(cfg, 'SIM_UNIT', None) == 'subbasin':
        rainB, tempB, snowB, petB = aggregate_meteo_by_sub(rainB, tempB, snowB, petB, grid2sub)

    # 9) 时间与长度对齐（以 qobs、rain 的最短长度为准）
    T = min(qobs.shape[0], rainA.shape[0], rainB.shape[0])
    rainA, tempA, snowA, petA = rainA[:T], tempA[:T], snowA[:T], petA[:T]
    rainB, tempB, snowB, petB = rainB[:T], tempB[:T], snowB[:T], petB[:T]
    q = qobs[:T]
    t_idx = pd.to_datetime(time_index[:T])
    if obs_station_arr is not None:
        obs_station_arr = obs_station_arr[:T]

    hydro_forcing_A = HydroForcing(
        rain=rainA,
        temp=tempA,
        snow=snowA,
        pet=petA,
        qobs=q,
        steps=T,
        obs_station_arr=obs_station_arr,
        sta_reach_idx=sta_reach_idx,
    )
    hydro_forcing_B = HydroForcing(
        rain=rainB,
        temp=tempB,
        snow=snowB,
        pet=petB,
        qobs=q,
        steps=T,
        obs_station_arr=obs_station_arr,
        sta_reach_idx=sta_reach_idx,
    )
    snowmeltA = build_snowmelt_controls(hydro_forcing_A, pdd_tuple, x0_struct)
    snowmeltB = build_snowmelt_controls(hydro_forcing_B, pdd_tuple, x0_struct)

    # 10) 模拟两场景
    yA = _simulate_series_fh(
        da,
        rainA,
        tempA,
        snowA,
        petA,
        obs_station_arr,
        sta_reach_idx,
        snowmelt=snowmeltA,
    )
    yB = _simulate_series_fh(
        da,
        rainB,
        tempB,
        snowB,
        petB,
        obs_station_arr,
        sta_reach_idx,
        snowmelt=snowmeltB,
    )

    # 11) 指标
    metrics = {
        'NSE': (_nse(yA, q), _nse(yB, q)),
        'KGE': (_kge(yA, q), _kge(yB, q)),
        'RMSE': (_rmse(yA, q), _rmse(yB, q)),
        'MAE': (_mae(yA, q), _mae(yB, q)),
    }
    df_metrics = pd.DataFrame({
        'CMFD': {k: float(v[0]) for k, v in metrics.items()},
        'StationSplit': {k: float(v[1]) for k, v in metrics.items()},
    })
    df_metrics['Delta(Station-CMFD)'] = df_metrics['StationSplit'] - df_metrics['CMFD']
    df_metrics.to_csv(out_dir / "metrics.csv")
    print(df_metrics)

    # 12) 可视化
    _plot_series(out_dir, "Sim vs Obs (Overlay)", t_idx, q, yA[:T], yB[:T])
    _plot_scatter(out_dir, yA[:T], yB[:T])

    # 13) 预览导出
    if dump_preview:
        try:
            tmeanA = (np.nanmean(tempA, axis=1) if getattr(tempA, 'ndim', 1) == 2 else np.asarray(tempA).reshape(-1))
            prev = pd.DataFrame({
                'time': t_idx,
                'station_total': station_total.iloc[:T].values,
                'temp_mean': np.asarray(tmeanA, dtype=np.float32)[:T],
                'rainA_g0': rainA[:T, 0] if rainA.ndim == 2 else rainA[:T],
                'snowA_g0': snowA[:T, 0] if snowA.ndim == 2 else snowA[:T],
                'rainB_g0': rainB[:T, 0] if rainB.ndim == 2 else rainB[:T],
                'snowB_g0': snowB[:T, 0] if snowB.ndim == 2 else snowB[:T],
            })
            prev.to_csv(out_dir / "meteo_preview.csv", index=False)
        except Exception as e:
            print(f"[WARN] 导出 meteo_preview 失败: {e}")

    print(f"[OK] 对比完成，输出目录: {out_dir}")


if __name__ == '__main__':  # pragma: no cover
    main()



