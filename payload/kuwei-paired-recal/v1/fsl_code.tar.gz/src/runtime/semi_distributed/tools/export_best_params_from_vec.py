"""export_best_params_from_vec.py

将已保存的 best_vec.npy 转换为参数字典，并序列化为 YAML（best_params.yml），
便于后续模拟与数据同化直接读取。

用法：
  python -m src.runtime.semi_distributed.tools.export_best_params_from_vec \
    --run-config experiments/semi_distributed/optimization/config/run_config_ylx_downstream.yml \
    [--vec results/fh_optimize/best_vec.npy] [--out results/fh_optimize/best_params.yml]
"""
from __future__ import annotations

from pathlib import Path
import argparse
import numpy as np
import yaml

from src.runtime.semi_distributed.core.config_loader import load_run_config_internal as _load_run_config, set_run_config_path
from src.runtime.semi_distributed.core.pipeline import prepare_calibration_session
from src.runtime.semi_distributed.core.params import vector_to_params


def _to_py(obj):
    """递归将 numpy 类型转换为 Python 原生类型/列表，便于 YAML/JSON 序列化。"""
    import numpy as _np
    if isinstance(obj, dict):
        return {k: _to_py(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [
            _to_py(v) for v in obj
        ]
    if isinstance(obj, (_np.ndarray,)):
        if obj.dtype.kind in ("i", "u"):
            return obj.astype(int).tolist()
        else:
            return obj.astype(float).tolist()
    if isinstance(obj, (_np.bool_,)):
        return bool(obj)
    if isinstance(obj, (_np.integer,)):
        return int(obj)
    if isinstance(obj, (_np.floating,)):
        return float(obj)
    return obj


def build_arg_parser():
    ap = argparse.ArgumentParser(description="Export best_vec.npy to best_params.yml")
    ap.add_argument("--run-config", required=False, help="run_config.yml 路径")
    ap.add_argument("--vec", required=False, default=None, help="best_vec.npy 路径（默认 results/fh_optimize/best_vec.npy）")
    ap.add_argument("--out", required=False, default=None, help="导出 YAML 路径（默认 results/fh_optimize/best_params.yml）")
    return ap


def main(argv=None):
    args = build_arg_parser().parse_args(argv)

    # 读取 run_config
    if getattr(args, 'run_config', None):
        set_run_config_path(Path(args.run_config))
    
    file_cfg = _load_run_config()

    # 准备会话，获取 calib_cfg 与 Ns
    from src.runtime.semi_distributed.core.optimization_config import OptimizationConfig
    cfg = OptimizationConfig()
    if isinstance(file_cfg, dict):
        if 'section' in file_cfg: cfg.set_section(file_cfg['section'])
        if 'sim_unit' in file_cfg: cfg.set_sim_unit(file_cfg['sim_unit'])
        if 'calib_anchor' in file_cfg: cfg.set_calib_anchor(file_cfg['calib_anchor'])
        if 'objective_flow' in file_cfg: cfg.set_objective_flow(file_cfg['objective_flow'])
        if 'calib_nodes' in file_cfg: cfg.select_calib_nodes(file_cfg['calib_nodes'])
        model_block = file_cfg.get('model')
        if isinstance(model_block, dict) and str(model_block.get('mode','')).lower() == 'inline':
            data_blk = model_block.get('data', {})
            setattr(cfg, 'INLINE_TOPOLOGY', data_blk.get('topology'))
            setattr(cfg, 'INLINE_CALIB', data_blk.get('calibration'))
            setattr(cfg, 'INLINE_PDD_XAJ', data_blk.get('pdd_xaj'))

    sess = prepare_calibration_session(cfg)
    calib_cfg = sess['calib_cfg']
    grid2sub = sess['grid2sub']
    Ns = grid2sub.shape[1]

    calib_cfg_eff = calib_cfg
    if not isinstance(calib_cfg.get('index_map', None), list) or len(calib_cfg['index_map']) == 0:
        calib_cfg_eff = dict(calib_cfg)
        calib_cfg_eff.pop('index_map', None)

    # 读取 best_vec.npy
    out_dir = Path('results') / 'fh_optimize'
    vec_path = Path(args.vec) if args.vec else (out_dir / 'best_vec.npy')
    x_best = np.load(vec_path)

    # 向量 → 参数字典，并序列化 YAML
    best_param_dict = vector_to_params(x_best, calib_cfg_eff, Ns)
    best_param_dict = _to_py(best_param_dict)
    out_path = Path(args.out) if args.out else (out_dir / 'best_params.yml')
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, 'w', encoding='utf-8') as fy:
        yaml.safe_dump(best_param_dict, fy, allow_unicode=True, sort_keys=False)
    print(f"[EXPORT] Saved YAML: {out_path}")


if __name__ == '__main__':  # pragma: no cover
    main()

