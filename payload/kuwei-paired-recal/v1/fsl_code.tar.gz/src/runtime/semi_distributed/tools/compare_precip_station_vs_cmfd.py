from __future__ import annotations
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import sys as _sys

import numpy as np
import pandas as pd
import yaml

# project root
PROJECT_ROOT = Path(__file__).resolve().parents[4]
if str(PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(PROJECT_ROOT))

from src.runtime.semi_distributed.core.optimization_config import OptimizationConfig  # noqa: E402
from src.runtime.semi_distributed.core.pipeline import prepare_calibration_session  # noqa: E402

DEFAULT_CFG_PATH = PROJECT_ROOT / "config" / "experiments" / "compare_total_precip_station_vs_cmfd.yml"


def _ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def _read_yaml(path: Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def _cfg_get(file_cfg: Dict[str, Any], key: str, default=None):
    if not isinstance(file_cfg, dict):
        return default
    if key in file_cfg:
        return file_cfg.get(key, default)
    scene = file_cfg.get('scene')
    if isinstance(scene, dict) and key in scene:
        return scene.get(key, default)
    return default


def _apply_base_config_to(cfg: OptimizationConfig, base_cfg: Dict[str, Any], overrides: Dict[str, Any]) -> None:
    _sec = _cfg_get(base_cfg, 'section');            _sec and cfg.set_section(_sec)
    _simu = _cfg_get(base_cfg, 'sim_unit');          _simu and cfg.set_sim_unit(_simu)
    _anch = _cfg_get(base_cfg, 'calib_anchor');      _anch and cfg.set_calib_anchor(_anch)
    _objf = _cfg_get(base_cfg, 'objective_flow');    _objf and cfg.set_objective_flow(_objf)
    _st = _cfg_get(base_cfg, 'start_date');          (isinstance(_st, str) and _st.strip()) and setattr(cfg, 'START_TIME', _st)
    _ed = _cfg_get(base_cfg, 'end_date');            (isinstance(_ed, str) and _ed.strip()) and setattr(cfg, 'END_TIME', _ed)
    _exy = _cfg_get(base_cfg, 'exclude_years')
    if _exy is not None:
        try:
            if isinstance(_exy, (list, tuple, set)):
                setattr(cfg, 'EXCLUDE_YEARS', set(int(x) for x in _exy))
            elif isinstance(_exy, str):
                years = [int(s.strip()) for s in _exy.split(',') if s.strip()]
                setattr(cfg, 'EXCLUDE_YEARS', set(years))
            else:
                setattr(cfg, 'EXCLUDE_YEARS', {int(_exy)})
        except Exception:
            pass
    time_blk = overrides.get('time') or {}
    if isinstance(time_blk, dict):
        ts = time_blk.get('start_date'); te = time_blk.get('end_date'); ex = time_blk.get('exclude_years')
        (isinstance(ts, str) and ts.strip()) and setattr(cfg, 'START_TIME', ts)
        (isinstance(te, str) and te.strip()) and setattr(cfg, 'END_TIME', te)
        if ex is not None:
            try:
                if isinstance(ex, (list, tuple, set)):
                    setattr(cfg, 'EXCLUDE_YEARS', set(int(x) for x in ex))
                elif isinstance(ex, str):
                    years = [int(s.strip()) for s in ex.split(',') if s.strip()]
                    setattr(cfg, 'EXCLUDE_YEARS', set(years))
                else:
                    setattr(cfg, 'EXCLUDE_YEARS', {int(ex)})
            except Exception:
                pass


def _read_station_daily_precip(station_dir: Path, station_ids: List[str]) -> pd.DataFrame:
    frames: List[pd.Series] = []
    cols: List[str] = []
    for sid in station_ids:
        sid_dir = station_dir / sid
        if not sid_dir.exists():
            continue
        series_list: List[pd.Series] = []
        for fp in sorted(sid_dir.glob("*.xlsx")):
            try:
                df = pd.read_excel(fp)
                if 'P' not in df or 'Time' not in df:
                    continue
                s = pd.Series(df['P'].values, index=pd.to_datetime(df['Time']), name=sid)
                series_list.append(s)
            except Exception:
                continue
        if series_list:
            ser = pd.concat(series_list).sort_index()
            ser.name = sid
            frames.append(ser)
            cols.append(sid)
    if not frames:
        raise FileNotFoundError(f"未在 {station_dir} 读取到任何有效站点降水")
    df_out = pd.concat(frames, axis=1)
    df_out.columns = cols
    return df_out


def _combine_station_total(df: pd.DataFrame, strategy: str, weights: Optional[Dict[str, float]]) -> pd.Series:
    stg = (strategy or 'mean').strip().lower()
    if stg == 'ylx':
        if 'ylx' not in df.columns:
            raise ValueError("strategy=ylx 但未找到 ylx 列")
        out = df['ylx'].astype(np.float32)
    elif stg == 'weighted':
        if not weights:
            raise ValueError("strategy=weighted 需要提供 weights")
        use_cols = [c for c in df.columns if c in weights]
        if not use_cols:
            raise ValueError("weights 与站点列无交集")
        w = np.array([float(weights[c]) for c in use_cols], dtype=np.float64)
        wsum = float(np.sum(w))
        if not np.isfinite(wsum) or wsum <= 0:
            raise ValueError("weights 非法或权重和为0")
        w = w / wsum
        out = (df[use_cols].to_numpy(np.float32) @ w.astype(np.float32)).astype(np.float32)
        out = pd.Series(out, index=df.index, name='station_total')
    else:
        out = df.mean(axis=1).astype(np.float32)
    out.name = 'station_total'
    return out


def _plot_overlay(out_dir: Path, time_index: pd.DatetimeIndex, station: np.ndarray, cmfd: np.ndarray):
    try:
        import matplotlib.pyplot as plt  # type: ignore
    except Exception:
        print("[WARN] 未安装 matplotlib，跳过绘图。")
        return
    fig, ax = plt.subplots(figsize=(10, 4))
    ax.plot(time_index, station, label='Station total', color='#ff7f0e', linewidth=1.0)
    ax.plot(time_index, cmfd, label='CMFD total (rain+snow)', color='#1f77b4', linewidth=1.0, alpha=0.85)
    ax.set_title('Total Precipitation: Station vs CMFD')
    ax.set_ylabel('mm/day')
    ax.grid(True, alpha=0.3)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(out_dir / "overlay_station_vs_cmfd_total.png", dpi=150)
    plt.close(fig)


def _plot_scatter(out_dir: Path, station: np.ndarray, cmfd: np.ndarray):
    try:
        import matplotlib.pyplot as plt  # type: ignore
    except Exception:
        return
    m = 0.0
    M = float(max(np.nanmax(station), np.nanmax(cmfd)))
    fig, ax = plt.subplots(figsize=(4, 4))
    ax.scatter(station, cmfd, s=6, alpha=0.5)
    ax.plot([m, M], [m, M], 'r--', linewidth=1.0)
    ax.set_xlabel('Station total (mm/day)')
    ax.set_ylabel('CMFD total (mm/day)')
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_dir / "scatter_station_vs_cmfd_total.png", dpi=150)
    plt.close(fig)


def main():
    cfg_path = DEFAULT_CFG_PATH
    if not cfg_path.exists():
        raise FileNotFoundError(f"未找到对比配置: {cfg_path}")
    compare_cfg = _read_yaml(cfg_path)

    # 读取 base run config
    base_run_cfg_path = str(compare_cfg.get('base_run_config') or "basins/ylx/config/run_config_ylx_downstream.yml")
    from src.runtime.semi_distributed.core import config_loader as _config_loader
    _config_loader.set_run_config_path(Path(base_run_cfg_path))
    base_cfg = _config_loader.load_run_config_internal()

    # 构造 OptimizationConfig 并应用覆盖
    cfg = OptimizationConfig()
    _apply_base_config_to(cfg, base_cfg, compare_cfg)

    # 会话：用于获取时间轴、grid2sub、sub_area以及 meteo_inputs（已按 SIM_UNIT 聚合）
    sess = prepare_calibration_session(cfg)
    rain, temp, snow, pet = sess['meteo_inputs']
    time_index = pd.to_datetime(sess['time_index'])
    sub_area = sess['sub_area']

    # 计算 CMFD 总降水（按配置聚合为单列）
    agg_mode = str((compare_cfg.get('cmfd') or {}).get('aggregate') or 'area_weighted').lower()
    if rain.ndim == 1 or rain.shape[1] == 1:
        cmfd_total = (np.asarray(rain).reshape(-1) + np.asarray(snow).reshape(-1)).astype(np.float32)
    else:
        total_mat = (rain.astype(np.float32) + snow.astype(np.float32))  # (T, N)
        if agg_mode == 'area_weighted' and sub_area is not None and sub_area.size == total_mat.shape[1]:
            w = np.asarray(sub_area, dtype=np.float32)
            w = w / max(float(np.sum(w)), 1e-6)
            cmfd_total = (total_mat @ w).astype(np.float32)
        else:
            cmfd_total = np.nanmean(total_mat, axis=1).astype(np.float32)

    # 读取站点降水并合成总降水
    sp_blk = compare_cfg.get('station_precip') or {}
    _sp_dir = sp_blk.get('dir')
    if not _sp_dir:
        raise ValueError("station_precip.dir is required in run_config. No hardcoded fallback.")
    station_dir = PROJECT_ROOT / str(_sp_dir)
    strategy = str(sp_blk.get('strategy') or 'mean')
    stations = list(sp_blk.get('stations') or ['ylx', 'zmsk', 'ql'])
    weights = sp_blk.get('weights')
    align_method = str(sp_blk.get('align_method') or 'interpolate').lower()
    dump_preview = bool(sp_blk.get('dump_preview', True))

    df_sta = _read_station_daily_precip(station_dir, stations)
    df_sta = df_sta.reindex(time_index)
    if align_method == 'interpolate':
        df_sta = df_sta.interpolate(method='time').ffill().bfill()
    else:
        df_sta = df_sta.ffill().bfill()
    df_sta = df_sta.astype(np.float32)
    if (~np.isfinite(df_sta.to_numpy(np.float32))).any():
        raise ValueError("站点降水对齐/填充后仍存在 NaN/Inf")
    station_total = _combine_station_total(df_sta, strategy, weights)

    # 对齐长度
    T = min(cmfd_total.shape[0], station_total.shape[0], time_index.shape[0])
    cmfd_total = cmfd_total[:T]
    station_total = station_total.iloc[:T]
    time_index = time_index[:T]

    # 简单指标（相关、偏差、RMSE）
    def _safe(arr): return np.asarray(arr, dtype=np.float64)
    a = _safe(station_total.values)
    b = _safe(cmfd_total)
    mask = np.isfinite(a) & np.isfinite(b)
    a = a[mask]; b = b[mask]
    corr = float(np.corrcoef(a, b)[0, 1]) if a.size > 1 else float('nan')
    bias = float(np.nanmean(b - a)) if a.size > 0 else float('nan')
    rmse = float(np.sqrt(np.nanmean((b - a) ** 2))) if a.size > 0 else float('nan')

    out_dir = PROJECT_ROOT / str(compare_cfg.get('output_dir') or "results/experiments/precip_station_vs_cmfd")
    _ensure_dir(out_dir)

    pd.DataFrame({
        'metric': ['corr', 'bias(cmfd-station)', 'rmse'],
        'value': [corr, bias, rmse],
    }).to_csv(out_dir / "metrics_precip.csv", index=False)

    _plot_overlay(out_dir, time_index, station_total.values.astype(np.float32), cmfd_total.astype(np.float32))
    _plot_scatter(out_dir, station_total.values.astype(np.float32), cmfd_total.astype(np.float32))

    if dump_preview:
        prev = pd.DataFrame({
            'time': time_index,
            'station_total': station_total.values.astype(np.float32),
            'cmfd_total': cmfd_total.astype(np.float32),
        })
        prev.to_csv(out_dir / "precip_preview.csv", index=False)

    print("[OK] 降水对比完成:", out_dir)


if __name__ == '__main__':  # pragma: no cover
    main()



