"""
params.py

Parameter handling utilities for semi-distributed optimization.
Reconstructed from lost file.
"""
from __future__ import annotations
import numpy as np
from typing import Dict, Any, Tuple, List, Optional, Union
from src.runtime.semi_distributed.core.param_utils import update_model_params

def compute_n_sub_from_K(K: float, dt: float) -> int:
    """
    根据传播时间 K 和步长 dt 计算分段数 n_sub。
    n_sub = ceil(K / dt)
    """
    if dt <= 0:
        return 1
    # 避免浮点误差导致的不必要进位，比如 1.0000000001 -> 2
    val = K / dt
    if abs(val - round(val)) < 1e-5:
        return max(1, int(round(val)))
    return max(1, int(np.ceil(val)))

def compute_muskingum_coefficients(K: float, X: float, dt: float) -> Tuple[float, float, float]:
    """
    计算 Muskingum 系数 c0, c1, c2。
    
    公式:
    D = K(1-X) + 0.5dt
    c0 = (-KX + 0.5dt) / D
    c1 = (KX + 0.5dt) / D
    c2 = (K(1-X) - 0.5dt) / D
    """
    D = K * (1 - X) + 0.5 * dt
    if abs(D) < 1e-6:
        # 避免除零
        return 0.0, 0.0, 0.0
    c0 = (-K * X + 0.5 * dt) / D
    c1 = (K * X + 0.5 * dt) / D
    c2 = (K * (1 - X) - 0.5 * dt) / D
    return c0, c1, c2

def vector_to_params(vec: np.ndarray, calib_cfg: Dict[str, Any], n_basins: int) -> Dict[str, Any]:
    """
    将优化参数向量转换为参数字典。
    
    参数:
        vec: 优化参数向量
        calib_cfg: 校准配置
        n_basins: 子流域数量 (用于 basin 级别参数展开)
        
    返回:
        参数字典 (sparse dict for update_model_params)
    """
    param_dict: Dict[str, Any] = {}
    
    # 1. 优先使用 index_map (支持 layer_node 等复杂结构)
    if "index_map" in calib_cfg:
        for i, (p_cfg, idx_info) in enumerate(calib_cfg["index_map"]):
            if i >= len(vec):
                break
            val = vec[i]
            if np.isnan(val):
                print(f"[DEBUG] NaN in vec at index {i}: {val}, p_cfg={p_cfg}")
            
            path = p_cfg["path"]
            
            # 特殊处理 msk_layers (list of dicts)
            if path[0] == "msk_layers":
                # 假设 path 是 ['msk_layers', 'K'] 或 ['msk_layers', '*', 'K']
                # idx_info 必须包含 (layer_idx, node_idx)
                if isinstance(idx_info, (list, tuple)) and len(idx_info) >= 2:
                    layer_idx, node_idx = idx_info[0], idx_info[1]
                    last_key = path[-1]
                    
                    if "msk_layers" not in param_dict:
                        param_dict["msk_layers"] = []
                    elif isinstance(param_dict["msk_layers"], dict):
                        # 如果已经被 generic recursion 创建为 dict，则覆盖为 list
                        # 这通常不应该发生，如果我们跳过了 generic recursion
                        param_dict["msk_layers"] = []
                    
                    # 确保 msk_layers 列表足够长
                    while len(param_dict["msk_layers"]) <= layer_idx:
                        param_dict["msk_layers"].append({})
                    
                    layer_dict = param_dict["msk_layers"][layer_idx]
                    
                    if last_key not in layer_dict:
                        layer_dict[last_key] = {} # 使用 dict 暂存 sparse values
                    
                    if isinstance(layer_dict[last_key], dict):
                        layer_dict[last_key][node_idx] = val
                    continue


            # 递归构建字典路径 (Generic)
            curr = param_dict
            for key in path[:-1]:
                if key not in curr:
                    curr[key] = {}
                curr = curr[key]
            
            last_key = path[-1]
            curr[last_key] = val
                
        # Post-process: convert sparse dicts to arrays for msk_layers
        if "msk_layers" in param_dict and isinstance(param_dict["msk_layers"], list):
            for layer in param_dict["msk_layers"]:
                for k, v in layer.items():
                    if isinstance(v, dict):
                        # Convert {idx: val} to array? We don't know size.
                        # Assuming max index is size-1?
                        max_idx = max(v.keys())
                        arr = np.zeros(max_idx + 1, dtype=np.float32) # Default 0? Or NaN?
                        # Ideally we should read from template, but we don't have template here.
                        # This is a limitation of vector_to_params without template.
                        for idx, val in v.items():
                            arr[idx] = val
                        layer[k] = arr

        return param_dict

    # 2. Fallback: 基于 calibrate_params 的旧逻辑
    calib_params = calib_cfg.get("calibrate_params", [])
    vec_idx = 0
    
    for p_cfg in calib_params:
        name = p_cfg.get("name")
        path = p_cfg.get("path", [name])
        level = p_cfg.get("level", "basin")
        
        # 确定参数数量
        count = 1
        if level == "basin" or level == "sub":
            count = n_basins
        elif level == "layer":
            # 假设 msk_layers 长度未知，这里可能无法正确处理 layer 级别
            # 除非 calib_cfg 有提示
            count = 1 # 暂时不支持自动推断 layer 数量
        
        # 提取值
        if vec_idx + count > len(vec):
            break
            
        vals = vec[vec_idx : vec_idx + count]
        vec_idx += count
        
        # 构建 param_dict
        curr = param_dict
        for key in path[:-1]:
            if key not in curr:
                curr[key] = {}
            curr = curr[key]
        
        last_key = path[-1]
        
        if level == "basin" or level == "sub":
            curr[last_key] = vals # Array
        else:
            curr[last_key] = vals[0] # Scalar
            
    return param_dict

def prepare_initial_state(initial_conditions: Dict[str, Any], Ng: int, enable_snowmelt: bool = False) -> np.ndarray:
    """
    准备初始状态数组 (Ng, 11)。
    状态定义:
    0: snow_depth
    1: ice_depth
    2: last_temp
    3: W (Soil Water)
    4: WU (Upper Soil Water)
    5: WL (Lower Soil Water)
    6: WD (Deep Soil Water)
    7: S (Free Water)
    8: QS (Surface Runoff)
    9: QI (Interflow)
    10: QG (Groundwater)
    """
    state = np.zeros((Ng, 11), dtype=np.float32)
    
    if not initial_conditions:
        return state
        
    # 键映射（liquid_water 是 col[2] 的 V3 别名，与 last_temp 共享同一列）
    key_map = {
        "snow_depth": 0, "ice_depth": 1, "last_temp": 2, "liquid_water": 2,
        "W": 3, "WU": 4, "WL": 5, "WD": 6, "S": 7,
        "QS": 8, "QI": 9, "QG": 10
    }
    
    for key, val in initial_conditions.items():
        if key in key_map:
            idx = key_map[key]
            if np.isscalar(val):
                state[:, idx] = val
            else:
                state[:, idx] = np.array(val, dtype=np.float32)
                
    return state

def prepare_model_params(
    param_dict: Dict[str, Any],
    model_params_template: Dict[str, Any],
    calibration_config: Dict[str, Any],
    grid2sub: np.ndarray,
    sub_area: np.ndarray,
    connection_matrices: List[np.ndarray],
    param_mode: Optional[Dict[str, Any]] = None
) -> Tuple[Dict[str, Any], Tuple, Tuple, Any, Dict[str, Any]]:
    """
    准备模型参数，返回模拟所需的各种元组和参数。
    
    返回:
        (merged_model, pdd_tuple, xaj_tuple, None, core_args)
    """
    # 1. 更新参数
    merged_model = update_model_params(model_params_template, param_dict, calibration_config)
    
    Ng = grid2sub.shape[0]
    
    def _get_vec(cfg, name, default=0.0):
        val = cfg.get(name, default)
        if np.isscalar(val):
            return np.full(Ng, val, dtype=np.float32)
        return np.array(val, dtype=np.float32)
    
    # 2. 提取 PDD 参数
    #    pdd_version: None → 按 cfr/cwh 存在性推断 v1/v2（向后兼容）
    #                 "v3" → 4-tuple (fsnow, fice, cfr, cwh)
    pdd_cfg = merged_model.get("pdd_params", {})
    pdd_version = pdd_cfg.get("pdd_version", None)

    if pdd_version == "v3":
        # V3: HBV 雪物理 + 冰川能量级联 + rfice 衰减 — 5-tuple
        pdd_tuple = (
            _get_vec(pdd_cfg, "pdd_factor_snow", 1.0),
            _get_vec(pdd_cfg, "pdd_factor_ice", 1.0),
            _get_vec(pdd_cfg, "cfr", 0.05),
            _get_vec(pdd_cfg, "cwh", 0.10),
            _get_vec(pdd_cfg, "rfice", 0.5),
        )
    elif "cfr" in pdd_cfg or "cwh" in pdd_cfg:
        # V2 (HBV): 6-tuple（向后兼容）
        pdd_version = "v2"
        pdd_tuple = (
            _get_vec(pdd_cfg, "pdd_factor_snow", 1.0),
            _get_vec(pdd_cfg, "pdd_factor_ice", 1.0),
            _get_vec(pdd_cfg, "refreeze_snow", 0.5),
            _get_vec(pdd_cfg, "refreeze_ice", 0.5),
            _get_vec(pdd_cfg, "cfr", 0.05),
            _get_vec(pdd_cfg, "cwh", 0.10),
        )
    else:
        # V1 (原版): 4-tuple
        pdd_version = "v1"
        pdd_tuple = (
            _get_vec(pdd_cfg, "pdd_factor_snow", 1.0),
            _get_vec(pdd_cfg, "pdd_factor_ice", 1.0),
            _get_vec(pdd_cfg, "refreeze_snow", 0.5),
            _get_vec(pdd_cfg, "refreeze_ice", 0.5),
        )
    
    # 3. 提取 XAJ 参数
    xaj_cfg = merged_model.get("xaj_params", {})
    # 顺序: kc, ki, kg, cs, ci, cg, wum, wlm, wdm, sm, imp, c, b, ex, uf, wmm, ms
    xaj_keys = ["kc", "ki", "kg", "cs", "ci", "cg", "wum", "wlm", "wdm", "sm", "imp", "c", "b", "ex", "uf", "wmm", "ms"]
    xaj_list = []
    for k in xaj_keys:
        default = 0.0
        if k == "kc": default = 1.0
        if k == "ex": default = 1.5
        xaj_list.append(_get_vec(xaj_cfg, k, default))
    xaj_tuple = tuple(xaj_list)
    
    # 4. 处理 Muskingum 层参数
    msk_layers = merged_model.get("msk_layers", [])
    msk_layers_params = []
    
    for layer in msk_layers:
        idx = layer.get("index")
        if idx is None:
            continue
        idx = np.array(idx, dtype=np.int32)
        size = len(idx)
        dt = 1.0  # Default time step (hour)

        # Check if c0, c1 are provided (Direct calibration mode)
        provided_c0 = layer.get("c0")
        provided_c1 = layer.get("c1")
        
        K = None  # Initialize K to avoid UnboundLocalError
        
        if provided_c0 is not None and provided_c1 is not None:
             if np.isscalar(provided_c0): c0 = np.full(size, provided_c0, dtype=np.float32)
             else: c0 = np.array(provided_c0, dtype=np.float32)
             
             if np.isscalar(provided_c1): c1 = np.full(size, provided_c1, dtype=np.float32)
             else: c1 = np.array(provided_c1, dtype=np.float32)
             
             c2 = 1.0 - c0 - c1
        else:
            K = layer.get("K")
            X = layer.get("X")
            
            # 确保 K, X 是数组
            if np.isscalar(K): 
                K = np.full(size, K, dtype=np.float32)
            else: 
                K = np.array(K, dtype=np.float32)
                if K.ndim == 0:
                    K = np.full(size, K.item(), dtype=np.float32)
            
            if np.any(np.isnan(K)):
                pass

            if np.isscalar(X): 
                X = np.full(size, X, dtype=np.float32)
            else: 
                X = np.array(X, dtype=np.float32)
                if X.ndim == 0:
                    X = np.full(size, X.item(), dtype=np.float32)
            
            # 先确定 n_sub
            if "n_sub" in layer:
                _pre_nsub = np.array(layer["n_sub"], dtype=np.int32)
                if _pre_nsub.ndim == 0:
                    _pre_nsub = np.full(size, _pre_nsub.item(), dtype=np.int32)
            else:
                _pre_nsub = np.array([compute_n_sub_from_K(k, dt) for k in K], dtype=np.int32)

            # 计算 Muskingum 系数 — 使用总 K（与原始优化行为一致）
            # 注: n_sub 由 compute_n_sub_from_K(K, dt) 自动计算，
            #     路由内核对每个子段重复应用 (c0, c1, c2) 共 n_sub 次。
            c0 = np.empty(size, dtype=np.float32)
            c1 = np.empty(size, dtype=np.float32)
            c2 = np.empty(size, dtype=np.float32)
            
            for i in range(size):
                _c0, _c1, _c2 = compute_muskingum_coefficients(K[i], X[i], dt)
                c0[i] = _c0
                c1[i] = _c1
                c2[i] = _c2
            
        # n_sub (final)
        if "n_sub" in layer:
            n_sub = np.array(layer["n_sub"], dtype=np.int32)
            if n_sub.ndim == 0:
                n_sub = np.full(size, n_sub.item(), dtype=np.int32)
        elif K is not None:
            n_sub = np.array([compute_n_sub_from_K(k, dt) for k in K], dtype=np.int32)
        else:
            n_sub = np.ones(size, dtype=np.int32)
            
        msk_layers_params.append((idx, c0, c1, c2, n_sub))
        
    core_args = {
        "msk_layers_params": msk_layers_params,
        "C_mats": connection_matrices,
        "pdd_version": pdd_version,
    }
    
    return merged_model, pdd_tuple, xaj_tuple, msk_layers_params, core_args

