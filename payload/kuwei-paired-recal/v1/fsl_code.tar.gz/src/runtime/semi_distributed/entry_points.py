"""
Shared Entry Points for Semi-Distributed Model Runtime
======================================================
This module centralizes the CLI logic for running optimization and evaluation.
It is used by:
1. scripts/run_calibration.py (Global Entry Point)
2. basins/<basin>/scripts/run_optimization.py (Basin-Specific Wrappers)
"""
import sys
import os
import argparse
from pathlib import Path
from typing import Any, Dict

from src.runtime.semi_distributed.core.optimization_config import OptimizationConfig
from src.runtime.semi_distributed.core.pipeline import run_optimization_eval
from src.runtime.semi_distributed.core.config_loader import (
    load_run_config_internal,
    set_run_config_path,
    _LAST_RUN_CONFIG_PATH
)

def _install_print_filter(level_name: str, evalchk_mode: str):
    """最小实现：返回原生 print，用于保持调用方语义。"""
    import builtins
    return builtins.print

def _summarize_config(cfg: OptimizationConfig) -> None:
    try:
        sec = getattr(cfg, 'SECTION', None) or getattr(cfg, 'section', None)
        sim_unit = getattr(cfg, 'SIM_UNIT', None)
        anchor = getattr(cfg, 'CALIB_ANCHOR', None)
        obj = getattr(cfg, 'OBJECTIVE_FLOW', None)
        it = getattr(cfg, 'MAX_ITER', None)
        pop = getattr(cfg, 'POP_SIZE', None)
        workers = getattr(cfg, 'WORKERS', None)
        print(f"[CFG] section={sec} sim_unit={sim_unit} anchor={anchor} objective={obj} max_iter={it} pop={pop} workers={workers}")
    except Exception:
        pass

def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description='半分布式参数优化/评价 (单一配置文件模式)',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument('--run-config', required=True, help='显式指定 run_config.yml')
    p.add_argument('--max-iter', type=int, help='Override max_iter')
    p.add_argument('--pop-size', type=int, help='Override pop_size')
    p.add_argument('--workers', type=int, help='Override workers')
    p.add_argument('--output-root', type=str, help='Override output root directory')
    return p

def run_optimization_cli(argv=None):
    """
    Main CLI entry point for running optimization/evaluation.
    
    Args:
        argv: Optional list of command line arguments (defaults to sys.argv[1:])
    """
    parser = build_arg_parser()
    args = parser.parse_args(argv)

    if getattr(args,'run_config', None):
        path = Path(args.run_config)
        if not path.exists():
            parser.error(f'--run-config not found: {path}')
        set_run_config_path(path)

    # 读取配置（严格单一配置源）
    file_cfg = load_run_config_internal()

    # 从 diagnostics 读取日志与打印策略
    diag = file_cfg.get('diagnostics', {}) if isinstance(file_cfg, dict) else {}
    level_name = str(diag.get('log_level') or os.environ.get('HYDRO_LOG_LEVEL') or 'info')
    evalchk_mode = str(diag.get('evalchk_mode') or 'once')
    os.environ['EVALCHK_MODE'] = evalchk_mode

    # 环境变量: 诊断/预检查控制（仅来自 run_config）
    debug_step0 = str(diag.get('debug_step0', 'off')).lower()
    if debug_step0 not in ('off','once','each'): debug_step0 = 'off'
    os.environ['STEP0_DEBUG_MODE'] = debug_step0
    os.environ.setdefault('STEP0_MASTER_ONLY', '1')
    if 'eval_precheck_serial' in file_cfg:
        os.environ['EVALOPT_PRECHECK_SERIAL'] = '1' if file_cfg['eval_precheck_serial'] else '0'
    if 'eval_precheck_iters' in file_cfg:
        os.environ['EVALOPT_PRECHECK_ITERS'] = str(file_cfg['eval_precheck_iters'])
    if 'eval_precheck_pop' in file_cfg:
        os.environ['EVALOPT_PRECHECK_POP'] = str(file_cfg['eval_precheck_pop'])
    if 'precheck_params_only' in diag:
        os.environ['PRECHECK_PARAMS_ONLY'] = '1' if diag['precheck_params_only'] else '0'
    if 'evalopt_print_freq' in diag:
        try:
            os.environ['EVALOPT_PRINT_FREQ'] = str(int(diag['evalopt_print_freq']))
        except Exception:
            pass
    # 新增: 抑制下游流量缺失告警
    if 'suppress_discharge_warn' in diag:
        os.environ['SUPPRESS_DISCHARGE_WARN'] = '1' if diag['suppress_discharge_warn'] else '0'
    # 新增: 固定广播文件路径 (npz) 供管线加载
    if 'fixed_broadcast' in file_cfg and file_cfg['fixed_broadcast']:
        os.environ['FIXED_BROADCAST_FILE'] = str(file_cfg['fixed_broadcast'])
    # 开启严格单一配置模式：禁用 OptimizationConfig 的环境注入
    os.environ['STRICT_SINGLE_CONFIG'] = '1'

    # 新增: 解析 model.inline 数据
    model_block = file_cfg.get('model') if isinstance(file_cfg, dict) else None
    if isinstance(model_block, dict) and str(model_block.get('mode','')).lower() == 'inline':
        data_blk = model_block.get('data', {})
        # 将内联三件套挂到 cfg 实例上（后续模块优先使用）
        file_cfg['_INLINE_TOPOLOGY'] = data_blk.get('topology')
        file_cfg['_INLINE_CALIB'] = data_blk.get('calibration')
        file_cfg['_INLINE_PDD_XAJ'] = data_blk.get('pdd_xaj')
        # 内联初始条件（如存在）
        ic_inline = data_blk.get('initial_conditions')
        if isinstance(ic_inline, dict):
            file_cfg['_INLINE_INITIAL_CONDITIONS'] = ic_inline

    # 新增: 严格无回退开关（默认开启）；仅当配置显式设置 strict_no_fallback: false 时关闭
    strict_no_fallback = True
    try:
        if 'strict_no_fallback' in file_cfg or 'strict_no_fallback' in diag:
            strict_no_fallback = bool(file_cfg.get('strict_no_fallback', diag.get('strict_no_fallback')))
    except Exception:
        strict_no_fallback = True
    if strict_no_fallback:
        os.environ['STRICT_NO_FALLBACK'] = '1'

    orig_print = _install_print_filter(level_name, evalchk_mode)
    if level_name not in ('warning','error','critical'):
        orig_print(f'[SUMMARY] log-level={level_name}')

    # -------- 兼容旧键：eval_station/flow_source -> calib_anchor/objective_flow --------
    def _invalid_str(x: Any) -> bool:
        return (not isinstance(x, str)) or (x.strip().lower() in ('', 'none', 'null'))

    legacy_eval_station = file_cfg.get('eval_station', None) if isinstance(file_cfg, dict) else None
    legacy_flow_source = file_cfg.get('flow_source', None) if isinstance(file_cfg, dict) else None
    # calib_anchor 兼容映射
    if (isinstance(file_cfg, dict) and _invalid_str(file_cfg.get('calib_anchor', None))
            and not _invalid_str(legacy_eval_station)):
        file_cfg['calib_anchor'] = str(legacy_eval_station).strip()
        orig_print('[WARN] 检测到旧键 eval_station，已映射为 calib_anchor。建议在 run_config.yml 中改用 calib_anchor。')
    # objective_flow 兼容映射
    if isinstance(file_cfg, dict) and _invalid_str(file_cfg.get('objective_flow', None)):
        if isinstance(legacy_flow_source, str) and not _invalid_str(legacy_flow_source):
            file_cfg['objective_flow'] = str(legacy_flow_source).strip()
            orig_print('[WARN] 检测到旧键 flow_source，已映射为 objective_flow。建议在 run_config.yml 中改用 objective_flow。')
        elif legacy_flow_source is None and not _invalid_str(file_cfg.get('calib_anchor', None)):
            # 旧语义：flow_source=null 等价“目标用 eval_station 自身”；
            # 严格模式下禁止该回退，要求显式 objective_flow
            if os.environ.get('STRICT_NO_FALLBACK','0') == '1':
                orig_print('[CRITICAL] 检测到旧 flow_source=null，严格模式禁止回退为 calib_anchor。请显式设置 objective_flow。')
                raise SystemExit(2)
            # 非严格模式：沿用回退为 calib_anchor
            file_cfg['objective_flow'] = str(file_cfg['calib_anchor']).strip()
            orig_print('[INFO] flow_source 未显式指定(null)，objective_flow 将回退为 calib_anchor 对应站点。')

    # -------- 强制要求 calib_anchor 与 objective_flow 显式提供 --------
    # calib_anchor 必须存在且非空（可取 outlet_series 或具体站名）；兼容旧键 eval_anchor
    anchor_raw = file_cfg.get('calib_anchor', None)
    legacy_anchor = file_cfg.get('eval_anchor', None)
    if _invalid_str(anchor_raw):
        if _invalid_str(legacy_anchor):
            orig_print('[CRITICAL] run_config 缺少或留空: calib_anchor。请在 run_config.yml 中显式设置 calib_anchor（如 ylx 或 outlet_series）。')
            raise SystemExit(2)
        else:
            anchor_raw = legacy_anchor
            orig_print('[WARN] 使用了已废弃键 eval_anchor，请改用 calib_anchor。')
    # objective_flow 必须存在且非空，且不得为 from_anchor
    if 'objective_flow' not in file_cfg or _invalid_str(file_cfg.get('objective_flow')):
        orig_print('[CRITICAL] run_config 缺少或留空: objective_flow。请在 run_config.yml 中显式设置 objective_flow（如 outlet/outlet_series 或具体站名）。')
        raise SystemExit(2)
    if str(file_cfg.get('objective_flow','')).strip().lower() == 'from_anchor':
        orig_print('[CRITICAL] objective_flow=from_anchor 不被允许（避免歧义）。请直接设置为 outlet/outlet_series 或具体站名。')
        raise SystemExit(2)

    # 构造配置对象并用 file_cfg 映射字段
    cfg = OptimizationConfig()
    
    # 自动设置 CONFIG_DIR 为 run_config 所在目录
    if getattr(args, 'run_config', None):
        cfg.CONFIG_DIR = Path(args.run_config).resolve().parent

    # scene
    if 'section' in file_cfg: cfg.set_section(file_cfg['section'])
    if 'matrix_prefix' in file_cfg: cfg.set_matrix_prefix(file_cfg['matrix_prefix'])
    ov = file_cfg.get('override', None)
    if ov is not None:
        if isinstance(ov, str):
            if ov.strip() == '*':
                cfg.set_override_stations(None)
            elif ov.strip() in ('', 'none', 'null'):
                cfg.set_override_stations([])
            else:
                cfg.set_override_stations([s for s in ov.split(',') if s])
        elif isinstance(ov, (list, tuple)):
            cfg.set_override_stations(list(ov))
    if 'calib_nodes' in file_cfg: cfg.select_calib_nodes(file_cfg['calib_nodes'])
    if 'verify' in file_cfg: cfg.set_verify_nodes(file_cfg['verify'])

    # 校准锚点：来自 calib_anchor（或旧键 eval_anchor）
    anchor = str(anchor_raw).strip()
    cfg.set_calib_anchor(anchor)

    # 目标流量：来自 objective_flow（已校验非空且不为 from_anchor）
    oflow = str(file_cfg.get('objective_flow')).strip()
    cfg.set_objective_flow(oflow)

    # 新增：严格要求 sim_unit 显式提供（grid 或 subbasin）
    sim_unit = file_cfg.get('sim_unit', None)
    if not isinstance(sim_unit, str) or sim_unit.strip().lower() not in ('grid', 'subbasin'):
        orig_print('[CRITICAL] run_config 缺少或非法: sim_unit。请在 run_config.yml 中显式设置 sim_unit: grid 或 subbasin。')
        raise SystemExit(2)
    cfg.set_sim_unit(sim_unit)

    # 同步旧字段（兼容 pipeline/validation 仍读取旧名）
    cfg.EVAL_STATION = cfg.CALIB_ANCHOR
    cfg.FLOW_SOURCE_STATION = cfg.OBJECTIVE_FLOW

    # optimizer block (new nested format, with top-level fallback for backward compat)
    opt_block = file_cfg.get('optimizer', {}) if isinstance(file_cfg, dict) else {}
    if not isinstance(opt_block, dict):
        opt_block = {}

    # Algorithm selection
    if isinstance(opt_block, dict):
        if 'algorithm' in opt_block:
            cfg.ALGORITHM = str(opt_block['algorithm']).strip().lower()
        if 'sigma0' in opt_block:
            cfg.CMAES_SIGMA0 = float(opt_block['sigma0'])
        if 'seed_from' in opt_block:
            cfg.SEED_FROM = str(opt_block['seed_from'])
        if 'n_trials' in opt_block:
            cfg.OPTUNA_N_TRIALS = int(opt_block['n_trials'])

    # optimizer params (prefer CLI > top-level > optimizer block)
    if args.max_iter is not None:
        file_cfg['max_iter'] = args.max_iter
    elif 'max_iter' not in file_cfg and 'max_iter' in opt_block:
        file_cfg['max_iter'] = opt_block['max_iter']
    if args.pop_size is not None:
        file_cfg['pop_size'] = args.pop_size
    elif 'pop_size' not in file_cfg and 'pop_size' in opt_block:
        file_cfg['pop_size'] = opt_block['pop_size']
    if args.workers is not None:
        file_cfg['workers'] = args.workers
    elif 'workers' not in file_cfg and 'workers' in opt_block:
        file_cfg['workers'] = opt_block['workers']
    if 'resume' not in file_cfg and 'resume' in opt_block:
        file_cfg['resume'] = opt_block['resume']
    if 'objective' not in file_cfg and 'objective' in opt_block:
        file_cfg['objective'] = opt_block['objective']
    if 'objective_mask' not in file_cfg and 'objective_mask' in opt_block:
        file_cfg['objective_mask'] = opt_block['objective_mask']
    if 'objective_weight' not in file_cfg and 'objective_weight' in opt_block:
        file_cfg['objective_weight'] = opt_block['objective_weight']
    # 2026-07-14: water-balance penalty wiring (default absent -> lambda 0 = legacy no-op)
    if 'mean_flow_penalty_lambda' not in file_cfg and 'mean_flow_penalty_lambda' in opt_block:
        file_cfg['mean_flow_penalty_lambda'] = opt_block['mean_flow_penalty_lambda']
    if 'mean_flow_penalty_yearly' not in file_cfg and 'mean_flow_penalty_yearly' in opt_block:
        file_cfg['mean_flow_penalty_yearly'] = opt_block['mean_flow_penalty_yearly']

    if 'max_iter' in file_cfg: cfg.MAX_ITER = int(file_cfg['max_iter'])
    if 'pop_size' in file_cfg: cfg.POP_SIZE = int(file_cfg['pop_size'])
    if 'workers' in file_cfg: cfg.WORKERS = int(file_cfg['workers'])
    if 'resume' in file_cfg: cfg.RESUME_TRAINING = bool(file_cfg['resume'])
    if 'objective_mask' in file_cfg: cfg.OBJECTIVE_MASK = str(file_cfg['objective_mask'])
    if 'objective_weight' in file_cfg: cfg.OBJECTIVE_WEIGHT = str(file_cfg['objective_weight'])
    if 'objective' in file_cfg: cfg.OBJECTIVE_TYPE = str(file_cfg['objective']).strip().lower()
    if 'mean_flow_penalty_lambda' in file_cfg: cfg.MEAN_FLOW_PENALTY = float(file_cfg['mean_flow_penalty_lambda'])
    if 'mean_flow_penalty_yearly' in file_cfg: cfg.MEAN_FLOW_PENALTY_YEARLY = bool(file_cfg['mean_flow_penalty_yearly'])

    # Output root override
    if args.output_root:
        overridden_path = Path(args.output_root).resolve()
        cfg._force_output_dir = overridden_path


    # time
    if 'start_date' in file_cfg and file_cfg['start_date']:
        cfg.START_TIME = file_cfg['start_date']
    if 'end_date' in file_cfg and file_cfg['end_date']:
        cfg.END_TIME = file_cfg['end_date']

    # exclude_years + exclude_mode (2026-05-27): 详见 dataio._resolve_exclude_config
    _ex = file_cfg.get('exclude_years')
    if _ex is None:
        cfg.EXCLUDE_YEARS = set()
    elif isinstance(_ex, (list, tuple, set)):
        cfg.EXCLUDE_YEARS = {int(x) for x in _ex}
    elif isinstance(_ex, str):
        cfg.EXCLUDE_YEARS = {int(s.strip()) for s in _ex.split(',') if s.strip()}
    else:
        try:
            cfg.EXCLUDE_YEARS = {int(_ex)}
        except Exception:
            cfg.EXCLUDE_YEARS = set()
    _em = file_cfg.get('exclude_mode')
    cfg.EXCLUDE_MODE = (str(_em).strip().lower() if isinstance(_em, str) and _em.strip() else None)
    # exclude_windows (2026-07-06): sub-year bad-data windows dropped from calib target
    # (e.g. 2022-09~10 reservoir phantom flow). Top-level or under time: block.
    _exw = file_cfg.get('exclude_windows')
    if not _exw and isinstance(file_cfg, dict):
        _tb = file_cfg.get('time')
        if isinstance(_tb, dict):
            _exw = _tb.get('exclude_windows')
    cfg.EXCLUDE_WINDOWS = list(_exw) if _exw else None
    # eval_start_date (2026-07-07 BUG FIX): spinup trim for the DE objective (pipeline.py:583).
    # Was only mapped on the eval path (forecast_runner.build_cfg_from_run_config:212) and NEVER
    # here on the calibration path, so every prior DE objective silently scored from start_date —
    # including spinup months (namou_kuwei: 2017-06~12, where q_obs is known-bad stage-drift data).
    # Top-level or under time: block, mirroring exclude_windows.
    _evs = file_cfg.get('eval_start_date')
    if not _evs and isinstance(file_cfg, dict):
        _tb_evs = file_cfg.get('time')
        if isinstance(_tb_evs, dict):
            _evs = _tb_evs.get('eval_start_date')
    if isinstance(_evs, str) and _evs.strip():
        cfg.EVAL_START_DATE = _evs.strip()
    dt_hours_value = file_cfg.get('dt_hours') or file_cfg.get('DT_HOURS')
    if dt_hours_value is None and isinstance(file_cfg, dict):
        time_block = file_cfg.get('time')
        if isinstance(time_block, dict):
            dt_hours_value = time_block.get('dt_hours') or time_block.get('time_step_hours') or time_block.get('DT_HOURS')
    if dt_hours_value is None:
        raise ValueError("[CRITICAL] run_config 缺少时间步长 dt_hours，请在配置的 time 段落中显式设置 dt_hours。")
    cfg.set_time_step_hours(dt_hours_value)

    # data paths
    if 'meteo_file' in file_cfg:
        cfg.set_meteo_file(file_cfg['meteo_file'])
    if 'data_dir' in file_cfg:
        data_dir = Path(file_cfg['data_dir'])
        if not data_dir.is_absolute():
            data_dir = cfg.PROJECT_ROOT / data_dir
        cfg.DATA_DIR = data_dir
    # Update: Map obs_discharge_file
    if 'obs_discharge_file' in file_cfg:
        cfg.OBS_DISCHARGE_FILE = file_cfg['obs_discharge_file']

    if 'basin_name' in file_cfg:
        cfg.BASIN_NAME = file_cfg['basin_name']

    # 新增: 提取 msk_segmented
    model_block = file_cfg.get('model')
    if isinstance(model_block, dict) and 'msk_segmented' in model_block:
        cfg.MSK_SEGMENTED = bool(model_block['msk_segmented'])

    # 若存在内联模型配置，注入到 cfg
    if file_cfg.get('_INLINE_TOPOLOGY') is not None:
        setattr(cfg, 'INLINE_TOPOLOGY', file_cfg.get('_INLINE_TOPOLOGY'))
    if file_cfg.get('_INLINE_CALIB') is not None:
        setattr(cfg, 'INLINE_CALIB', file_cfg.get('_INLINE_CALIB'))
    if file_cfg.get('_INLINE_PDD_XAJ') is not None:
        setattr(cfg, 'INLINE_PDD_XAJ', file_cfg.get('_INLINE_PDD_XAJ'))
    if file_cfg.get('_INLINE_INITIAL_CONDITIONS') is not None:
        setattr(cfg, 'INLINE_INITIAL_CONDITIONS', file_cfg.get('_INLINE_INITIAL_CONDITIONS'))

    # 摘要
    _summarize_config(cfg)
    if _LAST_RUN_CONFIG_PATH:
        orig_print(f'[RUNCFG] active_file={_LAST_RUN_CONFIG_PATH}')

    best_params, best_score = run_optimization_eval(cfg)
    return best_params, best_score
