"""Core parameter preparation utilities for semi-distributed optimization."""

from __future__ import annotations

from typing import Any, Dict, Tuple

import numpy as np


def prepare_initial_state(initial_conditions: Dict[str, Any], Ng: int, enable_snowmelt: bool = False) -> np.ndarray:
    """Placeholder for compatibility; actual implementation resides upstream.

    This module mirrors the legacy API; when migrating full logic, the implementation
    should be moved here.
    """

    raise NotImplementedError("prepare_initial_state should be provided by upstream modules.")


__all__ = ["prepare_initial_state"]


