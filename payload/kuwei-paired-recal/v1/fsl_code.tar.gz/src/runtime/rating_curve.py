"""Rating curve Q→H conversion.

Fits a power-law relationship H = a * Q^b + c from paired
observed discharge (Q) and stage (H) data.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np


@dataclass
class RatingCurve:
    """Power-law rating curve: H = a * Q^b + c."""

    a: float
    b: float
    c: float
    station_id: str = ""
    r2: float = float("nan")
    rmse: float = float("nan")
    n_samples: int = 0

    # ------------------------------------------------------------------
    # Apply
    # ------------------------------------------------------------------

    def apply(self, q: np.ndarray) -> np.ndarray:
        """Convert discharge Q (m³/s) to stage H (m).

        Clips Q to >= 0 before conversion. Returns NaN for NaN inputs.
        """
        q_arr = np.asarray(q, dtype=np.float64)
        q_safe = np.clip(q_arr, 0.0, None)
        h = self.a * np.power(q_safe, self.b) + self.c
        h = np.where(np.isfinite(q_arr), h, np.nan)
        return h

    # ------------------------------------------------------------------
    # Fit
    # ------------------------------------------------------------------

    @classmethod
    def fit(cls, q: np.ndarray, h: np.ndarray, station_id: str = "") -> "RatingCurve":
        """Fit rating curve from paired Q-H observations.

        Uses scipy.optimize.curve_fit with power-law model.

        Args:
            q: Observed discharge (m³/s), 1-D.
            h: Observed stage (m), 1-D, same length as q.
            station_id: Optional station identifier.

        Returns:
            Fitted RatingCurve instance.

        Raises:
            ValueError: If input arrays are too short or fitting fails.
        """
        from scipy.optimize import curve_fit

        q_arr = np.asarray(q, dtype=np.float64).ravel()
        h_arr = np.asarray(h, dtype=np.float64).ravel()

        # Drop NaN / invalid pairs
        mask = np.isfinite(q_arr) & np.isfinite(h_arr) & (q_arr > 0)
        q_clean = q_arr[mask]
        h_clean = h_arr[mask]

        if len(q_clean) < 10:
            raise ValueError(f"Need >= 10 valid Q-H pairs, got {len(q_clean)}")

        def _power_law(q_val, a, b, c):
            return a * np.power(q_val, b) + c

        # Initial guess: rough linear relationship
        p0 = [1.0, 0.5, float(np.min(h_clean))]
        try:
            popt, _ = curve_fit(
                _power_law, q_clean, h_clean,
                p0=p0, maxfev=10000,
            )
        except RuntimeError as exc:
            raise ValueError(f"Rating curve fitting failed: {exc}") from exc

        a_fit, b_fit, c_fit = popt
        h_pred = _power_law(q_clean, a_fit, b_fit, c_fit)
        ss_res = np.sum((h_clean - h_pred) ** 2)
        ss_tot = np.sum((h_clean - np.mean(h_clean)) ** 2)
        r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else float("nan")
        rmse = float(np.sqrt(np.mean((h_clean - h_pred) ** 2)))

        return cls(
            a=float(a_fit),
            b=float(b_fit),
            c=float(c_fit),
            station_id=station_id,
            r2=float(r2),
            rmse=rmse,
            n_samples=int(len(q_clean)),
        )

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        return {
            "station_id": self.station_id,
            "model": "power_law",
            "params": {"a": self.a, "b": self.b, "c": self.c},
            "fit_metrics": {
                "r2": self.r2,
                "rmse": self.rmse,
                "n_samples": self.n_samples,
            },
        }

    def save_yaml(self, path: Path) -> None:
        import yaml

        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            yaml.dump(self.to_dict(), f, default_flow_style=False, allow_unicode=True)

    @classmethod
    def from_dict(cls, data: dict) -> "RatingCurve":
        params = data.get("params", {})
        metrics = data.get("fit_metrics", {})
        return cls(
            a=float(params["a"]),
            b=float(params["b"]),
            c=float(params["c"]),
            station_id=str(data.get("station_id", "")),
            r2=float(metrics.get("r2", float("nan"))),
            rmse=float(metrics.get("rmse", float("nan"))),
            n_samples=int(metrics.get("n_samples", 0)),
        )

    @classmethod
    def load_yaml(cls, path: Path) -> "RatingCurve":
        import yaml

        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Rating curve file not found: {path}")
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        return cls.from_dict(data)
