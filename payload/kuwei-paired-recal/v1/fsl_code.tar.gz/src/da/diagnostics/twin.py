"""Twin experiment harness for DA diagnostic validation.

Generates synthetic truth from a known model, then runs DA with
diagnostic collection to validate L1/L3/L6 diagnostics.

Scenario A: correct structure, wrong parameters → DA should recover
Scenario B: wrong structure (missing process) → DA alarms
"""

from __future__ import annotations

import copy
from typing import Any, Callable, Dict, Optional, Tuple

import numpy as np

from src.da.diagnostics.collector import DiagnosticBundle, DiagnosticCollector


def generate_synthetic_truth(
    model_step: Callable,
    forcings: np.ndarray,
    x0: np.ndarray,
    obs_noise_std: float = 0.05,
    rng_seed: int = 42,
    process_noise_std: Optional[np.ndarray] = None,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Generate synthetic observations from a known model.

    Args:
        model_step: callable(x, forcing) → (x_new, q_scalar)
        forcings: (T,) or (T, ...) forcing sequence
        x0: (dim_x,) initial state
        obs_noise_std: absolute observation noise std
        rng_seed: random seed for reproducibility
        process_noise_std: (dim_x,) per-state process noise std.
            If provided, adds Gaussian noise to states at each step,
            simulating unmodeled fast processes (used for Scenario C).

    Returns:
        q_truth: (T,) true discharge
        q_noisy: (T,) noisy observations
        x_truth: (T, dim_x) true state trajectory
    """
    rng = np.random.RandomState(rng_seed)
    T = len(forcings)
    dim_x = len(x0)

    q_truth = np.zeros(T)
    x_truth = np.zeros((T, dim_x))
    x = x0.copy()

    for t in range(T):
        f_t = forcings[t] if forcings.ndim == 1 else forcings[t]
        x, q = model_step(x, f_t)
        if process_noise_std is not None:
            x = x + rng.randn(dim_x) * process_noise_std
            # Ensure non-negative states (stores, UH ordinates, discharge)
            x = np.maximum(x, 0.0)
        x_truth[t] = x
        q_truth[t] = q

    noise = rng.randn(T) * obs_noise_std
    q_noisy = q_truth + noise

    return q_truth, q_noisy, x_truth


def setup_scenario_a(
    model_true: Any,
    perturbation: float = 0.3,
    rng_seed: int = 123,
) -> Dict[str, Any]:
    """Scenario A: correct structure, wrong parameters.

    Perturbs the model's A matrix by ±perturbation fraction.
    DA should recover states; L1 pass; L3/L6 show correction.

    Args:
        model_true: model object with .A attribute (matrix)
        perturbation: fractional perturbation magnitude
        rng_seed: random seed

    Returns dict with model_wrong, A_wrong, description.
    """
    rng = np.random.RandomState(rng_seed)
    A_true = np.array(model_true.A, dtype=float)
    noise = rng.uniform(-perturbation, perturbation, size=A_true.shape)
    A_wrong = A_true * (1.0 + noise)

    # Ensure stability: rescale if spectral radius >= 1
    eigvals = np.linalg.eigvals(A_wrong)
    rho = np.max(np.abs(eigvals))
    if rho >= 0.99:
        A_wrong *= 0.98 / rho

    model_wrong = copy.deepcopy(model_true)
    model_wrong.A = A_wrong

    return {
        "model_wrong": model_wrong,
        "A_wrong": A_wrong,
        "perturbation": perturbation,
        "description": f"Scenario A: parameters perturbed by ±{perturbation*100:.0f}%",
    }


def setup_scenario_b(
    model_true: Any,
) -> Dict[str, Any]:
    """Scenario B: structural error — remove interflow (2nd state pathway).

    Zeroes out the second row/column coupling in A, simulating
    a model missing a key process (e.g., no interflow QI).

    Args:
        model_true: model object with .A attribute

    Returns dict with model_wrong, structural_change, description.
    """
    model_wrong = copy.deepcopy(model_true)
    A_wrong = np.array(model_wrong.A, dtype=float)

    # Zero out inter-state coupling for state 1 (interflow proxy)
    original_row = A_wrong[1, :].copy()
    A_wrong[1, :] = 0.0
    A_wrong[1, 1] = 0.5  # keep self-decay but remove all coupling
    A_wrong[:, 1] = 0.0
    A_wrong[1, 1] = 0.5
    model_wrong.A = A_wrong

    return {
        "model_wrong": model_wrong,
        "structural_change": f"Zeroed state-1 coupling (original row: {original_row})",
        "description": "Scenario B: structural error — interflow pathway removed",
    }


def run_twin_da(
    model_step: Callable,
    hx: Callable,
    forcings: np.ndarray,
    qobs: np.ndarray,
    x0: np.ndarray,
    dim_x: int,
    P0: np.ndarray,
    Q: np.ndarray,
    R: np.ndarray,
) -> Dict[str, Any]:
    """Run a simple DA loop with diagnostic collection.

    Uses a basic Kalman-like update (EKF-style) for the twin experiment.
    This avoids depending on the full UKF/filter infrastructure, making
    the twin experiment self-contained and testable.

    Args:
        model_step: callable(x, forcing) → (x_new, q_scalar)
        hx: observation function, callable(x) → (dim_z,) array
        forcings: (T,) forcing sequence
        qobs: (T,) noisy observations
        x0: (dim_x,) initial state
        dim_x: state dimension
        P0, Q, R: covariance matrices

    Returns dict with diagnostics (DiagnosticBundle), x_analysis, y_preds.
    """
    T = len(qobs)
    dim_z = R.shape[0]

    # Initialize
    x = x0.copy().astype(float)
    P = P0.copy().astype(float)

    collector = DiagnosticCollector(steps=T, dim_x=dim_x, dim_z=dim_z)
    x_analysis = np.zeros((T, dim_x))
    y_preds = np.zeros(T)

    for t in range(T):
        # Predict
        f_t = forcings[t] if forcings.ndim == 1 else forcings[t]
        x_pred, _ = model_step(x, f_t)

        # State transition Jacobian F via numerical perturbation
        eps_f = 1e-5
        F = np.zeros((dim_x, dim_x))
        for j in range(dim_x):
            x_pert_f = x.copy()
            x_pert_f[j] += eps_f
            x_pred_pert, _ = model_step(x_pert_f, f_t)
            F[:, j] = (x_pred_pert - x_pred) / eps_f

        P_pred = F @ P @ F.T + Q

        x_prior = x_pred.copy()

        # Observation Jacobian via numerical perturbation
        eps = 1e-5
        h0 = np.asarray(hx(x_pred)).ravel()
        H = np.zeros((dim_z, dim_x))
        for j in range(dim_x):
            x_pert = x_pred.copy()
            x_pert[j] += eps
            h_pert = np.asarray(hx(x_pert)).ravel()
            H[:, j] = (h_pert - h0) / eps

        # Innovation
        z = np.array([qobs[t]]) if dim_z == 1 else qobs[t]
        y_innov = z - h0

        # Innovation covariance
        S = H @ P_pred @ H.T + R

        # Kalman gain
        K = P_pred @ H.T @ np.linalg.inv(S)

        # Update
        x = x_pred + (K @ y_innov).ravel()
        P = (np.eye(dim_x) - K @ H) @ P_pred

        # Store
        x_analysis[t] = x
        y_preds[t] = float(np.asarray(hx(x)).ravel()[0])

        # Collect diagnostics using a SimpleNamespace to mimic filter
        from types import SimpleNamespace
        filt_mock = SimpleNamespace(K=K, y=y_innov, S=S, P=P)
        collector.collect(t, filt_mock, H, x_prior=x_prior, x_post=x.copy())

    return {
        "diagnostics": collector.finalize(),
        "x_analysis": x_analysis,
        "y_preds": y_preds,
    }
