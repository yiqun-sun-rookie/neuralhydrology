"""Publication-quality diagnostic visualization for DA framework.

Generates four key figures:
  Fig 1: NIS time series + chi2 bounds (L1)
  Fig 2: DFS bar chart by state type (L3)
  Fig 3: FSOI heatmap: state type × scenario (L6)
  Fig 4: Twin experiment scoreboard
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional

import numpy as np


def plot_nis_timeseries(
    nis: np.ndarray,
    dim_z: int = 1,
    alpha: float = 0.05,
    title: str = "NIS Time Series",
    save_path: Optional[Path] = None,
) -> None:
    """Plot NIS with chi-squared confidence bounds.

    Fig 1 for the paper: shows filter consistency over time.
    """
    import matplotlib.pyplot as plt
    from scipy import stats

    T = len(nis)
    ci_lower = stats.chi2.ppf(alpha / 2, df=dim_z)
    ci_upper = stats.chi2.ppf(1 - alpha / 2, df=dim_z)

    fig, ax = plt.subplots(figsize=(10, 3.5))
    ax.plot(nis, "k-", alpha=0.5, linewidth=0.5, label="NIS")

    # Rolling mean
    window = min(50, T // 5)
    if window > 1:
        rolling = np.convolve(nis, np.ones(window) / window, mode="valid")
        ax.plot(
            np.arange(window - 1, T), rolling,
            "b-", linewidth=1.5, label=f"Rolling mean (w={window})",
        )

    ax.axhline(dim_z, color="g", linestyle="--", linewidth=1, label=f"E[NIS]={dim_z}")
    ax.axhline(ci_lower, color="r", linestyle=":", linewidth=0.8,
               label=f"{(1-alpha)*100:.0f}% CI")
    ax.axhline(ci_upper, color="r", linestyle=":", linewidth=0.8)
    ax.fill_between([0, T], ci_lower, ci_upper, alpha=0.08, color="green")

    ax.set_xlabel("Time step")
    ax.set_ylabel("NIS")
    ax.set_title(title)
    ax.legend(loc="upper right", fontsize=8)
    ax.set_xlim(0, T)
    fig.tight_layout()

    if save_path:
        save_path = Path(save_path)
        save_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=200, bbox_inches="tight")
    plt.close(fig)


def plot_dfs_bar(
    dfs_mean: np.ndarray,
    state_names: List[str],
    title: str = "DFS per State Type",
    save_path: Optional[Path] = None,
) -> None:
    """Bar chart of time-averaged DFS per state.

    Fig 2 for the paper: key figure showing observability decomposition.
    """
    import matplotlib.pyplot as plt

    n = len(state_names)
    colors = []
    for d in dfs_mean:
        if d >= 0.1:
            colors.append("#2ca02c")  # green: observable
        elif d >= 0.01:
            colors.append("#ff7f0e")  # orange: marginal
        else:
            colors.append("#d62728")  # red: unobservable

    fig, ax = plt.subplots(figsize=(8, 4))
    bars = ax.bar(range(n), dfs_mean, color=colors, edgecolor="black", linewidth=0.5)

    ax.set_xticks(range(n))
    ax.set_xticklabels(state_names, rotation=45, ha="right")
    ax.set_ylabel("DFS (time-averaged)")
    ax.set_title(title)
    ax.axhline(0.01, color="gray", linestyle=":", linewidth=0.8, label="Threshold")

    # Add value labels
    for bar, val in zip(bars, dfs_mean):
        ax.text(
            bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.002,
            f"{val:.3f}", ha="center", va="bottom", fontsize=7,
        )

    ax.legend(fontsize=8)
    fig.tight_layout()

    if save_path:
        save_path = Path(save_path)
        save_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=200, bbox_inches="tight")
    plt.close(fig)


def plot_vr_bar(
    vr_mean: np.ndarray,
    state_names: List[str],
    title: str = "Variance Reduction per State",
    save_path: Optional[Path] = None,
) -> None:
    """Bar chart of time-averaged Variance Reduction per state.

    Complements DFS: shows UKF's actual correction including indirect
    cross-correlation effects that DFS (= K @ H) misses.
    """
    import matplotlib.pyplot as plt

    n = len(state_names)
    colors = []
    for v in vr_mean:
        if v >= 0.1:
            colors.append("#2ca02c")   # green: well-corrected
        elif v >= 0.01:
            colors.append("#ff7f0e")   # orange: weakly corrected
        else:
            colors.append("#d62728")   # red: uncorrected

    fig, ax = plt.subplots(figsize=(8, 4))
    bars = ax.bar(range(n), vr_mean, color=colors, edgecolor="black", linewidth=0.5)

    ax.set_xticks(range(n))
    ax.set_xticklabels(state_names, rotation=45, ha="right")
    ax.set_ylabel("VR (time-averaged)")
    ax.set_ylim(0, min(1.0, max(vr_mean) * 1.3 + 0.05))
    ax.set_title(title)

    for bar, val in zip(bars, vr_mean):
        ax.text(
            bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.002,
            f"{val:.4f}", ha="center", va="bottom", fontsize=7,
        )

    fig.tight_layout()

    if save_path:
        save_path = Path(save_path)
        save_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=200, bbox_inches="tight")
    plt.close(fig)


def plot_fsoi_heatmap(
    mean_fsoi: np.ndarray,
    beneficial_frac: np.ndarray,
    state_names: List[str],
    title: str = "FSOI by State Type",
    save_path: Optional[Path] = None,
) -> None:
    """Heatmap of FSOI impact by state type.

    Fig 3 for the paper: core novelty figure.
    Negative (blue) = beneficial, Positive (red) = harmful.
    """
    import matplotlib.pyplot as plt

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4), gridspec_kw={"width_ratios": [3, 2]})

    n = len(state_names)

    # Left: mean FSOI bar chart
    colors = ["#2166ac" if f < 0 else "#b2182b" for f in mean_fsoi]
    ax1.barh(range(n), mean_fsoi, color=colors, edgecolor="black", linewidth=0.5)
    ax1.set_yticks(range(n))
    ax1.set_yticklabels(state_names)
    ax1.axvline(0, color="black", linewidth=0.8)
    ax1.set_xlabel("Mean FSOI")
    ax1.set_title("Impact (negative = beneficial)")
    ax1.invert_yaxis()

    # Right: beneficial fraction
    ax2.barh(range(n), beneficial_frac, color="#4daf4a", edgecolor="black", linewidth=0.5)
    ax2.set_yticks(range(n))
    ax2.set_yticklabels([])
    ax2.set_xlim(0, 1)
    ax2.axvline(0.5, color="gray", linestyle=":", linewidth=0.8)
    ax2.set_xlabel("Beneficial fraction")
    ax2.set_title("Fraction of cycles (FSOI < 0)")
    ax2.invert_yaxis()

    fig.suptitle(title, fontsize=12)
    fig.tight_layout()

    if save_path:
        save_path = Path(save_path)
        save_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=200, bbox_inches="tight")
    plt.close(fig)


def plot_twin_scoreboard(
    results_a: Dict,
    results_b: Dict,
    state_names: List[str],
    title: str = "Twin Experiment Diagnostic Scoreboard",
    save_path: Optional[Path] = None,
) -> None:
    """Comparison table figure: Scenario A vs Scenario B.

    Fig 4 for the paper: shows diagnostic discriminability.
    """
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.axis("off")

    rows = [
        ["L1: NIS mean",
         f"{results_a['nis_result']['mean_nis']:.3f}",
         f"{results_b['nis_result']['mean_nis']:.3f}"],
        ["L1: NIS pass",
         str(results_a["nis_result"]["pass_flag"]),
         str(results_b["nis_result"]["pass_flag"])],
        ["L1: Desroziers",
         results_a["desroziers"]["diagnostic_flag"],
         results_b["desroziers"]["diagnostic_flag"]],
    ]

    # DFS per state
    for i, name in enumerate(state_names):
        dfs_a = results_a["dfs"]["dfs_mean"][i]
        dfs_b = results_b["dfs"]["dfs_mean"][i]
        rows.append([f"L3: DFS {name}", f"{dfs_a:.4f}", f"{dfs_b:.4f}"])

    col_labels = ["Diagnostic", "Scenario A\n(param error)", "Scenario B\n(structural error)"]

    table = ax.table(
        cellText=rows,
        colLabels=col_labels,
        loc="center",
        cellLoc="center",
    )
    table.auto_set_font_size(False)
    table.set_fontsize(9)
    table.scale(1, 1.5)

    # Color header
    for j in range(3):
        table[0, j].set_facecolor("#d4e6f1")

    # Color NIS pass/fail
    for row_idx, row in enumerate(rows, start=1):
        if "pass" in row[0].lower():
            for col in [1, 2]:
                cell = table[row_idx, col]
                if row[col] == "True":
                    cell.set_facecolor("#d5f5e3")
                else:
                    cell.set_facecolor("#fadbd8")

    ax.set_title(title, fontsize=12, pad=20)
    fig.tight_layout()

    if save_path:
        save_path = Path(save_path)
        save_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=200, bbox_inches="tight")
    plt.close(fig)
