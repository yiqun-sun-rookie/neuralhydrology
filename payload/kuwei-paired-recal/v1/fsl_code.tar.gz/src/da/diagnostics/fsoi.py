"""L6 FSOI — Forecast Sensitivity to Observation Impact.

Adapted from Langland & Baker (2004) for conceptual hydrology.

For each DA cycle at time t:
  1. dx_t = x_a - x_b  (analysis increment)
  2. Forecast from x_a for k steps → q_f(t+k)
  3. J = (q_f(t+k) - q_obs(t+k))^2
  4. dJ/d(dx_t) via PyTorch autograd (adjoint of k-step model)
  5. FSOI_i(t) = (dJ/d(dx_i)) * dx_i

If FSOI_i > 0: correcting state i worsened the forecast.
If FSOI_i < 0: correcting state i improved the forecast.
"""

from __future__ import annotations

from typing import Callable, Dict, List, Optional

import numpy as np
import torch

STATE_NAMES_11 = [
    "snow_depth", "ice_depth", "last_temp", "W",
    "WU", "WL", "WD", "S", "QS", "QI", "QG",
]


def compute_fsoi_from_states(
    x_prior: np.ndarray,
    x_post: np.ndarray,
    forcings_seq: np.ndarray,
    qobs: np.ndarray,
    model_step_fn: Callable,
    n_units: int,
    lead_time: int = 6,
) -> Dict[str, np.ndarray]:
    """Compute per-state FSOI using PyTorch autograd.

    This is a model-agnostic version that works with any differentiable
    step function accepting (state_tensor, forcing_tensor) → (new_state, q).

    Args:
        x_prior: (T, n_units, dim_state) background states
        x_post: (T, n_units, dim_state) analysis states
        forcings_seq: (T, n_units) forcing values per step (e.g., rain)
        qobs: (T,) observations
        model_step_fn: callable(state, forcing) → (new_state, q_scalar)
            state: (n_units, dim_state) tensor
            forcing: (n_units,) tensor
        n_units: number of grid units
        lead_time: k-step forecast horizon

    Returns:
        fsoi_per_state: (T_valid, n_units * dim_state) per-state FSOI
        fsoi_total: (T_valid,) total FSOI per cycle
    """
    T = x_prior.shape[0]
    dim_state = x_prior.shape[2]
    total_state_dim = n_units * dim_state
    T_valid = T - lead_time

    if T_valid <= 0:
        return {
            "fsoi_per_state": np.zeros((0, total_state_dim)),
            "fsoi_total": np.zeros(0),
        }

    fsoi_per_state = np.zeros((T_valid, total_state_dim))
    fsoi_total = np.zeros(T_valid)

    for t in range(T_valid):
        t_verify = t + lead_time
        if t_verify >= T:
            break

        # Analysis increment
        dx = x_post[t] - x_prior[t]  # (n_units, dim_state)
        dx_flat = dx.ravel()  # (n_units * dim_state,)

        # Skip if no correction
        if np.abs(dx_flat).max() < 1e-15:
            continue

        # Set up PyTorch state with grad tracking
        state_t = torch.tensor(
            x_post[t], dtype=torch.float64, requires_grad=True,
        )

        # Forward k steps
        state_cur = state_t
        for k in range(lead_time):
            forcing_k = torch.tensor(
                forcings_seq[t + k], dtype=torch.float64,
            )
            state_cur, q_k = model_step_fn(state_cur, forcing_k)

        # Forecast error: J = (q_f - q_obs)^2
        q_forecast = q_k.sum()  # sum over units for outlet Q
        q_obs_val = float(qobs[t_verify])
        J = (q_forecast - q_obs_val) ** 2

        # Backprop to get dJ/d(state_t)
        J.backward()

        if state_t.grad is not None:
            grad = state_t.grad.detach().numpy().ravel()  # (n_units * dim_state,)
            # FSOI_i = dJ/d(dx_i) * dx_i
            fsoi_t = grad * dx_flat
            # Replace NaN/Inf from numerical issues (e.g., snow in tropical basins)
            fsoi_t = np.where(np.isfinite(fsoi_t), fsoi_t, 0.0)
            fsoi_per_state[t] = fsoi_t
            fsoi_total[t] = fsoi_t.sum()

    return {
        "fsoi_per_state": fsoi_per_state,
        "fsoi_total": fsoi_total,
    }


def aggregate_fsoi_by_state_type(
    fsoi_per_state: np.ndarray,
    n_units: int,
    n_state_per_unit: int = 11,
) -> Dict[str, np.ndarray]:
    """Aggregate FSOI to state types (e.g., snow, WU, QS, ...).

    Reshapes (T, n_units * n_state) → (T, n_units, n_state) → mean over units.

    Args:
        fsoi_per_state: (T_valid, n_units * n_state_per_unit)
        n_units: number of grid units
        n_state_per_unit: states per unit (default 11 for XAJ)

    Returns:
        mean_fsoi: (n_state,) average impact per state type
        beneficial_frac: (n_state,) fraction of cycles where correction helped
        cumulative_impact: (n_state,) sum over all cycles
        state_names: list of state type names
    """
    T_valid = fsoi_per_state.shape[0]

    # Reshape: (T, n_units * n_state) → (T, n_units, n_state)
    reshaped = fsoi_per_state.reshape(T_valid, n_units, n_state_per_unit)

    # Average over units → (T, n_state)
    per_type = reshaped.mean(axis=1)

    mean_fsoi = np.nanmean(per_type, axis=0)
    cumulative_impact = np.nansum(per_type, axis=0)

    # Beneficial = FSOI < 0 (correction reduced forecast error)
    beneficial_frac = np.nanmean(per_type < 0, axis=0)

    names = STATE_NAMES_11[:n_state_per_unit]

    return {
        "mean_fsoi": mean_fsoi,
        "beneficial_frac": beneficial_frac,
        "cumulative_impact": cumulative_impact,
        "state_names": names,
    }
