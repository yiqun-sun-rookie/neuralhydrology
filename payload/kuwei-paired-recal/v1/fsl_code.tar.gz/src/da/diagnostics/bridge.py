"""Numba flat state vector ↔ PyTorch tensor converter for FSOI.

The DA system uses a flat NumPy vector (Numba-compatible) while FSOI
needs PyTorch tensors with grad tracking for adjoint computation.
"""

from __future__ import annotations

from typing import Dict, List, Tuple

import numpy as np
import torch


def numba_state_to_pytorch(
    x_flat: np.ndarray,
    flatten_spec: Dict,
    n_units: int,
) -> Tuple[torch.Tensor, List[torch.Tensor]]:
    """Convert Numba flat state vector to PyTorch tensors.

    Args:
        x_flat: (dim_x,) flat state from DA filter
        flatten_spec: from handles_factory — 'order', 'shapes', 'slices'
        n_units: number of hydrological computation units

    Returns:
        units_state: (n_units, 11) torch tensor with requires_grad=True
        msk_states: list of torch tensors for Muskingum routing states
    """
    # Extract unit states
    s, e = flatten_spec["slices"]["units"]
    units_shape = flatten_spec["shapes"]["units"]
    units_np = x_flat[s:e].reshape(units_shape)
    units_torch = torch.tensor(
        units_np, dtype=torch.float64, requires_grad=True,
    )

    # Extract Muskingum states
    msk_states = []
    for key in flatten_spec["order"]:
        if key.startswith("msk_"):
            s, e = flatten_spec["slices"][key]
            shape = flatten_spec["shapes"][key]
            msk_np = x_flat[s:e].reshape(shape)
            msk_states.append(
                torch.tensor(msk_np, dtype=torch.float64, requires_grad=True)
            )

    return units_torch, msk_states
