"""L3 observability analysis — Degrees of Freedom for Signal (DFS).

DFS = trace(K @ H) measures how much each state is corrected by observations.
Per-state decomposition: DFS_i = (K @ H)_{ii}
"""

from __future__ import annotations

from typing import Dict, List

import numpy as np

from src.da.diagnostics.collector import DiagnosticBundle


def compute_dfs(bundle: DiagnosticBundle) -> Dict[str, np.ndarray]:
    """Degrees of Freedom for Signal, decomposed per state.

    DFS_total = trace(K @ H)
    DFS_i     = (K @ H)_{ii}

    Returns:
        dfs_total: (T,) total DFS per timestep
        dfs_per_state: (T, dim_x) per-state DFS
        dfs_mean: (dim_x,) time-averaged DFS per state
    """
    # K: (T, dim_x, dim_z), H: (T, dim_z, dim_x)
    # KH: (T, dim_x, dim_x)
    KH = np.einsum("tij,tjk->tik", bundle.K, bundle.H)

    dfs_per_state = np.diagonal(KH, axis1=1, axis2=2)  # (T, dim_x)
    dfs_total = dfs_per_state.sum(axis=1)               # (T,)

    return {
        "dfs_total": dfs_total,
        "dfs_per_state": dfs_per_state,
        "dfs_mean": np.nanmean(dfs_per_state, axis=0),
    }


def compute_variance_reduction(bundle: DiagnosticBundle) -> Dict[str, np.ndarray]:
    """Variance Reduction (VR) per state — complementary to DFS for UKF.

    VR_i = 1 - P_post[i,i] / P_pred[i,i]

    Unlike DFS (= K @ H), VR captures *indirect* correction of states
    through UKF cross-correlations even when H is zero.

    Returns:
        vr_per_state: (T, dim_x) per-state VR
        vr_total: (T,) total VR per timestep (sum across states)
        vr_mean: (dim_x,) time-averaged VR
    """
    if bundle.P_pred_diag is None:
        raise ValueError(
            "P_pred_diag not collected. Re-run DA with collect_diagnostics=True "
            "using fh.py >= 2026-03-05 which captures predicted covariance."
        )
    P_post_diag = np.diagonal(bundle.P, axis1=1, axis2=2)  # (T, dim_x)
    P_pred_diag = bundle.P_pred_diag                        # (T, dim_x)

    eps = 1e-30
    vr = 1.0 - P_post_diag / np.maximum(P_pred_diag, eps)
    # Clamp to [0, 1]: VR < 0 shouldn't happen; VR > 1 means numerical noise
    vr = np.clip(vr, 0.0, 1.0)
    if bundle.observed_mask is not None:
        vr[~np.asarray(bundle.observed_mask, dtype=bool)] = np.nan

    return {
        "vr_per_state": vr,
        "vr_total": np.nansum(vr, axis=1),
        "vr_mean": np.nanmean(vr, axis=0),
    }


def dfs_recommendation(
    dfs_mean: np.ndarray,
    state_names: List[str],
    threshold: float = 0.01,
) -> Dict[str, List[str]]:
    """Classify states by observability based on time-averaged DFS.

    Categories:
        observable:    DFS_i >= 10 * threshold
        marginal:      threshold <= DFS_i < 10 * threshold
        unobservable:  DFS_i < threshold

    Unobservable states → recommend Q_ii = 0 to avoid noise injection.

    Returns dict with keys: observable, marginal, unobservable (lists of names).
    """
    observable = []
    marginal = []
    unobservable = []

    for i, name in enumerate(state_names):
        d = dfs_mean[i]
        if d >= 10 * threshold:
            observable.append(name)
        elif d >= threshold:
            marginal.append(name)
        else:
            unobservable.append(name)

    return {
        "observable": observable,
        "marginal": marginal,
        "unobservable": unobservable,
    }
