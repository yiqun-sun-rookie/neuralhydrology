"""Per-timestep diagnostic data collection from DA filters."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np


@dataclass
class DiagnosticBundle:
    """Per-timestep diagnostic data collected from a DA filter run.

    All arrays have time as the first axis (T, ...).
    """

    K: np.ndarray          # (T, dim_x, dim_z) Kalman gain
    y: np.ndarray          # (T, dim_z)        innovation (residual)
    S: np.ndarray          # (T, dim_z, dim_z) innovation covariance
    H: np.ndarray          # (T, dim_z, dim_x) observation Jacobian
    P: np.ndarray          # (T, dim_x, dim_x) posterior error covariance
    x_prior: np.ndarray    # (T, dim_x)        prior (background) state
    x_post: np.ndarray     # (T, dim_x)        posterior (analysis) state
    dim_x: int
    dim_z: int
    steps: int
    P_pred_diag: np.ndarray | None = None  # (T, dim_x) predicted cov diagonal
    observed_mask: np.ndarray | None = None  # (T,) true only when an observation update ran


class DiagnosticCollector:
    """Accumulates filter internals during a DA loop.

    Usage::

        coll = DiagnosticCollector(steps=T, dim_x=n, dim_z=m)
        for t in range(T):
            x_prior = filt.x.copy()
            filt.update(obs)
            coll.collect(t, filt, H_row, x_prior=x_prior, x_post=filt.x.copy())
        bundle = coll.finalize()
    """

    def __init__(self, steps: int, dim_x: int, dim_z: int) -> None:
        self._steps = steps
        self._dim_x = dim_x
        self._dim_z = dim_z

        self._K = np.full((steps, dim_x, dim_z), np.nan, dtype=float)
        self._y = np.full((steps, dim_z), np.nan, dtype=float)
        self._S = np.full((steps, dim_z, dim_z), np.nan, dtype=float)
        self._H = np.zeros((steps, dim_z, dim_x), dtype=float)
        self._P = np.zeros((steps, dim_x, dim_x), dtype=float)
        self._P_pred_diag = np.zeros((steps, dim_x), dtype=float)
        self._x_prior = np.zeros((steps, dim_x), dtype=float)
        self._x_post = np.zeros((steps, dim_x), dtype=float)
        self._observed_mask = np.zeros(steps, dtype=bool)

    def collect(
        self,
        t: int,
        filt: Any,
        H: np.ndarray,
        *,
        x_prior: np.ndarray,
        x_post: np.ndarray,
        P_pred_diag: np.ndarray | None = None,
        observation_used: bool = True,
    ) -> None:
        """Record diagnostic data for timestep *t*.

        Args:
            t: timestep index
            filt: filter object with K, y, S, P attributes
            H: observation Jacobian, shape (dim_z, dim_x)
            x_prior: state before update, shape (dim_x,)
            x_post: state after update, shape (dim_x,)
            P_pred_diag: diagonal of predicted covariance, shape (dim_x,).
                If None, zeros are stored.
        """
        P = np.asarray(getattr(filt, "P", np.zeros((self._dim_x, self._dim_x))))

        if observation_used:
            K = np.asarray(getattr(filt, "K", np.zeros((self._dim_x, self._dim_z))))
            y = np.asarray(getattr(filt, "y", np.zeros(self._dim_z)))
            S = np.asarray(getattr(filt, "S", np.zeros((self._dim_z, self._dim_z))))
            self._K[t] = K.reshape(self._dim_x, self._dim_z)
            self._y[t] = y.ravel()[: self._dim_z]
            self._S[t] = S.reshape(self._dim_z, self._dim_z)
        self._observed_mask[t] = observation_used
        self._H[t] = np.asarray(H).reshape(self._dim_z, self._dim_x)
        self._P[t] = P.reshape(self._dim_x, self._dim_x)
        if P_pred_diag is not None:
            self._P_pred_diag[t] = np.asarray(P_pred_diag).ravel()[: self._dim_x]
        self._x_prior[t] = np.asarray(x_prior).ravel()[: self._dim_x]
        self._x_post[t] = np.asarray(x_post).ravel()[: self._dim_x]

    def finalize(self) -> DiagnosticBundle:
        """Return an immutable bundle of all collected data."""
        return DiagnosticBundle(
            K=self._K.copy(),
            y=self._y.copy(),
            S=self._S.copy(),
            H=self._H.copy(),
            P=self._P.copy(),
            P_pred_diag=self._P_pred_diag.copy(),
            x_prior=self._x_prior.copy(),
            x_post=self._x_post.copy(),
            dim_x=self._dim_x,
            dim_z=self._dim_z,
            steps=self._steps,
            observed_mask=self._observed_mask.copy(),
        )
