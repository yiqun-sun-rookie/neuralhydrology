"""L1 statistical consistency diagnostics for DA filters.

Implements:
- NIS (Normalized Innovation Squared) with chi-squared test
- Innovation autocorrelation (ACF) with Ljung-Box test
- Desroziers diagnostic for R/B misspecification
"""

from __future__ import annotations

from typing import Dict

import numpy as np
from scipy import stats

from src.da.diagnostics.collector import DiagnosticBundle


def compute_nis(bundle: DiagnosticBundle) -> np.ndarray:
    """Normalized Innovation Squared time series.

    NIS_t = y_t^T @ S_t^{-1} @ y_t

    For a well-tuned filter, NIS ~ chi2(dim_z).

    Returns:
        nis: (T,) array of NIS values.
    """
    nis = np.full(bundle.steps, np.nan, dtype=float)
    observed_mask = (
        np.asarray(bundle.observed_mask, dtype=bool)
        if bundle.observed_mask is not None
        else np.ones(bundle.steps, dtype=bool)
    )
    for t in range(bundle.steps):
        y_t = bundle.y[t]  # (dim_z,)
        S_t = bundle.S[t]  # (dim_z, dim_z)
        if not observed_mask[t] or not (np.all(np.isfinite(y_t)) and np.all(np.isfinite(S_t))):
            continue
        nis[t] = float(y_t @ np.linalg.solve(S_t, y_t))
    return nis


def nis_test(
    nis: np.ndarray,
    dim_z: int,
    alpha: float = 0.05,
) -> Dict:
    """Chi-squared consistency test on NIS.

    Under a well-tuned filter, mean(NIS) ≈ dim_z.

    Returns dict with:
        mean_nis: sample mean
        expected: dim_z
        p_value: two-sided test p-value
        pass_flag: True if consistent at level alpha
        ci_lower, ci_upper: confidence interval for mean NIS
    """
    nis = np.asarray(nis, dtype=float)
    nis = nis[np.isfinite(nis)]
    n = len(nis)
    if n == 0:
        raise ValueError("nis contains no finite observation-update values")
    mean_nis = float(np.mean(nis))

    # Under H0, sum(NIS) ~ chi2(n * dim_z).
    # Equivalently, mean(NIS) has E=dim_z, Var=2*dim_z/n (CLT).
    # Use chi2 CDF for the two-sided test on mean.
    expected = float(dim_z)
    se = np.sqrt(2.0 * dim_z / n)
    z_score = (mean_nis - expected) / se
    p_value = float(2.0 * (1.0 - stats.norm.cdf(abs(z_score))))

    ci_lower = expected - stats.norm.ppf(1 - alpha / 2) * se
    ci_upper = expected + stats.norm.ppf(1 - alpha / 2) * se

    return {
        "mean_nis": mean_nis,
        "expected": expected,
        "p_value": p_value,
        "pass_flag": p_value > alpha,
        "ci_lower": float(ci_lower),
        "ci_upper": float(ci_upper),
    }


def innovation_acf(
    bundle: DiagnosticBundle,
    max_lag: int = 20,
) -> Dict:
    """Innovation autocorrelation function.

    For a well-tuned filter, innovations should be white noise,
    so ACF ≈ 0 for lag > 0.

    Returns dict with:
        acf: (max_lag+1,) ACF values (lag 0 = 1.0)
        ljung_box_p: Ljung-Box test p-value (H0: white noise)
    """
    observed_mask = (
        np.asarray(bundle.observed_mask, dtype=bool)
        if bundle.observed_mask is not None
        else np.ones(bundle.steps, dtype=bool)
    )
    finite_mask = observed_mask & np.all(np.isfinite(bundle.y), axis=1) & np.all(
        np.isfinite(bundle.S), axis=(1, 2)
    )
    T = bundle.steps
    dim_z = bundle.dim_z
    if not np.any(finite_mask):
        raise ValueError("diagnostic bundle contains no finite observation updates")

    # Normalize innovations: y_norm_t = y_t / sqrt(diag(S_t))
    y_norm = np.full((T, dim_z), np.nan, dtype=float)
    for t in np.flatnonzero(finite_mask):
        s_diag = np.sqrt(np.diag(bundle.S[t]))
        s_diag = np.where(s_diag > 1e-12, s_diag, 1.0)
        y_norm[t] = bundle.y[t] / s_diag

    # Compute ACF on first observation dimension
    y_1d = y_norm[:, 0]
    valid = np.isfinite(y_1d)
    valid_count = int(valid.sum())
    mean = float(np.mean(y_1d[valid]))
    y_centered = y_1d - mean
    var = float(np.mean(y_centered[valid] ** 2))
    if var < 1e-15:
        return {"acf": np.zeros(max_lag + 1), "ljung_box_p": 1.0}

    acf = np.full(max_lag + 1, np.nan, dtype=float)
    pair_counts = np.zeros(max_lag + 1, dtype=int)
    for lag in range(max_lag + 1):
        if lag == 0:
            acf[lag] = 1.0
            pair_counts[lag] = valid_count
        else:
            if lag >= T:
                continue
            pairs = valid[: T - lag] & valid[lag:]
            pair_counts[lag] = int(pairs.sum())
            if pair_counts[lag] > 0:
                c = np.mean(y_centered[: T - lag][pairs] * y_centered[lag:][pairs])
                acf[lag] = c / var

    # Ljung-Box statistic: Q = T*(T+2) * sum(acf[k]^2 / (T-k)) for k=1..m
    valid_lags = np.flatnonzero(np.isfinite(acf[1:]) & (pair_counts[1:] > 0)) + 1
    if valid_lags.size > 0:
        q_stat = valid_count * (valid_count + 2) * np.sum(
            acf[valid_lags] ** 2 / pair_counts[valid_lags]
        )
        ljung_box_p = float(1.0 - stats.chi2.cdf(q_stat, df=int(valid_lags.size)))
    else:
        ljung_box_p = 1.0

    return {"acf": acf, "ljung_box_p": ljung_box_p}


def desroziers_diagnostic(
    bundle: DiagnosticBundle,
    qobs: np.ndarray,
) -> Dict:
    """Desroziers et al. (2005) consistency diagnostic.

    Estimates observation error covariance R from:
        R_est = E[d_a * d_b^T]
    where d_b = z - H @ x_b (background departure)
          d_a = z - H @ x_a (analysis departure)

    For dim_z=1 this simplifies to a scalar.

    Returns dict with:
        estimated_R: estimated observation error variance
        ratio: estimated_R / configured_R (should be ~1)
        diagnostic_flag: 'consistent' | 'R_too_small' | 'R_too_large'
    """
    qobs = np.asarray(qobs).ravel()
    T = min(bundle.steps, qobs.size)
    observed_mask = (
        np.asarray(bundle.observed_mask[:T], dtype=bool)
        if bundle.observed_mask is not None
        else np.ones(T, dtype=bool)
    )
    valid_mask = observed_mask & np.isfinite(qobs[:T]) & np.all(np.isfinite(bundle.S[:T]), axis=(1, 2))
    if not np.any(valid_mask):
        raise ValueError("diagnostic bundle contains no finite observation updates")

    # Compute background and analysis departures
    d_b = []
    d_a = []
    for t in np.flatnonzero(valid_mask):
        H_t = bundle.H[t]  # (dim_z, dim_x)
        z_t = qobs[t]
        hx_b = float((H_t @ bundle.x_prior[t]).ravel()[0])
        hx_a = float((H_t @ bundle.x_post[t]).ravel()[0])
        d_b.append(z_t - hx_b)
        d_a.append(z_t - hx_a)

    # R_est = E[d_a * d_b] (scalar for dim_z=1)
    estimated_R = float(np.mean(np.asarray(d_a) * np.asarray(d_b)))

    # Configured R from innovation covariance (approximate)
    # We use the mean diagonal of S minus mean H@P@H^T as configured R
    configured_R = float(np.mean(np.diagonal(bundle.S[:T][valid_mask], axis1=1, axis2=2)))

    ratio = estimated_R / configured_R if abs(configured_R) > 1e-15 else float("inf")

    if ratio < 0.5:
        flag = "R_too_large"
    elif ratio > 2.0:
        flag = "R_too_small"
    else:
        flag = "consistent"

    return {
        "estimated_R": estimated_R,
        "configured_R": configured_R,
        "ratio": ratio,
        "diagnostic_flag": flag,
    }
