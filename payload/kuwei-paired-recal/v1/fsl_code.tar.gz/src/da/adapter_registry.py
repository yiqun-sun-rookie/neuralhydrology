"""模型适配器 & 数据提供者的注册表 + 动态加载工具。

使用方式非常简单：

1. 常用适配器写入注册表::

       register_adapter("fh", FHModelAdapter)

   配置里只需要写 ``model: fh``。

2. 临时/外部适配器直接写模块路径::

       model: mypkg.mymodel:MyAdapter

   代码会自动通过 ``importlib`` 找到并实例化。
"""

from __future__ import annotations

import importlib
from typing import Dict, Optional, TypeVar

from .interfaces import (
    AdapterFactory,
    DataProvider,
    DataProviderFactory,
    ModelAdapter,
)


_ADAPTER_REGISTRY: Dict[str, AdapterFactory] = {}
_PROVIDER_REGISTRY: Dict[str, DataProviderFactory] = {}


_FactoryT = TypeVar("_FactoryT")


def register_adapter(name: str, factory: AdapterFactory) -> None:
    """注册模型适配器。

    :param name: 短名字（配置里会用到，例如 ``"fh"``）。
    :param factory: 可直接传入类或返回实例的函数。
    """

    _ADAPTER_REGISTRY[name] = factory


def register_data_provider(name: str, factory: DataProviderFactory) -> None:
    """注册数据提供者。"""

    _PROVIDER_REGISTRY[name] = factory


def _load_from_registry(name: str, registry: Dict[str, _FactoryT]) -> Optional[_FactoryT]:
    return registry.get(name)


def _load_class(path: str):
    if not path:
        raise ValueError("路径字符串不能为空")
    if ":" in path:
        module_path, attr = path.split(":", 1)
    else:
        module_path, attr = path.rsplit(".", 1)
    module = importlib.import_module(module_path)
    try:
        return getattr(module, attr)
    except AttributeError as exc:
        raise AttributeError(f"模块 {module_path!r} 中找不到对象 {attr!r}") from exc


def _wrap_if_class(target):
    if isinstance(target, type):
        return target  # 类本身即可视为 factory
    return target


def resolve_adapter(name_or_path: str) -> AdapterFactory:
    """返回模型适配器的构造函数/类。

    依次尝试：
    1. 注册表；
    2. 模块路径加载。
    """

    factory = _load_from_registry(name_or_path, _ADAPTER_REGISTRY)
    if factory is not None:
        return _wrap_if_class(factory)

    target = _load_class(name_or_path)
    return _wrap_if_class(target)


def resolve_data_provider(name_or_path: str) -> DataProviderFactory:
    factory = _load_from_registry(name_or_path, _PROVIDER_REGISTRY)
    if factory is not None:
        return _wrap_if_class(factory)

    target = _load_class(name_or_path)
    return _wrap_if_class(target)


def create_adapter(name_or_path: str) -> ModelAdapter:
    factory = resolve_adapter(name_or_path)
    return factory()  # type: ignore[call-arg]


def create_data_provider(name_or_path: str) -> DataProvider:
    factory = resolve_data_provider(name_or_path)
    return factory()  # type: ignore[call-arg]


def available_adapters() -> Dict[str, AdapterFactory]:
    return dict(_ADAPTER_REGISTRY)


def available_data_providers() -> Dict[str, DataProviderFactory]:
    return dict(_PROVIDER_REGISTRY)



