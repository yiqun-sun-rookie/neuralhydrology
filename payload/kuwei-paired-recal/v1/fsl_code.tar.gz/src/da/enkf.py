"""
Ensemble Kalman Filter (EnKF) 构造器
-----------------------------------
EnKF 没有原生"controls"参数，我们做一个轻量包装，
让 .predict(controls=...) 的接口与 simulate_flood_da 兼容。

支持 filterpy 后端 (filterpy.kalman.EnsembleKalmanFilter)。
"""

import numpy as np
from src.da.da_registry import register_da

try:
    from filterpy.kalman import EnsembleKalmanFilter
except ModuleNotFoundError:
    # Fallback: try legacy filter package
    try:
        from filter.non_batch.kalman import EnsembleKalmanFilter  # type: ignore
        import filter.non_batch.kalman.ensemble_kalman_filter as _enkf_mod  # type: ignore
        import copy as _copy
        if not hasattr(_enkf_mod, 'zeros'):
            _enkf_mod.zeros = np.zeros
        if not hasattr(_enkf_mod, 'eye'):
            _enkf_mod.eye = np.eye
        if not hasattr(_enkf_mod, 'array'):
            _enkf_mod.array = np.array
        if not hasattr(_enkf_mod, 'dot'):
            _enkf_mod.dot = np.dot
        if not hasattr(_enkf_mod, 'deepcopy'):
            _enkf_mod.deepcopy = _copy.deepcopy
    except ModuleNotFoundError as exc:
        raise ImportError(
            "EnKF requires filterpy or filter package. Install: pip install filterpy"
        ) from exc


class _EnKFWithControl(EnsembleKalmanFilter):
    """在 predict 时接收 controls，并把它注入 fx"""

    def __init__(self, x0, P0, dim_z, dt, N, hx, fx_core):
        self._controls = None

        def fx_wrapped(x, dt):
            return fx_core(x, dt, controls=self._controls)

        super().__init__(x=x0, P=P0, dim_z=dim_z, dt=dt, N=N,
                         hx=hx, fx=fx_wrapped)

    def predict(self, controls=None, dt=None, **kwargs):
        # Accept and ignore extra kwargs (e.g. dt) for interface compatibility
        self._controls = controls
        super().predict()

    def update(self, z=None, R=None, **kwargs):
        # Accept and ignore extra kwargs (e.g. gain_mask) for interface compatibility
        if z is not None and not hasattr(z, "__len__"):
            z = np.asarray([z], dtype=float)
        super().update(z, R)


@register_da("enkf")
def build_enkf(
    fx, hx, x0,
    P0=None, Q=None, R=None,
    dt_hours: float = 1.0,
    ensemble_size: int = 80,
    **kwargs,
):
    """
    构造一个带 controls 的 EnKF；接口保持与 build_ukf 一致。
    使用与 UKF-M 完全相同的 Q, R, P0, x0 以保证公平对比。
    """
    dim_x = len(x0)
    P0 = P0 if P0 is not None else np.eye(dim_x) * 1.0
    Q  = Q  if Q  is not None else np.eye(dim_x) * 0.001
    R  = R  if R  is not None else np.eye(1) * 1

    enkf = _EnKFWithControl(
        x0=x0,
        P0=P0,
        dim_z=1,
        dt=dt_hours,
        N=ensemble_size,
        hx=lambda x: hx(x),
        fx_core=fx,
    )
    enkf.R = R
    enkf.Q = Q
    return enkf
