"""
IMM 适配器模块。
基于 external/filters 库中的 IMMEstimator 进行扩展，支持降雨驱动的 TPM。
"""
import sys
from pathlib import Path
import numpy as np
from typing import Any, Dict, List, Optional

from src.da.da_registry import register_da

# -------------------------------------------------------
# 动态添加 filters 库路径 (参考 src/da/ukf.py)
# -------------------------------------------------------
_PROJECT_ROOT = Path(__file__).resolve().parents[2]
_FILTERS_PATH_CANDIDATES = [
    _PROJECT_ROOT.parent / "filters",
    Path(r"G:/github/pycharm/projects/filters"),
]
for _candidate in _FILTERS_PATH_CANDIDATES:
    if _candidate.exists():
        if str(_candidate) not in sys.path:
            sys.path.insert(0, str(_candidate))
        # 可能还需要添加内层的 filters 目录
        _inner = _candidate / "filters"
        if _inner.exists() and str(_inner) not in sys.path:
            sys.path.insert(0, str(_inner))

# 尝试导入
try:
    # 注意：根据用户提供的文件列表，filters 包结构是 filters/filters/filter/...
    # 所以 import 路径可能是 filters.filter...
    from filters.filter.non_batch.kalman.IMM import IMMEstimator
except ImportError:
    # 备用：如果在 filters/filters 下
    try:
        from filter.non_batch.kalman.IMM import IMMEstimator
    except ImportError:
        raise ImportError("无法导入 filters.filter.non_batch.kalman.IMM，请检查 filters 库路径")


class RainfallDrivenIMMEstimator(IMMEstimator):
    """
    支持动态转移概率的 IMM 估计器。
    """
    def __init__(
        self, 
        filters: List[Any], 
        mu: np.ndarray, 
        base_M: np.ndarray,
        storm_M: Optional[np.ndarray] = None,
        rain_threshold: float = 5.0
    ):
        """
        Args:
            filters: 滤波器列表
            mu: 初始概率
            base_M: 基础 (低水/平时) 转移矩阵
            storm_M: 暴雨 (高水) 转移矩阵。如果为 None，则退化为标准 IMM。
            rain_threshold: 触发切换的降雨阈值
        """
        super().__init__(filters, mu, base_M)
        self.base_M = base_M
        self.storm_M = storm_M if storm_M is not None else base_M
        self.rain_threshold = rain_threshold

    def predict(self, u: Optional[Dict[str, Any]] = None):
        """
        重写 predict 方法，在混合前根据降雨量动态更新转移矩阵 M。
        
        Args:
            u: 控制量字典。必须包含 'controls' 键，
               且 controls 数组中对应降雨的维度需被正确解析。
               或者 u['rain'] 直接给出当前降雨标量/向量。
        """
        if u is not None and self.storm_M is not self.base_M:
            current_rain = 0.0
            
            # 尝试从控制量中提取降雨
            if isinstance(u, dict):
                if 'rain' in u:
                    # 如果是标量或单点降雨
                    current_rain = np.mean(u['rain'])
                elif 'controls' in u:
                    # 假设 controls 的第一行是 rain (根据 FHModelAdapter 的 schema)
                    # controls shape: (n_features, n_units)
                    ctrls = np.asarray(u['controls'])
                    if ctrls.ndim >= 2 and ctrls.shape[0] >= 1:
                        current_rain = np.mean(ctrls[0, :]) # 取面平均雨量
            
            # 动态切换 M
            if current_rain >= self.rain_threshold:
                self.M = self.storm_M
            else:
                self.M = self.base_M

        # Clean u for downstream filters (remove 'rain' if present, as filters may not accept it)
        u_downstream = u
        if isinstance(u, dict) and 'rain' in u:
            # Create a copy without 'rain'
            u_downstream = u.copy()
            u_downstream.pop('rain')
                
        # 调用父类 predict (执行 Mixing 和 Filter Predict)
        super().predict(u_downstream)

@register_da("imm")
def build_imm(
    # config 包含 IMM 层的配置
    imm_config: Dict[str, Any], 
    # filters 必须由外部构建好传入
    filters: List[Any], 
    **kwargs
):
    """
    构建 IMM 估计器 (工厂函数)。
    """
    mu = np.asarray(imm_config.get("mu", [1.0/len(filters)] * len(filters)))
    base_M = np.asarray(imm_config.get("M", np.eye(len(filters))))
    
    storm_M_cfg = imm_config.get("storm_M")
    storm_M = np.asarray(storm_M_cfg) if storm_M_cfg is not None else None
    
    rain_threshold = imm_config.get("rain_threshold", 5.0)
    
    imm = RainfallDrivenIMMEstimator(
        filters=filters,
        mu=mu,
        base_M=base_M,
        storm_M=storm_M,
        rain_threshold=rain_threshold
    )
    
    return imm

