"""Lumped DA runner -- connects any lumped model to UKF with diagnostics.

Provides a self-contained runner that:
1. Wraps a user-provided ``model_step(x, forcing) -> (x_new, q)`` into the
   UKF's ``fx(x, dt, controls=...)`` interface.
2. Runs the UKF predict/update loop with :class:`DiagnosticCollector`.
3. Returns analysis states, simulated Q, and a :class:`DiagnosticBundle`.

Usage::

    runner = LumpedDARunner(
        model_step=my_step_fn,  # (x_np, forcing_np) -> (x_new_np, q)
        hx=my_obs_fn,           # (x_np) -> obs_np  (1-D array, dim_z)
        forcings=forcings,       # (T, n_forcing)
        qobs=q_obs,             # (T,)
        x0=x0, P0=P0, Q=Q, R=R,
    )
    result = runner.run()
    bundle = result["diagnostics"]
"""
from __future__ import annotations

from typing import Callable

import numpy as np

from src.da.diagnostics.collector import DiagnosticCollector


def estimate_Q_from_openloop(
    model_step: Callable,
    forcings: np.ndarray,
    x0: np.ndarray,
    beta: float = 0.5,
) -> np.ndarray:
    """Estimate process noise Q diagonal from open-loop state increment variance.

    Runs the model forward without assimilation and computes
    ``Q_ii = beta * Var(x_i^{t+1} - x_i^t)`` for each state element.
    This is analogous to the NMC method (Parrish & Derber 1992) used in NWP.

    Parameters
    ----------
    model_step : callable
        ``(x_np, forcing_np) -> (x_new_np, q_scalar)``
    forcings : ndarray, shape (T, n_forcing)
    x0 : ndarray, shape (dim_x,)
        Initial state (should already be warmed up).
    beta : float
        Scaling factor (default 0.5).

    Returns
    -------
    Q_diag : ndarray, shape (dim_x,)
        Diagonal of the estimated Q matrix.
    """
    T = len(forcings)
    dim_x = len(x0)
    increments = np.zeros((T, dim_x))
    x = x0.copy()
    for t in range(T):
        x_new, _ = model_step(x, forcings[t])
        increments[t] = x_new - x
        x = x_new
    q_diag = np.var(increments, axis=0) * beta
    # Floor to avoid zero process noise (would freeze the state)
    q_diag = np.maximum(q_diag, 1e-8)
    return q_diag


class LumpedDARunner:
    """Run UKF data assimilation on a lumped hydrological model.

    Parameters
    ----------
    model_step : callable
        ``(x_np, forcing_np) -> (x_new_np, q_scalar)``
        One-step forward model.  *x_np* is the state vector ``(dim_x,)``,
        *forcing_np* is the forcing/control vector for this timestep.
    hx : callable
        ``(x_np) -> obs_np``  Observation operator mapping state to
        observation space.  Must return a 1-D array of shape ``(dim_z,)``.
    forcings : ndarray, shape (T, n_forcing)
        External forcing time series.
    qobs : ndarray, shape (T,)
        Observed discharge (or other observation).  ``NaN`` entries are
        treated as missing and the update step is skipped.
    x0 : ndarray, shape (dim_x,)
        Initial state vector.
    P0 : ndarray, shape (dim_x, dim_x)
        Initial error covariance.
    Q : ndarray, shape (dim_x, dim_x)
        Process noise covariance.
    R : ndarray, shape (dim_z, dim_z)
        Observation noise covariance.
    da_method : str
        DA algorithm name registered in ``da_registry`` (default ``"ukf"``).
    """

    def __init__(
        self,
        model_step: Callable,
        hx: Callable,
        forcings: np.ndarray,
        qobs: np.ndarray,
        x0: np.ndarray,
        P0: np.ndarray,
        Q: np.ndarray,
        R: np.ndarray,
        da_method: str = "ukf",
    ):
        self.model_step = model_step
        self.hx = hx
        self.forcings = forcings
        self.qobs = qobs
        self.x0 = np.asarray(x0, dtype=float)
        self.P0 = np.asarray(P0, dtype=float)
        self.Q_cov = np.asarray(Q, dtype=float)
        self.R_cov = np.asarray(R, dtype=float)
        self.da_method = da_method
        self.T = len(qobs)
        self.dim_x = len(x0)
        self.dim_z = self.R_cov.shape[0] if self.R_cov.ndim >= 1 else 1

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(self) -> dict:
        """Run UKF with diagnostic collection.

        Returns
        -------
        dict with keys:
            ``diagnostics`` : :class:`DiagnosticBundle`
            ``x_analysis``  : ndarray (T, dim_x) -- posterior state at each step
            ``q_sim``        : ndarray (T,) -- simulated discharge
        """
        from src.da import get_da_builder

        # --- Build the fx wrapper expected by filterpy / filters UKF ---
        # UKF calls  fx(sigma_point, dt, **fx_args)
        # Our model_step expects  model_step(x, forcing) -> (x_new, q)
        user_step = self.model_step

        def fx_wrapper(x, dt, controls=None):
            if controls is None:
                controls = np.zeros(self.forcings.shape[1])
            x_new, _q = user_step(x, controls)
            return np.asarray(x_new, dtype=float)

        # hx for UKF must return 1-D array
        user_hx = self.hx

        def hx_wrapper(x):
            return np.asarray(user_hx(x), dtype=float).ravel()

        # --- Construct the filter ---
        builder = get_da_builder(self.da_method)
        filt = builder(
            fx=fx_wrapper,
            hx=hx_wrapper,
            x0=self.x0.copy(),
            dt_hours=1.0,
            P0=self.P0.copy(),
            Q=self.Q_cov.copy(),
            R=self.R_cov.copy(),
        )

        # Ensure filter state is initialised
        filt.x = self.x0.copy()
        filt.P[:] = self.P0
        filt.Q[:] = self.Q_cov
        filt.R[:] = self.R_cov

        # --- Allocate storage ---
        collector = DiagnosticCollector(
            steps=self.T, dim_x=self.dim_x, dim_z=self.dim_z,
        )

        x_analysis = np.zeros((self.T, self.dim_x))
        q_sim = np.zeros(self.T)

        # --- Main DA loop ---
        for t in range(self.T):
            forcing_t = self.forcings[t]

            # -- Predict --
            filt.predict(controls=forcing_t)

            # Capture prior (after predict, before update)
            x_prior_t = np.asarray(filt.x).ravel().copy()
            P_pred_diag_t = np.diag(np.asarray(filt.P, dtype=float)).copy()

            # -- Update --
            z_t = self.qobs[t]
            if np.isnan(z_t):
                # No observation: skip update, record prior as posterior
                x_post_t = x_prior_t.copy()
                # Compute numerical H for collector (even on skip)
                H_mat = self._numerical_jacobian(hx_wrapper, x_prior_t)
                collector.collect(
                    t, filt, H_mat,
                    x_prior=x_prior_t,
                    x_post=x_post_t,
                    P_pred_diag=P_pred_diag_t,
                )
                x_analysis[t] = x_post_t
                q_sim[t] = hx_wrapper(x_post_t)[0]
                continue

            filt.update(np.array([z_t], dtype=float))

            x_post_t = np.asarray(filt.x).ravel().copy()

            # Numerical Jacobian for diagnostics
            H_mat = self._numerical_jacobian(hx_wrapper, x_post_t)

            collector.collect(
                t, filt, H_mat,
                x_prior=x_prior_t,
                x_post=x_post_t,
                P_pred_diag=P_pred_diag_t,
            )

            x_analysis[t] = x_post_t
            q_sim[t] = hx_wrapper(x_post_t)[0]

        bundle = collector.finalize()

        return {
            "diagnostics": bundle,
            "x_analysis": x_analysis,
            "q_sim": q_sim,
        }

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _numerical_jacobian(
        self, hx_fn: Callable, x: np.ndarray, eps: float = 1e-4,
    ) -> np.ndarray:
        """Compute numerical Jacobian of *hx_fn* at *x*.

        Returns shape ``(dim_z, dim_x)``.
        """
        h0 = hx_fn(x)
        dim_z = len(h0)
        dim_x = len(x)
        H = np.zeros((dim_z, dim_x))
        for j in range(dim_x):
            x_pert = x.copy()
            x_pert[j] += eps
            H[:, j] = (hx_fn(x_pert) - h0) / eps
        return H
