"""FH 水文模型适配器，实现 ModelAdapter 接口。

注意：实际的 FH 会话准备在 DataProvider 中完成，本适配器
通过 `fh_runtime.get_fh_context()` 共享这些信息，以保持两边独立。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

import numpy as np

from ..fh_runtime import get_fh_context
from ..interfaces import ControlsSchema, ModelAdapter, ModelSpec, StateVectorizer


def _ensure_controls_shape(controls: np.ndarray, expected_shape: tuple[int, ...]) -> np.ndarray:
    arr = np.asarray(controls, dtype=np.float32)
    if arr.ndim == 1:
        if arr.size != expected_shape[0]:
            raise ValueError(f"控制量长度应为 {expected_shape[0]}, 当前 {arr.size}")
        arr = arr.reshape(expected_shape[0], 1)
    if arr.ndim == 2 and arr.shape[1] == 1 and len(expected_shape) == 2:
        arr = np.repeat(arr, expected_shape[1], axis=1)
    if arr.shape != expected_shape:
        raise ValueError(f"控制量形状需为 {expected_shape}, 当前 {arr.shape}")
    return arr


@dataclass
class _FHVectorizer(StateVectorizer):
    """利用 DA 句柄提供的 flatten/unflatten。"""

    _flatten: Any
    _unflatten: Any

    def flatten(self, struct: Dict[str, Any]) -> np.ndarray:
        return np.asarray(self._flatten(struct), dtype=np.float32)

    def unflatten(self, vector: np.ndarray) -> Dict[str, Any]:
        return self._unflatten(np.asarray(vector, dtype=np.float32))


class FHModelAdapter(ModelAdapter):
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        ctx = get_fh_context()
        da = ctx['da']
        grid2sub = ctx['grid2sub']
        n_units = int(np.asarray(grid2sub).shape[0])

        control_shape = (4, n_units)
        self._controls_schema = ControlsSchema(
            names=("rain", "temp", "snow", "pet"),
            shape=control_shape,
            is_per_unit=True,
            notes="单位驱动量，顺序与原 FH 模型一致",
        )

        self._spec = ModelSpec(
            dim_x=int(da['state_dim']),
            dim_z=1,
            dt_hours=float(ctx.get('dt_hours', 1.0)),
            controls=self._controls_schema,
        )

        self._vectorizer = _FHVectorizer(da['flatten_state'], da['unflatten_state'])
        self._da = da

    def describe(self) -> ModelSpec:
        return self._spec

    def initial_state(self) -> np.ndarray:
        return np.asarray(self._da['x0_flat'], dtype=np.float64)

    def step(
        self,
        state: np.ndarray,
        controls: np.ndarray,
        extras: Optional[Dict[str, Any]] = None,
    ) -> np.ndarray:
        u = _ensure_controls_shape(controls, self._controls_schema.shape)
        x = np.asarray(state, dtype=np.float32)
        x_next = self._da['f_flat'](x, u)
        return np.asarray(x_next, dtype=np.float64)

    def observe(
        self,
        state: np.ndarray,
        extras: Optional[Dict[str, Any]] = None,
    ) -> np.ndarray:
        x = np.asarray(state, dtype=np.float32)
        y = self._da['h_flat'](x, mode='basin_sum')
        return np.asarray(y, dtype=np.float64).reshape(self._spec.dim_z)

    @property
    def vectorizer(self) -> StateVectorizer:
        return self._vectorizer


__all__ = ["FHModelAdapter"]



