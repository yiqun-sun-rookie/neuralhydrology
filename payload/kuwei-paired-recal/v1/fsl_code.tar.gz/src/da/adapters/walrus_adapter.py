from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, Optional

import numpy as np
import torch

from ..interfaces import ControlsSchema, ModelAdapter, ModelSpec, StateVectorizer
from ..adapter_registry import register_adapter

try:
    from filters.system_models.nonlinear.hydrological.walrus.walrus_torch import (
        WalrusTorch,
    )
except ModuleNotFoundError as exc:  # pragma: no cover - 依赖外部仓库
    raise ImportError(
        "未找到 filters.system_models...WalrusTorch，请确认 filters 仓库在 PYTHONPATH 中"
    ) from exc


DEFAULT_PARAMS = {
    "cw": 150.0,
    "cv": 30.0,
    "cg": 200.0,
    "cq": 5.0,
    "cd": 500.0,
    "cs": 20.0,
    "as_": 0.01,
}

DEFAULT_INITIAL_STATE = np.array(
    [200.0, 80.0, 1.0, 300.0, 0.5],
    dtype=np.float32,
)


def _ensure_vector(vector: Iterable[float], size: int, name: str) -> np.ndarray:
    arr = np.asarray(vector, dtype=np.float32).reshape(-1)
    if arr.size != size:
        raise ValueError(f"{name} 期望长度 {size}，当前 {arr.size}")
    return arr


def _ensure_controls(controls: np.ndarray) -> np.ndarray:
    arr = np.asarray(controls, dtype=np.float32)
    if arr.ndim == 0:
        raise ValueError("Walrus 控制量至少包含降水/潜在蒸散发两个分量")
    if arr.ndim == 1:
        if arr.size != 2:
            raise ValueError(f"Walrus 控制量期望长度 2 (P, ETpot)，当前 {arr.size}")
        arr = arr.reshape(1, 2)
    elif arr.ndim == 2:
        if arr.shape[1] != 2:
            raise ValueError(f"Walrus 控制量列数需为 2，当前 {arr.shape}")
    else:
        raise ValueError(f"Walrus 控制量维度不支持: {arr.shape}")
    return arr


@dataclass
class WalrusVectorizer(StateVectorizer):
    state_names: tuple[str, ...]

    def flatten(self, struct: Dict[str, Any] | np.ndarray) -> np.ndarray:
        if isinstance(struct, dict):
            values = [struct[name] for name in self.state_names]
            return _ensure_vector(values, len(self.state_names), "WalrusStateDict")
        return _ensure_vector(struct, len(self.state_names), "WalrusState")

    def unflatten(self, vector: np.ndarray) -> Dict[str, float]:
        arr = _ensure_vector(vector, len(self.state_names), "WalrusStateVec")
        return {name: float(arr[i]) for i, name in enumerate(self.state_names)}


class WalrusModelAdapter(ModelAdapter):
    """把 filters 仓库的 WalrusTorch 模型封装成 DA 统一接口。"""

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        cfg = config or {}
        params_cfg = {**DEFAULT_PARAMS, **(cfg.get("params") or {})}
        self._device = torch.device(cfg.get("device", "cpu"))
        self._dt_hours = float(cfg.get("dt_hours", 1.0))
        self._state_names = tuple(cfg.get("state_names", ["dv", "dg", "hq", "hs", "q"]))
        initial_state = _ensure_vector(
            cfg.get("initial_state", DEFAULT_INITIAL_STATE),
            len(self._state_names),
            "initial_state",
        )

        self._model = WalrusTorch(
            **params_cfg,
            device=self._device,
            m=len(self._state_names),
            n=1,
            initial_state=torch.as_tensor(
                initial_state.reshape(1, -1), dtype=torch.float32, device=self._device
            ),
            check_nan_flag=bool(cfg.get("check_nan", False)),
        )
        self._model.eval()

        self._spec = ModelSpec(
            dim_x=len(self._state_names),
            dim_z=1,
            dt_hours=self._dt_hours,
            controls=ControlsSchema(
                names=("precip", "etpot"),
                shape=(2,),
                is_per_unit=False,
                notes="Walrus 单流域控制量：降水/潜在蒸散发",
            ),
        )
        self._vectorizer = WalrusVectorizer(self._state_names)

        # 用 numpy 保存一个 baseline 初始状态，供 DA 初始化引用
        self._x0 = initial_state.astype(np.float64).copy()

    def describe(self) -> ModelSpec:
        return self._spec

    def initial_state(self) -> np.ndarray:
        return self._x0.copy()

    def _to_tensor(self, array: np.ndarray, batch_dim: bool = True) -> torch.Tensor:
        arr = np.asarray(array, dtype=np.float32)
        if batch_dim:
            arr = arr.reshape(1, -1)
        return torch.as_tensor(arr, dtype=torch.float32, device=self._device)

    def step(
        self,
        state: np.ndarray,
        controls: np.ndarray,
        extras: Optional[Dict[str, Any]] = None,
    ) -> np.ndarray:
        ctrl = _ensure_controls(controls)
        state_tensor = self._to_tensor(state, batch_dim=True)
        control_tensor = self._to_tensor(ctrl, batch_dim=False)
        with torch.no_grad():
            next_state = self._model.f(state_tensor, control_tensor)
        return (
            next_state.detach()
            .cpu()
            .numpy()
            .reshape(-1)
            .astype(np.float64, copy=False)
        )

    def observe(
        self,
        state: np.ndarray,
        extras: Optional[Dict[str, Any]] = None,
    ) -> np.ndarray:
        state_tensor = self._to_tensor(state, batch_dim=True)
        with torch.no_grad():
            y = self._model.h(state_tensor)
        return y.detach().cpu().numpy().reshape(self._spec.dim_z).astype(np.float64)

    @property
    def vectorizer(self) -> StateVectorizer:
        return self._vectorizer


__all__ = ["WalrusModelAdapter"]


register_adapter("walrus", WalrusModelAdapter)




