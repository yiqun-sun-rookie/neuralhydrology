"""FH 水文模型的适配器实现。

核心思路：
- 利用现有的 `get_da_handles` 产物（含扁平态/解扁平等工具）；
- 通过 `make_fx_hx_from_da` 得到 `fx/hx`，直接服务 Kalman 系列算法；
- 对外暴露统一的 `ModelAdapter` 接口，供通用 DA runner 调用。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

import numpy as np

from ..interfaces import ControlsSchema, ModelAdapter, ModelSpec, StateVectorizer


@dataclass
class FHStateVectorizer(StateVectorizer):
    """依托 DA 句柄提供的 flatten/unflatten 函数。"""

    flatten_state: Any
    unflatten_state: Any

    def flatten(self, struct: Dict[str, Any]) -> np.ndarray:
        return np.asarray(self.flatten_state(struct), dtype=np.float64)

    def unflatten(self, vector: np.ndarray) -> Dict[str, Any]:
        return self.unflatten_state(np.asarray(vector))


class FHModelAdapter(ModelAdapter):
    """把 FH 半分布式水文模型封装为 Kalman 可调用的接口。"""

    def __init__(
        self,
        *,
        da_handles: Dict[str, Any],
        fx,
        hx,
        ng: int,
        dt_hours: float = 1.0,
    ) -> None:
        self._da = da_handles
        self._fx = fx
        self._hx = hx
        self._fx_raw = fx
        self._hx_raw = hx
        self._dt_hours = float(dt_hours)
        self._vectorizer = FHStateVectorizer(
            flatten_state=da_handles['flatten_state'],
            unflatten_state=da_handles['unflatten_state'],
        )

        self._spec = ModelSpec(
            dim_x=int(da_handles['state_dim']),
            dim_z=1,
            dt_hours=self._dt_hours,
            controls=ControlsSchema(
                names=("rain", "temp", "snow", "pet"),
                shape=(4, int(ng)),
                is_per_unit=True,
                notes="控制量顺序固定为雨/温/雪/PET",
            ),
        )

    def describe(self) -> ModelSpec:
        return self._spec

    def initial_state(self) -> np.ndarray:
        return np.asarray(self._da['x0_flat'], dtype=np.float64)

    def step(
        self,
        state: np.ndarray,
        controls: np.ndarray,
        extras: Optional[Dict[str, Any]] = None,
    ) -> np.ndarray:
        controls_arr = np.asarray(controls, dtype=np.float32)
        next_state = self._fx(np.asarray(state, dtype=np.float64), self._dt_hours, controls=controls_arr)
        return np.asarray(next_state, dtype=np.float64)

    def observe(
        self,
        state: np.ndarray,
        extras: Optional[Dict[str, Any]] = None,
    ) -> np.ndarray:
        y = self._hx(np.asarray(state, dtype=np.float64))
        return np.asarray(y, dtype=np.float64).reshape(-1)

    @property
    def vectorizer(self) -> StateVectorizer:
        return self._vectorizer

    @property
    def fx_for_da(self):
        """返回原始 fx，供需要严格对齐的 DA 调度器直接复用。"""

        return self._fx_raw

    @property
    def hx_for_da(self):
        return self._hx_raw



