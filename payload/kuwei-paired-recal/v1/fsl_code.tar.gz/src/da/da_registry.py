"""
轻量级 DA 注册器
"""

from typing import Callable, Dict, Any

_DA_REGISTRY: Dict[str, Callable[..., Any]] = {}


def register_da(name: str):
    """装饰器：注册 DA 构造函数"""
    def decorator(func: Callable[..., Any]):
        _DA_REGISTRY[name] = func
        return func
    return decorator


def get_da_builder(name: str):
    """根据名称返回已注册的 DA 构造函数"""
    if name not in _DA_REGISTRY:
        raise ValueError(f"未注册的 DA 类型: {name!r}")
    return _DA_REGISTRY[name]

