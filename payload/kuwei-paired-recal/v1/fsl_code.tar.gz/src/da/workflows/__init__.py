"""Workflow helpers for running hydrologic DA demos."""

from .fh import (
    plot_obs_vs_openloop,
    plot_state_aggregations,
    run_assimilation,
    save_outputs,
)

__all__ = [
    "run_assimilation",
    "save_outputs",
    "plot_obs_vs_openloop",
    "plot_state_aggregations",
]


