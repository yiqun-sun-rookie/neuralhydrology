"""Reusable FH data-assimilation workflow helpers."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Dict, Iterable, Optional

import numpy as np

from src.da import get_da_builder

try:  # pragma: no cover - filters bridge only available when experiments pkg present
    from experiments.streaming_da.ylx import filters_bridge
except Exception:  # pragma: no cover
    filters_bridge = None

ControlBuilder = Callable[[Any, int], Any]


def _run_bridged_filter_with_missing_tail(
    da_name: str,
    hydro_backend: Any,
    da_setup: Any,
    ensemble_size: int,
    control_builder: ControlBuilder,
) -> Dict[str, np.ndarray]:
    """Run a bridged filter through observations, then predict a missing tail."""
    supplied_qobs = np.asarray(hydro_backend.forcings.qobs, dtype=float)
    if supplied_qobs.ndim != 1:
        raise ValueError(f"forcings.qobs must be one-dimensional, got shape {supplied_qobs.shape}")
    steps = int(hydro_backend.forcings.steps)
    qobs = np.full(steps, np.nan, dtype=float)
    copied = min(steps, supplied_qobs.size)
    qobs[:copied] = supplied_qobs[:copied]

    missing = ~np.isfinite(qobs)
    if not np.any(missing):
        return filters_bridge.run_filters_algorithm(
            da_name,
            hydro_backend,
            da_setup,
            ensemble_size,
            control_builder=control_builder,
        )

    first_missing = int(np.flatnonzero(missing)[0])
    if np.any(~missing[first_missing:]):
        raise ValueError(
            f"Bridged filter {da_name} supports missing observations only as a contiguous forecast tail"
        )

    prefix_result: Dict[str, np.ndarray] = {}
    if first_missing > 0:
        class _PrefixForcings:
            pass

        prefix_forcings = _PrefixForcings()
        prefix_forcings.steps = first_missing
        prefix_forcings.qobs = qobs[:first_missing]

        class _PrefixBackend:
            forcings = prefix_forcings
            hx = hydro_backend.hx

            @staticmethod
            def get_controls(t):
                return control_builder(hydro_backend, t)

        prefix_backend = _PrefixBackend()
        prefix_result = filters_bridge.run_filters_algorithm(
            da_name,
            prefix_backend,
            da_setup,
            ensemble_size,
            control_builder=lambda backend, t: backend.get_controls(t),
        )
        prefix_states = np.asarray(prefix_result["x_means"], dtype=float)
        state = prefix_states[-1].copy()
    else:
        prefix_states = np.empty((0, da_setup.dim_x), dtype=float)
        state = np.asarray(da_setup.x0_flat, dtype=float).copy()

    x_means = np.empty((steps, da_setup.dim_x), dtype=float)
    y_preds = np.empty(steps, dtype=float)
    if first_missing > 0:
        x_means[:first_missing] = prefix_states
        y_preds[:first_missing] = np.asarray(prefix_result["y_preds"], dtype=float)

    for t in range(first_missing, steps):
        controls_t = control_builder(hydro_backend, t)
        state = np.asarray(da_setup.fx(state, 1.0, controls=controls_t), dtype=float).reshape(-1)
        x_means[t] = state
        y_preds[t] = float(np.asarray(da_setup.hx(state), dtype=float).ravel()[0])

    result = dict(prefix_result)
    result["x_means"] = x_means
    result["y_preds"] = y_preds
    return result


def run_assimilation(
    da_list: Iterable[str],
    hydro_backend: Any,
    da_setup: Any,
    *,
    control_builder: Optional[ControlBuilder] = None,
    # 兼容旧接口，优先使用 da_setup.ensemble_size
    ensemble_size: Optional[int] = None,
    collect_diagnostics: bool = False,
):
    """Execute DA algorithms over the provided backend/setup.
    
    Args:
        da_list: 要运行的同化算法列表
        hydro_backend: 水文模型后端，需提供 get_controls(step) 方法
        da_setup: DA 配置（包含 fx, hx, P0, Q, R, ensemble_size 等）
        control_builder: 可选，自定义控制量构建器
        ensemble_size: 已废弃，请使用 da_setup.ensemble_size
    """

    forcings = hydro_backend.forcings
    results: Dict[str, Dict[str, np.ndarray]] = {}
    ran_algos: list[str] = []
    failed_algos: list[str] = []

    # 从 da_setup 获取 ensemble_size，兼容旧接口
    ens_size = ensemble_size or getattr(da_setup, "ensemble_size", 80)

    print(f"[FH/DA] 准备运行滤波算法: {', '.join(da_list)}")

    # 步长一致性检查
    snowmelt = getattr(hydro_backend, "snowmelt", None)
    if snowmelt is not None and snowmelt.steps != forcings.steps:
        raise ValueError("SnowmeltResult 步长与 forcings 不一致")

    # 优先使用 hydro_backend.get_controls()
    if control_builder is None:
        if hasattr(hydro_backend, "get_controls"):
            control_builder = lambda backend, t: backend.get_controls(t)
        else:
            raise ValueError(
                "control_builder is required when hydro_backend has no get_controls method"
            )

    bridge_algos = set(filters_bridge.available_algorithms()) if filters_bridge else set()

    for da_name in da_list:
        print(f"[FH/DA] 正在构造 {da_name.upper()} 滤波器...")
        
        # 路径 1：通过 filters_bridge 运行（外部滤波器库）
        if da_name in bridge_algos:
            try:
                bridge_result = _run_bridged_filter_with_missing_tail(
                    da_name,
                    hydro_backend,
                    da_setup,
                    ens_size,
                    control_builder,
                )
            except Exception as exc:  # pragma: no cover
                print(f"[ERROR] filters_bridge.{da_name} 失败: {exc}")
                failed_algos.append(da_name)
                continue
            results[da_name] = bridge_result
            ran_algos.append(da_name)
            print(f"[FH/DA] {da_name.upper()} (filters_bridge) 运行成功（T={forcings.steps}步）")
            continue

        # 路径 2：通过内置滤波器运行
        result = _run_builtin_filter(
            da_name, hydro_backend, da_setup, forcings, control_builder, ens_size,
            collect_diagnostics=collect_diagnostics,
        )
        if result is None:
            failed_algos.append(da_name)
        else:
            results[da_name] = result
            ran_algos.append(da_name)
            print(f"[FH/DA] {da_name.upper()} 运行成功（T={forcings.steps}步）")

    return results, ran_algos, failed_algos


def _make_hx_adapter(da_setup: Any, da_name: str) -> Callable:
    """
    为滤波器构建 hx 适配器。
    
    根据 da_name 和 da_setup 的配置，返回适当格式的观测函数：
    - EKF 需要标量输出 (float)
    - UKF/EnKF 需要向量输出 (1D ndarray)
    - 如果 da_setup 提供了 make_hx_adapter 方法，优先使用它
    
    Args:
        da_setup: DA 配置对象，必须包含 hx 方法
        da_name: 滤波器名称 ("ukf", "ekf", "enkf")
    
    Returns:
        适配后的 hx 函数
    """
    scalar_output = (da_name == "ekf")
    
    # 优先使用 da_setup 提供的自定义适配器
    if hasattr(da_setup, "make_hx_adapter"):
        return da_setup.make_hx_adapter(scalar_output=scalar_output)
    
    # 默认适配逻辑
    if scalar_output:
        return lambda x: float(np.asarray(da_setup.hx(x), dtype=float).ravel()[0])
    else:
        return lambda x: np.asarray(da_setup.hx(x), dtype=float).ravel()


def _run_builtin_filter(
    da_name: str,
    hydro_backend: Any,
    da_setup: Any,
    forcings: Any,
    control_builder: ControlBuilder,
    ensemble_size: int,
    *,
    collect_diagnostics: bool = False,
) -> Optional[Dict[str, np.ndarray]]:
    """运行内置滤波器（UKF/EKF/EnKF）。"""
    
    builder = get_da_builder(da_name)
    extra = {}
    if da_name == "enkf":
        extra["ensemble_size"] = int(ensemble_size)
    elif da_name == "imm_alpha_p":
        imm_cfg = getattr(da_setup, "da_config", {}).get("imm_alpha_p", {})
        extra["alpha_p_values"] = imm_cfg.get("alpha_p_values", [0.6, 0.8, 1.0, 1.2, 1.5])
        extra["stay_prob"] = imm_cfg.get("stay_prob", 0.98)

    hx_for_builder = _make_hx_adapter(da_setup, da_name)

    filt = builder(
        fx=da_setup.fx,
        hx=hx_for_builder,
        x0=da_setup.x0_flat.copy(),
        dt_hours=1.0,
        P0=da_setup.P0,
        Q=da_setup.Q,
        R=da_setup.R,
        **extra,
    )

    if filt is None:
        print(f"[ERROR] {da_name.upper()} 无法构造滤波器，跳过")
        return None

    print(f"[FH/DA] {da_name.upper()} 滤波器构造成功，开始运行...")
    
    # 初始化滤波器状态
    if hasattr(filt, "x"):
        filt.x = da_setup.x0_flat.copy()
    if hasattr(filt, "P"):
        filt.P[:] = da_setup.P0
    if hasattr(filt, "Q"):
        setattr(filt, "Q", np.array(da_setup.Q, dtype=float))
    if hasattr(filt, "R"):
        setattr(filt, "R", np.array(da_setup.R, dtype=float))

    # 逐步运行
    x_means = np.zeros((forcings.steps, da_setup.dim_x), dtype=float)
    y_preds = np.zeros((forcings.steps,), dtype=float)
    y_pred_stds = np.zeros((forcings.steps,), dtype=float)

    # Diagnostic collector (optional)
    collector = None
    if collect_diagnostics:
        from src.da.diagnostics.collector import DiagnosticCollector
        dim_z = da_setup.R.shape[0] if hasattr(da_setup.R, "shape") else 1
        collector = DiagnosticCollector(
            steps=forcings.steps, dim_x=da_setup.dim_x, dim_z=dim_z,
        )

    qobs = np.asarray(forcings.qobs, dtype=float)
    if qobs.ndim != 1:
        raise ValueError(f"forcings.qobs must be one-dimensional, got shape {qobs.shape}")

    for t in range(forcings.steps):
        controls_t = control_builder(hydro_backend, t)
        filt.predict(controls=controls_t)

        observation_value = qobs[t] if t < qobs.size else np.nan
        observation_t = np.array([observation_value], dtype=float)
        observation_used = bool(np.all(np.isfinite(observation_t)))
        if not observation_used:
            finalize_prediction = getattr(filt, "finalize_prediction", None)
            if callable(finalize_prediction):
                finalize_prediction()

        # Capture prior state and predicted covariance before update
        if collector is not None:
            x_prior_t = np.asarray(
                getattr(filt, "x", getattr(filt, "x_mean", da_setup.x0_flat))
            ).ravel().copy()
            P_pred_obj = getattr(filt, "P", None)
            P_pred_diag_t = (
                np.diag(np.asarray(P_pred_obj, dtype=float)).copy()
                if P_pred_obj is not None
                else None
            )

        if observation_used:
            gain_mask = getattr(da_setup, "gain_mask", None)
            if gain_mask is not None and da_name in {"ukf", "mukf"}:
                filt.update(observation_t, gain_mask=gain_mask)
            else:
                filt.update(observation_t)

        state_projector = getattr(da_setup, "state_projector", None)
        if callable(state_projector):
            current_state = np.asarray(
                getattr(filt, "x", getattr(filt, "x_mean", da_setup.x0_flat)),
                dtype=float,
            ).reshape(-1)
            projected_state = np.asarray(state_projector(current_state), dtype=float).reshape(-1)
            if projected_state.shape != current_state.shape:
                raise ValueError(
                    f"state_projector returned shape {projected_state.shape}, expected {current_state.shape}"
                )
            if hasattr(filt, "x"):
                filt.x = projected_state.copy()
            elif hasattr(filt, "x_mean"):
                filt.x_mean = projected_state.copy()
            if hasattr(filt, "x_post"):
                filt.x_post = projected_state.copy()

        x_vec = np.asarray(getattr(filt, "x", None))
        if x_vec is None or x_vec.size == 0:
            x_vec = np.asarray(getattr(filt, "x_mean", da_setup.x0_flat))
        x_vec = x_vec.reshape(-1)
        x_means[t] = x_vec
        y_pred_t = hydro_backend.hx(x_vec)
        y_preds[t] = float(np.asarray(y_pred_t, dtype=float).ravel()[0])

        # Extract posterior uncertainty and project to observation space
        P_post = getattr(filt, "P", None)
        H_row = None
        if P_post is not None:
            try:
                P_arr = np.asarray(P_post, dtype=float)
                # Numerical Jacobian of hx around current state
                eps_jac = 1e-4
                hx_func = hydro_backend.hx
                h0 = float(np.asarray(hx_func(x_vec), dtype=float).ravel()[0])
                H_row = np.zeros(da_setup.dim_x, dtype=float)
                for j in range(da_setup.dim_x):
                    x_pert = x_vec.copy()
                    x_pert[j] += eps_jac
                    H_row[j] = (float(np.asarray(hx_func(x_pert), dtype=float).ravel()[0]) - h0) / eps_jac
                # y_var = H @ P @ H^T (scalar)
                y_var = float(H_row @ P_arr @ H_row)
                y_pred_stds[t] = np.sqrt(max(y_var, 0.0))
            except Exception:
                y_pred_stds[t] = 0.0
        else:
            y_pred_stds[t] = 0.0

        # Collect diagnostics
        if collector is not None:
            H_mat = H_row.reshape(1, -1) if H_row is not None else np.zeros((1, da_setup.dim_x))
            collector.collect(
                t, filt, H_mat,
                x_prior=x_prior_t, x_post=x_vec.copy(),
                P_pred_diag=P_pred_diag_t,
                observation_used=observation_used,
            )

    result = {"x_means": x_means, "y_preds": y_preds, "y_pred_stds": y_pred_stds}
    if collector is not None:
        result["diagnostics"] = collector.finalize()
    if hasattr(filt, "mu_history") and filt.mu_history:
        result["mu_history"] = np.array(filt.mu_history)
        result["alpha_p_history"] = np.array(filt.alpha_p_history)
    return result


def save_outputs(
    ran_algos,
    results,
    y_openloop,
    states_ol,
    states_by_algo,
    first_algo,
    output_dir: Path,
    qobs,
):
    """Persist assimilation results and aggregated states."""

    output_dir.mkdir(parents=True, exist_ok=True)
    x_means = results[first_algo]["x_means"]
    y_preds = results[first_algo]["y_preds"]

    np.save(output_dir / "states_mean.npy", x_means)
    np.save(output_dir / "obs_pred.npy", y_preds)
    np.save(output_dir / "obs_true.npy", qobs)
    np.save(output_dir / "obs_openloop.npy", y_openloop)

    if len(ran_algos) > 1:
        for name in ran_algos:
            np.save(output_dir / f"obs_pred_{name}.npy", results[name]["y_preds"])

    def _save_states_npz(path, arrays: Dict[str, np.ndarray]):
        if arrays:
            np.savez(path, **arrays)
        else:
            np.savez(path)

    _save_states_npz(output_dir / "agg_states_openloop.npz", states_ol)
    for algo_name, agg_states in states_by_algo.items():
        _save_states_npz(output_dir / f"agg_states_{algo_name}.npz", agg_states)
    primary_states = states_by_algo.get(first_algo)
    if primary_states is not None:
        _save_states_npz(output_dir / "agg_states_ukf.npz", primary_states)

    if states_by_algo:
        print(
            "[FH/DA] 已保存聚合状态轨迹: Openloop + "
            + ", ".join(algo.upper() for algo in ran_algos)
        )


def plot_obs_vs_openloop(
    qobs: np.ndarray,
    y_preds: np.ndarray,
    y_openloop: np.ndarray,
    first_algo: str,
    nse_da: float,
    nse_ol: float,
    save_path: Path,
):
    """Plot observed vs. assimilated vs. open-loop discharge."""

    import matplotlib.pyplot as plt

    plt.figure(figsize=(10, 4))
    plt.plot(qobs, "k", label="Obs")
    plt.plot(y_preds, "r--", label=f"{first_algo.upper()} Pred")
    plt.plot(y_openloop, "b:", label="Openloop")
    plt.legend()
    plt.title(f"FH + {first_algo.upper()} (basin_sum), NSE={nse_da:.4f}, OL={nse_ol:.4f}")
    plt.tight_layout()
    save_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(save_path, dpi=150)
    plt.close()


def plot_state_aggregations(
    state_names,
    ran_algos,
    states_ol,
    states_by_algo,
    state_agg: str,
    save_path: Path,
):
    """Plot aggregated states for open-loop vs. DA runs."""

    import matplotlib.pyplot as plt

    if not state_names:
        return
    n = len(state_names)
    cols = 3
    rows = int(np.ceil(n / cols))
    fig, axes = plt.subplots(rows, cols, figsize=(4 * cols, 2.6 * rows), squeeze=False)
    algo_styles = ["r-", "g--", "m-.", "c-", "y--", "k-"]
    for i, name in enumerate(state_names):
        r, c = divmod(i, cols)
        ax = axes[r, c]
        show_label = i == 0
        ax.plot(
            states_ol[name],
            "b:",
            label="Openloop" if show_label else "_nolegend_",
        )
        for idx, algo_name in enumerate(ran_algos):
            algo_states = states_by_algo.get(algo_name)
            if not algo_states or name not in algo_states:
                continue
            style = algo_styles[idx % len(algo_styles)]
            label = algo_name.upper() if show_label else "_nolegend_"
            ax.plot(algo_states[name], style, label=label)
        ax.set_title(name)
    for j in range(n, rows * cols):
        r, c = divmod(j, cols)
        axes[r, c].axis("off")
    handles, labels = axes[0, 0].get_legend_handles_labels()
    if handles:
        fig.legend(handles, labels, loc="lower center", ncol=min(len(labels), 4))
    fig.suptitle(f"States ({state_agg})")
    fig.tight_layout(rect=[0, 0.04, 1, 0.98])
    save_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(save_path, dpi=150)
    plt.close(fig)


__all__ = [
    "run_assimilation",
    "save_outputs",
    "plot_obs_vs_openloop",
    "plot_state_aggregations",
]


