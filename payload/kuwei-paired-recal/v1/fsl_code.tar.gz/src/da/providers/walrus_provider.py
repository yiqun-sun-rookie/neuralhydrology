from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional, Sequence

import numpy as np

from ..interfaces import DataBundle, DataProvider
from ..adapter_registry import register_data_provider

_ARRAY_LIKE = (list, tuple, np.ndarray)


def _load_array(source: Any, name: str) -> np.ndarray:
    if source is None:
        raise ValueError(f"{name} 数据源不能为空")
    if isinstance(source, dict):
        if "data" in source:
            arr = np.asarray(source["data"], dtype=float)
        else:
            arr = _load_from_path(
                source.get("path"),
                name=name,
                key=source.get("key"),
                column=source.get("column"),
                delimiter=source.get("delimiter", ","),
            )
    elif isinstance(source, _ARRAY_LIKE):
        arr = np.asarray(source, dtype=float)
    else:
        arr = _load_from_path(source, name=name)
    if arr.size == 0:
        raise ValueError(f"{name} 数据为空")
    return arr


def _load_from_path(
    path_like: Any,
    *,
    name: str,
    key: Optional[str] = None,
    column: Optional[int] = None,
    delimiter: str = ",",
) -> np.ndarray:
    path = Path(path_like)
    if not path.exists():
        raise FileNotFoundError(f"{name} 文件不存在: {path}")
    suffix = path.suffix.lower()
    if suffix == ".npy":
        arr = np.load(path)
    elif suffix == ".npz":
        data = np.load(path)
        keys = list(data.keys())
        if key is None:
            if len(keys) != 1:
                raise ValueError(f"{name} .npz 需要指定 key，可选: {keys}")
            key = keys[0]
        arr = data[key]
    else:
        arr = np.loadtxt(path, delimiter=delimiter)
    arr = np.asarray(arr, dtype=float)
    if column is not None:
        if arr.ndim == 1:
            raise ValueError(f"{name} 只有一列，无法按 column={column} 选择")
        arr = arr[:, int(column)]
    return arr


def _ensure_controls_shape(controls: np.ndarray) -> np.ndarray:
    arr = np.asarray(controls, dtype=float)
    if arr.ndim == 1:
        if arr.size % 2 != 0:
            raise ValueError("Walrus 控制量长度必须为 2 的倍数 (降水/ET 成对)")
        arr = arr.reshape(-1, 2)
    if arr.ndim != 2 or arr.shape[1] != 2:
        raise ValueError(f"Walrus 控制量形状需为 (T,2)，当前 {arr.shape}")
    return arr


def _ensure_observations_shape(observations: np.ndarray, steps: int) -> np.ndarray:
    arr = np.asarray(observations, dtype=float).reshape(-1)
    if arr.size != steps:
        raise ValueError(f"观测长度({arr.size}) ≠ 控制量步数({steps})")
    return arr


def _materialize_time_index(source: Any, steps: int) -> Optional[Sequence[Any]]:
    if source is None:
        return None
    if isinstance(source, dict):
        if "data" in source:
            seq_raw = np.asarray(source["data"])
            seq = seq_raw.reshape(-1).tolist()
        else:
            seq = _materialize_time_index(source.get("path"), steps)
        if len(seq) != steps:
            raise ValueError(f"time_index 长度({len(seq)}) ≠ 控制量步数({steps})")
        return seq
    if isinstance(source, (list, tuple)):
        seq: Sequence[Any] = list(source)
    elif isinstance(source, np.ndarray):
        seq = source.tolist()
    else:
        path = Path(source)
        if not path.exists():
            raise FileNotFoundError(f"time_index 文件不存在: {path}")
        seq = np.loadtxt(path, dtype=str).tolist()
    if len(seq) != steps:
        raise ValueError(f"time_index 长度({len(seq)}) ≠ 控制量步数({steps})")
    return seq


@dataclass
class WalrusDataProvider(DataProvider):
    """提供单流域 Walrus 模型所需的降水/潜在蒸散发与观测序列。

    支持两种使用方式：
    1. 在构造函数里直接传入 numpy 数组；
    2. 在 ``load(config)`` 调用时以数组/文件路径/dict 形式提供。
    """

    defaults: Dict[str, Any] = field(default_factory=dict)

    def load(self, config: Optional[Dict[str, Any]] = None) -> DataBundle:
        cfg = {**self.defaults}
        if config:
            cfg.update(config)
        controls = _ensure_controls_shape(_load_array(cfg.get("controls"), "controls"))
        observations = _ensure_observations_shape(
            _load_array(cfg.get("observations"), "observations"), controls.shape[0]
        )
        time_index = _materialize_time_index(cfg.get("time_index"), controls.shape[0])
        extras = cfg.get("extras")
        return DataBundle(
            controls=controls,
            observations=observations,
            time_index=time_index,
            extras=extras,
        )


__all__ = ["WalrusDataProvider"]


register_data_provider("walrus", WalrusDataProvider)




