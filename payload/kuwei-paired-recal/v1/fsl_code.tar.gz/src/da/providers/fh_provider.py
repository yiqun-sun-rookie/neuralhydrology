"""FH Demo 专用的数据提供者实现。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, Sequence

import numpy as np

from ..interfaces import DataBundle, DataProvider


@dataclass
class FHDataLoader(DataProvider):
    """把预先准备好的数组封装为 ``DataBundle``。"""

    controls: np.ndarray
    observations: np.ndarray
    time_index: Optional[Sequence[Any]] = None
    extras: Optional[Dict[str, Any]] = None

    def load(self, config: Optional[Dict[str, Any]] = None) -> DataBundle:
        controls = np.asarray(self.controls, dtype=float)
        obs = np.asarray(self.observations, dtype=float)
        if controls.shape[0] != obs.shape[0]:
            raise ValueError("控制量与观测长度不一致")
        return DataBundle(
            controls=controls,
            observations=obs,
            time_index=self.time_index,
            extras=self.extras,
        )


FHDataProvider = FHDataLoader



