"""模型适配器与数据提供者的轻量接口定义。

本文件只做一件事：描述 DA 核心所需的最小“约定”。
团队成员无需深挖框架细节，只要按这些接口实现自己的类，
就能把水文模型或数据加载模块插到 DA 系统里。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional, Protocol, Sequence, Tuple

import numpy as np


@dataclass
class ControlsSchema:
    """描述控制量（驱动数据）的结构。

    - ``names``: 每个控制量的名字，确保人能看懂（例如 ``("rain", "temp")``）。
    - ``shape``: 每个时间步的数组形状。例如 ``(4, Ng)`` 表示 4 个变量 × Ng 个汇流单元。
    - ``is_per_unit``: ``True`` 表示控制量按空间网格展开；``False`` 表示整个流域只有一个值。
    - ``notes``: 可选说明（单位、来源等）。
    """

    names: Sequence[str]
    shape: Tuple[int, ...]
    is_per_unit: bool
    notes: Optional[str] = None


@dataclass
class ModelSpec:
    """模型的关键尺寸信息。"""

    dim_x: int
    dim_z: int
    dt_hours: float
    controls: ControlsSchema


class StateVectorizer(Protocol):
    """把模型内部结构与 1D 向量互转。"""

    def flatten(self, struct: Dict[str, Any]) -> np.ndarray:
        ...

    def unflatten(self, vector: np.ndarray) -> Dict[str, Any]:
        ...


class ModelAdapter(Protocol):
    """水文模型 → DA 的桥梁。"""

    def describe(self) -> ModelSpec:
        """返回模型尺寸与控制量信息。"""

    def initial_state(self) -> np.ndarray:
        """提供 DA 初始化所需的扁平化状态向量。"""

    def step(
        self,
        state: np.ndarray,
        controls: np.ndarray,
        extras: Optional[Dict[str, Any]] = None,
    ) -> np.ndarray:
        """推进一步模型。

        :param state: 当前状态（一维向量）。
        :param controls: 控制量，形状需和 ``describe().controls.shape`` 兼容。
        :param extras: 可选的外接来水等额外信息。
        :returns: 下一时刻的状态（一维向量）。
        """

    def observe(
        self,
        state: np.ndarray,
        extras: Optional[Dict[str, Any]] = None,
    ) -> np.ndarray:
        """从状态推算观测值（hx）。"""

    @property
    def vectorizer(self) -> StateVectorizer:
        """返回内部状态与向量的互转工具。"""


@dataclass
class DataBundle:
    """DA 运行所需的时间序列数据。"""

    controls: np.ndarray
    observations: np.ndarray
    time_index: Optional[Sequence[Any]] = None
    extras: Optional[Dict[str, Any]] = None


class DataProvider(Protocol):
    """负责准备驱动与观测的模块。"""

    def load(self, config: Optional[Dict[str, Any]] = None) -> DataBundle:
        ...


# 类型别名，方便在注册表中标注用途
AdapterFactory = Callable[[], ModelAdapter]
DataProviderFactory = Callable[[], DataProvider]



