"""
Extended Kalman Filter (EKF) 构造器
"""

import numpy as np
from src.da.da_registry import register_da

try:  # 依赖 filters 仓库
    from filter.non_batch.kalman import ExtendedKalmanFilter  # type: ignore
    import filter.non_batch.kalman.EKF as _ekf_mod  # type: ignore
    from filter.non_batch.common.helpers import reshape_z as _reshape_z  # type: ignore
    if not hasattr(_ekf_mod, 'reshape_z'):
        _ekf_mod.reshape_z = _reshape_z
    if not hasattr(_ekf_mod, 'linalg'):
        _ekf_mod.linalg = np.linalg
except ModuleNotFoundError as exc:
    raise ImportError(
        "未找到 filters.non_batch.kalman.EKF，请确认 filters 仓库在 PYTHONPATH 中"
    ) from exc


# ---------- 数值差分 Jacobian ------------------------------------
def numerical_jacobian(fun, x, eps: float = 1e-5):
    """
    fun : callable(x) -> ndarray(m,)   非线性函数
    x   : 1‑D ndarray(n,)
    eps : 差分步长
    Returns  J  shape=(m, n)
    """
    x = np.asarray(x, dtype=float)
    f0 = fun(x)
    m = f0.size
    n = x.size
    J = np.zeros((m, n), dtype=float)

    for i in range(n):
        dx = np.zeros(n)
        dx[i] = eps
        f1 = fun(x + dx)
        J[:, i] = (f1 - f0) / eps
    return J


# ---------- 带 controls 的 EKF 包装 ------------------------------
class _EKFWithControl(ExtendedKalmanFilter):
    def __init__(self, x0, P0, dt, hx, fx_core):
        dim_x = len(x0)
        super().__init__(dim_x=dim_x, dim_z=1)

        self.x = x0.reshape(-1, 1)
        self.P = P0
        self.Q = np.eye(dim_x) * 0.001
        self.R = np.eye(1) * 0.01
        self._dt = dt
        self._controls = None
        self._hx = hx
        self._fx_core = fx_core  # expects (state, dt, controls)

    # override predict so it accepts controls
    def predict(self, controls=None):
        self._controls = controls
        current = self.x.ravel().copy()
        F = numerical_jacobian(
            lambda x: self._fx_core(x, self._dt, controls=controls), current
        )
        self.F = F
        predicted = np.asarray(
            self._fx_core(current, self._dt, controls=controls), dtype=float
        ).reshape(-1, 1)
        self.x = predicted
        self.P = F @ self.P @ F.T + self.Q
        self.x_prior = self.x.copy()
        self.P_prior = self.P.copy()

    # override update so scalar z is accepted
    def update(self, z, R=None):
        if z is not None and not hasattr(z, "__len__"):
            z = np.asarray([z], dtype=float)
        H = numerical_jacobian(lambda x: self._hx(x), self.x.ravel())
        super().update(z, HJacobian=lambda _: H, Hx=lambda x: self._hx(x), R=R)


# ---------- 注册器函数 ------------------------------------------
@register_da("ekf")
def build_ekf(
    fx, hx, x0,
    P0=None, Q=None, R=None,
    dt_hours: float = 1.0
):
    dim_x = len(x0)
    P0 = P0 if P0 is not None else np.eye(dim_x) * 10.0

    ekf = _EKFWithControl(
        x0=x0,
        P0=P0,
        dt=dt_hours,
        hx=lambda x: np.asarray([hx(x)]),   # hx 输出 shape=(1,)
        fx_core=fx
    )
    if Q is not None:
        ekf.Q = Q
    if R is not None:
        ekf.R = R
    return ekf

