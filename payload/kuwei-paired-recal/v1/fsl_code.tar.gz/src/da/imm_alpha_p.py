"""
IMM-α_P: Interacting Multiple Model estimator with precipitation correction.

Ported from paper-imm-variable-params (Sun et al., 2026).

Each sub-filter (UKF) runs with a different multiplicative factor α_P on
precipitation input.  The IMM framework determines which α_P is most credible
at each timestep based on observation updates.

Key finding from the paper:  applying α_P correction during the **update
phase only** (not the forecast phase) gives the best lead-time forecast skill,
because it improves physical consistency of the updated state without
introducing systematic bias into the open-loop forecast trajectory.
"""

import numpy as np
from typing import List, Optional

from src.da.da_registry import register_da
from src.da.ukf import _build_ukf_common


class IMMAlphaPEstimator:
    """IMM estimator with per-filter precipitation correction factors.

    Wraps M UKF sub-filters. Each filter applies a different α_P to the
    rainfall component of the control vector during ``predict``.

    Presents a UKF-compatible interface (x, P, predict, update) so it can
    be used as a drop-in replacement in ``src.da.workflows.fh``.
    """

    def __init__(self, filters, alpha_p_values, M, mu0, hx):
        self.filters = filters
        self.alpha_p_values = np.asarray(alpha_p_values, dtype=float)
        self.M = np.asarray(M, dtype=float)        # transition matrix (n, n)
        self.mu = np.asarray(mu0, dtype=float)      # model probabilities (n,)
        self.n_models = len(filters)
        self._dim_x = filters[0]._dim_x
        self._dim_z = filters[0]._dim_z
        self._hx = hx

        # Combined state — fh.py reads these after each update.
        self.x = filters[0].x.copy()
        self.P = filters[0].P.copy()

        # Predicted model probabilities (set during interaction, used in update)
        self._c_bar = self.mu.copy()

        # History for analysis
        self.mu_history: list[np.ndarray] = []
        self.alpha_p_history: list[float] = []

    # ------------------------------------------------------------------
    # Public interface (matches UKF contract expected by fh.py)
    # ------------------------------------------------------------------

    @property
    def alpha_p_estimate(self) -> float:
        """Current IMM-weighted α_P estimate."""
        return float(self.mu @ self.alpha_p_values)

    def predict(self, controls=None, **kwargs):
        """IMM interaction step + per-filter predict with α_P-modified rain."""
        self._interaction_step()

        for i, filt in enumerate(self.filters):
            if controls is not None:
                filt.predict(controls=np.asarray(controls, dtype=float), **kwargs)
            else:
                filt.predict(**kwargs)

    def update(self, z, R=None, **kwargs):
        """Per-filter update, likelihood computation, probability & state combination."""
        z = np.atleast_1d(z) if z is not None else None

        if z is None or not np.all(np.isfinite(z)):
            self.finalize_prediction()
            return

        # 1. Predicted observations (before update) for likelihood
        z_preds = np.zeros((self.n_models, self._dim_z))
        for i, filt in enumerate(self.filters):
            z_preds[i] = np.asarray(self._hx(filt.x), dtype=float).ravel()[: self._dim_z]

        # 2. Update each sub-filter
        for filt in self.filters:
            filt.update(z, R=R, **kwargs)

        # 3. Likelihoods from pre-update innovations
        R_mat = self.filters[0].R if R is None else np.atleast_2d(R)
        likelihoods = np.zeros(self.n_models)
        for i in range(self.n_models):
            innovation = z - z_preds[i]
            likelihoods[i] = _gaussian_likelihood(innovation, R_mat)

        # 4. Update model probabilities
        self._update_probabilities(likelihoods)

        # 5. Record history
        self.mu_history.append(self.mu.copy())
        self.alpha_p_history.append(self.alpha_p_estimate)

        # 6. Compute combined x, P
        self._combination_step()

    def finalize_prediction(self):
        """Publish the combined predicted state when no observation is available."""
        probability_sum = float(self._c_bar.sum())
        if probability_sum > 0.0:
            self.mu = self._c_bar / probability_sum
        self._combination_step()
        self.mu_history.append(self.mu.copy())
        self.alpha_p_history.append(self.alpha_p_estimate)

    # ------------------------------------------------------------------
    # IMM internal steps
    # ------------------------------------------------------------------

    def _interaction_step(self):
        """Mix sub-filter states via Markov transition matrix."""
        n = self.n_models

        # Predicted probabilities:  c̄_j = Σ_i  M_{ij} μ_i
        c_bar = self.M.T @ self.mu
        c_bar = np.maximum(c_bar, 1e-30)
        self._c_bar = c_bar

        # Mixing weights:  μ(i|j) = M_{ij} μ_i / c̄_j
        mu_cond = (self.M * self.mu[:, None]) / c_bar[None, :]

        # Gather current sub-filter states
        xs = [filt.x.copy() for filt in self.filters]
        Ps = [filt.P.copy() for filt in self.filters]

        for j in range(n):
            # Mixed state:  x̃_j = Σ_i μ(i|j) x_i
            x_mixed = sum(mu_cond[i, j] * xs[i] for i in range(n))

            # Mixed covariance:  P̃_j = Σ_i μ(i|j) [P_i + δδᵀ]
            P_mixed = np.zeros_like(Ps[0])
            for i in range(n):
                d = xs[i] - x_mixed
                P_mixed += mu_cond[i, j] * (Ps[i] + np.outer(d, d))

            self.filters[j].x[:] = x_mixed
            self.filters[j].P[:] = P_mixed

    def _update_probabilities(self, likelihoods):
        """Bayes update:  μ_j ∝ c̄_j · L_j."""
        raw = self._c_bar * likelihoods
        total = raw.sum()
        if total > 1e-300:
            self.mu = raw / total

    def _combination_step(self):
        """Merge sub-filter estimates into combined IMM state."""
        self.x = sum(self.mu[j] * self.filters[j].x for j in range(self.n_models))

        self.P = np.zeros_like(self.filters[0].P)
        for j in range(self.n_models):
            d = self.filters[j].x - self.x
            self.P += self.mu[j] * (self.filters[j].P + np.outer(d, d))


# ------------------------------------------------------------------
# Helper
# ------------------------------------------------------------------

def _gaussian_likelihood(innovation: np.ndarray, R: np.ndarray) -> float:
    """Un-normalised Gaussian likelihood (sufficient for relative comparison)."""
    d = innovation.ravel()
    R_arr = np.atleast_2d(R)
    try:
        R_inv = np.linalg.inv(R_arr + np.eye(R_arr.shape[0]) * 1e-10)
        exponent = -0.5 * float(d @ R_inv @ d)
    except np.linalg.LinAlgError:
        exponent = -0.5 * float(d @ d)  # fallback
    return np.exp(np.clip(exponent, -500, 0))


# ------------------------------------------------------------------
# Registry builder
# ------------------------------------------------------------------

@register_da("imm_alpha_p")
def build_imm_alpha_p(
    fx, hx, x0,
    P0=None, Q=None, R=None,
    dt_hours=1.0,
    **kwargs,
):
    """Build IMM-α_P estimator with M UKF sub-filters.

    Extra kwargs consumed here:
        alpha_p_values: list[float]  — per-filter rain multipliers
        stay_prob: float             — diagonal of Markov transition matrix
    """
    alpha_p_values = kwargs.pop("alpha_p_values", [0.6, 0.8, 1.0, 1.2, 1.5])
    stay_prob = kwargs.pop("stay_prob", 0.98)
    n_models = len(alpha_p_values)

    filters = []
    for ap in alpha_p_values:
        def _make_fx(alpha_p_val):
            def fx_alpha(x, dt, controls=None, **kw):
                if controls is not None:
                    c = np.array(controls, dtype=float)
                    c[0] *= alpha_p_val
                    return fx(x, dt, controls=c, **kw)
                return fx(x, dt, controls=controls, **kw)
            return fx_alpha

        ukf = _build_ukf_common(
            _make_fx(ap), hx, x0.copy(),
            P0.copy() if P0 is not None else None,
            Q.copy() if Q is not None else None,
            R.copy() if R is not None else None,
            dt_hours,
            alpha=0.9, beta=2.0, kappa=0.0,
            kwargs=kwargs.copy(),
        )
        filters.append(ukf)

    # Markov transition matrix
    M_trans = np.full((n_models, n_models), (1 - stay_prob) / max(n_models - 1, 1))
    np.fill_diagonal(M_trans, stay_prob)

    mu0 = np.ones(n_models) / n_models

    return IMMAlphaPEstimator(filters, alpha_p_values, M_trans, mu0, hx)
