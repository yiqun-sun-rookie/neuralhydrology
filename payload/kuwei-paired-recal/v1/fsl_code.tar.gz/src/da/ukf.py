"""
UKF 构造器，并注册到 DA_REGISTRY

支持 Localization Mask (gain_mask) 用于物理阻断。
Mask 直接应用到 Kalman Gain 矩阵上。
"""
import sys
from pathlib import Path
from typing import Dict, Any, Optional
import math

import numpy as np

from src.da.da_registry import register_da

# 设置 filters 仓库路径
_PROJECT_ROOT = Path(__file__).resolve().parents[2]
_FILTERS_PATH_CANDIDATES = [
    _PROJECT_ROOT.parent / "filters",
    Path(r"G:/github/pycharm/projects/filters"),
]
for _candidate in _FILTERS_PATH_CANDIDATES:
    if _candidate.exists():
        if str(_candidate) not in sys.path:
            sys.path.insert(0, str(_candidate))
        _inner = _candidate / "filters"
        if _inner.exists() and str(_inner) not in sys.path:
            sys.path.insert(0, str(_inner))

_BACKEND = ""
_backend_errors: list[str] = []

try:  # 优先使用 filters 仓库
    from filters.filter.non_batch.kalman import UnscentedKalmanFilter as _BaseUKF, MerweScaledSigmaPoints  # type: ignore
    _BACKEND = "filters"
except Exception as exc:  # noqa: BLE001
    _backend_errors.append(f"filters backend failed: {exc!r}")
    try:
        from filterpy.kalman import UnscentedKalmanFilter as _BaseUKF, MerweScaledSigmaPoints  # type: ignore
        _BACKEND = "filterpy"
    except Exception as fallback_exc:  # noqa: BLE001
        _backend_errors.append(f"filterpy backend failed: {fallback_exc!r}")
        raise ImportError(
            "UKF backend 初始化失败，filters 与 filterpy 均不可用："
            + " | ".join(_backend_errors)
        ) from fallback_exc


class MaskedUKF(_BaseUKF):
    """
    支持 Localization Mask 的 UKF。

    重写 update 方法，将 mask 直接应用到 Kalman Gain K 上：
    K_masked = K * gain_mask
    """

    def update(self, z, R=None, gain_mask: Optional[np.ndarray] = None, **kwargs):
        """
        Update the UKF with measurement z.

        如果提供 gain_mask，则在计算 Kalman Gain 后应用：
        K_masked[i,j] = K[i,j] * gain_mask[i,j]

        这样可以实现：
        - ZMSK 观测（j=0）只更新 ZMSK 相关状态（gain_mask[:,0]=1 的位置）
        - QL 观测（j=1）只更新 QL 相关状态
        - YLX 观测（j=2）更新所有上游状态

        Args:
            z: measurement vector (dim_z,)
            R: measurement noise (optional)
            gain_mask: (dim_x, dim_z) binary mask
        """
        # Skip update for missing observations (NaN or None)
        if z is None or not np.all(np.isfinite(z)):
            return

        if gain_mask is None:
            # 无 mask，使用原始 update
            return super().update(z, R=R, **kwargs)

        # 需要手动实现 update 以便在 K 计算后应用 mask
        # 以下是标准 UKF update 的实现，加入了 mask 逻辑

        if z is None:
            self.x_post = self.x.copy()
            self.P_post = self.P.copy()
            return

        z = np.atleast_1d(z)

        if R is None:
            R = self.R
        elif np.isscalar(R):
            R = np.eye(self._dim_z) * R

        # 1. 将 sigma points 通过观测函数
        # 假设 sigmas_f 在 predict 时已计算
        sigmas_h = np.zeros((self._num_sigmas, self._dim_z))
        for i, s in enumerate(self.sigmas_f):
            sigmas_h[i] = self.hx(s)

        # 2. 计算预测观测的均值和协方差
        zp = np.dot(self.Wm, sigmas_h)

        # S = sum(Wc * (sigmas_h - zp) * (sigmas_h - zp)') + R
        Pz = np.zeros((self._dim_z, self._dim_z))
        for i in range(self._num_sigmas):
            y = sigmas_h[i] - zp
            Pz += self.Wc[i] * np.outer(y, y)
        Pz += R

        # 3. 计算交叉协方差 Pxz
        Pxz = np.zeros((self._dim_x, self._dim_z))
        for i in range(self._num_sigmas):
            dx = self.sigmas_f[i] - self.x
            dz = sigmas_h[i] - zp
            Pxz += self.Wc[i] * np.outer(dx, dz)

        # 4. 计算 Kalman Gain (with singular matrix protection)
        Pz += np.eye(self._dim_z) * 1e-8  # Regularize to prevent singular inversion
        try:
            K = np.dot(Pxz, np.linalg.inv(Pz))
        except np.linalg.LinAlgError:
            K = np.dot(Pxz, np.linalg.pinv(Pz))

        # === 关键：应用 Localization Mask ===
        K_masked = K * gain_mask

        # DEBUG: 打印 mask 效果（仅第一次）
        if not hasattr(self, '_mask_debug_printed'):
            self._mask_debug_printed = True
            n_blocked = np.sum(gain_mask == 0)
            n_total = gain_mask.size
            print(f"[MASK-DEBUG] K masked: {n_blocked}/{n_total} K elements zeroed out")
        # =====================================

        # 5. 更新状态
        y = z - zp  # 残差
        self.x = self.x + np.dot(K_masked, y)

        # 6. 更新协方差。P-KSK' 仅在 K=Pxz S^-1 时成立；mask 后的增益不再满足
        # 该恒等式，必须使用任意线性更新增益的完整协方差公式。
        self.P = (
            self.P
            - np.dot(K_masked, Pxz.T)
            - np.dot(Pxz, K_masked.T)
            + np.dot(K_masked, np.dot(Pz, K_masked.T))
        )

        # 确保 P 正定：对称化 + 添加小的正则化
        self.P = (self.P + self.P.T) / 2.0
        min_eig = np.min(np.linalg.eigvalsh(self.P))
        if min_eig < 1e-10:
            self.P += np.eye(self._dim_x) * (1e-10 - min_eig + 1e-8)

        # 保存后验
        self.x_post = self.x.copy()
        self.P_post = self.P.copy()
        self.y = y
        self.S = Pz
        self.K = K_masked


UnscentedKalmanFilter = MaskedUKF  # type: ignore




import math

def _build_ukf_common(
    fx, hx, x0,
    P0, Q, R, dt_hours,
    alpha: float, beta: float, kappa: float,
    kwargs
):
    from typing import Dict, Any
    dim_x = len(x0)
    # 推断 dim_z
    if R is not None:
        R_arr = np.asarray(R)
        dim_z = R_arr.shape[0] if R_arr.ndim >= 1 else 1
    else:
        dim_z = 1

    # 创建 Sigma Points
    points = MerweScaledSigmaPoints(
        n=dim_x, alpha=alpha, beta=beta, kappa=kappa
    )
    
    # 实例化 UKF
    ukf = UnscentedKalmanFilter(
        dim_x=dim_x,
        dim_z=dim_z,
        dt=dt_hours,
        fx=fx,
        hx=hx,
        points=points
    )
    ukf.x = np.asarray(x0, dtype=float)

    # 解析协方差配置
    cov = kwargs.copy()
    if "cov_opts" in cov:
        cov.update(cov.pop("cov_opts", {}))

    def _validated_diag(val, name: str):
        if val is None:
            return None
        if isinstance(val, tuple) and len(val) == 1 and isinstance(val[0], (list, np.ndarray)):
            val = val[0]
        val = np.asarray(val, dtype=float)
        if val.ndim == 0:
            val = np.full(dim_x, val)
        elif val.size == 1:
            val = np.full(dim_x, val.item())
        elif val.size != dim_x:
            raise ValueError(
                f"{name} 长度({val.size}) != dim_x({dim_x}). "
                f"请补齐或改用 *_scale."
            )
        return val

    EPS = 1e-8

    # ---------- P0 ----------
    if P0 is None:
        d = _validated_diag(cov.get("P0_diag"), "P0_diag")
        if d is not None:
            P0 = np.diag(d)
        elif "P0_scale" in cov and cov["P0_scale"] is not None:
            P0 = np.eye(dim_x) * float(cov["P0_scale"])
        else:
            P0 = np.eye(dim_x)
    P0 = np.asarray(P0, dtype=float) + np.eye(dim_x)*EPS

    # ---------- Q ----------
    if Q is None:
        d = _validated_diag(cov.get("Q_diag"), "Q_diag")
        if d is not None:
            Q = np.diag(d)
        elif "Q_scale" in cov and cov["Q_scale"] is not None:
            Q = np.eye(dim_x) * float(cov["Q_scale"])
        else:
            Q = np.eye(dim_x)*1e-4
    Q = np.asarray(Q, dtype=float) + np.eye(dim_x)*EPS

    # ---------- R ----------
    if R is None:
        if "R_diag" in cov and cov["R_diag"] is not None:
            d = np.asarray(cov["R_diag"], dtype=float)
            if d.ndim == 0:
                d = np.full(dim_z, d)
            if d.size != dim_z:
                raise ValueError("R_diag 长度与 dim_z 不符")
            R = np.diag(d)
        elif "R_scalar" in cov and cov["R_scalar"] is not None:
            R = np.array([[float(cov["R_scalar"])]], dtype=float)
        else:
            R = np.eye(dim_z)*0.05
    R = np.asarray(R, dtype=float) + np.eye(dim_z)*EPS

    ukf.P[:] = P0
    ukf.Q[:] = Q
    ukf.R[:] = R

    if cov.get("debug_print"):
        print(f"diag(P0) = {np.diag(ukf.P)[:min(10, dim_x)]}")
        print(f"diag(Q)  = {np.diag(ukf.Q)[:min(10, dim_x)]}")
        print(f"R        = {ukf.R}")

    return ukf


@register_da("ukf")
def build_ukf(
    fx, hx, x0,
    P0: np.ndarray | None = None,
    Q:  np.ndarray | None = None,
    R:  np.ndarray | None = None,
    dt_hours: float = 1.0,
    **kwargs: Dict[str, Any]
):
    """
    通用 UKF 构造器 (Standard UKF).
    Default params: alpha=0.9, beta=2.0, kappa=0.0
    """
    return _build_ukf_common(
        fx, hx, x0, P0, Q, R, dt_hours,
        alpha=0.9, beta=2.0, kappa=0.0,
        kwargs=kwargs
    )


@register_da("mukf")
def build_mukf(
    fx, hx, x0,
    P0: np.ndarray | None = None,
    Q:  np.ndarray | None = None,
    R:  np.ndarray | None = None,
    dt_hours: float = 1.0,
    **kwargs: Dict[str, Any]
):
    """
    Modified UKF (MUKF) 构造器.
    
    自动计算 alpha 和 kappa 以保证协方差矩阵的正定性.
    约束: 1 >= alpha^2 >= 2 - sqrt(4 - dim_x/(dim_x+kappa))
    """
    dim_x = len(x0)
    
    # 策略: 
    # 如果 dim_x <= 9, 选择 kappa 使得 dim_x + kappa = 3
    # 否则使用 kappa = 0 (或 3 - dim_x, 但这会导致非常负的 kappa)
    
    if dim_x <= 9:
        kappa = 3.0 - dim_x
    else:
        kappa = 0.0
        
    # 计算 alpha 约束
    n = float(dim_x)
    k = float(kappa)
    
    denom = n + k
    if abs(denom) < 1e-9: 
        target_term = 0.0
    else:
        target_term = n / denom
        
    discriminant = 4.0 - target_term
    
    if discriminant < 0:
        print(f"[MUKF-WARN] Discriminant < 0 ({discriminant:.4f}), using fallback alpha=0.9.")
        alpha = 0.9
    else:
        right_rhs = 2.0 - math.sqrt(discriminant)
        lower_bound_sq = max(1e-6, right_rhs)
        
        if lower_bound_sq > 1.0:
             print(f"[MUKF-WARN] No valid alpha for MUKF (lower_bound_sq={lower_bound_sq:.4f}). Using alpha=1.0")
             alpha = 1.0
        else:
             # 为了稳定性，取下界稍微大一点点
             chosen_sq = max(0.5, lower_bound_sq + 1e-3)
             if chosen_sq > 1.0: chosen_sq = 1.0
             alpha = math.sqrt(chosen_sq)
             
    beta = 2.0
    
    if kwargs.get("cov_opts", {}).get("debug_print", False):
        print(f"[MUKF] dim_x={dim_x}, kappa={kappa}, alpha={alpha:.4f} (sq={alpha**2:.4f})")

    return _build_ukf_common(
        fx, hx, x0, P0, Q, R, dt_hours,
        alpha=alpha, beta=beta, kappa=kappa,
        kwargs=kwargs
    )

