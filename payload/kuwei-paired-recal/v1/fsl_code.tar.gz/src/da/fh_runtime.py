"""共享的 FH 同化上下文缓存。

DataProvider 在完成昂贵的 FH 会话构建后，可把上下文存入此处，
模型适配器再从这里读取，避免重复工作。
"""

from __future__ import annotations

from typing import Any, Dict, Optional


_FH_CONTEXT: Optional[Dict[str, Any]] = None


def set_fh_context(ctx: Dict[str, Any]) -> None:
    """保存最新的 FH 上下文。"""

    if not isinstance(ctx, dict):
        raise TypeError("FH context 必须是 dict")
    global _FH_CONTEXT
    _FH_CONTEXT = ctx


def get_fh_context() -> Dict[str, Any]:
    """获取当前 FH 上下文。若尚未初始化，则抛出错误。"""

    if _FH_CONTEXT is None:
        raise RuntimeError("FH runtime context 未初始化，请先运行 FHDataProvider.load")
    return _FH_CONTEXT


def clear_fh_context() -> None:
    """清除缓存，便于测试。"""

    global _FH_CONTEXT
    _FH_CONTEXT = None



