"""
src.da  包的初始化
把默认 DA 模块提前 import，使其自动完成注册
"""

from .da_registry import get_da_builder, register_da   # 对外暴露

# ------------- 自动注册内置 DA -------------
from . import ukf  # noqa: F401  (确保 ukf.py 执行一次，完成注册)
from . import imm_alpha_p  # noqa: F401
try:  # pragma: no cover
    from . import enkf  # noqa: F401
except Exception:
    pass
try:  # pragma: no cover
    from . import ekf  # noqa: F401
except Exception:
    pass

# ------------- 默认模型适配器 / 数据提供者注册 -------------
from .adapters import fh_model_adapter  # noqa: F401
from .providers import fh_provider  # noqa: F401

try:  # pragma: no cover
    from .adapters import walrus_adapter  # noqa: F401
    from .providers import walrus_provider  # noqa: F401
except ImportError as exc:  # pragma: no cover
    print(f"[src.da] Walrus adapter unavailable: {exc}")
# 若以后还有 enkf.py / pf.py 等，也在这里 import 一行
