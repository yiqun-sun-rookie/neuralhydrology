"""SQLite timeseries storage layer for forecast system.

Provides DB connection, schema creation, and CRUD helpers.
One DB file per basin: basins/<name>/data/timeseries.db
"""
from __future__ import annotations

import sqlite3
from pathlib import Path

import pandas as pd

SCHEMA_VERSION = 1

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS meteo (
    time    TEXT NOT NULL PRIMARY KEY,
    rain    REAL NOT NULL,
    temp    REAL NOT NULL,
    pet     REAL NOT NULL,
    snow    REAL NOT NULL DEFAULT 0.0,
    source  TEXT DEFAULT 'era5'
);

CREATE TABLE IF NOT EXISTS discharge (
    time      TEXT NOT NULL PRIMARY KEY,
    discharge REAL NOT NULL,
    source    TEXT DEFAULT 'station'
);

CREATE TABLE IF NOT EXISTS forecast_input (
    issue_time  TEXT NOT NULL,
    valid_time  TEXT NOT NULL,
    variable    TEXT NOT NULL,
    value       REAL NOT NULL,
    source      TEXT NOT NULL,
    PRIMARY KEY (issue_time, valid_time, variable, source)
);
CREATE INDEX IF NOT EXISTS idx_fi_valid ON forecast_input(valid_time);

CREATE TABLE IF NOT EXISTS schema_version (
    version    INTEGER PRIMARY KEY,
    applied_at TEXT NOT NULL
);
"""


def open_db(path: str | Path) -> sqlite3.Connection:
    """Open (or create) a SQLite DB with WAL mode and recommended pragmas."""
    conn = sqlite3.connect(str(path))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def ensure_schema(conn: sqlite3.Connection) -> None:
    """Create tables if they don't exist. Idempotent."""
    conn.executescript(_SCHEMA_SQL)
    existing = conn.execute("SELECT version FROM schema_version").fetchone()
    if existing is None:
        conn.execute(
            "INSERT INTO schema_version (version, applied_at) VALUES (?, datetime('now'))",
            (SCHEMA_VERSION,),
        )
        conn.commit()


def insert_meteo(conn: sqlite3.Connection, rows: list[tuple]) -> int:
    """Insert meteo rows: [(time, rain, temp, pet, snow, source), ...].

    Uses INSERT OR IGNORE for idempotent ingestion.
    Returns number of rows inserted.
    """
    cursor = conn.executemany(
        "INSERT OR IGNORE INTO meteo (time, rain, temp, pet, snow, source) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        rows,
    )
    conn.commit()
    return cursor.rowcount


def insert_discharge(conn: sqlite3.Connection, rows: list[tuple]) -> int:
    """Insert discharge rows: [(time, discharge, source), ...].

    Uses INSERT OR IGNORE for idempotent ingestion.
    Returns number of rows inserted.
    """
    cursor = conn.executemany(
        "INSERT OR IGNORE INTO discharge (time, discharge, source) VALUES (?, ?, ?)",
        rows,
    )
    conn.commit()
    return cursor.rowcount


def query_meteo(
    conn: sqlite3.Connection,
    start: str,
    end: str,
    *,
    exclude_years: list[int] | None = None,
) -> pd.DataFrame:
    """Query meteo data for a time range. Returns DataFrame with columns
    [time, rain, temp, pet, snow], time as datetime."""
    sql = "SELECT time, rain, temp, pet, snow FROM meteo WHERE time >= ? AND time <= ? ORDER BY time"
    df = pd.read_sql_query(sql, conn, params=(start, end), parse_dates=["time"])
    if exclude_years:
        df = df[~df["time"].dt.year.isin(exclude_years)]
    return df.reset_index(drop=True)


def query_discharge(
    conn: sqlite3.Connection,
    start: str,
    end: str,
    *,
    exclude_years: list[int] | None = None,
) -> pd.Series:
    """Query discharge observations for a time range.
    Returns Series indexed by DatetimeIndex."""
    sql = "SELECT time, discharge FROM discharge WHERE time >= ? AND time <= ? ORDER BY time"
    df = pd.read_sql_query(sql, conn, params=(start, end), parse_dates=["time"])
    if exclude_years:
        df = df[~df["time"].dt.year.isin(exclude_years)]
    series = df.set_index("time")["discharge"]
    series = series[~series.index.duplicated(keep="first")]
    return series
