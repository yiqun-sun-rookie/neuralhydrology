"""Correlation-weighted areal-average rainfall.

Uses station reliability from rain_qc to weight stations dynamically.
Unreliable stations get zero weight; weights are based on inter-station
correlation computed from clean (reliable) data.

Usage (CLI):
    python -m src.data.rain_spatial --basin namou_kuwei
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.data.rain_qc import STATION_COL_TO_KEY, run_qc


def compute_correlation_weights(
    rain_df: pd.DataFrame,
    reliable: pd.DataFrame,
) -> dict[str, float]:
    """Compute base weights from inter-station correlation on clean data.

    For each station, compute its mean correlation with all other stations
    using only mutually reliable timesteps. Higher correlation = more
    representative = higher base weight.

    Returns
    -------
    dict mapping station column name to base weight (sums to 1.0).
    """
    station_cols = list(reliable.columns)
    clean = rain_df[station_cols].copy()
    # Mask unreliable data
    clean[~reliable] = np.nan

    # Use daily totals for more stable correlation
    daily = clean.resample("D").sum(min_count=12)  # need at least 12h/day

    corr = daily.corr(min_periods=30)

    weights = {}
    for col in station_cols:
        # Mean correlation with other stations (excluding self = 1.0)
        others = [c for c in station_cols if c != col]
        if others:
            mean_corr = corr.loc[col, others].mean()
            weights[col] = max(mean_corr, 0.0)  # floor at 0
        else:
            weights[col] = 1.0

    # Normalize
    total = sum(weights.values())
    if total > 0:
        weights = {k: v / total for k, v in weights.items()}
    else:
        # Equal weight fallback
        n = len(station_cols)
        weights = {k: 1.0 / n for k in station_cols}

    return weights


def weighted_areal_average(
    rain_df: pd.DataFrame,
    reliable: pd.DataFrame,
    base_weights: dict[str, float],
) -> pd.DataFrame:
    """Compute dynamic weighted areal average rainfall.

    At each timestep:
    - Only reliable stations contribute
    - Their base weights are renormalized to sum to 1.0
    - If 0 stations reliable: use previous timestep's value

    Parameters
    ----------
    rain_df : DataFrame
        Hourly rainfall, columns = stations, index = DatetimeIndex.
    reliable : DataFrame
        Boolean reliability mask (True = reliable).
    base_weights : dict
        Pre-computed correlation-based weights.

    Returns
    -------
    DataFrame with columns: rain_g0, n_stations, source
    """
    station_cols = list(reliable.columns)
    n = len(rain_df)

    rain_g0 = np.full(n, np.nan, dtype=np.float64)
    n_stations = np.zeros(n, dtype=np.int32)
    sources = []

    weight_arr = np.array([base_weights[c] for c in station_cols])
    rain_arr = rain_df[station_cols].values
    rel_arr = reliable.values

    last_valid = 0.0

    for i in range(n):
        mask = rel_arr[i, :]  # which stations are reliable
        n_good = mask.sum()

        if n_good == 0:
            # No reliable station — use last valid value
            rain_g0[i] = last_valid
            n_stations[i] = 0
            sources.append("fallback")
            continue

        # Renormalize weights for available stations
        w = weight_arr * mask.astype(float)
        w_sum = w.sum()
        if w_sum > 0:
            w = w / w_sum
        else:
            w = mask.astype(float) / n_good

        vals = np.where(np.isnan(rain_arr[i, :]), 0.0, rain_arr[i, :])
        rain_g0[i] = np.dot(w, vals)
        n_stations[i] = n_good
        last_valid = rain_g0[i]

        active = [station_cols[j] for j in range(len(station_cols)) if mask[j]]
        sources.append("+".join(active))

    result = pd.DataFrame(
        {
            "rain_g0": rain_g0,
            "n_stations": n_stations,
            "source": sources,
        },
        index=rain_df.index,
    )
    result.index.name = "time"
    return result


def generate_qc_meteo(basin_name: str) -> Path:
    """Full pipeline: QC -> weight -> areal average -> write CSV.

    Reads existing grid_meteo to get temp/pet/snow, replaces rain_g0
    with QC-weighted areal average.

    Returns path to output CSV.
    """
    basin_dir = PROJECT_ROOT / "basins" / basin_name
    data_dir = basin_dir / "data"
    raw_dir = data_dir / "raw"

    # Step 1: Run QC
    rain_df, reliable = run_qc(basin_name)

    # Step 2: Compute correlation weights
    base_weights = compute_correlation_weights(rain_df, reliable)
    print("\n=== Correlation-based base weights ===")
    for col, w in base_weights.items():
        print(f"  {col:15s}: {w:.4f}")

    # Step 3: Compute weighted areal average
    areal = weighted_areal_average(rain_df, reliable, base_weights)
    print(f"\n=== Areal average summary ===")
    print(f"  Mean n_stations: {areal['n_stations'].mean():.2f}")
    print(f"  Zero-station hours: {(areal['n_stations'] == 0).sum()}")
    print(f"  Mean rain_g0: {areal['rain_g0'].mean():.4f} mm/h")

    # Step 4: Build output CSV from existing meteo
    # Find existing meteo file for temp/pet/snow
    meteo_path = raw_dir / "grid_meteo_pet_hourly_era5_pet.csv"
    if not meteo_path.exists():
        candidates = sorted(raw_dir.glob("grid_meteo_pet_hourly*.csv"))
        if not candidates:
            raise FileNotFoundError(f"No grid_meteo CSV found in {raw_dir}")
        meteo_path = candidates[0]

    meteo = pd.read_csv(meteo_path, parse_dates=["time"], index_col="time")

    # Align time indices
    common_idx = meteo.index.intersection(areal.index)
    if len(common_idx) == 0:
        raise ValueError("No overlapping timestamps between rain and meteo data")

    output = meteo.loc[common_idx].copy()
    output["rain_g0"] = areal.loc[common_idx, "rain_g0"].values

    # Write output
    out_path = raw_dir / "grid_meteo_pet_hourly_qc.csv"
    output.to_csv(out_path, float_format="%.6f")
    print(f"\nQC meteo written to: {out_path}")
    print(f"  Rows: {len(output)}")

    # Also save the reliability matrix and source log
    areal_out = raw_dir / "rain_qc_areal_average.csv"
    areal.to_csv(areal_out, float_format="%.6f")
    print(f"Areal average log saved to: {areal_out}")

    return out_path


def main(argv: list[str] | None = None):
    parser = argparse.ArgumentParser(description="Generate QC-weighted areal average rainfall")
    parser.add_argument("--basin", required=True, help="Basin name")
    args = parser.parse_args(argv)

    generate_qc_meteo(args.basin)


if __name__ == "__main__":
    main()
