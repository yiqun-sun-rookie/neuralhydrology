"""Data ingestion: pull new data from external APIs into timeseries.db.

Usage:
    python -m src.data.ingest --basin namou_kuwei --source open_meteo
"""
from __future__ import annotations

import argparse
import sys
from datetime import datetime, timedelta
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.data.tsdb import open_db, ensure_schema, insert_meteo


def get_last_timestamp(conn, table: str) -> str | None:
    """Get the latest timestamp in a table."""
    row = conn.execute(f"SELECT MAX(time) FROM {table}").fetchone()
    return row[0] if row and row[0] else None


def ingest_open_meteo(
    conn,
    *,
    latitude: float,
    longitude: float,
    start_date: str | None = None,
) -> int:
    """Pull hourly forecast/historical data from Open-Meteo API.

    If start_date is None, resumes from last timestamp in DB.
    Returns number of new rows inserted.
    """
    import urllib.request
    import json

    if start_date is None:
        last = get_last_timestamp(conn, "meteo")
        if last:
            # Start from day after last timestamp
            dt = datetime.fromisoformat(last) + timedelta(hours=1)
            start_date = dt.strftime("%Y-%m-%d")
        else:
            raise ValueError("DB is empty and no start_date provided")

    end_date = datetime.utcnow().strftime("%Y-%m-%d")

    url = (
        f"https://archive-api.open-meteo.com/v1/archive?"
        f"latitude={latitude}&longitude={longitude}"
        f"&start_date={start_date}&end_date={end_date}"
        f"&hourly=temperature_2m,precipitation,et0_fao_evapotranspiration"
        f"&timezone=UTC"
    )

    req = urllib.request.Request(url)
    with urllib.request.urlopen(req, timeout=30) as resp:
        data = json.loads(resp.read().decode())

    hourly = data.get("hourly", {})
    times = hourly.get("time", [])
    temps = hourly.get("temperature_2m", [])
    rains = hourly.get("precipitation", [])
    pets = hourly.get("et0_fao_evapotranspiration", [])

    rows = []
    for i, t in enumerate(times):
        time_str = t.replace("T", " ") + ":00" if len(t) == 13 else t.replace("T", " ")
        rain = float(rains[i]) if rains[i] is not None else 0.0
        temp = float(temps[i]) if temps[i] is not None else 0.0
        pet = float(pets[i]) if pets[i] is not None else 0.0
        rows.append((time_str, rain, temp, pet, 0.0, "open_meteo"))

    n = insert_meteo(conn, rows)
    print(f"[INGEST] open_meteo: {len(rows)} rows fetched, {n} new rows inserted")
    return n


def main(argv: list[str] | None = None):
    parser = argparse.ArgumentParser(description="Ingest data into timeseries.db")
    parser.add_argument("--basin", required=True)
    parser.add_argument("--source", required=True, choices=["open_meteo"])
    parser.add_argument("--start-date", default=None, help="Override start date (YYYY-MM-DD)")
    parser.add_argument("--lat", type=float, default=None)
    parser.add_argument("--lon", type=float, default=None)
    args = parser.parse_args(argv)

    basin_dir = PROJECT_ROOT / "basins" / args.basin
    db_path = basin_dir / "data" / "timeseries.db"
    if not db_path.exists():
        raise FileNotFoundError(
            f"No timeseries.db for basin {args.basin}. Run migrate_csv first."
        )

    conn = open_db(db_path)
    ensure_schema(conn)

    if args.source == "open_meteo":
        # Read centroid from run_config if lat/lon not provided
        lat, lon = args.lat, args.lon
        if lat is None or lon is None:
            import yaml
            rc = basin_dir / "config" / "run_config.yml"
            if rc.exists():
                with open(rc, "r", encoding="utf-8") as f:
                    cfg = yaml.safe_load(f)
                centroid = (cfg.get("scene") or {}).get("centroid", [])
                if len(centroid) == 2:
                    lat, lon = centroid
            if lat is None or lon is None:
                raise ValueError("Provide --lat/--lon or set scene.centroid in run_config.yml")

        ingest_open_meteo(conn, latitude=lat, longitude=lon, start_date=args.start_date)

    conn.close()


if __name__ == "__main__":
    main()
