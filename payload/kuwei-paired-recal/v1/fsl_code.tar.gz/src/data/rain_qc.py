"""Rainfall quality control module.

Reads station_fault_registry.yml to blacklist known fault periods.
Produces a boolean reliability matrix: is_reliable[station, time].

Only uses confirmed equipment faults from the registry — no statistical
heuristics (those were removed due to false-positive risk with only 4 stations
and tropical convective variability).

Usage (CLI):
    python -m src.data.rain_qc --basin namou_kuwei
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# Station column names in rain.csv -> registry keys
STATION_COL_TO_KEY = {
    "mengwu": "mengwu",
    "kuwei_rain": "kuwei",
    "banteng": "banteng",
    "aka": "aka",
}

STATION_KEY_TO_COL = {v: k for k, v in STATION_COL_TO_KEY.items()}


def load_fault_registry(path: Path) -> dict:
    """Load station_fault_registry.yml and return parsed dict."""
    if not path.exists():
        raise FileNotFoundError(f"Fault registry not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def build_blacklist_mask(
    rain_df: pd.DataFrame,
    registry: dict,
) -> pd.DataFrame:
    """Build a boolean mask from fault registry blacklist periods.

    Parameters
    ----------
    rain_df : DataFrame
        Index = DatetimeIndex, columns = station column names.
    registry : dict
        Parsed station_fault_registry.yml.

    Returns
    -------
    DataFrame of same shape as rain_df, True = blacklisted (unreliable).
    """
    blacklist = pd.DataFrame(False, index=rain_df.index, columns=rain_df.columns)
    stations = registry.get("stations", {})

    for col_name, reg_key in STATION_COL_TO_KEY.items():
        if col_name not in blacklist.columns:
            continue
        station_info = stations.get(reg_key, {})
        faults = station_info.get("faults", [])
        for fault in faults:
            if fault.get("severity") != "blacklist":
                continue
            affected = fault.get("affected", "rain")
            if affected != "rain":
                continue
            start = pd.Timestamp(fault["start"])
            end = pd.Timestamp(fault["end"]) + pd.Timedelta(hours=23)
            mask = (rain_df.index >= start) & (rain_df.index <= end)
            blacklist.loc[mask, col_name] = True

    return blacklist


def compute_reliability(
    rain_df: pd.DataFrame,
    registry: dict,
) -> pd.DataFrame:
    """Compute per-station, per-timestep reliability.

    Unreliable = blacklisted by fault registry OR NaN.

    Returns
    -------
    DataFrame, True = reliable, False = unreliable.
    """
    station_cols = [c for c in rain_df.columns if c in STATION_COL_TO_KEY]
    rain = rain_df[station_cols].copy()

    blacklist = build_blacklist_mask(rain, registry)
    unreliable = blacklist | rain.isna()

    return ~unreliable


def load_rain_data(basin_name: str) -> pd.DataFrame:
    """Load per-station hourly rain CSV for a basin."""
    # SSOT: laos_forecast/data/03_final/<basin>/rain.csv (fsl/laos are siblings under projects/)
    rain_path = PROJECT_ROOT.parent / "laos_forecast" / "data" / "03_final" / basin_name / "rain.csv"
    if not rain_path.exists():
        raise FileNotFoundError(f"Rain data not found: {rain_path}")
    df = pd.read_csv(rain_path, parse_dates=["time"], index_col="time")
    return df


def run_qc(basin_name: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Run QC pipeline for a basin.

    Returns
    -------
    (rain_df, reliable_df) : tuple of DataFrames
        rain_df has station columns, reliable_df has matching boolean mask.
    """
    rain_df = load_rain_data(basin_name)
    registry_path = (
        PROJECT_ROOT / "basins" / basin_name / "config" / "station_fault_registry.yml"
    )
    registry = load_fault_registry(registry_path)
    reliable = compute_reliability(rain_df, registry)
    return rain_df, reliable


def main(argv: list[str] | None = None):
    parser = argparse.ArgumentParser(description="Rainfall quality control")
    parser.add_argument("--basin", required=True, help="Basin name")
    args = parser.parse_args(argv)

    rain_df, reliable = run_qc(args.basin)

    station_cols = [c for c in rain_df.columns if c in STATION_COL_TO_KEY]
    print(f"\n=== Rain QC Summary (blacklist only) ===")
    print(f"Period: {rain_df.index[0]} to {rain_df.index[-1]}")
    print(f"Total timesteps: {len(rain_df)}")
    print()
    for col in station_cols:
        n_total = len(reliable)
        n_reliable = reliable[col].sum()
        n_unreliable = n_total - n_reliable
        pct = n_unreliable / n_total * 100
        print(f"  {col:15s}: {n_unreliable:6d} unreliable ({pct:5.1f}%)")

    out_dir = PROJECT_ROOT / "basins" / args.basin / "data" / "raw"
    out_path = out_dir / "rain_reliability.csv"
    reliable.to_csv(out_path)
    print(f"\nReliability matrix saved to: {out_path}")


if __name__ == "__main__":
    main()
