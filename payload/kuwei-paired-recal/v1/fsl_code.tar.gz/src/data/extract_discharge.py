"""Extract and correct kuwei station discharge from MDB + xlsm sources.

The MDB (qijib.mdb) has hourly stage-discharge data for kuwei (CGB088004),
identical to the xlsm measured values. However, from 2019-10 onwards the MDB
timestamps are progressively offset (reaching +24h by 2020-01). This script:

  1. Reads MDB hourly data (primary: no interpolation needed)
  2. Reads xlsm 3h data (reference: correct timestamps)
  3. Auto-detects and corrects MDB time offsets using cross-correlation
  4. Fills the transition gap (2019.10-2019.12) with xlsm interpolated values
  5. Validates corrected MDB against xlsm
  6. Outputs standard discharge CSV

Usage:
    python -m src.data.extract_discharge \
        --mdb path/to/qijib.mdb \
        --xlsm path/to/七级水情数据（3小时）.xlsm \
        --basin namou_kuwei

Future use:
    from src.data.extract_discharge import extract_kuwei_discharge
    df = extract_kuwei_discharge(mdb_path, xlsm_path)
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

MDB_STATION_CODE = "CGB088004"


# ---------------------------------------------------------------------------
# Source readers
# ---------------------------------------------------------------------------

def read_mdb(mdb_path: Path) -> pd.DataFrame:
    """Read hourly kuwei discharge from MDB. Returns DataFrame[time, stage, q]."""
    import pyodbc

    conn_str = (
        r"DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};"
        f"DBQ={mdb_path};"
    )
    conn = pyodbc.connect(conn_str)
    cursor = conn.cursor()
    cursor.execute(
        f"SELECT ymdhm, zr, q FROM st_river_r "
        f"WHERE stcd='{MDB_STATION_CODE}' ORDER BY ymdhm"
    )
    rows = [(r[0], r[1], r[2]) for r in cursor.fetchall()]
    conn.close()

    df = pd.DataFrame(rows, columns=["time", "stage", "q"])
    df["time"] = pd.to_datetime(df["time"])
    df["stage"] = pd.to_numeric(df["stage"], errors="coerce")
    df["q"] = pd.to_numeric(df["q"], errors="coerce")
    return df.set_index("time").sort_index()


def read_xlsm(xlsm_path: Path) -> pd.DataFrame:
    """Read 3h kuwei discharge from xlsm. Returns DataFrame[time, stage, q]."""
    import openpyxl

    wb = openpyxl.load_workbook(str(xlsm_path), read_only=True, data_only=True)
    records = []

    for sheet_name in wb.sheetnames:
        if "降雨" in sheet_name:
            continue
        ws = wb[sheet_name]
        header = list(ws.iter_rows(min_row=4, max_row=4, values_only=True))[0]
        if not any("流量" in str(c) for c in header if c):
            continue

        cur_mo, cur_dy = None, None
        for row in ws.iter_rows(min_row=5, values_only=True):
            yr = row[0]
            if yr is None or not isinstance(yr, (int, float)):
                continue
            yr = int(yr)
            if row[1] is not None:
                cur_mo = int(row[1])
            if row[2] is not None:
                cur_dy = int(row[2])
            if row[3] is None or cur_mo is None or cur_dy is None:
                continue
            try:
                ts = pd.Timestamp(yr, cur_mo, cur_dy, int(row[3]))
            except ValueError:
                continue

            def _safe_float(v):
                if v is None:
                    return np.nan
                try:
                    return float(str(v).strip())
                except (ValueError, AttributeError):
                    return np.nan

            records.append({
                "time": ts,
                "stage": _safe_float(row[4]),
                "q": _safe_float(row[5]),
            })

    wb.close()
    df = pd.DataFrame(records)
    df = df.drop_duplicates("time").set_index("time").sort_index()
    return df


# ---------------------------------------------------------------------------
# Time offset detection & correction
# ---------------------------------------------------------------------------

def detect_offset_hours(
    mdb: pd.DataFrame,
    xlsm: pd.DataFrame,
    year: int,
    max_lag: int = 48,
) -> int:
    """Find the MDB time offset (hours) for a given year by cross-correlation.

    Returns offset such that mdb.index - offset aligns with xlsm.
    """
    mdb_yr = mdb.loc[mdb.index.year == year, "q"].dropna()
    xlsm_yr = xlsm.loc[xlsm.index.year == year, "q"].dropna()
    if len(mdb_yr) < 50 or len(xlsm_yr) < 50:
        return 0

    best_r, best_lag = -1.0, 0
    for lag_h in range(-max_lag, max_lag + 1):
        shifted = xlsm_yr.index + pd.Timedelta(hours=lag_h)
        common = shifted.intersection(mdb_yr.index)
        if len(common) < 50:
            continue
        x = xlsm_yr.loc[xlsm_yr.index.isin(common - pd.Timedelta(hours=lag_h))]
        m = mdb_yr.loc[common]
        if len(x) != len(m):
            continue
        r = np.corrcoef(x.values, m.values)[0, 1]
        if r > best_r:
            best_r = r
            best_lag = lag_h

    return best_lag


def correct_mdb(
    mdb: pd.DataFrame,
    xlsm: pd.DataFrame,
) -> pd.DataFrame:
    """Correct MDB timestamps using xlsm as reference.

    Strategy:
      - Per-year offset detection via cross-correlation
      - Years with offset=0 and perfect match: use MDB directly
      - Years with stable offset (e.g. +24h): shift MDB timestamps
      - Transition periods with unstable offset: fall back to xlsm interpolated
    """
    years = sorted(mdb.index.year.unique())
    corrected_parts = []

    for yr in years:
        offset_h = detect_offset_hours(mdb, xlsm, yr)
        mdb_yr = mdb.loc[mdb.index.year == yr].copy()

        if offset_h == 0:
            # Verify it's actually correct (not just low-corr default)
            xlsm_yr = xlsm.loc[xlsm.index.year == yr, "q"]
            common = mdb_yr.index.intersection(xlsm_yr.index)
            if len(common) > 50:
                exact = ((mdb_yr.loc[common, "q"] - xlsm_yr.loc[common]).abs() < 0.1).sum()
                match_pct = exact / len(common)
            else:
                match_pct = 1.0

            if match_pct > 0.9:
                corrected_parts.append(mdb_yr)
                print(f"  {yr}: offset=0h, match={match_pct:.0%} → use MDB directly")
            else:
                # Partial year offset (e.g. 2019: 0h until Oct, then drifting)
                # Split at the first mismatch and use xlsm for the rest
                _handle_transition_year(
                    yr, mdb_yr, xlsm, corrected_parts, match_pct
                )
        else:
            # Apply fixed shift
            shifted = mdb_yr.copy()
            shifted.index = shifted.index - pd.Timedelta(hours=offset_h)
            # Validate
            xlsm_yr = xlsm.loc[xlsm.index.year == yr, "q"]
            common = shifted.index.intersection(xlsm_yr.index)
            if len(common) > 50:
                exact = ((shifted.loc[common, "q"] - xlsm_yr.loc[common]).abs() < 0.1).sum()
                match_pct = exact / len(common)
            else:
                match_pct = 0.0
            corrected_parts.append(shifted)
            print(f"  {yr}: offset={offset_h:+d}h, post-shift match={match_pct:.0%}")

    result = pd.concat(corrected_parts).sort_index()
    result = result[~result.index.duplicated(keep="first")]
    return result


def _handle_transition_year(
    yr: int,
    mdb_yr: pd.DataFrame,
    xlsm: pd.DataFrame,
    parts: list,
    overall_match: float,
):
    """Handle a year where offset changes mid-year (e.g. 2019)."""
    xlsm_yr = xlsm.loc[xlsm.index.year == yr, "q"]
    common = mdb_yr.index.intersection(xlsm_yr.index)
    if len(common) == 0:
        parts.append(mdb_yr)
        return

    # Find the first persistent mismatch
    diffs = (mdb_yr.loc[common, "q"] - xlsm_yr.loc[common]).abs()
    mismatch = diffs[diffs >= 0.1]

    if len(mismatch) == 0:
        parts.append(mdb_yr)
        print(f"  {yr}: offset=0h, match=100% → use MDB directly")
        return

    split_time = mismatch.index[0]
    print(f"  {yr}: offset drifts from {split_time.strftime('%m-%d')}, "
          f"match={overall_match:.0%}")

    # Before split: use MDB (correct)
    good_part = mdb_yr.loc[mdb_yr.index < split_time]
    if len(good_part) > 0:
        parts.append(good_part)
        print(f"    → MDB direct: {good_part.index[0]} ~ {good_part.index[-1]}")

    # After split: interpolate xlsm 3h → 1h (safer than fixing variable offset)
    xlsm_after = xlsm.loc[
        (xlsm.index >= split_time) & (xlsm.index.year == yr)
    ].copy()
    if len(xlsm_after) > 0:
        end_time = xlsm_after.index[-1]
        full_idx = pd.date_range(split_time, end_time, freq="h")
        interp = xlsm_after.reindex(full_idx).interpolate(method="time")
        parts.append(interp)
        print(f"    → xlsm interp: {split_time} ~ {end_time}")


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------

def extract_kuwei_discharge(
    mdb_path: Path,
    xlsm_path: Path,
    *,
    start: str = "2014-01-01",
    end: str | None = None,
) -> pd.DataFrame:
    """Extract corrected hourly kuwei discharge.

    Returns DataFrame with DatetimeIndex and columns [q_obs].
    """
    print("[extract] Reading MDB...")
    mdb = read_mdb(mdb_path)
    print(f"  MDB: {len(mdb)} rows, {mdb.index[0]} ~ {mdb.index[-1]}")

    print("[extract] Reading xlsm...")
    xlsm = read_xlsm(xlsm_path)
    print(f"  xlsm: {len(xlsm)} rows, {xlsm.index[0]} ~ {xlsm.index[-1]}")

    print("[extract] Correcting MDB timestamps...")
    corrected = correct_mdb(mdb, xlsm)

    # Trim to requested range
    if end is None:
        end = corrected.index[-1].strftime("%Y-%m-%d %H:%M:%S")
    corrected = corrected.loc[start:end]

    # Final validation against xlsm
    common = corrected.index.intersection(xlsm.index)
    if len(common) > 0:
        diff = (corrected.loc[common, "q"] - xlsm.loc[common, "q"]).abs()
        exact = (diff < 0.1).sum()
        print(f"\n[validate] Corrected vs xlsm: {exact}/{len(common)} "
              f"exact match ({exact / len(common):.1%})")
        if exact / len(common) < 0.95:
            print(f"  WARNING: match rate below 95%, check data!")

    # Output format
    out = corrected[["q"]].rename(columns={"q": "q_obs"})
    out.index.name = "time"
    return out


def save_discharge(df: pd.DataFrame, basin_name: str) -> Path:
    """Save corrected discharge to basin data directory."""
    out_dir = PROJECT_ROOT / "basins" / basin_name / "data" / "raw"
    out_dir.mkdir(parents=True, exist_ok=True)

    out_path = out_dir / "discharge_corrected.csv"
    df.to_csv(out_path, float_format="%.2f")
    print(f"\n[save] {out_path} ({len(df)} rows)")
    return out_path


def main(argv: list[str] | None = None):
    parser = argparse.ArgumentParser(
        description="Extract corrected kuwei discharge from MDB + xlsm"
    )
    parser.add_argument("--mdb", required=True, help="Path to qijib.mdb")
    parser.add_argument("--xlsm", required=True, help="Path to 七级水情数据.xlsm")
    parser.add_argument("--basin", default="namou_kuwei", help="Basin name")
    parser.add_argument("--start", default="2014-01-01")
    parser.add_argument("--end", default=None)
    args = parser.parse_args(argv)

    df = extract_kuwei_discharge(
        Path(args.mdb), Path(args.xlsm),
        start=args.start, end=args.end,
    )

    # Summary
    print(f"\n=== Corrected discharge summary ===")
    print(f"Range: {df.index[0]} ~ {df.index[-1]}")
    print(f"Total hours: {len(df)}, NaN: {df['q_obs'].isna().sum()}")
    for yr in sorted(df.index.year.unique()):
        sub = df.loc[df.index.year == yr, "q_obs"].dropna()
        if len(sub) > 0:
            print(f"  {yr}: n={len(sub)}, mean={sub.mean():.1f}, max={sub.max():.1f}")

    save_discharge(df, args.basin)


if __name__ == "__main__":
    main()
