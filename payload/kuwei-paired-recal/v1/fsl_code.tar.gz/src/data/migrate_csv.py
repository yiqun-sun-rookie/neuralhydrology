"""One-time migration: import existing CSV files into SQLite timeseries.db.

Usage:
    python -m src.data.migrate_csv --basin namou_kuwei
    python -m src.data.migrate_csv --basin ylx
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.data.tsdb import open_db, ensure_schema, insert_meteo, insert_discharge


def migrate_basin(
    *,
    data_dir: Path,
    meteo_csv: Path,
    discharge_csv: Path,
    db_name: str = "timeseries.db",
) -> Path:
    """Import meteo and discharge CSVs into a SQLite DB.

    Parameters
    ----------
    data_dir : Path
        Basin data directory (DB will be created here).
    meteo_csv : Path
        Path to grid_meteo_pet_hourly_*.csv.
    discharge_csv : Path
        Path to obs_discharge_hourly.csv.

    Returns
    -------
    Path to the created/updated DB file.
    """
    db_path = data_dir / db_name
    conn = open_db(db_path)
    ensure_schema(conn)

    # --- Meteo ---
    meteo_df = pd.read_csv(meteo_csv, parse_dates=["time"])
    # Normalize column names: rain_g0 -> rain, temp_g0 -> temp, etc.
    col_map = {}
    for col in meteo_df.columns:
        for prefix in ("rain", "temp", "pet", "snow"):
            if col.startswith(prefix) and col != prefix:
                col_map[col] = prefix
    meteo_df = meteo_df.rename(columns=col_map)

    meteo_rows = [
        (
            row["time"].strftime("%Y-%m-%d %H:%M:%S"),
            float(row["rain"]),
            float(row["temp"]),
            float(row["pet"]),
            float(row.get("snow", 0.0)),
            "era5",
        )
        for _, row in meteo_df.iterrows()
    ]
    n_meteo = insert_meteo(conn, meteo_rows)
    print(f"[MIGRATE] meteo: {len(meteo_rows)} rows read, {n_meteo} inserted into {db_path.name}")

    # --- Discharge ---
    discharge_df = pd.read_csv(discharge_csv, parse_dates=["time"])
    discharge_rows = [
        (
            row["time"].strftime("%Y-%m-%d %H:%M:%S"),
            float(row["discharge"]),
            "station",
        )
        for _, row in discharge_df.iterrows()
    ]
    n_discharge = insert_discharge(conn, discharge_rows)
    print(f"[MIGRATE] discharge: {len(discharge_rows)} rows read, {n_discharge} inserted")

    conn.close()
    return db_path


def _resolve_basin_paths(basin_name: str):
    """Resolve CSV paths for a named basin using standard directory layout."""
    basin_dir = PROJECT_ROOT / "basins" / basin_name
    data_dir = basin_dir / "data"
    if not data_dir.exists():
        raise FileNotFoundError(f"Basin data dir not found: {data_dir}")

    # Meteo: raw/grid_meteo_pet_hourly_era5_pet.csv
    meteo_csv = data_dir / "raw" / "grid_meteo_pet_hourly_era5_pet.csv"
    if not meteo_csv.exists():
        # Try other naming patterns
        candidates = sorted(data_dir.glob("raw/grid_meteo_pet_hourly*.csv"))
        if candidates:
            meteo_csv = candidates[0]
        else:
            raise FileNotFoundError(f"No meteo CSV found in {data_dir / 'raw'}")

    # Discharge: {basin}_discharge_hourly/obs_discharge_hourly.csv
    discharge_csv = None
    for pattern in [
        data_dir / f"{basin_name}_discharge_hourly" / "obs_discharge_hourly.csv",
        data_dir / f"{basin_name}_discharge_daily" / "obs_discharge_daily.csv",
    ]:
        if pattern.exists():
            discharge_csv = pattern
            break
    if discharge_csv is None:
        raise FileNotFoundError(f"No discharge CSV found for basin {basin_name}")

    return data_dir, meteo_csv, discharge_csv


def main(argv: list[str] | None = None):
    parser = argparse.ArgumentParser(description="Migrate basin CSV data to SQLite")
    parser.add_argument("--basin", required=True, help="Basin name (e.g., namou_kuwei)")
    args = parser.parse_args(argv)

    data_dir, meteo_csv, discharge_csv = _resolve_basin_paths(args.basin)
    print(f"[MIGRATE] basin={args.basin}")
    print(f"[MIGRATE] meteo_csv={meteo_csv}")
    print(f"[MIGRATE] discharge_csv={discharge_csv}")
    db_path = migrate_basin(data_dir=data_dir, meteo_csv=meteo_csv, discharge_csv=discharge_csv)
    print(f"[MIGRATE] Done: {db_path}")


if __name__ == "__main__":
    main()
