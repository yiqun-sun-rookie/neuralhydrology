from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_DIR = (
    PROJECT_ROOT / "basins" / "namou_kuwei" / "dl" / "highflow_2026_06_17" / "scripts"
)
sys.path.insert(0, str(SCRIPT_DIR))

import paired_rain_recalibration as prr  # noqa: E402
import deterministic_fsl_calibration_adapter as adapter  # noqa: E402


CONFIG_PATH = (
    PROJECT_ROOT
    / "basins" / "namou_kuwei" / "dl" / "highflow_2026_06_17"
    / "configs" / "paired_rain_recalibration_20260824.yml"
)
LOCKED_2023_EVENT_TIMES = list(prr.LOCKED_2023_EVENT_TIMES)
LOCKED_2023_EVENT_FLOWS = list(prr.LOCKED_2023_EVENT_FLOWS)


@pytest.fixture(scope="module")
def config() -> dict:
    return prr.load_config(CONFIG_PATH)


# ----------------------------------------------------------------------------
# Contract
# ----------------------------------------------------------------------------


def test_arm_contract_has_one_changed_factor() -> None:
    contract = prr.load_contract(CONFIG_PATH)
    assert contract.arm_ids == ("current_input", "suspect_zero_excluded")
    assert contract.changed_fields == ("meteo_file.rain_g0",)
    assert contract.seeds == (20260824, 20260825, 20260826)
    assert contract.objective == "nse"
    assert contract.workers == 1
    assert contract.population_shape == (60, 17)
    assert contract.max_candidate_evaluations == 24060
    assert contract.initial_params is None
    assert contract.seed_from is None
    assert contract.resume is False


def test_validate_paired_contract_accepts_the_frozen_config(config: dict) -> None:
    contract = prr.validate_paired_contract(config)
    assert contract.objective == "nse"


def test_budget_is_declared_an_upper_bound(config: dict) -> None:
    """Infeasible individuals cost no evaluation, so 24,060 must never be stated as exact."""
    optimizer = config["optimizer_contract"]
    assert optimizer["max_candidate_evaluations_is_upper_bound"] is True
    assert "at most" in optimizer["upper_bound_note"].lower()


def test_invalid_flow_window_is_exact() -> None:
    mask = prr.build_score_mask(CONFIG_PATH)
    invalid = (mask.index >= "2022-09-01") & (mask.index < "2022-11-01")
    assert invalid.sum() == 1464
    assert not mask[invalid].any()
    assert len(mask) == 43824
    assert int(mask.sum()) == 42360


def test_full_time_contract_is_exact_and_aligned() -> None:
    current, excluded = prr.load_arm_time_axes(CONFIG_PATH)
    expected = pd.date_range("2017-06-01 00:00", "2023-12-31 23:00", freq="h")
    pd.testing.assert_index_equal(current, expected, exact=True)
    pd.testing.assert_index_equal(excluded, expected, exact=True)
    assert len(expected) == 57720


def test_population_hashes_are_paired_and_seed_distinct() -> None:
    paired_hashes = []
    for seed in (20260824, 20260825, 20260826):
        current = prr.population_for_arm(CONFIG_PATH, "current_input", seed)
        excluded = prr.population_for_arm(CONFIG_PATH, "suspect_zero_excluded", seed)
        np.testing.assert_array_equal(current, excluded)
        assert current.shape == (60, 17)
        paired_hashes.append(adapter.sha256_array(current))
    assert len(set(paired_hashes)) == 3


# ----------------------------------------------------------------------------
# Frozen 2023 event registry
# ----------------------------------------------------------------------------


def test_frozen_2023_event_registry() -> None:
    registry = prr.build_observed_event_registry(CONFIG_PATH)
    assert len(registry) == 10
    assert registry["obs_peak_time"].tolist() == LOCKED_2023_EVENT_TIMES
    assert registry["obs_peak_m3s"].tolist() == LOCKED_2023_EVENT_FLOWS


def test_frozen_registry_file_matches_regeneration() -> None:
    report = prr.verify_frozen_event_registry(CONFIG_PATH)
    assert report["event_count"] == 10
    assert report["regenerated_matches_frozen"] is True


def test_event_flows_come_from_the_observation_series_not_the_evaluation_product() -> None:
    """Guard the withdrawn correction: the model-evaluation product carries float32 residue."""
    registry = prr.build_observed_event_registry(CONFIG_PATH)
    flows = dict(zip(registry["obs_peak_time"], registry["obs_peak_m3s"]))
    assert flows["2023-07-31 21:00:00"] == 78.6
    assert flows["2023-08-16 08:00:00"] == 62.1

    product = pd.read_csv(
        PROJECT_ROOT
        / "basins" / "namou_kuwei" / "dl" / "highflow_2026_06_17" / "results"
        / "da_eval_framework_2026_07_13" / "event_eval_2023_verify_events.csv"
    )
    residue = product.loc[
        product["obs_peak_time"] == "2023-07-31 21:00:00", "obs_peak_m3s"
    ].iloc[0]
    # the downstream product differs; that is expected and must not trigger a "fix"
    assert residue != 78.6
    assert abs(residue - 78.6) < 1e-5


def test_observed_discharge_is_shared_by_both_arms(config: dict) -> None:
    assert config["arms"]["discharge"]["shared_by_both_arms"] is True


# ----------------------------------------------------------------------------
# Boundaries and prohibitions
# ----------------------------------------------------------------------------


def test_contract_lock_verifies() -> None:
    verified = prr.verify_contract_lock()
    assert set(verified) == {
        "implementation_plan", "configuration", "preregistration", "event_registry"
    }


def test_output_path_cannot_enter_read_only_repository() -> None:
    with pytest.raises(ValueError, match="read-only repository"):
        prr.validate_output_root(prr.READ_ONLY_REPOSITORY / "results" / "forbidden")


def test_no_persistence_baseline_and_no_forecast_claim(config: dict) -> None:
    evaluation = config["evaluation_contract"]
    assert evaluation["persistence_baseline"] is False
    assert config["paired_family"]["forecast_skill_claim"] is False
    assert config["paired_family"]["project_level_blind_holdout"] is False
    assert config["paired_family"]["verification_year_used_in_current_parameter_estimation"] is False
    assert config["paired_family"]["production_input_change_authorized"] is False
    assert evaluation["historical_nse_0p5616_is_reproduction_gate"] is False


def test_prohibitions_are_registered(config: dict) -> None:
    prohibited = set(config["prohibitions"])
    for item in (
        "drop_a_seed_after_seeing_results",
        "change_event_registry_after_seeing_either_arm",
        "use_2023_in_parameter_estimation",
        "claim_forecast_skill",
        "write_anywhere_inside_forecast_system_lite",
    ):
        assert item in prohibited


def test_bounds_agree_with_the_adapter(config: dict) -> None:
    bounds = tuple(tuple(map(float, b)) for b in config["optimizer_contract"]["bounds"])
    assert bounds == adapter.FROZEN_BOUNDS
    assert tuple(config["optimizer_contract"]["parameter_names"]) == adapter.FROZEN_PARAMETER_NAMES
