from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest
import scipy.stats


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_DIR = (
    PROJECT_ROOT
    / "basins"
    / "namou_kuwei"
    / "dl"
    / "highflow_2026_06_17"
    / "scripts"
)
sys.path.insert(0, str(SCRIPT_DIR))

import deterministic_fsl_calibration_adapter as adapter  # noqa: E402


FROZEN_BOUNDS = adapter.FROZEN_BOUNDS
FROZEN_LOWER_BOUNDS = adapter.FROZEN_LOWER_BOUNDS
FROZEN_UPPER_BOUNDS = adapter.FROZEN_UPPER_BOUNDS
FSL_ROOT = adapter.FSL_ROOT
BASE_CONFIG_PATH = adapter.BASE_RUN_CONFIG


# ----------------------------------------------------------------------------
# Step 1: randomness and data-routing contract
# ----------------------------------------------------------------------------


def test_same_seed_repeats_identically() -> None:
    first = adapter.run_quadratic_seed_smoke(seed=20260824)
    second = adapter.run_quadratic_seed_smoke(seed=20260824)
    np.testing.assert_array_equal(first.x, second.x)
    assert first.fun == second.fun
    assert first.trace == second.trace


def test_different_seeds_diverge() -> None:
    first = adapter.run_quadratic_seed_smoke(seed=20260824)
    second = adapter.run_quadratic_seed_smoke(seed=20260825)
    assert first.population_sha256 != second.population_sha256
    assert first.trace != second.trace


def test_explicit_population_contract() -> None:
    first = adapter.build_initial_population(seed=20260824, bounds=FROZEN_BOUNDS)
    second = adapter.build_initial_population(seed=20260824, bounds=FROZEN_BOUNDS)
    unit = scipy.stats.qmc.LatinHypercube(d=17, seed=20260824).random(n=60)
    expected = scipy.stats.qmc.scale(unit, FROZEN_LOWER_BOUNDS, FROZEN_UPPER_BOUNDS)
    assert first.shape == (60, 17)
    np.testing.assert_array_equal(first, second)
    np.testing.assert_array_equal(first, expected)
    assert np.all(first >= FROZEN_LOWER_BOUNDS)
    assert np.all(first <= FROZEN_UPPER_BOUNDS)
    assert np.unique(first, axis=0).shape[0] == 60


def test_formal_seed_populations_are_distinct() -> None:
    hashes = {
        adapter.sha256_array(adapter.build_initial_population(seed=seed, bounds=FROZEN_BOUNDS))
        for seed in (20260824, 20260825, 20260826)
    }
    assert len(hashes) == 3


def test_population_is_exactly_sixty_not_a_dimension_multiple() -> None:
    """Guard the 60 vs 1020 trap: SciPy would expand popsize=60 to 60*17 without an array."""
    population = adapter.build_initial_population(seed=20260824)
    assert population.shape[0] == 60
    assert population.shape[0] != 60 * 17
    assert adapter.POPULATION_ROWS == 60
    assert adapter.PARAMETER_DIMENSION == 17
    assert adapter.MAX_CANDIDATE_EVALUATIONS == 60 + 400 * 60


def test_frozen_bounds_match_the_read_only_contract() -> None:
    assert len(FROZEN_BOUNDS) == 17
    assert len(adapter.FROZEN_PARAMETER_NAMES) == 17
    assert all(hi > lo for lo, hi in FROZEN_BOUNDS)
    # captured from the read-only chain; reordering silently misplaces every population column
    assert FROZEN_BOUNDS[0] == (0.01, 0.8)
    assert FROZEN_BOUNDS[2] == (1.0, 5.0)
    assert FROZEN_BOUNDS[16] == (0.7, 0.999)
    assert adapter.FROZEN_PARAMETER_NAMES[0] == "msk_c0"
    assert adapter.FROZEN_PARAMETER_NAMES[16] == "cg"


def test_warm_start_and_resume_are_disabled() -> None:
    runtime = adapter.build_runtime_config(BASE_CONFIG_PATH, seed=20260824)
    assert runtime.initial_params is None
    assert runtime.seed_from is None
    assert runtime.resume is False
    assert runtime.workers == 1
    assert runtime.pop_size == 60
    assert runtime.objective == "nse"


def test_runtime_config_carries_the_frozen_time_contract() -> None:
    runtime = adapter.build_runtime_config(BASE_CONFIG_PATH, seed=20260824)
    assert adapter.CALIBRATION_END in runtime.text
    assert "exclude_windows" in runtime.text
    assert adapter.INVALID_FLOW_WINDOW[0] in runtime.text
    assert adapter.INVALID_FLOW_WINDOW[1] in runtime.text
    assert "eval_start_date" in runtime.text
    assert "initial_params" not in runtime.text


def test_runtime_data_dir_has_no_database(tmp_path: Path) -> None:
    spec = adapter.default_input_spec("current_input")
    paths = adapter.build_isolated_runtime_inputs(spec, tmp_path)
    assert not (paths.data_dir / "timeseries.db").exists()
    assert list(paths.data_dir.rglob("timeseries.db")) == []
    assert paths.meteo_file.is_file()
    assert paths.discharge_file.is_file()
    assert (paths.matrix_dir / "grid_to_subbasin_map.csv").is_file()
    assert (paths.matrix_dir / "sub_area.csv").is_file()


# ----------------------------------------------------------------------------
# Step 4: read-only boundary and source selection
# ----------------------------------------------------------------------------


def test_output_path_cannot_enter_fsl() -> None:
    with pytest.raises(ValueError, match="read-only repository"):
        adapter.validate_output_root(FSL_ROOT / "results" / "forbidden")


def test_output_path_cannot_be_the_read_only_root_itself() -> None:
    with pytest.raises(ValueError, match="read-only repository"):
        adapter.validate_output_root(FSL_ROOT)


def test_explicit_csv_source_is_used(tmp_path: Path) -> None:
    spec = adapter.default_input_spec("current_input")
    paths = adapter.build_isolated_runtime_inputs(spec, tmp_path)
    loaded = adapter.preflight_model_data(paths)
    assert loaded.meteo_sha256 == adapter.sha256_file(paths.meteo_file)
    assert loaded.discharge_sha256 == adapter.sha256_file(paths.discharge_file)
    assert loaded.meteo_rows == 57720
    assert loaded.discharge_rows == 57720


def test_both_arms_produce_distinct_meteo_snapshots(tmp_path: Path) -> None:
    left = adapter.build_isolated_runtime_inputs(
        adapter.default_input_spec("current_input"), tmp_path / "a"
    )
    right = adapter.build_isolated_runtime_inputs(
        adapter.default_input_spec("suspect_zero_excluded"), tmp_path / "b"
    )
    assert adapter.sha256_file(left.meteo_file) != adapter.sha256_file(right.meteo_file)
    # the discharge side must be identical between arms
    assert adapter.sha256_file(left.discharge_file) == adapter.sha256_file(right.discharge_file)


# ----------------------------------------------------------------------------
# Context-manager restoration
# ----------------------------------------------------------------------------


def test_seeded_context_restores_run_de_and_random_state() -> None:
    sys.path.insert(0, str(FSL_ROOT))
    from src.runtime.semi_distributed.core import optimize_eval as optimize_eval_module

    original = optimize_eval_module.run_de
    before = np.random.get_state()
    population = adapter.build_initial_population(seed=20260824)
    with adapter.seeded_de_context(20260824, population) as trace:
        assert optimize_eval_module.run_de is not original
        assert trace.seed == 20260824
    assert optimize_eval_module.run_de is original
    after = np.random.get_state()
    assert before[0] == after[0]
    np.testing.assert_array_equal(before[1], after[1])


def test_seeded_context_restores_even_when_body_raises() -> None:
    sys.path.insert(0, str(FSL_ROOT))
    from src.runtime.semi_distributed.core import optimize_eval as optimize_eval_module

    original = optimize_eval_module.run_de
    population = adapter.build_initial_population(seed=20260824)
    with pytest.raises(RuntimeError, match="deliberate"):
        with adapter.seeded_de_context(20260824, population):
            raise RuntimeError("deliberate")
    assert optimize_eval_module.run_de is original


def test_patched_run_de_rejects_an_internally_built_population() -> None:
    """If a warm-start path ever fires again, the run must stop rather than lose determinism."""
    sys.path.insert(0, str(FSL_ROOT))
    from src.runtime.semi_distributed.core import optimize_eval as optimize_eval_module

    population = adapter.build_initial_population(seed=20260824)
    with adapter.seeded_de_context(20260824, population):
        with pytest.raises(RuntimeError, match="internal unseeded population path"):
            optimize_eval_module.run_de(
                lambda x: 0.0,
                list(FROZEN_BOUNDS),
                init=np.zeros((60, 17)),
            )


def test_patched_run_de_rejects_drifted_bounds() -> None:
    sys.path.insert(0, str(FSL_ROOT))
    from src.runtime.semi_distributed.core import optimize_eval as optimize_eval_module

    population = adapter.build_initial_population(seed=20260824)
    drifted = list(FROZEN_BOUNDS[:-1]) + [(0.7, 1.5)]
    with adapter.seeded_de_context(20260824, population):
        with pytest.raises(RuntimeError, match="bounds drifted"):
            optimize_eval_module.run_de(
                lambda x: 0.0, drifted, init="latinhypercube"
            )


def test_constraints_skip_infeasible_objective_evaluations() -> None:
    """The 24,060 budget is an upper bound: infeasible individuals cost no evaluation.

    Without this the run cost, and any statement of how many candidates were evaluated,
    would be overstated by a large factor.
    """
    from scipy.optimize import NonlinearConstraint, differential_evolution

    population = adapter.build_initial_population(seed=20260824)

    def counted():
        calls = {"n": 0}

        def objective(vector):
            calls["n"] += 1
            return float(np.sum((np.asarray(vector, dtype=float) - 0.3) ** 2))

        return objective, calls

    unconstrained_objective, unconstrained_calls = counted()
    differential_evolution(
        unconstrained_objective,
        list(FROZEN_BOUNDS),
        constraints=(),
        maxiter=1,
        init=population,
        seed=20260824,
        **adapter.DETERMINISTIC_DE_KWARGS,
    )

    constrained_objective, constrained_calls = counted()
    differential_evolution(
        constrained_objective,
        list(FROZEN_BOUNDS),
        constraints=(NonlinearConstraint(lambda x: x[0] + x[1], -np.inf, 0.8),),
        maxiter=1,
        init=population,
        seed=20260824,
        **adapter.DETERMINISTIC_DE_KWARGS,
    )

    assert unconstrained_calls["n"] == 2 * 60
    assert constrained_calls["n"] < unconstrained_calls["n"]
    assert adapter.CONSTRAINT_SKIPS_INFEASIBLE_EVALUATIONS is True
    # the frozen population is genuinely split by the read-only constraint
    feasible = int((population[:, 0] + population[:, 1] <= 0.8).sum())
    assert 0 < feasible < 60


def test_deterministic_de_kwargs_pin_tol_and_atol() -> None:
    """run_de exposes no atol and its call site passes no tol; the adapter must supply both."""
    assert adapter.DETERMINISTIC_DE_KWARGS["tol"] == 0.0
    assert adapter.DETERMINISTIC_DE_KWARGS["atol"] == 0.0
    assert adapter.DETERMINISTIC_DE_KWARGS["workers"] == 1
    assert adapter.DETERMINISTIC_DE_KWARGS["polish"] is False
    assert adapter.DETERMINISTIC_DE_KWARGS["updating"] == "deferred"
    assert adapter.DETERMINISTIC_DE_KWARGS["strategy"] == "best1bin"
