"""Freeze a source-preserving continuous rainfall qualification and the two paired arm forcings.

This program produces inputs only. It performs no calibration, no model run, no evaluation and no
forecast. It reads rainfall lineage plus the registered invalid-flow window list, and never reads
model parameters, simulations, residuals or forecasts.

The two arms differ in exactly one field, hourly ``rain_g0``:

* ``current_input`` is a bitwise copy of the registered ``grid_hybrid.csv`` ``rain_g0``;
* ``suspect_zero_excluded`` copies that series and recomputes only the hours that actually lose at
  least one station to the frozen ``suspect_zero`` rule.

Recomputing every hour instead would inject floating point summation-order noise into hours that
have no suspect segment at all, which would destroy single-factor isolation. See the preregistration
for the measured magnitude.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
import pandas as pd
import yaml


HERE = Path(__file__).resolve().parent
CAMPAIGN_ROOT = HERE.parent
PROJECT_ROOT = CAMPAIGN_ROOT.parents[3]
DEFAULT_CONFIG = CAMPAIGN_ROOT / "configs" / "continuous_rainfall_qualification_20260824.yml"
CONTRACT_LOCK_PATH = (
    PROJECT_ROOT
    / "docs"
    / "experiments"
    / "continuous_rainfall_qualification_20260824"
    / "CONTRACT_LOCK.json"
)
READ_ONLY_REPOSITORY = Path("G:/github/pycharm/projects/forecast_system_lite")

FAMILY_ID = "continuous_rainfall_qualification_20260824"
FROZEN_CONFIG_SHA256 = "79ded434b73b983deea32c7795c230afacced2e23ad4acfce94a10213b0e5ad4"
FROZEN_CONTRACT_LOCK_SHA256 = "38c3e260725c70a1f200ba1827a1a0ecba2c2954f298f1b79826bb772962da64"

QUALIFICATION_STATUSES = (
    "positive",
    "eligible_zero",
    "missing",
    "suspect_zero",
    "undetermined",
)
INCLUDE_STATUSES = frozenset({"positive", "eligible_zero", "undetermined"})
EXCLUDE_STATUSES = frozenset({"missing", "suspect_zero"})

METEO_COLUMNS = ("time", "rain_g0", "temp_g0", "pet_g0", "snow_g0")

_CACHE: dict[str, Any] = {}


# ---------------------------------------------------------------------------
# Small utilities
# ---------------------------------------------------------------------------


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _jsonable(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    if isinstance(value, (pd.Timestamp, datetime)):
        return value.isoformat()
    if isinstance(value, Path):
        return str(value)
    return value


def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.write_text(
        json.dumps(_jsonable(payload), ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def _load_yaml(path: Path) -> dict[str, Any]:
    with open(path, "r", encoding="utf-8") as handle:
        loaded = yaml.safe_load(handle)
    if not isinstance(loaded, dict):
        raise RuntimeError(f"configuration is not a mapping: {path}")
    return loaded


def validate_output_root(path: Path) -> Path:
    resolved = Path(path).resolve()
    read_only = READ_ONLY_REPOSITORY.resolve()
    if resolved == read_only or read_only in resolved.parents:
        raise ValueError(f"output path enters the permanently read-only repository: {resolved}")
    project_root = PROJECT_ROOT.resolve()
    if resolved != project_root and project_root not in resolved.parents:
        raise ValueError(f"output path escapes the writable repository: {resolved}")
    return resolved


def verify_contract_lock(
    lock_path: Path = CONTRACT_LOCK_PATH,
    *,
    expected_lock_sha256: str = FROZEN_CONTRACT_LOCK_SHA256,
) -> dict[str, str]:
    lock_path = Path(lock_path).resolve()
    actual = sha256_file(lock_path)
    if actual != expected_lock_sha256.lower():
        raise RuntimeError(
            f"frozen contract-lock hash mismatch: expected={expected_lock_sha256.lower()}; actual={actual}"
        )
    payload = json.loads(lock_path.read_text(encoding="utf-8"))
    if payload.get("audit_family") != FAMILY_ID:
        raise RuntimeError("contract-lock family identity drifted")
    locked_files = payload.get("locked_files")
    if not isinstance(locked_files, Mapping) or set(locked_files) != {
        "implementation_plan",
        "configuration",
        "preregistration",
    }:
        raise RuntimeError("contract-lock file registry drifted")
    verified: dict[str, str] = {}
    project_root = PROJECT_ROOT.resolve()
    for name, entry in locked_files.items():
        path = Path(str(entry["path"])).resolve()
        if path != project_root and project_root not in path.parents:
            raise RuntimeError(f"contract-lock path escapes the project repository: {path}")
        expected = str(entry["sha256"]).lower()
        got = sha256_file(path)
        if got != expected:
            raise RuntimeError(
                f"locked file hash mismatch for {name}: expected={expected}; actual={got}"
            )
        verified[str(name)] = got
    return verified


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


def load_config(path: Path = DEFAULT_CONFIG) -> dict[str, Any]:
    path = Path(path).resolve()
    actual = sha256_file(path)
    if actual != FROZEN_CONFIG_SHA256:
        raise RuntimeError(
            f"frozen configuration hash mismatch: expected={FROZEN_CONFIG_SHA256}; actual={actual}"
        )
    config = _load_yaml(path)
    if config.get("continuous_family", {}).get("id") != FAMILY_ID:
        raise RuntimeError("configuration family identity drifted")
    for flag in (
        "model_training_performed",
        "model_evaluation_performed",
        "parameter_calibration_performed",
        "forecast_skill_claim",
        "rainfall_imputation_performed",
        "rainfall_value_inferred",
    ):
        if config["continuous_family"].get(flag) is not False:
            raise RuntimeError(f"configuration must declare {flag}=false")
    config["_config_path"] = str(path)
    config["_config_sha256"] = actual
    return config


def _verify_configured_hashes(config: Mapping[str, Any]) -> dict[str, dict[str, str]]:
    """Re-hash every registered input file and fail on any drift."""
    verified: dict[str, dict[str, str]] = {}
    for section_name in ("source_reference", "data"):
        section = config.get(section_name, {})
        for key, entry in section.items():
            if not isinstance(entry, Mapping) or "sha256" not in entry:
                continue
            path = Path(str(entry["path"]))
            expected = str(entry["sha256"]).lower()
            actual = sha256_file(path)
            if actual != expected:
                raise RuntimeError(
                    f"input hash drift for {section_name}.{key}: expected={expected}; actual={actual}"
                )
            verified[f"{section_name}.{key}"] = {"path": str(path), "sha256": actual}
    raw = config.get("raw_source_verification", {})
    era_a = raw.get("era_2017_2019", {})
    if "sha256" in era_a:
        path = Path(str(era_a["path"]))
        actual = sha256_file(path)
        if actual != str(era_a["sha256"]).lower():
            raise RuntimeError("input hash drift for raw_source_verification.era_2017_2019")
        verified["raw_source_verification.era_2017_2019"] = {"path": str(path), "sha256": actual}
    for station, entry in raw.get("era_2020_2023", {}).get("workbooks", {}).items():
        path = Path(str(entry["path"]))
        actual = sha256_file(path)
        if actual != str(entry["sha256"]).lower():
            raise RuntimeError(f"input hash drift for raw workbook {station}")
        verified[f"raw_source_verification.era_2020_2023.{station}"] = {
            "path": str(path),
            "sha256": actual,
        }
    return verified


def _window(config: Mapping[str, Any]) -> pd.DatetimeIndex:
    contract = config["time_contract"]
    index = pd.date_range(
        contract["spinup_start"], contract["verification_end"], freq=contract["frequency"]
    )
    if len(index) != int(contract["total_hours"]):
        raise RuntimeError(
            f"window length {len(index)} does not equal the frozen {contract['total_hours']}"
        )
    if index.has_duplicates or not index.is_monotonic_increasing:
        raise RuntimeError("window index is not unique and strictly increasing")
    deltas = np.unique(np.diff(index.values))
    if len(deltas) != 1 or deltas[0] != np.timedelta64(1, "h"):
        raise RuntimeError("window index is not strictly hourly with no gap")
    return index


# ---------------------------------------------------------------------------
# Frozen segment decisions
# ---------------------------------------------------------------------------


def load_frozen_segment_decisions(config_path: Path = DEFAULT_CONFIG) -> pd.DataFrame:
    """Return the frozen station-segment decisions with parsed boundaries."""
    config = load_config(config_path)
    path = Path(str(config["data"]["zero_segment_evidence_csv"]["path"]))
    frame = pd.read_csv(path, parse_dates=["start", "end"])
    keep = ["segment_id", "station", "start", "end", "n_hours", "qualification_status"]
    frame = frame[keep].copy()
    frame["n_hours"] = frame["n_hours"].astype(int)
    bad = set(frame["qualification_status"]) - set(QUALIFICATION_STATUSES)
    if bad:
        raise RuntimeError(f"unknown qualification status in frozen evidence: {sorted(bad)}")
    # every registered segment must have consistent inclusive-boundary hour count
    span = ((frame["end"] - frame["start"]).dt.total_seconds() / 3600.0 + 1).astype(int)
    mismatch = frame[span != frame["n_hours"]]
    if not mismatch.empty:
        raise RuntimeError(
            "frozen segment hour counts are not inclusive-boundary consistent: "
            f"{mismatch['segment_id'].tolist()}"
        )
    return frame.sort_values(["start", "station"]).reset_index(drop=True)


def _window_segments(config: Mapping[str, Any], status: str) -> pd.DataFrame:
    frame = load_frozen_segment_decisions(Path(config["_config_path"]))
    contract = config["time_contract"]
    start = pd.Timestamp(contract["spinup_start"])
    end = pd.Timestamp(contract["verification_end"])
    inside = frame[(frame["end"] >= start) & (frame["start"] <= end)]
    return inside[inside["qualification_status"].eq(status)].reset_index(drop=True)


def _verify_segment_contract(config: Mapping[str, Any]) -> dict[str, Any]:
    """Check the frozen segment counts declared in the configuration."""
    expected = config["segment_contract"]
    frame = load_frozen_segment_decisions(Path(config["_config_path"]))
    calib = frame[(frame["end"] >= "2018-01-01") & (frame["start"] < "2023-01-01")]
    full = frame[(frame["end"] >= "2017-06-01") & (frame["start"] < "2024-01-01")]
    verify = frame[(frame["end"] >= "2023-01-01") & (frame["start"] < "2024-01-01")]

    calib_sus = calib.query("qualification_status == 'suspect_zero'")
    calib_und = calib.query("qualification_status == 'undetermined'")
    full_und = full.query("qualification_status == 'undetermined'")
    verify_und = full_und[full_und["end"] >= "2023-01-01"]
    calib_ez = calib.query("qualification_status == 'eligible_zero'")

    checks = {
        "calibration_suspect_segments": (len(calib_sus), expected["expected_calibration_suspect_segments"]),
        "calibration_suspect_station_hours": (
            int(calib_sus["n_hours"].sum()),
            expected["expected_calibration_suspect_station_hours"],
        ),
        "calibration_undetermined_segments": (
            len(calib_und),
            expected["expected_calibration_undetermined_segments"],
        ),
        "calibration_undetermined_station_hours": (
            int(calib_und["n_hours"].sum()),
            expected["expected_calibration_undetermined_station_hours"],
        ),
        "full_period_undetermined_segments": (
            len(full_und),
            expected["expected_full_period_undetermined_segments"],
        ),
        "full_period_undetermined_station_hours": (
            int(full_und["n_hours"].sum()),
            expected["expected_full_period_undetermined_station_hours"],
        ),
        "verification_undetermined_segments": (
            len(verify_und),
            expected["expected_verification_undetermined_segments"],
        ),
        "verification_undetermined_station_hours": (
            int(verify_und["n_hours"].sum()),
            expected["expected_verification_undetermined_station_hours"],
        ),
        "verification_suspect_segments": (
            len(verify.query("qualification_status == 'suspect_zero'")),
            expected["expected_verification_suspect_segments"],
        ),
        "calibration_eligible_zero_segments": (
            len(calib_ez),
            expected["expected_calibration_eligible_zero_segments"],
        ),
    }
    failures = {k: v for k, v in checks.items() if v[0] != v[1]}
    if failures:
        raise RuntimeError(f"frozen segment contract mismatch: {failures}")

    registered_ids = {str(s["segment_id"]) for s in expected["excluded_segments"]}
    actual_ids = set(calib_sus["segment_id"])
    if registered_ids != actual_ids:
        raise RuntimeError(
            f"excluded segment identity drift: registered={sorted(registered_ids)}; actual={sorted(actual_ids)}"
        )
    preserved_ids = {str(s["segment_id"]) for s in expected["preserved_undetermined_segments"]}
    if preserved_ids != set(full_und["segment_id"]):
        raise RuntimeError("preserved undetermined segment identity drift")
    return {name: value for name, (value, _) in checks.items()}


# ---------------------------------------------------------------------------
# Continuous station-hour qualification
# ---------------------------------------------------------------------------


def _read_rain(config: Mapping[str, Any]) -> pd.DataFrame:
    path = Path(str(config["data"]["rain_csv"]["path"]))
    stations = list(config["stations"]["rain_csv_column_order"])
    frame = pd.read_csv(path, parse_dates=["time"]).set_index("time")
    missing_cols = [s for s in stations if s not in frame.columns]
    if missing_cols:
        raise RuntimeError(f"rain.csv is missing station columns: {missing_cols}")
    index = _window(config)
    if not index.isin(frame.index).all():
        raise RuntimeError("rain.csv does not cover the full continuous window")
    return frame.loc[index, stations]


def _read_missing_status(config: Mapping[str, Any]) -> pd.DataFrame:
    path = Path(str(config["data"]["missing_status_csv"]["path"]))
    frame = pd.read_csv(path, parse_dates=["time"])
    index = _window(config)
    frame = frame[frame["time"].isin(index)]
    return frame.pivot(index="time", columns="station", values="status").reindex(index)


def _segment_masks(config: Mapping[str, Any]) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    """Return boolean (time x station) masks for suspect and undetermined, plus segment ids."""
    index = _window(config)
    stations = list(config["stations"]["rain_csv_column_order"])
    suspect = pd.DataFrame(False, index=index, columns=stations)
    undetermined = pd.DataFrame(False, index=index, columns=stations)
    segment_id = pd.DataFrame("", index=index, columns=stations)

    for status, target in (("suspect_zero", suspect), ("undetermined", undetermined)):
        for _, row in _window_segments(config, status).iterrows():
            selected = (index >= row["start"]) & (index <= row["end"])
            if row["station"] not in stations:
                raise RuntimeError(f"segment station outside the four in-basin gauges: {row['station']}")
            if (target.loc[index[selected], row["station"]]).any():
                raise RuntimeError(f"overlapping {status} segments for {row['station']}")
            target.loc[index[selected], row["station"]] = True
            segment_id.loc[index[selected], row["station"]] = row["segment_id"]
    overlap = (suspect & undetermined).to_numpy().sum()
    if overlap:
        raise RuntimeError(f"{overlap} station-hours are both suspect and undetermined")
    return suspect, undetermined, {"segment_id": segment_id}


def build_continuous_station_hour_table(config: Mapping[str, Any]) -> pd.DataFrame:
    """Keep source values and assign positive/eligible_zero/missing/suspect_zero/undetermined."""
    cache_key = f"station_hours::{config['_config_sha256']}"
    if cache_key in _CACHE:
        return _CACHE[cache_key].copy()

    index = _window(config)
    stations = list(config["stations"]["rain_csv_column_order"])
    rain = _read_rain(config)
    status = _read_missing_status(config)
    suspect, undetermined, extra = _segment_masks(config)
    segment_id = extra["segment_id"]

    values = rain.to_numpy(dtype=float)
    is_missing = np.isnan(values)

    # cross-check the single-source status registry against rain.csv semantics
    if not status.isna().all().all():
        registry_missing = status[stations].to_numpy() == "missing"
        disagree = int((registry_missing != is_missing).sum())
        if disagree:
            raise RuntimeError(
                f"missing_status.csv disagrees with rain.csv at {disagree} station-hours"
            )

    sus = suspect.to_numpy()
    und = undetermined.to_numpy()

    # a suspect or undetermined cell must be an exact numeric zero in the source
    for name, mask in (("suspect_zero", sus), ("undetermined", und)):
        if is_missing[mask].any():
            raise RuntimeError(f"{name} mask covers a missing source value")
        offending = values[mask]
        if offending.size and not np.all(offending == 0.0):
            raise RuntimeError(f"{name} mask covers a non-zero source value")

    qualification = np.empty(values.shape, dtype=object)
    qualification[:] = "eligible_zero"
    qualification[values > 0.0] = "positive"
    qualification[und] = "undetermined"
    qualification[sus] = "suspect_zero"
    qualification[is_missing] = "missing"

    decision = np.where(np.isin(qualification, list(INCLUDE_STATUSES)), "include", "exclude")

    table = pd.DataFrame(
        {
            "time": np.repeat(index.values, len(stations)),
            "station": np.tile(np.asarray(stations, dtype=object), len(index)),
            "source_value_mm": values.reshape(-1),
            "source_status": np.where(
                is_missing, "missing", np.where(values > 0.0, "pos", "zero")
            ).reshape(-1),
            "qualification_status": qualification.reshape(-1),
            "eligibility_decision": decision.reshape(-1),
            "segment_id": segment_id.to_numpy().reshape(-1),
        }
    )
    table["time"] = pd.to_datetime(table["time"])
    if len(table) != len(index) * len(stations):
        raise RuntimeError("station-hour table row count drift")

    eligible = table[table["eligibility_decision"].eq("include")]
    counts = eligible.groupby("time")["station"].nunique().reindex(index, fill_value=0)
    minimum = int(config["qualification_contract"]["minimum_eligible_stations_for_mean"])
    if int(counts.min()) < minimum:
        starved = counts[counts < minimum]
        raise RuntimeError(
            f"{len(starved)} hours have fewer than {minimum} eligible stations; first={starved.index[0]}"
        )

    _CACHE[cache_key] = table.copy()
    return table


# ---------------------------------------------------------------------------
# Masks and arm forcing
# ---------------------------------------------------------------------------


def build_score_mask(config_path: Path = DEFAULT_CONFIG) -> pd.Series:
    """Boolean scored-hour mask over the calibration window; invalid flow is False."""
    config = load_config(config_path)
    contract = config["time_contract"]
    index = pd.date_range(
        contract["calibration_start"], contract["calibration_end"], freq=contract["frequency"]
    )
    if len(index) != int(contract["calibration_hours"]):
        raise RuntimeError("calibration window length drift")
    mask = pd.Series(True, index=index)
    invalid = (index >= contract["invalid_flow_start"]) & (
        index < contract["invalid_flow_end_exclusive"]
    )
    if int(invalid.sum()) != int(contract["invalid_flow_hours"]):
        raise RuntimeError(
            f"invalid-flow window is {int(invalid.sum())} hours, frozen is {contract['invalid_flow_hours']}"
        )
    mask.loc[index[invalid]] = False
    if int(mask.sum()) != int(contract["scored_calibration_hours"]):
        raise RuntimeError("scored calibration hour count drift")
    return mask


def affected_hour_mask(config_path: Path = DEFAULT_CONFIG) -> pd.Series:
    """True where at least one station is removed from that hour's mean."""
    config = load_config(config_path)
    index = _window(config)
    suspect, _, _ = _segment_masks(config)
    return pd.Series(suspect.to_numpy().any(axis=1), index=index)


def _read_current_grid(config: Mapping[str, Any]) -> pd.DataFrame:
    path = Path(str(config["data"]["grid_hybrid_csv"]["path"]))
    frame = pd.read_csv(path, parse_dates=["time"])
    contract = config["time_contract"]
    window = frame[
        (frame["time"] >= contract["spinup_start"]) & (frame["time"] <= contract["verification_end"])
    ].reset_index(drop=True)
    if len(window) != int(contract["total_hours"]):
        raise RuntimeError(f"grid_hybrid window is {len(window)} rows, frozen is {contract['total_hours']}")
    if list(window.columns) != list(METEO_COLUMNS):
        raise RuntimeError(f"grid_hybrid columns drifted: {list(window.columns)}")
    if window["rain_g0"].isna().any():
        raise RuntimeError("registered rain_g0 contains NaN inside the window")
    return window


def build_arm_grids(config_path: Path = DEFAULT_CONFIG) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return current and suspect-excluded grids; change rain_g0 only."""
    config = load_config(config_path)
    cache_key = f"arms::{config['_config_sha256']}"
    if cache_key in _CACHE:
        left, right = _CACHE[cache_key]
        return left.copy(), right.copy()

    index = _window(config)
    stations = list(config["stations"]["rain_csv_column_order"])
    arm = config["arm_contract"]

    current = _read_current_grid(config)

    # the registered rain_g0 must equal the registered upstream_mean bitwise
    rain = _read_rain(config)
    rain_path = Path(str(config["data"]["rain_csv"]["path"]))
    upstream = pd.read_csv(rain_path, parse_dates=["time"]).set_index("time").loc[index, "upstream_mean"]
    if not np.array_equal(current["rain_g0"].to_numpy(), upstream.to_numpy()):
        raise RuntimeError("registered rain_g0 is not bitwise equal to rain.csv upstream_mean")

    suspect, _, _ = _segment_masks(config)
    affected = suspect.to_numpy().any(axis=1)
    if int(affected.sum()) != int(arm["expected_affected_hours"]):
        raise RuntimeError(
            f"affected hours {int(affected.sum())} != frozen {arm['expected_affected_hours']}"
        )

    excluded = current.copy()
    subset = rain.mask(suspect).loc[affected]
    recomputed = subset.mean(axis=1, skipna=True)
    if recomputed.isna().any():
        raise RuntimeError("an affected hour has no eligible station after exclusion")
    excluded.loc[affected, "rain_g0"] = recomputed.to_numpy()

    delta = excluded["rain_g0"].to_numpy() - current["rain_g0"].to_numpy()
    tol_ge = float(arm["greater_or_equal_tolerance_mm"])
    if delta.min() < -tol_ge:
        raise RuntimeError(f"excluded arm is lower than current arm by {delta.min()}")
    if np.any(delta[~affected] != 0.0):
        raise RuntimeError("an unaffected hour changed between arms")

    changed = int((delta != 0.0).sum())
    if changed != int(arm["expected_changed_hours"]):
        raise RuntimeError(f"changed hours {changed} != frozen {arm['expected_changed_hours']}")

    tol = float(arm["added_rain_tolerance_mm"])
    if abs(float(delta.sum()) - float(arm["expected_added_rain_mm_total"])) > tol:
        raise RuntimeError(f"total added rainfall {float(delta.sum())} != frozen")
    verification = index >= config["time_contract"]["verification_start"]
    if abs(float(delta[verification].sum()) - float(arm["expected_added_rain_mm_verification"])) > tol:
        raise RuntimeError("verification-year rainfall changed; it must stay exactly zero")

    for column in ("time", "temp_g0", "pet_g0", "snow_g0"):
        if not current[column].equals(excluded[column]):
            raise RuntimeError(f"arms differ in {column}; only rain_g0 may differ")

    _CACHE[cache_key] = (current.copy(), excluded.copy())
    return current, excluded


def build_hour_mean_comparison(config_path: Path = DEFAULT_CONFIG) -> pd.DataFrame:
    """One row per hour comparing the two arms."""
    config = load_config(config_path)
    index = _window(config)
    current, excluded = build_arm_grids(config_path)
    table = build_continuous_station_hour_table(config)
    suspect, undetermined, _ = _segment_masks(config)

    eligible = table[table["eligibility_decision"].eq("include")]
    n_eligible = eligible.groupby("time")["station"].nunique().reindex(index, fill_value=0)
    n_missing = (
        table[table["qualification_status"].eq("missing")]
        .groupby("time")["station"]
        .nunique()
        .reindex(index, fill_value=0)
    )
    delta = excluded["rain_g0"].to_numpy() - current["rain_g0"].to_numpy()
    contract = config["time_contract"]
    period = np.where(
        index < contract["calibration_start"],
        "spinup",
        np.where(index < contract["verification_start"], "calibration", "verification"),
    )
    return pd.DataFrame(
        {
            "time": index,
            "period": period,
            "rain_g0_current": current["rain_g0"].to_numpy(),
            "rain_g0_suspect_excluded": excluded["rain_g0"].to_numpy(),
            "delta_mm": delta,
            "changed": delta != 0.0,
            "affected": suspect.to_numpy().any(axis=1),
            "n_suspect_stations": suspect.to_numpy().sum(axis=1),
            "n_undetermined_stations": undetermined.to_numpy().sum(axis=1),
            "n_missing_stations": n_missing.to_numpy(),
            # the station-hour table already marks suspect_zero as excluded, so the include
            # count IS the excluded arm. The current arm additionally keeps the suspect zeros.
            "n_eligible_stations_current": n_eligible.to_numpy()
            + suspect.to_numpy().sum(axis=1),
            "n_eligible_stations_excluded": n_eligible.to_numpy(),
        }
    )


# ---------------------------------------------------------------------------
# Raw-source retrace
# ---------------------------------------------------------------------------


def _normalise_raw_value(value: Any, missing_tokens: Sequence[str]) -> float:
    if value is None:
        return float("nan")
    if isinstance(value, str):
        text = value.strip()
        if text in missing_tokens:
            return float("nan")
        try:
            return float(text)
        except ValueError:
            return float("nan")
    try:
        result = float(value)
    except (TypeError, ValueError):
        return float("nan")
    return result


def _read_raw_era_2017_2019(config: Mapping[str, Any]) -> pd.DataFrame:
    raw = config["raw_source_verification"]
    era = raw["era_2017_2019"]
    tokens = list(raw["missing_tokens"])
    path = Path(str(era["path"]))
    header_row = int(era["header_row_index"])
    data_row = int(era["data_start_row_index"])
    time_col = int(era["time_column_index"])
    label_map = {str(v): k for k, v in era["station_header_labels"].items()}

    frames: list[pd.DataFrame] = []
    for sheet in era["sheets"]:
        block = pd.read_excel(path, sheet_name=sheet, header=None)
        labels = block.iloc[header_row].tolist()
        column_for: dict[str, int] = {}
        for position, label in enumerate(labels):
            key = label_map.get(str(label).strip())
            if key is not None:
                column_for[key] = position
        missing = set(label_map.values()) - set(column_for)
        if missing:
            raise RuntimeError(f"raw sheet {sheet} is missing station columns: {sorted(missing)}")
        body = block.iloc[data_row:]
        times = pd.to_datetime(body.iloc[:, time_col], errors="coerce")
        data = {"time": times}
        for station, position in column_for.items():
            data[station] = [
                _normalise_raw_value(v, tokens) for v in body.iloc[:, position].tolist()
            ]
        frame = pd.DataFrame(data).dropna(subset=["time"])
        frames.append(frame)
    combined = pd.concat(frames, ignore_index=True)
    combined = combined[~combined["time"].duplicated(keep="first")]
    return combined.set_index("time").sort_index()


def _read_raw_era_2020_2023(config: Mapping[str, Any]) -> pd.DataFrame:
    raw = config["raw_source_verification"]
    era = raw["era_2020_2023"]
    tokens = list(raw["missing_tokens"])
    time_column = str(era["time_column"])
    value_column = str(era["value_column"])
    series: dict[str, pd.Series] = {}
    for station, entry in era["workbooks"].items():
        path = Path(str(entry["path"]))
        parts: list[pd.DataFrame] = []
        for sheet in entry["sheets"]:
            block = pd.read_excel(path, sheet_name=sheet)
            if time_column not in block.columns or value_column not in block.columns:
                raise RuntimeError(f"raw workbook {path.name} sheet {sheet} lacks expected columns")
            frame = pd.DataFrame(
                {
                    "time": pd.to_datetime(block[time_column], errors="coerce"),
                    "value": [_normalise_raw_value(v, tokens) for v in block[value_column].tolist()],
                }
            ).dropna(subset=["time"])
            parts.append(frame)
        merged = pd.concat(parts, ignore_index=True)
        merged = merged[~merged["time"].duplicated(keep="first")]
        series[station] = merged.set_index("time")["value"].sort_index()
    return pd.DataFrame(series)


def retrace_raw_sources(config: Mapping[str, Any]) -> dict[str, Any]:
    """Compare the single source of truth with both eras of the archived raw record."""
    raw_cfg = config.get("raw_source_verification", {})
    if not raw_cfg.get("enabled", False):
        return {"enabled": False}

    index = _window(config)
    stations = list(config["stations"]["rain_csv_column_order"])
    rain = _read_rain(config)
    tol = float(raw_cfg["value_tolerance_mm"])

    eras = {
        "era_2017_2019": (
            _read_raw_era_2017_2019(config),
            pd.Timestamp(raw_cfg["era_2017_2019"]["covers_window_start"]),
            pd.Timestamp(raw_cfg["era_2017_2019"]["covers_window_end"]),
        ),
        "era_2020_2023": (
            _read_raw_era_2020_2023(config),
            pd.Timestamp(raw_cfg["era_2020_2023"]["covers_window_start"]),
            pd.Timestamp(raw_cfg["era_2020_2023"]["covers_window_end"]),
        ),
    }

    report: dict[str, Any] = {"enabled": True, "value_tolerance_mm": tol, "eras": {}}
    covered = np.zeros(len(index), dtype=bool)
    total_mismatch = 0

    for era_name, (raw_frame, era_start, era_end) in eras.items():
        selected = (index >= era_start) & (index <= era_end)
        covered |= selected
        era_index = index[selected]
        aligned = raw_frame.reindex(era_index)
        era_report: dict[str, Any] = {
            "window_start": str(era_start),
            "window_end": str(era_end),
            "window_hours": int(selected.sum()),
            "stations": {},
        }
        for station in stations:
            if station not in aligned.columns:
                raise RuntimeError(f"raw era {era_name} lacks station {station}")
            raw_values = aligned[station].to_numpy(dtype=float)
            ssot_values = rain.loc[era_index, station].to_numpy(dtype=float)
            raw_present = ~np.isnan(raw_values)
            ssot_present = ~np.isnan(ssot_values)
            both = raw_present & ssot_present
            agree = np.zeros_like(both)
            agree[both] = np.abs(raw_values[both] - ssot_values[both]) <= tol
            value_mismatch = int(both.sum() - agree.sum())
            total_mismatch += value_mismatch
            # Presence differences are two distinct facts and must not be pooled:
            # raw_row_absent  = the archive holds no row at all for that hour (coverage gap);
            # ssot_missing_only = the archive holds a value the single source of truth calls missing.
            era_report["stations"][station] = {
                "raw_rows_present": int(raw_present.sum()),
                "ssot_rows_present": int(ssot_present.sum()),
                "compared_hours": int(both.sum()),
                "value_agreement": int(agree.sum()),
                "value_agreement_rate": (
                    float(agree.sum() / both.sum()) if both.sum() else float("nan")
                ),
                "value_mismatch": value_mismatch,
                "raw_row_absent": int((ssot_present & ~raw_present).sum()),
                "ssot_missing_only": int((raw_present & ~ssot_present).sum()),
            }
        # hours where the archive holds no row for any of the four stations
        era_raw = raw_frame.reindex(era_index)
        no_raw_row = ~era_raw[stations].notna().any(axis=1).to_numpy()
        era_report["hours_with_no_raw_row_for_any_station"] = int(no_raw_row.sum())
        if no_raw_row.any():
            gap = era_index[no_raw_row]
            era_report["raw_coverage_gap_start"] = str(gap.min())
            era_report["raw_coverage_gap_end"] = str(gap.max())
        report["eras"][era_name] = era_report

    report["window_hours_covered_by_some_era"] = int(covered.sum())
    report["window_hours_not_covered"] = int((~covered).sum())
    report["total_value_mismatch"] = total_mismatch
    report["total_hours_with_no_raw_row"] = sum(
        int(era["hours_with_no_raw_row_for_any_station"]) for era in report["eras"].values()
    )

    # Which frozen suspect segments can actually be retraced to the archive, and which cannot.
    retraceable: dict[str, dict[str, Any]] = {}
    all_raw = {name: frame for name, (frame, _, _) in eras.items()}
    for segment in config["segment_contract"]["excluded_segments"]:
        seg_index = pd.date_range(segment["start"], segment["end"], freq="h")
        station = str(segment["station"])
        present = np.zeros(len(seg_index), dtype=bool)
        for era_name, (raw_frame, era_start, era_end) in eras.items():
            inside = (seg_index >= era_start) & (seg_index <= era_end)
            if not inside.any() or station not in raw_frame.columns:
                continue
            aligned = raw_frame.reindex(seg_index[inside])[station].to_numpy(dtype=float)
            present[inside] = ~np.isnan(aligned)
        retraceable[str(segment["segment_id"])] = {
            "station": station,
            "n_hours": int(len(seg_index)),
            "hours_present_in_raw_archive": int(present.sum()),
            "hours_absent_from_raw_archive": int((~present).sum()),
            "fully_retraceable": bool(present.all()),
        }
    report["excluded_segment_raw_retraceability"] = retraceable
    report["excluded_segment_hours_not_retraceable"] = sum(
        entry["hours_absent_from_raw_archive"] for entry in retraceable.values()
    )
    report["interpretation_limit"] = str(raw_cfg["interpretation_limit"]).strip()
    return report


# ---------------------------------------------------------------------------
# Registry, provenance and publication
# ---------------------------------------------------------------------------


def _repository_snapshot(repository: Path) -> dict[str, Any]:
    def run(arguments: Sequence[str]) -> str:
        result = subprocess.run(
            ["git", "-C", str(repository), "-c", "core.quotepath=false", *arguments],
            capture_output=True,
            check=True,
        )
        return result.stdout.decode("utf-8", errors="replace")

    tracked = run(["diff", "--name-status", "HEAD"]).splitlines()
    untracked = run(["ls-files", "--others", "--exclude-standard"]).splitlines()
    staged = run(["diff", "--cached", "--name-status"]).splitlines()

    def lock(lines: Iterable[str]) -> str:
        return hashlib.sha256("\n".join(lines).encode("utf-8")).hexdigest()

    return {
        "repository": str(repository),
        "branch": run(["rev-parse", "--abbrev-ref", "HEAD"]).strip(),
        "head": run(["rev-parse", "HEAD"]).strip(),
        "tracked_entries": len(tracked),
        "staged_entries": len(staged),
        "untracked_entries": len(untracked),
        "tracked_status_lock": lock(tracked),
        "untracked_lock": lock(untracked),
    }


def build_registry(
    config: Mapping[str, Any],
    segment_counts: Mapping[str, Any],
    comparison: pd.DataFrame,
    station_hours: pd.DataFrame,
    retrace: Mapping[str, Any],
) -> pd.DataFrame:
    contract = config["time_contract"]
    arm = config["arm_contract"]
    rows: list[dict[str, Any]] = []

    def add(scope: str, metric: str, value: Any, expected: Any = None) -> None:
        rows.append(
            {
                "scope": scope,
                "metric": metric,
                "value": value,
                "expected": expected,
                "matches_expected": (None if expected is None else value == expected),
            }
        )

    add("timeline", "total_hours", len(comparison), int(contract["total_hours"]))
    for period, expected in (
        ("spinup", contract["spinup_hours"]),
        ("calibration", contract["calibration_hours"]),
        ("verification", contract["verification_hours"]),
    ):
        add("timeline", f"{period}_hours", int((comparison["period"] == period).sum()), int(expected))
    add("timeline", "scored_calibration_hours", int(contract["scored_calibration_hours"]),
        int(contract["scored_calibration_hours"]))
    add("timeline", "invalid_flow_hours", int(contract["invalid_flow_hours"]),
        int(contract["invalid_flow_hours"]))

    for name, value in segment_counts.items():
        add("segments", name, int(value))

    counts = station_hours["qualification_status"].value_counts().to_dict()
    for status in QUALIFICATION_STATUSES:
        add("station_hours", f"status_{status}", int(counts.get(status, 0)))
    add("station_hours", "total_rows", int(len(station_hours)))
    add(
        "station_hours",
        "decision_include",
        int(station_hours["eligibility_decision"].eq("include").sum()),
    )
    add(
        "station_hours",
        "decision_exclude",
        int(station_hours["eligibility_decision"].eq("exclude").sum()),
    )
    add(
        "station_hours",
        "minimum_eligible_stations_per_hour",
        int(comparison["n_eligible_stations_excluded"].min()),
    )

    add("arms", "affected_hours", int(comparison["affected"].sum()),
        int(arm["expected_affected_hours"]))
    add("arms", "changed_hours", int(comparison["changed"].sum()),
        int(arm["expected_changed_hours"]))
    add("arms", "added_rain_mm_total", round(float(comparison["delta_mm"].sum()), 6),
        round(float(arm["expected_added_rain_mm_total"]), 6))
    for period in ("spinup", "calibration", "verification"):
        selected = comparison["period"] == period
        add("arms", f"added_rain_mm_{period}",
            round(float(comparison.loc[selected, "delta_mm"].sum()), 6))
    add("arms", "max_delta_mm", round(float(comparison["delta_mm"].max()), 6))
    add("arms", "min_delta_mm", round(float(comparison["delta_mm"].min()), 6))

    if retrace.get("enabled"):
        expected_gap = config["raw_source_verification"]["expected_coverage_gap"]
        add("raw_retrace", "window_hours_covered", int(retrace["window_hours_covered_by_some_era"]),
            int(contract["total_hours"]))
        add("raw_retrace", "window_hours_not_covered", int(retrace["window_hours_not_covered"]), 0)
        add("raw_retrace", "total_value_mismatch", int(retrace["total_value_mismatch"]), 0)
        add("raw_retrace", "total_hours_with_no_raw_row",
            int(retrace["total_hours_with_no_raw_row"]), int(expected_gap["hours"]))
        add("raw_retrace", "excluded_segment_hours_not_retraceable",
            int(retrace["excluded_segment_hours_not_retraceable"]),
            int(expected_gap["excluded_segment_hours_not_retraceable"]))
        for era_name, era in retrace["eras"].items():
            for station, stats in era["stations"].items():
                add(f"raw_retrace.{era_name}", f"{station}_compared_hours", int(stats["compared_hours"]))
                add(f"raw_retrace.{era_name}", f"{station}_value_mismatch", int(stats["value_mismatch"]), 0)
                add(f"raw_retrace.{era_name}", f"{station}_raw_row_absent",
                    int(stats["raw_row_absent"]))
                add(f"raw_retrace.{era_name}", f"{station}_ssot_missing_only",
                    int(stats["ssot_missing_only"]))
        for segment_id, stats in retrace["excluded_segment_raw_retraceability"].items():
            add("raw_retrace.excluded_segments", f"{segment_id}_hours_absent_from_raw_archive",
                int(stats["hours_absent_from_raw_archive"]))

    return pd.DataFrame(rows)


def _write_csv(frame: pd.DataFrame, path: Path, *, compressed: bool = False) -> None:
    if compressed:
        # gzip embeds a modification timestamp in its header, so the default settings make the
        # artifact bytes, and therefore its SHA-256, differ on every republication even when the
        # payload is identical. Pinning mtime=0 makes the artifact byte-reproducible.
        frame.to_csv(path, index=False, compression={"method": "gzip", "mtime": 0})
    else:
        frame.to_csv(path, index=False)


def expected_relative_artifacts(config: Mapping[str, Any]) -> set[str]:
    return set(config["output"]["expected_artifacts"])


def assert_output_available(output_root: Path, config: Mapping[str, Any]) -> None:
    if output_root.exists() and bool(config["output"].get("refuse_existing", True)):
        raise RuntimeError(f"refusing to overwrite an existing result family: {output_root}")


def run_preflight(config_path: Path = DEFAULT_CONFIG) -> dict[str, Any]:
    """Validate everything without writing a result family."""
    config = load_config(config_path)
    locked = verify_contract_lock()
    hashes = _verify_configured_hashes(config)
    segment_counts = _verify_segment_contract(config)
    station_hours = build_continuous_station_hour_table(config)
    comparison = build_hour_mean_comparison(config_path)
    score_mask = build_score_mask(config_path)
    output_root = validate_output_root(Path(str(config["output"]["root"])))

    report = {
        "family": FAMILY_ID,
        "config_sha256": config["_config_sha256"],
        "contract_lock_verified": sorted(locked),
        "verified_input_count": len(hashes),
        "segment_counts": segment_counts,
        "total_hours": int(len(comparison)),
        "scored_calibration_hours": int(score_mask.sum()),
        "station_hour_rows": int(len(station_hours)),
        "status_counts": {
            status: int((station_hours["qualification_status"] == status).sum())
            for status in QUALIFICATION_STATUSES
        },
        "affected_hours": int(comparison["affected"].sum()),
        "changed_hours": int(comparison["changed"].sum()),
        "added_rain_mm_total": round(float(comparison["delta_mm"].sum()), 6),
        "added_rain_mm_verification": round(
            float(comparison.loc[comparison["period"] == "verification", "delta_mm"].sum()), 6
        ),
        "minimum_eligible_stations_per_hour": int(
            comparison["n_eligible_stations_excluded"].min()
        ),
        "output_root": str(output_root),
        "output_root_exists": output_root.exists(),
        "read_only_repository_write_attempted": False,
    }
    report["ready_to_publish"] = not report["output_root_exists"]
    return report


def publish_family(
    config_path: Path = DEFAULT_CONFIG, output_root: Path | None = None
) -> dict[str, Any]:
    """Validate hashes and atomically publish the qualification family."""
    config = load_config(config_path)
    locked = verify_contract_lock()
    input_hashes = _verify_configured_hashes(config)
    segment_counts = _verify_segment_contract(config)

    root = validate_output_root(Path(output_root or str(config["output"]["root"])))
    assert_output_available(root, config)

    before = {
        "laos_forecast": _repository_snapshot(PROJECT_ROOT),
        "forecast_system_lite": _repository_snapshot(READ_ONLY_REPOSITORY),
    }

    station_hours = build_continuous_station_hour_table(config)
    current, excluded = build_arm_grids(config_path)
    comparison = build_hour_mean_comparison(config_path)
    retrace = retrace_raw_sources(config)
    registry = build_registry(config, segment_counts, comparison, station_hours, retrace)

    failed = registry[registry["matches_expected"].eq(False)]
    if not failed.empty:
        raise RuntimeError(f"registry expectation failures: {failed.to_dict('records')}")

    root.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=f".{FAMILY_ID}.staging.", dir=str(root.parent)))
    try:
        shutil.copyfile(Path(config["_config_path"]), staging / "config_snapshot.yml")
        _write_csv(station_hours, staging / "station_hour_qualification.csv.gz", compressed=True)
        _write_csv(comparison, staging / "hour_mean_comparison.csv.gz", compressed=True)
        _write_csv(current, staging / "grid_hybrid_current.csv")
        _write_csv(excluded, staging / "grid_hybrid_suspect_excluded.csv")
        _write_csv(registry, staging / "registry.csv")
        _write_json(staging / "input_hashes.json", {"inputs": input_hashes, "contract_lock": locked})

        after = {
            "laos_forecast": _repository_snapshot(PROJECT_ROOT),
            "forecast_system_lite": _repository_snapshot(READ_ONLY_REPOSITORY),
        }
        if after["forecast_system_lite"] != before["forecast_system_lite"]:
            raise RuntimeError("the permanently read-only repository changed during publication")

        _write_json(
            staging / "provenance.json",
            {
                "family": FAMILY_ID,
                "created_utc": datetime.now(timezone.utc).isoformat(),
                "python": sys.version,
                "platform": platform.platform(),
                "pandas": pd.__version__,
                "numpy": np.__version__,
                "config_path": config["_config_path"],
                "config_sha256": config["_config_sha256"],
                "contract_lock": locked,
                "raw_source_retrace": retrace,
                "repository_before": before,
                "repository_after": after,
            },
        )

        artifact_hashes = {
            path.name: sha256_file(path) for path in sorted(staging.iterdir()) if path.is_file()
        }
        expected_non_manifest = int(config["output"]["expected_non_manifest_artifacts"])
        if len(artifact_hashes) != expected_non_manifest:
            raise RuntimeError(
                f"produced {len(artifact_hashes)} artifacts, frozen expectation is {expected_non_manifest}"
            )

        manifest = {
            "schema_version": 1,
            "continuous_family": FAMILY_ID,
            "status": "COMPLETED_CONTINUOUS_QUALIFICATION_AND_ARM_FORCING_ONLY",
            "artifact_count_including_manifest": len(artifact_hashes) + 1,
            "artifact_sha256": artifact_hashes,
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "total_hours": int(len(comparison)),
            "station_hour_rows": int(len(station_hours)),
            "qualification_status_counts": {
                status: int((station_hours["qualification_status"] == status).sum())
                for status in QUALIFICATION_STATUSES
            },
            "segment_counts": segment_counts,
            "affected_hours": int(comparison["affected"].sum()),
            "changed_hours": int(comparison["changed"].sum()),
            "added_rain_mm_total": round(float(comparison["delta_mm"].sum()), 6),
            "added_rain_mm_verification": round(
                float(comparison.loc[comparison["period"] == "verification", "delta_mm"].sum()), 6
            ),
            "raw_source_retrace_total_value_mismatch": int(retrace.get("total_value_mismatch", -1)),
            "raw_source_retrace_hours_not_covered": int(retrace.get("window_hours_not_covered", -1)),
            "model_training_performed": False,
            "model_evaluation_performed": False,
            "parameter_calibration_performed": False,
            "forecast_skill_claim": False,
            "rainfall_imputation_performed": False,
            "rainfall_value_inferred": False,
            "source_files_modified": False,
            "read_only_repository_unchanged": True,
            "production_input_change_authorized": False,
            "interpretation_limit": str(config["interpretation_limit"]).strip(),
        }
        _write_json(staging / "family_manifest.json", manifest)

        expected_names = expected_relative_artifacts(config)
        produced = {path.name for path in staging.iterdir() if path.is_file()}
        if produced != expected_names:
            raise RuntimeError(
                f"artifact set drift: missing={sorted(expected_names - produced)}; "
                f"unexpected={sorted(produced - expected_names)}"
            )

        os.replace(staging, root)
        staging = None  # type: ignore[assignment]
    finally:
        if staging is not None and Path(staging).exists():
            shutil.rmtree(staging, ignore_errors=True)

    published = {path.name: sha256_file(path) for path in sorted(root.iterdir()) if path.is_file()}
    for name, digest in artifact_hashes.items():
        if published.get(name) != digest:
            raise RuntimeError(f"artifact hash changed during publication: {name}")

    return {
        "output_root": str(root),
        "artifact_count": len(published),
        "manifest_sha256": published["family_manifest.json"],
        "registry_rows": int(len(registry)),
        "raw_retrace_total_value_mismatch": int(retrace.get("total_value_mismatch", -1)),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--preflight", action="store_true", help="validate without publishing")
    arguments = parser.parse_args()

    if arguments.preflight:
        report = run_preflight(arguments.config)
        print(json.dumps(_jsonable(report), ensure_ascii=False, indent=2, sort_keys=True))
        return

    result = publish_family(arguments.config)
    print(json.dumps(_jsonable(result), ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
