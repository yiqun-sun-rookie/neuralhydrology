# Ku Wei Paired Rainfall-Handling Recalibration Preregistration

Date locked: 2026-08-25, Asia/Singapore.

## Question

Under one corrected calibration contract, does excluding the frozen high-confidence suspect zeros
from the available-station rainfall mean improve 2023 performance after each handling is
**separately recalibrated**?

## Why separate recalibration is required

A fixed-parameter comparison can only answer how an input change propagates through parameters that
were themselves optimised for the current, zero-containing input. It is structurally unfavourable to
the new input and cannot answer whether the new handling is better. The measured fixed-parameter
result illustrates this: over six 2020 events the equal-weight Nash-Sutcliffe efficiency fell from
-2.021013 to -2.981265. That number predicts nothing about the recalibrated direction.

## Two arms and the single changed factor

1. `current_input` — the registered `rain_g0`, a bitwise copy of `grid_hybrid.csv` over the window.
2. `suspect_zero_excluded` — identical except that station-hours frozen as `suspect_zero` are removed
   from that hour's arithmetic mean.

Everything else is shared bitwise: time axis, temperature, potential evapotranspiration, snow,
observed discharge, invalid-flow mask, parameter set, bounds, objective, budget, seeds, initial
populations and evaluation code. Measured difference between the arms: 1,801 affected hours, 348
hours whose value actually changes, 131.791667 mm added in total, all of it inside the calibration
period, and exactly 0.000000 mm in the verification year.

## Frozen optimisation contract

- Objective: Nash-Sutcliffe efficiency. Secondary metrics are reported but may not replace the
  primary conclusion after the fact.
- Seeds `20260824`, `20260825`, `20260826`, each used once per arm, six runs total.
- For each seed one explicit 60-by-17 Latin hypercube population inside the frozen bounds, shared
  bitwise by both arms of that seed; the three population hashes must differ from each other.
- Per run: 60 individuals, at most 400 generations, `workers=1`, `strategy=best1bin`,
  `updating=deferred`, `polish=false`, `tol=0`, `atol=0`, precheck off, resume off.
- Warm start is off: `initial_params` removed, `seed_from` unset, no checkpoint resume. The
  Kling-Gupta-calibrated parameters referenced by the stock configuration were obtained under the
  current rainfall input; seeding them would hand the current-input arm an unearned head start.
- **At most** 24,060 candidate objective evaluations per run. This is a ceiling, not a prediction:
  SciPy spends no evaluation on individuals violating the read-only combined constraints. Measured
  2026-08-25 with the seed-20260824 population and one generation: 120 calls unconstrained, 69 with
  `msk_c0 + msk_c1 <= 0.8` alone, 25 with the full constraint set.

## Determinism prerequisite, already satisfied

The read-only implementation cannot be driven deterministically as shipped: `run_de` exposes no
random seed and no `atol`, its call site passes no `tol` (so the effective setting is the SciPy
default `tol=0.01`), two internal population paths use unseeded `np.random.rand()`, and
`dataio.load_data` consults `<DATA_DIR>/timeseries.db` ahead of the configured `meteo_file`.

The adapter in `deterministic_fsl_calibration_adapter.py` replaces `run_de` for the duration of a run
with a wrapper that calls `scipy.optimize.differential_evolution` directly with an explicit seed, the
explicit population, `tol=0` and `atol=0`, restores the original function and NumPy random state in
`finally`, and materialises an isolated runtime directory proven to contain no `timeseries.db`.

The full-model gate has passed: the same arm and seed run twice produced bitwise-identical initial
population, ordered candidate vectors, ordered objective values, best vector, best objective,
generation count and objective-call count. The trace digest was stable across four independent runs.
This matters because the project has a registered differential-evolution run-to-run spread of plus
or minus 76.6 percent under the stock code path.

## Frozen 2023 event registry

Ten observed events, generated **before any formal run** from the frozen evaluation rule applied to
the observation series, not extracted from any model-evaluation product:

| Observed peak time (ICT, UTC+7) | Observed flow (m³/s) |
|---|---:|
| 2023-05-14 19:00 | 59.5 |
| 2023-07-31 21:00 | 78.6 |
| 2023-08-07 12:00 | 263.0 |
| 2023-08-13 06:00 | 137.0 |
| 2023-08-16 08:00 | 62.1 |
| 2023-08-20 22:00 | 106.0 |
| 2023-08-24 22:00 | 227.0 |
| 2023-08-28 23:00 | 147.0 |
| 2023-10-06 20:00 | 59.5 |
| 2023-10-15 05:00 | 247.0 |

Rule: 95th percentile observed threshold (54.3 m³/s), minimum separation 72 hours, 36-hour windows,
simulated-peak prominence fraction 0.10, rise-start fraction 0.10, one-to-one order-preserving
matching.

**Value provenance, recorded to stop a recurring error.** These flows come from the observation
series. `event_eval_2023_verify_events.csv` stores 78.5999984741211 and 62.09999847412109 for two of
them; that file is a downstream model-evaluation product whose values passed through single
precision, so its residue is precision loss, not extra precision. The raw workbook sheet
`2023年水位流量`, `discharge.csv` and `discharge_clean.csv` all read 78.6 and 62.1. On 2026-08-25 this
registry was briefly "corrected" toward the residue values and that change was withdrawn after
tracing the values to the raw workbook. Anyone who later notices the discrepancy must not repeat it.

The registry is frozen and hashed before either arm runs and may not change after seeing any result.

## Reporting rules

Per seed: 2023 Nash-Sutcliffe efficiency, Kling-Gupta efficiency, root mean square error, mean
absolute error, relative volume bias, and the ten registered events' peak magnitude and timing
errors. Also the signed `suspect_zero_excluded` minus `current_input` difference per seed, the median
paired difference, and the direction count.

No persistence baseline is computed: this is an open-loop historical simulation driven by concurrent
observed rainfall, so there is no forecast lead and no forecast-skill claim is permitted.
Calibration-period scores are diagnostic, not held-out evidence. The historical `NSE=0.5616`
parameter file is context only and is not a reproduction gate, because the evaluation start date and
the 2022 invalid-flow mask were wired into the read-only code after that file was produced
(2026-07-07 and 2026-07-06 respectively, versus the parameters' 2026-05-27).

2023 is outside this experiment's parameter estimation but has been viewed repeatedly by prior
project work. It is a retrospective time-extrapolation check, never a project-level blind holdout.

## Technical success and stop conditions

Technical success does **not** require the excluded arm to improve. A worse, flat or
seed-inconsistent outcome, reported honestly, is a complete experiment.

Execution stops immediately if: the two arms differ in any field other than `rain_g0`; any registered
input hash drifts; the timeline is not exactly 5,136 / 43,824 / 42,360 / 8,760 / 57,720 hours; the
paired populations for a seed are not bitwise identical; the three population hashes are not
distinct; the realised population is expanded beyond 60 rows; the same-seed determinism gate fails;
the event registry is not exactly the ten frozen events; the run reads `timeseries.db` instead of the
registered snapshot; any output path enters the read-only repository; a paired run is missing its
mate; or a final result root already exists.

No seed, run or metric may be dropped after results are seen, and no threshold, budget or conclusion
wording may be changed in response to them.

## Authorisation boundary

Freezing this contract and running the no-formal-calibration preflight is the scope of this step.
Launching the six formal runs, changing the production rainfall input, retraining a deep-learning
model, adding data assimilation or opening a new experiment family each require separate explicit
user authorisation.
