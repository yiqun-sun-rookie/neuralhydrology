# Ku Wei Continuous Rainfall Qualification And Paired Arm Forcing Preregistration

Date locked: 2026-08-25, Asia/Singapore.

## Question

For every one of the 57,720 hours from 2017-06-01 00:00 through 2023-12-31 23:00, and for each of
the four in-basin rain gauges, is the recorded source value eligible to participate in the existing
available-station arithmetic mean, and what are the two resulting hourly basin-rainfall series?

This family produces inputs only. It performs no calibration, no model run, no evaluation and no
forecast.

## Why this family exists

The frozen family `rainfall_input_qualification_20260824` covers only six 2020 flood events and
their preceding 168-hour contexts, about 2,001 event-specific hours. The paired recalibration
experiment needs continuous forcing across 2017 spinup, 2018--2022 calibration and 2023
verification. Without a continuous qualification result there is no input to calibrate on.

## Fixed scope

- Continuous window: `2017-06-01 00:00` through `2023-12-31 23:00`, exactly 57,720 unique, strictly
  hourly, gap-free timestamps.
- Period split: spinup 5,136 h, calibration 43,824 h, verification 8,760 h.
- The 1,464-hour invalid-flow window `2022-09-01 00:00` to `2022-11-01 00:00` is registered as a
  scoring mask only; it does not alter rainfall. Scored calibration hours are 42,360.
- Four stations: Mengwu, Banteng, Aka, Ku Wei rain gauge. Timestamps are Laos local time,
  Coordinated Universal Time plus 7 hours.
- This family reads rainfall lineage plus the registered invalid-flow window list. It does not read
  model parameters, simulations, residuals or forecasts.

## Frozen qualification states

Inherited unchanged from `rainfall_input_qualification_20260824`:

1. `positive` — raw source holds a numeric value greater than zero.
2. `eligible_zero` — raw source holds numeric zero and the conservative rule does not flag the hour.
3. `missing` — source row absent and the single-source status registry says missing.
4. `suspect_zero` — raw source holds numeric zero inside a high-confidence suspect segment.
5. `undetermined` — evidence incomplete without a direct contradiction.

Only `positive` and `eligible_zero` participate in the qualified mean. No missing, suspect or
undetermined value is filled, interpolated or inferred.

## Frozen segment counts

Within the continuous window, read from the frozen segment evidence:

- calibration period `suspect_zero`: 5 segments, 1,968 station-hours;
- calibration period `undetermined`: 1 segment, 144 station-hours;
- full period `undetermined`: 7 segments, 992 station-hours, of which 2023 holds 6 segments and
  848 station-hours;
- verification period `suspect_zero`: 0 segments;
- calibration period retained ordinary zero segments: 43.

Every `undetermined` station-hour is retained in both arms. Excluding one is a stop condition.

## Two arms and the single changed factor

1. `current_input` — the registered `rain_g0`, that is the hourly arithmetic mean over stations whose
   source value is not missing; numeric zeros participate.
2. `suspect_zero_excluded` — identical except that station-hours frozen as `suspect_zero` are removed
   from that hour's mean.

Only `rain_g0` may differ. `time`, `temp_g0`, `pet_g0` and `snow_g0` must be bitwise identical.

## Frozen construction rule and why it is not a plain recomputation

Recomputing every hour from `rain.csv` does not bitwise reproduce the registered `rain_g0`.
Measured on 2026-08-25: recomputing all 57,720 hours without excluding anything still differs from
the registered series at 525 hours, with a maximum absolute difference of 4.441e-16. The cause is
floating point summation order, not data.

A plain recomputation of the excluded arm would therefore carry 523 changed hours that have nothing
to do with excluding a suspect zero, including hours in 2017, 2021, 2022 and 2023 where no suspect
segment exists. That would silently break single-factor isolation and would contaminate the
verification year.

The frozen construction is therefore:

- `current_input` is a bitwise copy of the registered `grid_hybrid.csv` `rain_g0` over the window;
- `suspect_zero_excluded` is a copy of `current_input`, with only the hours that actually lose at
  least one station recomputed, using the arithmetic mean over the remaining eligible stations taken
  in the `rain.csv` column order.

Registered expectations, measured before locking:

- affected hours, meaning hours losing at least one station: 1,801, distributed 2018: 484,
  2019: 491, 2020: 826, and zero in 2017, 2021, 2022 and 2023;
- hours whose mean value actually changes: 348;
- total added rainfall across the window: 131.791667 mm, entirely inside the calibration period;
- added rainfall in the verification year: exactly 0.000000 mm;
- minimum eligible stations per hour after exclusion: 1, never 0;
- every excluded cell is exactly numeric zero in the source, never missing and never positive.

## Raw-source retrace and its declared coverage

Both eras of the archived raw record are read back and compared with the single source of truth:

- 2017-06-01 through 2019-12-31 from the 2014--2021 hourly rainfall workbook, yearly sheets;
- 2020-01-01 through 2023-12-31 from the four 2020--2024 station workbooks.

Coverage, agreement rate and any mismatch are recorded per station and per era in the registry.
Presence differences are recorded as two separate facts and are never pooled into one number:
`raw_row_absent` means the archive holds no row for that hour, while `ssot_missing_only` means the
archive holds a value that the single source of truth calls missing.

A raw retrace confirms that the processed layer reproduces the archived source values. It does not
establish how much rain actually fell, and it does not by itself prove a device failure. Any
unexplained contradiction between frozen sources stops execution instead of being reclassified.

### Registered coverage gap and its consequence

Measured on 2026-08-25: the archive does not cover `2018-06-01 00:00` through `2018-12-31 23:00`,
exactly 5,136 hours, for any of the four gauges. The 2014--2021 workbook sheet for 2018 ends at
`2018-05-31 23:00` and the 2020--2024 workbooks begin at `2020-01-01`. This gap is already
registered in `data/03_final/namou_kuwei/DATA_LINEAGE.md` as "2018: ends 2018-05-31".

Outside the gap the retrace is exact: 17,520 compared hours per station for Mengwu, Banteng and Aka
in the 2017--2019 era and 12,384 for the Ku Wei rain gauge, plus 26,301 to 35,060 per station in the
2020--2023 era, with zero value mismatches everywhere.

The consequence must be stated plainly. The largest frozen suspect-zero segment, Mengwu
`2018-07-12 08:00` to `2018-08-01 11:00`, 484 station-hours, lies **entirely** inside this gap. All
484 of its hours are unretraceable to the archive. Those zeros are traceable only to the single
source of truth. This bounds the evidence strength for that one segment. It does not change how the
two arms are constructed, because both arms read the same single source of truth, and it does not
affect the other four excluded segments, which are fully retraceable.

## Required evidence

- One row per hour per station preserving the raw source value, the processed value, the
  qualification status and the eligibility decision.
- One row per hour comparing the two arms, with the changed flag, the eligible-station counts and
  the signed difference.
- Two meteorological input files differing only in `rain_g0`.
- Registry rows carrying the period counts, segment counts, arm deltas and raw-retrace coverage.
- Input hashes, provenance and a family manifest hashing every non-self artifact.

## Interpretation boundary and stop

The suspect-zero-excluded mean is a source-preserving eligibility calculation. It is not a corrected
basin rainfall estimate, not a claim about true rainfall at the excluded station-hours, not evidence
of instrument failure, and not evidence about model skill. Producing these two inputs authorizes no
production input change.

Execution stops immediately if: any hour has no eligible station after exclusion; any `undetermined`
station-hour is excluded, interpolated or treated as true rainless; the timeline is not exactly
5,136 / 43,824 / 42,360 / 8,760 / 57,720 hours or contains duplicates, gaps or misalignment; the
current arm fails to bitwise reproduce the registered `rain_g0`; the two arms differ in any field
other than `rain_g0`; any excluded cell is not exactly numeric zero in the source; the excluded arm
is anywhere lower than the current arm; the measured affected-hour, changed-hour or added-rainfall
totals differ from the registered expectations; or any output path would enter the permanently
read-only repository.

After the family is published and independently hash-checked, stop. Building the deterministic
optimizer adapter, freezing the paired contract and running any calibration each require separate
explicit user authorization.
