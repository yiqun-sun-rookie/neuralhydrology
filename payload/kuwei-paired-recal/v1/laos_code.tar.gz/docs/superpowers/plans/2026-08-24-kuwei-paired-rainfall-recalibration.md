# 库尾降雨缺测处理成对重新率定实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在同一修正版率定合同下，分别用当前四站可用值平均和排除高可信可疑零值后的可用站平均重新率定库尾新安江降雨径流模型，并在本次参数估计未使用的 2023 年完成成对时间外验证。2023 年已经被项目既有研究多次查看，不得称为项目层面的盲测或从未使用留出集。

**Architecture:** 先建立独立、来源保持的连续降雨资格结果族，再通过 `laos_forecast` 侧的确定性适配器调用永久只读的 `forecast_system_lite` 模型代码。两个情景除逐小时 `rain_g0` 外完全相同，采用相同的成对随机种子、参数边界、目标函数、优化预算、流量掩码和评价代码；每个运行写入隔离目录，最后生成统一登记表和散列清单。

**Tech Stack:** Python 3、pandas、NumPy、SciPy 差分进化、PyYAML、pytest、现有 `forecast_system_lite` 新安江—马斯京根实现。

## Global Constraints

- 唯一允许写入的位置是 `G:\github\pycharm\projects\laos_forecast`。
- `G:\github\pycharm\projects\forecast_system_lite` 永久只读，只允许导入和读取，不得修改、生成结果、提交或推送。
- 两个仓库的现有脏工作树必须原样保留；本计划不包含任何 Git 暂存、提交、恢复、清理或推送步骤。
- 当前阶段不覆盖 `rain.csv`、`missing_status.csv`、`grid_hybrid.csv`、`discharge_clean.csv` 或任何既有结果。
- 降雨站时间均为老挝当地时间（UTC+7）；不得转换时区后再与当前逐小时模型输入混用。
- 处理情景只排除冻结规则判为 `suspect_zero` 的站点小时；`undetermined` 保持当前值并单独登记，禁止插值、反演或填造真实雨量。2018—2022 年率定期有 5 段 `suspect_zero`、合计 1,968 个站点小时，以及 1 段 `undetermined`、144 个站点小时；2017 年预热至 2023 年验证完整连续期共有 7 段 `undetermined`、992 个站点小时，其中 2023 年 6 段、848 个站点小时。
- 率定输入期为 `2017-06-01 00:00` 至 `2022-12-31 23:00`，其中 2017 年仅作连续预热；目标函数从 `2018-01-01 00:00` 开始评分。预热期必须恰为 5,136 小时，率定期必须恰为 43,824 小时。
- `2022-09-01 00:00` 至 `2022-11-01 00:00` 共 1,464 小时的无效流量不得进入率定目标，但模型状态必须连续推进；率定评分小时必须恰为 42,360。
- 时间外验证期固定为 `2023-01-01 00:00` 至 `2023-12-31 23:00`，必须恰为 8,760 小时；从预热开始到验证结束必须恰为 57,720 个唯一、严格逐小时、无缺口的时间戳。2023 年不进入本次参数估计，也不得在看到本次结果后用于删除种子、改变阈值或调整预算；但必须明确它不是项目历史上未查看的盲测集。
- 主率定目标固定为纳什效率系数；同时报告 Kling-Gupta 效率、均方根误差、平均绝对误差、相对水量偏差和洪峰量级/时间误差，但不得根据次要指标事后更换主结论。
- 参数集合和边界固定为现有 17 参数集；两个情景必须使用同一冻结快照。
- 暖启动固定关闭：新合同必须删除或显式置空 `initial_params`，不设置 `seed_from`，并禁止从检查点续跑。当前配置引用的历史 Kling-Gupta 效率参数是在当前降雨输入下得到的，若把它放入共同种群会给当前输入情景一个不必要的起点优势；它只作历史上下文，不进入任何正式初始种群。
- 正式种子固定为 `[20260824, 20260825, 20260826]`，每个种子在两个情景中配对使用。
- 每个种子用 `scipy.stats.qmc.LatinHypercube(d=17, seed=seed)` 在冻结边界内生成一个显式 60 行乘 17 列初始种群；同一种子的两个情景必须逐位使用同一初始种群。显式数组决定实际种群为 60 个体，禁止让 SciPy 把 `pop_size=60` 解释成 17 维的倍数而扩成 1,020 个体。
- 每个正式运行固定 60 个体、`max_iter=400`、`workers=1`、`strategy=best1bin`、`updating=deferred`、`polish=false`、`tol=0`、`atol=0`、预检查关闭、续跑关闭；没有提前终止时每次最多 24,060 次候选目标评估。必须登记实际代数、候选数和目标函数调用数；确定性门禁通过前禁止启动正式率定。
- 2023 年洪峰指标固定使用已登记的一对一事件评价规则：观察流量第 95 百分位阈值、事件最小间隔 72 小时、前后窗口各 36 小时、模拟峰显著性比例 0.10、涨水起点比例 0.10。参考实现为永久只读的 `event_peak_evaluation.py`，其 SHA-256 为 `148181cf09e4e0589c6895bcc3de9c9a06543f22cf59c7706e6d41286c8ca9f7`；必须在任何正式率定前从冻结观察流量生成并锁定 10 场 2023 年事件登记表。
- 本实验是使用同期观测降雨的开环历史模拟，没有预见期；因此不计算持续性预报基线，也不作预报技巧结论。
- 技术完成不等于处理情景改善；即使所有指标变差，完整且公平的成对结果仍属于实验成功完成。

---

### Task 1: 冻结连续降雨资格与两份气象输入

**Files:**
- Create: `basins/namou_kuwei/dl/highflow_2026_06_17/configs/continuous_rainfall_qualification_20260824.yml`
- Create: `docs/experiments/continuous_rainfall_qualification_20260824/PREREGISTRATION.md`
- Create: `docs/experiments/continuous_rainfall_qualification_20260824/CONTRACT_LOCK.json`
- Create: `basins/namou_kuwei/dl/highflow_2026_06_17/scripts/continuous_rainfall_qualification.py`
- Create: `tests/test_continuous_rainfall_qualification.py`
- Create on successful publication: `basins/namou_kuwei/dl/highflow_2026_06_17/results/continuous_rainfall_qualification_20260824/`

**Interfaces:**
- Consumes: `rain.csv`、`missing_status.csv`、`grid_hybrid.csv`、`zero_segment_evidence.csv`、2014—2021 逐小时雨量工作簿和 2020—2024 分站工作簿。
- Produces: `station_hour_qualification.csv.gz`、`hour_mean_comparison.csv.gz`、`grid_hybrid_current.csv`、`grid_hybrid_suspect_excluded.csv`、`registry.csv`、`provenance.json`、`input_hashes.json`、`family_manifest.json`。

- [ ] **Step 1: 写连续资格表的失败测试**

```python
def test_calibration_period_segment_contract():
    rows = load_frozen_segment_decisions(CONFIG_PATH)
    calibration = rows[(rows["end"] >= "2018-01-01") & (rows["start"] < "2023-01-01")]
    suspect = calibration.query("qualification_status == 'suspect_zero'")
    undetermined = calibration.query("qualification_status == 'undetermined'")
    assert len(suspect) == 5
    assert suspect["n_hours"].sum() == 1968
    assert len(undetermined) == 1
    assert undetermined["n_hours"].sum() == 144


def test_full_period_undetermined_contract():
    rows = load_frozen_segment_decisions(CONFIG_PATH)
    full = rows[(rows["end"] >= "2017-06-01") & (rows["start"] < "2024-01-01")]
    undetermined = full.query("qualification_status == 'undetermined'")
    verify_2023 = undetermined[(undetermined["end"] >= "2023-01-01")]
    assert len(undetermined) == 7
    assert undetermined["n_hours"].sum() == 992
    assert len(verify_2023) == 6
    assert verify_2023["n_hours"].sum() == 848


def test_only_rain_g0_differs_between_arm_grids():
    current, excluded = build_arm_grids(CONFIG_PATH)
    assert current["time"].equals(excluded["time"])
    fixed = [column for column in current.columns if column != "rain_g0"]
    pd.testing.assert_frame_equal(current[fixed], excluded[fixed], check_exact=True)
    assert (excluded["rain_g0"] >= current["rain_g0"] - 1e-12).all()
```

- [ ] **Step 2: 运行测试并确认因模块尚不存在而失败**

Run: `python -B -m pytest tests/test_continuous_rainfall_qualification.py -q -p no:cacheprovider`

Expected: FAIL with an import error for `continuous_rainfall_qualification`.

- [ ] **Step 3: 实现来源保持的连续资格构建器**

```python
def load_frozen_segment_decisions(config_path: Path) -> pd.DataFrame:
    """Return frozen 2017-06 through 2023 station-segment decisions with period labels."""


def build_continuous_station_hour_table(config: Mapping[str, Any]) -> pd.DataFrame:
    """Keep source values and assign positive/eligible_zero/missing/suspect_zero/undetermined."""


def build_arm_grids(config_path: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return current and suspect-excluded grids; change rain_g0 only."""


def publish_family(config_path: Path, output_root: Path) -> dict[str, Any]:
    """Validate hashes and atomically publish the qualification family."""
```

The five excluded segments are exactly:

1. 勐乌：`2018-07-12 08:00`—`2018-08-01 11:00`，484 小时；
2. 阿卡：`2019-06-13 12:00`—`2019-07-01 17:00`，438 小时；
3. 库尾雨量：`2019-06-24 19:00`—`2019-07-03 22:00`，220 小时；
4. 班腾：`2020-08-25 18:00`—`2020-09-08 10:00`，329 小时；
5. 班腾：`2020-09-12 16:00`—`2020-10-03 08:00`，497 小时。

The calibration-period undetermined segment `2020-06-27 23:00`—`2020-07-03 22:00` and all six 2023 undetermined segments remain in both arms and are never silently excluded.

- [ ] **Step 4: 增加硬门禁测试**

```python
def test_no_hour_loses_all_stations():
    table = build_continuous_station_hour_table(load_config(CONFIG_PATH))
    eligible = table[table["eligibility_decision"].eq("include")]
    expected = pd.date_range("2017-06-01 00:00", "2023-12-31 23:00", freq="h")
    counts = eligible.groupby("time")["station"].nunique().reindex(expected, fill_value=0)
    pd.testing.assert_index_equal(counts.index, expected, exact=True)
    assert len(counts) == 57720
    assert counts.min() >= 1


def test_continuous_time_axis_and_period_counts():
    table = build_continuous_station_hour_table(load_config(CONFIG_PATH))
    times = pd.DatetimeIndex(table["time"].drop_duplicates())
    expected = pd.date_range("2017-06-01 00:00", "2023-12-31 23:00", freq="h")
    pd.testing.assert_index_equal(times, expected, exact=True)
    assert len(expected) == 57720
    assert ((times >= "2017-06-01") & (times < "2018-01-01")).sum() == 5136
    assert ((times >= "2018-01-01") & (times < "2023-01-01")).sum() == 43824
    assert ((times >= "2023-01-01") & (times < "2024-01-01")).sum() == 8760


def test_scored_calibration_hour_count():
    mask = build_score_mask(CONFIG_PATH)
    assert len(mask) == 43824
    assert int(mask.sum()) == 42360


def test_registered_current_grid_is_exactly_reproduced():
    current, _ = build_arm_grids(CONFIG_PATH)
    source = pd.read_csv(GRID_HYBRID_PATH)
    pd.testing.assert_frame_equal(current, source.loc[current.index], check_exact=True)
```

- [ ] **Step 5: 运行聚焦测试与无写入预检**

Run: `python -B -m pytest tests/test_continuous_rainfall_qualification.py -q -p no:cacheprovider`

Run: `python -B basins/namou_kuwei/dl/highflow_2026_06_17/scripts/continuous_rainfall_qualification.py --preflight`

Expected: tests PASS; preflight distinguishes five calibration-period suspect segments (1,968 station-hours), one calibration-period undetermined segment (144 station-hours), and seven full-period undetermined segments (992 station-hours, including six/848 in 2023); it also reports 57,720 continuous hours, zero non-rain field differences, and no output directory.

- [ ] **Step 6: 发布连续资格结果族并复核散列**

Run: `python -B basins/namou_kuwei/dl/highflow_2026_06_17/scripts/continuous_rainfall_qualification.py`

Expected: one immutable result family with no staging residue; `family_manifest.json` lists every artifact and SHA-256.

### Task 2: 建立确定性差分进化适配器和隔离数据入口

**Files:**
- Create: `basins/namou_kuwei/dl/highflow_2026_06_17/scripts/deterministic_fsl_calibration_adapter.py`
- Create: `tests/test_deterministic_fsl_calibration_adapter.py`
- Read only: `G:/github/pycharm/projects/forecast_system_lite/src/runtime/semi_distributed/core/optimizer_facade.py`
- Read only: `G:/github/pycharm/projects/forecast_system_lite/src/runtime/semi_distributed/core/optimize_eval.py`
- Read only: `G:/github/pycharm/projects/forecast_system_lite/src/runtime/semi_distributed/core/dataio.py`

**Interfaces:**
- Consumes: one arm grid, `discharge_clean.csv`, a frozen 17-parameter configuration snapshot with warm start disabled, a seed, and an output directory under `laos_forecast`.
- Produces: a deterministic call into the read-only model, one explicit 60-by-17 initial population, an isolated runtime data directory without `timeseries.db`, and a complete run provenance record.

- [ ] **Step 1: 写随机性和数据路由失败测试**

```python
def test_same_seed_repeats_identically():
    first = run_quadratic_seed_smoke(seed=20260824)
    second = run_quadratic_seed_smoke(seed=20260824)
    np.testing.assert_array_equal(first.x, second.x)
    assert first.fun == second.fun
    assert first.trace == second.trace


def test_explicit_population_contract():
    first = build_initial_population(seed=20260824, bounds=FROZEN_BOUNDS)
    second = build_initial_population(seed=20260824, bounds=FROZEN_BOUNDS)
    unit = scipy.stats.qmc.LatinHypercube(d=17, seed=20260824).random(n=60)
    expected = scipy.stats.qmc.scale(unit, FROZEN_LOWER_BOUNDS, FROZEN_UPPER_BOUNDS)
    assert first.shape == (60, 17)
    np.testing.assert_array_equal(first, second)
    np.testing.assert_array_equal(first, expected)
    assert np.all(first >= FROZEN_LOWER_BOUNDS)
    assert np.all(first <= FROZEN_UPPER_BOUNDS)
    assert np.unique(first, axis=0).shape[0] == 60


def test_formal_seed_populations_are_distinct():
    hashes = {
        sha256_array(build_initial_population(seed=seed, bounds=FROZEN_BOUNDS))
        for seed in (20260824, 20260825, 20260826)
    }
    assert len(hashes) == 3


def test_warm_start_and_resume_are_disabled():
    runtime = build_runtime_config(BASE_CONFIG_PATH, seed=20260824)
    assert runtime.initial_params is None
    assert runtime.seed_from is None
    assert runtime.resume is False


def test_runtime_data_dir_has_no_database(tmp_path):
    paths = build_isolated_runtime_inputs(INPUT_SPEC, tmp_path)
    assert not (paths.data_dir / "timeseries.db").exists()
    assert paths.meteo_file.is_file()
    assert paths.discharge_file.is_file()
```

- [ ] **Step 2: 运行测试并确认缺少适配器而失败**

Run: `python -B -m pytest tests/test_deterministic_fsl_calibration_adapter.py -q -p no:cacheprovider`

Expected: FAIL with an import error for `deterministic_fsl_calibration_adapter`.

- [ ] **Step 3: 实现种子上下文和隔离输入**

```python
@contextmanager
def seeded_de_context(seed: int) -> Iterator[None]:
    """Seed NumPy population creation and inject the seed into SciPy DE."""


def build_initial_population(seed: int, bounds: Sequence[tuple[float, float]]) -> np.ndarray:
    """Build exactly 60 bounded rows with a seeded 17-dimensional Latin hypercube."""


def build_isolated_runtime_inputs(spec: RuntimeInputSpec, root: Path) -> RuntimePaths:
    """Write explicit meteo/discharge snapshots and assert that no timeseries.db is present."""


def run_calibration_arm(spec: CalibrationRunSpec) -> CalibrationArtifacts:
    """Run one arm/seed with read-only FSL code and outputs forced into laos_forecast."""
```

`optimizer_facade.run_de` 当前没有随机种子参数；`optimize_eval.py` 的调用也没有传种子，并且两条内部种群构造路径使用全局 `np.random.rand()`。正式路径必须用显式 60-by-17 拉丁超立方数组绕开两条内部构造路径；若内部路径仍被调用，预检必须失败。`seeded_de_context` 必须在 `finally` 中恢复原始 NumPy 随机状态和原始导入的 `run_de`。替代封装必须把同一个种子传给 SciPy 差分进化，并固定 `tol=0`、`atol=0`。禁止把配置中的 `seed_from` 路径误当随机种子。

2026-08-25 首查补记事实：`run_de` 除无种子外也没有暴露 `atol` 参数，且 `optimize_eval.py` 末尾对 `run_de` 的调用未传 `tol`，因此现行率定实际生效的是 SciPy 差分进化默认 `tol=0.01`，与本合同的 `tol=0`、`atol=0` 不符。由此明确：正式路径不得经由 `run_de`，适配器必须直接调用 `scipy.optimize.differential_evolution` 并显式传入 `seed`、`init`（60 行显式数组）、`tol=0`、`atol=0`、`polish=False`、`workers=1`、`strategy='best1bin'`、`updating='deferred'`、`maxiter=400`；确定性门禁须登记这些实参的实际取值。

- [ ] **Step 4: 增加永久只读边界和来源选择断言**

```python
def test_output_path_cannot_enter_fsl():
    with pytest.raises(ValueError, match="read-only repository"):
        validate_output_root(FSL_ROOT / "results" / "forbidden")


def test_explicit_csv_source_is_used(tmp_path):
    paths = build_isolated_runtime_inputs(INPUT_SPEC, tmp_path)
    loaded = preflight_model_data(paths)
    assert loaded.meteo_sha256 == sha256(paths.meteo_file)
    assert loaded.discharge_sha256 == sha256(paths.discharge_file)
```

- [ ] **Step 5: 运行适配器单元测试**

Run: `python -B -m pytest tests/test_deterministic_fsl_calibration_adapter.py -q -p no:cacheprovider`

Expected: PASS; same-seed quadratic smoke and Latin-hypercube 60-by-17 initial population are byte-identical, warm start/resume are disabled, and all outputs stay under `laos_forecast`.

- [ ] **Step 6: 运行一次短预算完整模型确定性门禁**

Use the current-input arm twice in separate temporary directories with seed `20260824`, the formal 60-person population, `max_iter=1`, `workers=1`, no resume, and the complete 2017-06 through 2022 model/objective path. Require exact equality of the initial population, ordered candidate vectors, ordered objective values, best vector, best objective, generation count, candidate count, and objective-call count. Provenance timestamps and absolute temporary paths are excluded from byte comparison.

Expected: both short runs are numerically and byte-for-byte identical for every registered deterministic artifact. Any difference stops the experiment before Task 3.

### Task 3: 冻结成对重新率定合同并完成无正式率定预检

**Files:**
- Create: `basins/namou_kuwei/dl/highflow_2026_06_17/configs/paired_rain_recalibration_20260824.yml`
- Create: `docs/experiments/paired_rain_recalibration_20260824/PREREGISTRATION.md`
- Create: `docs/experiments/paired_rain_recalibration_20260824/CONTRACT_LOCK.json`
- Create before any formal run: `docs/experiments/paired_rain_recalibration_20260824/event_registry_2023.csv`
- Create: `basins/namou_kuwei/dl/highflow_2026_06_17/scripts/paired_rain_recalibration.py`
- Create: `tests/test_paired_rain_recalibration.py`

**Interfaces:**
- Consumes: the Task 1 manifest and two grid snapshots, Task 2 deterministic adapter, the frozen event evaluator, fixed source hashes, seeds `[20260824, 20260825, 20260826]`.
- Produces before formal execution: a locked 2023 observed-event registry and a no-formal-calibration preflight report proving single-factor isolation, source routing, deterministic seeds, exact time masks, exact population semantics and output safety.

- [ ] **Step 1: 写合同失败测试**

```python
def test_arm_contract_has_one_changed_factor():
    contract = load_contract(CONFIG_PATH)
    assert contract.arm_ids == ("current_input", "suspect_zero_excluded")
    assert contract.changed_fields == ("meteo_file.rain_g0",)
    assert contract.seeds == (20260824, 20260825, 20260826)
    assert contract.objective == "nse"
    assert contract.workers == 1
    assert contract.population_shape == (60, 17)
    assert contract.max_candidate_evaluations == 24060
    assert contract.initial_params is None
    assert contract.seed_from is None
    assert contract.resume is False


def test_invalid_flow_window_is_exact():
    mask = build_score_mask(CONFIG_PATH)
    invalid = (mask.index >= "2022-09-01") & (mask.index < "2022-11-01")
    assert invalid.sum() == 1464
    assert not mask[invalid].any()
    assert len(mask) == 43824
    assert int(mask.sum()) == 42360


def test_full_time_contract_is_exact_and_aligned():
    current, excluded = load_arm_time_axes(CONFIG_PATH)
    expected = pd.date_range("2017-06-01 00:00", "2023-12-31 23:00", freq="h")
    pd.testing.assert_index_equal(current, expected, exact=True)
    pd.testing.assert_index_equal(excluded, expected, exact=True)
    assert len(expected) == 57720


def test_population_hashes_are_paired_and_seed_distinct():
    paired_hashes = []
    for seed in (20260824, 20260825, 20260826):
        current = population_for_arm(CONFIG_PATH, "current_input", seed)
        excluded = population_for_arm(CONFIG_PATH, "suspect_zero_excluded", seed)
        np.testing.assert_array_equal(current, excluded)
        paired_hashes.append(sha256_array(current))
    assert len(set(paired_hashes)) == 3


def test_frozen_2023_event_registry():
    registry = build_observed_event_registry(CONFIG_PATH)
    assert len(registry) == 10
    assert registry["obs_peak_time"].tolist() == LOCKED_2023_EVENT_TIMES
    assert registry["obs_peak_m3s"].tolist() == LOCKED_2023_EVENT_FLOWS
```

- [ ] **Step 2: 运行测试并确认合同尚不存在**

Run: `python -B -m pytest tests/test_paired_rain_recalibration.py -q -p no:cacheprovider`

Expected: FAIL because the paired contract and runner do not exist.

- [ ] **Step 3: 实现合同验证和预检入口**

```python
def validate_paired_contract(config: Mapping[str, Any]) -> ContractCheck:
    """Assert that only rain_g0 differs and every budget/period/parameter field is paired."""


def run_preflight(config_path: Path) -> dict[str, Any]:
    """Run hashes, routing, full-path determinism, event, population and mask checks without formal DE."""


def run_family(config_path: Path) -> dict[str, Any]:
    """Run six atomic calibration jobs, evaluate 2023, and publish one immutable family."""
```

- [ ] **Step 4: 冻结参数边界、评分口径和禁止项**

The preregistration must state:

- the historical `NSE=0.5616` file is context only and is not a reproduction gate;
- both arms use the corrected evaluation start and the 1,464-hour invalid-flow mask;
- both arms disable warm start/resume, use the same 60-person Latin-hypercube population for each paired seed, and have a maximum of 24,060 candidate evaluations per formal run;
- no seed, run, or metric may be dropped after seeing results;
- the primary scientific comparison is the three paired 2023 NSE differences;
- calibration-period scores are diagnostic, not held-out evidence;
- 2023 is outside this experiment's parameter estimation but has been viewed by prior project work, so it is a retrospective time-extrapolation check rather than a project-level blind holdout;
- the 2023 flood registry is frozen before formal runs from the established 10-event rule and may not be changed after viewing either arm;
- no persistence baseline is reported because this open-loop historical simulation has no forecast lead, and no forecast-skill claim is allowed;
- no production-input change follows automatically from this experiment.

The event registry must reproduce the ten observed peaks already registered by the frozen evaluator and observation series:

| Observed peak time (ICT, UTC+7) | Observed flow (m³/s) |
|---|---:|
| 2023-05-14 19:00 | 59.5 |
| 2023-07-31 21:00 | 78.6 |
| 2023-08-07 12:00 | 263.0 |
| 2023-08-13 06:00 | 137.0 |
| 2023-08-16 08:00 | 62.1 |
| 2023-08-20 22:00 | 106.0 |
| 2023-08-24 22:00 | 227.0 |
| 2023-08-28 23:00 | 147.0 |
| 2023-10-06 20:00 | 59.5 |
| 2023-10-15 05:00 | 247.0 |

2026-08-25 勘误（一次错误修订的撤回）：本表数值**保持原样 78.6 / 62.1，不改**。同日稍早曾把这两行改成
`78.5999984741211` / `62.09999847412109`，理由是「与源文件字面量不符会使精确相等断言必然失败」。
该修订方向错误，现已撤回。查证结果：原始工作簿 `1、七级库尾站.xls` 的 `2023年水位流量` 表、
单一事实来源 `discharge.csv`、掩码版 `discharge_clean.csv` **三者都是 78.6 与 62.1**；
`78.5999984741211` 只出现在 `event_eval_2023_verify_events.csv`，那是一次模型评价的下游产物，
其数值经过单精度往返，属于**精度损失而非更高精度**。

因此事件登记表必须由**冻结评价规则加观测序列**生成，即从 `discharge_clean.csv` 的 2023 年段调用
`detect_observed_events`，而不是从那份模型评价产物里提取数值。已实测：该路径复现**恰好 10 场，
峰值时刻与既有登记逐条一致，峰值流量即本表数值**，`test_frozen_2023_event_registry` 的精确相等断言
成立。下游若再次观察到「本表与 `event_eval_2023_verify_events.csv` 数值不一致」，那是预期的、
已解释的现象，**不得据此再次修改本表**。

The existing source registry is `G:\github\pycharm\projects\laos_forecast\basins\namou_kuwei\dl\highflow_2026_06_17\results\da_eval_framework_2026_07_13\event_eval_2023_verify_events.csv`, SHA-256 `41eb1137ec941cd3acca443dec57610410e170786cb36a5420d534c7821c7985`. It contains several model rows; the new registry must retain one unique copy of the observed time and flow only, then lock its own hash before either arm runs.

- [ ] **Step 5: 运行全部聚焦测试和无正式率定预检**

Run: `python -B -m pytest tests/test_continuous_rainfall_qualification.py tests/test_deterministic_fsl_calibration_adapter.py tests/test_paired_rain_recalibration.py -q -p no:cacheprovider`

Run: `python -B basins/namou_kuwei/dl/highflow_2026_06_17/scripts/paired_rain_recalibration.py --preflight`

Expected: all tests PASS; preflight creates no formal calibration output, proves the short-budget complete model path repeats exactly, proves all three paired seeds generate paired-identical 60-by-17 populations, proves the two arms differ only in `rain_g0`, freezes exactly 10 observed 2023 events, and reports no task-related running process or pre-existing output root.

### Task 4: 运行六个正式率定任务并完成本次率定未使用的2023年时间外验证

**Files:**
- Create atomically: `basins/namou_kuwei/dl/highflow_2026_06_17/results/paired_rain_recalibration_20260824/`
- Create within result family: one directory for each `arm/seed` pair, plus `registry.csv`、`paired_metrics.json`、`provenance.json`、`input_hashes.json`、`family_manifest.json`。

**Interfaces:**
- Consumes: frozen Task 1 family, Task 2 adapter, locked Task 3 contract and locked 2023 event registry.
- Produces: six parameter files, six calibration traces, six 2023 open-loop simulations, paired seed differences and a complete artifact manifest.

- [ ] **Step 1: 确认正式运行前门禁**

Run: `python -B basins/namou_kuwei/dl/highflow_2026_06_17/scripts/paired_rain_recalibration.py --preflight`

Expected: `ready_for_six_paired_runs=true`; any failed hash, route, mask, seed, existing-output or repository-preservation check must stop execution.

- [ ] **Step 2: 启动一次且仅一次的正式结果族**

Run: `python -B basins/namou_kuwei/dl/highflow_2026_06_17/scripts/paired_rain_recalibration.py`

Expected: six completed jobs: two arms times three paired seeds. The runner must refuse an existing final root and must never resume one arm without its paired mate under the same seed.

- [ ] **Step 3: 对每个参数文件独立重放2023年**

For each arm/seed, rerun a deterministic open-loop 2023 simulation from the same arm-specific continuous state history. Assert that the evaluated parameter SHA-256 is the one registered by that calibration run, that 2023 observations are identical across all six rows, and that all 8,760 2023 timestamps are unique, hourly and gap-free. This is time-extrapolation relative to the current parameter fit, not a previously unseen project-level blind test.

- [ ] **Step 4: 生成成对指标和明确边界**

`paired_metrics.json` must contain, per seed:

- 2018—2022 scored-hour objective and all-hours diagnostics;
- 2023 NSE、Kling-Gupta efficiency、均方根误差、平均绝对误差、相对水量偏差；
- registered 2023 flood-event peak magnitude and timing errors;
- `suspect_zero_excluded - current_input` signed differences;
- all three paired differences, median paired difference, and direction count;
- initial-population SHA-256, 60-person population size, completed generations, candidate evaluations and actual objective-function calls;
- `parameter_recalibrated=true`、`verification_year_used_in_current_parameter_estimation=false`、`project_level_blind_holdout=false`、`production_input_change_authorized=false`。

Peak magnitude and timing metrics must use the locked ten-event registry and frozen one-to-one matching rule. Do not calculate a persistence baseline: there is no forecast lead in this historical open-loop experiment.

- [ ] **Step 5: 原子发布并停止**

Expected: the final family contains no staging directory, no missing seed, no mixed source hash, and no write under `forecast_system_lite`. Stop after publication; do not alter production configuration.

### Task 5: 独立复算、完整性审计和结论分级

**Files:**
- Read: all artifacts from Task 4.
- No new scientific result files unless the locked contract explicitly registers an audit report.

**Interfaces:**
- Consumes: frozen result family.
- Produces: an independent PASS/FAIL audit and a fact/inference/unknown conclusion for the user.

- [ ] **Step 1: 独立复算成对指标**

Use a separate reader that does not import `paired_rain_recalibration.py`. Recompute all 2023 metrics from saved time series and require absolute difference `<=1e-6` from `paired_metrics.json`.

- [ ] **Step 2: 重新散列所有工件**

Recompute every SHA-256 in `family_manifest.json`; require exact artifact count, no extra file, no missing file, and no staging residue.

- [ ] **Step 3: 复核仓库保存状态**

Verify that `forecast_system_lite` branch, HEAD, tracked diff, staged diff and untracked aggregate equal the preflight snapshot. Verify that `laos_forecast` differs from preflight only by declared task files and the final result family.

- [ ] **Step 4: 按证据等级报告**

- Fact: the three paired-seed 2023 time-extrapolation metric differences and parameter changes.
- Inference: whether direction is consistent enough to justify a separate production-readiness study.
- Unknown: true rainfall at excluded station-hours, transfer to future years, forecast performance with data assimilation, and operational benefit.

Do not write “improved” when only a calibration score rises, when the three 2023 paired directions disagree, or when peak error and whole-process error point in different directions.

- [ ] **Step 5: 停止条件**

After the independent audit, stop and report. Changing the production rainfall input, retraining a deep-learning model, adding data assimilation, changing the objective, adding seeds, or rerunning failed arms requires a separate explicit user authorization and a new experiment family.
