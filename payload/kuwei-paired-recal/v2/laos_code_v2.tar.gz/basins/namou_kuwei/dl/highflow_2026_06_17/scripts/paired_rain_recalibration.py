"""Freeze and execute the paired rainfall-handling recalibration.

Two arms differ in exactly one field, hourly ``rain_g0``. Each arm is recalibrated separately under
one corrected contract, then compared on 2023, which is outside this experiment's parameter
estimation but has been viewed repeatedly by prior project work and is therefore a retrospective
time-extrapolation check rather than a blind holdout.

``--preflight`` performs every check without running a formal calibration. Running the six formal
jobs requires the explicit ``run_family`` entry point and separate user authorisation.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import shutil
import sys
import tempfile
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
import pandas as pd
import yaml


HERE = Path(__file__).resolve().parent
CAMPAIGN_ROOT = HERE.parent
sys.path.insert(0, str(HERE))
import deterministic_fsl_calibration_adapter as adapter  # noqa: E402

PROJECT_ROOT = adapter.PROJECT_ROOT
map_registered_path = adapter.map_registered_path
DEFAULT_CONFIG = CAMPAIGN_ROOT / "configs" / "paired_rain_recalibration_20260824.yml"
CONTRACT_LOCK_PATH = (
    PROJECT_ROOT / "docs" / "experiments" / "paired_rain_recalibration_20260824" / "CONTRACT_LOCK.json"
)
READ_ONLY_REPOSITORY = adapter.READ_ONLY_REPOSITORY

FAMILY_ID = "paired_rain_recalibration_20260824"
FROZEN_CONFIG_SHA256 = "35692bcd4fede09ab70beebf8c830fd334a2302b7fbee8c3cd47d8505a79611e"
FROZEN_CONTRACT_LOCK_SHA256 = "88b07534f53025e1757ff73f54d408184dd13865d82eb285644b7c691ee51655"

LOCKED_2023_EVENT_TIMES: tuple[str, ...] = (
    "2023-05-14 19:00:00", "2023-07-31 21:00:00", "2023-08-07 12:00:00",
    "2023-08-13 06:00:00", "2023-08-16 08:00:00", "2023-08-20 22:00:00",
    "2023-08-24 22:00:00", "2023-08-28 23:00:00", "2023-10-06 20:00:00",
    "2023-10-15 05:00:00",
)
LOCKED_2023_EVENT_FLOWS: tuple[float, ...] = (
    59.5, 78.6, 263.0, 137.0, 62.1, 106.0, 227.0, 147.0, 59.5, 247.0,
)


def sha256_file(path: Path) -> str:
    return adapter.sha256_file(Path(path))


def _jsonable(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    if isinstance(value, (pd.Timestamp, datetime)):
        return value.isoformat()
    if isinstance(value, Path):
        return str(value)
    return value


def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.write_text(
        json.dumps(_jsonable(payload), ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def validate_output_root(path: Path) -> Path:
    return adapter.validate_output_root(Path(path))


def verify_contract_lock(lock_path: Path = CONTRACT_LOCK_PATH) -> dict[str, str]:
    lock_path = Path(lock_path).resolve()
    actual = sha256_file(lock_path)
    if actual != FROZEN_CONTRACT_LOCK_SHA256:
        raise RuntimeError(
            f"frozen contract-lock hash mismatch: expected={FROZEN_CONTRACT_LOCK_SHA256}; actual={actual}"
        )
    payload = json.loads(lock_path.read_text(encoding="utf-8"))
    if payload.get("audit_family") != FAMILY_ID:
        raise RuntimeError("contract-lock family identity drifted")
    locked = payload.get("locked_files")
    if not isinstance(locked, Mapping) or set(locked) != {
        "implementation_plan", "configuration", "preregistration", "event_registry"
    }:
        raise RuntimeError("contract-lock file registry drifted")
    verified: dict[str, str] = {}
    root = PROJECT_ROOT.resolve()
    for name, entry in locked.items():
        path = map_registered_path(entry["path"]).resolve()
        if path != root and root not in path.parents:
            raise RuntimeError(f"contract-lock path escapes the project repository: {path}")
        got = sha256_file(path)
        if got != str(entry["sha256"]).lower():
            raise RuntimeError(f"locked file hash mismatch for {name}")
        verified[str(name)] = got
    return verified


# ---------------------------------------------------------------------------
# Contract
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ContractCheck:
    arm_ids: tuple[str, ...]
    changed_fields: tuple[str, ...]
    seeds: tuple[int, ...]
    objective: str
    workers: int
    population_shape: tuple[int, int]
    max_candidate_evaluations: int
    initial_params: Any
    seed_from: Any
    resume: bool


def load_config(path: Path = DEFAULT_CONFIG) -> dict[str, Any]:
    path = Path(path).resolve()
    actual = sha256_file(path)
    if actual != FROZEN_CONFIG_SHA256:
        raise RuntimeError(
            f"frozen configuration hash mismatch: expected={FROZEN_CONFIG_SHA256}; actual={actual}"
        )
    config = yaml.safe_load(path.read_text(encoding="utf-8"))
    if config.get("paired_family", {}).get("id") != FAMILY_ID:
        raise RuntimeError("configuration family identity drifted")
    config["_config_path"] = str(path)
    config["_config_sha256"] = actual
    return config


def load_contract(config_path: Path = DEFAULT_CONFIG) -> ContractCheck:
    config = load_config(config_path)
    optimizer = config["optimizer_contract"]
    return ContractCheck(
        arm_ids=tuple(config["arms"]["arm_ids"]),
        changed_fields=tuple(config["arms"]["changed_fields"]),
        seeds=tuple(int(s) for s in optimizer["seeds"]),
        objective=str(optimizer["objective"]).strip().lower(),
        workers=int(optimizer["workers"]),
        population_shape=tuple(int(v) for v in optimizer["population_shape"]),  # type: ignore[arg-type]
        max_candidate_evaluations=int(optimizer["max_candidate_evaluations"]),
        initial_params=optimizer["initial_params"],
        seed_from=optimizer["seed_from"],
        resume=bool(optimizer["resume"]),
    )


def validate_paired_contract(config: Mapping[str, Any]) -> ContractCheck:
    """Assert that only rain_g0 differs and every budget/period/parameter field is paired."""
    arms = config["arms"]
    optimizer = config["optimizer_contract"]
    if tuple(arms["arm_ids"]) != ("current_input", "suspect_zero_excluded"):
        raise RuntimeError("arm identity drifted")
    if tuple(arms["changed_fields"]) != ("meteo_file.rain_g0",):
        raise RuntimeError("more than one factor is declared as changed")
    if tuple(int(s) for s in optimizer["seeds"]) != adapter.FORMAL_SEEDS:
        raise RuntimeError("seed set drifted")
    if tuple(int(v) for v in optimizer["population_shape"]) != (
        adapter.POPULATION_ROWS, adapter.PARAMETER_DIMENSION
    ):
        raise RuntimeError("population shape drifted")
    if optimizer["initial_params"] is not None or optimizer["seed_from"] is not None:
        raise RuntimeError("warm start must be disabled")
    if bool(optimizer["resume"]):
        raise RuntimeError("resume must be disabled")
    if int(optimizer["workers"]) != 1:
        raise RuntimeError("workers must be 1")
    if float(optimizer["tol"]) != 0.0 or float(optimizer["atol"]) != 0.0:
        raise RuntimeError("tol and atol must both be 0")
    bounds = tuple(tuple(map(float, b)) for b in optimizer["bounds"])
    if bounds != adapter.FROZEN_BOUNDS:
        raise RuntimeError("parameter bounds drifted from the adapter's frozen contract")
    if tuple(optimizer["parameter_names"]) != adapter.FROZEN_PARAMETER_NAMES:
        raise RuntimeError("parameter names drifted")
    if not bool(optimizer["max_candidate_evaluations_is_upper_bound"]):
        raise RuntimeError("the candidate budget must be declared an upper bound")
    return load_contract(Path(config["_config_path"]))


def build_score_mask(config_path: Path = DEFAULT_CONFIG) -> pd.Series:
    config = load_config(config_path)
    contract = config["time_contract"]
    index = pd.date_range(contract["calibration_start"], contract["calibration_end"], freq="h")
    mask = pd.Series(True, index=index)
    start, end = contract["invalid_flow_window"]
    # the read-only implementation drops [start, end + 23:59]
    invalid = (index >= pd.Timestamp(start)) & (
        index <= pd.Timestamp(end) + pd.Timedelta(hours=23, minutes=59)
    )
    mask.loc[index[invalid]] = False
    if int(invalid.sum()) != int(contract["invalid_flow_hours"]):
        raise RuntimeError(f"invalid-flow window is {int(invalid.sum())} hours")
    if int(mask.sum()) != int(contract["scored_calibration_hours"]):
        raise RuntimeError("scored calibration hour count drift")
    return mask


def load_arm_time_axes(config_path: Path = DEFAULT_CONFIG) -> tuple[pd.DatetimeIndex, pd.DatetimeIndex]:
    config = load_config(config_path)
    axes = []
    for arm in config["arms"]["arm_ids"]:
        path = map_registered_path(config["arms"]["meteo"][arm]["path"])
        frame = pd.read_csv(path, usecols=["time"], parse_dates=["time"])
        # normalise the index name so callers can compare against a bare date_range
        axes.append(pd.DatetimeIndex(frame["time"]).rename(None))
    return axes[0], axes[1]


def population_for_arm(config_path: Path, arm_id: str, seed: int) -> np.ndarray:
    config = load_config(config_path)
    if arm_id not in config["arms"]["arm_ids"]:
        raise ValueError(f"unknown arm: {arm_id}")
    # the population depends only on the seed and the frozen bounds, never on the arm
    return adapter.build_initial_population(int(seed), adapter.FROZEN_BOUNDS)


def build_observed_event_registry(config_path: Path = DEFAULT_CONFIG) -> pd.DataFrame:
    """Regenerate the ten 2023 events from the frozen rule and the observation series."""
    config = load_config(config_path)
    event = config["event_contract"]
    rule = event["rule"]
    if str(READ_ONLY_REPOSITORY) not in sys.path:
        sys.path.insert(0, str(READ_ONLY_REPOSITORY))
    from scripts.event_peak_evaluation import detect_observed_events

    evaluator = map_registered_path(event["evaluator"]["path"])
    if sha256_file(evaluator) != str(event["evaluator"]["sha256"]).lower():
        raise RuntimeError("the frozen event evaluator drifted")

    discharge_path = map_registered_path(config["arms"]["discharge"]["path"])
    if sha256_file(discharge_path) != str(config["arms"]["discharge"]["sha256"]).lower():
        raise RuntimeError("observed discharge drifted")

    contract = config["time_contract"]
    index = pd.date_range(contract["verification_start"], contract["verification_end"], freq="h")
    series = pd.read_csv(discharge_path, parse_dates=["time"]).set_index("time").loc[index, "q_obs"]
    values = series.to_numpy(dtype=float)
    if np.isnan(values).any():
        raise RuntimeError("the verification year contains missing observed flow")

    events, height = detect_observed_events(
        values,
        index,
        np.ones(len(index), dtype=bool),
        min_separation_hours=int(rule["min_separation_hours"]),
        window_hours=int(rule["window_hours"]),
    )
    if abs(float(height) - float(rule["observed_height_threshold_m3s"])) > 1e-9:
        raise RuntimeError(f"observed threshold drifted: {height}")
    registry = pd.DataFrame(
        [
            {
                "event_index": i,
                "obs_peak_time": e["time"].strftime("%Y-%m-%d %H:%M:%S"),
                "obs_peak_m3s": float(e["peak_m3s"]),
            }
            for i, e in enumerate(events)
        ]
    )
    if len(registry) != int(event["expected_event_count"]):
        raise RuntimeError(f"event count drift: {len(registry)}")
    return registry


def verify_frozen_event_registry(config_path: Path = DEFAULT_CONFIG) -> dict[str, Any]:
    config = load_config(config_path)
    frozen_path = map_registered_path(config["event_contract"]["registry"]["path"])
    expected = str(config["event_contract"]["registry"]["sha256"]).lower()
    actual = sha256_file(frozen_path)
    if actual != expected:
        raise RuntimeError(f"frozen event registry drifted: {actual}")
    frozen = pd.read_csv(frozen_path)
    regenerated = build_observed_event_registry(config_path)
    if frozen["obs_peak_time"].tolist() != regenerated["obs_peak_time"].tolist():
        raise RuntimeError("regenerated event times differ from the frozen registry")
    if not np.array_equal(
        frozen["obs_peak_m3s"].to_numpy(float), regenerated["obs_peak_m3s"].to_numpy(float)
    ):
        raise RuntimeError("regenerated event flows differ from the frozen registry")
    return {
        "event_count": int(len(frozen)),
        "registry_sha256": actual,
        "regenerated_matches_frozen": True,
    }


# ---------------------------------------------------------------------------
# Preflight
# ---------------------------------------------------------------------------


def _verify_registered_hashes(config: Mapping[str, Any]) -> dict[str, str]:
    verified: dict[str, str] = {}

    def check(label: str, entry: Mapping[str, Any]) -> None:
        path = map_registered_path(entry["path"])
        got = sha256_file(path)
        if got != str(entry["sha256"]).lower():
            raise RuntimeError(f"input hash drift for {label}: {got}")
        verified[label] = got

    for key, entry in config["source_reference"].items():
        check(f"source_reference.{key}", entry)
    for arm, entry in config["arms"]["meteo"].items():
        check(f"arms.meteo.{arm}", entry)
    check("arms.discharge", config["arms"]["discharge"])
    check("event_contract.registry", config["event_contract"]["registry"])
    check("event_contract.evaluator", config["event_contract"]["evaluator"])
    return verified


def _verify_arms_differ_only_in_rain(config: Mapping[str, Any]) -> dict[str, Any]:
    left = pd.read_csv(map_registered_path(config["arms"]["meteo"]["current_input"]["path"]), parse_dates=["time"])
    right = pd.read_csv(
        map_registered_path(config["arms"]["meteo"]["suspect_zero_excluded"]["path"]), parse_dates=["time"]
    )
    if list(left.columns) != list(right.columns):
        raise RuntimeError("arm column sets differ")
    for column in config["arms"]["identical_fields"]:
        if not left[column].equals(right[column]):
            raise RuntimeError(f"arms differ in {column}; only rain_g0 may differ")
    delta = right["rain_g0"].to_numpy() - left["rain_g0"].to_numpy()
    if delta.min() < -1e-12:
        raise RuntimeError("the excluded arm is lower than the current arm somewhere")
    contract = config["time_contract"]
    times = pd.DatetimeIndex(left["time"])
    if len(times) != int(contract["total_hours"]):
        raise RuntimeError(f"arm length {len(times)} != {contract['total_hours']}")
    verification = times >= pd.Timestamp(contract["verification_start"])
    return {
        "changed_hours": int((delta != 0.0).sum()),
        "added_rain_mm_total": round(float(delta.sum()), 6),
        "added_rain_mm_verification": round(float(delta[verification].sum()), 6),
        "total_hours": int(len(times)),
    }


def _determinism_gate_status(config: Mapping[str, Any]) -> dict[str, Any]:
    path = map_registered_path(config["determinism_contract"]["gate_artifact"])
    if not path.is_file():
        return {"present": False, "all_identical": False}
    payload = json.loads(path.read_text(encoding="utf-8"))
    return {
        "present": True,
        "all_identical": bool(payload.get("all_identical")),
        "comparisons": payload.get("comparisons"),
        "trace_digest": payload.get("trace_digest"),
        "population_sha256": payload.get("population_sha256"),
    }


def run_preflight(config_path: Path = DEFAULT_CONFIG) -> dict[str, Any]:
    """Run hashes, routing, event, population and mask checks without any formal calibration."""
    config = load_config(config_path)
    locked = verify_contract_lock()
    contract = validate_paired_contract(config)
    hashes = _verify_registered_hashes(config)
    arm_delta = _verify_arms_differ_only_in_rain(config)
    mask = build_score_mask(config_path)
    events = verify_frozen_event_registry(config_path)
    gate = _determinism_gate_status(config)

    populations: dict[int, str] = {}
    for seed in contract.seeds:
        left = population_for_arm(config_path, "current_input", seed)
        right = population_for_arm(config_path, "suspect_zero_excluded", seed)
        if not np.array_equal(left, right):
            raise RuntimeError(f"paired populations differ for seed {seed}")
        if left.shape != (adapter.POPULATION_ROWS, adapter.PARAMETER_DIMENSION):
            raise RuntimeError("population shape drift")
        populations[int(seed)] = adapter.sha256_array(left)
    if len(set(populations.values())) != 3:
        raise RuntimeError("the three seed populations are not distinct")

    left_axis, right_axis = load_arm_time_axes(config_path)
    expected_axis = pd.date_range(
        config["time_contract"]["spinup_start"], config["time_contract"]["verification_end"], freq="h"
    )
    for axis in (left_axis, right_axis):
        if not axis.equals(expected_axis):
            raise RuntimeError("an arm time axis drifted")

    output_root = validate_output_root(map_registered_path(config["output"]["root"]))

    report = {
        "family": FAMILY_ID,
        "config_sha256": config["_config_sha256"],
        "contract_lock_verified": sorted(locked),
        "verified_input_count": len(hashes),
        "arm_ids": list(contract.arm_ids),
        "changed_fields": list(contract.changed_fields),
        "objective": contract.objective,
        "workers": contract.workers,
        "seeds": list(contract.seeds),
        "population_shape": list(contract.population_shape),
        "population_hashes": populations,
        "population_hashes_distinct": len(set(populations.values())) == 3,
        "max_candidate_evaluations_upper_bound": contract.max_candidate_evaluations,
        "warm_start_disabled": contract.initial_params is None and contract.seed_from is None,
        "resume_disabled": contract.resume is False,
        "calibration_hours": int(len(mask)),
        "scored_calibration_hours": int(mask.sum()),
        "invalid_flow_hours": int(len(mask) - mask.sum()),
        "arm_difference": arm_delta,
        "event_registry": events,
        "determinism_gate": gate,
        "output_root": str(output_root),
        "output_root_exists": output_root.exists(),
        "formal_calibration_performed": False,
        "created_utc": datetime.now(timezone.utc).isoformat(),
    }
    report["ready_for_six_paired_runs"] = bool(
        not report["output_root_exists"]
        and report["population_hashes_distinct"]
        and report["warm_start_disabled"]
        and report["resume_disabled"]
        and report["scored_calibration_hours"] == 42360
        and report["event_registry"]["event_count"] == 10
        and gate.get("all_identical") is True
        and arm_delta["added_rain_mm_verification"] == 0.0
    )
    return report


# ---------------------------------------------------------------------------
# Formal family (requires separate authorisation to invoke)
# ---------------------------------------------------------------------------


def run_family(config_path: Path = DEFAULT_CONFIG) -> dict[str, Any]:
    """Run six atomic calibration jobs, evaluate 2023, and publish one immutable family."""
    config = load_config(config_path)
    preflight = run_preflight(config_path)
    if not preflight["ready_for_six_paired_runs"]:
        raise RuntimeError(f"preflight did not authorise formal runs: {preflight}")

    root = validate_output_root(map_registered_path(config["output"]["root"]))
    if root.exists():
        raise RuntimeError(f"refusing to overwrite an existing result family: {root}")

    contract = load_contract(config_path)
    root.mkdir(parents=True, exist_ok=True)
    runs: list[dict[str, Any]] = []
    for seed in contract.seeds:
        for arm in contract.arm_ids:
            spec = adapter.CalibrationRunSpec(
                arm_id=arm,
                seed=int(seed),
                output_root=root / f"{arm}_seed{seed}",
                max_iter=int(config["optimizer_contract"]["max_iter"]),
                record_candidates=False,
            )
            artifacts = adapter.run_calibration_arm(spec)
            runs.append(
                {
                    "arm_id": arm,
                    "seed": int(seed),
                    "best_score": artifacts.best_score,
                    "population_sha256": artifacts.population_sha256,
                    "generations": artifacts.generations,
                    "objective_calls": artifacts.objective_calls,
                    "elapsed_seconds": round(artifacts.elapsed_seconds, 1),
                    "meteo_sha256": artifacts.sources.meteo_sha256,
                    "discharge_sha256": artifacts.sources.discharge_sha256,
                }
            )
    _write_json(root / "runs.json", {"runs": runs})
    return {"output_root": str(root), "run_count": len(runs), "runs": runs}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--preflight", action="store_true")
    parser.add_argument(
        "--run-family",
        action="store_true",
        help="launch the six formal calibrations; requires separate user authorisation",
    )
    arguments = parser.parse_args()

    if arguments.preflight:
        print(json.dumps(_jsonable(run_preflight(arguments.config)), ensure_ascii=False, indent=2, sort_keys=True))
        return
    if arguments.run_family:
        print(json.dumps(_jsonable(run_family(arguments.config)), ensure_ascii=False, indent=2, sort_keys=True))
        return
    parser.error("choose --preflight or --run-family")


if __name__ == "__main__":
    main()
