"""Deterministic adapter around the permanently read-only forecast_system_lite calibration.

Why this file exists
--------------------
The read-only implementation cannot be driven deterministically as shipped:

* ``optimizer_facade.run_de`` exposes no random seed, and the call site in ``optimize_eval`` passes
  none, so two runs of the same arm differ by optimizer noise alone;
* ``run_de`` also exposes no ``atol``, and the call site passes no ``tol`` either, so the effective
  setting today is the SciPy default ``tol=0.01`` rather than the contracted ``tol=0``/``atol=0``;
* two internal population paths build the remaining individuals with unseeded ``np.random.rand()``;
* ``dataio.load_data`` consults ``<DATA_DIR>/timeseries.db`` first and silently ignores the
  configured ``meteo_file`` when that database exists.

This adapter fixes all four from the writable repository without editing a single read-only file.
It replaces ``optimize_eval.run_de`` for the duration of one run with a wrapper that calls
``scipy.optimize.differential_evolution`` directly with an explicit seed, an explicit 60-by-17
initial population, ``tol=0`` and ``atol=0``; it restores the original function and the NumPy
random state in ``finally``; and it materialises an isolated runtime data directory that provably
contains no ``timeseries.db``.

It performs no calibration on import. Running a formal family is a separate, separately authorized
step.
"""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import json
import os
import platform
import re
import shutil
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterator, Mapping, Sequence

import numpy as np
import pandas as pd
import yaml
from scipy.optimize import differential_evolution
from scipy.stats import qmc


HERE = Path(__file__).resolve().parent
CAMPAIGN_ROOT = HERE.parent

# Registered (Windows) roots. Every path inside a frozen configuration is written against these,
# because the configuration file itself is hash-locked and must never be rewritten per machine.
REGISTERED_LAOS_ROOT = "G:/github/pycharm/projects/laos_forecast"
REGISTERED_FSL_ROOT = "G:/github/pycharm/projects/forecast_system_lite"

# Actual roots on this machine. Set KUWEI_LAOS_ROOT / KUWEI_FSL_ROOT to run the identical, still
# hash-verified contract on another host, for example an HPC compute node.
PROJECT_ROOT = Path(os.environ.get("KUWEI_LAOS_ROOT") or CAMPAIGN_ROOT.parents[3])
READ_ONLY_REPOSITORY = Path(os.environ.get("KUWEI_FSL_ROOT") or REGISTERED_FSL_ROOT)
FSL_ROOT = READ_ONLY_REPOSITORY


def map_registered_path(path: Any) -> Path:
    """Translate a path registered in a frozen configuration onto this machine's roots.

    The configuration is hash-locked, so it keeps the original absolute paths. Only the root
    prefix is remapped here; the remainder, and therefore the file content and its SHA-256, is
    unchanged. On the machine where the contract was authored this is the identity mapping.
    """
    text = str(path).replace("\\", "/")
    for registered, actual in (
        (REGISTERED_LAOS_ROOT, PROJECT_ROOT),
        (REGISTERED_FSL_ROOT, READ_ONLY_REPOSITORY),
    ):
        if text.lower().startswith(registered.lower()):
            remainder = text[len(registered):].lstrip("/")
            return Path(actual) / remainder if remainder else Path(actual)
    return Path(text)

BASE_RUN_CONFIG = FSL_ROOT / "basins" / "namou_kuwei" / "config" / "run_config.yml"
BASE_RUN_CONFIG_SHA256 = "b1348d716365b04817e8bb14877ead0d9d2c8b2a30184249cf755cd410ddd34e"

CONTINUOUS_FAMILY = (
    CAMPAIGN_ROOT
    / "results"
    / "continuous_rainfall_qualification_20260824"
)
ARM_GRID_FILES = {
    "current_input": CONTINUOUS_FAMILY / "grid_hybrid_current.csv",
    "suspect_zero_excluded": CONTINUOUS_FAMILY / "grid_hybrid_suspect_excluded.csv",
}
CLEAN_DISCHARGE = PROJECT_ROOT / "data" / "03_final" / "namou_kuwei" / "discharge_clean.csv"

FORMAL_SEEDS = (20260824, 20260825, 20260826)
POPULATION_ROWS = 60
PARAMETER_DIMENSION = 17
MAX_ITER = 400
# Upper bound only: 60 initial individuals plus 400 generations of 60. Measured on 2026-08-25,
# SciPy does NOT spend an objective evaluation on an individual that violates the read-only
# combined constraints (msk_c0 + msk_c1 <= 0.8 among them), so the realised call count is
# materially lower. Reference measurements with the frozen seed-20260824 population and maxiter=1:
# no constraint -> 120 calls; c0+c1 <= 0.8 alone -> 69 calls; the full fsl combined constraint
# set -> 25 calls. Budget statements must therefore say "at most", never "exactly".
MAX_CANDIDATE_EVALUATIONS = 24060
CONSTRAINT_SKIPS_INFEASIBLE_EVALUATIONS = True

# Captured from the read-only chain on 2026-08-25 by spying on the run_de call site.
# Order is the index_map expansion order and must not be reordered: the explicit initial
# population is positional.
FROZEN_PARAMETER_NAMES: tuple[str, ...] = (
    "msk_c0", "msk_c1", "msk_nsub",
    "kc", "c", "wum", "wlm", "wdm", "sm", "b", "ex", "imp",
    "ki", "kg", "cs", "ci", "cg",
)
FROZEN_BOUNDS: tuple[tuple[float, float], ...] = (
    (0.01, 0.8), (0.0, 0.8), (1.0, 5.0),
    (0.5, 2.8), (0.05, 0.25), (5.0, 100.0), (10.0, 90.0), (5.0, 150.0),
    (10.0, 50.0), (0.05, 0.6), (1.0, 4.0), (0.0, 0.5),
    (0.01, 0.7), (0.01, 0.8), (0.01, 0.99), (0.5, 0.99), (0.7, 0.999),
)
FROZEN_LOWER_BOUNDS = np.array([lo for lo, _ in FROZEN_BOUNDS], dtype=float)
FROZEN_UPPER_BOUNDS = np.array([hi for _, hi in FROZEN_BOUNDS], dtype=float)

# Frozen time contract, mirrored from the continuous qualification family.
SPINUP_START = "2017-06-01"
CALIBRATION_END = "2022-12-31 23:00:00"
EVAL_START = "2018-01-01"
INVALID_FLOW_WINDOW = ["2022-09-01", "2022-10-31"]
EXPECTED_SPINUP_HOURS = 5136
EXPECTED_CALIBRATION_HOURS = 43824
EXPECTED_SCORED_HOURS = 42360

DETERMINISTIC_DE_KWARGS: dict[str, Any] = {
    "strategy": "best1bin",
    "workers": 1,
    "updating": "deferred",
    "polish": False,
    "tol": 0.0,
    "atol": 0.0,
    "disp": False,
}


# ---------------------------------------------------------------------------
# Hashing and boundary helpers
# ---------------------------------------------------------------------------


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_array(array: np.ndarray) -> str:
    contiguous = np.ascontiguousarray(np.asarray(array, dtype=np.float64))
    return hashlib.sha256(contiguous.tobytes()).hexdigest()


def validate_output_root(path: Path) -> Path:
    resolved = Path(path).resolve()
    # guard the registered read-only root and the mapped one, so a remapped run cannot write
    # into the model source tree either
    candidates = {READ_ONLY_REPOSITORY, Path(REGISTERED_FSL_ROOT)}
    for candidate in candidates:
        try:
            read_only = candidate.resolve()
        except OSError:
            read_only = candidate
        if resolved == read_only or read_only in resolved.parents:
            raise ValueError(f"output path enters the read-only repository: {resolved}")
    return resolved


# ---------------------------------------------------------------------------
# Explicit initial population
# ---------------------------------------------------------------------------


def build_initial_population(
    seed: int, bounds: Sequence[tuple[float, float]] = FROZEN_BOUNDS
) -> np.ndarray:
    """Build exactly 60 bounded rows with a seeded 17-dimensional Latin hypercube."""
    bounds = tuple(tuple(map(float, b)) for b in bounds)
    if len(bounds) != PARAMETER_DIMENSION:
        raise ValueError(f"expected {PARAMETER_DIMENSION} bounds, got {len(bounds)}")
    lower = np.array([lo for lo, _ in bounds], dtype=float)
    upper = np.array([hi for _, hi in bounds], dtype=float)
    if np.any(upper <= lower):
        raise ValueError("every bound must satisfy hi > lo")
    unit = qmc.LatinHypercube(d=PARAMETER_DIMENSION, seed=int(seed)).random(n=POPULATION_ROWS)
    population = qmc.scale(unit, lower, upper)
    if population.shape != (POPULATION_ROWS, PARAMETER_DIMENSION):
        raise RuntimeError(f"population shape drift: {population.shape}")
    if np.any(population < lower) or np.any(population > upper):
        raise RuntimeError("population escaped the frozen bounds")
    if np.unique(population, axis=0).shape[0] != POPULATION_ROWS:
        raise RuntimeError("population contains duplicate rows")
    return population


def formal_population_hashes() -> dict[int, str]:
    return {seed: sha256_array(build_initial_population(seed)) for seed in FORMAL_SEEDS}


# ---------------------------------------------------------------------------
# Deterministic differential evolution context
# ---------------------------------------------------------------------------


@dataclass
class DeterministicTrace:
    """Everything a determinism gate must compare bitwise."""

    seed: int
    population_sha256: str
    candidate_vectors: list[list[float]] = field(default_factory=list)
    objective_values: list[float] = field(default_factory=list)
    best_x: list[float] | None = None
    best_fun: float | None = None
    generations: int | None = None
    objective_calls: int = 0
    init_argument_seen: str = ""

    def digest(self) -> str:
        payload = {
            "seed": self.seed,
            "population_sha256": self.population_sha256,
            "candidate_vectors": self.candidate_vectors,
            "objective_values": self.objective_values,
            "best_x": self.best_x,
            "best_fun": self.best_fun,
            "generations": self.generations,
            "objective_calls": self.objective_calls,
        }
        return hashlib.sha256(
            json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()


@contextlib.contextmanager
def seeded_de_context(
    seed: int,
    population: np.ndarray,
    *,
    max_iter: int = MAX_ITER,
    record_candidates: bool = True,
) -> Iterator[DeterministicTrace]:
    """Seed NumPy population creation and inject the seed into SciPy differential evolution.

    Replaces ``optimize_eval.run_de`` for the duration of the block. The replacement ignores the
    caller's ``init``/``popsize``/``tol`` and supplies the explicit population, the seed, ``tol=0``
    and ``atol=0``. The original function and the original NumPy random state are restored in
    ``finally`` whether or not the body raised.
    """
    if str(FSL_ROOT) not in sys.path:
        sys.path.insert(0, str(FSL_ROOT))
    from src.runtime.semi_distributed.core import optimize_eval as optimize_eval_module

    population = np.ascontiguousarray(np.asarray(population, dtype=float))
    if population.shape != (POPULATION_ROWS, PARAMETER_DIMENSION):
        raise ValueError(f"explicit population must be {POPULATION_ROWS}-by-{PARAMETER_DIMENSION}")

    trace = DeterministicTrace(seed=int(seed), population_sha256=sha256_array(population))
    original_run_de = optimize_eval_module.run_de
    original_state = np.random.get_state()

    def deterministic_run_de(objective: Callable[[Any], float], bounds, **kwargs):
        # The internal unseeded population paths must not have run. When warm start is off they
        # leave init as the literal string "latinhypercube"; an ndarray here means one of them fired.
        init_argument = kwargs.get("init", None)
        trace.init_argument_seen = type(init_argument).__name__
        if isinstance(init_argument, np.ndarray):
            raise RuntimeError(
                "an internal unseeded population path built the initial population; "
                "warm start and resume must be disabled before a deterministic run"
            )

        frozen = tuple(tuple(map(float, b)) for b in bounds)
        if frozen != FROZEN_BOUNDS:
            raise RuntimeError(
                "parameter bounds drifted from the frozen 17-parameter contract:\n"
                f"  actual={frozen}\n  frozen={FROZEN_BOUNDS}"
            )

        def recording_objective(vector):
            value = float(objective(vector))
            trace.objective_calls += 1
            if record_candidates:
                trace.candidate_vectors.append([float(v) for v in np.asarray(vector).ravel()])
                trace.objective_values.append(value)
            return value

        generations = {"n": 0}

        def counting_callback(*args, **kwargs_inner):
            generations["n"] += 1
            callback = kwargs.get("callback")
            if callback is not None:
                with contextlib.suppress(Exception):
                    callback(*args, **kwargs_inner)
            return False

        result = differential_evolution(
            recording_objective,
            list(bounds),
            constraints=kwargs.get("constraints", ()),
            maxiter=int(max_iter),
            init=population,
            seed=int(seed),
            callback=counting_callback,
            **DETERMINISTIC_DE_KWARGS,
        )
        trace.best_x = [float(v) for v in np.asarray(result.x).ravel()]
        trace.best_fun = float(result.fun)
        trace.generations = int(generations["n"])
        return result

    optimize_eval_module.run_de = deterministic_run_de
    np.random.seed(int(seed))
    try:
        yield trace
    finally:
        optimize_eval_module.run_de = original_run_de
        np.random.set_state(original_state)


def run_quadratic_seed_smoke(seed: int, *, dimension: int = PARAMETER_DIMENSION):
    """Cheap self-contained determinism smoke test on a quadratic, no model involved."""
    bounds = [(-5.0, 5.0)] * dimension
    lower = np.array([lo for lo, _ in bounds], dtype=float)
    upper = np.array([hi for _, hi in bounds], dtype=float)
    unit = qmc.LatinHypercube(d=dimension, seed=int(seed)).random(n=POPULATION_ROWS)
    population = qmc.scale(unit, lower, upper)

    calls: list[float] = []

    def objective(vector):
        value = float(np.sum((np.asarray(vector, dtype=float) - 0.25) ** 2))
        calls.append(value)
        return value

    result = differential_evolution(
        objective,
        bounds,
        maxiter=3,
        init=population,
        seed=int(seed),
        **DETERMINISTIC_DE_KWARGS,
    )
    return type(
        "QuadraticSmoke",
        (),
        {
            "x": np.asarray(result.x, dtype=float),
            "fun": float(result.fun),
            "trace": tuple(calls),
            "population_sha256": sha256_array(population),
        },
    )()


# ---------------------------------------------------------------------------
# Isolated runtime inputs
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class RuntimeInputSpec:
    arm_id: str
    meteo_source: Path
    discharge_source: Path = CLEAN_DISCHARGE
    window_start: str = SPINUP_START
    window_end: str = "2023-12-31 23:00:00"


@dataclass(frozen=True)
class RuntimePaths:
    data_dir: Path
    meteo_file: Path
    discharge_file: Path
    matrix_dir: Path


@dataclass(frozen=True)
class LoadedSources:
    meteo_sha256: str
    discharge_sha256: str
    meteo_rows: int
    discharge_rows: int


def default_input_spec(arm_id: str = "current_input") -> RuntimeInputSpec:
    if arm_id not in ARM_GRID_FILES:
        raise ValueError(f"unknown arm: {arm_id}")
    return RuntimeInputSpec(arm_id=arm_id, meteo_source=ARM_GRID_FILES[arm_id])


def build_isolated_runtime_inputs(spec: RuntimeInputSpec, root: Path) -> RuntimePaths:
    """Write explicit meteo/discharge snapshots and assert that no timeseries.db is present."""
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    data_dir = root / "runtime_data"
    matrix_dir = data_dir / "full"
    discharge_dir = data_dir / "namou_kuwei_discharge_hourly"
    matrix_dir.mkdir(parents=True, exist_ok=True)
    discharge_dir.mkdir(parents=True, exist_ok=True)

    for name in ("grid_to_subbasin_map.csv", "sub_area.csv", "meta.json", "cell_area.csv"):
        source = FSL_ROOT / "basins" / "namou_kuwei" / "data" / "full" / name
        if not source.is_file():
            raise FileNotFoundError(f"missing read-only matrix file: {source}")
        shutil.copyfile(source, matrix_dir / name)

    meteo_file = data_dir / f"meteo_{spec.arm_id}.csv"
    shutil.copyfile(spec.meteo_source, meteo_file)

    discharge = pd.read_csv(spec.discharge_source, parse_dates=["time"])
    window = discharge[
        (discharge["time"] >= spec.window_start) & (discharge["time"] <= spec.window_end)
    ][["time", "q_obs"]].rename(columns={"q_obs": "discharge"})
    discharge_file = discharge_dir / "obs_discharge_hourly.csv"
    window.to_csv(discharge_file, index=False)

    stray = list(data_dir.rglob("timeseries.db"))
    if stray:
        raise RuntimeError(f"isolated runtime directory must not contain timeseries.db: {stray}")

    return RuntimePaths(
        data_dir=data_dir,
        meteo_file=meteo_file,
        discharge_file=discharge_file,
        matrix_dir=matrix_dir,
    )


def preflight_model_data(paths: RuntimePaths) -> LoadedSources:
    """Hash the explicit CSV sources the run will actually consume."""
    if (paths.data_dir / "timeseries.db").exists():
        raise RuntimeError("timeseries.db reappeared inside the isolated runtime directory")
    meteo = pd.read_csv(paths.meteo_file, parse_dates=["time"])
    discharge = pd.read_csv(paths.discharge_file, parse_dates=["time"])
    return LoadedSources(
        meteo_sha256=sha256_file(paths.meteo_file),
        discharge_sha256=sha256_file(paths.discharge_file),
        meteo_rows=int(len(meteo)),
        discharge_rows=int(len(discharge)),
    )


# ---------------------------------------------------------------------------
# Runtime configuration with warm start forced off
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class RuntimeConfig:
    path: Path
    seed: int
    initial_params: str | None
    seed_from: str | None
    resume: bool
    workers: int
    max_iter: int
    pop_size: int
    objective: str
    text: str = field(repr=False, default="")


def build_runtime_config(
    base_config_path: Path = BASE_RUN_CONFIG,
    *,
    seed: int,
    paths: RuntimePaths | None = None,
    output_path: Path | None = None,
    max_iter: int = MAX_ITER,
) -> RuntimeConfig:
    """Derive a run configuration with warm start, seed_from and resume all disabled."""
    base_config_path = Path(base_config_path)
    actual = sha256_file(base_config_path)
    if actual != BASE_RUN_CONFIG_SHA256:
        raise RuntimeError(
            f"base run configuration drifted: expected={BASE_RUN_CONFIG_SHA256}; actual={actual}"
        )
    text = base_config_path.read_text(encoding="utf-8")

    # 1. warm start OFF: drop initial_params entirely
    text = re.sub(r"\n[ \t]*initial_params:[^\n]*\n", "\n", text)
    # 2. single process so the objective order is reproducible
    text = re.sub(r"\n([ \t]*)workers:[^\n]*\n", rf"\n\1workers: 1\n", text)
    # 3. explicit budget
    text = re.sub(r"\n([ \t]*)max_iter:[^\n]*\n", rf"\n\1max_iter: {int(max_iter)}\n", text)
    text = re.sub(r"\n([ \t]*)pop_size:[^\n]*\n", rf"\n\1pop_size: {POPULATION_ROWS}\n", text)
    # 4. never resume from a checkpoint
    text = re.sub(r"\n([ \t]*)resume:[^\n]*\n", rf"\n\1resume: false\n", text)
    # 5. full calibration window including its final hour, plus the frozen invalid-flow mask
    text = text.replace('end_date: "2022-12-31"', f'end_date: "{CALIBRATION_END}"')
    if "exclude_windows" not in text:
        text = text.replace(
            "  exclude_years: []",
            f"  exclude_windows: [{json.dumps(INVALID_FLOW_WINDOW)}]\n  exclude_years: []",
            1,
        )
    # 6. isolated sources
    if paths is not None:
        text = re.sub(
            r"\nmeteo_file:[^\n]*\n", f"\nmeteo_file: {paths.meteo_file.as_posix()}\n", text
        )
        text = re.sub(
            r"\ndata_dir:[^\n]*\n",
            f"\nobs_discharge_file: {paths.discharge_file.as_posix()}"
            f"\ndata_dir: {paths.data_dir.as_posix()}\n",
            text,
        )

    parsed = yaml.safe_load(text)
    calibration = parsed["model"]["data"]["calibration"]
    optimizer = parsed["optimizer"]
    if "initial_params" in calibration and calibration["initial_params"]:
        raise RuntimeError("initial_params survived; warm start must be disabled")
    if optimizer.get("seed_from"):
        raise RuntimeError("seed_from must not be set; it is a warm-start path, not a random seed")
    if optimizer.get("resume", False):
        raise RuntimeError("resume must be disabled")
    if int(optimizer["workers"]) != 1:
        raise RuntimeError("workers must be 1 for a deterministic run")
    if int(optimizer["pop_size"]) != POPULATION_ROWS:
        raise RuntimeError(f"pop_size must be {POPULATION_ROWS}")
    if str(optimizer["objective"]).strip().lower() != "nse":
        raise RuntimeError("the frozen primary objective is nse")

    if output_path is not None:
        output_path = Path(output_path)
        validate_output_root(output_path.parent)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(text, encoding="utf-8")

    return RuntimeConfig(
        path=Path(output_path) if output_path is not None else base_config_path,
        seed=int(seed),
        initial_params=calibration.get("initial_params"),
        seed_from=optimizer.get("seed_from"),
        resume=bool(optimizer.get("resume", False)),
        workers=int(optimizer["workers"]),
        max_iter=int(optimizer["max_iter"]),
        pop_size=int(optimizer["pop_size"]),
        objective=str(optimizer["objective"]).strip().lower(),
        text=text,
    )


# ---------------------------------------------------------------------------
# One arm/seed run
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CalibrationRunSpec:
    arm_id: str
    seed: int
    output_root: Path
    max_iter: int = MAX_ITER
    record_candidates: bool = True


@dataclass
class CalibrationArtifacts:
    arm_id: str
    seed: int
    output_root: Path
    best_params: dict[str, Any]
    best_score: float
    trace_digest: str
    population_sha256: str
    generations: int | None
    objective_calls: int
    elapsed_seconds: float
    sources: LoadedSources
    trace: DeterministicTrace = field(repr=False, default=None)  # type: ignore[assignment]


def run_calibration_arm(spec: CalibrationRunSpec) -> CalibrationArtifacts:
    """Run one arm/seed with read-only model code and outputs forced into laos_forecast."""
    output_root = validate_output_root(Path(spec.output_root))
    output_root.mkdir(parents=True, exist_ok=True)

    input_spec = default_input_spec(spec.arm_id)
    paths = build_isolated_runtime_inputs(input_spec, output_root)
    sources = preflight_model_data(paths)
    runtime = build_runtime_config(
        seed=spec.seed,
        paths=paths,
        output_path=output_root / f"run_config_{spec.arm_id}_seed{spec.seed}.yml",
        max_iter=spec.max_iter,
    )
    population = build_initial_population(spec.seed)

    if str(FSL_ROOT) not in sys.path:
        sys.path.insert(0, str(FSL_ROOT))
    from src.runtime.semi_distributed.entry_points import run_optimization_cli

    started = time.time()
    with seeded_de_context(
        spec.seed,
        population,
        max_iter=spec.max_iter,
        record_candidates=spec.record_candidates,
    ) as trace:
        best_params, best_score = run_optimization_cli(
            [
                "--run-config", str(runtime.path),
                "--output-root", str(output_root / "fsl_output"),
            ]
        )
    elapsed = time.time() - started

    if trace.init_argument_seen != "str":
        raise RuntimeError(
            f"expected the internal init argument to remain the string sentinel, "
            f"saw {trace.init_argument_seen}"
        )

    return CalibrationArtifacts(
        arm_id=spec.arm_id,
        seed=spec.seed,
        output_root=output_root,
        best_params=best_params,
        best_score=float(best_score),
        trace_digest=trace.digest(),
        population_sha256=trace.population_sha256,
        generations=trace.generations,
        objective_calls=trace.objective_calls,
        elapsed_seconds=elapsed,
        sources=sources,
        trace=trace,
    )


# ---------------------------------------------------------------------------
# Determinism gate
# ---------------------------------------------------------------------------


def run_determinism_gate(
    output_root: Path,
    *,
    arm_id: str = "current_input",
    seed: int = FORMAL_SEEDS[0],
    max_iter: int = 1,
) -> dict[str, Any]:
    """Run the same arm/seed twice through the complete model path and require bitwise equality."""
    output_root = validate_output_root(Path(output_root))
    results = []
    for replicate in ("a", "b"):
        spec = CalibrationRunSpec(
            arm_id=arm_id,
            seed=seed,
            output_root=output_root / f"replicate_{replicate}",
            max_iter=max_iter,
        )
        results.append(run_calibration_arm(spec))

    left, right = results
    comparisons = {
        "population_sha256": left.population_sha256 == right.population_sha256,
        "candidate_vectors": left.trace.candidate_vectors == right.trace.candidate_vectors,
        "objective_values": left.trace.objective_values == right.trace.objective_values,
        "best_x": left.trace.best_x == right.trace.best_x,
        "best_fun": left.trace.best_fun == right.trace.best_fun,
        "generations": left.generations == right.generations,
        "objective_calls": left.objective_calls == right.objective_calls,
        "trace_digest": left.trace_digest == right.trace_digest,
        "best_score": left.best_score == right.best_score,
        "meteo_sha256": left.sources.meteo_sha256 == right.sources.meteo_sha256,
        "discharge_sha256": left.sources.discharge_sha256 == right.sources.discharge_sha256,
    }
    report = {
        "arm_id": arm_id,
        "seed": seed,
        "max_iter": max_iter,
        "comparisons": comparisons,
        "all_identical": all(comparisons.values()),
        "population_sha256": left.population_sha256,
        "trace_digest": left.trace_digest,
        "objective_calls": left.objective_calls,
        "generations": left.generations,
        "candidate_count": len(left.trace.candidate_vectors),
        "best_score": left.best_score,
        "elapsed_seconds": [round(left.elapsed_seconds, 1), round(right.elapsed_seconds, 1)],
        "seconds_per_objective_call": (
            round(left.elapsed_seconds / left.objective_calls, 4) if left.objective_calls else None
        ),
        # Upper bound: assumes every one of the 24,060 candidates costs an evaluation. The read-only
        # combined constraints skip infeasible individuals, so the realised cost is lower; this
        # figure is a ceiling for planning, not a prediction.
        "projected_seconds_for_full_budget_upper_bound": (
            round(
                (left.elapsed_seconds / left.objective_calls) * MAX_CANDIDATE_EVALUATIONS, 1
            )
            if left.objective_calls
            else None
        ),
        "feasible_fraction_of_first_generation": (
            round(left.objective_calls / (2 * POPULATION_ROWS), 4)
            if max_iter == 1 and left.objective_calls
            else None
        ),
        "budget_note": (
            "MAX_CANDIDATE_EVALUATIONS is an upper bound; SciPy spends no objective evaluation "
            "on individuals that violate the read-only combined constraints."
        ),
        "meteo_sha256": left.sources.meteo_sha256,
        "discharge_sha256": left.sources.discharge_sha256,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
    }
    (output_root / "determinism_gate.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True, default=str) + "\n",
        encoding="utf-8",
    )
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--determinism-gate", action="store_true")
    parser.add_argument("--output-root", type=Path, required=False)
    parser.add_argument("--arm", default="current_input")
    parser.add_argument("--seed", type=int, default=FORMAL_SEEDS[0])
    parser.add_argument("--max-iter", type=int, default=1)
    arguments = parser.parse_args()

    if arguments.determinism_gate:
        if arguments.output_root is None:
            parser.error("--determinism-gate requires --output-root")
        report = run_determinism_gate(
            arguments.output_root,
            arm_id=arguments.arm,
            seed=arguments.seed,
            max_iter=arguments.max_iter,
        )
        print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True, default=str))
        return

    print(
        json.dumps(
            {
                "frozen_bounds": FROZEN_BOUNDS,
                "parameter_names": FROZEN_PARAMETER_NAMES,
                "formal_seeds": FORMAL_SEEDS,
                "population_hashes": formal_population_hashes(),
                "max_candidate_evaluations": MAX_CANDIDATE_EVALUATIONS,
            },
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
