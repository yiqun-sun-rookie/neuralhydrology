# Ku Wei Joint Filter Learning Preregistration

Locked: 2026-08-26, before any formal training run.

The frozen contract IS the configuration file `kuwei_joint_da_learning_20260826.yml`
(sha256 4e5edf68860b22e3ad14d749d87b05a4c9c5042bb101f0c578678bc2035e61fb), authorized by the user-approved draft
`2026-08-26-kuwei-joint-da-learning-contract-draft.md` (sha256 18d219b915f576511cc9480776f0955226a7af9f3e7729cf1244171ad61d09ed).
This document freezes the execution facts on top of those two:

## Phase 0 gates, all passed before this lock

- equivalence (filter transition, updates off, vs mirror sequence): max abs diff 0.0e+00;
- anchor (torch mirror vs read-only authority, DISABLE_NUMBA=1, full 57,720 h, three
  replicates): max abs diff 0.0e+00 / 0.0e+00 / 0.0e+00 — bitwise identical;
- determinism (joint arm, seed 20260824, 3 updates twice): loss trajectories identical;
- timing: projected 1.87 h per run, ~4 h for the family at 6 parallel processes → local
  execution; the 48 h HPC threshold is not reached.

## Anchor amendment 1 (made before any training result existed)

The draft's anchor reference (saved fsl eval2023 series) is a numba fastmath=True product.
Measured three-way comparison: mirror == no-numba authority bitwise, while the entire
mirror-vs-eval2023 gap (6.105e-3 / 2.024 / 3.418e-3 m3/s) lies between the fastmath and
no-fastmath builds of the same read-only code, amplified over 57,720 steps by the
replicate-20260825 long-memory channel (c2 ~ 0.97). The gate reference is therefore the
authority with deterministic float ordering; the fastmath gap is recorded as context in
every gate report. This also bounds engine comparability: all four arms run on the same
torch engine, so arm-vs-arm comparisons are unaffected; comparisons against fsl-pipeline
products carry an engine gap up to ~2 m3/s at flood peaks for that one replicate.

## Execution facts frozen

- 12 formal runs: 4 arms x 3 replicates; implementation `kuwei_joint_da_learning.py`
  (sha256 at launch c5814c9b178ba20962bfc0772f916640b67967e923a15e239d680bc4d437c533);
- training origins 4,380 / selection scored origins 1,330 / test origins 1,448 (sealed);
- checkpoint on the selection segment every 8 updates, tie -> earlier;
- the sealed 2023 stage runs exactly once, refuses to rerun, and requires all 12 manifests;
- verdict gates as in the configuration: joint/all_frozen median <= 0.90 and all
  replicates <= 1.00; any replicate > 1.05 fails the family; technical completion does
  not require improvement.

## Boundaries restated

Conclusions are limited to post-event observed forcing (no forecast-skill claims);
2023 is a retrospective time-extrapolation check, not a project-level blind holdout;
no production change is authorized by any outcome.
