"""Ku Wei joint filter learning: backprop through a differentiable UKF, four arms.

Family ``kuwei_joint_da_learning_20260826``. Frozen contract in the sibling config; approved
draft in docs/superpowers/plans/2026-08-26-kuwei-joint-da-learning-contract-draft.md.

Stages (CLI):
  --gates        Phase 0: anchor / equivalence / determinism / timing gates. No training.
  --run ARM SEED Phase 1: one formal run (training + selection checkpointing). Never reads 2023.
  --seal-test    Phase 2: one-shot sealed 2023 evaluation of all 12 checkpoints + verdict.

2023 is never touched by --gates or --run. The test stage refuses to start unless all twelve
run manifests exist.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd
import torch
import yaml

HERE = Path(__file__).resolve().parent
CAMPAIGN_ROOT = HERE.parent
PROJECT_ROOT = CAMPAIGN_ROOT.parents[3]
sys.path.insert(0, str(HERE))

import torch_xaj_mirror as mirror  # noqa: E402

FAMILY_ID = "kuwei_joint_da_learning_20260826"
CONFIG_PATH = CAMPAIGN_ROOT / "configs" / f"{FAMILY_ID}.yml"
OUTPUT_ROOT = CAMPAIGN_ROOT / "results" / FAMILY_ID

# Registered (Windows) roots; on another host set KUWEI_LAOS_ROOT / KUWEI_FSL_ROOT and every
# path read from the hash-locked config is prefix-remapped. Identity on the authoring machine.
_REG_LAOS = "G:/github/pycharm/projects/laos_forecast"
_REG_FSL = "G:/github/pycharm/projects/forecast_system_lite"
_LAOS_ACTUAL = Path(os.environ.get("KUWEI_LAOS_ROOT") or PROJECT_ROOT)
_FSL_ACTUAL = Path(os.environ.get("KUWEI_FSL_ROOT") or _REG_FSL)


def map_path(path: Any) -> Path:
    text = str(path).replace("\\", "/")
    for registered, actual in ((_REG_LAOS, _LAOS_ACTUAL), (_REG_FSL, _FSL_ACTUAL)):
        if text.lower().startswith(registered.lower()):
            remainder = text[len(registered):].lstrip("/")
            return Path(actual) / remainder if remainder else Path(actual)
    return Path(text)

FLOAT = torch.float32
STATE_DIM = 13          # 11 XAJ + MSK_OUT1 + MSK_PREV_IN (all replicates have n_sub = 1)
OBS_INDEX = 11          # MSK_OUT1
LEADS = (6, 12, 24)
WINDOW_HOURS = 720
OBS_FLOOR = 2.0

HYDRO_NAMES = ("msk_c0", "msk_c1", "kc", "c", "wum", "wlm", "wdm", "sm",
               "b", "ex", "imp", "ki", "kg", "cs", "ci", "cg")
HYDRO_BOUNDS = {
    "msk_c0": (0.01, 0.8), "msk_c1": (0.0, 0.8), "kc": (0.5, 2.8), "c": (0.05, 0.25),
    "wum": (5.0, 100.0), "wlm": (10.0, 90.0), "wdm": (5.0, 150.0), "sm": (10.0, 50.0),
    "b": (0.05, 0.6), "ex": (1.0, 4.0), "imp": (0.0, 0.5), "ki": (0.01, 0.7),
    "kg": (0.01, 0.8), "cs": (0.01, 0.99), "ci": (0.5, 0.99), "cg": (0.7, 0.999),
}
Q_INIT = np.array([0.001, 0.001, 0.001, 0.05, 0.1, 0.05, 0.01, 0.1, 0.5, 0.2, 0.05,
                   0.001, 0.001], dtype=np.float64)
S_INIT = 0.05
NOISE_BOUND_FACTOR = 400.0
MERWE_ALPHA, MERWE_BETA, MERWE_KAPPA = 0.9, 2.0, 0.0
P0_DIAG = np.array([1, 1, 1, 10, 10, 10, 5, 10, 20, 10, 5, 1, 1], dtype=np.float64)

WARMUP_START = pd.Timestamp("2017-06-01 00:00")
FILTER_START = pd.Timestamp("2018-01-01 00:00")
TRAIN_END = pd.Timestamp("2020-12-31 23:00")
SELECT_END = pd.Timestamp("2022-12-31 23:00")
FULL_END = pd.Timestamp("2023-12-31 23:00")

XAJ_INITIAL = {"W": 0.0, "WU": 10.1, "WL": 12.2, "WD": 50.8, "S": 5.1,
               "QS": 0.5, "QI": 5.0, "QG": 10.0}

ARMS = {"all_frozen": (False, False), "noise_only": (False, True),
        "hydro_only": (True, False), "joint": (True, True)}
# Extension arms (2026-08-28, user-requested staged learning; total budget equals the
# original arms' 192 updates, split 96+96; a fresh Adam per phase, checkpoint tracked
# globally across both phases; phase 2 continues from the END of phase 1, not its best).
STAGED_ARMS = {
    "hydro_then_noise": ((96, True, False), (96, False, True)),
    "noise_then_hydro": ((96, False, True), (96, True, False)),
}
SEEDS = (20260824, 20260825, 20260826)
N_UPDATES = 192
CHECKPOINT_EVERY = 8


def phase_plan(arm_id: str, n_updates: int) -> tuple[tuple[int, bool, bool], ...]:
    if arm_id in ARMS:
        learn_hydro, learn_noise = ARMS[arm_id]
        return ((n_updates if (learn_hydro or learn_noise) else 0, learn_hydro, learn_noise),)
    if arm_id in STAGED_ARMS:
        return STAGED_ARMS[arm_id]
    raise KeyError(f"unknown arm: {arm_id}")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _jsonable(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    if isinstance(value, Path):
        return str(value)
    return value


def write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(_jsonable(payload), ensure_ascii=False, indent=2,
                               sort_keys=True, default=str) + "\n", encoding="utf-8")


def load_config() -> dict:
    config = yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8"))
    if config["joint_family"]["id"] != FAMILY_ID:
        raise RuntimeError("config family identity drifted")
    return config


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------


@dataclass
class Forcing:
    index: pd.DatetimeIndex
    rain: torch.Tensor
    pet: torch.Tensor
    temp: torch.Tensor
    obs: torch.Tensor          # NaN where invalid
    obs_valid: torch.Tensor    # bool


_FORCING: Forcing | None = None


def load_forcing(config: Mapping[str, Any]) -> Forcing:
    global _FORCING
    if _FORCING is not None:
        return _FORCING
    meteo_path = map_path(config["data"]["meteo"]["path"])
    if sha256_file(meteo_path) != config["data"]["meteo"]["sha256"]:
        raise RuntimeError("meteo input hash drift")
    discharge_path = map_path(config["data"]["discharge"]["path"])
    if sha256_file(discharge_path) != config["data"]["discharge"]["sha256"]:
        raise RuntimeError("discharge input hash drift")

    index = pd.date_range(WARMUP_START, FULL_END, freq="h")
    meteo = pd.read_csv(meteo_path, parse_dates=["time"]).set_index("time").loc[index]
    q = pd.read_csv(discharge_path, parse_dates=["time"]).set_index("time")["q_obs"].reindex(index)
    if len(index) != 57720:
        raise RuntimeError("window length drift")
    obs = q.to_numpy(dtype=np.float32)
    _FORCING = Forcing(
        index=index,
        rain=torch.tensor(meteo["rain_g0"].to_numpy(np.float32)),
        pet=torch.tensor(meteo["pet_g0"].to_numpy(np.float32)),
        temp=torch.tensor(meteo["temp_g0"].to_numpy(np.float32)),
        obs=torch.tensor(obs),
        obs_valid=torch.tensor(np.isfinite(obs)),
    )
    return _FORCING


def hour_index(ts: pd.Timestamp) -> int:
    return int((ts - WARMUP_START) / pd.Timedelta(hours=1))


def origin_grid(first: str, last: str, stride: int) -> np.ndarray:
    rng = pd.date_range(first, last, freq=f"{stride}h")
    return np.array([hour_index(t) for t in rng], dtype=np.int64)


TRAIN_ORIGINS = origin_grid("2018-01-01 00:00", "2020-12-30 18:00", 6)
SELECT_ORIGINS = origin_grid("2021-01-03 00:00", "2022-12-30 12:00", 12)
TEST_ORIGINS = origin_grid("2023-01-03 00:00", "2023-12-30 18:00", 6)


def scored_mask(forcing: Forcing, origins: np.ndarray) -> np.ndarray:
    valid = forcing.obs_valid.numpy()
    ok = np.ones(len(origins), dtype=bool)
    for lead in LEADS:
        ok &= valid[origins + lead]
    return ok


# ---------------------------------------------------------------------------
# Parameters
# ---------------------------------------------------------------------------


def load_start_parameters(path: Path) -> tuple[dict[str, float], dict[str, torch.Tensor]]:
    payload = yaml.safe_load(path.read_text(encoding="utf-8"))["namou_kuwei"]
    xp = payload["xaj_params"]
    layer = payload["msk_layers"][0]
    if int(np.asarray(layer["n_sub"]).ravel()[0]) != 1:
        raise RuntimeError("this implementation is frozen to n_sub = 1 replicates")
    start = {name: float(xp[name]) for name in HYDRO_NAMES if name not in ("msk_c0", "msk_c1")}
    start["msk_c0"] = float(np.asarray(layer["c0"]).ravel()[0])
    start["msk_c1"] = float(np.asarray(layer["c1"]).ravel()[0])
    frozen = {
        "uf": torch.tensor([float(np.asarray(xp["uf"]).ravel()[0])], dtype=FLOAT),
        "wmm": torch.tensor([float(xp["wmm"])], dtype=FLOAT),
        "ms": torch.tensor([float(xp["ms"])], dtype=FLOAT),
    }
    return start, frozen


class LearnableConfiguration(torch.nn.Module):
    """Sigmoid-bounded hydrology + log-space noise, with per-arm learnability."""

    def __init__(self, start: Mapping[str, float], frozen: Mapping[str, torch.Tensor],
                 learn_hydro: bool, learn_noise: bool):
        super().__init__()
        raws = []
        for name in HYDRO_NAMES:
            lo, hi = HYDRO_BOUNDS[name]
            v = min(max(float(start[name]), lo + 1e-9 * (hi - lo)), hi - 1e-9 * (hi - lo))
            frac = (v - lo) / (hi - lo)
            frac = min(max(frac, 1e-7), 1 - 1e-7)
            raws.append(math.log(frac / (1 - frac)))
        self.hydro_raw = torch.nn.Parameter(
            torch.tensor(raws, dtype=torch.float64), requires_grad=learn_hydro)
        self.log_q = torch.nn.Parameter(
            torch.tensor(np.log(Q_INIT), dtype=torch.float64), requires_grad=learn_noise)
        self.log_s = torch.nn.Parameter(
            torch.tensor([math.log(S_INIT)], dtype=torch.float64), requires_grad=learn_noise)
        self.register_buffer("uf", frozen["uf"])
        self.register_buffer("wmm", frozen["wmm"])
        self.register_buffer("ms", frozen["ms"])
        self.learn_hydro, self.learn_noise = learn_hydro, learn_noise
        self._log_q_bounds = (torch.tensor(np.log(Q_INIT / NOISE_BOUND_FACTOR)),
                              torch.tensor(np.log(Q_INIT * NOISE_BOUND_FACTOR)))
        self._log_s_bounds = (math.log(S_INIT / NOISE_BOUND_FACTOR),
                              math.log(S_INIT * NOISE_BOUND_FACTOR))

    def hydro_values(self) -> dict[str, torch.Tensor]:
        values = {}
        for position, name in enumerate(HYDRO_NAMES):
            lo, hi = HYDRO_BOUNDS[name]
            values[name] = (lo + (hi - lo) * torch.sigmoid(self.hydro_raw[position])).to(FLOAT)
        c0, c1 = values["msk_c0"], values["msk_c1"]
        total = c0 + c1
        factor = torch.where(total > 0.8, 0.8 / total, torch.ones_like(total))
        values["msk_c0"], values["msk_c1"] = c0 * factor, c1 * factor
        return values

    def xaj(self) -> tuple[mirror.XAJParameters, torch.Tensor, torch.Tensor, torch.Tensor]:
        v = self.hydro_values()
        one = lambda t: t.reshape(1)
        xaj = mirror.XAJParameters(
            kc=one(v["kc"]), ki=one(v["ki"]), kg=one(v["kg"]), cs=one(v["cs"]),
            ci=one(v["ci"]), cg=one(v["cg"]), wum=one(v["wum"]), wlm=one(v["wlm"]),
            wdm=one(v["wdm"]), sm=one(v["sm"]), imp=one(v["imp"]), c=one(v["c"]),
            b=one(v["b"]), ex=one(v["ex"]), uf=self.uf, wmm=self.wmm, ms=self.ms)
        c0 = v["msk_c0"].reshape(1)
        c1 = v["msk_c1"].reshape(1)
        c2 = (1.0 - c0 - c1)
        return xaj, c0, c1, c2

    def q_diag(self) -> torch.Tensor:
        return torch.exp(self.log_q).to(FLOAT)

    def obs_scale(self) -> torch.Tensor:
        return torch.exp(self.log_s).to(FLOAT)[0]

    @torch.no_grad()
    def clamp_noise(self) -> None:
        lo, hi = self._log_q_bounds
        self.log_q.clamp_(lo.to(self.log_q.dtype), hi.to(self.log_q.dtype))
        self.log_s.clamp_(self._log_s_bounds[0], self._log_s_bounds[1])

    def parameter_vector(self) -> np.ndarray:
        return np.concatenate([
            self.hydro_raw.detach().numpy().ravel(),
            self.log_q.detach().numpy().ravel(),
            self.log_s.detach().numpy().ravel()])


# ---------------------------------------------------------------------------
# Transition, projection, filter
# ---------------------------------------------------------------------------


def transition(states: torch.Tensor, rain_t: torch.Tensor, pet_t: torch.Tensor,
               temp_t: torch.Tensor, xaj: mirror.XAJParameters,
               c0: torch.Tensor, c1: torch.Tensor, c2: torch.Tensor) -> torch.Tensor:
    """One hour for a batch of full filter states [B, 13] (n_sub = 1 unrolled)."""
    batch = states.shape[0]
    zero = torch.zeros(batch, dtype=FLOAT)
    step = mirror.torch_xaj_step_with_liquid(
        states[:, :11],
        rain_t.expand(batch), pet_t.expand(batch), xaj,
        snow_depth_snapshot=zero, ice_depth_snapshot=zero,
        last_temp_snapshot=temp_t.expand(batch))
    local = torch.sum(step.q_components, dim=1)
    out1 = c0 * local + c1 * states[:, 12] + c2 * states[:, 11]
    return torch.cat([step.state, out1.unsqueeze(1), local.unsqueeze(1)], dim=1)


def project(states: torch.Tensor, xaj: mirror.XAJParameters) -> torch.Tensor:
    wum, wlm, wdm, sm = (t.reshape(()) for t in (xaj.wum, xaj.wlm, xaj.wdm, xaj.sm))
    cols = list(states.unbind(dim=1))
    zero = torch.zeros_like(cols[0])
    cols[0], cols[1] = zero, zero
    cols[4] = cols[4].clamp(min=0.0).minimum(wum.expand_as(cols[4]))
    cols[5] = cols[5].clamp(min=0.0).minimum(wlm.expand_as(cols[5]))
    cols[6] = cols[6].clamp(min=0.0).minimum(wdm.expand_as(cols[6]))
    cols[3] = cols[4] + cols[5] + cols[6]
    cols[7] = cols[7].clamp(min=0.0).minimum(sm.expand_as(cols[7]))
    for j in (8, 9, 10, 11, 12):
        cols[j] = cols[j].clamp(min=0.0)
    return torch.stack(cols, dim=1)


class UnscentedFilter:
    def __init__(self, dim: int = STATE_DIM):
        self.n = dim
        lam = MERWE_ALPHA ** 2 * (dim + MERWE_KAPPA) - dim
        self.lam = lam
        wm = torch.full((2 * dim + 1,), 1.0 / (2 * (dim + lam)), dtype=FLOAT)
        wc = wm.clone()
        wm[0] = lam / (dim + lam)
        wc[0] = lam / (dim + lam) + (1 - MERWE_ALPHA ** 2 + MERWE_BETA)
        self.wm, self.wc = wm, wc

    def sigma_points(self, x: torch.Tensor, P: torch.Tensor) -> torch.Tensor:
        """Matrix square root of the scaled covariance.

        Amendment 2 (2026-08-27): the original ladder used absolute jitter 1e-8..1e-3, which is
        negligible against a covariance whose flow-state diagonal reaches O(1e3); replicate
        20260825 joint therefore raised "not positive definite" at update 54 and died. The first
        attempt is still an unjittered float32 Cholesky, so every previously successful step keeps
        its exact numerical path; only the failure branch changed, from raising to a
        scale-relative ladder and finally an eigenvalue-floor reconstruction that cannot fail.
        """
        scaled = (self.n + self.lam) * P
        eye = torch.eye(self.n, dtype=FLOAT)
        root = None
        try:                                    # unchanged fast path
            root = torch.linalg.cholesky(scaled)
            if not torch.isfinite(root).all():
                root = None
            else:
                self.last_jitter = 0.0
        except Exception:
            root = None
        if root is None:
            scale = float(torch.diagonal(scaled).abs().max().clamp(min=1.0))
            for exponent in range(-10, 0):
                jitter = scale * (10.0 ** exponent)
                try:
                    candidate = torch.linalg.cholesky(scaled + jitter * eye)
                except Exception:
                    continue
                if torch.isfinite(candidate).all():
                    root, self.last_jitter = candidate, jitter
                    break
        if root is None:                        # eigenvalue floor, cannot fail
            symmetric = 0.5 * (scaled + scaled.T)
            values, vectors = torch.linalg.eigh(symmetric)
            floor = float(torch.diagonal(symmetric).abs().max().clamp(min=1.0)) * 1e-9
            root = vectors @ torch.diag(torch.clamp(values, min=floor).sqrt())
            self.last_jitter = float("inf")
            self.eigen_fallbacks = getattr(self, "eigen_fallbacks", 0) + 1
        points = [x]
        for k in range(self.n):
            points.append(x + root[:, k])
        for k in range(self.n):
            points.append(x - root[:, k])
        return torch.stack(points)

    @staticmethod
    def pd_fix(P: torch.Tensor) -> torch.Tensor:
        P = 0.5 * (P + P.T)
        eigenvalues = torch.linalg.eigvalsh(P)
        floor = eigenvalues.min()
        if float(floor) < 1e-10:
            P = P + torch.eye(P.shape[0], dtype=FLOAT) * (1e-10 - floor + 1e-8)
        return P


def run_filter(configuration: LearnableConfiguration, forcing: Forcing,
               start_hour: int, end_hour: int,
               x0: torch.Tensor, P0: torch.Tensor,
               collect_at: np.ndarray | None = None,
               assimilate: bool = True) -> tuple[torch.Tensor, torch.Tensor, dict[int, torch.Tensor]]:
    """Filter hours (start_hour, end_hour]; returns final x, P and posterior means at collect_at."""
    ukf = UnscentedFilter()
    xaj, c0, c1, c2 = configuration.xaj()
    Q = torch.diag(configuration.q_diag())
    s = configuration.obs_scale()
    collect = {} if collect_at is None else {int(h): None for h in collect_at
                                             if start_hour < h <= end_hour}
    x, P = x0, P0
    for hour in range(start_hour + 1, end_hour + 1):
        sigmas = project(ukf.sigma_points(x, P), xaj)
        propagated = transition(sigmas, forcing.rain[hour], forcing.pet[hour],
                                forcing.temp[hour], xaj, c0, c1, c2)
        x_prior = torch.einsum("s,sd->d", ukf.wm, propagated)
        deviation = propagated - x_prior
        P_prior = torch.einsum("s,sd,se->de", ukf.wc, deviation, deviation) + Q
        if assimilate and bool(forcing.obs_valid[hour]):
            z = forcing.obs[hour]
            z_sigma = propagated[:, OBS_INDEX]
            z_hat = torch.einsum("s,s->", ukf.wm, z_sigma)
            dz = z_sigma - z_hat
            R = torch.maximum(torch.tensor(OBS_FLOOR, dtype=FLOAT), (s * z) ** 2)
            Pzz = torch.einsum("s,s,s->", ukf.wc, dz, dz) + R
            Pxz = torch.einsum("s,sd,s->d", ukf.wc, deviation, dz)
            K = Pxz / Pzz
            x = x_prior + K * (z - z_hat)
            P = P_prior - torch.outer(K, K) * Pzz
            P = ukf.pd_fix(P)
            x = project(x.unsqueeze(0), xaj)[0]
        else:
            x, P = x_prior, ukf.pd_fix(P_prior)
        if hour in collect:
            collect[hour] = x
    return x, P, collect


def warmup_rollout(configuration: LearnableConfiguration, forcing: Forcing) -> torch.Tensor:
    """Open-loop, single trajectory, authority initial-state convention. Returns [13]."""
    xaj, c0, c1, c2 = configuration.xaj()
    order = ("snow_depth", "ice_depth", "last_temp", "W", "WU", "WL", "WD", "S", "QS", "QI", "QG")
    base = {name: 0.0 for name in order}
    base.update(XAJ_INITIAL)
    state11 = torch.tensor([[base[name] for name in order]], dtype=FLOAT)
    q0 = float(state11[0, 8:11].sum())
    x = torch.cat([state11[0], torch.tensor([q0, q0], dtype=FLOAT)])
    end = hour_index(FILTER_START)  # exclusive of FILTER_START itself
    xb = x.unsqueeze(0)
    for hour in range(0, end):
        xb = transition(xb, forcing.rain[hour], forcing.pet[hour], forcing.temp[hour],
                        xaj, c0, c1, c2)
    return xb[0]


def batched_forecast(configuration: LearnableConfiguration, forcing: Forcing,
                     states: torch.Tensor, origins: np.ndarray) -> torch.Tensor:
    """From posterior states [K,13] at origins, roll 24 h; return predictions [K, len(LEADS)]."""
    xaj, c0, c1, c2 = configuration.xaj()
    lead_set = {lead: None for lead in LEADS}
    x = states
    origin_tensor = torch.tensor(origins, dtype=torch.long)
    out = torch.zeros((states.shape[0], len(LEADS)), dtype=FLOAT)
    for step_ahead in range(1, max(LEADS) + 1):
        hours = origin_tensor + step_ahead
        rain = forcing.rain[hours]
        pet = forcing.pet[hours]
        temp = forcing.temp[hours]
        batch = x.shape[0]
        zero = torch.zeros(batch, dtype=FLOAT)
        step = mirror.torch_xaj_step_with_liquid(
            x[:, :11], rain, pet, xaj,
            snow_depth_snapshot=zero, ice_depth_snapshot=zero, last_temp_snapshot=temp)
        local = torch.sum(step.q_components, dim=1)
        out1 = c0 * local + c1 * x[:, 12] + c2 * x[:, 11]
        x = torch.cat([step.state, out1.unsqueeze(1), local.unsqueeze(1)], dim=1)
        if step_ahead in lead_set:
            out[:, LEADS.index(step_ahead)] = x[:, OBS_INDEX]
    return out


def forecast_loss(forcing: Forcing, predictions: torch.Tensor, origins: np.ndarray) -> torch.Tensor:
    targets = torch.stack([forcing.obs[torch.tensor(origins + lead)] for lead in LEADS], dim=1)
    return torch.mean((predictions - targets) ** 2)


# ---------------------------------------------------------------------------
# Evaluation passes
# ---------------------------------------------------------------------------


def evaluate_origins(configuration: LearnableConfiguration, forcing: Forcing,
                     origins: np.ndarray, end_hour: int) -> dict[str, Any]:
    with torch.no_grad():
        x0 = warmup_rollout(configuration, forcing)
        P0 = torch.diag(torch.tensor(P0_DIAG, dtype=FLOAT))
        mask = scored_mask(forcing, origins)
        scored = origins[mask]
        _, _, collected = run_filter(configuration, forcing, hour_index(FILTER_START) - 1,
                                     end_hour, x0, P0, collect_at=scored)
        states = torch.stack([collected[int(h)] for h in scored])
        predictions = batched_forecast(configuration, forcing, states, scored)
        targets = torch.stack([forcing.obs[torch.tensor(scored + lead)] for lead in LEADS], dim=1)
        mse = torch.mean((predictions - targets) ** 2)
        per_lead = {}
        for j, lead in enumerate(LEADS):
            err = predictions[:, j] - targets[:, j]
            obs = targets[:, j]
            per_lead[str(lead)] = {
                "mse": float(torch.mean(err ** 2)),
                "nse": float(1 - torch.sum(err ** 2) / torch.sum((obs - obs.mean()) ** 2)),
            }
        return {"combined_mse": float(mse), "per_lead": per_lead,
                "n_scored_origins": int(mask.sum()),
                "predictions": predictions.numpy(), "scored_origins": scored}


# ---------------------------------------------------------------------------
# Training
# ---------------------------------------------------------------------------


def set_determinism(seed: int) -> None:
    torch.manual_seed(seed)
    torch.use_deterministic_algorithms(True)
    torch.set_num_threads(1)


def run_training(arm_id: str, seed: int, config: Mapping[str, Any],
                 n_updates: int = N_UPDATES, out_dir: Path | None = None,
                 quiet: bool = False, learning_seed: int = 0) -> dict[str, Any]:
    plan = phase_plan(arm_id, n_updates)
    learn_hydro = any(p[1] for p in plan)
    learn_noise = any(p[2] for p in plan)
    forcing = load_forcing(config)
    replicate = next(r for r in config["replicates"] if int(r["seed"]) == seed)
    start_path = map_path(replicate["start_params"]["path"])
    if sha256_file(start_path) != replicate["start_params"]["sha256"]:
        raise RuntimeError("start parameter hash drift")
    start, frozen = load_start_parameters(start_path)

    salt = int(learning_seed) * 1000003
    set_determinism(seed * 1000 + sum(map(ord, arm_id)) + salt)
    configuration = LearnableConfiguration(start, frozen, learn_hydro, learn_noise)
    rng = np.random.default_rng(seed * 7919 + sum(map(ord, arm_id)) + salt)

    select_end = hour_index(SELECT_END)
    history: list[dict[str, Any]] = []
    best = {"selection_mse": float("inf"), "update": -1, "state": None}

    def selection_eval(update_index: int) -> float:
        result = evaluate_origins(configuration, forcing, SELECT_ORIGINS, select_end)
        value = result["combined_mse"]
        if value < best["selection_mse"] - 0.0:
            best.update(selection_mse=value, update=update_index,
                        state={k: v.detach().clone() for k, v in configuration.state_dict().items()})
        history.append({"update": update_index, "selection_mse": value})
        if not quiet:
            print(f"[{arm_id}/{seed}] update={update_index} selection_mse={value:.4f} "
                  f"best={best['selection_mse']:.4f}@{best['update']}", flush=True)
        return value

    started = time.time()
    total_updates = sum(p[0] for p in plan)
    if total_updates == 0:
        selection_eval(0)
    else:
        selection_eval(0)
        train_end = hour_index(TRAIN_END)
        filter_start = hour_index(FILTER_START)
        max_start = train_end - WINDOW_HOURS + 1
        update = 0
        for phase_updates, phase_hydro, phase_noise in plan:
            configuration.hydro_raw.requires_grad_(phase_hydro)
            configuration.log_q.requires_grad_(phase_noise)
            configuration.log_s.requires_grad_(phase_noise)
            groups = []
            if phase_hydro:
                groups.append({"params": [configuration.hydro_raw], "lr": 0.005})
            if phase_noise:
                groups.append({"params": [configuration.log_q, configuration.log_s],
                               "lr": 0.05})
            optimizer = torch.optim.Adam(groups)
            for _ in range(phase_updates):
                update += 1
                win_start = int(rng.integers(filter_start, max_start + 1))
                win_end = win_start + WINDOW_HOURS - 1
                with torch.no_grad():
                    x0 = warmup_rollout(configuration, forcing)
                    P0 = torch.diag(torch.tensor(P0_DIAG, dtype=FLOAT))
                    x, P, _ = run_filter(configuration, forcing, filter_start - 1,
                                         win_start, x0, P0)
                x, P = x.detach(), P.detach()
                in_window = TRAIN_ORIGINS[(TRAIN_ORIGINS > win_start)
                                          & (TRAIN_ORIGINS + max(LEADS) <= win_end)]
                in_window = in_window[scored_mask(forcing, in_window)]
                if len(in_window) == 0:
                    continue
                _, _, collected = run_filter(configuration, forcing, win_start, win_end,
                                             x, P, collect_at=in_window)
                states = torch.stack([collected[int(h)] for h in in_window])
                predictions = batched_forecast(configuration, forcing, states, in_window)
                loss = forecast_loss(forcing, predictions, in_window)
                optimizer.zero_grad()
                loss.backward()
                for group in groups:
                    torch.nn.utils.clip_grad_norm_(group["params"], 1.0)
                optimizer.step()
                configuration.clamp_noise()
                history.append({"update": update, "train_window_start": win_start,
                                "train_loss": float(loss),
                                "n_window_origins": int(len(in_window))})
                if not quiet:
                    print(f"[{arm_id}/{seed}] update={update} window@{win_start} "
                          f"loss={float(loss):.4f} origins={len(in_window)}", flush=True)
                if update % CHECKPOINT_EVERY == 0:
                    selection_eval(update)
        if best["update"] < 0 or (total_updates % CHECKPOINT_EVERY) != 0:
            selection_eval(total_updates)

    elapsed = time.time() - started
    record = {
        "family": FAMILY_ID, "arm_id": arm_id, "seed": seed,
        "learn_hydro": learn_hydro, "learn_noise": learn_noise,
        "phase_plan": [list(p) for p in plan],
        "learning_seed": learning_seed,
        "n_updates": n_updates, "checkpoint_every": CHECKPOINT_EVERY,
        "best_update": best["update"], "best_selection_mse": best["selection_mse"],
        "elapsed_seconds": round(elapsed, 1), "history": history,
        "start_params_sha256": replicate["start_params"]["sha256"],
        "torch": torch.__version__, "numpy": np.__version__,
        "platform": platform.platform(),
        "created_utc": datetime.now(timezone.utc).isoformat(),
    }
    if out_dir is not None:
        out_dir.mkdir(parents=True, exist_ok=True)
        torch.save(best["state"] if best["state"] is not None
                   else configuration.state_dict(), out_dir / "checkpoint.pt")
        write_json(out_dir / "run_manifest.json", record)
    return record


# ---------------------------------------------------------------------------
# Phase 0 gates
# ---------------------------------------------------------------------------


def gate_equivalence(config: Mapping[str, Any]) -> dict[str, Any]:
    """Filter transition with updates off must equal the mirror sequence bitwise."""
    forcing = load_forcing(config)
    replicate = config["replicates"][0]
    start, frozen = load_start_parameters(map_path(replicate["start_params"]["path"]))
    configuration = LearnableConfiguration(start, frozen, False, False)
    hours = 2000
    xaj, c0, c1, c2 = configuration.xaj()
    order = ("snow_depth", "ice_depth", "last_temp", "W", "WU", "WL", "WD", "S", "QS", "QI", "QG")
    base = {name: 0.0 for name in order}
    base.update(XAJ_INITIAL)
    state11 = torch.tensor([[base[name] for name in order]], dtype=FLOAT)
    q0 = torch.sum(state11[:, 8:11], dim=1)[0]
    with torch.no_grad():
        reference = mirror.run_lumped_sequence(
            rain_mm=forcing.rain[:hours], pet_mm=forcing.pet[:hours],
            temp_c=forcing.temp[:hours], snow_mm=torch.zeros(hours, dtype=FLOAT),
            xaj=xaj, muskingum=mirror.MuskingumParameters(
                c0=c0, c1=c1, c2=c2, n_sub=torch.tensor([1], dtype=torch.int64)),
            initial_state=state11)
        x = torch.cat([state11[0], torch.tensor([q0, q0], dtype=FLOAT)]).unsqueeze(0)
        mine = []
        for hour in range(hours):
            x = transition(x, forcing.rain[hour], forcing.pet[hour], forcing.temp[hour],
                           xaj, c0, c1, c2)
            mine.append(float(x[0, OBS_INDEX]))
    diff = float(np.max(np.abs(np.array(mine) - reference.q_outlet.numpy())))
    return {"gate": "equivalence", "hours": hours, "max_abs_diff": diff, "passed": diff == 0.0}


def gate_anchor(config: Mapping[str, Any]) -> dict[str, Any]:
    """Torch mirror vs the read-only authority (DISABLE_NUMBA=1), per replicate.

    Amendment 1 (2026-08-26, before any training run existed): the original reference, the
    saved fsl eval2023 series, is a fastmath=True numba product; the measured three-way
    comparison showed the mirror is bitwise identical to the no-numba authority while the
    entire eval2023 gap (up to 2.024 m3/s for the c2~0.97 long-memory replicate) lies between
    the two builds of the same read-only code. The gate now tests physics fidelity against
    the deterministic-float-order authority; the eval2023 gap is reported as context.
    """
    forcing = load_forcing(config)
    zeros = torch.zeros(len(forcing.index), dtype=FLOAT)
    core = (map_path(config["repository_contract"]["read_only"][0])
            / "src" / "kernels" / "semi_distributed" / "core" / "hydromod_numba.py")
    authority = mirror._load_read_only_authority(core)
    rain = forcing.rain.numpy().astype(np.float32)
    pet = forcing.pet.numpy().astype(np.float32)
    temp = forcing.temp.numpy().astype(np.float32)
    results = []
    for replicate in config["replicates"]:
        start, frozen = load_start_parameters(map_path(replicate["start_params"]["path"]))
        configuration = LearnableConfiguration(start, frozen, False, False)
        xaj, c0, c1, c2 = configuration.xaj()
        musk = mirror.MuskingumParameters(
            c0=c0, c1=c1, c2=c2, n_sub=torch.tensor([1], dtype=torch.int64))
        order = ("snow_depth", "ice_depth", "last_temp", "W", "WU", "WL", "WD", "S",
                 "QS", "QI", "QG")
        base = {name: 0.0 for name in order}
        base.update(XAJ_INITIAL)
        state11 = torch.tensor([[base[name] for name in order]], dtype=FLOAT)
        with torch.no_grad():
            sequence = mirror.run_lumped_sequence(
                rain_mm=forcing.rain, pet_mm=forcing.pet, temp_c=forcing.temp, snow_mm=zeros,
                xaj=xaj, muskingum=musk, initial_state=state11)
        reference = mirror._run_read_only_sequence(authority, rain, pet, temp,
                                                   xaj, musk, state11)
        diff = float(np.max(np.abs(sequence.q_outlet.numpy() - reference)))
        anchor_path = map_path(replicate["anchor_series"]["path"])
        if sha256_file(anchor_path) != replicate["anchor_series"]["sha256"]:
            raise RuntimeError("anchor series hash drift")
        fastmath_gap = float(np.max(np.abs(sequence.q_outlet.numpy() - np.load(anchor_path))))
        results.append({"seed": replicate["seed"], "max_abs_diff_vs_authority": diff,
                        "context_fastmath_gap_vs_eval2023": fastmath_gap,
                        "passed": diff <= 1e-6})
    return {"gate": "anchor", "replicates": results,
            "passed": all(r["passed"] for r in results)}


def gate_determinism(config: Mapping[str, Any]) -> dict[str, Any]:
    outputs = []
    for _ in range(2):
        record = run_training("joint", SEEDS[0], config, n_updates=3, quiet=True)
        losses = [h.get("train_loss") for h in record["history"] if "train_loss" in h]
        outputs.append({"losses": losses, "best": record["best_selection_mse"]})
    identical = outputs[0] == outputs[1]
    return {"gate": "determinism", "runs": outputs, "passed": identical}


def gate_timing(config: Mapping[str, Any]) -> dict[str, Any]:
    forcing = load_forcing(config)
    replicate = config["replicates"][0]
    start, frozen = load_start_parameters(map_path(replicate["start_params"]["path"]))
    configuration = LearnableConfiguration(start, frozen, True, True)
    t0 = time.time()
    with torch.no_grad():
        x0 = warmup_rollout(configuration, forcing)
    warmup_seconds = time.time() - t0
    P0 = torch.diag(torch.tensor(P0_DIAG, dtype=FLOAT))
    t0 = time.time()
    with torch.no_grad():
        run_filter(configuration, forcing, hour_index(FILTER_START) - 1,
                   hour_index(FILTER_START) + 999, x0, P0)
    per_hour = (time.time() - t0) / 1000
    filter_hours = hour_index(SELECT_END) - hour_index(FILTER_START)
    projected_selection_eval = warmup_seconds + per_hour * filter_hours + 5
    prefix_average = warmup_seconds + per_hour * 0.5 * (hour_index(TRAIN_END)
                                                        - hour_index(FILTER_START))
    grad_factor = 3.0
    projected_update = prefix_average + per_hour * WINDOW_HOURS * grad_factor + 3
    projected_run = (projected_update * N_UPDATES
                     + projected_selection_eval * (N_UPDATES // CHECKPOINT_EVERY + 2))
    return {
        "gate": "timing",
        "warmup_rollout_seconds": round(warmup_seconds, 2),
        "filter_seconds_per_hour_step": round(per_hour, 5),
        "projected_selection_eval_seconds": round(projected_selection_eval, 1),
        "projected_update_seconds": round(projected_update, 1),
        "projected_run_hours": round(projected_run / 3600, 2),
        "projected_family_hours_6_parallel": round(projected_run / 3600 * 12 / 6, 2),
        "hpc_threshold_wall_hours": 48,
        "passed": True,
    }


def run_gates() -> dict[str, Any]:
    config = load_config()
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    report = {"family": FAMILY_ID, "created_utc": datetime.now(timezone.utc).isoformat()}
    report["equivalence"] = gate_equivalence(config)
    print(f"[gate] equivalence: {report['equivalence']['passed']} "
          f"(max diff {report['equivalence']['max_abs_diff']:.2e})", flush=True)
    report["anchor"] = gate_anchor(config)
    for r in report["anchor"]["replicates"]:
        print(f"[gate] anchor seed {r['seed']}: {r['passed']} "
              f"(vs authority {r['max_abs_diff_vs_authority']:.2e}, "
              f"fastmath context {r['context_fastmath_gap_vs_eval2023']:.2e})", flush=True)
    report["timing"] = gate_timing(config)
    print(f"[gate] timing: projected {report['timing']['projected_run_hours']} h/run, "
          f"family {report['timing']['projected_family_hours_6_parallel']} h @6 procs", flush=True)
    report["determinism"] = gate_determinism(config)
    print(f"[gate] determinism: {report['determinism']['passed']}", flush=True)
    report["all_passed"] = all(report[g]["passed"] for g in
                               ("equivalence", "anchor", "determinism", "timing"))
    write_json(OUTPUT_ROOT / "gates" / "phase0_gates.json", report)
    return report


# ---------------------------------------------------------------------------
# Phase 2: sealed test
# ---------------------------------------------------------------------------


def seal_test() -> dict[str, Any]:
    config = load_config()
    forcing = load_forcing(config)
    verdict_path = OUTPUT_ROOT / "holdout_2023_verdict.json"
    if verdict_path.exists():
        raise RuntimeError("verdict already exists; the sealed test runs exactly once")
    runs: dict[str, dict[str, Any]] = {}
    for seed in SEEDS:
        for arm_id in ARMS:
            run_dir = OUTPUT_ROOT / "runs" / f"{arm_id}_seed{seed}"
            if not (run_dir / "run_manifest.json").exists():
                raise RuntimeError(f"missing run manifest: {run_dir}; all 12 must finish first")
            runs[f"{arm_id}|{seed}"] = {"dir": run_dir}

    full_end = hour_index(FULL_END)
    results: dict[str, Any] = {}
    for key, meta in runs.items():
        arm_id, seed_text = key.split("|")
        replicate = next(r for r in config["replicates"] if int(r["seed"]) == int(seed_text))
        start, frozen = load_start_parameters(map_path(replicate["start_params"]["path"]))
        learn_hydro, learn_noise = ARMS[arm_id]
        configuration = LearnableConfiguration(start, frozen, learn_hydro, learn_noise)
        configuration.load_state_dict(torch.load(meta["dir"] / "checkpoint.pt",
                                                 weights_only=True))
        evaluation = evaluate_origins(configuration, forcing, TEST_ORIGINS, full_end)
        results[key] = {"combined_mse": evaluation["combined_mse"],
                        "per_lead": evaluation["per_lead"],
                        "n_scored_origins": evaluation["n_scored_origins"]}
        np.save(meta["dir"] / "test_predictions.npy", evaluation["predictions"])
        np.save(meta["dir"] / "test_origins.npy", evaluation["scored_origins"])
        print(f"[test] {key}: mse={evaluation['combined_mse']:.4f} "
              f"nse24={evaluation['per_lead']['24']['nse']:.4f}", flush=True)

    ratios = {}
    for seed in SEEDS:
        base = results[f"all_frozen|{seed}"]["combined_mse"]
        ratios[str(seed)] = {arm: results[f"{arm}|{seed}"]["combined_mse"] / base
                             for arm in ARMS}
    joint = [ratios[str(seed)]["joint"] for seed in SEEDS]
    verdict = {
        "family": FAMILY_ID, "results": results, "ratios": ratios,
        "joint_over_all_frozen": joint,
        "median_joint_ratio": float(np.median(joint)),
        "primary_gate_pass": bool(float(np.median(joint)) <= 0.90
                                  and all(r <= 1.00 for r in joint)),
        "harm_gate_fail": bool(any(r > 1.05 for r in joint)),
        "created_utc": datetime.now(timezone.utc).isoformat(),
    }
    verdict["overall"] = ("PASS" if verdict["primary_gate_pass"]
                          and not verdict["harm_gate_fail"] else "FAIL")
    write_json(verdict_path, verdict)
    return verdict


def extension_test() -> dict[str, Any]:
    """Evaluate the staged extension arms on the (already opened) 2023 test origins.

    Labeling matters: the family seal was opened on 2026-08-28 for the original four arms, so
    the staged arms' 2023 evaluation is an EXTENSION, not a preregistered blind reading. Their
    gates (same template: median <= 0.90, all <= 1.00, any > 1.05 harms) were declared before
    any staged run existed, but the sibling arms' 2023 numbers were known when the staged
    design was chosen. Every conclusion must carry that label.
    """
    config = load_config()
    forcing = load_forcing(config)
    verdict_path = OUTPUT_ROOT / "extension_2023_verdict.json"
    if verdict_path.exists():
        raise RuntimeError("extension verdict already exists; it runs exactly once")
    family = json.loads((OUTPUT_ROOT / "holdout_2023_verdict.json").read_text(encoding="utf-8"))

    full_end = hour_index(FULL_END)
    results: dict[str, Any] = {}
    for seed in SEEDS:
        for arm_id in STAGED_ARMS:
            run_dir = OUTPUT_ROOT / "runs" / f"{arm_id}_seed{seed}"
            if not (run_dir / "run_manifest.json").exists():
                raise RuntimeError(f"missing staged run: {run_dir}")
            replicate = next(r for r in config["replicates"] if int(r["seed"]) == seed)
            start, frozen = load_start_parameters(map_path(replicate["start_params"]["path"]))
            configuration = LearnableConfiguration(start, frozen, True, True)
            configuration.load_state_dict(torch.load(run_dir / "checkpoint.pt",
                                                     weights_only=True))
            evaluation = evaluate_origins(configuration, forcing, TEST_ORIGINS, full_end)
            results[f"{arm_id}|{seed}"] = {
                "combined_mse": evaluation["combined_mse"],
                "per_lead": evaluation["per_lead"],
                "n_scored_origins": evaluation["n_scored_origins"]}
            np.save(run_dir / "test_predictions.npy", evaluation["predictions"])
            np.save(run_dir / "test_origins.npy", evaluation["scored_origins"])
            print(f"[ext-test] {arm_id}/{seed}: mse={evaluation['combined_mse']:.4f} "
                  f"nse24={evaluation['per_lead']['24']['nse']:.4f}", flush=True)

    ratios = {}
    for seed in SEEDS:
        base = family["results"][f"all_frozen|{seed}"]["combined_mse"]
        ratios[str(seed)] = {arm: results[f"{arm}|{seed}"]["combined_mse"] / base
                             for arm in STAGED_ARMS}
    verdict = {"family": FAMILY_ID, "extension": True,
               "extension_after_family_unseal": True,
               "results": results, "ratios": ratios,
               "created_utc": datetime.now(timezone.utc).isoformat()}
    for arm in STAGED_ARMS:
        arm_ratios = [ratios[str(seed)][arm] for seed in SEEDS]
        verdict[f"{arm}_ratios"] = arm_ratios
        verdict[f"{arm}_median"] = float(np.median(arm_ratios))
        verdict[f"{arm}_gate_pass"] = bool(float(np.median(arm_ratios)) <= 0.90
                                           and all(r <= 1.00 for r in arm_ratios))
        verdict[f"{arm}_harm"] = bool(any(r > 1.05 for r in arm_ratios))
    write_json(verdict_path, verdict)
    return verdict


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gates", action="store_true")
    parser.add_argument("--run", nargs=2, metavar=("ARM", "SEED"))
    parser.add_argument("--learning-seed", type=int, default=0)
    parser.add_argument("--seal-test", action="store_true")
    parser.add_argument("--extension-test", action="store_true")
    arguments = parser.parse_args()
    if arguments.gates:
        report = run_gates()
        print(json.dumps({"all_passed": report["all_passed"]}, indent=2))
        return
    if arguments.run:
        arm_id, seed_text = arguments.run
        if (arm_id not in ARMS and arm_id not in STAGED_ARMS) or int(seed_text) not in SEEDS:
            raise SystemExit(f"unknown arm/seed: {arguments.run}")
        config = load_config()
        suffix = f"_ls{arguments.learning_seed}" if arguments.learning_seed else ""
        record = run_training(arm_id, int(seed_text), config,
                              out_dir=OUTPUT_ROOT / "runs" / f"{arm_id}_seed{seed_text}{suffix}",
                              learning_seed=arguments.learning_seed)
        print(json.dumps({"arm": arm_id, "seed": seed_text,
                          "best_update": record["best_update"],
                          "best_selection_mse": record["best_selection_mse"],
                          "elapsed_seconds": record["elapsed_seconds"]}, indent=2))
        return
    if arguments.seal_test:
        verdict = seal_test()
        print(json.dumps({"overall": verdict["overall"],
                          "median_joint_ratio": verdict["median_joint_ratio"]}, indent=2))
        return
    if arguments.extension_test:
        verdict = extension_test()
        print(json.dumps({arm: {"median": verdict[f"{arm}_median"],
                                "gate_pass": verdict[f"{arm}_gate_pass"],
                                "harm": verdict[f"{arm}_harm"]}
                          for arm in STAGED_ARMS}, indent=2))
        return
    parser.error("choose --gates, --run ARM SEED, --seal-test, or --extension-test")


if __name__ == "__main__":
    main()
