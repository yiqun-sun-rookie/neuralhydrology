"""Differentiable single-basin mirror of the read-only Ku Wei XAJ path.

The operation order and branch thresholds follow the current
``forecast_system_lite`` NumPy/Numba implementation. This file contains only
the verified zero-snow physical model and Muskingum routing; it intentionally
contains no rainfall gate, bypass, loss, optimizer, or observed-flow access.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
from dataclasses import dataclass, fields
from pathlib import Path
from typing import Mapping

import numpy as np
import pandas as pd
import torch
import yaml


FLOAT_DTYPE = torch.float32


def _as_float_vector(value, *, device: torch.device | str | None = None) -> torch.Tensor:
    tensor = torch.as_tensor(value, dtype=FLOAT_DTYPE, device=device)
    if tensor.ndim == 0:
        tensor = tensor.reshape(1)
    if tensor.ndim != 1:
        raise ValueError(f"parameter must be scalar or one-dimensional, got shape={tuple(tensor.shape)}")
    return tensor.detach().requires_grad_(False)


@dataclass(frozen=True)
class XAJParameters:
    kc: torch.Tensor
    ki: torch.Tensor
    kg: torch.Tensor
    cs: torch.Tensor
    ci: torch.Tensor
    cg: torch.Tensor
    wum: torch.Tensor
    wlm: torch.Tensor
    wdm: torch.Tensor
    sm: torch.Tensor
    imp: torch.Tensor
    c: torch.Tensor
    b: torch.Tensor
    ex: torch.Tensor
    uf: torch.Tensor
    wmm: torch.Tensor
    ms: torch.Tensor

    @property
    def wm(self) -> torch.Tensor:
        """Capacity used by the authority: sum of the three layer capacities."""

        return self.wum + self.wlm + self.wdm

    def tensor_values(self) -> tuple[torch.Tensor, ...]:
        return tuple(getattr(self, field.name) for field in fields(self))

    def expand(self, size: int) -> "XAJParameters":
        if size <= 0:
            raise ValueError("expanded parameter size must be positive")
        expanded = {}
        for field in fields(self):
            value = getattr(self, field.name)
            if value.numel() == 1:
                expanded[field.name] = value.expand(size)
            elif value.numel() == size:
                expanded[field.name] = value
            else:
                raise ValueError(f"parameter {field.name} has {value.numel()} values; expected 1 or {size}")
        return XAJParameters(**expanded)

    def as_numpy_tuple(self) -> tuple[np.ndarray, ...]:
        return tuple(value.detach().cpu().numpy().astype(np.float32, copy=False) for value in self.tensor_values())


@dataclass(frozen=True)
class MuskingumParameters:
    c0: torch.Tensor
    c1: torch.Tensor
    c2: torch.Tensor
    n_sub: torch.Tensor


@dataclass(frozen=True)
class XAJStepResult:
    state: torch.Tensor
    liquid_mm: torch.Tensor
    evap_mm: torch.Tensor
    runoff_mm: torch.Tensor
    rs_mm: torch.Tensor
    rs_core_mm: torch.Tensor
    surface_injection_mm: torch.Tensor
    ri_mm: torch.Tensor
    rg_mm: torch.Tensor
    q_components: torch.Tensor


@dataclass(frozen=True)
class LumpedSequenceResult:
    q_outlet: torch.Tensor
    q_components: torch.Tensor
    final_state: torch.Tensor
    final_muskingum_state: torch.Tensor


def load_lumped_parameters(
    parameter_file: Path,
    *,
    section: str = "namou_kuwei",
    device: torch.device | str | None = None,
) -> tuple[XAJParameters, MuskingumParameters]:
    """Load the frozen one-basin parameters without importing the model repo."""

    with Path(parameter_file).open("r", encoding="utf-8") as stream:
        payload = yaml.safe_load(stream) or {}
    if section not in payload or not isinstance(payload[section], Mapping):
        raise ValueError(f"missing parameter section {section!r}: {parameter_file}")
    basin = payload[section]
    xaj_payload = basin.get("xaj_params")
    if not isinstance(xaj_payload, Mapping):
        raise ValueError(f"missing xaj_params mapping: {parameter_file}")
    required = ("kc", "ki", "kg", "cs", "ci", "cg", "wum", "wlm", "wdm", "sm", "imp", "c", "b", "ex", "uf", "wmm", "ms")
    missing = [name for name in required if name not in xaj_payload]
    if missing:
        raise ValueError(f"missing XAJ parameters: {missing}")
    xaj = XAJParameters(**{name: _as_float_vector(xaj_payload[name], device=device) for name in required})

    layers = basin.get("msk_layers")
    if not isinstance(layers, list) or len(layers) != 1:
        raise ValueError("Ku Wei lumped mirror requires exactly one Muskingum layer")
    layer = layers[0]
    indices = np.asarray(layer.get("index"), dtype=np.int64)
    if indices.shape != (1,) or int(indices[0]) != 0:
        raise ValueError(f"Ku Wei lumped mirror requires the single reach index [0], got {indices.tolist()}")
    c0 = _as_float_vector(layer.get("c0"), device=device)
    c1 = _as_float_vector(layer.get("c1"), device=device)
    if c0.numel() != 1 or c1.numel() != 1:
        raise ValueError("Ku Wei lumped mirror requires one c0 and one c1 value")
    c2 = (torch.ones_like(c0) - c0 - c1).detach().requires_grad_(False)
    n_sub = torch.as_tensor(layer.get("n_sub"), dtype=torch.int64, device=device)
    if n_sub.ndim == 0:
        n_sub = n_sub.reshape(1)
    if n_sub.shape != (1,) or int(n_sub.item()) < 1:
        raise ValueError(f"invalid one-reach n_sub: {n_sub.detach().cpu().tolist()}")
    return xaj, MuskingumParameters(c0=c0, c1=c1, c2=c2, n_sub=n_sub)


def initial_lumped_state(
    initial: Mapping[str, float] | None = None,
    *,
    device: torch.device | str | None = None,
) -> torch.Tensor:
    """Return the current Ku Wei cold-start state with the authority's 11 columns."""

    values = {
        "snow_depth": 0.0,
        "ice_depth": 0.0,
        "last_temp": 0.0,
        "W": 0.0,
        "WU": 13.9,
        "WL": 31.7,
        "WD": 4.0,
        "S": 4.1,
        "QS": 0.5,
        "QI": 5.0,
        "QG": 10.0,
    }
    if initial is not None:
        unknown = set(initial) - set(values)
        if unknown:
            raise ValueError(f"unknown initial-state fields: {sorted(unknown)}")
        values.update({name: float(value) for name, value in initial.items()})
    ordered = (
        "snow_depth",
        "ice_depth",
        "last_temp",
        "W",
        "WU",
        "WL",
        "WD",
        "S",
        "QS",
        "QI",
        "QG",
    )
    return torch.tensor([[values[name] for name in ordered]], dtype=FLOAT_DTYPE, device=device)


def torch_redistribute_soil_water(
    w: torch.Tensor,
    wu: torch.Tensor,
    wl: torch.Tensor,
    wd: torch.Tensor,
    wm: torch.Tensor,
    wum: torch.Tensor,
    wlm: torch.Tensor,
    wdm: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """Mirror ``redistribute_soil_water_numba`` including its ``1e-4`` branch threshold."""

    zero = torch.zeros_like(w)
    w_new = torch.minimum(torch.maximum(w, zero), wm)
    extra = w_new - (wu + wl + wd)
    positive = extra > 1e-4
    negative = extra < -1e-4

    positive_extra = extra
    take = torch.minimum(positive_extra, wum - wu)
    positive_wu = wu + take
    positive_extra = positive_extra - take
    take = torch.minimum(positive_extra, wlm - wl)
    positive_wl = wl + take
    positive_extra = positive_extra - take
    take = torch.minimum(positive_extra, wdm - wd)
    positive_wd = wd + take

    negative_extra = extra
    take = torch.minimum(-negative_extra, wu)
    negative_wu = wu - take
    negative_extra = negative_extra + take
    take = torch.minimum(-negative_extra, wl)
    negative_wl = wl - take
    negative_extra = negative_extra + take
    take = torch.minimum(-negative_extra, wd)
    negative_wd = wd - take

    adjusted_wu = torch.where(positive, positive_wu, torch.where(negative, negative_wu, wu))
    adjusted_wl = torch.where(positive, positive_wl, torch.where(negative, negative_wl, wl))
    adjusted_wd = torch.where(positive, positive_wd, torch.where(negative, negative_wd, wd))
    adjusted_wu = torch.minimum(torch.maximum(adjusted_wu, zero), wum)
    adjusted_wl = torch.minimum(torch.maximum(adjusted_wl, zero), wlm)
    adjusted_wd = torch.minimum(torch.maximum(adjusted_wd, zero), wdm)
    return w_new, adjusted_wu, adjusted_wl, adjusted_wd


def torch_calc_runoff(
    w: torch.Tensor,
    wmm: torch.Tensor,
    wm: torch.Tensor,
    b: torch.Tensor,
    pe: torch.Tensor,
) -> torch.Tensor:
    """Mirror the storage-capacity runoff curve."""

    wm_safe = torch.maximum(wm, torch.full_like(wm, 1e-12))
    frac = torch.maximum(torch.zeros_like(w), torch.minimum(torch.ones_like(w), 1.0 - w / wm_safe))
    positive_frac = frac > 0.0
    safe_frac = torch.where(positive_frac, frac, torch.ones_like(frac))
    frac_power = torch.where(
        positive_frac,
        torch.pow(safe_frac, 1.0 / (1.0 + b)),
        torch.zeros_like(frac),
    )
    w_temp = wmm * (1.0 - frac_power)
    temporary = w_temp + pe
    within_capacity = temporary <= wmm
    curve_branch = (pe > 0.0) & within_capacity
    safe_power_base = torch.where(curve_branch, 1.0 - temporary / wmm, torch.ones_like(temporary))
    curve_runoff = pe + w - wm + wm * torch.pow(safe_power_base, 1.0 + b)
    saturated_runoff = pe + w - wm
    return torch.where(
        curve_branch,
        curve_runoff,
        torch.where((pe > 0.0) & (~within_capacity), saturated_runoff, torch.zeros_like(pe)),
    )


def torch_update_soil_layers(
    wu: torch.Tensor,
    wl: torch.Tensor,
    wd: torch.Tensor,
    runoff: torch.Tensor,
    rain: torch.Tensor,
    ep: torch.Tensor,
    wum: torch.Tensor,
    wlm: torch.Tensor,
    wdm: torch.Tensor,
    cpar: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """Mirror the authority's positive- and non-positive-effective-rain branches."""

    zero = torch.zeros_like(rain)
    pe = rain - ep
    water_extra = torch.maximum(pe - runoff, zero)
    positive = pe > 0.0

    positive_eu = ep
    wu_plus = wu + water_extra
    over_upper = wu_plus > wum
    positive_wu = torch.where(over_upper, wum, wu_plus)
    water_extra_upper = torch.where(over_upper, wu_plus - wum, zero)
    wl_plus = wl + water_extra_upper
    over_lower = wl_plus > wlm
    positive_wl = torch.where(over_lower, wlm, wl_plus)
    water_extra_lower = torch.where(over_lower, wl_plus - wlm, zero)
    wd_plus = wd + water_extra_lower
    positive_wd = torch.where(wd_plus > wdm, wdm, wd_plus)

    branch_a = (wu + rain) > ep
    negative_eu = torch.where(branch_a, ep, wu + rain)
    remainder = ep - (wu + rain)
    branch_b_cond1 = wl >= cpar * wlm
    branch_b_cond2 = (~branch_b_cond1) & (wl >= cpar * torch.abs(remainder))
    branch_b_cond3 = (~branch_b_cond1) & (~branch_b_cond2)
    el_a = torch.abs(remainder * wl / wlm)
    el_b = cpar * torch.abs(remainder)
    branch_b_el = torch.where(branch_b_cond1, el_a, torch.where(branch_b_cond2, el_b, wl))
    branch_b_wl = torch.where(
        branch_b_cond1,
        wl - el_a,
        torch.where(branch_b_cond2, wl - el_b, zero),
    )
    branch_b_ed = torch.where(branch_b_cond3, torch.abs(cpar * remainder - wl), zero)
    branch_b_wd = wd - branch_b_ed
    negative_wu = torch.where(branch_a, wu + pe, zero)
    negative_wl = torch.where(branch_a, wl, branch_b_wl)
    negative_wd = torch.where(branch_a, wd, branch_b_wd)
    negative_el = torch.where(branch_a, zero, branch_b_el)
    negative_ed = torch.where(branch_a, zero, branch_b_ed)

    new_wu = torch.where(positive, positive_wu, negative_wu)
    new_wl = torch.where(positive, positive_wl, negative_wl)
    new_wd = torch.where(positive, positive_wd, negative_wd)
    eu = torch.where(positive, positive_eu, negative_eu)
    el = torch.where(positive, zero, negative_el)
    ed = torch.where(positive, zero, negative_ed)
    new_wu = torch.minimum(torch.maximum(new_wu, zero), wum)
    new_wl = torch.minimum(torch.maximum(new_wl, zero), wlm)
    new_wd = torch.minimum(torch.maximum(new_wd, zero), wdm)
    return new_wu + new_wl + new_wd, new_wu, new_wl, new_wd, eu + el + ed


def torch_free_water(
    s: torch.Tensor,
    runoff: torch.Tensor,
    pe: torch.Tensor,
    ki: torch.Tensor,
    kg: torch.Tensor,
    ms: torch.Tensor,
    sm: torch.Tensor,
    ex: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """Mirror the free-water store and surface/interflow/groundwater split."""

    zero = torch.zeros_like(pe)
    one = torch.ones_like(pe)
    tiny = torch.full_like(pe, 1e-12)
    s_new = torch.minimum(sm, s) * (one - ki - kg)
    sm_safe = torch.maximum(sm, tiny)
    frac = torch.clamp(one - s_new / sm_safe, min=0.0, max=1.0)
    s_temp = ms * (one - torch.pow(frac, one / (one + ex)))

    runoff_mask = runoff > zero
    fraction_mask = runoff_mask & (pe > tiny)
    safe_pe = torch.where(fraction_mask, pe, one)
    fr = torch.where(fraction_mask, torch.minimum(one, runoff / safe_pe), zero)

    first_surface_branch = runoff_mask & ((pe + s_temp) < ms)
    safe_power_base = torch.where(first_surface_branch, one - (pe + s_temp) / ms, one)
    first_surface = fr * (pe + s_new - sm + sm * torch.pow(safe_power_base, one + ex))
    second_surface = fr * (pe + s_new - sm)
    rs = torch.where(first_surface_branch, first_surface, torch.where(runoff_mask, second_surface, zero))

    nonzero_fraction = fr > tiny
    safe_fraction = torch.where(nonzero_fraction, fr, one)
    ratio_rs = torch.where(nonzero_fraction, rs / safe_fraction, zero)
    updated_with_runoff = torch.clamp(s_new + pe - ratio_rs, min=0.0)
    updated_with_runoff = torch.minimum(updated_with_runoff, sm)
    s_new = torch.where(runoff_mask, updated_with_runoff, torch.minimum(sm, s_new))
    ri = ki * s_new * fr
    rg = kg * s_new * fr
    return s_new, rs, ri, rg, fr


def torch_update_q(
    qs: torch.Tensor,
    qi: torch.Tensor,
    qg: torch.Tensor,
    rs: torch.Tensor,
    ri: torch.Tensor,
    rg: torch.Tensor,
    cs: torch.Tensor,
    ci: torch.Tensor,
    cg: torch.Tensor,
    uf: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Mirror the three linear runoff reservoirs."""

    qs_new = cs * qs + (1.0 - cs) * rs * uf
    qi_new = ci * qi + (1.0 - ci) * ri * uf
    qg_new = cg * qg + (1.0 - cg) * rg * uf
    return qs_new, qi_new, qg_new


def torch_muskingum_subreach_step(
    q_last: torch.Tensor,
    q_in: torch.Tensor,
    c0: torch.Tensor,
    c1: torch.Tensor,
    c2: torch.Tensor,
    n_sub: torch.Tensor,
) -> torch.Tensor:
    """Mirror one vectorized Muskingum step, including the saved prior inflow column."""

    if q_last.ndim != 2:
        raise ValueError(f"q_last must have shape [reach, column], got {tuple(q_last.shape)}")
    reach_count, max_n = q_last.shape
    if not all(value.shape == (reach_count,) for value in (q_in, c0, c1, c2, n_sub)):
        raise ValueError("Muskingum input dimension mismatch")
    if torch.any(n_sub < 1) or int(torch.max(n_sub).item()) + 1 > max_n:
        raise ValueError("q_last lacks the required prior-inflow padding column")

    last_in_column = max_n - 1
    rows = []
    for reach in range(reach_count):
        segment_count = int(n_sub[reach].item())
        first_out = c0[reach] * q_in[reach] + c1[reach] * q_last[reach, last_in_column] + c2[reach] * q_last[
            reach, 0
        ]
        values = [first_out]
        inflow_now = first_out
        for column in range(1, max_n):
            if column < segment_count:
                next_out = (
                    c0[reach] * inflow_now
                    + c1[reach] * q_last[reach, column - 1]
                    + c2[reach] * q_last[reach, column]
                )
                values.append(next_out)
                inflow_now = next_out
            elif column == last_in_column:
                values.append(q_in[reach])
            else:
                values.append(q_last[reach, column])
        rows.append(torch.stack(values))
    return torch.stack(rows)


def torch_xaj_step_with_liquid(
    state: torch.Tensor,
    liquid_mm: torch.Tensor,
    pet_mm: torch.Tensor,
    xaj: XAJParameters,
    *,
    snow_depth_snapshot: torch.Tensor | None = None,
    ice_depth_snapshot: torch.Tensor | None = None,
    last_temp_snapshot: torch.Tensor | None = None,
    surface_injection_mm: torch.Tensor | None = None,
) -> XAJStepResult:
    """Execute one zero-snow XAJ step with externally supplied liquid water."""

    if state.ndim != 2 or state.shape[1] != 11:
        raise ValueError(f"state must have shape [unit, 11], got {tuple(state.shape)}")
    unit_count = state.shape[0]
    if liquid_mm.shape != (unit_count,) or pet_mm.shape != (unit_count,):
        raise ValueError("liquid_mm and pet_mm must have one value per state row")
    xaj = xaj.expand(unit_count)
    zero = torch.zeros_like(liquid_mm)
    snow_snapshot = state[:, 0] if snow_depth_snapshot is None else snow_depth_snapshot
    ice_snapshot = state[:, 1] if ice_depth_snapshot is None else ice_depth_snapshot
    temp_snapshot = state[:, 2] if last_temp_snapshot is None else last_temp_snapshot
    if surface_injection_mm is None:
        routed_surface_injection = zero
        add_surface_injection = False
    else:
        if surface_injection_mm.shape != (unit_count,):
            raise ValueError("surface_injection_mm must have one value per state row")
        if torch.any(surface_injection_mm < 0.0):
            raise ValueError("surface_injection_mm must be non-negative")
        routed_surface_injection = surface_injection_mm
        add_surface_injection = True

    w, wu, wl, wd = torch_redistribute_soil_water(
        state[:, 3],
        state[:, 4],
        state[:, 5],
        state[:, 6],
        xaj.wm,
        xaj.wum,
        xaj.wlm,
        xaj.wdm,
    )
    ep = pet_mm * xaj.kc
    pe = liquid_mm - ep
    runoff = torch_calc_runoff(w, xaj.wmm, xaj.wm, xaj.b, pe)
    w_new, wu_new, wl_new, wd_new, evap = torch_update_soil_layers(
        wu,
        wl,
        wd,
        runoff,
        liquid_mm,
        ep,
        xaj.wum,
        xaj.wlm,
        xaj.wdm,
        xaj.c,
    )
    s_new, rs_core, ri, rg, _ = torch_free_water(
        state[:, 7],
        runoff,
        pe,
        xaj.ki,
        xaj.kg,
        xaj.ms,
        xaj.sm,
        xaj.ex,
    )
    rs_routed = rs_core + routed_surface_injection if add_surface_injection else rs_core
    qs_new, qi_new, qg_new = torch_update_q(
        state[:, 8],
        state[:, 9],
        state[:, 10],
        rs_routed,
        ri,
        rg,
        xaj.cs,
        xaj.ci,
        xaj.cg,
        xaj.uf,
    )
    new_state = torch.stack(
        (
            snow_snapshot,
            ice_snapshot,
            temp_snapshot,
            w_new,
            wu_new,
            wl_new,
            wd_new,
            s_new,
            qs_new,
            qi_new,
            qg_new,
        ),
        dim=1,
    )
    return XAJStepResult(
        state=new_state,
        liquid_mm=liquid_mm,
        evap_mm=evap,
        runoff_mm=runoff,
        rs_mm=rs_routed,
        rs_core_mm=rs_core,
        surface_injection_mm=routed_surface_injection,
        ri_mm=ri,
        rg_mm=rg,
        q_components=torch.stack((qs_new, qi_new, qg_new), dim=1),
    )


def run_lumped_sequence(
    *,
    rain_mm: torch.Tensor,
    pet_mm: torch.Tensor,
    temp_c: torch.Tensor,
    snow_mm: torch.Tensor,
    xaj: XAJParameters,
    muskingum: MuskingumParameters,
    initial_state: torch.Tensor,
    initial_muskingum_state: torch.Tensor | None = None,
) -> LumpedSequenceResult:
    """Run the differentiable one-basin zero-snow sequence in local hourly order."""

    forcing = (rain_mm, pet_mm, temp_c, snow_mm)
    if not all(value.ndim == 1 and len(value) == len(rain_mm) for value in forcing):
        raise ValueError("all forcing arrays must be one-dimensional and equal length")
    if not all(value.dtype == FLOAT_DTYPE for value in forcing):
        raise TypeError("all forcing tensors must use torch.float32")
    if torch.count_nonzero(snow_mm).item() != 0:
        raise ValueError("Ku Wei differentiable mirror only supports the verified zero-snow path")
    if initial_state.shape != (1, 11):
        raise ValueError(f"initial_state must have shape [1, 11], got {tuple(initial_state.shape)}")
    if muskingum.c0.shape != (1,) or muskingum.n_sub.shape != (1,):
        raise ValueError("lumped sequence requires one Muskingum reach")

    state = initial_state
    if initial_muskingum_state is None:
        q0 = torch.sum(state[:, -3:], dim=1)[0]
        maximum_columns = int(torch.max(muskingum.n_sub).item()) + 1
        muskingum_state = q0.expand(1, maximum_columns).clone()
    else:
        muskingum_state = initial_muskingum_state

    q_outlet = []
    q_components = []
    zero_snapshot = torch.zeros(1, dtype=FLOAT_DTYPE, device=rain_mm.device)
    for time_position in range(len(rain_mm)):
        step = torch_xaj_step_with_liquid(
            state,
            rain_mm[time_position:time_position + 1],
            pet_mm[time_position:time_position + 1],
            xaj,
            snow_depth_snapshot=zero_snapshot,
            ice_depth_snapshot=zero_snapshot,
            last_temp_snapshot=temp_c[time_position:time_position + 1],
        )
        state = step.state
        local_outflow = torch.sum(step.q_components, dim=1)
        muskingum_state = torch_muskingum_subreach_step(
            muskingum_state,
            local_outflow,
            muskingum.c0,
            muskingum.c1,
            muskingum.c2,
            muskingum.n_sub,
        )
        outlet_column = int(muskingum.n_sub[0].item()) - 1
        q_outlet.append(muskingum_state[0, outlet_column])
        q_components.append(step.q_components[0])
    if q_outlet:
        outlet_tensor = torch.stack(q_outlet)
        component_tensor = torch.stack(q_components)
    else:
        outlet_tensor = torch.empty(0, dtype=FLOAT_DTYPE, device=rain_mm.device)
        component_tensor = torch.empty((0, 3), dtype=FLOAT_DTYPE, device=rain_mm.device)
    return LumpedSequenceResult(
        q_outlet=outlet_tensor,
        q_components=component_tensor,
        final_state=state,
        final_muskingum_state=muskingum_state,
    )


def nash_sutcliffe_efficiency(observed: np.ndarray, simulated: np.ndarray) -> float:
    """Compute Nash-Sutcliffe efficiency after explicit caller-side masking."""

    observed_array = np.asarray(observed, dtype=np.float64)
    simulated_array = np.asarray(simulated, dtype=np.float64)
    if observed_array.shape != simulated_array.shape or observed_array.size == 0:
        raise ValueError("observed and simulated arrays must be non-empty with equal shape")
    if not np.isfinite(observed_array).all() or not np.isfinite(simulated_array).all():
        raise ValueError("Nash-Sutcliffe inputs must be finite")
    denominator = float(np.sum((observed_array - np.mean(observed_array)) ** 2))
    if denominator <= 0.0:
        raise ValueError("observed series has zero variance")
    return 1.0 - float(np.sum((simulated_array - observed_array) ** 2)) / denominator


def load_clean_discharge_prefix(discharge_file: Path, inclusive_end: pd.Timestamp) -> pd.DataFrame:
    """Load the clean-flow hourly prefix without parsing any locked holdout value."""

    first_row = pd.read_csv(Path(discharge_file), usecols=["time"], nrows=1, parse_dates=["time"])
    if first_row.empty:
        raise ValueError(f"empty clean discharge file: {discharge_file}")
    first_time = pd.Timestamp(first_row.at[0, "time"])
    inclusive_end = pd.Timestamp(inclusive_end)
    duration = inclusive_end - first_time
    if duration < pd.Timedelta(0) or duration % pd.Timedelta(hours=1) != pd.Timedelta(0):
        raise ValueError(f"invalid clean-discharge prefix: {first_time} to {inclusive_end}")
    row_count = int(duration / pd.Timedelta(hours=1)) + 1
    clean = pd.read_csv(
        Path(discharge_file),
        usecols=["time", "q_obs", "mask"],
        nrows=row_count,
        parse_dates=["time"],
    ).set_index("time")
    expected_index = pd.date_range(first_time, inclusive_end, freq="h", name="time")
    if not clean.index.equals(expected_index):
        raise ValueError("clean discharge prefix is not a unique contiguous hourly series")
    return clean


def sequence_fidelity_metrics(
    index: pd.DatetimeIndex,
    actual: np.ndarray,
    expected: np.ndarray,
    *,
    rtol: float,
    atol: float,
) -> dict[str, object]:
    """Summarize sequence error and retain the first tolerance exceedance."""

    actual_array = np.asarray(actual, dtype=np.float64)
    expected_array = np.asarray(expected, dtype=np.float64)
    if actual_array.shape != expected_array.shape or actual_array.ndim != 1:
        raise ValueError("actual and expected must be equal-length one-dimensional arrays")
    if len(index) != len(actual_array):
        raise ValueError("index length does not match sequence length")
    if not np.isfinite(actual_array).all() or not np.isfinite(expected_array).all():
        raise ValueError("fidelity sequences must be finite")
    absolute_error = np.abs(actual_array - expected_array)
    relative_error = absolute_error / np.maximum(np.abs(expected_array), 1e-12)
    exceeds = absolute_error > (float(atol) + float(rtol) * np.abs(expected_array))
    result: dict[str, object] = {
        "count": int(len(actual_array)),
        "rtol": float(rtol),
        "atol": float(atol),
        "passed": bool(not exceeds.any()),
        "max_absolute_error": float(absolute_error.max(initial=0.0)),
        "max_relative_error": float(relative_error.max(initial=0.0)),
        "first_exceedance_time": None,
        "first_exceedance_actual": None,
        "first_exceedance_expected": None,
        "first_exceedance_absolute_error": None,
    }
    if exceeds.any():
        first = int(np.flatnonzero(exceeds)[0])
        result.update(
            {
                "first_exceedance_time": str(pd.Timestamp(index[first])),
                "first_exceedance_actual": float(actual_array[first]),
                "first_exceedance_expected": float(expected_array[first]),
                "first_exceedance_absolute_error": float(absolute_error[first]),
            }
        )
    return result


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _git_snapshot(repository: Path) -> dict[str, str]:
    def run(*arguments: str) -> str:
        result = subprocess.run(
            ["git", "-C", str(repository), *arguments],
            check=True,
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        return result.stdout.rstrip()

    return {"commit": run("rev-parse", "HEAD"), "status_short": run("status", "--short")}


def _load_read_only_authority(core_file: Path):
    previous_disable = os.environ.get("DISABLE_NUMBA")
    previous_bytecode = sys.dont_write_bytecode
    os.environ["DISABLE_NUMBA"] = "1"
    sys.dont_write_bytecode = True
    try:
        spec = importlib.util.spec_from_file_location("gb00_fsl_hydromod_authority", core_file)
        module = importlib.util.module_from_spec(spec)
        if spec.loader is None:
            raise ImportError(f"cannot load read-only authority: {core_file}")
        spec.loader.exec_module(module)
        return module
    finally:
        sys.dont_write_bytecode = previous_bytecode
        if previous_disable is None:
            os.environ.pop("DISABLE_NUMBA", None)
        else:
            os.environ["DISABLE_NUMBA"] = previous_disable


def _run_read_only_sequence(
    authority,
    rain: np.ndarray,
    pet: np.ndarray,
    temp: np.ndarray,
    xaj: XAJParameters,
    muskingum: MuskingumParameters,
    initial_state: torch.Tensor,
) -> np.ndarray:
    state = initial_state.detach().cpu().numpy().astype(np.float32, copy=True)
    q0 = float(state[:, -3:].sum(axis=1)[0])
    maximum_columns = int(muskingum.n_sub.max().item()) + 1
    muskingum_state = np.full((1, maximum_columns), q0, dtype=np.float32)
    q_outlet = np.empty(len(rain), dtype=np.float32)
    zero = np.zeros(1, dtype=np.float32)
    c0 = muskingum.c0.detach().cpu().numpy()
    c1 = muskingum.c1.detach().cpu().numpy()
    c2 = muskingum.c2.detach().cpu().numpy()
    n_sub = muskingum.n_sub.detach().cpu().numpy().astype(np.int32)
    xaj_tuple = xaj.as_numpy_tuple()
    for time_position in range(len(rain)):
        state, _ = authority.xaj_step_with_liquid_numba(
            state,
            rain[time_position:time_position + 1],
            pet[time_position:time_position + 1],
            xaj_tuple,
            zero,
            zero,
            temp[time_position:time_position + 1],
        )
        local_outflow = state[:, -3:].sum(axis=1)
        muskingum_state = authority.muskingum_subreach_step_vec_numba(
            muskingum_state,
            local_outflow,
            c0,
            c1,
            c2,
            n_sub,
        )
        q_outlet[time_position] = muskingum_state[0, n_sub[0] - 1]
    return q_outlet


def run_fidelity_audit(config_path: Path, output_root: Path | None = None) -> dict[str, object]:
    """Run and preserve the GB00 hard-gate evidence without touching the authority repo."""

    config_path = Path(config_path).resolve()
    with config_path.open("r", encoding="utf-8") as stream:
        config = yaml.safe_load(stream) or {}
    experiment_id = str(config["experiment"]["id"])
    if experiment_id != "GB00_fidelity":
        raise ValueError(f"unexpected fidelity experiment id: {experiment_id}")
    project_root = Path(__file__).resolve().parents[5]
    fsl_root = Path(config["fsl"]["root"])
    core_file = Path(config["fsl"]["core_file"])
    parameter_file = Path(config["fsl"]["parameter_file"])
    grid_file = Path(config["data"]["grid_hybrid_csv"])
    discharge_file = Path(config["data"]["discharge_clean_csv"])
    configured_root = config.get("output", {}).get("root")
    if output_root is None:
        if not configured_root:
            raise ValueError("output.root is required when output_root is not provided")
        output_root = Path(configured_root)
    output_root = Path(output_root).resolve()
    run_dir = output_root / experiment_id
    if run_dir.exists() and any(run_dir.iterdir()):
        raise FileExistsError(f"refusing to overwrite non-empty fidelity directory: {run_dir}")

    simulation = config["simulation"]
    grid = pd.read_csv(grid_file, parse_dates=["time"]).set_index("time")
    grid = grid.loc[simulation["start"]:simulation["end"]]
    expected_index = pd.date_range(simulation["start"], simulation["end"], freq="h")
    if not grid.index.equals(expected_index):
        raise ValueError("fidelity forcing does not exactly match the configured hourly axis")
    if not np.isfinite(grid[["rain_g0", "pet_g0", "temp_g0", "snow_g0"]].to_numpy()).all():
        raise ValueError("non-finite fidelity forcing")
    if np.count_nonzero(grid["snow_g0"].to_numpy()) != 0:
        raise ValueError("Ku Wei fidelity forcing violates the verified zero-snow path")

    xaj, muskingum = load_lumped_parameters(parameter_file, section=config["fsl"]["section"])
    initial_state = initial_lumped_state(simulation["initial_state"])
    rain = grid["rain_g0"].to_numpy(dtype=np.float32)
    pet = grid["pet_g0"].to_numpy(dtype=np.float32)
    temp = grid["temp_g0"].to_numpy(dtype=np.float32)
    snow = grid["snow_g0"].to_numpy(dtype=np.float32)
    with torch.no_grad():
        torch_result = run_lumped_sequence(
            rain_mm=torch.from_numpy(rain),
            pet_mm=torch.from_numpy(pet),
            temp_c=torch.from_numpy(temp),
            snow_mm=torch.from_numpy(snow),
            xaj=xaj,
            muskingum=muskingum,
            initial_state=initial_state,
        )
    torch_q = torch_result.q_outlet.detach().cpu().numpy()
    authority = _load_read_only_authority(core_file)
    authority_q = _run_read_only_sequence(authority, rain, pet, temp, xaj, muskingum, initial_state)

    thresholds = config["fidelity_thresholds"]
    full_metrics = sequence_fidelity_metrics(
        grid.index,
        torch_q,
        authority_q,
        rtol=float(thresholds["short_rtol"]),
        atol=float(thresholds["short_atol_m3s"]),
    )
    short_mask = (grid.index >= pd.Timestamp(thresholds["short_window_start"])) & (
        grid.index <= pd.Timestamp(thresholds["short_window_end"])
    )
    short_metrics = sequence_fidelity_metrics(
        grid.index[short_mask],
        torch_q[short_mask],
        authority_q[short_mask],
        rtol=float(thresholds["short_rtol"]),
        atol=float(thresholds["short_atol_m3s"]),
    )

    clean = load_clean_discharge_prefix(discharge_file, pd.Timestamp(thresholds["clean_nse_end"]))
    observed = clean["q_obs"].reindex(grid.index).to_numpy(dtype=np.float64)
    clean_mask = (grid.index >= pd.Timestamp(thresholds["clean_nse_start"])) & (
        grid.index <= pd.Timestamp(thresholds["clean_nse_end"])
    ) & np.isfinite(observed)
    nse_torch = nash_sutcliffe_efficiency(observed[clean_mask], torch_q[clean_mask])
    nse_authority = nash_sutcliffe_efficiency(observed[clean_mask], authority_q[clean_mask])
    nse_difference = abs(nse_torch - nse_authority)

    step_test_command = [
        sys.executable,
        "-X",
        "utf8",
        "-m",
        "pytest",
        "tests/test_torch_xaj_mirror.py",
        "-q",
        "-k",
        "not continuous and not sequence_fidelity_metrics",
    ]
    step_test = subprocess.run(
        step_test_command,
        cwd=project_root,
        capture_output=True,
        text=True,
        encoding="utf-8",
        check=False,
    )
    passed = bool(
        step_test.returncode == 0
        and short_metrics["passed"]
        and nse_difference <= float(thresholds["max_abs_nse_difference"])
    )
    status = "passed_fidelity" if passed else "failed_fidelity"
    conclusion = "zero-bypass differentiable mirror passed the frozen technical fidelity gate" if passed else (
        "本地可微镜像尚未忠实复现"
    )
    metrics: dict[str, object] = {
        "experiment_id": experiment_id,
        "status": status,
        "conclusion": conclusion,
        "step_function_tests": {
            "command": step_test_command,
            "returncode": int(step_test.returncode),
            "passed": step_test.returncode == 0,
            "output": (step_test.stdout + step_test.stderr).strip(),
        },
        "full_sequence": full_metrics,
        "short_window": short_metrics,
        "clean_2020_2022": {
            "count": int(clean_mask.sum()),
            "nse_torch": float(nse_torch),
            "nse_read_only_authority": float(nse_authority),
            "absolute_difference": float(nse_difference),
            "maximum_allowed_difference": float(thresholds["max_abs_nse_difference"]),
            "passed": bool(nse_difference <= float(thresholds["max_abs_nse_difference"])),
        },
    }

    run_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(config_path, run_dir / "config_snapshot.yml")
    hashes = {
        "config": {"path": str(config_path), "sha256": _sha256(config_path)},
        "mirror": {"path": str(Path(__file__).resolve()), "sha256": _sha256(Path(__file__).resolve())},
        "grid_hybrid": {"path": str(grid_file), "sha256": _sha256(grid_file)},
        "discharge_clean": {"path": str(discharge_file), "sha256": _sha256(discharge_file)},
        "fsl_core": {"path": str(core_file), "sha256": _sha256(core_file)},
        "fsl_parameters": {"path": str(parameter_file), "sha256": _sha256(parameter_file)},
    }
    (run_dir / "input_hashes.json").write_text(
        json.dumps(hashes, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    provenance = {
        "laos_forecast": _git_snapshot(project_root),
        "forecast_system_lite_read_only": _git_snapshot(fsl_root),
    }
    (run_dir / "provenance.json").write_text(
        json.dumps(provenance, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    metrics_path = run_dir / "fidelity_metrics.json"
    metrics_path.write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8")
    pd.DataFrame(
        {
            "time": grid.index[short_mask],
            "q_torch": torch_q[short_mask],
            "q_read_only_authority": authority_q[short_mask],
            "absolute_error": np.abs(torch_q[short_mask] - authority_q[short_mask]),
        }
    ).to_csv(run_dir / "short_window_comparison.csv", index=False)

    registry_path = output_root / "registry.csv"
    record = pd.DataFrame(
        [
            {
                "exp_id": experiment_id,
                "type": "reproduction",
                "status": status,
                "run_dir": str(run_dir),
                "metrics_path": str(metrics_path),
                "parameter_file": str(parameter_file),
                "notes": conclusion,
            }
        ]
    )
    if registry_path.exists():
        registry = pd.read_csv(registry_path)
        if experiment_id in set(registry["exp_id"].astype(str)):
            raise FileExistsError(f"registry already contains {experiment_id}: {registry_path}")
        record = pd.concat([registry, record], ignore_index=True)
    record.to_csv(registry_path, index=False)
    return metrics


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the frozen GB00 zero-bypass fidelity audit.")
    parser.add_argument("--fidelity-config", type=Path, required=True)
    parser.add_argument("--output-root", type=Path)
    arguments = parser.parse_args()
    metrics = run_fidelity_audit(arguments.fidelity_config, arguments.output_root)
    print(json.dumps(metrics, ensure_ascii=False, indent=2))
    if metrics["status"] != "passed_fidelity":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
