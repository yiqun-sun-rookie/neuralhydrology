"""Recover TUKF20 verification and figures without rerunning formal training."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import traceback
from typing import Any, Mapping


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import run_tukf20_hpc_formal_pipeline as formal_pipeline  # noqa: E402
from scripts import tukf20_hbv_rolling_origin_joint_learning_common as scientific  # noqa: E402
from scripts import tukf20_hpc_deployment_common as deployment_common  # noqa: E402


SCIENTIFIC_CONFIG_RELATIVE = Path(
    "configs/tukf20_hbv_rolling_origin_joint_learning_v1.json"
)
DEPLOYMENT_CONFIG_RELATIVE = Path("configs/tukf20_hpc_deployment_v1.json")
RESULT_RELATIVE = Path("results/tukf20_hbv_rolling_origin_joint_learning_v1")
FIGURE_RELATIVE = Path(
    "artifacts/tukf20_hbv_rolling_origin_joint_learning_v1/figures"
)
STANDARD_VERIFIER_RELATIVE = Path(
    "scripts/verify_tukf20_hbv_rolling_origin_joint_learning.py"
)


def _read_json(path: Path | str) -> dict[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(f"expected a JSON object: {path}")
    return value


def _write_new_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(text)


def _hash_and_size(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(path)
    return {
        "sha256": deployment_common.sha256_file(path),
        "bytes": path.stat().st_size,
    }


def _tree_count_and_bytes(root: Path) -> tuple[int, int]:
    files = tuple(path for path in root.rglob("*") if path.is_file())
    return len(files), sum(path.stat().st_size for path in files)


def load_recovery_contract(path: Path | str) -> dict[str, Any]:
    contract = _read_json(path)
    if contract.get("schema_version") != "tukf20_hpc_verifier_recovery_v1":
        raise ValueError("unexpected verifier-recovery schema")
    if contract.get("recovery_id") != "TUKF20_HPC_VERIFIER_RECOVERY_V1":
        raise ValueError("unexpected verifier-recovery identity")
    if contract.get("scientific_experiment_id") != scientific.EXPERIMENT_ID:
        raise ValueError("scientific experiment identity changed")
    authorization = contract.get("authorization", {})
    required_true = {
        "recoverable_technical_repair_authorized",
        "formal_training_rerun_forbidden",
        "smoke_resubmission_forbidden",
        "formal_resubmission_forbidden",
        "scientific_contract_change_forbidden",
        "original_source_target_mutation_forbidden",
        "new_non_overwrite_target_required",
        "package_only_after_recovery_completed_zero_exit",
        "publication_forbidden",
        "cleanup_forbidden",
    }
    if set(authorization) != required_true or not all(
        authorization[name] is True for name in required_true
    ):
        raise PermissionError("verifier-recovery authorization changed")
    source = contract.get("source", {})
    if (
        int(source.get("formal_job_id", -1)) != 210748
        or source.get("formal_job_state") != "FAILED"
        or source.get("formal_job_exit_code") != "1:0"
        or source.get("bundle_sha256")
        != "721fa666319cc448e901515d066bb217560c87ec8edd19e5cbb2300269074f76"
    ):
        raise PermissionError("source formal-job boundary changed")
    if Path(str(contract["recovery"]["target_root"])).resolve() != ROOT.resolve():
        raise ValueError("recovery entrypoint is not running from the registered target")
    return contract


def verify_recovery_bundle(
    recovery_contract: Mapping[str, Any], manifest_path: Path
) -> dict[str, Any]:
    external = _read_json(manifest_path)
    deployment_root = manifest_path.resolve().parents[1]
    payload_path = deployment_root / str(external["payload_manifest_name"])
    payload = _read_json(payload_path)
    checks = {
        "schema": external.get("schema_version")
        == "tukf20_hpc_verifier_recovery_bundle_manifest_v1",
        "recovery_identity": external.get("recovery_id")
        == recovery_contract["recovery_id"]
        and payload.get("recovery_id") == recovery_contract["recovery_id"],
        "scientific_identity": external.get("scientific_experiment_id")
        == scientific.EXPERIMENT_ID
        and payload.get("scientific_experiment_id") == scientific.EXPERIMENT_ID,
        "payload_hash": deployment_common.sha256_file(payload_path)
        == external.get("payload_manifest_sha256"),
        "member_map": payload.get("members") == external.get("members"),
    }
    members = external.get("members", {})
    member_checks: dict[str, bool] = {}
    for name, expected in members.items():
        value = Path(str(name))
        if value.is_absolute() or ".." in value.parts:
            member_checks[str(name)] = False
            continue
        candidate = (deployment_root / value).resolve()
        try:
            candidate.relative_to(deployment_root.resolve())
        except ValueError:
            member_checks[str(name)] = False
            continue
        member_checks[str(name)] = candidate.is_file() and (
            deployment_common.sha256_file(candidate) == expected
        )
    checks["all_members"] = bool(member_checks) and all(member_checks.values())
    runtime_mapping = {
        recovery_contract["recovery"]["corrected_verifier_runtime_path"]: (
            "scripts/verify_tukf20_hbv_rolling_origin_joint_learning_recovery1.py"
        ),
        recovery_contract["recovery"]["recovery_entrypoint_runtime_path"]: (
            "scripts/recover_tukf20_hpc_verifier_postprocessing.py"
        ),
        recovery_contract["recovery"]["packaging_entrypoint_runtime_path"]: (
            "scripts/package_tukf20_hpc_verifier_recovery.py"
        ),
    }
    runtime_checks: dict[str, bool] = {}
    for runtime_name, member_name in runtime_mapping.items():
        runtime_path = ROOT / str(runtime_name)
        runtime_checks[str(runtime_name)] = runtime_path.is_file() and (
            deployment_common.sha256_file(runtime_path) == members.get(member_name)
        )
    checks["runtime_files_match_bundle"] = all(runtime_checks.values())
    if not all(checks.values()):
        raise ValueError(
            f"recovery deployment validation failed: {checks}: {runtime_checks}"
        )
    return {
        "checks": checks,
        "runtime_checks": runtime_checks,
        "archive_sha256": external["archive_sha256"],
        "member_count": len(member_checks),
    }


def _source_paths(contract: Mapping[str, Any]) -> dict[str, Path]:
    source = Path(str(contract["source"]["target_root"]))
    result = source / RESULT_RELATIVE
    status = source / "artifacts/tukf20_hpc_deployment_v1/status"
    return {
        "root": source,
        "bundle_manifest": source / "_transport/bundle_manifest.sha256.json",
        "scientific_config": source / SCIENTIFIC_CONFIG_RELATIVE,
        "standard_verifier": source / STANDARD_VERIFIER_RELATIVE,
        "registry": result / "registry.json",
        "result_manifest": result / "manifest.json",
        "failed_verification": result / "independent_verification.json",
        "formal_stdout": source / "logs/formal-210748.out",
        "formal_stderr": source / "logs/formal-210748.err",
        "pipeline_started": status / "formal_pipeline_started.json",
        "pipeline_complete": status / "formal_pipeline_complete.json",
        "formal_completion": status / "formal_completion.json",
        "result": result,
    }


def _source_accounting(job_id: int) -> tuple[str, dict[str, str]]:
    command = [
        "sacct",
        "-X",
        "-n",
        "-P",
        "-j",
        str(job_id),
        "--format=JobIDRaw,State,ExitCode,Elapsed,Start,End,NodeList",
    ]
    completed = subprocess.run(command, check=False, capture_output=True, text=True)
    if completed.returncode != 0:
        raise RuntimeError(f"source accounting query failed: {completed.stderr}")
    row: dict[str, str] | None = None
    for raw in completed.stdout.splitlines():
        fields = raw.split("|")
        if fields and fields[0] == str(job_id):
            row = {
                "job_id": fields[0],
                "state": fields[1].split("+")[0],
                "exit_code": fields[2],
                "elapsed": fields[3],
                "start": fields[4],
                "end": fields[5],
                "node": fields[6] if len(fields) > 6 else "",
            }
            break
    if row is None:
        raise ValueError(f"source Slurm job is absent from accounting: {job_id}")
    return completed.stdout, row


def verify_source_evidence(
    contract: Mapping[str, Any], *, accounting_destination: Path | None = None
) -> dict[str, Any]:
    source = contract["source"]
    paths = _source_paths(contract)
    for name, path in paths.items():
        if name in {"pipeline_complete", "formal_completion"}:
            continue
        if name in {"root", "result"}:
            if not path.is_dir():
                raise FileNotFoundError(path)
        elif not path.is_file():
            raise FileNotFoundError(path)
    if paths["pipeline_complete"].exists() or paths["formal_completion"].exists():
        raise ValueError("failed source unexpectedly has a formal completion marker")

    accounting_text, accounting = _source_accounting(int(source["formal_job_id"]))
    if accounting_destination is not None:
        _write_new_text(accounting_destination, accounting_text)
    expected_hashes = {
        "bundle_manifest": source["bundle_manifest_sha256"],
        "scientific_config": source["scientific_config_sha256"],
        "standard_verifier": source["original_verifier_sha256"],
        "registry": source["registry_sha256"],
        "result_manifest": source["result_manifest_sha256"],
        "failed_verification": source["failed_independent_verification_sha256"],
        "formal_stdout": source["formal_stdout_sha256"],
        "formal_stderr": source["formal_stderr_sha256"],
        "pipeline_started": source["formal_pipeline_started_sha256"],
    }
    hash_checks = {
        name: deployment_common.sha256_file(paths[name]) == expected
        for name, expected in expected_hashes.items()
    }
    bundle_manifest = _read_json(paths["bundle_manifest"])
    failed = _read_json(paths["failed_verification"])
    failed_checks = failed.get("checks", {})
    false_checks = sorted(name for name, value in failed_checks.items() if not value)
    file_count, total_bytes = _tree_count_and_bytes(paths["result"])
    checks = {
        "source_accounting": accounting["state"] == source["formal_job_state"]
        and accounting["exit_code"] == source["formal_job_exit_code"],
        "source_elapsed": accounting["elapsed"] == source["formal_job_elapsed"],
        "source_bundle_identity": bundle_manifest.get("archive_sha256")
        == source["bundle_sha256"],
        "source_hashes": all(hash_checks.values()),
        "source_result_size": file_count == int(source["result_file_count"])
        and total_bytes == int(source["result_total_bytes"]),
        "failed_verification_status": failed.get("status")
        == source["expected_failed_verification_status"],
        "single_expected_failed_check": false_checks
        == [source["expected_failed_check"]],
        "all_other_failed_run_checks_true": len(failed_checks) == 20
        and sum(bool(value) for value in failed_checks.values()) == 19,
    }
    if not all(checks.values()):
        raise ValueError(
            f"source recovery evidence changed: {checks}: {hash_checks}: {accounting}"
        )
    return {
        "checks": checks,
        "hash_checks": hash_checks,
        "accounting": accounting,
        "file_count": file_count,
        "total_bytes": total_bytes,
        "failed_verification": failed,
    }


def _run_logged(command: list[str], stdout_path: Path, stderr_path: Path) -> dict[str, Any]:
    started = datetime.now(timezone.utc)
    stdout_path.parent.mkdir(parents=True, exist_ok=True)
    with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
        completed = subprocess.run(
            command,
            cwd=ROOT,
            check=False,
            stdout=stdout,
            stderr=stderr,
        )
    return {
        "command": command,
        "return_code": int(completed.returncode),
        "started_at_utc": started.isoformat(),
        "finished_at_utc": datetime.now(timezone.utc).isoformat(),
        "stdout": {"path": stdout_path.relative_to(ROOT).as_posix(), **_hash_and_size(stdout_path)},
        "stderr": {"path": stderr_path.relative_to(ROOT).as_posix(), **_hash_and_size(stderr_path)},
    }


def run_verifier_recovery(
    *, recovery_contract_path: Path, recovery_bundle_manifest_path: Path
) -> dict[str, Any]:
    contract = load_recovery_contract(recovery_contract_path)
    recovery = contract["recovery"]
    evidence_root = ROOT / str(recovery["deployment_evidence_root"])
    status_root = evidence_root / "status"
    evidence_files = evidence_root / "evidence"
    started_path = status_root / "verifier_recovery_started.json"
    complete_path = ROOT / str(recovery["outputs_complete_record"])
    failure_path = status_root / "verifier_recovery_failure.json"
    if any(path.exists() for path in (started_path, complete_path, failure_path)):
        raise FileExistsError("refusing to replace verifier-recovery status")
    result_root = ROOT / RESULT_RELATIVE
    figure_root = ROOT / FIGURE_RELATIVE
    failed_in_copy = result_root / "independent_verification.json"
    preserved_failure = ROOT / str(recovery["failed_verification_evidence"])
    if figure_root.exists() or preserved_failure.exists():
        raise FileExistsError("refusing to replace verifier-recovery evidence")

    try:
        bundle_validation = verify_recovery_bundle(
            contract, recovery_bundle_manifest_path
        )
        source_validation = verify_source_evidence(
            contract,
            accounting_destination=evidence_files / "source_formal_sacct_snapshot.txt",
        )
        copied_hashes = {
            "standard_verifier": deployment_common.sha256_file(
                ROOT / STANDARD_VERIFIER_RELATIVE
            ),
            "scientific_config": deployment_common.sha256_file(
                ROOT / SCIENTIFIC_CONFIG_RELATIVE
            ),
            "registry": deployment_common.sha256_file(result_root / "registry.json"),
            "result_manifest": deployment_common.sha256_file(
                result_root / "manifest.json"
            ),
            "failed_verification": deployment_common.sha256_file(failed_in_copy),
        }
        expected_copy_hashes = {
            "standard_verifier": contract["source"]["original_verifier_sha256"],
            "scientific_config": contract["source"]["scientific_config_sha256"],
            "registry": contract["source"]["registry_sha256"],
            "result_manifest": contract["source"]["result_manifest_sha256"],
            "failed_verification": contract["source"][
                "failed_independent_verification_sha256"
            ],
        }
        if copied_hashes != expected_copy_hashes:
            raise ValueError(f"copied recovery source differs: {copied_hashes}")

        scientific.write_new_json(
            started_path,
            {
                "schema_version": "tukf20_hpc_verifier_recovery_start_v1",
                "recovery_id": contract["recovery_id"],
                "scientific_experiment_id": scientific.EXPERIMENT_ID,
                "source_formal_job_id": contract["source"]["formal_job_id"],
                "recovery_bundle_sha256": bundle_validation["archive_sha256"],
                "recovery_slurm_job_id": os.environ.get("SLURM_JOB_ID"),
                "node": os.environ.get("SLURMD_NODENAME"),
                "started_at_utc": datetime.now(timezone.utc).isoformat(),
                "formal_training_rerun": False,
                "scientific_contract_changed": False,
            },
        )
        preserved_failure.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(failed_in_copy), str(preserved_failure))
        if deployment_common.sha256_file(preserved_failure) != contract["source"][
            "failed_independent_verification_sha256"
        ]:
            raise ValueError("preserved failed verification hash changed")

        scientific_config = ROOT / SCIENTIFIC_CONFIG_RELATIVE
        verifier_path = ROOT / str(recovery["corrected_verifier_runtime_path"])
        verifier_step = _run_logged(
            [
                sys.executable,
                "-u",
                "-B",
                str(verifier_path),
                "--stage",
                "formal",
                "--config",
                str(scientific_config),
            ],
            evidence_files / "corrected_verifier_stdout.txt",
            evidence_files / "corrected_verifier_stderr.txt",
        )
        if verifier_step["return_code"] != 0:
            raise RuntimeError(f"corrected independent verifier failed: {verifier_step}")
        recovered_verification = _read_json(failed_in_copy)
        verification_checks = recovered_verification.get("checks", {})
        expected = contract["technical_expectations"]
        if not (
            recovered_verification.get("status")
            == expected["independent_verification_status"]
            and len(verification_checks) == int(expected["independent_check_count"])
            and all(bool(value) for value in verification_checks.values())
            and int(recovered_verification.get("test_readout_count", -1))
            == int(expected["test_readout_count"])
            and int(recovered_verification.get("primary_clean_error_count", -1))
            == int(expected["primary_clean_error_count"])
        ):
            raise ValueError("corrected independent verification is incomplete")
        if recovered_verification.get("scientific_classification") != source_validation[
            "failed_verification"
        ].get("scientific_classification"):
            raise ValueError("verifier repair changed the scientific classification")

        plotter_step = _run_logged(
            [
                sys.executable,
                "-u",
                "-B",
                "scripts/plot_tukf20_hbv_rolling_origin_joint_learning.py",
                "--config",
                str(scientific_config),
            ],
            evidence_files / "plotter_stdout.txt",
            evidence_files / "plotter_stderr.txt",
        )
        if plotter_step["return_code"] != 0:
            raise RuntimeError(f"verified plotting failed: {plotter_step}")

        deployment = _read_json(ROOT / DEPLOYMENT_CONFIG_RELATIVE)
        scientific_contract = scientific.load_contract(scientific_config)
        validation = formal_pipeline.validate_formal_outputs(
            deployment, scientific_contract, scientific=scientific
        )
        source_after = verify_source_evidence(contract)
        corrected_verifier_hash = deployment_common.sha256_file(verifier_path)
        report = {
            "schema_version": "tukf20_hpc_verifier_recovery_outputs_complete_v1",
            "recovery_id": contract["recovery_id"],
            "scientific_experiment_id": scientific.EXPERIMENT_ID,
            "status": "VERIFIER_RECOVERY_OUTPUTS_VERIFIED_AWAITING_SLURM_ACCOUNTING",
            "source_formal_job_id": contract["source"]["formal_job_id"],
            "source_formal_state": contract["source"]["formal_job_state"],
            "source_formal_exit_code": contract["source"]["formal_job_exit_code"],
            "recovery_slurm_job_id": os.environ.get("SLURM_JOB_ID"),
            "recovery_bundle_sha256": bundle_validation["archive_sha256"],
            "original_verifier_sha256": contract["source"][
                "original_verifier_sha256"
            ],
            "corrected_verifier_sha256": corrected_verifier_hash,
            "source_validation_before": {
                key: value
                for key, value in source_validation.items()
                if key != "failed_verification"
            },
            "source_validation_after": {
                key: value
                for key, value in source_after.items()
                if key != "failed_verification"
            },
            "copied_source_hashes": copied_hashes,
            "preserved_failed_verification": {
                "path": preserved_failure.relative_to(ROOT).as_posix(),
                **_hash_and_size(preserved_failure),
            },
            "steps": [verifier_step, plotter_step],
            "validation": {
                key: value
                for key, value in validation.items()
                if key not in {"result_root", "figure_root"}
            },
            "scientific_classification": recovered_verification[
                "scientific_classification"
            ],
            "formal_training_rerun": False,
            "scientific_contract_changed": False,
            "technical_verification_is_not_scientific_success": True,
            "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        }
        scientific.write_new_json(complete_path, report)
        return report
    except Exception as error:
        if not failure_path.exists():
            scientific.write_new_json(
                failure_path,
                {
                    "schema_version": "tukf20_hpc_verifier_recovery_failure_v1",
                    "recovery_id": contract["recovery_id"],
                    "scientific_experiment_id": scientific.EXPERIMENT_ID,
                    "status": "VERIFIER_RECOVERY_FAILED",
                    "source_formal_job_id": contract["source"]["formal_job_id"],
                    "recovery_slurm_job_id": os.environ.get("SLURM_JOB_ID"),
                    "error_type": type(error).__name__,
                    "error": str(error),
                    "traceback": traceback.format_exc(),
                    "formal_training_rerun": False,
                    "scientific_contract_changed": False,
                    "failed_at_utc": datetime.now(timezone.utc).isoformat(),
                },
            )
        raise


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--recovery-config", type=Path, required=True)
    parser.add_argument("--recovery-bundle-manifest", type=Path, required=True)
    parser.add_argument("--confirm-verifier-only-recovery", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    if not args.confirm_verifier_only_recovery:
        raise PermissionError("explicit verifier-only recovery confirmation is required")
    report = run_verifier_recovery(
        recovery_contract_path=args.recovery_config.resolve(),
        recovery_bundle_manifest_path=args.recovery_bundle_manifest.resolve(),
    )
    print(
        json.dumps(
            {
                "status": report["status"],
                "source_formal_job_id": report["source_formal_job_id"],
                "recovery_slurm_job_id": report["recovery_slurm_job_id"],
                "corrected_verifier_sha256": report["corrected_verifier_sha256"],
                "scientific_classification": report["scientific_classification"],
                "technical_verification_is_not_scientific_success": True,
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
