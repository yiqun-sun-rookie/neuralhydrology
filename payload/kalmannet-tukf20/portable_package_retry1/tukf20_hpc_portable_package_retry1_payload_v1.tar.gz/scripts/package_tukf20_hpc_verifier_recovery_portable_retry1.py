"""Build a Windows-portable package from already verified TUKF20 evidence."""
from __future__ import annotations

import argparse
import base64
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import sys
import tarfile
import traceback
from typing import Any, Iterable, Mapping


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = ROOT / "configs/tukf20_hpc_portable_package_retry1_v1.json"
PAYLOAD_MANIFEST_NAME = "portable_package_result_payload_manifest.json"
RECOVERY_EVIDENCE_PREFIX = "portable_package_recovery"
RECOVERY_EVIDENCE_FILES = (
    "_transport/bundle_manifest.sha256.json",
    "_transport/tukf20_hpc_portable_package_retry1_payload_v1.tar.gz",
    "configs/tukf20_hpc_portable_package_retry1_v1.json",
    "docs/superpowers/plans/2026-08-24-tukf20-portable-package-recovery.md",
    "hpc/tukf20_hbv_rolling_origin_joint_learning/submit_verifier_recovery_portable_package_retry1_cpu1.slurm",
    "portable_package_recovery_payload_manifest.json",
    "scripts/build_tukf20_hpc_portable_package_retry1_bundle.py",
    "scripts/package_tukf20_hpc_verifier_recovery_portable_retry1.py",
)
WINDOWS_INVALID_CHARACTERS = frozenset('<>:"\\|?*')
WINDOWS_RESERVED_STEMS = frozenset(
    {"CON", "PRN", "AUX", "NUL"}
    | {f"COM{index}" for index in range(1, 10)}
    | {f"LPT{index}" for index in range(1, 10)}
)


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def sha256_file(path: Path | str) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_json_bytes(payload: Mapping[str, Any]) -> bytes:
    return (
        json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    ).encode("utf-8")


def read_json(path: Path | str) -> dict[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(f"expected a JSON object: {path}")
    return value


def write_new_json(path: Path | str, payload: Mapping[str, Any]) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("xb") as stream:
        stream.write(canonical_json_bytes(payload))


def canonical_source_member_name(raw: str) -> str:
    """Validate the existing Linux-relative name without claiming portability."""
    if not isinstance(raw, str) or not raw or "\\" in raw:
        raise ValueError(f"unsafe source member: {raw!r}")
    value = PurePosixPath(raw)
    if value.is_absolute() or ".." in value.parts or not value.parts:
        raise ValueError(f"unsafe source member: {raw}")
    if value.as_posix() != raw or raw.startswith("/"):
        raise ValueError(f"source member is not canonical POSIX text: {raw}")
    return raw


def portable_member_name(raw: str) -> str:
    """Require a canonical name that is also safe as a Windows relative path."""
    canonical_source_member_name(raw)
    value = PurePosixPath(raw)
    for part in value.parts:
        if (
            any(character in WINDOWS_INVALID_CHARACTERS for character in part)
            or any(ord(character) < 32 for character in part)
            or part.endswith((" ", "."))
            or part.split(".", 1)[0].upper() in WINDOWS_RESERVED_STEMS
        ):
            raise ValueError(f"archive member is not Windows portable: {raw}")
    return raw


def _encode_component(component: str) -> str:
    encoded = base64.urlsafe_b64encode(component.encode("utf-8")).decode("ascii")
    return "p_" + encoded.rstrip("=")


def _decode_component(component: str) -> str:
    if not component.startswith("p_"):
        raise ValueError(f"invalid encoded portable component: {component}")
    encoded = component[2:]
    encoded += "=" * (-len(encoded) % 4)
    return base64.urlsafe_b64decode(encoded.encode("ascii")).decode("utf-8")


def rewrite_source_member_name(raw: str, *, prefix: str) -> str:
    canonical_source_member_name(raw)
    portable_member_name(prefix)
    source = PurePosixPath(raw)
    if source.parts[0] in {prefix, RECOVERY_EVIDENCE_PREFIX}:
        raise ValueError(f"source member uses a reserved portability prefix: {raw}")
    try:
        return portable_member_name(raw)
    except ValueError:
        rewritten = PurePosixPath(prefix, *(_encode_component(part) for part in source.parts))
        name = rewritten.as_posix()
        portable_member_name(name)
        decoded = tuple(_decode_component(part) for part in rewritten.parts[1:])
        if decoded != source.parts:
            raise ValueError(f"portable member rewrite is not reversible: {raw}")
        return name


def build_portable_name_map(
    source_names: Iterable[str], *, prefix: str
) -> tuple[dict[str, str], dict[str, str]]:
    """Return safe-name-to-source and source-to-safe rewrite mappings."""
    safe_to_source: dict[str, str] = {}
    rewrites: dict[str, str] = {}
    casefolded: dict[str, str] = {}
    for source_name in sorted(source_names):
        safe_name = rewrite_source_member_name(source_name, prefix=prefix)
        if safe_name in safe_to_source:
            raise ValueError(f"portable archive name collision: {safe_name}")
        folded = safe_name.casefold()
        if folded in casefolded:
            raise ValueError(
                "case-insensitive portable archive collision: "
                f"{safe_name} and {casefolded[folded]}"
            )
        safe_to_source[safe_name] = source_name
        casefolded[folded] = safe_name
        if safe_name != source_name:
            rewrites[source_name] = safe_name
    return safe_to_source, rewrites


def _tar_info(name: str, size: int) -> tarfile.TarInfo:
    info = tarfile.TarInfo(name=portable_member_name(name))
    info.size = int(size)
    info.mtime = 0
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    info.mode = 0o755 if name.endswith((".sh", ".slurm")) else 0o644
    return info


def write_deterministic_archive(
    destination: Path,
    members: Mapping[str, Path],
    *,
    virtual_members: Mapping[str, bytes],
) -> None:
    if destination.exists():
        raise FileExistsError(f"refusing to replace portable archive: {destination}")
    overlap = set(members) & set(virtual_members)
    if overlap:
        raise ValueError(f"duplicate real and virtual members: {sorted(overlap)}")
    names = [portable_member_name(name) for name in (*members, *virtual_members)]
    if len(names) != len(set(names)) or len(names) != len({name.casefold() for name in names}):
        raise ValueError("portable archive contains duplicate member names")
    for name, path in members.items():
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"portable archive source is not a regular file: {name}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("xb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode="w", format=tarfile.PAX_FORMAT) as archive:
                for name in sorted((*members, *virtual_members)):
                    payload = (
                        virtual_members[name]
                        if name in virtual_members
                        else members[name].read_bytes()
                    )
                    archive.addfile(_tar_info(name, len(payload)), io.BytesIO(payload))


def verify_portable_archive(
    archive_path: Path, manifest: Mapping[str, Any]
) -> dict[str, bool]:
    if archive_path.stat().st_size != int(manifest["archive_bytes"]):
        raise ValueError("portable archive byte count changed")
    if sha256_file(archive_path) != manifest["archive_sha256"]:
        raise ValueError("portable archive hash changed")
    expected = set(manifest["members"]) | {manifest["payload_manifest_name"]}
    seen: list[str] = []
    with tarfile.open(archive_path, "r:gz") as archive:
        for member in archive.getmembers():
            name = portable_member_name(member.name)
            if not member.isfile() or name in seen:
                raise ValueError(f"invalid portable archive member: {name}")
            seen.append(name)
        if set(seen) != expected:
            raise ValueError("portable archive member set differs from manifest")
        if len({name.casefold() for name in seen}) != len(seen):
            raise ValueError("portable archive has a case-insensitive collision")
        payload_stream = archive.extractfile(manifest["payload_manifest_name"])
        if payload_stream is None:
            raise ValueError("portable payload manifest is unreadable")
        payload_bytes = payload_stream.read()
        if sha256_bytes(payload_bytes) != manifest["payload_manifest_sha256"]:
            raise ValueError("portable payload manifest hash changed")
        payload = json.loads(payload_bytes.decode("utf-8"))
        if payload.get("members") != manifest.get("members"):
            raise ValueError("portable embedded and external member maps differ")
        if payload.get("path_rewrites") != manifest.get("path_rewrites"):
            raise ValueError("portable rewrite maps differ")
        for name, expected_hash in manifest["members"].items():
            stream = archive.extractfile(name)
            if stream is None or sha256_bytes(stream.read()) != expected_hash:
                raise ValueError(f"portable archive member hash differs: {name}")
    return {
        "outer_hash_verified": True,
        "all_names_windows_portable": True,
        "case_insensitive_uniqueness_verified": True,
        "embedded_manifest_verified": True,
        "all_member_hashes_verified": True,
    }


def _relative_files(root: Path) -> dict[str, Path]:
    if root.is_symlink() or not root.is_dir():
        raise ValueError(f"source recovery root is unavailable: {root}")
    members: dict[str, Path] = {}
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise ValueError(f"source recovery tree contains a symlink: {path}")
        if not path.is_file():
            continue
        name = canonical_source_member_name(path.relative_to(root).as_posix())
        if name in members:
            raise ValueError(f"duplicate source recovery member: {name}")
        members[name] = path.resolve()
    return members


def validate_source_snapshot(contract: Mapping[str, Any]) -> dict[str, Any]:
    source = contract["source"]
    root = Path(source["target_root"]).resolve()
    first_archive = root / source["first_archive_relative_path"]
    first_manifest_path = root / source["first_manifest_relative_path"]
    first_outputs_path = root / source["first_packaging_outputs_relative_path"]
    first_completion_path = root / source["first_packaging_completion_relative_path"]
    verification_path = root / source["independent_verification_relative_path"]
    figure_manifest_path = root / source["figure_manifest_relative_path"]
    pinned = {
        first_archive: source["first_archive_sha256"],
        first_manifest_path: source["first_manifest_sha256"],
        first_outputs_path: source["first_packaging_outputs_sha256"],
        first_completion_path: source["first_packaging_completion_sha256"],
        verification_path: source["independent_verification_sha256"],
        figure_manifest_path: source["figure_manifest_sha256"],
    }
    for path, expected in pinned.items():
        if not path.is_file() or sha256_file(path) != expected:
            raise ValueError(f"pinned source evidence changed: {path}")
    if first_archive.stat().st_size != int(source["first_archive_bytes"]):
        raise ValueError("first package byte count changed")

    first_manifest = read_json(first_manifest_path)
    first_outputs = read_json(first_outputs_path)
    first_completion = read_json(first_completion_path)
    verification = read_json(verification_path)
    figures = read_json(figure_manifest_path)
    expected = contract["technical_expectations"]
    checks = {
        "first_manifest_count": len(first_manifest.get("members", {}))
        == int(source["first_manifest_member_count"]),
        "first_manifest_archive": first_manifest.get("archive_sha256")
        == source["first_archive_sha256"],
        "first_completion": first_completion.get("slurm_state") == "COMPLETED"
        and first_completion.get("slurm_exit_code") == "0:0"
        and int(first_completion.get("packaging_slurm_job_id", -1))
        == int(source["first_packaging_job_id"]),
        "first_completion_checks": bool(first_completion.get("validation_checks"))
        and all(first_completion["validation_checks"].values()),
        "first_outputs": first_outputs.get("status")
        == "VERIFIER_RECOVERY_PACKAGE_COMPLETE_AWAITING_SLURM_ACCOUNTING",
        "no_training_rerun": first_outputs.get("formal_training_rerun") is False,
        "no_verifier_rerun": first_outputs.get(
            "independent_verification_rerun_during_packaging"
        )
        is False,
        "verification_status": verification.get("status")
        == expected["independent_verification_status"],
        "verification_checks": len(verification.get("checks", {}))
        == int(expected["independent_check_count"])
        and all(verification.get("checks", {}).values()),
        "readout_count": verification.get("test_readout_count")
        == int(expected["test_readout_count"]),
        "clean_error_count": verification.get("primary_clean_error_count")
        == int(expected["primary_clean_error_count"]),
        "scientific_status": verification.get("scientific_classification", {}).get(
            "overall_status"
        )
        == expected["scientific_status"],
        "figure_status": figures.get("status")
        == expected["figure_manifest_status"],
        "figure_count": len(figures.get("files", {}))
        == int(expected["figure_count"]),
    }
    if not all(checks.values()):
        raise PermissionError(f"portable source evidence gate failed: {checks}")

    files = _relative_files(root)
    old_names = set(first_manifest["members"])
    additions = set(source["expected_post_package_additions"])
    if set(files) != old_names | additions:
        raise ValueError(
            "source recovery tree differs from the first package plus registered "
            f"evidence: missing={sorted((old_names | additions) - set(files))}, "
            f"extra={sorted(set(files) - (old_names | additions))}"
        )
    if len(files) != int(source["expected_source_file_count"]):
        raise ValueError("source recovery file count changed")
    for name, expected_hash in first_manifest["members"].items():
        if sha256_file(files[name]) != expected_hash:
            raise ValueError(f"first-package source member changed: {name}")

    evidence_root = "artifacts/tukf20_hpc_verifier_recovery_v1"
    sacct = files[f"{evidence_root}/evidence/packaging_sacct_snapshot.txt"]
    stdout = files[f"logs/verifier-recovery-package-{source['first_packaging_job_id']}.out"]
    stderr = files[f"logs/verifier-recovery-package-{source['first_packaging_job_id']}.err"]
    receipt = files[f"{evidence_root}/submission/package_submission_receipt.json"]
    raw = files[f"{evidence_root}/submission/package_submission_raw.txt"]
    queue = files[f"{evidence_root}/submission/package_squeue_snapshot.txt"]
    job_id = files[f"{evidence_root}/submission/package_job_id.txt"]
    receipt_payload = read_json(receipt)
    evidence_hashes = first_completion["evidence"]
    addition_checks = {
        "sacct_hash": sha256_file(sacct) == evidence_hashes["sacct_sha256"],
        "stdout_hash": sha256_file(stdout) == evidence_hashes["stdout_sha256"],
        "stderr_hash": sha256_file(stderr) == evidence_hashes["stderr_sha256"],
        "receipt_hash": sha256_file(receipt)
        == evidence_hashes["submission_receipt_sha256"],
        "raw_hash": sha256_file(raw) == receipt_payload["raw_output_sha256"],
        "queue_hash": sha256_file(queue)
        == receipt_payload["squeue_snapshot_sha256"],
        "job_id": job_id.read_text(encoding="utf-8").strip()
        == str(source["first_packaging_job_id"]),
        "sacct_terminal": f"{source['first_packaging_job_id']}|" in sacct.read_text(
            encoding="utf-8"
        )
        and "|COMPLETED|0:0|" in sacct.read_text(encoding="utf-8"),
    }
    if not all(addition_checks.values()):
        raise PermissionError(
            f"post-package source evidence gate failed: {addition_checks}"
        )
    return {
        "root": root,
        "files": files,
        "first_manifest": first_manifest,
        "checks": {**checks, **addition_checks},
        "verification": verification,
        "figures": figures,
    }


def package_portable_results(contract_path: Path) -> dict[str, Any]:
    contract = read_json(contract_path)
    portable = contract["portable_package"]
    archive_path = ROOT / portable["archive_relative_path"]
    manifest_path = ROOT / portable["manifest_relative_path"]
    started_path = ROOT / portable["started_relative_path"]
    outputs_path = ROOT / portable["outputs_relative_path"]
    failure_path = ROOT / portable["failure_relative_path"]
    if any(
        path.exists()
        for path in (
            archive_path,
            manifest_path,
            started_path,
            outputs_path,
            failure_path,
        )
    ):
        raise FileExistsError("refusing to replace portable-package evidence")
    job_id = str(os.environ.get("SLURM_JOB_ID", ""))
    if not job_id:
        raise PermissionError("portable packaging requires a Slurm allocation")

    try:
        source = validate_source_snapshot(contract)
        prefix = portable["archive_rewrite_prefix"]
        safe_to_source, rewrites = build_portable_name_map(
            source["files"], prefix=prefix
        )
        if len(rewrites) != int(
            contract["source"]["expected_windows_path_rewrite_count"]
        ):
            raise ValueError(
                f"unexpected portable path rewrite count: {len(rewrites)}"
            )
        write_new_json(
            started_path,
            {
                "schema_version": "tukf20_hpc_portable_package_retry1_start_v1",
                "recovery_id": contract["recovery_id"],
                "scientific_experiment_id": contract["scientific_experiment_id"],
                "packaging_slurm_job_id": int(job_id),
                "source_formal_job_id": contract["source"]["source_formal_job_id"],
                "verifier_recovery_job_id": contract["source"][
                    "verifier_recovery_job_id"
                ],
                "first_packaging_job_id": contract["source"][
                    "first_packaging_job_id"
                ],
                "started_at_utc": datetime.now(timezone.utc).isoformat(),
                "formal_training_rerun": False,
                "independent_verification_rerun": False,
                "plotting_rerun": False,
            },
        )

        members = {
            safe_name: source["files"][source_name]
            for safe_name, source_name in safe_to_source.items()
        }
        evidence_members: dict[str, str] = {}
        for relative in RECOVERY_EVIDENCE_FILES:
            path = ROOT / relative
            if path.is_symlink() or not path.is_file():
                raise FileNotFoundError(f"portable recovery evidence missing: {relative}")
            member_name = portable_member_name(
                f"{RECOVERY_EVIDENCE_PREFIX}/{relative}"
            )
            if member_name in members:
                raise ValueError(f"portable recovery evidence collision: {member_name}")
            members[member_name] = path.resolve()
            evidence_members[member_name] = relative

        member_hashes = {
            name: sha256_file(path) for name, path in sorted(members.items())
        }
        source_member_map = {
            safe_name: source_name
            for safe_name, source_name in sorted(safe_to_source.items())
        }
        payload = {
            "schema_version": "tukf20_hpc_portable_package_retry1_payload_v1",
            "recovery_id": contract["recovery_id"],
            "scientific_experiment_id": contract["scientific_experiment_id"],
            "source_formal_job_id": contract["source"]["source_formal_job_id"],
            "verifier_recovery_job_id": contract["source"][
                "verifier_recovery_job_id"
            ],
            "first_packaging_job_id": contract["source"]["first_packaging_job_id"],
            "portable_packaging_job_id": int(job_id),
            "failed_portability_archive_sha256": contract["source"][
                "first_archive_sha256"
            ],
            "source_file_count": len(source["files"]),
            "source_member_map": source_member_map,
            "recovery_evidence_members": evidence_members,
            "path_rewrites": dict(sorted(rewrites.items())),
            "members": member_hashes,
            "scientific_classification": source["verification"][
                "scientific_classification"
            ],
            "formal_training_rerun": False,
            "independent_verification_rerun": False,
            "plotting_rerun": False,
            "technical_verification_is_not_scientific_success": True,
        }
        payload_bytes = canonical_json_bytes(payload)
        write_deterministic_archive(
            archive_path,
            members,
            virtual_members={PAYLOAD_MANIFEST_NAME: payload_bytes},
        )
        external = {
            "schema_version": "tukf20_hpc_portable_package_retry1_manifest_v1",
            "recovery_id": contract["recovery_id"],
            "scientific_experiment_id": contract["scientific_experiment_id"],
            "source_formal_job_id": contract["source"]["source_formal_job_id"],
            "verifier_recovery_job_id": contract["source"][
                "verifier_recovery_job_id"
            ],
            "first_packaging_job_id": contract["source"]["first_packaging_job_id"],
            "portable_packaging_job_id": int(job_id),
            "failed_portability_archive_sha256": contract["source"][
                "first_archive_sha256"
            ],
            "archive_name": archive_path.name,
            "archive_sha256": sha256_file(archive_path),
            "archive_bytes": archive_path.stat().st_size,
            "payload_manifest_name": PAYLOAD_MANIFEST_NAME,
            "payload_manifest_sha256": sha256_bytes(payload_bytes),
            "source_file_count": len(source["files"]),
            "member_count": len(member_hashes),
            "rewrite_count": len(rewrites),
            "source_member_map": source_member_map,
            "recovery_evidence_members": evidence_members,
            "path_rewrites": dict(sorted(rewrites.items())),
            "members": member_hashes,
            "formal_training_rerun": False,
            "independent_verification_rerun": False,
            "plotting_rerun": False,
            "technical_verification_is_not_scientific_success": True,
        }
        write_new_json(manifest_path, external)
        archive_checks = verify_portable_archive(archive_path, external)
        report = {
            "schema_version": "tukf20_hpc_portable_package_retry1_outputs_v1",
            "recovery_id": contract["recovery_id"],
            "scientific_experiment_id": contract["scientific_experiment_id"],
            "status": "PORTABLE_PACKAGE_COMPLETE_AWAITING_SLURM_ACCOUNTING",
            "source_formal_job_id": contract["source"]["source_formal_job_id"],
            "verifier_recovery_job_id": contract["source"][
                "verifier_recovery_job_id"
            ],
            "first_packaging_job_id": contract["source"]["first_packaging_job_id"],
            "portable_packaging_job_id": int(job_id),
            "source_validation_checks": source["checks"],
            "archive_validation_checks": archive_checks,
            "archive": {
                "path": portable["archive_relative_path"],
                "sha256": external["archive_sha256"],
                "bytes": external["archive_bytes"],
                "member_count": external["member_count"],
                "rewrite_count": external["rewrite_count"],
            },
            "manifest": {
                "path": portable["manifest_relative_path"],
                "sha256": sha256_file(manifest_path),
                "bytes": manifest_path.stat().st_size,
            },
            "scientific_classification": source["verification"][
                "scientific_classification"
            ],
            "formal_training_rerun": False,
            "independent_verification_rerun": False,
            "plotting_rerun": False,
            "technical_verification_is_not_scientific_success": True,
            "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        }
        write_new_json(outputs_path, report)
        return report
    except Exception as error:
        if not failure_path.exists():
            write_new_json(
                failure_path,
                {
                    "schema_version": "tukf20_hpc_portable_package_retry1_failure_v1",
                    "recovery_id": contract.get("recovery_id"),
                    "scientific_experiment_id": contract.get(
                        "scientific_experiment_id"
                    ),
                    "status": "PORTABLE_PACKAGE_FAILED",
                    "packaging_slurm_job_id": job_id,
                    "error_type": type(error).__name__,
                    "error": str(error),
                    "traceback": traceback.format_exc(),
                    "formal_training_rerun": False,
                    "independent_verification_rerun": False,
                    "plotting_rerun": False,
                    "failed_at_utc": datetime.now(timezone.utc).isoformat(),
                },
            )
        raise


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument(
        "--confirm-portable-package-recovery", action="store_true"
    )
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    if not args.confirm_portable_package_recovery:
        raise PermissionError("explicit portable package recovery confirmation required")
    report = package_portable_results(args.config.resolve())
    print(
        json.dumps(
            {
                "status": report["status"],
                "source_formal_job_id": report["source_formal_job_id"],
                "verifier_recovery_job_id": report["verifier_recovery_job_id"],
                "first_packaging_job_id": report["first_packaging_job_id"],
                "portable_packaging_job_id": report["portable_packaging_job_id"],
                "archive": report["archive"],
                "formal_training_rerun": False,
                "independent_verification_rerun": False,
                "plotting_rerun": False,
                "technical_verification_is_not_scientific_success": True,
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
