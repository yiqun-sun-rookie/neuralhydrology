# TUKF20 Portable Result-Package Recovery Plan

**Goal:** Replace only the unsafe result archive with a new, non-overwriting,
Windows-portable archive while preserving the completed scientific outputs,
failed package evidence, frozen contract, and all job identities.

**Observed fault:** The first recovered archive has the expected SHA-256 and
all member hashes, but 31 archive names begin with or contain Windows drive
components such as `G:`. They are relative on Linux but unsafe to extract on
Windows. The local audit stopped before extraction.

**Boundary:** Do not rerun the smoke test, formal training, scientific
verification, or plotting. Do not modify the source recovery target. Use a new
deployment, target, submission claim, Slurm job, archive name, mailbox
retrieval path, and local audit path.

## Task 1: Lock the portability fault in tests

- Add a result-package portability guard that rejects Windows drive components;
  keep the Linux runtime-bundle naming contract unchanged.
- Add a reversible rewrite from unsafe source-relative names to a reserved,
  canonical POSIX subtree.
- Test drive-prefixed, nested-drive, traversal, duplicate, and collision cases.

## Task 2: Build a deterministic package-only recovery

- Freeze the source target, jobs 210748, 211130, and 211139, the unsafe archive
  SHA-256, and the expected 31 rewrites.
- Verify every member of the old manifest plus the exact post-package evidence
  additions before building.
- Include the old unsafe archive as opaque failed evidence.
- Emit a safe-name member manifest and an explicit original-to-safe rewrite map.

## Task 3: Run one new packaging job

- Deploy through the Git mailbox to a new non-overwrite target.
- Use one central processing unit on `hcpu48y`, no memory request, no `srun`,
  and no training or verification command.
- Persist a permanent claim and raw `sbatch` output before parsing the unique
  job identifier.
- Require final Slurm `COMPLETED` and `0:0` before writing completion evidence.

## Task 4: Retrieve and independently audit

- Retrieve the new archive, manifest, accounting, logs, receipts, and completion
  records through a new mailbox path.
- Require every outer archive name to be safe on POSIX and Windows, every hash
  to match, all 31 rewrites to be reversible, and every scientific evidence
  file to equal the previously verified source.
- Extract only after all archive checks pass, then verify 20 independent checks,
  108 readouts, 13,608 clean errors, five figure hashes, both packaging stages,
  and all three preregistered primary contrasts.
