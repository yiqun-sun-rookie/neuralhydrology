"""Independent artifact-only recomputation for TUKF06.

This module intentionally imports no TUKF06 runner or scoring function.
"""
from __future__ import annotations

from hashlib import sha256
from pathlib import Path
import argparse
import json
import math
import os
from typing import Any, Mapping

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = ROOT / "configs" / "tukf06_full_diagonal_search_head_to_head_v1.json"
DEFAULT_OUTPUT = ROOT / "results" / "tukf06_full_diagonal_search_head_to_head_v1"
EXPERIMENT_ID = "TUKF06_FULL_DIAGONAL_SEARCH_HEAD_TO_HEAD_V1"
LEADS = (1, 2, 3)
SYSTEM_NAMES = (
    "same_forcing_open_loop",
    "default_noise_filter",
    "sampling_search_filter",
    "backpropagation_filter",
    "persistence",
    "second_order_autoregression",
)
FILTER_METHODS = (
    "default_noise_filter",
    "sampling_search_filter",
    "backpropagation_filter",
)


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _load_npz(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as archive:
        return {name: archive[name] for name in archive.files}


def _sha256_file(path: Path) -> str:
    digest = sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _sha256_arrays(arrays: Mapping[str, np.ndarray]) -> str:
    digest = sha256()
    for name in sorted(arrays):
        array = np.ascontiguousarray(np.asarray(arrays[name]))
        digest.update(name.encode("utf-8"))
        digest.update(str(array.dtype).encode("ascii"))
        digest.update(np.asarray(array.shape, dtype=np.int64).tobytes())
        digest.update(array.tobytes())
    return digest.hexdigest()


def _atomic_json(path: Path, payload: Any) -> None:
    content = (
        json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False) + "\n"
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp-{os.getpid()}")
    temporary.write_text(content, encoding="utf-8")
    os.replace(temporary, path)


def _nse(prediction: np.ndarray, target: np.ndarray, mask: np.ndarray) -> float:
    selected = np.asarray(mask, dtype=bool)
    error = np.asarray(prediction, dtype=np.float64)[selected] - np.asarray(
        target, dtype=np.float64
    )[selected]
    value = 1.0 - float(np.mean(error ** 2)) / float(
        np.var(np.asarray(target, dtype=np.float64)[selected], ddof=0)
    )
    if not math.isfinite(value):
        raise FloatingPointError("independent Nash-Sutcliffe efficiency is non-finite")
    return value


def _choose(theta: np.ndarray, training: np.ndarray, validation: np.ndarray,
            limit: int | None = None) -> int:
    count = len(theta) if limit is None else int(limit)
    return min(range(count), key=lambda index: (
        float(validation[index]),
        float(training[index]),
        tuple(float(value) for value in np.exp(theta[index])),
        int(index),
    ))


def _bootstrap(values: np.ndarray, contract: Mapping[str, Any]) -> list[float]:
    rng = np.random.default_rng(int(contract["bootstrap"]["seed"]))
    count = int(contract["bootstrap"]["paired_resamples"])
    indices = rng.integers(0, len(values), size=(count, len(values)))
    medians = np.median(values[indices], axis=1)
    alpha = (1.0 - float(contract["bootstrap"]["interval"])) / 2.0
    return [float(np.quantile(medians, alpha)), float(np.quantile(medians, 1.0 - alpha))]


def _decision(value: float, tolerance: float) -> str:
    if value >= tolerance:
        return "BACKPROPAGATION_ADVANTAGE"
    if value <= -tolerance:
        return "SAMPLING_SEARCH_ADVANTAGE"
    return "NO_DISCERNIBLE_ADVANTAGE"


def _correlation(x: np.ndarray, y: np.ndarray) -> float | None:
    if len(x) < 2 or np.std(x) == 0.0 or np.std(y) == 0.0:
        return None
    value = float(np.corrcoef(x, y)[0, 1])
    return value if math.isfinite(value) else None


def _compare(actual: Any, expected: Any, path: str, mismatches: list[str]) -> None:
    if isinstance(expected, Mapping):
        if not isinstance(actual, Mapping):
            mismatches.append(f"{path}: expected mapping")
            return
        if set(actual) != set(expected):
            mismatches.append(
                f"{path}: keys differ actual={sorted(actual)} expected={sorted(expected)}"
            )
            return
        for key in expected:
            _compare(actual[key], expected[key], f"{path}.{key}", mismatches)
        return
    if isinstance(expected, list):
        if not isinstance(actual, list) or len(actual) != len(expected):
            mismatches.append(f"{path}: list shape differs")
            return
        for index, (left, right) in enumerate(zip(actual, expected)):
            _compare(left, right, f"{path}[{index}]", mismatches)
        return
    if isinstance(expected, (int, float)) and not isinstance(expected, bool):
        if not isinstance(actual, (int, float)) or not math.isclose(
            float(actual), float(expected), rel_tol=1e-11, abs_tol=1e-12
        ):
            mismatches.append(f"{path}: actual={actual!r} expected={expected!r}")
        return
    if actual != expected:
        mismatches.append(f"{path}: actual={actual!r} expected={expected!r}")


def _verify_manifests(output: Path) -> None:
    selection_manifest_path = output / "selection_manifest.sha256.json"
    selection_seal = _read_json(output / "selection.sealed.json")
    if selection_seal.get("selection_manifest_sha256") != _sha256_file(selection_manifest_path):
        raise RuntimeError("independent selection-seal hash check failed")
    selection_manifest = _read_json(selection_manifest_path)
    for relative, expected in selection_manifest["files"].items():
        path = output / relative
        if not path.is_file() or _sha256_file(path) != expected:
            raise RuntimeError(f"independent selection member hash failed: {relative}")
    evaluation_manifest = _read_json(output / "evaluation_manifest.sha256.json")
    for relative, expected in evaluation_manifest["files"].items():
        path = output / relative
        if not path.is_file() or _sha256_file(path) != expected:
            raise RuntimeError(f"independent evaluation member hash failed: {relative}")


def _verify_selection_history(output: Path, basin_id: str, selection: Mapping[str, Any],
                              contract: Mapping[str, Any]) -> None:
    history = _load_npz(output / "selection" / f"basin_{basin_id}.npz")
    if _sha256_arrays(history) != selection["history_sha256"]:
        raise RuntimeError(f"selection history semantic hash failed for {basin_id}")
    if not np.array_equal(
        history["sampling_theta_log"][:8], history["shared_start_theta_log"]
    ):
        raise RuntimeError(f"shared anchor check failed for {basin_id}")
    method_prefixes = {
        "sampling_search": "sampling",
        "backpropagation": "backpropagation",
    }
    for method, prefix in method_prefixes.items():
        theta = history[f"{prefix}_theta_log"]
        training = history[f"{prefix}_training_objective"]
        validation = history[f"{prefix}_validation_objective"]
        if theta.shape[0] != 256 or training.shape != (256,) or validation.shape != (256,):
            raise RuntimeError(f"selection budget shape failed for {basin_id} {method}")
        if _choose(theta, training, validation) != selection[method]["selected_index"]:
            raise RuntimeError(f"selection winner recomputation failed for {basin_id} {method}")
        for budget in contract["budgets"]["prefix_reports"]:
            expected = selection[method]["budget_best_indices"][str(budget)]
            if _choose(theta, training, validation, int(budget)) != expected:
                raise RuntimeError(
                    f"selection prefix winner failed for {basin_id} {method} {budget}"
                )
    input_arrays = _load_npz(output / "selection_inputs" / f"basin_{basin_id}.npz")
    if _sha256_arrays(input_arrays) != selection["selection_input_sha256"]:
        raise RuntimeError(f"selection input semantic hash failed for {basin_id}")


def _read_and_score_basin(output: Path, basin_id: str,
                          selection: Mapping[str, Any]) -> dict[str, Any]:
    record = _read_json(output / "evaluation" / f"basin_{basin_id}.json")
    arrays = _load_npz(output / "evaluation" / f"basin_{basin_id}.npz")
    if _sha256_arrays(arrays) != record["archive_sha256"]:
        raise RuntimeError(f"evaluation archive semantic hash failed for {basin_id}")
    selection_input = _load_npz(output / "selection_inputs" / f"basin_{basin_id}.npz")
    evaluation_inputs = {
        "dates_ns": arrays["dates_ns"],
        "forcing": arrays["forcing"],
        "observations": arrays["target"],
        "parameters": selection_input["parameters"],
        "initial_storage_state": selection_input["initial_storage_state"],
        "initial_state": selection_input["initial_state"],
        "initial_covariance": selection_input["initial_covariance"],
        "base_observation_variance": selection_input["base_observation_variance"],
        "state_dimension": selection_input["state_dimension"],
    }
    if _sha256_arrays(evaluation_inputs) != record["evaluation_input_sha256"]:
        raise RuntimeError(f"evaluation input semantic hash failed for {basin_id}")
    target = arrays["target"]
    scores = {name: {} for name in SYSTEM_NAMES}
    gains = {method: {} for method in FILTER_METHODS}
    paired = {}
    common_counts = {}
    for lead in LEADS:
        key = str(lead)
        mask = np.asarray(arrays[f"common_mask_lead_{lead}"], dtype=bool)
        expected_mask = np.isfinite(target)
        for name in SYSTEM_NAMES:
            expected_mask &= np.isfinite(arrays[f"{name}_lead_{lead}"])
        expected_mask[:365] = False
        if not np.array_equal(mask, expected_mask):
            raise RuntimeError(f"common finite mask failed for {basin_id} lead {lead}")
        common_counts[key] = int(mask.sum())
        for name in SYSTEM_NAMES:
            scores[name][key] = _nse(arrays[f"{name}_lead_{lead}"], target, mask)
        for method in FILTER_METHODS:
            gains[method][key] = scores[method][key] - scores["same_forcing_open_loop"][key]
        paired[key] = gains["backpropagation_filter"][key] - gains["sampling_search_filter"][key]
    recomputed = {
        "common_count_by_lead": common_counts,
        "nse_by_system_and_lead": scores,
        "gain_vs_same_forcing_open_loop": gains,
        "paired_backpropagation_minus_sampling_by_lead": paired,
        "paired_backpropagation_minus_sampling_mean": float(
            np.mean([paired[str(lead)] for lead in LEADS])
        ),
    }
    mismatches: list[str] = []
    for key, expected in recomputed.items():
        _compare(record[key], expected, f"basin.{basin_id}.{key}", mismatches)
    if mismatches:
        raise RuntimeError("; ".join(mismatches[:5]))
    return {"basin_id": basin_id, **recomputed}


def _decisive_summary(results: list[dict[str, Any]], selections: Mapping[str, Any],
                      contract: Mapping[str, Any]) -> dict[str, Any]:
    system_median_nse = {name: {} for name in SYSTEM_NAMES}
    median_gain = {method: {} for method in FILTER_METHODS}
    negative = {method: {} for method in FILTER_METHODS}
    catastrophic = {}
    wins_persistence = {method: {} for method in FILTER_METHODS}
    wins_ar2 = {method: {} for method in FILTER_METHODS}
    for lead in LEADS:
        key = str(lead)
        for name in SYSTEM_NAMES:
            system_median_nse[name][key] = float(np.median([
                row["nse_by_system_and_lead"][name][key] for row in results
            ]))
        for method in FILTER_METHODS:
            values = np.asarray([
                row["gain_vs_same_forcing_open_loop"][method][key] for row in results
            ])
            median_gain[method][key] = float(np.median(values))
            negative[method][key] = int(np.sum(values < 0.0))
            wins_persistence[method][key] = int(sum(
                row["nse_by_system_and_lead"][method][key]
                > row["nse_by_system_and_lead"]["persistence"][key]
                for row in results
            ))
            wins_ar2[method][key] = int(sum(
                row["nse_by_system_and_lead"][method][key]
                > row["nse_by_system_and_lead"]["second_order_autoregression"][key]
                for row in results
            ))
    for method in FILTER_METHODS:
        catastrophic[method] = int(sum(
            row["gain_vs_same_forcing_open_loop"][method]["1"] < -0.10
            for row in results
        ))
    paired_rows = [{
        "basin_id": row["basin_id"],
        "by_lead": row["paired_backpropagation_minus_sampling_by_lead"],
        "mean_three_leads": row["paired_backpropagation_minus_sampling_mean"],
    } for row in results]
    paired_values = np.asarray([row["mean_three_leads"] for row in paired_rows])
    paired_median = float(np.median(paired_values))
    tolerance = float(contract["practical_equivalence"]["tolerance"])
    validation = np.asarray([
        (
            selections[row["basin_id"]]["sampling_search"]["selected"]["validation_objective"]
            - selections[row["basin_id"]]["backpropagation"]["selected"]["validation_objective"]
        )
        / max(
            selections[row["basin_id"]]["sampling_search"]["selected"]["validation_objective"],
            1e-12,
        )
        for row in results
    ])
    boundary = {
        method: {
            "exact_any_basin_count": int(sum(
                selections[row["basin_id"]][method]["boundary"]["exact_any"]
                for row in results
            )),
            "outer_five_percent_any_basin_count": int(sum(
                selections[row["basin_id"]][method]["boundary"]["outer_five_percent_any"]
                for row in results
            )),
        }
        for method in ("sampling_search", "backpropagation")
    }
    cost = {
        method: {
            "training_queries": int(sum(
                selections[row["basin_id"]][method]["training_queries"] for row in results
            )),
            "validation_queries": int(sum(
                selections[row["basin_id"]][method]["validation_queries"] for row in results
            )),
            "filter_passes": int(sum(
                selections[row["basin_id"]][method]["filter_passes"] for row in results
            )),
            "gradient_updates": int(sum(
                selections[row["basin_id"]][method]["gradient_updates"] for row in results
            )),
            "basin_wall_seconds_sum": float(sum(
                selections[row["basin_id"]][method]["wall_seconds"] for row in results
            )),
        }
        for method in ("sampling_search", "backpropagation")
    }
    spreads = np.asarray([
        selections[row["basin_id"]]["backpropagation_start_dispersion"]["relative_spread"]
        for row in results
    ])
    parameter_ranges = {
        method: {
            "q_min": float(min(
                min(selections[row["basin_id"]][method]["selected"]["q_diagonal"])
                for row in results
            )),
            "q_max": float(max(
                max(selections[row["basin_id"]][method]["selected"]["q_diagonal"])
                for row in results
            )),
            "r_b_min": float(min(
                selections[row["basin_id"]][method]["selected"]["r_b"]
                for row in results
            )),
            "r_b_max": float(max(
                selections[row["basin_id"]][method]["selected"]["r_b"]
                for row in results
            )),
        }
        for method in ("sampling_search", "backpropagation")
    }
    return {
        "median_whole_system_nse": system_median_nse,
        "median_filter_gain_vs_same_forcing_open_loop": median_gain,
        "negative_gain_basin_count": negative,
        "catastrophic_lead1_basin_count": catastrophic,
        "wins_over_persistence_basin_count": wins_persistence,
        "wins_over_second_order_autoregression_basin_count": wins_ar2,
        "paired_backpropagation_minus_sampling": {
            "per_basin": paired_rows,
            "median_by_lead": {
                str(lead): float(np.median([
                    row["paired_backpropagation_minus_sampling_by_lead"][str(lead)]
                    for row in results
                ]))
                for lead in LEADS
            },
            "median_of_three_lead_basin_means": paired_median,
            "bootstrap_95_percent_interval": _bootstrap(paired_values, contract),
            "practical_equivalence_tolerance": tolerance,
            "verdict": _decision(paired_median, tolerance),
        },
        "validation_to_evaluation": {
            "median_relative_validation_objective_advantage_backpropagation": float(
                np.median(validation)
            ),
            "median_evaluation_nse_advantage_backpropagation": paired_median,
            "pearson_correlation": _correlation(validation, paired_values),
            "same_sign_basin_count": int(np.sum(np.sign(validation) == np.sign(paired_values))),
            "basin_count": len(results),
        },
        "selected_parameter_boundary": boundary,
        "selected_parameter_ranges": parameter_ranges,
        "backpropagation_start_stability": {
            "median_relative_best_validation_spread": float(np.median(spreads)),
            "maximum_relative_best_validation_spread": float(np.max(spreads)),
        },
        "selection_computational_cost": cost,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--output-root", "--output", dest="output_root", type=Path,
                        default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    contract = _read_json(args.config)
    output = args.output_root.resolve()
    if contract.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("independent verifier received a different experiment")
    if not (output / "evaluation_summary.json").is_file():
        raise FileNotFoundError("evaluation summary is absent")
    _verify_manifests(output)
    selections = {
        basin_id: _read_json(output / "selection" / f"basin_{basin_id}.json")
        for basin_id in contract["basins"]
    }
    results = []
    for basin_id in contract["basins"]:
        _verify_selection_history(output, basin_id, selections[basin_id], contract)
        results.append(_read_and_score_basin(output, basin_id, selections[basin_id]))
    recomputed = _decisive_summary(results, selections, contract)
    reported = _read_json(output / "evaluation_summary.json")
    mismatches: list[str] = []
    for key, expected in recomputed.items():
        _compare(reported.get(key), expected, key, mismatches)
    audit = {
        "experiment_id": EXPERIMENT_ID,
        "status": "REPRODUCIBLE" if not mismatches else "MISMATCH",
        "basin_count": len(results),
        "mismatch_count": len(mismatches),
        "mismatches": mismatches[:100],
        "evaluation_summary_sha256": _sha256_file(output / "evaluation_summary.json"),
        "selection_manifest_sha256": _sha256_file(output / "selection_manifest.sha256.json"),
        "evaluation_manifest_sha256": _sha256_file(output / "evaluation_manifest.sha256.json"),
    }
    _atomic_json(output / "independent_audit.json", audit)
    if mismatches:
        raise RuntimeError(f"independent audit found {len(mismatches)} mismatches")
    members = sorted(
        path for path in output.rglob("*")
        if path.is_file() and path.name != "manifest.final.sha256.json"
    )
    final_manifest = {
        "experiment_id": EXPERIMENT_ID,
        "status": "REPRODUCIBLE",
        "files": {
            str(path.relative_to(output)).replace("\\", "/"): _sha256_file(path)
            for path in members
        },
    }
    _atomic_json(output / "manifest.final.sha256.json", final_manifest)
    print(
        f"REPRODUCIBLE basins={len(results)} verdict="
        f"{reported['paired_backpropagation_minus_sampling']['verdict']}",
        flush=True,
    )


if __name__ == "__main__":
    main()
