"""Equal-budget selection for the TUKF06 full-diagonal optimizer comparison."""
from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
import argparse
import json
import os
import platform
import sys
import time
import traceback
from typing import Any, Callable, Mapping, Sequence

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
for _extra in (str(ROOT), str(ROOT / "src")):
    if _extra not in sys.path:
        sys.path.insert(0, _extra)

from scripts.tukf06_full_diagonal_common import (  # noqa: E402
    DEFAULT_BASIN_LIST,
    DEFAULT_CONFIG,
    DEFAULT_DATA_ROOT,
    DEFAULT_EXTERNAL_LOADER,
    DEFAULT_OUTPUT,
    DEFAULT_PRIOR_CSV,
    DEFAULT_SEARCH_DESIGN,
    EXPERIMENT_ID,
    atomic_write_bytes,
    atomic_write_json,
    atomic_write_npz,
    basin_input_arrays,
    boundary_diagnostics,
    build_basin_context,
    load_contract,
    load_period,
    load_search_design,
    log_bound_vectors,
    mem_available_gib,
    multilead_objective,
    sha256_arrays,
    sha256_file,
    source_hashes,
    worker_count_from_available_gib,
)
from global_hydrology.data.hbvlite_prior import load_hbvlite_prior  # noqa: E402


Objective = Callable[[Any, torch.Tensor, torch.Tensor, torch.Tensor, bool, Mapping[str, Any]], torch.Tensor]


@dataclass
class MethodSelection:
    theta_history: np.ndarray
    training_objectives: np.ndarray
    validation_objectives: np.ndarray
    selected_index: int
    budget_best: dict[int, int]
    training_queries: int
    validation_queries: int
    filter_passes: int
    gradient_updates: int
    wall_seconds: float
    start_theta: np.ndarray


def choose_checkpoint(
    theta_history: np.ndarray,
    training_objectives: np.ndarray,
    validation_objectives: np.ndarray,
    *,
    limit: int | None = None,
) -> int:
    theta = np.asarray(theta_history, dtype=np.float64)
    training = np.asarray(training_objectives, dtype=np.float64)
    validation = np.asarray(validation_objectives, dtype=np.float64)
    if theta.ndim != 2 or training.shape != (len(theta),) or validation.shape != (len(theta),):
        raise ValueError("checkpoint histories have inconsistent shapes")
    count = len(theta) if limit is None else int(limit)
    if count < 1 or count > len(theta):
        raise ValueError("checkpoint selection limit is invalid")
    if not np.isfinite(theta[:count]).all() or not np.isfinite(training[:count]).all() \
            or not np.isfinite(validation[:count]).all():
        raise FloatingPointError("checkpoint history contains a non-finite value")
    return min(
        range(count),
        key=lambda index: (
            float(validation[index]),
            float(training[index]),
            tuple(float(value) for value in np.exp(theta[index])),
            int(index),
        ),
    )


def _budget_best(
    theta_history: np.ndarray,
    training_objectives: np.ndarray,
    validation_objectives: np.ndarray,
    contract: Mapping[str, Any],
) -> dict[int, int]:
    return {
        int(budget): choose_checkpoint(
            theta_history, training_objectives, validation_objectives, limit=int(budget)
        )
        for budget in contract["budgets"]["prefix_reports"]
    }


def run_sampling_search(
    context: Any,
    training: tuple[torch.Tensor, torch.Tensor],
    validation: tuple[torch.Tensor, torch.Tensor],
    points: np.ndarray,
    contract: Mapping[str, Any],
    *,
    objective_fn: Objective = multilead_objective,
) -> MethodSelection:
    point_array = np.asarray(points, dtype=np.float64)
    expected = int(contract["budgets"]["candidate_or_checkpoint_count"])
    if point_array.shape != (expected, int(context.dimension) + 1):
        raise ValueError("sampling design shape does not match the basin state dimension")
    started = time.perf_counter()
    training_values: list[float] = []
    validation_values: list[float] = []
    device = getattr(context, "device", torch.device("cpu"))
    dtype = getattr(context, "dtype", torch.float64)
    for point in point_array:
        theta = torch.as_tensor(point, dtype=dtype, device=device)
        training_loss = objective_fn(
            context, training[0], training[1], theta, False, contract
        )
        validation_loss = objective_fn(
            context, validation[0], validation[1], theta, False, contract
        )
        row = (float(training_loss.detach()), float(validation_loss.detach()))
        if not np.isfinite(row).all():
            raise FloatingPointError("sampling objective is non-finite")
        training_values.append(row[0])
        validation_values.append(row[1])
    training_array = np.asarray(training_values, dtype=np.float64)
    validation_array = np.asarray(validation_values, dtype=np.float64)
    selected = choose_checkpoint(point_array, training_array, validation_array)
    return MethodSelection(
        theta_history=point_array.copy(),
        training_objectives=training_array,
        validation_objectives=validation_array,
        selected_index=selected,
        budget_best=_budget_best(point_array, training_array, validation_array, contract),
        training_queries=len(point_array),
        validation_queries=len(point_array),
        filter_passes=2 * len(point_array),
        gradient_updates=0,
        wall_seconds=time.perf_counter() - started,
        start_theta=point_array[:8].copy(),
    )


def run_backpropagation_search(
    context: Any,
    training: tuple[torch.Tensor, torch.Tensor],
    validation: tuple[torch.Tensor, torch.Tensor],
    anchors: np.ndarray,
    contract: Mapping[str, Any],
    *,
    objective_fn: Objective = multilead_objective,
) -> MethodSelection:
    anchor_array = np.asarray(anchors, dtype=np.float64)
    start_count = int(contract["backpropagation"]["starts"])
    if anchor_array.shape != (start_count, int(context.dimension) + 1):
        raise ValueError("backpropagation anchors do not match the basin state dimension")
    device = getattr(context, "device", torch.device("cpu"))
    dtype = getattr(context, "dtype", torch.float64)
    lower, upper = log_bound_vectors(
        int(context.dimension), contract, device=device, dtype=dtype
    )
    parameters = [
        torch.nn.Parameter(torch.as_tensor(row, dtype=dtype, device=device).clone())
        for row in anchor_array
    ]
    optimizers = [
        torch.optim.Adam([theta], lr=float(contract["backpropagation"]["learning_rate"]))
        for theta in parameters
    ]
    theta_rows: list[np.ndarray] = []
    training_values: list[float] = []
    validation_values: list[float] = []
    gradient_updates = 0
    started = time.perf_counter()
    updates_per_start = int(contract["backpropagation"]["updates_per_start"])
    for step in range(updates_per_start + 1):
        for start_index, (theta, optimizer) in enumerate(zip(parameters, optimizers)):
            optimizer.zero_grad(set_to_none=True)
            training_loss = objective_fn(
                context, training[0], training[1], theta, True, contract
            )
            validation_loss = objective_fn(
                context, validation[0], validation[1], theta, False, contract
            )
            row = theta.detach().cpu().numpy().astype(np.float64, copy=True)
            training_value = float(training_loss.detach())
            validation_value = float(validation_loss.detach())
            if not np.isfinite(row).all() or not np.isfinite(
                [training_value, validation_value]
            ).all():
                raise FloatingPointError(
                    f"non-finite backpropagation checkpoint at start {start_index}, step {step}"
                )
            theta_rows.append(row)
            training_values.append(training_value)
            validation_values.append(validation_value)
            if step == updates_per_start:
                continue
            training_loss.backward()
            if theta.grad is None or not bool(torch.isfinite(theta.grad).all()):
                raise FloatingPointError(
                    f"non-finite full-diagonal gradient at start {start_index}, step {step}"
                )
            optimizer.step()
            with torch.no_grad():
                theta.clamp_(min=lower, max=upper)
            gradient_updates += 1
    theta_array = np.stack(theta_rows, axis=0)
    training_array = np.asarray(training_values, dtype=np.float64)
    validation_array = np.asarray(validation_values, dtype=np.float64)
    expected = int(contract["budgets"]["candidate_or_checkpoint_count"])
    if len(theta_array) != expected or gradient_updates != int(
        contract["budgets"]["backpropagations_per_basin"]
    ):
        raise AssertionError("backpropagation did not consume the frozen budget")
    selected = choose_checkpoint(theta_array, training_array, validation_array)
    return MethodSelection(
        theta_history=theta_array,
        training_objectives=training_array,
        validation_objectives=validation_array,
        selected_index=selected,
        budget_best=_budget_best(theta_array, training_array, validation_array, contract),
        training_queries=len(theta_array),
        validation_queries=len(theta_array),
        filter_passes=2 * len(theta_array),
        gradient_updates=gradient_updates,
        wall_seconds=time.perf_counter() - started,
        start_theta=anchor_array.copy(),
    )


def load_selection_period(
    basin_id: str,
    contract: Mapping[str, Any],
    *,
    data_root: Path,
    loader_file: Path,
) -> tuple[torch.Tensor, torch.Tensor, np.ndarray, int]:
    training_period = contract["periods"]["training"]
    validation_period = contract["periods"]["validation"]
    evaluation_period = contract["periods"]["evaluation"]
    if training_period[0] <= evaluation_period[1]:
        raise RuntimeError("selection and evaluation periods overlap")
    forcing, observations, dates = load_period(
        basin_id,
        training_period[0],
        validation_period[1],
        data_root=data_root,
        loader_file=loader_file,
    )
    split = int((dates < np.datetime64(validation_period[0])).sum())
    if split <= 3 or split >= len(dates) - 3:
        raise ValueError(f"invalid training-validation split for {basin_id}")
    if dates[0] < np.datetime64(training_period[0]) or dates[-1] > np.datetime64(
        validation_period[1]
    ):
        raise RuntimeError("selection loader returned dates outside the frozen selection period")
    return forcing, observations, dates, split


def _method_record(method: MethodSelection, context: Any,
                   contract: Mapping[str, Any]) -> dict[str, Any]:
    selected_theta = method.theta_history[method.selected_index]
    actual = np.exp(selected_theta)
    return {
        "selected_index": int(method.selected_index),
        "selected": {
            "theta_log": selected_theta.tolist(),
            "q_diagonal": actual[:-1].tolist(),
            "r_b": float(actual[-1]),
            "training_objective": float(method.training_objectives[method.selected_index]),
            "validation_objective": float(method.validation_objectives[method.selected_index]),
        },
        "budget_best_indices": {str(key): int(value) for key, value in method.budget_best.items()},
        "boundary": boundary_diagnostics(selected_theta, context.dimension, contract),
        "training_queries": int(method.training_queries),
        "validation_queries": int(method.validation_queries),
        "filter_passes": int(method.filter_passes),
        "gradient_updates": int(method.gradient_updates),
        "wall_seconds": float(method.wall_seconds),
    }


def _start_dispersion(method: MethodSelection, start_count: int = 8) -> dict[str, Any]:
    rows = []
    for start_index in range(start_count):
        indices = np.arange(start_index, len(method.theta_history), start_count)
        local = choose_checkpoint(
            method.theta_history[indices],
            method.training_objectives[indices],
            method.validation_objectives[indices],
        )
        index = int(indices[local])
        rows.append({
            "start_index": start_index,
            "best_global_checkpoint_index": index,
            "best_step": int(index // start_count),
            "best_training_objective": float(method.training_objectives[index]),
            "best_validation_objective": float(method.validation_objectives[index]),
            "best_actual_parameters": np.exp(method.theta_history[index]).tolist(),
        })
    values = np.asarray([row["best_validation_objective"] for row in rows])
    return {
        "starts": rows,
        "best_validation": float(values.min()),
        "worst_validation": float(values.max()),
        "absolute_spread": float(values.max() - values.min()),
        "relative_spread": float((values.max() - values.min()) / max(values.min(), 1e-12)),
    }


def _load_npz(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as archive:
        return {name: archive[name] for name in archive.files}


def _verify_cached_basin(
    basin_id: str,
    output_root: Path,
    expected_hashes: Mapping[str, str],
) -> dict[str, Any]:
    json_path = output_root / "selection" / f"basin_{basin_id}.json"
    history_path = output_root / "selection" / f"basin_{basin_id}.npz"
    input_path = output_root / "selection_inputs" / f"basin_{basin_id}.npz"
    if not (json_path.is_file() and history_path.is_file() and input_path.is_file()):
        raise RuntimeError(f"incomplete cached basin artifact set for {basin_id}")
    record = json.loads(json_path.read_text(encoding="utf-8"))
    for name, expected in expected_hashes.items():
        if record.get(name) != expected:
            raise RuntimeError(f"cached {name} mismatch for {basin_id}")
    if record.get("history_sha256") != sha256_arrays(_load_npz(history_path)):
        raise RuntimeError(f"cached history hash mismatch for {basin_id}")
    if record.get("selection_input_sha256") != sha256_arrays(_load_npz(input_path)):
        raise RuntimeError(f"cached selection input hash mismatch for {basin_id}")
    return record


def run_basin_selection(
    prior: Any,
    basin_id: str,
    output_root: Path,
    contract: Mapping[str, Any],
    *,
    data_root: Path,
    loader_file: Path,
    points: np.ndarray,
    contract_sha256: str,
    source_manifest_sha256: str,
    search_design_sha256: str,
) -> dict[str, Any]:
    output_root = Path(output_root)
    expected_hashes = {
        "contract_sha256": contract_sha256,
        "source_manifest_sha256": source_manifest_sha256,
        "search_design_sha256": search_design_sha256,
    }
    existing = [
        output_root / "selection" / f"basin_{basin_id}.json",
        output_root / "selection" / f"basin_{basin_id}.npz",
        output_root / "selection_inputs" / f"basin_{basin_id}.npz",
    ]
    if any(path.exists() for path in existing):
        return _verify_cached_basin(basin_id, output_root, expected_hashes)

    forcing, observations, dates, split = load_selection_period(
        basin_id, contract, data_root=data_root, loader_file=loader_file
    )
    context = build_basin_context(
        prior, basin_id, observations[:split], contract, data_root=data_root, device="cpu"
    )
    if points.shape != (256, context.dimension + 1):
        raise ValueError(f"search design dimension mismatch for {basin_id}")
    input_arrays = basin_input_arrays(context, forcing, observations, dates)
    input_hash = sha256_arrays(input_arrays)
    training = (forcing[:split], observations[:split])
    validation = (forcing[split:], observations[split:])
    sampling = run_sampling_search(context, training, validation, points, contract)
    backpropagation = run_backpropagation_search(
        context, training, validation, points[:8], contract
    )
    expected_budget = contract["budgets"]
    for method in (sampling, backpropagation):
        if (
            method.training_queries != expected_budget["training_queries_per_method_per_basin"]
            or method.validation_queries != expected_budget["validation_queries_per_method_per_basin"]
            or method.filter_passes != expected_budget["filter_passes_per_method_per_basin"]
        ):
            raise AssertionError("method query budget differs from the frozen contract")
    if backpropagation.gradient_updates != expected_budget["backpropagations_per_basin"]:
        raise AssertionError("backpropagation count differs from the frozen contract")

    history_arrays = {
        "sampling_theta_log": sampling.theta_history,
        "sampling_training_objective": sampling.training_objectives,
        "sampling_validation_objective": sampling.validation_objectives,
        "backpropagation_theta_log": backpropagation.theta_history,
        "backpropagation_training_objective": backpropagation.training_objectives,
        "backpropagation_validation_objective": backpropagation.validation_objectives,
        "shared_start_theta_log": backpropagation.start_theta,
    }
    history_hash = sha256_arrays(history_arrays)
    record = {
        "experiment_id": EXPERIMENT_ID,
        "basin_id": str(basin_id).zfill(8),
        "state_dimension": context.dimension,
        "training_days": split,
        "validation_days": len(dates) - split,
        "base_observation_variance": context.base_observation_variance,
        "selection_input_sha256": input_hash,
        "history_sha256": history_hash,
        **expected_hashes,
        "evaluation_period_read": False,
        "sampling_search": _method_record(sampling, context, contract),
        "backpropagation": _method_record(backpropagation, context, contract),
        "backpropagation_start_dispersion": _start_dispersion(backpropagation),
    }
    input_path = output_root / "selection_inputs" / f"basin_{basin_id}.npz"
    history_path = output_root / "selection" / f"basin_{basin_id}.npz"
    json_path = output_root / "selection" / f"basin_{basin_id}.json"
    atomic_write_npz(input_path, **input_arrays)
    atomic_write_npz(history_path, **history_arrays)
    atomic_write_json(json_path, record, refuse_different=True)
    return record


def _worker(payload: dict[str, Any]) -> dict[str, Any]:
    torch.set_default_dtype(torch.float64)
    torch.set_num_threads(1)
    prior = load_hbvlite_prior(
        csv_path=payload["prior_csv"],
        basin_list_path=payload["basin_list"],
        dtype=torch.float64,
    )
    return run_basin_selection(
        prior,
        payload["basin_id"],
        Path(payload["output_root"]),
        payload["contract"],
        data_root=Path(payload["data_root"]),
        loader_file=Path(payload["loader_file"]),
        points=np.asarray(payload["points"], dtype=np.float64),
        contract_sha256=payload["contract_sha256"],
        source_manifest_sha256=payload["source_manifest_sha256"],
        search_design_sha256=payload["search_design_sha256"],
    )


def _environment_metadata(worker_count: int, available_gib: float | None) -> dict[str, Any]:
    return {
        "python": sys.version,
        "platform": platform.platform(),
        "torch": torch.__version__,
        "numpy": np.__version__,
        "worker_count": int(worker_count),
        "mem_available_gib_at_start": available_gib,
        "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
        "hostname": platform.node(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--search-design", type=Path, default=DEFAULT_SEARCH_DESIGN)
    parser.add_argument("--data-root", type=Path, default=DEFAULT_DATA_ROOT)
    parser.add_argument("--prior-csv", type=Path, default=DEFAULT_PRIOR_CSV)
    parser.add_argument("--basin-list", type=Path, default=DEFAULT_BASIN_LIST)
    parser.add_argument("--loader-file", type=Path, default=DEFAULT_EXTERNAL_LOADER)
    parser.add_argument("--output-root", "--output", dest="output_root", type=Path,
                        default=DEFAULT_OUTPUT)
    parser.add_argument("--worker-policy", choices=("serial", "memory-gated"), default="serial")
    parser.add_argument("--workers", type=int)
    parser.add_argument("--basins", nargs="*")
    args = parser.parse_args()

    torch.set_default_dtype(torch.float64)
    contract = load_contract(args.config)
    selected_basins = contract["basins"] if not args.basins else [str(x).zfill(8) for x in args.basins]
    if not selected_basins or any(basin not in contract["basins"] for basin in selected_basins):
        raise ValueError("requested basin list is empty or outside the frozen set")
    output_root = args.output_root.resolve()
    if (output_root / "evaluation_summary.json").exists():
        raise FileExistsError("final evaluation exists; selection cannot be changed")
    output_root.mkdir(parents=True, exist_ok=True)

    seal_path = output_root / "selection.sealed.json"
    if seal_path.exists():
        manifest_path = output_root / "selection_manifest.sha256.json"
        if not manifest_path.is_file():
            raise RuntimeError("selection seal exists without its manifest")
        seal = json.loads(seal_path.read_text(encoding="utf-8"))
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if (
            seal.get("status") != "SELECTED_SEALED"
            or seal.get("selection_manifest_sha256") != sha256_file(manifest_path)
            or manifest.get("contract_sha256") != sha256_file(args.config)
            or manifest.get("search_design_sha256") != sha256_file(args.search_design)
        ):
            raise RuntimeError("existing selection seal does not match the requested run")
        current_sources = source_hashes(contract)
        recorded_sources = json.loads(
            (output_root / "source_manifest.json").read_text(encoding="utf-8")
        )
        if current_sources != recorded_sources:
            raise RuntimeError("source hashes differ from the existing selection seal")
        for relative, expected in manifest.get("files", {}).items():
            path = output_root / relative
            if not path.is_file() or sha256_file(path) != expected:
                raise RuntimeError(f"sealed selection member mismatch: {relative}")
        print(f"SELECTION_ALREADY_SEALED output={output_root}", flush=True)
        return

    config_bytes = args.config.read_bytes()
    config_snapshot = output_root / "config.snapshot.json"
    atomic_write_bytes(config_snapshot, config_bytes, refuse_different=True)
    contract_hash = sha256_file(args.config)
    design_hash = sha256_file(args.search_design)
    metadata_path = args.search_design.with_suffix(".sha256.json")
    design_metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    if design_metadata["file_sha256"] != design_hash:
        raise RuntimeError("search design file hash differs from frozen metadata")
    hashes = source_hashes(contract)
    source_manifest_path = output_root / "source_manifest.json"
    atomic_write_json(source_manifest_path, hashes, refuse_different=True)
    source_manifest_hash = sha256_file(source_manifest_path)
    designs = load_search_design(args.search_design)

    if args.workers is not None:
        if args.workers < 1:
            raise ValueError("worker count must be positive")
        workers = int(args.workers)
        available_gib = None
    elif args.worker_policy == "memory-gated":
        available_gib = mem_available_gib()
        workers = worker_count_from_available_gib(available_gib)
    else:
        available_gib = None
        workers = 1
    workers = min(workers, len(selected_basins))
    payloads = [
        {
            "basin_id": basin_id,
            "output_root": str(output_root),
            "contract": contract,
            "data_root": str(args.data_root.resolve()),
            "loader_file": str(args.loader_file.resolve()),
            "prior_csv": str(args.prior_csv.resolve()),
            "basin_list": str(args.basin_list.resolve()),
            "points": designs[int(contract["expected_state_dimensions"][basin_id])],
            "contract_sha256": contract_hash,
            "source_manifest_sha256": source_manifest_hash,
            "search_design_sha256": design_hash,
        }
        for basin_id in selected_basins
    ]
    records: dict[str, dict[str, Any]] = {}
    failures: list[dict[str, str]] = []
    started = time.perf_counter()
    if workers == 1:
        prior = load_hbvlite_prior(
            csv_path=args.prior_csv, basin_list_path=args.basin_list, dtype=torch.float64
        )
        for payload in payloads:
            try:
                record = run_basin_selection(
                    prior,
                    payload["basin_id"],
                    output_root,
                    contract,
                    data_root=args.data_root,
                    loader_file=args.loader_file,
                    points=payload["points"],
                    contract_sha256=contract_hash,
                    source_manifest_sha256=source_manifest_hash,
                    search_design_sha256=design_hash,
                )
                records[record["basin_id"]] = record
                print(f"{record['basin_id']}: selected", flush=True)
            except Exception as error:
                traceback.print_exc()
                failures.append({
                    "basin_id": payload["basin_id"],
                    "error_type": type(error).__name__,
                    "error_message": str(error)[:1000],
                })
                break
    else:
        with ProcessPoolExecutor(max_workers=workers) as executor:
            future_map = {executor.submit(_worker, payload): payload["basin_id"] for payload in payloads}
            for future in as_completed(future_map):
                basin_id = future_map[future]
                try:
                    record = future.result()
                    records[record["basin_id"]] = record
                    print(f"{record['basin_id']}: selected", flush=True)
                except Exception as error:
                    failures.append({
                        "basin_id": basin_id,
                        "error_type": type(error).__name__,
                        "error_message": str(error)[:1000],
                    })
                    traceback.print_exc()

    ordered = [records[basin] for basin in selected_basins if basin in records]
    complete = len(ordered) == len(selected_basins) and not failures
    full_contract_complete = complete and selected_basins == contract["basins"]
    summary = {
        "experiment_id": EXPERIMENT_ID,
        "status": "SELECTION_COMPLETE" if full_contract_complete else (
            "PARTIAL_SELECTION_COMPLETE" if complete else "FAILED_SELECTION"
        ),
        "requested_basin_count": len(selected_basins),
        "basin_count": len(ordered),
        "evaluation_period_read": False,
        "failures": failures,
        "wall_seconds": time.perf_counter() - started,
        "environment": _environment_metadata(workers, available_gib),
        "basins": ordered,
    }
    atomic_write_json(output_root / "selection_summary.json", summary)
    if not complete:
        raise RuntimeError(f"selection failed after {len(ordered)} basins")
    if not full_contract_complete:
        print(f"PARTIAL_SELECTION_COMPLETE basins={len(ordered)}", flush=True)
        return

    files = [
        output_root / "selection_summary.json",
        config_snapshot,
        source_manifest_path,
    ]
    for basin_id in contract["basins"]:
        files.extend([
            output_root / "selection" / f"basin_{basin_id}.json",
            output_root / "selection" / f"basin_{basin_id}.npz",
            output_root / "selection_inputs" / f"basin_{basin_id}.npz",
        ])
    manifest = {
        "experiment_id": EXPERIMENT_ID,
        "status": "SELECTION_COMPLETE",
        "contract_sha256": contract_hash,
        "source_manifest_sha256": source_manifest_hash,
        "search_design_sha256": design_hash,
        "evaluation_period_read": False,
        "files": {
            str(path.relative_to(output_root)).replace("\\", "/"): sha256_file(path)
            for path in files
        },
    }
    manifest_path = output_root / "selection_manifest.sha256.json"
    atomic_write_json(manifest_path, manifest, refuse_different=True)
    seal = {
        "experiment_id": EXPERIMENT_ID,
        "status": "SELECTED_SEALED",
        "basin_count": 21,
        "selection_manifest_sha256": sha256_file(manifest_path),
        "evaluation_period_read": False,
    }
    atomic_write_json(output_root / "selection.sealed.json", seal, refuse_different=True)
    print(f"SELECTION_SEALED basins=21 output={output_root}", flush=True)


if __name__ == "__main__":
    main()
