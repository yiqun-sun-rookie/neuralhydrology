"""Freeze the deterministic full-dimensional candidate design for TUKF06."""
from __future__ import annotations

from hashlib import sha256
from io import BytesIO
from pathlib import Path
import argparse
import json
import os
import zipfile

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT = ROOT / "configs" / "tukf06_search_design_v1.npz"
STATE_DIMENSIONS = (7, 11, 18)
PROCESS_LOWER = 1e-5
PROCESS_UPPER = 0.1
OBSERVATION_LOWER = 0.0025
OBSERVATION_UPPER = 0.32


def log_bounds(state_dimension: int) -> tuple[np.ndarray, np.ndarray]:
    if int(state_dimension) < 5:
        raise ValueError("state dimension must include five storage states")
    lower = np.log(np.asarray(
        [PROCESS_LOWER] * int(state_dimension) + [OBSERVATION_LOWER],
        dtype=np.float64,
    ))
    upper = np.log(np.asarray(
        [PROCESS_UPPER] * int(state_dimension) + [OBSERVATION_UPPER],
        dtype=np.float64,
    ))
    return lower, upper


def build_anchor_points(state_dimension: int) -> np.ndarray:
    dimension = int(state_dimension)
    if dimension < 5:
        raise ValueError("state dimension must include five storage states")
    midpoint_r = float(np.sqrt(OBSERVATION_LOWER * OBSERVATION_UPPER))
    actual = np.empty((8, dimension + 1), dtype=np.float64)
    actual[0] = [0.001] * dimension + [0.02]
    actual[1] = [PROCESS_LOWER] * dimension + [OBSERVATION_LOWER]
    actual[2] = [PROCESS_UPPER] * dimension + [OBSERVATION_UPPER]
    actual[3] = [PROCESS_LOWER] * dimension + [OBSERVATION_UPPER]
    actual[4] = [PROCESS_UPPER] * dimension + [OBSERVATION_LOWER]
    actual[5] = [PROCESS_UPPER] * 5 + [PROCESS_LOWER] * (dimension - 5) + [midpoint_r]
    actual[6] = [PROCESS_LOWER] * 5 + [PROCESS_UPPER] * (dimension - 5) + [midpoint_r]
    actual[7] = [np.sqrt(PROCESS_LOWER * PROCESS_UPPER)] * dimension + [midpoint_r]
    return np.log(actual)


def _semantic_sha256(arrays: dict[str, np.ndarray]) -> str:
    digest = sha256()
    for name in sorted(arrays):
        array = np.ascontiguousarray(arrays[name], dtype=np.float64)
        digest.update(name.encode("utf-8"))
        digest.update(str(array.dtype).encode("ascii"))
        digest.update(np.asarray(array.shape, dtype=np.int64).tobytes())
        digest.update(array.tobytes())
    return digest.hexdigest()


def _deterministic_npz_bytes(arrays: dict[str, np.ndarray]) -> bytes:
    destination = BytesIO()
    with zipfile.ZipFile(
        destination, mode="w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as archive:
        for name in sorted(arrays):
            member = BytesIO()
            np.lib.format.write_array(
                member, np.ascontiguousarray(arrays[name]), allow_pickle=False
            )
            info = zipfile.ZipInfo(f"{name}.npy", date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 0
            info.external_attr = 0
            archive.writestr(info, member.getvalue(), compress_type=zipfile.ZIP_DEFLATED,
                             compresslevel=9)
    return destination.getvalue()


def _atomic_write_immutable(path: Path, content: bytes) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != content:
            raise RuntimeError(f"refusing to replace different frozen file: {path}")
        return
    temporary = path.with_name(path.name + f".tmp-{os.getpid()}")
    temporary.write_bytes(content)
    os.replace(temporary, path)


def freeze_search_design(output: Path, seed: int = 20260809) -> dict:
    arrays: dict[str, np.ndarray] = {}
    for state_dimension in STATE_DIMENSIONS:
        total_dimension = state_dimension + 1
        anchors = build_anchor_points(state_dimension)
        engine = torch.quasirandom.SobolEngine(
            dimension=total_dimension,
            scramble=True,
            seed=int(seed) + total_dimension,
        )
        unit_points = engine.draw(248).cpu().numpy().astype(np.float64)
        lower, upper = log_bounds(state_dimension)
        sobol = lower + unit_points * (upper - lower)
        points = np.concatenate([anchors, sobol], axis=0)
        if points.shape != (256, total_dimension):
            raise AssertionError(points.shape)
        if len(np.unique(points, axis=0)) != 256:
            raise ValueError("duplicate search points")
        if not np.isfinite(points).all() or np.any(points < lower) or np.any(points > upper):
            raise ValueError("search design is outside the frozen finite bounds")
        arrays[f"state_dim_{state_dimension}"] = points

    payload = _deterministic_npz_bytes(arrays)
    output = Path(output)
    _atomic_write_immutable(output, payload)
    metadata = {
        "experiment_id": "TUKF06_FULL_DIAGONAL_SEARCH_HEAD_TO_HEAD_V1",
        "seed": int(seed),
        "generator": "torch.quasirandom.SobolEngine(scramble=True)",
        "anchor_count": 8,
        "sobol_count": 248,
        "arrays": {
            name: {"shape": list(array.shape), "dtype": str(array.dtype)}
            for name, array in sorted(arrays.items())
        },
        "semantic_sha256": _semantic_sha256(arrays),
        "file_sha256": sha256(payload).hexdigest(),
    }
    metadata_bytes = (
        json.dumps(metadata, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    ).encode("utf-8")
    _atomic_write_immutable(output.with_suffix(".sha256.json"), metadata_bytes)
    return metadata


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--seed", type=int, default=20260809)
    args = parser.parse_args()
    metadata = freeze_search_design(args.output, args.seed)
    print(json.dumps(metadata, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
