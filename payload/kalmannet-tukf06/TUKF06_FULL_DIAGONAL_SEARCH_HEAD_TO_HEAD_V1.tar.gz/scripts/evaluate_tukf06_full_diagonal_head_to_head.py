"""One-shot reused-historical evaluation for the sealed TUKF06 selection."""
from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
import argparse
import json
import math
import os
import platform
import sys
import time
import traceback
from typing import Any, Mapping

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
for _extra in (str(ROOT), str(ROOT / "src")):
    if _extra not in sys.path:
        sys.path.insert(0, _extra)

from scripts.tukf06_full_diagonal_common import (  # noqa: E402
    DEFAULT_BASIN_LIST,
    DEFAULT_CONFIG,
    DEFAULT_DATA_ROOT,
    DEFAULT_EXTERNAL_LOADER,
    DEFAULT_OUTPUT,
    DEFAULT_PRIOR_CSV,
    EXPERIMENT_ID,
    LEADS,
    atomic_write_json,
    atomic_write_npz,
    basin_input_arrays,
    build_basin_context,
    common_finite_mask,
    filter_forecasts,
    load_contract,
    load_period,
    mem_available_gib,
    nse_population,
    open_loop_prediction,
    persistence_predictions,
    practical_equivalence_decision,
    second_order_autoregression_predictions,
    sha256_arrays,
    sha256_file,
    source_hashes,
    worker_count_from_available_gib,
)
from global_hydrology.data.hbvlite_prior import load_hbvlite_prior  # noqa: E402


SYSTEM_NAMES = (
    "same_forcing_open_loop",
    "default_noise_filter",
    "sampling_search_filter",
    "backpropagation_filter",
    "persistence",
    "second_order_autoregression",
)
FILTER_METHODS = (
    "default_noise_filter",
    "sampling_search_filter",
    "backpropagation_filter",
)


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _load_npz(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as archive:
        return {name: archive[name] for name in archive.files}


def verify_selection_seal(
    output_root: Path,
    contract: Mapping[str, Any],
    config_path: Path,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, dict[str, Any]]]:
    output_root = Path(output_root)
    seal_path = output_root / "selection.sealed.json"
    manifest_path = output_root / "selection_manifest.sha256.json"
    summary_path = output_root / "selection_summary.json"
    for path in (seal_path, manifest_path, summary_path, output_root / "source_manifest.json"):
        if not path.is_file():
            raise FileNotFoundError(f"sealed selection artifact is missing: {path}")
    seal = _read_json(seal_path)
    manifest = _read_json(manifest_path)
    summary = _read_json(summary_path)
    if seal != {
        "basin_count": 21,
        "evaluation_period_read": False,
        "experiment_id": EXPERIMENT_ID,
        "selection_manifest_sha256": sha256_file(manifest_path),
        "status": "SELECTED_SEALED",
    }:
        raise RuntimeError("selection seal is invalid or no longer matches the manifest")
    if summary.get("status") != "SELECTION_COMPLETE" or summary.get("basin_count") != 21:
        raise RuntimeError("selection summary is incomplete")
    if summary.get("evaluation_period_read") is not False:
        raise RuntimeError("selection reports evaluation-period access")
    if manifest.get("experiment_id") != EXPERIMENT_ID or manifest.get("status") != "SELECTION_COMPLETE":
        raise RuntimeError("selection manifest identity or status is invalid")
    if manifest.get("contract_sha256") != sha256_file(config_path):
        raise RuntimeError("selection contract hash differs from the requested configuration")
    if sha256_file(output_root / "config.snapshot.json") != sha256_file(config_path):
        raise RuntimeError("selection configuration snapshot mismatch")
    current_source = source_hashes(contract)
    recorded_source = _read_json(output_root / "source_manifest.json")
    if current_source != recorded_source:
        raise RuntimeError("current source hashes differ from the sealed selection")
    if manifest.get("source_manifest_sha256") != sha256_file(output_root / "source_manifest.json"):
        raise RuntimeError("selection source-manifest hash mismatch")
    for relative, expected in manifest.get("files", {}).items():
        path = output_root / relative
        if not path.is_file() or sha256_file(path) != expected:
            raise RuntimeError(f"sealed selection member mismatch: {relative}")
    selections = {
        basin_id: _read_json(output_root / "selection" / f"basin_{basin_id}.json")
        for basin_id in contract["basins"]
    }
    if any(row.get("evaluation_period_read") is not False for row in selections.values()):
        raise RuntimeError("a basin selection reports evaluation-period access")
    return seal, manifest, selections


def _validate_context_against_selection_input(context: Any, arrays: Mapping[str, np.ndarray]) -> None:
    comparisons = {
        "parameters": context.parameters.detach().cpu().numpy(),
        "initial_storage_state": context.initial_storage_state.detach().cpu().numpy(),
        "initial_state": context.initial_state.detach().cpu().numpy(),
        "initial_covariance": context.initial_covariance.detach().cpu().numpy(),
        "base_observation_variance": np.asarray(
            [context.base_observation_variance], dtype=np.float64
        ),
        "state_dimension": np.asarray([context.dimension], dtype=np.int64),
    }
    for name, current in comparisons.items():
        if name not in arrays or not np.array_equal(np.asarray(arrays[name]), current):
            raise RuntimeError(f"evaluation context differs from selection input: {name}")


def _evaluation_theta(selection: Mapping[str, Any], method: str) -> np.ndarray:
    theta = np.asarray(selection[method]["selected"]["theta_log"], dtype=np.float64)
    if not np.isfinite(theta).all():
        raise FloatingPointError(f"selected {method} theta is non-finite")
    return theta


def score_basin(
    prior: Any,
    basin_id: str,
    selection: Mapping[str, Any],
    output_root: Path,
    contract: Mapping[str, Any],
    *,
    data_root: Path,
    loader_file: Path,
) -> dict[str, Any]:
    output_root = Path(output_root)
    record_path = output_root / "evaluation" / f"basin_{basin_id}.json"
    archive_path = output_root / "evaluation" / f"basin_{basin_id}.npz"
    cached_record = None
    if record_path.exists() or archive_path.exists():
        if not (record_path.is_file() and archive_path.is_file()):
            raise RuntimeError(f"incomplete cached evaluation artifacts for {basin_id}")
        record = _read_json(record_path)
        arrays = _load_npz(archive_path)
        if record.get("archive_sha256") != sha256_arrays(arrays):
            raise RuntimeError(f"cached evaluation hash mismatch for {basin_id}")
        if record.get("selection_input_sha256") != selection["selection_input_sha256"]:
            raise RuntimeError(f"cached evaluation selection-input mismatch for {basin_id}")
        cached_record = record

    selection_input_path = output_root / "selection_inputs" / f"basin_{basin_id}.npz"
    selection_input = _load_npz(selection_input_path)
    if sha256_arrays(selection_input) != selection["selection_input_sha256"]:
        raise RuntimeError(f"selection input hash mismatch for {basin_id}")
    training_days = int(selection["training_days"])
    training_observations = torch.tensor(
        selection_input["observations"][:training_days], dtype=torch.float64
    ).unsqueeze(1)
    context = build_basin_context(
        prior, basin_id, training_observations, contract, data_root=data_root, device="cpu"
    )
    _validate_context_against_selection_input(context, selection_input)

    evaluation_period = contract["periods"]["evaluation"]
    forcing, observations, dates = load_period(
        basin_id,
        evaluation_period[0],
        evaluation_period[1],
        data_root=data_root,
        loader_file=loader_file,
    )
    target = observations[:, 0].detach().cpu().numpy()
    input_arrays = basin_input_arrays(context, forcing, observations, dates)
    evaluation_input_hash = sha256_arrays(input_arrays)
    if cached_record is not None:
        if cached_record.get("evaluation_input_sha256") != evaluation_input_hash:
            raise RuntimeError(f"cached evaluation current-input mismatch for {basin_id}")
        return cached_record

    sampling_theta = _evaluation_theta(selection, "sampling_search")
    backpropagation_theta = _evaluation_theta(selection, "backpropagation")
    default_actual = np.asarray(
        [float(contract["evaluation"]["default_process_diagonal"])] * context.dimension
        + [float(contract["evaluation"]["default_r_b"])],
        dtype=np.float64,
    )
    default_theta = np.log(default_actual)
    default_forecasts = filter_forecasts(
        context, forcing, observations, default_theta, contract
    )
    sampling_forecasts = filter_forecasts(
        context, forcing, observations, sampling_theta, contract
    )
    backpropagation_forecasts = filter_forecasts(
        context, forcing, observations, backpropagation_theta, contract
    )
    open_loop = open_loop_prediction(context, forcing)
    persistence = persistence_predictions(target)
    autoregression = second_order_autoregression_predictions(
        selection_input["observations"][:training_days], target
    )

    scores = {name: {} for name in SYSTEM_NAMES}
    common_counts: dict[str, int] = {}
    archive_arrays: dict[str, np.ndarray] = {
        "dates_ns": dates.astype("datetime64[ns]").astype(np.int64),
        "target": target,
        "forcing": forcing[:, 0, :].detach().cpu().numpy(),
    }
    warmup = int(contract["evaluation"]["warmup_days_excluded"])
    for lead in LEADS:
        predictions = {
            "same_forcing_open_loop": open_loop,
            "default_noise_filter": default_forecasts[lead],
            "sampling_search_filter": sampling_forecasts[lead],
            "backpropagation_filter": backpropagation_forecasts[lead],
            "persistence": persistence[lead],
            "second_order_autoregression": autoregression[lead],
        }
        mask = common_finite_mask(target, predictions, warmup)
        common_counts[str(lead)] = int(mask.sum())
        archive_arrays[f"common_mask_lead_{lead}"] = mask
        for name, prediction in predictions.items():
            scores[name][str(lead)] = nse_population(prediction, target, mask)
            archive_arrays[f"{name}_lead_{lead}"] = np.asarray(
                prediction, dtype=np.float64
            )
    if not all(np.isfinite(value) for rows in scores.values() for value in rows.values()):
        raise FloatingPointError(f"non-finite evaluation score for {basin_id}")
    gains = {
        method: {
            str(lead): scores[method][str(lead)]
            - scores["same_forcing_open_loop"][str(lead)]
            for lead in LEADS
        }
        for method in FILTER_METHODS
    }
    paired = {
        str(lead): gains["backpropagation_filter"][str(lead)]
        - gains["sampling_search_filter"][str(lead)]
        for lead in LEADS
    }
    archive_hash = sha256_arrays(archive_arrays)
    record = {
        "experiment_id": EXPERIMENT_ID,
        "basin_id": basin_id,
        "evaluation_role": contract["periods"]["evaluation_role"],
        "selection_input_sha256": selection["selection_input_sha256"],
        "evaluation_input_sha256": evaluation_input_hash,
        "archive_sha256": archive_hash,
        "common_count_by_lead": common_counts,
        "nse_by_system_and_lead": scores,
        "gain_vs_same_forcing_open_loop": gains,
        "paired_backpropagation_minus_sampling_by_lead": paired,
        "paired_backpropagation_minus_sampling_mean": float(
            np.mean([paired[str(lead)] for lead in LEADS])
        ),
    }
    atomic_write_npz(archive_path, **archive_arrays)
    atomic_write_json(record_path, record, refuse_different=True)
    return record


def _bootstrap_median_interval(values: np.ndarray, contract: Mapping[str, Any]) -> list[float]:
    array = np.asarray(values, dtype=np.float64)
    rng = np.random.default_rng(int(contract["bootstrap"]["seed"]))
    count = int(contract["bootstrap"]["paired_resamples"])
    indices = rng.integers(0, len(array), size=(count, len(array)))
    medians = np.median(array[indices], axis=1)
    interval = float(contract["bootstrap"]["interval"])
    alpha = (1.0 - interval) / 2.0
    return [float(np.quantile(medians, alpha)), float(np.quantile(medians, 1.0 - alpha))]


def _finite_correlation(x: np.ndarray, y: np.ndarray) -> float | None:
    x_array = np.asarray(x, dtype=np.float64)
    y_array = np.asarray(y, dtype=np.float64)
    if len(x_array) < 2 or np.std(x_array) == 0.0 or np.std(y_array) == 0.0:
        return None
    value = float(np.corrcoef(x_array, y_array)[0, 1])
    return value if math.isfinite(value) else None


def summarize(
    results: list[dict[str, Any]],
    selections: Mapping[str, Mapping[str, Any]],
    contract: Mapping[str, Any],
) -> dict[str, Any]:
    if [row["basin_id"] for row in results] != contract["basins"]:
        raise ValueError("evaluation results are not in the frozen 21-basin order")
    system_median_nse = {name: {} for name in SYSTEM_NAMES}
    median_gain = {method: {} for method in FILTER_METHODS}
    negative_gain_count = {method: {} for method in FILTER_METHODS}
    catastrophic_lead1 = {}
    wins_over_persistence = {method: {} for method in FILTER_METHODS}
    wins_over_autoregression = {method: {} for method in FILTER_METHODS}
    for lead in LEADS:
        key = str(lead)
        for name in SYSTEM_NAMES:
            system_median_nse[name][key] = float(np.median([
                row["nse_by_system_and_lead"][name][key] for row in results
            ]))
        for method in FILTER_METHODS:
            gains = np.asarray([
                row["gain_vs_same_forcing_open_loop"][method][key] for row in results
            ])
            median_gain[method][key] = float(np.median(gains))
            negative_gain_count[method][key] = int(np.sum(gains < 0.0))
            wins_over_persistence[method][key] = int(sum(
                row["nse_by_system_and_lead"][method][key]
                > row["nse_by_system_and_lead"]["persistence"][key]
                for row in results
            ))
            wins_over_autoregression[method][key] = int(sum(
                row["nse_by_system_and_lead"][method][key]
                > row["nse_by_system_and_lead"]["second_order_autoregression"][key]
                for row in results
            ))
    for method in FILTER_METHODS:
        catastrophic_lead1[method] = int(sum(
            row["gain_vs_same_forcing_open_loop"][method]["1"] < -0.10
            for row in results
        ))

    paired_rows = [{
        "basin_id": row["basin_id"],
        "by_lead": row["paired_backpropagation_minus_sampling_by_lead"],
        "mean_three_leads": row["paired_backpropagation_minus_sampling_mean"],
    } for row in results]
    paired_mean = np.asarray([row["mean_three_leads"] for row in paired_rows])
    paired_aggregate = float(np.median(paired_mean))
    paired_median_by_lead = {
        str(lead): float(np.median([
            row["paired_backpropagation_minus_sampling_by_lead"][str(lead)]
            for row in results
        ]))
        for lead in LEADS
    }
    tolerance = float(contract["practical_equivalence"]["tolerance"])

    validation_advantage = np.asarray([
        (
            selections[row["basin_id"]]["sampling_search"]["selected"]["validation_objective"]
            - selections[row["basin_id"]]["backpropagation"]["selected"]["validation_objective"]
        )
        / max(
            selections[row["basin_id"]]["sampling_search"]["selected"]["validation_objective"],
            1e-12,
        )
        for row in results
    ], dtype=np.float64)
    sign_agreement = int(np.sum(
        np.sign(validation_advantage) == np.sign(paired_mean)
    ))
    boundary = {
        method: {
            "exact_any_basin_count": int(sum(
                selections[row["basin_id"]][method]["boundary"]["exact_any"]
                for row in results
            )),
            "outer_five_percent_any_basin_count": int(sum(
                selections[row["basin_id"]][method]["boundary"]["outer_five_percent_any"]
                for row in results
            )),
        }
        for method in ("sampling_search", "backpropagation")
    }
    cost = {
        method: {
            "training_queries": int(sum(
                selections[row["basin_id"]][method]["training_queries"] for row in results
            )),
            "validation_queries": int(sum(
                selections[row["basin_id"]][method]["validation_queries"] for row in results
            )),
            "filter_passes": int(sum(
                selections[row["basin_id"]][method]["filter_passes"] for row in results
            )),
            "gradient_updates": int(sum(
                selections[row["basin_id"]][method]["gradient_updates"] for row in results
            )),
            "basin_wall_seconds_sum": float(sum(
                selections[row["basin_id"]][method]["wall_seconds"] for row in results
            )),
        }
        for method in ("sampling_search", "backpropagation")
    }
    start_spreads = np.asarray([
        selections[row["basin_id"]]["backpropagation_start_dispersion"]["relative_spread"]
        for row in results
    ], dtype=np.float64)
    selected_actual = {
        method: {
            "q_min": float(min(
                min(selections[row["basin_id"]][method]["selected"]["q_diagonal"])
                for row in results
            )),
            "q_max": float(max(
                max(selections[row["basin_id"]][method]["selected"]["q_diagonal"])
                for row in results
            )),
            "r_b_min": float(min(
                selections[row["basin_id"]][method]["selected"]["r_b"]
                for row in results
            )),
            "r_b_max": float(max(
                selections[row["basin_id"]][method]["selected"]["r_b"]
                for row in results
            )),
        }
        for method in ("sampling_search", "backpropagation")
    }
    return {
        "experiment_id": EXPERIMENT_ID,
        "status": "EVALUATION_COMPLETE",
        "evaluation_role": contract["periods"]["evaluation_role"],
        "basin_count": len(results),
        "median_whole_system_nse": system_median_nse,
        "median_filter_gain_vs_same_forcing_open_loop": median_gain,
        "negative_gain_basin_count": negative_gain_count,
        "catastrophic_lead1_basin_count": catastrophic_lead1,
        "wins_over_persistence_basin_count": wins_over_persistence,
        "wins_over_second_order_autoregression_basin_count": wins_over_autoregression,
        "paired_backpropagation_minus_sampling": {
            "per_basin": paired_rows,
            "median_by_lead": paired_median_by_lead,
            "median_of_three_lead_basin_means": paired_aggregate,
            "bootstrap_95_percent_interval": _bootstrap_median_interval(paired_mean, contract),
            "practical_equivalence_tolerance": tolerance,
            "verdict": practical_equivalence_decision(paired_aggregate, tolerance),
        },
        "validation_to_evaluation": {
            "median_relative_validation_objective_advantage_backpropagation": float(
                np.median(validation_advantage)
            ),
            "median_evaluation_nse_advantage_backpropagation": paired_aggregate,
            "pearson_correlation": _finite_correlation(validation_advantage, paired_mean),
            "same_sign_basin_count": sign_agreement,
            "basin_count": len(results),
        },
        "selected_parameter_boundary": boundary,
        "selected_parameter_ranges": selected_actual,
        "backpropagation_start_stability": {
            "median_relative_best_validation_spread": float(np.median(start_spreads)),
            "maximum_relative_best_validation_spread": float(np.max(start_spreads)),
        },
        "selection_computational_cost": cost,
        "basins": results,
        "interpretation_limits": [
            "The 1989-10-01 to 1999-09-30 interval is a reused historical benchmark, not an untouched confirmation period.",
            "Observed future precipitation and meteorology are supplied to every hydrological forecast.",
            "Persistence and autoregression comparisons describe the whole perfect-forcing forecast systems; optimizer comparison is only the paired sampling-versus-backpropagation result.",
        ],
    }


def _worker(payload: dict[str, Any]) -> dict[str, Any]:
    torch.set_default_dtype(torch.float64)
    torch.set_num_threads(1)
    prior = load_hbvlite_prior(
        csv_path=payload["prior_csv"],
        basin_list_path=payload["basin_list"],
        dtype=torch.float64,
    )
    return score_basin(
        prior,
        payload["basin_id"],
        payload["selection"],
        Path(payload["output_root"]),
        payload["contract"],
        data_root=Path(payload["data_root"]),
        loader_file=Path(payload["loader_file"]),
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--data-root", type=Path, default=DEFAULT_DATA_ROOT)
    parser.add_argument("--prior-csv", type=Path, default=DEFAULT_PRIOR_CSV)
    parser.add_argument("--basin-list", type=Path, default=DEFAULT_BASIN_LIST)
    parser.add_argument("--loader-file", type=Path, default=DEFAULT_EXTERNAL_LOADER)
    parser.add_argument("--output-root", "--output", dest="output_root", type=Path,
                        default=DEFAULT_OUTPUT)
    parser.add_argument("--worker-policy", choices=("serial", "memory-gated"), default="serial")
    parser.add_argument("--workers", type=int)
    args = parser.parse_args()

    torch.set_default_dtype(torch.float64)
    contract = load_contract(args.config)
    output_root = args.output_root.resolve()
    final_summary_path = output_root / "evaluation_summary.json"
    if final_summary_path.exists():
        raise FileExistsError("final evaluation already exists and is immutable")
    seal, selection_manifest, selections = verify_selection_seal(
        output_root, contract, args.config
    )
    del seal
    if args.workers is not None:
        if args.workers < 1:
            raise ValueError("worker count must be positive")
        workers = min(int(args.workers), 21)
        available_gib = None
    elif args.worker_policy == "memory-gated":
        available_gib = mem_available_gib()
        workers = worker_count_from_available_gib(available_gib)
    else:
        workers = 1
        available_gib = None
    payloads = [{
        "basin_id": basin_id,
        "selection": selections[basin_id],
        "output_root": str(output_root),
        "contract": contract,
        "data_root": str(args.data_root.resolve()),
        "loader_file": str(args.loader_file.resolve()),
        "prior_csv": str(args.prior_csv.resolve()),
        "basin_list": str(args.basin_list.resolve()),
    } for basin_id in contract["basins"]]
    records: dict[str, dict[str, Any]] = {}
    failures: list[dict[str, str]] = []
    started = time.perf_counter()
    if workers == 1:
        prior = load_hbvlite_prior(
            csv_path=args.prior_csv, basin_list_path=args.basin_list, dtype=torch.float64
        )
        for payload in payloads:
            try:
                record = score_basin(
                    prior,
                    payload["basin_id"],
                    payload["selection"],
                    output_root,
                    contract,
                    data_root=args.data_root,
                    loader_file=args.loader_file,
                )
                records[record["basin_id"]] = record
                print(f"{record['basin_id']}: evaluated", flush=True)
            except Exception as error:
                traceback.print_exc()
                failures.append({
                    "basin_id": payload["basin_id"],
                    "error_type": type(error).__name__,
                    "error_message": str(error)[:1000],
                })
                break
    else:
        with ProcessPoolExecutor(max_workers=workers) as executor:
            future_map = {executor.submit(_worker, payload): payload["basin_id"] for payload in payloads}
            for future in as_completed(future_map):
                basin_id = future_map[future]
                try:
                    record = future.result()
                    records[record["basin_id"]] = record
                    print(f"{record['basin_id']}: evaluated", flush=True)
                except Exception as error:
                    traceback.print_exc()
                    failures.append({
                        "basin_id": basin_id,
                        "error_type": type(error).__name__,
                        "error_message": str(error)[:1000],
                    })
    if failures or len(records) != 21:
        atomic_write_json(output_root / "evaluation_failed.json", {
            "experiment_id": EXPERIMENT_ID,
            "failures": failures,
            "completed_basin_count": len(records),
        })
        raise RuntimeError(f"evaluation failed after {len(records)} basins")
    ordered = [records[basin_id] for basin_id in contract["basins"]]
    summary = summarize(ordered, selections, contract)
    summary["wall_seconds"] = time.perf_counter() - started
    summary["execution"] = {
        "worker_count": workers,
        "mem_available_gib_at_start": available_gib,
        "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
        "hostname": platform.node(),
    }
    summary["selection_manifest_sha256"] = sha256_file(
        output_root / "selection_manifest.sha256.json"
    )
    atomic_write_json(final_summary_path, summary, refuse_different=True)
    files = [final_summary_path]
    for basin_id in contract["basins"]:
        files.extend([
            output_root / "evaluation" / f"basin_{basin_id}.json",
            output_root / "evaluation" / f"basin_{basin_id}.npz",
        ])
    manifest = {
        "experiment_id": EXPERIMENT_ID,
        "status": "EVALUATION_COMPLETE",
        "evaluation_role": contract["periods"]["evaluation_role"],
        "selection_manifest_sha256": sha256_file(
            output_root / "selection_manifest.sha256.json"
        ),
        "source_sha256": source_hashes(contract),
        "files": {
            str(path.relative_to(output_root)).replace("\\", "/"): sha256_file(path)
            for path in files
        },
    }
    atomic_write_json(
        output_root / "evaluation_manifest.sha256.json", manifest, refuse_different=True
    )
    print(
        f"EVALUATION_COMPLETE verdict={summary['paired_backpropagation_minus_sampling']['verdict']} "
        f"paired_median={summary['paired_backpropagation_minus_sampling']['median_of_three_lead_basin_means']:+.6f}",
        flush=True,
    )


if __name__ == "__main__":
    main()
