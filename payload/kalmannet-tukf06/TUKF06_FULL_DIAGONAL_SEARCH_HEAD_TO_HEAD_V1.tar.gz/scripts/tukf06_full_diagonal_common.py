"""Portable, contract-frozen primitives for the TUKF06 comparison."""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from hashlib import sha256
from pathlib import Path
import importlib.util
import json
import math
import os
import sys
from typing import Any, Mapping, Sequence

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
for _extra in (str(ROOT), str(ROOT / "src")):
    if _extra not in sys.path:
        sys.path.insert(0, _extra)

from scripts.differentiable_ukf_hbvlite import run_hbvlite_corrected_ukf  # noqa: E402
from global_hydrology.models.differentiable_hbv_lite import (  # noqa: E402
    PARAM_NAMES,
    recession_half_weights,
)
from global_hydrology.models.hbvlite_system_model import HBVLiteSystemModel  # noqa: E402
from global_hydrology.models.hbvlite_ukf_adapter import RoutedHBVLiteUKFAdapter  # noqa: E402


EXPERIMENT_ID = "TUKF06_FULL_DIAGONAL_SEARCH_HEAD_TO_HEAD_V1"
DEFAULT_CONFIG = ROOT / "configs" / "tukf06_full_diagonal_search_head_to_head_v1.json"
DEFAULT_SEARCH_DESIGN = ROOT / "configs" / "tukf06_search_design_v1.npz"
DEFAULT_OUTPUT = ROOT / "results" / "tukf06_full_diagonal_search_head_to_head_v1"
DEFAULT_NEURALHYDROLOGY_ROOT = Path("G:/github/pycharm/projects/neuralhydrology")
DEFAULT_DATA_ROOT = DEFAULT_NEURALHYDROLOGY_ROOT / "data" / "camels_us"
DEFAULT_PRIOR_CSV = (
    DEFAULT_NEURALHYDROLOGY_ROOT
    / "results/10_global_conceptual_model_benchmark/camels_us_531_repro_v01_BEST/summary/hbv_lite_cma_local_full.csv"
)
DEFAULT_BASIN_LIST = (
    DEFAULT_NEURALHYDROLOGY_ROOT
    / "src/xaj_global_pilot/configs/conceptual_benchmark_camels_us_531_repro.txt"
)
DEFAULT_EXTERNAL_LOADER = DEFAULT_NEURALHYDROLOGY_ROOT / "src/hydroagent/data_loading.py"
VENDORED_LOADER = ROOT / "vendor" / "hydroagent_data_loading.py"
LEADS = (1, 2, 3)


@dataclass
class BasinContext:
    basin_id: str
    adapter: Any
    plain_model: HBVLiteSystemModel
    initial_state: torch.Tensor
    initial_covariance: torch.Tensor
    parameters: torch.Tensor
    initial_storage_state: torch.Tensor
    project_mean: Any
    base_observation_variance: float
    dimension: int
    device: torch.device
    dtype: torch.dtype


def load_contract(path: Path = DEFAULT_CONFIG) -> dict[str, Any]:
    contract = json.loads(Path(path).read_text(encoding="utf-8"))
    if contract.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("experiment identifier changed")
    if contract.get("engine") != "scripts/differentiable_ukf_hbvlite.py":
        raise ValueError("corrected differentiable engine is required")
    basins = contract.get("basins", [])
    if len(basins) != 21 or len(set(basins)) != 21:
        raise ValueError("the frozen verdict set must contain 21 unique basins")
    if set(contract.get("expected_state_dimensions", {})) != set(basins):
        raise ValueError("every frozen basin requires exactly one expected state dimension")
    process = contract["parameter_space"]["process_diagonal"]
    if process != {
        "one_per_state": True,
        "lower": 1e-5,
        "upper": 0.1,
        "coordinate": "natural_log",
    }:
        raise ValueError("process-noise parameter space changed")
    observation = contract["parameter_space"]["observation"]
    if observation != {
        "name": "r_b",
        "lower": 0.0025,
        "upper": 0.32,
        "coordinate": "natural_log",
    }:
        raise ValueError("observation-noise parameter space changed")
    periods = contract["periods"]
    expected_periods = {
        "training": ["1999-10-01", "2006-09-30"],
        "validation": ["2006-10-01", "2008-09-30"],
        "evaluation": ["1989-10-01", "1999-09-30"],
        "selection_must_not_read_evaluation": True,
        "evaluation_role": "reused_historical_benchmark",
    }
    if periods != expected_periods:
        raise ValueError("period roles or leakage guard changed")
    budgets = contract["budgets"]
    expected_budget = {
        "candidate_or_checkpoint_count": 256,
        "training_queries_per_method_per_basin": 256,
        "validation_queries_per_method_per_basin": 256,
        "filter_passes_per_method_per_basin": 512,
        "backpropagations_per_basin": 248,
        "prefix_reports": [32, 64, 128, 256],
    }
    if budgets != expected_budget:
        raise ValueError("equal search budget changed")
    backpropagation = contract["backpropagation"]
    if (
        backpropagation["optimizer"] != "Adam"
        or backpropagation["learning_rate"] != 0.05
        or backpropagation["starts"] != 8
        or backpropagation["updates_per_start"] != 31
        or backpropagation["early_stopping"] is not False
    ):
        raise ValueError("backpropagation contract changed")
    if contract["practical_equivalence"]["tolerance"] != 0.01:
        raise ValueError("practical-equivalence tolerance changed")
    if contract["objective"]["leads_days"] != [1, 2, 3]:
        raise ValueError("forecast objective leads changed")
    return contract


def atomic_write_bytes(path: Path, content: bytes, *, refuse_different: bool = False) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and refuse_different:
        if path.read_bytes() != content:
            raise RuntimeError(f"refusing to replace different file: {path}")
        return
    temporary = path.with_name(path.name + f".tmp-{os.getpid()}")
    temporary.write_bytes(content)
    os.replace(temporary, path)


def atomic_write_json(path: Path, payload: Any, *, refuse_different: bool = False) -> None:
    content = (
        json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False) + "\n"
    ).encode("utf-8")
    atomic_write_bytes(path, content, refuse_different=refuse_different)


def atomic_write_npz(path: Path, **arrays: np.ndarray) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp-{os.getpid()}")
    with temporary.open("wb") as handle:
        np.savez_compressed(handle, **arrays)
    os.replace(temporary, path)


def sha256_file(path: Path) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_arrays(arrays: Mapping[str, np.ndarray]) -> str:
    digest = sha256()
    for name in sorted(arrays):
        array = np.ascontiguousarray(np.asarray(arrays[name]))
        digest.update(name.encode("utf-8"))
        digest.update(str(array.dtype).encode("ascii"))
        digest.update(np.asarray(array.shape, dtype=np.int64).tobytes())
        digest.update(array.tobytes())
    return digest.hexdigest()


def source_hashes(contract: Mapping[str, Any], root: Path = ROOT) -> dict[str, str]:
    result: dict[str, str] = {}
    for relative in contract["code_and_input_files_to_hash"]:
        path = Path(root) / relative
        if not path.is_file():
            raise FileNotFoundError(f"frozen source missing: {relative}")
        result[relative] = sha256_file(path)
    return result


def resolve_loader_file(loader_file: Path | None = None) -> Path:
    candidates: list[Path] = []
    if loader_file is not None:
        candidates.append(Path(loader_file))
    environment_path = os.environ.get("TUKF06_DATA_LOADER_FILE")
    if environment_path:
        candidates.append(Path(environment_path))
    candidates.extend([VENDORED_LOADER, DEFAULT_EXTERNAL_LOADER])
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()
    raise FileNotFoundError("no standalone CAMELS-US data loader snapshot is available")


@lru_cache(maxsize=4)
def _load_data_loader(loader_path: str):
    path = Path(loader_path)
    module_name = f"tukf06_data_loader_{sha256(path.read_bytes()).hexdigest()[:16]}"
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot load standalone data loader: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if not callable(getattr(module, "load_camels_basin", None)):
        raise AttributeError("standalone data loader lacks load_camels_basin")
    return module.load_camels_basin


def load_period(
    basin_id: str,
    start: str,
    end: str,
    *,
    data_root: Path = DEFAULT_DATA_ROOT,
    loader_file: Path | None = None,
) -> tuple[torch.Tensor, torch.Tensor, np.ndarray]:
    load_camels_basin = _load_data_loader(str(resolve_loader_file(loader_file)))
    forcing_frame, observation_series, _ = load_camels_basin(
        str(basin_id).zfill(8),
        data_root=str(Path(data_root)),
        start_date=start,
        end_date=end,
        forcing="maurer",
        pet_method="oudin",
        keep_obs_nan_days=True,
    )
    forcing = torch.tensor(
        np.stack(
            [
                forcing_frame["prcp"].to_numpy(),
                forcing_frame["tmean"].to_numpy(),
                forcing_frame["ep"].to_numpy(),
            ],
            axis=-1,
        ),
        dtype=torch.float64,
    ).unsqueeze(1)
    observations = torch.tensor(
        observation_series.to_numpy(dtype=float), dtype=torch.float64
    ).unsqueeze(1)
    dates = np.asarray(forcing_frame.index).astype("datetime64[ns]")
    if forcing.shape[0] != observations.shape[0] or len(dates) != forcing.shape[0]:
        raise ValueError(f"forcing, observation, and date lengths differ for {basin_id}")
    if not torch.isfinite(forcing).all():
        raise FloatingPointError(f"non-finite forcing for {basin_id}")
    if len(dates) == 0 or np.any(dates[1:] <= dates[:-1]):
        raise ValueError(f"dates are empty or not strictly increasing for {basin_id}")
    return forcing, observations, dates


def build_basin_context(
    prior: Any,
    basin_id: str,
    training_observations: torch.Tensor,
    contract: Mapping[str, Any],
    data_root: Path | None = None,
    device: str | torch.device = "cpu",
) -> BasinContext:
    del data_root
    selected_device = torch.device(device)
    dtype = torch.float64
    basin = str(basin_id).zfill(8)
    index = prior.basin_ids.index(basin)
    parameters = prior.param_table[index:index + 1].clone().to(selected_device, dtype=dtype)
    initial_storage = prior.x0_table[index:index + 1].clone().to(selected_device, dtype=dtype)
    lag = parameters[:, -1:]
    routing_length = int(torch.clamp(torch.ceil(lag), min=1).max().item())
    weights = recession_half_weights(lag, routing_length)
    adapter = RoutedHBVLiteUKFAdapter(
        parameters,
        weights,
        device=selected_device,
        dtype=dtype,
        clamp_storage=True,
    )
    plain_model = HBVLiteSystemModel(
        parameters,
        emission="routed",
        lag_weights=weights,
        device=selected_device,
        dtype=dtype,
    )
    field_capacity = parameters[:, PARAM_NAMES.index("parFC")]

    def project_mean(state: torch.Tensor) -> torch.Tensor:
        storages = torch.clamp(state[:, :5], min=0.0)
        soil = torch.clamp(storages[:, 2:3], max=field_capacity)
        routing = torch.clamp(state[:, 5:], min=0.0)
        return torch.cat([storages[:, :2], soil, storages[:, 3:5], routing], dim=-1)

    initial_state = torch.cat(
        [
            initial_storage,
            torch.zeros(1, routing_length, dtype=dtype, device=selected_device),
        ],
        dim=-1,
    )
    dimension = int(adapter.dim_x)
    expected = int(contract["expected_state_dimensions"][basin])
    if dimension != expected:
        raise RuntimeError(
            f"state dimension mismatch for {basin}: computed {dimension}, expected {expected}"
        )
    initial_covariance = (
        torch.eye(dimension, dtype=dtype, device=selected_device).unsqueeze(0)
        * float(contract["hydrological_contract"]["initial_covariance_diagonal"])
    )
    training_array = training_observations[:, 0].detach().cpu().numpy()
    observation_std = float(np.nanstd(training_array, ddof=0))
    if not np.isfinite(observation_std):
        raise FloatingPointError(f"non-finite training observation standard deviation for {basin}")
    base_variance = max((0.05 * observation_std) ** 2, 1e-10)
    return BasinContext(
        basin_id=basin,
        adapter=adapter,
        plain_model=plain_model,
        initial_state=initial_state,
        initial_covariance=initial_covariance,
        parameters=parameters,
        initial_storage_state=initial_storage,
        project_mean=project_mean,
        base_observation_variance=base_variance,
        dimension=dimension,
        device=selected_device,
        dtype=dtype,
    )


def log_bound_vectors(
    state_dimension: int,
    contract: Mapping[str, Any],
    *,
    device: torch.device | str = "cpu",
    dtype: torch.dtype = torch.float64,
) -> tuple[torch.Tensor, torch.Tensor]:
    process = contract["parameter_space"]["process_diagonal"]
    observation = contract["parameter_space"]["observation"]
    lower = torch.log(torch.tensor(
        [float(process["lower"])] * int(state_dimension) + [float(observation["lower"])],
        dtype=dtype,
        device=device,
    ))
    upper = torch.log(torch.tensor(
        [float(process["upper"])] * int(state_dimension) + [float(observation["upper"])],
        dtype=dtype,
        device=device,
    ))
    return lower, upper


def decode_theta(
    theta: torch.Tensor,
    state_dimension: int,
    contract: Mapping[str, Any],
) -> tuple[torch.Tensor, torch.Tensor]:
    if not torch.is_tensor(theta) or theta.shape != (int(state_dimension) + 1,):
        supplied = getattr(theta, "shape", None)
        raise ValueError(f"theta shape {supplied} does not match state_dimension + 1")
    if not theta.dtype.is_floating_point or not bool(torch.isfinite(theta).all()):
        raise ValueError("theta must be a finite floating-point vector")
    lower, upper = log_bound_vectors(
        state_dimension, contract, device=theta.device, dtype=theta.dtype
    )
    if bool(torch.any(theta < lower)) or bool(torch.any(theta > upper)):
        raise ValueError("theta lies outside the frozen natural-log bounds")
    actual = torch.exp(theta)
    if not bool(torch.isfinite(actual).all()) or bool(torch.any(actual <= 0.0)):
        raise FloatingPointError("decoded noise parameters are non-finite or non-positive")
    return actual[:int(state_dimension)], actual[int(state_dimension)]


def multilead_torch(
    plain_model: HBVLiteSystemModel,
    posterior: torch.Tensor,
    forcings: torch.Tensor,
) -> dict[int, tuple[torch.Tensor, torch.Tensor]]:
    starts = posterior.shape[0] - max(LEADS)
    if starts < 1:
        raise ValueError("forecast period is shorter than the maximum lead")
    state = posterior[:starts]
    result: dict[int, tuple[torch.Tensor, torch.Tensor]] = {}
    for lead in LEADS:
        state = plain_model.f(state, forcings[lead:starts + lead, 0, :])
        forecast = plain_model.h(state)[:, 0]
        indices = torch.arange(
            lead, lead + forecast.shape[0], device=forecast.device, dtype=torch.long
        )
        result[lead] = (forecast, indices)
    return result


def run_parameterized_filter(
    context: BasinContext,
    forcings: torch.Tensor,
    observations: torch.Tensor,
    theta: torch.Tensor,
    contract: Mapping[str, Any],
) -> dict[str, torch.Tensor]:
    q_diagonal, r_b = decode_theta(theta, context.dimension, contract)
    result = run_hbvlite_corrected_ukf(
        context.adapter,
        forcings.to(context.device, dtype=context.dtype),
        observations.to(context.device, dtype=context.dtype),
        context.initial_state,
        context.initial_covariance,
        q_diagonal,
        base_observation_variance=context.base_observation_variance,
        r_b=r_b,
        project_mean=context.project_mean,
    )
    for name in ("posterior_state", "prior_state"):
        if name in result and not bool(torch.isfinite(result[name]).all()):
            raise FloatingPointError(f"non-finite {name} for {context.basin_id}")
    return result


def multilead_objective(
    context: BasinContext,
    forcings: torch.Tensor,
    observations: torch.Tensor,
    theta: torch.Tensor,
    grad: bool,
    contract: Mapping[str, Any],
) -> torch.Tensor:
    manager = torch.enable_grad() if grad else torch.no_grad()
    with manager:
        result = run_parameterized_filter(context, forcings, observations, theta, contract)
        posterior = result["posterior_state"][:, 0, :]
        total = torch.zeros((), dtype=context.dtype, device=context.device)
        for lead, (forecast, target_indices) in multilead_torch(
            context.plain_model,
            posterior,
            forcings.to(context.device, dtype=context.dtype),
        ).items():
            target = observations.to(context.device, dtype=context.dtype)[target_indices, 0]
            finite = torch.isfinite(target)
            if not bool(finite.any()):
                raise FloatingPointError(
                    f"no finite lead-{lead} targets for {context.basin_id}"
                )
            total = total + ((forecast[finite] - target[finite]) ** 2).mean()
        value = total / len(LEADS)
    if not bool(torch.isfinite(value)):
        raise FloatingPointError(f"non-finite objective for {context.basin_id}")
    return value


def filter_forecasts(
    context: BasinContext,
    forcings: torch.Tensor,
    observations: torch.Tensor,
    theta: Sequence[float] | np.ndarray | torch.Tensor,
    contract: Mapping[str, Any],
) -> dict[int, np.ndarray]:
    theta_tensor = torch.as_tensor(
        theta, dtype=context.dtype, device=context.device
    )
    with torch.no_grad():
        result = run_parameterized_filter(
            context, forcings, observations, theta_tensor, contract
        )
        raw = multilead_torch(
            context.plain_model,
            result["posterior_state"][:, 0, :],
            forcings.to(context.device, dtype=context.dtype),
        )
    aligned: dict[int, np.ndarray] = {}
    for lead, (forecast, indices) in raw.items():
        values = np.full(forcings.shape[0], np.nan, dtype=np.float64)
        values[indices.detach().cpu().numpy()] = forecast.detach().cpu().numpy()
        aligned[lead] = values
    return aligned


def open_loop_prediction(context: BasinContext, forcings: torch.Tensor) -> np.ndarray:
    values: list[float] = []
    state = context.initial_state.clone()
    forcing_device = forcings.to(context.device, dtype=context.dtype)
    with torch.no_grad():
        for day in range(forcing_device.shape[0]):
            state = context.plain_model.f(state, forcing_device[day])
            values.append(float(context.plain_model.h(state)[0, 0]))
    result = np.asarray(values, dtype=np.float64)
    if not np.isfinite(result).all():
        raise FloatingPointError(f"non-finite open loop for {context.basin_id}")
    return result


def persistence_predictions(observations: np.ndarray) -> dict[int, np.ndarray]:
    observation_array = np.asarray(observations, dtype=np.float64)
    result: dict[int, np.ndarray] = {}
    for lead in LEADS:
        values = np.full(len(observation_array), np.nan, dtype=np.float64)
        values[lead:] = observation_array[:-lead]
        result[lead] = values
    return result


def second_order_autoregression_predictions(
    training_observations: np.ndarray,
    evaluation_observations: np.ndarray,
) -> dict[int, np.ndarray]:
    training = np.asarray(training_observations, dtype=np.float64)
    finite_training = training[np.isfinite(training)]
    if finite_training.size < 4:
        raise ValueError("second-order autoregression requires at least four observations")
    design = np.stack([finite_training[1:-1], finite_training[:-2]], axis=1)
    coefficients, *_ = np.linalg.lstsq(
        np.concatenate([design, np.ones((len(design), 1))], axis=1),
        finite_training[2:],
        rcond=None,
    )
    a1, a2, intercept = coefficients
    filled = np.asarray(evaluation_observations, dtype=np.float64).copy()
    for index in range(len(filled)):
        if not np.isfinite(filled[index]):
            filled[index] = (
                filled[index - 1] if index else float(np.mean(finite_training))
            )
    result: dict[int, np.ndarray] = {}
    for lead in LEADS:
        prediction = np.full(len(filled), np.nan, dtype=np.float64)
        for origin in range(1, len(filled) - lead):
            y1, y2 = filled[origin], filled[origin - 1]
            for _ in range(lead):
                y1, y2 = a1 * y1 + a2 * y2 + intercept, y1
            prediction[origin + lead] = y1
        result[lead] = prediction
    return result


def common_finite_mask(
    target: np.ndarray,
    predictions: Mapping[str, np.ndarray],
    first_scoring_index: int,
) -> np.ndarray:
    target_array = np.asarray(target, dtype=np.float64)
    mask = np.isfinite(target_array)
    for values in predictions.values():
        array = np.asarray(values, dtype=np.float64)
        if array.shape != target_array.shape:
            raise ValueError("every prediction must align exactly to the target")
        mask &= np.isfinite(array)
    mask[:int(first_scoring_index)] = False
    if int(mask.sum()) < 2:
        raise ValueError("common finite index contains fewer than two targets")
    if float(np.var(target_array[mask], ddof=0)) <= 0.0:
        raise ValueError("common target variance must be positive")
    return mask


def nse_population(prediction: np.ndarray, target: np.ndarray, mask: np.ndarray) -> float:
    prediction_array = np.asarray(prediction, dtype=np.float64)
    target_array = np.asarray(target, dtype=np.float64)
    selected = np.asarray(mask, dtype=bool)
    error = prediction_array[selected] - target_array[selected]
    value = 1.0 - float(np.mean(error ** 2)) / float(np.var(target_array[selected], ddof=0))
    if not np.isfinite(value):
        raise FloatingPointError("non-finite Nash-Sutcliffe efficiency")
    return value


def basin_input_arrays(
    context: BasinContext,
    forcing: torch.Tensor,
    observations: torch.Tensor,
    dates: np.ndarray,
) -> dict[str, np.ndarray]:
    return {
        "dates_ns": dates.astype("datetime64[ns]").astype(np.int64),
        "forcing": forcing[:, 0, :].detach().cpu().numpy(),
        "observations": observations[:, 0].detach().cpu().numpy(),
        "parameters": context.parameters.detach().cpu().numpy(),
        "initial_storage_state": context.initial_storage_state.detach().cpu().numpy(),
        "initial_state": context.initial_state.detach().cpu().numpy(),
        "initial_covariance": context.initial_covariance.detach().cpu().numpy(),
        "base_observation_variance": np.asarray(
            [context.base_observation_variance], dtype=np.float64
        ),
        "state_dimension": np.asarray([context.dimension], dtype=np.int64),
    }


def load_search_design(path: Path = DEFAULT_SEARCH_DESIGN) -> dict[int, np.ndarray]:
    result: dict[int, np.ndarray] = {}
    with np.load(path, allow_pickle=False) as archive:
        if set(archive.files) != {"state_dim_7", "state_dim_11", "state_dim_18"}:
            raise ValueError("search design contains unexpected arrays")
        for dimension in (7, 11, 18):
            array = np.asarray(archive[f"state_dim_{dimension}"], dtype=np.float64)
            if array.shape != (256, dimension + 1) or not np.isfinite(array).all():
                raise ValueError(f"invalid search design for state dimension {dimension}")
            result[dimension] = array
    return result


def boundary_diagnostics(theta: Sequence[float], state_dimension: int,
                         contract: Mapping[str, Any]) -> dict[str, Any]:
    array = np.asarray(theta, dtype=np.float64)
    lower_t, upper_t = log_bound_vectors(state_dimension, contract)
    lower = lower_t.cpu().numpy()
    upper = upper_t.cpu().numpy()
    if array.shape != lower.shape:
        raise ValueError("boundary vector shape mismatch")
    position = (array - lower) / (upper - lower)
    exact = np.isclose(array, lower, atol=1e-12, rtol=0.0) | np.isclose(
        array, upper, atol=1e-12, rtol=0.0
    )
    outer = (position <= 0.05) | (position >= 0.95)
    return {
        "exact_any": bool(exact.any()),
        "exact_count": int(exact.sum()),
        "outer_five_percent_any": bool(outer.any()),
        "outer_five_percent_count": int(outer.sum()),
        "normalized_log_position": position.tolist(),
    }


def practical_equivalence_decision(value: float, tolerance: float) -> str:
    if not math.isfinite(value) or not math.isfinite(tolerance) or tolerance <= 0.0:
        raise ValueError("decision inputs must be finite and tolerance positive")
    if value >= tolerance:
        return "BACKPROPAGATION_ADVANTAGE"
    if value <= -tolerance:
        return "SAMPLING_SEARCH_ADVANTAGE"
    return "NO_DISCERNIBLE_ADVANTAGE"


def mem_available_gib(meminfo: Path = Path("/proc/meminfo")) -> float:
    for line in Path(meminfo).read_text(encoding="utf-8").splitlines():
        if line.startswith("MemAvailable:"):
            kib = int(line.split()[1])
            return kib / (1024.0 ** 2)
    raise RuntimeError("MemAvailable is absent from /proc/meminfo")


def worker_count_from_available_gib(available_gib: float) -> int:
    if available_gib >= 96.0:
        return 21
    if available_gib >= 64.0:
        return 12
    if available_gib >= 48.0:
        return 8
    raise MemoryError(f"available memory {available_gib:.2f} GiB is below the 48 GiB gate")
