"""Build and verify the minimal immutable TUKF06 high-performance-computing bundle."""
from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import argparse
import gzip
import json
import os
import sys
import tarfile
from typing import Any, Mapping

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
for _extra in (str(ROOT), str(ROOT / "src")):
    if _extra not in sys.path:
        sys.path.insert(0, _extra)

from scripts.tukf06_full_diagonal_common import (  # noqa: E402
    DEFAULT_BASIN_LIST,
    DEFAULT_CONFIG,
    DEFAULT_DATA_ROOT,
    DEFAULT_EXTERNAL_LOADER,
    DEFAULT_PRIOR_CSV,
    EXPERIMENT_ID,
    atomic_write_bytes,
    atomic_write_json,
    basin_input_arrays,
    build_basin_context,
    load_contract,
    load_period,
    sha256_arrays,
    sha256_file,
)
from scripts.run_tukf06_full_diagonal_selection import load_selection_period  # noqa: E402
from global_hydrology.data.hbvlite_prior import load_hbvlite_prior  # noqa: E402


DEFAULT_BUNDLE_OUTPUT = ROOT / "artifacts" / "tukf06_hpc_bundle"
DEFAULT_FINGERPRINTS = ROOT / "configs" / "tukf06_data_fingerprints_v1.json"
ARCHIVE_NAME = f"{EXPERIMENT_ID}.tar.gz"

REPOSITORY_MEMBERS = (
    "configs/tukf06_full_diagonal_search_head_to_head_v1.json",
    "configs/tukf06_search_design_v1.npz",
    "configs/tukf06_search_design_v1.sha256.json",
    "scripts/freeze_tukf06_search_design.py",
    "scripts/tukf06_full_diagonal_common.py",
    "scripts/run_tukf06_full_diagonal_selection.py",
    "scripts/evaluate_tukf06_full_diagonal_head_to_head.py",
    "scripts/verify_tukf06_full_diagonal_head_to_head.py",
    "scripts/build_tukf06_hpc_bundle.py",
    "scripts/smoke_tukf06_full_diagonal.py",
    "scripts/differentiable_ukf_hbvlite.py",
    "scripts/run_aligned_gr4j_da.py",
    "scripts/run_aligned_gr4j_differentiable_ukf.py",
    "src/global_hydrology/__init__.py",
    "src/global_hydrology/data/__init__.py",
    "src/global_hydrology/data/hbvlite_prior.py",
    "src/global_hydrology/models/__init__.py",
    "src/global_hydrology/models/differentiable_hbv_lite.py",
    "src/global_hydrology/models/hbvlite_system_model.py",
    "src/global_hydrology/models/hbvlite_ukf_adapter.py",
    "src/global_hydrology/assimilation/__init__.py",
    "src/global_hydrology/assimilation/conventional_ukf.py",
    "hpc/tukf06_full_diagonal/preflight.sh",
    "hpc/tukf06_full_diagonal/submit_smoke_cpu.slurm",
    "hpc/tukf06_full_diagonal/submit_selection_cpu.slurm",
    "hpc/tukf06_full_diagonal/submit_evaluation_cpu.slurm",
)


@dataclass(frozen=True)
class BundleManifest:
    archive_path: Path
    archive_sha256: str
    archive_size: int
    manifest_path: Path
    member_sha256: dict[str, str]


def bundle_member_sources(
    *,
    prior_csv: Path,
    basin_list: Path,
    loader_file: Path,
    fingerprints: Path,
    root: Path = ROOT,
) -> dict[str, Path]:
    members = {name: Path(root) / name for name in REPOSITORY_MEMBERS}
    members.update({
        "configs/tukf06_data_fingerprints_v1.json": Path(fingerprints),
        "inputs/hbv_lite_cma_local_full.csv": Path(prior_csv),
        "inputs/conceptual_benchmark_camels_us_531_repro.txt": Path(basin_list),
        "vendor/hydroagent_data_loading.py": Path(loader_file),
    })
    for name, path in members.items():
        if Path(name).is_absolute() or ".." in Path(name).parts:
            raise ValueError(f"unsafe bundle member name: {name}")
        if not path.is_file():
            raise FileNotFoundError(f"bundle source is absent: {name} <- {path}")
    forbidden = ("results/", "draft/", ".git/")
    if any(name.startswith(forbidden) or "__pycache__" in name for name in members):
        raise RuntimeError("bundle allowlist contains a forbidden dirty-worktree path")
    return dict(sorted(members.items()))


def _semantic_fingerprints(
    *,
    data_root: Path,
    prior_csv: Path,
    basin_list: Path,
    loader_file: Path,
    config: Path,
) -> dict[str, Any]:
    torch.set_default_dtype(torch.float64)
    contract = load_contract(config)
    prior = load_hbvlite_prior(
        csv_path=prior_csv, basin_list_path=basin_list, dtype=torch.float64
    )
    rows: dict[str, Any] = {}
    for basin_id in contract["basins"]:
        selection_forcing, selection_observations, selection_dates, split = load_selection_period(
            basin_id,
            contract,
            data_root=data_root,
            loader_file=loader_file,
        )
        context = build_basin_context(
            prior,
            basin_id,
            selection_observations[:split],
            contract,
            data_root=data_root,
            device="cpu",
        )
        selection_arrays = basin_input_arrays(
            context, selection_forcing, selection_observations, selection_dates
        )
        evaluation_period = contract["periods"]["evaluation"]
        evaluation_forcing, evaluation_observations, evaluation_dates = load_period(
            basin_id,
            evaluation_period[0],
            evaluation_period[1],
            data_root=data_root,
            loader_file=loader_file,
        )
        evaluation_arrays = basin_input_arrays(
            context, evaluation_forcing, evaluation_observations, evaluation_dates
        )
        rows[basin_id] = {
            "state_dimension": context.dimension,
            "training_days": split,
            "validation_days": len(selection_dates) - split,
            "selection_days": len(selection_dates),
            "evaluation_days": len(evaluation_dates),
            "selection_first_date_ns": int(selection_arrays["dates_ns"][0]),
            "selection_last_date_ns": int(selection_arrays["dates_ns"][-1]),
            "evaluation_first_date_ns": int(evaluation_arrays["dates_ns"][0]),
            "evaluation_last_date_ns": int(evaluation_arrays["dates_ns"][-1]),
            "selection_finite_observation_count": int(np.isfinite(
                selection_arrays["observations"]
            ).sum()),
            "evaluation_finite_observation_count": int(np.isfinite(
                evaluation_arrays["observations"]
            ).sum()),
            "selection_semantic_sha256": sha256_arrays(selection_arrays),
            "evaluation_semantic_sha256": sha256_arrays(evaluation_arrays),
        }
    return {
        "experiment_id": EXPERIMENT_ID,
        "hash_scope": "dates, forcing, observations, parameters, initial states, initial covariance, base observation variance, and state dimension",
        "evaluation_access_role": "hash_only_integrity_preflight_not_used_for_selection",
        "prior_csv_sha256": sha256_file(prior_csv),
        "basin_list_sha256": sha256_file(basin_list),
        "loader_file_sha256": sha256_file(loader_file),
        "basins": rows,
    }


def freeze_data_fingerprints(
    output: Path = DEFAULT_FINGERPRINTS,
    *,
    data_root: Path = DEFAULT_DATA_ROOT,
    prior_csv: Path = DEFAULT_PRIOR_CSV,
    basin_list: Path = DEFAULT_BASIN_LIST,
    loader_file: Path = DEFAULT_EXTERNAL_LOADER,
    config: Path = DEFAULT_CONFIG,
) -> dict[str, Any]:
    payload = _semantic_fingerprints(
        data_root=Path(data_root),
        prior_csv=Path(prior_csv),
        basin_list=Path(basin_list),
        loader_file=Path(loader_file),
        config=Path(config),
    )
    content = (
        json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False)
        + "\n"
    ).encode("utf-8")
    atomic_write_bytes(Path(output), content, refuse_different=True)
    return payload


def verify_data_fingerprints(
    reference: Path,
    *,
    data_root: Path,
    prior_csv: Path,
    basin_list: Path,
    loader_file: Path,
    config: Path,
) -> None:
    expected = json.loads(Path(reference).read_text(encoding="utf-8"))
    actual = _semantic_fingerprints(
        data_root=Path(data_root),
        prior_csv=Path(prior_csv),
        basin_list=Path(basin_list),
        loader_file=Path(loader_file),
        config=Path(config),
    )
    if actual != expected:
        raise RuntimeError("current data or frozen input fingerprints differ")


def _tar_bytes(members: Mapping[str, Path]) -> tuple[bytes, dict[str, str]]:
    member_hashes = {name: sha256_file(path) for name, path in members.items()}
    member_sizes = {name: int(path.stat().st_size) for name, path in members.items()}
    internal_manifest = {
        "experiment_id": EXPERIMENT_ID,
        "member_sha256": member_hashes,
        "member_size": member_sizes,
    }
    payloads: dict[str, bytes] = {
        name: path.read_bytes() for name, path in members.items()
    }
    payloads["bundle_manifest.json"] = (
        json.dumps(internal_manifest, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    ).encode("utf-8")
    raw = BytesIO()
    with gzip.GzipFile(fileobj=raw, mode="wb", filename="", mtime=0, compresslevel=9) as gz:
        with tarfile.open(fileobj=gz, mode="w", format=tarfile.PAX_FORMAT) as archive:
            for name in sorted(payloads):
                content = payloads[name]
                info = tarfile.TarInfo(name=name)
                info.size = len(content)
                info.mtime = 0
                info.uid = 0
                info.gid = 0
                info.uname = ""
                info.gname = ""
                info.mode = 0o755 if name.endswith((".sh", ".slurm")) else 0o644
                archive.addfile(info, BytesIO(content))
    return raw.getvalue(), member_hashes


def build_bundle(
    destination: Path = DEFAULT_BUNDLE_OUTPUT,
    *,
    prior_csv: Path = DEFAULT_PRIOR_CSV,
    basin_list: Path = DEFAULT_BASIN_LIST,
    loader_file: Path = DEFAULT_EXTERNAL_LOADER,
    fingerprints: Path = DEFAULT_FINGERPRINTS,
) -> BundleManifest:
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    members = bundle_member_sources(
        prior_csv=Path(prior_csv),
        basin_list=Path(basin_list),
        loader_file=Path(loader_file),
        fingerprints=Path(fingerprints),
    )
    archive_bytes, member_hashes = _tar_bytes(members)
    if len(archive_bytes) >= 90 * 1024 * 1024:
        raise RuntimeError("bundle exceeds the frozen 90 MiB limit")
    archive_path = destination / ARCHIVE_NAME
    atomic_write_bytes(archive_path, archive_bytes, refuse_different=True)
    archive_hash = sha256(archive_bytes).hexdigest()
    manifest = {
        "experiment_id": EXPERIMENT_ID,
        "archive_name": ARCHIVE_NAME,
        "archive_sha256": archive_hash,
        "archive_size": len(archive_bytes),
        "member_sha256": member_hashes,
    }
    manifest_path = destination / "bundle_manifest.sha256.json"
    atomic_write_json(manifest_path, manifest, refuse_different=True)
    with tarfile.open(archive_path, "r:gz") as archive:
        names = archive.getnames()
        if names != sorted(names) or len(names) != len(set(names)):
            raise RuntimeError("archive member ordering or uniqueness check failed")
        extracted_manifest = json.loads(
            archive.extractfile("bundle_manifest.json").read().decode("utf-8")
        )
    if extracted_manifest["member_sha256"] != member_hashes:
        raise RuntimeError("archive internal manifest verification failed")
    return BundleManifest(
        archive_path=archive_path,
        archive_sha256=archive_hash,
        archive_size=len(archive_bytes),
        manifest_path=manifest_path,
        member_sha256=member_hashes,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=DEFAULT_BUNDLE_OUTPUT)
    parser.add_argument("--fingerprints", type=Path, default=DEFAULT_FINGERPRINTS)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--data-root", type=Path, default=DEFAULT_DATA_ROOT)
    parser.add_argument("--prior-csv", type=Path, default=DEFAULT_PRIOR_CSV)
    parser.add_argument("--basin-list", type=Path, default=DEFAULT_BASIN_LIST)
    parser.add_argument("--loader-file", type=Path, default=DEFAULT_EXTERNAL_LOADER)
    parser.add_argument("--verify-inputs-only", action="store_true")
    args = parser.parse_args()
    if args.verify_inputs_only:
        verify_data_fingerprints(
            args.fingerprints,
            data_root=args.data_root,
            prior_csv=args.prior_csv,
            basin_list=args.basin_list,
            loader_file=args.loader_file,
            config=args.config,
        )
        print("TUKF06_DATA_FINGERPRINTS_MATCH", flush=True)
        return
    if args.fingerprints.exists():
        verify_data_fingerprints(
            args.fingerprints,
            data_root=args.data_root,
            prior_csv=args.prior_csv,
            basin_list=args.basin_list,
            loader_file=args.loader_file,
            config=args.config,
        )
    else:
        freeze_data_fingerprints(
            args.fingerprints,
            data_root=args.data_root,
            prior_csv=args.prior_csv,
            basin_list=args.basin_list,
            loader_file=args.loader_file,
            config=args.config,
        )
    result = build_bundle(
        args.output,
        prior_csv=args.prior_csv,
        basin_list=args.basin_list,
        loader_file=args.loader_file,
        fingerprints=args.fingerprints,
    )
    print(json.dumps({
        "archive": str(result.archive_path),
        "archive_sha256": result.archive_sha256,
        "archive_size": result.archive_size,
        "manifest": str(result.manifest_path),
    }, indent=2, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
