"""One-basin objective and gradient parity smoke for TUKF06."""
from __future__ import annotations

from pathlib import Path
import argparse
import json
import os
import platform
import sys
import time

import numpy as np
import torch

try:
    import resource
except ImportError:  # Windows local parity run
    resource = None


ROOT = Path(__file__).resolve().parents[1]
for _extra in (str(ROOT), str(ROOT / "src")):
    if _extra not in sys.path:
        sys.path.insert(0, _extra)

from scripts.tukf06_full_diagonal_common import (  # noqa: E402
    DEFAULT_BASIN_LIST,
    DEFAULT_CONFIG,
    DEFAULT_DATA_ROOT,
    DEFAULT_EXTERNAL_LOADER,
    DEFAULT_PRIOR_CSV,
    DEFAULT_SEARCH_DESIGN,
    atomic_write_json,
    build_basin_context,
    load_contract,
    load_search_design,
    log_bound_vectors,
    multilead_objective,
    sha256_arrays,
    sha256_file,
    source_hashes,
)
from scripts.run_tukf06_full_diagonal_selection import load_selection_period  # noqa: E402
from global_hydrology.data.hbvlite_prior import load_hbvlite_prior  # noqa: E402


def _checkpoint(context, training, validation, theta, contract) -> dict:
    if theta.grad is not None:
        theta.grad = None
    training_loss = multilead_objective(
        context, training[0], training[1], theta, True, contract
    )
    validation_loss = multilead_objective(
        context, validation[0], validation[1], theta, False, contract
    )
    training_loss.backward()
    if theta.grad is None or not bool(torch.isfinite(theta.grad).all()):
        raise FloatingPointError("smoke gradient is absent or non-finite")
    return {
        "theta_log": theta.detach().cpu().numpy().tolist(),
        "training_objective": float(training_loss.detach()),
        "validation_objective": float(validation_loss.detach()),
        "gradient": theta.grad.detach().cpu().numpy().tolist(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--search-design", type=Path, default=DEFAULT_SEARCH_DESIGN)
    parser.add_argument("--data-root", type=Path, default=DEFAULT_DATA_ROOT)
    parser.add_argument("--prior-csv", type=Path, default=DEFAULT_PRIOR_CSV)
    parser.add_argument("--basin-list", type=Path, default=DEFAULT_BASIN_LIST)
    parser.add_argument("--loader-file", type=Path, default=DEFAULT_EXTERNAL_LOADER)
    parser.add_argument("--basin", default="04105700")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    torch.set_default_dtype(torch.float64)
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    started = time.perf_counter()
    contract = load_contract(args.config)
    basin_id = str(args.basin).zfill(8)
    if basin_id not in contract["basins"]:
        raise ValueError("smoke basin is outside the frozen set")
    prior = load_hbvlite_prior(
        csv_path=args.prior_csv, basin_list_path=args.basin_list, dtype=torch.float64
    )
    forcing, observations, dates, split = load_selection_period(
        basin_id,
        contract,
        data_root=args.data_root,
        loader_file=args.loader_file,
    )
    context = build_basin_context(
        prior, basin_id, observations[:split], contract, data_root=args.data_root, device="cpu"
    )
    design = load_search_design(args.search_design)[context.dimension]
    training = (forcing[:split], observations[:split])
    validation = (forcing[split:], observations[split:])

    repeats = []
    for _ in range(2):
        theta = torch.nn.Parameter(torch.tensor(design[0], dtype=torch.float64))
        repeats.append(_checkpoint(context, training, validation, theta, contract))
    repeated_training_difference = abs(
        repeats[0]["training_objective"] - repeats[1]["training_objective"]
    )
    repeated_validation_difference = abs(
        repeats[0]["validation_objective"] - repeats[1]["validation_objective"]
    )
    repeated_gradient_difference = float(np.max(np.abs(
        np.asarray(repeats[0]["gradient"]) - np.asarray(repeats[1]["gradient"])
    )))
    if max(
        repeated_training_difference,
        repeated_validation_difference,
        repeated_gradient_difference,
    ) > 1e-12:
        raise RuntimeError("two deterministic smoke repeats differ by more than 1e-12")

    anchors = []
    lower, upper = log_bound_vectors(context.dimension, contract)
    for start_index, anchor in enumerate(design[:8]):
        theta = torch.nn.Parameter(torch.tensor(anchor, dtype=torch.float64))
        optimizer = torch.optim.Adam(
            [theta], lr=float(contract["backpropagation"]["learning_rate"])
        )
        optimizer.zero_grad(set_to_none=True)
        initial = _checkpoint(context, training, validation, theta, contract)
        optimizer.step()
        with torch.no_grad():
            theta.clamp_(min=lower, max=upper)
        updated_training = multilead_objective(
            context, training[0], training[1], theta, False, contract
        )
        updated_validation = multilead_objective(
            context, validation[0], validation[1], theta, False, contract
        )
        anchors.append({
            "start_index": start_index,
            "initial": initial,
            "updated": {
                "theta_log": theta.detach().cpu().numpy().tolist(),
                "training_objective": float(updated_training),
                "validation_objective": float(updated_validation),
            },
        })
    input_arrays = {
        "dates_ns": dates.astype("datetime64[ns]").astype(np.int64),
        "forcing": forcing[:, 0, :].numpy(),
        "observations": observations[:, 0].numpy(),
        "parameters": context.parameters.numpy(),
        "initial_state": context.initial_state.numpy(),
        "initial_covariance": context.initial_covariance.numpy(),
    }
    if resource is not None:
        maximum_rss = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        maximum_rss_units = "kibibytes_on_linux"
    else:
        import psutil
        maximum_rss = int(psutil.Process().memory_info().rss)
        maximum_rss_units = "bytes_on_windows_current_rss"
    payload = {
        "experiment_id": contract["experiment_id"],
        "basin_id": basin_id,
        "state_dimension": context.dimension,
        "training_days": split,
        "validation_days": len(dates) - split,
        "contract_sha256": sha256_file(args.config),
        "search_design_sha256": sha256_file(args.search_design),
        "source_sha256": source_hashes(contract),
        "input_semantic_sha256": sha256_arrays(input_arrays),
        "neutral_repeats": repeats,
        "repeat_maximum_differences": {
            "training_objective": repeated_training_difference,
            "validation_objective": repeated_validation_difference,
            "gradient": repeated_gradient_difference,
        },
        "anchors_after_one_update": anchors,
        "elapsed_seconds": time.perf_counter() - started,
        "maximum_resident_set_size_native_units": maximum_rss,
        "maximum_resident_set_size_units": maximum_rss_units,
        "environment": {
            "python": sys.version,
            "torch": torch.__version__,
            "numpy": np.__version__,
            "platform": platform.platform(),
            "hostname": platform.node(),
            "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
        },
    }
    atomic_write_json(args.output, payload)
    print(json.dumps({
        "output": str(args.output),
        "elapsed_seconds": payload["elapsed_seconds"],
        "repeat_maximum_differences": payload["repeat_maximum_differences"],
    }, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
