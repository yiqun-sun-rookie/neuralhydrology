"""Sigma-point adapter: routed HBV-lite f/h  ->  Batch-UKF fx/hx.

``BatchUnscentedKalmanFilterGPU`` drives the process/observation model through
sigma points: ``fx(sigmas[B,S,m], dt) -> [B,S,m]`` and ``hx(sigmas[B,S,m]) ->
[B,S,1]``, where ``B`` = number of basins (the filter batch), ``S = 2m+1`` =
num_sigmas. This adapter wraps the **routed** :class:`HBVLiteSystemModel` (faithful
UH-lag form, ``m = 5 + L``) so each basin's frozen per-basin params + routing
weights are applied to that basin's sigma points.

Row-order contract (the alignment that must not break):
``sigmas.reshape(B*S, m)`` puts basin ``b``'s sigma ``s`` at row ``b*S + s``; the
expanded system model is built with params/weights ``repeat_interleave(S, dim=0)``
so row ``b*S+s`` carries basin ``b``'s params; the current-step forcing is likewise
``repeat_interleave(S)``. (Mirrors ``filters/da_coupler/walrus_batch.py``.)

Storage safety: the UKF analysis can push sigma storages negative, which would feed
``pow(SM<0, BETA) -> NaN`` in ``forward_step``. ``fx`` can clamp declared storage
channels before the step.  Routing memory has two explicit contracts: the default
physical contract reports nonnegative routed discharge, while
``signed_routing_memory=True`` treats routing-memory values as signed assimilation
corrections and keeps the sigma-point observation map linear across zero.

Forcing is injected per step via :meth:`set_forcing` (call before ``ukf.predict``);
``fx``/``hx`` are bound once on the filter.
"""
from typing import Optional, Union, Dict

import torch

from .hbvlite_system_model import HBVLiteSystemModel
from .differentiable_hbv_lite import N_STATES


class RoutedHBVLiteUKFAdapter:
    """Expose a routed HBV-lite batch as Batch-UKF ``fx``/``hx`` callables."""

    def __init__(
        self,
        params: Union[torch.Tensor, Dict[str, torch.Tensor]],
        lag_weights: torch.Tensor,
        device: Optional[torch.device] = None,
        dtype: torch.dtype = torch.float32,
        clamp_storage: bool = False,
        clamp_idx: tuple = (0, 1, 2, 3, 4),
        bias: bool = False,
        mult_bias: bool = False,
        signed_routing_memory: bool = False,
    ):
        """
        Args:
            params: ``[B,13]`` per-basin physical params (PARAM_NAMES order) or dict.
            lag_weights: ``[B,L]`` RECESSION-half routing weights (recession_half_weights).
            device, dtype: compute device / working dtype.
            clamp_storage: if True, clamp each sigma's storages >=0 in fx (legacy safety net;
                biases the UT mean and pins SUZ — default False, see fx docstring / review F3).
            signed_routing_memory: if True, routing-memory channels are signed
                assimilation corrections and ``hx`` returns their weighted sum
                without clamping individual sigma-point observations at zero.
        """
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.dtype = dtype
        self.clamp_storage = clamp_storage
        self.clamp_idx = list(clamp_idx)

        if isinstance(params, dict):
            from .differentiable_hbv_lite import PARAM_NAMES
            params = torch.cat([params[k].reshape(-1, 1) for k in PARAM_NAMES], dim=-1)
        self._params = params.to(self.device, self.dtype).detach()       # [B,13]
        self._weights = lag_weights.to(self.device, self.dtype).detach()  # [B,L]
        self.B = self._params.shape[0]
        self.L = self._weights.shape[-1]
        self.bias = bias
        self.mult_bias = mult_bias                       # emission gain (1+g)*routed vs additive routed+b
        self.signed_routing_memory = bool(signed_routing_memory)
        self.m_phys = N_STATES + self.L                 # storages + routing buffer (sm handles)
        self.dim_x = self.m_phys + (1 if bias else 0)   # + additive emission-bias state
        self.num_sigmas = 2 * self.dim_x + 1

        # Build ONE expanded routed model whose batch is B * num_sigmas, with each
        # basin's params/weights repeated across its sigma points (row b*S+s -> basin b).
        S = self.num_sigmas
        params_rep = self._params.repeat_interleave(S, dim=0)            # [B*S,13]
        weights_rep = self._weights.repeat_interleave(S, dim=0)          # [B*S,L]
        self._sm = HBVLiteSystemModel(
            params_rep, emission="routed", lag_weights=weights_rep,
            device=self.device, dtype=self.dtype,
        )
        self._forcing: Optional[torch.Tensor] = None                    # [B,3] current step

    def set_forcing(self, forcing: torch.Tensor):
        """Set the current-step forcing ``u=(P,T,PET)`` [B,3] (call before predict)."""
        self._forcing = forcing.to(self.device, self.dtype)

    def fx(self, sigmas: torch.Tensor, dt: float = 1.0) -> torch.Tensor:
        """[B,S,m] -> [B,S,m] one routed HBV-lite step over all sigma points."""
        if self._forcing is None:
            raise ValueError("call set_forcing(u[B,3]) before fx().")
        B, S, m = sigmas.shape
        flat = sigmas.reshape(B * S, m).to(self.device, self.dtype)
        sb = flat[:, :self.m_phys]                                       # storages + buffer
        # NO per-sigma storage clamp (clamp_storage=False default). The blanket clamp
        # pinned SUZ (median x0=0) -> the fast-flow store was DEAD in the DA (independent
        # review F3). forward_step guards pow(SM<0) internally and is bounded for small
        # negative SUZ/SLZ/snow; with the small per-state spreads this is stable (the iter1
        # -1e38 blow-up was under LARGE spread). Physicality is enforced on the post-predict
        # MEAN by the driver. clamp_storage=True restores the old safety net if needed.
        if self.clamp_storage and self.clamp_idx:
            sb = sb.clone()
            sb[:, self.clamp_idx] = sb[:, self.clamp_idx].clamp(min=0.0)
        u_rep = self._forcing.repeat_interleave(S, dim=0)               # [B*S,3]
        out_sb = self._sm.f(sb, u_rep)                                   # [B*S,m_phys]
        if self.bias:
            out_sb = torch.cat([out_sb, flat[:, self.m_phys:]], dim=-1)  # bias = random walk
        return out_sb.reshape(B, S, m)

    def hx(self, sigmas: torch.Tensor) -> torch.Tensor:
        """[B,S,m] -> [B,S,1] routed (lagged) discharge (+ additive bias) over all sigma points."""
        B, S, m = sigmas.shape
        flat = sigmas.reshape(B * S, m).to(self.device, self.dtype)
        if not self.bias and not self.signed_routing_memory:
            return self._sm.h(flat).reshape(B, S, 1)
        # Compute the routed sum without the system model's physical-output clamp.
        # Signed assimilation memory must remain linear at zero so R -> 0 can
        # recover an exact positive discharge even when some sigma points are
        # negative.  The physical-output contract retains the final clamp.
        buf = flat[:, N_STATES:N_STATES + self.L]
        routed = (buf * self._sm.lag_weights).sum(dim=-1, keepdim=True)
        if self.bias:
            g = flat[:, self.m_phys:]
            routed = (1.0 + g) * routed if self.mult_bias else routed + g
        if not self.signed_routing_memory:
            routed = torch.clamp(routed, min=0.0)
        return routed.reshape(B, S, 1)
