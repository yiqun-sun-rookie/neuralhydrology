#!/usr/bin/env bash
set -eo pipefail

ROOT=/data1/home/sunyiq/kalmannet_tukf06_20260809
SOURCE="$ROOT/source"
DATA=/data1/home/sunyiq/neuralhydrology/data/camels_us

if [[ -z "${SLURM_JOB_ID:-}" ]]; then
  echo "TUKF06 preflight performs data hashing and must run inside a SLURM allocation" >&2
  exit 20
fi
if [[ "$(pwd -P)" != "$SOURCE" ]]; then
  echo "unexpected source directory: $(pwd -P)" >&2
  exit 21
fi
if [[ ! -f bundle_manifest.json ]]; then
  echo "bundle_manifest.json is absent" >&2
  exit 22
fi
if [[ "${SLURM_CPUS_PER_TASK:-0}" -lt 48 ]]; then
  echo "fewer than 48 allocated central processor cores" >&2
  exit 23
fi
available_kib=$(awk '/^MemAvailable:/ {print $2}' /proc/meminfo)
if [[ -z "$available_kib" || "$available_kib" -lt 50331648 ]]; then
  echo "less than 48 GiB available memory" >&2
  exit 24
fi

python - <<'PY'
import hashlib
import json
import pathlib
import platform
import sys

import numpy
import pandas
import scipy
import torch

root = pathlib.Path('.').resolve()
manifest = json.loads((root / 'bundle_manifest.json').read_text(encoding='utf-8'))
if manifest.get('experiment_id') != 'TUKF06_FULL_DIAGONAL_SEARCH_HEAD_TO_HEAD_V1':
    raise SystemExit('bundle experiment identifier mismatch')
for relative, expected in manifest['member_sha256'].items():
    path = root / relative
    if not path.is_file():
        raise SystemExit(f'missing bundle member: {relative}')
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        raise SystemExit(f'bundle member hash mismatch: {relative}')
if sys.version_info[:2] != (3, 11):
    raise SystemExit(f'Python 3.11 required, got {sys.version}')
print(json.dumps({
    'hostname': platform.node(),
    'python': sys.version,
    'torch': torch.__version__,
    'numpy': numpy.__version__,
    'pandas': pandas.__version__,
    'scipy': scipy.__version__,
}, sort_keys=True))
PY

python -u scripts/build_tukf06_hpc_bundle.py \
  --verify-inputs-only \
  --config configs/tukf06_full_diagonal_search_head_to_head_v1.json \
  --fingerprints configs/tukf06_data_fingerprints_v1.json \
  --data-root "$DATA" \
  --prior-csv inputs/hbv_lite_cma_local_full.csv \
  --basin-list inputs/conceptual_benchmark_camels_us_531_repro.txt \
  --loader-file vendor/hydroagent_data_loading.py

echo "TUKF06_PREFLIGHT_PASS mem_available_kib=$available_kib"
