#!/usr/bin/env bash

# Download-only preparation for the frozen private runtime.  This script must
# run on login4, outside Slurm.  It neither builds nor installs a package and it
# never modifies the shared nh_final environment.
set -eo pipefail

ROOT="/data1/home/sunyiq/kalmannet_tukf09_455_basin_zero_validation_target_variance_revision_v1_a800_exclusive_v2r14_20260909"
BUNDLE_ROOT="${ROOT}/bundle"
PROJECT_ROOT="${BUNDLE_ROOT}/kalmannet"
STATUS_ROOT="${ROOT}/status"
FINAL="${ROOT}/offline_inputs_v2r14"
ATTEMPT="${1:-}"
LOCK="${STATUS_ROOT}/offline_inputs_download.lock"
PYTHON="/data1/home/sunyiq/miniconda3/envs/nh_final/bin/python"
BINARY_LOCK="${PROJECT_ROOT}/hpc/tukf09_455_basin_revision_a800_exclusive_v2r14/runtime-binary.lock"
PSUTIL_LOCK="${PROJECT_ROOT}/hpc/tukf09_455_basin_revision_a800_exclusive_v2r14/psutil-source.lock"
STAGE_TOOL="${PROJECT_ROOT}/hpc/tukf09_455_basin_revision_a800_exclusive_v2r14/stage_and_train.py"

test -z "${SLURM_JOB_ID:-}"
case "$(hostname -s)" in
  login4) ;;
  *) echo "locked runtime inputs may only be acquired on login4" >&2; exit 60 ;;
esac
if [[ ! "${ATTEMPT}" =~ ^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$ ]]; then
  echo "a safe explicit download attempt identifier is required" >&2
  exit 61
fi

test -d "${ROOT}"
test ! -L "${ROOT}"
test -d "${BUNDLE_ROOT}"
test ! -L "${BUNDLE_ROOT}"
test -d "${PROJECT_ROOT}"
test ! -L "${PROJECT_ROOT}"
test -d "${STATUS_ROOT}"
test ! -L "${STATUS_ROOT}"
test -d "${ROOT}/logs"
test -x "${PYTHON}"
test -f "${BINARY_LOCK}"
test ! -L "${BINARY_LOCK}"
test "$(stat -c '%h' "${BINARY_LOCK}")" -eq 1
test -f "${PSUTIL_LOCK}"
test ! -L "${PSUTIL_LOCK}"
test "$(stat -c '%h' "${PSUTIL_LOCK}")" -eq 1
test -f "${STAGE_TOOL}"
test ! -L "${STAGE_TOOL}"

if [[ -L "${LOCK}" || ( -e "${LOCK}" && ! -f "${LOCK}" ) ]]; then
  echo "the offline-input acquisition lock is linked or irregular" >&2
  exit 62
fi
exec 8>> "${LOCK}"
test -f "${LOCK}"
test ! -L "${LOCK}"
test "$(stat -c '%h' "${LOCK}")" -eq 1
if ! flock -n 8; then
  echo "another offline-input acquisition holds the experiment lock" >&2
  exit 63
fi

export PYTHONNOUSERSITE=1
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH="${PROJECT_ROOT}"

if [[ -e "${FINAL}" || -L "${FINAL}" ]]; then
  test -d "${FINAL}"
  test ! -L "${FINAL}"
  "${PYTHON}" -B "${STAGE_TOOL}" verify-offline-inputs \
    --manifest "${FINAL}/manifest.json" \
    --wheelhouse "${FINAL}/wheelhouse" \
    --sourcehouse "${FINAL}/sourcehouse"
  echo "TUKF09_455_OFFLINE_RUNTIME_INPUTS_ALREADY_VERIFIED"
  exit 0
fi

# A fresh offline-input publication must precede every mutable scientific or
# training output in this unique v2r14 root.
for forbidden in \
  "${ROOT}/runtime_v2r14" \
  "${STATUS_ROOT}/staged_training_sources.json" \
  "${STATUS_ROOT}/preparation_probe.json" \
  "${STATUS_ROOT}/hpc_technical_admission.json" \
  "${STATUS_ROOT}/training_job_id.txt"; do
  if [[ -e "${forbidden}" || -L "${forbidden}" ]]; then
    echo "offline inputs were not frozen before mutable execution evidence: ${forbidden}" >&2
    exit 64
  fi
done

PENDING="${ROOT}/offline_inputs_v2r14.pending.${ATTEMPT}"
if [[ -e "${PENDING}" || -L "${PENDING}" ]]; then
  echo "download attempt path already exists and will not be reused" >&2
  exit 65
fi
mkdir "${PENDING}"
mkdir "${PENDING}/wheelhouse" "${PENDING}/sourcehouse" "${PENDING}/evidence"
WHEELHOUSE="${PENDING}/wheelhouse"
SOURCEHOUSE="${PENDING}/sourcehouse"
EVIDENCE="${PENDING}/evidence"

{
  printf '%s\n' 'python -m pip download --timeout 120 --retries 10 --no-cache-dir --no-deps --only-binary=:all: --require-hashes --dest WHEELHOUSE --requirement runtime-binary.lock'
  printf '%s\n' 'python -m pip download --timeout 120 --retries 10 --no-cache-dir --no-deps --no-binary=:all: --require-hashes --dest SOURCEHOUSE --requirement psutil-source.lock'
} > "${EVIDENCE}/download-command.txt"
: > "${EVIDENCE}/download-stdout.log"
: > "${EVIDENCE}/download-stderr.log"

"${PYTHON}" -B "${STAGE_TOOL}" snapshot-shared-environment \
  --output "${EVIDENCE}/shared-environment-before.json"
"${PYTHON}" -VV >> "${EVIDENCE}/download-stdout.log" 2>> "${EVIDENCE}/download-stderr.log"
"${PYTHON}" -m pip --version >> "${EVIDENCE}/download-stdout.log" 2>> "${EVIDENCE}/download-stderr.log"
uname -a >> "${EVIDENCE}/download-stdout.log" 2>> "${EVIDENCE}/download-stderr.log"
getconf GNU_LIBC_VERSION >> "${EVIDENCE}/download-stdout.log" 2>> "${EVIDENCE}/download-stderr.log"

"${PYTHON}" -m pip download \
  --timeout 120 \
  --retries 10 \
  --no-cache-dir \
  --no-deps \
  --only-binary=:all: \
  --require-hashes \
  --dest "${WHEELHOUSE}" \
  --requirement "${BINARY_LOCK}" \
  >> "${EVIDENCE}/download-stdout.log" 2>> "${EVIDENCE}/download-stderr.log"

"${PYTHON}" -m pip download \
  --timeout 120 \
  --retries 10 \
  --no-cache-dir \
  --no-deps \
  --no-binary=:all: \
  --require-hashes \
  --dest "${SOURCEHOUSE}" \
  --requirement "${PSUTIL_LOCK}" \
  >> "${EVIDENCE}/download-stdout.log" 2>> "${EVIDENCE}/download-stderr.log"

"${PYTHON}" -B "${STAGE_TOOL}" snapshot-shared-environment \
  --output "${EVIDENCE}/shared-environment-after.json"
cmp --silent \
  "${EVIDENCE}/shared-environment-before.json" \
  "${EVIDENCE}/shared-environment-after.json"

"${PYTHON}" -B "${STAGE_TOOL}" freeze-offline-inputs \
  --wheelhouse "${WHEELHOUSE}" \
  --sourcehouse "${SOURCEHOUSE}" \
  --download-command-file "${EVIDENCE}/download-command.txt" \
  --download-stdout-file "${EVIDENCE}/download-stdout.log" \
  --download-stderr-file "${EVIDENCE}/download-stderr.log" \
  --shared-environment-before "${EVIDENCE}/shared-environment-before.json" \
  --shared-environment-after "${EVIDENCE}/shared-environment-after.json" \
  --output "${PENDING}/manifest.json" \
  --authorize-offline-input-publication

mv --no-clobber --no-target-directory "${PENDING}" "${FINAL}"
if [[ -e "${PENDING}" || -L "${PENDING}" ]]; then
  echo "offline inputs were not published because the final path appeared concurrently" >&2
  exit 66
fi
"${PYTHON}" -B "${STAGE_TOOL}" verify-offline-inputs \
  --manifest "${FINAL}/manifest.json" \
  --wheelhouse "${FINAL}/wheelhouse" \
  --sourcehouse "${FINAL}/sourcehouse"

echo "TUKF09_455_OFFLINE_RUNTIME_INPUTS_PUBLISHED"
