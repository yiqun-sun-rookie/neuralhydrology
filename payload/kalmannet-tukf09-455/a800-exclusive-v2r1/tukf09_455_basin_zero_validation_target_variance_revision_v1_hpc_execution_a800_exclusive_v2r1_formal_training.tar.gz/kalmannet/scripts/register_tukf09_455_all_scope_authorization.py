"""Register the user's exact all-scope authorization for sequential gates."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
from pathlib import Path
import sys
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import tukf09_455_training_common as common
from scripts import tukf09_455_training_profile as profile


canonical_json_bytes = common.canonical_json_bytes


def _timestamp() -> str:
    return datetime.now(timezone.utc).isoformat()


def _file_record(project_root: Path, relative: Path) -> dict[str, Any]:
    path = common.require_regular_unlinked_file(
        project_root / relative, label="authorization frozen input", stop_at=project_root
    )
    return {
        "path": relative.as_posix(),
        "sha256": common.sha256_file(path),
        "size_bytes": path.stat().st_size,
    }


def register_all_scope_authorization(
    *,
    authorization_text: str,
    register: bool,
    project_root: Path = ROOT,
    registered_at_utc: str | None = None,
) -> dict[str, Any]:
    # The explicit mutation gate must precede every filesystem read.
    if register is not True:
        raise PermissionError("explicit authorization registration is required")
    if authorization_text != profile.EXACT_AUTHORIZATION_TEXT:
        raise PermissionError("authorization text must be exactly 全部授权")
    root = Path(project_root)
    frozen_inputs = {
        "scientific_contract": _file_record(root, profile.CONTRACT_RELATIVE),
        "independent_preflight_final_manifest": _file_record(
            root, profile.PREFLIGHT_FINAL_RELATIVE
        ),
        "filter_migration_config": _file_record(
            root, profile.FILTER_MIGRATION_CONFIG_RELATIVE
        ),
        "formal_training_execution_config": _file_record(
            root, profile.FORMAL_TRAINING_CONFIG_RELATIVE
        ),
        "formal_evaluation_algorithm_config": _file_record(
            root, profile.FORMAL_EVALUATION_CONFIG_RELATIVE
        ),
    }
    if (
        frozen_inputs["scientific_contract"]["sha256"]
        != profile.EXPECTED_CONTRACT_SHA256
        or frozen_inputs["independent_preflight_final_manifest"]["sha256"]
        != profile.EXPECTED_PREFLIGHT_FINAL_SHA256
    ):
        raise RuntimeError("contract or independent preflight identity changed")
    payload: dict[str, Any] = {
        "schema_version": profile.AUTHORIZATION_SCHEMA,
        "experiment_id": profile.EXPERIMENT_ID,
        "status": "ALL_REQUESTED_PHASES_AUTHORIZED_SEQUENTIAL_ADMISSION_REQUIRED",
        "registered_at_utc": registered_at_utc or _timestamp(),
        "authorization_text": authorization_text,
        "result_root": profile.OUTPUT_RELATIVE.as_posix(),
        "scope": {
            "result_migration_authorized": True,
            "filter_result_rebinding_authorized": True,
            "new_filter_optimization_authorized": False,
            "neural_training_authorized": True,
            "formal_evaluation_authorized": True,
        },
        "required_phase_order": [
            "filter_migration",
            "filter_migration_independent_verification",
            "formal_training_admission",
            "formal_training_root_initialization",
            "filter_rebinding_installation",
            "filter_rebinding_independent_verification",
            "neural_training",
            "training_selection_seal",
            "training_selection_independent_verification",
            "formal_evaluation_authorization",
            "formal_evaluation_admission",
            "formal_evaluation",
            "formal_evaluation_independent_verification",
        ],
        "frozen_inputs": frozen_inputs,
        "access_ledger": {
            "evaluation_array_reads": 0,
            "evaluation_predictions": 0,
            "evaluation_metrics": 0,
            "evaluation_outputs": 0,
        },
    }
    payload["authorization_record_sha256"] = hashlib.sha256(
        canonical_json_bytes(payload)
    ).hexdigest()
    destination = root / profile.AUTHORIZATION_RELATIVE
    common.atomic_write_json_exclusive(destination, payload)
    return payload


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--authorization-text", required=True)
    parser.add_argument("--register", action="store_true")
    return parser


def main() -> None:
    args = _parser().parse_args()
    record = register_all_scope_authorization(
        authorization_text=args.authorization_text,
        register=bool(args.register),
    )
    print(record["status"])


if __name__ == "__main__":
    main()
