"""Train and seal one TUKF09 backpropagation filter basin.

The runner deliberately has no evaluation-period argument or loader.  Its
production path receives an independently verified training admission, loads
only the frozen training and validation periods, and publishes exactly one
basin directory with one atomic directory rename.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from hashlib import sha256
from io import BytesIO
import json
import math
import os
from pathlib import Path
import shutil
import sys
from typing import Any, Callable, Mapping, Sequence
import uuid
import zipfile

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
for _extra in (str(ROOT), str(ROOT / "src")):
    if _extra not in sys.path:
        sys.path.insert(0, _extra)

from scripts.differentiable_ukf_hbvlite import run_hbvlite_corrected_ukf  # noqa: E402
from scripts.tukf09_confirmatory_common import (  # noqa: E402
    EXPERIMENT_ID,
    PARAMETER_NAMES,
    default_routed_initial_state,
    load_contract,
    routed_state_dimension,
)
from global_hydrology.models.differentiable_hbv_lite import (  # noqa: E402
    PARAM_NAMES as MODEL_PARAMETER_NAMES,
    recession_half_weights,
)
from global_hydrology.models.hbvlite_system_model import HBVLiteSystemModel  # noqa: E402
from global_hydrology.models.hbvlite_ukf_adapter import RoutedHBVLiteUKFAdapter  # noqa: E402


DEFAULT_CONFIG = ROOT / "configs" / "tukf09_backpropagation_vs_neural_backward_time_confirmation_v1.json"
DEFAULT_PREFLIGHT_ROOT = (
    ROOT
    / "artifacts"
    / "tukf09_backpropagation_vs_neural_backward_time_confirmation_v1"
    / "preflight"
)
DEFAULT_OUTPUT_ROOT = ROOT / "results" / "tukf09_backpropagation_vs_neural_backward_time_confirmation_v1"
DEFAULT_EXECUTION_CONFIG = ROOT / "configs" / "tukf09_formal_training_execution_v1.json"
DEFAULT_TRAINING_ADMISSION = (
    ROOT
    / "artifacts"
    / "tukf09_backpropagation_vs_neural_backward_time_confirmation_v1"
    / "training_admission"
    / "training_admission.json"
)
LEADS = (1, 2, 3)
UNIT_MEMBER_NAMES = (
    "access_ledger.json",
    "history.npz",
    "identity.json",
    "selection.json",
)


@dataclass(frozen=True)
class PeriodData:
    """One exact, finite period; no cross-period state is carried here."""

    forcing: torch.Tensor
    observations: torch.Tensor
    dates_ns: np.ndarray


@dataclass
class FilterContext:
    basin_id: str
    adapter: Any
    plain_model: HBVLiteSystemModel
    initial_state: torch.Tensor
    initial_covariance: torch.Tensor
    parameters: torch.Tensor
    project_mean: Callable[[torch.Tensor], torch.Tensor]
    base_observation_variance: float
    dimension: int
    device: torch.device
    dtype: torch.dtype


@dataclass(frozen=True)
class OptimizationHistory:
    theta_log: np.ndarray
    training_objective: np.ndarray
    validation_objective: np.ndarray
    selected_index: int
    training_queries: int
    validation_queries: int
    filter_passes: int
    gradient_updates: int


Objective = Callable[
    [FilterContext, torch.Tensor, torch.Tensor, torch.Tensor, bool, Mapping[str, Any], str],
    torch.Tensor,
]


def configure_single_thread_execution() -> dict[str, int]:
    """Pin one formal-training subprocess to one PyTorch CPU thread."""

    torch.set_num_threads(1)
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        # PyTorch permits setting the inter-operation pool only before its first
        # parallel operation. A fresh command-line unit must still already be at
        # the required value if another import initialized that pool.
        if int(torch.get_num_interop_threads()) != 1:
            raise
    counts = {
        "torch_intraop_thread_count": int(torch.get_num_threads()),
        "torch_interop_thread_count": int(torch.get_num_interop_threads()),
    }
    if counts != {
        "torch_intraop_thread_count": 1,
        "torch_interop_thread_count": 1,
    }:
        raise RuntimeError("formal filter unit did not enter one-thread PyTorch mode")
    return counts


def _normalize_basin_id(value: Any) -> str:
    if isinstance(value, bool):
        raise ValueError("basin identifier must be numeric text")
    text = str(value).strip()
    if not text or not text.isascii() or not text.isdigit() or len(text) > 8:
        raise ValueError(f"invalid basin identifier: {value!r}")
    return text.zfill(8)


def _json_bytes(payload: Any) -> bytes:
    return (
        json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")


def _sha256_bytes(content: bytes) -> str:
    return sha256(content).hexdigest()


def _sha256_file(path: Path) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _canonical_payload_sha256(payload: Any) -> str:
    content = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return _sha256_bytes(content)


def _deterministic_npz_bytes(arrays: Mapping[str, np.ndarray]) -> bytes:
    destination = BytesIO()
    with zipfile.ZipFile(
        destination,
        mode="w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    ) as archive:
        for name in sorted(arrays):
            array = np.ascontiguousarray(np.asarray(arrays[name]))
            if array.dtype.hasobject or not (
                np.issubdtype(array.dtype, np.number) or np.issubdtype(array.dtype, np.bool_)
            ):
                raise TypeError(f"history array {name} must be a non-object numeric array")
            if np.issubdtype(array.dtype, np.floating) and not np.isfinite(array).all():
                raise FloatingPointError(f"history array {name} is non-finite")
            member = BytesIO()
            np.lib.format.write_array(member, array, allow_pickle=False)
            info = zipfile.ZipInfo(f"{name}.npy", date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 0
            info.external_attr = 0
            archive.writestr(
                info,
                member.getvalue(),
                compress_type=zipfile.ZIP_DEFLATED,
                compresslevel=9,
            )
    return destination.getvalue()


def _ensure_within(root: Path, candidate: Path) -> None:
    root_resolved = Path(root).resolve()
    candidate_resolved = Path(candidate).resolve()
    try:
        candidate_resolved.relative_to(root_resolved)
    except ValueError as exc:
        raise ValueError(f"unit path escapes the output root: {candidate}") from exc


def _parameter_mapping(parameter_row: Mapping[str, Any] | Sequence[float]) -> dict[str, float]:
    if isinstance(parameter_row, Mapping):
        result: dict[str, float] = {}
        for name in PARAMETER_NAMES:
            if name in parameter_row:
                raw = parameter_row[name]
            elif f"p_{name}" in parameter_row:
                raw = parameter_row[f"p_{name}"]
            else:
                raise KeyError(f"parameter row is missing {name}")
            result[name] = float(raw)
    else:
        values = np.asarray(parameter_row, dtype=np.float64)
        if values.shape != (len(PARAMETER_NAMES),):
            raise ValueError("parameter vector must contain exactly thirteen values")
        result = {name: float(value) for name, value in zip(PARAMETER_NAMES, values)}
    if not np.isfinite(list(result.values())).all():
        raise FloatingPointError("physical parameters must all be finite")
    return result


def _as_forcing(value: Any) -> torch.Tensor:
    forcing = torch.as_tensor(value, dtype=torch.float64, device="cpu")
    if forcing.ndim == 2 and forcing.shape[-1] == 3:
        forcing = forcing.unsqueeze(1)
    if forcing.ndim != 3 or forcing.shape[1:] != (1, 3):
        raise ValueError("forcing must have shape [days, 3] or [days, 1, 3]")
    if not bool(torch.isfinite(forcing).all()):
        raise FloatingPointError("forcing contains a non-finite value")
    return forcing.contiguous()


def _as_observations(value: Any) -> torch.Tensor:
    observations = torch.as_tensor(value, dtype=torch.float64, device="cpu")
    if observations.ndim == 1:
        observations = observations.unsqueeze(1)
    if observations.ndim != 2 or observations.shape[1] != 1:
        raise ValueError("observations must have shape [days] or [days, 1]")
    if not bool(torch.isfinite(observations).all()):
        raise FloatingPointError("observations contain a non-finite value")
    if bool(torch.any(observations < 0.0)):
        raise ValueError("observations must be nonnegative")
    return observations.contiguous()


def normalize_period_data(
    value: PeriodData | Mapping[str, Any] | Sequence[Any],
    *,
    expected_day_count: int | None = None,
) -> PeriodData:
    if isinstance(value, PeriodData):
        forcing_raw, observations_raw, dates_raw = (
            value.forcing,
            value.observations,
            value.dates_ns,
        )
    elif all(hasattr(value, name) for name in ("forcing", "observations", "dates_ns")):
        forcing_raw = getattr(value, "forcing")
        observations_raw = getattr(value, "observations")
        dates_raw = getattr(value, "dates_ns")
    elif isinstance(value, Mapping):
        forcing_raw = value["forcing"]
        observations_raw = value["observations"]
        dates_raw = value.get("dates_ns", value.get("dates"))
    elif isinstance(value, Sequence) and not isinstance(value, (str, bytes)) and len(value) == 3:
        forcing_raw, observations_raw, dates_raw = value
    else:
        raise TypeError("period data must provide forcing, observations, and dates")
    forcing = _as_forcing(forcing_raw)
    observations = _as_observations(observations_raw)
    if forcing.shape[0] != observations.shape[0]:
        raise ValueError("forcing and observation day counts differ")
    if expected_day_count is not None and forcing.shape[0] != int(expected_day_count):
        raise ValueError("period day count differs from the frozen contract")
    if dates_raw is None:
        raise ValueError("period dates are required")
    dates = np.asarray(dates_raw)
    if np.issubdtype(dates.dtype, np.datetime64):
        dates_ns = dates.astype("datetime64[ns]").astype("<i8")
    else:
        dates_ns = np.asarray(dates, dtype="<i8")
    if dates_ns.shape != (forcing.shape[0],):
        raise ValueError("period dates do not match the day count")
    if len(dates_ns) and np.any(dates_ns[1:] <= dates_ns[:-1]):
        raise ValueError("period dates must be strictly increasing")
    return PeriodData(forcing=forcing, observations=observations, dates_ns=dates_ns)


def build_causal_filter_context(
    basin_id: str,
    parameter_row: Mapping[str, Any] | Sequence[float],
    training_observations: torch.Tensor | np.ndarray,
    contract: Mapping[str, Any],
) -> FilterContext:
    """Build the parameter-only period-local context; no saved state is accepted."""

    basin = _normalize_basin_id(basin_id)
    row = _parameter_mapping(parameter_row)
    if tuple(MODEL_PARAMETER_NAMES) != tuple(PARAMETER_NAMES):
        raise RuntimeError("HBV-light model parameter order differs from the frozen contract")
    parameters = torch.tensor(
        [[row[name] for name in PARAMETER_NAMES]], dtype=torch.float64, device="cpu"
    )
    dimension = routed_state_dimension(row)
    lag = parameters[:, -1:]
    routing_length = dimension - 5
    weights = recession_half_weights(lag, routing_length)
    adapter = RoutedHBVLiteUKFAdapter(
        parameters,
        weights,
        device=torch.device("cpu"),
        dtype=torch.float64,
        clamp_storage=True,
    )
    if int(adapter.dim_x) != dimension:
        raise RuntimeError("routed state dimension differs from the parameter-only derivation")
    plain_model = HBVLiteSystemModel(
        parameters,
        emission="routed",
        lag_weights=weights,
        device=torch.device("cpu"),
        dtype=torch.float64,
    )
    field_capacity = parameters[:, PARAMETER_NAMES.index("parFC")]

    def project_mean(state: torch.Tensor) -> torch.Tensor:
        storages = torch.clamp(state[:, :5], min=0.0)
        soil = torch.clamp(storages[:, 2:3], max=field_capacity)
        routing = torch.clamp(state[:, 5:], min=0.0)
        return torch.cat([storages[:, :2], soil, storages[:, 3:5], routing], dim=-1)

    initial_state = torch.tensor(
        np.array(default_routed_initial_state(row), dtype=np.float64, copy=True),
        dtype=torch.float64,
        device="cpu",
    ).reshape(1, dimension)
    expected_initial = contract["filter_system"]["initialization"]
    if expected_initial.get("forbid_prior_x0_table") is not True or expected_initial.get(
        "forbid_cal_final_2008_state_columns"
    ) is not True:
        raise RuntimeError("causal initial-state prohibitions changed")
    covariance_diagonal = float(expected_initial["initial_covariance_diagonal"])
    if covariance_diagonal != 0.001:
        raise ValueError("initial covariance diagonal differs from 0.001")
    initial_covariance = (
        torch.eye(dimension, dtype=torch.float64, device="cpu").unsqueeze(0)
        * covariance_diagonal
    )
    observations = _as_observations(training_observations)
    observation_std = float(np.std(observations[:, 0].numpy(), ddof=0))
    if not math.isfinite(observation_std):
        raise FloatingPointError("training observation standard deviation is non-finite")
    base_variance = max((0.05 * observation_std) ** 2, 1e-10)
    return FilterContext(
        basin_id=basin,
        adapter=adapter,
        plain_model=plain_model,
        initial_state=initial_state,
        initial_covariance=initial_covariance,
        parameters=parameters,
        project_mean=project_mean,
        base_observation_variance=base_variance,
        dimension=dimension,
        device=torch.device("cpu"),
        dtype=torch.float64,
    )


def log_bound_vectors(
    state_dimension: int,
    contract: Mapping[str, Any],
) -> tuple[torch.Tensor, torch.Tensor]:
    space = contract["filter_system"]["noise_parameter_space"]
    process = space["process_diagonal"]
    observation = space["observation"]
    dimension = int(state_dimension)
    if dimension < 6:
        raise ValueError("state dimension must include five storages and routing")
    lower = torch.log(
        torch.tensor(
            [float(process["lower"])] * dimension + [float(observation["lower"])],
            dtype=torch.float64,
        )
    )
    upper = torch.log(
        torch.tensor(
            [float(process["upper"])] * dimension + [float(observation["upper"])],
            dtype=torch.float64,
        )
    )
    return lower, upper


def decode_theta(
    theta_log: torch.Tensor,
    state_dimension: int,
    contract: Mapping[str, Any],
) -> tuple[torch.Tensor, torch.Tensor]:
    theta = torch.as_tensor(theta_log)
    dimension = int(state_dimension)
    if theta.dtype != torch.float64 or theta.shape != (dimension + 1,):
        raise ValueError("theta must be a float64 state-dimension-plus-one vector")
    if not bool(torch.isfinite(theta).all()):
        raise FloatingPointError("theta contains a non-finite value")
    lower, upper = log_bound_vectors(dimension, contract)
    lower = lower.to(theta.device)
    upper = upper.to(theta.device)
    if bool(torch.any(theta < lower)) or bool(torch.any(theta > upper)):
        raise ValueError("theta lies outside the frozen natural-log bounds")
    actual = torch.exp(theta)
    return actual[:-1], actual[-1]


def build_anchor_points(state_dimension: int, contract: Mapping[str, Any]) -> np.ndarray:
    dimension = int(state_dimension)
    if dimension < 6:
        raise ValueError("state dimension must include routing")
    anchors = contract["filter_system"]["anchors"]
    if len(anchors) != 8:
        raise ValueError("the filter contract must contain exactly eight starts")
    rows: list[list[float]] = []
    for anchor in anchors:
        actual = (
            [float(anchor["storage_q"])] * 5
            + [float(anchor["routing_q"])] * (dimension - 5)
            + [float(anchor["r_b"])]
        )
        if not np.isfinite(actual).all() or np.any(np.asarray(actual) <= 0.0):
            raise ValueError("anchor values must be finite and positive")
        rows.append(actual)
    result = np.log(np.asarray(rows, dtype=np.float64))
    lower, upper = log_bound_vectors(dimension, contract)
    lower_np, upper_np = lower.numpy(), upper.numpy()
    if np.any(result < lower_np) or np.any(result > upper_np):
        raise ValueError("an anchor lies outside the frozen bounds")
    return result


def multilead_torch(
    plain_model: HBVLiteSystemModel,
    posterior: torch.Tensor,
    forcing: torch.Tensor,
) -> dict[int, tuple[torch.Tensor, torch.Tensor]]:
    starts = int(posterior.shape[0]) - max(LEADS)
    if starts < 1:
        raise ValueError("period is shorter than the maximum forecast lead")
    state = posterior[:starts]
    result: dict[int, tuple[torch.Tensor, torch.Tensor]] = {}
    for lead in LEADS:
        state = plain_model.f(state, forcing[lead : starts + lead, 0, :])
        forecast = plain_model.h(state)[:, 0]
        indices = torch.arange(
            lead,
            lead + forecast.shape[0],
            dtype=torch.long,
            device=forecast.device,
        )
        result[lead] = (forecast, indices)
    return result


def run_parameterized_filter(
    context: FilterContext,
    forcing: torch.Tensor,
    observations: torch.Tensor,
    theta_log: torch.Tensor,
    contract: Mapping[str, Any],
) -> dict[str, torch.Tensor]:
    process_diagonal, r_b = decode_theta(theta_log, context.dimension, contract)
    result = run_hbvlite_corrected_ukf(
        context.adapter,
        forcing.to(dtype=torch.float64, device="cpu"),
        observations.to(dtype=torch.float64, device="cpu"),
        context.initial_state.clone(),
        context.initial_covariance.clone(),
        process_diagonal,
        base_observation_variance=context.base_observation_variance,
        r_b=r_b,
        localization_multiplier=1.0,
        project_mean=context.project_mean,
    )
    for name in ("posterior_state", "prior_state", "prediction"):
        if name in result and not bool(torch.isfinite(result[name]).all()):
            raise FloatingPointError(f"non-finite {name} for {context.basin_id}")
    return result


def equal_weight_multilead_mse(
    forecasts: Mapping[int, tuple[torch.Tensor, torch.Tensor]],
    observations: torch.Tensor,
    *,
    period_name: str,
    contract: Mapping[str, Any],
) -> tuple[torch.Tensor, dict[int, int]]:
    if period_name not in ("training", "validation"):
        raise ValueError("filter training objective accepts only training or validation")
    objective_contract = contract["filter_system"]["objective"]
    warmup = int(objective_contract["first_scoring_index"])
    expected_raw = objective_contract["expected_scored_days_per_basin_by_period_and_lead"][
        period_name
    ]
    target_source = _as_observations(observations)
    total = torch.zeros((), dtype=torch.float64)
    counts: dict[int, int] = {}
    for lead in LEADS:
        if lead not in forecasts:
            raise KeyError(f"missing lead-{lead} forecast")
        prediction, target_indices = forecasts[lead]
        if prediction.dtype != torch.float64:
            raise ValueError("filter forecast must be float64")
        if target_indices.dtype != torch.long or target_indices.ndim != 1:
            raise ValueError("target indices must be a one-dimensional long tensor")
        if prediction.shape != target_indices.shape:
            raise ValueError("forecast and target-index shapes differ")
        scoring = target_indices >= warmup
        selected_indices = target_indices[scoring]
        selected_prediction = prediction[scoring]
        target = target_source.to(prediction.device)[selected_indices, 0]
        if not bool(torch.isfinite(selected_prediction).all()) or not bool(
            torch.isfinite(target).all()
        ):
            raise FloatingPointError("objective input contains a non-finite value")
        count = int(target.numel())
        expected = int(expected_raw[str(lead)])
        if count != expected:
            raise RuntimeError(
                f"{period_name} lead-{lead} count {count} differs from frozen {expected}"
            )
        counts[lead] = count
        total = total + torch.mean((selected_prediction - target) ** 2)
    value = total / float(len(LEADS))
    if value.dtype != torch.float64 or not bool(torch.isfinite(value)):
        raise FloatingPointError("filter objective is non-finite or not float64")
    return value, counts


def multilead_objective(
    context: FilterContext,
    forcing: torch.Tensor,
    observations: torch.Tensor,
    theta_log: torch.Tensor,
    grad: bool,
    contract: Mapping[str, Any],
    period_name: str,
) -> torch.Tensor:
    manager = torch.enable_grad() if grad else torch.no_grad()
    with manager:
        filtered = run_parameterized_filter(
            context, forcing, observations, theta_log, contract
        )
        forecasts = multilead_torch(
            context.plain_model,
            filtered["posterior_state"][:, 0, :],
            forcing,
        )
        value, _ = equal_weight_multilead_mse(
            forecasts,
            observations,
            period_name=period_name,
            contract=contract,
        )
    return value


def choose_checkpoint(
    theta_log: np.ndarray,
    training_objective: np.ndarray,
    validation_objective: np.ndarray,
) -> int:
    theta = np.asarray(theta_log, dtype=np.float64)
    training = np.asarray(training_objective, dtype=np.float64)
    validation = np.asarray(validation_objective, dtype=np.float64)
    if theta.ndim != 2 or training.shape != (len(theta),) or validation.shape != (len(theta),):
        raise ValueError("checkpoint history shapes differ")
    if len(theta) < 1 or not np.isfinite(theta).all() or not np.isfinite(training).all() \
            or not np.isfinite(validation).all():
        raise FloatingPointError("checkpoint history is empty or non-finite")
    actual = np.exp(theta)
    if not np.isfinite(actual).all() or np.any(actual <= 0.0):
        raise FloatingPointError("actual checkpoint parameters are non-finite or non-positive")
    return min(
        range(len(theta)),
        key=lambda index: (
            float(validation[index]),
            float(training[index]),
            tuple(float(value) for value in actual[index]),
            int(index),
        ),
    )


def run_backpropagation_search(
    context: FilterContext,
    training: PeriodData,
    validation: PeriodData,
    anchors: np.ndarray,
    contract: Mapping[str, Any],
    *,
    objective_fn: Objective = multilead_objective,
) -> OptimizationHistory:
    settings = contract["filter_system"]["backpropagation"]
    anchor_array = np.asarray(anchors, dtype=np.float64)
    starts = int(settings["starts"])
    updates = int(settings["updates_per_start"])
    if starts != 8 or updates != 31 or anchor_array.shape != (
        starts,
        context.dimension + 1,
    ):
        raise ValueError("backpropagation starts, updates, or anchor shape changed")
    if settings["precision"] != "float64" or settings["checkpoint_order"] != (
        "round_robin_by_step_then_start"
    ):
        raise ValueError("backpropagation precision or checkpoint order changed")
    lower, upper = log_bound_vectors(context.dimension, contract)
    parameters = [
        torch.nn.Parameter(torch.tensor(row, dtype=torch.float64, device="cpu"))
        for row in anchor_array
    ]
    betas = tuple(float(value) for value in settings["adam_betas"])
    optimizers = [
        torch.optim.Adam(
            [theta],
            lr=float(settings["learning_rate"]),
            betas=betas,
            eps=float(settings["adam_epsilon"]),
            weight_decay=float(settings["weight_decay"]),
            amsgrad=bool(settings["amsgrad"]),
        )
        for theta in parameters
    ]
    theta_rows: list[np.ndarray] = []
    training_values: list[float] = []
    validation_values: list[float] = []
    training_queries = 0
    validation_queries = 0
    gradient_updates = 0
    for step in range(updates + 1):
        for start_index, (theta, optimizer) in enumerate(zip(parameters, optimizers)):
            optimizer.zero_grad(set_to_none=True)
            training_loss = objective_fn(
                context,
                training.forcing,
                training.observations,
                theta,
                True,
                contract,
                "training",
            )
            training_queries += 1
            validation_loss = objective_fn(
                context,
                validation.forcing,
                validation.observations,
                theta,
                False,
                contract,
                "validation",
            )
            validation_queries += 1
            row = theta.detach().cpu().numpy().astype(np.float64, copy=True)
            training_value = float(training_loss.detach())
            validation_value = float(validation_loss.detach())
            if not np.isfinite(row).all() or not np.isfinite(
                [training_value, validation_value]
            ).all():
                raise FloatingPointError(
                    f"non-finite checkpoint at start {start_index}, step {step}"
                )
            theta_rows.append(row)
            training_values.append(training_value)
            validation_values.append(validation_value)
            if step == updates:
                continue
            training_loss.backward()
            if theta.grad is None or theta.grad.dtype != torch.float64 or not bool(
                torch.isfinite(theta.grad).all()
            ):
                raise FloatingPointError(
                    f"non-finite float64 gradient at start {start_index}, step {step}"
                )
            optimizer.step()
            with torch.no_grad():
                if not bool(torch.isfinite(theta).all()):
                    raise FloatingPointError(
                        f"non-finite parameter at start {start_index}, step {step}"
                    )
                theta.clamp_(min=lower, max=upper)
            gradient_updates += 1
    theta_array = np.stack(theta_rows, axis=0)
    training_array = np.asarray(training_values, dtype=np.float64)
    validation_array = np.asarray(validation_values, dtype=np.float64)
    expected_checkpoints = int(settings["checkpoints_total"])
    expected_gradients = int(settings["backpropagations_per_basin"])
    if (
        theta_array.shape != (expected_checkpoints, context.dimension + 1)
        or training_queries != int(settings["training_queries_per_basin"])
        or validation_queries != int(settings["validation_queries_per_basin"])
        or gradient_updates != expected_gradients
        or 2 * expected_checkpoints != int(settings["filter_passes_per_basin"])
    ):
        raise AssertionError("backpropagation did not consume the exact frozen budget")
    return OptimizationHistory(
        theta_log=theta_array,
        training_objective=training_array,
        validation_objective=validation_array,
        selected_index=choose_checkpoint(theta_array, training_array, validation_array),
        training_queries=training_queries,
        validation_queries=validation_queries,
        filter_passes=training_queries + validation_queries,
        gradient_updates=gradient_updates,
    )


def _period_identity(period: PeriodData) -> str:
    digest = sha256()
    for name, array in (
        ("dates_ns", np.asarray(period.dates_ns, dtype="<i8")),
        ("forcing", period.forcing[:, 0, :].numpy().astype("<f8", copy=False)),
        ("observations", period.observations[:, 0].numpy().astype("<f8", copy=False)),
    ):
        contiguous = np.ascontiguousarray(array)
        digest.update(name.encode("utf-8"))
        digest.update(str(contiguous.dtype).encode("ascii"))
        digest.update(np.asarray(contiguous.shape, dtype="<i8").tobytes())
        digest.update(contiguous.tobytes())
    return digest.hexdigest()


def _manifest_payload(basin_id: str, members: Mapping[str, bytes]) -> dict[str, Any]:
    if set(members) != set(UNIT_MEMBER_NAMES):
        raise ValueError("filter unit must contain exactly four non-manifest members")
    return {
        "schema_version": "tukf09_filter_unit_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "unit_type": "filter_basin",
        "unit_id": basin_id,
        "file_count": 4,
        "files": {
            name: {
                "sha256": _sha256_bytes(content),
                "size_bytes": len(content),
            }
            for name, content in sorted(members.items())
        },
    }


def _publish_unit(output_root: Path, basin_id: str, members: Mapping[str, bytes]) -> Path:
    root = Path(output_root)
    filter_root = root / "filter"
    final = filter_root / f"basin_{basin_id}"
    _ensure_within(root, final)
    if root.exists() and root.is_symlink():
        raise RuntimeError("output root must not be a symbolic link")
    if filter_root.exists() and filter_root.is_symlink():
        raise RuntimeError("filter output root must not be a symbolic link")
    if final.exists() or final.is_symlink():
        raise FileExistsError(f"filter basin unit already exists: {final}")
    filter_root.mkdir(parents=True, exist_ok=True)
    pending = filter_root / f".basin_{basin_id}.pending-{os.getpid()}-{uuid.uuid4().hex}"
    _ensure_within(root, pending)
    pending.mkdir(mode=0o700)
    try:
        for name, content in members.items():
            with (pending / name).open("xb") as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
        manifest = _manifest_payload(basin_id, members)
        manifest_bytes = _json_bytes(manifest)
        with (pending / "manifest.sha256.json").open("xb") as handle:
            handle.write(manifest_bytes)
            handle.flush()
            os.fsync(handle.fileno())
        actual_names = {path.name for path in pending.iterdir()}
        expected_names = set(UNIT_MEMBER_NAMES) | {"manifest.sha256.json"}
        if actual_names != expected_names or any(path.is_symlink() for path in pending.iterdir()):
            raise RuntimeError("pending filter unit members differ from the exact layout")
        if final.exists() or final.is_symlink():
            raise FileExistsError(f"filter basin unit appeared during publication: {final}")
        os.replace(pending, final)
    except BaseException:
        if pending.exists():
            shutil.rmtree(pending)
        raise
    return final


def _build_unit_payloads(
    *,
    basin_id: str,
    context: FilterContext,
    history: OptimizationHistory,
    contract: Mapping[str, Any],
    parameter_row: Mapping[str, float],
    training: PeriodData,
    validation: PeriodData,
    provenance: Mapping[str, Any],
) -> tuple[dict[str, bytes], dict[str, Any]]:
    selected = int(history.selected_index)
    selected_theta = history.theta_log[selected]
    selected_actual = np.exp(selected_theta)
    if not np.isfinite(selected_actual).all() or np.any(selected_actual <= 0.0):
        raise FloatingPointError("selected filter parameters are non-finite or non-positive")
    expected_counts = contract["filter_system"]["objective"][
        "expected_scored_days_per_basin_by_period_and_lead"
    ]
    identity = {
        "schema_version": "tukf09_filter_unit_identity_v1",
        "experiment_id": EXPERIMENT_ID,
        "unit_type": "filter_basin",
        "unit_id": basin_id,
        "state_dimension": context.dimension,
        "parameter_names": list(PARAMETER_NAMES),
        "physical_parameter_sha256": _canonical_payload_sha256(
            [float(parameter_row[name]) for name in PARAMETER_NAMES]
        ),
        "training_period_sha256": _period_identity(training),
        "validation_period_sha256": _period_identity(validation),
        "initial_state": context.initial_state[0].tolist(),
        "initial_covariance_diagonal": 0.001,
        "base_observation_variance": context.base_observation_variance,
        "precision": "float64",
        "torch_intraop_thread_count": int(torch.get_num_threads()),
        "torch_interop_thread_count": int(torch.get_num_interop_threads()),
        "starts": 8,
        "updates_per_start": 31,
        "checkpoint_order": "round_robin_by_step_then_start",
        "runner_sha256": _sha256_file(Path(__file__).resolve()),
        **dict(provenance),
    }
    history_arrays = {
        "checkpoint_index": np.arange(256, dtype=np.int64),
        "start_index": np.tile(np.arange(8, dtype=np.int64), 32),
        "step_index": np.repeat(np.arange(32, dtype=np.int64), 8),
        "theta_log": history.theta_log.astype(np.float64, copy=False),
        "training_objective": history.training_objective.astype(np.float64, copy=False),
        "validation_objective": history.validation_objective.astype(np.float64, copy=False),
    }
    selection = {
        "schema_version": "tukf09_filter_unit_selection_v1",
        "experiment_id": EXPERIMENT_ID,
        "unit_type": "filter_basin",
        "unit_id": basin_id,
        "status": "FILTER_BASIN_SELECTED",
        "selected_index": selected,
        "selected_theta_log": selected_theta.tolist(),
        "selected_process_diagonal": selected_actual[:-1].tolist(),
        "selected_r_b": float(selected_actual[-1]),
        "selected_training_objective": float(history.training_objective[selected]),
        "selected_validation_objective": float(history.validation_objective[selected]),
        "checkpoint_count": 256,
        "training_query_count": history.training_queries,
        "validation_query_count": history.validation_queries,
        "filter_pass_count": history.filter_passes,
        "gradient_update_count": history.gradient_updates,
        "scored_target_count_by_period_and_lead": expected_counts,
    }
    access_ledger = {
        "schema_version": "tukf09_filter_unit_access_ledger_v1",
        "experiment_id": EXPERIMENT_ID,
        "unit_type": "filter_basin",
        "unit_id": basin_id,
        "training_period_loaded": True,
        "validation_period_loaded": True,
        "evaluation_array_read_count": 0,
        "evaluation_prediction_count": 0,
        "evaluation_metric_count": 0,
        "evaluation_output_write_count": 0,
        "formal_evaluation_authorized": False,
    }
    members = {
        "identity.json": _json_bytes(identity),
        "history.npz": _deterministic_npz_bytes(history_arrays),
        "selection.json": _json_bytes(selection),
        "access_ledger.json": _json_bytes(access_ledger),
    }
    return members, selection


def _get_attribute(value: Any, name: str) -> Any:
    if isinstance(value, Mapping):
        return value[name]
    return getattr(value, name)


def _load_production_inputs(
    *,
    basin_id: str,
    config_path: Path,
    preflight_root: Path,
    authorization_path: Path,
    execution_config_path: Path,
    training_admission_path: Path,
    output_root: Path,
) -> tuple[dict[str, Any], dict[str, float], PeriodData, PeriodData, dict[str, Any]]:
    # Delayed import keeps the runner testable without widening the public common layer.
    from scripts import tukf09_training_common as training_common  # noqa: WPS433

    technical_admission = training_common.load_and_verify_training_admission(
        training_admission_path,
        execution_config_path,
        [
            ROOT / relative
            for relative in training_common.REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS
        ],
    )
    training_common.verify_initialized_training_root(
        output_root=output_root,
        config_path=config_path,
        authorization=authorization_path,
        execution_config=execution_config_path,
        training_admission=training_admission_path,
        training_admission_record=technical_admission,
    )
    preflight_final = Path(preflight_root) / "independent" / "manifest.final.sha256.json"
    admission = training_common.verify_preflight_for_training(
        config_path,
        preflight_final,
        authorization_path,
        output_root,
        require_output_absent=False,
        recompute_training_validation_semantics=False,
        verify_all_raw_source_bytes=False,
    )
    contract = load_contract(config_path)
    basin_ids = tuple(str(value).zfill(8) for value in _get_attribute(admission, "ordered_basin_ids"))
    if len(basin_ids) != 456 or len(set(basin_ids)) != 456:
        raise RuntimeError("training admission must contain exactly 456 unique basins")
    if basin_id not in basin_ids:
        raise ValueError("requested basin is outside the admitted 456-basin population")
    parameter_names = tuple(_get_attribute(admission, "parameter_names"))
    if parameter_names != tuple(PARAMETER_NAMES):
        raise RuntimeError("admitted physical-parameter order changed")
    parameter_values = np.asarray(_get_attribute(admission, "parameter_values"), dtype=np.float64)
    if parameter_values.shape != (456, 13) or not np.isfinite(parameter_values).all():
        raise RuntimeError("admitted parameter matrix differs from 456 by 13 finite values")
    index = basin_ids.index(basin_id)
    parameter_row = {
        name: float(parameter_values[index, column])
        for column, name in enumerate(parameter_names)
    }
    loaded_periods = training_common.load_training_validation_periods(
        admission, [basin_id]
    )
    if set(loaded_periods) != {basin_id}:
        raise RuntimeError("period loader returned an unexpected basin set")
    basin_periods = loaded_periods[basin_id]
    if set(basin_periods) != {"training", "validation"}:
        raise RuntimeError("period loader returned a forbidden or missing period")
    training = normalize_period_data(
        basin_periods["training"],
        expected_day_count=int(contract["periods"]["training"]["day_count"]),
    )
    validation = normalize_period_data(
        basin_periods["validation"],
        expected_day_count=int(contract["periods"]["validation"]["day_count"]),
    )
    access_count = int(_get_attribute(admission, "evaluation_access_count"))
    provenance = {
        "contract_file_sha256": str(_get_attribute(admission, "contract_sha256")),
        "preflight_final_manifest_sha256": str(
            _get_attribute(admission, "preflight_final_manifest_sha256")
        ),
        "authorization_file_sha256": str(
            _get_attribute(_get_attribute(admission, "authorization"), "authorization_file_sha256")
        ),
        "training_admission_evaluation_access_count": access_count,
        "training_admission_record_sha256": str(
            technical_admission["training_admission_record_sha256"]
        ),
    }
    if technical_admission.get("access_ledger") != {
        "evaluation_array_reads": 0,
        "evaluation_predictions": 0,
        "evaluation_metrics": 0,
        "evaluation_outputs": 0,
    }:
        raise RuntimeError("technical training admission recorded evaluation access")
    if provenance["training_admission_evaluation_access_count"] != 0:
        raise RuntimeError("training admission recorded evaluation access")
    return contract, parameter_row, training, validation, provenance


def train_one_basin(
    basin_id: str,
    *,
    output_root: Path,
    execute_formal_training: bool,
    config_path: Path | None = None,
    preflight_root: Path | None = None,
    authorization_path: Path | None = None,
    execution_config_path: Path | None = None,
    training_admission_path: Path | None = None,
    contract: Mapping[str, Any] | None = None,
    parameter_row: Mapping[str, Any] | Sequence[float] | None = None,
    training_period: PeriodData | Mapping[str, Any] | Sequence[Any] | None = None,
    validation_period: PeriodData | Mapping[str, Any] | Sequence[Any] | None = None,
    objective_fn: Objective = multilead_objective,
    provenance: Mapping[str, Any] | None = None,
    allow_synthetic_test_inputs: bool = False,
) -> dict[str, Any]:
    """Train one admitted basin and atomically publish its immutable unit."""

    # This acknowledgement is intentionally the first gate, before any file or data read.
    if execute_formal_training is not True:
        raise PermissionError("formal filter training requires explicit authorization")
    basin = _normalize_basin_id(basin_id)

    injected_values = (contract, parameter_row, training_period, validation_period)
    any_injected = any(value is not None for value in injected_values)
    injected = all(value is not None for value in injected_values)
    if any_injected and not injected:
        raise ValueError("injected training inputs must be supplied as one complete set")
    if injected:
        if allow_synthetic_test_inputs is not True:
            raise PermissionError("injected training inputs are forbidden outside synthetic tests")
        if Path(output_root).resolve(strict=False) == DEFAULT_OUTPUT_ROOT.resolve(strict=False):
            raise PermissionError("the formal result root forbids injected training inputs")
    elif (
        allow_synthetic_test_inputs is True
        or objective_fn is not multilead_objective
        or provenance is not None
    ):
        raise PermissionError("synthetic overrides require one complete injected test input set")

    destination = Path(output_root) / "filter" / f"basin_{basin}"
    if destination.exists() or destination.is_symlink():
        raise FileExistsError(f"filter basin unit already exists: {destination}")

    if injected:
        active_contract = dict(contract)  # type: ignore[arg-type]
        active_parameters = _parameter_mapping(parameter_row)  # type: ignore[arg-type]
        training = normalize_period_data(
            training_period,  # type: ignore[arg-type]
            expected_day_count=int(active_contract["periods"]["training"]["day_count"]),
        )
        validation = normalize_period_data(
            validation_period,  # type: ignore[arg-type]
            expected_day_count=int(active_contract["periods"]["validation"]["day_count"]),
        )
        active_provenance = dict(provenance or {})
    else:
        if any(
            value is None
            for value in (
                config_path,
                preflight_root,
                authorization_path,
                execution_config_path,
                training_admission_path,
            )
        ):
            raise ValueError(
                "production training requires config, preflight, authorization, "
                "execution-config, and training-admission paths"
            )
        configure_single_thread_execution()
        (
            active_contract,
            active_parameters,
            training,
            validation,
            active_provenance,
        ) = _load_production_inputs(
            basin_id=basin,
            config_path=Path(config_path),
            preflight_root=Path(preflight_root),
            authorization_path=Path(authorization_path),
            execution_config_path=Path(execution_config_path),
            training_admission_path=Path(training_admission_path),
            output_root=Path(output_root),
        )
    context = build_causal_filter_context(
        basin,
        active_parameters,
        training.observations,
        active_contract,
    )
    anchors = build_anchor_points(context.dimension, active_contract)
    history = run_backpropagation_search(
        context,
        training,
        validation,
        anchors,
        active_contract,
        objective_fn=objective_fn,
    )
    members, selection = _build_unit_payloads(
        basin_id=basin,
        context=context,
        history=history,
        contract=active_contract,
        parameter_row=active_parameters,
        training=training,
        validation=validation,
        provenance=active_provenance,
    )
    unit_dir = _publish_unit(Path(output_root), basin, members)
    manifest_path = unit_dir / "manifest.sha256.json"
    return {
        **selection,
        "unit_directory": str(unit_dir),
        "unit_manifest_sha256": _sha256_file(manifest_path),
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Train one authorized TUKF09 backpropagation filter basin."
    )
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--preflight-root", type=Path, default=DEFAULT_PREFLIGHT_ROOT)
    parser.add_argument("--authorization", type=Path, required=True)
    parser.add_argument("--execution-config", type=Path, required=True)
    parser.add_argument("--training-admission", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--basin-id", required=True)
    parser.add_argument("--execute-formal-training", action="store_true")
    args = parser.parse_args()
    result = train_one_basin(
        args.basin_id,
        config_path=args.config,
        preflight_root=args.preflight_root,
        authorization_path=args.authorization,
        execution_config_path=args.execution_config,
        training_admission_path=args.training_admission,
        output_root=args.output_root,
        execute_formal_training=args.execute_formal_training,
    )
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
