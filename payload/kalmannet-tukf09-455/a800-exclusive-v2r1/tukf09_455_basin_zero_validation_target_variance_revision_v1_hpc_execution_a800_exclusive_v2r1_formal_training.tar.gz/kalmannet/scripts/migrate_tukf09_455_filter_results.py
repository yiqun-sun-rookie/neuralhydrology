"""Build an unpublished, self-contained 455-basin filter-migration candidate.

This module never reads evaluation arrays and never publishes the final migration
root.  Publication belongs to the separately implemented independent verifier.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import shutil
import sys
import uuid
import zipfile
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

import numpy as np


ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

EXPERIMENT_ID = "TUKF09_455_BASIN_ZERO_VALIDATION_TARGET_VARIANCE_REVISION_V1"
SOURCE_EXPERIMENT_ID = "TUKF09_BACKPROPAGATION_VS_NEURAL_BACKWARD_TIME_CONFIRMATION_V1"
EXCLUDED_BASIN = "08202700"
EXPECTED_UNIT_COUNT = 455
EXPECTED_CHECKPOINT_COUNT = 116_480
EXPECTED_GRADIENT_UPDATE_COUNT = 112_840
UNIT_MEMBER_NAMES = {
    "identity.json",
    "history.npz",
    "selection.json",
    "access_ledger.json",
    "migration_provenance.json",
    "manifest.sha256.json",
}
SOURCE_MEMBER_NAMES = {
    "identity.json",
    "history.npz",
    "selection.json",
    "access_ledger.json",
    "manifest.sha256.json",
}
PARAMETER_NAMES = (
    "parTT",
    "parCFMAX",
    "parCFR",
    "parCWH",
    "parFC",
    "parBETA",
    "parLP",
    "parK0",
    "parK1",
    "parUZL",
    "parPERC",
    "parK2",
    "lag_time",
)
REQUIRED_SCOPE = {
    "result_migration_authorized": True,
    "filter_result_rebinding_authorized": True,
    "new_filter_optimization_authorized": False,
    "neural_training_authorized": True,
    "formal_evaluation_authorized": True,
}
REQUIRED_PHASE_ORDER = [
    "filter_migration",
    "filter_migration_independent_verification",
    "formal_training_admission",
    "formal_training_root_initialization",
    "filter_rebinding_installation",
    "filter_rebinding_independent_verification",
    "neural_training",
    "training_selection_seal",
    "training_selection_independent_verification",
    "formal_evaluation_authorization",
    "formal_evaluation_admission",
    "formal_evaluation",
    "formal_evaluation_independent_verification",
]
ZERO_ACCESS_LEDGER = {
    "evaluation_array_reads": 0,
    "evaluation_predictions": 0,
    "evaluation_metrics": 0,
    "evaluation_outputs": 0,
}


def _reject_constant(value: str) -> None:
    raise ValueError(f"non-finite JSON value is forbidden: {value}")


def _pairs_no_duplicates(pairs: Sequence[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def _parse_json(content: bytes, *, require_canonical: bool) -> Any:
    try:
        payload = json.loads(
            content.decode("utf-8"),
            object_pairs_hook=_pairs_no_duplicates,
            parse_constant=_reject_constant,
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("invalid UTF-8 JSON") from exc
    if require_canonical and content != canonical_json_bytes(payload):
        raise ValueError("generated JSON is not canonical compact UTF-8 plus final LF")
    return payload


def canonical_json_bytes(payload: Any) -> bytes:
    return (
        json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
        + b"\n"
    )


def _canonical_payload_sha256(payload: Any) -> str:
    return hashlib.sha256(canonical_json_bytes(payload)[:-1]).hexdigest()


def sha256_bytes(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def _verify_authorization_record(payload: Mapping[str, Any]) -> None:
    if (
        payload.get("schema_version") != "tukf09_455_all_scope_authorization_v1"
        or payload.get("experiment_id") != EXPERIMENT_ID
        or payload.get("status")
        != "ALL_REQUESTED_PHASES_AUTHORIZED_SEQUENTIAL_ADMISSION_REQUIRED"
        or payload.get("authorization_text") != "全部授权"
    ):
        raise PermissionError("all-scope authorization is missing or changed")
    if payload.get("scope") != REQUIRED_SCOPE:
        raise PermissionError("authorization scope does not admit the frozen sequential phases")
    if payload.get("required_phase_order") != REQUIRED_PHASE_ORDER:
        raise PermissionError("authorization phase order changed")
    if payload.get("access_ledger") != ZERO_ACCESS_LEDGER:
        raise PermissionError("all-scope authorization records evaluation access")
    unsigned = dict(payload)
    recorded = unsigned.pop("authorization_record_sha256", None)
    if recorded != sha256_bytes(canonical_json_bytes(unsigned)):
        raise PermissionError("all-scope authorization self-hash changed")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def file_record(path: Path) -> dict[str, object]:
    return {"sha256": sha256_file(path), "size_bytes": Path(path).stat().st_size}


def bytes_record(content: bytes) -> dict[str, object]:
    return {"sha256": sha256_bytes(content), "size_bytes": len(content)}


def _is_reparse(path: Path) -> bool:
    stat = Path(path).lstat()
    return bool(getattr(stat, "st_file_attributes", 0) & 0x400)


def assert_regular_unlinked_file(path: Path, *, label: str) -> None:
    target = Path(path)
    if target.is_symlink() or _is_reparse(target) or not target.is_file():
        raise RuntimeError(f"{label} must be one regular non-reparse file")
    if target.stat().st_nlink != 1:
        raise RuntimeError(f"{label} is a hard link or has multiple names")


def assert_plain_directory(path: Path, *, label: str) -> None:
    target = Path(path)
    if target.is_symlink() or _is_reparse(target) or not target.is_dir():
        raise RuntimeError(f"{label} must be one regular non-reparse directory")


def _ensure_descendant(path: Path, parent: Path) -> None:
    resolved = Path(path).resolve(strict=False)
    ancestor = Path(parent).resolve(strict=False)
    try:
        resolved.relative_to(ancestor)
    except ValueError as exc:
        raise RuntimeError(f"path escapes its admitted root: {path}") from exc


def deterministic_npz_bytes(arrays: Mapping[str, np.ndarray]) -> bytes:
    destination = BytesIO()
    with zipfile.ZipFile(
        destination,
        mode="w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    ) as archive:
        for name in sorted(arrays):
            array = np.ascontiguousarray(np.asarray(arrays[name]))
            if array.dtype.hasobject:
                raise TypeError("object arrays are forbidden")
            if np.issubdtype(array.dtype, np.floating) and not np.isfinite(array).all():
                raise FloatingPointError("non-finite history array")
            member = BytesIO()
            np.lib.format.write_array(member, array, allow_pickle=False)
            info = zipfile.ZipInfo(f"{name}.npy", date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 0
            info.external_attr = 0
            archive.writestr(info, member.getvalue(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    return destination.getvalue()


def _finite_vector(value: Any, length: int, *, label: str) -> np.ndarray:
    array = np.asarray(value, dtype=np.float64)
    if array.shape != (length,) or not np.isfinite(array).all():
        raise RuntimeError(f"{label} is non-finite or has the wrong length")
    return array


def _selected_checkpoint(
    theta_log: np.ndarray,
    training_objective: np.ndarray,
    validation_objective: np.ndarray,
) -> tuple[int, np.ndarray]:
    with np.errstate(over="ignore", invalid="ignore"):
        actual = np.exp(theta_log)
    if not np.isfinite(actual).all() or np.any(actual <= 0.0):
        raise RuntimeError("filter history contains invalid actual noise parameters")
    selected = min(
        range(theta_log.shape[0]),
        key=lambda index: (
            float(validation_objective[index]),
            float(training_objective[index]),
            tuple(float(value) for value in actual[index]),
            int(index),
        ),
    )
    return int(selected), actual


def _load_history(path: Path, dimension: int) -> dict[str, np.ndarray]:
    assert_regular_unlinked_file(path, label="source history")
    try:
        with np.load(path, allow_pickle=False) as archive:
            if set(archive.files) != {
                "checkpoint_index",
                "start_index",
                "step_index",
                "theta_log",
                "training_objective",
                "validation_objective",
            }:
                raise RuntimeError("filter history member set changed")
            arrays = {name: np.array(archive[name], copy=True) for name in archive.files}
    except (OSError, ValueError, zipfile.BadZipFile) as exc:
        raise RuntimeError("filter history is not a valid non-pickle NumPy archive") from exc
    checkpoint = arrays["checkpoint_index"]
    start = arrays["start_index"]
    step = arrays["step_index"]
    theta = arrays["theta_log"]
    training = arrays["training_objective"]
    validation = arrays["validation_objective"]
    if (
        checkpoint.dtype != np.int64
        or start.dtype != np.int64
        or step.dtype != np.int64
        or theta.dtype != np.float64
        or training.dtype != np.float64
        or validation.dtype != np.float64
        or checkpoint.shape != (256,)
        or start.shape != (256,)
        or step.shape != (256,)
        or theta.shape != (256, dimension + 1)
        or training.shape != (256,)
        or validation.shape != (256,)
    ):
        raise RuntimeError("filter history dtype or shape changed")
    if not (
        np.array_equal(checkpoint, np.arange(256, dtype=np.int64))
        and np.array_equal(start, np.tile(np.arange(8, dtype=np.int64), 32))
        and np.array_equal(step, np.repeat(np.arange(32, dtype=np.int64), 8))
    ):
        raise RuntimeError("filter history order changed")
    if not (np.isfinite(theta).all() and np.isfinite(training).all() and np.isfinite(validation).all()):
        raise RuntimeError("filter history contains a non-finite value")
    return arrays


@dataclass(frozen=True)
class VerifiedParentUnit:
    basin_id: str
    unit_directory: Path
    identity: Mapping[str, Any]
    selection: Mapping[str, Any]
    access_ledger: Mapping[str, Any]
    history_arrays: Mapping[str, np.ndarray]
    source_members: Mapping[str, bytes]
    source_manifest: Mapping[str, Any]
    source_manifest_sha256: str
    selected_index: int
    checkpoint_count: int
    gradient_update_count: int


def recompute_parent_filter_unit(
    unit_directory: Path,
    basin_id: str,
    *,
    expected_parameter_sha256: str | None = None,
    expected_training_period_sha256: str | None = None,
    expected_validation_period_sha256: str | None = None,
    expected_state_dimension: int | None = None,
    expected_initial_state: Sequence[float] | None = None,
    expected_base_observation_variance: float | None = None,
) -> VerifiedParentUnit:
    basin = str(basin_id)
    if len(basin) != 8 or not basin.isdigit():
        raise ValueError("basin identifier must contain exactly eight digits")
    unit = Path(unit_directory)
    assert_plain_directory(unit, label="source filter unit")
    names = {path.name for path in unit.iterdir()}
    if names != SOURCE_MEMBER_NAMES:
        raise RuntimeError("source filter unit has missing or extra members")
    for path in unit.iterdir():
        assert_regular_unlinked_file(path, label=f"source member {path.name}")
    manifest_bytes = (unit / "manifest.sha256.json").read_bytes()
    manifest = _parse_json(manifest_bytes, require_canonical=True)
    if not isinstance(manifest, dict) or (
        manifest.get("schema_version") != "tukf09_filter_unit_manifest_v1"
        or manifest.get("experiment_id") != SOURCE_EXPERIMENT_ID
        or manifest.get("unit_type") != "filter_basin"
        or manifest.get("unit_id") != basin
        or manifest.get("file_count") != 4
        or set(manifest.get("files", {})) != SOURCE_MEMBER_NAMES - {"manifest.sha256.json"}
    ):
        raise RuntimeError("source filter manifest identity changed")
    source_members: dict[str, bytes] = {}
    for name in sorted(SOURCE_MEMBER_NAMES - {"manifest.sha256.json"}):
        content = (unit / name).read_bytes()
        if manifest["files"][name] != bytes_record(content):
            raise RuntimeError(f"source filter member hash mismatch: {name}")
        source_members[name] = content

    identity = _parse_json(source_members["identity.json"], require_canonical=True)
    if not isinstance(identity, dict) or (
        identity.get("schema_version") != "tukf09_filter_unit_identity_v1"
        or identity.get("experiment_id") != SOURCE_EXPERIMENT_ID
        or identity.get("unit_type") != "filter_basin"
        or identity.get("unit_id") != basin
        or identity.get("parameter_names") != list(PARAMETER_NAMES)
        or identity.get("precision") != "float64"
        or identity.get("starts") != 8
        or identity.get("updates_per_start") != 31
        or identity.get("checkpoint_order") != "round_robin_by_step_then_start"
    ):
        raise RuntimeError("source filter identity changed")
    dimension = identity.get("state_dimension")
    if type(dimension) is not int or not 7 <= dimension <= 20:
        raise RuntimeError("source state dimension changed")
    _finite_vector(identity.get("initial_state"), dimension, label="source initial state")
    if not math.isfinite(float(identity.get("base_observation_variance", math.nan))) or float(
        identity["base_observation_variance"]
    ) <= 0.0:
        raise RuntimeError("source observation variance is invalid")
    if expected_state_dimension is not None and dimension != expected_state_dimension:
        raise RuntimeError("source state dimension differs from the independently rebuilt context")
    if expected_initial_state is not None and not np.array_equal(
        _finite_vector(identity.get("initial_state"), dimension, label="source initial state"),
        np.asarray(expected_initial_state, dtype=np.float64),
    ):
        raise RuntimeError("source initial state differs from the independently rebuilt context")
    if expected_base_observation_variance is not None and np.asarray(
        [identity.get("base_observation_variance")], dtype=np.float64
    ).view("<u8")[0] != np.asarray([expected_base_observation_variance], dtype=np.float64).view("<u8")[0]:
        raise RuntimeError("source observation variance differs from the independently rebuilt context")
    for name, expected in (
        ("physical_parameter_sha256", expected_parameter_sha256),
        ("training_period_sha256", expected_training_period_sha256),
        ("validation_period_sha256", expected_validation_period_sha256),
    ):
        value = identity.get(name)
        if not isinstance(value, str) or len(value) != 64:
            raise RuntimeError(f"source identity hash is invalid: {name}")
        if expected is not None and value != expected:
            raise RuntimeError(f"source identity differs from revised preflight: {name}")

    arrays = _load_history(unit / "history.npz", dimension)
    expected_selected, actual = _selected_checkpoint(
        arrays["theta_log"], arrays["training_objective"], arrays["validation_objective"]
    )
    selection = _parse_json(source_members["selection.json"], require_canonical=True)
    if not isinstance(selection, dict) or (
        selection.get("schema_version") != "tukf09_filter_unit_selection_v1"
        or selection.get("experiment_id") != SOURCE_EXPERIMENT_ID
        or selection.get("unit_type") != "filter_basin"
        or selection.get("unit_id") != basin
        or selection.get("status") != "FILTER_BASIN_SELECTED"
        or selection.get("selected_index") != expected_selected
        or selection.get("checkpoint_count") != 256
        or selection.get("training_query_count") != 256
        or selection.get("validation_query_count") != 256
        or selection.get("filter_pass_count") != 512
        or selection.get("gradient_update_count") != 248
    ):
        raise RuntimeError("source filter selection contract changed")
    if not np.array_equal(
        _finite_vector(selection.get("selected_theta_log"), dimension + 1, label="selected theta"),
        arrays["theta_log"][expected_selected],
    ) or not np.array_equal(
        _finite_vector(
            selection.get("selected_process_diagonal"), dimension, label="selected process diagonal"
        ),
        actual[expected_selected, :-1],
    ):
        raise RuntimeError("source selected vector differs from independently selected history")
    selected_scalars = np.asarray(
        [
            selection.get("selected_r_b"),
            selection.get("selected_training_objective"),
            selection.get("selected_validation_objective"),
        ],
        dtype=np.float64,
    )
    expected_scalars = np.asarray(
        [
            actual[expected_selected, -1],
            arrays["training_objective"][expected_selected],
            arrays["validation_objective"][expected_selected],
        ],
        dtype=np.float64,
    )
    if not np.isfinite(selected_scalars).all() or not np.array_equal(selected_scalars, expected_scalars):
        raise RuntimeError("source selected scalars differ from independently selected history")
    ledger = _parse_json(source_members["access_ledger.json"], require_canonical=True)
    zero_fields = (
        "evaluation_array_read_count",
        "evaluation_prediction_count",
        "evaluation_metric_count",
        "evaluation_output_write_count",
    )
    if not isinstance(ledger, dict) or (
        ledger.get("experiment_id") != SOURCE_EXPERIMENT_ID
        or ledger.get("unit_id") != basin
        or ledger.get("training_period_loaded") is not True
        or ledger.get("validation_period_loaded") is not True
        or ledger.get("formal_evaluation_authorized") is not False
        or any(type(ledger.get(name)) is not int or ledger.get(name) != 0 for name in zero_fields)
    ):
        raise PermissionError("source filter access ledger records forbidden evaluation access")
    return VerifiedParentUnit(
        basin_id=basin,
        unit_directory=unit,
        identity=identity,
        selection=selection,
        access_ledger=ledger,
        history_arrays=arrays,
        source_members=source_members,
        source_manifest=manifest,
        source_manifest_sha256=sha256_bytes(manifest_bytes),
        selected_index=expected_selected,
        checkpoint_count=256,
        gradient_update_count=248,
    )


def build_rebound_unit(
    parent: VerifiedParentUnit,
    *,
    scientific_contract_sha256: str,
    preflight_final_manifest_sha256: str,
    all_scope_authorization_sha256: str,
    migration_config_sha256: str,
    compatibility_projection_sha256: str,
) -> Mapping[str, bytes]:
    hashes = {
        "scientific_contract_sha256": scientific_contract_sha256,
        "preflight_final_manifest_sha256": preflight_final_manifest_sha256,
        "all_scope_authorization_sha256": all_scope_authorization_sha256,
        "migration_config_sha256": migration_config_sha256,
        "compatibility_projection_sha256": compatibility_projection_sha256,
    }
    if any(not isinstance(value, str) or len(value) != 64 for value in hashes.values()):
        raise ValueError("rebound provenance requires five SHA-256 values")
    source_identity = dict(parent.identity)
    identity = {
        "schema_version": "tukf09_455_rebound_filter_unit_identity_v1",
        "experiment_id": EXPERIMENT_ID,
        "unit_type": "filter_basin",
        "unit_id": parent.basin_id,
        "state_dimension": source_identity["state_dimension"],
        "parameter_names": source_identity["parameter_names"],
        "physical_parameter_sha256": source_identity["physical_parameter_sha256"],
        "training_period_sha256": source_identity["training_period_sha256"],
        "validation_period_sha256": source_identity["validation_period_sha256"],
        "initial_state": source_identity["initial_state"],
        "initial_covariance_diagonal": source_identity["initial_covariance_diagonal"],
        "base_observation_variance": source_identity["base_observation_variance"],
        "precision": "float64",
        "starts": 8,
        "updates_per_start": 31,
        "checkpoint_order": "round_robin_by_step_then_start",
        **hashes,
    }
    selection = dict(parent.selection)
    selection.update(
        {
            "schema_version": "tukf09_455_rebound_filter_unit_selection_v1",
            "experiment_id": EXPERIMENT_ID,
            "status": "FILTER_BASIN_REBOUND_FROM_VERIFIED_PARENT",
        }
    )
    ledger = {
        "schema_version": "tukf09_455_rebound_filter_unit_access_ledger_v1",
        "experiment_id": EXPERIMENT_ID,
        "unit_type": "filter_basin",
        "unit_id": parent.basin_id,
        "training_period_loaded": True,
        "validation_period_loaded": True,
        "evaluation_array_read_count": 0,
        "evaluation_prediction_count": 0,
        "evaluation_metric_count": 0,
        "evaluation_output_write_count": 0,
        "formal_evaluation_authorized": False,
        "new_filter_optimization_count": 0,
    }
    provenance = {
        "schema_version": "tukf09_455_filter_unit_migration_provenance_v1",
        "experiment_id": EXPERIMENT_ID,
        "source_experiment_id": SOURCE_EXPERIMENT_ID,
        "unit_id": parent.basin_id,
        "migration_mode": "byte_copy_history_and_rebuild_identity",
        "source_unit_path": str(parent.unit_directory.resolve()),
        "source_unit_manifest_sha256": parent.source_manifest_sha256,
        "source_members": {
            name: bytes_record(content) for name, content in sorted(parent.source_members.items())
        },
        "history_byte_identity_required": True,
        "selection_numeric_identity_required": True,
        "source_runner_sha256": parent.identity["runner_sha256"],
        "source_contract_sha256": parent.identity["contract_file_sha256"],
        "source_preflight_final_manifest_sha256": parent.identity[
            "preflight_final_manifest_sha256"
        ],
        "source_authorization_sha256": parent.identity["authorization_file_sha256"],
        "source_training_admission_record_sha256": parent.identity[
            "training_admission_record_sha256"
        ],
        **hashes,
    }
    members = {
        "identity.json": canonical_json_bytes(identity),
        "history.npz": parent.source_members["history.npz"],
        "selection.json": canonical_json_bytes(selection),
        "access_ledger.json": canonical_json_bytes(ledger),
        "migration_provenance.json": canonical_json_bytes(provenance),
    }
    manifest = {
        "schema_version": "tukf09_455_rebound_filter_unit_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "unit_type": "filter_basin",
        "unit_id": parent.basin_id,
        "file_count": 5,
        "files": {name: bytes_record(content) for name, content in sorted(members.items())},
    }
    return {**members, "manifest.sha256.json": canonical_json_bytes(manifest)}


def _manifest_map(root: Path, basin_ids: Sequence[str]) -> dict[str, str]:
    return {
        basin: sha256_file(Path(root) / f"basin_{basin}" / "manifest.sha256.json")
        for basin in basin_ids
    }


def build_source_inventory(
    source_filter_root: Path,
    ordered_basin_ids: Sequence[str],
    *,
    source_population_ids: Sequence[str] | None = None,
    production_verify: Callable[[Path, str], Any] | None = None,
    parameter_sha256_by_basin: Mapping[str, str] | None = None,
    training_period_sha256_by_basin: Mapping[str, str] | None = None,
    validation_period_sha256_by_basin: Mapping[str, str] | None = None,
    rebuilt_context_by_basin: Mapping[str, Mapping[str, Any]] | None = None,
) -> dict[str, object]:
    root = Path(source_filter_root)
    assert_plain_directory(root, label="source filter root")
    retained = [str(value) for value in ordered_basin_ids]
    if len(retained) != len(set(retained)):
        raise ValueError("revised filter population contains duplicates")
    if EXCLUDED_BASIN in retained:
        raise ValueError("the zero-validation-variance basin cannot be rebound")
    source_ids = [str(value) for value in (source_population_ids or retained)]
    if len(source_ids) != len(set(source_ids)):
        raise ValueError("source population contains duplicates")
    if not set(retained).issubset(source_ids):
        raise ValueError("revised population is not a source-population subset")
    excluded = [basin for basin in source_ids if basin not in set(retained)]
    if source_population_ids is not None and excluded != [EXCLUDED_BASIN]:
        raise ValueError("source-to-revised exclusion must be exactly basin 08202700")
    actual_dirs = sorted(
        path.name.removeprefix("basin_")
        for path in root.iterdir()
        if path.is_dir() and path.name.startswith("basin_")
    )
    if set(actual_dirs) != set(source_ids):
        raise RuntimeError("source filter root differs from the admitted source population")
    if production_verify is not None:
        for basin in source_ids:
            production_verify(root / f"basin_{basin}", basin)
    records: dict[str, Any] = {}
    for basin in retained:
        verified = recompute_parent_filter_unit(
            root / f"basin_{basin}",
            basin,
            expected_parameter_sha256=(parameter_sha256_by_basin or {}).get(basin),
            expected_training_period_sha256=(training_period_sha256_by_basin or {}).get(basin),
            expected_validation_period_sha256=(validation_period_sha256_by_basin or {}).get(basin),
            expected_state_dimension=(rebuilt_context_by_basin or {}).get(basin, {}).get(
                "state_dimension"
            ),
            expected_initial_state=(rebuilt_context_by_basin or {}).get(basin, {}).get(
                "initial_state"
            ),
            expected_base_observation_variance=(rebuilt_context_by_basin or {}).get(basin, {}).get(
                "base_observation_variance"
            ),
        )
        manifest_path = verified.unit_directory / "manifest.sha256.json"
        records[basin] = {
            "source_unit_relative_path": f"basin_{basin}",
            "source_unit_manifest_sha256": verified.source_manifest_sha256,
            "source_unit_manifest_size_bytes": manifest_path.stat().st_size,
            "source_members": {
                name: dict(verified.source_manifest["files"][name])
                for name in sorted(verified.source_manifest["files"])
            },
            "selected_index": verified.selected_index,
            "checkpoint_count": verified.checkpoint_count,
            "gradient_update_count": verified.gradient_update_count,
        }
    full_map = _manifest_map(root, source_ids)
    return {
        "schema_version": "tukf09_455_filter_migration_source_inventory_v1",
        "experiment_id": EXPERIMENT_ID,
        "source_experiment_id": SOURCE_EXPERIMENT_ID,
        "source_filter_root": str(root.resolve()),
        "ordered_basin_ids": retained,
        "unit_count": len(retained),
        "source_population_count": len(source_ids),
        "excluded_source_basins": excluded,
        "source_population_manifest_map_sha256": _canonical_payload_sha256(full_map),
        "retained_inventory_sha256": _canonical_payload_sha256(records),
        "records": records,
    }


def _normalize_numbers(value: Any) -> Any:
    if isinstance(value, bool) or value is None or isinstance(value, str):
        return value
    if isinstance(value, (int, float)):
        number = float(value)
        if not math.isfinite(number):
            raise ValueError("non-finite contract number")
        return number
    if isinstance(value, list):
        return [_normalize_numbers(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _normalize_numbers(item) for key, item in value.items()}
    raise TypeError(f"unsupported compatibility value: {type(value).__name__}")


def build_filter_compatibility_projection(
    parent_contract: Mapping[str, Any], revised_contract: Mapping[str, Any]
) -> dict[str, Any]:
    projection_keys = (
        "periods",
        "filter_system",
        "information_contract",
        "source_anchors",
        "primary_comparison",
    )
    parent = {key: _normalize_numbers(parent_contract[key]) for key in projection_keys}
    revised = {key: _normalize_numbers(revised_contract[key]) for key in projection_keys}
    if parent != revised:
        raise RuntimeError("runner-consumed filter contract projection changed")
    return {
        "schema_version": "tukf09_455_filter_compatibility_projection_v1",
        "projection": revised,
        "projection_sha256": _canonical_payload_sha256(revised),
    }


def _read_json_file(path: Path, *, canonical: bool = False) -> Mapping[str, Any]:
    assert_regular_unlinked_file(path, label=f"JSON input {path}")
    payload = _parse_json(path.read_bytes(), require_canonical=canonical)
    if not isinstance(payload, dict):
        raise ValueError(f"JSON input must be an object: {path}")
    return payload


def _period_identity(period: Any) -> str:
    forcing = np.asarray(getattr(period, "forcing", period[0] if isinstance(period, tuple) else None))
    observations = np.asarray(
        getattr(period, "observations", period[1] if isinstance(period, tuple) else None)
    )
    dates_raw = getattr(period, "dates_ns", None)
    if dates_raw is None:
        dates_raw = getattr(period, "dates", period[2] if isinstance(period, tuple) else None)
    if forcing.ndim == 3:
        forcing = forcing[:, 0, :]
    if observations.ndim == 2:
        observations = observations[:, 0]
    dates = np.asarray(dates_raw)
    if np.issubdtype(dates.dtype, np.datetime64):
        dates = dates.astype("datetime64[ns]").astype("<i8")
    else:
        dates = dates.astype("<i8", copy=False)
    digest = hashlib.sha256()
    for name, array in (
        ("dates_ns", dates),
        ("forcing", np.asarray(forcing, dtype="<f8")),
        ("observations", np.asarray(observations, dtype="<f8")),
    ):
        contiguous = np.ascontiguousarray(array)
        if np.issubdtype(contiguous.dtype, np.floating) and not np.isfinite(contiguous).all():
            raise RuntimeError("training or validation period contains non-finite values")
        digest.update(name.encode("utf-8"))
        digest.update(str(contiguous.dtype).encode("ascii"))
        digest.update(np.asarray(contiguous.shape, dtype="<i8").tobytes())
        digest.update(contiguous.tobytes())
    return digest.hexdigest()


def _production_source_context(
    retained_ids: Sequence[str],
) -> tuple[
    Callable[[Path, str], Any],
    dict[str, str],
    dict[str, str],
    dict[str, Mapping[str, Any]],
]:
    from scripts import tukf09_training_common as common
    from scripts import tukf09_training_controller_common as controller_common
    from scripts.run_tukf09_filter_training_controller import FILTER_RUNNER, verify_completed_filter_unit
    from scripts.run_tukf09_formal_training_sequence import fixed_paths, verify_training_admission
    from scripts.run_tukf09_filter_training import build_causal_filter_context

    paths = fixed_paths()
    admission = verify_training_admission(paths)
    common.verify_initialized_training_root(
        output_root=paths.output_root,
        config_path=paths.config,
        authorization=paths.authorization,
        execution_config=paths.execution_config,
        training_admission=paths.training_admission,
        training_admission_record=admission,
    )
    context = common.verify_preflight_for_training(
        paths.config,
        paths.preflight_root / "independent" / "manifest.final.sha256.json",
        paths.authorization,
        paths.output_root,
        require_output_absent=False,
        recompute_training_validation_semantics=False,
        verify_all_raw_source_bytes=False,
    )
    if context.evaluation_access_count != 0:
        raise PermissionError("source production context records evaluation access")
    provenance = {
        "contract_file_sha256": context.contract_sha256,
        "preflight_final_manifest_sha256": context.preflight_final_manifest_sha256,
        "authorization_file_sha256": context.authorization.authorization_file_sha256,
        "training_admission_record_sha256": admission["training_admission_record_sha256"],
    }
    runner_hash = controller_common.sha256_file(FILTER_RUNNER)

    def verify(unit: Path, basin: str) -> Any:
        return verify_completed_filter_unit(
            unit,
            basin,
            expected_runner_sha256=runner_hash,
            expected_provenance=provenance,
        )

    loaded = common.load_training_validation_periods(context, retained_ids)
    training_hashes: dict[str, str] = {}
    validation_hashes: dict[str, str] = {}
    rebuilt: dict[str, Mapping[str, Any]] = {}
    contract = _read_json_file(paths.config)
    population_index = {basin: index for index, basin in enumerate(context.ordered_basin_ids)}
    for basin in retained_ids:
        periods = loaded[basin]
        if set(periods) != {"training", "validation"}:
            raise RuntimeError("frozen loader returned a forbidden or missing period")
        training_hashes[basin] = _period_identity(periods["training"])
        validation_hashes[basin] = _period_identity(periods["validation"])
        row = {
            name: float(context.parameter_values[population_index[basin], column])
            for column, name in enumerate(context.parameter_names)
        }
        filter_context = build_causal_filter_context(
            basin,
            row,
            periods["training"].observations,
            contract,
        )
        rebuilt[basin] = {
            "state_dimension": int(filter_context.dimension),
            "initial_state": filter_context.initial_state[0].detach().cpu().numpy().tolist(),
            "base_observation_variance": float(filter_context.base_observation_variance),
        }
    return verify, training_hashes, validation_hashes, rebuilt


def _parameter_hashes(path: Path) -> dict[str, str]:
    assert_regular_unlinked_file(path, label="revised parameter archive")
    with np.load(path, allow_pickle=False) as archive:
        if set(archive.files) != {"basin_ids", "parameter_names", "values"}:
            raise RuntimeError("revised parameter archive member set changed")
        basin_ids = [str(value) for value in archive["basin_ids"]]
        names = tuple(str(value) for value in archive["parameter_names"])
        values = np.asarray(archive["values"], dtype=np.float64)
    if names != PARAMETER_NAMES or values.shape != (len(basin_ids), 13) or not np.isfinite(values).all():
        raise RuntimeError("revised parameter archive changed")
    return {
        basin: _canonical_payload_sha256([float(value) for value in row])
        for basin, row in zip(basin_ids, values)
    }


def _write_exclusive(path: Path, content: bytes) -> None:
    with Path(path).open("xb") as handle:
        handle.write(content)
        handle.flush()
        os.fsync(handle.fileno())


def execute_filter_migration(
    *,
    migration_config_path: Path | None = None,
    authorization_path: Path | None = None,
    candidate_root: Path | None = None,
    authorize: bool,
    fail_after_write: int | None = None,
) -> dict[str, object]:
    if authorize is not True:
        raise PermissionError("filter migration requires explicit authorization")
    migration_config_path = migration_config_path or ROOT / "configs" / (
        "tukf09_455_basin_zero_validation_target_variance_filter_migration_v1.json"
    )
    authorization_path = authorization_path or ROOT / "artifacts" / (
        "tukf09_455_basin_zero_validation_target_variance_revision_v1/authorizations/"
        "all_scope_authorization.json"
    )
    config_bytes = Path(migration_config_path).read_bytes()
    config = _parse_json(config_bytes, require_canonical=False)
    authorization_bytes = Path(authorization_path).read_bytes()
    authorization = _parse_json(authorization_bytes, require_canonical=True)
    if not isinstance(config, dict) or (
        config.get("schema_version") != "tukf09_455_filter_migration_execution_v1"
        or config.get("experiment_id") != EXPERIMENT_ID
        or config.get("status") != "FILTER_MIGRATION_DESIGN_FROZEN_EXECUTION_NOT_STARTED"
    ):
        raise RuntimeError("migration configuration identity changed")
    if not isinstance(authorization, dict):
        raise PermissionError("all-scope authorization is not an object")
    _verify_authorization_record(authorization)

    revised_contract_path = ROOT / "configs/tukf09_455_basin_zero_validation_target_variance_revision_v1.json"
    parent_contract_path = ROOT / "configs/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1.json"
    preflight_root = ROOT / "artifacts/tukf09_455_basin_zero_validation_target_variance_revision_v1/preflight"
    revised_contract = _read_json_file(revised_contract_path)
    parent_contract = _read_json_file(parent_contract_path)
    preflight_final_path = preflight_root / "independent/manifest.final.sha256.json"
    if (
        sha256_file(revised_contract_path)
        != "7710594dcc5cce7f087cb70492a6f827c3925a98ea7fa051d26c5ef1660304e1"
        or sha256_file(preflight_final_path)
        != "f7e0a3f0708d0498cbaeaa77a044687f20d017ffa316170cd4770fc920b144aa"
        or config.get("scientific_contract", {}).get("sha256") != sha256_file(revised_contract_path)
        or config.get("independent_preflight_final_manifest", {}).get("sha256")
        != sha256_file(preflight_final_path)
        or config.get("source_experiment", {}).get("scientific_contract", {}).get("sha256")
        != sha256_file(parent_contract_path)
        or config.get("source_experiment", {})
        .get("independent_preflight_final_manifest", {})
        .get("sha256")
        != sha256_file(
            ROOT
            / "artifacts/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1/"
            "preflight/independent/manifest.final.sha256.json"
        )
    ):
        raise RuntimeError("migration config, revised preflight, or source frozen identity changed")
    compatibility = build_filter_compatibility_projection(parent_contract, revised_contract)
    population = _read_json_file(preflight_root / "population_registry.json", canonical=True)
    retained = [str(value) for value in population.get("eligible", [])]
    if len(retained) != EXPECTED_UNIT_COUNT or EXCLUDED_BASIN in retained:
        raise RuntimeError("revised preflight population changed")
    newline_digest = sha256_bytes("".join(f"{basin}\n" for basin in retained).encode("utf-8"))
    compact_digest = _canonical_payload_sha256(retained)
    if (
        newline_digest != "38987bce45fa38ff68f5b067db17e8cb3212d98fecdd106f57d268a130ee8fbd"
        or compact_digest != "75ef2cee206fb15ee3f31ae0bbfcf594661c5ccdda0b28de9ff65634332c8902"
        or config.get("population", {}).get("ordered_newline_sha256") != newline_digest
        or config.get("population", {}).get("compact_json_sha256") != compact_digest
    ):
        raise RuntimeError("revised population order or digest changed")
    source_population_artifact = _read_json_file(
        ROOT / "artifacts/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1/preflight/population_registry.json",
        canonical=True,
    )
    source_ids = [str(value) for value in source_population_artifact.get("eligible", [])]
    if len(source_ids) != 456 or [value for value in source_ids if value not in set(retained)] != [EXCLUDED_BASIN]:
        raise RuntimeError("source population no longer maps exactly to the revised population")
    production_verify, training_hashes, validation_hashes, rebuilt_contexts = (
        _production_source_context(retained)
    )
    parameter_hashes = _parameter_hashes(preflight_root / "parameters_only.npz")
    source_filter_root = ROOT / "results/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1/filter"
    inventory = build_source_inventory(
        source_filter_root,
        retained,
        source_population_ids=source_ids,
        production_verify=production_verify,
        parameter_sha256_by_basin=parameter_hashes,
        training_period_sha256_by_basin=training_hashes,
        validation_period_sha256_by_basin=validation_hashes,
        rebuilt_context_by_basin=rebuilt_contexts,
    )
    before_source_digest = inventory["source_population_manifest_map_sha256"]

    final_root = ROOT / "artifacts/tukf09_455_basin_zero_validation_target_variance_revision_v1/filter_migration_v1"
    if final_root.exists() or final_root.is_symlink():
        raise FileExistsError("final filter-migration root already exists; use independent verify-existing")
    candidate = candidate_root or final_root.with_name(f"{final_root.name}.pending.{uuid.uuid4().hex}")
    _ensure_descendant(candidate, final_root.parent)
    if (
        Path(candidate).resolve(strict=False).parent != final_root.resolve(strict=False).parent
        or not Path(candidate).name.startswith(f"{final_root.name}.pending.")
    ):
        raise ValueError("filter-migration candidate must match the frozen sibling pending pattern")
    if candidate.exists() or candidate.is_symlink():
        raise FileExistsError("filter-migration candidate already exists")
    candidate.mkdir(parents=False)
    writes = 0

    def write(path: Path, content: bytes) -> None:
        nonlocal writes
        path.parent.mkdir(parents=True, exist_ok=True)
        _write_exclusive(path, content)
        writes += 1
        if fail_after_write is not None and writes >= fail_after_write:
            raise RuntimeError("injected migration write failure")

    try:
        write(candidate / "migration_config.snapshot.json", config_bytes)
        write(candidate / "all_scope_authorization.snapshot.json", authorization_bytes)
        write(candidate / "source_inventory.sha256.json", canonical_json_bytes(inventory))
        source_units: dict[str, VerifiedParentUnit] = {}
        for basin in retained:
            source_units[basin] = recompute_parent_filter_unit(
                source_filter_root / f"basin_{basin}",
                basin,
                expected_parameter_sha256=parameter_hashes[basin],
                expected_training_period_sha256=training_hashes[basin],
                expected_validation_period_sha256=validation_hashes[basin],
                expected_state_dimension=int(rebuilt_contexts[basin]["state_dimension"]),
                expected_initial_state=rebuilt_contexts[basin]["initial_state"],
                expected_base_observation_variance=float(
                    rebuilt_contexts[basin]["base_observation_variance"]
                ),
            )
            rebound = build_rebound_unit(
                source_units[basin],
                scientific_contract_sha256=sha256_file(revised_contract_path),
                preflight_final_manifest_sha256=sha256_file(
                    preflight_root / "independent/manifest.final.sha256.json"
                ),
                all_scope_authorization_sha256=sha256_bytes(authorization_bytes),
                migration_config_sha256=sha256_bytes(config_bytes),
                compatibility_projection_sha256=compatibility["projection_sha256"],
            )
            unit = candidate / "units" / f"basin_{basin}"
            for name, content in rebound.items():
                write(unit / name, content)
        summary = {
            "schema_version": "tukf09_455_filter_migration_summary_v1",
            "experiment_id": EXPERIMENT_ID,
            "status": "FILTER_MIGRATION_CANDIDATE_455_COMPLETE_EVALUATION_HOLD",
            "final_root": str(final_root.resolve()),
            "source_filter_root": str(source_filter_root.resolve()),
            "ordered_basin_ids": retained,
            "unit_count": EXPECTED_UNIT_COUNT,
            "unit_file_count": EXPECTED_UNIT_COUNT * 6,
            "inherited_checkpoint_count": EXPECTED_CHECKPOINT_COUNT,
            "inherited_training_objective_count": EXPECTED_CHECKPOINT_COUNT,
            "inherited_validation_objective_count": EXPECTED_CHECKPOINT_COUNT,
            "inherited_gradient_update_count": EXPECTED_GRADIENT_UPDATE_COUNT,
            "new_filter_optimization_count": 0,
            "new_filter_training_objective_count": 0,
            "new_filter_validation_objective_count": 0,
            "new_filter_gradient_update_count": 0,
            "evaluation_access_count": 0,
            "compatibility_projection_sha256": compatibility["projection_sha256"],
            "source_population_manifest_map_sha256_before": before_source_digest,
        }
        write(candidate / "migration_summary.json", canonical_json_bytes(summary))
        current_files = {
            path.relative_to(candidate).as_posix(): file_record(path)
            for path in sorted(candidate.rglob("*"))
            if path.is_file()
        }
        manifest = {
            "schema_version": "tukf09_455_filter_migration_manifest_v1",
            "experiment_id": EXPERIMENT_ID,
            "file_count": len(current_files),
            "files": current_files,
        }
        write(candidate / "migration_manifest.sha256.json", canonical_json_bytes(manifest))
        after_source_digest = _canonical_payload_sha256(_manifest_map(source_filter_root, source_ids))
        if after_source_digest != before_source_digest:
            raise RuntimeError("source filter tree changed during candidate generation")
        return {
            "status": summary["status"],
            "candidate_root": str(candidate),
            "final_root": str(final_root),
            "unit_count": EXPECTED_UNIT_COUNT,
            "unit_file_count": EXPECTED_UNIT_COUNT * 6,
            "evaluation_access_count": 0,
        }
    except BaseException:
        if candidate.exists() and candidate.name.startswith(f"{final_root.name}.pending."):
            shutil.rmtree(candidate)
        raise


def _cli() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--migration-config", type=Path)
    parser.add_argument("--authorization", type=Path)
    parser.add_argument("--candidate-root", type=Path)
    parser.add_argument("--authorize-filter-migration", action="store_true")
    args = parser.parse_args()
    result = execute_filter_migration(
        migration_config_path=args.migration_config,
        authorization_path=args.authorization,
        candidate_root=args.candidate_root,
        authorize=args.authorize_filter_migration,
    )
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli())
