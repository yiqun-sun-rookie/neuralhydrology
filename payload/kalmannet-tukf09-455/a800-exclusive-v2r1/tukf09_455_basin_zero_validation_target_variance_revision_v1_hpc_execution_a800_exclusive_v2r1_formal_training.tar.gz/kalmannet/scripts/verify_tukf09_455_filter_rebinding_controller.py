"""Read-only controller gate for the installed 455 rebound filter units."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any, Callable, Mapping

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import tukf09_455_training_common as training_common
from scripts import tukf09_455_training_profile as profile
from scripts.verify_tukf09_455_filter_installation import (
    verify_filter_installation_independently,
)


EXPERIMENT_ID = profile.EXPERIMENT_ID
RESULT_SCHEMA = "tukf09_455_filter_rebinding_controller_result_v1"
RESULT_STATUS = "FILTER_REBINDING_VERIFIED_EVALUATION_HOLD"


def _fixed_paths() -> dict[str, Path]:
    return {
        "config": ROOT / profile.CONTRACT_RELATIVE,
        "preflight_root": ROOT / profile.PREFLIGHT_ROOT_RELATIVE,
        "authorization": ROOT / profile.AUTHORIZATION_RELATIVE,
        "training_admission": ROOT / profile.ADMISSION_RELATIVE,
        "execution_config": ROOT / profile.FORMAL_TRAINING_CONFIG_RELATIVE,
        "output_root": ROOT / profile.OUTPUT_RELATIVE,
        "migration_root": ROOT / profile.FILTER_MIGRATION_ROOT_RELATIVE,
    }


def run_filter_rebinding_verification(
    *,
    execute_formal_training: bool,
    config: Path | None = None,
    preflight_root: Path | None = None,
    authorization: Path | None = None,
    training_admission: Path | None = None,
    execution_config: Path | None = None,
    output_root: Path | None = None,
    migration_root: Path | None = None,
    production: bool = True,
    training_admission_verifier: Callable[..., Mapping[str, Any]] | None = None,
    initialized_root_verifier: Callable[..., Mapping[str, Any]] | None = None,
    preflight_verifier: Callable[..., Any] | None = None,
    installation_verifier: Callable[..., Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    if execute_formal_training is not True:
        raise PermissionError("explicit formal-training authorization is required")
    fixed = _fixed_paths()
    selected = {
        "config": fixed["config"] if config is None else Path(config),
        "preflight_root": (
            fixed["preflight_root"] if preflight_root is None else Path(preflight_root)
        ),
        "authorization": (
            fixed["authorization"] if authorization is None else Path(authorization)
        ),
        "training_admission": (
            fixed["training_admission"]
            if training_admission is None
            else Path(training_admission)
        ),
        "execution_config": (
            fixed["execution_config"]
            if execution_config is None
            else Path(execution_config)
        ),
        "output_root": fixed["output_root"] if output_root is None else Path(output_root),
        "migration_root": (
            fixed["migration_root"] if migration_root is None else Path(migration_root)
        ),
    }
    if production:
        for name, expected in fixed.items():
            if selected[name].resolve(strict=False) != expected.resolve(strict=False):
                raise ValueError(f"filter-rebinding controller {name} differs from fixed path")
    admission_loader = (
        training_common.load_and_verify_training_admission
        if training_admission_verifier is None
        else training_admission_verifier
    )
    admission = dict(
        admission_loader(
            selected["training_admission"],
            selected["execution_config"],
            tuple(
                ROOT / relative
                for relative in training_common.REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS
            ),
        )
    )
    admission_sha256 = admission.get("training_admission_record_sha256")
    if not isinstance(admission_sha256, str) or len(admission_sha256) != 64:
        raise RuntimeError("verified training admission lacks its record SHA-256")
    root_verifier = (
        training_common.verify_initialized_training_root
        if initialized_root_verifier is None
        else initialized_root_verifier
    )
    root_verifier(
        output_root=selected["output_root"],
        config_path=selected["config"],
        authorization=selected["authorization"],
        execution_config=selected["execution_config"],
        training_admission=selected["training_admission"],
        training_admission_record=admission,
    )
    context_loader = (
        training_common.verify_preflight_for_revision_training
        if preflight_verifier is None
        else preflight_verifier
    )
    context = context_loader(
        selected["config"],
        selected["preflight_root"] / "independent/manifest.final.sha256.json",
        selected["authorization"],
        selected["output_root"],
        require_output_absent=False,
        recompute_training_validation_semantics=False,
        verify_all_raw_source_bytes=False,
    )
    if int(getattr(context, "evaluation_access_count", 0)) != 0:
        raise RuntimeError("filter-rebinding verification records evaluation access")
    verifier = (
        verify_filter_installation_independently
        if installation_verifier is None
        else installation_verifier
    )
    verified = dict(
        verifier(
            migration_root=selected["migration_root"],
            results_root=selected["output_root"],
            training_admission_path=selected["training_admission"],
            authorize=True,
            publish=False,
        )
    )
    expected = {
        "status": "FILTER_REBINDING_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD",
        "unit_count": 455,
        "new_filter_optimization_count": 0,
        "evaluation_access_count": 0,
    }
    for key, value in expected.items():
        if verified.get(key) != value:
            raise RuntimeError(f"installed filter-rebinding verification changed: {key}")
    return {
        "schema_version": RESULT_SCHEMA,
        "experiment_id": EXPERIMENT_ID,
        "status": RESULT_STATUS,
        "canonical_unit_count": 455,
        "completed_unit_count": 455,
        "training_admission_record_sha256": admission_sha256,
        "evaluation_access_count": 0,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=_fixed_paths()["config"])
    parser.add_argument(
        "--preflight-root", type=Path, default=_fixed_paths()["preflight_root"]
    )
    parser.add_argument(
        "--authorization", type=Path, default=_fixed_paths()["authorization"]
    )
    parser.add_argument("--training-admission", type=Path, required=True)
    parser.add_argument("--execution-config", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, default=_fixed_paths()["output_root"])
    parser.add_argument("--execute-formal-training", action="store_true")
    args = parser.parse_args()
    result = run_filter_rebinding_verification(
        execute_formal_training=args.execute_formal_training,
        config=args.config,
        preflight_root=args.preflight_root,
        authorization=args.authorization,
        training_admission=args.training_admission,
        execution_config=args.execution_config,
        output_root=args.output_root,
    )
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()
