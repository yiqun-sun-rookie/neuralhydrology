"""Shared authorization, provenance, and no-evaluation gates for TUKF09.

This module deliberately contains no optimizer, model, prediction, or metric
execution.  A training process may receive only training/validation identities
from :func:`verify_preflight_for_training`; evaluation arrays are never loaded
or returned here.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
import csv
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import platform
import re
import shutil
import stat
import struct
import subprocess
import sys
from typing import Any, Callable, Iterable, Mapping, Sequence
import uuid

import numpy as np


EXPERIMENT_ID = "TUKF09_BACKPROPAGATION_VS_NEURAL_BACKWARD_TIME_CONFIRMATION_V1"
EXACT_AUTHORIZATION_TEXT = "授权正式训练"
EXPECTED_CONTRACT_SHA256 = (
    "0a3cdd0c0cfabccf971cc49821943c976e2a51dd01e79ec6f3f9279f993bac5d"
)
EXPECTED_PREFLIGHT_FINAL_MANIFEST_SHA256 = (
    "162049e28a1e470fc82385f98ab68698541da03304628f230ee4587359c90614"
)
CONFIG_RELATIVE = Path(
    "configs/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1.json"
)
PREFLIGHT_FINAL_RELATIVE = Path(
    "artifacts/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1/"
    "preflight/independent/manifest.final.sha256.json"
)
AUTHORIZATION_RELATIVE = Path(
    "artifacts/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1/"
    "authorizations/formal_training_authorization.json"
)
OUTPUT_RELATIVE = Path(
    "results/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1"
)
ADMISSION_RELATIVE = Path(
    "artifacts/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1/"
    "training_admission/training_admission.json"
)
TRAINING_PERIOD_NAMES = ("training", "validation")
SEMANTIC_ARRAY_NAMES = ("dates_ns", "forcing", "observations")
REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS = (
    "scripts/admit_tukf09_formal_training.py",
    "scripts/differentiable_ukf_hbvlite.py",
    "scripts/initialize_tukf09_formal_training.py",
    "scripts/run_aligned_gr4j_da.py",
    "scripts/run_aligned_gr4j_differentiable_ukf.py",
    "scripts/run_tukf09_filter_training.py",
    "scripts/run_tukf09_filter_training_controller.py",
    "scripts/run_tukf09_formal_training_sequence.py",
    "scripts/run_tukf09_neural_training.py",
    "scripts/run_tukf09_neural_training_controller.py",
    "scripts/seal_tukf09_training_selection.py",
    "scripts/tukf07_information_matched_model.py",
    "scripts/tukf09_confirmatory_common.py",
    "scripts/tukf09_training_common.py",
    "scripts/tukf09_training_controller_common.py",
    "scripts/verify_tukf09_training_selection.py",
    "src/global_hydrology/__init__.py",
    "src/global_hydrology/assimilation/__init__.py",
    "src/global_hydrology/assimilation/conventional_ukf.py",
    "src/global_hydrology/data/__init__.py",
    "src/global_hydrology/data/caravan_dataset.py",
    "src/global_hydrology/data/multi_obs_caravan.py",
    "src/global_hydrology/models/__init__.py",
    "src/global_hydrology/models/aligned_gr4j_pdd.py",
    "src/global_hydrology/models/differentiable_gr4j_pdd.py",
    "src/global_hydrology/models/differentiable_hbv_lite.py",
    "src/global_hydrology/models/differentiable_m4.py",
    "src/global_hydrology/models/differentiable_walrus.py",
    "src/global_hydrology/models/dl_ssm.py",
    "src/global_hydrology/models/hbvlite_system_model.py",
    "src/global_hydrology/models/hbvlite_ukf_adapter.py",
    "src/global_hydrology/models/hydro_system.py",
    "src/global_hydrology/models/m4_system_model.py",
    "src/global_hydrology/models/static_encoder.py",
    "src/global_hydrology/models/walrus_system_model.py",
)
RUNTIME_ENVIRONMENT_IDENTITY_KEYS = (
    "schema_version",
    "python_version",
    "python_executable",
    "numpy_version",
    "torch_version",
    "psutil_version",
    "torch_cuda_runtime_version",
    "cudnn_version",
    "cuda_available",
    "cuda_device_count",
    "cuda_device_name_0",
    "nvidia_gpu_uuid_0",
    "nvidia_driver_version",
    "platform",
    "machine",
    "logical_cpu_count",
)
REQUIRED_FORMAL_TRAINING_PYTEST_RELATIVE_PATHS = (
    "tests/test_tukf09_backward_time_confirmation_preflight.py",
    "tests/test_tukf09_training_authorization.py",
    "tests/test_tukf09_filter_training.py",
    "tests/test_tukf09_filter_training_controller.py",
    "tests/test_tukf09_neural_training.py",
    "tests/test_tukf09_neural_training_controller.py",
    "tests/test_tukf09_training_controllers.py",
    "tests/test_tukf09_formal_training_sequence.py",
    "tests/test_tukf09_training_selection_seal.py",
)
REQUIRED_FORMAL_TRAINING_PYTEST_SUPPORT_RELATIVE_PATHS = (
    "tests/conftest.py",
    "scripts/register_tukf09_formal_training_authorization.py",
    "scripts/preflight_tukf09_backward_time_confirmation.py",
    "scripts/verify_tukf09_backward_time_confirmation_preflight.py",
)
REQUIRED_FORMAL_TRAINING_PYTEST_TRAILING_ARGUMENTS = (
    "-q",
    "-p",
    "no:cacheprovider",
)
REQUIRED_FORMAL_TRAINING_PYTEST_ENVIRONMENT = {
    "PYTHONDONTWRITEBYTECODE": "1",
    "PYTHONUNBUFFERED": "1",
    "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1",
    "PYTEST_ADDOPTS": "",
    "PYTEST_PLUGINS": "",
}
_NVIDIA_SMI_IDENTITY_COMMAND = (
    "nvidia-smi",
    "--query-gpu=index,uuid,driver_version",
    "--format=csv,noheader,nounits",
)
_NVIDIA_GPU_UUID_PATTERN = re.compile(
    r"GPU-[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-"
    r"[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}"
)
_NVIDIA_DRIVER_VERSION_PATTERN = re.compile(r"[0-9]+(?:\.[0-9]+){1,3}")
_PYTEST_COUNT_PATTERN = re.compile(
    r"(?P<count>[0-9]+)\s+(?P<kind>passed|failed|errors?|skipped)\b",
    flags=re.IGNORECASE,
)
EXPECTED_PREFLIGHT_FINAL_MEMBERS = frozenset(
    {
        "contract.snapshot.json",
        "parameters_only.npz",
        "population_registry.json",
        "preflight_manifest.sha256.json",
        "preflight_summary.json",
        "raw_source_manifest.sha256.json",
        "semantic_input_manifest.sha256.json",
        "independent/independent_audit.json",
    }
)


def _query_nvidia_smi_gpu_zero(
    *,
    runner: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
) -> tuple[str, str]:
    """Return physical NVIDIA GPU zero UUID and driver version, or stop."""

    command = list(_NVIDIA_SMI_IDENTITY_COMMAND)
    try:
        completed = runner(
            command,
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=15,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise RuntimeError("nvidia-smi runtime identity query failed") from exc
    if int(completed.returncode) != 0 or str(completed.stderr or "").strip():
        raise RuntimeError("nvidia-smi runtime identity query failed")

    records: dict[int, tuple[str, str]] = {}
    for raw_line in str(completed.stdout or "").splitlines():
        if not raw_line.strip():
            continue
        fields = tuple(field.strip() for field in raw_line.split(","))
        if len(fields) != 3 or re.fullmatch(r"[0-9]+", fields[0]) is None:
            raise RuntimeError("nvidia-smi returned a malformed runtime identity row")
        index = int(fields[0])
        gpu_uuid, driver_version = fields[1:]
        if (
            index in records
            or _NVIDIA_GPU_UUID_PATTERN.fullmatch(gpu_uuid) is None
            or _NVIDIA_DRIVER_VERSION_PATTERN.fullmatch(driver_version) is None
        ):
            raise RuntimeError("nvidia-smi returned a malformed runtime identity row")
        records[index] = (gpu_uuid, driver_version)
    if set(records) != {0}:
        raise RuntimeError(
            "nvidia-smi did not report one unambiguous physical GPU at index zero"
        )
    return records[0]


def validate_runtime_environment_identity(
    identity: Mapping[str, Any],
) -> dict[str, Any]:
    """Validate the exact formal CUDA runtime identity schema."""

    record = dict(identity)
    if set(record) != set(RUNTIME_ENVIRONMENT_IDENTITY_KEYS):
        raise RuntimeError("formal training runtime environment identity schema changed")
    if record["schema_version"] != "tukf09_runtime_environment_identity_v1":
        raise RuntimeError("formal training runtime environment identity version changed")
    for key in (
        "python_version",
        "python_executable",
        "numpy_version",
        "torch_version",
        "psutil_version",
        "torch_cuda_runtime_version",
        "cuda_device_name_0",
        "nvidia_gpu_uuid_0",
        "nvidia_driver_version",
        "platform",
        "machine",
    ):
        if not isinstance(record[key], str) or not record[key].strip():
            raise RuntimeError(
                f"formal training runtime environment identity is invalid: {key}"
            )
    if not Path(record["python_executable"]).is_absolute():
        raise RuntimeError("formal training Python executable identity is not absolute")
    if record["cuda_available"] is not True:
        raise RuntimeError("formal training CUDA runtime is unavailable")
    for key in ("cuda_device_count", "logical_cpu_count"):
        value = record[key]
        if isinstance(value, bool) or not isinstance(value, int) or value < 1:
            raise RuntimeError(
                f"formal training runtime environment identity is invalid: {key}"
            )
    cudnn_version = record["cudnn_version"]
    if (
        isinstance(cudnn_version, bool)
        or not isinstance(cudnn_version, int)
        or cudnn_version < 1
    ):
        raise RuntimeError("formal training cuDNN version identity is invalid")
    if _NVIDIA_GPU_UUID_PATTERN.fullmatch(record["nvidia_gpu_uuid_0"]) is None:
        raise RuntimeError("formal training NVIDIA GPU UUID identity is invalid")
    if (
        _NVIDIA_DRIVER_VERSION_PATTERN.fullmatch(record["nvidia_driver_version"])
        is None
    ):
        raise RuntimeError("formal training NVIDIA driver identity is invalid")
    return record


def runtime_environment_identity() -> dict[str, Any]:
    """Collect the exact Python, numerical-library, CUDA, GPU, and driver identity."""

    try:
        import psutil
        import torch
    except ImportError as exc:
        raise RuntimeError(
            "PyTorch and psutil are required for formal training runtime identity"
        ) from exc
    if str(os.environ.get("CUDA_VISIBLE_DEVICES", "")).strip():
        raise RuntimeError(
            "CUDA_VISIBLE_DEVICES remapping is forbidden for formal training identity"
        )
    if not bool(torch.cuda.is_available()):
        raise RuntimeError("CUDA is unavailable for the formal CUDA training route")
    try:
        cuda_device_count = int(torch.cuda.device_count())
        cuda_device_name_0 = str(torch.cuda.get_device_name(0))
        torch_cuda_runtime_version = str(torch.version.cuda or "")
        cudnn_raw = torch.backends.cudnn.version()
        cudnn_version = None if cudnn_raw is None else int(cudnn_raw)
    except Exception as exc:
        raise RuntimeError("CUDA runtime identity collection failed") from exc
    if cuda_device_count < 1 or not cuda_device_name_0 or not torch_cuda_runtime_version:
        raise RuntimeError("CUDA runtime identity is incomplete")
    gpu_uuid, driver_version = _query_nvidia_smi_gpu_zero()
    identity = {
        "schema_version": "tukf09_runtime_environment_identity_v1",
        "python_version": platform.python_version(),
        "python_executable": os.path.abspath(sys.executable),
        "numpy_version": str(np.__version__),
        "torch_version": str(torch.__version__),
        "psutil_version": str(psutil.__version__),
        "torch_cuda_runtime_version": torch_cuda_runtime_version,
        "cudnn_version": cudnn_version,
        "cuda_available": True,
        "cuda_device_count": cuda_device_count,
        "cuda_device_name_0": cuda_device_name_0,
        "nvidia_gpu_uuid_0": gpu_uuid,
        "nvidia_driver_version": driver_version,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "logical_cpu_count": os.cpu_count(),
    }
    return validate_runtime_environment_identity(identity)


def validate_formal_training_required_test_policy(
    execution: Mapping[str, Any],
) -> dict[str, Any]:
    """Validate the one exact pytest policy admitted for formal training."""

    policy = execution.get("required_test_policy")
    if not isinstance(policy, dict):
        raise RuntimeError("formal training required-test policy is missing")
    expected_keys = {
        "pytest_files",
        "pytest_support_files",
        "pytest_trailing_arguments",
        "expected_passed_count",
        "required_failed_count",
        "required_error_count",
        "required_skipped_count",
    }
    if set(policy) != expected_keys:
        raise RuntimeError("formal training required-test policy schema changed")
    if policy.get("pytest_files") != list(
        REQUIRED_FORMAL_TRAINING_PYTEST_RELATIVE_PATHS
    ):
        raise RuntimeError("formal training required pytest file list changed")
    if policy.get("pytest_support_files") != list(
        REQUIRED_FORMAL_TRAINING_PYTEST_SUPPORT_RELATIVE_PATHS
    ):
        raise RuntimeError("formal training required pytest support file list changed")
    if policy.get("pytest_trailing_arguments") != list(
        REQUIRED_FORMAL_TRAINING_PYTEST_TRAILING_ARGUMENTS
    ):
        raise RuntimeError("formal training required pytest arguments changed")
    passed_count = policy.get("expected_passed_count")
    if (
        isinstance(passed_count, bool)
        or not isinstance(passed_count, int)
        or passed_count < 1
        or policy.get("required_failed_count") != 0
        or policy.get("required_error_count") != 0
        or policy.get("required_skipped_count") != 0
    ):
        raise RuntimeError("formal training required pytest counts are invalid")
    for key in (
        "required_failed_count",
        "required_error_count",
        "required_skipped_count",
    ):
        if type(policy[key]) is not int:
            raise RuntimeError("formal training required pytest counts are invalid")
    return dict(policy)


def build_formal_training_required_test_command(
    execution: Mapping[str, Any],
    *,
    python_executable: str | Path | None = None,
) -> list[str]:
    """Build the exact self-run pytest command bound by the admission."""

    validate_formal_training_required_test_policy(execution)
    executable = sys.executable if python_executable is None else python_executable
    return [
        os.fspath(executable),
        "-B",
        "-m",
        "pytest",
        *REQUIRED_FORMAL_TRAINING_PYTEST_RELATIVE_PATHS,
        *REQUIRED_FORMAL_TRAINING_PYTEST_TRAILING_ARGUMENTS,
    ]


def formal_training_required_pytest_file_records(
    project_root: str | Path,
) -> dict[str, dict[str, Any]]:
    """Hash every directly selected pytest file and its auto-loaded support file."""

    root = Path(project_root)
    records: dict[str, dict[str, Any]] = {}
    for relative in (
        *REQUIRED_FORMAL_TRAINING_PYTEST_RELATIVE_PATHS,
        *REQUIRED_FORMAL_TRAINING_PYTEST_SUPPORT_RELATIVE_PATHS,
    ):
        path = require_regular_unlinked_file(
            root / relative,
            label="required formal-training pytest file",
            stop_at=root,
        )
        records[relative] = {
            "sha256": sha256_file(path),
            "size_bytes": path.stat().st_size,
        }
    return records


def parse_formal_training_pytest_summary_counts(
    stdout: str, stderr: str
) -> dict[str, int]:
    """Parse the final pytest summary used by the exact-count admission gate."""

    candidates = [
        line.strip()
        for line in (str(stdout) + "\n" + str(stderr)).splitlines()
        if _PYTEST_COUNT_PATTERN.search(line)
    ]
    if not candidates:
        raise RuntimeError("required pytest output lacks a count summary")
    summary = candidates[-1]
    counts = {"passed": 0, "failed": 0, "error": 0, "skipped": 0}
    for match in _PYTEST_COUNT_PATTERN.finditer(summary):
        kind = match.group("kind").lower()
        normalized = "error" if kind in {"error", "errors"} else kind
        counts[normalized] += int(match.group("count"))
    return counts


def validate_training_admission_test_evidence(
    evidence: Mapping[str, Any],
    execution: Mapping[str, Any],
    project_root: str | Path,
) -> dict[str, Any]:
    """Independently revalidate all persisted required-pytest evidence."""

    expected_keys = {
        "result",
        "command",
        "exit_code",
        "passed_count",
        "failed_count",
        "error_count",
        "skipped_count",
        "duration_seconds",
        "stdout",
        "stderr",
        "stdout_sha256",
        "stderr_sha256",
        "pytest_file_records",
        "environment_overrides",
    }
    record = dict(evidence)
    policy = validate_formal_training_required_test_policy(execution)
    if set(record) != expected_keys:
        raise RuntimeError("required pytest evidence schema changed")
    integer_counts = (
        record.get("exit_code"),
        record.get("passed_count"),
        record.get("failed_count"),
        record.get("error_count"),
        record.get("skipped_count"),
    )
    if any(type(value) is not int for value in integer_counts):
        raise RuntimeError("required pytest evidence count types changed")
    if (
        record.get("result") != "PASS"
        or record.get("command")
        != build_formal_training_required_test_command(execution)
        or record.get("exit_code") != 0
        or record.get("passed_count") != policy["expected_passed_count"]
        or record.get("failed_count") != 0
        or record.get("error_count") != 0
        or record.get("skipped_count") != 0
        or record.get("pytest_file_records")
        != formal_training_required_pytest_file_records(project_root)
        or record.get("environment_overrides")
        != REQUIRED_FORMAL_TRAINING_PYTEST_ENVIRONMENT
    ):
        raise RuntimeError("required pytest evidence does not satisfy the exact gate")
    duration = record.get("duration_seconds")
    if (
        isinstance(duration, bool)
        or not isinstance(duration, (int, float))
        or not math.isfinite(float(duration))
        or float(duration) < 0.0
    ):
        raise RuntimeError("required pytest evidence duration is invalid")
    for stream in ("stdout", "stderr"):
        content = record.get(stream)
        digest = record.get(f"{stream}_sha256")
        if not isinstance(content, str) or digest != hashlib.sha256(
            content.encode("utf-8")
        ).hexdigest():
            raise RuntimeError(f"required pytest {stream} evidence hash mismatch")
    counts = parse_formal_training_pytest_summary_counts(
        record["stdout"], record["stderr"]
    )
    if counts != {
        "passed": policy["expected_passed_count"],
        "failed": 0,
        "error": 0,
        "skipped": 0,
    }:
        raise RuntimeError("required pytest evidence summary changed")
    return record


@dataclass(frozen=True)
class VerifiedAuthorization:
    record: Mapping[str, Any]
    authorization_path: Path
    authorization_file_sha256: str
    contract_sha256: str
    preflight_final_manifest_sha256: str
    output_root: Path
    project_root: Path


@dataclass(frozen=True)
class PeriodIdentity:
    name: str
    start_date: str
    end_date: str
    day_count: int
    first_scoring_index: int
    first_scoring_date: str


@dataclass(frozen=True)
class PeriodArrays:
    """Read-only arrays for one permitted training or validation period."""

    dates_ns: np.ndarray
    forcing: np.ndarray
    observations: np.ndarray


@dataclass(frozen=True)
class TrainingAdmissionContext:
    experiment_id: str
    project_root: Path
    output_root: Path
    preflight_root: Path
    data_root: Path
    authorization: VerifiedAuthorization
    contract_sha256: str
    preflight_final_manifest_sha256: str
    source_anchor_sha256: Mapping[str, str]
    raw_source_files: Mapping[str, Mapping[str, Any]]
    ordered_basin_ids: tuple[str, ...]
    parameter_names: tuple[str, ...]
    parameter_values: np.ndarray
    periods: Mapping[str, PeriodIdentity]
    semantic_members: Mapping[str, Mapping[str, Mapping[str, Any]]]
    evaluation_identity_count: int
    evaluation_identity_sha256: str
    access_ledger: Mapping[str, int]

    @property
    def evaluation_access_count(self) -> int:
        """Single compatibility counter required by all training runners."""
        return sum(int(value) for value in self.access_ledger.values())


def _reject_json_constant(token: str) -> None:
    raise ValueError(f"non-finite JSON constant is forbidden: {token}")


def _object_without_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key is forbidden: {key}")
        result[key] = value
    return result


def read_json_strict(path: str | Path) -> dict[str, Any]:
    value = json.loads(
        Path(path).read_text(encoding="utf-8"),
        parse_constant=_reject_json_constant,
        object_pairs_hook=_object_without_duplicate_keys,
    )
    if not isinstance(value, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return value


def canonical_json_bytes(value: Any, *, trailing_line_feed: bool = True) -> bytes:
    content = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return content + (b"\n" if trailing_line_feed else b"")


def canonical_json_sha256(value: Any) -> str:
    return hashlib.sha256(
        canonical_json_bytes(value, trailing_line_feed=False)
    ).hexdigest()


def sha256_file(path: str | Path, *, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def path_exists_including_broken_link(path: str | Path) -> bool:
    return os.path.lexists(os.fspath(path))


def _absolute_without_resolving(path: str | Path) -> Path:
    return Path(os.path.abspath(os.fspath(path)))


def _same_path(left: str | Path, right: str | Path) -> bool:
    return os.path.normcase(os.fspath(_absolute_without_resolving(left))) == os.path.normcase(
        os.fspath(_absolute_without_resolving(right))
    )


def ensure_within(path: str | Path, parent: str | Path) -> Path:
    candidate = Path(path).resolve(strict=False)
    boundary = Path(parent).resolve(strict=False)
    try:
        candidate.relative_to(boundary)
    except ValueError as exc:
        raise ValueError(f"path escapes its fixed root: {path}") from exc
    return candidate


def ensure_no_symlink_components(path: str | Path, *, stop_at: str | Path | None = None) -> None:
    candidate = _absolute_without_resolving(path)
    boundary = (
        _absolute_without_resolving(stop_at) if stop_at is not None else Path(candidate.anchor)
    )
    ensure_within(candidate, boundary)
    relative = candidate.relative_to(boundary)
    current = boundary
    paths = [boundary]
    for component in relative.parts:
        current = current / component
        paths.append(current)
    for component_path in paths:
        if not path_exists_including_broken_link(component_path):
            continue
        status = component_path.lstat()
        attributes = int(getattr(status, "st_file_attributes", 0))
        reparse_flag = int(getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))
        if stat.S_ISLNK(status.st_mode) or bool(attributes & reparse_flag):
            raise ValueError(f"linked path is forbidden: {component_path}")


def require_regular_unlinked_file(
    path: str | Path,
    *,
    label: str,
    stop_at: str | Path | None = None,
) -> Path:
    candidate = _absolute_without_resolving(path)
    ensure_no_symlink_components(candidate, stop_at=stop_at)
    if not candidate.is_file() or candidate.is_symlink():
        raise FileNotFoundError(f"{label} is missing or not a regular file: {candidate}")
    if candidate.stat().st_nlink != 1:
        raise ValueError(f"linked {label} is forbidden: {candidate}")
    return candidate


def _safe_relative_path(text: str) -> PurePosixPath:
    relative = PurePosixPath(text)
    if (
        not text
        or relative.is_absolute()
        or "\\" in text
        or any(part in {"", ".", ".."} for part in relative.parts)
        or relative.as_posix() != text
    ):
        raise ValueError(f"noncanonical relative path is forbidden: {text!r}")
    return relative


def atomic_write_bytes_exclusive(path: str | Path, content: bytes) -> Path:
    destination = _absolute_without_resolving(path)
    if path_exists_including_broken_link(destination):
        raise FileExistsError(f"destination already exists: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    ensure_no_symlink_components(destination.parent)
    # Keep the sibling name short enough for Windows test roots that approach
    # the legacy path-length boundary.
    temporary = destination.with_name(f".pending-{uuid.uuid4().hex[:8]}")
    try:
        with temporary.open("xb") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        if path_exists_including_broken_link(destination):
            raise FileExistsError(f"destination appeared during publication: {destination}")
        os.replace(temporary, destination)
    finally:
        if path_exists_including_broken_link(temporary):
            temporary.unlink()
    return destination


def atomic_write_json_exclusive(path: str | Path, value: Mapping[str, Any]) -> Path:
    return atomic_write_bytes_exclusive(path, canonical_json_bytes(dict(value)))


def atomic_publish_directory(
    destination: str | Path,
    payloads: Mapping[str, bytes],
) -> Path:
    target = _absolute_without_resolving(destination)
    if path_exists_including_broken_link(target):
        raise FileExistsError(f"destination directory already exists: {target}")
    target.parent.mkdir(parents=True, exist_ok=True)
    ensure_no_symlink_components(target.parent)
    token = uuid.uuid4().hex
    # The final member name can already be long; a compact sibling avoids
    # exceeding the legacy Windows path limit before the atomic rename.
    pending = target.with_name(f".pending-{token[:8]}")
    pending.mkdir(parents=False, exist_ok=False)
    try:
        for relative_text, content in sorted(payloads.items()):
            relative = _safe_relative_path(relative_text)
            member = pending.joinpath(*relative.parts)
            ensure_within(member, pending)
            member.parent.mkdir(parents=True, exist_ok=True)
            with member.open("xb") as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
        actual = {
            path.relative_to(pending).as_posix()
            for path in pending.rglob("*")
            if path.is_file() and not path.is_symlink()
        }
        if actual != set(payloads):
            raise RuntimeError("atomic directory publication member set changed")
        if path_exists_including_broken_link(target):
            raise FileExistsError(f"destination appeared during publication: {target}")
        os.replace(pending, target)
    finally:
        if path_exists_including_broken_link(pending):
            resolved_pending = ensure_within(pending, target.parent)
            if token not in resolved_pending.name:
                raise RuntimeError("refusing to remove an unowned pending directory")
            shutil.rmtree(resolved_pending)
    return target


def build_file_manifest(
    root: str | Path,
    relative_paths: Iterable[str],
) -> dict[str, dict[str, Any]]:
    base = Path(root)
    files: dict[str, dict[str, Any]] = {}
    for relative_text in sorted(set(relative_paths)):
        relative = _safe_relative_path(relative_text)
        path = require_regular_unlinked_file(
            base.joinpath(*relative.parts), label="manifest member", stop_at=base
        )
        files[relative_text] = {
            "sha256": sha256_file(path),
            "size_bytes": path.stat().st_size,
        }
    return files


def verify_file_manifest(
    root: str | Path,
    files: Mapping[str, Mapping[str, Any]],
) -> None:
    base = Path(root)
    for relative_text, expected in sorted(files.items()):
        if set(expected) != {"sha256", "size_bytes"}:
            raise ValueError(f"manifest member schema changed: {relative_text}")
        relative = _safe_relative_path(relative_text)
        path = require_regular_unlinked_file(
            base.joinpath(*relative.parts), label="manifest member", stop_at=base
        )
        if path.stat().st_size != int(expected["size_bytes"]):
            raise RuntimeError(f"manifest member size mismatch: {relative_text}")
        if sha256_file(path) != expected["sha256"]:
            raise RuntimeError(f"manifest member hash mismatch: {relative_text}")


def _project_root_from_config(config: str | Path) -> Path:
    candidate = _absolute_without_resolving(config)
    if candidate.name != CONFIG_RELATIVE.name or candidate.parent.name != "configs":
        raise ValueError("scientific contract is not at the fixed config path")
    return candidate.parent.parent


def _require_fixed_path(
    actual: str | Path,
    project_root: Path,
    relative: Path,
    *,
    label: str,
) -> Path:
    expected = project_root / relative
    if not _same_path(actual, expected):
        raise ValueError(f"{label} must use the fixed path: {expected}")
    ensure_no_symlink_components(actual, stop_at=project_root)
    return _absolute_without_resolving(actual)


def _authorization_unsigned(record: Mapping[str, Any]) -> dict[str, Any]:
    unsigned = dict(record)
    try:
        unsigned.pop("authorization_record_sha256")
    except KeyError as exc:
        raise RuntimeError("authorization record lacks its payload hash") from exc
    return unsigned


def _validate_timestamp(value: Any) -> str:
    if not isinstance(value, str):
        raise RuntimeError("authorization timestamp is invalid")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise RuntimeError("authorization timestamp is invalid") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise RuntimeError("authorization timestamp must include a UTC offset")
    return value


def load_and_verify_authorization(
    path: str | Path,
    config: str | Path,
    preflight: str | Path,
    output_root: str | Path,
) -> VerifiedAuthorization:
    project_root = _project_root_from_config(config)
    config_path = _require_fixed_path(
        config, project_root, CONFIG_RELATIVE, label="scientific contract"
    )
    preflight_path = _require_fixed_path(
        preflight,
        project_root,
        PREFLIGHT_FINAL_RELATIVE,
        label="independent preflight final manifest",
    )
    authorization_path = _require_fixed_path(
        path, project_root, AUTHORIZATION_RELATIVE, label="authorization"
    )
    fixed_output = _require_fixed_path(
        output_root, project_root, OUTPUT_RELATIVE, label="output root"
    )
    config_path = require_regular_unlinked_file(
        config_path, label="scientific contract", stop_at=project_root
    )
    preflight_path = require_regular_unlinked_file(
        preflight_path,
        label="independent preflight final manifest",
        stop_at=project_root,
    )
    authorization_path = require_regular_unlinked_file(
        authorization_path, label="authorization", stop_at=project_root
    )

    contract_hash = sha256_file(config_path)
    preflight_hash = sha256_file(preflight_path)
    if contract_hash != EXPECTED_CONTRACT_SHA256:
        raise RuntimeError("scientific contract hash differs from the frozen value")
    if preflight_hash != EXPECTED_PREFLIGHT_FINAL_MANIFEST_SHA256:
        raise RuntimeError("preflight final manifest hash differs from the frozen value")

    contract = read_json_strict(config_path)
    if contract.get("experiment_id") != EXPERIMENT_ID:
        raise RuntimeError("scientific contract experiment identity changed")
    if contract.get("authorizations", {}).get("formal_training") is not False:
        raise RuntimeError("frozen contract must not be edited to authorize training")
    if contract.get("authorizations", {}).get("formal_evaluation") is not False:
        raise RuntimeError("frozen contract unexpectedly authorizes evaluation")

    record = read_json_strict(authorization_path)
    required_keys = {
        "schema_version",
        "experiment_id",
        "status",
        "authorization_text",
        "scope",
        "scientific_contract",
        "independent_preflight_final_manifest",
        "authorized_output_root",
        "registered_at_utc",
        "authorization_record_sha256",
    }
    if set(record) != required_keys:
        raise RuntimeError("authorization record schema changed")
    expected_scope = {
        "formal_training_authorized": True,
        "training_period_learning_authorized": True,
        "validation_checkpoint_selection_authorized": True,
        "training_selection_sealing_authorized": True,
        "independent_training_selection_verification_authorized": True,
        "formal_evaluation_authorized": False,
    }
    if (
        record["schema_version"] != "tukf09_formal_training_authorization_v1"
        or record["experiment_id"] != EXPERIMENT_ID
        or record["status"] != "FORMAL_TRAINING_AUTHORIZED_EVALUATION_HOLD"
        or record["authorization_text"] != EXACT_AUTHORIZATION_TEXT
        or record["scope"] != expected_scope
        or record["authorized_output_root"] != OUTPUT_RELATIVE.as_posix()
    ):
        raise RuntimeError("authorization scope or identity is invalid")
    _validate_timestamp(record["registered_at_utc"])
    expected_contract = {
        "path": CONFIG_RELATIVE.as_posix(),
        "sha256": EXPECTED_CONTRACT_SHA256,
    }
    expected_preflight = {
        "path": PREFLIGHT_FINAL_RELATIVE.as_posix(),
        "sha256": EXPECTED_PREFLIGHT_FINAL_MANIFEST_SHA256,
    }
    if record["scientific_contract"] != expected_contract:
        raise RuntimeError("authorization does not bind the frozen scientific contract")
    if record["independent_preflight_final_manifest"] != expected_preflight:
        raise RuntimeError("authorization does not bind the frozen preflight manifest")
    unsigned = _authorization_unsigned(record)
    if record["authorization_record_sha256"] != hashlib.sha256(
        canonical_json_bytes(unsigned)
    ).hexdigest():
        raise RuntimeError("authorization payload hash mismatch")
    return VerifiedAuthorization(
        record=record,
        authorization_path=authorization_path,
        authorization_file_sha256=sha256_file(authorization_path),
        contract_sha256=contract_hash,
        preflight_final_manifest_sha256=preflight_hash,
        output_root=fixed_output.resolve(strict=False),
        project_root=project_root.resolve(strict=False),
    )


_FORBIDDEN_TRAINING_SURFACE_TOKENS = frozenset(
    {
        "evaluation",
        "eval",
        "test",
        "testing",
        "holdout",
        "prediction",
        "predictions",
        "metric",
        "metrics",
    }
)


def gate_training_period_only(
    period_name: str,
    path: str | Path | None = None,
) -> str:
    name = str(period_name).strip().lower()
    if name not in TRAINING_PERIOD_NAMES:
        raise PermissionError("training/validation only: evaluation and test periods are forbidden")
    if path is not None:
        tokens = {
            token
            for token in re.split(r"[^a-z0-9]+", os.fspath(path).lower())
            if token
        }
        if tokens.intersection(_FORBIDDEN_TRAINING_SURFACE_TOKENS):
            raise PermissionError(
                "training/validation only: evaluation predictions and metrics are forbidden"
            )
    return name


def training_validation_period_specs(
    contract: Mapping[str, Any],
) -> dict[str, PeriodIdentity]:
    if contract.get("periods", {}).get("reset_each_period") is not True:
        raise RuntimeError("training and validation must reset independently")
    periods: dict[str, PeriodIdentity] = {}
    for name in TRAINING_PERIOD_NAMES:
        gate_training_period_only(name)
        source = contract["periods"][name]
        start, end = source["input"]
        day_count = (date.fromisoformat(end) - date.fromisoformat(start)).days + 1
        if day_count != int(source["day_count"]):
            raise RuntimeError(f"{name} period day count changed")
        first_index = int(source["first_scoring_index"])
        first_date = date.fromisoformat(start).fromordinal(
            date.fromisoformat(start).toordinal() + first_index
        ).isoformat()
        if source.get("first_scoring_date") != first_date:
            raise RuntimeError(f"{name} first scoring date changed")
        periods[name] = PeriodIdentity(
            name=name,
            start_date=start,
            end_date=end,
            day_count=day_count,
            first_scoring_index=first_index,
            first_scoring_date=first_date,
        )
    return periods


def _verify_exact_preflight_tree(preflight_root: Path) -> None:
    expected = set(EXPECTED_PREFLIGHT_FINAL_MEMBERS)
    expected.add("independent/manifest.final.sha256.json")
    actual_files: set[str] = set()
    for path in preflight_root.rglob("*"):
        if path.is_symlink():
            raise ValueError(f"linked preflight member is forbidden: {path}")
        if path.is_file():
            actual_files.add(path.relative_to(preflight_root).as_posix())
        elif not path.is_dir():
            raise ValueError(f"unknown preflight member type: {path}")
    if actual_files != expected:
        missing = sorted(expected.difference(actual_files))
        extra = sorted(actual_files.difference(expected))
        raise RuntimeError(f"preflight exact member set changed: missing={missing}, extra={extra}")


def _verify_source_anchors(
    contract: Mapping[str, Any], project_root: Path
) -> dict[str, str]:
    anchors = contract.get("source_anchors")
    if not isinstance(anchors, dict) or len(anchors) != 19:
        raise RuntimeError("source anchor count changed")
    verified: dict[str, str] = {}
    for name, record in anchors.items():
        if set(record) != {"path", "sha256"}:
            raise RuntimeError(f"source anchor schema changed: {name}")
        source = Path(record["path"])
        if not source.is_absolute():
            source = project_root / source
            source = require_regular_unlinked_file(
                source, label=f"source anchor {name}", stop_at=project_root
            )
        else:
            source = require_regular_unlinked_file(source, label=f"source anchor {name}")
        actual = sha256_file(source)
        if actual != record["sha256"]:
            raise RuntimeError(f"source anchor hash mismatch: {name}")
        verified[name] = actual
    return dict(sorted(verified.items()))


def _ordered_newline_sha256(values: Sequence[str]) -> str:
    return hashlib.sha256("".join(f"{value}\n" for value in values).encode("utf-8")).hexdigest()


def _verify_population(
    population: Mapping[str, Any], contract: Mapping[str, Any]
) -> tuple[str, ...]:
    required = {
        "schema_version",
        "experiment_id",
        "canonical",
        "previously_evaluated",
        "candidates",
        "eligible",
        "date_incomplete",
        "missing_days_by_basin",
    }
    if set(population) != required:
        raise RuntimeError("population registry schema changed")
    if (
        population["schema_version"] != "tukf09_population_registry_v1"
        or population["experiment_id"] != EXPERIMENT_ID
    ):
        raise RuntimeError("population registry identity changed")
    lists: dict[str, tuple[str, ...]] = {}
    for key in (
        "canonical",
        "previously_evaluated",
        "candidates",
        "eligible",
        "date_incomplete",
    ):
        values = tuple(population[key])
        if any(not isinstance(value, str) or len(value) != 8 or not value.isdigit() for value in values):
            raise RuntimeError(f"invalid basin identity in {key}")
        if len(set(values)) != len(values):
            raise RuntimeError(f"duplicate basin identity in {key}")
        lists[key] = values
    frozen = contract["population"]
    if len(lists["canonical"]) != int(frozen["canonical_basin_count"]):
        raise RuntimeError("canonical basin count changed")
    if lists["previously_evaluated"] != tuple(frozen["previously_evaluated_basins"]):
        raise RuntimeError("previously evaluated basin order changed")
    prior = set(lists["previously_evaluated"])
    expected_candidates = tuple(value for value in lists["canonical"] if value not in prior)
    if lists["candidates"] != expected_candidates:
        raise RuntimeError("candidate basin order changed")
    incomplete = set(lists["date_incomplete"])
    expected_eligible = tuple(value for value in expected_candidates if value not in incomplete)
    if lists["eligible"] != expected_eligible:
        raise RuntimeError("eligible basin order changed")
    if len(lists["eligible"]) != int(frozen["primary_basin_count"]):
        raise RuntimeError("eligible basin count changed")
    if len(lists["date_incomplete"]) != int(frozen["date_incomplete_exclusion_count"]):
        raise RuntimeError("date-incomplete basin count changed")
    if _ordered_newline_sha256(lists["eligible"]) != frozen[
        "eligible_ordered_newline_utf8_sha256"
    ]:
        raise RuntimeError("eligible ordered basin digest changed")
    if canonical_json_sha256(list(lists["eligible"])) != frozen[
        "eligible_compact_json_sha256"
    ]:
        raise RuntimeError("eligible compact basin digest changed")
    missing_days = population["missing_days_by_basin"]
    if set(missing_days) != set(expected_candidates):
        raise RuntimeError("missing-day registry does not cover the candidates")
    if any(int(missing_days[value]) != 0 for value in lists["eligible"]):
        raise RuntimeError("eligible basin has a nonzero missing-day count")
    if any(int(missing_days[value]) <= 0 for value in lists["date_incomplete"]):
        raise RuntimeError("excluded basin lacks a positive missing-day count")
    return lists["eligible"]


def _load_parameter_snapshot(
    path: Path,
    ordered_basin_ids: Sequence[str],
    contract: Mapping[str, Any],
) -> tuple[tuple[str, ...], np.ndarray]:
    require_regular_unlinked_file(path, label="parameter-only archive", stop_at=path.parent)
    with np.load(path, allow_pickle=False) as archive:
        if set(archive.files) != {"basin_ids", "parameter_names", "values"}:
            raise RuntimeError("parameter-only archive member set changed")
        basin_ids = tuple(str(value) for value in archive["basin_ids"].tolist())
        parameter_names = tuple(str(value) for value in archive["parameter_names"].tolist())
        values = np.asarray(archive["values"], dtype=np.float64).copy()
    expected_names = tuple(
        str(value).removeprefix("p_")
        for value in contract["filter_system"]["hydrological_model"]["parameter_columns"]
    )
    if basin_ids != tuple(ordered_basin_ids):
        raise RuntimeError("parameter-only basin order changed")
    if parameter_names != expected_names:
        raise RuntimeError("parameter-only column order changed")
    if values.shape != (len(ordered_basin_ids), len(expected_names)):
        raise RuntimeError("parameter-only array shape changed")
    if not np.isfinite(values).all():
        raise FloatingPointError("parameter-only array contains a non-finite value")
    values.setflags(write=False)
    return parameter_names, values


def _verify_raw_source_manifest(
    manifest: Mapping[str, Any],
    contract: Mapping[str, Any],
    *,
    verify_member_bytes: bool = True,
) -> dict[str, Mapping[str, Any]]:
    if set(manifest) != {
        "schema_version",
        "experiment_id",
        "file_count",
        "aggregate_sha256",
        "files",
    }:
        raise RuntimeError("raw source manifest schema changed")
    files = manifest["files"]
    if (
        manifest["schema_version"] != "tukf09_raw_source_manifest_v1"
        or manifest["experiment_id"] != EXPERIMENT_ID
        or int(manifest["file_count"]) != len(files)
        or len(files) != int(contract["raw_input_seal"]["candidate_raw_data_file_count"])
        or canonical_json_sha256(files) != manifest["aggregate_sha256"]
    ):
        raise RuntimeError("raw source manifest identity or aggregate changed")
    data_root = Path(contract["paths"]["data_root"])
    verified: dict[str, Mapping[str, Any]] = {}
    for relative_text, record in sorted(files.items()):
        if set(record) != {"sha256", "size_bytes"}:
            raise RuntimeError(f"raw source member schema changed: {relative_text}")
        relative = _safe_relative_path(relative_text)
        if verify_member_bytes:
            source = require_regular_unlinked_file(
                data_root.joinpath(*relative.parts), label="raw source", stop_at=data_root
            )
            if source.stat().st_size != int(record["size_bytes"]):
                raise RuntimeError(f"raw source size changed: {relative_text}")
            if sha256_file(source) != record["sha256"]:
                raise RuntimeError(f"raw source hash changed: {relative_text}")
        verified[relative_text] = dict(record)
    return verified


def _validate_semantic_record(
    key: str, record: Mapping[str, Any], period: PeriodIdentity
) -> None:
    if set(record) != {"dtype", "shape", "sha256"}:
        raise RuntimeError(f"semantic member schema changed: {key}")
    array_name = key.rsplit("/", 1)[-1]
    expected_dtype = "<i8" if array_name == "dates_ns" else "<f8"
    expected_shape = [period.day_count, 3] if array_name == "forcing" else [period.day_count]
    if (
        record["dtype"] != expected_dtype
        or record["shape"] != expected_shape
        or not isinstance(record["sha256"], str)
        or len(record["sha256"]) != 64
    ):
        raise RuntimeError(f"semantic member identity changed: {key}")


def _split_semantic_manifest(
    manifest: Mapping[str, Any],
    contract: Mapping[str, Any],
    ordered_basin_ids: Sequence[str],
    periods: Mapping[str, PeriodIdentity],
) -> tuple[dict[str, dict[str, Mapping[str, Any]]], int, str]:
    if set(manifest) != {
        "schema_version",
        "experiment_id",
        "member_count",
        "aggregate_sha256",
        "members",
    }:
        raise RuntimeError("semantic input manifest schema changed")
    members = manifest["members"]
    expected_total = int(contract["raw_input_seal"]["semantic_array_member_count"])
    if (
        manifest["schema_version"] != "tukf09_semantic_input_manifest_v1"
        or manifest["experiment_id"] != EXPERIMENT_ID
        or int(manifest["member_count"]) != len(members)
        or len(members) != expected_total
        or canonical_json_sha256(members) != manifest["aggregate_sha256"]
    ):
        raise RuntimeError("semantic input manifest identity or aggregate changed")
    expected_keys = {
        f"{basin}/{period}/{array_name}"
        for basin in ordered_basin_ids
        for period in (*TRAINING_PERIOD_NAMES, "evaluation")
        for array_name in SEMANTIC_ARRAY_NAMES
    }
    if set(members) != expected_keys:
        raise RuntimeError("semantic input member set changed")

    selected: dict[str, dict[str, Mapping[str, Any]]] = {
        name: {} for name in TRAINING_PERIOD_NAMES
    }
    evaluation_members: dict[str, Mapping[str, Any]] = {}
    evaluation_period_source = contract["periods"]["evaluation"]
    evaluation_period = PeriodIdentity(
        name="evaluation",
        start_date=evaluation_period_source["input"][0],
        end_date=evaluation_period_source["input"][1],
        day_count=int(evaluation_period_source["day_count"]),
        first_scoring_index=int(evaluation_period_source["first_scoring_index"]),
        first_scoring_date=evaluation_period_source["first_scoring_date"],
    )
    for key, record in sorted(members.items()):
        basin_id, period_name, array_name = key.split("/")
        if array_name not in SEMANTIC_ARRAY_NAMES:
            raise RuntimeError(f"unknown semantic array: {key}")
        if period_name in TRAINING_PERIOD_NAMES:
            _validate_semantic_record(key, record, periods[period_name])
            selected[period_name][f"{basin_id}/{array_name}"] = dict(record)
        elif period_name == "evaluation":
            _validate_semantic_record(key, record, evaluation_period)
            evaluation_members[key] = dict(record)
        else:
            raise PermissionError("training/validation only: unknown semantic period")
    return selected, len(evaluation_members), canonical_json_sha256(evaluation_members)


def _normalize_basin_id(value: Any) -> str:
    text = str(value).strip()
    if not text.isascii() or not text.isdigit() or not 1 <= len(text) <= 8:
        raise ValueError(f"invalid basin identifier: {value!r}")
    return text.zfill(8)


def _load_area_by_basin(data_root: Path, basin_ids: Sequence[str]) -> dict[str, float]:
    path = require_regular_unlinked_file(
        data_root / "camels_attributes_v2.0" / "camels_topo.txt",
        label="topographic attributes",
        stop_at=data_root,
    )
    requested = set(basin_ids)
    areas: dict[str, float] = {}
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle, delimiter=";")
        if not {"gauge_id", "area_gages2"}.issubset(reader.fieldnames or ()):
            raise KeyError("topographic attributes lack required columns")
        for row in reader:
            basin_id = _normalize_basin_id(row["gauge_id"])
            if basin_id not in requested:
                continue
            if basin_id in areas:
                raise ValueError(f"duplicate topographic area: {basin_id}")
            area = float(row["area_gages2"])
            if not math.isfinite(area) or area <= 0.0:
                raise ValueError(f"invalid topographic area: {basin_id}")
            areas[basin_id] = area
    if set(areas) != requested:
        raise KeyError("eligible topographic area coverage changed")
    return areas


def _period_layout(periods: Mapping[str, PeriodIdentity]) -> dict[str, dict[str, Any]]:
    layout: dict[str, dict[str, Any]] = {}
    all_ordinals: set[int] = set()
    for name in TRAINING_PERIOD_NAMES:
        period = periods[name]
        ordinals = np.arange(
            date.fromisoformat(period.start_date).toordinal(),
            date.fromisoformat(period.end_date).toordinal() + 1,
            dtype=np.int64,
        )
        if ordinals.size != period.day_count:
            raise RuntimeError(f"{name} semantic day count changed")
        if all_ordinals.intersection(int(value) for value in ordinals):
            raise RuntimeError("training and validation semantic periods overlap")
        all_ordinals.update(int(value) for value in ordinals)
        dates = np.arange(
            np.datetime64(period.start_date, "D"),
            np.datetime64(period.end_date, "D") + np.timedelta64(1, "D"),
            dtype="datetime64[D]",
        ).astype("datetime64[ns]")
        layout[name] = {
            "ordinals": ordinals,
            "dates_ns": np.ascontiguousarray(dates.view("<i8"), dtype=np.dtype("<i8")),
        }
    return layout


def _ordinal_lookup(layout: Mapping[str, Mapping[str, Any]]) -> dict[int, tuple[str, int]]:
    lookup: dict[int, tuple[str, int]] = {}
    for period_name in TRAINING_PERIOD_NAMES:
        for index, ordinal in enumerate(layout[period_name]["ordinals"]):
            key = int(ordinal)
            if key in lookup:
                raise RuntimeError("semantic training dates contain a duplicate")
            lookup[key] = (period_name, index)
    return lookup


def _parse_flow_training_validation(
    path: Path,
    area_km2: float,
    layout: Mapping[str, Mapping[str, Any]],
    lookup: Mapping[int, tuple[str, int]],
) -> dict[str, np.ndarray]:
    values = {
        period: np.empty(len(layout[period]["ordinals"]), dtype=np.float64)
        for period in TRAINING_PERIOD_NAMES
    }
    counts = {
        period: np.zeros(len(layout[period]["ordinals"]), dtype=np.int16)
        for period in TRAINING_PERIOD_NAMES
    }
    prior_required: int | None = None
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            fields = line.split()
            if len(fields) < 5:
                continue
            try:
                ordinal = date(int(fields[1]), int(fields[2]), int(fields[3])).toordinal()
            except (TypeError, ValueError):
                continue
            location = lookup.get(ordinal)
            if location is None:
                continue
            if prior_required is not None and ordinal <= prior_required:
                raise ValueError(f"training flow dates are not strictly increasing: {path}")
            prior_required = ordinal
            period_name, index = location
            counts[period_name][index] += 1
            value = float(fields[4])
            if not math.isfinite(value) or value < 0.0:
                raise ValueError(f"invalid training discharge: {path}")
            values[period_name][index] = value
    factor = 2.4466 / float(area_km2)
    result: dict[str, np.ndarray] = {}
    for period_name in TRAINING_PERIOD_NAMES:
        if not np.all(counts[period_name] == 1):
            raise ValueError(f"incomplete training discharge support: {path}")
        converted = np.ascontiguousarray(values[period_name] * factor, dtype=np.dtype("<f8"))
        if not np.isfinite(converted).all() or np.any(converted < 0.0):
            raise ValueError(f"invalid converted training discharge: {path}")
        result[period_name] = converted
    return result


def _parse_forcing_training_validation(
    path: Path,
    layout: Mapping[str, Mapping[str, Any]],
    lookup: Mapping[int, tuple[str, int]],
) -> dict[str, np.ndarray]:
    raw = {
        period: np.empty((len(layout[period]["ordinals"]), 5), dtype=np.float64)
        for period in TRAINING_PERIOD_NAMES
    }
    counts = {
        period: np.zeros(len(layout[period]["ordinals"]), dtype=np.int16)
        for period in TRAINING_PERIOD_NAMES
    }
    prior_required: int | None = None
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            fields = line.split()
            if len(fields) < 10:
                continue
            try:
                ordinal = date(int(fields[0]), int(fields[1]), int(fields[2])).toordinal()
            except (TypeError, ValueError):
                continue
            location = lookup.get(ordinal)
            if location is None:
                continue
            if prior_required is not None and ordinal <= prior_required:
                raise ValueError(f"training forcing dates are not strictly increasing: {path}")
            prior_required = ordinal
            period_name, index = location
            counts[period_name][index] += 1
            row = tuple(float(fields[position]) for position in (4, 5, 6, 8, 9))
            if not all(math.isfinite(value) for value in row):
                raise ValueError(f"invalid training forcing: {path}")
            raw[period_name][index] = row
    result: dict[str, np.ndarray] = {}
    for period_name in TRAINING_PERIOD_NAMES:
        if not np.all(counts[period_name] == 1):
            raise ValueError(f"incomplete training forcing support: {path}")
        day_length = raw[period_name][:, 0]
        precipitation = raw[period_name][:, 1]
        shortwave = raw[period_name][:, 2]
        mean_temperature = (raw[period_name][:, 3] + raw[period_name][:, 4]) / 2.0
        shortwave_megajoule = shortwave * day_length / 1.0e6
        potential_evapotranspiration = np.where(
            mean_temperature > -5.0,
            shortwave_megajoule * (mean_temperature + 5.0) / 245.0,
            0.0,
        )
        forcing = np.ascontiguousarray(
            np.stack(
                [
                    precipitation,
                    mean_temperature,
                    np.maximum(potential_evapotranspiration, 0.0),
                ],
                axis=-1,
            ),
            dtype=np.dtype("<f8"),
        )
        if not np.isfinite(forcing).all():
            raise ValueError(f"non-finite derived training forcing: {path}")
        result[period_name] = forcing
    return result


def semantic_array_identity(name: str, array: np.ndarray, dtype: str) -> dict[str, Any]:
    canonical = np.ascontiguousarray(array, dtype=np.dtype(dtype))
    name_bytes = name.encode("utf-8")
    dtype_bytes = dtype.encode("utf-8")
    digest = hashlib.sha256()
    digest.update(struct.pack("<Q", len(name_bytes)))
    digest.update(name_bytes)
    digest.update(struct.pack("<Q", len(dtype_bytes)))
    digest.update(dtype_bytes)
    digest.update(struct.pack("<q", canonical.ndim))
    for dimension in canonical.shape:
        digest.update(struct.pack("<q", int(dimension)))
    digest.update(canonical.tobytes(order="C"))
    return {
        "dtype": dtype,
        "shape": [int(value) for value in canonical.shape],
        "sha256": digest.hexdigest(),
    }


def _raw_paths_by_basin(
    raw_files: Mapping[str, Mapping[str, Any]], data_root: Path
) -> dict[str, tuple[Path, Path]]:
    flow: dict[str, Path] = {}
    forcing: dict[str, Path] = {}
    for relative_text in raw_files:
        filename = PurePosixPath(relative_text).name
        basin_id = filename[:8]
        path = data_root.joinpath(*PurePosixPath(relative_text).parts)
        if relative_text.startswith("usgs_streamflow/"):
            flow[basin_id] = path
        elif relative_text.startswith("basin_mean_forcing/maurer/"):
            forcing[basin_id] = path
    if set(flow) != set(forcing):
        raise RuntimeError("raw flow/forcing basin identities differ")
    return {basin: (flow[basin], forcing[basin]) for basin in sorted(flow)}


def _recompute_training_validation_semantic_members(
    contract: Mapping[str, Any],
    ordered_basin_ids: Sequence[str],
    periods: Mapping[str, PeriodIdentity],
    raw_files: Mapping[str, Mapping[str, Any]],
    expected: Mapping[str, Mapping[str, Mapping[str, Any]]],
) -> None:
    data_root = Path(contract["paths"]["data_root"])
    paths = _raw_paths_by_basin(raw_files, data_root)
    areas = _load_area_by_basin(data_root, ordered_basin_ids)
    layout = _period_layout(periods)
    lookup = _ordinal_lookup(layout)
    for basin_id in ordered_basin_ids:
        if basin_id not in paths:
            raise RuntimeError(f"eligible basin lacks raw-source identity: {basin_id}")
        flow_path, forcing_path = paths[basin_id]
        observations = _parse_flow_training_validation(
            flow_path, areas[basin_id], layout, lookup
        )
        forcing = _parse_forcing_training_validation(forcing_path, layout, lookup)
        for period_name in TRAINING_PERIOD_NAMES:
            arrays = {
                "dates_ns": layout[period_name]["dates_ns"],
                "forcing": forcing[period_name],
                "observations": observations[period_name],
            }
            for array_name in SEMANTIC_ARRAY_NAMES:
                full_name = f"{basin_id}/{period_name}/{array_name}"
                identity = semantic_array_identity(
                    full_name,
                    arrays[array_name],
                    "<i8" if array_name == "dates_ns" else "<f8",
                )
                if identity != expected[period_name][f"{basin_id}/{array_name}"]:
                    raise RuntimeError(f"training semantic identity mismatch: {full_name}")


def load_training_validation_periods(
    context: TrainingAdmissionContext,
    basin_ids: Sequence[str] | None = None,
) -> dict[str, dict[str, PeriodArrays]]:
    """Load and hash-check only the training and validation arrays.

    The outer mapping preserves the requested basin order.  Every returned
    NumPy array is read-only.  Evaluation members remain represented only by
    the aggregate identity already stored on ``context``.
    """
    if context.evaluation_access_count != 0:
        raise PermissionError("training context already records evaluation access")
    requested = (
        tuple(context.ordered_basin_ids)
        if basin_ids is None
        else tuple(str(value) for value in basin_ids)
    )
    if not requested:
        raise ValueError("at least one training basin is required")
    if len(set(requested)) != len(requested):
        raise ValueError("duplicate requested training basin")
    allowed = set(context.ordered_basin_ids)
    unknown = [value for value in requested if value not in allowed]
    if unknown:
        raise ValueError(f"requested basin is outside the sealed population: {unknown}")
    if set(context.periods) != set(TRAINING_PERIOD_NAMES):
        raise PermissionError("training context exposes a non-training period")
    if set(context.semantic_members) != set(TRAINING_PERIOD_NAMES):
        raise PermissionError("training context exposes a non-training semantic group")

    paths = _raw_paths_by_basin(context.raw_source_files, context.data_root)
    areas = _load_area_by_basin(context.data_root, requested)
    layout = _period_layout(context.periods)
    lookup = _ordinal_lookup(layout)
    for period_name in TRAINING_PERIOD_NAMES:
        layout[period_name]["dates_ns"].setflags(write=False)

    result: dict[str, dict[str, PeriodArrays]] = {}
    for basin_id in requested:
        if basin_id not in paths:
            raise RuntimeError(f"sealed raw-source identity lacks basin {basin_id}")
        flow_path, forcing_path = paths[basin_id]
        selected_raw_records = {
            relative_text: record
            for relative_text, record in context.raw_source_files.items()
            if PurePosixPath(relative_text).name.startswith(basin_id)
            and (
                relative_text.startswith("usgs_streamflow/")
                or relative_text.startswith("basin_mean_forcing/maurer/")
            )
        }
        if len(selected_raw_records) != 2:
            raise RuntimeError(f"sealed raw-source records differ for basin {basin_id}")
        for relative_text, record in selected_raw_records.items():
            relative = _safe_relative_path(relative_text)
            source = require_regular_unlinked_file(
                context.data_root.joinpath(*relative.parts),
                label="selected training raw source",
                stop_at=context.data_root,
            )
            if (
                source.stat().st_size != int(record["size_bytes"])
                or sha256_file(source) != record["sha256"]
            ):
                raise RuntimeError(f"selected training raw source changed: {relative_text}")
        for period_name in TRAINING_PERIOD_NAMES:
            gate_training_period_only(period_name, flow_path)
            gate_training_period_only(period_name, forcing_path)
        observations = _parse_flow_training_validation(
            flow_path, areas[basin_id], layout, lookup
        )
        forcing = _parse_forcing_training_validation(forcing_path, layout, lookup)
        per_period: dict[str, PeriodArrays] = {}
        for period_name in TRAINING_PERIOD_NAMES:
            dates_ns = layout[period_name]["dates_ns"]
            arrays = {
                "dates_ns": dates_ns,
                "forcing": forcing[period_name],
                "observations": observations[period_name],
            }
            for array_name, array in arrays.items():
                full_name = f"{basin_id}/{period_name}/{array_name}"
                actual = semantic_array_identity(
                    full_name,
                    array,
                    "<i8" if array_name == "dates_ns" else "<f8",
                )
                expected = context.semantic_members[period_name].get(
                    f"{basin_id}/{array_name}"
                )
                if actual != expected:
                    raise RuntimeError(f"training semantic identity mismatch: {full_name}")
                array.setflags(write=False)
            per_period[period_name] = PeriodArrays(
                dates_ns=dates_ns,
                forcing=forcing[period_name],
                observations=observations[period_name],
            )
        result[basin_id] = per_period
    return result


def _verify_preflight_contents(
    config_path: Path,
    preflight_final_path: Path,
    project_root: Path,
    *,
    recompute_training_validation_semantics: bool,
    verify_all_raw_source_bytes: bool,
) -> dict[str, Any]:
    contract = read_json_strict(config_path)
    preflight_root = preflight_final_path.parent.parent
    _verify_exact_preflight_tree(preflight_root)
    final_manifest = read_json_strict(preflight_final_path)
    if (
        set(final_manifest)
        != {"schema_version", "experiment_id", "file_count", "files"}
        or final_manifest["schema_version"] != "tukf09_preflight_final_manifest_v1"
        or final_manifest["experiment_id"] != EXPERIMENT_ID
        or int(final_manifest["file_count"]) != 8
        or set(final_manifest["files"]) != EXPECTED_PREFLIGHT_FINAL_MEMBERS
    ):
        raise RuntimeError("independent preflight final manifest schema changed")
    verify_file_manifest(preflight_root, final_manifest["files"])
    if (preflight_root / "contract.snapshot.json").read_bytes() != config_path.read_bytes():
        raise RuntimeError("preflight contract snapshot differs from the frozen contract")

    source_hashes = _verify_source_anchors(contract, project_root)
    population = read_json_strict(preflight_root / "population_registry.json")
    ordered_basin_ids = _verify_population(population, contract)
    parameter_names, parameter_values = _load_parameter_snapshot(
        preflight_root / "parameters_only.npz", ordered_basin_ids, contract
    )
    periods = training_validation_period_specs(contract)
    raw_files = _verify_raw_source_manifest(
        read_json_strict(preflight_root / "raw_source_manifest.sha256.json"),
        contract,
        verify_member_bytes=verify_all_raw_source_bytes,
    )
    semantic_members, evaluation_count, evaluation_digest = _split_semantic_manifest(
        read_json_strict(preflight_root / "semantic_input_manifest.sha256.json"),
        contract,
        ordered_basin_ids,
        periods,
    )
    if recompute_training_validation_semantics:
        _recompute_training_validation_semantic_members(
            contract,
            ordered_basin_ids,
            periods,
            raw_files,
            semantic_members,
        )
    summary = read_json_strict(preflight_root / "preflight_summary.json")
    audit = read_json_strict(preflight_root / "independent/independent_audit.json")
    if (
        summary.get("status") != "PREFLIGHT_PASS_EXECUTION_HOLD"
        or summary.get("training_authorized") is not False
        or summary.get("evaluation_authorized") is not False
        or audit.get("status") != "REPRODUCIBLE"
        or audit.get("training_authorized") is not False
        or audit.get("evaluation_authorized") is not False
    ):
        raise RuntimeError("preflight is not reproducible at the training hold boundary")
    return {
        "contract": contract,
        "preflight_root": preflight_root,
        "source_hashes": source_hashes,
        "raw_files": raw_files,
        "ordered_basin_ids": ordered_basin_ids,
        "parameter_names": parameter_names,
        "parameter_values": parameter_values,
        "periods": periods,
        "semantic_members": semantic_members,
        "evaluation_count": evaluation_count,
        "evaluation_digest": evaluation_digest,
    }


def _gate_output_before_training(output_root: Path, *, require_absent: bool) -> None:
    if require_absent and path_exists_including_broken_link(output_root):
        raise FileExistsError(f"formal training output root already exists: {output_root}")
    if not path_exists_including_broken_link(output_root):
        return
    ensure_no_symlink_components(output_root)
    if not output_root.is_dir():
        raise FileExistsError(f"formal training output root is not a directory: {output_root}")
    for child in output_root.rglob("*"):
        tokens = {
            token
            for token in re.split(r"[^a-z0-9]+", child.relative_to(output_root).as_posix().lower())
            if token
        }
        if tokens.intersection(_FORBIDDEN_TRAINING_SURFACE_TOKENS):
            raise PermissionError("training output contains an evaluation surface")


def verify_preflight_for_training(
    config: str | Path,
    preflight: str | Path,
    authorization: str | Path,
    output_root: str | Path,
    *,
    require_output_absent: bool = False,
    recompute_training_validation_semantics: bool = True,
    verify_all_raw_source_bytes: bool = True,
) -> TrainingAdmissionContext:
    project_root = _project_root_from_config(config)
    fixed_output = _require_fixed_path(
        output_root, project_root, OUTPUT_RELATIVE, label="output root"
    )
    _gate_output_before_training(fixed_output, require_absent=require_output_absent)
    verified_authorization = load_and_verify_authorization(
        authorization, config, preflight, output_root
    )
    config_path = require_regular_unlinked_file(
        config, label="scientific contract", stop_at=project_root
    )
    preflight_path = require_regular_unlinked_file(
        preflight,
        label="independent preflight final manifest",
        stop_at=project_root,
    )
    evidence = _verify_preflight_contents(
        config_path,
        preflight_path,
        project_root,
        recompute_training_validation_semantics=recompute_training_validation_semantics,
        verify_all_raw_source_bytes=verify_all_raw_source_bytes,
    )
    access_ledger = {
        "evaluation_array_reads": 0,
        "evaluation_predictions": 0,
        "evaluation_metrics": 0,
        "evaluation_outputs": 0,
    }
    return TrainingAdmissionContext(
        experiment_id=EXPERIMENT_ID,
        project_root=project_root.resolve(strict=False),
        output_root=fixed_output.resolve(strict=False),
        preflight_root=evidence["preflight_root"].resolve(strict=False),
        data_root=Path(evidence["contract"]["paths"]["data_root"]).resolve(strict=False),
        authorization=verified_authorization,
        contract_sha256=verified_authorization.contract_sha256,
        preflight_final_manifest_sha256=(
            verified_authorization.preflight_final_manifest_sha256
        ),
        source_anchor_sha256=evidence["source_hashes"],
        raw_source_files=evidence["raw_files"],
        ordered_basin_ids=evidence["ordered_basin_ids"],
        parameter_names=evidence["parameter_names"],
        parameter_values=evidence["parameter_values"],
        periods=evidence["periods"],
        semantic_members=evidence["semantic_members"],
        evaluation_identity_count=evidence["evaluation_count"],
        evaluation_identity_sha256=evidence["evaluation_digest"],
        access_ledger=access_ledger,
    )


def load_and_verify_training_admission(
    path: str | Path,
    execution_config: str | Path,
    required_executable_paths: Sequence[str | Path],
) -> dict[str, Any]:
    """Verify the immutable technical admission before any training unit starts."""
    execution_path = _absolute_without_resolving(execution_config)
    if execution_path.parent.name != "configs":
        raise ValueError("training execution config is outside the fixed configs directory")
    project_root = execution_path.parent.parent
    execution_path = require_regular_unlinked_file(
        execution_path, label="training execution config", stop_at=project_root
    )
    admission_path = _require_fixed_path(
        path, project_root, ADMISSION_RELATIVE, label="training admission"
    )
    admission_path = require_regular_unlinked_file(
        admission_path, label="training admission", stop_at=project_root
    )
    raw = admission_path.read_bytes()
    payload = read_json_strict(admission_path)
    if raw != canonical_json_bytes(payload):
        raise RuntimeError("training admission is not canonical compact JSON with one LF")
    required_keys = {
        "schema_version",
        "experiment_id",
        "status",
        "admitted_at_utc",
        "formal_evaluation_authorized",
        "scientific_contract_sha256",
        "preflight_final_manifest_sha256",
        "authorization",
        "execution_config",
        "executables",
        "test_evidence",
        "runtime_environment_identity",
        "tensorfloat32",
        "resource_policy",
        "output_tree",
        "population",
        "training_validation_semantic_sha256",
        "evaluation_identity",
        "access_ledger",
        "training_admission_record_sha256",
    }
    if set(payload) != required_keys:
        raise RuntimeError("training admission schema changed")
    if (
        payload["schema_version"] != "tukf09_training_admission_v1"
        or payload["experiment_id"] != EXPERIMENT_ID
        or payload["status"] != "TRAINING_ADMITTED_EVALUATION_HOLD"
        or payload["formal_evaluation_authorized"] is not False
        or payload["scientific_contract_sha256"] != EXPECTED_CONTRACT_SHA256
        or payload["preflight_final_manifest_sha256"]
        != EXPECTED_PREFLIGHT_FINAL_MANIFEST_SHA256
    ):
        raise RuntimeError("training admission identity or frozen hashes changed")
    _validate_timestamp(payload["admitted_at_utc"])
    unsigned = dict(payload)
    stored_record_hash = unsigned.pop("training_admission_record_sha256")
    if stored_record_hash != hashlib.sha256(canonical_json_bytes(unsigned)).hexdigest():
        raise RuntimeError("training admission record hash mismatch")

    admitted_runtime_identity = validate_runtime_environment_identity(
        payload["runtime_environment_identity"]
    )
    current_runtime_identity = runtime_environment_identity()
    if current_runtime_identity != admitted_runtime_identity:
        raise RuntimeError("formal training runtime environment identity changed")

    execution_record = payload["execution_config"]
    if set(execution_record) != {"path", "sha256"}:
        raise RuntimeError("training admission execution-config schema changed")
    expected_execution_relative = execution_path.relative_to(project_root).as_posix()
    if (
        execution_record["path"] != expected_execution_relative
        or execution_record["sha256"] != sha256_file(execution_path)
    ):
        raise RuntimeError("training execution config hash mismatch")
    execution = read_json_strict(execution_path)
    if (
        execution.get("schema_version") != "tukf09_formal_training_execution_v1"
        or execution.get("experiment_id") != EXPERIMENT_ID
        or execution.get("authorization", {}).get("formal_evaluation") is not False
        or execution.get("paths", {}).get("results_root") != OUTPUT_RELATIVE.as_posix()
        or execution.get("resource_policy", {}).get("execution_route")
        != "local_sequential_controller"
        or execution.get("resource_policy", {}).get("filter_worker_count") != 2
        or execution.get("controller_order", {}).get("training_stages")
        != ["filter", "neural"]
        or payload["resource_policy"] != execution.get("resource_policy")
        or payload["output_tree"] != execution.get("paths")
    ):
        raise RuntimeError("training execution config no longer matches admission")

    authorization_record = payload["authorization"]
    if set(authorization_record) != {"path", "file_sha256", "record_sha256"}:
        raise RuntimeError("training admission authorization schema changed")
    authorization_path = project_root / AUTHORIZATION_RELATIVE
    verified_authorization = load_and_verify_authorization(
        authorization_path,
        project_root / CONFIG_RELATIVE,
        project_root / PREFLIGHT_FINAL_RELATIVE,
        project_root / OUTPUT_RELATIVE,
    )
    if (
        authorization_record["path"] != AUTHORIZATION_RELATIVE.as_posix()
        or authorization_record["file_sha256"]
        != verified_authorization.authorization_file_sha256
        or authorization_record["record_sha256"]
        != verified_authorization.record["authorization_record_sha256"]
    ):
        raise RuntimeError("training admission authorization hash mismatch")

    expected_executables: dict[str, Path] = {}
    for raw_path in required_executable_paths:
        candidate = Path(raw_path)
        if not candidate.is_absolute():
            candidate = project_root / candidate
        executable = require_regular_unlinked_file(
            candidate, label="required training executable", stop_at=project_root
        )
        try:
            relative = executable.relative_to(project_root).as_posix()
        except ValueError as exc:
            raise ValueError("required training executable escapes the project root") from exc
        if relative in expected_executables:
            raise ValueError(f"duplicate required training executable: {relative}")
        expected_executables[relative] = executable
    executable_records = payload["executables"]
    if set(executable_records) != set(expected_executables):
        raise RuntimeError("training admission executable set changed")
    for relative, executable in expected_executables.items():
        record = executable_records[relative]
        if set(record) != {"sha256", "size_bytes"}:
            raise RuntimeError(f"training executable record schema changed: {relative}")
        if (
            int(record["size_bytes"]) != executable.stat().st_size
            or record["sha256"] != sha256_file(executable)
        ):
            raise RuntimeError(f"training executable hash mismatch: {relative}")

    if payload["tensorfloat32"] != {"cuda_matmul": False, "cudnn": False}:
        raise RuntimeError("training admission does not disable TensorFloat32")
    validate_training_admission_test_evidence(
        payload["test_evidence"], execution, project_root
    )
    ledger = payload["access_ledger"]
    expected_ledger = {
        "evaluation_array_reads": 0,
        "evaluation_predictions": 0,
        "evaluation_metrics": 0,
        "evaluation_outputs": 0,
    }
    if ledger != expected_ledger:
        raise PermissionError("training admission records evaluation access")
    evaluation_identity = payload["evaluation_identity"]
    if (
        set(evaluation_identity)
        != {"member_count", "identity_only_sha256", "arrays_loaded"}
        or int(evaluation_identity["member_count"]) != 456 * 3
        or evaluation_identity["arrays_loaded"] is not False
        or not isinstance(evaluation_identity["identity_only_sha256"], str)
        or len(evaluation_identity["identity_only_sha256"]) != 64
    ):
        raise PermissionError("training admission evaluation identity boundary changed")
    return payload


def verify_initialized_training_root(
    *,
    output_root: str | Path,
    config_path: str | Path,
    authorization: str | Path,
    execution_config: str | Path,
    training_admission: str | Path,
    training_admission_record: Mapping[str, Any],
) -> dict[str, Any]:
    """Verify the initialized five-file trust root without forbidding resume trees."""

    execution_path = _absolute_without_resolving(execution_config)
    if execution_path.parent.name != "configs":
        raise ValueError("training execution config is outside the fixed configs directory")
    project_root = execution_path.parent.parent
    output = _absolute_without_resolving(output_root)
    expected_output = project_root / OUTPUT_RELATIVE
    if not _same_path(output, expected_output):
        raise ValueError("training output root differs from the fixed formal result root")
    ensure_no_symlink_components(output, stop_at=project_root)
    if not output.is_dir() or output.is_symlink():
        raise RuntimeError("initialized formal training result root is required")
    core_names = {
        "scientific_contract.snapshot.json",
        "authorization.snapshot.json",
        "execution_config.snapshot.json",
        "training_admission.snapshot.json",
        "training_context.json",
    }
    allowed_later = {"filter", "neural", "control", "logs", "selection", "independent"}
    actual_names = {path.name for path in output.iterdir()}
    if not core_names.issubset(actual_names):
        raise RuntimeError("initialized training root is missing a trust-root member")
    unknown = actual_names.difference(core_names | allowed_later)
    if unknown:
        raise RuntimeError(f"initialized training root contains unknown members: {sorted(unknown)}")
    for path in output.iterdir():
        ensure_no_symlink_components(path, stop_at=project_root)
        if path.is_symlink():
            raise RuntimeError(f"initialized training root contains a linked member: {path.name}")
        if path.name in allowed_later and not path.is_dir():
            raise RuntimeError(f"initialized training resume member is not a directory: {path.name}")

    sources = {
        "scientific_contract.snapshot.json": require_regular_unlinked_file(
            config_path, label="scientific contract", stop_at=project_root
        ),
        "authorization.snapshot.json": require_regular_unlinked_file(
            authorization, label="training authorization", stop_at=project_root
        ),
        "execution_config.snapshot.json": require_regular_unlinked_file(
            execution_path, label="training execution config", stop_at=project_root
        ),
        "training_admission.snapshot.json": require_regular_unlinked_file(
            training_admission, label="training admission", stop_at=project_root
        ),
    }
    snapshot_records: dict[str, dict[str, Any]] = {}
    for name, source in sorted(sources.items()):
        snapshot = require_regular_unlinked_file(
            output / name, label="initialized training snapshot", stop_at=output
        )
        source_bytes = source.read_bytes()
        if snapshot.read_bytes() != source_bytes:
            raise RuntimeError(f"initialized training snapshot differs: {name}")
        snapshot_records[name] = {
            "sha256": hashlib.sha256(source_bytes).hexdigest(),
            "size_bytes": len(source_bytes),
        }

    context_path = require_regular_unlinked_file(
        output / "training_context.json",
        label="initialized training context",
        stop_at=output,
    )
    context = read_json_strict(context_path)
    if context_path.read_bytes() != canonical_json_bytes(context):
        raise RuntimeError("initialized training context is not canonical JSON")
    expected_ledger = {
        "evaluation_array_reads": 0,
        "evaluation_predictions": 0,
        "evaluation_metrics": 0,
        "evaluation_outputs": 0,
    }
    admission = dict(training_admission_record)
    authorization_record = admission.get("authorization", {})
    evaluation_identity = admission.get("evaluation_identity", {})
    expected_keys = {
        "schema_version",
        "experiment_id",
        "status",
        "formal_evaluation_authorized",
        "output_root",
        "scientific_contract_sha256",
        "preflight_final_manifest_sha256",
        "authorization_file_sha256",
        "training_admission_record_sha256",
        "evaluation_identity_only_sha256",
        "access_ledger",
        "initial_member_count",
        "snapshots",
    }
    if (
        set(context) != expected_keys
        or context.get("schema_version") != "tukf09_training_context_v1"
        or context.get("experiment_id") != EXPERIMENT_ID
        or context.get("status") != "TRAINING_ROOT_INITIALIZED_EVALUATION_HOLD"
        or context.get("formal_evaluation_authorized") is not False
        or context.get("output_root") != OUTPUT_RELATIVE.as_posix()
        or context.get("scientific_contract_sha256")
        != admission.get("scientific_contract_sha256")
        or context.get("preflight_final_manifest_sha256")
        != admission.get("preflight_final_manifest_sha256")
        or context.get("authorization_file_sha256")
        != authorization_record.get("file_sha256")
        or context.get("training_admission_record_sha256")
        != admission.get("training_admission_record_sha256")
        or context.get("evaluation_identity_only_sha256")
        != evaluation_identity.get("identity_only_sha256")
        or context.get("access_ledger") != expected_ledger
        or context.get("initial_member_count") != 5
        or context.get("snapshots") != snapshot_records
    ):
        raise RuntimeError("initialized training context identity differs")
    return context
