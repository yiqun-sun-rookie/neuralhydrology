"""Independently verify and seal the revised 455-basin preflight package.

The only shared scientific input adapter is the frozen production loader that
returns training and validation periods.  This module independently derives
the revised population and every decisive preflight artifact.  It never loads
evaluation arrays, migrates results, registers training, or evaluates models.
"""
from __future__ import annotations

import argparse
from collections import Counter
from hashlib import sha256
import importlib
import json
import math
import os
from pathlib import Path
import shutil
import stat
from typing import Any, Mapping, Sequence
import uuid

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
EXPERIMENT_ID = "TUKF09_455_BASIN_ZERO_VALIDATION_TARGET_VARIANCE_REVISION_V1"
SOURCE_EXPERIMENT_ID = "TUKF09_BACKPROPAGATION_VS_NEURAL_BACKWARD_TIME_CONFIRMATION_V1"
CONFIG_RELATIVE = Path(
    "configs/tukf09_455_basin_zero_validation_target_variance_revision_v1.json"
)
EXECUTION_CONFIG_RELATIVE = Path(
    "configs/tukf09_455_basin_zero_validation_target_variance_execution_v1.json"
)
PREFLIGHT_RELATIVE = Path(
    "artifacts/tukf09_455_basin_zero_validation_target_variance_revision_v1/preflight"
)
FUTURE_RESULTS_RELATIVE = Path(
    "results/tukf09_455_basin_zero_validation_target_variance_revision_v1"
)
SOURCE_RESULTS_RELATIVE = Path(
    "results/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1"
)
SOURCE_NEURAL_EVENT_LOG_RELATIVE = Path(
    "results/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1/control/neural/events.jsonl"
)
EXPECTED_SOURCE_NEURAL_EVENT_LOG_SHA256 = (
    "83b0f67268ceb5d0e3fb9eefc62d0aa79f327472787fcbaaf95b118e51e7e037"
)
EXPECTED_CONTRACT_FILE_SHA256 = (
    "7710594dcc5cce7f087cb70492a6f827c3925a98ea7fa051d26c5ef1660304e1"
)
EXPECTED_EXECUTION_FILE_SHA256 = (
    "e12e104c90afff709e5edd707a9339b05450fb232e92039699dad1a8283637b6"
)
EXPECTED_REVISED_NEWLINE_SHA256 = (
    "38987bce45fa38ff68f5b067db17e8cb3212d98fecdd106f57d268a130ee8fbd"
)
EXPECTED_REVISED_COMPACT_SHA256 = (
    "75ef2cee206fb15ee3f31ae0bbfcf594661c5ccdda0b28de9ff65634332c8902"
)
EXPECTED_DIMENSION_COUNTS = {
    "7": 312,
    "8": 61,
    "9": 25,
    "10": 7,
    "11": 11,
    "12": 10,
    "13": 6,
    "15": 3,
    "17": 3,
    "18": 3,
    "20": 14,
}
EXPECTED_DIMENSION_MAPPING_SHA256 = (
    "3cb2b8e5d8199cefc4fc6c777e52c76f110ec346be68f90aad7784f42ef7fd44"
)
EXPECTED_AUTHORIZATIONS = {
    "preflight": True,
    "independent_preflight": True,
    "result_migration": False,
    "filter_result_rebinding": False,
    "formal_training": False,
    "filter_training": False,
    "neural_training": False,
    "training_period_learning": False,
    "validation_checkpoint_selection": False,
    "training_selection_sealing": False,
    "independent_training_selection_verification": False,
    "formal_evaluation": False,
    "evaluation_prediction_generation": False,
    "evaluation_metric_computation": False,
    "independent_final_audit": False,
}
PREFLIGHT_MEMBERS = frozenset(
    {
        "contract.snapshot.json",
        "execution_config.snapshot.json",
        "population_registry.json",
        "parameters_only.npz",
        "raw_source_manifest.sha256.json",
        "semantic_input_manifest.sha256.json",
        "validation_target_variance_manifest.sha256.json",
        "source_experiment_evidence.json",
        "preflight_summary.json",
        "preflight_manifest.sha256.json",
    }
)
MANIFESTED_PREFLIGHT_MEMBERS = PREFLIGHT_MEMBERS - {
    "preflight_manifest.sha256.json"
}


def _reject_json_constant(token: str) -> None:
    raise ValueError(f"non-finite JSON constant is forbidden: {token}")


def _reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key is forbidden: {key}")
        result[key] = value
    return result


def _parse_json(raw: bytes, *, label: str) -> dict[str, Any]:
    try:
        value = json.loads(
            raw.decode("utf-8"),
            parse_constant=_reject_json_constant,
            object_pairs_hook=_reject_duplicate_keys,
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"invalid UTF-8 JSON: {label}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"JSON root must be an object: {label}")
    return value


def _canonical_json_bytes(value: Any, *, trailing_lf: bool = True) -> bytes:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return payload + (b"\n" if trailing_lf else b"")


def _canonical_json_sha256(value: Any) -> str:
    return sha256(_canonical_json_bytes(value, trailing_lf=False)).hexdigest()


def _read_json(path: Path, *, require_canonical: bool = True) -> dict[str, Any]:
    raw = Path(path).read_bytes()
    value = _parse_json(raw, label=str(path))
    if require_canonical and raw != _canonical_json_bytes(value):
        raise ValueError(f"noncanonical or byte-modified JSON: {path}")
    return value


def _sha256_file(path: Path) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _file_record(path: Path) -> dict[str, Any]:
    metadata = Path(path).stat()
    return {"sha256": _sha256_file(path), "size_bytes": int(metadata.st_size)}


def _ordered_newline_sha256(values: Sequence[str]) -> str:
    digest = sha256()
    for value in values:
        digest.update(str(value).encode("ascii"))
        digest.update(b"\n")
    return digest.hexdigest()


def _ordered_compact_sha256(values: Sequence[str]) -> str:
    payload = json.dumps(
        list(values), ensure_ascii=False, separators=(",", ":")
    ).encode("utf-8")
    return sha256(payload).hexdigest()


def _lexists(path: Path) -> bool:
    return os.path.lexists(os.fspath(path))


def _ensure_within(path: Path, parent: Path) -> Path:
    candidate = Path(path).resolve(strict=False)
    boundary = Path(parent).resolve(strict=False)
    try:
        candidate.relative_to(boundary)
    except ValueError as exc:
        raise ValueError(f"path escapes its fixed root: {path}") from exc
    return candidate


def _ensure_no_link_components(path: Path, *, stop_at: Path | None = None) -> None:
    candidate = _absolute(path)
    boundary = _absolute(stop_at) if stop_at is not None else Path(candidate.anchor)
    _ensure_within(candidate, boundary)
    current = boundary
    components = [boundary]
    for component in candidate.relative_to(boundary).parts:
        current = current / component
        components.append(current)
    for component_path in components:
        if not _lexists(component_path):
            continue
        metadata = component_path.lstat()
        attributes = int(getattr(metadata, "st_file_attributes", 0))
        reparse_flag = int(getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))
        if stat.S_ISLNK(metadata.st_mode) or bool(attributes & reparse_flag):
            raise ValueError(f"linked path component is forbidden: {component_path}")


def _absolute(path: Path) -> Path:
    return Path(os.path.abspath(os.fspath(path)))


def _require_exact_path(path: Path, expected: Path, *, label: str) -> Path:
    actual = _absolute(path)
    fixed = _absolute(expected)
    if os.path.normcase(os.fspath(actual)) != os.path.normcase(os.fspath(fixed)):
        raise ValueError(f"{label} must use the isolated frozen path")
    _ensure_no_link_components(actual, stop_at=ROOT)
    return actual


def _assert_regular_unlinked_file(path: Path, *, label: str) -> None:
    _ensure_no_link_components(Path(path))
    metadata = Path(path).lstat()
    if (
        Path(path).is_symlink()
        or not stat.S_ISREG(metadata.st_mode)
        or int(getattr(metadata, "st_nlink", 1)) != 1
    ):
        raise ValueError(f"{label} is linked or not a regular file: {path}")


def _gate_before_read(preflight_root: Path, authorize: bool) -> None:
    if authorize is not True:
        raise PermissionError("independent revised-preflight authorization is required")
    independent = Path(preflight_root) / "independent"
    if _lexists(independent):
        raise FileExistsError(f"independent seal already exists: {independent}")
    if Path(preflight_root).is_dir():
        pending = sorted(Path(preflight_root).glob(".independent.pending-*"))
        if pending:
            raise FileExistsError(f"independent pending directory exists: {pending[0]}")


def _load_contract_and_execution(
    config_path: Path, execution_path: Path, preflight_root: Path
) -> tuple[dict[str, Any], dict[str, Any], bytes, bytes]:
    config_path = _require_exact_path(config_path, ROOT / CONFIG_RELATIVE, label="contract")
    execution_path = _require_exact_path(
        execution_path, ROOT / EXECUTION_CONFIG_RELATIVE, label="execution design"
    )
    _require_exact_path(
        preflight_root, ROOT / PREFLIGHT_RELATIVE, label="preflight package"
    )
    for path, label in (
        (config_path, "scientific contract"),
        (execution_path, "execution design"),
    ):
        _assert_regular_unlinked_file(path, label=label)
    config_bytes = config_path.read_bytes()
    execution_bytes = execution_path.read_bytes()
    if sha256(config_bytes).hexdigest() != EXPECTED_CONTRACT_FILE_SHA256:
        raise ValueError("revised scientific-contract file hash changed")
    if sha256(execution_bytes).hexdigest() != EXPECTED_EXECUTION_FILE_SHA256:
        raise ValueError("revised execution-design file hash changed")
    contract = _parse_json(config_bytes, label=str(config_path))
    execution = _parse_json(execution_bytes, label=str(execution_path))
    if (
        contract.get("schema_version")
        != "tukf09_455_basin_zero_validation_target_variance_revision_contract_v1"
        or contract.get("experiment_id") != EXPERIMENT_ID
        or contract.get("authorizations") != EXPECTED_AUTHORIZATIONS
    ):
        raise ValueError("revised scientific-contract identity or authorization changed")
    if (
        execution.get("schema_version")
        != "tukf09_455_basin_zero_validation_target_variance_execution_design_v1"
        or execution.get("experiment_id") != EXPERIMENT_ID
        or execution.get("status")
        != "PREFLIGHT_ONLY_MIGRATION_TRAINING_EVALUATION_HOLD"
        or execution.get("authorization_boundary") != EXPECTED_AUTHORIZATIONS
        or execution.get("implementation_admitted") is not False
        or execution.get("training_entrypoints_registered") is not False
        or execution.get("formal_training_authorization_path") is not None
        or execution.get("training_admission_path") is not None
    ):
        raise ValueError("execution-design identity or hold boundary changed")
    binding = execution.get("scientific_contract", {})
    if binding != {
        "path": CONFIG_RELATIVE.as_posix(),
        "sha256": EXPECTED_CONTRACT_FILE_SHA256,
    }:
        raise ValueError("execution design no longer binds the frozen contract")
    if contract.get("paths", {}).get("preflight_root") != PREFLIGHT_RELATIVE.as_posix():
        raise ValueError("scientific-contract preflight path changed")
    if contract.get("paths", {}).get("future_results_root") != (
        FUTURE_RESULTS_RELATIVE.as_posix()
    ):
        raise ValueError("scientific-contract future results path changed")
    if _lexists(ROOT / FUTURE_RESULTS_RELATIVE):
        raise FileExistsError("future results root exists during preflight-only phase")
    return contract, execution, config_bytes, execution_bytes


def _validate_preflight_layout(preflight_root: Path) -> None:
    _ensure_no_link_components(Path(preflight_root), stop_at=ROOT)
    if not Path(preflight_root).is_dir() or Path(preflight_root).is_symlink():
        raise ValueError("preflight package is missing or linked")
    names = {path.name for path in Path(preflight_root).iterdir()}
    if names != PREFLIGHT_MEMBERS:
        raise ValueError("preflight package has missing or extra top-level members")
    for name in sorted(PREFLIGHT_MEMBERS):
        _assert_regular_unlinked_file(
            Path(preflight_root) / name, label=f"preflight member {name}"
        )


def _capture_preflight_records(preflight_root: Path) -> dict[str, dict[str, Any]]:
    return {
        name: _file_record(Path(preflight_root) / name)
        for name in sorted(PREFLIGHT_MEMBERS)
    }


def _assert_records_unchanged(
    preflight_root: Path,
    expected: Mapping[str, Mapping[str, Any]],
    *,
    allowed_pending: Path | None = None,
) -> None:
    names = {path.name for path in Path(preflight_root).iterdir()}
    expected_names = set(PREFLIGHT_MEMBERS)
    if allowed_pending is not None:
        expected_names.add(Path(allowed_pending).name)
    if names != expected_names:
        raise RuntimeError("preflight package membership changed during verification")
    for name in PREFLIGHT_MEMBERS:
        _assert_regular_unlinked_file(
            Path(preflight_root) / name, label=f"preflight member {name}"
        )
    actual = _capture_preflight_records(preflight_root)
    if actual != {name: dict(record) for name, record in expected.items()}:
        raise RuntimeError("preflight package changed during independent verification")


def _validate_preflight_manifest(
    preflight_root: Path, fixed_records: Mapping[str, Mapping[str, Any]]
) -> None:
    manifest = _read_json(Path(preflight_root) / "preflight_manifest.sha256.json")
    expected_files = {
        name: dict(fixed_records[name]) for name in sorted(MANIFESTED_PREFLIGHT_MEMBERS)
    }
    if manifest != {
        "schema_version": "tukf09_455_basin_preflight_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "file_count": 9,
        "files": expected_files,
    }:
        raise ValueError("preflight manifest does not seal the nine payload members")


def _verify_parent_frozen_files(
    contract: Mapping[str, Any]
) -> dict[str, dict[str, Any]]:
    provenance = contract.get("parent_revision_provenance")
    if not isinstance(provenance, dict) or provenance.get("source_experiment_id") != (
        SOURCE_EXPERIMENT_ID
    ):
        raise ValueError("parent experiment identity changed")
    records = provenance.get("frozen_files")
    expected_names = {
        "scientific_contract",
        "execution_config",
        "independent_preflight_final_manifest",
        "population_registry",
        "parameters_only",
        "raw_source_manifest",
        "semantic_input_manifest",
        "formal_training_authorization",
        "training_admission",
        "production_training_validation_loader",
    }
    if not isinstance(records, dict) or set(records) != expected_names:
        raise ValueError("parent frozen-file registry changed")
    actual: dict[str, dict[str, Any]] = {}
    for name in sorted(records):
        record = records[name]
        if not isinstance(record, dict) or set(record) != {"path", "sha256"}:
            raise ValueError(f"invalid parent frozen-file record: {name}")
        path = ROOT / record["path"]
        _assert_regular_unlinked_file(path, label=f"parent frozen file {name}")
        digest = _sha256_file(path)
        if digest != record["sha256"]:
            raise ValueError(f"parent frozen-file hash changed: {name}")
        actual[name] = {
            "path": record["path"],
            "sha256": digest,
            "size_bytes": int(path.stat().st_size),
        }
    final_path = ROOT / records["independent_preflight_final_manifest"]["path"]
    final_manifest = _read_json(final_path)
    if (
        final_manifest.get("experiment_id") != SOURCE_EXPERIMENT_ID
        or final_manifest.get("file_count") != 8
        or not isinstance(final_manifest.get("files"), dict)
    ):
        raise ValueError("parent independent final-manifest identity changed")
    parent_members = {
        "population_registry": "population_registry.json",
        "parameters_only": "parameters_only.npz",
        "raw_source_manifest": "raw_source_manifest.sha256.json",
        "semantic_input_manifest": "semantic_input_manifest.sha256.json",
    }
    for record_name, member_name in parent_members.items():
        if final_manifest["files"].get(member_name) != {
            "sha256": actual[record_name]["sha256"],
            "size_bytes": actual[record_name]["size_bytes"],
        }:
            raise ValueError(f"parent final manifest no longer seals {member_name}")
    return actual


def _verify_revision_trigger_event(contract: Mapping[str, Any]) -> dict[str, Any]:
    path = ROOT / SOURCE_NEURAL_EVENT_LOG_RELATIVE
    _assert_regular_unlinked_file(path, label="parent neural event log")
    raw = path.read_bytes()
    digest = sha256(raw).hexdigest()
    if digest != EXPECTED_SOURCE_NEURAL_EVENT_LOG_SHA256:
        raise ValueError("parent neural event-log hash changed")
    events = [
        _parse_json(line, label=f"{path}:line-{index}")
        for index, line in enumerate(raw.splitlines(), start=1)
        if line.strip()
    ]
    if [event.get("sequence_number") for event in events] != [1, 2, 3]:
        raise ValueError("parent neural event sequence changed")
    if any(event.get("evaluation_access_count") != 0 for event in events):
        raise PermissionError("parent neural event log records evaluation access")
    failed = events[-1]
    trigger = contract["parent_revision_provenance"]["revision_trigger"]
    expected_time = str(trigger["failed_at_utc"]).replace("Z", "+00:00")
    detail = failed.get("detail")
    if (
        failed.get("event_type") != "UNIT_FAILED"
        or failed.get("exit_status") != "FAILED_STOP"
        or failed.get("unit_id") != trigger["failed_unit"]
        or failed.get("timestamp_utc") != expected_time
        or not isinstance(detail, dict)
        or detail.get("ended_at_utc") != expected_time
        or trigger["error"] not in str(detail.get("error_message", ""))
    ):
        raise ValueError("parent neural failure event differs from the revision trigger")
    return {
        "path": SOURCE_NEURAL_EVENT_LOG_RELATIVE.as_posix(),
        "sha256": digest,
        "size_bytes": len(raw),
        "sequence_number": 3,
        "event_type": "UNIT_FAILED",
        "unit_id": trigger["failed_unit"],
        "timestamp_utc": failed["timestamp_utc"],
        "evaluation_access_count": 0,
    }


def _production_context(contract: Mapping[str, Any]):
    parent_loader = importlib.import_module("scripts.tukf09_training_common")
    frozen = contract["parent_revision_provenance"]["frozen_files"]
    context = parent_loader.verify_preflight_for_training(
        ROOT / frozen["scientific_contract"]["path"],
        ROOT / frozen["independent_preflight_final_manifest"]["path"],
        ROOT / frozen["formal_training_authorization"]["path"],
        ROOT / SOURCE_RESULTS_RELATIVE,
        require_output_absent=False,
        recompute_training_validation_semantics=False,
        verify_all_raw_source_bytes=False,
    )
    if context.experiment_id != SOURCE_EXPERIMENT_ID:
        raise ValueError("parent production context identity changed")
    if len(context.ordered_basin_ids) != 456:
        raise ValueError("parent production context population changed")
    if context.evaluation_access_count != 0:
        raise PermissionError("parent production context records evaluation access")
    return context, parent_loader


def _validation_record(observations: np.ndarray) -> dict[str, Any]:
    values = np.asarray(observations, dtype=np.float64)
    if values.shape != (731,):
        raise ValueError("validation observations must contain exactly 731 days")
    if not np.isfinite(values).all() or np.any(values < 0.0):
        raise ValueError("validation observations must be finite and nonnegative")
    scoring = values[365:731]
    mean = np.mean(scoring, dtype=np.float64)
    denominator = np.sum(np.square(scoring - mean), dtype=np.float64)
    if not math.isfinite(float(denominator)) or denominator < 0.0:
        raise ValueError("validation target denominator is invalid")
    return {
        "validation_scoring_day_count": 366,
        "validation_target_positive_day_count": int(np.count_nonzero(scoring > 0.0)),
        "validation_target_min": float(np.min(scoring)),
        "validation_target_max": float(np.max(scoring)),
        "validation_target_mean": float(mean),
        "validation_denominator": float(denominator),
        "metric_defined": bool(denominator > 0.0),
    }


def _training_record(observations: np.ndarray) -> dict[str, Any]:
    values = np.asarray(observations, dtype=np.float64)
    if values.shape != (2557,):
        raise ValueError("training observations must contain exactly 2557 days")
    if not np.isfinite(values).all() or np.any(values < 0.0):
        raise ValueError("training observations must be finite and nonnegative")
    scoring = values[365:2557]
    mean = np.mean(scoring, dtype=np.float64)
    denominator = np.sum(np.square(scoring - mean), dtype=np.float64)
    if not math.isfinite(float(denominator)) or denominator < 0.0:
        raise ValueError("training target denominator is invalid")
    return {
        "training_scoring_day_count": 2192,
        "training_target_positive_day_count": int(np.count_nonzero(scoring > 0.0)),
        "training_denominator": float(denominator),
    }


def _variance_records(context, parent_loader) -> dict[str, dict[str, Any]]:
    if context.evaluation_access_count != 0:
        raise PermissionError("evaluation access occurred before period loading")
    periods = parent_loader.load_training_validation_periods(
        context, context.ordered_basin_ids
    )
    if tuple(periods) != tuple(context.ordered_basin_ids):
        raise ValueError("production loader changed basin order")
    records: dict[str, dict[str, Any]] = {}
    for basin_id in context.ordered_basin_ids:
        per_period = periods[basin_id]
        if set(per_period) != {"training", "validation"}:
            raise PermissionError("production loader returned a non-training period")
        record = _validation_record(per_period["validation"].observations)
        record.update(_training_record(per_period["training"].observations))
        identity = context.semantic_members["validation"].get(
            f"{basin_id}/observations"
        )
        if not isinstance(identity, dict):
            raise ValueError(f"missing parent validation identity: {basin_id}")
        record["validation_observations_semantic_identity"] = dict(identity)
        records[basin_id] = record
    if context.evaluation_access_count != 0:
        raise PermissionError("evaluation access occurred during period loading")
    return records


def _revised_population(
    source: Mapping[str, Any], records: Mapping[str, Mapping[str, Any]]
) -> dict[str, Any]:
    source_eligible = [str(value) for value in source["eligible"]]
    if set(records) != set(source_eligible):
        raise ValueError("variance records do not cover the parent population")
    defined: list[str] = []
    undefined: list[str] = []
    for basin_id in source_eligible:
        denominator = float(records[basin_id]["validation_denominator"])
        if not math.isfinite(denominator) or denominator < 0.0:
            raise ValueError(f"invalid validation denominator: {basin_id}")
        metric_defined = denominator > 0.0
        if bool(records[basin_id]["metric_defined"]) is not metric_defined:
            raise ValueError(f"metric-defined flag changed: {basin_id}")
        (defined if metric_defined else undefined).append(basin_id)
    result = {
        "schema_version": "tukf09_455_basin_validation_metric_defined_population_v1",
        "experiment_id": EXPERIMENT_ID,
        "canonical": list(source["canonical"]),
        "previously_evaluated": list(source["previously_evaluated"]),
        "candidates": list(source["candidates"]),
        "source_date_complete": source_eligible,
        "date_incomplete": list(source["date_incomplete"]),
        "validation_metric_defined": defined,
        "validation_metric_undefined": undefined,
        "eligible": defined,
        "missing_days_by_basin": dict(source["missing_days_by_basin"]),
        "eligibility_rule": {
            "source_population_rule": "inherit parent date completeness and finite nonnegative input qualification",
            "validation_scoring_slice": [365, 731],
            "validation_scoring_period": ["2007-10-01", "2008-09-30"],
            "validation_scoring_day_count": 366,
            "denominator_formula": "float64 sum((target - float64_mean(target))^2)",
            "required": "finite and strictly greater than 0.0",
            "uses_model_predictions": False,
            "uses_pairwise_outcomes": False,
        },
        "eligible_ordered_newline_utf8_sha256": _ordered_newline_sha256(defined),
        "eligible_compact_json_sha256": _ordered_compact_sha256(defined),
    }
    if (
        len(source_eligible) != 456
        or len(defined) != 455
        or undefined != ["08202700"]
        or result["eligible_ordered_newline_utf8_sha256"]
        != EXPECTED_REVISED_NEWLINE_SHA256
        or result["eligible_compact_json_sha256"] != EXPECTED_REVISED_COMPACT_SHA256
    ):
        raise ValueError("uniform validation-variance rule did not reproduce 455 basins")
    return result


def _verify_parameters(
    source_path: Path,
    revised_path: Path,
    source_eligible: Sequence[str],
    revised: Sequence[str],
) -> tuple[dict[str, int], str]:
    with np.load(source_path, allow_pickle=False) as source_archive:
        if set(source_archive.files) != {"basin_ids", "parameter_names", "values"}:
            raise ValueError("parent parameter archive schema changed")
        source_basins = tuple(
            str(value) for value in source_archive["basin_ids"].tolist()
        )
        source_names = np.asarray(source_archive["parameter_names"])
        source_values = np.asarray(source_archive["values"], dtype=np.float64)
    with np.load(revised_path, allow_pickle=False) as revised_archive:
        if set(revised_archive.files) != {"basin_ids", "parameter_names", "values"}:
            raise ValueError("revised parameter archive schema changed")
        revised_basins = tuple(
            str(value) for value in revised_archive["basin_ids"].tolist()
        )
        revised_names = np.asarray(revised_archive["parameter_names"])
        revised_values = np.asarray(revised_archive["values"], dtype=np.float64)
    if source_basins != tuple(source_eligible) or source_values.shape != (456, 13):
        raise ValueError("parent parameter archive population changed")
    if revised_basins != tuple(revised) or revised_values.shape != (455, 13):
        raise ValueError("revised parameter archive population changed")
    if not np.array_equal(source_names, revised_names):
        raise ValueError("revised parameter names differ from parent")
    index = {basin: row for row, basin in enumerate(source_basins)}
    expected_values = np.asarray(
        [source_values[index[basin]] for basin in revised], dtype=np.float64
    )
    if not np.array_equal(revised_values, expected_values):
        raise ValueError("revised parameters differ from the ordered parent subset")
    if not np.isfinite(revised_values).all():
        raise ValueError("revised parameters contain non-finite values")
    names = tuple(str(value) for value in revised_names.tolist())
    lag_index = names.index("lag_time")
    dimensions = {
        basin: 5 + max(1, math.ceil(float(revised_values[row, lag_index])))
        for row, basin in enumerate(revised)
    }
    counts = {
        str(dimension): int(count)
        for dimension, count in sorted(Counter(dimensions.values()).items())
    }
    mapping_hash = _canonical_json_sha256(dimensions)
    if counts != EXPECTED_DIMENSION_COUNTS or mapping_hash != (
        EXPECTED_DIMENSION_MAPPING_SHA256
    ):
        raise ValueError("revised routed-state dimension evidence changed")
    return counts, mapping_hash


def _expected_raw_manifest(source: Mapping[str, Any]) -> dict[str, Any]:
    files = source.get("files")
    if (
        source.get("experiment_id") != SOURCE_EXPERIMENT_ID
        or source.get("file_count") != 1020
        or not isinstance(files, dict)
        or len(files) != 1020
        or source.get("aggregate_sha256") != _canonical_json_sha256(files)
    ):
        raise ValueError("parent raw-source manifest changed")
    return {
        "schema_version": "tukf09_455_basin_inherited_raw_source_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "derived_from_parent_file_sha256": sha256(
            _canonical_json_bytes(source)
        ).hexdigest(),
        "file_count": 1020,
        "aggregate_sha256": _canonical_json_sha256(files),
        "files": files,
    }


def _expected_semantic_manifest(
    source: Mapping[str, Any], revised: Sequence[str]
) -> dict[str, Any]:
    members = source.get("members")
    if (
        source.get("experiment_id") != SOURCE_EXPERIMENT_ID
        or source.get("member_count") != 4104
        or not isinstance(members, dict)
        or len(members) != 4104
        or source.get("aggregate_sha256") != _canonical_json_sha256(members)
    ):
        raise ValueError("parent semantic-input manifest changed")
    revised_set = set(revised)
    selected = {
        name: record
        for name, record in members.items()
        if name.split("/", 1)[0] in revised_set
    }
    expected_names = {
        f"{basin}/{period}/{array_name}"
        for basin in revised
        for period in ("training", "validation", "evaluation")
        for array_name in ("dates_ns", "forcing", "observations")
    }
    if set(selected) != expected_names or len(selected) != 4095:
        raise ValueError("revised semantic-input membership changed")
    return {
        "schema_version": "tukf09_455_basin_inherited_semantic_input_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "evaluation_arrays_reconstructed": False,
        "evaluation_identities_inherited_from_parent": True,
        "derived_from_parent_file_sha256": sha256(
            _canonical_json_bytes(source)
        ).hexdigest(),
        "member_count": 4095,
        "aggregate_sha256": _canonical_json_sha256(selected),
        "members": selected,
    }


def _expected_variance_manifest(
    records: Mapping[str, Mapping[str, Any]]
) -> dict[str, Any]:
    undefined = [
        basin_id
        for basin_id, record in records.items()
        if not bool(record["metric_defined"])
    ]
    result = {
        "schema_version": "tukf09_455_basin_validation_target_variance_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "source_experiment_id": SOURCE_EXPERIMENT_ID,
        "record_count": len(records),
        "metric_defined_count": len(records) - len(undefined),
        "metric_undefined_count": len(undefined),
        "metric_undefined_basins": undefined,
        "scoring_support": {
            "period": "validation",
            "input_index_slice": [365, 731],
            "dates": ["2007-10-01", "2008-09-30"],
            "day_count": 366,
            "dtype": "float64",
            "denominator_formula": "sum((target - mean(target))^2)",
            "required": "finite and strictly greater than 0.0",
        },
        "aggregate_sha256": _canonical_json_sha256(records),
        "records": dict(records),
    }
    if (
        result["record_count"] != 456
        or result["metric_defined_count"] != 455
        or undefined != ["08202700"]
    ):
        raise ValueError("validation-target variance evidence changed")
    return result


def _expected_source_evidence(
    parent_files: Mapping[str, Mapping[str, Any]],
    contract: Mapping[str, Any],
    evaluation_access_count: int,
) -> dict[str, Any]:
    frozen = contract["parent_revision_provenance"]["frozen_files"]
    return {
        "schema_version": "tukf09_455_basin_parent_evidence_v1",
        "experiment_id": EXPERIMENT_ID,
        "source_experiment_id": SOURCE_EXPERIMENT_ID,
        "frozen_files": {
            name: dict(record) for name, record in parent_files.items()
        },
        "parent_preflight_status": "REPRODUCIBLE",
        "parent_context_role": "read-only training-and-validation data context; grants no authority to the revised experiment",
        "production_loader_path": frozen["production_training_validation_loader"]["path"],
        "production_loader_shared_by_generator_and_independent_verifier": True,
        "direct_raw_file_reads_by_revision_code": False,
        "training_arrays_loaded": True,
        "validation_arrays_loaded": True,
        "evaluation_identity_inherited": True,
        "evaluation_arrays_loaded": False,
        "evaluation_predictions": 0,
        "evaluation_metrics": 0,
        "evaluation_outputs": 0,
        "evaluation_access_count": evaluation_access_count,
    }


def _expected_summary(
    contract: Mapping[str, Any],
    execution: Mapping[str, Any],
    config_bytes: bytes,
    execution_bytes: bytes,
    raw_manifest: Mapping[str, Any],
    semantic_manifest: Mapping[str, Any],
    variance_manifest: Mapping[str, Any],
    dimension_counts: Mapping[str, int],
    dimension_mapping_hash: str,
    evaluation_access_count: int,
) -> dict[str, Any]:
    return {
        "schema_version": "tukf09_455_basin_preflight_summary_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "PREFLIGHT_PASS_MIGRATION_TRAINING_EVALUATION_HOLD",
        "contract_file_sha256": sha256(config_bytes).hexdigest(),
        "contract_canonical_sha256": _canonical_json_sha256(contract),
        "execution_config_file_sha256": sha256(execution_bytes).hexdigest(),
        "execution_config_canonical_sha256": _canonical_json_sha256(execution),
        "parent_source_date_complete_basin_count": 456,
        "validation_metric_defined_basin_count": 455,
        "validation_metric_undefined_basin_count": 1,
        "validation_metric_undefined_basins": ["08202700"],
        "eligible_ordered_newline_utf8_sha256": EXPECTED_REVISED_NEWLINE_SHA256,
        "eligible_compact_json_sha256": EXPECTED_REVISED_COMPACT_SHA256,
        "raw_source_file_count": 1020,
        "raw_source_aggregate_sha256": raw_manifest["aggregate_sha256"],
        "semantic_input_member_count": 4095,
        "semantic_input_aggregate_sha256": semantic_manifest["aggregate_sha256"],
        "validation_variance_record_count": 456,
        "validation_variance_aggregate_sha256": variance_manifest["aggregate_sha256"],
        "parameter_shape": [455, 13],
        "state_dimension_counts": dict(dimension_counts),
        "state_dimension_mapping_sha256": dimension_mapping_hash,
        "evaluation_arrays_loaded": False,
        "evaluation_access_count": evaluation_access_count,
        "preflight_authorized": True,
        "independent_preflight_authorized": True,
        "result_migration_authorized": False,
        "training_authorized": False,
        "evaluation_authorized": False,
    }


def _write_new_json(path: Path, value: Any) -> None:
    payload = _canonical_json_bytes(value)
    with Path(path).open("xb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())


def _remove_own_pending(pending: Path, preflight_root: Path) -> None:
    if not _lexists(pending):
        return
    if (
        pending.parent.resolve() != Path(preflight_root).resolve()
        or not pending.name.startswith(".independent.pending-")
        or pending.is_symlink()
    ):
        raise RuntimeError("refusing to remove an unverified pending path")
    shutil.rmtree(pending)


def _publish_independent_seal(
    preflight_root: Path,
    audit: Mapping[str, Any],
    fixed_records: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    destination = Path(preflight_root) / "independent"
    pending = Path(preflight_root) / f".independent.pending-{uuid.uuid4().hex}"
    if _lexists(destination):
        raise FileExistsError(f"independent seal already exists: {destination}")
    competitors = sorted(Path(preflight_root).glob(".independent.pending-*"))
    if competitors:
        raise FileExistsError(f"independent pending directory exists: {competitors[0]}")
    _assert_records_unchanged(preflight_root, fixed_records)
    pending.mkdir(exist_ok=False)
    try:
        audit_path = pending / "independent_audit.json"
        _write_new_json(audit_path, dict(audit))
        _assert_records_unchanged(
            preflight_root, fixed_records, allowed_pending=pending
        )
        final_files = {
            name: dict(fixed_records[name]) for name in sorted(PREFLIGHT_MEMBERS)
        }
        final_files["independent/independent_audit.json"] = _file_record(audit_path)
        final_manifest = {
            "schema_version": "tukf09_455_basin_preflight_final_manifest_v1",
            "experiment_id": EXPERIMENT_ID,
            "file_count": 11,
            "files": final_files,
        }
        final_path = pending / "manifest.final.sha256.json"
        _write_new_json(final_path, final_manifest)
        if {path.name for path in pending.iterdir()} != {
            "independent_audit.json",
            "manifest.final.sha256.json",
        }:
            raise RuntimeError("independent pending member set changed")
        for path in pending.iterdir():
            _assert_regular_unlinked_file(path, label="independent pending member")
        if _read_json(audit_path) != dict(audit):
            raise RuntimeError("independent audit changed after write")
        if _read_json(final_path) != final_manifest:
            raise RuntimeError("independent final manifest changed after write")
        for name, record in final_files.items():
            actual_path = audit_path if name.startswith("independent/") else (
                Path(preflight_root) / name
            )
            if _file_record(actual_path) != record:
                raise RuntimeError(f"final manifest byte check failed: {name}")
        _assert_records_unchanged(
            preflight_root, fixed_records, allowed_pending=pending
        )
        if _lexists(destination):
            raise FileExistsError("independent destination appeared during publication")
        os.replace(pending, destination)
        return final_manifest
    except BaseException:
        _remove_own_pending(pending, preflight_root)
        raise


def verify_preflight(
    config_path: Path,
    execution_config_path: Path,
    preflight_root: Path,
    *,
    authorize: bool = False,
) -> dict[str, Any]:
    """Recompute every decisive artifact and atomically publish its seal."""

    config_path = Path(config_path)
    execution_config_path = Path(execution_config_path)
    preflight_root = Path(preflight_root)
    _gate_before_read(preflight_root, authorize)
    contract, execution, config_bytes, execution_bytes = _load_contract_and_execution(
        config_path, execution_config_path, preflight_root
    )
    _validate_preflight_layout(preflight_root)
    fixed_records = _capture_preflight_records(preflight_root)
    _validate_preflight_manifest(preflight_root, fixed_records)
    if (preflight_root / "contract.snapshot.json").read_bytes() != config_bytes:
        raise ValueError("contract snapshot differs from the frozen contract")
    if (preflight_root / "execution_config.snapshot.json").read_bytes() != execution_bytes:
        raise ValueError("execution snapshot differs from the frozen execution design")

    parent_files = _verify_parent_frozen_files(contract)
    revision_trigger_event = _verify_revision_trigger_event(contract)
    context, parent_loader = _production_context(contract)
    records = _variance_records(context, parent_loader)
    frozen = contract["parent_revision_provenance"]["frozen_files"]
    source_population = _read_json(ROOT / frozen["population_registry"]["path"])
    population = _revised_population(source_population, records)
    if _read_json(preflight_root / "population_registry.json") != population:
        raise ValueError("population artifact differs from independent derivation")

    dimension_counts, dimension_mapping_hash = _verify_parameters(
        ROOT / frozen["parameters_only"]["path"],
        preflight_root / "parameters_only.npz",
        population["source_date_complete"],
        population["eligible"],
    )
    parent_raw = _read_json(ROOT / frozen["raw_source_manifest"]["path"])
    parent_semantic = _read_json(ROOT / frozen["semantic_input_manifest"]["path"])
    raw_manifest = _expected_raw_manifest(parent_raw)
    semantic_manifest = _expected_semantic_manifest(
        parent_semantic, population["eligible"]
    )
    variance_manifest = _expected_variance_manifest(records)
    if _read_json(preflight_root / "raw_source_manifest.sha256.json") != raw_manifest:
        raise ValueError("raw-source manifest differs from independent derivation")
    if _read_json(preflight_root / "semantic_input_manifest.sha256.json") != (
        semantic_manifest
    ):
        raise ValueError("semantic-input manifest differs from independent derivation")
    if _read_json(
        preflight_root / "validation_target_variance_manifest.sha256.json"
    ) != variance_manifest:
        raise ValueError("variance manifest differs from independent derivation")

    source_evidence = _expected_source_evidence(
        parent_files, contract, context.evaluation_access_count
    )
    if _read_json(preflight_root / "source_experiment_evidence.json") != (
        source_evidence
    ):
        raise ValueError("source-experiment evidence differs from independent derivation")
    summary = _expected_summary(
        contract,
        execution,
        config_bytes,
        execution_bytes,
        raw_manifest,
        semantic_manifest,
        variance_manifest,
        dimension_counts,
        dimension_mapping_hash,
        context.evaluation_access_count,
    )
    if _read_json(preflight_root / "preflight_summary.json") != summary:
        raise ValueError("preflight summary differs from independent derivation")
    if context.evaluation_access_count != 0:
        raise PermissionError("evaluation access occurred during independent verification")

    audit = {
        "schema_version": "tukf09_455_basin_independent_preflight_audit_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "REPRODUCIBLE_PREFLIGHT_ONLY",
        "preflight_status": "PREFLIGHT_PASS_MIGRATION_TRAINING_EVALUATION_HOLD",
        "source_date_complete_basin_count": 456,
        "validation_metric_defined_basin_count": 455,
        "validation_metric_undefined_basin_count": 1,
        "validation_metric_undefined_basins": ["08202700"],
        "state_dimension_mismatch_count": 0,
        "parent_frozen_file_mismatch_count": 0,
        "artifact_mismatch_count": 0,
        "revision_trigger_event": revision_trigger_event,
        "evaluation_arrays_loaded": False,
        "evaluation_access_count": context.evaluation_access_count,
        "result_migration_authorized": False,
        "training_authorized": False,
        "evaluation_authorized": False,
        "independent_final_audit_authorized": False,
    }
    if config_path.read_bytes() != config_bytes:
        raise RuntimeError("scientific contract changed during independent verification")
    if execution_config_path.read_bytes() != execution_bytes:
        raise RuntimeError("execution design changed during independent verification")
    if _verify_parent_frozen_files(contract) != parent_files:
        raise RuntimeError("parent frozen evidence changed during independent verification")
    if _verify_revision_trigger_event(contract) != revision_trigger_event:
        raise RuntimeError("parent neural failure event changed during verification")
    if _lexists(ROOT / FUTURE_RESULTS_RELATIVE):
        raise FileExistsError("future results root appeared during independent verification")
    _assert_records_unchanged(preflight_root, fixed_records)
    _publish_independent_seal(preflight_root, audit, fixed_records)
    return audit


def verify_existing_seal(preflight_root: Path) -> dict[str, Any]:
    """Read-only byte verification of an already published independent seal."""

    preflight_root = _require_exact_path(
        Path(preflight_root), ROOT / PREFLIGHT_RELATIVE, label="preflight package"
    )
    independent = preflight_root / "independent"
    if not independent.is_dir() or independent.is_symlink():
        raise ValueError("independent seal is missing or linked")
    if {path.name for path in independent.iterdir()} != {
        "independent_audit.json",
        "manifest.final.sha256.json",
    }:
        raise ValueError("independent seal member set changed")
    audit_path = independent / "independent_audit.json"
    final_path = independent / "manifest.final.sha256.json"
    for path in (audit_path, final_path):
        _assert_regular_unlinked_file(path, label="independent seal member")
    audit = _read_json(audit_path)
    final_manifest = _read_json(final_path)
    files = final_manifest.get("files")
    if (
        final_manifest.get("schema_version")
        != "tukf09_455_basin_preflight_final_manifest_v1"
        or final_manifest.get("experiment_id") != EXPERIMENT_ID
        or final_manifest.get("file_count") != 11
        or not isinstance(files, dict)
        or len(files) != 11
    ):
        raise ValueError("independent final-manifest identity changed")
    expected_names = set(PREFLIGHT_MEMBERS) | {"independent/independent_audit.json"}
    if set(files) != expected_names:
        raise ValueError("independent final-manifest membership changed")
    for relative, record in files.items():
        path = preflight_root / Path(relative)
        _assert_regular_unlinked_file(path, label=f"final-manifest member {relative}")
        if _file_record(path) != record:
            raise ValueError(f"independent final-manifest byte mismatch: {relative}")
    if audit.get("status") != "REPRODUCIBLE_PREFLIGHT_ONLY":
        raise ValueError("independent audit status changed")
    return {
        "status": "SEALED_PREFLIGHT_BYTES_VERIFIED",
        "file_count": 11,
        "evaluation_access_count": audit.get("evaluation_access_count"),
        "training_authorized": audit.get("training_authorized"),
        "evaluation_authorized": audit.get("evaluation_authorized"),
    }


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Independently verify only the revised 455-basin preflight"
    )
    parser.add_argument("--config", type=Path)
    parser.add_argument("--execution-config", type=Path)
    parser.add_argument("--preflight-root", type=Path)
    parser.add_argument("--authorize-independent-preflight", action="store_true")
    parser.add_argument("--verify-existing", action="store_true")
    arguments = parser.parse_args(argv)
    preflight_root = arguments.preflight_root or ROOT / PREFLIGHT_RELATIVE
    if arguments.verify_existing:
        result = verify_existing_seal(preflight_root)
    else:
        if arguments.config is None or arguments.execution_config is None:
            parser.error("--config and --execution-config are required for independent sealing")
        result = verify_preflight(
            arguments.config,
            arguments.execution_config,
            preflight_root,
            authorize=arguments.authorize_independent_preflight,
        )
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = ["verify_existing_seal", "verify_preflight"]
