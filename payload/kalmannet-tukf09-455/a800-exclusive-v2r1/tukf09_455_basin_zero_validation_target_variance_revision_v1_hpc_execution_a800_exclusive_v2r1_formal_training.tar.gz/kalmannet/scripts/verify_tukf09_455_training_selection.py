"""Independently verify the sealed TUKF09 training selection.

The implementation imports only the frozen executable-path tuple from the
revision training common module.  It imports no sealer, runner, controller,
admission, or evaluation implementation.  It opens only training/validation
histories and metadata, independently recomputes every manifest and checkpoint
choice, and publishes a two-file audit directory in one atomic rename.  It
never opens an evaluation array.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import sys
from typing import Any, Iterator, Mapping, Sequence
import uuid

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

try:
    from scripts.tukf09_455_training_common import (
        REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS,
    )
except ImportError:  # pragma: no cover - direct script execution
    from tukf09_455_training_common import REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS

EXPERIMENT_ID = "TUKF09_455_BASIN_ZERO_VALIDATION_TARGET_VARIANCE_REVISION_V1"
PARENT_EXPERIMENT_ID = "TUKF09_BACKPROPAGATION_VS_NEURAL_BACKWARD_TIME_CONFIRMATION_V1"
DEFAULT_EXECUTION_CONFIG = ROOT / "configs" / "tukf09_455_basin_zero_validation_target_variance_formal_training_execution_v1.json"
DEFAULT_POPULATION_REGISTRY = (
    ROOT
    / "artifacts"
    / "tukf09_455_basin_zero_validation_target_variance_revision_v1"
    / "preflight"
    / "population_registry.json"
)
DEFAULT_OUTPUT_ROOT = (
    ROOT / "results" / "tukf09_455_basin_zero_validation_target_variance_revision_v1"
)

FILTER_CHECKPOINT_COUNT = 256
FILTER_TRAINING_QUERY_COUNT = 256
FILTER_VALIDATION_QUERY_COUNT = 256
FILTER_PASS_COUNT = 512
FILTER_GRADIENT_UPDATE_COUNT = 248
NEURAL_CHECKPOINT_COUNT = 30
TRAINING_DAYS = 2557
VALIDATION_DAYS = 731
SEQUENCE_LENGTH = 365
TRAINING_SAMPLES_PER_BASIN = 2192
VALIDATION_SAMPLES_PER_BASIN = 366
ROOT_EVIDENCE_MEMBERS = (
    "authorization.snapshot.json",
    "scientific_contract.snapshot.json",
    "execution_config.snapshot.json",
    "training_admission.snapshot.json",
    "training_context.json",
)
FILTER_MEMBER_NAMES = (
    "access_ledger.json",
    "history.npz",
    "identity.json",
    "migration_provenance.json",
    "selection.json",
)
LEGACY_FILTER_MEMBER_NAMES = tuple(
    name for name in FILTER_MEMBER_NAMES if name != "migration_provenance.json"
)
NEURAL_MEMBER_NAMES = (
    "identity.json",
    *tuple(f"checkpoints/epoch_{epoch:03d}.pt" for epoch in range(1, 31)),
    "validation_history.npz",
    "model_selection.json",
    "access_ledger.json",
)
SELECTION_MEMBER_NAMES = frozenset(
    {
        "filter_registry.json",
        "neural_registry.json",
        "selected_model_summary.json",
        "training_manifest.sha256.json",
        "training_selection.sealed.json",
    }
)
INDEPENDENT_MEMBER_NAMES = frozenset(
    {"independent_audit.json", "manifest.final.sha256.json"}
)
EXPECTED_SCORED_TARGET_COUNTS = {
    "training": {"1": 2190, "2": 2191, "3": 2192},
    "validation": {"1": 364, "2": 365, "3": 366},
}
EXPECTED_COMPLETION_COUNTS = {
    "rebound_filter_units": 455,
    "new_filter_training_units": 0,
    "inherited_filter_checkpoint_records": 116480,
    "new_filter_training_objective_calls": 0,
    "new_filter_validation_objective_calls": 0,
    "new_filter_gradient_updates": 0,
    "neural_model_units": 9,
    "neural_checkpoints": 270,
    "evaluation_array_reads": 0,
    "evaluation_predictions": 0,
    "evaluation_metrics": 0,
    "evaluation_outputs": 0,
}
EXPECTED_NEURAL_UNITS = tuple(
    (lead_days, seed) for lead_days in (1, 2, 3) for seed in (0, 1, 2)
)
NEURAL_RUNNER_RELATIVE_PATH = "scripts/run_tukf09_455_neural_training.py"
FROZEN_NEURAL_MODEL_RELATIVE_PATH = "scripts/tukf07_information_matched_model.py"


@dataclass(frozen=True)
class VerificationExpectations:
    basin_ids: tuple[str, ...]
    neural_units: tuple[tuple[int, int], ...]
    production: bool
    execution_config_sha256: str | None = None
    scientific_contract_sha256: str | None = None
    preflight_final_manifest_sha256: str | None = None


@dataclass(frozen=True)
class AdmittedSourceBindings:
    training_admission_record_sha256: str
    neural_runner_sha256: str
    frozen_model_source_sha256: str
    all_scope_authorization_sha256: str | None = None
    migration_config_sha256: str | None = None
    filter_migration_final_manifest_sha256: str | None = None
    filter_installation_final_manifest_sha256: str | None = None
    installed_unit_records: Mapping[str, Mapping[str, Any]] | None = None
    scientific_contract_sha256: str | None = None
    preflight_final_manifest_sha256: str | None = None


@dataclass(frozen=True)
class IndependentPhaseOwner:
    schema_version: str
    experiment_id: str
    role: str
    execution_id: str
    process_id: int
    started_at_utc: str
    recovered_stale_lock: bool


def _reject_nonfinite_json(token: str) -> None:
    raise ValueError(f"non-finite JSON number is forbidden: {token}")


def _json_bytes(value: Any) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")


def _payload_sha256(value: Any) -> str:
    return sha256(_json_bytes(value)[:-1]).hexdigest()


def _sha256_file(path: Path) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _record(path: Path) -> dict[str, Any]:
    return {"sha256": _sha256_file(path), "size_bytes": int(path.stat().st_size)}


def _exists(path: Path) -> bool:
    return os.path.lexists(os.fspath(path))


def _regular(path: Path, label: str) -> Path:
    path = Path(path)
    if not path.is_file() or path.is_symlink() or path.stat().st_nlink != 1:
        raise FileNotFoundError(f"independent {label} is missing, linked, or non-regular: {path}")
    return path


def _read_json(path: Path, *, canonical: bool = True) -> dict[str, Any]:
    path = _regular(path, "JSON artifact")
    raw = path.read_bytes()
    try:
        value = json.loads(raw.decode("utf-8"), parse_constant=_reject_nonfinite_json)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"independent invalid JSON artifact: {path}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"independent JSON object required: {path}")
    if canonical and raw != _json_bytes(value):
        raise RuntimeError(f"independent non-canonical JSON artifact: {path}")
    return value


def _validate_owned_phase_lock(
    root: Path, owner: IndependentPhaseOwner
) -> str:
    relative_owner = "control/.training_phase.lock/owner.json"
    lock = root / "control" / ".training_phase.lock"
    if not lock.is_dir() or lock.is_symlink():
        raise RuntimeError("independent owned training phase lock is invalid")
    if {path.name for path in lock.iterdir()} != {"owner.json"}:
        raise RuntimeError("independent owned training phase lock member set changed")
    recorded = _read_json(_regular(lock / "owner.json", "training phase owner"))
    if recorded != owner.__dict__ or recorded.get("role") != "independent":
        raise RuntimeError("independent owned training phase-lock identity changed")
    return relative_owner


@contextmanager
def _training_phase_lock(
    output_root: Path, role: str = "independent"
) -> Iterator[IndependentPhaseOwner]:
    """Independently hold the shared mutation lock without stale recovery."""

    if role != "independent":
        raise ValueError("independent verifier phase role must be independent")
    root = Path(output_root)
    if not root.is_dir() or root.is_symlink():
        raise FileNotFoundError("independent formal training result root is absent or linked")
    control = root / "control"
    if _exists(control) and (not control.is_dir() or control.is_symlink()):
        raise RuntimeError("independent training control root is linked or invalid")
    control.mkdir(parents=True, exist_ok=True)
    lock = control / ".training_phase.lock"
    try:
        lock.mkdir()
    except FileExistsError as exc:
        # Any prior phase lock is an immutable HOLD condition.  Its owner is
        # deliberately neither interpreted for liveness nor removed here.
        raise RuntimeError(
            "existing training phase lock requires HOLD and manual process audit"
        ) from exc
    owner = IndependentPhaseOwner(
        schema_version="tukf09_training_phase_owner_v1",
        experiment_id=EXPERIMENT_ID,
        role=role,
        execution_id=uuid.uuid4().hex,
        process_id=os.getpid(),
        started_at_utc=datetime.now(timezone.utc).isoformat(),
        recovered_stale_lock=False,
    )
    owner_path = lock / "owner.json"
    try:
        with owner_path.open("xb") as handle:
            handle.write(_json_bytes(owner.__dict__))
            handle.flush()
            os.fsync(handle.fileno())
        yield owner
    finally:
        recorded_owner = _validate_owned_phase_lock(root, owner)
        if recorded_owner != "control/.training_phase.lock/owner.json":
            raise AssertionError("independent phase owner path changed")
        owner_path.unlink()
        lock.rmdir()


def _is_hash(value: Any) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(character in "0123456789abcdef" for character in value)
    )


def _validate_admitted_executables(
    admission: Mapping[str, Any],
    admission_record_sha256: Any,
) -> AdmittedSourceBindings:
    """Independently rehash the exact local sources admitted for training."""

    if not _is_hash(admission_record_sha256):
        raise RuntimeError("independent training admission hash is invalid for source binding")
    executables = admission.get("executables")
    if not isinstance(executables, Mapping) or set(executables) != set(
        REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS
    ):
        raise RuntimeError(
            "independent training admission executable source set is not frozen"
        )
    for relative in REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS:
        admitted = executables.get(relative)
        if not isinstance(admitted, Mapping) or set(admitted) != {
            "sha256",
            "size_bytes",
        }:
            raise RuntimeError(
                f"independent training admission executable record changed: {relative}"
            )
        size_bytes = admitted.get("size_bytes")
        if (
            not _is_hash(admitted.get("sha256"))
            or isinstance(size_bytes, bool)
            or not isinstance(size_bytes, int)
            or size_bytes < 0
        ):
            raise RuntimeError(
                f"independent training admission executable record is invalid: {relative}"
            )
        current = _record(_regular(ROOT / relative, f"admitted executable source {relative}"))
        if dict(admitted) != current:
            raise RuntimeError(f"independent admitted executable source changed: {relative}")
    return AdmittedSourceBindings(
        training_admission_record_sha256=str(admission_record_sha256),
        neural_runner_sha256=str(executables[NEURAL_RUNNER_RELATIVE_PATH]["sha256"]),
        frozen_model_source_sha256=str(
            executables[FROZEN_NEURAL_MODEL_RELATIVE_PATH]["sha256"]
        ),
    )


def _basin(value: Any) -> str:
    if isinstance(value, bool):
        raise ValueError("independent basin identifier must be text")
    text = str(value).strip()
    if len(text) != 8 or not text.isascii() or not text.isdigit():
        raise ValueError(f"independent basin identifier changed: {value!r}")
    return text


def _units(values: Sequence[Any]) -> tuple[tuple[int, int], ...]:
    result: list[tuple[int, int]] = []
    for value in values:
        if isinstance(value, Mapping):
            lead, seed = value.get("lead_days"), value.get("seed")
        else:
            try:
                lead, seed = value
            except (TypeError, ValueError) as exc:
                raise ValueError("independent neural unit identity changed") from exc
        if isinstance(lead, bool) or isinstance(seed, bool):
            raise ValueError("independent neural unit contains a Boolean")
        unit = (int(lead), int(seed))
        if unit[0] not in (1, 2, 3) or unit[1] not in (0, 1, 2):
            raise ValueError(f"independent neural unit is outside the frozen set: {unit}")
        result.append(unit)
    if len(result) != len(set(result)):
        raise ValueError("independent neural unit set contains a duplicate")
    return tuple(result)


def _expectations(
    *,
    output_root: Path,
    population_registry: Path | None,
    execution_config: Path | None,
    expected_basin_ids: Sequence[str] | None,
    expected_neural_units: Sequence[Any] | None,
) -> VerificationExpectations:
    injected = expected_basin_ids is not None or expected_neural_units is not None
    if injected:
        if expected_basin_ids is None or expected_neural_units is None:
            raise ValueError("independent synthetic expectations are incomplete")
        basins = tuple(_basin(value) for value in expected_basin_ids)
        neural = _units(expected_neural_units)
        if not basins or len(basins) != len(set(basins)) or not neural:
            raise ValueError("independent synthetic population is empty or duplicated")
        return VerificationExpectations(basins, neural, False)
    registry = _read_json(Path(population_registry or DEFAULT_POPULATION_REGISTRY))
    execution = _read_json(Path(execution_config or DEFAULT_EXECUTION_CONFIG), canonical=False)
    if (
        registry.get("schema_version")
        != "tukf09_455_basin_validation_metric_defined_population_v1"
        or registry.get("experiment_id") != EXPERIMENT_ID
        or execution.get("schema_version") != "tukf09_455_formal_training_execution_v1"
        or execution.get("experiment_id") != EXPERIMENT_ID
        or execution.get("completion_counts") != EXPECTED_COMPLETION_COUNTS
    ):
        raise RuntimeError("independent production population or execution contract changed")
    eligible = registry.get("eligible")
    if not isinstance(eligible, list):
        raise ValueError("independent eligible basin order is absent")
    basins = tuple(_basin(value) for value in eligible)
    if len(basins) != 455 or len(set(basins)) != 455:
        raise RuntimeError("independent production verification requires exactly 455 basins")
    order = execution.get("controller_order", {}).get("neural_models")
    if not isinstance(order, list) or _units(order) != EXPECTED_NEURAL_UNITS:
        raise RuntimeError("independent production verification requires the frozen nine models")
    authorization = execution.get("authorization")
    if not isinstance(authorization, Mapping) or (
        authorization.get("neural_training") is not True
        or authorization.get("training_selection_sealing") is not True
        or authorization.get("independent_training_selection_verification") is not True
        or authorization.get("formal_evaluation_access_during_training") is not False
    ):
        raise PermissionError("independent execution authorization crossed into evaluation")
    configured = execution.get("paths", {}).get("results_root")
    if not isinstance(configured, str):
        raise ValueError("independent configured result root is absent")
    fixed = Path(configured)
    if not fixed.is_absolute():
        fixed = ROOT / fixed
    if output_root.resolve(strict=False) != fixed.resolve(strict=False):
        raise ValueError("independent output root differs from the frozen result root")
    scientific = execution.get("scientific_contract")
    preflight = execution.get("independent_preflight_final_manifest")
    if (
        not isinstance(scientific, Mapping)
        or not _is_hash(scientific.get("sha256"))
        or not isinstance(preflight, Mapping)
        or not _is_hash(preflight.get("sha256"))
    ):
        raise RuntimeError("independent frozen source hashes are absent")
    execution_path = Path(execution_config or DEFAULT_EXECUTION_CONFIG)
    return VerificationExpectations(
        basins,
        EXPECTED_NEURAL_UNITS,
        True,
        _sha256_file(execution_path),
        str(scientific["sha256"]),
        str(preflight["sha256"]),
    )


def _no_evaluation_surface(
    root: Path, *, phase_owner: IndependentPhaseOwner | None = None
) -> None:
    if not root.is_dir() or root.is_symlink():
        raise FileNotFoundError("independent formal training result root is absent or linked")
    allowed_top_level = set(ROOT_EVIDENCE_MEMBERS) | {
        "filter",
        "neural",
        "control",
        "logs",
        "selection",
        "independent",
    }
    unknown = {path.name for path in root.iterdir()}.difference(allowed_top_level)
    if unknown:
        raise RuntimeError(
            f"independent unknown top-level training artifact is forbidden: {sorted(unknown)}"
        )
    if not (root / "selection").is_dir() or (root / "selection").is_symlink():
        raise FileNotFoundError("independent verification requires an unlinked selection seal")
    phase_lock = root / "control" / ".training_phase.lock"
    if phase_owner is None:
        if _exists(phase_lock):
            raise RuntimeError(
                "existing training phase lock requires HOLD and manual process audit"
            )
    else:
        _validate_owned_phase_lock(root, phase_owner)
    for path in root.rglob("*"):
        if path.is_symlink():
            raise RuntimeError(f"independent linked training artifact is forbidden: {path}")
        lock_name = path.name.lower()
        if (
            lock_name == "controller.lock"
            or lock_name.endswith("_controller.lock")
            or lock_name.endswith(".controller.lock")
        ):
            raise RuntimeError(f"independent active controller lock is forbidden: {path}")
        parts = tuple(part.lower() for part in path.relative_to(root).parts)
        if any(part == "evaluation" or part.startswith("evaluation_") for part in parts):
            raise RuntimeError(f"independent evaluation output surface is forbidden: {path}")


def _filter_rebinding_evidence(
    root: Path,
    expected: VerificationExpectations,
    admission: Mapping[str, Any],
    authorization: Mapping[str, Any],
    records: Mapping[str, Mapping[str, Any]],
    admitted_sources: AdmittedSourceBindings,
) -> AdmittedSourceBindings:
    """Independently bind installed rebound units to both final manifests."""

    migration_reference = admission.get("filter_migration_final_manifest")
    if not isinstance(migration_reference, Mapping):
        raise RuntimeError("independent training admission lacks the migration final seal")
    migration_path = Path(str(migration_reference.get("path", "")))
    if not migration_path.is_absolute():
        migration_path = ROOT / migration_path
    migration_path = _regular(migration_path, "filter-migration independent final manifest")
    migration_hash = _sha256_file(migration_path)
    migration_final = _read_json(migration_path)
    if (
        migration_reference.get("sha256") != migration_hash
        or migration_final.get("schema_version")
        != "tukf09_455_filter_migration_final_manifest_v1"
        or migration_final.get("experiment_id") != EXPERIMENT_ID
        or migration_final.get("status")
        != "FILTER_MIGRATION_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
    ):
        raise RuntimeError("independent filter-migration final seal changed")

    control = root / "control" / "filter_rebinding"
    seal_path = control / "filter_rebinding.sealed.json"
    audit_path = control / "independent" / "independent_audit.json"
    final_path = control / "independent" / "manifest.final.sha256.json"
    seal = _read_json(seal_path)
    audit = _read_json(audit_path)
    final = _read_json(final_path)
    if (
        seal.get("schema_version") != "tukf09_455_filter_rebinding_seal_v1"
        or seal.get("experiment_id") != EXPERIMENT_ID
        or seal.get("status") != "FILTER_REBINDING_INSTALLED_455_EVALUATION_HOLD"
        or seal.get("ordered_basin_ids") != list(expected.basin_ids)
        or seal.get("unit_count") != len(expected.basin_ids)
        or seal.get("unit_file_count") != len(expected.basin_ids) * 6
        or seal.get("training_admission_sha256")
        != records["training_admission.snapshot.json"]["sha256"]
        or seal.get("migration_final_manifest_sha256") != migration_hash
        or seal.get("inherited_checkpoint_count")
        != len(expected.basin_ids) * FILTER_CHECKPOINT_COUNT
        or seal.get("inherited_gradient_update_count")
        != len(expected.basin_ids) * FILTER_GRADIENT_UPDATE_COUNT
        or seal.get("new_filter_optimization_count") != 0
        or seal.get("new_filter_objective_count") != 0
        or seal.get("new_filter_gradient_update_count") != 0
        or seal.get("evaluation_access_count") != 0
        or audit.get("schema_version")
        != "tukf09_455_filter_installation_independent_audit_v1"
        or audit.get("experiment_id") != EXPERIMENT_ID
        or audit.get("status")
        != "FILTER_REBINDING_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
        or audit.get("unit_count") != len(expected.basin_ids)
        or audit.get("unit_file_count") != len(expected.basin_ids) * 6
        or audit.get("training_admission_sha256")
        != records["training_admission.snapshot.json"]["sha256"]
        or audit.get("migration_final_manifest_sha256") != migration_hash
        or audit.get("new_filter_optimization_count") != 0
        or audit.get("evaluation_access_count") != 0
        or final.get("schema_version")
        != "tukf09_455_filter_installation_final_manifest_v1"
        or final.get("experiment_id") != EXPERIMENT_ID
        or final.get("status")
        != "FILTER_REBINDING_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
    ):
        raise RuntimeError("independent filter-rebinding installation seal changed")
    final_files = final.get("files")
    if not isinstance(final_files, Mapping):
        raise RuntimeError("independent filter-rebinding file records are absent")
    expected_paths = {
        f"filter/basin_{basin}/{name}"
        for basin in expected.basin_ids
        for name in (*FILTER_MEMBER_NAMES, "manifest.sha256.json")
    } | {
        "control/filter_rebinding/filter_rebinding.sealed.json",
        "control/filter_rebinding/independent/independent_audit.json",
    }
    if set(final_files) != expected_paths or final.get("file_count") != len(expected_paths):
        raise RuntimeError("independent filter-rebinding final scope changed")
    for relative, recorded in final_files.items():
        actual = _record(_regular(root / relative, f"filter-rebinding file {relative}"))
        if recorded != actual:
            raise RuntimeError(
                f"independent filter-rebinding file changed after verification: {relative}"
            )
    unit_manifest_map = seal.get("unit_manifest_sha256_by_basin")
    if not isinstance(unit_manifest_map, Mapping) or set(unit_manifest_map) != set(
        expected.basin_ids
    ):
        raise RuntimeError("independent filter-rebinding unit manifest map changed")
    for basin in expected.basin_ids:
        relative = f"filter/basin_{basin}/manifest.sha256.json"
        if unit_manifest_map[basin] != final_files[relative]["sha256"]:
            raise RuntimeError(
                f"independent filter-rebinding unit manifest binding changed: {basin}"
            )
    migration_config = authorization.get("frozen_inputs", {}).get(
        "filter_migration_config", {}
    )
    if not _is_hash(migration_config.get("sha256")):
        raise RuntimeError("independent authorization lacks the migration-config hash")
    return AdmittedSourceBindings(
        training_admission_record_sha256=(
            admitted_sources.training_admission_record_sha256
        ),
        neural_runner_sha256=admitted_sources.neural_runner_sha256,
        frozen_model_source_sha256=admitted_sources.frozen_model_source_sha256,
        all_scope_authorization_sha256=records["authorization.snapshot.json"]["sha256"],
        migration_config_sha256=str(migration_config["sha256"]),
        filter_migration_final_manifest_sha256=migration_hash,
        filter_installation_final_manifest_sha256=_sha256_file(final_path),
        installed_unit_records={
            relative: dict(value)
            for relative, value in final_files.items()
            if relative.startswith("filter/basin_")
        },
        scientific_contract_sha256=expected.scientific_contract_sha256,
        preflight_final_manifest_sha256=expected.preflight_final_manifest_sha256,
    )


def _root_records(
    root: Path, expected: VerificationExpectations
) -> tuple[dict[str, Any], AdmittedSourceBindings | None]:
    records = {
        name: _record(_regular(root / name, f"root evidence {name}"))
        for name in ROOT_EVIDENCE_MEMBERS
    }
    if not expected.production:
        return records, None
    authorization = _read_json(root / "authorization.snapshot.json")
    admission = _read_json(root / "training_admission.snapshot.json")
    context = _read_json(root / "training_context.json")
    execution = _read_json(root / "execution_config.snapshot.json", canonical=False)
    authorization_unsigned = dict(authorization)
    authorization_record_sha256 = authorization_unsigned.pop(
        "authorization_record_sha256", None
    )
    admission_unsigned = dict(admission)
    admission_record_sha256 = admission_unsigned.pop(
        "training_admission_record_sha256", None
    )
    if (
        authorization.get("status")
        != "ALL_REQUESTED_PHASES_AUTHORIZED_SEQUENTIAL_ADMISSION_REQUIRED"
        or authorization.get("scope", {}).get("neural_training_authorized") is not True
        or authorization.get("scope", {}).get("new_filter_optimization_authorized")
        is not False
        or admission.get("formal_evaluation_authorized") is not False
        or admission.get("phase_scope", {}).get(
            "training_selection_sealing_authorized"
        )
        is not True
        or admission.get("phase_scope", {}).get("formal_evaluation_access_admitted")
        is not False
        or admission.get("evaluation_identity", {}).get("arrays_loaded") is not False
        or context.get("formal_evaluation_authorized") is not False
        or execution.get("authorization", {}).get(
            "formal_evaluation_access_during_training"
        )
        is not False
    ):
        raise RuntimeError("independent root evidence crossed the evaluation boundary")
    if any(value != 0 for value in context.get("access_ledger", {}).values()) or (
        admission.get("access_ledger")
        and any(value != 0 for value in admission["access_ledger"].values())
    ):
        raise RuntimeError("independent root evidence records evaluation access")
    if (
        records["execution_config.snapshot.json"]["sha256"]
        != expected.execution_config_sha256
        or records["scientific_contract.snapshot.json"]["sha256"]
        != expected.scientific_contract_sha256
        or authorization_record_sha256
        != sha256(_json_bytes(authorization_unsigned)).hexdigest()
        or admission_record_sha256
        != sha256(_json_bytes(admission_unsigned)).hexdigest()
        or authorization.get("frozen_inputs", {}).get("scientific_contract", {}).get("sha256")
        != expected.scientific_contract_sha256
        or authorization.get("frozen_inputs", {})
        .get("independent_preflight_final_manifest", {})
        .get("sha256")
        != expected.preflight_final_manifest_sha256
        or admission.get("scientific_contract_sha256")
        != expected.scientific_contract_sha256
        or admission.get("preflight_final_manifest_sha256")
        != expected.preflight_final_manifest_sha256
        or admission.get("authorization", {}).get("file_sha256")
        != records["authorization.snapshot.json"]["sha256"]
        or admission.get("authorization", {}).get("record_sha256")
        != authorization_record_sha256
        or admission.get("execution_config", {}).get("sha256")
        != records["execution_config.snapshot.json"]["sha256"]
        or context.get("scientific_contract_sha256")
        != expected.scientific_contract_sha256
        or context.get("preflight_final_manifest_sha256")
        != expected.preflight_final_manifest_sha256
        or context.get("authorization_file_sha256")
        != records["authorization.snapshot.json"]["sha256"]
        or context.get("training_admission_record_sha256") != admission_record_sha256
    ):
        raise RuntimeError("independent frozen authorization and admission hashes differ")
    source_bindings = _validate_admitted_executables(
        admission, admission_record_sha256
    )
    digest = sha256(
        "".join(f"{value}\n" for value in expected.basin_ids).encode("utf-8")
    ).hexdigest()
    admitted_population = admission.get("population", {})
    if (
        admitted_population.get("ordered_basin_count") != len(expected.basin_ids)
        or admitted_population.get("ordered_newline_sha256") != digest
    ):
        raise RuntimeError("independent admitted population changed")
    snapshots = context.get("snapshots")
    if not isinstance(snapshots, Mapping) or any(
        snapshots.get(name) != records[name] for name in ROOT_EVIDENCE_MEMBERS[:-1]
    ):
        raise RuntimeError("independent training root snapshot record changed")
    return records, _filter_rebinding_evidence(
        root, expected, admission, authorization, records, source_bindings
    )


def _unit_manifest(
    directory: Path,
    *,
    schema: str,
    unit_type: str,
    unit_id: str,
    members: Sequence[str],
) -> tuple[dict[str, Any], dict[str, Any]]:
    if not directory.is_dir() or directory.is_symlink():
        raise FileNotFoundError(f"independent complete unit is absent or linked: {directory}")
    manifest_path = directory / "manifest.sha256.json"
    manifest = _read_json(manifest_path)
    files = manifest.get("files")
    if (
        set(manifest) != {"schema_version", "experiment_id", "unit_type", "unit_id", "file_count", "files"}
        or manifest.get("schema_version") != schema
        or manifest.get("experiment_id") != EXPERIMENT_ID
        or manifest.get("unit_type") != unit_type
        or manifest.get("unit_id") != unit_id
        or manifest.get("file_count") != len(members)
        or not isinstance(files, dict)
        or set(files) != set(members)
    ):
        raise RuntimeError(f"independent exact unit manifest changed: {unit_id}")
    actual_files: set[str] = set()
    actual_directories: set[str] = set()
    for path in directory.rglob("*"):
        relative = path.relative_to(directory).as_posix()
        if path.is_symlink():
            raise RuntimeError(f"independent linked unit member: {relative}")
        if path.is_dir():
            actual_directories.add(relative)
        elif path.is_file() and path.stat().st_nlink == 1:
            actual_files.add(relative)
        else:
            raise RuntimeError(f"independent non-regular unit member: {relative}")
    expected_directories = {"checkpoints"} if unit_type == "neural_lead_seed" else set()
    if actual_directories != expected_directories or actual_files != set(members) | {
        "manifest.sha256.json"
    }:
        raise RuntimeError(f"independent exact unit layout changed: {unit_id}")
    tree: dict[str, Any] = {}
    for relative in members:
        record = files[relative]
        if (
            not isinstance(record, dict)
            or set(record) != {"sha256", "size_bytes"}
            or not _is_hash(record.get("sha256"))
            or not isinstance(record.get("size_bytes"), int)
        ):
            raise RuntimeError(f"independent invalid unit record: {unit_id}:{relative}")
        actual = _record(_regular(directory / Path(relative), f"unit member {relative}"))
        if record != actual:
            raise RuntimeError(f"independent unit manifest hash or size mismatch: {unit_id}:{relative}")
        tree[relative] = actual
    tree["manifest.sha256.json"] = _record(manifest_path)
    return manifest, tree


def _npz(path: Path, names: set[str]) -> dict[str, np.ndarray]:
    try:
        with np.load(_regular(path, "history archive"), allow_pickle=False) as archive:
            if set(archive.files) != names:
                raise RuntimeError(f"independent history archive member set changed: {path}")
            return {name: np.asarray(archive[name]) for name in archive.files}
    except (OSError, ValueError) as exc:
        raise RuntimeError(f"independent invalid history archive: {path}") from exc


def _filter_unit(
    root: Path,
    basin_id: str,
    *,
    source_bindings: AdmittedSourceBindings | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    directory = root / "filter" / f"basin_{basin_id}"
    production_rebound = (
        source_bindings is not None
        and source_bindings.installed_unit_records is not None
    )
    manifest, tree = _unit_manifest(
        directory,
        schema=(
            "tukf09_455_rebound_filter_unit_manifest_v1"
            if production_rebound
            else "tukf09_filter_unit_manifest_v1"
        ),
        unit_type="filter_basin",
        unit_id=basin_id,
        members=(
            FILTER_MEMBER_NAMES if production_rebound else LEGACY_FILTER_MEMBER_NAMES
        ),
    )
    identity = _read_json(directory / "identity.json")
    dimension = identity.get("state_dimension")
    common_identity = (
        identity.get("experiment_id") == EXPERIMENT_ID
        and identity.get("unit_type") == "filter_basin"
        and identity.get("unit_id") == basin_id
        and identity.get("precision") == "float64"
        and identity.get("starts") == 8
        and identity.get("updates_per_start") == 31
        and identity.get("checkpoint_order") == "round_robin_by_step_then_start"
        and isinstance(dimension, int)
        and not isinstance(dimension, bool)
        and dimension >= 1
    )
    if production_rebound:
        exact_identity_keys = {
            "schema_version",
            "experiment_id",
            "unit_type",
            "unit_id",
            "state_dimension",
            "parameter_names",
            "physical_parameter_sha256",
            "training_period_sha256",
            "validation_period_sha256",
            "initial_state",
            "initial_covariance_diagonal",
            "base_observation_variance",
            "precision",
            "starts",
            "updates_per_start",
            "checkpoint_order",
            "scientific_contract_sha256",
            "preflight_final_manifest_sha256",
            "all_scope_authorization_sha256",
            "migration_config_sha256",
            "compatibility_projection_sha256",
        }
        if (
            set(identity) != exact_identity_keys
            or identity.get("schema_version")
            != "tukf09_455_rebound_filter_unit_identity_v1"
            or not common_identity
            or identity.get("scientific_contract_sha256")
            != source_bindings.scientific_contract_sha256
            or identity.get("preflight_final_manifest_sha256")
            != source_bindings.preflight_final_manifest_sha256
            or identity.get("all_scope_authorization_sha256")
            != source_bindings.all_scope_authorization_sha256
            or identity.get("migration_config_sha256")
            != source_bindings.migration_config_sha256
            or not _is_hash(identity.get("physical_parameter_sha256"))
            or not _is_hash(identity.get("training_period_sha256"))
            or not _is_hash(identity.get("validation_period_sha256"))
            or not _is_hash(identity.get("compatibility_projection_sha256"))
        ):
            raise RuntimeError(f"independent rebound filter identity changed: {basin_id}")
        installed_records = source_bindings.installed_unit_records
        assert installed_records is not None
        for member, record in tree.items():
            relative = f"filter/basin_{basin_id}/{member}"
            if installed_records.get(relative) != record:
                raise RuntimeError(
                    "independent rebound filter differs from installation final "
                    f"manifest: {relative}"
                )
    elif (
        identity.get("schema_version") != "tukf09_filter_unit_identity_v1"
        or not common_identity
        or identity.get("training_admission_evaluation_access_count") != 0
        or not _is_hash(identity.get("runner_sha256"))
    ):
        raise RuntimeError(f"independent filter identity changed: {basin_id}")
    arrays = _npz(
        directory / "history.npz",
        {
            "checkpoint_index",
            "start_index",
            "step_index",
            "theta_log",
            "training_objective",
            "validation_objective",
        },
    )
    expected_integer = {
        "checkpoint_index": np.arange(256, dtype=np.int64),
        "start_index": np.tile(np.arange(8, dtype=np.int64), 32),
        "step_index": np.repeat(np.arange(32, dtype=np.int64), 8),
    }
    if any(
        arrays[name].dtype != np.dtype("int64") or not np.array_equal(arrays[name], value)
        for name, value in expected_integer.items()
    ):
        raise RuntimeError(f"independent filter history order changed: {basin_id}")
    theta = arrays["theta_log"]
    training = arrays["training_objective"]
    validation = arrays["validation_objective"]
    if (
        any(value.dtype != np.dtype("float64") for value in (theta, training, validation))
        or theta.shape != (256, dimension + 1)
        or training.shape != (256,)
        or validation.shape != (256,)
        or not np.isfinite(theta).all()
        or not np.isfinite(training).all()
        or not np.isfinite(validation).all()
    ):
        raise RuntimeError(f"independent filter history changed: {basin_id}")
    with np.errstate(over="ignore", invalid="ignore"):
        actual = np.exp(theta)
    if not np.isfinite(actual).all() or np.any(actual <= 0.0):
        raise RuntimeError(f"independent filter parameters are invalid: {basin_id}")
    selected = min(
        range(256),
        key=lambda index: (
            float(validation[index]),
            float(training[index]),
            tuple(float(value) for value in actual[index]),
            index,
        ),
    )
    selection = {
        "schema_version": (
            "tukf09_455_rebound_filter_unit_selection_v1"
            if production_rebound
            else "tukf09_filter_unit_selection_v1"
        ),
        "experiment_id": EXPERIMENT_ID,
        "unit_type": "filter_basin",
        "unit_id": basin_id,
        "status": (
            "FILTER_BASIN_REBOUND_FROM_VERIFIED_PARENT"
            if production_rebound
            else "FILTER_BASIN_SELECTED"
        ),
        "selected_index": selected,
        "selected_theta_log": theta[selected].tolist(),
        "selected_process_diagonal": actual[selected, :-1].tolist(),
        "selected_r_b": float(actual[selected, -1]),
        "selected_training_objective": float(training[selected]),
        "selected_validation_objective": float(validation[selected]),
        "checkpoint_count": FILTER_CHECKPOINT_COUNT,
        "training_query_count": FILTER_TRAINING_QUERY_COUNT,
        "validation_query_count": FILTER_VALIDATION_QUERY_COUNT,
        "filter_pass_count": FILTER_PASS_COUNT,
        "gradient_update_count": FILTER_GRADIENT_UPDATE_COUNT,
        "scored_target_count_by_period_and_lead": EXPECTED_SCORED_TARGET_COUNTS,
    }
    if _read_json(directory / "selection.json") != selection:
        raise RuntimeError(f"independent filter checkpoint selection differs: {basin_id}")
    ledger = {
        "schema_version": (
            "tukf09_455_rebound_filter_unit_access_ledger_v1"
            if production_rebound
            else "tukf09_filter_unit_access_ledger_v1"
        ),
        "experiment_id": EXPERIMENT_ID,
        "unit_type": "filter_basin",
        "unit_id": basin_id,
        "training_period_loaded": True,
        "validation_period_loaded": True,
        "evaluation_array_read_count": 0,
        "evaluation_prediction_count": 0,
        "evaluation_metric_count": 0,
        "evaluation_output_write_count": 0,
        "formal_evaluation_authorized": False,
    }
    if production_rebound:
        ledger["new_filter_optimization_count"] = 0
    if _read_json(directory / "access_ledger.json") != ledger:
        raise RuntimeError(f"independent filter evaluation ledger differs: {basin_id}")
    if production_rebound:
        provenance = _read_json(directory / "migration_provenance.json")
        expected_provenance_keys = {
            "schema_version",
            "experiment_id",
            "source_experiment_id",
            "unit_id",
            "migration_mode",
            "source_unit_path",
            "source_unit_manifest_sha256",
            "source_members",
            "history_byte_identity_required",
            "selection_numeric_identity_required",
            "source_runner_sha256",
            "source_contract_sha256",
            "source_preflight_final_manifest_sha256",
            "source_authorization_sha256",
            "source_training_admission_record_sha256",
            "scientific_contract_sha256",
            "preflight_final_manifest_sha256",
            "all_scope_authorization_sha256",
            "migration_config_sha256",
            "compatibility_projection_sha256",
        }
        source_members = provenance.get("source_members")
        source_member_names = {
            "identity.json",
            "history.npz",
            "selection.json",
            "access_ledger.json",
        }
        source_path = provenance.get("source_unit_path")
        if (
            set(provenance) != expected_provenance_keys
            or provenance.get("schema_version")
            != "tukf09_455_filter_unit_migration_provenance_v1"
            or provenance.get("experiment_id") != EXPERIMENT_ID
            or provenance.get("source_experiment_id") != PARENT_EXPERIMENT_ID
            or provenance.get("unit_id") != basin_id
            or provenance.get("migration_mode")
            != "byte_copy_history_and_rebuild_identity"
            or not isinstance(source_path, str)
            or not Path(source_path).is_absolute()
            or provenance.get("history_byte_identity_required") is not True
            or provenance.get("selection_numeric_identity_required") is not True
            or not _is_hash(provenance.get("source_unit_manifest_sha256"))
            or not isinstance(source_members, Mapping)
            or set(source_members) != source_member_names
            or source_members.get("history.npz") != tree["history.npz"]
            or any(
                not isinstance(source_members.get(name), Mapping)
                or set(source_members[name]) != {"sha256", "size_bytes"}
                or not _is_hash(source_members[name].get("sha256"))
                or isinstance(source_members[name].get("size_bytes"), bool)
                or not isinstance(source_members[name].get("size_bytes"), int)
                or source_members[name].get("size_bytes") < 0
                for name in source_member_names
            )
            or any(
                not _is_hash(provenance.get(name))
                for name in (
                    "source_runner_sha256",
                    "source_contract_sha256",
                    "source_preflight_final_manifest_sha256",
                    "source_authorization_sha256",
                    "source_training_admission_record_sha256",
                )
            )
            or any(
                provenance.get(name) != identity.get(name)
                for name in (
                    "scientific_contract_sha256",
                    "preflight_final_manifest_sha256",
                    "all_scope_authorization_sha256",
                    "migration_config_sha256",
                    "compatibility_projection_sha256",
                )
            )
        ):
            raise RuntimeError(
                f"independent rebound filter migration provenance changed: {basin_id}"
            )
    return (
        {
            "basin_id": basin_id,
            "unit_relative_path": f"filter/basin_{basin_id}",
            "unit_manifest_sha256": _sha256_file(directory / "manifest.sha256.json"),
            "unit_manifest_file_count": manifest["file_count"],
            "selected_index": selected,
            "selected_theta_log": selection["selected_theta_log"],
            "selected_process_diagonal": selection["selected_process_diagonal"],
            "selected_r_b": selection["selected_r_b"],
            "selected_training_objective": selection["selected_training_objective"],
            "selected_validation_objective": selection["selected_validation_objective"],
            "filter_result_origin": (
                "FILTER_BASIN_REBOUND_FROM_VERIFIED_PARENT"
                if production_rebound
                else "FILTER_BASIN_SELECTED"
            ),
            "inherited_checkpoint_records": FILTER_CHECKPOINT_COUNT,
            "inherited_training_objective_records": FILTER_TRAINING_QUERY_COUNT,
            "inherited_validation_objective_records": FILTER_VALIDATION_QUERY_COUNT,
            "inherited_gradient_update_records": FILTER_GRADIENT_UPDATE_COUNT,
            "new_filter_training_objective_calls": 0,
            "new_filter_validation_objective_calls": 0,
            "new_filter_gradient_updates": 0,
            **(
                {
                    "training_admission_record_sha256": (
                        source_bindings.training_admission_record_sha256
                    ),
                    "filter_migration_final_manifest_sha256": (
                        source_bindings.filter_migration_final_manifest_sha256
                    ),
                    "filter_installation_final_manifest_sha256": (
                        source_bindings.filter_installation_final_manifest_sha256
                    ),
                }
                if production_rebound
                else {}
            ),
        },
        tree,
    )


def _scaler(root: Path, basins: Sequence[str]) -> tuple[str, dict[str, Any]]:
    shared = root / "neural" / "shared"
    if not shared.is_dir() or shared.is_symlink():
        raise FileNotFoundError("independent training-only scaler directory is absent")
    children = list(shared.iterdir())
    if len(children) != 1 or children[0].name != "training_scaler.json":
        raise RuntimeError("independent training-only scaler exact member set changed")
    path = _regular(children[0], "training-only scaler")
    value = _read_json(path)
    if (
        set(value)
        != {
            "schema_version",
            "experiment_id",
            "basin_ids",
            "forcing_feature_order",
            "forcing_center",
            "forcing_scale",
            "discharge_center",
            "discharge_scale",
            "per_basin_discharge_standard_deviation",
            "population_standard_deviation_ddof",
            "normalization_scope",
            "training_row_count",
        }
        or value.get("schema_version") != "tukf09_neural_training_scaler_v1"
        or value.get("experiment_id") != EXPERIMENT_ID
        or value.get("basin_ids") != list(basins)
        or value.get("forcing_feature_order")
        != [
            "precipitation",
            "mean_air_temperature",
            "oudin_potential_evapotranspiration",
        ]
        or value.get("population_standard_deviation_ddof") != 0
        or value.get("normalization_scope") != "training_only_global_population_statistics"
        or value.get("training_row_count") != len(basins) * TRAINING_DAYS
    ):
        raise RuntimeError("independent training-only scaler identity changed")
    center = np.asarray(value.get("forcing_center"), dtype=np.float64)
    scale = np.asarray(value.get("forcing_scale"), dtype=np.float64)
    basin_scale = value.get("per_basin_discharge_standard_deviation")
    if (
        center.shape != (3,)
        or scale.shape != (3,)
        or not np.isfinite(center).all()
        or not np.isfinite(scale).all()
        or np.any(scale <= 0.0)
        or not isinstance(basin_scale, dict)
        or set(basin_scale) != set(basins)
    ):
        raise RuntimeError("independent training-only scaler arrays changed")
    numbers = [
        value.get("discharge_center"),
        value.get("discharge_scale"),
        *(basin_scale[basin_id] for basin_id in basins),
    ]
    if any(isinstance(number, bool) or not isinstance(number, (int, float)) for number in numbers):
        raise RuntimeError("independent training-only scaler contains a non-number")
    numbers_array = np.asarray(numbers, dtype=np.float64)
    if (
        not np.isfinite(numbers_array).all()
        or numbers_array[1] <= 0.0
        or np.any(numbers_array[2:] <= 0.0)
    ):
        raise RuntimeError("independent training-only scaler is invalid")
    return _sha256_file(path), _record(path)


def _neural_unit(
    root: Path,
    basins: Sequence[str],
    scaler_hash: str,
    lead: int,
    seed: int,
    *,
    source_bindings: AdmittedSourceBindings | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    unit_id = f"lead_{lead}_seed_{seed}"
    directory = root / "neural" / unit_id
    manifest, tree = _unit_manifest(
        directory,
        schema="tukf09_neural_unit_manifest_v1",
        unit_type="neural_lead_seed",
        unit_id=unit_id,
        members=NEURAL_MEMBER_NAMES,
    )
    identity = _read_json(directory / "identity.json")
    unsigned = dict(identity)
    identity_hash = unsigned.pop("identity_sha256", None)
    basin_hash = sha256(
        "".join(f"{value}\n" for value in basins).encode("utf-8")
    ).hexdigest()
    if (
        identity.get("schema_version") != "tukf09_neural_unit_identity_v1"
        or identity.get("experiment_id") != EXPERIMENT_ID
        or identity.get("unit_type") != "neural_lead_seed"
        or identity.get("unit_id") != unit_id
        or identity.get("lead_days") != lead
        or identity.get("seed") != seed
        or identity.get("basin_count") != len(basins)
        or identity.get("ordered_basin_newline_sha256") != basin_hash
        or identity.get("training_sample_count") != len(basins) * TRAINING_SAMPLES_PER_BASIN
        or identity.get("validation_sample_count") != len(basins) * VALIDATION_SAMPLES_PER_BASIN
        or identity.get("epochs") != 30
        or identity.get("batch_size") != 256
        or identity.get("training_scaler_sha256") != scaler_hash
        or identity.get("tensorfloat32") is not False
        or identity.get("evaluation_access_count") != 0
        or not _is_hash(identity.get("runner_sha256"))
        or not _is_hash(identity.get("frozen_model_source_sha256"))
        or identity_hash != _payload_sha256(unsigned)
    ):
        raise RuntimeError(f"independent neural identity changed: {unit_id}")
    admission_evidence = identity.get("admission_evidence")
    if source_bindings is not None and (
        identity.get("runner_sha256") != source_bindings.neural_runner_sha256
        or identity.get("frozen_model_source_sha256")
        != source_bindings.frozen_model_source_sha256
        or not isinstance(admission_evidence, Mapping)
        or admission_evidence.get("training_admission_record_sha256")
        != source_bindings.training_admission_record_sha256
    ):
        raise RuntimeError(
            f"independent neural identity differs from admitted sources or admission: {unit_id}"
        )
    arrays = _npz(
        directory / "validation_history.npz",
        {
            "epochs",
            "basin_ids",
            "training_loss",
            "maximum_gradient_norm",
            "learning_rate",
            "validation_nse_by_basin",
            "validation_median_nse",
            "evaluation_access_count",
        },
    )
    if arrays["epochs"].dtype != np.dtype("int64") or not np.array_equal(
        arrays["epochs"], np.arange(1, 31, dtype=np.int64)
    ):
        raise RuntimeError(f"independent neural epoch order changed: {unit_id}")
    if arrays["basin_ids"].tolist() != list(basins):
        raise RuntimeError(f"independent neural basin order changed: {unit_id}")
    loss = arrays["training_loss"]
    gradient = arrays["maximum_gradient_norm"]
    rates = arrays["learning_rate"]
    nse = arrays["validation_nse_by_basin"]
    medians = arrays["validation_median_nse"]
    numeric = (loss, gradient, rates, nse, medians)
    if (
        any(value.dtype != np.dtype("float64") for value in numeric)
        or loss.shape != (30,)
        or gradient.shape != (30,)
        or rates.shape != (30,)
        or nse.shape != (30, len(basins))
        or medians.shape != (30,)
        or any(not np.isfinite(value).all() for value in numeric)
        or np.any(gradient < 0.0)
    ):
        raise RuntimeError(f"independent neural history changed: {unit_id}")
    expected_rates = np.asarray(
        [0.001 if epoch < 10 else 0.0005 if epoch < 25 else 0.0001 for epoch in range(1, 31)],
        dtype=np.float64,
    )
    recomputed_medians = np.median(nse, axis=1)
    if not np.array_equal(rates, expected_rates) or not np.array_equal(medians, recomputed_medians):
        raise RuntimeError(f"independent neural schedule or medians changed: {unit_id}")
    if arrays["evaluation_access_count"].dtype != np.dtype("int64") or not np.array_equal(
        arrays["evaluation_access_count"], np.asarray([0], dtype=np.int64)
    ):
        raise RuntimeError(f"independent neural history records evaluation access: {unit_id}")
    selected_epoch = int(np.flatnonzero(medians == np.max(medians))[0]) + 1
    selected_relative = f"checkpoints/epoch_{selected_epoch:03d}.pt"
    selection = {
        "schema_version": "tukf09_neural_model_selection_v1",
        "experiment_id": EXPERIMENT_ID,
        "unit_id": unit_id,
        "lead_days": lead,
        "seed": seed,
        "selected_epoch": selected_epoch,
        "selected_checkpoint_relative_path": selected_relative,
        "selected_checkpoint_sha256": _sha256_file(directory / selected_relative),
        "validation_median_nse": float(medians[selected_epoch - 1]),
        "checkpoint_count": 30,
        "selection_rule": "largest_455_basin_median_nse_earliest_epoch_tie_break",
        "best_seed_selection_forbidden": True,
        "evaluation_access_count": 0,
    }
    if _read_json(directory / "model_selection.json") != selection:
        raise RuntimeError(f"independent neural checkpoint selection differs: {unit_id}")
    ledger = {
        "schema_version": "tukf09_neural_access_ledger_v1",
        "experiment_id": EXPERIMENT_ID,
        "unit_id": unit_id,
        "lead_days": lead,
        "training": {
            "sample_count": len(basins) * TRAINING_SAMPLES_PER_BASIN,
            "first_target_index": SEQUENCE_LENGTH,
            "last_target_index": TRAINING_DAYS - 1,
            "maximum_discharge_source_offset_days": lead,
            "meteorological_forcing_through_target": True,
        },
        "validation": {
            "sample_count": len(basins) * VALIDATION_SAMPLES_PER_BASIN,
            "first_target_index": SEQUENCE_LENGTH,
            "last_target_index": VALIDATION_DAYS - 1,
            "maximum_discharge_source_offset_days": lead,
            "meteorological_forcing_through_target": True,
        },
        "evaluation_access_count": 0,
        "evaluation_prediction_count": 0,
        "evaluation_metric_count": 0,
    }
    if _read_json(directory / "access_ledger.json") != ledger:
        raise RuntimeError(f"independent neural evaluation ledger differs: {unit_id}")
    return (
        {
            "unit_id": unit_id,
            "lead_days": lead,
            "seed": seed,
            "unit_relative_path": f"neural/{unit_id}",
            "unit_manifest_sha256": _sha256_file(directory / "manifest.sha256.json"),
            "unit_manifest_file_count": manifest["file_count"],
            "training_scaler_sha256": scaler_hash,
            "selected_epoch": selected_epoch,
            "selected_checkpoint_relative_path": f"neural/{unit_id}/{selected_relative}",
            "selected_checkpoint_sha256": selection["selected_checkpoint_sha256"],
            "validation_median_nse": selection["validation_median_nse"],
            "best_seed_selection_forbidden": True,
        },
        tree,
    )


def _counts(expected: VerificationExpectations) -> dict[str, int]:
    filters = len(expected.basin_ids)
    neural = len(expected.neural_units)
    return {
        "rebound_filter_units": filters,
        "new_filter_training_units": 0,
        "inherited_filter_checkpoint_records": filters * FILTER_CHECKPOINT_COUNT,
        "new_filter_training_objective_calls": 0,
        "new_filter_validation_objective_calls": 0,
        "new_filter_gradient_updates": 0,
        "neural_model_units": neural,
        "neural_checkpoints": neural * NEURAL_CHECKPOINT_COUNT,
        "evaluation_array_reads": 0,
        "evaluation_predictions": 0,
        "evaluation_metrics": 0,
        "evaluation_outputs": 0,
    }


def _controller_and_log_records(
    root: Path, *, phase_owner: IndependentPhaseOwner | None = None
) -> dict[str, Any]:
    records: dict[str, Any] = {}
    excluded_owner = (
        _validate_owned_phase_lock(root, phase_owner) if phase_owner is not None else None
    )
    for directory_name in ("control", "logs"):
        directory = root / directory_name
        if not _exists(directory):
            continue
        if not directory.is_dir() or directory.is_symlink():
            raise RuntimeError(f"independent {directory_name} evidence root is invalid")
        for path in directory.rglob("*"):
            relative = path.relative_to(root).as_posix()
            if path.is_symlink():
                raise RuntimeError(f"independent linked controller evidence: {relative}")
            if path.is_dir():
                continue
            if not path.is_file() or path.stat().st_nlink != 1:
                raise RuntimeError(f"independent non-regular controller evidence: {relative}")
            if relative == excluded_owner:
                continue
            records[relative] = _record(path)
    return records


def _recompute_documents(
    root: Path,
    expected: VerificationExpectations,
    *,
    phase_owner: IndependentPhaseOwner | None = None,
) -> tuple[dict[str, dict[str, Any]], dict[str, Any]]:
    _no_evaluation_surface(root, phase_owner=phase_owner)
    root_records, source_bindings = _root_records(root, expected)
    tree: dict[str, Any] = dict(root_records)
    tree.update(_controller_and_log_records(root, phase_owner=phase_owner))
    filter_root = root / "filter"
    expected_filter = {f"basin_{basin_id}" for basin_id in expected.basin_ids}
    if (
        not filter_root.is_dir()
        or filter_root.is_symlink()
        or {path.name for path in filter_root.iterdir()} != expected_filter
        or any(not path.is_dir() or path.is_symlink() for path in filter_root.iterdir())
    ):
        raise RuntimeError("independent filter exact unit set differs")
    neural_root = root / "neural"
    neural_ids = tuple(f"lead_{lead}_seed_{seed}" for lead, seed in expected.neural_units)
    if (
        not neural_root.is_dir()
        or neural_root.is_symlink()
        or {path.name for path in neural_root.iterdir()} != {"shared", *neural_ids}
        or any(not path.is_dir() or path.is_symlink() for path in neural_root.iterdir())
    ):
        raise RuntimeError("independent neural exact unit set differs")
    filter_entries: list[dict[str, Any]] = []
    for basin_id in expected.basin_ids:
        entry, records = _filter_unit(
            root, basin_id, source_bindings=source_bindings
        )
        filter_entries.append(entry)
        prefix = f"filter/basin_{basin_id}/"
        tree.update({prefix + name: record for name, record in records.items()})
    scaler_hash, scaler_record = _scaler(root, expected.basin_ids)
    tree["neural/shared/training_scaler.json"] = scaler_record
    neural_entries: list[dict[str, Any]] = []
    for lead, seed in expected.neural_units:
        entry, records = _neural_unit(
            root,
            expected.basin_ids,
            scaler_hash,
            lead,
            seed,
            source_bindings=source_bindings,
        )
        neural_entries.append(entry)
        prefix = f"neural/lead_{lead}_seed_{seed}/"
        tree.update({prefix + name: record for name, record in records.items()})
    counts = _counts(expected)
    if expected.production:
        if counts != EXPECTED_COMPLETION_COUNTS:
            raise AssertionError("independent production totals changed")
    basin_digest = sha256(
        "".join(f"{value}\n" for value in expected.basin_ids).encode("utf-8")
    ).hexdigest()
    filter_registry = {
        "schema_version": "tukf09_filter_training_selection_registry_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "FILTER_REBOUND_SELECTION_COMPLETE_EVALUATION_HOLD",
        "basin_count": len(expected.basin_ids),
        "ordered_basin_newline_sha256": basin_digest,
        "checkpoint_count_per_basin": 256,
        "filter_result_origin": "FILTER_BASIN_REBOUND_FROM_VERIFIED_PARENT",
        "new_filter_training_units": 0,
        "selection_rule": "minimum_validation_objective_then_training_objective_then_actual_parameters_then_index",
        "formal_evaluation_authorized": False,
        "evaluation_access_count": 0,
        "units": filter_entries,
    }
    neural_registry = {
        "schema_version": "tukf09_neural_training_selection_registry_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "NEURAL_TRAINING_SELECTION_COMPLETE_EVALUATION_HOLD",
        "model_count": len(expected.neural_units),
        "ordered_basin_newline_sha256": basin_digest,
        "training_scaler_relative_path": "neural/shared/training_scaler.json",
        "training_scaler_sha256": scaler_hash,
        "normalization_scope": "training_only_global_population_statistics",
        "checkpoint_count_per_model": 30,
        "selection_rule": "largest_455_basin_median_nse_earliest_epoch_tie_break",
        "best_seed_selection_forbidden": True,
        "formal_evaluation_authorized": False,
        "evaluation_access_count": 0,
        "units": neural_entries,
    }
    filter_bytes = _json_bytes(filter_registry)
    neural_bytes = _json_bytes(neural_registry)
    summary = {
        "schema_version": "tukf09_selected_model_summary_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "TRAINING_MODEL_SELECTION_COMPLETE_EVALUATION_HOLD",
        "filter_registry_sha256": sha256(filter_bytes).hexdigest(),
        "neural_registry_sha256": sha256(neural_bytes).hexdigest(),
        "filter_selected_model_count": len(filter_entries),
        "neural_selected_model_count": len(neural_entries),
        "completion_counts": counts,
        "evaluation_access_ledger": {
            "evaluation_array_reads": 0,
            "evaluation_predictions": 0,
            "evaluation_metrics": 0,
            "evaluation_outputs": 0,
        },
        "formal_evaluation_authorized": False,
        "independent_training_selection_verification_required": True,
    }
    summary_bytes = _json_bytes(summary)
    tree.update(
        {
            "selection/filter_registry.json": {
                "sha256": sha256(filter_bytes).hexdigest(),
                "size_bytes": len(filter_bytes),
            },
            "selection/neural_registry.json": {
                "sha256": sha256(neural_bytes).hexdigest(),
                "size_bytes": len(neural_bytes),
            },
            "selection/selected_model_summary.json": {
                "sha256": sha256(summary_bytes).hexdigest(),
                "size_bytes": len(summary_bytes),
            },
        }
    )
    tree = dict(sorted(tree.items()))
    manifest = {
        "schema_version": "tukf09_full_training_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "FULL_TRAINING_MANIFEST_COMPLETE_EVALUATION_HOLD",
        "file_count": len(tree),
        "files": tree,
        "files_canonical_sha256": _payload_sha256(tree),
        "completion_counts": counts,
        "formal_evaluation_authorized": False,
    }
    manifest_bytes = _json_bytes(manifest)
    seal = {
        "schema_version": "tukf09_training_selection_seal_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "TRAINING_SELECTION_SEALED_EVALUATION_HOLD",
        "training_manifest_relative_path": "selection/training_manifest.sha256.json",
        "training_manifest_sha256": sha256(manifest_bytes).hexdigest(),
        "training_manifest_file_count": manifest["file_count"],
        "selection_directory_member_count": 5,
        "completion_counts": counts,
        "evaluation_access_ledger": summary["evaluation_access_ledger"],
        "formal_evaluation_authorized": False,
        "evaluation_prediction_generation_authorized": False,
        "evaluation_metric_computation_authorized": False,
        "independent_training_selection_verification_required": True,
    }
    return (
        {
            "filter_registry.json": filter_registry,
            "neural_registry.json": neural_registry,
            "selected_model_summary.json": summary,
            "training_manifest.sha256.json": manifest,
            "training_selection.sealed.json": seal,
        },
        {"scaler_sha256": scaler_hash, "counts": counts, "tree": tree},
    )


def _verify_selection_directory(
    root: Path, documents: Mapping[str, Mapping[str, Any]]
) -> None:
    selection = root / "selection"
    if not selection.is_dir() or selection.is_symlink():
        raise FileNotFoundError("independent training selection directory is absent or linked")
    actual = set()
    for path in selection.rglob("*"):
        if path.is_symlink() or not path.is_file() or path.stat().st_nlink != 1:
            raise RuntimeError(f"independent sealed selection member is invalid: {path}")
        actual.add(path.relative_to(selection).as_posix())
    if actual != SELECTION_MEMBER_NAMES:
        raise RuntimeError("independent sealed selection exact member set changed")
    for name, expected in documents.items():
        if _read_json(selection / name) != expected:
            raise RuntimeError(f"independent recomputation differs from sealed selection: {name}")


def _verify_existing(destination: Path, payloads: Mapping[str, bytes]) -> None:
    if not destination.is_dir() or destination.is_symlink():
        raise FileExistsError("independent audit destination is not an unlinked directory")
    actual = set()
    for path in destination.rglob("*"):
        if path.is_symlink() or not path.is_file() or path.stat().st_nlink != 1:
            raise RuntimeError(f"independent audit member is invalid: {path}")
        actual.add(path.relative_to(destination).as_posix())
    if actual != set(payloads):
        raise RuntimeError("independent audit exact member set changed")
    for name, content in payloads.items():
        if (destination / name).read_bytes() != content:
            raise RuntimeError(f"existing independent audit differs: {name}")


def _publish(destination: Path, payloads: Mapping[str, bytes]) -> None:
    if _exists(destination):
        raise FileExistsError("independent audit destination already exists")
    token = uuid.uuid4().hex
    pending = destination.with_name(f".independent.pending-{token}")
    pending.mkdir(parents=False, exist_ok=False)
    try:
        for name, content in sorted(payloads.items()):
            if Path(name).name != name:
                raise ValueError("independent audit member must be a direct file")
            with (pending / name).open("xb") as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
        if {path.name for path in pending.iterdir()} != set(payloads):
            raise RuntimeError("pending independent audit exact member set changed")
        if _exists(destination):
            raise FileExistsError("independent audit destination appeared during publication")
        os.replace(pending, destination)
    finally:
        if _exists(pending):
            if pending.parent != destination.parent or token not in pending.name:
                raise RuntimeError("refusing to remove an unowned independent pending directory")
            shutil.rmtree(pending)


def _independent_audit_payloads(
    root: Path,
    expected: VerificationExpectations,
    evidence: Mapping[str, Any],
) -> tuple[dict[str, Any], dict[str, bytes]]:
    selection_seal_path = root / "selection" / "training_selection.sealed.json"
    training_manifest_path = root / "selection" / "training_manifest.sha256.json"
    audit = {
        "schema_version": "tukf09_training_selection_independent_audit_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "TRAINING_SELECTION_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD",
        "mismatch_count": 0,
        "filter_basin_units_recomputed": len(expected.basin_ids),
        "neural_model_units_recomputed": len(expected.neural_units),
        "completion_counts": evidence["counts"],
        "training_tree_file_count": len(evidence["tree"]),
        "training_tree_files_canonical_sha256": _payload_sha256(evidence["tree"]),
        "training_only_normalization_sha256": evidence["scaler_sha256"],
        "training_manifest_sha256": _sha256_file(training_manifest_path),
        "training_selection_seal_sha256": _sha256_file(selection_seal_path),
        "unit_manifests_recomputed": True,
        "checkpoint_choices_recomputed": True,
        "training_only_normalization_identity_recomputed": True,
        "access_ledgers_recomputed": True,
        "evaluation_access_ledger": {
            "evaluation_array_reads": 0,
            "evaluation_predictions": 0,
            "evaluation_metrics": 0,
            "evaluation_outputs": 0,
        },
        "formal_evaluation_authorized": False,
    }
    audit_bytes = _json_bytes(audit)
    final_manifest = {
        "schema_version": "tukf09_training_selection_independent_final_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "TRAINING_SELECTION_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD",
        "file_count": 1,
        "files": {
            "independent_audit.json": {
                "sha256": sha256(audit_bytes).hexdigest(),
                "size_bytes": len(audit_bytes),
            }
        },
        "source_training_selection_seal_sha256": audit[
            "training_selection_seal_sha256"
        ],
        "formal_evaluation_authorized": False,
    }
    payloads = {
        "independent_audit.json": audit_bytes,
        "manifest.final.sha256.json": _json_bytes(final_manifest),
    }
    if set(payloads) != INDEPENDENT_MEMBER_NAMES:
        raise AssertionError("internal independent audit member set changed")
    return audit, payloads


def verify_training_selection_independently(
    *,
    output_root: str | Path,
    population_registry: str | Path | None = None,
    execution_config: str | Path | None = None,
    expected_basin_ids: Sequence[str] | None = None,
    expected_neural_units: Sequence[Any] | None = None,
    verify_independent_training_selection: bool,
) -> dict[str, Any]:
    """Independently reproduce the selection seal and atomically publish its audit."""

    if verify_independent_training_selection is not True:
        raise PermissionError("explicit independent training-selection verification is required")
    root = Path(output_root)
    with _training_phase_lock(root, "independent") as phase_owner:
        expected = _expectations(
            output_root=root,
            population_registry=(
                Path(population_registry) if population_registry is not None else None
            ),
            execution_config=(Path(execution_config) if execution_config is not None else None),
            expected_basin_ids=expected_basin_ids,
            expected_neural_units=expected_neural_units,
        )
        documents, evidence = _recompute_documents(
            root, expected, phase_owner=phase_owner
        )
        _verify_selection_directory(root, documents)
        audit, payloads = _independent_audit_payloads(root, expected, evidence)
        destination = root / "independent"
        reused = False
        if _exists(destination):
            _verify_existing(destination, payloads)
            reused = True
        else:
            _publish(destination, payloads)
            _verify_existing(destination, payloads)

    post_documents, post_evidence = _recompute_documents(root, expected)
    _verify_selection_directory(root, post_documents)
    post_audit, post_payloads = _independent_audit_payloads(
        root, expected, post_evidence
    )
    if (
        post_documents != documents
        or post_evidence != evidence
        or post_audit != audit
        or post_payloads != payloads
    ):
        raise RuntimeError("independent training tree changed across phase-lock release")
    _verify_existing(destination, post_payloads)
    return {
        "status": audit["status"],
        "independent_root": str(destination.resolve(strict=False)),
        "mismatch_count": 0,
        "filter_basin_units": len(expected.basin_ids),
        "neural_model_units": len(expected.neural_units),
        "formal_evaluation_authorized": False,
        "reused": reused,
    }


verify_tukf09_training_selection = verify_training_selection_independently


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--population-registry", type=Path, default=DEFAULT_POPULATION_REGISTRY)
    parser.add_argument("--execution-config", type=Path, default=DEFAULT_EXECUTION_CONFIG)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--verify-independent-training-selection", action="store_true")
    return parser


def main() -> None:
    arguments = _parser().parse_args()
    result = verify_training_selection_independently(
        output_root=arguments.output_root,
        population_registry=arguments.population_registry,
        execution_config=arguments.execution_config,
        verify_independent_training_selection=arguments.verify_independent_training_selection,
    )
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
