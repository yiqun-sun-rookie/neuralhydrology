"""Run the admitted TUKF09 filter and neural controllers strictly in sequence.

This top-level controller never imports or loads hydrological period arrays.  It
holds one process lock, runs the filter controller to exact successful
completion, and only then runs the neural controller.  Both child commands are
constructed exclusively from the fixed admitted paths.
"""
from __future__ import annotations

import argparse
from contextlib import AbstractContextManager
from dataclasses import dataclass
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from typing import Any, Callable, Mapping, Sequence
import uuid


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import tukf09_455_training_common as training_common  # noqa: E402
from scripts import tukf09_455_training_controller_common as controller_common  # noqa: E402


EXPERIMENT_ID = training_common.EXPERIMENT_ID
EVENT_SCHEMA = "tukf09_formal_training_sequence_event_v1"
RESULT_SCHEMA = "tukf09_formal_training_sequence_result_v1"
EXECUTION_RELATIVE = Path("configs/tukf09_455_basin_zero_validation_target_variance_formal_training_execution_v1.json")
FILTER_CONTROLLER_RELATIVE = Path(
    "scripts/verify_tukf09_455_filter_rebinding_controller.py"
)
NEURAL_CONTROLLER_RELATIVE = Path(
    "scripts/run_tukf09_455_neural_training_controller.py"
)
STAGE_ORDER = ("verify_filter_rebinding", "neural")
_HEX_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_CHILD_FLAGS = frozenset(
    {
        "--config",
        "--preflight-root",
        "--authorization",
        "--training-admission",
        "--execution-config",
        "--output-root",
        "--execute-formal-training",
    }
)


@dataclass(frozen=True)
class FixedPaths:
    project_root: Path
    config: Path
    preflight_root: Path
    authorization: Path
    training_admission: Path
    execution_config: Path
    output_root: Path
    control_root: Path
    logs_root: Path
    filter_controller: Path
    neural_controller: Path


def fixed_paths(project_root: Path = ROOT) -> FixedPaths:
    root = _absolute_without_resolving(project_root)
    output = root / training_common.OUTPUT_RELATIVE
    return FixedPaths(
        project_root=root,
        config=root / training_common.CONFIG_RELATIVE,
        preflight_root=(root / training_common.PREFLIGHT_FINAL_RELATIVE).parents[1],
        authorization=root / training_common.AUTHORIZATION_RELATIVE,
        training_admission=root / training_common.ADMISSION_RELATIVE,
        execution_config=root / EXECUTION_RELATIVE,
        output_root=output,
        control_root=output / "control" / "formal_training_sequence",
        logs_root=output / "logs" / "formal_training_sequence",
        filter_controller=root / FILTER_CONTROLLER_RELATIVE,
        neural_controller=root / NEURAL_CONTROLLER_RELATIVE,
    )


def _absolute_without_resolving(path: Path | str) -> Path:
    return Path(os.path.abspath(os.fspath(path)))


def _same_path(left: Path | str, right: Path | str) -> bool:
    return os.path.normcase(os.fspath(_absolute_without_resolving(left))) == os.path.normcase(
        os.fspath(_absolute_without_resolving(right))
    )


def _is_link_or_reparse(path: Path) -> bool:
    candidate = Path(path)
    if candidate.is_symlink():
        return True
    status = os.lstat(candidate)
    attributes = int(getattr(status, "st_file_attributes", 0))
    reparse_flag = int(getattr(status, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))
    return bool(attributes & reparse_flag)


def _gate_unlinked_components(path: Path, *, stop_at: Path) -> None:
    target = _absolute_without_resolving(path)
    boundary = _absolute_without_resolving(stop_at)
    try:
        relative = target.relative_to(boundary)
    except ValueError as exc:
        raise ValueError("formal training sequence path escapes the project root") from exc
    current = boundary
    candidates = [boundary]
    for part in relative.parts:
        current = current / part
        candidates.append(current)
    for candidate in candidates:
        if os.path.lexists(os.fspath(candidate)) and _is_link_or_reparse(candidate):
            raise RuntimeError(
                f"formal training sequence path contains a link or reparse point: {candidate}"
            )


def gate_fixed_paths(requested: FixedPaths, expected: FixedPaths | None = None) -> None:
    """Reject every override, link, reparse point, or uninitialized output."""

    frozen = fixed_paths(requested.project_root) if expected is None else expected
    for field in FixedPaths.__dataclass_fields__:
        if not _same_path(getattr(requested, field), getattr(frozen, field)):
            raise ValueError(f"formal training sequence {field} differs from its fixed path")
    for path in (
        requested.config,
        requested.authorization,
        requested.training_admission,
        requested.execution_config,
        requested.filter_controller,
        requested.neural_controller,
    ):
        _gate_unlinked_components(path, stop_at=requested.project_root)
        if (
            not os.path.lexists(os.fspath(path))
            or not path.is_file()
            or _is_link_or_reparse(path)
            or int(path.stat().st_nlink) != 1
        ):
            raise FileNotFoundError(
                f"formal training sequence requires one regular unlinked file: {path}"
            )
    final_manifest = requested.preflight_root / "independent" / "manifest.final.sha256.json"
    _gate_unlinked_components(final_manifest, stop_at=requested.project_root)
    if (
        not final_manifest.is_file()
        or _is_link_or_reparse(final_manifest)
        or int(final_manifest.stat().st_nlink) != 1
    ):
        raise FileNotFoundError("fixed independent preflight final manifest is unavailable")
    _gate_unlinked_components(requested.output_root, stop_at=requested.project_root)
    if not requested.output_root.is_dir() or _is_link_or_reparse(requested.output_root):
        raise RuntimeError("initialized regular unlinked formal-training output root is required")
    for directory in (requested.control_root, requested.logs_root):
        _gate_unlinked_components(directory, stop_at=requested.project_root)
        if os.path.lexists(os.fspath(directory)) and (
            not directory.is_dir() or _is_link_or_reparse(directory)
        ):
            raise RuntimeError("formal training sequence control or log root is invalid")


class SequenceLock(AbstractContextManager["SequenceLock"]):
    """One lifecycle directory lock with exact dead-owner recovery."""

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.owner: dict[str, Any] | None = None
        self.parent_created = False

    @staticmethod
    def _process_is_alive(process_id: int) -> bool:
        return controller_common.process_is_alive(process_id)

    def _validate_owner(self) -> dict[str, Any]:
        if not self.path.is_dir() or _is_link_or_reparse(self.path):
            raise RuntimeError("formal training sequence lock is linked or invalid")
        if {member.name for member in self.path.iterdir()} != {"owner.json"}:
            raise RuntimeError("formal training sequence lock member set changed")
        owner_path = self.path / "owner.json"
        if (
            not owner_path.is_file()
            or _is_link_or_reparse(owner_path)
            or int(owner_path.stat().st_nlink) != 1
        ):
            raise RuntimeError("formal training sequence owner is linked or invalid")
        raw = owner_path.read_bytes()
        try:
            owner = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise RuntimeError("formal training sequence owner is invalid JSON") from exc
        if not isinstance(owner, dict) or raw != controller_common.canonical_json_bytes(owner):
            raise RuntimeError("formal training sequence owner is not canonical")
        if (
            set(owner)
            != {
                "schema_version",
                "experiment_id",
                "execution_id",
                "process_id",
                "started_at_utc",
            }
            or owner.get("schema_version") != "tukf09_formal_training_sequence_owner_v1"
            or owner.get("experiment_id") != EXPERIMENT_ID
            or not isinstance(owner.get("execution_id"), str)
            or len(owner["execution_id"]) != 32
            or not isinstance(owner.get("process_id"), int)
            or isinstance(owner.get("process_id"), bool)
            or owner["process_id"] <= 0
            or not isinstance(owner.get("started_at_utc"), str)
        ):
            raise RuntimeError("formal training sequence owner identity changed")
        return owner

    def __enter__(self) -> "SequenceLock":
        self.parent_created = not os.path.lexists(os.fspath(self.path.parent))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            self.path.mkdir()
        except FileExistsError:
            prior = self._validate_owner()
            if self._process_is_alive(int(prior["process_id"])):
                raise RuntimeError("another formal training sequence controller is active")
            raise RuntimeError(
                "stale formal training sequence lock requires manual global process audit"
            )
        self.owner = {
            "schema_version": "tukf09_formal_training_sequence_owner_v1",
            "experiment_id": EXPERIMENT_ID,
            "execution_id": uuid.uuid4().hex,
            "process_id": os.getpid(),
            "started_at_utc": controller_common.utc_now(),
        }
        owner_path = self.path / "owner.json"
        with owner_path.open("xb") as handle:
            handle.write(controller_common.canonical_json_bytes(self.owner))
            handle.flush()
            os.fsync(handle.fileno())
        return self

    def __exit__(self, exc_type, exc_value, traceback_value) -> None:
        if self.owner is None:
            return
        if self._validate_owner() != self.owner:
            raise RuntimeError("formal training sequence lock identity changed")
        (self.path / "owner.json").unlink()
        self.path.rmdir()
        if self.parent_created and self.path.parent.is_dir() and not any(
            self.path.parent.iterdir()
        ):
            self.path.parent.rmdir()
        self.owner = None


class SleepPrevention(AbstractContextManager["SleepPrevention"]):
    def __init__(self, enabled: bool) -> None:
        self.enabled = bool(enabled)

    @staticmethod
    def _set(enabled: bool) -> None:
        if os.name != "nt":  # pragma: no cover - production is Windows
            return
        import ctypes

        es_continuous = 0x80000000
        flags = es_continuous | (0x00000001 | 0x00000040 if enabled else 0)
        if not ctypes.windll.kernel32.SetThreadExecutionState(flags):
            raise RuntimeError("Windows sleep-prevention request failed")

    def __enter__(self) -> "SleepPrevention":
        if self.enabled:
            self._set(True)
        return self

    def __exit__(self, exc_type, exc_value, traceback_value) -> None:
        if self.enabled:
            self._set(False)


class CanonicalEventLog:
    """Append-only canonical JSON Lines with a global monotonic sequence."""

    def __init__(self, path: Path, execution_id: str) -> None:
        self.path = Path(path)
        self.execution_id = str(execution_id)
        self.sequence = self._verify_prior_records()

    def _verify_prior_records(self) -> int:
        if not os.path.lexists(os.fspath(self.path)):
            return 0
        if (
            not self.path.is_file()
            or _is_link_or_reparse(self.path)
            or int(self.path.stat().st_nlink) != 1
        ):
            raise RuntimeError("formal training sequence event log is linked or invalid")
        raw = self.path.read_bytes()
        if raw and not raw.endswith(b"\n"):
            raise RuntimeError("formal training sequence event log has a truncated record")
        expected = 0
        for line in raw.splitlines(keepends=True):
            try:
                record = json.loads(line.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise RuntimeError("formal training sequence event log contains invalid JSON") from exc
            if not isinstance(record, dict) or line != controller_common.canonical_json_bytes(record):
                raise RuntimeError("formal training sequence event log is not canonical")
            expected += 1
            if (
                record.get("schema_version") != EVENT_SCHEMA
                or record.get("experiment_id") != EXPERIMENT_ID
                or record.get("sequence") != expected
                or not isinstance(record.get("execution_id"), str)
            ):
                raise RuntimeError("formal training sequence event identity or order changed")
        return expected

    def emit(self, event: str, **fields: Any) -> dict[str, Any]:
        self.sequence += 1
        record = {
            "schema_version": EVENT_SCHEMA,
            "experiment_id": EXPERIMENT_ID,
            "execution_id": self.execution_id,
            "sequence": self.sequence,
            "event": str(event),
            "event_at_utc": controller_common.utc_now(),
            **fields,
        }
        self.path.parent.mkdir(parents=True, exist_ok=True)
        flags = os.O_WRONLY | os.O_CREAT | os.O_APPEND | getattr(os, "O_BINARY", 0)
        descriptor = os.open(self.path, flags, 0o600)
        try:
            os.write(descriptor, controller_common.canonical_json_bytes(record))
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
        return record


def load_sequence_execution_contract(path: Path) -> dict[str, Any]:
    contract = controller_common.load_execution_config(path)
    resources = contract.get("resource_policy", {})
    if (
        resources.get("execution_route") != "local_sequential_controller"
        or resources.get("prevent_system_sleep_while_controller_active") is not True
        or contract.get("controller_order", {}).get("training_stages")
        != list(STAGE_ORDER)
    ):
        raise RuntimeError("formal training sequence order or resource route changed")
    return contract


def verify_training_admission(paths: FixedPaths) -> dict[str, Any]:
    required = [
        paths.project_root / relative
        for relative in training_common.REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS
    ]
    return training_common.load_and_verify_training_admission(
        paths.training_admission,
        paths.execution_config,
        required,
    )


def controller_source_hashes(paths: FixedPaths) -> dict[str, str]:
    return {
        "verify_filter_rebinding": controller_common.sha256_file(paths.filter_controller),
        "neural": controller_common.sha256_file(paths.neural_controller),
    }


def build_stage_command(
    stage: str,
    paths: FixedPaths,
    *,
    python_executable: Path | str | None = None,
) -> list[str]:
    if stage not in STAGE_ORDER:
        raise ValueError("unknown formal training stage")
    controller = paths.filter_controller if stage == "verify_filter_rebinding" else paths.neural_controller
    command = [
        os.fspath(sys.executable if python_executable is None else python_executable),
        "-B",
        os.fspath(controller),
        "--config",
        os.fspath(paths.config),
        "--preflight-root",
        os.fspath(paths.preflight_root),
        "--authorization",
        os.fspath(paths.authorization),
        "--training-admission",
        os.fspath(paths.training_admission),
        "--execution-config",
        os.fspath(paths.execution_config),
        "--output-root",
        os.fspath(paths.output_root),
        "--execute-formal-training",
    ]
    flags = {part for part in command if part.startswith("--")}
    if flags != _CHILD_FLAGS or len(command) != 16:
        raise PermissionError("formal training stage command surface changed")
    return command


def _stage_log_paths(paths: FixedPaths, stage: str) -> tuple[Path, Path]:
    return (
        paths.logs_root / f"{stage}_controller.stdout.log",
        paths.logs_root / f"{stage}_controller.stderr.log",
    )


def _open_stage_logs(paths: FixedPaths, stage: str) -> tuple[Any, Any, int]:
    paths.logs_root.mkdir(parents=True, exist_ok=True)
    stdout_path, stderr_path = _stage_log_paths(paths, stage)
    for path in (stdout_path, stderr_path):
        if os.path.lexists(os.fspath(path)) and (
            not path.is_file()
            or _is_link_or_reparse(path)
            or int(path.stat().st_nlink) != 1
        ):
            raise RuntimeError("formal training sequence stage log is linked or invalid")
    stdout_offset = stdout_path.stat().st_size if stdout_path.exists() else 0
    return (
        stdout_path.open("ab", buffering=0),
        stderr_path.open("ab", buffering=0),
        stdout_offset,
    )


def verify_stage_completion_stdout(
    stage: str,
    stdout_path: Path,
    *,
    offset: int,
    admission_record_sha256: str,
) -> dict[str, Any]:
    raw = Path(stdout_path).read_bytes()[int(offset) :]
    records: list[dict[str, Any]] = []
    for line in raw.splitlines():
        if not line.strip():
            continue
        try:
            value = json.loads(line.decode("utf-8"), parse_constant=lambda token: (_ for _ in ()).throw(ValueError(token)))
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
            raise RuntimeError("stage stdout contains a non-JSON completion record") from exc
        if not isinstance(value, dict):
            raise RuntimeError("stage stdout completion record is not an object")
        records.append(value)
    if len(records) != 1:
        raise RuntimeError("stage stdout must contain exactly one completion record")
    result = records[0]
    if stage == "verify_filter_rebinding":
        if (
            result.get("schema_version") != "tukf09_455_filter_rebinding_controller_result_v1"
            or result.get("experiment_id") != EXPERIMENT_ID
            or result.get("status") != "FILTER_REBINDING_VERIFIED_EVALUATION_HOLD"
            or result.get("canonical_unit_count") != 455
            or result.get("completed_unit_count") != 455
            or result.get("training_admission_record_sha256")
            != admission_record_sha256
            or result.get("evaluation_access_count") != 0
        ):
            raise RuntimeError(
                "filter-rebinding controller did not report exact successful completion"
            )
    elif stage == "neural":
        if (
            result.get("schema_version") != "tukf09_neural_controller_result_v1"
            or result.get("experiment_id") != EXPERIMENT_ID
            or result.get("status") != "NEURAL_TRAINING_COMPLETE_EVALUATION_HOLD"
            or result.get("unit_count") != 9
            or result.get("checkpoint_count") != 270
            or result.get("evaluation_access_count") != 0
            or result.get("training_admission_record_sha256")
            != admission_record_sha256
        ):
            raise RuntimeError("neural controller did not report exact successful completion")
    else:
        raise ValueError("unknown formal training stage")
    return result


def _terminate_process(process: Any) -> int | None:
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=10)
    value = getattr(process, "returncode", None)
    return int(value) if isinstance(value, int) else None


def _run_stage(
    stage: str,
    *,
    paths: FixedPaths,
    events: CanonicalEventLog,
    admission_record_sha256: str,
    source_sha256: Mapping[str, str],
    process_factory: Callable[..., Any],
    completion_verifier: Callable[..., Mapping[str, Any]],
) -> dict[str, Any]:
    command = build_stage_command(stage, paths)
    stdout_path, stderr_path = _stage_log_paths(paths, stage)
    stdout_handle, stderr_handle, stdout_offset = _open_stage_logs(paths, stage)
    environment = dict(os.environ)
    environment.update({"PYTHONDONTWRITEBYTECODE": "1", "PYTHONUNBUFFERED": "1"})
    kwargs: dict[str, Any] = {
        "cwd": os.fspath(paths.project_root),
        "env": environment,
        "stdin": subprocess.DEVNULL,
        "stdout": stdout_handle,
        "stderr": stderr_handle,
    }
    if os.name == "nt":
        kwargs["creationflags"] = int(getattr(subprocess, "CREATE_NO_WINDOW", 0))
    started_at_utc = controller_common.utc_now()
    process: Any | None = None
    try:
        process = process_factory(command, **kwargs)
        process_id = getattr(process, "pid", None)
        if not isinstance(process_id, int) or process_id <= 0:
            raise RuntimeError("formal training stage process has no valid identity")
        events.emit(
            "stage_started",
            stage=stage,
            stage_process_id=process_id,
            stage_started_at_utc=started_at_utc,
            training_admission_record_sha256=admission_record_sha256,
            stage_controller_source_sha256=dict(source_sha256),
        )
        exit_code = int(process.wait())
    except BaseException as exc:
        exit_code = _terminate_process(process) if process is not None else None
        ended_at_utc = controller_common.utc_now()
        events.emit(
            "stage_failed",
            stage=stage,
            stage_process_id=(getattr(process, "pid", None) if process is not None else None),
            stage_started_at_utc=started_at_utc,
            stage_ended_at_utc=ended_at_utc,
            exit_code=exit_code,
            error=f"{type(exc).__name__}: {exc}",
            training_admission_record_sha256=admission_record_sha256,
            stage_controller_source_sha256=dict(source_sha256),
        )
        raise
    finally:
        stdout_handle.close()
        stderr_handle.close()
    ended_at_utc = controller_common.utc_now()
    if exit_code != 0:
        events.emit(
            "stage_failed",
            stage=stage,
            stage_process_id=process.pid,
            stage_started_at_utc=started_at_utc,
            stage_ended_at_utc=ended_at_utc,
            exit_code=exit_code,
            error="controller returned a nonzero exit code",
            training_admission_record_sha256=admission_record_sha256,
            stage_controller_source_sha256=dict(source_sha256),
        )
        raise RuntimeError(f"formal training {stage} controller failed with exit code {exit_code}")
    try:
        completion = dict(
            completion_verifier(
                stage,
                stdout_path,
                offset=stdout_offset,
                admission_record_sha256=admission_record_sha256,
            )
        )
    except BaseException as exc:
        events.emit(
            "stage_failed",
            stage=stage,
            stage_process_id=process.pid,
            stage_started_at_utc=started_at_utc,
            stage_ended_at_utc=ended_at_utc,
            exit_code=exit_code,
            error=f"completion verification failed: {type(exc).__name__}: {exc}",
            training_admission_record_sha256=admission_record_sha256,
            stage_controller_source_sha256=dict(source_sha256),
        )
        raise
    events.emit(
        "stage_completed",
        stage=stage,
        stage_process_id=process.pid,
        stage_started_at_utc=started_at_utc,
        stage_ended_at_utc=ended_at_utc,
        exit_code=exit_code,
        training_admission_record_sha256=admission_record_sha256,
        stage_controller_source_sha256=dict(source_sha256),
        completion_status=completion.get("status"),
    )
    return {
        "stage": stage,
        "process_id": int(process.pid),
        "started_at_utc": started_at_utc,
        "ended_at_utc": ended_at_utc,
        "exit_code": exit_code,
        "completion": completion,
    }


def run_sequence(
    *,
    execute_formal_training: bool,
    paths: FixedPaths | None = None,
    process_factory: Callable[..., Any] = subprocess.Popen,
    admission_verifier: Callable[[FixedPaths], Mapping[str, Any]] = verify_training_admission,
    execution_loader: Callable[[Path], Mapping[str, Any]] = load_sequence_execution_contract,
    path_gate: Callable[[FixedPaths, FixedPaths | None], None] = gate_fixed_paths,
    source_hasher: Callable[[FixedPaths], Mapping[str, str]] = controller_source_hashes,
    completion_verifier: Callable[..., Mapping[str, Any]] = verify_stage_completion_stdout,
    initialized_root_verifier: Callable[..., Mapping[str, Any]] = (
        training_common.verify_initialized_training_root
    ),
    sleep_prevention_factory: Callable[[bool], Any] = SleepPrevention,
    lock_factory: Callable[[Path], Any] = SequenceLock,
) -> dict[str, Any]:
    if execute_formal_training is not True:
        raise PermissionError("formal training sequence requires explicit training authorization")
    selected = fixed_paths() if paths is None else paths
    path_gate(selected, fixed_paths(selected.project_root))
    execution = dict(execution_loader(selected.execution_config))
    if execution.get("controller_order", {}).get("training_stages") != list(STAGE_ORDER):
        raise RuntimeError("formal training stage order changed")
    resources = execution.get("resource_policy", {})
    if resources.get("execution_route") != "local_sequential_controller":
        raise RuntimeError("formal training execution route is not the sequential controller")
    admission = dict(admission_verifier(selected))
    admission_record_sha256 = admission.get("training_admission_record_sha256")
    if _HEX_SHA256.fullmatch(str(admission_record_sha256)) is None:
        raise RuntimeError("verified training admission lacks its record SHA-256")
    initialized_root_verifier(
        output_root=selected.output_root,
        config_path=selected.config,
        authorization=selected.authorization,
        execution_config=selected.execution_config,
        training_admission=selected.training_admission,
        training_admission_record=admission,
    )
    source_sha256 = dict(source_hasher(selected))
    if set(source_sha256) != set(STAGE_ORDER) or any(
        _HEX_SHA256.fullmatch(str(value)) is None for value in source_sha256.values()
    ):
        raise RuntimeError("formal training controller source SHA-256 set is invalid")

    phase_control_root = selected.output_root / "control"
    lock_path = phase_control_root / ".sequence_controller.lock"
    with lock_factory(lock_path) as sequence_lock:
        owner = getattr(sequence_lock, "owner", None)
        if (
            not isinstance(owner, Mapping)
            or re.fullmatch(r"[0-9a-f]{32}", str(owner.get("execution_id", ""))) is None
            or owner.get("process_id") != os.getpid()
        ):
            raise RuntimeError("formal training sequence lock did not issue its owner capability")
        with controller_common.training_phase_lock(phase_control_root, "sequence"):
            controller_common.reject_post_training_outputs(selected.output_root)
        selected.control_root.mkdir(parents=True, exist_ok=True)
        # Mutable identities are verified again after exclusive ownership.
        path_gate(selected, fixed_paths(selected.project_root))
        if dict(source_hasher(selected)) != source_sha256:
            raise RuntimeError("formal training controller source changed before launch")
        if (
            dict(admission_verifier(selected)).get("training_admission_record_sha256")
            != admission_record_sha256
        ):
            raise RuntimeError("training admission changed before launch")
        execution_id = str(owner["execution_id"])
        events = CanonicalEventLog(selected.control_root / "events.jsonl", execution_id)
        events.emit(
            "sequence_started",
            controller_process_id=os.getpid(),
            training_stages=list(STAGE_ORDER),
            training_admission_record_sha256=admission_record_sha256,
            stage_controller_source_sha256=source_sha256,
        )
        completed: list[dict[str, Any]] = []
        try:
            with sleep_prevention_factory(
                bool(resources.get("prevent_system_sleep_while_controller_active"))
            ):
                for stage in STAGE_ORDER:
                    if dict(source_hasher(selected)) != source_sha256:
                        raise RuntimeError("formal training controller source changed between stages")
                    if (
                        dict(admission_verifier(selected)).get(
                            "training_admission_record_sha256"
                        )
                        != admission_record_sha256
                    ):
                        raise RuntimeError("training admission changed between stages")
                    completed.append(
                        _run_stage(
                            stage,
                            paths=selected,
                            events=events,
                            admission_record_sha256=str(admission_record_sha256),
                            source_sha256=source_sha256,
                            process_factory=process_factory,
                            completion_verifier=completion_verifier,
                        )
                    )
            if [item["stage"] for item in completed] != list(STAGE_ORDER):
                raise RuntimeError("formal training stages did not complete in fixed order")
            if dict(source_hasher(selected)) != source_sha256:
                raise RuntimeError("formal training controller source changed before completion")
            if (
                dict(admission_verifier(selected)).get("training_admission_record_sha256")
                != admission_record_sha256
            ):
                raise RuntimeError("training admission changed before completion")
            result = {
                "schema_version": RESULT_SCHEMA,
                "experiment_id": EXPERIMENT_ID,
                "status": "FORMAL_TRAINING_COMPLETE_EVALUATION_HOLD",
                "controller_process_id": os.getpid(),
                "execution_id": execution_id,
                "training_admission_record_sha256": admission_record_sha256,
                "stage_controller_source_sha256": source_sha256,
                "stage_order": list(STAGE_ORDER),
                "stages": completed,
                "evaluation_access_count": 0,
            }
            events.emit(
                "sequence_completed",
                controller_process_id=os.getpid(),
                training_admission_record_sha256=admission_record_sha256,
                stage_controller_source_sha256=source_sha256,
                stage_order=list(STAGE_ORDER),
                evaluation_access_count=0,
            )
            return result
        except BaseException as exc:
            events.emit(
                "sequence_failed",
                controller_process_id=os.getpid(),
                completed_stages=[item["stage"] for item in completed],
                error=f"{type(exc).__name__}: {exc}",
                training_admission_record_sha256=admission_record_sha256,
                stage_controller_source_sha256=source_sha256,
                evaluation_access_count=0,
            )
            raise


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute-formal-training", action="store_true")
    return parser


def main() -> None:
    arguments = _parser().parse_args()
    result = run_sequence(execute_formal_training=arguments.execute_formal_training)
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, allow_nan=False), flush=True)


__all__ = [
    "CanonicalEventLog",
    "FixedPaths",
    "SequenceLock",
    "SleepPrevention",
    "build_stage_command",
    "controller_source_hashes",
    "fixed_paths",
    "gate_fixed_paths",
    "load_sequence_execution_contract",
    "run_sequence",
    "verify_stage_completion_stdout",
]


if __name__ == "__main__":
    main()
