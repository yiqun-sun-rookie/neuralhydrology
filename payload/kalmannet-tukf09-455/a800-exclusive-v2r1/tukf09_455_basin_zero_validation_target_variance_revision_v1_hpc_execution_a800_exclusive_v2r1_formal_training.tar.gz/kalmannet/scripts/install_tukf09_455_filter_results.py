"""Install independently sealed rebound-filter units into an initialized result root."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import uuid
from pathlib import Path
from typing import Any, Mapping, Sequence


ROOT = Path(__file__).resolve().parent.parent
EXPERIMENT_ID = "TUKF09_455_BASIN_ZERO_VALIDATION_TARGET_VARIANCE_REVISION_V1"
EXPECTED_UNIT_NAMES = {
    "identity.json",
    "history.npz",
    "selection.json",
    "access_ledger.json",
    "migration_provenance.json",
    "manifest.sha256.json",
}


def _reject_constant(value: str) -> None:
    raise ValueError(f"non-finite JSON is forbidden: {value}")


def _pairs(pairs: Sequence[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def _json_bytes(payload: Any) -> bytes:
    return (
        json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
        + b"\n"
    )


def _read_json(path: Path, *, canonical: bool = True) -> Mapping[str, Any]:
    _regular(path, label=f"JSON input {path}")
    content = Path(path).read_bytes()
    try:
        payload = json.loads(
            content.decode("utf-8"),
            object_pairs_hook=_pairs,
            parse_constant=_reject_constant,
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"invalid JSON: {path}") from exc
    if not isinstance(payload, dict):
        raise ValueError(f"JSON input must be an object: {path}")
    if canonical and content != _json_bytes(payload):
        raise ValueError(f"JSON input is noncanonical: {path}")
    return payload


def _hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _record(path: Path) -> dict[str, object]:
    return {"sha256": _hash_file(path), "size_bytes": Path(path).stat().st_size}


def _payload_hash(payload: Any) -> str:
    return hashlib.sha256(_json_bytes(payload)[:-1]).hexdigest()


def _reparse(path: Path) -> bool:
    return bool(getattr(Path(path).lstat(), "st_file_attributes", 0) & 0x400)


def _regular(path: Path, *, label: str) -> None:
    target = Path(path)
    if target.is_symlink() or _reparse(target) or not target.is_file():
        raise RuntimeError(f"{label} must be a regular non-reparse file")
    if target.stat().st_nlink != 1:
        raise RuntimeError(f"{label} is a hard link")


def _directory(path: Path, *, label: str) -> None:
    target = Path(path)
    if target.is_symlink() or _reparse(target) or not target.is_dir():
        raise RuntimeError(f"{label} must be a regular non-reparse directory")


def _same_file_content(left: Path, right: Path) -> bool:
    return left.stat().st_size == right.stat().st_size and _hash_file(left) == _hash_file(right)


def _verify_migration_final(migration_root: Path) -> Mapping[str, Any]:
    root = Path(migration_root)
    _directory(root, label="sealed migration root")
    final_path = root / "independent/manifest.final.sha256.json"
    audit_path = root / "independent/independent_audit.json"
    final = _read_json(final_path)
    audit = _read_json(audit_path)
    if (
        final.get("schema_version") != "tukf09_455_filter_migration_final_manifest_v1"
        or final.get("status") != "FILTER_MIGRATION_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
        or audit.get("status") != "FILTER_MIGRATION_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
        or audit.get("evaluation_access_count") != 0
    ):
        raise RuntimeError("migration independent seal changed")
    actual = {
        path.relative_to(root).as_posix(): _record(path)
        for path in sorted(root.rglob("*"))
        if path.is_file() and path != final_path
    }
    if final.get("file_count") != len(actual) or final.get("files") != actual:
        raise RuntimeError("migration final manifest differs from its sealed files")
    return final


def _migration_reference(admission: Mapping[str, Any]) -> Mapping[str, Any]:
    for key in (
        "migration_final_manifest",
        "filter_migration_final_manifest",
        "independent_filter_migration_final_manifest",
    ):
        value = admission.get(key)
        if isinstance(value, dict):
            return value
    raise RuntimeError("training admission does not bind the filter-migration final seal")


def _verify_admission(path: Path, migration_root: Path) -> tuple[Mapping[str, Any], str]:
    admission = _read_json(path)
    if (
        admission.get("schema_version") != "tukf09_455_training_admission_v1"
        or admission.get("experiment_id") != EXPERIMENT_ID
        or admission.get("status")
        != "NEURAL_TRAINING_ADMITTED_FILTER_REBINDING_INSTALLATION_PENDING_EVALUATION_HOLD"
    ):
        raise PermissionError("training admission is missing or changed")
    ledger = admission.get("access_ledger", {})
    if not isinstance(ledger, dict) or any(
        ledger.get(name) != 0
        for name in (
            "evaluation_array_reads",
            "evaluation_predictions",
            "evaluation_metrics",
            "evaluation_outputs",
        )
    ):
        raise PermissionError("training admission records evaluation access")
    final_path = Path(migration_root) / "independent/manifest.final.sha256.json"
    reference = _migration_reference(admission)
    reference_path = Path(str(reference.get("path")))
    if not reference_path.is_absolute():
        reference_path = ROOT / reference_path
    if reference_path.resolve(strict=False) != final_path.resolve(strict=False) or reference.get(
        "sha256"
    ) != _hash_file(final_path):
        raise RuntimeError("training admission migration-final binding changed")
    return admission, _hash_file(path)


def installation_attempt_id(training_admission_path: Path, migration_root: Path) -> str:
    admission_hash = _hash_file(Path(training_admission_path))
    migration_hash = _hash_file(Path(migration_root) / "independent/manifest.final.sha256.json")
    return hashlib.sha256(f"{admission_hash}:{migration_hash}".encode("ascii")).hexdigest()[:20]


def _stream_copy(source: Path, destination: Path) -> None:
    _regular(source, label="sealed staging source")
    with source.open("rb") as reader, destination.open("xb") as writer:
        for block in iter(lambda: reader.read(1024 * 1024), b""):
            writer.write(block)
        writer.flush()
        os.fsync(writer.fileno())
    _regular(destination, label="installed copy")
    if not _same_file_content(source, destination):
        raise RuntimeError("installed file is not byte-identical to the sealed staging source")
    if (source.stat().st_dev, source.stat().st_ino) == (
        destination.stat().st_dev,
        destination.stat().st_ino,
    ):
        raise RuntimeError("installed file aliases the staging source")


def _verify_unit_equal(source: Path, destination: Path) -> str:
    _directory(source, label="sealed staging unit")
    _directory(destination, label="installed filter unit")
    if {path.name for path in source.iterdir()} != EXPECTED_UNIT_NAMES or {
        path.name for path in destination.iterdir()
    } != EXPECTED_UNIT_NAMES:
        raise RuntimeError("staged or installed unit member set changed")
    for name in sorted(EXPECTED_UNIT_NAMES):
        left = source / name
        right = destination / name
        _regular(left, label=f"staging member {name}")
        _regular(right, label=f"installed member {name}")
        if not _same_file_content(left, right):
            raise RuntimeError(f"installed member differs from sealed staging: {name}")
        if (left.stat().st_dev, left.stat().st_ino) == (right.stat().st_dev, right.stat().st_ino):
            raise RuntimeError(f"installed member aliases the staging source: {name}")
    return _hash_file(destination / "manifest.sha256.json")


def _ordered_basins(
    admission: Mapping[str, Any], migration_root: Path, expected: Sequence[str] | None
) -> list[str]:
    if expected is not None:
        basins = [str(value) for value in expected]
    else:
        population = admission.get("population", {})
        basins = [str(value) for value in population.get("ordered_basin_ids", [])]
        if not basins:
            basins = [
                str(value)
                for value in _read_json(Path(migration_root) / "migration_summary.json").get(
                    "ordered_basin_ids", []
                )
            ]
    if len(basins) != len(set(basins)) or "08202700" in basins:
        raise RuntimeError("training-admitted filter population changed")
    if expected is None and len(basins) != 455:
        raise RuntimeError("production filter installation requires exactly 455 basins")
    return basins


def _verify_initialized_production_root(
    results_root: Path,
    training_admission_path: Path,
    admission: Mapping[str, Any],
) -> None:
    from scripts import tukf09_455_training_common as common
    from scripts import tukf09_455_training_profile as profile

    execution = ROOT / profile.FORMAL_TRAINING_CONFIG_RELATIVE
    verified = common.load_and_verify_training_admission(
        training_admission_path,
        execution,
        tuple(ROOT / relative for relative in common.REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS),
    )
    if dict(verified) != dict(admission):
        raise RuntimeError("installer admission differs from the production admission verifier")
    common.verify_initialized_training_root(
        output_root=results_root,
        config_path=ROOT / profile.CONTRACT_RELATIVE,
        authorization=ROOT / profile.AUTHORIZATION_RELATIVE,
        execution_config=execution,
        training_admission=training_admission_path,
        training_admission_record=verified,
    )


def _verify_existing_seal(
    seal_path: Path,
    *,
    admission_hash: str,
    migration_final_hash: str,
    basin_ids: Sequence[str],
    manifest_map: Mapping[str, str],
) -> Mapping[str, Any]:
    seal = _read_json(seal_path)
    if (
        seal.get("schema_version") != "tukf09_455_filter_rebinding_seal_v1"
        or seal.get("experiment_id") != EXPERIMENT_ID
        or seal.get("status") != "FILTER_REBINDING_INSTALLED_455_EVALUATION_HOLD"
        or seal.get("training_admission_sha256") != admission_hash
        or seal.get("migration_final_manifest_sha256") != migration_final_hash
        or seal.get("ordered_basin_ids") != list(basin_ids)
        or seal.get("unit_manifest_sha256_by_basin") != dict(manifest_map)
        or seal.get("evaluation_access_count") != 0
    ):
        raise RuntimeError("existing filter-rebinding seal changed")
    return seal


def install_rebound_filters(
    *,
    migration_root: Path | None = None,
    results_root: Path | None = None,
    training_admission_path: Path | None = None,
    authorize: bool,
    expected_basin_ids: Sequence[str] | None = None,
    fail_after_unit: int | None = None,
) -> dict[str, object]:
    if authorize is not True:
        raise PermissionError("filter-result installation requires explicit authorization")
    migration_root = migration_root or ROOT / (
        "artifacts/tukf09_455_basin_zero_validation_target_variance_revision_v1/filter_migration_v1"
    )
    results_root = results_root or ROOT / (
        "results/tukf09_455_basin_zero_validation_target_variance_revision_v1"
    )
    training_admission_path = training_admission_path or ROOT / (
        "artifacts/tukf09_455_basin_zero_validation_target_variance_revision_v1/"
        "training_admission/training_admission.json"
    )
    _verify_migration_final(Path(migration_root))
    admission, admission_hash = _verify_admission(Path(training_admission_path), Path(migration_root))
    _directory(Path(results_root), label="initialized result root")
    if expected_basin_ids is None:
        _verify_initialized_production_root(
            Path(results_root), Path(training_admission_path), admission
        )
    control = Path(results_root) / "control"
    if control.exists() or control.is_symlink():
        _directory(control, label="initialized result control root")
    else:
        control.mkdir()
    basins = _ordered_basins(admission, Path(migration_root), expected_basin_ids)
    source_units = Path(migration_root) / "units"
    _directory(source_units, label="sealed staging units root")
    if {path.name for path in source_units.iterdir()} != {f"basin_{basin}" for basin in basins}:
        raise RuntimeError("sealed staging population differs from training admission")
    final_migration_path = Path(migration_root) / "independent/manifest.final.sha256.json"
    migration_hash = _hash_file(final_migration_path)
    attempt = installation_attempt_id(Path(training_admission_path), Path(migration_root))
    filter_root = Path(results_root) / "filter"
    if filter_root.exists():
        _directory(filter_root, label="result filter root")
    else:
        filter_root.mkdir()
    installed = 0
    reused = 0
    manifest_map: dict[str, str] = {}
    for basin in basins:
        source = source_units / f"basin_{basin}"
        final = filter_root / f"basin_{basin}"
        if final.exists() or final.is_symlink():
            manifest_map[basin] = _verify_unit_equal(source, final)
            reused += 1
            continue
        competitors = [
            path
            for path in filter_root.glob(f"basin_{basin}.pending.*")
            if path.name != f"basin_{basin}.pending.{attempt}"
        ]
        if competitors:
            raise RuntimeError("a filter installation pending directory belongs to another attempt")
        pending = filter_root / f"basin_{basin}.pending.{attempt}"
        if pending.exists():
            _directory(pending, label="resumable pending filter unit")
            if not {path.name for path in pending.iterdir()}.issubset(EXPECTED_UNIT_NAMES):
                raise RuntimeError("pending filter unit has unexpected members")
            for path in pending.iterdir():
                _regular(path, label=f"pending member {path.name}")
                if not _same_file_content(source / path.name, path):
                    raise RuntimeError("pending filter unit differs from the admitted attempt")
        else:
            pending.mkdir()
        try:
            for name in sorted(EXPECTED_UNIT_NAMES):
                target = pending / name
                if not target.exists():
                    _stream_copy(source / name, target)
            if {path.name for path in pending.iterdir()} != EXPECTED_UNIT_NAMES:
                raise RuntimeError("completed pending filter unit has missing or extra members")
            if final.exists() or final.is_symlink():
                raise FileExistsError("filter unit destination appeared during installation")
            os.replace(pending, final)
            manifest_map[basin] = _verify_unit_equal(source, final)
            installed += 1
            if fail_after_unit is not None and installed >= fail_after_unit:
                raise RuntimeError("injected filter-installation interruption")
        except BaseException:
            # An exact pending unit is intentionally retained for the same admitted attempt.
            raise
    actual_names = {path.name for path in filter_root.iterdir()}
    if actual_names != {f"basin_{basin}" for basin in basins}:
        raise RuntimeError("result filter root has missing, extra, or pending units")
    rebinding = control / "filter_rebinding"
    seal_path = rebinding / "filter_rebinding.sealed.json"
    if rebinding.exists():
        _directory(rebinding, label="existing filter-rebinding control root")
        _verify_existing_seal(
            seal_path,
            admission_hash=admission_hash,
            migration_final_hash=migration_hash,
            basin_ids=basins,
            manifest_map=manifest_map,
        )
    else:
        pending_control = control / f"filter_rebinding.pending.{uuid.uuid4().hex}"
        pending_control.mkdir()
        try:
            seal = {
                "schema_version": "tukf09_455_filter_rebinding_seal_v1",
                "experiment_id": EXPERIMENT_ID,
                "status": "FILTER_REBINDING_INSTALLED_455_EVALUATION_HOLD",
                "ordered_basin_ids": basins,
                "unit_count": len(basins),
                "unit_file_count": len(basins) * 6,
                "unit_manifest_sha256_by_basin": manifest_map,
                "unit_manifest_map_sha256": _payload_hash(manifest_map),
                "training_admission_path": str(Path(training_admission_path).resolve()),
                "training_admission_sha256": admission_hash,
                "migration_final_manifest_path": str(final_migration_path.resolve()),
                "migration_final_manifest_sha256": migration_hash,
                "inherited_checkpoint_count": len(basins) * 256,
                "inherited_gradient_update_count": len(basins) * 248,
                "new_filter_optimization_count": 0,
                "new_filter_objective_count": 0,
                "new_filter_gradient_update_count": 0,
                "evaluation_access_count": 0,
            }
            with (pending_control / "filter_rebinding.sealed.json").open("xb") as handle:
                handle.write(_json_bytes(seal))
                handle.flush()
                os.fsync(handle.fileno())
            if rebinding.exists() or rebinding.is_symlink():
                raise FileExistsError("filter-rebinding control root appeared during sealing")
            os.replace(pending_control, rebinding)
        except BaseException:
            if pending_control.exists():
                shutil.rmtree(pending_control)
            raise
    return {
        "status": "FILTER_REBINDING_INSTALLED_455_EVALUATION_HOLD",
        "results_root": str(Path(results_root)),
        "unit_count": len(basins),
        "installed_unit_count": installed,
        "reused_unit_count": reused,
        "unit_file_count": len(basins) * 6,
        "new_filter_optimization_count": 0,
        "evaluation_access_count": 0,
    }


def _cli() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--migration-root", type=Path)
    parser.add_argument("--results-root", type=Path)
    parser.add_argument("--training-admission", type=Path)
    parser.add_argument("--authorize-filter-installation", action="store_true")
    args = parser.parse_args()
    result = install_rebound_filters(
        migration_root=args.migration_root,
        results_root=args.results_root,
        training_admission_path=args.training_admission,
        authorize=args.authorize_filter_installation,
    )
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli())
