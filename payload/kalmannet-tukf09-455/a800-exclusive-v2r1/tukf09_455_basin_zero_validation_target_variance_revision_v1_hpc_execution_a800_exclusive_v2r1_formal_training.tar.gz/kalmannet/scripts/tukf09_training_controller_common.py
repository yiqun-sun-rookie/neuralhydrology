"""Process and exact-manifest helpers for TUKF09 training controllers.

This module never loads model inputs.  It only validates the separately
admitted execution identity, manages one controller lock, launches atomic
training units, and verifies completed unit directories.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from typing import Any, Iterator, Mapping, Sequence
import uuid


ROOT = Path(__file__).resolve().parents[1]
EXPERIMENT_ID = "TUKF09_BACKPROPAGATION_VS_NEURAL_BACKWARD_TIME_CONFIRMATION_V1"
EXECUTION_SCHEMA = "tukf09_formal_training_execution_v1"
DEFAULT_EXECUTION_CONFIG = ROOT / "configs/tukf09_formal_training_execution_v1.json"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def canonical_json_bytes(value: Any) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
        + b"\n"
    )


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_json(path: Path) -> dict[str, Any]:
    def reject(token: str) -> None:
        raise ValueError(f"non-finite JSON token is forbidden: {token}")

    value = json.loads(Path(path).read_text(encoding="utf-8"), parse_constant=reject)
    if not isinstance(value, dict):
        raise ValueError(f"JSON object required: {path}")
    return value


def _resolve_project_path(text: str, *, project_root: Path = ROOT) -> Path:
    path = Path(text)
    if not path.is_absolute():
        path = project_root / path
    return path.resolve(strict=False)


def _regular_unlinked_file(path: Path) -> bool:
    return path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1


def load_execution_config(
    path: Path = DEFAULT_EXECUTION_CONFIG,
    *,
    project_root: Path = ROOT,
) -> dict[str, Any]:
    path = Path(path)
    config = _read_json(path)
    if config.get("schema_version") != EXECUTION_SCHEMA:
        raise ValueError("TUKF09 training execution schema changed")
    if config.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("TUKF09 training experiment identity changed")
    authorization = config.get("authorization")
    if not isinstance(authorization, dict) or (
        authorization.get("required_exact_text") != "授权正式训练"
        or authorization.get("formal_training") is not True
        or authorization.get("formal_evaluation") is not False
        or authorization.get("evaluation_prediction_generation") is not False
        or authorization.get("evaluation_metric_computation") is not False
    ):
        raise ValueError("TUKF09 training/evaluation authorization boundary changed")
    scientific = config.get("scientific_contract")
    preflight = config.get("independent_preflight_final_manifest")
    if not isinstance(scientific, dict) or not isinstance(preflight, dict):
        raise ValueError("TUKF09 frozen source identities are missing")
    for name, record in (("scientific contract", scientific), ("preflight", preflight)):
        source = _resolve_project_path(str(record.get("path", "")), project_root=project_root)
        expected = record.get("sha256")
        if not _regular_unlinked_file(source):
            raise FileNotFoundError(f"TUKF09 {name} is missing or linked: {source}")
        if not isinstance(expected, str) or len(expected) != 64 or sha256_file(source) != expected:
            raise RuntimeError(f"TUKF09 {name} hash mismatch")
    resources = config.get("resource_policy")
    if not isinstance(resources, dict):
        raise ValueError("TUKF09 resource policy is missing")
    workers = resources.get("filter_worker_count")
    if not isinstance(workers, int) or isinstance(workers, bool) or workers != 2:
        raise ValueError("TUKF09 filter worker count must remain exactly two")
    if resources.get("neural_model_parallelism") != 1:
        raise ValueError("TUKF09 neural models must run serially")
    if (
        resources.get("disable_cuda_matrix_multiplication_tensorfloat32") is not True
        or resources.get("disable_cudnn_tensorfloat32") is not True
    ):
        raise ValueError("TUKF09 TensorFloat32 must remain disabled")
    counts = config.get("completion_counts")
    expected_counts = {
        "filter_basin_units": 456,
        "filter_checkpoint_records": 116736,
        "filter_training_objective_calls": 116736,
        "filter_validation_objective_calls": 116736,
        "filter_gradient_updates": 113088,
        "neural_model_units": 9,
        "neural_checkpoints": 270,
        "evaluation_array_reads": 0,
        "evaluation_predictions": 0,
        "evaluation_metrics": 0,
    }
    if counts != expected_counts:
        raise ValueError("TUKF09 training completion counts changed")
    return config


def configured_results_root(
    config: Mapping[str, Any], *, project_root: Path = ROOT
) -> Path:
    paths = config.get("paths")
    if not isinstance(paths, Mapping):
        raise ValueError("TUKF09 execution paths are missing")
    return _resolve_project_path(str(paths.get("results_root", "")), project_root=project_root)


def require_fixed_results_root(
    requested: Path,
    config: Mapping[str, Any],
    *,
    project_root: Path = ROOT,
) -> Path:
    expected = configured_results_root(config, project_root=project_root)
    actual = Path(requested).resolve(strict=False)
    if actual != expected:
        raise ValueError("TUKF09 training output root differs from the fixed result root")
    return actual


def verify_unit_directory(
    unit_directory: Path,
    *,
    schema_version: str,
    unit_type: str,
    unit_id: str,
    expected_nonmanifest_count: int,
) -> dict[str, Any]:
    unit_directory = Path(unit_directory)
    if not unit_directory.is_dir() or unit_directory.is_symlink():
        raise FileNotFoundError(f"complete unlinked unit directory required: {unit_directory}")
    manifest_path = unit_directory / "manifest.sha256.json"
    if not _regular_unlinked_file(manifest_path):
        raise FileNotFoundError(f"unit manifest is missing or linked: {manifest_path}")
    manifest = _read_json(manifest_path)
    if manifest.get("schema_version") != schema_version:
        raise ValueError("unit manifest schema mismatch")
    if manifest.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("unit experiment identity mismatch")
    if manifest.get("unit_type") != unit_type or manifest.get("unit_id") != unit_id:
        raise ValueError("unit identity mismatch")
    files = manifest.get("files")
    if not isinstance(files, dict) or manifest.get("file_count") != expected_nonmanifest_count:
        raise ValueError("unit manifest file count mismatch")
    if len(files) != expected_nonmanifest_count:
        raise ValueError("unit manifest member count mismatch")
    expected_names = set(files) | {"manifest.sha256.json"}
    actual_names: set[str] = set()
    for member in unit_directory.rglob("*"):
        relative_name = member.relative_to(unit_directory).as_posix()
        if member.is_symlink():
            raise ValueError(f"linked unit member is forbidden: {relative_name}")
        if member.is_dir():
            continue
        if not member.is_file() or member.stat().st_nlink != 1:
            raise ValueError(f"non-regular unit member is forbidden: {relative_name}")
        actual_names.add(relative_name)
    if actual_names != expected_names:
        raise ValueError("unit directory has missing or extra members")
    for relative, record in files.items():
        if not isinstance(relative, str) or not relative or "\\" in relative:
            raise ValueError("invalid unit manifest member name")
        parts = Path(relative).parts
        if (
            Path(relative).is_absolute()
            or any(part in {"", ".", ".."} for part in parts)
            or relative == "manifest.sha256.json"
        ):
            raise ValueError("invalid unit manifest member name")
        if not isinstance(record, dict) or set(record) != {"sha256", "size_bytes"}:
            raise ValueError("invalid unit manifest member record")
        member = unit_directory.joinpath(*parts)
        if unit_directory.resolve(strict=False) not in (
            member.resolve(strict=False),
            *member.resolve(strict=False).parents,
        ):
            raise ValueError("unit manifest member escapes its directory")
        if not _regular_unlinked_file(member):
            raise FileNotFoundError(f"unit member is missing or linked: {relative}")
        if member.stat().st_size != record["size_bytes"] or sha256_file(member) != record["sha256"]:
            raise RuntimeError(f"unit member hash or size mismatch: {relative}")
    return manifest


@dataclass(frozen=True)
class ControllerOwner:
    controller: str
    execution_id: str
    process_id: int
    started_at_utc: str


@dataclass(frozen=True)
class TrainingPhaseOwner:
    schema_version: str
    experiment_id: str
    role: str
    execution_id: str
    process_id: int
    started_at_utc: str
    recovered_stale_lock: bool


def _path_exists(path: Path) -> bool:
    return os.path.lexists(os.fspath(path))


def _process_is_alive(process_id: int) -> bool:
    if not isinstance(process_id, int) or isinstance(process_id, bool) or process_id <= 0:
        return False
    if process_id == os.getpid():
        return True
    if os.name == "nt":
        return _windows_process_is_alive(process_id)
    try:
        os.kill(process_id, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def _windows_process_is_alive(process_id: int, *, kernel32: Any | None = None) -> bool:
    """Query Windows process state without sending a terminating signal."""

    if kernel32 is None:  # pragma: no cover - exercised on the registered Windows route
        import ctypes

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.OpenProcess.argtypes = [ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
        kernel32.OpenProcess.restype = ctypes.c_void_p
        kernel32.GetExitCodeProcess.argtypes = [
            ctypes.c_void_p,
            ctypes.POINTER(ctypes.c_ulong),
        ]
        kernel32.GetExitCodeProcess.restype = ctypes.c_int
        kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
        kernel32.CloseHandle.restype = ctypes.c_int
        get_last_error = ctypes.get_last_error
        code_factory = ctypes.c_ulong
    else:
        get_last_error = getattr(kernel32, "get_last_error", lambda: 5)

        class _Code:
            value = 0

        code_factory = _Code
    process_query_limited_information = 0x1000
    still_active = 259
    handle = kernel32.OpenProcess(
        process_query_limited_information, False, int(process_id)
    )
    if not handle:
        error = int(get_last_error())
        if error in {87, 1168}:  # invalid parameter / element not found
            return False
        return True  # access denial or an unknown error is conservatively active
    try:
        exit_code = code_factory()
        if not kernel32.GetExitCodeProcess(handle, exit_code):
            return True
        return int(exit_code.value) == still_active
    finally:
        kernel32.CloseHandle(handle)


def process_is_alive(process_id: int) -> bool:
    return _process_is_alive(process_id)


def _validate_phase_owner(path: Path) -> dict[str, Any]:
    if not path.is_dir() or path.is_symlink():
        raise RuntimeError("TUKF09 training phase lock is linked or invalid")
    if {member.name for member in path.iterdir()} != {"owner.json"}:
        raise RuntimeError("TUKF09 training phase lock member set changed")
    owner_path = path / "owner.json"
    if not _regular_unlinked_file(owner_path):
        raise RuntimeError("TUKF09 training phase owner is linked or invalid")
    raw = owner_path.read_bytes()
    owner = _read_json(owner_path)
    if raw != canonical_json_bytes(owner):
        raise RuntimeError("TUKF09 training phase owner is not canonical")
    if (
        set(owner)
        != {
            "schema_version",
            "experiment_id",
            "role",
            "execution_id",
            "process_id",
            "started_at_utc",
            "recovered_stale_lock",
        }
        or owner.get("schema_version") != "tukf09_training_phase_owner_v1"
        or owner.get("experiment_id") != EXPERIMENT_ID
        or owner.get("role")
        not in {"sequence", "filter", "neural", "seal", "independent"}
        or not isinstance(owner.get("execution_id"), str)
        or len(owner["execution_id"]) != 32
        or not isinstance(owner.get("process_id"), int)
        or isinstance(owner.get("process_id"), bool)
        or owner["process_id"] <= 0
        or not isinstance(owner.get("started_at_utc"), str)
        or not isinstance(owner.get("recovered_stale_lock"), bool)
    ):
        raise RuntimeError("TUKF09 training phase owner identity changed")
    return owner


@contextmanager
def training_phase_lock(
    control_root: Path,
    role: str,
    *,
    pid_is_alive: Any = _process_is_alive,
) -> Iterator[TrainingPhaseOwner]:
    """Hold the one mutation lock shared by training, sealing, and verification.

    A stale lock is recoverable only when its exact canonical owner record is
    intact and that process identifier is no longer alive.  A reused live
    process identifier is deliberately treated as active.
    """

    if role not in {"sequence", "filter", "neural", "seal", "independent"}:
        raise ValueError("unknown TUKF09 training phase role")
    control = Path(control_root)
    control.mkdir(parents=True, exist_ok=True)
    lock = control / ".training_phase.lock"
    recovered = False
    try:
        lock.mkdir()
    except FileExistsError:
        prior = _validate_phase_owner(lock)
        if bool(pid_is_alive(int(prior["process_id"]))):
            raise RuntimeError("another TUKF09 training phase mutation is active")
        raise RuntimeError(
            "stale TUKF09 training phase lock requires manual global process audit"
        )
    owner = TrainingPhaseOwner(
        schema_version="tukf09_training_phase_owner_v1",
        experiment_id=EXPERIMENT_ID,
        role=role,
        execution_id=uuid.uuid4().hex,
        process_id=os.getpid(),
        started_at_utc=utc_now(),
        recovered_stale_lock=recovered,
    )
    owner_path = lock / "owner.json"
    try:
        with owner_path.open("xb") as handle:
            handle.write(canonical_json_bytes(owner.__dict__))
            handle.flush()
            os.fsync(handle.fileno())
        yield owner
    finally:
        try:
            if _validate_phase_owner(lock) != owner.__dict__:
                raise RuntimeError("TUKF09 training phase lock identity changed")
            owner_path.unlink()
            lock.rmdir()
        except FileNotFoundError:
            raise RuntimeError("TUKF09 training phase lock disappeared")


def reject_post_training_outputs(output_root: Path) -> None:
    """Training mutation is forbidden after selection or independent output."""

    root = Path(output_root)
    for name in ("selection", "independent"):
        if _path_exists(root / name):
            raise RuntimeError(
                f"TUKF09 training mutation is forbidden after {name} output exists"
            )


@contextmanager
def training_controller_locks(
    output_root: Path, controller: str
) -> Iterator[tuple[TrainingPhaseOwner, ControllerOwner]]:
    """Acquire the shared phase lock before the controller-specific lock."""

    if controller not in {"filter", "neural"}:
        raise ValueError("unknown TUKF09 training controller")
    root = Path(output_root)
    control = root / "control"
    with training_phase_lock(control, controller) as phase_owner:
        reject_post_training_outputs(root)
        with controller_lock(control, controller) as controller_owner:
            yield phase_owner, controller_owner


def _validate_controller_owner(lock: Path, controller: str) -> dict[str, Any]:
    if not lock.is_dir() or lock.is_symlink():
        raise RuntimeError(f"TUKF09 {controller} controller lock is linked or invalid")
    if {member.name for member in lock.iterdir()} != {"owner.json"}:
        raise RuntimeError(f"TUKF09 {controller} controller lock member set changed")
    owner_path = lock / "owner.json"
    if not _regular_unlinked_file(owner_path):
        raise RuntimeError(f"TUKF09 {controller} controller owner is linked or invalid")
    raw = owner_path.read_bytes()
    owner = _read_json(owner_path)
    if raw != canonical_json_bytes(owner):
        raise RuntimeError(f"TUKF09 {controller} controller owner is not canonical")
    if (
        set(owner) != {"controller", "execution_id", "process_id", "started_at_utc"}
        or owner.get("controller") != controller
        or not isinstance(owner.get("execution_id"), str)
        or len(owner["execution_id"]) != 32
        or not isinstance(owner.get("process_id"), int)
        or isinstance(owner.get("process_id"), bool)
        or owner["process_id"] <= 0
        or not isinstance(owner.get("started_at_utc"), str)
    ):
        raise RuntimeError(f"TUKF09 {controller} controller owner identity changed")
    return owner


@contextmanager
def controller_lock(
    control_root: Path,
    controller: str,
    *,
    pid_is_alive: Any = _process_is_alive,
) -> Iterator[ControllerOwner]:
    control_root = Path(control_root)
    if controller not in {"filter", "neural"}:
        raise ValueError("unknown TUKF09 controller")
    control_root.mkdir(parents=True, exist_ok=True)
    lock = control_root / f".{controller}_controller.lock"
    execution_id = uuid.uuid4().hex
    owner = ControllerOwner(controller, execution_id, os.getpid(), utc_now())
    try:
        lock.mkdir()
    except FileExistsError:
        prior = _validate_controller_owner(lock, controller)
        if bool(pid_is_alive(int(prior["process_id"]))):
            raise RuntimeError(
                f"TUKF09 {controller} controller lock already exists and owner is active"
            )
        if _validate_controller_owner(lock, controller) != prior:
            raise RuntimeError(
                f"TUKF09 stale {controller} controller owner changed during recovery"
            )
        (lock / "owner.json").unlink()
        lock.rmdir()
        try:
            lock.mkdir()
        except FileExistsError as exc:
            raise RuntimeError(
                f"TUKF09 {controller} controller lock already exists after stale recovery"
            ) from exc
    owner_path = lock / "owner.json"
    try:
        owner_path.write_bytes(canonical_json_bytes(owner.__dict__))
        yield owner
    finally:
        # Remove only the exact two paths owned by this live context.  Unknown
        # content is a hard stop and is deliberately left for manual audit.
        try:
            if set(path.name for path in lock.iterdir()) != {"owner.json"}:
                raise RuntimeError(f"unexpected member appeared in controller lock: {lock}")
            recorded = _validate_controller_owner(lock, controller)
            if recorded != owner.__dict__:
                raise RuntimeError(f"controller lock identity changed: {lock}")
            owner_path.unlink()
            lock.rmdir()
        except FileNotFoundError:
            raise RuntimeError(f"controller lock disappeared: {lock}")


def append_controller_event(log_path: Path, event: Mapping[str, Any]) -> None:
    log_path = Path(log_path)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    payload = canonical_json_bytes(dict(event))
    descriptor = os.open(log_path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
    try:
        os.write(descriptor, payload)
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def run_unit_command(
    command: Sequence[str],
    *,
    timeout_seconds: int,
    environment: Mapping[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    if not command or Path(command[0]).name.lower() not in {
        Path(sys.executable).name.lower(),
        "python",
        "python.exe",
    }:
        raise ValueError("TUKF09 unit command must use the admitted Python executable")
    lowered = " ".join(str(part).lower() for part in command)
    if any(token in lowered for token in ("evaluation", "prediction", "metric")):
        raise PermissionError("training unit command contains an evaluation surface")
    return subprocess.run(
        list(command),
        check=False,
        capture_output=True,
        text=True,
        timeout=timeout_seconds,
        env=None if environment is None else dict(environment),
    )


def resource_snapshot(output_parent: Path) -> dict[str, Any]:
    disk = shutil.disk_usage(Path(output_parent))
    result: dict[str, Any] = {
        "disk_free_gib": disk.free / (1024**3),
        "logical_processor_count": os.cpu_count(),
    }
    try:
        import psutil

        memory = psutil.virtual_memory()
        result["system_memory_available_gib"] = memory.available / (1024**3)
        result["system_memory_total_gib"] = memory.total / (1024**3)
    except ImportError:
        result["system_memory_available_gib"] = None
        result["system_memory_total_gib"] = None
    return result


__all__ = [
    "ControllerOwner",
    "TrainingPhaseOwner",
    "EXPERIMENT_ID",
    "append_controller_event",
    "canonical_json_bytes",
    "configured_results_root",
    "controller_lock",
    "load_execution_config",
    "process_is_alive",
    "require_fixed_results_root",
    "resource_snapshot",
    "reject_post_training_outputs",
    "run_unit_command",
    "sha256_file",
    "training_controller_locks",
    "training_phase_lock",
    "utc_now",
    "verify_unit_directory",
]
