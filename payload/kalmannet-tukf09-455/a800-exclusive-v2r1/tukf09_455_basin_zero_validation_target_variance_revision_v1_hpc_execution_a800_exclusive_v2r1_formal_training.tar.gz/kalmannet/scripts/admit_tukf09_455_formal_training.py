"""Create the immutable technical admission for 455-basin formal training."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import os
from pathlib import Path
import re
import subprocess
import sys
from time import monotonic
from typing import Any, Mapping

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import tukf09_455_training_common as common
from scripts import tukf09_455_training_profile as profile


canonical_json_bytes = common.canonical_json_bytes
_COUNT = re.compile(r"(?P<count>[0-9]+)\s+(?P<kind>passed|failed|errors?|skipped)\b", re.I)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _hex_digest(value: Any) -> bool:
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


def _zero_ledger(value: Any) -> dict[str, int]:
    expected = {
        "evaluation_array_reads": 0,
        "evaluation_predictions": 0,
        "evaluation_metrics": 0,
        "evaluation_outputs": 0,
    }
    if value != expected:
        raise PermissionError("formal training evidence records evaluation access")
    return expected


def build_training_admission_payload(
    *,
    evidence: Mapping[str, Any],
    execution_config_record: Mapping[str, Any],
    executable_records: Mapping[str, Mapping[str, Any]],
    test_evidence: Mapping[str, Any],
    runtime_environment_identity: Mapping[str, Any],
    tensorfloat32_state: Mapping[str, Any],
    execution: Mapping[str, Any],
    admitted_at_utc: str,
) -> dict[str, Any]:
    migration = evidence.get("filter_migration_final_manifest", {})
    if not _hex_digest(migration.get("sha256")):
        raise RuntimeError("independently sealed filter migration is required")
    evaluation = evidence.get("evaluation_identity", {})
    if (
        evaluation.get("arrays_loaded") is not False
        or evaluation.get("member_count") != profile.EVALUATION_IDENTITY_MEMBER_COUNT
        or evaluation.get("identity_only_sha256") != profile.EVALUATION_IDENTITY_SHA256
    ):
        raise PermissionError("evaluation identity boundary changed")
    ledger = _zero_ledger(evidence.get("access_ledger"))
    population = evidence.get("population", {})
    if (
        population.get("ordered_basin_count") != profile.ORDERED_BASIN_COUNT
        or population.get("ordered_newline_sha256")
        != profile.ORDERED_BASIN_NEWLINE_SHA256
        or population.get("compact_json_sha256")
        != profile.ORDERED_BASIN_COMPACT_JSON_SHA256
    ):
        raise RuntimeError("formal training population identity changed")
    if test_evidence.get("result") != "PASS":
        raise RuntimeError("required isolated test suite did not pass")
    if tensorfloat32_state != {"cuda_matmul": False, "cudnn": False}:
        raise RuntimeError("TensorFloat32 must be disabled before admission")
    completion = execution.get("completion_counts", {})
    expected_completion = {
        "rebound_filter_units": 455,
        "new_filter_training_units": 0,
        "inherited_filter_checkpoint_records": 116480,
        "new_filter_training_objective_calls": 0,
        "new_filter_validation_objective_calls": 0,
        "new_filter_gradient_updates": 0,
        "neural_model_units": 9,
        "neural_checkpoints": 270,
        "evaluation_array_reads": 0,
        "evaluation_predictions": 0,
        "evaluation_metrics": 0,
        "evaluation_outputs": 0,
    }
    if completion != expected_completion:
        raise RuntimeError("formal training completion contract changed")
    scientific = evidence.get("scientific_contract", {})
    preflight = evidence.get("independent_preflight_final_manifest", {})
    payload: dict[str, Any] = {
        "schema_version": profile.TRAINING_ADMISSION_SCHEMA,
        "experiment_id": profile.EXPERIMENT_ID,
        "status": (
            "NEURAL_TRAINING_ADMITTED_FILTER_REBINDING_INSTALLATION_PENDING_"
            "EVALUATION_HOLD"
        ),
        "admitted_at_utc": admitted_at_utc,
        "formal_evaluation_authorized": False,
        "phase_scope": {
            "filter_rebinding_installation_authorized": True,
            "new_filter_training_authorized": False,
            "neural_training_authorized": True,
            "validation_checkpoint_selection_authorized": True,
            "training_selection_sealing_authorized": True,
            "formal_evaluation_access_admitted": False,
        },
        "scientific_contract_sha256": scientific.get("sha256"),
        "preflight_final_manifest_sha256": preflight.get("sha256"),
        "scientific_contract": dict(scientific),
        "independent_preflight_final_manifest": dict(preflight),
        "filter_migration_final_manifest": dict(migration),
        "authorization": dict(evidence.get("authorization", {})),
        "execution_config": dict(execution_config_record),
        "executables": {
            str(key): dict(value) for key, value in executable_records.items()
        },
        "test_evidence": dict(test_evidence),
        "runtime_environment_identity": dict(runtime_environment_identity),
        "tensorfloat32": dict(tensorfloat32_state),
        "resource_policy": dict(execution.get("resource_policy", {})),
        "output_tree": dict(execution.get("paths", {})),
        "population": dict(population),
        "parameter_snapshot": dict(evidence.get("parameter_snapshot", {})),
        "training_validation_semantic_identity": dict(
            evidence.get("training_validation_semantic_identity", {})
        ),
        "evaluation_identity": dict(evaluation),
        "access_ledger": ledger,
        "expected_completion": expected_completion,
    }
    payload["training_admission_record_sha256"] = hashlib.sha256(
        canonical_json_bytes(payload)
    ).hexdigest()
    return payload


def _file_record(path: Path, root: Path) -> dict[str, Any]:
    source = common.require_regular_unlinked_file(
        path, label="formal training admission input", stop_at=root
    )
    return {
        "path": source.relative_to(root).as_posix(),
        "sha256": common.sha256_file(source),
    }


def _executable_records(
    root: Path, relatives: list[str]
) -> dict[str, dict[str, Any]]:
    records: dict[str, dict[str, Any]] = {}
    for relative in relatives:
        source = common.require_regular_unlinked_file(
            root / relative, label="required training executable", stop_at=root
        )
        records[relative] = {
            "sha256": common.sha256_file(source),
            "size_bytes": source.stat().st_size,
        }
    return records


def _parse_counts(stdout: str, stderr: str) -> dict[str, int]:
    lines = [
        line
        for line in (stdout + "\n" + stderr).splitlines()
        if _COUNT.search(line)
    ]
    if not lines:
        raise RuntimeError("required pytest output lacks a summary")
    result = {"passed": 0, "failed": 0, "error": 0, "skipped": 0}
    for match in _COUNT.finditer(lines[-1]):
        kind = match.group("kind").lower()
        if kind == "errors":
            kind = "error"
        result[kind] += int(match.group("count"))
    return result


def run_required_tests(
    execution: Mapping[str, Any], *, project_root: Path
) -> dict[str, Any]:
    policy = execution.get("required_test_policy", {})
    files = policy.get("pytest_files")
    arguments = policy.get("pytest_trailing_arguments")
    environment = policy.get("environment")
    if not isinstance(files, list) or not isinstance(arguments, list) or not isinstance(environment, dict):
        raise RuntimeError("formal training required-test policy changed")
    for relative in files:
        common.require_regular_unlinked_file(
            project_root / str(relative),
            label="required formal-training pytest file",
            stop_at=project_root,
        )
    pytest_file_records = {
        str(relative): {
            "sha256": common.sha256_file(project_root / str(relative)),
            "size_bytes": (project_root / str(relative)).stat().st_size,
        }
        for relative in files
    }
    command = [sys.executable, "-B", "-m", "pytest", *files, *arguments]
    child_environment = os.environ.copy()
    child_environment.update({str(key): str(value) for key, value in environment.items()})
    started = monotonic()
    completed = subprocess.run(
        command,
        cwd=project_root,
        env=child_environment,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    duration = monotonic() - started
    counts = _parse_counts(completed.stdout, completed.stderr)
    if completed.returncode != 0 or counts["failed"] or counts["error"] or counts["skipped"]:
        raise RuntimeError("required isolated formal-training tests did not pass exactly")
    return {
        "result": "PASS",
        "command": command,
        "exit_code": int(completed.returncode),
        "passed_count": counts["passed"],
        "failed_count": counts["failed"],
        "error_count": counts["error"],
        "skipped_count": counts["skipped"],
        "duration_seconds": duration,
        "stdout": completed.stdout,
        "stderr": completed.stderr,
        "stdout_sha256": hashlib.sha256(completed.stdout.encode("utf-8")).hexdigest(),
        "stderr_sha256": hashlib.sha256(completed.stderr.encode("utf-8")).hexdigest(),
        "environment_overrides": dict(environment),
        "pytest_file_records": pytest_file_records,
    }


def _disable_tensorfloat32() -> dict[str, bool]:
    try:
        import torch
    except ImportError as exc:
        raise RuntimeError("PyTorch is required for formal training admission") from exc
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    state = {
        "cuda_matmul": bool(torch.backends.cuda.matmul.allow_tf32),
        "cudnn": bool(torch.backends.cudnn.allow_tf32),
    }
    if state != {"cuda_matmul": False, "cudnn": False}:
        raise RuntimeError("TensorFloat32 could not be disabled")
    return state


def admit_formal_training(
    *,
    authorize_admission: bool,
    run_required_test_suite: bool,
    project_root: Path = ROOT,
    admitted_at_utc: str | None = None,
) -> dict[str, Any]:
    # The mutation gate precedes every filesystem read.
    if authorize_admission is not True:
        raise PermissionError("explicit formal training admission is required")
    if run_required_test_suite is not True:
        raise PermissionError("formal training admission requires its isolated test suite")
    root = Path(project_root)
    contract_path = root / profile.CONTRACT_RELATIVE
    preflight_path = root / profile.PREFLIGHT_FINAL_RELATIVE
    authorization_path = root / profile.AUTHORIZATION_RELATIVE
    execution_path = root / profile.FORMAL_TRAINING_CONFIG_RELATIVE
    migration_path = root / profile.FILTER_MIGRATION_FINAL_RELATIVE
    output = root / profile.OUTPUT_RELATIVE
    if common.path_exists_including_broken_link(output):
        raise FileExistsError("formal result root must remain absent before admission")
    context = common.verify_preflight_for_revision_training(
        contract_path,
        preflight_path,
        authorization_path,
        output,
        require_output_absent=True,
        recompute_training_validation_semantics=False,
        verify_all_raw_source_bytes=False,
    )
    migration = common.read_json_strict(migration_path)
    if (
        migration.get("schema_version") != "tukf09_455_filter_migration_final_manifest_v1"
        or migration.get("experiment_id") != profile.EXPERIMENT_ID
        or migration.get("status")
        != "FILTER_MIGRATION_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
    ):
        raise RuntimeError("independently sealed filter migration identity changed")
    execution = common.read_json_strict(execution_path)
    relatives = execution.get("required_executables")
    if relatives != list(common.REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS):
        raise RuntimeError("formal training executable list changed")
    tests = run_required_tests(execution, project_root=root)
    authorization = context.authorization
    final = common.read_json_strict(preflight_path)
    evidence = {
        "scientific_contract": _file_record(contract_path, root),
        "independent_preflight_final_manifest": _file_record(preflight_path, root),
        "filter_migration_final_manifest": _file_record(migration_path, root),
        "authorization": {
            "path": profile.AUTHORIZATION_RELATIVE.as_posix(),
            "file_sha256": authorization.authorization_file_sha256,
            "record_sha256": authorization.record["authorization_record_sha256"],
        },
        "population": {
            "ordered_basin_count": 455,
            "ordered_newline_sha256": profile.ORDERED_BASIN_NEWLINE_SHA256,
            "compact_json_sha256": profile.ORDERED_BASIN_COMPACT_JSON_SHA256,
        },
        "parameter_snapshot": {
            "shape": list(profile.PARAMETER_SHAPE),
            "sha256": final["files"]["parameters_only.npz"]["sha256"],
        },
        "training_validation_semantic_identity": {
            "member_count": profile.TRAINING_VALIDATION_IDENTITY_MEMBER_COUNT,
            "identity_only_sha256": profile.TRAINING_VALIDATION_IDENTITY_SHA256,
        },
        "evaluation_identity": {
            "member_count": profile.EVALUATION_IDENTITY_MEMBER_COUNT,
            "identity_only_sha256": profile.EVALUATION_IDENTITY_SHA256,
            "arrays_loaded": False,
        },
        "access_ledger": dict(context.access_ledger),
    }
    payload = build_training_admission_payload(
        evidence=evidence,
        execution_config_record=_file_record(execution_path, root),
        executable_records=_executable_records(root, relatives),
        test_evidence=tests,
        runtime_environment_identity=common.runtime_environment_identity(),
        tensorfloat32_state=_disable_tensorfloat32(),
        execution=execution,
        admitted_at_utc=admitted_at_utc or _utc_now(),
    )
    common.atomic_write_json_exclusive(root / profile.ADMISSION_RELATIVE, payload)
    return payload


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--authorize-admission", action="store_true")
    parser.add_argument("--run-required-test-suite", action="store_true")
    return parser


def main() -> None:
    args = _parser().parse_args()
    record = admit_formal_training(
        authorize_admission=bool(args.authorize_admission),
        run_required_test_suite=bool(args.run_required_test_suite),
    )
    print(record["status"])


if __name__ == "__main__":
    main()
