"""Independently verify and seal installed 455-basin rebound-filter units."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
from pathlib import Path
from typing import Any, Mapping, Sequence


ROOT = Path(__file__).resolve().parent.parent
EXPERIMENT_ID = "TUKF09_455_BASIN_ZERO_VALIDATION_TARGET_VARIANCE_REVISION_V1"
UNIT_NAMES = {
    "identity.json",
    "history.npz",
    "selection.json",
    "access_ledger.json",
    "migration_provenance.json",
    "manifest.sha256.json",
}


def _reject(value: str) -> None:
    raise ValueError(f"non-finite JSON is forbidden: {value}")


def _pairs(pairs: Sequence[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def _json_bytes(payload: Any) -> bytes:
    return (
        json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
        + b"\n"
    )


def _hash(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _record(path: Path) -> dict[str, object]:
    return {"sha256": _hash(path), "size_bytes": Path(path).stat().st_size}


def _payload_hash(payload: Any) -> str:
    return hashlib.sha256(_json_bytes(payload)[:-1]).hexdigest()


def _reparse(path: Path) -> bool:
    return bool(getattr(Path(path).lstat(), "st_file_attributes", 0) & 0x400)


def _regular(path: Path, *, label: str) -> None:
    target = Path(path)
    if target.is_symlink() or _reparse(target) or not target.is_file():
        raise RuntimeError(f"{label} must be a regular non-reparse file")
    if target.stat().st_nlink != 1:
        raise RuntimeError(f"{label} is a hard link")


def _directory(path: Path, *, label: str) -> None:
    target = Path(path)
    if target.is_symlink() or _reparse(target) or not target.is_dir():
        raise RuntimeError(f"{label} must be a regular non-reparse directory")


def _read(path: Path) -> Mapping[str, Any]:
    _regular(path, label=f"JSON member {path}")
    content = Path(path).read_bytes()
    try:
        payload = json.loads(
            content.decode("utf-8"),
            object_pairs_hook=_pairs,
            parse_constant=_reject,
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"invalid JSON: {path}") from exc
    if not isinstance(payload, dict) or content != _json_bytes(payload):
        raise ValueError(f"JSON member is not a canonical object: {path}")
    return payload


def _migration_final(root: Path) -> tuple[Mapping[str, Any], str]:
    _directory(root, label="migration root")
    final_path = root / "independent/manifest.final.sha256.json"
    audit_path = root / "independent/independent_audit.json"
    final = _read(final_path)
    audit = _read(audit_path)
    if (
        final.get("schema_version") != "tukf09_455_filter_migration_final_manifest_v1"
        or final.get("status") != "FILTER_MIGRATION_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
        or audit.get("status") != "FILTER_MIGRATION_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
        or audit.get("evaluation_access_count") != 0
    ):
        raise RuntimeError("migration final seal changed")
    actual = {
        path.relative_to(root).as_posix(): _record(path)
        for path in sorted(root.rglob("*"))
        if path.is_file() and path != final_path
    }
    if final.get("file_count") != len(actual) or final.get("files") != actual:
        raise RuntimeError("migration final manifest differs from files")
    return final, _hash(final_path)


def _migration_reference(admission: Mapping[str, Any]) -> Mapping[str, Any]:
    for key in (
        "migration_final_manifest",
        "filter_migration_final_manifest",
        "independent_filter_migration_final_manifest",
    ):
        value = admission.get(key)
        if isinstance(value, dict):
            return value
    raise RuntimeError("training admission lacks a migration-final reference")


def _admission(path: Path, migration_root: Path, migration_hash: str) -> tuple[Mapping[str, Any], str]:
    payload = _read(path)
    if (
        payload.get("schema_version") != "tukf09_455_training_admission_v1"
        or payload.get("experiment_id") != EXPERIMENT_ID
        or payload.get("status")
        != "NEURAL_TRAINING_ADMITTED_FILTER_REBINDING_INSTALLATION_PENDING_EVALUATION_HOLD"
    ):
        raise PermissionError("training admission changed")
    ledger = payload.get("access_ledger", {})
    if not isinstance(ledger, dict) or any(
        ledger.get(name) != 0
        for name in (
            "evaluation_array_reads",
            "evaluation_predictions",
            "evaluation_metrics",
            "evaluation_outputs",
        )
    ):
        raise PermissionError("training admission records evaluation access")
    reference = _migration_reference(payload)
    reference_path = Path(str(reference.get("path")))
    if not reference_path.is_absolute():
        # Resolve project-relative references from the repository containing scripts/.
        reference_path = Path(__file__).resolve().parent.parent / reference_path
    expected_path = migration_root / "independent/manifest.final.sha256.json"
    if reference_path.resolve(strict=False) != expected_path.resolve(strict=False) or reference.get(
        "sha256"
    ) != migration_hash:
        raise RuntimeError("training admission migration binding changed")
    return payload, _hash(path)


def _basins(
    admission: Mapping[str, Any], migration_root: Path, expected: Sequence[str] | None
) -> list[str]:
    if expected is not None:
        values = [str(value) for value in expected]
    else:
        values = [str(value) for value in admission.get("population", {}).get("ordered_basin_ids", [])]
        if not values:
            values = [
                str(value)
                for value in _read(migration_root / "migration_summary.json").get("ordered_basin_ids", [])
            ]
    if len(values) != len(set(values)) or "08202700" in values:
        raise RuntimeError("filter installation population changed")
    if expected is None and len(values) != 455:
        raise RuntimeError("production filter verification requires exactly 455 basins")
    return values


def _verify_initialized_production_root(
    results_root: Path,
    training_admission_path: Path,
    admission: Mapping[str, Any],
) -> None:
    from scripts import tukf09_455_training_common as common
    from scripts import tukf09_455_training_profile as profile

    execution = ROOT / profile.FORMAL_TRAINING_CONFIG_RELATIVE
    verified = common.load_and_verify_training_admission(
        training_admission_path,
        execution,
        tuple(ROOT / relative for relative in common.REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS),
    )
    if dict(verified) != dict(admission):
        raise RuntimeError("installation verifier admission differs from production verification")
    common.verify_initialized_training_root(
        output_root=results_root,
        config_path=ROOT / profile.CONTRACT_RELATIVE,
        authorization=ROOT / profile.AUTHORIZATION_RELATIVE,
        execution_config=execution,
        training_admission=training_admission_path,
        training_admission_record=verified,
    )


def _same(left: Path, right: Path) -> bool:
    return left.stat().st_size == right.stat().st_size and _hash(left) == _hash(right)


def _unit(source: Path, target: Path, basin: str) -> str:
    _directory(source, label="staged unit")
    _directory(target, label="installed unit")
    if {path.name for path in source.iterdir()} != UNIT_NAMES or {
        path.name for path in target.iterdir()
    } != UNIT_NAMES:
        raise RuntimeError("staged or installed unit member set changed")
    for name in sorted(UNIT_NAMES):
        left = source / name
        right = target / name
        _regular(left, label=f"staged member {name}")
        _regular(right, label=f"installed member {name}")
        if not _same(left, right):
            raise RuntimeError(f"installed member differs from staged member: {name}")
        if (left.stat().st_dev, left.stat().st_ino) == (right.stat().st_dev, right.stat().st_ino):
            raise RuntimeError(f"installed member aliases staged member: {name}")
    identity = _read(target / "identity.json")
    selection = _read(target / "selection.json")
    ledger = _read(target / "access_ledger.json")
    provenance = _read(target / "migration_provenance.json")
    manifest = _read(target / "manifest.sha256.json")
    if (
        identity.get("experiment_id") != EXPERIMENT_ID
        or identity.get("unit_id") != basin
        or selection.get("status") != "FILTER_BASIN_REBOUND_FROM_VERIFIED_PARENT"
        or selection.get("unit_id") != basin
        or provenance.get("unit_id") != basin
        or manifest.get("schema_version") != "tukf09_455_rebound_filter_unit_manifest_v1"
        or manifest.get("unit_id") != basin
        or ledger.get("new_filter_optimization_count") != 0
        or any(
            ledger.get(name) != 0
            for name in (
                "evaluation_array_read_count",
                "evaluation_prediction_count",
                "evaluation_metric_count",
                "evaluation_output_write_count",
            )
        )
    ):
        raise RuntimeError("installed unit identity, status, or access ledger changed")
    return _hash(target / "manifest.sha256.json")


def _scope_records(results_root: Path, basins: Sequence[str], include_audit: bool) -> dict[str, Any]:
    paths: list[Path] = []
    for basin in basins:
        paths.extend(
            sorted((results_root / "filter" / f"basin_{basin}").iterdir(), key=lambda path: path.name)
        )
    rebinding = results_root / "control/filter_rebinding"
    paths.append(rebinding / "filter_rebinding.sealed.json")
    if include_audit:
        paths.append(rebinding / "independent/independent_audit.json")
    return {path.relative_to(results_root).as_posix(): _record(path) for path in paths}


def _verify_existing_final(results_root: Path, basins: Sequence[str]) -> Mapping[str, Any]:
    independent = results_root / "control/filter_rebinding/independent"
    audit = _read(independent / "independent_audit.json")
    final = _read(independent / "manifest.final.sha256.json")
    if (
        audit.get("schema_version") != "tukf09_455_filter_installation_independent_audit_v1"
        or audit.get("status") != "FILTER_REBINDING_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
        or final.get("schema_version") != "tukf09_455_filter_installation_final_manifest_v1"
        or final.get("status") != "FILTER_REBINDING_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
    ):
        raise RuntimeError("installation independent seal identity changed")
    files = _scope_records(results_root, basins, include_audit=True)
    if final.get("file_count") != len(files) or final.get("files") != files:
        raise RuntimeError("installation independent final manifest changed")
    return audit


def _write(path: Path, content: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as handle:
        handle.write(content)
        handle.flush()
        os.fsync(handle.fileno())


def verify_filter_installation_independently(
    *,
    migration_root: Path,
    results_root: Path,
    training_admission_path: Path,
    authorize: bool,
    publish: bool,
    expected_basin_ids: Sequence[str] | None = None,
    fail_after_write: int | None = None,
) -> dict[str, object]:
    if authorize is not True:
        raise PermissionError("independent filter-installation verification requires authorization")
    migration_root = Path(migration_root)
    results_root = Path(results_root)
    _directory(results_root, label="initialized result root")
    _, migration_hash = _migration_final(migration_root)
    admission, admission_hash = _admission(Path(training_admission_path), migration_root, migration_hash)
    if expected_basin_ids is None:
        _verify_initialized_production_root(
            results_root, Path(training_admission_path), admission
        )
    basins = _basins(admission, migration_root, expected_basin_ids)
    staged_root = migration_root / "units"
    installed_root = results_root / "filter"
    _directory(staged_root, label="staged units root")
    _directory(installed_root, label="installed filter root")
    expected_names = {f"basin_{basin}" for basin in basins}
    if {path.name for path in staged_root.iterdir()} != expected_names or {
        path.name for path in installed_root.iterdir()
    } != expected_names:
        raise RuntimeError("staged or installed filter population changed")
    before = {
        basin: _hash(staged_root / f"basin_{basin}" / "manifest.sha256.json") for basin in basins
    }
    installed: dict[str, str] = {}
    for basin in basins:
        installed[basin] = _unit(
            staged_root / f"basin_{basin}",
            installed_root / f"basin_{basin}",
            basin,
        )
    if before != installed:
        raise RuntimeError("installed unit-manifest mapping differs from migration staging")
    seal_path = results_root / "control/filter_rebinding/filter_rebinding.sealed.json"
    seal = _read(seal_path)
    if (
        seal.get("schema_version") != "tukf09_455_filter_rebinding_seal_v1"
        or seal.get("experiment_id") != EXPERIMENT_ID
        or seal.get("status") != "FILTER_REBINDING_INSTALLED_455_EVALUATION_HOLD"
        or seal.get("ordered_basin_ids") != basins
        or seal.get("unit_count") != len(basins)
        or seal.get("unit_file_count") != len(basins) * 6
        or seal.get("unit_manifest_sha256_by_basin") != installed
        or seal.get("unit_manifest_map_sha256") != _payload_hash(installed)
        or seal.get("training_admission_sha256") != admission_hash
        or seal.get("migration_final_manifest_sha256") != migration_hash
        or seal.get("new_filter_optimization_count") != 0
        or seal.get("evaluation_access_count") != 0
    ):
        raise RuntimeError("filter-rebinding installation seal changed")
    after = {
        basin: _hash(staged_root / f"basin_{basin}" / "manifest.sha256.json") for basin in basins
    }
    if before != after:
        raise RuntimeError("migration staging changed during installation verification")
    independent = results_root / "control/filter_rebinding/independent"
    result = {
        "status": "FILTER_REBINDING_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD",
        "results_root": str(results_root),
        "unit_count": len(basins),
        "unit_file_count": len(basins) * 6,
        "new_filter_optimization_count": 0,
        "evaluation_access_count": 0,
    }
    if independent.exists():
        audit = _verify_existing_final(results_root, basins)
        if audit.get("unit_count") != len(basins):
            raise RuntimeError("existing installation audit count changed")
        return result
    if not publish:
        return result
    attempt = hashlib.sha256(f"{admission_hash}:{migration_hash}".encode("ascii")).hexdigest()[:20]
    pending = independent.with_name(f"independent.pending.{attempt}")
    if pending.exists() or pending.is_symlink():
        raise RuntimeError("an incomplete independent installation seal already exists")
    writes = 0
    try:
        pending.mkdir()
        audit = {
            "schema_version": "tukf09_455_filter_installation_independent_audit_v1",
            "experiment_id": EXPERIMENT_ID,
            "status": result["status"],
            "unit_count": len(basins),
            "unit_file_count": len(basins) * 6,
            "unit_manifest_map_sha256": _payload_hash(installed),
            "migration_unit_manifest_map_sha256_before": _payload_hash(before),
            "migration_unit_manifest_map_sha256_after": _payload_hash(after),
            "training_admission_sha256": admission_hash,
            "migration_final_manifest_sha256": migration_hash,
            "new_filter_optimization_count": 0,
            "evaluation_access_count": 0,
        }
        _write(pending / "independent_audit.json", _json_bytes(audit))
        writes += 1
        if fail_after_write == writes:
            raise RuntimeError("injected installation-audit failure")
        files = _scope_records(results_root, basins, include_audit=False)
        files[
            "control/filter_rebinding/independent/independent_audit.json"
        ] = _record(pending / "independent_audit.json")
        final = {
            "schema_version": "tukf09_455_filter_installation_final_manifest_v1",
            "experiment_id": EXPERIMENT_ID,
            "status": result["status"],
            "file_count": len(files),
            "files": files,
        }
        _write(pending / "manifest.final.sha256.json", _json_bytes(final))
        writes += 1
        if fail_after_write == writes:
            raise RuntimeError("injected installation-audit failure")
        if independent.exists() or independent.is_symlink():
            raise FileExistsError("independent installation seal appeared during publication")
        os.replace(pending, independent)
        _verify_existing_final(results_root, basins)
        return result
    except BaseException:
        if pending.exists():
            shutil.rmtree(pending)
        raise


def _cli() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--migration-root", type=Path, required=True)
    parser.add_argument("--results-root", type=Path, required=True)
    parser.add_argument("--training-admission", type=Path, required=True)
    parser.add_argument("--authorize-independent-filter-installation", action="store_true")
    parser.add_argument("--publish", action="store_true")
    args = parser.parse_args()
    result = verify_filter_installation_independently(
        migration_root=args.migration_root,
        results_root=args.results_root,
        training_admission_path=args.training_admission,
        authorize=args.authorize_independent_filter_installation,
        publish=args.publish,
    )
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli())
