"""Immutable identity constants for the 455-basin TUKF09 revision.

This module contains no data loader and performs no filesystem writes.  The
preflight-only execution design remains frozen; later phase records are kept in
separate files and bind back to the identities declared here.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


EXPERIMENT_ID = "TUKF09_455_BASIN_ZERO_VALIDATION_TARGET_VARIANCE_REVISION_V1"
SOURCE_EXPERIMENT_ID = "TUKF09_BACKPROPAGATION_VS_NEURAL_BACKWARD_TIME_CONFIRMATION_V1"
EXACT_AUTHORIZATION_TEXT = "全部授权"

EXPECTED_CONTRACT_SHA256 = (
    "7710594dcc5cce7f087cb70492a6f827c3925a98ea7fa051d26c5ef1660304e1"
)
EXPECTED_PREFLIGHT_FINAL_SHA256 = (
    "f7e0a3f0708d0498cbaeaa77a044687f20d017ffa316170cd4770fc920b144aa"
)
EXPECTED_PREFLIGHT_EXECUTION_DESIGN_SHA256 = (
    "e12e104c90afff709e5edd707a9339b05450fb232e92039699dad1a8283637b6"
)

ORDERED_BASIN_COUNT = 455
EXCLUDED_BASINS = ("08202700",)
ORDERED_BASIN_NEWLINE_SHA256 = (
    "38987bce45fa38ff68f5b067db17e8cb3212d98fecdd106f57d268a130ee8fbd"
)
ORDERED_BASIN_COMPACT_JSON_SHA256 = (
    "75ef2cee206fb15ee3f31ae0bbfcf594661c5ccdda0b28de9ff65634332c8902"
)
PARAMETER_SHAPE = (455, 13)
TRAINING_IDENTITY_MEMBER_COUNT = 1365
TRAINING_IDENTITY_SHA256 = (
    "3ef5f011c060145f1fbc7bbf33af80f8cf6873dee72b9774bdf39f86614ca569"
)
VALIDATION_IDENTITY_MEMBER_COUNT = 1365
VALIDATION_IDENTITY_SHA256 = (
    "20b4aa7891f3e878e82798045f37c4405249ff3b7f2f13b903354b1cbe523db3"
)
TRAINING_VALIDATION_IDENTITY_MEMBER_COUNT = 2730
TRAINING_VALIDATION_IDENTITY_SHA256 = (
    "8e9d4701478e3bb69e6b343c16a1a9ff336512f0b983a29415f7bc320bb2f2f8"
)
EVALUATION_IDENTITY_MEMBER_COUNT = 1365
EVALUATION_IDENTITY_SHA256 = (
    "fac922d51908376d078a2d3abc023e065a8f785317e059d309dfbbabad37e4a5"
)

CONTRACT_RELATIVE = Path(
    "configs/tukf09_455_basin_zero_validation_target_variance_revision_v1.json"
)
PREFLIGHT_EXECUTION_DESIGN_RELATIVE = Path(
    "configs/tukf09_455_basin_zero_validation_target_variance_execution_v1.json"
)
FILTER_MIGRATION_CONFIG_RELATIVE = Path(
    "configs/tukf09_455_basin_zero_validation_target_variance_filter_migration_v1.json"
)
FORMAL_TRAINING_CONFIG_RELATIVE = Path(
    "configs/tukf09_455_basin_zero_validation_target_variance_formal_training_execution_v1.json"
)
FORMAL_EVALUATION_CONFIG_RELATIVE = Path(
    "configs/tukf09_455_basin_zero_validation_target_variance_formal_evaluation_v1.json"
)
PREFLIGHT_ROOT_RELATIVE = Path(
    "artifacts/tukf09_455_basin_zero_validation_target_variance_revision_v1/preflight"
)
PREFLIGHT_FINAL_RELATIVE = (
    PREFLIGHT_ROOT_RELATIVE / "independent/manifest.final.sha256.json"
)
FILTER_MIGRATION_ROOT_RELATIVE = Path(
    "artifacts/tukf09_455_basin_zero_validation_target_variance_revision_v1/filter_migration_v1"
)
FILTER_MIGRATION_FINAL_RELATIVE = (
    FILTER_MIGRATION_ROOT_RELATIVE / "independent/manifest.final.sha256.json"
)
AUTHORIZATION_RELATIVE = Path(
    "artifacts/tukf09_455_basin_zero_validation_target_variance_revision_v1/"
    "authorizations/all_scope_authorization.json"
)
ADMISSION_RELATIVE = Path(
    "artifacts/tukf09_455_basin_zero_validation_target_variance_revision_v1/"
    "training_admission/training_admission.json"
)
OUTPUT_RELATIVE = Path(
    "results/tukf09_455_basin_zero_validation_target_variance_revision_v1"
)
FILTER_INSTALLATION_SEAL_RELATIVE = (
    OUTPUT_RELATIVE / "control/filter_rebinding/filter_rebinding.sealed.json"
)
FILTER_INSTALLATION_FINAL_RELATIVE = (
    OUTPUT_RELATIVE
    / "control/filter_rebinding/independent/manifest.final.sha256.json"
)

SOURCE_CONTRACT_RELATIVE = Path(
    "configs/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1.json"
)
SOURCE_PREFLIGHT_FINAL_RELATIVE = Path(
    "artifacts/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1/"
    "preflight/independent/manifest.final.sha256.json"
)
SOURCE_AUTHORIZATION_RELATIVE = Path(
    "artifacts/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1/"
    "authorizations/formal_training_authorization.json"
)
SOURCE_OUTPUT_RELATIVE = Path(
    "results/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1"
)

AUTHORIZATION_SCHEMA = "tukf09_455_all_scope_authorization_v1"
TRAINING_ADMISSION_SCHEMA = "tukf09_455_training_admission_v1"
TRAINING_CONTEXT_SCHEMA = "tukf09_455_training_context_v1"
FORMAL_TRAINING_EXECUTION_SCHEMA = "tukf09_455_formal_training_execution_v1"


@dataclass(frozen=True)
class ExperimentProfile:
    experiment_id: str = EXPERIMENT_ID
    source_experiment_id: str = SOURCE_EXPERIMENT_ID
    contract_relative: Path = CONTRACT_RELATIVE
    preflight_final_relative: Path = PREFLIGHT_FINAL_RELATIVE
    migration_config_relative: Path = FILTER_MIGRATION_CONFIG_RELATIVE
    training_config_relative: Path = FORMAL_TRAINING_CONFIG_RELATIVE
    evaluation_config_relative: Path = FORMAL_EVALUATION_CONFIG_RELATIVE
    authorization_relative: Path = AUTHORIZATION_RELATIVE
    admission_relative: Path = ADMISSION_RELATIVE
    output_relative: Path = OUTPUT_RELATIVE
    ordered_basin_count: int = ORDERED_BASIN_COUNT
    ordered_basin_newline_sha256: str = ORDERED_BASIN_NEWLINE_SHA256


PROFILE = ExperimentProfile()


__all__ = [
    "ADMISSION_RELATIVE",
    "AUTHORIZATION_RELATIVE",
    "AUTHORIZATION_SCHEMA",
    "CONTRACT_RELATIVE",
    "EVALUATION_IDENTITY_MEMBER_COUNT",
    "EVALUATION_IDENTITY_SHA256",
    "EXACT_AUTHORIZATION_TEXT",
    "EXCLUDED_BASINS",
    "EXPERIMENT_ID",
    "EXPECTED_CONTRACT_SHA256",
    "EXPECTED_PREFLIGHT_EXECUTION_DESIGN_SHA256",
    "EXPECTED_PREFLIGHT_FINAL_SHA256",
    "ExperimentProfile",
    "FILTER_INSTALLATION_FINAL_RELATIVE",
    "FILTER_INSTALLATION_SEAL_RELATIVE",
    "FILTER_MIGRATION_CONFIG_RELATIVE",
    "FILTER_MIGRATION_FINAL_RELATIVE",
    "FILTER_MIGRATION_ROOT_RELATIVE",
    "FORMAL_EVALUATION_CONFIG_RELATIVE",
    "FORMAL_TRAINING_CONFIG_RELATIVE",
    "FORMAL_TRAINING_EXECUTION_SCHEMA",
    "ORDERED_BASIN_COMPACT_JSON_SHA256",
    "ORDERED_BASIN_COUNT",
    "ORDERED_BASIN_NEWLINE_SHA256",
    "OUTPUT_RELATIVE",
    "PARAMETER_SHAPE",
    "PREFLIGHT_EXECUTION_DESIGN_RELATIVE",
    "PREFLIGHT_FINAL_RELATIVE",
    "PREFLIGHT_ROOT_RELATIVE",
    "PROFILE",
    "SOURCE_AUTHORIZATION_RELATIVE",
    "SOURCE_CONTRACT_RELATIVE",
    "SOURCE_EXPERIMENT_ID",
    "SOURCE_OUTPUT_RELATIVE",
    "SOURCE_PREFLIGHT_FINAL_RELATIVE",
    "TRAINING_ADMISSION_SCHEMA",
    "TRAINING_CONTEXT_SCHEMA",
    "TRAINING_IDENTITY_MEMBER_COUNT",
    "TRAINING_IDENTITY_SHA256",
    "TRAINING_VALIDATION_IDENTITY_MEMBER_COUNT",
    "TRAINING_VALIDATION_IDENTITY_SHA256",
    "VALIDATION_IDENTITY_MEMBER_COUNT",
    "VALIDATION_IDENTITY_SHA256",
]
