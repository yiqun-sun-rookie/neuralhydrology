"""Independently verify, seal, and optionally publish a filter-migration candidate."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import shutil
import sys
import zipfile
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np


ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

EXPERIMENT_ID = "TUKF09_455_BASIN_ZERO_VALIDATION_TARGET_VARIANCE_REVISION_V1"
SOURCE_EXPERIMENT_ID = "TUKF09_BACKPROPAGATION_VS_NEURAL_BACKWARD_TIME_CONFIRMATION_V1"
UNIT_NAMES = {
    "identity.json",
    "history.npz",
    "selection.json",
    "access_ledger.json",
    "migration_provenance.json",
    "manifest.sha256.json",
}
SOURCE_NAMES = {
    "identity.json",
    "history.npz",
    "selection.json",
    "access_ledger.json",
    "manifest.sha256.json",
}
REQUIRED_SCOPE = {
    "result_migration_authorized": True,
    "filter_result_rebinding_authorized": True,
    "new_filter_optimization_authorized": False,
    "neural_training_authorized": True,
    "formal_evaluation_authorized": True,
}
REQUIRED_PHASE_ORDER = [
    "filter_migration",
    "filter_migration_independent_verification",
    "formal_training_admission",
    "formal_training_root_initialization",
    "filter_rebinding_installation",
    "filter_rebinding_independent_verification",
    "neural_training",
    "training_selection_seal",
    "training_selection_independent_verification",
    "formal_evaluation_authorization",
    "formal_evaluation_admission",
    "formal_evaluation",
    "formal_evaluation_independent_verification",
]
ZERO_ACCESS_LEDGER = {
    "evaluation_array_reads": 0,
    "evaluation_predictions": 0,
    "evaluation_metrics": 0,
    "evaluation_outputs": 0,
}


def _reject_constant(value: str) -> None:
    raise ValueError(f"non-finite JSON value is forbidden: {value}")


def _pairs(pairs: Sequence[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def _json_bytes(payload: Any) -> bytes:
    return (
        json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
        + b"\n"
    )


def _read_json(path: Path, *, canonical: bool = True) -> Mapping[str, Any]:
    _regular(path, label=f"JSON member {path}")
    content = Path(path).read_bytes()
    try:
        value = json.loads(
            content.decode("utf-8"),
            object_pairs_hook=_pairs,
            parse_constant=_reject_constant,
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"invalid JSON: {path}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"JSON member must be an object: {path}")
    if canonical and content != _json_bytes(value):
        raise ValueError(f"JSON member is noncanonical: {path}")
    return value


def _hash_bytes(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def _hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _record(path: Path) -> dict[str, object]:
    return {"sha256": _hash_file(path), "size_bytes": Path(path).stat().st_size}


def _payload_hash(payload: Any) -> str:
    return _hash_bytes(_json_bytes(payload)[:-1])


def _verify_authorization_record(payload: Mapping[str, Any]) -> None:
    if (
        payload.get("schema_version") != "tukf09_455_all_scope_authorization_v1"
        or payload.get("experiment_id") != EXPERIMENT_ID
        or payload.get("status")
        != "ALL_REQUESTED_PHASES_AUTHORIZED_SEQUENTIAL_ADMISSION_REQUIRED"
        or payload.get("authorization_text") != "全部授权"
    ):
        raise PermissionError("migration authorization identity changed")
    if payload.get("scope") != REQUIRED_SCOPE:
        raise PermissionError("migration authorization scope changed")
    if payload.get("required_phase_order") != REQUIRED_PHASE_ORDER:
        raise PermissionError("migration authorization phase order changed")
    if payload.get("access_ledger") != ZERO_ACCESS_LEDGER:
        raise PermissionError("migration authorization records evaluation access")
    unsigned = dict(payload)
    recorded = unsigned.pop("authorization_record_sha256", None)
    if recorded != _hash_bytes(_json_bytes(unsigned)):
        raise PermissionError("migration authorization self-hash changed")


def _reparse(path: Path) -> bool:
    return bool(getattr(Path(path).lstat(), "st_file_attributes", 0) & 0x400)


def _regular(path: Path, *, label: str) -> None:
    target = Path(path)
    if target.is_symlink() or _reparse(target) or not target.is_file():
        raise RuntimeError(f"{label} must be a regular non-reparse file")
    if target.stat().st_nlink != 1:
        raise RuntimeError(f"{label} is a hard link")


def _directory(path: Path, *, label: str) -> None:
    target = Path(path)
    if target.is_symlink() or _reparse(target) or not target.is_dir():
        raise RuntimeError(f"{label} must be a regular non-reparse directory")


def _finite(value: Any, length: int) -> np.ndarray:
    array = np.asarray(value, dtype=np.float64)
    if array.shape != (length,) or not np.isfinite(array).all():
        raise RuntimeError("filter vector is non-finite or has the wrong length")
    return array


def _history(path: Path, dimension: int) -> dict[str, np.ndarray]:
    _regular(path, label="history archive")
    try:
        with np.load(path, allow_pickle=False) as archive:
            required = {
                "checkpoint_index",
                "start_index",
                "step_index",
                "theta_log",
                "training_objective",
                "validation_objective",
            }
            if set(archive.files) != required:
                raise RuntimeError("history archive member set changed")
            arrays = {name: np.array(archive[name], copy=True) for name in archive.files}
    except (OSError, ValueError, zipfile.BadZipFile) as exc:
        raise RuntimeError("history archive is invalid") from exc
    theta = arrays["theta_log"]
    training = arrays["training_objective"]
    validation = arrays["validation_objective"]
    if (
        arrays["checkpoint_index"].dtype != np.int64
        or arrays["start_index"].dtype != np.int64
        or arrays["step_index"].dtype != np.int64
        or theta.dtype != np.float64
        or training.dtype != np.float64
        or validation.dtype != np.float64
        or theta.shape != (256, dimension + 1)
        or training.shape != (256,)
        or validation.shape != (256,)
        or not np.array_equal(arrays["checkpoint_index"], np.arange(256, dtype=np.int64))
        or not np.array_equal(arrays["start_index"], np.tile(np.arange(8, dtype=np.int64), 32))
        or not np.array_equal(arrays["step_index"], np.repeat(np.arange(32, dtype=np.int64), 8))
        or not np.isfinite(theta).all()
        or not np.isfinite(training).all()
        or not np.isfinite(validation).all()
    ):
        raise RuntimeError("history dtype, shape, order, or finiteness changed")
    return arrays


def _selection(arrays: Mapping[str, np.ndarray]) -> tuple[int, np.ndarray]:
    with np.errstate(over="ignore", invalid="ignore"):
        actual = np.exp(arrays["theta_log"])
    if not np.isfinite(actual).all() or np.any(actual <= 0.0):
        raise RuntimeError("history noise parameters are invalid")
    index = min(
        range(256),
        key=lambda item: (
            float(arrays["validation_objective"][item]),
            float(arrays["training_objective"][item]),
            tuple(float(value) for value in actual[item]),
            item,
        ),
    )
    return int(index), actual


def _manifest_members(unit: Path, *, source: bool) -> Mapping[str, Any]:
    expected = SOURCE_NAMES if source else UNIT_NAMES
    _directory(unit, label="filter unit")
    if {path.name for path in unit.iterdir()} != expected:
        raise RuntimeError("filter unit has missing or extra members")
    for path in unit.iterdir():
        _regular(path, label=f"filter member {path.name}")
    manifest = _read_json(unit / "manifest.sha256.json")
    schema = "tukf09_filter_unit_manifest_v1" if source else "tukf09_455_rebound_filter_unit_manifest_v1"
    experiment = SOURCE_EXPERIMENT_ID if source else EXPERIMENT_ID
    nonmanifest = expected - {"manifest.sha256.json"}
    if (
        manifest.get("schema_version") != schema
        or manifest.get("experiment_id") != experiment
        or manifest.get("unit_type") != "filter_basin"
        or manifest.get("file_count") != len(nonmanifest)
        or set(manifest.get("files", {})) != nonmanifest
    ):
        raise RuntimeError("filter unit manifest contract changed")
    for name in nonmanifest:
        if manifest["files"][name] != _record(unit / name):
            raise RuntimeError(f"filter unit member hash mismatch: {name}")
    return manifest


def _verify_source_and_rebound(
    source: Path,
    rebound: Path,
    basin: str,
    inventory_record: Mapping[str, Any],
    *,
    expected_parameter_sha256: str | None = None,
    expected_training_period_sha256: str | None = None,
    expected_validation_period_sha256: str | None = None,
    expected_state_dimension: int | None = None,
    expected_initial_state: Sequence[float] | None = None,
    expected_base_observation_variance: float | None = None,
    expected_rebound_provenance: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    source_manifest = _manifest_members(source, source=True)
    if source_manifest.get("unit_id") != basin or _hash_file(source / "manifest.sha256.json") != inventory_record.get(
        "source_unit_manifest_sha256"
    ):
        raise RuntimeError("source unit differs from the sealed inventory")
    if inventory_record.get("source_members") is not None and inventory_record.get(
        "source_members"
    ) != source_manifest.get("files"):
        raise RuntimeError("source member inventory differs from the source manifest")
    source_identity = _read_json(source / "identity.json")
    source_selection = _read_json(source / "selection.json")
    source_ledger = _read_json(source / "access_ledger.json")
    if source_identity.get("experiment_id") != SOURCE_EXPERIMENT_ID or source_identity.get("unit_id") != basin:
        raise RuntimeError("source unit identity changed")
    for name, expected in (
        ("physical_parameter_sha256", expected_parameter_sha256),
        ("training_period_sha256", expected_training_period_sha256),
        ("validation_period_sha256", expected_validation_period_sha256),
    ):
        if expected is not None and source_identity.get(name) != expected:
            raise RuntimeError(f"source unit differs from independent revised semantics: {name}")
    if any(
        source_ledger.get(name) != 0
        for name in (
            "evaluation_array_read_count",
            "evaluation_prediction_count",
            "evaluation_metric_count",
            "evaluation_output_write_count",
        )
    ):
        raise PermissionError("source unit records evaluation access")
    dimension = source_identity.get("state_dimension")
    if type(dimension) is not int or not 7 <= dimension <= 20:
        raise RuntimeError("source unit dimension changed")
    if expected_state_dimension is not None and dimension != expected_state_dimension:
        raise RuntimeError("source state dimension differs from independently rebuilt context")
    if expected_initial_state is not None and not np.array_equal(
        _finite(source_identity.get("initial_state"), dimension),
        np.asarray(expected_initial_state, dtype=np.float64),
    ):
        raise RuntimeError("source initial state differs from independently rebuilt context")
    if expected_base_observation_variance is not None and np.asarray(
        [source_identity.get("base_observation_variance")], dtype=np.float64
    ).view("<u8")[0] != np.asarray(
        [expected_base_observation_variance], dtype=np.float64
    ).view("<u8")[0]:
        raise RuntimeError("source observation variance differs from independently rebuilt context")
    arrays = _history(source / "history.npz", dimension)
    selected, actual = _selection(arrays)
    if source_selection.get("selected_index") != selected:
        raise RuntimeError("source selected index changed")

    rebound_manifest = _manifest_members(rebound, source=False)
    if rebound_manifest.get("unit_id") != basin:
        raise RuntimeError("rebound manifest unit identity changed")
    identity = _read_json(rebound / "identity.json")
    selection = _read_json(rebound / "selection.json")
    ledger = _read_json(rebound / "access_ledger.json")
    provenance = _read_json(rebound / "migration_provenance.json")
    if (
        identity.get("schema_version") != "tukf09_455_rebound_filter_unit_identity_v1"
        or identity.get("experiment_id") != EXPERIMENT_ID
        or identity.get("unit_id") != basin
        or selection.get("schema_version") != "tukf09_455_rebound_filter_unit_selection_v1"
        or selection.get("experiment_id") != EXPERIMENT_ID
        or selection.get("unit_id") != basin
        or selection.get("status") != "FILTER_BASIN_REBOUND_FROM_VERIFIED_PARENT"
        or ledger.get("schema_version") != "tukf09_455_rebound_filter_unit_access_ledger_v1"
        or ledger.get("experiment_id") != EXPERIMENT_ID
        or ledger.get("unit_id") != basin
        or provenance.get("schema_version") != "tukf09_455_filter_unit_migration_provenance_v1"
        or provenance.get("unit_id") != basin
        or provenance.get("source_unit_manifest_sha256")
        != _hash_file(source / "manifest.sha256.json")
    ):
        raise RuntimeError("rebound identity or provenance changed")
    for name, expected in dict(expected_rebound_provenance or {}).items():
        if identity.get(name) != expected or provenance.get(name) != expected:
            raise RuntimeError(f"rebound provenance binding changed: {name}")
    for name in (
        "state_dimension",
        "parameter_names",
        "physical_parameter_sha256",
        "training_period_sha256",
        "validation_period_sha256",
        "initial_state",
        "initial_covariance_diagonal",
        "base_observation_variance",
    ):
        if identity.get(name) != source_identity.get(name):
            raise RuntimeError(f"rebound scientific identity differs from source: {name}")
    if (rebound / "history.npz").read_bytes() != (source / "history.npz").read_bytes():
        raise RuntimeError("rebound history is not byte-identical to the source")
    rebound_arrays = _history(rebound / "history.npz", dimension)
    for name in arrays:
        if not np.array_equal(rebound_arrays[name], arrays[name]):
            raise RuntimeError("rebound history array differs from source")
    if selection.get("selected_index") != selected:
        raise RuntimeError("rebound selected index changed")
    vector_pairs = (
        ("selected_theta_log", arrays["theta_log"][selected]),
        ("selected_process_diagonal", actual[selected, :-1]),
    )
    for name, expected in vector_pairs:
        if not np.array_equal(_finite(selection.get(name), expected.shape[0]), expected):
            raise RuntimeError(f"rebound selected vector changed: {name}")
    scalars = np.asarray(
        [
            selection.get("selected_r_b"),
            selection.get("selected_training_objective"),
            selection.get("selected_validation_objective"),
        ],
        dtype=np.float64,
    )
    expected_scalars = np.asarray(
        [actual[selected, -1], arrays["training_objective"][selected], arrays["validation_objective"][selected]],
        dtype=np.float64,
    )
    if not np.array_equal(scalars, expected_scalars):
        raise RuntimeError("rebound selected scalars changed")
    if (
        selection.get("checkpoint_count") != 256
        or selection.get("gradient_update_count") != 248
        or ledger.get("new_filter_optimization_count") != 0
        or ledger.get("formal_evaluation_authorized") is not False
        or any(
            ledger.get(name) != 0
            for name in (
                "evaluation_array_read_count",
                "evaluation_prediction_count",
                "evaluation_metric_count",
                "evaluation_output_write_count",
            )
        )
    ):
        raise PermissionError("rebound count or evaluation ledger changed")
    return {
        "unit_manifest_sha256": _hash_file(rebound / "manifest.sha256.json"),
        "selected_index": selected,
        "checkpoint_count": 256,
        "gradient_update_count": 248,
    }


def _verify_generator_manifest(root: Path) -> None:
    manifest = _read_json(root / "migration_manifest.sha256.json")
    if manifest.get("schema_version") != "tukf09_455_filter_migration_manifest_v1" or manifest.get(
        "experiment_id"
    ) != EXPERIMENT_ID:
        raise RuntimeError("migration generator manifest identity changed")
    actual = {
        path.relative_to(root).as_posix(): _record(path)
        for path in sorted(root.rglob("*"))
        if path.is_file()
        and path.relative_to(root).as_posix() != "migration_manifest.sha256.json"
        and not path.relative_to(root).as_posix().startswith("independent/")
    }
    if manifest.get("file_count") != len(actual) or manifest.get("files") != actual:
        raise RuntimeError("migration generator manifest differs from candidate files")


def _source_map(source_root: Path, basin_ids: Sequence[str]) -> dict[str, str]:
    return {
        basin: _hash_file(source_root / f"basin_{basin}" / "manifest.sha256.json")
        for basin in basin_ids
    }


def _period_identity(period: Any) -> str:
    dates = np.asarray(period.dates_ns, dtype="<i8")
    forcing = np.asarray(period.forcing, dtype="<f8")
    observations = np.asarray(period.observations, dtype="<f8")
    if forcing.ndim == 3:
        forcing = forcing[:, 0, :]
    if observations.ndim == 2:
        observations = observations[:, 0]
    digest = hashlib.sha256()
    for name, array in (
        ("dates_ns", dates),
        ("forcing", forcing),
        ("observations", observations),
    ):
        contiguous = np.ascontiguousarray(array)
        if np.issubdtype(contiguous.dtype, np.floating) and not np.isfinite(contiguous).all():
            raise RuntimeError("training or validation period contains non-finite values")
        digest.update(name.encode("utf-8"))
        digest.update(str(contiguous.dtype).encode("ascii"))
        digest.update(np.asarray(contiguous.shape, dtype="<i8").tobytes())
        digest.update(contiguous.tobytes())
    return digest.hexdigest()


def _independent_parameter_hashes(path: Path) -> dict[str, str]:
    _regular(path, label="revised parameter archive")
    with np.load(path, allow_pickle=False) as archive:
        if set(archive.files) != {"basin_ids", "parameter_names", "values"}:
            raise RuntimeError("revised parameter archive member set changed")
        basin_ids = [str(value) for value in archive["basin_ids"]]
        names = [str(value) for value in archive["parameter_names"]]
        values = np.asarray(archive["values"], dtype=np.float64)
    expected_names = [
        "parTT", "parCFMAX", "parCFR", "parCWH", "parFC", "parBETA", "parLP",
        "parK0", "parK1", "parUZL", "parPERC", "parK2", "lag_time",
    ]
    if names != expected_names or values.shape != (len(basin_ids), 13) or not np.isfinite(values).all():
        raise RuntimeError("revised parameter archive changed")
    return {
        basin: _payload_hash([float(value) for value in row])
        for basin, row in zip(basin_ids, values)
    }


def _normalized(value: Any) -> Any:
    if isinstance(value, bool) or value is None or isinstance(value, str):
        return value
    if isinstance(value, (int, float)):
        number = float(value)
        if not math.isfinite(number):
            raise ValueError("non-finite contract number")
        return number
    if isinstance(value, list):
        return [_normalized(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _normalized(item) for key, item in value.items()}
    raise TypeError("unsupported contract compatibility value")


def _independent_compatibility_digest() -> str:
    parent = _read_json(
        ROOT / "configs/tukf09_backpropagation_vs_neural_backward_time_confirmation_v1.json",
        canonical=False,
    )
    revised = _read_json(
        ROOT / "configs/tukf09_455_basin_zero_validation_target_variance_revision_v1.json",
        canonical=False,
    )
    keys = ("periods", "filter_system", "information_contract", "source_anchors", "primary_comparison")
    parent_projection = {key: _normalized(parent[key]) for key in keys}
    revised_projection = {key: _normalized(revised[key]) for key in keys}
    if parent_projection != revised_projection:
        raise RuntimeError("runner-consumed filter contract projection changed")
    return _payload_hash(revised_projection)


def _independent_production_evidence(
    source_root: Path, basin_ids: Sequence[str]
) -> tuple[
    dict[str, str],
    dict[str, str],
    dict[str, str],
    dict[str, Mapping[str, Any]],
]:
    """Re-run the frozen source verifier and training/validation loader only."""

    from scripts import tukf09_training_common as common
    from scripts import tukf09_training_controller_common as controller_common
    from scripts.run_tukf09_filter_training_controller import FILTER_RUNNER, verify_completed_filter_unit
    from scripts.run_tukf09_filter_training import build_causal_filter_context
    from scripts.run_tukf09_formal_training_sequence import fixed_paths, verify_training_admission

    paths = fixed_paths()
    if source_root.resolve() != (paths.output_root / "filter").resolve():
        raise RuntimeError("candidate source root differs from the frozen production source root")
    admission = verify_training_admission(paths)
    common.verify_initialized_training_root(
        output_root=paths.output_root,
        config_path=paths.config,
        authorization=paths.authorization,
        execution_config=paths.execution_config,
        training_admission=paths.training_admission,
        training_admission_record=admission,
    )
    context = common.verify_preflight_for_training(
        paths.config,
        paths.preflight_root / "independent/manifest.final.sha256.json",
        paths.authorization,
        paths.output_root,
        require_output_absent=False,
        recompute_training_validation_semantics=False,
        verify_all_raw_source_bytes=False,
    )
    if context.evaluation_access_count != 0:
        raise PermissionError("frozen source context records evaluation access")
    provenance = {
        "contract_file_sha256": context.contract_sha256,
        "preflight_final_manifest_sha256": context.preflight_final_manifest_sha256,
        "authorization_file_sha256": context.authorization.authorization_file_sha256,
        "training_admission_record_sha256": admission["training_admission_record_sha256"],
    }
    runner_hash = controller_common.sha256_file(FILTER_RUNNER)
    source_population = tuple(str(value) for value in context.ordered_basin_ids)
    if len(source_population) != 456 or len(set(source_population)) != 456:
        raise RuntimeError("frozen source population changed")
    for basin in source_population:
        verify_completed_filter_unit(
            source_root / f"basin_{basin}",
            basin,
            expected_runner_sha256=runner_hash,
            expected_provenance=provenance,
        )
    loaded = common.load_training_validation_periods(context, basin_ids)
    training: dict[str, str] = {}
    validation: dict[str, str] = {}
    rebuilt: dict[str, Mapping[str, Any]] = {}
    contract = _read_json(paths.config, canonical=False)
    population_index = {basin: index for index, basin in enumerate(source_population)}
    for basin in basin_ids:
        if set(loaded[basin]) != {"training", "validation"}:
            raise RuntimeError("frozen loader returned a forbidden or missing period")
        training[basin] = _period_identity(loaded[basin]["training"])
        validation[basin] = _period_identity(loaded[basin]["validation"])
        row = {
            name: float(context.parameter_values[population_index[basin], column])
            for column, name in enumerate(context.parameter_names)
        }
        filter_context = build_causal_filter_context(
            basin,
            row,
            loaded[basin]["training"].observations,
            contract,
        )
        rebuilt[basin] = {
            "state_dimension": int(filter_context.dimension),
            "initial_state": filter_context.initial_state[0].detach().cpu().numpy().tolist(),
            "base_observation_variance": float(filter_context.base_observation_variance),
        }
    parameters = _independent_parameter_hashes(
        ROOT
        / "artifacts/tukf09_455_basin_zero_validation_target_variance_revision_v1/preflight/parameters_only.npz"
    )
    if set(parameters) != set(basin_ids):
        raise RuntimeError("revised parameter population changed")
    return parameters, training, validation, rebuilt


def _write(path: Path, content: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as handle:
        handle.write(content)
        handle.flush()
        os.fsync(handle.fileno())


def _verify_final_manifest(root: Path) -> Mapping[str, Any]:
    final_path = root / "independent" / "manifest.final.sha256.json"
    audit_path = root / "independent" / "independent_audit.json"
    final = _read_json(final_path)
    audit = _read_json(audit_path)
    if (
        final.get("schema_version") != "tukf09_455_filter_migration_final_manifest_v1"
        or final.get("status") != "FILTER_MIGRATION_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
        or audit.get("schema_version") != "tukf09_455_filter_migration_independent_audit_v1"
        or audit.get("status") != "FILTER_MIGRATION_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
    ):
        raise RuntimeError("independent migration seal identity changed")
    actual = {
        path.relative_to(root).as_posix(): _record(path)
        for path in sorted(root.rglob("*"))
        if path.is_file() and path != final_path
    }
    if final.get("file_count") != len(actual) or final.get("files") != actual:
        raise RuntimeError("independent migration final manifest differs from files")
    return audit


def verify_filter_migration(
    candidate_root: Path,
    authorize: bool,
    publish: bool,
    *,
    expected_unit_count: int = 455,
    expected_checkpoint_count: int = 116_480,
    expected_gradient_update_count: int = 112_840,
    fail_after_write: int | None = None,
) -> dict[str, object]:
    if authorize is not True:
        raise PermissionError("independent filter-migration verification requires authorization")
    root = Path(candidate_root)
    _directory(root, label="migration candidate or final root")
    summary = _read_json(root / "migration_summary.json")
    inventory = _read_json(root / "source_inventory.sha256.json")
    config_snapshot_path = root / "migration_config.snapshot.json"
    authorization_snapshot_path = root / "all_scope_authorization.snapshot.json"
    config_snapshot = _read_json(config_snapshot_path, canonical=False)
    authorization = _read_json(authorization_snapshot_path)
    _verify_authorization_record(authorization)
    basins = [str(value) for value in summary.get("ordered_basin_ids", [])]
    if (
        summary.get("experiment_id") != EXPERIMENT_ID
        or summary.get("status") != "FILTER_MIGRATION_CANDIDATE_455_COMPLETE_EVALUATION_HOLD"
        or len(basins) != expected_unit_count
        or len(set(basins)) != expected_unit_count
        or "08202700" in basins
        or inventory.get("ordered_basin_ids") != basins
        or inventory.get("unit_count") != expected_unit_count
    ):
        raise RuntimeError("candidate population or status changed")
    units_root = root / "units"
    _directory(units_root, label="candidate units root")
    actual_unit_names = {path.name for path in units_root.iterdir()}
    if actual_unit_names != {f"basin_{basin}" for basin in basins}:
        raise RuntimeError("candidate unit population has missing or extra directories")
    source_root = Path(str(summary.get("source_filter_root"))).resolve(strict=True)
    _directory(source_root, label="source filter root")
    source_ids = sorted(
        path.name.removeprefix("basin_")
        for path in source_root.iterdir()
        if path.is_dir() and path.name.startswith("basin_")
    )
    before = _source_map(source_root, source_ids)
    if inventory.get("source_population_manifest_map_sha256") is not None and inventory.get(
        "source_population_manifest_map_sha256"
    ) != _payload_hash(before):
        raise RuntimeError("source filter tree differs from the candidate snapshot")
    if expected_unit_count == 455:
        (
            parameter_hashes,
            training_hashes,
            validation_hashes,
            rebuilt_contexts,
        ) = _independent_production_evidence(source_root, basins)
        external_config = ROOT / (
            "configs/tukf09_455_basin_zero_validation_target_variance_filter_migration_v1.json"
        )
        external_authorization = ROOT / (
            "artifacts/tukf09_455_basin_zero_validation_target_variance_revision_v1/"
            "authorizations/all_scope_authorization.json"
        )
        if config_snapshot_path.read_bytes() != external_config.read_bytes() or (
            authorization_snapshot_path.read_bytes() != external_authorization.read_bytes()
        ):
            raise RuntimeError("migration config or authorization snapshot differs from its frozen source")
        contract_path = ROOT / "configs/tukf09_455_basin_zero_validation_target_variance_revision_v1.json"
        preflight_final_path = ROOT / (
            "artifacts/tukf09_455_basin_zero_validation_target_variance_revision_v1/"
            "preflight/independent/manifest.final.sha256.json"
        )
        if (
            _hash_file(contract_path)
            != "7710594dcc5cce7f087cb70492a6f827c3925a98ea7fa051d26c5ef1660304e1"
            or _hash_file(preflight_final_path)
            != "f7e0a3f0708d0498cbaeaa77a044687f20d017ffa316170cd4770fc920b144aa"
            or config_snapshot.get("scientific_contract", {}).get("sha256")
            != _hash_file(contract_path)
            or config_snapshot.get("independent_preflight_final_manifest", {}).get("sha256")
            != _hash_file(preflight_final_path)
        ):
            raise RuntimeError("revised contract or preflight identity changed")
        rebound_provenance = {
            "scientific_contract_sha256": _hash_file(contract_path),
            "preflight_final_manifest_sha256": _hash_file(preflight_final_path),
            "all_scope_authorization_sha256": _hash_file(external_authorization),
            "migration_config_sha256": _hash_file(external_config),
            "compatibility_projection_sha256": _independent_compatibility_digest(),
        }
    else:
        parameter_hashes = {}
        training_hashes = {}
        validation_hashes = {}
        rebuilt_contexts = {}
        rebound_provenance = {}
    records: dict[str, Any] = {}
    checkpoints = 0
    gradients = 0
    for basin in basins:
        source = source_root / f"basin_{basin}"
        rebound = units_root / f"basin_{basin}"
        record = inventory.get("records", {}).get(basin)
        if not isinstance(record, dict):
            raise RuntimeError("source inventory record is missing")
        verified = _verify_source_and_rebound(
            source,
            rebound,
            basin,
            record,
            expected_parameter_sha256=parameter_hashes.get(basin),
            expected_training_period_sha256=training_hashes.get(basin),
            expected_validation_period_sha256=validation_hashes.get(basin),
            expected_state_dimension=(rebuilt_contexts.get(basin) or {}).get("state_dimension"),
            expected_initial_state=(rebuilt_contexts.get(basin) or {}).get("initial_state"),
            expected_base_observation_variance=(rebuilt_contexts.get(basin) or {}).get(
                "base_observation_variance"
            ),
            expected_rebound_provenance=rebound_provenance,
        )
        records[basin] = verified
        checkpoints += int(verified["checkpoint_count"])
        gradients += int(verified["gradient_update_count"])
    if checkpoints != expected_checkpoint_count or gradients != expected_gradient_update_count:
        raise RuntimeError("independently recomputed migration totals changed")
    if (
        summary.get("unit_count") != expected_unit_count
        or summary.get("unit_file_count") != expected_unit_count * 6
        or summary.get("inherited_checkpoint_count") != expected_checkpoint_count
        or summary.get("inherited_training_objective_count") != expected_checkpoint_count
        or summary.get("inherited_validation_objective_count") != expected_checkpoint_count
        or summary.get("inherited_gradient_update_count") != expected_gradient_update_count
        or summary.get("new_filter_optimization_count") != 0
        or summary.get("evaluation_access_count") != 0
    ):
        raise RuntimeError("candidate declared totals changed")
    _verify_generator_manifest(root)
    after = _source_map(source_root, source_ids)
    if before != after:
        raise RuntimeError("source filter tree changed during independent verification")
    independent = root / "independent"
    result = {
        "status": "FILTER_MIGRATION_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD",
        "migration_root": str(root),
        "unit_count": expected_unit_count,
        "checkpoint_count": checkpoints,
        "gradient_update_count": gradients,
        "evaluation_access_count": 0,
    }
    if independent.exists():
        audit = _verify_final_manifest(root)
        if audit.get("unit_count") != expected_unit_count:
            raise RuntimeError("existing migration audit count changed")
        if not publish:
            return result
        final_root = Path(str(summary.get("final_root"))).resolve(strict=False)
        if root.resolve() == final_root:
            return result
        if final_root.parent != root.resolve().parent:
            raise RuntimeError("candidate and final migration roots are not same-volume siblings")
        if final_root.exists() or final_root.is_symlink():
            raise FileExistsError("final migration root already exists")
        os.replace(root, final_root)
        result["migration_root"] = str(final_root)
        return result
    if not publish:
        return result
    final_root = Path(str(summary.get("final_root"))).resolve(strict=False)
    if final_root.parent != root.resolve().parent:
        raise RuntimeError("candidate and final migration roots are not same-volume siblings")
    if final_root.exists() or final_root.is_symlink():
        raise FileExistsError("final migration root already exists")
    writes = 0
    try:
        independent.mkdir(exist_ok=False)
        audit = {
            "schema_version": "tukf09_455_filter_migration_independent_audit_v1",
            "experiment_id": EXPERIMENT_ID,
            "status": result["status"],
            "unit_count": expected_unit_count,
            "unit_file_count": expected_unit_count * 6,
            "checkpoint_count": checkpoints,
            "training_objective_count": checkpoints,
            "validation_objective_count": checkpoints,
            "gradient_update_count": gradients,
            "new_filter_optimization_count": 0,
            "evaluation_access_count": 0,
            "source_manifest_map_sha256_before": _payload_hash(before),
            "source_manifest_map_sha256_after": _payload_hash(after),
            "rebound_unit_manifest_map_sha256": _payload_hash(
                {basin: record["unit_manifest_sha256"] for basin, record in records.items()}
            ),
        }
        _write(independent / "independent_audit.json", _json_bytes(audit))
        writes += 1
        if fail_after_write == writes:
            raise RuntimeError("injected independent-seal write failure")
        files = {
            path.relative_to(root).as_posix(): _record(path)
            for path in sorted(root.rglob("*"))
            if path.is_file()
        }
        final_manifest = {
            "schema_version": "tukf09_455_filter_migration_final_manifest_v1",
            "experiment_id": EXPERIMENT_ID,
            "status": result["status"],
            "file_count": len(files),
            "files": files,
        }
        _write(independent / "manifest.final.sha256.json", _json_bytes(final_manifest))
        writes += 1
        if fail_after_write == writes:
            raise RuntimeError("injected independent-seal write failure")
        _verify_final_manifest(root)
        os.replace(root, final_root)
        result["migration_root"] = str(final_root)
        return result
    except BaseException:
        if independent.exists():
            shutil.rmtree(independent)
        raise


def _cli() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("candidate_root", type=Path)
    parser.add_argument("--authorize-independent-filter-migration", action="store_true")
    parser.add_argument("--publish", action="store_true")
    args = parser.parse_args()
    result = verify_filter_migration(
        args.candidate_root,
        authorize=args.authorize_independent_filter_migration,
        publish=args.publish,
    )
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli())
