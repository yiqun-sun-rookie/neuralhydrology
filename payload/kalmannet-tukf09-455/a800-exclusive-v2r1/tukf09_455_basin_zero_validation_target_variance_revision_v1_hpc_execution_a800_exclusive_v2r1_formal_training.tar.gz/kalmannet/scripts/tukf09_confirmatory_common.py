"""Read-only primitives for the TUKF09 backward-time confirmation preflight.

This module deliberately contains no optimizer, neural-network, forecast, metric,
or artifact-writing entry point.  It derives the preregistered population directly
from raw daily input coverage and exposes only parameter and causal-initial-state
helpers needed before either system may be trained.
"""
from __future__ import annotations

import csv
from dataclasses import dataclass
from datetime import date, timedelta
from hashlib import sha256
import json
import math
import operator
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping, Sequence

import numpy as np


EXPERIMENT_ID = "TUKF09_BACKPROPAGATION_VS_NEURAL_BACKWARD_TIME_CONFIRMATION_V1"
SCHEMA_VERSION = "tukf09_backward_time_confirmation_contract_v1"

# SHA-256 of the canonical JSON representation (sorted keys, compact separators)
# of the frozen TUKF09 contract.  Whitespace-only file changes remain harmless,
# while every scientific or execution field is protected.
_FROZEN_CONTRACT_CANONICAL_SHA256 = (
    "78327fc9718588a046fbc4ace07cb56c9f94436391d1598bcec6ed15a0e16186"
)

PARAMETER_NAMES = (
    "parTT",
    "parCFMAX",
    "parCFR",
    "parCWH",
    "parFC",
    "parBETA",
    "parLP",
    "parK0",
    "parK1",
    "parUZL",
    "parPERC",
    "parK2",
    "lag_time",
)

_PERIOD_NAMES = ("training", "validation", "evaluation")
_EXPECTED_AUTHORIZATIONS = {
    "preflight": True,
    "independent_preflight": True,
    "formal_training": False,
    "formal_evaluation": False,
    "independent_final_audit": False,
}
_EXPECTED_DATA_ACCESS_RECORD = {
    "evaluation_input_read_for_eligibility": True,
    "evaluation_model_outputs_read": False,
    "evaluation_pairwise_outcomes_read": False,
    "evaluation_metric_computed": False,
}


@dataclass(frozen=True)
class PopulationRegistry:
    """Immutable ordered population partition produced without model outcomes."""

    canonical: tuple[str, ...]
    previously_evaluated: tuple[str, ...]
    candidates: tuple[str, ...]
    eligible: tuple[str, ...]
    date_incomplete: tuple[str, ...]
    missing_days_by_basin: Mapping[str, int]

    def __post_init__(self) -> None:
        for name in (
            "canonical",
            "previously_evaluated",
            "candidates",
            "eligible",
            "date_incomplete",
        ):
            object.__setattr__(self, name, tuple(getattr(self, name)))
        missing = {
            str(basin): int(count)
            for basin, count in self.missing_days_by_basin.items()
        }
        if any(count < 0 for count in missing.values()):
            raise ValueError("missing-day counts must be nonnegative")
        object.__setattr__(self, "missing_days_by_basin", MappingProxyType(missing))


@dataclass(frozen=True)
class ParameterOnlyTable:
    """Immutable physical-parameter matrix with no saved states or metrics."""

    basin_ids: tuple[str, ...]
    parameter_names: tuple[str, ...]
    values: np.ndarray

    def __post_init__(self) -> None:
        basin_ids = tuple(self.basin_ids)
        parameter_names = tuple(self.parameter_names)
        values = np.array(self.values, dtype=np.float64, order="C", copy=True)
        if values.ndim != 2:
            raise ValueError("parameter values must be a two-dimensional array")
        if values.shape != (len(basin_ids), len(parameter_names)):
            raise ValueError("parameter values do not match basin and parameter names")
        if not np.isfinite(values).all():
            raise ValueError("parameter values must all be finite")
        values.setflags(write=False)
        object.__setattr__(self, "basin_ids", basin_ids)
        object.__setattr__(self, "parameter_names", parameter_names)
        object.__setattr__(self, "values", values)


def _reject_nonfinite_json(token: str) -> None:
    raise ValueError(f"non-finite JSON number is forbidden: {token}")


def _canonical_json_sha256(payload: Any) -> str:
    encoded = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")
    return sha256(encoded).hexdigest()


def load_contract(path: Path) -> dict[str, Any]:
    """Load the one frozen TUKF09 contract and reject any semantic change."""

    contract_path = Path(path)
    try:
        contract = json.loads(
            contract_path.read_text(encoding="utf-8"),
            parse_constant=_reject_nonfinite_json,
        )
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid TUKF09 contract JSON: {contract_path}") from exc
    if not isinstance(contract, dict):
        raise ValueError("TUKF09 contract must be a JSON object")
    if contract.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("TUKF09 contract schema version changed")
    if contract.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("TUKF09 experiment identifier changed")
    if contract.get("authorizations") != _EXPECTED_AUTHORIZATIONS:
        raise ValueError("TUKF09 execution authorization boundary changed")
    if contract.get("data_access_record") != _EXPECTED_DATA_ACCESS_RECORD:
        raise ValueError("TUKF09 evaluation-input access record changed")

    population = contract.get("population")
    if not isinstance(population, dict):
        raise ValueError("TUKF09 population contract is missing")
    if (
        population.get("canonical_basin_count") != 531
        or population.get("previously_evaluated_basin_count") != 21
        or population.get("candidate_count") != 510
        or population.get("primary_basin_count") != 456
        or population.get("date_incomplete_exclusion_count") != 54
    ):
        raise ValueError("TUKF09 population counts changed")
    prior = population.get("previously_evaluated_basins")
    if not isinstance(prior, list) or len(prior) != 21 or len(set(prior)) != 21:
        raise ValueError("TUKF09 previously evaluated basin registry changed")

    periods = contract.get("periods")
    if not isinstance(periods, dict) or periods.get("reset_each_period") is not True:
        raise ValueError("TUKF09 period reset contract changed")
    for period_name, expected in {
        "training": (["1999-10-01", "2006-09-30"], 2557),
        "validation": (["2006-10-01", "2008-09-30"], 731),
        "evaluation": (["1980-10-01", "1989-09-30"], 3287),
    }.items():
        period = periods.get(period_name)
        if (
            not isinstance(period, dict)
            or period.get("input") != expected[0]
            or period.get("day_count") != expected[1]
            or period.get("first_scoring_index") != 365
        ):
            raise ValueError(f"TUKF09 {period_name} period changed")

    dimensions = contract.get("state_dimensions")
    expected_dimension_counts = {
        "7": 313,
        "8": 61,
        "9": 25,
        "10": 7,
        "11": 11,
        "12": 10,
        "13": 6,
        "15": 3,
        "17": 3,
        "18": 3,
        "20": 14,
    }
    if not isinstance(dimensions, dict) or dimensions.get("counts") != expected_dimension_counts:
        raise ValueError("TUKF09 routed-state dimension distribution changed")
    if sum(expected_dimension_counts.values()) != 456:
        raise AssertionError("internal routed-state dimension count is inconsistent")

    anchors = contract.get("source_anchors")
    if not isinstance(anchors, dict) or len(anchors) != 19:
        raise ValueError("TUKF09 must contain exactly nineteen source anchors")
    for name, anchor in anchors.items():
        if not isinstance(anchor, dict) or set(anchor) != {"path", "sha256"}:
            raise ValueError(f"invalid TUKF09 source anchor: {name}")
        digest = anchor["sha256"]
        if (
            not isinstance(anchor["path"], str)
            or not anchor["path"]
            or not isinstance(digest, str)
            or len(digest) != 64
            or any(character not in "0123456789abcdef" for character in digest)
        ):
            raise ValueError(f"invalid TUKF09 source anchor value: {name}")

    raw_seal = contract.get("raw_input_seal")
    if not isinstance(raw_seal, dict) or (
        raw_seal.get("required_before_training") is not True
        or raw_seal.get("candidate_raw_data_file_count") != 1020
        or raw_seal.get("candidate_forcing_file_count") != 510
        or raw_seal.get("candidate_discharge_file_count") != 510
        or raw_seal.get("eligible_basin_period_count") != 1368
        or raw_seal.get("semantic_array_member_count") != 4104
        or raw_seal.get("later_training_must_recompute_both_manifests") is not True
    ):
        raise ValueError("TUKF09 raw-input seal contract changed")
    raw_manifest_schema = raw_seal.get("raw_source_manifest_schema")
    semantic_manifest_schema = raw_seal.get("semantic_input_manifest_schema")
    if not isinstance(raw_manifest_schema, dict) or (
        raw_manifest_schema.get("schema_version") != "tukf09_raw_source_manifest_v1"
        or raw_manifest_schema.get("member_object_key") != "files"
        or raw_manifest_schema.get("member_value_keys") != ["sha256", "size_bytes"]
    ):
        raise ValueError("TUKF09 raw-source manifest schema changed")
    if not isinstance(semantic_manifest_schema, dict) or (
        semantic_manifest_schema.get("schema_version")
        != "tukf09_semantic_input_manifest_v1"
        or semantic_manifest_schema.get("member_object_key") != "members"
        or semantic_manifest_schema.get("period_name_order")
        != ["training", "validation", "evaluation"]
        or semantic_manifest_schema.get("array_name_order")
        != ["dates_ns", "forcing", "observations"]
        or semantic_manifest_schema.get("member_value_keys")
        != ["dtype", "shape", "sha256"]
        or semantic_manifest_schema.get("canonical_dtype_by_array")
        != {"dates_ns": "<i8", "forcing": "<f8", "observations": "<f8"}
    ):
        raise ValueError("TUKF09 semantic-input manifest schema changed")

    paths = contract.get("paths")
    if not isinstance(paths, dict):
        raise ValueError("TUKF09 path contract is missing")
    preflight_root = paths.get("preflight_root")
    future_results_root = paths.get("future_results_root")
    if (
        not isinstance(preflight_root, str)
        or not preflight_root.startswith("artifacts/tukf09_")
        or not isinstance(future_results_root, str)
        or not future_results_root.startswith("results/tukf09_")
        or preflight_root == future_results_root
    ):
        raise ValueError("TUKF09 preflight and future-results paths changed")

    if _canonical_json_sha256(contract) != _FROZEN_CONTRACT_CANONICAL_SHA256:
        raise ValueError("TUKF09 frozen contract content changed")
    return contract


def _normalize_basin_id(value: Any) -> str:
    if isinstance(value, bool):
        raise ValueError("basin identifier must be numeric text")
    text = str(value).strip()
    if not text or not text.isascii() or not text.isdigit() or len(text) > 8:
        raise ValueError(f"invalid basin identifier: {value!r}")
    return text.zfill(8)


def _parse_iso_date(value: Any, *, name: str) -> date:
    if not isinstance(value, str):
        raise ValueError(f"{name} must be an ISO calendar date")
    try:
        parsed = date.fromisoformat(value)
    except ValueError as exc:
        raise ValueError(f"invalid {name}: {value!r}") from exc
    if parsed.isoformat() != value:
        raise ValueError(f"{name} must use YYYY-MM-DD format")
    return parsed


def _inclusive_ordinals(start: date, end: date) -> set[int]:
    if end < start:
        raise ValueError("period end precedes period start")
    return set(range(start.toordinal(), end.toordinal() + 1))


def _required_period_ordinals(contract: Mapping[str, Any]) -> set[int]:
    try:
        periods = contract["periods"]
    except (KeyError, TypeError) as exc:
        raise ValueError("contract periods are missing") from exc
    required: set[int] = set()
    expected_total = 0
    for period_name in _PERIOD_NAMES:
        try:
            period = periods[period_name]
            bounds = period["input"]
            expected_day_count = int(period["day_count"])
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f"invalid {period_name} period contract") from exc
        if not isinstance(bounds, Sequence) or isinstance(bounds, (str, bytes)) or len(bounds) != 2:
            raise ValueError(f"invalid {period_name} input date range")
        start = _parse_iso_date(bounds[0], name=f"{period_name} start")
        end = _parse_iso_date(bounds[1], name=f"{period_name} end")
        ordinals = _inclusive_ordinals(start, end)
        if len(ordinals) != expected_day_count:
            raise ValueError(f"{period_name} day count does not match its date range")
        if required.intersection(ordinals):
            raise ValueError("TUKF09 input periods must not overlap")
        required.update(ordinals)
        expected_total += expected_day_count
    if len(required) != expected_total:
        raise ValueError("TUKF09 required date support is inconsistent")
    return required


def _find_basin_file(data_root: Path, subdirectory: Path, filename: str) -> Path:
    base = Path(data_root) / subdirectory
    direct = base / filename[:2] / filename
    if direct.is_file():
        return direct
    matches = sorted(path for path in base.glob(f"*/{filename}") if path.is_file())
    if not matches:
        raise FileNotFoundError(f"missing basin input file: {base}/*/{filename}")
    if len(matches) != 1:
        raise ValueError(f"ambiguous basin input file: {base}/*/{filename}")
    return matches[0]


def _valid_flow_ordinals(path: Path, required: set[int]) -> set[int]:
    counts: dict[int, int] = {}
    finite_nonnegative: dict[int, bool] = {}
    with Path(path).open("r", encoding="utf-8") as handle:
        for line in handle:
            fields = line.split()
            if len(fields) < 5:
                continue
            try:
                ordinal = date(int(fields[1]), int(fields[2]), int(fields[3])).toordinal()
            except (TypeError, ValueError):
                continue
            if ordinal not in required:
                continue
            counts[ordinal] = counts.get(ordinal, 0) + 1
            try:
                discharge = float(fields[4])
            except ValueError:
                valid = False
            else:
                valid = math.isfinite(discharge) and discharge >= 0.0
            finite_nonnegative[ordinal] = finite_nonnegative.get(ordinal, True) and valid
    return {
        ordinal
        for ordinal, count in counts.items()
        if count == 1 and finite_nonnegative.get(ordinal, False)
    }


def _valid_forcing_ordinals(path: Path, required: set[int]) -> set[int]:
    counts: dict[int, int] = {}
    finite_required_inputs: dict[int, bool] = {}
    with Path(path).open("r", encoding="utf-8") as handle:
        for line in handle:
            fields = line.split()
            # Data rows are Year, Mnth, Day, Hr, Dayl, PRCP, SRAD, SWE,
            # Tmax, Tmin, Vp.  Reading positions avoids defective headers.
            if len(fields) < 10:
                continue
            try:
                ordinal = date(int(fields[0]), int(fields[1]), int(fields[2])).toordinal()
            except (TypeError, ValueError):
                continue
            if ordinal not in required:
                continue
            counts[ordinal] = counts.get(ordinal, 0) + 1
            try:
                day_length = float(fields[4])
                precipitation = float(fields[5])
                shortwave_radiation = float(fields[6])
                maximum_temperature = float(fields[8])
                minimum_temperature = float(fields[9])
                mean_temperature = 0.5 * (maximum_temperature + minimum_temperature)
            except ValueError:
                valid = False
            else:
                valid = all(
                    math.isfinite(value)
                    for value in (
                        day_length,
                        precipitation,
                        shortwave_radiation,
                        maximum_temperature,
                        minimum_temperature,
                        mean_temperature,
                    )
                )
            finite_required_inputs[ordinal] = (
                finite_required_inputs.get(ordinal, True) and valid
            )
    return {
        ordinal
        for ordinal, count in counts.items()
        if count == 1 and finite_required_inputs.get(ordinal, False)
    }


def flow_period_is_complete(path: Path, start: str, end: str) -> bool:
    """Return whether a flow file has one valid row for each in-range day.

    Rows before ``start`` and after ``end`` are deliberately ignored, which
    enforces the 1980-10-01 eligibility boundary for the retrospective period.
    """

    first = _parse_iso_date(start, name="flow-period start")
    last = _parse_iso_date(end, name="flow-period end")
    required = _inclusive_ordinals(first, last)
    return _valid_flow_ordinals(Path(path), required) == required


def _ordered_basin_digest_newline(basin_ids: Sequence[str]) -> str:
    payload = "".join(f"{basin_id}\n" for basin_id in basin_ids).encode("utf-8")
    return sha256(payload).hexdigest()


def _ordered_basin_digest_compact_json(basin_ids: Sequence[str]) -> str:
    payload = json.dumps(
        list(basin_ids), separators=(",", ":"), ensure_ascii=False, allow_nan=False
    ).encode("utf-8")
    return sha256(payload).hexdigest()


def derive_population(
    contract: Mapping[str, Any],
    data_root: Path,
    canonical_list: Path,
) -> PopulationRegistry:
    """Derive the model-blind complete-record population in canonical order."""

    canonical_path = Path(canonical_list)
    canonical = tuple(
        _normalize_basin_id(line)
        for line in canonical_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    )
    if len(canonical) != len(set(canonical)):
        raise ValueError("canonical basin list contains duplicates")

    try:
        population = contract["population"]
        previous_raw = population["previously_evaluated_basins"]
    except (KeyError, TypeError) as exc:
        raise ValueError("population contract is missing") from exc
    if not isinstance(previous_raw, Sequence) or isinstance(previous_raw, (str, bytes)):
        raise ValueError("previously evaluated basin list is invalid")
    previously_evaluated = tuple(_normalize_basin_id(value) for value in previous_raw)
    if len(previously_evaluated) != len(set(previously_evaluated)):
        raise ValueError("previously evaluated basin list contains duplicates")
    previous_set = set(previously_evaluated)
    if not previous_set.issubset(canonical):
        raise ValueError("previously evaluated basin is absent from canonical list")

    candidates = tuple(basin for basin in canonical if basin not in previous_set)
    for key, actual in (
        ("canonical_basin_count", len(canonical)),
        ("previously_evaluated_basin_count", len(previously_evaluated)),
        ("candidate_count", len(candidates)),
    ):
        if key in population and int(population[key]) != actual:
            raise ValueError(f"derived population count does not match {key}")

    required = _required_period_ordinals(contract)
    root = Path(data_root)
    eligible_list: list[str] = []
    incomplete_list: list[str] = []
    missing_days: dict[str, int] = {}
    for basin_id in candidates:
        try:
            flow_path = _find_basin_file(
                root,
                Path("usgs_streamflow"),
                f"{basin_id}_streamflow_qc.txt",
            )
        except FileNotFoundError:
            valid_flow: set[int] = set()
        else:
            valid_flow = _valid_flow_ordinals(flow_path, required)

        try:
            forcing_path = _find_basin_file(
                root,
                Path("basin_mean_forcing") / "maurer",
                f"{basin_id}_lump_maurer_forcing_leap.txt",
            )
        except FileNotFoundError:
            valid_forcing: set[int] = set()
        else:
            valid_forcing = _valid_forcing_ordinals(forcing_path, required)

        complete_dates = valid_flow.intersection(valid_forcing)
        missing_count = len(required) - len(complete_dates)
        missing_days[basin_id] = missing_count
        if missing_count == 0:
            eligible_list.append(basin_id)
        else:
            incomplete_list.append(basin_id)

    eligible = tuple(eligible_list)
    date_incomplete = tuple(incomplete_list)
    for key, actual in (
        ("primary_basin_count", len(eligible)),
        ("date_incomplete_exclusion_count", len(date_incomplete)),
    ):
        if key in population and int(population[key]) != actual:
            raise ValueError(f"derived population count does not match {key}")

    expected_newline_digest = population.get("eligible_ordered_newline_utf8_sha256")
    if (
        expected_newline_digest is not None
        and _ordered_basin_digest_newline(eligible) != expected_newline_digest
    ):
        raise ValueError("eligible basin order or newline digest changed")
    expected_json_digest = population.get("eligible_compact_json_sha256")
    if (
        expected_json_digest is not None
        and _ordered_basin_digest_compact_json(eligible) != expected_json_digest
    ):
        raise ValueError("eligible basin order or compact-JSON digest changed")

    return PopulationRegistry(
        canonical=canonical,
        previously_evaluated=previously_evaluated,
        candidates=candidates,
        eligible=eligible,
        date_incomplete=date_incomplete,
        missing_days_by_basin=missing_days,
    )


def load_parameter_only_table(
    csv_path: Path,
    basin_ids: Sequence[str],
) -> ParameterOnlyTable:
    """Load only the thirteen physical parameters for the requested basins."""

    requested = tuple(_normalize_basin_id(value) for value in basin_ids)
    if len(requested) != len(set(requested)):
        raise ValueError("requested basin identifiers must be unique")
    required_columns = ("basin_id",) + tuple(f"p_{name}" for name in PARAMETER_NAMES)
    selected: dict[str, tuple[float, ...]] = {}
    with Path(csv_path).open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        fieldnames = tuple(reader.fieldnames or ())
        missing_columns = [column for column in required_columns if column not in fieldnames]
        if missing_columns:
            raise KeyError(f"parameter CSV is missing required columns: {missing_columns}")
        requested_set = set(requested)
        for row in reader:
            basin_id = _normalize_basin_id(row["basin_id"])
            if basin_id not in requested_set:
                continue
            if basin_id in selected:
                raise ValueError(f"duplicate requested basin in parameter CSV: {basin_id}")
            try:
                values = tuple(float(row[f"p_{name}"]) for name in PARAMETER_NAMES)
            except (TypeError, ValueError) as exc:
                raise ValueError(f"invalid physical parameters for basin {basin_id}") from exc
            if not all(math.isfinite(value) for value in values):
                raise ValueError(f"non-finite physical parameters for basin {basin_id}")
            selected[basin_id] = values

    absent = [basin_id for basin_id in requested if basin_id not in selected]
    if absent:
        raise KeyError(f"requested basins are absent from parameter CSV: {absent}")
    matrix = np.asarray([selected[basin_id] for basin_id in requested], dtype=np.float64)
    if not requested:
        matrix = np.empty((0, len(PARAMETER_NAMES)), dtype=np.float64)
    return ParameterOnlyTable(
        basin_ids=requested,
        parameter_names=PARAMETER_NAMES,
        values=matrix,
    )


def _parameter_value(parameter_row: Mapping[str, float], name: str) -> float:
    if name in parameter_row:
        raw_value = parameter_row[name]
    elif f"p_{name}" in parameter_row:
        raw_value = parameter_row[f"p_{name}"]
    else:
        raise KeyError(f"parameter row is missing {name}")
    value = float(raw_value)
    if not math.isfinite(value):
        raise ValueError(f"parameter {name} must be finite")
    return value


def routed_state_dimension(parameter_row: Mapping[str, float]) -> int:
    """Return five HBV storages plus the causal routed first-in-first-out queue."""

    lag_time = _parameter_value(parameter_row, "lag_time")
    return 5 + max(1, math.ceil(lag_time))


def default_routed_initial_state(parameter_row: Mapping[str, float]) -> np.ndarray:
    """Build the frozen period-local state without saved 2008 state columns."""

    field_capacity = _parameter_value(parameter_row, "parFC")
    if field_capacity <= 0.0:
        raise ValueError("parFC must be positive")
    dimension = routed_state_dimension(parameter_row)
    state = np.zeros(dimension, dtype=np.float64)
    state[2] = 0.3 * field_capacity
    state[3] = 5.0
    state[4] = 10.0
    state.setflags(write=False)
    return state


def _strict_nonnegative_integer(value: Any, *, name: str) -> int:
    if isinstance(value, bool):
        raise ValueError(f"{name} must be an integer")
    try:
        integer = operator.index(value)
    except TypeError as exc:
        raise ValueError(f"{name} must be an integer") from exc
    integer = int(integer)
    if integer < 0:
        raise ValueError(f"{name} must be nonnegative")
    return integer


def scored_target_indices(
    day_count: int,
    lead_days: int,
    warmup_days: int = 365,
) -> np.ndarray:
    """Return the deterministic common target-index support for one lead."""

    total = _strict_nonnegative_integer(day_count, name="day_count")
    warmup = _strict_nonnegative_integer(warmup_days, name="warmup_days")
    lead = _strict_nonnegative_integer(lead_days, name="lead_days")
    if lead not in (1, 2, 3):
        raise ValueError("lead must be 1, 2, or 3 days")
    stop = total - (3 - lead)
    indices = np.arange(warmup, max(warmup, stop), dtype=np.int64)
    indices.setflags(write=False)
    return indices


__all__ = [
    "EXPERIMENT_ID",
    "PARAMETER_NAMES",
    "ParameterOnlyTable",
    "PopulationRegistry",
    "default_routed_initial_state",
    "derive_population",
    "flow_period_is_complete",
    "load_contract",
    "load_parameter_only_table",
    "routed_state_dimension",
    "scored_target_indices",
]
