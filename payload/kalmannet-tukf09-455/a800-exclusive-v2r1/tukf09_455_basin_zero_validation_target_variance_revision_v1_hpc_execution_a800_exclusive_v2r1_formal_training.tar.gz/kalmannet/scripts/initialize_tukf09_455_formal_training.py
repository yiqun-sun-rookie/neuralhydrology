"""Atomically initialize the absent 455-basin formal-training result root."""
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
import sys
from typing import Any, Mapping

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import tukf09_455_training_common as common
from scripts import tukf09_455_training_profile as profile


def _snapshot_record(content: bytes) -> dict[str, Any]:
    return {
        "sha256": hashlib.sha256(content).hexdigest(),
        "size_bytes": len(content),
    }


def _context_payload(
    *,
    admission: Mapping[str, Any],
    snapshots: Mapping[str, bytes],
) -> dict[str, Any]:
    authorization = admission.get("authorization", {})
    evaluation = admission.get("evaluation_identity", {})
    migration = admission.get("filter_migration_final_manifest", {})
    return {
        "schema_version": profile.TRAINING_CONTEXT_SCHEMA,
        "experiment_id": profile.EXPERIMENT_ID,
        "status": (
            "TRAINING_ROOT_INITIALIZED_FILTER_REBINDING_PENDING_EVALUATION_HOLD"
        ),
        "formal_evaluation_authorized": False,
        "output_root": profile.OUTPUT_RELATIVE.as_posix(),
        "scientific_contract_sha256": admission.get("scientific_contract_sha256"),
        "preflight_final_manifest_sha256": admission.get(
            "preflight_final_manifest_sha256"
        ),
        "filter_migration_final_manifest_sha256": migration.get("sha256"),
        "authorization_file_sha256": authorization.get("file_sha256"),
        "training_admission_record_sha256": admission.get(
            "training_admission_record_sha256"
        ),
        "evaluation_identity_only_sha256": evaluation.get(
            "identity_only_sha256"
        ),
        "access_ledger": {
            "evaluation_array_reads": 0,
            "evaluation_predictions": 0,
            "evaluation_metrics": 0,
            "evaluation_outputs": 0,
        },
        "initial_member_count": 5,
        "snapshots": {
            name: _snapshot_record(content)
            for name, content in sorted(snapshots.items())
        },
    }


def initialize_formal_training(
    *,
    initialize: bool,
    project_root: Path = ROOT,
) -> dict[str, Any]:
    # The mutation gate must run before admission or snapshot bytes are read.
    if initialize is not True:
        raise PermissionError("explicit formal training initialization is required")
    root = Path(project_root)
    output = root / profile.OUTPUT_RELATIVE
    if common.path_exists_including_broken_link(output):
        raise FileExistsError("formal training result root already exists")
    execution_path = root / profile.FORMAL_TRAINING_CONFIG_RELATIVE
    admission_path = root / profile.ADMISSION_RELATIVE
    admission = common.load_and_verify_training_admission(
        admission_path,
        execution_path,
        tuple(root / value for value in common.REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS),
    )
    sources = {
        "scientific_contract.snapshot.json": root / profile.CONTRACT_RELATIVE,
        "authorization.snapshot.json": root / profile.AUTHORIZATION_RELATIVE,
        "execution_config.snapshot.json": execution_path,
        "training_admission.snapshot.json": admission_path,
    }
    snapshots = {
        name: common.require_regular_unlinked_file(
            path, label="formal training trust source", stop_at=root
        ).read_bytes()
        for name, path in sources.items()
    }
    context = _context_payload(admission=admission, snapshots=snapshots)
    payloads = dict(snapshots)
    payloads["training_context.json"] = common.canonical_json_bytes(context)
    common.atomic_publish_directory(output, payloads)
    verified = common.verify_initialized_training_root(
        output_root=output,
        config_path=sources["scientific_contract.snapshot.json"],
        authorization=sources["authorization.snapshot.json"],
        execution_config=execution_path,
        training_admission=admission_path,
        training_admission_record=admission,
    )
    if verified != context:
        raise RuntimeError("initialized formal training context changed after publication")
    return verified


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--initialize", action="store_true")
    return parser


def main() -> None:
    args = _parser().parse_args()
    context = initialize_formal_training(initialize=bool(args.initialize))
    print(context["status"])


if __name__ == "__main__":
    main()
