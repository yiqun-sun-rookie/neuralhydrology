"""Read-only trust gates shared by the 455-basin training chain.

The module deliberately exposes only training and validation array loading.
Evaluation members are retained as hashes and counts, never as arrays.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import time
from typing import Any, Mapping, Sequence

import numpy as np

from scripts import tukf09_455_training_profile as profile
from scripts import tukf09_training_common as parent_common


EXPERIMENT_ID = profile.EXPERIMENT_ID
EXACT_AUTHORIZATION_TEXT = profile.EXACT_AUTHORIZATION_TEXT
CONFIG_RELATIVE = profile.CONTRACT_RELATIVE
PREFLIGHT_FINAL_RELATIVE = profile.PREFLIGHT_FINAL_RELATIVE
AUTHORIZATION_RELATIVE = profile.AUTHORIZATION_RELATIVE
ADMISSION_RELATIVE = profile.ADMISSION_RELATIVE
OUTPUT_RELATIVE = profile.OUTPUT_RELATIVE
FORMAL_TRAINING_CONFIG_RELATIVE = profile.FORMAL_TRAINING_CONFIG_RELATIVE
FILTER_MIGRATION_FINAL_RELATIVE = profile.FILTER_MIGRATION_FINAL_RELATIVE
FILTER_INSTALLATION_FINAL_RELATIVE = profile.FILTER_INSTALLATION_FINAL_RELATIVE
TRAINING_PERIOD_NAMES = ("training", "validation")
SEMANTIC_ARRAY_NAMES = ("dates_ns", "forcing", "observations")

# This is the exact set hashed by the technical admission.  It intentionally
# includes future evaluation code: evaluation arrays remain inaccessible, but
# the code that will later consume them is frozen before any model training.
REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS = (
    "scripts/admit_tukf09_455_formal_training.py",
    "scripts/admit_tukf09_455_formal_evaluation.py",
    "scripts/evaluate_tukf09_455_basin_revision.py",
    "scripts/initialize_tukf09_455_formal_training.py",
    "scripts/install_tukf09_455_filter_results.py",
    "scripts/migrate_tukf09_455_filter_results.py",
    "scripts/register_tukf09_455_all_scope_authorization.py",
    "scripts/register_tukf09_455_formal_evaluation_authorization.py",
    "scripts/run_aligned_gr4j_da.py",
    "scripts/run_aligned_gr4j_differentiable_ukf.py",
    "scripts/run_tukf09_455_formal_training_sequence.py",
    "scripts/run_tukf09_455_neural_training.py",
    "scripts/run_tukf09_455_neural_training_controller.py",
    "scripts/run_tukf09_filter_training.py",
    "scripts/seal_tukf09_455_training_selection.py",
    "scripts/tukf07_information_matched_model.py",
    "scripts/tukf09_455_training_common.py",
    "scripts/tukf09_455_training_controller_common.py",
    "scripts/tukf09_455_training_profile.py",
    "scripts/tukf09_455_evaluation_common.py",
    "scripts/tukf09_confirmatory_common.py",
    "scripts/tukf09_training_controller_common.py",
    "scripts/tukf09_training_common.py",
    "scripts/verify_tukf09_455_basin_zero_validation_target_variance_preflight.py",
    "scripts/verify_tukf09_455_filter_installation.py",
    "scripts/verify_tukf09_455_filter_migration.py",
    "scripts/verify_tukf09_455_filter_rebinding_controller.py",
    "scripts/verify_tukf09_455_basin_evaluation.py",
    "scripts/verify_tukf09_455_training_selection.py",
    "src/global_hydrology/assimilation/conventional_ukf.py",
)

canonical_json_bytes = parent_common.canonical_json_bytes
canonical_json_sha256 = parent_common.canonical_json_sha256
sha256_file = parent_common.sha256_file
path_exists_including_broken_link = parent_common.path_exists_including_broken_link
ensure_within = parent_common.ensure_within
ensure_no_symlink_components = parent_common.ensure_no_symlink_components
require_regular_unlinked_file = parent_common.require_regular_unlinked_file
atomic_write_bytes_exclusive = parent_common.atomic_write_bytes_exclusive
atomic_write_json_exclusive = parent_common.atomic_write_json_exclusive
atomic_publish_directory = parent_common.atomic_publish_directory
runtime_environment_identity = parent_common.runtime_environment_identity
validate_runtime_environment_identity = parent_common.validate_runtime_environment_identity
PeriodIdentity = parent_common.PeriodIdentity
PeriodArrays = parent_common.PeriodArrays
gate_training_period_only = parent_common.gate_training_period_only


def read_json_strict(path: str | Path) -> dict[str, Any]:
    return parent_common.read_json_strict(path)


def _absolute(path: str | Path) -> Path:
    return Path(os.path.abspath(os.fspath(path)))


def _same_path(left: str | Path, right: str | Path) -> bool:
    return os.path.normcase(os.fspath(_absolute(left))) == os.path.normcase(
        os.fspath(_absolute(right))
    )


def _project_root_from_config(config: str | Path) -> Path:
    candidate = _absolute(config)
    if candidate.parent.name != "configs":
        raise ValueError("scientific contract must be in the fixed configs directory")
    return candidate.parent.parent


def _fixed_file(
    supplied: str | Path,
    project_root: Path,
    relative: Path,
    *,
    label: str,
) -> Path:
    expected = project_root / relative
    if not _same_path(supplied, expected):
        raise ValueError(f"{label} differs from its fixed path")
    return require_regular_unlinked_file(expected, label=label, stop_at=project_root)


def _validate_timestamp(value: Any) -> str:
    if not isinstance(value, str):
        raise ValueError("timestamp must be a string")
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("timestamp must include a UTC offset")
    return value


@dataclass(frozen=True)
class VerifiedAuthorization:
    record: Mapping[str, Any]
    authorization_path: Path
    authorization_file_sha256: str
    contract_sha256: str
    preflight_final_manifest_sha256: str
    output_root: Path
    project_root: Path


@dataclass(frozen=True)
class TrainingAdmissionContext:
    experiment_id: str
    project_root: Path
    output_root: Path
    preflight_root: Path
    data_root: Path
    authorization: VerifiedAuthorization
    contract: Mapping[str, Any]
    contract_sha256: str
    preflight_final_manifest_sha256: str
    source_anchor_sha256: Mapping[str, str]
    raw_source_files: Mapping[str, Mapping[str, Any]]
    ordered_basin_ids: tuple[str, ...]
    parameter_names: tuple[str, ...]
    parameter_values: np.ndarray
    periods: Mapping[str, PeriodIdentity]
    semantic_members: Mapping[str, Mapping[str, Mapping[str, Any]]]
    training_semantic_sha256: str
    validation_semantic_sha256: str
    evaluation_identity_count: int
    evaluation_identity_sha256: str
    access_ledger: Mapping[str, int]

    @property
    def evaluation_access_count(self) -> int:
        return sum(int(value) for value in self.access_ledger.values())

    @property
    def population_sha256(self) -> str:
        return profile.ORDERED_BASIN_NEWLINE_SHA256

    @property
    def source_hashes(self) -> Mapping[str, str]:
        return self.source_anchor_sha256

    @property
    def raw_source_hashes(self) -> Mapping[str, str]:
        return {
            str(path): str(record["sha256"])
            for path, record in self.raw_source_files.items()
        }


@dataclass(frozen=True)
class FilterInstallationAdmission:
    experiment_id: str
    unit_count: int
    unit_file_count: int
    training_admission_record_sha256: str
    training_admission_file_sha256: str
    filter_migration_final_sha256: str
    filter_installation_final_sha256: str
    evaluation_access_count: int


def _strict_file_record(path: Path, *, root: Path, label: str) -> dict[str, Any]:
    source = require_regular_unlinked_file(path, label=label, stop_at=root)
    return {"sha256": sha256_file(source), "size_bytes": int(source.stat().st_size)}


def _require_plain_directory(path: Path, *, label: str) -> Path:
    target = Path(path)
    if not target.is_dir() or target.is_symlink():
        raise RuntimeError(f"{label} must be a regular non-reparse directory")
    status = os.lstat(target)
    attributes = int(getattr(status, "st_file_attributes", 0))
    reparse_flag = int(getattr(status, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))
    if attributes & reparse_flag:
        raise RuntimeError(f"{label} must be a regular non-reparse directory")
    return target


def _canonical_json_object(path: Path, *, root: Path, label: str) -> dict[str, Any]:
    source = require_regular_unlinked_file(path, label=label, stop_at=root)
    raw = source.read_bytes()
    record = read_json_strict(source)
    if raw != canonical_json_bytes(record):
        raise RuntimeError(f"{label} is not canonical JSON")
    return record


def _verify_installed_filter_unit_semantics(
    *,
    output_root: Path,
    basin_id: str,
    final_files: Mapping[str, Any],
) -> str:
    """Recheck one installed six-file unit without loading hydrological arrays."""

    unit_root = _require_plain_directory(
        output_root / "filter" / f"basin_{basin_id}",
        label=f"installed filter unit {basin_id}",
    )
    expected_members = {
        "identity.json",
        "history.npz",
        "selection.json",
        "access_ledger.json",
        "migration_provenance.json",
        "manifest.sha256.json",
    }
    if {member.name for member in unit_root.iterdir()} != expected_members:
        raise RuntimeError(f"installed filter unit member set changed: {basin_id}")

    prefix = f"filter/basin_{basin_id}/"
    for member_name in sorted(expected_members):
        relative = prefix + member_name
        if final_files.get(relative) != _strict_file_record(
            unit_root / member_name,
            root=output_root,
            label=f"installed filter unit member {relative}",
        ):
            raise RuntimeError(f"installed filter unit member changed: {relative}")

    identity = _canonical_json_object(
        unit_root / "identity.json", root=output_root, label="installed filter identity"
    )
    selection = _canonical_json_object(
        unit_root / "selection.json", root=output_root, label="installed filter selection"
    )
    ledger = _canonical_json_object(
        unit_root / "access_ledger.json",
        root=output_root,
        label="installed filter access ledger",
    )
    provenance = _canonical_json_object(
        unit_root / "migration_provenance.json",
        root=output_root,
        label="installed filter migration provenance",
    )
    manifest = _canonical_json_object(
        unit_root / "manifest.sha256.json",
        root=output_root,
        label="installed filter unit manifest",
    )
    if (
        identity.get("schema_version")
        != "tukf09_455_rebound_filter_unit_identity_v1"
        or identity.get("experiment_id") != EXPERIMENT_ID
        or identity.get("unit_type") != "filter_basin"
        or identity.get("unit_id") != basin_id
        or selection.get("schema_version")
        != "tukf09_455_rebound_filter_unit_selection_v1"
        or selection.get("experiment_id") != EXPERIMENT_ID
        or selection.get("unit_type") != "filter_basin"
        or selection.get("unit_id") != basin_id
        or selection.get("status") != "FILTER_BASIN_REBOUND_FROM_VERIFIED_PARENT"
        or selection.get("checkpoint_count") != 256
        or selection.get("training_query_count") != 256
        or selection.get("validation_query_count") != 256
        or selection.get("filter_pass_count") != 512
        or selection.get("gradient_update_count") != 248
        or ledger.get("schema_version")
        != "tukf09_455_rebound_filter_unit_access_ledger_v1"
        or ledger.get("experiment_id") != EXPERIMENT_ID
        or ledger.get("unit_type") != "filter_basin"
        or ledger.get("unit_id") != basin_id
        or ledger.get("training_period_loaded") is not True
        or ledger.get("validation_period_loaded") is not True
        or ledger.get("formal_evaluation_authorized") is not False
        or ledger.get("new_filter_optimization_count") != 0
        or provenance.get("schema_version")
        != "tukf09_455_filter_unit_migration_provenance_v1"
        or provenance.get("experiment_id") != EXPERIMENT_ID
        or provenance.get("unit_id") != basin_id
        or provenance.get("history_byte_identity_required") is not True
        or provenance.get("selection_numeric_identity_required") is not True
        or manifest.get("schema_version")
        != "tukf09_455_rebound_filter_unit_manifest_v1"
        or manifest.get("experiment_id") != EXPERIMENT_ID
        or manifest.get("unit_type") != "filter_basin"
        or manifest.get("unit_id") != basin_id
        or manifest.get("file_count") != 5
    ):
        raise RuntimeError(f"installed filter unit semantic identity changed: {basin_id}")
    zero_evaluation_fields = (
        "evaluation_array_read_count",
        "evaluation_prediction_count",
        "evaluation_metric_count",
        "evaluation_output_write_count",
    )
    if any(type(ledger.get(name)) is not int or ledger.get(name) != 0 for name in zero_evaluation_fields):
        raise PermissionError(f"installed filter unit records evaluation access: {basin_id}")
    expected_manifest_members = expected_members - {"manifest.sha256.json"}
    manifest_files = manifest.get("files")
    if not isinstance(manifest_files, dict) or set(manifest_files) != expected_manifest_members:
        raise RuntimeError(f"installed filter unit manifest member set changed: {basin_id}")
    if any(
        manifest_files[name] != final_files[prefix + name]
        for name in expected_manifest_members
    ):
        raise RuntimeError(f"installed filter unit manifest hashes changed: {basin_id}")
    return str(final_files[prefix + "manifest.sha256.json"]["sha256"])


def verify_filter_installation_final_for_neural(
    *,
    output_root: str | Path,
    training_admission: str | Path,
    training_admission_record: Mapping[str, Any],
) -> FilterInstallationAdmission:
    """Rehash the complete installed-filter seal before any neural operation."""

    output = _absolute(output_root)
    if not output.is_dir() or output.is_symlink():
        raise RuntimeError("initialized formal training result root is required")
    final_relative = FILTER_INSTALLATION_FINAL_RELATIVE.relative_to(OUTPUT_RELATIVE)
    final_path = output / final_relative
    if not final_path.is_file():
        raise RuntimeError("filter installation final manifest is required before neural training")
    final_path = require_regular_unlinked_file(
        final_path, label="filter installation final manifest", stop_at=output
    )
    final_raw = final_path.read_bytes()
    final = read_json_strict(final_path)
    if final_raw != canonical_json_bytes(final):
        raise RuntimeError("filter installation final manifest is not canonical JSON")
    files = final.get("files")
    if (
        final.get("schema_version")
        != "tukf09_455_filter_installation_final_manifest_v1"
        or final.get("experiment_id") != EXPERIMENT_ID
        or final.get("status")
        != "FILTER_REBINDING_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
        or not isinstance(files, dict)
        or final.get("file_count") != 455 * 6 + 2
        or len(files) != 455 * 6 + 2
    ):
        raise RuntimeError("filter installation final manifest identity or count changed")

    seal_relative = "control/filter_rebinding/filter_rebinding.sealed.json"
    audit_relative = "control/filter_rebinding/independent/independent_audit.json"
    seal_path = output / PurePosixPath(seal_relative)
    audit_path = output / PurePosixPath(audit_relative)
    seal = read_json_strict(
        require_regular_unlinked_file(
            seal_path, label="filter installation seal", stop_at=output
        )
    )
    audit = read_json_strict(
        require_regular_unlinked_file(
            audit_path, label="filter installation independent audit", stop_at=output
        )
    )
    if seal_path.read_bytes() != canonical_json_bytes(seal) or audit_path.read_bytes() != canonical_json_bytes(audit):
        raise RuntimeError("filter installation seal or audit is not canonical JSON")

    admission_record_sha256 = training_admission_record.get(
        "training_admission_record_sha256"
    )
    migration_reference = training_admission_record.get(
        "filter_migration_final_manifest", {}
    )
    if (
        not isinstance(admission_record_sha256, str)
        or re.fullmatch(r"[0-9a-f]{64}", admission_record_sha256) is None
        or not isinstance(migration_reference, Mapping)
        or re.fullmatch(
            r"[0-9a-f]{64}", str(migration_reference.get("sha256", ""))
        )
        is None
    ):
        raise RuntimeError("training admission lacks migration or record SHA-256 binding")
    admission_source = require_regular_unlinked_file(
        Path(training_admission), label="training admission", stop_at=Path(training_admission).parent
    )
    admission_raw = admission_source.read_bytes()
    admission_payload = read_json_strict(admission_source)
    if (
        admission_raw != canonical_json_bytes(admission_payload)
        or dict(admission_payload) != dict(training_admission_record)
        or admission_payload.get("schema_version") != profile.TRAINING_ADMISSION_SCHEMA
        or admission_payload.get("experiment_id") != EXPERIMENT_ID
        or admission_payload.get("status")
        != "NEURAL_TRAINING_ADMITTED_FILTER_REBINDING_INSTALLATION_PENDING_EVALUATION_HOLD"
        or admission_payload.get("formal_evaluation_authorized") is not False
    ):
        raise RuntimeError("filter installation training-admission binding changed")
    unsigned_admission = dict(admission_payload)
    stored_admission_record_sha256 = unsigned_admission.pop(
        "training_admission_record_sha256", None
    )
    if (
        stored_admission_record_sha256 != admission_record_sha256
        or hashlib.sha256(canonical_json_bytes(unsigned_admission)).hexdigest()
        != admission_record_sha256
    ):
        raise RuntimeError("filter installation training-admission record hash changed")
    admission_ledger = admission_payload.get("access_ledger")
    if not isinstance(admission_ledger, dict) or any(
        type(admission_ledger.get(name)) is not int
        or admission_ledger.get(name) != 0
        for name in (
            "evaluation_array_reads",
            "evaluation_predictions",
            "evaluation_metrics",
            "evaluation_outputs",
        )
    ):
        raise PermissionError("filter installation training admission records evaluation access")
    admission_file_sha256 = sha256_file(admission_source)
    migration_sha256 = str(migration_reference["sha256"])
    basin_ids = seal.get("ordered_basin_ids")
    if (
        seal.get("schema_version") != "tukf09_455_filter_rebinding_seal_v1"
        or seal.get("experiment_id") != EXPERIMENT_ID
        or seal.get("status") != "FILTER_REBINDING_INSTALLED_455_EVALUATION_HOLD"
        or not isinstance(basin_ids, list)
        or len(basin_ids) != profile.ORDERED_BASIN_COUNT
        or len(set(basin_ids)) != profile.ORDERED_BASIN_COUNT
        or any(
            not isinstance(value, str) or re.fullmatch(r"[0-9]{8}", value) is None
            for value in basin_ids
        )
        or _ordered_newline_digest(basin_ids) != profile.ORDERED_BASIN_NEWLINE_SHA256
        or seal.get("unit_count") != profile.ORDERED_BASIN_COUNT
        or seal.get("unit_file_count") != profile.ORDERED_BASIN_COUNT * 6
        or seal.get("training_admission_sha256") != admission_file_sha256
        or seal.get("migration_final_manifest_sha256") != migration_sha256
        or seal.get("inherited_checkpoint_count") != profile.ORDERED_BASIN_COUNT * 256
        or seal.get("inherited_gradient_update_count") != profile.ORDERED_BASIN_COUNT * 248
        or seal.get("new_filter_optimization_count") != 0
        or seal.get("new_filter_objective_count") != 0
        or seal.get("new_filter_gradient_update_count") != 0
        or seal.get("evaluation_access_count") != 0
        or audit.get("schema_version")
        != "tukf09_455_filter_installation_independent_audit_v1"
        or audit.get("experiment_id") != EXPERIMENT_ID
        or audit.get("status")
        != "FILTER_REBINDING_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
        or audit.get("unit_count") != profile.ORDERED_BASIN_COUNT
        or audit.get("unit_file_count") != profile.ORDERED_BASIN_COUNT * 6
        or audit.get("training_admission_sha256") != admission_file_sha256
        or audit.get("migration_final_manifest_sha256") != migration_sha256
        or audit.get("new_filter_optimization_count") != 0
        or audit.get("evaluation_access_count") != 0
    ):
        raise RuntimeError("filter installation seal, audit, migration, or admission binding changed")

    unit_members = {
        "identity.json",
        "history.npz",
        "selection.json",
        "access_ledger.json",
        "migration_provenance.json",
        "manifest.sha256.json",
    }
    expected_paths = {
        f"filter/basin_{basin}/{member}"
        for basin in basin_ids
        for member in unit_members
    } | {seal_relative, audit_relative}
    if set(files) != expected_paths:
        raise RuntimeError("filter installation final manifest member set changed")
    for relative in sorted(expected_paths):
        recorded = files.get(relative)
        if (
            not isinstance(recorded, dict)
            or set(recorded) != {"sha256", "size_bytes"}
            or recorded
            != _strict_file_record(
                output / PurePosixPath(relative),
                root=output,
                label=f"installed filter evidence {relative}",
            )
        ):
            raise RuntimeError(f"installed filter evidence changed: {relative}")

    filter_root = _require_plain_directory(
        output / "filter", label="installed filter population root"
    )
    if {member.name for member in filter_root.iterdir()} != {
        f"basin_{basin}" for basin in basin_ids
    }:
        raise RuntimeError("installed filter population topology changed")
    independently_rebuilt_manifest_map = {
        basin: _verify_installed_filter_unit_semantics(
            output_root=output,
            basin_id=basin,
            final_files=files,
        )
        for basin in basin_ids
    }
    manifest_map = seal.get("unit_manifest_sha256_by_basin")
    if (
        not isinstance(manifest_map, dict)
        or set(manifest_map) != set(basin_ids)
        or manifest_map != independently_rebuilt_manifest_map
        or seal.get("unit_manifest_map_sha256") != canonical_json_sha256(manifest_map)
        or audit.get("unit_manifest_map_sha256") != canonical_json_sha256(manifest_map)
        or any(
            manifest_map[basin]
            != files[f"filter/basin_{basin}/manifest.sha256.json"]["sha256"]
            for basin in basin_ids
        )
    ):
        raise RuntimeError("filter installation unit-manifest map changed")
    return FilterInstallationAdmission(
        experiment_id=EXPERIMENT_ID,
        unit_count=profile.ORDERED_BASIN_COUNT,
        unit_file_count=profile.ORDERED_BASIN_COUNT * 6,
        training_admission_record_sha256=admission_record_sha256,
        training_admission_file_sha256=admission_file_sha256,
        filter_migration_final_sha256=migration_sha256,
        filter_installation_final_sha256=sha256_file(final_path),
        evaluation_access_count=0,
    )


def _read_sequence_events(path: Path) -> list[dict[str, Any]]:
    source = require_regular_unlinked_file(
        path, label="formal training sequence event log", stop_at=path.parents[2]
    )
    raw = source.read_bytes()
    if not raw or not raw.endswith(b"\n"):
        raise PermissionError("top-level sequence event log is absent or incomplete")
    records: list[dict[str, Any]] = []
    for number, line in enumerate(raw.splitlines(keepends=True), start=1):
        try:
            record = json.loads(line.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise PermissionError("top-level sequence event log is invalid") from exc
        if (
            not isinstance(record, dict)
            or line != canonical_json_bytes(record)
            or record.get("schema_version") != "tukf09_formal_training_sequence_event_v1"
            or record.get("experiment_id") != EXPERIMENT_ID
            or record.get("sequence") != number
        ):
            raise PermissionError("top-level sequence event identity or order changed")
        records.append(record)
    return records


def verify_neural_sequence_process_chain(
    *,
    output_root: str | Path,
    training_admission_record_sha256: str,
    filter_installation_final_sha256: str,
    role: str,
    wait_seconds: float = 10.0,
) -> dict[str, Any]:
    """Prove the current process belongs to the live fixed top-level sequence."""

    if role not in {"neural_controller", "neural_unit"}:
        raise ValueError("unknown neural sequence role")
    if (
        re.fullmatch(r"[0-9a-f]{64}", str(training_admission_record_sha256)) is None
        or re.fullmatch(r"[0-9a-f]{64}", str(filter_installation_final_sha256)) is None
    ):
        raise PermissionError("neural sequence binding SHA-256 is invalid")
    output = _absolute(output_root)
    lock = output / "control" / ".sequence_controller.lock"
    if not lock.is_dir() or lock.is_symlink() or {path.name for path in lock.iterdir()} != {"owner.json"}:
        raise PermissionError("live top-level sequence owner is required")
    owner_path = require_regular_unlinked_file(
        lock / "owner.json", label="top-level sequence owner", stop_at=output
    )
    owner_raw = owner_path.read_bytes()
    owner = read_json_strict(owner_path)
    if (
        owner_raw != canonical_json_bytes(owner)
        or set(owner)
        != {"schema_version", "experiment_id", "execution_id", "process_id", "started_at_utc"}
        or owner.get("schema_version") != "tukf09_formal_training_sequence_owner_v1"
        or owner.get("experiment_id") != EXPERIMENT_ID
        or re.fullmatch(r"[0-9a-f]{32}", str(owner.get("execution_id", ""))) is None
        or type(owner.get("process_id")) is not int
        or owner["process_id"] <= 0
        or not isinstance(owner.get("started_at_utc"), str)
    ):
        raise PermissionError("top-level sequence owner identity changed")
    from scripts import tukf09_455_training_controller_common as process_common

    if not process_common.process_is_alive(int(owner["process_id"])):
        raise PermissionError("top-level sequence owner process is not alive")
    current_process_id = os.getpid()
    parent_process_id = os.getppid()
    if role == "neural_controller" and parent_process_id != int(owner["process_id"]):
        raise PermissionError("neural controller was not launched by the top-level sequence")

    events_path = output / "control" / "formal_training_sequence" / "events.jsonl"
    deadline = time.monotonic() + max(0.0, float(wait_seconds))
    scoped: list[dict[str, Any]] = []
    while True:
        if events_path.is_file():
            records = _read_sequence_events(events_path)
            scoped = [
                record
                for record in records
                if record.get("execution_id") == owner["execution_id"]
            ]
        neural_started = [
            record
            for record in scoped
            if record.get("event") == "stage_started"
            and record.get("stage") == "neural"
        ]
        expected_stage_process = (
            current_process_id if role == "neural_controller" else parent_process_id
        )
        if any(
            record.get("stage_process_id") == expected_stage_process
            for record in neural_started
        ):
            break
        if time.monotonic() >= deadline:
            raise PermissionError("top-level sequence did not authorize this neural process")
        time.sleep(0.01)
    sequence_started = [
        record for record in scoped if record.get("event") == "sequence_started"
    ]
    filter_completed = [
        record
        for record in scoped
        if record.get("event") == "stage_completed"
        and record.get("stage") == "verify_filter_rebinding"
    ]
    matching_neural = [
        record
        for record in neural_started
        if record.get("stage_process_id") == expected_stage_process
    ]
    if (
        len(sequence_started) != 1
        or sequence_started[0].get("controller_process_id") != owner["process_id"]
        or sequence_started[0].get("training_admission_record_sha256")
        != training_admission_record_sha256
        or len(filter_completed) != 1
        or filter_completed[0].get("exit_code") != 0
        or filter_completed[0].get("completion_status")
        != "FILTER_REBINDING_VERIFIED_EVALUATION_HOLD"
        or filter_completed[0].get("training_admission_record_sha256")
        != training_admission_record_sha256
        or len(matching_neural) != 1
        or matching_neural[0].get("training_admission_record_sha256")
        != training_admission_record_sha256
        or filter_completed[0]["sequence"] >= matching_neural[0]["sequence"]
    ):
        raise PermissionError("top-level filter-to-neural stage order or admission binding changed")
    if role == "neural_unit" and not process_common.process_is_alive(parent_process_id):
        raise PermissionError("neural unit parent controller is not alive")
    return {
        "experiment_id": EXPERIMENT_ID,
        "sequence_execution_id": str(owner["execution_id"]),
        "sequence_process_id": int(owner["process_id"]),
        "neural_controller_process_id": int(expected_stage_process),
        "current_process_id": int(current_process_id),
        "training_admission_record_sha256": str(training_admission_record_sha256),
        "filter_installation_final_sha256": str(filter_installation_final_sha256),
    }


def load_and_verify_authorization(
    path: str | Path,
    config: str | Path,
    preflight: str | Path,
    output_root: str | Path,
) -> VerifiedAuthorization:
    project_root = _project_root_from_config(config)
    config_path = _fixed_file(
        config, project_root, CONFIG_RELATIVE, label="scientific contract"
    )
    preflight_path = _fixed_file(
        preflight,
        project_root,
        PREFLIGHT_FINAL_RELATIVE,
        label="independent preflight final manifest",
    )
    authorization_path = _fixed_file(
        path, project_root, AUTHORIZATION_RELATIVE, label="all-scope authorization"
    )
    expected_output = project_root / OUTPUT_RELATIVE
    if not _same_path(output_root, expected_output):
        raise ValueError("formal training output root differs from its fixed path")
    raw = authorization_path.read_bytes()
    record = read_json_strict(authorization_path)
    if raw != canonical_json_bytes(record):
        raise RuntimeError("all-scope authorization is not canonical JSON")
    if (
        record.get("schema_version") != profile.AUTHORIZATION_SCHEMA
        or record.get("experiment_id") != EXPERIMENT_ID
        or record.get("status")
        != "ALL_REQUESTED_PHASES_AUTHORIZED_SEQUENTIAL_ADMISSION_REQUIRED"
        or record.get("authorization_text") != EXACT_AUTHORIZATION_TEXT
        or record.get("result_root") != OUTPUT_RELATIVE.as_posix()
    ):
        raise RuntimeError("all-scope authorization identity changed")
    scope = record.get("scope", {})
    expected_scope = {
        "result_migration_authorized": True,
        "filter_result_rebinding_authorized": True,
        "new_filter_optimization_authorized": False,
        "neural_training_authorized": True,
        "formal_evaluation_authorized": True,
    }
    if scope != expected_scope:
        raise PermissionError("all-scope authorization boundaries changed")
    _validate_timestamp(record.get("registered_at_utc"))
    unsigned = dict(record)
    stored = unsigned.pop("authorization_record_sha256", None)
    if stored != hashlib.sha256(canonical_json_bytes(unsigned)).hexdigest():
        raise RuntimeError("all-scope authorization record hash mismatch")
    if sha256_file(config_path) != profile.EXPECTED_CONTRACT_SHA256:
        raise RuntimeError("scientific contract hash mismatch")
    if sha256_file(preflight_path) != profile.EXPECTED_PREFLIGHT_FINAL_SHA256:
        raise RuntimeError("independent preflight final hash mismatch")
    anchors = record.get("frozen_inputs", {})
    if (
        anchors.get("scientific_contract", {}).get("sha256")
        != profile.EXPECTED_CONTRACT_SHA256
        or anchors.get("independent_preflight_final_manifest", {}).get("sha256")
        != profile.EXPECTED_PREFLIGHT_FINAL_SHA256
    ):
        raise RuntimeError("authorization frozen-input hashes changed")
    phase_inputs = {
        "scientific_contract": CONFIG_RELATIVE,
        "independent_preflight_final_manifest": PREFLIGHT_FINAL_RELATIVE,
        "filter_migration_config": profile.FILTER_MIGRATION_CONFIG_RELATIVE,
        "formal_training_execution_config": profile.FORMAL_TRAINING_CONFIG_RELATIVE,
        "formal_evaluation_algorithm_config": profile.FORMAL_EVALUATION_CONFIG_RELATIVE,
    }
    if set(anchors) != set(phase_inputs):
        raise RuntimeError("authorization frozen-input set changed")
    for label, relative in phase_inputs.items():
        source = require_regular_unlinked_file(
            project_root / relative,
            label=f"authorization frozen input {label}",
            stop_at=project_root,
        )
        expected = {
            "path": relative.as_posix(),
            "sha256": sha256_file(source),
            "size_bytes": source.stat().st_size,
        }
        if anchors[label] != expected:
            raise RuntimeError(f"authorization frozen input changed: {label}")
    return VerifiedAuthorization(
        record=record,
        authorization_path=authorization_path,
        authorization_file_sha256=sha256_file(authorization_path),
        contract_sha256=profile.EXPECTED_CONTRACT_SHA256,
        preflight_final_manifest_sha256=profile.EXPECTED_PREFLIGHT_FINAL_SHA256,
        output_root=expected_output,
        project_root=project_root,
    )


def training_validation_period_specs(
    contract: Mapping[str, Any],
) -> dict[str, PeriodIdentity]:
    if contract.get("periods", {}).get("reset_each_period") is not True:
        raise RuntimeError("training and validation must reset independently")
    result: dict[str, PeriodIdentity] = {}
    for name in TRAINING_PERIOD_NAMES:
        source = contract["periods"][name]
        start, end = source["input"]
        count = (date.fromisoformat(end) - date.fromisoformat(start)).days + 1
        if count != int(source["day_count"]):
            raise RuntimeError(f"{name} period day count changed")
        result[name] = PeriodIdentity(
            name=name,
            start_date=start,
            end_date=end,
            day_count=count,
            first_scoring_index=int(source["first_scoring_index"]),
            first_scoring_date=str(source["first_scoring_date"]),
        )
    return result


def _ordered_newline_digest(values: Sequence[str]) -> str:
    return hashlib.sha256(
        "".join(f"{value}\n" for value in values).encode("utf-8")
    ).hexdigest()


def _compact_digest(values: Sequence[str]) -> str:
    encoded = json.dumps(
        list(values), ensure_ascii=False, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _semantic_identity(records: Mapping[str, Any]) -> str:
    encoded = json.dumps(
        dict(sorted(records.items())),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _split_semantics(
    manifest: Mapping[str, Any], ordered: Sequence[str]
) -> tuple[dict[str, dict[str, Mapping[str, Any]]], str, str, int, str]:
    members = manifest.get("members")
    if not isinstance(members, dict) or int(manifest.get("member_count", -1)) != 4095:
        raise RuntimeError("semantic input manifest count changed")
    expected_keys = {
        f"{basin}/{period}/{array_name}"
        for basin in ordered
        for period in (*TRAINING_PERIOD_NAMES, "evaluation")
        for array_name in SEMANTIC_ARRAY_NAMES
    }
    if set(members) != expected_keys:
        raise RuntimeError("semantic input member set changed")
    selected: dict[str, dict[str, Mapping[str, Any]]] = {
        "training": {},
        "validation": {},
    }
    identities: dict[str, dict[str, Any]] = {
        "training": {},
        "validation": {},
        "evaluation": {},
    }
    for key, value in members.items():
        basin, period, array_name = key.split("/")
        if period in selected:
            selected[period][f"{basin}/{array_name}"] = dict(value)
        identities[period][key] = value
    digests = {name: _semantic_identity(value) for name, value in identities.items()}
    if (
        len(identities["training"]) != profile.TRAINING_IDENTITY_MEMBER_COUNT
        or len(identities["validation"]) != profile.VALIDATION_IDENTITY_MEMBER_COUNT
        or len(identities["evaluation"]) != profile.EVALUATION_IDENTITY_MEMBER_COUNT
        or digests["training"] != profile.TRAINING_IDENTITY_SHA256
        or digests["validation"] != profile.VALIDATION_IDENTITY_SHA256
        or digests["evaluation"] != profile.EVALUATION_IDENTITY_SHA256
    ):
        raise RuntimeError("semantic period identity changed")
    return (
        selected,
        digests["training"],
        digests["validation"],
        len(identities["evaluation"]),
        digests["evaluation"],
    )


def _gate_output(output: Path, *, require_absent: bool) -> None:
    if require_absent and path_exists_including_broken_link(output):
        raise FileExistsError("formal training output root already exists")
    if not path_exists_including_broken_link(output):
        return
    ensure_no_symlink_components(output)
    if not output.is_dir():
        raise RuntimeError("formal training output root is not a directory")
    forbidden = {"formal_evaluation", "formal_evaluation_independent"}
    if any(member.name in forbidden for member in output.iterdir()):
        raise PermissionError("training output already contains formal evaluation")


def verify_preflight_for_revision_training(
    config: str | Path,
    preflight: str | Path,
    authorization: str | Path,
    output_root: str | Path,
    *,
    require_output_absent: bool = False,
    recompute_training_validation_semantics: bool = True,
    verify_all_raw_source_bytes: bool = True,
) -> TrainingAdmissionContext:
    project_root = _project_root_from_config(config)
    config_path = _fixed_file(
        config, project_root, CONFIG_RELATIVE, label="scientific contract"
    )
    preflight_path = _fixed_file(
        preflight,
        project_root,
        PREFLIGHT_FINAL_RELATIVE,
        label="independent preflight final manifest",
    )
    output = project_root / OUTPUT_RELATIVE
    if not _same_path(output_root, output):
        raise ValueError("formal training output root differs from its fixed path")
    _gate_output(output, require_absent=require_output_absent)
    verified_authorization = load_and_verify_authorization(
        authorization, config_path, preflight_path, output
    )
    contract = read_json_strict(config_path)
    if contract.get("experiment_id") != EXPERIMENT_ID:
        raise RuntimeError("scientific contract experiment changed")
    preflight_root = preflight_path.parent.parent
    final = read_json_strict(preflight_path)
    files = final.get("files")
    if (
        final.get("schema_version")
        != "tukf09_455_basin_preflight_final_manifest_v1"
        or final.get("experiment_id") != EXPERIMENT_ID
        or not isinstance(files, dict)
        or int(final.get("file_count", -1)) != len(files)
    ):
        raise RuntimeError("independent preflight final manifest changed")
    for relative, record in files.items():
        source = require_regular_unlinked_file(
            preflight_root / PurePosixPath(relative),
            label="preflight sealed member",
            stop_at=preflight_root,
        )
        if source.stat().st_size != int(record["size_bytes"]) or sha256_file(source) != record["sha256"]:
            raise RuntimeError(f"preflight sealed member changed: {relative}")
    population = read_json_strict(preflight_root / "population_registry.json")
    ordered = tuple(str(value) for value in population.get("eligible", ()))
    if (
        len(ordered) != profile.ORDERED_BASIN_COUNT
        or len(set(ordered)) != len(ordered)
        or profile.EXCLUDED_BASINS[0] in ordered
        or _ordered_newline_digest(ordered) != profile.ORDERED_BASIN_NEWLINE_SHA256
        or _compact_digest(ordered) != profile.ORDERED_BASIN_COMPACT_JSON_SHA256
    ):
        raise RuntimeError("revised population identity changed")
    parameters_path = preflight_root / "parameters_only.npz"
    with np.load(parameters_path, allow_pickle=False) as archive:
        if set(archive.files) != {"basin_ids", "parameter_names", "values"}:
            raise RuntimeError("parameter snapshot member set changed")
        basin_ids = tuple(str(value) for value in archive["basin_ids"].tolist())
        parameter_names = tuple(str(value) for value in archive["parameter_names"].tolist())
        parameter_values = np.asarray(archive["values"], dtype=np.float64).copy()
    if basin_ids != ordered or parameter_values.shape != profile.PARAMETER_SHAPE:
        raise RuntimeError("parameter snapshot shape or population changed")
    if not np.isfinite(parameter_values).all():
        raise FloatingPointError("parameter snapshot contains a non-finite value")
    parameter_values.setflags(write=False)
    semantic_manifest = read_json_strict(
        preflight_root / "semantic_input_manifest.sha256.json"
    )
    semantics, train_sha, validation_sha, evaluation_count, evaluation_sha = (
        _split_semantics(semantic_manifest, ordered)
    )
    raw_manifest = read_json_strict(preflight_root / "raw_source_manifest.sha256.json")
    raw_files = raw_manifest.get("files")
    if not isinstance(raw_files, dict):
        raise RuntimeError("raw-source identity manifest changed")
    # Byte verification is intentionally deferred to the training-only loader.
    # This verifier never opens a CAMELS source file, even when called by an
    # admission process.
    _ = (recompute_training_validation_semantics, verify_all_raw_source_bytes)
    anchors = {
        relative: str(record["sha256"])
        for relative, record in files.items()
    }
    ledger = {
        "evaluation_array_reads": 0,
        "evaluation_predictions": 0,
        "evaluation_metrics": 0,
        "evaluation_outputs": 0,
    }
    return TrainingAdmissionContext(
        experiment_id=EXPERIMENT_ID,
        project_root=project_root,
        output_root=output,
        preflight_root=preflight_root,
        data_root=Path(str(contract["paths"]["data_root"])),
        authorization=verified_authorization,
        contract=contract,
        contract_sha256=profile.EXPECTED_CONTRACT_SHA256,
        preflight_final_manifest_sha256=profile.EXPECTED_PREFLIGHT_FINAL_SHA256,
        source_anchor_sha256=anchors,
        raw_source_files={str(key): dict(value) for key, value in raw_files.items()},
        ordered_basin_ids=ordered,
        parameter_names=parameter_names,
        parameter_values=parameter_values,
        periods=training_validation_period_specs(contract),
        semantic_members=semantics,
        training_semantic_sha256=train_sha,
        validation_semantic_sha256=validation_sha,
        evaluation_identity_count=evaluation_count,
        evaluation_identity_sha256=evaluation_sha,
        access_ledger=ledger,
    )


verify_preflight_for_training = verify_preflight_for_revision_training


def load_training_validation_periods_455(
    context: TrainingAdmissionContext,
) -> dict[str, dict[str, PeriodArrays]]:
    """Load exactly the sealed 455-basin training and validation periods."""
    if context.experiment_id != EXPERIMENT_ID:
        raise RuntimeError("training context experiment changed")
    if tuple(context.ordered_basin_ids) and (
        len(context.ordered_basin_ids) != profile.ORDERED_BASIN_COUNT
        or profile.EXCLUDED_BASINS[0] in context.ordered_basin_ids
    ):
        raise RuntimeError("training context population changed")
    result = parent_common.load_training_validation_periods(
        context, basin_ids=context.ordered_basin_ids
    )
    if context.evaluation_access_count != 0:
        raise PermissionError("training/validation loading recorded evaluation access")
    return result


def _expected_executables_from_config(execution: Mapping[str, Any]) -> tuple[str, ...]:
    values = execution.get("required_executables")
    if not isinstance(values, list) or values != list(
        REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS
    ):
        raise RuntimeError("formal training executable list changed")
    return tuple(str(value) for value in values)


def load_and_verify_training_admission(
    path: str | Path,
    execution_config: str | Path,
    required_executable_paths: Sequence[str | Path],
) -> dict[str, Any]:
    execution_path = _absolute(execution_config)
    if execution_path.parent.name != "configs":
        raise ValueError("training execution config is outside the fixed configs directory")
    project_root = execution_path.parent.parent
    execution_path = _fixed_file(
        execution_path,
        project_root,
        FORMAL_TRAINING_CONFIG_RELATIVE,
        label="formal training execution config",
    )
    admission_path = _fixed_file(
        path, project_root, ADMISSION_RELATIVE, label="formal training admission"
    )
    raw = admission_path.read_bytes()
    payload = read_json_strict(admission_path)
    if raw != canonical_json_bytes(payload):
        raise RuntimeError("training admission is not canonical JSON")
    unsigned = dict(payload)
    stored = unsigned.pop("training_admission_record_sha256", None)
    if stored != hashlib.sha256(canonical_json_bytes(unsigned)).hexdigest():
        raise RuntimeError("training admission record hash mismatch")
    if (
        payload.get("schema_version") != profile.TRAINING_ADMISSION_SCHEMA
        or payload.get("experiment_id") != EXPERIMENT_ID
        or payload.get("status")
        != "NEURAL_TRAINING_ADMITTED_FILTER_REBINDING_INSTALLATION_PENDING_EVALUATION_HOLD"
        or payload.get("phase_scope", {}).get("formal_evaluation_access_admitted")
        is not False
        or payload.get("evaluation_identity", {}).get("arrays_loaded") is not False
        or set(payload.get("access_ledger", {}).values()) != {0}
    ):
        raise PermissionError("training admission identity or evaluation hold changed")
    execution = read_json_strict(execution_path)
    frozen_relatives = _expected_executables_from_config(execution)
    supplied: list[str] = []
    for raw_path in required_executable_paths:
        candidate = Path(raw_path)
        if not candidate.is_absolute():
            candidate = project_root / candidate
        try:
            supplied.append(candidate.relative_to(project_root).as_posix())
        except ValueError as exc:
            raise ValueError("required executable escapes the project root") from exc
    if tuple(supplied) != frozen_relatives:
        raise RuntimeError("required training executable set changed")
    records = payload.get("executables")
    if not isinstance(records, dict) or set(records) != set(frozen_relatives):
        raise RuntimeError("admitted executable record set changed")
    for relative in frozen_relatives:
        executable = require_regular_unlinked_file(
            project_root / relative,
            label="required training executable",
            stop_at=project_root,
        )
        record = records[relative]
        if record != {
            "sha256": sha256_file(executable),
            "size_bytes": executable.stat().st_size,
        }:
            raise RuntimeError(f"training executable hash mismatch: {relative}")
    if payload.get("execution_config") != {
        "path": FORMAL_TRAINING_CONFIG_RELATIVE.as_posix(),
        "sha256": sha256_file(execution_path),
    }:
        raise RuntimeError("training execution-config hash changed")
    tests = payload.get("test_evidence", {})
    policy = execution.get("required_test_policy", {})
    expected_test_paths = policy.get("pytest_files", [])
    if (
        tests.get("result") != "PASS"
        or tests.get("exit_code") != 0
        or type(tests.get("passed_count")) is not int
        or tests.get("passed_count", 0) < 1
        or tests.get("failed_count") != 0
        or tests.get("error_count") != 0
        or tests.get("skipped_count") != 0
        or tests.get("environment_overrides") != policy.get("environment")
        or not isinstance(tests.get("pytest_file_records"), dict)
        or set(tests["pytest_file_records"]) != set(expected_test_paths)
    ):
        raise RuntimeError("required isolated test evidence changed")
    for relative in expected_test_paths:
        source = require_regular_unlinked_file(
            project_root / relative,
            label="required formal-training pytest file",
            stop_at=project_root,
        )
        if tests["pytest_file_records"][relative] != {
            "sha256": sha256_file(source),
            "size_bytes": source.stat().st_size,
        }:
            raise RuntimeError(f"required pytest file changed: {relative}")
    for stream in ("stdout", "stderr"):
        content = tests.get(stream)
        if not isinstance(content, str) or tests.get(f"{stream}_sha256") != hashlib.sha256(
            content.encode("utf-8")
        ).hexdigest():
            raise RuntimeError(f"required pytest {stream} evidence changed")
    return payload


def verify_initialized_training_root(
    *,
    output_root: str | Path,
    config_path: str | Path,
    authorization: str | Path,
    execution_config: str | Path,
    training_admission: str | Path,
    training_admission_record: Mapping[str, Any],
) -> dict[str, Any]:
    execution_path = _absolute(execution_config)
    project_root = execution_path.parent.parent
    output = _absolute(output_root)
    if not _same_path(output, project_root / OUTPUT_RELATIVE):
        raise ValueError("training output root differs from the fixed formal result root")
    if not output.is_dir() or output.is_symlink():
        raise RuntimeError("initialized formal training result root is required")
    core = {
        "scientific_contract.snapshot.json": Path(config_path),
        "authorization.snapshot.json": Path(authorization),
        "execution_config.snapshot.json": Path(execution_config),
        "training_admission.snapshot.json": Path(training_admission),
    }
    allowed = {
        *core,
        "training_context.json",
        "filter",
        "neural",
        "control",
        "logs",
        "selection",
        "independent",
    }
    unknown = {member.name for member in output.iterdir()}.difference(allowed)
    if unknown:
        raise RuntimeError(f"initialized training root contains unknown members: {sorted(unknown)}")
    snapshot_records: dict[str, dict[str, Any]] = {}
    for name, source in core.items():
        source = require_regular_unlinked_file(source, label="training trust source")
        snapshot = require_regular_unlinked_file(
            output / name, label="training trust snapshot", stop_at=output
        )
        content = source.read_bytes()
        if snapshot.read_bytes() != content:
            raise RuntimeError(f"initialized training snapshot differs: {name}")
        snapshot_records[name] = {
            "sha256": hashlib.sha256(content).hexdigest(),
            "size_bytes": len(content),
        }
    context_path = require_regular_unlinked_file(
        output / "training_context.json", label="training context", stop_at=output
    )
    context = read_json_strict(context_path)
    if context_path.read_bytes() != canonical_json_bytes(context):
        raise RuntimeError("initialized training context is not canonical JSON")
    admission = dict(training_admission_record)
    authorization_record = admission.get("authorization", {})
    evaluation_identity = admission.get("evaluation_identity", {})
    if (
        context.get("experiment_id") != EXPERIMENT_ID
        or context.get("formal_evaluation_authorized") is not False
        or context.get("output_root") != OUTPUT_RELATIVE.as_posix()
        or context.get("scientific_contract_sha256")
        != admission.get("scientific_contract_sha256")
        or context.get("preflight_final_manifest_sha256")
        != admission.get("preflight_final_manifest_sha256")
        or context.get("authorization_file_sha256")
        != authorization_record.get("file_sha256")
        or context.get("training_admission_record_sha256")
        != admission.get("training_admission_record_sha256")
        or context.get("evaluation_identity_only_sha256")
        != evaluation_identity.get("identity_only_sha256")
        or set(context.get("access_ledger", {}).values()) != {0}
        or context.get("snapshots") != snapshot_records
    ):
        raise RuntimeError("initialized training context identity differs")
    return context


__all__ = [
    "ADMISSION_RELATIVE",
    "AUTHORIZATION_RELATIVE",
    "CONFIG_RELATIVE",
    "EXPERIMENT_ID",
    "FILTER_INSTALLATION_FINAL_RELATIVE",
    "FilterInstallationAdmission",
    "OUTPUT_RELATIVE",
    "PREFLIGHT_FINAL_RELATIVE",
    "REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS",
    "TrainingAdmissionContext",
    "VerifiedAuthorization",
    "atomic_publish_directory",
    "atomic_write_bytes_exclusive",
    "atomic_write_json_exclusive",
    "canonical_json_bytes",
    "gate_training_period_only",
    "load_and_verify_training_admission",
    "load_training_validation_periods_455",
    "read_json_strict",
    "require_regular_unlinked_file",
    "runtime_environment_identity",
    "sha256_file",
    "verify_initialized_training_root",
    "verify_filter_installation_final_for_neural",
    "verify_neural_sequence_process_chain",
    "verify_preflight_for_revision_training",
    "verify_preflight_for_training",
]
