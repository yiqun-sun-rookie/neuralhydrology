from __future__ import annotations

import torch
from torch import nn


FROZEN_LEADS_DAYS = (1, 2, 3)
FROZEN_FORCING_FEATURES = 3
FROZEN_HIDDEN_SIZE = 256
FROZEN_OUTPUT_DROPOUT = 0.4
FROZEN_INITIAL_FORGET_BIAS = 3.0
FROZEN_OUTPUT_SIZE = 1


class DirectAutoregressiveLSTM(nn.Module):
    """Information-matched direct autoregressive long short-term memory model.

    The final forcing timestep is the forecast target day. At each timestep, the
    autoregressive input is observed discharge shifted by ``lead_days``. Missing
    shifted discharge at a reset-period boundary is replaced by the model output
    from ``lead_days`` earlier, matching the frozen NeuralHydrology reference.
    """

    def __init__(
        self,
        *,
        lead_days: int,
        forcing_features: int = FROZEN_FORCING_FEATURES,
        hidden_size: int = FROZEN_HIDDEN_SIZE,
        output_dropout: float = FROZEN_OUTPUT_DROPOUT,
        initial_forget_bias: float = FROZEN_INITIAL_FORGET_BIAS,
        output_size: int = FROZEN_OUTPUT_SIZE,
    ) -> None:
        super().__init__()
        if lead_days not in FROZEN_LEADS_DAYS:
            raise ValueError("the frozen forecast leads are 1, 2, and 3 days")
        if forcing_features != FROZEN_FORCING_FEATURES:
            raise ValueError("the frozen model has exactly three forcing features")
        if hidden_size != FROZEN_HIDDEN_SIZE:
            raise ValueError("the frozen model has exactly 256 hidden units")
        if output_dropout != FROZEN_OUTPUT_DROPOUT:
            raise ValueError("the frozen output dropout is 0.4")
        if initial_forget_bias != FROZEN_INITIAL_FORGET_BIAS:
            raise ValueError("the frozen initial forget bias is 3.0")
        if output_size != FROZEN_OUTPUT_SIZE:
            raise ValueError("the frozen model predicts exactly one discharge value")

        self.lead_days = int(lead_days)
        self.forcing_features = int(forcing_features)
        self.hidden_size = int(hidden_size)
        self.output_size = int(output_size)
        self.input_size = self.forcing_features + self.output_size + self.output_size

        self.cell = nn.LSTM(
            input_size=self.input_size,
            hidden_size=self.hidden_size,
            dtype=torch.float32,
        )
        self.dropout = nn.Dropout(p=float(output_dropout))
        self.head = nn.Linear(
            self.hidden_size,
            self.output_size,
            dtype=torch.float32,
        )
        self._reset_forget_bias(float(initial_forget_bias))

    def _reset_forget_bias(self, value: float) -> None:
        with torch.no_grad():
            self.cell.bias_hh_l0[self.hidden_size : 2 * self.hidden_size] = value

    def _validate_inputs(
        self,
        forcing: torch.Tensor,
        lagged_discharge: torch.Tensor,
        h_0: torch.Tensor | None,
        c_0: torch.Tensor | None,
    ) -> tuple[int, int]:
        if not torch.is_floating_point(forcing) or not torch.is_floating_point(lagged_discharge):
            raise TypeError("forcing and lagged discharge must be floating-point tensors")
        if forcing.ndim != 3 or forcing.shape[-1] != self.forcing_features:
            raise ValueError("forcing must have shape [batch, sequence, 3]")
        if lagged_discharge.shape != (*forcing.shape[:2], self.output_size):
            raise ValueError("lagged discharge must have shape [batch, sequence, 1]")
        if forcing.shape[1] < 1:
            raise ValueError("sequence must contain at least one timestep")
        if forcing.device != lagged_discharge.device or forcing.dtype != lagged_discharge.dtype:
            raise ValueError("forcing and lagged discharge must share device and dtype")
        parameter = self.cell.weight_ih_l0
        if forcing.device != parameter.device or forcing.dtype != parameter.dtype:
            raise ValueError("input device and dtype must match model parameters")
        if not torch.isfinite(forcing).all():
            raise FloatingPointError("forcing contains a non-finite value")
        if torch.isinf(lagged_discharge).any():
            raise FloatingPointError("lagged discharge contains an infinite value")

        batch_size, sequence_length = forcing.shape[:2]
        expected_state_shape = (1, batch_size, self.hidden_size)
        for name, state in (("h_0", h_0), ("c_0", c_0)):
            if state is None:
                continue
            if state.shape != expected_state_shape:
                raise ValueError(f"{name} must have shape {expected_state_shape}")
            if state.device != forcing.device or state.dtype != forcing.dtype:
                raise ValueError(f"{name} must share input device and dtype")
            if not torch.isfinite(state).all():
                raise FloatingPointError(f"{name} contains a non-finite value")
        return int(batch_size), int(sequence_length)

    def forward(
        self,
        forcing: torch.Tensor,
        lagged_discharge: torch.Tensor,
        h_0: torch.Tensor | None = None,
        c_0: torch.Tensor | None = None,
    ) -> dict[str, torch.Tensor]:
        batch_size, sequence_length = self._validate_inputs(
            forcing, lagged_discharge, h_0, c_0
        )
        forcing_time_first = forcing.transpose(0, 1)
        lagged_time_first = lagged_discharge.transpose(0, 1)

        if h_0 is None:
            h_0 = forcing.new_zeros((1, batch_size, self.hidden_size))
        if c_0 is None:
            c_0 = forcing.new_zeros((1, batch_size, self.hidden_size))

        last_prediction = forcing.new_zeros(
            (self.lead_days, batch_size, self.output_size)
        )
        lstm_output: list[torch.Tensor] = []
        predictions: list[torch.Tensor] = []
        availability_flags: list[torch.Tensor] = []

        for timestep in range(sequence_length):
            forcing_t = forcing_time_first[timestep]
            autoregressive_t = lagged_time_first[timestep].clone()
            replace_indices = torch.isnan(autoregressive_t)
            autoregressive_t[replace_indices] = last_prediction[-1][replace_indices]

            flags_t = forcing.new_zeros((batch_size, self.output_size))
            flags_t[replace_indices] = 1
            cell_input = torch.unsqueeze(
                torch.cat([forcing_t, autoregressive_t, flags_t], dim=-1), dim=0
            )
            cell_output, (h_0, c_0) = self.cell(cell_input, (h_0, c_0))
            lstm_output.append(cell_output.transpose(0, 1))

            last_prediction[1:] = last_prediction[:-1].clone()
            prediction = torch.squeeze(
                self.head(self.dropout(h_0.transpose(0, 1))), dim=1
            )
            last_prediction[0] = prediction
            predictions.append(prediction)
            availability_flags.append(flags_t)

        result = {
            "lstm_output": torch.cat(lstm_output, dim=1),
            "h_n": h_0.transpose(0, 1),
            "c_n": c_0.transpose(0, 1),
            "y_hat": torch.stack(predictions, dim=1),
            "autoregressive_flags": torch.stack(availability_flags, dim=1),
        }
        for name, value in result.items():
            if not torch.isfinite(value).all():
                raise FloatingPointError(f"model output contains a non-finite value: {name}")
        return result
