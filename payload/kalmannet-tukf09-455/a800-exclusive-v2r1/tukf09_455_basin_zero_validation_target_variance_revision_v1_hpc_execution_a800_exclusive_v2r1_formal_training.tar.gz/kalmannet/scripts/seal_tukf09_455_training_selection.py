"""Seal the complete TUKF09 training and validation model selection.

This module never imports either training runner and never opens an evaluation
array.  It accepts only already-published filter and neural training units,
recomputes their manifests and validation-based checkpoint choices, and then
publishes the five-file selection directory in one atomic rename.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import sys
from typing import Any, Mapping, Sequence
import uuid

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

try:
    from scripts import tukf09_455_training_controller_common as phase_common
    from scripts.tukf09_455_training_common import (
        REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS,
    )
except ImportError:  # pragma: no cover - direct script execution
    import tukf09_455_training_controller_common as phase_common
    from tukf09_455_training_common import REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS

EXPERIMENT_ID = "TUKF09_455_BASIN_ZERO_VALIDATION_TARGET_VARIANCE_REVISION_V1"
PARENT_EXPERIMENT_ID = "TUKF09_BACKPROPAGATION_VS_NEURAL_BACKWARD_TIME_CONFIRMATION_V1"
DEFAULT_EXECUTION_CONFIG = ROOT / "configs" / "tukf09_455_basin_zero_validation_target_variance_formal_training_execution_v1.json"
DEFAULT_POPULATION_REGISTRY = (
    ROOT
    / "artifacts"
    / "tukf09_455_basin_zero_validation_target_variance_revision_v1"
    / "preflight"
    / "population_registry.json"
)
DEFAULT_OUTPUT_ROOT = (
    ROOT / "results" / "tukf09_455_basin_zero_validation_target_variance_revision_v1"
)

FILTER_CHECKPOINT_COUNT = 256
FILTER_TRAINING_QUERY_COUNT = 256
FILTER_VALIDATION_QUERY_COUNT = 256
FILTER_PASS_COUNT = 512
FILTER_GRADIENT_UPDATE_COUNT = 248
NEURAL_CHECKPOINT_COUNT = 30
TRAINING_DAYS = 2557
VALIDATION_DAYS = 731
SEQUENCE_LENGTH = 365
TRAINING_SAMPLES_PER_BASIN = 2192
VALIDATION_SAMPLES_PER_BASIN = 366

ROOT_EVIDENCE_MEMBERS = (
    "authorization.snapshot.json",
    "scientific_contract.snapshot.json",
    "execution_config.snapshot.json",
    "training_admission.snapshot.json",
    "training_context.json",
)
FILTER_MEMBER_NAMES = (
    "access_ledger.json",
    "history.npz",
    "identity.json",
    "migration_provenance.json",
    "selection.json",
)
LEGACY_FILTER_MEMBER_NAMES = tuple(
    name for name in FILTER_MEMBER_NAMES if name != "migration_provenance.json"
)
NEURAL_MEMBER_NAMES = (
    "identity.json",
    *tuple(f"checkpoints/epoch_{epoch:03d}.pt" for epoch in range(1, 31)),
    "validation_history.npz",
    "model_selection.json",
    "access_ledger.json",
)
SELECTION_MEMBER_NAMES = frozenset(
    {
        "filter_registry.json",
        "neural_registry.json",
        "selected_model_summary.json",
        "training_manifest.sha256.json",
        "training_selection.sealed.json",
    }
)
EXPECTED_SCORED_TARGET_COUNTS = {
    "training": {"1": 2190, "2": 2191, "3": 2192},
    "validation": {"1": 364, "2": 365, "3": 366},
}
EXPECTED_COMPLETION_COUNTS = {
    "rebound_filter_units": 455,
    "new_filter_training_units": 0,
    "inherited_filter_checkpoint_records": 116480,
    "new_filter_training_objective_calls": 0,
    "new_filter_validation_objective_calls": 0,
    "new_filter_gradient_updates": 0,
    "neural_model_units": 9,
    "neural_checkpoints": 270,
    "evaluation_array_reads": 0,
    "evaluation_predictions": 0,
    "evaluation_metrics": 0,
    "evaluation_outputs": 0,
}
EXPECTED_NEURAL_UNITS = tuple(
    (lead_days, seed) for lead_days in (1, 2, 3) for seed in (0, 1, 2)
)
NEURAL_RUNNER_RELATIVE_PATH = "scripts/run_tukf09_455_neural_training.py"
FROZEN_NEURAL_MODEL_RELATIVE_PATH = "scripts/tukf07_information_matched_model.py"


@dataclass(frozen=True)
class SelectionExpectations:
    basin_ids: tuple[str, ...]
    neural_units: tuple[tuple[int, int], ...]
    production: bool
    execution_config_sha256: str | None = None
    scientific_contract_sha256: str | None = None
    preflight_final_manifest_sha256: str | None = None


@dataclass(frozen=True)
class AdmittedSourceBindings:
    training_admission_record_sha256: str
    neural_runner_sha256: str
    frozen_model_source_sha256: str
    all_scope_authorization_sha256: str | None = None
    migration_config_sha256: str | None = None
    filter_migration_final_manifest_sha256: str | None = None
    filter_installation_final_manifest_sha256: str | None = None
    installed_unit_records: Mapping[str, Mapping[str, Any]] | None = None
    scientific_contract_sha256: str | None = None
    preflight_final_manifest_sha256: str | None = None


def _reject_nonfinite_json(token: str) -> None:
    raise ValueError(f"non-finite JSON number is forbidden: {token}")


def _canonical_json_bytes(value: Any) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")


def _canonical_payload_sha256(value: Any) -> str:
    return sha256(_canonical_json_bytes(value)[:-1]).hexdigest()


def _sha256_file(path: Path) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _record(path: Path) -> dict[str, Any]:
    return {"sha256": _sha256_file(path), "size_bytes": int(path.stat().st_size)}


def _path_exists(path: Path) -> bool:
    return os.path.lexists(os.fspath(path))


def _require_regular_file(path: Path, label: str) -> Path:
    candidate = Path(path)
    if not candidate.is_file() or candidate.is_symlink():
        raise FileNotFoundError(f"{label} is missing or linked: {candidate}")
    if candidate.stat().st_nlink != 1:
        raise RuntimeError(f"hard-linked {label} is forbidden: {candidate}")
    return candidate


def _read_json(path: Path, *, canonical: bool = True) -> dict[str, Any]:
    source = _require_regular_file(path, "JSON artifact")
    raw = source.read_bytes()
    try:
        value = json.loads(raw.decode("utf-8"), parse_constant=_reject_nonfinite_json)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"invalid UTF-8 JSON artifact: {source}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"JSON object required: {source}")
    if canonical and raw != _canonical_json_bytes(value):
        raise RuntimeError(f"non-canonical JSON artifact: {source}")
    return value


def _is_hex_sha256(value: Any) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(character in "0123456789abcdef" for character in value)
    )


def _validate_admitted_executables(
    admission: Mapping[str, Any],
    admission_record_sha256: Any,
) -> AdmittedSourceBindings:
    """Rehash the exact admitted local sources and return unit bindings."""

    if not _is_hex_sha256(admission_record_sha256):
        raise RuntimeError("training admission record hash is invalid for source binding")
    executables = admission.get("executables")
    if not isinstance(executables, Mapping) or set(executables) != set(
        REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS
    ):
        raise RuntimeError("training admission executable source set is not the frozen set")
    for relative in REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS:
        admitted = executables.get(relative)
        if not isinstance(admitted, Mapping) or set(admitted) != {
            "sha256",
            "size_bytes",
        }:
            raise RuntimeError(f"training admission executable record changed: {relative}")
        size_bytes = admitted.get("size_bytes")
        if (
            not _is_hex_sha256(admitted.get("sha256"))
            or isinstance(size_bytes, bool)
            or not isinstance(size_bytes, int)
            or size_bytes < 0
        ):
            raise RuntimeError(f"training admission executable record is invalid: {relative}")
        current = _record(
            _require_regular_file(ROOT / relative, f"admitted executable source {relative}")
        )
        if dict(admitted) != current:
            raise RuntimeError(f"admitted executable source hash changed: {relative}")
    return AdmittedSourceBindings(
        training_admission_record_sha256=str(admission_record_sha256),
        neural_runner_sha256=str(executables[NEURAL_RUNNER_RELATIVE_PATH]["sha256"]),
        frozen_model_source_sha256=str(
            executables[FROZEN_NEURAL_MODEL_RELATIVE_PATH]["sha256"]
        ),
    )


def _normalize_basin_id(value: Any) -> str:
    if isinstance(value, bool):
        raise ValueError("basin identifier must be eight-digit text")
    text = str(value).strip()
    if len(text) != 8 or not text.isascii() or not text.isdigit():
        raise ValueError(f"basin identifier is not eight-digit text: {value!r}")
    return text


def _normalize_neural_units(values: Sequence[Any]) -> tuple[tuple[int, int], ...]:
    units: list[tuple[int, int]] = []
    for value in values:
        if isinstance(value, Mapping):
            lead_days, seed = value.get("lead_days"), value.get("seed")
        else:
            try:
                lead_days, seed = value
            except (TypeError, ValueError) as exc:
                raise ValueError("neural unit must contain lead_days and seed") from exc
        if isinstance(lead_days, bool) or isinstance(seed, bool):
            raise ValueError("neural lead and seed must be integers")
        unit = (int(lead_days), int(seed))
        if unit[0] not in (1, 2, 3) or unit[1] not in (0, 1, 2):
            raise ValueError(f"neural lead-seed unit is outside the frozen set: {unit}")
        units.append(unit)
    if len(units) != len(set(units)):
        raise ValueError("duplicate neural lead-seed unit")
    return tuple(units)


def _load_expectations(
    *,
    output_root: Path,
    population_registry: Path | None,
    execution_config: Path | None,
    expected_basin_ids: Sequence[str] | None,
    expected_neural_units: Sequence[Any] | None,
) -> SelectionExpectations:
    injected = expected_basin_ids is not None or expected_neural_units is not None
    if injected:
        if expected_basin_ids is None or expected_neural_units is None:
            raise ValueError("synthetic expectations require basin ids and neural units together")
        basins = tuple(_normalize_basin_id(value) for value in expected_basin_ids)
        units = _normalize_neural_units(expected_neural_units)
        if not basins or len(basins) != len(set(basins)) or not units:
            raise ValueError("synthetic selection population must be nonempty and unique")
        return SelectionExpectations(basins, units, False)

    registry_path = Path(population_registry or DEFAULT_POPULATION_REGISTRY)
    execution_path = Path(execution_config or DEFAULT_EXECUTION_CONFIG)
    registry = _read_json(registry_path, canonical=True)
    execution = _read_json(execution_path, canonical=False)
    if (
        registry.get("schema_version")
        != "tukf09_455_basin_validation_metric_defined_population_v1"
        or registry.get("experiment_id") != EXPERIMENT_ID
    ):
        raise ValueError("population registry identity changed")
    eligible = registry.get("eligible")
    if not isinstance(eligible, list):
        raise ValueError("population registry eligible order is absent")
    basins = tuple(_normalize_basin_id(value) for value in eligible)
    if len(basins) != 455 or len(set(basins)) != 455:
        raise RuntimeError("production selection requires exactly 455 eligible basins")
    if (
        execution.get("schema_version") != "tukf09_455_formal_training_execution_v1"
        or execution.get("experiment_id") != EXPERIMENT_ID
        or execution.get("completion_counts") != EXPECTED_COMPLETION_COUNTS
    ):
        raise ValueError("formal training execution completion contract changed")
    authorization = execution.get("authorization")
    if not isinstance(authorization, Mapping) or (
        authorization.get("neural_training") is not True
        or authorization.get("training_selection_sealing") is not True
        or authorization.get("independent_training_selection_verification") is not True
        or authorization.get("formal_evaluation_access_during_training") is not False
    ):
        raise PermissionError("training selection is not authorized or evaluation is enabled")
    order = execution.get("controller_order", {}).get("neural_models")
    if not isinstance(order, list):
        raise ValueError("neural controller order is absent")
    units = _normalize_neural_units(order)
    if units != EXPECTED_NEURAL_UNITS:
        raise RuntimeError("production selection requires the frozen nine neural units")
    configured = execution.get("paths", {}).get("results_root")
    if not isinstance(configured, str):
        raise ValueError("configured result root is absent")
    expected_root = Path(configured)
    if not expected_root.is_absolute():
        expected_root = ROOT / expected_root
    if Path(output_root).resolve(strict=False) != expected_root.resolve(strict=False):
        raise ValueError("production selection output root differs from the fixed result root")
    scientific = execution.get("scientific_contract")
    preflight = execution.get("independent_preflight_final_manifest")
    if (
        not isinstance(scientific, Mapping)
        or not _is_hex_sha256(scientific.get("sha256"))
        or not isinstance(preflight, Mapping)
        or not _is_hex_sha256(preflight.get("sha256"))
    ):
        raise ValueError("frozen scientific or preflight hash is absent")
    return SelectionExpectations(
        basins,
        units,
        True,
        _sha256_file(execution_path),
        str(scientific["sha256"]),
        str(preflight["sha256"]),
    )


def _validate_filter_rebinding_evidence(
    root: Path,
    expectations: SelectionExpectations,
    admission: Mapping[str, Any],
    authorization: Mapping[str, Any],
    records: Mapping[str, Mapping[str, Any]],
    admitted_sources: AdmittedSourceBindings,
) -> AdmittedSourceBindings:
    migration_reference = admission.get("filter_migration_final_manifest")
    if not isinstance(migration_reference, Mapping):
        raise RuntimeError("training admission lacks the filter-migration final seal")
    migration_path = Path(str(migration_reference.get("path", "")))
    if not migration_path.is_absolute():
        migration_path = ROOT / migration_path
    migration_path = _require_regular_file(
        migration_path, "filter-migration independent final manifest"
    )
    migration_hash = _sha256_file(migration_path)
    migration_final = _read_json(migration_path, canonical=True)
    if (
        migration_reference.get("sha256") != migration_hash
        or migration_final.get("schema_version")
        != "tukf09_455_filter_migration_final_manifest_v1"
        or migration_final.get("experiment_id") != EXPERIMENT_ID
        or migration_final.get("status")
        != "FILTER_MIGRATION_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
    ):
        raise RuntimeError("filter-migration independent final seal changed")

    control = root / "control" / "filter_rebinding"
    seal_path = control / "filter_rebinding.sealed.json"
    audit_path = control / "independent" / "independent_audit.json"
    final_path = control / "independent" / "manifest.final.sha256.json"
    seal = _read_json(seal_path, canonical=True)
    audit = _read_json(audit_path, canonical=True)
    final = _read_json(final_path, canonical=True)
    if (
        seal.get("schema_version") != "tukf09_455_filter_rebinding_seal_v1"
        or seal.get("status") != "FILTER_REBINDING_INSTALLED_455_EVALUATION_HOLD"
        or seal.get("ordered_basin_ids") != list(expectations.basin_ids)
        or seal.get("unit_count") != len(expectations.basin_ids)
        or seal.get("unit_file_count") != len(expectations.basin_ids) * 6
        or seal.get("training_admission_sha256")
        != records["training_admission.snapshot.json"]["sha256"]
        or seal.get("migration_final_manifest_sha256") != migration_hash
        or seal.get("inherited_checkpoint_count")
        != len(expectations.basin_ids) * FILTER_CHECKPOINT_COUNT
        or seal.get("inherited_gradient_update_count")
        != len(expectations.basin_ids) * FILTER_GRADIENT_UPDATE_COUNT
        or seal.get("new_filter_optimization_count") != 0
        or seal.get("new_filter_objective_count") != 0
        or seal.get("new_filter_gradient_update_count") != 0
        or seal.get("evaluation_access_count") != 0
        or audit.get("schema_version")
        != "tukf09_455_filter_installation_independent_audit_v1"
        or audit.get("status")
        != "FILTER_REBINDING_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
        or audit.get("unit_count") != len(expectations.basin_ids)
        or audit.get("unit_file_count") != len(expectations.basin_ids) * 6
        or audit.get("training_admission_sha256")
        != records["training_admission.snapshot.json"]["sha256"]
        or audit.get("migration_final_manifest_sha256") != migration_hash
        or audit.get("new_filter_optimization_count") != 0
        or audit.get("evaluation_access_count") != 0
        or final.get("schema_version")
        != "tukf09_455_filter_installation_final_manifest_v1"
        or final.get("experiment_id") != EXPERIMENT_ID
        or final.get("status")
        != "FILTER_REBINDING_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
    ):
        raise RuntimeError("filter-rebinding installation seal changed")
    final_files = final.get("files")
    if not isinstance(final_files, Mapping):
        raise RuntimeError("filter-rebinding final file records are absent")
    expected_paths = {
        f"filter/basin_{basin}/{name}"
        for basin in expectations.basin_ids
        for name in (*FILTER_MEMBER_NAMES, "manifest.sha256.json")
    } | {
        "control/filter_rebinding/filter_rebinding.sealed.json",
        "control/filter_rebinding/independent/independent_audit.json",
    }
    if set(final_files) != expected_paths or final.get("file_count") != len(expected_paths):
        raise RuntimeError("filter-rebinding independent final scope changed")
    for relative, expected in final_files.items():
        current = _record(
            _require_regular_file(root / relative, f"filter-rebinding file {relative}")
        )
        if expected != current:
            raise RuntimeError(f"filter-rebinding file changed after verification: {relative}")
    unit_manifest_map = seal.get("unit_manifest_sha256_by_basin")
    if not isinstance(unit_manifest_map, Mapping) or set(unit_manifest_map) != set(
        expectations.basin_ids
    ):
        raise RuntimeError("filter-rebinding unit manifest map changed")
    for basin in expectations.basin_ids:
        relative = f"filter/basin_{basin}/manifest.sha256.json"
        if unit_manifest_map[basin] != final_files[relative]["sha256"]:
            raise RuntimeError(f"filter-rebinding unit manifest binding changed: {basin}")
    frozen_inputs = authorization.get("frozen_inputs", {})
    migration_config = frozen_inputs.get("filter_migration_config", {})
    if not _is_hex_sha256(migration_config.get("sha256")):
        raise RuntimeError("all-scope authorization lacks the migration-config hash")
    installed = {
        relative: dict(value)
        for relative, value in final_files.items()
        if relative.startswith("filter/basin_")
    }
    return AdmittedSourceBindings(
        training_admission_record_sha256=(
            admitted_sources.training_admission_record_sha256
        ),
        neural_runner_sha256=admitted_sources.neural_runner_sha256,
        frozen_model_source_sha256=admitted_sources.frozen_model_source_sha256,
        all_scope_authorization_sha256=records["authorization.snapshot.json"]["sha256"],
        migration_config_sha256=str(migration_config["sha256"]),
        filter_migration_final_manifest_sha256=migration_hash,
        filter_installation_final_manifest_sha256=_sha256_file(final_path),
        installed_unit_records=installed,
        scientific_contract_sha256=expectations.scientific_contract_sha256,
        preflight_final_manifest_sha256=expectations.preflight_final_manifest_sha256,
    )


def _validate_root_evidence(
    root: Path, expectations: SelectionExpectations
) -> tuple[dict[str, Any], AdmittedSourceBindings | None]:
    records: dict[str, Any] = {}
    for name in ROOT_EVIDENCE_MEMBERS:
        path = _require_regular_file(root / name, f"training root evidence {name}")
        records[name] = _record(path)
    if not expectations.production:
        return records, None

    authorization = _read_json(root / "authorization.snapshot.json", canonical=True)
    admission = _read_json(root / "training_admission.snapshot.json", canonical=True)
    context = _read_json(root / "training_context.json", canonical=True)
    execution = _read_json(root / "execution_config.snapshot.json", canonical=False)
    authorization_unsigned = dict(authorization)
    authorization_record_sha256 = authorization_unsigned.pop(
        "authorization_record_sha256", None
    )
    admission_unsigned = dict(admission)
    admission_record_sha256 = admission_unsigned.pop(
        "training_admission_record_sha256", None
    )
    if authorization.get("experiment_id") != EXPERIMENT_ID or (
        authorization.get("status")
        != "ALL_REQUESTED_PHASES_AUTHORIZED_SEQUENTIAL_ADMISSION_REQUIRED"
        or authorization.get("scope", {}).get("neural_training_authorized") is not True
        or authorization.get("scope", {}).get("new_filter_optimization_authorized")
        is not False
    ):
        raise PermissionError("training authorization snapshot does not permit selection-only work")
    if admission.get("experiment_id") != EXPERIMENT_ID or (
        admission.get("formal_evaluation_authorized") is not False
        or admission.get("phase_scope", {}).get(
            "training_selection_sealing_authorized"
        )
        is not True
        or admission.get("phase_scope", {}).get("formal_evaluation_access_admitted")
        is not False
        or admission.get("tensorfloat32") != {"cuda_matmul": False, "cudnn": False}
        or admission.get("evaluation_identity", {}).get("arrays_loaded") is not False
    ):
        raise RuntimeError("training admission snapshot crossed the evaluation boundary")
    if context.get("experiment_id") != EXPERIMENT_ID or (
        context.get("formal_evaluation_authorized") is not False
        or any(value != 0 for value in context.get("access_ledger", {}).values())
    ):
        raise RuntimeError("training context snapshot records evaluation access")
    if (
        execution.get("authorization", {}).get(
            "formal_evaluation_access_during_training"
        )
        is not False
    ):
        raise RuntimeError("execution snapshot authorizes evaluation")
    if (
        records["execution_config.snapshot.json"]["sha256"]
        != expectations.execution_config_sha256
        or records["scientific_contract.snapshot.json"]["sha256"]
        != expectations.scientific_contract_sha256
        or authorization_record_sha256
        != sha256(_canonical_json_bytes(authorization_unsigned)).hexdigest()
        or admission_record_sha256
        != sha256(_canonical_json_bytes(admission_unsigned)).hexdigest()
        or authorization.get("frozen_inputs", {})
        .get("scientific_contract", {})
        .get("sha256")
        != expectations.scientific_contract_sha256
        or authorization.get("frozen_inputs", {})
        .get("independent_preflight_final_manifest", {})
        .get("sha256")
        != expectations.preflight_final_manifest_sha256
        or admission.get("scientific_contract_sha256")
        != expectations.scientific_contract_sha256
        or admission.get("preflight_final_manifest_sha256")
        != expectations.preflight_final_manifest_sha256
        or admission.get("authorization", {}).get("file_sha256")
        != records["authorization.snapshot.json"]["sha256"]
        or admission.get("authorization", {}).get("record_sha256")
        != authorization_record_sha256
        or admission.get("execution_config", {}).get("sha256")
        != records["execution_config.snapshot.json"]["sha256"]
        or context.get("scientific_contract_sha256")
        != expectations.scientific_contract_sha256
        or context.get("preflight_final_manifest_sha256")
        != expectations.preflight_final_manifest_sha256
        or context.get("authorization_file_sha256")
        != records["authorization.snapshot.json"]["sha256"]
        or context.get("training_admission_record_sha256") != admission_record_sha256
    ):
        raise RuntimeError("frozen training authorization, admission, and context hashes differ")
    source_bindings = _validate_admitted_executables(
        admission, admission_record_sha256
    )
    ordered_digest = sha256(
        "".join(f"{value}\n" for value in expectations.basin_ids).encode("utf-8")
    ).hexdigest()
    admitted_population = admission.get("population", {})
    if (
        admitted_population.get("ordered_basin_count") != len(expectations.basin_ids)
        or admitted_population.get("ordered_newline_sha256") != ordered_digest
    ):
        raise RuntimeError("training admission population differs from the selection population")
    if admission.get("access_ledger") and any(
        value != 0 for value in admission["access_ledger"].values()
    ):
        raise RuntimeError("training admission access ledger records evaluation access")
    snapshots = context.get("snapshots")
    if not isinstance(snapshots, Mapping):
        raise RuntimeError("training context snapshot records are absent")
    for name in ROOT_EVIDENCE_MEMBERS[:-1]:
        if snapshots.get(name) != records[name]:
            raise RuntimeError(f"training context evidence hash changed: {name}")
    return records, _validate_filter_rebinding_evidence(
        root, expectations, admission, authorization, records, source_bindings
    )


def _phase_owner_payload(owner: Any) -> dict[str, Any]:
    if isinstance(owner, Mapping):
        return dict(owner)
    try:
        return dict(owner.__dict__)
    except AttributeError as exc:
        raise TypeError("training phase owner must be a record") from exc


def _validate_owned_phase_lock(root: Path, owner: Any) -> str:
    relative_owner = "control/.training_phase.lock/owner.json"
    lock = root / "control" / ".training_phase.lock"
    expected = _phase_owner_payload(owner)
    if not lock.is_dir() or lock.is_symlink():
        raise RuntimeError("owned training phase lock is absent, linked, or invalid")
    if {path.name for path in lock.iterdir()} != {"owner.json"}:
        raise RuntimeError("owned training phase lock exact member set changed")
    owner_path = _require_regular_file(lock / "owner.json", "training phase owner")
    recorded = _read_json(owner_path, canonical=True)
    if recorded != expected or recorded.get("role") != "seal":
        raise RuntimeError("owned selection phase-lock identity changed")
    return relative_owner


def _validate_no_forbidden_surface(root: Path, *, phase_owner: Any | None = None) -> None:
    if not root.is_dir() or root.is_symlink():
        raise FileNotFoundError("formal training result root is absent or linked")
    allowed_top_level = set(ROOT_EVIDENCE_MEMBERS) | {
        "filter",
        "neural",
        "control",
        "logs",
        "selection",
        "independent",
    }
    actual_top_level = {path.name for path in root.iterdir()}
    unknown = actual_top_level.difference(allowed_top_level)
    if unknown:
        raise RuntimeError(f"unknown top-level training artifact is forbidden: {sorted(unknown)}")
    if (root / "independent").exists() and not (root / "selection").exists():
        raise RuntimeError("independent audit cannot precede the training selection seal")
    phase_lock = root / "control" / ".training_phase.lock"
    if phase_owner is None:
        if _path_exists(phase_lock):
            raise RuntimeError(
                "existing training phase lock requires HOLD and manual process audit"
            )
    else:
        _validate_owned_phase_lock(root, phase_owner)
    for path in root.rglob("*"):
        if path.is_symlink():
            raise RuntimeError(f"linked training artifact is forbidden: {path}")
        lock_name = path.name.lower()
        if (
            lock_name == "controller.lock"
            or lock_name.endswith("_controller.lock")
            or lock_name.endswith(".controller.lock")
        ):
            raise RuntimeError(f"active controller lock forbids selection sealing: {path}")
        lowered_parts = tuple(part.lower() for part in path.relative_to(root).parts)
        if any(part == "evaluation" or part.startswith("evaluation_") for part in lowered_parts):
            raise RuntimeError(f"evaluation output surface is forbidden during training: {path}")


def _validate_unit_manifest(
    directory: Path,
    *,
    schema_version: str,
    unit_type: str,
    unit_id: str,
    expected_members: Sequence[str],
) -> tuple[dict[str, Any], dict[str, Any]]:
    if not directory.is_dir() or directory.is_symlink():
        raise FileNotFoundError(f"complete unlinked training unit required: {directory}")
    manifest_path = directory / "manifest.sha256.json"
    manifest = _read_json(manifest_path, canonical=True)
    expected_set = set(expected_members)
    if manifest != {
        "schema_version": schema_version,
        "experiment_id": EXPERIMENT_ID,
        "unit_type": unit_type,
        "unit_id": unit_id,
        "file_count": len(expected_members),
        "files": manifest.get("files"),
    }:
        raise RuntimeError(f"{unit_type} manifest identity or count changed: {unit_id}")
    files = manifest.get("files")
    if not isinstance(files, dict) or set(files) != expected_set:
        raise RuntimeError(f"{unit_type} manifest exact member set changed: {unit_id}")
    actual_files: set[str] = set()
    actual_directories: set[str] = set()
    for path in directory.rglob("*"):
        relative = path.relative_to(directory).as_posix()
        if path.is_symlink():
            raise RuntimeError(f"linked training unit member is forbidden: {relative}")
        if path.is_dir():
            actual_directories.add(relative)
        elif path.is_file():
            if path.stat().st_nlink != 1:
                raise RuntimeError(f"hard-linked training unit member is forbidden: {relative}")
            actual_files.add(relative)
        else:
            raise RuntimeError(f"non-file training unit member is forbidden: {relative}")
    expected_directories = {"checkpoints"} if unit_type == "neural_lead_seed" else set()
    if actual_directories != expected_directories or actual_files != expected_set | {
        "manifest.sha256.json"
    }:
        raise RuntimeError(f"{unit_type} unit exact layout changed: {unit_id}")
    tree_records: dict[str, Any] = {}
    for relative in expected_members:
        record = files[relative]
        if not isinstance(record, dict) or set(record) != {"sha256", "size_bytes"}:
            raise RuntimeError(f"invalid manifest record: {unit_id}:{relative}")
        if not _is_hex_sha256(record.get("sha256")) or not isinstance(
            record.get("size_bytes"), int
        ):
            raise RuntimeError(f"invalid manifest hash or size: {unit_id}:{relative}")
        path = _require_regular_file(directory / Path(relative), f"unit member {relative}")
        recomputed = _record(path)
        if record != recomputed:
            raise RuntimeError(f"unit manifest hash or size mismatch: {unit_id}:{relative}")
        tree_records[relative] = recomputed
    tree_records["manifest.sha256.json"] = _record(manifest_path)
    return manifest, tree_records


def _load_npz_exact(path: Path, names: set[str]) -> dict[str, np.ndarray]:
    source = _require_regular_file(path, "history archive")
    try:
        with np.load(source, allow_pickle=False) as archive:
            if set(archive.files) != names:
                raise RuntimeError(f"history archive exact member set changed: {source}")
            return {name: np.asarray(archive[name]) for name in archive.files}
    except (OSError, ValueError) as exc:
        raise RuntimeError(f"invalid history archive: {source}") from exc


def _validate_filter_unit(
    root: Path,
    basin_id: str,
    *,
    source_bindings: AdmittedSourceBindings | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    unit = root / "filter" / f"basin_{basin_id}"
    production_rebound = (
        source_bindings is not None
        and source_bindings.installed_unit_records is not None
    )
    manifest, tree = _validate_unit_manifest(
        unit,
        schema_version=(
            "tukf09_455_rebound_filter_unit_manifest_v1"
            if production_rebound
            else "tukf09_filter_unit_manifest_v1"
        ),
        unit_type="filter_basin",
        unit_id=basin_id,
        expected_members=(
            FILTER_MEMBER_NAMES if production_rebound else LEGACY_FILTER_MEMBER_NAMES
        ),
    )
    identity = _read_json(unit / "identity.json", canonical=True)
    common_identity = (
        identity.get("experiment_id") == EXPERIMENT_ID
        and identity.get("unit_type") == "filter_basin"
        and identity.get("unit_id") == basin_id
        and identity.get("precision") == "float64"
        and identity.get("starts") == 8
        and identity.get("updates_per_start") == 31
        and identity.get("checkpoint_order") == "round_robin_by_step_then_start"
    )
    if production_rebound:
        exact_identity_keys = {
            "schema_version",
            "experiment_id",
            "unit_type",
            "unit_id",
            "state_dimension",
            "parameter_names",
            "physical_parameter_sha256",
            "training_period_sha256",
            "validation_period_sha256",
            "initial_state",
            "initial_covariance_diagonal",
            "base_observation_variance",
            "precision",
            "starts",
            "updates_per_start",
            "checkpoint_order",
            "scientific_contract_sha256",
            "preflight_final_manifest_sha256",
            "all_scope_authorization_sha256",
            "migration_config_sha256",
            "compatibility_projection_sha256",
        }
        if (
            set(identity) != exact_identity_keys
            or identity.get("schema_version")
            != "tukf09_455_rebound_filter_unit_identity_v1"
            or not common_identity
            or identity.get("scientific_contract_sha256")
            != source_bindings.scientific_contract_sha256
            or identity.get("preflight_final_manifest_sha256")
            != source_bindings.preflight_final_manifest_sha256
            or identity.get("all_scope_authorization_sha256")
            != source_bindings.all_scope_authorization_sha256
            or identity.get("migration_config_sha256")
            != source_bindings.migration_config_sha256
            or not _is_hex_sha256(identity.get("physical_parameter_sha256"))
            or not _is_hex_sha256(identity.get("training_period_sha256"))
            or not _is_hex_sha256(identity.get("validation_period_sha256"))
            or not _is_hex_sha256(identity.get("compatibility_projection_sha256"))
        ):
            raise RuntimeError(f"rebound filter unit identity changed: {basin_id}")
        installed_records = source_bindings.installed_unit_records
        assert installed_records is not None
        for member, record in tree.items():
            relative = f"filter/basin_{basin_id}/{member}"
            if installed_records.get(relative) != record:
                raise RuntimeError(
                    f"rebound filter differs from installation final manifest: {relative}"
                )
    elif (
        identity.get("schema_version") != "tukf09_filter_unit_identity_v1"
        or not common_identity
        or identity.get("training_admission_evaluation_access_count") != 0
        or not _is_hex_sha256(identity.get("runner_sha256"))
    ):
        raise RuntimeError(f"filter unit identity changed: {basin_id}")
    dimension = identity.get("state_dimension")
    if not isinstance(dimension, int) or isinstance(dimension, bool) or dimension < 1:
        raise RuntimeError(f"filter state dimension is invalid: {basin_id}")
    arrays = _load_npz_exact(
        unit / "history.npz",
        {
            "checkpoint_index",
            "start_index",
            "step_index",
            "theta_log",
            "training_objective",
            "validation_objective",
        },
    )
    expected_integer_arrays = {
        "checkpoint_index": np.arange(256, dtype=np.int64),
        "start_index": np.tile(np.arange(8, dtype=np.int64), 32),
        "step_index": np.repeat(np.arange(32, dtype=np.int64), 8),
    }
    for name, expected in expected_integer_arrays.items():
        if arrays[name].dtype != np.dtype("int64") or not np.array_equal(arrays[name], expected):
            raise RuntimeError(f"filter 256-record history order changed: {basin_id}:{name}")
    theta = arrays["theta_log"]
    training = arrays["training_objective"]
    validation = arrays["validation_objective"]
    if (
        theta.dtype != np.dtype("float64")
        or training.dtype != np.dtype("float64")
        or validation.dtype != np.dtype("float64")
        or theta.shape != (256, dimension + 1)
        or training.shape != (256,)
        or validation.shape != (256,)
        or not np.isfinite(theta).all()
        or not np.isfinite(training).all()
        or not np.isfinite(validation).all()
    ):
        raise RuntimeError(f"filter history shape, type, or finiteness changed: {basin_id}")
    with np.errstate(over="ignore", invalid="ignore"):
        actual = np.exp(theta)
    if not np.isfinite(actual).all() or np.any(actual <= 0.0):
        raise RuntimeError(f"filter actual parameters are invalid: {basin_id}")
    selected = min(
        range(256),
        key=lambda index: (
            float(validation[index]),
            float(training[index]),
            tuple(float(value) for value in actual[index]),
            index,
        ),
    )
    expected_selection = {
        "schema_version": (
            "tukf09_455_rebound_filter_unit_selection_v1"
            if production_rebound
            else "tukf09_filter_unit_selection_v1"
        ),
        "experiment_id": EXPERIMENT_ID,
        "unit_type": "filter_basin",
        "unit_id": basin_id,
        "status": (
            "FILTER_BASIN_REBOUND_FROM_VERIFIED_PARENT"
            if production_rebound
            else "FILTER_BASIN_SELECTED"
        ),
        "selected_index": selected,
        "selected_theta_log": theta[selected].tolist(),
        "selected_process_diagonal": actual[selected, :-1].tolist(),
        "selected_r_b": float(actual[selected, -1]),
        "selected_training_objective": float(training[selected]),
        "selected_validation_objective": float(validation[selected]),
        "checkpoint_count": FILTER_CHECKPOINT_COUNT,
        "training_query_count": FILTER_TRAINING_QUERY_COUNT,
        "validation_query_count": FILTER_VALIDATION_QUERY_COUNT,
        "filter_pass_count": FILTER_PASS_COUNT,
        "gradient_update_count": FILTER_GRADIENT_UPDATE_COUNT,
        "scored_target_count_by_period_and_lead": EXPECTED_SCORED_TARGET_COUNTS,
    }
    selection = _read_json(unit / "selection.json", canonical=True)
    if selection != expected_selection:
        raise RuntimeError(f"filter checkpoint selection does not recompute exactly: {basin_id}")
    expected_ledger = {
        "schema_version": (
            "tukf09_455_rebound_filter_unit_access_ledger_v1"
            if production_rebound
            else "tukf09_filter_unit_access_ledger_v1"
        ),
        "experiment_id": EXPERIMENT_ID,
        "unit_type": "filter_basin",
        "unit_id": basin_id,
        "training_period_loaded": True,
        "validation_period_loaded": True,
        "evaluation_array_read_count": 0,
        "evaluation_prediction_count": 0,
        "evaluation_metric_count": 0,
        "evaluation_output_write_count": 0,
        "formal_evaluation_authorized": False,
    }
    if production_rebound:
        expected_ledger["new_filter_optimization_count"] = 0
    if _read_json(unit / "access_ledger.json", canonical=True) != expected_ledger:
        raise RuntimeError(f"filter evaluation access ledger is nonzero or changed: {basin_id}")
    if production_rebound:
        provenance = _read_json(unit / "migration_provenance.json", canonical=True)
        expected_provenance_keys = {
            "schema_version",
            "experiment_id",
            "source_experiment_id",
            "unit_id",
            "migration_mode",
            "source_unit_path",
            "source_unit_manifest_sha256",
            "source_members",
            "history_byte_identity_required",
            "selection_numeric_identity_required",
            "source_runner_sha256",
            "source_contract_sha256",
            "source_preflight_final_manifest_sha256",
            "source_authorization_sha256",
            "source_training_admission_record_sha256",
            "scientific_contract_sha256",
            "preflight_final_manifest_sha256",
            "all_scope_authorization_sha256",
            "migration_config_sha256",
            "compatibility_projection_sha256",
        }
        source_members = provenance.get("source_members")
        source_member_names = {
            "identity.json",
            "history.npz",
            "selection.json",
            "access_ledger.json",
        }
        source_path = provenance.get("source_unit_path")
        if (
            set(provenance) != expected_provenance_keys
            or provenance.get("schema_version")
            != "tukf09_455_filter_unit_migration_provenance_v1"
            or provenance.get("experiment_id") != EXPERIMENT_ID
            or provenance.get("source_experiment_id") != PARENT_EXPERIMENT_ID
            or provenance.get("unit_id") != basin_id
            or provenance.get("migration_mode")
            != "byte_copy_history_and_rebuild_identity"
            or not isinstance(source_path, str)
            or not Path(source_path).is_absolute()
            or provenance.get("history_byte_identity_required") is not True
            or provenance.get("selection_numeric_identity_required") is not True
            or not _is_hex_sha256(provenance.get("source_unit_manifest_sha256"))
            or not isinstance(source_members, Mapping)
            or set(source_members) != source_member_names
            or source_members.get("history.npz") != tree["history.npz"]
            or any(
                not isinstance(source_members.get(name), Mapping)
                or set(source_members[name]) != {"sha256", "size_bytes"}
                or not _is_hex_sha256(source_members[name].get("sha256"))
                or isinstance(source_members[name].get("size_bytes"), bool)
                or not isinstance(source_members[name].get("size_bytes"), int)
                or source_members[name].get("size_bytes") < 0
                for name in source_member_names
            )
            or any(
                not _is_hex_sha256(provenance.get(name))
                for name in (
                    "source_runner_sha256",
                    "source_contract_sha256",
                    "source_preflight_final_manifest_sha256",
                    "source_authorization_sha256",
                    "source_training_admission_record_sha256",
                )
            )
            or any(
                provenance.get(name) != identity.get(name)
                for name in (
                    "scientific_contract_sha256",
                    "preflight_final_manifest_sha256",
                    "all_scope_authorization_sha256",
                    "migration_config_sha256",
                    "compatibility_projection_sha256",
                )
            )
        ):
            raise RuntimeError(f"rebound filter migration provenance changed: {basin_id}")
    entry = {
        "basin_id": basin_id,
        "unit_relative_path": f"filter/basin_{basin_id}",
        "unit_manifest_sha256": _sha256_file(unit / "manifest.sha256.json"),
        "unit_manifest_file_count": manifest["file_count"],
        "selected_index": selected,
        "selected_theta_log": selection["selected_theta_log"],
        "selected_process_diagonal": selection["selected_process_diagonal"],
        "selected_r_b": selection["selected_r_b"],
        "selected_training_objective": selection["selected_training_objective"],
        "selected_validation_objective": selection["selected_validation_objective"],
        "filter_result_origin": (
            "FILTER_BASIN_REBOUND_FROM_VERIFIED_PARENT"
            if production_rebound
            else "FILTER_BASIN_SELECTED"
        ),
        "inherited_checkpoint_records": FILTER_CHECKPOINT_COUNT,
        "inherited_training_objective_records": FILTER_TRAINING_QUERY_COUNT,
        "inherited_validation_objective_records": FILTER_VALIDATION_QUERY_COUNT,
        "inherited_gradient_update_records": FILTER_GRADIENT_UPDATE_COUNT,
        "new_filter_training_objective_calls": 0,
        "new_filter_validation_objective_calls": 0,
        "new_filter_gradient_updates": 0,
    }
    if production_rebound:
        entry.update(
            {
                "training_admission_record_sha256": (
                    source_bindings.training_admission_record_sha256
                ),
                "filter_migration_final_manifest_sha256": (
                    source_bindings.filter_migration_final_manifest_sha256
                ),
                "filter_installation_final_manifest_sha256": (
                    source_bindings.filter_installation_final_manifest_sha256
                ),
            }
        )
    return entry, tree


def _validate_neural_scaler(root: Path, basin_ids: Sequence[str]) -> tuple[str, dict[str, Any]]:
    shared = root / "neural" / "shared"
    if not shared.is_dir() or shared.is_symlink():
        raise FileNotFoundError("shared neural training scaler directory is absent or linked")
    children = list(shared.iterdir())
    if len(children) != 1 or children[0].name != "training_scaler.json":
        raise RuntimeError("shared neural directory exact member set changed")
    path = _require_regular_file(children[0], "training-only neural scaler")
    scaler = _read_json(path, canonical=True)
    expected_keys = {
        "schema_version",
        "experiment_id",
        "basin_ids",
        "forcing_feature_order",
        "forcing_center",
        "forcing_scale",
        "discharge_center",
        "discharge_scale",
        "per_basin_discharge_standard_deviation",
        "population_standard_deviation_ddof",
        "normalization_scope",
        "training_row_count",
    }
    if set(scaler) != expected_keys or (
        scaler.get("schema_version") != "tukf09_neural_training_scaler_v1"
        or scaler.get("experiment_id") != EXPERIMENT_ID
        or scaler.get("basin_ids") != list(basin_ids)
        or scaler.get("forcing_feature_order")
        != [
            "precipitation",
            "mean_air_temperature",
            "oudin_potential_evapotranspiration",
        ]
        or scaler.get("population_standard_deviation_ddof") != 0
        or scaler.get("normalization_scope")
        != "training_only_global_population_statistics"
        or scaler.get("training_row_count") != len(basin_ids) * TRAINING_DAYS
    ):
        raise RuntimeError("training-only neural normalization identity changed")
    center = np.asarray(scaler.get("forcing_center"), dtype=np.float64)
    scale = np.asarray(scaler.get("forcing_scale"), dtype=np.float64)
    basin_scale = scaler.get("per_basin_discharge_standard_deviation")
    if (
        center.shape != (3,)
        or scale.shape != (3,)
        or not np.isfinite(center).all()
        or not np.isfinite(scale).all()
        or np.any(scale <= 0.0)
        or not isinstance(basin_scale, dict)
        or set(basin_scale) != set(basin_ids)
    ):
        raise RuntimeError("training-only neural normalization arrays changed")
    numeric = [
        scaler.get("discharge_center"),
        scaler.get("discharge_scale"),
        *(basin_scale[basin_id] for basin_id in basin_ids),
    ]
    if any(isinstance(value, bool) or not isinstance(value, (int, float)) for value in numeric):
        raise RuntimeError("training-only neural normalization contains a non-number")
    values = np.asarray(numeric, dtype=np.float64)
    if not np.isfinite(values).all() or values[1] <= 0.0 or np.any(values[2:] <= 0.0):
        raise RuntimeError("training-only neural normalization is non-finite or non-positive")
    return _sha256_file(path), _record(path)


def _validate_neural_unit(
    root: Path,
    basin_ids: Sequence[str],
    scaler_sha256: str,
    lead_days: int,
    seed: int,
    *,
    source_bindings: AdmittedSourceBindings | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    unit_id = f"lead_{lead_days}_seed_{seed}"
    unit = root / "neural" / unit_id
    manifest, tree = _validate_unit_manifest(
        unit,
        schema_version="tukf09_neural_unit_manifest_v1",
        unit_type="neural_lead_seed",
        unit_id=unit_id,
        expected_members=NEURAL_MEMBER_NAMES,
    )
    identity = _read_json(unit / "identity.json", canonical=True)
    identity_unsigned = dict(identity)
    identity_sha256 = identity_unsigned.pop("identity_sha256", None)
    ordered_digest = sha256(
        "".join(f"{value}\n" for value in basin_ids).encode("utf-8")
    ).hexdigest()
    if (
        identity.get("schema_version") != "tukf09_neural_unit_identity_v1"
        or identity.get("experiment_id") != EXPERIMENT_ID
        or identity.get("unit_type") != "neural_lead_seed"
        or identity.get("unit_id") != unit_id
        or identity.get("lead_days") != lead_days
        or identity.get("seed") != seed
        or identity.get("basin_count") != len(basin_ids)
        or identity.get("ordered_basin_newline_sha256") != ordered_digest
        or identity.get("training_sample_count")
        != len(basin_ids) * TRAINING_SAMPLES_PER_BASIN
        or identity.get("validation_sample_count")
        != len(basin_ids) * VALIDATION_SAMPLES_PER_BASIN
        or identity.get("epochs") != NEURAL_CHECKPOINT_COUNT
        or identity.get("batch_size") != 256
        or identity.get("training_scaler_sha256") != scaler_sha256
        or identity.get("tensorfloat32") is not False
        or identity.get("evaluation_access_count") != 0
        or not _is_hex_sha256(identity.get("runner_sha256"))
        or not _is_hex_sha256(identity.get("frozen_model_source_sha256"))
        or identity_sha256 != _canonical_payload_sha256(identity_unsigned)
    ):
        raise RuntimeError(f"neural unit identity changed: {unit_id}")
    admission_evidence = identity.get("admission_evidence")
    if source_bindings is not None and (
        identity.get("runner_sha256") != source_bindings.neural_runner_sha256
        or identity.get("frozen_model_source_sha256")
        != source_bindings.frozen_model_source_sha256
        or not isinstance(admission_evidence, Mapping)
        or admission_evidence.get("training_admission_record_sha256")
        != source_bindings.training_admission_record_sha256
    ):
        raise RuntimeError(
            f"neural unit identity differs from admitted sources or admission: {unit_id}"
        )
    arrays = _load_npz_exact(
        unit / "validation_history.npz",
        {
            "epochs",
            "basin_ids",
            "training_loss",
            "maximum_gradient_norm",
            "learning_rate",
            "validation_nse_by_basin",
            "validation_median_nse",
            "evaluation_access_count",
        },
    )
    if arrays["epochs"].dtype != np.dtype("int64") or not np.array_equal(
        arrays["epochs"], np.arange(1, 31, dtype=np.int64)
    ):
        raise RuntimeError(f"neural 30-checkpoint epoch order changed: {unit_id}")
    if arrays["basin_ids"].tolist() != list(basin_ids):
        raise RuntimeError(f"neural validation basin order changed: {unit_id}")
    training_loss = arrays["training_loss"]
    gradient_norm = arrays["maximum_gradient_norm"]
    learning_rate = arrays["learning_rate"]
    validation_nse = arrays["validation_nse_by_basin"]
    medians = arrays["validation_median_nse"]
    numeric_arrays = (training_loss, gradient_norm, learning_rate, validation_nse, medians)
    if any(array.dtype != np.dtype("float64") for array in numeric_arrays) or (
        training_loss.shape != (30,)
        or gradient_norm.shape != (30,)
        or learning_rate.shape != (30,)
        or validation_nse.shape != (30, len(basin_ids))
        or medians.shape != (30,)
        or any(not np.isfinite(array).all() for array in numeric_arrays)
        or np.any(gradient_norm < 0.0)
    ):
        raise RuntimeError(f"neural validation history shape, type, or finiteness changed: {unit_id}")
    expected_rates = np.asarray(
        [0.001 if epoch < 10 else 0.0005 if epoch < 25 else 0.0001 for epoch in range(1, 31)],
        dtype=np.float64,
    )
    recomputed_medians = np.median(validation_nse, axis=1)
    if not np.array_equal(learning_rate, expected_rates) or not np.array_equal(
        medians, recomputed_medians
    ):
        raise RuntimeError(f"neural schedule or validation medians do not recompute: {unit_id}")
    evaluation_access = arrays["evaluation_access_count"]
    if evaluation_access.dtype != np.dtype("int64") or not np.array_equal(
        evaluation_access, np.asarray([0], dtype=np.int64)
    ):
        raise RuntimeError(f"neural history records evaluation access: {unit_id}")
    selected_epoch = int(np.flatnonzero(medians == np.max(medians))[0]) + 1
    selected_relative = f"checkpoints/epoch_{selected_epoch:03d}.pt"
    expected_selection = {
        "schema_version": "tukf09_neural_model_selection_v1",
        "experiment_id": EXPERIMENT_ID,
        "unit_id": unit_id,
        "lead_days": lead_days,
        "seed": seed,
        "selected_epoch": selected_epoch,
        "selected_checkpoint_relative_path": selected_relative,
        "selected_checkpoint_sha256": _sha256_file(unit / selected_relative),
        "validation_median_nse": float(medians[selected_epoch - 1]),
        "checkpoint_count": NEURAL_CHECKPOINT_COUNT,
        "selection_rule": "largest_455_basin_median_nse_earliest_epoch_tie_break",
        "best_seed_selection_forbidden": True,
        "evaluation_access_count": 0,
    }
    selection = _read_json(unit / "model_selection.json", canonical=True)
    if selection != expected_selection:
        raise RuntimeError(f"neural checkpoint selection does not recompute exactly: {unit_id}")
    expected_ledger = {
        "schema_version": "tukf09_neural_access_ledger_v1",
        "experiment_id": EXPERIMENT_ID,
        "unit_id": unit_id,
        "lead_days": lead_days,
        "training": {
            "sample_count": len(basin_ids) * TRAINING_SAMPLES_PER_BASIN,
            "first_target_index": SEQUENCE_LENGTH,
            "last_target_index": TRAINING_DAYS - 1,
            "maximum_discharge_source_offset_days": lead_days,
            "meteorological_forcing_through_target": True,
        },
        "validation": {
            "sample_count": len(basin_ids) * VALIDATION_SAMPLES_PER_BASIN,
            "first_target_index": SEQUENCE_LENGTH,
            "last_target_index": VALIDATION_DAYS - 1,
            "maximum_discharge_source_offset_days": lead_days,
            "meteorological_forcing_through_target": True,
        },
        "evaluation_access_count": 0,
        "evaluation_prediction_count": 0,
        "evaluation_metric_count": 0,
    }
    if _read_json(unit / "access_ledger.json", canonical=True) != expected_ledger:
        raise RuntimeError(f"neural evaluation access ledger is nonzero or changed: {unit_id}")
    entry = {
        "unit_id": unit_id,
        "lead_days": lead_days,
        "seed": seed,
        "unit_relative_path": f"neural/{unit_id}",
        "unit_manifest_sha256": _sha256_file(unit / "manifest.sha256.json"),
        "unit_manifest_file_count": manifest["file_count"],
        "training_scaler_sha256": scaler_sha256,
        "selected_epoch": selected_epoch,
        "selected_checkpoint_relative_path": f"neural/{unit_id}/{selected_relative}",
        "selected_checkpoint_sha256": selection["selected_checkpoint_sha256"],
        "validation_median_nse": selection["validation_median_nse"],
        "best_seed_selection_forbidden": True,
    }
    return entry, tree


def _completion_counts(expectations: SelectionExpectations) -> dict[str, int]:
    filter_count = len(expectations.basin_ids)
    neural_count = len(expectations.neural_units)
    return {
        "rebound_filter_units": filter_count,
        "new_filter_training_units": 0,
        "inherited_filter_checkpoint_records": filter_count * FILTER_CHECKPOINT_COUNT,
        "new_filter_training_objective_calls": 0,
        "new_filter_validation_objective_calls": 0,
        "new_filter_gradient_updates": 0,
        "neural_model_units": neural_count,
        "neural_checkpoints": neural_count * NEURAL_CHECKPOINT_COUNT,
        "evaluation_array_reads": 0,
        "evaluation_predictions": 0,
        "evaluation_metrics": 0,
        "evaluation_outputs": 0,
    }


def _controller_and_log_records(
    root: Path, *, phase_owner: Any | None = None
) -> dict[str, Any]:
    """Bind all completed controller evidence without accepting active locks."""

    records: dict[str, Any] = {}
    excluded_owner = (
        _validate_owned_phase_lock(root, phase_owner) if phase_owner is not None else None
    )
    for directory_name in ("control", "logs"):
        directory = root / directory_name
        if not _path_exists(directory):
            continue
        if not directory.is_dir() or directory.is_symlink():
            raise RuntimeError(f"{directory_name} training evidence root is invalid")
        for path in directory.rglob("*"):
            relative = path.relative_to(root).as_posix()
            if path.is_symlink():
                raise RuntimeError(f"linked controller evidence is forbidden: {relative}")
            if path.is_dir():
                continue
            if not path.is_file() or path.stat().st_nlink != 1:
                raise RuntimeError(f"non-regular controller evidence is forbidden: {relative}")
            if relative == excluded_owner:
                continue
            records[relative] = _record(path)
    return records


def _collect_selection_payloads(
    root: Path,
    expectations: SelectionExpectations,
    *,
    phase_owner: Any | None = None,
) -> tuple[dict[str, bytes], dict[str, Any]]:
    _validate_no_forbidden_surface(root, phase_owner=phase_owner)
    evidence_records, source_bindings = _validate_root_evidence(root, expectations)
    filter_root = root / "filter"
    if not filter_root.is_dir() or filter_root.is_symlink():
        raise FileNotFoundError("filter training root is absent or linked")
    expected_filter_directories = {f"basin_{value}" for value in expectations.basin_ids}
    actual_filter = {path.name for path in filter_root.iterdir()}
    if actual_filter != expected_filter_directories or any(
        not path.is_dir() or path.is_symlink() for path in filter_root.iterdir()
    ):
        raise RuntimeError("filter training exact unit set differs")
    neural_root = root / "neural"
    if not neural_root.is_dir() or neural_root.is_symlink():
        raise FileNotFoundError("neural training root is absent or linked")
    neural_unit_ids = tuple(f"lead_{lead}_seed_{seed}" for lead, seed in expectations.neural_units)
    expected_neural_directories = {"shared", *neural_unit_ids}
    actual_neural = {path.name for path in neural_root.iterdir()}
    if actual_neural != expected_neural_directories or any(
        not path.is_dir() or path.is_symlink() for path in neural_root.iterdir()
    ):
        raise RuntimeError("neural training exact unit set differs")

    training_tree: dict[str, Any] = dict(evidence_records)
    training_tree.update(_controller_and_log_records(root, phase_owner=phase_owner))
    filter_entries: list[dict[str, Any]] = []
    for basin_id in expectations.basin_ids:
        entry, tree = _validate_filter_unit(
            root, basin_id, source_bindings=source_bindings
        )
        filter_entries.append(entry)
        prefix = f"filter/basin_{basin_id}/"
        training_tree.update({prefix + name: record for name, record in tree.items()})
    scaler_sha256, scaler_record = _validate_neural_scaler(root, expectations.basin_ids)
    training_tree["neural/shared/training_scaler.json"] = scaler_record
    neural_entries: list[dict[str, Any]] = []
    for lead_days, seed in expectations.neural_units:
        entry, tree = _validate_neural_unit(
            root,
            expectations.basin_ids,
            scaler_sha256,
            lead_days,
            seed,
            source_bindings=source_bindings,
        )
        neural_entries.append(entry)
        prefix = f"neural/lead_{lead_days}_seed_{seed}/"
        training_tree.update({prefix + name: record for name, record in tree.items()})

    counts = _completion_counts(expectations)
    if expectations.production:
        if counts != EXPECTED_COMPLETION_COUNTS:
            raise AssertionError("production completion totals changed")
    basin_digest = sha256(
        "".join(f"{value}\n" for value in expectations.basin_ids).encode("utf-8")
    ).hexdigest()
    filter_registry = {
        "schema_version": "tukf09_filter_training_selection_registry_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "FILTER_REBOUND_SELECTION_COMPLETE_EVALUATION_HOLD",
        "basin_count": len(expectations.basin_ids),
        "ordered_basin_newline_sha256": basin_digest,
        "checkpoint_count_per_basin": FILTER_CHECKPOINT_COUNT,
        "filter_result_origin": "FILTER_BASIN_REBOUND_FROM_VERIFIED_PARENT",
        "new_filter_training_units": 0,
        "selection_rule": (
            "minimum_validation_objective_then_training_objective_then_actual_parameters_then_index"
        ),
        "formal_evaluation_authorized": False,
        "evaluation_access_count": 0,
        "units": filter_entries,
    }
    neural_registry = {
        "schema_version": "tukf09_neural_training_selection_registry_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "NEURAL_TRAINING_SELECTION_COMPLETE_EVALUATION_HOLD",
        "model_count": len(expectations.neural_units),
        "ordered_basin_newline_sha256": basin_digest,
        "training_scaler_relative_path": "neural/shared/training_scaler.json",
        "training_scaler_sha256": scaler_sha256,
        "normalization_scope": "training_only_global_population_statistics",
        "checkpoint_count_per_model": NEURAL_CHECKPOINT_COUNT,
        "selection_rule": "largest_455_basin_median_nse_earliest_epoch_tie_break",
        "best_seed_selection_forbidden": True,
        "formal_evaluation_authorized": False,
        "evaluation_access_count": 0,
        "units": neural_entries,
    }
    filter_bytes = _canonical_json_bytes(filter_registry)
    neural_bytes = _canonical_json_bytes(neural_registry)
    summary = {
        "schema_version": "tukf09_selected_model_summary_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "TRAINING_MODEL_SELECTION_COMPLETE_EVALUATION_HOLD",
        "filter_registry_sha256": sha256(filter_bytes).hexdigest(),
        "neural_registry_sha256": sha256(neural_bytes).hexdigest(),
        "filter_selected_model_count": len(filter_entries),
        "neural_selected_model_count": len(neural_entries),
        "completion_counts": counts,
        "evaluation_access_ledger": {
            "evaluation_array_reads": 0,
            "evaluation_predictions": 0,
            "evaluation_metrics": 0,
            "evaluation_outputs": 0,
        },
        "formal_evaluation_authorized": False,
        "independent_training_selection_verification_required": True,
    }
    summary_bytes = _canonical_json_bytes(summary)
    selection_records = {
        "selection/filter_registry.json": {
            "sha256": sha256(filter_bytes).hexdigest(),
            "size_bytes": len(filter_bytes),
        },
        "selection/neural_registry.json": {
            "sha256": sha256(neural_bytes).hexdigest(),
            "size_bytes": len(neural_bytes),
        },
        "selection/selected_model_summary.json": {
            "sha256": sha256(summary_bytes).hexdigest(),
            "size_bytes": len(summary_bytes),
        },
    }
    training_tree.update(selection_records)
    training_tree = dict(sorted(training_tree.items()))
    manifest = {
        "schema_version": "tukf09_full_training_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "FULL_TRAINING_MANIFEST_COMPLETE_EVALUATION_HOLD",
        "file_count": len(training_tree),
        "files": training_tree,
        "files_canonical_sha256": _canonical_payload_sha256(training_tree),
        "completion_counts": counts,
        "formal_evaluation_authorized": False,
    }
    manifest_bytes = _canonical_json_bytes(manifest)
    seal = {
        "schema_version": "tukf09_training_selection_seal_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "TRAINING_SELECTION_SEALED_EVALUATION_HOLD",
        "training_manifest_relative_path": "selection/training_manifest.sha256.json",
        "training_manifest_sha256": sha256(manifest_bytes).hexdigest(),
        "training_manifest_file_count": manifest["file_count"],
        "selection_directory_member_count": 5,
        "completion_counts": counts,
        "evaluation_access_ledger": summary["evaluation_access_ledger"],
        "formal_evaluation_authorized": False,
        "evaluation_prediction_generation_authorized": False,
        "evaluation_metric_computation_authorized": False,
        "independent_training_selection_verification_required": True,
    }
    payloads = {
        "filter_registry.json": filter_bytes,
        "neural_registry.json": neural_bytes,
        "selected_model_summary.json": summary_bytes,
        "training_manifest.sha256.json": manifest_bytes,
        "training_selection.sealed.json": _canonical_json_bytes(seal),
    }
    if set(payloads) != SELECTION_MEMBER_NAMES:
        raise AssertionError("internal selection directory member set changed")
    return payloads, seal


def _verify_existing_directory(destination: Path, payloads: Mapping[str, bytes]) -> None:
    if not destination.is_dir() or destination.is_symlink():
        raise FileExistsError(f"selection destination exists but is not an unlinked directory: {destination}")
    actual: set[str] = set()
    for path in destination.rglob("*"):
        if path.is_symlink() or not path.is_file() or path.stat().st_nlink != 1:
            raise RuntimeError(f"sealed selection contains a linked or non-file member: {path}")
        actual.add(path.relative_to(destination).as_posix())
    if actual != set(payloads):
        raise RuntimeError("existing selection directory exact member set changed")
    for relative, expected in payloads.items():
        if (destination / relative).read_bytes() != expected:
            raise RuntimeError(f"existing selection artifact differs: {relative}")


def _atomic_publish_directory(destination: Path, payloads: Mapping[str, bytes]) -> None:
    target = Path(destination)
    if _path_exists(target):
        raise FileExistsError(f"selection destination already exists: {target}")
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.parent.is_symlink():
        raise RuntimeError("selection parent is linked")
    token = uuid.uuid4().hex
    pending = target.with_name(f".selection.pending-{token}")
    pending.mkdir(parents=False, exist_ok=False)
    try:
        for relative, content in sorted(payloads.items()):
            if Path(relative).is_absolute() or Path(relative).name != relative:
                raise ValueError(f"selection member must be a direct relative file: {relative}")
            path = pending / relative
            with path.open("xb") as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
        if {path.name for path in pending.iterdir()} != set(payloads):
            raise RuntimeError("pending selection exact member set changed")
        if _path_exists(target):
            raise FileExistsError("selection destination appeared during publication")
        os.replace(pending, target)
    finally:
        if _path_exists(pending):
            if pending.parent != target.parent or token not in pending.name:
                raise RuntimeError("refusing to remove an unowned selection pending directory")
            shutil.rmtree(pending)


def seal_training_selection(
    *,
    output_root: str | Path,
    population_registry: str | Path | None = None,
    execution_config: str | Path | None = None,
    expected_basin_ids: Sequence[str] | None = None,
    expected_neural_units: Sequence[Any] | None = None,
    seal_training_selection: bool,
) -> dict[str, Any]:
    """Recompute every training choice and atomically publish the selection seal."""

    if seal_training_selection is not True:
        raise PermissionError("explicit training-selection sealing authorization is required")
    root = Path(output_root)
    if not root.is_dir() or root.is_symlink():
        raise FileNotFoundError("formal training result root is absent or linked")
    control = root / "control"
    if _path_exists(control) and (not control.is_dir() or control.is_symlink()):
        raise RuntimeError("training control root is linked or invalid")
    with phase_common.training_phase_lock(control, "seal") as phase_owner:
        expectations = _load_expectations(
            output_root=root,
            population_registry=(
                Path(population_registry) if population_registry is not None else None
            ),
            execution_config=(Path(execution_config) if execution_config is not None else None),
            expected_basin_ids=expected_basin_ids,
            expected_neural_units=expected_neural_units,
        )
        payloads, seal = _collect_selection_payloads(
            root, expectations, phase_owner=phase_owner
        )
        destination = root / "selection"
        reused = False
        if _path_exists(destination):
            _verify_existing_directory(destination, payloads)
            reused = True
        else:
            _atomic_publish_directory(destination, payloads)
            _verify_existing_directory(destination, payloads)

    # Recompute after the exact owned phase lock has been identity-checked and
    # removed.  This proves that the manifest did not self-reference its lock
    # and that no controller/log member changed across publication.
    post_payloads, post_seal = _collect_selection_payloads(root, expectations)
    if post_payloads != payloads or post_seal != seal:
        raise RuntimeError("training tree changed across phase-lock release")
    _verify_existing_directory(destination, post_payloads)
    return {
        "status": seal["status"],
        "selection_root": str(destination.resolve(strict=False)),
        "training_manifest_sha256": seal["training_manifest_sha256"],
        "filter_basin_units": len(expectations.basin_ids),
        "neural_model_units": len(expectations.neural_units),
        "formal_evaluation_authorized": False,
        "reused": reused,
    }


seal_tukf09_training_selection = seal_training_selection


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--population-registry", type=Path, default=DEFAULT_POPULATION_REGISTRY)
    parser.add_argument("--execution-config", type=Path, default=DEFAULT_EXECUTION_CONFIG)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--seal-training-selection", action="store_true")
    return parser


def main() -> None:
    arguments = _parser().parse_args()
    result = seal_training_selection(
        output_root=arguments.output_root,
        population_registry=arguments.population_registry,
        execution_config=arguments.execution_config,
        seal_training_selection=arguments.seal_training_selection,
    )
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
