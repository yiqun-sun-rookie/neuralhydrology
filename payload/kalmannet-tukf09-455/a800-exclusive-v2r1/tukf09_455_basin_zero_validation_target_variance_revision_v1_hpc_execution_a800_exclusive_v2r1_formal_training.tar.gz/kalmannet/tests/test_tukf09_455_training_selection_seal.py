from __future__ import annotations

import ast
from hashlib import sha256
from io import BytesIO
import json
import os
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import pytest

from scripts import seal_tukf09_455_training_selection as sealer
from scripts import tukf09_455_training_common as training_common
from scripts import verify_tukf09_455_training_selection as independent_verifier
from scripts.seal_tukf09_455_training_selection import seal_training_selection
from scripts.verify_tukf09_455_training_selection import (
    verify_training_selection_independently,
)


EXPERIMENT_ID = "TUKF09_455_BASIN_ZERO_VALIDATION_TARGET_VARIANCE_REVISION_V1"
ROOT_MEMBERS = (
    "authorization.snapshot.json",
    "scientific_contract.snapshot.json",
    "execution_config.snapshot.json",
    "training_admission.snapshot.json",
    "training_context.json",
)
REQUIRED_SOURCE_PATHS = training_common.REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS
FILTER_RUNNER_SHA256 = "1" * 64
NEURAL_RUNNER_SHA256 = "2" * 64
FROZEN_MODEL_SHA256 = "3" * 64
TRAINING_ADMISSION_RECORD_SHA256 = "4" * 64
ALL_SCOPE_AUTHORIZATION_SHA256 = "5" * 64
MIGRATION_CONFIG_SHA256 = "6" * 64
FILTER_MIGRATION_FINAL_SHA256 = "7" * 64
FILTER_INSTALLATION_FINAL_SHA256 = "8" * 64
SCIENTIFIC_CONTRACT_SHA256 = "9" * 64
PREFLIGHT_FINAL_SHA256 = "a" * 64
COMPATIBILITY_PROJECTION_SHA256 = "b" * 64


def _json_bytes(value: Any) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")


def _write_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(_json_bytes(value))


def _record(path: Path) -> dict[str, Any]:
    raw = path.read_bytes()
    return {"sha256": sha256(raw).hexdigest(), "size_bytes": len(raw)}


def _source_project_and_admission(tmp_path: Path) -> tuple[Path, dict[str, Any]]:
    project = tmp_path / "source_project"
    executables: dict[str, dict[str, Any]] = {}
    for relative in REQUIRED_SOURCE_PATHS:
        path = project / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes((relative + "\n").encode("utf-8"))
        executables[relative] = _record(path)
    return project, {"executables": executables}


def _source_bindings(module: Any) -> Any:
    return module.AdmittedSourceBindings(
        training_admission_record_sha256=TRAINING_ADMISSION_RECORD_SHA256,
        neural_runner_sha256=NEURAL_RUNNER_SHA256,
        frozen_model_source_sha256=FROZEN_MODEL_SHA256,
    )


def _rewrite_filter_identity(
    root: Path,
    basin_id: str,
    **overrides: Any,
) -> None:
    unit = root / "filter" / f"basin_{basin_id}"
    identity_path = unit / "identity.json"
    identity = json.loads(identity_path.read_text(encoding="utf-8"))
    identity.update(
        {
            "runner_sha256": FILTER_RUNNER_SHA256,
            "training_admission_record_sha256": TRAINING_ADMISSION_RECORD_SHA256,
            **overrides,
        }
    )
    _write_json(identity_path, identity)
    _write_manifest(
        unit,
        schema_version="tukf09_filter_unit_manifest_v1",
        unit_type="filter_basin",
        unit_id=basin_id,
    )


def _rewrite_neural_identity(
    root: Path,
    lead_days: int,
    seed: int,
    **overrides: Any,
) -> None:
    unit_id = f"lead_{lead_days}_seed_{seed}"
    unit = root / "neural" / unit_id
    identity_path = unit / "identity.json"
    identity = json.loads(identity_path.read_text(encoding="utf-8"))
    identity.pop("identity_sha256", None)
    identity.update(
        {
            "runner_sha256": NEURAL_RUNNER_SHA256,
            "frozen_model_source_sha256": FROZEN_MODEL_SHA256,
            "admission_evidence": {
                "training_admission_record_sha256": TRAINING_ADMISSION_RECORD_SHA256
            },
            **overrides,
        }
    )
    identity["identity_sha256"] = sha256(_json_bytes(identity)[:-1]).hexdigest()
    _write_json(identity_path, identity)
    _write_manifest(
        unit,
        schema_version="tukf09_neural_unit_manifest_v1",
        unit_type="neural_lead_seed",
        unit_id=unit_id,
    )


def _npz_bytes(arrays: Mapping[str, np.ndarray]) -> bytes:
    destination = BytesIO()
    np.savez(destination, **arrays)
    return destination.getvalue()


def _write_manifest(
    directory: Path,
    *,
    schema_version: str,
    unit_type: str,
    unit_id: str,
) -> None:
    files = {
        member.relative_to(directory).as_posix(): _record(member)
        for member in sorted(directory.rglob("*"))
        if member.is_file() and member.name != "manifest.sha256.json"
    }
    _write_json(
        directory / "manifest.sha256.json",
        {
            "schema_version": schema_version,
            "experiment_id": EXPERIMENT_ID,
            "unit_type": unit_type,
            "unit_id": unit_id,
            "file_count": len(files),
            "files": files,
        },
    )


def _filter_selection(
    basin_id: str,
    theta_log: np.ndarray,
    training: np.ndarray,
    validation: np.ndarray,
) -> dict[str, Any]:
    actual = np.exp(theta_log)
    selected = min(
        range(256),
        key=lambda index: (
            float(validation[index]),
            float(training[index]),
            tuple(float(value) for value in actual[index]),
            index,
        ),
    )
    return {
        "schema_version": "tukf09_filter_unit_selection_v1",
        "experiment_id": EXPERIMENT_ID,
        "unit_type": "filter_basin",
        "unit_id": basin_id,
        "status": "FILTER_BASIN_SELECTED",
        "selected_index": selected,
        "selected_theta_log": theta_log[selected].tolist(),
        "selected_process_diagonal": actual[selected, :-1].tolist(),
        "selected_r_b": float(actual[selected, -1]),
        "selected_training_objective": float(training[selected]),
        "selected_validation_objective": float(validation[selected]),
        "checkpoint_count": 256,
        "training_query_count": 256,
        "validation_query_count": 256,
        "filter_pass_count": 512,
        "gradient_update_count": 248,
        "scored_target_count_by_period_and_lead": {
            "training": {"1": 2190, "2": 2191, "3": 2192},
            "validation": {"1": 364, "2": 365, "3": 366},
        },
    }


def _create_filter_unit(root: Path, basin_id: str) -> None:
    unit = root / "filter" / f"basin_{basin_id}"
    unit.mkdir(parents=True)
    checkpoint = np.arange(256, dtype=np.float64)
    theta = np.column_stack(
        (
            -5.0 + checkpoint / 10000.0,
            -4.0 + checkpoint / 20000.0,
            -3.0 + checkpoint / 30000.0,
        )
    )
    training = 2.0 + np.square(checkpoint - 8.0) / 1000.0
    validation = 1.0 + np.square(checkpoint - 7.0) / 1000.0
    history = {
        "checkpoint_index": np.arange(256, dtype=np.int64),
        "start_index": np.tile(np.arange(8, dtype=np.int64), 32),
        "step_index": np.repeat(np.arange(32, dtype=np.int64), 8),
        "theta_log": theta,
        "training_objective": training,
        "validation_objective": validation,
    }
    (unit / "history.npz").write_bytes(_npz_bytes(history))
    _write_json(
        unit / "identity.json",
        {
            "schema_version": "tukf09_filter_unit_identity_v1",
            "experiment_id": EXPERIMENT_ID,
            "unit_type": "filter_basin",
            "unit_id": basin_id,
            "state_dimension": 2,
            "parameter_names": ["p"],
            "precision": "float64",
            "starts": 8,
            "updates_per_start": 31,
            "checkpoint_order": "round_robin_by_step_then_start",
            "runner_sha256": "1" * 64,
            "training_admission_evaluation_access_count": 0,
        },
    )
    _write_json(unit / "selection.json", _filter_selection(basin_id, theta, training, validation))
    _write_json(
        unit / "access_ledger.json",
        {
            "schema_version": "tukf09_filter_unit_access_ledger_v1",
            "experiment_id": EXPERIMENT_ID,
            "unit_type": "filter_basin",
            "unit_id": basin_id,
            "training_period_loaded": True,
            "validation_period_loaded": True,
            "evaluation_array_read_count": 0,
            "evaluation_prediction_count": 0,
            "evaluation_metric_count": 0,
            "evaluation_output_write_count": 0,
            "formal_evaluation_authorized": False,
        },
    )
    _write_manifest(
        unit,
        schema_version="tukf09_filter_unit_manifest_v1",
        unit_type="filter_basin",
        unit_id=basin_id,
    )


def _convert_filter_unit_to_rebound(root: Path, basin_id: str) -> None:
    unit = root / "filter" / f"basin_{basin_id}"
    source_records = {
        name: _record(unit / name)
        for name in (
            "identity.json",
            "history.npz",
            "selection.json",
            "access_ledger.json",
        )
    }
    source_manifest_sha256 = sha256(
        (unit / "manifest.sha256.json").read_bytes()
    ).hexdigest()
    hashes = {
        "scientific_contract_sha256": SCIENTIFIC_CONTRACT_SHA256,
        "preflight_final_manifest_sha256": PREFLIGHT_FINAL_SHA256,
        "all_scope_authorization_sha256": ALL_SCOPE_AUTHORIZATION_SHA256,
        "migration_config_sha256": MIGRATION_CONFIG_SHA256,
        "compatibility_projection_sha256": COMPATIBILITY_PROJECTION_SHA256,
    }
    _write_json(
        unit / "identity.json",
        {
            "schema_version": "tukf09_455_rebound_filter_unit_identity_v1",
            "experiment_id": EXPERIMENT_ID,
            "unit_type": "filter_basin",
            "unit_id": basin_id,
            "state_dimension": 2,
            "parameter_names": ["p"],
            "physical_parameter_sha256": "c" * 64,
            "training_period_sha256": "d" * 64,
            "validation_period_sha256": "e" * 64,
            "initial_state": [1.0, 2.0],
            "initial_covariance_diagonal": [0.1, 0.2],
            "base_observation_variance": 1.5,
            "precision": "float64",
            "starts": 8,
            "updates_per_start": 31,
            "checkpoint_order": "round_robin_by_step_then_start",
            **hashes,
        },
    )
    selection_path = unit / "selection.json"
    selection = json.loads(selection_path.read_text(encoding="utf-8"))
    selection.update(
        {
            "schema_version": "tukf09_455_rebound_filter_unit_selection_v1",
            "status": "FILTER_BASIN_REBOUND_FROM_VERIFIED_PARENT",
        }
    )
    _write_json(selection_path, selection)
    ledger_path = unit / "access_ledger.json"
    ledger = json.loads(ledger_path.read_text(encoding="utf-8"))
    ledger.update(
        {
            "schema_version": "tukf09_455_rebound_filter_unit_access_ledger_v1",
            "new_filter_optimization_count": 0,
        }
    )
    _write_json(ledger_path, ledger)
    _write_json(
        unit / "migration_provenance.json",
        {
            "schema_version": "tukf09_455_filter_unit_migration_provenance_v1",
            "experiment_id": EXPERIMENT_ID,
            "source_experiment_id": (
                "TUKF09_BACKPROPAGATION_VS_NEURAL_BACKWARD_TIME_CONFIRMATION_V1"
            ),
            "unit_id": basin_id,
            "migration_mode": "byte_copy_history_and_rebuild_identity",
            "source_unit_path": str(unit.resolve()),
            "source_unit_manifest_sha256": source_manifest_sha256,
            "source_members": source_records,
            "history_byte_identity_required": True,
            "selection_numeric_identity_required": True,
            "source_runner_sha256": "f" * 64,
            "source_contract_sha256": "1" * 64,
            "source_preflight_final_manifest_sha256": "2" * 64,
            "source_authorization_sha256": "3" * 64,
            "source_training_admission_record_sha256": "4" * 64,
            **hashes,
        },
    )
    _write_manifest(
        unit,
        schema_version="tukf09_455_rebound_filter_unit_manifest_v1",
        unit_type="filter_basin",
        unit_id=basin_id,
    )


def _production_source_bindings(module: Any, root: Path, basin_id: str) -> Any:
    unit = root / "filter" / f"basin_{basin_id}"
    installed_records = {
        f"filter/basin_{basin_id}/{path.name}": _record(path)
        for path in unit.iterdir()
        if path.is_file()
    }
    return module.AdmittedSourceBindings(
        training_admission_record_sha256=TRAINING_ADMISSION_RECORD_SHA256,
        neural_runner_sha256=NEURAL_RUNNER_SHA256,
        frozen_model_source_sha256=FROZEN_MODEL_SHA256,
        all_scope_authorization_sha256=ALL_SCOPE_AUTHORIZATION_SHA256,
        migration_config_sha256=MIGRATION_CONFIG_SHA256,
        filter_migration_final_manifest_sha256=FILTER_MIGRATION_FINAL_SHA256,
        filter_installation_final_manifest_sha256=FILTER_INSTALLATION_FINAL_SHA256,
        installed_unit_records=installed_records,
        scientific_contract_sha256=SCIENTIFIC_CONTRACT_SHA256,
        preflight_final_manifest_sha256=PREFLIGHT_FINAL_SHA256,
    )


def _create_neural_shared(root: Path, basin_ids: Sequence[str]) -> str:
    scaler = {
        "schema_version": "tukf09_neural_training_scaler_v1",
        "experiment_id": EXPERIMENT_ID,
        "basin_ids": list(basin_ids),
        "forcing_feature_order": [
            "precipitation",
            "mean_air_temperature",
            "oudin_potential_evapotranspiration",
        ],
        "forcing_center": [1.0, 2.0, 3.0],
        "forcing_scale": [2.0, 3.0, 4.0],
        "discharge_center": 5.0,
        "discharge_scale": 6.0,
        "per_basin_discharge_standard_deviation": {
            basin_id: float(index + 1) for index, basin_id in enumerate(basin_ids)
        },
        "population_standard_deviation_ddof": 0,
        "normalization_scope": "training_only_global_population_statistics",
        "training_row_count": len(basin_ids) * 2557,
    }
    path = root / "neural" / "shared" / "training_scaler.json"
    _write_json(path, scaler)
    return sha256(path.read_bytes()).hexdigest()


def _create_neural_unit(
    root: Path,
    basin_ids: Sequence[str],
    scaler_sha256: str,
    lead_days: int,
    seed: int,
) -> None:
    unit_id = f"lead_{lead_days}_seed_{seed}"
    unit = root / "neural" / unit_id
    checkpoints = unit / "checkpoints"
    checkpoints.mkdir(parents=True)
    for epoch in range(1, 31):
        (checkpoints / f"epoch_{epoch:03d}.pt").write_bytes(
            f"{unit_id}:{epoch}\n".encode("ascii")
        )
    identity_without_hash = {
        "schema_version": "tukf09_neural_unit_identity_v1",
        "experiment_id": EXPERIMENT_ID,
        "unit_type": "neural_lead_seed",
        "unit_id": unit_id,
        "lead_days": lead_days,
        "seed": seed,
        "basin_count": len(basin_ids),
        "ordered_basin_newline_sha256": sha256(
            "".join(f"{value}\n" for value in basin_ids).encode("utf-8")
        ).hexdigest(),
        "training_sample_count": len(basin_ids) * 2192,
        "validation_sample_count": len(basin_ids) * 366,
        "epochs": 30,
        "batch_size": 256,
        "training_scaler_sha256": scaler_sha256,
        "runner_sha256": "2" * 64,
        "frozen_model_source_sha256": "3" * 64,
        "torch_version": "synthetic",
        "device": "cpu",
        "tensorfloat32": False,
        "evaluation_access_count": 0,
        "admission_evidence": {},
    }
    identity = dict(identity_without_hash)
    identity["identity_sha256"] = sha256(
        _json_bytes(identity_without_hash)[:-1]
    ).hexdigest()
    _write_json(unit / "identity.json", identity)
    epoch_values = np.arange(1, 31, dtype=np.float64)
    validation = np.column_stack(
        [
            0.1 * (index + 1) - np.square(epoch_values - (5 + index)) / 1000.0
            for index in range(len(basin_ids))
        ]
    )
    medians = np.median(validation, axis=1)
    history = {
        "epochs": np.arange(1, 31, dtype=np.int64),
        "basin_ids": np.asarray(basin_ids, dtype="<U8"),
        "training_loss": 1.0 / epoch_values,
        "maximum_gradient_norm": epoch_values / 100.0,
        "learning_rate": np.asarray(
            [0.001 if epoch < 10 else 0.0005 if epoch < 25 else 0.0001 for epoch in range(1, 31)],
            dtype=np.float64,
        ),
        "validation_nse_by_basin": validation,
        "validation_median_nse": medians,
        "evaluation_access_count": np.asarray([0], dtype=np.int64),
    }
    (unit / "validation_history.npz").write_bytes(_npz_bytes(history))
    selected_epoch = int(np.flatnonzero(medians == np.max(medians))[0]) + 1
    selected_path = checkpoints / f"epoch_{selected_epoch:03d}.pt"
    _write_json(
        unit / "model_selection.json",
        {
            "schema_version": "tukf09_neural_model_selection_v1",
            "experiment_id": EXPERIMENT_ID,
            "unit_id": unit_id,
            "lead_days": lead_days,
            "seed": seed,
            "selected_epoch": selected_epoch,
            "selected_checkpoint_relative_path": f"checkpoints/epoch_{selected_epoch:03d}.pt",
            "selected_checkpoint_sha256": sha256(selected_path.read_bytes()).hexdigest(),
            "validation_median_nse": float(medians[selected_epoch - 1]),
            "checkpoint_count": 30,
            "selection_rule": "largest_455_basin_median_nse_earliest_epoch_tie_break",
            "best_seed_selection_forbidden": True,
            "evaluation_access_count": 0,
        },
    )
    _write_json(
        unit / "access_ledger.json",
        {
            "schema_version": "tukf09_neural_access_ledger_v1",
            "experiment_id": EXPERIMENT_ID,
            "unit_id": unit_id,
            "lead_days": lead_days,
            "training": {
                "sample_count": len(basin_ids) * 2192,
                "first_target_index": 365,
                "last_target_index": 2556,
                "maximum_discharge_source_offset_days": lead_days,
                "meteorological_forcing_through_target": True,
            },
            "validation": {
                "sample_count": len(basin_ids) * 366,
                "first_target_index": 365,
                "last_target_index": 730,
                "maximum_discharge_source_offset_days": lead_days,
                "meteorological_forcing_through_target": True,
            },
            "evaluation_access_count": 0,
            "evaluation_prediction_count": 0,
            "evaluation_metric_count": 0,
        },
    )
    _write_manifest(
        unit,
        schema_version="tukf09_neural_unit_manifest_v1",
        unit_type="neural_lead_seed",
        unit_id=unit_id,
    )


@pytest.fixture
def synthetic_training_root(tmp_path: Path) -> tuple[Path, tuple[str, ...], tuple[tuple[int, int], ...]]:
    root = tmp_path / "formal_training"
    root.mkdir()
    for name in ROOT_MEMBERS:
        _write_json(root / name, {"synthetic": name})
    basin_ids = ("00000001", "00000002")
    neural_units = ((1, 0), (2, 1))
    for basin_id in basin_ids:
        _create_filter_unit(root, basin_id)
    scaler_hash = _create_neural_shared(root, basin_ids)
    for lead_days, seed in neural_units:
        _create_neural_unit(root, basin_ids, scaler_hash, lead_days, seed)
    return root, basin_ids, neural_units


def _seal(root: Path, basin_ids: Sequence[str], neural_units: Sequence[tuple[int, int]]) -> dict[str, Any]:
    return seal_training_selection(
        output_root=root,
        expected_basin_ids=basin_ids,
        expected_neural_units=neural_units,
        seal_training_selection=True,
    )


def test_seal_and_independent_verification_are_exact_and_atomic(
    synthetic_training_root: tuple[Path, tuple[str, ...], tuple[tuple[int, int], ...]],
) -> None:
    root, basin_ids, neural_units = synthetic_training_root
    sealed = _seal(root, basin_ids, neural_units)
    assert sealed["status"] == "TRAINING_SELECTION_SEALED_EVALUATION_HOLD"
    assert sealed["filter_basin_units"] == 2
    assert sealed["neural_model_units"] == 2
    assert sealed["formal_evaluation_authorized"] is False
    assert set(path.name for path in (root / "selection").iterdir()) == {
        "filter_registry.json",
        "neural_registry.json",
        "selected_model_summary.json",
        "training_manifest.sha256.json",
        "training_selection.sealed.json",
    }
    manifest = json.loads(
        (root / "selection" / "training_manifest.sha256.json").read_text(
            encoding="utf-8"
        )
    )
    assert "control/.training_phase.lock/owner.json" not in manifest["files"]
    assert not (root / "control" / ".training_phase.lock").exists()

    audit = verify_training_selection_independently(
        output_root=root,
        expected_basin_ids=basin_ids,
        expected_neural_units=neural_units,
        verify_independent_training_selection=True,
    )
    assert audit["status"] == "TRAINING_SELECTION_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
    assert audit["mismatch_count"] == 0
    assert audit["formal_evaluation_authorized"] is False
    assert set(path.name for path in (root / "independent").iterdir()) == {
        "independent_audit.json",
        "manifest.final.sha256.json",
    }
    assert not (root / "control" / ".training_phase.lock").exists()

    reused_seal = _seal(root, basin_ids, neural_units)
    assert reused_seal["reused"] is True
    reused_audit = verify_training_selection_independently(
        output_root=root,
        expected_basin_ids=basin_ids,
        expected_neural_units=neural_units,
        verify_independent_training_selection=True,
    )
    assert reused_audit["reused"] is True


def test_filter_checkpoint_selection_is_recomputed_before_publication(
    synthetic_training_root: tuple[Path, tuple[str, ...], tuple[tuple[int, int], ...]],
) -> None:
    root, basin_ids, neural_units = synthetic_training_root
    unit = root / "filter" / f"basin_{basin_ids[0]}"
    selection = json.loads((unit / "selection.json").read_text(encoding="utf-8"))
    selection["selected_index"] += 1
    _write_json(unit / "selection.json", selection)
    _write_manifest(
        unit,
        schema_version="tukf09_filter_unit_manifest_v1",
        unit_type="filter_basin",
        unit_id=basin_ids[0],
    )
    with pytest.raises(RuntimeError, match="filter checkpoint selection"):
        _seal(root, basin_ids, neural_units)
    assert not (root / "selection").exists()


def test_nonzero_evaluation_ledger_stops_selection_seal(
    synthetic_training_root: tuple[Path, tuple[str, ...], tuple[tuple[int, int], ...]],
) -> None:
    root, basin_ids, neural_units = synthetic_training_root
    lead, seed = neural_units[0]
    unit_id = f"lead_{lead}_seed_{seed}"
    unit = root / "neural" / unit_id
    ledger = json.loads((unit / "access_ledger.json").read_text(encoding="utf-8"))
    ledger["evaluation_metric_count"] = 1
    _write_json(unit / "access_ledger.json", ledger)
    _write_manifest(
        unit,
        schema_version="tukf09_neural_unit_manifest_v1",
        unit_type="neural_lead_seed",
        unit_id=unit_id,
    )
    with pytest.raises(RuntimeError, match="evaluation"):
        _seal(root, basin_ids, neural_units)
    assert not (root / "selection").exists()


def test_neural_checkpoint_selection_is_recomputed_before_publication(
    synthetic_training_root: tuple[Path, tuple[str, ...], tuple[tuple[int, int], ...]],
) -> None:
    root, basin_ids, neural_units = synthetic_training_root
    lead, seed = neural_units[0]
    unit_id = f"lead_{lead}_seed_{seed}"
    unit = root / "neural" / unit_id
    selection = json.loads((unit / "model_selection.json").read_text(encoding="utf-8"))
    selection["selected_epoch"] = 30 if selection["selected_epoch"] != 30 else 29
    _write_json(unit / "model_selection.json", selection)
    _write_manifest(
        unit,
        schema_version="tukf09_neural_unit_manifest_v1",
        unit_type="neural_lead_seed",
        unit_id=unit_id,
    )
    with pytest.raises(RuntimeError, match="neural checkpoint selection"):
        _seal(root, basin_ids, neural_units)
    assert not (root / "selection").exists()


def test_extra_unit_member_stops_selection_seal(
    synthetic_training_root: tuple[Path, tuple[str, ...], tuple[tuple[int, int], ...]],
) -> None:
    root, basin_ids, neural_units = synthetic_training_root
    unit = root / "filter" / f"basin_{basin_ids[0]}"
    (unit / "unexpected.txt").write_text("extra", encoding="utf-8")
    with pytest.raises(RuntimeError, match="exact layout|exact member"):
        _seal(root, basin_ids, neural_units)
    assert not (root / "selection").exists()


@pytest.mark.parametrize(
    "relative_lock",
    (
        ".sequence_controller.lock",
        ".filter_controller.lock",
        "neural_controller/controller.lock",
    ),
)
def test_active_controller_lock_stops_selection_seal(
    synthetic_training_root: tuple[Path, tuple[str, ...], tuple[tuple[int, int], ...]],
    relative_lock: str,
) -> None:
    root, basin_ids, neural_units = synthetic_training_root
    lock = root / "control" / Path(relative_lock)
    lock.mkdir(parents=True)
    _write_json(lock / "owner.json", {"process_id": 123})
    with pytest.raises(RuntimeError, match="active controller lock"):
        _seal(root, basin_ids, neural_units)
    assert not (root / "selection").exists()


def test_preexisting_training_phase_lock_is_hold_and_is_not_removed(
    synthetic_training_root: tuple[Path, tuple[str, ...], tuple[tuple[int, int], ...]],
) -> None:
    root, basin_ids, neural_units = synthetic_training_root
    lock = root / "control" / ".training_phase.lock"
    owner = {
        "schema_version": "tukf09_training_phase_owner_v1",
        "experiment_id": EXPERIMENT_ID,
        "role": "filter",
        "execution_id": "a" * 32,
        "process_id": os.getpid(),
        "started_at_utc": "2026-08-11T00:00:00+00:00",
        "recovered_stale_lock": False,
    }
    _write_json(lock / "owner.json", owner)
    original = (lock / "owner.json").read_bytes()
    with pytest.raises(RuntimeError, match="training phase"):
        _seal(root, basin_ids, neural_units)
    assert lock.is_dir()
    assert (lock / "owner.json").read_bytes() == original
    assert not (root / "selection").exists()


def test_selection_postpublication_recompute_detects_late_control_write(
    synthetic_training_root: tuple[Path, tuple[str, ...], tuple[tuple[int, int], ...]],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    root, basin_ids, neural_units = synthetic_training_root
    original_publish = sealer._atomic_publish_directory

    def publish_then_mutate(destination: Path, payloads: Mapping[str, bytes]) -> None:
        original_publish(destination, payloads)
        _write_json(root / "control" / "late_controller_event.json", {"late": True})

    monkeypatch.setattr(sealer, "_atomic_publish_directory", publish_then_mutate)
    with pytest.raises(RuntimeError, match="changed across phase-lock release"):
        _seal(root, basin_ids, neural_units)
    assert (root / "selection").is_dir()
    assert not (root / "control" / ".training_phase.lock").exists()


def test_independent_verifier_detects_postseal_unit_tampering(
    synthetic_training_root: tuple[Path, tuple[str, ...], tuple[tuple[int, int], ...]],
) -> None:
    root, basin_ids, neural_units = synthetic_training_root
    _seal(root, basin_ids, neural_units)
    checkpoint = root / "neural" / "lead_1_seed_0" / "checkpoints" / "epoch_001.pt"
    checkpoint.write_bytes(checkpoint.read_bytes() + b"tampered")
    with pytest.raises(RuntimeError, match="manifest|hash|size"):
        verify_training_selection_independently(
            output_root=root,
            expected_basin_ids=basin_ids,
            expected_neural_units=neural_units,
            verify_independent_training_selection=True,
        )
    assert not (root / "independent").exists()


def test_independent_verifier_rejects_neural_controller_activity_lock(
    synthetic_training_root: tuple[Path, tuple[str, ...], tuple[tuple[int, int], ...]],
) -> None:
    root, basin_ids, neural_units = synthetic_training_root
    _seal(root, basin_ids, neural_units)
    lock = root / "control" / "neural_controller" / "controller.lock"
    lock.mkdir(parents=True)
    _write_json(lock / "owner.json", {"process_id": 456})
    with pytest.raises(RuntimeError, match="active controller lock"):
        verify_training_selection_independently(
            output_root=root,
            expected_basin_ids=basin_ids,
            expected_neural_units=neural_units,
            verify_independent_training_selection=True,
        )
    assert not (root / "independent").exists()


def test_seal_and_independent_phase_locks_are_mutually_exclusive(
    synthetic_training_root: tuple[Path, tuple[str, ...], tuple[tuple[int, int], ...]],
) -> None:
    root, basin_ids, neural_units = synthetic_training_root
    _seal(root, basin_ids, neural_units)
    control = root / "control"

    with sealer.phase_common.training_phase_lock(control, "seal"):
        owner_path = control / ".training_phase.lock" / "owner.json"
        owner_before = owner_path.read_bytes()
        with pytest.raises(RuntimeError, match="training phase lock"):
            verify_training_selection_independently(
                output_root=root,
                expected_basin_ids=basin_ids,
                expected_neural_units=neural_units,
                verify_independent_training_selection=True,
            )
        assert owner_path.read_bytes() == owner_before
        assert not (root / "independent").exists()

    with independent_verifier._training_phase_lock(root, "independent"):
        owner_path = control / ".training_phase.lock" / "owner.json"
        owner_before = owner_path.read_bytes()
        with pytest.raises(RuntimeError, match="training phase"):
            _seal(root, basin_ids, neural_units)
        assert owner_path.read_bytes() == owner_before
    assert not (control / ".training_phase.lock").exists()


def test_independent_phase_owner_tampering_leaves_lock_for_manual_audit(
    synthetic_training_root: tuple[Path, tuple[str, ...], tuple[tuple[int, int], ...]],
) -> None:
    root, _, _ = synthetic_training_root
    lock = root / "control" / ".training_phase.lock"
    with pytest.raises(RuntimeError, match="phase-lock identity"):
        with independent_verifier._training_phase_lock(root, "independent"):
            owner_path = lock / "owner.json"
            owner = json.loads(owner_path.read_text(encoding="utf-8"))
            owner["execution_id"] = "f" * 32
            _write_json(owner_path, owner)
    assert lock.is_dir()
    assert (lock / "owner.json").is_file()


def _imported_modules(source_path: Path) -> list[str]:
    tree = ast.parse(source_path.read_text(encoding="utf-8"))
    imported: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imported.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            imported.append(node.module or "")
    return imported


def test_verifier_is_independent_and_sealer_does_not_import_runners() -> None:
    verifier_imports = _imported_modules(Path("scripts/verify_tukf09_455_training_selection.py"))
    assert not [name for name in verifier_imports if "seal_tukf09" in name.lower()]
    assert not [name for name in verifier_imports if "run_tukf09" in name.lower()]
    sealer_imports = _imported_modules(Path("scripts/seal_tukf09_455_training_selection.py"))
    assert not [name for name in sealer_imports if "run_tukf09" in name.lower()]


def test_production_completion_constants_are_exact() -> None:
    assert sealer.EXPECTED_COMPLETION_COUNTS == {
        "rebound_filter_units": 455,
        "new_filter_training_units": 0,
        "inherited_filter_checkpoint_records": 116480,
        "new_filter_training_objective_calls": 0,
        "new_filter_validation_objective_calls": 0,
        "new_filter_gradient_updates": 0,
        "neural_model_units": 9,
        "neural_checkpoints": 270,
        "evaluation_array_reads": 0,
        "evaluation_predictions": 0,
        "evaluation_metrics": 0,
        "evaluation_outputs": 0,
    }
    assert sealer.EXPECTED_NEURAL_UNITS == tuple(
        (lead, seed) for lead in (1, 2, 3) for seed in (0, 1, 2)
    )
    assert sealer.FILTER_CHECKPOINT_COUNT == 256
    assert sealer.NEURAL_CHECKPOINT_COUNT == 30


def test_frozen_production_population_and_model_order_are_loaded_read_only() -> None:
    expected = sealer._load_expectations(
        output_root=sealer.DEFAULT_OUTPUT_ROOT,
        population_registry=sealer.DEFAULT_POPULATION_REGISTRY,
        execution_config=sealer.DEFAULT_EXECUTION_CONFIG,
        expected_basin_ids=None,
        expected_neural_units=None,
    )
    assert expected.production is True
    assert len(expected.basin_ids) == 455
    assert expected.neural_units == sealer.EXPECTED_NEURAL_UNITS
    recomputed = independent_verifier._expectations(
        output_root=independent_verifier.DEFAULT_OUTPUT_ROOT,
        population_registry=independent_verifier.DEFAULT_POPULATION_REGISTRY,
        execution_config=independent_verifier.DEFAULT_EXECUTION_CONFIG,
        expected_basin_ids=None,
        expected_neural_units=None,
    )
    assert recomputed.basin_ids == expected.basin_ids
    assert recomputed.neural_units == expected.neural_units
    assert recomputed.execution_config_sha256 == expected.execution_config_sha256


def test_sealer_and_independent_verifier_freeze_the_exact_revision_source_paths() -> None:
    assert len(REQUIRED_SOURCE_PATHS) == 30
    assert training_common.REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS == REQUIRED_SOURCE_PATHS
    assert sealer.REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS == REQUIRED_SOURCE_PATHS
    assert (
        independent_verifier.REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS
        == REQUIRED_SOURCE_PATHS
    )
    for required in (
        "scripts/verify_tukf09_455_filter_rebinding_controller.py",
        "scripts/run_tukf09_455_neural_training.py",
        "scripts/run_tukf09_filter_training.py",
        "scripts/run_aligned_gr4j_da.py",
        "scripts/run_aligned_gr4j_differentiable_ukf.py",
        "scripts/tukf07_information_matched_model.py",
        "scripts/seal_tukf09_455_training_selection.py",
        "scripts/verify_tukf09_455_training_selection.py",
        "scripts/tukf09_455_evaluation_common.py",
        "scripts/tukf09_confirmatory_common.py",
        "scripts/tukf09_training_controller_common.py",
        "src/global_hydrology/assimilation/conventional_ukf.py",
        "scripts/evaluate_tukf09_455_basin_revision.py",
        "scripts/verify_tukf09_455_basin_evaluation.py",
    ):
        assert required in REQUIRED_SOURCE_PATHS


def test_exact_admitted_source_set_is_accepted_by_both_implementations(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    project, admission = _source_project_and_admission(tmp_path)
    monkeypatch.setattr(sealer, "ROOT", project)
    monkeypatch.setattr(independent_verifier, "ROOT", project)

    for module in (sealer, independent_verifier):
        bindings = module._validate_admitted_executables(
            admission, TRAINING_ADMISSION_RECORD_SHA256
        )
        assert (
            bindings.training_admission_record_sha256
            == TRAINING_ADMISSION_RECORD_SHA256
        )
        assert bindings.neural_runner_sha256 == admission["executables"][
            "scripts/run_tukf09_455_neural_training.py"
        ]["sha256"]
        assert bindings.frozen_model_source_sha256 == admission["executables"][
            "scripts/tukf07_information_matched_model.py"
        ]["sha256"]


@pytest.mark.parametrize("relative", REQUIRED_SOURCE_PATHS)
def test_each_revision_admitted_source_is_rehashed_and_tampering_is_rejected(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    relative: str,
) -> None:
    project, admission = _source_project_and_admission(tmp_path)
    monkeypatch.setattr(sealer, "ROOT", project)
    monkeypatch.setattr(independent_verifier, "ROOT", project)
    source = project / relative
    source.write_bytes(source.read_bytes() + b"tampered")

    for module in (sealer, independent_verifier):
        with pytest.raises(RuntimeError, match="source|executable|admission"):
            module._validate_admitted_executables(
                admission, TRAINING_ADMISSION_RECORD_SHA256
            )


@pytest.mark.parametrize("mutation", ("missing", "extra"))
def test_admitted_source_set_must_be_exactly_the_frozen_revision_paths(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    mutation: str,
) -> None:
    project, admission = _source_project_and_admission(tmp_path)
    executables = admission["executables"]
    if mutation == "missing":
        executables.pop(REQUIRED_SOURCE_PATHS[0])
    else:
        extra = project / "scripts" / "unexpected.py"
        extra.write_text("unexpected\n", encoding="utf-8")
        executables["scripts/unexpected.py"] = _record(extra)
    monkeypatch.setattr(sealer, "ROOT", project)
    monkeypatch.setattr(independent_verifier, "ROOT", project)

    for module in (sealer, independent_verifier):
        with pytest.raises(RuntimeError, match="source|executable|admission"):
            module._validate_admitted_executables(
                admission, TRAINING_ADMISSION_RECORD_SHA256
            )


def test_production_rebound_filter_six_file_schema_and_inherited_counts_are_accepted(
    synthetic_training_root: tuple[Path, tuple[str, ...], tuple[tuple[int, int], ...]],
) -> None:
    root, basin_ids, _ = synthetic_training_root
    basin_id = basin_ids[0]
    _convert_filter_unit_to_rebound(root, basin_id)

    for module, validator in (
        (sealer, sealer._validate_filter_unit),
        (independent_verifier, independent_verifier._filter_unit),
    ):
        entry, tree = validator(
            root,
            basin_id,
            source_bindings=_production_source_bindings(module, root, basin_id),
        )
        assert set(tree) == {
            "identity.json",
            "history.npz",
            "selection.json",
            "access_ledger.json",
            "migration_provenance.json",
            "manifest.sha256.json",
        }
        assert entry["filter_result_origin"] == "FILTER_BASIN_REBOUND_FROM_VERIFIED_PARENT"
        assert entry["inherited_checkpoint_records"] == 256
        assert entry["inherited_training_objective_records"] == 256
        assert entry["inherited_validation_objective_records"] == 256
        assert entry["inherited_gradient_update_records"] == 248
        assert entry["new_filter_training_objective_calls"] == 0
        assert entry["new_filter_validation_objective_calls"] == 0
        assert entry["new_filter_gradient_updates"] == 0
        assert entry["training_admission_record_sha256"] == TRAINING_ADMISSION_RECORD_SHA256
        assert entry["filter_migration_final_manifest_sha256"] == FILTER_MIGRATION_FINAL_SHA256
        assert (
            entry["filter_installation_final_manifest_sha256"]
            == FILTER_INSTALLATION_FINAL_SHA256
        )


@pytest.mark.parametrize(
    "mutation",
    (
        "identity_schema",
        "identity_authorization_hash",
        "identity_migration_config_hash",
        "selection_schema",
        "selection_status",
        "ledger_schema",
        "ledger_new_optimization",
        "provenance_schema",
        "provenance_source_experiment",
        "provenance_migration_mode",
        "provenance_history_binding",
        "manifest_schema",
    ),
)
def test_production_rebound_filter_schema_or_provenance_tampering_is_rejected(
    synthetic_training_root: tuple[Path, tuple[str, ...], tuple[tuple[int, int], ...]],
    mutation: str,
) -> None:
    root, basin_ids, _ = synthetic_training_root
    basin_id = basin_ids[0]
    _convert_filter_unit_to_rebound(root, basin_id)
    unit = root / "filter" / f"basin_{basin_id}"
    member_name, field, value = {
        "identity_schema": ("identity.json", "schema_version", "wrong"),
        "identity_authorization_hash": (
            "identity.json",
            "all_scope_authorization_sha256",
            "0" * 64,
        ),
        "identity_migration_config_hash": (
            "identity.json",
            "migration_config_sha256",
            "0" * 64,
        ),
        "selection_schema": ("selection.json", "schema_version", "wrong"),
        "selection_status": ("selection.json", "status", "FILTER_BASIN_SELECTED"),
        "ledger_schema": ("access_ledger.json", "schema_version", "wrong"),
        "ledger_new_optimization": (
            "access_ledger.json",
            "new_filter_optimization_count",
            1,
        ),
        "provenance_schema": (
            "migration_provenance.json",
            "schema_version",
            "wrong",
        ),
        "provenance_source_experiment": (
            "migration_provenance.json",
            "source_experiment_id",
            "wrong",
        ),
        "provenance_migration_mode": (
            "migration_provenance.json",
            "migration_mode",
            "reference_only",
        ),
        "manifest_schema": ("manifest.sha256.json", "schema_version", "wrong"),
    }.get(mutation, ("migration_provenance.json", "source_members", None))
    path = unit / member_name
    value_document = json.loads(path.read_text(encoding="utf-8"))
    if mutation == "provenance_history_binding":
        value_document["source_members"]["history.npz"]["sha256"] = "0" * 64
    else:
        value_document[field] = value
    _write_json(path, value_document)
    if member_name != "manifest.sha256.json":
        _write_manifest(
            unit,
            schema_version="tukf09_455_rebound_filter_unit_manifest_v1",
            unit_type="filter_basin",
            unit_id=basin_id,
        )

    for module, validator in (
        (sealer, sealer._validate_filter_unit),
        (independent_verifier, independent_verifier._filter_unit),
    ):
        with pytest.raises(RuntimeError, match="filter|manifest|provenance"):
            validator(
                root,
                basin_id,
                source_bindings=_production_source_bindings(module, root, basin_id),
            )


@pytest.mark.parametrize(
    "field,changed_value",
    (
        ("runner_sha256", "a" * 64),
        ("frozen_model_source_sha256", "b" * 64),
        (
            "admission_evidence",
            {"training_admission_record_sha256": "c" * 64},
        ),
    ),
)
def test_neural_identity_must_match_admitted_runner_model_and_admission_record(
    synthetic_training_root: tuple[Path, tuple[str, ...], tuple[tuple[int, int], ...]],
    field: str,
    changed_value: Any,
) -> None:
    root, basin_ids, neural_units = synthetic_training_root
    lead_days, seed = neural_units[0]
    _rewrite_neural_identity(root, lead_days, seed, **{field: changed_value})
    scaler_sha256 = sha256(
        (root / "neural" / "shared" / "training_scaler.json").read_bytes()
    ).hexdigest()

    for module, validator in (
        (sealer, sealer._validate_neural_unit),
        (independent_verifier, independent_verifier._neural_unit),
    ):
        with pytest.raises(RuntimeError, match="neural.*identity"):
            validator(
                root,
                basin_ids,
                scaler_sha256,
                lead_days,
                seed,
                source_bindings=_source_bindings(module),
            )
