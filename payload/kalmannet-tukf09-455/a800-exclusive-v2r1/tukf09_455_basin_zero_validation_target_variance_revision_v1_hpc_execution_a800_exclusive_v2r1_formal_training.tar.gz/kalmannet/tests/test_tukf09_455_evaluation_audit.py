from __future__ import annotations

import ast
import json
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import numpy as np
import pytest

from scripts import evaluate_tukf09_455_basin_revision as evaluator
from scripts import admit_tukf09_455_formal_evaluation as admission_module
from scripts import tukf09_455_evaluation_common as common
from scripts import tukf09_455_training_common as training_common
from scripts import verify_tukf09_455_basin_evaluation as independent


DAY_NS = 86_400_000_000_000
ROOT = Path(__file__).resolve().parents[1]


def _period(basin_id: str) -> common.EvaluationPeriod:
    days = 12
    return common.EvaluationPeriod(
        basin_id=basin_id,
        dates_ns=np.arange(days, dtype=np.int64) * DAY_NS,
        forcing=np.column_stack([np.arange(days), np.ones(days), np.full(days, 2.0)]),
        observations=np.arange(days, dtype=np.float64) + 1.0,
        production=False,
    )


def _predictions(period: common.EvaluationPeriod) -> tuple[dict[int, np.ndarray], dict[int, dict[int, np.ndarray]]]:
    filter_predictions = {
        lead: period.observations + lead * 0.1 for lead in (1, 2, 3)
    }
    seed_predictions = {
        lead: {
            seed: period.observations + lead * 0.2 + seed * 0.01
            for seed in (0, 1, 2)
        }
        for lead in (1, 2, 3)
    }
    return filter_predictions, seed_predictions


def _evaluation(tmp_path: Path) -> tuple[Path, dict[str, common.EvaluationPeriod]]:
    periods = {f"0000000{i}": _period(f"0000000{i}") for i in (1, 2)}
    output = tmp_path / "formal-evaluation"
    evaluator.run_formal_evaluation(
        authorize=True,
        output_root=output,
        ordered_basin_ids=tuple(periods),
        admitted_identity={"admission_sha256": "a" * 64, "attempt_id": "attempt-one"},
        acquire_verified_capability=lambda: object(),
        period_loader=lambda _capability: periods,
        filter_predictor=lambda _basin, period: _predictions(period)[0],
        neural_seed_predictor=lambda _basin, period: _predictions(period)[1],
        first_scoring_index=3,
        expected_supports={1: 9, 2: 9, 3: 9},
        bootstrap_resamples=50,
        production=False,
    )
    return output, periods


def test_independent_verifier_does_not_import_evaluator_or_shared_score_functions() -> None:
    source_path = ROOT / "scripts" / "verify_tukf09_455_basin_evaluation.py"
    tree = ast.parse(source_path.read_text(encoding="utf-8"))
    imported: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imported.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            imported.append(node.module or "")
    assert all("evaluate_tukf09_455_basin_revision" not in name for name in imported)
    source = source_path.read_text(encoding="utf-8")
    assert "common_mask_and_nse" not in source
    assert "tukf09_455_evaluation_common" not in imported


def test_independent_full_prediction_replay_and_metric_only_boundary(tmp_path: Path) -> None:
    output, periods = _evaluation(tmp_path)

    full = independent.verify_formal_evaluation_independently(
        authorize=True,
        evaluation_root=output,
        independent_root=tmp_path / "independent-full",
        expected_basin_ids=tuple(periods),
        replay_basin=lambda basin_id: _predictions(periods[basin_id]),
        bootstrap_resamples=50,
        production=False,
    )
    assert full["status"] == "FULL_EVALUATION_INDEPENDENTLY_REPRODUCED"
    assert (tmp_path / "independent-full" / "independent_audit.json").is_file()
    assert (tmp_path / "independent-full" / "manifest.final.sha256.json").is_file()

    metric_only = independent.verify_formal_evaluation_independently(
        authorize=True,
        evaluation_root=output,
        independent_root=tmp_path / "independent-metric-only",
        expected_basin_ids=tuple(periods),
        replay_basin=None,
        bootstrap_resamples=50,
        production=False,
    )
    assert metric_only["status"] == "METRICS_ONLY_NOT_FULL_PREDICTION_REPLAY"


def test_independent_verifier_detects_bit_tamper(tmp_path: Path) -> None:
    output, periods = _evaluation(tmp_path)
    archive = output / "basins" / "00000001.predictions.npz"
    content = bytearray(archive.read_bytes())
    content[len(content) // 2] ^= 1
    archive.write_bytes(bytes(content))
    with pytest.raises(RuntimeError, match="manifest|hash"):
        independent.verify_formal_evaluation_independently(
            authorize=True,
            evaluation_root=output,
            independent_root=tmp_path / "independent",
            expected_basin_ids=tuple(periods),
            replay_basin=lambda basin_id: _predictions(periods[basin_id]),
            bootstrap_resamples=50,
            production=False,
        )


def test_independent_authorization_gate_precedes_every_read(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def forbidden(*_args: Any, **_kwargs: Any) -> Any:
        raise AssertionError("independent authorization gate must precede every read")

    monkeypatch.setattr(Path, "read_bytes", forbidden)
    with pytest.raises(PermissionError):
        independent.verify_formal_evaluation_independently(
            authorize=False,
            evaluation_root=Path("unused"),
            independent_root=Path("unused"),
            expected_basin_ids=(),
            replay_basin=None,
            production=False,
        )


def test_existing_independent_seal_is_read_only_and_exact(tmp_path: Path) -> None:
    output, periods = _evaluation(tmp_path)
    root = tmp_path / "independent"
    kwargs = dict(
        authorize=True,
        evaluation_root=output,
        independent_root=root,
        expected_basin_ids=tuple(periods),
        replay_basin=lambda basin_id: _predictions(periods[basin_id]),
        bootstrap_resamples=50,
        production=False,
    )
    first = independent.verify_formal_evaluation_independently(**kwargs)
    before = {path.name: path.read_bytes() for path in root.iterdir()}
    second = independent.verify_formal_evaluation_independently(**kwargs)
    after = {path.name: path.read_bytes() for path in root.iterdir()}
    assert first["status"] == second["status"]
    assert second["reused"] is True
    assert before == after

    audit_path = root / "independent_audit.json"
    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    audit["mismatch_count"] = 1
    audit_path.write_text(json.dumps(audit), encoding="utf-8")
    with pytest.raises(RuntimeError, match="existing|seal|differs"):
        independent.verify_formal_evaluation_independently(**kwargs)


def _formal_lifecycle_fixture(
    tmp_path: Path, *, results: Path | None = None
) -> tuple[Path, Path, str, str]:
    results = results or (tmp_path / "results")
    control = results / "control"
    evaluation = results / "evaluation"
    evaluation.mkdir(parents=True)
    summary = evaluation / "evaluation_summary.json"
    manifest = evaluation / "manifest.sha256.json"
    ledger = evaluation / "access_ledger.json"
    summary.write_text("{}\n", encoding="utf-8")
    manifest.write_text("{}\n", encoding="utf-8")
    ledger.write_text("{}\n", encoding="utf-8")
    admission_sha256 = "a" * 64
    runtime_sha256 = "b" * 64
    attempt = independent._atomic_control_record(
        control / "formal_evaluation_attempt.json",
        {
            "schema_version": "tukf09_455_formal_evaluation_attempt_v1",
            "experiment_id": independent.EXPERIMENT_ID,
            "status": "FORMAL_EVALUATION_ATTEMPT_REGISTERED_ZERO_ACCESS",
            "created_utc": "2026-08-31T00:00:00Z",
            "attempt_id": "attempt-one",
            "admission_sha256": admission_sha256,
            "lock_sha256": "c" * 64,
            "runtime_environment_identity_sha256": runtime_sha256,
            "evaluation_output_root": str(evaluation.resolve()),
            "evaluation_arrays_loaded": False,
            "evaluation_access_ledger": {
                "evaluation_array_reads": 0,
                "evaluation_predictions": 0,
                "evaluation_metrics": 0,
                "evaluation_outputs": 0,
            },
            "retry_allowed": False,
        },
    )
    independent._atomic_control_record(
        control / "formal_evaluation_consumption.json",
        {
            "schema_version": "tukf09_455_formal_evaluation_consumption_v1",
            "experiment_id": independent.EXPERIMENT_ID,
            "status": "FORMAL_EVALUATION_ACCESS_CONSUMED_BEFORE_FIRST_ARRAY_READ",
            "created_utc": "2026-08-31T00:00:01Z",
            "attempt_id": "attempt-one",
            "attempt_record_sha256": attempt["record_sha256"],
            "admission_sha256": admission_sha256,
            "evaluation_access_consumed": True,
            "evaluation_array_read_attempts": 1,
            "evaluation_arrays_loaded_at_publication": False,
            "retry_allowed": False,
        },
    )
    independent._atomic_control_record(
        control / "formal_evaluation_success.json",
        {
            "schema_version": "tukf09_455_formal_evaluation_success_v1",
            "experiment_id": independent.EXPERIMENT_ID,
            "status": "FORMAL_EVALUATION_OUTPUT_PUBLISHED_RETRY_FORBIDDEN",
            "created_utc": "2026-08-31T00:00:02Z",
            "attempt_id": "attempt-one",
            "attempt_record_sha256": attempt["record_sha256"],
            "consumption_record_sha256": independent._sha256_file(
                control / "formal_evaluation_consumption.json"
            ),
            "evaluation_summary_path": str(summary.resolve()),
            "evaluation_summary_sha256": independent._sha256_file(summary),
            "evaluation_manifest_sha256": independent._sha256_file(manifest),
            "evaluation_access_ledger_sha256": independent._sha256_file(ledger),
            "retry_allowed": False,
        },
    )
    return control, evaluation, admission_sha256, runtime_sha256


def test_independent_entry_rejects_lifecycle_cross_hash_tamper(tmp_path: Path) -> None:
    control, evaluation, admission_sha256, runtime_sha256 = _formal_lifecycle_fixture(
        tmp_path
    )
    independent._validate_formal_lifecycle_for_independent_replay(
        control=control,
        evaluation_root=evaluation,
        summary_path=evaluation / "evaluation_summary.json",
        admission_sha256=admission_sha256,
        runtime_sha256=runtime_sha256,
    )
    success_path = control / "formal_evaluation_success.json"
    success = json.loads(success_path.read_text(encoding="utf-8"))
    success["attempt_record_sha256"] = "f" * 64
    unsigned = dict(success)
    unsigned.pop("record_sha256")
    success["record_sha256"] = independent._json_sha256(unsigned)
    success_path.write_bytes(independent._json_bytes(success))
    with pytest.raises(RuntimeError, match="success lifecycle binding"):
        independent._validate_formal_lifecycle_for_independent_replay(
            control=control,
            evaluation_root=evaluation,
            summary_path=evaluation / "evaluation_summary.json",
            admission_sha256=admission_sha256,
            runtime_sha256=runtime_sha256,
        )


def test_formal_and_independent_entries_reject_nested_neural_controller_lock(
    tmp_path: Path,
) -> None:
    control = tmp_path / "control"
    nested = control / "neural" / "controller.lock"
    nested.parent.mkdir(parents=True)
    nested.write_text("stale\n", encoding="utf-8")
    with pytest.raises(RuntimeError, match="controller lock"):
        evaluator._reject_training_locks(control)
    with pytest.raises(RuntimeError, match="controller lock"):
        independent._reject_training_locks(control)


def test_fixed_independent_wrapper_publishes_attempt_before_inside_recheck_and_consumes_once(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    config_source = ROOT / (
        "configs/tukf09_455_basin_zero_validation_target_variance_formal_evaluation_v1.json"
    )
    config_path = tmp_path / "configs" / config_source.name
    config_path.parent.mkdir(parents=True)
    config_path.write_bytes(config_source.read_bytes())
    results = tmp_path / (
        "results/tukf09_455_basin_zero_validation_target_variance_revision_v1"
    )
    control, evaluation, admission_sha256, runtime_sha256 = _formal_lifecycle_fixture(
        tmp_path, results=results
    )
    admitted = admission_module.EvaluationAdmission(
        path=tmp_path / "synthetic-admission.json",
        file_sha256=admission_sha256,
        record={"runtime_environment_identity_sha256": runtime_sha256},
    )
    load_calls = 0
    saw_attempt_before_inside = False

    def fake_load(*_args: Any, **_kwargs: Any) -> admission_module.EvaluationAdmission:
        nonlocal load_calls, saw_attempt_before_inside
        load_calls += 1
        if load_calls == 2:
            saw_attempt_before_inside = (
                control / "formal_evaluation_independent_attempt.json"
            ).is_file()
        return admitted

    monkeypatch.setattr(admission_module, "load_and_verify_evaluation_admission", fake_load)
    replay = SimpleNamespace(
        ordered_basin_ids=("00000001",),
        admission_sha256=admission_sha256,
        replay=lambda *_args: ({}, {}),
    )
    monkeypatch.setattr(
        independent,
        "build_independent_production_replay",
        lambda **_kwargs: replay,
    )

    def fake_verify(**kwargs: Any) -> dict[str, Any]:
        assert (control / "formal_evaluation_independent_consumption.json").is_file()
        destination = Path(kwargs["independent_root"])
        destination.mkdir(parents=True)
        (destination / "independent_audit.json").write_text("{}\n", encoding="utf-8")
        (destination / "manifest.final.sha256.json").write_text("{}\n", encoding="utf-8")
        return {
            "status": "FULL_EVALUATION_INDEPENDENTLY_REPRODUCED",
            "prediction_vectors_replayed": 15,
        }

    monkeypatch.setattr(independent, "verify_formal_evaluation_independently", fake_verify)
    result = independent.verify_formal_evaluation_independently_from_fixed_artifacts(
        authorize=True, project_root=tmp_path
    )
    assert result["status"] == "FULL_EVALUATION_INDEPENDENTLY_REPRODUCED"
    assert saw_attempt_before_inside is True
    assert load_calls == 2
    assert (control / "formal_evaluation_independent_success.json").is_file()
    with pytest.raises(FileExistsError, match="already consumed|retry"):
        independent.verify_formal_evaluation_independently_from_fixed_artifacts(
            authorize=True, project_root=tmp_path
        )


def test_formal_and_independent_lock_and_attempt_prechecks_have_zero_external_writes(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(
        training_common,
        "ensure_no_symlink_components",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(ValueError("junction rejected")),
    )
    formal_results = tmp_path / "formal-results"
    with pytest.raises(ValueError, match="junction rejected"):
        with evaluator._formal_evaluation_lock(
            results_root=formal_results,
            admission_sha256="a" * 64,
            runtime_environment_identity_sha256="b" * 64,
        ):
            pass
    assert not (formal_results / "control").exists()

    independent_results = tmp_path / "independent-results"
    with pytest.raises(ValueError, match="junction rejected"):
        with independent._independent_evaluation_lock(
            results_root=independent_results,
            admission_sha256="a" * 64,
            runtime_sha256="b" * 64,
        ):
            pass
    assert not (independent_results / "control").exists()

    formal_attempt = tmp_path / "formal-attempt" / "attempt.json"
    with pytest.raises(ValueError, match="junction rejected"):
        evaluator._atomic_control_record(formal_attempt, {"status": "synthetic"})
    assert not formal_attempt.parent.exists()

    independent_attempt = tmp_path / "independent-attempt" / "attempt.json"
    with pytest.raises(ValueError, match="junction rejected"):
        independent._atomic_control_record(independent_attempt, {"status": "synthetic"})
    assert not independent_attempt.parent.exists()
