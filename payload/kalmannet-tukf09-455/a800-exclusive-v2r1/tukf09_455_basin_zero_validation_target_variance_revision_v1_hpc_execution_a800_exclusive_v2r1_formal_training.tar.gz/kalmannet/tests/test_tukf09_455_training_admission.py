from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
TRAINING_CONFIG = (
    ROOT
    / "configs/tukf09_455_basin_zero_validation_target_variance_formal_training_execution_v1.json"
)


def _evidence() -> dict[str, object]:
    return {
        "scientific_contract": {
            "path": "configs/tukf09_455_basin_zero_validation_target_variance_revision_v1.json",
            "sha256": "1" * 64,
        },
        "independent_preflight_final_manifest": {
            "path": "artifacts/preflight/independent/manifest.final.sha256.json",
            "sha256": "2" * 64,
        },
        "filter_migration_final_manifest": {
            "path": "artifacts/filter_migration_v1/independent/manifest.final.sha256.json",
            "sha256": "3" * 64,
        },
        "authorization": {
            "path": "artifacts/authorizations/all_scope_authorization.json",
            "file_sha256": "4" * 64,
            "record_sha256": "5" * 64,
        },
        "population": {
            "ordered_basin_count": 455,
            "ordered_newline_sha256": (
                "38987bce45fa38ff68f5b067db17e8cb3212d98fecdd106f57d268a130ee8fbd"
            ),
            "compact_json_sha256": (
                "75ef2cee206fb15ee3f31ae0bbfcf594661c5ccdda0b28de9ff65634332c8902"
            ),
        },
        "parameter_snapshot": {"shape": [455, 13], "sha256": "6" * 64},
        "training_validation_semantic_identity": {
            "member_count": 2730,
            "identity_only_sha256": (
                "8e9d4701478e3bb69e6b343c16a1a9ff336512f0b983a29415f7bc320bb2f2f8"
            ),
        },
        "evaluation_identity": {
            "member_count": 1365,
            "identity_only_sha256": (
                "fac922d51908376d078a2d3abc023e065a8f785317e059d309dfbbabad37e4a5"
            ),
            "arrays_loaded": False,
        },
        "access_ledger": {
            "evaluation_array_reads": 0,
            "evaluation_predictions": 0,
            "evaluation_metrics": 0,
            "evaluation_outputs": 0,
        },
    }


def test_training_admission_gate_precedes_every_file_read(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from scripts import admit_tukf09_455_formal_training as admission

    def forbidden(*_args: object, **_kwargs: object) -> bytes:
        raise AssertionError("admission gate must run before file reads")

    monkeypatch.setattr(Path, "read_bytes", forbidden)
    with pytest.raises(PermissionError, match="admission"):
        admission.admit_formal_training(
            authorize_admission=False,
            run_required_test_suite=False,
            project_root=ROOT,
        )


def test_training_admission_payload_is_evaluation_gated() -> None:
    from scripts import admit_tukf09_455_formal_training as admission

    execution = json.loads(TRAINING_CONFIG.read_text(encoding="utf-8"))
    payload = admission.build_training_admission_payload(
        evidence=_evidence(),
        execution_config_record={
            "path": TRAINING_CONFIG.relative_to(ROOT).as_posix(),
            "sha256": hashlib.sha256(TRAINING_CONFIG.read_bytes()).hexdigest(),
        },
        executable_records={
            "scripts/run_tukf09_455_neural_training.py": {
                "sha256": "7" * 64,
                "size_bytes": 123,
            }
        },
        test_evidence={
            "result": "PASS",
            "passed_count": 1,
            "failed_count": 0,
            "error_count": 0,
            "skipped_count": 0,
        },
        runtime_environment_identity={"schema_version": "synthetic_runtime_v1"},
        tensorfloat32_state={"cuda_matmul": False, "cudnn": False},
        execution=execution,
        admitted_at_utc="2026-08-31T12:30:00+00:00",
    )
    assert payload["status"] == (
        "NEURAL_TRAINING_ADMITTED_FILTER_REBINDING_INSTALLATION_PENDING_"
        "EVALUATION_HOLD"
    )
    assert payload["phase_scope"] == {
        "filter_rebinding_installation_authorized": True,
        "new_filter_training_authorized": False,
        "neural_training_authorized": True,
        "validation_checkpoint_selection_authorized": True,
        "training_selection_sealing_authorized": True,
        "formal_evaluation_access_admitted": False,
    }
    assert payload["evaluation_identity"]["arrays_loaded"] is False
    assert set(payload["access_ledger"].values()) == {0}
    assert payload["expected_completion"]["rebound_filter_units"] == 455
    assert payload["expected_completion"]["new_filter_training_units"] == 0
    assert payload["expected_completion"]["neural_model_units"] == 9
    unsigned = dict(payload)
    stored = unsigned.pop("training_admission_record_sha256")
    assert stored == hashlib.sha256(admission.canonical_json_bytes(unsigned)).hexdigest()


def test_payload_rejects_any_evaluation_access_or_unsealed_migration() -> None:
    from scripts import admit_tukf09_455_formal_training as admission

    execution = json.loads(TRAINING_CONFIG.read_text(encoding="utf-8"))
    bad = _evidence()
    bad["access_ledger"] = dict(bad["access_ledger"])  # type: ignore[arg-type]
    bad["access_ledger"]["evaluation_array_reads"] = 1  # type: ignore[index]
    with pytest.raises(PermissionError, match="evaluation"):
        admission.build_training_admission_payload(
            evidence=bad,
            execution_config_record={"path": "x", "sha256": "8" * 64},
            executable_records={"x.py": {"sha256": "9" * 64, "size_bytes": 1}},
            test_evidence={"result": "PASS"},
            runtime_environment_identity={"schema_version": "synthetic"},
            tensorfloat32_state={"cuda_matmul": False, "cudnn": False},
            execution=execution,
            admitted_at_utc="2026-08-31T12:30:00+00:00",
        )

    bad = _evidence()
    bad["filter_migration_final_manifest"] = {
        "path": "artifacts/filter_migration_v1/independent/manifest.final.sha256.json",
        "sha256": None,
    }
    with pytest.raises(RuntimeError, match="migration"):
        admission.build_training_admission_payload(
            evidence=bad,
            execution_config_record={"path": "x", "sha256": "8" * 64},
            executable_records={"x.py": {"sha256": "9" * 64, "size_bytes": 1}},
            test_evidence={"result": "PASS"},
            runtime_environment_identity={"schema_version": "synthetic"},
            tensorfloat32_state={"cuda_matmul": False, "cudnn": False},
            execution=execution,
            admitted_at_utc="2026-08-31T12:30:00+00:00",
        )


def test_initialize_gate_precedes_admission_or_snapshot_reads(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from scripts import initialize_tukf09_455_formal_training as initializer

    def forbidden(*_args: object, **_kwargs: object) -> bytes:
        raise AssertionError("initialization gate must run before file reads")

    monkeypatch.setattr(Path, "read_bytes", forbidden)
    with pytest.raises(PermissionError, match="initialization"):
        initializer.initialize_formal_training(
            initialize=False,
            project_root=ROOT,
        )


def test_training_common_exposes_no_evaluation_array_loader() -> None:
    from scripts import tukf09_455_training_common as common

    assert callable(common.load_training_validation_periods_455)
    assert callable(common.verify_initialized_training_root)
    assert not hasattr(common, "load_evaluation_periods")
    source = Path(common.__file__).read_text(encoding="utf-8").lower()
    assert "def load_evaluation" not in source


def test_controller_common_exposes_required_hard_gates() -> None:
    from scripts import tukf09_455_training_controller_common as controller

    for name in (
        "training_phase_lock",
        "controller_lock",
        "append_controller_event",
        "resource_snapshot",
        "process_is_alive",
        "reject_post_training_outputs",
    ):
        assert callable(getattr(controller, name))

