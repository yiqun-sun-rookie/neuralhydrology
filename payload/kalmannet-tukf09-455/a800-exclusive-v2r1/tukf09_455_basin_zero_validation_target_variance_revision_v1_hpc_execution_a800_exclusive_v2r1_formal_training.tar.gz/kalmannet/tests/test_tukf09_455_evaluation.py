from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path
from typing import Any

import numpy as np
import pytest
import torch

from scripts import tukf09_455_evaluation_common as common
from scripts import evaluate_tukf09_455_basin_revision as evaluator


EXPERIMENT_ID = "TUKF09_455_BASIN_ZERO_VALIDATION_TARGET_VARIANCE_REVISION_V1"
DAY_NS = 86_400_000_000_000


def _period(days: int = 12, basin_id: str = "00000001") -> common.EvaluationPeriod:
    dates = np.arange(days, dtype=np.int64) * DAY_NS
    forcing = np.column_stack(
        [np.arange(days, dtype=np.float64), np.ones(days), np.full(days, 2.0)]
    )
    observations = np.arange(days, dtype=np.float64) + 1.0
    return common.EvaluationPeriod(
        basin_id=basin_id,
        dates_ns=dates,
        forcing=forcing,
        observations=observations,
        production=False,
    )


def _capability(tmp_path: Path) -> common.EvaluationCapability:
    admission = {
        "schema_version": "tukf09_455_formal_evaluation_admission_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "FORMAL_EVALUATION_TECHNICALLY_ADMITTED_ONE_TIME",
        "evaluation_arrays_loaded": False,
        "evaluation_access_ledger": {
            "evaluation_array_reads": 0,
            "evaluation_predictions": 0,
            "evaluation_metrics": 0,
            "evaluation_outputs": 0,
        },
        "selection_sha256": "1" * 64,
        "independent_selection_sha256": "2" * 64,
        "exclusive_lock_identity": "lock-one",
    }
    lock = {
        "schema_version": "tukf09_455_formal_evaluation_lock_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "FORMAL_EVALUATION_LOCK_HELD",
        "lock_identity": "lock-one",
        "admission_sha256": "pending",
    }
    admission_path = tmp_path / "admission.json"
    lock_path = tmp_path / "lock.json"
    admission_path.write_text(json.dumps(admission), encoding="utf-8")
    lock["admission_sha256"] = sha256(admission_path.read_bytes()).hexdigest()
    lock_path.write_text(json.dumps(lock), encoding="utf-8")
    return common.issue_evaluation_capability(
        admission_path=admission_path,
        lock_path=lock_path,
        expected_selection_sha256="1" * 64,
        expected_independent_selection_sha256="2" * 64,
        production=False,
    )


def test_evaluation_capability_cannot_be_constructed_directly() -> None:
    with pytest.raises(PermissionError):
        common.EvaluationCapability()  # type: ignore[call-arg]


def test_loader_requires_capability_before_any_raw_callback(tmp_path: Path) -> None:
    called = False

    def raw_loader(_basin: str) -> Any:
        nonlocal called
        called = True
        raise AssertionError

    with pytest.raises(PermissionError):
        common.load_evaluation_periods(
            object(),  # type: ignore[arg-type]
            basin_ids=("00000001",),
            semantic_members={},
            raw_loader=raw_loader,
            production=False,
        )
    assert called is False


def test_loader_rechecks_semantic_identities_and_callback_order(tmp_path: Path) -> None:
    capability = _capability(tmp_path)
    period = _period()
    members = {
        f"{period.basin_id}/evaluation/{name}": common.semantic_array_identity(
            f"{period.basin_id}/evaluation/{name}",
            getattr(period, name),
            "<i8" if name == "dates_ns" else "<f8",
        )
        for name in ("dates_ns", "forcing", "observations")
    }
    order: list[str] = []

    def verify_sources() -> int:
        order.append("hash-raw")
        return 2

    def raw_loader(basin_id: str) -> common.EvaluationPeriod:
        order.append(f"load-{basin_id}")
        return period

    loaded = common.load_evaluation_periods(
        capability,
        basin_ids=(period.basin_id,),
        semantic_members=members,
        raw_loader=raw_loader,
        verify_raw_sources=verify_sources,
        production=False,
        expected_raw_source_count=2,
    )
    assert order == ["hash-raw", f"load-{period.basin_id}"]
    assert tuple(loaded) == (period.basin_id,)
    assert loaded[period.basin_id].observations.flags.writeable is False

    changed = dict(members)
    changed[f"{period.basin_id}/evaluation/observations"] = dict(
        changed[f"{period.basin_id}/evaluation/observations"]
    )
    changed[f"{period.basin_id}/evaluation/observations"]["sha256"] = "0" * 64
    with pytest.raises(RuntimeError, match="semantic"):
        common.load_evaluation_periods(
            capability,
            basin_ids=(period.basin_id,),
            semantic_members=changed,
            raw_loader=lambda _basin: period,
            production=False,
        )


@pytest.mark.parametrize(
    "mutator, message",
    [
        (lambda f, q: (np.array(f, copy=True), np.array(q, copy=True)), ""),
        (lambda f, q: (np.where(np.indices(f.shape)[0] == 0, np.nan, f), q), "forcing"),
        (lambda f, q: (f, np.where(np.arange(len(q)) == 0, -1.0, q)), "target"),
        (lambda f, q: (f, np.where(np.arange(len(q)) == 0, np.nan, q)), "target"),
    ],
)
def test_period_validation(mutator: Any, message: str) -> None:
    days = 8
    dates = np.arange(days, dtype=np.int64) * DAY_NS
    forcing = np.ones((days, 3), dtype=np.float64)
    target = np.arange(days, dtype=np.float64)
    changed_forcing, changed_target = mutator(forcing, target)
    if not message:
        period = common.EvaluationPeriod(
            basin_id="00000001",
            dates_ns=dates,
            forcing=changed_forcing,
            observations=changed_target,
            production=False,
        )
        assert period.forcing.flags.writeable is False
        return
    with pytest.raises((ValueError, FloatingPointError), match=message):
        common.EvaluationPeriod(
            basin_id="00000001",
            dates_ns=dates,
            forcing=changed_forcing,
            observations=changed_target,
            production=False,
        )


def test_filter_receives_fresh_contract_state_and_selected_diagonal() -> None:
    period = _period(days=14)
    initial = np.arange(5, dtype=np.float64)
    diagonal = np.linspace(0.1, 0.5, 5)
    received: list[tuple[np.ndarray, float, np.ndarray, float]] = []

    def runner(
        _period: common.EvaluationPeriod,
        initial_state: np.ndarray,
        base_observation_variance: float,
        process_diagonal: np.ndarray,
        observation_noise_multiplier: float,
    ) -> dict[int, np.ndarray]:
        received.append(
            (
                initial_state.copy(),
                base_observation_variance,
                process_diagonal.copy(),
                observation_noise_multiplier,
            )
        )
        initial_state[:] = -999.0
        return {lead: np.arange(14, dtype=np.float64) for lead in (1, 2, 3)}

    result = common.evaluate_filter(
        period,
        initial_state=initial,
        base_observation_variance=2.5,
        process_diagonal=diagonal,
        observation_noise_multiplier=0.7,
        runner=runner,
        first_scoring_index=3,
        expected_supports={1: 11, 2: 11, 3: 11},
        production=False,
    )
    assert set(result) == {1, 2, 3}
    assert len(received) == 1
    np.testing.assert_array_equal(received[0][0], np.arange(5, dtype=np.float64))
    np.testing.assert_array_equal(initial, np.arange(5, dtype=np.float64))
    np.testing.assert_array_equal(received[0][2], diagonal)
    assert received[0][1:] [0] == 2.5
    assert received[0][3] == 0.7


@dataclass(frozen=True)
class _Scaler:
    forcing_center: np.ndarray
    forcing_scale: np.ndarray
    discharge_center: float
    discharge_scale: float
    training_row_count: int = 100
    normalization_scope: str = "training_only_global_population_statistics"


class _RecordingModel(torch.nn.Module):
    def __init__(self, lead_days: int) -> None:
        super().__init__()
        self.lead_days = lead_days
        self.hidden_size = 2
        self.anchor = torch.nn.Parameter(torch.tensor(0.0))
        self.calls: list[tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]] = []

    def forward(
        self,
        forcing: torch.Tensor,
        lagged: torch.Tensor,
        h_0: torch.Tensor,
        c_0: torch.Tensor,
    ) -> dict[str, torch.Tensor]:
        self.calls.append((forcing.detach().cpu(), lagged.detach().cpu(), h_0.cpu(), c_0.cpu()))
        assert torch.count_nonzero(h_0) == 0
        assert torch.count_nonzero(c_0) == 0
        y_hat = torch.zeros((*forcing.shape[:2], 1), device=forcing.device)
        y_hat[:, -1, 0] = torch.arange(forcing.shape[0], device=forcing.device) + 1.0
        return {"y_hat": y_hat + self.anchor * 0.0}


def test_neural_inference_resets_every_window_is_causal_and_inverse_scales() -> None:
    period = _period(days=10)
    scaler = _Scaler(
        forcing_center=np.zeros(3),
        forcing_scale=np.ones(3),
        discharge_center=10.0,
        discharge_scale=2.0,
    )
    model = _RecordingModel(lead_days=2)
    prediction = common.evaluate_neural_seed(
        period,
        lead_days=2,
        model=model,
        scaler=scaler,
        selected_checkpoint_sha256="a" * 64,
        current_checkpoint_sha256="a" * 64,
        sequence_length=4,
        first_scoring_index=4,
        batch_size=2,
        production=False,
    )[2]
    assert model.training is False
    assert all(parameter.grad is None for parameter in model.parameters())
    assert len(model.calls) == 3
    finite = prediction[np.isfinite(prediction)]
    np.testing.assert_array_equal(finite, np.tile(np.asarray([12.0, 14.0]), 3))
    for _forcing, lagged, hidden, memory in model.calls:
        assert torch.count_nonzero(hidden) == 0
        assert torch.count_nonzero(memory) == 0
        assert lagged.shape[1] == 4


def test_three_seed_ensemble_is_arithmetic_mean_in_original_units() -> None:
    predictions = [
        np.asarray([1.0, 4.0]),
        np.asarray([2.0, 5.0]),
        np.asarray([6.0, 9.0]),
    ]
    np.testing.assert_array_equal(
        common.three_seed_ensemble(predictions),
        np.asarray([3.0, 6.0]),
    )
    with pytest.raises(ValueError, match="three"):
        common.three_seed_ensemble(predictions[:2])


def test_common_mask_nse_and_zero_variance_hard_stop() -> None:
    target = np.asarray([9.0, 9.0, 1.0, 2.0, 3.0, 4.0])
    filter_prediction = np.asarray([0.0, 0.0, 1.0, 2.0, np.nan, 4.0])
    ensemble = np.asarray([0.0, 0.0, 1.5, 2.5, 3.5, 4.5])
    seeds = [ensemble + value for value in (-0.1, 0.0, 0.1)]
    record = common.common_mask_and_nse(
        target,
        filter_prediction,
        ensemble,
        seeds,
        lead_days=1,
        first_scoring_index=2,
        expected_count=3,
    )
    np.testing.assert_array_equal(record.mask, [False, False, True, True, False, True])
    assert record.target_denominator == pytest.approx(14.0 / 3.0)
    assert record.filter_nse == pytest.approx(1.0)
    assert len(record.seed_nse) == 3

    constant = np.ones(6)
    with pytest.raises(common.UndefinedEvaluationTargetVariance):
        common.common_mask_and_nse(
            constant,
            constant,
            constant,
            [constant, constant, constant],
            lead_days=1,
            first_scoring_index=2,
            expected_count=4,
            basin_id="00000001",
        )


def test_bootstrap_is_deterministic_and_decision_boundaries_are_frozen() -> None:
    values = np.linspace(-0.05, 0.05, 11)
    first = common.paired_basin_bootstrap(values, seed=20260811, resamples=250)
    second = common.paired_basin_bootstrap(values, seed=20260811, resamples=250)
    assert first == second
    assert first.population_count == 11
    assert first.resamples == 250
    assert common.decision_from_interval(0.01, 0.02)[0] == (
        "FILTER_PRACTICALLY_EXCEEDS_NEURAL_ENSEMBLE"
    )
    assert common.decision_from_interval(-0.01, 0.02)[0] == (
        "FILTER_REACHES_NEURAL_ENSEMBLE_WITHOUT_PROVEN_PRACTICAL_SUPERIORITY"
    )
    assert common.decision_from_interval(-0.03, -0.01)[0] == (
        "FILTER_BELOW_NEURAL_ENSEMBLE"
    )
    assert common.decision_from_interval(-0.01, 0.02)[1] is False
    assert common.decision_from_interval(-0.02, 0.02)[0] == "INCONCLUSIVE"


def _synthetic_predictions(period: common.EvaluationPeriod) -> tuple[dict[int, np.ndarray], dict[int, dict[int, np.ndarray]]]:
    target = period.observations
    filter_predictions = {lead: target + 0.1 * lead for lead in (1, 2, 3)}
    seed_predictions = {
        lead: {seed: target + 0.2 * lead + 0.01 * seed for seed in (0, 1, 2)}
        for lead in (1, 2, 3)
    }
    return filter_predictions, seed_predictions


def test_formal_evaluation_synthetic_publication_and_failure_boundary(tmp_path: Path) -> None:
    periods = {f"0000000{i}": _period(days=12, basin_id=f"0000000{i}") for i in (1, 2)}

    result = evaluator.run_formal_evaluation(
        authorize=True,
        output_root=tmp_path / "formal-evaluation",
        ordered_basin_ids=tuple(periods),
        admitted_identity={"admission_sha256": "a" * 64, "attempt_id": "attempt-one"},
        acquire_verified_capability=lambda: object(),
        period_loader=lambda _capability: periods,
        filter_predictor=lambda _basin, period: _synthetic_predictions(period)[0],
        neural_seed_predictor=lambda _basin, period: _synthetic_predictions(period)[1],
        first_scoring_index=3,
        expected_supports={1: 9, 2: 9, 3: 9},
        bootstrap_resamples=50,
        production=False,
    )
    assert result["status"] == "FORMAL_EVALUATION_COMPLETE_PENDING_INDEPENDENT_AUDIT"
    assert result["basin_count"] == 2
    assert result["primary_nse_count"] == 12
    assert result["supplemental_seed_nse_count"] == 18
    assert (tmp_path / "formal-evaluation" / "evaluation_summary.json").is_file()
    assert (tmp_path / "formal-evaluation" / "manifest.sha256.json").is_file()

    constant_period = common.EvaluationPeriod(
        basin_id="00000003",
        dates_ns=np.arange(12, dtype=np.int64) * DAY_NS,
        forcing=np.ones((12, 3)),
        observations=np.ones(12),
        production=False,
    )
    with pytest.raises(common.UndefinedEvaluationTargetVariance):
        evaluator.run_formal_evaluation(
            authorize=True,
            output_root=tmp_path / "constant-evaluation",
            ordered_basin_ids=("00000003",),
            admitted_identity={"admission_sha256": "b" * 64, "attempt_id": "attempt-two"},
            acquire_verified_capability=lambda: object(),
            period_loader=lambda _capability: {"00000003": constant_period},
            filter_predictor=lambda _basin, period: _synthetic_predictions(period)[0],
            neural_seed_predictor=lambda _basin, period: _synthetic_predictions(period)[1],
            first_scoring_index=3,
            expected_supports={1: 9, 2: 9, 3: 9},
            bootstrap_resamples=20,
            production=False,
        )
    failure = tmp_path / "constant-evaluation.failed.attempt-two" / "target_variance_failure.json"
    assert failure.is_file()
    assert not (tmp_path / "constant-evaluation" / "evaluation_summary.json").exists()


def test_formal_evaluation_authorization_gate_precedes_capability() -> None:
    called = False

    def capability() -> Any:
        nonlocal called
        called = True
        raise AssertionError

    with pytest.raises(PermissionError):
        evaluator.run_formal_evaluation(
            authorize=False,
            output_root=Path("unused"),
            ordered_basin_ids=(),
            admitted_identity={},
            acquire_verified_capability=capability,
            period_loader=lambda _capability: {},
            filter_predictor=lambda _basin, _period: {},
            neural_seed_predictor=lambda _basin, _period: {},
            production=False,
        )
    assert called is False
