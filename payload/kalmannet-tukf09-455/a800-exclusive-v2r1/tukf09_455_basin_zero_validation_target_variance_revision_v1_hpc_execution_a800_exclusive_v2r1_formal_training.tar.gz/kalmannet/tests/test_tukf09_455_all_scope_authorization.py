from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

import pytest


ROOT = Path(__file__).resolve().parents[1]
CONTRACT = ROOT / "configs/tukf09_455_basin_zero_validation_target_variance_revision_v1.json"
PREFLIGHT_FINAL = (
    ROOT
    / "artifacts/tukf09_455_basin_zero_validation_target_variance_revision_v1"
    / "preflight/independent/manifest.final.sha256.json"
)
MIGRATION_CONFIG = (
    ROOT
    / "configs/tukf09_455_basin_zero_validation_target_variance_filter_migration_v1.json"
)
TRAINING_CONFIG = (
    ROOT
    / "configs/tukf09_455_basin_zero_validation_target_variance_formal_training_execution_v1.json"
)
EVALUATION_CONFIG = (
    ROOT
    / "configs/tukf09_455_basin_zero_validation_target_variance_formal_evaluation_v1.json"
)
PRODUCTION_CLI_RELATIVES = (
    "scripts/preflight_tukf09_455_basin_zero_validation_target_variance_revision.py",
    "scripts/register_tukf09_455_all_scope_authorization.py",
    "scripts/migrate_tukf09_455_filter_results.py",
    "scripts/verify_tukf09_455_filter_migration.py",
    "scripts/admit_tukf09_455_formal_training.py",
    "scripts/initialize_tukf09_455_formal_training.py",
    "scripts/install_tukf09_455_filter_results.py",
    "scripts/verify_tukf09_455_filter_installation.py",
    "scripts/verify_tukf09_455_filter_rebinding_controller.py",
    "scripts/run_tukf09_455_neural_training.py",
    "scripts/run_tukf09_455_neural_training_controller.py",
    "scripts/run_tukf09_455_formal_training_sequence.py",
    "scripts/seal_tukf09_455_training_selection.py",
    "scripts/verify_tukf09_455_training_selection.py",
    "scripts/register_tukf09_455_formal_evaluation_authorization.py",
    "scripts/admit_tukf09_455_formal_evaluation.py",
    "scripts/evaluate_tukf09_455_basin_revision.py",
    "scripts/verify_tukf09_455_basin_evaluation.py",
)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _copy_fixed_inputs(destination: Path) -> None:
    for source in (
        CONTRACT,
        MIGRATION_CONFIG,
        TRAINING_CONFIG,
        EVALUATION_CONFIG,
        PREFLIGHT_FINAL,
    ):
        relative = source.relative_to(ROOT)
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)


def test_three_phase_configs_are_isolated_and_frozen() -> None:
    migration = json.loads(MIGRATION_CONFIG.read_text(encoding="utf-8"))
    training = json.loads(TRAINING_CONFIG.read_text(encoding="utf-8"))
    evaluation = json.loads(EVALUATION_CONFIG.read_text(encoding="utf-8"))

    experiment = "TUKF09_455_BASIN_ZERO_VALIDATION_TARGET_VARIANCE_REVISION_V1"
    assert migration["experiment_id"] == experiment
    assert training["experiment_id"] == experiment
    assert evaluation["experiment_id"] == experiment
    assert migration["status"] == "FILTER_MIGRATION_DESIGN_FROZEN_EXECUTION_NOT_STARTED"
    assert training["status"] == "FORMAL_TRAINING_DESIGN_FROZEN_MIGRATION_SEAL_PENDING"
    assert evaluation["status"] == "FORMAL_EVALUATION_ALGORITHM_FROZEN_SELECTION_SEAL_PENDING"

    assert migration["population"]["ordered_basin_count"] == 455
    assert migration["population"]["excluded_basins"] == ["08202700"]
    assert migration["atomic_unit"]["count"] == 455
    assert migration["atomic_unit"]["file_count"] == 6
    assert migration["completion_counts"]["new_filter_optimization_units"] == 0
    assert training["completion_counts"]["rebound_filter_units"] == 455
    assert training["completion_counts"]["new_filter_training_units"] == 0
    assert training["completion_counts"]["neural_model_units"] == 9
    assert training["completion_counts"]["neural_checkpoints"] == 270
    assert training["completion_counts"]["evaluation_array_reads"] == 0
    assert training["controller_order"]["training_stages"] == [
        "verify_filter_rebinding",
        "neural",
    ]
    assert "scripts/verify_tukf09_455_filter_rebinding_controller.py" in (
        training["required_executables"]
    )
    for relative in (
        "tests/test_tukf09_455_evaluation_authorization.py",
        "tests/test_tukf09_455_evaluation.py",
        "tests/test_tukf09_455_evaluation_audit.py",
    ):
        assert relative in training["required_test_policy"]["pytest_files"]
    assert "tests/test_tukf09_455_training_controllers.py" not in (
        training["required_test_policy"]["pytest_files"]
    )
    assert evaluation["executables"] == [
        "scripts/tukf09_455_evaluation_common.py",
        "scripts/register_tukf09_455_formal_evaluation_authorization.py",
        "scripts/admit_tukf09_455_formal_evaluation.py",
        "scripts/evaluate_tukf09_455_basin_revision.py",
        "scripts/verify_tukf09_455_basin_evaluation.py",
    ]
    assert training["filter_migration_final_manifest"]["sha256"] is None
    assert training["filter_migration_final_manifest"]["binding_stage"] == (
        "training_admission"
    )

    assert evaluation["selection_final_manifest"]["sha256"] is None
    assert evaluation["selection_final_manifest"]["binding_stage"] == (
        "formal_evaluation_admission"
    )
    assert evaluation["population"]["ordered_basin_count"] == 455
    assert evaluation["evaluation_period"]["day_count"] == 3287
    assert evaluation["evaluation_identity"]["member_count"] == 1365
    assert evaluation["completion_counts"]["prediction_vectors"] == 6825
    assert evaluation["completion_counts"]["total_nse_values"] == 6825
    assert evaluation["paths"]["authorization"].endswith(
        "authorizations/formal_evaluation_authorization.json"
    )
    assert evaluation["paths"]["admission"].endswith(
        "formal_evaluation_admission/formal_evaluation_admission.json"
    )
    assert evaluation["decision_rule"]["ordered_first_match"] == [
        {
            "condition": "lower_bound >= 0.01",
            "classification": "FILTER_PRACTICALLY_EXCEEDS_NEURAL_ENSEMBLE",
            "success": True,
        },
        {
            "condition": "lower_bound >= -0.01",
            "classification": (
                "FILTER_REACHES_NEURAL_ENSEMBLE_WITHOUT_PROVEN_PRACTICAL_"
                "SUPERIORITY"
            ),
            "success": False,
        },
        {
            "condition": "upper_bound <= -0.01",
            "classification": "FILTER_BELOW_NEURAL_ENSEMBLE",
            "success": False,
        },
        {
            "condition": "otherwise",
            "classification": "INCONCLUSIVE",
            "success": False,
        },
    ]


def test_profile_pins_existing_frozen_evidence_without_changing_it() -> None:
    from scripts import tukf09_455_training_profile as profile

    assert profile.EXPECTED_CONTRACT_SHA256 == _sha256(CONTRACT)
    assert profile.EXPECTED_PREFLIGHT_FINAL_SHA256 == _sha256(PREFLIGHT_FINAL)
    assert profile.EXPERIMENT_ID == (
        "TUKF09_455_BASIN_ZERO_VALIDATION_TARGET_VARIANCE_REVISION_V1"
    )
    assert profile.ORDERED_BASIN_COUNT == 455
    assert profile.ORDERED_BASIN_NEWLINE_SHA256 == (
        "38987bce45fa38ff68f5b067db17e8cb3212d98fecdd106f57d268a130ee8fbd"
    )
    assert profile.EVALUATION_IDENTITY_MEMBER_COUNT == 1365


def test_registration_gate_precedes_every_file_read(monkeypatch: pytest.MonkeyPatch) -> None:
    from scripts import register_tukf09_455_all_scope_authorization as registration

    def forbidden(*_args: object, **_kwargs: object) -> bytes:
        raise AssertionError("authorization gate must run before file reads")

    monkeypatch.setattr(Path, "read_bytes", forbidden)
    with pytest.raises(PermissionError, match="authorization"):
        registration.register_all_scope_authorization(
            authorization_text="全部授权",
            register=False,
            project_root=ROOT,
        )


def test_all_scope_authorization_is_canonical_atomic_and_does_not_create_results(
    tmp_path: Path,
) -> None:
    from scripts import register_tukf09_455_all_scope_authorization as registration
    from scripts import tukf09_455_training_profile as profile

    _copy_fixed_inputs(tmp_path)
    result = registration.register_all_scope_authorization(
        authorization_text="全部授权",
        register=True,
        project_root=tmp_path,
        registered_at_utc="2026-08-31T12:00:00+00:00",
    )
    authorization_path = tmp_path / profile.AUTHORIZATION_RELATIVE
    assert result["status"] == (
        "ALL_REQUESTED_PHASES_AUTHORIZED_SEQUENTIAL_ADMISSION_REQUIRED"
    )
    assert authorization_path.is_file()
    record = json.loads(authorization_path.read_text(encoding="utf-8"))
    assert authorization_path.read_bytes() == registration.canonical_json_bytes(record)
    assert record["authorization_text"] == "全部授权"
    assert record["scope"]["result_migration_authorized"] is True
    assert record["scope"]["filter_result_rebinding_authorized"] is True
    assert record["scope"]["new_filter_optimization_authorized"] is False
    assert record["scope"]["neural_training_authorized"] is True
    assert record["scope"]["formal_evaluation_authorized"] is True
    assert record["required_phase_order"][0] == "filter_migration"
    unsigned = dict(record)
    stored = unsigned.pop("authorization_record_sha256")
    assert stored == hashlib.sha256(
        registration.canonical_json_bytes(unsigned)
    ).hexdigest()
    assert not (tmp_path / profile.OUTPUT_RELATIVE).exists()


def test_all_fixed_production_cli_paths_import_and_expose_help() -> None:
    environment = dict(os.environ)
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    for relative in PRODUCTION_CLI_RELATIVES:
        completed = subprocess.run(
            [sys.executable, "-B", os.fspath(ROOT / relative), "--help"],
            cwd=ROOT,
            env=environment,
            stdin=subprocess.DEVNULL,
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        assert completed.returncode == 0, (
            relative,
            completed.stdout,
            completed.stderr,
        )
