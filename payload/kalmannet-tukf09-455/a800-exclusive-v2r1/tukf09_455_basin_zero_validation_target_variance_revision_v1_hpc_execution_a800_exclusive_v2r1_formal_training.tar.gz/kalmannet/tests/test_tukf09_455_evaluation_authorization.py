from __future__ import annotations

from hashlib import sha256
import json
from pathlib import Path
from typing import Any, Mapping

import pytest

from scripts import admit_tukf09_455_formal_evaluation as admission
from scripts import register_tukf09_455_formal_evaluation_authorization as registration
from scripts import tukf09_455_training_common as training_common


EXPERIMENT_ID = "TUKF09_455_BASIN_ZERO_VALIDATION_TARGET_VARIANCE_REVISION_V1"
ZERO_LEDGER = {
    "evaluation_array_reads": 0,
    "evaluation_predictions": 0,
    "evaluation_metrics": 0,
    "evaluation_outputs": 0,
}
REQUIRED_BINDINGS = (
    "scientific_contract",
    "independent_preflight_final_manifest",
    "all_scope_authorization",
    "filter_migration_final_manifest",
    "training_authorization",
    "training_admission",
    "filter_installation_final_manifest",
    "training_completion",
    "training_selection_seal",
    "independent_training_selection_final_manifest",
    "formal_training_execution_config",
    "formal_evaluation_config",
    "evaluation_common_source",
    "evaluator_source",
    "independent_evaluation_verifier_source",
    "model_source",
    "filter_runner_source",
    "confirmatory_common_source",
    "covariance_update_source",
    "differentiable_ukf_reference_source",
    "conventional_ukf_source",
    "differentiable_filter_engine_source",
    "differentiable_hbvlite_model_source",
    "hbvlite_system_model_source",
    "hbvlite_ukf_adapter_source",
    "fixed_results_identity",
)


def _json_bytes(value: Any) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")


def _write_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(_json_bytes(value))


def _record(path: Path) -> dict[str, Any]:
    return {"sha256": sha256(path.read_bytes()).hexdigest(), "size_bytes": path.stat().st_size}


def _upstream_payload(label: str) -> dict[str, Any]:
    status = {
        "scientific_contract": "SCIENTIFIC_CONTRACT_FROZEN",
        "independent_preflight_final_manifest": "PREFLIGHT_INDEPENDENTLY_VERIFIED",
        "all_scope_authorization": "ALL_SCOPE_EXECUTION_AUTHORIZED",
        "filter_migration_final_manifest": "FILTER_MIGRATION_INDEPENDENTLY_VERIFIED",
        "training_authorization": "FORMAL_TRAINING_AUTHORIZED",
        "training_admission": "FORMAL_TRAINING_TECHNICALLY_ADMITTED",
        "filter_installation_final_manifest": "FILTER_INSTALLATION_INDEPENDENTLY_VERIFIED",
        "training_completion": "FORMAL_TRAINING_COMPLETE_EVALUATION_HOLD",
        "training_selection_seal": "TRAINING_SELECTION_SEALED_EVALUATION_HOLD",
        "independent_training_selection_final_manifest": (
            "TRAINING_SELECTION_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
        ),
        "formal_evaluation_config": "FORMAL_EVALUATION_ALGORITHM_FROZEN",
        "fixed_results_identity": "FIXED_RESULTS_ROOT_IDENTITY",
    }.get(label, "SOURCE_FILE")
    payload: dict[str, Any] = {
        "schema_version": f"synthetic_{label}_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": status,
    }
    if label in {
        "training_authorization",
        "training_admission",
        "training_completion",
        "training_selection_seal",
        "independent_training_selection_final_manifest",
        "fixed_results_identity",
    }:
        payload["evaluation_arrays_loaded"] = False
        payload["evaluation_access_ledger"] = dict(ZERO_LEDGER)
    if label == "training_completion":
        payload.update({"completed_neural_models": 9, "expected_neural_models": 9})
    if label == "training_selection_seal":
        payload.update(
            {
                "filter_selected_model_count": 455,
                "neural_selected_model_count": 9,
                "independent_training_selection_verification_required": True,
            }
        )
    if label == "independent_training_selection_final_manifest":
        payload.update({"mismatch_count": 0, "file_count": 1})
    return payload


def _binding_tree(tmp_path: Path) -> dict[str, Path]:
    result: dict[str, Path] = {}
    for label in REQUIRED_BINDINGS:
        path = tmp_path / "bindings" / f"{label}.json"
        _write_json(path, _upstream_payload(label))
        result[label] = path
    return result


def _test_evidence(tmp_path: Path, bindings: Mapping[str, Path]) -> Path:
    source_labels = set(registration.SOURCE_BINDING_LABELS)
    payload = {
        "schema_version": "tukf09_455_evaluation_test_evidence_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "EVALUATION_CODE_TESTS_PASSED",
        "command": (
            "python -B -m pytest tests/test_tukf09_455_evaluation_authorization.py "
            "tests/test_tukf09_455_evaluation.py tests/test_tukf09_455_evaluation_audit.py"
        ),
        "passed": 24,
        "failed": 0,
        "cache_disabled": True,
        "bytecode_disabled": True,
        "source_sha256": {
            label: sha256(bindings[label].read_bytes()).hexdigest()
            for label in source_labels
        },
    }
    path = tmp_path / "test_evidence.json"
    _write_json(path, payload)
    return path


def test_registration_refuses_before_any_file_read(monkeypatch: pytest.MonkeyPatch) -> None:
    def forbidden(*_args: Any, **_kwargs: Any) -> Any:
        raise AssertionError("authorization gate must precede every read")

    monkeypatch.setattr(Path, "read_bytes", forbidden)
    monkeypatch.setattr(Path, "read_text", forbidden)
    with pytest.raises(PermissionError, match="explicit"):
        registration.register_evaluation_authorization(
            bindings={},
            fixed_results_root=Path("unused"),
            evaluation_output_root=Path("unused"),
            destination=Path("unused"),
            authorize=False,
            production=False,
        )


def test_registration_binds_every_input_and_keeps_evaluation_access_zero(
    tmp_path: Path,
) -> None:
    bindings = _binding_tree(tmp_path)
    destination = tmp_path / "authorization" / "formal_evaluation_authorization.json"
    result = registration.register_evaluation_authorization(
        bindings=bindings,
        fixed_results_root=tmp_path / "fixed-results",
        evaluation_output_root=tmp_path / "fixed-results" / "formal_evaluation",
        destination=destination,
        authorize=True,
        production=False,
        created_utc="2026-08-31T00:00:00Z",
    )

    assert destination.is_file()
    assert result["status"] == "FORMAL_EVALUATION_AUTHORIZED_ONE_TIME"
    assert result["one_time"] is True
    assert result["evaluation_arrays_loaded"] is False
    assert result["evaluation_access_ledger"] == ZERO_LEDGER
    assert set(result["bindings"]) == set(REQUIRED_BINDINGS)
    for label, path in bindings.items():
        assert result["bindings"][label]["sha256"] == sha256(path.read_bytes()).hexdigest()
        assert result["bindings"][label]["size_bytes"] == path.stat().st_size
    assert result["record_sha256"] == registration.record_sha256(result)
    with pytest.raises(FileExistsError):
        registration.register_evaluation_authorization(
            bindings=bindings,
            fixed_results_root=tmp_path / "fixed-results",
            evaluation_output_root=tmp_path / "fixed-results" / "formal_evaluation",
            destination=destination,
            authorize=True,
            production=False,
            created_utc="2026-08-31T00:00:00Z",
        )


def test_registration_rejects_incomplete_selection_or_nonzero_access(tmp_path: Path) -> None:
    bindings = _binding_tree(tmp_path)
    selection = _upstream_payload("training_selection_seal")
    selection["neural_selected_model_count"] = 8
    _write_json(bindings["training_selection_seal"], selection)
    with pytest.raises(RuntimeError, match="selection"):
        registration.register_evaluation_authorization(
            bindings=bindings,
            fixed_results_root=tmp_path / "fixed-results",
            evaluation_output_root=tmp_path / "fixed-results" / "formal_evaluation",
            destination=tmp_path / "authorization.json",
            authorize=True,
            production=False,
        )

    bindings = _binding_tree(tmp_path / "second")
    training = _upstream_payload("training_completion")
    training["evaluation_access_ledger"]["evaluation_array_reads"] = 1
    _write_json(bindings["training_completion"], training)
    with pytest.raises(RuntimeError, match="evaluation access"):
        registration.register_evaluation_authorization(
            bindings=bindings,
            fixed_results_root=tmp_path / "fixed-results-2",
            evaluation_output_root=tmp_path / "fixed-results-2" / "formal_evaluation",
            destination=tmp_path / "authorization-2.json",
            authorize=True,
            production=False,
        )


def test_admission_gate_precedes_every_file_read(monkeypatch: pytest.MonkeyPatch) -> None:
    def forbidden(*_args: Any, **_kwargs: Any) -> Any:
        raise AssertionError("admission gate must precede every read")

    monkeypatch.setattr(Path, "read_bytes", forbidden)
    with pytest.raises(PermissionError, match="explicit"):
        admission.admit_formal_evaluation(
            authorization_path=Path("unused"),
            test_evidence_path=Path("unused"),
            destination=Path("unused"),
            authorize=False,
            production=False,
        )


def test_admission_rehashes_sources_without_constructing_evaluation_arrays(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    bindings = _binding_tree(tmp_path)
    authorization_path = tmp_path / "authorization.json"
    registration.register_evaluation_authorization(
        bindings=bindings,
        fixed_results_root=tmp_path / "fixed-results",
        evaluation_output_root=tmp_path / "fixed-results" / "formal_evaluation",
        destination=authorization_path,
        authorize=True,
        production=False,
        created_utc="2026-08-31T00:00:00Z",
    )
    evidence = _test_evidence(tmp_path, bindings)

    def forbidden_load(*_args: Any, **_kwargs: Any) -> Any:
        raise AssertionError("technical admission must not load any NumPy array")

    monkeypatch.setattr(admission.np, "load", forbidden_load)
    destination = tmp_path / "admission.json"
    result = admission.admit_formal_evaluation(
        authorization_path=authorization_path,
        test_evidence_path=evidence,
        destination=destination,
        authorize=True,
        production=False,
        created_utc="2026-08-31T00:01:00Z",
    )
    assert isinstance(result, admission.EvaluationAdmission)
    assert result.record["status"] == "FORMAL_EVALUATION_TECHNICALLY_ADMITTED_ONE_TIME"
    assert result.record["evaluation_arrays_loaded"] is False
    assert result.record["evaluation_access_ledger"] == ZERO_LEDGER
    assert result.record["authorization_sha256"] == sha256(
        authorization_path.read_bytes()
    ).hexdigest()


def test_admission_detects_changed_executable_and_failed_test_evidence(tmp_path: Path) -> None:
    bindings = _binding_tree(tmp_path)
    authorization_path = tmp_path / "authorization.json"
    registration.register_evaluation_authorization(
        bindings=bindings,
        fixed_results_root=tmp_path / "fixed-results",
        evaluation_output_root=tmp_path / "fixed-results" / "formal_evaluation",
        destination=authorization_path,
        authorize=True,
        production=False,
    )
    evidence = _test_evidence(tmp_path, bindings)
    bindings["evaluator_source"].write_text("changed", encoding="utf-8")
    with pytest.raises(RuntimeError, match="changed"):
        admission.admit_formal_evaluation(
            authorization_path=authorization_path,
            test_evidence_path=evidence,
            destination=tmp_path / "admission.json",
            authorize=True,
            production=False,
        )

    bindings = _binding_tree(tmp_path / "second")
    authorization_path = tmp_path / "authorization-2.json"
    registration.register_evaluation_authorization(
        bindings=bindings,
        fixed_results_root=tmp_path / "fixed-results-2",
        evaluation_output_root=tmp_path / "fixed-results-2" / "formal_evaluation",
        destination=authorization_path,
        authorize=True,
        production=False,
    )
    evidence = _test_evidence(tmp_path / "second", bindings)
    payload = json.loads(evidence.read_text(encoding="utf-8"))
    payload["failed"] = 1
    _write_json(evidence, payload)
    with pytest.raises(RuntimeError, match="tests"):
        admission.admit_formal_evaluation(
            authorization_path=authorization_path,
            test_evidence_path=evidence,
            destination=tmp_path / "admission-2.json",
            authorize=True,
            production=False,
        )


def test_ordered_thirty_file_closure_survives_canonical_json_key_sorting(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root = tmp_path / "project"
    expected = list(training_common.REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS)
    assert len(expected) == 30
    executable_records: dict[str, dict[str, Any]] = {}
    for index, relative in enumerate(expected):
        path = root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(f"source-{index}\n", encoding="utf-8")
        executable_records[relative] = _record(path)
    execution_path = root / (
        "configs/tukf09_455_basin_zero_validation_target_variance_"
        "formal_training_execution_v1.json"
    )
    _write_json(execution_path, {"required_executables": expected})
    admission_payload = {
        "executables": executable_records,
        "execution_config": {
            "path": (
                "configs/tukf09_455_basin_zero_validation_target_variance_"
                "formal_training_execution_v1.json"
            ),
            "sha256": sha256(execution_path.read_bytes()).hexdigest(),
        },
    }
    # Canonical JSON sorts object keys, so order must come only from the config array.
    round_tripped = json.loads(_json_bytes(admission_payload))
    assert list(round_tripped["executables"]) != expected
    monkeypatch.setattr(registration, "ROOT", root)
    result = registration._validate_training_executable_closure(
        {
            "formal_training_execution_config": {"required_executables": expected},
            "training_admission": round_tripped,
        },
        {"formal_training_execution_config": {"path": str(execution_path), **_record(execution_path)}},
    )
    assert list(result) == expected


def _pretraining_identity_fixture() -> tuple[dict[str, dict[str, Any]], dict[str, dict[str, Any]]]:
    hashes = {
        "contract": "1" * 64,
        "preflight": "2" * 64,
        "training_config": "3" * 64,
        "evaluation_config": "4" * 64,
        "authorization_file": "5" * 64,
    }
    all_scope: dict[str, Any] = {
        "experiment_id": EXPERIMENT_ID,
        "frozen_inputs": {
            "scientific_contract": {"sha256": hashes["contract"]},
            "independent_preflight_final_manifest": {"sha256": hashes["preflight"]},
            "formal_training_execution_config": {"sha256": hashes["training_config"]},
            "formal_evaluation_algorithm_config": {"sha256": hashes["evaluation_config"]},
        },
    }
    all_scope["authorization_record_sha256"] = registration._canonical_sha256(all_scope)
    training: dict[str, Any] = {
        "experiment_id": EXPERIMENT_ID,
        "scientific_contract_sha256": hashes["contract"],
        "scientific_contract": {"sha256": hashes["contract"]},
        "preflight_final_manifest_sha256": hashes["preflight"],
        "independent_preflight_final_manifest": {"sha256": hashes["preflight"]},
        "execution_config": {"sha256": hashes["training_config"]},
        "authorization": {
            "file_sha256": hashes["authorization_file"],
            "record_sha256": all_scope["authorization_record_sha256"],
        },
    }
    training["training_admission_record_sha256"] = registration._canonical_sha256(training)
    records = {
        "scientific_contract": {"sha256": hashes["contract"]},
        "independent_preflight_final_manifest": {"sha256": hashes["preflight"]},
        "formal_training_execution_config": {"sha256": hashes["training_config"]},
        "formal_evaluation_config": {"sha256": hashes["evaluation_config"]},
        "all_scope_authorization": {"sha256": hashes["authorization_file"]},
        "training_authorization": {"sha256": hashes["authorization_file"]},
    }
    return {"training_admission": training, "all_scope_authorization": all_scope}, records


@pytest.mark.parametrize("changed_label", ["scientific_contract", "formal_evaluation_config"])
def test_post_training_contract_or_evaluation_config_replacement_is_rejected(
    changed_label: str,
) -> None:
    documents, records = _pretraining_identity_fixture()
    registration._validate_pretraining_identity_chain(documents, records)
    records[changed_label] = {"sha256": "f" * 64}
    with pytest.raises(RuntimeError, match="pretraining identity"):
        registration._validate_pretraining_identity_chain(documents, records)


def _runtime_identity() -> dict[str, Any]:
    return {
        "schema_version": "tukf09_runtime_environment_identity_v1",
        "python_version": "3.12.0",
        "python_executable": str(Path("C:/Python/python.exe")),
        "numpy_version": "2.0.0",
        "torch_version": "2.7.0",
        "psutil_version": "6.0.0",
        "torch_cuda_runtime_version": "12.8",
        "cudnn_version": 90000,
        "cuda_available": True,
        "cuda_device_count": 1,
        "cuda_device_name_0": "Synthetic GPU",
        "nvidia_gpu_uuid_0": "GPU-12345678-1234-1234-1234-123456789abc",
        "nvidia_driver_version": "999.1",
        "platform": "Windows-synthetic",
        "machine": "AMD64",
        "logical_cpu_count": 8,
    }


def test_evaluation_runtime_drift_from_training_admission_is_rejected(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    training_path = tmp_path / "training_admission.json"
    expected = _runtime_identity()
    _write_json(training_path, {"runtime_environment_identity": expected})
    changed = dict(expected)
    changed["numpy_version"] = "2.0.1"
    monkeypatch.setattr(training_common, "runtime_environment_identity", lambda: changed)
    with pytest.raises(RuntimeError, match="runtime environment differs"):
        admission._require_current_runtime_matches_training(
            {"training_admission": {"path": str(training_path)}}
        )


def _selection_bundle(tmp_path: Path) -> tuple[dict[str, Any], dict[str, Any], Path]:
    results = tmp_path / "results"
    selection = results / "selection"
    independent = results / "independent"
    selection.mkdir(parents=True)
    independent.mkdir(parents=True)
    current_admission = tmp_path / "training_admission.json"
    _write_json(current_admission, {"experiment_id": EXPERIMENT_ID, "status": "ADMITTED"})
    snapshot = results / "training_admission.snapshot.json"
    snapshot.write_bytes(current_admission.read_bytes())
    counts = {
        "rebound_filter_units": 455,
        "new_filter_training_units": 0,
        "inherited_filter_checkpoint_records": 116480,
        "new_filter_training_objective_calls": 0,
        "new_filter_validation_objective_calls": 0,
        "new_filter_gradient_updates": 0,
        "neural_model_units": 9,
        "neural_checkpoints": 270,
        **ZERO_LEDGER,
    }
    files = {"training_admission.snapshot.json": _record(snapshot)}
    manifest = {
        "schema_version": "tukf09_full_training_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "FULL_TRAINING_MANIFEST_COMPLETE_EVALUATION_HOLD",
        "file_count": 1,
        "files": files,
        "files_canonical_sha256": registration._canonical_sha256(files),
        "completion_counts": counts,
        "formal_evaluation_authorized": False,
    }
    manifest_path = selection / "training_manifest.sha256.json"
    _write_json(manifest_path, manifest)
    seal = {
        "experiment_id": EXPERIMENT_ID,
        "status": "TRAINING_SELECTION_SEALED_EVALUATION_HOLD",
        "training_manifest_relative_path": "selection/training_manifest.sha256.json",
        "training_manifest_sha256": sha256(manifest_path.read_bytes()).hexdigest(),
        "training_manifest_file_count": 1,
        "completion_counts": counts,
    }
    seal_path = selection / "training_selection.sealed.json"
    _write_json(seal_path, seal)
    audit = {
        "schema_version": "tukf09_training_selection_independent_audit_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "TRAINING_SELECTION_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD",
        "mismatch_count": 0,
        "formal_evaluation_authorized": False,
        "training_selection_seal_sha256": sha256(seal_path.read_bytes()).hexdigest(),
        "training_manifest_sha256": sha256(manifest_path.read_bytes()).hexdigest(),
        "training_tree_file_count": 1,
        "training_tree_files_canonical_sha256": registration._canonical_sha256(files),
        "completion_counts": counts,
        "evaluation_access_ledger": dict(ZERO_LEDGER),
    }
    audit_path = independent / "independent_audit.json"
    _write_json(audit_path, audit)
    final = {
        "schema_version": "tukf09_training_selection_independent_final_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "TRAINING_SELECTION_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD",
        "file_count": 1,
        "files": {"independent_audit.json": _record(audit_path)},
        "source_training_selection_seal_sha256": sha256(seal_path.read_bytes()).hexdigest(),
        "formal_evaluation_authorized": False,
    }
    final_path = independent / "manifest.final.sha256.json"
    _write_json(final_path, final)
    documents = {
        "training_selection_seal": seal,
        "independent_training_selection_final_manifest": final,
    }
    records = {
        "training_selection_seal": {"path": str(seal_path), **_record(seal_path)},
        "independent_training_selection_final_manifest": {
            "path": str(final_path),
            **_record(final_path),
        },
        "training_admission": {"path": str(current_admission), **_record(current_admission)},
    }
    return documents, records, seal_path


def test_stale_independent_selection_or_changed_training_tree_is_rejected(tmp_path: Path) -> None:
    documents, records, seal_path = _selection_bundle(tmp_path)
    registration._validate_independent_training_selection_bundle(documents, records)
    changed = dict(documents["training_selection_seal"])
    changed["status"] = "TRAINING_SELECTION_SEALED_EVALUATION_HOLD_NEW"
    _write_json(seal_path, changed)
    documents["training_selection_seal"] = changed
    records["training_selection_seal"] = {"path": str(seal_path), **_record(seal_path)}
    with pytest.raises(RuntimeError, match="stale|inconsistent"):
        registration._validate_independent_training_selection_bundle(documents, records)


def test_reparse_component_gate_precedes_registration_file_read(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    source = tmp_path / "source.json"
    source.write_text("{}", encoding="utf-8")
    monkeypatch.setattr(
        training_common,
        "ensure_no_symlink_components",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(ValueError("linked path is forbidden")),
    )
    with pytest.raises(ValueError, match="linked path"):
        registration._require_file(source, label="synthetic reparse source")


def test_admission_fixed_path_escape_stops_before_pytest_or_evidence_write(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    escaped_name = f"escaped-{tmp_path.name}"
    config_path = tmp_path / (
        "configs/tukf09_455_basin_zero_validation_target_variance_formal_evaluation_v1.json"
    )
    payload = {
        "paths": {
            "results_root": "results/tukf09_455_basin_zero_validation_target_variance_revision_v1",
            "formal_evaluation": "results/tukf09_455_basin_zero_validation_target_variance_revision_v1/evaluation",
            "evaluation_summary": "results/tukf09_455_basin_zero_validation_target_variance_revision_v1/evaluation/evaluation_summary.json",
            "independent_evaluation": "results/tukf09_455_basin_zero_validation_target_variance_revision_v1/evaluation_independent",
            "authorization": f"../{escaped_name}/authorization.json",
            "admission": f"../{escaped_name}/admission.json",
        }
    }
    _write_json(config_path, payload)
    called = False

    def forbidden_tests(_root: Path) -> dict[str, Any]:
        nonlocal called
        called = True
        raise AssertionError("pytest must not run for a path-escaped configuration")

    monkeypatch.setattr(admission, "_evaluation_test_evidence", forbidden_tests)
    with pytest.raises(RuntimeError, match="fixed formal evaluation output paths"):
        admission.admit_formal_evaluation_from_fixed_artifacts(
            authorize=True, project_root=tmp_path
        )
    assert called is False
    assert not (tmp_path.parent / escaped_name).exists()


def test_registration_and_admission_reparse_precheck_has_zero_write_side_effect(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(
        training_common,
        "ensure_no_symlink_components",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(ValueError("junction rejected")),
    )
    targets = (
        (registration._atomic_write_exclusive, tmp_path / "register-out" / "record.json"),
        (admission._atomic_write_exclusive, tmp_path / "admit-out" / "record.json"),
    )
    for writer, target in targets:
        with pytest.raises(ValueError, match="junction rejected"):
            writer(target, b"{}\n")
        assert not target.parent.exists()
