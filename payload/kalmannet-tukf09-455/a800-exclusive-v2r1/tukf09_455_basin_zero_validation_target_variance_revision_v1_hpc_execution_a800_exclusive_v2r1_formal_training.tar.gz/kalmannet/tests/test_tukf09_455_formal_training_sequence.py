from __future__ import annotations

from contextlib import nullcontext
import json
import os
from pathlib import Path
from types import SimpleNamespace

import pytest

from scripts import run_tukf09_455_formal_training_sequence as sequence
from scripts import verify_tukf09_455_filter_rebinding_controller as rebinding
from scripts import tukf09_455_training_common as training_common
from scripts import tukf09_455_training_controller_common as controller_common


ADMISSION_SHA256 = "a" * 64
FILTER_SHA256 = "b" * 64
NEURAL_SHA256 = "c" * 64


def test_rebinding_controller_gate_precedes_every_read(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def forbidden(*_args, **_kwargs):
        raise AssertionError("authorization gate must precede reads")

    monkeypatch.setattr(Path, "read_bytes", forbidden)
    with pytest.raises(PermissionError, match="explicit"):
        rebinding.run_filter_rebinding_verification(
            execute_formal_training=False,
            production=False,
        )


def test_rebinding_controller_reports_only_verified_installed_units() -> None:
    admission = {"training_admission_record_sha256": ADMISSION_SHA256}
    result = rebinding.run_filter_rebinding_verification(
        execute_formal_training=True,
        production=False,
        training_admission_verifier=lambda *_args: admission,
        initialized_root_verifier=lambda **_kwargs: {"status": "initialized"},
        preflight_verifier=lambda *_args, **_kwargs: SimpleNamespace(
            evaluation_access_count=0
        ),
        installation_verifier=lambda **_kwargs: {
            "status": "FILTER_REBINDING_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD",
            "unit_count": 455,
            "new_filter_optimization_count": 0,
            "evaluation_access_count": 0,
        },
    )
    assert result == {
        "schema_version": "tukf09_455_filter_rebinding_controller_result_v1",
        "experiment_id": sequence.EXPERIMENT_ID,
        "status": "FILTER_REBINDING_VERIFIED_EVALUATION_HOLD",
        "canonical_unit_count": 455,
        "completed_unit_count": 455,
        "training_admission_record_sha256": ADMISSION_SHA256,
        "evaluation_access_count": 0,
    }


def _make_fixed_tree(tmp_path: Path) -> sequence.FixedPaths:
    paths = sequence.fixed_paths(tmp_path)
    files = (
        paths.config,
        paths.authorization,
        paths.training_admission,
        paths.execution_config,
        paths.filter_controller,
        paths.neural_controller,
        paths.preflight_root / "independent" / "manifest.final.sha256.json",
    )
    for index, path in enumerate(files):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(f"source-{index}\n", encoding="utf-8")
    paths.output_root.mkdir(parents=True)
    return paths


def _execution(_path: Path) -> dict:
    return {
        "controller_order": {"training_stages": ["verify_filter_rebinding", "neural"]},
        "resource_policy": {
            "execution_route": "local_sequential_controller",
            "prevent_system_sleep_while_controller_active": True,
        },
    }


def _admission(_paths: sequence.FixedPaths) -> dict:
    return {"training_admission_record_sha256": ADMISSION_SHA256}


def _sources(_paths: sequence.FixedPaths) -> dict[str, str]:
    return {"verify_filter_rebinding": FILTER_SHA256, "neural": NEURAL_SHA256}


def _root_verified(**_kwargs):
    return {"status": "TRAINING_ROOT_INITIALIZED_EVALUATION_HOLD"}


def _completion(stage: str, _path: Path, **_kwargs) -> dict:
    return {
        "status": (
            "FILTER_REBINDING_VERIFIED_EVALUATION_HOLD"
            if stage == "verify_filter_rebinding"
            else "NEURAL_TRAINING_COMPLETE_EVALUATION_HOLD"
        )
    }


class FakeProcess:
    def __init__(self, pid: int, return_code: int) -> None:
        self.pid = pid
        self.returncode = return_code
        self.terminated = False

    def wait(self, timeout=None):
        return self.returncode

    def poll(self):
        return self.returncode

    def terminate(self):
        self.terminated = True

    def kill(self):
        self.terminated = True


def _run(paths: sequence.FixedPaths, process_factory, **overrides):
    options = {
        "admission_verifier": _admission,
        "execution_loader": _execution,
        "source_hasher": _sources,
        "completion_verifier": _completion,
        "initialized_root_verifier": _root_verified,
        "sleep_prevention_factory": lambda enabled: nullcontext(),
    }
    options.update(overrides)
    return sequence.run_sequence(
        execute_formal_training=True,
        paths=paths,
        process_factory=process_factory,
        **options,
    )


def test_sequence_runs_filter_then_neural_with_only_fixed_child_arguments(tmp_path: Path):
    paths = _make_fixed_tree(tmp_path)
    calls = []

    def factory(command, **kwargs):
        calls.append((list(command), kwargs))
        return FakeProcess(8100 + len(calls), 0)

    result = _run(paths, factory)
    assert result["status"] == "FORMAL_TRAINING_COMPLETE_EVALUATION_HOLD"
    assert result["stage_order"] == ["verify_filter_rebinding", "neural"]
    assert [row["process_id"] for row in result["stages"]] == [8101, 8102]
    assert [Path(call[0][2]).name for call in calls] == [
        "verify_tukf09_455_filter_rebinding_controller.py",
        "run_tukf09_455_neural_training_controller.py",
    ]
    expected_flags = {
        "--config",
        "--preflight-root",
        "--authorization",
        "--training-admission",
        "--execution-config",
        "--output-root",
        "--execute-formal-training",
    }
    for command, kwargs in calls:
        assert {part for part in command if part.startswith("--")} == expected_flags
        assert len(command) == 16
        assert kwargs["stdin"] == sequence.subprocess.DEVNULL
    assert not (paths.output_root / "control" / ".sequence_controller.lock").exists()
    events = [json.loads(line) for line in (paths.control_root / "events.jsonl").read_text().splitlines()]
    assert [row["sequence"] for row in events] == list(range(1, len(events) + 1))
    assert [row["stage"] for row in events if row["event"] == "stage_started"] == [
        "verify_filter_rebinding",
        "neural",
    ]
    terminals = [row for row in events if row["event"] == "stage_completed"]
    assert [row["exit_code"] for row in terminals] == [0, 0]
    assert all(row["training_admission_record_sha256"] == ADMISSION_SHA256 for row in terminals)
    assert {row["execution_id"] for row in events} == {result["execution_id"]}


def test_filter_nonzero_stops_before_any_neural_launch(tmp_path: Path):
    paths = _make_fixed_tree(tmp_path)
    calls = []

    def factory(command, **_kwargs):
        calls.append(list(command))
        return FakeProcess(8201, 17)

    with pytest.raises(
        RuntimeError,
        match="verify_filter_rebinding controller failed with exit code 17",
    ):
        _run(paths, factory)
    assert len(calls) == 1
    assert Path(calls[0][2]).name == "verify_tukf09_455_filter_rebinding_controller.py"
    events = [json.loads(line) for line in (paths.control_root / "events.jsonl").read_text().splitlines()]
    assert any(row["event"] == "stage_failed" and row["exit_code"] == 17 for row in events)
    assert not any(row.get("stage") == "neural" for row in events)


def test_existing_selection_stops_before_logs_or_child_and_preserves_all_bytes(tmp_path: Path):
    paths = _make_fixed_tree(tmp_path)
    selection_root = paths.output_root / "selection"
    selection_root.mkdir()
    (selection_root / "training_selection.sealed.json").write_bytes(b"sealed\n")
    before = {
        path.relative_to(paths.output_root).as_posix(): path.read_bytes()
        for path in paths.output_root.rglob("*")
        if path.is_file()
    }
    calls = []

    def factory(command, **_kwargs):
        calls.append(list(command))
        return FakeProcess(8250, 0)

    with pytest.raises(RuntimeError, match="after selection output exists"):
        _run(paths, factory)
    after = {
        path.relative_to(paths.output_root).as_posix(): path.read_bytes()
        for path in paths.output_root.rglob("*")
        if path.is_file()
    }
    assert calls == []
    assert after == before
    assert not paths.logs_root.exists()
    assert not paths.control_root.exists()


def test_filter_launch_exception_stops_before_neural(tmp_path: Path):
    paths = _make_fixed_tree(tmp_path)
    calls = []

    def factory(command, **_kwargs):
        calls.append(list(command))
        raise OSError("injected launch failure")

    with pytest.raises(OSError, match="injected launch failure"):
        _run(paths, factory)
    assert len(calls) == 1
    events = [json.loads(line) for line in (paths.control_root / "events.jsonl").read_text().splitlines()]
    failed = [row for row in events if row["event"] == "stage_failed"]
    assert failed[0]["stage_process_id"] is None
    assert failed[0]["exit_code"] is None


def test_filter_completion_verification_failure_stops_neural(tmp_path: Path):
    paths = _make_fixed_tree(tmp_path)
    calls = []

    def factory(command, **_kwargs):
        calls.append(list(command))
        return FakeProcess(8301, 0)

    def reject_completion(*_args, **_kwargs):
        raise RuntimeError("injected completion mismatch")

    with pytest.raises(RuntimeError, match="injected completion mismatch"):
        _run(paths, factory, completion_verifier=reject_completion)
    assert len(calls) == 1
    events = [json.loads(line) for line in (paths.control_root / "events.jsonl").read_text().splitlines()]
    assert any(
        row["event"] == "stage_failed"
        and row["stage"] == "verify_filter_rebinding"
        and row["exit_code"] == 0
        for row in events
    )


def test_fixed_path_override_and_hard_link_are_rejected(tmp_path: Path):
    paths = _make_fixed_tree(tmp_path)
    changed = sequence.FixedPaths(
        **{**paths.__dict__, "output_root": tmp_path / "different-output"}
    )
    with pytest.raises(ValueError, match="output_root differs"):
        sequence.gate_fixed_paths(changed, paths)
    linked = paths.config.with_name("linked-config.json")
    paths.config.unlink()
    source = tmp_path / "source-config.json"
    source.write_text("same\n", encoding="utf-8")
    os.link(source, paths.config)
    with pytest.raises(FileNotFoundError, match="regular unlinked file"):
        sequence.gate_fixed_paths(paths, paths)


def test_sequence_lock_rejects_live_and_dead_residual_without_deleting(tmp_path: Path, monkeypatch):
    lock = tmp_path / "controller.lock"
    with sequence.SequenceLock(lock):
        with pytest.raises(RuntimeError, match="active"):
            with sequence.SequenceLock(lock):
                pass
    assert not lock.exists()

    lock.mkdir()
    owner = {
        "schema_version": "tukf09_formal_training_sequence_owner_v1",
        "experiment_id": sequence.EXPERIMENT_ID,
        "execution_id": "d" * 32,
        "process_id": 999999,
        "started_at_utc": "2026-08-11T00:00:00+00:00",
    }
    (lock / "owner.json").write_bytes(controller_common.canonical_json_bytes(owner))
    monkeypatch.setattr(sequence.SequenceLock, "_process_is_alive", staticmethod(lambda _pid: False))
    with pytest.raises(RuntimeError, match="manual global process audit"):
        with sequence.SequenceLock(lock):
            pass
    assert (lock / "owner.json").read_bytes() == controller_common.canonical_json_bytes(owner)


def test_phase_lock_rejects_live_and_dead_residual_without_deleting(tmp_path: Path):
    with controller_common.training_phase_lock(tmp_path, "verify_filter_rebinding"):
        with pytest.raises(RuntimeError, match="active"):
            with controller_common.training_phase_lock(
                tmp_path, "neural", pid_is_alive=lambda _pid: True
            ):
                pass
    lock = tmp_path / ".training_phase.lock"
    lock.mkdir()
    owner = {
        "schema_version": "tukf09_training_phase_owner_v1",
        "experiment_id": sequence.EXPERIMENT_ID,
        "role": "verify_filter_rebinding",
        "execution_id": "e" * 32,
        "process_id": 999999,
        "started_at_utc": "2026-08-11T00:00:00+00:00",
        "recovered_stale_lock": False,
    }
    (lock / "owner.json").write_bytes(controller_common.canonical_json_bytes(owner))
    with pytest.raises(RuntimeError, match="manual global process audit"):
        with controller_common.training_phase_lock(
            tmp_path, "neural", pid_is_alive=lambda _pid: False
        ):
            pass
    assert (lock / "owner.json").read_bytes() == controller_common.canonical_json_bytes(owner)


class _FakeKernel32:
    def __init__(self, *, handle, error=0, exit_code=259):
        self.handle = handle
        self.error = error
        self.exit_code = exit_code
        self.closed = []

    def get_last_error(self):
        return self.error

    def OpenProcess(self, *_args):
        return self.handle

    def GetExitCodeProcess(self, _handle, code):
        code.value = self.exit_code
        return 1

    def CloseHandle(self, handle):
        self.closed.append(handle)
        return 1


@pytest.mark.parametrize(
    ("kernel", "expected"),
    [
        (_FakeKernel32(handle=123, exit_code=259), True),
        (_FakeKernel32(handle=123, exit_code=0), False),
        (_FakeKernel32(handle=0, error=87), False),
        (_FakeKernel32(handle=0, error=5), True),
    ],
)
def test_windows_process_probe_is_read_only_and_conservative(kernel, expected):
    assert controller_common._windows_process_is_alive(12345, kernel32=kernel) is expected
    if kernel.handle:
        assert kernel.closed == [kernel.handle]


def test_process_probe_reports_self_and_nonexistent_pid_without_signalling():
    assert controller_common.process_is_alive(os.getpid()) is True
    assert controller_common.process_is_alive(2_000_000_000) is False


@pytest.mark.parametrize(
    ("stage", "mutation"),
    [
        ("verify_filter_rebinding", {"training_admission_record_sha256": "f" * 64}),
        ("verify_filter_rebinding", {"evaluation_access_count": 1}),
        ("neural", {"training_admission_record_sha256": "f" * 64}),
        ("neural", {"evaluation_access_count": 1}),
    ],
)
def test_stage_completion_rejects_admission_or_evaluation_mutation(
    tmp_path: Path, stage: str, mutation: dict
):
    if stage == "verify_filter_rebinding":
        result = {
            "schema_version": "tukf09_455_filter_rebinding_controller_result_v1",
            "experiment_id": sequence.EXPERIMENT_ID,
            "status": "FILTER_REBINDING_VERIFIED_EVALUATION_HOLD",
            "canonical_unit_count": 455,
            "completed_unit_count": 455,
            "training_admission_record_sha256": ADMISSION_SHA256,
            "evaluation_access_count": 0,
        }
    else:
        result = {
            "schema_version": "tukf09_neural_controller_result_v1",
            "experiment_id": sequence.EXPERIMENT_ID,
            "status": "NEURAL_TRAINING_COMPLETE_EVALUATION_HOLD",
            "unit_count": 9,
            "checkpoint_count": 270,
            "training_admission_record_sha256": ADMISSION_SHA256,
            "evaluation_access_count": 0,
        }
    result.update(mutation)
    path = tmp_path / "stdout.log"
    path.write_text(json.dumps(result) + "\n", encoding="utf-8")
    with pytest.raises(RuntimeError, match="exact successful completion"):
        sequence.verify_stage_completion_stdout(
            stage,
            path,
            offset=0,
            admission_record_sha256=ADMISSION_SHA256,
        )


def test_child_command_has_no_period_or_evaluation_surface(tmp_path: Path):
    paths = _make_fixed_tree(tmp_path)
    for stage in ("verify_filter_rebinding", "neural"):
        command = sequence.build_stage_command(stage, paths)
        lowered = " ".join(command).lower()
        assert "evaluation" not in lowered
        assert "period" not in lowered
