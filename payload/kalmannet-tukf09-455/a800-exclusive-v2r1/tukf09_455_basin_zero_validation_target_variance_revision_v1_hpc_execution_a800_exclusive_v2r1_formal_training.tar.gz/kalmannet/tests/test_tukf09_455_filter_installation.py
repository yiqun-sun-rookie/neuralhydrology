from __future__ import annotations

import hashlib
import json
import runpy
from pathlib import Path

import pytest

_MIGRATION_HELPERS = runpy.run_path(
    str(Path(__file__).with_name("test_tukf09_455_filter_migration.py"))
)
EXPERIMENT_ID = _MIGRATION_HELPERS["EXPERIMENT_ID"]
_json_bytes = _MIGRATION_HELPERS["_json_bytes"]
_make_source_unit = _MIGRATION_HELPERS["_make_source_unit"]
_write_candidate = _MIGRATION_HELPERS["_write_candidate"]


def _prepare_sealed_migration(tmp_path: Path) -> tuple[Path, list[str]]:
    from scripts.verify_tukf09_455_filter_migration import verify_filter_migration

    source = tmp_path / "source"
    _make_source_unit(source)
    candidate = tmp_path / "filter_migration_v1.pending.abc"
    final = _write_candidate(candidate, source)
    verify_filter_migration(
        candidate,
        authorize=True,
        publish=True,
        expected_unit_count=1,
        expected_checkpoint_count=256,
        expected_gradient_update_count=248,
    )
    return final, ["01022500"]


def _make_admission(path: Path, migration_root: Path) -> Path:
    final_manifest = migration_root / "independent" / "manifest.final.sha256.json"
    payload = {
        "schema_version": "tukf09_455_training_admission_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "NEURAL_TRAINING_ADMITTED_FILTER_REBINDING_INSTALLATION_PENDING_EVALUATION_HOLD",
        "migration_final_manifest": {
            "path": str(final_manifest.resolve()),
            "sha256": hashlib.sha256(final_manifest.read_bytes()).hexdigest(),
        },
        "population": {"ordered_basin_ids": ["01022500"], "ordered_basin_count": 1},
        "access_ledger": {
            "evaluation_array_reads": 0,
            "evaluation_predictions": 0,
            "evaluation_metrics": 0,
            "evaluation_outputs": 0,
        },
    }
    path.write_bytes(_json_bytes(payload))
    return path


def test_install_requires_authorization_before_read(monkeypatch: pytest.MonkeyPatch) -> None:
    from scripts.install_tukf09_455_filter_results import install_rebound_filters

    def forbidden(*args: object, **kwargs: object) -> bytes:
        raise AssertionError("authorization gate must run before reads")

    monkeypatch.setattr(Path, "read_bytes", forbidden)
    monkeypatch.setattr(Path, "read_text", forbidden)
    with pytest.raises(PermissionError):
        install_rebound_filters(authorize=False)


def test_installation_verifier_requires_authorization_before_read(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from scripts.verify_tukf09_455_filter_installation import (
        verify_filter_installation_independently,
    )

    def forbidden(*args: object, **kwargs: object) -> bytes:
        raise AssertionError("authorization gate must run before reads")

    monkeypatch.setattr(Path, "read_bytes", forbidden)
    with pytest.raises(PermissionError):
        verify_filter_installation_independently(
            migration_root=Path("missing"),
            results_root=Path("missing"),
            training_admission_path=Path("missing"),
            authorize=False,
            publish=False,
        )


def test_install_and_independent_seal_copy_exact_regular_files(tmp_path: Path) -> None:
    from scripts.install_tukf09_455_filter_results import install_rebound_filters
    from scripts.verify_tukf09_455_filter_installation import (
        verify_filter_installation_independently,
    )

    migration_root, basins = _prepare_sealed_migration(tmp_path)
    admission = _make_admission(tmp_path / "training_admission.json", migration_root)
    results = tmp_path / "results"
    results.mkdir()
    result = install_rebound_filters(
        migration_root=migration_root,
        results_root=results,
        training_admission_path=admission,
        authorize=True,
        expected_basin_ids=basins,
    )
    assert result["status"] == "FILTER_REBINDING_INSTALLED_455_EVALUATION_HOLD"
    source_unit = migration_root / "units" / "basin_01022500"
    installed = results / "filter" / "basin_01022500"
    assert {path.name for path in installed.iterdir()} == {path.name for path in source_unit.iterdir()}
    for source in source_unit.iterdir():
        target = installed / source.name
        assert target.read_bytes() == source.read_bytes()
        assert (target.stat().st_dev, target.stat().st_ino) != (
            source.stat().st_dev,
            source.stat().st_ino,
        )
        assert target.stat().st_nlink == 1
    verified = verify_filter_installation_independently(
        migration_root=migration_root,
        results_root=results,
        training_admission_path=admission,
        authorize=True,
        publish=True,
        expected_basin_ids=basins,
    )
    assert verified["status"] == "FILTER_REBINDING_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
    final = results / "control" / "filter_rebinding" / "independent" / "manifest.final.sha256.json"
    assert final.is_file()
    again = verify_filter_installation_independently(
        migration_root=migration_root,
        results_root=results,
        training_admission_path=admission,
        authorize=True,
        publish=False,
        expected_basin_ids=basins,
    )
    assert again["unit_count"] == 1


def test_production_population_defaults_require_exactly_455_basins() -> None:
    from scripts.install_tukf09_455_filter_results import _ordered_basins
    from scripts.verify_tukf09_455_filter_installation import _basins

    admission = {"population": {"ordered_basin_ids": ["01022500"]}}
    with pytest.raises(RuntimeError, match="455"):
        _ordered_basins(admission, Path("unused"), None)
    with pytest.raises(RuntimeError, match="455"):
        _basins(admission, Path("unused"), None)


@pytest.mark.parametrize("fail_after_write", [1, 2])
def test_independent_installation_seal_is_never_partially_visible(
    tmp_path: Path, fail_after_write: int
) -> None:
    from scripts.install_tukf09_455_filter_results import install_rebound_filters
    from scripts.verify_tukf09_455_filter_installation import (
        verify_filter_installation_independently,
    )

    migration_root, basins = _prepare_sealed_migration(tmp_path)
    admission = _make_admission(tmp_path / "training_admission.json", migration_root)
    results = tmp_path / "results"
    results.mkdir()
    install_rebound_filters(
        migration_root=migration_root,
        results_root=results,
        training_admission_path=admission,
        authorize=True,
        expected_basin_ids=basins,
    )
    with pytest.raises(RuntimeError, match="injected"):
        verify_filter_installation_independently(
            migration_root=migration_root,
            results_root=results,
            training_admission_path=admission,
            authorize=True,
            publish=True,
            expected_basin_ids=basins,
            fail_after_write=fail_after_write,
        )
    rebinding = results / "control" / "filter_rebinding"
    assert not (rebinding / "independent").exists()
    assert not list(rebinding.glob("independent.pending.*"))


def test_install_rejects_missing_or_changed_migration_seal(tmp_path: Path) -> None:
    from scripts.install_tukf09_455_filter_results import install_rebound_filters

    migration_root, basins = _prepare_sealed_migration(tmp_path)
    admission = _make_admission(tmp_path / "training_admission.json", migration_root)
    final_manifest = migration_root / "independent" / "manifest.final.sha256.json"
    with final_manifest.open("ab") as handle:
        handle.write(b"tamper")
    results = tmp_path / "results"
    (results / "control").mkdir(parents=True)
    with pytest.raises((RuntimeError, ValueError)):
        install_rebound_filters(
            migration_root=migration_root,
            results_root=results,
            training_admission_path=admission,
            authorize=True,
            expected_basin_ids=basins,
        )
    assert not (results / "filter" / "basin_01022500").exists()


def test_identical_partial_pending_unit_is_resumed(tmp_path: Path) -> None:
    from scripts.install_tukf09_455_filter_results import (
        installation_attempt_id,
        install_rebound_filters,
    )

    migration_root, basins = _prepare_sealed_migration(tmp_path)
    admission = _make_admission(tmp_path / "training_admission.json", migration_root)
    results = tmp_path / "results"
    (results / "control").mkdir(parents=True)
    attempt = installation_attempt_id(admission, migration_root)
    pending = results / "filter" / f"basin_01022500.pending.{attempt}"
    pending.mkdir(parents=True)
    source_identity = migration_root / "units" / "basin_01022500" / "identity.json"
    (pending / "identity.json").write_bytes(source_identity.read_bytes())
    result = install_rebound_filters(
        migration_root=migration_root,
        results_root=results,
        training_admission_path=admission,
        authorize=True,
        expected_basin_ids=basins,
    )
    assert result["installed_unit_count"] == 1
    assert not pending.exists()


def test_changed_installed_unit_fails_closed(tmp_path: Path) -> None:
    from scripts.install_tukf09_455_filter_results import install_rebound_filters
    from scripts.verify_tukf09_455_filter_installation import (
        verify_filter_installation_independently,
    )

    migration_root, basins = _prepare_sealed_migration(tmp_path)
    admission = _make_admission(tmp_path / "training_admission.json", migration_root)
    results = tmp_path / "results"
    (results / "control").mkdir(parents=True)
    install_rebound_filters(
        migration_root=migration_root,
        results_root=results,
        training_admission_path=admission,
        authorize=True,
        expected_basin_ids=basins,
    )
    target = results / "filter" / "basin_01022500" / "selection.json"
    with target.open("ab") as handle:
        handle.write(b"tamper")
    with pytest.raises((RuntimeError, ValueError)):
        verify_filter_installation_independently(
            migration_root=migration_root,
            results_root=results,
            training_admission_path=admission,
            authorize=True,
            publish=True,
            expected_basin_ids=basins,
        )


def test_changed_partial_pending_unit_fails_closed(tmp_path: Path) -> None:
    from scripts.install_tukf09_455_filter_results import (
        installation_attempt_id,
        install_rebound_filters,
    )

    migration_root, basins = _prepare_sealed_migration(tmp_path)
    admission = _make_admission(tmp_path / "training_admission.json", migration_root)
    results = tmp_path / "results"
    (results / "control").mkdir(parents=True)
    attempt = installation_attempt_id(admission, migration_root)
    pending = results / "filter" / f"basin_01022500.pending.{attempt}"
    pending.mkdir(parents=True)
    (pending / "identity.json").write_bytes(b"changed")
    with pytest.raises(RuntimeError, match="differs"):
        install_rebound_filters(
            migration_root=migration_root,
            results_root=results,
            training_admission_path=admission,
            authorize=True,
            expected_basin_ids=basins,
        )
    assert not (results / "filter" / "basin_01022500").exists()


def test_installation_verifier_does_not_import_installer() -> None:
    source = Path("scripts/verify_tukf09_455_filter_installation.py").read_text(encoding="utf-8")
    assert "install_tukf09_455_filter_results" not in source
