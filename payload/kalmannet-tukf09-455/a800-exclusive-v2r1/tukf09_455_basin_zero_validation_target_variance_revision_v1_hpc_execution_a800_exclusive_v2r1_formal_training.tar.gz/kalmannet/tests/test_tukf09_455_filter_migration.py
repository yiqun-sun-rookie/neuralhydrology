from __future__ import annotations

import hashlib
import io
import json
import os
from pathlib import Path

import numpy as np
import pytest


EXPERIMENT_ID = "TUKF09_455_BASIN_ZERO_VALIDATION_TARGET_VARIANCE_REVISION_V1"
SOURCE_EXPERIMENT_ID = "TUKF09_BACKPROPAGATION_VS_NEURAL_BACKWARD_TIME_CONFIRMATION_V1"
HEX_A = "a" * 64
HEX_B = "b" * 64
HEX_C = "c" * 64
HEX_D = "d" * 64


def _json_bytes(payload: object) -> bytes:
    return (
        json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
        + b"\n"
    )


def _record(content: bytes) -> dict[str, object]:
    return {"sha256": hashlib.sha256(content).hexdigest(), "size_bytes": len(content)}


def _make_source_unit(root: Path, basin: str = "01022500", dimension: int = 7) -> Path:
    from scripts.migrate_tukf09_455_filter_results import deterministic_npz_bytes

    unit = root / f"basin_{basin}"
    unit.mkdir(parents=True)
    theta = np.full((256, dimension + 1), -3.0, dtype=np.float64)
    theta[:, -1] = np.log(0.0025)
    training = np.arange(256, dtype=np.float64) + 1.0
    validation = np.arange(256, dtype=np.float64) + 2.0
    history = deterministic_npz_bytes(
        {
            "checkpoint_index": np.arange(256, dtype=np.int64),
            "start_index": np.tile(np.arange(8, dtype=np.int64), 32),
            "step_index": np.repeat(np.arange(32, dtype=np.int64), 8),
            "theta_log": theta,
            "training_objective": training,
            "validation_objective": validation,
        }
    )
    actual = np.exp(theta[0])
    identity = {
        "schema_version": "tukf09_filter_unit_identity_v1",
        "experiment_id": SOURCE_EXPERIMENT_ID,
        "unit_type": "filter_basin",
        "unit_id": basin,
        "state_dimension": dimension,
        "parameter_names": [
            "parTT", "parCFMAX", "parCFR", "parCWH", "parFC", "parBETA",
            "parLP", "parK0", "parK1", "parUZL", "parPERC", "parK2", "lag_time",
        ],
        "physical_parameter_sha256": HEX_A,
        "training_period_sha256": HEX_B,
        "validation_period_sha256": HEX_C,
        "initial_state": [0.0] * dimension,
        "initial_covariance_diagonal": 0.001,
        "base_observation_variance": 0.25,
        "precision": "float64",
        "torch_intraop_thread_count": 1,
        "torch_interop_thread_count": 1,
        "starts": 8,
        "updates_per_start": 31,
        "checkpoint_order": "round_robin_by_step_then_start",
        "runner_sha256": HEX_D,
        "contract_file_sha256": HEX_A,
        "preflight_final_manifest_sha256": HEX_B,
        "authorization_file_sha256": HEX_C,
        "training_admission_evaluation_access_count": 0,
        "training_admission_record_sha256": HEX_D,
    }
    selection = {
        "schema_version": "tukf09_filter_unit_selection_v1",
        "experiment_id": SOURCE_EXPERIMENT_ID,
        "unit_type": "filter_basin",
        "unit_id": basin,
        "status": "FILTER_BASIN_SELECTED",
        "selected_index": 0,
        "selected_theta_log": theta[0].tolist(),
        "selected_process_diagonal": actual[:-1].tolist(),
        "selected_r_b": float(actual[-1]),
        "selected_training_objective": 1.0,
        "selected_validation_objective": 2.0,
        "checkpoint_count": 256,
        "training_query_count": 256,
        "validation_query_count": 256,
        "filter_pass_count": 512,
        "gradient_update_count": 248,
        "scored_target_count_by_period_and_lead": {
            "training": {"1": 2190, "2": 2191, "3": 2192},
            "validation": {"1": 364, "2": 365, "3": 366},
        },
    }
    ledger = {
        "schema_version": "tukf09_filter_unit_access_ledger_v1",
        "experiment_id": SOURCE_EXPERIMENT_ID,
        "unit_type": "filter_basin",
        "unit_id": basin,
        "training_period_loaded": True,
        "validation_period_loaded": True,
        "evaluation_array_read_count": 0,
        "evaluation_prediction_count": 0,
        "evaluation_metric_count": 0,
        "evaluation_output_write_count": 0,
        "formal_evaluation_authorized": False,
    }
    members = {
        "identity.json": _json_bytes(identity),
        "history.npz": history,
        "selection.json": _json_bytes(selection),
        "access_ledger.json": _json_bytes(ledger),
    }
    for name, content in members.items():
        (unit / name).write_bytes(content)
    manifest = {
        "schema_version": "tukf09_filter_unit_manifest_v1",
        "experiment_id": SOURCE_EXPERIMENT_ID,
        "unit_type": "filter_basin",
        "unit_id": basin,
        "file_count": 4,
        "files": {name: _record(content) for name, content in sorted(members.items())},
    }
    (unit / "manifest.sha256.json").write_bytes(_json_bytes(manifest))
    return unit


def _rebound_kwargs() -> dict[str, str]:
    return {
        "scientific_contract_sha256": HEX_A,
        "preflight_final_manifest_sha256": HEX_B,
        "all_scope_authorization_sha256": HEX_C,
        "migration_config_sha256": HEX_D,
        "compatibility_projection_sha256": "e" * 64,
    }


def _replace_history(unit: Path, arrays: dict[str, np.ndarray]) -> None:
    destination = io.BytesIO()
    np.savez_compressed(destination, **arrays)
    content = destination.getvalue()
    (unit / "history.npz").write_bytes(content)
    manifest = json.loads((unit / "manifest.sha256.json").read_text())
    manifest["files"]["history.npz"] = _record(content)
    (unit / "manifest.sha256.json").write_bytes(_json_bytes(manifest))


def _write_candidate(candidate: Path, source_root: Path, basin: str = "01022500") -> Path:
    from scripts.migrate_tukf09_455_filter_results import (
        build_rebound_unit,
        recompute_parent_filter_unit,
    )

    verified = recompute_parent_filter_unit(source_root / f"basin_{basin}", basin)
    rebound = build_rebound_unit(verified, **_rebound_kwargs())
    unit = candidate / "units" / f"basin_{basin}"
    unit.mkdir(parents=True)
    for name, content in rebound.items():
        (unit / name).write_bytes(content)
    source_manifest = source_root / f"basin_{basin}" / "manifest.sha256.json"
    inventory = {
        "schema_version": "tukf09_455_filter_migration_source_inventory_v1",
        "experiment_id": EXPERIMENT_ID,
        "source_experiment_id": SOURCE_EXPERIMENT_ID,
        "ordered_basin_ids": [basin],
        "unit_count": 1,
        "source_filter_root": str(source_root.resolve()),
        "records": {
            basin: {
                "source_unit_relative_path": f"basin_{basin}",
                "source_unit_manifest_sha256": hashlib.sha256(source_manifest.read_bytes()).hexdigest(),
                "source_unit_manifest_size_bytes": source_manifest.stat().st_size,
            }
        },
    }
    final = candidate.parent / "filter_migration_v1"
    config = {
        "schema_version": "tukf09_455_filter_migration_execution_v1",
        "experiment_id": EXPERIMENT_ID,
        "source_experiment_id": SOURCE_EXPERIMENT_ID,
        "expected_unit_count": 1,
        "expected_checkpoint_count": 256,
        "expected_gradient_update_count": 248,
    }
    authorization = {
        "schema_version": "tukf09_455_all_scope_authorization_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "ALL_REQUESTED_PHASES_AUTHORIZED_SEQUENTIAL_ADMISSION_REQUIRED",
        "authorization_text": "全部授权",
        "scope": {
            "result_migration_authorized": True,
            "filter_result_rebinding_authorized": True,
            "new_filter_optimization_authorized": False,
            "neural_training_authorized": True,
            "formal_evaluation_authorized": True,
        },
        "required_phase_order": [
            "filter_migration",
            "filter_migration_independent_verification",
            "formal_training_admission",
            "formal_training_root_initialization",
            "filter_rebinding_installation",
            "filter_rebinding_independent_verification",
            "neural_training",
            "training_selection_seal",
            "training_selection_independent_verification",
            "formal_evaluation_authorization",
            "formal_evaluation_admission",
            "formal_evaluation",
            "formal_evaluation_independent_verification",
        ],
        "access_ledger": {
            "evaluation_array_reads": 0,
            "evaluation_predictions": 0,
            "evaluation_metrics": 0,
            "evaluation_outputs": 0,
        },
    }
    authorization["authorization_record_sha256"] = hashlib.sha256(
        _json_bytes(authorization)
    ).hexdigest()
    summary = {
        "schema_version": "tukf09_455_filter_migration_summary_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "FILTER_MIGRATION_CANDIDATE_455_COMPLETE_EVALUATION_HOLD",
        "final_root": str(final.resolve()),
        "source_filter_root": str(source_root.resolve()),
        "ordered_basin_ids": [basin],
        "unit_count": 1,
        "unit_file_count": 6,
        "inherited_checkpoint_count": 256,
        "inherited_training_objective_count": 256,
        "inherited_validation_objective_count": 256,
        "inherited_gradient_update_count": 248,
        "new_filter_optimization_count": 0,
        "evaluation_access_count": 0,
    }
    payloads = {
        "migration_config.snapshot.json": _json_bytes(config),
        "all_scope_authorization.snapshot.json": _json_bytes(authorization),
        "source_inventory.sha256.json": _json_bytes(inventory),
        "migration_summary.json": _json_bytes(summary),
    }
    candidate.mkdir(parents=True, exist_ok=True)
    for name, content in payloads.items():
        (candidate / name).write_bytes(content)
    files = {}
    for path in sorted(candidate.rglob("*")):
        if path.is_file():
            files[path.relative_to(candidate).as_posix()] = _record(path.read_bytes())
    manifest = {
        "schema_version": "tukf09_455_filter_migration_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "file_count": len(files),
        "files": files,
    }
    (candidate / "migration_manifest.sha256.json").write_bytes(_json_bytes(manifest))
    return final


def test_execute_requires_authorization_before_any_read(monkeypatch: pytest.MonkeyPatch) -> None:
    from scripts.migrate_tukf09_455_filter_results import execute_filter_migration

    def forbidden(*args: object, **kwargs: object) -> bytes:
        raise AssertionError("authorization gate must run before reads")

    monkeypatch.setattr(Path, "read_bytes", forbidden)
    monkeypatch.setattr(Path, "read_text", forbidden)
    with pytest.raises(PermissionError):
        execute_filter_migration(authorize=False)


def test_parent_recomputation_and_rebound_unit_are_exact(tmp_path: Path) -> None:
    from scripts.migrate_tukf09_455_filter_results import (
        build_rebound_unit,
        recompute_parent_filter_unit,
    )

    source = tmp_path / "source"
    unit = _make_source_unit(source)
    verified = recompute_parent_filter_unit(unit, "01022500")
    assert verified.selected_index == 0
    assert verified.checkpoint_count == 256
    assert verified.gradient_update_count == 248
    rebound = build_rebound_unit(verified, **_rebound_kwargs())
    assert set(rebound) == {
        "identity.json",
        "history.npz",
        "selection.json",
        "access_ledger.json",
        "migration_provenance.json",
        "manifest.sha256.json",
    }
    assert rebound["history.npz"] == (unit / "history.npz").read_bytes()
    selection = json.loads(rebound["selection.json"])
    identity = json.loads(rebound["identity.json"])
    ledger = json.loads(rebound["access_ledger.json"])
    assert selection["status"] == "FILTER_BASIN_REBOUND_FROM_VERIFIED_PARENT"
    assert selection["experiment_id"] == EXPERIMENT_ID
    assert identity["experiment_id"] == EXPERIMENT_ID
    assert ledger["evaluation_array_read_count"] == 0
    assert ledger["formal_evaluation_authorized"] is False


@pytest.mark.parametrize(
    ("expected", "message"),
    [
        ({"expected_state_dimension": 8}, "state dimension"),
        ({"expected_initial_state": [1.0] + [0.0] * 6}, "initial state"),
        ({"expected_base_observation_variance": 0.5}, "observation variance"),
    ],
)
def test_parent_recomputation_binds_independently_rebuilt_filter_context(
    tmp_path: Path, expected: dict[str, object], message: str
) -> None:
    from scripts.migrate_tukf09_455_filter_results import recompute_parent_filter_unit

    unit = _make_source_unit(tmp_path / "source")
    with pytest.raises(RuntimeError, match=message):
        recompute_parent_filter_unit(unit, "01022500", **expected)


def test_independent_reverification_binds_rebuilt_filter_context(tmp_path: Path) -> None:
    from scripts.migrate_tukf09_455_filter_results import (
        build_rebound_unit,
        recompute_parent_filter_unit,
    )
    from scripts.verify_tukf09_455_filter_migration import _verify_source_and_rebound

    source = _make_source_unit(tmp_path / "source")
    verified = recompute_parent_filter_unit(source, "01022500")
    rebound = tmp_path / "rebound"
    rebound.mkdir()
    for name, content in build_rebound_unit(verified, **_rebound_kwargs()).items():
        (rebound / name).write_bytes(content)
    inventory_record = {
        "source_unit_manifest_sha256": hashlib.sha256(
            (source / "manifest.sha256.json").read_bytes()
        ).hexdigest()
    }
    with pytest.raises(RuntimeError, match="initial state"):
        _verify_source_and_rebound(
            source,
            rebound,
            "01022500",
            inventory_record,
            expected_state_dimension=7,
            expected_initial_state=[1.0] + [0.0] * 6,
            expected_base_observation_variance=0.25,
        )


@pytest.mark.parametrize("target", ["history", "manifest", "ledger"])
def test_parent_recomputation_rejects_tampering(tmp_path: Path, target: str) -> None:
    from scripts.migrate_tukf09_455_filter_results import recompute_parent_filter_unit

    unit = _make_source_unit(tmp_path / "source")
    if target == "history":
        with (unit / "history.npz").open("ab") as handle:
            handle.write(b"x")
    elif target == "manifest":
        payload = json.loads((unit / "manifest.sha256.json").read_text())
        payload["file_count"] = 5
        (unit / "manifest.sha256.json").write_bytes(_json_bytes(payload))
    else:
        payload = json.loads((unit / "access_ledger.json").read_text())
        payload["evaluation_array_read_count"] = 1
        content = _json_bytes(payload)
        (unit / "access_ledger.json").write_bytes(content)
        manifest = json.loads((unit / "manifest.sha256.json").read_text())
        manifest["files"]["access_ledger.json"] = _record(content)
        (unit / "manifest.sha256.json").write_bytes(_json_bytes(manifest))
    with pytest.raises((RuntimeError, ValueError, PermissionError)):
        recompute_parent_filter_unit(unit, "01022500")


def test_source_inventory_requires_exact_population_and_exclusion(tmp_path: Path) -> None:
    from scripts.migrate_tukf09_455_filter_results import build_source_inventory

    source = tmp_path / "source"
    _make_source_unit(source, "01022500")
    _make_source_unit(source, "08202700")
    inventory = build_source_inventory(
        source,
        ["01022500"],
        source_population_ids=["01022500", "08202700"],
        production_verify=lambda path, basin: None,
    )
    assert inventory["unit_count"] == 1
    assert inventory["excluded_source_basins"] == ["08202700"]
    with pytest.raises(ValueError):
        build_source_inventory(
            source,
            ["01022500", "08202700"],
            source_population_ids=["01022500", "08202700"],
            production_verify=lambda path, basin: None,
        )
    with pytest.raises(ValueError):
        build_source_inventory(
            source,
            ["01022500", "01022500"],
            source_population_ids=["01022500", "08202700"],
            production_verify=lambda path, basin: None,
        )


def test_parent_recomputation_rejects_hard_link(tmp_path: Path) -> None:
    from scripts.migrate_tukf09_455_filter_results import recompute_parent_filter_unit

    unit = _make_source_unit(tmp_path / "source")
    original = unit / "history.npz"
    linked = tmp_path / "outside_history_link.npz"
    try:
        os.link(original, linked)
    except OSError:
        pytest.skip("hard links unavailable")
    assert original.stat().st_nlink > 1
    with pytest.raises(RuntimeError, match="hard link"):
        recompute_parent_filter_unit(unit, "01022500")


@pytest.mark.parametrize("failure", ["nonfinite", "dtype", "order", "shape"])
def test_parent_recomputation_rejects_invalid_history_contract(
    tmp_path: Path, failure: str
) -> None:
    from scripts.migrate_tukf09_455_filter_results import recompute_parent_filter_unit

    unit = _make_source_unit(tmp_path / "source")
    with np.load(unit / "history.npz", allow_pickle=False) as archive:
        arrays = {name: np.array(archive[name], copy=True) for name in archive.files}
    if failure == "nonfinite":
        arrays["theta_log"][0, 0] = np.nan
    elif failure == "dtype":
        arrays["checkpoint_index"] = arrays["checkpoint_index"].astype(np.int32)
    elif failure == "order":
        arrays["start_index"][[0, 1]] = arrays["start_index"][[1, 0]]
    else:
        arrays["theta_log"] = arrays["theta_log"][:-1]
    _replace_history(unit, arrays)
    with pytest.raises((RuntimeError, FloatingPointError)):
        recompute_parent_filter_unit(unit, "01022500")


def test_parent_recomputation_rejects_extra_member(tmp_path: Path) -> None:
    from scripts.migrate_tukf09_455_filter_results import recompute_parent_filter_unit

    unit = _make_source_unit(tmp_path / "source")
    (unit / "extra.json").write_bytes(b"{}\n")
    with pytest.raises(RuntimeError, match="missing or extra"):
        recompute_parent_filter_unit(unit, "01022500")


def test_independent_verifier_does_not_import_generator() -> None:
    source = Path("scripts/verify_tukf09_455_filter_migration.py").read_text(encoding="utf-8")
    assert "migrate_tukf09_455_filter_results" not in source


def test_independent_verifier_rejects_incomplete_authorization_scope() -> None:
    from scripts.verify_tukf09_455_filter_migration import (
        REQUIRED_PHASE_ORDER,
        _verify_authorization_record,
    )

    authorization = {
        "schema_version": "tukf09_455_all_scope_authorization_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "ALL_REQUESTED_PHASES_AUTHORIZED_SEQUENTIAL_ADMISSION_REQUIRED",
        "authorization_text": "全部授权",
        "scope": {},
        "required_phase_order": REQUIRED_PHASE_ORDER,
        "access_ledger": {
            "evaluation_array_reads": 0,
            "evaluation_predictions": 0,
            "evaluation_metrics": 0,
            "evaluation_outputs": 0,
        },
    }
    authorization["authorization_record_sha256"] = hashlib.sha256(
        _json_bytes(authorization)
    ).hexdigest()
    with pytest.raises(PermissionError, match="scope"):
        _verify_authorization_record(authorization)


def test_independent_verifier_seals_candidate_atomically(tmp_path: Path) -> None:
    from scripts.verify_tukf09_455_filter_migration import verify_filter_migration

    source = tmp_path / "source"
    _make_source_unit(source)
    candidate = tmp_path / "filter_migration_v1.pending.abc"
    final = _write_candidate(candidate, source)
    result = verify_filter_migration(
        candidate,
        authorize=True,
        publish=True,
        expected_unit_count=1,
        expected_checkpoint_count=256,
        expected_gradient_update_count=248,
    )
    assert result["status"] == "FILTER_MIGRATION_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
    assert final.is_dir()
    assert not candidate.exists()
    assert (final / "independent" / "manifest.final.sha256.json").is_file()
    verified = verify_filter_migration(
        final,
        authorize=True,
        publish=False,
        expected_unit_count=1,
        expected_checkpoint_count=256,
        expected_gradient_update_count=248,
    )
    assert verified["unit_count"] == 1


def test_independent_publish_resumes_a_presealed_candidate(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from scripts import verify_tukf09_455_filter_migration as verifier

    source = tmp_path / "source"
    _make_source_unit(source)
    candidate = tmp_path / "filter_migration_v1.pending.abc"
    final = _write_candidate(candidate, source)
    real_replace = verifier.os.replace
    monkeypatch.setattr(verifier.os, "replace", lambda source_path, final_path: None)
    verifier.verify_filter_migration(
        candidate,
        authorize=True,
        publish=True,
        expected_unit_count=1,
        expected_checkpoint_count=256,
        expected_gradient_update_count=248,
    )
    assert candidate.is_dir()
    assert (candidate / "independent" / "manifest.final.sha256.json").is_file()
    monkeypatch.setattr(verifier.os, "replace", real_replace)
    resumed = verifier.verify_filter_migration(
        candidate,
        authorize=True,
        publish=True,
        expected_unit_count=1,
        expected_checkpoint_count=256,
        expected_gradient_update_count=248,
    )
    assert resumed["migration_root"] == str(final)
    assert final.is_dir()
    assert not candidate.exists()


def test_verifier_failure_never_publishes_final(tmp_path: Path) -> None:
    from scripts.verify_tukf09_455_filter_migration import verify_filter_migration

    source = tmp_path / "source"
    _make_source_unit(source)
    candidate = tmp_path / "filter_migration_v1.pending.abc"
    final = _write_candidate(candidate, source)
    history = candidate / "units" / "basin_01022500" / "history.npz"
    with history.open("ab") as handle:
        handle.write(b"tamper")
    with pytest.raises((RuntimeError, ValueError)):
        verify_filter_migration(
            candidate,
            authorize=True,
            publish=True,
            expected_unit_count=1,
            expected_checkpoint_count=256,
            expected_gradient_update_count=248,
        )
    assert not final.exists()


@pytest.mark.parametrize("fail_after_write", [1, 2])
def test_independent_seal_write_failure_never_publishes_final(
    tmp_path: Path, fail_after_write: int
) -> None:
    from scripts.verify_tukf09_455_filter_migration import verify_filter_migration

    source = tmp_path / "source"
    _make_source_unit(source)
    candidate = tmp_path / "filter_migration_v1.pending.abc"
    final = _write_candidate(candidate, source)
    with pytest.raises(RuntimeError, match="injected"):
        verify_filter_migration(
            candidate,
            authorize=True,
            publish=True,
            expected_unit_count=1,
            expected_checkpoint_count=256,
            expected_gradient_update_count=248,
            fail_after_write=fail_after_write,
        )
    assert candidate.is_dir()
    assert not (candidate / "independent").exists()
    assert not final.exists()


def test_changed_source_between_snapshots_fails(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from scripts import verify_tukf09_455_filter_migration as verifier

    source = tmp_path / "source"
    _make_source_unit(source)
    candidate = tmp_path / "filter_migration_v1.pending.abc"
    final = _write_candidate(candidate, source)
    original = verifier._source_map
    calls = 0

    def changed(root: Path, basins: list[str]) -> dict[str, str]:
        nonlocal calls
        calls += 1
        result = original(root, basins)
        if calls > 1:
            result = dict(result)
            result[basins[0]] = "f" * 64
        return result

    monkeypatch.setattr(verifier, "_source_map", changed)
    with pytest.raises(RuntimeError, match="changed during"):
        verifier.verify_filter_migration(
            candidate,
            authorize=True,
            publish=True,
            expected_unit_count=1,
            expected_checkpoint_count=256,
            expected_gradient_update_count=248,
        )
    assert not final.exists()


def test_verify_existing_detects_final_seal_tampering(tmp_path: Path) -> None:
    from scripts.verify_tukf09_455_filter_migration import verify_filter_migration

    source = tmp_path / "source"
    _make_source_unit(source)
    candidate = tmp_path / "filter_migration_v1.pending.abc"
    final = _write_candidate(candidate, source)
    verify_filter_migration(
        candidate,
        authorize=True,
        publish=True,
        expected_unit_count=1,
        expected_checkpoint_count=256,
        expected_gradient_update_count=248,
    )
    with (final / "independent" / "independent_audit.json").open("ab") as handle:
        handle.write(b"tamper")
    with pytest.raises((RuntimeError, ValueError)):
        verify_filter_migration(
            final,
            authorize=True,
            publish=False,
            expected_unit_count=1,
            expected_checkpoint_count=256,
            expected_gradient_update_count=248,
        )
