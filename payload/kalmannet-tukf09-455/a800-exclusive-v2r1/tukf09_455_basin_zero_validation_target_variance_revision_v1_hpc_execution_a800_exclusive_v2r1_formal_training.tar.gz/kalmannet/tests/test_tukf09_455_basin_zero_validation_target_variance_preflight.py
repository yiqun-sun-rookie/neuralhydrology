"""Preflight-only gates for the post-discovery 455-basin revision.

These tests must not migrate results, train either forecast system, construct
evaluation arrays, generate predictions, or calculate evaluation metrics.
"""
from __future__ import annotations

import builtins
import hashlib
import importlib
import json
from pathlib import Path
import subprocess
import sys

import numpy as np
import pytest


ROOT = Path(__file__).resolve().parents[1]
EXPERIMENT_ID = "TUKF09_455_BASIN_ZERO_VALIDATION_TARGET_VARIANCE_REVISION_V1"
STEM = "tukf09_455_basin_zero_validation_target_variance_revision_v1"
CONFIG = ROOT / "configs" / f"{STEM}.json"
EXECUTION_CONFIG = (
    ROOT
    / "configs"
    / "tukf09_455_basin_zero_validation_target_variance_execution_v1.json"
)

EXPECTED_AUTHORIZATIONS = {
    "preflight": True,
    "independent_preflight": True,
    "result_migration": False,
    "filter_result_rebinding": False,
    "formal_training": False,
    "filter_training": False,
    "neural_training": False,
    "training_period_learning": False,
    "validation_checkpoint_selection": False,
    "training_selection_sealing": False,
    "independent_training_selection_verification": False,
    "formal_evaluation": False,
    "evaluation_prediction_generation": False,
    "evaluation_metric_computation": False,
    "independent_final_audit": False,
}

SOURCE_HASHES = {
    "scientific_contract": "0a3cdd0c0cfabccf971cc49821943c976e2a51dd01e79ec6f3f9279f993bac5d",
    "execution_config": "574ccbfc4b7cf6366a289b0b407de6f4cd79cffed2e7ae7a3aff768e3ec73bb3",
    "independent_preflight_final_manifest": "162049e28a1e470fc82385f98ab68698541da03304628f230ee4587359c90614",
    "formal_training_authorization": "1f4f04a67bb812bd15a6700fea029062a6bbb2db8c42486705a190b9a17ff464",
    "training_admission": "b521ebbb2d7b2f492d0a4a1d6876b25d06ae6c0da4826e5245dde21c72f367c6",
}


def _load_module(name: str):
    return importlib.import_module(name)


def _ordered_newline_sha256(values: list[str]) -> str:
    payload = b"".join(value.encode("ascii") + bytes([10]) for value in values)
    return hashlib.sha256(payload).hexdigest()


def test_contract_is_isolated_post_discovery_and_preflight_only():
    contract = json.loads(CONFIG.read_text(encoding="utf-8"))
    assert contract["experiment_id"] == EXPERIMENT_ID
    assert contract["analysis_identity"][
        "original_protocol_amended_after_validation_metric_undefined_discovery"
    ] is True
    assert contract["analysis_identity"][
        "revision_frozen_before_any_evaluation_prediction_or_metric"
    ] is True
    assert contract["analysis_identity"]["untouched_prospective_confirmation"] is False
    assert contract["population"]["primary_basin_count"] == 455
    assert contract["population"]["source_date_complete_basin_count"] == 456
    assert contract["population"]["validation_variance_exclusion_count"] == 1
    assert contract["population"]["validation_variance_excluded_basins"] == [
        "08202700"
    ]
    assert contract["population"]["eligible_ordered_newline_utf8_sha256"] == (
        "38987bce45fa38ff68f5b067db17e8cb3212d98fecdd106f57d268a130ee8fbd"
    )
    assert contract["population"]["eligible_compact_json_sha256"] == (
        "75ef2cee206fb15ee3f31ae0bbfcf594661c5ccdda0b28de9ff65634332c8902"
    )
    assert contract["authorizations"] == EXPECTED_AUTHORIZATIONS
    assert contract["paths"]["preflight_root"] == f"artifacts/{STEM}/preflight"
    assert contract["paths"]["future_results_root"] == f"results/{STEM}"


def test_execution_design_is_not_a_training_admission():
    execution = json.loads(EXECUTION_CONFIG.read_text(encoding="utf-8"))
    assert execution["experiment_id"] == EXPERIMENT_ID
    assert execution["status"] == "PREFLIGHT_ONLY_MIGRATION_TRAINING_EVALUATION_HOLD"
    assert execution["authorization_boundary"] == EXPECTED_AUTHORIZATIONS
    assert execution["atomic_units"]["filter"]["count"] == 455
    assert execution["atomic_units"]["neural"]["count"] == 9
    assert execution["completion_counts"]["filter_checkpoint_records"] == 116480
    assert execution["completion_counts"]["filter_gradient_updates"] == 112840
    assert execution["completion_counts"]["neural_checkpoints"] == 270
    assert execution["training_entrypoints_registered"] is False
    assert execution["formal_training_authorization_path"] is None
    assert execution["training_admission_path"] is None


def test_source_experiment_five_frozen_hashes_still_match():
    contract = json.loads(CONFIG.read_text(encoding="utf-8"))
    frozen = contract["parent_revision_provenance"]["frozen_files"]
    for name, expected in SOURCE_HASHES.items():
        record = frozen[name]
        path = ROOT / record["path"]
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected
        assert record["sha256"] == expected


def test_validation_denominator_accepts_varying_targets_and_rejects_constant():
    preflight = _load_module(
        "scripts.preflight_tukf09_455_basin_zero_validation_target_variance_revision"
    )
    varying = np.zeros(731, dtype=np.float64)
    varying[-1] = 1.0
    constant = np.zeros(731, dtype=np.float64)
    varying_record = preflight.validation_target_variance_record(varying)
    constant_record = preflight.validation_target_variance_record(constant)
    assert varying_record["validation_scoring_day_count"] == 366
    assert varying_record["validation_denominator"] > 0.0
    assert varying_record["metric_defined"] is True
    assert constant_record["validation_denominator"] == 0.0
    assert constant_record["metric_defined"] is False


def test_validation_denominator_rejects_nonfinite_or_wrong_length():
    preflight = _load_module(
        "scripts.preflight_tukf09_455_basin_zero_validation_target_variance_revision"
    )
    nonfinite = np.zeros(731, dtype=np.float64)
    nonfinite[-1] = np.nan
    with pytest.raises(ValueError, match="finite"):
        preflight.validation_target_variance_record(nonfinite)
    with pytest.raises(ValueError, match="731"):
        preflight.validation_target_variance_record(np.zeros(730, dtype=np.float64))


def test_uniform_population_rule_preserves_order_and_excludes_only_zero():
    preflight = _load_module(
        "scripts.preflight_tukf09_455_basin_zero_validation_target_variance_revision"
    )
    source = {
        "canonical": ["01000000", "08202700", "09000000"],
        "previously_evaluated": [],
        "candidates": ["01000000", "08202700", "09000000"],
        "eligible": ["01000000", "08202700", "09000000"],
        "date_incomplete": [],
        "missing_days_by_basin": {
            "01000000": 0,
            "08202700": 0,
            "09000000": 0,
        },
    }
    records = {
        "01000000": {"validation_denominator": 1.0, "metric_defined": True},
        "08202700": {"validation_denominator": 0.0, "metric_defined": False},
        "09000000": {"validation_denominator": 2.0, "metric_defined": True},
    }
    revised = preflight.derive_revised_population(source, records)
    assert revised["eligible"] == ["01000000", "09000000"]
    assert revised["validation_metric_defined"] == ["01000000", "09000000"]
    assert revised["validation_metric_undefined"] == ["08202700"]
    assert _ordered_newline_sha256(revised["eligible"]) == (
        revised["eligible_ordered_newline_utf8_sha256"]
    )


@pytest.mark.parametrize("module_name,function_name", [
    (
        "scripts.preflight_tukf09_455_basin_zero_validation_target_variance_revision",
        "execute_preflight",
    ),
    (
        "scripts.verify_tukf09_455_basin_zero_validation_target_variance_preflight",
        "verify_preflight",
    ),
])
def test_authorization_gate_precedes_every_read(monkeypatch, tmp_path, module_name, function_name):
    module = _load_module(module_name)

    def forbidden(*_args, **_kwargs):
        raise AssertionError("a read occurred before authorization")

    monkeypatch.setattr(builtins, "open", forbidden)
    monkeypatch.setattr(Path, "read_bytes", forbidden)
    monkeypatch.setattr(Path, "read_text", forbidden)
    function = getattr(module, function_name)
    with pytest.raises(PermissionError):
        function(
            CONFIG,
            EXECUTION_CONFIG,
            tmp_path / "preflight",
            authorize=False,
        )
    assert list(tmp_path.iterdir()) == []


def test_independent_verifier_does_not_import_preflight_generator():
    source = (
        ROOT
        / "scripts"
        / "verify_tukf09_455_basin_zero_validation_target_variance_preflight.py"
    ).read_text(encoding="utf-8")
    assert (
        "preflight_tukf09_455_basin_zero_validation_target_variance_revision"
        not in source
    )


def test_preflight_modules_do_not_import_parent_loader_at_module_import():
    modules = [
        "scripts.preflight_tukf09_455_basin_zero_validation_target_variance_revision",
        "scripts.verify_tukf09_455_basin_zero_validation_target_variance_preflight",
    ]
    for module_name in modules:
        statement = (
            "import sys; "
            f"import {module_name}; "
            "assert 'scripts.tukf09_training_common' not in sys.modules"
        )
        completed = subprocess.run(
            [sys.executable, "-B", "-c", statement],
            cwd=ROOT,
            check=False,
            capture_output=True,
            text=True,
        )
        assert completed.returncode == 0, completed.stderr


def test_generator_and_verifier_pin_complete_config_file_hashes():
    expected_contract = hashlib.sha256(CONFIG.read_bytes()).hexdigest()
    expected_execution = hashlib.sha256(EXECUTION_CONFIG.read_bytes()).hexdigest()
    for module_name in (
        "scripts.preflight_tukf09_455_basin_zero_validation_target_variance_revision",
        "scripts.verify_tukf09_455_basin_zero_validation_target_variance_preflight",
    ):
        module = _load_module(module_name)
        assert module.EXPECTED_CONTRACT_FILE_SHA256 == expected_contract
        assert module.EXPECTED_EXECUTION_FILE_SHA256 == expected_execution


def test_independent_atomic_publication_allows_only_its_own_pending_directory(tmp_path):
    verifier = _load_module(
        "scripts.verify_tukf09_455_basin_zero_validation_target_variance_preflight"
    )
    preflight_root = tmp_path / "preflight"
    preflight_root.mkdir()
    for member in verifier.PREFLIGHT_MEMBERS:
        (preflight_root / member).write_bytes(member.encode("utf-8"))
    fixed_records = verifier._capture_preflight_records(preflight_root)
    audit = {"status": "REPRODUCIBLE_PREFLIGHT_ONLY"}
    final_manifest = verifier._publish_independent_seal(
        preflight_root, audit, fixed_records
    )
    assert final_manifest["file_count"] == 11
    assert (preflight_root / "independent" / "independent_audit.json").is_file()
    assert not list(preflight_root.glob(".independent.pending-*"))
