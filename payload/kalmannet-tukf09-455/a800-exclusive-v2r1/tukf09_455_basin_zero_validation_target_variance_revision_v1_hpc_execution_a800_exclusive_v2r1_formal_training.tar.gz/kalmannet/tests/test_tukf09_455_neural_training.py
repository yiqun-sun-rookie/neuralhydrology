from __future__ import annotations

import copy
import hashlib
import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace

import numpy as np
import pytest
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import scripts.run_tukf09_455_neural_training as neural  # noqa: E402
from scripts.tukf07_information_matched_model import (  # noqa: E402
    DirectAutoregressiveLSTM,
)


def _dates(day_count: int, start: str = "2001-01-01") -> np.ndarray:
    return np.arange(
        np.datetime64(start, "D"),
        np.datetime64(start, "D") + np.timedelta64(day_count, "D"),
        dtype="datetime64[D]",
    ).astype("datetime64[ns]").view(np.int64)


def _period(day_count: int, offset: float) -> neural.PeriodArrays:
    index = np.arange(day_count, dtype=np.float64)
    forcing = np.stack(
        [index + offset, 2.0 * index - offset, np.square(index + 1.0) + offset],
        axis=-1,
    )
    observations = index + 1.0 + offset
    return neural.PeriodArrays(_dates(day_count), forcing, observations)


@pytest.fixture
def small_spec() -> neural.DatasetSpec:
    return neural.DatasetSpec(
        basin_count=2,
        sequence_length=3,
        first_target_index=3,
        training_day_count=6,
        validation_day_count=5,
        expected_training_samples=6,
        expected_validation_samples=4,
    )


@pytest.fixture
def small_periods() -> dict[str, dict[str, neural.PeriodArrays]]:
    return {
        "00000001": {"training": _period(6, 0.0), "validation": _period(5, 10.0)},
        "00000002": {"training": _period(6, 2.0), "validation": _period(5, 20.0)},
    }


def test_frozen_population_has_exact_training_and_validation_sample_counts():
    assert neural.expected_sample_count(
        basin_count=455, day_count=2557, first_target_index=365
    ) == 997_360
    assert neural.expected_sample_count(
        basin_count=455, day_count=731, first_target_index=365
    ) == 166_530


def test_contract_maps_to_the_frozen_dynamic_dataset_spec():
    contract = neural._json_load(
        ROOT / "configs" / "tukf09_455_basin_zero_validation_target_variance_revision_v1.json"
    )
    spec = neural.dataset_spec_from_contract(contract)
    assert spec == neural.DatasetSpec(
        basin_count=455,
        sequence_length=365,
        first_target_index=365,
        training_day_count=2557,
        validation_day_count=731,
        expected_training_samples=997_360,
        expected_validation_samples=166_530,
        training_start_ns=neural._iso_ns("1999-10-01"),
        training_end_ns=neural._iso_ns("2006-09-30"),
        validation_start_ns=neural._iso_ns("2006-10-01"),
        validation_end_ns=neural._iso_ns("2008-09-30"),
    )


def test_period_validation_rejects_any_third_period_before_array_access(
    small_spec,
    small_periods,
):
    supplied = copy.deepcopy(small_periods)
    supplied["00000001"]["evaluation"] = object()
    with pytest.raises(ValueError, match="training and validation periods only"):
        neural.validate_training_validation_periods(
            supplied, ("00000001", "00000002"), small_spec
        )


@pytest.mark.parametrize("lead_days", [1, 2, 3])
def test_causal_window_never_reads_discharge_after_origin(lead_days):
    forcing = np.arange(30, dtype=np.float64).reshape(10, 3)
    observations = np.arange(10, dtype=np.float64)
    window = neural.build_causal_window(
        forcing,
        observations,
        target_index=5,
        lead_days=lead_days,
        sequence_length=4,
    )
    np.testing.assert_array_equal(window.forcing_indices, np.arange(2, 6))
    expected = np.arange(2, 6) - lead_days
    expected = np.where(expected < 0, -1, expected)
    np.testing.assert_array_equal(window.discharge_source_indices, expected)
    assert window.origin_index == 5 - lead_days
    assert np.all(
        window.discharge_source_indices[window.discharge_source_indices >= 0]
        <= window.origin_index
    )


def test_dynamic_dataset_uses_arithmetic_indexing_without_sample_table(
    small_spec,
    small_periods,
):
    basin_ids = ("00000001", "00000002")
    periods = neural.validate_training_validation_periods(
        small_periods, basin_ids, small_spec
    )
    scaler = neural.fit_training_scaler(periods, basin_ids)
    dataset = neural.TUKF09NeuralWindowDataset(
        periods,
        basin_ids,
        scaler,
        period_name="training",
        lead_days=2,
        spec=small_spec,
    )
    assert len(dataset) == 6
    assert not hasattr(dataset, "sample_indices")
    first = dataset[0]
    fourth = dataset[3]
    assert (first["basin_id"], first["target_index"], first["origin_index"]) == (
        "00000001",
        3,
        1,
    )
    assert (fourth["basin_id"], fourth["target_index"]) == ("00000002", 3)
    assert torch.isnan(first["lagged_discharge"][0, 0])


def test_training_scaler_is_unchanged_when_validation_values_change(
    small_spec,
    small_periods,
):
    basin_ids = ("00000001", "00000002")
    first = neural.validate_training_validation_periods(
        small_periods, basin_ids, small_spec
    )
    changed = copy.deepcopy(small_periods)
    for basin in basin_ids:
        original = changed[basin]["validation"]
        changed[basin]["validation"] = neural.PeriodArrays(
            original.dates_ns,
            original.forcing + 1_000_000.0,
            original.observations + 1_000_000.0,
        )
    second = neural.validate_training_validation_periods(changed, basin_ids, small_spec)
    scaler_a = neural.fit_training_scaler(first, basin_ids)
    scaler_b = neural.fit_training_scaler(second, basin_ids)
    assert neural.training_scaler_payload(scaler_a) == neural.training_scaler_payload(
        scaler_b
    )


def test_target_noise_matches_the_frozen_cpu_generator_oracle():
    target = torch.tensor([[1.0], [-0.25], [0.5]], dtype=torch.float32)
    actual_generator = torch.Generator(device="cpu").manual_seed(100)
    oracle_generator = torch.Generator(device="cpu").manual_seed(100)
    oracle_noise = torch.randn(
        tuple(target.shape), dtype=target.dtype, generator=oracle_generator
    )
    expected = target + (target + 2.0 / 4.0) * (oracle_noise * 0.005)
    actual = neural.apply_target_noise(
        target,
        discharge_center=2.0,
        discharge_scale=4.0,
        generator=actual_generator,
    )
    torch.testing.assert_close(actual, expected, rtol=0.0, atol=0.0)


def test_basin_balanced_loss_matches_the_frozen_equation():
    prediction = torch.tensor([[2.0], [4.0]], dtype=torch.float32)
    target = torch.tensor([[1.0], [2.0]], dtype=torch.float32)
    basin_std = torch.tensor([[0.9], [1.9]], dtype=torch.float32)
    expected = torch.mean(torch.square(prediction - target) / torch.square(basin_std + 0.1))
    actual = neural.basin_balanced_nse_loss(prediction, target, basin_std)
    torch.testing.assert_close(actual, expected, rtol=0.0, atol=0.0)


def test_seed_controls_reproduce_the_exact_initial_model_state():
    neural.set_global_seed(2)
    first = DirectAutoregressiveLSTM(lead_days=1)
    first_state = {name: value.detach().clone() for name, value in first.state_dict().items()}
    neural.set_global_seed(2)
    second = DirectAutoregressiveLSTM(lead_days=1)
    for name, value in second.state_dict().items():
        torch.testing.assert_close(value, first_state[name], rtol=0.0, atol=0.0)


def test_direct_model_uses_prediction_from_lead_steps_earlier_for_missing_lag():
    neural.set_global_seed(0)
    model = DirectAutoregressiveLSTM(lead_days=2)
    with torch.no_grad():
        model.head.weight.zero_()
        model.head.bias.fill_(2.0)
    captured: list[torch.Tensor] = []

    def capture_input(_module, arguments):
        captured.append(arguments[0].detach().clone())

    hook = model.cell.register_forward_pre_hook(capture_input)
    forcing = torch.zeros((1, 4, 3), dtype=torch.float32)
    lagged = torch.zeros((1, 4, 1), dtype=torch.float32)
    lagged[0, 2, 0] = torch.nan
    result = model(forcing, lagged)
    hook.remove()
    assert result["autoregressive_flags"][0, 2, 0].item() == 1.0
    assert captured[2][0, 0, 3].item() == pytest.approx(2.0)


def test_tensorfloat32_is_disabled_and_verified():
    state = neural.configure_float32_device_arithmetic()
    assert state == {
        "cuda_matrix_multiplication_tensorfloat32": False,
        "cudnn_tensorfloat32": False,
    }


def test_formal_training_device_is_exactly_first_cuda_device():
    assert neural.require_formal_training_device(
        None,
        cuda_available=True,
        cuda_device_count=1,
    ) == torch.device("cuda:0")
    with pytest.raises(ValueError, match="exactly cuda:0"):
        neural.require_formal_training_device(
            "cpu",
            cuda_available=True,
            cuda_device_count=1,
        )
    with pytest.raises(RuntimeError, match="requires graphics processor"):
        neural.require_formal_training_device(
            "cuda:0",
            cuda_available=False,
            cuda_device_count=0,
        )


@pytest.mark.parametrize(
    ("epoch", "expected"),
    [(1, 0.001), (9, 0.001), (10, 0.0005), (24, 0.0005), (25, 0.0001), (30, 0.0001)],
)
def test_learning_rate_schedule_is_frozen(epoch, expected):
    assert neural.learning_rate_for_epoch(epoch) == expected


def test_checkpoint_selection_maximizes_455_basin_median_and_breaks_ties_early():
    history = np.zeros((30, 455), dtype=np.float64)
    history[4] = 0.75
    history[9] = 0.75
    history[20] = 0.70
    assert neural.select_validation_checkpoint(history) == 5


class _ValidationDataset(Dataset):
    def __init__(self) -> None:
        self.targets = [1.0, 2.0, 1.0, 2.0]

    def __len__(self) -> int:
        return len(self.targets)

    def __getitem__(self, index: int):
        return {
            "forcing": torch.zeros((2, 3), dtype=torch.float32),
            "lagged_discharge": torch.zeros((2, 1), dtype=torch.float32),
            "target_discharge_raw": torch.tensor(
                [self.targets[index]], dtype=torch.float32
            ),
        }


class _ConstantValidationModel(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.value = nn.Parameter(torch.tensor(0.0))

    def forward(self, forcing, lagged_discharge):
        batch, sequence = forcing.shape[:2]
        return {"y_hat": self.value.expand(batch, sequence, 1)}


def test_validation_changes_neither_parameters_nor_gradients():
    model = _ConstantValidationModel()
    model.value.grad = torch.tensor(3.0)
    parameter_before = model.value.detach().clone()
    gradient_before = model.value.grad.detach().clone()
    scaler = neural.TrainingScaler(
        basin_ids=("00000001", "00000002"),
        forcing_center=np.zeros(3),
        forcing_scale=np.ones(3),
        discharge_center=0.0,
        discharge_scale=1.0,
        per_basin_discharge_std=np.ones(2),
        training_row_count=2,
    )
    scores = neural._run_validation(
        model=model,
        loader=DataLoader(_ValidationDataset(), batch_size=2, shuffle=False),
        scaler=scaler,
        device=torch.device("cpu"),
        basin_count=2,
        samples_per_basin=2,
    )
    assert scores.shape == (2,)
    torch.testing.assert_close(model.value.detach(), parameter_before)
    torch.testing.assert_close(model.value.grad, gradient_before)


def _create_synthetic_unit_members(directory: Path) -> None:
    for relative in neural._unit_member_names():
        path = directory / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes((relative + "\n").encode("utf-8"))


def _trusted_unit_fixture(
    tmp_path: Path,
    *,
    unit_id: str = "lead_1_seed_0",
    lead_days: int = 1,
    seed: int = 0,
) -> tuple[Path, dict, tuple[str, ...], str]:
    basin_ids = tuple(f"{index:08d}" for index in range(1, 456))
    basin_digest = hashlib.sha256(
        "".join(f"{value}\n" for value in basin_ids).encode("utf-8")
    ).hexdigest()
    scaler_sha256 = "b" * 64
    admission_sha256 = "a" * 64
    runner_path = ROOT / neural.NEURAL_RUNNER_RELATIVE_PATH
    model_path = ROOT / neural.FROZEN_MODEL_RELATIVE_PATH
    admission = {
        "training_admission_record_sha256": admission_sha256,
        "population": {
            "ordered_basin_count": 455,
            "ordered_newline_sha256": basin_digest,
        },
        "executables": {
            neural.NEURAL_RUNNER_RELATIVE_PATH: {
                "sha256": neural.sha256_file(runner_path),
                "size_bytes": runner_path.stat().st_size,
            },
            neural.FROZEN_MODEL_RELATIVE_PATH: {
                "sha256": neural.sha256_file(model_path),
                "size_bytes": model_path.stat().st_size,
            },
        },
    }
    pending = tmp_path / "neural" / f"{unit_id}.pending-{os.getpid()}-{'8' * 32}"
    final = tmp_path / "neural" / unit_id
    pending.mkdir(parents=True)
    _create_synthetic_unit_members(pending)
    identity = {
        "schema_version": "tukf09_neural_unit_identity_v1",
        "experiment_id": neural.EXPERIMENT_ID,
        "unit_type": "neural_lead_seed",
        "unit_id": unit_id,
        "lead_days": lead_days,
        "seed": seed,
        "basin_count": 455,
        "ordered_basin_newline_sha256": basin_digest,
        "training_sample_count": neural.FROZEN_TRAINING_SAMPLES,
        "validation_sample_count": neural.FROZEN_VALIDATION_SAMPLES,
        "epochs": neural.FROZEN_EPOCHS,
        "batch_size": neural.FROZEN_BATCH_SIZE,
        "training_scaler_sha256": scaler_sha256,
        "runner_sha256": admission["executables"][neural.NEURAL_RUNNER_RELATIVE_PATH][
            "sha256"
        ],
        "frozen_model_source_sha256": admission["executables"][
            neural.FROZEN_MODEL_RELATIVE_PATH
        ]["sha256"],
        "torch_version": str(neural.torch.__version__),
        "device": "cuda:0",
        "tensorfloat32": False,
        "evaluation_access_count": 0,
        "admission_evidence": {
            "training_admission_record_sha256": admission_sha256,
        },
    }
    identity["identity_sha256"] = neural._canonical_json_sha256(identity)
    (pending / "identity.json").write_bytes(neural._canonical_json_bytes(identity))
    selection = {
        "unit_id": unit_id,
        "lead_days": lead_days,
        "seed": seed,
        "checkpoint_count": neural.FROZEN_EPOCHS,
        "evaluation_access_count": 0,
    }
    (pending / "model_selection.json").write_bytes(
        neural._canonical_json_bytes(selection)
    )
    access_ledger = {
        "schema_version": "tukf09_neural_access_ledger_v1",
        "experiment_id": neural.EXPERIMENT_ID,
        "unit_id": unit_id,
        "lead_days": lead_days,
        "training": {
            "sample_count": neural.FROZEN_TRAINING_SAMPLES,
            "first_target_index": neural.FROZEN_SEQUENCE_LENGTH,
            "last_target_index": neural.FROZEN_TRAINING_DAYS - 1,
            "maximum_discharge_source_offset_days": lead_days,
            "meteorological_forcing_through_target": True,
        },
        "validation": {
            "sample_count": neural.FROZEN_VALIDATION_SAMPLES,
            "first_target_index": neural.FROZEN_SEQUENCE_LENGTH,
            "last_target_index": neural.FROZEN_VALIDATION_DAYS - 1,
            "maximum_discharge_source_offset_days": lead_days,
            "meteorological_forcing_through_target": True,
        },
        "evaluation_access_count": 0,
        "evaluation_prediction_count": 0,
        "evaluation_metric_count": 0,
    }
    (pending / "access_ledger.json").write_bytes(
        neural._canonical_json_bytes(access_ledger)
    )
    neural.publish_complete_unit(pending, final, unit_id)
    return final, admission, basin_ids, scaler_sha256


def _rewrite_identity_and_reseal(
    unit: Path,
    mutate,
    *,
    recompute_identity_sha256: bool = True,
) -> None:
    identity_path = unit / "identity.json"
    identity = json.loads(identity_path.read_text(encoding="utf-8"))
    mutate(identity)
    if recompute_identity_sha256:
        identity.pop("identity_sha256", None)
        identity["identity_sha256"] = neural._canonical_json_sha256(identity)
    identity_path.write_bytes(neural._canonical_json_bytes(identity))
    manifest = neural._manifest_for_directory(unit, unit.name)
    (unit / "manifest.sha256.json").write_bytes(neural._canonical_json_bytes(manifest))


def test_production_reuse_accepts_only_a_source_and_admission_bound_identity(tmp_path):
    unit, admission, basin_ids, scaler_sha256 = _trusted_unit_fixture(tmp_path)
    manifest = neural.validate_reusable_complete_unit(
        unit,
        unit.name,
        training_admission_record=admission,
        ordered_basin_ids=basin_ids,
        training_scaler_sha256_value=scaler_sha256,
    )
    assert manifest["unit_id"] == "lead_1_seed_0"


@pytest.mark.parametrize(
    ("field", "replacement"),
    [
        ("unit_id", "lead_3_seed_2"),
        ("lead_days", 2),
        ("seed", 1),
        ("basin_count", 454),
        ("ordered_basin_newline_sha256", "c" * 64),
        ("training_sample_count", neural.FROZEN_TRAINING_SAMPLES - 1),
        ("validation_sample_count", neural.FROZEN_VALIDATION_SAMPLES - 1),
        ("training_scaler_sha256", "c" * 64),
        ("runner_sha256", "c" * 64),
        ("frozen_model_source_sha256", "c" * 64),
        ("evaluation_access_count", 1),
    ],
)
def test_production_reuse_rejects_resealed_identity_field_tampering(
    tmp_path,
    field,
    replacement,
):
    unit, admission, basin_ids, scaler_sha256 = _trusted_unit_fixture(tmp_path)
    _rewrite_identity_and_reseal(
        unit, lambda identity: identity.__setitem__(field, replacement)
    )
    with pytest.raises(RuntimeError):
        neural.validate_reusable_complete_unit(
            unit,
            unit.name,
            training_admission_record=admission,
            ordered_basin_ids=basin_ids,
            training_scaler_sha256_value=scaler_sha256,
        )


def test_production_reuse_rejects_resealed_training_admission_identity_tampering(tmp_path):
    unit, admission, basin_ids, scaler_sha256 = _trusted_unit_fixture(tmp_path)
    _rewrite_identity_and_reseal(
        unit,
        lambda identity: identity["admission_evidence"].__setitem__(
            "training_admission_record_sha256", "c" * 64
        ),
    )
    with pytest.raises(RuntimeError, match="admission identity differs"):
        neural.validate_reusable_complete_unit(
            unit,
            unit.name,
            training_admission_record=admission,
            ordered_basin_ids=basin_ids,
            training_scaler_sha256_value=scaler_sha256,
        )


def test_production_reuse_rejects_resealed_identity_hash_tampering(tmp_path):
    unit, admission, basin_ids, scaler_sha256 = _trusted_unit_fixture(tmp_path)
    _rewrite_identity_and_reseal(
        unit,
        lambda identity: identity.__setitem__("identity_sha256", "c" * 64),
        recompute_identity_sha256=False,
    )
    with pytest.raises(RuntimeError, match="identity hash does not match"):
        neural.validate_reusable_complete_unit(
            unit,
            unit.name,
            training_admission_record=admission,
            ordered_basin_ids=basin_ids,
            training_scaler_sha256_value=scaler_sha256,
        )


@pytest.mark.parametrize(
    ("relative_path", "identity_field"),
    [
        (neural.NEURAL_RUNNER_RELATIVE_PATH, "runner_sha256"),
        (neural.FROZEN_MODEL_RELATIVE_PATH, "frozen_model_source_sha256"),
    ],
)
def test_production_reuse_rejects_an_admission_resealed_to_a_noncurrent_source(
    tmp_path,
    relative_path,
    identity_field,
):
    unit, admission, basin_ids, scaler_sha256 = _trusted_unit_fixture(tmp_path)
    fake_sha256 = "c" * 64
    admission["executables"][relative_path]["sha256"] = fake_sha256
    _rewrite_identity_and_reseal(
        unit, lambda identity: identity.__setitem__(identity_field, fake_sha256)
    )
    with pytest.raises(RuntimeError, match="current source differs"):
        neural.validate_reusable_complete_unit(
            unit,
            unit.name,
            training_admission_record=admission,
            ordered_basin_ids=basin_ids,
            training_scaler_sha256_value=scaler_sha256,
        )


def test_production_reuse_rejects_resealed_evaluation_ledger_tampering(tmp_path):
    unit, admission, basin_ids, scaler_sha256 = _trusted_unit_fixture(tmp_path)
    ledger_path = unit / "access_ledger.json"
    ledger = json.loads(ledger_path.read_text(encoding="utf-8"))
    ledger["evaluation_prediction_count"] = 1
    ledger_path.write_bytes(neural._canonical_json_bytes(ledger))
    manifest = neural._manifest_for_directory(unit, unit.name)
    (unit / "manifest.sha256.json").write_bytes(neural._canonical_json_bytes(manifest))
    with pytest.raises(RuntimeError, match="records evaluation"):
        neural.validate_reusable_complete_unit(
            unit,
            unit.name,
            training_admission_record=admission,
            ordered_basin_ids=basin_ids,
            training_scaler_sha256_value=scaler_sha256,
        )


def test_unit_publication_is_one_atomic_directory_with_exact_34_member_manifest(tmp_path):
    final = tmp_path / "neural" / "lead_1_seed_0"
    pending = tmp_path / "neural" / f"lead_1_seed_0.pending-{os.getpid()}-{'a' * 32}"
    pending.mkdir(parents=True)
    _create_synthetic_unit_members(pending)
    result = neural.publish_complete_unit(pending, final, "lead_1_seed_0")
    assert result["reused"] is False
    assert not pending.exists()
    assert final.is_dir()
    manifest = neural.validate_complete_unit(final, "lead_1_seed_0")
    assert manifest["schema_version"] == "tukf09_neural_unit_manifest_v1"
    assert manifest["unit_type"] == "neural_lead_seed"
    assert manifest["unit_id"] == "lead_1_seed_0"
    assert manifest["file_count"] == 34
    assert len(manifest["files"]) == 34
    assert "manifest.sha256.json" not in manifest["files"]


def test_existing_unit_is_reused_only_when_its_exact_manifest_still_matches(tmp_path):
    final = tmp_path / "neural" / "lead_1_seed_0"
    pending = tmp_path / "neural" / f"lead_1_seed_0.pending-{os.getpid()}-{'b' * 32}"
    pending.mkdir(parents=True)
    _create_synthetic_unit_members(pending)
    neural.publish_complete_unit(pending, final, "lead_1_seed_0")
    reused = neural.publish_complete_unit(
        tmp_path / "does-not-exist", final, "lead_1_seed_0"
    )
    assert reused["reused"] is True
    (final / "identity.json").write_text("tampered", encoding="utf-8")
    with pytest.raises(RuntimeError, match="manifest differs"):
        neural.publish_complete_unit(
            tmp_path / "still-does-not-exist", final, "lead_1_seed_0"
        )


def test_complete_unit_rejects_a_semantically_equal_noncanonical_manifest(tmp_path):
    final = tmp_path / "neural" / "lead_1_seed_0"
    pending = tmp_path / "neural" / f"lead_1_seed_0.pending-{os.getpid()}-{'5' * 32}"
    pending.mkdir(parents=True)
    _create_synthetic_unit_members(pending)
    neural.publish_complete_unit(pending, final, "lead_1_seed_0")
    manifest_path = final / "manifest.sha256.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    with pytest.raises(RuntimeError, match="not canonical JSON"):
        neural.validate_complete_unit(final, "lead_1_seed_0")


def test_exact_manifest_rejects_an_extra_empty_directory(tmp_path):
    pending = tmp_path / "neural" / f"lead_1_seed_0.pending-{os.getpid()}-{'1' * 32}"
    pending.mkdir(parents=True)
    _create_synthetic_unit_members(pending)
    (pending / "extra-empty-directory").mkdir()
    with pytest.raises(RuntimeError, match="directory set differs"):
        neural.publish_complete_unit(
            pending,
            tmp_path / "neural" / "lead_1_seed_0",
            "lead_1_seed_0",
        )


def test_exact_manifest_rejects_a_multiply_linked_member(tmp_path):
    pending = tmp_path / "neural" / f"lead_1_seed_0.pending-{os.getpid()}-{'2' * 32}"
    pending.mkdir(parents=True)
    _create_synthetic_unit_members(pending)
    os.link(pending / "identity.json", tmp_path / "external-hard-link.json")
    with pytest.raises(RuntimeError, match="multiply-linked"):
        neural.publish_complete_unit(
            pending,
            tmp_path / "neural" / "lead_1_seed_0",
            "lead_1_seed_0",
        )


def test_publication_holds_if_a_final_unit_appears_while_pending_exists(tmp_path):
    final = tmp_path / "neural" / "lead_1_seed_0"
    first = tmp_path / "neural" / f"lead_1_seed_0.pending-{os.getpid()}-{'3' * 32}"
    first.mkdir(parents=True)
    _create_synthetic_unit_members(first)
    neural.publish_complete_unit(first, final, "lead_1_seed_0")
    competing = tmp_path / "neural" / f"lead_1_seed_0.pending-{os.getpid()}-{'4' * 32}"
    competing.mkdir()
    _create_synthetic_unit_members(competing)
    with pytest.raises(RuntimeError, match="appeared while this unit was pending"):
        neural.publish_complete_unit(competing, final, "lead_1_seed_0")
    assert competing.is_dir()


def test_incomplete_pending_directory_is_never_published(tmp_path):
    final = tmp_path / "neural" / "lead_1_seed_0"
    pending = tmp_path / "neural" / f"lead_1_seed_0.pending-{os.getpid()}-{'c' * 32}"
    pending.mkdir(parents=True)
    (pending / "identity.json").write_text("{}", encoding="utf-8")
    with pytest.raises(RuntimeError, match="directory set differs|member set differs"):
        neural.publish_complete_unit(pending, final, "lead_1_seed_0")
    assert not final.exists()


def test_execute_gate_runs_before_admission_or_data_loading(monkeypatch, tmp_path):
    called = False

    def forbidden(*_args, **_kwargs):
        nonlocal called
        called = True
        raise AssertionError("admission must not run")

    monkeypatch.setattr(neural, "_load_admission_context", forbidden)
    with pytest.raises(RuntimeError, match="explicit execution authorization"):
        neural.train_one_model(
            tmp_path / "config.json",
            tmp_path / "preflight",
            tmp_path / "authorization.json",
            tmp_path / "output",
            1,
            0,
            execute_formal_training=False,
        )
    assert called is False
    assert not (tmp_path / "output").exists()


def test_injected_neural_inputs_require_explicit_synthetic_test_mode(monkeypatch, tmp_path):
    called = False

    def forbidden(*_args, **_kwargs):
        nonlocal called
        called = True
        raise AssertionError("admission must not run for forbidden injection")

    monkeypatch.setattr(neural, "_load_verified_training_admission", forbidden)
    with pytest.raises(PermissionError, match="forbidden outside synthetic tests"):
        neural.train_one_model(
            tmp_path / "config.json",
            tmp_path / "preflight",
            tmp_path / "authorization.json",
            tmp_path / "output",
            1,
            0,
            execute_formal_training=True,
            periods_by_basin={},
            admission_context=SimpleNamespace(),
        )
    assert called is False


def test_synthetic_neural_inputs_cannot_target_the_formal_result_root(monkeypatch, tmp_path):
    output = tmp_path / "formal-output"
    monkeypatch.setattr(neural, "DEFAULT_OUTPUT_ROOT", output)
    with pytest.raises(PermissionError, match="formal result root forbids"):
        neural.train_one_model(
            tmp_path / "config.json",
            tmp_path / "preflight",
            tmp_path / "authorization.json",
            output,
            1,
            0,
            execute_formal_training=True,
            periods_by_basin={},
            admission_context=SimpleNamespace(),
            allow_synthetic_test_inputs=True,
        )


def test_failed_unit_removes_only_its_own_well_formed_pending_directory(
    monkeypatch,
    tmp_path,
):
    output = tmp_path / "output"
    neural_root = output / "neural"
    neural_root.mkdir(parents=True)
    token = "d" * 32

    def fail(*_args, **_kwargs):
        pending = neural_root / f"lead_1_seed_0.pending-{os.getpid()}-{token}"
        pending.mkdir()
        (pending / "identity.json").write_text("{}", encoding="utf-8")
        raise FloatingPointError("injected training failure")

    monkeypatch.setattr(neural, "_train_one_model_impl", fail)
    with pytest.raises(FloatingPointError, match="injected training failure"):
        neural.train_one_model(
            tmp_path / "config.json",
            tmp_path / "preflight",
            tmp_path / "authorization.json",
            output,
            1,
            0,
            execute_formal_training=True,
        )
    assert not (neural_root / f"lead_1_seed_0.pending-{os.getpid()}-{token}").exists()


def test_failed_unit_holds_when_pending_contains_an_unexpected_member(
    monkeypatch,
    tmp_path,
):
    output = tmp_path / "output"
    neural_root = output / "neural"
    neural_root.mkdir(parents=True)
    token = "e" * 32
    pending = neural_root / f"lead_1_seed_0.pending-{os.getpid()}-{token}"

    def fail(*_args, **_kwargs):
        pending.mkdir()
        (pending / "foreign.bin").write_bytes(b"foreign")
        raise FloatingPointError("injected training failure")

    monkeypatch.setattr(neural, "_train_one_model_impl", fail)
    with pytest.raises(RuntimeError, match="could not be safely removed"):
        neural.train_one_model(
            tmp_path / "config.json",
            tmp_path / "preflight",
            tmp_path / "authorization.json",
            output,
            1,
            0,
            execute_formal_training=True,
        )
    assert pending.is_dir()


def test_default_admission_loader_uses_training_validation_loader_only(monkeypatch, tmp_path):
    calls: list[tuple[str, object]] = []
    fake_context = SimpleNamespace(ordered_basin_ids=("00000001",))
    fake_periods = {"00000001": {"training": object(), "validation": object()}}

    def verify(*args, **kwargs):
        calls.append(("verify", kwargs))
        return fake_context

    def load(context):
        calls.append(("load", context))
        return fake_periods

    monkeypatch.setattr(
        "scripts.tukf09_455_training_common.verify_preflight_for_revision_training",
        verify,
    )
    monkeypatch.setattr(
        "scripts.tukf09_455_training_common.load_training_validation_periods_455",
        load,
    )
    context, _gate, periods = neural._load_admission_context(
        tmp_path / "config.json",
        tmp_path / "preflight",
        tmp_path / "authorization.json",
        tmp_path / "output",
    )
    assert context is fake_context
    assert periods is fake_periods
    assert calls[0][0] == "verify"
    assert calls[0][1]["recompute_training_validation_semantics"] is False
    assert calls[0][1]["verify_all_raw_source_bytes"] is False
    assert calls[1] == ("load", fake_context)


def test_training_admission_verifier_uses_the_complete_frozen_executable_set(
    monkeypatch,
    tmp_path,
):
    from scripts import tukf09_455_training_common as common

    captured = {}
    expected = {"training_admission_record_sha256": "a" * 64}

    def verify(path, execution_config, executables):
        captured["path"] = path
        captured["execution_config"] = execution_config
        captured["executables"] = tuple(executables)
        return expected

    monkeypatch.setattr(common, "load_and_verify_training_admission", verify)
    result = neural._load_verified_training_admission(
        tmp_path / "training_admission.json",
        tmp_path / "execution.json",
    )
    assert result is expected
    assert captured["path"] == tmp_path / "training_admission.json"
    assert captured["execution_config"] == tmp_path / "execution.json"
    assert captured["executables"] == tuple(
        neural.ROOT / relative
        for relative in common.REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS
    )


def test_production_runner_requires_the_initialized_training_root(
    monkeypatch,
    tmp_path,
):
    from scripts import tukf09_455_training_common as common

    output = tmp_path / common.OUTPUT_RELATIVE
    output.mkdir(parents=True)
    sources = {}
    for name in (
        "scientific_contract",
        "authorization",
        "execution_config",
        "training_admission",
    ):
        parent = tmp_path / "configs" if name == "execution_config" else tmp_path / "sources"
        parent.mkdir(parents=True, exist_ok=True)
        source = parent / f"{name}.json"
        source.write_text(f'{{"name":"{name}"}}\n', encoding="utf-8")
        sources[name] = source
    snapshot_sources = {
        "scientific_contract.snapshot.json": sources["scientific_contract"],
        "authorization.snapshot.json": sources["authorization"],
        "execution_config.snapshot.json": sources["execution_config"],
        "training_admission.snapshot.json": sources["training_admission"],
    }
    for relative, source in snapshot_sources.items():
        (output / relative).write_bytes(source.read_bytes())
    admission = {
        "scientific_contract_sha256": "a" * 64,
        "preflight_final_manifest_sha256": "b" * 64,
        "training_admission_record_sha256": "c" * 64,
        "authorization": {"file_sha256": "d" * 64},
        "evaluation_identity": {"identity_only_sha256": "e" * 64},
    }
    snapshot_records = {
        relative: {
            "sha256": common.sha256_file(source),
            "size_bytes": source.stat().st_size,
        }
        for relative, source in snapshot_sources.items()
    }
    context = {
        "schema_version": "tukf09_training_context_v1",
        "experiment_id": neural.EXPERIMENT_ID,
        "status": "TRAINING_ROOT_INITIALIZED_EVALUATION_HOLD",
        "formal_evaluation_authorized": False,
        "output_root": "results/tukf09_455_basin_zero_validation_target_variance_revision_v1",
        "scientific_contract_sha256": "a" * 64,
        "preflight_final_manifest_sha256": "b" * 64,
        "authorization_file_sha256": "d" * 64,
        "training_admission_record_sha256": "c" * 64,
        "evaluation_identity_only_sha256": "e" * 64,
        "access_ledger": {
            "evaluation_array_reads": 0,
            "evaluation_predictions": 0,
            "evaluation_metrics": 0,
            "evaluation_outputs": 0,
        },
        "initial_member_count": 5,
        "snapshots": snapshot_records,
    }
    (output / "training_context.json").write_bytes(neural._canonical_json_bytes(context))
    verified = neural._verify_initialized_training_root(
        output_root=output,
        config_path=sources["scientific_contract"],
        authorization=sources["authorization"],
        execution_config=sources["execution_config"],
        training_admission=sources["training_admission"],
        training_admission_record=admission,
    )
    assert verified == context
    (output / "authorization.snapshot.json").write_bytes(b"tampered")
    with pytest.raises(RuntimeError, match="snapshot differs"):
        neural._verify_initialized_training_root(
            output_root=output,
            config_path=sources["scientific_contract"],
            authorization=sources["authorization"],
            execution_config=sources["execution_config"],
            training_admission=sources["training_admission"],
            training_admission_record=admission,
        )


def test_identity_evidence_requires_and_records_training_admission_hash():
    context = SimpleNamespace(contract_sha256="b" * 64, authorization=None)
    evidence = neural._identity_evidence(
        context,
        {"training_admission_record_sha256": "c" * 64},
    )
    assert evidence["contract_sha256"] == "b" * 64
    assert evidence["training_admission_record_sha256"] == "c" * 64
    with pytest.raises(RuntimeError, match="lacks its record hash"):
        neural._identity_evidence(context, {})


def test_cli_surface_contains_no_period_or_prediction_argument():
    source = (ROOT / "scripts" / "run_tukf09_neural_training.py").read_text(
        encoding="utf-8"
    )
    for required in (
        "--config",
        "--preflight-root",
        "--authorization",
        "--training-admission",
        "--execution-config",
        "--output-root",
        "--lead-days",
        "--seed",
        "--execute-formal-training",
    ):
        assert required in source
    assert "add_argument(\"--evaluation" not in source
    assert "add_argument(\"--prediction" not in source


def test_production_runner_rejects_initialized_root_without_filter_installation_final(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    admission = {"training_admission_record_sha256": "a" * 64}
    monkeypatch.setattr(
        neural,
        "_load_verified_training_admission",
        lambda *_args, **_kwargs: admission,
    )
    monkeypatch.setattr(
        neural,
        "_verify_initialized_training_root",
        lambda **_kwargs: {"status": "initialized"},
    )

    def forbidden(*_args, **_kwargs):
        raise AssertionError("training data or model code ran before installation final gate")

    monkeypatch.setattr(neural, "_load_admission_context", forbidden)
    output = tmp_path / "initialized_result_root"
    output.mkdir()
    with pytest.raises(RuntimeError, match="installation final"):
        neural.train_one_model(
            tmp_path / "contract.json",
            tmp_path / "preflight",
            tmp_path / "authorization.json",
            output,
            1,
            0,
            execute_formal_training=True,
            training_admission=tmp_path / "training_admission.json",
            execution_config=tmp_path / "execution.json",
        )


def test_forged_neural_unit_stage_capability_is_rejected() -> None:
    forged = object.__new__(neural.NeuralUnitStageCapability)
    object.__setattr__(forged, "experiment_id", neural.EXPERIMENT_ID)
    object.__setattr__(forged, "sequence_execution_id", "1" * 32)
    object.__setattr__(forged, "sequence_process_id", os.getpid())
    object.__setattr__(forged, "neural_controller_process_id", os.getpid())
    object.__setattr__(forged, "unit_process_id", os.getpid())
    object.__setattr__(forged, "training_admission_record_sha256", "a" * 64)
    object.__setattr__(forged, "filter_installation_final_sha256", "b" * 64)
    object.__setattr__(forged, "_seal", object())
    with pytest.raises(PermissionError, match="capability"):
        neural.require_neural_unit_stage_capability(forged)
    assert not hasattr(neural, "_issue_neural_unit_stage_capability")


def test_direct_neural_unit_call_without_top_level_sequence_is_rejected(
    tmp_path: Path,
) -> None:
    with pytest.raises(PermissionError, match="top-level|sequence"):
        neural.verify_top_level_neural_unit_stage(
            output_root=tmp_path,
            training_admission_record_sha256="a" * 64,
            filter_installation_final_sha256="b" * 64,
        )
