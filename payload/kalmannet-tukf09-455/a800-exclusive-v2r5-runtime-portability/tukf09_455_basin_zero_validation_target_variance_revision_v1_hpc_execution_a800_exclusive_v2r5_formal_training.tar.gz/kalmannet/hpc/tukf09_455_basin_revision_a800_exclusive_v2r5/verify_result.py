"""Verify completed HPC formal training without loading formal-evaluation arrays."""
from __future__ import annotations

import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import sys
from typing import Any, Mapping, Sequence


ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
EXPERIMENT_ID = "TUKF09_455_BASIN_ZERO_VALIDATION_TARGET_VARIANCE_REVISION_V1"
EXPERIMENT_SLUG = "tukf09_455_basin_zero_validation_target_variance_revision_v1"
RESULTS_ROOT = ROOT / "results" / EXPERIMENT_SLUG
HPC_CONFIG = (
    ROOT
    / "configs"
    / "tukf09_455_basin_zero_validation_target_variance_hpc_execution_a800_exclusive_v2r5.json"
)
ORIGINAL_ADMISSION_RELATIVE = Path(
    "artifacts"
) / EXPERIMENT_SLUG / "training_admission/training_admission.json"
MIGRATION_ROOT_RELATIVE = Path("artifacts") / EXPERIMENT_SLUG / "filter_migration_v1"
REMOTE_FILTER_SEAL_RELATIVE = Path(
    "control/filter_rebinding/independent/manifest.final.sha256.json"
)
EXPECTED_UNITS = tuple(
    f"lead_{lead}_seed_{seed}" for lead in (1, 2, 3) for seed in (0, 1, 2)
)
EXPECTED_STAGES = ("verify_filter_rebinding", "neural")
FORBIDDEN_RESULT_MEMBERS = (
    "selection",
    "evaluation",
    "formal_evaluation",
    "evaluation_independent",
    "formal_evaluation_independent",
)
HEX64 = re.compile(r"^[0-9a-f]{64}$")
HEX32 = re.compile(r"^[0-9a-f]{32}$")


def canonical_json_bytes(value: Any) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
        + b"\n"
    )


def sha256_file(path: Path) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _reject_nonfinite(value: str) -> None:
    raise ValueError(f"non-finite JSON is forbidden: {value}")


def _reject_duplicate_keys(pairs: Sequence[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def _json_object(raw: bytes, *, label: str) -> dict[str, Any]:
    try:
        value = json.loads(
            raw.decode("utf-8"),
            object_pairs_hook=_reject_duplicate_keys,
            parse_constant=_reject_nonfinite,
        )
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        raise RuntimeError(f"invalid JSON evidence: {label}") from exc
    if not isinstance(value, dict):
        raise RuntimeError(f"JSON evidence is not an object: {label}")
    return value


def _is_link_or_reparse(path: Path) -> bool:
    candidate = Path(path)
    if candidate.is_symlink():
        return True
    status = os.lstat(candidate)
    attributes = int(getattr(status, "st_file_attributes", 0))
    return bool(attributes & int(getattr(status, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)))


def _require_directory(path: Path, *, label: str) -> Path:
    candidate = Path(os.path.abspath(os.fspath(path)))
    if not candidate.is_dir() or _is_link_or_reparse(candidate):
        raise RuntimeError(f"{label} is absent or linked: {candidate}")
    return candidate


def _require_file(path: Path, *, label: str, root: Path | None = None) -> Path:
    candidate = Path(os.path.abspath(os.fspath(path)))
    if root is not None:
        trusted = _require_directory(root, label=f"{label} root")
        try:
            relative = candidate.relative_to(trusted)
        except ValueError as exc:
            raise RuntimeError(f"{label} escapes its evidence root") from exc
        current = trusted
        for part in relative.parts:
            current = current / part
            if os.path.lexists(os.fspath(current)) and _is_link_or_reparse(current):
                raise RuntimeError(f"{label} contains a link or reparse point: {current}")
    if (
        not candidate.is_file()
        or _is_link_or_reparse(candidate)
        or int(candidate.stat().st_nlink) != 1
    ):
        raise RuntimeError(f"{label} is not a regular unlinked file: {candidate}")
    return candidate


def _read(
    path: Path,
    *,
    label: str,
    root: Path | None = None,
    canonical: bool = True,
) -> dict[str, Any]:
    source = _require_file(path, label=label, root=root)
    raw = source.read_bytes()
    value = _json_object(raw, label=label)
    if canonical and raw != canonical_json_bytes(value):
        raise RuntimeError(f"JSON evidence is not canonical: {label}")
    return value


def _payload_identity(payload: Mapping[str, Any]) -> str:
    unsigned = {key: value for key, value in payload.items() if key != "identity_sha256"}
    return sha256(canonical_json_bytes(unsigned)).hexdigest()


def _verify_payload_identity(payload: Mapping[str, Any], *, label: str) -> str:
    identity = payload.get("identity_sha256")
    if not isinstance(identity, str) or HEX64.fullmatch(identity) is None:
        raise RuntimeError(f"{label} lacks a valid identity SHA-256")
    if identity != _payload_identity(payload):
        raise RuntimeError(f"{label} identity SHA-256 changed")
    return identity


def _read_canonical_json_lines(path: Path, *, label: str) -> list[dict[str, Any]]:
    source = _require_file(path, label=label)
    raw = source.read_bytes()
    if not raw or not raw.endswith(b"\n"):
        raise RuntimeError(f"{label} is empty or truncated")
    records: list[dict[str, Any]] = []
    for index, line in enumerate(raw.splitlines(keepends=True), start=1):
        record = _json_object(line, label=f"{label} line {index}")
        if line != canonical_json_bytes(record):
            raise RuntimeError(f"{label} line {index} is not canonical")
        records.append(record)
    return records


def _last_json_object_line(path: Path, *, label: str) -> tuple[dict[str, Any], str]:
    source = _require_file(path, label=label)
    raw = source.read_bytes()
    records = [
        _json_object(line, label=f"{label} completion line")
        for line in raw.splitlines()
        if line.strip()
    ]
    if not records:
        raise RuntimeError(f"{label} contains no completion record")
    return records[-1], sha256(raw).hexdigest()


def _require_sha256(value: Any, *, label: str) -> str:
    if not isinstance(value, str) or HEX64.fullmatch(value) is None:
        raise RuntimeError(f"{label} is not a lowercase SHA-256 digest")
    return value


def _require_zero_evaluation(payload: Mapping[str, Any], *, label: str) -> None:
    for field in (
        "evaluation_array_reads",
        "evaluation_predictions",
        "evaluation_metrics",
        "evaluation_outputs",
    ):
        if type(payload.get(field)) is not int or payload[field] != 0:
            raise RuntimeError(f"{label} records evaluation activity: {field}")


def _source_capsule_contract_evidence(config: Mapping[str, Any]) -> dict[str, Any]:
    contract = config.get("training_source_capsule")
    if not isinstance(contract, Mapping):
        raise RuntimeError("training source capsule contract is absent")
    if config.get("remote_layout", {}).get("read_only_camels_root") != contract.get(
        "data_root"
    ):
        raise RuntimeError("training source capsule data-root binding changed")
    expected = {
        "source_capsule_root": contract.get("root"),
        "source_capsule_data_root": contract.get("data_root"),
        "source_capsule_manifest_sha256": contract.get("manifest_sha256"),
        "source_capsule_manifest_sha256_record_sha256": contract.get(
            "manifest_sha256_record_sha256"
        ),
        "source_capsule_ready_sha256": contract.get("ready_sha256"),
        "source_capsule_data_identity_sha256": contract.get(
            "data_identity_sha256"
        ),
        "source_capsule_deployment_result_sha256": contract.get(
            "deployment_result_sha256"
        ),
        "source_capsule_deployment_mailbox_sequence": contract.get(
            "deployment_mailbox_sequence"
        ),
        "source_capsule_post_publication_audit_mailbox_sequence": contract.get(
            "post_publication_audit_mailbox_sequence"
        ),
        "source_capsule_post_publication_audit_command_sha256": contract.get(
            "post_publication_audit_command_sha256"
        ),
        "source_capsule_post_publication_audit_result_sha256": contract.get(
            "post_publication_audit_result_sha256"
        ),
        "source_capsule_data_file_count": contract.get("data_file_count"),
        "source_capsule_evidence_file_count": contract.get("evidence_file_count"),
        "source_capsule_directory_count": contract.get("directory_count"),
        "source_capsule_data_total_bytes": contract.get("data_total_bytes"),
    }
    if (
        expected["source_capsule_manifest_sha256_record_sha256"]
        != "8725143e54efbb47aa73b8c960efee73aaf28fee85f54d331784d0373106ec69"
        or expected["source_capsule_data_file_count"] != 911
        or expected["source_capsule_evidence_file_count"] != 3
        or contract.get("total_file_count") != 914
        or expected["source_capsule_directory_count"] != 44
        or expected["source_capsule_data_total_bytes"] != 464_792_200
        or expected["source_capsule_post_publication_audit_mailbox_sequence"] != 47
        or expected["source_capsule_post_publication_audit_command_sha256"]
        != "3028bfac9f7a09fb060c23caca47578d40518c5b3adb301018dcaaef7b9ce3d4"
        or expected["source_capsule_post_publication_audit_result_sha256"]
        != "8d522b19230c8e33bbf2b87025ffd74f45e3c5f498c77530a9cafc76558db02e"
        or contract.get("post_publication_audit_status") != "PASS"
        or any(
            int(contract.get(key, -1)) != 0
            for key in (
                "formal_evaluation_array_reads",
                "formal_evaluation_predictions",
                "formal_evaluation_metrics",
                "formal_evaluation_outputs",
            )
        )
    ):
        raise RuntimeError("training source capsule contract changed scope or counts")
    return expected


def _require_source_capsule_evidence(
    payload: Mapping[str, Any], *, expected: Mapping[str, Any], label: str
) -> None:
    if any(payload.get(key) != value for key, value in expected.items()):
        raise RuntimeError(f"{label} training source capsule evidence changed")


def _same_path(left: Path, right: Path) -> bool:
    return os.path.normcase(os.path.abspath(os.fspath(left))) == os.path.normcase(
        os.path.abspath(os.fspath(right))
    )


def _reject_post_training_outputs(results_root: Path) -> Path:
    root = _require_directory(results_root, label="formal training result root")
    for name in FORBIDDEN_RESULT_MEMBERS:
        candidate = root / name
        if os.path.lexists(os.fspath(candidate)):
            raise RuntimeError(f"forbidden selection or evaluation output exists: {name}")
    return root


def _verify_bundle_scientific_files(
    *,
    project_root: Path,
    config_path: Path,
    config: Mapping[str, Any],
    bundle: Mapping[str, Any],
) -> None:
    members = bundle.get("member_sha256")
    if not isinstance(members, Mapping):
        raise RuntimeError("extracted bundle manifest lacks member hashes")
    relative_config = Path(config_path).relative_to(project_root).as_posix()
    required: dict[str, str] = {relative_config: sha256_file(config_path)}
    science = config.get("scientific_identity")
    if not isinstance(science, Mapping):
        raise RuntimeError("HPC execution config lacks scientific identity")
    for key in (
        "scientific_contract",
        "formal_training_execution",
        "independent_preflight_final_manifest",
        "filter_migration_final_manifest",
        "all_scope_authorization",
        "original_training_admission",
    ):
        record = science.get(key)
        if not isinstance(record, Mapping) or not isinstance(record.get("path"), str):
            raise RuntimeError(f"HPC execution config lacks frozen file: {key}")
        relative = Path(str(record["path"]))
        path = _require_file(
            project_root / relative,
            label=f"frozen scientific file {key}",
            root=project_root,
        )
        expected = record.get("file_sha256", record.get("sha256"))
        if sha256_file(path) != expected:
            raise RuntimeError(f"frozen scientific file changed: {key}")
        required[relative.as_posix()] = str(expected)
    for relative, digest in required.items():
        if members.get(f"kalmannet/{relative}") != digest:
            raise RuntimeError(f"bundle manifest does not bind current file: {relative}")


def _verify_recorded_runtime(
    runtime: Any, *, config: Mapping[str, Any]
) -> Mapping[str, Any]:
    if not isinstance(runtime, Mapping):
        raise RuntimeError("HPC preparation probe lacks its runtime identity")
    required = config.get("required_hpc_runtime")
    if not isinstance(required, Mapping):
        raise RuntimeError("HPC execution config lacks its required runtime")
    slurm = config.get("slurm")
    exclusive = (
        slurm.get("exclusive_node_runtime_evidence_contract")
        if isinstance(slurm, Mapping)
        else None
    )
    if not isinstance(exclusive, Mapping):
        raise RuntimeError("HPC execution config lacks exclusive-node runtime evidence")
    step_gpus = runtime.get("slurm_step_gpus")
    job_gpus = runtime.get("slurm_job_gpus")
    slurm_gpu_text = step_gpus or job_gpus
    slurm_gpu_ids = (
        [value.strip() for value in slurm_gpu_text.split(",") if value.strip()]
        if isinstance(slurm_gpu_text, str)
        else []
    )
    if (
        runtime.get("schema_version") != "tukf09_455_hpc_runtime_identity_a800_exclusive_v2r5"
        or runtime.get("python_version") != required.get("python_version")
        or runtime.get("numpy_version") != required.get("numpy_version")
        or runtime.get("torch_version") != required.get("torch_full_version")
        or runtime.get("torch_base_version") != required.get("torch_base_version")
        or runtime.get("psutil_version") != required.get("psutil_version")
        or runtime.get("torch_cuda_runtime_version")
        != required.get("torch_cuda_runtime_version")
        or runtime.get("cudnn_version") != required.get("cudnn_version")
        or runtime.get("cuda_available") is not True
        or runtime.get("cuda_device_count") != 1
        or runtime.get("cuda_device_name") != required.get("cuda_device_name")
        or runtime.get("cuda_compute_capability")
        != required.get("cuda_compute_capability")
        or type(runtime.get("cuda_device_total_memory_bytes")) is not int
        or runtime["cuda_device_total_memory_bytes"]
        < int(required.get("minimum_cuda_device_total_memory_bytes", 0))
        or runtime.get("tensorfloat32") != {"cuda_matmul": False, "cudnn": False}
        or not isinstance(runtime.get("nvidia_gpu_uuid"), str)
        or not runtime["nvidia_gpu_uuid"].startswith("GPU-")
        or runtime.get("torch_process_gpu_uuid") != runtime.get("nvidia_gpu_uuid")
        or not isinstance(runtime.get("selected_global_gpu_id"), str)
        or not runtime["selected_global_gpu_id"]
        or not isinstance(slurm, Mapping)
        or slurm.get("require_slurm_gpu_allocation_variable") is not True
        or runtime.get("slurm_gpu_allocation_variable_present") is not True
        or len(slurm_gpu_ids) != 1
        or runtime.get("selected_global_gpu_id") != slurm_gpu_ids[0]
        or runtime.get("slurm_job_cpus_per_node_raw")
        not in exclusive.get("accepted_slurm_job_cpus_per_node_formats", [])
        or runtime.get("slurm_job_cpus_per_node_normalized")
        != exclusive.get("expected_cpus_per_node")
        or runtime.get("slurm_job_node_count") != exclusive.get("expected_node_count")
        or runtime.get("slurm_cpus_on_node")
        != exclusive.get("expected_slurm_cpus_on_node")
        or runtime.get("slurm_cpus_per_task")
        != exclusive.get("expected_slurm_cpus_per_task")
        or runtime.get("exclusive_node_runtime_evidence_passed") is not True
        or exclusive.get("exclusive_node_runtime_evidence_passed_required") is not True
    ):
        raise RuntimeError("recorded HPC runtime differs from the technical execution config")
    return runtime


def _verify_hpc_technical_admission(
    *,
    project_root: Path,
    results_root: Path,
    config_path: Path,
    hpc_admission_path: Path,
    private_runtime_manifest: Path,
    preparation_probe: Path,
    staged_sources_manifest: Path,
    bundle_manifest: Path,
) -> dict[str, Any]:
    project = _require_directory(project_root, label="extracted Kalmannet project")
    expected_config = (
        project
        / "configs"
        / "tukf09_455_basin_zero_validation_target_variance_hpc_execution_a800_exclusive_v2r5.json"
    )
    if not _same_path(config_path, expected_config):
        raise RuntimeError("supplied HPC execution config differs from the fixed bundle path")
    config_source = _require_file(config_path, label="HPC execution config", root=project)
    config = _read(config_source, label="HPC execution config", root=project, canonical=False)
    if (
        config.get("schema_version") != "tukf09_455_basin_hpc_execution_a800_exclusive_v2r5"
        or config.get("experiment_id") != EXPERIMENT_ID
        or config.get("status") != "HPC_TECHNICAL_EXECUTION_FROZEN_FORMAL_EVALUATION_HOLD"
        or config.get("runtime_transition", {}).get(
            "bitwise_equivalence_to_rtx3090_claimed"
        )
        is not False
    ):
        raise RuntimeError("HPC execution config identity or evaluation hold changed")
    remote_layout = config.get("remote_layout")
    if not isinstance(remote_layout, Mapping):
        raise RuntimeError("HPC execution config lacks the remote layout")
    remote_root = _require_directory(
        Path(str(remote_layout["remote_root"])), label="remote experiment root"
    )
    if (
        not _same_path(project, Path(str(remote_layout["project_root"])))
        or not _same_path(project.parent, Path(str(remote_layout["bundle_root"])))
        or not _same_path(results_root, project / "results" / EXPERIMENT_SLUG)
    ):
        raise RuntimeError("project, bundle, or result path differs from the frozen remote layout")
    supplied = {
        "private_runtime_manifest": Path(private_runtime_manifest),
        "staged_sources_manifest": Path(staged_sources_manifest),
        "preparation_probe": Path(preparation_probe),
        "hpc_technical_admission": Path(hpc_admission_path),
    }
    for name, path in supplied.items():
        if not _same_path(path, Path(str(remote_layout[name]))):
            raise RuntimeError(f"supplied HPC evidence path differs from the frozen path: {name}")
    initial_path = Path(str(remote_layout["initial_bundle_verification"]))
    offline_path = Path(str(remote_layout["offline_runtime_inputs_manifest"]))
    expected_bundle = project.parent / "bundle_manifest.json"
    if not _same_path(bundle_manifest, expected_bundle):
        raise RuntimeError("supplied bundle manifest differs from the extracted bundle path")
    private = _read(
        supplied["private_runtime_manifest"],
        label="private runtime manifest",
        root=remote_root,
    )
    staged = _read(
        supplied["staged_sources_manifest"],
        label="staged source manifest",
        root=remote_root,
    )
    probe = _read(
        supplied["preparation_probe"], label="HPC preparation probe", root=remote_root
    )
    admission = _read(
        supplied["hpc_technical_admission"],
        label="HPC technical admission",
        root=remote_root,
    )
    initial = _read(
        initial_path,
        label="initial strict bundle verification",
        root=remote_root,
    )
    offline = _read(
        offline_path,
        label="offline runtime input manifest",
        root=remote_root,
    )
    private_identity = _verify_payload_identity(private, label="private runtime manifest")
    staged_identity = _verify_payload_identity(staged, label="staged source manifest")
    probe_identity = _verify_payload_identity(probe, label="HPC preparation probe")
    admission_identity = _verify_payload_identity(admission, label="HPC technical admission")
    initial_identity = _verify_payload_identity(
        initial, label="initial strict bundle verification"
    )
    offline_identity = _verify_payload_identity(
        offline, label="offline runtime input manifest"
    )
    bundle_path = _require_file(
        bundle_manifest,
        label="extracted bundle manifest",
        root=project.parent,
    )
    bundle = _read(
        bundle_path,
        label="extracted bundle manifest",
        root=project.parent,
        canonical=False,
    )
    if (
        initial.get("schema_version")
        != "tukf09_455_hpc_initial_bundle_verification_a800_exclusive_v2r5"
        or initial.get("experiment_id") != EXPERIMENT_ID
        or initial.get("status")
        != "STRICT_PRISTINE_A800_EXCLUSIVE_V2R5_BUNDLE_VERIFIED_BEFORE_RUNTIME_MUTATION"
        or initial.get("bundle_manifest_sha256") != sha256_file(bundle_path)
        or initial.get("strict_verifier_sha256")
        != sha256_file(project / "scripts/build_tukf09_455_a800_exclusive_hpc_bundle_v2r5.py")
        or initial.get("member_count") != 2808
        or initial.get("admitted_executable_count") != 30
        or initial.get("admitted_test_count") != 12
        or initial.get("formal_evaluation_output_count") != 0
        or initial.get("mutable_file_count_at_verification") != 0
        or initial.get("mutable_directory_count_at_verification") != 0
        or initial.get("scientific_contract_changed") is not False
    ):
        raise RuntimeError("initial strict bundle verification evidence changed")
    if (
        bundle.get("schema_version") != "tukf09_455_a800_exclusive_training_hpc_bundle_manifest_v2r5"
        or bundle.get("experiment_id") != EXPERIMENT_ID
        or bundle.get("purpose") != "formal_training_only_no_formal_evaluation"
        or bundle.get("formal_evaluation_output_count") != 0
        or bundle.get("formal_selection_output_count") != 0
        or bundle.get("local_results_file_count") != 0
        or bundle.get("member_count") != 2808
    ):
        raise RuntimeError("extracted bundle manifest changed scope")
    _verify_bundle_scientific_files(
        project_root=project,
        config_path=config_source,
        config=config,
        bundle=bundle,
    )
    remote_seal = _require_file(
        Path(results_root) / REMOTE_FILTER_SEAL_RELATIVE,
        label="remote independent filter installation seal",
        root=results_root,
    )
    science = config["scientific_identity"]
    offline_contract = config["offline_runtime_inputs"]
    source_capsule_evidence = _source_capsule_contract_evidence(config)
    _require_source_capsule_evidence(
        staged,
        expected=source_capsule_evidence,
        label="staged source manifest",
    )
    _require_source_capsule_evidence(
        probe,
        expected=source_capsule_evidence,
        label="HPC preparation probe",
    )
    _require_source_capsule_evidence(
        admission,
        expected=source_capsule_evidence,
        label="HPC technical admission",
    )
    offline_files = offline.get("files")
    if (
        offline.get("schema_version") != offline_contract["schema_version"]
        or offline.get("experiment_id") != EXPERIMENT_ID
        or offline.get("status")
        != "LOGIN4_LOCKED_RUNTIME_INPUTS_FROZEN_FOR_OFFLINE_SLURM_INSTALLATION"
        or offline.get("acquisition_host_shortname") != "login4"
        or offline.get("runtime_binary_lock_sha256")
        != offline_contract["runtime_binary_lock_sha256"]
        or offline.get("psutil_source_lock_sha256")
        != offline_contract["psutil_source_lock_sha256"]
        or offline.get("locked_binary_wheel_count") != 23
        or offline.get("source_archive_count") != 1
        or offline.get("total_file_count") != 24
        or offline.get("total_bytes") != 2_817_756_909
        or offline.get("download_only_no_build_no_install") is not True
        or offline.get("shared_nh_final_modified") is not False
        or offline.get("scientific_contract_changed") is not False
        or offline.get("formal_evaluation_authorized") is not False
        or not isinstance(offline_files, Mapping)
        or offline_files != offline_contract["expected_files"]
    ):
        raise RuntimeError("offline runtime input evidence changed identity or scope")
    _require_zero_evaluation(offline, label="offline runtime input manifest")
    if (
        private.get("schema_version") != "tukf09_455_hpc_private_runtime_manifest_a800_exclusive_v2r5"
        or private.get("experiment_id") != EXPERIMENT_ID
        or private.get("status") != "PRIVATE_RUNTIME_FROZEN_NOT_A_SCIENTIFIC_CONTRACT_CHANGE"
        or private.get("private_dependency_closure_complete") is not True
        or private.get("shared_nh_final_modified") is not False
        or private.get("offline_input_manifest_sha256") != sha256_file(offline_path)
        or private.get("offline_input_identity_sha256") != offline_identity
    ):
        raise RuntimeError("private runtime evidence changed scope")
    basin_ids = staged.get("ordered_basin_ids")
    if (
        staged.get("schema_version") != "tukf09_455_hpc_staged_training_sources_a800_exclusive_v2r5"
        or staged.get("experiment_id") != EXPERIMENT_ID
        or staged.get("status")
        != "STAGED_455_TRAINING_VALIDATION_SOURCE_FILES_EVALUATION_HOLD"
        or not isinstance(basin_ids, list)
        or len(basin_ids) != 455
        or len(set(basin_ids)) != 455
        or "08202700" in basin_ids
        or staged.get("file_count") != 911
        or not isinstance(staged.get("file_sha256"), Mapping)
        or len(staged["file_sha256"]) != 911
        or not isinstance(staged.get("file_size"), Mapping)
        or len(staged["file_size"]) != 911
        or staged.get("publication_policy")
        != "exclusive_destination_reservation_no_overwrite_freeze_root_on_failure"
        or staged.get("existing_tree_policy") != "exact_verify_only_no_overwrite"
    ):
        raise RuntimeError("staged training-source evidence changed scope or count")
    newline_hash = sha256(
        "".join(f"{value}\n" for value in basin_ids).encode("utf-8")
    ).hexdigest()
    compact_hash = sha256(
        json.dumps(basin_ids, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    if (
        newline_hash != science.get("ordered_basin_newline_sha256")
        or compact_hash != science.get("ordered_basin_compact_json_sha256")
        or science.get("ordered_basin_count") != 455
    ):
        raise RuntimeError("staged basin population differs from the frozen population")
    _require_zero_evaluation(staged, label="staged source manifest")
    if (
        probe.get("schema_version") != "tukf09_455_hpc_preparation_probe_a800_exclusive_v2r5"
        or probe.get("experiment_id") != EXPERIMENT_ID
        or probe.get("status") != "HPC_A800_EXCLUSIVE_V2R5_PREPARED_FILTERS_455_NEURAL_0_OF_9_EVALUATION_HOLD"
        or probe.get("filter_unit_count") != 455
        or probe.get("neural_model_unit_count") != 0
        or probe.get("scientific_contract_changed") is not False
        or probe.get("bundle_manifest_sha256") != sha256_file(bundle_path)
        or probe.get("initial_bundle_verification_sha256") != sha256_file(initial_path)
        or probe.get("initial_bundle_verification_identity_sha256") != initial_identity
        or probe.get("private_runtime_manifest_sha256")
        != sha256_file(supplied["private_runtime_manifest"])
        or probe.get("private_runtime_identity_sha256") != private_identity
        or probe.get("offline_input_manifest_sha256") != sha256_file(offline_path)
        or probe.get("offline_input_identity_sha256") != offline_identity
        or probe.get("staged_sources_manifest_sha256")
        != sha256_file(supplied["staged_sources_manifest"])
        or probe.get("staged_sources_identity_sha256") != staged_identity
        or probe.get("remote_filter_installation_final_sha256") != sha256_file(remote_seal)
    ):
        raise RuntimeError("HPC preparation evidence changed identity or counts")
    _require_zero_evaluation(probe, label="HPC preparation probe")
    recorded_runtime = _verify_recorded_runtime(probe.get("runtime"), config=config)
    if (
        admission.get("schema_version") != "tukf09_455_hpc_technical_admission_a800_exclusive_v2r5"
        or admission.get("experiment_id") != EXPERIMENT_ID
        or admission.get("status")
        != "HPC_A800_EXCLUSIVE_V2R5_TECHNICAL_EXECUTION_ADMITTED_FORMAL_EVALUATION_HOLD"
        or admission.get("scientific_contract_sha256")
        != science["scientific_contract"]["sha256"]
        or admission.get("original_training_admission_file_sha256")
        != science["original_training_admission"]["file_sha256"]
        or admission.get("original_training_admission_record_sha256")
        != science["original_training_admission"]["record_sha256"]
        or admission.get("local_filter_installation_final_sha256")
        != science["local_filter_installation_final_manifest"]["sha256"]
        or admission.get("remote_filter_installation_final_sha256") != sha256_file(remote_seal)
        or admission.get("bundle_manifest_sha256") != sha256_file(bundle_path)
        or admission.get("initial_bundle_verification_sha256")
        != sha256_file(initial_path)
        or admission.get("initial_bundle_verification_identity_sha256")
        != initial_identity
        or admission.get("private_runtime_manifest_sha256")
        != sha256_file(supplied["private_runtime_manifest"])
        or admission.get("private_runtime_identity_sha256") != private_identity
        or admission.get("offline_input_manifest_sha256") != sha256_file(offline_path)
        or admission.get("offline_input_identity_sha256") != offline_identity
        or admission.get("staged_sources_manifest_sha256")
        != sha256_file(supplied["staged_sources_manifest"])
        or admission.get("staged_sources_identity_sha256") != staged_identity
        or admission.get("preparation_probe_sha256")
        != sha256_file(supplied["preparation_probe"])
        or admission.get("preparation_probe_identity_sha256") != probe_identity
        or admission.get("admitted_runtime") != recorded_runtime
        or admission.get("ordered_basin_count") != 455
        or admission.get("neural_model_order") != list(EXPECTED_UNITS)
        or admission.get("neural_model_parallelism") != 1
        or admission.get("exclusive_node_required") is not True
        or admission.get("exclusive_node_runtime_evidence_passed") is not True
        or admission.get("formal_evaluation_authorized") is not False
        or admission.get("scientific_contract_changed") is not False
        or admission.get("original_training_admission_changed") is not False
        or admission.get("bitwise_equivalence_to_rtx3090_claimed") is not False
    ):
        raise RuntimeError("HPC technical admission changed identity, evidence, or scope")
    _require_zero_evaluation(admission, label="HPC technical admission")
    return {
        "admission": admission,
        "admission_sha256": sha256_file(supplied["hpc_technical_admission"]),
        "admission_identity_sha256": admission_identity,
        "ordered_basin_ids": tuple(str(value) for value in basin_ids),
        "recorded_runtime": dict(recorded_runtime),
        "remote_filter_installation_final_sha256": sha256_file(remote_seal),
    }


def _verify_admitted_training_root(
    *, project_root: Path, results_root: Path
) -> dict[str, Any]:
    from scripts import tukf09_455_training_common as training_common
    from scripts import tukf09_455_training_profile as profile

    project = Path(project_root)
    admission_path = project / profile.ADMISSION_RELATIVE
    execution_path = project / profile.FORMAL_TRAINING_CONFIG_RELATIVE
    admission = dict(
        training_common.load_and_verify_training_admission(
            admission_path,
            execution_path,
            tuple(
                project / relative
                for relative in training_common.REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS
            ),
        )
    )
    training_common.verify_initialized_training_root(
        output_root=results_root,
        config_path=project / profile.CONTRACT_RELATIVE,
        authorization=project / profile.AUTHORIZATION_RELATIVE,
        execution_config=execution_path,
        training_admission=admission_path,
        training_admission_record=admission,
    )
    return admission


def _verify_production_filter_installation(
    *, project_root: Path, results_root: Path
) -> dict[str, Any]:
    from scripts.verify_tukf09_455_filter_installation import (
        verify_filter_installation_independently,
    )

    project = Path(project_root)
    result = dict(
        verify_filter_installation_independently(
            migration_root=project / MIGRATION_ROOT_RELATIVE,
            results_root=results_root,
            training_admission_path=project / ORIGINAL_ADMISSION_RELATIVE,
            authorize=True,
            publish=False,
        )
    )
    expected = {
        "status": "FILTER_REBINDING_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD",
        "unit_count": 455,
        "unit_file_count": 2730,
        "new_filter_optimization_count": 0,
        "evaluation_access_count": 0,
    }
    for key, value in expected.items():
        if result.get(key) != value:
            raise RuntimeError(f"production filter installation count changed: {key}")
    seal = _read(
        Path(results_root) / "control/filter_rebinding/filter_rebinding.sealed.json",
        label="installed filter population seal",
        root=results_root,
    )
    basin_ids = seal.get("ordered_basin_ids")
    if (
        not isinstance(basin_ids, list)
        or len(basin_ids) != 455
        or len(set(basin_ids)) != 455
        or seal.get("unit_count") != 455
        or seal.get("unit_file_count") != 2730
    ):
        raise RuntimeError("installed filter population seal count changed")
    return {
        **result,
        "ordered_basin_ids": tuple(str(value) for value in basin_ids),
        "independent_final_sha256": sha256_file(
            Path(results_root) / REMOTE_FILTER_SEAL_RELATIVE
        ),
    }


def _verify_neural_units(
    *, results_root: Path, admission: Mapping[str, Any], basin_ids: Sequence[str]
) -> dict[str, Any]:
    from scripts import run_tukf09_455_neural_training as neural_training

    root = Path(results_root)
    neural_root = _require_directory(root / "neural", label="neural result directory")
    names = tuple(sorted(path.name for path in neural_root.iterdir()))
    if names != tuple(sorted((*EXPECTED_UNITS, "shared"))):
        raise RuntimeError("neural unit inventory is not exactly the frozen nine units")
    shared_sha256 = neural_training.validate_shared_training_scaler(root)
    checkpoints = 0
    units: dict[str, Any] = {}
    for unit_id in EXPECTED_UNITS:
        unit = neural_root / unit_id
        manifest = neural_training.validate_reusable_complete_unit(
            unit,
            unit_id,
            training_admission_record=admission,
            ordered_basin_ids=tuple(basin_ids),
            training_scaler_sha256_value=shared_sha256,
        )
        files = manifest.get("files")
        if not isinstance(files, Mapping):
            raise RuntimeError(f"neural manifest is incomplete: {unit_id}")
        checkpoint_names = sorted(
            name
            for name in files
            if name.startswith("checkpoints/epoch_") and name.endswith(".pt")
        )
        if len(checkpoint_names) != 30:
            raise RuntimeError(f"neural checkpoint count differs: {unit_id}")
        manifest_path = unit / "manifest.sha256.json"
        checkpoints += len(checkpoint_names)
        units[unit_id] = {
            "manifest_sha256": sha256_file(manifest_path),
            "checkpoint_count": len(checkpoint_names),
        }
    if len(units) != 9 or checkpoints != 270:
        raise RuntimeError("complete neural result count differs")
    return {
        "unit_count": len(units),
        "checkpoint_count": checkpoints,
        "shared_training_scaler_sha256": shared_sha256,
        "units": units,
    }


def _verify_formal_sequence_events(
    *,
    results_root: Path,
    training_admission_record_sha256: str,
    remote_filter_installation_final_sha256: str,
    stage_controller_source_sha256: Mapping[str, str],
    neural: Mapping[str, Any],
) -> dict[str, Any]:
    root = Path(results_root)
    admission_sha = _require_sha256(
        training_admission_record_sha256, label="training admission record hash"
    )
    sequence_path = root / "control/formal_training_sequence/events.jsonl"
    records = _read_canonical_json_lines(
        sequence_path, label="formal training sequence event log"
    )
    for expected, record in enumerate(records, start=1):
        if (
            record.get("schema_version") != "tukf09_formal_training_sequence_event_v1"
            or record.get("experiment_id") != EXPERIMENT_ID
            or record.get("sequence") != expected
            or HEX32.fullmatch(str(record.get("execution_id", ""))) is None
        ):
            raise RuntimeError("formal training sequence event identity or order changed")
    final = records[-1]
    execution_id = str(final["execution_id"])
    current = [record for record in records if record.get("execution_id") == execution_id]
    if [record.get("event") for record in current] != [
        "sequence_started",
        "stage_started",
        "stage_completed",
        "stage_started",
        "stage_completed",
        "sequence_completed",
    ]:
        raise RuntimeError("final formal training execution is not an exact successful sequence")
    (
        sequence_started,
        filter_started,
        filter_completed,
        neural_started,
        neural_completed,
        final,
    ) = current
    controller_process_id = final.get("controller_process_id")
    source_hashes = final.get("stage_controller_source_sha256")
    expected_source_hashes = dict(stage_controller_source_sha256)
    if (
        type(controller_process_id) is not int
        or controller_process_id <= 0
        or sequence_started.get("controller_process_id") != controller_process_id
        or sequence_started.get("training_stages") != list(EXPECTED_STAGES)
        or final.get("stage_order") != list(EXPECTED_STAGES)
        or final.get("training_admission_record_sha256") != admission_sha
        or final.get("evaluation_access_count") != 0
        or not isinstance(source_hashes, Mapping)
        or set(source_hashes) != set(EXPECTED_STAGES)
        or any(HEX64.fullmatch(str(value)) is None for value in source_hashes.values())
        or dict(source_hashes) != expected_source_hashes
    ):
        raise RuntimeError("formal training final event changed identity, order, or scope")
    for record in current:
        if "training_admission_record_sha256" in record and record.get(
            "training_admission_record_sha256"
        ) != admission_sha:
            raise RuntimeError("formal training event admission identity changed")
        if "stage_controller_source_sha256" in record and record.get(
            "stage_controller_source_sha256"
        ) != source_hashes:
            raise RuntimeError("formal training event source identity changed")
        if "evaluation_access_count" in record and record.get("evaluation_access_count") != 0:
            raise RuntimeError("formal training event records evaluation access")
    for started, completed, stage, status in (
        (
            filter_started,
            filter_completed,
            "verify_filter_rebinding",
            "FILTER_REBINDING_VERIFIED_EVALUATION_HOLD",
        ),
        (
            neural_started,
            neural_completed,
            "neural",
            "NEURAL_TRAINING_COMPLETE_EVALUATION_HOLD",
        ),
    ):
        if (
            started.get("stage") != stage
            or completed.get("stage") != stage
            or type(started.get("stage_process_id")) is not int
            or completed.get("stage_process_id") != started.get("stage_process_id")
            or completed.get("exit_code") != 0
            or completed.get("completion_status") != status
        ):
            raise RuntimeError(f"formal training stage event changed: {stage}")

    filter_stdout, filter_stdout_sha = _last_json_object_line(
        root / "logs/formal_training_sequence/verify_filter_rebinding_controller.stdout.log",
        label="filter controller stdout",
    )
    if (
        filter_stdout.get("schema_version")
        != "tukf09_455_filter_rebinding_controller_result_v1"
        or filter_stdout.get("experiment_id") != EXPERIMENT_ID
        or filter_stdout.get("status") != "FILTER_REBINDING_VERIFIED_EVALUATION_HOLD"
        or filter_stdout.get("canonical_unit_count") != 455
        or filter_stdout.get("completed_unit_count") != 455
        or filter_stdout.get("training_admission_record_sha256") != admission_sha
        or filter_stdout.get("evaluation_access_count") != 0
    ):
        raise RuntimeError("filter controller completion record changed counts or identity")
    neural_stdout, neural_stdout_sha = _last_json_object_line(
        root / "logs/formal_training_sequence/neural_controller.stdout.log",
        label="neural controller stdout",
    )
    completed_units = neural_stdout.get("completed_units")
    if (
        neural_stdout.get("schema_version") != "tukf09_neural_controller_result_v1"
        or neural_stdout.get("experiment_id") != EXPERIMENT_ID
        or neural_stdout.get("status") != "NEURAL_TRAINING_COMPLETE_EVALUATION_HOLD"
        or neural_stdout.get("controller_process_id") != neural_started.get("stage_process_id")
        or neural_stdout.get("unit_count") != 9
        or neural_stdout.get("checkpoint_count") != 270
        or neural_stdout.get("training_admission_record_sha256") != admission_sha
        or neural_stdout.get("evaluation_access_count") != 0
        or not isinstance(completed_units, list)
        or len(completed_units) != 9
        or [row.get("unit_id") for row in completed_units if isinstance(row, Mapping)]
        != list(EXPECTED_UNITS)
    ):
        raise RuntimeError("neural controller completion record changed counts or identity")
    unit_records = neural.get("units")
    if (
        neural.get("unit_count") != 9
        or neural.get("checkpoint_count") != 270
        or not isinstance(unit_records, Mapping)
        or set(unit_records) != set(EXPECTED_UNITS)
    ):
        raise RuntimeError("verified neural unit records are absent")
    for row in completed_units:
        if not isinstance(row, Mapping):
            raise RuntimeError("neural controller unit completion is not an object")
        actual = unit_records.get(str(row.get("unit_id")))
        if (
            not isinstance(actual, Mapping)
            or row.get("checkpoint_count") != 30
            or row.get("manifest_sha256") != actual.get("manifest_sha256")
        ):
            raise RuntimeError("neural controller unit completion differs from result members")

    neural_event_path = root / "control/neural/events.jsonl"
    neural_events = _read_canonical_json_lines(
        neural_event_path, label="neural training controller event log"
    )
    for expected, record in enumerate(neural_events, start=1):
        if (
            record.get("schema_version") != "tukf09_neural_controller_event_v1"
            or record.get("experiment_id") != EXPERIMENT_ID
            or record.get("sequence_number") != expected
            or record.get("evaluation_access_count") != 0
        ):
            raise RuntimeError("neural controller event identity, order, or scope changed")
    final_neural = neural_events[-1]
    start_indexes = [
        index
        for index, record in enumerate(neural_events)
        if record.get("event_type") == "CONTROLLER_STARTED"
    ]
    if not start_indexes:
        raise RuntimeError("neural controller start event is absent")
    final_segment = neural_events[start_indexes[-1] :]
    controller_started = final_segment[0]
    terminal_units = [
        record
        for record in final_segment
        if record.get("event_type") in {"UNIT_COMPLETED", "UNIT_REUSED"}
    ]
    if (
        final_neural.get("event_type") != "CONTROLLER_COMPLETED"
        or final_neural.get("controller_process_id") != neural_stdout.get("controller_process_id")
        or final_neural.get("unit_id") is not None
        or final_neural.get("exit_status") != "COMPLETE_EVALUATION_HOLD"
        or final_neural.get("detail") != {"unit_count": 9, "checkpoint_count": 270}
        or controller_started.get("controller_process_id")
        != final_neural.get("controller_process_id")
        or controller_started.get("exit_status") != "RUNNING"
        or controller_started.get("detail", {}).get(
            "training_admission_record_sha256"
        )
        != admission_sha
        or controller_started.get("detail", {}).get(
            "filter_installation_final_sha256"
        )
        != remote_filter_installation_final_sha256
        or controller_started.get("detail", {}).get("sequence_execution_id")
        != execution_id
        or any(
            record.get("event_type") in {"UNIT_FAILED", "CONTROLLER_FAILED"}
            for record in final_segment
        )
        or [record.get("unit_id") for record in terminal_units] != list(EXPECTED_UNITS)
    ):
        raise RuntimeError("neural controller final event or complete unit history changed")
    for record in terminal_units:
        unit_id = str(record["unit_id"])
        expected_exit = (
            "COMPLETE" if record.get("event_type") == "UNIT_COMPLETED" else "COMPLETE_EXACT_MANIFEST"
        )
        if (
            record.get("exit_status") != expected_exit
            or record.get("unit_manifest_sha256")
            != unit_records[unit_id]["manifest_sha256"]
        ):
            raise RuntimeError("neural controller event manifest differs from result members")
    return {
        "formal_sequence_execution_id": execution_id,
        "formal_sequence_final_event_sequence": final["sequence"],
        "formal_sequence_event_log_sha256": sha256_file(sequence_path),
        "filter_controller_stdout_sha256": filter_stdout_sha,
        "neural_controller_stdout_sha256": neural_stdout_sha,
        "neural_controller_final_event_sequence": final_neural["sequence_number"],
        "neural_controller_event_log_sha256": sha256_file(neural_event_path),
    }


def verify(
    *,
    project_root: Path,
    results_root: Path,
    hpc_execution_config: Path,
    hpc_technical_admission: Path,
    private_runtime_manifest: Path,
    preparation_probe: Path,
    staged_sources_manifest: Path,
    bundle_manifest: Path,
) -> dict[str, Any]:
    project = _require_directory(project_root, label="verification project root")
    if not _same_path(project, ROOT):
        raise RuntimeError("verification project root differs from the verifier location")
    root = _reject_post_training_outputs(Path(results_root))
    technical = _verify_hpc_technical_admission(
        project_root=project,
        results_root=root,
        config_path=hpc_execution_config,
        hpc_admission_path=hpc_technical_admission,
        private_runtime_manifest=private_runtime_manifest,
        preparation_probe=preparation_probe,
        staged_sources_manifest=staged_sources_manifest,
        bundle_manifest=bundle_manifest,
    )
    admission = _verify_admitted_training_root(project_root=project, results_root=root)
    admission_record_sha = _require_sha256(
        admission.get("training_admission_record_sha256"),
        label="verified original training admission record hash",
    )
    if admission_record_sha != technical["admission"].get(
        "original_training_admission_record_sha256"
    ):
        raise RuntimeError("HPC technical admission does not bind the verified training admission")
    filters = _verify_production_filter_installation(
        project_root=project, results_root=root
    )
    if (
        filters["independent_final_sha256"]
        != technical["remote_filter_installation_final_sha256"]
        or tuple(filters["ordered_basin_ids"]) != tuple(technical["ordered_basin_ids"])
    ):
        raise RuntimeError("remote filter installation differs from the HPC technical admission")
    neural = _verify_neural_units(
        results_root=root,
        admission=admission,
        basin_ids=filters["ordered_basin_ids"],
    )
    events = _verify_formal_sequence_events(
        results_root=root,
        training_admission_record_sha256=admission_record_sha,
        remote_filter_installation_final_sha256=filters["independent_final_sha256"],
        stage_controller_source_sha256={
            "verify_filter_rebinding": sha256_file(
                project / "scripts/verify_tukf09_455_filter_rebinding_controller.py"
            ),
            "neural": sha256_file(
                project / "scripts/run_tukf09_455_neural_training_controller.py"
            ),
        },
        neural=neural,
    )
    recorded_runtime = technical.get("recorded_runtime", {})
    return {
        "schema_version": "tukf09_455_hpc_training_verification_a800_exclusive_v2r5",
        "status": (
            "HPC_A800_EXCLUSIVE_V2R5_FORMAL_TRAINING_VERIFIED_FILTERS_455_"
            "NEURAL_9_OF_9_FORMAL_EVALUATION_HOLD"
        ),
        "filter_units": filters["unit_count"],
        "filter_unit_files": filters["unit_file_count"],
        "new_filter_training_units": filters["new_filter_optimization_count"],
        "remote_filter_installation_final_sha256": filters[
            "independent_final_sha256"
        ],
        "hpc_technical_admission_sha256": technical["admission_sha256"],
        "hpc_technical_admission_identity_sha256": technical[
            "admission_identity_sha256"
        ],
        "slurm_job_cpus_per_node_raw": recorded_runtime.get(
            "slurm_job_cpus_per_node_raw"
        ),
        "slurm_job_cpus_per_node_normalized": recorded_runtime.get(
            "slurm_job_cpus_per_node_normalized"
        ),
        "slurm_job_node_count": recorded_runtime.get("slurm_job_node_count"),
        "slurm_cpus_on_node": recorded_runtime.get("slurm_cpus_on_node"),
        "slurm_cpus_per_task": recorded_runtime.get("slurm_cpus_per_task"),
        "exclusive_node_runtime_evidence_passed": recorded_runtime.get(
            "exclusive_node_runtime_evidence_passed"
        ),
        "slurm_gpu_allocation_variable_present": recorded_runtime.get(
            "slurm_gpu_allocation_variable_present"
        ),
        "training_admission_record_sha256": admission_record_sha,
        "neural_model_units": neural["unit_count"],
        "neural_checkpoints": neural["checkpoint_count"],
        "shared_training_scaler_sha256": neural["shared_training_scaler_sha256"],
        "units": neural["units"],
        **events,
        "formal_evaluation_attempted": False,
        "evaluation_array_reads": 0,
        "evaluation_predictions": 0,
        "evaluation_metrics": 0,
        "evaluation_outputs": 0,
    }


def _write_exclusive(path: Path, payload: dict[str, Any]) -> None:
    destination = Path(path)
    content = canonical_json_bytes(payload)
    if os.path.lexists(os.fspath(destination)):
        if (
            destination.is_file()
            and not _is_link_or_reparse(destination)
            and int(destination.stat().st_nlink) == 1
            and destination.read_bytes() == content
        ):
            return
        raise RuntimeError(f"refusing to replace different verification evidence: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("xb") as handle:
        handle.write(content)
        handle.flush()
        os.fsync(handle.fileno())


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--results-root", type=Path, required=True)
    parser.add_argument("--hpc-execution-config", type=Path, required=True)
    parser.add_argument("--hpc-technical-admission", type=Path, required=True)
    parser.add_argument("--private-runtime-manifest", type=Path, required=True)
    parser.add_argument("--preparation-probe", type=Path, required=True)
    parser.add_argument("--staged-sources-manifest", type=Path, required=True)
    parser.add_argument("--bundle-manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    output = (
        args.hpc_technical_admission.parent / "training_verification.json"
        if args.output is None
        else args.output
    )
    try:
        payload = verify(
            project_root=args.project_root,
            results_root=args.results_root,
            hpc_execution_config=args.hpc_execution_config,
            hpc_technical_admission=args.hpc_technical_admission,
            private_runtime_manifest=args.private_runtime_manifest,
            preparation_probe=args.preparation_probe,
            staged_sources_manifest=args.staged_sources_manifest,
            bundle_manifest=args.bundle_manifest,
        )
        code = 0
    except Exception as exc:
        payload = {
            "schema_version": "tukf09_455_hpc_training_verification_a800_exclusive_v2r5",
            "status": "HPC_TRAINING_VERIFICATION_FAILURE",
            "error_type": type(exc).__name__,
            "message": str(exc),
            "formal_evaluation_attempted": False,
        }
        code = 1
    _write_exclusive(output, payload)
    stream = sys.stdout if code == 0 else sys.stderr
    print(canonical_json_bytes(payload).decode("utf-8"), end="", file=stream)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
