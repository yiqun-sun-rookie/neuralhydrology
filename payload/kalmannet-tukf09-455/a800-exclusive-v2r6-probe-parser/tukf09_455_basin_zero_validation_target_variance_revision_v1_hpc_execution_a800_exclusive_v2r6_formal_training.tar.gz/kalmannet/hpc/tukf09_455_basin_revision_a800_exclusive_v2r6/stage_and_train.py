"""Fail-closed HPC preparation and launch for the frozen 455-basin training stage.

This wrapper is deliberately outside the 30-file scientific training admission.  It
does not change that admission.  It records and verifies the separate Linux/A800
technical execution identity, stages only the sealed training/validation source
surface, recreates the already-sealed filter installation in a new result root, and
then invokes the unchanged serial training sequence.  Formal evaluation is never
called from this module.
"""
from __future__ import annotations

import argparse
from hashlib import sha256
import importlib.metadata
import json
import os
from pathlib import Path, PurePosixPath
import platform
import re
import shutil
import socket
import stat
import subprocess
import sys
from typing import Any, Mapping, Sequence


ROOT = Path(__file__).resolve().parents[2]
EXPERIMENT_ID = "TUKF09_455_BASIN_ZERO_VALIDATION_TARGET_VARIANCE_REVISION_V1"
EXPERIMENT_SLUG = "tukf09_455_basin_zero_validation_target_variance_revision_v1"
CONFIG_RELATIVE = Path(
    "configs/tukf09_455_basin_zero_validation_target_variance_hpc_execution_a800_exclusive_v2r6.json"
)
SCIENTIFIC_CONTRACT_RELATIVE = Path(
    "configs/tukf09_455_basin_zero_validation_target_variance_revision_v1.json"
)
ORIGINAL_ADMISSION_RELATIVE = Path(
    "artifacts"
) / EXPERIMENT_SLUG / "training_admission" / "training_admission.json"
PREFLIGHT_ROOT_RELATIVE = Path("artifacts") / EXPERIMENT_SLUG / "preflight"
MIGRATION_ROOT_RELATIVE = (
    Path("artifacts") / EXPERIMENT_SLUG / "filter_migration_v1"
)
RESULTS_ROOT_RELATIVE = Path("results") / EXPERIMENT_SLUG
REMOTE_FILTER_SEAL_RELATIVE = (
    RESULTS_ROOT_RELATIVE
    / "control"
    / "filter_rebinding"
    / "independent"
    / "manifest.final.sha256.json"
)
POPULATION_RELATIVE = PREFLIGHT_ROOT_RELATIVE / "population_registry.json"
RAW_MANIFEST_RELATIVE = PREFLIGHT_ROOT_RELATIVE / "raw_source_manifest.sha256.json"
FORMAL_SEQUENCE_RELATIVE = Path("scripts/run_tukf09_455_formal_training_sequence.py")
BINARY_LOCK_RELATIVE = Path("hpc/tukf09_455_basin_revision_a800_exclusive_v2r6/runtime-binary.lock")
PSUTIL_SOURCE_LOCK_RELATIVE = Path("hpc/tukf09_455_basin_revision_a800_exclusive_v2r6/psutil-source.lock")
HEX64 = re.compile(r"[0-9a-f]{64}")
LOCK_HASH = re.compile(r"--hash=sha256:([0-9a-f]{64})(?:\s|$)")
EVALUATION_ZERO_FIELDS = (
    "evaluation_array_reads",
    "evaluation_predictions",
    "evaluation_metrics",
    "evaluation_outputs",
)


def canonical_json_bytes(value: Any) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
        + b"\n"
    )


def sha256_bytes(value: bytes) -> str:
    return sha256(value).hexdigest()


def sha256_file(path: Path, *, chunk_size: int = 1024 * 1024) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(chunk_size), b""):
            digest.update(block)
    return digest.hexdigest()


def _stat_identity(value: os.stat_result) -> tuple[int, int, int, int, int, int]:
    return (
        value.st_dev,
        value.st_ino,
        value.st_size,
        value.st_mtime_ns,
        value.st_mode,
        value.st_nlink,
    )


def stable_file_bytes(path: Path) -> bytes:
    """Read a frozen file and reject any concurrent metadata or size change."""

    source = Path(path)
    before = source.stat()
    raw = source.read_bytes()
    after = source.stat()
    if _stat_identity(before) != _stat_identity(after) or len(raw) != before.st_size:
        raise RuntimeError(f"file changed while it was being read: {source}")
    return raw


def stable_sha256_file(path: Path, *, chunk_size: int = 1024 * 1024) -> str:
    """Hash a frozen file and reject any concurrent metadata change."""

    source = Path(path)
    before = source.stat()
    digest = sha256()
    with source.open("rb") as handle:
        for block in iter(lambda: handle.read(chunk_size), b""):
            digest.update(block)
    after = source.stat()
    if _stat_identity(before) != _stat_identity(after):
        raise RuntimeError(f"file changed while it was being hashed: {source}")
    return digest.hexdigest()


def path_exists(path: Path) -> bool:
    return os.path.lexists(os.fspath(path))


def _relative_inside(path: Path, root: Path) -> Path:
    absolute_root = Path(os.path.abspath(os.fspath(root)))
    absolute_path = Path(os.path.abspath(os.fspath(path)))
    try:
        return absolute_path.relative_to(absolute_root)
    except ValueError as exc:
        raise RuntimeError(f"path escapes its allowed root: {path}") from exc


def require_unlinked_directory(path: Path, *, label: str) -> Path:
    """Require an existing directory whose absolute path contains no links."""

    candidate = Path(os.path.abspath(os.fspath(path)))
    anchor = Path(candidate.anchor)
    current = anchor
    for part in candidate.relative_to(anchor).parts:
        current = current / part
        if current.is_symlink():
            raise RuntimeError(f"{label} contains a symbolic link: {current}")
    if not candidate.is_dir() or candidate.is_symlink():
        raise RuntimeError(f"{label} is not a regular directory: {candidate}")
    return candidate


def require_unlinked_existing_chain(path: Path, *, root: Path, label: str) -> Path:
    """Reject links in an existing or not-yet-created path below a trusted root."""

    trusted = require_unlinked_directory(root, label=f"{label} root")
    candidate = Path(os.path.abspath(os.fspath(path)))
    relative = _relative_inside(candidate, trusted)
    current = trusted
    for part in relative.parts:
        current = current / part
        if current.is_symlink():
            raise RuntimeError(f"{label} contains a symbolic link: {current}")
        if not path_exists(current):
            break
    return candidate


def require_regular_unlinked_file(path: Path, *, root: Path, label: str) -> Path:
    candidate = Path(os.path.abspath(os.fspath(path)))
    current = require_unlinked_directory(root, label=f"{label} root")
    relative = _relative_inside(candidate, current)
    for part in relative.parts:
        current = current / part
        if current.is_symlink():
            raise RuntimeError(f"{label} contains a symbolic link: {current}")
    if not candidate.is_file() or candidate.is_symlink():
        raise RuntimeError(f"{label} is not a regular file: {candidate}")
    if candidate.stat().st_nlink != 1:
        raise RuntimeError(f"{label} is hard-linked: {candidate}")
    return candidate


def read_json(path: Path, *, root: Path | None = None, canonical: bool = False) -> dict[str, Any]:
    source = Path(path)
    if root is not None:
        source = require_regular_unlinked_file(source, root=root, label="JSON evidence")
    raw = source.read_bytes()
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"invalid JSON evidence: {source}") from exc
    if not isinstance(value, dict):
        raise RuntimeError(f"JSON evidence is not an object: {source}")
    if canonical and raw != canonical_json_bytes(value):
        raise RuntimeError(f"JSON evidence is not canonical: {source}")
    return value


def _payload_identity(payload: Mapping[str, Any]) -> str:
    unsigned = {key: value for key, value in payload.items() if key != "identity_sha256"}
    return sha256_bytes(canonical_json_bytes(unsigned))


def _verify_payload_identity(payload: Mapping[str, Any], *, label: str) -> None:
    identity = payload.get("identity_sha256")
    if not isinstance(identity, str) or HEX64.fullmatch(identity) is None:
        raise RuntimeError(f"{label} lacks a valid identity SHA-256")
    if identity != _payload_identity(payload):
        raise RuntimeError(f"{label} identity SHA-256 changed")


def require_zero_evaluation(payload: Mapping[str, Any], *, label: str) -> None:
    for field in EVALUATION_ZERO_FIELDS:
        if type(payload.get(field)) is not int or payload[field] != 0:
            raise RuntimeError(f"{label} does not record exact zero evaluation activity: {field}")


def write_canonical_json_exclusive(path: Path, payload: Mapping[str, Any]) -> bool:
    destination = Path(path)
    content = canonical_json_bytes(payload)
    if path_exists(destination):
        if (
            destination.is_file()
            and not destination.is_symlink()
            and destination.read_bytes() == content
        ):
            return True
        raise RuntimeError(f"refusing to replace different evidence: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    # The final name itself is reserved with O_EXCL.  A check-then-os.replace
    # publication could overwrite a file created by another process between
    # the last check and the replace operation.
    with destination.open("xb") as handle:
        handle.write(content)
        handle.flush()
        os.fsync(handle.fileno())
    return False


def load_execution_config(path: Path = ROOT / CONFIG_RELATIVE) -> dict[str, Any]:
    config_path = require_regular_unlinked_file(path, root=ROOT, label="HPC execution config")
    config = read_json(config_path)
    remote_root = "/data1/home/sunyiq/kalmannet_tukf09_455_basin_zero_validation_target_variance_revision_v1_a800_exclusive_v2r6_20260902"
    remote_layout = config.get("remote_layout", {})
    if (
        config.get("schema_version") != "tukf09_455_basin_hpc_execution_a800_exclusive_v2r6"
        or config.get("experiment_id") != EXPERIMENT_ID
        or config.get("status") != "HPC_TECHNICAL_EXECUTION_FROZEN_FORMAL_EVALUATION_HOLD"
        or config.get("execution_route", {}).get("formal_evaluation_access") is not False
        or config.get("runtime_transition", {}).get("scientific_contract_change_allowed")
        is not False
        or config.get("runtime_transition", {}).get(
            "bitwise_equivalence_to_rtx3090_claimed"
        )
        is not False
        or remote_layout.get("remote_root") != remote_root
        or remote_layout.get("preparation_failure_marker")
        != f"{remote_root}/status/PREPARATION_FAILED.json"
        or remote_layout.get("runtime_pending_glob")
        != f"{remote_root}/runtime_v2r6.pending.*"
        or remote_layout.get("same_root_retry_after_preparation_failure_allowed")
        is not False
    ):
        raise RuntimeError("HPC technical execution config changed scope")
    _validate_frozen_source_capsule_contract(config)
    return config


def _validate_frozen_source_capsule_contract(config: Mapping[str, Any]) -> None:
    contract = config.get("training_source_capsule")
    root = "/data1/home/sunyiq/kalmannet_tukf09_455_basin_zero_validation_target_variance_revision_v1_training_source_capsule_v2_20260901"
    if (
        not isinstance(contract, Mapping)
        or contract.get("schema_version") != "tukf09_455_training_source_capsule_v2"
        or contract.get("root") != root
        or contract.get("data_root") != f"{root}/data/camels_us"
        or contract.get("manifest")
        != f"{root}/evidence/source_capsule_manifest.json"
        or contract.get("manifest_size") != 569_601
        or contract.get("manifest_sha256")
        != "d5de91725d0da93f3aa4a234f5c103131fad8ef4b3c86f919236b9e42a318547"
        or contract.get("manifest_sha256_record")
        != f"{root}/evidence/source_capsule_manifest.sha256"
        or contract.get("manifest_sha256_record_size") != 95
        or contract.get("manifest_sha256_record_sha256")
        != "8725143e54efbb47aa73b8c960efee73aaf28fee85f54d331784d0373106ec69"
        or contract.get("ready") != f"{root}/evidence/READY.json"
        or contract.get("ready_size") != 1_236
        or contract.get("ready_sha256")
        != "10331991ee26049554a3d18682c907bfb343877311ca053ac696ccfa1c6a8b93"
        or contract.get("data_file_count") != 911
        or contract.get("evidence_file_count") != 3
        or contract.get("total_file_count") != 914
        or contract.get("directory_count") != 44
        or contract.get("data_total_bytes") != 464_792_200
        or contract.get("data_identity_sha256")
        != "dd238eebc1696f73f9eee7adf924913ff5a912c8f795f8998255e87408b760da"
        or contract.get("deployment_mailbox_sequence") != 45
        or contract.get("deployment_command_sha256")
        != "5956de9ae96f5db93b0e86d69f0b2ce26394c59931e08acde890c0620bbf3cd9"
        or contract.get("deployment_result_commit")
        != "08d7d719eccbe723c9825558b34e6be14649e7ba"
        or contract.get("deployment_result_size") != 1_202
        or contract.get("deployment_result_sha256")
        != "78da4a712fdbee06dac78f50f92390c341a3ac83b5da25fee099acb12943b5eb"
        or contract.get("failed_post_publication_audit_mailbox_sequence") != 46
        or contract.get("failed_post_publication_audit_result_commit")
        != "95929ed6f6258bbdd5e38a1fe514e354f7f637e0"
        or contract.get("failed_post_publication_audit_result_size") != 388
        or contract.get("failed_post_publication_audit_result_sha256")
        != "6aa3bce163b3deec6907efce1a6a750418b77b0b3d2ae4f276a79491d3fde804"
        or contract.get("failed_post_publication_audit_root_cause")
        != "auditor_sorted_the_basin_set_instead_of_using_the_frozen_population_registry_order"
        or contract.get("post_publication_audit_mailbox_sequence") != 47
        or contract.get("post_publication_audit_command_size") != 22_720
        or contract.get("post_publication_audit_command_sha256")
        != "3028bfac9f7a09fb060c23caca47578d40518c5b3adb301018dcaaef7b9ce3d4"
        or contract.get("post_publication_audit_result_commit")
        != "c46f27ac2809933b02a8982ee56d9c0908765379"
        or contract.get("post_publication_audit_result_size") != 3_317
        or contract.get("post_publication_audit_result_sha256")
        != "8d522b19230c8e33bbf2b87025ffd74f45e3c5f498c77530a9cafc76558db02e"
        or contract.get("post_publication_audit_status") != "PASS"
        or contract.get("publication_mode")
        != "exclusive_root_reservation_then_exact_ready_json_then_root_mode_0555_final_gate"
        or contract.get("required_root_mode") != "0555"
        or contract.get("required_directory_mode") != "0555"
        or contract.get("required_file_mode") != "0444"
        or contract.get("symbolic_links_allowed") is not False
        or contract.get("hard_link_count_above_one_allowed") is not False
        or contract.get("verify_manifest_ready_tree_surface_and_all_911_files_before_copy")
        is not True
        or any(
            int(contract.get(key, -1)) != 0
            for key in (
                "formal_evaluation_array_reads",
                "formal_evaluation_predictions",
                "formal_evaluation_metrics",
                "formal_evaluation_outputs",
            )
        )
        or config.get("remote_layout", {}).get("read_only_camels_root")
        != contract.get("data_root")
    ):
        raise RuntimeError("training source capsule contract changed frozen identity")


def expected_source_capsule_evidence(config: Mapping[str, Any]) -> dict[str, Any]:
    contract = config.get("training_source_capsule")
    if not isinstance(contract, Mapping):
        raise RuntimeError("training source capsule contract is absent")
    return {
        "source_capsule_root": contract.get("root"),
        "source_capsule_data_root": contract.get("data_root"),
        "source_capsule_manifest_sha256": contract.get("manifest_sha256"),
        "source_capsule_manifest_sha256_record_sha256": contract.get(
            "manifest_sha256_record_sha256"
        ),
        "source_capsule_ready_sha256": contract.get("ready_sha256"),
        "source_capsule_data_identity_sha256": contract.get(
            "data_identity_sha256"
        ),
        "source_capsule_deployment_result_sha256": contract.get(
            "deployment_result_sha256"
        ),
        "source_capsule_deployment_mailbox_sequence": contract.get(
            "deployment_mailbox_sequence"
        ),
        "source_capsule_post_publication_audit_mailbox_sequence": contract.get(
            "post_publication_audit_mailbox_sequence"
        ),
        "source_capsule_post_publication_audit_command_sha256": contract.get(
            "post_publication_audit_command_sha256"
        ),
        "source_capsule_post_publication_audit_result_sha256": contract.get(
            "post_publication_audit_result_sha256"
        ),
        "source_capsule_data_file_count": contract.get("data_file_count"),
        "source_capsule_evidence_file_count": contract.get("evidence_file_count"),
        "source_capsule_directory_count": contract.get("directory_count"),
        "source_capsule_data_total_bytes": contract.get("data_total_bytes"),
    }


def verify_source_capsule_evidence(
    payload: Mapping[str, Any], *, config: Mapping[str, Any], label: str
) -> dict[str, Any]:
    expected = expected_source_capsule_evidence(config)
    if any(payload.get(key) != value for key, value in expected.items()):
        raise RuntimeError(f"{label} training source capsule evidence changed")
    return expected


def verify_training_source_capsule(
    *,
    source_root: Path,
    config_path: Path = ROOT / CONFIG_RELATIVE,
) -> dict[str, Any]:
    """Verify the exact read-only capsule before any source byte is staged."""

    config = load_execution_config(config_path)
    contract = config.get("training_source_capsule")
    if not isinstance(contract, Mapping):
        raise RuntimeError("training source capsule contract is absent")
    capsule_root = require_unlinked_directory(
        Path(str(contract.get("root", ""))), label="training source capsule root"
    )
    data_root = require_unlinked_directory(
        Path(str(contract.get("data_root", ""))), label="training source capsule data root"
    )
    requested_source = require_unlinked_directory(
        source_root, label="requested training source capsule data root"
    )
    if requested_source != data_root:
        raise RuntimeError("requested training source is not the frozen capsule data root")
    _relative_inside(data_root, capsule_root)

    expected_directory_mode = int(str(contract.get("required_directory_mode", "")), 8)
    expected_root_mode = int(str(contract.get("required_root_mode", "")), 8)
    expected_file_mode = int(str(contract.get("required_file_mode", "")), 8)
    if (
        expected_directory_mode != 0o555
        or expected_root_mode != 0o555
        or expected_file_mode != 0o444
        or stat.S_IMODE(capsule_root.stat().st_mode) != expected_root_mode
    ):
        raise RuntimeError("training source capsule publication modes changed")

    manifest_path = require_regular_unlinked_file(
        Path(str(contract.get("manifest", ""))),
        root=capsule_root,
        label="training source capsule manifest",
    )
    ready_path = require_regular_unlinked_file(
        Path(str(contract.get("ready", ""))),
        root=capsule_root,
        label="training source capsule READY gate",
    )
    manifest_sha_path = require_regular_unlinked_file(
        Path(str(contract.get("manifest_sha256_record", ""))),
        root=capsule_root,
        label="training source capsule manifest SHA-256 record",
    )
    for evidence in (manifest_path, manifest_sha_path, ready_path):
        if stat.S_IMODE(evidence.stat().st_mode) != expected_file_mode:
            raise RuntimeError(f"training source capsule evidence is not read-only: {evidence}")

    manifest_bytes = stable_file_bytes(manifest_path)
    manifest_sha_record_bytes = stable_file_bytes(manifest_sha_path)
    ready_bytes = stable_file_bytes(ready_path)
    manifest_sha = sha256_bytes(manifest_bytes)
    manifest_sha_record_sha = sha256_bytes(manifest_sha_record_bytes)
    ready_sha = sha256_bytes(ready_bytes)
    if (
        manifest_path.stat().st_size != int(contract.get("manifest_size", -1))
        or manifest_sha != contract.get("manifest_sha256")
        or manifest_sha_path != manifest_path.with_name("source_capsule_manifest.sha256")
        or manifest_sha_path.stat().st_size
        != int(contract.get("manifest_sha256_record_size", -1))
        or manifest_sha_record_sha
        != contract.get("manifest_sha256_record_sha256")
        or ready_path.stat().st_size != int(contract.get("ready_size", -1))
        or ready_sha != contract.get("ready_sha256")
        or manifest_sha_record_bytes
        != f"{manifest_sha}  source_capsule_manifest.json\n".encode("ascii")
    ):
        raise RuntimeError("training source capsule manifest or READY bytes changed")
    try:
        manifest = json.loads(manifest_bytes.decode("utf-8"))
        ready = json.loads(ready_bytes.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError("training source capsule evidence is invalid JSON") from exc
    if not isinstance(manifest, dict) or not isinstance(ready, dict):
        raise RuntimeError("training source capsule evidence is not a JSON object")

    expected_file_count = int(contract.get("data_file_count", -1))
    expected_evidence_count = int(contract.get("evidence_file_count", -1))
    expected_total_file_count = int(contract.get("total_file_count", -1))
    expected_directory_count = int(contract.get("directory_count", -1))
    expected_total_bytes = int(contract.get("data_total_bytes", -1))
    expected_identity = str(contract.get("data_identity_sha256", ""))
    zero_keys = (
        "formal_evaluation_array_reads",
        "formal_evaluation_predictions",
        "formal_evaluation_metrics",
        "formal_evaluation_outputs",
    )
    if (
        contract.get("schema_version") != "tukf09_455_training_source_capsule_v2"
        or contract.get("publication_mode")
        != "exclusive_root_reservation_then_exact_ready_json_then_root_mode_0555_final_gate"
        or contract.get("symbolic_links_allowed") is not False
        or contract.get("hard_link_count_above_one_allowed") is not False
        or contract.get("verify_manifest_ready_tree_surface_and_all_911_files_before_copy")
        is not True
        or expected_file_count <= 0
        or expected_evidence_count != 3
        or expected_total_file_count != expected_file_count + expected_evidence_count
        or expected_directory_count <= 0
        or expected_total_bytes <= 0
        or HEX64.fullmatch(expected_identity) is None
        or type(contract.get("deployment_mailbox_sequence")) is not int
        or int(contract["deployment_mailbox_sequence"]) <= 0
        or HEX64.fullmatch(str(contract.get("deployment_command_sha256", ""))) is None
        or not isinstance(contract.get("deployment_result_commit"), str)
        or len(contract["deployment_result_commit"]) != 40
        or type(contract.get("deployment_result_size")) is not int
        or int(contract["deployment_result_size"]) <= 0
        or HEX64.fullmatch(str(contract.get("deployment_result_sha256", ""))) is None
        or any(int(contract.get(key, -1)) != 0 for key in zero_keys)
    ):
        raise RuntimeError("training source capsule contract changed identity or scope")
    if (
        manifest.get("schema_version") != contract.get("schema_version")
        or manifest.get("purpose")
        != "read_only_training_validation_source_only_no_formal_evaluation"
        or manifest.get("scientific_identity") != config.get("scientific_identity")
        or manifest.get("capsule_root") != os.fspath(capsule_root)
        or manifest.get("capsule_data_root") != os.fspath(data_root)
        or manifest.get("file_count") != expected_file_count
        or manifest.get("total_bytes") != expected_total_bytes
        or manifest.get("data_identity_sha256") != expected_identity
        or manifest.get("capsule_deployment_mailbox_sequence")
        != contract.get("deployment_mailbox_sequence")
        or manifest.get("capsule_deployment_command_sha256")
        != contract.get("deployment_command_sha256")
        or manifest.get("publication_mode") != contract.get("publication_mode")
        or any(int(manifest.get(key, -1)) != 0 for key in zero_keys)
    ):
        raise RuntimeError("training source capsule manifest changed identity or scope")
    if (
        ready.get("schema_version")
        != "tukf09_455_training_source_capsule_ready_v2"
        or ready.get("status") != "READY"
        or ready.get("capsule_root") != os.fspath(capsule_root)
        or ready.get("capsule_data_root") != os.fspath(data_root)
        or ready.get("manifest_relative_path")
        != manifest_path.relative_to(capsule_root).as_posix()
        or ready.get("manifest_size") != len(manifest_bytes)
        or ready.get("manifest_sha256") != manifest_sha
        or ready.get("data_file_count") != expected_file_count
        or ready.get("data_total_bytes") != expected_total_bytes
        or ready.get("data_identity_sha256") != expected_identity
        or ready.get("deployment_mailbox_sequence")
        != contract.get("deployment_mailbox_sequence")
        or ready.get("deployment_command_sha256")
        != contract.get("deployment_command_sha256")
        or ready.get("validity_gate")
        != "exact_ready_json_and_manifest_and_911_files_and_all_directories_mode_0555"
        or ready.get("required_capsule_root_mode") != "0555"
        or ready.get("required_all_directory_mode") != "0555"
        or ready.get("required_all_file_mode") != "0444"
        or any(int(ready.get(key, -1)) != 0 for key in zero_keys)
    ):
        raise RuntimeError("training source capsule READY gate changed identity or scope")

    raw_manifest_relative = str(config["data_staging"]["raw_source_manifest"])
    raw_manifest_path = require_regular_unlinked_file(
        ROOT.joinpath(*PurePosixPath(raw_manifest_relative).parts),
        root=ROOT,
        label="frozen raw source manifest",
    )
    if (
        manifest.get("raw_source_manifest_relative_path") != raw_manifest_relative
        or manifest.get("raw_source_manifest_size") != raw_manifest_path.stat().st_size
        or manifest.get("raw_source_manifest_sha256") != sha256_file(raw_manifest_path)
    ):
        raise RuntimeError("training source capsule raw manifest binding changed")

    raw_records = manifest.get("files")
    if not isinstance(raw_records, list) or len(raw_records) != expected_file_count:
        raise RuntimeError("training source capsule file records changed")
    records: dict[str, dict[str, Any]] = {}
    for raw_record in raw_records:
        if not isinstance(raw_record, Mapping):
            raise RuntimeError("training source capsule file record is not an object")
        relative = str(raw_record.get("relative_path", ""))
        pure = PurePosixPath(relative)
        size = raw_record.get("size_bytes")
        digest = raw_record.get("sha256")
        if (
            not relative
            or pure.is_absolute()
            or ".." in pure.parts
            or "\\" in relative
            or relative in records
            or not isinstance(size, int)
            or size <= 0
            or not isinstance(digest, str)
            or HEX64.fullmatch(digest) is None
        ):
            raise RuntimeError(f"invalid training source capsule record: {relative}")
        records[relative] = {"size_bytes": size, "sha256": digest}

    actual_files: set[str] = set()
    actual_directories: set[str] = set()
    for directory, names, filenames in os.walk(capsule_root, topdown=True, followlinks=False):
        directory_path = Path(directory)
        if directory_path.is_symlink() or stat.S_IMODE(directory_path.stat().st_mode) != expected_directory_mode:
            raise RuntimeError(f"training source capsule directory changed: {directory_path}")
        actual_directories.add(
            "."
            if directory_path == capsule_root
            else directory_path.relative_to(capsule_root).as_posix()
        )
        for name in names:
            candidate = directory_path / name
            if candidate.is_symlink():
                raise RuntimeError(f"training source capsule contains a linked directory: {candidate}")
        for name in filenames:
            candidate = require_regular_unlinked_file(
                directory_path / name,
                root=capsule_root,
                label="training source capsule tree file",
            )
            if stat.S_IMODE(candidate.stat().st_mode) != expected_file_mode:
                raise RuntimeError(f"training source capsule file is not read-only: {candidate}")
            actual_files.add(candidate.relative_to(capsule_root).as_posix())

    data_relative = data_root.relative_to(capsule_root)
    expected_files = {
        (data_relative / Path(*PurePosixPath(relative).parts)).as_posix()
        for relative in records
    }
    expected_files.update(
        {
            manifest_path.relative_to(capsule_root).as_posix(),
            manifest_sha_path.relative_to(capsule_root).as_posix(),
            ready_path.relative_to(capsule_root).as_posix(),
        }
    )
    expected_directories = {".", data_relative.parts[0], data_relative.as_posix(), "evidence"}
    for relative in records:
        cursor = data_relative / Path(*PurePosixPath(relative).parts)
        for parent in cursor.parents:
            if parent == Path("."):
                break
            expected_directories.add(parent.as_posix())
    if (
        actual_files != expected_files
        or actual_directories != expected_directories
        or len(actual_files) != expected_file_count + expected_evidence_count
        or len(actual_files) != expected_total_file_count
        or len(actual_directories) != expected_directory_count
    ):
        raise RuntimeError("training source capsule file or directory surface changed")

    total_bytes = 0
    identity_rows: list[dict[str, Any]] = []
    for relative, record in sorted(records.items()):
        path = require_regular_unlinked_file(
            data_root.joinpath(*PurePosixPath(relative).parts),
            root=capsule_root,
            label="training source capsule data file",
        )
        if (
            path.stat().st_size != int(record["size_bytes"])
            or stable_sha256_file(path) != record["sha256"]
        ):
            raise RuntimeError(f"training source capsule data differs: {relative}")
        total_bytes += path.stat().st_size
        identity_rows.append(
            {
                "relative_path": relative,
                "size_bytes": int(record["size_bytes"]),
                "sha256": record["sha256"],
            }
        )
    identity_sha = sha256_bytes(
        json.dumps(
            identity_rows,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    )
    if total_bytes != expected_total_bytes or identity_sha != expected_identity:
        raise RuntimeError("training source capsule data identity changed")
    return {
        "root": os.fspath(capsule_root),
        "data_root": os.fspath(data_root),
        "manifest_sha256": manifest_sha,
        "manifest_sha256_record_sha256": manifest_sha_record_sha,
        "ready_sha256": ready_sha,
        "data_identity_sha256": identity_sha,
        "data_file_count": len(records),
        "evidence_file_count": expected_evidence_count,
        "directory_count": len(actual_directories),
        "data_total_bytes": total_bytes,
        "deployment_result_sha256": contract["deployment_result_sha256"],
        "post_publication_audit_mailbox_sequence": contract.get(
            "post_publication_audit_mailbox_sequence"
        ),
        "post_publication_audit_command_sha256": contract.get(
            "post_publication_audit_command_sha256"
        ),
        "post_publication_audit_result_sha256": contract.get(
            "post_publication_audit_result_sha256"
        ),
    }


def _inventory_regular_files(root: Path) -> dict[str, tuple[str, int]]:
    directory = require_unlinked_directory(root, label="inventory directory")
    records: dict[str, tuple[str, int]] = {}
    for path in sorted(directory.rglob("*"), key=lambda value: value.as_posix()):
        if path.is_dir() and not path.is_symlink():
            continue
        relative = path.relative_to(directory).as_posix()
        require_regular_unlinked_file(path, root=directory, label="private runtime member")
        if relative in records:
            raise RuntimeError(f"duplicate private runtime member: {relative}")
        records[relative] = (sha256_file(path), path.stat().st_size)
    return records


def _inventory_flat_regular_files(root: Path, *, label: str) -> dict[str, tuple[str, int]]:
    directory = require_unlinked_directory(root, label=label)
    for child in directory.iterdir():
        if child.is_dir() or child.is_symlink():
            raise RuntimeError(f"{label} contains a directory or link: {child}")
    inventory = _inventory_regular_files(directory)
    if any("/" in name or "\\" in name for name in inventory):
        raise RuntimeError(f"{label} is not a flat file inventory")
    return inventory


def _normalized_distribution_name(value: str) -> str:
    return re.sub(r"[-_.]+", "-", value).lower()


def _private_distribution_versions(pysite: Path) -> dict[str, str]:
    versions: dict[str, str] = {}
    for distribution in importlib.metadata.distributions(path=[os.fspath(pysite)]):
        name = distribution.metadata.get("Name")
        if not isinstance(name, str) or not name.strip():
            raise RuntimeError("private distribution lacks a name")
        normalized = _normalized_distribution_name(name)
        if normalized in versions:
            raise RuntimeError(f"duplicate private distribution: {normalized}")
        versions[normalized] = str(distribution.version)
    return dict(sorted(versions.items()))


def _locked_hashes(path: Path, *, expected_count: int) -> tuple[str, set[str]]:
    lock = require_regular_unlinked_file(path, root=ROOT, label="private dependency lock")
    raw = lock.read_bytes()
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise RuntimeError("private dependency lock is not UTF-8") from exc
    values = LOCK_HASH.findall(text)
    if len(values) != expected_count or len(set(values)) != expected_count:
        raise RuntimeError("private dependency lock hash closure differs")
    return sha256_bytes(raw), set(values)


def _expected_offline_input_records(config: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    contract = config.get("offline_runtime_inputs", {})
    raw_records = contract.get("expected_files")
    if not isinstance(raw_records, Mapping):
        raise RuntimeError("offline runtime input file contract is absent")
    records: dict[str, dict[str, Any]] = {}
    for raw_name, raw_record in raw_records.items():
        name = str(raw_name)
        if (
            not name
            or name in {".", ".."}
            or Path(name).name != name
            or not isinstance(raw_record, Mapping)
        ):
            raise RuntimeError("offline runtime input filename is unsafe")
        record = {
            "kind": raw_record.get("kind"),
            "size": raw_record.get("size"),
            "sha256": raw_record.get("sha256"),
        }
        if (
            record["kind"] not in {"binary_wheel", "source_archive"}
            or not isinstance(record["size"], int)
            or record["size"] <= 0
            or not isinstance(record["sha256"], str)
            or HEX64.fullmatch(record["sha256"]) is None
        ):
            raise RuntimeError(f"offline runtime input record is invalid: {name}")
        if record["kind"] == "binary_wheel" and not name.endswith(".whl"):
            raise RuntimeError(f"locked binary input is not a wheel: {name}")
        if record["kind"] == "source_archive" and name != "psutil-5.9.0.tar.gz":
            raise RuntimeError(f"locked source input differs: {name}")
        records[name] = record
    binary_records = {
        name: record for name, record in records.items() if record["kind"] == "binary_wheel"
    }
    source_records = {
        name: record for name, record in records.items() if record["kind"] == "source_archive"
    }
    binary_lock_sha256, binary_hashes = _locked_hashes(
        ROOT / BINARY_LOCK_RELATIVE, expected_count=23
    )
    source_lock_sha256, source_hashes = _locked_hashes(
        ROOT / PSUTIL_SOURCE_LOCK_RELATIVE, expected_count=1
    )
    if (
        len(records) != int(contract.get("total_file_count", -1))
        or len(binary_records) != int(contract.get("locked_binary_wheel_count", -1))
        or len(source_records) != int(contract.get("source_archive_count", -1))
        or sum(int(record["size"]) for record in records.values())
        != int(contract.get("total_bytes", -1))
        or {record["sha256"] for record in binary_records.values()} != binary_hashes
        or {record["sha256"] for record in source_records.values()} != source_hashes
        or binary_lock_sha256 != contract.get("runtime_binary_lock_sha256")
        or source_lock_sha256 != contract.get("psutil_source_lock_sha256")
    ):
        raise RuntimeError("offline runtime input closure differs from its two locks")
    return dict(sorted(records.items()))


def _verify_offline_input_directories(
    *, wheelhouse: Path, sourcehouse: Path, config: Mapping[str, Any]
) -> dict[str, dict[str, Any]]:
    wheel_inventory = _inventory_flat_regular_files(
        wheelhouse, label="offline binary wheel directory"
    )
    source_inventory = _inventory_flat_regular_files(
        sourcehouse, label="offline source archive directory"
    )
    if set(wheel_inventory) & set(source_inventory):
        raise RuntimeError("offline runtime input names overlap")
    actual: dict[str, dict[str, Any]] = {
        name: {"kind": "binary_wheel", "size": size, "sha256": digest}
        for name, (digest, size) in wheel_inventory.items()
    }
    actual.update(
        {
            name: {"kind": "source_archive", "size": size, "sha256": digest}
            for name, (digest, size) in source_inventory.items()
        }
    )
    expected = _expected_offline_input_records(config)
    if dict(sorted(actual.items())) != expected:
        raise RuntimeError("offline runtime input bytes differ from the frozen closure")
    return expected


def _verify_wheelhouse_against_locks(
    wheel_inventory: Mapping[str, tuple[str, int]],
) -> dict[str, Any]:
    binary_lock_sha256, binary_hashes = _locked_hashes(
        ROOT / BINARY_LOCK_RELATIVE, expected_count=23
    )
    source_lock_sha256, source_hashes = _locked_hashes(
        ROOT / PSUTIL_SOURCE_LOCK_RELATIVE, expected_count=1
    )
    psutil_sources = {
        name: record
        for name, record in wheel_inventory.items()
        if name == "psutil-5.9.0.tar.gz"
    }
    built_psutil_wheels = {
        name: record
        for name, record in wheel_inventory.items()
        if name.startswith("psutil-5.9.0-") and name.endswith(".whl")
    }
    locked_binary_wheels = {
        name: record
        for name, record in wheel_inventory.items()
        if name.endswith(".whl") and name not in built_psutil_wheels
    }
    if (
        len(psutil_sources) != 1
        or len(built_psutil_wheels) != 1
        or len(locked_binary_wheels) != 23
        or {digest for digest, _ in psutil_sources.values()} != source_hashes
        or {digest for digest, _ in locked_binary_wheels.values()} != binary_hashes
        or len(wheel_inventory) != 25
    ):
        raise RuntimeError("private wheelhouse differs from the two dependency locks")
    psutil_wheel_name, (psutil_wheel_sha256, _) = next(
        iter(built_psutil_wheels.items())
    )
    return {
        "runtime_binary_lock_sha256": binary_lock_sha256,
        "runtime_binary_locked_wheel_count": len(locked_binary_wheels),
        "psutil_source_lock_sha256": source_lock_sha256,
        "psutil_source_sha256": next(iter(source_hashes)),
        "built_psutil_wheel_filename": psutil_wheel_name,
        "built_psutil_wheel_sha256": psutil_wheel_sha256,
    }


def _current_python_executable_evidence() -> dict[str, Any]:
    declared = Path(os.path.abspath(sys.executable))
    resolved = declared.resolve(strict=True)
    if not resolved.is_file():
        raise RuntimeError("the active Python interpreter is not a regular file")
    return {
        "python_executable": os.fspath(declared),
        "python_executable_resolved": os.fspath(resolved),
        "python_executable_sha256": sha256_file(resolved),
        "python_executable_size": resolved.stat().st_size,
        "python_version": platform.python_version(),
    }


def snapshot_shared_environment(
    *, output: Path, config_path: Path = ROOT / CONFIG_RELATIVE
) -> dict[str, Any]:
    """Record the bootstrap environment without installing, building, or importing torch."""

    config = load_execution_config(config_path)
    remote_root = Path(config["remote_layout"]["remote_root"])
    interpreter = _current_python_executable_evidence()
    contract = config["offline_runtime_inputs"]
    if (
        interpreter["python_executable"] != contract["required_bootstrap_python_executable"]
        or interpreter["python_version"] != config["required_hpc_runtime"]["python_version"]
    ):
        raise RuntimeError("offline acquisition bootstrap Python differs")
    distributions: list[dict[str, str]] = []
    for distribution in importlib.metadata.distributions():
        name = distribution.metadata.get("Name")
        if not isinstance(name, str) or not name.strip():
            raise RuntimeError("shared environment distribution lacks a name")
        distributions.append(
            {
                "name": _normalized_distribution_name(name),
                "version": str(distribution.version),
                "location": os.fspath(Path(distribution.locate_file("")).resolve()),
            }
        )
    distributions.sort(key=lambda item: (item["name"], item["version"], item["location"]))
    payload: dict[str, Any] = {
        "schema_version": "tukf09_455_hpc_shared_environment_snapshot_a800_exclusive_v2r6",
        "experiment_id": EXPERIMENT_ID,
        "status": "SHARED_BOOTSTRAP_ENVIRONMENT_READ_ONLY_SNAPSHOT",
        "hostname": socket.gethostname(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "libc": list(platform.libc_ver()),
        "pip_version": importlib.metadata.version("pip"),
        "distributions": distributions,
        **interpreter,
        "scientific_contract_changed": False,
        "formal_evaluation_authorized": False,
    }
    payload["identity_sha256"] = _payload_identity(payload)
    destination = require_unlinked_existing_chain(
        output, root=remote_root, label="shared environment snapshot"
    )
    write_canonical_json_exclusive(destination, payload)
    return payload


def _offline_evidence_record(path: Path, *, offline_root: Path, label: str) -> dict[str, Any]:
    source = require_regular_unlinked_file(path, root=offline_root, label=label)
    relative = _relative_inside(source, offline_root).as_posix()
    if not relative.startswith("evidence/"):
        raise RuntimeError(f"{label} is outside the offline evidence directory")
    return {
        "path": relative,
        "size": source.stat().st_size,
        "sha256": sha256_file(source),
    }


def freeze_offline_inputs_manifest(
    *,
    wheelhouse: Path,
    sourcehouse: Path,
    download_command_file: Path,
    download_stdout_file: Path,
    download_stderr_file: Path,
    shared_environment_before: Path,
    shared_environment_after: Path,
    output: Path,
    config_path: Path = ROOT / CONFIG_RELATIVE,
) -> dict[str, Any]:
    config = load_execution_config(config_path)
    remote_root = Path(config["remote_layout"]["remote_root"])
    wheels = require_unlinked_directory(wheelhouse, label="downloaded binary wheel directory")
    sources = require_unlinked_directory(sourcehouse, label="downloaded source archive directory")
    offline_root = wheels.parent
    if sources.parent != offline_root:
        raise RuntimeError("offline wheel and source directories do not share one root")
    _relative_inside(offline_root, remote_root)
    records = _verify_offline_input_directories(
        wheelhouse=wheels, sourcehouse=sources, config=config
    )
    command_path = require_regular_unlinked_file(
        download_command_file, root=offline_root, label="offline download command"
    )
    try:
        command_text = command_path.read_bytes().decode("utf-8")
    except UnicodeDecodeError as exc:
        raise RuntimeError("offline download command is not UTF-8") from exc
    if (
        command_text.count("pip download") != 2
        or "pip install" in command_text
        or "pip wheel" in command_text
    ):
        raise RuntimeError("offline acquisition command changed from download-only scope")
    before_path = require_regular_unlinked_file(
        shared_environment_before, root=offline_root, label="shared environment before snapshot"
    )
    after_path = require_regular_unlinked_file(
        shared_environment_after, root=offline_root, label="shared environment after snapshot"
    )
    before = read_json(before_path, canonical=True)
    after = read_json(after_path, canonical=True)
    _verify_payload_identity(before, label="shared environment before snapshot")
    _verify_payload_identity(after, label="shared environment after snapshot")
    if before_path.read_bytes() != after_path.read_bytes():
        raise RuntimeError("shared nh_final environment changed during download")
    contract = config["offline_runtime_inputs"]
    short_hostname = socket.gethostname().split(".", 1)[0]
    if short_hostname != contract["acquisition_host_shortname"]:
        raise RuntimeError("offline runtime inputs were not acquired on login4")
    interpreter = _current_python_executable_evidence()
    if (
        interpreter["python_executable"] != contract["required_bootstrap_python_executable"]
        or interpreter["python_version"] != config["required_hpc_runtime"]["python_version"]
    ):
        raise RuntimeError("offline acquisition Python differs")
    evidence = {
        "download_command": _offline_evidence_record(
            command_path, offline_root=offline_root, label="offline download command"
        ),
        "download_stdout": _offline_evidence_record(
            download_stdout_file, offline_root=offline_root, label="offline download stdout"
        ),
        "download_stderr": _offline_evidence_record(
            download_stderr_file, offline_root=offline_root, label="offline download stderr"
        ),
        "shared_environment_before": _offline_evidence_record(
            before_path, offline_root=offline_root, label="shared environment before snapshot"
        ),
        "shared_environment_after": _offline_evidence_record(
            after_path, offline_root=offline_root, label="shared environment after snapshot"
        ),
    }
    payload: dict[str, Any] = {
        "schema_version": contract["schema_version"],
        "experiment_id": EXPERIMENT_ID,
        "status": "LOGIN4_LOCKED_RUNTIME_INPUTS_FROZEN_FOR_OFFLINE_SLURM_INSTALLATION",
        "acquisition_host": socket.gethostname(),
        "acquisition_host_shortname": short_hostname,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "libc": list(platform.libc_ver()),
        "pip_version": importlib.metadata.version("pip"),
        **interpreter,
        "runtime_binary_lock_path": BINARY_LOCK_RELATIVE.as_posix(),
        "runtime_binary_lock_sha256": contract["runtime_binary_lock_sha256"],
        "psutil_source_lock_path": PSUTIL_SOURCE_LOCK_RELATIVE.as_posix(),
        "psutil_source_lock_sha256": contract["psutil_source_lock_sha256"],
        "locked_binary_wheel_count": contract["locked_binary_wheel_count"],
        "source_archive_count": contract["source_archive_count"],
        "total_file_count": contract["total_file_count"],
        "total_bytes": contract["total_bytes"],
        "files": records,
        "download_evidence": evidence,
        "shared_environment_inventory_sha256": sha256_file(before_path),
        "shared_nh_final_modified": False,
        "download_only_no_build_no_install": True,
        "all_regular_files": True,
        "all_link_counts_one": True,
        "symbolic_links_present": False,
        "publication_mode": contract["publication_mode"],
        "compute_copy_mode": contract["compute_copy_mode"],
        "scientific_contract_changed": False,
        "formal_evaluation_authorized": False,
        "evaluation_array_reads": 0,
        "evaluation_predictions": 0,
        "evaluation_metrics": 0,
        "evaluation_outputs": 0,
    }
    payload["identity_sha256"] = _payload_identity(payload)
    destination = require_unlinked_existing_chain(
        output, root=offline_root, label="offline runtime input manifest"
    )
    write_canonical_json_exclusive(destination, payload)
    return payload


def verify_offline_inputs_manifest(
    *,
    manifest_path: Path,
    wheelhouse: Path | None = None,
    sourcehouse: Path | None = None,
    config_path: Path = ROOT / CONFIG_RELATIVE,
) -> dict[str, Any]:
    config = load_execution_config(config_path)
    remote_root = Path(config["remote_layout"]["remote_root"])
    expected_manifest = Path(config["remote_layout"]["offline_runtime_inputs_manifest"])
    manifest_file = require_regular_unlinked_file(
        manifest_path, root=remote_root, label="offline runtime input manifest"
    )
    if Path(os.path.abspath(os.fspath(manifest_file))) != Path(
        os.path.abspath(os.fspath(expected_manifest))
    ):
        raise RuntimeError("offline runtime input manifest is outside its final path")
    manifest = read_json(manifest_file, canonical=True)
    contract = config["offline_runtime_inputs"]
    if (
        manifest.get("schema_version") != contract["schema_version"]
        or manifest.get("experiment_id") != EXPERIMENT_ID
        or manifest.get("status")
        != "LOGIN4_LOCKED_RUNTIME_INPUTS_FROZEN_FOR_OFFLINE_SLURM_INSTALLATION"
        or manifest.get("acquisition_host_shortname") != contract["acquisition_host_shortname"]
        or manifest.get("runtime_binary_lock_sha256")
        != contract["runtime_binary_lock_sha256"]
        or manifest.get("psutil_source_lock_sha256")
        != contract["psutil_source_lock_sha256"]
        or manifest.get("total_file_count") != contract["total_file_count"]
        or manifest.get("total_bytes") != contract["total_bytes"]
        or manifest.get("download_only_no_build_no_install") is not True
        or manifest.get("shared_nh_final_modified") is not False
        or manifest.get("scientific_contract_changed") is not False
        or manifest.get("formal_evaluation_authorized") is not False
    ):
        raise RuntimeError("offline runtime input manifest changed scope")
    require_zero_evaluation(manifest, label="offline runtime input manifest")
    _verify_payload_identity(manifest, label="offline runtime input manifest")
    expected_records = _expected_offline_input_records(config)
    if manifest.get("files") != expected_records:
        raise RuntimeError("offline runtime input manifest file closure differs")
    offline_root = require_unlinked_directory(
        manifest_file.parent, label="published offline runtime input root"
    )
    evidence = manifest.get("download_evidence")
    if not isinstance(evidence, Mapping) or set(evidence) != {
        "download_command",
        "download_stdout",
        "download_stderr",
        "shared_environment_before",
        "shared_environment_after",
    }:
        raise RuntimeError("offline runtime input evidence inventory differs")
    for label, raw_record in evidence.items():
        if not isinstance(raw_record, Mapping):
            raise RuntimeError("offline runtime input evidence record is invalid")
        relative = PurePosixPath(str(raw_record.get("path", "")))
        if relative.is_absolute() or ".." in relative.parts:
            raise RuntimeError("offline runtime input evidence path is unsafe")
        evidence_path = offline_root.joinpath(*relative.parts)
        source = require_regular_unlinked_file(
            evidence_path, root=offline_root, label=f"offline evidence {label}"
        )
        if (
            source.stat().st_size != raw_record.get("size")
            or sha256_file(source) != raw_record.get("sha256")
        ):
            raise RuntimeError(f"offline runtime input evidence changed: {label}")
    before_record = evidence["shared_environment_before"]
    after_record = evidence["shared_environment_after"]
    before_path = offline_root.joinpath(*PurePosixPath(before_record["path"]).parts)
    after_path = offline_root.joinpath(*PurePosixPath(after_record["path"]).parts)
    if (
        before_path.read_bytes() != after_path.read_bytes()
        or sha256_file(before_path) != manifest.get("shared_environment_inventory_sha256")
    ):
        raise RuntimeError("shared environment snapshot evidence differs")
    selected_wheelhouse = wheelhouse if wheelhouse is not None else offline_root / "wheelhouse"
    selected_sourcehouse = sourcehouse if sourcehouse is not None else offline_root / "sourcehouse"
    _verify_offline_input_directories(
        wheelhouse=selected_wheelhouse,
        sourcehouse=selected_sourcehouse,
        config=config,
    )
    return manifest


def copy_offline_inputs(
    *,
    manifest_path: Path,
    source_wheelhouse: Path,
    source_sourcehouse: Path,
    destination_wheelhouse: Path,
    destination_sourcehouse: Path,
    authorize: bool,
    config_path: Path = ROOT / CONFIG_RELATIVE,
) -> dict[str, Any]:
    """Copy the frozen closure with exclusive byte writes and no filesystem clone API."""

    if authorize is not True:
        raise PermissionError("explicit offline input copy authorization is required")
    config = load_execution_config(config_path)
    remote_root = Path(config["remote_layout"]["remote_root"])
    manifest = verify_offline_inputs_manifest(
        manifest_path=manifest_path,
        wheelhouse=source_wheelhouse,
        sourcehouse=source_sourcehouse,
        config_path=config_path,
    )
    source_wheels = require_unlinked_directory(
        source_wheelhouse, label="published offline wheel source"
    )
    source_sources = require_unlinked_directory(
        source_sourcehouse, label="published offline source archive source"
    )
    destination_wheels = require_unlinked_directory(
        destination_wheelhouse, label="private runtime wheel copy destination"
    )
    destination_sources = require_unlinked_directory(
        destination_sourcehouse, label="private runtime source copy destination"
    )
    for destination in (destination_wheels, destination_sources):
        _relative_inside(destination, remote_root)
        if any(destination.iterdir()):
            raise RuntimeError("offline input copy destination is not empty")
    if (
        source_wheels.resolve(strict=True) == destination_wheels.resolve(strict=True)
        or source_sources.resolve(strict=True) == destination_sources.resolve(strict=True)
    ):
        raise RuntimeError("offline input copy source and destination are identical")
    records = _expected_offline_input_records(config)
    copied: dict[str, dict[str, Any]] = {}
    for name, record in records.items():
        if record["kind"] == "binary_wheel":
            source_root = source_wheels
            destination_root = destination_wheels
        else:
            source_root = source_sources
            destination_root = destination_sources
        source = require_regular_unlinked_file(
            source_root / name, root=source_root, label="offline input copy source"
        )
        destination = destination_root / name
        if path_exists(destination):
            raise RuntimeError(f"offline input copy target already exists: {destination}")
        with source.open("rb") as reader, destination.open("xb") as writer:
            shutil.copyfileobj(reader, writer, length=1024 * 1024)
            writer.flush()
            os.fsync(writer.fileno())
        copied_file = require_regular_unlinked_file(
            destination, root=destination_root, label="offline input byte copy"
        )
        copied_record = {
            "kind": record["kind"],
            "size": copied_file.stat().st_size,
            "sha256": sha256_file(copied_file),
        }
        if copied_record != record:
            raise RuntimeError(f"offline input byte copy differs: {name}")
        copied[name] = copied_record
    verified = verify_offline_inputs_manifest(
        manifest_path=manifest_path,
        wheelhouse=destination_wheels,
        sourcehouse=destination_sources,
        config_path=config_path,
    )
    payload: dict[str, Any] = {
        "schema_version": "tukf09_455_hpc_offline_runtime_input_copy_a800_exclusive_v2r6",
        "experiment_id": EXPERIMENT_ID,
        "status": "LOCKED_RUNTIME_INPUTS_COPIED_AS_EXCLUSIVE_BUFFERED_BYTES",
        "offline_input_manifest_sha256": sha256_file(manifest_path),
        "offline_input_identity_sha256": manifest["identity_sha256"],
        "copy_mode": config["offline_runtime_inputs"]["compute_copy_mode"],
        "copied_file_count": len(copied),
        "copied_total_bytes": sum(int(record["size"]) for record in copied.values()),
        "copied_files": dict(sorted(copied.items())),
        "post_copy_manifest_identity_sha256": verified["identity_sha256"],
        "scientific_contract_changed": False,
        "formal_evaluation_authorized": False,
        "evaluation_array_reads": 0,
        "evaluation_predictions": 0,
        "evaluation_metrics": 0,
        "evaluation_outputs": 0,
    }
    payload["identity_sha256"] = _payload_identity(payload)
    return payload


def freeze_private_runtime_manifest(
    *,
    pysite: Path,
    wheelhouse: Path,
    pip_command_file: Path,
    pip_stdout_file: Path,
    pip_stderr_file: Path,
    offline_input_manifest: Path,
    output: Path,
    config_path: Path = ROOT / CONFIG_RELATIVE,
) -> dict[str, Any]:
    config = load_execution_config(config_path)
    remote_root = Path(config["remote_layout"]["remote_root"])
    site = Path(pysite)
    wheels = Path(wheelhouse)
    _relative_inside(site, remote_root)
    _relative_inside(wheels, remote_root)
    if not site.is_dir() or site.is_symlink() or not wheels.is_dir() or wheels.is_symlink():
        raise RuntimeError("private runtime directories are absent or linked")
    site_inventory = _inventory_regular_files(site)
    wheel_inventory = _inventory_regular_files(wheels)
    if not wheel_inventory or any(not name.endswith((".whl", ".tar.gz")) for name in wheel_inventory):
        raise RuntimeError("wheelhouse contains an unexpected member")
    command_bytes = require_regular_unlinked_file(
        pip_command_file, root=remote_root, label="pip command evidence"
    ).read_bytes()
    stdout_bytes = require_regular_unlinked_file(
        pip_stdout_file, root=remote_root, label="pip stdout evidence"
    ).read_bytes()
    stderr_bytes = require_regular_unlinked_file(
        pip_stderr_file, root=remote_root, label="pip stderr evidence"
    ).read_bytes()
    try:
        pip_command = command_bytes.decode("utf-8").rstrip("\n")
        pip_stdout = stdout_bytes.decode("utf-8")
        pip_stderr = stderr_bytes.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise RuntimeError("pip evidence is not UTF-8") from exc
    distributions = _private_distribution_versions(site)
    expected_distributions = config["private_runtime_provenance"][
        "expected_distribution_versions"
    ]
    if distributions != expected_distributions:
        raise RuntimeError("private distribution closure differs from the frozen closure")
    targets = config["private_runtime_provenance"]["target_versions"]
    if distributions.get("numpy") != targets["numpy"]:
        raise RuntimeError("private NumPy version differs")
    if distributions.get("psutil") != targets["psutil"]:
        raise RuntimeError("private psutil version differs")
    torch_full = distributions.get("torch", "")
    if torch_full.split("+", 1)[0] != targets["torch"]:
        raise RuntimeError("private PyTorch base version differs")
    lock_evidence = _verify_wheelhouse_against_locks(wheel_inventory)
    offline = verify_offline_inputs_manifest(manifest_path=offline_input_manifest)
    interpreter = _current_python_executable_evidence()
    if (
        interpreter["python_executable"]
        != config["private_runtime_provenance"]["required_bootstrap_python_executable"]
        or interpreter["python_version"]
        != config["required_hpc_runtime"]["python_version"]
    ):
        raise RuntimeError("the bootstrap Python interpreter differs from the frozen runtime")
    payload: dict[str, Any] = {
        "schema_version": "tukf09_455_hpc_private_runtime_manifest_a800_exclusive_v2r6",
        "experiment_id": EXPERIMENT_ID,
        "status": "PRIVATE_RUNTIME_FROZEN_NOT_A_SCIENTIFIC_CONTRACT_CHANGE",
        "target_versions": dict(targets),
        "distribution_versions": distributions,
        "torch_full_distribution_version": torch_full,
        "wheel_sha256_by_filename": {
            name: digest for name, (digest, _) in wheel_inventory.items()
        },
        "wheel_size_by_filename": {
            name: size for name, (_, size) in wheel_inventory.items()
        },
        "pip_command": pip_command,
        "pip_command_sha256": sha256_bytes(command_bytes),
        "pip_stdout": pip_stdout,
        "pip_stdout_sha256": sha256_bytes(stdout_bytes),
        "pip_stderr": pip_stderr,
        "pip_stderr_sha256": sha256_bytes(stderr_bytes),
        "pysite_file_sha256": {
            name: digest for name, (digest, _) in site_inventory.items()
        },
        "pysite_file_size": {name: size for name, (_, size) in site_inventory.items()},
        "offline_input_manifest_sha256": sha256_file(offline_input_manifest),
        "offline_input_identity_sha256": offline["identity_sha256"],
        "offline_input_total_file_count": offline["total_file_count"],
        "offline_input_total_bytes": offline["total_bytes"],
        "offline_input_copy_mode": config["offline_runtime_inputs"]["compute_copy_mode"],
        **lock_evidence,
        **interpreter,
        "private_dependency_closure_complete": True,
        "shared_nh_final_modified": False,
    }
    payload["identity_sha256"] = _payload_identity(payload)
    write_canonical_json_exclusive(output, payload)
    return payload


def _inside(candidate: Path, root: Path) -> bool:
    try:
        Path(candidate).resolve(strict=True).relative_to(Path(root).resolve(strict=True))
    except (FileNotFoundError, ValueError):
        return False
    return True


def verify_private_runtime_manifest(
    *,
    manifest_path: Path,
    pysite: Path,
    wheelhouse: Path,
    import_check: bool,
    config_path: Path = ROOT / CONFIG_RELATIVE,
) -> dict[str, Any]:
    config = load_execution_config(config_path)
    remote_root = Path(config["remote_layout"]["remote_root"])
    manifest = read_json(manifest_path, root=remote_root, canonical=True)
    if (
        manifest.get("schema_version")
        != config["private_runtime_provenance"]["schema_version"]
        or manifest.get("experiment_id") != EXPERIMENT_ID
        or manifest.get("private_dependency_closure_complete") is not True
        or manifest.get("shared_nh_final_modified") is not False
    ):
        raise RuntimeError("private runtime manifest changed scope")
    _verify_payload_identity(manifest, label="private runtime manifest")
    offline_manifest_path = Path(
        config["remote_layout"]["offline_runtime_inputs_manifest"]
    )
    offline = verify_offline_inputs_manifest(manifest_path=offline_manifest_path)
    if (
        manifest.get("offline_input_manifest_sha256")
        != sha256_file(offline_manifest_path)
        or manifest.get("offline_input_identity_sha256") != offline.get("identity_sha256")
        or manifest.get("offline_input_total_file_count") != offline.get("total_file_count")
        or manifest.get("offline_input_total_bytes") != offline.get("total_bytes")
        or manifest.get("offline_input_copy_mode")
        != config["offline_runtime_inputs"]["compute_copy_mode"]
    ):
        raise RuntimeError("private runtime no longer matches its frozen offline inputs")
    site_inventory = _inventory_regular_files(pysite)
    wheel_inventory = _inventory_regular_files(wheelhouse)
    lock_evidence = _verify_wheelhouse_against_locks(wheel_inventory)
    expected_site_hash = manifest.get("pysite_file_sha256")
    expected_site_size = manifest.get("pysite_file_size")
    expected_wheels = manifest.get("wheel_sha256_by_filename")
    expected_wheel_sizes = manifest.get("wheel_size_by_filename")
    if (
        not isinstance(expected_site_hash, dict)
        or not isinstance(expected_site_size, dict)
        or not isinstance(expected_wheels, dict)
        or not isinstance(expected_wheel_sizes, dict)
        or {name: digest for name, (digest, _) in site_inventory.items()}
        != expected_site_hash
        or {name: size for name, (_, size) in site_inventory.items()} != expected_site_size
        or {name: digest for name, (digest, _) in wheel_inventory.items()}
        != expected_wheels
        or {name: size for name, (_, size) in wheel_inventory.items()}
        != expected_wheel_sizes
    ):
        raise RuntimeError("private runtime file inventory differs")
    distributions = _private_distribution_versions(pysite)
    expected_distributions = config["private_runtime_provenance"][
        "expected_distribution_versions"
    ]
    if (
        distributions != manifest.get("distribution_versions")
        or distributions != expected_distributions
    ):
        raise RuntimeError("private distribution closure differs")
    if any(manifest.get(key) != value for key, value in lock_evidence.items()):
        raise RuntimeError("private runtime no longer matches its dependency locks")
    interpreter = _current_python_executable_evidence()
    if (
        interpreter["python_executable"]
        != config["private_runtime_provenance"]["required_bootstrap_python_executable"]
        or interpreter["python_version"]
        != config["required_hpc_runtime"]["python_version"]
        or any(manifest.get(key) != value for key, value in interpreter.items())
    ):
        raise RuntimeError("private runtime Python interpreter differs")
    targets = config["private_runtime_provenance"]["target_versions"]
    if (
        distributions.get("numpy") != targets["numpy"]
        or distributions.get("psutil") != targets["psutil"]
        or distributions.get("torch", "").split("+", 1)[0] != targets["torch"]
    ):
        raise RuntimeError("private target package versions differ")
    if import_check:
        import numpy as np
        import psutil
        import torch

        origins = {
            "numpy": Path(np.__file__).resolve(strict=True),
            "psutil": Path(psutil.__file__).resolve(strict=True),
            "torch": Path(torch.__file__).resolve(strict=True),
        }
        if not all(_inside(path, pysite) for path in origins.values()):
            raise RuntimeError("a target package was imported outside the private runtime")
        if (
            np.__version__ != targets["numpy"]
            or psutil.__version__ != targets["psutil"]
            or str(torch.__version__).split("+", 1)[0] != targets["torch"]
        ):
            raise RuntimeError("imported private target package versions differ")
    return manifest


def configure_deterministic_cuda() -> None:
    import torch

    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False


def _current_process_gpu_uuid() -> str:
    query = subprocess.run(
        [
            "nvidia-smi",
            "--query-compute-apps=gpu_uuid,pid",
            "--format=csv,noheader,nounits",
        ],
        check=True,
        capture_output=True,
        text=True,
        timeout=15,
    )
    matches: set[str] = set()
    for row in query.stdout.splitlines():
        fields = [field.strip() for field in row.split(",")]
        if len(fields) != 2:
            continue
        try:
            pid = int(fields[1])
        except ValueError:
            continue
        if pid == os.getpid() and fields[0].startswith("GPU-"):
            matches.add(fields[0])
    if len(matches) != 1:
        raise RuntimeError("nvidia-smi did not bind the current PyTorch process to one GPU UUID")
    return next(iter(matches))


def _parse_slurm_job_cpus_per_node(value: str) -> tuple[int, int]:
    match = re.fullmatch(r"([1-9][0-9]*)(?:\(x([1-9][0-9]*)\))?", str(value))
    if match is None:
        raise RuntimeError(
            "SLURM_JOB_CPUS_PER_NODE is not one accepted single-node format"
        )
    return int(match.group(1)), int(match.group(2) or "1")


def _exclusive_node_runtime_evidence(
    config: Mapping[str, Any],
) -> dict[str, Any]:
    slurm = config.get("slurm")
    contract = (
        slurm.get("exclusive_node_runtime_evidence_contract")
        if isinstance(slurm, Mapping)
        else None
    )
    if not isinstance(contract, Mapping):
        raise RuntimeError("exclusive-node runtime evidence contract is absent")
    raw_job_cpus = os.environ.get("SLURM_JOB_CPUS_PER_NODE", "")
    cpus_per_node, node_count = _parse_slurm_job_cpus_per_node(raw_job_cpus)

    def required_environment_integer(name: str) -> int:
        raw = os.environ.get(name, "")
        if re.fullmatch(r"[1-9][0-9]*", raw) is None:
            raise RuntimeError(
                "Slurm whole-node CPU runtime evidence differs from the exclusive-node contract"
            )
        return int(raw)

    cpus_on_node = required_environment_integer("SLURM_CPUS_ON_NODE")
    cpus_per_task = required_environment_integer("SLURM_CPUS_PER_TASK")
    accepted_formats = contract.get("accepted_slurm_job_cpus_per_node_formats")
    if (
        contract.get("exclusive_node_runtime_evidence_passed_required") is not True
        or not isinstance(accepted_formats, list)
        or raw_job_cpus not in accepted_formats
        or node_count != int(contract.get("expected_node_count", -1))
        or cpus_per_node != int(contract.get("expected_cpus_per_node", -1))
        or cpus_on_node != int(contract.get("expected_slurm_cpus_on_node", -1))
        or cpus_per_task != int(contract.get("expected_slurm_cpus_per_task", -1))
        or not isinstance(slurm, Mapping)
        or slurm.get("nodes") != node_count
        or slurm.get("cpus_per_task") != cpus_per_task
        or slurm.get("exclusive_node") is not True
    ):
        raise RuntimeError(
            "Slurm whole-node CPU runtime evidence differs from the exclusive-node contract"
        )
    return {
        "slurm_job_cpus_per_node_raw": raw_job_cpus,
        "slurm_job_cpus_per_node_normalized": cpus_per_node,
        "slurm_job_node_count": node_count,
        "slurm_cpus_on_node": cpus_on_node,
        "slurm_cpus_per_task": cpus_per_task,
        "exclusive_node_runtime_evidence_passed": True,
    }


def runtime_identity(
    *,
    require_slurm: bool = True,
    config: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    import numpy as np
    import psutil
    import torch

    if require_slurm and not os.environ.get("SLURM_JOB_ID"):
        raise RuntimeError("HPC runtime probe must run inside Slurm")
    execution_config = load_execution_config() if config is None else config
    exclusive_node_evidence = _exclusive_node_runtime_evidence(execution_config)
    configure_deterministic_cuda()
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError("exactly one Slurm-visible CUDA device is required")
    device = torch.device("cuda:0")
    properties = torch.cuda.get_device_properties(device)
    if torch.cuda.get_device_name(device) != "NVIDIA A800-SXM4-80GB":
        raise RuntimeError("the visible CUDA device is not an NVIDIA A800-SXM4-80GB")
    if tuple(torch.cuda.get_device_capability(device)) != (8, 0):
        raise RuntimeError("A800 compute capability changed")
    torch.zeros(1, device=device)
    torch.cuda.synchronize(device)
    torch_process_gpu_uuid = _current_process_gpu_uuid()
    global_gpu_text = (
        os.environ.get("SLURM_STEP_GPUS")
        or os.environ.get("SLURM_JOB_GPUS")
        or ""
    )
    global_gpu_ids = [value.strip() for value in global_gpu_text.split(",") if value.strip()]
    if len(global_gpu_ids) != 1:
        raise RuntimeError("Slurm did not expose one unambiguous global GPU identifier")
    query = subprocess.run(
        [
            "nvidia-smi",
            "--id",
            global_gpu_ids[0],
            "--query-gpu=uuid,driver_version,memory.total",
            "--format=csv,noheader,nounits",
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    rows = [row.strip() for row in query.stdout.splitlines() if row.strip()]
    if len(rows) != 1:
        raise RuntimeError("nvidia-smi did not expose exactly one Slurm-visible device")
    fields = [field.strip() for field in rows[0].split(",")]
    if len(fields) != 3:
        raise RuntimeError("nvidia-smi runtime identity format changed")
    if fields[0] != torch_process_gpu_uuid:
        raise RuntimeError("PyTorch cuda:0 is not the Slurm-assigned physical GPU")
    return {
        "schema_version": "tukf09_455_hpc_runtime_identity_a800_exclusive_v2r6",
        "python_version": platform.python_version(),
        "python_executable": sys.executable,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "numpy_version": np.__version__,
        "torch_version": str(torch.__version__),
        "torch_base_version": str(torch.__version__).split("+", 1)[0],
        "psutil_version": psutil.__version__,
        "torch_cuda_runtime_version": str(torch.version.cuda),
        "cudnn_version": int(torch.backends.cudnn.version() or 0),
        "cuda_available": True,
        "cuda_device_count": 1,
        "cuda_device_name": torch.cuda.get_device_name(device),
        "cuda_compute_capability": list(torch.cuda.get_device_capability(device)),
        "cuda_device_total_memory_bytes": int(properties.total_memory),
        "nvidia_gpu_uuid": fields[0],
        "torch_process_gpu_uuid": torch_process_gpu_uuid,
        "slurm_global_gpu_id": global_gpu_ids[0],
        "nvidia_driver_version": fields[1],
        "nvidia_reported_memory_total_mib": int(fields[2]),
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES", ""),
        "slurm_job_id": os.environ.get("SLURM_JOB_ID", ""),
        "slurm_job_gpus": os.environ.get("SLURM_JOB_GPUS", ""),
        "slurm_step_gpus": os.environ.get("SLURM_STEP_GPUS", ""),
        "selected_global_gpu_id": global_gpu_ids[0],
        "slurm_gpus_on_node": os.environ.get("SLURM_GPUS_ON_NODE", ""),
        "slurm_gpu_allocation_variable_present": True,
        "hostname": socket.gethostname(),
        "logical_cpu_count": os.cpu_count(),
        "tensorfloat32": {
            "cuda_matmul": bool(torch.backends.cuda.matmul.allow_tf32),
            "cudnn": bool(torch.backends.cudnn.allow_tf32),
        },
        **exclusive_node_evidence,
    }


def verify_runtime_against_config(identity: Mapping[str, Any], config: Mapping[str, Any]) -> None:
    required = config["required_hpc_runtime"]
    slurm = config["slurm"]
    exclusive = slurm["exclusive_node_runtime_evidence_contract"]
    if (
        identity.get("python_version") != required["python_version"]
        or identity.get("numpy_version") != required["numpy_version"]
        or identity.get("torch_base_version") != required["torch_base_version"]
        or identity.get("psutil_version") != required["psutil_version"]
        or identity.get("torch_cuda_runtime_version")
        != required["torch_cuda_runtime_version"]
        or identity.get("cuda_available") is not True
        or identity.get("cuda_device_count") != 1
        or identity.get("cuda_device_name") != required["cuda_device_name"]
        or identity.get("cuda_compute_capability")
        != required["cuda_compute_capability"]
        or int(identity.get("cuda_device_total_memory_bytes", 0))
        < int(required["minimum_cuda_device_total_memory_bytes"])
        or identity.get("tensorfloat32") != {"cuda_matmul": False, "cudnn": False}
        or slurm.get("require_slurm_gpu_allocation_variable") is not True
        or identity.get("slurm_gpu_allocation_variable_present") is not True
        or identity.get("slurm_job_cpus_per_node_raw")
        not in exclusive["accepted_slurm_job_cpus_per_node_formats"]
        or identity.get("slurm_job_cpus_per_node_normalized")
        != exclusive["expected_cpus_per_node"]
        or identity.get("slurm_job_node_count") != exclusive["expected_node_count"]
        or identity.get("slurm_cpus_on_node")
        != exclusive["expected_slurm_cpus_on_node"]
        or identity.get("slurm_cpus_per_task")
        != exclusive["expected_slurm_cpus_per_task"]
        or identity.get("exclusive_node_runtime_evidence_passed") is not True
    ):
        raise RuntimeError("current HPC runtime differs from the technical execution config")
    expected_full = required.get("torch_full_version")
    expected_cudnn = required.get("cudnn_version")
    if expected_full is not None and identity.get("torch_version") != expected_full:
        raise RuntimeError("full PyTorch build identity differs")
    if expected_cudnn is not None and identity.get("cudnn_version") != expected_cudnn:
        raise RuntimeError("cuDNN runtime identity differs")


def _selected_raw_records(
    *, population: Mapping[str, Any], raw_manifest: Mapping[str, Any]
) -> tuple[list[str], dict[str, dict[str, Any]]]:
    basins = population.get("eligible")
    files = raw_manifest.get("files")
    if (
        not isinstance(basins, list)
        or len(basins) != 455
        or len(set(basins)) != 455
        or "08202700" in basins
        or not isinstance(files, dict)
    ):
        raise RuntimeError("sealed 455-basin population or raw manifest changed")
    newline_hash = sha256_bytes(("\n".join(basins) + "\n").encode("ascii"))
    compact_hash = sha256_bytes(
        json.dumps(basins, separators=(",", ":"), ensure_ascii=True).encode("ascii")
    )
    if (
        newline_hash != population.get("eligible_ordered_newline_utf8_sha256")
        or compact_hash != population.get("eligible_compact_json_sha256")
    ):
        raise RuntimeError("sealed population hashes changed")
    basin_set = set(basins)
    selected: dict[str, dict[str, Any]] = {}
    count_by_basin = {basin: 0 for basin in basins}
    for relative, record in files.items():
        pure = PurePosixPath(str(relative))
        if pure.is_absolute() or ".." in pure.parts or "\\" in str(relative):
            raise RuntimeError(f"unsafe raw source member: {relative}")
        basin = pure.name[:8]
        if basin not in basin_set:
            continue
        if (
            not isinstance(record, dict)
            or set(record) != {"sha256", "size_bytes"}
            or HEX64.fullmatch(str(record["sha256"])) is None
            or int(record["size_bytes"]) <= 0
        ):
            raise RuntimeError(f"invalid raw source record: {relative}")
        text = pure.as_posix()
        if not (
            text.startswith("basin_mean_forcing/maurer/")
            or text.startswith("usgs_streamflow/")
        ):
            raise RuntimeError(f"unexpected selected raw source: {relative}")
        selected[text] = {"sha256": str(record["sha256"]), "size_bytes": int(record["size_bytes"])}
        count_by_basin[basin] += 1
    if len(selected) != 910 or set(count_by_basin.values()) != {2}:
        raise RuntimeError("selected raw source surface is not two files for each of 455 basins")
    return [str(value) for value in basins], dict(sorted(selected.items()))


def _expected_stage_records(
    *, project_root: Path, source_root: Path, config: Mapping[str, Any]
) -> tuple[list[str], dict[str, dict[str, Any]]]:
    population = read_json(project_root / POPULATION_RELATIVE, root=project_root)
    raw_manifest = read_json(project_root / RAW_MANIFEST_RELATIVE, root=project_root)
    basins, selected = _selected_raw_records(population=population, raw_manifest=raw_manifest)
    topography_relative = config["data_staging"]["topography_relative_path"]
    selected[str(topography_relative)] = {
        "sha256": config["data_staging"]["topography_sha256"],
        "size_bytes": int(config["data_staging"]["topography_size_bytes"]),
    }
    if len(selected) != 911:
        raise RuntimeError("staged source inventory is not exactly 911 files")
    return basins, dict(sorted(selected.items()))


def verify_staged_training_sources(
    *, destination_root: Path, records: Mapping[str, Mapping[str, Any]]
) -> dict[str, Any]:
    root = require_unlinked_directory(destination_root, label="staged CAMELS root")
    actual_names = {
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_file() or path.is_symlink()
    }
    if actual_names != set(records):
        raise RuntimeError("staged CAMELS file inventory differs")
    total = 0
    for relative, record in records.items():
        path = require_regular_unlinked_file(
            root.joinpath(*PurePosixPath(relative).parts),
            root=root,
            label="staged training source",
        )
        if path.stat().st_size != int(record["size_bytes"]) or sha256_file(path) != record["sha256"]:
            raise RuntimeError(f"staged training source differs: {relative}")
        total += path.stat().st_size
    return {"file_count": len(records), "total_size_bytes": total}


def stage_training_sources(
    *,
    project_root: Path,
    source_root: Path,
    destination_root: Path,
    manifest_path: Path,
    pending_parent: Path | None = None,
    config_path: Path = ROOT / CONFIG_RELATIVE,
) -> dict[str, Any]:
    config = load_execution_config(config_path)
    project = require_unlinked_directory(project_root, label="HPC project root")
    verify_training_source_capsule(
        source_root=source_root,
        config_path=config_path,
    )
    source = require_unlinked_directory(source_root, label="shared training source root")
    destination = require_unlinked_existing_chain(
        destination_root,
        root=project,
        label="staged training destination",
    )
    basins, records = _expected_stage_records(
        project_root=project, source_root=source, config=config
    )
    evidence_root = require_unlinked_directory(
        Path(pending_parent) if pending_parent is not None else Path(manifest_path).parent,
        label="staged-data evidence root",
    )
    if path_exists(destination):
        require_regular_unlinked_file(
            manifest_path,
            root=evidence_root,
            label="completed staged training source manifest",
        )
        verification = verify_staged_training_sources(
            destination_root=destination, records=records
        )
        reused = True
    else:
        destination.parent.mkdir(parents=True, exist_ok=True)
        if path_exists(manifest_path):
            raise RuntimeError("staged-source manifest exists before destination reservation")
        destination.mkdir(parents=False, exist_ok=False)
        for relative, record in records.items():
            source_path = require_regular_unlinked_file(
                source.joinpath(*PurePosixPath(relative).parts),
                root=source,
                label="shared read-only training source",
            )
            if source_path.stat().st_size != int(record["size_bytes"]) or sha256_file(source_path) != record["sha256"]:
                raise RuntimeError(f"shared training source differs: {relative}")
            target = destination.joinpath(*PurePosixPath(relative).parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with source_path.open("rb") as reader, target.open("xb") as writer:
                shutil.copyfileobj(reader, writer, length=1024 * 1024)
                writer.flush()
                os.fsync(writer.fileno())
            if target.stat().st_nlink != 1:
                raise RuntimeError(f"staged target is hard-linked: {target}")
        verification = verify_staged_training_sources(
            destination_root=destination, records=records
        )
        reused = False
    payload: dict[str, Any] = {
        "schema_version": "tukf09_455_hpc_staged_training_sources_a800_exclusive_v2r6",
        "experiment_id": EXPERIMENT_ID,
        "status": "STAGED_455_TRAINING_VALIDATION_SOURCE_FILES_EVALUATION_HOLD",
        "ordered_basin_ids": basins,
        "file_sha256": {name: value["sha256"] for name, value in records.items()},
        "file_size": {name: int(value["size_bytes"]) for name, value in records.items()},
        "file_count": verification["file_count"],
        "total_size_bytes": verification["total_size_bytes"],
        **expected_source_capsule_evidence(config),
        "evaluation_array_reads": 0,
        "evaluation_predictions": 0,
        "evaluation_metrics": 0,
        "evaluation_outputs": 0,
        "publication_policy": "exclusive_destination_reservation_no_overwrite_freeze_root_on_failure",
        "existing_tree_policy": "exact_verify_only_no_overwrite",
    }
    payload["identity_sha256"] = _payload_identity(payload)
    write_canonical_json_exclusive(manifest_path, payload)
    return {**payload, "reused_exact_existing_tree": reused}


def _run_checked(command: Sequence[str], *, cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        list(command), cwd=cwd, check=True, text=True, capture_output=True
    )


def prepare_filter_installation(*, project_root: Path) -> dict[str, Any]:
    project = Path(project_root)
    results = project / RESULTS_ROOT_RELATIVE
    python = sys.executable
    if not path_exists(results):
        _run_checked(
            [python, "-B", "scripts/initialize_tukf09_455_formal_training.py", "--initialize"],
            cwd=project,
        )
    _run_checked(
        [
            python,
            "-B",
            "scripts/install_tukf09_455_filter_results.py",
            "--migration-root",
            os.fspath(project / MIGRATION_ROOT_RELATIVE),
            "--results-root",
            os.fspath(results),
            "--training-admission",
            os.fspath(project / ORIGINAL_ADMISSION_RELATIVE),
            "--authorize-filter-installation",
        ],
        cwd=project,
    )
    completed = _run_checked(
        [
            python,
            "-B",
            "scripts/verify_tukf09_455_filter_installation.py",
            "--migration-root",
            os.fspath(project / MIGRATION_ROOT_RELATIVE),
            "--results-root",
            os.fspath(results),
            "--training-admission",
            os.fspath(project / ORIGINAL_ADMISSION_RELATIVE),
            "--authorize-independent-filter-installation",
            "--publish",
        ],
        cwd=project,
    )
    seal = require_regular_unlinked_file(
        project / REMOTE_FILTER_SEAL_RELATIVE,
        root=project,
        label="remote independent filter installation seal",
    )
    return {
        "status": "REMOTE_FILTER_INSTALLATION_VERIFIED_455_EVALUATION_HOLD",
        "remote_filter_installation_final_sha256": sha256_file(seal),
        "verifier_stdout_sha256": sha256_bytes(completed.stdout.encode("utf-8")),
        "evaluation_array_reads": 0,
        "evaluation_predictions": 0,
        "evaluation_metrics": 0,
        "evaluation_outputs": 0,
    }


def _bundle_manifest_path(project_root: Path) -> Path:
    return Path(project_root).parent / "bundle_manifest.json"


def verify_or_publish_initial_bundle_verification(
    *, project_root: Path, output: Path, config_path: Path = ROOT / CONFIG_RELATIVE
) -> dict[str, Any]:
    """Bind one strict pristine-bundle verification before any mutable tree exists."""

    config = load_execution_config(config_path)
    remote_root = Path(config["remote_layout"]["remote_root"])
    project = require_unlinked_directory(project_root, label="HPC project root")
    bundle_root = require_unlinked_directory(project.parent, label="HPC bundle root")
    manifest = require_regular_unlinked_file(
        _bundle_manifest_path(project), root=bundle_root, label="bundle manifest"
    )
    builder = require_regular_unlinked_file(
        project / "scripts/build_tukf09_455_a800_exclusive_hpc_bundle_v2r6.py",
        root=project,
        label="strict bundle verifier",
    )
    expected = {
        "schema_version": "tukf09_455_hpc_initial_bundle_verification_a800_exclusive_v2r6",
        "experiment_id": EXPERIMENT_ID,
        "status": "STRICT_PRISTINE_A800_EXCLUSIVE_V2R6_BUNDLE_VERIFIED_BEFORE_RUNTIME_MUTATION",
        "bundle_manifest_sha256": sha256_file(manifest),
        "strict_verifier_sha256": sha256_file(builder),
        "member_count": 2808,
        "admitted_executable_count": 30,
        "admitted_test_count": 12,
        "formal_evaluation_output_count": 0,
        "mutable_file_count_at_verification": 0,
        "mutable_directory_count_at_verification": 0,
        "scientific_contract_changed": False,
    }
    destination = require_unlinked_existing_chain(
        output, root=remote_root, label="initial bundle verification evidence"
    )
    if path_exists(destination):
        payload = read_json(destination, root=remote_root, canonical=True)
        _verify_payload_identity(payload, label="initial bundle verification")
        if any(payload.get(key) != value for key, value in expected.items()):
            raise RuntimeError("initial strict bundle verification evidence differs")
        return payload

    from scripts.build_tukf09_455_a800_exclusive_hpc_bundle_v2r6 import verify_extracted_bundle

    strict = verify_extracted_bundle(bundle_root)
    if (
        strict.get("status") != "TUKF09_455_A800_EXCLUSIVE_V2R6_HPC_BUNDLE_VERIFIED"
        or strict.get("experiment_id") != EXPERIMENT_ID
        or strict.get("member_count") != 2808
        or strict.get("formal_evaluation_output_count") != 0
    ):
        raise RuntimeError("strict initial bundle verifier returned an unexpected result")
    payload = dict(expected)
    payload["identity_sha256"] = _payload_identity(payload)
    write_canonical_json_exclusive(destination, payload)
    return payload


def _default_contract_destination(project_root: Path, config: Mapping[str, Any]) -> Path:
    if os.name != "posix":
        raise RuntimeError("the frozen drive-letter data path can only be staged on POSIX here")
    relative = PurePosixPath(config["remote_layout"]["staged_camels_root_from_project"])
    if relative.is_absolute() or ".." in relative.parts:
        raise RuntimeError("frozen staged CAMELS path is unsafe")
    return Path(project_root).joinpath(*relative.parts)


def create_preparation_probe(
    *,
    project_root: Path,
    source_root: Path,
    pysite: Path,
    wheelhouse: Path,
    private_manifest: Path,
    staged_manifest: Path,
    output: Path,
    config_path: Path = ROOT / CONFIG_RELATIVE,
) -> dict[str, Any]:
    config = load_execution_config(config_path)
    project = Path(project_root)
    initial_path = Path(config["remote_layout"]["initial_bundle_verification"])
    initial_bundle = verify_or_publish_initial_bundle_verification(
        project_root=project,
        output=initial_path,
        config_path=config_path,
    )
    private = verify_private_runtime_manifest(
        manifest_path=private_manifest,
        pysite=pysite,
        wheelhouse=wheelhouse,
        import_check=True,
        config_path=config_path,
    )
    runtime = runtime_identity(require_slurm=True, config=config)
    verify_runtime_against_config(runtime, config)
    destination = _default_contract_destination(project, config)
    staged = stage_training_sources(
        project_root=project,
        source_root=source_root,
        destination_root=destination,
        manifest_path=staged_manifest,
        pending_parent=Path(config["remote_layout"]["staging_pending_parent"]),
        config_path=config_path,
    )
    capsule_evidence = verify_source_capsule_evidence(
        staged,
        config=config,
        label="staged training source manifest",
    )
    filter_result = prepare_filter_installation(project_root=project)
    bundle_manifest = require_regular_unlinked_file(
        _bundle_manifest_path(project),
        root=project.parent,
        label="extracted bundle manifest",
    )
    payload: dict[str, Any] = {
        "schema_version": "tukf09_455_hpc_preparation_probe_a800_exclusive_v2r6",
        "experiment_id": EXPERIMENT_ID,
        "status": "HPC_A800_EXCLUSIVE_V2R6_PREPARED_FILTERS_455_NEURAL_0_OF_9_EVALUATION_HOLD",
        "runtime": runtime,
        "bundle_manifest_sha256": sha256_file(bundle_manifest),
        "initial_bundle_verification_sha256": sha256_file(initial_path),
        "initial_bundle_verification_identity_sha256": initial_bundle[
            "identity_sha256"
        ],
        "private_runtime_manifest_sha256": sha256_file(private_manifest),
        "private_runtime_identity_sha256": private["identity_sha256"],
        "offline_input_manifest_sha256": private["offline_input_manifest_sha256"],
        "offline_input_identity_sha256": private["offline_input_identity_sha256"],
        "staged_sources_manifest_sha256": sha256_file(staged_manifest),
        "staged_sources_identity_sha256": staged["identity_sha256"],
        **capsule_evidence,
        "remote_filter_installation_final_sha256": filter_result[
            "remote_filter_installation_final_sha256"
        ],
        "filter_unit_count": 455,
        "neural_model_unit_count": 0,
        "evaluation_array_reads": 0,
        "evaluation_predictions": 0,
        "evaluation_metrics": 0,
        "evaluation_outputs": 0,
        "scientific_contract_changed": False,
    }
    payload["identity_sha256"] = _payload_identity(payload)
    write_canonical_json_exclusive(output, payload)
    return payload


def create_hpc_technical_admission(
    *,
    project_root: Path,
    probe_path: Path,
    private_manifest: Path,
    output: Path,
    authorize: bool,
    config_path: Path = ROOT / CONFIG_RELATIVE,
) -> dict[str, Any]:
    if authorize is not True:
        raise PermissionError("explicit HPC technical execution authorization is required")
    config = load_execution_config(config_path)
    project = Path(project_root)
    remote_root = Path(config["remote_layout"]["remote_root"])
    probe = read_json(probe_path, root=remote_root, canonical=True)
    if (
        probe.get("schema_version") != "tukf09_455_hpc_preparation_probe_a800_exclusive_v2r6"
        or probe.get("experiment_id") != EXPERIMENT_ID
        or probe.get("status")
        != "HPC_A800_EXCLUSIVE_V2R6_PREPARED_FILTERS_455_NEURAL_0_OF_9_EVALUATION_HOLD"
        or probe.get("scientific_contract_changed") is not False
        or type(probe.get("neural_model_unit_count")) is not int
        or probe.get("neural_model_unit_count") != 0
    ):
        raise RuntimeError("HPC preparation probe changed scope")
    require_zero_evaluation(probe, label="HPC preparation probe")
    _verify_payload_identity(probe, label="HPC preparation probe")
    private = read_json(private_manifest, root=remote_root, canonical=True)
    _verify_payload_identity(private, label="private runtime manifest")
    staged_path = Path(config["remote_layout"]["staged_sources_manifest"])
    staged = read_json(staged_path, root=remote_root, canonical=True)
    _verify_payload_identity(staged, label="staged training source manifest")
    capsule_evidence = verify_source_capsule_evidence(
        staged,
        config=config,
        label="staged training source manifest",
    )
    verify_source_capsule_evidence(
        probe,
        config=config,
        label="HPC preparation probe",
    )
    verify_training_source_capsule(
        source_root=Path(config["remote_layout"]["read_only_camels_root"]),
        config_path=config_path,
    )
    if (
        sha256_file(private_manifest) != probe.get("private_runtime_manifest_sha256")
        or private.get("identity_sha256")
        != probe.get("private_runtime_identity_sha256")
        or private.get("offline_input_manifest_sha256")
        != probe.get("offline_input_manifest_sha256")
        or private.get("offline_input_identity_sha256")
        != probe.get("offline_input_identity_sha256")
        or sha256_file(staged_path) != probe.get("staged_sources_manifest_sha256")
        or staged.get("identity_sha256") != probe.get("staged_sources_identity_sha256")
        or staged.get("file_count") != 911
        or staged.get("publication_policy")
        != "exclusive_destination_reservation_no_overwrite_freeze_root_on_failure"
    ):
        raise RuntimeError("staged training sources changed after the preparation probe")
    require_zero_evaluation(staged, label="staged training source manifest")
    initial_path = Path(config["remote_layout"]["initial_bundle_verification"])
    initial = verify_or_publish_initial_bundle_verification(
        project_root=project,
        output=initial_path,
        config_path=config_path,
    )
    if (
        sha256_file(initial_path) != probe.get("initial_bundle_verification_sha256")
        or initial.get("identity_sha256")
        != probe.get("initial_bundle_verification_identity_sha256")
    ):
        raise RuntimeError("initial strict bundle verification changed after preparation")
    seal_path = require_regular_unlinked_file(
        project / REMOTE_FILTER_SEAL_RELATIVE,
        root=project,
        label="remote independent filter installation seal",
    )
    if sha256_file(seal_path) != probe["remote_filter_installation_final_sha256"]:
        raise RuntimeError("remote filter installation changed after the probe")
    science = config["scientific_identity"]
    payload: dict[str, Any] = {
        "schema_version": "tukf09_455_hpc_technical_admission_a800_exclusive_v2r6",
        "experiment_id": EXPERIMENT_ID,
        "status": "HPC_A800_EXCLUSIVE_V2R6_TECHNICAL_EXECUTION_ADMITTED_FORMAL_EVALUATION_HOLD",
        "scientific_contract_sha256": science["scientific_contract"]["sha256"],
        "original_training_admission_file_sha256": science["original_training_admission"][
            "file_sha256"
        ],
        "original_training_admission_record_sha256": science[
            "original_training_admission"
        ]["record_sha256"],
        "local_filter_installation_final_sha256": science[
            "local_filter_installation_final_manifest"
        ]["sha256"],
        "remote_filter_installation_final_sha256": sha256_file(seal_path),
        "bundle_manifest_sha256": probe["bundle_manifest_sha256"],
        "initial_bundle_verification_sha256": sha256_file(initial_path),
        "initial_bundle_verification_identity_sha256": initial["identity_sha256"],
        "private_runtime_manifest_sha256": sha256_file(private_manifest),
        "private_runtime_identity_sha256": private["identity_sha256"],
        "offline_input_manifest_sha256": private["offline_input_manifest_sha256"],
        "offline_input_identity_sha256": private["offline_input_identity_sha256"],
        "staged_sources_manifest_sha256": sha256_file(staged_path),
        "staged_sources_identity_sha256": staged["identity_sha256"],
        **capsule_evidence,
        "preparation_probe_sha256": sha256_file(probe_path),
        "preparation_probe_identity_sha256": probe["identity_sha256"],
        "admitted_runtime": probe["runtime"],
        "ordered_basin_count": 455,
        "neural_model_order": [
            f"lead_{lead}_seed_{seed}" for lead in (1, 2, 3) for seed in (0, 1, 2)
        ],
        "neural_model_parallelism": 1,
        "exclusive_node_required": True,
        "exclusive_node_runtime_evidence_passed": probe["runtime"].get(
            "exclusive_node_runtime_evidence_passed"
        )
        is True,
        "formal_evaluation_authorized": False,
        "evaluation_array_reads": 0,
        "evaluation_predictions": 0,
        "evaluation_metrics": 0,
        "evaluation_outputs": 0,
        "scientific_contract_changed": False,
        "original_training_admission_changed": False,
        "bitwise_equivalence_to_rtx3090_claimed": False,
    }
    payload["identity_sha256"] = _payload_identity(payload)
    write_canonical_json_exclusive(output, payload)
    return payload


def _runtime_contract_view(identity: Mapping[str, Any]) -> dict[str, Any]:
    keys = (
        "python_version",
        "numpy_version",
        "torch_version",
        "torch_base_version",
        "psutil_version",
        "torch_cuda_runtime_version",
        "cudnn_version",
        "cuda_available",
        "cuda_device_count",
        "cuda_device_name",
        "cuda_compute_capability",
        "cuda_device_total_memory_bytes",
        "tensorfloat32",
        "slurm_job_cpus_per_node_raw",
        "slurm_job_cpus_per_node_normalized",
        "slurm_job_node_count",
        "slurm_cpus_on_node",
        "slurm_cpus_per_task",
        "exclusive_node_runtime_evidence_passed",
        "slurm_gpu_allocation_variable_present",
    )
    return {key: identity.get(key) for key in keys}


def verify_hpc_technical_admission(
    *,
    project_root: Path,
    admission_path: Path,
    private_manifest: Path,
    probe_path: Path,
    staged_manifest: Path,
    current_runtime: Mapping[str, Any],
    config_path: Path = ROOT / CONFIG_RELATIVE,
) -> dict[str, Any]:
    config = load_execution_config(config_path)
    remote_root = Path(config["remote_layout"]["remote_root"])
    admission = read_json(admission_path, root=remote_root, canonical=True)
    if (
        admission.get("schema_version") != "tukf09_455_hpc_technical_admission_a800_exclusive_v2r6"
        or admission.get("experiment_id") != EXPERIMENT_ID
        or admission.get("status")
        != "HPC_A800_EXCLUSIVE_V2R6_TECHNICAL_EXECUTION_ADMITTED_FORMAL_EVALUATION_HOLD"
        or admission.get("formal_evaluation_authorized") is not False
        or admission.get("scientific_contract_changed") is not False
        or admission.get("original_training_admission_changed") is not False
        or admission.get("bitwise_equivalence_to_rtx3090_claimed") is not False
        or admission.get("exclusive_node_required") is not True
        or admission.get("exclusive_node_runtime_evidence_passed") is not True
    ):
        raise RuntimeError("HPC technical admission changed scope")
    require_zero_evaluation(admission, label="HPC technical admission")
    _verify_payload_identity(admission, label="HPC technical admission")
    probe = read_json(probe_path, root=remote_root, canonical=True)
    _verify_payload_identity(probe, label="HPC preparation probe")
    require_zero_evaluation(probe, label="HPC preparation probe")
    private = read_json(private_manifest, root=remote_root, canonical=True)
    _verify_payload_identity(private, label="private runtime manifest")
    staged = read_json(staged_manifest, root=remote_root, canonical=True)
    _verify_payload_identity(staged, label="staged training source manifest")
    require_zero_evaluation(staged, label="staged training source manifest")
    capsule_evidence = verify_source_capsule_evidence(
        staged,
        config=config,
        label="staged training source manifest",
    )
    verify_source_capsule_evidence(
        probe,
        config=config,
        label="HPC preparation probe",
    )
    verify_source_capsule_evidence(
        admission,
        config=config,
        label="HPC technical admission",
    )
    verify_training_source_capsule(
        source_root=Path(config["remote_layout"]["read_only_camels_root"]),
        config_path=config_path,
    )
    initial_path = Path(config["remote_layout"]["initial_bundle_verification"])
    initial = verify_or_publish_initial_bundle_verification(
        project_root=Path(project_root),
        output=initial_path,
        config_path=config_path,
    )
    science = config["scientific_identity"]
    if (
        admission.get("scientific_contract_sha256")
        != science["scientific_contract"]["sha256"]
        or admission.get("original_training_admission_file_sha256")
        != science["original_training_admission"]["file_sha256"]
        or admission.get("local_filter_installation_final_sha256")
        != science["local_filter_installation_final_manifest"]["sha256"]
        or admission.get("private_runtime_manifest_sha256")
        != sha256_file(private_manifest)
        or admission.get("private_runtime_identity_sha256")
        != private.get("identity_sha256")
        or probe.get("private_runtime_manifest_sha256")
        != sha256_file(private_manifest)
        or probe.get("private_runtime_identity_sha256")
        != private.get("identity_sha256")
        or admission.get("offline_input_manifest_sha256")
        != private.get("offline_input_manifest_sha256")
        or admission.get("offline_input_identity_sha256")
        != private.get("offline_input_identity_sha256")
        or probe.get("offline_input_manifest_sha256")
        != private.get("offline_input_manifest_sha256")
        or probe.get("offline_input_identity_sha256")
        != private.get("offline_input_identity_sha256")
        or admission.get("preparation_probe_sha256") != sha256_file(probe_path)
        or admission.get("preparation_probe_identity_sha256")
        != probe.get("identity_sha256")
        or admission.get("staged_sources_manifest_sha256")
        != sha256_file(staged_manifest)
        or admission.get("staged_sources_identity_sha256")
        != staged.get("identity_sha256")
        or probe.get("staged_sources_manifest_sha256") != sha256_file(staged_manifest)
        or probe.get("staged_sources_identity_sha256") != staged.get("identity_sha256")
        or any(
            admission.get(key) != value or probe.get(key) != value or staged.get(key) != value
            for key, value in capsule_evidence.items()
        )
        or admission.get("bundle_manifest_sha256")
        != sha256_file(_bundle_manifest_path(project_root))
        or admission.get("initial_bundle_verification_sha256")
        != sha256_file(initial_path)
        or admission.get("initial_bundle_verification_identity_sha256")
        != initial.get("identity_sha256")
        or probe.get("initial_bundle_verification_sha256")
        != sha256_file(initial_path)
        or probe.get("initial_bundle_verification_identity_sha256")
        != initial.get("identity_sha256")
        or admission.get("remote_filter_installation_final_sha256")
        != sha256_file(Path(project_root) / REMOTE_FILTER_SEAL_RELATIVE)
        or admission.get("exclusive_node_runtime_evidence_passed")
        != (current_runtime.get("exclusive_node_runtime_evidence_passed") is True)
        or _runtime_contract_view(admission.get("admitted_runtime", {}))
        != _runtime_contract_view(current_runtime)
    ):
        raise RuntimeError("HPC technical admission evidence or runtime differs")
    basins, expected_records = _expected_stage_records(
        project_root=Path(project_root),
        source_root=Path(config["remote_layout"]["read_only_camels_root"]),
        config=config,
    )
    if (
        staged.get("ordered_basin_ids") != basins
        or staged.get("file_count") != 911
        or staged.get("file_sha256")
        != {name: record["sha256"] for name, record in expected_records.items()}
        or staged.get("file_size")
        != {name: int(record["size_bytes"]) for name, record in expected_records.items()}
        or staged.get("publication_policy")
        != "exclusive_destination_reservation_no_overwrite_freeze_root_on_failure"
    ):
        raise RuntimeError("staged training source manifest differs from frozen evidence")
    verify_staged_training_sources(
        destination_root=_default_contract_destination(Path(project_root), config),
        records=expected_records,
    )
    verify_runtime_against_config(current_runtime, config)
    return admission


def run_formal_training(
    *,
    project_root: Path,
    admission_path: Path,
    private_manifest: Path,
    probe_path: Path,
    wheelhouse: Path,
    staged_manifest: Path,
    config_path: Path = ROOT / CONFIG_RELATIVE,
) -> int:
    config = load_execution_config(config_path)
    project = Path(project_root)
    verify_private_runtime_manifest(
        manifest_path=private_manifest,
        pysite=Path(config["remote_layout"]["private_python_site"]),
        wheelhouse=wheelhouse,
        import_check=True,
        config_path=config_path,
    )
    current = runtime_identity(require_slurm=True, config=config)
    verify_hpc_technical_admission(
        project_root=project,
        admission_path=admission_path,
        private_manifest=private_manifest,
        probe_path=probe_path,
        staged_manifest=staged_manifest,
        current_runtime=current,
        config_path=config_path,
    )
    staged = read_json(staged_manifest, root=Path(config["remote_layout"]["remote_root"]), canonical=True)
    _verify_payload_identity(staged, label="staged training source manifest")
    destination = _default_contract_destination(project, config)
    records = {
        name: {"sha256": digest, "size_bytes": staged["file_size"][name]}
        for name, digest in staged["file_sha256"].items()
    }
    verify_staged_training_sources(destination_root=destination, records=records)
    forbidden = tuple(
        project / RESULTS_ROOT_RELATIVE / name
        for name in ("selection", "evaluation", "formal_evaluation")
    )
    if any(path_exists(path) for path in forbidden):
        raise RuntimeError("formal selection or evaluation output exists before HPC neural training")
    # Replace this wrapper process instead of keeping a parent CUDA context alive.
    # The frozen inner controller permits only its own compute PID on the node.
    os.chdir(project)
    command = [
        sys.executable,
        "-B",
        "-u",
        os.fspath(FORMAL_SEQUENCE_RELATIVE),
        "--execute-formal-training",
    ]
    os.execv(sys.executable, command)
    raise AssertionError("os.execv unexpectedly returned")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    snapshot = subparsers.add_parser("snapshot-shared-environment")
    snapshot.add_argument("--output", type=Path, required=True)

    offline_freeze = subparsers.add_parser("freeze-offline-inputs")
    offline_freeze.add_argument("--wheelhouse", type=Path, required=True)
    offline_freeze.add_argument("--sourcehouse", type=Path, required=True)
    offline_freeze.add_argument("--download-command-file", type=Path, required=True)
    offline_freeze.add_argument("--download-stdout-file", type=Path, required=True)
    offline_freeze.add_argument("--download-stderr-file", type=Path, required=True)
    offline_freeze.add_argument("--shared-environment-before", type=Path, required=True)
    offline_freeze.add_argument("--shared-environment-after", type=Path, required=True)
    offline_freeze.add_argument("--output", type=Path, required=True)
    offline_freeze.add_argument("--authorize-offline-input-publication", action="store_true")

    offline_verify = subparsers.add_parser("verify-offline-inputs")
    offline_verify.add_argument("--manifest", type=Path, required=True)
    offline_verify.add_argument("--wheelhouse", type=Path)
    offline_verify.add_argument("--sourcehouse", type=Path)

    offline_copy = subparsers.add_parser("copy-offline-inputs")
    offline_copy.add_argument("--manifest", type=Path, required=True)
    offline_copy.add_argument("--source-wheelhouse", type=Path, required=True)
    offline_copy.add_argument("--source-sourcehouse", type=Path, required=True)
    offline_copy.add_argument("--destination-wheelhouse", type=Path, required=True)
    offline_copy.add_argument("--destination-sourcehouse", type=Path, required=True)
    offline_copy.add_argument("--authorize-offline-input-copy", action="store_true")

    initial = subparsers.add_parser("initial-bundle")
    initial.add_argument("--project-root", type=Path, required=True)
    initial.add_argument("--output", type=Path, required=True)
    initial.add_argument("--authorize-initial-bundle-verification", action="store_true")

    freeze = subparsers.add_parser("freeze-private-runtime")
    freeze.add_argument("--pysite", type=Path, required=True)
    freeze.add_argument("--wheelhouse", type=Path, required=True)
    freeze.add_argument("--pip-command-file", type=Path, required=True)
    freeze.add_argument("--pip-stdout-file", type=Path, required=True)
    freeze.add_argument("--pip-stderr-file", type=Path, required=True)
    freeze.add_argument("--offline-input-manifest", type=Path, required=True)
    freeze.add_argument("--output", type=Path, required=True)
    freeze.add_argument("--authorize-private-runtime-provenance", action="store_true")

    capsule = subparsers.add_parser("verify-source-capsule")
    capsule.add_argument("--source-root", type=Path, required=True)

    probe = subparsers.add_parser("prepare-probe")
    probe.add_argument("--project-root", type=Path, required=True)
    probe.add_argument("--source-root", type=Path, required=True)
    probe.add_argument("--pysite", type=Path, required=True)
    probe.add_argument("--wheelhouse", type=Path, required=True)
    probe.add_argument("--private-manifest", type=Path, required=True)
    probe.add_argument("--staged-manifest", type=Path, required=True)
    probe.add_argument("--output", type=Path, required=True)

    admit = subparsers.add_parser("admit")
    admit.add_argument("--project-root", type=Path, required=True)
    admit.add_argument("--probe", type=Path, required=True)
    admit.add_argument("--private-manifest", type=Path, required=True)
    admit.add_argument("--output", type=Path, required=True)
    admit.add_argument("--authorize-hpc-technical-execution", action="store_true")

    run = subparsers.add_parser("run")
    run.add_argument("--project-root", type=Path, required=True)
    run.add_argument("--admission", type=Path, required=True)
    run.add_argument("--private-manifest", type=Path, required=True)
    run.add_argument("--probe", type=Path, required=True)
    run.add_argument("--wheelhouse", type=Path, required=True)
    run.add_argument("--staged-manifest", type=Path, required=True)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if args.command == "snapshot-shared-environment":
        payload = snapshot_shared_environment(output=args.output)
    elif args.command == "freeze-offline-inputs":
        if not args.authorize_offline_input_publication:
            raise PermissionError("explicit offline input publication authorization is required")
        payload = freeze_offline_inputs_manifest(
            wheelhouse=args.wheelhouse,
            sourcehouse=args.sourcehouse,
            download_command_file=args.download_command_file,
            download_stdout_file=args.download_stdout_file,
            download_stderr_file=args.download_stderr_file,
            shared_environment_before=args.shared_environment_before,
            shared_environment_after=args.shared_environment_after,
            output=args.output,
        )
    elif args.command == "verify-offline-inputs":
        if (args.wheelhouse is None) != (args.sourcehouse is None):
            raise ValueError("wheelhouse and sourcehouse must be provided together")
        payload = verify_offline_inputs_manifest(
            manifest_path=args.manifest,
            wheelhouse=args.wheelhouse,
            sourcehouse=args.sourcehouse,
        )
    elif args.command == "copy-offline-inputs":
        payload = copy_offline_inputs(
            manifest_path=args.manifest,
            source_wheelhouse=args.source_wheelhouse,
            source_sourcehouse=args.source_sourcehouse,
            destination_wheelhouse=args.destination_wheelhouse,
            destination_sourcehouse=args.destination_sourcehouse,
            authorize=bool(args.authorize_offline_input_copy),
        )
    elif args.command == "initial-bundle":
        if not args.authorize_initial_bundle_verification:
            raise PermissionError("explicit initial bundle verification authorization is required")
        payload = verify_or_publish_initial_bundle_verification(
            project_root=args.project_root,
            output=args.output,
        )
    elif args.command == "freeze-private-runtime":
        if not args.authorize_private_runtime_provenance:
            raise PermissionError("explicit private runtime provenance authorization is required")
        payload = freeze_private_runtime_manifest(
            pysite=args.pysite,
            wheelhouse=args.wheelhouse,
            pip_command_file=args.pip_command_file,
            pip_stdout_file=args.pip_stdout_file,
            pip_stderr_file=args.pip_stderr_file,
            offline_input_manifest=args.offline_input_manifest,
            output=args.output,
        )
    elif args.command == "verify-source-capsule":
        payload = verify_training_source_capsule(source_root=args.source_root)
    elif args.command == "prepare-probe":
        payload = create_preparation_probe(
            project_root=args.project_root,
            source_root=args.source_root,
            pysite=args.pysite,
            wheelhouse=args.wheelhouse,
            private_manifest=args.private_manifest,
            staged_manifest=args.staged_manifest,
            output=args.output,
        )
    elif args.command == "admit":
        payload = create_hpc_technical_admission(
            project_root=args.project_root,
            probe_path=args.probe,
            private_manifest=args.private_manifest,
            output=args.output,
            authorize=bool(args.authorize_hpc_technical_execution),
        )
    else:
        return run_formal_training(
            project_root=args.project_root,
            admission_path=args.admission,
            private_manifest=args.private_manifest,
            probe_path=args.probe,
            wheelhouse=args.wheelhouse,
            staged_manifest=args.staged_manifest,
        )
    print(json.dumps(payload, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
