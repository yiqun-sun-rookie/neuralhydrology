from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import sys
import time
from types import SimpleNamespace

import pytest

from scripts import run_tukf09_455_neural_training as neural
from scripts import run_tukf09_455_neural_training_controller as controller
from scripts import tukf09_455_training_common as training_common
from scripts import tukf09_455_training_controller_common as controller_common


ROOT = Path(__file__).resolve().parents[1]
EXECUTION_CONFIG = ROOT / "configs" / "tukf09_455_basin_zero_validation_target_variance_formal_training_execution_v1.json"


def _plentiful_resources(_output_root: Path) -> controller.ResourceSnapshot:
    return controller.ResourceSnapshot(
        graphics_processor_count=1,
        free_graphics_memory_bytes=8 * 1024**3,
        available_system_memory_bytes=16 * 1024**3,
        free_output_disk_bytes=100 * 1024**3,
    )


def _verified_training_admission(_path: Path, _execution: Path) -> dict[str, str]:
    return {"training_admission_record_sha256": "a" * 64}


def _publish_fake_unit(output_root: Path, lead_days: int, seed: int) -> None:
    unit_id = f"lead_{lead_days}_seed_{seed}"
    neural_root = Path(output_root) / "neural"
    neural_root.mkdir(parents=True, exist_ok=True)
    token = hashlib.md5(unit_id.encode("ascii"), usedforsecurity=False).hexdigest()
    pending = neural_root / f"{unit_id}.pending-{os.getpid()}-{token}"
    pending.mkdir()
    for relative in neural._unit_member_names():
        member = pending / Path(relative)
        member.parent.mkdir(parents=True, exist_ok=True)
        member.write_bytes(f"{unit_id}:{relative}".encode("utf-8"))
    neural.publish_complete_unit(pending, neural_root / unit_id, unit_id)


def _run_in_temporary_root(
    tmp_path: Path,
    unit_runner,
    **overrides,
):
    output_root = tmp_path / "output"
    control_root = output_root / "control" / "neural"
    kwargs = {
        "execute_formal_training": True,
        "admission_context": SimpleNamespace(evaluation_access_count=0),
        "periods_by_basin": {},
        "unit_runner": unit_runner,
        "in_process_test_mode": True,
        "resource_probe": _plentiful_resources,
        "graphics_process_probe": lambda: [],
        "pid_is_alive": lambda _pid: False,
        "training_admission_verifier": _verified_training_admission,
        "initialized_root_verifier": lambda **_kwargs: {},
        "path_gate": lambda _output, _control: None,
        "enable_sleep_prevention": False,
    }
    kwargs.update(overrides)
    result = controller.run_controller(
        tmp_path / "scientific.json",
        tmp_path / "preflight",
        tmp_path / "authorization.json",
        tmp_path / "training_admission.json",
        EXECUTION_CONFIG,
        output_root,
        control_root,
        **kwargs,
    )
    return result, output_root, control_root


def _successful_fake_runner(calls: list[tuple[int, int]]):
    def run(
        _config,
        _preflight,
        _authorization,
        output_root,
        lead_days,
        seed,
        **kwargs,
    ):
        assert kwargs["execute_formal_training"] is True
        assert kwargs["training_admission"].name == "training_admission.json"
        assert kwargs["execution_config"] == EXECUTION_CONFIG
        assert kwargs["device"] == "cuda:0"
        calls.append((lead_days, seed))
        _publish_fake_unit(Path(output_root), int(lead_days), int(seed))
        return {"status": "COMPLETE"}

    return run


def _read_events(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]


def _write_top_level_sequence_state(
    output_root: Path,
    *,
    owner_execution_id: str,
    event_execution_id: str,
    sequence_process_id: int,
    neural_process_id: int,
) -> None:
    lock = output_root / "control" / ".sequence_controller.lock"
    lock.mkdir(parents=True)
    owner = {
        "schema_version": "tukf09_formal_training_sequence_owner_v1",
        "experiment_id": controller.EXPERIMENT_ID,
        "execution_id": owner_execution_id,
        "process_id": sequence_process_id,
        "started_at_utc": "2026-08-31T00:00:00+00:00",
    }
    (lock / "owner.json").write_bytes(controller_common.canonical_json_bytes(owner))
    source_hashes = {
        "verify_filter_rebinding": "1" * 64,
        "neural": "2" * 64,
    }
    records = [
        {
            "schema_version": "tukf09_formal_training_sequence_event_v1",
            "experiment_id": controller.EXPERIMENT_ID,
            "execution_id": event_execution_id,
            "sequence": 1,
            "event": "sequence_started",
            "event_at_utc": "2026-08-31T00:00:01+00:00",
            "controller_process_id": sequence_process_id,
            "training_stages": ["verify_filter_rebinding", "neural"],
            "training_admission_record_sha256": "a" * 64,
            "stage_controller_source_sha256": source_hashes,
        },
        {
            "schema_version": "tukf09_formal_training_sequence_event_v1",
            "experiment_id": controller.EXPERIMENT_ID,
            "execution_id": event_execution_id,
            "sequence": 2,
            "event": "stage_completed",
            "event_at_utc": "2026-08-31T00:00:02+00:00",
            "stage": "verify_filter_rebinding",
            "stage_process_id": sequence_process_id + 1,
            "stage_started_at_utc": "2026-08-31T00:00:01+00:00",
            "stage_ended_at_utc": "2026-08-31T00:00:02+00:00",
            "exit_code": 0,
            "training_admission_record_sha256": "a" * 64,
            "stage_controller_source_sha256": source_hashes,
            "completion_status": "FILTER_REBINDING_VERIFIED_EVALUATION_HOLD",
        },
        {
            "schema_version": "tukf09_formal_training_sequence_event_v1",
            "experiment_id": controller.EXPERIMENT_ID,
            "execution_id": event_execution_id,
            "sequence": 3,
            "event": "stage_started",
            "event_at_utc": "2026-08-31T00:00:03+00:00",
            "stage": "neural",
            "stage_process_id": neural_process_id,
            "stage_started_at_utc": "2026-08-31T00:00:03+00:00",
            "training_admission_record_sha256": "a" * 64,
            "stage_controller_source_sha256": source_hashes,
        },
    ]
    events_path = output_root / "control" / "formal_training_sequence" / "events.jsonl"
    events_path.parent.mkdir(parents=True)
    events_path.write_bytes(b"".join(controller_common.canonical_json_bytes(row) for row in records))


def test_registered_units_are_the_fixed_three_leads_by_three_seeds_order():
    assert controller.registered_units() == tuple(
        {
            "unit_id": f"lead_{lead_days}_seed_{seed}",
            "lead_days": lead_days,
            "seed": seed,
        }
        for lead_days in (1, 2, 3)
        for seed in (0, 1, 2)
    )


def test_execution_contract_freezes_wave_width_and_completion_counts():
    execution = controller.load_execution_contract(EXECUTION_CONFIG)
    assert execution["resource_policy"]["neural_model_parallelism"] == 8
    assert execution["resource_policy"]["neural_device"] == "cuda"
    assert execution["completion_counts"]["neural_model_units"] == 9
    assert execution["completion_counts"]["neural_checkpoints"] == 270


def test_direct_neural_controller_call_without_top_level_sequence_is_rejected(
    tmp_path: Path,
) -> None:
    with pytest.raises(PermissionError, match="top-level|sequence"):
        controller.verify_top_level_neural_stage(
            output_root=tmp_path,
            training_admission_record_sha256="a" * 64,
            filter_installation_final_sha256="b" * 64,
        )


def test_forged_neural_controller_stage_capability_is_rejected() -> None:
    forged = object.__new__(controller.NeuralControllerStageCapability)
    object.__setattr__(forged, "experiment_id", controller.EXPERIMENT_ID)
    object.__setattr__(forged, "sequence_execution_id", "1" * 32)
    object.__setattr__(forged, "sequence_process_id", os.getpid())
    object.__setattr__(forged, "controller_process_id", os.getpid())
    object.__setattr__(forged, "training_admission_record_sha256", "a" * 64)
    object.__setattr__(forged, "filter_installation_final_sha256", "b" * 64)
    object.__setattr__(forged, "_seal", object())
    with pytest.raises(PermissionError, match="capability"):
        controller.require_neural_controller_stage_capability(forged)
    assert not hasattr(controller, "_issue_neural_controller_stage_capability")


def test_neural_controller_rejects_sequence_events_from_another_execution(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    _write_top_level_sequence_state(
        tmp_path,
        owner_execution_id="1" * 32,
        event_execution_id="2" * 32,
        sequence_process_id=os.getppid(),
        neural_process_id=os.getpid(),
    )
    ticks = iter((0.0, 11.0))
    monkeypatch.setattr(training_common.time, "monotonic", lambda: next(ticks))
    with pytest.raises(PermissionError, match="authorize|sequence"):
        controller.verify_top_level_neural_stage(
            output_root=tmp_path,
            training_admission_record_sha256="a" * 64,
            filter_installation_final_sha256="b" * 64,
        )


def test_neural_unit_rejects_a_neural_stage_bound_to_another_parent_process(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    _write_top_level_sequence_state(
        tmp_path,
        owner_execution_id="3" * 32,
        event_execution_id="3" * 32,
        sequence_process_id=os.getpid(),
        neural_process_id=os.getppid() + 100_000,
    )
    ticks = iter((0.0, 11.0))
    monkeypatch.setattr(training_common.time, "monotonic", lambda: next(ticks))
    with pytest.raises(PermissionError, match="authorize|process"):
        neural.verify_top_level_neural_unit_stage(
            output_root=tmp_path,
            training_admission_record_sha256="a" * 64,
            filter_installation_final_sha256="b" * 64,
        )


@pytest.mark.parametrize(
    ("snapshot", "message"),
    [
        (
            controller.ResourceSnapshot(0, 8 * 1024**3, 16 * 1024**3, 100 * 1024**3),
            "graphics processor",
        ),
        (
            controller.ResourceSnapshot(1, 3999 * 1024**2, 16 * 1024**3, 100 * 1024**3),
            "graphics memory",
        ),
        (
            controller.ResourceSnapshot(1, 8 * 1024**3, 4 * 1024**3 - 1, 100 * 1024**3),
            "system memory",
        ),
        (
            controller.ResourceSnapshot(1, 8 * 1024**3, 16 * 1024**3, 20 * 1024**3 - 1),
            "output disk",
        ),
    ],
)
def test_resource_gate_stops_below_each_frozen_minimum(snapshot, message):
    execution = controller.load_execution_contract(EXECUTION_CONFIG)
    with pytest.raises(RuntimeError, match=message):
        controller.gate_resources(snapshot, execution)


def test_graphics_process_gate_allows_only_the_controller_process():
    controller.gate_no_other_graphics_training(
        [{"pid": os.getpid(), "process_name": "python", "used_gpu_memory_mib": 1}],
        controller_pid=os.getpid(),
        own_process_ids=(),
    )
    with pytest.raises(RuntimeError, match="another graphics-processor"):
        controller.gate_no_other_graphics_training(
            [{"pid": os.getpid() + 1, "process_name": "python", "used_gpu_memory_mib": 1}],
            controller_pid=os.getpid(),
            own_process_ids=(),
        )


def test_own_job_process_ids_covers_this_process_and_its_parent():
    own = controller.own_job_process_ids(os.getpid())
    assert os.getpid() in own
    assert os.getppid() in own
    assert 1 not in own


def test_own_job_process_ids_of_an_unknown_process_is_just_that_process():
    # A process identifier this run cannot resolve must not silently widen the gate.
    assert controller.own_job_process_ids(2**22 + 7) == frozenset({2**22 + 7})


def test_own_job_process_ids_survives_a_restricted_process_view(monkeypatch):
    """The 2026-09-04 second failure: inside the job container the process table root is
    absent, and the process library raised a plain operating-system error the walk did
    not catch. The immediate parent must still be recognised."""

    class Blocked:
        def __init__(self, _pid):
            raise FileNotFoundError(2, "No such file or directory", "/proc/1/stat")

    monkeypatch.setattr(controller.psutil, "Process", Blocked)
    own = controller.own_job_process_ids(os.getpid())
    assert os.getpid() in own
    assert os.getppid() in own


def test_own_job_process_ids_survives_a_denied_process_view(monkeypatch):
    class Denied:
        def __init__(self, _pid):
            raise controller.psutil.AccessDenied(_pid)

    monkeypatch.setattr(controller.psutil, "Process", Denied)
    own = controller.own_job_process_ids(os.getpid())
    assert own == frozenset({os.getpid(), os.getppid()})


def test_own_job_process_ids_never_reads_the_process_table_root(monkeypatch):
    """Walking must stop before the process table root, which a job container may hide."""
    seen: list[int] = []

    class Recorder:
        def __init__(self, pid):
            seen.append(int(pid))
            self._pid = int(pid)

        def ppid(self):
            return 1 if self._pid == os.getpid() else 0

        def children(self, recursive=False):
            return []

    monkeypatch.setattr(controller.psutil, "Process", Recorder)
    own = controller.own_job_process_ids(os.getpid())
    assert 1 not in seen and 1 not in own
    assert os.getpid() in own


def test_own_job_process_ids_walks_a_synthetic_chain(monkeypatch):
    chain = {4001: 4002, 4002: 4003, 4003: 1}

    class Chain:
        def __init__(self, pid):
            self._pid = int(pid)
            if self._pid not in chain:
                raise controller.psutil.NoSuchProcess(self._pid)

        def ppid(self):
            return chain[self._pid]

        def children(self, recursive=False):
            return []

    monkeypatch.setattr(controller.psutil, "Process", Chain)
    assert controller.own_job_process_ids(4001) == frozenset({4001, 4002, 4003})


def test_own_job_process_ids_stops_on_a_cyclic_chain(monkeypatch):
    chain = {5001: 5002, 5002: 5001}

    class Cycle:
        def __init__(self, pid):
            self._pid = int(pid)

        def ppid(self):
            return chain[self._pid]

        def children(self, recursive=False):
            return []

    monkeypatch.setattr(controller.psutil, "Process", Cycle)
    assert controller.own_job_process_ids(5001) == frozenset({5001, 5002})


def test_gate_accepts_the_parent_that_started_this_controller():
    """The 2026-09-04 failure: the frozen top-level sequence already holds a graphics
    context, so the driver lists it, and a self-only gate called it a foreign process."""
    parent = os.getppid()
    controller.gate_no_other_graphics_training(
        [
            {"graphics_processor_index": 0, "pid": os.getpid(), "process_type": "C", "process_name": "python"},
            {"graphics_processor_index": 0, "pid": parent, "process_type": "C", "process_name": "python"},
        ],
        controller_pid=os.getpid(),
    )


def test_gate_still_stops_on_a_process_outside_this_run(monkeypatch):
    foreign = {
        "graphics_processor_index": 3,
        "pid": 2**22 + 11,
        "process_type": "C",
        "process_name": "someone_else",
    }
    with pytest.raises(RuntimeError, match="another graphics-processor compute process"):
        controller.gate_no_other_graphics_training(
            [
                {"graphics_processor_index": 0, "pid": os.getpid(), "process_type": "C", "process_name": "python"},
                foreign,
            ],
            controller_pid=os.getpid(),
        )


def test_gate_reports_every_foreign_process_not_only_the_first():
    foreign_a = {"pid": 2**22 + 13, "process_type": "C", "process_name": "a"}
    foreign_b = {"pid": 2**22 + 17, "process_type": "C", "process_name": "b"}
    with pytest.raises(RuntimeError) as error:
        controller.gate_no_other_graphics_training(
            [foreign_a, {"pid": os.getpid()}, foreign_b],
            controller_pid=os.getpid(),
            own_process_ids=(),
        )
    message = str(error.value)
    assert str(foreign_a["pid"]) in message and str(foreign_b["pid"]) in message


def test_gate_own_process_set_is_explicit_when_injected():
    controller.gate_no_other_graphics_training(
        [{"pid": 4242, "process_type": "C", "process_name": "python"}],
        controller_pid=os.getpid(),
        own_process_ids=(4242,),
    )
    with pytest.raises(RuntimeError, match="another graphics-processor"):
        controller.gate_no_other_graphics_training(
            [{"pid": 4243, "process_type": "C", "process_name": "python"}],
            controller_pid=os.getpid(),
            own_process_ids=(4242,),
        )


def test_windows_graphics_monitor_detects_only_exact_compute_processes(monkeypatch):
    completed = SimpleNamespace(
        returncode=0,
        stdout=(
            "# gpu pid type sm mem enc dec jpg ofa command\n"
            "0 1234 C 10 5 - - - - python.exe\n"
            "0 2345 C+G 1 2 - - - - explorer.exe\n"
            "0 3456 G 1 2 - - - - graphics.exe\n"
            "0 - - - - - - - - -\n"
        ),
        stderr="",
    )
    captured = {}

    def run(command, **kwargs):
        captured["command"] = command
        captured["kwargs"] = kwargs
        return completed

    monkeypatch.setattr(controller.subprocess, "run", run)
    assert controller.active_graphics_compute_processes() == [
        {
            "graphics_processor_index": 0,
            "pid": 1234,
            "process_type": "C",
            "process_name": "python.exe",
        }
    ]
    assert captured["command"] == ["nvidia-smi", "pmon", "-c", "1"]
    assert captured["kwargs"]["timeout"] == 15


@pytest.mark.parametrize(
    "line",
    [
        "0 1234 X 1 2 - - - - python.exe",
        "0 not-a-pid C 1 2 - - - - python.exe",
        "0 1234 C too-few-fields",
    ],
)
def test_windows_graphics_monitor_rejects_unknown_format(monkeypatch, line):
    completed = SimpleNamespace(returncode=0, stdout=line + "\n", stderr="")
    monkeypatch.setattr(
        controller.subprocess,
        "run",
        lambda *_args, **_kwargs: completed,
    )
    with pytest.raises(RuntimeError, match="graphics-process probe"):
        controller.active_graphics_compute_processes()


def test_controller_lock_refuses_a_duplicate_holder(tmp_path):
    lock_path = tmp_path / "control" / "controller.lock"
    with controller.ControllerLock(lock_path):
        with pytest.raises(RuntimeError, match="another neural training controller"):
            with controller.ControllerLock(lock_path):
                pass


def test_event_log_rejects_noncanonical_or_multiply_linked_history(tmp_path):
    event_path = tmp_path / "events.jsonl"
    log = controller.AppendOnlyEventLog(event_path, controller_pid=os.getpid())
    event = log.append("TEST", unit_id=None, exit_status="RUNNING")
    event_path.write_text(json.dumps(event, separators=(", ", ": ")) + "\n", encoding="utf-8")
    with pytest.raises(RuntimeError, match="not canonical"):
        controller.AppendOnlyEventLog(event_path, controller_pid=os.getpid())

    event_path.write_bytes(
        json.dumps(
            event,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        + b"\n"
    )
    os.link(event_path, tmp_path / "event-hard-link.jsonl")
    with pytest.raises(RuntimeError, match="linked or invalid"):
        controller.AppendOnlyEventLog(event_path, controller_pid=os.getpid())


def test_fixed_path_gate_rejects_any_alternate_output_or_control_root(
    monkeypatch,
    tmp_path,
):
    project = tmp_path / "project"
    output = project / "results" / "fixed"
    output.mkdir(parents=True)
    monkeypatch.setattr(controller, "ROOT", project)
    monkeypatch.setattr(controller, "DEFAULT_OUTPUT_ROOT", output)
    controller.gate_controller_paths(
        output,
        output / "control" / "neural",
    )
    with pytest.raises(ValueError, match="fixed results root"):
        controller.gate_controller_paths(
            tmp_path / "alternate-output",
            tmp_path / "alternate-output" / "control" / "neural",
        )
    with pytest.raises(ValueError, match="output/control/neural"):
        controller.gate_controller_paths(
            output,
            output / "control" / "alternate",
        )


def test_fixed_path_gate_requires_the_initialized_output_root(monkeypatch, tmp_path):
    project = tmp_path / "project"
    output = project / "results" / "fixed"
    project.mkdir()
    monkeypatch.setattr(controller, "ROOT", project)
    monkeypatch.setattr(controller, "DEFAULT_OUTPUT_ROOT", output)
    with pytest.raises(RuntimeError, match="initialized neural training output root"):
        controller.gate_controller_paths(output, output / "control" / "neural")


def test_fixed_path_gate_rejects_a_non_directory_output(monkeypatch, tmp_path):
    output = tmp_path / "output-file"
    output.write_bytes(b"not a directory")
    monkeypatch.setattr(controller, "ROOT", tmp_path)
    monkeypatch.setattr(controller, "DEFAULT_OUTPUT_ROOT", output)
    with pytest.raises(RuntimeError, match="initialized neural training output root"):
        controller.gate_controller_paths(output, output / "control" / "neural")


def test_execute_acknowledgement_precedes_admission_and_all_writes(tmp_path):
    called = False

    def forbidden(_path, _execution):
        nonlocal called
        called = True
        raise AssertionError("admission must not run")

    with pytest.raises(RuntimeError, match="explicit formal-training authorization"):
        controller.run_controller(
            tmp_path / "scientific.json",
            tmp_path / "preflight",
            tmp_path / "authorization.json",
            tmp_path / "training_admission.json",
            tmp_path / "execution.json",
            tmp_path / "output",
            tmp_path / "output" / "control" / "neural",
            execute_formal_training=False,
            training_admission_verifier=forbidden,
        )
    assert called is False
    assert not (tmp_path / "output").exists()


def test_initialized_controller_root_without_filter_installation_final_stops_before_data(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    output = tmp_path / "initialized-output"
    output.mkdir()

    def forbidden(*_args, **_kwargs):
        raise AssertionError("training data or model code ran before installation final gate")

    monkeypatch.setattr(controller, "_load_context_only", forbidden)
    monkeypatch.setattr(controller, "_load_context_and_periods", forbidden)
    with pytest.raises(RuntimeError, match="installation final"):
        controller.run_controller(
            tmp_path / "scientific.json",
            tmp_path / "preflight",
            tmp_path / "authorization.json",
            tmp_path / "training_admission.json",
            EXECUTION_CONFIG,
            output,
            output / "control" / "neural",
            execute_formal_training=True,
            training_admission_verifier=_verified_training_admission,
            initialized_root_verifier=lambda **_kwargs: {},
            path_gate=lambda _output, _control: None,
        )


def test_controller_injections_require_explicit_synthetic_test_mode(tmp_path):
    with pytest.raises(RuntimeError, match="restricted to explicit synthetic tests"):
        controller.run_controller(
            tmp_path / "scientific.json",
            tmp_path / "preflight",
            tmp_path / "authorization.json",
            tmp_path / "training_admission.json",
            EXECUTION_CONFIG,
            tmp_path / "output",
            tmp_path / "output" / "control" / "neural",
            execute_formal_training=True,
            admission_context=SimpleNamespace(evaluation_access_count=0),
            periods_by_basin={},
        )


def test_synthetic_controller_mode_cannot_target_the_formal_result_root(
    monkeypatch,
    tmp_path,
):
    output = tmp_path / "formal-output"
    monkeypatch.setattr(controller, "DEFAULT_OUTPUT_ROOT", output)
    with pytest.raises(PermissionError, match="formal result root forbids"):
        controller.run_controller(
            tmp_path / "scientific.json",
            tmp_path / "preflight",
            tmp_path / "authorization.json",
            tmp_path / "training_admission.json",
            EXECUTION_CONFIG,
            output,
            output / "control" / "neural",
            execute_formal_training=True,
            admission_context=SimpleNamespace(evaluation_access_count=0),
            periods_by_basin={},
            in_process_test_mode=True,
        )


def test_production_controller_uses_trusted_identity_validation_for_all_reused_units(
    monkeypatch,
    tmp_path,
):
    output_root = tmp_path / "output"
    for lead_days in (1, 2, 3):
        for seed in (0, 1, 2):
            _publish_fake_unit(output_root, lead_days, seed)
    basin_ids = tuple(f"{index:08d}" for index in range(1, 457))
    monkeypatch.setattr(
        controller,
        "_load_context_only",
        lambda *_args: SimpleNamespace(
            evaluation_access_count=0,
            ordered_basin_ids=basin_ids,
        ),
    )
    monkeypatch.setattr(
        controller,
        "validate_shared_training_scaler",
        lambda _output: "b" * 64,
    )
    calls = []

    def validate_trusted(directory, unit_id, **kwargs):
        calls.append((unit_id, kwargs))
        return neural.validate_complete_unit(directory, unit_id)

    monkeypatch.setattr(controller, "validate_reusable_complete_unit", validate_trusted)
    installation = SimpleNamespace(filter_installation_final_sha256="d" * 64)
    stage_capability = SimpleNamespace(
        filter_installation_final_sha256="d" * 64,
        sequence_execution_id="e" * 32,
    )
    monkeypatch.setattr(
        controller,
        "verify_filter_installation_for_neural",
        lambda **_kwargs: installation,
    )
    monkeypatch.setattr(
        controller,
        "verify_top_level_neural_stage",
        lambda **_kwargs: stage_capability,
    )
    monkeypatch.setattr(
        controller,
        "require_neural_controller_stage_capability",
        lambda value: value,
    )
    result = controller.run_controller(
        tmp_path / "scientific.json",
        tmp_path / "preflight",
        tmp_path / "authorization.json",
        tmp_path / "training_admission.json",
        EXECUTION_CONFIG,
        output_root,
        output_root / "control" / "neural",
        execute_formal_training=True,
        resource_probe=_plentiful_resources,
        graphics_process_probe=lambda: [],
        pid_is_alive=lambda _pid: False,
        training_admission_verifier=_verified_training_admission,
        initialized_root_verifier=lambda **_kwargs: {},
        path_gate=lambda _output, _control: None,
        enable_sleep_prevention=False,
    )
    assert len(calls) == 9
    assert [unit_id for unit_id, _kwargs in calls] == [
        str(unit["unit_id"]) for unit in controller.REGISTERED_UNITS
    ]
    assert all(
        kwargs["training_admission_record"]["training_admission_record_sha256"]
        == "a" * 64
        and kwargs["ordered_basin_ids"] == basin_ids
        and kwargs["training_scaler_sha256_value"] == "b" * 64
        for _unit_id, kwargs in calls
    )
    assert all(unit["reused"] is True for unit in result["completed_units"])


def test_admission_then_fixed_path_gate_precede_config_reads_and_writes(tmp_path):
    order: list[str] = []

    def admission(_path, _execution):
        order.append("admission")
        return {"training_admission_record_sha256": "a" * 64}

    def path_gate(_output, _control):
        order.append("path")
        raise RuntimeError("injected path stop")

    with pytest.raises(RuntimeError, match="injected path stop"):
        controller.run_controller(
            tmp_path / "scientific.json",
            tmp_path / "preflight",
            tmp_path / "authorization.json",
            tmp_path / "training_admission.json",
            tmp_path / "missing-execution.json",
            tmp_path / "output",
            tmp_path / "output" / "control" / "neural",
            execute_formal_training=True,
            training_admission_verifier=admission,
            path_gate=path_gate,
        )
    assert order == ["admission", "path"]
    assert not (tmp_path / "output").exists()


def test_controller_holds_lock_before_loading_all_period_arrays(monkeypatch, tmp_path):
    output = tmp_path / "output"
    control = output / "control" / "neural"
    lock = control / "controller.lock"

    def load(*_args):
        with pytest.raises(RuntimeError, match="another neural training controller"):
            with controller.ControllerLock(lock):
                pass
        return SimpleNamespace(evaluation_access_count=0), {}

    monkeypatch.setattr(controller, "_load_context_and_periods", load)
    calls: list[tuple[int, int]] = []
    result, _, _ = _run_in_temporary_root(
        tmp_path,
        _successful_fake_runner(calls),
        admission_context=None,
        periods_by_basin=None,
    )
    assert result["unit_count"] == 9
    assert len(calls) == 9


def test_controller_runs_all_nine_units_serially_in_fixed_order(tmp_path):
    calls: list[tuple[int, int]] = []
    result, output, control = _run_in_temporary_root(
        tmp_path,
        _successful_fake_runner(calls),
    )
    assert calls == [(lead, seed) for lead in (1, 2, 3) for seed in (0, 1, 2)]
    assert result["status"] == "NEURAL_TRAINING_COMPLETE_EVALUATION_HOLD"
    assert result["unit_count"] == 9
    assert result["checkpoint_count"] == 270
    assert result["evaluation_access_count"] == 0
    assert len(list((output / "neural").glob("lead_*_seed_*"))) == 9
    events = _read_events(control / "events.jsonl")
    assert [event["sequence_number"] for event in events] == list(range(1, 21))
    assert events[0]["event_type"] == "CONTROLLER_STARTED"
    assert events[-1]["event_type"] == "CONTROLLER_COMPLETED"
    assert all(event["evaluation_access_count"] == 0 for event in events)


def test_production_route_launches_each_unit_as_a_timeout_bounded_subprocess(tmp_path):
    waves: list[tuple[list[str], int, tuple[str, ...]]] = []
    output = tmp_path / "output"

    def wave_runner(commands, *, timeout_seconds, device_tokens):
        controller.gate_wave_device_slots(len(commands), device_tokens)
        waves.append(
            (sorted(commands), int(timeout_seconds), tuple(device_tokens[: len(commands)]))
        )
        outcomes = {}
        for unit_id, command in commands.items():
            command = list(command)
            calls.append((command, int(timeout_seconds)))
            lead_days = int(command[command.index("--lead-days") + 1])
            seed = int(command[command.index("--seed") + 1])
            _publish_fake_unit(output, lead_days, seed)
            outcomes[unit_id] = {"returncode": 0, "stderr": ""}
        return outcomes

    calls: list[tuple[list[str], int]] = []
    result, _, _ = _run_in_temporary_root(
        tmp_path,
        None,
        unit_wave_runner=wave_runner,
        graphics_device_probe=lambda: tuple(str(index) for index in range(8)),
    )
    assert result["unit_count"] == 9
    assert len(calls) == 9
    assert all(timeout == 86400 for _, timeout in calls)
    assert all("--execute-formal-training" in command for command, _ in calls)
    assert all("--training-admission" in command for command, _ in calls)
    assert all("--execution-config" in command for command, _ in calls)
    # One unit alone establishes the shared normalisation, then the other eight run
    # together, each pinned to its own card.
    assert [len(unit_ids) for unit_ids, _, _ in waves] == [1, 8]
    assert waves[0][0] == ["lead_1_seed_0"]
    assert waves[0][2] == ("0",)
    assert waves[1][2] == tuple(str(index) for index in range(8))


def test_subprocess_timeout_is_logged_and_stops_before_the_second_wave(tmp_path):
    calls = 0

    def timeout(commands, *, timeout_seconds, device_tokens):
        nonlocal calls
        calls += 1
        raise controller.subprocess.TimeoutExpired("python", timeout_seconds)

    with pytest.raises(TimeoutError, match="86400-second timeout"):
        _run_in_temporary_root(
            tmp_path,
            None,
            unit_wave_runner=timeout,
            graphics_device_probe=lambda: tuple(str(index) for index in range(8)),
        )
    # The first wave holds a single unit, so the run stops with one launch recorded.
    assert calls == 1
    events = _read_events(tmp_path / "output" / "control" / "neural" / "events.jsonl")
    assert [event["event_type"] for event in events] == [
        "CONTROLLER_STARTED",
        "UNIT_STARTED",
        "UNIT_FAILED",
    ]
    assert events[-1]["detail"]["error_type"] == "TimeoutError"


def test_second_controller_run_reuses_only_exact_complete_units(tmp_path):
    first_calls: list[tuple[int, int]] = []
    _, _, control = _run_in_temporary_root(
        tmp_path,
        _successful_fake_runner(first_calls),
    )

    def forbidden(*_args, **_kwargs):
        raise AssertionError("exact completed units must be reused")

    result, _, _ = _run_in_temporary_root(tmp_path, forbidden)
    assert all(unit["reused"] is True for unit in result["completed_units"])
    events = _read_events(control / "events.jsonl")
    assert [event["sequence_number"] for event in events] == list(range(1, 32))
    assert sum(event["event_type"] == "UNIT_REUSED" for event in events) == 9


def test_tampered_complete_unit_holds_instead_of_being_skipped(tmp_path):
    calls: list[tuple[int, int]] = []
    _, output, _ = _run_in_temporary_root(
        tmp_path,
        _successful_fake_runner(calls),
    )
    (output / "neural" / "lead_1_seed_0" / "identity.json").write_bytes(b"tampered")

    def forbidden(*_args, **_kwargs):
        raise AssertionError("tampered final unit must not be overwritten")

    with pytest.raises(RuntimeError, match="manifest differs"):
        _run_in_temporary_root(tmp_path, forbidden)


def test_unit_failure_is_logged_and_stops_before_the_second_unit(tmp_path):
    calls: list[tuple[int, int]] = []

    def fail(_config, _preflight, _authorization, _output, lead_days, seed, **_kwargs):
        calls.append((lead_days, seed))
        raise FloatingPointError("injected unit failure")

    with pytest.raises(FloatingPointError, match="injected unit failure"):
        _run_in_temporary_root(tmp_path, fail)
    assert calls == [(1, 0)]
    events = _read_events(tmp_path / "output" / "control" / "neural" / "events.jsonl")
    assert [event["event_type"] for event in events] == [
        "CONTROLLER_STARTED",
        "UNIT_STARTED",
        "UNIT_FAILED",
    ]


def test_dead_unit_pending_is_safely_removed_and_logged(tmp_path):
    neural_root = tmp_path / "neural"
    pending = neural_root / f"lead_1_seed_0.pending-987654-{'b' * 32}"
    pending.mkdir(parents=True)
    (pending / "identity.json").write_text("{}", encoding="utf-8")
    log = controller.AppendOnlyEventLog(tmp_path / "events.jsonl", controller_pid=os.getpid())
    recovered = controller.recover_stale_pending_units(
        neural_root,
        pid_is_alive=lambda _pid: False,
        event_log=log,
    )
    assert recovered == ["lead_1_seed_0"]
    assert not pending.exists()
    assert _read_events(tmp_path / "events.jsonl")[0]["event_type"] == "STALE_PENDING_REMOVED"


def test_dead_shared_scaler_pending_is_safely_removed_and_logged(tmp_path):
    neural_root = tmp_path / "neural"
    owner_pid = 987653
    pending = neural_root / f"shared.pending-{owner_pid}-{'c' * 32}"
    pending.mkdir(parents=True)
    temporary = pending / f"training_scaler.json.tmp-{owner_pid}-{'d' * 32}"
    temporary.write_text("{}", encoding="utf-8")
    log = controller.AppendOnlyEventLog(tmp_path / "events.jsonl", controller_pid=os.getpid())
    recovered = controller.recover_stale_pending_units(
        neural_root,
        pid_is_alive=lambda _pid: False,
        event_log=log,
    )
    assert recovered == ["shared"]
    assert not pending.exists()
    assert _read_events(tmp_path / "events.jsonl")[0]["event_type"] == (
        "STALE_SHARED_PENDING_REMOVED"
    )


@pytest.mark.parametrize(
    "pending_name",
    [
        f"lead_1_seed_0.pending-987652-{'e' * 32}",
        f"shared.pending-987652-{'f' * 32}",
    ],
)
def test_live_pending_owner_causes_hold_without_deletion(tmp_path, pending_name):
    neural_root = tmp_path / "neural"
    pending = neural_root / pending_name
    pending.mkdir(parents=True)
    log = controller.AppendOnlyEventLog(tmp_path / "events.jsonl", controller_pid=os.getpid())
    with pytest.raises(RuntimeError, match="still owns"):
        controller.recover_stale_pending_units(
            neural_root,
            pid_is_alive=lambda _pid: True,
            event_log=log,
        )
    assert pending.is_dir()


def test_unexpected_shared_pending_member_causes_hold_without_deletion(tmp_path):
    neural_root = tmp_path / "neural"
    pending = neural_root / f"shared.pending-987651-{'0' * 32}"
    pending.mkdir(parents=True)
    (pending / "foreign.bin").write_bytes(b"foreign")
    log = controller.AppendOnlyEventLog(tmp_path / "events.jsonl", controller_pid=os.getpid())
    with pytest.raises(RuntimeError, match="unexpected file"):
        controller.recover_stale_pending_units(
            neural_root,
            pid_is_alive=lambda _pid: False,
            event_log=log,
        )
    assert pending.is_dir()


def test_controller_command_line_has_no_evaluation_surface():
    source = (
        ROOT / "scripts" / "run_tukf09_455_neural_training_controller.py"
    ).read_text(encoding="utf-8")
    for required in (
        "--config",
        "--preflight-root",
        "--authorization",
        "--training-admission",
        "--execution-config",
        "--output-root",
        "--control-root",
        "--execute-formal-training",
    ):
        assert required in source
    assert "add_argument(\"--evaluation" not in source
    assert "add_argument(\"--prediction" not in source


# The exact bytes nvidia-smi printed on the exclusive A800 node ngu202 under driver
# 535.104.05 on 2026-09-02, captured by job 218580.  That driver family prints eight
# columns; drivers from the 550 family onward insert "jpg" and "ofa" before "command".
A800_IDLE_PROBE = (
    "# gpu         pid  type    sm    mem    enc    dec    command" + "\n"
    + "# Idx           #   C/G     %      %      %      %    name" + "\n"
    + "".join(
        "    {index}          -     -      -      -      -      -    -              ".format(index=index)
        + "\n"
        for index in range(8)
    )
)

A800_BUSY_PROBE = (
    "# gpu         pid  type    sm    mem    enc    dec    command" + "\n"
    + "# Idx           #   C/G     %      %      %      %    name" + "\n"
    + "    0      41234     C     97     44      -      -    python         " + "\n"
    + "    1          -     -      -      -      -      -    -              " + "\n"
)

TEN_COLUMN_IDLE_PROBE = (
    "# gpu         pid   type     sm    mem    enc    dec    jpg    ofa    command" + "\n"
    + "# Idx           #    C/G      %      %      %      %      %      %    name" + "\n"
    + "    0          -      -      -      -      -      -      -      -    -" + "\n"
)


def _probe(monkeypatch, stdout: str, returncode: int = 0):
    completed = SimpleNamespace(returncode=returncode, stdout=stdout, stderr="")
    monkeypatch.setattr(
        controller.subprocess, "run", lambda *_args, **_kwargs: completed
    )


def test_probe_reads_the_eight_column_driver_the_cluster_actually_runs(monkeypatch):
    """The 2026-09-02 failure: eight columns were rejected by a hard-coded ten."""
    _probe(monkeypatch, A800_IDLE_PROBE)
    assert controller.active_graphics_compute_processes() == []


def test_probe_detects_a_compute_process_in_the_eight_column_layout(monkeypatch):
    _probe(monkeypatch, A800_BUSY_PROBE)
    assert controller.active_graphics_compute_processes() == [
        {
            "graphics_processor_index": 0,
            "pid": 41234,
            "process_type": "C",
            "process_name": "python",
        }
    ]


def test_probe_still_reads_the_ten_column_driver(monkeypatch):
    _probe(monkeypatch, TEN_COLUMN_IDLE_PROBE)
    assert controller.active_graphics_compute_processes() == []


def test_eight_column_compute_process_still_stops_the_exclusive_node_gate(monkeypatch):
    """The node gate is not weakened: a foreign compute process still hard-stops."""
    _probe(monkeypatch, A800_BUSY_PROBE)
    with pytest.raises(RuntimeError, match="another graphics-processor compute process"):
        controller.gate_no_other_graphics_training(
            controller.active_graphics_compute_processes(),
            controller_pid=os.getpid() + 1,
        )


def test_probe_keeps_a_command_name_that_contains_a_space(monkeypatch):
    _probe(
        monkeypatch,
        "# gpu pid type sm mem enc dec command" + "\n"
        + "0 1234 C 1 2 - - NVIDIA Overlay." + "\n",
    )
    assert controller.active_graphics_compute_processes()[0]["process_name"] == (
        "NVIDIA Overlay."
    )


@pytest.mark.parametrize(
    "stdout",
    [
        "",
        "0 1234 C 1 2 - - python" + "\n",
        "# Idx  #  C/G  %  %  %  %  name" + "\n" + "0 1234 C 1 2 - - python" + "\n",
        "# gpu pid type sm mem enc dec" + "\n" + "0 1234 C 1 2 - -" + "\n",
    ],
    ids=["empty", "no-header", "units-line-only", "header-without-command"],
)
def test_probe_without_a_usable_header_stops_the_run(monkeypatch, stdout):
    _probe(monkeypatch, stdout)
    with pytest.raises(RuntimeError, match="graphics-process probe header is missing"):
        controller.active_graphics_compute_processes()


@pytest.mark.parametrize(
    "row",
    ["0 1234 C 1", "0 1234 C", "0"],
    ids=["four-of-eight", "three-of-eight", "one-of-eight"],
)
def test_probe_row_narrower_than_the_declared_header_stops_the_run(monkeypatch, row):
    _probe(
        monkeypatch,
        "# gpu pid type sm mem enc dec command" + "\n" + row + "\n",
    )
    with pytest.raises(RuntimeError, match="graphics-process probe output changed"):
        controller.active_graphics_compute_processes()


@pytest.mark.parametrize(
    ("row", "message"),
    [
        ("0 1234 X 1 2 - - python", "unknown process type"),
        ("0 not-a-pid C 1 2 - - python", "invalid process id"),
        ("gpu0 1234 C 1 2 - - python", "invalid graphics index"),
    ],
    ids=["type", "pid", "index"],
)
def test_probe_unreadable_eight_column_field_stops_the_run(monkeypatch, row, message):
    _probe(
        monkeypatch,
        "# gpu pid type sm mem enc dec command" + "\n" + row + "\n",
    )
    with pytest.raises(RuntimeError, match=message):
        controller.active_graphics_compute_processes()


def test_probe_never_silently_skips_a_line_it_cannot_read(monkeypatch):
    """A readable row before an unreadable one must not mask the unreadable one."""
    _probe(
        monkeypatch,
        "# gpu pid type sm mem enc dec command" + "\n"
        + "0 1234 C 1 2 - - python" + "\n"
        + "1 5678 C 1 2 - -" + "\n",
    )
    with pytest.raises(RuntimeError, match="graphics-process probe output changed"):
        controller.active_graphics_compute_processes()


def test_probe_failure_return_code_stops_the_run(monkeypatch):
    _probe(monkeypatch, A800_IDLE_PROBE, returncode=9)
    with pytest.raises(RuntimeError, match="graphics-process probe failed"):
        controller.active_graphics_compute_processes()


# --------------------------------------------------------------------------------------
# The two-wave schedule: one unit alone to establish the shared normalisation, then the
# remaining eight at once, one graphics card each.
# --------------------------------------------------------------------------------------


class _FakeProcess:
    """A stand-in for a unit subprocess that finishes after a set number of polls."""

    def __init__(self, *, returncode=0, polls_until_exit=0, stderr=""):
        self._returncode = int(returncode)
        self._remaining = int(polls_until_exit)
        self._stderr = str(stderr)
        self.killed = False
        self.environment = None
        self.command = None

    def poll(self):
        if self._remaining > 0:
            self._remaining -= 1
            return None
        return self._returncode

    def communicate(self):
        while self._remaining > 0:
            time.sleep(0.001)
            self._remaining -= 1
        return "", self._stderr

    def kill(self):
        self.killed = True
        self._remaining = 0
        self._returncode = -9

    @property
    def returncode(self):
        return self._returncode


def test_wave_layout_runs_one_unit_then_the_other_eight_in_registered_order():
    waves = controller.NEURAL_EXECUTION_WAVES
    assert [len(wave) for wave in waves] == [1, 8]
    flattened = [unit["unit_id"] for wave in waves for unit in wave]
    assert flattened == [unit["unit_id"] for unit in controller.REGISTERED_UNITS]
    assert flattened[0] == "lead_1_seed_0"
    assert controller.FROZEN_NEURAL_MODEL_PARALLELISM == 8
    assert max(len(wave) for wave in waves) <= controller.FROZEN_NEURAL_MODEL_PARALLELISM


def test_visible_devices_come_from_the_scheduler_allocation_when_it_sets_one():
    tokens = controller.visible_graphics_device_tokens({"CUDA_VISIBLE_DEVICES": "4,5,6,7"})
    assert tokens == ("4", "5", "6", "7")


def test_visible_devices_fall_back_to_the_device_count_without_an_allocation():
    assert controller.visible_graphics_device_tokens({}, device_count=8) == tuple(
        str(index) for index in range(8)
    )
    assert controller.visible_graphics_device_tokens(
        {"CUDA_VISIBLE_DEVICES": "  "}, device_count=3
    ) == ("0", "1", "2")


def test_visible_devices_reject_an_empty_or_repeating_allocation():
    with pytest.raises(RuntimeError, match="empty"):
        controller.visible_graphics_device_tokens({"CUDA_VISIBLE_DEVICES": ","})
    with pytest.raises(RuntimeError, match="repeats"):
        controller.visible_graphics_device_tokens({"CUDA_VISIBLE_DEVICES": "0,1,0"})
    with pytest.raises(RuntimeError, match="no graphics processor"):
        controller.visible_graphics_device_tokens({}, device_count=0)


def test_unit_environment_pins_exactly_one_card():
    prepared = controller.build_neural_unit_environment("5", environment={"PATH": "x"})
    assert prepared["CUDA_VISIBLE_DEVICES"] == "5"
    assert prepared["PATH"] == "x"


def test_wave_refuses_to_start_without_one_card_per_unit():
    with pytest.raises(RuntimeError, match="one graphics processor per unit"):
        controller.gate_wave_device_slots(8, ("0", "1", "2"))
    with pytest.raises(RuntimeError, match="exceeds the frozen model parallelism"):
        controller.gate_wave_device_slots(9, tuple(str(index) for index in range(9)))
    with pytest.raises(ValueError, match="at least one unit"):
        controller.gate_wave_device_slots(0, ("0",))
    controller.gate_wave_device_slots(8, tuple(str(index) for index in range(8)))


def test_wave_gives_every_unit_its_own_card_and_reports_each_outcome():
    started = {}

    def starter(command, *, environment):
        process = _FakeProcess(returncode=0)
        process.command = list(command)
        process.environment = dict(environment)
        started[str(command[-1])] = process
        return process

    commands = {f"unit_{index}": ["python", "-B", "train.py", str(index)] for index in range(8)}
    outcomes = controller.run_neural_unit_wave(
        commands,
        timeout_seconds=86400,
        device_tokens=tuple(str(index) for index in range(8)),
        process_starter=starter,
        poll_seconds=0.001,
    )
    assert set(outcomes) == set(commands)
    assert all(row["returncode"] == 0 for row in outcomes.values())
    pinned = [started[str(index)].environment["CUDA_VISIBLE_DEVICES"] for index in range(8)]
    assert pinned == [str(index) for index in range(8)]
    assert len(set(pinned)) == 8


def test_wave_stops_the_siblings_when_one_unit_fails():
    processes = {}

    def starter(command, *, environment):
        unit = str(command[-1])
        process = _FakeProcess(
            returncode=1 if unit == "2" else 0,
            polls_until_exit=0 if unit == "2" else 400,
            stderr="boom" if unit == "2" else "",
        )
        processes[unit] = process
        return process

    commands = {f"unit_{index}": ["python", "-B", "train.py", str(index)] for index in range(4)}
    outcomes = controller.run_neural_unit_wave(
        commands,
        timeout_seconds=86400,
        device_tokens=("0", "1", "2", "3"),
        process_starter=starter,
        poll_seconds=0.001,
    )
    assert outcomes["unit_2"]["returncode"] == 1
    assert "boom" in outcomes["unit_2"]["stderr"]
    assert any(process.killed for unit, process in processes.items() if unit != "2")


def test_wave_kills_everything_and_raises_when_the_frozen_timeout_passes():
    processes = []

    def starter(command, *, environment):
        process = _FakeProcess(returncode=0, polls_until_exit=10**9)
        processes.append(process)
        return process

    with pytest.raises(TimeoutError, match="86400-second timeout"):
        controller.run_neural_unit_wave(
            {"unit_0": ["python", "-B", "train.py", "0"]},
            timeout_seconds=0,
            device_tokens=("0",),
            process_starter=starter,
            poll_seconds=0.001,
        )
    assert all(process.killed for process in processes)


def test_started_unit_process_refuses_a_foreign_interpreter_or_an_evaluation_surface():
    from scripts import tukf09_455_training_controller_common as controller_common

    with pytest.raises(ValueError, match="admitted Python executable"):
        controller_common.start_unit_process(["curl", "http://example.invalid"])
    with pytest.raises(PermissionError, match="evaluation surface"):
        controller_common.start_unit_process(
            [sys.executable, "-B", "scripts/evaluate_something.py", "--metric", "nse"]
        )


def test_resource_probe_reports_the_scarcest_card_because_a_wave_uses_them_all(monkeypatch):
    free_by_device = {0: 70 * 1024**3, 1: 9 * 1024**3, 2: 70 * 1024**3}
    monkeypatch.setattr(controller.torch.cuda, "is_available", lambda: True)
    monkeypatch.setattr(controller.torch.cuda, "device_count", lambda: 3)
    monkeypatch.setattr(
        controller.torch.cuda, "mem_get_info", lambda index: (free_by_device[index], 0)
    )
    snapshot = controller.probe_resources(Path.cwd())
    assert snapshot.graphics_processor_count == 3
    assert snapshot.free_graphics_memory_bytes == 9 * 1024**3
