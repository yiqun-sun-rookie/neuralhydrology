"""Filesystem, process, and lock gates for the 455-basin controllers."""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
import os
from pathlib import Path
import subprocess
import sys
from typing import Any, Iterator, Mapping, Sequence
import uuid

from scripts import tukf09_455_training_profile as profile
from scripts import tukf09_training_controller_common as parent_controller


ROOT = Path(__file__).resolve().parents[1]
EXPERIMENT_ID = profile.EXPERIMENT_ID
EXECUTION_SCHEMA = profile.FORMAL_TRAINING_EXECUTION_SCHEMA
DEFAULT_EXECUTION_CONFIG = ROOT / profile.FORMAL_TRAINING_CONFIG_RELATIVE

canonical_json_bytes = parent_controller.canonical_json_bytes
sha256_file = parent_controller.sha256_file
process_is_alive = parent_controller.process_is_alive
_process_is_alive = parent_controller._process_is_alive
_windows_process_is_alive = parent_controller._windows_process_is_alive
append_controller_event = parent_controller.append_controller_event
resource_snapshot = parent_controller.resource_snapshot
# The nine models occupy the eight cards of one exclusive node: the first alone, so it
# can publish the normalisation the other eight then read, and those eight together.
FROZEN_NEURAL_MODEL_PARALLELISM = 8

run_unit_command = parent_controller.run_unit_command
controller_lock = parent_controller.controller_lock
ControllerOwner = parent_controller.ControllerOwner


def gate_unit_command(command: Sequence[str]) -> None:
    """Refuse a unit command that is not the admitted interpreter or touches evaluation.

    The same refusals the blocking form applies, kept here rather than in the module the
    other experiment shares, so that experiment's admitted sources stay untouched.
    """
    if not command or Path(command[0]).name.lower() not in {
        Path(sys.executable).name.lower(),
        "python",
        "python.exe",
    }:
        raise ValueError("TUKF09 unit command must use the admitted Python executable")
    lowered = " ".join(str(part).lower() for part in command)
    if any(token in lowered for token in ("evaluation", "prediction", "metric")):
        raise PermissionError("training unit command contains an evaluation surface")


def start_unit_process(
    command: Sequence[str],
    *,
    environment: Mapping[str, str] | None = None,
) -> subprocess.Popen[str]:
    """Start a unit without waiting, so a wave of units can run at once.

    The caller owns the wait and the timeout. Validation is the same as the blocking
    form, so a concurrent wave cannot reach a surface the serial path refuses.
    """
    gate_unit_command(command)
    return subprocess.Popen(
        list(command),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        env=None if environment is None else dict(environment),
    )


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_execution_config(
    path: Path = DEFAULT_EXECUTION_CONFIG,
    *,
    project_root: Path = ROOT,
) -> dict[str, Any]:
    from scripts.tukf09_455_training_common import read_json_strict

    config_path = Path(path)
    config = read_json_strict(config_path)
    if config.get("schema_version") != EXECUTION_SCHEMA:
        raise ValueError("455-basin formal training execution schema changed")
    if config.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("455-basin formal training experiment identity changed")
    if config.get("controller_order", {}).get("training_stages") != [
        "verify_filter_rebinding",
        "neural",
    ]:
        raise ValueError("455-basin formal training stage order changed")
    authorization = config.get("authorization", {})
    if (
        authorization.get("required_exact_text") != profile.EXACT_AUTHORIZATION_TEXT
        or authorization.get("filter_rebinding_installation") is not True
        or authorization.get("new_filter_training") is not False
        or authorization.get("neural_training") is not True
        or authorization.get("formal_evaluation_access_during_training") is not False
    ):
        raise PermissionError("455-basin training authorization boundary changed")
    for key in ("scientific_contract", "independent_preflight_final_manifest"):
        record = config.get(key, {})
        source = Path(str(record.get("path", "")))
        if not source.is_absolute():
            source = Path(project_root) / source
        if (
            not source.is_file()
            or source.is_symlink()
            or source.stat().st_nlink != 1
            or sha256_file(source) != record.get("sha256")
        ):
            raise RuntimeError(f"455-basin frozen {key} identity changed")
    resources = config.get("resource_policy", {})
    if (
        resources.get("filter_rebinding_verification_parallelism") != 1
        or resources.get("neural_model_parallelism") != FROZEN_NEURAL_MODEL_PARALLELISM
        or resources.get("disable_cuda_matrix_multiplication_tensorfloat32") is not True
        or resources.get("disable_cudnn_tensorfloat32") is not True
    ):
        raise ValueError("455-basin formal training resource policy changed")
    return config


def configured_results_root(
    config: Mapping[str, Any], *, project_root: Path = ROOT
) -> Path:
    text = str(config.get("paths", {}).get("results_root", ""))
    path = Path(text)
    if not path.is_absolute():
        path = Path(project_root) / path
    return path.resolve(strict=False)


def require_fixed_results_root(
    requested: Path,
    config: Mapping[str, Any],
    *,
    project_root: Path = ROOT,
) -> Path:
    expected = configured_results_root(config, project_root=project_root)
    actual = Path(requested).resolve(strict=False)
    if actual != expected:
        raise ValueError("455-basin training output root differs from the fixed root")
    return actual


@dataclass(frozen=True)
class TrainingPhaseOwner:
    schema_version: str
    experiment_id: str
    role: str
    execution_id: str
    process_id: int
    started_at_utc: str
    recovered_stale_lock: bool


def _regular_unlinked_file(path: Path) -> bool:
    return path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1


def _read_owner(path: Path) -> dict[str, Any]:
    from scripts.tukf09_455_training_common import read_json_strict

    if not path.is_dir() or path.is_symlink():
        raise RuntimeError("455-basin training phase lock is linked or invalid")
    if {member.name for member in path.iterdir()} != {"owner.json"}:
        raise RuntimeError("455-basin training phase lock member set changed")
    owner_path = path / "owner.json"
    if not _regular_unlinked_file(owner_path):
        raise RuntimeError("455-basin training phase owner is linked or invalid")
    raw = owner_path.read_bytes()
    owner = read_json_strict(owner_path)
    if raw != canonical_json_bytes(owner):
        raise RuntimeError("455-basin training phase owner is not canonical")
    if (
        set(owner)
        != {
            "schema_version",
            "experiment_id",
            "role",
            "execution_id",
            "process_id",
            "started_at_utc",
            "recovered_stale_lock",
        }
        or owner.get("schema_version") != "tukf09_training_phase_owner_v1"
        or owner.get("experiment_id") != EXPERIMENT_ID
        or owner.get("role")
        not in {
            "sequence",
            "filter",
            "verify_filter_rebinding",
            "neural",
            "seal",
            "independent",
        }
        or not isinstance(owner.get("execution_id"), str)
        or len(owner["execution_id"]) != 32
        or type(owner.get("process_id")) is not int
        or owner["process_id"] <= 0
        or not isinstance(owner.get("started_at_utc"), str)
        or type(owner.get("recovered_stale_lock")) is not bool
    ):
        raise RuntimeError("455-basin training phase-lock identity changed")
    return owner


@contextmanager
def training_phase_lock(
    control_root: Path,
    role: str,
    *,
    pid_is_alive: Any = _process_is_alive,
) -> Iterator[TrainingPhaseOwner]:
    roles = {
        "sequence",
        "filter",
        "verify_filter_rebinding",
        "neural",
        "seal",
        "independent",
    }
    if role not in roles:
        raise ValueError("unknown 455-basin training phase role")
    control = Path(control_root)
    control.mkdir(parents=True, exist_ok=True)
    lock = control / ".training_phase.lock"
    try:
        lock.mkdir()
    except FileExistsError:
        prior = _read_owner(lock)
        if bool(pid_is_alive(int(prior["process_id"]))):
            raise RuntimeError("another 455-basin training phase mutation is active")
        raise RuntimeError(
            "stale 455-basin training phase lock requires manual global process audit"
        )
    owner = TrainingPhaseOwner(
        schema_version="tukf09_training_phase_owner_v1",
        experiment_id=EXPERIMENT_ID,
        role=role,
        execution_id=uuid.uuid4().hex,
        process_id=os.getpid(),
        started_at_utc=utc_now(),
        recovered_stale_lock=False,
    )
    owner_path = lock / "owner.json"
    try:
        with owner_path.open("xb") as handle:
            handle.write(canonical_json_bytes(owner.__dict__))
            handle.flush()
            os.fsync(handle.fileno())
        yield owner
    finally:
        try:
            if _read_owner(lock) != owner.__dict__:
                raise RuntimeError("455-basin training phase-lock identity changed")
            owner_path.unlink()
            lock.rmdir()
        except FileNotFoundError as exc:
            raise RuntimeError("455-basin training phase lock disappeared") from exc


def reject_post_training_outputs(output_root: Path) -> None:
    root = Path(output_root)
    for name in (
        "selection",
        "independent",
        "formal_evaluation",
        "formal_evaluation_independent",
    ):
        if os.path.lexists(os.fspath(root / name)):
            raise RuntimeError(
                f"455-basin training mutation is forbidden after {name} output exists"
            )


@contextmanager
def training_controller_locks(
    output_root: Path, controller: str
) -> Iterator[tuple[TrainingPhaseOwner, ControllerOwner]]:
    if controller not in {"filter", "verify_filter_rebinding", "neural"}:
        raise ValueError("unknown 455-basin training controller")
    root = Path(output_root)
    control = root / "control"
    phase_role = "verify_filter_rebinding" if controller == "filter" else controller
    with training_phase_lock(control, phase_role) as phase_owner:
        reject_post_training_outputs(root)
        lock_controller = "filter" if controller == "verify_filter_rebinding" else controller
        with controller_lock(control, lock_controller) as controller_owner:
            yield phase_owner, controller_owner


__all__ = [
    "ControllerOwner",
    "EXPERIMENT_ID",
    "TrainingPhaseOwner",
    "append_controller_event",
    "canonical_json_bytes",
    "configured_results_root",
    "controller_lock",
    "load_execution_config",
    "process_is_alive",
    "reject_post_training_outputs",
    "require_fixed_results_root",
    "resource_snapshot",
    "FROZEN_NEURAL_MODEL_PARALLELISM",
    "gate_unit_command",
    "run_unit_command",
    "start_unit_process",
    "sha256_file",
    "training_controller_locks",
    "training_phase_lock",
    "utc_now",
]
