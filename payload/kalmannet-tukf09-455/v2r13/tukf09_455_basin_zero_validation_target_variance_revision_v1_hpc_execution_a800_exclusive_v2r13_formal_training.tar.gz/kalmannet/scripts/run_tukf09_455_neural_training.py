from __future__ import annotations

import argparse
import copy
from dataclasses import dataclass
import hashlib
import io
import json
import math
import os
from pathlib import Path
import random
import re
import shutil
import sys
from typing import Any, Callable, Mapping, Sequence
import uuid

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import tukf09_455_training_common as training_common  # noqa: E402


EXPERIMENT_ID = "TUKF09_455_BASIN_ZERO_VALIDATION_TARGET_VARIANCE_REVISION_V1"
DEFAULT_CONFIG = (
    ROOT / "configs" / "tukf09_455_basin_zero_validation_target_variance_revision_v1.json"
)
DEFAULT_PREFLIGHT_ROOT = (
    ROOT
    / "artifacts"
    / "tukf09_455_basin_zero_validation_target_variance_revision_v1"
    / "preflight"
)
DEFAULT_OUTPUT_ROOT = (
    ROOT / "results" / "tukf09_455_basin_zero_validation_target_variance_revision_v1"
)
DEFAULT_EXECUTION_CONFIG = ROOT / "configs" / "tukf09_455_basin_zero_validation_target_variance_formal_training_execution_v1.json"
DEFAULT_TRAINING_ADMISSION = (
    ROOT
    / "artifacts"
    / "tukf09_455_basin_zero_validation_target_variance_revision_v1"
    / "training_admission"
    / "training_admission.json"
)

DAY_NS = 86_400_000_000_000
FROZEN_BASIN_COUNT = 455
FROZEN_SEQUENCE_LENGTH = 365
FROZEN_TRAINING_DAYS = 2557
FROZEN_VALIDATION_DAYS = 731
FROZEN_TRAINING_SAMPLES = 997_360
FROZEN_VALIDATION_SAMPLES = 166_530
FROZEN_EPOCHS = 30
FROZEN_BATCH_SIZE = 256
FROZEN_LEADS = (1, 2, 3)
FROZEN_SEEDS = (0, 1, 2)
UNIT_MEMBER_COUNT = 34
FROZEN_UNIT_SPECS = {
    f"lead_{lead_days}_seed_{seed}": (lead_days, seed)
    for lead_days in FROZEN_LEADS
    for seed in FROZEN_SEEDS
}
NEURAL_RUNNER_RELATIVE_PATH = "scripts/run_tukf09_455_neural_training.py"
FROZEN_MODEL_RELATIVE_PATH = "scripts/tukf07_information_matched_model.py"


def _neural_unit_capability_authority():
    private_seal = object()

    @dataclass(frozen=True)
    class Capability:
        experiment_id: str
        sequence_execution_id: str
        sequence_process_id: int
        neural_controller_process_id: int
        unit_process_id: int
        training_admission_record_sha256: str
        filter_installation_final_sha256: str
        _seal: object

    def verify_and_issue(
        *,
        output_root: Path,
        training_admission_record_sha256: str,
        filter_installation_final_sha256: str,
    ) -> Capability:
        chain = training_common.verify_neural_sequence_process_chain(
            output_root=output_root,
            training_admission_record_sha256=training_admission_record_sha256,
            filter_installation_final_sha256=filter_installation_final_sha256,
            role="neural_unit",
        )
        return Capability(
            experiment_id=EXPERIMENT_ID,
            sequence_execution_id=str(chain["sequence_execution_id"]),
            sequence_process_id=int(chain["sequence_process_id"]),
            neural_controller_process_id=int(chain["neural_controller_process_id"]),
            unit_process_id=int(chain["current_process_id"]),
            training_admission_record_sha256=training_admission_record_sha256,
            filter_installation_final_sha256=filter_installation_final_sha256,
            _seal=private_seal,
        )

    def require(value: Any) -> Capability:
        if (
            type(value) is not Capability
            or value._seal is not private_seal
            or value.experiment_id != EXPERIMENT_ID
            or value.unit_process_id != os.getpid()
            or value.neural_controller_process_id != os.getppid()
        ):
            raise PermissionError("valid neural-unit stage capability is required")
        return value

    return Capability, verify_and_issue, require


(
    NeuralUnitStageCapability,
    verify_top_level_neural_unit_stage,
    require_neural_unit_stage_capability,
) = _neural_unit_capability_authority()
del _neural_unit_capability_authority


def verify_filter_installation_for_neural_unit(
    *,
    output_root: Path,
    training_admission: Path,
    training_admission_record: Mapping[str, Any],
) -> training_common.FilterInstallationAdmission:
    return training_common.verify_filter_installation_final_for_neural(
        output_root=output_root,
        training_admission=training_admission,
        training_admission_record=training_admission_record,
    )


@dataclass(frozen=True)
class PeriodArrays:
    dates_ns: np.ndarray
    forcing: np.ndarray
    observations: np.ndarray


@dataclass(frozen=True)
class CausalWindow:
    forcing: np.ndarray
    lagged_discharge: np.ndarray
    forcing_indices: np.ndarray
    discharge_source_indices: np.ndarray
    target_discharge: float
    target_index: int
    origin_index: int
    lead_days: int


@dataclass(frozen=True)
class DatasetSpec:
    basin_count: int
    sequence_length: int
    first_target_index: int
    training_day_count: int
    validation_day_count: int
    expected_training_samples: int
    expected_validation_samples: int
    training_start_ns: int | None = None
    training_end_ns: int | None = None
    validation_start_ns: int | None = None
    validation_end_ns: int | None = None


@dataclass(frozen=True)
class TrainingScaler:
    basin_ids: tuple[str, ...]
    forcing_center: np.ndarray
    forcing_scale: np.ndarray
    discharge_center: float
    discharge_scale: float
    per_basin_discharge_std: np.ndarray
    training_row_count: int

    def __post_init__(self) -> None:
        center = np.asarray(self.forcing_center, dtype=np.float64).copy()
        scale = np.asarray(self.forcing_scale, dtype=np.float64).copy()
        basin_std = np.asarray(self.per_basin_discharge_std, dtype=np.float64).copy()
        if center.shape != (3,) or scale.shape != (3,):
            raise ValueError("forcing scaler arrays must each have shape [3]")
        if basin_std.shape != (len(self.basin_ids),):
            raise ValueError("per-basin discharge scales do not match basin order")
        if not np.isfinite(center).all() or not np.isfinite(scale).all():
            raise FloatingPointError("forcing normalization contains a non-finite value")
        if not np.isfinite(basin_std).all():
            raise FloatingPointError("basin discharge weights contain a non-finite value")
        if np.any(scale <= 0.0) or np.any(basin_std <= 0.0):
            raise ValueError("all training standard deviations must be positive")
        if not math.isfinite(float(self.discharge_center)):
            raise FloatingPointError("discharge center is non-finite")
        if not math.isfinite(float(self.discharge_scale)) or self.discharge_scale <= 0.0:
            raise ValueError("discharge scale must be finite and positive")
        if int(self.training_row_count) <= 0:
            raise ValueError("training row count must be positive")
        center.setflags(write=False)
        scale.setflags(write=False)
        basin_std.setflags(write=False)
        object.__setattr__(self, "forcing_center", center)
        object.__setattr__(self, "forcing_scale", scale)
        object.__setattr__(self, "per_basin_discharge_std", basin_std)
        object.__setattr__(self, "discharge_center", float(self.discharge_center))
        object.__setattr__(self, "discharge_scale", float(self.discharge_scale))
        object.__setattr__(self, "training_row_count", int(self.training_row_count))

    def discharge_std_for_index(self, basin_index: int) -> float:
        return float(self.per_basin_discharge_std[int(basin_index)])


def _reject_nonfinite_json(token: str) -> None:
    raise ValueError(f"non-finite JSON token is forbidden: {token}")


def _canonical_json_bytes(value: Any) -> bytes:
    text = json.dumps(
        value,
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    )
    return (text + "\n").encode("utf-8")


def _canonical_json_sha256(value: Any) -> str:
    return hashlib.sha256(_canonical_json_bytes(value)[:-1]).hexdigest()


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _json_load(path: Path) -> dict[str, Any]:
    value = json.loads(
        Path(path).read_text(encoding="utf-8"),
        parse_constant=_reject_nonfinite_json,
    )
    if not isinstance(value, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return value


def _atomic_write_bytes(path: Path, content: bytes) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(
        destination.name + f".tmp-{os.getpid()}-{uuid.uuid4().hex}"
    )
    with temporary.open("xb") as handle:
        handle.write(content)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, destination)


def _atomic_write_json(path: Path, value: Any) -> None:
    _atomic_write_bytes(path, _canonical_json_bytes(value))


def _write_checkpoint(path: Path, payload: Mapping[str, Any]) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(
        destination.name + f".tmp-{os.getpid()}-{uuid.uuid4().hex}"
    )
    with temporary.open("xb") as handle:
        torch.save(dict(payload), handle)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, destination)


def _npz_bytes(arrays: Mapping[str, np.ndarray]) -> bytes:
    stream = io.BytesIO()
    np.savez(stream, **{key: np.asarray(value) for key, value in arrays.items()})
    return stream.getvalue()


def _mapping_or_attribute(value: Any, name: str, default: Any = ...) -> Any:
    if isinstance(value, Mapping) and name in value:
        return value[name]
    if hasattr(value, name):
        return getattr(value, name)
    if default is not ...:
        return default
    raise KeyError(f"training admission context lacks {name}")


def _coerce_period(value: Any) -> PeriodArrays:
    dates = _mapping_or_attribute(value, "dates_ns")
    forcing = _mapping_or_attribute(value, "forcing")
    observations = _mapping_or_attribute(value, "observations")
    return PeriodArrays(
        dates_ns=np.asarray(dates, dtype=np.int64),
        forcing=np.asarray(forcing, dtype=np.float64),
        observations=np.asarray(observations, dtype=np.float64),
    )


def _iso_ns(value: str) -> int:
    return int(np.datetime64(str(value), "ns").astype(np.int64))


def dataset_spec_from_contract(contract: Mapping[str, Any]) -> DatasetSpec:
    if contract.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("scientific experiment identifier changed")
    neural = contract.get("neural_system", {})
    model = neural.get("model", {})
    training = neural.get("training", {})
    if model.get("leads_days") != [1, 2, 3] or model.get("seeds") != [0, 1, 2]:
        raise ValueError("neural lead or seed contract changed")
    expected_training = {
        "sequence_length_days": 365,
        "first_scored_target_index": 365,
        "batch_size": 256,
        "epochs": 30,
        "precision": "float32",
        "expected_training_samples_per_lead": 997_360,
        "expected_validation_samples_per_lead": 166_530,
    }
    for key, expected in expected_training.items():
        if training.get(key) != expected:
            raise ValueError(f"neural training contract changed: {key}")
    periods = contract.get("periods", {})
    training_period = periods.get("training", {})
    validation_period = periods.get("validation", {})
    if training_period.get("input") != ["1999-10-01", "2006-09-30"]:
        raise ValueError("training period changed")
    if validation_period.get("input") != ["2006-10-01", "2008-09-30"]:
        raise ValueError("validation period changed")
    if training_period.get("day_count") != FROZEN_TRAINING_DAYS:
        raise ValueError("training day count changed")
    if validation_period.get("day_count") != FROZEN_VALIDATION_DAYS:
        raise ValueError("validation day count changed")
    if contract.get("population", {}).get("primary_basin_count") != FROZEN_BASIN_COUNT:
        raise ValueError("training population count changed")
    return DatasetSpec(
        basin_count=FROZEN_BASIN_COUNT,
        sequence_length=FROZEN_SEQUENCE_LENGTH,
        first_target_index=FROZEN_SEQUENCE_LENGTH,
        training_day_count=FROZEN_TRAINING_DAYS,
        validation_day_count=FROZEN_VALIDATION_DAYS,
        expected_training_samples=FROZEN_TRAINING_SAMPLES,
        expected_validation_samples=FROZEN_VALIDATION_SAMPLES,
        training_start_ns=_iso_ns(training_period["input"][0]),
        training_end_ns=_iso_ns(training_period["input"][1]),
        validation_start_ns=_iso_ns(validation_period["input"][0]),
        validation_end_ns=_iso_ns(validation_period["input"][1]),
    )


def expected_sample_count(
    *, basin_count: int, day_count: int, first_target_index: int
) -> int:
    values = (basin_count, day_count, first_target_index)
    if any(not isinstance(value, (int, np.integer)) for value in values):
        raise TypeError("sample-count inputs must be integers")
    if int(basin_count) <= 0 or int(first_target_index) < 1:
        raise ValueError("basin count and first target index are invalid")
    per_basin = int(day_count) - int(first_target_index)
    if per_basin <= 0:
        raise ValueError("period is too short for the frozen warmup")
    return int(basin_count) * per_basin


def _validate_period(
    period: PeriodArrays,
    *,
    basin_id: str,
    period_name: str,
    expected_days: int,
    expected_start_ns: int | None,
    expected_end_ns: int | None,
) -> PeriodArrays:
    dates = np.asarray(period.dates_ns, dtype=np.int64)
    forcing = np.asarray(period.forcing, dtype=np.float64)
    observations = np.asarray(period.observations, dtype=np.float64)
    if dates.shape != (int(expected_days),):
        raise ValueError(f"{period_name} date count changed for basin {basin_id}")
    if forcing.shape != (int(expected_days), 3):
        raise ValueError(f"{period_name} forcing shape changed for basin {basin_id}")
    if observations.shape != (int(expected_days),):
        raise ValueError(f"{period_name} discharge shape changed for basin {basin_id}")
    if len(dates) > 1 and np.any(np.diff(dates) != DAY_NS):
        raise ValueError(f"{period_name} dates are not strictly daily: {basin_id}")
    if expected_start_ns is not None and int(dates[0]) != int(expected_start_ns):
        raise ValueError(f"{period_name} start date changed for basin {basin_id}")
    if expected_end_ns is not None and int(dates[-1]) != int(expected_end_ns):
        raise ValueError(f"{period_name} end date changed for basin {basin_id}")
    if not np.isfinite(forcing).all():
        raise FloatingPointError(f"{period_name} forcing is non-finite: {basin_id}")
    if not np.isfinite(observations).all() or np.any(observations < 0.0):
        raise FloatingPointError(f"{period_name} discharge is invalid: {basin_id}")
    return PeriodArrays(dates, forcing, observations)


def validate_training_validation_periods(
    periods_by_basin: Mapping[str, Mapping[str, Any]],
    basin_ids: Sequence[str],
    spec: DatasetSpec,
    *,
    period_gate: Callable[..., Any] | None = None,
) -> dict[str, dict[str, PeriodArrays]]:
    ordered = tuple(str(value) for value in basin_ids)
    if len(ordered) != spec.basin_count or len(set(ordered)) != len(ordered):
        raise ValueError("ordered training basin population changed")
    if set(periods_by_basin) != set(ordered):
        raise ValueError("training arrays do not cover the exact ordered basin population")
    result: dict[str, dict[str, PeriodArrays]] = {}
    for basin_id in ordered:
        supplied = periods_by_basin[basin_id]
        if not isinstance(supplied, Mapping) or set(supplied) != {"training", "validation"}:
            raise ValueError(
                f"basin {basin_id} must expose training and validation periods only"
            )
        result[basin_id] = {}
        for period_name in ("training", "validation"):
            if period_gate is not None:
                period_gate(period_name)
            expected_days = (
                spec.training_day_count
                if period_name == "training"
                else spec.validation_day_count
            )
            expected_start = (
                spec.training_start_ns
                if period_name == "training"
                else spec.validation_start_ns
            )
            expected_end = (
                spec.training_end_ns
                if period_name == "training"
                else spec.validation_end_ns
            )
            result[basin_id][period_name] = _validate_period(
                _coerce_period(supplied[period_name]),
                basin_id=basin_id,
                period_name=period_name,
                expected_days=expected_days,
                expected_start_ns=expected_start,
                expected_end_ns=expected_end,
            )
    return result


def fit_training_scaler(
    periods_by_basin: Mapping[str, Mapping[str, PeriodArrays]],
    basin_ids: Sequence[str],
) -> TrainingScaler:
    ordered = tuple(str(value) for value in basin_ids)
    if set(periods_by_basin) != set(ordered):
        raise ValueError("training scaler basin population differs")
    forcing_rows: list[np.ndarray] = []
    discharge_rows: list[np.ndarray] = []
    per_basin_std: list[float] = []
    for basin_id in ordered:
        periods = periods_by_basin[basin_id]
        if set(periods) != {"training", "validation"}:
            raise ValueError("normalization input contains a forbidden period")
        training = periods["training"]
        forcing = np.asarray(training.forcing, dtype=np.float64)
        discharge = np.asarray(training.observations, dtype=np.float64)
        if not np.isfinite(forcing).all() or not np.isfinite(discharge).all():
            raise FloatingPointError("training normalization input is non-finite")
        basin_std = float(np.std(discharge, ddof=0))
        if not math.isfinite(basin_std) or basin_std <= 0.0:
            raise ValueError(f"training discharge scale is invalid: {basin_id}")
        forcing_rows.append(forcing)
        discharge_rows.append(discharge)
        per_basin_std.append(basin_std)
    all_forcing = np.concatenate(forcing_rows, axis=0)
    all_discharge = np.concatenate(discharge_rows, axis=0)
    return TrainingScaler(
        basin_ids=ordered,
        forcing_center=np.mean(all_forcing, axis=0, dtype=np.float64),
        forcing_scale=np.std(all_forcing, axis=0, ddof=0, dtype=np.float64),
        discharge_center=float(np.mean(all_discharge, dtype=np.float64)),
        discharge_scale=float(np.std(all_discharge, ddof=0, dtype=np.float64)),
        per_basin_discharge_std=np.asarray(per_basin_std, dtype=np.float64),
        training_row_count=int(all_discharge.size),
    )


def training_scaler_payload(scaler: TrainingScaler) -> dict[str, Any]:
    return {
        "schema_version": "tukf09_neural_training_scaler_v1",
        "experiment_id": EXPERIMENT_ID,
        "basin_ids": list(scaler.basin_ids),
        "forcing_feature_order": [
            "precipitation",
            "mean_air_temperature",
            "oudin_potential_evapotranspiration",
        ],
        "forcing_center": scaler.forcing_center.tolist(),
        "forcing_scale": scaler.forcing_scale.tolist(),
        "discharge_center": scaler.discharge_center,
        "discharge_scale": scaler.discharge_scale,
        "per_basin_discharge_standard_deviation": {
            basin_id: scaler.discharge_std_for_index(index)
            for index, basin_id in enumerate(scaler.basin_ids)
        },
        "population_standard_deviation_ddof": 0,
        "normalization_scope": "training_only_global_population_statistics",
        "training_row_count": scaler.training_row_count,
    }


def build_causal_window(
    forcing: np.ndarray,
    observations: np.ndarray,
    *,
    target_index: int,
    lead_days: int,
    sequence_length: int,
) -> CausalWindow:
    forcing_array = np.asarray(forcing, dtype=np.float64)
    observation_array = np.asarray(observations, dtype=np.float64)
    if forcing_array.ndim != 2 or forcing_array.shape[1] != 3:
        raise ValueError("forcing must have shape [days, 3]")
    if observation_array.shape != (len(forcing_array),):
        raise ValueError("discharge must align one-to-one with forcing")
    if int(lead_days) not in FROZEN_LEADS:
        raise ValueError("lead must be one, two, or three days")
    if int(sequence_length) <= 0:
        raise ValueError("sequence length must be positive")
    target = int(target_index)
    start = target - int(sequence_length) + 1
    if start < 0 or target >= len(forcing_array):
        raise ValueError("target does not support the complete reset-period window")
    forcing_indices = np.arange(start, target + 1, dtype=np.int64)
    source_indices = forcing_indices - int(lead_days)
    source_indices = np.where(source_indices < 0, -1, source_indices)
    lagged = np.full((int(sequence_length), 1), np.nan, dtype=np.float64)
    observed = source_indices >= 0
    lagged[observed, 0] = observation_array[source_indices[observed]]
    origin = target - int(lead_days)
    if np.any(source_indices[observed] > origin):
        raise RuntimeError("lagged discharge reads after the forecast origin")
    if not np.array_equal(
        source_indices,
        np.where(forcing_indices - int(lead_days) < 0, -1, forcing_indices - int(lead_days)),
    ):
        raise RuntimeError("lagged discharge source ledger changed")
    return CausalWindow(
        forcing=forcing_array[forcing_indices].copy(),
        lagged_discharge=lagged,
        forcing_indices=forcing_indices,
        discharge_source_indices=source_indices.astype(np.int64, copy=False),
        target_discharge=float(observation_array[target]),
        target_index=target,
        origin_index=origin,
        lead_days=int(lead_days),
    )


class TUKF09NeuralWindowDataset(Dataset):
    """O(1)-indexed 455-basin causal windows without an in-memory sample table."""

    def __init__(
        self,
        periods_by_basin: Mapping[str, Mapping[str, PeriodArrays]],
        basin_ids: Sequence[str],
        scaler: TrainingScaler,
        *,
        period_name: str,
        lead_days: int,
        spec: DatasetSpec,
    ) -> None:
        if period_name not in ("training", "validation"):
            raise ValueError("neural dataset permits training and validation only")
        if int(lead_days) not in FROZEN_LEADS:
            raise ValueError("lead must be one, two, or three days")
        ordered = tuple(str(value) for value in basin_ids)
        if len(ordered) != spec.basin_count or scaler.basin_ids != ordered:
            raise ValueError("dataset population and training scaler differ")
        if set(periods_by_basin) != set(ordered):
            raise ValueError("dataset periods do not cover the exact population")
        day_count = (
            spec.training_day_count
            if period_name == "training"
            else spec.validation_day_count
        )
        expected_total = (
            spec.expected_training_samples
            if period_name == "training"
            else spec.expected_validation_samples
        )
        self.samples_per_basin = int(day_count) - int(spec.first_target_index)
        actual_total = expected_sample_count(
            basin_count=len(ordered),
            day_count=int(day_count),
            first_target_index=int(spec.first_target_index),
        )
        if actual_total != int(expected_total):
            raise ValueError(f"{period_name} sample count changed")
        self.period_name = period_name
        self.lead_days = int(lead_days)
        self.sequence_length = int(spec.sequence_length)
        self.first_target_index = int(spec.first_target_index)
        self.basin_ids = ordered
        self.scaler = scaler
        self._periods = {
            basin_id: periods_by_basin[basin_id][period_name] for basin_id in ordered
        }
        self._sample_count = actual_total

    def __len__(self) -> int:
        return self._sample_count

    def __getitem__(self, index: int) -> dict[str, Any]:
        item = int(index)
        if item < 0:
            item += len(self)
        if item < 0 or item >= len(self):
            raise IndexError(index)
        basin_index, offset = divmod(item, self.samples_per_basin)
        target_index = self.first_target_index + offset
        basin_id = self.basin_ids[basin_index]
        period = self._periods[basin_id]
        window = build_causal_window(
            period.forcing,
            period.observations,
            target_index=target_index,
            lead_days=self.lead_days,
            sequence_length=self.sequence_length,
        )
        standardized_forcing = (
            window.forcing - self.scaler.forcing_center
        ) / self.scaler.forcing_scale
        standardized_lagged = (
            window.lagged_discharge - self.scaler.discharge_center
        ) / self.scaler.discharge_scale
        standardized_target = (
            window.target_discharge - self.scaler.discharge_center
        ) / self.scaler.discharge_scale
        if not np.isfinite(standardized_forcing).all():
            raise FloatingPointError("standardized forcing is non-finite")
        finite_lagged = np.isfinite(standardized_lagged)
        if not np.isfinite(standardized_lagged[finite_lagged]).all():
            raise FloatingPointError("standardized lagged discharge is non-finite")
        if not math.isfinite(float(standardized_target)):
            raise FloatingPointError("standardized target is non-finite")
        return {
            "basin_id": basin_id,
            "basin_index": basin_index,
            "target_index": window.target_index,
            "origin_index": window.origin_index,
            "target_date_ns": int(period.dates_ns[target_index]),
            "forcing": torch.as_tensor(standardized_forcing, dtype=torch.float32),
            "lagged_discharge": torch.as_tensor(
                standardized_lagged, dtype=torch.float32
            ),
            "target": torch.tensor([standardized_target], dtype=torch.float32),
            "target_discharge_raw": torch.tensor(
                [window.target_discharge], dtype=torch.float32
            ),
            "basin_discharge_std": torch.tensor(
                [self.scaler.discharge_std_for_index(basin_index)],
                dtype=torch.float32,
            ),
        }


def configure_float32_device_arithmetic() -> dict[str, bool]:
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    state = {
        "cuda_matrix_multiplication_tensorfloat32": bool(
            torch.backends.cuda.matmul.allow_tf32
        ),
        "cudnn_tensorfloat32": bool(torch.backends.cudnn.allow_tf32),
    }
    if state != {
        "cuda_matrix_multiplication_tensorfloat32": False,
        "cudnn_tensorfloat32": False,
    }:
        raise RuntimeError("TensorFloat32 could not be disabled")
    return state


def require_formal_training_device(
    device: str | torch.device | None,
    *,
    cuda_available: bool | None = None,
    cuda_device_count: int | None = None,
) -> torch.device:
    selected = torch.device("cuda:0" if device is None else device)
    if selected != torch.device("cuda:0"):
        raise ValueError("formal neural training device must be exactly cuda:0")
    available = torch.cuda.is_available() if cuda_available is None else bool(cuda_available)
    count = torch.cuda.device_count() if cuda_device_count is None else int(cuda_device_count)
    if not available or count < 1:
        raise RuntimeError("formal neural training requires graphics processor cuda:0")
    return selected


def set_global_seed(seed: int) -> None:
    if int(seed) not in FROZEN_SEEDS:
        raise ValueError("seed must be zero, one, or two")
    random.seed(int(seed))
    np.random.seed(int(seed))
    torch.manual_seed(int(seed))
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(int(seed))


def capture_random_states() -> dict[str, Any]:
    return {
        "python": copy.deepcopy(random.getstate()),
        "numpy": copy.deepcopy(np.random.get_state()),
        "torch_cpu": torch.get_rng_state().cpu().clone(),
        "torch_cuda": (
            [state.cpu().clone() for state in torch.cuda.get_rng_state_all()]
            if torch.cuda.is_available()
            else []
        ),
    }


def create_sampler_generator(seed: int) -> torch.Generator:
    generator = torch.Generator(device="cpu")
    generator.manual_seed(int(seed))
    return generator


def create_target_noise_generator(seed: int) -> torch.Generator:
    generator = torch.Generator(device="cpu")
    generator.manual_seed(1_000_000 + int(seed))
    return generator


def apply_target_noise(
    target: torch.Tensor,
    *,
    discharge_center: float,
    discharge_scale: float,
    generator: torch.Generator,
    noise_standard_deviation: float = 0.005,
) -> torch.Tensor:
    if not torch.is_floating_point(target) or not torch.isfinite(target).all():
        raise FloatingPointError("target must be finite floating point")
    if not math.isfinite(float(discharge_center)):
        raise FloatingPointError("discharge center is non-finite")
    if not math.isfinite(float(discharge_scale)) or discharge_scale <= 0.0:
        raise ValueError("discharge scale must be finite and positive")
    if float(noise_standard_deviation) != 0.005:
        raise ValueError("target-noise standard deviation changed")
    noise = torch.randn(
        tuple(target.shape),
        dtype=target.dtype,
        device="cpu",
        generator=generator,
    ).to(target.device)
    result = target + (
        target + float(discharge_center) / float(discharge_scale)
    ) * (noise * float(noise_standard_deviation))
    if not torch.isfinite(result).all():
        raise FloatingPointError("noisy target is non-finite")
    return result


def basin_balanced_nse_loss(
    prediction: torch.Tensor,
    target: torch.Tensor,
    basin_std: torch.Tensor,
    *,
    epsilon: float = 0.1,
) -> torch.Tensor:
    if float(epsilon) != 0.1:
        raise ValueError("loss epsilon changed")
    if prediction.shape != target.shape or basin_std.shape != target.shape:
        raise ValueError("prediction, target, and basin weights must align")
    if not torch.isfinite(prediction).all() or not torch.isfinite(target).all():
        raise FloatingPointError("loss input is non-finite")
    if not torch.isfinite(basin_std).all() or torch.any(basin_std <= 0.0):
        raise ValueError("basin discharge weights are invalid")
    loss = torch.mean(torch.square(prediction - target) / torch.square(basin_std + 0.1))
    if not torch.isfinite(loss):
        raise FloatingPointError("training loss is non-finite")
    return loss


def learning_rate_for_epoch(epoch: int) -> float:
    number = int(epoch)
    if number < 1 or number > FROZEN_EPOCHS:
        raise ValueError("epoch must be from one through thirty")
    if number >= 25:
        return 0.0001
    if number >= 10:
        return 0.0005
    return 0.001


def select_validation_checkpoint(validation_nse: np.ndarray) -> int:
    values = np.asarray(validation_nse, dtype=np.float64)
    if values.shape != (FROZEN_EPOCHS, FROZEN_BASIN_COUNT):
        raise ValueError("validation history must have shape [30, 455]")
    if not np.isfinite(values).all():
        raise FloatingPointError("validation history is non-finite")
    medians = np.median(values, axis=1)
    maximum = float(np.max(medians))
    return int(np.flatnonzero(medians == maximum)[0]) + 1


def _set_learning_rate(optimizer: torch.optim.Optimizer, epoch: int) -> float:
    value = learning_rate_for_epoch(epoch)
    for group in optimizer.param_groups:
        group["lr"] = value
    return value


def _run_training_epoch(
    *,
    model: DirectAutoregressiveLSTM,
    optimizer: torch.optim.Optimizer,
    loader: DataLoader,
    scaler: TrainingScaler,
    target_noise_generator: torch.Generator,
    device: torch.device,
) -> tuple[float, float]:
    model.train()
    loss_sum = 0.0
    sample_count = 0
    maximum_gradient_norm = 0.0
    for batch in loader:
        forcing = batch["forcing"].to(device)
        lagged = batch["lagged_discharge"].to(device)
        target = batch["target"].to(device)
        basin_std = batch["basin_discharge_std"].to(device)
        noisy_target = apply_target_noise(
            target,
            discharge_center=scaler.discharge_center,
            discharge_scale=scaler.discharge_scale,
            generator=target_noise_generator,
        )
        optimizer.zero_grad(set_to_none=True)
        prediction = model(forcing, lagged)["y_hat"][:, -1, :]
        loss = basin_balanced_nse_loss(prediction, noisy_target, basin_std)
        loss.backward()
        gradients = [
            parameter.grad for parameter in model.parameters() if parameter.grad is not None
        ]
        if not gradients or any(not torch.isfinite(value).all() for value in gradients):
            raise FloatingPointError("model gradient is absent or non-finite")
        norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        if not torch.isfinite(norm):
            raise FloatingPointError("global gradient norm is non-finite")
        optimizer.step()
        if any(not torch.isfinite(parameter).all() for parameter in model.parameters()):
            raise FloatingPointError("model parameter became non-finite")
        count = int(target.shape[0])
        loss_sum += float(loss.detach().cpu()) * count
        sample_count += count
        maximum_gradient_norm = max(maximum_gradient_norm, float(norm.detach().cpu()))
    if sample_count != len(loader.dataset):
        raise RuntimeError("training loader did not visit every sample exactly once")
    mean_loss = loss_sum / sample_count
    if not math.isfinite(mean_loss):
        raise FloatingPointError("mean training loss is non-finite")
    return float(mean_loss), float(maximum_gradient_norm)


def _run_validation(
    *,
    model: DirectAutoregressiveLSTM,
    loader: DataLoader,
    scaler: TrainingScaler,
    device: torch.device,
    basin_count: int,
    samples_per_basin: int,
) -> np.ndarray:
    model.eval()
    expected = int(basin_count) * int(samples_per_basin)
    predictions = np.empty(expected, dtype=np.float64)
    targets = np.empty(expected, dtype=np.float64)
    cursor = 0
    with torch.no_grad():
        for batch in loader:
            standardized = model(
                batch["forcing"].to(device),
                batch["lagged_discharge"].to(device),
            )["y_hat"][:, -1, 0]
            raw_prediction = (
                standardized * scaler.discharge_scale + scaler.discharge_center
            ).detach().cpu().to(torch.float64).numpy()
            raw_target = batch["target_discharge_raw"][:, 0].to(torch.float64).numpy()
            count = len(raw_target)
            predictions[cursor : cursor + count] = raw_prediction
            targets[cursor : cursor + count] = raw_target
            cursor += count
    if cursor != expected:
        raise RuntimeError("validation loader did not visit every sample exactly once")
    if not np.isfinite(predictions).all() or not np.isfinite(targets).all():
        raise FloatingPointError("validation prediction or target is non-finite")
    prediction_matrix = predictions.reshape(int(basin_count), int(samples_per_basin))
    target_matrix = targets.reshape(int(basin_count), int(samples_per_basin))
    centered = target_matrix - np.mean(target_matrix, axis=1, keepdims=True)
    denominator = np.sum(np.square(centered), axis=1, dtype=np.float64)
    if not np.isfinite(denominator).all() or np.any(denominator <= 0.0):
        raise ValueError("validation target variance is not positive for every basin")
    numerator = np.sum(
        np.square(prediction_matrix - target_matrix), axis=1, dtype=np.float64
    )
    scores = 1.0 - numerator / denominator
    if scores.shape != (int(basin_count),) or not np.isfinite(scores).all():
        raise FloatingPointError("validation efficiency is non-finite")
    return scores


def _unit_member_names() -> tuple[str, ...]:
    return (
        "identity.json",
        *tuple(f"checkpoints/epoch_{epoch:03d}.pt" for epoch in range(1, 31)),
        "validation_history.npz",
        "model_selection.json",
        "access_ledger.json",
    )


def _manifest_for_directory(directory: Path, unit_id: str) -> dict[str, Any]:
    root = Path(directory)
    if not root.is_dir() or _is_link_or_reparse(root):
        raise RuntimeError("neural unit directory is absent, linked, or reparse-backed")
    expected = _unit_member_names()
    files_on_disk: set[str] = set()
    directories_on_disk: set[str] = set()
    for path in root.rglob("*"):
        if _is_link_or_reparse(path):
            raise RuntimeError("neural unit contains a linked or reparse-backed member")
        relative = path.relative_to(root).as_posix()
        if path.is_dir():
            directories_on_disk.add(relative)
            continue
        if not path.is_file() or int(path.stat().st_nlink) != 1:
            raise RuntimeError("neural unit contains a non-regular or multiply-linked member")
        if relative != "manifest.sha256.json":
            files_on_disk.add(relative)
    if directories_on_disk != {"checkpoints"}:
        raise RuntimeError(
            f"neural unit directory set differs: {sorted(directories_on_disk)}"
        )
    if files_on_disk != set(expected):
        missing = sorted(set(expected).difference(files_on_disk))
        extra = sorted(files_on_disk.difference(expected))
        raise RuntimeError(f"neural unit member set differs; missing={missing}, extra={extra}")
    members: dict[str, dict[str, Any]] = {}
    for relative in expected:
        path = root / Path(relative)
        if _is_link_or_reparse(path) or not path.is_file() or int(path.stat().st_nlink) != 1:
            raise RuntimeError(f"neural unit member is missing or linked: {relative}")
        members[relative] = {
            "sha256": sha256_file(path),
            "size_bytes": int(path.stat().st_size),
        }
    if len(members) != UNIT_MEMBER_COUNT:
        raise AssertionError("internal neural unit member count changed")
    return {
        "schema_version": "tukf09_neural_unit_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "unit_type": "neural_lead_seed",
        "unit_id": str(unit_id),
        "file_count": UNIT_MEMBER_COUNT,
        "files": members,
    }


def validate_complete_unit(directory: Path, unit_id: str) -> dict[str, Any]:
    root = Path(directory)
    if not root.is_dir() or _is_link_or_reparse(root):
        raise RuntimeError("neural unit directory is absent or linked")
    manifest_path = root / "manifest.sha256.json"
    if (
        not manifest_path.is_file()
        or _is_link_or_reparse(manifest_path)
        or int(manifest_path.stat().st_nlink) != 1
    ):
        raise RuntimeError("neural unit manifest is absent or linked")
    manifest_bytes = manifest_path.read_bytes()
    stored = _json_load(manifest_path)
    if manifest_bytes != _canonical_json_bytes(stored):
        raise RuntimeError("neural unit manifest is not canonical JSON")
    recomputed = _manifest_for_directory(root, unit_id)
    if stored != recomputed:
        raise RuntimeError("neural unit manifest differs from current members")
    all_files = {
        path.relative_to(root).as_posix() for path in root.rglob("*") if path.is_file()
    }
    if all_files != set(_unit_member_names()).union({"manifest.sha256.json"}):
        raise RuntimeError("neural unit contains an unexpected file")
    return stored


def _require_sha256(value: Any, *, label: str) -> str:
    if not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{64}", value) is None:
        raise RuntimeError(f"{label} is not a lowercase SHA-256 digest")
    return value


def _canonical_json_object(path: Path, *, label: str) -> dict[str, Any]:
    candidate = Path(path)
    if (
        not candidate.is_file()
        or _is_link_or_reparse(candidate)
        or int(candidate.stat().st_nlink) != 1
    ):
        raise RuntimeError(f"{label} is absent, linked, or multiply linked")
    raw = candidate.read_bytes()
    payload = _json_load(candidate)
    if raw != _canonical_json_bytes(payload):
        raise RuntimeError(f"{label} is not canonical JSON")
    return payload


def _ordered_basin_compact_digest(basin_ids: Sequence[str]) -> str:
    # Byte-for-byte the form the admission producer hashes: a compact JSON list.
    encoded = json.dumps(
        list(basin_ids), ensure_ascii=False, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _ordered_basin_summary(ordered_basin_ids: Sequence[str]) -> tuple[tuple[str, ...], str]:
    basin_ids = tuple(str(value) for value in ordered_basin_ids)
    if (
        len(basin_ids) != FROZEN_BASIN_COUNT
        or len(set(basin_ids)) != FROZEN_BASIN_COUNT
        or any(re.fullmatch(r"[0-9]{8}", value) is None for value in basin_ids)
    ):
        raise RuntimeError("trusted neural unit requires exactly 455 unique eight-digit basins")
    digest = hashlib.sha256(
        "".join(f"{value}\n" for value in basin_ids).encode("utf-8")
    ).hexdigest()
    return basin_ids, digest


def _admitted_current_source_sha256(
    training_admission_record: Mapping[str, Any],
    *,
    relative_path: str,
    current_path: Path,
) -> str:
    executables = training_admission_record.get("executables")
    if not isinstance(executables, Mapping):
        raise RuntimeError("trusted neural unit requires admitted executable records")
    record = executables.get(relative_path)
    if not isinstance(record, Mapping) or set(record) != {"sha256", "size_bytes"}:
        raise RuntimeError(f"admitted executable record changed: {relative_path}")
    path = Path(current_path)
    if (
        not path.is_file()
        or _is_link_or_reparse(path)
        or int(path.stat().st_nlink) != 1
    ):
        raise RuntimeError(f"current admitted source is absent or linked: {relative_path}")
    current_sha256 = sha256_file(path)
    admitted_sha256 = _require_sha256(
        record.get("sha256"), label=f"admitted executable hash for {relative_path}"
    )
    if (
        admitted_sha256 != current_sha256
        or type(record.get("size_bytes")) is not int
        or int(record["size_bytes"]) != int(path.stat().st_size)
    ):
        raise RuntimeError(f"current source differs from training admission: {relative_path}")
    return current_sha256


def training_scaler_sha256(scaler: TrainingScaler) -> str:
    return _sha256_bytes(_canonical_json_bytes(training_scaler_payload(scaler)))


def validate_shared_training_scaler(
    output_root: Path,
    *,
    expected_sha256: str | None = None,
) -> str:
    shared = Path(output_root) / "neural" / "shared"
    scaler_path = shared / "training_scaler.json"
    if not shared.is_dir() or _is_link_or_reparse(shared):
        raise RuntimeError("shared neural training scaler directory is absent or linked")
    members = list(shared.iterdir())
    if len(members) != 1 or members[0] != scaler_path:
        raise RuntimeError("shared neural training scaler directory differs")
    payload = _canonical_json_object(scaler_path, label="shared neural training scaler")
    raw = scaler_path.read_bytes()
    if raw != _canonical_json_bytes(payload):
        raise RuntimeError("shared neural training scaler differs from canonical content")
    digest = _sha256_bytes(raw)
    if expected_sha256 is not None:
        expected = _require_sha256(expected_sha256, label="expected training scaler hash")
        if digest != expected:
            raise RuntimeError("shared neural training scaler hash differs")
    return digest


def validate_reusable_complete_unit(
    directory: Path,
    unit_id: str,
    *,
    training_admission_record: Mapping[str, Any],
    ordered_basin_ids: Sequence[str],
    training_scaler_sha256_value: str,
) -> dict[str, Any]:
    """Validate that an exact unit is also bound to the current admitted production run."""

    manifest = validate_complete_unit(directory, unit_id)
    expected_unit = FROZEN_UNIT_SPECS.get(str(unit_id))
    if expected_unit is None or len(FROZEN_UNIT_SPECS) != 9:
        raise RuntimeError("trusted neural unit is not one of the fixed nine lead-seed units")
    lead_days, seed = expected_unit
    basin_ids, basin_digest = _ordered_basin_summary(ordered_basin_ids)
    population = training_admission_record.get("population")
    # The admission records the population three ways. Every one of them is re-derived here
    # from the basins this unit was trained on, and the block must carry exactly those three
    # keys with exactly those values.
    expected_population = {
        "ordered_basin_count": FROZEN_BASIN_COUNT,
        "ordered_newline_sha256": basin_digest,
        "compact_json_sha256": _ordered_basin_compact_digest(basin_ids),
    }
    if not isinstance(population, Mapping) or dict(population) != expected_population:
        raise RuntimeError("training admission basin population differs from the neural unit")
    admission_sha256 = _require_sha256(
        training_admission_record.get("training_admission_record_sha256"),
        label="training admission record hash",
    )
    scaler_sha256 = _require_sha256(
        training_scaler_sha256_value, label="training scaler hash"
    )
    runner_sha256 = _admitted_current_source_sha256(
        training_admission_record,
        relative_path=NEURAL_RUNNER_RELATIVE_PATH,
        current_path=Path(__file__).resolve(),
    )
    model_sha256 = _admitted_current_source_sha256(
        training_admission_record,
        relative_path=FROZEN_MODEL_RELATIVE_PATH,
        current_path=ROOT / FROZEN_MODEL_RELATIVE_PATH,
    )

    root = Path(directory)
    identity = _canonical_json_object(root / "identity.json", label="neural unit identity")
    required_identity_keys = {
        "schema_version",
        "experiment_id",
        "unit_type",
        "unit_id",
        "lead_days",
        "seed",
        "basin_count",
        "ordered_basin_newline_sha256",
        "training_sample_count",
        "validation_sample_count",
        "epochs",
        "batch_size",
        "training_scaler_sha256",
        "runner_sha256",
        "frozen_model_source_sha256",
        "torch_version",
        "device",
        "tensorfloat32",
        "evaluation_access_count",
        "admission_evidence",
        "identity_sha256",
    }
    if set(identity) != required_identity_keys:
        raise RuntimeError("trusted neural unit identity schema changed")
    expected_identity_values = {
        "schema_version": "tukf09_neural_unit_identity_v1",
        "experiment_id": EXPERIMENT_ID,
        "unit_type": "neural_lead_seed",
        "unit_id": str(unit_id),
        "lead_days": int(lead_days),
        "seed": int(seed),
        "basin_count": FROZEN_BASIN_COUNT,
        "ordered_basin_newline_sha256": basin_digest,
        "training_sample_count": FROZEN_TRAINING_SAMPLES,
        "validation_sample_count": FROZEN_VALIDATION_SAMPLES,
        "epochs": FROZEN_EPOCHS,
        "batch_size": FROZEN_BATCH_SIZE,
        "training_scaler_sha256": scaler_sha256,
        "runner_sha256": runner_sha256,
        "frozen_model_source_sha256": model_sha256,
        "torch_version": str(torch.__version__),
        "device": "cuda:0",
        "tensorfloat32": False,
        "evaluation_access_count": 0,
    }
    for key, expected in expected_identity_values.items():
        if identity.get(key) != expected or type(identity.get(key)) is not type(expected):
            raise RuntimeError(f"trusted neural unit identity differs: {key}")
    evidence = identity.get("admission_evidence")
    if (
        not isinstance(evidence, Mapping)
        or evidence.get("training_admission_record_sha256") != admission_sha256
    ):
        raise RuntimeError("trusted neural unit admission identity differs")
    recorded_identity_sha256 = _require_sha256(
        identity.get("identity_sha256"), label="neural unit identity hash"
    )
    unsigned_identity = dict(identity)
    del unsigned_identity["identity_sha256"]
    if recorded_identity_sha256 != _canonical_json_sha256(unsigned_identity):
        raise RuntimeError("neural unit identity hash does not match its content")

    selection = _canonical_json_object(
        root / "model_selection.json", label="neural unit model selection"
    )
    if (
        selection.get("unit_id") != str(unit_id)
        or selection.get("lead_days") != int(lead_days)
        or selection.get("seed") != int(seed)
        or selection.get("checkpoint_count") != FROZEN_EPOCHS
        or selection.get("evaluation_access_count") != 0
    ):
        raise RuntimeError("trusted neural unit model-selection identity differs")
    ledger = _canonical_json_object(
        root / "access_ledger.json", label="neural unit access ledger"
    )
    expected_ledger = {
        "schema_version": "tukf09_neural_access_ledger_v1",
        "experiment_id": EXPERIMENT_ID,
        "unit_id": str(unit_id),
        "lead_days": int(lead_days),
        "training": {
            "sample_count": FROZEN_TRAINING_SAMPLES,
            "first_target_index": FROZEN_SEQUENCE_LENGTH,
            "last_target_index": FROZEN_TRAINING_DAYS - 1,
            "maximum_discharge_source_offset_days": int(lead_days),
            "meteorological_forcing_through_target": True,
        },
        "validation": {
            "sample_count": FROZEN_VALIDATION_SAMPLES,
            "first_target_index": FROZEN_SEQUENCE_LENGTH,
            "last_target_index": FROZEN_VALIDATION_DAYS - 1,
            "maximum_discharge_source_offset_days": int(lead_days),
            "meteorological_forcing_through_target": True,
        },
        "evaluation_access_count": 0,
        "evaluation_prediction_count": 0,
        "evaluation_metric_count": 0,
    }
    if ledger != expected_ledger:
        raise RuntimeError("trusted neural unit access ledger differs or records evaluation")
    return manifest


def publish_complete_unit(pending: Path, final: Path, unit_id: str) -> dict[str, Any]:
    pending_root = Path(pending)
    final_root = Path(final)
    if final_root.exists() or final_root.is_symlink():
        if pending_root.exists() or pending_root.is_symlink():
            raise RuntimeError("complete neural unit appeared while this unit was pending")
        manifest = validate_complete_unit(final_root, unit_id)
        return {"manifest": manifest, "reused": True}
    if pending_root.parent.resolve(strict=False) != final_root.parent.resolve(strict=False):
        raise ValueError("pending and final neural units must be siblings")
    manifest = _manifest_for_directory(pending_root, unit_id)
    _atomic_write_json(pending_root / "manifest.sha256.json", manifest)
    validate_complete_unit(pending_root, unit_id)
    os.replace(pending_root, final_root)
    final_manifest = validate_complete_unit(final_root, unit_id)
    return {"manifest": final_manifest, "reused": False}


def parse_pending_owner(path: Path, unit_id: str) -> tuple[int, str] | None:
    match = re.fullmatch(
        re.escape(str(unit_id)) + r"\.pending-([1-9][0-9]*)-([0-9a-f]{32})",
        Path(path).name,
    )
    if match is None:
        return None
    return int(match.group(1)), match.group(2)


def parse_shared_pending_owner(path: Path) -> tuple[int, str] | None:
    match = re.fullmatch(
        r"shared\.pending-([1-9][0-9]*)-([0-9a-f]{32})",
        Path(path).name,
    )
    if match is None:
        return None
    return int(match.group(1)), match.group(2)


def _is_link_or_reparse(path: Path) -> bool:
    candidate = Path(path)
    if candidate.is_symlink():
        return True
    stat = os.lstat(candidate)
    attributes = int(getattr(stat, "st_file_attributes", 0))
    reparse_flag = int(getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))
    return bool(attributes & reparse_flag)


def remove_owned_pending(
    pending: Path,
    neural_root: Path,
    unit_id: str,
    *,
    expected_pid: int,
    expected_token: str,
) -> None:
    candidate = Path(pending)
    parent = Path(neural_root)
    owner = parse_pending_owner(candidate, unit_id)
    if owner != (int(expected_pid), str(expected_token)):
        raise RuntimeError("pending neural unit owner identity differs")
    if candidate.parent.resolve(strict=False) != parent.resolve(strict=False):
        raise RuntimeError("pending neural unit escapes its fixed parent")
    if not candidate.exists() or not candidate.is_dir() or _is_link_or_reparse(candidate):
        raise RuntimeError("pending neural unit is absent, linked, or reparse-backed")
    allowed_files = set(_unit_member_names()).union({"manifest.sha256.json"})
    allowed_directories = {"checkpoints"}
    for child in candidate.rglob("*"):
        if _is_link_or_reparse(child):
            raise RuntimeError("pending neural unit contains a linked member")
        relative = child.relative_to(candidate).as_posix()
        if child.is_dir():
            if relative not in allowed_directories:
                raise RuntimeError("pending neural unit contains an unexpected directory")
            continue
        if relative in allowed_files:
            continue
        if ".tmp-" in relative:
            base = relative.split(".tmp-", 1)[0]
            suffix = relative.split(".tmp-", 1)[1]
            if base in allowed_files and re.fullmatch(
                r"[1-9][0-9]*-[0-9a-f]{32}", suffix
            ):
                continue
        raise RuntimeError(f"pending neural unit contains an unexpected file: {relative}")
    shutil.rmtree(candidate)
    if os.path.lexists(os.fspath(candidate)):
        raise RuntimeError("owned pending neural unit cleanup was incomplete")


def remove_owned_shared_pending(
    pending: Path,
    neural_root: Path,
    *,
    expected_pid: int,
    expected_token: str,
) -> None:
    candidate = Path(pending)
    parent = Path(neural_root)
    owner = parse_shared_pending_owner(candidate)
    if owner != (int(expected_pid), str(expected_token)):
        raise RuntimeError("pending shared scaler owner identity differs")
    if candidate.parent.resolve(strict=False) != parent.resolve(strict=False):
        raise RuntimeError("pending shared scaler escapes its fixed parent")
    if not candidate.exists() or not candidate.is_dir() or _is_link_or_reparse(candidate):
        raise RuntimeError("pending shared scaler is absent, linked, or reparse-backed")
    for child in candidate.rglob("*"):
        if _is_link_or_reparse(child):
            raise RuntimeError("pending shared scaler contains a linked member")
        if child.is_dir():
            raise RuntimeError("pending shared scaler contains an unexpected directory")
        relative = child.relative_to(candidate).as_posix()
        if relative == "training_scaler.json":
            continue
        match = re.fullmatch(
            r"training_scaler\.json\.tmp-([1-9][0-9]*)-([0-9a-f]{32})",
            relative,
        )
        if match is not None and int(match.group(1)) == int(expected_pid):
            continue
        raise RuntimeError(
            f"pending shared scaler contains an unexpected file: {relative}"
        )
    shutil.rmtree(candidate)
    if os.path.lexists(os.fspath(candidate)):
        raise RuntimeError("owned pending shared scaler cleanup was incomplete")


def _publish_shared_scaler(output_root: Path, scaler: TrainingScaler) -> dict[str, Any]:
    neural_root = Path(output_root) / "neural"
    shared = neural_root / "shared"
    scaler_path = shared / "training_scaler.json"
    content = _canonical_json_bytes(training_scaler_payload(scaler))
    digest = training_scaler_sha256(scaler)
    if shared.exists() or shared.is_symlink():
        if _is_link_or_reparse(shared) or not shared.is_dir():
            raise RuntimeError("shared neural directory is linked or invalid")
        members = list(shared.iterdir())
        if members != [scaler_path] and set(members) != {scaler_path}:
            raise RuntimeError("shared neural directory contains an unexpected member")
        if (
            _is_link_or_reparse(scaler_path)
            or not scaler_path.is_file()
            or int(scaler_path.stat().st_nlink) != 1
            or scaler_path.read_bytes() != content
        ):
            raise RuntimeError("shared training scaler differs")
        return {"path": scaler_path, "sha256": digest, "reused": True}
    neural_root.mkdir(parents=True, exist_ok=True)
    pending = neural_root / f"shared.pending-{os.getpid()}-{uuid.uuid4().hex}"
    pending.mkdir(parents=False, exist_ok=False)
    _atomic_write_bytes(pending / "training_scaler.json", content)
    os.replace(pending, shared)
    if scaler_path.read_bytes() != content:
        raise RuntimeError("published shared training scaler differs")
    return {"path": scaler_path, "sha256": digest, "reused": False}


def _load_admission_context(
    config_path: Path,
    preflight_root: Path,
    authorization: Path,
    output_root: Path,
) -> tuple[Any, Callable[..., Any] | None, Mapping[str, Mapping[str, Any]]]:
    try:
        from scripts.tukf09_455_training_common import (  # type: ignore
            gate_training_period_only,
            load_training_validation_periods_455,
            verify_preflight_for_revision_training,
        )
    except ImportError as exc:  # pragma: no cover - integration sequencing guard
        raise RuntimeError("TUKF09 training admission module is unavailable") from exc
    preflight = Path(preflight_root)
    final_manifest = (
        preflight / "independent" / "manifest.final.sha256.json"
        if preflight.is_dir()
        else preflight
    )
    context = verify_preflight_for_revision_training(
        Path(config_path),
        final_manifest,
        Path(authorization),
        Path(output_root),
        require_output_absent=False,
        recompute_training_validation_semantics=False,
        verify_all_raw_source_bytes=False,
    )
    periods = load_training_validation_periods_455(context)
    return context, gate_training_period_only, periods


def _load_verified_training_admission(
    training_admission: Path | None,
    execution_config: Path | None,
) -> dict[str, Any]:
    if training_admission is None or execution_config is None:
        raise ValueError(
            "training-admission and execution-config paths are required before training"
        )
    try:
        from scripts import tukf09_455_training_common as common  # type: ignore
    except ImportError as exc:  # pragma: no cover - integration sequencing guard
        raise RuntimeError("TUKF09 training admission module is unavailable") from exc
    required_executables = tuple(
        ROOT / relative
        for relative in common.REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS
    )
    return common.load_and_verify_training_admission(
        Path(training_admission),
        Path(execution_config),
        required_executables,
    )


def _verify_initialized_training_root(
    *,
    output_root: Path,
    config_path: Path,
    authorization: Path,
    execution_config: Path,
    training_admission: Path,
    training_admission_record: Mapping[str, Any],
) -> dict[str, Any]:
    from scripts import tukf09_455_training_common as common

    return common.verify_initialized_training_root(
        output_root=output_root,
        config_path=config_path,
        authorization=authorization,
        execution_config=execution_config,
        training_admission=training_admission,
        training_admission_record=training_admission_record,
    )


def _identity_evidence(
    context: Any,
    training_admission_record: Mapping[str, Any],
) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key in (
        "contract_sha256",
        "preflight_final_manifest_sha256",
        "population_sha256",
        "training_semantic_sha256",
        "validation_semantic_sha256",
        "source_hashes",
        "source_anchor_sha256",
        "raw_source_hashes",
        "evaluation_identity_sha256",
    ):
        value = _mapping_or_attribute(context, key, None)
        if value is not None:
            result[key] = value
    authorization = _mapping_or_attribute(context, "authorization", None)
    if authorization is not None:
        digest = _mapping_or_attribute(
            authorization, "authorization_file_sha256", None
        )
        if digest is not None:
            result["authorization_sha256"] = digest
    admission_sha256 = training_admission_record.get(
        "training_admission_record_sha256"
    )
    if not isinstance(admission_sha256, str) or len(admission_sha256) != 64:
        raise RuntimeError("verified training admission lacks its record hash")
    result["training_admission_record_sha256"] = admission_sha256
    return result


def _checkpoint_payload(
    *,
    unit_id: str,
    epoch: int,
    model: DirectAutoregressiveLSTM,
    optimizer: torch.optim.Optimizer,
    learning_rate: float,
    training_loss: float,
    maximum_gradient_norm: float,
    validation_nse: np.ndarray,
    validation_median_nse: float,
    sampler_generator: torch.Generator,
    target_noise_generator: torch.Generator,
    identity_sha256: str,
    scaler_sha256: str,
) -> dict[str, Any]:
    return {
        "schema_version": "tukf09_neural_checkpoint_v1",
        "experiment_id": EXPERIMENT_ID,
        "unit_id": unit_id,
        "epoch": int(epoch),
        "model_state": copy.deepcopy(model.state_dict()),
        "optimizer_state": copy.deepcopy(optimizer.state_dict()),
        "random_states": capture_random_states(),
        "sampler_generator_state": sampler_generator.get_state().cpu().clone(),
        "target_noise_generator_state": target_noise_generator.get_state().cpu().clone(),
        "learning_rate": float(learning_rate),
        "training_loss": float(training_loss),
        "maximum_gradient_norm": float(maximum_gradient_norm),
        "validation_nse_by_basin": np.asarray(validation_nse, dtype=np.float64),
        "validation_median_nse": float(validation_median_nse),
        "identity_sha256": identity_sha256,
        "training_scaler_sha256": scaler_sha256,
        "evaluation_access_count": 0,
    }


def _train_one_model_impl(
    config_path: Path,
    preflight_root: Path,
    authorization: Path,
    output_root: Path,
    lead_days: int,
    seed: int,
    *,
    execute_formal_training: bool,
    training_admission: Path | None = None,
    execution_config: Path | None = None,
    periods_by_basin: Mapping[str, Mapping[str, Any]] | None = None,
    admission_context: Any | None = None,
    device: str | torch.device | None = None,
    allow_synthetic_test_inputs: bool = False,
) -> dict[str, Any]:
    """Train and atomically publish one frozen neural lead/seed selection unit."""

    # This acknowledgement intentionally precedes every contract, admission, and data read.
    if execute_formal_training is not True:
        raise RuntimeError("formal neural training requires explicit execution authorization")
    injected_values = (periods_by_basin, admission_context)
    any_injected = any(value is not None for value in injected_values)
    all_injected = all(value is not None for value in injected_values)
    if any_injected and not all_injected:
        raise ValueError("injected neural inputs must be supplied as one complete set")
    if all_injected:
        if allow_synthetic_test_inputs is not True:
            raise PermissionError("injected neural inputs are forbidden outside synthetic tests")
        if Path(output_root).resolve(strict=False) == DEFAULT_OUTPUT_ROOT.resolve(strict=False):
            raise PermissionError("the formal result root forbids injected neural inputs")
    elif allow_synthetic_test_inputs is True or device is not None:
        raise PermissionError("synthetic neural overrides require complete injected test inputs")
    training_admission_record = _load_verified_training_admission(
        training_admission,
        execution_config,
    )
    _verify_initialized_training_root(
        output_root=Path(output_root),
        config_path=Path(config_path),
        authorization=Path(authorization),
        execution_config=Path(execution_config),
        training_admission=Path(training_admission),
        training_admission_record=training_admission_record,
    )
    if not all_injected:
        installation_admission = verify_filter_installation_for_neural_unit(
            output_root=Path(output_root),
            training_admission=Path(training_admission),
            training_admission_record=training_admission_record,
        )
        unit_stage_capability = verify_top_level_neural_unit_stage(
            output_root=Path(output_root),
            training_admission_record_sha256=str(
                training_admission_record.get("training_admission_record_sha256", "")
            ),
            filter_installation_final_sha256=(
                installation_admission.filter_installation_final_sha256
            ),
        )
        require_neural_unit_stage_capability(unit_stage_capability)
    if int(lead_days) not in FROZEN_LEADS:
        raise ValueError("lead must be one, two, or three days")
    if int(seed) not in FROZEN_SEEDS:
        raise ValueError("seed must be zero, one, or two")

    period_gate: Callable[..., Any] | None = None
    context = admission_context
    loaded_periods: Mapping[str, Mapping[str, Any]] | None = None
    if context is None:
        context, period_gate, loaded_periods = _load_admission_context(
            Path(config_path), Path(preflight_root), Path(authorization), Path(output_root)
        )
    contract = _mapping_or_attribute(context, "contract", None)
    if contract is None:
        try:
            from scripts.tukf09_455_training_common import read_json_strict  # type: ignore
        except ImportError as exc:  # pragma: no cover - integration sequencing guard
            raise RuntimeError("TUKF09 strict contract reader is unavailable") from exc
        contract = read_json_strict(Path(config_path))
    basin_ids = tuple(
        str(value)
        for value in _mapping_or_attribute(
            context,
            "ordered_basin_ids",
            _mapping_or_attribute(context, "basin_ids", None),
        )
    )
    if not basin_ids:
        raise ValueError("training admission context has no basin population")
    supplied_periods = (
        periods_by_basin
        if periods_by_basin is not None
        else (
            loaded_periods
            if loaded_periods is not None
            else _mapping_or_attribute(context, "periods_by_basin")
        )
    )
    evaluation_access_count = int(
        _mapping_or_attribute(context, "evaluation_access_count", 0)
    )
    if evaluation_access_count != 0:
        raise RuntimeError("training admission records evaluation-period access")

    spec = dataset_spec_from_contract(contract)
    validated_periods = validate_training_validation_periods(
        supplied_periods,
        basin_ids,
        spec,
        period_gate=period_gate,
    )
    scaler = fit_training_scaler(validated_periods, basin_ids)
    if scaler.training_row_count != FROZEN_BASIN_COUNT * FROZEN_TRAINING_DAYS:
        raise RuntimeError("training-only normalization row count changed")

    configure_float32_device_arithmetic()
    selected_device = require_formal_training_device(device)
    unit_id = f"lead_{int(lead_days)}_seed_{int(seed)}"
    neural_root = Path(output_root) / "neural"
    final_root = neural_root / unit_id
    if final_root.exists() or final_root.is_symlink():
        expected_scaler_sha256 = training_scaler_sha256(scaler)
        validate_shared_training_scaler(
            Path(output_root), expected_sha256=expected_scaler_sha256
        )
        manifest = validate_reusable_complete_unit(
            final_root,
            unit_id,
            training_admission_record=training_admission_record,
            ordered_basin_ids=basin_ids,
            training_scaler_sha256_value=expected_scaler_sha256,
        )
        selection = _json_load(final_root / "model_selection.json")
        return {
            **selection,
            "unit_manifest_sha256": sha256_file(final_root / "manifest.sha256.json"),
            "unit_manifest": manifest,
            "reused": True,
        }

    scaler_record = _publish_shared_scaler(Path(output_root), scaler)
    pending = neural_root / f"{unit_id}.pending-{os.getpid()}-{uuid.uuid4().hex}"
    pending.mkdir(parents=False, exist_ok=False)

    runner_hash = sha256_file(Path(__file__).resolve())
    model_source = ROOT / "scripts" / "tukf07_information_matched_model.py"
    identity = {
        "schema_version": "tukf09_neural_unit_identity_v1",
        "experiment_id": EXPERIMENT_ID,
        "unit_type": "neural_lead_seed",
        "unit_id": unit_id,
        "lead_days": int(lead_days),
        "seed": int(seed),
        "basin_count": len(basin_ids),
        "ordered_basin_newline_sha256": hashlib.sha256(
            "".join(f"{value}\n" for value in basin_ids).encode("utf-8")
        ).hexdigest(),
        "training_sample_count": FROZEN_TRAINING_SAMPLES,
        "validation_sample_count": FROZEN_VALIDATION_SAMPLES,
        "epochs": FROZEN_EPOCHS,
        "batch_size": FROZEN_BATCH_SIZE,
        "training_scaler_sha256": scaler_record["sha256"],
        "runner_sha256": runner_hash,
        "frozen_model_source_sha256": sha256_file(model_source),
        "torch_version": torch.__version__,
        "device": str(selected_device),
        "tensorfloat32": False,
        "evaluation_access_count": 0,
        "admission_evidence": _identity_evidence(context, training_admission_record),
    }
    identity["identity_sha256"] = _canonical_json_sha256(identity)
    _atomic_write_json(pending / "identity.json", identity)

    training_dataset = TUKF09NeuralWindowDataset(
        validated_periods,
        basin_ids,
        scaler,
        period_name="training",
        lead_days=int(lead_days),
        spec=spec,
    )
    validation_dataset = TUKF09NeuralWindowDataset(
        validated_periods,
        basin_ids,
        scaler,
        period_name="validation",
        lead_days=int(lead_days),
        spec=spec,
    )
    if len(training_dataset) != FROZEN_TRAINING_SAMPLES:
        raise RuntimeError("training dataset sample count changed")
    if len(validation_dataset) != FROZEN_VALIDATION_SAMPLES:
        raise RuntimeError("validation dataset sample count changed")

    set_global_seed(int(seed))
    from scripts.tukf07_information_matched_model import DirectAutoregressiveLSTM

    model = DirectAutoregressiveLSTM(lead_days=int(lead_days)).to(selected_device)
    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=0.001,
        betas=(0.9, 0.999),
        eps=1e-8,
        weight_decay=0.0,
    )
    sampler_generator = create_sampler_generator(int(seed))
    target_noise_generator = create_target_noise_generator(int(seed))
    training_loader = DataLoader(
        training_dataset,
        batch_size=FROZEN_BATCH_SIZE,
        shuffle=True,
        generator=sampler_generator,
        num_workers=0,
        drop_last=False,
    )
    validation_loader = DataLoader(
        validation_dataset,
        batch_size=FROZEN_BATCH_SIZE,
        shuffle=False,
        num_workers=0,
        drop_last=False,
    )

    training_losses = np.empty(FROZEN_EPOCHS, dtype=np.float64)
    maximum_gradient_norms = np.empty(FROZEN_EPOCHS, dtype=np.float64)
    learning_rates = np.empty(FROZEN_EPOCHS, dtype=np.float64)
    validation_nse = np.empty(
        (FROZEN_EPOCHS, FROZEN_BASIN_COUNT), dtype=np.float64
    )
    validation_medians = np.empty(FROZEN_EPOCHS, dtype=np.float64)
    for epoch in range(1, FROZEN_EPOCHS + 1):
        configure_float32_device_arithmetic()
        learning_rate = _set_learning_rate(optimizer, epoch)
        training_loss, maximum_gradient_norm = _run_training_epoch(
            model=model,
            optimizer=optimizer,
            loader=training_loader,
            scaler=scaler,
            target_noise_generator=target_noise_generator,
            device=selected_device,
        )
        scores = _run_validation(
            model=model,
            loader=validation_loader,
            scaler=scaler,
            device=selected_device,
            basin_count=FROZEN_BASIN_COUNT,
            samples_per_basin=validation_dataset.samples_per_basin,
        )
        median = float(np.median(scores))
        if not math.isfinite(median):
            raise FloatingPointError("validation median efficiency is non-finite")
        index = epoch - 1
        training_losses[index] = training_loss
        maximum_gradient_norms[index] = maximum_gradient_norm
        learning_rates[index] = learning_rate
        validation_nse[index] = scores
        validation_medians[index] = median
        checkpoint = _checkpoint_payload(
            unit_id=unit_id,
            epoch=epoch,
            model=model,
            optimizer=optimizer,
            learning_rate=learning_rate,
            training_loss=training_loss,
            maximum_gradient_norm=maximum_gradient_norm,
            validation_nse=scores,
            validation_median_nse=median,
            sampler_generator=sampler_generator,
            target_noise_generator=target_noise_generator,
            identity_sha256=identity["identity_sha256"],
            scaler_sha256=scaler_record["sha256"],
        )
        _write_checkpoint(pending / "checkpoints" / f"epoch_{epoch:03d}.pt", checkpoint)

    selected_epoch = select_validation_checkpoint(validation_nse)
    selected_checkpoint = pending / "checkpoints" / f"epoch_{selected_epoch:03d}.pt"
    history_arrays = {
        "epochs": np.arange(1, FROZEN_EPOCHS + 1, dtype=np.int64),
        "basin_ids": np.asarray(basin_ids, dtype="<U8"),
        "training_loss": training_losses,
        "maximum_gradient_norm": maximum_gradient_norms,
        "learning_rate": learning_rates,
        "validation_nse_by_basin": validation_nse,
        "validation_median_nse": validation_medians,
        "evaluation_access_count": np.asarray([0], dtype=np.int64),
    }
    _atomic_write_bytes(pending / "validation_history.npz", _npz_bytes(history_arrays))
    selection = {
        "schema_version": "tukf09_neural_model_selection_v1",
        "experiment_id": EXPERIMENT_ID,
        "unit_id": unit_id,
        "lead_days": int(lead_days),
        "seed": int(seed),
        "selected_epoch": selected_epoch,
        "selected_checkpoint_relative_path": (
            f"checkpoints/epoch_{selected_epoch:03d}.pt"
        ),
        "selected_checkpoint_sha256": sha256_file(selected_checkpoint),
        "validation_median_nse": float(validation_medians[selected_epoch - 1]),
        "checkpoint_count": FROZEN_EPOCHS,
        "selection_rule": "largest_455_basin_median_nse_earliest_epoch_tie_break",
        "best_seed_selection_forbidden": True,
        "evaluation_access_count": 0,
    }
    _atomic_write_json(pending / "model_selection.json", selection)
    access_ledger = {
        "schema_version": "tukf09_neural_access_ledger_v1",
        "experiment_id": EXPERIMENT_ID,
        "unit_id": unit_id,
        "lead_days": int(lead_days),
        "training": {
            "sample_count": len(training_dataset),
            "first_target_index": spec.first_target_index,
            "last_target_index": spec.training_day_count - 1,
            "maximum_discharge_source_offset_days": int(lead_days),
            "meteorological_forcing_through_target": True,
        },
        "validation": {
            "sample_count": len(validation_dataset),
            "first_target_index": spec.first_target_index,
            "last_target_index": spec.validation_day_count - 1,
            "maximum_discharge_source_offset_days": int(lead_days),
            "meteorological_forcing_through_target": True,
        },
        "evaluation_access_count": 0,
        "evaluation_prediction_count": 0,
        "evaluation_metric_count": 0,
    }
    _atomic_write_json(pending / "access_ledger.json", access_ledger)
    publication = publish_complete_unit(pending, final_root, unit_id)
    trusted_manifest = validate_reusable_complete_unit(
        final_root,
        unit_id,
        training_admission_record=training_admission_record,
        ordered_basin_ids=basin_ids,
        training_scaler_sha256_value=str(scaler_record["sha256"]),
    )
    return {
        **selection,
        "unit_manifest_sha256": sha256_file(final_root / "manifest.sha256.json"),
        "unit_manifest": trusted_manifest,
        "reused": publication["reused"],
    }


def train_one_model(
    config_path: Path,
    preflight_root: Path,
    authorization: Path,
    output_root: Path,
    lead_days: int,
    seed: int,
    *,
    execute_formal_training: bool,
    training_admission: Path | None = None,
    execution_config: Path | None = None,
    periods_by_basin: Mapping[str, Mapping[str, Any]] | None = None,
    admission_context: Any | None = None,
    device: str | torch.device | None = None,
    allow_synthetic_test_inputs: bool = False,
) -> dict[str, Any]:
    """Run one unit and remove only its own unsealed directory after failure."""

    if execute_formal_training is not True:
        raise RuntimeError("formal neural training requires explicit execution authorization")
    unit_id = f"lead_{int(lead_days)}_seed_{int(seed)}"
    neural_root = Path(output_root) / "neural"
    process_id = os.getpid()
    before = (
        {path.name for path in neural_root.glob(f"{unit_id}.pending-{process_id}-*")}
        if neural_root.is_dir()
        else set()
    )
    try:
        return _train_one_model_impl(
            config_path,
            preflight_root,
            authorization,
            output_root,
            lead_days,
            seed,
            execute_formal_training=True,
            training_admission=training_admission,
            execution_config=execution_config,
            periods_by_basin=periods_by_basin,
            admission_context=admission_context,
            device=device,
            allow_synthetic_test_inputs=allow_synthetic_test_inputs,
        )
    except BaseException as original:
        if neural_root.is_dir():
            created = [
                path
                for path in neural_root.glob(f"{unit_id}.pending-{process_id}-*")
                if path.name not in before
            ]
            for pending in created:
                owner = parse_pending_owner(pending, unit_id)
                if owner is None or owner[0] != process_id:
                    raise RuntimeError(
                        "failed neural unit left an unverifiable pending directory"
                    ) from original
                try:
                    remove_owned_pending(
                        pending,
                        neural_root,
                        unit_id,
                        expected_pid=owner[0],
                        expected_token=owner[1],
                    )
                except Exception as cleanup_error:
                    raise RuntimeError(
                        "failed neural unit pending directory could not be safely removed"
                    ) from cleanup_error
        raise


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Train one authorized TUKF09 neural lead/seed selection unit."
    )
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--preflight-root", type=Path, default=DEFAULT_PREFLIGHT_ROOT)
    parser.add_argument("--authorization", type=Path, required=True)
    parser.add_argument("--training-admission", type=Path, required=True)
    parser.add_argument("--execution-config", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--lead-days", type=int, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--execute-formal-training", action="store_true")
    args = parser.parse_args()
    result = train_one_model(
        args.config,
        args.preflight_root,
        args.authorization,
        args.output_root,
        args.lead_days,
        args.seed,
        execute_formal_training=args.execute_formal_training,
        training_admission=args.training_admission,
        execution_config=args.execution_config,
    )
    print(json.dumps(result, ensure_ascii=False, sort_keys=True), flush=True)


__all__ = [
    "CausalWindow",
    "DatasetSpec",
    "PeriodArrays",
    "TUKF09NeuralWindowDataset",
    "TrainingScaler",
    "NeuralUnitStageCapability",
    "apply_target_noise",
    "basin_balanced_nse_loss",
    "build_causal_window",
    "configure_float32_device_arithmetic",
    "dataset_spec_from_contract",
    "expected_sample_count",
    "fit_training_scaler",
    "learning_rate_for_epoch",
    "publish_complete_unit",
    "require_formal_training_device",
    "parse_pending_owner",
    "parse_shared_pending_owner",
    "remove_owned_pending",
    "remove_owned_shared_pending",
    "select_validation_checkpoint",
    "set_global_seed",
    "train_one_model",
    "require_neural_unit_stage_capability",
    "verify_filter_installation_for_neural_unit",
    "verify_top_level_neural_unit_stage",
    "training_scaler_payload",
    "validate_complete_unit",
    "validate_training_validation_periods",
]


if __name__ == "__main__":
    main()
