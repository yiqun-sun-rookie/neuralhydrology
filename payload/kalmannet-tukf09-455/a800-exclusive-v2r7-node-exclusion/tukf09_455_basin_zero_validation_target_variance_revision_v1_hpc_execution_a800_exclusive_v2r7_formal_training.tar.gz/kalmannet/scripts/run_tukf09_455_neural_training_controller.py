from __future__ import annotations

import argparse
from contextlib import AbstractContextManager, contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from typing import Any, Callable, Mapping, Sequence

import psutil
import torch


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.run_tukf09_455_neural_training import (  # noqa: E402
    DEFAULT_CONFIG,
    DEFAULT_OUTPUT_ROOT,
    DEFAULT_PREFLIGHT_ROOT,
    EXPERIMENT_ID,
    configure_float32_device_arithmetic,
    parse_pending_owner,
    parse_shared_pending_owner,
    remove_owned_pending,
    remove_owned_shared_pending,
    sha256_file,
    validate_complete_unit,
    validate_reusable_complete_unit,
    validate_shared_training_scaler,
)
from scripts import tukf09_455_training_controller_common as controller_common  # noqa: E402
from scripts import tukf09_455_training_common as training_common  # noqa: E402


DEFAULT_EXECUTION_CONFIG = ROOT / "configs" / "tukf09_455_basin_zero_validation_target_variance_formal_training_execution_v1.json"
DEFAULT_AUTHORIZATION = (
    ROOT
    / "artifacts"
    / "tukf09_455_basin_zero_validation_target_variance_revision_v1"
    / "authorizations"
    / "all_scope_authorization.json"
)
DEFAULT_CONTROL_ROOT = DEFAULT_OUTPUT_ROOT / "control" / "neural"
EVENT_SCHEMA = "tukf09_neural_controller_event_v1"
CONTROLLER_SCHEMA = "tukf09_neural_controller_result_v1"
MINIMUM_NEURAL_SYSTEM_MEMORY_BYTES = 4 * 1024**3

REGISTERED_UNITS = tuple(
    {
        "unit_id": f"lead_{lead_days}_seed_{seed}",
        "lead_days": lead_days,
        "seed": seed,
    }
    for lead_days in (1, 2, 3)
    for seed in (0, 1, 2)
)


@dataclass(frozen=True)
class ResourceSnapshot:
    graphics_processor_count: int
    free_graphics_memory_bytes: int
    available_system_memory_bytes: int
    free_output_disk_bytes: int


def _neural_controller_capability_authority():
    private_seal = object()

    @dataclass(frozen=True)
    class Capability:
        experiment_id: str
        sequence_execution_id: str
        sequence_process_id: int
        controller_process_id: int
        training_admission_record_sha256: str
        filter_installation_final_sha256: str
        _seal: object

    def verify_and_issue(
        *,
        output_root: Path,
        training_admission_record_sha256: str,
        filter_installation_final_sha256: str,
    ) -> Capability:
        chain = training_common.verify_neural_sequence_process_chain(
            output_root=output_root,
            training_admission_record_sha256=training_admission_record_sha256,
            filter_installation_final_sha256=filter_installation_final_sha256,
            role="neural_controller",
        )
        return Capability(
            experiment_id=EXPERIMENT_ID,
            sequence_execution_id=str(chain["sequence_execution_id"]),
            sequence_process_id=int(chain["sequence_process_id"]),
            controller_process_id=int(chain["current_process_id"]),
            training_admission_record_sha256=training_admission_record_sha256,
            filter_installation_final_sha256=filter_installation_final_sha256,
            _seal=private_seal,
        )

    def require(value: Any) -> Capability:
        if (
            type(value) is not Capability
            or value._seal is not private_seal
            or value.experiment_id != EXPERIMENT_ID
            or value.controller_process_id != os.getpid()
        ):
            raise PermissionError("valid neural-controller stage capability is required")
        return value

    return Capability, verify_and_issue, require


(
    NeuralControllerStageCapability,
    verify_top_level_neural_stage,
    require_neural_controller_stage_capability,
) = _neural_controller_capability_authority()
del _neural_controller_capability_authority


def verify_filter_installation_for_neural(
    *,
    output_root: Path,
    training_admission: Path,
    training_admission_record: Mapping[str, Any],
) -> training_common.FilterInstallationAdmission:
    return training_common.verify_filter_installation_final_for_neural(
        output_root=output_root,
        training_admission=training_admission,
        training_admission_record=training_admission_record,
    )


def _strict_json(path: Path) -> dict[str, Any]:
    from scripts.tukf09_455_training_common import read_json_strict

    return read_json_strict(Path(path))


def load_execution_contract(path: Path = DEFAULT_EXECUTION_CONFIG) -> dict[str, Any]:
    contract = _strict_json(Path(path))
    if contract.get("schema_version") != "tukf09_455_formal_training_execution_v1":
        raise ValueError("formal training execution schema changed")
    if contract.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("formal training execution experiment changed")
    resource = contract.get("resource_policy", {})
    expected_resource = {
        "neural_model_parallelism": 1,
        "neural_device": "cuda",
        "minimum_free_gpu_memory_mib_before_neural_launch": 4000,
        "minimum_free_output_disk_gib": 20.0,
        "disable_cuda_matrix_multiplication_tensorfloat32": True,
        "disable_cudnn_tensorfloat32": True,
        "prevent_system_sleep_while_controller_active": True,
        "neural_unit_timeout_seconds": 86400,
    }
    for key, expected in expected_resource.items():
        if resource.get(key) != expected:
            raise ValueError(f"neural execution resource contract changed: {key}")
    expected_order = [
        {"lead_days": unit["lead_days"], "seed": unit["seed"]}
        for unit in REGISTERED_UNITS
    ]
    if contract.get("controller_order", {}).get("neural_models") != expected_order:
        raise ValueError("neural controller order changed")
    atomic = contract.get("atomic_units", {}).get("neural", {})
    if (
        atomic.get("count") != 9
        or atomic.get("checkpoint_count_per_unit") != 30
        or contract.get("completion_counts", {}).get("neural_model_units") != 9
        or contract.get("completion_counts", {}).get("neural_checkpoints") != 270
    ):
        raise ValueError("neural atomic-unit counts changed")
    return contract


def registered_units() -> tuple[dict[str, int | str], ...]:
    return tuple(dict(value) for value in REGISTERED_UNITS)


def _absolute_without_resolving(path: Path) -> Path:
    return Path(os.path.abspath(os.fspath(Path(path))))


def _same_path(left: Path, right: Path) -> bool:
    return os.path.normcase(os.fspath(_absolute_without_resolving(left))) == os.path.normcase(
        os.fspath(_absolute_without_resolving(right))
    )


def _is_link_or_reparse(path: Path) -> bool:
    candidate = Path(path)
    if candidate.is_symlink():
        return True
    stat = os.lstat(candidate)
    attributes = int(getattr(stat, "st_file_attributes", 0))
    reparse_flag = int(getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))
    return bool(attributes & reparse_flag)


def _gate_unlinked_components(path: Path, *, stop_at: Path) -> None:
    target = _absolute_without_resolving(path)
    anchor = _absolute_without_resolving(stop_at)
    try:
        relative = target.relative_to(anchor)
    except ValueError as exc:
        raise ValueError("neural controller path escapes the project root") from exc
    current = anchor
    for part in (Path(), *relative.parts):
        if part != Path():
            current = current / part
        if os.path.lexists(os.fspath(current)) and _is_link_or_reparse(current):
            raise RuntimeError("neural controller path contains a link or reparse point")


def gate_controller_paths(output_root: Path, control_root: Path) -> None:
    output = _absolute_without_resolving(output_root)
    control = _absolute_without_resolving(control_root)
    expected_output = _absolute_without_resolving(DEFAULT_OUTPUT_ROOT)
    expected_control = expected_output / "control" / "neural"
    if not _same_path(output, expected_output):
        raise ValueError("neural controller output root differs from the fixed results root")
    if not _same_path(control, expected_control):
        raise ValueError("neural controller control root differs from output/control/neural")
    _gate_unlinked_components(output, stop_at=ROOT)
    _gate_unlinked_components(control, stop_at=ROOT)
    if not os.path.lexists(os.fspath(output)) or not output.is_dir():
        raise RuntimeError("initialized neural training output root is required")
    if os.path.lexists(os.fspath(control)) and not control.is_dir():
        raise RuntimeError("neural controller control root is not a directory")


def probe_resources(output_root: Path) -> ResourceSnapshot:
    if not torch.cuda.is_available():
        graphics_count = 0
        graphics_free = 0
    else:
        graphics_count = int(torch.cuda.device_count())
        graphics_free = int(torch.cuda.mem_get_info(0)[0])
    output_parent = Path(output_root).resolve(strict=False).parent
    disk = shutil.disk_usage(output_parent)
    memory = psutil.virtual_memory()
    return ResourceSnapshot(
        graphics_processor_count=graphics_count,
        free_graphics_memory_bytes=graphics_free,
        available_system_memory_bytes=int(memory.available),
        free_output_disk_bytes=int(disk.free),
    )


def gate_resources(
    snapshot: ResourceSnapshot,
    execution_contract: Mapping[str, Any],
) -> None:
    resource = execution_contract["resource_policy"]
    required_graphics = int(
        resource["minimum_free_gpu_memory_mib_before_neural_launch"]
    ) * 1024**2
    required_disk = int(float(resource["minimum_free_output_disk_gib"]) * 1024**3)
    if snapshot.graphics_processor_count < 1:
        raise RuntimeError("neural training requires an available graphics processor")
    if snapshot.free_graphics_memory_bytes < required_graphics:
        raise RuntimeError("free graphics memory is below the execution contract")
    if snapshot.available_system_memory_bytes < MINIMUM_NEURAL_SYSTEM_MEMORY_BYTES:
        raise RuntimeError("available system memory is below four gibibytes")
    if snapshot.free_output_disk_bytes < required_disk:
        raise RuntimeError("free output disk is below the execution contract")


GRAPHICS_PROBE_LEADING_COLUMNS = ("gpu", "pid", "type")
GRAPHICS_PROBE_COMMAND_COLUMN = "command"
GRAPHICS_PROBE_KNOWN_PROCESS_TYPES = frozenset({"C", "G", "C+G"})


def _graphics_probe_header(stripped: str) -> tuple[str, ...] | None:
    """Return the declared column names when this comment line is the table header."""
    tokens = tuple(stripped.lstrip("#").split())
    if tokens[: len(GRAPHICS_PROBE_LEADING_COLUMNS)] != GRAPHICS_PROBE_LEADING_COLUMNS:
        return None
    if tokens[-1] != GRAPHICS_PROBE_COMMAND_COLUMN:
        return None
    if len(set(tokens)) != len(tokens):
        return None
    return tokens


def parse_graphics_process_probe(stdout: str) -> list[dict[str, Any]]:
    """Read the whole-node compute-process table using the driver's own column count.

    The table width is a driver property, not a constant: driver 535 prints
    ``gpu pid type sm mem enc dec command`` while newer drivers insert ``jpg`` and
    ``ofa`` before ``command``.  The width is therefore taken from the header the
    driver itself prints and is never assumed.  A missing header, an unexpected
    row width, an unreadable index or process identifier, and an unknown process
    type all stop the run; no line is ever skipped because it could not be read.
    """
    header: tuple[str, ...] | None = None
    result: list[dict[str, Any]] = []
    for line in stdout.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("#"):
            if header is None:
                header = _graphics_probe_header(stripped)
            continue
        if header is None:
            raise RuntimeError("graphics-process probe header is missing")
        fields = stripped.split(maxsplit=len(header) - 1)
        if len(fields) != len(header):
            raise RuntimeError("graphics-process probe output changed")
        row = dict(zip(header, fields))
        try:
            graphics_index = int(row["gpu"])
        except ValueError as exc:
            raise RuntimeError("graphics-process probe contains an invalid graphics index") from exc
        pid_text, process_type = row["pid"], row["type"]
        if pid_text == "-" and process_type == "-":
            continue
        try:
            pid = int(pid_text)
        except ValueError as exc:
            raise RuntimeError("graphics-process probe contains an invalid process id") from exc
        if process_type not in GRAPHICS_PROBE_KNOWN_PROCESS_TYPES:
            raise RuntimeError("graphics-process probe contains an unknown process type")
        if process_type != "C":
            continue
        result.append(
            {
                "graphics_processor_index": graphics_index,
                "pid": pid,
                "process_type": process_type,
                "process_name": row[GRAPHICS_PROBE_COMMAND_COLUMN],
            }
        )
    if header is None:
        raise RuntimeError("graphics-process probe header is missing")
    return result


def active_graphics_compute_processes() -> list[dict[str, Any]]:
    command = [
        "nvidia-smi",
        "pmon",
        "-c",
        "1",
    ]
    completed = subprocess.run(
        command,
        check=False,
        capture_output=True,
        text=True,
        timeout=15,
    )
    if completed.returncode != 0:
        raise RuntimeError("graphics-process probe failed")
    return parse_graphics_process_probe(completed.stdout)


def gate_no_other_graphics_training(
    processes: Sequence[Mapping[str, Any]],
    *,
    controller_pid: int,
) -> None:
    others = [
        dict(process)
        for process in processes
        if int(process.get("pid", -1)) != int(controller_pid)
    ]
    if others:
        raise RuntimeError(f"another graphics-processor compute process is active: {others}")


class ControllerLock(AbstractContextManager["ControllerLock"]):
    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.handle = None

    def __enter__(self) -> "ControllerLock":
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if os.path.lexists(os.fspath(self.path)) and (
            _is_link_or_reparse(self.path)
            or not self.path.is_file()
            or int(self.path.stat().st_nlink) != 1
        ):
            raise RuntimeError("neural controller lock is linked or invalid")
        self.handle = self.path.open("a+b")
        self.handle.seek(0, os.SEEK_END)
        if self.handle.tell() == 0:
            self.handle.write(b"0")
            self.handle.flush()
            os.fsync(self.handle.fileno())
        self.handle.seek(0)
        try:
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:  # pragma: no cover - Windows is the registered local route
                import fcntl

                fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (OSError, BlockingIOError) as error:
            self.handle.close()
            self.handle = None
            raise RuntimeError("another neural training controller holds the lock") from error
        return self

    def __exit__(self, exc_type, exc_value, traceback_value) -> None:
        if self.handle is None:
            return
        self.handle.seek(0)
        if os.name == "nt":
            import msvcrt

            msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
        else:  # pragma: no cover - Windows is the registered local route
            import fcntl

            fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
        self.handle.close()
        self.handle = None
        if (
            self.path.is_file()
            and not _is_link_or_reparse(self.path)
            and int(self.path.stat().st_nlink) == 1
            and self.path.read_bytes() == b"0"
        ):
            self.path.unlink()
        else:
            raise RuntimeError("neural controller lock identity changed before cleanup")


@contextmanager
def neural_training_locks(output_root: Path, lock_path: Path):
    """Acquire the shared phase lock before the neural byte-range lock."""

    with controller_common.training_phase_lock(Path(output_root) / "control", "neural"):
        controller_common.reject_post_training_outputs(Path(output_root))
        with ControllerLock(Path(lock_path)):
            yield


class SleepPrevention(AbstractContextManager["SleepPrevention"]):
    def __init__(self, enabled: bool) -> None:
        self.enabled = bool(enabled)

    @staticmethod
    def _set(enabled: bool) -> None:
        if os.name != "nt":  # pragma: no cover - Windows is the registered local route
            return
        import ctypes

        es_continuous = 0x80000000
        flags = es_continuous | (0x00000001 | 0x00000040 if enabled else 0)
        if not ctypes.windll.kernel32.SetThreadExecutionState(flags):
            raise RuntimeError("Windows sleep-prevention request failed")

    def __enter__(self) -> "SleepPrevention":
        if self.enabled:
            self._set(True)
        return self

    def __exit__(self, exc_type, exc_value, traceback_value) -> None:
        if self.enabled:
            self._set(False)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class AppendOnlyEventLog:
    def __init__(self, path: Path, *, controller_pid: int) -> None:
        self.path = Path(path)
        self.controller_pid = int(controller_pid)
        self.next_sequence = 1
        if os.path.lexists(os.fspath(self.path)):
            if (
                not self.path.is_file()
                or _is_link_or_reparse(self.path)
                or int(self.path.stat().st_nlink) != 1
            ):
                raise RuntimeError("neural controller event log is linked or invalid")
            prior_bytes = self.path.read_bytes()
            if prior_bytes and not prior_bytes.endswith(b"\n"):
                raise RuntimeError("neural controller event log lacks its final newline")
            prior = prior_bytes.splitlines()
            expected = 1
            for raw in prior:
                try:
                    event = json.loads(raw.decode("utf-8"))
                except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                    raise RuntimeError("neural controller event log is invalid") from exc
                canonical = json.dumps(
                    event,
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                    allow_nan=False,
                ).encode("utf-8")
                if raw != canonical:
                    raise RuntimeError("neural controller event history is not canonical")
                if (
                    event.get("schema_version") != EVENT_SCHEMA
                    or event.get("sequence_number") != expected
                    or event.get("experiment_id") != EXPERIMENT_ID
                ):
                    raise RuntimeError("neural controller event history differs")
                expected += 1
            self.next_sequence = expected

    def append(
        self,
        event_type: str,
        *,
        unit_id: str | None,
        exit_status: str,
        unit_manifest_sha256: str | None = None,
        detail: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        event = {
            "schema_version": EVENT_SCHEMA,
            "experiment_id": EXPERIMENT_ID,
            "sequence_number": self.next_sequence,
            "timestamp_utc": _utc_now(),
            "controller_process_id": self.controller_pid,
            "event_type": str(event_type),
            "unit_id": unit_id,
            "exit_status": str(exit_status),
            "unit_manifest_sha256": unit_manifest_sha256,
            "detail": dict(detail or {}),
            "evaluation_access_count": 0,
        }
        content = (
            json.dumps(
                event,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
                allow_nan=False,
            )
            + "\n"
        ).encode("utf-8")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("ab") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        self.next_sequence += 1
        return event


def _pid_is_alive(pid: int) -> bool:
    return psutil.pid_exists(int(pid))


def recover_stale_pending_units(
    neural_root: Path,
    *,
    pid_is_alive: Callable[[int], bool],
    event_log: AppendOnlyEventLog,
) -> list[str]:
    root = Path(neural_root)
    if not root.exists():
        return []
    if not root.is_dir() or _is_link_or_reparse(root):
        raise RuntimeError("neural output root is linked or invalid")
    allowed_units = {str(unit["unit_id"]) for unit in REGISTERED_UNITS}
    recovered: list[str] = []
    for candidate in sorted(root.iterdir(), key=lambda value: value.name):
        if ".pending-" not in candidate.name:
            continue
        shared_owner = parse_shared_pending_owner(candidate)
        if shared_owner is not None:
            owner_pid, token = shared_owner
            if pid_is_alive(owner_pid):
                raise RuntimeError("a neural training process still owns the shared scaler")
            remove_owned_shared_pending(
                candidate,
                root,
                expected_pid=owner_pid,
                expected_token=token,
            )
            recovered.append("shared")
            event_log.append(
                "STALE_SHARED_PENDING_REMOVED",
                unit_id="shared",
                exit_status="RECOVERED_FROM_FIXED_BEGINNING",
                detail={"stale_owner_process_id": owner_pid},
            )
            continue
        matches = [unit_id for unit_id in allowed_units if candidate.name.startswith(unit_id + ".pending-")]
        if len(matches) != 1:
            raise RuntimeError("neural output contains an unregistered pending directory")
        unit_id = matches[0]
        owner = parse_pending_owner(candidate, unit_id)
        if owner is None:
            raise RuntimeError("stale neural pending directory name is malformed")
        owner_pid, token = owner
        if pid_is_alive(owner_pid):
            raise RuntimeError("a neural training process still owns a pending unit")
        remove_owned_pending(
            candidate,
            root,
            unit_id,
            expected_pid=owner_pid,
            expected_token=token,
        )
        recovered.append(unit_id)
        event_log.append(
            "STALE_PENDING_REMOVED",
            unit_id=unit_id,
            exit_status="RECOVERED_FROM_FIXED_BEGINNING",
            detail={"stale_owner_process_id": owner_pid},
        )
    return recovered


def source_fingerprints() -> dict[str, str]:
    return {
        "controller": sha256_file(Path(__file__).resolve()),
        "unit_runner": sha256_file(
            ROOT / "scripts" / "run_tukf09_455_neural_training.py"
        ),
        "frozen_model": sha256_file(
            ROOT / "scripts" / "tukf07_information_matched_model.py"
        ),
        "training_common": sha256_file(ROOT / "scripts" / "tukf09_455_training_common.py"),
    }


def verify_training_admission(
    training_admission: Path,
    execution_config: Path,
) -> dict[str, Any]:
    from scripts import tukf09_455_training_common as common

    required_executables = tuple(
        ROOT / relative
        for relative in common.REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS
    )
    return common.load_and_verify_training_admission(
        Path(training_admission),
        Path(execution_config),
        required_executables,
    )


def build_neural_unit_command(
    *,
    config_path: Path,
    preflight_root: Path,
    authorization: Path,
    training_admission: Path,
    execution_config: Path,
    output_root: Path,
    lead_days: int,
    seed: int,
) -> list[str]:
    return [
        sys.executable,
        "-B",
        os.fspath(ROOT / "scripts" / "run_tukf09_455_neural_training.py"),
        "--config",
        os.fspath(config_path),
        "--preflight-root",
        os.fspath(preflight_root),
        "--authorization",
        os.fspath(authorization),
        "--training-admission",
        os.fspath(training_admission),
        "--execution-config",
        os.fspath(execution_config),
        "--output-root",
        os.fspath(output_root),
        "--lead-days",
        str(int(lead_days)),
        "--seed",
        str(int(seed)),
        "--execute-formal-training",
    ]


def run_neural_unit_command(
    command: Sequence[str],
    *,
    timeout_seconds: int,
) -> subprocess.CompletedProcess[str]:
    from scripts.tukf09_455_training_controller_common import run_unit_command

    return run_unit_command(command, timeout_seconds=int(timeout_seconds))


def _load_context_only(
    config_path: Path,
    preflight_root: Path,
    authorization: Path,
    output_root: Path,
) -> Any:
    from scripts.tukf09_455_training_common import (
        verify_preflight_for_revision_training,
    )

    final_manifest = Path(preflight_root) / "independent" / "manifest.final.sha256.json"
    return verify_preflight_for_revision_training(
        Path(config_path),
        final_manifest,
        Path(authorization),
        Path(output_root),
        require_output_absent=False,
        recompute_training_validation_semantics=False,
        verify_all_raw_source_bytes=False,
    )


def _load_context_and_periods(
    config_path: Path,
    preflight_root: Path,
    authorization: Path,
    output_root: Path,
) -> tuple[Any, Mapping[str, Mapping[str, Any]]]:
    from scripts.tukf09_455_training_common import (
        load_training_validation_periods_455,
        verify_preflight_for_revision_training,
    )

    final_manifest = Path(preflight_root) / "independent" / "manifest.final.sha256.json"
    context = verify_preflight_for_revision_training(
        Path(config_path),
        final_manifest,
        Path(authorization),
        Path(output_root),
        require_output_absent=False,
        recompute_training_validation_semantics=False,
        verify_all_raw_source_bytes=False,
    )
    periods = load_training_validation_periods_455(context)
    if context.evaluation_access_count != 0:
        raise RuntimeError("neural controller admission records evaluation access")
    return context, periods


def run_controller(
    config_path: Path,
    preflight_root: Path,
    authorization: Path,
    training_admission: Path,
    execution_config: Path,
    output_root: Path,
    control_root: Path,
    *,
    execute_formal_training: bool,
    admission_context: Any | None = None,
    periods_by_basin: Mapping[str, Mapping[str, Any]] | None = None,
    unit_runner: Callable[..., Mapping[str, Any]] | None = None,
    unit_command_runner: Callable[..., Any] = run_neural_unit_command,
    resource_probe: Callable[[Path], ResourceSnapshot] = probe_resources,
    graphics_process_probe: Callable[[], Sequence[Mapping[str, Any]]] = (
        active_graphics_compute_processes
    ),
    pid_is_alive: Callable[[int], bool] = _pid_is_alive,
    training_admission_verifier: Callable[[Path, Path], Mapping[str, Any]] = (
        verify_training_admission
    ),
    initialized_root_verifier: Callable[..., Mapping[str, Any]] = (
        training_common.verify_initialized_training_root
    ),
    path_gate: Callable[[Path, Path], None] = gate_controller_paths,
    in_process_test_mode: bool = False,
    enable_sleep_prevention: bool = True,
) -> dict[str, Any]:
    if execute_formal_training is not True:
        raise RuntimeError("neural controller requires explicit formal-training authorization")
    synthetic_injection = (
        admission_context is not None
        or periods_by_basin is not None
        or unit_runner is not None
        or unit_command_runner is not run_neural_unit_command
    )
    if synthetic_injection and in_process_test_mode is not True:
        raise RuntimeError(
            "injected neural controller inputs are restricted to explicit synthetic tests"
        )
    if in_process_test_mode is True:
        if not synthetic_injection:
            raise RuntimeError("synthetic neural controller mode requires injected test inputs")
        if Path(output_root).resolve(strict=False) == DEFAULT_OUTPUT_ROOT.resolve(strict=False):
            raise PermissionError("the formal result root forbids synthetic neural controller mode")
    training_admission_record = training_admission_verifier(
        Path(training_admission),
        Path(execution_config),
    )
    training_admission_sha256 = training_admission_record.get(
        "training_admission_record_sha256"
    )
    if not isinstance(training_admission_sha256, str) or len(training_admission_sha256) != 64:
        raise RuntimeError("verified training admission lacks its record hash")
    path_gate(Path(output_root), Path(control_root))
    initialized_root_verifier(
        output_root=Path(output_root),
        config_path=Path(config_path),
        authorization=Path(authorization),
        execution_config=Path(execution_config),
        training_admission=Path(training_admission),
        training_admission_record=training_admission_record,
    )
    stage_capability: NeuralControllerStageCapability | None = None
    installation_admission: training_common.FilterInstallationAdmission | None = None
    if in_process_test_mode is not True:
        installation_admission = verify_filter_installation_for_neural(
            output_root=Path(output_root),
            training_admission=Path(training_admission),
            training_admission_record=training_admission_record,
        )
        stage_capability = verify_top_level_neural_stage(
            output_root=Path(output_root),
            training_admission_record_sha256=str(training_admission_sha256),
            filter_installation_final_sha256=(
                installation_admission.filter_installation_final_sha256
            ),
        )
        require_neural_controller_stage_capability(stage_capability)
    execution = load_execution_contract(Path(execution_config))
    configure_float32_device_arithmetic()
    gate_resources(resource_probe(Path(output_root)), execution)
    gate_no_other_graphics_training(
        graphics_process_probe(), controller_pid=os.getpid()
    )
    control = Path(control_root)
    lock_path = control / "controller.lock"
    with neural_training_locks(Path(output_root), lock_path):
        if in_process_test_mode is not True:
            assert installation_admission is not None
            assert stage_capability is not None
            refreshed_installation = verify_filter_installation_for_neural(
                output_root=Path(output_root),
                training_admission=Path(training_admission),
                training_admission_record=training_admission_record,
            )
            refreshed_capability = verify_top_level_neural_stage(
                output_root=Path(output_root),
                training_admission_record_sha256=str(training_admission_sha256),
                filter_installation_final_sha256=(
                    refreshed_installation.filter_installation_final_sha256
                ),
            )
            require_neural_controller_stage_capability(refreshed_capability)
            if (
                refreshed_installation != installation_admission
                or refreshed_capability != stage_capability
            ):
                raise RuntimeError(
                    "filter installation or top-level neural capability changed under lock"
                )
        # Repeat mutable resource and activity gates after the exclusive lock.
        configure_float32_device_arithmetic()
        gate_resources(resource_probe(Path(output_root)), execution)
        gate_no_other_graphics_training(
            graphics_process_probe(), controller_pid=os.getpid()
        )
        event_log = AppendOnlyEventLog(
            control / "events.jsonl", controller_pid=os.getpid()
        )
        baseline_sources = source_fingerprints()
        event_log.append(
            "CONTROLLER_STARTED",
            unit_id=None,
            exit_status="RUNNING",
            detail={
                "source_sha256": baseline_sources,
                "training_admission_record_sha256": training_admission_sha256,
                "filter_installation_final_sha256": (
                    stage_capability.filter_installation_final_sha256
                    if stage_capability is not None
                    else None
                ),
                "sequence_execution_id": (
                    stage_capability.sequence_execution_id
                    if stage_capability is not None
                    else None
                ),
            },
        )
        recover_stale_pending_units(
            Path(output_root) / "neural",
            pid_is_alive=pid_is_alive,
            event_log=event_log,
        )
        context = admission_context
        periods = periods_by_basin
        try:
            if context is None and unit_runner is None:
                context = _load_context_only(
                    Path(config_path),
                    Path(preflight_root),
                    Path(authorization),
                    Path(output_root),
                )
            elif context is None or periods is None:
                context, periods = _load_context_and_periods(
                    Path(config_path),
                    Path(preflight_root),
                    Path(authorization),
                    Path(output_root),
                )
            if int(getattr(context, "evaluation_access_count", 0)) != 0:
                raise RuntimeError("neural controller context records evaluation access")
        except BaseException as error:
            event_log.append(
                "CONTROLLER_FAILED",
                unit_id=None,
                exit_status="FAILED_STOP",
                detail={
                    "error_type": type(error).__name__,
                    "error_message": str(error)[:2000],
                },
            )
            raise
        completed: list[dict[str, Any]] = []
        with SleepPrevention(enable_sleep_prevention):
            for unit in REGISTERED_UNITS:
                if source_fingerprints() != baseline_sources:
                    raise RuntimeError("neural training source changed during controller run")
                refreshed_admission = training_admission_verifier(
                    Path(training_admission),
                    Path(execution_config),
                )
                if (
                    refreshed_admission.get("training_admission_record_sha256")
                    != training_admission_sha256
                ):
                    raise RuntimeError("training admission identity changed during controller run")
                configure_float32_device_arithmetic()
                gate_resources(resource_probe(Path(output_root)), execution)
                gate_no_other_graphics_training(
                    graphics_process_probe(), controller_pid=os.getpid()
                )
                unit_id = str(unit["unit_id"])
                final = Path(output_root) / "neural" / unit_id
                if final.exists() or final.is_symlink():
                    if in_process_test_mode:
                        manifest = validate_complete_unit(final, unit_id)
                    else:
                        scaler_sha256 = validate_shared_training_scaler(Path(output_root))
                        manifest = validate_reusable_complete_unit(
                            final,
                            unit_id,
                            training_admission_record=refreshed_admission,
                            ordered_basin_ids=tuple(context.ordered_basin_ids),
                            training_scaler_sha256_value=scaler_sha256,
                        )
                    manifest_sha = sha256_file(final / "manifest.sha256.json")
                    event_log.append(
                        "UNIT_REUSED",
                        unit_id=unit_id,
                        exit_status="COMPLETE_EXACT_MANIFEST",
                        unit_manifest_sha256=manifest_sha,
                    )
                    completed.append(
                        {
                            "unit_id": unit_id,
                            "manifest_sha256": manifest_sha,
                            "reused": True,
                            "checkpoint_count": sum(
                                1
                                for name in manifest["files"]
                                if name.startswith("checkpoints/epoch_")
                            ),
                        }
                    )
                    continue
                started_at = _utc_now()
                event_log.append(
                    "UNIT_STARTED",
                    unit_id=unit_id,
                    exit_status="RUNNING",
                    detail={"started_at_utc": started_at},
                )
                try:
                    if unit_runner is None:
                        command = build_neural_unit_command(
                            config_path=Path(config_path),
                            preflight_root=Path(preflight_root),
                            authorization=Path(authorization),
                            training_admission=Path(training_admission),
                            execution_config=Path(execution_config),
                            output_root=Path(output_root),
                            lead_days=int(unit["lead_days"]),
                            seed=int(unit["seed"]),
                        )
                        try:
                            completed_process = unit_command_runner(
                                command,
                                timeout_seconds=int(
                                    execution["resource_policy"][
                                        "neural_unit_timeout_seconds"
                                    ]
                                ),
                            )
                        except subprocess.TimeoutExpired as error:
                            raise TimeoutError(
                                "neural unit exceeded the frozen 86400-second timeout"
                            ) from error
                        if int(completed_process.returncode) != 0:
                            stderr = str(getattr(completed_process, "stderr", ""))[-2000:]
                            raise RuntimeError(
                                f"neural unit subprocess failed with exit code "
                                f"{completed_process.returncode}: {stderr}"
                            )
                    else:
                        unit_runner(
                            Path(config_path),
                            Path(preflight_root),
                            Path(authorization),
                            Path(output_root),
                            int(unit["lead_days"]),
                            int(unit["seed"]),
                            execute_formal_training=True,
                            training_admission=Path(training_admission),
                            execution_config=Path(execution_config),
                            periods_by_basin=periods,
                            admission_context=context,
                            device="cuda:0",
                            allow_synthetic_test_inputs=True,
                        )
                    if in_process_test_mode:
                        manifest = validate_complete_unit(final, unit_id)
                    else:
                        scaler_sha256 = validate_shared_training_scaler(Path(output_root))
                        manifest = validate_reusable_complete_unit(
                            final,
                            unit_id,
                            training_admission_record=refreshed_admission,
                            ordered_basin_ids=tuple(context.ordered_basin_ids),
                            training_scaler_sha256_value=scaler_sha256,
                        )
                    manifest_sha = sha256_file(final / "manifest.sha256.json")
                    checkpoint_count = sum(
                        1
                        for name in manifest["files"]
                        if name.startswith("checkpoints/epoch_")
                    )
                    if checkpoint_count != 30:
                        raise RuntimeError("completed neural unit lacks thirty checkpoints")
                    if source_fingerprints() != baseline_sources:
                        raise RuntimeError("neural training source changed during a unit")
                    refreshed_admission = training_admission_verifier(
                        Path(training_admission),
                        Path(execution_config),
                    )
                    if (
                        refreshed_admission.get("training_admission_record_sha256")
                        != training_admission_sha256
                    ):
                        raise RuntimeError("training admission identity changed during a unit")
                    event_log.append(
                        "UNIT_COMPLETED",
                        unit_id=unit_id,
                        exit_status="COMPLETE",
                        unit_manifest_sha256=manifest_sha,
                        detail={
                            "started_at_utc": started_at,
                            "ended_at_utc": _utc_now(),
                        },
                    )
                    completed.append(
                        {
                            "unit_id": unit_id,
                            "manifest_sha256": manifest_sha,
                            "reused": False,
                            "checkpoint_count": checkpoint_count,
                        }
                    )
                except BaseException as error:
                    event_log.append(
                        "UNIT_FAILED",
                        unit_id=unit_id,
                        exit_status="FAILED_STOP",
                        detail={
                            "error_type": type(error).__name__,
                            "error_message": str(error)[:2000],
                            "started_at_utc": started_at,
                            "ended_at_utc": _utc_now(),
                        },
                    )
                    raise
        if source_fingerprints() != baseline_sources:
            raise RuntimeError("neural training source changed before controller completion")
        final_admission = training_admission_verifier(
            Path(training_admission),
            Path(execution_config),
        )
        if (
            final_admission.get("training_admission_record_sha256")
            != training_admission_sha256
        ):
            raise RuntimeError("training admission identity changed before completion")
        if len(completed) != 9 or sum(row["checkpoint_count"] for row in completed) != 270:
            raise RuntimeError("neural controller completion counts differ")
        event_log.append(
            "CONTROLLER_COMPLETED",
            unit_id=None,
            exit_status="COMPLETE_EVALUATION_HOLD",
            detail={"unit_count": 9, "checkpoint_count": 270},
        )
        return {
            "schema_version": CONTROLLER_SCHEMA,
            "experiment_id": EXPERIMENT_ID,
            "status": "NEURAL_TRAINING_COMPLETE_EVALUATION_HOLD",
            "controller_process_id": os.getpid(),
            "unit_count": 9,
            "checkpoint_count": 270,
            "completed_units": completed,
            "event_log": str((control / "events.jsonl").resolve(strict=False)),
            "training_admission_record_sha256": training_admission_sha256,
            "evaluation_access_count": 0,
        }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run nine authorized TUKF09 neural units serially on one GPU."
    )
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--preflight-root", type=Path, default=DEFAULT_PREFLIGHT_ROOT)
    parser.add_argument("--authorization", type=Path, default=DEFAULT_AUTHORIZATION)
    parser.add_argument("--training-admission", type=Path, required=True)
    parser.add_argument("--execution-config", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--control-root", type=Path, default=DEFAULT_CONTROL_ROOT)
    parser.add_argument("--execute-formal-training", action="store_true")
    args = parser.parse_args()
    result = run_controller(
        args.config,
        args.preflight_root,
        args.authorization,
        args.training_admission,
        args.execution_config,
        args.output_root,
        args.control_root,
        execute_formal_training=args.execute_formal_training,
    )
    print(json.dumps(result, ensure_ascii=False, sort_keys=True), flush=True)


__all__ = [
    "AppendOnlyEventLog",
    "build_neural_unit_command",
    "ControllerLock",
    "ResourceSnapshot",
    "NeuralControllerStageCapability",
    "active_graphics_compute_processes",
    "gate_no_other_graphics_training",
    "gate_controller_paths",
    "gate_resources",
    "load_execution_contract",
    "parse_graphics_process_probe",
    "probe_resources",
    "recover_stale_pending_units",
    "registered_units",
    "run_controller",
    "run_neural_unit_command",
    "require_neural_controller_stage_capability",
    "source_fingerprints",
    "verify_training_admission",
    "verify_filter_installation_for_neural",
    "verify_top_level_neural_stage",
]


if __name__ == "__main__":
    main()
