# ID32 — Why a Transformer loses to an LSTM on rainfall-runoff, and what fixes it

**Status:** configs frozen, local tests pass, no training run yet.
**Created:** 2026-09-02

## The question

Under one frozen development protocol on 531 CAMELS-US basins, the ID30 arms score:

| Arm | Model | Median validation NSE | Verified |
|---|---|---|---|
| B01 | `cudalstm`, hidden 256 | **0.705402** | 2026-09-02, epoch-30 artifact hash `981171c7bbaa2dae…` |
| D01 | dense causal Transformer, width 128, 4 layers | **0.671034** | 2026-09-02, hash `26cb602a68c48cc4…` |
| D02 | dense Transformer, width 256, 4 layers | 0.647760 | hash `f26db69634630077…` |
| D03 | dense Transformer, width 256, 8 layers | 0.646806 | hash `2ced417aa18f9f14…` |

Two facts constrain any explanation:

1. **Scaling the Transformer up makes it worse.** D02 and D03 are larger than D01 and both lose
   about 0.023. Under-capacity is therefore not the explanation.
2. **Both families overfit.** From the epoch-11 learning-rate drop to epoch 30, D01's training
   loss falls a further 37 % while its validation loss rises 7.7 %; B01 rises 7.0 %.

## The two competing explanations

**H1 — missing inductive bias.** Streamflow is an accumulate-and-decay process. The LSTM cell
update is a leaky linear reservoir, so that prior is free. Attention is a retrieval mechanism
with no state and no recency preference, so the Transformer must learn both from data, and 531
basins of daily data may not be enough to pay for it.

**H2 — mismatched training recipe.** B01 and D01 are *not* recipe-matched. B01 uses
`output_dropout: 0.4`, Adam, batch 256 and learning rate 1e-3; D01 uses `output_dropout: 0.0`,
AdamW, batch 64 and 3e-4. Given that both overfit and that bigger Transformers do worse, "the
Transformer is simply under-regularized" is a serious competing explanation, and it would sink
any H1 paper if a reviewer raised it first.

**This workspace tests both, H2 first.**

## The arms

All six change exactly one factor against their own baseline. `audit_configs.py` enforces this
and fails on any other difference, on any sealed year, and on any registry hash mismatch.

| Arm | Baseline | Single changed factor | Tests |
|---|---|---|---|
| `R01` | D01 | `output_dropout` 0.0 → 0.4 | H2: under-regularized |
| `T02` | D01 | causal exponentially weighted precipitation at decays 0.9 / 0.97 / 0.99 | H1: cannot build an accumulator |
| `T03` | D01 | per-head learnable exponential distance penalty on attention logits | H1: no recency prior |
| `T04` | D01 | causal depthwise convolution, kernel 7 | H1: no cheap local mixing |
| `T05` | D01 | `T02` + `T03` | are they complementary |
| `L01` | B01 | the `T02` features injected into the LSTM | do the features help *any* model, or only the Transformer |

`L01` is not optional. Without it, "adding antecedent precipitation raised the Transformer" is
indistinguishable from ordinary feature engineering that would raise anything.

## Why no baseline arm is needed

`RecencyBiasedTransformer` with every option disabled is *numerically identical* to the ID30
dense control: same module names, same name-derived seeded initialization, same forward result.
`test_recency_biased_transformer.py::test_disabled_options_reproduce_dense_control_bitwise`
asserts equality of the full state dict and of the prediction tensor. That is what lets D01's
0.671034 be cited as the ablation baseline instead of spending a seventh 6.2-hour run.

Both injections are additionally zero-initialized, so each treated arm *starts* training from
exactly the dense control and any gain is attributable to what the model learns to use.

## Information contract

`T02`, `T05` and `L01` add no information. A causal exponentially weighted moving average is a
deterministic function of precipitation, which every arm already receives; only the
representation changes. Observed discharge is supervision only. Nothing reads the sealed
1989–1999 period, and `formal_evaluation_authorized` is `false` in every manifest.

## Novelty, stated honestly

- **`T02` is not novel.** Antecedent precipitation indices are standard hydrological practice.
  Its value here is *diagnostic*: it measures how much of the gap is a representation problem.
- **`T03` has no hydrological precedent found** in a 2026-09-02 literature check, and none of
  the retrieved rainfall-runoff Transformer papers use a distance-decay attention bias. This is
  a search, not a proof of absence; a full check is required before any manuscript.
- The publishable claim, if the arms support it, is the *diagnosis plus its minimal repair*,
  with the learned per-head time constants recovered as recession scales — not the modules
  themselves.

## Cost

D01 took 6.2 hours for 30 epochs (12.8 minutes per epoch) on one RTX 3090. Five Transformer arms
plus one faster LSTM arm is roughly 33 GPU-hours, and the arms are independent so they can run
concurrently.

## Layout

```
configs/     one YAML per arm, each a single-factor edit of the ID30 baseline
scripts/     audit_configs.py (static one-factor gate), run_development.py (hash-bound runner)
hpc/         submit_ablation_arm.slurm, takes EXPERIMENT_ID from the environment
registry/    experiments.csv, binds every arm to its config hash and baseline
```

Model code lives in `neuralhydrology/modelzoo/recency_biased_transformer.py`. It imports from
the ID30 implementation and never modifies it, and it does not touch ID31 at all.

## Reading the result

Compare each arm's epoch-30 median NSE, and the basin-paired difference, against its own
baseline: D01 0.671034 for the Transformer arms, B01 0.705402 for `L01`.

- If **`R01` alone** closes most of the 0.034 gap, the honest conclusion is that the ID30
  comparison was under-regularized, and H1 is not established.
- If `R01` moves little but **`T02` or `T03`** closes the gap, H1 is supported, and `L01` says
  whether the accumulation result is Transformer-specific.
- If **nothing** closes it, the diagnosis is wrong; report that and stop.
