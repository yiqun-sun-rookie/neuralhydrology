"""Static one-factor audit for the ID32 inductive-bias ablation.

Every arm must differ from its own baseline in exactly one declared way. The Transformer arms
are compared against the ID30 D01 dense control and the long short-term memory arm against the
ID30 B01 control, so a single accidental edit to width, depth, dates, basins, optimizer or
learning rate is caught before any machine time is spent.

Reads only; writes nothing.
"""

from __future__ import annotations

import hashlib
import sys
from pathlib import Path
from typing import Any, Dict, List

from ruamel.yaml import YAML

REPO_ROOT = Path(__file__).resolve().parents[3]
IDEA_DIR = REPO_ROOT / "src/transformer_inductive_bias"
CONFIG_DIR = IDEA_DIR / "configs"
REGISTRY = IDEA_DIR / "registry/experiments.csv"

TRANSFORMER_BASELINE = REPO_ROOT / "src/modern_transformer_moe/configs/dense_d128_l4_s100.yml"
LSTM_BASELINE_NAME = "B01"

# arm -> (config file, baseline kind, keys this arm is allowed to change)
ARMS: Dict[str, tuple] = {
    "R01": ("recipe_dropout_s100.yml", "transformer", {"output_dropout"}),
    "T02": ("ema_accumulation_s100.yml", "transformer", {"recency_ema_decays", "recency_ema_inputs"}),
    "T03": ("decay_attention_s100.yml", "transformer", {"recency_decay_attention"}),
    "T04": ("local_convolution_s100.yml", "transformer", {"recency_conv_kernel"}),
    "T05": ("ema_plus_decay_s100.yml", "transformer",
            {"recency_ema_decays", "recency_ema_inputs", "recency_decay_attention"}),
    "L01": ("lstm_ema_control_s100.yml", "lstm", {"recency_ema_decays", "recency_ema_inputs"}),
}

# Always allowed to differ: identity and the model dispatch name.
IDENTITY_KEYS = {"experiment_name", "run_dir", "model"}

MODEL_BY_ARM = {
    "R01": "recency_biased_transformer",
    "T02": "recency_biased_transformer",
    "T03": "recency_biased_transformer",
    "T04": "recency_biased_transformer",
    "T05": "recency_biased_transformer",
    "L01": "recency_biased_lstm",
}

FORBIDDEN_INPUT_TOKENS = ("usgs_streamflow", "camels_hydro", "_obs_eval")
SEALED_YEARS = tuple(str(year) for year in range(1989, 1999))

REQUIRED_CONTRACT = {
    "number_of_basins": 531,
    "train_start_date": "01/10/1999",
    "train_end_date": "30/09/2006",
    "validation_start_date": "01/10/2006",
    "validation_end_date": "30/09/2008",
    "seq_length": 270,
    "predict_last_n": 1,
    "epochs": 30,
    "seed": 100,
    "loss": "NSE",
}

ALLOWED_DYNAMIC_INPUTS = ["PRCP(mm/day)", "Tmin(C)", "Tmax(C)", "SRAD(W/m2)", "Vp(Pa)"]


def load_yaml(path: Path) -> Dict[str, Any]:
    with path.open(encoding="utf-8") as stream:
        return YAML(typ="safe").load(stream)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _lstm_baseline() -> Dict[str, Any] | None:
    """Return the ID30 B01 config when the ID30 workspace carries it, else ``None``."""
    candidate = REPO_ROOT / "src/modern_transformer_moe/configs/baseline_lstm_s100.yml"
    return load_yaml(candidate) if candidate.is_file() else None


def _compare(arm: str, config: Dict[str, Any], baseline: Dict[str, Any], allowed: set) -> List[str]:
    issues: List[str] = []
    permitted = IDENTITY_KEYS | allowed
    for key in sorted(set(config) | set(baseline)):
        if key in permitted:
            continue
        if config.get(key) != baseline.get(key):
            issues.append(f"{arm}: unintended difference in '{key}': "
                          f"baseline={baseline.get(key)!r} arm={config.get(key)!r}")
    for key in sorted(allowed):
        if key == "output_dropout":
            continue
        if key not in config:
            issues.append(f"{arm}: declared changed factor '{key}' is absent from the config")
    return issues


def _audit_contract(arm: str, config: Dict[str, Any]) -> List[str]:
    issues: List[str] = []
    for key, expected in REQUIRED_CONTRACT.items():
        if config.get(key) != expected:
            issues.append(f"{arm}: frozen contract field '{key}' is {config.get(key)!r}, expected {expected!r}")
    if list(config.get("dynamic_inputs", [])) != ALLOWED_DYNAMIC_INPUTS:
        issues.append(f"{arm}: dynamic_inputs deviates from the allowed five Maurer forcings")
    if config.get("model") != MODEL_BY_ARM[arm]:
        issues.append(f"{arm}: model is {config.get('model')!r}, expected {MODEL_BY_ARM[arm]!r}")
    text = (CONFIG_DIR / ARMS[arm][0]).read_text(encoding="utf-8")
    for token in FORBIDDEN_INPUT_TOKENS:
        if token in text:
            issues.append(f"{arm}: forbidden input token '{token}' appears in the config")
    for year in SEALED_YEARS:
        if f"/{year}" in text:
            issues.append(f"{arm}: sealed evaluation year {year} appears in the config")
    if not str(config.get("run_dir", "")).startswith("results/32_transformer_inductive_bias/"):
        issues.append(f"{arm}: run_dir must stay under results/32_transformer_inductive_bias/")
    return issues


def _audit_registry() -> List[str]:
    if not REGISTRY.is_file():
        return [f"registry missing: {REGISTRY}"]
    issues: List[str] = []
    import csv
    rows = {row["experiment_id"]: row for row in csv.DictReader(REGISTRY.open(encoding="utf-8"))}
    for arm, (filename, _kind, _allowed) in ARMS.items():
        if arm not in rows:
            issues.append(f"registry: arm {arm} is not registered")
            continue
        recorded = rows[arm].get("config_sha256", "")
        actual = sha256_file(CONFIG_DIR / filename)
        if recorded != actual:
            issues.append(f"registry: {arm} config_sha256 is {recorded[:16]}..., file hashes {actual[:16]}...")
    return issues


def audit_repository(repo_root: Path = REPO_ROOT) -> List[str]:
    issues: List[str] = []
    transformer_baseline = load_yaml(TRANSFORMER_BASELINE)
    lstm_baseline = _lstm_baseline()

    for arm, (filename, kind, allowed) in ARMS.items():
        path = CONFIG_DIR / filename
        if not path.is_file():
            issues.append(f"{arm}: config missing at {path}")
            continue
        config = load_yaml(path)
        issues.extend(_audit_contract(arm, config))
        if kind == "transformer":
            issues.extend(_compare(arm, config, transformer_baseline, allowed))
        elif lstm_baseline is None:
            issues.append(f"{arm}: the ID30 {LSTM_BASELINE_NAME} baseline config is not present locally; "
                          "one-factor comparison against it was skipped")
        else:
            issues.extend(_compare(arm, config, lstm_baseline, allowed))

    issues.extend(_audit_registry())
    return issues


def main() -> int:
    issues = audit_repository()
    if issues:
        print("ID32 CONFIG AUDIT: FAIL")
        for issue in issues:
            print(f"  - {issue}")
        return 1
    print(f"ID32 CONFIG AUDIT: PASS ({len(ARMS)} arms; one factor each; no data read; no training launched)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
