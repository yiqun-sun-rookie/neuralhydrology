"""Run one hash-bound ID32 inductive-bias experiment on candidate-safe data.

The default mode is a read-only plan. Real training requires both execution flags, writes only
below ``results/32_transformer_inductive_bias``, and never touches the sealed evaluation period
or the ID30 and ID31 deployments.

The manifest records the source integrity before and after training, the data-access audit and
the metrics artifact hash, so a completed run is auditable without trusting the log.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import statistics
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ruamel.yaml import YAML

from src.transformer_inductive_bias.scripts import audit_configs
from src.modern_transformer_moe.scripts.candidate_safe_data import (
    assert_safe_data_unchanged,
    audit_access_log,
    capture_safe_data_snapshot,
)

REPO_ROOT = Path(__file__).resolve().parents[3]
RESULT_ROOT = Path("results/32_transformer_inductive_bias")
INVOCATION_ROOT = RESULT_ROOT / "_invocations"

CONFIG_BY_ID = {arm: Path("src/transformer_inductive_bias/configs") / filename
                for arm, (filename, _kind, _allowed) in audit_configs.ARMS.items()}

IMPLEMENTATION_RELATIVE_PATHS = (
    Path("neuralhydrology/modelzoo/__init__.py"),
    Path("neuralhydrology/modelzoo/recency_biased_transformer.py"),
    Path("neuralhydrology/modelzoo/modern_causal_transformer.py"),
    Path("neuralhydrology/modelzoo/cudalstm.py"),
    Path("neuralhydrology/utils/config.py"),
    Path("src/transformer_inductive_bias/hpc/submit_ablation_arm.slurm"),
    Path("src/transformer_inductive_bias/registry/experiments.csv"),
    Path("src/transformer_inductive_bias/scripts/audit_configs.py"),
    Path("src/transformer_inductive_bias/scripts/run_development.py"),
)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _relative(path: Path) -> str:
    return str(Path(path).resolve().relative_to(REPO_ROOT)).replace("\\", "/")


def capture_source_integrity(experiment_id: str) -> dict[str, Any]:
    files = {}
    for relative in IMPLEMENTATION_RELATIVE_PATHS:
        absolute = REPO_ROOT / relative
        files[str(relative).replace("\\", "/")] = _sha256(absolute) if absolute.is_file() else "MISSING"
    config_path = REPO_ROOT / CONFIG_BY_ID[experiment_id]
    return {
        "experiment_id": experiment_id,
        "implementation_files": files,
        "config_file": {_relative(config_path): _sha256(config_path)},
    }


def _load_yaml(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as stream:
        return YAML(typ="safe").load(stream)


def _atomic_json(path: Path, value: dict[str, Any], *, create: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if create and path.exists():
        raise FileExistsError(f"Refusing to overwrite an existing manifest: {path}")
    temporary = path.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True), encoding="utf-8")
    temporary.replace(path)


def _registered_hash(experiment_id: str) -> str:
    registry = REPO_ROOT / "src/transformer_inductive_bias/registry/experiments.csv"
    with registry.open(encoding="utf-8") as stream:
        for row in csv.DictReader(stream):
            if row["experiment_id"] == experiment_id:
                return row["config_sha256"]
    raise KeyError(f"{experiment_id} is not registered")


def plan(experiment_id: str, gpu: int, run_id: str) -> dict[str, Any]:
    issues = audit_configs.audit_repository(REPO_ROOT)
    if issues:
        raise RuntimeError("ID32 configuration audit failed:\n  - " + "\n  - ".join(issues))
    config_path = REPO_ROOT / CONFIG_BY_ID[experiment_id]
    actual = _sha256(config_path)
    registered = _registered_hash(experiment_id)
    if actual != registered:
        raise RuntimeError(f"{experiment_id} config hash {actual} does not match the registry value {registered}")
    config = _load_yaml(config_path)
    return {
        "experiment_id": experiment_id,
        "run_id": run_id,
        "seed": config["seed"],
        "gpu": gpu,
        "config_path": _relative(config_path),
        "config_sha256": actual,
        "run_root": str(config["run_dir"]).replace("\\", "/"),
        "date_contract": {key: config[key] for key in
                          ("train_start_date", "train_end_date", "validation_start_date", "validation_end_date")},
        "formal_evaluation_authorized": False,
        "required_flags": ["--execute", "--operator-approved-heavy-compute"],
        "command": [sys.executable, "-u", "-m", "neuralhydrology.nh_run", "train",
                    "--config-file", _relative(config_path), "--gpu", str(gpu)],
        "source_integrity_before": capture_source_integrity(experiment_id),
    }


def _new_run_dir(run_root: Path, before: set[Path]) -> Path:
    after = {path.resolve() for path in run_root.iterdir() if path.is_dir()}
    created = sorted(after - before)
    if len(created) != 1:
        raise RuntimeError(f"Expected exactly one new run directory under {run_root}, found {created}")
    return created[0]


def _build_metrics_artifact(experiment_id: str, run_dir: Path) -> Path:
    metrics = run_dir / "validation/model_epoch030/validation_metrics.csv"
    if not metrics.is_file():
        raise FileNotFoundError(f"Epoch-30 validation metrics are missing: {metrics}")
    with metrics.open(encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    column = "NSE" if rows and "NSE" in rows[0] else list(rows[0].keys())[-1]
    values: dict[str, float] = {}
    for row in rows:
        raw = (row.get(column) or "").strip()
        value = float(raw)
        if not math.isfinite(value):
            raise ValueError(f"Non-finite {column} for basin {row.get('basin')}")
        values[row["basin"]] = value
    if len(values) != 531:
        raise ValueError(f"Expected 531 basins in the epoch-30 metrics, found {len(values)}")
    artifact = run_dir / "epoch030_metrics.json"
    artifact.write_text(json.dumps({
        "experiment_id": experiment_id,
        "basin_count": len(values),
        "median_nse": statistics.median(values.values()),
        "metric_column": column,
        "source_csv_sha256": _sha256(metrics),
        "basin_nse": values,
    }, indent=2, sort_keys=True), encoding="utf-8")
    return artifact


def execute(experiment_id: str, gpu: int, run_id: str) -> dict[str, Any]:
    execution_plan = plan(experiment_id, gpu, run_id)
    config = _load_yaml(REPO_ROOT / CONFIG_BY_ID[experiment_id])
    source_integrity_before = execution_plan["source_integrity_before"]

    invocation_dir = REPO_ROOT / INVOCATION_ROOT / run_id
    invocation_dir.mkdir(parents=True, exist_ok=False)
    manifest_path = invocation_dir / "run_manifest.json"
    access_log = invocation_dir / "data_access.jsonl"
    safe_before = capture_safe_data_snapshot(REPO_ROOT, config)
    run_root = (REPO_ROOT / str(config["run_dir"])).resolve()
    run_root.mkdir(parents=True, exist_ok=True)
    before = {path.resolve() for path in run_root.iterdir() if path.is_dir()}

    manifest: dict[str, Any] = {
        **execution_plan,
        "mode": "execute",
        "status": "RUNNING",
        "started_at_utc": _utc_now(),
        "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
        "candidate_safe_data_before": safe_before,
        "data_access_log": _relative(access_log),
    }
    _atomic_json(manifest_path, manifest, create=True)

    environment = os.environ.copy()
    environment["NEURALHYDROLOGY_DATA_ACCESS_LOG"] = str(access_log)
    try:
        completed = subprocess.run(execution_plan["command"], cwd=REPO_ROOT, env=environment, check=False)
        manifest["training_return_code"] = completed.returncode
        if completed.returncode != 0:
            raise RuntimeError(f"NeuralHydrology training returned {completed.returncode}")
        run_dir = _new_run_dir(run_root, before)
        source_integrity_after = capture_source_integrity(experiment_id)
        if source_integrity_after != source_integrity_before:
            raise RuntimeError("ID32 source configuration or implementation changed during training")
        artifact = _build_metrics_artifact(experiment_id, run_dir)
        safe_after = assert_safe_data_unchanged(safe_before, REPO_ROOT, config)
        data_access = audit_access_log(access_log, Path(safe_before["forcing_dir"]),
                                       Path(safe_before["supervision_dir"]))
        manifest.update({
            "status": "COMPLETE",
            "completed_at_utc": _utc_now(),
            "run_dir": _relative(run_dir),
            "metrics_artifact_path": _relative(artifact),
            "metrics_artifact_sha256": _sha256(artifact),
            "median_nse_epoch030": json.loads(artifact.read_text(encoding="utf-8"))["median_nse"],
            "source_integrity_after": source_integrity_after,
            "candidate_safe_data_after": safe_after,
            "data_access": data_access,
        })
    except Exception as error:
        manifest.update({
            "status": "FAILED",
            "failed_at_utc": _utc_now(),
            "error_type": type(error).__name__,
            "error": str(error),
        })
        _atomic_json(manifest_path, manifest)
        raise
    _atomic_json(manifest_path, manifest)
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("experiment_id", choices=sorted(CONFIG_BY_ID))
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--operator-approved-heavy-compute", action="store_true")
    args = parser.parse_args()

    if args.execute != args.operator_approved_heavy_compute:
        print("Both --execute and --operator-approved-heavy-compute are required to train.", file=sys.stderr)
        return 2
    if args.execute:
        manifest = execute(args.experiment_id, args.gpu, args.run_id)
    else:
        manifest = plan(args.experiment_id, args.gpu, args.run_id)
    print(json.dumps(manifest, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
