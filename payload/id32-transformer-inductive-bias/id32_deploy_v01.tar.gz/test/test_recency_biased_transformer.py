"""Focused tests for the ID32 recency-biased causal Transformer.

The decisive test is :func:`test_disabled_options_reproduce_dense_control_bitwise`. It is what
allows the ID30 D01 median Nash-Sutcliffe efficiency to be cited as the ablation baseline
instead of spending a repeat training run: with every recency option switched off, this model
must be numerically indistinguishable from the dense control it extends.
"""

from pathlib import Path

import pytest
import torch
from ruamel.yaml import YAML

from neuralhydrology.modelzoo import get_model
from neuralhydrology.modelzoo.modern_causal_transformer import ModernCausalTransformer
from neuralhydrology.modelzoo.recency_biased_transformer import (RecencyBiasedLSTM,
                                                                 RecencyBiasedTransformer,
                                                                 causal_ema)
from neuralhydrology.utils.config import Config

BATCH = 4
DAYS = 32
DYNAMIC_INPUTS = ["PRCP(mm/day)", "Tmin(C)", "Tmax(C)", "SRAD(W/m2)", "Vp(Pa)"]
STATIC_ATTRIBUTES = ["p_mean", "aridity", "frac_snow", "elev_mean"]


def _base_config(tmp_path: Path, **overrides) -> Config:
    tmp_path = Path(tmp_path)
    tmp_path.mkdir(parents=True, exist_ok=True)
    cfg = {
        "experiment_name": "id32_unit",
        "run_dir": str(tmp_path),
        "dataset": "camels_us",
        "data_dir": str(tmp_path),
        "model": "recency_biased_transformer",
        "head": "regression",
        "output_activation": "linear",
        "output_dropout": 0.0,
        "dynamics_embedding": {"type": "fc", "hiddens": [32], "activation": "linear", "dropout": 0.0},
        "statics_embedding": {"type": "fc", "hiddens": [32], "activation": "linear", "dropout": 0.0},
        "transformer_nheads": 4,
        "transformer_nlayers": 2,
        "transformer_dim_feedforward": 128,
        "transformer_dropout": 0.0,
        "optimizer": "AdamW",
        "loss": "NSE",
        "learning_rate": {0: 1e-3},
        "batch_size": BATCH,
        "epochs": 1,
        "seq_length": DAYS,
        "predict_last_n": 1,
        "seed": 100,
        "forcings": ["maurer"],
        "dynamic_inputs": list(DYNAMIC_INPUTS),
        "target_variables": ["QObs(mm/d)"],
        "static_attributes": list(STATIC_ATTRIBUTES),
        "train_start_date": "01/10/1999",
        "train_end_date": "30/09/2006",
        "validation_start_date": "01/10/2006",
        "validation_end_date": "30/09/2008",
        "test_start_date": "01/10/2006",
        "test_end_date": "30/09/2008",
    }
    cfg.update(overrides)
    path = tmp_path / "config.yml"
    YAML().dump(cfg, path)
    return Config(path)


def _batch(seed: int = 0) -> dict:
    generator = torch.Generator().manual_seed(seed)
    x_d = {
        name: torch.randn(BATCH, DAYS, 1, generator=generator)
        for name in DYNAMIC_INPUTS
    }
    return {
        "x_d": x_d,
        "x_s": torch.randn(BATCH, len(STATIC_ATTRIBUTES), generator=generator),
    }


# --------------------------------------------------------------------------------------
# The decisive equivalence test
# --------------------------------------------------------------------------------------
def test_disabled_options_reproduce_dense_control_bitwise(tmp_path):
    """With all recency options off, the model must equal the ID30 dense control exactly."""
    control_cfg = _base_config(tmp_path / "control", model="modern_transformer")
    treated_cfg = _base_config(tmp_path / "treated")

    control = ModernCausalTransformer(control_cfg).eval()
    treated = RecencyBiasedTransformer(treated_cfg).eval()

    control_state = control.state_dict()
    treated_state = treated.state_dict()
    assert set(control_state) == set(treated_state), "module naming diverged from the dense control"
    for name, tensor in control_state.items():
        assert torch.equal(tensor, treated_state[name]), f"seeded initialization differs for {name}"

    data = _batch()
    with torch.no_grad():
        expected = control(data)["y_hat"]
        actual = treated(data)["y_hat"]
    assert torch.equal(expected, actual), "forward pass diverged from the dense control"


def test_factory_dispatch(tmp_path):
    model = get_model(_base_config(tmp_path))
    assert isinstance(model, RecencyBiasedTransformer)


# --------------------------------------------------------------------------------------
# Causal exponentially weighted moving average
# --------------------------------------------------------------------------------------
def test_causal_ema_matches_the_recursive_definition():
    x = torch.randn(2, 40, 3)
    decay = 0.9
    fast = causal_ema(x, decay)
    slow = torch.zeros_like(x)
    running = torch.zeros(x.shape[0], x.shape[2])
    for step in range(x.shape[1]):
        running = decay * running + (1.0 - decay) * x[:, step, :]
        slow[:, step, :] = running
    assert torch.allclose(fast, slow, atol=1e-5)


def test_causal_ema_never_sees_the_future():
    x = torch.randn(2, 40, 1)
    reference = causal_ema(x, 0.95)
    perturbed = x.clone()
    perturbed[:, 25:, :] += 100.0
    changed = causal_ema(perturbed, 0.95)
    assert torch.allclose(reference[:, :25, :], changed[:, :25, :], atol=1e-6)
    assert not torch.allclose(reference[:, 25:, :], changed[:, 25:, :])


@pytest.mark.parametrize("decay", [0.0, 1.0, -0.1, 1.5])
def test_causal_ema_rejects_invalid_decay(decay):
    with pytest.raises(ValueError):
        causal_ema(torch.randn(1, 4, 1), decay)


# --------------------------------------------------------------------------------------
# Each option in isolation
# --------------------------------------------------------------------------------------
def test_ema_injection_starts_as_a_no_op_and_then_trains(tmp_path):
    cfg = _base_config(tmp_path,
                       recency_ema_decays=[0.9, 0.97, 0.99],
                       recency_ema_inputs=["PRCP(mm/day)"])
    model = RecencyBiasedTransformer(cfg)
    assert torch.count_nonzero(model.ema_projection.weight) == 0

    control = ModernCausalTransformer(_base_config(tmp_path / "c", model="modern_transformer")).eval()
    data = _batch()
    with torch.no_grad():
        assert torch.equal(model.eval()(data)["y_hat"], control(data)["y_hat"])

    model.train()
    model(data)["y_hat"].sum().backward()
    assert model.ema_projection.weight.grad is not None
    assert torch.count_nonzero(model.ema_projection.weight.grad) > 0


def test_decay_attention_initializes_to_geometric_memory_lengths(tmp_path):
    cfg = _base_config(tmp_path, recency_decay_attention=True)
    model = RecencyBiasedTransformer(cfg).eval()
    memory = model.learned_memory_days()
    assert memory is not None
    assert memory.shape == (cfg.transformer_nlayers, cfg.transformer_nheads)
    assert torch.allclose(memory[0], torch.tensor([4.0, 16.0, 64.0, 256.0]), rtol=1e-3)


def test_decay_attention_changes_predictions_and_carries_gradient(tmp_path):
    data = _batch()
    plain = RecencyBiasedTransformer(_base_config(tmp_path / "plain")).eval()
    decayed = RecencyBiasedTransformer(_base_config(tmp_path / "decay", recency_decay_attention=True))
    with torch.no_grad():
        assert not torch.allclose(plain(data)["y_hat"], decayed.eval()(data)["y_hat"])

    decayed.train()
    decayed(data)["y_hat"].sum().backward()
    for block in decayed.blocks:
        grad = block.attention.decay_logit.grad
        assert grad is not None and torch.isfinite(grad).all() and torch.count_nonzero(grad) > 0


def test_decay_attention_stays_causal(tmp_path):
    model = RecencyBiasedTransformer(_base_config(tmp_path, recency_decay_attention=True)).eval()
    data = _batch()
    perturbed = {"x_s": data["x_s"], "x_d": {k: v.clone() for k, v in data["x_d"].items()}}
    for name in perturbed["x_d"]:
        perturbed["x_d"][name][:, -1, :] += 50.0
    with torch.no_grad():
        base = model(data)["y_hat"]
        moved = model(perturbed)["y_hat"]
    # Only the final day is predicted, so perturbing it must change the answer; the guard
    # against future leakage is the mask itself, verified below on the mask tensor.
    assert not torch.allclose(base, moved)
    mask = model.blocks[0].attention._decay_mask(8, torch.device("cpu"), torch.float32)
    upper = torch.triu(torch.ones(8, 8, dtype=torch.bool), diagonal=1)
    assert torch.isinf(mask[0][upper]).all() and (mask[0][upper] < 0).all()
    assert torch.isfinite(mask[0][~upper]).all()


def test_causal_convolution_starts_as_a_no_op_and_stays_causal(tmp_path):
    cfg = _base_config(tmp_path, recency_conv_kernel=7)
    model = RecencyBiasedTransformer(cfg)
    assert torch.count_nonzero(model.local_convolution.weight) == 0

    control = ModernCausalTransformer(_base_config(tmp_path / "c", model="modern_transformer")).eval()
    data = _batch()
    with torch.no_grad():
        assert torch.equal(model.eval()(data)["y_hat"], control(data)["y_hat"])

    model.train()
    model(data)["y_hat"].sum().backward()
    assert torch.count_nonzero(model.local_convolution.weight.grad) > 0


@pytest.mark.parametrize("kernel", [2, 4, -1])
def test_invalid_convolution_kernel_is_rejected(tmp_path, kernel):
    with pytest.raises(ValueError):
        RecencyBiasedTransformer(_base_config(tmp_path, recency_conv_kernel=kernel))


def test_unknown_ema_input_is_rejected(tmp_path):
    with pytest.raises(ValueError):
        RecencyBiasedTransformer(_base_config(tmp_path,
                                              recency_ema_decays=[0.9],
                                              recency_ema_inputs=["QObs(mm/d)"]))


def test_prediction_shape_and_determinism(tmp_path):
    cfg = _base_config(tmp_path,
                       recency_ema_decays=[0.9, 0.99],
                       recency_ema_inputs=["PRCP(mm/day)"],
                       recency_decay_attention=True,
                       recency_conv_kernel=7)
    data = _batch()
    first = RecencyBiasedTransformer(cfg).eval()
    second = RecencyBiasedTransformer(cfg).eval()
    with torch.no_grad():
        a, b = first(data)["y_hat"], second(data)["y_hat"]
    assert a.shape == (BATCH, DAYS, 1)
    assert torch.equal(a, b)


# --------------------------------------------------------------------------------------
# The long short-term memory control arm
# --------------------------------------------------------------------------------------
def _lstm_config(tmp_path: Path, **overrides) -> Config:
    return _base_config(tmp_path,
                        model="recency_biased_lstm",
                        hidden_size=64,
                        initial_forget_bias=5,
                        optimizer="Adam",
                        **overrides)


def test_lstm_without_ema_matches_the_plain_cudalstm(tmp_path):
    from neuralhydrology.modelzoo.cudalstm import CudaLSTM
    control = CudaLSTM(_base_config(tmp_path / "c", model="cudalstm", hidden_size=64,
                                    initial_forget_bias=5, optimizer="Adam")).eval()
    treated = RecencyBiasedLSTM(_lstm_config(tmp_path / "t")).eval()
    treated.load_state_dict(control.state_dict())
    data = _batch()
    with torch.no_grad():
        assert torch.equal(control(data)["y_hat"], treated(data)["y_hat"])


def test_lstm_ema_injection_starts_as_a_no_op_and_then_trains(tmp_path):
    from neuralhydrology.modelzoo.cudalstm import CudaLSTM
    cfg = _lstm_config(tmp_path / "ema",
                       recency_ema_decays=[0.9, 0.97, 0.99],
                       recency_ema_inputs=["PRCP(mm/day)"])
    model = RecencyBiasedLSTM(cfg)
    assert torch.count_nonzero(model.ema_projection.weight) == 0

    control = CudaLSTM(_base_config(tmp_path / "c2", model="cudalstm", hidden_size=64,
                                    initial_forget_bias=5, optimizer="Adam")).eval()
    shared = {k: v for k, v in control.state_dict().items()}
    model.load_state_dict(shared, strict=False)
    data = _batch()
    with torch.no_grad():
        assert torch.equal(model.eval()(data)["y_hat"], control(data)["y_hat"])

    model.train()
    model(data)["y_hat"].sum().backward()
    assert torch.count_nonzero(model.ema_projection.weight.grad) > 0


def test_lstm_factory_dispatch(tmp_path):
    assert isinstance(get_model(_lstm_config(tmp_path)), RecencyBiasedLSTM)
