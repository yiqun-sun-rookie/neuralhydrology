import os.path
import time, torch
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm
try:
    import pynvml  # 可选 GPU 利用率
    _PYNVML_AVAILABLE = True
except Exception:
    _PYNVML_AVAILABLE = False

def _classify_mem(alloc_mb: float, total_mb: float):
    if total_mb <= 0:
        return '未知', ''
    r = alloc_mb / total_mb
    if r < 0.30:
        return '利用不足', '显存占用低，可尝试增大 batch_size 或开启更大模型以提升吞吐'
    if r < 0.70:
        return '适中', '可继续微调 batch_size（目标 ~75-80%）以提高效率'
    if r < 0.85:
        return '较高', '接近最佳区间，如需再提速可小幅增 batch 或启用 AMP/compile'
    if r < 0.93:
        return '临近上限', '再增大容易 OOM，建议保持或稍减'
    return '危险', '显存非常紧张，建议减小 batch_size 或关闭不必要的缓存'
from collections import defaultdict
from knet.modules.pipeline.utils import prepare_batch_data
from knet.modules.pipeline.core_fun import forward_sequence, system_model_forecast, rearrange_data_unfold
from knet.modules.utils.metrics import compute_train_loss, composite_loss
from knet.modules.utils.metricsV2 import compute_display_metrics  # NEW
import copy, math, optuna
import multiprocessing as mp
# ---- 安���训练超参 ----
GRAD_CLIP      = 1.0      # 原来就有的梯度范数上限
UPDATE_CLIP    = 0.1      # 单次权重更新绝对值上限
REL_CLIP = 0.05           # 相对步长上限
NAN_BACKOFF    = 0.5      # 触发 NaN/爆梯度后学习率乘以该系数
MAX_NAN_RESETS = 3        # 单个 epoch 最多自救次数

def _env_flag(name: str, default: bool=False) -> bool:
    v = os.getenv(name, None)
    if v is None:
        return default
    return v.strip().lower() in ("1","true","yes","on")

def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except Exception:
        return default

def train_nn(
    pipeline,
    train_loader,
    val_loader,
    resume_checkpoint: str | None = None,
    optuna_trial=None,                     # ★ ① 新增：用于 Pruner
):
    # 1) 生成训练用文件夹
    train_path, ckpt_path, logs_path = create_training_directory(
        base_results_path=os.path.join(pipeline.base_path, "results")
    )
    pipeline.train_path, pipeline.checkpoints_path, pipeline.logs_path = (
        train_path,
        ckpt_path,
        logs_path,
    )

    # 2) 初始化训练参数
    initialize_training(pipeline, train_loader, val_loader)

    # 3) 如需 resume
    if resume_checkpoint:
        # 使用更安全的方式加载checkpoint，避免警告
        try:
            ckpt = torch.load(resume_checkpoint, map_location="cpu", weights_only=True)
        except Exception:
            # 如果weights_only=True失败，回退到传统方式但抑制警告
            import warnings
            with warnings.catch_warnings():
                warnings.filterwarnings("ignore", message=".*torch.load.*weights_only.*")
                ckpt = torch.load(resume_checkpoint, map_location="cpu", weights_only=False)
        pipeline.knet_model.load_state_dict(ckpt["model_state_dict"])
        pipeline.optimizer.load_state_dict(ckpt["optimizer_state_dict"])
        pipeline.scheduler.load_state_dict(ckpt["scheduler"])
        pipeline.best_val_bp_loss  = ckpt["best_val_bp_loss"]
        pipeline.current_phase_idx = ckpt["current_phase_idx"]
        pipeline.no_improve_epochs = ckpt["no_improve_epochs"]
        start_epoch = ckpt["epoch"] + 1
        print(f"[INFO] Resume from checkpoint: {resume_checkpoint}")
        # [WRR-HP-EXT] restore the random-number generator states saved with the checkpoint so that a
        # resumed run continues the same shuffle / dropout trajectory as an uninterrupted one.
        _rng = ckpt.get("rng_state")
        if _rng:
            _restore_rng_state(_rng)
            print("[INFO] Restored RNG states (python/numpy/torch/cuda) from checkpoint")
        else:
            print("[WARN] Checkpoint has no rng_state; resumed trajectory is NOT identical to an uninterrupted run")
        try:
            cur_lr = pipeline.optimizer.param_groups[0]['lr']
            print(f"[INFO] Restored optimizer LR = {cur_lr}")
        except Exception:
            pass
    else:
        # ★ ② 可在 YAML.runtime.skip_initial_epoch 控制跳过多少轮
        start_epoch = int(
            getattr(pipeline.args, "skip_initial_epoch", 0)
        )

    # 3.5) 保存‘当前状态’为安全快照
    # 注：若为断点恢复，此时的快照即为“断点状态”；若为从头训练，则为“初始状态”。
    _save_safe_state(pipeline)

    # 4) 早停标志
    pipeline.should_stop = False

    # 5) TensorBoard - 使用固定目录名，避免时间戳哈希
    # 创建固定的TensorBoard日志目录，使用固定的子目录名
    tb_log_dir = os.path.join(pipeline.logs_path, "tb_logs")
    os.makedirs(tb_log_dir, exist_ok=True)
    # 使用固定的日志目录，避免SummaryWriter自动添加时间戳
    pipeline.writer = SummaryWriter(log_dir=tb_log_dir, filename_suffix="", purge_step=None)

    # ★ ③ 占位，避免 0 epoch 时报未定义
    train_avg_bp_loss = val_avg_bp_loss = None
    train_avg_display_loss = val_avg_display_loss = None

    # ==== 额外运行环境加速设置 ====
    # 1) cudnn benchmark 显式开启/关闭日志 (需求7)
    try:
        import torch.backends.cudnn as cudnn
        if not hasattr(pipeline.args, '_logged_cudnn'):
            cudnn.benchmark = True  # 默认打开
            print(f"[Perf] cudnn.benchmark={cudnn.benchmark}")
            pipeline.args._logged_cudnn = True
    except Exception:
        pass
    # 2) matmul 精度 (需求8)
    try:
        prec = os.getenv('MATMUL_PRECISION', 'high')
        if prec:
            torch.set_float32_matmul_precision(prec)  # high/medium/default
            print(f"[Perf] set_float32_matmul_precision={prec}")
    except Exception:
        pass
    # 3) Batch 放大 (需求1): 通过环境变量 BATCH_SCALE=2,4...
    try:
        scale = float(os.getenv('BATCH_SCALE','1'))
        if scale > 1.01:
            old_bs = pipeline.args.n_batch
            new_bs = int(old_bs * scale)
            pipeline.args.n_batch = new_bs
            # 提示用户需要重新构造 DataLoader 才生效
            print(f"[Perf] BATCH_SCALE={scale} 建议把 DataLoader batch_size 从 {old_bs} 调整为 {new_bs} (需在创建 DataLoader 时应用)")
    except Exception:
        pass
    perf_interval = _env_int('PERF_INTERVAL', 0)  # 需求9：>0 时打印 batch 性能
    disable_tqdm = _env_flag('NO_TQDM', False)    # 需求6
    # 日志模式: normal (默认), compact (合并/降低频率), verbose (未来可扩展)
    log_mode = os.getenv('LOG_MODE', 'normal').strip().lower()
    if log_mode not in ('normal','compact','verbose'):
        log_mode = 'normal'
    if log_mode == 'compact':
        # 关闭 tqdm 与过多 batch 指标
        disable_tqdm = True
        # 若用户未显式设置 PERF_INTERVAL, 则将其重置为 0（关闭 Perf per batch）
        if os.getenv('PERF_INTERVAL') is None:
            perf_interval = 0
        # 若用户未显式设置 EPOCH_SUMMARY=0, 保留 epoch 起始心跳
        # 其余 PerfAdvice/SlowBatch 在 epoch 级仍然可以通过环境选择
    pipeline._log_mode = log_mode

    # 6) 主循环
    # 读取节流参数：每多少个 epoch 进行一次详细指标打印（含 EpochSummary 与 Batch 汇总）
    try:
        epoch_report_every = int(os.getenv('EPOCH_REPORT_EVERY', '1'))
        if epoch_report_every < 1:
            epoch_report_every = 1
    except Exception:
        epoch_report_every = 1
    pipeline._epoch_report_every = epoch_report_every

    for epoch in range(start_epoch, pipeline.args.train_epochs):
        # ====== [测试/应急] 轮询 emergency_save.flag 或 TEST_ABORT_AFTER_EPOCH ======
        try:
            abort_after = int(os.getenv('TEST_ABORT_AFTER_EPOCH','-1'))
        except Exception:
            abort_after = -1
        # 若 shell trap 写入 emergency_save.flag，优先安全保存并退出
        if os.path.exists('emergency_save.flag'):
            try:
                # 保存紧急checkpoint (使用 _emergency 后缀避免覆盖常规)
                emer_path = os.path.join(pipeline.checkpoints_path, f'checkpoint_epoch_{max(epoch-1,0)}_emergency.pt')
                torch.save({
                    'epoch':               max(epoch-1,0),
                    'model_state_dict':    pipeline.knet_model.state_dict(),
                    'optimizer_state_dict':pipeline.optimizer.state_dict(),
                    'scheduler':           pipeline.scheduler.state_dict() if pipeline.scheduler else {},
                    'best_val_bp_loss':    getattr(pipeline,'best_val_bp_loss', None),
                    'current_phase_idx':   getattr(pipeline,'current_phase_idx', None),
                    'no_improve_epochs':   getattr(pipeline,'no_improve_epochs', None),
                }, emer_path)
                print(f"[Emergency] 检测到 emergency_save.flag，已保存紧急 checkpoint: {emer_path}，即将安全退出。")
            except Exception as e:
                print(f"[Emergency][Error] 保存紧急checkpoint失败: {e}")
            finally:
                # 避免下次循环重复退出
                try:
                    os.remove('emergency_save.flag')
                except Exception:
                    pass
            break
        # 人工测试：在进入某个 epoch 时强制退出（不保存当轮未开始的梯度状态，只保留上一轮）
        if abort_after >= 0 and epoch > 0 and epoch-1 == abort_after:
            # 上一轮已经完整结束并在 post_epoch_operations 中保存过正常 checkpoint
            print(f"[TestAbort] TEST_ABORT_AFTER_EPOCH={abort_after} 触发 (已完成 epoch {abort_after})，退出以测试 resume……")
            break
        # 是否在本 epoch 打印详细指标（首/尾 epoch 强制打印）
        pipeline._report_this_epoch = (
            ( (epoch + 1) % pipeline._epoch_report_every == 0 ) or
            (epoch == start_epoch) or
            (epoch + 1 == pipeline.args.train_epochs)
        )
        # 每个 epoch 重置调试统计
        pipeline._debug_stats = {
            'epoch': epoch,
            'skipped_nan_inf': 0,
            'skipped_grad_explosion': 0,
            'skipped_empty_window': 0,
            'processed_batches': 0,
            'processed_samples': 0,
        }
        # ==== 新增: Epoch 开始心跳，可通过环境变量 EPOCH_SUMMARY=0 关闭 ====
        if os.getenv('EPOCH_SUMMARY', '1') != '0':
            try:
                cur_lr = pipeline.optimizer.param_groups[0]['lr']
            except Exception:
                cur_lr = float('nan')
            print(f"[EpochStart] {epoch+1}/{pipeline.args.train_epochs} lr={cur_lr}", flush=True)
        if getattr(pipeline.args, 'debug_checks', False) or (os.getenv('KF_DEBUG_CHECKS', '0') == '1'):
            try:
                ds_len = len(train_loader.dataset) if train_loader is not None else -1
                print(f"[Debug] Epoch {epoch} start. train_ds_len={ds_len}, lead_time={pipeline.args.forecast_lead_time}, lr={pipeline.optimizer.param_groups[0]['lr']}")
            except Exception:
                pass

        # ------ Train ------
        train_avg_bp_loss, train_avg_display_loss = run_one_epoch(
            pipeline, train_loader, epoch, is_training=True
        )

        # ------ Val --------
        val_avg_bp_loss, val_avg_display_loss = run_one_epoch(
            pipeline, val_loader, epoch, is_training=False
        )

        # 7) epoch 结束后的事务（含相对阈值早停）
        post_epoch_operations(
            pipeline,
            epoch,
            train_avg_bp_loss,
            val_avg_bp_loss,
            train_avg_display_loss,
            val_avg_display_loss,
        )

        # ==== 新增: Epoch 汇总打印（不依赖 tqdm），便于 VS Code 任务面板实时查看 ====
        if os.getenv('EPOCH_SUMMARY', '1') != '0' and pipeline._report_this_epoch:
            try:
                nse_val = float(val_avg_display_loss.get('nse', float('nan'))) if isinstance(val_avg_display_loss, dict) else float('nan')
            except Exception:
                nse_val = float('nan')
            try:
                lr_now = pipeline.optimizer.param_groups[0]['lr']
            except Exception:
                lr_now = float('nan')
            try:
                print(f"[EpochSummary] {epoch+1}/{pipeline.args.train_epochs} train_bp={train_avg_bp_loss:.6f} val_bp={val_avg_bp_loss:.6f} val_nse={nse_val:.6f} lr={lr_now:.4g}", flush=True)
            except Exception as e:
                print(f"[EpochSummary][Error] 打印失败: {e}", flush=True)

        # 8) Optuna Pruner（若传入 trial）
        if optuna_trial is not None:
            # 选择与早停一致的监控指标
            mon_val = val_avg_bp_loss  # 或 -val_avg_display_loss['nse']
            optuna_trial.report(mon_val, step=epoch)
            if optuna_trial.should_prune():
                raise optuna.TrialPruned()

        # 9) 早停检测
        if pipeline.should_stop:
            print(f"[INFO] Early stopping triggered at epoch {epoch}.")
            break

        # 10) 记录 loss 曲线（保持旧逻辑）
        pipeline.loss_train[epoch] = train_avg_bp_loss
        pipeline.loss_cv[epoch]    = val_avg_bp_loss
        torch.cuda.empty_cache()

    # 11) 结束
    pipeline.writer.close()
    return (
        train_avg_bp_loss,
        train_avg_display_loss,
        val_avg_bp_loss,
        val_avg_display_loss,
    )

def run_one_epoch(
    pipeline,
    data_loader,
    epoch,
    is_training=True,
    lr_finder_mode: bool = False,
    num_iter: int | None = None,
    lr_finder_callback=None
):
    if is_training and not hasattr(pipeline, "nan_resets_left"):
        pipeline.nan_resets_left = MAX_NAN_RESETS
    if is_training and pipeline.nan_resets_left <= 0:
        raise RuntimeError("Exceeded max NaN recoveries in this epoch")

    if is_training:
        pipeline.knet_model.train()
        desc = f"[Train] Epoch {epoch + 1}/{pipeline.args.train_epochs}"
    else:
        pipeline.knet_model.eval()
        desc = f"[Validate] Epoch {epoch + 1}/{pipeline.args.train_epochs}"

    total_bp_loss, total_display_loss, total_samples, main_display_metric_avg = 0.0, defaultdict(float), 0, None
    if len(pipeline.display_metrics_list) > 0:
        main_display_metric = pipeline.display_metrics_list[0]  # 'mse' or 'nse'

    # ===== [新增] 如果是验证/测试阶段、且打算保存预测，则清空 pipeline.predictions =====
    if (not is_training) and getattr(pipeline, 'save_predictions', False):
        pipeline.predictions = []  # 准备存放所有batch的预测结果

    # 调试打印：数据加载器与序列长度
    debug_on = getattr(pipeline.args, 'debug_checks', False) or (os.getenv('KF_DEBUG_CHECKS', '0') == '1')
    if debug_on:
        try:
            ds_len = len(data_loader.dataset)
            first_T = data_loader.dataset[0]['p'].shape[-1] if ds_len > 0 else -1
            print(f"[Debug] {desc}: loader_len={len(data_loader)}, dataset_len={ds_len}, first_T={first_T}, lead_time={pipeline.args.forecast_lead_time}")
        except Exception as e:
            print(f"[Debug] {desc}: failed to inspect loader/dataset: {e}")

    perf_interval = int(os.getenv('PERF_INTERVAL','0'))
    disable_tqdm = _env_flag('NO_TQDM', False)
    validation_quiet = _env_flag('VALIDATION_QUIET', False)
    # 验证阶段静默控制：如果是验证阶段且设置了VALIDATION_QUIET，则禁用进度条
    if not is_training and validation_quiet:
        show_bar = False
    else:
        show_bar = (mp.current_process().name == "MainProcess") and (not disable_tqdm)
    perf_gpu = os.getenv('PERF_GPU','0') == '1'
    mem_advice = os.getenv('MEM_ADVICE','0') == '1'
    # --- 允许通过配置 (pipeline.args) 控制，而非必须环境变量 ---
    bottleneck_analysis = bool(getattr(pipeline.args, 'bottleneck_analysis', None)) if hasattr(pipeline.args, 'bottleneck_analysis') else _env_flag('BOTTLENECK_ANALYSIS', False)
    metrics_interval = int(getattr(pipeline.args, 'metrics_interval', 1))  # 仅每 N 个 batch 计算显示指标
    if metrics_interval < 1:
        metrics_interval = 1
    # DataLoader 探测（优先 pipeline.args.loader_probe_steps, 否则 env DRYRUN_LOADER_STEPS）
    loader_probe_steps = int(getattr(pipeline.args, 'loader_probe_steps', -1))
    if loader_probe_steps < 0:
        loader_probe_steps = _env_int('DRYRUN_LOADER_STEPS', 0)
    total_mem_mb = None
    if mem_advice and torch.cuda.is_available():
        try:
            props = torch.cuda.get_device_properties(pipeline.args.device)
            total_mem_mb = props.total_memory / 1024**2
        except Exception:
            total_mem_mb = None
    # ---- 可选：DataLoader 纯取数据探测（不含前向/反向）----
    dryrun_steps = loader_probe_steps
    if dryrun_steps > 0 and is_training and epoch == 0:
        try:
            it_probe = iter(data_loader)
            probe_times = []
            for _ in range(min(dryrun_steps, len(data_loader))):
                t0p = time.time(); next(it_probe); probe_times.append(time.time()-t0p)
            if probe_times:
                avg_p = sum(probe_times)/len(probe_times)
                max_p = max(probe_times)
                print(f"[LoaderProbe] steps={len(probe_times)} avg_fetch={avg_p*1000:.1f}ms max_fetch={max_p*1000:.1f}ms")
        except Exception as e:
            print(f"[LoaderProbe][Warn] dry run failed: {e}")
    total_data_time = 0.0
    total_step_time = 0.0
    last_end = time.time()
    # 记录每个 batch 的 (data, compute) 时间，供瓶颈分析
    if bottleneck_analysis:
        per_batch_data = []
        per_batch_comp = []
        per_batch_idx  = []
    with torch.set_grad_enabled(is_training):
        iterator = data_loader if not show_bar else tqdm(data_loader, desc=desc, unit='batch', disable=False)
    # 统计参与显示指标计算的样本数量（避免 metrics_interval 采样导致平均被稀释）
    metric_samples = 0
    _MINIMAL = os.getenv('KNET_MINIMAL','0')=='1'

    # === Fast / Limited batch mode (只跑部分 batch 做快速验证) ===
    # 通过下列环境变量之一控制：
    #   训练阶段优先级: MAX_TRAIN_BATCHES > MAX_BATCHES > ONE_BATCH (ONE_BATCH=任意非空即视为1)
    #   验证阶段优先级: MAX_VAL_BATCHES  > MAX_BATCHES > ONE_BATCH
    # 示例：os.environ['MAX_TRAIN_BATCHES']='1'  或  ONE_BATCH=1
    def _parse_limit(names):
        for nm in names:
            val = os.getenv(nm)
            if val is None:
                continue
            if nm == 'ONE_BATCH':
                return 1, nm, val
            try:
                return int(val), nm, val
            except Exception:
                continue
        return None, None, None
    if is_training:
        _limit_batches, _limit_src, _limit_raw = _parse_limit(['MAX_TRAIN_BATCHES','MAX_BATCHES','ONE_BATCH'])
    else:
        _limit_batches, _limit_src, _limit_raw = _parse_limit(['MAX_VAL_BATCHES','MAX_BATCHES','ONE_BATCH'])
    if _limit_batches is not None and _limit_batches <= 0:
        _limit_batches = 1
    if lr_finder_mode and num_iter is not None:
        _limit_batches = max(1, int(num_iter))
        _limit_src = "LR_FINDER"
        _limit_raw = str(num_iter)

    # 收集 LR-finder 数据
    lr_finder_losses = []
    lr_finder_lrs = []

    for i, batch in enumerate(iterator):
        if lr_finder_mode and lr_finder_callback is not None and is_training:
            current_lr = lr_finder_callback(pipeline.optimizer)
            lr_finder_lrs.append(current_lr)
        now = time.time()
        data_time = now - last_end
        if not is_training:
            compute_metrics_flag = True
        else:
            compute_metrics_flag = ((i % metrics_interval) == 0) or (i == len(data_loader)-1)
        bp_loss, display_loss, batch_size, step_time = run_one_batch(
            pipeline, batch, is_training, epoch,
            measure_time=True, compute_metrics=compute_metrics_flag
        )
        last_end = time.time()
        total_data_time += data_time
        total_step_time += step_time
        if bottleneck_analysis:
            per_batch_data.append(data_time)
            per_batch_comp.append(step_time)
            per_batch_idx.append(i+1)
        total_bp_loss += bp_loss
        total_samples += batch_size
        if display_loss:
            metric_samples += batch_size
            for key, value in display_loss.items():
                total_display_loss[key] += value
        if total_samples > 0:
            avg_bp_loss = total_bp_loss / total_samples
        else:
            avg_bp_loss = float('inf')
        if display_loss and main_display_metric in display_loss and metric_samples > 0:
            main_display_metric_avg = total_display_loss[main_display_metric] / metric_samples
        if (
            (not _MINIMAL)
            and pipeline._report_this_epoch
            and (
                ((i + 1) % pipeline.args.batch_display_interval == 0)
                or (show_bar and (i == len(data_loader) - 1))
            )
        ):
            msg = f"Batch {i + 1}: mse:{avg_bp_loss:.5f}"
            if main_display_metric_avg is not None and math.isfinite(avg_bp_loss) and metric_samples > 0 and compute_metrics_flag:
                msg += f", {main_display_metric}:{main_display_metric_avg:.5f}"
            msg += f", LR:{pipeline.optimizer.param_groups[0]['lr']}"
            avg_dt = avg_st = None
            if perf_interval > 0:
                avg_dt = total_data_time / (i + 1)
                avg_st = total_step_time / (i + 1)
            tp = (total_samples / total_step_time) if total_step_time > 0 else 0.0
            if avg_dt is not None and avg_st is not None:
                msg += f" | data_t:{avg_dt*1000:.1f}ms step_t:{avg_st*1000:.1f}ms throughput:{tp:.1f}samp/s"
            else:
                msg += f" | throughput:{tp:.1f}samp/s"
            if perf_gpu:
                try:
                    mem_alloc = torch.cuda.memory_allocated() / 1024**2
                    mem_reserved = torch.cuda.memory_reserved() / 1024**2
                    util_str = ''
                    if _PYNVML_AVAILABLE:
                        try:
                            pynvml.nvmlInit()
                            h = pynvml.nvmlDeviceGetHandleByIndex(0)
                            util = pynvml.nvmlDeviceGetUtilizationRates(h).gpu
                            util_str = f" util:{util}%"
                        except Exception:
                            util_str = ''
                    msg += f" mem:{mem_alloc:.0f}MB/{mem_reserved:.0f}MB{util_str}"
                    if mem_advice and total_mem_mb:
                        try:
                            cls, suggestion = _classify_mem(mem_alloc, total_mem_mb)
                            if (i + 1) % max(1, pipeline.args.batch_display_interval) == 0 or (i+1)==len(data_loader):
                                msg += f" [{cls}]"
                                if not hasattr(pipeline, '_last_mem_cls') or pipeline._last_mem_cls != cls:
                                    pipeline._last_mem_cls = cls
                                    advisory = f"[MemAdvice] batch_size={pipeline.args.n_batch} alloc={mem_alloc:.0f}MB ({mem_alloc/total_mem_mb*100:.1f}%) → {cls}: {suggestion}"
                                    if show_bar:
                                        tqdm.write(advisory)
                                    else:
                                        print(advisory)
                        except Exception:
                            pass
                except Exception:
                    pass
            if show_bar:
                tqdm.write(msg)
            else:
                print(f"[BatchLog] {desc} {msg}")
        if (not _MINIMAL) and perf_interval > 0 and ((i + 1) % perf_interval == 0):
            avg_dt = total_data_time / (i + 1)
            avg_st = total_step_time / (i + 1)
            tp = (total_samples / total_step_time) if total_step_time > 0 else 0.0
            line = f"[PerfStep] {desc} step {i+1}: avg_data={avg_dt*1000:.1f}ms avg_step={avg_st*1000:.1f}ms throughput={tp:.1f}samp/s"
            if perf_gpu:
                try:
                    mem_alloc = torch.cuda.memory_allocated() / 1024**2
                    mem_reserved = torch.cuda.memory_reserved() / 1024**2
                    line += f" mem:{mem_alloc:.0f}/{mem_reserved:.0f}MB"
                    if mem_advice and total_mem_mb:
                        cls, _ = _classify_mem(mem_alloc, total_mem_mb)
                        line += f" [{cls}]"
                except Exception:
                    pass
            print(line)

        # ---- Fast mode early break ----
        if lr_finder_mode and batch_size > 0:
            lr_finder_losses.append(bp_loss / batch_size)

        if _limit_batches is not None and (i + 1) >= _limit_batches:
            # 提前终止循环；保留已累计的 loss/metrics
            msg_fast = f"[FastMode] Early break after {i+1} batches ({_limit_src}={_limit_raw})."
            if show_bar:
                try:
                    tqdm.write(msg_fast)
                except Exception:
                    print(msg_fast)
            else:
                print(msg_fast)
            break

    # for 循环结束后：若本 epoch 被抑制（未报告），输出一条收尾摘要
    if total_samples > 0 and (not pipeline._report_this_epoch) and not _MINIMAL:
        try:
            brief_tp = (total_samples / total_step_time) if total_step_time > 0 else 0.0
            print(f"[EpochStepDone] {desc} batches={len(data_loader)} throughput={brief_tp:.1f}samp/s")
        except Exception:
            pass

    # epoch结束，计算最终平均
    if total_samples == 0:
        # 输出详尽诊断，避免 ZeroDivisionError
        print("[Diag] total_samples == 0, 本 epoch 无有效 batch 被统计，可能全部被跳过。")
        ds_len = len(data_loader.dataset) if hasattr(data_loader, 'dataset') else -1
        print(f"[Diag] dataset_len={ds_len}, loader_len={len(data_loader)}")
        if hasattr(pipeline, '_debug_stats'):
            s = pipeline._debug_stats
            print(f"[Diag] Skips: NaN/Inf={s.get('skipped_nan_inf', 0)}, GradExplosion={s.get('skipped_grad_explosion', 0)}, EmptyWindow={s.get('skipped_empty_window', 0)}")
        print(f"[Diag] lead_time={pipeline.args.forecast_lead_time}, lr={pipeline.optimizer.param_groups[0]['lr']}")
        print("[Hint] 请检查：1) 学习率是否过大；2) 数据是否含 NaN/Inf；3) 是否存在 T < lead_time 的短序列。")
        final_avg_bp_loss = float('inf')
        final_avg_display_loss = {}
    else:
        final_avg_bp_loss = total_bp_loss / total_samples
        # 显示指标用实际参与计算的样本计数，避免被 metrics_interval 稀释
        if 'metric_samples' in locals() and metric_samples > 0:
            final_avg_display_loss = {
                metric_name: (val_sum / metric_samples)
                for metric_name, val_sum in total_display_loss.items()
            }
        else:
            final_avg_display_loss = {
                metric_name: (val_sum / total_samples)
                for metric_name, val_sum in total_display_loss.items()
            }
    if perf_interval > 0 and total_samples > 0:
        steps = len(data_loader)
        tp = (total_samples / total_step_time) if total_step_time > 0 else 0.0
        line = f"[PerfEpoch] {desc}: steps={steps} data_avg={(total_data_time/steps)*1000:.1f}ms step_avg={(total_step_time/steps)*1000:.1f}ms throughput={tp:.1f}samp/s"
        if os.getenv('PERF_GPU','0') == '1':
            try:
                mem_alloc = torch.cuda.memory_allocated() / 1024**2
                mem_reserved = torch.cuda.memory_reserved() / 1024**2
                line += f" mem_final:{mem_alloc:.0f}/{mem_reserved:.0f}MB"
                if mem_advice and total_mem_mb:
                    try:
                        cls, suggestion = _classify_mem(mem_alloc, total_mem_mb)
                        line += f" [{cls}]"
                        print(f"[MemAdvice][Epoch] batch_size={pipeline.args.n_batch} alloc={mem_alloc:.0f}MB/{total_mem_mb:.0f}MB ({mem_alloc/total_mem_mb*100:.1f}%) → {cls}: {suggestion}")
                    except Exception:
                        pass
            except Exception:
                pass
        print(line)
    # ---- 瓶颈分析总结 ----
    # 受控性能输出：通过环境变量/模式进一步压缩
    perf_disabled = os.getenv('NO_PERF_ANALYSIS', '0') == '1'
    suppress_breakdown = os.getenv('NO_PERF_BREAKDOWN', '0') == '1'
    suppress_advice = os.getenv('NO_PERF_ADVICE', '0') == '1'
    suppress_slow = os.getenv('NO_SLOW_BATCH', '0') == '1'
    slow_batch_topk = int(os.getenv('SLOW_BATCH_TOPK', '3')) if os.getenv('SLOW_BATCH_TOPK') else 3
    summary_only = (getattr(pipeline, '_log_mode', 'normal') == 'compact') or os.getenv('PERF_SUMMARY_ONLY','0') == '1'
    if bottleneck_analysis and not perf_disabled and (total_data_time + total_step_time) > 0:
        data_ratio = total_data_time / (total_data_time + total_step_time)
        comp_ratio = 1 - data_ratio
        if data_ratio >= 0.6:
            cls = 'DataBound'
            advice = '数据加载占比高：考虑增大 num_workers、启用 pin_memory、提前缓存/预处理、使用更快的存储或减小数据转换开销'
        elif comp_ratio >= 0.85:
            cls = 'ComputeBound'
            advice = '计算占比高：考虑 AMP(torch.cuda.amp)、torch.compile、增大 batch、减少不必要的指标或打印'
        else:
            cls = 'Mixed'
            advice = '数据与计算均有空间：同时适度提升 batch、优化数据增强/IO'
        if summary_only:
            print(f"[PerfSummary] {desc} cls={cls} data={data_ratio*100:.1f}% comp={comp_ratio*100:.1f}% dt={total_data_time:.2f}s ct={total_step_time:.2f}s")
        else:
            if not suppress_breakdown:
                print(f"[PerfBreakdown] {desc} data_time={total_data_time:.3f}s compute_time={total_step_time:.3f}s data_ratio={data_ratio*100:.1f}% class={cls}")
            if not suppress_advice:
                print(f"[PerfAdvice] {cls}: {advice}")
            if not suppress_slow and slow_batch_topk > 0:
                try:
                    combined = [(per_batch_data[j]+per_batch_comp[j], per_batch_data[j], per_batch_comp[j], per_batch_idx[j]) for j in range(len(per_batch_idx))]
                    combined.sort(reverse=True)
                    top_k = combined[:slow_batch_topk]
                    for tot, dt, ct, bi in top_k:
                        print(f"[PerfSlowBatch] idx={bi} total={tot*1000:.1f}ms (data={dt*1000:.1f}ms compute={ct*1000:.1f}ms)")
                except Exception:
                    pass
    if lr_finder_mode:
        return lr_finder_losses, lr_finder_lrs

    return final_avg_bp_loss, final_avg_display_loss

def run_one_batch(pipeline, batch, is_training, epoch, measure_time: bool=False, compute_metrics: bool=True):
    t0 = time.time() if measure_time else None
    p, ep, y_obs, state0, tm_hours = prepare_batch_data(batch, pipeline.args.device)
    control = torch.cat((p, ep), dim=1)
    current_batch_size = p.size(0)
    # 初始化knet_model
    pipeline.knet_model.batch_size = current_batch_size
    pipeline.knet_model.init_hidden_KNet()
    pipeline.knet_model.update_mode = True
    pipeline.knet_model.init_sequence(state0[:, :, 0], pipeline.sys_model.train_seq_len)

    # 计算可行窗口步数，若为 0 则跳过本 batch
    num_timesteps = y_obs.size(-1)
    # [WRR-HP-EXT] Forecast slots are lead 1..L hours (no analysis slot) when the switch is on (default on):
    # forecast L+1 slots (slot 0 == analysis h(x_{t|t})), then drop slot 0 in outputs, states and targets.
    _leads_from_one = os.getenv('KNET_FORECAST_LEADS_START_AT_ONE', '1') == '1'
    _L = pipeline.args.forecast_lead_time
    _L_fc = _L + 1 if _leads_from_one else _L
    feas_T = num_timesteps - _L_fc + 1
    if feas_T <= 0:
        if getattr(pipeline.args, 'debug_checks', False) or (os.getenv('KF_DEBUG_CHECKS', '0') == '1'):
            print(f"[SafeTrain] Empty window: T={num_timesteps} < L={pipeline.args.forecast_lead_time} at epoch {epoch}. skip batch.")
        # 统计
        if hasattr(pipeline, '_debug_stats'):
            pipeline._debug_stats['skipped_empty_window'] = pipeline._debug_stats.get('skipped_empty_window', 0) + 1
        step_time = (time.time()-t0) if measure_time else 0.0
        return 0.0, {}, 0, step_time

    # 前向update计算
    states_upd, outputs_upd = forward_sequence(pipeline, y_obs, control)

    # 预报计算
    states_forecast_flat, outputs_forecast_flat = system_model_forecast(sys_model=pipeline.sys_model,
                                                                        p=p, etpot=ep, states_updated=states_upd,
                                                                        lead_time=_L_fc)
    # 计算损失
    if pipeline.sys_model.n == 1:
        outputs_forecast_flat = outputs_forecast_flat.squeeze(1)
    y_future = rearrange_data_unfold(y_obs, _L_fc).reshape(-1, _L_fc)
    if _leads_from_one:
        # slot k (k = 1..L) is the k-hour-ahead forecast x_{t+k|t} paired with y_{t+k}
        outputs_forecast_flat = outputs_forecast_flat[:, 1:]
        states_forecast_flat = states_forecast_flat[:, :, 1:]
        y_future = y_future[:, 1:]

    # C) t = 0 的预测 / 观测
    upd_now = outputs_upd[:, 0, :feas_T].reshape(-1)  # [N]
    y_now = y_obs[:, 0, :feas_T].reshape(-1)  # [N]

    # ---------- 3. 组合损失 ----------
    # 从配置中读取损失类型，默认为 'mse'
    loss_type = getattr(pipeline.args, 'loss_type', 'mse')
    bp_loss, loss_dict = composite_loss(
        outputs_fc=outputs_forecast_flat,  # [N, L]
        y_future=y_future,  # [N, L]
        outputs_upd=upd_now,  # [N]
        y_now=y_now,  # [N]
        lambda_upd=pipeline.args.lambda_upd,
        high_flow_thr=pipeline.args.high_flow_thr,
        alpha_hf=pipeline.args.alpha_hf,
        delta_thr=pipeline.args.delta_thr,
        beta_rise=pipeline.args.beta_rise,
        use_log=pipeline.args.use_log,
        gamma_slope=pipeline.args.gamma_slope,
        loss_type=loss_type,  # 'mse', 'nse', or 'kge'
    )

    # ---------- 4. display metrics ----------
    if compute_metrics:
        # 显示指标不参与反向传播，no_grad 可减少显存和构图开销
        with torch.no_grad():
            display_loss = compute_display_metrics(
                outputs_forecast_flat,  # pred  [N, L]
                y_future,  # obs   [N, L]
                metrics=pipeline.display_metrics_list + ['nse_high'],
                lead_times=None,
                high_flow_thr=pipeline.args.high_flow_thr
            )
    else:
        display_loss = {}

    # 如果是训练模式，则反向传播、优化
    if is_training:
        # 0) 先检测 loss 数值
        if not torch.isfinite(bp_loss):
            print(f"[SafeTrain] NaN/Inf loss at epoch {epoch} ⇒ backoff LR ×{NAN_BACKOFF}")
            _restore_safe_state(pipeline)
            pipeline.nan_resets_left -= 1
            if hasattr(pipeline, '_debug_stats'):
                pipeline._debug_stats['skipped_nan_inf'] = pipeline._debug_stats.get('skipped_nan_inf', 0) + 1
            step_time = (time.time()-t0) if measure_time else 0.0
            return 0.0, {}, 0, step_time  # 跳过此 batch 统计

        pipeline.optimizer.zero_grad()
        bp_loss.backward()

        # 梯度裁剪
        grad_norm = torch.nn.utils.clip_grad_norm_(pipeline.knet_model.parameters(), max_norm=GRAD_CLIP)
        if grad_norm > 1:
            print(f"Warning: high gradient norm {grad_norm} detected at epoch {epoch}")
        # 如仍异常大，则回滚并降 LR
        if not math.isfinite(grad_norm) or grad_norm > 1e4:
            print(f"[SafeTrain] Grad explosion {grad_norm:.2e} at epoch {epoch}")
            _restore_safe_state(pipeline)
            pipeline.nan_resets_left -= 1
            if hasattr(pipeline, '_debug_stats'):
                pipeline._debug_stats['skipped_grad_explosion'] = pipeline._debug_stats.get('skipped_grad_explosion', 0) + 1
            step_time = (time.time()-t0) if measure_time else 0.0
            return 0.0, {}, 0, step_time

        cur_lr = pipeline.optimizer.param_groups[0]['lr']

        for p in pipeline.knet_model.parameters():
            if p.grad is None:
                continue

            # 计算当前参数平均幅度；加 eps 防 0
            mean_abs_w = p.data.abs().mean().clamp(min=1e-8)

            # 目标：lr * |grad| ≤ REL_CLIP * mean_abs_w
            max_grad_val = (REL_CLIP * mean_abs_w) / cur_lr

            p.grad.data.clamp_(-max_grad_val, max_grad_val)

        pipeline.optimizer.step()
        # _save_safe_state(pipeline)  # ← 无条件 【已移至 post_epoch_operations】
        pipeline.nan_resets_left = MAX_NAN_RESETS

    # ========== [新增] 如��是测试/验证模式且需要保存结果，追加到 pipeline.predictions ==========
    if (not is_training) and getattr(pipeline, 'save_predictions', False):
        # ---------- 1. 窗口化驱动/观测 ----------
        # [WRR-HP-EXT] windows are built with _L_fc and, when leads start at one, slot 0 is dropped so that
        # every saved window aligns with the forecast slots (lead 1..L).
        p_win = rearrange_data_unfold(p, _L_fc).squeeze(2)  # [B,T-L_fc+1,L_fc]
        ep_win = rearrange_data_unfold(ep, _L_fc).squeeze(2)
        y_win = rearrange_data_unfold(y_obs, _L_fc).squeeze(2)

        # ---------- 2. 窗口化时间戳 ----------
        tm_raw = tm_hours.squeeze(1) if tm_hours.dim() == 3 else tm_hours  # [B,T]
        tm_win = tm_raw.unfold(1, _L_fc, 1)  # [B,T-L_fc+1,L_fc]
        if _leads_from_one:
            p_win, ep_win, y_win, tm_win = p_win[:, :, 1:], ep_win[:, :, 1:], y_win[:, :, 1:], tm_win[:, :, 1:]

        # ---------- 3. 预测结果 reshape 成窗口格式 ----------
        states_fc_win = states_forecast_flat.reshape(
            current_batch_size, -1, pipeline.sys_model.m, _L
        )  # [B,T-L_fc+1,m,L]
        outputs_fc_win = outputs_forecast_flat.reshape(
            current_batch_size, -1, _L
        )  # [B,T-L_fc+1,L]

        # ---------- 4. 追加到 predictions ----------
        pipeline.predictions.append({
            "p_raw": p.detach().cpu(),
            "ep_raw": ep.detach().cpu(),
            "y_obs_raw": y_obs.detach().cpu(),
            "tm_hours_raw": tm_raw.detach().cpu(),
            "p_win": p_win.detach().cpu(),
            "ep_win": ep_win.detach().cpu(),
            "y_obs_win": y_win.detach().cpu(),
            "tm_hours_win": tm_win.detach().cpu(),
            "outputs_upd": outputs_upd.detach().cpu(),
            "states_upd": states_upd.detach().cpu(),
            "states_fc_win": states_fc_win.detach().cpu(),
            "outputs_fc_win": outputs_fc_win.detach().cpu(),
        })

    # 记录处理的 batch/samples
    if hasattr(pipeline, '_debug_stats') and current_batch_size > 0:
        pipeline._debug_stats['processed_batches'] = pipeline._debug_stats.get('processed_batches', 0) + 1
        pipeline._debug_stats['processed_samples'] = pipeline._debug_stats.get('processed_samples', 0) + int(current_batch_size)

    # 统一返回“批次总和”
    bp_loss_batch_sum = loss_dict['loss_total'] * current_batch_size
    # 对显示指标(此处只有 'nse')也做 batch_size 加权
    display_metrics_batch_sum = {}
    for k, v in display_loss.items():
        display_metrics_batch_sum[k] = v * current_batch_size  # => “该batch总和”

    step_time = (time.time()-t0) if measure_time else 0.0
    return bp_loss_batch_sum, display_metrics_batch_sum, current_batch_size, step_time

def initialize_training(pipeline, train_loader, val_loader):
    pipeline.loss_cv = torch.zeros([pipeline.args.train_epochs])  # 循环n_epochs次
    pipeline.loss_train = torch.zeros([pipeline.args.train_epochs])
    pipeline.best_val_bp_loss_idx = 0

    pipeline.sys_model.train_seq_len = train_loader.dataset[0]['p'].shape[-1]  # train_seq_len is the maximum length of the pipeline sequences
    pipeline.sys_model.val_seq_len = val_loader.dataset[0]['p'].shape[-1]  # val_seq_len is the maximum length of the CV sequences
    # 安全状态缓存 for 梯度爆炸回退
    pipeline.last_safe_state = None    # 上一次成功更新后的快照
    pipeline.nan_resets_left = MAX_NAN_RESETS

###########################
# post_epoch_operations
###########################
def post_epoch_operations(
    pipeline,
    epoch: int,
    train_avg_bp_loss: float,
    val_avg_bp_loss: float,
    train_avg_display_loss: dict,
    val_avg_display_loss: dict,
):
    """
    1. 根据相对阈值判定是否改进 → 保存 best_model
    2. 按配置间隔保存 checkpoint（而非每个 epoch）
    3. 写 TensorBoard
    4. 调用 scheduler.step()
    """
    # ───────────────────────── 0. 读取 EarlyStopping 配置 ──────────────────
    es_cfg = getattr(pipeline.args, "early_stopping", {
        "patience":   10,
        "rel_delta":  1e-3,    # 0.1 %
        "monitor":    "val_bp_loss",
        "mode":       "min",
    })
    patience = int(es_cfg.get("patience", 10))
    rel_delta = float(es_cfg.get("rel_delta", 1e-3))
    monitor = es_cfg.get("monitor", "val_bp_loss")
    mode = es_cfg.get("mode", "min")  # 'min' or 'max'

    # 当前监控指标值
    if monitor == "val_bp_loss":
        val_metric = val_avg_bp_loss
        best_attr  = "best_val_bp_loss"
    elif monitor == "val_nse":
        val_metric = val_avg_display_loss["nse"]
        best_attr  = "best_val_nse"
    else:
        raise ValueError(f"Unsupported monitor = {monitor}")

    # 若首次 epoch 没有 best_attr，初始化
    if not hasattr(pipeline, best_attr):
        setattr(pipeline, best_attr, float("inf") if mode == "min" else -float("inf"))
        pipeline.no_improve_epochs = 0
        pipeline.best_val_metric_idx = -1

    best_metric = getattr(pipeline, best_attr)

    # ───────────────────────── 1. 判定是否改进 ──────────────────────────────
    improved = False
    # 确保当前验证指标是有效数值
    if not math.isfinite(val_metric):
        print(f"[Warning] Invalid validation metric ({monitor}={val_metric}) at epoch {epoch}. Skipping improvement check.")
    elif best_metric == float("inf") and mode == "min":
        improved = True
    elif best_metric == -float("inf") and mode == "max":
        improved = True
    else:
        if mode == "min":
            improvement = (best_metric - val_metric) / max(abs(best_metric), 1e-12)
            if improvement > rel_delta:
                improved = True
        else:   # mode == "max"
            improvement = (val_metric - best_metric) / max(abs(best_metric), 1e-12)
            if improvement > rel_delta:
                improved = True

    if improved:
        # 更新最佳
        setattr(pipeline, best_attr, val_metric)
        pipeline.no_improve_epochs   = 0
        pipeline.best_val_metric_idx = epoch

        # 保存最佳模型
        best_model_path = os.path.join(pipeline.train_path, 'best_model.pt')
        torch.save({
            'epoch':               epoch,
            'model_state_dict':    pipeline.knet_model.state_dict(),
            'optimizer_state_dict':pipeline.optimizer.state_dict(),
            'scheduler':           pipeline.scheduler.state_dict(),
            best_attr:             val_metric,
            'current_phase_idx':   pipeline.current_phase_idx,
            'no_improve_epochs':   pipeline.no_improve_epochs,
            'rng_state':           _rng_state_snapshot(),
        }, best_model_path)

        print(f"[INFO] Best model updated (epoch {epoch}). "
              f"{monitor}={val_metric:.6f}")
    else:
        pipeline.no_improve_epochs += 1

    # ───────────────────────── 2. 早停检查 ─────────────────────────────────
    if pipeline.no_improve_epochs >= patience:
        print(f"[EarlyStop] {patience} epochs 无显著改进，终止训练")
        pipeline.should_stop = True   # 主循环检测该标志后 break

    # ───────────────────────── 3. 按配置间隔保存 checkpoint ──────────────────────
    # 从 pipeline.args 读取 checkpoint 保存间隔；若外部未在 YAML 指定，则使用新的默认 20
    ckpt_interval = getattr(pipeline.args, 'ckpt_interval', 20)
    last_epoch = pipeline.args.train_epochs - 1

    # 只在以下情况保存 checkpoint：
    # 1) 模型有改进时
    # 2) 按配置的间隔 (每 ckpt_interval 个 epoch)
    # 3) 最后一个 epoch
    if improved or (epoch + 1) % ckpt_interval == 0 or epoch == last_epoch:
        ckpt_path = os.path.join(pipeline.checkpoints_path,
                                 f'checkpoint_epoch_{epoch}.pt')
        torch.save({
            'epoch':               epoch,
            'model_state_dict':    pipeline.knet_model.state_dict(),
            'optimizer_state_dict':pipeline.optimizer.state_dict(),
            'scheduler':           pipeline.scheduler.state_dict(),
            best_attr:             getattr(pipeline, best_attr),
            'current_phase_idx':   pipeline.current_phase_idx,
            'no_improve_epochs':   pipeline.no_improve_epochs,
            'loss_train':          pipeline.loss_train,
            'loss_cv':             pipeline.loss_cv,
            'rng_state':           _rng_state_snapshot(),
        }, ckpt_path)

        if improved:
            print(f"[INFO] Checkpoint saved (model improved) → {ckpt_path}")
        elif epoch == last_epoch:
            print(f"[INFO] Final checkpoint saved → {ckpt_path}")
        else:
            print(f"[INFO] Interval checkpoint saved (every {ckpt_interval} epochs) → {ckpt_path}")

    # ───────────────────────── 4. TensorBoard 日志 ─────────────────────────
    writer = pipeline.writer
    writer.add_scalar('Loss/Train', train_avg_bp_loss, epoch)
    writer.add_scalar('Loss/Validation', val_avg_bp_loss, epoch)

    base_metrics = pipeline.display_metrics_list + ["nse_high", "mse_high"]
    for m in base_metrics:
        writer.add_scalar(f"Metrics/Train_{m}", train_avg_display_loss.get(m, 0), epoch)
        writer.add_scalar(f"Metrics/Val_{m}",   val_avg_display_loss.get(m, 0),   epoch)

    writer.add_scalar("HP/LR",       pipeline.optimizer.param_groups[0]["lr"], epoch)
    writer.add_scalar("HP/LeadTime", pipeline.args.forecast_lead_time, epoch)
    writer.add_scalar("Stage/Phase", pipeline.current_phase_idx, epoch)

    # ───────────────────────── 5. 调度器步进 ────────────────────────────────
    _lr_used_this_epoch = pipeline.optimizer.param_groups[0]["lr"]
    pipeline.scheduler.step(val_metric)   # 用一致的监控指标驱动 scheduler
    _lr_next_epoch = pipeline.optimizer.param_groups[0]["lr"]

    # [WRR-HP-EXT] one JSON line per epoch: effective learning rate, losses, screening value, safeguard events.
    _append_epoch_log(pipeline, epoch, train_avg_bp_loss, val_avg_bp_loss, val_avg_display_loss,
                      improved, _lr_used_this_epoch, _lr_next_epoch, monitor, val_metric)

    # ───────────────────────── 6. 保存安全快照 (为下一个 epoch 准备) ──────────
    _save_safe_state(pipeline)


# ---- [WRR-HP-EXT] helpers: RNG snapshot / restore and per-epoch JSON log ----
def _rng_state_snapshot():
    import random as _random
    import numpy as _np
    snap = {
        "python": _random.getstate(),
        "numpy": _np.random.get_state(),
        "torch": torch.get_rng_state(),
        "cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
    }
    return snap


def _restore_rng_state(snap):
    import random as _random
    import numpy as _np
    if snap.get("python") is not None:
        _random.setstate(snap["python"])
    if snap.get("numpy") is not None:
        _np.random.set_state(snap["numpy"])
    if snap.get("torch") is not None:
        torch.set_rng_state(snap["torch"].cpu() if hasattr(snap["torch"], "cpu") else snap["torch"])
    if snap.get("cuda") is not None and torch.cuda.is_available():
        torch.cuda.set_rng_state_all([s.cpu() if hasattr(s, "cpu") else s for s in snap["cuda"]])


def _append_epoch_log(pipeline, epoch, train_bp, val_bp, val_disp, improved, lr_used, lr_next, monitor, val_metric):
    import json as _json
    stats = getattr(pipeline, "_debug_stats", {}) or {}
    rec = {
        "epoch_zero_based": int(epoch),
        "lr_used_this_epoch": float(lr_used),
        "lr_next_epoch": float(lr_next),
        "train_bp_loss": float(train_bp) if train_bp is not None else None,
        "val_bp_loss": float(val_bp) if val_bp is not None else None,
        "val_screening_nse": float(val_disp.get("nse", float("nan"))) if isinstance(val_disp, dict) else None,
        "val_nse_high": float(val_disp.get("nse_high", float("nan"))) if isinstance(val_disp, dict) else None,
        "monitor": monitor,
        "monitor_value": float(val_metric) if val_metric is not None else None,
        "improved": bool(improved),
        "best_epoch_zero_based": int(getattr(pipeline, "best_val_metric_idx", -1)),
        "no_improve_epochs": int(getattr(pipeline, "no_improve_epochs", -1)),
        "grad_explosion_rollbacks": int(stats.get("skipped_grad_explosion", 0)),
        "nan_inf_skips": int(stats.get("skipped_nan_inf", 0)),
        "empty_window_skips": int(stats.get("skipped_empty_window", 0)),
        "processed_batches": int(stats.get("processed_batches", 0)),
        "forecast_leads_start_at_one": os.getenv("KNET_FORECAST_LEADS_START_AT_ONE", "1") == "1",
        "time": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    try:
        with open(os.path.join(pipeline.train_path, "epoch_log.jsonl"), "a", encoding="utf-8") as fh:
            fh.write(_json.dumps(rec) + "\n")
    except Exception as _e:
        print(f"[WARN] epoch_log write failed: {_e}")


def post_epoch_operations0(
    pipeline,
    epoch,
    train_avg_bp_loss,
    val_avg_bp_loss,
    train_avg_display_loss,
    val_avg_display_loss
):
    # ========== 1. 记录最优模型 ==========
    min_delta = 1e-6

    if pipeline.best_val_bp_loss - val_avg_bp_loss > min_delta:
        pipeline.best_val_bp_loss = val_avg_bp_loss
        pipeline.no_improve_epochs = 0
        pipeline.best_val_bp_loss_idx = epoch

        # 保存最佳模型
        best_model_path = os.path.join(pipeline.train_path, 'best_model.pt')
        torch.save({
            'epoch': epoch,
            'model_state_dict': pipeline.knet_model.state_dict(),
            'optimizer_state_dict': pipeline.optimizer.state_dict(),
            'scheduler': pipeline.scheduler.state_dict(),
            'best_val_bp_loss': pipeline.best_val_bp_loss,
            'current_phase_idx': pipeline.current_phase_idx,
            'no_improve_epochs': pipeline.no_improve_epochs,
        }, best_model_path)

        print(f"[INFO] Best model updated. Train loss = {train_avg_display_loss['nse']:.5f}. Val loss = {val_avg_display_loss['nse']:.5f}")
    else:
        pipeline.no_improve_epochs += 1

    # ========== 2. 定期保存 checkpoint ==========
    if epoch % 1 == 0 or epoch == pipeline.args.train_epochs - 1:
        checkpoint_path = os.path.join(pipeline.checkpoints_path, f'checkpoint_epoch_{epoch}.pt')
        torch.save({
            'epoch': epoch,
            'model_state_dict': pipeline.knet_model.state_dict(),
            'optimizer_state_dict': pipeline.optimizer.state_dict(),
            'scheduler': pipeline.scheduler.state_dict(),
            'best_val_bp_loss': pipeline.best_val_bp_loss,
            'current_phase_idx': pipeline.current_phase_idx,
            'no_improve_epochs': pipeline.no_improve_epochs,
            'loss_train': pipeline.loss_train,
            'loss_cv': pipeline.loss_cv,
        }, checkpoint_path)
        print(f"[INFO] Checkpoint saved => {checkpoint_path}")

    # ========== 3. 更新预报阶段 (lead_time) ==========
    # maybe_update_lead_time_phase(pipeline, epoch, val_avg_display_loss)
    # ========== 4. TensorBoard 日志写入 ==========
    writer = pipeline.writer  # 直接从 pipeline 里取

    writer.add_scalar('Loss/Train', train_avg_bp_loss, epoch)
    writer.add_scalar('Loss/Validation', val_avg_bp_loss, epoch)

    # 确保 nse_high / mse_high 被写入
    base_metrics = pipeline.display_metrics_list + ["nse_high", "mse_high"]
    for m in base_metrics:
        writer.add_scalar(f"Metrics/Train_{m}", train_avg_display_loss.get(m, 0), epoch)
        writer.add_scalar(f"Metrics/Val_{m}",   val_avg_display_loss.get(m, 0),   epoch)

    writer.add_scalar("HP/LR",         pipeline.optimizer.param_groups[0]["lr"], epoch)
    writer.add_scalar("HP/LeadTime",   pipeline.args.forecast_lead_time, epoch)
    writer.add_scalar("Stage/Phase",   pipeline.current_phase_idx,  epoch)

    #
    pipeline.scheduler.step(val_avg_bp_loss)

def create_training_directory(base_results_path):
    # 直接使用base_results_path，不创建时间戳子目录
    train_path = base_results_path
    checkpoints_path = os.path.join(train_path, "checkpoints")
    logs_path = os.path.join(train_path, "logs", "train")

    os.makedirs(checkpoints_path, exist_ok=True)
    os.makedirs(logs_path, exist_ok=True)

    return train_path, checkpoints_path, logs_path

def _save_safe_state(pipeline):
    """保存最近一次成功 step 的模型 & 优化器快照。"""
    pipeline.last_safe_state = {
        "model": copy.deepcopy(pipeline.knet_model.state_dict()),
        "opt":   copy.deepcopy(pipeline.optimizer.state_dict()),
        "sch":   copy.deepcopy(pipeline.scheduler.state_dict() if pipeline.scheduler else {}),
    }

def _restore_safe_state(pipeline):
    """出现 NaN/爆梯度时回滚，并降低 LR。"""
    if pipeline.last_safe_state is None:
        raise RuntimeError("Safe‑state not found, aborting trial.")
    pipeline.knet_model.load_state_dict(pipeline.last_safe_state["model"])
    pipeline.optimizer.load_state_dict(pipeline.last_safe_state["opt"])
    if pipeline.scheduler and pipeline.last_safe_state["sch"]:
        pipeline.scheduler.load_state_dict(pipeline.last_safe_state["sch"])

    for g in pipeline.optimizer.param_groups:
        g["lr"] *= NAN_BACKOFF

# WRR learning-rate study: observation only; original source above is byte-identical.
from wrr_lr_observer import install as _install_wrr_lr_observer
_install_wrr_lr_observer(globals())
