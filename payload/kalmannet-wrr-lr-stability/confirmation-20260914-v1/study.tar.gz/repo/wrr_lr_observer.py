"""Observe unchanged training calls; never inspect tensors or mutate numerical state."""
from __future__ import annotations

import functools
import json
import os
from datetime import datetime, timezone
from pathlib import Path


def install(namespace: dict, output: Path | None = None) -> None:
    if namespace.get('_wrr_lr_observer_installed'):
        raise RuntimeError('learning-rate observer was installed twice')
    if output is None:
        configured = os.environ.get('WRR_LR_OBSERVER_PATH')
        if not configured:
            raise RuntimeError('WRR_LR_OBSERVER_PATH is required in this study')
        output = Path(configured)
    output = Path(output)
    if not output.is_absolute() or output.is_symlink():
        raise ValueError('observer output must be an absolute non-symlink path')
    sequence = 0
    batch_number = 0
    active_batch = None

    def emit(event, **fields):
        nonlocal sequence
        sequence += 1
        record = {'schema_version': 1, 'sequence': sequence, 'event': event,
                  'time_utc': datetime.now(timezone.utc).isoformat(),
                  'run_id': os.environ.get('WRR_LR_RUN_ID'), **fields}
        with output.open('a', encoding='utf-8', newline='\n') as stream:
            stream.write(json.dumps(record, sort_keys=True, allow_nan=False) + '\n')

    def lrs(pipeline):
        return [float(group['lr']) for group in pipeline.optimizer.param_groups]

    def counters(pipeline):
        stats = getattr(pipeline, '_debug_stats', {})
        return {name: int(stats.get(name, 0)) for name in (
            'skipped_grad_explosion', 'skipped_nan_inf', 'skipped_empty_window')}

    def phase(training):
        if training:
            return 'training'
        return ('post_training_validation' if os.environ.get('KNET_FORECAST_LEADS_START_AT_ONE') == '0'
                else 'epoch_validation')

    batch_function = namespace['run_one_batch']
    epoch_function = namespace['run_one_epoch']
    recovery_function = namespace['_restore_safe_state']

    @functools.wraps(batch_function)
    def observed_batch(pipeline, batch, is_training, epoch, *args, **kwargs):
        nonlocal batch_number, active_batch
        if active_batch is not None:
            raise RuntimeError('unexpected nested batch in observer')
        batch_number += 1
        context = {'batch_id': batch_number, 'epoch_zero_based': int(epoch),
                   'is_training': bool(is_training), 'phase': phase(is_training)}
        before = counters(pipeline)
        emit('batch_start', **context, learning_rates=lrs(pipeline),
             recovery_budget=getattr(pipeline, 'nan_resets_left', None))
        active_batch = context
        try:
            result = batch_function(pipeline, batch, is_training, epoch, *args, **kwargs)
        except BaseException as error:
            emit('batch_error', **context, error_type=type(error).__name__, error=str(error)[:2000],
                 learning_rates=lrs(pipeline))
            raise
        else:
            after = counters(pipeline)
            samples = int(result[2])
            emit('batch_end', **context, learning_rates=lrs(pipeline), returned_samples=samples,
                 optimizer_update_completed=bool(is_training and samples > 0),
                 grad_recoveries=after['skipped_grad_explosion'] - before['skipped_grad_explosion'],
                 loss_recoveries=after['skipped_nan_inf'] - before['skipped_nan_inf'],
                 empty_window_skips=after['skipped_empty_window'] - before['skipped_empty_window'],
                 recovery_budget=getattr(pipeline, 'nan_resets_left', None))
            return result
        finally:
            active_batch = None

    @functools.wraps(epoch_function)
    def observed_epoch(pipeline, data_loader, epoch, is_training=True, *args, **kwargs):
        context = {'epoch_zero_based': int(epoch), 'is_training': bool(is_training),
                   'phase': phase(is_training)}
        emit('epoch_start', **context, learning_rates=lrs(pipeline),
             recovery_budget=getattr(pipeline, 'nan_resets_left', None))
        try:
            result = epoch_function(pipeline, data_loader, epoch, is_training, *args, **kwargs)
        except BaseException as error:
            emit('epoch_error', **context, error_type=type(error).__name__, error=str(error)[:2000],
                 learning_rates=lrs(pipeline))
            raise
        emit('epoch_end', **context, learning_rates=lrs(pipeline),
             recovery_budget=getattr(pipeline, 'nan_resets_left', None))
        return result

    @functools.wraps(recovery_function)
    def observed_recovery(pipeline, *args, **kwargs):
        before = lrs(pipeline)
        result = recovery_function(pipeline, *args, **kwargs)
        emit('recovery', **(active_batch or {}), lr_before=before, lr_after=lrs(pipeline),
             recovery_budget_before_decrement=getattr(pipeline, 'nan_resets_left', None))
        return result

    # Claim the stream before changing function bindings. Any existing stream is a hard stop.
    with output.open('x', encoding='utf-8'):
        pass
    emit('observer_installed', numerical_algorithm='frozen_legacy_20260907',
         train_denominator='batch_start with is_training=true; validation excluded')
    namespace['run_one_batch'] = observed_batch
    namespace['run_one_epoch'] = observed_epoch
    namespace['_restore_safe_state'] = observed_recovery
    namespace['_wrr_lr_observer_installed'] = True
