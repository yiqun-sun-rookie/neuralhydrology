"""Metadata-only observer summary; terminality and scores must be joined separately."""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def summarize_events(records, best_epoch=None):
    if not records or records[0]['event'] != 'observer_installed':
        raise ValueError('missing observer header')
    if [record['sequence'] for record in records] != list(range(1, len(records) + 1)):
        raise ValueError('observer sequence missing, duplicated or out of order')
    starts, ends, recoveries = {}, {}, []
    learning_rates = []
    for record in records:
        if record.get('is_training') is not True:
            continue
        if best_epoch is not None and record.get('epoch_zero_based', best_epoch + 1) > best_epoch:
            continue
        event = record['event']
        if event == 'batch_start':
            key = record['batch_id']
            if key in starts:
                raise ValueError('duplicate training batch start')
            starts[key] = record
            if not learning_rates or learning_rates[-1]['learning_rates'] != record['learning_rates']:
                learning_rates.append({'batch_id': key, 'epoch_zero_based': record['epoch_zero_based'],
                                       'learning_rates': record['learning_rates']})
        elif event in ('batch_end', 'batch_error'):
            key = record['batch_id']
            if key not in starts or key in ends:
                raise ValueError('orphan or duplicate training batch end')
            ends[key] = record
        elif event == 'recovery':
            if record['batch_id'] not in starts:
                raise ValueError('orphan recovery')
            recoveries.append(record)
    complete = [record for record in ends.values() if record['event'] == 'batch_end']
    grad = sum(record['grad_recoveries'] for record in complete)
    loss = sum(record['loss_recoveries'] for record in complete)
    if grad + loss > len(recoveries):
        raise ValueError('missing recovery event')
    if set(starts) == set(ends) and all(record['event'] == 'batch_end' for record in ends.values()):
        if grad + loss != len(recoveries):
            raise ValueError('recovery reason counter mismatch')
    return {'training_batches_attempted': len(starts),
            'training_batches_completed': len(complete),
            'optimizer_updates_completed': sum(record['optimizer_update_completed'] for record in complete),
            'unfinished_batch_ids': sorted(set(starts) - set(ends)),
            'batch_errors': [record for record in ends.values() if record['event'] == 'batch_error'],
            'grad_recoveries': grad, 'loss_recoveries': loss,
            'recoveries_total_observed': len(recoveries),
            'recoveries_with_unfinished_reason': len(recoveries) - grad - loss,
            'recoveries_per_1000_training_batches': 1000 * len(recoveries) / len(starts) if starts else None,
            'learning_rate_changes_at_batch_start': learning_rates,
            'through_epoch_zero_based': best_epoch,
            'does_not_establish_scheduler_terminality': True}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('events', type=Path)
    parser.add_argument('--best-epoch', type=int)
    args = parser.parse_args()
    records = [json.loads(line) for line in args.events.read_text(encoding='utf-8').splitlines() if line.strip()]
    print(json.dumps(summarize_events(records, args.best_epoch), indent=2, allow_nan=False))


if __name__ == '__main__':
    main()
