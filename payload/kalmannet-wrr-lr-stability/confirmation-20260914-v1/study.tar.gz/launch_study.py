"""Ten-run identity adapter; the original launcher and numerical rules stay frozen."""
from __future__ import annotations

import argparse
import importlib.util
import os
from pathlib import Path

ROOT = Path('/data1/home/sunyiq/kalmannet_wrr_lr_stability_20260914')


def combinations():
    return [dict(index=2 * (seed - 45) + arm, seed=seed, effective_seed=seed,
                 hidden_size=32, num_layers=1, in_out_mult=10, lr=lr,
                 role='learning_rate_confirmation',
                 run_id=f'WRR-LR-20260914-I{2 * (seed - 45) + arm:02d}')
            for seed in range(45, 50) for arm, lr in enumerate((0.01, 0.02))]


def validate_index(index):
    if type(index) is not int or not 0 <= index < 10:
        raise ValueError('study index must be an integer in 0..9')
    return index


def validate_combo(index, combo):
    validate_index(index)
    if combo != combinations()[index]:
        raise RuntimeError(f'protected combination mismatch at index {index}')


def load_guard(root):
    spec = importlib.util.spec_from_file_location('frozen_replication_guard', root / 'legacy_guard.py')
    guard = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guard)
    guard.REMOTE_ROOT = ROOT
    guard.validate_index = validate_index
    guard.validate_combo = validate_combo
    return guard


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--index', type=int)
    parser.add_argument('--check-environment', action='store_true')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    if root != ROOT:
        raise RuntimeError(f'only the isolated compute deployment may launch: {root}')
    if not os.environ.get('SLURM_JOB_ID'):
        raise RuntimeError('scheduler allocation required; login-node execution forbidden')
    guard = load_guard(root)
    _, expected = guard._load_controls(root)
    if args.check_environment:
        guard.validate_runtime_snapshot(guard.inspect_environment(), expected, guard.VERSION_RUNTIME_FIELDS)
        print('EXPECTED_RUNTIME_MATCH', flush=True)
        return
    index = validate_index(args.index)
    if os.environ.get('SLURM_ARRAY_TASK_ID') != str(index):
        raise RuntimeError('array identity mismatch')
    observer_dir = root / 'diagnostics'
    observer_dir.mkdir(exist_ok=True)
    os.environ['WRR_LR_OBSERVER_PATH'] = str(observer_dir / f'index{index:04d}.jsonl')
    os.environ['WRR_LR_RUN_ID'] = combinations()[index]['run_id']
    guard.run_one(root, index)


if __name__ == '__main__':
    main()
