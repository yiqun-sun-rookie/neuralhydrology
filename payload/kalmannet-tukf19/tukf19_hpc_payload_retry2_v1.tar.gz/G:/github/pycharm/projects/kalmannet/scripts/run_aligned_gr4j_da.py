"""Leakage-safe building blocks for the aligned GR4J-PDD lead-one audit.

Importing this module performs no data access.  The functions in this file use
daily discharge in millimetres and keep discharge outside the persistent state.
"""
from __future__ import annotations

from dataclasses import dataclass
from collections.abc import Mapping, Sequence
import argparse
import csv
import hashlib
import json
import math
import platform
from pathlib import Path
import shutil
import sys

import numpy as np
import torch


CALIBRATION_START = np.datetime64("1999-10-01", "D")
CALIBRATION_END = np.datetime64("2008-09-30", "D")
VALIDATION_START = np.datetime64("2006-10-02", "D")
VALIDATION_END = CALIBRATION_END

TRAINING_BASINS = (
    "06847900", "05408000", "04115265", "12390700", "07301410",
    "08086212", "08195000", "09312600", "10343500", "02381600",
    "13018300", "02038850", "03473000", "01440000", "02059500",
    "01181000", "01596500", "03011800", "06888500", "03182500",
    "02014000", "09508300", "03186500", "12041200", "06917000",
    "01365000", "02395120", "06623800", "08014500", "08013000",
    "03144000", "11478500", "11264500", "12377150", "02481510",
    "02481000", "14137000", "14141500", "12025700", "14301000",
)
HOLDOUT_BASINS = (
    "09306242", "01632900", "01591400", "13023000",
    "11141280", "09513780", "07362587", "12488500",
    "13235000", "09497980", "02374500", "02081500",
    "05592575", "12114500", "12082500", "03015500",
)
PARAMETER_NAMES = (
    "pdd_factor_snow", "refreeze_snow", "temp_snow", "temp_rain",
    "x1", "x2", "x3", "x4",
)
EXPECTED_CANDIDATES = (
    ("q1e-4_r0.01", 1e-4, 0.01),
    ("q1e-4_r0.1", 1e-4, 0.1),
    ("q1e-4_r1", 1e-4, 1.0),
    ("q1e-3_r0.01", 1e-3, 0.01),
    ("q1e-3_r0.1", 1e-3, 0.1),
    ("q1e-3_r1", 1e-3, 1.0),
    ("q1e-2_r0.01", 1e-2, 0.01),
    ("q1e-2_r0.1", 1e-2, 0.1),
    ("q1e-2_r1", 1e-2, 1.0),
)
PERIOD_CONTRACT = {
    "evaluation_warmup": ("1980-10-01", "1989-09-30", 3287),
    "evaluation": ("1989-10-01", "1999-09-30", 3652),
    "calibration": ("1999-10-01", "2008-09-30", 3288),
    "validation": ("2006-10-02", "2008-09-30", 730),
}
LOADER_CFS_TO_MM_DAY_KM2 = 2.4466


def _sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_frozen_protocol(path: str | Path) -> dict:
    """Load and strictly validate the version-one audit contract."""
    config_path = Path(path)
    with config_path.open("r", encoding="utf-8") as stream:
        protocol = json.load(stream)
    if protocol.get("schema_version") != "aligned_gr4j_da_v1":
        raise ValueError("schema_version must be aligned_gr4j_da_v1")
    basins = protocol.get("basins", {})
    training = tuple(str(value).zfill(8) for value in basins.get("training", ()))
    holdout = tuple(str(value).zfill(8) for value in basins.get("holdout", ()))
    if training != TRAINING_BASINS or holdout != HOLDOUT_BASINS:
        raise ValueError("basin split must equal the frozen 40-training/16-holdout contract")
    if set(training) & set(holdout):
        raise ValueError("training and holdout basin sets must not overlap")

    periods = protocol.get("periods", {})
    for name, (start, end, days) in PERIOD_CONTRACT.items():
        row = periods.get(name, {})
        if row.get("start") != start or row.get("end") != end or int(row.get("days", -1)) != days:
            raise ValueError(f"period '{name}' does not match the frozen contract")
        calendar_days = int(
            (np.datetime64(end, "D") - np.datetime64(start, "D"))
            / np.timedelta64(1, "D")) + 1
        if calendar_days != days:
            raise ValueError(f"period '{name}' day count is internally inconsistent")
    if int(periods.get("calibration_warmup_days", -1)) != 365:
        raise ValueError("calibration_warmup_days must be 365")

    data = protocol.get("data", {})
    expected_projection = ["basin_id"] + [f"p_{name}" for name in PARAMETER_NAMES]
    if data.get("parameter_projection") != expected_projection:
        raise ValueError("parameter_projection must contain identifiers and p_* columns only")
    if data.get("forcing_product") != "maurer" or data.get(
            "potential_evapotranspiration") != "priestley_taylor":
        raise ValueError("forcing and potential-evapotranspiration products are frozen")
    if float(data.get("loader_cfs_to_mm_day_km2_factor", 0.0)) != LOADER_CFS_TO_MM_DAY_KM2:
        raise ValueError("loader discharge conversion factor must be 2.4466")

    ukf = protocol.get("ukf", {})
    if ukf.get("modes") != ["storage_only", "full_state"]:
        raise ValueError("both frozen update modes must be present in order")
    if ukf.get("candidate_budget_by_mode") != {"storage_only": 9, "full_state": 9}:
        raise ValueError("both update modes must receive the same nine-candidate budget")
    candidates = ukf.get("candidates", ())
    actual_candidates = tuple((
        str(row.get("id")),
        float(row.get("process_variance_multiplier", float("nan"))),
        float(row.get("observation_variance_multiplier", float("nan"))),
    ) for row in candidates)
    if actual_candidates != EXPECTED_CANDIDATES:
        raise ValueError("UKF candidate grid or deterministic order changed")
    if not bool(ukf.get("candidate_order_is_tie_breaker")):
        raise ValueError("candidate order must be the deterministic tie breaker")
    frozen_selection_objective = (
        "mean across the 40 training basins of each basin's validation squared error "
        "divided by that basin's validation observed-flow sum of squared deviations"
    )
    if float(ukf.get("initial_variance_multiplier", float("nan"))) != 1.0:
        raise ValueError("frozen initial_variance_multiplier must be 1.0")
    if ukf.get("selection_objective") != frozen_selection_objective:
        raise ValueError("frozen UKF selection objective changed")

    scales = protocol.get("scales", {})
    if float(scales.get("numeric_floor", float("nan"))) != 1e-6:
        raise ValueError("frozen adjacent-difference scale floor must be 1e-6")
    gate = protocol.get("gate", {})
    if float(gate.get("paired_median_margin", float("nan"))) != 0.013:
        raise ValueError("frozen paired-median gate margin must be 0.013")
    outputs = protocol.get("outputs", {})
    if outputs.get("formal_root") != "results/aligned_da_v1":
        raise ValueError("frozen formal output root must be results/aligned_da_v1")

    state = protocol.get("state", {})
    if state.get("persistent_prefix") != ["snow", "S", "R"] or state.get(
            "discharge_is_state") is not False:
        raise ValueError("persistent state must start with snow, S, R and exclude discharge")
    hashing = protocol.get("hashing", {})
    if hashing.get("algorithm") != "sha256":
        raise ValueError("hash algorithm must be sha256")
    for key in ("parameter_csv", "canonical_basin_list", "loader_source"):
        value = str(hashing.get(key, ""))
        if len(value) != 64 or any(character not in "0123456789abcdef" for character in value):
            raise ValueError(f"hashing.{key} must be a lowercase SHA-256 digest")
    return protocol


@dataclass(frozen=True)
class ParameterOnlyPrior:
    """Per-basin calibrated parameters with no state or historical score fields."""

    basin_ids: tuple[str, ...]
    parameter_names: tuple[str, ...]
    param_table: np.ndarray
    id2idx: dict[str, int]

    def params_for_basin(self, basin_id: str) -> dict[str, float]:
        normalized = str(basin_id).zfill(8)
        if normalized not in self.id2idx:
            raise KeyError(f"basin {normalized} is absent from the parameter table")
        row = self.param_table[self.id2idx[normalized]]
        return {name: float(row[index]) for index, name in enumerate(self.parameter_names)}


def load_parameter_only_prior(
    csv_path: str | Path,
    basin_list_path: str | Path,
    parameter_names: Sequence[str] = PARAMETER_NAMES,
) -> ParameterOnlyPrior:
    """Project a frozen result table onto basin identifiers and p_* columns only."""
    import pandas as pd
    names = tuple(str(name) for name in parameter_names)
    if not names or len(names) != len(set(names)):
        raise ValueError("parameter_names must be unique and non-empty")
    columns = ["basin_id"] + [f"p_{name}" for name in names]
    table = pd.read_csv(
        Path(csv_path), usecols=columns, dtype={"basin_id": "string"})
    table["basin_id"] = table["basin_id"].astype(str).str.zfill(8)
    if table["basin_id"].duplicated().any():
        raise ValueError("parameter CSV contains duplicate basin identifiers")
    canonical = tuple(
        line.strip().zfill(8)
        for line in Path(basin_list_path).read_text(encoding="utf-8").splitlines()
        if line.strip()
    )
    if len(canonical) != len(set(canonical)):
        raise ValueError("canonical basin list contains duplicate identifiers")
    indexed = table.set_index("basin_id")
    missing = [basin for basin in canonical if basin not in indexed.index]
    if missing:
        raise KeyError(f"parameter CSV is missing canonical basins: {missing[:3]}")
    values = indexed.loc[list(canonical), columns[1:]].to_numpy(dtype=np.float64)
    if values.shape != (len(canonical), len(names)) or not np.isfinite(values).all():
        raise ValueError("projected parameter table must be finite and rectangular")
    return ParameterOnlyPrior(
        basin_ids=canonical,
        parameter_names=names,
        param_table=values,
        id2idx={basin: index for index, basin in enumerate(canonical)},
    )


def simulate_openloop(model, forcings, initial_state=None) -> dict[str, np.ndarray]:
    """Advance raw ``[precipitation, temperature, PET]`` forcing without observations."""
    forcing_values = np.asarray(forcings, dtype=np.float64)
    if forcing_values.ndim != 2 or forcing_values.shape[1] != 3 or forcing_values.shape[0] < 1:
        raise ValueError("forcings must have shape [day, 3]")
    if not np.isfinite(forcing_values).all():
        raise ValueError("forcings must be finite")
    if initial_state is None:
        state = model.default_state()[0]
    else:
        state = torch.as_tensor(
            initial_state, dtype=torch.float64, device=getattr(model, "device", "cpu"))
        if state.shape == (1, int(model.dim_x)):
            state = state[0]
        if state.shape != (int(model.dim_x),):
            raise ValueError("initial_state must have one value per persistent state")
        state = model.project_state(state)
    predictions = np.empty(forcing_values.shape[0], dtype=np.float64)
    states = np.empty((forcing_values.shape[0], int(model.dim_x)), dtype=np.float64)
    with torch.no_grad():
        for day, forcing in enumerate(forcing_values):
            next_state, discharge = model.transition(state.unsqueeze(0), tuple(forcing))
            state = torch.as_tensor(
                next_state, dtype=torch.float64, device=state.device)[0]
            predictions[day] = float(torch.as_tensor(discharge).reshape(-1)[0].cpu())
            states[day] = state.cpu().numpy()
    return {"prediction": predictions, "state": states, "final_state": states[-1].copy()}


def load_basin_arrays(load_camels_basin, basin_id: str, protocol: Mapping) -> dict:
    """Load exact raw daily forcing and observations without snow preprocessing."""
    import pandas as pd
    periods = protocol["periods"]
    data = protocol["data"]
    normalized = str(basin_id).zfill(8)
    common = {
        "data_root": str(data["camels_us_root"]),
        "forcing": str(data["forcing_product"]),
        "pet_method": str(data["potential_evapotranspiration"]),
        "keep_obs_nan_days": True,
    }
    evaluation_all, evaluation_observations_all, evaluation_area = load_camels_basin(
        normalized,
        start_date=periods["evaluation_warmup"]["start"],
        end_date=periods["evaluation"]["end"],
        **common,
    )
    calibration, calibration_observations, calibration_area = load_camels_basin(
        normalized,
        start_date=periods["calibration"]["start"],
        end_date=periods["calibration"]["end"],
        **common,
    )
    expected_warmup = pd.date_range(
        periods["evaluation_warmup"]["start"], periods["evaluation_warmup"]["end"], freq="D")
    expected_evaluation = pd.date_range(
        periods["evaluation"]["start"], periods["evaluation"]["end"], freq="D")
    expected_all = expected_warmup.append(expected_evaluation)
    expected_calibration = pd.date_range(
        periods["calibration"]["start"], periods["calibration"]["end"], freq="D")
    if not evaluation_all.index.equals(expected_all) or not evaluation_observations_all.index.equals(
            expected_all):
        raise ValueError("evaluation warmup and evaluation must form the exact daily index")
    if not calibration.index.equals(expected_calibration) or not calibration_observations.index.equals(
            expected_calibration):
        raise ValueError("calibration must form the exact daily index")
    if len(expected_warmup) != int(periods["evaluation_warmup"]["days"]):
        raise ValueError("evaluation warmup day count changed")
    if len(expected_evaluation) != int(periods["evaluation"]["days"]):
        raise ValueError("evaluation day count changed")
    if len(expected_calibration) != int(periods["calibration"]["days"]):
        raise ValueError("calibration day count changed")
    if not math.isclose(float(evaluation_area), float(calibration_area), rel_tol=0.0, abs_tol=1e-9):
        raise ValueError("basin area changed between evaluation and calibration loads")
    area = float(evaluation_area)
    if not math.isfinite(area) or area <= 0.0:
        raise ValueError("basin area must be positive and finite")

    def raw_forcing(frame, label: str) -> np.ndarray:
        missing = [column for column in ("prcp", "tmean", "ep") if column not in frame]
        if missing:
            raise KeyError(f"{label} forcing is missing raw columns {missing}")
        values = frame.loc[:, ["prcp", "tmean", "ep"]].to_numpy(dtype=np.float64)
        if not np.isfinite(values).all():
            raise ValueError(f"{label} raw precipitation, temperature, or PET is non-finite")
        if np.any(values[:, 0] < 0.0) or np.any(values[:, 2] < 0.0):
            raise ValueError(f"{label} precipitation and PET must be nonnegative")
        return values

    evaluation_all_forcing = raw_forcing(evaluation_all, "evaluation")
    calibration_forcing = raw_forcing(calibration, "calibration")
    warmup_days = len(expected_warmup)
    evaluation_observation_values = evaluation_observations_all.to_numpy(dtype=np.float64)
    calibration_observation_values = calibration_observations.to_numpy(dtype=np.float64)
    return {
        "basin_id": normalized,
        "area_km2": area,
        "evaluation_warmup_dates": expected_warmup.to_numpy(dtype="datetime64[D]"),
        "evaluation_warmup_forcing": evaluation_all_forcing[:warmup_days],
        "evaluation_dates": expected_evaluation.to_numpy(dtype="datetime64[D]"),
        "evaluation_forcing": evaluation_all_forcing[warmup_days:],
        "evaluation_observations": evaluation_observation_values[warmup_days:],
        "calibration_dates": expected_calibration.to_numpy(dtype="datetime64[D]"),
        "calibration_forcing": calibration_forcing,
        "calibration_observations": calibration_observation_values,
    }


def isolated_next_day_effect(model, reference_state, correction, forcings) -> np.ndarray:
    """Measure each corrected channel's isolated effect on the following day's flow."""
    reference = np.asarray(reference_state, dtype=np.float64)
    changes = np.asarray(correction, dtype=np.float64)
    forcing_values = np.asarray(forcings, dtype=np.float64)
    expected = (forcing_values.shape[0], int(model.dim_x))
    if reference.shape != expected or changes.shape != expected or forcing_values.shape[1:] != (3,):
        raise ValueError("state, correction, and raw forcing arrays must align")
    if not np.isfinite(reference).all() or not np.isfinite(changes).all() or not np.isfinite(
            forcing_values).all():
        raise ValueError("state, correction, and forcing must be finite")
    effects = np.full(expected, np.nan, dtype=np.float64)
    dimension = int(model.dim_x)
    device = getattr(model, "device", "cpu")
    with torch.no_grad():
        for day in range(forcing_values.shape[0] - 1):
            base = torch.as_tensor(reference[day], dtype=torch.float64, device=device)
            base = model.project_state(base)
            _, base_discharge = model.transition(
                base.unsqueeze(0), tuple(forcing_values[day + 1]))
            perturbed = base.repeat(dimension, 1)
            diagonal = torch.arange(dimension, device=perturbed.device)
            perturbed[diagonal, diagonal] += torch.as_tensor(
                changes[day], dtype=torch.float64, device=perturbed.device)
            perturbed = model.project_state(perturbed)
            _, changed_discharge = model.transition(
                perturbed, tuple(forcing_values[day + 1]))
            effects[day] = (
                torch.as_tensor(changed_discharge).reshape(-1)
                - torch.as_tensor(base_discharge).reshape(-1)[0]
            ).cpu().numpy()
    return effects


def normalized_squared_error(observations, prediction, base_mask=None) -> dict[str, float | int]:
    """Return one basin's squared error normalized by its observed-flow variation."""
    obs = np.asarray(observations, dtype=np.float64)
    pred = np.asarray(prediction, dtype=np.float64)
    if obs.ndim != 1 or pred.shape != obs.shape:
        raise ValueError("observations and prediction must be aligned vectors")
    if base_mask is None:
        mask = np.ones(obs.shape, dtype=bool)
    else:
        mask = np.asarray(base_mask, dtype=bool).copy()
        if mask.shape != obs.shape:
            raise ValueError("base_mask must align with observations")
    mask &= np.isfinite(obs) & np.isfinite(pred)
    if int(mask.sum()) < 2:
        raise ValueError("fewer than two finite scoring days")
    selected_obs = obs[mask]
    squared_error = float(np.sum((pred[mask] - selected_obs) ** 2))
    denominator = float(np.sum((selected_obs - selected_obs.mean()) ** 2))
    if not np.isfinite(denominator) or denominator <= 0.0:
        raise ValueError("observed-flow normalization denominator must be positive")
    return {
        "n": int(mask.sum()),
        "squared_error": squared_error,
        "denominator": denominator,
        "normalized_squared_error": squared_error / denominator,
    }


def select_shared_candidate(
    per_basin_losses: Mapping[str, Mapping[str, float]],
    candidate_order: Sequence[str],
    expected_training_basins: Sequence[str],
) -> dict:
    """Choose one shared candidate; the fixed order resolves exact objective ties."""
    expected = tuple(str(basin) for basin in expected_training_basins)
    actual = tuple(str(basin) for basin in per_basin_losses)
    if set(actual) != set(expected) or len(actual) != len(expected):
        raise ValueError("losses must contain the exact frozen training basin set")
    candidates = tuple(str(candidate) for candidate in candidate_order)
    if not candidates or len(candidates) != len(set(candidates)):
        raise ValueError("candidate_order must be unique and non-empty")
    matrix = np.empty((len(expected), len(candidates)), dtype=np.float64)
    for basin_index, basin in enumerate(expected):
        row = per_basin_losses[basin]
        if set(row) != set(candidates):
            raise ValueError("every training basin must contain every candidate exactly once")
        matrix[basin_index] = [float(row[candidate]) for candidate in candidates]
    if not np.isfinite(matrix).all():
        raise ValueError("candidate losses must be finite")
    means = matrix.mean(axis=0)
    selected_index = int(np.argmin(means))
    return {
        "selected_id": candidates[selected_index],
        "selected_index": selected_index,
        "objective": float(means[selected_index]),
        "candidate_order": list(candidates),
        "mean_normalized_squared_error": {
            candidate: float(means[index]) for index, candidate in enumerate(candidates)
        },
        "per_basin_normalized_squared_error": {
            basin: {candidate: float(per_basin_losses[basin][candidate]) for candidate in candidates}
            for basin in expected
        },
    }


def build_scaled_covariances(
    model,
    state_scale,
    observation_scale: float,
    candidate: Mapping[str, float | str],
    initial_variance_multiplier: float,
    mode: str,
) -> dict[str, np.ndarray | float]:
    """Apply the frozen dimensionless covariance formula for one candidate."""
    permission_mask(model, mode)
    scales = np.asarray(state_scale, dtype=np.float64)
    if scales.shape != (int(model.dim_x),) or not np.isfinite(scales).all() or np.any(scales <= 0.0):
        raise ValueError("state_scale must be positive and finite per persistent state")
    discharge_scale = float(observation_scale)
    initial_multiplier = float(initial_variance_multiplier)
    process_multiplier = float(candidate["process_variance_multiplier"])
    observation_multiplier = float(candidate["observation_variance_multiplier"])
    if not all(math.isfinite(value) and value > 0.0 for value in (
            discharge_scale, initial_multiplier, process_multiplier, observation_multiplier)):
        raise ValueError("scales and covariance multipliers must be positive and finite")
    return {
        "initial_covariance": np.diag(scales * scales * initial_multiplier),
        "process_covariance": np.diag(scales * scales * process_multiplier),
        "observation_variance": discharge_scale * discharge_scale * observation_multiplier,
    }


def write_daily_npz(
    path: str | Path,
    payload: Mapping[str, np.ndarray | float | int],
    loader_cfs_factor: float = LOADER_CFS_TO_MM_DAY_KM2,
) -> dict[str, str | int]:
    """Write one basin immediately as compressed, non-pickle numerical arrays."""
    destination = Path(path)
    arrays = {str(name): np.asarray(value) for name, value in payload.items()}
    required = {"dates", "area_km2", "observed_mm_per_day"}
    if not required.issubset(arrays):
        raise ValueError(f"daily payload is missing {sorted(required - set(arrays))}")
    dates = arrays["dates"].astype("datetime64[D]")
    if dates.ndim != 1:
        raise ValueError("dates must be a daily vector")
    observations = np.asarray(arrays["observed_mm_per_day"], dtype=np.float64)
    if observations.shape != dates.shape:
        raise ValueError("observed_mm_per_day must align with dates")
    area = float(np.asarray(arrays["area_km2"]).reshape(()))
    factor = float(loader_cfs_factor)
    if not math.isfinite(area) or area <= 0.0 or not math.isfinite(factor) or factor <= 0.0:
        raise ValueError("area and loader conversion factor must be positive and finite")
    arrays["dates"] = dates
    arrays["area_km2"] = np.asarray(area, dtype=np.float64)
    arrays["area"] = arrays["area_km2"].copy()
    arrays["observed_mm_per_day"] = observations
    arrays["obs_mm"] = observations.copy()
    arrays["observed_cfs"] = observations * area / factor
    arrays["observed_cfs_reconstructed"] = arrays["observed_cfs"].copy()
    arrays["obs_cfs_reconstructed"] = arrays["observed_cfs"].copy()
    channel_metadata = {"state_names", "state_scale", "ar2_coefficients"}
    for name, array in arrays.items():
        if array.dtype == object:
            raise ValueError(f"daily array '{name}' must not use object dtype")
        if array.ndim > 0 and name not in channel_metadata and array.shape[0] not in (dates.size,):
            raise ValueError(f"daily array '{name}' must align on its first dimension")
    destination.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(destination, **arrays)
    return {
        "path": str(destination),
        "format": "npz_compressed",
        "sha256": _sha256(destination),
        "days": int(dates.size),
    }


def strict_calibration_masks(dates: Sequence) -> dict[str, np.ndarray]:
    """Return exact calibration/train/validation masks for a daily date axis."""
    values = np.asarray(dates)
    if values.ndim != 1 or values.size == 0:
        raise ValueError("dates must be a non-empty one-dimensional daily axis")
    try:
        daily = values.astype("datetime64[D]")
    except (TypeError, ValueError) as error:
        raise ValueError("dates must be convertible to calendar dates") from error
    if np.isnat(daily).any():
        raise ValueError("dates must not contain missing values")
    if daily.size > 1 and not np.all(np.diff(daily) == np.timedelta64(1, "D")):
        raise ValueError("dates must be strictly consecutive daily values")
    if daily[0] > CALIBRATION_START or daily[-1] < CALIBRATION_END:
        raise ValueError(
            "dates must cover 1999-10-01 through 2008-09-30")

    calibration = (daily >= CALIBRATION_START) & (daily <= CALIBRATION_END)
    validation = (daily >= VALIDATION_START) & (daily <= VALIDATION_END)
    train = calibration & ~validation
    if int(validation.sum()) != 730:
        raise ValueError("validation must contain exactly the final 730 calibration days")
    return {
        "calibration": calibration,
        "train": train,
        "validation": validation,
    }


def difference_p95_scale(
    values: np.ndarray | Sequence,
    mask: np.ndarray | Sequence[bool],
    floor: float = 1e-6,
) -> np.ndarray:
    """Compute a per-channel 95th percentile absolute daily-difference scale."""
    data = np.asarray(values, dtype=np.float64)
    if data.ndim == 1:
        data = data[:, None]
    if data.ndim != 2:
        raise ValueError("values must have shape [time] or [time, channel]")
    selected = np.asarray(mask, dtype=bool)
    if selected.ndim != 1 or selected.shape[0] != data.shape[0]:
        raise ValueError("mask must have one entry per day")
    if not np.isfinite(floor) or floor <= 0.0:
        raise ValueError("floor must be a positive finite number")

    scales = np.full(data.shape[1], float(floor), dtype=np.float64)
    adjacent_in_mask = selected[:-1] & selected[1:]
    differences = np.abs(np.diff(data, axis=0))
    for channel in range(data.shape[1]):
        valid = adjacent_in_mask & np.isfinite(data[:-1, channel]) & np.isfinite(
            data[1:, channel])
        if valid.any():
            scales[channel] = max(
                float(np.percentile(differences[valid, channel], 95.0)),
                float(floor),
            )
    return scales


def permission_mask(model, mode: str) -> torch.Tensor:
    """Return which persistent GR4J-PDD state channels an update may change."""
    names = tuple(model.state_names)
    if len(names) != int(model.dim_x):
        raise ValueError("model state metadata does not match its state dimension")
    if "q" in names:
        raise ValueError("discharge must not be a persistent state channel")
    if names[:3] != ("snow", "S", "R"):
        raise ValueError("the first persistent channels must be snow, S, and R")
    if mode == "storage_only":
        allowed = [True, True, True] + [False] * (model.dim_x - 3)
    elif mode == "full_state":
        allowed = [True] * model.dim_x
    else:
        raise ValueError("mode must be 'storage_only' or 'full_state'")
    return torch.tensor(allowed, dtype=torch.bool, device=getattr(model, "device", "cpu"))


def certify_full_state_reachable_envelope(model) -> dict:
    """Certify whether physical full-state bounds give a finite lead-one envelope.

    This structural check deliberately has no observation argument.  It does
    not choose a future target or a state that matches one.  A permitted
    lag-one routing queue with no finite upper bound is a constructive proof
    that the physical output envelope is unbounded and therefore useless as a
    finite performance gate.
    """
    allowed = permission_mask(model, "full_state").detach().cpu().numpy()
    metadata = tuple(getattr(model, "state_metadata", ()))
    if len(metadata) != int(model.dim_x):
        raise ValueError("complete state metadata are required for certification")
    witnesses = []
    for channel in metadata:
        index = int(channel.index)
        if index < 0 or index >= int(model.dim_x):
            raise ValueError("state metadata contain an invalid channel index")
        if (
            bool(allowed[index])
            and str(channel.role) in {"uh1_queue", "uh2_queue"}
            and int(channel.release_lag_days or -1) == 1
            and not math.isfinite(float(channel.upper))
        ):
            witnesses.append(channel)
    if witnesses:
        witness = witnesses[0]
        return {
            "certificate_scope": "unrestricted_physical_full_state",
            "certificate_status": "certified_unbounded",
            "finite_output_envelope": False,
            "reason_code": "unbounded_lag1_routing_queue",
            "witness_state_index": int(witness.index),
            "witness_state_name": str(witness.name),
            "witness_state_role": str(witness.role),
            "witness_release_lag_days": int(witness.release_lag_days),
            "witness_upper_bound": None,
            "witness_upper_bound_is_infinite": True,
            "future_observation_used": False,
            "theoretical_upper_bound": False,
            "interpretation": (
                "physical full-state output is unbounded, so no finite, "
                "decision-useful performance upper bound is certified"
            ),
        }
    return {
        "certificate_scope": "unrestricted_physical_full_state",
        "certificate_status": "not_certified",
        "finite_output_envelope": False,
        "reason_code": "no_unbounded_lag1_witness_but_finite_inclusion_not_proven",
        "future_observation_used": False,
        "theoretical_upper_bound": False,
    }


def gate_decision_from_certificate(certificate: Mapping, threshold: float = 0.013) -> dict:
    """Apply the frozen gate only to a finite certified paired performance upper bound."""
    margin = float(threshold)
    if not math.isfinite(margin) or margin < 0.0:
        raise ValueError("gate threshold must be a finite nonnegative number")
    status = str(certificate.get("certificate_status", ""))
    finite = bool(certificate.get("finite_output_envelope", False))
    if status != "certified_finite" or not finite:
        return {
            "gate_status": "indeterminate",
            "gate_threshold": margin,
            "gate_metric": None,
            "kalmannet_eligible": False,
            "negative_conclusion": False,
            "reason_code": str(certificate.get("reason_code", "finite_certificate_absent")),
        }
    metric = float(certificate["paired_median_upper_minus_ar2"])
    if not math.isfinite(metric):
        raise ValueError("finite certificate metric must be finite")
    if metric > margin:
        return {
            "gate_status": "potential_not_ruled_out",
            "gate_threshold": margin,
            "gate_metric": metric,
            "kalmannet_eligible": True,
            "negative_conclusion": False,
            "reason_code": "finite_certified_upper_exceeds_margin",
        }
    return {
        "gate_status": "negative",
        "gate_threshold": margin,
        "gate_metric": metric,
        "kalmannet_eligible": False,
        "negative_conclusion": True,
        "reason_code": "finite_certified_upper_does_not_exceed_margin",
    }


def fit_ar2(
    observations: np.ndarray | Sequence[float],
    openloop: np.ndarray | Sequence[float],
    train_mask: np.ndarray | Sequence[bool],
) -> np.ndarray:
    """Fit two no-intercept lag coefficients to training residuals only."""
    obs = np.asarray(observations, dtype=np.float64)
    base = np.asarray(openloop, dtype=np.float64)
    selected = np.asarray(train_mask, dtype=bool)
    if obs.ndim != 1 or base.shape != obs.shape or selected.shape != obs.shape:
        raise ValueError("observations, openloop, and train_mask must be aligned vectors")
    if obs.size < 3:
        raise ValueError("at least three daily values are required")
    residual = obs - base
    valid = (
        selected[2:]
        & selected[1:-1]
        & selected[:-2]
        & np.isfinite(residual[2:])
        & np.isfinite(residual[1:-1])
        & np.isfinite(residual[:-2])
    )
    design = np.column_stack(
        [residual[1:-1][valid], residual[:-2][valid]])
    target = residual[2:][valid]
    if design.shape[0] < 2:
        raise ValueError("fewer than two finite training residual triples")
    coefficients, _, _, _ = np.linalg.lstsq(design, target, rcond=None)
    return coefficients


def causal_ar2_predictions(
    observations: np.ndarray | Sequence[float],
    openloop: np.ndarray | Sequence[float],
    coefficients: np.ndarray | Sequence[float],
) -> np.ndarray:
    """Predict day ``t`` using only observed residuals from days ``t-1`` and ``t-2``."""
    obs = np.asarray(observations, dtype=np.float64)
    base = np.asarray(openloop, dtype=np.float64)
    coef = np.asarray(coefficients, dtype=np.float64)
    if obs.ndim != 1 or base.shape != obs.shape:
        raise ValueError("observations and openloop must be aligned vectors")
    if coef.shape != (2,) or not np.isfinite(coef).all():
        raise ValueError("coefficients must contain two finite no-intercept lags")
    predictions = np.full(obs.shape, np.nan, dtype=np.float64)
    residual = obs - base
    for index in range(2, obs.size):
        if (
            np.isfinite(base[index])
            and np.isfinite(residual[index - 1])
            and np.isfinite(residual[index - 2])
        ):
            predictions[index] = base[index] + (
                coef[0] * residual[index - 1]
                + coef[1] * residual[index - 2]
            )
    return predictions


def common_mask_scores(
    observations: np.ndarray | Sequence[float],
    predictions: Mapping[str, np.ndarray | Sequence[float]],
    base_mask: np.ndarray | Sequence[bool] | None = None,
) -> dict:
    """Score every method on one exact finite-date mask and one NSE denominator."""
    obs = np.asarray(observations, dtype=np.float64)
    if obs.ndim != 1 or not predictions:
        raise ValueError("observations must be a vector and predictions cannot be empty")
    if base_mask is None:
        common = np.ones(obs.shape, dtype=bool)
    else:
        common = np.asarray(base_mask, dtype=bool).copy()
        if common.shape != obs.shape:
            raise ValueError("base_mask must align with observations")
    common &= np.isfinite(obs)
    arrays: dict[str, np.ndarray] = {}
    for name, prediction in predictions.items():
        array = np.asarray(prediction, dtype=np.float64)
        if array.shape != obs.shape:
            raise ValueError(f"prediction '{name}' does not align with observations")
        arrays[str(name)] = array
        common &= np.isfinite(array)
    if int(common.sum()) < 2:
        raise ValueError("the common finite mask has fewer than two days")
    observed_common = obs[common]
    denominator = float(np.sum((observed_common - observed_common.mean()) ** 2))
    if not np.isfinite(denominator) or denominator <= 0.0:
        raise ValueError("NSE denominator on the common mask must be positive")
    scores = {
        name: float(1.0 - np.sum((array[common] - observed_common) ** 2) / denominator)
        for name, array in arrays.items()
    }
    return {
        "mask": common,
        "n": int(common.sum()),
        "denominator": denominator,
        "scores": scores,
    }


def paired_summary(
    candidate: np.ndarray | Sequence[float],
    baseline: np.ndarray | Sequence[float],
) -> dict:
    """Summarize per-basin paired score differences and disclose the wrong shortcut."""
    candidate_values = np.asarray(candidate, dtype=np.float64)
    baseline_values = np.asarray(baseline, dtype=np.float64)
    if candidate_values.ndim != 1 or baseline_values.shape != candidate_values.shape:
        raise ValueError("candidate and baseline must be aligned per-basin vectors")
    valid = np.isfinite(candidate_values) & np.isfinite(baseline_values)
    if not valid.any():
        raise ValueError("no finite basin pairs are available")
    candidate_valid = candidate_values[valid]
    baseline_valid = baseline_values[valid]
    differences = candidate_valid - baseline_valid
    return {
        "n": int(differences.size),
        "paired_differences": differences,
        "paired_median": float(np.median(differences)),
        "paired_mean": float(np.mean(differences)),
        "wins": int(np.sum(differences > 0.0)),
        "losses": int(np.sum(differences < 0.0)),
        "ties": int(np.sum(differences == 0.0)),
        "candidate_median": float(np.median(candidate_valid)),
        "baseline_median": float(np.median(baseline_valid)),
        "difference_of_medians": float(
            np.median(candidate_valid) - np.median(baseline_valid)),
    }


def _stable_covariance(covariance: torch.Tensor, floor: float = 1e-12) -> torch.Tensor:
    """Symmetrize a covariance and clip only numerically negative eigenvalues."""
    symmetric = 0.5 * (covariance + covariance.T)
    eigenvalues, eigenvectors = torch.linalg.eigh(symmetric)
    scale = torch.diagonal(symmetric).abs().max().clamp(min=1.0)
    clipped = torch.clamp(eigenvalues, min=floor * scale)
    return 0.5 * (
        (eigenvectors * clipped.unsqueeze(0)) @ eigenvectors.T
        + ((eigenvectors * clipped.unsqueeze(0)) @ eigenvectors.T).T
    )


def _validate_external_covariance(
    covariance: torch.Tensor,
    name: str,
    tolerance: float = 1e-10,
) -> torch.Tensor:
    """Reject invalid external covariance while allowing scale-relative roundoff."""
    if covariance.ndim != 2 or covariance.shape[0] != covariance.shape[1]:
        raise ValueError(f"{name} must be square")
    if not torch.isfinite(covariance).all():
        raise ValueError(f"{name} must be finite")
    scale = torch.max(torch.abs(covariance)).clamp(min=1e-12)
    asymmetry = torch.max(torch.abs(covariance - covariance.T))
    if asymmetry > tolerance * scale:
        raise ValueError(f"{name} must be symmetric")
    symmetric = 0.5 * (covariance + covariance.T)
    minimum_eigenvalue = torch.linalg.eigvalsh(symmetric).min()
    if minimum_eigenvalue < -tolerance * scale:
        raise ValueError(f"{name} must be positive semidefinite")
    return symmetric


def _stable_square_root(covariance: torch.Tensor) -> torch.Tensor:
    """Return a finite lower square root, with deterministic jitter and eigen fallback."""
    symmetric = 0.5 * (covariance + covariance.T)
    dimension = symmetric.shape[0]
    identity = torch.eye(dimension, dtype=symmetric.dtype, device=symmetric.device)
    scale = torch.diagonal(symmetric).abs().max().clamp(min=1.0)
    for multiplier in (0.0, 1e-12, 1e-10, 1e-8, 1e-6):
        candidate = symmetric + multiplier * scale * identity
        try:
            return torch.linalg.cholesky(candidate)
        except torch.linalg.LinAlgError:
            continue
    eigenvalues, eigenvectors = torch.linalg.eigh(symmetric)
    eigenvalues = torch.clamp(eigenvalues, min=1e-12 * scale)
    return eigenvectors @ torch.diag(torch.sqrt(eigenvalues))


def merwe_sigma_points(
    mean: torch.Tensor | np.ndarray | Sequence[float],
    covariance: torch.Tensor | np.ndarray,
    *,
    alpha: float = 0.3,
    beta: float = 2.0,
    kappa: float = 0.0,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Construct stable Merwe scaled sigma points for one persistent state vector."""
    state_mean = torch.as_tensor(mean, dtype=torch.float64)
    state_covariance = torch.as_tensor(
        covariance, dtype=state_mean.dtype, device=state_mean.device)
    if state_mean.ndim != 1:
        raise ValueError("mean must be one-dimensional")
    dimension = state_mean.numel()
    if state_covariance.shape != (dimension, dimension):
        raise ValueError("covariance must be square and match the mean")
    if not torch.isfinite(state_mean).all() or not torch.isfinite(state_covariance).all():
        raise ValueError("mean and covariance must be finite")
    if alpha <= 0.0 or beta < 0.0:
        raise ValueError("alpha must be positive and beta must be nonnegative")
    scaling = alpha * alpha * (dimension + kappa)
    if scaling <= 0.0:
        raise ValueError("dimension + kappa must produce positive sigma scaling")
    lambda_value = scaling - dimension

    mean_weights = torch.full(
        (2 * dimension + 1,),
        1.0 / (2.0 * scaling),
        dtype=state_mean.dtype,
        device=state_mean.device,
    )
    covariance_weights = mean_weights.clone()
    mean_weights[0] = lambda_value / scaling
    covariance_weights[0] = lambda_value / scaling + (1.0 - alpha * alpha + beta)
    root = _stable_square_root(scaling * state_covariance)
    sigma_points = [state_mean]
    for channel in range(dimension):
        offset = root[:, channel]
        sigma_points.extend((state_mean + offset, state_mean - offset))
    return torch.stack(sigma_points), mean_weights, covariance_weights


def constrained_covariance_update(
    prior_covariance: torch.Tensor | np.ndarray,
    cross_covariance: torch.Tensor | np.ndarray,
    innovation_covariance: torch.Tensor | np.ndarray | float,
    constrained_gain: torch.Tensor | np.ndarray,
) -> torch.Tensor:
    """Apply the general covariance formula for an arbitrarily constrained gain."""
    prior = torch.as_tensor(prior_covariance, dtype=torch.float64)
    cross = torch.as_tensor(
        cross_covariance, dtype=prior.dtype, device=prior.device)
    gain = torch.as_tensor(constrained_gain, dtype=prior.dtype, device=prior.device)
    innovation = torch.as_tensor(
        innovation_covariance, dtype=prior.dtype, device=prior.device)
    if innovation.ndim == 0:
        innovation = innovation.reshape(1, 1)
    if prior.ndim != 2 or prior.shape[0] != prior.shape[1]:
        raise ValueError("prior_covariance must be square")
    if cross.ndim == 1:
        cross = cross[:, None]
    if gain.ndim == 1:
        gain = gain[:, None]
    if cross.shape != gain.shape or cross.shape[0] != prior.shape[0]:
        raise ValueError("cross covariance and gain must match the state dimension")
    if innovation.shape != (cross.shape[1], cross.shape[1]):
        raise ValueError("innovation covariance does not match the observation dimension")
    posterior = (
        prior
        - gain @ cross.T
        - cross @ gain.T
        + gain @ innovation @ gain.T
    )
    return 0.5 * (posterior + posterior.T)


def _project_vector(model, state: torch.Tensor) -> torch.Tensor:
    projected = model.project_state(state.unsqueeze(0))
    if projected.shape != (1, int(model.dim_x)):
        raise ValueError("model.project_state returned an unexpected shape")
    return projected[0]


def _synchronize_boundary_covariance(
    covariance: torch.Tensor,
    hits: torch.Tensor,
    floor: float = 1e-12,
) -> torch.Tensor:
    """Remove cross terms for projected channels while retaining finite variance."""
    synchronized = covariance.clone()
    for channel in torch.nonzero(hits, as_tuple=False).flatten().tolist():
        variance = torch.clamp(synchronized[channel, channel], min=floor)
        synchronized[channel, :] = 0.0
        synchronized[:, channel] = 0.0
        synchronized[channel, channel] = variance
    return synchronized


def _validate_filter_inputs(
    model,
    forcings: np.ndarray | Sequence,
    observations: np.ndarray | Sequence[float],
    initial_state: np.ndarray | Sequence[float],
) -> tuple[np.ndarray, np.ndarray, torch.Tensor]:
    forcing_values = np.asarray(forcings, dtype=np.float64)
    observation_values = np.asarray(observations, dtype=np.float64)
    if forcing_values.ndim != 2 or forcing_values.shape[1] != 3:
        raise ValueError("forcings must have shape [time, 3]")
    if observation_values.shape != (forcing_values.shape[0],):
        raise ValueError("observations must have one value per forcing day")
    if not np.isfinite(forcing_values).all():
        raise ValueError("forcings must be finite")
    state = torch.as_tensor(
        initial_state,
        dtype=torch.float64,
        device=getattr(model, "device", "cpu"),
    )
    if state.shape != (int(model.dim_x),) or not torch.isfinite(state).all():
        raise ValueError("initial_state must be a finite persistent-state vector")
    return forcing_values, observation_values, _project_vector(model, state)


def _matrix_for_day(
    values: torch.Tensor | np.ndarray,
    day: int,
    days: int,
    dimension: int,
    device: torch.device,
    name: str,
) -> torch.Tensor:
    matrix = torch.as_tensor(values, dtype=torch.float64, device=device)
    if matrix.shape == (dimension, dimension):
        selected = matrix
    elif matrix.shape == (days, dimension, dimension):
        selected = matrix[day]
    else:
        raise ValueError(
            f"{name} must have shape [{dimension}, {dimension}] or "
            f"[time, {dimension}, {dimension}]")
    if not torch.isfinite(selected).all():
        raise ValueError(f"{name} must be finite")
    return _validate_external_covariance(selected, name)


def _variance_for_day(
    values: float | np.ndarray | Sequence[float],
    day: int,
    days: int,
    device: torch.device,
) -> torch.Tensor:
    variance = torch.as_tensor(values, dtype=torch.float64, device=device)
    if variance.ndim == 0:
        selected = variance
    elif variance.shape == (days,):
        selected = variance[day]
    else:
        raise ValueError("observation_variance must be scalar or have one value per day")
    if not torch.isfinite(selected) or selected <= 0.0:
        raise ValueError("observation_variance must be positive and finite")
    return selected


def run_persistent_ukf(
    model,
    forcings: np.ndarray | Sequence,
    observations: np.ndarray | Sequence[float],
    initial_state: np.ndarray | Sequence[float],
    initial_covariance: np.ndarray | torch.Tensor,
    process_covariance: np.ndarray | torch.Tensor,
    observation_variance: float | np.ndarray | Sequence[float],
    mode: str,
    *,
    alpha: float = 0.3,
    beta: float = 2.0,
    kappa: float = 0.0,
) -> dict[str, np.ndarray]:
    """Run a causal persistent-state unscented Kalman filter.

    ``prediction[t]`` is stored before ``observations[t]`` is inspected.  The
    same-day observation updates ``posterior_state[t]`` and can first affect
    ``prediction[t + 1]``.
    """
    forcing_values, observation_values, mean = _validate_filter_inputs(
        model, forcings, observations, initial_state)
    days = forcing_values.shape[0]
    dimension = int(model.dim_x)
    device = mean.device
    covariance = torch.as_tensor(
        initial_covariance, dtype=torch.float64, device=device)
    if covariance.shape != (dimension, dimension):
        raise ValueError("initial_covariance must be a finite state covariance matrix")
    covariance = _stable_covariance(
        _validate_external_covariance(covariance, "initial_covariance"))
    allowed = permission_mask(model, mode).to(device=device)

    prediction = np.full(days, np.nan, dtype=np.float64)
    prior_state = np.full((days, dimension), np.nan, dtype=np.float64)
    posterior_state = np.full((days, dimension), np.nan, dtype=np.float64)
    correction = np.zeros((days, dimension), dtype=np.float64)
    gain_values = np.zeros((days, dimension), dtype=np.float64)
    cross_values = np.full((days, dimension), np.nan, dtype=np.float64)
    boundary_hits = np.zeros((days, dimension), dtype=bool)
    projection_clips = np.zeros((days, dimension), dtype=bool)
    prior_covariance_values = np.full(
        (days, dimension, dimension), np.nan, dtype=np.float64)
    posterior_covariance_values = np.full_like(prior_covariance_values, np.nan)

    for day in range(days):
        sigma, mean_weights, covariance_weights = merwe_sigma_points(
            mean,
            covariance,
            alpha=alpha,
            beta=beta,
            kappa=kappa,
        )
        projected_sigma = model.project_state(sigma)
        propagated_state, propagated_discharge = model.transition(
            projected_sigma, tuple(forcing_values[day]))
        propagated_state = torch.as_tensor(
            propagated_state, dtype=torch.float64, device=device)
        propagated_discharge = torch.as_tensor(
            propagated_discharge, dtype=torch.float64, device=device).reshape(-1)
        expected_shape = (2 * dimension + 1, dimension)
        if propagated_state.shape != expected_shape:
            raise ValueError("model.transition returned an unexpected state shape")
        if propagated_discharge.shape != (2 * dimension + 1,):
            raise ValueError("model.transition returned an unexpected discharge shape")

        raw_prior_mean = torch.sum(
            mean_weights[:, None] * propagated_state, dim=0)
        projected_prior_mean = _project_vector(model, raw_prior_mean)
        prior_projection_hits = projected_prior_mean != raw_prior_mean
        discharge_mean = torch.sum(mean_weights * propagated_discharge)
        state_deviation = propagated_state - raw_prior_mean
        discharge_deviation = propagated_discharge - discharge_mean
        propagated_covariance = torch.einsum(
            "s,si,sj->ij",
            covariance_weights,
            state_deviation,
            state_deviation,
        )
        process_for_day = _matrix_for_day(
            process_covariance,
            day,
            days,
            dimension,
            device,
            "process_covariance",
        )
        propagated_covariance = _stable_covariance(
            propagated_covariance + process_for_day)
        cross_covariance = torch.einsum(
            "s,si,s->i", covariance_weights, state_deviation, discharge_deviation)
        observation_for_day = _variance_for_day(
            observation_variance, day, days, device)
        innovation_variance = torch.sum(
            covariance_weights * discharge_deviation * discharge_deviation)
        innovation_variance = innovation_variance + observation_for_day
        if not torch.isfinite(innovation_variance) or innovation_variance <= 0.0:
            raise ValueError("the propagated observation covariance is not positive")
        if prior_projection_hits.any():
            propagated_covariance = _synchronize_boundary_covariance(
                propagated_covariance, prior_projection_hits)
            cross_covariance = cross_covariance.clone()
            cross_covariance[prior_projection_hits] = 0.0

        prediction[day] = float(discharge_mean.detach().cpu())
        prior_state[day] = projected_prior_mean.detach().cpu().numpy()
        prior_covariance_values[day] = propagated_covariance.detach().cpu().numpy()
        cross_values[day] = cross_covariance.detach().cpu().numpy()

        if np.isfinite(observation_values[day]):
            gain = cross_covariance / innovation_variance
            gain = torch.where(allowed, gain, torch.zeros_like(gain))
            raw_posterior_mean = projected_prior_mean + gain * (
                float(observation_values[day]) - discharge_mean)
            projected_posterior_mean = _project_vector(model, raw_posterior_mean)
            posterior_projection_hits = projected_posterior_mean != raw_posterior_mean
            posterior_covariance = constrained_covariance_update(
                propagated_covariance,
                cross_covariance[:, None],
                innovation_variance.reshape(1, 1),
                gain[:, None],
            )
            posterior_covariance = _stable_covariance(posterior_covariance)
            if posterior_projection_hits.any():
                posterior_covariance = _synchronize_boundary_covariance(
                    posterior_covariance, posterior_projection_hits)
            day_correction = projected_posterior_mean - projected_prior_mean
        else:
            gain = torch.zeros(dimension, dtype=torch.float64, device=device)
            projected_posterior_mean = projected_prior_mean
            posterior_covariance = propagated_covariance
            posterior_projection_hits = torch.zeros(
                dimension, dtype=torch.bool, device=device)
            day_correction = torch.zeros_like(projected_prior_mean)

        if torch.any(day_correction[~allowed] != 0.0):
            raise RuntimeError("a disabled state channel received a correction")
        gain_values[day] = gain.detach().cpu().numpy()
        correction[day] = day_correction.detach().cpu().numpy()
        posterior_state[day] = projected_posterior_mean.detach().cpu().numpy()
        posterior_covariance_values[day] = posterior_covariance.detach().cpu().numpy()
        projection_clips[day] = (
            prior_projection_hits | posterior_projection_hits).detach().cpu().numpy()
        boundary_hits[day] = (
            _state_boundary_hits(model, projected_prior_mean)
            | _state_boundary_hits(model, projected_posterior_mean)
        ).detach().cpu().numpy()
        mean = projected_posterior_mean.detach()
        covariance = posterior_covariance.detach()

    return {
        "prediction": prediction,
        "prior_state": prior_state,
        "posterior_state": posterior_state,
        "correction": correction,
        "gain": gain_values,
        "cross_covariance": cross_values,
        "boundary_hits": boundary_hits,
        "projection_clips": projection_clips,
        "prior_covariance": prior_covariance_values,
        "posterior_covariance": posterior_covariance_values,
    }


INVERSE_MAX_ITER = 12
INVERSE_MAX_NORMALIZED_STEP = 5.0
INVERSE_LINE_SEARCH = (1.0, 0.5, 0.25, 0.125, 0.0625)


def _clip_normalized_step(
    normalized: torch.Tensor,
    allowed: torch.Tensor,
    maximum: float,
) -> torch.Tensor:
    restricted = torch.where(allowed, normalized, torch.zeros_like(normalized))
    norm = torch.linalg.vector_norm(restricted)
    if norm > maximum:
        restricted = restricted * (maximum / norm)
    return restricted


def _state_boundary_hits(model, state: torch.Tensor) -> torch.Tensor:
    lower = torch.as_tensor(
        model.lower_bounds, dtype=state.dtype, device=state.device)
    upper = torch.as_tensor(
        model.upper_bounds, dtype=state.dtype, device=state.device)
    lower_hit = torch.isclose(state, lower, rtol=0.0, atol=1e-12)
    upper_hit = torch.isfinite(upper) & torch.isclose(
        state, upper, rtol=0.0, atol=1e-12)
    return lower_hit | upper_hit


def run_causal_inverse(
    model,
    forcings: np.ndarray | Sequence,
    observations: np.ndarray | Sequence[float],
    initial_state: np.ndarray | Sequence[float],
    state_scale: np.ndarray | Sequence[float],
    mode: str,
) -> dict:
    """Run a fixed, causal current-observation inverse on the previous state.

    On day ``t`` the open prediction is emitted first.  Only then is ``obs[t]``
    used to minimally change the normalized previous persistent state, whose
    transition becomes ``posterior_state[t]``.  No future observation enters the
    inverse or the propagated state.
    """
    forcing_values, observation_values, previous_posterior = _validate_filter_inputs(
        model, forcings, observations, initial_state)
    days = forcing_values.shape[0]
    dimension = int(model.dim_x)
    device = previous_posterior.device
    scale = torch.as_tensor(state_scale, dtype=torch.float64, device=device)
    if scale.shape != (dimension,) or not torch.isfinite(scale).all() or torch.any(scale <= 0.0):
        raise ValueError("state_scale must be a positive finite scale per state channel")
    allowed = permission_mask(model, mode).to(device=device)

    prediction = np.full(days, np.nan, dtype=np.float64)
    analysis_discharge = np.full(days, np.nan, dtype=np.float64)
    analysis_error = np.full(days, np.nan, dtype=np.float64)
    prior_state = np.full((days, dimension), np.nan, dtype=np.float64)
    posterior_state = np.full((days, dimension), np.nan, dtype=np.float64)
    correction = np.zeros((days, dimension), dtype=np.float64)
    boundary_hits = np.zeros((days, dimension), dtype=bool)

    for day in range(days):
        source_state = previous_posterior.detach()
        open_state, open_discharge = model.transition(
            source_state.unsqueeze(0), tuple(forcing_values[day]))
        open_state = torch.as_tensor(
            open_state, dtype=torch.float64, device=device)[0]
        open_discharge = torch.as_tensor(
            open_discharge, dtype=torch.float64, device=device).reshape(-1)[0]
        prediction[day] = float(open_discharge.detach().cpu())
        prior_state[day] = open_state.detach().cpu().numpy()

        if np.isfinite(observation_values[day]):
            target = torch.tensor(
                float(observation_values[day]), dtype=torch.float64, device=device)
            normalized = torch.zeros(dimension, dtype=torch.float64, device=device)
            for _ in range(INVERSE_MAX_ITER):
                variable = normalized.detach().requires_grad_(True)
                raw_candidate = source_state + scale * torch.where(
                    allowed, variable, torch.zeros_like(variable))
                candidate_source = _project_vector(model, raw_candidate)
                _, candidate_discharge = model.transition(
                    candidate_source.unsqueeze(0), tuple(forcing_values[day]))
                candidate_discharge = torch.as_tensor(
                    candidate_discharge, dtype=torch.float64, device=device).reshape(-1)[0]
                residual = target - candidate_discharge
                if float(torch.abs(residual).detach().cpu()) <= 1e-10:
                    normalized = (
                        (candidate_source - source_state) / scale).detach()
                    break
                gradient = torch.autograd.grad(
                    candidate_discharge, variable, allow_unused=False)[0]
                gradient = torch.where(allowed, gradient, torch.zeros_like(gradient))
                gradient_norm_squared = torch.dot(gradient, gradient)
                if (
                    not torch.isfinite(gradient_norm_squared)
                    or float(gradient_norm_squared.detach().cpu()) <= 1e-20
                ):
                    break
                minimum_norm_step = residual.detach() * gradient.detach() / gradient_norm_squared.detach()
                old_error = float((residual.detach() * residual.detach()).cpu())
                accepted = False
                for fraction in INVERSE_LINE_SEARCH:
                    trial_normalized = _clip_normalized_step(
                        normalized + fraction * minimum_norm_step,
                        allowed,
                        INVERSE_MAX_NORMALIZED_STEP,
                    )
                    trial_raw = source_state + scale * trial_normalized
                    trial_source = _project_vector(model, trial_raw)
                    trial_normalized = torch.where(
                        allowed,
                        (trial_source - source_state) / scale,
                        torch.zeros_like(trial_normalized),
                    )
                    trial_normalized = _clip_normalized_step(
                        trial_normalized, allowed, INVERSE_MAX_NORMALIZED_STEP)
                    trial_source = _project_vector(
                        model, source_state + scale * trial_normalized)
                    with torch.no_grad():
                        _, trial_discharge = model.transition(
                            trial_source.unsqueeze(0), tuple(forcing_values[day]))
                        trial_discharge = torch.as_tensor(
                            trial_discharge,
                            dtype=torch.float64,
                            device=device,
                        ).reshape(-1)[0]
                        trial_error = float(((target - trial_discharge) ** 2).cpu())
                    if trial_error < old_error:
                        normalized = trial_normalized.detach()
                        accepted = True
                        break
                if not accepted:
                    break

            normalized = _clip_normalized_step(
                normalized, allowed, INVERSE_MAX_NORMALIZED_STEP)
            corrected_source = _project_vector(
                model, source_state + scale * normalized)
            day_correction = torch.where(
                allowed,
                corrected_source - source_state,
                torch.zeros_like(corrected_source),
            )
            corrected_source = _project_vector(model, source_state + day_correction)
            day_posterior, day_analysis_discharge = model.transition(
                corrected_source.unsqueeze(0), tuple(forcing_values[day]))
            day_posterior = torch.as_tensor(
                day_posterior, dtype=torch.float64, device=device)[0]
            day_analysis_discharge = torch.as_tensor(
                day_analysis_discharge,
                dtype=torch.float64,
                device=device,
            ).reshape(-1)[0]
            analysis_discharge[day] = float(day_analysis_discharge.detach().cpu())
            analysis_error[day] = float(
                (day_analysis_discharge - target).detach().cpu())
            boundary = _state_boundary_hits(model, corrected_source) | _state_boundary_hits(
                model, day_posterior)
        else:
            day_correction = torch.zeros(dimension, dtype=torch.float64, device=device)
            day_posterior = open_state
            analysis_discharge[day] = prediction[day]
            boundary = _state_boundary_hits(model, day_posterior)

        if torch.any(day_correction[~allowed] != 0.0):
            raise RuntimeError("a disabled state channel received an inverse correction")
        correction[day] = day_correction.detach().cpu().numpy()
        posterior_state[day] = day_posterior.detach().cpu().numpy()
        boundary_hits[day] = boundary.detach().cpu().numpy()
        previous_posterior = day_posterior.detach()

    current_state_effect = posterior_state - prior_state
    return {
        "prediction": prediction,
        "prior_state": prior_state,
        "posterior_state": posterior_state,
        "source_correction": correction,
        "current_state_effect": current_state_effect,
        "correction": correction,
        "correction_semantics": {
            "source_correction": "change applied to the pre-transition persistent state",
            "current_state_effect": "posterior_state minus prior_state after transition",
            "correction": "alias of source_correction",
        },
        "analysis_discharge": analysis_discharge,
        "analysis_error": analysis_error,
        "boundary_hits": boundary_hits,
        "settings": {
            "max_iter": INVERSE_MAX_ITER,
            "max_normalized_step": INVERSE_MAX_NORMALIZED_STEP,
            "line_search": list(INVERSE_LINE_SEARCH),
        },
    }


def prepare_basin_context(
    model,
    loaded: Mapping,
    protocol: Mapping,
    *,
    prepare_evaluation: bool = True,
) -> dict:
    """Prepare forcing-only states, training-only scales, and causal AR2 fits."""
    calibration_dates = np.asarray(loaded["calibration_dates"]).astype("datetime64[D]")
    calibration_forcing = np.asarray(loaded["calibration_forcing"], dtype=np.float64)
    calibration_observations = np.asarray(
        loaded["calibration_observations"], dtype=np.float64)
    if calibration_forcing.shape != (calibration_dates.size, 3) or calibration_observations.shape != (
            calibration_dates.size,):
        raise ValueError("calibration arrays are not aligned")
    calibration_openloop = simulate_openloop(model, calibration_forcing)
    masks = strict_calibration_masks(calibration_dates)
    after_warmup = np.arange(calibration_dates.size) >= int(
        protocol["periods"]["calibration_warmup_days"])
    scale_mask = masks["train"] & after_warmup
    state_scale = difference_p95_scale(
        calibration_openloop["state"], scale_mask,
        floor=float(protocol["scales"]["numeric_floor"]))
    observation_scale = float(difference_p95_scale(
        calibration_observations, scale_mask,
        floor=float(protocol["scales"]["numeric_floor"]))[0])
    selection_ar2_coefficients = fit_ar2(
        calibration_observations,
        calibration_openloop["prediction"],
        scale_mask,
    )
    final_fit_mask = masks["calibration"] & after_warmup
    final_ar2_coefficients = fit_ar2(
        calibration_observations,
        calibration_openloop["prediction"],
        final_fit_mask,
    )
    validation_indices = np.flatnonzero(masks["validation"])
    if validation_indices.size != 730 or validation_indices[0] < 1:
        raise ValueError("validation must be the exact final 730 calibration days")
    validation_start = int(validation_indices[0])
    context = {
        "basin_id": str(loaded["basin_id"]),
        "area_km2": float(loaded["area_km2"]),
        "state_names": np.asarray(model.state_names),
        "state_scale": state_scale,
        "observation_scale": observation_scale,
        "calibration_dates": calibration_dates,
        "calibration_forcing": calibration_forcing,
        "calibration_observations": calibration_observations,
        "calibration_openloop": calibration_openloop["prediction"],
        "calibration_state": calibration_openloop["state"],
        "calibration_scale_mask": scale_mask,
        "selection_ar2_coefficients": selection_ar2_coefficients,
        "final_ar2_coefficients": final_ar2_coefficients,
        "validation_dates": calibration_dates[validation_indices],
        "validation_forcing": calibration_forcing[validation_indices],
        "validation_observations": calibration_observations[validation_indices],
        "validation_initial_state": calibration_openloop["state"][validation_start - 1].copy(),
    }
    if prepare_evaluation:
        warmup = simulate_openloop(
            model, np.asarray(loaded["evaluation_warmup_forcing"], dtype=np.float64))
        evaluation = simulate_openloop(
            model,
            np.asarray(loaded["evaluation_forcing"], dtype=np.float64),
            warmup["final_state"],
        )
        context.update({
            "evaluation_initial_state": warmup["final_state"],
            "evaluation_dates": np.asarray(loaded["evaluation_dates"]).astype("datetime64[D]"),
            "evaluation_forcing": np.asarray(loaded["evaluation_forcing"], dtype=np.float64),
            "evaluation_observations": np.asarray(
                loaded["evaluation_observations"], dtype=np.float64),
            "evaluation_openloop": evaluation["prediction"],
            "evaluation_openloop_state": evaluation["state"],
        })
    return context


def run_training_candidate_grid(
    model,
    context: Mapping,
    protocol: Mapping,
    *,
    max_validation_days: int = 0,
) -> dict:
    """Run both permissions over the same frozen candidate grid for one training basin."""
    days = int(max_validation_days) if int(max_validation_days) > 0 else 730
    if days < 3 or days > 730:
        raise ValueError("max_validation_days must be zero or between 3 and 730")
    forcing = np.asarray(context["validation_forcing"], dtype=np.float64)[:days]
    observations = np.asarray(context["validation_observations"], dtype=np.float64)[:days]
    dates = np.asarray(context["validation_dates"]).astype("datetime64[D]")[:days]
    candidates = tuple(protocol["ukf"]["candidates"])
    candidate_ids = tuple(str(candidate["id"]) for candidate in candidates)
    losses: dict[str, dict[str, float]] = {mode: {} for mode in protocol["ukf"]["modes"]}
    predictions: dict[str, np.ndarray] = {}
    sigma = protocol["ukf"]["sigma_points"]
    for mode in protocol["ukf"]["modes"]:
        for candidate in candidates:
            covariance = build_scaled_covariances(
                model,
                context["state_scale"],
                context["observation_scale"],
                candidate,
                protocol["ukf"]["initial_variance_multiplier"],
                mode,
            )
            result = run_persistent_ukf(
                model,
                forcing,
                observations,
                context["validation_initial_state"],
                covariance["initial_covariance"],
                covariance["process_covariance"],
                covariance["observation_variance"],
                mode,
                alpha=float(sigma["alpha"]),
                beta=float(sigma["beta"]),
                kappa=float(sigma["kappa"]),
            )
            prediction = np.asarray(result["prediction"], dtype=np.float64)
            key = f"prediction_{mode}__{candidate['id']}"
            predictions[key] = prediction
            loss = normalized_squared_error(observations, prediction)
            losses[mode][str(candidate["id"])] = float(loss["normalized_squared_error"])
            del result
    return {
        "dates": dates,
        "forcing": forcing,
        "observations": observations,
        "candidate_ids": candidate_ids,
        "predictions": predictions,
        "losses": losses,
    }


def _finite_abs_summary(values: np.ndarray) -> tuple[float, float, float]:
    finite = np.abs(np.asarray(values, dtype=np.float64))
    finite = finite[np.isfinite(finite)]
    if finite.size == 0:
        return float("nan"), float("nan"), float("nan")
    return (
        float(np.median(finite)),
        float(np.percentile(finite, 95.0)),
        float(np.max(finite)),
    )


def state_diagnostic_rows(
    basin_id: str,
    method: str,
    mode: str,
    state_names: Sequence[str],
    state_scale: np.ndarray,
    correction: np.ndarray,
    current_state_effect: np.ndarray,
    boundary_hits: np.ndarray,
    next_effect: np.ndarray,
) -> list[dict]:
    """Summarize correction magnitude, persistence, boundary hits, and flow transmission."""
    names = tuple(str(name) for name in state_names)
    scale = np.asarray(state_scale, dtype=np.float64)
    update = np.asarray(correction, dtype=np.float64)
    current = np.asarray(current_state_effect, dtype=np.float64)
    boundary = np.asarray(boundary_hits, dtype=bool)
    following = np.asarray(next_effect, dtype=np.float64)
    expected = (update.shape[0], len(names))
    if update.shape != expected or current.shape != expected or boundary.shape != expected or following.shape != expected:
        raise ValueError("state diagnostic arrays must share [day, state] shape")
    rows = []
    for channel, name in enumerate(names):
        correction_summary = _finite_abs_summary(update[:, channel])
        normalized_summary = _finite_abs_summary(update[:, channel] / scale[channel])
        current_summary = _finite_abs_summary(current[:, channel])
        next_summary = _finite_abs_summary(following[:, channel])
        rows.append({
            "basin_id": str(basin_id).zfill(8),
            "method": str(method),
            "mode": str(mode),
            "state_index": channel,
            "state_name": name,
            "state_scale": float(scale[channel]),
            "correction_abs_median": correction_summary[0],
            "correction_abs_p95": correction_summary[1],
            "correction_abs_max": correction_summary[2],
            "normalized_correction_abs_median": normalized_summary[0],
            "normalized_correction_abs_p95": normalized_summary[1],
            "normalized_correction_abs_max": normalized_summary[2],
            "current_state_effect_abs_median": current_summary[0],
            "current_state_effect_abs_p95": current_summary[1],
            "current_state_effect_abs_max": current_summary[2],
            "boundary_hit_rate": float(np.mean(boundary[:, channel])),
            "next_day_flow_effect_abs_median": next_summary[0],
            "next_day_flow_effect_abs_p95": next_summary[1],
            "next_day_flow_effect_abs_max": next_summary[2],
        })
    return rows


def evaluate_holdout_basin(
    model,
    context: Mapping,
    protocol: Mapping,
    selected_candidates: Mapping[str, Mapping],
    *,
    max_eval_days: int = 0,
) -> dict:
    """Evaluate all legal predictors on one holdout basin using frozen shared candidates."""
    formal_days = int(protocol["periods"]["evaluation"]["days"])
    days = int(max_eval_days) if int(max_eval_days) > 0 else formal_days
    if days < 3 or days > formal_days:
        raise ValueError("max_eval_days must be zero or between 3 and the formal evaluation length")
    dates = np.asarray(context["evaluation_dates"]).astype("datetime64[D]")[:days]
    forcing = np.asarray(context["evaluation_forcing"], dtype=np.float64)[:days]
    observations = np.asarray(context["evaluation_observations"], dtype=np.float64)[:days]
    openloop = np.asarray(context["evaluation_openloop"], dtype=np.float64)[:days]
    ar2 = causal_ar2_predictions(observations, openloop, context["final_ar2_coefficients"])
    predictions = {"openloop": openloop, "ar2": ar2}
    method_results: dict[str, dict] = {}
    state_rows: list[dict] = []
    sigma = protocol["ukf"]["sigma_points"]
    candidate_lookup = {str(row["id"]): row for row in protocol["ukf"]["candidates"]}

    for mode in protocol["ukf"]["modes"]:
        selected_id = str(selected_candidates[mode]["selected_id"])
        if selected_id not in candidate_lookup:
            raise ValueError(f"selected candidate {selected_id} is outside the frozen grid")
        covariance = build_scaled_covariances(
            model,
            context["state_scale"],
            context["observation_scale"],
            candidate_lookup[selected_id],
            protocol["ukf"]["initial_variance_multiplier"],
            mode,
        )
        ukf_result = run_persistent_ukf(
            model,
            forcing,
            observations,
            context["evaluation_initial_state"],
            covariance["initial_covariance"],
            covariance["process_covariance"],
            covariance["observation_variance"],
            mode,
            alpha=float(sigma["alpha"]),
            beta=float(sigma["beta"]),
            kappa=float(sigma["kappa"]),
        )
        ukf_name = f"ukf_{mode}"
        predictions[ukf_name] = ukf_result["prediction"]
        ukf_next = isolated_next_day_effect(
            model, ukf_result["prior_state"], ukf_result["correction"], forcing)
        method_results[ukf_name] = {
            "prior_state": ukf_result["prior_state"],
            "posterior_state": ukf_result["posterior_state"],
            "correction": ukf_result["correction"],
            "current_state_effect": ukf_result["correction"],
            "boundary_hits": ukf_result["boundary_hits"],
            "projection_clips": ukf_result["projection_clips"],
            "next_effect": ukf_next,
        }
        state_rows.extend(state_diagnostic_rows(
            context["basin_id"], "ukf", mode, context["state_names"],
            context["state_scale"], ukf_result["correction"], ukf_result["correction"],
            ukf_result["boundary_hits"], ukf_next))
        del ukf_result

        inverse_result = run_causal_inverse(
            model,
            forcing,
            observations,
            context["evaluation_initial_state"],
            context["state_scale"],
            mode,
        )
        inverse_name = f"inverse_{mode}"
        predictions[inverse_name] = inverse_result["prediction"]
        inverse_next = isolated_next_day_effect(
            model,
            inverse_result["prior_state"],
            inverse_result["current_state_effect"],
            forcing,
        )
        method_results[inverse_name] = {
            "prior_state": inverse_result["prior_state"],
            "posterior_state": inverse_result["posterior_state"],
            "correction": inverse_result["source_correction"],
            "current_state_effect": inverse_result["current_state_effect"],
            "boundary_hits": inverse_result["boundary_hits"],
            "next_effect": inverse_next,
        }
        state_rows.extend(state_diagnostic_rows(
            context["basin_id"], "inverse", mode, context["state_names"],
            context["state_scale"], inverse_result["source_correction"],
            inverse_result["current_state_effect"], inverse_result["boundary_hits"],
            inverse_next))
        del inverse_result

    scores = common_mask_scores(observations, predictions)
    expected_common_days = days - 2
    if int(scores["n"]) != expected_common_days:
        raise ValueError(
            f"common AR2 scoring mask has {scores['n']} days, expected {expected_common_days}")
    return {
        "dates": dates,
        "forcing": forcing,
        "observations": observations,
        "predictions": predictions,
        "method_results": method_results,
        "common_mask": scores["mask"],
        "scores": scores["scores"],
        "score_denominator": scores["denominator"],
        "score_days": scores["n"],
        "state_rows": state_rows,
    }


def _json_ready(value):
    if isinstance(value, Mapping):
        return {str(key): _json_ready(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_ready(item) for item in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, Path):
        return str(value)
    return value


def _write_json(path: str | Path, payload) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(_json_ready(payload), indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def _write_csv(path: str | Path, rows: Sequence[Mapping]) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        raise ValueError(f"cannot write empty table {destination}")
    columns = []
    for row in rows:
        for key in row:
            if key not in columns:
                columns.append(key)
    with destination.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction="raise")
        writer.writeheader()
        writer.writerows(rows)


def _basin_input_files(data_root: str | Path, basin_id: str) -> tuple[Path, ...]:
    root = Path(data_root)
    normalized = str(basin_id).zfill(8)
    forcing = list((root / "basin_mean_forcing" / "maurer").glob(
        f"*/{normalized}_lump_maurer_forcing_leap.txt"))
    streamflow = list((root / "usgs_streamflow").glob(
        f"*/{normalized}_streamflow_qc.txt"))
    if len(forcing) != 1 or len(streamflow) != 1:
        raise FileNotFoundError(
            f"expected exactly one forcing and streamflow file for basin {normalized}")
    area = root / "camels_attributes_v2.0" / "camels_topo.txt"
    if not area.is_file():
        raise FileNotFoundError(f"missing basin-area file {area}")
    return forcing[0], streamflow[0], area


def _verify_source_hashes(protocol: Mapping) -> list[dict[str, str]]:
    pairs = (
        ("parameter_csv", Path(protocol["data"]["parameter_csv"])),
        ("canonical_basin_list", Path(protocol["data"]["canonical_basin_list"])),
        ("loader_source", Path(protocol["data"]["loader_source"])),
    )
    rows = []
    for key, path in pairs:
        actual = _sha256(path)
        expected = str(protocol["hashing"][key])
        if actual != expected:
            raise ValueError(f"frozen source hash changed for {key}: {actual} != {expected}")
        rows.append({"role": key, "path": str(path), "sha256": actual})
    return rows


def runtime_code_paths(protocol: Mapping, project_root: str | Path) -> tuple[Path, ...]:
    """Return the complete directly imported model and data-loader code chain."""
    root = Path(project_root).resolve()
    external_source = Path(protocol["data"]["neuralhydrology_root"]).resolve() / "src"
    paths = (
        Path(__file__).resolve(),
        root / "src" / "global_hydrology" / "models" / "aligned_gr4j_pdd.py",
        root / "src" / "global_hydrology" / "models" / "differentiable_gr4j_pdd.py",
        external_source / "xaj_global_pilot" / "gr4j_core.py",
        external_source / "xaj_global_pilot" / "pdd_core.py",
        Path(protocol["data"]["loader_source"]).resolve(),
    )
    missing = [path for path in paths if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"runtime code manifest is missing {missing}")
    if len(set(paths)) != len(paths):
        raise ValueError("runtime code manifest contains duplicate paths")
    return paths


def _load_runtime_dependencies(protocol: Mapping):
    project_root = Path(__file__).resolve().parents[1]
    external_source = Path(protocol["data"]["neuralhydrology_root"]) / "src"
    project_source = project_root / "src"
    for source in (external_source, project_source):
        if str(source) not in sys.path:
            sys.path.insert(0, str(source))
    from global_hydrology.models.aligned_gr4j_pdd import AlignedGR4JPDD
    from global_hydrology.models.differentiable_gr4j_pdd import PARAM_NAMES
    from hydroagent.data_loading import load_camels_basin
    if tuple(PARAM_NAMES) != PARAMETER_NAMES:
        raise ValueError("runtime GR4J-PDD parameter order changed")
    return AlignedGR4JPDD, load_camels_basin


def _write_output_manifest(output_root: Path) -> Path:
    destination = output_root / "manifest.sha256"
    files = sorted(
        path for path in output_root.rglob("*")
        if path.is_file() and path.resolve() != destination.resolve())
    lines = [f"{_sha256(path)}  {path.relative_to(output_root).as_posix()}" for path in files]
    destination.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return destination


def run_formal_driver(
    config_path: str | Path,
    *,
    smoke: bool = False,
    output_override: str | Path | None = None,
) -> dict:
    """Run the frozen shared-selection and holdout audit, writing each basin immediately."""
    project_root = Path(__file__).resolve().parents[1]
    protocol = load_frozen_protocol(config_path)
    configured_output = protocol["outputs"]["smoke_root" if smoke else "formal_root"]
    output_root = Path(output_override or configured_output)
    if not output_root.is_absolute():
        output_root = project_root / output_root
    output_root = output_root.resolve()
    try:
        output_root.relative_to(project_root.resolve())
    except ValueError as error:
        raise ValueError("output must stay inside the kalmannet working directory") from error
    if output_root.exists() and any(output_root.iterdir()):
        raise FileExistsError(f"refusing to overwrite non-empty output directory {output_root}")
    output_root.mkdir(parents=True, exist_ok=True)
    shutil.copy2(Path(config_path), output_root / "frozen_config.json")

    source_rows = _verify_source_hashes(protocol)
    model_class, load_camels_basin = _load_runtime_dependencies(protocol)
    prior = load_parameter_only_prior(
        protocol["data"]["parameter_csv"],
        protocol["data"]["canonical_basin_list"],
        PARAMETER_NAMES,
    )
    structural_certificates = {}
    for basin_id in TRAINING_BASINS + HOLDOUT_BASINS:
        structural_model = model_class(prior.params_for_basin(basin_id))
        structural_certificates[basin_id] = certify_full_state_reachable_envelope(
            structural_model)
    certificate_statuses = {
        row["certificate_status"] for row in structural_certificates.values()
    }
    reason_codes = {row["reason_code"] for row in structural_certificates.values()}
    if certificate_statuses != {"certified_unbounded"} or reason_codes != {
            "unbounded_lag1_routing_queue"}:
        raise ValueError("the frozen basin set does not share one certified-unbounded state contract")
    first_certificate = dict(structural_certificates[TRAINING_BASINS[0]])
    reachable_certificate = {
        **first_certificate,
        "basin_count_checked": len(structural_certificates),
        "basin_ids_checked": list(structural_certificates),
        "all_basins_same_status": True,
    }
    gate_decision = gate_decision_from_certificate(
        reachable_certificate,
        threshold=float(protocol["gate"]["paired_median_margin"]),
    )
    training_basins = TRAINING_BASINS[:1] if smoke else TRAINING_BASINS
    holdout_basins = HOLDOUT_BASINS[:1] if smoke else HOLDOUT_BASINS
    max_validation_days = 30 if smoke else 0
    max_eval_days = 30 if smoke else 0
    candidate_order = tuple(row["id"] for row in protocol["ukf"]["candidates"])
    losses_by_mode = {
        mode: {} for mode in protocol["ukf"]["modes"]
    }
    input_paths: set[Path] = set()
    daily_artifacts = []

    for basin_id in training_basins:
        loaded = load_basin_arrays(load_camels_basin, basin_id, protocol)
        model = model_class(prior.params_for_basin(basin_id))
        context = prepare_basin_context(model, loaded, protocol, prepare_evaluation=False)
        grid = run_training_candidate_grid(
            model, context, protocol, max_validation_days=max_validation_days)
        payload = {
            "dates": grid["dates"],
            "forcing": grid["forcing"],
            "area_km2": context["area_km2"],
            "observed_mm_per_day": grid["observations"],
            "state_names": context["state_names"],
            "state_scale": context["state_scale"],
            "observation_scale": context["observation_scale"],
            **grid["predictions"],
        }
        daily_artifacts.append(write_daily_npz(
            output_root / "validation" / f"{basin_id}.npz", payload,
            loader_cfs_factor=protocol["data"]["loader_cfs_to_mm_day_km2_factor"]))
        for mode in protocol["ukf"]["modes"]:
            losses_by_mode[mode][basin_id] = grid["losses"][mode]
        input_paths.update(_basin_input_files(protocol["data"]["camels_us_root"], basin_id))
        del grid, context, model, loaded

    selected = {}
    selection_rows = []
    for mode in protocol["ukf"]["modes"]:
        selected[mode] = select_shared_candidate(
            losses_by_mode[mode], candidate_order, training_basins)
        for basin_id in training_basins:
            for candidate_id in candidate_order:
                selection_rows.append({
                    "basin_id": basin_id,
                    "mode": mode,
                    "candidate_id": candidate_id,
                    "normalized_squared_error": losses_by_mode[mode][basin_id][candidate_id],
                    "candidate_mean_normalized_squared_error": selected[mode][
                        "mean_normalized_squared_error"][candidate_id],
                    "selected": candidate_id == selected[mode]["selected_id"],
                })
    _write_json(output_root / "selection.json", selected)
    _write_csv(output_root / "selection.csv", selection_rows)

    basin_rows = []
    all_state_rows = []
    for basin_id in holdout_basins:
        loaded = load_basin_arrays(load_camels_basin, basin_id, protocol)
        model = model_class(prior.params_for_basin(basin_id))
        context = prepare_basin_context(model, loaded, protocol, prepare_evaluation=True)
        calibration_payload = {
            "dates": context["calibration_dates"],
            "forcing": context["calibration_forcing"],
            "area_km2": context["area_km2"],
            "observed_mm_per_day": context["calibration_observations"],
            "openloop": context["calibration_openloop"],
            "openloop_state": context["calibration_state"],
            "state_names": context["state_names"],
            "state_scale": context["state_scale"],
            "observation_scale": context["observation_scale"],
            "ar2_coefficients": context["final_ar2_coefficients"],
            "training_scale_mask": context["calibration_scale_mask"],
        }
        daily_artifacts.append(write_daily_npz(
            output_root / "calibration" / f"{basin_id}.npz", calibration_payload,
            loader_cfs_factor=protocol["data"]["loader_cfs_to_mm_day_km2_factor"]))

        evaluation = evaluate_holdout_basin(
            model, context, protocol, selected, max_eval_days=max_eval_days)
        evaluation_payload = {
            "dates": evaluation["dates"],
            "forcing": evaluation["forcing"],
            "area_km2": context["area_km2"],
            "observed_mm_per_day": evaluation["observations"],
            "common_mask": evaluation["common_mask"],
            "state_names": context["state_names"],
            "state_scale": context["state_scale"],
            "observation_scale": context["observation_scale"],
            "ar2_coefficients": context["final_ar2_coefficients"],
        }
        for name, prediction in evaluation["predictions"].items():
            evaluation_payload[f"prediction_{name}"] = prediction
        for name, result in evaluation["method_results"].items():
            for field, values in result.items():
                evaluation_payload[f"{name}_{field}"] = values
        daily_artifacts.append(write_daily_npz(
            output_root / "evaluation" / f"{basin_id}.npz", evaluation_payload,
            loader_cfs_factor=protocol["data"]["loader_cfs_to_mm_day_km2_factor"]))
        row = {
            "basin_id": basin_id,
            "area_km2": context["area_km2"],
            "common_days": evaluation["score_days"],
            "common_nse_denominator": evaluation["score_denominator"],
            **{f"nse_{name}": score for name, score in evaluation["scores"].items()},
        }
        for name, score in evaluation["scores"].items():
            if name != "ar2":
                row[f"paired_difference_{name}_minus_ar2"] = score - evaluation["scores"]["ar2"]
        basin_rows.append(row)
        all_state_rows.extend(evaluation["state_rows"])
        input_paths.update(_basin_input_files(protocol["data"]["camels_us_root"], basin_id))
        del evaluation, context, model, loaded

    _write_csv(output_root / "per_basin.csv", basin_rows)
    _write_csv(output_root / "per_state.csv", all_state_rows)
    method_names = [key[4:] for key in basin_rows[0] if key.startswith("nse_")]
    ar2_scores = np.asarray([row["nse_ar2"] for row in basin_rows], dtype=np.float64)
    paired = {}
    for method in method_names:
        if method == "ar2":
            continue
        paired[method] = paired_summary(
            np.asarray([row[f"nse_{method}"] for row in basin_rows], dtype=np.float64),
            ar2_scores,
        )
    main_result = {
        "schema_version": protocol["schema_version"],
        "formal_protocol": not smoke,
        "training_basin_count": len(training_basins),
        "holdout_basin_count": len(holdout_basins),
        "validation_days": 30 if smoke else 730,
        "evaluation_days": 30 if smoke else 3652,
        "common_ar2_score_days_per_complete_basin": 28 if smoke else 3650,
        "selected_shared_candidates": selected,
        "paired_against_ar2": paired,
        "gate_threshold": protocol["gate"]["paired_median_margin"],
        "reachable_set_certificate": reachable_certificate,
        "gate_decision": gate_decision,
        "legal_inverse_and_ukf_are_not_theoretical_upper_bounds": True,
    }
    _write_json(output_root / "main_result.json", main_result)
    _write_json(output_root / "reachable_set_certificate.json", {
        "certificate": reachable_certificate,
        "gate_decision": gate_decision,
    })

    project_inputs = [Path(config_path).resolve(), *runtime_code_paths(protocol, project_root)]
    input_manifest_by_path = {
        Path(row["path"]).resolve(): dict(row) for row in source_rows
    }
    for path in sorted(set(project_inputs) | input_paths, key=lambda value: str(value)):
        resolved = Path(path).resolve()
        if resolved not in input_manifest_by_path:
            input_manifest_by_path[resolved] = {
                "role": "runtime_input_or_code",
                "path": str(resolved),
                "sha256": _sha256(resolved),
            }
    input_manifest_rows = [
        input_manifest_by_path[path] for path in sorted(
            input_manifest_by_path, key=lambda value: str(value))
    ]
    _write_json(output_root / "input_manifest.json", {
        "hash_algorithm": "sha256",
        "parameter_columns_read": protocol["data"]["parameter_projection"],
        "forbidden_parameter_columns_read": [],
        "raw_forcing_columns": ["prcp", "tmean", "ep"],
        "snow_liquid_preprocessing_called": False,
        "files": input_manifest_rows,
    })
    _write_json(output_root / "environment.json", {
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "torch": torch.__version__,
        "command": protocol["reproduction"]["smoke_command" if smoke else "formal_command"],
        "output_root": str(output_root),
        "write_and_release_per_basin": True,
    })
    _write_json(output_root / "daily_artifacts.json", daily_artifacts)
    manifest_path = _write_output_manifest(output_root)
    return {
        "output_root": str(output_root),
        "manifest": str(manifest_path),
        "main_result": main_result,
    }


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Frozen legal one-day-ahead GR4J-PDD data-assimilation audit")
    parser.add_argument(
        "--config", default="configs/aligned_gr4j_da_v1.json",
        help="frozen protocol JSON")
    parser.add_argument(
        "--smoke", action="store_true",
        help="run one training and one holdout basin over 30 scoring days; invalid for gate claims")
    parser.add_argument(
        "--output", default=None,
        help="optional output path inside the kalmannet repository")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_argument_parser().parse_args(argv)
    result = run_formal_driver(args.config, smoke=bool(args.smoke), output_override=args.output)
    print(json.dumps(_json_ready(result), indent=2, sort_keys=True))
    return 0


__all__ = [
    "build_scaled_covariances",
    "certify_full_state_reachable_envelope",
    "causal_ar2_predictions",
    "common_mask_scores",
    "constrained_covariance_update",
    "difference_p95_scale",
    "fit_ar2",
    "gate_decision_from_certificate",
    "isolated_next_day_effect",
    "load_basin_arrays",
    "load_frozen_protocol",
    "load_parameter_only_prior",
    "merwe_sigma_points",
    "paired_summary",
    "permission_mask",
    "run_causal_inverse",
    "run_formal_driver",
    "run_persistent_ukf",
    "runtime_code_paths",
    "select_shared_candidate",
    "simulate_openloop",
    "strict_calibration_masks",
    "write_daily_npz",
]


if __name__ == "__main__":
    raise SystemExit(main())
