"""Frozen common primitives for the TUKF11 synthetic joint-learning gate.

The hidden truth transition is intentionally isolated from the trainable
PyTorch HBV-light adapter.  It calls the external NumPy implementation one day
at a time, then applies the registered stochastic increment and projection.
PyTorch is used to create the forcing because the frozen 128-day byte anchor
was generated with ``torch.pi``/``torch.sin`` rather than NumPy trigonometry.
"""
from __future__ import annotations

from collections.abc import Mapping, Sequence
import hashlib
import importlib
import json
import math
from pathlib import Path
import sys
from typing import Any

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

EXPERIMENT_ID = "TUKF11_HBV_JOINT_PARAMETER_SYNTHETIC_MECHANISM_GATE_V1"
DEFAULT_CONFIG = (
    ROOT / "configs" / "tukf11_hbv_joint_parameter_synthetic_mechanism_gate_v1.json"
)
EXTERNAL_NUMPY_TRUTH_PATH = Path(
    "G:/github/pycharm/projects/neuralhydrology/src/scl_hydro/hbv_lite_numpy.py"
)
TRUTH_SEEDS = (211, 307, 401)
START_IDS = ("start_00", "start_01", "start_02")
FROZEN_CONFIG_SHA256 = "3f370beee3f41b217e0820c46faf2879c69b3f5c267841c9efafbc356c148244"
FORCING_128_SHA256 = "1b5a92901896a3108eafd74d9b1913a65aae7615f169a87a92ddb26576aab5c3"

HASHED_SOURCE_FILES = (
    "configs/tukf11_hbv_joint_parameter_synthetic_mechanism_gate_v1.json",
    "scripts/tukf11_hbv_joint_parameter_synthetic_common.py",
    "scripts/run_tukf11_hbv_joint_parameter_synthetic_mechanism_gate.py",
    "scripts/verify_tukf11_hbv_joint_parameter_synthetic_mechanism_gate.py",
    "tests/test_tukf11_hbv_joint_parameter_synthetic_mechanism_gate.py",
    "src/global_hydrology/models/trainable_hbvlite_ukf_adapter.py",
    "scripts/tukf10_joint_hbv_physical_filter_common.py",
    "scripts/differentiable_ukf_hbvlite.py",
    "src/global_hydrology/models/differentiable_hbv_lite.py",
    "scripts/run_aligned_gr4j_da.py",
    "scripts/run_aligned_gr4j_differentiable_ukf.py",
    "src/global_hydrology/assimilation/conventional_ukf.py",
    "G:/github/pycharm/projects/neuralhydrology/src/scl_hydro/hbv_lite_numpy.py",
)

EXPECTED_OPTIMIZER = {
    "name": "Adam",
    "hydrology_learning_rate": 0.005,
    "filter_learning_rate": 0.05,
    "group_gradient_norm": 1.0,
    "updates": 32,
    "selection_interval": 4,
}
EXPECTED_SEGMENTS = {
    "days": 192,
    "warmup_target_start": 28,
    "train_target_start": 28,
    "train_target_end_exclusive": 108,
    "selection_target_start": 108,
    "selection_target_end_exclusive": 148,
    "test_target_start": 148,
    "test_target_end_exclusive": 192,
}
EXPECTED_PROCESS_TRUTH = [0.04, 0.025, 0.05, 0.05, 0.03, 0.04, 0.025, 0.015]


def sha256_file(path: Path | str) -> str:
    """Return the SHA-256 of one file without following any manifest indirection."""

    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_array(array: np.ndarray) -> str:
    """Hash the raw bytes of a C-contiguous array (the frozen forcing convention)."""

    value = np.ascontiguousarray(np.asarray(array))
    return hashlib.sha256(value.tobytes()).hexdigest()


def sha256_arrays(arrays: Mapping[str, np.ndarray]) -> str:
    """Hash named arrays including name, dtype, shape, and C-contiguous bytes."""

    digest = hashlib.sha256()
    for name in sorted(arrays):
        value = np.ascontiguousarray(np.asarray(arrays[name]))
        digest.update(str(name).encode("utf-8"))
        digest.update(str(value.dtype).encode("ascii"))
        digest.update(np.asarray(value.shape, dtype=np.int64).tobytes())
        digest.update(value.tobytes())
    return digest.hexdigest()


def resolve_dependency_path(path: str | Path) -> Path:
    """Resolve a registered repository-relative or external absolute dependency."""

    value = Path(path)
    return value.resolve() if value.is_absolute() else (ROOT / value).resolve()


def source_hashes(contract: Mapping[str, Any]) -> dict[str, str]:
    """Hash the complete registered dependency closure; missing members hard-stop."""

    result: dict[str, str] = {}
    for name in contract["code_and_input_files_to_hash"]:
        path = resolve_dependency_path(name)
        if not path.is_file():
            raise FileNotFoundError(f"registered dependency is missing: {path}")
        result[str(name)] = sha256_file(path)
    return result


def resolve_output_path(relative: str | Path, allowed_root: Path) -> Path:
    """Resolve one output and reject absolute/path-traversal escapes."""

    root = Path(allowed_root).resolve()
    value = Path(relative)
    candidate = value.resolve() if value.is_absolute() else (root / value).resolve()
    try:
        candidate.relative_to(root)
    except ValueError as error:
        raise ValueError(f"output path escapes allowed root: {candidate}") from error
    return candidate


def load_contract(path: Path = DEFAULT_CONFIG) -> dict[str, Any]:
    """Load the single frozen TUKF11 contract and reject semantic or byte drift."""

    selected = Path(path)
    contract = json.loads(selected.read_text(encoding="utf-8"))
    if contract.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("TUKF11 experiment identifier changed")
    if contract.get("mode") != "joint_only":
        raise ValueError("TUKF11 is a joint-only mechanism gate")
    if contract.get("truth_seeds") != list(TRUTH_SEEDS):
        raise ValueError("truth seeds changed")
    if contract.get("start_ids") != list(START_IDS):
        raise ValueError("start identifiers changed")
    if contract.get("optimizer") != EXPECTED_OPTIMIZER:
        raise ValueError("optimizer or budget changed")
    if contract.get("segments") != EXPECTED_SEGMENTS:
        raise ValueError("causal target segments changed")
    if contract.get("truth", {}).get("process_nominal_variances") != EXPECTED_PROCESS_TRUTH:
        raise ValueError("nominal process-variance truth changed")
    if contract.get("code_and_input_files_to_hash") != list(HASHED_SOURCE_FILES):
        raise ValueError("hashed dependency closure changed")

    frozen_dependencies = contract.get("frozen_dependency_sha256")
    expected_frozen_names = set(HASHED_SOURCE_FILES[5:])
    if not isinstance(frozen_dependencies, dict) or set(frozen_dependencies) != expected_frozen_names:
        raise ValueError("frozen dependency SHA-256 registry changed")
    for name in HASHED_SOURCE_FILES[5:]:
        recorded = frozen_dependencies[name]
        if not isinstance(recorded, str) or len(recorded) != 64:
            raise ValueError(f"invalid frozen dependency SHA-256 for {name}")
        current = sha256_file(resolve_dependency_path(name))
        if current != recorded:
            raise ValueError(f"frozen dependency bytes changed: {name}")

    canonical = json.loads(DEFAULT_CONFIG.read_text(encoding="utf-8"))
    if contract != canonical:
        raise ValueError("one or more frozen TUKF11 contract fields changed")
    if selected.resolve() == DEFAULT_CONFIG.resolve() and sha256_file(selected) != FROZEN_CONFIG_SHA256:
        raise ValueError("frozen TUKF11 config bytes changed")

    from global_hydrology.models.differentiable_hbv_lite import PARAM_NAMES
    from global_hydrology.models.trainable_hbvlite_ukf_adapter import (
        HBV_LITE_V5_PARAMETER_BOUNDS,
        TRAINABLE_HYDROLOGY_PARAMETER_NAMES,
    )

    truth = contract["truth"]
    if truth["parameter_names"] != list(PARAM_NAMES):
        raise ValueError("HBV-light parameter order changed")
    if truth["trainable_hydrology_names"] != list(TRAINABLE_HYDROLOGY_PARAMETER_NAMES):
        raise ValueError("trainable hydrology parameter set changed")
    expected_bounds = {
        name: list(HBV_LITE_V5_PARAMETER_BOUNDS[name]) for name in PARAM_NAMES
    }
    if truth["hydrology_v5_bounds"] != expected_bounds:
        raise ValueError("fifth-version hydrology bounds changed")
    return contract


def build_forcing(days: int) -> np.ndarray:
    """Build the frozen forcing with PyTorch float64 byte semantics."""

    if isinstance(days, bool) or int(days) != days or int(days) < 1:
        raise ValueError("forcing day count must be a positive integer")
    t = torch.arange(int(days), dtype=torch.float64, device=torch.device("cpu"))
    temperature = 1.0 + 8.0 * torch.sin(2.0 * torch.pi * (t - 80.0) / 365.0)
    integer_t = t.to(torch.int64)
    precipitation = torch.where(
        integer_t % 9 == 0,
        torch.tensor(18.0, dtype=torch.float64),
        torch.where(
            integer_t % 4 == 0,
            torch.tensor(3.0, dtype=torch.float64),
            torch.tensor(0.0, dtype=torch.float64),
        ),
    )
    potential_evapotranspiration = torch.clamp(
        1.5 + 1.2 * torch.sin(2.0 * torch.pi * (t - 30.0) / 365.0), min=0.1
    )
    forcing = torch.stack(
        (precipitation, temperature, potential_evapotranspiration), dim=-1
    )
    return np.ascontiguousarray(forcing.detach().cpu().numpy(), dtype=np.float64)


def routing_weights_numpy(length: int) -> np.ndarray:
    """Newest-to-oldest recession-half routing weights in independent NumPy."""

    if isinstance(length, bool) or int(length) != length or int(length) < 1:
        raise ValueError("routing length must be a positive integer")
    raw = np.arange(int(length), 0, -1, dtype=np.float64)
    return np.ascontiguousarray(raw / raw.sum())


def sample_self_consistent_observation(
    clean_discharge: np.ndarray,
    standard_normal: np.ndarray,
    ratio: float,
    base_variance: float,
    denominator_margin: float,
) -> tuple[np.ndarray, dict[str, Any]]:
    """Solve the registered observation-scale fixed point exactly by branch."""

    q = np.ascontiguousarray(np.asarray(clean_discharge, dtype=np.float64))
    z = np.ascontiguousarray(np.asarray(standard_normal, dtype=np.float64))
    if q.ndim != 1 or z.shape != q.shape:
        raise ValueError("clean discharge and observation normals must be equal 1-D arrays")
    if not np.isfinite(q).all() or np.any(q < 0.0) or not np.isfinite(z).all():
        raise ValueError("observation fixed-point inputs must be finite and discharge nonnegative")
    ratio = float(ratio)
    base_variance = float(base_variance)
    denominator_margin = float(denominator_margin)
    if not math.isfinite(ratio) or ratio <= 0.0:
        raise ValueError("observation ratio must be finite and positive")
    if not math.isfinite(base_variance) or base_variance <= 0.0:
        raise ValueError("base observation variance must be finite and positive")
    if not math.isfinite(denominator_margin) or denominator_margin <= 0.0:
        raise ValueError("denominator margin must be finite and positive")

    base_scale = math.sqrt(base_variance)
    observation = np.empty_like(q)
    negative = z <= 0.0
    observation[negative] = q[negative] + z[negative] * np.maximum(
        base_scale, ratio * q[negative]
    )

    positive_indices = np.flatnonzero(~negative)
    candidate = q[positive_indices] + z[positive_indices] * base_scale
    floor_branch = ratio * candidate <= base_scale
    observation[positive_indices[floor_branch]] = candidate[floor_branch]
    proportional_indices = positive_indices[~floor_branch]
    denominator = 1.0 - ratio * z[proportional_indices]
    if np.any(denominator <= denominator_margin):
        raise ValueError("self-consistent observation denominator failed")
    observation[proportional_indices] = q[proportional_indices] / denominator

    scale = np.sqrt(
        np.maximum(
            base_variance,
            (ratio * np.maximum.reduce((q, observation, np.zeros_like(q)))) ** 2,
        )
    )
    standardized = (observation - q) / scale
    fixed_point_error = np.abs(standardized - z)
    proportional = ratio * np.maximum.reduce((q, observation, np.zeros_like(q))) > base_scale
    branch_codes = np.where(
        negative,
        np.where(proportional, 1, 0),
        np.where(proportional, 3, 2),
    ).astype(np.int8)
    minimum_denominator = float(np.min(denominator)) if denominator.size else 1.0
    diagnostics: dict[str, Any] = {
        "branch_codes": np.ascontiguousarray(branch_codes),
        "standardized_residual": np.ascontiguousarray(standardized),
        "scale": np.ascontiguousarray(scale),
        "fixed_point_max_absolute_error": float(np.max(fixed_point_error, initial=0.0)),
        "maximum_standardized_residual_error": float(
            np.max(fixed_point_error, initial=0.0)
        ),
        "minimum_positive_proportional_denominator": minimum_denominator,
        "proportional_branch_fraction": float(np.mean(proportional)) if q.size else 0.0,
        "branch_counts": {
            "negative_floor": int(np.count_nonzero(branch_codes == 0)),
            "negative_proportional": int(np.count_nonzero(branch_codes == 1)),
            "positive_floor": int(np.count_nonzero(branch_codes == 2)),
            "positive_proportional": int(np.count_nonzero(branch_codes == 3)),
        },
    }
    if not np.isfinite(observation).all() or not np.isfinite(scale).all():
        raise FloatingPointError("self-consistent observations are non-finite")
    return np.ascontiguousarray(observation), diagnostics


def _load_external_numpy_truth(path: Path):
    selected = Path(path).resolve()
    if not selected.is_file():
        raise FileNotFoundError(f"external NumPy HBV-light model is missing: {selected}")
    external_src = selected.parents[1]
    if str(external_src) not in sys.path:
        sys.path.insert(0, str(external_src))
    module = importlib.import_module("scl_hydro.hbv_lite_numpy")
    loaded_path = Path(module.__file__).resolve()
    if loaded_path != selected:
        raise ImportError(
            "imported scl_hydro.hbv_lite_numpy does not match the frozen external path: "
            f"{loaded_path} != {selected}"
        )
    function = getattr(module, "_simulate_loop", None)
    if function is None:
        raise AttributeError("external NumPy HBV-light _simulate_loop is missing")
    return function


def generate_independent_truth(
    truth_parameters: np.ndarray,
    forcing: np.ndarray,
    initial_state: np.ndarray,
    process_variance: np.ndarray,
    process_standard_normals: np.ndarray,
    observation_standard_normals: np.ndarray,
    *,
    observation_ratio: float,
    base_observation_variance: float,
    denominator_margin: float = 1e-6,
    fixed_point_tolerance: float = 1e-12,
    maximum_projection_fraction: float = 0.15,
    minimum_proportional_branch_fraction: float = 0.50,
    external_model_path: Path = EXTERNAL_NUMPY_TRUTH_PATH,
) -> dict[str, Any]:
    """Generate recursive hidden truth using only the external NumPy transition."""

    parameter = np.ascontiguousarray(
        np.asarray(truth_parameters, dtype=np.float64).reshape(-1)
    )
    forcing_array = np.ascontiguousarray(np.asarray(forcing, dtype=np.float64))
    first_state = np.ascontiguousarray(np.asarray(initial_state, dtype=np.float64).reshape(-1))
    process = np.ascontiguousarray(
        np.asarray(process_variance, dtype=np.float64).reshape(-1)
    )
    process_z = np.ascontiguousarray(np.asarray(process_standard_normals, dtype=np.float64))
    observation_z = np.ascontiguousarray(
        np.asarray(observation_standard_normals, dtype=np.float64).reshape(-1)
    )
    if parameter.shape != (13,):
        raise ValueError("truth parameters must contain thirteen HBV-light values")
    if forcing_array.ndim != 2 or forcing_array.shape[1] != 3:
        raise ValueError("truth forcing must be [T,3]")
    days = int(forcing_array.shape[0])
    if first_state.shape != (8,) or process.shape != (8,):
        raise ValueError("TUKF11 truth state and process variance must contain eight values")
    if process_z.shape != (days, 8) or observation_z.shape != (days,):
        raise ValueError("frozen standard-normal arrays have wrong shapes")
    if not all(
        np.isfinite(value).all()
        for value in (parameter, forcing_array, first_state, process, process_z, observation_z)
    ):
        raise ValueError("truth inputs must be finite")
    if np.any(process < 0.0):
        raise ValueError("nominal process variances must be nonnegative")
    if float(parameter[-1]) != 3.0:
        raise ValueError("TUKF11 truth lag_time must remain exactly 3.0")

    simulate_one_day = _load_external_numpy_truth(Path(external_model_path))
    weights = routing_weights_numpy(3)
    states = np.empty((days + 1, 8), dtype=np.float64)
    deterministic_states = np.empty((days, 8), dtype=np.float64)
    increments = np.sqrt(process).reshape(1, -1) * process_z
    projection_delta = np.empty((days, 8), dtype=np.float64)
    projection_hits = np.empty((days, 8), dtype=bool)
    raw_discharge = np.empty(days, dtype=np.float64)
    clean_discharge = np.empty(days, dtype=np.float64)
    states[0] = first_state
    state = first_state.copy()
    field_capacity = float(parameter[4])

    for day, row in enumerate(forcing_array):
        result = simulate_one_day(
            np.asarray([row[0]], dtype=np.float64),
            np.asarray([row[2]], dtype=np.float64),
            np.asarray([row[1]], dtype=np.float64),
            *state[:5].tolist(),
            *parameter[:12].tolist(),
        )
        one_day_raw = float(np.asarray(result[0], dtype=np.float64).reshape(-1)[0])
        deterministic = np.concatenate(
            (
                np.asarray(result[1:6], dtype=np.float64),
                np.asarray([one_day_raw, state[5], state[6]], dtype=np.float64),
            )
        )
        deterministic_states[day] = deterministic
        unprojected = deterministic + increments[day]
        projected = np.maximum(unprojected, 0.0)
        projected[2] = min(projected[2], field_capacity)
        delta = projected - unprojected
        projection_delta[day] = delta
        projection_hits[day] = delta != 0.0
        state = projected
        states[day + 1] = state
        raw_discharge[day] = one_day_raw
        clean_discharge[day] = max(float(np.dot(state[5:], weights)), 0.0)

    observations, observation_report = sample_self_consistent_observation(
        clean_discharge,
        observation_z,
        observation_ratio,
        base_observation_variance,
        denominator_margin,
    )
    projection_fraction = float(np.mean(projection_hits))
    fixed_point_error = float(observation_report["fixed_point_max_absolute_error"])
    proportional_fraction = float(observation_report["proportional_branch_fraction"])
    if projection_fraction > float(maximum_projection_fraction):
        raise ValueError("truth projection fraction exceeds the frozen maximum")
    if fixed_point_error > float(fixed_point_tolerance):
        raise ValueError("self-consistent observation fixed-point error exceeds tolerance")
    if proportional_fraction < float(minimum_proportional_branch_fraction):
        raise ValueError("proportional observation branch fraction is below the frozen minimum")

    return {
        "states": np.ascontiguousarray(states),
        "deterministic_pre_noise_states": np.ascontiguousarray(deterministic_states),
        "preprojection_process_increment": np.ascontiguousarray(increments),
        "projection_delta": np.ascontiguousarray(projection_delta),
        "projection_hit_mask": np.ascontiguousarray(projection_hits),
        "raw_discharge": np.ascontiguousarray(raw_discharge),
        "clean_discharge": np.ascontiguousarray(clean_discharge),
        "observations": observations,
        "process_standard_normals": process_z.copy(),
        "observation_standard_normals": observation_z.copy(),
        "observation_branch_codes": observation_report["branch_codes"],
        "standardized_observation_residual": observation_report["standardized_residual"],
        "observation_scale": observation_report["scale"],
        "routing_weights": weights,
        "projection_fraction": projection_fraction,
        "fixed_point_max_absolute_error": fixed_point_error,
        "maximum_standardized_residual_error": fixed_point_error,
        "minimum_fixed_point_denominator": float(
            observation_report["minimum_positive_proportional_denominator"]
        ),
        "proportional_branch_fraction": proportional_fraction,
        "observation_branch_counts": observation_report["branch_counts"],
    }


def build_start_values(contract: Mapping[str, Any], start_id: str) -> dict[str, Any]:
    """Decode one frozen formal start without constructing a PyTorch model."""

    if start_id not in START_IDS:
        raise ValueError(f"unknown TUKF11 start identifier: {start_id}")
    truth = contract["truth"]
    starts = contract["starts"]
    names = truth["trainable_hydrology_names"]
    truth_parameter = np.asarray(truth["hydrology_parameters"], dtype=np.float64)
    lower = np.asarray([truth["hydrology_v5_bounds"][name][0] for name in names])
    upper = np.asarray([truth["hydrology_v5_bounds"][name][1] for name in names])
    truth_coordinate = (truth_parameter[:12] - lower) / (upper - lower)
    signs = np.asarray(starts["hydrology_sign_patterns"][start_id], dtype=np.float64)
    coordinate = truth_coordinate + float(starts["hydrology_coordinate_distance"]) * signs
    if np.any(coordinate <= 0.0) or np.any(coordinate >= 1.0):
        raise ValueError("registered hydrology start is not strictly inside fifth-version bounds")
    hydrology = lower + coordinate * (upper - lower)
    base_parameters = np.concatenate((hydrology, truth_parameter[12:13]))
    process = np.asarray(truth["process_nominal_variances"], dtype=np.float64) * np.asarray(
        starts["process_variance_multipliers"][start_id], dtype=np.float64
    )
    observation = float(truth["observation_residual_ratio"]) * float(
        starts["observation_ratio_multipliers"][start_id]
    )
    q_lower, q_upper = starts["process_variance_bounds"]
    r_lower, r_upper = starts["observation_ratio_bounds"]
    if np.any(process < q_lower) or np.any(process > q_upper):
        raise ValueError("registered process-noise start lies outside bounds")
    if not (r_lower <= observation <= r_upper):
        raise ValueError("registered observation start lies outside bounds")
    return {
        "base_parameters": np.ascontiguousarray(base_parameters),
        "hydrology_coordinates": np.ascontiguousarray(coordinate),
        "process_diagonal": np.ascontiguousarray(process),
        "observation_ratio": observation,
    }


def build_joint_model(
    contract: Mapping[str, Any],
    start_id: str,
    *,
    device: torch.device | None = None,
    dtype: torch.dtype = torch.float64,
):
    """Construct one single-basin joint model from a frozen formal start."""

    from global_hydrology.models.trainable_hbvlite_ukf_adapter import (
        JointTrainableRoutedHBVLiteUKF,
    )

    values = build_start_values(contract, start_id)
    selected_device = device or torch.device("cpu")
    weights = torch.as_tensor(
        contract["truth"]["routing_weights"], dtype=dtype, device=selected_device
    ).reshape(1, -1)
    model = JointTrainableRoutedHBVLiteUKF(
        torch.as_tensor(values["base_parameters"], dtype=dtype, device=selected_device).reshape(1, -1),
        weights,
        initial_process_diagonal=torch.as_tensor(
            values["process_diagonal"], dtype=dtype, device=selected_device
        ),
        initial_observation_ratio=values["observation_ratio"],
        process_noise_bounds=tuple(contract["starts"]["process_variance_bounds"]),
        observation_ratio_bounds=tuple(contract["starts"]["observation_ratio_bounds"]),
        clamp_storage=True,
        signed_routing_memory=False,
        device=selected_device,
        dtype=dtype,
    )
    if model.dim_x != int(contract["truth"]["state_dimension"]):
        raise RuntimeError("joint model state dimension differs from the frozen contract")
    return model


def segmented_multilead_objective(
    model,
    forcings: torch.Tensor,
    observations: torch.Tensor,
    initial_state: torch.Tensor,
    initial_covariance: torch.Tensor,
    *,
    base_observation_variance: torch.Tensor | float,
    target_start: int,
    target_end_exclusive: int,
    leads: Sequence[int] = (1, 2, 3),
) -> tuple[torch.Tensor, dict[int, torch.Tensor]]:
    """Compute target-aligned causal forecasts after filtering only each origin prefix."""

    from scripts.differentiable_ukf_hbvlite import run_hbvlite_corrected_ukf

    selected_leads = tuple(int(lead) for lead in leads)
    if selected_leads != (1, 2, 3):
        raise ValueError("TUKF11 leads must remain exactly one, two, and three days")
    if isinstance(target_start, bool) or isinstance(target_end_exclusive, bool):
        raise ValueError("target bounds must be integer indices")
    target_start = int(target_start)
    target_end_exclusive = int(target_end_exclusive)
    forcing = torch.as_tensor(forcings, dtype=model.dtype, device=model.device)
    observation = torch.as_tensor(observations, dtype=model.dtype, device=model.device)
    state0 = torch.as_tensor(initial_state, dtype=model.dtype, device=model.device)
    covariance0 = torch.as_tensor(
        initial_covariance, dtype=model.dtype, device=model.device
    )
    if forcing.ndim != 3 or forcing.shape[1:] != (1, 3):
        raise ValueError("forcings must be [T,1,3]")
    if observation.shape != (forcing.shape[0], 1):
        raise ValueError("observations must be [T,1]")
    if state0.shape != (1, model.dim_x):
        raise ValueError("initial state shape differs from the joint model")
    if covariance0.shape != (1, model.dim_x, model.dim_x):
        raise ValueError("initial covariance shape differs from the joint model")
    if target_start < max(selected_leads):
        raise ValueError("target start must provide a posterior origin for every lead")
    if not (target_start < target_end_exclusive <= forcing.shape[0]):
        raise ValueError("target interval is empty or outside the synthetic sequence")
    targets = observation[target_start:target_end_exclusive, 0]
    if not bool(torch.isfinite(targets).all()):
        raise FloatingPointError("every synthetic target must be finite")
    base_variance = torch.as_tensor(
        base_observation_variance, dtype=model.dtype, device=model.device
    )
    if not bool(torch.isfinite(base_variance).all()) or bool(torch.any(base_variance <= 0)):
        raise ValueError("base observation variance must be finite and positive")

    filter_end = target_end_exclusive - 1
    result = run_hbvlite_corrected_ukf(
        model,
        forcing[:filter_end],
        observation[:filter_end],
        model.project_mean(state0),
        covariance0,
        model.process_diagonal(),
        base_observation_variance=base_variance,
        r_b=model.observation_ratio(),
        project_mean=model.project_mean,
    )
    posterior = result["posterior_state"][:, 0, :]
    forecasts: dict[int, torch.Tensor] = {}
    losses = []
    for lead in selected_leads:
        origins = torch.arange(
            target_start - lead,
            target_end_exclusive - lead,
            dtype=torch.long,
            device=model.device,
        )
        state = posterior[origins]
        for step in range(1, lead + 1):
            state = model.f(state, forcing[origins + step, 0, :])
        forecast = model.h(state)[:, 0]
        if forecast.shape != targets.shape or not bool(torch.isfinite(forecast).all()):
            raise FloatingPointError(f"lead-{lead} forecast is non-finite or misaligned")
        forecasts[lead] = forecast
        losses.append(torch.mean((forecast - targets) ** 2))
    loss = torch.stack(losses).mean()
    if not bool(torch.isfinite(loss)):
        raise FloatingPointError("segmented multi-lead objective is non-finite")
    return loss, forecasts


def build_grouped_adam(model, contract: Mapping[str, Any]) -> torch.optim.Adam:
    """Build exactly two Adam groups with frozen group-specific learning rates."""

    if model.hydrology_coordinates is None:
        raise ValueError("joint-only optimizer requires trainable hydrology coordinates")
    optimizer = contract["optimizer"]
    return torch.optim.Adam(
        [
            {
                "params": [model.hydrology_coordinates],
                "lr": float(optimizer["hydrology_learning_rate"]),
                "group_name": "hydrology",
            },
            {
                "params": [model.log_process_diagonal, model.log_observation_ratio],
                "lr": float(optimizer["filter_learning_rate"]),
                "group_name": "filter",
            },
        ],
        betas=(0.9, 0.999),
        eps=1e-8,
        weight_decay=0.0,
        amsgrad=False,
    )


def clip_active_groups_(model, max_norm: float) -> dict[str, float]:
    """Clip hydrology and filter gradients independently and return pre-clip norms."""

    limit = float(max_norm)
    if not math.isfinite(limit) or limit <= 0.0:
        raise ValueError("group gradient norm must be finite and positive")
    if model.hydrology_coordinates is None:
        raise ValueError("joint-only clipping requires hydrology coordinates")
    groups = {
        "hydrology": [model.hydrology_coordinates],
        "filter": [model.log_process_diagonal, model.log_observation_ratio],
    }
    result: dict[str, float] = {}
    for name, parameters in groups.items():
        for parameter in parameters:
            if parameter.grad is None or not bool(torch.isfinite(parameter.grad).all()):
                raise FloatingPointError(f"{name} gradient is missing or non-finite")
        norm = torch.nn.utils.clip_grad_norm_(parameters, limit)
        value = float(norm)
        if not math.isfinite(value):
            raise FloatingPointError(f"{name} gradient norm is non-finite")
        result[name] = value
    return result


def snapshot_trainables(model) -> dict[str, np.ndarray]:
    """Return independent NumPy copies sufficient to restore and audit a checkpoint."""

    if model.hydrology_coordinates is None:
        raise ValueError("joint-only snapshot requires hydrology coordinates")
    return {
        "hydrology": np.ascontiguousarray(
            model.hydrology_coordinates.detach().cpu().numpy().copy()
        ),
        "log_process": np.ascontiguousarray(
            model.log_process_diagonal.detach().cpu().numpy().copy()
        ),
        "log_observation": np.ascontiguousarray(
            model.log_observation_ratio.detach().reshape(1).cpu().numpy().copy()
        ),
        "lag_time": np.ascontiguousarray(model.fixed_lag_time.detach().cpu().numpy().copy()),
        "physical_parameters": np.ascontiguousarray(
            model.physical_parameter_tensor().detach().cpu().numpy().copy()
        ),
        "process_diagonal": np.ascontiguousarray(
            model.process_diagonal().detach().cpu().numpy().copy()
        ),
        "observation_ratio": np.ascontiguousarray(
            model.observation_ratio().detach().reshape(1).cpu().numpy().copy()
        ),
        "state_dimension": np.asarray([int(model.dim_x)], dtype=np.int64),
    }


@torch.no_grad()
def restore_trainables_(model, snapshot: Mapping[str, np.ndarray]) -> None:
    """Restore one selected trainable checkpoint while proving lag invariance."""

    lag = torch.as_tensor(snapshot["lag_time"], dtype=model.dtype, device=model.device)
    if not torch.equal(lag, model.fixed_lag_time):
        raise ValueError("checkpoint lag_time differs from the fixed model")
    model.hydrology_coordinates.copy_(
        torch.as_tensor(snapshot["hydrology"], dtype=model.dtype, device=model.device)
    )
    model.log_process_diagonal.copy_(
        torch.as_tensor(snapshot["log_process"], dtype=model.dtype, device=model.device)
    )
    model.log_observation_ratio.copy_(
        torch.as_tensor(snapshot["log_observation"], dtype=model.dtype, device=model.device).reshape(())
    )
    model.project_trainable_coordinates_()


def _error_ratio(selected: float, initial: float) -> float:
    if not (math.isfinite(selected) and math.isfinite(initial)) or initial <= 0.0:
        raise ValueError("recovery errors must be finite and the initial error positive")
    return selected / initial


def recovery_metrics(
    initial_snapshot: Mapping[str, np.ndarray],
    selected_snapshot: Mapping[str, np.ndarray],
    contract: Mapping[str, Any],
    *,
    boundary_tolerance: float = 1e-12,
) -> dict[str, Any]:
    """Measure physical-coordinate and log-noise recovery without mixing units."""

    tolerance = float(boundary_tolerance)
    if not math.isfinite(tolerance) or tolerance < 0.0:
        raise ValueError("boundary tolerance must be finite and nonnegative")
    truth = contract["truth"]
    starts = contract["starts"]
    names = truth["trainable_hydrology_names"]
    true_parameter = np.asarray(truth["hydrology_parameters"], dtype=np.float64)
    lower = np.asarray([truth["hydrology_v5_bounds"][name][0] for name in names])
    upper = np.asarray([truth["hydrology_v5_bounds"][name][1] for name in names])
    true_coordinate = (true_parameter[:12] - lower) / (upper - lower)

    initial_h = np.asarray(initial_snapshot["hydrology"], dtype=np.float64).reshape(-1)
    selected_h = np.asarray(selected_snapshot["hydrology"], dtype=np.float64).reshape(-1)
    true_q = np.asarray(truth["process_nominal_variances"], dtype=np.float64)
    initial_q = np.asarray(initial_snapshot["process_diagonal"], dtype=np.float64).reshape(-1)
    selected_q = np.asarray(selected_snapshot["process_diagonal"], dtype=np.float64).reshape(-1)
    true_r = float(truth["observation_residual_ratio"])
    initial_r = float(np.asarray(initial_snapshot["observation_ratio"]).reshape(-1)[0])
    selected_r = float(np.asarray(selected_snapshot["observation_ratio"]).reshape(-1)[0])
    if initial_h.shape != true_coordinate.shape or selected_h.shape != true_coordinate.shape:
        raise ValueError("hydrology snapshot shape differs from truth")
    if initial_q.shape != true_q.shape or selected_q.shape != true_q.shape:
        raise ValueError("process snapshot shape differs from truth")
    if np.any(initial_q <= 0.0) or np.any(selected_q <= 0.0) or initial_r <= 0.0 or selected_r <= 0.0:
        raise ValueError("noise snapshots must remain strictly positive")

    hydrology_initial = float(np.sqrt(np.mean((initial_h - true_coordinate) ** 2)))
    hydrology_selected = float(np.sqrt(np.mean((selected_h - true_coordinate) ** 2)))
    process_initial = float(np.sqrt(np.mean(np.log(initial_q / true_q) ** 2)))
    process_selected = float(np.sqrt(np.mean(np.log(selected_q / true_q) ** 2)))
    observation_initial = abs(math.log(initial_r / true_r))
    observation_selected = abs(math.log(selected_r / true_r))
    q_lower, q_upper = (float(value) for value in starts["process_variance_bounds"])
    r_lower, r_upper = (float(value) for value in starts["observation_ratio_bounds"])
    hydrology_hits = int(
        np.count_nonzero((selected_h <= tolerance) | (selected_h >= 1.0 - tolerance))
    )
    process_hits = int(
        np.count_nonzero(
            (selected_q <= q_lower + tolerance) | (selected_q >= q_upper - tolerance)
        )
    )
    observation_hits = int(
        selected_r <= r_lower + tolerance or selected_r >= r_upper - tolerance
    )

    groups = {
        "hydrology": {
            "initial_error": hydrology_initial,
            "selected_error": hydrology_selected,
            "selected_to_initial_ratio": _error_ratio(hydrology_selected, hydrology_initial),
            "selected_boundary_hit_count": hydrology_hits,
            "boundary_total": 12,
        },
        "process": {
            "initial_error": process_initial,
            "selected_error": process_selected,
            "selected_to_initial_ratio": _error_ratio(process_selected, process_initial),
            "selected_boundary_hit_count": process_hits,
            "boundary_total": 8,
        },
        "observation": {
            "initial_error": observation_initial,
            "selected_error": observation_selected,
            "selected_to_initial_ratio": _error_ratio(
                observation_selected, observation_initial
            ),
            "selected_boundary_hit_count": observation_hits,
            "boundary_total": 1,
        },
    }
    groups["selected_boundary_hit_count"] = hydrology_hits + process_hits + observation_hits
    groups["selected_boundary_total"] = 21
    return groups
