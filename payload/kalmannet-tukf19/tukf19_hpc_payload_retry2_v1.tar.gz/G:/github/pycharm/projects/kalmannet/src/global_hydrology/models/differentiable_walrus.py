"""
Differentiable Walrus Hydrological Model (PyTorch Implementation)
==================================================================

A differentiable version of the Walrus hydrological model for joint optimization
with KalmanNet. This implementation allows gradient flow through the physical
parameters cw, cv, cg, cq while keeping cd and cs fixed.

Key Design Principles:
    - cw, cv, cg, cq: Learnable parameters (from StaticEncoder)
    - cd, cs: Fixed parameters (not optimized, to reduce equifinality)
    - All operations use PyTorch tensors for automatic differentiation
    - Supports batch processing (multiple catchments simultaneously)

Author: KalmanNet Global DA Project
Date: 2026-01-20
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple, Dict, Optional


class DifferentiableWalrus(nn.Module):
    """
    可微 Walrus 水文模型 (Differentiable Walrus Hydrological Model)
    
    这是一个支持梯度回传的 Walrus 模型实现，用于与 KalmanNet 联合优化。
    
    Attributes:
        eps (float): 数值稳定性常数
        m (int): 状态维度 (5: dv, dg, hq, hs, q)
        n (int): 观测维度 (1: q)
    
    Args (forward):
        forcing: [Batch, Time, 2] - 气象驱动 (Precip, ETpot)
        hydro_params: [Batch, 4] - 由 StaticEncoder 生成的水文参数 (cw, cv, cg, cq)
        state_init: Optional - 初始状态字典
        cd: float - 固定参数：河道深度
        cs: float - 固定参数：河道形状参数
        
    Returns:
        q_sim: [Batch, Time, 1] - 模拟流量
        states_all: Dict - 所有时间步的状态变量
    """
    
    # 参数索引常量 (仅4个可学习参数)
    PARAM_CW = 0   # Catchment wetness parameter
    PARAM_CV = 1   # Vadose zone recession
    PARAM_CG = 2   # Groundwater recession
    PARAM_CQ = 3   # Quickflow recession
    
    N_PARAMS = 4   # 可学习参数数量
    N_STATES = 5   # 状态变量数量 (dv, dg, hq, hs, q)
    
    def __init__(self, 
                 cd: float = 2450.0,
                 cs: float = 0.2,
                 as_: float = 0.01,
                 eps: float = 1e-6,
                 device: Optional[torch.device] = None):
        """
        初始化 DifferentiableWalrus
        
        Args:
            cd: 固定参数 - 河道深度 (mm)
            cs: 固定参数 - 河道形状参数
            as_: 表面区域比例
            eps: 数值稳定性常数
            device: 计算设备
        """
        super().__init__()
        
        if device is None:
            device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.device = device
        
        self.eps = eps
        self.m = self.N_STATES
        self.n = 1
        
        # 固定参数 (不参与梯度更新)
        self.register_buffer('cd', torch.tensor(cd, dtype=torch.float32, device=device))
        self.register_buffer('cs', torch.tensor(cs, dtype=torch.float32, device=device))
        self.register_buffer('as_', torch.tensor(as_, dtype=torch.float32, device=device))
        self.register_buffer('ag_', torch.tensor(1.0 - as_, dtype=torch.float32, device=device))
        
        # 其他固定参数 (物理常数)
        self.register_buffer('b', torch.tensor(4.38, dtype=torch.float32, device=device))
        self.register_buffer('psi_ae', torch.tensor(90.0, dtype=torch.float32, device=device))
        self.register_buffer('theta_s', torch.tensor(0.41, dtype=torch.float32, device=device))
        self.register_buffer('zeta1', torch.tensor(0.02, dtype=torch.float32, device=device))
        self.register_buffer('zeta2', torch.tensor(400.0, dtype=torch.float32, device=device))
        self.register_buffer('min_h', torch.tensor(0.001, dtype=torch.float32, device=device))
        self.register_buffer('hs_min', torch.tensor(0.0, dtype=torch.float32, device=device))
        self.register_buffer('exps', torch.tensor(1.5, dtype=torch.float32, device=device))
        
        # 状态约束边界
        self.register_buffer('dv_lb', torch.tensor(5.0, dtype=torch.float32, device=device))
        self.register_buffer('dv_ub', torch.tensor(500.0, dtype=torch.float32, device=device))
        self.register_buffer('dg_lb', torch.tensor(5.0, dtype=torch.float32, device=device))
        self.register_buffer('dg_ub', self.cd.clone().detach())
        self.register_buffer('hq_lb', torch.tensor(0.0, dtype=torch.float32, device=device))
        self.register_buffer('hq_ub', torch.tensor(20.0, dtype=torch.float32, device=device))
        self.register_buffer('hs_lb', torch.tensor(5.0, dtype=torch.float32, device=device))
        self.register_buffer('hs_ub', torch.tensor(5000.0, dtype=torch.float32, device=device))
        self.register_buffer('q_lb', torch.tensor(0.0, dtype=torch.float32, device=device))
        self.register_buffer('q_ub', torch.tensor(5.0, dtype=torch.float32, device=device))
        
        # 状态名称
        self.state_names = ['dv', 'dg', 'hq', 'hs', 'q']
        self.observed_state_names = ['q']
    
    def _constrain_params(self, raw_params: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        将原始参数转换为物理合理的范围。
        
        仅对 4 个可学习参数进行约束：
        - cw: Catchment wetness (范围约 [10, 1000] mm)
        - cv: Vadose zone recession (范围约 [1, 200])
        - cg: Groundwater recession (范围约 [1000, 1e7])
        - cq: Quickflow recession (范围约 [0.1, 50])
        
        Args:
            raw_params: [Batch, 4] - 原始参数（无约束）
            
        Returns:
            params: Dict[str, Tensor] - 约束后的参数字典
        """
        params = {}
        
        # cw: Catchment wetness - 使用 softplus 保证正值，范围约 [10, 1000]
        params['cw'] = F.softplus(raw_params[:, self.PARAM_CW:self.PARAM_CW+1]) * 500.0 + 10.0
        
        # cv: Vadose zone recession - 范围约 [1, 200]
        params['cv'] = F.softplus(raw_params[:, self.PARAM_CV:self.PARAM_CV+1]) * 100.0 + 1.0
        
        # cg: Groundwater recession - 范围约 [1000, 1e7] (这个值通常很大)
        params['cg'] = F.softplus(raw_params[:, self.PARAM_CG:self.PARAM_CG+1]) * 1e6 + 1000.0
        
        # cq: Quickflow recession - 范围约 [0.1, 50]
        params['cq'] = F.softplus(raw_params[:, self.PARAM_CQ:self.PARAM_CQ+1]) * 25.0 + 0.1
        
        return params
    
    def _init_states(self, batch_size: int, device: torch.device) -> Dict[str, torch.Tensor]:
        """
        初始化状态变量
        
        Args:
            batch_size: 批次大小
            device: 计算设备
            
        Returns:
            states: Dict containing dv, dg, hq, hs, q
        """
        states = {
            'dv': torch.ones(batch_size, 1, device=device) * 140.0,  # 土壤水分深度
            'dg': torch.ones(batch_size, 1, device=device) * 1000.0,  # 地下水深度
            'hq': torch.ones(batch_size, 1, device=device) * 4.0,     # 快流水位
            'hs': torch.ones(batch_size, 1, device=device) * 1200.0,  # 慢流水位
            'q': torch.ones(batch_size, 1, device=device) * 0.1,      # 流量
        }
        return states
    
    def _apply_state_constraints(self, x: torch.Tensor) -> torch.Tensor:
        """
        对状态向量应用物理约束（与 WalrusBatch.apply_state_constraints_pure 一致）
        
        Args:
            x: [Batch, 5] - 状态向量 (dv, dg, hq, hs, q)
            
        Returns:
            x_constrained: [Batch, 5] - 约束后的状态向量
        """
        dv = torch.clamp(x[:, 0:1], self.dv_lb, self.dv_ub)
        dg = torch.clamp(x[:, 1:2], self.dg_lb, self.dg_ub)
        hq = torch.clamp(x[:, 2:3], self.hq_lb, self.hq_ub)
        hs = torch.clamp(x[:, 3:4], self.hs_lb, self.hs_ub)
        q = torch.clamp(x[:, 4:5], self.q_lb, self.q_ub)
        
        x_constrained = torch.cat([dv, dg, hq, hs, q], dim=1)
        return x_constrained
    
    def _func_w_dv(self, dv: torch.Tensor, cw: torch.Tensor) -> torch.Tensor:
        """计算权重函数 w(dv, cw)"""
        # torch.clamp 混合类型支持有限，拆分为两步
        # result = 0.5 * torch.cos(torch.clamp(dv, min=0, max=cw) * torch.pi / (cw + self.eps)) + 0.5
        dv_clamped = torch.clamp(dv, min=0.0)
        dv_clamped = torch.min(dv_clamped, cw)
        result = 0.5 * torch.cos(dv_clamped * torch.pi / (cw + self.eps)) + 0.5
        return result
    
    def _func_dveq_dg(self, dg: torch.Tensor) -> torch.Tensor:
        """计算平衡土壤水分深度"""
        dg = torch.clamp(dg, self.dg_lb, self.dg_ub)
        psi_ae, b, theta_s = self.psi_ae, self.b, self.theta_s
        
        dveq = torch.where(
            dg > psi_ae,
            (dg - (psi_ae / (1 - b)) - (dg ** (1 - 1 / b)) * (psi_ae ** (1 / b)) / (1 - 1 / b)) * theta_s,
            torch.where(dg < 0.0, dg, torch.zeros_like(dg))
        )
        return dveq
    
    def _func_get_pq_pv_ps(self, p_t: torch.Tensor, w: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """计算降水分配"""
        pq = p_t * w * self.ag_
        pv = p_t * (1 - w) * self.ag_
        ps = p_t * self.as_
        return pq, pv, ps
    
    def _func_get_etv_ets(self, etpot_t: torch.Tensor, dv: torch.Tensor, hs: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """计算实际蒸发"""
        etv = etpot_t * self._func_beta_dv(dv) * self.ag_
        ets = etpot_t * self.as_
        ets = torch.where(hs < self.min_h, torch.zeros_like(ets), ets)
        return etv, ets
    
    def _func_beta_dv(self, dv: torch.Tensor) -> torch.Tensor:
        """计算土壤水分调整系数"""
        exp_term = torch.exp(self.zeta1 * (dv - self.zeta2))
        beta = (1 - exp_term) / (1 + exp_term) * 0.5 + 0.5
        beta = torch.where(torch.isnan(beta), torch.zeros_like(beta), beta)
        return beta
    
    def _func_q_hs(self, hs: torch.Tensor) -> torch.Tensor:
        """计算流量"""
        hs = torch.clamp(hs, self.hs_lb, self.hs_ub)
        hs_min, exps, cd, cs = self.hs_min, self.exps, self.cd, self.cs
        
        normal_flow = (hs > hs_min) & (hs <= cd)
        overflow = hs > cd + 1.0
        
        q = torch.zeros_like(hs)
        q = torch.where(normal_flow, cs * ((hs - hs_min) / (cd - hs_min + self.eps)) ** exps, q)
        
        denom = torch.clamp(cd - hs_min, min=0.01)
        base = torch.clamp(hs - cd, min=0.01)
        q = torch.where(overflow, cs + cs * (base / denom) ** exps, q)
        
        return q
    
    def _func_pond_flood(self, dv: torch.Tensor, hs: torch.Tensor, dg: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """处理溢流和负值"""
        cd = self.cd
        
        condition1 = (dv < 0.0) & (hs <= cd)
        condition2 = (dv >= 0.0) & (hs > cd)
        condition3 = (dv <= 0.0) & (hs >= cd)
        condition4 = dv < 0.0
        
        hs = torch.where(condition1, hs - (dv * self.ag_ / self.as_), hs)
        dv = torch.where(condition1, torch.zeros_like(dv), dv)
        
        dv = torch.where(condition2, dv - (hs - cd) * self.as_ / self.ag_, dv)
        hs = torch.where(condition2, cd * torch.ones_like(hs), hs)
        
        adjustment = dv * self.ag_ - (hs - cd) * self.as_
        hs = torch.where(condition3, cd - adjustment, hs)
        dv = torch.where(condition3, adjustment, dv)
        dg = torch.where(condition4, dv, dg)
        
        return dv, hs, dg
    
    def forward_step(self, 
                     x: torch.Tensor,
                     p_t: torch.Tensor,
                     etpot_t: torch.Tensor,
                     params: Dict[str, torch.Tensor]) -> torch.Tensor:
        """
        单步前向传播
        
        Args:
            x: [Batch, 5] - 当前状态 (dv, dg, hq, hs, q)
            p_t: [Batch, 1] - 当前时刻降水
            etpot_t: [Batch, 1] - 当前时刻潜在蒸发
            params: 约束后的参数字典
            
        Returns:
            x_next: [Batch, 5] - 下一时刻状态
        """
        cw = params['cw']
        cv = params['cv']
        cg = params['cg']
        cq = params['cq']
        
        # 先对输入状态做完整约束（与 WalrusBatch.apply_state_constraints_pure 一致）
        x = self._apply_state_constraints(x)
        
        # 分解状态（已约束，无需再做 min clamp）
        dv0 = x[:, 0:1]
        dg0 = x[:, 1:2]
        hq0 = x[:, 2:3]
        hs0 = x[:, 3:4]
        q0 = x[:, 4:5]
        
        # 计算中间变量
        w0 = self._func_w_dv(dv0, cw)
        dveq0 = self._func_dveq_dg(dg0)
        
        pq, pv, ps = self._func_get_pq_pv_ps(p_t, w0)
        etv, ets = self._func_get_etv_ets(etpot_t, dv0, hs0)
        
        fqs = hq0 / (cq + self.eps)
        
        if torch.any(cg <= 0):
            raise ValueError("cg must be positive to avoid division by zero.")
        
        fgs = (self.cd - dg0 - hs0) * torch.max((self.cd - dg0), hs0) / (cg + self.eps)
        
        # 状态更新
        dv = dv0 - (pv - etv - fgs) / self.ag_
        dg = dg0 + (dv0 - dveq0) / (cv + self.eps)
        hq = hq0 + (pq - fqs) / self.ag_
        hs = hs0 + (ps - ets + fgs + fqs - q0) / self.as_
        
        # 计算流量
        q = self._func_q_hs(hs)
        
        # 处理溢流
        dv, hs, dg = self._func_pond_flood(dv, hs, dg)
        
        # 最终约束 (使用与 WalrusBatch 一致的物理边界)
        # 注意：这里用下限稍微宽松一点 (0.001) 防止负值，上限用物理边界
        dv = torch.clamp(dv, min=self.dv_lb, max=self.dv_ub)
        dg = torch.clamp(dg, min=self.dg_lb, max=self.dg_ub)
        hq = torch.clamp(hq, min=0.001, max=self.hq_ub)  # hq 下限用 0.001 防止除零
        hs = torch.clamp(hs, min=0.001, max=self.hs_ub)  # hs 下限用 0.001 防止负值
        q = torch.clamp(q, min=self.q_lb, max=self.q_ub)
        
        # 组合状态
        x_next = torch.cat([dv, dg, hq, hs, q], dim=1)
        
        return x_next
    
    def forward(self, 
                forcing: torch.Tensor,
                hydro_params: torch.Tensor,
                state_init: Optional[Dict[str, torch.Tensor]] = None,
                return_internals: bool = False) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """
        前向传播 - 运行 Walrus 模型
        
        Args:
            forcing: [Batch, Time, 2] - 气象驱动
                     Channel 0: Precipitation (mm/day)
                     Channel 1: Potential Evapotranspiration (mm/day)
            hydro_params: [Batch, 4] - 由 StaticEncoder 生成的原始参数 (cw, cv, cg, cq)
            state_init: Optional - 初始状态字典
            return_internals: 是否返回内部通量（用于诊断）
            
        Returns:
            Q_sim: [Batch, Time, 1] - 模拟总流量 (mm/day)
            final_states: Dict - 最终时刻的状态变量
            (optional) internals: Dict - 内部通量时间序列
        """
        batch_size, time_steps, n_features = forcing.shape
        device = forcing.device
        
        assert n_features >= 2, f"Forcing must have at least 2 features, got {n_features}"
        assert hydro_params.shape[1] == self.N_PARAMS, \
            f"Expected {self.N_PARAMS} params, got {hydro_params.shape[1]}"
        
        # 1. 约束参数到物理合理范围
        params = self._constrain_params(hydro_params)
        
        # 2. 初始化状态
        if state_init is None:
            states = self._init_states(batch_size, device)
        else:
            states = {k: v.clone() for k, v in state_init.items()}
        
        # 将状态字典转换为张量
        x = torch.cat([
            states['dv'], states['dg'], states['hq'], states['hs'], states['q']
        ], dim=-1)  # [Batch, 5]
        
        # 3. 存储输出
        Q_sim_list = []
        
        if return_internals:
            internals = {
                'dv': [], 'dg': [], 'hq': [], 'hs': [], 'q': []
            }
        
        # 4. 时间步循环
        for t in range(time_steps):
            # 提取当前时刻的驱动
            P = forcing[:, t, 0:1]    # Precipitation
            ETpot = forcing[:, t, 1:2]  # Potential ET
            
            # 执行一步前向传播
            x = self.forward_step(x, P, ETpot, params)
            
            # 提取流量 (q 是状态的最后一维)
            Q_total = x[:, 4:5]
            Q_sim_list.append(Q_total)
            
            # 存储内部变量（如果需要）
            if return_internals:
                internals['dv'].append(x[:, 0:1].detach())
                internals['dg'].append(x[:, 1:2].detach())
                internals['hq'].append(x[:, 2:3].detach())
                internals['hs'].append(x[:, 3:4].detach())
                internals['q'].append(x[:, 4:5].detach())
        
        # 5. 拼接时间步
        Q_sim = torch.stack(Q_sim_list, dim=1)  # [Batch, Time, 1]
        
        # 6. 最终状态
        final_states = {
            'dv': x[:, 0:1],
            'dg': x[:, 1:2],
            'hq': x[:, 2:3],
            'hs': x[:, 3:4],
            'q': x[:, 4:5],
        }
        
        if return_internals:
            # 将列表转为张量
            for key in internals:
                internals[key] = torch.stack(internals[key], dim=1)
            return Q_sim, final_states, internals
        
        return Q_sim, final_states
    
    def get_state_tensor(self, states: Dict[str, torch.Tensor]) -> torch.Tensor:
        """
        将状态字典转换为单个张量（用于 KalmanNet 处理）
        
        Args:
            states: Dict with dv, dg, hq, hs, q
            
        Returns:
            state_tensor: [Batch, N_STATES]
        """
        return torch.cat([
            states['dv'],
            states['dg'],
            states['hq'],
            states['hs'],
            states['q'],
        ], dim=-1)
    
    def set_state_from_tensor(self, state_tensor: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        将状态张量转换回字典（KalmanNet 修正后使用）
        
        Args:
            state_tensor: [Batch, N_STATES]
            
        Returns:
            states: Dict with dv, dg, hq, hs, q
        """
        return {
            'dv': state_tensor[:, 0:1],
            'dg': state_tensor[:, 1:2],
            'hq': state_tensor[:, 2:3],
            'hs': state_tensor[:, 3:4],
            'q': state_tensor[:, 4:5],
        }


# ============================================================================
# 简单测试
# ============================================================================
if __name__ == "__main__":
    print("Testing DifferentiableWalrus...")
    
    # 创建模型
    model = DifferentiableWalrus(cd=2450.0, cs=0.2)
    
    # 创建假数据
    batch_size = 4
    time_steps = 365
    
    # 气象驱动: [Batch, Time, 2] (Precip, ETpot)
    forcing = torch.rand(batch_size, time_steps, 2)
    forcing[:, :, 0] *= 20    # Precip: 0-20 mm/day
    forcing[:, :, 1] *= 5     # ETpot: 0-5 mm/day
    
    # 水文参数: [Batch, 4] (cw, cv, cg, cq)
    hydro_params = torch.randn(batch_size, model.N_PARAMS)
    
    # 前向传播
    Q_sim, final_states = model(forcing, hydro_params)
    
    print(f"Input forcing shape: {forcing.shape}")
    print(f"Input params shape: {hydro_params.shape}")
    print(f"Output Q_sim shape: {Q_sim.shape}")
    print(f"Final states: {list(final_states.keys())}")
    print(f"Sample Q values: {Q_sim[0, :5, 0].detach().numpy()}")
    
    # 测试梯度 (确保 cw, cv, cg, cq 有梯度，cd, cs 无梯度)
    loss = Q_sim.mean()
    loss.backward()
    
    # 检查参数约束
    params = model._constrain_params(hydro_params)
    print(f"\nConstrained params:")
    print(f"  cw range: [{params['cw'].min():.2f}, {params['cw'].max():.2f}]")
    print(f"  cv range: [{params['cv'].min():.2f}, {params['cv'].max():.2f}]")
    print(f"  cg range: [{params['cg'].min():.2f}, {params['cg'].max():.2f}]")
    print(f"  cq range: [{params['cq'].min():.2f}, {params['cq'].max():.2f}]")
    print(f"  cd (fixed): {model.cd.item():.2f}")
    print(f"  cs (fixed): {model.cs.item():.2f}")
    
    print("\n✅ DifferentiableWalrus test passed!")
