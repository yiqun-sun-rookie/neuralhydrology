"""
M4 System Model Adapter for KalmanNet
======================================

This module wraps the DifferentiableM4 model into a SystemModel interface
that is compatible with the existing KalmanNet framework.

The adapter allows:
1. Using M4 as the process model (f) in the Kalman filter loop
2. Defining the observation model (h) as a simple state-to-output mapping
3. Integrating with StaticEncoder for global-scale applications

Author: KalmanNet Global DA Project
Date: 2026-01-14
"""

import torch
import torch.nn as nn
from typing import Tuple, Dict, Optional, Callable

from .differentiable_m4 import DifferentiableM4
from .static_encoder import StaticEncoder


class M4SystemModel:
    """
    将 DifferentiableM4 包装成 KalmanNet 需要的 SystemModel 接口。
    
    KalmanNet 需要的接口:
        - f(x, u): 状态转移函数
        - h(x): 观测函数
        - m: 状态维度
        - n: 观测维度
        - prior_q, prior_state_cov, prior_r: 先验协方差
    
    M4 模型的状态:
        - S_snow: 积雪量 (mm)
        - S_soil: 土壤水 (mm)
        - S_fast: 快流水库 (mm)
        - S_slow: 慢流水库 (mm)
    
    观测:
        - Q: 流量 (mm/day)
    
    Args:
        hydro_params: [Batch, N_PARAMS] 由 StaticEncoder 生成的水文参数
        device: 计算设备
    """
    
    # 状态和观测维度 (M4 模型固定)
    m = 4  # 状态维度: (S_snow, S_soil, S_fast, S_slow)
    n = 1  # 观测维度: Q
    
    def __init__(self, 
                 hydro_params: torch.Tensor,
                 device: torch.device = None,
                 seq_len: int = 365,
                 seq_len_test: int = 365):
        """
        初始化 M4 系统模型适配器。
        
        Args:
            hydro_params: [Batch, N_PARAMS] 水文参数
            device: 计算设备
            seq_len: 训练序列长度
            seq_len_test: 测试序列长度
        """
        self.device = device or torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # 存储水文参数（批次）
        self.hydro_params = hydro_params.to(self.device)
        self.batch_size = hydro_params.shape[0]
        
        # 创建内部 M4 模型实例
        self._m4_model = DifferentiableM4()
        
        # 约束参数（用于内部计算）
        self._constrained_params = self._m4_model._constrain_params(self.hydro_params)
        
        # 序列长度
        self.seq_len = seq_len
        self.seq_len_test = seq_len_test
        
        # 噪声协方差的先验（用于 KalmanNet 初始化）
        # 这些值不需要精确，因为 KalmanNet 会学习真正的增益
        self.q = torch.eye(self.m, device=self.device) * 0.1
        self.r = torch.eye(self.n, device=self.device) * 0.1
        
        self.prior_q = torch.eye(self.m, device=self.device)
        self.prior_state_cov = torch.eye(self.m, device=self.device) * 10.0
        self.prior_r = torch.eye(self.n, device=self.device)
        
        # 当前强迫数据（在 step 调用时需要）
        self._current_forcing = None
        
        # 初始状态
        self.m1x_0 = None  # 状态均值
        self.m2x_0 = None  # 状态协方差
    
    def set_forcing(self, forcing: torch.Tensor):
        """
        设置当前时间步的强迫数据。
        
        这个方法在每个时间步调用 f() 之前必须先调用。
        
        Args:
            forcing: [Batch, 3] 当前时间步的驱动 (P, T, PET)
        """
        self._current_forcing = forcing.to(self.device)
    
    def f(self, x: torch.Tensor, u: torch.Tensor = None) -> torch.Tensor:
        """
        状态转移函数 (Process Model)
        
        执行 M4 模型的一步前向传播。
        
        Args:
            x: [Batch, m] 或 [m,] 当前状态 (S_snow, S_soil, S_fast, S_slow)
            u: 输入（未使用，强迫通过 set_forcing 设置）
            
        Returns:
            x_next: [Batch, m] 下一时刻的状态
        """
        # 确保 x 是 2D
        if x.dim() == 1:
            x = x.unsqueeze(0)
        
        # 从状态张量构建状态字典
        states = self._m4_model.set_state_from_tensor(x)
        
        # 获取当前强迫 (优先使用 u，其次使用 set_forcing 设置的值)
        if u is not None:
            forcing = u
        elif self._current_forcing is not None:
            forcing = self._current_forcing
        else:
            raise ValueError("Must provide u or call set_forcing() before f()")
        
        batch_size = x.shape[0]
        
        # 确保强迫数据维度正确
        if forcing.dim() == 1:
            forcing = forcing.unsqueeze(0)
        if forcing.shape[0] == 1 and batch_size > 1:
            forcing = forcing.expand(batch_size, -1)
        
        # 提取强迫变量
        P = forcing[:, 0:1]
        T = forcing[:, 1:2]
        PET = forcing[:, 2:3]
        
        # 获取约束后的参数
        params = self._constrained_params
        
        # 执行 M4 模型的各个模块
        S_snow = states['S_snow']
        S_soil = states['S_soil']
        S_fast = states['S_fast']
        S_slow = states['S_slow']
        
        # Snow Module
        S_snow, P_eff, _ = self._m4_model._snow_module(P, T, S_snow, params)
        
        # Soil Module
        S_soil, Recharge, _ = self._m4_model._soil_module(P_eff, PET, S_soil, params)
        
        # Routing Module
        S_fast, S_slow, _, _ = self._m4_model._routing_module(Recharge, S_fast, S_slow, params)
        
        # 构建输出状态张量
        x_next = torch.cat([S_snow, S_soil, S_fast, S_slow], dim=-1)
        
        return x_next
    
    def h(self, x: torch.Tensor) -> torch.Tensor:
        """
        观测函数 (Observation Model)
        
        将状态映射到可观测量（流量）。
        
        对于 M4 模型: Q = Q_fast + Q_slow = K0 * S_fast + K1 * S_slow
        
        Args:
            x: [Batch, m] 状态向量
            
        Returns:
            y: [Batch, n] 观测向量 (流量)
        """
        # 确保 x 是 2D
        if x.dim() == 1:
            x = x.unsqueeze(0)
        
        # 提取状态
        S_fast = x[:, 2:3]
        S_slow = x[:, 3:4]
        
        # 获取汇流参数
        K0 = self._constrained_params['K0']
        K1 = self._constrained_params['K1']
        
        # 计算流量
        Q_fast = K0 * S_fast
        Q_slow = K1 * S_slow
        Q = Q_fast + Q_slow
        
        return Q
    
    def InitSequence(self, m1x_0: torch.Tensor, m2x_0: torch.Tensor):
        """
        初始化状态序列（单样本）
        
        Args:
            m1x_0: [m,] 初始状态均值
            m2x_0: [m, m] 初始状态协方差
        """
        self.m1x_0 = m1x_0.to(self.device)
        self.m2x_0 = m2x_0.to(self.device)
    
    def Init_batched_sequence(self, m1x_0_batch: torch.Tensor, m2x_0_batch: torch.Tensor):
        """
        初始化状态序列（批次）
        
        Args:
            m1x_0_batch: [Batch, m] 初始状态均值
            m2x_0_batch: [Batch, m, m] 初始状态协方差
        """
        self.m1x_0_batch = m1x_0_batch.to(self.device)
        self.x_prev = m1x_0_batch.to(self.device)
        self.m2x_0_batch = m2x_0_batch.to(self.device)
    
    def get_default_initial_state(self) -> torch.Tensor:
        """
        获取默认的初始状态
        
        Returns:
            x0: [Batch, m] 初始状态
        """
        # 使用 M4 模型的默认初始化
        params = self._constrained_params
        FC = params['FC']
        
        # 默认初始状态
        S_snow_init = torch.zeros(self.batch_size, 1, device=self.device)
        S_soil_init = FC * 0.5  # 半饱和
        S_fast_init = torch.zeros(self.batch_size, 1, device=self.device)
        S_slow_init = torch.ones(self.batch_size, 1, device=self.device) * 10.0
        
        x0 = torch.cat([S_snow_init, S_soil_init, S_fast_init, S_slow_init], dim=-1)
        return x0
    
    def UpdateCovariance_Matrix(self, Q: torch.Tensor, R: torch.Tensor):
        """更新噪声协方差矩阵"""
        self.Q = Q.to(self.device)
        self.R = R.to(self.device)


class GlobalHydroSystem(nn.Module):
    """
    全球水文系统模型 - 集成 StaticEncoder + M4 + KalmanNet
    
    这是一个端到端的可微模型，用于全球尺度的水文状态估计。
    
    架构:
        1. StaticEncoder: 静态属性 -> 水文参数
        2. M4SystemModel: 物理过程模型
        3. KalmanNet: 状态更新
    
    Args:
        n_static_attrs: 静态属性数量
        encoder_hidden: StaticEncoder 隐藏层大小
        encoder_layers: StaticEncoder 层数
    """
    
    def __init__(self, 
                 n_static_attrs: int = 16,
                 encoder_hidden: int = 64,
                 encoder_layers: int = 2):
        super().__init__()
        
        # 静态属性编码器
        self.static_encoder = StaticEncoder(
            n_attributes=n_static_attrs,
            n_params=DifferentiableM4.N_PARAMS,
            hidden_size=encoder_hidden,
            n_layers=encoder_layers
        )
        
        # M4 模型（无参数，只有计算图）
        self.m4_model = DifferentiableM4()
        
        # KalmanNet 将在后续集成
        # self.kalman_net = None
    
    def create_system_model(self, static_attrs: torch.Tensor, 
                            seq_len: int = 365) -> M4SystemModel:
        """
        根据静态属性创建系统模型实例
        
        Args:
            static_attrs: [Batch, n_static_attrs] 静态属性
            seq_len: 序列长度
            
        Returns:
            M4SystemModel 实例
        """
        # 生成水文参数
        hydro_params = self.static_encoder(static_attrs)
        
        # 创建系统模型
        sys_model = M4SystemModel(
            hydro_params=hydro_params,
            seq_len=seq_len,
            seq_len_test=seq_len
        )
        
        return sys_model
    
    def forward_openloop(self, forcing: torch.Tensor, 
                         static_attrs: torch.Tensor) -> torch.Tensor:
        """
        开环前向传播（不使用 KalmanNet）
        
        用于 Phase 1 训练：让 StaticEncoder 学习物理参数。
        
        Args:
            forcing: [Batch, Time, 3] 气象驱动
            static_attrs: [Batch, n_static_attrs] 静态属性
            
        Returns:
            Q_sim: [Batch, Time, 1] 模拟流量
        """
        # 生成水文参数
        hydro_params = self.static_encoder(static_attrs)
        
        # 运行 M4 模型
        Q_sim, final_states = self.m4_model(forcing, hydro_params)
        
        return Q_sim


# ============================================================================
# 测试代码
# ============================================================================
if __name__ == "__main__":
    print("Testing M4SystemModel adapter...")
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    batch_size = 4
    
    # 创建 StaticEncoder 并生成参数
    encoder = StaticEncoder(n_attributes=16, n_params=10)
    static_attrs = torch.randn(batch_size, 16)
    hydro_params = encoder(static_attrs)
    
    # 创建 M4SystemModel
    sys_model = M4SystemModel(hydro_params=hydro_params, device=device)
    
    print(f"State dimension (m): {sys_model.m}")
    print(f"Observation dimension (n): {sys_model.n}")
    
    # 测试初始状态
    x0 = sys_model.get_default_initial_state()
    print(f"Initial state shape: {x0.shape}")
    
    # 测试状态转移
    forcing = torch.rand(batch_size, 3)  # P, T, PET
    forcing[:, 0] *= 10  # P: 0-10 mm
    forcing[:, 1] = forcing[:, 1] * 20 + 5  # T: 5-25 °C
    forcing[:, 2] *= 5  # PET: 0-5 mm
    
    sys_model.set_forcing(forcing)
    x1 = sys_model.f(x0)
    print(f"Next state shape: {x1.shape}")
    
    # 测试观测函数
    y = sys_model.h(x1)
    print(f"Observation shape: {y.shape}")
    print(f"Observation values: {y.squeeze().detach().numpy()}")
    
    # 测试 GlobalHydroSystem
    print("\nTesting GlobalHydroSystem...")
    global_system = GlobalHydroSystem(n_static_attrs=16)
    
    forcing_seq = torch.rand(batch_size, 30, 3)
    Q_sim = global_system.forward_openloop(forcing_seq, static_attrs)
    print(f"Simulated Q shape: {Q_sim.shape}")
    
    print("\n[OK] M4SystemModel adapter test passed!")
