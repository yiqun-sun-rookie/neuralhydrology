"""Numerical and information contracts for conventional UKF baselines.

The original filter implementations remain untouched.  These helpers live in
the experiment repository because they define how a hydrological driver keeps
physical state means, covariance matrices, and evaluation information valid.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Tuple

import numpy as np
import torch


@dataclass(frozen=True)
class CovarianceRepairDiagnostics:
    """Independent eigenvalue evidence from one covariance repair call."""

    pre_min_eigenvalue: float
    post_min_eigenvalue: float
    repaired_matrix_count: int
    matrix_count: int
    eigenvalue_floor: float
    effective_eigenvalue_floor: float


@dataclass(frozen=True)
class ResidualVarianceDiagnostics:
    """Provenance for a calibration-derived observation variance."""

    reference_period: str
    valid_pair_count: int
    residual_standard_deviation: float
    residual_fraction: float
    variance_floor: float


def _validate_covariance(covariance: torch.Tensor) -> None:
    if not torch.is_tensor(covariance) or covariance.ndim < 2:
        raise ValueError("covariance must be a tensor with at least two dimensions")
    if covariance.shape[-1] != covariance.shape[-2]:
        raise ValueError("covariance matrices must be square")
    if not covariance.dtype.is_floating_point:
        raise ValueError("covariance must use a floating-point dtype")
    if not bool(torch.isfinite(covariance).all()):
        raise ValueError("covariance contains nonfinite values")


def repair_covariance_psd(
    covariance: torch.Tensor,
    *,
    eigenvalue_floor: float,
) -> Tuple[torch.Tensor, CovarianceRepairDiagnostics]:
    """Symmetrize and project covariance matrices onto a positive-definite cone.

    Merely adding a fixed epsilon to the diagonal cannot repair an eigenvalue
    more negative than that epsilon.  This routine floors the actual symmetric
    eigenvalues, reconstructs the matrix, and independently checks the result.
    The leading dimensions, device, and dtype are preserved.
    """

    _validate_covariance(covariance)
    if not math.isfinite(eigenvalue_floor) or eigenvalue_floor <= 0.0:
        raise ValueError("eigenvalue_floor must be positive and finite")

    original_dtype = covariance.dtype
    work_dtype = (
        torch.float64
        if original_dtype in (torch.float16, torch.bfloat16, torch.float32)
        else original_dtype
    )
    symmetric = 0.5 * (covariance + covariance.transpose(-1, -2))
    symmetric_work = symmetric.to(work_dtype)
    eigenvalues, eigenvectors = torch.linalg.eigh(symmetric_work)
    minimum_before = eigenvalues[..., 0]
    dimension = covariance.shape[-1]
    scale = eigenvalues.abs().amax(dim=-1).clamp(min=1.0)
    # In float32 a tiny absolute eigenvalue can disappear when the largest
    # eigenvalue is many orders of magnitude larger.  Use a scale-aware floor
    # large enough to survive reconstruction and conversion to the caller dtype.
    roundoff_floor = (
        torch.finfo(original_dtype).eps * float(8 * dimension) * scale
    )
    requested_floor = torch.as_tensor(
        eigenvalue_floor, dtype=work_dtype, device=covariance.device
    )
    effective_floor = torch.maximum(roundoff_floor, requested_floor)
    floored = torch.maximum(eigenvalues, effective_floor.unsqueeze(-1))
    repaired_work = (
        eigenvectors @ torch.diag_embed(floored) @ eigenvectors.transpose(-1, -2)
    )
    repaired = repaired_work.to(original_dtype)
    repaired = 0.5 * (repaired + repaired.transpose(-1, -2))

    # Independently check the matrix after conversion to the caller dtype.  Add
    # a scale-aware diagonal deficit iteratively; fail closed if the requested
    # positive-definite contract cannot be represented.
    identity = torch.eye(dimension, dtype=repaired.dtype, device=repaired.device)
    for _ in range(4):
        post_eigenvalues = torch.linalg.eigvalsh(repaired.to(work_dtype))
        deficit = torch.clamp(effective_floor - post_eigenvalues[..., 0], min=0.0)
        if not bool((deficit > 0.0).any()):
            break
        addition = deficit + effective_floor
        repaired = repaired + addition.to(repaired.dtype)[..., None, None] * identity
        repaired = 0.5 * (repaired + repaired.transpose(-1, -2))
    post_eigenvalues = torch.linalg.eigvalsh(repaired.to(work_dtype))
    if bool((post_eigenvalues[..., 0] < requested_floor).any()):
        raise FloatingPointError(
            "covariance could not satisfy the requested eigenvalue floor in its working dtype"
        )

    diagnostics = CovarianceRepairDiagnostics(
        pre_min_eigenvalue=float(minimum_before.min().detach().cpu()),
        post_min_eigenvalue=float(post_eigenvalues[..., 0].min().detach().cpu()),
        repaired_matrix_count=int((minimum_before < eigenvalue_floor).sum().detach().cpu()),
        matrix_count=int(minimum_before.numel()),
        eigenvalue_floor=float(eigenvalue_floor),
        effective_eigenvalue_floor=float(effective_floor.max().detach().cpu()),
    )
    return repaired, diagnostics


def recenter_covariance(
    covariance: torch.Tensor,
    *,
    source_mean: torch.Tensor,
    replacement_mean: torch.Tensor,
) -> torch.Tensor:
    """Express a covariance about a replacement mean without losing spread.

    If propagated sigma points have mean ``source_mean`` and their covariance is
    then paired with a different deterministic mean, the correct second central
    moment about that replacement is ``P + d dT`` where
    ``d = source_mean - replacement_mean``.
    """

    _validate_covariance(covariance)
    if source_mean.shape != replacement_mean.shape:
        raise ValueError("source and replacement means must have identical shapes")
    if source_mean.shape != covariance.shape[:-1]:
        raise ValueError("mean shape must match covariance leading and state dimensions")
    if not bool(torch.isfinite(source_mean).all()) or not bool(
        torch.isfinite(replacement_mean).all()
    ):
        raise ValueError("means contain nonfinite values")
    displacement = (source_mean - replacement_mean).unsqueeze(-1)
    recentered = covariance + displacement @ displacement.transpose(-1, -2)
    return 0.5 * (recentered + recentered.transpose(-1, -2))


def condition_covariance_on_projected_channels(
    covariance: torch.Tensor,
    *,
    source_mean: torch.Tensor,
    replacement_mean: torch.Tensor,
    eigenvalue_floor: float,
) -> torch.Tensor:
    """Condition covariance on coordinates fixed by a hard projection.

    A clipped coordinate lies on an active physical boundary.  Treating the
    rejected displacement as uncertainty (``P + d dT``) immediately restores
    spread across the forbidden side of that boundary.  This helper instead
    removes covariance rows and columns for coordinates changed by projection
    and assigns only the declared numerical variance floor on their diagonal.
    Unchanged coordinates and their mutual covariance are preserved.
    """

    _validate_covariance(covariance)
    if source_mean.shape != replacement_mean.shape:
        raise ValueError("source and replacement means must have identical shapes")
    if source_mean.shape != covariance.shape[:-1]:
        raise ValueError("mean shape must match covariance leading and state dimensions")
    if not math.isfinite(eigenvalue_floor) or eigenvalue_floor <= 0.0:
        raise ValueError("eigenvalue_floor must be positive and finite")
    if not bool(torch.isfinite(source_mean).all()) or not bool(
        torch.isfinite(replacement_mean).all()
    ):
        raise ValueError("means contain nonfinite values")

    conditioned = covariance.clone()
    active = source_mean != replacement_mean
    for batch_index in range(conditioned.shape[0]):
        indices = torch.nonzero(active[batch_index], as_tuple=False).reshape(-1)
        for state_index in indices.tolist():
            conditioned[batch_index, state_index, :] = 0.0
            conditioned[batch_index, :, state_index] = 0.0
            conditioned[batch_index, state_index, state_index] = eigenvalue_floor
    return 0.5 * (conditioned + conditioned.transpose(-1, -2))


def project_nonnegative_prefix(
    state: torch.Tensor,
    *,
    nonnegative_prefix_length: int,
) -> tuple[torch.Tensor, int]:
    """Clamp a declared physical prefix to zero while preserving other states."""

    if state.ndim != 2:
        raise ValueError("state must have shape [batch, state_dimension]")
    if not 0 <= nonnegative_prefix_length <= state.shape[1]:
        raise ValueError("nonnegative prefix is outside the state vector")
    if not bool(torch.isfinite(state).all()):
        raise ValueError("state contains nonfinite values")
    projected = state.clone()
    prefix = projected[:, :nonnegative_prefix_length]
    projected[:, :nonnegative_prefix_length] = torch.clamp(prefix, min=0.0)
    changed = int(torch.count_nonzero(projected != state).detach().cpu())
    return projected, changed


def project_hbvlite_state(
    state: torch.Tensor,
    *,
    field_capacity: torch.Tensor,
    routing_length: int,
    has_signed_bias: bool,
) -> tuple[torch.Tensor, int]:
    """Project an HBV-light routed mean onto its physical state domain.

    Layout is ``[snow, meltwater, soil, upper, lower, routing..., bias?]``.
    All physical channels are nonnegative and soil moisture cannot exceed the
    basin's field capacity.  The optional additive or multiplicative bias state
    remains signed.
    """

    if state.ndim != 2:
        raise ValueError("state must have shape [batch, state_dimension]")
    if routing_length < 1:
        raise ValueError("routing_length must be positive")
    expected_dimension = 5 + routing_length + (1 if has_signed_bias else 0)
    if state.shape[1] != expected_dimension:
        raise ValueError(
            f"state dimension {state.shape[1]} does not match HBV routed layout {expected_dimension}"
        )
    if field_capacity.numel() not in (1, state.shape[0]):
        raise ValueError("field_capacity must be scalar or have one value per batch row")
    capacity = field_capacity.to(device=state.device, dtype=state.dtype).reshape(-1, 1)
    if capacity.shape[0] == 1 and state.shape[0] > 1:
        capacity = capacity.expand(state.shape[0], 1)
    if not bool(torch.isfinite(state).all()) or not bool(torch.isfinite(capacity).all()):
        raise ValueError("state and field capacity must be finite")
    if bool((capacity <= 0.0).any()):
        raise ValueError("field capacity must be positive")

    physical_dimension = 5 + routing_length
    projected = state.clone()
    projected[:, :physical_dimension] = torch.clamp(
        projected[:, :physical_dimension], min=0.0
    )
    projected[:, 2:3] = torch.minimum(projected[:, 2:3], capacity)
    changed = int(torch.count_nonzero(projected != state).detach().cpu())
    return projected, changed


def project_hbvlite_assimilation_state(
    state: torch.Tensor,
    *,
    field_capacity: torch.Tensor,
    routing_length: int,
    has_signed_bias: bool,
) -> tuple[torch.Tensor, int]:
    """Project HBV storages while retaining signed routing corrections.

    Layout is ``[snow, meltwater, soil, upper, lower, routing..., bias?]``.
    The five HBV storages are physical and therefore nonnegative, with soil
    moisture capped at field capacity.  Routing-memory channels are left
    signed because, under this assimilation contract, they carry corrections
    to a physical runoff queue rather than physical runoff values themselves.
    The optional bias state also remains signed.
    """

    if state.ndim != 2:
        raise ValueError("state must have shape [batch, state_dimension]")
    if routing_length < 1:
        raise ValueError("routing_length must be positive")
    expected_dimension = 5 + routing_length + (1 if has_signed_bias else 0)
    if state.shape[1] != expected_dimension:
        raise ValueError(
            f"state dimension {state.shape[1]} does not match HBV routed layout {expected_dimension}"
        )
    if field_capacity.numel() not in (1, state.shape[0]):
        raise ValueError("field_capacity must be scalar or have one value per batch row")
    capacity = field_capacity.to(device=state.device, dtype=state.dtype).reshape(-1, 1)
    if capacity.shape[0] == 1 and state.shape[0] > 1:
        capacity = capacity.expand(state.shape[0], 1)
    if not bool(torch.isfinite(state).all()) or not bool(torch.isfinite(capacity).all()):
        raise ValueError("state and field capacity must be finite")
    if bool((capacity <= 0.0).any()):
        raise ValueError("field capacity must be positive")

    projected = state.clone()
    projected[:, :5] = torch.clamp(projected[:, :5], min=0.0)
    projected[:, 2:3] = torch.minimum(projected[:, 2:3], capacity)
    changed = int(torch.count_nonzero(projected != state).detach().cpu())
    return projected, changed


def estimate_calibration_residual_variance(
    observed: np.ndarray,
    simulated: np.ndarray,
    *,
    residual_fraction: float,
    variance_floor: float,
    reference_period: str,
) -> tuple[float, ResidualVarianceDiagnostics]:
    """Estimate base observation variance from paired calibration residuals.

    The explicit period argument is a fail-closed guard: an evaluation residual
    series cannot silently choose a filter noise value used to score that same
    evaluation period.
    """

    if reference_period != "calibration":
        raise ValueError("observation variance must be fitted from calibration data only")
    if not math.isfinite(residual_fraction) or residual_fraction <= 0.0:
        raise ValueError("residual_fraction must be positive and finite")
    if not math.isfinite(variance_floor) or variance_floor <= 0.0:
        raise ValueError("variance_floor must be positive and finite")
    observed_array = np.asarray(observed, dtype=float).reshape(-1)
    simulated_array = np.asarray(simulated, dtype=float).reshape(-1)
    if observed_array.shape != simulated_array.shape:
        raise ValueError("observed and simulated series must have identical shapes")
    valid = np.isfinite(observed_array) & np.isfinite(simulated_array)
    valid_count = int(valid.sum())
    if valid_count < 2:
        raise ValueError("at least two finite calibration residual pairs are required")
    residual_standard_deviation = float(
        np.std(observed_array[valid] - simulated_array[valid])
    )
    if not math.isfinite(residual_standard_deviation):
        raise ValueError("calibration residual standard deviation is nonfinite")
    variance = max(
        (float(residual_fraction) * residual_standard_deviation) ** 2,
        float(variance_floor),
    )
    diagnostics = ResidualVarianceDiagnostics(
        reference_period=reference_period,
        valid_pair_count=valid_count,
        residual_standard_deviation=residual_standard_deviation,
        residual_fraction=float(residual_fraction),
        variance_floor=float(variance_floor),
    )
    return variance, diagnostics


def select_innovation_gate_scale(
    *,
    noise_reference: str,
    observation_variance: float,
    calibration_diagnostics: ResidualVarianceDiagnostics | None,
    legacy_evaluation_scale: float | None = None,
) -> tuple[float, str]:
    """Choose an innovation-gate scale without silently reading evaluation errors.

    Calibration-derived filters reuse the calibration residual standard
    deviation.  A fully predeclared filter uses the standard deviation implied
    by its declared observation variance.  Evaluation-derived scales are
    accepted only when the caller has already selected the explicitly labelled
    legacy-development mode.
    """

    if not math.isfinite(observation_variance) or observation_variance <= 0.0:
        raise ValueError("observation_variance must be positive and finite")
    if noise_reference == "calibration":
        if calibration_diagnostics is None:
            raise ValueError("calibration diagnostics are required for calibration noise")
        if calibration_diagnostics.reference_period != "calibration":
            raise ValueError("innovation-gate calibration scale has invalid provenance")
        scale = calibration_diagnostics.residual_standard_deviation
        reference = "calibration_residual_standard_deviation"
    elif noise_reference == "fixed_predeclared":
        if calibration_diagnostics is not None or legacy_evaluation_scale is not None:
            raise ValueError("predeclared noise cannot carry fitted residual diagnostics")
        scale = math.sqrt(observation_variance)
        reference = "predeclared_observation_standard_deviation"
    elif noise_reference == "evaluation_legacy_development_only":
        if calibration_diagnostics is not None or legacy_evaluation_scale is None:
            raise ValueError("legacy evaluation mode requires its explicit evaluation scale")
        scale = float(legacy_evaluation_scale)
        reference = "evaluation_legacy_development_only"
    else:
        raise ValueError(f"unknown noise_reference: {noise_reference}")
    if not math.isfinite(scale) or scale <= 0.0:
        raise ValueError("innovation-gate scale must be positive and finite")
    return float(scale), reference
