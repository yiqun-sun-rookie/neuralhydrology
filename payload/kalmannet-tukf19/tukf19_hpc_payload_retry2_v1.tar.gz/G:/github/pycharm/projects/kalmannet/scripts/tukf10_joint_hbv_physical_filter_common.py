"""Common, capability-only primitives for TUKF10 joint parameter learning."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping, Sequence

import torch


ROOT = Path(__file__).resolve().parents[1]
EXPERIMENT_ID = "TUKF10_JOINT_HBV_PHYSICAL_FILTER_PARAMETER_LEARNING_V1"
DEFAULT_CONFIG = (
    ROOT / "configs" / "tukf10_joint_hbv_physical_filter_parameter_learning_v1.json"
)
HASHED_SOURCE_FILES = (
    "configs/tukf10_joint_hbv_physical_filter_parameter_learning_v1.json",
    "src/global_hydrology/models/trainable_hbvlite_ukf_adapter.py",
    "scripts/tukf10_joint_hbv_physical_filter_common.py",
    "scripts/preflight_tukf10_joint_hbv_physical_filter_parameter_learning.py",
    "tests/test_tukf10_joint_hbv_physical_filter_parameter_learning.py",
    "scripts/differentiable_ukf_hbvlite.py",
    "src/global_hydrology/models/differentiable_hbv_lite.py",
    "scripts/tukf06_full_diagonal_common.py",
    "src/global_hydrology/data/hbvlite_prior.py",
    "src/global_hydrology/models/hbvlite_system_model.py",
    "src/global_hydrology/models/hbvlite_ukf_adapter.py",
    "scripts/run_aligned_gr4j_da.py",
    "scripts/run_aligned_gr4j_differentiable_ukf.py",
    "src/global_hydrology/assimilation/conventional_ukf.py",
)

from scripts.differentiable_ukf_hbvlite import run_hbvlite_corrected_ukf
from global_hydrology.models.differentiable_hbv_lite import PARAM_NAMES
from global_hydrology.models.trainable_hbvlite_ukf_adapter import (
    HBV_LITE_V5_PARAMETER_BOUNDS,
    TRAINABLE_HYDROLOGY_PARAMETER_NAMES,
    JointTrainableRoutedHBVLiteUKF,
)


def load_contract(path: Path = DEFAULT_CONFIG) -> dict[str, Any]:
    """Load and strictly validate the capability-only experiment contract."""

    contract = json.loads(Path(path).read_text(encoding="utf-8"))
    if contract.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("TUKF10 experiment identifier changed")
    hydrology = contract.get("hydrology", {})
    if hydrology.get("trainable") != list(TRAINABLE_HYDROLOGY_PARAMETER_NAMES):
        raise ValueError("the twelve trainable hydrology parameters changed")
    if hydrology.get("fixed") != ["lag_time"]:
        raise ValueError("lag_time must remain the sole fixed hydrology parameter")
    if hydrology.get("coordinate") != (
        "v5_bound_normalized_linear_projected_to_closed_unit_interval"
    ):
        raise ValueError("hydrology coordinate contract changed")
    expected_bounds = {
        name: list(HBV_LITE_V5_PARAMETER_BOUNDS[name]) for name in PARAM_NAMES
    }
    if hydrology.get("bounds") != expected_bounds:
        raise ValueError("HBV-lite v5 physical parameter bounds changed")
    filter_contract = contract.get("filter", {})
    if filter_contract.get("process_noise") != {
        "one_per_state": True,
        "lower": 1e-5,
        "upper": 0.1,
    }:
        raise ValueError("process-noise bounds or dimensionality changed")
    if filter_contract.get("observation_noise") != {
        "name": "discharge_proportional_ratio",
        "lower": 0.0025,
        "upper": 0.32,
    }:
        raise ValueError("observation-noise contract changed")
    if contract.get("objective", {}).get("leads_days") != [1, 2, 3]:
        raise ValueError("the equal one-to-three-day objective changed")
    periods = contract.get("periods", {})
    if periods.get("repeated_historical_evaluation") != [
        "1989-10-01",
        "1999-09-30",
    ]:
        raise ValueError("historical evaluation boundary changed")
    if periods.get("evaluation_access") != (
        "prohibited_as_selected_samples_or_objective_inputs"
    ):
        raise ValueError("capability preflight must prohibit evaluation samples")
    if periods.get("loader_raw_file_behavior") != (
        "full_raw_files_loaded_before_requested_date_slice"
    ):
        raise ValueError("raw-file loading behavior must be declared literally")
    if contract.get("data_contract") != {
        "dataset": "CAMELS-US",
        "forcing_product": "Maurer",
        "potential_evaporation_method": "Oudin",
        "discharge_unit": "millimetres_per_day",
        "loader": "scripts/tukf06_full_diagonal_common.py:load_period",
        "initial_storage": (
            "zero_snow_zero_melt_half_base_field_capacity_zero_upper_zero_lower"
        ),
        "initial_storage_uses_future_information": False,
    }:
        raise ValueError("capability data contract changed")
    preflight = contract.get("preflight", {})
    if preflight.get("random_seed") != 0:
        raise ValueError("capability preflight random seed changed")
    if preflight.get("stochastic_draws_expected") is not False:
        raise ValueError("capability preflight must declare no stochastic draws")
    if preflight.get("output") != (
        "artifacts/tukf10_joint_hbv_physical_filter_parameter_learning_v1/"
        "preflight/capability_preflight_v2.json"
    ):
        raise ValueError("capability preflight output path changed")
    if preflight.get("supersedes") != (
        "artifacts/tukf10_joint_hbv_physical_filter_parameter_learning_v1/"
        "preflight/capability_preflight.json"
    ):
        raise ValueError("capability preflight supersession pointer changed")
    if contract.get("code_and_input_files_to_hash") != list(HASHED_SOURCE_FILES):
        raise ValueError("hashed source dependency closure changed")
    return contract


def joint_multilead_objective(
    model: JointTrainableRoutedHBVLiteUKF,
    forcings: torch.Tensor,
    observations: torch.Tensor,
    initial_state: torch.Tensor,
    initial_covariance: torch.Tensor,
    *,
    base_observation_variance: torch.Tensor | float,
    leads: Sequence[int] = (1, 2, 3),
) -> torch.Tensor:
    """Return one loss whose graph contains hydrology, process noise, and observation noise."""

    selected_leads = tuple(int(lead) for lead in leads)
    if not selected_leads or selected_leads != tuple(range(1, max(selected_leads) + 1)):
        raise ValueError("leads must be consecutive positive integers beginning at one")
    forcings = torch.as_tensor(forcings, dtype=model.dtype, device=model.device)
    observations = torch.as_tensor(observations, dtype=model.dtype, device=model.device)
    initial_state = torch.as_tensor(initial_state, dtype=model.dtype, device=model.device)
    initial_covariance = torch.as_tensor(
        initial_covariance, dtype=model.dtype, device=model.device
    )
    if model.batch_size != 1:
        raise ValueError("TUKF10 capability objective currently requires one basin per model")
    if forcings.ndim != 3 or forcings.shape[1:] != (1, 3):
        raise ValueError("forcings must be [T,1,3]")
    if observations.shape != (forcings.shape[0], 1):
        raise ValueError("observations must be [T,1]")
    if initial_state.shape != (1, model.dim_x):
        raise ValueError("initial_state shape does not match the routed model")
    if initial_covariance.shape != (1, model.dim_x, model.dim_x):
        raise ValueError("initial_covariance shape does not match the routed model")
    if forcings.shape[0] <= max(selected_leads):
        raise ValueError("forecast period is too short for the requested leads")
    base_variance = torch.as_tensor(
        base_observation_variance, dtype=model.dtype, device=model.device
    )
    if not bool(torch.isfinite(base_variance).all()) or bool(torch.any(base_variance <= 0)):
        raise ValueError("base_observation_variance must be finite and positive")

    projected_initial_state = model.project_mean(initial_state)
    result = run_hbvlite_corrected_ukf(
        model,
        forcings,
        observations,
        projected_initial_state,
        initial_covariance,
        model.process_diagonal(),
        base_observation_variance=base_variance,
        r_b=model.observation_ratio(),
        project_mean=model.project_mean,
    )
    posterior = result["posterior_state"]
    if posterior.shape != (forcings.shape[0], 1, model.dim_x):
        raise RuntimeError("corrected filter returned an unexpected posterior shape")
    if not bool(torch.isfinite(posterior).all()):
        raise FloatingPointError("joint filter posterior is non-finite")

    origin_count = posterior.shape[0] - max(selected_leads)
    state = posterior[:origin_count, 0, :]
    total = torch.zeros((), dtype=model.dtype, device=model.device)
    for lead in selected_leads:
        state = model.f(state, forcings[lead:origin_count + lead, 0, :])
        forecast = model.h(state)[:, 0]
        target = observations[lead:origin_count + lead, 0]
        finite = torch.isfinite(target)
        if not bool(finite.any()):
            raise FloatingPointError(f"no finite lead-{lead} targets")
        total = total + ((forecast[finite] - target[finite]) ** 2).mean()
    value = total / len(selected_leads)
    if not bool(torch.isfinite(value)):
        raise FloatingPointError("joint multi-lead objective is non-finite")
    return value


def _gradient_statistics(parameter: torch.nn.Parameter | None) -> dict[str, Any]:
    if parameter is None:
        return {
            "count": 0,
            "finite": False,
            "nonzero_count": 0,
            "l2_norm": 0.0,
            "maximum_absolute": 0.0,
        }
    gradient = parameter.grad
    if gradient is None:
        return {
            "count": int(parameter.numel()),
            "finite": False,
            "nonzero_count": 0,
            "l2_norm": 0.0,
            "maximum_absolute": 0.0,
        }
    values = gradient.detach()
    finite = bool(torch.isfinite(values).all())
    finite_values = values if finite else torch.nan_to_num(values)
    return {
        "count": int(values.numel()),
        "finite": finite,
        "nonzero_count": int(torch.count_nonzero(finite_values).item()),
        "l2_norm": float(torch.linalg.vector_norm(finite_values)),
        "maximum_absolute": float(torch.max(torch.abs(finite_values))),
    }


def joint_gradient_report(
    model: JointTrainableRoutedHBVLiteUKF,
) -> dict[str, dict[str, Any]]:
    """Summarize gradients without converting a zero process into a failure silently."""

    return {
        "hydrology": _gradient_statistics(model.hydrology_coordinates),
        "process_noise": _gradient_statistics(model.log_process_diagonal),
        "observation_noise": _gradient_statistics(model.log_observation_ratio),
    }


def validate_joint_gradient_report(report: Mapping[str, Mapping[str, Any]]) -> None:
    """Require finite and non-zero evidence for every jointly learned group."""

    for group in ("hydrology", "process_noise", "observation_noise"):
        if group not in report:
            raise ValueError(f"gradient report is missing {group}")
        row = report[group]
        if not bool(row.get("finite")):
            raise ValueError(f"{group} gradient is missing or non-finite")
        if int(row.get("count", 0)) < 1:
            raise ValueError(f"{group} gradient group is empty")
        if int(row.get("nonzero_count", 0)) < 1:
            raise ValueError(f"{group} gradient is identically zero")


def parameter_snapshot(model: JointTrainableRoutedHBVLiteUKF) -> dict[str, Any]:
    """Return JSON-ready trainable and physical values for audit artifacts."""

    hydrology_coordinates = (
        []
        if model.hydrology_coordinates is None
        else model.hydrology_coordinates.detach().cpu().tolist()
    )
    return {
        "hydrology_parameter_names": list(PARAM_NAMES),
        "trainable_hydrology_names": list(model.trainable_hydrology_names),
        "hydrology_coordinates": hydrology_coordinates,
        "physical_parameters": model.physical_parameter_tensor().detach().cpu().tolist(),
        "process_noise_diagonal": model.process_diagonal().detach().cpu().tolist(),
        "observation_noise_ratio": float(model.observation_ratio().detach()),
        "fixed_lag_time": model.fixed_lag_time.detach().cpu().tolist(),
        "state_dimension": int(model.dim_x),
    }
