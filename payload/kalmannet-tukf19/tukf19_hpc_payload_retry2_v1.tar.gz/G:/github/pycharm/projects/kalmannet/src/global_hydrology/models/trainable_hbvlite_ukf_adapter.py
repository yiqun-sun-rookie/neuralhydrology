"""TUKF10-only routed HBV-lite model with live physical and noise parameters.

This module deliberately does not modify the frozen HBV-lite system model or
sigma-point adapter used by TUKF04--TUKF09.  It reuses the verified
``DifferentiableHBVLite.forward_step`` equations while keeping twelve continuous
physical parameters in the same autograd graph as the corrected differentiable
unscented Kalman filter.  ``lag_time`` and routing weights stay fixed because the
existing routing contract uses ``ceil(lag_time)`` to choose the state dimension.
"""
from __future__ import annotations

from collections.abc import Sequence
from typing import Optional

import torch
from torch import nn

from .differentiable_hbv_lite import DifferentiableHBVLite, N_STATES, PARAM_NAMES


HBV_LITE_V5_PARAMETER_BOUNDS: dict[str, tuple[float, float]] = {
    "parTT": (-2.5, 2.5),
    "parCFMAX": (0.5, 15.0),
    "parCFR": (0.0, 0.1),
    "parCWH": (0.0, 0.2),
    "parFC": (50.0, 2500.0),
    "parBETA": (1.0, 6.0),
    "parLP": (0.2, 1.0),
    "parK0": (0.05, 0.99),
    "parK1": (0.01, 0.5),
    "parUZL": (0.0, 200.0),
    "parPERC": (0.0, 30.0),
    "parK2": (0.0001, 0.5),
    "lag_time": (1.0, 15.0),
}

TRAINABLE_HYDROLOGY_PARAMETER_NAMES = tuple(PARAM_NAMES[:-1])


def _finite_tensor(value: torch.Tensor, *, name: str) -> None:
    if not bool(torch.isfinite(value).all()):
        raise ValueError(f"{name} must be finite")


def _straight_through_closed_clamp(
    value: torch.Tensor, *, lower: torch.Tensor, upper: torch.Tensor
) -> torch.Tensor:
    """Return a strictly bounded value while preserving the incoming gradient.

    ``exp(log(lower))`` can round a few units outside a decimal bound in float64.
    A second ordinary clamp would then make the projected boundary an absorbing
    zero-gradient state.  This straight-through form keeps the exact forward
    bound while allowing an optimizer step whose gradient points back inward.
    """

    bounded = value.clamp(min=lower, max=upper)
    return value + (bounded - value).detach()


class JointTrainableRoutedHBVLiteUKF(nn.Module):
    """Routed HBV-lite duck type with jointly trainable physical and noise terms.

    The module itself is passed to ``run_hbvlite_corrected_ukf`` through
    ``set_forcing``/``fx``/``hx``.  The same object supplies ``f``/``h`` for
    deterministic multi-origin forecasts, preventing a stale or detached copy of
    the hydrological parameters from entering the forecast loss.
    """

    def __init__(
        self,
        base_parameters: torch.Tensor,
        lag_weights: torch.Tensor,
        *,
        initial_process_diagonal: torch.Tensor | float,
        initial_observation_ratio: torch.Tensor | float,
        trainable_hydrology_names: Sequence[str] = TRAINABLE_HYDROLOGY_PARAMETER_NAMES,
        process_noise_bounds: tuple[float, float] = (1e-5, 0.1),
        observation_ratio_bounds: tuple[float, float] = (0.0025, 0.32),
        clamp_storage: bool = True,
        clamp_indices: Sequence[int] = (0, 1, 2, 3, 4),
        signed_routing_memory: bool = False,
        device: Optional[torch.device] = None,
        dtype: torch.dtype = torch.float64,
    ) -> None:
        super().__init__()
        self.device = device or torch.device("cpu")
        self.dtype = dtype
        self.clamp_storage = bool(clamp_storage)
        self.clamp_indices = tuple(int(index) for index in clamp_indices)
        self.signed_routing_memory = bool(signed_routing_memory)

        base = torch.as_tensor(base_parameters, dtype=dtype, device=self.device)
        if base.ndim != 2 or base.shape[1] != len(PARAM_NAMES):
            raise ValueError(
                f"base_parameters must be [B,{len(PARAM_NAMES)}], got {tuple(base.shape)}"
            )
        if base.shape[0] != 1:
            raise ValueError(
                "joint-learning adapter currently supports exactly one basin per model"
            )
        _finite_tensor(base, name="base_parameters")
        for index, name in enumerate(PARAM_NAMES):
            lower, upper = HBV_LITE_V5_PARAMETER_BOUNDS[name]
            values = base[:, index]
            if bool(torch.any(values < lower)) or bool(torch.any(values > upper)):
                raise ValueError(
                    f"base parameter {name} lies outside v5 bounds [{lower}, {upper}]"
                )

        weights = torch.as_tensor(lag_weights, dtype=dtype, device=self.device)
        if weights.ndim != 2 or weights.shape[0] != base.shape[0] or weights.shape[1] < 1:
            raise ValueError("lag_weights must be [B,L] with the same B as base_parameters")
        _finite_tensor(weights, name="lag_weights")
        if bool(torch.any(weights < 0.0)):
            raise ValueError("lag_weights must be nonnegative")
        if not torch.allclose(
            weights.sum(dim=-1), torch.ones(weights.shape[0], dtype=dtype, device=self.device),
            rtol=1e-12, atol=1e-12,
        ):
            raise ValueError("each lag-weight row must sum to one")

        names = tuple(str(name) for name in trainable_hydrology_names)
        if len(set(names)) != len(names):
            raise ValueError("trainable hydrology names must be unique")
        unknown = [name for name in names if name not in PARAM_NAMES]
        if unknown:
            raise ValueError(f"unknown hydrology parameters: {unknown}")
        if "lag_time" in names:
            raise ValueError(
                "lag_time cannot be gradient-trained under the fixed routing-state contract"
            )
        self.trainable_hydrology_names = names
        self._trainable_positions = {name: position for position, name in enumerate(names)}
        indices = [PARAM_NAMES.index(name) for name in names]

        self.register_buffer("base_parameters", base.detach().clone())
        self.register_buffer("fixed_routing_weights", weights.detach().clone())
        lag_index = PARAM_NAMES.index("lag_time")
        self.register_buffer(
            "fixed_lag_time", base[:, lag_index:lag_index + 1].detach().clone()
        )
        self.batch_size = int(base.shape[0])
        self.routing_length = int(weights.shape[1])
        self.m_phys = N_STATES + self.routing_length
        self.dim_x = self.m_phys
        self.num_sigmas = 2 * self.dim_x + 1
        required_length = int(torch.ceil(self.fixed_lag_time).max().item())
        if self.routing_length < required_length:
            raise ValueError(
                f"routing length {self.routing_length} is shorter than fixed lag requirement "
                f"{required_length}"
            )

        if names:
            lower = torch.tensor(
                [HBV_LITE_V5_PARAMETER_BOUNDS[name][0] for name in names],
                dtype=dtype,
                device=self.device,
            ).unsqueeze(0)
            upper = torch.tensor(
                [HBV_LITE_V5_PARAMETER_BOUNDS[name][1] for name in names],
                dtype=dtype,
                device=self.device,
            ).unsqueeze(0)
            span = upper - lower
            coordinates = (base[:, indices] - lower) / span
            if bool(torch.any(coordinates < 0.0)) or bool(torch.any(coordinates > 1.0)):
                raise ValueError("encoded v5 hydrology coordinates lie outside [0,1]")
            self.register_buffer("_hydrology_lower", lower)
            self.register_buffer("_hydrology_span", span)
            self.hydrology_coordinates = nn.Parameter(coordinates.detach().clone())
        else:
            self.register_buffer(
                "_hydrology_lower", torch.empty(1, 0, dtype=dtype, device=self.device)
            )
            self.register_buffer(
                "_hydrology_span", torch.empty(1, 0, dtype=dtype, device=self.device)
            )
            self.register_parameter("hydrology_coordinates", None)

        q_lower, q_upper = (float(value) for value in process_noise_bounds)
        r_lower, r_upper = (float(value) for value in observation_ratio_bounds)
        if not (0.0 < q_lower < q_upper) or not (0.0 < r_lower < r_upper):
            raise ValueError("noise bounds must be finite, positive, and ordered")
        process = torch.as_tensor(
            initial_process_diagonal, dtype=dtype, device=self.device
        ).reshape(-1)
        if process.numel() == 1:
            process = process.repeat(self.dim_x)
        if process.shape != (self.dim_x,):
            raise ValueError(
                f"initial_process_diagonal must contain {self.dim_x} values"
            )
        _finite_tensor(process, name="initial_process_diagonal")
        if bool(torch.any(process < q_lower)) or bool(torch.any(process > q_upper)):
            raise ValueError("initial process noise lies outside configured bounds")
        observation = torch.as_tensor(
            initial_observation_ratio, dtype=dtype, device=self.device
        ).reshape(())
        _finite_tensor(observation, name="initial_observation_ratio")
        if not (r_lower <= float(observation) <= r_upper):
            raise ValueError("initial observation ratio lies outside configured bounds")

        self.register_buffer(
            "_log_process_lower", torch.tensor(q_lower, dtype=dtype, device=self.device).log()
        )
        self.register_buffer(
            "_log_process_upper", torch.tensor(q_upper, dtype=dtype, device=self.device).log()
        )
        self.register_buffer(
            "_log_observation_lower", torch.tensor(r_lower, dtype=dtype, device=self.device).log()
        )
        self.register_buffer(
            "_log_observation_upper", torch.tensor(r_upper, dtype=dtype, device=self.device).log()
        )
        self.register_buffer(
            "_process_lower", torch.tensor(q_lower, dtype=dtype, device=self.device)
        )
        self.register_buffer(
            "_process_upper", torch.tensor(q_upper, dtype=dtype, device=self.device)
        )
        self.register_buffer(
            "_observation_lower", torch.tensor(r_lower, dtype=dtype, device=self.device)
        )
        self.register_buffer(
            "_observation_upper", torch.tensor(r_upper, dtype=dtype, device=self.device)
        )
        self.log_process_diagonal = nn.Parameter(process.log().detach().clone())
        self.log_observation_ratio = nn.Parameter(observation.log().detach().clone())
        self._model = DifferentiableHBVLite()
        self._forcing: Optional[torch.Tensor] = None

    def physical_parameter_tensor(self) -> torch.Tensor:
        """Return the current `[B,13]` physical tensor without detaching it."""

        decoded: dict[str, torch.Tensor] = {}
        if self.hydrology_coordinates is not None:
            coordinates = self.hydrology_coordinates.clamp(0.0, 1.0)
            values = self._hydrology_lower + coordinates * self._hydrology_span
            for name, position in self._trainable_positions.items():
                decoded[name] = values[:, position:position + 1]
        columns = []
        for index, name in enumerate(PARAM_NAMES):
            if name == "lag_time":
                columns.append(self.fixed_lag_time)
            elif name in decoded:
                columns.append(decoded[name])
            else:
                columns.append(self.base_parameters[:, index:index + 1])
        return torch.cat(columns, dim=-1)

    def process_diagonal(self) -> torch.Tensor:
        raw = torch.exp(
            self.log_process_diagonal.clamp(
                min=self._log_process_lower, max=self._log_process_upper
            )
        )
        return _straight_through_closed_clamp(
            raw, lower=self._process_lower, upper=self._process_upper
        )

    def observation_ratio(self) -> torch.Tensor:
        raw = torch.exp(
            self.log_observation_ratio.clamp(
                min=self._log_observation_lower, max=self._log_observation_upper
            )
        )
        return _straight_through_closed_clamp(
            raw, lower=self._observation_lower, upper=self._observation_upper
        )

    @torch.no_grad()
    def project_trainable_coordinates_(self) -> None:
        """Project every optimizer coordinate back into its frozen closed bounds."""

        if self.hydrology_coordinates is not None:
            self.hydrology_coordinates.clamp_(0.0, 1.0)
        self.log_process_diagonal.clamp_(
            min=self._log_process_lower, max=self._log_process_upper
        )
        self.log_observation_ratio.clamp_(
            min=self._log_observation_lower, max=self._log_observation_upper
        )

    def _expand_rows(self, table: torch.Tensor, rows: int, *, name: str) -> torch.Tensor:
        if table.shape[0] == rows:
            return table
        if table.shape[0] == 1:
            return table.expand(rows, -1)
        raise ValueError(
            f"{name} has {table.shape[0]} basin rows and cannot expand to {rows} rows"
        )

    def _parameter_dict_for_rows(self, rows: int) -> dict[str, torch.Tensor]:
        table = self._expand_rows(
            self.physical_parameter_tensor(), rows, name="physical parameters"
        )
        return {name: table[:, index:index + 1] for index, name in enumerate(PARAM_NAMES)}

    def _transition_rows(self, state: torch.Tensor, forcing: torch.Tensor) -> torch.Tensor:
        if state.ndim != 2 or state.shape[1] != self.dim_x:
            raise ValueError(f"state must be [N,{self.dim_x}]")
        if forcing.ndim == 1:
            forcing = forcing.unsqueeze(0)
        if forcing.ndim != 2 or forcing.shape[1] != 3:
            raise ValueError("forcing must be [N,3] in (precipitation, temperature, PET) order")
        if forcing.shape[0] == 1 and state.shape[0] > 1:
            forcing = forcing.expand(state.shape[0], -1)
        if forcing.shape[0] != state.shape[0]:
            raise ValueError("forcing and state row counts differ")
        forcing = forcing.to(device=self.device, dtype=self.dtype)
        state = state.to(device=self.device, dtype=self.dtype)
        storage = state[:, :N_STATES]
        if self.clamp_storage and self.clamp_indices:
            pieces = []
            clamped = set(self.clamp_indices)
            for index in range(N_STATES):
                column = storage[:, index:index + 1]
                pieces.append(torch.clamp(column, min=0.0) if index in clamped else column)
            storage = torch.cat(pieces, dim=-1)
        parameters = self._parameter_dict_for_rows(state.shape[0])
        next_storage, runoff = self._model.forward_step(
            storage,
            forcing[:, 0:1],
            forcing[:, 2:3],
            forcing[:, 1:2],
            parameters,
        )
        routing = state[:, N_STATES:N_STATES + self.routing_length]
        next_routing = torch.cat(
            [runoff, routing[:, :self.routing_length - 1]], dim=-1
        )
        return torch.cat([next_storage, next_routing], dim=-1)

    def set_forcing(self, forcing: torch.Tensor) -> None:
        forcing = torch.as_tensor(forcing, dtype=self.dtype, device=self.device)
        if forcing.shape != (self.batch_size, 3):
            raise ValueError(
                f"filter forcing must be [{self.batch_size},3], got {tuple(forcing.shape)}"
            )
        self._forcing = forcing

    def fx(self, sigmas: torch.Tensor, dt: float = 1.0) -> torch.Tensor:
        del dt
        if self._forcing is None:
            raise ValueError("call set_forcing before fx")
        if sigmas.ndim != 3 or sigmas.shape[0] != self.batch_size:
            raise ValueError("sigmas must be [B,S,m] with the configured basin batch")
        batch, sigma_count, dimension = sigmas.shape
        if dimension != self.dim_x:
            raise ValueError("sigma-point state dimension changed")
        flat = sigmas.reshape(batch * sigma_count, dimension)
        forcing = self._forcing.repeat_interleave(sigma_count, dim=0)
        return self._transition_rows(flat, forcing).reshape(batch, sigma_count, dimension)

    def hx(self, sigmas: torch.Tensor) -> torch.Tensor:
        if sigmas.ndim != 3 or sigmas.shape[0] != self.batch_size:
            raise ValueError("sigmas must be [B,S,m] with the configured basin batch")
        batch, sigma_count, dimension = sigmas.shape
        if dimension != self.dim_x:
            raise ValueError("sigma-point state dimension changed")
        return self.h(sigmas.reshape(batch * sigma_count, dimension)).reshape(
            batch, sigma_count, 1
        )

    def f(self, state: torch.Tensor, forcing: torch.Tensor) -> torch.Tensor:
        """Deterministic routed step for all multi-lead forecast origins."""

        if state.ndim == 1:
            state = state.unsqueeze(0)
        return self._transition_rows(state, forcing)

    def h(self, state: torch.Tensor) -> torch.Tensor:
        """Routed discharge for filter sigma points or deterministic forecasts."""

        if state.ndim == 1:
            state = state.unsqueeze(0)
        if state.ndim != 2 or state.shape[1] != self.dim_x:
            raise ValueError(f"state must be [N,{self.dim_x}]")
        weights = self._expand_rows(
            self.fixed_routing_weights, state.shape[0], name="routing weights"
        )
        routing = state[:, N_STATES:N_STATES + self.routing_length]
        discharge = (routing * weights).sum(dim=-1, keepdim=True)
        return discharge if self.signed_routing_memory else torch.clamp(discharge, min=0.0)

    def project_mean(self, state: torch.Tensor) -> torch.Tensor:
        """Apply the TUKF06 mean projection using the current learned field capacity."""

        if state.ndim != 2 or state.shape[1] != self.dim_x:
            raise ValueError(f"state must be [N,{self.dim_x}]")
        storage = torch.clamp(state[:, :N_STATES], min=0.0)
        parameters = self._expand_rows(
            self.physical_parameter_tensor(), state.shape[0], name="physical parameters"
        )
        field_capacity = parameters[:, PARAM_NAMES.index("parFC"):PARAM_NAMES.index("parFC") + 1]
        soil = torch.minimum(storage[:, 2:3], field_capacity)
        routing = torch.clamp(state[:, N_STATES:], min=0.0)
        return torch.cat(
            [storage[:, :2], soil, storage[:, 3:5], routing], dim=-1
        )
