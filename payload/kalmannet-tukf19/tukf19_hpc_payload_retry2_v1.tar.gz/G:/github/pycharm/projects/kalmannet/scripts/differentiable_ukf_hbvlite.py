"""Differentiable HBV-lite UKF with the corrected measurement update (TUKF04 stage 1).

Fuses the half of each existing engine that the three-way independent audit
(2026-08-07) confirmed correct, and nothing else:

- **redraw sigma points before the measurement update** (filters BatchUKF path,
  Wan & van der Merwe original flow): the process noise added to the prior
  covariance reaches the innovation variance and the cross covariance;
- **the general constrained-gain covariance update** (GR4J line,
  ``constrained_covariance_update``): exact for the damped / localized gain
  actually executed, replacing the optimal-gain formula plus the realized
  -innovation ``d dT`` recentering patch whose daily error is
  ``(I-D) K (nu^2 - S) K^T (I-D)``;
- **flow-proportional observation variance inside the day loop**,
  ``R_t = max(base, (r_b * max(z_hat, obs, 0))**2)``, with ``r_b`` a tensor so
  gradients flow to it (the discrete grid pinned 12/21 basins at the r_b edge).

Everything from the filters repository and the GR4J line is imported read-only;
neither is modified. Mean projection after predict and after update keeps the
legacy driver's recenter bookkeeping so the loc_mult=1, constant-R setting can
be compared against the legacy engine directly.
"""

from __future__ import annotations

from pathlib import Path
import sys
from typing import Any, Callable, Sequence

import torch

ROOT = Path(__file__).resolve().parents[1]
for _extra in (str(ROOT), str(ROOT / "src")):
    if _extra not in sys.path:
        sys.path.insert(0, _extra)

from scripts.run_aligned_gr4j_da import constrained_covariance_update  # noqa: E402  (read-only reuse)
from scripts.run_aligned_gr4j_differentiable_ukf import (  # noqa: E402  (read-only reuse)
    stable_covariance_functional,
)
from global_hydrology.assimilation.conventional_ukf import recenter_covariance  # noqa: E402


def merwe_weights(
    dimension: int,
    *,
    alpha: float,
    beta: float = 2.0,
    kappa: float = 0.0,
    dtype: torch.dtype = torch.float64,
    device: torch.device | str = "cpu",
) -> tuple[torch.Tensor, torch.Tensor, float]:
    """Return (Wm, Wc, c) exactly as the legacy MerwePoints holder computes them."""
    if alpha <= 0.0 or beta < 0.0:
        raise ValueError("alpha must be positive and beta nonnegative")
    scaling = alpha * alpha * (dimension + kappa)
    if scaling <= 0.0:
        raise ValueError("dimension + kappa must give positive sigma scaling")
    lam = scaling - dimension
    base = 0.5 / scaling
    mean_weights = torch.full((2 * dimension + 1,), base, dtype=dtype, device=device)
    covariance_weights = mean_weights.clone()
    mean_weights[0] = lam / scaling
    covariance_weights[0] = lam / scaling + (1.0 - alpha * alpha + beta)
    return mean_weights, covariance_weights, scaling


def batched_sigma_points(
    mean: torch.Tensor, covariance: torch.Tensor, scaling: float
) -> torch.Tensor:
    """Draw 2m+1 sigma points per batch row from Cholesky columns of c*P.

    Column convention matches the legacy driver's ``stable_sigma_points``. The
    caller must hand in an already-stabilized covariance; a failed factorization
    is a stop condition, not something to be papered over.
    """
    if mean.ndim != 2 or covariance.shape != mean.shape + (mean.shape[-1],):
        raise ValueError("mean must be [B,m] and covariance [B,m,m]")
    if not torch.isfinite(mean).all() or not torch.isfinite(covariance).all():
        raise ValueError("sigma-point inputs must be finite")
    root = torch.linalg.cholesky(scaling * covariance)  # [B,m,m], lower
    points = [mean]
    for index in range(mean.shape[-1]):
        column = root[:, :, index]
        points.append(mean + column)
        points.append(mean - column)
    return torch.stack(points, dim=1)  # [B, 2m+1, m]


def _stabilize(covariance: torch.Tensor, floor: float) -> torch.Tensor:
    """Batched differentiable spectral floor (read-only reuse of the GR4J functional)."""
    return torch.stack(
        [stable_covariance_functional(covariance[b], floor=floor) for b in range(covariance.shape[0])]
    )


def run_hbvlite_corrected_ukf(
    model: Any,
    forcings: torch.Tensor,
    observations: torch.Tensor,
    initial_state: torch.Tensor,
    initial_covariance: torch.Tensor,
    process_diagonal: torch.Tensor,
    *,
    base_observation_variance: torch.Tensor | float,
    r_b: torch.Tensor | None = None,
    localization_multiplier: float = 1.0,
    localization_indices: Sequence[int] = (),
    project_mean: Callable[[torch.Tensor], torch.Tensor] | None = None,
    alpha: float = 0.3,
    beta: float = 2.0,
    kappa: float = 0.0,
    covariance_floor: float = 1e-12,
) -> dict[str, torch.Tensor]:
    """Run the corrected filter over [T] days; every output keeps the autograd graph.

    ``model`` duck-types the routed adapter: ``set_forcing(u[B,3])``,
    ``fx(sig[B,S,m]) -> [B,S,m]``, ``hx(sig[B,S,m]) -> [B,S,1]``.
    ``process_diagonal`` is the positive per-state process variance ([m] or
    [B,m]); parameterize positivity (e.g. exp of logs) in the caller.
    ``r_b=None`` disables the flow-proportional term entirely (constant R),
    which is the configuration the legacy-equivalence test runs.
    """
    if forcings.ndim != 3 or forcings.shape[-1] != 3:
        raise ValueError("forcings must be [T,B,3]")
    days, batch = forcings.shape[0], forcings.shape[1]
    if observations.shape != (days, batch):
        raise ValueError("observations must be [T,B]")
    mean = initial_state.clone()
    dtype, device = mean.dtype, mean.device
    dimension = mean.shape[-1]
    if mean.shape != (batch, dimension):
        raise ValueError("initial_state must be [B,m]")
    covariance = _stabilize(initial_covariance.clone(), covariance_floor)
    q_diag = process_diagonal.to(dtype=dtype, device=device)
    if q_diag.ndim == 1:
        q_diag = q_diag.unsqueeze(0).expand(batch, -1)
    if not torch.all(q_diag > 0):
        raise ValueError("process_diagonal must be strictly positive")
    base_var = torch.as_tensor(base_observation_variance, dtype=dtype, device=device)
    base_var = base_var.reshape(-1).expand(batch) if base_var.ndim <= 1 else base_var
    if not torch.all(base_var > 0):
        raise ValueError("base_observation_variance must be strictly positive")

    mean_weights, covariance_weights, scaling = merwe_weights(
        dimension, alpha=alpha, beta=beta, kappa=kappa, dtype=dtype, device=device
    )
    damping = torch.ones(dimension, dtype=dtype, device=device)
    for index in localization_indices:
        damping[index] = localization_multiplier

    out: dict[str, list[torch.Tensor]] = {
        "prediction": [], "prior_state": [], "posterior_state": [],
        "observation_variance": [], "innovation": [],
    }
    for day in range(days):
        model.set_forcing(forcings[day])
        # ---- predict: draw from the posterior, propagate, add Q (legacy order)
        sigmas = batched_sigma_points(mean, covariance, scaling)
        propagated = model.fx(sigmas)
        prior_raw = torch.einsum("s,bsm->bm", mean_weights, propagated)
        deviation = propagated - prior_raw.unsqueeze(1)
        prior_covariance = torch.einsum(
            "s,bsi,bsj->bij", covariance_weights, deviation, deviation
        ) + torch.diag_embed(q_diag)
        prior_covariance = _stabilize(prior_covariance, covariance_floor)
        prior_mean = project_mean(prior_raw) if project_mean is not None else prior_raw
        if project_mean is not None and not torch.equal(prior_mean, prior_raw):
            prior_covariance = recenter_covariance(
                prior_covariance, source_mean=prior_raw, replacement_mean=prior_mean
            )
            prior_covariance = _stabilize(prior_covariance, covariance_floor)

        # ---- update: REDRAW from (prior mean, prior covariance): Q reaches S and C
        update_sigmas = batched_sigma_points(prior_mean, prior_covariance, scaling)
        observed = model.hx(update_sigmas)[..., 0]  # [B,S]
        predicted = torch.einsum("s,bs->b", mean_weights, observed)
        observation = torch.nan_to_num(observations[day], nan=0.0)
        available = torch.isfinite(observations[day])
        flow_level = torch.clamp(torch.maximum(predicted, observation), min=0.0)
        if r_b is not None:
            observation_variance = torch.maximum(base_var, (r_b * flow_level) ** 2)
        else:
            observation_variance = base_var.expand(batch)
        observed_deviation = observed - predicted.unsqueeze(1)
        innovation_variance = torch.einsum(
            "s,bs,bs->b", covariance_weights, observed_deviation, observed_deviation
        ) + observation_variance
        state_deviation = update_sigmas - prior_mean.unsqueeze(1)
        cross = torch.einsum(
            "s,bsm,bs->bm", covariance_weights, state_deviation, observed_deviation
        )
        gain = cross / innovation_variance.unsqueeze(-1)
        executed_gain = gain * damping
        innovation = observation - predicted
        updated_mean = prior_mean + executed_gain * innovation.unsqueeze(-1)
        posterior_rows = []
        for b in range(batch):
            posterior_rows.append(
                constrained_covariance_update(
                    prior_covariance[b],
                    cross[b].unsqueeze(-1),
                    innovation_variance[b].reshape(1, 1),
                    executed_gain[b].unsqueeze(-1),
                )
            )
        updated_covariance = _stabilize(torch.stack(posterior_rows), covariance_floor)
        keep = available.to(dtype).unsqueeze(-1)
        posterior_raw = keep * updated_mean + (1.0 - keep) * prior_mean
        posterior_covariance = (
            keep.unsqueeze(-1) * updated_covariance
            + (1.0 - keep.unsqueeze(-1)) * prior_covariance
        )
        posterior_mean = (
            project_mean(posterior_raw) if project_mean is not None else posterior_raw
        )
        if project_mean is not None and not torch.equal(posterior_mean, posterior_raw):
            posterior_covariance = recenter_covariance(
                posterior_covariance,
                source_mean=posterior_raw,
                replacement_mean=posterior_mean,
            )
            posterior_covariance = _stabilize(posterior_covariance, covariance_floor)
        if not torch.isfinite(posterior_mean).all() or not torch.isfinite(
            posterior_covariance
        ).all():
            raise FloatingPointError(f"nonfinite filter state on day {day}")

        out["prediction"].append(predicted)
        out["prior_state"].append(prior_mean)
        out["posterior_state"].append(posterior_mean)
        out["observation_variance"].append(observation_variance)
        out["innovation"].append(innovation)
        mean, covariance = posterior_mean, posterior_covariance

    return {name: torch.stack(values) for name, values in out.items()}
