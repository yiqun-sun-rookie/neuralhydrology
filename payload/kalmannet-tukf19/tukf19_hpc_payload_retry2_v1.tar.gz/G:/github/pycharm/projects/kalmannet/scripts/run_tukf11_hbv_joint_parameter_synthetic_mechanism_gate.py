"""Run the frozen TUKF11 synthetic joint-parameter mechanism gate.

This runner owns orchestration and artifact writing only.  The experiment
contract, independent NumPy truth generator, causal segmented objective, model
builder, optimizer groups, and recovery metrics live in the TUKF11 common
module.  Existing TUKF04--TUKF10 sources and artifacts are read-only inputs.
"""

from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
from importlib import metadata as importlib_metadata
import json
import math
import os
from pathlib import Path
import platform
import sys
from typing import Any, Mapping, Sequence

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
for _candidate in (ROOT, ROOT / "src"):
    if str(_candidate) not in sys.path:
        sys.path.insert(0, str(_candidate))

from global_hydrology.models.differentiable_hbv_lite import (  # noqa: E402
    PARAM_NAMES,
    recession_half_weights,
)
from global_hydrology.models.trainable_hbvlite_ukf_adapter import (  # noqa: E402
    HBV_LITE_V5_PARAMETER_BOUNDS,
    TRAINABLE_HYDROLOGY_PARAMETER_NAMES,
    JointTrainableRoutedHBVLiteUKF,
)
from scripts.tukf10_joint_hbv_physical_filter_common import (  # noqa: E402
    joint_multilead_objective,
)
from scripts.tukf11_hbv_joint_parameter_synthetic_common import (  # noqa: E402
    DEFAULT_CONFIG,
    EXPERIMENT_ID,
    HASHED_SOURCE_FILES,
    build_forcing,
    build_grouped_adam,
    build_joint_model,
    clip_active_groups_,
    generate_independent_truth,
    load_contract,
    recovery_metrics,
    resolve_output_path,
    restore_trainables_,
    segmented_multilead_objective,
    sha256_array,
    sha256_file,
    snapshot_trainables,
)


DTYPE = torch.float64
DEVICE = torch.device("cpu")
LEADS = (1, 2, 3)
EXPECTED_FORCING_SHA256 = (
    "1b5a92901896a3108eafd74d9b1913a65aae7615f169a87a92ddb26576aab5c3"
)
EXPECTED_PREFLIGHT_OBJECTIVE = 0.5259205315088843
DEFAULT_PREFLIGHT_RELATIVE = (
    "artifacts/tukf11_hbv_joint_parameter_synthetic_mechanism_gate_v1/"
    "preflight/engineering_preflight.json"
)
DEFAULT_FORMAL_RELATIVE = (
    "results/tukf11_hbv_joint_parameter_synthetic_mechanism_gate_v1"
)
PREFLIGHT_SCHEMA_VERSION = "tukf11_engineering_preflight_v1"
ENVIRONMENT_SCHEMA_VERSION = "tukf11_runtime_environment_v1"
REQUIRED_ENGINEERING_CHECKS = frozenset(
    {
        "forcing_hash_matches",
        "independent_truth_matches",
        "objective_matches",
        "all_gradients_nonzero",
        "all_groups_changed",
        "lag_and_dimension_fixed",
        "fixed_point_valid",
        "projection_fraction_valid",
        "proportional_branch_fraction_valid",
    }
)


def _minimal_environment() -> dict[str, Any]:
    """Return only the frozen numerical runtime and two approved controls."""

    try:
        numba_version = importlib_metadata.version("numba")
    except importlib_metadata.PackageNotFoundError:
        numba_version = "UNAVAILABLE"

    def approved_environment_value(name: str) -> str:
        return str(os.environ[name]) if name in os.environ else "UNSET"

    return {
        "schema_version": ENVIRONMENT_SCHEMA_VERSION,
        "python_version": platform.python_version(),
        "numpy_version": str(np.__version__),
        "pytorch_version": str(torch.__version__),
        "numba_version": str(numba_version),
        "device": "cpu",
        "dtype": "float64",
        "torch_threads": int(torch.get_num_threads()),
        "environment_variables": {
            "DISABLE_NUMBA": approved_environment_value("DISABLE_NUMBA"),
            "HBV_BOUNDS": approved_environment_value("HBV_BOUNDS"),
        },
    }


def _configure_environment(contract: Mapping[str, Any]) -> dict[str, Any]:
    """Apply and attest the frozen CPU-float64 thread contract."""

    numerical = contract.get("numerical_environment")
    if not isinstance(numerical, Mapping):
        raise ValueError("TUKF11 numerical_environment contract is missing")
    if (
        str(numerical.get("device")) != "cpu"
        or str(numerical.get("torch_dtype")) != "float64"
        or str(numerical.get("numpy_dtype")) != "float64"
        or DEVICE.type != "cpu"
        or DTYPE is not torch.float64
    ):
        raise RuntimeError("TUKF11 requires CPU float64 execution")
    threads = int(numerical["torch_threads"])
    if threads != 1:
        raise RuntimeError("TUKF11 requires exactly one PyTorch compute thread")
    torch.set_num_threads(threads)
    environment = _minimal_environment()
    if (
        environment["device"] != "cpu"
        or environment["dtype"] != "float64"
        or environment["torch_threads"] != threads
    ):
        raise RuntimeError("TUKF11 runtime differs from its CPU float64 contract")
    return environment


def _jsonable(value: Any) -> Any:
    """Convert tensors, arrays, paths, and NumPy scalars to strict JSON values."""

    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, torch.Tensor):
        return _jsonable(value.detach().cpu().numpy())
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("refusing to serialize a non-finite float")
    return value


def _write_new_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(
        _jsonable(payload),
        indent=2,
        sort_keys=True,
        ensure_ascii=False,
        allow_nan=False,
    ) + "\n"
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def _write_new_npz(path: Path, arrays: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    normalized: dict[str, np.ndarray] = {}
    for key, value in arrays.items():
        array = np.asarray(value)
        if array.dtype == object:
            raise ValueError(f"object array is prohibited in persisted NPZ: {key}")
        if np.issubdtype(array.dtype, np.number) and not np.isfinite(array).all():
            raise ValueError(f"non-finite array is prohibited in persisted NPZ: {key}")
        normalized[str(key)] = np.ascontiguousarray(array)
    with path.open("xb") as handle:
        np.savez_compressed(handle, **normalized)


def _write_new_torch(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as handle:
        torch.save(dict(payload), handle)


def create_new_output_directory(path: Path) -> Path:
    """Create exactly one new output directory and refuse every existing target."""

    resolved = Path(path).resolve()
    resolved.mkdir(parents=True, exist_ok=False)
    return resolved


def select_checkpoint(history: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    """Select minimum registered selection loss; an exact tie selects earlier update."""

    if not history:
        raise ValueError("selection history is empty")
    validated: list[dict[str, Any]] = []
    seen_updates: set[int] = set()
    for raw in history:
        row = dict(raw)
        update = int(row.get("update", -1))
        loss = float(row.get("selection_loss", float("nan")))
        if update < 0 or update in seen_updates:
            raise ValueError("selection updates must be unique nonnegative integers")
        if not math.isfinite(loss):
            raise ValueError("selection loss must be finite")
        seen_updates.add(update)
        row["update"] = update
        row["selection_loss"] = loss
        validated.append(row)
    return min(validated, key=lambda row: (row["selection_loss"], row["update"]))


def _source_path(raw: str | Path) -> Path:
    path = Path(raw)
    return path.resolve() if path.is_absolute() else (ROOT / path).resolve()


def _source_hashes() -> dict[str, str]:
    hashes: dict[str, str] = {}
    for raw in HASHED_SOURCE_FILES:
        path = _source_path(raw)
        if not path.is_file():
            raise FileNotFoundError(f"hashed TUKF11 dependency is missing: {path}")
        hashes[str(raw).replace("\\", "/")] = sha256_file(path)
    return hashes


def _output_value(contract: Mapping[str, Any], kind: str, default: str) -> str:
    outputs = contract.get("outputs", {})
    candidates = {
        "preflight": (
            "preflight_report",
            "preflight",
            "preflight_output",
            "engineering_preflight",
            "engineering_preflight_path",
        ),
        "formal": ("formal", "formal_root", "formal_output", "result_root"),
    }[kind]
    for key in candidates:
        value = outputs.get(key)
        if isinstance(value, str) and value:
            return value
    return default


def _project_output_path(raw: str, required_root: Path) -> Path:
    """Resolve one project-relative output and enforce its dedicated subtree."""

    resolved = resolve_output_path(raw, ROOT)
    try:
        resolved.relative_to(required_root.resolve())
    except ValueError as exc:
        raise ValueError(
            f"configured output escapes its required root {required_root}: {raw}"
        ) from exc
    return resolved


def _preflight_path(contract: Mapping[str, Any]) -> Path:
    relative = _output_value(contract, "preflight", DEFAULT_PREFLIGHT_RELATIVE)
    return _project_output_path(relative, ROOT / "artifacts")


def _formal_root(contract: Mapping[str, Any]) -> Path:
    relative = _output_value(contract, "formal", DEFAULT_FORMAL_RELATIVE)
    return _project_output_path(relative, ROOT / "results")


def _truth_contract(contract: Mapping[str, Any]) -> Mapping[str, Any]:
    truth = contract.get("truth")
    if not isinstance(truth, Mapping):
        raise ValueError("TUKF11 truth contract is missing")
    return truth


def _segments(contract: Mapping[str, Any]) -> Mapping[str, int]:
    values = contract.get("segments")
    if not isinstance(values, Mapping):
        raise ValueError("TUKF11 segments are missing")
    return {str(key): int(value) for key, value in values.items()}


def _truth_values(contract: Mapping[str, Any]) -> dict[str, Any]:
    truth = _truth_contract(contract)
    parameters = np.asarray(truth["hydrology_parameters"], dtype=np.float64)
    process = np.asarray(truth["process_nominal_variances"], dtype=np.float64)
    initial_state = np.asarray(truth["initial_state"], dtype=np.float64)
    if parameters.shape != (13,):
        raise ValueError("truth hydrology_parameters must contain 13 values")
    if process.shape != (8,):
        raise ValueError("truth process_nominal_variances must contain 8 values")
    if initial_state.shape != (8,):
        raise ValueError("truth initial_state must contain 8 values")
    if not (
        np.isfinite(parameters).all()
        and np.isfinite(process).all()
        and np.isfinite(initial_state).all()
    ):
        raise ValueError("truth arrays must be finite")
    return {
        "parameters": parameters,
        "process_variances": process,
        "observation_ratio": float(truth["observation_residual_ratio"]),
        "base_variance": float(truth["base_observation_variance"]),
        "initial_state": initial_state,
    }


def _truth_generation_values(contract: Mapping[str, Any]) -> dict[str, float]:
    values = contract.get("truth_generation", {})
    return {
        "denominator_margin": float(
            values.get("minimum_fixed_point_denominator_margin", 1e-6)
        ),
        "fixed_point_tolerance": float(
            values.get("observation_fixed_point_tolerance", 1e-12)
        ),
        "maximum_projection_fraction": float(
            values.get("maximum_projected_state_element_fraction", 0.10)
        ),
        "minimum_proportional_branch_fraction": float(
            values.get("minimum_proportional_branch_fraction", 0.50)
        ),
    }


def _initial_covariance(
    model: JointTrainableRoutedHBVLiteUKF, contract: Mapping[str, Any]
) -> torch.Tensor:
    diagonal = float(_truth_contract(contract)["initial_covariance_diagonal"])
    if not math.isfinite(diagonal) or diagonal <= 0.0:
        raise ValueError("initial covariance diagonal must be positive and finite")
    return torch.eye(model.dim_x, dtype=DTYPE, device=DEVICE).unsqueeze(0) * diagonal


def _tensor_inputs(
    forcing: np.ndarray,
    observations: np.ndarray,
    initial_state: np.ndarray,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    return (
        torch.tensor(forcing, dtype=DTYPE, device=DEVICE).unsqueeze(1),
        torch.tensor(observations, dtype=DTYPE, device=DEVICE).unsqueeze(1),
        torch.tensor(initial_state, dtype=DTYPE, device=DEVICE).reshape(1, -1),
    )


def _standard_normals(days: int, truth_seed: int) -> tuple[np.ndarray, np.ndarray]:
    process_generator = np.random.Generator(np.random.PCG64(100000 + int(truth_seed)))
    observation_generator = np.random.Generator(np.random.PCG64(200000 + int(truth_seed)))
    process = process_generator.standard_normal((days, 8), dtype=np.float64)
    observation = observation_generator.standard_normal(days, dtype=np.float64)
    return np.ascontiguousarray(process), np.ascontiguousarray(observation)


def _generate_truth(
    contract: Mapping[str, Any],
    *,
    days: int,
    truth_seed: int | None,
) -> tuple[np.ndarray, dict[str, Any]]:
    values = _truth_values(contract)
    forcing = build_forcing(days)
    if forcing.shape != (days, 3) or forcing.dtype != np.float64:
        raise ValueError("frozen forcing must be NumPy float64 with shape [T,3]")
    if truth_seed is None:
        process_normals = np.zeros((days, 8), dtype=np.float64)
        observation_normals = np.zeros(days, dtype=np.float64)
    else:
        process_normals, observation_normals = _standard_normals(days, truth_seed)
    generation = _truth_generation_values(contract)
    result = generate_independent_truth(
        values["parameters"],
        forcing,
        values["initial_state"],
        values["process_variances"] if truth_seed is not None else np.zeros(8),
        process_normals,
        observation_normals,
        observation_ratio=values["observation_ratio"],
        base_observation_variance=values["base_variance"],
        denominator_margin=generation["denominator_margin"],
        fixed_point_tolerance=generation["fixed_point_tolerance"],
        maximum_projection_fraction=generation["maximum_projection_fraction"],
        minimum_proportional_branch_fraction=generation[
            "minimum_proportional_branch_fraction"
        ],
    )
    return forcing, dict(result)


def _truth_diagnostics(result: Mapping[str, Any], contract: Mapping[str, Any]) -> dict[str, float]:
    del contract
    return {
        "fixed_point_max_abs_error": float(
            result["fixed_point_max_absolute_error"]
        ),
        "minimum_fixed_point_denominator": float(
            result["minimum_fixed_point_denominator"]
        ),
        "projection_fraction": float(result["projection_fraction"]),
        "proportional_branch_fraction": float(
            result["proportional_branch_fraction"]
        ),
    }


def _fixed_parameter_model(
    parameters_array: np.ndarray,
    process_variances: np.ndarray,
    observation_ratio: float,
) -> JointTrainableRoutedHBVLiteUKF:
    parameters = torch.tensor(parameters_array, dtype=DTYPE).reshape(1, -1)
    lag = parameters[:, PARAM_NAMES.index("lag_time"):]
    length = int(torch.ceil(lag).max().item())
    weights = recession_half_weights(lag, length)
    return JointTrainableRoutedHBVLiteUKF(
        parameters,
        weights,
        initial_process_diagonal=torch.tensor(process_variances, dtype=DTYPE),
        initial_observation_ratio=float(observation_ratio),
        trainable_hydrology_names=(),
        clamp_storage=True,
        dtype=DTYPE,
        device=DEVICE,
    )


def _pytorch_deterministic_truth(
    parameters: np.ndarray,
    initial_state: np.ndarray,
    forcing: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    model = _fixed_parameter_model(
        parameters,
        np.full(8, 0.001, dtype=np.float64),
        0.05,
    )
    initial = torch.tensor(initial_state, dtype=DTYPE, device=DEVICE).reshape(1, -1)
    state = initial
    states = [state[0].clone()]
    discharge: list[torch.Tensor] = []
    forcing_tensor = torch.tensor(forcing, dtype=DTYPE, device=DEVICE)
    with torch.no_grad():
        for day in range(forcing.shape[0]):
            state = model.project_mean(model.f(state, forcing_tensor[day]))
            states.append(state[0].clone())
            discharge.append(model.h(state)[0, 0].clone())
    return (
        torch.stack(states).cpu().numpy(),
        torch.stack(discharge).cpu().numpy(),
    )


def _capability_probe_values(contract: Mapping[str, Any]) -> dict[str, Any]:
    probe = contract.get("capability_probe")
    if not isinstance(probe, Mapping):
        raise ValueError("TUKF11 capability_probe contract is missing")
    values = {
        "learner_parameters": np.asarray(
            probe["learner_hydrology_parameters"], dtype=np.float64
        ),
        "truth_parameters": np.asarray(
            probe["truth_hydrology_parameters"], dtype=np.float64
        ),
        "initial_state": np.asarray(probe["initial_state"], dtype=np.float64),
        "process_variances": np.asarray(
            probe["initial_process_variances"], dtype=np.float64
        ),
        "observation_ratio": float(probe["initial_observation_ratio"]),
        "base_variance": float(probe["base_observation_variance"]),
        "initial_covariance_diagonal": float(
            probe["initial_covariance_diagonal"]
        ),
    }
    if values["learner_parameters"].shape != (13,) or values[
        "truth_parameters"
    ].shape != (13,):
        raise ValueError("capability-probe hydrology parameters must contain 13 values")
    if values["initial_state"].shape != (8,) or values[
        "process_variances"
    ].shape != (8,):
        raise ValueError("capability-probe state and process vectors must contain 8 values")
    return values


def _build_capability_probe_model(
    contract: Mapping[str, Any],
) -> JointTrainableRoutedHBVLiteUKF:
    probe = _capability_probe_values(contract)
    parameters = torch.tensor(
        probe["learner_parameters"], dtype=DTYPE, device=DEVICE
    ).reshape(1, -1)
    lag = parameters[:, PARAM_NAMES.index("lag_time"):]
    length = int(torch.ceil(lag).max().item())
    if length != 3:
        raise ValueError("capability-probe routing length must remain three")
    return JointTrainableRoutedHBVLiteUKF(
        parameters,
        recession_half_weights(lag, length),
        initial_process_diagonal=torch.tensor(
            probe["process_variances"], dtype=DTYPE, device=DEVICE
        ),
        initial_observation_ratio=probe["observation_ratio"],
        trainable_hydrology_names=TRAINABLE_HYDROLOGY_PARAMETER_NAMES,
        clamp_storage=True,
        dtype=DTYPE,
        device=DEVICE,
    )


def _gradient_summary(model: JointTrainableRoutedHBVLiteUKF) -> dict[str, Any]:
    groups = {
        "hydrology": model.hydrology_coordinates,
        "process_noise": model.log_process_diagonal,
        "observation_scale": model.log_observation_ratio,
    }
    summary: dict[str, Any] = {}
    for name, parameter in groups.items():
        if parameter is None or parameter.grad is None:
            summary[name] = {
                "count": 0 if parameter is None else int(parameter.numel()),
                "finite_count": 0,
                "nonzero_count": 0,
                "maximum_absolute": 0.0,
            }
            continue
        gradient = parameter.grad.detach()
        finite = torch.isfinite(gradient)
        summary[name] = {
            "count": int(gradient.numel()),
            "finite_count": int(finite.sum()),
            "nonzero_count": int(torch.count_nonzero(gradient[finite])),
            "maximum_absolute": float(gradient[finite].abs().max())
            if bool(finite.any())
            else float("nan"),
        }
    return summary


def _gradient_arrays(
    model: JointTrainableRoutedHBVLiteUKF,
) -> dict[str, np.ndarray]:
    parameters = {
        "hydrology": model.hydrology_coordinates,
        "process_noise": model.log_process_diagonal,
        "observation_scale": model.log_observation_ratio,
    }
    arrays: dict[str, np.ndarray] = {}
    for name, parameter in parameters.items():
        if parameter is None or parameter.grad is None:
            raise RuntimeError(f"missing {name} gradient in capability probe")
        value = parameter.grad.detach().cpu().numpy().astype(np.float64, copy=True)
        if not np.isfinite(value).all():
            raise FloatingPointError(f"non-finite {name} capability-probe gradient")
        arrays[name] = value.reshape(-1)
    return arrays


def _snapshot_changed(before: Mapping[str, Any], after: Mapping[str, Any], key: str) -> bool:
    return not np.array_equal(np.asarray(before[key]), np.asarray(after[key]))


def _failure_preflight_path(
    contract: Mapping[str, Any], preflight_path: Path
) -> Path:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    outputs = contract.get("outputs", {})
    raw_root = outputs.get("preflight_failure_root")
    if isinstance(raw_root, str) and raw_root:
        root = _project_output_path(raw_root, ROOT / "artifacts")
    else:
        root = preflight_path.parent / "failures"
    return root / f"engineering_preflight_failure_{stamp}.json"


def run_preflight(contract: Mapping[str, Any]) -> dict[str, Any]:
    """Run the frozen one-update engineering gate and write one new report."""

    environment = _configure_environment(contract)
    source_before = _source_hashes()
    report: dict[str, Any]
    try:
        probe_contract = contract["capability_probe"]
        engineering = contract["gates"]["engineering"]
        probe = _capability_probe_values(contract)
        forcing = build_forcing(int(probe_contract["days"]))
        probe_days = int(probe_contract["days"])
        independent = generate_independent_truth(
            probe["truth_parameters"],
            forcing,
            probe["initial_state"],
            np.zeros(8, dtype=np.float64),
            np.zeros((probe_days, 8), dtype=np.float64),
            np.zeros(probe_days, dtype=np.float64),
            observation_ratio=probe["observation_ratio"],
            base_observation_variance=probe["base_variance"],
            denominator_margin=_truth_generation_values(contract)[
                "denominator_margin"
            ],
            fixed_point_tolerance=_truth_generation_values(contract)[
                "fixed_point_tolerance"
            ],
            maximum_projection_fraction=_truth_generation_values(contract)[
                "maximum_projection_fraction"
            ],
            minimum_proportional_branch_fraction=0.0,
        )
        forcing_hash = sha256_array(forcing)
        pytorch_states, pytorch_discharge = _pytorch_deterministic_truth(
            probe["truth_parameters"], probe["initial_state"], forcing
        )
        observation_hash = sha256_array(pytorch_discharge)
        independent_observation_hash = sha256_array(
            np.asarray(independent["observations"], dtype=np.float64)
        )
        state_difference = float(
            np.max(np.abs(np.asarray(independent["states"]) - pytorch_states))
        )
        discharge_difference = float(
            np.max(
                np.abs(
                    np.asarray(independent["clean_discharge"]) - pytorch_discharge
                )
            )
        )

        model = _build_capability_probe_model(contract)
        forcing_tensor, observation_tensor, initial_state = _tensor_inputs(
            forcing,
            pytorch_discharge,
            probe["initial_state"],
        )
        covariance = (
            torch.eye(model.dim_x, dtype=DTYPE, device=DEVICE).unsqueeze(0)
            * probe["initial_covariance_diagonal"]
        )
        optimizer = build_grouped_adam(model, contract)
        optimizer.zero_grad(set_to_none=True)
        before = snapshot_trainables(model)
        objective = joint_multilead_objective(
            model,
            forcing_tensor,
            observation_tensor,
            initial_state,
            covariance,
            base_observation_variance=probe["base_variance"],
            leads=LEADS,
        )
        if not bool(torch.isfinite(objective)):
            raise FloatingPointError("preflight objective is non-finite")
        objective.backward()
        gradients = _gradient_summary(model)
        gradient_arrays = _gradient_arrays(model)
        clip_norms = clip_active_groups_(
            model, float(contract["optimizer"]["group_gradient_norm"])
        )
        optimizer.step()
        model.project_trainable_coordinates_()
        after = snapshot_trainables(model)

        stochastic: dict[str, Any] = {}
        generation = _truth_generation_values(contract)
        for seed in contract["truth_seeds"]:
            _, result = _generate_truth(contract, days=192, truth_seed=int(seed))
            stochastic[str(seed)] = _truth_diagnostics(result, contract)

        expected_counts = probe_contract["expected_nonzero_gradient_counts"]
        gradient_tolerance = float(probe_contract["objective_absolute_tolerance"])
        expected_hydrology_gradient = np.asarray(
            probe_contract["expected_hydrology_coordinate_gradients"],
            dtype=np.float64,
        )
        expected_process_gradient = np.asarray(
            probe_contract["expected_process_log_gradients"], dtype=np.float64
        )
        expected_observation_gradient = np.asarray(
            [probe_contract["expected_observation_log_gradient"]], dtype=np.float64
        )
        checks = {
            "forcing_sha256": forcing_hash
            == str(engineering["forcing_sha256_required"])
            == str(probe_contract["forcing_raw_c_float64_sha256"]),
            "observation_sha256": observation_hash
            == str(probe_contract["observations_raw_c_float64_sha256"]),
            "independent_state_parity": state_difference
            <= float(engineering["numpy_pytorch_state_max_absolute_error"]),
            "independent_discharge_parity": discharge_difference
            <= float(engineering["numpy_pytorch_discharge_max_absolute_error"]),
            "objective_exact": abs(
                float(objective.detach()) - float(probe_contract["expected_objective"])
            )
            <= float(probe_contract["objective_absolute_tolerance"]),
            "hydrology_gradients_12_of_12": gradients["hydrology"]["finite_count"]
            == int(expected_counts["hydrology"])
            and gradients["hydrology"]["nonzero_count"]
            == int(engineering["required_hydrology_nonzero_gradients"]),
            "process_gradients_8_of_8": gradients["process_noise"]["finite_count"]
            == int(expected_counts["process_noise"])
            and gradients["process_noise"]["nonzero_count"]
            == int(engineering["required_process_nonzero_gradients"]),
            "observation_gradient_1_of_1": gradients["observation_scale"][
                "finite_count"
            ]
            == int(expected_counts["observation_noise"])
            and gradients["observation_scale"]["nonzero_count"]
            == int(engineering["required_observation_nonzero_gradients"]),
            "hydrology_gradient_values": bool(
                np.allclose(
                    gradient_arrays["hydrology"],
                    expected_hydrology_gradient,
                    rtol=0.0,
                    atol=gradient_tolerance,
                )
            ),
            "process_gradient_values": bool(
                np.allclose(
                    gradient_arrays["process_noise"],
                    expected_process_gradient,
                    rtol=0.0,
                    atol=gradient_tolerance,
                )
            ),
            "observation_gradient_value": bool(
                np.allclose(
                    gradient_arrays["observation_scale"],
                    expected_observation_gradient,
                    rtol=0.0,
                    atol=gradient_tolerance,
                )
            ),
            "hydrology_changed": _snapshot_changed(before, after, "hydrology"),
            "process_changed": _snapshot_changed(before, after, "log_process"),
            "observation_changed": _snapshot_changed(
                before, after, "log_observation"
            ),
            "lag_unchanged": np.array_equal(before["lag_time"], after["lag_time"]),
            "state_dimension_unchanged": int(
                np.asarray(before["state_dimension"]).reshape(-1)[0]
            )
            == int(np.asarray(after["state_dimension"]).reshape(-1)[0])
            == 8,
            "all_stochastic_fixed_points": all(
                row["fixed_point_max_abs_error"]
                <= float(engineering["fixed_point_max_absolute_error"])
                for row in stochastic.values()
            ),
            "all_stochastic_denominators": all(
                row["minimum_fixed_point_denominator"]
                > float(
                    engineering[
                        "minimum_fixed_point_denominator_margin_exclusive"
                    ]
                )
                for row in stochastic.values()
            ),
            "all_stochastic_projection_fractions": all(
                row["projection_fraction"]
                <= float(engineering["maximum_projection_fraction"])
                for row in stochastic.values()
            ),
            "all_stochastic_proportional_fractions": all(
                row["proportional_branch_fraction"]
                >= float(engineering["minimum_proportional_branch_fraction"])
                for row in stochastic.values()
            ),
        }
        source_after = _source_hashes()
        checks["source_hashes_unchanged"] = source_before == source_after
        engineering_checks = {
            "forcing_hash_matches": checks["forcing_sha256"],
            "independent_truth_matches": checks["observation_sha256"]
            and checks["independent_state_parity"]
            and checks["independent_discharge_parity"],
            "objective_matches": checks["objective_exact"],
            "all_gradients_nonzero": checks["hydrology_gradients_12_of_12"]
            and checks["process_gradients_8_of_8"]
            and checks["observation_gradient_1_of_1"],
            "all_groups_changed": checks["hydrology_changed"]
            and checks["process_changed"]
            and checks["observation_changed"],
            "lag_and_dimension_fixed": checks["lag_unchanged"]
            and checks["state_dimension_unchanged"],
            "fixed_point_valid": checks["all_stochastic_fixed_points"]
            and checks["all_stochastic_denominators"],
            "projection_fraction_valid": checks[
                "all_stochastic_projection_fractions"
            ],
            "proportional_branch_fraction_valid": checks[
                "all_stochastic_proportional_fractions"
            ],
        }
        report = {
            "schema_version": PREFLIGHT_SCHEMA_VERSION,
            "experiment_id": EXPERIMENT_ID,
            "stage": "preflight",
            "status": "PREFLIGHT_PASS" if all(checks.values()) else "STOP_ENGINEERING",
            "scientific_effect_claimed": False,
            "environment": environment,
            "engineering_checks": engineering_checks,
            "checks": checks,
            "forcing_sha256": forcing_hash,
            "observations_sha256": observation_hash,
            "independent_observations_sha256": independent_observation_hash,
            "independent_parity": {
                "state_maximum_absolute_difference": state_difference,
                "discharge_maximum_absolute_difference": discharge_difference,
            },
            "objective": float(objective.detach()),
            "gradients": gradients,
            "gradient_arrays": gradient_arrays,
            "gradient_clip_norms": clip_norms,
            "stochastic_truth_diagnostics": stochastic,
            "source_sha256": source_after,
            "source_sha256_start": source_before,
            "source_sha256_end": source_after,
        }
    except Exception as error:
        try:
            source_after = _source_hashes()
        except Exception:
            source_after = source_before
        report = {
            "schema_version": PREFLIGHT_SCHEMA_VERSION,
            "experiment_id": EXPERIMENT_ID,
            "stage": "preflight",
            "status": "STOP_ENGINEERING",
            "scientific_effect_claimed": False,
            "environment": environment,
            "error_type": type(error).__name__,
            "error": str(error),
            "source_sha256": source_after,
            "source_sha256_start": source_before,
            "source_sha256_end": source_after,
        }

    target = _preflight_path(contract)
    if report["status"] == "PREFLIGHT_PASS":
        if target.exists():
            existing = json.loads(target.read_text(encoding="utf-8"))
            if existing != _jsonable(report):
                raise FileExistsError(f"refusing to replace preflight artifact: {target}")
        else:
            _write_new_json(target, report)
    else:
        _write_new_json(_failure_preflight_path(contract, target), report)
    return report


def _parameter_truth_snapshot(template: Mapping[str, Any], contract: Mapping[str, Any]) -> dict[str, Any]:
    values = _truth_values(contract)
    coordinates = []
    for index, name in enumerate(TRAINABLE_HYDROLOGY_PARAMETER_NAMES):
        lower, upper = HBV_LITE_V5_PARAMETER_BOUNDS[name]
        coordinates.append((values["parameters"][index] - lower) / (upper - lower))
    snapshot = copy.deepcopy(dict(template))
    snapshot["hydrology"] = np.asarray(coordinates, dtype=np.float64).reshape(1, -1)
    snapshot["log_process"] = np.log(values["process_variances"])
    snapshot["log_observation"] = np.asarray(
        math.log(values["observation_ratio"]), dtype=np.float64
    ).reshape(np.asarray(template["log_observation"]).shape)
    snapshot["physical_parameters"] = values["parameters"].reshape(1, -1)
    snapshot["process_diagonal"] = values["process_variances"].copy()
    snapshot["observation_ratio"] = np.asarray(values["observation_ratio"])
    return snapshot


def _copy_snapshot(snapshot: Mapping[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in snapshot.items():
        result[key] = np.asarray(value).copy() if isinstance(value, np.ndarray) else copy.deepcopy(value)
    return result


def _finite_gradients_or_raise(model: JointTrainableRoutedHBVLiteUKF) -> dict[str, Any]:
    report = _gradient_summary(model)
    for name, row in report.items():
        if row["finite_count"] != row["count"]:
            raise FloatingPointError(f"non-finite {name} gradient")
        if row["nonzero_count"] == 0:
            raise FloatingPointError(f"zero {name} gradient group")
    return report


def _evaluate_segment(
    model: JointTrainableRoutedHBVLiteUKF,
    forcings: torch.Tensor,
    observations: torch.Tensor,
    initial_state: torch.Tensor,
    initial_covariance: torch.Tensor,
    contract: Mapping[str, Any],
    *,
    target_start: int,
    target_end_exclusive: int,
) -> tuple[float, dict[int, np.ndarray]]:
    with torch.no_grad():
        loss, forecasts = segmented_multilead_objective(
            model,
            forcings,
            observations,
            initial_state,
            initial_covariance,
            base_observation_variance=_truth_values(contract)["base_variance"],
            target_start=target_start,
            target_end_exclusive=target_end_exclusive,
            leads=LEADS,
        )
    value = float(loss.detach())
    if not math.isfinite(value):
        raise FloatingPointError("segmented objective is non-finite")
    arrays = {
        lead: forecasts[lead].detach().cpu().numpy().astype(np.float64, copy=True)
        for lead in LEADS
    }
    return value, arrays


def _mse_by_lead(
    forecasts: Mapping[int, np.ndarray], target: np.ndarray
) -> tuple[dict[str, float], float]:
    values: dict[str, float] = {}
    for lead in LEADS:
        prediction = np.asarray(forecasts[lead], dtype=np.float64)
        if prediction.shape != target.shape:
            raise ValueError(f"lead-{lead} prediction shape does not match target")
        values[str(lead)] = float(np.mean((prediction - target) ** 2))
    return values, float(np.mean(list(values.values())))


def _ratio(metrics: Mapping[str, Any], group: str) -> float:
    aliases = {
        "hydrology": ("hydrology", "hydrology_parameters"),
        "process_noise": ("process_noise", "process"),
        "observation_scale": ("observation_scale", "observation"),
    }[group]
    ratios = metrics.get("ratios", {})
    for alias in aliases:
        if alias in ratios:
            return float(ratios[alias])
        row = metrics.get(alias)
        if isinstance(row, Mapping):
            for key in ("selected_to_initial_ratio", "ratio", "error_ratio"):
                if key in row:
                    return float(row[key])
        for suffix in (
            "_selected_to_initial_ratio",
            "_error_ratio",
            "_ratio",
        ):
            key = alias + suffix
            if key in metrics:
                return float(metrics[key])
    raise KeyError(f"recovery metrics omit the {group} error ratio")


def _bound_hit_count(metrics: Mapping[str, Any]) -> int:
    for key in (
        "selected_boundary_hit_count",
        "selected_parameter_bound_hit_count",
        "selected_bound_hits",
    ):
        if key in metrics:
            value = metrics[key]
            if isinstance(value, Mapping):
                return int(value.get("total", sum(int(item) for item in value.values())))
            return int(value)
    hits = metrics.get("boundary_hits")
    if isinstance(hits, Mapping):
        selected = hits.get("selected", hits)
        if isinstance(selected, Mapping):
            return int(selected.get("total", sum(int(item) for item in selected.values())))
        return int(selected)
    raise KeyError("recovery metrics omit selected boundary-hit count")


def _run_manifest(run_directory: Path, truth_seed: int, start_id: str) -> dict[str, Any]:
    required_files = (
        "input_arrays.npz",
        "history.json",
        "selected_checkpoint.pt",
        "metrics.json",
        "config_snapshot.json",
    )
    files = {
        name: sha256_file(run_directory / name)
        for name in required_files
    }
    return {
        "schema_version": "tukf11_run_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "truth_seed": int(truth_seed),
        "start_id": str(start_id),
        "files": files,
    }


def run_one(
    contract: Mapping[str, Any],
    truth_seed: int,
    start_id: str,
    output_dir: Path,
) -> dict[str, Any]:
    """Run one frozen seed/start combination and persist one isolated run."""

    if int(truth_seed) not in [int(value) for value in contract["truth_seeds"]]:
        raise ValueError("truth seed is outside the frozen registry")
    if str(start_id) not in [str(value) for value in contract["start_ids"]]:
        raise ValueError("start identifier is outside the frozen registry")
    environment = _configure_environment(contract)
    run_directory = create_new_output_directory(output_dir)
    source_before = _source_hashes()
    segments = _segments(contract)
    days = segments["days"]
    forcing, truth = _generate_truth(
        contract, days=days, truth_seed=int(truth_seed)
    )
    diagnostics = _truth_diagnostics(truth, contract)
    observations = np.asarray(truth["observations"], dtype=np.float64)
    model = build_joint_model(contract, str(start_id), device=DEVICE, dtype=DTYPE)
    forcings, observation_tensor, initial_state = _tensor_inputs(
        forcing, observations, _truth_values(contract)["initial_state"]
    )
    covariance = _initial_covariance(model, contract)
    optimizer = build_grouped_adam(model, contract)
    optimizer_contract = contract["optimizer"]
    updates = int(optimizer_contract["updates"])
    interval = int(optimizer_contract["selection_interval"])
    selection_updates = tuple(range(0, updates + 1, interval))
    if selection_updates != (0, 4, 8, 12, 16, 20, 24, 28, 32):
        raise ValueError("selection update registry changed")

    initial_snapshot = _copy_snapshot(snapshot_trainables(model))
    selection_history: list[dict[str, Any]] = []
    training_history: list[dict[str, Any]] = []
    snapshots: dict[int, dict[str, Any]] = {}
    selection_forecasts: dict[int, dict[int, np.ndarray]] = {}

    selection_start = segments["selection_target_start"]
    selection_end = segments["selection_target_end_exclusive"]
    train_start = segments["train_target_start"]
    train_end = segments["train_target_end_exclusive"]

    selection_loss, selection_prediction = _evaluate_segment(
        model,
        forcings,
        observation_tensor,
        initial_state,
        covariance,
        contract,
        target_start=selection_start,
        target_end_exclusive=selection_end,
    )
    selection_history.append({"update": 0, "selection_loss": selection_loss})
    snapshots[0] = _copy_snapshot(snapshot_trainables(model))
    selection_forecasts[0] = selection_prediction

    for update in range(1, updates + 1):
        optimizer.zero_grad(set_to_none=True)
        loss, _ = segmented_multilead_objective(
            model,
            forcings,
            observation_tensor,
            initial_state,
            covariance,
            base_observation_variance=_truth_values(contract)["base_variance"],
            target_start=train_start,
            target_end_exclusive=train_end,
            leads=LEADS,
        )
        if not bool(torch.isfinite(loss)):
            raise FloatingPointError(f"non-finite training loss at update {update}")
        loss.backward()
        gradient_report = _finite_gradients_or_raise(model)
        clip_norms = clip_active_groups_(
            model, float(optimizer_contract["group_gradient_norm"])
        )
        if not all(math.isfinite(float(value)) for value in clip_norms.values()):
            raise FloatingPointError(f"non-finite gradient clipping norm at update {update}")
        optimizer.step()
        model.project_trainable_coordinates_()
        training_history.append(
            {
                "update": update,
                "training_loss": float(loss.detach()),
                "gradient_counts": {
                    key: int(value["nonzero_count"])
                    for key, value in gradient_report.items()
                },
                "gradient_clip_norms": dict(clip_norms),
            }
        )
        if update in selection_updates:
            selection_loss, selection_prediction = _evaluate_segment(
                model,
                forcings,
                observation_tensor,
                initial_state,
                covariance,
                contract,
                target_start=selection_start,
                target_end_exclusive=selection_end,
            )
            selection_history.append(
                {"update": update, "selection_loss": selection_loss}
            )
            snapshots[update] = _copy_snapshot(snapshot_trainables(model))
            selection_forecasts[update] = selection_prediction

    selected_row = select_checkpoint(selection_history)
    selected_update = int(selected_row["update"])
    selected_snapshot = snapshots[selected_update]
    selected_selection_forecasts = selection_forecasts[selected_update]

    # The checkpoint is now frozen.  Hidden-parameter errors and sealed-test
    # predictions are not evaluated anywhere above this line.
    test_start = segments["test_target_start"]
    test_end = segments["test_target_end_exclusive"]
    target = observations[test_start:test_end].copy()

    restore_trainables_(model, initial_snapshot)
    initial_test_loss, initial_test_forecasts = _evaluate_segment(
        model,
        forcings,
        observation_tensor,
        initial_state,
        covariance,
        contract,
        target_start=test_start,
        target_end_exclusive=test_end,
    )
    restore_trainables_(model, selected_snapshot)
    selected_test_loss, selected_test_forecasts = _evaluate_segment(
        model,
        forcings,
        observation_tensor,
        initial_state,
        covariance,
        contract,
        target_start=test_start,
        target_end_exclusive=test_end,
    )
    truth_snapshot = _parameter_truth_snapshot(selected_snapshot, contract)
    restore_trainables_(model, truth_snapshot)
    truth_oracle_test_loss, truth_oracle_test_forecasts = _evaluate_segment(
        model,
        forcings,
        observation_tensor,
        initial_state,
        covariance,
        contract,
        target_start=test_start,
        target_end_exclusive=test_end,
    )
    restore_trainables_(model, selected_snapshot)

    initial_mse_by_lead, initial_mean_mse = _mse_by_lead(
        initial_test_forecasts, target
    )
    selected_mse_by_lead, selected_mean_mse = _mse_by_lead(
        selected_test_forecasts, target
    )
    truth_mse_by_lead, truth_mean_mse = _mse_by_lead(
        truth_oracle_test_forecasts, target
    )
    if initial_mean_mse <= 0.0:
        raise FloatingPointError("initial sealed-test mean squared error is not positive")
    test_ratio = selected_mean_mse / initial_mean_mse

    parameter_metrics = recovery_metrics(
        initial_snapshot,
        selected_snapshot,
        contract,
        boundary_tolerance=1e-12,
    )
    hydrology_ratio = _ratio(parameter_metrics, "hydrology")
    process_ratio = _ratio(parameter_metrics, "process_noise")
    observation_ratio = _ratio(parameter_metrics, "observation_scale")
    boundary_hits = _bound_hit_count(parameter_metrics)
    if not all(
        math.isfinite(value)
        for value in (hydrology_ratio, process_ratio, observation_ratio, test_ratio)
    ):
        raise FloatingPointError("a recovery or test ratio is non-finite")

    source_after = _source_hashes()
    if source_before != source_after:
        raise RuntimeError("a hashed dependency changed during a TUKF11 run")

    arrays: dict[str, Any] = {
        "forcing": forcing,
        "observations": observations,
        "truth_states": truth["states"],
        "deterministic_pre_noise_states": truth["deterministic_pre_noise_states"],
        "preprojection_process_increment": truth["preprojection_process_increment"],
        "projection_delta": truth["projection_delta"],
        "projection_hit_mask": np.asarray(truth["projection_hit_mask"], dtype=np.uint8),
        "raw_discharge": truth["raw_discharge"],
        "clean_discharge": truth["clean_discharge"],
        "process_standard_normals": truth["process_standard_normals"],
        "observation_standard_normals": truth["observation_standard_normals"],
        "observation_branch_codes": truth["observation_branch_codes"],
        "standardized_observation_residual": truth[
            "standardized_observation_residual"
        ],
        "test_targets": target,
        "selection_targets": observations[selection_start:selection_end],
        "truth_hydrology_coordinates": truth_snapshot["hydrology"],
        "initial_hydrology_coordinates": initial_snapshot["hydrology"],
        "selected_hydrology_coordinates": selected_snapshot["hydrology"],
        "truth_process_diagonal": _truth_values(contract)["process_variances"],
        "initial_process_diagonal": initial_snapshot["process_diagonal"],
        "selected_process_diagonal": selected_snapshot["process_diagonal"],
        "truth_observation_ratio": np.asarray(
            [_truth_values(contract)["observation_ratio"]], dtype=np.float64
        ),
        "initial_observation_ratio": np.asarray(
            initial_snapshot["observation_ratio"], dtype=np.float64
        ).reshape(-1),
        "selected_observation_ratio": np.asarray(
            selected_snapshot["observation_ratio"], dtype=np.float64
        ).reshape(-1),
    }
    for lead in LEADS:
        arrays[f"initial_test_forecast_lead_{lead}"] = initial_test_forecasts[lead]
        arrays[f"selected_test_forecast_lead_{lead}"] = selected_test_forecasts[lead]
        arrays[f"truth_oracle_test_forecast_lead_{lead}"] = truth_oracle_test_forecasts[lead]
        arrays[f"selected_selection_forecast_lead_{lead}"] = selected_selection_forecasts[lead]

    history = {
        "schema_version": "tukf11_run_history_v1",
        "experiment_id": EXPERIMENT_ID,
        "truth_seed": int(truth_seed),
        "start_id": str(start_id),
        "training_updates": training_history,
        "selection_queries": selection_history,
        "selected_update": selected_update,
        "selected_selection_loss": float(selected_row["selection_loss"]),
        "test_query_count_before_selection": 0,
        "test_query_count_after_selection": 3,
    }
    metrics = {
        "schema_version": "tukf11_run_metrics_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "COMPLETE",
        "truth_seed": int(truth_seed),
        "start_id": str(start_id),
        "environment": environment,
        "selected_update": selected_update,
        "selection_query_count": len(selection_history),
        "test_query_count_before_selection": 0,
        "test_query_count_after_selection": 3,
        "test_query_count": 3,
        "selection": {
            "target_start": selection_start,
            "target_end_exclusive": selection_end,
            "selected_loss": float(selected_row["selection_loss"]),
        },
        "test": {
            "target_start": test_start,
            "target_end_exclusive": test_end,
            "initial_objective": initial_test_loss,
            "selected_objective": selected_test_loss,
            "truth_oracle_objective": truth_oracle_test_loss,
            "initial_mse_by_lead": initial_mse_by_lead,
            "selected_mse_by_lead": selected_mse_by_lead,
            "truth_oracle_mse_by_lead": truth_mse_by_lead,
            "initial_mean_mse": initial_mean_mse,
            "selected_mean_mse": selected_mean_mse,
            "truth_oracle_mean_mse": truth_mean_mse,
            "ratio": test_ratio,
        },
        "parameters": {
            "truth": {
                "hydrology_coordinates": truth_snapshot["hydrology"],
                "process_diagonal": _truth_values(contract)["process_variances"],
                "observation_ratio": _truth_values(contract)["observation_ratio"],
            },
            "initial": {
                "hydrology_coordinates": initial_snapshot["hydrology"],
                "process_diagonal": initial_snapshot["process_diagonal"],
                "observation_ratio": float(
                    np.asarray(initial_snapshot["observation_ratio"]).reshape(-1)[0]
                ),
            },
            "selected": {
                "hydrology_coordinates": selected_snapshot["hydrology"],
                "process_diagonal": selected_snapshot["process_diagonal"],
                "observation_ratio": float(
                    np.asarray(selected_snapshot["observation_ratio"]).reshape(-1)[0]
                ),
            },
            "recovery": parameter_metrics,
            "ratios": {
                "hydrology": hydrology_ratio,
                "process_noise": process_ratio,
                "observation_scale": observation_ratio,
            },
            "bound_hits": {"selected_total": boundary_hits},
        },
        "truth_generation_diagnostics": diagnostics,
        "source_sha256_start": source_before,
        "source_sha256_end": source_after,
        "claims_not_authorized": [
            "structural identifiability",
            "real-basin validity",
            "joint learning superiority over separate learning",
        ],
    }

    _write_new_npz(run_directory / "input_arrays.npz", arrays)
    _write_new_json(run_directory / "history.json", history)
    _write_new_torch(
        run_directory / "selected_checkpoint.pt",
        {
            "schema_version": 1,
            "experiment_id": EXPERIMENT_ID,
            "truth_seed": int(truth_seed),
            "start_id": str(start_id),
            "selected_update": selected_update,
            "selected_selection_loss": float(selected_row["selection_loss"]),
            "model_state_dict": model.state_dict(),
            "selected_trainables": selected_snapshot,
            "source_sha256": source_after,
        },
    )
    _write_new_json(run_directory / "metrics.json", metrics)
    _write_new_json(run_directory / "config_snapshot.json", dict(contract))
    manifest = _run_manifest(run_directory, int(truth_seed), str(start_id))
    _write_new_json(run_directory / "manifest.json", manifest)

    return {
        "truth_seed": int(truth_seed),
        "start_id": str(start_id),
        "run_dir": str(run_directory.relative_to(_formal_root(contract))).replace(
            "\\", "/"
        ),
        "status": "COMPLETE",
        "engineering_passed": True,
        "selected_update": selected_update,
        "hydrology_error_ratio": hydrology_ratio,
        "process_noise_error_ratio": process_ratio,
        "observation_scale_error_ratio": observation_ratio,
        "test_mse_ratio": test_ratio,
        "selected_parameter_bound_hits": boundary_hits,
    }


def _classification_thresholds(contract: Mapping[str, Any]) -> dict[str, float | int]:
    gates = contract["gates"]["formal"]
    recovery_limits = {
        float(gates["median_hydrology_error_ratio_max_exclusive"]),
        float(gates["median_process_error_ratio_max_exclusive"]),
        float(gates["median_observation_error_ratio_max_exclusive"]),
    }
    if len(recovery_limits) != 1:
        raise ValueError(
            "current independent verifier requires one common recovery threshold"
        )
    parameter_minimum = int(gates["minimum_improved_runs_per_parameter_group"])
    test_minimum = int(gates["minimum_test_improved_runs"])
    if parameter_minimum != test_minimum:
        raise ValueError(
            "current independent verifier requires equal parameter and test counts"
        )
    if int(gates["required_completed_runs"]) != 9:
        raise ValueError("current independent verifier requires exactly nine runs")
    return {
        "median_recovery_ratio_max": recovery_limits.pop(),
        "minimum_improved_runs": parameter_minimum,
        "median_test_ratio_max": float(
            gates["median_test_loss_ratio_max_exclusive"]
        ),
        "maximum_bound_hits": int(
            gates["maximum_selected_parameter_boundary_hits"]
        ),
    }


def classify_registry(
    rows: Sequence[Mapping[str, Any]], contract: Mapping[str, Any]
) -> dict[str, Any]:
    """Aggregate the exact nine rows and select one frozen mechanism class."""

    expected = {
        (int(seed), str(start_id))
        for seed in contract["truth_seeds"]
        for start_id in contract["start_ids"]
    }
    if len(rows) != 9:
        raise ValueError("TUKF11 registry must contain exactly 9 rows")
    identities = [(int(row["truth_seed"]), str(row["start_id"])) for row in rows]
    if len(set(identities)) != len(identities) or set(identities) != expected:
        raise ValueError("TUKF11 registry identities are missing, duplicated, or extra")
    required = (
        "hydrology_error_ratio",
        "process_noise_error_ratio",
        "observation_scale_error_ratio",
        "test_mse_ratio",
    )
    arrays: dict[str, np.ndarray] = {}
    for key in required:
        values = np.asarray([float(row[key]) for row in rows], dtype=np.float64)
        if not np.isfinite(values).all() or np.any(values < 0.0):
            raise ValueError(f"registry contains invalid {key}")
        arrays[key] = values
    bound_hits: list[int] = []
    for row in rows:
        raw = row.get("selected_parameter_bound_hits")
        if isinstance(raw, bool):
            raise ValueError("selected parameter-bound hit count is invalid")
        try:
            count = int(raw)
        except (TypeError, ValueError) as exc:
            raise ValueError("selected parameter-bound hit count is invalid") from exc
        if count < 0 or raw != count:
            raise ValueError("selected parameter-bound hit count is invalid")
        bound_hits.append(count)
    engineering_gate = all(
        row.get("status") == "COMPLETE"
        and row.get("engineering_passed") is True
        for row in rows
    )
    thresholds = _classification_thresholds(contract)
    recovery_groups = {
        "hydrology": arrays["hydrology_error_ratio"],
        "process_noise": arrays["process_noise_error_ratio"],
        "observation_scale": arrays["observation_scale_error_ratio"],
    }
    recovery = {
        name: {
            "median_selected_to_initial_error_ratio": float(np.median(values)),
            "improved_run_count": int(np.count_nonzero(values < 1.0)),
        }
        for name, values in recovery_groups.items()
    }
    recovery_gate = all(
        summary["median_selected_to_initial_error_ratio"]
        < float(thresholds["median_recovery_ratio_max"])
        and summary["improved_run_count"]
        >= int(thresholds["minimum_improved_runs"])
        for summary in recovery.values()
    )
    test = {
        "median_selected_to_initial_mse_ratio": float(
            np.median(arrays["test_mse_ratio"])
        ),
        "improved_run_count": int(np.count_nonzero(arrays["test_mse_ratio"] < 1.0)),
    }
    test_gate = bool(
        test["median_selected_to_initial_mse_ratio"]
        < float(thresholds["median_test_ratio_max"])
        and test["improved_run_count"] >= int(thresholds["minimum_improved_runs"])
    )
    boundary_gate = all(
        count <= int(thresholds["maximum_bound_hits"])
        for count in bound_hits
    )
    if engineering_gate and recovery_gate and test_gate and boundary_gate:
        classification = "MECHANISM_PASS"
    elif engineering_gate and test_gate and not recovery_gate and boundary_gate:
        classification = "PREDICTIVE_PARAMETER_COMPENSATION"
    elif engineering_gate and recovery_gate and not test_gate and boundary_gate:
        classification = "MECHANISM_RECOVERY_WITHOUT_PREDICTIVE_GAIN"
    else:
        classification = "RECOVERY_HOLD"
    return {
        "run_count": 9,
        "engineering_gate": engineering_gate,
        "recovery": recovery,
        "test": test,
        "boundary": {
            "total_selected_bound_hits": sum(bound_hits),
            "runs_with_bound_hits": sum(count > 0 for count in bound_hits),
            "gate": boundary_gate,
        },
        "recovery_gate": recovery_gate,
        "test_gate": test_gate,
        "thresholds": thresholds,
        "classification": classification,
    }


def _require_preflight(contract: Mapping[str, Any]) -> dict[str, Any]:
    path = _preflight_path(contract)
    if not path.is_file():
        raise FileNotFoundError(f"passing TUKF11 preflight is missing: {path}")
    report = json.loads(path.read_text(encoding="utf-8"))
    if report.get("schema_version") != PREFLIGHT_SCHEMA_VERSION:
        raise ValueError("preflight schema version changed")
    if report.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("preflight experiment identifier changed")
    if report.get("status") != "PREFLIGHT_PASS":
        raise RuntimeError("formal TUKF11 execution requires PREFLIGHT_PASS")
    engineering_checks = report.get("engineering_checks")
    if not isinstance(engineering_checks, Mapping) or set(
        engineering_checks
    ) != set(REQUIRED_ENGINEERING_CHECKS):
        raise RuntimeError("preflight engineering-check coverage changed")
    if not all(engineering_checks[name] is True for name in REQUIRED_ENGINEERING_CHECKS):
        raise RuntimeError("formal TUKF11 execution requires all engineering checks")
    current = _source_hashes()
    for name in ("source_sha256", "source_sha256_start", "source_sha256_end"):
        if report.get(name) != current:
            raise RuntimeError(
                f"current dependency hashes do not match preflight {name}"
            )
    current_environment = _configure_environment(contract)
    if report.get("environment") != current_environment:
        raise RuntimeError("current runtime environment does not match the preflight")
    return report


def _root_manifest(root: Path) -> dict[str, Any]:
    files: dict[str, str] = {}
    for path in sorted(root.rglob("*")):
        if path.is_file() and path != root / "manifest.json":
            files[path.relative_to(root).as_posix()] = sha256_file(path)
    return {
        "schema_version": 1,
        "experiment_id": EXPERIMENT_ID,
        "files": files,
    }


def _unique_failed_formal_root(canonical_root: Path) -> tuple[Path, str]:
    """Choose one unused timestamped sibling after strict path validation."""

    canonical = Path(canonical_root).resolve()
    allowed = (ROOT / "results").resolve()
    try:
        canonical.relative_to(allowed)
    except ValueError as exc:
        raise ValueError("canonical formal root escapes ROOT/results") from exc
    if canonical == allowed:
        raise ValueError("canonical formal root cannot equal ROOT/results")
    for _ in range(1000):
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        candidate = canonical.with_name(f"{canonical.name}_failed_{stamp}").resolve()
        try:
            candidate.relative_to(allowed)
        except ValueError as exc:
            raise ValueError("failed formal root escapes ROOT/results") from exc
        if candidate.parent != canonical.parent:
            raise ValueError("failed formal root is not a canonical-root sibling")
        if not candidate.exists():
            return candidate, stamp
    raise FileExistsError("could not allocate a unique failed formal root")


def _archive_failed_formal_root(
    canonical_root: Path,
    error: BaseException,
    *,
    rows: Sequence[Mapping[str, Any]],
    preflight_sha256: str,
    expected_source_sha256: Mapping[str, str],
    environment: Mapping[str, Any],
) -> Path:
    """Atomically move a failed canonical root and write its bounded audit record."""

    canonical = Path(canonical_root).resolve()
    if not canonical.is_dir():
        raise FileNotFoundError(f"failed canonical formal root is missing: {canonical}")
    failed_root, failure_stamp = _unique_failed_formal_root(canonical)
    if failed_root.exists():
        raise FileExistsError(f"refusing to overwrite failed formal root: {failed_root}")
    try:
        current_source: Mapping[str, str] | None = _source_hashes()
        current_source_error: dict[str, str] | None = None
    except Exception as source_error:
        current_source = None
        current_source_error = {
            "error_type": type(source_error).__name__,
            "error": str(source_error),
        }
    try:
        current_environment: Mapping[str, Any] | None = _minimal_environment()
        current_environment_error: dict[str, str] | None = None
    except Exception as environment_error:
        current_environment = None
        current_environment_error = {
            "error_type": type(environment_error).__name__,
            "error": str(environment_error),
        }
    payload = {
        "schema_version": "tukf11_formal_failure_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "FORMAL_FAILED",
        "failure_utc": failure_stamp,
        "error_type": type(error).__name__,
        "error": str(error),
        "completed_run_count": len(rows),
        "completed_rows": list(rows),
        "engineering_preflight_sha256": preflight_sha256,
        "expected_source_sha256": dict(expected_source_sha256),
        "current_source_sha256": current_source,
        "current_source_error": current_source_error,
        "environment": dict(environment),
        "current_environment": current_environment,
        "current_environment_error": current_environment_error,
    }
    canonical.rename(failed_root)
    if canonical.exists() or not failed_root.is_dir():
        raise RuntimeError("failed formal root move did not restore canonical absence")
    _write_new_json(failed_root / "formal_failure.json", payload)
    return failed_root


def run_formal(contract: Mapping[str, Any]) -> dict[str, Any]:
    """Run exactly the frozen 3-by-3 registry after a matching preflight."""

    preflight = _require_preflight(contract)
    environment = _minimal_environment()
    if preflight.get("environment") != environment:
        raise RuntimeError("formal runtime environment differs from the preflight")
    expected_source = dict(preflight["source_sha256"])
    source_before = _source_hashes()
    if source_before != expected_source:
        raise RuntimeError("formal source closure differs before result-root creation")
    preflight_path = _preflight_path(contract)
    preflight_sha256 = sha256_file(preflight_path)
    rows: list[dict[str, Any]] = []
    directory_template = str(contract["outputs"]["run_directory_template"])
    root = create_new_output_directory(_formal_root(contract))
    try:
        for truth_seed in contract["truth_seeds"]:
            for start_id in contract["start_ids"]:
                if _source_hashes() != expected_source:
                    raise RuntimeError("formal source closure changed before a run")
                if _minimal_environment() != environment:
                    raise RuntimeError("formal runtime environment changed between runs")
                relative = directory_template.format(
                    truth_seed=int(truth_seed), start_id=str(start_id)
                )
                run_directory = resolve_output_path(relative, root)
                row = run_one(
                    contract,
                    int(truth_seed),
                    str(start_id),
                    run_directory,
                )
                rows.append(row)
                if _source_hashes() != expected_source:
                    raise RuntimeError("formal source closure changed during a run")
                if _minimal_environment() != environment:
                    raise RuntimeError("formal runtime environment changed during a run")
        aggregate = classify_registry(rows, contract)
        source_after = _source_hashes()
        if source_after != expected_source:
            raise RuntimeError("formal source closure changed before registry writing")
        if _minimal_environment() != environment:
            raise RuntimeError("formal runtime environment changed before registry writing")
        if sha256_file(preflight_path) != preflight_sha256:
            raise RuntimeError("engineering preflight artifact changed during formal execution")
        registry = {
            "schema_version": "tukf11_registry_v1",
            "experiment_id": EXPERIMENT_ID,
            "rows": rows,
            "aggregate": aggregate,
            "classification": aggregate["classification"],
            "environment": environment,
            "engineering_preflight_sha256": preflight_sha256,
            "engineering_preflight_status": preflight["status"],
            "source_sha256_start": source_before,
            "source_sha256_end": source_after,
            "claims_not_authorized": [
                "structural identifiability",
                "real-basin validity",
                "joint learning superiority over separate learning",
            ],
        }
        _write_new_json(root / "config_snapshot.json", dict(contract))
        _write_new_json(root / "registry.json", registry)
        _write_new_json(root / "manifest.json", _root_manifest(root))
        return registry
    except BaseException as error:
        try:
            _archive_failed_formal_root(
                root,
                error,
                rows=rows,
                preflight_sha256=preflight_sha256,
                expected_source_sha256=expected_source,
                environment=environment,
            )
        except BaseException as archive_error:
            archive_error.add_note(
                f"original formal failure: {type(error).__name__}: {error}"
            )
            raise
        raise


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--stage",
        choices=("preflight", "formal"),
        required=True,
        help="Run only the one-update engineering preflight or the frozen nine-run gate.",
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=DEFAULT_CONFIG,
        help="Frozen TUKF11 JSON contract.",
    )
    return parser


def main() -> int:
    arguments = build_argument_parser().parse_args()
    contract = load_contract(arguments.config)
    if arguments.stage == "preflight":
        report = run_preflight(contract)
        print(f"{report['status']} {_preflight_path(contract)}", flush=True)
        return 0 if report["status"] == "PREFLIGHT_PASS" else 1
    registry = run_formal(contract)
    print(
        f"{registry['classification']} {_formal_root(contract)}",
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
