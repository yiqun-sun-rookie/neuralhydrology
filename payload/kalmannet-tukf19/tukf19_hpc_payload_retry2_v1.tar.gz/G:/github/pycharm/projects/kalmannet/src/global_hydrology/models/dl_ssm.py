"""
DL-SSM (LSTM/GRU) System Model for DA
====================================

This module provides a lightweight, fully learnable state-space model
that can be used with KalmanNet for data assimilation.

State update:
    x_{t+1} = GRUCell([u_t, s_embed], x_t)
Observation:
    y_t = MLP(x_t)
Initial state:
    x_0 = MLP(s)
"""

from dataclasses import dataclass
import torch
import torch.nn as nn


@dataclass
class DLSSMConfig:
    state_dim: int = 16
    obs_dim: int = 1
    forcing_dim: int = 3
    static_dim: int = 16
    static_embed_dim: int = 16
    init_hidden: int = 64
    obs_hidden: int = 64
    dropout: float = 0.0
    use_static_in_transition: bool = True


class DLSSMSystemModel(nn.Module):
    """A minimal DL-based SSM with static attributes."""

    def __init__(self, config: DLSSMConfig):
        super().__init__()
        self.config = config
        self.m = config.state_dim
        self.n = config.obs_dim

        self.static_encoder = nn.Sequential(
            nn.Linear(config.static_dim, config.static_embed_dim),
            nn.ReLU(),
            nn.Dropout(config.dropout),
            nn.Linear(config.static_embed_dim, config.static_embed_dim),
        )

        self.init_net = nn.Sequential(
            nn.Linear(config.static_dim, config.init_hidden),
            nn.ReLU(),
            nn.Dropout(config.dropout),
            nn.Linear(config.init_hidden, config.state_dim),
            nn.Tanh(),
        )

        input_dim = config.forcing_dim
        if config.use_static_in_transition:
            input_dim += config.static_embed_dim

        self.gru_cell = nn.GRUCell(input_size=input_dim, hidden_size=config.state_dim)

        self.obs_net = nn.Sequential(
            nn.Linear(config.state_dim, config.obs_hidden),
            nn.ReLU(),
            nn.Dropout(config.dropout),
            nn.Linear(config.obs_hidden, config.obs_dim),
        )

        # Priors for KalmanNet initialization (buffers move with .to())
        self.register_buffer("prior_q", torch.eye(config.state_dim))
        self.register_buffer("prior_state_cov", torch.eye(config.state_dim) * 10.0)
        self.register_buffer("prior_r", torch.eye(config.obs_dim))

    def encode_static(self, static: torch.Tensor) -> torch.Tensor:
        if static.dim() == 1:
            static = static.unsqueeze(0)
        return self.static_encoder(static)

    def init_state(self, static: torch.Tensor) -> torch.Tensor:
        if static.dim() == 1:
            static = static.unsqueeze(0)
        return self.init_net(static)

    def f(self, x: torch.Tensor, u: torch.Tensor, static_embed: torch.Tensor = None) -> torch.Tensor:
        if x.dim() == 1:
            x = x.unsqueeze(0)
        if u.dim() == 1:
            u = u.unsqueeze(0)

        if self.config.use_static_in_transition:
            if static_embed is None:
                raise ValueError("static_embed is required when use_static_in_transition=True")
            if static_embed.dim() == 1:
                static_embed = static_embed.unsqueeze(0)
            inp = torch.cat([u, static_embed], dim=-1)
        else:
            inp = u

        return self.gru_cell(inp, x)

    def h(self, x: torch.Tensor) -> torch.Tensor:
        if x.dim() == 1:
            x = x.unsqueeze(0)
        return self.obs_net(x)
