"""
Walrus System Model Adapter for KalmanNet
==========================================

This module wraps the DifferentiableWalrus model into a SystemModel interface
that is compatible with the existing KalmanNet framework.

The adapter allows:
1. Using Walrus as the process model (f) in the Kalman filter loop
2. Defining the observation model (h) as a simple state-to-output mapping
3. Integrating with StaticEncoder for global-scale applications

Author: KalmanNet Global DA Project
Date: 2026-01-20
"""

import torch
import torch.nn as nn
from typing import Tuple, Dict, Optional

from .differentiable_walrus import DifferentiableWalrus


class WalrusSystemModel:
    """
    将 DifferentiableWalrus 包装成 KalmanNet 需要的 SystemModel 接口。
    
    KalmanNet 需要的接口:
        - f(x, u): 状态转移函数
        - h(x): 观测函数
        - m: 状态维度
        - n: 观测维度
        - prior_q, prior_state_cov, prior_r: 先验协方差
    
    Walrus 模型的状态:
        - dv: 土壤水分深度 (mm)
        - dg: 地下水深度 (mm)
        - hq: 快流水位 (mm)
        - hs: 慢流水位 (mm)
        - q: 流量 (mm/day)
    
    观测:
        - Q: 流量 (mm/day) - 直接对应状态 q
    
    Args:
        hydro_params: [Batch, 4] 由 StaticEncoder 生成的水文参数 (cw, cv, cg, cq)
        cd: 固定参数 - 河道深度
        cs: 固定参数 - 河道形状参数
        device: 计算设备
    """
    
    # 状态和观测维度 (Walrus 模型固定)
    m = 5  # 状态维度: (dv, dg, hq, hs, q)
    n = 1  # 观测维度: Q
    
    def __init__(self, 
                 hydro_params: torch.Tensor,
                 cd: float = 2450.0,
                 cs: float = 0.2,
                 device: torch.device = None,
                 seq_len: int = 365,
                 seq_len_test: int = 365):
        """
        初始化 Walrus 系统模型适配器。
        
        Args:
            hydro_params: [Batch, 4] 水文参数 (cw, cv, cg, cq)
            cd: 固定参数 - 河道深度
            cs: 固定参数 - 河道形状参数
            device: 计算设备
            seq_len: 训练序列长度
            seq_len_test: 测试序列长度
        """
        self.device = device or torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # 存储水文参数（批次）
        # 注意：不要 detach，需要保持梯度流以便反向传播到 StaticEncoder
        self.hydro_params = hydro_params.to(self.device)
        self.batch_size = hydro_params.shape[0]
        
        # 存储固定参数
        self.cd = cd
        self.cs = cs
        
        # 创建内部 Walrus 模型实例
        self._walrus_model = DifferentiableWalrus(cd=cd, cs=cs, device=self.device)
        
        # 约束参数（用于内部计算）
        # 注意：这里的约束参数持有对 hydro_params 的计算图引用，这是必要的
        self._constrained_params = self._walrus_model._constrain_params(self.hydro_params)
        
        # 序列长度
        self.seq_len = seq_len
        self.seq_len_test = seq_len_test
        
        # 噪声协方差的先验（用于 KalmanNet 初始化）
        # 这些值不需要精确，因为 KalmanNet 会学习真正的增益
        self.q = torch.eye(self.m, device=self.device) * 0.1
        self.r = torch.eye(self.n, device=self.device) * 0.1
        
        self.prior_q = torch.eye(self.m, device=self.device)
        self.prior_state_cov = torch.eye(self.m, device=self.device) * 10.0
        self.prior_r = torch.eye(self.n, device=self.device)
        
        # 当前强迫数据（在 step 调用时需要）
        self._current_forcing = None
        
        # 初始状态
        self.m1x_0 = None  # 状态均值
        self.m2x_0 = None  # 状态协方差
    
    def set_forcing(self, forcing: torch.Tensor):
        """
        设置当前时间步的强迫数据。
        
        这个方法在每个时间步调用 f() 之前必须先调用。
        
        Args:
            forcing: [Batch, 2] 当前时间步的驱动 (P, ETpot)
        """
        self._current_forcing = forcing.to(self.device)
    
    def f(self, x: torch.Tensor, u: torch.Tensor = None) -> torch.Tensor:
        """
        状态转移函数 (Process Model)
        
        执行 Walrus 模型的一步前向传播。
        
        Args:
            x: [Batch, m] 或 [m,] 当前状态 (dv, dg, hq, hs, q)
            u: 输入（未使用，强迫通过 set_forcing 设置）
            
        Returns:
            x_next: [Batch, m] 下一时刻的状态
        """
        # 确保 x 是 2D
        if x.dim() == 1:
            x = x.unsqueeze(0)
        
        # 获取当前强迫 (优先使用 u，其次使用 set_forcing 设置的值)
        if u is not None:
            forcing = u
        elif self._current_forcing is not None:
            forcing = self._current_forcing
        else:
            raise ValueError("Must provide u or call set_forcing() before f()")
        
        batch_size = x.shape[0]
        
        # 确保强迫数据维度正确
        if forcing.dim() == 1:
            forcing = forcing.unsqueeze(0)
        if forcing.shape[0] == 1 and batch_size > 1:
            forcing = forcing.expand(batch_size, -1)
        
        # 提取强迫变量
        P = forcing[:, 0:1]
        ETpot = forcing[:, 1:2]
        
        # 获取约束后的参数
        params = self._constrained_params
        
        # 处理参数扩展：如果输入 x 的 batch_size 大于参数的 batch_size (通常发生在 system_model_forecast 的展平操作中)
        if batch_size > self.batch_size:
            # 计算重复次数
            if batch_size % self.batch_size != 0:
                raise ValueError(f"Input batch size {batch_size} is not a multiple of param batch size {self.batch_size}")
            repeat_factor = batch_size // self.batch_size
            
            # 扩展参数
            expanded_params = {}
            for k, v in params.items():
                # v: [original_batch, 1] -> [original_batch, 1, 1] -> repeat -> [original_batch, repeat, 1] -> view -> [new_batch, 1]
                # 注意：system_model_forecast 的展平顺序是 [batch, time]，所以我们需要正确地重复参数
                # 在 system_model_forecast 中: total_samples = batch_size * feasible_timesteps
                # 数据重组方式: rearrange_data_unfold -> reshape
                # 实际上，对于静态参数，我们只需要简单的 repeat_interleave 或者 repeat
                # 这里的 batch_size = original_batch * time_steps
                # 每个 original_batch 的样本对应 time_steps 个时间步，它们共享同一组参数
                # 因此应该使用 repeat_interleave
                expanded_params[k] = v.repeat_interleave(repeat_factor, dim=0)
            params = expanded_params
        
        # 执行 Walrus 模型的一步前向传播
        x_next = self._walrus_model.forward_step(x, P, ETpot, params)
        
        return x_next
    
    def h(self, x: torch.Tensor) -> torch.Tensor:
        """
        观测函数 (Observation Model)
        
        将状态映射到可观测量（流量）。
        
        对于 Walrus 模型: Q = q (流量直接对应状态的最后一维)
        
        Args:
            x: [Batch, m] 状态向量
            
        Returns:
            y: [Batch, n] 观测向量 (流量)
        """
        # 确保 x 是 2D
        if x.dim() == 1:
            x = x.unsqueeze(0)
        
        # 提取流量 (q 是状态的最后一维)
        Q = x[:, 4:5]
        
        return Q
    
    def InitSequence(self, m1x_0: torch.Tensor, m2x_0: torch.Tensor):
        """
        初始化状态序列（单样本）
        
        Args:
            m1x_0: [m,] 初始状态均值
            m2x_0: [m, m] 初始状态协方差
        """
        self.m1x_0 = m1x_0.to(self.device)
        self.m2x_0 = m2x_0.to(self.device)
    
    def Init_batched_sequence(self, m1x_0_batch: torch.Tensor, m2x_0_batch: torch.Tensor):
        """
        初始化状态序列（批次）
        
        Args:
            m1x_0_batch: [Batch, m] 初始状态均值
            m2x_0_batch: [Batch, m, m] 初始状态协方差
        """
        self.m1x_0_batch = m1x_0_batch.to(self.device)
        self.x_prev = m1x_0_batch.to(self.device)
        self.m2x_0_batch = m2x_0_batch.to(self.device)
    
    def get_default_initial_state(self) -> torch.Tensor:
        """
        获取默认的初始状态
        
        Returns:
            x0: [Batch, m] 初始状态
        """
        # 使用 Walrus 模型的默认初始化
        states = self._walrus_model._init_states(self.batch_size, self.device)
        x0 = self._walrus_model.get_state_tensor(states)
        return x0
    
    def UpdateCovariance_Matrix(self, Q: torch.Tensor, R: torch.Tensor):
        """更新噪声协方差矩阵"""
        self.Q = Q.to(self.device)
        self.R = R.to(self.device)


# ============================================================================
# 测试代码
# ============================================================================
if __name__ == "__main__":
    print("Testing WalrusSystemModel adapter...")
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    batch_size = 4
    
    # 创建 StaticEncoder 并生成参数
    from .static_encoder import StaticEncoder
    encoder = StaticEncoder(n_attributes=16, n_params=4)  # 输出4个参数
    static_attrs = torch.randn(batch_size, 16)
    hydro_params = encoder(static_attrs)
    
    # 创建 WalrusSystemModel
    sys_model = WalrusSystemModel(
        hydro_params=hydro_params,
        cd=2450.0,
        cs=0.2,
        device=device
    )
    
    print(f"State dimension (m): {sys_model.m}")
    print(f"Observation dimension (n): {sys_model.n}")
    
    # 测试初始状态
    x0 = sys_model.get_default_initial_state()
    print(f"Initial state shape: {x0.shape}")
    
    # 测试状态转移
    forcing = torch.rand(batch_size, 2)  # P, ETpot
    forcing[:, 0] *= 10  # P: 0-10 mm
    forcing[:, 1] *= 5  # ETpot: 0-5 mm
    
    sys_model.set_forcing(forcing)
    x1 = sys_model.f(x0)
    print(f"Next state shape: {x1.shape}")
    
    # 测试观测函数
    y = sys_model.h(x1)
    print(f"Observation shape: {y.shape}")
    print(f"Observation values: {y.squeeze().detach().numpy()}")
    
    print("\n[OK] WalrusSystemModel adapter test passed!")
