"""
Unified Hydrological System Model
=================================

This module provides a unified interface for different hydrological models
(M4 and Walrus) with joint optimization support.

The system integrates:
1. StaticEncoder: Maps catchment attributes to hydrological parameters
2. Differentiable Hydrological Model (M4 or Walrus)
3. KalmanNet: State update (optional, for DA mode)

Author: KalmanNet Global DA Project
Date: 2026-01-20
"""

import torch
import torch.nn as nn
from typing import Tuple, Optional, Literal

from .static_encoder import StaticEncoder
from .differentiable_m4 import DifferentiableM4
from .differentiable_walrus import DifferentiableWalrus
from .m4_system_model import M4SystemModel
from .walrus_system_model import WalrusSystemModel
# NOTE: HBV backbone deprecated & archived 2026-06-05 (weak ~0.49). See archive/project02_hbv_deprecated_20260605/.


class GlobalHydroSystem(nn.Module):
    """
    全球水文系统模型 - 支持 M4 和 Walrus 两种模型
    
    这是一个端到端的可微模型，用于全球尺度的水文状态估计和联合优化。
    
    架构:
        1. StaticEncoder (mode='static_encoder'): 静态属性 -> 水文参数 (泛化能力，可用于无资料流域)
        2. BasinEmbedding (mode='basin_embedding'): 流域ID -> 水文参数 (过拟合能力，用于确定性能上限)
        3. Hydrological Model (M4 or Walrus): 物理过程模型
        4. KalmanNet: 状态更新（可选，用于 DA 模式）
    
    Args:
        model_type: "m4" 或 "walrus"
        param_mode: "static_encoder" 或 "basin_embedding"
        n_basins: 流域总数（仅 basin_embedding 模式需要）
        n_static_attrs: 静态属性数量（仅 static_encoder 模式需要）
        encoder_hidden: StaticEncoder 隐藏层大小
        encoder_layers: StaticEncoder 层数
        cd: Walrus 固定参数 - 河道深度（仅 Walrus 使用）
        cs: Walrus 固定参数 - 河道形状参数（仅 Walrus 使用）
    """
    
    def __init__(self, 
                 model_type: Literal["m4", "walrus"] = "walrus",
                 param_mode: Literal["static_encoder", "basin_embedding"] = "static_encoder",
                 n_basins: Optional[int] = None,
                 n_static_attrs: int = 16,
                 encoder_hidden: int = 64,
                 encoder_layers: int = 2,
                 encoder_dropout: float = 0.0,
                 cd: float = 2450.0,
                 cs: float = 0.2):
        super().__init__()
        
        self.model_type = model_type.lower()
        self.param_mode = param_mode.lower()
        
        if self.model_type == "m4":
            n_params = DifferentiableM4.N_PARAMS  # 10
        elif self.model_type == "walrus":
            n_params = DifferentiableWalrus.N_PARAMS  # 4
        else:
            raise ValueError(f"Unknown model_type: {model_type}. Must be 'm4' or 'walrus'")
        
        # 参数化模块
        if self.param_mode == "static_encoder":
            self.static_encoder = StaticEncoder(
                n_attributes=n_static_attrs,
                n_params=n_params,
                hidden_size=encoder_hidden,
                n_layers=encoder_layers,
                dropout=encoder_dropout
            )
            self.basin_embedding = None
        elif self.param_mode == "basin_embedding":
            if n_basins is None:
                raise ValueError("n_basins must be provided when param_mode is 'basin_embedding'")
            
            # 使用 Embedding 直接学习每个流域的参数
            self.basin_embedding = nn.Embedding(n_basins, n_params)
            # 初始化：用小的随机扰动，避免初始值太大或太小
            nn.init.normal_(self.basin_embedding.weight, mean=0.0, std=0.1)
            
            self.static_encoder = None
        else:
            raise ValueError(f"Unknown param_mode: {param_mode}")
        
        # 水文模型（无参数，只有计算图）
        if self.model_type == "m4":
            self.hydro_model = DifferentiableM4()
        elif self.model_type == "walrus":
            self.hydro_model = DifferentiableWalrus(cd=cd, cs=cs)
        
        # 存储固定参数（用于 Walrus）
        self.cd = cd
        self.cs = cs
    
    def get_hydro_params(self, 
                        static_attrs: Optional[torch.Tensor] = None,
                        basin_idx: Optional[torch.Tensor] = None) -> torch.Tensor:
        """根据当前模式获取水文参数"""
        if self.param_mode == "static_encoder":
            if static_attrs is None:
                raise ValueError("static_attrs required for static_encoder mode")
            return self.static_encoder(static_attrs)
        elif self.param_mode == "basin_embedding":
            if basin_idx is None:
                # 兼容性处理：如果没传 basin_idx 但传了 static_attrs（batch大小），尝试报错或处理
                # 这里必须报错，因为无法从 static_attrs 推断 basin_idx
                raise ValueError("basin_idx required for basin_embedding mode")
            return self.basin_embedding(basin_idx)
        else:
            raise ValueError(f"Unknown param_mode: {self.param_mode}")

    def create_system_model(self, 
                           static_attrs: Optional[torch.Tensor] = None, 
                           basin_idx: Optional[torch.Tensor] = None,
                           seq_len: int = 365,
                           seq_len_test: int = 365,
                           device: Optional[torch.device] = None) -> M4SystemModel | WalrusSystemModel:
        """
        根据输入（属性或索引）创建系统模型实例（用于 KalmanNet）
        
        Args:
            static_attrs: [Batch, n_static_attrs] 静态属性 (mode='static_encoder')
            basin_idx: [Batch] 流域索引 (mode='basin_embedding')
            seq_len: 训练序列长度
            seq_len_test: 测试序列长度
            device: 计算设备
            
        Returns:
            M4SystemModel 或 WalrusSystemModel 实例
        """
        if device is None:
            device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # 生成水文参数
        hydro_params = self.get_hydro_params(static_attrs, basin_idx)
        
        # 创建系统模型
        if self.model_type == "m4":
            sys_model = M4SystemModel(
                hydro_params=hydro_params,
                device=device,
                seq_len=seq_len,
                seq_len_test=seq_len_test
            )
        elif self.model_type == "walrus":
            sys_model = WalrusSystemModel(
                hydro_params=hydro_params,
                cd=self.cd,
                cs=self.cs,
                device=device,
                seq_len=seq_len,
                seq_len_test=seq_len_test
            )
        else:
            raise ValueError(f"Unknown model_type: {self.model_type}")
        
        return sys_model
    
    def forward_openloop(self, 
                        forcing: torch.Tensor, 
                        static_attrs: Optional[torch.Tensor] = None,
                        basin_idx: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        开环前向传播（不使用 KalmanNet）
        
        用于联合优化的 Open Loop Loss 计算。
        
        Args:
            forcing: [Batch, Time, n_features] 气象驱动
            static_attrs: [Batch, n_static_attrs] 静态属性 (mode='static_encoder')
            basin_idx: [Batch] 流域索引 (mode='basin_embedding')
            
        Returns:
            Q_sim: [Batch, Time, 1] 模拟流量
        """
        # 生成水文参数
        hydro_params = self.get_hydro_params(static_attrs, basin_idx)
        
        # 运行水文模型
        if self.model_type in ("m4", "walrus"):
            Q_sim, final_states = self.hydro_model(forcing, hydro_params)
        else:
            raise ValueError(f"Unknown model_type: {self.model_type}")
        
        return Q_sim
    
    def forward_da(self,
                   forcing: torch.Tensor,
                   static_attrs: torch.Tensor,
                   observations: torch.Tensor,
                   knet_model: nn.Module) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        数据同化前向传播（使用 KalmanNet）
        
        用于联合优化的 DA Loss 计算。
        
        Args:
            forcing: [Batch, Time, n_features] 气象驱动
            static_attrs: [Batch, n_static_attrs] 静态属性
            observations: [Batch, Time, 1] 观测流量
            knet_model: KalmanNet 模型实例
            
        Returns:
            Q_da: [Batch, Time, 1] 同化后的流量
            states_da: Dict - 同化后的状态变量
        """
        # 创建系统模型
        sys_model = self.create_system_model(static_attrs, seq_len=forcing.shape[1])
        
        # 这里需要调用 KalmanNet 的前向传播逻辑
        # 注意：实际的 DA 前向传播应该在训练脚本中实现，
        # 因为需要访问 Pipeline 的完整逻辑
        # 这里只是一个占位接口
        
        raise NotImplementedError(
            "forward_da should be implemented in the training script "
            "using the existing Pipeline logic"
        )


# ============================================================================
# 测试代码
# ============================================================================
if __name__ == "__main__":
    print("Testing GlobalHydroSystem...")
    
    batch_size = 4
    time_steps = 30
    n_static_attrs = 16
    
    # 测试 M4 模型
    print("\n--- Testing M4 Model ---")
    m4_system = GlobalHydroSystem(
        model_type="m4",
        n_static_attrs=n_static_attrs
    )
    
    static_attrs = torch.randn(batch_size, n_static_attrs)
    forcing_m4 = torch.rand(batch_size, time_steps, 3)  # P, T, PET
    forcing_m4[:, :, 0] *= 10
    forcing_m4[:, :, 1] = forcing_m4[:, :, 1] * 20 + 5
    forcing_m4[:, :, 2] *= 5
    
    Q_sim_m4 = m4_system.forward_openloop(forcing_m4, static_attrs)
    print(f"M4 Q_sim shape: {Q_sim_m4.shape}")
    
    # 测试 Walrus 模型
    print("\n--- Testing Walrus Model ---")
    walrus_system = GlobalHydroSystem(
        model_type="walrus",
        n_static_attrs=n_static_attrs,
        cd=2450.0,
        cs=0.2
    )
    
    forcing_walrus = torch.rand(batch_size, time_steps, 2)  # P, ETpot
    forcing_walrus[:, :, 0] *= 10
    forcing_walrus[:, :, 1] *= 5
    
    Q_sim_walrus = walrus_system.forward_openloop(forcing_walrus, static_attrs)
    print(f"Walrus Q_sim shape: {Q_sim_walrus.shape}")
    
    # 测试系统模型创建
    print("\n--- Testing System Model Creation ---")
    sys_model = walrus_system.create_system_model(static_attrs)
    print(f"System model type: {type(sys_model).__name__}")
    print(f"System model state dim: {sys_model.m}")
    print(f"System model obs dim: {sys_model.n}")
    
    print("\n✅ GlobalHydroSystem test passed!")
