"""
Caravan Dataset Loader for PyTorch
===================================

This module provides a PyTorch-compatible Dataset for loading Caravan data,
including both dynamic forcings (meteorological time series) and static 
attributes (catchment characteristics).

Caravan Data Structure:
    data/Caravan/
    ├── attributes/               # Static attributes (CSV files)
    │   ├── camels/
    │   ├── camelsaus/
    │   └── ...
    ├── timeseries/               # Dynamic data (NetCDF per basin)
    │   ├── netcdf/
    │   │   ├── camels/
    │   │   │   └── camels_01013500.nc
    │   │   └── ...
    └── all_basins.txt            # List of all basin IDs

Author: KalmanNet Global DA Project
Date: 2026-01-21
"""

import os
import pandas as pd
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from pathlib import Path
from typing import List, Dict, Tuple, Optional, Union
from tqdm import tqdm
import warnings

# NetCDF 延迟导入（避免启动时的兼容性问题）
HAS_XARRAY = None  # Will be set on first use
HAS_NETCDF4 = None  # Will be set on first use
xr = None
netCDF4 = None


def _check_xarray():
    """Lazy check for xarray availability"""
    global HAS_XARRAY, xr
    if HAS_XARRAY is None:
        try:
            import xarray as _xr
            xr = _xr
            HAS_XARRAY = True
        except Exception as e:
            HAS_XARRAY = False
            warnings.warn(f"xarray not available: {e}. NetCDF via xarray disabled.")
    return HAS_XARRAY


def _check_netcdf4():
    """Lazy check for netCDF4 availability"""
    global HAS_NETCDF4, netCDF4
    if HAS_NETCDF4 is None:
        try:
            import netCDF4 as _nc
            netCDF4 = _nc
            HAS_NETCDF4 = True
        except Exception as e:
            HAS_NETCDF4 = False
            warnings.warn(f"netCDF4 not available: {e}. NetCDF support disabled.")
    return HAS_NETCDF4


def _load_nc_to_dataframe(nc_path: Path) -> pd.DataFrame:
    """
    读取 NetCDF 文件，优先使用 xarray（更稳健），失败后回退到 netCDF4。
    """
    # 1) 优先使用 xarray（支持 h5netcdf/scipy 引擎）
    if _check_xarray():
        try:
            ds = xr.open_dataset(nc_path, engine="h5netcdf")
            df = ds.to_dataframe()
            ds.close()
            # 处理索引
            if 'time' in df.index.names:
                df = df.reset_index().set_index('time')
            elif 'date' in df.columns:
                df = df.set_index('date')
            df.index = pd.to_datetime(df.index)
            return df
        except Exception as e:
            warnings.warn(f"xarray failed to load {nc_path}: {e}. Falling back to netCDF4.")

    # 2) 回退到 netCDF4
    if not _check_netcdf4():
        return None

    try:
        ds = netCDF4.Dataset(str(nc_path), 'r')

        # 提取时间变量
        time_var = None
        for tname in ['time', 'date', 'Date']:
            if tname in ds.variables:
                time_var = ds.variables[tname]
                break

        if time_var is None:
            ds.close()
            return None

        # 解析时间
        try:
            from netCDF4 import num2date
            times = num2date(time_var[:], units=time_var.units, calendar=getattr(time_var, 'calendar', 'standard'))
            times = pd.to_datetime([t.strftime('%Y-%m-%d') for t in times])
        except Exception:
            times = pd.to_datetime(time_var[:])

        # 提取所有变量
        data = {}
        for var_name in ds.variables:
            if var_name in ['time', 'date', 'Date']:
                continue
            var = ds.variables[var_name]
            if len(var.shape) == 1 and var.shape[0] == len(times):
                data[var_name] = var[:]

        ds.close()

        df = pd.DataFrame(data, index=times)
        df.index.name = 'date'
        return df

    except Exception as e:
        warnings.warn(f"Failed to load {nc_path} via netCDF4: {e}")
        return None


# ============================================================================
# 变量定义 (参考 DATA_USAGE_GUIDE.md)
# ============================================================================

# Caravan 动态输入变量（与 M4 模型匹配）
DEFAULT_DYNAMIC_INPUTS = [
    'total_precipitation_sum',           # 降水 (mm) -> M4 P
    'temperature_2m_mean',               # 平均气温 (K) -> M4 T (需转换为°C)
    'potential_evaporation_sum',         # 潜在蒸发 (mm) -> M4 PET
]

# 备选动态变量（扩展用）
EXTENDED_DYNAMIC_INPUTS = [
    'total_precipitation_sum',
    'temperature_2m_mean',
    'temperature_2m_max',
    'temperature_2m_min',
    'potential_evaporation_sum',
    'surface_net_solar_radiation_mean',
    'snow_depth_water_equivalent_mean',
]

# Caravan 静态属性（用于 StaticEncoder）
DEFAULT_STATIC_ATTRIBUTES = [
    # 气候属性 (Climate)
    'p_mean',                    # 年均降水 (mm/day)
    'pet_mean',                  # 年均潜在蒸发 (mm/day)
    'aridity',                   # 干旱指数 PET/P
    'frac_snow',                 # 降雪比例
    'high_prec_freq',            # 高降水频率 (days/year)
    'low_prec_freq',             # 低降水频率
    # 地形属性 (Topography) - 来自 HydroATLAS
    'ele_mt_sav',                # 平均高程 (m)
    'slp_dg_sav',                # 平均坡度 (degree)
    'area',                      # 流域面积 (km²)
    # 土壤属性 (Soil)
    'cly_pc_sav',                # 黏土比例 (%)
    'snd_pc_sav',                # 砂土比例 (%)
    'slt_pc_sav',                # 粉砂比例 (%)
    'soc_th_sav',                # 土壤有机碳
    # 植被属性 (Vegetation)
    'for_pc_sse',                # 森林覆盖率 (%)
    'crp_pc_sse',                # 耕地覆盖率 (%)
    'ire_pc_sse',                # 灌溉面积比例
]

# 目标变量
TARGET_VARIABLE = 'streamflow'  # 流量 (mm/day 或 m³/s)


class CaravanDataset(Dataset):
    """
    Caravan 数据集 PyTorch 包装器
    
    这个类负责：
    1. 加载静态属性（一次性加载到内存）
    2. 按需加载动态时间序列
    3. 将数据切片成固定长度的训练窗口
    
    Args:
        data_dir: Caravan 数据根目录
        basins: 要加载的流域 ID 列表（None = 全部）
        dynamic_inputs: 动态输入变量名列表
        static_attributes: 静态属性变量名列表
        seq_length: 序列长度（天数）
        start_date: 开始日期 (str, e.g., '1990-01-01')
        end_date: 结束日期
        normalize_static: 是否标准化静态属性 (Default: True)
        normalize_dynamic: 是否标准化动态变量 (Default: False for physical models)
        cache_timeseries: 是否缓存时间序列到内存
    """
    
    def __init__(self,
                 data_dir: str = 'data/Caravan',
                 basins: Optional[List[str]] = None,
                 dynamic_inputs: List[str] = None,
                 static_attributes: List[str] = None,
                 seq_length: int = 365,
                 start_date: str = '1990-01-01',
                 end_date: str = '2010-12-31',
                 normalize_static: bool = True,
                 normalize_dynamic: bool = False,
                 cache_timeseries: bool = True):
        
        super().__init__()
        
        self.data_dir = Path(data_dir)
        self.seq_length = seq_length
        self.start_date = pd.to_datetime(start_date)
        self.end_date = pd.to_datetime(end_date)
        self.normalize_static = normalize_static
        self.normalize_dynamic = normalize_dynamic
        self.cache_timeseries = cache_timeseries
        
        # 变量列表
        self.dynamic_inputs = dynamic_inputs or DEFAULT_DYNAMIC_INPUTS
        self.static_attributes = static_attributes or DEFAULT_STATIC_ATTRIBUTES
        
        # 加载流域列表
        if basins is None:
            basins = self._load_basin_list()
        self.basins = basins
        
        print(f"Loading Caravan dataset with {len(self.basins)} basins...")
        
        # 加载静态属性
        self.static_data = self._load_static_attributes()
        
        # 过滤掉没有静态属性的流域
        valid_basins = [b for b in self.basins if b in self.static_data.index]
        if len(valid_basins) < len(self.basins):
            warnings.warn(f"Removed {len(self.basins) - len(valid_basins)} basins without static attributes")
        self.basins = valid_basins
        
        # 计算标准化参数
        self._compute_normalization_stats()
        
        # 时间序列缓存
        self._timeseries_cache: Dict[str, pd.DataFrame] = {}
        
        # 构建样本索引 (basin_idx, start_time_idx)
        self.samples = self._build_sample_index()
        
        print(f"Dataset ready: {len(self.samples)} samples from {len(self.basins)} basins")
    
    def _load_basin_list(self) -> List[str]:
        """从 all_basins.txt 加载流域列表"""
        basin_file = self.data_dir / 'all_basins.txt'
        if basin_file.exists():
            with open(basin_file, 'r') as f:
                return [line.strip() for line in f if line.strip()]
        else:
            # 扫描 timeseries 文件夹
            ts_dir = self.data_dir / 'timeseries' / 'csv'
            basins = []
            for subdir in ts_dir.iterdir():
                if subdir.is_dir():
                    for csv_file in subdir.glob('*.csv'):
                        basins.append(csv_file.stem)
            return basins
    
    def _load_static_attributes(self) -> pd.DataFrame:
        """加载所有静态属性"""
        attr_dir = self.data_dir / 'attributes'
        
        all_attrs = []
        
        # 遍历所有子数据集
        for subdir in attr_dir.iterdir():
            if not subdir.is_dir():
                continue
            
            # 尝试加载 caravan 属性文件
            attr_files = list(subdir.glob('attributes_caravan_*.csv'))
            hydro_files = list(subdir.glob('attributes_hydroatlas_*.csv'))
            
            for f in attr_files + hydro_files:
                try:
                    df = pd.read_csv(f, index_col=0)
                    all_attrs.append(df)
                except Exception as e:
                    warnings.warn(f"Failed to load {f}: {e}")
        
        if not all_attrs:
            raise ValueError(f"No attribute files found in {attr_dir}")
        
        # 合并所有属性
        combined = pd.concat(all_attrs, axis=0)
        
        # 去重（同一流域可能在多个文件中）
        combined = combined[~combined.index.duplicated(keep='first')]
        
        # 只保留需要的列
        available_cols = [c for c in self.static_attributes if c in combined.columns]
        if len(available_cols) < len(self.static_attributes):
            missing = set(self.static_attributes) - set(available_cols)
            warnings.warn(f"Missing static attributes: {missing}")
        
        self.static_attributes = available_cols
        
        return combined[available_cols]
    
    def _compute_normalization_stats(self):
        """计算标准化统计量"""
        # 静态属性标准化
        self.static_mean = self.static_data.mean()
        self.static_std = self.static_data.std().replace(0, 1)
        
        # 动态变量的先验统计量（来自 Caravan 文档）
        # 这些是全球范围的大致统计量
        self.dynamic_stats = {
            'total_precipitation_sum': {'mean': 3.0, 'std': 8.0},  # mm/day
            'temperature_2m_mean': {'mean': 283, 'std': 15},       # K
            'temperature_2m_max': {'mean': 290, 'std': 15},
            'temperature_2m_min': {'mean': 278, 'std': 15},
            'potential_evaporation_sum': {'mean': 3.0, 'std': 2.0},
            'surface_net_solar_radiation_mean': {'mean': 1e7, 'std': 8e6},
            'snow_depth_water_equivalent_mean': {'mean': 0.05, 'std': 0.1},
            'streamflow': {'mean': 1.5, 'std': 3.0},  # mm/day
        }
    
    def _build_sample_index(self) -> List[Tuple[int, int]]:
        """
        构建样本索引
        
        每个样本是 (basin_index, time_start_index) 的组合。
        """
        samples = []
        
        # 计算每个流域可以产生的样本数
        total_days = (self.end_date - self.start_date).days + 1
        n_samples_per_basin = max(1, total_days - self.seq_length + 1)
        
        for basin_idx in range(len(self.basins)):
            for t_idx in range(n_samples_per_basin):
                samples.append((basin_idx, t_idx))
        
        return samples
    
    def _load_timeseries(self, basin_id: str) -> pd.DataFrame:
        """加载单个流域的时间序列（支持 NetCDF 和 CSV 格式）"""
        if self.cache_timeseries and basin_id in self._timeseries_cache:
            return self._timeseries_cache[basin_id]
        
        # 确定子数据集
        parts = basin_id.split('_')
        subdataset = parts[0]  # e.g., 'camels', 'hysets', etc.
        
        # 优先尝试 NetCDF 格式
        nc_path = self.data_dir / 'timeseries' / 'netcdf' / subdataset / f'{basin_id}.nc'
        csv_path = self.data_dir / 'timeseries' / 'csv' / subdataset / f'{basin_id}.csv'
        
        df = None
        
        if nc_path.exists():
            # 加载 NetCDF 文件（使用 netCDF4 直接读取）
            df = _load_nc_to_dataframe(nc_path)
        
        if df is None and csv_path.exists():
            # 回退到 CSV 格式
            df = pd.read_csv(csv_path, parse_dates=['date'], index_col='date')
        
        if df is None:
            raise FileNotFoundError(f"Timeseries file not found: {nc_path} or {csv_path}")
        
        # 确保索引是 DatetimeIndex
        if not isinstance(df.index, pd.DatetimeIndex):
            df.index = pd.to_datetime(df.index)
        
        # 筛选日期范围
        df = df.loc[self.start_date:self.end_date]
        
        if self.cache_timeseries:
            self._timeseries_cache[basin_id] = df
        
        return df
    
    def __len__(self) -> int:
        return len(self.samples)
    
    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        """
        获取单个样本
        
        Returns:
            Dict containing:
                - 'forcing': [seq_length, 3] 动态输入 (P, T, PET)
                - 'target': [seq_length, 1] 目标流量
                - 'static': [n_static] 静态属性
                - 'basin_id': str 流域ID
        """
        basin_idx, t_start = self.samples[idx]
        basin_id = self.basins[basin_idx]
        
        # 加载时间序列
        ts = self._load_timeseries(basin_id)
        
        # 切片
        t_end = t_start + self.seq_length
        ts_slice = ts.iloc[t_start:t_end]
        
        # 提取动态输入
        forcing_data = []
        for var in self.dynamic_inputs:
            if var in ts_slice.columns:
                values = ts_slice[var].values.astype(np.float32)
            else:
                # 如果变量缺失，用 0 填充
                values = np.zeros(self.seq_length, dtype=np.float32)
            
            # 温度转换 (K -> °C)
            if 'temperature' in var and values.mean() > 100:
                values = values - 273.15
            
            # 标准化
            if self.normalize_dynamic and var in self.dynamic_stats:
                mean = self.dynamic_stats[var]['mean']
                std = self.dynamic_stats[var]['std']
                # 温度转换后需要调整统计量
                if 'temperature' in var and mean > 100:
                    mean = mean - 273.15
                values = (values - mean) / std
                values = values.astype(np.float32)
            
            forcing_data.append(values)
        
        forcing = np.stack(forcing_data, axis=-1)  # [seq_length, n_features]
        
        # 提取目标变量
        if TARGET_VARIABLE in ts_slice.columns:
            target = ts_slice[TARGET_VARIABLE].values.astype(np.float32)
        else:
            target = np.zeros(self.seq_length, dtype=np.float32)
        
        if self.normalize_dynamic and TARGET_VARIABLE in self.dynamic_stats:
            mean = self.dynamic_stats[TARGET_VARIABLE]['mean']
            std = self.dynamic_stats[TARGET_VARIABLE]['std']
            target = (target - mean) / std
            target = target.astype(np.float32)
        
        target = target.reshape(-1, 1)  # [seq_length, 1]
        
        # 提取静态属性
        if basin_id in self.static_data.index:
            static = self.static_data.loc[basin_id].values.astype(np.float32)
            if self.normalize_static:
                static = (static - self.static_mean.values) / self.static_std.values
                static = static.astype(np.float32)
        else:
            static = np.zeros(len(self.static_attributes), dtype=np.float32)
        
        # 处理 NaN
        forcing = np.nan_to_num(forcing, nan=0.0)
        target = np.nan_to_num(target, nan=0.0)
        static = np.nan_to_num(static, nan=0.0)
        
        return {
            'forcing': torch.from_numpy(forcing),
            'target': torch.from_numpy(target),
            'static': torch.from_numpy(static),
            'basin_id': basin_id,
        }
    
    def get_normalization_params(self) -> Dict:
        """返回标准化参数（用于反标准化）"""
        return {
            'static_mean': self.static_mean,
            'static_std': self.static_std,
            'dynamic_stats': self.dynamic_stats,
        }


def create_caravan_dataloader(
    data_dir: str = 'data/Caravan',
    basins: Optional[List[str]] = None,
    seq_length: int = 365,
    start_date: str = '1990-01-01',
    end_date: str = '2010-12-31',
    batch_size: int = 256,
    shuffle: bool = True,
    num_workers: int = 0,  # Windows 建议设为 0
    **kwargs
) -> DataLoader:
    """
    创建 Caravan DataLoader 的便捷函数
    
    Args:
        data_dir: 数据目录
        basins: 流域列表
        seq_length: 序列长度
        start_date: 开始日期
        end_date: 结束日期
        batch_size: 批次大小
        shuffle: 是否打乱
        num_workers: 数据加载线程数
        
    Returns:
        PyTorch DataLoader
    """
    dataset = CaravanDataset(
        data_dir=data_dir,
        basins=basins,
        seq_length=seq_length,
        start_date=start_date,
        end_date=end_date,
        **kwargs
    )
    
    def collate_fn(batch):
        """自定义 collate 函数处理字符串字段"""
        forcing = torch.stack([b['forcing'] for b in batch])
        target = torch.stack([b['target'] for b in batch])
        static = torch.stack([b['static'] for b in batch])
        basin_ids = [b['basin_id'] for b in batch]
        
        return {
            'forcing': forcing,
            'target': target,
            'static': static,
            'basin_ids': basin_ids,
        }
    
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        collate_fn=collate_fn,
        pin_memory=torch.cuda.is_available(),
    )


# ============================================================================
# 简单测试
# ============================================================================
if __name__ == "__main__":
    print("Testing CaravanDataset...")
    
    # 测试加载少量数据
    try:
        dataset = CaravanDataset(
            data_dir='data/Caravan',
            basins=None,  # 加载全部
            seq_length=30,  # 短序列用于测试
            start_date='2000-01-01',
            end_date='2000-12-31',
            cache_timeseries=False,  # 不缓存节省内存
        )
        
        print(f"\nDataset size: {len(dataset)}")
        print(f"Number of basins: {len(dataset.basins)}")
        print(f"Static attributes: {dataset.static_attributes}")
        print(f"Dynamic inputs: {dataset.dynamic_inputs}")
        
        # 获取一个样本
        sample = dataset[0]
        print(f"\nSample keys: {sample.keys()}")
        print(f"Forcing shape: {sample['forcing'].shape}")
        print(f"Target shape: {sample['target'].shape}")
        print(f"Static shape: {sample['static'].shape}")
        print(f"Basin ID: {sample['basin_id']}")
        
        # 测试 DataLoader
        loader = create_caravan_dataloader(
            data_dir='data/Caravan',
            seq_length=30,
            start_date='2000-01-01',
            end_date='2000-12-31',
            batch_size=4,
        )
        
        batch = next(iter(loader))
        print(f"\nBatch forcing shape: {batch['forcing'].shape}")
        print(f"Batch target shape: {batch['target'].shape}")
        print(f"Batch static shape: {batch['static'].shape}")
        print(f"Basin IDs: {batch['basin_ids']}")
        
        print("\n✅ CaravanDataset test passed!")
        
    except FileNotFoundError as e:
        print(f"⚠️ Data not found (expected if Caravan not linked): {e}")
    except Exception as e:
        print(f"❌ Test failed: {e}")
        raise
