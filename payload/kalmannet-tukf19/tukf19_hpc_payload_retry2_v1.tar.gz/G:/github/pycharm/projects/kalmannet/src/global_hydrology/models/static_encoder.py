"""
Static Encoder - Maps catchment attributes to hydrological parameters
======================================================================

This module implements the "brain" that generates catchment-specific 
hydrological parameters from static attributes (soil, topography, climate).

This is the key to global generalization:
- Instead of manually calibrating parameters for each catchment,
- The neural network learns the mapping: Attributes -> Parameters

Architecture:
    Input: Static attributes (e.g., 30 features from Caravan)
    Hidden: MLP with residual connections
    Output: Raw parameters (to be constrained by DifferentiableM4)

Author: KalmanNet Global DA Project
Date: 2026-01-07
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional


class StaticEncoder(nn.Module):
    """
    静态属性编码器 (Static Attribute Encoder)
    
    将流域的静态属性（土壤、地形、气候指数）映射到水文模型参数。
    这是实现"一个模型适配全球"的核心组件。
    
    Args:
        n_attributes: 静态属性的数量 (Caravan ~30)
        n_params: 输出的水文参数数量 (M4 = 10)
        hidden_size: 隐藏层大小
        n_layers: 隐藏层数量
        dropout: Dropout 比例
        
    Example:
        encoder = StaticEncoder(n_attributes=30, n_params=10)
        attrs = torch.randn(batch_size, 30)  # Static attributes
        params = encoder(attrs)  # [batch_size, 10] raw params
    """
    
    def __init__(self, 
                 n_attributes: int = 30,
                 n_params: int = 10,
                 hidden_size: int = 64,
                 n_layers: int = 2,
                 dropout: float = 0.1):
        super().__init__()
        
        self.n_attributes = n_attributes
        self.n_params = n_params
        self.hidden_size = hidden_size
        
        # 输入层：属性 -> 隐藏空间
        self.input_layer = nn.Sequential(
            nn.Linear(n_attributes, hidden_size),
            nn.LayerNorm(hidden_size),
            nn.ReLU(),
            nn.Dropout(dropout)
        )
        
        # 隐藏层（带残差连接）
        self.hidden_layers = nn.ModuleList()
        for _ in range(n_layers):
            self.hidden_layers.append(
                ResidualBlock(hidden_size, dropout)
            )
        
        # 输出层：隐藏空间 -> 原始参数
        self.output_layer = nn.Linear(hidden_size, n_params)
        
        # 参数初始化（使输出接近 0，让 M4 的 softplus/sigmoid 从中间值开始）
        nn.init.zeros_(self.output_layer.weight)
        nn.init.zeros_(self.output_layer.bias)
        
    def forward(self, static_attributes: torch.Tensor) -> torch.Tensor:
        """
        前向传播
        
        Args:
            static_attributes: [Batch, n_attributes] - 静态属性
            
        Returns:
            raw_params: [Batch, n_params] - 原始参数（未约束）
        """
        x = self.input_layer(static_attributes)
        
        for layer in self.hidden_layers:
            x = layer(x)
        
        raw_params = self.output_layer(x)
        
        return raw_params
    
    def get_knet_initial_state(self, static_attributes: torch.Tensor,
                                lstm_hidden_size: int) -> tuple:
        """
        为 KalmanNet 的 LSTM 生成初始隐状态。
        
        这是实现 "Attribute-Aware KalmanNet" 的关键：
        让 KalmanNet 在开始过滤之前，就根据流域属性"定好性格"。
        
        Args:
            static_attributes: [Batch, n_attributes]
            lstm_hidden_size: KalmanNet LSTM 的隐藏层大小
            
        Returns:
            (h_0, c_0): LSTM 初始状态元组，每个 [1, Batch, lstm_hidden_size]
        """
        # 复用 input_layer 的特征提取
        features = self.input_layer(static_attributes)
        
        # 投影到 LSTM 隐藏空间
        # 注意：这里需要额外的投影层，暂时用线性插值
        batch_size = static_attributes.shape[0]
        
        # 简单方案：用 hidden_size 的特征去初始化 lstm_hidden_size
        # 实际项目中可以增加一个专门的投影层
        if self.hidden_size != lstm_hidden_size:
            # 如果维度不匹配，用简单的线性插值
            features = F.adaptive_avg_pool1d(
                features.unsqueeze(1),  # [B, 1, hidden_size]
                lstm_hidden_size
            ).squeeze(1)  # [B, lstm_hidden_size]
        
        # 形状调整为 LSTM 需要的 [n_layers, Batch, hidden_size]
        h_0 = features.unsqueeze(0)  # [1, B, lstm_hidden_size]
        c_0 = torch.zeros_like(h_0)  # cell state 初始化为 0
        
        return (h_0, c_0)


class ResidualBlock(nn.Module):
    """
    带残差连接的全连接层块
    
    残差连接有助于梯度流动，在深层网络中尤为重要。
    """
    
    def __init__(self, hidden_size: int, dropout: float = 0.1):
        super().__init__()
        
        self.block = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.LayerNorm(hidden_size),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_size, hidden_size),
            nn.LayerNorm(hidden_size),
        )
        self.activation = nn.ReLU()
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.activation(x + self.block(x))


# ============================================================================
# 简单测试
# ============================================================================
if __name__ == "__main__":
    print("Testing StaticEncoder...")
    
    # 创建编码器
    encoder = StaticEncoder(
        n_attributes=30,
        n_params=10,
        hidden_size=64,
        n_layers=2
    )
    
    # 打印参数量
    n_params = sum(p.numel() for p in encoder.parameters())
    print(f"Total parameters: {n_params:,}")
    
    # 创建假数据
    batch_size = 8
    static_attrs = torch.randn(batch_size, 30)
    
    # 前向传播
    raw_params = encoder(static_attrs)
    print(f"Input shape: {static_attrs.shape}")
    print(f"Output shape: {raw_params.shape}")
    print(f"Sample output: {raw_params[0].detach().numpy()}")
    
    # 测试 KNet 初始状态生成
    h_0, c_0 = encoder.get_knet_initial_state(static_attrs, lstm_hidden_size=128)
    print(f"LSTM h_0 shape: {h_0.shape}")
    print(f"LSTM c_0 shape: {c_0.shape}")
    
    # 测试梯度
    loss = raw_params.mean()
    loss.backward()
    print(f"Gradient flows correctly: {static_attrs.grad is None}")  # attrs 不需要梯度
    
    print("\n✅ StaticEncoder test passed!")
