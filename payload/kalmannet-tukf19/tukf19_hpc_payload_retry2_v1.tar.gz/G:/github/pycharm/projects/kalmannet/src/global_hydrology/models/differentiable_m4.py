"""
Differentiable M4 Hydrological Model (PyTorch Implementation)
==============================================================

A generic, differentiable hydrological model structure inspired by HBV and SuperflexPy.
This "M4" structure contains 4 core reservoirs:
    1. Snow Reservoir - Handles snowfall accumulation and melt (Degree-day method)
    2. Soil Reservoir - Non-linear bucket for runoff generation (Beta function)
    3. Fast Reservoir - Quick response runoff (flood peaks)
    4. Slow Reservoir - Baseflow component (groundwater)

Key Design Principles:
    - All operations use PyTorch tensors for automatic differentiation.
    - Supports batch processing (multiple catchments simultaneously).
    - Parameters are passed externally (from StaticEncoder), not learned internally.
    - Physical constraints enforced via softplus/clamp.

Author: KalmanNet Global DA Project
Date: 2026-01-07
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple, Optional, Dict


class DifferentiableM4(nn.Module):
    """
    可微分 M4 水文模型 (Differentiable M4 Hydrological Model)
    
    这是一个通用的、支持全球尺度的水文模型骨架。
    它不包含可学习的参数，所有水文参数由外部的 StaticEncoder 提供。
    
    Attributes:
        eps (float): 数值稳定性常数，防止除零。
    
    Args (forward):
        forcing: [Batch, Time, 3] - 气象驱动 (Precip, Temp, PET)
        hydro_params: [Batch, N_PARAMS] - 由 StaticEncoder 生成的水文参数
        state_init: Optional - 初始状态字典
        
    Returns:
        q_sim: [Batch, Time, 1] - 模拟流量
        states_all: Dict - 所有时间步的状态变量（用于分析/KNet修正）
    """
    
    # 参数索引常量 (便于代码阅读和维护)
    # 共 10 个参数
    PARAM_TT = 0        # 临界温度 (°C) - Snow/Rain threshold
    PARAM_CFMAX = 1     # 融雪系数 (mm/°C/day) - Degree-day factor
    PARAM_FC = 2        # 田间持水量 (mm) - Max soil moisture capacity
    PARAM_BETA = 3      # 非线性指数 (-) - Shape parameter for runoff
    PARAM_LP = 4        # 蒸发阈值比例 (-) - Limit for potential ET
    PARAM_K0 = 5        # 快流衰减系数 (1/day) - Upper zone recession
    PARAM_K1 = 6        # 慢流衰减系数 (1/day) - Lower zone recession
    PARAM_K2 = 7        # 极慢流衰减系数 (1/day) - Deep groundwater
    PARAM_PERC = 8      # 下渗率 (mm/day) - Percolation to lower zone
    PARAM_ALPHA = 9     # 分流系数 (-) - Split between fast/slow
    
    N_PARAMS = 10       # 总参数数量
    N_STATES = 4        # 状态变量数量 (Snow, Soil, Fast, Slow)
    
    def __init__(self, eps: float = 1e-6):
        super().__init__()
        self.eps = eps
        
    def _constrain_params(self, raw_params: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        将原始参数转换为物理合理的范围。
        使用 softplus 确保正值，使用 sigmoid 确保 [0, 1] 范围。
        
        这是关键步骤：Static Encoder 输出的是无约束的实数，
        我们在这里将其映射到水文上合理的范围。
        
        Args:
            raw_params: [Batch, N_PARAMS] - 原始参数（无约束）
            
        Returns:
            params: Dict[str, Tensor] - 约束后的参数字典
        """
        # 使用 softplus 保证正值: softplus(x) = log(1 + exp(x))
        # 使用 sigmoid 保证 [0, 1]: sigmoid(x) = 1 / (1 + exp(-x))
        
        params = {}
        
        # 温度阈值: 范围约 [-5, 5] °C
        params['TT'] = raw_params[:, self.PARAM_TT:self.PARAM_TT+1]  # 不约束，可正可负
        
        # 融雪系数: 放宽下限，允许弱融雪 [~0.1, +inf) mm/°C/day
        params['CFMAX'] = F.softplus(raw_params[:, self.PARAM_CFMAX:self.PARAM_CFMAX+1]) + 0.1
        
        # 田间持水量: 范围约 [50, 700] mm
        params['FC'] = F.softplus(raw_params[:, self.PARAM_FC:self.PARAM_FC+1]) * 100 + 50
        
        # 非线性指数: 范围约 [1, 6]
        params['BETA'] = F.softplus(raw_params[:, self.PARAM_BETA:self.PARAM_BETA+1]) + 1.0
        
        # 蒸发阈值比例: 放宽到 [0.05, 1.0]
        params['LP'] = torch.sigmoid(raw_params[:, self.PARAM_LP:self.PARAM_LP+1]) * 0.95 + 0.05
        
        # 快流衰减: 放宽到 [0.001, 1.0] 1/day
        params['K0'] = torch.sigmoid(raw_params[:, self.PARAM_K0:self.PARAM_K0+1]) * 0.999 + 0.001
        
        # 慢流衰减: 放宽到 [0.001, 0.6] 1/day
        params['K1'] = torch.sigmoid(raw_params[:, self.PARAM_K1:self.PARAM_K1+1]) * 0.599 + 0.001
        
        # 极慢流衰减: 放宽到 [1e-5, 0.05] 1/day
        params['K2'] = torch.sigmoid(raw_params[:, self.PARAM_K2:self.PARAM_K2+1]) * 0.04999 + 0.00001
        
        # 下渗率: 范围约 [0, 6] mm/day
        params['PERC'] = F.softplus(raw_params[:, self.PARAM_PERC:self.PARAM_PERC+1])
        
        # 分流系数: 范围 [0, 1] (快流占比)
        params['ALPHA'] = torch.sigmoid(raw_params[:, self.PARAM_ALPHA:self.PARAM_ALPHA+1])
        
        return params
    
    def _init_states(self, batch_size: int, device: torch.device, 
                     params: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """
        初始化状态变量。
        
        Args:
            batch_size: 批次大小
            device: 计算设备 (CPU/GPU)
            params: 约束后的参数字典
            
        Returns:
            states: Dict containing S_snow, S_soil, S_fast, S_slow
        """
        states = {
            'S_snow': torch.zeros(batch_size, 1, device=device),
            'S_soil': params['FC'] * 0.5,  # 初始化为半饱和状态
            'S_fast': torch.zeros(batch_size, 1, device=device),
            'S_slow': torch.zeros(batch_size, 1, device=device) + 50.0,  # 增加初始基流（从10增加到50 mm）
        }
        return states
    
    def _snow_module(self, P: torch.Tensor, T: torch.Tensor, 
                     S_snow: torch.Tensor, params: Dict[str, torch.Tensor]
                     ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        积雪模块 (Snow Module) - Degree-day method
        
        物理过程:
            1. 如果气温 < TT，降水以雪的形式累积。
            2. 如果气温 >= TT，积雪按度日因子融化。
        
        Args:
            P: [Batch, 1] 降水量 (mm/day)
            T: [Batch, 1] 气温 (°C)
            S_snow: [Batch, 1] 当前积雪量 (mm)
            params: 参数字典
            
        Returns:
            S_snow_new: 更新后的积雪量
            P_rain: 液态降雨量 (mm/day)
            Melt: 融雪量 (mm/day)
        """
        TT = params['TT']
        CFMAX = params['CFMAX']
        
        # 使用 sigmoid 进行软分类 (避免 if/else 不可微)
        # 温度越高于 TT，snow_frac 越接近 0
        snow_frac = torch.sigmoid(-(T - TT) * 2.0)  # 平滑过渡
        rain_frac = 1.0 - snow_frac
        
        # 降雪和降雨
        P_snow = P * snow_frac
        P_rain = P * rain_frac
        
        # 融雪 (仅当 T > TT 时发生)
        # 潜在融雪量 = CFMAX * (T - TT)
        potential_melt = CFMAX * F.relu(T - TT)  # relu 确保非负
        Melt = torch.min(potential_melt, S_snow)  # 不能融超过现有积雪
        
        # 质量平衡
        S_snow_new = S_snow + P_snow - Melt
        S_snow_new = F.relu(S_snow_new)  # 确保非负
        
        # 有效降水 = 液态雨 + 融雪
        P_eff = P_rain + Melt
        
        return S_snow_new, P_eff, Melt
    
    def _soil_module(self, P_eff: torch.Tensor, PET: torch.Tensor,
                     S_soil: torch.Tensor, params: Dict[str, torch.Tensor]
                     ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        土壤模块 (Soil Moisture Module) - Beta function runoff generation
        
        物理过程:
            1. 产流: 当土壤越湿，越多的降雨变成径流。
            2. 蒸发: 实际蒸发受土壤湿度限制。
            
        核心公式:
            产流系数 = (S_soil / FC) ^ BETA
            实际蒸发 = PET * min(S_soil / (LP * FC), 1)
        
        Args:
            P_eff: [Batch, 1] 有效降水 (mm/day)
            PET: [Batch, 1] 潜在蒸发 (mm/day)
            S_soil: [Batch, 1] 当前土壤水量 (mm)
            params: 参数字典
            
        Returns:
            S_soil_new: 更新后的土壤水量
            Recharge: 产流量/下渗补给 (mm/day)
            E_act: 实际蒸发量 (mm/day)
        """
        FC = params['FC']
        BETA = params['BETA']
        LP = params['LP']
        
        # 相对土壤湿度 [0, 1]
        rel_soil = torch.clamp(S_soil / (FC + self.eps), 0.0, 1.0)
        
        # 产流系数 (非线性: 土壤越湿，产流越多)
        runoff_coeff = torch.pow(rel_soil + self.eps, BETA)
        runoff_coeff = torch.clamp(runoff_coeff, 0.0, 1.0)
        
        # 产流量 (进入快/慢流水库)
        Recharge = P_eff * runoff_coeff
        
        # 实际蒸发 (受土壤湿度限制)
        # 当 S_soil < LP * FC 时，蒸发受限
        LP_threshold = LP * FC
        evap_factor = torch.clamp(S_soil / (LP_threshold + self.eps), 0.0, 1.0)
        E_act = PET * evap_factor
        
        # 确保不蒸发超过现有水量
        E_act = torch.min(E_act, S_soil)
        
        # 入渗量 (未产流的部分进入土壤)
        Infiltration = P_eff - Recharge
        
        # 质量平衡
        S_soil_new = S_soil + Infiltration - E_act
        
        # 处理溢出 (超过 FC 的部分全部产流)
        overflow = F.relu(S_soil_new - FC)
        S_soil_new = S_soil_new - overflow
        Recharge = Recharge + overflow
        
        # 确保非负
        S_soil_new = F.relu(S_soil_new)
        
        return S_soil_new, Recharge, E_act
    
    def _routing_module(self, Recharge: torch.Tensor,
                        S_fast: torch.Tensor, S_slow: torch.Tensor,
                        params: Dict[str, torch.Tensor]
                        ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        汇流模块 (Routing Module) - Parallel linear reservoirs
        
        物理过程:
            1. 产流按 ALPHA 比例分配到快流和慢流水库。
            2. 快流水库: 响应快，产生洪峰。
            3. 慢流水库: 响应慢，产生基流。
            4. 下渗: 快流水库向慢流水库缓慢下渗。
        
        Args:
            Recharge: [Batch, 1] 产流补给 (mm/day)
            S_fast: [Batch, 1] 快流水库蓄量 (mm)
            S_slow: [Batch, 1] 慢流水库蓄量 (mm)
            params: 参数字典
            
        Returns:
            S_fast_new, S_slow_new: 更新后的水库蓄量
            Q_fast, Q_slow: 快流和慢流出流 (mm/day)
        """
        K0 = params['K0']
        K1 = params['K1']
        PERC = params['PERC']
        ALPHA = params['ALPHA']
        
        # 分流
        R_fast = Recharge * ALPHA
        R_slow = Recharge * (1.0 - ALPHA)
        
        # 快流出流 (Q = K * S)
        Q_fast = K0 * S_fast
        
        # 下渗 (从快流到慢流)
        Perc = torch.min(PERC, S_fast)  # 不能下渗超过现有量
        
        # 快流水库质量平衡
        S_fast_new = S_fast + R_fast - Q_fast - Perc
        S_fast_new = F.relu(S_fast_new)
        
        # 慢流出流
        Q_slow = K1 * S_slow
        
        # 慢流水库质量平衡
        S_slow_new = S_slow + R_slow + Perc - Q_slow
        S_slow_new = F.relu(S_slow_new)
        
        return S_fast_new, S_slow_new, Q_fast, Q_slow
    
    def forward(self, forcing: torch.Tensor, hydro_params: torch.Tensor,
                state_init: Optional[Dict[str, torch.Tensor]] = None,
                return_internals: bool = False
                ) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """
        前向传播 - 运行水文模型
        
        Args:
            forcing: [Batch, Time, 3] - 气象驱动
                     Channel 0: Precipitation (mm/day)
                     Channel 1: Temperature (°C)
                     Channel 2: Potential Evapotranspiration (mm/day)
            hydro_params: [Batch, N_PARAMS] - 由 StaticEncoder 生成的原始参数
            state_init: Optional - 初始状态字典（用于 KalmanNet 修正后重启）
            return_internals: 是否返回内部通量（用于诊断）
            
        Returns:
            Q_sim: [Batch, Time, 1] - 模拟总流量 (mm/day)
            final_states: Dict - 最终时刻的状态变量
            (optional) internals: Dict - 内部通量时间序列
        """
        batch_size, time_steps, n_features = forcing.shape
        device = forcing.device
        
        assert n_features >= 3, f"Forcing must have at least 3 features, got {n_features}"
        assert hydro_params.shape[1] == self.N_PARAMS, \
            f"Expected {self.N_PARAMS} params, got {hydro_params.shape[1]}"
        
        # 1. 约束参数到物理合理范围
        params = self._constrain_params(hydro_params)
        
        # 2. 初始化状态
        if state_init is None:
            states = self._init_states(batch_size, device, params)
        else:
            states = {k: v.clone() for k, v in state_init.items()}
        
        S_snow = states['S_snow']
        S_soil = states['S_soil']
        S_fast = states['S_fast']
        S_slow = states['S_slow']
        
        # 3. 存储输出
        Q_sim_list = []
        
        if return_internals:
            internals = {
                'S_snow': [], 'S_soil': [], 'S_fast': [], 'S_slow': [],
                'Melt': [], 'Recharge': [], 'E_act': [], 'Q_fast': [], 'Q_slow': []
            }
        
        # 4. 时间步循环
        for t in range(time_steps):
            # 提取当前时刻的驱动
            P = forcing[:, t, 0:1]    # Precipitation
            T = forcing[:, t, 1:2]    # Temperature
            PET = forcing[:, t, 2:3]  # Potential ET
            
            # --- A. Snow Module ---
            S_snow, P_eff, Melt = self._snow_module(P, T, S_snow, params)
            
            # --- B. Soil Module ---
            S_soil, Recharge, E_act = self._soil_module(P_eff, PET, S_soil, params)
            
            # --- C. Routing Module ---
            S_fast, S_slow, Q_fast, Q_slow = self._routing_module(
                Recharge, S_fast, S_slow, params
            )
            
            # --- D. Total Discharge ---
            Q_total = Q_fast + Q_slow
            Q_sim_list.append(Q_total)
            
            # 存储内部变量（如果需要）
            if return_internals:
                internals['S_snow'].append(S_snow.detach())
                internals['S_soil'].append(S_soil.detach())
                internals['S_fast'].append(S_fast.detach())
                internals['S_slow'].append(S_slow.detach())
                internals['Melt'].append(Melt.detach())
                internals['Recharge'].append(Recharge.detach())
                internals['E_act'].append(E_act.detach())
                internals['Q_fast'].append(Q_fast.detach())
                internals['Q_slow'].append(Q_slow.detach())
        
        # 5. 拼接时间步
        Q_sim = torch.stack(Q_sim_list, dim=1)  # [Batch, Time, 1]
        
        # 6. 最终状态
        final_states = {
            'S_snow': S_snow,
            'S_soil': S_soil,
            'S_fast': S_fast,
            'S_slow': S_slow,
        }
        
        if return_internals:
            # 将列表转为张量
            for key in internals:
                internals[key] = torch.stack(internals[key], dim=1)
            return Q_sim, final_states, internals
        
        return Q_sim, final_states
    
    def get_state_tensor(self, states: Dict[str, torch.Tensor]) -> torch.Tensor:
        """
        将状态字典转换为单个张量（用于 KalmanNet 处理）
        
        Args:
            states: Dict with S_snow, S_soil, S_fast, S_slow
            
        Returns:
            state_tensor: [Batch, N_STATES]
        """
        return torch.cat([
            states['S_snow'],
            states['S_soil'],
            states['S_fast'],
            states['S_slow'],
        ], dim=-1)
    
    def set_state_from_tensor(self, state_tensor: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        将状态张量转换回字典（KalmanNet 修正后使用）
        
        Args:
            state_tensor: [Batch, N_STATES]
            
        Returns:
            states: Dict with S_snow, S_soil, S_fast, S_slow
        """
        return {
            'S_snow': state_tensor[:, 0:1],
            'S_soil': state_tensor[:, 1:2],
            'S_fast': state_tensor[:, 2:3],
            'S_slow': state_tensor[:, 3:4],
        }


# ============================================================================
# 简单测试
# ============================================================================
if __name__ == "__main__":
    print("Testing DifferentiableM4...")
    
    # 创建模型
    model = DifferentiableM4()
    
    # 创建假数据
    batch_size = 4
    time_steps = 365
    
    # 气象驱动: [Batch, Time, 3] (Precip, Temp, PET)
    forcing = torch.rand(batch_size, time_steps, 3)
    forcing[:, :, 0] *= 20    # Precip: 0-20 mm/day
    forcing[:, :, 1] = forcing[:, :, 1] * 30 - 5  # Temp: -5 to 25 °C
    forcing[:, :, 2] *= 5     # PET: 0-5 mm/day
    
    # 水文参数: [Batch, N_PARAMS]
    hydro_params = torch.randn(batch_size, model.N_PARAMS)
    
    # 前向传播
    Q_sim, final_states = model(forcing, hydro_params)
    
    print(f"Input forcing shape: {forcing.shape}")
    print(f"Input params shape: {hydro_params.shape}")
    print(f"Output Q_sim shape: {Q_sim.shape}")
    print(f"Final states: {list(final_states.keys())}")
    print(f"Sample Q values: {Q_sim[0, :5, 0].detach().numpy()}")
    
    # 测试梯度
    loss = Q_sim.mean()
    loss.backward()
    print(f"Gradient flows correctly: {hydro_params.grad is not None}")
    
    print("\n✅ DifferentiableM4 test passed!")
