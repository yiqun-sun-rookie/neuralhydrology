"""Differentiable full-state counterpart of the audited aligned GR4J-PDD UKF."""

from __future__ import annotations

from collections.abc import Callable
import math

import torch

from scripts.run_aligned_gr4j_da import (
    _matrix_for_day,
    _project_vector,
    _state_boundary_hits,
    _validate_external_covariance,
    _variance_for_day,
    constrained_covariance_update,
    merwe_sigma_points,
    permission_mask,
)


def minimum_active_process_multipliers(
    state_scale: torch.Tensor,
    *,
    baseline_multiplier: float,
    covariance_floor: float = 1e-12,
    floor_multiple: float = 10.0,
) -> torch.Tensor:
    """Keep every diagonal process variance above the filter's numerical floor."""
    scale = torch.as_tensor(state_scale)
    if scale.ndim != 1 or not torch.is_floating_point(scale):
        raise ValueError("state_scale must be a floating-point vector")
    if not torch.isfinite(scale).all() or torch.any(scale <= 0.0):
        raise ValueError("state_scale must be positive and finite")
    for name, value in (
        ("baseline_multiplier", baseline_multiplier),
        ("covariance_floor", covariance_floor),
        ("floor_multiple", floor_multiple),
    ):
        if not math.isfinite(float(value)) or float(value) <= 0.0:
            raise ValueError(f"{name} must be positive and finite")
    maximum_initial_variance = scale.square().max().clamp(min=1.0)
    minimum_process_variance = (
        float(floor_multiple) * float(covariance_floor) * maximum_initial_variance)
    baseline = torch.full_like(scale, float(baseline_multiplier))
    return torch.maximum(baseline, minimum_process_variance / scale.square())


class PositiveDiagonalProcessNoise(torch.nn.Module):
    """One strictly positive process-variance multiplier per persistent state."""

    def __init__(
        self,
        state_dimension: int,
        initial_multiplier: float | torch.Tensor,
        *,
        dtype: torch.dtype = torch.float64,
        device: torch.device | str = "cpu",
    ) -> None:
        super().__init__()
        if state_dimension < 1:
            raise ValueError("state_dimension must be positive")
        supplied = torch.as_tensor(initial_multiplier, dtype=dtype, device=device)
        if supplied.ndim == 0:
            reference = torch.full(
                (int(state_dimension),), float(supplied), dtype=dtype, device=device)
        elif supplied.shape == (int(state_dimension),):
            reference = supplied.clone()
        else:
            raise ValueError("initial_multiplier must be scalar or have one value per state")
        if not torch.isfinite(reference).all() or torch.any(reference <= 0.0):
            raise ValueError("initial_multiplier must be positive and finite")
        self.register_buffer("reference_multipliers", reference)
        self.log_multipliers = torch.nn.Parameter(torch.zeros_like(reference))

    def multipliers(self) -> torch.Tensor:
        return self.reference_multipliers * torch.exp(self.log_multipliers)

    def covariance(self, state_scale: torch.Tensor) -> torch.Tensor:
        scale = torch.as_tensor(
            state_scale,
            dtype=self.log_multipliers.dtype,
            device=self.log_multipliers.device,
        )
        if scale.shape != self.log_multipliers.shape:
            raise ValueError("state_scale must have one value per state")
        if not torch.isfinite(scale).all() or torch.any(scale <= 0.0):
            raise ValueError("state_scale must be positive and finite")
        return torch.diag(scale.square() * self.multipliers())


def central_difference_gradient(
    loss_value: Callable[[], torch.Tensor],
    parameter: torch.Tensor,
    *,
    step: float,
    stop_requested: Callable[[], bool] | None = None,
) -> torch.Tensor:
    """Independently estimate every scalar derivative and restore the parameter."""
    if not math.isfinite(step) or step <= 0.0:
        raise ValueError("step must be positive and finite")
    if not torch.is_floating_point(parameter) or not torch.isfinite(parameter).all():
        raise ValueError("parameter must be a finite floating-point tensor")
    original = parameter.detach().clone()
    numeric = torch.empty_like(original)
    flat_parameter = parameter.reshape(-1)
    flat_original = original.reshape(-1)
    flat_numeric = numeric.reshape(-1)
    try:
        with torch.no_grad():
            for index in range(flat_parameter.numel()):
                if stop_requested is not None and stop_requested():
                    raise RuntimeError("resource stop required during finite differences")
                parameter.copy_(original)
                flat_parameter[index] = flat_original[index] + step
                plus = torch.as_tensor(loss_value()).reshape(())
                parameter.copy_(original)
                flat_parameter[index] = flat_original[index] - step
                minus = torch.as_tensor(loss_value()).reshape(())
                if not torch.isfinite(plus) or not torch.isfinite(minus):
                    raise ValueError("finite-difference loss must remain finite")
                flat_numeric[index] = (plus - minus) / (2.0 * step)
    finally:
        with torch.no_grad():
            parameter.copy_(original)
    return numeric


def synchronize_boundary_covariance_functional(
    covariance: torch.Tensor,
    hits: torch.Tensor,
    *,
    floor: float = 1e-12,
) -> torch.Tensor:
    """Match the audited boundary covariance rule without in-place graph changes."""
    if covariance.ndim != 2 or covariance.shape[0] != covariance.shape[1]:
        raise ValueError("covariance must be square")
    boundary_hits = torch.as_tensor(hits, dtype=torch.bool, device=covariance.device)
    if boundary_hits.shape != (covariance.shape[0],):
        raise ValueError("hits must have one flag per covariance channel")
    keep = (~boundary_hits).to(dtype=covariance.dtype)
    retained = covariance * keep[:, None] * keep[None, :]
    boundary_variance = torch.where(
        boundary_hits,
        torch.diagonal(covariance).clamp(min=floor),
        torch.zeros(covariance.shape[0], dtype=covariance.dtype, device=covariance.device),
    )
    return retained + torch.diag(boundary_variance)


class _SymmetricEigenvalueFloor(torch.autograd.Function):
    """Exact spectral floor with a divided-difference backward for repeated roots."""

    @staticmethod
    def forward(ctx, symmetric: torch.Tensor, threshold: torch.Tensor) -> torch.Tensor:
        eigenvalues, eigenvectors = torch.linalg.eigh(symmetric)
        floored = torch.maximum(eigenvalues, threshold)
        reconstructed = (eigenvectors * floored.unsqueeze(0)) @ eigenvectors.T
        ctx.save_for_backward(eigenvalues, eigenvectors, threshold, floored)
        return 0.5 * (reconstructed + reconstructed.T)

    @staticmethod
    def backward(ctx, output_gradient: torch.Tensor):
        eigenvalues, eigenvectors, threshold, floored = ctx.saved_tensors
        symmetric_gradient = 0.5 * (output_gradient + output_gradient.T)
        eigen_gradient = eigenvectors.T @ symmetric_gradient @ eigenvectors
        denominator = eigenvalues[:, None] - eigenvalues[None, :]
        numerator = floored[:, None] - floored[None, :]
        comparison_scale = torch.maximum(
            eigenvalues.abs().max(), threshold.abs()).clamp(min=1.0)
        repeated = denominator.abs() <= (
            8.0 * torch.finfo(eigenvalues.dtype).eps * comparison_scale)
        active = eigenvalues > threshold
        repeated_factor = (active[:, None] & active[None, :]).to(eigenvalues.dtype)
        safe_denominator = torch.where(repeated, torch.ones_like(denominator), denominator)
        factor = torch.where(repeated, repeated_factor, numerator / safe_denominator)
        input_gradient = eigenvectors @ (factor * eigen_gradient) @ eigenvectors.T
        input_gradient = 0.5 * (input_gradient + input_gradient.T)
        threshold_gradient = torch.sum(torch.diagonal(eigen_gradient)[~active])
        return input_gradient, threshold_gradient.reshape_as(threshold)


def stable_covariance_functional(
    covariance: torch.Tensor,
    *,
    floor: float = 1e-12,
) -> torch.Tensor:
    """Stabilize a covariance without differentiating repeated eigenvectors."""
    if covariance.ndim != 2 or covariance.shape[0] != covariance.shape[1]:
        raise ValueError("covariance must be square")
    if not torch.isfinite(covariance).all():
        raise ValueError("covariance must be finite")
    symmetric = 0.5 * (covariance + covariance.T)
    scale = torch.diagonal(symmetric).abs().max().clamp(min=1.0)
    threshold = floor * scale
    return _SymmetricEigenvalueFloor.apply(symmetric, threshold)


def run_persistent_ukf_torch(
    model,
    forcings,
    observations,
    initial_state,
    initial_covariance,
    process_covariance,
    observation_variance,
    mode: str,
    *,
    alpha: float = 0.3,
    beta: float = 2.0,
    kappa: float = 0.0,
    stop_requested: Callable[[], bool] | None = None,
) -> dict[str, torch.Tensor]:
    """Run the audited filter equations without detaching the daily graph."""
    device = getattr(model, "device", torch.device("cpu"))
    forcing_values = torch.as_tensor(forcings, dtype=torch.float64, device=device)
    observation_values = torch.as_tensor(observations, dtype=torch.float64, device=device)
    dimension = int(model.dim_x)
    if forcing_values.ndim != 2 or forcing_values.shape[1] != 3:
        raise ValueError("forcings must have shape [time, 3]")
    days = int(forcing_values.shape[0])
    if observation_values.shape != (days,):
        raise ValueError("observations must have one value per forcing day")
    if not torch.isfinite(forcing_values).all():
        raise ValueError("forcings must be finite")

    mean = torch.as_tensor(initial_state, dtype=torch.float64, device=device)
    if mean.shape != (dimension,) or not torch.isfinite(mean).all():
        raise ValueError("initial_state must be a finite persistent-state vector")
    mean = _project_vector(model, mean)
    covariance = torch.as_tensor(initial_covariance, dtype=torch.float64, device=device)
    if covariance.shape != (dimension, dimension):
        raise ValueError("initial_covariance must match the state dimension")
    covariance = stable_covariance_functional(
        _validate_external_covariance(covariance, "initial_covariance"))
    allowed = permission_mask(model, mode).to(device=device)

    output: dict[str, list[torch.Tensor]] = {
        "prediction": [],
        "prior_state": [],
        "posterior_state": [],
        "correction": [],
        "gain": [],
        "cross_covariance": [],
        "boundary_hits": [],
        "projection_clips": [],
        "prior_covariance": [],
        "posterior_covariance": [],
    }

    for day in range(days):
        if stop_requested is not None and stop_requested():
            raise RuntimeError("resource stop required at a filter day boundary")
        sigma, mean_weights, covariance_weights = merwe_sigma_points(
            mean, covariance, alpha=alpha, beta=beta, kappa=kappa)
        projected_sigma = model.project_state(sigma)
        propagated_state, propagated_discharge = model.transition(
            projected_sigma, tuple(forcing_values[day]))
        propagated_state = torch.as_tensor(
            propagated_state, dtype=torch.float64, device=device)
        propagated_discharge = torch.as_tensor(
            propagated_discharge, dtype=torch.float64, device=device).reshape(-1)

        raw_prior_mean = torch.sum(mean_weights[:, None] * propagated_state, dim=0)
        projected_prior_mean = _project_vector(model, raw_prior_mean)
        prior_projection_hits = projected_prior_mean != raw_prior_mean
        discharge_mean = torch.sum(mean_weights * propagated_discharge)
        state_deviation = propagated_state - raw_prior_mean
        discharge_deviation = propagated_discharge - discharge_mean
        propagated_covariance = torch.einsum(
            "s,si,sj->ij", covariance_weights, state_deviation, state_deviation)
        process_for_day = _matrix_for_day(
            process_covariance,
            day,
            days,
            dimension,
            mean.device,
            "process_covariance",
        )
        propagated_covariance = stable_covariance_functional(
            propagated_covariance + process_for_day)
        cross_covariance = torch.einsum(
            "s,si,s->i", covariance_weights, state_deviation, discharge_deviation)
        observation_for_day = _variance_for_day(
            observation_variance, day, days, mean.device)
        innovation_variance = torch.sum(
            covariance_weights * discharge_deviation * discharge_deviation)
        innovation_variance = innovation_variance + observation_for_day
        if not torch.isfinite(innovation_variance) or innovation_variance <= 0.0:
            raise ValueError("the propagated observation covariance is not positive")
        if prior_projection_hits.any():
            propagated_covariance = synchronize_boundary_covariance_functional(
                propagated_covariance, prior_projection_hits)
            cross_covariance = torch.where(
                prior_projection_hits, torch.zeros_like(cross_covariance), cross_covariance)

        if torch.isfinite(observation_values[day]):
            gain = cross_covariance / innovation_variance
            gain = torch.where(allowed, gain, torch.zeros_like(gain))
            raw_posterior_mean = projected_prior_mean + gain * (
                observation_values[day] - discharge_mean)
            projected_posterior_mean = _project_vector(model, raw_posterior_mean)
            posterior_projection_hits = projected_posterior_mean != raw_posterior_mean
            posterior_covariance = constrained_covariance_update(
                propagated_covariance,
                cross_covariance[:, None],
                innovation_variance.reshape(1, 1),
                gain[:, None],
            )
            posterior_covariance = stable_covariance_functional(posterior_covariance)
            if posterior_projection_hits.any():
                posterior_covariance = synchronize_boundary_covariance_functional(
                    posterior_covariance, posterior_projection_hits)
            day_correction = projected_posterior_mean - projected_prior_mean
        else:
            gain = torch.zeros(dimension, dtype=torch.float64, device=mean.device)
            projected_posterior_mean = projected_prior_mean
            posterior_covariance = propagated_covariance
            posterior_projection_hits = torch.zeros(
                dimension, dtype=torch.bool, device=mean.device)
            day_correction = torch.zeros_like(projected_prior_mean)

        if torch.any(day_correction[~allowed] != 0.0):
            raise RuntimeError("a disabled state channel received a correction")
        output["prediction"].append(discharge_mean)
        output["prior_state"].append(projected_prior_mean)
        output["posterior_state"].append(projected_posterior_mean)
        output["correction"].append(day_correction)
        output["gain"].append(gain)
        output["cross_covariance"].append(cross_covariance)
        output["prior_covariance"].append(propagated_covariance)
        output["posterior_covariance"].append(posterior_covariance)
        output["projection_clips"].append(
            prior_projection_hits | posterior_projection_hits)
        output["boundary_hits"].append(
            _state_boundary_hits(model, projected_prior_mean)
            | _state_boundary_hits(model, projected_posterior_mean))

        mean = projected_posterior_mean
        covariance = posterior_covariance

    return {name: torch.stack(values) for name, values in output.items()}
