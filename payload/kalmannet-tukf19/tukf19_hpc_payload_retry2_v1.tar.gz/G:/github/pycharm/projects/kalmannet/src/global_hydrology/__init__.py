# Global Hydrology Module
# A differentiable hydrological framework for global-scale data assimilation

from .models import DifferentiableM4, StaticEncoder, M4SystemModel, GlobalHydroSystem
from .data import CaravanDataset, create_caravan_dataloader

__version__ = "0.1.0"
__all__ = [
    "DifferentiableM4",
    "StaticEncoder",
    "M4SystemModel",
    "GlobalHydroSystem",
    "CaravanDataset",
    "create_caravan_dataloader",
]
