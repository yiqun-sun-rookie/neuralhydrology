# Global Hydrology Models
# This package contains differentiable hydrological models for global-scale DA

from .differentiable_m4 import DifferentiableM4
from .static_encoder import StaticEncoder
from .m4_system_model import M4SystemModel
from .dl_ssm import DLSSMSystemModel, DLSSMConfig
from .hydro_system import GlobalHydroSystem

# NOTE: HBV backbone deprecated & archived 2026-06-05 (weak ~0.49; superseded by
# neuralhydrology src/scl_hydro HBV-lite 0.6227). See archive/project02_hbv_deprecated_20260605/.

__all__ = [
    "DifferentiableM4",
    "StaticEncoder",
    "M4SystemModel",
    "DLSSMSystemModel",
    "DLSSMConfig",
    "GlobalHydroSystem",
]
