"""
Multi-observation Caravan dataset for the I14 latent SSM.

Returns per-sample dicts: {forcing, attrs, obs: {Q, SM, SWE}, basin_id}
where observations are Caravan pseudo-obs (ERA5-Land soil moisture layer mean,
snow water equivalent, and USGS streamflow).
"""

from __future__ import annotations

import warnings
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset

from .caravan_dataset import (
    CaravanDataset,
    DEFAULT_STATIC_ATTRIBUTES,
)

# Forcing variables — use the actual Caravan column names (potential_evaporation_sum,
# NOT the FAO-PENMAN-MONTEITH variant which is a different column).
DEFAULT_FORCING_VARS = [
    "total_precipitation_sum",
    "temperature_2m_mean",
    "potential_evaporation_sum",
]

# Pseudo-observation columns (ERA5-Land).
# SM aggregated across 4 layers with layer-depth weights (see _aggregate_sm).
_SM_LAYER_COLS = [f"volumetric_soil_water_layer_{i}_mean" for i in range(1, 5)]
# Standard ERA5-Land layer depths (cm): 0-7, 7-28, 28-100, 100-289
_SM_LAYER_WEIGHTS = np.array([7, 21, 72, 189], dtype=np.float32)
_SM_LAYER_WEIGHTS = _SM_LAYER_WEIGHTS / _SM_LAYER_WEIGHTS.sum()

_SWE_COL = "snow_depth_water_equivalent_mean"
_Q_COL = "streamflow"


def _aggregate_sm(df: pd.DataFrame) -> pd.Series:
    """Depth-weighted mean of the 4 ERA5-Land soil moisture layers.

    If any of the 4 expected columns are missing, raises ValueError so the
    caller can decide whether to fill with NaN or propagate the error.
    """
    cols = [c for c in _SM_LAYER_COLS if c in df.columns]
    if len(cols) != 4:
        missing = set(_SM_LAYER_COLS) - set(df.columns)
        raise ValueError(
            f"Expected 4 SM layer columns; missing from dataset: {missing}"
        )
    arr = df[cols].to_numpy(dtype=np.float32)
    return pd.Series(arr @ _SM_LAYER_WEIGHTS, index=df.index, name="SM")


class MultiObsCaravanDataset(Dataset):
    """
    Wraps ``CaravanDataset`` and exposes ``{forcing, attrs, obs: {Q, SM, SWE}}``
    per sample.

    Reuses ``CaravanDataset`` for basin listing, attribute normalization, and
    NetCDF loading.  The window indexing is re-derived here to allow independent
    control over ``seq_length`` and ``stride``, and to keep NaN values in the
    observation streams (``CaravanDataset.__getitem__`` zero-fills NaN, which
    would make missing observations indistinguishable from observed zeros).

    Args:
        data_dir: Caravan data root directory (contains ``timeseries/`` and
            ``attributes/`` subdirectories).
        basins: List of basin IDs to load.  ``None`` loads all basins.
        seq_length: Window length in days.
        stride: Step between consecutive windows (default = ``seq_length``
            for non-overlapping windows).
        start_date: Inclusive start date, e.g. ``"1990-01-01"``.
        end_date: Inclusive end date.
        forcing_vars: Dynamic forcing columns to include in ``forcing``.
        static_attributes: Static attribute columns to include in ``attrs``.
        cache_timeseries: Whether to cache per-basin time series in memory.
    """

    def __init__(
        self,
        data_dir: str = "data/Caravan",
        basins: Optional[List[str]] = None,
        seq_length: int = 365,
        stride: Optional[int] = None,
        start_date: str = "1990-01-01",
        end_date: str = "2010-12-31",
        forcing_vars: Optional[List[str]] = None,
        static_attributes: Optional[List[str]] = None,
        cache_timeseries: bool = True,
    ):
        super().__init__()

        self.forcing_vars = forcing_vars or DEFAULT_FORCING_VARS
        self.static_attributes = static_attributes or list(DEFAULT_STATIC_ATTRIBUTES)
        self.seq_length = seq_length
        self.stride = stride if stride is not None else seq_length

        # Basin ID normalization: CAMELS-US lists often store bare USGS gauge IDs
        # (e.g. "01484100"); the base loader splits on "_" to derive the subdataset
        # directory, so an ID without a prefix would resolve to a missing folder.
        # Prepend "camels_" when an ID has no underscore.
        if basins is not None:
            basins = [b if "_" in b else f"camels_{b}" for b in basins]

        # Build the list of dynamic columns the base loader must ingest.
        # We request all SM layers + SWE + streamflow alongside the forcing vars
        # so that the base loader's NetCDF caching covers every column we need.
        _dyn_extra = list(_SM_LAYER_COLS) + [_SWE_COL, _Q_COL]
        dyn_vars_needed = list(self.forcing_vars) + _dyn_extra

        # Construct the underlying CaravanDataset.
        # We set normalize_dynamic=False so raw physical values are preserved.
        # normalize_static=True so static_mean / static_std are computed.
        self._base = CaravanDataset(
            data_dir=data_dir,
            basins=basins,
            dynamic_inputs=dyn_vars_needed,
            static_attributes=list(self.static_attributes),
            seq_length=seq_length,
            start_date=start_date,
            end_date=end_date,
            normalize_static=True,
            normalize_dynamic=False,
            cache_timeseries=cache_timeseries,
        )

        # Sync basin list (base may have dropped basins missing static attrs).
        self.basins = self._base.basins

        # Pre-cache per-basin DataFrames with the SM aggregate column added.
        # We reuse the base loader's _load_timeseries (which already filters the
        # date range and optionally caches) to avoid reading NetCDF twice.
        self._basin_ts_cache: Dict[str, pd.DataFrame] = {}
        self._samples: List[tuple] = []

        for basin in self.basins:
            df = self._prepare_basin_df(basin)
            n = len(df)
            if n < seq_length:
                continue
            self._basin_ts_cache[basin] = df
            for start in range(0, n - seq_length + 1, self.stride):
                self._samples.append((basin, start))

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _prepare_basin_df(self, basin: str) -> pd.DataFrame:
        """Load raw time series via the base loader and add SM aggregate column.

        The base loader's ``_load_timeseries`` already:
        - loads from NetCDF / CSV
        - filters to ``[start_date, end_date]``
        - caches the result keyed by ``basin_id``

        We do NOT strip the SM layer columns after aggregating so that
        ``forcing`` extraction can still find any overlap if needed.
        """
        df = self._base._load_timeseries(basin)  # pylint: disable=protected-access

        # Attempt SM aggregation; fall back to NaN column if layers are absent.
        df = df.copy()
        try:
            df["SM"] = _aggregate_sm(df)
        except ValueError as e:
            warnings.warn(
                f"SM layers missing for basin {basin}; SM stream will be all-NaN. Error: {e}",
                RuntimeWarning,
                stacklevel=2,
            )
            df["SM"] = np.nan

        return df

    # ------------------------------------------------------------------
    # Dataset interface
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        return len(self._samples)

    def __getitem__(self, idx: int) -> Dict:
        basin, start = self._samples[idx]
        df = self._basin_ts_cache[basin]
        window = df.iloc[start : start + self.seq_length]

        # --- Forcing [seq_len, n_forcing] ---
        forcing_cols = [c for c in self.forcing_vars if c in window.columns]
        if len(forcing_cols) == len(self.forcing_vars):
            forcing = window[self.forcing_vars].to_numpy(dtype=np.float32)
        else:
            # Fill missing columns with zeros (matching base loader behavior).
            forcing_arrays = []
            for col in self.forcing_vars:
                if col in window.columns:
                    vals = window[col].to_numpy(dtype=np.float32)
                else:
                    vals = np.zeros(self.seq_length, dtype=np.float32)
                forcing_arrays.append(vals)
            forcing = np.stack(forcing_arrays, axis=-1)

        # Temperature K -> °C conversion (mirrors base loader logic).
        for i, col in enumerate(self.forcing_vars):
            if "temperature" in col and np.nanmean(forcing[:, i]) > 100:
                forcing[:, i] -= 273.15

        # --- Observations: preserve NaN (do NOT zero-fill) ---
        _nan_col = np.full(self.seq_length, np.nan, dtype=np.float32)
        obs_Q = (
            window[_Q_COL].to_numpy(dtype=np.float32)
            if _Q_COL in window.columns
            else _nan_col.copy()
        )
        obs_SM = window["SM"].to_numpy(dtype=np.float32)
        obs_SWE = (
            window[_SWE_COL].to_numpy(dtype=np.float32)
            if _SWE_COL in window.columns
            else _nan_col.copy()
        )

        # --- Static attributes (z-score normalized by base loader stats) ---
        # static_mean and static_std are pandas Series; reindex to match the
        # (potentially pruned) self._base.static_attributes column order.
        avail_attrs = self._base.static_attributes  # pruned list after loading
        if basin in self._base.static_data.index:
            raw = self._base.static_data.loc[basin, avail_attrs].to_numpy(dtype=np.float32)
            mean = self._base.static_mean[avail_attrs].to_numpy(dtype=np.float32)
            std = self._base.static_std[avail_attrs].to_numpy(dtype=np.float32)
            attrs = (raw - mean) / (std + 1e-6)
        else:
            attrs = np.zeros(len(avail_attrs), dtype=np.float32)

        return {
            "forcing": torch.from_numpy(np.nan_to_num(forcing, nan=0.0)),
            "attrs": torch.from_numpy(np.nan_to_num(attrs, nan=0.0)),
            "obs": {
                "Q": torch.from_numpy(obs_Q),
                "SM": torch.from_numpy(obs_SM),
                "SWE": torch.from_numpy(obs_SWE),
            },
            "basin_id": basin,
        }
