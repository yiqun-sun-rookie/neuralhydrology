from __future__ import annotations

import copy
import json
from pathlib import Path
import subprocess
import sys
import tarfile

import pytest

from scripts import tukf19_hbv_rolling_origin_formal_common as scientific_common
from scripts import tukf19_hpc_deployment_common as deployment_common
from scripts import build_tukf19_hpc_bundle as bundle_builder
from scripts import smoke_tukf19_hpc_compatibility as smoke
from scripts import run_tukf19_hpc_formal_pipeline as hpc_pipeline


ROOT = Path(__file__).resolve().parents[1]
RETRY1_CONFIG = ROOT / "configs" / "tukf19_hpc_deployment_retry1_v1.json"
RETRY2_CONFIG = ROOT / "configs" / "tukf19_hpc_deployment_retry2_v1.json"


def test_hpc_deployment_preserves_scientific_identity_and_authorization() -> None:
    deployment = deployment_common.load_deployment()
    scientific = scientific_common.load_contract()

    assert deployment["scientific_experiment_id"] == scientific["experiment_id"]
    assert deployment["slurm"]["partition"] == "hcpu48y"
    assert deployment["slurm"]["cpus_per_task"] == 1
    assert deployment["slurm"]["custom_memory_directive_forbidden"] is True
    assert deployment["authorization"]["paid_smoke_job_authorized"] is True
    assert deployment["authorization"]["formal_after_smoke_authorized"] is True
    assert deployment["authorization"]["two_hour_monitoring_authorized"] is True
    assert deployment_common.validate_deployment(deployment)["scientific_contract_verified"]


def test_deployment_rejects_scientific_identity_or_slurm_drift() -> None:
    deployment = deployment_common.load_deployment()
    for section, key, value in (
        ("source_contract", "scientific_config_sha256", "0" * 64),
        ("slurm", "partition", "hcpu48"),
        ("slurm", "cpus_per_task", 2),
        ("hpc", "mailbox_channel", "probe"),
        ("smoke", "truth_seed", 1801),
    ):
        changed = copy.deepcopy(deployment)
        changed[section][key] = value
        with pytest.raises((ValueError, PermissionError)):
            deployment_common.validate_deployment(changed)


def test_retry1_is_unique_and_bound_to_preserved_failure() -> None:
    original = deployment_common.load_deployment()
    retry = deployment_common.load_deployment(RETRY1_CONFIG)

    assert retry["deployment_id"] != original["deployment_id"]
    assert retry["scientific_experiment_id"] == original["scientific_experiment_id"]
    assert retry["repair_basis"]["failed_smoke_job_id"] == 209815
    assert retry["repair_basis"]["failed_smoke_report_sha256"] == (
        "fe662637a6bf85f1cd525471e05ffe2a13dc7bd62cdff515af0c6d89435651c5"
    )
    assert retry["repair_basis"]["formal_submission_absent"] is True
    assert retry["hpc"]["target_root"].endswith("_retry1")
    assert retry["outputs"]["local_bundle_root"].endswith("_retry1_v1")


def test_retry1_rejects_failed_evidence_mutation() -> None:
    retry = deployment_common.load_deployment(RETRY1_CONFIG)
    retry["repair_basis"]["failed_smoke_job_id"] = 209816
    with pytest.raises(ValueError, match="failure evidence"):
        deployment_common.validate_deployment(
            retry, configuration_path=RETRY1_CONFIG
        )


def test_retry2_is_bound_to_runtime_only_failure_and_preserves_science() -> None:
    original = deployment_common.load_deployment()
    retry1 = deployment_common.load_deployment(RETRY1_CONFIG)
    retry2 = deployment_common.load_deployment(RETRY2_CONFIG)

    assert retry2["deployment_id"] != retry1["deployment_id"]
    assert retry2["scientific_experiment_id"] == original["scientific_experiment_id"]
    assert retry2["repair_basis"]["failed_smoke_job_id"] == 209825
    assert retry2["repair_basis"]["failed_smoke_report_sha256"] == (
        "7ab176aa0fa4a569a113575952d4334d79e977b55440692d70c8ea583038ab72"
    )
    assert retry2["repair_basis"]["failed_check"] == "smoke_runtime"
    assert retry2["repair_basis"]["formal_submission_absent"] is True
    assert retry2["hpc"]["target_root"].endswith("_retry2")
    assert retry2["outputs"]["local_bundle_root"].endswith("_retry2_v1")
    assert original["smoke"]["maximum_smoke_elapsed_seconds"] == 30.0
    assert retry1["smoke"]["maximum_smoke_elapsed_seconds"] == 30.0
    assert retry2["smoke"]["maximum_smoke_elapsed_seconds"] == 60.0
    for key in retry1["smoke"]:
        if key != "maximum_smoke_elapsed_seconds":
            assert retry2["smoke"][key] == retry1["smoke"][key]


def test_retry2_rejects_failure_evidence_or_runtime_scope_mutation() -> None:
    retry = deployment_common.load_deployment(RETRY2_CONFIG)
    for section, key, value in (
        ("repair_basis", "failed_smoke_job_id", 209826),
        ("repair_basis", "observed_smoke_elapsed_seconds", 40.0),
        ("smoke", "maximum_smoke_elapsed_seconds", 61.0),
    ):
        changed = copy.deepcopy(retry)
        changed[section][key] = value
        with pytest.raises(ValueError):
            deployment_common.validate_deployment(
                changed, configuration_path=RETRY2_CONFIG
            )


def test_payload_member_map_is_complete_and_preserves_windows_paths() -> None:
    deployment = deployment_common.load_deployment()
    members = bundle_builder.payload_members(deployment)
    external_hash = deployment["source_contract"]["external_numpy_hbv_sha256"]
    direct = (
        "G:/github/pycharm/projects/neuralhydrology/src/"
        "scl_hydro/hbv_lite_numpy.py"
    )
    nested = (
        "G:/github/pycharm/projects/kalmannet/G:/github/pycharm/projects/"
        "neuralhydrology/src/scl_hydro/hbv_lite_numpy.py"
    )

    assert bundle_builder.sha256_file(members[direct]) == external_hash
    assert bundle_builder.sha256_file(members[nested]) == external_hash
    assert "configs/tukf19_hbv_rolling_origin_formal_execution_v1.json" in members
    assert "scripts/run_tukf19_hbv_rolling_origin_formal_execution.py" in members
    assert "scripts/verify_tukf19_hbv_rolling_origin_formal_execution.py" in members
    assert "scripts/plot_tukf19_hbv_rolling_origin_formal_execution.py" in members
    assert not any(name.startswith("results/") for name in members)


def test_retry_payload_contains_package_initializer_import_closure() -> None:
    retry = deployment_common.load_deployment(RETRY1_CONFIG)
    members = bundle_builder.payload_members(retry)
    prefix = "G:/github/pycharm/projects/kalmannet/src/global_hydrology/"
    expected = {
        "models/differentiable_m4.py",
        "models/static_encoder.py",
        "models/m4_system_model.py",
        "models/dl_ssm.py",
        "models/hydro_system.py",
        "models/differentiable_walrus.py",
        "models/walrus_system_model.py",
        "data/__init__.py",
        "data/caravan_dataset.py",
        "data/multi_obs_caravan.py",
    }
    assert {prefix + relative for relative in expected} <= set(members)


def test_retry_bundle_is_deterministic(tmp_path: Path) -> None:
    first = bundle_builder.build_bundle(
        tmp_path / "retry-first", deployment_path=RETRY1_CONFIG
    )
    second = bundle_builder.build_bundle(
        tmp_path / "retry-second", deployment_path=RETRY1_CONFIG
    )
    assert first["archive_sha256"] == second["archive_sha256"]
    assert first["members"] == second["members"]
    assert first["archive_name"] == "tukf19_hpc_payload_retry1_v1.tar.gz"


def test_retry2_bundle_is_deterministic(tmp_path: Path) -> None:
    first = bundle_builder.build_bundle(
        tmp_path / "retry2-first", deployment_path=RETRY2_CONFIG
    )
    second = bundle_builder.build_bundle(
        tmp_path / "retry2-second", deployment_path=RETRY2_CONFIG
    )
    assert first["archive_sha256"] == second["archive_sha256"]
    assert first["members"] == second["members"]
    assert first["archive_name"] == "tukf19_hpc_payload_retry2_v1.tar.gz"


def test_bundle_is_deterministic_and_manifest_bound(tmp_path: Path) -> None:
    first = bundle_builder.build_bundle(tmp_path / "first")
    second = bundle_builder.build_bundle(tmp_path / "second")

    assert first["archive_sha256"] == second["archive_sha256"]
    assert first["archive_bytes"] == second["archive_bytes"]
    assert first["members"] == second["members"]
    with tarfile.open(first["archive_path"], "r:gz") as archive:
        names = tuple(sorted(archive.getnames()))
        payload_manifest = json.load(archive.extractfile("payload_manifest.json"))
    assert names == tuple(sorted((*first["members"], "payload_manifest.json")))
    assert payload_manifest["members"] == first["members"]


def test_bundle_builder_can_run_by_direct_script_path(tmp_path: Path) -> None:
    completed = subprocess.run(
        [
            sys.executable,
            "-B",
            "scripts/build_tukf19_hpc_bundle.py",
            "--output-root",
            str(tmp_path / "direct"),
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    assert completed.returncode == 0, completed.stderr
    report = json.loads(completed.stdout)
    assert report["status"] == "HPC_BUNDLE_COMPLETE"


def test_smoke_reference_tolerance_and_sealed_boundary() -> None:
    deployment = deployment_common.load_deployment()
    reference = deployment["smoke"]["reference"]["hydrology_update_only"]
    assert smoke.within_reference(
        reference["training_loss"] + 1e-11,
        reference["training_loss"],
        deployment,
    )
    assert not smoke.within_reference(
        reference["training_loss"] + 1e-5,
        reference["training_loss"],
        deployment,
    )
    assert deployment["smoke"]["test_origin_queries"] == 0
    assert deployment["smoke"]["clean_target_queries"] == 0


@pytest.mark.parametrize(
    "relative",
    [
        "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_smoke_cpu.slurm",
        "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_formal_cpu.slurm",
        "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_smoke_cpu_retry1.slurm",
        "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_formal_cpu_retry1.slurm",
        "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_smoke_cpu_retry2.slurm",
        "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_formal_cpu_retry2.slurm",
    ],
)
def test_slurm_scripts_follow_cluster_contract(relative: str) -> None:
    source = (ROOT / relative).read_text(encoding="utf-8")
    assert "#SBATCH --partition=hcpu48y" in source
    assert "#SBATCH --nodes=1" in source
    assert "#SBATCH --ntasks=1" in source
    assert "#SBATCH --cpus-per-task=1" in source
    assert "MKL_THREADING_LAYER=GNU" in source
    assert "MKL_SERVICE_FORCE_INTEL=1" in source
    assert "OMP_NUM_THREADS=1" in source
    assert "MKL_NUM_THREADS=1" in source
    assert "OPENBLAS_NUM_THREADS=1" in source
    assert "set -eo pipefail" in source
    assert "--mem" not in source
    assert "srun" not in source
    assert "set -u" not in source
    assert "python -B" in source


def test_formal_pipeline_requires_bound_smoke_pass() -> None:
    deployment = deployment_common.load_deployment()
    good = {
        "status": "HPC_SMOKE_PASS",
        "deployment_id": deployment["deployment_id"],
        "bundle_sha256": "1" * 64,
        "checks": {"all": True},
    }
    assert hpc_pipeline.require_smoke_pass(
        good, deployment=deployment, expected_bundle_sha256="1" * 64
    )

    bad = copy.deepcopy(good)
    bad["checks"]["all"] = False
    with pytest.raises(PermissionError):
        hpc_pipeline.require_smoke_pass(
            bad, deployment=deployment, expected_bundle_sha256="1" * 64
        )
