from __future__ import annotations

import copy
from pathlib import Path
import sys

import numpy as np
import pytest

from scripts import tukf18_hbv_rolling_origin_balance_common as common
from scripts import run_tukf18_hbv_rolling_origin_balance_preflight as runner
from scripts import verify_tukf18_hbv_rolling_origin_balance_preflight as verifier


ROOT = Path(__file__).resolve().parents[1]


def test_only_scientific_factor_is_hydrology_distance() -> None:
    contract = common.load_contract()
    parent = common.load_parent_contract()

    assert contract["experiment_id"] == common.EXPERIMENT_ID
    assert contract["balanced_error_design"]["hydrology_coordinate_distance"] == 0.05
    assert contract["balanced_error_design"]["filter_perturbation_factor"] == 8.0
    assert (
        contract["balanced_error_design"]["process_standard_deviation_fraction"]
        == 0.02
    )

    normalized = copy.deepcopy(contract)
    for key in common.ALLOWED_EFFECTIVE_TOP_LEVEL_CHANGES:
        normalized[key] = copy.deepcopy(parent[key])
    assert normalized == parent


def test_confirmation_seed_range_is_unseen_and_formal_is_forbidden() -> None:
    contract = common.load_contract()
    policy = contract["truth_seed_policy"]

    assert policy["first_candidate"] == 1801
    assert policy["candidate_step"] == 1
    assert policy["accepted_count"] == 27
    assert set(range(1701, 1731)).isdisjoint(range(1801, 1901))
    assert contract["authorization"]["formal_training_authorized_at_config_freeze"] is False
    assert contract["authorization"]["preflight_execution_authorized"] is True


def test_registration_and_parent_evidence_are_frozen() -> None:
    registration = common.read_registration()
    validation = common.validate_registration(registration)

    assert validation["parent_configuration_verified"] is True
    assert validation["parent_balance_hold_verified"] is True
    assert validation["parent_independent_verification_verified"] is True
    assert validation["design_registry_verified"] is True
    assert registration["scientific_change"] == {
        "factor": "hydrology_coordinate_distance",
        "previous_value": 0.04,
        "new_value": 0.05,
        "no_iterative_retuning_after_preflight": True,
    }


@pytest.mark.parametrize(
    "section,key,value",
    [
        ("scientific_change", "new_value", 0.051),
        ("confirmation_seed_policy", "first_candidate", 1701),
        ("balance_gate", "required_ratio_count", 7),
        ("authorization", "formal_training_authorized", True),
    ],
)
def test_registration_rejects_contract_drift(
    section: str, key: str, value: object
) -> None:
    registration = common.read_registration()
    registration[section][key] = value
    with pytest.raises((ValueError, PermissionError)):
        common.validate_registration(registration)


def test_start_values_apply_distance_point_zero_five_and_keep_filter_factor_eight() -> None:
    contract = common.load_contract()
    truth = common.build_start_values(
        contract, "start_03", hydrology_source="truth", filter_source="truth"
    )
    initial = common.build_start_values(
        contract, "start_03", hydrology_source="initial", filter_source="initial"
    )

    coordinate_distance = np.abs(
        np.asarray(initial["hydrology_coordinates"])
        - np.asarray(truth["hydrology_coordinates"])
    )
    assert np.allclose(coordinate_distance, 0.05, rtol=0.0, atol=1e-15)

    process_ratio = np.asarray(initial["process_variances"]) / np.asarray(
        truth["process_variances"]
    )
    assert set(np.round(process_ratio, 12)) <= {0.125, 8.0}
    observation_ratio = initial["observation_ratio"] / truth["observation_ratio"]
    assert observation_ratio in {0.125, 8.0}


def test_outputs_are_isolated_and_formal_root_is_not_created_by_loading() -> None:
    contract = common.load_contract()
    outputs = contract["outputs"]

    assert all("tukf18_hbv_rolling_origin_balance_adjustment_v1" in value for value in outputs.values())
    assert all("tukf17_hbv_rolling_origin_state_hydrology_update_v1" not in value for value in outputs.values())
    assert not common.resolve_output_path(contract, outputs["result_root"]).exists()


def test_source_closure_is_complete_and_contains_no_formal_runner() -> None:
    paths = common.source_paths(common.DEFAULT_CONFIG)
    relative = {path.relative_to(ROOT).as_posix() for path in paths}

    assert "scripts/run_tukf18_hbv_rolling_origin_balance_preflight.py" in relative
    assert "scripts/verify_tukf18_hbv_rolling_origin_balance_preflight.py" in relative
    assert not any("formal" in path for path in relative)


@pytest.mark.parametrize("module", [runner, verifier])
def test_preflight_commands_expose_no_formal_stage(
    monkeypatch: pytest.MonkeyPatch, module: object
) -> None:
    monkeypatch.setattr(sys, "argv", ["program", "--stage", "formal"])
    with pytest.raises(SystemExit) as error:
        module._parse_args()
    assert error.value.code == 2


def test_engineering_preflight_refuses_to_replace_an_existing_root(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    contract = common.load_contract()
    existing = tmp_path / "preflight"
    existing.mkdir()
    result = tmp_path / "result"

    def fake_output_path(_contract: object, raw: str) -> Path:
        return existing if raw.endswith("/preflight") else result

    monkeypatch.setattr(common, "resolve_output_path", fake_output_path)
    with pytest.raises(FileExistsError, match="refusing to replace"):
        runner.run_preflight(contract, contract_path=common.DEFAULT_CONFIG)


def test_independent_comparators_reject_shape_or_value_drift() -> None:
    baseline = np.asarray([1.0, 2.0], dtype=np.float64)
    assert verifier._arrays_close(baseline, baseline.copy())
    assert not verifier._arrays_close(baseline, np.asarray([[1.0, 2.0]]))
    assert not verifier._arrays_close(baseline, np.asarray([1.0, 2.1]))
