from __future__ import annotations

import copy
from pathlib import Path

import pytest

from scripts import tukf19_hbv_rolling_origin_formal_common as common
from scripts import run_tukf19_hbv_rolling_origin_formal_execution as runner
from scripts import verify_tukf19_hbv_rolling_origin_formal_execution as verifier
from scripts import plot_tukf19_hbv_rolling_origin_formal_execution as plotter


ROOT = Path(__file__).resolve().parents[1]


def test_formal_authorization_and_scientific_contract_are_frozen() -> None:
    contract = common.load_contract()
    parent = common.load_parent_contract()

    assert contract["experiment_id"] == common.EXPERIMENT_ID
    assert contract["authorization"]["formal_training_authorized"] is True
    assert contract["authorization"]["authorization_text"] == "全部授权"
    assert contract["parallel_execution"]["unrelated_formal_processes_allowed"] is True
    assert contract["balanced_error_design"]["hydrology_coordinate_distance"] == 0.05
    assert contract["balanced_error_design"]["filter_perturbation_factor"] == 8.0
    assert (
        contract["balanced_error_design"]["process_standard_deviation_fraction"]
        == 0.02
    )

    normalized = copy.deepcopy(contract)
    for key in common.REPLACED_PARENT_KEYS:
        normalized[key] = copy.deepcopy(parent[key])
    for key in common.ADDED_EFFECTIVE_KEYS:
        normalized.pop(key)
    assert normalized == parent


def test_parent_preflight_and_engine_files_are_hash_locked() -> None:
    registration = common.read_registration()
    validation = common.validate_registration(registration)

    assert validation == {
        "parent_balance_pass_verified": True,
        "parent_independent_verification_verified": True,
        "parent_zero_formal_work_verified": True,
        "parent_resource_conflict_audit_verified": True,
        "runtime_engine_verified": True,
    }


@pytest.mark.parametrize(
    "section,key,value",
    [
        ("authorization", "formal_training_authorized", False),
        ("authorization", "authorization_text", "go"),
        ("parallel_execution", "unrelated_formal_processes_allowed", False),
        ("resources", "minimum_available_memory_gib", 7.0),
        ("scientific_contract", "hydrology_coordinate_distance", 0.051),
        ("expected_budget", "real_optimizer_updates", 5183),
    ],
)
def test_registration_rejects_authorization_resource_science_or_budget_drift(
    section: str, key: str, value: object
) -> None:
    registration = common.read_registration()
    registration[section][key] = value
    with pytest.raises((ValueError, PermissionError)):
        common.validate_registration(registration)


def test_outputs_are_unique_and_parent_preflight_is_read_only() -> None:
    contract = common.load_contract()
    outputs = contract["outputs"]

    assert outputs["preflight_root"].startswith(
        "artifacts/tukf18_hbv_rolling_origin_balance_adjustment_v1/"
    )
    assert outputs["result_root"] == (
        "results/tukf19_hbv_rolling_origin_formal_execution_v1"
    )
    assert outputs["failed_result_root"] == (
        "results/tukf19_hbv_rolling_origin_formal_execution_v1_failed_attempts"
    )
    assert outputs["figure_root"] == (
        "artifacts/tukf19_hbv_rolling_origin_formal_execution_v1/"
        "formal_verified_summary_v1"
    )
    assert not common.resolve_output_path(contract, outputs["result_root"]).exists()
    assert not common.resolve_output_path(contract, outputs["figure_root"]).exists()


def test_source_closure_contains_adapters_tests_and_reused_engines() -> None:
    relative = {
        path.relative_to(ROOT).as_posix()
        for path in common.source_paths(common.DEFAULT_CONFIG)
    }
    assert {
        "scripts/tukf19_hbv_rolling_origin_formal_common.py",
        "scripts/run_tukf19_hbv_rolling_origin_formal_execution.py",
        "scripts/verify_tukf19_hbv_rolling_origin_formal_execution.py",
        "scripts/plot_tukf19_hbv_rolling_origin_formal_execution.py",
        "tests/test_tukf19_hbv_rolling_origin_formal_execution.py",
        "scripts/tukf18_hbv_rolling_origin_balance_common.py",
        "scripts/run_tukf17_hbv_rolling_origin_state_hydrology_update.py",
        "scripts/verify_tukf17_hbv_rolling_origin_state_hydrology_update.py",
        "scripts/plot_tukf17_hbv_rolling_origin_state_hydrology_update.py",
    } <= relative


@pytest.mark.parametrize(
    "formal,parallel",
    [(False, False), (True, False), (False, True)],
)
def test_formal_runner_requires_both_runtime_confirmations(
    formal: bool, parallel: bool
) -> None:
    contract = common.load_contract()
    with pytest.raises(PermissionError, match="both formal and parallel"):
        runner.run_authorized_formal(
            contract,
            contract_path=common.DEFAULT_CONFIG,
            confirm_formal_training=formal,
            confirm_parallel_execution=parallel,
        )


def test_resource_admission_records_but_allows_unrelated_formal_processes(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    contract = common.load_contract()
    processes = [
        {
            "process_id": 101,
            "command": "python run_tukf09_filter_training.py --execute-formal-training",
            "same_experiment": False,
        }
    ]
    monkeypatch.setattr(runner, "available_memory_gib", lambda: 9.0)
    monkeypatch.setattr(runner, "workspace_free_storage_gib", lambda: 100.0)
    monkeypatch.setattr(runner, "active_formal_processes", lambda: processes)

    report = runner.resource_admission(contract)

    assert report["status"] == "RESOURCE_ADMITTED_WITH_PARALLEL_WAIVER"
    assert report["checks"] == {
        "available_memory": True,
        "workspace_free_storage": True,
        "no_other_same_experiment_controller": True,
        "unrelated_formal_processes_authorized": True,
    }
    assert report["unrelated_formal_process_ids"] == [101]
    assert report["same_experiment_other_controller_ids"] == []


def test_resource_admission_rejects_duplicate_same_experiment_controller(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    contract = common.load_contract()
    processes = [
        {
            "process_id": 202,
            "command": (
                "python run_tukf19_hbv_rolling_origin_formal_execution.py "
                "--confirm-formal-training --confirm-parallel-execution"
            ),
            "same_experiment": True,
        }
    ]
    monkeypatch.setattr(runner, "available_memory_gib", lambda: 9.0)
    monkeypatch.setattr(runner, "workspace_free_storage_gib", lambda: 100.0)
    monkeypatch.setattr(runner, "active_formal_processes", lambda: processes)

    report = runner.resource_admission(contract)

    assert report["status"] == "RESOURCE_HOLD"
    assert report["checks"]["no_other_same_experiment_controller"] is False


def test_parent_preflight_chain_is_accepted_without_relabeling_parent_hold() -> None:
    contract = common.load_contract()
    preflight, verification = runner.require_verified_parent_preflight(
        contract, common.DEFAULT_CONFIG
    )

    assert preflight["status"] == "PREFLIGHT_ENGINEERING_PASS"
    assert preflight["balance_status"] == "BALANCE_PASS"
    assert verification["status"] == "PREFLIGHT_VERIFIED"
    assert all(verification["checks"].values())


def test_runner_and_independent_verifier_use_identical_source_closure() -> None:
    contract = common.load_contract()
    assert runner.formal_source_hashes(contract, common.DEFAULT_CONFIG) == (
        verifier.independent_source_hashes(contract, common.DEFAULT_CONFIG)
    )


def test_independent_verifier_does_not_import_tukf19_runner() -> None:
    source = (
        ROOT / "scripts" / "verify_tukf19_hbv_rolling_origin_formal_execution.py"
    ).read_text(encoding="utf-8")
    assert "run_tukf19_hbv_rolling_origin_formal_execution" not in source


def test_plotter_requires_formal_verification_before_delegating(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    contract = common.load_contract()
    result_root = tmp_path / "result"
    result_root.mkdir()
    common.write_new_json(
        result_root / "independent_verification.json",
        {"status": "FORMAL_VERIFICATION_FAILED", "checks": {"x": False}},
    )
    original = common.resolve_output_path

    def fake_output_path(candidate: object, raw: str) -> Path:
        if raw == contract["outputs"]["result_root"]:
            return result_root
        return original(candidate, raw)

    monkeypatch.setattr(common, "resolve_output_path", fake_output_path)
    with pytest.raises(PermissionError, match="FORMAL_VERIFIED"):
        plotter.create_verified_figures(contract)
