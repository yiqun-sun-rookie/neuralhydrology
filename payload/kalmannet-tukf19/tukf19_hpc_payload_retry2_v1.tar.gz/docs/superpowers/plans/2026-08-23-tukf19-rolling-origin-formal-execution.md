# TUKF19 Rolling-Origin Formal Execution Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Register, implement, run, independently verify, and summarize the formally authorized rolling-origin comparison using the already balanced `0.05` hydrologic-coordinate start distance.

**Architecture:** Preserve TUKF17 and TUKF18 byte-for-byte and create a new TUKF19 identity. Pin the TUKF18 balance arrays, verification, seed registry, and postflight resource-conflict audit as read-only inputs; record the user's explicit authorization to run concurrently with unrelated formal work. Reuse the tested TUKF17 formal numerical engine through a TUKF19 adapter whose common module supplies the TUKF18 balanced starts, TUKF19 contract validation, unique output roots, and complete source hashes.

**Tech Stack:** Python 3, NumPy, PyTorch, pytest, JSON, SHA-256, PowerShell

## Global Constraints

- Write only inside `G:/github/pycharm/projects/kalmannet-tukf17-implementation-20260823`.
- Keep `G:/github/pycharm/projects/kalmannet`, TUKF17, TUKF18, and all predecessor evidence read-only.
- Freeze `hydrology_coordinate_distance=0.05`, `filter_perturbation_factor=8.0`, `process_standard_deviation_fraction=0.02`, 27 accepted TUKF18 seed/start pairs, all origin windows, all metrics, and the `96`-update budget.
- Record the user's `2026-08-23` message `全部授权` as explicit formal-training authorization and as acceptance of concurrent unrelated formal processes.
- Require at least `8.0` GiB available memory and `2.0` GiB free workspace storage at launch; allow unrelated formal processes but forbid another active TUKF19 controller.
- Keep test-period observations and clean targets sealed until all `108` method cells and their selections are complete.
- Never overwrite a result, admission, failed-attempt, verification, or figure root.
- Run in the foreground; do not commit, push, publish, clean, delete, or alter existing evidence.

---

### Task 1: Freeze the formal registration and tests

**Files:**
- Create: `configs/tukf19_hbv_rolling_origin_formal_execution_v1.json`
- Create: `tests/test_tukf19_hbv_rolling_origin_formal_execution.py`

**Interfaces:**
- Consumes: exact TUKF18 configuration and preflight artifact hashes.
- Produces: one formal experiment identifier, one result root, one failed-attempt root, one figure root, and one explicit parallel-execution authorization record.

- [ ] **Step 1: Write failing contract tests**

```python
def test_formal_authorization_and_scientific_contract_are_frozen():
    contract = common.load_contract()
    assert contract["authorization"]["formal_training_authorized"] is True
    assert contract["parallel_execution"]["unrelated_formal_processes_allowed"] is True
    assert contract["balanced_error_design"]["hydrology_coordinate_distance"] == 0.05
```

- [ ] **Step 2: Confirm the missing-module failure**

Run: `python -B -m pytest tests/test_tukf19_hbv_rolling_origin_formal_execution.py -q`

Expected: collection fails because the TUKF19 common module does not exist.

- [ ] **Step 3: Create the registration with exact hashes and unique paths**

The registration must pin all six TUKF18 preflight files, both reused TUKF17 engine files, the TUKF18 common module, the fixed budget, and the authorization text. Formal output must be `results/tukf19_hbv_rolling_origin_formal_execution_v1`.

### Task 2: Build the TUKF19 effective contract

**Files:**
- Create: `scripts/tukf19_hbv_rolling_origin_formal_common.py`
- Modify: `tests/test_tukf19_hbv_rolling_origin_formal_execution.py`

**Interfaces:**
- Consumes: `tukf18_hbv_rolling_origin_balance_common.load_contract()` and frozen TUKF18 evidence.
- Produces: `load_contract`, `validate_contract`, `source_hashes`, `formal_pairs`, and delegation of tested numerical primitives.

- [ ] **Step 1: Verify every parent hash and status**

```python
assert balance["status"] == "BALANCE_PASS"
assert verification["status"] == "PREFLIGHT_VERIFIED"
assert conflict["status"] == "RESOURCE_HOLD_POSTFLIGHT"
assert registration["parallel_execution"]["user_accepted_resource_isolation_waiver"] is True
```

- [ ] **Step 2: Construct the effective contract with no scientific drift**

Change only experiment identity, authorization, resource policy, claim boundary, and TUKF19 output roots. Preserve TUKF18 balanced starts, seed policy, objective, optimizer, selection, gates, and budget exactly.

- [ ] **Step 3: Test parent mutation, authorization removal, scientific drift, duplicate output, and seed mismatch failures**

Run: `python -B -m pytest tests/test_tukf19_hbv_rolling_origin_formal_execution.py -q`

Expected: all focused contract tests pass.

### Task 3: Adapt and guard the formal runner

**Files:**
- Create: `scripts/run_tukf19_hbv_rolling_origin_formal_execution.py`
- Modify: `tests/test_tukf19_hbv_rolling_origin_formal_execution.py`

**Interfaces:**
- Consumes: tested TUKF17 formal functions with the TUKF19 common module injected.
- Produces: complete per-method histories, selected checkpoints, a global selection seal, 162 test readouts, a registry, and a manifest.

- [ ] **Step 1: Require two runtime confirmations**

```python
if not confirm_formal_training or not confirm_parallel_execution:
    raise PermissionError("both formal and parallel execution confirmations are required")
```

- [ ] **Step 2: Admit resources without ignoring duplicate TUKF19 controllers**

The resource report must record all unrelated formal processes, pass them only because the user waiver is frozen, reject any other TUKF19 controller, and reject memory below `8.0` GiB or storage below `2.0` GiB.

- [ ] **Step 3: Verify the TUKF18 preflight chain before touching the result root**

Require exact config, source, seed-registry, balance-array, balance-gate, independent-verification, and conflict-audit hashes. Require zero test queries and zero formal optimizer updates in the parent preflight.

- [ ] **Step 4: Delegate formal execution and archive only a newly owned failed attempt**

Run contract:

`python -B scripts/run_tukf19_hbv_rolling_origin_formal_execution.py --confirm-formal-training --confirm-parallel-execution`

### Task 4: Adapt independent formal verification and plotting

**Files:**
- Create: `scripts/verify_tukf19_hbv_rolling_origin_formal_execution.py`
- Create: `scripts/plot_tukf19_hbv_rolling_origin_formal_execution.py`
- Modify: `tests/test_tukf19_hbv_rolling_origin_formal_execution.py`

**Interfaces:**
- Consumes: sealed TUKF19 selection checkpoints, raw truth/readout arrays, registry, and manifest.
- Produces: independent recomputation status and a verified summary figure rooted only in TUKF19 outputs.

- [ ] **Step 1: Patch the independent TUKF17 verifier with TUKF19 contract and source hashing**

The verifier must not import the TUKF19 engineering runner. It must recompute all `108` selections, `162` readouts, `81` state-update counterfactuals, aggregates, and manifest hashes.

- [ ] **Step 2: Refuse plotting unless independent formal verification passes**

The plot adapter must require `FORMAL_VERIFIED`, pin its input hashes, and create the figure root exclusively.

- [ ] **Step 3: Run focused tests**

Run: `python -B -m pytest tests/test_tukf19_hbv_rolling_origin_formal_execution.py -q`

Expected: all guard, adapter, source-closure, and failure-path tests pass.

### Task 5: Run the full launch gate

**Files:**
- Read only: all TUKF17, TUKF18, and TUKF19 source and evidence files.

**Interfaces:**
- Consumes: frozen implementation.
- Produces: proof that the formal command is the first TUKF19 controller and that source hashes are stable.

- [ ] **Step 1: Run combined regression tests**

Run: `python -B -m pytest tests/test_tukf17_hbv_rolling_origin_state_hydrology_update.py tests/test_tukf17_hbv_rolling_origin_mechanics.py tests/test_tukf17_hbv_rolling_origin_runner.py tests/test_verify_tukf17_hbv_rolling_origin_state_hydrology_update.py tests/test_tukf18_hbv_rolling_origin_balance_adjustment.py tests/test_tukf19_hbv_rolling_origin_formal_execution.py -q`

Expected: all tests pass with no TUKF17 or TUKF18 hash change.

- [ ] **Step 2: Confirm launch resources and exclusive TUKF19 roots**

Expected: available memory at least `8.0` GiB, storage at least `2.0` GiB, zero active TUKF19 controllers, and absent TUKF19 result/failed/figure roots.

### Task 6: Run, verify, and summarize

**Files:**
- Create through tested commands only: `results/tukf19_hbv_rolling_origin_formal_execution_v1/**`
- Create through tested commands only: `artifacts/tukf19_hbv_rolling_origin_formal_execution_v1/formal_verified_summary_v1/**`

**Interfaces:**
- Consumes: frozen TUKF19 contract and source closure.
- Produces: one complete formal registry, one independent verification, and one verified figure package.

- [ ] **Step 1: Start formal training in the foreground**

Run the Task 3 command once. Monitor completed `history.json` files and available memory without launching a second controller.

- [ ] **Step 2: Independently verify the completed formal result**

Run: `python -B scripts/verify_tukf19_hbv_rolling_origin_formal_execution.py`

Expected: `FORMAL_VERIFIED` and every check true.

- [ ] **Step 3: Generate the verified summary**

Run: `python -B scripts/plot_tukf19_hbv_rolling_origin_formal_execution.py`

Expected: an exclusive figure root whose manifest binds the verified registry and independent verification.

- [ ] **Step 4: Report facts, inference, and unknowns separately**

Report exact median ratios, direction counts, confidence intervals, state-error results, interaction diagnostics, runtime, resource history, and artifact paths. Do not equate technical completion with scientific success.
