# TUKF19 HPC Cold-Start Runtime Retry 2 Implementation Plan

**Goal:** Repair the second high-performance-computing smoke failure by revising only the deployment smoke wall-time allowance from 30 to 60 seconds, while preserving every scientific input, numerical reference, success criterion, and prior failure artifact.

**Architecture:** Register a new deployment identity and a new target ending in `retry2`. Reuse the frozen scientific experiment and the verified 71-member import-closed payload, bind the retry to job `209825` and its smoke report, and require a fresh paid smoke pass before submitting the formal job.

**Tech Stack:** Python 3.11, deterministic gzip/tar, SHA-256, pytest, Bash, Slurm

## Evidence and boundary

- Preserve job `209825`, deployment target `/data1/home/sunyiq/kalmannet_tukf19_20260823_retry1`, bundle SHA-256 `d4e37bbd3f9191f26adb8b2a2a060358aeba5a822b0697fbb292e90308f2b407`, and smoke report SHA-256 `7ab176aa0fa4a569a113575952d4334d79e977b55440692d70c8ea583038ab72` without modification.
- The retry-1 report has 14 passing checks and one failing check: total smoke wall time was `40.415059223771095` seconds against a `30.0` second deployment limit.
- Numerical repetition was deterministic, all registered numerical references passed, no test-period origin or clean target was queried, and the first numerical pass took `2.047028988599777` seconds.
- The measured formal-runtime projection was `5117.572471499443` seconds, below the unchanged `64800.0` second formal projection limit.
- The revised `60.0` second smoke wall-time allowance covers the observed cold-start overhead while remaining thirty times smaller than the unchanged 30-minute Slurm smoke limit.
- Keep the scientific experiment identifier, configuration hash, source closure, parameters, seeds, windows, budgets, numerical tolerances, formal success criteria, and stopping conditions unchanged.
- Keep `hcpu48y`, one node, one task, one CPU, no custom memory directive, direct Python execution, and the existing thread environment unchanged.
- Never overwrite a package, deployment target, smoke report, submission record, formal result, prior failure, or retrieved artifact.

## Task 1: Register the runtime evidence and retry identity

- Create `configs/tukf19_hpc_deployment_retry2_v1.json`.
- Extend `scripts/tukf19_hpc_deployment_common.py` to validate the exact retry-2 evidence, target, output roots, and the single revised technical wall-time value.
- Add tests that reject changes to the failed job, report hash, prior bundle hash, observed timing, formal-submission absence, or scientific identity.

## Task 2: Add retry-specific scheduler entrypoints

- Create `submit_smoke_cpu_retry2.slurm` and `submit_formal_cpu_retry2.slurm` under `hpc/tukf19_hbv_rolling_origin_formal_execution`.
- Point both scripts only to `/data1/home/sunyiq/kalmannet_tukf19_20260823_retry2` and the retry-2 deployment configuration.
- Preserve all existing scheduler and thread settings.

## Task 3: Build and verify a new immutable payload

- Extend the deterministic payload builder to include the retry-2 plan, configuration, and scheduler scripts.
- Run focused migration tests and the complete scientific regression selection; require zero failures.
- Build a new archive and external manifest under `artifacts/tukf19_hpc_deployment_retry2_v1` and record their byte counts and SHA-256 values.

## Task 4: Deploy and execute the gated sequence

- Deploy atomically into the absent retry-2 target without touching retry-1 or the first target.
- Submit exactly one retry-2 smoke job and retain its submission record.
- Submit the formal paid job exactly once only if the retry-2 report is `HPC_SMOKE_PASS`, every check is true, and the report is bound to the retry-2 bundle hash.
- If the smoke or formal job fails, preserve the evidence and continue only with a new evidence-bound, non-overwriting repair.
