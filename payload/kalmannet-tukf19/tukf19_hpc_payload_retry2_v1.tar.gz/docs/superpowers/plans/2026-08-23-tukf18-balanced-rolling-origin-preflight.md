# TUKF18 Balanced Rolling-Origin Preflight Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a separately registered, preflight-only experiment that changes the normalized hydrologic-coordinate starting distance from `0.04` to `0.05`, confirms balance on unseen mechanically accepted truth seeds, and cannot start formal training.

**Architecture:** Keep the completed TUKF17 experiment and artifacts byte-for-byte unchanged. Add a compact TUKF18 registration that pins the failed TUKF17 evidence and the older candidate registry, then construct an effective runtime contract from the frozen TUKF17 configuration while allowing only the registered hydrologic-distance, confirmation-seed, identity, authorization, and output-root changes. Reuse the already tested rolling-origin numerical primitives, but implement a TUKF18-specific start-value builder, preflight runner, and independent recomputation path.

**Tech Stack:** Python 3, NumPy, PyTorch, pytest, JSON, SHA-256, PowerShell

## Global Constraints

- Write only inside `G:/github/pycharm/projects/kalmannet-tukf17-implementation-20260823`.
- Treat `G:/github/pycharm/projects/kalmannet` and every TUKF15, TUKF16, and TUKF17 file and artifact as read-only evidence.
- The only scientific design change is `hydrology_coordinate_distance: 0.04 -> 0.05`; keep `process_standard_deviation_fraction: 0.02` and `filter_perturbation_factor: 8.0` unchanged.
- Use mechanically accepted confirmation truth seeds beginning at `1801`, with no scientific metric queries during seed acceptance and no overlap with TUKF17 attempted seeds `1701` through `1730`.
- Require all eight train/selection by-lead and equal-weight filter-over-hydrology influence ratios to remain in `[1/3, 3]`; any failure produces `BALANCE_HOLD` and ends this experiment.
- Do not access test-period targets, run an optimizer update, start formal training, plot formal results, launch a background process, commit, push, publish, clean, overwrite, or delete existing evidence.
- Refuse to overwrite an existing TUKF18 preflight root.

---

### Task 1: Freeze the new experiment registration and contract tests

**Files:**
- Create: `configs/tukf18_hbv_rolling_origin_balance_adjustment_v1.json`
- Create: `tests/test_tukf18_hbv_rolling_origin_balance_adjustment.py`

**Interfaces:**
- Consumes: frozen TUKF17 configuration and preflight artifact hashes; frozen TUKF15 candidate registry hash.
- Produces: one stable experiment identifier, one immutable registration, one output root, and executable contract assertions.

- [ ] **Step 1: Write registration tests before the implementation**

```python
def test_only_scientific_factor_is_hydrology_distance():
    contract = common.load_contract()
    assert contract["balanced_error_design"]["hydrology_coordinate_distance"] == 0.05
    assert contract["balanced_error_design"]["filter_perturbation_factor"] == 8.0
    assert contract["balanced_error_design"]["process_standard_deviation_fraction"] == 0.02

def test_confirmation_seed_range_is_unseen_and_formal_is_forbidden():
    contract = common.load_contract()
    assert contract["truth_seed_policy"]["first_candidate"] == 1801
    assert contract["authorization"]["formal_training_authorized_at_config_freeze"] is False
```

- [ ] **Step 2: Run the focused test and confirm the missing-module failure**

Run: `python -B -m pytest tests/test_tukf18_hbv_rolling_origin_balance_adjustment.py -q`

Expected: collection fails because `scripts.tukf18_hbv_rolling_origin_balance_common` does not yet exist.

- [ ] **Step 3: Create the registration with exact parent hashes and stop rules**

The registration must contain:

```json
{
  "experiment_id": "TUKF18_HBV_ROLLING_ORIGIN_BALANCE_ADJUSTMENT_V1",
  "scientific_change": {
    "factor": "hydrology_coordinate_distance",
    "previous_value": 0.04,
    "new_value": 0.05,
    "no_iterative_retuning_after_preflight": true
  },
  "confirmation_seed_policy": {
    "first_candidate": 1801,
    "candidate_step": 1,
    "accepted_count": 27
  },
  "balance_gate": {
    "influence_ratio_interval": [0.3333333333333333, 3.0],
    "required_ratio_count": 8,
    "any_failure_stops": true
  }
}
```

Expected: all paths are unique to TUKF18 and formal authorization is false.

### Task 2: Build the isolated effective contract and start values

**Files:**
- Create: `scripts/tukf18_hbv_rolling_origin_balance_common.py`
- Modify: `tests/test_tukf18_hbv_rolling_origin_balance_adjustment.py`

**Interfaces:**
- Consumes: `load_contract(path: Path | str) -> dict[str, Any]` and the frozen TUKF17 numerical primitives.
- Produces: `validate_contract`, `freeze_seed_registry`, `build_start_values`, `build_model`, and aliases for deterministic truth generation, rolling-origin scoring, and balance classification.

- [ ] **Step 1: Validate the frozen parent chain before constructing the effective contract**

Implementation requirements:

```python
if sha256_file(parent_config_path) != registration["parent_evidence"]["configuration_sha256"]:
    raise ValueError("TUKF17 parent configuration changed")
if read_json(parent_balance_path)["status"] != "BALANCE_HOLD":
    raise ValueError("TUKF17 parent balance status changed")
base.validate_contract(parent_contract)
```

- [ ] **Step 2: Allow only registered identity, authorization, output, seed-confirmation, and distance changes**

Implementation requirements:

```python
design = copy.deepcopy(parent_contract["balanced_error_design"])
design["hydrology_coordinate_distance"] = 0.05
effective["balanced_error_design"] = design
effective["truth_seed_policy"]["first_candidate"] = 1801
```

The loader must reject any drift in the process standard-deviation fraction, filter perturbation factor, influence interval, origin windows, forecast leads, optimizer budget, numerical precision, or read-only predecessor hashes.

- [ ] **Step 3: Apply contract values rather than TUKF17 constants when building starts**

```python
distance = float(contract["balanced_error_design"]["hydrology_coordinate_distance"])
factor = float(contract["balanced_error_design"]["filter_perturbation_factor"])
coordinate = truth_coordinate + distance * np.asarray(entry["hydrology_signs"])
```

- [ ] **Step 4: Run focused tests**

Run: `python -B -m pytest tests/test_tukf18_hbv_rolling_origin_balance_adjustment.py -q`

Expected: all contract, evidence-chain, unseen-seed, and start-distance tests pass.

### Task 3: Add the engineering preflight runner

**Files:**
- Create: `scripts/run_tukf18_hbv_rolling_origin_balance_preflight.py`
- Modify: `tests/test_tukf18_hbv_rolling_origin_balance_adjustment.py`

**Interfaces:**
- Consumes: the effective contract and 27 accepted `(truth_seed, start_id)` pairs.
- Produces: `seed_registry.json`, `balance_errors.npz`, `balance_gate.json`, and `preflight.json` under the unique TUKF18 preflight root.

- [ ] **Step 1: Test overwrite refusal and zero-query fields**

```python
assert report["test_metric_queries"] == 0
assert report["formal_optimizer_updates"] == 0
assert report["formal_training_authorized"] is False
```

- [ ] **Step 2: Compute the four raw error arrays only on training and selection origins**

For each pair, compute `E00`, `E01`, `E10`, and diagnostic `E11` with shape `[27, 2, 3]`. Do not call the test-origin window.

- [ ] **Step 3: Write every artifact with exclusive creation and record hashes**

Run contract: `python -B scripts/run_tukf18_hbv_rolling_origin_balance_preflight.py`

Expected status mapping: `PREFLIGHT_ENGINEERING_PASS` only when all eight ratios pass; otherwise `BALANCE_HOLD`.

### Task 4: Add independent recomputation

**Files:**
- Create: `scripts/verify_tukf18_hbv_rolling_origin_balance_preflight.py`
- Modify: `tests/test_tukf18_hbv_rolling_origin_balance_adjustment.py`

**Interfaces:**
- Consumes: stored TUKF18 registration, source hashes, seed attempts, and raw arrays.
- Produces: `independent_verification.json` with per-check booleans and either `PREFLIGHT_VERIFIED`, `BALANCE_HOLD_VERIFIED`, or `PREFLIGHT_VERIFICATION_FAILED`.

- [ ] **Step 1: Recompute every mechanical seed decision**

Verify all attempted candidates, accepted order, 27 unique truth seeds, start mapping, and zero scientific queries.

- [ ] **Step 2: Independently rebuild all four arrays and the eight-ratio classification**

Do not import the engineering runner. Compare floating arrays with `rtol=1e-10` and `atol=1e-11`, and compare artifact hashes exactly.

- [ ] **Step 3: Run the focused tests again**

Run: `python -B -m pytest tests/test_tukf18_hbv_rolling_origin_balance_adjustment.py -q`

Expected: all tests pass.

### Task 5: Execute one frozen preflight and stop at its gate

**Files:**
- Create only through the runner: `artifacts/tukf18_hbv_rolling_origin_balance_adjustment_v1/preflight/*`
- Do not create: `results/tukf18_hbv_rolling_origin_balance_adjustment_v1`

**Interfaces:**
- Consumes: the frozen configuration and tested scripts.
- Produces: one auditable engineering result and one independently recomputed result.

- [ ] **Step 1: Run the broader TUKF17 and TUKF18 test set**

Run: `python -B -m pytest tests/test_tukf17_hbv_rolling_origin_state_hydrology_update.py tests/test_tukf17_hbv_rolling_origin_mechanics.py tests/test_tukf17_hbv_rolling_origin_runner.py tests/test_verify_tukf17_hbv_rolling_origin_state_hydrology_update.py tests/test_tukf18_hbv_rolling_origin_balance_adjustment.py -q`

Expected: no regression in the frozen TUKF17 implementation and all TUKF18 tests pass.

- [ ] **Step 2: Run the TUKF18 engineering preflight once in the foreground**

Run: `python -B scripts/run_tukf18_hbv_rolling_origin_balance_preflight.py`

Expected: creates exactly one preflight root; no formal result root, optimizer update, test query, or background process.

- [ ] **Step 3: Run independent recomputation once in the foreground**

Run: `python -B scripts/verify_tukf18_hbv_rolling_origin_balance_preflight.py`

Expected: every evidence check is true and the verification status matches the balance result.

- [ ] **Step 4: Audit boundaries and report without continuing to training**

Read-only checks: compare original repository status counts to the recorded baseline, confirm no formal controller process is active, confirm the TUKF18 result root is absent, and list the new preflight artifact hashes. If any of the eight ratios is outside `[1/3, 3]`, report the exact failed window and lead and stop.
