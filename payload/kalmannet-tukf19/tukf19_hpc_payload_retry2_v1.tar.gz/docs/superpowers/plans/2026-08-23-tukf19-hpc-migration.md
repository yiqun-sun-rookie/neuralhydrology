# TUKF19 HPC Migration Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Move the already authorized eight-state hydrologic rolling-origin formal comparison to an isolated Linux high-performance-computing deployment without changing its scientific contract, then run a paid compatibility smoke job and automatically submit the paid formal job only after every smoke gate passes.

**Architecture:** Preserve every TUKF17, TUKF18, and TUKF19 scientific file byte-for-byte. Build a deterministic archive that reproduces the registered Windows drive paths as legal Linux archive members, adds only a deployment registry, smoke checker, formal pipeline wrapper, and two Slurm scripts, and binds every member by SHA-256. Use the dedicated `kalmannet-tukf19` Git-mailbox channel and the isolated `/data1/home/sunyiq/kalmannet_tukf19_20260823` target; never touch the dirty `~/neuralhydrology` clone or any other channel.

**Tech Stack:** Python 3.11, NumPy, PyTorch, psutil, matplotlib, pytest, JSON, SHA-256, deterministic gzip/tar, Bash, Slurm

## Global Constraints

- Write implementation files only inside `G:/github/pycharm/projects/kalmannet-tukf17-implementation-20260823`; use the Git mailbox only for the dedicated channel and its payload.
- Keep `G:/github/pycharm/projects/kalmannet`, `G:/github/pycharm/projects/neuralhydrology`, all TUKF17/TUKF18/TUKF19 scientific files, predecessor evidence, and unrelated dirty changes read-only.
- Preserve experiment identifier `TUKF19_HBV_ROLLING_ORIGIN_FORMAL_EXECUTION_V1`, hydrology-coordinate distance `0.05`, filter perturbation factor `8.0`, process standard-deviation fraction `0.02`, all `27` accepted pairs, all origin windows, all metrics, and all `5,184` optimizer updates.
- Record the user's exact `2026-08-23` authorization to migrate, stop the local gate, submit the paid smoke job, submit the paid formal job after smoke success, monitor every two hours, and repair recoverable in-scope failures without further approval.
- Use mailbox channel `kalmannet-tukf19` and high-performance-computing target `/data1/home/sunyiq/kalmannet_tukf19_20260823` only.
- Use Slurm partition `hcpu48y`, one node, one task, one central-processing-unit core, no graphics processor, no `--mem`, no `srun`, and no `set -u`.
- Activate conda environment `nh_final`; export `MKL_THREADING_LAYER=GNU`, `MKL_SERVICE_FORCE_INTEL=1`, `OMP_NUM_THREADS=1`, `MKL_NUM_THREADS=1`, and `OPENBLAS_NUM_THREADS=1`.
- Limit the smoke job to `00:30:00` and the formal job to `1-00:00:00`.
- Require the smoke job to pass source, package, environment, deterministic-numerical, resource, runtime-projection, and sealed-test-boundary gates before formal submission.
- Never overwrite a local or high-performance-computing result, failed attempt, verification, figure, package, log, or status marker.
- Do not commit the isolated Kalmannet implementation worktree. Mailbox commits and pushes are permitted only because they are the documented transport required for this authorized migration.
- Do not equate a successful job, independent technical verification, or figure generation with scientific success.

---

### Task 1: Freeze the deployment registration and path-preserving package contract

**Files:**
- Create: `configs/tukf19_hpc_deployment_v1.json`
- Create: `tests/test_tukf19_hpc_migration.py`

**Interfaces:**
- Consumes: the frozen TUKF19 configuration and all hash-registered TUKF17/TUKF18 evidence.
- Produces: deployment identity `TUKF19_HBV_ROLLING_ORIGIN_FORMAL_EXECUTION_HPC_DEPLOYMENT_V1`, the authorized Slurm shape, the unique target, the smoke references, and the exact package-member policy.

- [ ] **Step 1: Write failing deployment-contract tests**

```python
def test_hpc_deployment_preserves_scientific_identity_and_authorization():
    deployment = load_deployment()
    scientific = common.load_contract()
    assert deployment["scientific_experiment_id"] == scientific["experiment_id"]
    assert deployment["slurm"]["partition"] == "hcpu48y"
    assert deployment["slurm"]["cpus_per_task"] == 1
    assert deployment["authorization"]["formal_after_smoke_authorized"] is True
```

- [ ] **Step 2: Run the focused test and confirm the missing-module failure**

Run: `python -B -m pytest tests/test_tukf19_hpc_migration.py -q`

Expected: collection fails because the high-performance-computing deployment module does not exist.

- [ ] **Step 3: Freeze the local numerical smoke references**

Use accepted pair `truth_seed=1802`, `start_id=start_03`, one optimizer update, and only training/selection observations. Register these Windows reference values:

```json
{
  "hydrology_update_only": {
    "training_loss": 0.15125146814722032,
    "gradient_norm_before_clipping": 3.4497972860803485,
    "selection_loss_after_one_update": 0.3694786507115457,
    "gradient_nonzero_count": 10
  },
  "state_and_hydrology_update": {
    "training_loss": 0.03175369137765366,
    "gradient_norm_before_clipping": 0.610623824133628,
    "selection_loss_after_one_update": 0.08638733140975573,
    "gradient_nonzero_count": 12
  }
}
```

Accept a scalar only when `abs(actual-reference) <= 1e-10 + 1e-8 * abs(reference)`; require exact gradient nonzero counts and finite coordinates.

### Task 2: Implement deterministic package construction

**Files:**
- Create: `scripts/tukf19_hpc_deployment_common.py`
- Create: `scripts/build_tukf19_hpc_bundle.py`
- Modify: `tests/test_tukf19_hpc_migration.py`

**Interfaces:**
- Consumes: frozen deployment registration, worktree scientific files, original read-only Kalmannet inputs, and the external NumPy hydrologic model.
- Produces: `artifacts/tukf19_hpc_deployment_v1/tukf19_hpc_payload_v1.tar.gz` and `bundle_manifest.sha256.json`.

- [ ] **Step 1: Validate roots, identities, and registered source hashes**

```python
def validate_deployment(deployment):
    contract = scientific_common.load_contract()
    assert contract["experiment_id"] == deployment["scientific_experiment_id"]
    assert scientific_common.sha256_file(scientific_common.DEFAULT_CONFIG) == deployment["scientific_config_sha256"]
    assert not scientific_common.resolve_output_path(contract, contract["outputs"]["result_root"]).exists()
```

- [ ] **Step 2: Build a sorted deterministic member map**

Include the TUKF19/TUKF18/TUKF17 configs, plans, tests, runners, verifiers, plotters, parent preflight artifacts, registered original-repository inputs, package initializers, deployment files, and the two copies required by POSIX interpretation of the frozen Windows external-model path:

```text
G:/github/pycharm/projects/neuralhydrology/src/scl_hydro/hbv_lite_numpy.py
G:/github/pycharm/projects/kalmannet/G:/github/pycharm/projects/neuralhydrology/src/scl_hydro/hbv_lite_numpy.py
```

Both copies must have SHA-256 `8c6356926fd6b4bdef672c4ea56bc7941291ee05298dd461100e919beb590103`.

- [ ] **Step 3: Write a deterministic archive**

Sort member names; set tar modification time, uid, and gid to zero; set gzip modification time to zero; reject absolute paths and `..`; add `payload_manifest.json`; then write the external archive manifest with archive SHA-256 and byte count.

- [ ] **Step 4: Test repeatability and closure**

Build twice in temporary directories and require identical archive SHA-256 values, identical member sets, no result directory members, and exact registered-source hashes.

### Task 3: Implement the paid compatibility smoke gate

**Files:**
- Create: `scripts/smoke_tukf19_hpc_compatibility.py`
- Create: `hpc/tukf19_hbv_rolling_origin_formal_execution/submit_smoke_cpu.slurm`
- Modify: `tests/test_tukf19_hpc_migration.py`

**Interfaces:**
- Consumes: extracted payload, deployment registration, package manifest, conda environment `nh_final`, and pair `(1802, start_03)`.
- Produces: a new `artifacts/tukf19_hpc_deployment_v1/smoke/smoke_report.json` with status `HPC_SMOKE_PASS` or a preserved failure report.

- [ ] **Step 1: Verify the complete extracted member manifest before imports**

Reject any missing, extra, or hash-mismatched registered member. Record Python, operating system, NumPy, PyTorch, psutil, matplotlib, Slurm job, node, thread, memory, and storage facts.

- [ ] **Step 2: Exercise both trainable branches without test information**

For `hydrology_update_only` and `state_and_hydrology_update`, create a fresh model, compute one training-origin objective, backpropagate once, perform one Adam update, and compute one selection-origin objective. Do not call test origins, clean targets, formal runner, verifier, or plotter.

- [ ] **Step 3: Require deterministic and cross-environment numerical agreement**

Run each branch twice, require exact repeat equality inside the high-performance-computing process, compare both runs with the frozen Windows references using the registered tolerance, require the filter-noise parameters unchanged, and require `torch.get_num_threads() == 1`.

- [ ] **Step 4: Enforce resource and runtime gates**

Require at least `8.0` GiB available memory, at least `2.0` GiB free storage, finite peak resident memory, smoke elapsed time at most `30` seconds, and projected formal time `smoke_elapsed_seconds * 2500 <= 64800` seconds.

- [ ] **Step 5: Verify the smoke Slurm script**

Require `#SBATCH --partition=hcpu48y`, `--nodes=1`, `--ntasks=1`, `--cpus-per-task=1`, `--time=00:30:00`, the five one-thread/MKL exports, direct `python -B`, and absence of `--mem`, `srun`, and `set -u`.

### Task 4: Implement the formal high-performance-computing pipeline

**Files:**
- Create: `scripts/run_tukf19_hpc_formal_pipeline.py`
- Create: `hpc/tukf19_hbv_rolling_origin_formal_execution/submit_formal_cpu.slurm`
- Modify: `tests/test_tukf19_hpc_migration.py`

**Interfaces:**
- Consumes: an immutable `HPC_SMOKE_PASS` report bound to the same archive and deployment hashes.
- Produces: the original TUKF19 formal result root, independent verification, verified figures, high-performance-computing status records, and a hash-bound result archive.

- [ ] **Step 1: Refuse formal execution unless smoke is complete and bound**

```python
if smoke["status"] != "HPC_SMOKE_PASS" or not all(smoke["checks"].values()):
    raise PermissionError("formal HPC execution requires a complete bound smoke pass")
```

- [ ] **Step 2: Execute the existing scientific programs without modifying them**

Run, in order and with the same Python executable:

```text
python -B scripts/run_tukf19_hbv_rolling_origin_formal_execution.py --confirm-formal-training --confirm-parallel-execution
python -B scripts/verify_tukf19_hbv_rolling_origin_formal_execution.py
python -B scripts/plot_tukf19_hbv_rolling_origin_formal_execution.py
```

- [ ] **Step 3: Require technical completion before packaging**

Require the registry status `FORMAL_COMPLETE_AWAITING_INDEPENDENT_VERIFICATION`, independent status `FORMAL_VERIFIED` with every check true, figure-manifest status `VERIFIED_FIGURES_COMPLETE`, `108` complete method histories, `162` test readouts, and all manifest hashes valid.

- [ ] **Step 4: Create non-overwriting status and result packages**

Write one start record, one success or failure record, one result member manifest, and `tukf19_hpc_formal_result_v1.tar.gz` using exclusive creation. Preserve partial or failed evidence and never reuse a result path.

- [ ] **Step 5: Verify the formal Slurm script**

Require `#SBATCH --partition=hcpu48y`, one core, `--time=1-00:00:00`, the same thread/MKL exports, direct Python, and absence of `--mem`, `srun`, and `set -u`.

### Task 5: Run local non-training verification and freeze the payload

**Files:**
- Read only: all scientific sources and predecessor evidence.
- Create through tested builder only: `artifacts/tukf19_hpc_deployment_v1/**`.

**Interfaces:**
- Consumes: completed deployment implementation.
- Produces: passing focused and regression tests plus one immutable package SHA-256.

- [ ] **Step 1: Run focused migration tests**

Run: `python -B -m pytest tests/test_tukf19_hpc_migration.py -q`

Expected: all tests pass without creating the formal result root.

- [ ] **Step 2: Run the existing combined regression suite**

Run: `python -B -m pytest tests/test_tukf17_hbv_rolling_origin_state_hydrology_update.py tests/test_tukf17_hbv_rolling_origin_mechanics.py tests/test_tukf17_hbv_rolling_origin_runner.py tests/test_verify_tukf17_hbv_rolling_origin_state_hydrology_update.py tests/test_tukf18_hbv_rolling_origin_balance_adjustment.py tests/test_tukf19_hbv_rolling_origin_formal_execution.py -q`

Expected: all tests pass and all registered predecessor hashes remain unchanged.

- [ ] **Step 3: Build and independently inspect the archive**

Run: `python -B scripts/build_tukf19_hpc_bundle.py`

Expected: one new archive and manifest, exact member closure, no formal outputs, and a stable second-build SHA-256.

### Task 6: Deploy, submit, monitor, verify, and retrieve

**Files:**
- Modify only through Git mailbox: `payload/kalmannet-tukf19/**`, `inbox/kalmannet-tukf19/cmd.sh`, `inbox/kalmannet-tukf19/seq`.
- Create remotely only: `/data1/home/sunyiq/kalmannet_tukf19_20260823/**` and `outbox/kalmannet-tukf19/**`.

**Interfaces:**
- Consumes: immutable payload, explicit paid-job authorization, and live Slurm state.
- Produces: smoke job identifier, formal job identifier, two-hour status evidence, independently verified results, and a locally retrieved archive.

- [ ] **Step 1: Push the package through the dedicated mailbox channel**

Add only `payload/kalmannet-tukf19/**` and this channel's command/sequence files; rebase before push; verify the remote blob byte count and SHA-256.

- [ ] **Step 2: Deploy into a unique staging directory and atomically claim the target**

Extract outside the target, verify every member, then move to `/data1/home/sunyiq/kalmannet_tukf19_20260823` only if the target is absent. Preserve a failed staging directory as evidence.

- [ ] **Step 3: Submit the paid smoke job and verify the real submission**

Call `sbatch` with the script path only. Accept submission only when exit code is zero and output matches `Submitted batch job <number>`.

- [ ] **Step 4: Submit the formal paid job only after smoke pass**

Require Slurm state `COMPLETED`, exit code `0:0`, and a bound `HPC_SMOKE_PASS` report before calling `sbatch` for the formal script. Record the formal job identifier.

- [ ] **Step 5: Create a two-hour heartbeat monitor**

Every two hours, inspect the dedicated mailbox channel, `squeue`, `sacct`, exact log paths, method-history count, registry, verification, figures, storage, and job resource state. Make only minimal, non-overwriting, task-scoped repairs; never launch a duplicate controller.

- [ ] **Step 6: Retrieve and verify final evidence**

Return the result archive through `outbox/kalmannet-tukf19/`, verify remote and local byte counts and SHA-256, inspect the independent verification and scientific summary, and report facts, inference, and unknowns separately.
