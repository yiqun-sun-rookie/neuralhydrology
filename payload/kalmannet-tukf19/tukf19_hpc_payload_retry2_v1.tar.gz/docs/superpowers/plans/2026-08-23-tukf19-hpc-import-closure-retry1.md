# TUKF19 HPC Import Closure Retry 1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Repair the first high-performance-computing smoke failure by adding the exact transitive Python package files imported by the original package initializers, while preserving the failed deployment and all scientific files.

**Architecture:** Register a new deployment identity and target ending in `retry1`. Reuse the frozen scientific experiment and deployment machinery, expand only the read-only package import closure, build a new deterministic archive, and submit a new paid smoke job whose pass alone authorizes the formal job.

**Tech Stack:** Python 3.11, deterministic gzip/tar, SHA-256, pytest, Bash, Slurm

## Global Constraints

- Preserve failed smoke job `209815`, report SHA-256 `fe662637a6bf85f1cd525471e05ffe2a13dc7bd62cdff515af0c6d89435651c5`, first bundle SHA-256 `17cf65f4e798253b66c3e4edc16f36b0e5f9b5d307faecfb80472fe27fb1130a`, and `/data1/home/sunyiq/kalmannet_tukf19_20260823` without modification.
- Keep the scientific experiment identifier, configuration, numerical references, parameters, seeds, windows, budgets, gates, and source files unchanged.
- Use new deployment identifier `TUKF19_HBV_ROLLING_ORIGIN_FORMAL_EXECUTION_HPC_DEPLOYMENT_RETRY1_V1` and target `/data1/home/sunyiq/kalmannet_tukf19_20260823_retry1`.
- Add only the ten original read-only Python files required by `global_hydrology/__init__.py`, `global_hydrology/models/__init__.py`, and `global_hydrology/data/__init__.py`.
- Keep the same `hcpu48y`, one-core, no-custom-memory, direct-Python Slurm contract.
- Never overwrite a package, target, smoke report, submission record, formal result, failure record, or retrieved artifact.

---

### Task 1: Register the failed evidence and unique retry

**Files:**
- Create: `configs/tukf19_hpc_deployment_retry1_v1.json`
- Modify: `scripts/tukf19_hpc_deployment_common.py`
- Modify: `tests/test_tukf19_hpc_migration.py`

**Interfaces:**
- Consumes: exact job `209815` failure evidence and the original deployment registration.
- Produces: a new deployment identity, target, outputs, and repair basis bound to the old hashes.

- [ ] **Step 1: Add a failing retry-registration test**

```python
def test_retry1_is_unique_and_bound_to_preserved_failure():
    retry = deployment_common.load_deployment(RETRY_CONFIG)
    assert retry["repair_basis"]["failed_smoke_job_id"] == 209815
    assert retry["repair_basis"]["failed_smoke_report_sha256"] == "fe662637a6bf85f1cd525471e05ffe2a13dc7bd62cdff515af0c6d89435651c5"
    assert retry["hpc"]["target_root"].endswith("_retry1")
```

- [ ] **Step 2: Add the retry registration and exact variant validation**

Reject changes to the old bundle hash, report hash, error type, missing-module text, target, output roots, or authorization.

### Task 2: Complete the original package import closure

**Files:**
- Modify: `scripts/build_tukf19_hpc_bundle.py`
- Modify: `tests/test_tukf19_hpc_migration.py`

**Interfaces:**
- Consumes: original read-only Kalmannet package sources.
- Produces: a payload containing the modules imported transitively at package initialization.

- [ ] **Step 1: Add these exact read-only members**

```text
src/global_hydrology/models/differentiable_m4.py
src/global_hydrology/models/static_encoder.py
src/global_hydrology/models/m4_system_model.py
src/global_hydrology/models/dl_ssm.py
src/global_hydrology/models/hydro_system.py
src/global_hydrology/models/differentiable_walrus.py
src/global_hydrology/models/walrus_system_model.py
src/global_hydrology/data/__init__.py
src/global_hydrology/data/caravan_dataset.py
src/global_hydrology/data/multi_obs_caravan.py
```

- [ ] **Step 2: Test the exact closure and deterministic retry archive**

Require every member to come from the original read-only root, appear once, and have identical hashes across two retry builds.

### Task 3: Add retry-specific Slurm entrypoints and fix package provenance

**Files:**
- Create: `hpc/tukf19_hbv_rolling_origin_formal_execution/submit_smoke_cpu_retry1.slurm`
- Create: `hpc/tukf19_hbv_rolling_origin_formal_execution/submit_formal_cpu_retry1.slurm`
- Modify: `scripts/run_tukf19_hpc_formal_pipeline.py`
- Modify: `scripts/build_tukf19_hpc_bundle.py`
- Modify: `tests/test_tukf19_hpc_migration.py`

**Interfaces:**
- Consumes: retry config and target.
- Produces: retry smoke/formal entrypoints and result packaging bound to the config actually used.

- [ ] **Step 1: Pass the retry config explicitly in both scripts**

Use `/data1/home/sunyiq/kalmannet_tukf19_20260823_retry1`, the same one-core environment, and the same time limits.

- [ ] **Step 2: Package the active deployment config**

Pass `deployment_path` through result-member collection instead of always packaging the default first-attempt config.

### Task 4: Verify, deploy, and rerun the gated sequence

**Files:**
- Create through the builder only: `artifacts/tukf19_hpc_deployment_retry1_v1/**`.
- Modify through the mailbox only: dedicated channel sequence and retry payload files.

**Interfaces:**
- Consumes: repaired deterministic payload.
- Produces: retry smoke job, and only after a bound pass, the formal job.

- [ ] **Step 1: Run focused and combined tests**

Run both migration tests and the complete 81-test scientific regression set; require zero failures.

- [ ] **Step 2: Build and hash the retry payload**

Require a new archive name, new archive SHA-256, complete import closure, and no formal outputs.

- [ ] **Step 3: Deploy without touching the first target**

Use a new staging directory and atomically move only into the absent retry target.

- [ ] **Step 4: Submit retry smoke and conditionally submit formal**

Record both job identifiers. If smoke fails, preserve it and diagnose; if it passes, submit formal exactly once and begin the two-hour monitor.
