"""Frozen, preflight-only primitives for the TUKF18 balance adjustment.

TUKF18 is a new experiment identity.  It imports the already tested TUKF17
rolling-origin numerical primitives but never mutates TUKF17 code, configuration,
or artifacts.  Importing this module performs no computation and creates no file.
"""
from __future__ import annotations

from collections.abc import Mapping
import copy
from pathlib import Path
from typing import Any

import numpy as np
import torch

from scripts import tukf17_hbv_rolling_origin_state_hydrology_common as base


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = ROOT / "configs" / "tukf18_hbv_rolling_origin_balance_adjustment_v1.json"
EXPERIMENT_ID = "TUKF18_HBV_ROLLING_ORIGIN_BALANCE_ADJUSTMENT_V1"
SCHEMA_VERSION = "tukf18_hbv_rolling_origin_balance_adjustment_v1"
PARENT_EXPERIMENT_ID = base.EXPERIMENT_ID
HYDROLOGY_DISTANCE = 0.05
FILTER_FACTOR = 8.0
PROCESS_FRACTION = 0.02
CONFIRMATION_SEED_START = 1801

PIPELINE_ORDER = base.PIPELINE_ORDER
READOUT_ORDER = base.READOUT_ORDER
LEADS = base.LEADS
ORIGIN_WINDOWS = base.ORIGIN_WINDOWS
START_IDS = base.START_IDS
STATE_SCALES = base.STATE_SCALES
PROCESS_NOISE_BOUNDS = base.PROCESS_NOISE_BOUNDS
OBSERVATION_RATIO_BOUNDS = base.OBSERVATION_RATIO_BOUNDS

EXPECTED_OUTPUTS = {
    "preflight_root": "artifacts/tukf18_hbv_rolling_origin_balance_adjustment_v1/preflight",
    "result_root": "results/tukf18_hbv_rolling_origin_balance_adjustment_v1",
    "failed_result_root": "results/tukf18_hbv_rolling_origin_balance_adjustment_v1_failed_attempts",
    "figure_root": "artifacts/tukf18_hbv_rolling_origin_balance_adjustment_v1/formal_verified_summary_v1",
}
ALLOWED_EFFECTIVE_TOP_LEVEL_CHANGES = (
    "schema_version",
    "experiment_id",
    "status",
    "authorization",
    "balanced_error_design",
    "truth_seed_policy",
    "outputs",
    "claims_not_authorized",
)
EXPECTED_SCIENTIFIC_CHANGE = {
    "factor": "hydrology_coordinate_distance",
    "previous_value": 0.04,
    "new_value": 0.05,
    "no_iterative_retuning_after_preflight": True,
}
EXPECTED_UNCHANGED_VALUES = {
    "process_standard_deviation_fraction": 0.02,
    "filter_perturbation_factor": 8.0,
    "filter_perturbation_low_multiplier": 0.125,
    "filter_perturbation_high_multiplier": 8.0,
    "influence_ratio_interval": [1.0 / 3.0, 3.0],
}
EXPECTED_BALANCE_GATE = {
    "influence_ratio_interval": [1.0 / 3.0, 3.0],
    "required_windows": ["train", "selection"],
    "required_leads_days": [1, 2, 3],
    "equal_weight_summary_required": True,
    "required_ratio_count": 8,
    "any_failure_stops": True,
    "combined_error_is_diagnostic_not_a_gate": True,
    "test_metric_queries": 0,
}
EXPECTED_CLAIMS_NOT_AUTHORIZED = [
    "formal training has been authorized",
    "hydrologic parameter identifiability",
    "recovery from an erroneous initial state",
    "online test-period parameter learning",
    "real-catchment forecast validity",
    "forecast value under forcing forecast error",
    "replacement of any sealed predecessor verdict",
    "scientific success from technical verification alone",
]
SOURCE_RELATIVE_PATHS = (
    "docs/superpowers/plans/2026-08-23-tukf18-balanced-rolling-origin-preflight.md",
    "scripts/tukf18_hbv_rolling_origin_balance_common.py",
    "scripts/run_tukf18_hbv_rolling_origin_balance_preflight.py",
    "scripts/verify_tukf18_hbv_rolling_origin_balance_preflight.py",
    "tests/test_tukf18_hbv_rolling_origin_balance_adjustment.py",
)


read_json = base.read_json
jsonable = base.jsonable
write_new_json = base.write_new_json
write_new_npz = base.write_new_npz
sha256_file = base.sha256_file
sha256_arrays = base.sha256_arrays
resolve_output_path = base.resolve_output_path
resolve_readonly_input = base.resolve_readonly_input
predecessor_root = base.predecessor_root
predecessor_modules = base.predecessor_modules
parent_contracts = base.parent_contracts
truth_process_variances = base.truth_process_variances
generate_truth_for_seed = base.generate_truth_for_seed
mechanically_accept_truth_seed = base.mechanically_accept_truth_seed
registered_pairs = base.registered_pairs
origin_indices = base.origin_indices
rolling_origin_objective = base.rolling_origin_objective
classify_balance_arrays = base.classify_balance_arrays


def source_paths(configuration_path: Path | str = DEFAULT_CONFIG) -> tuple[Path, ...]:
    paths = (
        Path(configuration_path).resolve(),
        *(ROOT / value for value in SOURCE_RELATIVE_PATHS),
    )
    missing = [path for path in paths if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"TUKF18 source closure is incomplete: {missing}")
    return tuple(paths)


def read_registration(path: Path | str = DEFAULT_CONFIG) -> dict[str, Any]:
    return read_json(path)


def _local_evidence_path(raw: str) -> Path:
    value = Path(raw)
    if value.is_absolute():
        raise ValueError("TUKF18 parent evidence paths must be worktree-relative")
    path = (ROOT / value).resolve()
    try:
        path.relative_to(ROOT.resolve())
    except ValueError as error:
        raise ValueError(f"parent evidence path escapes the worktree: {path}") from error
    return path


def _expected_confirmation_policy() -> dict[str, Any]:
    return {
        "first_candidate": CONFIRMATION_SEED_START,
        "candidate_step": 1,
        "accepted_count": 27,
        "start_ids_in_accepted_order": list(START_IDS),
        "acceptance_conditions": {
            "all_truth_arrays_finite": True,
            "maximum_projection_fraction": 0.15,
            "maximum_observation_fixed_point_error": 1e-12,
            "minimum_proportional_observation_branch_fraction": 0.5,
        },
        "scientific_metric_queries": 0,
        "disjoint_from_tukf17_attempted_seed_interval": [1701, 1730],
    }


def _verify_file(path: Path, expected: str, label: str) -> None:
    if not path.is_file():
        raise FileNotFoundError(f"registered {label} is missing: {path}")
    if sha256_file(path) != expected:
        raise ValueError(f"registered {label} SHA-256 changed")


def _candidate(registry: Mapping[str, Any], candidate_id: str) -> Mapping[str, Any]:
    rows = [
        row
        for row in registry.get("candidates", ())
        if row.get("candidate_id") == candidate_id
    ]
    if len(rows) != 1:
        raise ValueError(f"expected one design-evidence candidate: {candidate_id}")
    return rows[0]


def _verify_design_evidence(registration: Mapping[str, Any]) -> None:
    evidence = registration.get("design_evidence", {})
    expected_path = Path(
        "G:/github/pycharm/projects/kalmannet/results/"
        "tukf15_hbv_truth_balance_forward_gate_v1/registry.json"
    ).resolve()
    path = Path(str(evidence.get("registry_path", ""))).resolve()
    if path != expected_path:
        raise ValueError("TUKF15 design registry path changed")
    expected_hash = "79ae0f108e9d2fe8a5cd9e8f5ebad0a712920e2b8bcfa14b458673c870979ed8"
    if evidence.get("registry_sha256") != expected_hash:
        raise ValueError("TUKF15 design registry registered hash changed")
    _verify_file(path, expected_hash, "TUKF15 design registry")
    registry = read_json(path)

    factor_four = _candidate(registry, "qf_0020__ff_04__hd_0040")
    factor_four_ratios = [
        float(factor_four["windows"]["train"]["by_lead"][str(lead)]["influence_ratio"])
        for lead in LEADS
    ]
    expected_factor_four = [
        0.40249355404506804,
        0.2889473950553593,
        0.17579764925443347,
    ]
    if factor_four_ratios != expected_factor_four:
        raise ValueError("factor-four design evidence changed")

    distance_four = _candidate(registry, "qf_0020__ff_08__hd_0040")
    distance_eight = _candidate(registry, "qf_0020__ff_08__hd_0080")
    minimum_four = min(
        float(distance_four["windows"]["train"]["by_lead"][str(lead)]["influence_ratio"])
        for lead in LEADS
    )
    minimum_eight = min(
        float(distance_eight["windows"]["train"]["by_lead"][str(lead)]["influence_ratio"])
        for lead in LEADS
    )
    if minimum_four != 0.40710992226210496 or minimum_eight != 0.28549126250522194:
        raise ValueError("hydrologic-distance design evidence changed")


def _parent_paths(registration: Mapping[str, Any]) -> dict[str, Path]:
    evidence = registration.get("parent_evidence", {})
    path_keys = {
        "configuration": "configuration_path",
        "runtime_common": "runtime_common_path",
        "preflight": "preflight_path",
        "balance_gate": "balance_gate_path",
        "balance_errors": "balance_errors_path",
        "seed_registry": "seed_registry_path",
        "independent_verification": "independent_verification_path",
    }
    return {
        label: _local_evidence_path(str(evidence.get(key, "")))
        for label, key in path_keys.items()
    }


def _verify_parent_evidence(registration: Mapping[str, Any]) -> dict[str, Path]:
    evidence = registration.get("parent_evidence", {})
    paths = _parent_paths(registration)
    for label, path in paths.items():
        expected = str(evidence.get(f"{label}_sha256", ""))
        if len(expected) != 64:
            raise ValueError(f"registered parent hash is invalid: {label}")
        _verify_file(path, expected, f"TUKF17 {label}")

    parent_preflight = read_json(paths["preflight"])
    parent_balance = read_json(paths["balance_gate"])
    parent_verification = read_json(paths["independent_verification"])
    if parent_preflight.get("experiment_id") != PARENT_EXPERIMENT_ID:
        raise ValueError("TUKF17 parent experiment identity changed")
    if (
        parent_preflight.get("status") != "BALANCE_HOLD"
        or parent_preflight.get("balance_status") != "BALANCE_HOLD"
        or int(parent_preflight.get("test_metric_queries", -1)) != 0
        or int(parent_preflight.get("formal_optimizer_updates", -1)) != 0
        or bool(parent_preflight.get("formal_training_authorized"))
    ):
        raise ValueError("TUKF17 parent preflight boundary changed")
    if (
        parent_balance.get("status") != "BALANCE_HOLD"
        or int(parent_balance.get("ratio_count", -1)) != 8
        or float(parent_balance.get("maximum_ratio", -1.0)) != 3.246927759094365
        or int(parent_balance.get("test_metric_queries", -1)) != 0
    ):
        raise ValueError("TUKF17 parent balance evidence changed")
    if (
        parent_verification.get("status") != "BALANCE_HOLD_VERIFIED"
        or not all(parent_verification.get("checks", {}).values())
        or int(parent_verification.get("test_metric_queries", -1)) != 0
        or int(parent_verification.get("formal_optimizer_updates", -1)) != 0
    ):
        raise ValueError("TUKF17 independent verification evidence changed")
    return paths


def _load_parent_contract_from_registration(
    registration: Mapping[str, Any], *, verify_base_contract: bool = True
) -> dict[str, Any]:
    paths = _parent_paths(registration)
    parent = read_json(paths["configuration"])
    if verify_base_contract:
        base.validate_contract(parent)
    return parent


def validate_registration(registration: Mapping[str, Any]) -> dict[str, Any]:
    if registration.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("unexpected TUKF18 registration schema")
    if registration.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("unexpected TUKF18 experiment identifier")
    if registration.get("status") != "PREFLIGHT_AUTHORIZED_FORMAL_TRAINING_NOT_AUTHORIZED":
        raise ValueError("TUKF18 registration status changed")

    authorization = registration.get("authorization", {})
    if not bool(authorization.get("preflight_implementation_authorized")):
        raise PermissionError("TUKF18 implementation is not authorized")
    if not bool(authorization.get("preflight_execution_authorized")):
        raise PermissionError("TUKF18 preflight is not authorized")
    if bool(authorization.get("formal_training_authorized")):
        raise PermissionError("TUKF18 formal training is not authorized")
    if authorization.get("authorization_date") != "2026-08-23":
        raise ValueError("TUKF18 authorization date changed")
    if not str(authorization.get("basis", "")).strip():
        raise ValueError("TUKF18 authorization basis is missing")

    if registration.get("scientific_change") != EXPECTED_SCIENTIFIC_CHANGE:
        raise ValueError("TUKF18 scientific change drifted")
    if registration.get("unchanged_scientific_values") != EXPECTED_UNCHANGED_VALUES:
        raise ValueError("TUKF18 unchanged scientific values drifted")
    if registration.get("confirmation_seed_policy") != _expected_confirmation_policy():
        raise ValueError("TUKF18 confirmation seed policy drifted")
    if registration.get("balance_gate") != EXPECTED_BALANCE_GATE:
        raise ValueError("TUKF18 balance gate drifted")
    if registration.get("outputs") != EXPECTED_OUTPUTS:
        raise ValueError("TUKF18 output roots drifted")
    if registration.get("claims_not_authorized") != EXPECTED_CLAIMS_NOT_AUTHORIZED:
        raise ValueError("TUKF18 claim boundary drifted")
    for raw in EXPECTED_OUTPUTS.values():
        resolve_output_path({"outputs": EXPECTED_OUTPUTS}, raw)

    paths = _verify_parent_evidence(registration)
    parent = _load_parent_contract_from_registration(registration)
    if sha256_file(paths["configuration"]) != registration["parent_evidence"]["configuration_sha256"]:
        raise ValueError("TUKF17 parent configuration changed")
    if parent["balanced_error_design"]["hydrology_coordinate_distance"] != 0.04:
        raise ValueError("TUKF17 parent hydrologic distance changed")
    _verify_design_evidence(registration)
    return {
        "parent_configuration_verified": True,
        "parent_balance_hold_verified": True,
        "parent_independent_verification_verified": True,
        "design_registry_verified": True,
    }


def load_parent_contract(
    registration_path: Path | str = DEFAULT_CONFIG,
) -> dict[str, Any]:
    registration = read_registration(registration_path)
    validate_registration(registration)
    return _load_parent_contract_from_registration(registration)


def _effective_contract(
    registration: Mapping[str, Any], parent: Mapping[str, Any]
) -> dict[str, Any]:
    contract = copy.deepcopy(parent)
    contract["schema_version"] = SCHEMA_VERSION
    contract["experiment_id"] = EXPERIMENT_ID
    contract["status"] = "DESIGN_FROZEN_PREFLIGHT_ONLY"
    contract["authorization"] = {
        "implementation_authorized": True,
        "preflight_execution_authorized": True,
        "formal_training_authorized_at_config_freeze": False,
        "formal_training_requires_separate_user_confirmation": True,
        "authorization_date": registration["authorization"]["authorization_date"],
        "basis": registration["authorization"]["basis"],
    }
    design = copy.deepcopy(parent["balanced_error_design"])
    design["hydrology_coordinate_distance"] = HYDROLOGY_DISTANCE
    contract["balanced_error_design"] = design
    policy = registration["confirmation_seed_policy"]
    contract["truth_seed_policy"] = {
        "first_candidate": int(policy["first_candidate"]),
        "candidate_step": int(policy["candidate_step"]),
        "accepted_count": int(policy["accepted_count"]),
        "start_ids_in_accepted_order": list(policy["start_ids_in_accepted_order"]),
        "acceptance_conditions": copy.deepcopy(policy["acceptance_conditions"]),
    }
    contract["outputs"] = copy.deepcopy(registration["outputs"])
    contract["claims_not_authorized"] = copy.deepcopy(
        registration["claims_not_authorized"]
    )
    return contract


def validate_contract(
    contract: Mapping[str, Any], *, registration_path: Path | str = DEFAULT_CONFIG
) -> dict[str, Any]:
    registration = read_registration(registration_path)
    registration_validation = validate_registration(registration)
    parent = _load_parent_contract_from_registration(registration)
    expected = _effective_contract(registration, parent)
    if contract != expected:
        raise ValueError("effective TUKF18 contract differs from its frozen registration")

    normalized = copy.deepcopy(contract)
    for key in ALLOWED_EFFECTIVE_TOP_LEVEL_CHANGES:
        normalized[key] = copy.deepcopy(parent[key])
    if normalized != parent:
        raise ValueError("TUKF18 changed an unregistered parent field")
    if contract["balanced_error_design"] != {
        **parent["balanced_error_design"],
        "hydrology_coordinate_distance": HYDROLOGY_DISTANCE,
    }:
        raise ValueError("TUKF18 balanced-error design has more than one change")
    if bool(contract["authorization"]["formal_training_authorized_at_config_freeze"]):
        raise PermissionError("TUKF18 formal training remains forbidden")
    return {
        **registration_validation,
        "origin_counts": {name: len(values) for name, values in ORIGIN_WINDOWS.items()},
        "accepted_confirmation_seed_count": 27,
        "formal_training_authorized": False,
    }


def load_contract(path: Path | str = DEFAULT_CONFIG) -> dict[str, Any]:
    registration = read_registration(path)
    validate_registration(registration)
    parent = _load_parent_contract_from_registration(registration)
    contract = _effective_contract(registration, parent)
    validate_contract(contract, registration_path=path)
    return contract


def source_hashes(
    contract: Mapping[str, Any], configuration_path: Path | str = DEFAULT_CONFIG
) -> dict[str, str]:
    validate_contract(contract, registration_path=configuration_path)
    result = {
        path.relative_to(ROOT).as_posix(): sha256_file(path)
        for path in source_paths(configuration_path)
    }
    registration = read_registration(configuration_path)
    for label, path in _parent_paths(registration).items():
        result[f"parent:{label}"] = sha256_file(path)
    design_path = Path(registration["design_evidence"]["registry_path"]).resolve()
    result["design:TUKF15_registry"] = sha256_file(design_path)
    for raw, expected in contract["readonly_input_sha256"].items():
        path = resolve_readonly_input(contract, raw)
        actual = sha256_file(path)
        if actual != str(expected):
            raise ValueError(f"read-only input SHA-256 mismatch: {raw}")
        result[f"readonly:{raw}"] = actual
    return result


def freeze_seed_registry(
    contract: Mapping[str, Any], *, destination: Path | str, configuration_path: Path | str
) -> dict[str, Any]:
    validate_contract(contract, registration_path=configuration_path)
    policy = contract["truth_seed_policy"]
    accepted_target = int(policy["accepted_count"])
    candidate = int(policy["first_candidate"])
    step = int(policy["candidate_step"])
    attempts: list[dict[str, Any]] = []
    accepted: list[dict[str, Any]] = []
    while len(accepted) < accepted_target:
        row = mechanically_accept_truth_seed(candidate, contract)
        attempts.append(row)
        if row["accepted"]:
            accepted.append(
                {
                    "accepted_order": len(accepted) + 1,
                    "truth_seed": candidate,
                    "start_id": START_IDS[len(accepted)],
                    "truth_array_sha256": row.get("truth_array_sha256"),
                }
            )
        candidate += step
    if any(1701 <= int(row["seed"]) <= 1730 for row in attempts):
        raise RuntimeError("TUKF18 confirmation seeds overlap TUKF17 attempts")
    registry = {
        "schema_version": "tukf18_truth_seed_registry_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "UNSEEN_TRUTH_SEEDS_MECHANICALLY_FROZEN",
        "candidate_start": int(policy["first_candidate"]),
        "attempted_candidates": attempts,
        "accepted_pairs": accepted,
        "accepted_count": len(accepted),
        "scientific_metric_queries": 0,
        "tukf17_seed_overlap_count": 0,
        "truth_generator_sha256": contract["readonly_input_sha256"][
            "scripts/tukf11_hbv_joint_parameter_synthetic_common.py"
        ],
        "configuration_sha256": sha256_file(configuration_path),
    }
    write_new_json(destination, registry)
    return registry


def build_start_values(
    contract: Mapping[str, Any],
    start_id: str,
    *,
    hydrology_source: str = "initial",
    filter_source: str = "initial",
) -> dict[str, Any]:
    parent, starts = parent_contracts(contract)
    if start_id not in START_IDS:
        raise ValueError(f"unknown TUKF18 start identifier: {start_id}")
    entry = starts["start_registry"][start_id]
    truth = parent["truth"]
    names = truth["trainable_hydrology_names"]
    parameters = np.asarray(truth["hydrology_parameters"], dtype=np.float64)
    lower = np.asarray([truth["hydrology_v5_bounds"][name][0] for name in names])
    upper = np.asarray([truth["hydrology_v5_bounds"][name][1] for name in names])
    truth_coordinate = (parameters[:12] - lower) / (upper - lower)
    distance = float(contract["balanced_error_design"]["hydrology_coordinate_distance"])
    if hydrology_source == "truth":
        coordinate = truth_coordinate
    elif hydrology_source == "initial":
        coordinate = truth_coordinate + distance * np.asarray(
            entry["hydrology_signs"], dtype=np.float64
        )
    else:
        raise ValueError(f"unknown hydrology source: {hydrology_source}")
    if coordinate.shape != (12,) or np.any(coordinate <= 0.0) or np.any(coordinate >= 1.0):
        raise ValueError("TUKF18 hydrology start lies outside strict parameter bounds")
    hydrology = np.concatenate((lower + coordinate * (upper - lower), parameters[12:13]))

    process_truth = truth_process_variances(contract)
    observation_truth = float(truth["observation_residual_ratio"])
    factor = float(contract["balanced_error_design"]["filter_perturbation_factor"])
    if filter_source == "truth":
        process = process_truth
        observation = observation_truth
    elif filter_source == "initial":
        process_multiplier = np.asarray(
            [
                1.0 / factor if float(value) < 1.0 else factor
                for value in entry["process_multipliers"]
            ],
            dtype=np.float64,
        )
        process = process_truth * process_multiplier
        observation = observation_truth * (
            1.0 / factor if float(entry["observation_multiplier"]) < 1.0 else factor
        )
    else:
        raise ValueError(f"unknown filter source: {filter_source}")
    return {
        "hydrology_parameters": np.ascontiguousarray(hydrology),
        "hydrology_coordinates": np.ascontiguousarray(coordinate),
        "process_variances": np.ascontiguousarray(process),
        "observation_ratio": float(observation),
        "truth_process_variances": np.ascontiguousarray(process_truth),
    }


def build_model(
    contract: Mapping[str, Any],
    start_id: str,
    *,
    hydrology_source: str = "initial",
    filter_source: str = "initial",
    dtype: torch.dtype = torch.float64,
    device: torch.device | str = torch.device("cpu"),
):
    modules = predecessor_modules(contract)
    parent, _ = parent_contracts(contract)
    values = build_start_values(
        contract,
        start_id,
        hydrology_source=hydrology_source,
        filter_source=filter_source,
    )
    model = modules["adapter"].JointTrainableRoutedHBVLiteUKF(
        torch.as_tensor(values["hydrology_parameters"], dtype=dtype, device=device).reshape(1, -1),
        torch.as_tensor(parent["truth"]["routing_weights"], dtype=dtype, device=device).reshape(1, -1),
        initial_process_diagonal=torch.as_tensor(
            values["process_variances"], dtype=dtype, device=device
        ),
        initial_observation_ratio=values["observation_ratio"],
        process_noise_bounds=PROCESS_NOISE_BOUNDS,
        observation_ratio_bounds=OBSERVATION_RATIO_BOUNDS,
        clamp_storage=True,
        signed_routing_memory=False,
        dtype=dtype,
        device=torch.device(device),
    )
    if int(model.dim_x) != 8:
        raise RuntimeError("TUKF18 requires exactly eight routed state coordinates")
    model._tukf17_readonly_predecessor_root = str(predecessor_root(contract))
    model._tukf18_experiment_id = EXPERIMENT_ID
    return model
