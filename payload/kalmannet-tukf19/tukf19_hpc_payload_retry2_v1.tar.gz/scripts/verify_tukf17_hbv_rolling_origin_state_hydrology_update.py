"""Independently verify TUKF17 without importing its formal runner."""
from __future__ import annotations

import argparse
from fractions import Fraction
import json
import math
from pathlib import Path
import sys
from typing import Any, Mapping, Sequence

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import tukf17_hbv_rolling_origin_state_hydrology_common as common  # noqa: E402


DEFAULT_CONFIG = common.DEFAULT_CONFIG
ABSOLUTE_TOLERANCE = 1e-11
RELATIVE_TOLERANCE = 1e-10


def _source_hashes(
    contract: Mapping[str, Any], contract_path: Path
) -> dict[str, str]:
    relative = (
        "scripts/tukf17_hbv_rolling_origin_state_hydrology_common.py",
        "scripts/run_tukf17_hbv_rolling_origin_state_hydrology_update.py",
        "scripts/verify_tukf17_hbv_rolling_origin_state_hydrology_update.py",
        "scripts/plot_tukf17_hbv_rolling_origin_state_hydrology_update.py",
        "tests/test_tukf17_hbv_rolling_origin_state_hydrology_update.py",
        "tests/test_tukf17_hbv_rolling_origin_mechanics.py",
        "tests/test_tukf17_hbv_rolling_origin_runner.py",
        "tests/test_verify_tukf17_hbv_rolling_origin_state_hydrology_update.py",
    )
    paths = (contract_path.resolve(), *(ROOT / value for value in relative))
    if any(not path.is_file() for path in paths):
        raise FileNotFoundError("independent source closure is incomplete")
    result = {
        path.relative_to(ROOT).as_posix(): common.sha256_file(path) for path in paths
    }
    for raw, expected in contract["readonly_input_sha256"].items():
        path = common.resolve_readonly_input(contract, raw)
        actual = common.sha256_file(path)
        if actual != str(expected):
            raise ValueError(f"read-only input SHA-256 mismatch: {raw}")
        result[f"readonly:{raw}"] = actual
    return result


def _load_npz(path: Path | str) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as archive:
        return {name: np.asarray(archive[name]).copy() for name in archive.files}


def _snapshot_hash(snapshot: Mapping[str, Any]) -> str:
    return common.sha256_arrays(snapshot)


def _arrays_close(left: np.ndarray, right: np.ndarray) -> bool:
    a = np.asarray(left)
    b = np.asarray(right)
    if a.shape != b.shape or a.dtype.kind != b.dtype.kind:
        return False
    if a.dtype.kind in "fc":
        return bool(
            np.allclose(
                a,
                b,
                rtol=RELATIVE_TOLERANCE,
                atol=ABSOLUTE_TOLERANCE,
                equal_nan=False,
            )
        )
    return bool(np.array_equal(a, b))


def _values_close(left: Any, right: Any) -> bool:
    if isinstance(left, Mapping) and isinstance(right, Mapping):
        return set(left) == set(right) and all(
            _values_close(left[key], right[key]) for key in left
        )
    if isinstance(left, (list, tuple)) and isinstance(right, (list, tuple)):
        return len(left) == len(right) and all(
            _values_close(a, b) for a, b in zip(left, right)
        )
    if isinstance(left, (int, float, np.number)) and isinstance(
        right, (int, float, np.number)
    ):
        return math.isclose(
            float(left),
            float(right),
            rel_tol=RELATIVE_TOLERANCE,
            abs_tol=ABSOLUTE_TOLERANCE,
        )
    return left == right


def independently_select_checkpoint(
    rows: Sequence[Mapping[str, Any]]
) -> dict[str, Any]:
    if not rows:
        raise ValueError("selection rows are empty")
    values = [
        {"update": int(row["update"]), "selection_loss": float(row["selection_loss"])}
        for row in rows
    ]
    updates = tuple(row["update"] for row in values)
    if len(values) == 1:
        if updates != (0,):
            raise ValueError("nonlearning selection must contain only update zero")
    elif updates != tuple(range(0, 97, 4)):
        raise ValueError("selection rows are not the complete 0,4,...,96 schedule")
    if not all(math.isfinite(row["selection_loss"]) for row in values):
        raise ValueError("selection loss is non-finite")
    return min(values, key=lambda row: (row["selection_loss"], row["update"]))


def _tensor_inputs(
    contract: Mapping[str, Any], forcing: np.ndarray, observations: np.ndarray
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    return (
        torch.as_tensor(forcing, dtype=torch.float64),
        torch.as_tensor(observations, dtype=torch.float64),
        torch.as_tensor(contract["truth_and_filter"]["initial_state"], dtype=torch.float64),
        torch.eye(8, dtype=torch.float64)
        * float(contract["truth_and_filter"]["initial_covariance_diagonal"]),
    )


def _independent_balance_errors(
    contract: Mapping[str, Any], registry: Mapping[str, Any]
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    pairs = common.registered_pairs(contract, registry)
    result = {
        name: np.empty((27, 2, 3), dtype=np.float64)
        for name in ("E00", "E01", "E10", "E11")
    }
    definitions = {
        "E00": ("truth", "truth"),
        "E01": ("truth", "initial"),
        "E10": ("initial", "truth"),
        "E11": ("initial", "initial"),
    }
    for pair_index, (seed, start_id) in enumerate(pairs):
        forcing, truth = common.generate_truth_for_seed(contract, seed)
        observations = np.asarray(truth["observations"], dtype=np.float64)
        forcing_tensor, observation_tensor, initial_state, covariance = _tensor_inputs(
            contract, forcing, observations
        )
        for label, (hydrology_source, filter_source) in definitions.items():
            model = common.build_model(
                contract,
                start_id,
                hydrology_source=hydrology_source,
                filter_source=filter_source,
            )
            for window_index, split in enumerate(("train", "selection")):
                with torch.no_grad():
                    _, details = common.rolling_origin_objective(
                        model,
                        forcing_tensor,
                        observation_tensor,
                        initial_state,
                        covariance,
                        common.origin_indices(contract, split),
                        state_update=True,
                        targets=observation_tensor,
                        base_observation_variance=float(
                            contract["truth_and_filter"]["base_observation_variance"]
                        ),
                    )
                result[label][pair_index, window_index] = [
                    float(details["mse_by_lead"][lead]) for lead in common.LEADS
                ]
    return result["E00"], result["E01"], result["E10"], result["E11"]


def verify_preflight(
    contract: Mapping[str, Any], *, contract_path: Path = DEFAULT_CONFIG
) -> dict[str, Any]:
    common.validate_contract(contract)
    root = common.resolve_output_path(contract, contract["outputs"]["preflight_root"])
    preflight = common.read_json(root / "preflight.json")
    seed_registry = common.read_json(root / "seed_registry.json")
    stored_balance = common.read_json(root / "balance_gate.json")
    stored_errors = _load_npz(root / "balance_errors.npz")

    seed_checks = []
    for stored in seed_registry["attempted_candidates"]:
        recomputed = common.mechanically_accept_truth_seed(
            int(stored["seed"]), contract
        )
        seed_checks.append(
            all(
                _values_close(stored.get(key), recomputed.get(key))
                for key in (
                    "seed",
                    "accepted",
                    "checks",
                    "diagnostics",
                    "scientific_metric_queries",
                    "truth_array_sha256",
                    "generation_error",
                )
            )
        )
    pairs = common.registered_pairs(contract, seed_registry)
    accepted_attempts = [
        row for row in seed_registry["attempted_candidates"] if bool(row["accepted"])
    ][:27]
    expected_accepted = [
        {
            "accepted_order": index,
            "truth_seed": int(row["seed"]),
            "start_id": common.START_IDS[index - 1],
            "truth_array_sha256": row.get("truth_array_sha256"),
        }
        for index, row in enumerate(accepted_attempts, 1)
    ]
    e00, e01, e10, e11 = _independent_balance_errors(contract, seed_registry)
    recomputed_balance = common.classify_balance_arrays(
        e00, e01, e10, e11, contract
    )
    checks = {
        "configuration_identity": preflight.get("config_sha256")
        == common.sha256_file(contract_path),
        "source_identity": preflight.get("source_sha256")
        == _source_hashes(contract, contract_path),
        "seed_attempts_recomputed": bool(seed_checks) and all(seed_checks),
        "seed_registry_file_identity": (
            seed_registry.get("configuration_sha256")
            == common.sha256_file(contract_path)
            and seed_registry.get("truth_generator_sha256")
            == contract["readonly_input_sha256"][
                "scripts/tukf11_hbv_joint_parameter_synthetic_common.py"
            ]
            and preflight.get("seed_registry_sha256")
            == common.sha256_file(root / "seed_registry.json")
        ),
        "accepted_seed_assignment_recomputed": _values_close(
            seed_registry.get("accepted_pairs"), expected_accepted
        ),
        "accepted_seed_count_and_independence": len(pairs) == 27
        and len({seed for seed, _ in pairs}) == 27,
        "zero_scientific_queries_during_seed_selection": int(
            seed_registry.get("scientific_metric_queries", -1)
        )
        == 0,
        "balance_e00_raw_arrays": _arrays_close(stored_errors["E00"], e00),
        "balance_e01_raw_arrays": _arrays_close(stored_errors["E01"], e01),
        "balance_e10_raw_arrays": _arrays_close(stored_errors["E10"], e10),
        "balance_e11_raw_arrays": _arrays_close(stored_errors["E11"], e11),
        "balance_artifact_hashes": (
            set(stored_errors) == {"E00", "E01", "E10", "E11"}
            and preflight.get("balance_errors_sha256")
            == common.sha256_file(root / "balance_errors.npz")
            and preflight.get("balance_gate_sha256")
            == common.sha256_file(root / "balance_gate.json")
        ),
        "balance_classification_recomputed": _values_close(
            stored_balance, recomputed_balance
        ),
        "preflight_status_matches_balance": preflight.get("status")
        == (
            "PREFLIGHT_ENGINEERING_PASS"
            if recomputed_balance["status"] == "BALANCE_PASS"
            else "BALANCE_HOLD"
        ),
        "no_test_queries": int(preflight.get("test_metric_queries", -1)) == 0,
        "no_formal_optimizer_updates": int(
            preflight.get("formal_optimizer_updates", -1)
        )
        == 0,
    }
    if all(checks.values()) and recomputed_balance["status"] == "BALANCE_PASS":
        status = "PREFLIGHT_VERIFIED"
    elif all(checks.values()):
        status = "BALANCE_HOLD_VERIFIED"
    else:
        status = "PREFLIGHT_VERIFICATION_FAILED"
    report = {
        "schema_version": "tukf17_independent_preflight_verification_v1",
        "experiment_id": common.EXPERIMENT_ID,
        "status": status,
        "checks": checks,
        "balance_status": recomputed_balance["status"],
        "accepted_seed_count": len(pairs),
        "test_metric_queries": 0,
        "formal_optimizer_updates": 0,
    }
    common.write_new_json(root / "independent_verification.json", report)
    return report


def _verify_manifest(root: Path, manifest: Mapping[str, Any]) -> bool:
    expected = {
        path.relative_to(root).as_posix(): common.sha256_file(path)
        for path in sorted(root.rglob("*"))
        if path.is_file()
        and path.name not in {"manifest.json", "independent_verification.json"}
    }
    return manifest.get("files") == expected


def _stream_reconstruct(
    contract: Mapping[str, Any],
    model,
    readout_id: str,
    forcing: np.ndarray,
    truth: Mapping[str, Any],
) -> dict[str, Any]:
    specification = contract["readout_grid"][readout_id]
    origins = common.origin_indices(contract, "test")
    origin_set = set(origins)
    forcing_tensor, observation_tensor, initial_state, covariance = _tensor_inputs(
        contract, forcing, np.asarray(truth["observations"], dtype=np.float64)
    )
    states: list[torch.Tensor] = []
    priors: list[torch.Tensor] = []
    prior_covariances: list[torch.Tensor] = []
    posterior_covariances: list[torch.Tensor] = []
    post_forecasts = {lead: [] for lead in common.LEADS}
    prior_forecasts = {lead: [] for lead in common.LEADS}
    if bool(specification["state_update"]):
        mean = initial_state.reshape(1, -1)
        cov = covariance.reshape(1, 8, 8)
        for day in range(max(origins) + 1):
            trace = common.rollout_state_update_trace(
                model,
                forcing_tensor[day : day + 1],
                observation_tensor[day : day + 1],
                mean,
                cov,
                base_observation_variance=float(
                    contract["truth_and_filter"]["base_observation_variance"]
                ),
            )
            mean = trace["posterior_state"][0]
            cov = trace["posterior_covariance"][0]
            if day in origin_set:
                prior = trace["prior_state"][0, 0]
                posterior = trace["posterior_state"][0, 0]
                priors.append(prior)
                states.append(posterior)
                prior_covariances.append(trace["prior_covariance"][0, 0])
                posterior_covariances.append(trace["posterior_covariance"][0, 0])
                issued_post = common.forecast_from_origin_states(
                    model, posterior.reshape(1, -1), forcing_tensor, (day,)
                )
                issued_prior = common.forecast_from_origin_states(
                    model, prior.reshape(1, -1), forcing_tensor, (day,)
                )
                for lead in common.LEADS:
                    post_forecasts[lead].append(issued_post[lead][0])
                    prior_forecasts[lead].append(issued_prior[lead][0])
    else:
        replay = common.rollout_open_loop_states(
            model, forcing_tensor, initial_state, max(origins) + 1
        )
        selected = replay[
            torch.as_tensor([origin + 1 for origin in origins], dtype=torch.long)
        ]
        states = [row for row in selected]
        issued = common.forecast_from_origin_states(
            model, selected, forcing_tensor, origins
        )
        for lead in common.LEADS:
            post_forecasts[lead] = list(issued[lead])

    forecast_matrix = np.column_stack(
        [
            torch.stack(post_forecasts[lead]).detach().cpu().numpy()
            for lead in common.LEADS
        ]
    )
    origin_array = np.asarray(origins, dtype=np.int64)
    clean = np.asarray(truth["clean_discharge"], dtype=np.float64)
    observed = np.asarray(truth["observations"], dtype=np.float64)
    clean_targets = np.column_stack([clean[origin_array + lead] for lead in common.LEADS])
    observed_targets = np.column_stack(
        [observed[origin_array + lead] for lead in common.LEADS]
    )
    state_array = torch.stack(states).detach().cpu().numpy()
    state_metrics = common.state_error_metrics(
        state_array, np.asarray(truth["states"], dtype=np.float64), origins
    )
    result: dict[str, Any] = {
        "origins": origin_array,
        "forecasts": forecast_matrix,
        "clean_targets": clean_targets,
        "observed_targets": observed_targets,
        "origin_states": state_array,
        "standardized_state_error": state_metrics["standardized_error"],
        "complete_state_error_by_origin": state_metrics["complete_error_by_origin"],
        "complete_state_rmse": float(state_metrics["complete_rmse"]),
        "per_state_rmse": np.asarray(state_metrics["per_state_rmse"]),
    }
    if bool(specification["state_update"]):
        prior_array = torch.stack(priors).detach().cpu().numpy()
        prior_matrix = np.column_stack(
            [
                torch.stack(prior_forecasts[lead]).detach().cpu().numpy()
                for lead in common.LEADS
            ]
        )
        prior_metrics = common.state_error_metrics(
            prior_array, np.asarray(truth["states"], dtype=np.float64), origins
        )
        result.update(
            {
                "prior_origin_states": prior_array,
                "prior_standardized_state_error": prior_metrics[
                    "standardized_error"
                ],
                "prior_complete_state_error_by_origin": prior_metrics[
                    "complete_error_by_origin"
                ],
                "prior_origin_covariances": torch.stack(prior_covariances)
                .detach()
                .cpu()
                .numpy(),
                "posterior_origin_covariances": torch.stack(posterior_covariances)
                .detach()
                .cpu()
                .numpy(),
                "prior_counterfactual_forecasts": prior_matrix,
                "prior_counterfactual_clean_squared_error": np.square(
                    prior_matrix - clean_targets
                ),
                "posterior_counterfactual_clean_squared_error": np.square(
                    forecast_matrix - clean_targets
                ),
                "prior_complete_state_rmse": float(prior_metrics["complete_rmse"]),
                "prior_per_state_rmse": np.asarray(
                    prior_metrics["per_state_rmse"]
                ),
            }
        )
    return result


def _recomputed_row(
    truth_seed: int,
    start_id: str,
    readout_id: str,
    reconstructed: Mapping[str, Any],
    contract: Mapping[str, Any],
) -> dict[str, Any]:
    clean_error = np.square(
        reconstructed["forecasts"] - reconstructed["clean_targets"]
    )
    observed_error = np.square(
        reconstructed["forecasts"] - reconstructed["observed_targets"]
    )
    clean_by_lead = {
        str(lead): float(np.mean(clean_error[:, index]))
        for index, lead in enumerate(common.LEADS)
    }
    observed_by_lead = {
        str(lead): float(np.mean(observed_error[:, index]))
        for index, lead in enumerate(common.LEADS)
    }
    specification = contract["readout_grid"][readout_id]
    row: dict[str, Any] = {
        "truth_seed": truth_seed,
        "start_id": start_id,
        "readout_id": readout_id,
        "parameter_set": specification["parameter_set"],
        "state_update": bool(specification["state_update"]),
        "primary_pipeline": bool(specification["primary_pipeline"]),
        "primary_clean_mse": float(np.mean(list(clean_by_lead.values()))),
        "primary_clean_mse_by_lead": clean_by_lead,
        "secondary_observed_mse": float(np.mean(list(observed_by_lead.values()))),
        "secondary_observed_mse_by_lead": observed_by_lead,
        "primary_clean_error_count": int(clean_error.size),
        "complete_state_rmse": float(reconstructed["complete_state_rmse"]),
        "per_state_rmse": np.asarray(reconstructed["per_state_rmse"]).tolist(),
        "online_parameter_update_count": 0,
        "released_observation_count": (
            max(common.origin_indices(contract, "test")) + 1
            if bool(specification["state_update"])
            else 0
        ),
    }
    if bool(specification["state_update"]):
        prior_complete = float(reconstructed["prior_complete_state_rmse"])
        posterior_per_state = np.asarray(reconstructed["per_state_rmse"])
        prior_per_state = np.asarray(reconstructed["prior_per_state_rmse"])
        prior_error = np.asarray(
            reconstructed["prior_counterfactual_clean_squared_error"]
        )
        posterior_error = np.asarray(
            reconstructed["posterior_counterfactual_clean_squared_error"]
        )
        row.update(
            {
                "prior_complete_state_rmse": prior_complete,
                "prior_per_state_rmse": prior_per_state.tolist(),
                "posterior_over_prior_complete_state_rmse": (
                    float(reconstructed["complete_state_rmse"] / prior_complete)
                    if prior_complete > 0.0
                    else None
                ),
                "posterior_over_prior_per_state_rmse": [
                    float(posterior / prior) if prior > 0.0 else None
                    for posterior, prior in zip(
                        posterior_per_state, prior_per_state
                    )
                ],
                "single_update_clean_mse_prior_by_lead": {
                    str(lead): float(np.mean(prior_error[:, index]))
                    for index, lead in enumerate(common.LEADS)
                },
                "single_update_clean_mse_posterior_by_lead": {
                    str(lead): float(np.mean(posterior_error[:, index]))
                    for index, lead in enumerate(common.LEADS)
                },
            }
        )
    return row


def _classify_local(ratios: Sequence[float], contract: Mapping[str, Any]) -> str:
    values = np.asarray(ratios, dtype=np.float64)
    median = float(np.median(values))
    wins = int(np.count_nonzero(values < 1.0))
    losses = int(np.count_nonzero(values > 1.0))
    minimum = int(contract["gates"]["minimum_direction_count"])
    if median <= float(contract["gates"]["clear_benefit_median_ratio_maximum"]) and wins >= minimum:
        return "CLEAR_BENEFIT"
    if median >= float(contract["gates"]["clear_harm_median_ratio_minimum"]) and losses >= minimum:
        return "CLEAR_HARM"
    if (
        float(contract["gates"]["clear_benefit_median_ratio_maximum"])
        < median
        < float(contract["gates"]["clear_harm_median_ratio_minimum"])
        and (wins >= minimum or losses >= minimum)
    ):
        return "DIRECTIONAL_SMALL"
    return "MIXED_OR_INCONCLUSIVE"


def _binomial_tail_local(successes: int, trials: int) -> Fraction:
    return Fraction(
        sum(math.comb(trials, value) for value in range(successes, trials + 1)),
        2**trials,
    )


def _binomial_cdf_local(successes: int, trials: int, probability: float) -> float:
    return sum(
        math.comb(trials, value)
        * probability**value
        * (1.0 - probability) ** (trials - value)
        for value in range(successes + 1)
    )


def _clopper_pearson_local(
    successes: int, trials: int, alpha: float
) -> list[float]:
    if successes == 0:
        lower = 0.0
    else:
        lo, hi = 0.0, 1.0
        for _ in range(100):
            mid = 0.5 * (lo + hi)
            upper_tail = 1.0 - _binomial_cdf_local(
                successes - 1, trials, mid
            )
            if upper_tail < alpha / 2.0:
                lo = mid
            else:
                hi = mid
        lower = 0.5 * (lo + hi)
    if successes == trials:
        upper = 1.0
    else:
        lo, hi = 0.0, 1.0
        for _ in range(100):
            mid = 0.5 * (lo + hi)
            lower_tail = _binomial_cdf_local(successes, trials, mid)
            if lower_tail > alpha / 2.0:
                lo = mid
            else:
                hi = mid
        upper = 0.5 * (lo + hi)
    return [lower, upper]


def independently_aggregate(
    rows: Sequence[Mapping[str, Any]], contract: Mapping[str, Any]
) -> dict[str, Any]:
    indexed = {
        (int(row["truth_seed"]), str(row["start_id"]), str(row["readout_id"])): row
        for row in rows
    }
    if len(indexed) != 162 or len(rows) != 162:
        raise ValueError("independent aggregate requires 162 unique readout rows")
    pairs = sorted({(seed, start) for seed, start, _ in indexed})
    if (
        len(pairs) != 27
        or len({seed for seed, _ in pairs}) != 27
        or {start for _, start in pairs} != set(common.START_IDS)
    ):
        raise ValueError("independent aggregate requires 27 independent pairs")
    expected = {
        (seed, start, readout)
        for seed, start in pairs
        for readout in common.READOUT_ORDER
    }
    if set(indexed) != expected:
        raise ValueError("independent aggregate readout grid is incomplete")
    alpha = float(contract["gates"]["sign_test_one_sided_alpha"])

    def contrasts(specifications: Mapping[str, Any]) -> dict[str, Any]:
        result = {}
        for name, specification in specifications.items():
            numerator = str(specification["numerator"])
            denominator = str(specification["denominator"])
            ratios: list[float] = []
            per_pair: list[dict[str, Any]] = []
            for seed, start in pairs:
                top = float(indexed[(seed, start, numerator)]["primary_clean_mse"])
                bottom = float(indexed[(seed, start, denominator)]["primary_clean_mse"])
                if not (
                    math.isfinite(top)
                    and math.isfinite(bottom)
                    and top > 0.0
                    and bottom > 0.0
                ):
                    raise ValueError("independent aggregate found an invalid clean error")
                ratio = top / bottom
                ratios.append(ratio)
                per_pair.append(
                    {"truth_seed": seed, "start_id": start, "ratio": ratio}
                )
            values = np.asarray(ratios, dtype=np.float64)
            wins = int(np.count_nonzero(values < 1.0))
            losses = int(np.count_nonzero(values > 1.0))
            win_tail = _binomial_tail_local(wins, len(ratios))
            loss_tail = _binomial_tail_local(losses, len(ratios))
            by_lead: dict[str, Any] = {}
            for lead in common.LEADS:
                lead_ratios = [
                    float(
                        indexed[(seed, start, numerator)][
                            "primary_clean_mse_by_lead"
                        ][str(lead)]
                    )
                    / float(
                        indexed[(seed, start, denominator)][
                            "primary_clean_mse_by_lead"
                        ][str(lead)]
                    )
                    for seed, start in pairs
                ]
                by_lead[str(lead)] = {
                    "median_ratio": float(np.median(lead_ratios)),
                    "ratio_range": [min(lead_ratios), max(lead_ratios)],
                    "wins_below_one": int(
                        np.count_nonzero(np.asarray(lead_ratios) < 1.0)
                    ),
                    "ratios": lead_ratios,
                }
            result[name] = {
                "numerator": numerator,
                "denominator": denominator,
                "per_pair_ratios": per_pair,
                "ratios": ratios,
                "median_ratio": float(np.median(ratios)),
                "ratio_range": [min(ratios), max(ratios)],
                "wins_below_one": wins,
                "losses_above_one": losses,
                "ties_at_one": len(ratios) - wins - losses,
                "win_fraction_exact_95_percent_interval": _clopper_pearson_local(
                    wins, len(ratios), alpha
                ),
                "benefit_sign_test_one_sided_p": float(win_tail),
                "benefit_sign_test_fraction": [
                    win_tail.numerator,
                    win_tail.denominator,
                ],
                "harm_sign_test_one_sided_p": float(loss_tail),
                "harm_sign_test_fraction": [
                    loss_tail.numerator,
                    loss_tail.denominator,
                ],
                "classification": _classify_local(ratios, contract),
                "by_lead": by_lead,
            }
        return result

    primary = contrasts(contract["primary_contrasts"])
    crossed = contrasts(contract["fixed_parameter_state_contrasts"])
    interaction_values: list[float] = []
    interaction_rows: list[dict[str, Any]] = []
    for seed, start in pairs:
        value = {
            readout: float(indexed[(seed, start, readout)]["primary_clean_mse"])
            for readout in common.PIPELINE_ORDER
        }
        ratio = (
            value["state_and_hydrology_update"] * value["no_update"]
        ) / (value["state_update_only"] * value["hydrology_update_only"])
        interaction_values.append(ratio)
        interaction_rows.append(
            {
                "truth_seed": seed,
                "start_id": start,
                "interaction_ratio": ratio,
                "log_interaction_ratio": math.log(ratio),
            }
        )
    interaction_array = np.asarray(interaction_values, dtype=np.float64)
    below = int(np.count_nonzero(interaction_array < 1.0))
    above = int(np.count_nonzero(interaction_array > 1.0))
    interaction = {
        "per_pair": interaction_rows,
        "median_ratio": float(np.median(interaction_values)),
        "ratio_range": [min(interaction_values), max(interaction_values)],
        "below_one_count": below,
        "above_one_count": above,
        "ties_at_one": len(interaction_values) - below - above,
        "below_one_fraction_exact_95_percent_interval": _clopper_pearson_local(
            below, len(interaction_values), alpha
        ),
        "above_one_fraction_exact_95_percent_interval": _clopper_pearson_local(
            above, len(interaction_values), alpha
        ),
    }
    state_classes = [
        crossed[name]["classification"]
        for name in (
            "initial_parameters",
            "openloop_trained_parameters",
            "state_trained_parameters",
        )
    ]
    parameter_classes = [
        primary["hydrology_update_only_over_no_update"]["classification"],
        primary["state_and_hydrology_update_over_state_update_only"]["classification"],
    ]
    state_label = (
        "CLEAR_BENEFIT_ACROSS_ALL_PARAMETER_SETS"
        if all(value == "CLEAR_BENEFIT" for value in state_classes)
        else "PARAMETER_SET_DEPENDENT"
        if len(set(state_classes)) > 1
        else state_classes[0]
    )
    parameter_label = (
        "CLEAR_BENEFIT_WITH_AND_WITHOUT_STATE_UPDATE"
        if all(value == "CLEAR_BENEFIT" for value in parameter_classes)
        else "CONTEXT_DEPENDENT"
        if len(set(parameter_classes)) > 1
        else parameter_classes[0]
    )
    primary_payload = {
        "independent_unit": "unique_truth_seed_and_registered_start_pair",
        "independent_unit_count": len(pairs),
        "contrasts": primary,
        "interaction": interaction,
    }
    mechanisms = {
        "test_period_state_update": state_label,
        "hydrology_parameter_learning_pipeline": parameter_label,
        "state_update_fixed_parameter_classes": state_classes,
        "hydrology_learning_context_classes": parameter_classes,
        "interaction_is_descriptive_not_causal": True,
    }
    return {
        "primary": primary,
        "primary_payload": primary_payload,
        "crossed": crossed,
        "interaction": interaction,
        "interaction_median_ratio": interaction["median_ratio"],
        "interaction_below_one_count": interaction["below_one_count"],
        "state_mechanism": state_label,
        "parameter_mechanism": parameter_label,
        "mechanism_classifications": mechanisms,
    }


def _aggregate_matches_registry(
    independent: Mapping[str, Any], registry: Mapping[str, Any]
) -> bool:
    return (
        _values_close(
            independent["primary_payload"], registry["aggregates"]["primary"]
        )
        and _values_close(
            independent["crossed"], registry["aggregates"]["crossed"]
        )
        and _values_close(
            independent["mechanism_classifications"],
            registry["mechanism_classifications"],
        )
    )


def verify_formal(
    contract: Mapping[str, Any], *, contract_path: Path = DEFAULT_CONFIG
) -> dict[str, Any]:
    common.validate_contract(contract)
    root = common.resolve_output_path(contract, contract["outputs"]["result_root"])
    preflight_root = common.resolve_output_path(
        contract, contract["outputs"]["preflight_root"]
    )
    preflight_verification = common.read_json(
        preflight_root / "independent_verification.json"
    )
    if preflight_verification.get("status") != "PREFLIGHT_VERIFIED":
        raise PermissionError("formal verification requires verified passing preflight")
    registry = common.read_json(root / "registry.json")
    seal = common.read_json(root / "selection_seal.json")
    manifest = common.read_json(root / "manifest.json")
    seed_registry = common.read_json(preflight_root / "seed_registry.json")
    pairs = common.registered_pairs(contract, seed_registry)
    expected_sources = _source_hashes(contract, contract_path)

    expected_cell_identities = {
        (seed, start_id, method)
        for seed, start_id in pairs
        for method in common.PIPELINE_ORDER
    }
    seal_cells = list(seal.get("cells", ()))
    actual_cell_identities = {
        (int(cell["truth_seed"]), str(cell["start_id"]), str(cell["method"]))
        for cell in seal_cells
    }
    selection_ok = (
        len(seal_cells) == 108
        and actual_cell_identities == expected_cell_identities
    )
    checkpoint_index: dict[tuple[int, str, str], dict[str, np.ndarray]] = {}
    for cell in seal_cells:
        seed = int(cell["truth_seed"])
        start_id = str(cell["start_id"])
        method = str(cell["method"])
        method_root = root / "repetitions" / f"truth_{seed}__{start_id}" / "methods" / method
        history = common.read_json(method_root / "history.json")
        selected = independently_select_checkpoint(history["selection_rows"])
        checkpoint_path = root / str(cell["checkpoint_path"])
        snapshot = _load_npz(checkpoint_path)
        checkpoint_index[(seed, start_id, method)] = snapshot
        query_snapshots: dict[int, dict[str, np.ndarray]] = {}
        for query in history["selection_rows"]:
            update = int(query["update"])
            query_path = method_root / str(query["checkpoint_file"])
            query_snapshot = _load_npz(query_path)
            query_snapshots[update] = query_snapshot
            selection_ok = selection_ok and (
                common.sha256_file(query_path) == query["checkpoint_file_sha256"]
                and _snapshot_hash(query_snapshot) == query["snapshot_sha256"]
            )
        selected_query_snapshot = query_snapshots[int(selected["update"])]
        same_selected_arrays = set(snapshot) == set(selected_query_snapshot) and all(
            _arrays_close(snapshot[name], selected_query_snapshot[name])
            for name in snapshot
        )
        initial_model = common.build_model(contract, start_id)
        initial_snapshot = common.snapshot_model(initial_model)
        frozen_keys = (
            "log_process",
            "log_observation",
            "process_diagonal",
            "observation_ratio",
            "lag_time",
            "state_dimension",
        )
        frozen_values_ok = all(
            name in snapshot
            and name in initial_snapshot
            and np.array_equal(snapshot[name], initial_snapshot[name])
            for name in frozen_keys
        )
        learns = bool(contract["pipeline_masks"][method]["learn_hydrology"])
        selection_ok = selection_ok and (
            selected == {
                "update": int(cell["selected_update"]),
                "selection_loss": float(cell["selected_selection_loss"]),
            }
            and _values_close(history["selected"], selected)
            and history["method"] == method
            and common.sha256_file(checkpoint_path) == cell["checkpoint_file_sha256"]
            and common.sha256_file(checkpoint_path)
            == history["checkpoint_file_sha256"]
            and _snapshot_hash(snapshot) == cell["selected_snapshot_sha256"]
            and _snapshot_hash(snapshot) == history["selected_snapshot_sha256"]
            and same_selected_arrays
            and frozen_values_ok
            and int(history["optimizer_step_count"]) == (96 if learns else 0)
            and int(history["selection_query_count"]) == (25 if learns else 1)
            and int(history["maximum_observation_index_supplied"]) == 147
            and int(history["test_observation_input_count"]) == 0
            and int(history["clean_target_query_count"]) == 0
        )

    raw_arrays_ok = True
    metric_rows_ok = True
    pair_metric_files_ok = True
    reconstructed_rows: list[dict[str, Any]] = []
    state_counterfactual_count = 0
    registry_rows = list(registry.get("rows", ()))
    registry_row_index = {
        (int(row["truth_seed"]), str(row["start_id"]), str(row["readout_id"])): row
        for row in registry_rows
    }
    metric_rows_ok = metric_rows_ok and (
        len(registry_rows) == 162 and len(registry_row_index) == 162
    )
    for seed, start_id in pairs:
        forcing, truth = common.generate_truth_for_seed(contract, seed)
        pair_root = root / "repetitions" / f"truth_{seed}__{start_id}"
        stored_truth = _load_npz(pair_root / "truth_arrays.npz")
        expected_truth = {
            name: value for name, value in truth.items() if isinstance(value, np.ndarray)
        }
        raw_arrays_ok = raw_arrays_ok and set(stored_truth) == set(expected_truth)
        raw_arrays_ok = raw_arrays_ok and all(
            name in stored_truth
            and _arrays_close(stored_truth[name], expected_truth[name])
            for name in expected_truth
        )
        pair_rows: list[dict[str, Any]] = []
        for readout_id in common.READOUT_ORDER:
            specification = contract["readout_grid"][readout_id]
            source_method = str(specification["parameter_source_pipeline"])
            snapshot = checkpoint_index[(seed, start_id, source_method)]
            model = common.build_model(contract, start_id)
            common.restore_model_(model, snapshot)
            reconstructed = _stream_reconstruct(
                contract, model, readout_id, forcing, truth
            )
            readout_root = pair_root / "readouts" / readout_id
            arrays_path = readout_root / "arrays.npz"
            stored_arrays = _load_npz(arrays_path)
            expected_array_names = {
                "origins",
                "forecasts",
                "clean_targets",
                "observed_targets",
                "origin_states",
                "standardized_state_error",
                "complete_state_error_by_origin",
            }
            if bool(specification["state_update"]):
                expected_array_names.update(
                    {
                        "prior_origin_states",
                        "prior_standardized_state_error",
                        "prior_complete_state_error_by_origin",
                        "prior_origin_covariances",
                        "posterior_origin_covariances",
                        "prior_counterfactual_forecasts",
                        "prior_counterfactual_clean_squared_error",
                        "posterior_counterfactual_clean_squared_error",
                    }
                )
            raw_arrays_ok = raw_arrays_ok and set(stored_arrays) == expected_array_names
            raw_arrays_ok = raw_arrays_ok and all(
                name in stored_arrays
                and name in reconstructed
                and _arrays_close(stored_arrays[name], reconstructed[name])
                for name in expected_array_names
            )
            stored_metrics = common.read_json(readout_root / "metrics.json")
            row = _recomputed_row(
                seed, start_id, readout_id, reconstructed, contract
            )
            reconstructed_rows.append(row)
            expected_metric_file = {
                **row,
                "arrays_sha256": common.sha256_file(arrays_path),
                "parameter_snapshot_sha256": _snapshot_hash(snapshot),
            }
            metric_rows_ok = metric_rows_ok and _values_close(
                stored_metrics, expected_metric_file
            )
            metric_rows_ok = metric_rows_ok and _values_close(
                registry_row_index.get((seed, start_id, readout_id)),
                expected_metric_file,
            )
            pair_rows.append(expected_metric_file)
            if bool(specification["state_update"]):
                state_counterfactual_count += 1
        stored_pair_metrics = common.read_json(pair_root / "pair_metrics.json")
        pair_metric_files_ok = pair_metric_files_ok and _values_close(
            stored_pair_metrics,
            {
                "schema_version": "tukf17_pair_metrics_v1",
                "truth_seed": seed,
                "start_id": start_id,
                "readouts": pair_rows,
            },
        )

    independent_aggregate = independently_aggregate(reconstructed_rows, contract)
    checks = {
        "configuration_identity": common.sha256_file(contract_path)
        == common.sha256_file(DEFAULT_CONFIG),
        "source_identity": seal.get("source_sha256") == expected_sources
        and registry.get("source_sha256_start") == expected_sources
        and registry.get("source_sha256_end") == expected_sources,
        "seed_and_start_identity": len(pairs) == 27
        and len({seed for seed, _ in pairs}) == 27,
        "all_budget_selections_recomputed": selection_ok
        and len(checkpoint_index) == 108,
        "selection_seal": int(seal.get("test_observation_inputs_before_seal", -1))
        == 0
        and int(seal.get("clean_target_queries_before_seal", -1)) == 0,
        "truth_and_readout_raw_arrays_recomputed": raw_arrays_ok,
        "all_test_metrics_recomputed": metric_rows_ok
        and pair_metric_files_ok
        and len(reconstructed_rows) == 162,
        "single_update_counterfactuals_recomputed": state_counterfactual_count == 81,
        "paired_aggregates_recomputed": _aggregate_matches_registry(
            independent_aggregate, registry
        ),
        "manifest_hashes": _verify_manifest(root, manifest),
        "registry_and_selection_seal_identity": registry.get(
            "selection_seal_sha256"
        )
        == common.sha256_file(root / "selection_seal.json"),
        "formal_complete": registry.get("status")
        == "FORMAL_COMPLETE_AWAITING_INDEPENDENT_VERIFICATION",
    }
    report = {
        "schema_version": "tukf17_formal_independent_verification_v1",
        "experiment_id": common.EXPERIMENT_ID,
        "status": "FORMAL_VERIFIED" if all(checks.values()) else "FORMAL_VERIFICATION_FAILED",
        "checks": checks,
        "recomputed_test_readout_count": len(reconstructed_rows),
        "recomputed_state_update_counterfactual_count": state_counterfactual_count,
        "recomputed_primary_clean_error_count": len(reconstructed_rows) * 126,
        "independent_aggregate": independent_aggregate,
    }
    common.write_new_json(root / "independent_verification.json", report)
    return report


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("preflight", "formal"), required=True)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    contract_path = args.config.resolve()
    contract = common.load_contract(contract_path)
    report = (
        verify_preflight(contract, contract_path=contract_path)
        if args.stage == "preflight"
        else verify_formal(contract, contract_path=contract_path)
    )
    print(
        json.dumps(
            {"status": report["status"], "checks": report["checks"]},
            ensure_ascii=False,
            sort_keys=True,
            allow_nan=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
