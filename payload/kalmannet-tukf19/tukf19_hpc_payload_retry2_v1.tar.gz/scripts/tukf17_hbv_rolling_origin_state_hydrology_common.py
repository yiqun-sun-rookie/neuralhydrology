"""Frozen primitives for the rolling-origin state/hydrology comparison.

The predecessor experiment files are deliberately loaded from the original
repository as read-only, SHA-256-pinned inputs.  This module owns every new
TUKF17 contract, causal-origin, pairing, and classification rule, but performs
no experiment at import time.
"""
from __future__ import annotations

from collections.abc import Mapping, Sequence
import copy
from fractions import Fraction
import hashlib
import importlib
import json
import math
from pathlib import Path
import sys
from typing import Any

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = (
    ROOT / "configs" / "tukf17_hbv_rolling_origin_state_hydrology_update_v1.json"
)
DEFAULT_READONLY_PREDECESSOR_ROOT = Path(
    "G:/github/pycharm/projects/kalmannet"
).resolve()
EXPERIMENT_ID = "TUKF17_HBV_ROLLING_ORIGIN_STATE_HYDROLOGY_UPDATE_V1"
SCHEMA_VERSION = "tukf17_hbv_rolling_origin_state_hydrology_update_v1"
PIPELINE_ORDER = (
    "no_update",
    "state_update_only",
    "hydrology_update_only",
    "state_and_hydrology_update",
)
READOUT_ORDER = (
    "no_update",
    "state_update_only",
    "hydrology_update_only",
    "openloop_trained_parameters_with_state_update",
    "state_trained_parameters_without_state_update",
    "state_and_hydrology_update",
)
LEADS = (1, 2, 3)
ORIGIN_WINDOWS = {
    "train": tuple(range(27, 105)),
    "selection": tuple(range(107, 145)),
    "test": tuple(range(147, 189)),
}
START_IDS = tuple(f"start_{index:02d}" for index in range(3, 30))
STATE_SCALES = np.asarray(
    [8.0, 1.0, 180.0, 25.0, 50.0, 1.0, 1.0, 1.0], dtype=np.float64
)
PROCESS_FRACTION = 0.02
FILTER_FACTOR = 8.0
HYDROLOGY_DISTANCE = 0.04
PROCESS_NOISE_BOUNDS = (1e-6, 200.0)
OBSERVATION_RATIO_BOUNDS = (0.0025, 0.8)
CLAIMS_NOT_AUTHORIZED = (
    "hydrologic parameter identifiability",
    "recovery from an erroneous initial state",
    "online test-period parameter learning",
    "real-catchment forecast validity",
    "forecast value under forcing forecast error",
    "causal transfer of error between state components",
    "replacement of any sealed predecessor verdict",
    "scientific success from technical verification alone",
)
EXPECTED_PARENT_CONFIGS = {
    "truth_generator": "configs/tukf11_hbv_joint_parameter_synthetic_mechanism_gate_v1.json",
    "start_registry": "configs/tukf14_hbv_four_mode_randomised_start_ablation_v1.json",
    "balanced_design": "configs/tukf16_hbv_balanced_error_four_mode_rerun_v1.json",
}
EXPECTED_OUTPUTS = {
    "preflight_root": "artifacts/tukf17_hbv_rolling_origin_state_hydrology_update_v1/preflight",
    "result_root": "results/tukf17_hbv_rolling_origin_state_hydrology_update_v1",
    "failed_result_root": "results/tukf17_hbv_rolling_origin_state_hydrology_update_v1_failed_attempts",
    "figure_root": "artifacts/tukf17_hbv_rolling_origin_state_hydrology_update_v1/formal_verified_summary_v1",
}
EXPECTED_READONLY_INPUTS = {
    "configs/tukf11_hbv_joint_parameter_synthetic_mechanism_gate_v1.json",
    "configs/tukf14_hbv_four_mode_randomised_start_ablation_v1.json",
    "configs/tukf16_hbv_balanced_error_four_mode_rerun_v1.json",
    "scripts/tukf11_hbv_joint_parameter_synthetic_common.py",
    "scripts/run_tukf11_hbv_joint_parameter_synthetic_mechanism_gate.py",
    "scripts/differentiable_ukf_hbvlite.py",
    "scripts/tukf10_joint_hbv_physical_filter_common.py",
    "src/global_hydrology/models/trainable_hbvlite_ukf_adapter.py",
    "src/global_hydrology/models/differentiable_hbv_lite.py",
    "scripts/run_aligned_gr4j_da.py",
    "scripts/run_aligned_gr4j_differentiable_ukf.py",
    "src/global_hydrology/assimilation/conventional_ukf.py",
    "G:/github/pycharm/projects/neuralhydrology/src/scl_hydro/hbv_lite_numpy.py",
}


def read_json(path: Path | str) -> dict[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected a JSON object: {path}")
    return value


def jsonable(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(item) for item in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().numpy().tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("refusing to serialize a non-finite float")
    return value


def write_new_json(path: Path | str, payload: Mapping[str, Any]) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(
        jsonable(payload),
        indent=2,
        sort_keys=True,
        ensure_ascii=False,
        allow_nan=False,
    ) + "\n"
    with target.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def write_new_npz(path: Path | str, arrays: Mapping[str, Any]) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as handle:
        np.savez_compressed(
            handle, **{str(key): np.asarray(value) for key, value in arrays.items()}
        )


def sha256_file(path: Path | str) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_arrays(arrays: Mapping[str, Any]) -> str:
    digest = hashlib.sha256()
    for name in sorted(arrays):
        value = np.ascontiguousarray(np.asarray(arrays[name]))
        digest.update(str(name).encode("utf-8"))
        digest.update(str(value.dtype).encode("ascii"))
        digest.update(np.asarray(value.shape, dtype=np.int64).tobytes())
        digest.update(value.tobytes())
    return digest.hexdigest()


def copy_snapshot(snapshot: Mapping[str, Any]) -> dict[str, Any]:
    return {
        str(key): np.asarray(value).copy()
        if isinstance(value, (np.ndarray, np.generic))
        else copy.deepcopy(value)
        for key, value in snapshot.items()
    }


def predecessor_root(contract: Mapping[str, Any]) -> Path:
    raw = contract.get("readonly_predecessor_root", DEFAULT_READONLY_PREDECESSOR_ROOT)
    root = Path(str(raw)).resolve()
    if root == ROOT.resolve():
        raise ValueError("the writable worktree cannot be its own predecessor root")
    if not root.is_dir():
        raise FileNotFoundError(f"read-only predecessor root is missing: {root}")
    return root


def resolve_readonly_input(contract: Mapping[str, Any], raw: Path | str) -> Path:
    value = Path(str(raw))
    return value.resolve() if value.is_absolute() else (predecessor_root(contract) / value).resolve()


def resolve_output_path(contract: Mapping[str, Any], raw: Path | str) -> Path:
    value = Path(str(raw))
    if value.is_absolute():
        raise ValueError("TUKF17 outputs must be worktree-relative")
    candidate = (ROOT / value).resolve()
    try:
        candidate.relative_to(ROOT.resolve())
    except ValueError as error:
        raise ValueError(f"output path escapes the independent worktree: {candidate}") from error
    return candidate


def _activate_predecessor_imports(contract: Mapping[str, Any]) -> Path:
    root = predecessor_root(contract)
    for value in (root, root / "src"):
        text = str(value)
        if text in sys.path:
            sys.path.remove(text)
        sys.path.insert(0, text)
    return root


def predecessor_modules(contract: Mapping[str, Any]) -> dict[str, Any]:
    _activate_predecessor_imports(contract)
    return {
        "truth_common": importlib.import_module(
            "scripts.tukf11_hbv_joint_parameter_synthetic_common"
        ),
        "truth_runner": importlib.import_module(
            "scripts.run_tukf11_hbv_joint_parameter_synthetic_mechanism_gate"
        ),
        "adapter": importlib.import_module(
            "global_hydrology.models.trainable_hbvlite_ukf_adapter"
        ),
        "ukf": importlib.import_module("scripts.differentiable_ukf_hbvlite"),
    }


def _predecessor_contract_for_model(model) -> dict[str, str]:
    root = getattr(
        model,
        "_tukf17_readonly_predecessor_root",
        DEFAULT_READONLY_PREDECESSOR_ROOT,
    )
    return {"readonly_predecessor_root": str(root)}


def _expected_pipeline_masks() -> dict[str, dict[str, Any]]:
    return {
        "no_update": {
            "state_update": False,
            "learn_hydrology": False,
            "parameter_set": "initial_parameters",
        },
        "state_update_only": {
            "state_update": True,
            "learn_hydrology": False,
            "parameter_set": "initial_parameters",
        },
        "hydrology_update_only": {
            "state_update": False,
            "learn_hydrology": True,
            "parameter_set": "openloop_trained_parameters",
        },
        "state_and_hydrology_update": {
            "state_update": True,
            "learn_hydrology": True,
            "parameter_set": "state_trained_parameters",
        },
    }


def _expected_readout_grid() -> dict[str, dict[str, Any]]:
    return {
        "no_update": {
            "parameter_source_pipeline": "no_update",
            "parameter_set": "initial_parameters",
            "state_update": False,
            "primary_pipeline": True,
        },
        "state_update_only": {
            "parameter_source_pipeline": "state_update_only",
            "parameter_set": "initial_parameters",
            "state_update": True,
            "primary_pipeline": True,
        },
        "hydrology_update_only": {
            "parameter_source_pipeline": "hydrology_update_only",
            "parameter_set": "openloop_trained_parameters",
            "state_update": False,
            "primary_pipeline": True,
        },
        "openloop_trained_parameters_with_state_update": {
            "parameter_source_pipeline": "hydrology_update_only",
            "parameter_set": "openloop_trained_parameters",
            "state_update": True,
            "primary_pipeline": False,
        },
        "state_trained_parameters_without_state_update": {
            "parameter_source_pipeline": "state_and_hydrology_update",
            "parameter_set": "state_trained_parameters",
            "state_update": False,
            "primary_pipeline": False,
        },
        "state_and_hydrology_update": {
            "parameter_source_pipeline": "state_and_hydrology_update",
            "parameter_set": "state_trained_parameters",
            "state_update": True,
            "primary_pipeline": True,
        },
    }


def validate_contract(
    contract: Mapping[str, Any], *, verify_files: bool = True
) -> dict[str, Any]:
    if contract.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("unexpected TUKF17 schema version")
    if contract.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("unexpected TUKF17 experiment identifier")
    if contract.get("status") != "DESIGN_REVIEWED_EXECUTION_NOT_STARTED":
        raise ValueError("TUKF17 design status changed")
    authorization = contract.get("authorization", {})
    if not bool(authorization.get("implementation_authorized")):
        raise PermissionError("TUKF17 implementation is not authorized")
    if bool(authorization.get("formal_training_authorized_at_config_freeze")):
        raise PermissionError("formal training must remain separately authorized")
    if not bool(authorization.get("formal_training_requires_separate_user_confirmation")):
        raise PermissionError("formal training confirmation guard is missing")
    if contract.get("parent_configs") != EXPECTED_PARENT_CONFIGS:
        raise ValueError("predecessor configuration paths changed")
    if set(contract.get("readonly_input_sha256", {})) != EXPECTED_READONLY_INPUTS:
        raise ValueError("read-only input closure changed")

    if tuple(contract.get("pipeline_order", ())) != PIPELINE_ORDER:
        raise ValueError("primary pipeline order changed")
    if contract.get("pipeline_masks") != _expected_pipeline_masks():
        raise ValueError("primary pipeline factors changed")
    if tuple(contract.get("readout_order", ())) != READOUT_ORDER:
        raise ValueError("test readout order changed")
    if contract.get("readout_grid") != _expected_readout_grid():
        raise ValueError("crossed test readout grid changed")
    expected_primary_contrasts = {
        "state_update_only_over_no_update": {
            "numerator": "state_update_only",
            "denominator": "no_update",
        },
        "state_and_hydrology_update_over_hydrology_update_only": {
            "numerator": "state_and_hydrology_update",
            "denominator": "hydrology_update_only",
        },
        "hydrology_update_only_over_no_update": {
            "numerator": "hydrology_update_only",
            "denominator": "no_update",
        },
        "state_and_hydrology_update_over_state_update_only": {
            "numerator": "state_and_hydrology_update",
            "denominator": "state_update_only",
        },
    }
    if contract.get("primary_contrasts") != expected_primary_contrasts:
        raise ValueError("primary contrast definitions changed")
    expected_fixed_contrasts = {
        "initial_parameters": {
            "numerator": "state_update_only",
            "denominator": "no_update",
        },
        "openloop_trained_parameters": {
            "numerator": "openloop_trained_parameters_with_state_update",
            "denominator": "hydrology_update_only",
        },
        "state_trained_parameters": {
            "numerator": "state_and_hydrology_update",
            "denominator": "state_trained_parameters_without_state_update",
        },
    }
    if contract.get("fixed_parameter_state_contrasts") != expected_fixed_contrasts:
        raise ValueError("fixed-parameter state contrast definitions changed")

    design = contract.get("balanced_error_design", {})
    expected_design = {
        "process_standard_deviation_fraction": PROCESS_FRACTION,
        "filter_perturbation_factor": FILTER_FACTOR,
        "filter_perturbation_low_multiplier": 1.0 / FILTER_FACTOR,
        "filter_perturbation_high_multiplier": FILTER_FACTOR,
        "hydrology_coordinate_distance": HYDROLOGY_DISTANCE,
        "influence_ratio_interval": [1.0 / 3.0, 3.0],
    }
    if design != expected_design:
        raise ValueError("balanced error design changed")

    origins = contract.get("origins", {})
    for name, expected in ORIGIN_WINDOWS.items():
        row = origins.get(name, {})
        actual = tuple(range(int(row.get("start", -1)), int(row.get("end_inclusive", -2)) + 1))
        if actual != expected or int(row.get("count", -1)) != len(expected):
            raise ValueError(f"{name} origin window changed")
    objective = contract.get("objective", {})
    if tuple(objective.get("leads_days", ())) != LEADS:
        raise ValueError("forecast leads changed")
    if not bool(objective.get("shared_origins_for_all_leads")):
        raise ValueError("all leads must share each origin set")
    if objective.get("primary_test_target") != "clean_discharge":
        raise ValueError("clean discharge must remain the primary test target")
    if objective.get("training_and_selection_target") != "noisy_discharge_observation":
        raise ValueError("training and selection target changed")
    if objective.get("secondary_test_target") != "noisy_discharge_observation":
        raise ValueError("secondary compatibility target changed")
    if tuple(float(value) for value in objective.get("lead_weights", ())) != (
        1.0 / 3.0,
        1.0 / 3.0,
        1.0 / 3.0,
    ):
        raise ValueError("forecast lead weights changed")
    if objective.get("origin_state_alignment") != (
        "state_after_processing_origin_day_equals_truth_states_origin_plus_one"
    ):
        raise ValueError("origin-state alignment changed")
    if not bool(objective.get("future_observation_updates_forbidden")):
        raise ValueError("future observation access guard changed")

    seed_policy = contract.get("truth_seed_policy", {})
    if (
        int(seed_policy.get("first_candidate", -1)) != 1701
        or int(seed_policy.get("candidate_step", -1)) != 1
        or int(seed_policy.get("accepted_count", -1)) != 27
        or tuple(seed_policy.get("start_ids_in_accepted_order", ())) != START_IDS
    ):
        raise ValueError("truth seed acceptance order changed")
    conditions = seed_policy.get("acceptance_conditions", {})
    if conditions != {
        "all_truth_arrays_finite": True,
        "maximum_projection_fraction": 0.15,
        "maximum_observation_fixed_point_error": 1e-12,
        "minimum_proportional_observation_branch_fraction": 0.5,
    }:
        raise ValueError("mechanical seed acceptance conditions changed")

    truth_filter = contract.get("truth_and_filter", {})
    if int(truth_filter.get("days", -1)) != 192:
        raise ValueError("synthetic sequence length changed")
    if not np.array_equal(
        np.asarray(truth_filter.get("initial_state"), dtype=np.float64),
        np.asarray([8.0, 1.0, 180.0, 25.0, 50.0, 0.0, 0.0, 0.0]),
    ):
        raise ValueError("common exact-truth initial state changed")
    if not np.array_equal(
        np.asarray(truth_filter.get("state_scales"), dtype=np.float64), STATE_SCALES
    ):
        raise ValueError("state scales changed")
    if not bool(truth_filter.get("frozen_filter_noise_parameters")):
        raise ValueError("filter noise parameters must remain frozen")
    if float(truth_filter.get("initial_covariance_diagonal", math.nan)) != 0.001:
        raise ValueError("initial state covariance changed")
    if float(truth_filter.get("base_observation_variance", math.nan)) != 0.0001:
        raise ValueError("base observation variance changed")
    if float(truth_filter.get("fixed_lag_time_days", math.nan)) != 3.0:
        raise ValueError("fixed routing lag changed")
    if tuple(float(value) for value in truth_filter.get("process_noise_bounds", ())) != PROCESS_NOISE_BOUNDS:
        raise ValueError("process-noise bounds changed")
    if tuple(float(value) for value in truth_filter.get("observation_ratio_bounds", ())) != OBSERVATION_RATIO_BOUNDS:
        raise ValueError("observation-noise bounds changed")

    optimizer = contract.get("optimizer", {})
    expected_optimizer = {
        "name": "Adam",
        "hydrology_learning_rate": 0.005,
        "group_gradient_norm": 1.0,
        "updates": 96,
        "selection_interval": 4,
        "betas": [0.9, 0.999],
        "epsilon": 1e-8,
        "weight_decay": 0.0,
        "amsgrad": False,
    }
    if optimizer != expected_optimizer:
        raise ValueError("optimizer contract changed")
    expected_selection = {
        "query_updates": list(range(0, 97, 4)),
        "metric": "selection_origin_equal_weight_noisy_observation_mse",
        "direction": "minimize",
        "tie_break": "earliest_update",
        "nonlearning_selected_update": 0,
    }
    if contract.get("selection") != expected_selection:
        raise ValueError("selection contract changed")

    budget = contract.get("seals_and_budget", {})
    expected_counts = {
        "trainable_units": 54,
        "real_optimizer_updates": 5184,
        "selection_queries": 1404,
        "sealed_primary_pipeline_checkpoints": 108,
        "test_readout_units": 162,
        "state_updating_test_readout_units": 81,
        "primary_errors_per_readout_unit": 126,
        "clean_target_queries_before_global_selection_seal": 0,
        "test_observation_inputs_before_global_selection_seal": 0,
    }
    if budget != expected_counts:
        raise ValueError("formal execution counts changed")
    gates = contract.get("gates", {})
    expected_gates = {
        "clear_benefit_median_ratio_maximum": 0.90,
        "clear_harm_median_ratio_minimum": 1.10,
        "minimum_direction_count": 19,
        "independent_replicates": 27,
        "sign_test_one_sided_alpha": 0.05,
        "classes": [
            "CLEAR_BENEFIT",
            "CLEAR_HARM",
            "DIRECTIONAL_SMALL",
            "MIXED_OR_INCONCLUSIVE",
        ],
    }
    if gates != expected_gates:
        raise ValueError("visible-effect classification gates changed")
    if tuple(contract.get("claims_not_authorized", ())) != CLAIMS_NOT_AUTHORIZED:
        raise ValueError("claims-not-authorized boundary changed")

    if contract.get("outputs") != EXPECTED_OUTPUTS:
        raise ValueError("TUKF17 output roots changed")
    if contract.get("resources") != {
        "minimum_available_memory_gib": 8.0,
        "minimum_workspace_free_storage_gib": 2.0,
        "maximum_other_active_formal_controllers": 0,
    }:
        raise ValueError("formal resource thresholds changed")
    if contract.get("numerical_environment") != {
        "device": "cpu",
        "torch_dtype": "float64",
        "numpy_dtype": "float64",
        "torch_threads": 1,
    }:
        raise ValueError("numerical environment changed")
    for raw in contract.get("outputs", {}).values():
        resolve_output_path(contract, raw)
    verified_inputs = 0
    if verify_files:
        for raw, expected in contract.get("readonly_input_sha256", {}).items():
            path = resolve_readonly_input(contract, raw)
            if not path.is_file():
                raise FileNotFoundError(f"registered read-only input is missing: {path}")
            if sha256_file(path) != str(expected):
                raise ValueError(f"read-only input SHA-256 mismatch: {raw}")
            verified_inputs += 1

        balanced = read_json(
            resolve_readonly_input(contract, contract["parent_configs"]["balanced_design"])
        )["balanced_error_design"]
        for key in (
            "process_standard_deviation_fraction",
            "filter_perturbation_factor",
            "filter_perturbation_low_multiplier",
            "filter_perturbation_high_multiplier",
            "hydrology_coordinate_distance",
        ):
            if balanced[key] != design[key]:
                raise ValueError(f"TUKF16 balanced design differs at {key}")
    return {
        "pipeline_count": len(PIPELINE_ORDER),
        "readout_count": len(READOUT_ORDER),
        "origin_counts": {name: len(values) for name, values in ORIGIN_WINDOWS.items()},
        "verified_readonly_input_count": verified_inputs,
    }


def load_contract(path: Path | str = DEFAULT_CONFIG) -> dict[str, Any]:
    contract = read_json(path)
    validate_contract(contract)
    return contract


def origin_indices(contract: Mapping[str, Any], split: str) -> tuple[int, ...]:
    if split not in ORIGIN_WINDOWS:
        raise ValueError(f"unknown origin split: {split}")
    row = contract["origins"][split]
    values = tuple(range(int(row["start"]), int(row["end_inclusive"]) + 1))
    if values != ORIGIN_WINDOWS[split]:
        raise ValueError(f"{split} origin window differs from the frozen contract")
    return values


def parent_contracts(contract: Mapping[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    paths = contract["parent_configs"]
    return (
        read_json(resolve_readonly_input(contract, paths["truth_generator"])),
        read_json(resolve_readonly_input(contract, paths["start_registry"])),
    )


def truth_process_variances(contract: Mapping[str, Any]) -> np.ndarray:
    scales = np.asarray(contract["truth_and_filter"]["state_scales"], dtype=np.float64)
    return np.square(scales * float(contract["balanced_error_design"]["process_standard_deviation_fraction"]))


def generate_truth_for_seed(
    contract: Mapping[str, Any], seed: int, *, permissive_validity_thresholds: bool = False
) -> tuple[np.ndarray, dict[str, Any]]:
    modules = predecessor_modules(contract)
    parent, _ = parent_contracts(contract)
    values = modules["truth_runner"]._truth_values(parent)
    generation = modules["truth_runner"]._truth_generation_values(parent)
    days = int(contract["truth_and_filter"]["days"])
    forcing = modules["truth_common"].build_forcing(days)
    process_normals, observation_normals = modules["truth_runner"]._standard_normals(
        days, int(seed)
    )
    truth = modules["truth_common"].generate_independent_truth(
        values["parameters"],
        forcing,
        values["initial_state"],
        truth_process_variances(contract),
        process_normals,
        observation_normals,
        observation_ratio=values["observation_ratio"],
        base_observation_variance=values["base_variance"],
        denominator_margin=generation["denominator_margin"],
        fixed_point_tolerance=(math.inf if permissive_validity_thresholds else 1e-12),
        maximum_projection_fraction=(1.0 if permissive_validity_thresholds else 0.15),
        minimum_proportional_branch_fraction=(
            0.0 if permissive_validity_thresholds else 0.5
        ),
    )
    return np.ascontiguousarray(forcing), dict(truth)


def _truth_arrays_finite(truth: Mapping[str, Any]) -> bool:
    arrays = [
        np.asarray(value)
        for value in truth.values()
        if isinstance(value, np.ndarray) and value.dtype.kind in "fciu"
    ]
    return bool(arrays) and all(np.isfinite(value).all() for value in arrays)


def mechanically_accept_truth_seed(
    seed: int, contract: Mapping[str, Any], *, diagnostics: Mapping[str, Any] | None = None
) -> dict[str, Any]:
    """Apply only the four frozen truth-validity conditions to one candidate."""

    if isinstance(seed, bool) or int(seed) != seed or int(seed) < 0:
        raise ValueError("truth seed must be a nonnegative integer")
    truth: Mapping[str, Any] | None = None
    generation_error: str | None = None
    if diagnostics is None:
        try:
            _, generated = generate_truth_for_seed(
                contract, int(seed), permissive_validity_thresholds=True
            )
            truth = generated
            diagnostics = {
                "all_truth_arrays_finite": _truth_arrays_finite(generated),
                "projection_fraction": float(generated["projection_fraction"]),
                "observation_fixed_point_max_absolute_error": float(
                    generated["fixed_point_max_absolute_error"]
                ),
                "proportional_observation_branch_fraction": float(
                    generated["proportional_branch_fraction"]
                ),
            }
        except (ValueError, FloatingPointError) as error:
            generation_error = f"{type(error).__name__}: {error}"
            diagnostics = {
                "all_truth_arrays_finite": False,
                "projection_fraction": 1e308,
                "observation_fixed_point_max_absolute_error": 1e308,
                "proportional_observation_branch_fraction": -1e308,
            }
    required = contract["truth_seed_policy"]["acceptance_conditions"]
    finite = bool(diagnostics["all_truth_arrays_finite"])
    projection = float(diagnostics["projection_fraction"])
    fixed_point = float(diagnostics["observation_fixed_point_max_absolute_error"])
    proportional = float(diagnostics["proportional_observation_branch_fraction"])
    checks = {
        "all_truth_arrays_finite": finite,
        "projection_fraction": math.isfinite(projection)
        and projection <= float(required["maximum_projection_fraction"]),
        "observation_fixed_point_error": math.isfinite(fixed_point)
        and fixed_point <= float(required["maximum_observation_fixed_point_error"]),
        "proportional_observation_branch_fraction": math.isfinite(proportional)
        and proportional
        >= float(required["minimum_proportional_observation_branch_fraction"]),
    }
    result = {
        "seed": int(seed),
        "accepted": all(checks.values()),
        "checks": checks,
        "diagnostics": {
            "all_truth_arrays_finite": finite,
            "projection_fraction": projection,
            "observation_fixed_point_max_absolute_error": fixed_point,
            "proportional_observation_branch_fraction": proportional,
        },
        "scientific_metric_queries": 0,
    }
    if generation_error is not None:
        result["generation_error"] = generation_error
    if truth is not None:
        result["truth_array_sha256"] = sha256_arrays(
            {
                name: value
                for name, value in truth.items()
                if isinstance(value, np.ndarray)
            }
        )
    return result


def freeze_seed_registry(
    contract: Mapping[str, Any],
    *,
    destination: Path | str | None = None,
    configuration_path: Path | str = DEFAULT_CONFIG,
) -> dict[str, Any]:
    policy = contract["truth_seed_policy"]
    accepted_target = int(policy["accepted_count"])
    candidate = int(policy["first_candidate"])
    step = int(policy["candidate_step"])
    attempts: list[dict[str, Any]] = []
    accepted: list[dict[str, Any]] = []
    while len(accepted) < accepted_target:
        row = mechanically_accept_truth_seed(candidate, contract)
        attempts.append(row)
        if row["accepted"]:
            accepted.append(
                {
                    "accepted_order": len(accepted) + 1,
                    "truth_seed": candidate,
                    "start_id": START_IDS[len(accepted)],
                    "truth_array_sha256": row.get("truth_array_sha256"),
                }
            )
        candidate += step
    registry = {
        "schema_version": "tukf17_truth_seed_registry_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "TRUTH_SEEDS_MECHANICALLY_FROZEN",
        "candidate_start": int(policy["first_candidate"]),
        "attempted_candidates": attempts,
        "accepted_pairs": accepted,
        "accepted_count": len(accepted),
        "scientific_metric_queries": 0,
        "truth_generator_sha256": contract["readonly_input_sha256"][
            "scripts/tukf11_hbv_joint_parameter_synthetic_common.py"
        ],
        "configuration_sha256": sha256_file(configuration_path),
    }
    target = destination
    if target is None:
        target = resolve_output_path(contract, contract["outputs"]["preflight_root"]) / "seed_registry.json"
    write_new_json(target, registry)
    return registry


def registered_pairs(
    contract: Mapping[str, Any], registry: Mapping[str, Any]
) -> tuple[tuple[int, str], ...]:
    rows = registry.get("accepted_pairs", ())
    pairs = tuple((int(row["truth_seed"]), str(row["start_id"])) for row in rows)
    if len(pairs) != 27 or len(set(pairs)) != 27:
        raise ValueError("seed registry must contain exactly 27 unique pairs")
    if len({seed for seed, _ in pairs}) != 27:
        raise ValueError("every formal repetition requires a unique truth seed")
    if tuple(start for _, start in pairs) != START_IDS:
        raise ValueError("accepted seeds are not mapped to start_03 through start_29")
    if any(int(row.get("accepted_order", -1)) != index for index, row in enumerate(rows, 1)):
        raise ValueError("accepted seed order is not contiguous")
    if int(registry.get("scientific_metric_queries", -1)) != 0:
        raise PermissionError("seed selection used a scientific metric")
    return pairs


def build_start_values(
    contract: Mapping[str, Any],
    start_id: str,
    *,
    hydrology_source: str = "initial",
    filter_source: str = "initial",
) -> dict[str, Any]:
    parent, starts = parent_contracts(contract)
    if start_id not in START_IDS:
        raise ValueError(f"unknown TUKF17 start identifier: {start_id}")
    entry = starts["start_registry"][start_id]
    truth = parent["truth"]
    names = truth["trainable_hydrology_names"]
    parameters = np.asarray(truth["hydrology_parameters"], dtype=np.float64)
    lower = np.asarray([truth["hydrology_v5_bounds"][name][0] for name in names])
    upper = np.asarray([truth["hydrology_v5_bounds"][name][1] for name in names])
    truth_coordinate = (parameters[:12] - lower) / (upper - lower)
    if hydrology_source == "truth":
        coordinate = truth_coordinate
    elif hydrology_source == "initial":
        coordinate = truth_coordinate + HYDROLOGY_DISTANCE * np.asarray(
            entry["hydrology_signs"], dtype=np.float64
        )
    else:
        raise ValueError(f"unknown hydrology source: {hydrology_source}")
    if coordinate.shape != (12,) or np.any(coordinate <= 0.0) or np.any(coordinate >= 1.0):
        raise ValueError("hydrology start lies outside strict parameter bounds")
    hydrology = np.concatenate((lower + coordinate * (upper - lower), parameters[12:13]))
    process_truth = truth_process_variances(contract)
    observation_truth = float(truth["observation_residual_ratio"])
    if filter_source == "truth":
        process = process_truth
        observation = observation_truth
    elif filter_source == "initial":
        process_multiplier = np.asarray(
            [1.0 / FILTER_FACTOR if float(value) < 1.0 else FILTER_FACTOR for value in entry["process_multipliers"]],
            dtype=np.float64,
        )
        process = process_truth * process_multiplier
        observation = observation_truth * (
            1.0 / FILTER_FACTOR
            if float(entry["observation_multiplier"]) < 1.0
            else FILTER_FACTOR
        )
    else:
        raise ValueError(f"unknown filter source: {filter_source}")
    return {
        "hydrology_parameters": np.ascontiguousarray(hydrology),
        "hydrology_coordinates": np.ascontiguousarray(coordinate),
        "process_variances": np.ascontiguousarray(process),
        "observation_ratio": float(observation),
        "truth_process_variances": np.ascontiguousarray(process_truth),
    }


def build_model(
    contract: Mapping[str, Any],
    start_id: str,
    *,
    hydrology_source: str = "initial",
    filter_source: str = "initial",
    dtype: torch.dtype = torch.float64,
    device: torch.device | str = torch.device("cpu"),
):
    modules = predecessor_modules(contract)
    parent, _ = parent_contracts(contract)
    values = build_start_values(
        contract,
        start_id,
        hydrology_source=hydrology_source,
        filter_source=filter_source,
    )
    model = modules["adapter"].JointTrainableRoutedHBVLiteUKF(
        torch.as_tensor(values["hydrology_parameters"], dtype=dtype, device=device).reshape(1, -1),
        torch.as_tensor(parent["truth"]["routing_weights"], dtype=dtype, device=device).reshape(1, -1),
        initial_process_diagonal=torch.as_tensor(
            values["process_variances"], dtype=dtype, device=device
        ),
        initial_observation_ratio=values["observation_ratio"],
        process_noise_bounds=PROCESS_NOISE_BOUNDS,
        observation_ratio_bounds=OBSERVATION_RATIO_BOUNDS,
        clamp_storage=True,
        signed_routing_memory=False,
        dtype=dtype,
        device=torch.device(device),
    )
    if int(model.dim_x) != 8:
        raise RuntimeError("TUKF17 requires exactly eight routed state coordinates")
    model._tukf17_readonly_predecessor_root = str(predecessor_root(contract))
    return model


def snapshot_model(model) -> dict[str, np.ndarray]:
    module = predecessor_modules(_predecessor_contract_for_model(model))["truth_common"]
    return copy_snapshot(module.snapshot_trainables(model))


def restore_model_(model, snapshot: Mapping[str, Any]) -> None:
    module = predecessor_modules(_predecessor_contract_for_model(model))["truth_common"]
    module.restore_trainables_(model, snapshot)


def rollout_open_loop_states(
    model,
    forcings: torch.Tensor | np.ndarray,
    initial_state: torch.Tensor | np.ndarray,
    end_exclusive: int,
) -> torch.Tensor:
    """Replay deterministically from the common initial state and retain x[0:T+1]."""

    end = int(end_exclusive)
    forcing = torch.as_tensor(forcings, dtype=model.dtype, device=model.device)
    if forcing.ndim == 3 and forcing.shape[1] == 1:
        forcing = forcing[:, 0, :]
    if forcing.ndim != 2 or forcing.shape[1] != 3:
        raise ValueError("open-loop forcings must be [T,3]")
    if not (0 <= end <= forcing.shape[0]):
        raise ValueError("open-loop end_exclusive is outside the forcing sequence")
    state = torch.as_tensor(initial_state, dtype=model.dtype, device=model.device)
    if state.ndim == 1:
        state = state.unsqueeze(0)
    if state.shape != (1, int(model.dim_x)):
        raise ValueError("open-loop initial state must be [8] or [1,8]")
    states = [model.project_mean(state)]
    for day in range(end):
        state = model.f(state, forcing[day : day + 1])
        state = model.project_mean(state)
        if not bool(torch.isfinite(state).all()):
            raise FloatingPointError(f"non-finite open-loop state on day {day}")
        states.append(state)
    return torch.cat(states, dim=0)


def rollout_state_update_trace(
    model,
    forcings: torch.Tensor | np.ndarray,
    observation_prefix: torch.Tensor | np.ndarray,
    initial_state: torch.Tensor | np.ndarray,
    covariance: torch.Tensor | np.ndarray,
    *,
    base_observation_variance: torch.Tensor | float = 1e-4,
    alpha: float = 0.3,
    beta: float = 2.0,
    kappa: float = 0.0,
    covariance_floor: float = 1e-12,
) -> dict[str, torch.Tensor]:
    """Run the corrected filter and retain both means and covariances each day."""

    modules = predecessor_modules(_predecessor_contract_for_model(model))
    ukf = modules["ukf"]
    forcing = torch.as_tensor(forcings, dtype=model.dtype, device=model.device)
    if forcing.ndim == 2:
        forcing = forcing.unsqueeze(1)
    observation = torch.as_tensor(
        observation_prefix, dtype=model.dtype, device=model.device
    )
    if observation.ndim == 1:
        observation = observation.unsqueeze(1)
    if forcing.ndim != 3 or forcing.shape[1:] != (1, 3):
        raise ValueError("state-update forcings must be [T,3] or [T,1,3]")
    if observation.shape != (forcing.shape[0], 1):
        raise ValueError("observation prefix must contain one value per released day")
    mean = torch.as_tensor(initial_state, dtype=model.dtype, device=model.device)
    if mean.ndim == 1:
        mean = mean.unsqueeze(0)
    if mean.shape != (1, int(model.dim_x)):
        raise ValueError("filter initial state shape changed")
    mean = model.project_mean(mean)
    cov = torch.as_tensor(covariance, dtype=model.dtype, device=model.device)
    if cov.ndim == 2:
        cov = cov.unsqueeze(0)
    if cov.shape != (1, int(model.dim_x), int(model.dim_x)):
        raise ValueError("filter initial covariance shape changed")
    cov = torch.stack(
        [ukf._stabilize(cov[index : index + 1], covariance_floor)[0] for index in range(cov.shape[0])]
    )
    q_diag = model.process_diagonal().reshape(1, -1)
    base_var = torch.as_tensor(
        base_observation_variance, dtype=model.dtype, device=model.device
    ).reshape(1)
    if not bool(torch.all(q_diag > 0.0)) or not bool(torch.all(base_var > 0.0)):
        raise ValueError("filter noise variances must be strictly positive")
    mean_weights, covariance_weights, scaling = ukf.merwe_weights(
        int(model.dim_x),
        alpha=alpha,
        beta=beta,
        kappa=kappa,
        dtype=model.dtype,
        device=model.device,
    )
    out: dict[str, list[torch.Tensor]] = {
        "prediction": [],
        "prior_state": [],
        "posterior_state": [],
        "prior_covariance": [],
        "posterior_covariance": [],
        "observation_variance": [],
        "innovation": [],
    }
    for day in range(forcing.shape[0]):
        model.set_forcing(forcing[day])
        sigmas = ukf.batched_sigma_points(mean, cov, scaling)
        propagated = model.fx(sigmas)
        prior_raw = torch.einsum("s,bsm->bm", mean_weights, propagated)
        deviation = propagated - prior_raw.unsqueeze(1)
        prior_covariance = torch.einsum(
            "s,bsi,bsj->bij", covariance_weights, deviation, deviation
        ) + torch.diag_embed(q_diag)
        prior_covariance = ukf._stabilize(prior_covariance, covariance_floor)
        prior_mean = model.project_mean(prior_raw)
        if not torch.equal(prior_mean, prior_raw):
            conventional = importlib.import_module(
                "global_hydrology.assimilation.conventional_ukf"
            )
            prior_covariance = conventional.recenter_covariance(
                prior_covariance, source_mean=prior_raw, replacement_mean=prior_mean
            )
            prior_covariance = ukf._stabilize(prior_covariance, covariance_floor)

        update_sigmas = ukf.batched_sigma_points(prior_mean, prior_covariance, scaling)
        observed = model.hx(update_sigmas)[..., 0]
        predicted = torch.einsum("s,bs->b", mean_weights, observed)
        released = observation[day]
        available = torch.isfinite(released)
        safe_observation = torch.nan_to_num(released, nan=0.0)
        flow_level = torch.clamp(torch.maximum(predicted, safe_observation), min=0.0)
        observation_variance = torch.maximum(
            base_var, (model.observation_ratio() * flow_level) ** 2
        )
        observed_deviation = observed - predicted.unsqueeze(1)
        innovation_variance = torch.einsum(
            "s,bs,bs->b", covariance_weights, observed_deviation, observed_deviation
        ) + observation_variance
        state_deviation = update_sigmas - prior_mean.unsqueeze(1)
        cross = torch.einsum(
            "s,bsm,bs->bm", covariance_weights, state_deviation, observed_deviation
        )
        gain = cross / innovation_variance.unsqueeze(-1)
        innovation = safe_observation - predicted
        updated_mean = prior_mean + gain * innovation.unsqueeze(-1)
        posterior_rows = []
        for basin in range(prior_mean.shape[0]):
            posterior = (
                prior_covariance[basin]
                - gain[basin].unsqueeze(-1) @ cross[basin].unsqueeze(0)
                - cross[basin].unsqueeze(-1) @ gain[basin].unsqueeze(0)
                + gain[basin].unsqueeze(-1)
                @ innovation_variance[basin].reshape(1, 1)
                @ gain[basin].unsqueeze(0)
            )
            posterior_rows.append(0.5 * (posterior + posterior.T))
        updated_covariance = ukf._stabilize(
            torch.stack(posterior_rows), covariance_floor
        )
        keep = available.to(model.dtype).unsqueeze(-1)
        posterior_raw = keep * updated_mean + (1.0 - keep) * prior_mean
        posterior_covariance = (
            keep.unsqueeze(-1) * updated_covariance
            + (1.0 - keep.unsqueeze(-1)) * prior_covariance
        )
        posterior_mean = model.project_mean(posterior_raw)
        if not torch.equal(posterior_mean, posterior_raw):
            conventional = importlib.import_module(
                "global_hydrology.assimilation.conventional_ukf"
            )
            posterior_covariance = conventional.recenter_covariance(
                posterior_covariance,
                source_mean=posterior_raw,
                replacement_mean=posterior_mean,
            )
            posterior_covariance = ukf._stabilize(
                posterior_covariance, covariance_floor
            )
        if not bool(torch.isfinite(posterior_mean).all()) or not bool(
            torch.isfinite(posterior_covariance).all()
        ):
            raise FloatingPointError(f"non-finite filter state on day {day}")
        out["prediction"].append(predicted)
        out["prior_state"].append(prior_mean)
        out["posterior_state"].append(posterior_mean)
        out["prior_covariance"].append(prior_covariance)
        out["posterior_covariance"].append(posterior_covariance)
        out["observation_variance"].append(observation_variance)
        out["innovation"].append(innovation)
        mean, cov = posterior_mean, posterior_covariance
    return {name: torch.stack(values) for name, values in out.items()}


def forecast_from_origin_states(
    model,
    origin_states: torch.Tensor | np.ndarray,
    forcings: torch.Tensor | np.ndarray,
    origins: Sequence[int],
    leads: Sequence[int] = LEADS,
) -> dict[int, torch.Tensor]:
    selected_origins = tuple(int(value) for value in origins)
    selected_leads = tuple(int(value) for value in leads)
    if not selected_origins or selected_leads != LEADS:
        raise ValueError("origins must be nonempty and leads must be exactly 1, 2, 3")
    states = torch.as_tensor(origin_states, dtype=model.dtype, device=model.device)
    if states.ndim == 3 and states.shape[1] == 1:
        states = states[:, 0, :]
    if states.shape != (len(selected_origins), int(model.dim_x)):
        raise ValueError("one origin state is required for every origin")
    forcing = torch.as_tensor(forcings, dtype=model.dtype, device=model.device)
    if forcing.ndim == 3 and forcing.shape[1] == 1:
        forcing = forcing[:, 0, :]
    if forcing.ndim != 2 or forcing.shape[1] != 3:
        raise ValueError("forecast forcings must be [T,3]")
    if max(selected_origins) + max(selected_leads) >= forcing.shape[0]:
        raise ValueError("future forcing is incomplete for the requested origins")
    origin_tensor = torch.as_tensor(
        selected_origins, dtype=torch.long, device=model.device
    )
    forecasts: dict[int, torch.Tensor] = {}
    for lead in selected_leads:
        state = states
        for step in range(1, lead + 1):
            state = model.f(state, forcing[origin_tensor + step])
            state = model.project_mean(state)
        prediction = model.h(state)[:, 0]
        if not bool(torch.isfinite(prediction).all()):
            raise FloatingPointError(f"lead-{lead} forecast is non-finite")
        forecasts[lead] = prediction
    return forecasts


def rolling_origin_objective(
    model,
    forcings: torch.Tensor | np.ndarray,
    observations: torch.Tensor | np.ndarray,
    initial_state: torch.Tensor | np.ndarray,
    initial_covariance: torch.Tensor | np.ndarray,
    origins: Sequence[int],
    *,
    state_update: bool,
    targets: torch.Tensor | np.ndarray | None = None,
    base_observation_variance: torch.Tensor | float = 1e-4,
    leads: Sequence[int] = LEADS,
) -> tuple[torch.Tensor, dict[str, Any]]:
    """Score shared rolling origins without releasing a future observation."""

    selected_origins = tuple(int(value) for value in origins)
    if not selected_origins:
        raise ValueError("rolling-origin objective requires at least one origin")
    forcing = torch.as_tensor(forcings, dtype=model.dtype, device=model.device)
    if forcing.ndim == 3 and forcing.shape[1] == 1:
        forcing = forcing[:, 0, :]
    observation = torch.as_tensor(
        observations, dtype=model.dtype, device=model.device
    ).reshape(-1)
    target_values = observation if targets is None else torch.as_tensor(
        targets, dtype=model.dtype, device=model.device
    ).reshape(-1)
    if forcing.shape[0] != observation.shape[0] or target_values.shape[0] != forcing.shape[0]:
        raise ValueError("forcing, observations, and targets must share the day axis")
    max_origin = max(selected_origins)
    if state_update:
        trace = rollout_state_update_trace(
            model,
            forcing[: max_origin + 1],
            observation[: max_origin + 1],
            initial_state,
            initial_covariance,
            base_observation_variance=base_observation_variance,
        )
        index = torch.as_tensor(selected_origins, dtype=torch.long, device=model.device)
        states = trace["posterior_state"][index, 0, :]
    else:
        trace = None
        replay = rollout_open_loop_states(
            model, forcing, initial_state, max_origin + 1
        )
        index = torch.as_tensor(
            [origin + 1 for origin in selected_origins],
            dtype=torch.long,
            device=model.device,
        )
        states = replay[index]
    forecasts = forecast_from_origin_states(model, states, forcing, selected_origins, leads)
    losses: dict[int, torch.Tensor] = {}
    target_by_lead: dict[int, torch.Tensor] = {}
    origin_tensor = torch.as_tensor(
        selected_origins, dtype=torch.long, device=model.device
    )
    for lead in LEADS:
        target = target_values[origin_tensor + lead]
        target_by_lead[lead] = target
        losses[lead] = torch.mean((forecasts[lead] - target) ** 2)
    loss = torch.stack([losses[lead] for lead in LEADS]).mean()
    if not bool(torch.isfinite(loss)):
        raise FloatingPointError("rolling-origin objective is non-finite")
    return loss, {
        "origins": selected_origins,
        "origin_states": states,
        "forecasts": forecasts,
        "targets": target_by_lead,
        "mse_by_lead": losses,
        "trace": trace,
    }


def state_error_metrics(
    origin_states: np.ndarray | torch.Tensor,
    truth_states: np.ndarray | torch.Tensor,
    origins: Sequence[int],
    scales: Sequence[float] = STATE_SCALES,
) -> dict[str, np.ndarray | float]:
    estimate = np.asarray(
        origin_states.detach().cpu().numpy()
        if isinstance(origin_states, torch.Tensor)
        else origin_states,
        dtype=np.float64,
    )
    if estimate.ndim == 3 and estimate.shape[1] == 1:
        estimate = estimate[:, 0, :]
    truth = np.asarray(
        truth_states.detach().cpu().numpy()
        if isinstance(truth_states, torch.Tensor)
        else truth_states,
        dtype=np.float64,
    )
    selected = np.asarray(tuple(int(value) for value in origins), dtype=np.int64)
    scale = np.asarray(scales, dtype=np.float64)
    if estimate.shape != (selected.size, 8) or truth.ndim != 2 or truth.shape[1] != 8:
        raise ValueError("state-error arrays have incompatible shapes")
    if scale.shape != (8,) or np.any(scale <= 0.0):
        raise ValueError("state scales must contain eight positive values")
    target = truth[selected + 1]
    standardized = (estimate - target) / scale.reshape(1, -1)
    square = np.square(standardized)
    return {
        "standardized_error": np.ascontiguousarray(standardized),
        "standardized_squared_error": np.ascontiguousarray(square),
        "complete_error_by_origin": np.sqrt(np.mean(square, axis=1)),
        "per_state_rmse": np.sqrt(np.mean(square, axis=0)),
        "complete_rmse": float(np.sqrt(np.mean(square))),
    }


def classify_balance_arrays(
    e00: np.ndarray,
    e01: np.ndarray,
    e10: np.ndarray,
    e11: np.ndarray,
    contract: Mapping[str, Any],
) -> dict[str, Any]:
    """Classify fresh-seed train/selection influence without test access."""

    arrays = [
        np.asarray(value, dtype=np.float64) for value in (e00, e01, e10, e11)
    ]
    expected_shape = (27, 2, 3)
    if any(value.shape != expected_shape for value in arrays):
        raise ValueError("balance error arrays must have shape [27,2,3]")
    if any(not np.isfinite(value).all() or np.any(value <= 0.0) for value in arrays):
        raise ValueError("balance errors must be finite and positive")
    lower, upper = (
        float(value)
        for value in contract["balanced_error_design"]["influence_ratio_interval"]
    )
    windows: dict[str, Any] = {}
    all_ratios: list[float] = []
    for window_index, window in enumerate(("train", "selection")):
        by_lead: dict[str, Any] = {}
        for lead_index, lead in enumerate(LEADS):
            filter_values = (
                arrays[1][:, window_index, lead_index]
                - arrays[0][:, window_index, lead_index]
            ) / arrays[1][:, window_index, lead_index]
            hydrology_values = (
                arrays[2][:, window_index, lead_index]
                - arrays[0][:, window_index, lead_index]
            ) / arrays[2][:, window_index, lead_index]
            median_filter = float(np.median(filter_values))
            median_hydrology = float(np.median(hydrology_values))
            ratio = median_filter / median_hydrology
            all_ratios.append(ratio)
            by_lead[str(lead)] = {
                "median_filter_influence": median_filter,
                "median_hydrology_influence": median_hydrology,
                "median_combined_error": float(
                    np.median(arrays[3][:, window_index, lead_index])
                ),
                "filter_over_hydrology_ratio": ratio,
                "balance_pass": lower <= ratio <= upper,
            }
        means = [np.mean(value[:, window_index, :], axis=1) for value in arrays]
        filter_equal = (means[1] - means[0]) / means[1]
        hydrology_equal = (means[2] - means[0]) / means[2]
        equal_ratio = float(np.median(filter_equal)) / float(np.median(hydrology_equal))
        all_ratios.append(equal_ratio)
        windows[window] = {
            "by_lead": by_lead,
            "equal_weight": {
                "median_filter_influence": float(np.median(filter_equal)),
                "median_hydrology_influence": float(np.median(hydrology_equal)),
                "median_combined_error": float(np.median(means[3])),
                "filter_over_hydrology_ratio": equal_ratio,
                "balance_pass": lower <= equal_ratio <= upper,
            },
        }
    passed = all(lower <= value <= upper for value in all_ratios)
    return {
        "status": "BALANCE_PASS" if passed else "BALANCE_HOLD",
        "ratio_interval": [lower, upper],
        "minimum_ratio": min(all_ratios),
        "maximum_ratio": max(all_ratios),
        "ratio_count": len(all_ratios),
        "windows": windows,
        "combined_error_is_diagnostic_not_a_gate": True,
        "test_metric_queries": 0,
    }


def _binomial_tail_fraction(successes: int, trials: int) -> Fraction:
    return Fraction(
        sum(math.comb(trials, value) for value in range(successes, trials + 1)),
        2**trials,
    )


def _binomial_cdf(successes: int, trials: int, probability: float) -> float:
    p = float(probability)
    return sum(
        math.comb(trials, value) * p**value * (1.0 - p) ** (trials - value)
        for value in range(successes + 1)
    )


def _clopper_pearson(successes: int, trials: int, alpha: float = 0.05) -> list[float]:
    if not (0 <= successes <= trials and trials > 0 and 0.0 < alpha < 1.0):
        raise ValueError("invalid binomial interval inputs")
    if successes == 0:
        lower = 0.0
    else:
        lo, hi = 0.0, 1.0
        for _ in range(100):
            mid = 0.5 * (lo + hi)
            upper_tail = 1.0 - _binomial_cdf(successes - 1, trials, mid)
            if upper_tail < alpha / 2.0:
                lo = mid
            else:
                hi = mid
        lower = 0.5 * (lo + hi)
    if successes == trials:
        upper = 1.0
    else:
        lo, hi = 0.0, 1.0
        for _ in range(100):
            mid = 0.5 * (lo + hi)
            lower_tail = _binomial_cdf(successes, trials, mid)
            if lower_tail > alpha / 2.0:
                lo = mid
            else:
                hi = mid
        upper = 0.5 * (lo + hi)
    return [lower, upper]


def classify_contrast(
    ratios: Sequence[float], contract: Mapping[str, Any]
) -> str:
    values = np.asarray(ratios, dtype=np.float64)
    replicates = int(contract["gates"]["independent_replicates"])
    if values.shape != (replicates,) or not np.isfinite(values).all() or np.any(values <= 0.0):
        raise ValueError(f"contrast requires {replicates} finite positive paired ratios")
    median = float(np.median(values))
    wins = int(np.count_nonzero(values < 1.0))
    losses = int(np.count_nonzero(values > 1.0))
    minimum = int(contract["gates"]["minimum_direction_count"])
    if (
        median <= float(contract["gates"]["clear_benefit_median_ratio_maximum"])
        and wins >= minimum
    ):
        return "CLEAR_BENEFIT"
    if (
        median >= float(contract["gates"]["clear_harm_median_ratio_minimum"])
        and losses >= minimum
    ):
        return "CLEAR_HARM"
    if (
        float(contract["gates"]["clear_benefit_median_ratio_maximum"])
        < median
        < float(contract["gates"]["clear_harm_median_ratio_minimum"])
        and (wins >= minimum or losses >= minimum)
    ):
        return "DIRECTIONAL_SMALL"
    return "MIXED_OR_INCONCLUSIVE"


def _index_readout_rows(
    rows: Sequence[Mapping[str, Any]], contract: Mapping[str, Any]
) -> tuple[dict[tuple[int, str, str], Mapping[str, Any]], tuple[tuple[int, str], ...]]:
    indexed: dict[tuple[int, str, str], Mapping[str, Any]] = {}
    for row in rows:
        key = (int(row["truth_seed"]), str(row["start_id"]), str(row["readout_id"]))
        if key in indexed:
            raise ValueError(f"duplicate readout row: {key}")
        indexed[key] = row
    pairs = tuple(sorted({(seed, start) for seed, start, _ in indexed}))
    expected_starts = set(START_IDS)
    if (
        len(pairs) != 27
        or len({seed for seed, _ in pairs}) != 27
        or {start for _, start in pairs} != expected_starts
    ):
        raise ValueError("readout rows do not contain 27 independent registered pairs")
    expected = {(seed, start, readout) for seed, start in pairs for readout in READOUT_ORDER}
    if set(indexed) != expected:
        raise ValueError("six-readout test product is incomplete")
    return indexed, pairs


def _contrast_summary(
    indexed: Mapping[tuple[int, str, str], Mapping[str, Any]],
    pairs: Sequence[tuple[int, str]],
    numerator: str,
    denominator: str,
    contract: Mapping[str, Any],
) -> dict[str, Any]:
    ratios: list[float] = []
    per_pair: list[dict[str, Any]] = []
    for seed, start_id in pairs:
        numerator_value = float(indexed[(seed, start_id, numerator)]["primary_clean_mse"])
        denominator_value = float(indexed[(seed, start_id, denominator)]["primary_clean_mse"])
        if not (
            math.isfinite(numerator_value)
            and math.isfinite(denominator_value)
            and numerator_value > 0.0
            and denominator_value > 0.0
        ):
            raise ValueError("primary clean errors must be finite and positive")
        ratio = numerator_value / denominator_value
        ratios.append(ratio)
        per_pair.append({"truth_seed": seed, "start_id": start_id, "ratio": ratio})
    wins = int(np.count_nonzero(np.asarray(ratios) < 1.0))
    losses = int(np.count_nonzero(np.asarray(ratios) > 1.0))
    win_tail = _binomial_tail_fraction(wins, len(ratios))
    loss_tail = _binomial_tail_fraction(losses, len(ratios))
    by_lead: dict[str, Any] = {}
    for lead in LEADS:
        lead_ratios = [
            float(indexed[(seed, start, numerator)]["primary_clean_mse_by_lead"][str(lead)])
            / float(indexed[(seed, start, denominator)]["primary_clean_mse_by_lead"][str(lead)])
            for seed, start in pairs
        ]
        by_lead[str(lead)] = {
            "median_ratio": float(np.median(lead_ratios)),
            "ratio_range": [min(lead_ratios), max(lead_ratios)],
            "wins_below_one": int(np.count_nonzero(np.asarray(lead_ratios) < 1.0)),
            "ratios": lead_ratios,
        }
    return {
        "numerator": numerator,
        "denominator": denominator,
        "per_pair_ratios": per_pair,
        "ratios": ratios,
        "median_ratio": float(np.median(ratios)),
        "ratio_range": [min(ratios), max(ratios)],
        "wins_below_one": wins,
        "losses_above_one": losses,
        "ties_at_one": len(ratios) - wins - losses,
        "win_fraction_exact_95_percent_interval": _clopper_pearson(wins, len(ratios)),
        "benefit_sign_test_one_sided_p": float(win_tail),
        "benefit_sign_test_fraction": [win_tail.numerator, win_tail.denominator],
        "harm_sign_test_one_sided_p": float(loss_tail),
        "harm_sign_test_fraction": [loss_tail.numerator, loss_tail.denominator],
        "classification": classify_contrast(ratios, contract),
        "by_lead": by_lead,
    }


def aggregate_primary_pipelines(
    rows: Sequence[Mapping[str, Any]], contract: Mapping[str, Any]
) -> dict[str, Any]:
    indexed, pairs = _index_readout_rows(rows, contract)
    primary = {
        name: _contrast_summary(
            indexed,
            pairs,
            str(specification["numerator"]),
            str(specification["denominator"]),
            contract,
        )
        for name, specification in contract["primary_contrasts"].items()
    }
    interactions: list[float] = []
    per_pair: list[dict[str, Any]] = []
    for seed, start in pairs:
        values = {
            readout: float(indexed[(seed, start, readout)]["primary_clean_mse"])
            for readout in PIPELINE_ORDER
        }
        ratio = (
            values["state_and_hydrology_update"] * values["no_update"]
        ) / (values["state_update_only"] * values["hydrology_update_only"])
        interactions.append(ratio)
        per_pair.append(
            {
                "truth_seed": seed,
                "start_id": start,
                "interaction_ratio": ratio,
                "log_interaction_ratio": math.log(ratio),
            }
        )
    interaction_values = np.asarray(interactions, dtype=np.float64)
    below = int(np.count_nonzero(interaction_values < 1.0))
    above = int(np.count_nonzero(interaction_values > 1.0))
    alpha = float(contract["gates"]["sign_test_one_sided_alpha"])
    return {
        "independent_unit": "unique_truth_seed_and_registered_start_pair",
        "independent_unit_count": len(pairs),
        "contrasts": primary,
        "interaction": {
            "per_pair": per_pair,
            "median_ratio": float(np.median(interactions)),
            "ratio_range": [min(interactions), max(interactions)],
            "below_one_count": below,
            "above_one_count": above,
            "ties_at_one": len(interactions) - below - above,
            "below_one_fraction_exact_95_percent_interval": _clopper_pearson(
                below, len(interactions), alpha=alpha
            ),
            "above_one_fraction_exact_95_percent_interval": _clopper_pearson(
                above, len(interactions), alpha=alpha
            ),
        },
    }


def aggregate_crossed_readouts(
    rows: Sequence[Mapping[str, Any]], contract: Mapping[str, Any]
) -> dict[str, Any]:
    indexed, pairs = _index_readout_rows(rows, contract)
    return {
        name: _contrast_summary(
            indexed,
            pairs,
            str(specification["numerator"]),
            str(specification["denominator"]),
            contract,
        )
        for name, specification in contract["fixed_parameter_state_contrasts"].items()
    }


def classify_mechanisms(
    aggregate: Mapping[str, Any], contract: Mapping[str, Any]
) -> dict[str, Any]:
    del contract
    primary = aggregate["primary"]["contrasts"]
    crossed = aggregate["crossed"]
    state_classes = [
        crossed[name]["classification"]
        for name in (
            "initial_parameters",
            "openloop_trained_parameters",
            "state_trained_parameters",
        )
    ]
    parameter_classes = [
        primary["hydrology_update_only_over_no_update"]["classification"],
        primary["state_and_hydrology_update_over_state_update_only"]["classification"],
    ]
    if all(value == "CLEAR_BENEFIT" for value in state_classes):
        state_label = "CLEAR_BENEFIT_ACROSS_ALL_PARAMETER_SETS"
    elif len(set(state_classes)) > 1:
        state_label = "PARAMETER_SET_DEPENDENT"
    else:
        state_label = state_classes[0]
    if all(value == "CLEAR_BENEFIT" for value in parameter_classes):
        parameter_label = "CLEAR_BENEFIT_WITH_AND_WITHOUT_STATE_UPDATE"
    elif len(set(parameter_classes)) > 1:
        parameter_label = "CONTEXT_DEPENDENT"
    else:
        parameter_label = parameter_classes[0]
    return {
        "test_period_state_update": state_label,
        "hydrology_parameter_learning_pipeline": parameter_label,
        "state_update_fixed_parameter_classes": state_classes,
        "hydrology_learning_context_classes": parameter_classes,
        "interaction_is_descriptive_not_causal": True,
    }
