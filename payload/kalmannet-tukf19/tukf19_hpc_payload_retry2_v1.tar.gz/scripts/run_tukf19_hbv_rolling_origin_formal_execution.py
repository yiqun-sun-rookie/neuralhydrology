"""Run the authorized TUKF19 formal comparison with an explicit parallel waiver."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import sys
from typing import Any, Mapping

import psutil


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import tukf19_hbv_rolling_origin_formal_common as common  # noqa: E402
from scripts import run_tukf17_hbv_rolling_origin_state_hydrology_update as engine  # noqa: E402


DEFAULT_CONFIG = common.DEFAULT_CONFIG
FORMAL_FLAGS = (
    "--execute-formal-training",
    "--confirm-formal-training",
    "--stage formal",
)
SAME_EXPERIMENT_PROGRAM = "run_tukf19_hbv_rolling_origin_formal_execution.py"
formal_source_hashes = common.source_hashes


def available_memory_gib() -> float:
    return float(psutil.virtual_memory().available / (1024**3))


def workspace_free_storage_gib() -> float:
    return float(shutil.disk_usage(ROOT).free / (1024**3))


def active_formal_processes() -> list[dict[str, Any]]:
    current = os.getpid()
    rows: list[dict[str, Any]] = []
    for process in psutil.process_iter(["pid", "name", "cmdline", "create_time"]):
        try:
            pid = int(process.info["pid"])
            if pid == current:
                continue
            process_name = str(process.info.get("name") or "").lower()
            if not process_name.startswith("python"):
                continue
            command = " ".join(process.info.get("cmdline") or [])
            lowered = command.lower()
        except (psutil.NoSuchProcess, psutil.AccessDenied, TypeError, ValueError):
            continue
        if not ("run_tukf" in lowered or "verify_tukf" in lowered):
            continue
        if not any(flag in lowered for flag in FORMAL_FLAGS):
            continue
        rows.append(
            {
                "process_id": pid,
                "process_name": process_name,
                "command": command,
                "created_unix_seconds": float(process.info.get("create_time") or 0.0),
                "same_experiment": SAME_EXPERIMENT_PROGRAM in lowered,
            }
        )
    return sorted(rows, key=lambda row: int(row["process_id"]))


def resource_admission(contract: Mapping[str, Any]) -> dict[str, Any]:
    required = contract["resources"]
    memory = available_memory_gib()
    storage = workspace_free_storage_gib()
    processes = active_formal_processes()
    same = [int(row["process_id"]) for row in processes if row["same_experiment"]]
    unrelated = [int(row["process_id"]) for row in processes if not row["same_experiment"]]
    unrelated_allowed = bool(required["unrelated_formal_processes_allowed"]) and bool(
        contract["parallel_execution"]["unrelated_formal_processes_allowed"]
    )
    checks = {
        "available_memory": memory
        >= float(required["minimum_available_memory_gib"]),
        "workspace_free_storage": storage
        >= float(required["minimum_workspace_free_storage_gib"]),
        "no_other_same_experiment_controller": len(same)
        <= int(required["maximum_same_experiment_other_controllers"]),
        "unrelated_formal_processes_authorized": not unrelated or unrelated_allowed,
    }
    if all(checks.values()):
        status = (
            "RESOURCE_ADMITTED_WITH_PARALLEL_WAIVER"
            if unrelated
            else "RESOURCE_ADMITTED"
        )
    else:
        status = "RESOURCE_HOLD"
    return {
        "status": status,
        "checks": checks,
        "available_memory_gib": memory,
        "workspace_free_storage_gib": storage,
        "same_experiment_other_controller_ids": same,
        "unrelated_formal_process_ids": unrelated,
        "active_formal_processes": processes,
        "parallel_execution_authorization_text": contract["parallel_execution"][
            "authorization_text"
        ],
    }


def require_verified_parent_preflight(
    contract: Mapping[str, Any], contract_path: Path
) -> tuple[dict[str, Any], dict[str, Any]]:
    common.validate_contract(contract, registration_path=contract_path)
    registration = common.read_registration(contract_path)
    common.validate_registration(registration)
    root = common.resolve_output_path(contract, contract["outputs"]["preflight_root"])
    preflight = common.read_json(root / "preflight.json")
    verification = common.read_json(root / "independent_verification.json")
    conflict = common.read_json(root / "postflight_resource_conflict.json")
    if (
        preflight.get("status") != "PREFLIGHT_ENGINEERING_PASS"
        or preflight.get("balance_status") != "BALANCE_PASS"
        or int(preflight.get("test_metric_queries", -1)) != 0
        or int(preflight.get("formal_optimizer_updates", -1)) != 0
        or bool(preflight.get("formal_training_authorized"))
    ):
        raise PermissionError("formal training requires the frozen TUKF18 balance pass")
    if (
        verification.get("status") != "PREFLIGHT_VERIFIED"
        or not verification.get("checks")
        or not all(verification["checks"].values())
        or int(verification.get("test_metric_queries", -1)) != 0
        or int(verification.get("formal_optimizer_updates", -1)) != 0
    ):
        raise PermissionError("formal training requires verified TUKF18 preflight evidence")
    if conflict.get("status") != "RESOURCE_HOLD_POSTFLIGHT":
        raise RuntimeError("TUKF18 postflight resource audit identity changed")
    parent = common.load_parent_contract(contract_path)
    parent_result = common.resolve_output_path(parent, parent["outputs"]["result_root"])
    if parent_result.exists():
        raise RuntimeError("TUKF18 formal result unexpectedly exists")
    return preflight, verification


def _patch_engine() -> None:
    engine.common = common
    engine.DEFAULT_CONFIG = common.DEFAULT_CONFIG
    engine.EXPERIMENT_ID = common.EXPERIMENT_ID
    engine.source_hashes = formal_source_hashes
    engine._require_verified_preflight = require_verified_parent_preflight
    engine.resource_admission = resource_admission


def run_authorized_formal(
    contract: Mapping[str, Any],
    *,
    contract_path: Path = DEFAULT_CONFIG,
    confirm_formal_training: bool = False,
    confirm_parallel_execution: bool = False,
) -> dict[str, Any]:
    if not (confirm_formal_training and confirm_parallel_execution):
        raise PermissionError(
            "both formal and parallel execution confirmations are required"
        )
    common.validate_contract(contract, registration_path=contract_path)
    _patch_engine()
    return engine.run_formal(
        contract,
        contract_path=contract_path,
        user_confirmed_formal_training=True,
    )


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--confirm-formal-training", action="store_true")
    parser.add_argument("--confirm-parallel-execution", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    contract_path = args.config.resolve()
    contract = common.load_contract(contract_path)
    formal_root_existed_before_call = common.resolve_output_path(
        contract, contract["outputs"]["result_root"]
    ).exists()
    _patch_engine()
    try:
        report = run_authorized_formal(
            contract,
            contract_path=contract_path,
            confirm_formal_training=bool(args.confirm_formal_training),
            confirm_parallel_execution=bool(args.confirm_parallel_execution),
        )
    except BaseException as error:
        if not formal_root_existed_before_call:
            engine._archive_failed_formal_attempt(contract, error)
        raise
    print(
        json.dumps(
            {
                "status": report["status"],
                "experiment_id": report["experiment_id"],
                "resource_status": report["resource_admission"]["status"],
                "elapsed_seconds": report["elapsed_seconds"],
            },
            ensure_ascii=False,
            sort_keys=True,
            allow_nan=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
