"""Independently verify TUKF19 without importing its engineering runner."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any, Mapping


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import tukf19_hbv_rolling_origin_formal_common as common  # noqa: E402
from scripts import verify_tukf17_hbv_rolling_origin_state_hydrology_update as engine  # noqa: E402


DEFAULT_CONFIG = common.DEFAULT_CONFIG
independent_source_hashes = common.source_hashes


def _patch_engine() -> None:
    engine.common = common
    engine.DEFAULT_CONFIG = common.DEFAULT_CONFIG
    engine._source_hashes = independent_source_hashes


def verify_formal(
    contract: Mapping[str, Any], *, contract_path: Path = DEFAULT_CONFIG
) -> dict[str, Any]:
    common.validate_contract(contract, registration_path=contract_path)
    registration = common.read_registration(contract_path)
    if not bool(registration["authorization"]["independent_verification_authorized"]):
        raise PermissionError("TUKF19 independent verification is not authorized")
    root = common.resolve_output_path(contract, contract["outputs"]["result_root"])
    registry = common.read_json(root / "registry.json")
    if (
        registry.get("experiment_id") != common.EXPERIMENT_ID
        or registry.get("status")
        != "FORMAL_COMPLETE_AWAITING_INDEPENDENT_VERIFICATION"
    ):
        raise PermissionError("TUKF19 formal result is incomplete")
    _patch_engine()
    return engine.verify_formal(contract, contract_path=contract_path)


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    contract_path = args.config.resolve()
    contract = common.load_contract(contract_path)
    report = verify_formal(contract, contract_path=contract_path)
    print(
        json.dumps(
            {"status": report["status"], "checks": report["checks"]},
            ensure_ascii=False,
            sort_keys=True,
            allow_nan=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
