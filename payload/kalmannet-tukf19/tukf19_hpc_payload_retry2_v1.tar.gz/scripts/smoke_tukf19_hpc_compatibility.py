"""Run a sealed, one-update cross-platform compatibility gate for TUKF19."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path, PurePosixPath
import platform
import shutil
import sys
import time
import traceback
from typing import Any, Mapping

import numpy as np
import psutil
import torch


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import tukf19_hbv_rolling_origin_formal_common as scientific  # noqa: E402
from scripts import tukf19_hpc_deployment_common as deployment_common  # noqa: E402
from scripts import run_tukf19_hbv_rolling_origin_formal_execution as runner  # noqa: E402


DEFAULT_CONFIG = deployment_common.DEFAULT_CONFIG


def within_reference(
    actual: float, reference: float, deployment: Mapping[str, Any]
) -> bool:
    smoke = deployment["smoke"]
    return abs(float(actual) - float(reference)) <= float(
        smoke["absolute_tolerance"]
    ) + float(smoke["relative_tolerance"]) * abs(float(reference))


def _member_path(root: Path, name: str) -> Path:
    pure = PurePosixPath(name)
    if pure.is_absolute() or ".." in pure.parts:
        raise ValueError(f"unsafe payload member in manifest: {name}")
    candidate = root.joinpath(*pure.parts).resolve()
    try:
        candidate.relative_to(root.resolve())
    except ValueError as error:
        raise ValueError(f"payload member escapes root: {name}") from error
    return candidate


def verify_extracted_payload(
    root: Path, external_manifest_path: Path
) -> dict[str, Any]:
    external = deployment_common.read_json(external_manifest_path)
    archive_path = external_manifest_path.parent / external["archive_name"]
    if not archive_path.is_file():
        raise FileNotFoundError(f"transport archive is missing: {archive_path}")
    if archive_path.stat().st_size != int(external["archive_bytes"]):
        raise ValueError("transport archive byte count changed")
    if deployment_common.sha256_file(archive_path) != external["archive_sha256"]:
        raise ValueError("transport archive SHA-256 changed")

    payload_path = root / external["payload_manifest_name"]
    if deployment_common.sha256_file(payload_path) != external["payload_manifest_sha256"]:
        raise ValueError("extracted payload manifest SHA-256 changed")
    payload = deployment_common.read_json(payload_path)
    if payload.get("deployment_id") != external.get("deployment_id"):
        raise ValueError("payload and bundle deployment identities differ")
    if payload.get("members") != external.get("members"):
        raise ValueError("payload and external bundle member maps differ")
    mismatches: list[str] = []
    for name, expected in payload["members"].items():
        path = _member_path(root, name)
        if not path.is_file() or deployment_common.sha256_file(path) != expected:
            mismatches.append(name)
    if mismatches:
        raise ValueError(f"extracted payload member mismatch: {mismatches}")
    return {
        "bundle_sha256": external["archive_sha256"],
        "bundle_bytes": int(external["archive_bytes"]),
        "payload_manifest_sha256": external["payload_manifest_sha256"],
        "verified_member_count": len(payload["members"]),
    }


def _environment_report() -> dict[str, Any]:
    import matplotlib

    return {
        "python": sys.version,
        "python_executable": sys.executable,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "torch": torch.__version__,
        "psutil": psutil.__version__,
        "matplotlib": matplotlib.__version__,
        "torch_threads": torch.get_num_threads(),
        "torch_interop_threads": torch.get_num_interop_threads(),
        "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
        "slurm_partition": os.environ.get("SLURM_JOB_PARTITION"),
        "slurm_cpus_per_task": os.environ.get("SLURM_CPUS_PER_TASK"),
        "node": os.environ.get("SLURMD_NODENAME") or platform.node(),
        "thread_environment": {
            name: os.environ.get(name)
            for name in deployment_common.EXPECTED_SLURM["thread_environment"]
        },
    }


def _measure_branch(
    contract: Mapping[str, Any],
    method: str,
    *,
    start_id: str,
    forcing: np.ndarray,
    observations: np.ndarray,
) -> dict[str, Any]:
    engine = runner.engine
    model = scientific.build_model(contract, start_id)
    engine.configure_method_(model, method)
    optimizer = engine.build_optimizer(model, method, contract)
    if optimizer is None:
        raise RuntimeError(f"HPC smoke branch is not trainable: {method}")
    forcing_tensor, observation_tensor, initial_state, covariance = (
        engine._tensor_inputs(contract, forcing, observations)
    )
    state_update = bool(contract["pipeline_masks"][method]["state_update"])
    base_variance = float(contract["truth_and_filter"]["base_observation_variance"])
    initial_snapshot = scientific.snapshot_model(model)
    started = time.perf_counter()

    optimizer.zero_grad(set_to_none=True)
    loss, training_details = scientific.rolling_origin_objective(
        model,
        forcing_tensor,
        observation_tensor,
        initial_state,
        covariance,
        scientific.origin_indices(contract, "train"),
        state_update=state_update,
        targets=observation_tensor,
        base_observation_variance=base_variance,
    )
    loss.backward()
    gradient = model.hydrology_coordinates.grad
    if gradient is None or not bool(torch.isfinite(gradient).all()):
        raise FloatingPointError(f"non-finite HPC smoke gradient: {method}")
    raw_gradient = gradient.detach().cpu().numpy().copy()
    gradient_norm = float(
        torch.nn.utils.clip_grad_norm_(
            [model.hydrology_coordinates],
            float(contract["optimizer"]["group_gradient_norm"]),
        )
    )
    optimizer.step()
    model.project_trainable_coordinates_()
    current_snapshot = scientific.snapshot_model(model)
    engine._assert_noise_and_structure_unchanged(initial_snapshot, current_snapshot)

    with torch.no_grad():
        selection_loss, selection_details = scientific.rolling_origin_objective(
            model,
            forcing_tensor,
            observation_tensor,
            initial_state,
            covariance,
            scientific.origin_indices(contract, "selection"),
            state_update=state_update,
            targets=observation_tensor,
            base_observation_variance=base_variance,
        )
    elapsed = time.perf_counter() - started
    return {
        "method": method,
        "training_loss": float(loss.detach()),
        "training_mse_by_lead": {
            str(lead): float(training_details["mse_by_lead"][lead])
            for lead in scientific.LEADS
        },
        "gradient_norm_before_clipping": gradient_norm,
        "gradient_nonzero_count": int(np.count_nonzero(raw_gradient)),
        "gradient_values": raw_gradient.reshape(-1).tolist(),
        "selection_loss_after_one_update": float(selection_loss),
        "selection_mse_by_lead_after_one_update": {
            str(lead): float(selection_details["mse_by_lead"][lead])
            for lead in scientific.LEADS
        },
        "coordinates_after_one_update": (
            model.hydrology_coordinates.detach().cpu().numpy().reshape(-1).tolist()
        ),
        "filter_noise_parameters_unchanged": True,
        "elapsed_seconds": elapsed,
    }


def _deterministic_payload(row: Mapping[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in row.items() if key != "elapsed_seconds"}


def run_numeric_smoke(
    deployment: Mapping[str, Any], contract: Mapping[str, Any]
) -> dict[str, Any]:
    runner._patch_engine()
    torch.set_num_threads(1)
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        if torch.get_num_interop_threads() != 1:
            raise
    pairs = scientific.formal_pairs(contract)
    expected_pair = (
        int(deployment["smoke"]["truth_seed"]),
        str(deployment["smoke"]["start_id"]),
    )
    if pairs[0] != expected_pair:
        raise ValueError(f"first formal pair changed: {pairs[0]} != {expected_pair}")
    seed, start_id = expected_pair
    forcing, truth = scientific.generate_truth_for_seed(contract, seed)
    observations = np.asarray(truth["observations"], dtype=np.float64)
    first: dict[str, dict[str, Any]] = {}
    second: dict[str, dict[str, Any]] = {}
    for method in deployment["smoke"]["branches"]:
        first[method] = _measure_branch(
            contract,
            method,
            start_id=start_id,
            forcing=forcing,
            observations=observations,
        )
        second[method] = _measure_branch(
            contract,
            method,
            start_id=start_id,
            forcing=forcing,
            observations=observations,
        )

    deterministic = all(
        _deterministic_payload(first[method]) == _deterministic_payload(second[method])
        for method in deployment["smoke"]["branches"]
    )
    reference_checks: dict[str, bool] = {}
    for method, reference in deployment["smoke"]["reference"].items():
        actual = first[method]
        for key in (
            "training_loss",
            "gradient_norm_before_clipping",
            "selection_loss_after_one_update",
        ):
            reference_checks[f"{method}:{key}"] = within_reference(
                actual[key], reference[key], deployment
            )
        reference_checks[f"{method}:gradient_nonzero_count"] = (
            int(actual["gradient_nonzero_count"])
            == int(reference["gradient_nonzero_count"])
        )
        reference_checks[f"{method}:finite_coordinates"] = bool(
            np.isfinite(actual["coordinates_after_one_update"]).all()
        )
        reference_checks[f"{method}:filter_noise_unchanged"] = bool(
            actual["filter_noise_parameters_unchanged"]
        )
    first_elapsed = sum(float(row["elapsed_seconds"]) for row in first.values())
    return {
        "truth_seed": seed,
        "start_id": start_id,
        "first": first,
        "second": second,
        "deterministic": deterministic,
        "reference_checks": reference_checks,
        "test_origin_queries": 0,
        "clean_target_queries": 0,
        "first_pass_elapsed_seconds": first_elapsed,
        "projected_formal_seconds": first_elapsed
        * float(deployment["smoke"]["formal_runtime_projection_multiplier"]),
    }


def run_smoke(
    *,
    deployment_path: Path = DEFAULT_CONFIG,
    external_manifest_path: Path | None = None,
) -> dict[str, Any]:
    started = time.perf_counter()
    deployment = deployment_common.load_deployment(deployment_path)
    report_path = deployment_common.resolve_root_relative(
        deployment["outputs"]["smoke_report"]
    )
    if report_path.exists():
        raise FileExistsError(f"refusing to replace HPC smoke report: {report_path}")
    manifest_path = external_manifest_path or (
        ROOT / "_transport" / deployment["outputs"]["bundle_manifest_name"]
    )
    base_report: dict[str, Any] = {
        "schema_version": "tukf19_hpc_smoke_report_v1",
        "deployment_id": deployment["deployment_id"],
        "scientific_experiment_id": deployment["scientific_experiment_id"],
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "deployment_config_sha256": deployment_common.sha256_file(deployment_path),
    }
    try:
        package = verify_extracted_payload(ROOT, manifest_path)
        contract = scientific.load_contract()
        numeric = run_numeric_smoke(deployment, contract)
        environment = _environment_report()
        memory_gib = float(psutil.virtual_memory().available / (1024**3))
        storage_gib = float(shutil.disk_usage(ROOT).free / (1024**3))
        rss_gib = float(psutil.Process().memory_info().rss / (1024**3))
        elapsed = time.perf_counter() - started
        thread_expected = deployment["slurm"]["thread_environment"]
        checks = {
            "payload_integrity": package["verified_member_count"] > 0,
            "scientific_contract": contract["experiment_id"]
            == deployment["scientific_experiment_id"],
            "environment_imports": all(
                environment[name]
                for name in ("numpy", "torch", "psutil", "matplotlib")
            ),
            "single_torch_thread": int(environment["torch_threads"]) == 1,
            "thread_environment": environment["thread_environment"]
            == thread_expected,
            "available_memory": memory_gib
            >= float(deployment["smoke"]["minimum_available_memory_gib"]),
            "free_storage": storage_gib
            >= float(deployment["smoke"]["minimum_free_storage_gib"]),
            "finite_resident_memory": math.isfinite(rss_gib) and rss_gib > 0.0,
            "deterministic_repetition": bool(numeric["deterministic"]),
            "numerical_reference": all(numeric["reference_checks"].values()),
            "sealed_test_boundary": int(numeric["test_origin_queries"]) == 0
            and int(numeric["clean_target_queries"]) == 0,
            "smoke_runtime": elapsed
            <= float(deployment["smoke"]["maximum_smoke_elapsed_seconds"]),
            "formal_runtime_projection": float(numeric["projected_formal_seconds"])
            <= float(deployment["smoke"]["maximum_projected_formal_seconds"]),
            "formal_result_absent": not scientific.resolve_output_path(
                contract, contract["outputs"]["result_root"]
            ).exists(),
            "formal_figure_absent": not scientific.resolve_output_path(
                contract, contract["outputs"]["figure_root"]
            ).exists(),
        }
        report = {
            **base_report,
            "status": "HPC_SMOKE_PASS" if all(checks.values()) else "HPC_SMOKE_FAIL",
            "checks": checks,
            "bundle_sha256": package["bundle_sha256"],
            "package": package,
            "environment": environment,
            "resources": {
                "available_memory_gib": memory_gib,
                "free_storage_gib": storage_gib,
                "resident_memory_gib": rss_gib,
            },
            "numeric": numeric,
            "elapsed_seconds": elapsed,
            "finished_at_utc": datetime.now(timezone.utc).isoformat(),
        }
    except BaseException as error:
        report = {
            **base_report,
            "status": "HPC_SMOKE_ERROR",
            "checks": {"completed_without_exception": False},
            "error_type": type(error).__name__,
            "error": str(error),
            "traceback": traceback.format_exc(),
            "elapsed_seconds": time.perf_counter() - started,
            "finished_at_utc": datetime.now(timezone.utc).isoformat(),
        }
    deployment_common.write_new_json(report_path, report)
    return report


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--bundle-manifest", type=Path)
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    report = run_smoke(
        deployment_path=args.config.resolve(),
        external_manifest_path=(
            args.bundle_manifest.resolve() if args.bundle_manifest else None
        ),
    )
    print(
        json.dumps(
            {"status": report["status"], "checks": report["checks"]},
            sort_keys=True,
        )
    )
    return 0 if report["status"] == "HPC_SMOKE_PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
