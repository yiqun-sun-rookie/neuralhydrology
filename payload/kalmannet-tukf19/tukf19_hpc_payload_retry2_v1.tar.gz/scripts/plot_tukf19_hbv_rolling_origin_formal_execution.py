"""Create TUKF19 figures only after complete independent formal verification."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any, Mapping


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import tukf19_hbv_rolling_origin_formal_common as common  # noqa: E402
from scripts import plot_tukf17_hbv_rolling_origin_state_hydrology_update as engine  # noqa: E402


DEFAULT_CONFIG = common.DEFAULT_CONFIG


def create_verified_figures(
    contract: Mapping[str, Any], *, contract_path: Path = DEFAULT_CONFIG
) -> dict[str, Any]:
    common.validate_contract(contract, registration_path=contract_path)
    registration = common.read_registration(contract_path)
    if not bool(
        registration["authorization"]["verified_figure_generation_authorized"]
    ):
        raise PermissionError("TUKF19 verified figure generation is not authorized")
    result_root = common.resolve_output_path(
        contract, contract["outputs"]["result_root"]
    )
    verification = common.read_json(result_root / "independent_verification.json")
    if (
        verification.get("status") != "FORMAL_VERIFIED"
        or not verification.get("checks")
        or not all(verification["checks"].values())
    ):
        raise PermissionError("figures require TUKF19 status FORMAL_VERIFIED")
    engine.common = common
    figure_data = engine.create_figures(contract)
    figure_root = common.resolve_output_path(
        contract, contract["outputs"]["figure_root"]
    )
    files = {
        path.relative_to(figure_root).as_posix(): common.sha256_file(path)
        for path in sorted(figure_root.rglob("*"))
        if path.is_file() and path.name != "manifest.json"
    }
    manifest = {
        "schema_version": "tukf19_verified_figure_manifest_v1",
        "experiment_id": common.EXPERIMENT_ID,
        "status": "VERIFIED_FIGURES_COMPLETE",
        "configuration_sha256": common.sha256_file(contract_path),
        "source_sha256": common.source_hashes(contract, contract_path),
        "registry_sha256": common.sha256_file(result_root / "registry.json"),
        "independent_verification_sha256": common.sha256_file(
            result_root / "independent_verification.json"
        ),
        "files": files,
    }
    common.write_new_json(figure_root / "manifest.json", manifest)
    return {**figure_data, "manifest": manifest}


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    contract_path = args.config.resolve()
    contract = common.load_contract(contract_path)
    result = create_verified_figures(contract, contract_path=contract_path)
    print(
        json.dumps(
            {
                "status": result["manifest"]["status"],
                "selected_pair": result["selected_pair"],
                "files": result["files"],
            },
            ensure_ascii=False,
            sort_keys=True,
            allow_nan=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
