"""Run the TUKF17 rolling-origin state/hydrology comparison.

The command exposes preflight and formal stages, but formal execution requires
an explicit runtime confirmation in addition to the frozen configuration.
Importing this module performs no work and creates no output.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import shutil
import sys
import time
from typing import Any, Mapping, Sequence

import numpy as np
import psutil
import torch


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import tukf17_hbv_rolling_origin_state_hydrology_common as common  # noqa: E402


DEFAULT_CONFIG = common.DEFAULT_CONFIG
EXPERIMENT_ID = common.EXPERIMENT_ID
DTYPE = torch.float64
DEVICE = torch.device("cpu")


def _source_paths(contract_path: Path) -> tuple[Path, ...]:
    relative = (
        "scripts/tukf17_hbv_rolling_origin_state_hydrology_common.py",
        "scripts/run_tukf17_hbv_rolling_origin_state_hydrology_update.py",
        "scripts/verify_tukf17_hbv_rolling_origin_state_hydrology_update.py",
        "scripts/plot_tukf17_hbv_rolling_origin_state_hydrology_update.py",
        "tests/test_tukf17_hbv_rolling_origin_state_hydrology_update.py",
        "tests/test_tukf17_hbv_rolling_origin_mechanics.py",
        "tests/test_tukf17_hbv_rolling_origin_runner.py",
        "tests/test_verify_tukf17_hbv_rolling_origin_state_hydrology_update.py",
    )
    paths = (contract_path.resolve(), *(ROOT / value for value in relative))
    missing = [path for path in paths if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"TUKF17 source closure is incomplete: {missing}")
    return tuple(paths)


def source_hashes(contract: Mapping[str, Any], contract_path: Path) -> dict[str, str]:
    result = {
        path.relative_to(ROOT).as_posix(): common.sha256_file(path)
        for path in _source_paths(contract_path)
    }
    for raw, expected in contract["readonly_input_sha256"].items():
        path = common.resolve_readonly_input(contract, raw)
        actual = common.sha256_file(path)
        if actual != str(expected):
            raise ValueError(f"read-only input SHA-256 mismatch: {raw}")
        result[f"readonly:{raw}"] = actual
    return result


def other_formal_controller_pids() -> list[int]:
    current = os.getpid()
    result: list[int] = []
    for process in psutil.process_iter(["pid", "cmdline"]):
        try:
            pid = int(process.info["pid"])
            if pid == current:
                continue
            command = " ".join(process.info.get("cmdline") or []).lower()
        except (psutil.NoSuchProcess, psutil.AccessDenied, TypeError, ValueError):
            continue
        if ("run_tukf" in command or "verify_tukf" in command) and (
            "--stage formal" in command or "--confirm-formal-training" in command
        ):
            result.append(pid)
    return sorted(set(result))


def resource_admission(contract: Mapping[str, Any]) -> dict[str, Any]:
    required = contract["resources"]
    memory_gib = psutil.virtual_memory().available / (1024**3)
    storage_gib = shutil.disk_usage(ROOT).free / (1024**3)
    controllers = other_formal_controller_pids()
    checks = {
        "available_memory": memory_gib
        >= float(required["minimum_available_memory_gib"]),
        "workspace_free_storage": storage_gib
        >= float(required["minimum_workspace_free_storage_gib"]),
        "other_active_formal_controllers": len(controllers)
        <= int(required["maximum_other_active_formal_controllers"]),
    }
    return {
        "status": "RESOURCE_ADMITTED" if all(checks.values()) else "RESOURCE_HOLD",
        "checks": checks,
        "available_memory_gib": memory_gib,
        "workspace_free_storage_gib": storage_gib,
        "other_active_formal_controller_pids": controllers,
    }


def configure_method_(model, method: str) -> None:
    """Give gradients only to the twelve hydrologic coordinates when allowed."""

    if method not in common.PIPELINE_ORDER:
        raise ValueError(f"unknown TUKF17 pipeline: {method}")
    if int(model.hydrology_coordinates.numel()) != 12:
        raise RuntimeError("TUKF17 requires exactly twelve hydrologic coordinates")
    if int(model.log_process_diagonal.numel()) != 8:
        raise RuntimeError("TUKF17 requires exactly eight process-noise values")
    if int(model.log_observation_ratio.numel()) != 1:
        raise RuntimeError("TUKF17 requires exactly one observation-noise ratio")
    learn_hydrology = bool(
        common._expected_pipeline_masks()[method]["learn_hydrology"]
    )
    model.hydrology_coordinates.grad = None
    model.hydrology_coordinates.requires_grad_(learn_hydrology)
    for parameter in (model.log_process_diagonal, model.log_observation_ratio):
        parameter.grad = None
        parameter.requires_grad_(False)


def build_optimizer(
    model, method: str, contract: Mapping[str, Any]
) -> torch.optim.Adam | None:
    if method not in common.PIPELINE_ORDER:
        raise ValueError(f"unknown TUKF17 pipeline: {method}")
    if not bool(common._expected_pipeline_masks()[method]["learn_hydrology"]):
        return None
    values = contract["optimizer"]
    return torch.optim.Adam(
        [
            {
                "params": [model.hydrology_coordinates],
                "lr": float(values["hydrology_learning_rate"]),
                "group_name": "hydrology",
            }
        ],
        betas=tuple(float(value) for value in values["betas"]),
        eps=float(values["epsilon"]),
        weight_decay=float(values["weight_decay"]),
        amsgrad=bool(values["amsgrad"]),
    )


def _assert_noise_and_structure_unchanged(
    initial: Mapping[str, Any], current: Mapping[str, Any]
) -> None:
    for key in (
        "log_process",
        "log_observation",
        "process_diagonal",
        "observation_ratio",
        "lag_time",
        "state_dimension",
    ):
        if not np.array_equal(np.asarray(initial[key]), np.asarray(current[key])):
            raise RuntimeError(f"frozen filter or structure value changed: {key}")


def _snapshot_hash(snapshot: Mapping[str, Any]) -> str:
    return common.sha256_arrays(snapshot)


def _load_snapshot(path: Path | str) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as archive:
        return {name: np.asarray(archive[name]).copy() for name in archive.files}


def select_checkpoint(rows: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    values = [
        {"update": int(row["update"]), "selection_loss": float(row["selection_loss"])}
        for row in rows
    ]
    if not values:
        raise ValueError("selection history is empty")
    updates = tuple(row["update"] for row in values)
    if len(values) == 1:
        if updates != (0,):
            raise ValueError("a nonlearning pipeline must select update zero")
    elif updates != tuple(range(0, 97, 4)):
        raise ValueError("trainable selection queries must be 0,4,...,96")
    if not all(
        math.isfinite(row["selection_loss"]) and row["selection_loss"] >= 0.0
        for row in values
    ):
        raise ValueError("selection losses must be finite and nonnegative")
    return min(values, key=lambda row: (row["selection_loss"], row["update"]))


def _tensor_inputs(
    contract: Mapping[str, Any], forcing: np.ndarray, observations: np.ndarray
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    forcing_tensor = torch.as_tensor(forcing, dtype=DTYPE, device=DEVICE)
    observation_tensor = torch.as_tensor(observations, dtype=DTYPE, device=DEVICE)
    initial_state = torch.as_tensor(
        contract["truth_and_filter"]["initial_state"], dtype=DTYPE, device=DEVICE
    )
    covariance = torch.eye(8, dtype=DTYPE, device=DEVICE) * float(
        contract["truth_and_filter"]["initial_covariance_diagonal"]
    )
    return forcing_tensor, observation_tensor, initial_state, covariance


def run_method_training(
    contract: Mapping[str, Any],
    model,
    method: str,
    *,
    forcing: np.ndarray,
    observations: np.ndarray,
    directory: Path | None = None,
) -> dict[str, Any]:
    """Train/select one pipeline using noisy train/selection targets only."""

    if directory is not None and directory.exists():
        raise FileExistsError(f"refusing to replace method directory: {directory}")
    configure_method_(model, method)
    optimizer = build_optimizer(model, method, contract)
    supplied_end = (
        max(common.origin_indices(contract, "selection")) + max(common.LEADS) + 1
    )
    forcing = np.asarray(forcing, dtype=np.float64)
    observations = np.asarray(observations, dtype=np.float64)
    if forcing.shape[0] < supplied_end or observations.shape[0] < supplied_end:
        raise ValueError("training inputs do not cover the complete selection targets")
    forcing = np.ascontiguousarray(forcing[:supplied_end])
    observations = np.ascontiguousarray(observations[:supplied_end])
    forcing_tensor, observation_tensor, initial_state, covariance = _tensor_inputs(
        contract, forcing, observations
    )
    state_update = bool(contract["pipeline_masks"][method]["state_update"])
    base_variance = float(contract["truth_and_filter"]["base_observation_variance"])
    initial_snapshot = common.snapshot_model(model)
    snapshots: dict[int, dict[str, Any]] = {}
    selection_rows: list[dict[str, Any]] = []
    training_rows: list[dict[str, Any]] = []

    def register(update: int) -> None:
        with torch.no_grad():
            loss, details = common.rolling_origin_objective(
                model,
                forcing_tensor,
                observation_tensor,
                initial_state,
                covariance,
                common.origin_indices(contract, "selection"),
                state_update=state_update,
                targets=observation_tensor,
                base_observation_variance=base_variance,
            )
        snapshot = common.snapshot_model(model)
        _assert_noise_and_structure_unchanged(initial_snapshot, snapshot)
        selection_rows.append(
            {
                "update": int(update),
                "selection_loss": float(loss),
                "snapshot_sha256": _snapshot_hash(snapshot),
                "selection_mse_by_lead": {
                    str(lead): float(details["mse_by_lead"][lead])
                    for lead in common.LEADS
                },
            }
        )
        snapshots[int(update)] = snapshot

    register(0)
    optimizer_steps = 0
    if optimizer is not None:
        for update in range(1, int(contract["optimizer"]["updates"]) + 1):
            optimizer.zero_grad(set_to_none=True)
            loss, _ = common.rolling_origin_objective(
                model,
                forcing_tensor,
                observation_tensor,
                initial_state,
                covariance,
                common.origin_indices(contract, "train"),
                state_update=state_update,
                targets=observation_tensor,
                base_observation_variance=base_variance,
            )
            loss.backward()
            gradient = model.hydrology_coordinates.grad
            if gradient is None or not bool(torch.isfinite(gradient).all()):
                raise FloatingPointError("hydrology gradient is missing or non-finite")
            if model.log_process_diagonal.grad is not None or model.log_observation_ratio.grad is not None:
                raise RuntimeError("frozen filter-noise parameter received a gradient")
            norm = float(
                torch.nn.utils.clip_grad_norm_(
                    [model.hydrology_coordinates],
                    float(contract["optimizer"]["group_gradient_norm"]),
                )
            )
            if not math.isfinite(norm):
                raise FloatingPointError("hydrology gradient norm is non-finite")
            optimizer.step()
            optimizer_steps += 1
            model.project_trainable_coordinates_()
            current = common.snapshot_model(model)
            _assert_noise_and_structure_unchanged(initial_snapshot, current)
            training_rows.append(
                {
                    "update": update,
                    "training_loss": float(loss.detach()),
                    "gradient_nonzero_count": int(torch.count_nonzero(gradient).item()),
                    "gradient_norm_before_clipping": norm,
                }
            )
            if update in contract["selection"]["query_updates"]:
                register(update)
    selected = select_checkpoint(selection_rows)
    selected_snapshot = common.copy_snapshot(snapshots[int(selected["update"])])
    common.restore_model_(model, selected_snapshot)
    _assert_noise_and_structure_unchanged(initial_snapshot, selected_snapshot)
    result: dict[str, Any] = {
        "method": method,
        "selected": selected,
        "selected_snapshot": selected_snapshot,
        "selected_snapshot_sha256": _snapshot_hash(selected_snapshot),
        "initial_snapshot_sha256": _snapshot_hash(initial_snapshot),
        "optimizer_step_count": optimizer_steps,
        "selection_query_count": len(selection_rows),
        "training_rows": training_rows,
        "selection_rows": selection_rows,
        "test_observation_input_count": 0,
        "clean_target_query_count": 0,
        "maximum_observation_index_supplied": supplied_end - 1,
        "filter_noise_parameters_unchanged": True,
    }
    if directory is not None:
        directory.mkdir(parents=True, exist_ok=False)
        checkpoint_directory = directory / "selection_checkpoints"
        checkpoint_directory.mkdir(exist_ok=False)
        rows_by_update = {
            int(row["update"]): row for row in selection_rows
        }
        for update, snapshot in sorted(snapshots.items()):
            query_path = checkpoint_directory / f"update_{update:03d}.npz"
            common.write_new_npz(query_path, snapshot)
            rows_by_update[update].update(
                {
                    "checkpoint_file": query_path.relative_to(directory).as_posix(),
                    "checkpoint_file_sha256": common.sha256_file(query_path),
                }
            )
        checkpoint_path = directory / "selected_checkpoint.npz"
        common.write_new_npz(checkpoint_path, selected_snapshot)
        history_payload = {
            key: value
            for key, value in result.items()
            if key != "selected_snapshot"
        }
        history_payload.update(
            {
                "schema_version": "tukf17_method_history_v1",
                "experiment_id": EXPERIMENT_ID,
                "checkpoint_file": checkpoint_path.name,
                "checkpoint_file_sha256": common.sha256_file(checkpoint_path),
            }
        )
        common.write_new_json(directory / "history.json", history_payload)
        result["checkpoint_path"] = checkpoint_path
        result["checkpoint_file_sha256"] = common.sha256_file(checkpoint_path)
    return result


def write_global_selection_seal(
    root: Path,
    contract: Mapping[str, Any],
    cells: Sequence[Mapping[str, Any]],
    *,
    source_sha256: Mapping[str, str],
) -> dict[str, Any]:
    expected = int(
        contract["seals_and_budget"]["sealed_primary_pipeline_checkpoints"]
    )
    if len(cells) != expected:
        raise RuntimeError(f"global selection requires {expected} method checkpoints")
    identities = {
        (int(row["truth_seed"]), str(row["start_id"]), str(row["method"]))
        for row in cells
    }
    pairs = {(seed, start) for seed, start, _ in identities}
    if (
        len(identities) != expected
        or len(pairs) != 27
        or len({seed for seed, _ in pairs}) != 27
        or {method for _, _, method in identities} != set(common.PIPELINE_ORDER)
    ):
        raise RuntimeError("global selection identities are incomplete or non-independent")
    optimizer_steps = sum(int(row["optimizer_step_count"]) for row in cells)
    selection_queries = sum(int(row["selection_query_count"]) for row in cells)
    if optimizer_steps != int(contract["seals_and_budget"]["real_optimizer_updates"]):
        raise RuntimeError("optimizer update count differs from the frozen budget")
    if selection_queries != int(contract["seals_and_budget"]["selection_queries"]):
        raise RuntimeError("selection query count differs from the frozen budget")
    if any(
        int(row["test_observation_input_count"]) != 0
        or int(row["clean_target_query_count"]) != 0
        for row in cells
    ):
        raise PermissionError("test information was accessed before global selection")
    for row in cells:
        learns = bool(contract["pipeline_masks"][str(row["method"])]["learn_hydrology"])
        selected_update = int(row["selected"]["update"])
        if not learns and selected_update != 0:
            raise RuntimeError("nonlearning pipelines must seal update zero")
        if learns and selected_update not in contract["selection"]["query_updates"]:
            raise RuntimeError("trainable pipeline selected an unqueried update")
    seal = {
        "schema_version": "tukf17_global_selection_seal_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "GLOBAL_SELECTION_SEALED",
        "completed_method_checkpoints": len(cells),
        "optimizer_step_count": optimizer_steps,
        "selection_query_count": selection_queries,
        "test_observation_inputs_before_seal": 0,
        "clean_target_queries_before_seal": 0,
        "source_sha256": dict(source_sha256),
        "cells": [
            {
                "truth_seed": int(row["truth_seed"]),
                "start_id": str(row["start_id"]),
                "method": str(row["method"]),
                "selected_update": int(row["selected"]["update"]),
                "selected_selection_loss": float(row["selected"]["selection_loss"]),
                "selected_snapshot_sha256": str(row["selected_snapshot_sha256"]),
                "checkpoint_path": str(Path(row["checkpoint_path"]).relative_to(root).as_posix()),
                "checkpoint_file_sha256": str(row["checkpoint_file_sha256"]),
            }
            for row in cells
        ],
    }
    common.write_new_json(root / "selection_seal.json", seal)
    return seal


def require_complete_selection_seal(
    root: Path, contract: Mapping[str, Any]
) -> dict[str, Any]:
    path = root / "selection_seal.json"
    if not path.is_file():
        raise PermissionError("test readout requires the global selection seal")
    seal = common.read_json(path)
    if not (
        seal.get("status") == "GLOBAL_SELECTION_SEALED"
        and int(seal.get("completed_method_checkpoints", -1))
        == int(contract["seals_and_budget"]["sealed_primary_pipeline_checkpoints"])
        and int(seal.get("test_observation_inputs_before_seal", -1)) == 0
        and int(seal.get("clean_target_queries_before_seal", -1)) == 0
    ):
        raise PermissionError("global selection seal is incomplete")
    return seal


def _mse_payload(forecasts: np.ndarray, target: np.ndarray) -> tuple[dict[str, float], float]:
    if forecasts.shape != target.shape or forecasts.shape[1] != 3:
        raise ValueError("forecast and target matrices must both be [origin,3]")
    by_lead = {
        str(lead): float(np.mean(np.square(forecasts[:, index] - target[:, index])))
        for index, lead in enumerate(common.LEADS)
    }
    return by_lead, float(np.mean(list(by_lead.values())))


def evaluate_readout(
    contract: Mapping[str, Any],
    model,
    readout_id: str,
    *,
    forcing: np.ndarray,
    truth: Mapping[str, Any],
) -> tuple[dict[str, np.ndarray], dict[str, Any]]:
    """Stream test origins causally and score one frozen parameter/readout cell."""

    if readout_id not in common.READOUT_ORDER:
        raise ValueError(f"unknown test readout: {readout_id}")
    specification = contract["readout_grid"][readout_id]
    state_update = bool(specification["state_update"])
    origins = common.origin_indices(contract, "test")
    origin_set = set(origins)
    forcing_tensor, observation_tensor, initial_state, covariance = _tensor_inputs(
        contract, forcing, np.asarray(truth["observations"], dtype=np.float64)
    )
    base_variance = float(contract["truth_and_filter"]["base_observation_variance"])
    origin_states: list[torch.Tensor] = []
    prior_states: list[torch.Tensor] = []
    prior_covariances: list[torch.Tensor] = []
    posterior_covariances: list[torch.Tensor] = []
    forecasts: dict[int, list[torch.Tensor]] = {lead: [] for lead in common.LEADS}
    prior_forecasts: dict[int, list[torch.Tensor]] = {
        lead: [] for lead in common.LEADS
    }

    if state_update:
        mean = initial_state.reshape(1, -1)
        cov = covariance.reshape(1, 8, 8)
        for day in range(max(origins) + 1):
            trace = common.rollout_state_update_trace(
                model,
                forcing_tensor[day : day + 1],
                observation_tensor[day : day + 1],
                mean,
                cov,
                base_observation_variance=base_variance,
            )
            prior = trace["prior_state"][0, 0]
            posterior = trace["posterior_state"][0, 0]
            mean = trace["posterior_state"][0]
            cov = trace["posterior_covariance"][0]
            if day in origin_set:
                prior_states.append(prior)
                origin_states.append(posterior)
                prior_covariances.append(trace["prior_covariance"][0, 0])
                posterior_covariances.append(trace["posterior_covariance"][0, 0])
                post = common.forecast_from_origin_states(
                    model, posterior.reshape(1, -1), forcing_tensor, (day,)
                )
                pre = common.forecast_from_origin_states(
                    model, prior.reshape(1, -1), forcing_tensor, (day,)
                )
                for lead in common.LEADS:
                    forecasts[lead].append(post[lead][0])
                    prior_forecasts[lead].append(pre[lead][0])
    else:
        replay = common.rollout_open_loop_states(
            model, forcing_tensor, initial_state, max(origins) + 1
        )
        selected = replay[
            torch.as_tensor([origin + 1 for origin in origins], dtype=torch.long)
        ]
        origin_states = [row for row in selected]
        issued = common.forecast_from_origin_states(
            model, selected, forcing_tensor, origins
        )
        for lead in common.LEADS:
            forecasts[lead] = [value for value in issued[lead]]

    forecast_matrix = np.column_stack(
        [
            torch.stack(forecasts[lead]).detach().cpu().numpy()
            for lead in common.LEADS
        ]
    )
    origin_array = np.asarray(origins, dtype=np.int64)
    clean = np.asarray(truth["clean_discharge"], dtype=np.float64)
    observed = np.asarray(truth["observations"], dtype=np.float64)
    clean_targets = np.column_stack([clean[origin_array + lead] for lead in common.LEADS])
    observed_targets = np.column_stack(
        [observed[origin_array + lead] for lead in common.LEADS]
    )
    clean_by_lead, clean_mean = _mse_payload(forecast_matrix, clean_targets)
    observed_by_lead, observed_mean = _mse_payload(forecast_matrix, observed_targets)
    state_array = torch.stack(origin_states).detach().cpu().numpy()
    state_metrics = common.state_error_metrics(
        state_array, np.asarray(truth["states"], dtype=np.float64), origins
    )
    arrays: dict[str, np.ndarray] = {
        "origins": origin_array,
        "forecasts": np.ascontiguousarray(forecast_matrix),
        "clean_targets": np.ascontiguousarray(clean_targets),
        "observed_targets": np.ascontiguousarray(observed_targets),
        "origin_states": np.ascontiguousarray(state_array),
        "standardized_state_error": np.asarray(state_metrics["standardized_error"]),
        "complete_state_error_by_origin": np.asarray(
            state_metrics["complete_error_by_origin"]
        ),
    }
    metrics: dict[str, Any] = {
        "readout_id": readout_id,
        "parameter_set": specification["parameter_set"],
        "state_update": state_update,
        "primary_pipeline": bool(specification["primary_pipeline"]),
        "primary_clean_mse": clean_mean,
        "primary_clean_mse_by_lead": clean_by_lead,
        "secondary_observed_mse": observed_mean,
        "secondary_observed_mse_by_lead": observed_by_lead,
        "primary_clean_error_count": int(clean_targets.size),
        "complete_state_rmse": float(state_metrics["complete_rmse"]),
        "per_state_rmse": np.asarray(state_metrics["per_state_rmse"]).tolist(),
        "online_parameter_update_count": 0,
    }
    if state_update:
        prior_array = torch.stack(prior_states).detach().cpu().numpy()
        prior_covariance_array = torch.stack(prior_covariances).detach().cpu().numpy()
        posterior_covariance_array = torch.stack(posterior_covariances).detach().cpu().numpy()
        prior_matrix = np.column_stack(
            [
                torch.stack(prior_forecasts[lead]).detach().cpu().numpy()
                for lead in common.LEADS
            ]
        )
        prior_state_metrics = common.state_error_metrics(
            prior_array, np.asarray(truth["states"], dtype=np.float64), origins
        )
        prior_error = np.square(prior_matrix - clean_targets)
        posterior_error = np.square(forecast_matrix - clean_targets)
        arrays.update(
            {
                "prior_origin_states": np.ascontiguousarray(prior_array),
                "prior_standardized_state_error": np.asarray(
                    prior_state_metrics["standardized_error"]
                ),
                "prior_complete_state_error_by_origin": np.asarray(
                    prior_state_metrics["complete_error_by_origin"]
                ),
                "prior_origin_covariances": np.ascontiguousarray(prior_covariance_array),
                "posterior_origin_covariances": np.ascontiguousarray(
                    posterior_covariance_array
                ),
                "prior_counterfactual_forecasts": np.ascontiguousarray(prior_matrix),
                "prior_counterfactual_clean_squared_error": np.ascontiguousarray(
                    prior_error
                ),
                "posterior_counterfactual_clean_squared_error": np.ascontiguousarray(
                    posterior_error
                ),
            }
        )
        metrics["prior_complete_state_rmse"] = float(
            prior_state_metrics["complete_rmse"]
        )
        metrics["prior_per_state_rmse"] = np.asarray(
            prior_state_metrics["per_state_rmse"]
        ).tolist()
        prior_complete = float(prior_state_metrics["complete_rmse"])
        metrics["posterior_over_prior_complete_state_rmse"] = (
            float(state_metrics["complete_rmse"] / prior_complete)
            if prior_complete > 0.0
            else None
        )
        posterior_per_state = np.asarray(state_metrics["per_state_rmse"])
        prior_per_state = np.asarray(prior_state_metrics["per_state_rmse"])
        metrics["posterior_over_prior_per_state_rmse"] = [
            float(posterior / prior) if prior > 0.0 else None
            for posterior, prior in zip(posterior_per_state, prior_per_state)
        ]
        metrics["single_update_clean_mse_prior_by_lead"] = {
            str(lead): float(np.mean(prior_error[:, index]))
            for index, lead in enumerate(common.LEADS)
        }
        metrics["single_update_clean_mse_posterior_by_lead"] = {
            str(lead): float(np.mean(posterior_error[:, index]))
            for index, lead in enumerate(common.LEADS)
        }
        metrics["released_observation_count"] = max(origins) + 1
    else:
        metrics["released_observation_count"] = 0
    if metrics["primary_clean_error_count"] != int(
        contract["seals_and_budget"]["primary_errors_per_readout_unit"]
    ):
        raise RuntimeError("test readout did not produce exactly 42 x 3 clean errors")
    return arrays, metrics


def _balance_errors(
    contract: Mapping[str, Any], registry: Mapping[str, Any]
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    pairs = common.registered_pairs(contract, registry)
    arrays = {
        "E00": np.empty((27, 2, 3), dtype=np.float64),
        "E01": np.empty((27, 2, 3), dtype=np.float64),
        "E10": np.empty((27, 2, 3), dtype=np.float64),
        "E11": np.empty((27, 2, 3), dtype=np.float64),
    }
    for pair_index, (seed, start_id) in enumerate(pairs):
        forcing, truth = common.generate_truth_for_seed(contract, seed)
        observations = np.asarray(truth["observations"], dtype=np.float64)
        forcing_tensor, observation_tensor, initial_state, covariance = _tensor_inputs(
            contract, forcing, observations
        )
        models = {
            "E00": common.build_model(
                contract, start_id, hydrology_source="truth", filter_source="truth"
            ),
            "E01": common.build_model(
                contract, start_id, hydrology_source="truth", filter_source="initial"
            ),
            "E10": common.build_model(
                contract, start_id, hydrology_source="initial", filter_source="truth"
            ),
            "E11": common.build_model(
                contract, start_id, hydrology_source="initial", filter_source="initial"
            ),
        }
        for window_index, split in enumerate(("train", "selection")):
            for label, model in models.items():
                with torch.no_grad():
                    _, details = common.rolling_origin_objective(
                        model,
                        forcing_tensor,
                        observation_tensor,
                        initial_state,
                        covariance,
                        common.origin_indices(contract, split),
                        state_update=True,
                        targets=observation_tensor,
                        base_observation_variance=float(
                            contract["truth_and_filter"]["base_observation_variance"]
                        ),
                    )
                arrays[label][pair_index, window_index] = np.asarray(
                    [float(details["mse_by_lead"][lead]) for lead in common.LEADS]
                )
    return arrays["E00"], arrays["E01"], arrays["E10"], arrays["E11"]


def run_preflight(
    contract: Mapping[str, Any], *, contract_path: Path = DEFAULT_CONFIG
) -> dict[str, Any]:
    validation = common.validate_contract(contract)
    root = common.resolve_output_path(contract, contract["outputs"]["preflight_root"])
    result_root = common.resolve_output_path(contract, contract["outputs"]["result_root"])
    if root.exists():
        raise FileExistsError(f"refusing to replace preflight root: {root}")
    if result_root.exists():
        raise FileExistsError(f"formal result root already exists: {result_root}")
    root.mkdir(parents=True, exist_ok=False)
    seed_registry = common.freeze_seed_registry(
        contract,
        destination=root / "seed_registry.json",
        configuration_path=contract_path,
    )
    e00, e01, e10, e11 = _balance_errors(contract, seed_registry)
    common.write_new_npz(
        root / "balance_errors.npz",
        {"E00": e00, "E01": e01, "E10": e10, "E11": e11},
    )
    balance = common.classify_balance_arrays(e00, e01, e10, e11, contract)
    common.write_new_json(root / "balance_gate.json", balance)
    resources = resource_admission(contract)
    sources = source_hashes(contract, contract_path)
    report = {
        "schema_version": "tukf17_engineering_preflight_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": (
            "PREFLIGHT_ENGINEERING_PASS"
            if balance["status"] == "BALANCE_PASS"
            else "BALANCE_HOLD"
        ),
        "validation": validation,
        "balance_status": balance["status"],
        "resource_status": resources["status"],
        "resources": resources,
        "source_sha256": sources,
        "config_sha256": common.sha256_file(contract_path),
        "seed_registry_sha256": common.sha256_file(root / "seed_registry.json"),
        "balance_gate_sha256": common.sha256_file(root / "balance_gate.json"),
        "balance_errors_sha256": common.sha256_file(root / "balance_errors.npz"),
        "test_metric_queries": 0,
        "formal_optimizer_updates": 0,
        "formal_training_authorized": False,
    }
    common.write_new_json(root / "preflight.json", report)
    return report


def _require_verified_preflight(
    contract: Mapping[str, Any], contract_path: Path
) -> tuple[dict[str, Any], dict[str, Any]]:
    root = common.resolve_output_path(contract, contract["outputs"]["preflight_root"])
    preflight = common.read_json(root / "preflight.json")
    verification = common.read_json(root / "independent_verification.json")
    if preflight.get("status") != "PREFLIGHT_ENGINEERING_PASS":
        raise PermissionError("formal training requires a passing balance gate")
    if verification.get("status") != "PREFLIGHT_VERIFIED" or not all(
        verification.get("checks", {}).values()
    ):
        raise PermissionError("formal training requires independent preflight verification")
    if preflight.get("source_sha256") != source_hashes(contract, contract_path):
        raise RuntimeError("source files changed after preflight")
    if preflight.get("config_sha256") != common.sha256_file(contract_path):
        raise RuntimeError("configuration changed after preflight")
    return preflight, verification


def _root_manifest(root: Path) -> dict[str, Any]:
    return {
        "schema_version": "tukf17_root_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "files": {
            path.relative_to(root).as_posix(): common.sha256_file(path)
            for path in sorted(root.rglob("*"))
            if path.is_file() and path.name != "manifest.json"
        },
    }


def _archive_failed_formal_attempt(
    contract: Mapping[str, Any], error: BaseException
) -> Path | None:
    root = common.resolve_output_path(contract, contract["outputs"]["result_root"])
    identity_path = root / "attempt_identity.json"
    if not identity_path.is_file():
        return None
    identity = common.read_json(identity_path)
    if int(identity.get("controller_pid", -1)) != os.getpid():
        return None
    if (root / "registry.json").is_file() and (root / "manifest.json").is_file():
        return None
    failed_root = common.resolve_output_path(
        contract, contract["outputs"]["failed_result_root"]
    )
    failed_root.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
    attempt_root = failed_root / f"attempt_{stamp}_pid_{os.getpid()}"
    attempt_root.mkdir(exist_ok=False)
    partial_root = attempt_root / "partial_result"
    root.rename(partial_root)
    common.write_new_json(
        attempt_root / "failure.json",
        {
            "schema_version": "tukf17_failed_formal_attempt_v1",
            "experiment_id": EXPERIMENT_ID,
            "status": "FORMAL_ATTEMPT_FAILED",
            "formal_started_at_utc": identity.get("formal_started_at_utc"),
            "failed_at_utc": datetime.now(timezone.utc).isoformat(),
            "controller_pid": os.getpid(),
            "exception_type": type(error).__name__,
            "exception_message": str(error),
            "partial_result_directory": "partial_result",
        },
    )
    return attempt_root


def run_formal(
    contract: Mapping[str, Any],
    *,
    contract_path: Path = DEFAULT_CONFIG,
    user_confirmed_formal_training: bool = False,
) -> dict[str, Any]:
    if not user_confirmed_formal_training:
        raise PermissionError("formal training requires separate explicit user confirmation")
    common.validate_contract(contract)
    _require_verified_preflight(contract, contract_path)
    admission = resource_admission(contract)
    if admission["status"] != "RESOURCE_ADMITTED":
        raise PermissionError("formal resource admission is on hold")
    preflight_root = common.resolve_output_path(
        contract, contract["outputs"]["preflight_root"]
    )
    seed_registry = common.read_json(preflight_root / "seed_registry.json")
    pairs = common.registered_pairs(contract, seed_registry)
    root = common.resolve_output_path(contract, contract["outputs"]["result_root"])
    if root.exists():
        raise FileExistsError(f"refusing to replace formal result root: {root}")
    sources = source_hashes(contract, contract_path)
    torch.set_num_threads(1)
    root.mkdir(parents=True, exist_ok=False)
    started_at_utc = datetime.now(timezone.utc).isoformat()
    common.write_new_json(
        root / "attempt_identity.json",
        {
            "schema_version": "tukf17_formal_attempt_identity_v1",
            "experiment_id": EXPERIMENT_ID,
            "controller_pid": os.getpid(),
            "formal_started_at_utc": started_at_utc,
        },
    )
    started = time.time()
    completed: list[dict[str, Any]] = []
    truth_cache: dict[tuple[int, str], tuple[np.ndarray, dict[str, Any]]] = {}
    for seed, start_id in pairs:
        forcing, truth = common.generate_truth_for_seed(contract, seed)
        truth_cache[(seed, start_id)] = (forcing, truth)
        observations = np.asarray(truth["observations"], dtype=np.float64)
        pair_root = root / "repetitions" / f"truth_{seed}__{start_id}"
        for method in common.PIPELINE_ORDER:
            model = common.build_model(contract, start_id)
            result = run_method_training(
                contract,
                model,
                method,
                forcing=forcing,
                observations=observations,
                directory=pair_root / "methods" / method,
            )
            completed.append(
                {
                    "truth_seed": seed,
                    "start_id": start_id,
                    **result,
                }
            )
    seal = write_global_selection_seal(
        root, contract, completed, source_sha256=sources
    )
    require_complete_selection_seal(root, contract)
    cell_index = {
        (int(row["truth_seed"]), str(row["start_id"]), str(row["method"])): row
        for row in completed
    }
    rows: list[dict[str, Any]] = []
    for seed, start_id in pairs:
        forcing, truth = truth_cache[(seed, start_id)]
        pair_root = root / "repetitions" / f"truth_{seed}__{start_id}"
        common.write_new_npz(
            pair_root / "truth_arrays.npz",
            {
                name: value
                for name, value in truth.items()
                if isinstance(value, np.ndarray)
            },
        )
        pair_rows: list[dict[str, Any]] = []
        for readout_id in common.READOUT_ORDER:
            specification = contract["readout_grid"][readout_id]
            source_method = str(specification["parameter_source_pipeline"])
            snapshot = cell_index[(seed, start_id, source_method)]["selected_snapshot"]
            model = common.build_model(contract, start_id)
            common.restore_model_(model, snapshot)
            arrays, metrics = evaluate_readout(
                contract,
                model,
                readout_id,
                forcing=forcing,
                truth=truth,
            )
            readout_root = pair_root / "readouts" / readout_id
            common.write_new_npz(readout_root / "arrays.npz", arrays)
            row = {
                "truth_seed": seed,
                "start_id": start_id,
                **metrics,
                "arrays_sha256": common.sha256_file(readout_root / "arrays.npz"),
                "parameter_snapshot_sha256": _snapshot_hash(snapshot),
            }
            common.write_new_json(readout_root / "metrics.json", row)
            rows.append(row)
            pair_rows.append(row)
        common.write_new_json(
            pair_root / "pair_metrics.json",
            {
                "schema_version": "tukf17_pair_metrics_v1",
                "truth_seed": seed,
                "start_id": start_id,
                "readouts": pair_rows,
            },
        )
    primary = common.aggregate_primary_pipelines(rows, contract)
    crossed = common.aggregate_crossed_readouts(rows, contract)
    aggregate = {"primary": primary, "crossed": crossed}
    mechanisms = common.classify_mechanisms(aggregate, contract)
    registry = {
        "schema_version": "tukf17_formal_registry_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "FORMAL_COMPLETE_AWAITING_INDEPENDENT_VERIFICATION",
        "rows": rows,
        "aggregates": aggregate,
        "mechanism_classifications": mechanisms,
        "selection_seal_sha256": common.sha256_file(root / "selection_seal.json"),
        "source_sha256_start": sources,
        "source_sha256_end": source_hashes(contract, contract_path),
        "resource_admission": admission,
        "formal_started_at_utc": started_at_utc,
        "elapsed_seconds": time.time() - started,
        "claims_not_authorized": contract["claims_not_authorized"],
    }
    common.write_new_json(root / "registry.json", registry)
    common.write_new_json(root / "manifest.json", _root_manifest(root))
    return registry


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("preflight", "formal"), required=True)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument(
        "--confirm-formal-training",
        action="store_true",
        help="Required only after the user separately authorizes formal training.",
    )
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    contract_path = args.config.resolve()
    contract = common.load_contract(contract_path)
    if args.stage == "preflight":
        if args.confirm_formal_training:
            raise PermissionError("formal confirmation cannot be attached to preflight")
        report = run_preflight(contract, contract_path=contract_path)
    else:
        formal_root_existed_before_call = common.resolve_output_path(
            contract, contract["outputs"]["result_root"]
        ).exists()
        try:
            report = run_formal(
                contract,
                contract_path=contract_path,
                user_confirmed_formal_training=bool(args.confirm_formal_training),
            )
        except BaseException as error:
            if not formal_root_existed_before_call:
                _archive_failed_formal_attempt(contract, error)
            raise
    print(
        json.dumps(
            {
                "status": report["status"],
                "resource_status": report.get("resource_status"),
                "balance_status": report.get("balance_status"),
            },
            ensure_ascii=False,
            sort_keys=True,
            allow_nan=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
