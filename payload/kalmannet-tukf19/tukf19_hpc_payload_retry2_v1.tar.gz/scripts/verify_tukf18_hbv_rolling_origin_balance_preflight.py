"""Independently recompute the preflight-only TUKF18 balance confirmation.

The verifier does not import the engineering runner.  It rechecks every seed
decision, rebuilds all four raw arrays, and recomputes all eight balance ratios.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import sys
from typing import Any, Mapping

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import tukf18_hbv_rolling_origin_balance_common as common  # noqa: E402


DEFAULT_CONFIG = common.DEFAULT_CONFIG
ABSOLUTE_TOLERANCE = 1e-11
RELATIVE_TOLERANCE = 1e-10


def _load_npz(path: Path | str) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as archive:
        return {name: np.asarray(archive[name]).copy() for name in archive.files}


def _arrays_close(left: np.ndarray, right: np.ndarray) -> bool:
    a = np.asarray(left)
    b = np.asarray(right)
    if a.shape != b.shape or a.dtype.kind != b.dtype.kind:
        return False
    if a.dtype.kind in "fc":
        return bool(
            np.allclose(
                a,
                b,
                rtol=RELATIVE_TOLERANCE,
                atol=ABSOLUTE_TOLERANCE,
                equal_nan=False,
            )
        )
    return bool(np.array_equal(a, b))


def _values_close(left: Any, right: Any) -> bool:
    if isinstance(left, Mapping) and isinstance(right, Mapping):
        return set(left) == set(right) and all(
            _values_close(left[key], right[key]) for key in left
        )
    if isinstance(left, (list, tuple)) and isinstance(right, (list, tuple)):
        return len(left) == len(right) and all(
            _values_close(a, b) for a, b in zip(left, right)
        )
    if isinstance(left, (int, float, np.number)) and isinstance(
        right, (int, float, np.number)
    ):
        return math.isclose(
            float(left),
            float(right),
            rel_tol=RELATIVE_TOLERANCE,
            abs_tol=ABSOLUTE_TOLERANCE,
        )
    return left == right


def _independent_source_hashes(
    contract: Mapping[str, Any], contract_path: Path
) -> dict[str, str]:
    paths = (
        contract_path.resolve(),
        *(ROOT / value for value in common.SOURCE_RELATIVE_PATHS),
    )
    if any(not path.is_file() for path in paths):
        raise FileNotFoundError("TUKF18 independent source closure is incomplete")
    result = {
        path.relative_to(ROOT).as_posix(): common.sha256_file(path) for path in paths
    }

    registration = common.read_registration(contract_path)
    parent = registration["parent_evidence"]
    parent_path_keys = {
        "configuration": "configuration_path",
        "runtime_common": "runtime_common_path",
        "preflight": "preflight_path",
        "balance_gate": "balance_gate_path",
        "balance_errors": "balance_errors_path",
        "seed_registry": "seed_registry_path",
        "independent_verification": "independent_verification_path",
    }
    for label, key in parent_path_keys.items():
        path = (ROOT / parent[key]).resolve()
        actual = common.sha256_file(path)
        if actual != parent[f"{label}_sha256"]:
            raise ValueError(f"TUKF18 parent evidence changed: {label}")
        result[f"parent:{label}"] = actual

    design_path = Path(registration["design_evidence"]["registry_path"]).resolve()
    design_hash = common.sha256_file(design_path)
    if design_hash != registration["design_evidence"]["registry_sha256"]:
        raise ValueError("TUKF18 design registry changed")
    result["design:TUKF15_registry"] = design_hash
    for raw, expected in contract["readonly_input_sha256"].items():
        path = common.resolve_readonly_input(contract, raw)
        actual = common.sha256_file(path)
        if actual != str(expected):
            raise ValueError(f"read-only input SHA-256 mismatch: {raw}")
        result[f"readonly:{raw}"] = actual
    return result


def _tensor_inputs(
    contract: Mapping[str, Any], forcing: np.ndarray, observations: np.ndarray
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    return (
        torch.as_tensor(forcing, dtype=torch.float64),
        torch.as_tensor(observations, dtype=torch.float64),
        torch.as_tensor(
            contract["truth_and_filter"]["initial_state"], dtype=torch.float64
        ),
        torch.eye(8, dtype=torch.float64)
        * float(contract["truth_and_filter"]["initial_covariance_diagonal"]),
    )


def independent_balance_errors(
    contract: Mapping[str, Any], registry: Mapping[str, Any]
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    pairs = common.registered_pairs(contract, registry)
    arrays = {
        name: np.empty((27, 2, 3), dtype=np.float64)
        for name in ("E00", "E01", "E10", "E11")
    }
    definitions = {
        "E00": ("truth", "truth"),
        "E01": ("truth", "initial"),
        "E10": ("initial", "truth"),
        "E11": ("initial", "initial"),
    }
    for pair_index, (seed, start_id) in enumerate(pairs):
        forcing, truth = common.generate_truth_for_seed(contract, seed)
        observations = np.asarray(truth["observations"], dtype=np.float64)
        forcing_tensor, observation_tensor, initial_state, covariance = _tensor_inputs(
            contract, forcing, observations
        )
        for label, (hydrology_source, filter_source) in definitions.items():
            model = common.build_model(
                contract,
                start_id,
                hydrology_source=hydrology_source,
                filter_source=filter_source,
            )
            for window_index, split in enumerate(("train", "selection")):
                origins = common.origin_indices(contract, split)
                with torch.no_grad():
                    _, details = common.rolling_origin_objective(
                        model,
                        forcing_tensor,
                        observation_tensor,
                        initial_state,
                        covariance,
                        origins,
                        state_update=True,
                        targets=observation_tensor,
                        base_observation_variance=float(
                            contract["truth_and_filter"]["base_observation_variance"]
                        ),
                    )
                arrays[label][pair_index, window_index] = [
                    float(details["mse_by_lead"][lead]) for lead in common.LEADS
                ]
    return arrays["E00"], arrays["E01"], arrays["E10"], arrays["E11"]


def verify_preflight(
    contract: Mapping[str, Any], *, contract_path: Path = DEFAULT_CONFIG
) -> dict[str, Any]:
    common.validate_contract(contract, registration_path=contract_path)
    root = common.resolve_output_path(contract, contract["outputs"]["preflight_root"])
    result_root = common.resolve_output_path(contract, contract["outputs"]["result_root"])
    preflight = common.read_json(root / "preflight.json")
    seed_registry = common.read_json(root / "seed_registry.json")
    stored_balance = common.read_json(root / "balance_gate.json")
    stored_errors = _load_npz(root / "balance_errors.npz")

    seed_checks = []
    for stored in seed_registry["attempted_candidates"]:
        recomputed = common.mechanically_accept_truth_seed(int(stored["seed"]), contract)
        seed_checks.append(
            all(
                _values_close(stored.get(key), recomputed.get(key))
                for key in (
                    "seed",
                    "accepted",
                    "checks",
                    "diagnostics",
                    "scientific_metric_queries",
                    "truth_array_sha256",
                    "generation_error",
                )
            )
        )
    pairs = common.registered_pairs(contract, seed_registry)
    accepted_attempts = [
        row for row in seed_registry["attempted_candidates"] if bool(row["accepted"])
    ][:27]
    expected_accepted = [
        {
            "accepted_order": index,
            "truth_seed": int(row["seed"]),
            "start_id": common.START_IDS[index - 1],
            "truth_array_sha256": row.get("truth_array_sha256"),
        }
        for index, row in enumerate(accepted_attempts, 1)
    ]

    e00, e01, e10, e11 = independent_balance_errors(contract, seed_registry)
    recomputed_balance = common.classify_balance_arrays(e00, e01, e10, e11, contract)
    attempted_seeds = [int(row["seed"]) for row in seed_registry["attempted_candidates"]]
    checks = {
        "configuration_identity": preflight.get("config_sha256")
        == common.sha256_file(contract_path),
        "source_identity": preflight.get("source_sha256")
        == _independent_source_hashes(contract, contract_path),
        "registered_one_factor_change": (
            float(preflight.get("registered_hydrology_coordinate_distance", -1.0))
            == 0.05
            and float(preflight.get("registered_filter_perturbation_factor", -1.0))
            == 8.0
        ),
        "seed_attempts_recomputed": bool(seed_checks) and all(seed_checks),
        "seed_registry_file_identity": (
            seed_registry.get("configuration_sha256")
            == common.sha256_file(contract_path)
            and seed_registry.get("truth_generator_sha256")
            == contract["readonly_input_sha256"][
                "scripts/tukf11_hbv_joint_parameter_synthetic_common.py"
            ]
            and preflight.get("seed_registry_sha256")
            == common.sha256_file(root / "seed_registry.json")
        ),
        "accepted_seed_assignment_recomputed": _values_close(
            seed_registry.get("accepted_pairs"), expected_accepted
        ),
        "accepted_seed_count_and_independence": len(pairs) == 27
        and len({seed for seed, _ in pairs}) == 27,
        "confirmation_seeds_unseen_by_tukf17": (
            bool(attempted_seeds)
            and min(attempted_seeds) >= 1801
            and not any(1701 <= seed <= 1730 for seed in attempted_seeds)
            and int(seed_registry.get("tukf17_seed_overlap_count", -1)) == 0
        ),
        "zero_scientific_queries_during_seed_selection": int(
            seed_registry.get("scientific_metric_queries", -1)
        )
        == 0,
        "balance_e00_raw_arrays": _arrays_close(stored_errors["E00"], e00),
        "balance_e01_raw_arrays": _arrays_close(stored_errors["E01"], e01),
        "balance_e10_raw_arrays": _arrays_close(stored_errors["E10"], e10),
        "balance_e11_raw_arrays": _arrays_close(stored_errors["E11"], e11),
        "balance_artifact_hashes": (
            set(stored_errors) == {"E00", "E01", "E10", "E11"}
            and preflight.get("balance_errors_sha256")
            == common.sha256_file(root / "balance_errors.npz")
            and preflight.get("balance_gate_sha256")
            == common.sha256_file(root / "balance_gate.json")
        ),
        "balance_classification_recomputed": _values_close(
            stored_balance, recomputed_balance
        ),
        "all_eight_balance_ratios_classified": int(
            recomputed_balance.get("ratio_count", -1)
        )
        == 8,
        "preflight_status_matches_balance": preflight.get("status")
        == (
            "PREFLIGHT_ENGINEERING_PASS"
            if recomputed_balance["status"] == "BALANCE_PASS"
            else "BALANCE_HOLD"
        ),
        "no_test_queries": int(preflight.get("test_metric_queries", -1)) == 0,
        "no_formal_optimizer_updates": int(
            preflight.get("formal_optimizer_updates", -1)
        )
        == 0,
        "formal_training_not_authorized": not bool(
            preflight.get("formal_training_authorized", True)
        ),
        "formal_result_root_absent": not result_root.exists(),
    }
    if all(checks.values()) and recomputed_balance["status"] == "BALANCE_PASS":
        status = "PREFLIGHT_VERIFIED"
    elif all(checks.values()):
        status = "BALANCE_HOLD_VERIFIED"
    else:
        status = "PREFLIGHT_VERIFICATION_FAILED"
    report = {
        "schema_version": "tukf18_independent_preflight_verification_v1",
        "experiment_id": common.EXPERIMENT_ID,
        "status": status,
        "checks": checks,
        "balance_status": recomputed_balance["status"],
        "accepted_seed_count": len(pairs),
        "attempted_seed_count": len(attempted_seeds),
        "test_metric_queries": 0,
        "formal_optimizer_updates": 0,
        "formal_training_authorized": False,
    }
    common.write_new_json(root / "independent_verification.json", report)
    return report


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    contract_path = args.config.resolve()
    contract = common.load_contract(contract_path)
    report = verify_preflight(contract, contract_path=contract_path)
    print(
        json.dumps(
            {"status": report["status"], "checks": report["checks"]},
            ensure_ascii=False,
            sort_keys=True,
            allow_nan=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
