"""Create the five frozen TUKF17 figure groups after formal verification."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any, Mapping

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import tukf17_hbv_rolling_origin_state_hydrology_common as common  # noqa: E402


STATE_NAMES = (
    "snow_storage",
    "snow_liquid_water",
    "soil_moisture",
    "upper_reservoir",
    "lower_reservoir",
    "runoff_memory_day_0",
    "runoff_memory_day_1",
    "runoff_memory_day_2",
)


def _load_npz(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as archive:
        return {name: np.asarray(archive[name]).copy() for name in archive.files}


def select_display_pair(registry: Mapping[str, Any]) -> dict[str, Any]:
    contrast = registry["aggregates"]["primary"]["contrasts"][
        "state_and_hydrology_update_over_no_update"
    ]
    rows = contrast["per_pair_ratios"]
    median = float(contrast["median_ratio"])
    selected = min(
        rows,
        key=lambda row: (
            abs(float(row["ratio"]) - median),
            int(row["truth_seed"]),
            str(row["start_id"]),
        ),
    )
    return {
        "truth_seed": int(selected["truth_seed"]),
        "start_id": str(selected["start_id"]),
        "ratio": float(selected["ratio"]),
        "population_median_ratio": median,
    }


def _ratio_boxplot(ax, contrasts: Mapping[str, Any], names: list[str]) -> None:
    values = [contrasts[name]["ratios"] for name in names]
    _ratio_values_boxplot(ax, values, names)


def _ratio_values_boxplot(ax, values: list[Any], labels: list[str]) -> None:
    ax.boxplot(values, tick_labels=labels, showfliers=True)
    ax.axhline(1.0, color="black", linewidth=1.0, linestyle="--")
    ax.axhline(0.9, color="#2a9d8f", linewidth=0.8, linestyle=":")
    ax.axhline(1.1, color="#e76f51", linewidth=0.8, linestyle=":")
    ax.set_ylabel("paired clean-flow MSE ratio")
    ax.tick_params(axis="x", rotation=20)


def primary_lead_boxplot_data(
    contrasts: Mapping[str, Any], contract: Mapping[str, Any]
) -> tuple[list[Any], list[str]]:
    values: list[Any] = []
    labels: list[str] = []
    for name in contract["primary_contrasts"]:
        for lead in common.LEADS:
            values.append(contrasts[name]["by_lead"][str(lead)]["ratios"])
            labels.append(f"{name}:L{lead}")
    return values, labels


def create_figures(
    contract: Mapping[str, Any], *, output_root: Path | None = None
) -> dict[str, Any]:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    result_root = common.resolve_output_path(
        contract, contract["outputs"]["result_root"]
    )
    verification = common.read_json(result_root / "independent_verification.json")
    if verification.get("status") != "FORMAL_VERIFIED" or not all(
        verification.get("checks", {}).values()
    ):
        raise PermissionError("figures require complete independent formal verification")
    registry = common.read_json(result_root / "registry.json")
    root = output_root or common.resolve_output_path(
        contract, contract["outputs"]["figure_root"]
    )
    if root.exists():
        raise FileExistsError(f"refusing to replace figure root: {root}")
    root.mkdir(parents=True, exist_ok=False)
    files: dict[str, str] = {}

    primary = registry["aggregates"]["primary"]["contrasts"]
    primary_values, primary_labels = primary_lead_boxplot_data(primary, contract)
    figure, axis = plt.subplots(figsize=(16, 6.5))
    _ratio_values_boxplot(axis, primary_values, primary_labels)
    axis.set_title("Primary rolling-origin clean-flow contrasts by forecast lead")
    figure.tight_layout()
    path = root / "primary_clean_forecast_error_ratios.png"
    figure.savefig(path, dpi=200)
    plt.close(figure)
    files["primary_clean_forecast_error_ratios"] = path.name

    crossed = registry["aggregates"]["crossed"]
    crossed_names = list(contract["fixed_parameter_state_contrasts"])
    figure, axis = plt.subplots(figsize=(10, 5.5))
    _ratio_boxplot(axis, crossed, crossed_names)
    axis.set_title("State update on/off with identical hydrologic parameters")
    figure.tight_layout()
    path = root / "fixed_parameter_state_update_comparison.png"
    figure.savefig(path, dpi=200)
    plt.close(figure)
    files["fixed_parameter_state_update_comparison"] = path.name

    pair_roots = sorted((result_root / "repetitions").glob("truth_*__start_*"))
    origin_values = np.asarray(common.origin_indices(contract, "test"), dtype=np.int64)
    figure, axis = plt.subplots(figsize=(11, 5.5))
    state_curve_data: dict[str, Any] = {}
    for readout_id in common.PIPELINE_ORDER:
        curves = np.stack(
            [
                _load_npz(pair_root / "readouts" / readout_id / "arrays.npz")[
                    "complete_state_error_by_origin"
                ]
                for pair_root in pair_roots
            ]
        )
        median = np.median(curves, axis=0)
        lower = np.quantile(curves, 0.25, axis=0)
        upper = np.quantile(curves, 0.75, axis=0)
        axis.plot(origin_values, median, label=readout_id)
        axis.fill_between(origin_values, lower, upper, alpha=0.15)
        state_curve_data[readout_id] = {
            "median": median.tolist(),
            "q25": lower.tolist(),
            "q75": upper.tolist(),
        }
    axis.set_xlabel("test origin day")
    axis.set_ylabel("complete standardized state error")
    axis.set_title("Median and interquartile complete-state error")
    axis.legend(fontsize=8)
    figure.tight_layout()
    path = root / "complete_state_error_curves.png"
    figure.savefig(path, dpi=200)
    plt.close(figure)
    files["complete_state_error_curves"] = path.name

    selected = select_display_pair(registry)
    selected_root = (
        result_root
        / "repetitions"
        / f"truth_{selected['truth_seed']}__{selected['start_id']}"
    )
    truth = _load_npz(selected_root / "truth_arrays.npz")
    truth_states = truth["states"][origin_values + 1]
    figure, axes = plt.subplots(4, 2, figsize=(14, 13), sharex=True)
    trajectory_data: dict[str, Any] = {"truth": truth_states.tolist()}
    for state_index, (axis, name) in enumerate(zip(axes.flat, STATE_NAMES)):
        axis.plot(origin_values, truth_states[:, state_index], color="black", label="truth")
        for readout_id in common.PIPELINE_ORDER:
            values = _load_npz(
                selected_root / "readouts" / readout_id / "arrays.npz"
            )["origin_states"]
            axis.plot(origin_values, values[:, state_index], label=readout_id, alpha=0.8)
            trajectory_data.setdefault(readout_id, values.tolist())
        axis.set_title(name)
    axes[-1, 0].set_xlabel("test origin day")
    axes[-1, 1].set_xlabel("test origin day")
    axes[0, 0].legend(fontsize=6, ncol=2)
    figure.suptitle("Mechanically selected truth and primary-pipeline states")
    figure.tight_layout()
    path = root / "selected_pair_eight_state_trajectories.png"
    figure.savefig(path, dpi=200)
    plt.close(figure)
    files["selected_pair_eight_state_trajectories"] = path.name

    updating_readouts = [
        readout
        for readout in common.READOUT_ORDER
        if contract["readout_grid"][readout]["state_update"]
    ]
    effects = []
    labels = []
    for readout_id in updating_readouts:
        arrays = [
            _load_npz(pair_root / "readouts" / readout_id / "arrays.npz")
            for pair_root in pair_roots
        ]
        prior = np.concatenate(
            [value["prior_counterfactual_clean_squared_error"] for value in arrays],
            axis=0,
        )
        posterior = np.concatenate(
            [value["posterior_counterfactual_clean_squared_error"] for value in arrays],
            axis=0,
        )
        for lead_index, lead in enumerate(common.LEADS):
            effects.append(posterior[:, lead_index] / np.maximum(prior[:, lead_index], 1e-30))
            labels.append(f"{readout_id}:L{lead}")
    figure, axis = plt.subplots(figsize=(14, 5.5))
    axis.boxplot(effects, tick_labels=labels, showfliers=False)
    axis.axhline(1.0, color="black", linestyle="--", linewidth=1.0)
    axis.set_yscale("log")
    axis.set_ylabel("posterior/prior clean squared-error ratio")
    axis.set_title("Single-update forecast counterfactual by lead")
    axis.tick_params(axis="x", rotation=35, labelsize=7)
    figure.tight_layout()
    path = root / "single_update_forecast_effects.png"
    figure.savefig(path, dpi=200)
    plt.close(figure)
    files["single_update_forecast_effects"] = path.name

    figure_data = {
        "schema_version": "tukf17_figure_data_v1",
        "experiment_id": common.EXPERIMENT_ID,
        "selected_pair": selected,
        "test_origins": origin_values.tolist(),
        "primary_contrasts": primary,
        "fixed_parameter_state_contrasts": crossed,
        "complete_state_curves": state_curve_data,
        "selected_pair_state_trajectories": trajectory_data,
        "files": files,
    }
    common.write_new_json(root / "figure_data.json", figure_data)
    return figure_data


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=common.DEFAULT_CONFIG)
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    contract = common.load_contract(args.config.resolve())
    result = create_figures(contract)
    print(json.dumps({"selected_pair": result["selected_pair"], "files": result["files"]}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
