"""Run the preflight-only TUKF18 rolling-origin balance confirmation.

This command has no formal-training stage.  It evaluates only training and
selection origins, writes a new preflight root once, and never queries test
targets or performs an optimizer update.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import sys
from typing import Any, Mapping

import numpy as np
import psutil
import torch


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import tukf18_hbv_rolling_origin_balance_common as common  # noqa: E402


DEFAULT_CONFIG = common.DEFAULT_CONFIG
EXPERIMENT_ID = common.EXPERIMENT_ID
DTYPE = torch.float64
DEVICE = torch.device("cpu")


def other_formal_controller_pids() -> list[int]:
    current = os.getpid()
    result: list[int] = []
    for process in psutil.process_iter(["pid", "cmdline"]):
        try:
            pid = int(process.info["pid"])
            if pid == current:
                continue
            command = " ".join(process.info.get("cmdline") or []).lower()
        except (psutil.NoSuchProcess, psutil.AccessDenied, TypeError, ValueError):
            continue
        if ("run_tukf" in command or "verify_tukf" in command) and (
            "--stage formal" in command or "--confirm-formal-training" in command
        ):
            result.append(pid)
    return sorted(set(result))


def resource_admission(contract: Mapping[str, Any]) -> dict[str, Any]:
    required = contract["resources"]
    memory_gib = psutil.virtual_memory().available / (1024**3)
    storage_gib = shutil.disk_usage(ROOT).free / (1024**3)
    controllers = other_formal_controller_pids()
    checks = {
        "available_memory": memory_gib
        >= float(required["minimum_available_memory_gib"]),
        "workspace_free_storage": storage_gib
        >= float(required["minimum_workspace_free_storage_gib"]),
        "other_active_formal_controllers": len(controllers)
        <= int(required["maximum_other_active_formal_controllers"]),
    }
    return {
        "status": "RESOURCE_ADMITTED" if all(checks.values()) else "RESOURCE_HOLD",
        "checks": checks,
        "available_memory_gib": memory_gib,
        "workspace_free_storage_gib": storage_gib,
        "other_active_formal_controller_pids": controllers,
    }


def _tensor_inputs(
    contract: Mapping[str, Any], forcing: np.ndarray, observations: np.ndarray
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    return (
        torch.as_tensor(forcing, dtype=DTYPE, device=DEVICE),
        torch.as_tensor(observations, dtype=DTYPE, device=DEVICE),
        torch.as_tensor(
            contract["truth_and_filter"]["initial_state"], dtype=DTYPE, device=DEVICE
        ),
        torch.eye(8, dtype=DTYPE, device=DEVICE)
        * float(contract["truth_and_filter"]["initial_covariance_diagonal"]),
    )


def balance_errors(
    contract: Mapping[str, Any], registry: Mapping[str, Any]
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    pairs = common.registered_pairs(contract, registry)
    arrays = {
        name: np.empty((27, 2, 3), dtype=np.float64)
        for name in ("E00", "E01", "E10", "E11")
    }
    definitions = {
        "E00": ("truth", "truth"),
        "E01": ("truth", "initial"),
        "E10": ("initial", "truth"),
        "E11": ("initial", "initial"),
    }
    for pair_index, (seed, start_id) in enumerate(pairs):
        forcing, truth = common.generate_truth_for_seed(contract, seed)
        observations = np.asarray(truth["observations"], dtype=np.float64)
        forcing_tensor, observation_tensor, initial_state, covariance = _tensor_inputs(
            contract, forcing, observations
        )
        models = {
            label: common.build_model(
                contract,
                start_id,
                hydrology_source=hydrology_source,
                filter_source=filter_source,
            )
            for label, (hydrology_source, filter_source) in definitions.items()
        }
        for window_index, split in enumerate(("train", "selection")):
            if split == "test":
                raise PermissionError("TUKF18 preflight cannot access test origins")
            origins = common.origin_indices(contract, split)
            for label, model in models.items():
                with torch.no_grad():
                    _, details = common.rolling_origin_objective(
                        model,
                        forcing_tensor,
                        observation_tensor,
                        initial_state,
                        covariance,
                        origins,
                        state_update=True,
                        targets=observation_tensor,
                        base_observation_variance=float(
                            contract["truth_and_filter"]["base_observation_variance"]
                        ),
                    )
                arrays[label][pair_index, window_index] = np.asarray(
                    [float(details["mse_by_lead"][lead]) for lead in common.LEADS]
                )
    return arrays["E00"], arrays["E01"], arrays["E10"], arrays["E11"]


def run_preflight(
    contract: Mapping[str, Any], *, contract_path: Path = DEFAULT_CONFIG
) -> dict[str, Any]:
    validation = common.validate_contract(contract, registration_path=contract_path)
    root = common.resolve_output_path(contract, contract["outputs"]["preflight_root"])
    result_root = common.resolve_output_path(contract, contract["outputs"]["result_root"])
    if root.exists():
        raise FileExistsError(f"refusing to replace TUKF18 preflight root: {root}")
    if result_root.exists():
        raise FileExistsError(f"TUKF18 formal result root already exists: {result_root}")
    root.mkdir(parents=True, exist_ok=False)

    seed_registry = common.freeze_seed_registry(
        contract,
        destination=root / "seed_registry.json",
        configuration_path=contract_path,
    )
    e00, e01, e10, e11 = balance_errors(contract, seed_registry)
    common.write_new_npz(
        root / "balance_errors.npz",
        {"E00": e00, "E01": e01, "E10": e10, "E11": e11},
    )
    balance = common.classify_balance_arrays(e00, e01, e10, e11, contract)
    if int(balance["ratio_count"]) != 8:
        raise RuntimeError("TUKF18 balance classification did not produce eight ratios")
    common.write_new_json(root / "balance_gate.json", balance)
    resources = resource_admission(contract)
    sources = common.source_hashes(contract, contract_path)
    report = {
        "schema_version": "tukf18_engineering_preflight_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": (
            "PREFLIGHT_ENGINEERING_PASS"
            if balance["status"] == "BALANCE_PASS"
            else "BALANCE_HOLD"
        ),
        "validation": validation,
        "registered_hydrology_coordinate_distance": 0.05,
        "registered_filter_perturbation_factor": 8.0,
        "confirmation_seed_start": 1801,
        "balance_status": balance["status"],
        "resource_status": resources["status"],
        "resources": resources,
        "source_sha256": sources,
        "config_sha256": common.sha256_file(contract_path),
        "seed_registry_sha256": common.sha256_file(root / "seed_registry.json"),
        "balance_gate_sha256": common.sha256_file(root / "balance_gate.json"),
        "balance_errors_sha256": common.sha256_file(root / "balance_errors.npz"),
        "test_metric_queries": 0,
        "formal_optimizer_updates": 0,
        "formal_training_authorized": False,
    }
    common.write_new_json(root / "preflight.json", report)
    return report


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    contract_path = args.config.resolve()
    contract = common.load_contract(contract_path)
    report = run_preflight(contract, contract_path=contract_path)
    print(
        json.dumps(
            {
                "status": report["status"],
                "balance_status": report["balance_status"],
                "resource_status": report["resource_status"],
            },
            ensure_ascii=False,
            sort_keys=True,
            allow_nan=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
