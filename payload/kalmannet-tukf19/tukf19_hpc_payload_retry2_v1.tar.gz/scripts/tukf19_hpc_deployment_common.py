"""Frozen deployment-only contract for the TUKF19 Linux migration.

This module does not run the experiment.  It validates transport, scheduler,
authorization, and smoke-test values while leaving the scientific files and
their registered hashes unchanged.
"""
from __future__ import annotations

from collections.abc import Mapping
import hashlib
import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = ROOT / "configs" / "tukf19_hpc_deployment_v1.json"
RETRY1_CONFIG = ROOT / "configs" / "tukf19_hpc_deployment_retry1_v1.json"
RETRY2_CONFIG = ROOT / "configs" / "tukf19_hpc_deployment_retry2_v1.json"
DEPLOYMENT_ID = "TUKF19_HBV_ROLLING_ORIGIN_FORMAL_EXECUTION_HPC_DEPLOYMENT_V1"
RETRY1_DEPLOYMENT_ID = (
    "TUKF19_HBV_ROLLING_ORIGIN_FORMAL_EXECUTION_HPC_DEPLOYMENT_RETRY1_V1"
)
RETRY2_DEPLOYMENT_ID = (
    "TUKF19_HBV_ROLLING_ORIGIN_FORMAL_EXECUTION_HPC_DEPLOYMENT_RETRY2_V1"
)
SCIENTIFIC_EXPERIMENT_ID = "TUKF19_HBV_ROLLING_ORIGIN_FORMAL_EXECUTION_V1"
EXPECTED_AUTHORIZATION = {
    "migration_authorized": True,
    "local_memory_gate_stop_authorized": True,
    "paid_smoke_job_authorized": True,
    "formal_after_smoke_authorized": True,
    "two_hour_monitoring_authorized": True,
    "recoverable_in_scope_repairs_authorized_without_reconfirmation": True,
    "authorization_date": "2026-08-23",
    "migration_authorization_text": (
        "允许迁移到超算，停止本机门控，并允许提交体检作业及体检通过后的正式付费作业"
    ),
    "monitoring_authorization_text": (
        "然后你这个超算上的你也要两个小时检查一次啊如果出问题的自行解决不要问我授权"
    ),
}
EXPECTED_SOURCE_CONTRACT = {
    "scientific_config_path": (
        "configs/tukf19_hbv_rolling_origin_formal_execution_v1.json"
    ),
    "scientific_config_sha256": (
        "68692007dda28ca58711ea9223835ceb9baed812e7d52ebf422564e2ce951d1a"
    ),
    "scientific_source_hash_count": 37,
    "implementation_plan_path": (
        "docs/superpowers/plans/2026-08-23-tukf19-hpc-migration.md"
    ),
    "implementation_plan_sha256": (
        "8c635ecdef8ac18ba79a9bcfb0836f1222ab864573bc4f058ae49f8ebc2d7bd0"
    ),
    "readonly_kalmannet_root": "G:/github/pycharm/projects/kalmannet",
    "readonly_neuralhydrology_root": (
        "G:/github/pycharm/projects/neuralhydrology"
    ),
    "external_numpy_hbv_path": (
        "G:/github/pycharm/projects/neuralhydrology/"
        "src/scl_hydro/hbv_lite_numpy.py"
    ),
    "external_numpy_hbv_sha256": (
        "8c6356926fd6b4bdef672c4ea56bc7941291ee05298dd461100e919beb590103"
    ),
}
EXPECTED_HPC = {
    "mailbox_channel": "kalmannet-tukf19",
    "target_root": "/data1/home/sunyiq/kalmannet_tukf19_20260823",
    "conda_environment": "nh_final",
    "runner": "runner2.sh",
    "monitor_interval_hours": 2,
    "original_hpc_repository_must_remain_untouched": True,
}
EXPECTED_SLURM = {
    "partition": "hcpu48y",
    "nodes": 1,
    "ntasks": 1,
    "cpus_per_task": 1,
    "smoke_time_limit": "00:30:00",
    "formal_time_limit": "1-00:00:00",
    "custom_memory_directive_forbidden": True,
    "srun_forbidden": True,
    "thread_environment": {
        "MKL_THREADING_LAYER": "GNU",
        "MKL_SERVICE_FORCE_INTEL": "1",
        "OMP_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
    },
}
EXPECTED_OUTPUTS = {
    "local_bundle_root": "artifacts/tukf19_hpc_deployment_v1",
    "bundle_name": "tukf19_hpc_payload_v1.tar.gz",
    "bundle_manifest_name": "bundle_manifest.sha256.json",
    "payload_manifest_name": "payload_manifest.json",
    "smoke_report": (
        "artifacts/tukf19_hpc_deployment_v1/smoke/smoke_report.json"
    ),
    "hpc_status_root": "artifacts/tukf19_hpc_deployment_v1/status",
    "formal_result_archive": (
        "artifacts/tukf19_hpc_deployment_v1/"
        "tukf19_hpc_formal_result_v1.tar.gz"
    ),
}
EXPECTED_RETRY1_SOURCE_CONTRACT = {
    **EXPECTED_SOURCE_CONTRACT,
    "implementation_plan_path": (
        "docs/superpowers/plans/2026-08-23-tukf19-hpc-import-closure-retry1.md"
    ),
    "implementation_plan_sha256": (
        "ca462ef1c65be204f927c674a4bede6486bcfa4c801a5fdbafebb78a806fc857"
    ),
}
EXPECTED_RETRY1_HPC = {
    **EXPECTED_HPC,
    "target_root": "/data1/home/sunyiq/kalmannet_tukf19_20260823_retry1",
}
EXPECTED_RETRY1_OUTPUTS = {
    "local_bundle_root": "artifacts/tukf19_hpc_deployment_retry1_v1",
    "bundle_name": "tukf19_hpc_payload_retry1_v1.tar.gz",
    "bundle_manifest_name": "bundle_manifest.sha256.json",
    "payload_manifest_name": "payload_manifest.json",
    "smoke_report": (
        "artifacts/tukf19_hpc_deployment_retry1_v1/smoke/smoke_report.json"
    ),
    "hpc_status_root": "artifacts/tukf19_hpc_deployment_retry1_v1/status",
    "formal_result_archive": (
        "artifacts/tukf19_hpc_deployment_retry1_v1/"
        "tukf19_hpc_formal_result_retry1_v1.tar.gz"
    ),
}
EXPECTED_RETRY1_REPAIR_BASIS = {
    "previous_deployment_id": DEPLOYMENT_ID,
    "failed_smoke_job_id": 209815,
    "failed_smoke_state": "FAILED",
    "failed_smoke_exit_code": "2:0",
    "failed_smoke_report_sha256": (
        "fe662637a6bf85f1cd525471e05ffe2a13dc7bd62cdff515af0c6d89435651c5"
    ),
    "failed_smoke_report_bytes": 3222,
    "previous_bundle_sha256": (
        "17cf65f4e798253b66c3e4edc16f36b0e5f9b5d307faecfb80472fe27fb1130a"
    ),
    "error_type": "ModuleNotFoundError",
    "error": "No module named 'global_hydrology.models.differentiable_m4'",
    "formal_submission_absent": True,
    "repair_scope": (
        "Add only the original read-only transitive modules imported by the "
        "global_hydrology package initializers."
    ),
}
EXPECTED_RETRY2_SOURCE_CONTRACT = {
    **EXPECTED_SOURCE_CONTRACT,
    "implementation_plan_path": (
        "docs/superpowers/plans/"
        "2026-08-23-tukf19-hpc-cold-start-runtime-retry2.md"
    ),
    "implementation_plan_sha256": (
        "67b55940c9184eeb3f5861dfa30d8c177af7c520bcc95ee283418caed6caba8e"
    ),
}
EXPECTED_RETRY2_HPC = {
    **EXPECTED_HPC,
    "target_root": "/data1/home/sunyiq/kalmannet_tukf19_20260823_retry2",
}
EXPECTED_RETRY2_OUTPUTS = {
    "local_bundle_root": "artifacts/tukf19_hpc_deployment_retry2_v1",
    "bundle_name": "tukf19_hpc_payload_retry2_v1.tar.gz",
    "bundle_manifest_name": "bundle_manifest.sha256.json",
    "payload_manifest_name": "payload_manifest.json",
    "smoke_report": (
        "artifacts/tukf19_hpc_deployment_retry2_v1/smoke/smoke_report.json"
    ),
    "hpc_status_root": "artifacts/tukf19_hpc_deployment_retry2_v1/status",
    "formal_result_archive": (
        "artifacts/tukf19_hpc_deployment_retry2_v1/"
        "tukf19_hpc_formal_result_retry2_v1.tar.gz"
    ),
}
EXPECTED_RETRY2_REPAIR_BASIS = {
    "previous_deployment_id": RETRY1_DEPLOYMENT_ID,
    "failed_smoke_job_id": 209825,
    "failed_smoke_state": "FAILED",
    "failed_smoke_exit_code": "2:0",
    "failed_smoke_report_sha256": (
        "7ab176aa0fa4a569a113575952d4334d79e977b55440692d70c8ea583038ab72"
    ),
    "failed_smoke_report_bytes": 9476,
    "previous_bundle_sha256": (
        "d4e37bbd3f9191f26adb8b2a2a060358aeba5a822b0697fbb292e90308f2b407"
    ),
    "failed_check": "smoke_runtime",
    "passing_check_count": 14,
    "failed_check_count": 1,
    "observed_smoke_elapsed_seconds": 40.415059223771095,
    "previous_maximum_smoke_elapsed_seconds": 30.0,
    "revised_maximum_smoke_elapsed_seconds": 60.0,
    "first_pass_elapsed_seconds": 2.047028988599777,
    "projected_formal_seconds": 5117.572471499443,
    "formal_submission_absent": True,
    "repair_scope": (
        "Revise only the deployment smoke wall-time allowance to cover "
        "measured high-performance-computing cold-start overhead."
    ),
}
EXPECTED_CLAIMS_NOT_AUTHORIZED = [
    "scientific success from deployment success",
    "scientific success from smoke success",
    "scientific success from technical verification alone",
    "cross-platform bitwise identity beyond the registered smoke checks",
    "modification of predecessor conclusions",
]


def read_json(path: Path | str) -> dict[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected a JSON object: {path}")
    return value


def sha256_file(path: Path | str) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def canonical_json_bytes(payload: Mapping[str, Any]) -> bytes:
    return (
        json.dumps(
            payload,
            indent=2,
            sort_keys=True,
            ensure_ascii=False,
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")


def write_new_json(path: Path | str, payload: Mapping[str, Any]) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as handle:
        handle.write(canonical_json_bytes(payload))


def resolve_root_relative(raw: Path | str) -> Path:
    value = Path(str(raw))
    if value.is_absolute():
        raise ValueError("deployment output must be root-relative")
    candidate = (ROOT / value).resolve()
    try:
        candidate.relative_to(ROOT.resolve())
    except ValueError as error:
        raise ValueError(f"deployment path escapes payload root: {candidate}") from error
    return candidate


def load_deployment(path: Path | str = DEFAULT_CONFIG) -> dict[str, Any]:
    deployment = read_json(path)
    validate_deployment(deployment, configuration_path=path)
    return deployment


def validate_deployment(
    deployment: Mapping[str, Any], *, configuration_path: Path | str = DEFAULT_CONFIG
) -> dict[str, bool]:
    deployment_id = deployment.get("deployment_id")
    if deployment_id == DEPLOYMENT_ID:
        expected_schema = "tukf19_hpc_deployment_v1"
        expected_status = "HPC_MIGRATION_AND_PAID_EXECUTION_AUTHORIZED"
        expected_source = EXPECTED_SOURCE_CONTRACT
        expected_hpc = EXPECTED_HPC
        expected_outputs = EXPECTED_OUTPUTS
        expected_maximum_smoke_elapsed_seconds = 30.0
        if "repair_basis" in deployment:
            raise ValueError("first HPC deployment cannot contain retry evidence")
    elif deployment_id == RETRY1_DEPLOYMENT_ID:
        expected_schema = "tukf19_hpc_deployment_retry1_v1"
        expected_status = "HPC_RECOVERABLE_IMPORT_CLOSURE_REPAIR_AUTHORIZED"
        expected_source = EXPECTED_RETRY1_SOURCE_CONTRACT
        expected_hpc = EXPECTED_RETRY1_HPC
        expected_outputs = EXPECTED_RETRY1_OUTPUTS
        expected_maximum_smoke_elapsed_seconds = 30.0
        if deployment.get("repair_basis") != EXPECTED_RETRY1_REPAIR_BASIS:
            raise ValueError("HPC retry failure evidence or repair scope changed")
    elif deployment_id == RETRY2_DEPLOYMENT_ID:
        expected_schema = "tukf19_hpc_deployment_retry2_v1"
        expected_status = "HPC_RECOVERABLE_COLD_START_RUNTIME_REPAIR_AUTHORIZED"
        expected_source = EXPECTED_RETRY2_SOURCE_CONTRACT
        expected_hpc = EXPECTED_RETRY2_HPC
        expected_outputs = EXPECTED_RETRY2_OUTPUTS
        expected_maximum_smoke_elapsed_seconds = 60.0
        if deployment.get("repair_basis") != EXPECTED_RETRY2_REPAIR_BASIS:
            raise ValueError("HPC retry-2 failure evidence or repair scope changed")
    else:
        raise ValueError("unexpected HPC deployment identifier")
    if deployment.get("schema_version") != expected_schema:
        raise ValueError("unexpected HPC deployment schema")
    if deployment.get("scientific_experiment_id") != SCIENTIFIC_EXPERIMENT_ID:
        raise ValueError("scientific experiment identity changed during deployment")
    if deployment.get("status") != expected_status:
        raise PermissionError("HPC deployment authorization status changed")
    if deployment.get("authorization") != EXPECTED_AUTHORIZATION:
        raise PermissionError("HPC migration or paid-job authorization changed")
    if deployment.get("source_contract") != expected_source:
        raise ValueError("HPC source contract changed")
    if deployment.get("hpc") != expected_hpc:
        raise ValueError("HPC target or mailbox contract changed")
    if deployment.get("slurm") != EXPECTED_SLURM:
        raise ValueError("Slurm resource contract changed")
    if deployment.get("outputs") != expected_outputs:
        raise ValueError("HPC deployment output roots changed")
    if deployment.get("claims_not_authorized") != EXPECTED_CLAIMS_NOT_AUTHORIZED:
        raise ValueError("HPC deployment claim boundary changed")

    smoke = deployment.get("smoke", {})
    expected_smoke_scalars = {
        "truth_seed": 1802,
        "start_id": "start_03",
        "optimizer_updates_per_branch": 1,
        "branches": ["hydrology_update_only", "state_and_hydrology_update"],
        "absolute_tolerance": 1e-10,
        "relative_tolerance": 1e-8,
        "minimum_available_memory_gib": 8.0,
        "minimum_free_storage_gib": 2.0,
        "maximum_smoke_elapsed_seconds": expected_maximum_smoke_elapsed_seconds,
        "formal_runtime_projection_multiplier": 2500.0,
        "maximum_projected_formal_seconds": 64800.0,
        "test_origin_queries": 0,
        "clean_target_queries": 0,
    }
    for key, expected in expected_smoke_scalars.items():
        if smoke.get(key) != expected:
            raise ValueError(f"HPC smoke contract changed: {key}")
    if set(smoke) != {
        *expected_smoke_scalars,
        "windows_reference_environment",
        "reference",
    }:
        raise ValueError("HPC smoke field set changed")
    references = smoke.get("reference", {})
    expected_references = {
        "hydrology_update_only": {
            "training_loss": 0.15125146814722032,
            "gradient_norm_before_clipping": 3.4497972860803485,
            "selection_loss_after_one_update": 0.3694786507115457,
            "gradient_nonzero_count": 10,
        },
        "state_and_hydrology_update": {
            "training_loss": 0.03175369137765366,
            "gradient_norm_before_clipping": 0.610623824133628,
            "selection_loss_after_one_update": 0.08638733140975573,
            "gradient_nonzero_count": 12,
        },
    }
    if references != expected_references:
        raise ValueError("HPC numerical smoke references changed")

    source = deployment["source_contract"]
    scientific_config = resolve_root_relative(source["scientific_config_path"])
    plan_path = resolve_root_relative(source["implementation_plan_path"])
    if sha256_file(scientific_config) != source["scientific_config_sha256"]:
        raise ValueError("frozen scientific configuration hash changed")
    if sha256_file(plan_path) != source["implementation_plan_sha256"]:
        raise ValueError("HPC implementation plan hash changed")

    from scripts import tukf19_hbv_rolling_origin_formal_common as scientific

    contract = scientific.load_contract(scientific_config)
    if contract["experiment_id"] != SCIENTIFIC_EXPERIMENT_ID:
        raise ValueError("loaded scientific experiment identity changed")
    source_hashes = scientific.source_hashes(contract, scientific_config)
    if len(source_hashes) != int(source["scientific_source_hash_count"]):
        raise ValueError("scientific source closure count changed")
    return {
        "authorization_verified": True,
        "scientific_contract_verified": True,
        "source_hashes_verified": True,
        "scheduler_contract_verified": True,
    }
