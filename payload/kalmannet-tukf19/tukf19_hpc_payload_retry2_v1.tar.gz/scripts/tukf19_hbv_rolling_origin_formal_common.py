"""Frozen contract and delegated numerical primitives for TUKF19 formal work.

Importing this module performs no experiment and creates no file.  Scientific
values come from the independently verified TUKF18 balance preflight; TUKF19
changes only identity, authorization, resource policy, and output ownership.
"""
from __future__ import annotations

from collections.abc import Mapping
import copy
from pathlib import Path
from typing import Any

from scripts import tukf17_hbv_rolling_origin_state_hydrology_common as base
from scripts import tukf18_hbv_rolling_origin_balance_common as balance_common


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = ROOT / "configs" / "tukf19_hbv_rolling_origin_formal_execution_v1.json"
EXPERIMENT_ID = "TUKF19_HBV_ROLLING_ORIGIN_FORMAL_EXECUTION_V1"
SCHEMA_VERSION = "tukf19_hbv_rolling_origin_formal_execution_v1"
PARENT_EXPERIMENT_ID = balance_common.EXPERIMENT_ID

PIPELINE_ORDER = balance_common.PIPELINE_ORDER
READOUT_ORDER = balance_common.READOUT_ORDER
LEADS = balance_common.LEADS
ORIGIN_WINDOWS = balance_common.ORIGIN_WINDOWS
START_IDS = balance_common.START_IDS
STATE_SCALES = balance_common.STATE_SCALES
PROCESS_NOISE_BOUNDS = balance_common.PROCESS_NOISE_BOUNDS
OBSERVATION_RATIO_BOUNDS = balance_common.OBSERVATION_RATIO_BOUNDS

REPLACED_PARENT_KEYS = (
    "schema_version",
    "experiment_id",
    "status",
    "authorization",
    "resources",
    "outputs",
    "claims_not_authorized",
)
ADDED_EFFECTIVE_KEYS = ("parallel_execution",)
EXPECTED_SCIENTIFIC_CONTRACT = {
    "hydrology_coordinate_distance": 0.05,
    "filter_perturbation_factor": 8.0,
    "process_standard_deviation_fraction": 0.02,
    "accepted_truth_start_pairs": 27,
    "optimizer_updates_per_trainable_unit": 96,
    "train_origin_count": 78,
    "selection_origin_count": 38,
    "test_origin_count": 42,
    "forecast_leads_days": [1, 2, 3],
}
EXPECTED_BUDGET = {
    "trainable_units": 54,
    "real_optimizer_updates": 5184,
    "selection_queries": 1404,
    "sealed_primary_pipeline_checkpoints": 108,
    "test_readout_units": 162,
    "state_updating_test_readout_units": 81,
    "primary_errors_per_readout_unit": 126,
    "test_observation_inputs_before_global_selection_seal": 0,
    "clean_target_queries_before_global_selection_seal": 0,
}
EXPECTED_RESOURCES = {
    "minimum_available_memory_gib": 8.0,
    "minimum_workspace_free_storage_gib": 2.0,
    "maximum_same_experiment_other_controllers": 0,
    "unrelated_formal_processes_allowed": True,
}
EXPECTED_OUTPUTS = {
    "preflight_root": "artifacts/tukf18_hbv_rolling_origin_balance_adjustment_v1/preflight",
    "result_root": "results/tukf19_hbv_rolling_origin_formal_execution_v1",
    "failed_result_root": "results/tukf19_hbv_rolling_origin_formal_execution_v1_failed_attempts",
    "figure_root": (
        "artifacts/tukf19_hbv_rolling_origin_formal_execution_v1/"
        "formal_verified_summary_v1"
    ),
}
EXPECTED_CLAIMS_NOT_AUTHORIZED = [
    "hydrologic parameter identifiability",
    "recovery from an erroneous initial state",
    "online test-period parameter learning",
    "real-catchment forecast validity",
    "forecast value under forcing forecast error",
    "replacement of any sealed predecessor verdict",
    "scientific success from technical verification alone",
    "scientific validity from concurrent resource execution alone",
]
SOURCE_RELATIVE_PATHS = (
    "docs/superpowers/plans/2026-08-23-tukf19-rolling-origin-formal-execution.md",
    "scripts/tukf19_hbv_rolling_origin_formal_common.py",
    "scripts/run_tukf19_hbv_rolling_origin_formal_execution.py",
    "scripts/verify_tukf19_hbv_rolling_origin_formal_execution.py",
    "scripts/plot_tukf19_hbv_rolling_origin_formal_execution.py",
    "tests/test_tukf19_hbv_rolling_origin_formal_execution.py",
    "scripts/tukf18_hbv_rolling_origin_balance_common.py",
    "scripts/tukf17_hbv_rolling_origin_state_hydrology_common.py",
    "scripts/run_tukf17_hbv_rolling_origin_state_hydrology_update.py",
    "scripts/verify_tukf17_hbv_rolling_origin_state_hydrology_update.py",
    "scripts/plot_tukf17_hbv_rolling_origin_state_hydrology_update.py",
)


read_json = base.read_json
jsonable = base.jsonable
write_new_json = base.write_new_json
write_new_npz = base.write_new_npz
sha256_file = base.sha256_file
sha256_arrays = base.sha256_arrays
resolve_output_path = base.resolve_output_path
resolve_readonly_input = base.resolve_readonly_input
predecessor_root = base.predecessor_root
predecessor_modules = base.predecessor_modules
parent_contracts = base.parent_contracts
truth_process_variances = base.truth_process_variances
generate_truth_for_seed = base.generate_truth_for_seed
mechanically_accept_truth_seed = base.mechanically_accept_truth_seed
registered_pairs = base.registered_pairs
origin_indices = base.origin_indices
rolling_origin_objective = base.rolling_origin_objective
classify_balance_arrays = base.classify_balance_arrays
build_start_values = balance_common.build_start_values
build_model = balance_common.build_model


def read_registration(path: Path | str = DEFAULT_CONFIG) -> dict[str, Any]:
    return read_json(path)


def _local_path(raw: str) -> Path:
    value = Path(raw)
    if value.is_absolute():
        raise ValueError("TUKF19 registered local paths must be worktree-relative")
    path = (ROOT / value).resolve()
    try:
        path.relative_to(ROOT.resolve())
    except ValueError as error:
        raise ValueError(f"registered path escapes the isolated worktree: {path}") from error
    return path


def _verify_file(entry: Mapping[str, Any], label: str) -> Path:
    path = _local_path(str(entry.get("path", "")))
    expected = str(entry.get("sha256", ""))
    if len(expected) != 64:
        raise ValueError(f"registered SHA-256 is invalid: {label}")
    if not path.is_file():
        raise FileNotFoundError(f"registered file is missing: {label}: {path}")
    if sha256_file(path) != expected:
        raise ValueError(f"registered file changed: {label}")
    return path


def _verify_parent_evidence(registration: Mapping[str, Any]) -> dict[str, Path]:
    entries = registration.get("parent_evidence", {})
    expected_labels = {
        "configuration",
        "runtime_common",
        "preflight",
        "balance_gate",
        "balance_errors",
        "seed_registry",
        "independent_verification",
        "postflight_resource_conflict",
    }
    if set(entries) != expected_labels:
        raise ValueError("TUKF19 parent-evidence set changed")
    paths = {
        label: _verify_file(entries[label], f"TUKF18 {label}")
        for label in sorted(expected_labels)
    }
    preflight = read_json(paths["preflight"])
    balance = read_json(paths["balance_gate"])
    verification = read_json(paths["independent_verification"])
    conflict = read_json(paths["postflight_resource_conflict"])
    seed_registry = read_json(paths["seed_registry"])
    if (
        preflight.get("experiment_id") != PARENT_EXPERIMENT_ID
        or preflight.get("status") != "PREFLIGHT_ENGINEERING_PASS"
        or preflight.get("balance_status") != "BALANCE_PASS"
        or int(preflight.get("test_metric_queries", -1)) != 0
        or int(preflight.get("formal_optimizer_updates", -1)) != 0
        or bool(preflight.get("formal_training_authorized"))
    ):
        raise ValueError("TUKF18 preflight boundary changed")
    if (
        balance.get("status") != "BALANCE_PASS"
        or int(balance.get("ratio_count", -1)) != 8
        or float(balance.get("minimum_ratio", -1.0)) != 0.6235826223702902
        or float(balance.get("maximum_ratio", -1.0)) != 1.7820886065520245
        or int(balance.get("test_metric_queries", -1)) != 0
    ):
        raise ValueError("TUKF18 balance evidence changed")
    if (
        verification.get("status") != "PREFLIGHT_VERIFIED"
        or not verification.get("checks")
        or not all(verification["checks"].values())
        or int(verification.get("accepted_seed_count", -1)) != 27
        or int(verification.get("test_metric_queries", -1)) != 0
        or int(verification.get("formal_optimizer_updates", -1)) != 0
        or bool(verification.get("formal_training_authorized"))
    ):
        raise ValueError("TUKF18 independent verification changed")
    if (
        seed_registry.get("status") != "UNSEEN_TRUTH_SEEDS_MECHANICALLY_FROZEN"
        or int(seed_registry.get("accepted_count", -1)) != 27
        or int(seed_registry.get("scientific_metric_queries", -1)) != 0
        or len(seed_registry.get("accepted_pairs", ())) != 27
    ):
        raise ValueError("TUKF18 seed registry changed")
    if (
        conflict.get("status") != "RESOURCE_HOLD_POSTFLIGHT"
        or conflict.get("facts", {}).get("computed_balance_status") != "BALANCE_PASS"
        or not bool(
            conflict.get("facts", {}).get("independent_computation_checks_all_true")
        )
        or int(conflict.get("facts", {}).get("test_metric_queries", -1)) != 0
        or int(conflict.get("facts", {}).get("formal_optimizer_updates", -1)) != 0
        or bool(conflict.get("facts", {}).get("tukf18_formal_result_root_exists"))
        or bool(conflict.get("facts", {}).get("tukf18_failed_formal_result_root_exists"))
    ):
        raise ValueError("TUKF18 postflight resource-conflict audit changed")
    bindings = conflict.get("artifact_bindings", {})
    expected_bindings = {
        "preflight_json_sha256": entries["preflight"]["sha256"],
        "balance_gate_json_sha256": entries["balance_gate"]["sha256"],
        "balance_errors_npz_sha256": entries["balance_errors"]["sha256"],
        "seed_registry_json_sha256": entries["seed_registry"]["sha256"],
        "independent_verification_json_sha256": entries["independent_verification"][
            "sha256"
        ],
    }
    if bindings != expected_bindings:
        raise ValueError("TUKF18 postflight artifact bindings changed")
    return paths


def _verify_runtime_engine(registration: Mapping[str, Any]) -> dict[str, Path]:
    entries = registration.get("runtime_engine", {})
    if set(entries) != {"common", "formal_runner", "independent_verifier", "plotter"}:
        raise ValueError("TUKF19 runtime-engine set changed")
    return {
        label: _verify_file(entries[label], f"TUKF17 runtime {label}")
        for label in sorted(entries)
    }


def validate_registration(registration: Mapping[str, Any]) -> dict[str, bool]:
    if registration.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("unexpected TUKF19 registration schema")
    if registration.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("unexpected TUKF19 experiment identifier")
    if registration.get("status") != "FORMAL_AND_PARALLEL_EXECUTION_AUTHORIZED":
        raise ValueError("TUKF19 registration status changed")
    authorization = registration.get("authorization", {})
    for key in (
        "implementation_authorized",
        "formal_training_authorized",
        "independent_verification_authorized",
        "verified_figure_generation_authorized",
    ):
        if not bool(authorization.get(key)):
            raise PermissionError(f"TUKF19 authorization missing: {key}")
    if (
        authorization.get("authorization_date") != "2026-08-23"
        or authorization.get("authorization_text") != "全部授权"
        or not str(authorization.get("scope", "")).strip()
    ):
        raise ValueError("TUKF19 authorization record changed")
    parallel = registration.get("parallel_execution", {})
    if parallel != {
        "unrelated_formal_processes_allowed": True,
        "user_accepted_resource_isolation_waiver": True,
        "same_experiment_other_controller_limit": 0,
        "authorization_date": "2026-08-23",
        "authorization_text": "全部授权",
    }:
        raise PermissionError("TUKF19 parallel-execution authorization changed")
    if registration.get("scientific_contract") != EXPECTED_SCIENTIFIC_CONTRACT:
        raise ValueError("TUKF19 scientific contract drifted")
    if registration.get("expected_budget") != EXPECTED_BUDGET:
        raise ValueError("TUKF19 formal budget drifted")
    if registration.get("resources") != EXPECTED_RESOURCES:
        raise ValueError("TUKF19 resource policy drifted")
    if registration.get("outputs") != EXPECTED_OUTPUTS:
        raise ValueError("TUKF19 output roots drifted")
    if registration.get("claims_not_authorized") != EXPECTED_CLAIMS_NOT_AUTHORIZED:
        raise ValueError("TUKF19 claim boundary drifted")
    for raw in EXPECTED_OUTPUTS.values():
        resolve_output_path({"outputs": EXPECTED_OUTPUTS}, raw)

    _verify_parent_evidence(registration)
    _verify_runtime_engine(registration)
    return {
        "parent_balance_pass_verified": True,
        "parent_independent_verification_verified": True,
        "parent_zero_formal_work_verified": True,
        "parent_resource_conflict_audit_verified": True,
        "runtime_engine_verified": True,
    }


def load_parent_contract(
    registration_path: Path | str = DEFAULT_CONFIG,
) -> dict[str, Any]:
    registration = read_registration(registration_path)
    validate_registration(registration)
    return balance_common.load_contract(
        _local_path(registration["parent_evidence"]["configuration"]["path"])
    )


def _effective_contract(
    registration: Mapping[str, Any], parent: Mapping[str, Any]
) -> dict[str, Any]:
    contract = copy.deepcopy(parent)
    contract["schema_version"] = SCHEMA_VERSION
    contract["experiment_id"] = EXPERIMENT_ID
    contract["status"] = "FORMAL_AUTHORIZED_AWAITING_EXECUTION"
    contract["authorization"] = copy.deepcopy(registration["authorization"])
    contract["parallel_execution"] = copy.deepcopy(registration["parallel_execution"])
    contract["resources"] = copy.deepcopy(registration["resources"])
    contract["outputs"] = copy.deepcopy(registration["outputs"])
    contract["claims_not_authorized"] = copy.deepcopy(
        registration["claims_not_authorized"]
    )
    return contract


def validate_contract(
    contract: Mapping[str, Any], *, registration_path: Path | str = DEFAULT_CONFIG
) -> dict[str, Any]:
    registration = read_registration(registration_path)
    registration_validation = validate_registration(registration)
    parent = balance_common.load_contract(
        _local_path(registration["parent_evidence"]["configuration"]["path"])
    )
    expected = _effective_contract(registration, parent)
    if contract != expected:
        raise ValueError("effective TUKF19 contract differs from its frozen registration")
    normalized = copy.deepcopy(contract)
    for key in REPLACED_PARENT_KEYS:
        normalized[key] = copy.deepcopy(parent[key])
    for key in ADDED_EFFECTIVE_KEYS:
        normalized.pop(key)
    if normalized != parent:
        raise ValueError("TUKF19 changed an unregistered parent field")
    science = registration["scientific_contract"]
    if contract["balanced_error_design"] != parent["balanced_error_design"]:
        raise ValueError("TUKF19 balanced-error design changed")
    if contract["truth_seed_policy"] != parent["truth_seed_policy"]:
        raise ValueError("TUKF19 truth-seed policy changed")
    if contract["optimizer"] != parent["optimizer"]:
        raise ValueError("TUKF19 optimizer changed")
    if contract["origins"] != parent["origins"]:
        raise ValueError("TUKF19 origin windows changed")
    if contract["seals_and_budget"] != EXPECTED_BUDGET:
        raise ValueError("TUKF19 effective formal budget changed")
    if (
        float(contract["balanced_error_design"]["hydrology_coordinate_distance"])
        != science["hydrology_coordinate_distance"]
        or float(contract["balanced_error_design"]["filter_perturbation_factor"])
        != science["filter_perturbation_factor"]
        or float(
            contract["balanced_error_design"]["process_standard_deviation_fraction"]
        )
        != science["process_standard_deviation_fraction"]
    ):
        raise ValueError("TUKF19 registered and effective scientific values differ")
    return {
        **registration_validation,
        "formal_training_authorized": True,
        "parallel_execution_authorized": True,
        "accepted_pair_count": 27,
    }


def load_contract(path: Path | str = DEFAULT_CONFIG) -> dict[str, Any]:
    registration = read_registration(path)
    validate_registration(registration)
    parent = balance_common.load_contract(
        _local_path(registration["parent_evidence"]["configuration"]["path"])
    )
    contract = _effective_contract(registration, parent)
    validate_contract(contract, registration_path=path)
    return contract


def source_paths(configuration_path: Path | str = DEFAULT_CONFIG) -> tuple[Path, ...]:
    paths = (
        Path(configuration_path).resolve(),
        *(ROOT / value for value in SOURCE_RELATIVE_PATHS),
    )
    missing = [path for path in paths if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"TUKF19 source closure is incomplete: {missing}")
    return tuple(paths)


def source_hashes(
    contract: Mapping[str, Any], configuration_path: Path | str = DEFAULT_CONFIG
) -> dict[str, str]:
    validate_contract(contract, registration_path=configuration_path)
    result = {
        path.relative_to(ROOT).as_posix(): sha256_file(path)
        for path in source_paths(configuration_path)
    }
    registration = read_registration(configuration_path)
    for label, entry in registration["parent_evidence"].items():
        result[f"parent:{label}"] = sha256_file(_local_path(entry["path"]))
    for label, entry in registration["runtime_engine"].items():
        result[f"engine:{label}"] = sha256_file(_local_path(entry["path"]))
    for raw, expected in contract["readonly_input_sha256"].items():
        path = resolve_readonly_input(contract, raw)
        actual = sha256_file(path)
        if actual != str(expected):
            raise ValueError(f"read-only input SHA-256 mismatch: {raw}")
        result[f"readonly:{raw}"] = actual
    return result


def formal_pairs(contract: Mapping[str, Any]) -> list[tuple[int, str]]:
    root = resolve_output_path(contract, contract["outputs"]["preflight_root"])
    return registered_pairs(contract, read_json(root / "seed_registry.json"))


def __getattr__(name: str) -> Any:
    """Delegate unchanged tested numerical helpers without copying their code."""

    if hasattr(balance_common, name):
        return getattr(balance_common, name)
    if hasattr(base, name):
        return getattr(base, name)
    raise AttributeError(name)
