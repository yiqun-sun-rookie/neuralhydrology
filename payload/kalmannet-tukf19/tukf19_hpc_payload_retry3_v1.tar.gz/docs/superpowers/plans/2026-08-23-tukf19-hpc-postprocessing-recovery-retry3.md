# TUKF19 HPC Postprocessing Recovery Retry 3 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Recover the verified numerical result of Slurm job 209845 by copying it byte-for-byte to a new target, repairing only the display-pair selector, creating verified figures, and packaging the result without rerunning training or independent scientific computation.

**Architecture:** A new deployment bundle is extracted at `/data1/home/sunyiq/kalmannet_tukf19_20260823_retry3`. Its recovery runner verifies the pinned hashes and the internal result manifest in the immutable retry-2 source, copies the 10,785,273-byte result tree to the new target, and derives the missing display-only comparison from the already verified registry rows. It then calls the unchanged frozen plot engine through a runtime selector patch, validates the copied result and new figure manifest, and writes a deterministic archive that also contains job 209845's preserved failure evidence.

**Tech Stack:** Python 3.11, pytest, NumPy, Matplotlib, deterministic gzip/tar packaging, Slurm on `hcpu48y`, and the Git mailbox channel `kalmannet-tukf19`.

## Global Constraints

- The original repository `G:/github/pycharm/projects/kalmannet` and original high-performance-computing repository remain untouched.
- The verified source directory `/data1/home/sunyiq/kalmannet_tukf19_20260823_retry2` is read-only for recovery.
- Slurm job 209845 remains the only formal training job; recovery must never invoke either formal runner or independent verifier.
- The frozen scientific configuration, 37-file source closure, accepted pairs, origins, optimizer budget, random seeds, metrics, gates, and stop rules remain byte-identical.
- Every retry-3 output path is new and refuses overwrite.
- Registry SHA-256 is `5f39f8d71736f04af89ec7ab220966817351ab99541efdbaf0d638a870684974`.
- Independent-verification SHA-256 is `d792a58d848f65d9fc226b249234fb3e3ee338e4aaf5a0c91d5cb970961ac3c7`.
- Result-manifest SHA-256 is `a2caf3088f82cc9a54f2a1112d3fbb890c1ed2cc68271386935732e07f8b6f2a`.
- Source smoke-report SHA-256 is `da3ff78101afa609b183ae283e2f5db7500f8c52356db32b96191920d72ea4aa`.
- Formal-failure evidence SHA-256 is `e9f973531202cb02789f3285fd76b82efbc29f2a4f9f940db0037404b4c3e5a1`.
- Deployment retry-2 bundle SHA-256 is `3d1b118be805a95746fb8c7ac999df627675bb18573fb66311f8572395a7f629`.
- Technical completion must not be reported as scientific success.

---

### Task 1: Freeze the postprocessing recovery contract

**Files:**
- Create: `configs/tukf19_hpc_deployment_retry3_v1.json`
- Modify: `scripts/tukf19_hpc_deployment_common.py`
- Test: `tests/test_tukf19_hpc_migration.py`

**Interfaces:**
- Consumes: the five pinned source-evidence hashes and retry-2 deployment identity.
- Produces: `RETRY3_CONFIG`, `RETRY3_DEPLOYMENT_ID`, and `load_deployment(RETRY3_CONFIG)`.

- [ ] **Step 1: Write failing contract tests**

Add tests that load retry 3, assert source job `209845`, source target, all five evidence hashes, `formal_training_rerun_forbidden == true`, and the new target suffix `_retry3`; mutate each protected value and assert validation fails.

- [ ] **Step 2: Run the focused tests and confirm failure**

Run: `python -m pytest tests/test_tukf19_hpc_migration.py -k retry3 -q`

Expected: failure because retry-3 constants and configuration do not yet exist.

- [ ] **Step 3: Add the exact retry-3 contract**

Register a deployment whose status is `HPC_VERIFIED_RESULT_POSTPROCESSING_RECOVERY_AUTHORIZED`, whose repair basis identifies the plotting `KeyError`, and whose target and output roots are retry-3-only. Preserve the retry-2 smoke and Slurm values exactly even though recovery will not execute the smoke or formal runners.

- [ ] **Step 4: Run the focused tests**

Run: `python -m pytest tests/test_tukf19_hpc_migration.py -k retry3 -q`

Expected: all selected tests pass.

### Task 2: Implement a training-free recovery runner

**Files:**
- Create: `scripts/recover_tukf19_hpc_postprocessing.py`
- Test: `tests/test_tukf19_hpc_migration.py`

**Interfaces:**
- Consumes: `run_recovery(deployment_path: Path, bundle_manifest_path: Path) -> dict[str, Any]`.
- Produces: `select_display_pair_from_verified_rows(registry: Mapping[str, Any]) -> dict[str, Any]`, a verified figure tree, `postprocessing_recovery_complete.json`, and a deterministic result archive.

- [ ] **Step 1: Write failing selector and no-training tests**

Build a synthetic registry containing only the four registered primary contrasts and six readouts for three truth/start pairs. Assert the selector computes `state_and_hydrology_update / no_update` directly from `primary_clean_mse`, chooses the pair nearest the median ratio, and does not add a scientific contrast. Assert the recovery source contains no call to either formal runner or independent verifier.

- [ ] **Step 2: Run the focused tests and confirm failure**

Run: `python -m pytest tests/test_tukf19_hpc_migration.py -k 'display_pair or training_free' -q`

Expected: failure because the recovery module does not exist.

- [ ] **Step 3: Implement immutable-source verification and copying**

Before copying, require the exact source paths and hashes, `FORMAL_COMPLETE_AWAITING_INDEPENDENT_VERIFICATION`, 162 registry rows, `FORMAL_VERIFIED`, all 12 verification checks true, 162 independently recomputed readouts, and an internal manifest whose listed hashes equal the source files. Use `shutil.copytree` only when the retry-3 result root does not exist, then repeat the same checks on the copy and require identical relative paths and hashes.

- [ ] **Step 4: Implement the display-only selector patch**

Index registry rows by `(truth_seed, start_id, readout_id)`, compute 27 direct ratios from the two already verified `primary_clean_mse` values, take the population median, and choose the minimum tuple `(absolute distance from median, truth seed, start identifier)`. Patch only `plot_tukf17_hbv_rolling_origin_state_hydrology_update.select_display_pair` in memory before calling the unchanged TUKF19 verified-figure adapter.

- [ ] **Step 5: Implement validation and deterministic packaging**

Reuse `validate_formal_outputs` after plotting. Package the copied result tree, verified figure tree, copied smoke report, retry-3 completion status, retry-3 deployment file, bundle manifest, recovery script, recovery plan, and original `formal_failure_209845.json`. Write the archive and external hash manifest with exclusive creation and no overwrite.

- [ ] **Step 6: Run focused recovery tests**

Run: `python -m pytest tests/test_tukf19_hpc_migration.py -k 'retry3 or display_pair or training_free' -q`

Expected: all selected tests pass.

### Task 3: Package and schedule one recovery job

**Files:**
- Create: `hpc/tukf19_hbv_rolling_origin_formal_execution/submit_postprocessing_recovery_cpu_retry3.slurm`
- Modify: `scripts/build_tukf19_hpc_bundle.py`
- Test: `tests/test_tukf19_hpc_migration.py`

**Interfaces:**
- Consumes: retry-3 deployment contract and recovery runner.
- Produces: a deterministic retry-3 payload and a single Slurm submission command.

- [ ] **Step 1: Register bundle members and scheduler assertions**

Add the retry-3 configuration, plan, runner, and Slurm script to `APPLICATION_FILES`. Extend deterministic-bundle and scheduler-contract tests to require partition `hcpu48y`, one CPU, no custom memory directive, no `srun`, and the exact recovery entrypoint.

- [ ] **Step 2: Run the complete local regression suite**

Run: `python -m pytest tests/test_tukf17_hbv_rolling_origin_mechanics.py tests/test_tukf17_hbv_rolling_origin_runner.py tests/test_tukf17_hbv_rolling_origin_state_hydrology_update.py tests/test_tukf18_hbv_rolling_origin_balance_adjustment.py tests/test_tukf19_hbv_rolling_origin_formal_execution.py tests/test_tukf19_hpc_migration.py tests/test_verify_tukf17_hbv_rolling_origin_state_hydrology_update.py -q`

Expected: 93 previous tests plus the new recovery tests pass; no experiment is run.

- [ ] **Step 3: Build the bundle twice and compare hashes**

Run the builder twice with `configs/tukf19_hpc_deployment_retry3_v1.json` in two new temporary directories.

Expected: both archives have identical SHA-256, member maps, and byte counts.

- [ ] **Step 4: Deploy through the Git mailbox**

Send the bundle and manifest through channel `kalmannet-tukf19`. The remote command must require absent retry-3 target, verify the archive SHA-256, extract into the new target, verify every payload member, and record one submission receipt before calling `sbatch` exactly once.

- [ ] **Step 5: Monitor the recovery job**

Read Slurm queue, accounting, stdout, stderr, completion/failure status, and archive manifest. Never submit a second job when any retry-3 submission receipt or job identifier exists.

### Task 4: Retrieve and independently audit the package

**Files:**
- Create only under: `artifacts/tukf19_hpc_deployment_retry3_v1/retrieved/`

**Interfaces:**
- Consumes: remote retry-3 archive and external manifest.
- Produces: a local read-only audit finding that separates technical completion from scientific interpretation.

- [ ] **Step 1: Retrieve without overwriting**

Transfer the archive and external manifest through the mailbox to a new local retrieval path and require the received archive SHA-256 and byte count to equal the remote manifest.

- [ ] **Step 2: Audit archive membership and hashes**

Read the embedded payload manifest, reject unsafe or duplicate names, require every member hash to match, and verify the pinned registry, independent-verification, result-manifest, smoke, and job-failure hashes.

- [ ] **Step 3: Audit numerical and figure status**

Require all 12 independent checks true, 162 readouts, 20,412 primary clean errors, 108 training histories, 1,701 NumPy archives, five registered figure files plus figure data and manifest, and exact selected-pair reconstruction from registry rows.

- [ ] **Step 4: Report bounded conclusions**

Report technical status from Slurm, package, and hash evidence. Report scientific classifications only as the registered formal contrasts show them; do not call technical recovery or independent-verification success a scientific success.

## Self-Review

- Spec coverage: immutable source, no retraining, new paths, exact hashes, one job, package retrieval, and claim boundaries each have an explicit task.
- Placeholder scan: the plan contains no deferred implementation placeholder.
- Type consistency: retry-3 contract, selector, recovery runner, bundle builder, Slurm entrypoint, and audit outputs use the same paths and identifiers throughout.

## Execution Handoff

The user already authorized inline execution and autonomous recovery of in-scope technical failures. Execute this plan in the current isolated implementation worktree without subagents and stop before any scientific-contract change, publication, cleanup, or experiment expansion.
