from __future__ import annotations

import copy
import json
from pathlib import Path
import subprocess
import sys
import tarfile

import pytest

from scripts import tukf19_hbv_rolling_origin_formal_common as scientific_common
from scripts import tukf19_hpc_deployment_common as deployment_common
from scripts import build_tukf19_hpc_bundle as bundle_builder
from scripts import smoke_tukf19_hpc_compatibility as smoke
from scripts import run_tukf19_hpc_formal_pipeline as hpc_pipeline
from scripts import recover_tukf19_hpc_postprocessing as postprocessing_recovery


ROOT = Path(__file__).resolve().parents[1]
RETRY1_CONFIG = ROOT / "configs" / "tukf19_hpc_deployment_retry1_v1.json"
RETRY2_CONFIG = ROOT / "configs" / "tukf19_hpc_deployment_retry2_v1.json"
RETRY3_CONFIG = ROOT / "configs" / "tukf19_hpc_deployment_retry3_v1.json"
RETRY4_CONFIG = ROOT / "configs" / "tukf19_hpc_deployment_retry4_v1.json"


def test_hpc_deployment_preserves_scientific_identity_and_authorization() -> None:
    deployment = deployment_common.load_deployment()
    scientific = scientific_common.load_contract()

    assert deployment["scientific_experiment_id"] == scientific["experiment_id"]
    assert deployment["slurm"]["partition"] == "hcpu48y"
    assert deployment["slurm"]["cpus_per_task"] == 1
    assert deployment["slurm"]["custom_memory_directive_forbidden"] is True
    assert deployment["authorization"]["paid_smoke_job_authorized"] is True
    assert deployment["authorization"]["formal_after_smoke_authorized"] is True
    assert deployment["authorization"]["two_hour_monitoring_authorized"] is True
    assert deployment_common.validate_deployment(deployment)["scientific_contract_verified"]


def test_deployment_rejects_scientific_identity_or_slurm_drift() -> None:
    deployment = deployment_common.load_deployment()
    for section, key, value in (
        ("source_contract", "scientific_config_sha256", "0" * 64),
        ("slurm", "partition", "hcpu48"),
        ("slurm", "cpus_per_task", 2),
        ("hpc", "mailbox_channel", "probe"),
        ("smoke", "truth_seed", 1801),
    ):
        changed = copy.deepcopy(deployment)
        changed[section][key] = value
        with pytest.raises((ValueError, PermissionError)):
            deployment_common.validate_deployment(changed)


def test_retry1_is_unique_and_bound_to_preserved_failure() -> None:
    original = deployment_common.load_deployment()
    retry = deployment_common.load_deployment(RETRY1_CONFIG)

    assert retry["deployment_id"] != original["deployment_id"]
    assert retry["scientific_experiment_id"] == original["scientific_experiment_id"]
    assert retry["repair_basis"]["failed_smoke_job_id"] == 209815
    assert retry["repair_basis"]["failed_smoke_report_sha256"] == (
        "fe662637a6bf85f1cd525471e05ffe2a13dc7bd62cdff515af0c6d89435651c5"
    )
    assert retry["repair_basis"]["formal_submission_absent"] is True
    assert retry["hpc"]["target_root"].endswith("_retry1")
    assert retry["outputs"]["local_bundle_root"].endswith("_retry1_v1")


def test_retry1_rejects_failed_evidence_mutation() -> None:
    retry = deployment_common.load_deployment(RETRY1_CONFIG)
    retry["repair_basis"]["failed_smoke_job_id"] = 209816
    with pytest.raises(ValueError, match="failure evidence"):
        deployment_common.validate_deployment(
            retry, configuration_path=RETRY1_CONFIG
        )


def test_retry2_is_bound_to_runtime_only_failure_and_preserves_science() -> None:
    original = deployment_common.load_deployment()
    retry1 = deployment_common.load_deployment(RETRY1_CONFIG)
    retry2 = deployment_common.load_deployment(RETRY2_CONFIG)

    assert retry2["deployment_id"] != retry1["deployment_id"]
    assert retry2["scientific_experiment_id"] == original["scientific_experiment_id"]
    assert retry2["repair_basis"]["failed_smoke_job_id"] == 209825
    assert retry2["repair_basis"]["failed_smoke_report_sha256"] == (
        "7ab176aa0fa4a569a113575952d4334d79e977b55440692d70c8ea583038ab72"
    )
    assert retry2["repair_basis"]["failed_check"] == "smoke_runtime"
    assert retry2["repair_basis"]["formal_submission_absent"] is True
    assert retry2["hpc"]["target_root"].endswith("_retry2")
    assert retry2["outputs"]["local_bundle_root"].endswith("_retry2_v1")
    assert original["smoke"]["maximum_smoke_elapsed_seconds"] == 30.0
    assert retry1["smoke"]["maximum_smoke_elapsed_seconds"] == 30.0
    assert retry2["smoke"]["maximum_smoke_elapsed_seconds"] == 60.0
    for key in retry1["smoke"]:
        if key != "maximum_smoke_elapsed_seconds":
            assert retry2["smoke"][key] == retry1["smoke"][key]


def test_retry2_rejects_failure_evidence_or_runtime_scope_mutation() -> None:
    retry = deployment_common.load_deployment(RETRY2_CONFIG)
    for section, key, value in (
        ("repair_basis", "failed_smoke_job_id", 209826),
        ("repair_basis", "observed_smoke_elapsed_seconds", 40.0),
        ("smoke", "maximum_smoke_elapsed_seconds", 61.0),
    ):
        changed = copy.deepcopy(retry)
        changed[section][key] = value
        with pytest.raises(ValueError):
            deployment_common.validate_deployment(
                changed, configuration_path=RETRY2_CONFIG
            )


def test_retry3_is_bound_to_verified_postprocessing_failure_without_training() -> None:
    retry2 = deployment_common.load_deployment(RETRY2_CONFIG)
    retry3 = deployment_common.load_deployment(RETRY3_CONFIG)

    assert retry3["deployment_id"] != retry2["deployment_id"]
    assert retry3["scientific_experiment_id"] == retry2["scientific_experiment_id"]
    assert retry3["status"] == "HPC_VERIFIED_RESULT_POSTPROCESSING_RECOVERY_AUTHORIZED"
    assert retry3["repair_basis"] == {
        "previous_deployment_id": retry2["deployment_id"],
        "failed_formal_job_id": 209845,
        "failed_formal_state": "FAILED",
        "failed_formal_exit_code": "1:0",
        "source_target_root": retry2["hpc"]["target_root"],
        "previous_bundle_sha256": (
            "3d1b118be805a95746fb8c7ac999df627675bb18573fb66311f8572395a7f629"
        ),
        "source_registry_sha256": (
            "5f39f8d71736f04af89ec7ab220966817351ab99541efdbaf0d638a870684974"
        ),
        "source_independent_verification_sha256": (
            "d792a58d848f65d9fc226b249234fb3e3ee338e4aaf5a0c91d5cb970961ac3c7"
        ),
        "source_result_manifest_sha256": (
            "a2caf3088f82cc9a54f2a1112d3fbb890c1ed2cc68271386935732e07f8b6f2a"
        ),
        "source_smoke_report_sha256": (
            "da3ff78101afa609b183ae283e2f5db7500f8c52356db32b96191920d72ea4aa"
        ),
        "source_formal_failure_sha256": (
            "e9f973531202cb02789f3285fd76b82efbc29f2a4f9f940db0037404b4c3e5a1"
        ),
        "source_result_file_count": 2003,
        "source_result_total_bytes": 10785273,
        "scientific_runner_return_code": 0,
        "independent_verifier_return_code": 0,
        "independent_verification_status": "FORMAL_VERIFIED",
        "failed_step": "verified_figure_generation",
        "error_type": "KeyError",
        "missing_display_contrast": (
            "state_and_hydrology_update_over_no_update"
        ),
        "formal_training_rerun_forbidden": True,
        "independent_verification_rerun_forbidden": True,
        "source_result_mutation_forbidden": True,
        "repair_scope": (
            "Copy the independently verified result byte-for-byte to a new "
            "target, reconstruct only the missing display-pair ratio from "
            "verified registry rows, then plot, validate, and package."
        ),
    }
    assert retry3["hpc"]["target_root"].endswith("_retry3")
    assert retry3["outputs"]["local_bundle_root"].endswith("_retry3_v1")


@pytest.mark.parametrize(
    "key,value",
    [
        ("failed_formal_job_id", 209846),
        ("source_registry_sha256", "0" * 64),
        ("formal_training_rerun_forbidden", False),
        ("missing_display_contrast", "state_update_only_over_no_update"),
    ],
)
def test_retry3_rejects_evidence_or_recovery_scope_mutation(
    key: str, value: object
) -> None:
    retry3 = deployment_common.load_deployment(RETRY3_CONFIG)
    changed = copy.deepcopy(retry3)
    changed["repair_basis"][key] = value
    with pytest.raises(ValueError):
        deployment_common.validate_deployment(
            changed, configuration_path=RETRY3_CONFIG
        )


def test_postprocessing_display_pair_is_derived_from_verified_rows_only() -> None:
    readouts = (
        "no_update",
        "state_update_only",
        "hydrology_update_only",
        "state_and_hydrology_update",
        "openloop_trained_parameters_with_state_update",
        "state_trained_parameters_without_state_update",
    )
    pairs = (
        (1801, "start_01", 2.0, 2.0),
        (1802, "start_02", 2.0, 1.0),
        (1803, "start_03", 2.0, 0.4),
    )
    rows = []
    for truth_seed, start_id, no_update, combined in pairs:
        for readout_id in readouts:
            value = 1.0
            if readout_id == "no_update":
                value = no_update
            elif readout_id == "state_and_hydrology_update":
                value = combined
            rows.append(
                {
                    "truth_seed": truth_seed,
                    "start_id": start_id,
                    "readout_id": readout_id,
                    "primary_clean_mse": value,
                }
            )
    registry = {
        "rows": rows,
        "aggregates": {
            "primary": {
                "contrasts": {
                    "state_update_only_over_no_update": {},
                    "state_and_hydrology_update_over_hydrology_update_only": {},
                    "hydrology_update_only_over_no_update": {},
                    "state_and_hydrology_update_over_state_update_only": {},
                }
            }
        },
    }
    before = copy.deepcopy(registry)

    selected = postprocessing_recovery.select_display_pair_from_verified_rows(
        registry
    )

    assert selected == {
        "truth_seed": 1802,
        "start_id": "start_02",
        "ratio": 0.5,
        "population_median_ratio": 0.5,
        "pair_count": 3,
        "selection_basis": (
            "display_only_state_and_hydrology_update_over_no_update_derived_from_"
            "verified_registry_rows"
        ),
    }
    assert registry == before


def test_postprocessing_recovery_source_is_training_free() -> None:
    source = (ROOT / "scripts/recover_tukf19_hpc_postprocessing.py").read_text(
        encoding="utf-8"
    )
    assert "run_tukf19_hbv_rolling_origin_formal_execution.py" not in source
    assert "verify_tukf19_hbv_rolling_origin_formal_execution.py" not in source
    assert "confirm-formal-training" not in source


def test_retry4_is_bound_to_retry3_failure_and_layered_source_error() -> None:
    retry2 = deployment_common.load_deployment(RETRY2_CONFIG)
    retry3 = deployment_common.load_deployment(RETRY3_CONFIG)
    retry4 = deployment_common.load_deployment(RETRY4_CONFIG)

    assert retry4["status"] == "HPC_WRAPPED_ERROR_POSTPROCESSING_RECOVERY_AUTHORIZED"
    assert retry4["scientific_experiment_id"] == retry3["scientific_experiment_id"]
    assert retry4["repair_basis"] == {
        "previous_deployment_id": retry3["deployment_id"],
        "failed_recovery_job_id": 209938,
        "failed_recovery_state": "FAILED",
        "failed_recovery_exit_code": "1:0",
        "failed_recovery_elapsed_seconds": 5,
        "failed_recovery_bundle_sha256": (
            "497f3347134a0f19ecc6bbf1cbc2dc42e5a326aaf8c6cc52cda81c77265ee5c9"
        ),
        "failed_recovery_submission_sha256": (
            "af07f09972ba6438dd7cc29f3a2165576e388caa883433080073ef1265304898"
        ),
        "failed_recovery_failure_sha256": (
            "effec19c256e5bcff91bdf969b92fcff11701414f8a0967bbde14b98a4035e49"
        ),
        "failed_recovery_stderr_sha256": (
            "236b410d1a8291d86d300c1c9fee812dd84d33e94a6545807ac67293b1e79733"
        ),
        "failed_recovery_error_type": "ValueError",
        "failed_recovery_stage": "source_formal_failure_validation",
        "failed_recovery_started_absent": True,
        "copied_result_absent": True,
        "figure_root_absent": True,
        "package_absent": True,
        "source_target_root": retry2["hpc"]["target_root"],
        "source_formal_job_id": 209845,
        "source_bundle_sha256": (
            "3d1b118be805a95746fb8c7ac999df627675bb18573fb66311f8572395a7f629"
        ),
        "source_registry_sha256": (
            "5f39f8d71736f04af89ec7ab220966817351ab99541efdbaf0d638a870684974"
        ),
        "source_independent_verification_sha256": (
            "d792a58d848f65d9fc226b249234fb3e3ee338e4aaf5a0c91d5cb970961ac3c7"
        ),
        "source_result_manifest_sha256": (
            "a2caf3088f82cc9a54f2a1112d3fbb890c1ed2cc68271386935732e07f8b6f2a"
        ),
        "source_smoke_report_sha256": (
            "da3ff78101afa609b183ae283e2f5db7500f8c52356db32b96191920d72ea4aa"
        ),
        "source_formal_failure_sha256": (
            "e9f973531202cb02789f3285fd76b82efbc29f2a4f9f940db0037404b4c3e5a1"
        ),
        "source_formal_stderr_sha256": (
            "b396a0bef8ab19203dafa7eddf67a34f30b005d57ae3cc19656aa4f8a8c33cb1"
        ),
        "source_result_file_count": 2003,
        "source_result_total_bytes": 10785273,
        "source_pipeline_error_type": "RuntimeError",
        "source_pipeline_error_contains": "formal HPC step failed",
        "source_nested_error_type": "KeyError",
        "source_nested_missing_contrast": (
            "state_and_hydrology_update_over_no_update"
        ),
        "formal_training_rerun_forbidden": True,
        "independent_verification_rerun_forbidden": True,
        "source_result_mutation_forbidden": True,
        "repair_scope": (
            "Correct only the evidence-layer distinction: validate the pipeline "
            "RuntimeError in formal_failure_209845.json and the nested KeyError "
            "plus missing display contrast in the pinned formal stderr; retain "
            "the retry-3 copy, plot, validation, and packaging logic."
        ),
    }
    assert retry4["hpc"]["target_root"].endswith("_retry4")
    assert retry4["outputs"]["local_bundle_root"].endswith("_retry4_v1")


@pytest.mark.parametrize(
    "key,value",
    [
        ("failed_recovery_job_id", 209939),
        ("failed_recovery_failure_sha256", "0" * 64),
        ("source_formal_stderr_sha256", "0" * 64),
        ("formal_training_rerun_forbidden", False),
    ],
)
def test_retry4_rejects_failure_evidence_or_scope_mutation(
    key: str, value: object
) -> None:
    retry4 = deployment_common.load_deployment(RETRY4_CONFIG)
    changed = copy.deepcopy(retry4)
    changed["repair_basis"][key] = value
    with pytest.raises(ValueError):
        deployment_common.validate_deployment(
            changed, configuration_path=RETRY4_CONFIG
        )


def test_wrapped_error_and_nested_stderr_are_validated_separately(
    tmp_path: Path,
) -> None:
    paths = {
        name: tmp_path / name
        for name in (
            "failure",
            "submission",
            "started",
            "stdout",
            "stderr",
            "bundle_manifest",
            "smoke",
        )
    }
    failure = {
        "status": "HPC_FORMAL_PIPELINE_FAILED",
        "error_type": "RuntimeError",
        "error": "formal HPC step failed: {'return_code': 1}",
        "steps": [{"return_code": 0}, {"return_code": 0}],
    }
    paths["failure"].write_text(json.dumps(failure), encoding="utf-8")
    paths["submission"].write_text("submission", encoding="utf-8")
    paths["started"].write_text(
        json.dumps({"slurm_job_id": "209845"}), encoding="utf-8"
    )
    paths["stdout"].write_text("", encoding="utf-8")
    paths["stderr"].write_text(
        "KeyError: 'state_and_hydrology_update_over_no_update'\n",
        encoding="utf-8",
    )
    paths["bundle_manifest"].write_text(
        json.dumps({"archive_sha256": "1" * 64}), encoding="utf-8"
    )
    paths["smoke"].write_text("smoke", encoding="utf-8")
    deployment = {
        "repair_basis": {
            "source_formal_failure_sha256": deployment_common.sha256_file(
                paths["failure"]
            ),
            "source_smoke_report_sha256": deployment_common.sha256_file(
                paths["smoke"]
            ),
            "source_formal_stderr_sha256": deployment_common.sha256_file(
                paths["stderr"]
            ),
            "source_pipeline_error_type": "RuntimeError",
            "source_pipeline_error_contains": "formal HPC step failed",
            "source_nested_error_type": "KeyError",
            "source_nested_missing_contrast": (
                "state_and_hydrology_update_over_no_update"
            ),
            "source_formal_job_id": 209845,
            "source_bundle_sha256": "1" * 64,
        }
    }

    checks = postprocessing_recovery._verify_source_failure(deployment, paths)

    assert checks and all(checks.values())


def test_payload_member_map_is_complete_and_preserves_windows_paths() -> None:
    deployment = deployment_common.load_deployment()
    members = bundle_builder.payload_members(deployment)
    external_hash = deployment["source_contract"]["external_numpy_hbv_sha256"]
    direct = (
        "G:/github/pycharm/projects/neuralhydrology/src/"
        "scl_hydro/hbv_lite_numpy.py"
    )
    nested = (
        "G:/github/pycharm/projects/kalmannet/G:/github/pycharm/projects/"
        "neuralhydrology/src/scl_hydro/hbv_lite_numpy.py"
    )

    assert bundle_builder.sha256_file(members[direct]) == external_hash
    assert bundle_builder.sha256_file(members[nested]) == external_hash
    assert "configs/tukf19_hbv_rolling_origin_formal_execution_v1.json" in members
    assert "scripts/run_tukf19_hbv_rolling_origin_formal_execution.py" in members
    assert "scripts/verify_tukf19_hbv_rolling_origin_formal_execution.py" in members
    assert "scripts/plot_tukf19_hbv_rolling_origin_formal_execution.py" in members
    assert not any(name.startswith("results/") for name in members)


def test_retry_payload_contains_package_initializer_import_closure() -> None:
    retry = deployment_common.load_deployment(RETRY1_CONFIG)
    members = bundle_builder.payload_members(retry)
    prefix = "G:/github/pycharm/projects/kalmannet/src/global_hydrology/"
    expected = {
        "models/differentiable_m4.py",
        "models/static_encoder.py",
        "models/m4_system_model.py",
        "models/dl_ssm.py",
        "models/hydro_system.py",
        "models/differentiable_walrus.py",
        "models/walrus_system_model.py",
        "data/__init__.py",
        "data/caravan_dataset.py",
        "data/multi_obs_caravan.py",
    }
    assert {prefix + relative for relative in expected} <= set(members)


def test_retry_bundle_is_deterministic(tmp_path: Path) -> None:
    first = bundle_builder.build_bundle(
        tmp_path / "retry-first", deployment_path=RETRY1_CONFIG
    )
    second = bundle_builder.build_bundle(
        tmp_path / "retry-second", deployment_path=RETRY1_CONFIG
    )
    assert first["archive_sha256"] == second["archive_sha256"]
    assert first["members"] == second["members"]
    assert first["archive_name"] == "tukf19_hpc_payload_retry1_v1.tar.gz"


def test_retry2_bundle_is_deterministic(tmp_path: Path) -> None:
    first = bundle_builder.build_bundle(
        tmp_path / "retry2-first", deployment_path=RETRY2_CONFIG
    )
    second = bundle_builder.build_bundle(
        tmp_path / "retry2-second", deployment_path=RETRY2_CONFIG
    )
    assert first["archive_sha256"] == second["archive_sha256"]
    assert first["members"] == second["members"]
    assert first["archive_name"] == "tukf19_hpc_payload_retry2_v1.tar.gz"


def test_retry3_bundle_is_deterministic_and_contains_only_recovery_entrypoint(
    tmp_path: Path,
) -> None:
    first = bundle_builder.build_bundle(
        tmp_path / "retry3-first", deployment_path=RETRY3_CONFIG
    )
    second = bundle_builder.build_bundle(
        tmp_path / "retry3-second", deployment_path=RETRY3_CONFIG
    )
    assert first["archive_sha256"] == second["archive_sha256"]
    assert first["members"] == second["members"]
    assert first["archive_name"] == "tukf19_hpc_payload_retry3_v1.tar.gz"
    assert "scripts/recover_tukf19_hpc_postprocessing.py" in first["members"]
    assert (
        "hpc/tukf19_hbv_rolling_origin_formal_execution/"
        "submit_postprocessing_recovery_cpu_retry3.slurm"
    ) in first["members"]


def test_retry4_bundle_is_deterministic_and_contains_corrected_recovery(
    tmp_path: Path,
) -> None:
    first = bundle_builder.build_bundle(
        tmp_path / "retry4-first", deployment_path=RETRY4_CONFIG
    )
    second = bundle_builder.build_bundle(
        tmp_path / "retry4-second", deployment_path=RETRY4_CONFIG
    )
    assert first["archive_sha256"] == second["archive_sha256"]
    assert first["members"] == second["members"]
    assert first["archive_name"] == "tukf19_hpc_payload_retry4_v1.tar.gz"
    assert "scripts/recover_tukf19_hpc_postprocessing.py" in first["members"]
    assert (
        "hpc/tukf19_hbv_rolling_origin_formal_execution/"
        "submit_postprocessing_recovery_cpu_retry4.slurm"
    ) in first["members"]


def test_bundle_is_deterministic_and_manifest_bound(tmp_path: Path) -> None:
    first = bundle_builder.build_bundle(tmp_path / "first")
    second = bundle_builder.build_bundle(tmp_path / "second")

    assert first["archive_sha256"] == second["archive_sha256"]
    assert first["archive_bytes"] == second["archive_bytes"]
    assert first["members"] == second["members"]
    with tarfile.open(first["archive_path"], "r:gz") as archive:
        names = tuple(sorted(archive.getnames()))
        payload_manifest = json.load(archive.extractfile("payload_manifest.json"))
    assert names == tuple(sorted((*first["members"], "payload_manifest.json")))
    assert payload_manifest["members"] == first["members"]


def test_bundle_builder_can_run_by_direct_script_path(tmp_path: Path) -> None:
    completed = subprocess.run(
        [
            sys.executable,
            "-B",
            "scripts/build_tukf19_hpc_bundle.py",
            "--output-root",
            str(tmp_path / "direct"),
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    assert completed.returncode == 0, completed.stderr
    report = json.loads(completed.stdout)
    assert report["status"] == "HPC_BUNDLE_COMPLETE"


def test_smoke_reference_tolerance_and_sealed_boundary() -> None:
    deployment = deployment_common.load_deployment()
    reference = deployment["smoke"]["reference"]["hydrology_update_only"]
    assert smoke.within_reference(
        reference["training_loss"] + 1e-11,
        reference["training_loss"],
        deployment,
    )
    assert not smoke.within_reference(
        reference["training_loss"] + 1e-5,
        reference["training_loss"],
        deployment,
    )
    assert deployment["smoke"]["test_origin_queries"] == 0
    assert deployment["smoke"]["clean_target_queries"] == 0


@pytest.mark.parametrize(
    "relative",
    [
        "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_smoke_cpu.slurm",
        "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_formal_cpu.slurm",
        "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_smoke_cpu_retry1.slurm",
        "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_formal_cpu_retry1.slurm",
        "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_smoke_cpu_retry2.slurm",
        "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_formal_cpu_retry2.slurm",
        "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_postprocessing_recovery_cpu_retry3.slurm",
        "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_postprocessing_recovery_cpu_retry4.slurm",
    ],
)
def test_slurm_scripts_follow_cluster_contract(relative: str) -> None:
    source = (ROOT / relative).read_text(encoding="utf-8")
    assert "#SBATCH --partition=hcpu48y" in source
    assert "#SBATCH --nodes=1" in source
    assert "#SBATCH --ntasks=1" in source
    assert "#SBATCH --cpus-per-task=1" in source
    assert "MKL_THREADING_LAYER=GNU" in source
    assert "MKL_SERVICE_FORCE_INTEL=1" in source
    assert "OMP_NUM_THREADS=1" in source
    assert "MKL_NUM_THREADS=1" in source
    assert "OPENBLAS_NUM_THREADS=1" in source
    assert "set -eo pipefail" in source
    assert "--mem" not in source
    assert "srun" not in source
    assert "set -u" not in source
    assert "python -B" in source


def test_retry3_slurm_runs_only_postprocessing_recovery() -> None:
    source = (
        ROOT
        / "hpc/tukf19_hbv_rolling_origin_formal_execution/"
        "submit_postprocessing_recovery_cpu_retry3.slurm"
    ).read_text(encoding="utf-8")
    assert "scripts/recover_tukf19_hpc_postprocessing.py" in source
    assert "--confirm-postprocessing-recovery" in source
    assert "run_tukf19_hbv_rolling_origin_formal_execution.py" not in source
    assert "verify_tukf19_hbv_rolling_origin_formal_execution.py" not in source


def test_retry4_slurm_runs_only_corrected_postprocessing_recovery() -> None:
    source = (
        ROOT
        / "hpc/tukf19_hbv_rolling_origin_formal_execution/"
        "submit_postprocessing_recovery_cpu_retry4.slurm"
    ).read_text(encoding="utf-8")
    assert "scripts/recover_tukf19_hpc_postprocessing.py" in source
    assert "configs/tukf19_hpc_deployment_retry4_v1.json" in source
    assert "--confirm-postprocessing-recovery" in source
    assert "run_tukf19_hbv_rolling_origin_formal_execution.py" not in source
    assert "verify_tukf19_hbv_rolling_origin_formal_execution.py" not in source


def test_formal_pipeline_requires_bound_smoke_pass() -> None:
    deployment = deployment_common.load_deployment()
    good = {
        "status": "HPC_SMOKE_PASS",
        "deployment_id": deployment["deployment_id"],
        "bundle_sha256": "1" * 64,
        "checks": {"all": True},
    }
    assert hpc_pipeline.require_smoke_pass(
        good, deployment=deployment, expected_bundle_sha256="1" * 64
    )

    bad = copy.deepcopy(good)
    bad["checks"]["all"] = False
    with pytest.raises(PermissionError):
        hpc_pipeline.require_smoke_pass(
            bad, deployment=deployment, expected_bundle_sha256="1" * 64
        )
