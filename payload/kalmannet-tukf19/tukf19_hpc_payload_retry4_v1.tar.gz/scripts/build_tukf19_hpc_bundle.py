"""Build the deterministic, path-preserving TUKF19 HPC payload archive."""
from __future__ import annotations

import argparse
import gzip
import io
import json
from pathlib import Path, PurePosixPath
import sys
import tarfile
from typing import Any, Mapping


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import tukf19_hpc_deployment_common as deployment_common


DEFAULT_CONFIG = deployment_common.DEFAULT_CONFIG
sha256_file = deployment_common.sha256_file

APPLICATION_FILES = (
    "configs/tukf17_hbv_rolling_origin_state_hydrology_update_v1.json",
    "configs/tukf18_hbv_rolling_origin_balance_adjustment_v1.json",
    "configs/tukf19_hbv_rolling_origin_formal_execution_v1.json",
    "configs/tukf19_hpc_deployment_v1.json",
    "configs/tukf19_hpc_deployment_retry1_v1.json",
    "configs/tukf19_hpc_deployment_retry2_v1.json",
    "configs/tukf19_hpc_deployment_retry3_v1.json",
    "configs/tukf19_hpc_deployment_retry4_v1.json",
    "docs/superpowers/plans/2026-08-23-tukf18-balanced-rolling-origin-preflight.md",
    "docs/superpowers/plans/2026-08-23-tukf19-rolling-origin-formal-execution.md",
    "docs/superpowers/plans/2026-08-23-tukf19-hpc-migration.md",
    "docs/superpowers/plans/2026-08-23-tukf19-hpc-import-closure-retry1.md",
    "docs/superpowers/plans/2026-08-23-tukf19-hpc-cold-start-runtime-retry2.md",
    "docs/superpowers/plans/2026-08-23-tukf19-hpc-postprocessing-recovery-retry3.md",
    "docs/superpowers/plans/2026-08-23-tukf19-hpc-wrapped-error-recovery-retry4.md",
    "scripts/tukf17_hbv_rolling_origin_state_hydrology_common.py",
    "scripts/tukf18_hbv_rolling_origin_balance_common.py",
    "scripts/tukf19_hbv_rolling_origin_formal_common.py",
    "scripts/run_tukf17_hbv_rolling_origin_state_hydrology_update.py",
    "scripts/run_tukf18_hbv_rolling_origin_balance_preflight.py",
    "scripts/run_tukf19_hbv_rolling_origin_formal_execution.py",
    "scripts/verify_tukf17_hbv_rolling_origin_state_hydrology_update.py",
    "scripts/verify_tukf18_hbv_rolling_origin_balance_preflight.py",
    "scripts/verify_tukf19_hbv_rolling_origin_formal_execution.py",
    "scripts/plot_tukf17_hbv_rolling_origin_state_hydrology_update.py",
    "scripts/plot_tukf19_hbv_rolling_origin_formal_execution.py",
    "scripts/tukf19_hpc_deployment_common.py",
    "scripts/build_tukf19_hpc_bundle.py",
    "scripts/smoke_tukf19_hpc_compatibility.py",
    "scripts/run_tukf19_hpc_formal_pipeline.py",
    "scripts/recover_tukf19_hpc_postprocessing.py",
    "tests/test_tukf18_hbv_rolling_origin_balance_adjustment.py",
    "tests/test_tukf19_hbv_rolling_origin_formal_execution.py",
    "tests/test_tukf19_hpc_migration.py",
    "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_smoke_cpu.slurm",
    "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_formal_cpu.slurm",
    "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_smoke_cpu_retry1.slurm",
    "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_formal_cpu_retry1.slurm",
    "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_smoke_cpu_retry2.slurm",
    "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_formal_cpu_retry2.slurm",
    "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_postprocessing_recovery_cpu_retry3.slurm",
    "hpc/tukf19_hbv_rolling_origin_formal_execution/submit_postprocessing_recovery_cpu_retry4.slurm",
)
PREFLIGHT_FILES = (
    "artifacts/tukf17_hbv_rolling_origin_state_hydrology_update_v1/preflight/balance_errors.npz",
    "artifacts/tukf17_hbv_rolling_origin_state_hydrology_update_v1/preflight/balance_gate.json",
    "artifacts/tukf17_hbv_rolling_origin_state_hydrology_update_v1/preflight/independent_verification.json",
    "artifacts/tukf17_hbv_rolling_origin_state_hydrology_update_v1/preflight/preflight.json",
    "artifacts/tukf17_hbv_rolling_origin_state_hydrology_update_v1/preflight/seed_registry.json",
    "artifacts/tukf18_hbv_rolling_origin_balance_adjustment_v1/preflight/balance_errors.npz",
    "artifacts/tukf18_hbv_rolling_origin_balance_adjustment_v1/preflight/balance_gate.json",
    "artifacts/tukf18_hbv_rolling_origin_balance_adjustment_v1/preflight/independent_verification.json",
    "artifacts/tukf18_hbv_rolling_origin_balance_adjustment_v1/preflight/postflight_resource_conflict.json",
    "artifacts/tukf18_hbv_rolling_origin_balance_adjustment_v1/preflight/preflight.json",
    "artifacts/tukf18_hbv_rolling_origin_balance_adjustment_v1/preflight/seed_registry.json",
)
READONLY_KALMANNET_FILES = (
    "configs/tukf11_hbv_joint_parameter_synthetic_mechanism_gate_v1.json",
    "configs/tukf14_hbv_four_mode_randomised_start_ablation_v1.json",
    "configs/tukf16_hbv_balanced_error_four_mode_rerun_v1.json",
    "scripts/tukf11_hbv_joint_parameter_synthetic_common.py",
    "scripts/run_tukf11_hbv_joint_parameter_synthetic_mechanism_gate.py",
    "scripts/differentiable_ukf_hbvlite.py",
    "scripts/tukf10_joint_hbv_physical_filter_common.py",
    "scripts/run_aligned_gr4j_da.py",
    "scripts/run_aligned_gr4j_differentiable_ukf.py",
    "src/global_hydrology/__init__.py",
    "src/global_hydrology/assimilation/__init__.py",
    "src/global_hydrology/assimilation/conventional_ukf.py",
    "src/global_hydrology/models/__init__.py",
    "src/global_hydrology/models/differentiable_m4.py",
    "src/global_hydrology/models/static_encoder.py",
    "src/global_hydrology/models/m4_system_model.py",
    "src/global_hydrology/models/dl_ssm.py",
    "src/global_hydrology/models/hydro_system.py",
    "src/global_hydrology/models/differentiable_walrus.py",
    "src/global_hydrology/models/walrus_system_model.py",
    "src/global_hydrology/models/differentiable_hbv_lite.py",
    "src/global_hydrology/models/trainable_hbvlite_ukf_adapter.py",
    "src/global_hydrology/data/__init__.py",
    "src/global_hydrology/data/caravan_dataset.py",
    "src/global_hydrology/data/multi_obs_caravan.py",
    "results/tukf15_hbv_truth_balance_forward_gate_v1/registry.json",
)


def _safe_member_name(raw: str) -> str:
    value = PurePosixPath(raw)
    if value.is_absolute() or ".." in value.parts or not value.parts:
        raise ValueError(f"unsafe archive member: {raw}")
    normalized = value.as_posix()
    if normalized != raw or raw.startswith("/"):
        raise ValueError(f"archive member is not canonical POSIX text: {raw}")
    return normalized


def payload_members(deployment: Mapping[str, Any]) -> dict[str, Path]:
    deployment_common.validate_deployment(deployment)
    source = deployment["source_contract"]
    readonly_kalmannet = Path(source["readonly_kalmannet_root"])
    readonly_neuralhydrology = Path(source["readonly_neuralhydrology_root"])
    members: dict[str, Path] = {}

    def register(name: str, path: Path) -> None:
        member = _safe_member_name(name)
        resolved = path.resolve()
        if member in members and members[member] != resolved:
            raise ValueError(f"duplicate archive member with different source: {member}")
        if not resolved.is_file():
            raise FileNotFoundError(f"payload source is missing: {member}: {resolved}")
        members[member] = resolved

    for relative in (*APPLICATION_FILES, *PREFLIGHT_FILES):
        register(relative, ROOT / relative)
    for relative in READONLY_KALMANNET_FILES:
        register(
            f"G:/github/pycharm/projects/kalmannet/{relative}",
            readonly_kalmannet / relative,
        )

    external_relative = "src/scl_hydro/hbv_lite_numpy.py"
    external_source = readonly_neuralhydrology / external_relative
    register(
        "G:/github/pycharm/projects/neuralhydrology/" + external_relative,
        external_source,
    )
    register(
        "G:/github/pycharm/projects/kalmannet/"
        "G:/github/pycharm/projects/neuralhydrology/"
        + external_relative,
        external_source,
    )
    initializer = readonly_neuralhydrology / "src/scl_hydro/__init__.py"
    register(
        "G:/github/pycharm/projects/neuralhydrology/src/scl_hydro/__init__.py",
        initializer,
    )

    external_hash = source["external_numpy_hbv_sha256"]
    if sha256_file(external_source) != external_hash:
        raise ValueError("external NumPy HBV-light source hash changed")
    return dict(sorted(members.items()))


def _tar_info(name: str, size: int) -> tarfile.TarInfo:
    info = tarfile.TarInfo(name=name)
    info.size = int(size)
    info.mtime = 0
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    info.mode = 0o755 if name.endswith((".sh", ".slurm")) else 0o644
    return info


def write_deterministic_archive(
    destination: Path,
    members: Mapping[str, Path],
    *,
    virtual_members: Mapping[str, bytes] | None = None,
) -> None:
    target = Path(destination)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        raise FileExistsError(f"refusing to replace archive: {target}")
    virtual = dict(virtual_members or {})
    overlap = set(members) & set(virtual)
    if overlap:
        raise ValueError(f"real and virtual archive members overlap: {sorted(overlap)}")
    for name in (*members, *virtual):
        _safe_member_name(name)

    with target.open("xb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as zipped:
            with tarfile.open(
                fileobj=zipped, mode="w", format=tarfile.PAX_FORMAT
            ) as archive:
                for name in sorted((*members, *virtual)):
                    if name in virtual:
                        payload = virtual[name]
                    else:
                        payload = Path(members[name]).read_bytes()
                    archive.addfile(_tar_info(name, len(payload)), io.BytesIO(payload))


def build_bundle(
    output_root: Path | str | None = None,
    *,
    deployment_path: Path | str = DEFAULT_CONFIG,
) -> dict[str, Any]:
    deployment = deployment_common.load_deployment(deployment_path)
    output = (
        Path(output_root)
        if output_root is not None
        else deployment_common.resolve_root_relative(
            deployment["outputs"]["local_bundle_root"]
        )
    )
    output.mkdir(parents=True, exist_ok=True)
    archive_path = output / deployment["outputs"]["bundle_name"]
    external_manifest_path = output / deployment["outputs"]["bundle_manifest_name"]
    if archive_path.exists() or external_manifest_path.exists():
        raise FileExistsError("refusing to replace an existing HPC bundle or manifest")

    members = payload_members(deployment)
    member_hashes = {name: sha256_file(path) for name, path in members.items()}
    payload_manifest = {
        "schema_version": "tukf19_hpc_payload_manifest_v1",
        "deployment_id": deployment["deployment_id"],
        "scientific_experiment_id": deployment["scientific_experiment_id"],
        "deployment_config_sha256": sha256_file(deployment_path),
        "members": member_hashes,
    }
    payload_manifest_bytes = deployment_common.canonical_json_bytes(payload_manifest)
    payload_manifest_name = deployment["outputs"]["payload_manifest_name"]
    write_deterministic_archive(
        archive_path,
        members,
        virtual_members={payload_manifest_name: payload_manifest_bytes},
    )
    external_manifest = {
        "schema_version": "tukf19_hpc_bundle_manifest_v1",
        "deployment_id": deployment["deployment_id"],
        "scientific_experiment_id": deployment["scientific_experiment_id"],
        "archive_name": archive_path.name,
        "archive_sha256": sha256_file(archive_path),
        "archive_bytes": archive_path.stat().st_size,
        "payload_manifest_name": payload_manifest_name,
        "payload_manifest_sha256": deployment_common.sha256_bytes(
            payload_manifest_bytes
        ),
        "member_count": len(member_hashes),
        "members": member_hashes,
    }
    deployment_common.write_new_json(external_manifest_path, external_manifest)
    return {
        **external_manifest,
        "archive_path": archive_path,
        "manifest_path": external_manifest_path,
    }


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--output-root", type=Path)
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    result = build_bundle(args.output_root, deployment_path=args.config)
    print(
        json.dumps(
            {
                "status": "HPC_BUNDLE_COMPLETE",
                "archive": str(result["archive_path"]),
                "archive_sha256": result["archive_sha256"],
                "archive_bytes": result["archive_bytes"],
                "member_count": result["member_count"],
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
