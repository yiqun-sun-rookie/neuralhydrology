"""Run, independently verify, plot, and package TUKF19 after HPC smoke pass."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
from typing import Any, Mapping


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import build_tukf19_hpc_bundle as bundle_builder  # noqa: E402
from scripts import tukf19_hbv_rolling_origin_formal_common as scientific  # noqa: E402
from scripts import tukf19_hpc_deployment_common as deployment_common  # noqa: E402


DEFAULT_CONFIG = deployment_common.DEFAULT_CONFIG


def require_smoke_pass(
    smoke: Mapping[str, Any],
    *,
    deployment: Mapping[str, Any],
    expected_bundle_sha256: str,
) -> bool:
    if smoke.get("status") != "HPC_SMOKE_PASS":
        raise PermissionError("formal HPC execution requires HPC_SMOKE_PASS")
    checks = smoke.get("checks", {})
    if not checks or not all(bool(value) for value in checks.values()):
        raise PermissionError("formal HPC execution requires every smoke check true")
    if smoke.get("deployment_id") != deployment["deployment_id"]:
        raise PermissionError("smoke deployment identity differs")
    if smoke.get("bundle_sha256") != expected_bundle_sha256:
        raise PermissionError("smoke bundle binding differs")
    return True


def _run_step(command: list[str]) -> dict[str, Any]:
    started = time.perf_counter()
    completed = subprocess.run(command, cwd=ROOT, check=False)
    row = {
        "command": command,
        "return_code": int(completed.returncode),
        "elapsed_seconds": time.perf_counter() - started,
    }
    if completed.returncode != 0:
        raise RuntimeError(f"formal HPC step failed: {row}")
    return row


def validate_formal_outputs(
    deployment: Mapping[str, Any], contract: Mapping[str, Any]
) -> dict[str, Any]:
    result_root = scientific.resolve_output_path(
        contract, contract["outputs"]["result_root"]
    )
    figure_root = scientific.resolve_output_path(
        contract, contract["outputs"]["figure_root"]
    )
    registry = scientific.read_json(result_root / "registry.json")
    verification = scientific.read_json(result_root / "independent_verification.json")
    figure_manifest = scientific.read_json(figure_root / "manifest.json")
    histories = tuple(result_root.rglob("methods/*/history.json"))
    checks = {
        "registry_status": registry.get("status")
        == "FORMAL_COMPLETE_AWAITING_INDEPENDENT_VERIFICATION",
        "registry_rows": len(registry.get("rows", ())) == 162,
        "method_histories": len(histories) == 108,
        "independent_verification": verification.get("status") == "FORMAL_VERIFIED"
        and bool(verification.get("checks"))
        and all(verification["checks"].values()),
        "independent_readouts": int(
            verification.get("recomputed_test_readout_count", -1)
        )
        == 162,
        "verified_figures": figure_manifest.get("status")
        == "VERIFIED_FIGURES_COMPLETE",
        "scientific_identity": registry.get("experiment_id")
        == deployment["scientific_experiment_id"],
    }
    if not all(checks.values()):
        raise RuntimeError(f"formal HPC output validation failed: {checks}")
    return {
        "checks": checks,
        "result_root": result_root,
        "figure_root": figure_root,
        "registry_sha256": scientific.sha256_file(result_root / "registry.json"),
        "verification_sha256": scientific.sha256_file(
            result_root / "independent_verification.json"
        ),
        "figure_manifest_sha256": scientific.sha256_file(
            figure_root / "manifest.json"
        ),
    }


def _result_members(
    validation: Mapping[str, Any],
    *,
    smoke_path: Path,
    complete_status_path: Path,
) -> dict[str, Path]:
    members: dict[str, Path] = {}
    for root in (validation["result_root"], validation["figure_root"]):
        for path in sorted(Path(root).rglob("*")):
            if path.is_file():
                members[path.relative_to(ROOT).as_posix()] = path
    for path in (smoke_path, complete_status_path, DEFAULT_CONFIG):
        members[path.relative_to(ROOT).as_posix()] = path
    return dict(sorted(members.items()))


def _package_results(
    deployment: Mapping[str, Any],
    validation: Mapping[str, Any],
    *,
    smoke_path: Path,
    complete_status_path: Path,
) -> dict[str, Any]:
    archive_path = deployment_common.resolve_root_relative(
        deployment["outputs"]["formal_result_archive"]
    )
    external_manifest_path = archive_path.with_suffix(archive_path.suffix + ".sha256.json")
    if archive_path.exists() or external_manifest_path.exists():
        raise FileExistsError("refusing to replace formal HPC result package")
    members = _result_members(
        validation, smoke_path=smoke_path, complete_status_path=complete_status_path
    )
    hashes = {name: deployment_common.sha256_file(path) for name, path in members.items()}
    payload_manifest = {
        "schema_version": "tukf19_hpc_formal_result_payload_manifest_v1",
        "deployment_id": deployment["deployment_id"],
        "scientific_experiment_id": deployment["scientific_experiment_id"],
        "members": hashes,
    }
    virtual_name = "formal_result_payload_manifest.json"
    virtual_bytes = deployment_common.canonical_json_bytes(payload_manifest)
    bundle_builder.write_deterministic_archive(
        archive_path,
        members,
        virtual_members={virtual_name: virtual_bytes},
    )
    external_manifest = {
        "schema_version": "tukf19_hpc_formal_result_bundle_manifest_v1",
        "deployment_id": deployment["deployment_id"],
        "scientific_experiment_id": deployment["scientific_experiment_id"],
        "archive_name": archive_path.name,
        "archive_sha256": deployment_common.sha256_file(archive_path),
        "archive_bytes": archive_path.stat().st_size,
        "payload_manifest_name": virtual_name,
        "payload_manifest_sha256": deployment_common.sha256_bytes(virtual_bytes),
        "member_count": len(hashes),
        "members": hashes,
    }
    deployment_common.write_new_json(external_manifest_path, external_manifest)
    return {
        **external_manifest,
        "archive_path": archive_path,
        "manifest_path": external_manifest_path,
    }


def run_pipeline(
    *,
    deployment_path: Path = DEFAULT_CONFIG,
    bundle_manifest_path: Path | None = None,
) -> dict[str, Any]:
    deployment = deployment_common.load_deployment(deployment_path)
    external_path = bundle_manifest_path or (
        ROOT / "_transport" / deployment["outputs"]["bundle_manifest_name"]
    )
    external = deployment_common.read_json(external_path)
    smoke_path = deployment_common.resolve_root_relative(
        deployment["outputs"]["smoke_report"]
    )
    smoke = deployment_common.read_json(smoke_path)
    require_smoke_pass(
        smoke,
        deployment=deployment,
        expected_bundle_sha256=external["archive_sha256"],
    )
    contract = scientific.load_contract()
    status_root = deployment_common.resolve_root_relative(
        deployment["outputs"]["hpc_status_root"]
    )
    start_path = status_root / "formal_started.json"
    complete_path = status_root / "formal_complete.json"
    if start_path.exists() or complete_path.exists():
        raise FileExistsError("refusing to replace formal HPC status evidence")
    started_at = datetime.now(timezone.utc).isoformat()
    deployment_common.write_new_json(
        start_path,
        {
            "schema_version": "tukf19_hpc_formal_start_v1",
            "deployment_id": deployment["deployment_id"],
            "scientific_experiment_id": deployment["scientific_experiment_id"],
            "bundle_sha256": external["archive_sha256"],
            "smoke_report_sha256": deployment_common.sha256_file(smoke_path),
            "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
            "node": os.environ.get("SLURMD_NODENAME"),
            "started_at_utc": started_at,
        },
    )
    commands = [
        [
            sys.executable,
            "-B",
            "scripts/run_tukf19_hbv_rolling_origin_formal_execution.py",
            "--confirm-formal-training",
            "--confirm-parallel-execution",
        ],
        [
            sys.executable,
            "-B",
            "scripts/verify_tukf19_hbv_rolling_origin_formal_execution.py",
        ],
        [
            sys.executable,
            "-B",
            "scripts/plot_tukf19_hbv_rolling_origin_formal_execution.py",
        ],
    ]
    steps: list[dict[str, Any]] = []
    try:
        for command in commands:
            steps.append(_run_step(command))
        validation = validate_formal_outputs(deployment, contract)
        completion = {
            "schema_version": "tukf19_hpc_formal_complete_v1",
            "deployment_id": deployment["deployment_id"],
            "scientific_experiment_id": deployment["scientific_experiment_id"],
            "status": "HPC_FORMAL_PIPELINE_VERIFIED",
            "bundle_sha256": external["archive_sha256"],
            "smoke_report_sha256": deployment_common.sha256_file(smoke_path),
            "steps": steps,
            "validation": {
                key: value
                for key, value in validation.items()
                if key not in {"result_root", "figure_root"}
            },
            "finished_at_utc": datetime.now(timezone.utc).isoformat(),
        }
        deployment_common.write_new_json(complete_path, completion)
        package = _package_results(
            deployment,
            validation,
            smoke_path=smoke_path,
            complete_status_path=complete_path,
        )
        return {**completion, "package": package}
    except BaseException as error:
        failure_name = f"formal_failure_{os.environ.get('SLURM_JOB_ID', 'unknown')}.json"
        failure_path = status_root / failure_name
        if not failure_path.exists():
            deployment_common.write_new_json(
                failure_path,
                {
                    "schema_version": "tukf19_hpc_formal_failure_v1",
                    "deployment_id": deployment["deployment_id"],
                    "scientific_experiment_id": deployment["scientific_experiment_id"],
                    "status": "HPC_FORMAL_PIPELINE_FAILED",
                    "steps": steps,
                    "error_type": type(error).__name__,
                    "error": str(error),
                    "traceback": traceback.format_exc(),
                    "failed_at_utc": datetime.now(timezone.utc).isoformat(),
                },
            )
        raise


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--bundle-manifest", type=Path)
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    report = run_pipeline(
        deployment_path=args.config.resolve(),
        bundle_manifest_path=(
            args.bundle_manifest.resolve() if args.bundle_manifest else None
        ),
    )
    print(
        json.dumps(
            {
                "status": report["status"],
                "archive_sha256": report["package"]["archive_sha256"],
                "archive_bytes": report["package"]["archive_bytes"],
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
