"""Plan or launch one validation-only development run.

The command is deliberately dry-run by default.  A real, hours-long training
process requires both ``--execute`` and ``--operator-approved-heavy-compute``.
This module never evaluates the sealed test period.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import socket
import subprocess
import sys
import tempfile
import threading
import time
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ruamel.yaml import YAML

from neuralhydrology.utils.config import Config
from src.modern_transformer_moe.scripts import audit_configs
from src.modern_transformer_moe.scripts import build_epoch030_metrics_artifact
from src.modern_transformer_moe.scripts.candidate_safe_data import (assert_safe_data_unchanged, audit_access_log,
                                                                   capture_safe_data_snapshot)


REPO_ROOT = Path(__file__).resolve().parents[3]
IDEA_DIR = REPO_ROOT / "src" / "modern_transformer_moe"
REGISTRY_RELATIVE_PATH = Path("src/modern_transformer_moe/registry/experiments.csv")
RUN_BINDINGS_RELATIVE_PATH = Path("src/modern_transformer_moe/registry/development_run_bindings.json")
RUN_BINDINGS_LOCK_RELATIVE_PATH = Path("src/modern_transformer_moe/.development_run_bindings.lock")
RUN_BINDING_SCHEMA_VERSION = 2
INVOCATIONS_RELATIVE_ROOT = Path("results/30_modern_transformer_moe/_development_invocations")
REGISTRY_LOCK_RELATIVE_PATH = Path("src/modern_transformer_moe/.development_registry.lock")
CONFIG_RELATIVE_BY_ID = {
    "B01": Path("src/modern_transformer_moe/configs/baseline_lstm_s100.yml"),
    "D01": Path("src/modern_transformer_moe/configs/dense_d128_l4_s100.yml"),
    "D02": Path("src/modern_transformer_moe/configs/dense_d256_l4_s100.yml"),
    "D03": Path("src/modern_transformer_moe/configs/dense_d256_l8_s100.yml"),
    "M01": Path("src/modern_transformer_moe/configs/moe_selected_s100.yml"),
}
DENSE_IDS = {"D01", "D02", "D03"}
CLI_EXPERIMENT_IDS = {*CONFIG_RELATIVE_BY_ID, "SELECTED_DENSE"}
DEVELOPMENT_SEEDS = {100, 200, 300}
DERIVED_CONFIG_RELATIVE_ROOT = Path("src/modern_transformer_moe/configs/development_seeds")
DERIVED_CONFIG_STEMS = {
    "B01": "baseline_lstm",
    "SELECTED_DENSE": "selected_dense",
    "M01": "moe_selected",
}
DERIVED_PROVENANCE_KEYS = {
    "schema_version",
    "role",
    "seed",
    "derived_config_path",
    "derived_config_sha256",
    "base_config_path",
    "base_config_sha256",
    "selection_report_path",
    "selection_report_sha256",
    "selected_dense_experiment_id",
    "allowed_config_differences",
}
RUN_BINDING_KEYS = {
    "role",
    "seed",
    "run_id",
    "status",
    "config_path",
    "config_sha256",
    "provenance_path",
    "provenance_sha256",
    "invocation_manifest_path",
    "invocation_manifest_sha256",
    "run_dir",
    "metrics_artifact_path",
    "metrics_artifact_sha256",
    "failure_stage",
    "failure_reason",
    "created_at_utc",
    "updated_at_utc",
    "history",
}
RUN_BINDING_ATTEMPT_KEYS = RUN_BINDING_KEYS - {"history"}
RUN_BINDING_STATUSES = {"RUNNING", "POSTPROCESSING", "COMPLETE", "FAILED"}
HEARTBEAT_INTERVAL_SECONDS = 30.0
EPOCH030_REQUIRED_RELATIVE_FILES = (
    Path("config.yml"),
    Path("model_epoch030.pt"),
    Path("validation/model_epoch030/validation_metrics.csv"),
    Path("validation/model_epoch030/validation_results.p"),
)
EPOCH030_INVENTORY_RELATIVE_FILES = (*EPOCH030_REQUIRED_RELATIVE_FILES, Path("epoch030_metrics.json"))
CRITICAL_RELATIVE_FILES = (
    Path("neuralhydrology/nh_run.py"),
    Path("neuralhydrology/datasetzoo/__init__.py"),
    Path("neuralhydrology/datasetzoo/basedataset.py"),
    Path("neuralhydrology/datasetzoo/camelsus.py"),
    Path("neuralhydrology/datasetzoo/camelsus_track0_bundle.py"),
    Path("neuralhydrology/modelzoo/__init__.py"),
    Path("neuralhydrology/modelzoo/modern_causal_transformer.py"),
    Path("neuralhydrology/training/__init__.py"),
    Path("neuralhydrology/training/basetrainer.py"),
    Path("neuralhydrology/training/loss.py"),
    Path("neuralhydrology/training/regularization.py"),
    Path("neuralhydrology/utils/config.py"),
    Path("src/modern_transformer_moe/scripts/audit_configs.py"),
    Path("src/modern_transformer_moe/scripts/audit_track0_supervision_bundle.py"),
    Path("src/modern_transformer_moe/scripts/build_dense_selection_report.py"),
    Path("src/modern_transformer_moe/scripts/build_epoch030_metrics_artifact.py"),
    Path("src/modern_transformer_moe/scripts/build_single_seed_dense_gate.py"),
    Path("src/modern_transformer_moe/scripts/candidate_safe_data.py"),
    Path("src/modern_transformer_moe/scripts/inspect_development_runs.py"),
    Path("src/modern_transformer_moe/scripts/run_development.py"),
    Path("src/modern_transformer_moe/scripts/track0_bundle_common.py"),
    Path("src/fair_benchmark/frozen/track0_forcing_only_basins.txt"),
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _relative(path: Path, repo_root: Path) -> str:
    return Path(path).resolve().relative_to(Path(repo_root).resolve()).as_posix()


def _atomic_json(path: Path, value: dict[str, Any], *, create: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if create:
        with path.open("x", encoding="utf-8") as stream:
            json.dump(value, stream, indent=2, sort_keys=True)
            stream.write("\n")
        return
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        with temporary.open("x", encoding="utf-8") as stream:
            json.dump(value, stream, indent=2, sort_keys=True)
            stream.write("\n")
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _process_start_time(process_id: int) -> float:
    """Return a process creation timestamp suitable for detecting process-ID reuse."""
    try:
        import psutil

        return float(psutil.Process(process_id).create_time())
    except (ImportError, OSError):
        stat_path = Path(f"/proc/{process_id}/stat")
        proc_stat_path = Path("/proc/stat")
        if not stat_path.is_file() or not proc_stat_path.is_file():
            raise RuntimeError("Cannot determine process start time without psutil or Linux /proc.")
        fields = stat_path.read_text(encoding="utf-8").rsplit(")", 1)[1].split()
        start_ticks = int(fields[19])
        boot_line = next(line for line in proc_stat_path.read_text(encoding="utf-8").splitlines()
                         if line.startswith("btime "))
        boot_time = int(boot_line.split()[1])
        return boot_time + start_ticks / os.sysconf("SC_CLK_TCK")


def _tee_stream(stream, destination: Path, console) -> None:
    with destination.open("x", encoding="utf-8", buffering=1) as log:
        for line in iter(stream.readline, ""):
            log.write(line)
            console.write(line)
            console.flush()
    stream.close()


def _run_training_process(command: list[str],
                          repo_root: Path,
                          environment: dict[str, str],
                          manifest: dict[str, Any],
                          manifest_path: Path,
                          invocation_dir: Path,
                          heartbeat_interval_seconds: float = HEARTBEAT_INTERVAL_SECONDS) -> int:
    """Run training with tee'd logs and an atomic heartbeat-bound process identity."""
    stdout_path = invocation_dir / "training_stdout.log"
    stderr_path = invocation_dir / "training_stderr.log"
    process = subprocess.Popen(
        command,
        cwd=repo_root,
        env=environment,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
    )
    if process.stdout is None or process.stderr is None:
        raise RuntimeError("Training child process did not expose stdout and stderr pipes.")
    manifest["child_process"] = {
        "process_id": process.pid,
        "process_start_time_epoch_seconds": _process_start_time(process.pid),
    }
    manifest["logs"] = {
        "stdout": _relative(stdout_path, repo_root),
        "stderr": _relative(stderr_path, repo_root),
    }
    manifest["last_heartbeat_at_utc"] = datetime.now(timezone.utc).isoformat()
    _atomic_json(manifest_path, manifest)

    threads = [
        threading.Thread(target=_tee_stream, args=(process.stdout, stdout_path, sys.stdout), daemon=True),
        threading.Thread(target=_tee_stream, args=(process.stderr, stderr_path, sys.stderr), daemon=True),
    ]
    for thread in threads:
        thread.start()
    while True:
        try:
            return_code = process.wait(timeout=heartbeat_interval_seconds)
            break
        except subprocess.TimeoutExpired:
            manifest["last_heartbeat_at_utc"] = datetime.now(timezone.utc).isoformat()
            _atomic_json(manifest_path, manifest)
    for thread in threads:
        thread.join()
    manifest["last_heartbeat_at_utc"] = datetime.now(timezone.utc).isoformat()
    manifest["child_process"]["return_code"] = return_code
    _atomic_json(manifest_path, manifest)
    return return_code


def _load_run_bindings(repo_root: Path) -> dict[str, Any]:
    repo_root = Path(repo_root).resolve()
    path = repo_root / RUN_BINDINGS_RELATIVE_PATH
    if not path.is_file():
        raise FileNotFoundError(f"development run binding registry does not exist: {path}")
    value = audit_configs.load_json(path)
    if (set(value) != {"schema_version", "records"}
            or value.get("schema_version") != RUN_BINDING_SCHEMA_VERSION):
        raise ValueError("development run binding registry schema mismatch")
    records = value.get("records")
    if not isinstance(records, list):
        raise ValueError("development run binding registry records must be a list")
    seen_role_seeds: set[tuple[str, int]] = set()
    seen_run_ids: set[str] = set()
    for index, record in enumerate(records):
        if not isinstance(record, dict) or set(record) != RUN_BINDING_KEYS:
            raise ValueError(f"development run binding record {index} has an invalid schema")
        if record.get("role") not in CLI_EXPERIMENT_IDS or record.get("seed") not in DEVELOPMENT_SEEDS:
            raise ValueError(f"development run binding record {index} has an invalid role or seed")
        role_seed = (record["role"], record["seed"])
        if role_seed in seen_role_seeds:
            raise ValueError(f"development run binding registry repeats role/seed {role_seed}")
        seen_role_seeds.add(role_seed)
        if record.get("status") not in RUN_BINDING_STATUSES:
            raise ValueError(f"development run binding record {index} has an invalid status")
        if (not isinstance(record.get("run_id"), str)
                or re.fullmatch(r"[A-Za-z0-9_.-]+", record["run_id"]) is None):
            raise ValueError(f"development run binding record {index} has an invalid run_id")
        expected_manifest = (INVOCATIONS_RELATIVE_ROOT / record["run_id"] / "run_manifest.json").as_posix()
        if record["invocation_manifest_path"] != expected_manifest:
            raise ValueError(f"development run binding record {index} has a non-canonical invocation manifest")
        history = record.get("history")
        if not isinstance(history, list):
            raise ValueError(f"development run binding record {index} history must be a list")
        attempt_ids = {record["run_id"]}
        for attempt_index, attempt in enumerate(history):
            if not isinstance(attempt, dict) or set(attempt) != RUN_BINDING_ATTEMPT_KEYS:
                raise ValueError(
                    f"development run binding record {index} history attempt {attempt_index} has an invalid schema"
                )
            if (attempt.get("role") != record["role"] or attempt.get("seed") != record["seed"]
                    or attempt.get("status") != "FAILED"):
                raise ValueError(
                    f"development run binding record {index} history attempt {attempt_index} is not a matching failure"
                )
            if attempt.get("run_id") in attempt_ids:
                raise ValueError(f"development run binding record {index} repeats an attempt run_id")
            attempt_ids.add(attempt["run_id"])
            expected_history_manifest = (
                INVOCATIONS_RELATIVE_ROOT / attempt["run_id"] / "run_manifest.json"
            ).as_posix()
            if (attempt["invocation_manifest_path"] != expected_history_manifest
                    or attempt["invocation_manifest_sha256"] == "not_bound"
                    or attempt["failure_stage"] == "not_applicable"
                    or attempt["failure_reason"] == "not_applicable"):
                raise ValueError(
                    f"development run binding record {index} history attempt {attempt_index} lacks failure evidence"
                )
            history_manifest_path = repo_root / expected_history_manifest
            if not history_manifest_path.is_file():
                raise FileNotFoundError(
                    f"history invocation manifest does not exist for run_id={attempt['run_id']}: "
                    f"{history_manifest_path}"
                )
            if _sha256(history_manifest_path) != attempt["invocation_manifest_sha256"]:
                raise ValueError(f"history invocation manifest hash drifted for run_id={attempt['run_id']}")
            for field in ("config_path", "config_sha256", "provenance_path", "provenance_sha256"):
                if attempt[field] != record[field]:
                    raise ValueError(
                        f"development run binding record {index} history attempt {attempt_index} changed {field}"
                    )
        repeated_global_run_ids = attempt_ids & seen_run_ids
        if repeated_global_run_ids:
            raise ValueError(f"development run binding registry repeats run_id values {repeated_global_run_ids}")
        seen_run_ids.update(attempt_ids)
        if record["status"] == "FAILED":
            if (record["failure_stage"] == "not_applicable" or record["failure_reason"] == "not_applicable"
                    or record["invocation_manifest_sha256"] == "not_bound"):
                raise ValueError(f"development run binding record {index} has incomplete failure evidence")
    return value


def _write_run_bindings_locked(repo_root: Path, mutate) -> Any:
    registry_path = repo_root / RUN_BINDINGS_RELATIVE_PATH
    lock_path = repo_root / RUN_BINDINGS_LOCK_RELATIVE_PATH
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as error:
        raise RuntimeError(f"development run binding lock already exists: {lock_path}") from error
    os.close(descriptor)
    temporary: Path | None = None
    try:
        value = _load_run_bindings(repo_root)
        result = mutate(value["records"])
        temporary = registry_path.with_name(f".{registry_path.name}.{os.getpid()}.tmp")
        with temporary.open("x", encoding="utf-8") as stream:
            json.dump(value, stream, indent=2, sort_keys=True)
            stream.write("\n")
        os.replace(temporary, registry_path)
        temporary = None
        return result
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
        lock_path.unlink(missing_ok=True)


def _matching_run_bindings(records: list[dict[str, Any]], role: str, seed: int) -> list[dict[str, Any]]:
    return [record for record in records if record.get("role") == role and record.get("seed") == seed]


def _all_bound_run_ids(records: list[dict[str, Any]]) -> set[str]:
    return {
        attempt["run_id"]
        for record in records
        for attempt in ({"run_id": record["run_id"]}, *record["history"])
    }


def _reserve_run_binding(
    role: str,
    seed: int,
    run_id: str,
    config_path: Path,
    provenance_path: Path | None,
    repo_root: Path,
) -> dict[str, Any]:
    """Atomically reserve the only admissible development run for one role/seed."""
    config_relative = _relative(config_path, repo_root)
    provenance_relative = _relative(provenance_path, repo_root) if provenance_path is not None else "not_applicable"
    provenance_sha256 = _sha256(provenance_path) if provenance_path is not None else "not_applicable"
    manifest_relative = (INVOCATIONS_RELATIVE_ROOT / run_id / "run_manifest.json").as_posix()

    def mutate(records: list[dict[str, Any]]) -> dict[str, Any]:
        matches = _matching_run_bindings(records, role, seed)
        if len(matches) > 1:
            raise ValueError(f"non-unique development run bindings exist for {role}:{seed}")
        if matches:
            existing = matches[0]
            if existing["run_id"] != run_id:
                raise FileExistsError(
                    f"{role}:{seed} is already reserved by run_id={existing['run_id']} with status={existing['status']}"
                )
            expected = {
                "config_path": config_relative,
                "config_sha256": _sha256(config_path),
                "provenance_path": provenance_relative,
                "provenance_sha256": provenance_sha256,
                "invocation_manifest_path": manifest_relative,
            }
            if any(existing[field] != value for field, value in expected.items()):
                raise ValueError(f"existing {role}:{seed} reservation config/provenance binding drifted")
            if existing["status"] != "RUNNING":
                raise FileExistsError(
                    f"{role}:{seed} run_id={run_id} is already {existing['status']}; use --finalize-run-dir"
                )
            return dict(existing)
        if run_id in _all_bound_run_ids(records):
            raise FileExistsError(f"development run_id={run_id!r} is already used by another binding or history")
        now = datetime.now(timezone.utc).isoformat()
        record = {
            "role": role,
            "seed": seed,
            "run_id": run_id,
            "status": "RUNNING",
            "config_path": config_relative,
            "config_sha256": _sha256(config_path),
            "provenance_path": provenance_relative,
            "provenance_sha256": provenance_sha256,
            "invocation_manifest_path": manifest_relative,
            "invocation_manifest_sha256": "not_bound",
            "run_dir": "not_bound",
            "metrics_artifact_path": "not_bound",
            "metrics_artifact_sha256": "not_bound",
            "failure_stage": "not_applicable",
            "failure_reason": "not_applicable",
            "created_at_utc": now,
            "updated_at_utc": now,
            "history": [],
        }
        records.append(record)
        return dict(record)

    return _write_run_bindings_locked(repo_root, mutate)


def _attempt_run_directories(attempt: dict[str, Any], repo_root: Path) -> list[Path]:
    """Return every run directory claimed by one immutable failed-attempt manifest."""
    expected_manifest = (INVOCATIONS_RELATIVE_ROOT / attempt["run_id"] / "run_manifest.json").as_posix()
    if attempt["invocation_manifest_path"] != expected_manifest:
        raise ValueError(f"failed attempt {attempt['run_id']} invocation-manifest path is not canonical")
    manifest_path = (repo_root / expected_manifest).resolve()
    if not manifest_path.is_file():
        raise FileNotFoundError(f"failed attempt invocation manifest does not exist: {manifest_path}")
    if attempt["invocation_manifest_sha256"] != _sha256(manifest_path):
        raise ValueError(f"failed attempt {attempt['run_id']} invocation manifest hash drifted")
    manifest = audit_configs.load_json(manifest_path)
    if (manifest.get("run_id") != attempt["run_id"] or manifest.get("experiment_id") != attempt["role"]
            or int(manifest.get("seed", -1)) != attempt["seed"] or manifest.get("status") != "FAILED"):
        raise ValueError(f"failed attempt {attempt['run_id']} invocation manifest identity/status drifted")

    relative_candidates: list[str] = []
    if attempt["run_dir"] != "not_bound":
        relative_candidates.append(attempt["run_dir"])
    if isinstance(manifest.get("run_dir"), str):
        relative_candidates.append(manifest["run_dir"])
    created = manifest.get("new_run_directories", [])
    if not isinstance(created, list) or any(not isinstance(path, str) for path in created):
        raise ValueError(f"failed attempt {attempt['run_id']} has invalid new_run_directories evidence")
    relative_candidates.extend(created)

    directories: list[Path] = []
    for relative in relative_candidates:
        candidate = (repo_root / relative).resolve()
        try:
            candidate.relative_to(repo_root)
        except ValueError as error:
            raise ValueError(f"failed attempt {attempt['run_id']} run directory leaves the repository") from error
        if candidate not in directories:
            directories.append(candidate)
    return directories


def _epoch030_product_inventory(run_directories: list[Path], repo_root: Path) -> list[dict[str, Any]]:
    """Snapshot all expected epoch-30 files without reading validation contents."""
    inventory: list[dict[str, Any]] = []
    for run_dir in run_directories:
        products: dict[str, dict[str, Any]] = {}
        for relative in EPOCH030_INVENTORY_RELATIVE_FILES:
            path = run_dir / relative
            if path.is_file():
                products[relative.as_posix()] = {
                    "state": "present",
                    "sha256": _sha256(path),
                    "size_bytes": path.stat().st_size,
                }
            else:
                products[relative.as_posix()] = {"state": "missing"}
        inventory.append({"run_dir": _relative(run_dir, repo_root), "products": products})
    return inventory


def _complete_epoch030_run_directories(attempt: dict[str, Any], repo_root: Path) -> list[Path]:
    """Verify the failed inventory and find evidence that must be finalized, not retrained."""
    run_directories = _attempt_run_directories(attempt, repo_root)
    manifest_path = repo_root / attempt["invocation_manifest_path"]
    manifest = audit_configs.load_json(manifest_path)
    inventory = manifest.get("epoch030_product_inventory")
    if not isinstance(inventory, list):
        raise ValueError(f"failed attempt {attempt['run_id']} has no epoch-30 product inventory")
    expected_run_directories = {_relative(path, repo_root): path for path in run_directories}
    if (len(inventory) != len(expected_run_directories)
            or {item.get("run_dir") for item in inventory if isinstance(item, dict)} != set(expected_run_directories)):
        raise ValueError(f"failed attempt {attempt['run_id']} product inventory does not cover its run directories")

    complete: list[Path] = []
    expected_product_keys = {path.as_posix() for path in EPOCH030_INVENTORY_RELATIVE_FILES}
    for item in inventory:
        if not isinstance(item, dict) or set(item) != {"run_dir", "products"}:
            raise ValueError(f"failed attempt {attempt['run_id']} has an invalid product-inventory entry")
        run_dir = expected_run_directories[item["run_dir"]]
        products = item["products"]
        if not isinstance(products, dict) or set(products) != expected_product_keys:
            raise ValueError(f"failed attempt {attempt['run_id']} product-inventory schema drifted")
        for relative, evidence in products.items():
            if not isinstance(evidence, dict) or evidence.get("state") not in {"present", "missing"}:
                raise ValueError(f"failed attempt {attempt['run_id']} has invalid evidence for {relative}")
            path = run_dir / relative
            if evidence["state"] == "missing":
                if set(evidence) != {"state"} or path.exists():
                    raise ValueError(f"failed attempt {attempt['run_id']} product inventory drifted at {path}")
                continue
            if set(evidence) != {"state", "sha256", "size_bytes"}:
                raise ValueError(f"failed attempt {attempt['run_id']} has incomplete evidence for {relative}")
            if (not path.is_file() or _sha256(path) != evidence["sha256"]
                    or path.stat().st_size != evidence["size_bytes"]):
                raise ValueError(f"failed attempt {attempt['run_id']} product hash/size drifted at {path}")
        try:
            build_epoch030_metrics_artifact.preflight(
                attempt["role"],
                run_dir,
                repo_root,
                source_config_path=repo_root / attempt["config_path"],
            )
        except Exception:
            continue
        else:
            complete.append(run_dir)
    if attempt["metrics_artifact_path"] != "not_bound":
        artifact_path = (repo_root / attempt["metrics_artifact_path"]).resolve()
        try:
            artifact_path.relative_to(repo_root)
        except ValueError as error:
            raise ValueError("failed attempt metrics artifact leaves the repository") from error
        if not artifact_path.is_file() or _sha256(artifact_path) != attempt["metrics_artifact_sha256"]:
            raise ValueError("failed attempt metrics artifact hash binding drifted")
    return complete


def _retry_failed_run_binding(
    role: str,
    seed: int,
    failed_run_id: str,
    new_run_id: str,
    config_path: Path,
    provenance_path: Path | None,
    repo_root: Path,
) -> dict[str, Any]:
    """Atomically archive one failed attempt and reserve a distinct replacement."""
    config_relative = _relative(config_path, repo_root)
    provenance_relative = _relative(provenance_path, repo_root) if provenance_path is not None else "not_applicable"
    provenance_sha256 = _sha256(provenance_path) if provenance_path is not None else "not_applicable"
    manifest_relative = (INVOCATIONS_RELATIVE_ROOT / new_run_id / "run_manifest.json").as_posix()

    def mutate(records: list[dict[str, Any]]) -> dict[str, Any]:
        matches = _matching_run_bindings(records, role, seed)
        if len(matches) != 1:
            raise ValueError(f"expected exactly one failed development run for {role}:{seed}, found {len(matches)}")
        record = matches[0]
        if record["status"] != "FAILED":
            raise ValueError(f"controlled retry requires {role}:{seed} status FAILED, found {record['status']}")
        if record["run_id"] != failed_run_id:
            raise ValueError(
                f"controlled retry expected failed run_id={failed_run_id}, found current run_id={record['run_id']}"
            )
        used_run_ids = _all_bound_run_ids(records)
        if new_run_id in used_run_ids:
            raise FileExistsError(f"controlled retry requires a new run_id; {new_run_id!r} was already used")
        expected = {
            "config_path": config_relative,
            "config_sha256": _sha256(config_path),
            "provenance_path": provenance_relative,
            "provenance_sha256": provenance_sha256,
        }
        if any(record[field] != value for field, value in expected.items()):
            raise ValueError(f"failed {role}:{seed} config/provenance binding drifted")
        if (repo_root / INVOCATIONS_RELATIVE_ROOT / new_run_id).exists():
            raise FileExistsError(f"refusing to overwrite development invocation for retry: {new_run_id}")
        complete = _complete_epoch030_run_directories(record, repo_root)
        if complete:
            relative = [_relative(path, repo_root) for path in complete]
            raise FileExistsError(
                f"failed {role}:{seed} already has complete epoch-30 products at {relative}; "
                "use --finalize-run-dir instead of retraining"
            )

        previous = {key: deepcopy(record[key]) for key in RUN_BINDING_ATTEMPT_KEYS}
        record["history"].append(previous)
        now = datetime.now(timezone.utc).isoformat()
        record.update({
            "run_id": new_run_id,
            "status": "RUNNING",
            "invocation_manifest_path": manifest_relative,
            "invocation_manifest_sha256": "not_bound",
            "run_dir": "not_bound",
            "metrics_artifact_path": "not_bound",
            "metrics_artifact_sha256": "not_bound",
            "failure_stage": "not_applicable",
            "failure_reason": "not_applicable",
            "created_at_utc": now,
            "updated_at_utc": now,
        })
        return deepcopy(record)

    return _write_run_bindings_locked(repo_root, mutate)


def _mark_run_binding_failed(
    role: str,
    seed: int,
    run_id: str,
    repo_root: Path,
    *,
    manifest_path: Path,
    failure_stage: str,
    failure_reason: str,
    run_dir: Path | None,
) -> dict[str, Any]:
    """Atomically bind a failed attempt to its retained invocation evidence."""
    if not failure_stage or not failure_reason:
        raise ValueError("FAILED transition requires a failure stage and reason")
    manifest_relative = _relative(manifest_path, repo_root)
    expected_manifest = (INVOCATIONS_RELATIVE_ROOT / run_id / "run_manifest.json").as_posix()
    if manifest_relative != expected_manifest or not manifest_path.is_file():
        raise ValueError("FAILED transition requires the canonical retained invocation manifest")
    manifest_sha256 = _sha256(manifest_path)
    run_relative = _relative(run_dir, repo_root) if run_dir is not None else "not_bound"
    artifact_path = run_dir / "epoch030_metrics.json" if run_dir is not None else None
    artifact_relative = (
        _relative(artifact_path, repo_root)
        if artifact_path is not None and artifact_path.is_file()
        else "not_bound"
    )
    artifact_sha256 = _sha256(artifact_path) if artifact_path is not None and artifact_path.is_file() else "not_bound"

    def mutate(records: list[dict[str, Any]]) -> dict[str, Any]:
        matches = _matching_run_bindings(records, role, seed)
        if len(matches) != 1:
            raise ValueError(f"expected exactly one development run binding for {role}:{seed}, found {len(matches)}")
        record = matches[0]
        if record["run_id"] != run_id:
            raise FileExistsError(f"{role}:{seed} is reserved by a different run_id={record['run_id']}")
        if record["status"] == "COMPLETE":
            raise ValueError(f"cannot mark completed {role}:{seed} as FAILED")
        if record["status"] not in {"RUNNING", "POSTPROCESSING", "FAILED"}:
            raise ValueError(f"cannot transition {role}:{seed} from {record['status']} to FAILED")
        if record["invocation_manifest_path"] != manifest_relative:
            raise ValueError(f"{role}:{seed} invocation-manifest binding drifted")
        if run_relative != "not_bound" and record["run_dir"] not in {"not_bound", run_relative}:
            raise ValueError(f"{role}:{seed} failure identifies a different run directory")
        expected_failed = {
            "invocation_manifest_sha256": manifest_sha256,
            "run_dir": run_relative if run_relative != "not_bound" else record["run_dir"],
            "metrics_artifact_path": artifact_relative,
            "metrics_artifact_sha256": artifact_sha256,
            "failure_stage": failure_stage,
            "failure_reason": failure_reason,
        }
        if record["status"] == "FAILED":
            if any(record[field] != value for field, value in expected_failed.items()):
                raise ValueError(f"FAILED evidence for {role}:{seed} is immutable")
            return deepcopy(record)
        record.update({
            "status": "FAILED",
            **expected_failed,
            "updated_at_utc": datetime.now(timezone.utc).isoformat(),
        })
        return deepcopy(record)

    return _write_run_bindings_locked(repo_root, mutate)


def _transition_run_binding(
    role: str,
    seed: int,
    run_id: str,
    status: str,
    repo_root: Path,
    *,
    run_dir: Path,
    artifact_path: Path | None = None,
) -> dict[str, Any]:
    if status not in {"POSTPROCESSING", "COMPLETE"}:
        raise ValueError(f"unsupported development run transition: {status}")
    run_relative = _relative(run_dir, repo_root)

    def mutate(records: list[dict[str, Any]]) -> dict[str, Any]:
        matches = _matching_run_bindings(records, role, seed)
        if len(matches) != 1:
            raise ValueError(f"expected exactly one development run binding for {role}:{seed}, found {len(matches)}")
        record = matches[0]
        if record["run_id"] != run_id:
            raise FileExistsError(f"{role}:{seed} is reserved by a different run_id={record['run_id']}")
        if record["run_dir"] not in {"not_bound", run_relative}:
            raise ValueError(f"{role}:{seed} binding already identifies a different run directory")
        if status == "POSTPROCESSING":
            if record["status"] == "COMPLETE":
                if record["run_dir"] != run_relative:
                    raise ValueError(f"completed {role}:{seed} run directory mismatch")
                return dict(record)
            if record["status"] not in {"RUNNING", "POSTPROCESSING", "FAILED"}:
                raise ValueError(f"cannot transition {role}:{seed} from {record['status']} to POSTPROCESSING")
            record["status"] = "POSTPROCESSING"
            record["run_dir"] = run_relative
        else:
            if artifact_path is None or not artifact_path.is_file():
                raise FileNotFoundError("COMPLETE transition requires an existing metrics artifact")
            artifact_relative = _relative(artifact_path, repo_root)
            artifact_sha256 = _sha256(artifact_path)
            if record["status"] == "COMPLETE":
                expected = (run_relative, artifact_relative, artifact_sha256)
                actual = (record["run_dir"], record["metrics_artifact_path"], record["metrics_artifact_sha256"])
                if actual != expected:
                    raise ValueError(f"completed {role}:{seed} artifact binding mismatch")
                return dict(record)
            if record["status"] not in {"RUNNING", "POSTPROCESSING"}:
                raise ValueError(f"cannot transition {role}:{seed} from {record['status']} to COMPLETE")
            record.update({
                "status": "COMPLETE",
                "run_dir": run_relative,
                "metrics_artifact_path": artifact_relative,
                "metrics_artifact_sha256": artifact_sha256,
            })
            manifest_path = repo_root / record["invocation_manifest_path"]
            if manifest_path.is_file():
                record["invocation_manifest_sha256"] = _sha256(manifest_path)
        record["updated_at_utc"] = datetime.now(timezone.utc).isoformat()
        return dict(record)

    return _write_run_bindings_locked(repo_root, mutate)


def verify_complete_run_binding(
    role: str, seed: int, artifact_path: Path, *, repo_root: Path = REPO_ROOT
) -> dict[str, Any]:
    """Require one and only one COMPLETE binding for a comparison artifact."""
    repo_root = Path(repo_root).resolve()
    artifact_path = Path(artifact_path).resolve()
    records = _load_run_bindings(repo_root)["records"]
    matches = _matching_run_bindings(records, role, seed)
    if len(matches) != 1:
        raise ValueError(f"expected one unique COMPLETE binding for {role}:{seed}, found {len(matches)}")
    record = matches[0]
    if record["status"] != "COMPLETE":
        raise ValueError(f"{role}:{seed} binding status is {record['status']}, expected COMPLETE")
    expected_path = _relative(artifact_path, repo_root)
    if record["metrics_artifact_path"] != expected_path or record["metrics_artifact_sha256"] != _sha256(artifact_path):
        raise ValueError(f"{role}:{seed} comparison artifact is not its unique COMPLETE binding")
    artifact = audit_configs.load_json(artifact_path)
    run_dir = audit_configs.resolve_repository_file(artifact["checkpoint_path"], repo_root).parent
    if record["run_dir"] != _relative(run_dir, repo_root):
        raise ValueError(f"{role}:{seed} COMPLETE binding run directory disagrees with the artifact")
    return record


def _load_registered_experiment(
    experiment_id: str, repo_root: Path, *, allow_completed: bool = False
) -> tuple[dict[str, str], Path, dict[str, Any]]:
    if experiment_id not in CONFIG_RELATIVE_BY_ID:
        raise ValueError(f"experiment_id must be one of {sorted(CONFIG_RELATIVE_BY_ID)}, got {experiment_id!r}")
    registry_path = repo_root / REGISTRY_RELATIVE_PATH
    rows = audit_configs.load_registry(registry_path)
    registry_issues = audit_configs.audit_registry(rows, repo_root)
    if registry_issues:
        raise ValueError("registry audit failed: " + "; ".join(registry_issues))
    row = next(item for item in rows if item["exp_id"] == experiment_id)
    if experiment_id == "M01":
        allowed_statuses = {"planned", "development_complete"} if allow_completed else {"planned"}
        if (row.get("status") not in allowed_statuses
                or row.get("config_path") != CONFIG_RELATIVE_BY_ID[experiment_id].as_posix()):
            raise ValueError("M01 is unavailable until the existing dense-selection gate generates its config")
    elif row.get("status") != "planned" and not (allow_completed and row.get("status") == "development_complete"):
        raise FileExistsError(f"{experiment_id} is already registered as {row.get('status')}; refusing a duplicate run")

    config_path = repo_root / CONFIG_RELATIVE_BY_ID[experiment_id]
    if not config_path.is_file():
        raise FileNotFoundError(f"registered configuration does not exist: {config_path}")
    if row.get("config_sha256") != _sha256(config_path):
        raise ValueError(f"{experiment_id} configuration SHA-256 disagrees with the registry")
    Config(config_path)
    config = audit_configs.load_yaml(config_path)
    contract_issues = audit_configs.audit_common_contract(config, experiment_id, repo_root)
    if contract_issues:
        raise ValueError("development information contract failed: " + "; ".join(contract_issues))
    return row, config_path, config


def _derived_paths(role: str, seed: int, repo_root: Path) -> tuple[Path, Path]:
    if role not in DERIVED_CONFIG_STEMS or seed not in {200, 300}:
        raise ValueError("derived development configs are limited to B01, SELECTED_DENSE, and M01 at seeds 200/300")
    stem = DERIVED_CONFIG_STEMS[role]
    config_path = repo_root / DERIVED_CONFIG_RELATIVE_ROOT / f"{stem}_s{seed}.yml"
    return config_path, config_path.with_suffix(".provenance.json")


def _derived_spec(role: str, seed: int, repo_root: Path) -> tuple[dict[str, Any], dict[str, Any], Path, Path]:
    rows = audit_configs.load_registry(repo_root / REGISTRY_RELATIVE_PATH)
    issues = audit_configs.audit_registry(rows, repo_root)
    if issues:
        raise ValueError("registry audit failed: " + "; ".join(issues))
    by_id = {row["exp_id"]: row for row in rows}
    if role == "B01":
        base_relative = by_id["B01"]["config_path"]
        selection_relative = "not_applicable"
        selection_sha256 = "not_applicable"
        selected_id = "not_applicable"
    else:
        m01 = by_id["M01"]
        if m01.get("status") not in {"planned", "development_complete"}:
            raise ValueError(f"{role} seed {seed} is unavailable until the existing dense-selection gate completes")
        selection_relative = m01["selection_report_path"]
        selection_path = audit_configs.resolve_repository_file(selection_relative, repo_root)
        if not selection_path.is_file() or _sha256(selection_path) != m01["selection_report_sha256"]:
            raise ValueError("registered dense-selection report hash binding failed")
        selection_sha256 = _sha256(selection_path)
        report = audit_configs.load_json(selection_path)
        report_issues = audit_configs.audit_selection_report(report, repo_root)
        if report_issues:
            raise ValueError("dense-selection report audit failed: " + "; ".join(report_issues))
        selected_id = str(report["selected_experiment_id"])
        base_relative = m01["source_config_path"] if role == "SELECTED_DENSE" else m01["config_path"]
    base_path = audit_configs.resolve_repository_file(base_relative, repo_root)
    if not base_path.is_file():
        raise FileNotFoundError(f"base configuration does not exist: {base_path}")
    base = audit_configs.load_yaml(base_path)
    derived = deepcopy(base)
    stem = DERIVED_CONFIG_STEMS[role]
    derived.update({
        "seed": seed,
        "experiment_name": f"modern_transformer_moe_{stem}_s{seed}",
        "run_dir": f"results/30_modern_transformer_moe/development_seeds/{stem}/s{seed}",
    })
    Config(deepcopy(derived))
    config_path, provenance_path = _derived_paths(role, seed, repo_root)
    provenance = {
        "schema_version": 1,
        "role": role,
        "seed": seed,
        "derived_config_path": _relative(config_path, repo_root),
        "derived_config_sha256": "computed_when_materialized",
        "base_config_path": _relative(base_path, repo_root),
        "base_config_sha256": _sha256(base_path),
        "selection_report_path": selection_relative,
        "selection_report_sha256": selection_sha256,
        "selected_dense_experiment_id": selected_id,
        "allowed_config_differences": ["experiment_name", "run_dir", "seed"],
    }
    return derived, provenance, config_path, provenance_path


def _validate_derived_config(role: str, seed: int, repo_root: Path) -> tuple[Path, dict[str, Any], Path]:
    expected, expected_provenance, config_path, provenance_path = _derived_spec(role, seed, repo_root)
    if not config_path.is_file() or not provenance_path.is_file():
        raise FileNotFoundError(f"derived config and provenance must both exist: {config_path}, {provenance_path}")
    actual = audit_configs.load_yaml(config_path)
    if actual != expected:
        raise ValueError(f"derived configuration drifted from its bound base: {config_path}")
    provenance = audit_configs.load_json(provenance_path)
    if set(provenance) != DERIVED_PROVENANCE_KEYS:
        raise ValueError(f"derived provenance schema mismatch: {provenance_path}")
    expected_provenance["derived_config_sha256"] = _sha256(config_path)
    if provenance != expected_provenance:
        raise ValueError(f"derived provenance binding mismatch: {provenance_path}")
    return config_path, actual, provenance_path


def materialize_derived_config(role: str, seed: int, *, repo_root: Path = REPO_ROOT) -> tuple[Path, Path]:
    """Create one immutable seed-200/300 config and its provenance sidecar without training."""
    repo_root = Path(repo_root).resolve()
    expected, provenance, config_path, provenance_path = _derived_spec(role, seed, repo_root)
    if config_path.exists() or provenance_path.exists():
        _validate_derived_config(role, seed, repo_root)
        return config_path, provenance_path
    config_path.parent.mkdir(parents=True, exist_ok=True)
    lock_path = config_path.with_suffix(".lock")
    try:
        descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as error:
        raise RuntimeError(f"derived configuration generation is already locked: {lock_path}") from error
    os.close(descriptor)
    temporary_config = config_path.with_name(f".{config_path.name}.{os.getpid()}.tmp")
    temporary_provenance = provenance_path.with_name(f".{provenance_path.name}.{os.getpid()}.tmp")
    config_installed = False
    try:
        if config_path.exists() or provenance_path.exists():
            raise FileExistsError("refusing to overwrite a partial or existing derived configuration binding")
        yaml = YAML()
        with temporary_config.open("x", encoding="utf-8") as stream:
            yaml.dump(expected, stream)
        provenance["derived_config_sha256"] = _sha256(temporary_config)
        with temporary_provenance.open("x", encoding="utf-8") as stream:
            json.dump(provenance, stream, indent=2, sort_keys=True)
            stream.write("\n")
        os.replace(temporary_config, config_path)
        config_installed = True
        os.replace(temporary_provenance, provenance_path)
        _validate_derived_config(role, seed, repo_root)
    except BaseException:
        if config_installed:
            config_path.unlink(missing_ok=True)
        provenance_path.unlink(missing_ok=True)
        raise
    finally:
        temporary_config.unlink(missing_ok=True)
        temporary_provenance.unlink(missing_ok=True)
        lock_path.unlink(missing_ok=True)
    return config_path, provenance_path


def _resolve_experiment(
    experiment_id: str,
    seed: int,
    repo_root: Path,
    *,
    require_materialized: bool,
    allow_completed: bool = False,
) -> tuple[dict[str, str] | None, Path, dict[str, Any], Path | None]:
    if seed not in DEVELOPMENT_SEEDS:
        raise ValueError(f"development seed must be one of {sorted(DEVELOPMENT_SEEDS)}")
    if seed == 100:
        if experiment_id == "SELECTED_DENSE":
            raise ValueError("seed 100 selected dense run is represented by its D01, D02, or D03 identifier")
        row, config_path, config = _load_registered_experiment(
            experiment_id, repo_root, allow_completed=allow_completed
        )
        return row, config_path, config, None
    if experiment_id not in DERIVED_CONFIG_STEMS:
        raise ValueError("seeds 200/300 are limited to B01, SELECTED_DENSE, and M01")
    if require_materialized:
        config_path, config, provenance_path = _validate_derived_config(experiment_id, seed, repo_root)
    else:
        expected, _, config_path, provenance_path = _derived_spec(experiment_id, seed, repo_root)
        if config_path.exists() or provenance_path.exists():
            config_path, config, provenance_path = _validate_derived_config(experiment_id, seed, repo_root)
        else:
            config = expected
    return None, config_path, config, provenance_path


def plan_development(
    experiment_id: str,
    *,
    seed: int = 100,
    gpu: int = 0,
    repo_root: Path = REPO_ROOT,
    allow_completed: bool = False,
) -> dict[str, Any]:
    """Return a read-only command and budget plan; never spawn a child process."""
    repo_root = Path(repo_root).resolve()
    row, config_path, config, provenance_path = _resolve_experiment(
        experiment_id, seed, repo_root, require_materialized=False, allow_completed=allow_completed
    )
    command = [
        sys.executable,
        "-m",
        "neuralhydrology.nh_run",
        "train",
        "--config-file",
        str(config_path),
        "--gpu",
        str(gpu),
    ]
    return {
        "mode": "DRY_RUN",
        "experiment_id": experiment_id,
        "seed": seed,
        "config_path": _relative(config_path, repo_root),
        "config_sha256": _sha256(config_path) if config_path.is_file() else "not_materialized",
        "derived_config_status": (
            "not_applicable_seed100" if seed == 100 else "materialized" if config_path.is_file() else "would_create"
        ),
        "provenance_path": _relative(provenance_path, repo_root) if provenance_path is not None else "not_applicable",
        "run_root": str(config["run_dir"]),
        "command": command,
        "budget": {
            "basins": int(config["number_of_basins"]),
            "epochs": int(config["epochs"]),
            "sequence_length_days": int(config["seq_length"]),
            "batch_size": int(config["batch_size"]),
            "validation_basins_each_epoch": int(config["validate_n_random_basins"]),
            "device": f"cuda:{gpu}",
            "runtime_class": "hours_long_gpu_run_not_measured",
        },
        "execution_requirements": ["--execute", "--operator-approved-heavy-compute"],
    }


def _capture_source_snapshot(
    config_path: Path, repo_root: Path, *, additional_paths: tuple[Path, ...] = ()
) -> dict[str, Any]:
    paths = ([repo_root / item for item in CRITICAL_RELATIVE_FILES]
             + [config_path, repo_root / REGISTRY_RELATIVE_PATH, *additional_paths])
    missing = [path for path in paths if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"critical development files are missing: {missing}")
    revision = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=repo_root, check=True, capture_output=True, text=True
    ).stdout.strip()
    status = subprocess.run(
        ["git", "status", "--porcelain"], cwd=repo_root, check=True, capture_output=True, text=True
    ).stdout.splitlines()
    snapshot = {
        "captured_at_utc": datetime.now(timezone.utc).isoformat(),
        "git_revision": revision,
        "git_dirty": bool(status),
        "git_status_sha256": hashlib.sha256("\n".join(status).encode("utf-8")).hexdigest(),
        "git_changed_path_count": len(status),
        "files": {_relative(path, repo_root): _sha256(path) for path in paths},
    }
    config = audit_configs.load_yaml(config_path)
    if config.get("dataset") == "camels_us_track0_bundle":
        snapshot["candidate_safe_data"] = capture_safe_data_snapshot(repo_root, config)
    return snapshot


def _assert_source_unchanged(snapshot: dict[str, Any], repo_root: Path, *, ignore_registry: bool = False) -> None:
    changed = []
    for relative_path, expected_hash in snapshot["files"].items():
        if ignore_registry and Path(relative_path) == REGISTRY_RELATIVE_PATH:
            continue
        path = repo_root / relative_path
        if not path.is_file() or _sha256(path) != expected_hash:
            changed.append(relative_path)
    if changed:
        raise RuntimeError(f"critical source/config changed during training: {changed}")
    safe_data = snapshot.get("candidate_safe_data")
    if safe_data is not None:
        assert_safe_data_unchanged(
            safe_data,
            repo_root,
            {"data_dir": safe_data["forcing_dir"], "track0_supervision_dir": safe_data["supervision_dir"]},
        )


def _direct_subdirectories(path: Path) -> set[Path]:
    if not path.is_dir():
        return set()
    return {candidate.resolve() for candidate in path.iterdir() if candidate.is_dir()}


def _write_registry_rows(rows: list[dict[str, str]], path: Path) -> Path:
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", newline="", dir=path.parent, prefix=".development_registry_", suffix=".tmp",
        delete=False
    ) as stream:
        writer = csv.DictWriter(stream, fieldnames=audit_configs.REGISTRY_COLUMNS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
        return Path(stream.name)


def _update_registry(experiment_id: str, artifact_path: Path, repo_root: Path) -> None:
    registry_path = repo_root / REGISTRY_RELATIVE_PATH
    lock_path = repo_root / REGISTRY_LOCK_RELATIVE_PATH
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as error:
        raise RuntimeError(f"development registry lock already exists: {lock_path}") from error
    os.close(descriptor)
    original = registry_path.read_bytes()
    temporary: Path | None = None
    rollback: Path | None = None
    try:
        rows = audit_configs.load_registry(registry_path)
        row = next(item for item in rows if item["exp_id"] == experiment_id)
        if row.get("status") not in {"planned", "development_complete"}:
            raise FileExistsError(f"{experiment_id} registry row cannot be finalized from {row.get('status')}")
        artifact = audit_configs.load_json(artifact_path)
        issues, _ = audit_configs.audit_metrics_artifact(
            artifact, experiment_id, repo_root, artifact_path=artifact_path
        )
        if issues:
            raise ValueError("metrics artifact audit failed: " + "; ".join(issues))
        if row.get("status") == "development_complete":
            expected = {
                "best_checkpoint": artifact["checkpoint_path"],
                "checkpoint_sha256": artifact["checkpoint_sha256"],
                "metrics_path": _relative(artifact_path, repo_root),
                "metrics_sha256": _sha256(artifact_path),
            }
            mismatches = {
                field: (row.get(field), value) for field, value in expected.items() if row.get(field) != value
            }
            if mismatches:
                raise ValueError(f"completed {experiment_id} registry binding disagrees with artifact: {mismatches}")
            completed_issues = audit_configs.audit_registry(rows, repo_root)
            if completed_issues:
                raise ValueError("completed registry state failed audit: " + "; ".join(completed_issues))
            return
        row.update({
            "status": "development_complete",
            "best_checkpoint": artifact["checkpoint_path"],
            "checkpoint_sha256": artifact["checkpoint_sha256"],
            "metrics_path": _relative(artifact_path, repo_root),
            "metrics_sha256": _sha256(artifact_path),
        })
        row_issues = audit_configs.audit_registry(rows, repo_root)
        if row_issues:
            raise ValueError("proposed registry state failed audit: " + "; ".join(row_issues))
        temporary = _write_registry_rows(rows, registry_path)
        os.replace(temporary, registry_path)
        temporary = None
        post_issues = audit_configs.audit_registry(audit_configs.load_registry(registry_path), repo_root)
        if post_issues:
            raise RuntimeError("post-update registry audit failed: " + "; ".join(post_issues))
    except BaseException:
        if registry_path.read_bytes() != original:
            with tempfile.NamedTemporaryFile(
                mode="wb", dir=registry_path.parent, prefix=".development_rollback_", suffix=".tmp", delete=False
            ) as stream:
                stream.write(original)
                rollback = Path(stream.name)
            os.replace(rollback, registry_path)
            rollback = None
        raise
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
        if rollback is not None:
            rollback.unlink(missing_ok=True)
        lock_path.unlink(missing_ok=True)


def _find_bound_invocation(run_dir: Path, repo_root: Path) -> tuple[Path, dict[str, Any]]:
    invocation_root = repo_root / INVOCATIONS_RELATIVE_ROOT
    matches: list[tuple[Path, dict[str, Any]]] = []
    if invocation_root.is_dir():
        for path in invocation_root.glob("*/run_manifest.json"):
            try:
                value = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            bound_run_dir = value.get("run_dir")
            if bound_run_dir is None:
                created = value.get("new_run_directories")
                if isinstance(created, list) and len(created) == 1:
                    bound_run_dir = created[0]
            if bound_run_dir == _relative(run_dir, repo_root):
                matches.append((path, value))
    if len(matches) != 1:
        raise ValueError(f"expected exactly one source-bound invocation manifest for {run_dir}, found {len(matches)}")
    return matches[0]


def finalize_existing_run(
    experiment_id: str,
    run_dir: Path,
    *,
    seed: int = 100,
    repo_root: Path = REPO_ROOT,
) -> dict[str, Any]:
    """Recover post-processing for one completed, source-bound run without spawning training."""
    repo_root = Path(repo_root).resolve()
    _, config_path, config, _ = _resolve_experiment(
        experiment_id,
        seed,
        repo_root,
        require_materialized=True,
        allow_completed=True,
    )
    run_dir = Path(run_dir)
    if not run_dir.is_absolute():
        run_dir = repo_root / run_dir
    run_dir = run_dir.resolve()
    try:
        run_dir.relative_to(repo_root)
    except ValueError as error:
        raise ValueError(f"run_dir must be inside the repository: {run_dir}") from error
    expected_parent = (repo_root / str(config["run_dir"])).resolve()
    if run_dir.parent != expected_parent:
        raise ValueError(f"run_dir must be one direct run below {expected_parent}")
    records = _load_run_bindings(repo_root)["records"]
    matches = _matching_run_bindings(records, experiment_id, seed)
    if len(matches) != 1:
        raise ValueError(
            f"expected exactly one reserved development run for {experiment_id}:{seed}, found {len(matches)}"
        )
    binding = matches[0]
    if binding["run_dir"] not in {"not_bound", _relative(run_dir, repo_root)}:
        raise ValueError("reserved development run identifies a different run directory")
    manifest_path = repo_root / INVOCATIONS_RELATIVE_ROOT / binding["run_id"] / "run_manifest.json"
    if not manifest_path.is_file():
        raise FileNotFoundError(f"reserved development invocation manifest does not exist: {manifest_path}")
    manifest = audit_configs.load_json(manifest_path)
    if manifest.get("experiment_id") != experiment_id:
        raise ValueError("invocation manifest experiment identifier disagrees with finalize request")
    if int(manifest.get("seed", 100)) != seed:
        raise ValueError("invocation manifest seed disagrees with finalize request")
    if manifest.get("run_id") != binding["run_id"]:
        raise ValueError("invocation manifest run_id disagrees with the unique reservation")
    if binding["run_dir"] == "not_bound":
        claimed = []
        if isinstance(manifest.get("run_dir"), str):
            claimed.append(manifest["run_dir"])
        created = manifest.get("new_run_directories", [])
        if not isinstance(created, list) or any(not isinstance(path, str) for path in created):
            raise ValueError("invocation manifest has invalid run-directory evidence")
        claimed.extend(created)
        claimed_directories = {(repo_root / relative).resolve() for relative in claimed}
        if run_dir not in claimed_directories:
            raise ValueError("unbound invocation manifest does not identify the requested run directory")
    if binding["status"] == "FAILED":
        if run_dir not in _attempt_run_directories(binding, repo_root):
            raise ValueError("failed invocation manifest does not identify the requested run directory")
        if run_dir not in _complete_epoch030_run_directories(binding, repo_root):
            raise ValueError("failed invocation does not contain an unchanged complete epoch-30 product set")
    snapshot = manifest.get("source_snapshot")
    if not isinstance(snapshot, dict):
        raise ValueError("invocation manifest has no pre-training source snapshot")
    _assert_source_unchanged(snapshot, repo_root, ignore_registry=True)
    if snapshot.get("files", {}).get(_relative(config_path, repo_root)) != _sha256(config_path):
        raise ValueError("current source configuration differs from the pre-training snapshot")
    build_epoch030_metrics_artifact.preflight(
        experiment_id, run_dir, repo_root, source_config_path=config_path
    )
    _transition_run_binding(
        experiment_id,
        seed,
        binding["run_id"],
        "POSTPROCESSING",
        repo_root,
        run_dir=run_dir,
    )
    artifact_path = run_dir / "epoch030_metrics.json"
    if artifact_path.exists():
        artifact = audit_configs.load_json(artifact_path)
        issues, _ = audit_configs.audit_metrics_artifact(
            artifact,
            experiment_id,
            repo_root,
            artifact_path=artifact_path,
            expected_source_config_path=_relative(config_path, repo_root),
        )
        if issues:
            raise ValueError("existing metrics artifact failed audit: " + "; ".join(issues))
    else:
        artifact_path = build_epoch030_metrics_artifact.build(
            experiment_id, run_dir, repo_root, source_config_path=config_path
        )
    if seed == 100:
        _update_registry(experiment_id, artifact_path, repo_root)
    recovered = {
        "status": "COMPLETE",
        "experiment_id": experiment_id,
        "seed": seed,
        "run_dir": _relative(run_dir, repo_root),
        "metrics_artifact": {"path": _relative(artifact_path, repo_root), "sha256": _sha256(artifact_path)},
        "recovered_without_training": True,
        "source_invocation_manifest": _relative(manifest_path, repo_root),
    }
    manifest.update(recovered)
    manifest["finalized_at_utc"] = datetime.now(timezone.utc).isoformat()
    _atomic_json(manifest_path, manifest)
    _transition_run_binding(
        experiment_id,
        seed,
        binding["run_id"],
        "COMPLETE",
        repo_root,
        run_dir=run_dir,
        artifact_path=artifact_path,
    )
    return recovered


def execute_development(
    experiment_id: str,
    run_id: str,
    *,
    operator_approved_heavy_compute: bool,
    seed: int = 100,
    gpu: int = 0,
    repo_root: Path = REPO_ROOT,
    retry_failed_run_id: str | None = None,
) -> dict[str, Any]:
    """Execute exactly one approved run and return its final manifest."""
    if not operator_approved_heavy_compute:
        raise PermissionError("real training requires --operator-approved-heavy-compute")
    if re.fullmatch(r"[A-Za-z0-9_.-]+", run_id) is None:
        raise ValueError("run_id may contain only letters, digits, dot, underscore, and hyphen")
    repo_root = Path(repo_root).resolve()
    invocation_dir = repo_root / INVOCATIONS_RELATIVE_ROOT / run_id
    if invocation_dir.exists():
        raise FileExistsError(f"refusing to overwrite development invocation: {invocation_dir}")
    if seed in {200, 300}:
        materialize_derived_config(experiment_id, seed, repo_root=repo_root)
    plan = plan_development(
        experiment_id, seed=seed, gpu=gpu, repo_root=repo_root,
        allow_completed=retry_failed_run_id is not None
    )
    config_path = repo_root / plan["config_path"]
    provenance_path: Path | None = None
    additional_paths: tuple[Path, ...] = ()
    if plan["provenance_path"] != "not_applicable":
        provenance_path = repo_root / plan["provenance_path"]
        provenance = audit_configs.load_json(provenance_path)
        additional_paths = (provenance_path, repo_root / provenance["base_config_path"])
        if provenance["selection_report_path"] != "not_applicable":
            additional_paths += (repo_root / provenance["selection_report_path"],)
    run_root = (repo_root / plan["run_root"]).resolve()
    before = _direct_subdirectories(run_root)
    if retry_failed_run_id is not None:
        _retry_failed_run_binding(
            experiment_id, seed, retry_failed_run_id, run_id, config_path, provenance_path, repo_root
        )
    else:
        _reserve_run_binding(experiment_id, seed, run_id, config_path, provenance_path, repo_root)
    manifest_path = invocation_dir / "run_manifest.json"
    data_access_log_path = invocation_dir / "data_access.jsonl"
    manifest: dict[str, Any] = {
        "schema_version": 1,
        "run_id": run_id,
        "experiment_id": experiment_id,
        "seed": seed,
        "status": "RUNNING",
        "operator_approved_heavy_compute": True,
        "controlled_retry_from_run_id": retry_failed_run_id or "not_applicable",
        "command": plan["command"],
        "budget": plan["budget"],
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "runner_process": {
            "host": socket.gethostname(),
            "process_id": os.getpid(),
            "process_start_time_epoch_seconds": _process_start_time(os.getpid()),
            "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
        },
    }
    failure_stage = "source_snapshot"
    failed_run_dir: Path | None = None
    started: float | None = None
    try:
        snapshot = _capture_source_snapshot(config_path, repo_root, additional_paths=additional_paths)
        manifest["source_snapshot"] = snapshot
        manifest["data_contract"] = snapshot.get("candidate_safe_data", {"status": "NOT_APPLICABLE"})
        failure_stage = "manifest_initialization"
        invocation_dir.mkdir(parents=True, exist_ok=False)
        _atomic_json(manifest_path, manifest, create=True)
        failure_stage = "training_subprocess"
        started = time.perf_counter()
        environment = os.environ.copy()
        environment["NEURALHYDROLOGY_DATA_ACCESS_LOG"] = str(data_access_log_path)
        return_code = _run_training_process(
            plan["command"],
            repo_root=repo_root,
            environment=environment,
            manifest=manifest,
            manifest_path=manifest_path,
            invocation_dir=invocation_dir,
        )
        manifest["return_code"] = return_code
        manifest["wall_seconds"] = time.perf_counter() - started
        after = _direct_subdirectories(run_root)
        created = sorted(after - before)
        manifest["new_run_directories"] = [_relative(path, repo_root) for path in created]
        if len(created) == 1:
            failed_run_dir = created[0]
            manifest["run_dir"] = _relative(failed_run_dir, repo_root)
        if return_code != 0:
            raise RuntimeError(f"training exited with code {return_code}")
        failure_stage = "run_directory_discovery"
        if len(created) != 1:
            raise RuntimeError(f"expected exactly one new run directory below {run_root}, found {created}")
        run_dir = created[0]
        failure_stage = "source_integrity_verification"
        _assert_source_unchanged(snapshot, repo_root, ignore_registry=seed != 100)
        if snapshot.get("candidate_safe_data") is not None:
            manifest["data_access"] = audit_access_log(
                data_access_log_path,
                snapshot["candidate_safe_data"]["forcing_dir"],
                snapshot["candidate_safe_data"]["supervision_dir"],
            )
        failure_stage = "epoch030_product_verification"
        required = {
            "run_config": run_dir / "config.yml",
            "checkpoint": run_dir / "model_epoch030.pt",
            "validation_metrics": run_dir / "validation/model_epoch030/validation_metrics.csv",
            "validation_results": run_dir / "validation/model_epoch030/validation_results.p",
        }
        missing = [path for path in required.values() if not path.is_file()]
        if missing:
            raise FileNotFoundError(f"completed run is missing epoch-30 products: {missing}")
        manifest["run_dir"] = _relative(run_dir, repo_root)
        manifest["run_products"] = {
            name: {"path": _relative(path, repo_root), "sha256": _sha256(path)} for name, path in required.items()
        }
        failure_stage = "binding_postprocessing"
        _transition_run_binding(
            experiment_id,
            seed,
            run_id,
            "POSTPROCESSING",
            repo_root,
            run_dir=run_dir,
        )
        manifest["status"] = "POSTPROCESSING"
        _atomic_json(manifest_path, manifest)
        failure_stage = "metrics_artifact_build"
        artifact_path = build_epoch030_metrics_artifact.build(
            experiment_id, run_dir, repo_root, source_config_path=config_path
        )
        if seed == 100:
            failure_stage = "seed100_registry_update"
            _update_registry(experiment_id, artifact_path, repo_root)
        manifest["metrics_artifact"] = {
            "path": _relative(artifact_path, repo_root),
            "sha256": _sha256(artifact_path),
        }
        manifest["status"] = "COMPLETE"
        manifest["completed_at_utc"] = datetime.now(timezone.utc).isoformat()
        _atomic_json(manifest_path, manifest)
        failure_stage = "binding_completion"
        _transition_run_binding(
            experiment_id,
            seed,
            run_id,
            "COMPLETE",
            repo_root,
            run_dir=run_dir,
            artifact_path=artifact_path,
        )
    except BaseException as error:
        if "new_run_directories" not in manifest:
            created = sorted(_direct_subdirectories(run_root) - before)
            manifest["new_run_directories"] = [_relative(path, repo_root) for path in created]
            if len(created) == 1:
                failed_run_dir = created[0]
                manifest["run_dir"] = _relative(failed_run_dir, repo_root)
        else:
            created = [(repo_root / relative).resolve() for relative in manifest["new_run_directories"]]
        manifest["epoch030_product_inventory"] = _epoch030_product_inventory(created, repo_root)
        manifest["status"] = "FAILED"
        manifest["failure_stage"] = failure_stage
        manifest["error_type"] = type(error).__name__
        manifest["error"] = str(error)
        manifest["failed_at_utc"] = datetime.now(timezone.utc).isoformat()
        invocation_dir.mkdir(parents=True, exist_ok=True)
        _atomic_json(manifest_path, manifest)
        _mark_run_binding_failed(
            experiment_id,
            seed,
            run_id,
            repo_root,
            manifest_path=manifest_path,
            failure_stage=failure_stage,
            failure_reason=str(error),
            run_dir=failed_run_dir,
        )
        raise
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("experiment_id", choices=sorted(CLI_EXPERIMENT_IDS))
    parser.add_argument("--seed", type=int, choices=sorted(DEVELOPMENT_SEEDS), default=100)
    parser.add_argument("--run-id")
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--execute", action="store_true", help="Request a real training process instead of dry-run.")
    parser.add_argument("--operator-approved-heavy-compute", action="store_true")
    parser.add_argument("--retry-failed-run-id",
                        help="Exact FAILED run ID to archive before reserving the distinct --run-id replacement.")
    parser.add_argument("--finalize-run-dir", type=Path,
                        help="Finalize an existing source-bound epoch-30 run without launching training.")
    parser.add_argument("--prepare-derived-config", action="store_true",
                        help="Materialize and audit a seed-200/300 config without training.")
    args = parser.parse_args()
    if args.prepare_derived_config:
        if (args.execute or args.operator_approved_heavy_compute or args.finalize_run_dir is not None
                or args.retry_failed_run_id is not None):
            raise ValueError("--prepare-derived-config cannot be combined with execution/finalization flags")
        config_path, provenance_path = materialize_derived_config(args.experiment_id, args.seed)
        print(json.dumps({"config_path": str(config_path), "provenance_path": str(provenance_path)}, indent=2))
        return 0
    if args.finalize_run_dir is not None:
        if args.execute or args.operator_approved_heavy_compute or args.retry_failed_run_id is not None:
            raise ValueError("--finalize-run-dir cannot be combined with execution flags")
        print(json.dumps(finalize_existing_run(args.experiment_id, args.finalize_run_dir, seed=args.seed), indent=2))
        return 0
    if not args.execute:
        if args.operator_approved_heavy_compute or args.retry_failed_run_id is not None:
            raise ValueError(
                "heavy-compute approval and --retry-failed-run-id are valid only together with --execute"
            )
        print(json.dumps(plan_development(args.experiment_id, seed=args.seed, gpu=args.gpu), indent=2))
        return 0
    if args.retry_failed_run_id is not None and args.run_id is None:
        raise ValueError("--retry-failed-run-id requires an explicit new --run-id")
    run_id = args.run_id or datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    manifest = execute_development(
        args.experiment_id,
        run_id,
        operator_approved_heavy_compute=args.operator_approved_heavy_compute,
        seed=args.seed,
        gpu=args.gpu,
        retry_failed_run_id=args.retry_failed_run_id,
    )
    print(json.dumps(manifest, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
