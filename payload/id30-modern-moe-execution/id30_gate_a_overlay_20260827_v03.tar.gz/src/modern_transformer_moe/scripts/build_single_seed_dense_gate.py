"""Build Gate A: the selected dense Transformer must match or exceed the corrected LSTM."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any

from src.modern_transformer_moe.scripts import audit_configs, compare_development


EXPERIMENT_IDS = ("B01", "D01", "D02", "D03")
DEFAULT_SELECTION_REPORT = Path("results/30_modern_transformer_moe/dense_selection_report.json")
DEFAULT_OUTPUT = Path("results/30_modern_transformer_moe/single_seed_dense_gate.json")


def _resolve_inside_repository(path: Path, repo_root: Path) -> Path:
    path = Path(path)
    if not path.is_absolute():
        path = repo_root / path
    path = path.resolve()
    try:
        path.relative_to(repo_root)
    except ValueError as error:
        raise ValueError(f"path must remain inside the repository: {path}") from error
    return path


def _write_new_or_identical(path: Path, report: dict[str, Any]) -> None:
    payload = (json.dumps(report, indent=2, sort_keys=True) + "\n").encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    lock_path = path.with_name(f".{path.name}.lock")
    temporary_path = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as error:
        raise RuntimeError(f"single-seed gate generation is already locked: {lock_path}") from error
    os.close(descriptor)
    try:
        if path.exists():
            if path.read_bytes() == payload:
                return
            raise FileExistsError(f"refusing to overwrite a different single-seed gate report: {path}")
        temporary_path.write_bytes(payload)
        os.replace(temporary_path, path)
    finally:
        temporary_path.unlink(missing_ok=True)
        lock_path.unlink(missing_ok=True)


def build(
    selection_report_path: Path = DEFAULT_SELECTION_REPORT,
    output_path: Path = DEFAULT_OUTPUT,
    *,
    repo_root: Path = audit_configs.REPO_ROOT,
    require_complete_binding: bool = True,
) -> tuple[Path, dict[str, Any]]:
    """Recompute B01 and D01-D03 validation metrics and persist the preregistered Gate A decision."""
    repo_root = Path(repo_root).resolve()
    selection_report_path = _resolve_inside_repository(selection_report_path, repo_root)
    output_path = _resolve_inside_repository(output_path, repo_root)
    selection = audit_configs.load_json(selection_report_path)
    selection_issues = audit_configs.audit_selection_report(selection, repo_root)
    if selection_issues:
        raise ValueError("dense selection report failed audit: " + "; ".join(selection_issues))

    rows = audit_configs.load_registry(repo_root / "src/modern_transformer_moe/registry/experiments.csv")
    specifications = []
    for experiment_id in EXPERIMENT_IDS:
        matches = [row for row in rows if row.get("exp_id") == experiment_id]
        if len(matches) != 1:
            raise ValueError(f"expected exactly one registry row for {experiment_id}, found {len(matches)}")
        row = matches[0]
        if row.get("status") != "development_complete":
            raise ValueError(f"{experiment_id} must have status development_complete before Gate A")
        if row.get("seed") != "100":
            raise ValueError(f"{experiment_id} must be seed 100 before Gate A")
        artifact_path = audit_configs.resolve_repository_file(row.get("metrics_path"), repo_root)
        if row.get("metrics_sha256") != audit_configs.sha256_file(artifact_path):
            raise ValueError(f"{experiment_id} metrics SHA-256 mismatch against the registry")
        specifications.append(f"{experiment_id}:100={artifact_path.relative_to(repo_root).as_posix()}")

    report = compare_development.compare(
        specifications,
        repo_root=repo_root,
        require_complete_binding=require_complete_binding,
    )
    gate = report["single_seed_dense_gate"]
    if gate.get("selected_dense") != selection["selected_experiment_id"]:
        raise ValueError("Gate A selected dense model disagrees with the audited dense selection report")
    _write_new_or_identical(output_path, report)
    return output_path, report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--selection-report", type=Path, default=DEFAULT_SELECTION_REPORT)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    output_path, report = build(args.selection_report, args.output)
    gate = report["single_seed_dense_gate"]
    print(json.dumps({"report": str(output_path), **gate}, indent=2, sort_keys=True))
    return 0 if gate["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
