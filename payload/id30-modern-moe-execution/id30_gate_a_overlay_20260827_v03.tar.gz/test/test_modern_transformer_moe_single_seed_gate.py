import json
from copy import deepcopy
from pathlib import Path

import torch

from src.modern_transformer_moe.scripts import audit_configs
from src.modern_transformer_moe.scripts import build_epoch030_metrics_artifact as metrics_builder
from src.modern_transformer_moe.scripts import build_single_seed_dense_gate as gate_builder
from test.test_modern_transformer_moe_configs import (
    _complete_dense_candidates,
    _copy_task4_repository,
    _write_registry,
    _write_validation_products,
    _write_yaml,
)


def _prepare(tmp_path: Path, baseline_nse: float) -> tuple[Path, Path]:
    repository = _copy_task4_repository(tmp_path)
    selection_path, _ = _complete_dense_candidates(repository)
    registry_path = repository / "src/modern_transformer_moe/registry/experiments.csv"
    rows = audit_configs.load_registry(registry_path)
    baseline = next(row for row in rows if row["exp_id"] == "B01")
    source_path = repository / baseline["config_path"]
    source = audit_configs.load_yaml(source_path)
    run_relative = "results/30_modern_transformer_moe/B01/synthetic_epoch30"
    run_path = repository / run_relative
    run_path.mkdir(parents=True)
    run_config = deepcopy(source)
    run_config.update({
        "run_dir": run_relative,
        "train_dir": f"{run_relative}/train_data",
        "img_log_dir": f"{run_relative}/img_log",
        "commit_hash": "test-commit",
        "package_version": "test-version",
    })
    _write_yaml(run_path / "config.yml", run_config)
    torch.save({"synthetic_weight": torch.tensor([1.0])}, run_path / "model_epoch030.pt")
    basins = [line.strip() for line in (repository / audit_configs.BASIN_FILE).read_text().splitlines() if line.strip()]
    _write_validation_products(run_path, basins, baseline_nse)
    artifact_path = metrics_builder.build("B01", run_path, repository)
    artifact = audit_configs.load_json(artifact_path)
    baseline.update({
        "status": "development_complete",
        "best_checkpoint": artifact["checkpoint_path"],
        "checkpoint_sha256": artifact["checkpoint_sha256"],
        "metrics_path": artifact_path.relative_to(repository).as_posix(),
        "metrics_sha256": audit_configs.sha256_file(artifact_path),
    })
    _write_registry(registry_path, rows)
    return repository, selection_path


def test_gate_a_passes_only_when_selected_dense_matches_or_exceeds_corrected_lstm(tmp_path: Path) -> None:
    repository, selection_path = _prepare(tmp_path, baseline_nse=0.71)
    output_path, report = gate_builder.build(
        selection_path,
        repo_root=repository,
        require_complete_binding=False,
    )

    gate = report["single_seed_dense_gate"]
    assert gate["status"] == "PASS"
    assert gate["selected_dense"] == "D02"
    assert gate["selected_minus_baseline_median"] > 0
    assert json.loads(output_path.read_text())["single_seed_dense_gate"] == gate


def test_gate_a_writes_hold_evidence_and_refuses_to_authorize_m01(tmp_path: Path) -> None:
    repository, selection_path = _prepare(tmp_path, baseline_nse=0.80)
    output_path, report = gate_builder.build(
        selection_path,
        repo_root=repository,
        require_complete_binding=False,
    )

    assert report["single_seed_dense_gate"]["status"] == "HOLD"
    assert output_path.is_file()
    assert not (repository / "src/modern_transformer_moe/configs/moe_selected_s100.yml").exists()
