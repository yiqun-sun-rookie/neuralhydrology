from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
HPC_DIR = REPO_ROOT / "src/modern_transformer_moe/hpc"


def _read(name: str) -> str:
    return (HPC_DIR / name).read_text(encoding="utf-8")


def test_all_execution_stages_are_compute_node_slurm_jobs_with_fail_fast_shells():
    expected = {
        "submit_prepare_track0_bundles.slurm",
        "submit_preselection_gates.slurm",
        "submit_seed100_development.slurm",
        "submit_dense_selection.slurm",
        "submit_m01_development.slurm",
    }
    assert {path.name for path in HPC_DIR.glob("*.slurm")} == expected
    for name in expected:
        text = _read(name)
        assert "#SBATCH --partition=hgpu2p" in text
        assert "#SBATCH --nodes=1" in text
        assert "#SBATCH --ntasks=1" in text
        assert "conda activate nh_final" in text
        assert "id30_modern_transformer_moe_20260827/repo" in text
        assert "usgs_streamflow" not in text or name == "submit_prepare_track0_bundles.slurm"
        assert "_obs_eval" not in text


def test_gpu_stages_request_one_gpu_exclude_the_known_bad_node_and_hard_check_cuda():
    for name in (
        "submit_preselection_gates.slurm",
        "submit_seed100_development.slurm",
        "submit_m01_development.slurm",
    ):
        text = _read(name)
        assert "#SBATCH --gres=gpu:1" in text
        assert "#SBATCH --exclude=ngu002" in text
        assert "nvidia-smi" in text
    assert "torch.cuda.is_available()" in _read("submit_preselection_gates.slurm")


def test_full_development_requires_bound_gates_and_explicit_heavy_compute_authorization():
    candidate = _read("submit_seed100_development.slurm")
    assert 'for experiment_id in ("B01", "D01", "D02", "D03")' in candidate
    assert 'report["overall_status"] == "PASS"' in candidate
    assert "--operator-approved-heavy-compute" in candidate
    assert "B01|D01|D02|D03" in candidate

    m01 = _read("submit_m01_development.slurm")
    assert "--experiment-id M01" in m01
    assert 'report["overall_status"] == "PASS"' in m01
    assert "--operator-approved-heavy-compute" in m01


def test_dense_selection_is_validation_only_and_materializes_m01_after_all_dense_runs():
    text = _read("submit_dense_selection.slurm")
    assert "build_dense_selection_report" in text
    assert "build_single_seed_dense_gate" in text
    assert text.index("build_single_seed_dense_gate") < text.index("generate_selected_moe_config")
    assert "generate_selected_moe_config" in text
    assert "score.py" not in text
    assert "evaluate" not in text
    assert "--gres" not in text
