"""Run one full-production-shape, actual-data optimizer step as a GPU resource gate."""

from __future__ import annotations

import argparse
import json
import math
import os
import platform
import re
import socket
import subprocess
import sys
import time
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import torch

from neuralhydrology.training.basetrainer import BaseTrainer
from neuralhydrology.utils.config import Config
from src.modern_transformer_moe.scripts import audit_configs, run_development
from src.modern_transformer_moe.scripts.candidate_safe_data import (assert_safe_data_unchanged, audit_access_log,
                                                                   capture_safe_data_snapshot)


REPO_ROOT = Path(__file__).resolve().parents[3]
OUTPUT_RELATIVE_ROOT = Path("results/30_modern_transformer_moe/_gpu_resource_probes")
GPU_MEMORY_LIMIT_BYTES = 12 * 1024**3
ALLOWED_EXPERIMENT_IDS = {"B01", "D01", "D02", "D03", "M01"}
ALLOWED_RUNTIME_DIFFERENCES = {
    "cache_validation_data",
    "device",
    "epochs",
    "experiment_name",
    "log_interval",
    "log_n_figures",
    "log_tensorboard",
    "max_updates_per_epoch",
    "metrics",
    "run_dir",
    "save_all_output",
    "save_git_diff",
    "save_train_data",
    "save_validation_results",
    "save_weights_every",
    "validate_every",
}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _json_default(value: Any) -> str:
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"Object of type {value.__class__.__name__} is not JSON serializable")


def _atomic_json(path: Path, value: dict[str, Any], *, create: bool = False) -> None:
    serialized = json.dumps(value, indent=2, sort_keys=True, default=_json_default) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    if create:
        with path.open("x", encoding="utf-8") as file:
            file.write(serialized)
        return
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        with temporary.open("x", encoding="utf-8") as file:
            file.write(serialized)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _validate_probe_id(probe_id: str) -> None:
    if not probe_id or re.fullmatch(r"[A-Za-z0-9_.-]+", probe_id) is None:
        raise ValueError("probe_id may contain only letters, digits, dot, underscore, and hyphen")


def _source_config_path(experiment_id: str, repo_root: Path) -> Path:
    if experiment_id not in ALLOWED_EXPERIMENT_IDS:
        raise ValueError(f"experiment_id must be one of {sorted(ALLOWED_EXPERIMENT_IDS)}")
    return Path(repo_root) / run_development.CONFIG_RELATIVE_BY_ID[experiment_id]


def build_runtime_config(source_path: Path, probe_dir: Path, probe_id: str,
                         gpu: int) -> tuple[dict[str, Any], dict[str, Any], dict[str, dict[str, Any]]]:
    source_config = Config(Path(source_path)).as_dict()
    runtime_config = deepcopy(source_config)
    runtime_config.update({
        "cache_validation_data": False,
        "device": f"cuda:{gpu}",
        "epochs": 1,
        "experiment_name": f"{source_config['experiment_name']}_{probe_id}",
        "log_interval": 1,
        "log_n_figures": 0,
        "log_tensorboard": False,
        "max_updates_per_epoch": 1,
        "metrics": [],
        "run_dir": Path(probe_dir) / "training",
        "save_all_output": False,
        "save_git_diff": False,
        "save_train_data": False,
        "save_validation_results": False,
        "save_weights_every": 1,
        "validate_every": None,
    })
    differences = {
        key: {"source": source_config.get(key), "runtime": runtime_config.get(key)}
        for key in sorted(set(source_config) | set(runtime_config))
        if source_config.get(key) != runtime_config.get(key)
    }
    unexpected = set(differences) - ALLOWED_RUNTIME_DIFFERENCES
    if unexpected:
        raise ValueError(f"Runtime probe configuration drift: unexpected={sorted(unexpected)}")
    return source_config, runtime_config, differences


def plan_probe(experiment_id: str,
               seed: int,
               gpu: int,
               probe_id: str,
               repo_root: Path = REPO_ROOT,
               output_root: Path | None = None) -> dict[str, Any]:
    _validate_probe_id(probe_id)
    if seed != 100:
        raise ValueError("The preregistered full-size resource probes use random seed 100.")
    repo_root = Path(repo_root).resolve()
    source_path = _source_config_path(experiment_id, repo_root)
    source = audit_configs.load_yaml(source_path)
    issues = audit_configs.audit_common_contract(source, experiment_id, repo_root)
    if issues:
        raise ValueError("Source configuration failed the common contract: " + "; ".join(issues))
    output_root = Path(output_root) if output_root is not None else repo_root / OUTPUT_RELATIVE_ROOT
    return {
        "mode": "dry_run",
        "experiment_id": experiment_id,
        "seed": seed,
        "gpu": gpu,
        "probe_id": probe_id,
        "source_config": str(source_path),
        "configured_batch_size": int(source["batch_size"]),
        "configured_sequence_length": int(source["seq_length"]),
        "probe_dir": str(output_root / probe_id),
        "memory_limit_bytes": GPU_MEMORY_LIMIT_BYTES,
        "required_flags": ["--execute", "--operator-approved-gpu-probe"],
    }


def _tensor_shapes(value: Any) -> list[list[int]]:
    if torch.is_tensor(value):
        return [list(value.shape)]
    if isinstance(value, dict):
        return [shape for child in value.values() for shape in _tensor_shapes(child)]
    if isinstance(value, (list, tuple)):
        return [shape for child in value for shape in _tensor_shapes(child)]
    return []


def _optimizer_steps(optimizer: torch.optim.Optimizer) -> list[int]:
    steps = []
    for state in optimizer.state.values():
        if "step" not in state:
            continue
        step = state["step"]
        steps.append(int(step.item()) if torch.is_tensor(step) else int(step))
    return steps


def _source_metadata(repo_root: Path) -> dict[str, Any]:
    revision = subprocess.run(["git", "rev-parse", "HEAD"], cwd=repo_root, check=True, capture_output=True,
                              text=True).stdout.strip()
    status = subprocess.run(["git", "status", "--porcelain"], cwd=repo_root, check=True, capture_output=True,
                            text=True).stdout.splitlines()
    return {
        "git_revision": revision,
        "dirty_worktree": bool(status),
        "changed_path_count": len(status),
    }


def run_probe(experiment_id: str,
              seed: int,
              gpu: int,
              probe_id: str,
              operator_approved_gpu_probe: bool,
              repo_root: Path = REPO_ROOT,
              output_root: Path | None = None,
              trainer_factory=BaseTrainer) -> dict[str, Any]:
    if not operator_approved_gpu_probe:
        raise PermissionError("Real probe requires --operator-approved-gpu-probe.")
    plan = plan_probe(experiment_id, seed, gpu, probe_id, repo_root=repo_root, output_root=output_root)
    repo_root = Path(repo_root).resolve()
    probe_dir = Path(plan["probe_dir"])
    if probe_dir.exists():
        raise FileExistsError(f"Refusing to overwrite existing probe directory: {probe_dir}")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable; a full-size GPU probe cannot run.")
    if gpu < 0 or gpu >= torch.cuda.device_count():
        raise RuntimeError(f"GPU index {gpu} is outside the available CUDA device range.")

    source_path = Path(plan["source_config"])
    source_config, runtime_dict, differences = build_runtime_config(source_path, probe_dir, probe_id, gpu)
    data_snapshot = capture_safe_data_snapshot(repo_root, source_config)
    probe_dir.mkdir(parents=True, exist_ok=False)
    report_path = probe_dir / "probe_report.json"
    runtime_path = probe_dir / "runtime_config.yml"
    Config(runtime_dict).dump_config(probe_dir, runtime_path.name)
    access_log_path = probe_dir / "data_access.jsonl"
    report: dict[str, Any] = {
        "schema_version": 1,
        "probe_id": probe_id,
        "experiment_id": experiment_id,
        "seed": seed,
        "status": "RUNNING",
        "overall_status": "RUNNING",
        "started_at_utc": _utc_now(),
        "host": socket.gethostname(),
        "process_id": os.getpid(),
        "source_config_path": str(source_path),
        "source_config_sha256": audit_configs.sha256_file(source_path),
        "runtime_config_path": str(runtime_path),
        "runtime_config_sha256": audit_configs.sha256_file(runtime_path),
        "allowed_runtime_differences": differences,
        "source": _source_metadata(repo_root),
        "data_contract": data_snapshot,
        "environment": {
            "platform": platform.platform(),
            "python": platform.python_version(),
            "torch": torch.__version__,
            "device_index": gpu,
            "device_name": torch.cuda.get_device_name(gpu),
            "device_total_memory_bytes": int(torch.cuda.get_device_properties(gpu).total_memory),
        },
    }
    _atomic_json(report_path, report, create=True)
    failure_stage = "trainer_initialization"
    previous_access_log = os.environ.get("NEURALHYDROLOGY_DATA_ACCESS_LOG")
    os.environ["NEURALHYDROLOGY_DATA_ACCESS_LOG"] = str(access_log_path)
    forward_observation: dict[str, Any] = {"calls": 0, "input_tensor_shapes": [], "output_shape": None}
    hook = None
    started = time.perf_counter()
    try:
        runtime_config = Config(runtime_path)
        trainer = trainer_factory(cfg=runtime_config)
        trainer.initialize_training()
        failure_stage = "production_update"

        def observe_forward(_module, args, output):
            forward_observation["calls"] += 1
            forward_observation["input_tensor_shapes"].extend(_tensor_shapes(args))
            if isinstance(output, dict) and torch.is_tensor(output.get("y_hat")):
                forward_observation["output_shape"] = list(output["y_hat"].shape)

        hook = trainer.model.register_forward_hook(observe_forward)
        torch.cuda.synchronize(gpu)
        torch.cuda.reset_peak_memory_stats(gpu)
        trainer._train_epoch(1)
        torch.cuda.synchronize(gpu)
        losses = trainer.experiment_logger.summarise()
        loss_value = float(losses["avg_total_loss"])
        gradients = [parameter.grad.detach() for parameter in trainer.model.parameters() if parameter.grad is not None]
        finite_gradients = bool(gradients) and all(bool(torch.isfinite(gradient).all().item()) for gradient in gradients)
        nonzero_gradients = sum(int(torch.count_nonzero(gradient).item()) for gradient in gradients)
        optimizer_steps = _optimizer_steps(trainer.optimizer)
        input_shapes = forward_observation["input_tensor_shapes"]
        shape_observed = any(plan["configured_batch_size"] in shape and plan["configured_sequence_length"] in shape
                             for shape in input_shapes)
        peak_allocated = int(torch.cuda.max_memory_allocated(gpu))
        peak_reserved = int(torch.cuda.max_memory_reserved(gpu))
        checks = {
            "one_forward_call": forward_observation["calls"] == 1,
            "configured_batch_and_sequence_observed": shape_observed,
            "finite_loss": math.isfinite(loss_value),
            "finite_gradients": finite_gradients,
            "nonzero_gradients": nonzero_gradients > 0,
            "optimizer_state_exists": bool(optimizer_steps),
            "optimizer_step_exactly_one": bool(optimizer_steps) and set(optimizer_steps) == {1},
            "peak_reserved_below_12_gib": peak_reserved < GPU_MEMORY_LIMIT_BYTES,
        }
        failure_stage = "postflight_integrity"
        current_data = assert_safe_data_unchanged(data_snapshot, repo_root, source_config)
        data_access = audit_access_log(access_log_path, data_snapshot["forcing_dir"], data_snapshot["supervision_dir"])
        if audit_configs.sha256_file(source_path) != report["source_config_sha256"]:
            raise RuntimeError("Source configuration changed during the probe.")

        report.update({
            "status": "COMPLETE",
            "overall_status": "PASS" if all(checks.values()) else "FAIL",
            "completed_at_utc": _utc_now(),
            "wall_seconds": time.perf_counter() - started,
            "actual": {
                "configured_batch_size": plan["configured_batch_size"],
                "configured_sequence_length": plan["configured_sequence_length"],
                "forward_observation": forward_observation,
                "loss": loss_value,
                "gradient_tensor_count": len(gradients),
                "nonzero_gradient_element_count": nonzero_gradients,
                "optimizer_state_entry_count": len(trainer.optimizer.state),
                "optimizer_step_values": sorted(set(optimizer_steps)),
                "total_parameters": sum(parameter.numel() for parameter in trainer.model.parameters()),
                "trainable_parameters": sum(parameter.numel() for parameter in trainer.model.parameters()
                                            if parameter.requires_grad),
            },
            "memory": {
                "limit_bytes": GPU_MEMORY_LIMIT_BYTES,
                "peak_allocated_bytes": peak_allocated,
                "peak_reserved_bytes": peak_reserved,
                "headroom_bytes": GPU_MEMORY_LIMIT_BYTES - peak_reserved,
                "headroom_warning": GPU_MEMORY_LIMIT_BYTES - peak_reserved < 1024**3,
            },
            "checks": checks,
            "postflight_data_contract": current_data,
            "data_access": data_access,
            "training_run_dir": str(trainer.cfg.run_dir),
        })
        _atomic_json(report_path, report)
        return report
    except BaseException as error:
        report.update({
            "status": "FAILED",
            "overall_status": "FAIL",
            "failed_at_utc": _utc_now(),
            "wall_seconds": time.perf_counter() - started,
            "failure_stage": failure_stage,
            "error_type": type(error).__name__,
            "error": str(error),
        })
        _atomic_json(report_path, report)
        raise
    finally:
        if hook is not None:
            hook.remove()
        if previous_access_log is None:
            os.environ.pop("NEURALHYDROLOGY_DATA_ACCESS_LOG", None)
        else:
            os.environ["NEURALHYDROLOGY_DATA_ACCESS_LOG"] = previous_access_log


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment-id", choices=sorted(ALLOWED_EXPERIMENT_IDS), required=True)
    parser.add_argument("--seed", type=int, default=100)
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--probe-id", required=True)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--operator-approved-gpu-probe", action="store_true")
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps(plan_probe(args.experiment_id, args.seed, args.gpu, args.probe_id), indent=2))
        return 0
    report = run_probe(
        experiment_id=args.experiment_id,
        seed=args.seed,
        gpu=args.gpu,
        probe_id=args.probe_id,
        operator_approved_gpu_probe=args.operator_approved_gpu_probe,
    )
    print(json.dumps(report, indent=2))
    return 0 if report["overall_status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
