from pathlib import Path

import pytest

from src.modern_transformer_moe.scripts import run_full_size_gpu_probe as gpu_probe


REPO_ROOT = Path(__file__).resolve().parents[1]


def test_probe_is_dry_run_by_default_and_writes_nothing(tmp_path):
    plan = gpu_probe.plan_probe("D01", seed=100, gpu=0, probe_id="unit_dry", repo_root=REPO_ROOT,
                                output_root=tmp_path)

    assert plan["mode"] == "dry_run"
    assert plan["experiment_id"] == "D01"
    assert plan["configured_batch_size"] == 64
    assert plan["configured_sequence_length"] == 270
    assert not (tmp_path / "unit_dry").exists()


def test_real_probe_requires_explicit_operator_approval(tmp_path):
    with pytest.raises(PermissionError, match="operator-approved-gpu-probe"):
        gpu_probe.run_probe(
            "D01",
            seed=100,
            gpu=0,
            probe_id="unit_no_approval",
            operator_approved_gpu_probe=False,
            repo_root=REPO_ROOT,
            output_root=tmp_path,
        )
    assert not (tmp_path / "unit_no_approval").exists()


@pytest.mark.parametrize("probe_id", ["", "contains space", "../escape", "a/b"])
def test_probe_id_must_be_globally_safe(probe_id, tmp_path):
    with pytest.raises(ValueError, match="probe_id"):
        gpu_probe.plan_probe("B01", seed=100, gpu=0, probe_id=probe_id, repo_root=REPO_ROOT,
                             output_root=tmp_path)


def test_existing_probe_directory_is_rejected_before_cuda_or_training(tmp_path, monkeypatch):
    existing = tmp_path / "unit_existing"
    existing.mkdir(parents=True)
    monkeypatch.setattr(gpu_probe.torch.cuda, "is_available", lambda: pytest.fail("CUDA queried after collision"))

    with pytest.raises(FileExistsError, match="Refusing to overwrite"):
        gpu_probe.run_probe(
            "D01",
            seed=100,
            gpu=0,
            probe_id="unit_existing",
            operator_approved_gpu_probe=True,
            repo_root=REPO_ROOT,
            output_root=tmp_path,
        )


def test_runtime_config_changes_only_preregistered_probe_fields(tmp_path):
    source_path = REPO_ROOT / "src/modern_transformer_moe/configs/dense_d128_l4_s100.yml"
    source, runtime, differences = gpu_probe.build_runtime_config(
        source_path=source_path,
        probe_dir=tmp_path / "probe",
        probe_id="unit_runtime",
        gpu=0,
    )

    assert set(differences).issubset(gpu_probe.ALLOWED_RUNTIME_DIFFERENCES)
    assert {"epochs", "experiment_name", "max_updates_per_epoch", "run_dir", "validate_every"}.issubset(differences)
    assert runtime["batch_size"] == source["batch_size"] == 64
    assert runtime["seq_length"] == source["seq_length"] == 270
    assert runtime["dataset"] == source["dataset"] == "camels_us_track0_bundle"
    assert runtime["max_updates_per_epoch"] == 1
    assert runtime["epochs"] == 1


def test_probe_report_json_serializes_runtime_path_values(tmp_path):
    report_path = tmp_path / "probe_report.json"

    gpu_probe._atomic_json(
        report_path,
        {"allowed_runtime_differences": {"run_dir": {"source": Path("source"), "runtime": Path("runtime")}}},
        create=True,
    )

    assert report_path.read_text(encoding="utf-8") == (
        '{\n'
        '  "allowed_runtime_differences": {\n'
        '    "run_dir": {\n'
        '      "runtime": "runtime",\n'
        '      "source": "source"\n'
        '    }\n'
        '  }\n'
        '}\n'
    )


def test_probe_report_serialization_failure_does_not_publish_partial_json(tmp_path):
    report_path = tmp_path / "probe_report.json"

    with pytest.raises(TypeError, match="not JSON serializable"):
        gpu_probe._atomic_json(report_path, {"unsupported": object()}, create=True)

    assert not report_path.exists()


def test_postselection_mixture_of_experts_is_an_explicit_probe_target():
    assert "M01" in gpu_probe.ALLOWED_EXPERIMENT_IDS
    assert gpu_probe._source_config_path("M01", REPO_ROOT) == (
        REPO_ROOT / "src/modern_transformer_moe/configs/moe_selected_s100.yml"
    )
