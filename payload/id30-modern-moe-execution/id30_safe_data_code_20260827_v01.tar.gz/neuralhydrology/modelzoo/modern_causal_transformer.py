"""Modern causal Transformer with an optional dropless mixture-of-experts feed-forward sublayer."""

import hashlib
from typing import Dict, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as functional

from neuralhydrology.modelzoo.basemodel import BaseModel
from neuralhydrology.modelzoo.head import get_head
from neuralhydrology.modelzoo.inputlayer import InputLayer
from neuralhydrology.utils.config import Config


class RMSNorm(nn.Module):
    """Root-mean-square normalization with a learned per-feature scale."""

    def __init__(self, width: int, eps: float = 1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(width))
        self.eps = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        calculation_dtype = torch.float32 if x.dtype in (torch.float16, torch.bfloat16) else x.dtype
        variance = x.to(calculation_dtype).square().mean(dim=-1, keepdim=True)
        normalized = x.to(calculation_dtype) * torch.rsqrt(variance + self.eps)
        return normalized.to(x.dtype) * self.weight.to(x.dtype)


class RotaryEmbedding(nn.Module):
    """Apply rotary positions to query and key tensors in ``[batch, heads, sequence, width]`` format."""

    def __init__(self, head_dimension: int, base: float = 10_000.0):
        super().__init__()
        if head_dimension % 2 != 0:
            raise ValueError(
                f"Rotary position encoding requires an even attention-head dimension, got {head_dimension}.")
        inverse_frequency = 1.0 / (base**(torch.arange(0, head_dimension, 2, dtype=torch.float32) / head_dimension))
        self.register_buffer("inverse_frequency", inverse_frequency, persistent=False)
        self.head_dimension = head_dimension

    @staticmethod
    def _rotate(x: torch.Tensor, cosine: torch.Tensor, sine: torch.Tensor) -> torch.Tensor:
        even = x[..., 0::2]
        odd = x[..., 1::2]
        rotated = torch.stack((even * cosine - odd * sine, even * sine + odd * cosine), dim=-1)
        return rotated.flatten(start_dim=-2)

    def forward(self, query: torch.Tensor, key: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        if query.shape[-1] != self.head_dimension or key.shape[-1] != self.head_dimension:
            raise ValueError("Query and key widths must match the configured rotary attention-head dimension.")
        if query.shape[-2] != key.shape[-2]:
            raise ValueError("Query and key sequence lengths must match for causal self-attention.")

        positions = torch.arange(query.shape[-2], device=query.device, dtype=self.inverse_frequency.dtype)
        angles = torch.outer(positions, self.inverse_frequency.to(query.device))
        query_cosine = angles.cos().to(query.dtype).view(1, 1, query.shape[-2], -1)
        query_sine = angles.sin().to(query.dtype).view(1, 1, query.shape[-2], -1)
        key_cosine = query_cosine.to(dtype=key.dtype, device=key.device)
        key_sine = query_sine.to(dtype=key.dtype, device=key.device)
        return self._rotate(query, query_cosine, query_sine), self._rotate(key, key_cosine, key_sine)


class CausalSelfAttention(nn.Module):
    """Multi-head rotary self-attention backed by PyTorch scaled dot-product attention."""

    def __init__(self, model_width: int, num_heads: int, dropout: float):
        super().__init__()
        if model_width % num_heads != 0:
            raise ValueError(f"Model width {model_width} must be divisible by {num_heads} attention heads.")
        head_dimension = model_width // num_heads
        if head_dimension % 2 != 0:
            raise ValueError(
                f"Rotary position encoding requires an even attention-head dimension, got {head_dimension}.")

        self.model_width = model_width
        self.num_heads = num_heads
        self.head_dimension = head_dimension
        self.dropout = dropout
        self.query_projection = nn.Linear(model_width, model_width, bias=False)
        self.key_projection = nn.Linear(model_width, model_width, bias=False)
        self.value_projection = nn.Linear(model_width, model_width, bias=False)
        self.output_projection = nn.Linear(model_width, model_width, bias=False)
        self.rotary_embedding = RotaryEmbedding(head_dimension)
        self.residual_dropout = nn.Dropout(dropout)

    def _split_heads(self, x: torch.Tensor) -> torch.Tensor:
        batch_size, sequence_length, _ = x.shape
        return x.view(batch_size, sequence_length, self.num_heads, self.head_dimension).transpose(1, 2)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        query = self._split_heads(self.query_projection(x))
        key = self._split_heads(self.key_projection(x))
        value = self._split_heads(self.value_projection(x))
        query, key = self.rotary_embedding(query, key)

        attended = functional.scaled_dot_product_attention(query,
                                                           key,
                                                           value,
                                                           dropout_p=self.dropout if self.training else 0.0,
                                                           is_causal=True)
        attended = attended.transpose(1, 2).contiguous().view(x.shape)
        return self.residual_dropout(self.output_projection(attended))


class GatedFeedForward(nn.Module):
    """SwiGLU feed-forward network: ``down(silu(gate(x)) * up(x))``."""

    def __init__(self, model_width: int, intermediate_width: int, dropout: float = 0.0):
        super().__init__()
        if intermediate_width <= 0:
            raise ValueError("Feed-forward intermediate width must be positive.")
        self.intermediate_width = intermediate_width
        self.gate_projection = nn.Linear(model_width, intermediate_width, bias=False)
        self.up_projection = nn.Linear(model_width, intermediate_width, bias=False)
        self.down_projection = nn.Linear(intermediate_width, model_width, bias=False)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        activated = functional.silu(self.gate_projection(x)) * self.up_projection(x)
        return self.dropout(self.down_projection(activated))


class DroplessMoEFeedForward(nn.Module):
    """One always-active shared expert plus sparse routed experts without a capacity limit."""

    def __init__(self,
                 model_width: int,
                 shared_intermediate: int,
                 routed_intermediate: int,
                 num_experts: int,
                 top_k: int,
                 router_jitter: float,
                 dropout: float = 0.0):
        super().__init__()
        if num_experts < 1:
            raise ValueError("The number of routed experts must be positive.")
        if not 1 <= top_k <= num_experts:
            raise ValueError(f"top_k must be between 1 and {num_experts}, got {top_k}.")
        if not 0.0 <= router_jitter < 1.0:
            raise ValueError("Router jitter must be in the interval [0, 1).")

        self.num_experts = num_experts
        self.top_k = top_k
        self.router_jitter = router_jitter
        self.shared_expert = GatedFeedForward(model_width, shared_intermediate, dropout=dropout)
        self.routed_experts = nn.ModuleList(
            [GatedFeedForward(model_width, routed_intermediate, dropout=dropout) for _ in range(num_experts)])
        self.router = nn.Linear(model_width, num_experts, bias=False)

    def _route(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        router_input = x
        if self.training and self.router_jitter > 0.0:
            noise = torch.empty_like(router_input).uniform_(1.0 - self.router_jitter, 1.0 + self.router_jitter)
            router_input = router_input * noise

        # ``linear`` is normally autocast to a low-precision kernel. Disable autocast locally so routing decisions and
        # the load-balancing probabilities are always computed in float32, including during mixed-precision training.
        with torch.autocast(device_type=router_input.device.type, enabled=False):
            router_logits = functional.linear(router_input.float(), self.router.weight.float())
        router_probabilities = torch.softmax(router_logits, dim=-1)
        selected_probabilities, selected_indices = torch.topk(router_probabilities, k=self.top_k, dim=-1)
        selected_weights = selected_probabilities / selected_probabilities.sum(dim=-1, keepdim=True)
        return router_logits, router_probabilities, selected_indices, selected_weights

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        original_shape = x.shape
        flattened = x.reshape(-1, original_shape[-1])
        if flattened.shape[0] == 0:
            raise ValueError("Mixture-of-experts routing requires at least one token.")

        router_logits, router_probabilities, selected_indices, selected_weights = self._route(flattened)
        expert_load = torch.bincount(selected_indices.reshape(-1), minlength=self.num_experts)
        load_fraction = expert_load.to(router_probabilities.dtype) / (flattened.shape[0] * self.top_k)
        importance = router_probabilities.mean(dim=0)
        auxiliary_loss = self.num_experts * torch.sum(importance * load_fraction)

        shared_output = self.shared_expert(flattened)
        routed_output = torch.zeros_like(shared_output)
        for expert_index, expert in enumerate(self.routed_experts):
            assignments = torch.nonzero(selected_indices == expert_index, as_tuple=False)
            if assignments.numel() == 0:
                continue
            token_indices = assignments[:, 0]
            route_indices = assignments[:, 1]
            expert_input = flattened.index_select(0, token_indices)
            expert_output = expert(expert_input)
            weights = selected_weights[token_indices, route_indices].to(expert_output.dtype).unsqueeze(-1)
            routed_output = routed_output.index_add(0, token_indices, expert_output * weights)

        output = shared_output + routed_output
        diagnostics = {
            "auxiliary_loss": auxiliary_loss,
            "router_logits": router_logits.detach(),
            "router_probabilities": router_probabilities.detach(),
            "topk_indices": selected_indices.detach(),
            "topk_weights": selected_weights.detach(),
            "expert_load": expert_load.detach(),
            "dropped_tokens": torch.zeros((), dtype=torch.long, device=x.device),
        }
        return output.view(original_shape), diagnostics


class ModernTransformerBlock(nn.Module):
    """Pre-normalized causal attention and feed-forward residual block."""

    def __init__(self, model_width: int, num_heads: int, feed_forward: nn.Module, dropout: float):
        super().__init__()
        self.attention_norm = RMSNorm(model_width)
        self.attention = CausalSelfAttention(model_width, num_heads, dropout)
        self.feed_forward_norm = RMSNorm(model_width)
        self.feed_forward = feed_forward

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, Dict[str, torch.Tensor] | None]:
        x = x + self.attention(self.attention_norm(x))
        feed_forward_input = self.feed_forward_norm(x)
        if isinstance(self.feed_forward, DroplessMoEFeedForward):
            feed_forward_output, diagnostics = self.feed_forward(feed_forward_input)
        else:
            feed_forward_output = self.feed_forward(feed_forward_input)
            diagnostics = None
        return x + feed_forward_output, diagnostics


class ModernCausalTransformer(BaseModel):
    """Causal Transformer whose dense and mixture-of-experts variants share one implementation."""

    module_parts = ["embedding_net", "input_projection", "blocks", "final_norm", "head"]

    def __init__(self, cfg: Config):
        super().__init__(cfg=cfg)
        self.embedding_net = InputLayer(cfg)
        self.model_width = self.embedding_net.output_size
        self.is_moe = cfg.model.lower() == "modern_transformer_moe"

        if self.model_width % cfg.transformer_nheads != 0:
            raise ValueError(
                f"Embedding dimension {self.model_width} must be divisible by "
                f"{cfg.transformer_nheads} attention heads.")
        head_dimension = self.model_width // cfg.transformer_nheads
        if head_dimension % 2 != 0:
            raise ValueError(
                f"Rotary position encoding requires an even attention-head dimension, got {head_dimension}.")

        self.input_projection = nn.Linear(self.model_width, self.model_width, bias=False)
        self.blocks = nn.ModuleList()
        self._moe_first_layer = cfg.transformer_nlayers
        self._active_feed_forward_width = cfg.transformer_dim_feedforward

        if self.is_moe:
            self._validate_moe_configuration(cfg)
            self._moe_first_layer = cfg.transformer_moe_first_layer

        for layer_index in range(cfg.transformer_nlayers):
            if self.is_moe and layer_index >= self._moe_first_layer:
                feed_forward = DroplessMoEFeedForward(
                    model_width=self.model_width,
                    shared_intermediate=cfg.transformer_moe_shared_dim,
                    routed_intermediate=cfg.transformer_moe_routed_dim,
                    num_experts=cfg.transformer_moe_num_experts,
                    top_k=cfg.transformer_moe_top_k,
                    router_jitter=cfg.transformer_moe_router_jitter,
                    dropout=cfg.transformer_dropout)
            else:
                feed_forward = GatedFeedForward(self.model_width,
                                                cfg.transformer_dim_feedforward,
                                                dropout=cfg.transformer_dropout)
            self.blocks.append(
                ModernTransformerBlock(self.model_width, cfg.transformer_nheads, feed_forward, cfg.transformer_dropout))

        self.final_norm = RMSNorm(self.model_width)
        self.output_dropout = nn.Dropout(cfg.output_dropout)
        self.head = get_head(cfg=cfg, n_in=self.model_width, n_out=self.output_size)
        if cfg.seed is None:
            self.apply(self._initialize_module)
        else:
            self._initialize_named_parameters(cfg.seed)

    @staticmethod
    def _initialize_module(module: nn.Module):
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, RMSNorm):
            nn.init.ones_(module.weight)

    @staticmethod
    def _derive_parameter_seed(base_seed: int, parameter_name: str) -> int:
        seed_material = f"{int(base_seed)}\0{parameter_name}".encode("utf-8")
        digest = hashlib.sha256(seed_material).digest()
        return int.from_bytes(digest[:8], byteorder="big", signed=False) % (2**63 - 1)

    @staticmethod
    def _normal_initialize_parameter(parameter: nn.Parameter, seed: int):
        generator = torch.Generator(device=parameter.device)
        generator.manual_seed(seed)
        with torch.no_grad():
            parameter.normal_(mean=0.0, std=0.02, generator=generator)

    def _initialize_named_parameters(self, base_seed: int):
        """Initialize every supported parameter from a stable seed derived from its full model name."""
        for module_name, module in self.named_modules():
            parameter_prefix = f"{module_name}." if module_name else ""
            if isinstance(module, nn.Linear):
                parameter_name = f"{parameter_prefix}weight"
                parameter_seed = self._derive_parameter_seed(base_seed, parameter_name)
                self._normal_initialize_parameter(module.weight, parameter_seed)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
            elif isinstance(module, RMSNorm):
                nn.init.ones_(module.weight)

    @staticmethod
    def _validate_moe_configuration(cfg: Config):
        if not 0 <= cfg.transformer_moe_first_layer < cfg.transformer_nlayers:
            raise ValueError("transformer_moe_first_layer is a zero-based index and must identify an existing layer.")
        active_width = cfg.transformer_moe_shared_dim + cfg.transformer_moe_top_k * cfg.transformer_moe_routed_dim
        if active_width != cfg.transformer_dim_feedforward:
            raise ValueError(
                "Mixture-of-experts active feed-forward width must exactly match the dense feed-forward width: "
                f"{cfg.transformer_moe_shared_dim} + {cfg.transformer_moe_top_k} * "
                f"{cfg.transformer_moe_routed_dim} = {active_width}, expected {cfg.transformer_dim_feedforward}.")

    def parameter_counts(self) -> Dict[str, int | float]:
        """Return total and per-token active parameter counts for auditable dense/sparse comparisons."""
        total_parameters = sum(parameter.numel() for parameter in self.parameters())
        inactive_parameters = 0
        for block in self.blocks:
            if isinstance(block.feed_forward, DroplessMoEFeedForward):
                expert_parameters = sum(parameter.numel()
                                        for parameter in block.feed_forward.routed_experts[0].parameters())
                inactive_parameters += (block.feed_forward.num_experts - block.feed_forward.top_k) * expert_parameters
        active_parameters = total_parameters - inactive_parameters
        return {
            "total_parameters": total_parameters,
            "active_parameters_per_token": active_parameters,
            "active_to_total_ratio": active_parameters / total_parameters,
            "active_feed_forward_width": self._active_feed_forward_width,
        }

    def forward(self, data: dict[str, torch.Tensor | dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        embedding = self.embedding_net(data)
        hidden = self.input_projection(embedding.transpose(0, 1))
        router_losses = []
        expert_loads = []
        dropped_tokens = []

        for block in self.blocks:
            hidden, diagnostics = block(hidden)
            if diagnostics is not None:
                router_losses.append(diagnostics["auxiliary_loss"])
                expert_loads.append(diagnostics["expert_load"])
                dropped_tokens.append(diagnostics["dropped_tokens"])

        prediction = self.head(self.output_dropout(self.final_norm(hidden)))
        prediction["embedding"] = embedding
        if router_losses:
            router_loss = torch.stack(router_losses).mean()
            total_dropped_tokens = torch.stack(dropped_tokens).sum()
            # BaseTester concatenates every tensor output along axis 0 when ``save_all_output`` is enabled. Keep the
            # training loss scalar for regularization, but expose evaluation scalars as one-element tensors so that
            # diagnostic collection remains compatible with that interface.
            if not self.training:
                router_loss = router_loss.reshape(1)
                total_dropped_tokens = total_dropped_tokens.reshape(1)
            prediction["moe_router_loss"] = router_loss
            prediction["moe_expert_load"] = torch.stack(expert_loads)
            prediction["moe_dropped_tokens"] = total_dropped_tokens
        return prediction
