import logging
import warnings
from typing import Iterable, List, Union

import torch

import neuralhydrology.training.loss as loss
from neuralhydrology.training import regularization
from neuralhydrology.utils.config import Config

LOGGER = logging.getLogger(__name__)


def get_optimizer(model: Union[torch.nn.Module, Iterable], cfg: Config) -> torch.optim.Optimizer:
    """Get specific optimizer object, depending on the run configuration.

    Currently only 'Adam' and 'AdamW' are supported.

    Parameters
    ----------
    model : Union[torch.nn.Module, Iterable]
        The model to be optimized, or an iterable of `torch.Tensor`s or `dict`s specifying what should be optimized.
        The latter is used by data assimilation, which optimizes model states instead of model weights.
    cfg : Config
        The run configuration.

    Returns
    -------
    torch.optim.Optimizer
        Optimizer object that can be used for training.
    """
    parameters = model.parameters() if isinstance(model, torch.nn.Module) else model

    if cfg.optimizer.lower() == "adam":
        optimizer = torch.optim.Adam(parameters, lr=cfg.learning_rate[0])
    elif cfg.optimizer.lower() == "adamw":
        optimizer = torch.optim.AdamW(parameters, lr=cfg.learning_rate[0])
    else:
        raise NotImplementedError(f"{cfg.optimizer} not implemented or not linked in `get_optimizer()`")

    return optimizer


def get_loss_obj(cfg: Config) -> loss.BaseLoss:
    """Get loss object, depending on the run configuration.
    
    Currently supported are 'MSE', 'NSE', 'RMSE', 'GMMLoss', 'CMALLoss', and 'UMALLoss'.
    
    Parameters
    ----------
    cfg : Config
        The run configuration.

    Returns
    -------
    loss.BaseLoss
        A new loss instance that implements the loss specified in the config or, if different, the loss required by the 
        head.
    """
    if cfg.loss.lower() == "mse":
        loss_obj = loss.MaskedMSELoss(cfg)
    elif cfg.loss.lower() == "nse":
        loss_obj = loss.MaskedNSELoss(cfg)
    elif cfg.loss.lower() == "weightednse":
        warnings.warn("'WeightedNSE loss has been removed. Use 'NSE' with 'target_loss_weights'", FutureWarning)
        loss_obj = loss.MaskedNSELoss(cfg)
    elif cfg.loss.lower() == "rmse":
        loss_obj = loss.MaskedRMSELoss(cfg)
    elif cfg.loss.lower() == "gmmloss":
        loss_obj = loss.MaskedGMMLoss(cfg)
    elif cfg.loss.lower() == "cmalloss":
        loss_obj = loss.MaskedCMALLoss(cfg)
    elif cfg.loss.lower() == "umalloss":
        loss_obj = loss.MaskedUMALLoss(cfg)
    elif cfg.loss.lower() == "evtloss":
        loss_obj = loss.MaskedEVTLoss(cfg)
    elif cfg.loss.lower() == "gaussiannllloss":
        loss_obj = loss.MaskedGaussianNLLLoss(cfg)
    elif cfg.loss.lower() == "maskedpeakweightedmse":
        loss_obj = loss.MaskedPeakWeightedMSELoss(cfg,
                                                  alpha=cfg.peak_loss_alpha,
                                                  threshold=cfg.peak_loss_threshold,
                                                  weight_cap=cfg.peak_loss_weight_cap)
    elif cfg.loss.lower() == "anchornse":
        loss_obj = loss.MaskedAnchorNSELoss(cfg, gamma=cfg.anchor_gamma)
    elif cfg.loss.lower() == "quantile":
        loss_obj = loss.MaskedQuantileLoss(cfg, tau=cfg.quantile_tau)
    else:
        raise NotImplementedError(f"{cfg.loss} not implemented or not linked in `get_loss()`")

    return loss_obj


def get_regularization_obj(cfg: Config) -> List[regularization.BaseRegularization]:
    """Get list of regularization objects.
    
    Currently, only the 'tie_frequencies' regularization is implemented.
    
    Parameters
    ----------
    cfg : Config
        The run configuration.

    Returns
    -------
    List[regularization.BaseRegularization]
        List of regularization objects that will be added to the loss during training.
    """
    regularization_modules = []
    for reg_item in cfg.regularization:
        if isinstance(reg_item, str):
            reg_name = reg_item
            reg_weight = 1.0
        else:
            reg_name, reg_weight = reg_item
        if reg_name == "tie_frequencies":
            regularization_modules.append(regularization.TiedFrequencyMSERegularization(cfg=cfg, weight=reg_weight))
        elif reg_name == "forecast_overlap":
            regularization_modules.append(regularization.ForecastOverlapMSERegularization(cfg=cfg, weight=reg_weight))
        elif reg_name == "moe_router":
            regularization_modules.append(regularization.MoERouterRegularization(cfg=cfg, weight=reg_weight))
        else:
            raise NotImplementedError(f"{reg_name} not implemented or not linked in `get_regularization_obj()`.")

    return regularization_modules
