"""Candidate-safe CAMELS-US loader for the forcing-only development track."""

from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Dict, List, Union

import pandas as pd
import xarray

from neuralhydrology.datasetzoo.basedataset import BaseDataset
from neuralhydrology.utils.config import Config


FORCING_VARIABLES = ["PRCP(mm/day)", "Tmin(C)", "Tmax(C)", "SRAD(W/m2)", "Vp(Pa)"]
TARGET_COLUMN = "QObs(mm/d)"
TRACK0_STATIC_ATTRIBUTES = [
    "p_mean",
    "pet_mean",
    "aridity",
    "p_seasonality",
    "frac_snow",
    "high_prec_freq",
    "high_prec_dur",
    "low_prec_freq",
    "low_prec_dur",
    "elev_mean",
    "slope_mean",
    "area_gages2",
    "frac_forest",
    "lai_max",
    "lai_diff",
    "gvf_max",
    "gvf_diff",
    "soil_depth_pelletier",
    "soil_depth_statsgo",
    "soil_porosity",
    "soil_conductivity",
    "max_water_content",
    "sand_frac",
    "silt_frac",
    "clay_frac",
    "carbonate_rocks_frac",
    "geol_permeability",
]


def _safe_file(root: Path, *parts: str) -> Path:
    """Resolve one existing file and reject symlinks or traversal outside its configured safe root."""
    resolved_root = Path(root).resolve(strict=True)
    candidate = resolved_root.joinpath(*parts).resolve(strict=True)
    try:
        candidate.relative_to(resolved_root)
    except ValueError as error:
        raise ValueError(f"Candidate path escapes configured safe root {resolved_root}: {candidate}") from error
    if not candidate.is_file():
        raise FileNotFoundError(f"Expected candidate-safe data file: {candidate}")
    access_log = os.environ.get("NEURALHYDROLOGY_DATA_ACCESS_LOG")
    if access_log:
        record = json.dumps({"process_id": os.getpid(), "path": str(candidate)}, sort_keys=True) + "\n"
        descriptor = os.open(access_log, os.O_APPEND | os.O_CREAT | os.O_WRONLY, 0o600)
        try:
            os.write(descriptor, record.encode("utf-8"))
        finally:
            os.close(descriptor)
    return candidate


class CamelsUSTrack0Bundle(BaseDataset):
    """Load only prebuilt Track 0 forcing, static attributes, and date-limited supervision.

    Unlike :class:`CamelsUS`, this class has no raw CAMELS-US path and never calls the raw forcing,
    attribute, or discharge loaders.
    """

    def __init__(self,
                 cfg: Config,
                 is_train: bool,
                 period: str,
                 basin: str = None,
                 additional_features: List[Dict[str, pd.DataFrame]] = [],
                 id_to_int: Dict[str, int] = {},
                 scaler: Dict[str, Union[pd.Series, xarray.DataArray]] = {}):
        super().__init__(cfg=cfg,
                         is_train=is_train,
                         period=period,
                         basin=basin,
                         additional_features=additional_features,
                         id_to_int=id_to_int,
                         scaler=scaler)

    @staticmethod
    def _validate_basin(basin: str) -> str:
        basin = str(basin)
        if re.fullmatch(r"[0-9]{8}", basin) is None:
            raise ValueError(f"Invalid eight-digit basin identifier: {basin!r}")
        return basin

    @staticmethod
    def _as_date_index(frame: pd.DataFrame, label: str) -> pd.DataFrame:
        frame = frame.copy()
        frame["date"] = pd.to_datetime(frame["date"], errors="raise")
        if frame["date"].duplicated().any():
            raise ValueError(f"{label} contains duplicate dates.")
        if not frame["date"].is_monotonic_increasing:
            raise ValueError(f"{label} dates are not strictly ordered.")
        return frame.set_index("date")

    def _load_basin_data(self, basin: str) -> pd.DataFrame:
        basin = self._validate_basin(basin)
        forcing_path = _safe_file(self.cfg.data_dir, "track0_forcing.parquet")
        forcing = pd.read_parquet(
            forcing_path,
            columns=["gauge_id", "date", *FORCING_VARIABLES],
            filters=[("gauge_id", "==", basin)],
        )
        if list(forcing.columns) != ["gauge_id", "date", *FORCING_VARIABLES]:
            raise ValueError("Candidate-safe forcing file does not match the locked schema.")
        forcing["gauge_id"] = forcing["gauge_id"].astype(str).str.zfill(8)
        if forcing.empty or set(forcing["gauge_id"]) != {basin}:
            raise ValueError(f"Candidate-safe forcing data is missing basin {basin}.")
        forcing = self._as_date_index(forcing.drop(columns="gauge_id"), f"forcing for basin {basin}")

        target_path = _safe_file(self.cfg.track0_supervision_dir, "targets", f"{basin}.parquet")
        target = pd.read_parquet(target_path)
        if list(target.columns) != ["date", TARGET_COLUMN]:
            raise ValueError(f"Candidate-safe supervision for basin {basin} does not match the locked schema.")
        target = self._as_date_index(target, f"supervision for basin {basin}")
        if not target.index.isin(forcing.index).all():
            raise ValueError(f"Candidate-safe supervision extends beyond available forcing for basin {basin}.")
        return forcing.join(target, how="left")

    def _load_attributes(self) -> pd.DataFrame:
        requested = list(self.cfg.static_attributes)
        forbidden = [attribute for attribute in requested if attribute not in TRACK0_STATIC_ATTRIBUTES]
        if forbidden:
            raise ValueError(f"Static attributes are outside the locked Track 0 schema: {forbidden}")
        statics_path = _safe_file(self.cfg.data_dir, "track0_statics.csv")
        attributes = pd.read_csv(statics_path, dtype={"gauge_id": str})
        if list(attributes.columns) != ["gauge_id", *TRACK0_STATIC_ATTRIBUTES]:
            raise ValueError("Candidate-safe static table does not match the locked Track 0 schema.")
        if attributes["gauge_id"].duplicated().any():
            raise ValueError("Candidate-safe static table contains duplicate basin identifiers.")
        attributes = attributes.set_index("gauge_id")
        if any(basin not in attributes.index for basin in self.basins):
            raise ValueError("Candidate-safe static table is missing one or more requested basins.")
        return attributes.loc[self.basins, requested]
