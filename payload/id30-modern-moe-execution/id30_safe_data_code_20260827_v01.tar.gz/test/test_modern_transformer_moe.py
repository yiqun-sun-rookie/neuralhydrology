"""Unit tests for dropless shared-expert top-two routing."""

import numpy as np
import pytest
import torch

from neuralhydrology.modelzoo import get_model
from neuralhydrology.modelzoo.modern_causal_transformer import DroplessMoEFeedForward, ModernCausalTransformer
from neuralhydrology.training import get_loss_obj, get_regularization_obj
from neuralhydrology.utils.config import Config


def _config(**updates) -> Config:
    values = {
        "model": "modern_transformer_moe",
        "head": "regression",
        "target_variables": ["q"],
        "dynamic_inputs": ["precipitation", "temperature"],
        "static_attributes": ["area", "slope"],
        "dynamics_embedding": {
            "type": "fc",
            "hiddens": [8],
            "activation": "linear",
            "dropout": 0.0,
        },
        "statics_embedding": {
            "type": "fc",
            "hiddens": [8],
            "activation": "linear",
            "dropout": 0.0,
        },
        "seq_length": 16,
        "transformer_nheads": 4,
        "transformer_dim_feedforward": 32,
        "transformer_dropout": 0.0,
        "transformer_nlayers": 2,
        "transformer_moe_num_experts": 8,
        "transformer_moe_top_k": 2,
        "transformer_moe_first_layer": 1,
        "transformer_moe_shared_dim": 8,
        "transformer_moe_routed_dim": 12,
        "transformer_moe_router_jitter": 0.0,
        "output_dropout": 0.0,
        "loss": "mse",
        "predict_last_n": 1,
        "regularization": [["moe_router", 0.01]],
    }
    values.update(updates)
    return Config(values)


def _dense_config(seed: int) -> Config:
    values = _config(seed=seed).as_dict().copy()
    values["model"] = "modern_transformer"
    values["regularization"] = []
    for key in list(values):
        if key.startswith("transformer_moe_"):
            values.pop(key)
    return Config(values)


def _common_non_feed_forward_parameters(
        dense: ModernCausalTransformer,
        sparse: ModernCausalTransformer) -> dict[str, tuple[torch.Tensor, torch.Tensor]]:
    dense_parameters = dict(dense.named_parameters())
    sparse_parameters = dict(sparse.named_parameters())
    common = {}
    for name in sorted(set(dense_parameters) & set(sparse_parameters)):
        if ".feed_forward." in name or ".router." in name:
            continue
        if dense_parameters[name].shape == sparse_parameters[name].shape:
            common[name] = (dense_parameters[name], sparse_parameters[name])
    return common


def _slow_reference(module: DroplessMoEFeedForward, x: torch.Tensor,
                    topk_indices: torch.Tensor, topk_weights: torch.Tensor) -> torch.Tensor:
    reference = module.shared_expert(x)
    routed = torch.zeros_like(reference)
    for token_index in range(x.shape[0]):
        for route_index in range(module.top_k):
            expert_index = int(topk_indices[token_index, route_index])
            expert_output = module.routed_experts[expert_index](x[token_index:token_index + 1]).squeeze(0)
            routed[token_index] += topk_weights[token_index, route_index].to(x.dtype) * expert_output
    return reference + routed


def test_dropless_dispatch_matches_slow_reference():
    torch.manual_seed(5)
    module = DroplessMoEFeedForward(model_width=16,
                                     shared_intermediate=8,
                                     routed_intermediate=12,
                                     num_experts=4,
                                     top_k=2,
                                     router_jitter=0.0)
    x = torch.randn(13, 16)

    output, diagnostics = module(x)
    reference = _slow_reference(module, x, diagnostics["topk_indices"], diagnostics["topk_weights"])
    router_probabilities = torch.softmax(torch.nn.functional.linear(x.float(), module.router.weight.float()), dim=-1)
    reference_indices = torch.topk(router_probabilities, k=module.top_k, dim=-1).indices

    assert torch.equal(diagnostics["topk_indices"], reference_indices)
    assert (output - reference).abs().max().item() < 1e-6


def test_routing_is_top_two_float32_dropless_and_has_finite_gradients():
    torch.manual_seed(17)
    module = DroplessMoEFeedForward(model_width=16,
                                     shared_intermediate=8,
                                     routed_intermediate=12,
                                     num_experts=4,
                                     top_k=2,
                                     router_jitter=0.0)
    x = torch.randn(19, 16, requires_grad=True)

    output, diagnostics = module(x)

    assert diagnostics["router_logits"].dtype == torch.float32
    assert diagnostics["topk_indices"].shape == (19, 2)
    assert torch.allclose(diagnostics["topk_weights"].sum(dim=-1), torch.ones(19), atol=1e-6)
    assert int(diagnostics["expert_load"].sum()) == 19 * 2
    assert diagnostics["dropped_tokens"].item() == 0

    (output.square().mean() + diagnostics["auxiliary_loss"]).backward()
    assert module.router.weight.grad is not None
    assert torch.isfinite(module.router.weight.grad).all()
    for parameter in module.shared_expert.parameters():
        assert parameter.grad is not None
        assert torch.isfinite(parameter.grad).all()
    for expert_index in diagnostics["topk_indices"].unique().tolist():
        for parameter in module.routed_experts[expert_index].parameters():
            assert parameter.grad is not None
            assert torch.isfinite(parameter.grad).all()


def test_router_remains_float32_under_mixed_precision_autocast():
    module = DroplessMoEFeedForward(model_width=16,
                                     shared_intermediate=8,
                                     routed_intermediate=12,
                                     num_experts=4,
                                     top_k=2,
                                     router_jitter=0.0)
    x = torch.randn(9, 16)

    with torch.autocast(device_type="cpu", dtype=torch.bfloat16):
        output, diagnostics = module(x)

    assert diagnostics["router_logits"].dtype == torch.float32
    assert torch.isfinite(output).all()


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA is not available")
def test_sparse_model_runs_mixed_precision_forward_and_backward_on_cuda():
    model = get_model(_config()).cuda()
    data = {
        "x_d": {
            "precipitation": torch.randn(2, 16, 1, device="cuda"),
            "temperature": torch.randn(2, 16, 1, device="cuda"),
        },
        "x_s": torch.randn(2, 2, device="cuda"),
    }

    with torch.autocast(device_type="cuda", dtype=torch.float16):
        output = model(data)
        objective = output["y_hat"].float().square().mean() + output["moe_router_loss"]
    objective.backward()

    assert output["y_hat"].device.type == "cuda"
    assert output["moe_router_loss"].dtype == torch.float32
    moe_layer = model.blocks[1].feed_forward
    assert moe_layer.router.weight.grad is not None
    assert torch.isfinite(moe_layer.router.weight.grad).all()


def test_model_factory_and_router_regularization_are_wired():
    model = get_model(_config())
    data = {
        "x_d": {
            "precipitation": torch.randn(3, 16, 1),
            "temperature": torch.randn(3, 16, 1),
        },
        "x_s": torch.randn(3, 2),
    }

    output = model(data)
    regularizers = get_regularization_obj(_config())
    router_loss = regularizers[0]({}, {}, output)

    assert isinstance(model, ModernCausalTransformer)
    assert output["y_hat"].shape == (3, 16, 1)
    assert output["moe_router_loss"].ndim == 0
    assert output["moe_expert_load"].shape == (1, 8)
    assert len(model.blocks[1].feed_forward.routed_experts) == 8
    assert regularizers[0].name == "moe_router"
    assert regularizers[0].weight == 0.01
    assert torch.equal(router_loss, output["moe_router_loss"])


def test_evaluation_diagnostics_can_be_concatenated_by_save_all_output():
    model = get_model(_config())
    model.eval()
    data = {
        "x_d": {
            "precipitation": torch.randn(3, 16, 1),
            "temperature": torch.randn(3, 16, 1),
        },
        "x_s": torch.randn(3, 2),
    }

    with torch.no_grad():
        outputs = [model(data), model(data)]

    assert outputs[0]["moe_router_loss"].shape == (1, )
    assert outputs[0]["moe_dropped_tokens"].shape == (1, )
    concatenated = {
        key: np.concatenate([output[key].detach().cpu().numpy() for output in outputs], axis=0)
        for key in outputs[0]
    }
    assert concatenated["moe_router_loss"].shape == (2, )
    assert concatenated["moe_dropped_tokens"].shape == (2, )


def test_prediction_and_router_losses_backpropagate_through_training_loss_interface():
    config = _config()
    model = get_model(config)
    data = {
        "x_d": {
            "precipitation": torch.randn(3, 16, 1),
            "temperature": torch.randn(3, 16, 1),
        },
        "x_s": torch.randn(3, 2),
        "y": torch.randn(3, 16, 1),
    }
    loss = get_loss_obj(config)
    loss.set_regularization_terms(get_regularization_obj(config))

    model_output = model(data)
    total_loss, components = loss(model_output, data)
    total_loss.backward()

    assert model_output["moe_router_loss"].ndim == 0
    assert model_output["moe_dropped_tokens"].ndim == 0
    assert total_loss.ndim == 0
    assert set(components) >= {"loss", "moe_router", "total_loss"}
    assert torch.allclose(components["total_loss"], components["loss"] + 0.01 * components["moe_router"])
    moe_layer = model.blocks[1].feed_forward
    assert moe_layer.router.weight.grad is not None
    assert torch.isfinite(moe_layer.router.weight.grad).all()


def test_active_width_must_exactly_match_dense_feed_forward_width():
    invalid = _config(transformer_moe_shared_dim=7)

    try:
        get_model(invalid)
    except ValueError as error:
        assert "active" in str(error).lower()
        assert "32" in str(error)
    else:
        raise AssertionError("A compute-mismatched mixture-of-experts configuration must be rejected.")


def test_parameter_report_distinguishes_total_and_active_parameters():
    dense_values = _config().as_dict().copy()
    dense_values["model"] = "modern_transformer"
    for key in list(dense_values):
        if key.startswith("transformer_moe_"):
            dense_values.pop(key)
    dense_values["regularization"] = []
    dense = get_model(Config(dense_values))
    sparse = get_model(_config())

    dense_counts = dense.parameter_counts()
    sparse_counts = sparse.parameter_counts()

    assert dense_counts["active_feed_forward_width"] == 32
    assert sparse_counts["active_feed_forward_width"] == 32
    assert dense_counts["active_parameters_per_token"] == dense_counts["total_parameters"]
    assert sparse_counts["total_parameters"] > dense_counts["total_parameters"]
    assert sparse_counts["active_parameters_per_token"] < sparse_counts["total_parameters"]
    assert 0.0 < sparse_counts["active_to_total_ratio"] < 1.0


def test_same_seed_dense_and_sparse_models_have_identical_common_non_feed_forward_parameters():
    dense = get_model(_dense_config(seed=100))
    sparse = get_model(_config(seed=100))

    common = _common_non_feed_forward_parameters(dense, sparse)

    assert any(name.startswith("embedding_net.") for name in common)
    assert "input_projection.weight" in common
    assert any(".attention." in name for name in common)
    assert any("_norm.weight" in name for name in common)
    assert any(name.startswith("head.") for name in common)
    for name, (dense_parameter, sparse_parameter) in common.items():
        assert torch.equal(dense_parameter, sparse_parameter), name


def test_named_initialization_changes_with_seed_and_keeps_layers_independent():
    seed_100 = get_model(_dense_config(seed=100))
    seed_101 = get_model(_dense_config(seed=101))

    common = _common_non_feed_forward_parameters(seed_100, seed_101)

    assert any(not torch.equal(first, second) for first, second in common.values())
    assert not torch.equal(seed_100.blocks[0].attention.query_projection.weight,
                           seed_100.blocks[1].attention.query_projection.weight)
