import csv
import json
import math
import os
import pickle
import shutil
from copy import deepcopy
from pathlib import Path

import pytest
import torch
import xarray
from ruamel.yaml import YAML

from neuralhydrology.evaluation.metrics import nse
from neuralhydrology.utils.config import Config
from src.modern_transformer_moe.scripts import audit_configs
from src.modern_transformer_moe.scripts import build_epoch030_metrics_artifact as metrics_builder
from src.modern_transformer_moe.scripts import generate_selected_moe_config as generator


REPO_ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = REPO_ROOT / "src" / "modern_transformer_moe" / "configs"
REGISTRY_PATH = REPO_ROOT / "src" / "modern_transformer_moe" / "registry" / "experiments.csv"


@pytest.fixture(scope="module")
def configs() -> dict[str, dict]:
    return {path.name: audit_configs.load_yaml(path) for path in sorted(CONFIG_DIR.glob("*.yml"))}


def _write_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _write_registry(path: Path, rows: list[dict[str, str]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=audit_configs.REGISTRY_COLUMNS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def _write_yaml(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    yaml = YAML()
    with path.open("w", encoding="utf-8") as stream:
        yaml.dump(value, stream)


def _write_validation_products(run_path: Path, basins: list[str], requested_nse: float) -> float:
    result_dir = run_path / "validation" / "model_epoch030"
    result_dir.mkdir(parents=True, exist_ok=True)
    observed_values = [[0.0], [1.0], [2.0], [3.0]]
    error = math.sqrt((1.0 - requested_nse) * 5.0 / 4.0)
    simulated_values = [[value[0] + error] for value in observed_values]
    dataset = xarray.Dataset({
        "QObs(mm/d)_obs": (("date", "time_step"), observed_values),
        "QObs(mm/d)_sim": (("date", "time_step"), simulated_values),
    })
    stacked = dataset.stack(datetime=["date", "time_step"])
    measured_nse = nse(stacked["QObs(mm/d)_obs"], stacked["QObs(mm/d)_sim"])
    results = {basin: {"1D": {"xr": dataset, "NSE": measured_nse}} for basin in basins}
    with (result_dir / "validation_results.p").open("wb") as stream:
        pickle.dump(results, stream)

    with (result_dir / "validation_metrics.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=["basin", "NSE"], lineterminator="\n")
        writer.writeheader()
        for basin in basins:
            writer.writerow({"basin": basin, "NSE": measured_nse})
    return measured_nse


def _copy_task4_repository(tmp_path: Path) -> Path:
    temporary_root = tmp_path / "repository"
    idea_source = REPO_ROOT / "src" / "modern_transformer_moe"
    idea_destination = temporary_root / "src" / "modern_transformer_moe"
    idea_destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(idea_source, idea_destination)
    basin_destination = temporary_root / audit_configs.BASIN_FILE
    basin_destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(REPO_ROOT / audit_configs.BASIN_FILE, basin_destination)
    return temporary_root


def _complete_dense_candidates(
    temporary_root: Path, medians: dict[str, float] | None = None
) -> tuple[Path, dict]:
    medians = medians or {"D01": 0.70, "D02": 0.72, "D03": 0.71}
    basin_path = temporary_root / audit_configs.BASIN_FILE
    basins = [line.strip() for line in basin_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    rows = audit_configs.load_registry(
        temporary_root / "src" / "modern_transformer_moe" / "registry" / "experiments.csv"
    )
    rows_by_id = {row["exp_id"]: row for row in rows}
    candidate_metrics = []

    for experiment_id in ["D01", "D02", "D03"]:
        config_relative = audit_configs.DENSE_CONFIG_BY_ID[experiment_id]
        config_path = temporary_root / config_relative
        source_config = audit_configs.load_yaml(config_path)
        run_name = f"{source_config['experiment_name']}_2026_0826_1200_ep30"
        run_relative = f"results/30_modern_transformer_moe/{experiment_id}/{run_name}"
        run_path = temporary_root / run_relative
        run_path.mkdir(parents=True, exist_ok=True)
        run_config = deepcopy(source_config)
        run_config.update({
            "run_dir": run_relative,
            "train_dir": f"{run_relative}/train_data",
            "img_log_dir": f"{run_relative}/img_log",
            "commit_hash": "test-commit",
            "package_version": "test-version",
        })
        _write_yaml(run_path / "config.yml", run_config)

        checkpoint_relative = f"{run_relative}/model_epoch030.pt"
        checkpoint_path = temporary_root / checkpoint_relative
        torch.save({"synthetic_weight": torch.tensor([float(len(candidate_metrics))])}, checkpoint_path)

        _write_validation_products(run_path, basins, medians[experiment_id])
        metrics_path = metrics_builder.build(experiment_id, run_path, temporary_root)
        metrics_relative = metrics_path.relative_to(temporary_root).as_posix()
        artifact = audit_configs.load_json(metrics_path)
        metrics_sha256 = audit_configs.sha256_file(metrics_path)
        candidate_metrics.append({
            "experiment_id": experiment_id,
            "median_nse": artifact["median_nse"],
            "metrics_artifact_path": metrics_relative,
            "metrics_artifact_sha256": metrics_sha256,
        })
        rows_by_id[experiment_id].update({
            "status": "development_complete",
            "best_checkpoint": checkpoint_relative,
            "checkpoint_sha256": artifact["checkpoint_sha256"],
            "metrics_path": metrics_relative,
            "metrics_sha256": metrics_sha256,
        })

    registry_path = temporary_root / "src" / "modern_transformer_moe" / "registry" / "experiments.csv"
    _write_registry(registry_path, rows)

    order = {experiment_id: index for index, experiment_id in enumerate(["D01", "D02", "D03"])}
    measured_medians = {item["experiment_id"]: item["median_nse"] for item in candidate_metrics}
    selected_id = max(
        measured_medians,
        key=lambda experiment_id: (measured_medians[experiment_id], -order[experiment_id]),
    )
    selected_config_relative = audit_configs.DENSE_CONFIG_BY_ID[selected_id]
    report = {
        "candidate_experiment_ids": ["D01", "D02", "D03"],
        "candidate_metrics": candidate_metrics,
        "selected_experiment_id": selected_id,
        "selected_config_path": selected_config_relative,
        "selected_config_sha256": audit_configs.sha256_file(temporary_root / selected_config_relative),
        "selection_metric": "median_NSE",
        "selection_epoch": 30,
        "selection_period": {"start": "2006-10-01", "end": "2008-09-30"},
        "selection_rule": audit_configs.SELECTION_RULE,
    }
    report_path = temporary_root / "results" / "30_modern_transformer_moe" / "dense_selection_report.json"
    _write_json(report_path, report)
    return report_path, report


def _candidate_artifact(temporary_root: Path, report: dict, experiment_id: str) -> tuple[Path, dict]:
    record = next(item for item in report["candidate_metrics"] if item["experiment_id"] == experiment_id)
    path = temporary_root / record["metrics_artifact_path"]
    return path, audit_configs.load_json(path)


def _rewrite_artifact_and_registry(
    temporary_root: Path, experiment_id: str, artifact_path: Path, artifact: dict
) -> None:
    _write_json(artifact_path, artifact)
    registry_path = temporary_root / "src" / "modern_transformer_moe" / "registry" / "experiments.csv"
    rows = audit_configs.load_registry(registry_path)
    row = next(item for item in rows if item["exp_id"] == experiment_id)
    row["metrics_sha256"] = audit_configs.sha256_file(artifact_path)
    _write_registry(registry_path, rows)


def test_all_runnable_configs_use_the_strict_neuralhydrology_config_interface() -> None:
    for path in sorted(CONFIG_DIR.glob("*.yml")):
        config = Config(path)
        assert config.number_of_basins == 531


def test_all_present_configs_satisfy_the_development_information_contract(configs: dict[str, dict]) -> None:
    mandatory = {audit_configs.BASE_CONFIG_FILE, *audit_configs.RUN_CONFIG_FILES}
    assert mandatory.issubset(configs)
    assert set(configs).issubset(mandatory | {audit_configs.OPTIONAL_SPARSE_CONFIG_FILE})
    for filename, config in configs.items():
        assert audit_configs.audit_common_contract(config, filename, REPO_ROOT) == []
        assert len(config["dynamic_inputs"]) == 5
        assert len(config["static_attributes"]) == 27
        assert not (set(config) & audit_configs.FORBIDDEN_CONFIG_KEYS)


def test_model_families_capacity_and_optimization_recipes_are_frozen(configs: dict[str, dict]) -> None:
    baseline = configs["baseline_lstm_s100.yml"]
    assert baseline["model"] == "cudalstm"
    assert baseline["hidden_size"] == 256
    assert baseline["initial_forget_bias"] == 5
    assert baseline["output_dropout"] == 0.4
    assert baseline["optimizer"] == "Adam"
    assert baseline["batch_size"] == 256
    assert baseline["learning_rate"] == {0: 1e-3, 11: 5e-4, 21: 1e-4}

    expected_dense = {
        "dense_d128_l4_s100.yml": (128, 4, 4, 512),
        "dense_d256_l4_s100.yml": (256, 4, 8, 1024),
        "dense_d256_l8_s100.yml": (256, 8, 8, 1024),
    }
    for filename, (width, layers, heads, intermediate) in expected_dense.items():
        config = configs[filename]
        assert config["model"] == "modern_transformer"
        assert audit_configs.embedding_width(config) == width
        assert config["transformer_nlayers"] == layers
        assert config["transformer_nheads"] == heads
        assert width // heads == 32
        assert config["transformer_dim_feedforward"] == intermediate
        assert config["optimizer"] == "AdamW"
        assert config["learning_rate"] == {0: 3e-4, 11: 1e-4, 21: 3e-5}
        assert config["batch_size"] == 64
        assert config["output_dropout"] == 0.0
        assert config["save_all_output"] is False


def test_current_repository_m01_materialization_matches_its_registry_state() -> None:
    rows = audit_configs.load_registry(REGISTRY_PATH)
    m01 = next(row for row in rows if row["exp_id"] == "M01")
    m01_path = CONFIG_DIR / audit_configs.OPTIONAL_SPARSE_CONFIG_FILE
    if m01["status"] == "awaiting_dense_selection":
        assert not m01_path.exists()
        assert m01["config_path"] == "not_generated"
        assert m01["source_config_path"] == "not_selected"
        assert m01["selection_report_path"] == "not_available"
    else:
        assert m01["status"] == "planned"
        assert m01_path.is_file()
    assert audit_configs.audit_registry(rows, REPO_ROOT) == []


@pytest.mark.parametrize(
    ("selected_id", "filename", "expected_shared", "expected_routed"),
    [
        ("D01", "dense_d128_l4_s100.yml", 128, 192),
        ("D02", "dense_d256_l4_s100.yml", 256, 384),
        ("D03", "dense_d256_l8_s100.yml", 256, 384),
    ],
)
def test_generator_builds_an_exact_combined_treatment_pair_for_any_dense_winner(
    configs: dict[str, dict], selected_id: str, filename: str, expected_shared: int, expected_routed: int
) -> None:
    dense = configs[filename]
    sparse = generator.build_sparse_config(dense, selected_id)

    assert audit_configs.audit_dense_sparse_pair(dense, sparse) == []
    Config(sparse)
    assert sparse["model"] == "modern_transformer_moe"
    assert sparse["transformer_moe_num_experts"] == 8
    assert sparse["transformer_moe_top_k"] == 2
    assert sparse["transformer_moe_first_layer"] == 2
    assert sparse["transformer_moe_shared_dim"] == expected_shared
    assert sparse["transformer_moe_routed_dim"] == expected_routed
    assert expected_shared + 2 * expected_routed == sparse["transformer_dim_feedforward"]
    assert sparse["batch_size"] == dense["batch_size"]
    assert sparse["learning_rate"] == dense["learning_rate"]
    assert sparse["regularization"] == [["moe_router", 0.01]]


def test_selection_report_recomputes_all_metrics_and_rejects_a_forged_winner(tmp_path: Path) -> None:
    temporary_root = _copy_task4_repository(tmp_path)
    _, report = _complete_dense_candidates(temporary_root)
    assert audit_configs.audit_selection_report(report, temporary_root) == []

    forged = deepcopy(report)
    forged["selected_experiment_id"] = "D03"
    forged["selected_config_path"] = audit_configs.DENSE_CONFIG_BY_ID["D03"]
    forged["selected_config_sha256"] = audit_configs.sha256_file(
        temporary_root / audit_configs.DENSE_CONFIG_BY_ID["D03"]
    )
    issues = audit_configs.audit_selection_report(forged, temporary_root)
    assert any("recomputed epoch-30 winner" in issue for issue in issues)

    forged_value = deepcopy(report)
    forged_value["candidate_metrics"][0]["median_nse"] += 0.1
    issues = audit_configs.audit_selection_report(forged_value, temporary_root)
    assert any("does not match the metrics artifact" in issue for issue in issues)


def test_metrics_builder_binds_and_recomputes_every_epoch30_run_product(tmp_path: Path) -> None:
    temporary_root = _copy_task4_repository(tmp_path)
    _, report = _complete_dense_candidates(temporary_root)
    artifact_path, artifact = _candidate_artifact(temporary_root, report, "D01")

    assert set(artifact) == audit_configs.METRICS_ARTIFACT_REQUIRED_KEYS
    for prefix in (
        "source_config",
        "run_config",
        "checkpoint",
        "validation_metrics",
        "validation_results",
    ):
        bound_path = temporary_root / artifact[f"{prefix}_path"]
        assert bound_path.is_file()
        assert artifact[f"{prefix}_sha256"] == audit_configs.sha256_file(bound_path)
    assert audit_configs.audit_metrics_artifact(
        artifact, "D01", temporary_root, artifact_path=artifact_path
    )[0] == []


def test_validation_csv_requires_exact_531_basin_finite_nse_schema(tmp_path: Path) -> None:
    temporary_root = _copy_task4_repository(tmp_path)
    basins = [
        line.strip()
        for line in (temporary_root / audit_configs.BASIN_FILE).read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    metrics_path = temporary_root / "validation_metrics.csv"
    metrics_path.write_text("basin,NSE,RMSE\n", encoding="utf-8")
    with pytest.raises(ValueError, match="columns must be exactly"):
        audit_configs.load_validation_nse_csv(metrics_path, temporary_root)

    with metrics_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(["basin", "NSE"])
        writer.writerows((basin, 0.5) for basin in basins[:-1])
    with pytest.raises(ValueError, match="530 rows, expected 531"):
        audit_configs.load_validation_nse_csv(metrics_path, temporary_root)

    with metrics_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(["basin", "NSE"])
        writer.writerows((basin, "nan" if index == 0 else 0.5) for index, basin in enumerate(basins))
    with pytest.raises(ValueError, match="non-finite NSE"):
        audit_configs.load_validation_nse_csv(metrics_path, temporary_root)


def test_audit_rejects_forged_json_even_after_its_registry_hash_is_refreshed(tmp_path: Path) -> None:
    temporary_root = _copy_task4_repository(tmp_path)
    _, report = _complete_dense_candidates(temporary_root)
    artifact_path, artifact = _candidate_artifact(temporary_root, report, "D01")
    artifact["basin_nse"] = {basin: value + 0.1 for basin, value in artifact["basin_nse"].items()}
    artifact["median_nse"] += 0.1
    _rewrite_artifact_and_registry(temporary_root, "D01", artifact_path, artifact)

    issues = audit_configs.audit_repository(temporary_root)
    assert any("basin_nse disagrees with the bound validation CSV" in issue for issue in issues)
    assert any("median_nse does not equal" in issue for issue in issues)


def test_audit_rejects_csv_tampering_even_after_bound_hashes_are_refreshed(tmp_path: Path) -> None:
    temporary_root = _copy_task4_repository(tmp_path)
    _, report = _complete_dense_candidates(temporary_root)
    artifact_path, artifact = _candidate_artifact(temporary_root, report, "D01")
    csv_path = temporary_root / artifact["validation_metrics_path"]
    with csv_path.open("r", encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    rows[0]["NSE"] = str(float(rows[0]["NSE"]) + 0.1)
    with csv_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=["basin", "NSE"], lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    artifact["validation_metrics_sha256"] = audit_configs.sha256_file(csv_path)
    _rewrite_artifact_and_registry(temporary_root, "D01", artifact_path, artifact)

    issues = audit_configs.audit_repository(temporary_root)
    assert any("validation CSV disagrees with NSE recomputed from y_obs/y_sim" in issue for issue in issues)


def test_audit_rejects_validation_prediction_pickle_tampering_with_refreshed_hashes(tmp_path: Path) -> None:
    temporary_root = _copy_task4_repository(tmp_path)
    _, report = _complete_dense_candidates(temporary_root)
    artifact_path, artifact = _candidate_artifact(temporary_root, report, "D01")
    results_path = temporary_root / artifact["validation_results_path"]
    with results_path.open("rb") as stream:
        results = pickle.load(stream)
    basin = next(iter(results))
    frequency_results = next(iter(results[basin].values()))
    dataset = frequency_results["xr"].copy(deep=True)
    dataset["QObs(mm/d)_sim"] = dataset["QObs(mm/d)_sim"] + 0.2
    stacked = dataset.stack(datetime=["date", "time_step"])
    frequency_results["xr"] = dataset
    frequency_results["NSE"] = nse(stacked["QObs(mm/d)_obs"], stacked["QObs(mm/d)_sim"])
    with results_path.open("wb") as stream:
        pickle.dump(results, stream)
    artifact["validation_results_sha256"] = audit_configs.sha256_file(results_path)
    _rewrite_artifact_and_registry(temporary_root, "D01", artifact_path, artifact)

    issues = audit_configs.audit_repository(temporary_root)
    assert any("validation CSV disagrees with NSE recomputed from y_obs/y_sim" in issue for issue in issues)


def test_audit_rejects_checkpoint_tampering(tmp_path: Path) -> None:
    temporary_root = _copy_task4_repository(tmp_path)
    _, report = _complete_dense_candidates(temporary_root)
    _, artifact = _candidate_artifact(temporary_root, report, "D01")
    checkpoint_path = temporary_root / artifact["checkpoint_path"]
    checkpoint_path.write_bytes(checkpoint_path.read_bytes() + b"tampered")

    issues = audit_configs.audit_repository(temporary_root)
    assert any("checkpoint SHA-256 mismatch" in issue for issue in issues)
    assert any("checkpoint_sha256 does not match" in issue for issue in issues)


def test_audit_rejects_run_config_scientific_drift_with_refreshed_hashes(tmp_path: Path) -> None:
    temporary_root = _copy_task4_repository(tmp_path)
    _, report = _complete_dense_candidates(temporary_root)
    artifact_path, artifact = _candidate_artifact(temporary_root, report, "D01")
    run_config_path = temporary_root / artifact["run_config_path"]
    run_config = audit_configs.load_yaml(run_config_path)
    run_config["seq_length"] = 271
    _write_yaml(run_config_path, run_config)
    artifact["run_config_sha256"] = audit_configs.sha256_file(run_config_path)
    _rewrite_artifact_and_registry(temporary_root, "D01", artifact_path, artifact)

    issues = audit_configs.audit_repository(temporary_root)
    assert any("run config scientific field seq_length drifted" in issue for issue in issues)


def test_selection_report_uses_preregistered_smaller_model_tie_break(tmp_path: Path) -> None:
    temporary_root = _copy_task4_repository(tmp_path)
    _, report = _complete_dense_candidates(temporary_root, {"D01": 0.7, "D02": 0.7, "D03": 0.7})
    assert report["selected_experiment_id"] == "D01"
    assert audit_configs.audit_selection_report(report, temporary_root) == []

    report["selected_experiment_id"] = "D02"
    report["selected_config_path"] = audit_configs.DENSE_CONFIG_BY_ID["D02"]
    report["selected_config_sha256"] = audit_configs.sha256_file(
        temporary_root / audit_configs.DENSE_CONFIG_BY_ID["D02"]
    )
    assert any("winner" in issue for issue in audit_configs.audit_selection_report(report, temporary_root))


def test_postselection_generation_and_repository_audit_are_valid(tmp_path: Path) -> None:
    temporary_root = _copy_task4_repository(tmp_path)
    report_path, report = _complete_dense_candidates(temporary_root)

    assert audit_configs.audit_repository(temporary_root) == []
    output_path = generator.generate(report_path, temporary_root)

    assert output_path.is_file()
    rows = audit_configs.load_registry(
        temporary_root / "src" / "modern_transformer_moe" / "registry" / "experiments.csv"
    )
    m01 = next(row for row in rows if row["exp_id"] == "M01")
    assert m01["status"] == "planned"
    assert m01["source_config_path"] == report["selected_config_path"]
    assert m01["source_config_sha256"] == report["selected_config_sha256"]
    assert audit_configs.audit_repository(temporary_root) == []


def test_generator_rolls_back_second_replace_failure_and_can_be_rerun(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    temporary_root = _copy_task4_repository(tmp_path)
    report_path, _ = _complete_dense_candidates(temporary_root)
    registry_path = temporary_root / "src" / "modern_transformer_moe" / "registry" / "experiments.csv"
    original_registry = registry_path.read_bytes()
    output_path = temporary_root / generator.M01_CONFIG_RELATIVE_PATH
    lock_path = temporary_root / generator.LOCK_RELATIVE_PATH

    real_replace = os.replace
    call_count = 0

    def fail_second_replace(source: Path, destination: Path) -> None:
        nonlocal call_count
        call_count += 1
        if call_count == 2:
            raise OSError("injected registry replacement failure")
        real_replace(source, destination)

    monkeypatch.setattr(generator.os, "replace", fail_second_replace)
    with pytest.raises(OSError, match="injected registry replacement failure"):
        generator.generate(report_path, temporary_root)

    assert registry_path.read_bytes() == original_registry
    assert not output_path.exists()
    assert not lock_path.exists()
    assert audit_configs.audit_repository(temporary_root) == []

    generated = generator.generate(report_path, temporary_root)
    assert generated.is_file()
    assert audit_configs.audit_repository(temporary_root) == []


def test_audit_rejects_forbidden_attribute_and_evaluation_period(configs: dict[str, dict]) -> None:
    invalid = deepcopy(configs["dense_d128_l4_s100.yml"])
    invalid["static_attributes"] = [*invalid["static_attributes"], "runoff_ratio"]
    invalid["test_start_date"] = "01/10/1989"

    issues = audit_configs.audit_common_contract(invalid, "invalid.yml", REPO_ROOT)

    assert any("static_attributes" in issue for issue in issues)
    assert any("test_start_date" in issue for issue in issues)


def test_audit_rejects_dense_sparse_attention_drift(configs: dict[str, dict]) -> None:
    dense = configs["dense_d256_l8_s100.yml"]
    drifted = generator.build_sparse_config(dense, "D03")
    drifted["transformer_nheads"] = 4

    issues = audit_configs.audit_dense_sparse_pair(dense, drifted)

    assert any("transformer_nheads" in issue for issue in issues)


def test_executable_static_audit_passes_in_current_preselection_state() -> None:
    assert audit_configs.audit_repository(REPO_ROOT) == []
