from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import pytest
import torch
import xarray
from ruamel.yaml import YAML

from neuralhydrology.modelzoo.modern_causal_transformer import DroplessMoEFeedForward
from src.modern_transformer_moe.scripts import audit_configs
from src.modern_transformer_moe.scripts import build_router_diagnostics
from src.modern_transformer_moe.scripts import compare_development
from src.modern_transformer_moe.scripts import generate_selected_moe_config


REPO_ROOT = Path(__file__).resolve().parents[1]


class ToyRouterModel(torch.nn.Module):
    def __init__(self, num_layers: int = 2):
        super().__init__()
        self.layers = torch.nn.ModuleList([
            DroplessMoEFeedForward(
                model_width=4,
                shared_intermediate=4,
                routed_intermediate=4,
                num_experts=8,
                top_k=2,
                router_jitter=0.0,
                dropout=0.0,
            )
            for _ in range(num_layers)
        ])

    def route(self, batches: list[torch.Tensor]) -> None:
        self.eval()
        with torch.no_grad():
            for batch in batches:
                for layer in self.layers:
                    layer(batch)


class FakeValidationTester:
    def __init__(self, model: ToyRouterModel, batches: list[torch.Tensor], results: dict[str, Any]):
        self.model = model
        self._batches = batches
        self._results = results
        self.calls: list[dict[str, Any]] = []

    def evaluate(self, **kwargs: Any) -> dict:
        self.calls.append(kwargs)
        self.model.route(self._batches)
        return self._results


def _write_yaml(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    yaml = YAML()
    with path.open("w", encoding="utf-8") as stream:
        yaml.dump(value, stream)


def _completed_m01_run(tmp_path: Path) -> tuple[Path, Path, Path]:
    repo_root = tmp_path / "repo"
    basin_path = repo_root / audit_configs.BASIN_FILE
    basin_path.parent.mkdir(parents=True, exist_ok=True)
    basin_path.write_bytes((REPO_ROOT / audit_configs.BASIN_FILE).read_bytes())

    dense = audit_configs.load_yaml(REPO_ROOT / audit_configs.DENSE_CONFIG_BY_ID["D02"])
    config = generate_selected_moe_config.build_sparse_config(dense, "D02")
    run_relative = "results/30_modern_transformer_moe/M01/actual"
    config.update({
        "run_dir": run_relative,
        "train_dir": f"{run_relative}/train_data",
        "img_log_dir": f"{run_relative}/img_log",
        "commit_hash": "synthetic",
        "package_version": "synthetic",
    })
    run_dir = repo_root / run_relative
    run_dir.mkdir(parents=True)
    config_path = run_dir / "config.yml"
    _write_yaml(config_path, config)
    checkpoint_path = run_dir / "model_epoch030.pt"
    checkpoint_path.write_bytes(b"synthetic M01 epoch-30 checkpoint")
    scaler_path = run_dir / "train_data" / "train_data_scaler.yml"
    scaler_path.parent.mkdir(parents=True)
    scaler_path.write_bytes(b"synthetic training scaler")
    validation_dir = run_dir / "validation" / "model_epoch030"
    validation_dir.mkdir(parents=True)
    (validation_dir / "validation_metrics.csv").write_bytes(b"existing internal-validation metric marker")
    (validation_dir / "validation_results.p").write_bytes(b"existing internal-validation result marker")
    return repo_root, run_dir, config_path


def _complete_validation_results(repo_root: Path) -> dict[str, Any]:
    basins = [
        line.strip()
        for line in (repo_root / audit_configs.BASIN_FILE).read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    dates = np.arange(np.datetime64("2006-10-01"), np.datetime64("2008-10-01"), dtype="datetime64[D]")
    dataset = xarray.Dataset(coords={"date": dates})
    return {basin: {"1D": {"xr": dataset}} for basin in basins}


def test_collect_expert_token_counts_matches_actual_moe_diagnostics() -> None:
    torch.manual_seed(7)
    model = ToyRouterModel()
    batches = [torch.randn(2, 3, 4), torch.randn(1, 3, 4)]
    expected = [torch.zeros(8, dtype=torch.long) for _layer in model.layers]
    model.eval()
    with torch.no_grad():
        for batch in batches:
            for layer_index, layer in enumerate(model.layers):
                _, diagnostics = layer(batch)
                expected[layer_index] += diagnostics["expert_load"].cpu()

    accounting, evaluation_result = build_router_diagnostics.collect_expert_token_counts(
        model,
        lambda: (model.route(batches), "validation result")[1],
        expected_num_experts=8,
        expected_top_k=2,
        expected_module_count=2,
    )

    assert [layer.layer_id for layer in accounting.layers] == ["layers.0", "layers.1"]
    assert [layer.expert_token_counts for layer in accounting.layers] == [
        counts.tolist() for counts in expected
    ]
    assert all(layer.validation_token_count == 9 for layer in accounting.layers)
    assert all(layer.dropped_token_count == 0 for layer in accounting.layers)
    assert accounting.validation_token_count == 9
    assert accounting.total_routed_assignments == 36
    assert accounting.dropped_token_count == 0
    assert evaluation_result == "validation result"


def test_generate_writes_compare_schema_and_refuses_overwrite(tmp_path: Path) -> None:
    repo_root, run_dir, _ = _completed_m01_run(tmp_path)
    batches = [torch.randn(2, 3, 4), torch.randn(1, 3, 4)]
    tester = FakeValidationTester(ToyRouterModel(), batches, _complete_validation_results(repo_root))

    def factory(**kwargs: Any) -> FakeValidationTester:
        assert kwargs["period"] == "validation"
        assert kwargs["run_dir"] == run_dir
        assert kwargs["init_model"] is True
        return tester

    output_path = build_router_diagnostics.generate(run_dir, repo_root=repo_root, tester_factory=factory)
    value = json.loads(output_path.read_text(encoding="utf-8"))

    assert build_router_diagnostics.ROUTER_DIAGNOSTIC_REQUIRED_KEYS == (
        compare_development.ROUTER_DIAGNOSTIC_REQUIRED_KEYS
    )
    assert build_router_diagnostics.ROUTER_LAYER_REQUIRED_KEYS == compare_development.ROUTER_LAYER_REQUIRED_KEYS
    assert set(value) == build_router_diagnostics.ROUTER_DIAGNOSTIC_REQUIRED_KEYS
    assert value["schema_version"] == 2
    assert value["seed"] == 100
    assert value["period"] == audit_configs.SELECTION_PERIOD
    checkpoint_path = run_dir / "model_epoch030.pt"
    assert value["checkpoint_path"] == checkpoint_path.relative_to(repo_root).as_posix()
    assert value["checkpoint_sha256"] == audit_configs.sha256_file(checkpoint_path)
    for prefix, bound_path in {
        "run_config": run_dir / "config.yml",
        "scaler": run_dir / "train_data/train_data_scaler.yml",
        "basin_file": repo_root / audit_configs.BASIN_FILE,
    }.items():
        assert value[f"{prefix}_path"] == bound_path.relative_to(repo_root).as_posix()
        assert value[f"{prefix}_sha256"] == audit_configs.sha256_file(bound_path)
    assert value["basin_count"] == 531
    assert value["validation_start_date"] == "2006-10-01"
    assert value["validation_end_date"] == "2008-09-30"
    assert value["validation_day_count"] == 731
    assert value["validation_token_count"] == 9
    assert value["top_k"] == 2
    assert value["moe_layer_count"] == 2
    assert value["total_routed_assignments"] == 36
    assert value["dropped_token_count"] == 0
    assert [layer["layer_id"] for layer in value["layers"]] == ["layers.0", "layers.1"]
    for layer in value["layers"]:
        assert set(layer) == build_router_diagnostics.ROUTER_LAYER_REQUIRED_KEYS
        assert layer["validation_token_count"] == 9
        assert layer["dropped_token_count"] == 0
        assert len(layer["expert_token_counts"]) == 8
        assert sum(layer["expert_token_counts"]) == 18
    assert tester.calls == [{
        "epoch": 30, "save_results": False, "save_all_output": False, "metrics": []
    }]
    with pytest.raises(FileExistsError, match="refusing to overwrite"):
        build_router_diagnostics.generate(run_dir, repo_root=repo_root, tester_factory=factory)


@pytest.mark.parametrize(
    ("key", "value", "message"),
    [
        ("validation_start_date", "01/10/1989", "forbidden value fragment"),
        ("dynamic_inputs", [*audit_configs.ALLOWED_DYNAMIC_INPUTS, "QObs(mm/d)"], "dynamic_inputs"),
    ],
)
def test_generate_rejects_wrong_period_or_forbidden_model_input_before_inference(
    tmp_path: Path, key: str, value: Any, message: str
) -> None:
    repo_root, run_dir, config_path = _completed_m01_run(tmp_path)
    config = audit_configs.load_yaml(config_path)
    config[key] = value
    _write_yaml(config_path, config)

    def fail_factory(**_kwargs: Any) -> Any:
        raise AssertionError("validation inference started before the safety audit passed")

    with pytest.raises(ValueError, match=message):
        build_router_diagnostics.generate(run_dir, repo_root=repo_root, tester_factory=fail_factory)


def test_collect_rejects_missing_routed_layer_before_evaluation() -> None:
    model = ToyRouterModel(num_layers=1)
    with pytest.raises(ValueError, match="1 routed feed-forward layers, expected 2"):
        build_router_diagnostics.collect_expert_token_counts(
            model,
            lambda: pytest.fail("evaluation should not start"),
            expected_num_experts=8,
            expected_top_k=2,
            expected_module_count=2,
        )


def test_generate_rejects_incomplete_basin_or_date_coverage(tmp_path: Path) -> None:
    repo_root, run_dir, _ = _completed_m01_run(tmp_path)
    results = _complete_validation_results(repo_root)
    results.pop(next(iter(results)))
    tester = FakeValidationTester(ToyRouterModel(), [torch.randn(1, 2, 4)], results)

    with pytest.raises(ValueError, match="exactly the frozen 531 basins"):
        build_router_diagnostics.generate(
            run_dir, repo_root=repo_root, tester_factory=lambda **_kwargs: tester
        )


def test_generate_rejects_incomplete_daily_coverage(tmp_path: Path) -> None:
    repo_root, run_dir, _ = _completed_m01_run(tmp_path)
    results = _complete_validation_results(repo_root)
    basin = next(iter(results))
    results[basin] = {"1D": {"xr": results[basin]["1D"]["xr"].isel(date=slice(1, None))}}
    tester = FakeValidationTester(ToyRouterModel(), [torch.randn(1, 2, 4)], results)

    with pytest.raises(ValueError, match="complete daily 2006-10-01 through 2008-09-30"):
        build_router_diagnostics.generate(
            run_dir, repo_root=repo_root, tester_factory=lambda **_kwargs: tester
        )


def test_collect_rejects_any_reported_dropped_token() -> None:
    model = ToyRouterModel(num_layers=1)
    original_forward = model.layers[0].forward

    def forward_with_drop(x: torch.Tensor) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
        output, diagnostics = original_forward(x)
        diagnostics["dropped_tokens"] = torch.ones((), dtype=torch.long)
        return output, diagnostics

    model.layers[0].forward = forward_with_drop
    with pytest.raises(ValueError, match="reported 1 dropped token"):
        build_router_diagnostics.collect_expert_token_counts(
            model,
            lambda: model.route([torch.randn(1, 2, 4)]),
            expected_num_experts=8,
            expected_top_k=2,
            expected_module_count=1,
        )
