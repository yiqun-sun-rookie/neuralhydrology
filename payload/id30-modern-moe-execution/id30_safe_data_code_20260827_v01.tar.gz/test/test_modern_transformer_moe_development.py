from __future__ import annotations

import csv
import json
import math
import pickle
import shutil
from pathlib import Path

import pytest
import torch
import xarray
from ruamel.yaml import YAML

from neuralhydrology.evaluation.metrics import nse
from src.modern_transformer_moe.scripts import audit_configs
from src.modern_transformer_moe.scripts import compare_development
from src.modern_transformer_moe.scripts import run_development


REPO_ROOT = Path(__file__).resolve().parents[1]


def _write_yaml(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    yaml = YAML()
    with path.open("w", encoding="utf-8") as stream:
        yaml.dump(value, stream)


def _copy_contract_repository(tmp_path: Path) -> Path:
    root = tmp_path / "repo"
    destination = root / "src/modern_transformer_moe"
    destination.parent.mkdir(parents=True)
    shutil.copytree(REPO_ROOT / "src/modern_transformer_moe", destination)
    basin_path = root / audit_configs.BASIN_FILE
    basin_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(REPO_ROOT / audit_configs.BASIN_FILE, basin_path)
    return root


def test_runner_is_dry_by_default_and_spawns_no_process(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(run_development.subprocess, "run", lambda *args, **kwargs: pytest.fail("spawned process"))
    plan = run_development.plan_development("D01", repo_root=REPO_ROOT)
    assert plan["mode"] == "DRY_RUN"
    assert plan["budget"]["epochs"] == 30
    assert plan["execution_requirements"] == ["--execute", "--operator-approved-heavy-compute"]


def test_runner_rejects_execution_without_operator_approval(tmp_path: Path) -> None:
    with pytest.raises(PermissionError, match="operator-approved-heavy-compute"):
        run_development.execute_development(
            "D01", "not_approved", operator_approved_heavy_compute=False, repo_root=tmp_path
        )


def test_runner_rejects_existing_invocation_before_spawning(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root = _copy_contract_repository(tmp_path)
    conflict = root / run_development.INVOCATIONS_RELATIVE_ROOT / "conflict"
    conflict.mkdir(parents=True)
    monkeypatch.setattr(run_development.subprocess, "run", lambda *args, **kwargs: pytest.fail("spawned process"))
    with pytest.raises(FileExistsError, match="overwrite"):
        run_development.execute_development(
            "D01", "conflict", operator_approved_heavy_compute=True, repo_root=root
        )


def test_retry_cli_requires_explicit_new_run_id(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(run_development.sys, "argv", [
        "run_development",
        "D01",
        "--retry-failed-run-id",
        "failed_attempt",
        "--execute",
        "--operator-approved-heavy-compute",
    ])
    monkeypatch.setattr(run_development.subprocess, "run", lambda *args, **kwargs: pytest.fail("spawned process"))
    with pytest.raises(ValueError, match="explicit new --run-id"):
        run_development.main()


def _source_config(role: str, seed: int, run_root: str) -> dict:
    model = "cudalstm" if role == "B01" else "modern_transformer_moe" if role == "M01" else "modern_transformer"
    config = {
        "experiment_name": f"{role}_{seed}",
        "run_dir": run_root,
        "dataset": "camels_us_track0_bundle",
        "data_dir": "data/camels_us_track0_development_forcing_v01",
        "track0_supervision_dir": "data/camels_us_track0_supervision_v01",
        "number_of_basins": 531,
        "train_basin_file": audit_configs.BASIN_FILE,
        "validation_basin_file": audit_configs.BASIN_FILE,
        "train_start_date": "01/10/1999",
        "train_end_date": "30/09/2006",
        "validation_start_date": "01/10/2006",
        "validation_end_date": "30/09/2008",
        "model": model,
        "epochs": 30,
        "seq_length": 270,
        "seed": seed,
    }
    if role != "B01":
        width, layers = compare_development.EXPECTED_ARCHITECTURE.get(role, (256, 4))
        config.update({
            "dynamics_embedding": {"hiddens": [width // 2]},
            "statics_embedding": {"hiddens": [width // 2]},
            "transformer_nheads": 8,
            "transformer_nlayers": layers,
            "transformer_dim_feedforward": 1024,
        })
    if role == "M01":
        config.update({
            "transformer_moe_num_experts": 8,
            "transformer_moe_top_k": 2,
            "transformer_moe_first_layer": 2,
            "transformer_moe_shared_dim": 256,
            "transformer_moe_routed_dim": 384,
            "transformer_moe_router_jitter": 0.0,
            "regularization": [["moe_router", 0.01]],
        })
    return config


def _write_artifact(
    root: Path, role: str, seed: int, requested_nse: float, *, source_path: Path | None = None
) -> Path:
    run_root_relative = f"runs/{role}_{seed}"
    if source_path is not None:
        source = audit_configs.load_yaml(source_path)
        run_root_relative = str(source["run_dir"])
    run_relative = f"{run_root_relative}/actual"
    run_dir = root / run_relative
    result_dir = run_dir / "validation/model_epoch030"
    result_dir.mkdir(parents=True)
    if source_path is None:
        source_path = root / f"configs/{role}_{seed}.yml"
        source = _source_config(role, seed, run_root_relative)
        _write_yaml(source_path, source)
    run_config = dict(source)
    run_config.update({
        "run_dir": run_relative,
        "train_dir": f"{run_relative}/train_data",
        "img_log_dir": f"{run_relative}/img_log",
        "commit_hash": "synthetic",
        "package_version": "synthetic",
    })
    _write_yaml(run_dir / "config.yml", run_config)
    torch.save({"synthetic_weight": torch.tensor([float(seed)])}, run_dir / "model_epoch030.pt")
    scaler_path = run_dir / "train_data/train_data_scaler.yml"
    scaler_path.parent.mkdir(parents=True)
    scaler_path.write_bytes(f"scaler {role} {seed}".encode())

    observed = [[0.0], [1.0], [2.0], [3.0]]
    error = math.sqrt((1.0 - requested_nse) * 5.0 / 4.0)
    simulated = [[value[0] + error] for value in observed]
    dataset = xarray.Dataset({
        "QObs(mm/d)_obs": (("date", "time_step"), observed),
        "QObs(mm/d)_sim": (("date", "time_step"), simulated),
    })
    stacked = dataset.stack(datetime=["date", "time_step"])
    measured = float(nse(stacked["QObs(mm/d)_obs"], stacked["QObs(mm/d)_sim"]))
    basins = [line.strip() for line in (root / audit_configs.BASIN_FILE).read_text().splitlines() if line.strip()]
    results = {basin: {"1D": {"xr": dataset, "NSE": measured}} for basin in basins}
    results_path = result_dir / "validation_results.p"
    with results_path.open("wb") as stream:
        pickle.dump(results, stream)
    metrics_path = result_dir / "validation_metrics.csv"
    with metrics_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=["basin", "NSE"], lineterminator="\n")
        writer.writeheader()
        writer.writerows({"basin": basin, "NSE": measured} for basin in basins)

    def bound(path: Path, prefix: str) -> dict[str, str]:
        return {
            f"{prefix}_path": path.relative_to(root).as_posix(),
            f"{prefix}_sha256": audit_configs.sha256_file(path),
        }

    artifact = {
        "experiment_id": role,
        **bound(source_path, "source_config"),
        **bound(run_dir / "config.yml", "run_config"),
        **bound(run_dir / "model_epoch030.pt", "checkpoint"),
        **bound(metrics_path, "validation_metrics"),
        **bound(results_path, "validation_results"),
        "epoch": 30,
        "metric": "NSE",
        "period": audit_configs.SELECTION_PERIOD,
        "basin_nse": {basin: measured for basin in basins},
        "median_nse": measured,
    }
    artifact_path = run_dir / "epoch030_metrics.json"
    artifact_path.write_text(json.dumps(artifact), encoding="utf-8")
    return artifact_path


def _comparison_fixture(tmp_path: Path) -> tuple[Path, list[str], list[str]]:
    root = tmp_path / "repo"
    basin_path = root / audit_configs.BASIN_FILE
    basin_path.parent.mkdir(parents=True)
    shutil.copy2(REPO_ROOT / audit_configs.BASIN_FILE, basin_path)
    paths: dict[tuple[str, int], Path] = {}
    for role, seed, score in [
        ("B01", 100, 0.50), ("B01", 200, 0.50), ("B01", 300, 0.50),
        ("D01", 100, 0.49), ("D02", 100, 0.55), ("D03", 100, 0.54),
        ("SELECTED_DENSE", 200, 0.55), ("SELECTED_DENSE", 300, 0.55),
        ("M01", 100, 0.58), ("M01", 200, 0.58), ("M01", 300, 0.58),
    ]:
        paths[(role, seed)] = _write_artifact(root, role, seed, score)
    specs = [f"{role}:{seed}={path.relative_to(root).as_posix()}" for (role, seed), path in paths.items()]
    diagnostics = []
    for seed in (100, 200, 300):
        artifact = json.loads(paths[("M01", seed)].read_text())
        run_dir = (root / artifact["checkpoint_path"]).parent
        scaler_path = run_dir / "train_data/train_data_scaler.yml"
        basin_path = root / audit_configs.BASIN_FILE
        diagnostic_path = root / f"router_{seed}.json"
        diagnostic_path.write_text(json.dumps({
            "schema_version": 2,
            "seed": seed,
            "period": audit_configs.SELECTION_PERIOD,
            "checkpoint_path": artifact["checkpoint_path"],
            "checkpoint_sha256": artifact["checkpoint_sha256"],
            "run_config_path": artifact["run_config_path"],
            "run_config_sha256": artifact["run_config_sha256"],
            "scaler_path": scaler_path.relative_to(root).as_posix(),
            "scaler_sha256": audit_configs.sha256_file(scaler_path),
            "basin_file_path": basin_path.relative_to(root).as_posix(),
            "basin_file_sha256": audit_configs.sha256_file(basin_path),
            "basin_count": 531,
            "validation_start_date": "2006-10-01",
            "validation_end_date": "2008-09-30",
            "validation_day_count": 731,
            "validation_token_count": 20,
            "top_k": 2,
            "moe_layer_count": 2,
            "total_routed_assignments": 80,
            "dropped_token_count": 0,
            "layers": [
                {
                    "layer_id": f"blocks.{layer_index}.feed_forward",
                    "validation_token_count": 20,
                    "dropped_token_count": 0,
                    "expert_token_counts": [5] * 8,
                }
                for layer_index in (2, 3)
            ],
        }))
        diagnostics.append(f"{seed}={diagnostic_path.relative_to(root).as_posix()}")
    return root, specs, diagnostics


def test_comparison_recomputes_synthetic_validation_artifacts_and_passes_registered_gates(tmp_path: Path) -> None:
    root, specs, diagnostics = _comparison_fixture(tmp_path)
    report = compare_development.compare(
        specs,
        router_diagnostic_specs=diagnostics,
        repo_root=root,
        n_bootstrap=200,
        require_canonical_derived=False,
        require_complete_binding=False,
    )
    assert report["single_seed_dense_gate"]["status"] == "PASS"
    assert report["single_seed_dense_gate"]["selected_dense"] == "D02"
    assert report["three_seed_continuation_gate"]["status"] == "PASS"
    assert report["three_seed_continuation_gate"]["statistics"]["n"] == 531
    for spec in diagnostics:
        seed, relative_path = spec.split("=", 1)
        assert report["three_seed_continuation_gate"]["router_diagnostics"][seed] == {
            "path": relative_path,
            "sha256": audit_configs.sha256_file(root / relative_path),
        }


def test_comparison_rejects_hash_tampering(tmp_path: Path) -> None:
    root, specs, _ = _comparison_fixture(tmp_path)
    first = compare_development.parse_artifact_spec(specs[0])
    artifact = json.loads((root / first[2]).read_text())
    (root / artifact["validation_results_path"]).write_bytes(b"tampered")
    with pytest.raises(ValueError, match="hash binding failed"):
        compare_development.compare(
            specs,
            repo_root=root,
            n_bootstrap=10,
            require_canonical_derived=False,
            require_complete_binding=False,
        )


def test_comparison_rejects_router_count_or_scaler_tampering(tmp_path: Path) -> None:
    root, specs, diagnostics = _comparison_fixture(tmp_path)
    _, diagnostic_relative = diagnostics[0].split("=", 1)
    diagnostic_path = root / diagnostic_relative
    diagnostic = json.loads(diagnostic_path.read_text())
    diagnostic["total_routed_assignments"] += 1
    diagnostic_path.write_text(json.dumps(diagnostic))
    with pytest.raises(ValueError, match="routed-assignment accounting"):
        compare_development.compare(
            specs,
            router_diagnostic_specs=diagnostics,
            repo_root=root,
            n_bootstrap=10,
            require_canonical_derived=False,
            require_complete_binding=False,
        )

    diagnostic["total_routed_assignments"] -= 1
    diagnostic_path.write_text(json.dumps(diagnostic))
    scaler_path = root / diagnostic["scaler_path"]
    scaler_path.write_bytes(b"tampered scaler")
    with pytest.raises(ValueError, match="scaler hash binding failed"):
        compare_development.compare(
            specs,
            router_diagnostic_specs=diagnostics,
            repo_root=root,
            n_bootstrap=10,
            require_canonical_derived=False,
            require_complete_binding=False,
        )


def test_comparison_holds_for_complementary_layerwise_dead_experts(tmp_path: Path) -> None:
    root, specs, diagnostics = _comparison_fixture(tmp_path)
    _, diagnostic_relative = diagnostics[0].split("=", 1)
    diagnostic_path = root / diagnostic_relative
    diagnostic = json.loads(diagnostic_path.read_text())
    diagnostic["layers"][0]["expert_token_counts"] = [10, 10, 10, 10, 0, 0, 0, 0]
    diagnostic["layers"][1]["expert_token_counts"] = [0, 0, 0, 0, 10, 10, 10, 10]
    aggregate = [sum(layer["expert_token_counts"][index] for layer in diagnostic["layers"]) for index in range(8)]
    assert all(count > 0 for count in aggregate)
    diagnostic_path.write_text(json.dumps(diagnostic))

    report = compare_development.compare(
        specs,
        router_diagnostic_specs=diagnostics,
        repo_root=root,
        n_bootstrap=50,
        require_canonical_derived=False,
        require_complete_binding=False,
    )

    continuation = report["three_seed_continuation_gate"]
    assert continuation["status"] == "HOLD"
    assert continuation["checks"]["no_dead_expert"] is False
    assert any("seed_100_layer_blocks.2.feed_forward_expert_4" in reason for reason in continuation["reasons"])
    assert any("seed_100_layer_blocks.3.feed_forward_expert_0" in reason for reason in continuation["reasons"])


def test_finalize_existing_run_recovers_postprocessing_without_training(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root = tmp_path / "repo"
    config_path = root / "config.yml"
    config_path.parent.mkdir(parents=True)
    config_path.write_text("seed: 100\n")
    run_dir = root / "runs/D01/actual"
    for relative in (
        "config.yml", "model_epoch030.pt", "validation/model_epoch030/validation_metrics.csv",
        "validation/model_epoch030/validation_results.p"
    ):
        path = run_dir / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b"product")
    bindings_path = root / run_development.RUN_BINDINGS_RELATIVE_PATH
    bindings_path.parent.mkdir(parents=True)
    bindings_path.write_text(json.dumps({"schema_version": 2, "records": []}))
    run_development._reserve_run_binding("D01", 100, "recover", config_path, None, root)
    manifest_path = root / run_development.INVOCATIONS_RELATIVE_ROOT / "recover" / "run_manifest.json"
    manifest_path.parent.mkdir(parents=True)
    snapshot = {"files": {"config.yml": run_development._sha256(config_path)}}
    monkeypatch.setattr(
        run_development, "_load_registered_experiment",
        lambda *args, **kwargs: ({"status": "planned"}, config_path, {"run_dir": "runs/D01"})
    )
    manifest_path.write_text(json.dumps({
        "run_id": "recover",
        "experiment_id": "D01",
        "seed": 100,
        "status": "RUNNING",
        "run_dir": run_dir.relative_to(root).as_posix(),
        "new_run_directories": [run_dir.relative_to(root).as_posix()],
        "source_snapshot": snapshot,
    }))
    monkeypatch.setattr(run_development, "_assert_source_unchanged", lambda *args, **kwargs: None)
    artifact_path = run_dir / "epoch030_metrics.json"
    def build_artifact(*args, **kwargs):
        artifact_path.write_text("{}")
        return artifact_path
    monkeypatch.setattr(
        run_development.build_epoch030_metrics_artifact, "build",
        build_artifact
    )
    monkeypatch.setattr(
        run_development.build_epoch030_metrics_artifact, "preflight",
        lambda *args, **kwargs: {}
    )
    updated = []
    monkeypatch.setattr(run_development, "_update_registry", lambda *args, **kwargs: updated.append(True))
    monkeypatch.setattr(run_development.subprocess, "run", lambda *args, **kwargs: pytest.fail("spawned process"))
    result = run_development.finalize_existing_run("D01", run_dir, repo_root=root)
    assert result["recovered_without_training"] is True
    assert updated == [True]


def test_seed200_dry_run_is_read_only_and_reports_unmaterialized_config(tmp_path: Path) -> None:
    root = _copy_contract_repository(tmp_path)
    config_path, provenance_path = run_development._derived_paths("B01", 200, root)
    plan = run_development.plan_development("B01", seed=200, repo_root=root)
    assert plan["mode"] == "DRY_RUN"
    assert plan["seed"] == 200
    assert plan["derived_config_status"] == "would_create"
    assert not config_path.exists()
    assert not provenance_path.exists()


def test_seed200_config_is_immutable_and_binds_base_seed_and_hash(tmp_path: Path) -> None:
    root = _copy_contract_repository(tmp_path)
    config_path, provenance_path = run_development.materialize_derived_config("B01", 200, repo_root=root)
    config = audit_configs.load_yaml(config_path)
    provenance = audit_configs.load_json(provenance_path)
    assert config["seed"] == 200
    assert provenance["base_config_path"].endswith("baseline_lstm_s100.yml")
    assert provenance["derived_config_sha256"] == audit_configs.sha256_file(config_path)
    original = config_path.read_bytes()
    config_path.write_bytes(original + b"\n# tamper\n")
    with pytest.raises(ValueError, match="drifted|binding mismatch"):
        run_development.materialize_derived_config("B01", 200, repo_root=root)
    assert config_path.read_bytes().endswith(b"# tamper\n")


def test_selected_dense_and_moe_seed_derivations_preserve_the_selected_pair(tmp_path: Path) -> None:
    from src.modern_transformer_moe.scripts import generate_selected_moe_config
    from test.test_modern_transformer_moe_configs import _complete_dense_candidates, _copy_task4_repository

    root = _copy_task4_repository(tmp_path)
    report_path, report = _complete_dense_candidates(root)
    generate_selected_moe_config.generate(report_path, root)
    dense_path, dense_provenance_path = run_development.materialize_derived_config(
        "SELECTED_DENSE", 200, repo_root=root
    )
    moe_path, moe_provenance_path = run_development.materialize_derived_config("M01", 200, repo_root=root)
    dense = audit_configs.load_yaml(dense_path)
    moe = audit_configs.load_yaml(moe_path)
    assert audit_configs.audit_dense_sparse_pair(dense, moe) == []
    for path in (dense_provenance_path, moe_provenance_path):
        provenance = audit_configs.load_json(path)
        assert provenance["selected_dense_experiment_id"] == report["selected_experiment_id"]
        assert provenance["selection_report_sha256"] == audit_configs.sha256_file(report_path)


def test_derived_epoch30_artifact_binds_derived_config_and_compare_accepts_it(tmp_path: Path) -> None:
    root = _copy_contract_repository(tmp_path)
    config_path, provenance_path = run_development.materialize_derived_config("B01", 200, repo_root=root)
    manual_artifact = _write_artifact(root, "B01", 200, 0.5, source_path=config_path)
    run_dir = manual_artifact.parent
    manual_artifact.unlink()
    artifact_path = run_development.build_epoch030_metrics_artifact.build(
        "B01", run_dir, root, source_config_path=config_path
    )
    artifact = audit_configs.load_json(artifact_path)
    issues, median = audit_configs.audit_metrics_artifact(
        artifact,
        "B01",
        root,
        artifact_path=artifact_path,
        expected_source_config_path=config_path.relative_to(root),
    )
    assert issues == []
    assert median == pytest.approx(0.5)
    run_development._reserve_run_binding(
        "B01", 200, "bound_b01_s200", config_path, provenance_path, root
    )
    run_development._transition_run_binding(
        "B01", 200, "bound_b01_s200", "POSTPROCESSING", root, run_dir=run_dir
    )
    run_development._transition_run_binding(
        "B01",
        200,
        "bound_b01_s200",
        "COMPLETE",
        root,
        run_dir=run_dir,
        artifact_path=artifact_path,
    )
    loaded = compare_development.load_bound_artifact("B01", 200, artifact_path, repo_root=root)
    assert loaded.seed == 200
    assert loaded.artifact["source_config_path"] == config_path.relative_to(root).as_posix()


def test_compare_rejects_artifact_identity_that_disagrees_with_input_role(tmp_path: Path) -> None:
    root, specs, _ = _comparison_fixture(tmp_path)
    role, seed, relative_path = compare_development.parse_artifact_spec(
        next(spec for spec in specs if spec.startswith("D01:100="))
    )
    artifact_path = root / relative_path
    artifact = json.loads(artifact_path.read_text())
    artifact["experiment_id"] = "D02"
    artifact_path.write_text(json.dumps(artifact))
    with pytest.raises(ValueError, match="does not match input role"):
        compare_development.load_bound_artifact(
            role,
            seed,
            artifact_path,
            repo_root=root,
            require_canonical_derived=False,
            require_complete_binding=False,
        )


def test_compare_rejects_dense_moe_field_drift_even_when_artifact_hashes_are_refreshed(tmp_path: Path) -> None:
    root, specs, diagnostics = _comparison_fixture(tmp_path)
    _, _, relative_path = compare_development.parse_artifact_spec(
        next(spec for spec in specs if spec.startswith("M01:100="))
    )
    artifact_path = root / relative_path
    artifact = json.loads(artifact_path.read_text())
    source_path = root / artifact["source_config_path"]
    run_config_path = root / artifact["run_config_path"]
    source = audit_configs.load_yaml(source_path)
    run_config = audit_configs.load_yaml(run_config_path)
    source["pair_drift"] = "forbidden"
    run_config["pair_drift"] = "forbidden"
    _write_yaml(source_path, source)
    _write_yaml(run_config_path, run_config)
    artifact["source_config_sha256"] = audit_configs.sha256_file(source_path)
    artifact["run_config_sha256"] = audit_configs.sha256_file(run_config_path)
    artifact_path.write_text(json.dumps(artifact))
    with pytest.raises(ValueError, match="not the preregistered paired treatment"):
        compare_development.compare(
            specs,
            router_diagnostic_specs=diagnostics,
            repo_root=root,
            n_bootstrap=10,
            require_canonical_derived=False,
            require_complete_binding=False,
        )


def test_finalize_is_idempotent_when_registry_completed_before_manifest(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from test.test_modern_transformer_moe_configs import _complete_dense_candidates, _copy_task4_repository

    root = _copy_task4_repository(tmp_path)
    _, report = _complete_dense_candidates(root)
    record = next(item for item in report["candidate_metrics"] if item["experiment_id"] == "D01")
    artifact_path = root / record["metrics_artifact_path"]
    artifact = audit_configs.load_json(artifact_path)
    run_dir = (root / artifact["checkpoint_path"]).parent
    source_path = root / artifact["source_config_path"]
    manifest_path = root / run_development.INVOCATIONS_RELATIVE_ROOT / "crash_after_registry" / "run_manifest.json"
    manifest_path.parent.mkdir(parents=True)
    manifest_path.write_text(json.dumps({
        "schema_version": 1,
        "run_id": "crash_after_registry",
        "experiment_id": "D01",
        "seed": 100,
        "status": "POSTPROCESSING",
        "run_dir": run_dir.relative_to(root).as_posix(),
        "source_snapshot": {
            "files": {source_path.relative_to(root).as_posix(): audit_configs.sha256_file(source_path)}
        },
    }))
    run_development._reserve_run_binding(
        "D01", 100, "crash_after_registry", source_path, None, root
    )
    run_development._transition_run_binding(
        "D01",
        100,
        "crash_after_registry",
        "POSTPROCESSING",
        root,
        run_dir=run_dir,
    )
    monkeypatch.setattr(run_development, "_assert_source_unchanged", lambda *args, **kwargs: None)
    registry_path = root / run_development.REGISTRY_RELATIVE_PATH
    registry_before = registry_path.read_bytes()
    result = run_development.finalize_existing_run("D01", run_dir, seed=100, repo_root=root)
    assert result["status"] == "COMPLETE"
    assert registry_path.read_bytes() == registry_before
    finalized_manifest = json.loads(manifest_path.read_text())
    assert finalized_manifest["status"] == "COMPLETE"
    assert finalized_manifest["recovered_without_training"] is True


def test_different_run_id_is_rejected_before_any_subprocess(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root = _copy_contract_repository(tmp_path)
    config_path = root / run_development.CONFIG_RELATIVE_BY_ID["D01"]
    run_development._reserve_run_binding("D01", 100, "first_run", config_path, None, root)
    monkeypatch.setattr(run_development.subprocess, "run", lambda *args, **kwargs: pytest.fail("spawned process"))
    with pytest.raises(FileExistsError, match="already reserved"):
        run_development.execute_development(
            "D01",
            "different_run",
            operator_approved_heavy_compute=True,
            seed=100,
            repo_root=root,
        )


def test_compare_rejects_unregistered_and_nonunique_complete_artifact_bindings(tmp_path: Path) -> None:
    root, specs, _ = _comparison_fixture(tmp_path)
    artifact_spec = next(spec for spec in specs if spec.startswith("D01:100="))
    role, seed, relative_path = compare_development.parse_artifact_spec(artifact_spec)
    artifact_path = root / relative_path
    binding_path = root / run_development.RUN_BINDINGS_RELATIVE_PATH
    binding_path.parent.mkdir(parents=True)
    binding_path.write_text(json.dumps({"schema_version": 2, "records": []}))
    with pytest.raises(ValueError, match="expected one unique COMPLETE binding"):
        compare_development.compare(
            [artifact_spec], repo_root=root, require_canonical_derived=False
        )

    artifact = audit_configs.load_json(artifact_path)
    source_path = root / artifact["source_config_path"]
    run_dir = (root / artifact["checkpoint_path"]).parent
    now = "2026-08-26T00:00:00+00:00"
    base_record = {
        "role": role,
        "seed": seed,
        "run_id": "first",
        "status": "COMPLETE",
        "config_path": artifact["source_config_path"],
        "config_sha256": audit_configs.sha256_file(source_path),
        "provenance_path": "not_applicable",
        "provenance_sha256": "not_applicable",
        "invocation_manifest_path": (
            run_development.INVOCATIONS_RELATIVE_ROOT / "first" / "run_manifest.json"
        ).as_posix(),
        "invocation_manifest_sha256": "not_bound",
        "run_dir": run_dir.relative_to(root).as_posix(),
        "metrics_artifact_path": artifact_path.relative_to(root).as_posix(),
        "metrics_artifact_sha256": audit_configs.sha256_file(artifact_path),
        "failure_stage": "not_applicable",
        "failure_reason": "not_applicable",
        "created_at_utc": now,
        "updated_at_utc": now,
        "history": [],
    }
    duplicate = dict(base_record)
    duplicate["run_id"] = "second"
    duplicate["invocation_manifest_path"] = (
        run_development.INVOCATIONS_RELATIVE_ROOT / "second" / "run_manifest.json"
    ).as_posix()
    binding_path.write_text(json.dumps({"schema_version": 2, "records": [base_record, duplicate]}))
    with pytest.raises(ValueError, match="repeats role/seed"):
        compare_development.compare(
            [artifact_spec], repo_root=root, require_canonical_derived=False
        )


def _stub_source_snapshot(config_path: Path, repo_root: Path, **_kwargs) -> dict:
    return {
        "captured_at_utc": "2026-08-26T00:00:00+00:00",
        "git_revision": "synthetic",
        "git_dirty": False,
        "git_status_sha256": "0" * 64,
        "git_changed_path_count": 0,
        "files": {
            config_path.relative_to(repo_root).as_posix(): run_development._sha256(config_path),
        },
    }


def test_nonzero_subprocess_marks_failed_and_controlled_retry_preserves_old_evidence(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root = _copy_contract_repository(tmp_path)
    monkeypatch.setattr(run_development, "_capture_source_snapshot", _stub_source_snapshot)
    return_codes = iter((7, 9))
    subprocess_calls = 0

    def fail_training(command, **_kwargs):
        nonlocal subprocess_calls
        subprocess_calls += 1
        if subprocess_calls == 2:
            active = run_development._load_run_bindings(root)["records"][0]
            assert active["status"] == "RUNNING"
            assert active["run_id"] == "retry_attempt"
            assert [attempt["run_id"] for attempt in active["history"]] == ["failed_attempt"]
        return run_development.subprocess.CompletedProcess(command, next(return_codes))

    monkeypatch.setattr(run_development.subprocess, "run", fail_training)
    with pytest.raises(RuntimeError, match="training exited with code 7"):
        run_development.execute_development(
            "D01", "failed_attempt", operator_approved_heavy_compute=True, repo_root=root
        )

    failed = run_development._load_run_bindings(root)["records"][0]
    old_manifest = root / failed["invocation_manifest_path"]
    old_manifest_bytes = old_manifest.read_bytes()
    assert failed["status"] == "FAILED"
    assert failed["failure_stage"] == "training_subprocess"
    assert failed["failure_reason"] == "training exited with code 7"
    assert failed["invocation_manifest_sha256"] == run_development._sha256(old_manifest)
    assert run_development._mark_run_binding_failed(
        "D01",
        100,
        "failed_attempt",
        root,
        manifest_path=old_manifest,
        failure_stage="training_subprocess",
        failure_reason="training exited with code 7",
        run_dir=None,
    ) == failed
    old_manifest.write_bytes(old_manifest_bytes + b"\n")
    with pytest.raises(ValueError, match="immutable"):
        run_development._mark_run_binding_failed(
            "D01",
            100,
            "failed_attempt",
            root,
            manifest_path=old_manifest,
            failure_stage="training_subprocess",
            failure_reason="training exited with code 7",
            run_dir=None,
        )
    old_manifest.write_bytes(old_manifest_bytes)

    with pytest.raises(RuntimeError, match="training exited with code 9"):
        run_development.execute_development(
            "D01",
            "retry_attempt",
            operator_approved_heavy_compute=True,
            repo_root=root,
            retry_failed_run_id="failed_attempt",
        )

    retried = run_development._load_run_bindings(root)["records"][0]
    assert retried["status"] == "FAILED"
    assert retried["run_id"] == "retry_attempt"
    assert len(retried["history"]) == 1
    assert retried["history"][0]["run_id"] == "failed_attempt"
    assert retried["history"][0]["failure_reason"] == "training exited with code 7"
    assert old_manifest.read_bytes() == old_manifest_bytes
    assert retried["history"][0]["invocation_manifest_sha256"] == run_development._sha256(old_manifest)


def test_controlled_retry_rejects_failed_attempt_with_complete_epoch030_products(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root = _copy_contract_repository(tmp_path)
    monkeypatch.setattr(run_development, "_capture_source_snapshot", _stub_source_snapshot)
    run_root = root / "results/30_modern_transformer_moe/D01"
    run_dir = run_root / "actual"
    config_path = root / run_development.CONFIG_RELATIVE_BY_ID["D01"]
    subprocess_calls = 0

    def fail_after_writing_complete_products(command, **_kwargs):
        nonlocal subprocess_calls
        subprocess_calls += 1
        artifact_path = _write_artifact(root, "D01", 100, 0.5, source_path=config_path)
        assert artifact_path.parent == run_dir
        return run_development.subprocess.CompletedProcess(command, 11)

    monkeypatch.setattr(run_development.subprocess, "run", fail_after_writing_complete_products)
    with pytest.raises(RuntimeError, match="training exited with code 11"):
        run_development.execute_development(
            "D01", "failed_with_products", operator_approved_heavy_compute=True, repo_root=root
        )

    with pytest.raises(FileExistsError, match="finalize-run-dir"):
        run_development.execute_development(
            "D01",
            "forbidden_retry",
            operator_approved_heavy_compute=True,
            repo_root=root,
            retry_failed_run_id="failed_with_products",
        )
    assert subprocess_calls == 1
    binding = run_development._load_run_bindings(root)["records"][0]
    assert binding["status"] == "FAILED"
    assert binding["run_id"] == "failed_with_products"
    assert binding["history"] == []


def test_controlled_retry_allows_unchanged_but_unparseable_epoch030_files(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root = _copy_contract_repository(tmp_path)
    monkeypatch.setattr(run_development, "_capture_source_snapshot", _stub_source_snapshot)
    corrupt_run = root / "results/30_modern_transformer_moe/D01/corrupt"
    subprocess_calls = 0

    def fail_with_corrupt_files(command, **_kwargs):
        nonlocal subprocess_calls
        subprocess_calls += 1
        if subprocess_calls == 1:
            for relative in run_development.EPOCH030_REQUIRED_RELATIVE_FILES:
                path = corrupt_run / relative
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(b"")
        return run_development.subprocess.CompletedProcess(command, 20 + subprocess_calls)

    monkeypatch.setattr(run_development.subprocess, "run", fail_with_corrupt_files)
    with pytest.raises(RuntimeError, match="training exited with code 21"):
        run_development.execute_development(
            "D01", "corrupt_attempt", operator_approved_heavy_compute=True, repo_root=root
        )
    with pytest.raises(RuntimeError, match="training exited with code 22"):
        run_development.execute_development(
            "D01",
            "retry_after_corruption",
            operator_approved_heavy_compute=True,
            repo_root=root,
            retry_failed_run_id="corrupt_attempt",
        )
    assert subprocess_calls == 2
    binding = run_development._load_run_bindings(root)["records"][0]
    assert binding["run_id"] == "retry_after_corruption"
    assert [attempt["run_id"] for attempt in binding["history"]] == ["corrupt_attempt"]


@pytest.mark.parametrize("mutation", ["delete", "tamper"])
def test_loading_bindings_rejects_missing_or_tampered_history_manifest(tmp_path: Path, mutation: str) -> None:
    root = _copy_contract_repository(tmp_path)
    config_path = root / run_development.CONFIG_RELATIVE_BY_ID["D01"]
    run_development._reserve_run_binding("D01", 100, "old_failed", config_path, None, root)
    manifest_path = root / run_development.INVOCATIONS_RELATIVE_ROOT / "old_failed/run_manifest.json"
    manifest_path.parent.mkdir(parents=True)
    manifest_path.write_text(json.dumps({
        "run_id": "old_failed",
        "experiment_id": "D01",
        "seed": 100,
        "status": "FAILED",
        "new_run_directories": [],
        "epoch030_product_inventory": [],
    }))
    run_development._mark_run_binding_failed(
        "D01",
        100,
        "old_failed",
        root,
        manifest_path=manifest_path,
        failure_stage="training_subprocess",
        failure_reason="synthetic failure",
        run_dir=None,
    )
    run_development._retry_failed_run_binding(
        "D01", 100, "old_failed", "replacement", config_path, None, root
    )

    if mutation == "delete":
        manifest_path.unlink()
        expected_error = FileNotFoundError
    else:
        manifest_path.write_bytes(manifest_path.read_bytes() + b"\n")
        expected_error = ValueError
    with pytest.raises(expected_error, match="history invocation manifest"):
        run_development._load_run_bindings(root)
