from types import MethodType, SimpleNamespace

import numpy as np
import pandas as pd
import pytest

from neuralhydrology.datasetzoo.basedataset import BaseDataset
from neuralhydrology.datasetzoo.camelsus import CamelsUS, load_camels_us_attributes


_BASIN = "01000000"
_TARGET = "QObs(mm/d)"
_TRACK0_ATTRIBUTES = [
    "p_mean",
    "pet_mean",
    "aridity",
    "p_seasonality",
    "frac_snow",
    "high_prec_freq",
    "high_prec_dur",
    "low_prec_freq",
    "low_prec_dur",
    "elev_mean",
    "slope_mean",
    "area_gages2",
    "frac_forest",
    "lai_max",
    "lai_diff",
    "gvf_max",
    "gvf_diff",
    "soil_depth_pelletier",
    "soil_depth_statsgo",
    "soil_porosity",
    "soil_conductivity",
    "max_water_content",
    "sand_frac",
    "silt_frac",
    "clay_frac",
    "carbonate_rocks_frac",
    "geol_permeability",
]


def _training_statistics(warmup_targets: np.ndarray):
    dates = pd.date_range("2000-01-01", periods=40, freq="D", name="date")
    frame = pd.DataFrame({
        "forcing": np.linspace(0.0, 1.0, len(dates)),
        _TARGET: np.concatenate([warmup_targets, np.linspace(1.0, 10.0, 10)]),
    }, index=dates)

    dataset = object.__new__(BaseDataset)
    dataset.cfg = SimpleNamespace(
        train_data_file=None,
        target_variables=[_TARGET],
        evolving_attributes=[],
        mass_inputs=[],
        autoregressive_inputs=[],
        dynamic_inputs=["forcing"],
        dynamic_inputs_flattened=["forcing"],
        dynamic_conceptual_inputs=[],
        duplicate_features={},
        lagged_features={},
        random_holdout_from_dynamic_features={},
        custom_normalization={},
        save_train_data=False,
    )
    dataset.is_train = True
    dataset.basins = [_BASIN]
    dataset.additional_features = []
    dataset._disable_pbar = True
    dataset.frequencies = ["1D"]
    dataset.seq_len = [31]
    dataset._predict_last_n = [1]
    dataset.start_and_end_dates = {
        _BASIN: {
            "start_dates": [pd.Timestamp("2000-01-31")],
            "end_dates": [pd.Timestamp("2000-02-09")],
        }
    }
    dataset._load_basin_data = MethodType(lambda self, basin: frame.copy(), dataset)

    xr = dataset._load_or_create_xarray_dataset()
    dataset.scaler = {}
    dataset._setup_normalization(xr)
    dataset._per_basin_target_stds = {}
    dataset._calculate_per_basin_std(xr)

    return {
        "xarray": xr,
        "center": float(dataset.scaler["xarray_feature_center"][_TARGET]),
        "scale": float(dataset.scaler["xarray_feature_scale"][_TARGET]),
        "basin_std": float(dataset._per_basin_target_stds[_BASIN][0, 0]),
    }


def test_warmup_targets_do_not_affect_training_statistics():
    baseline = _training_statistics(np.arange(30, dtype=np.float32))
    perturbed = _training_statistics(np.arange(30, dtype=np.float32) + 1_000_000.0)

    assert baseline["center"] == pytest.approx(perturbed["center"])
    assert baseline["scale"] == pytest.approx(perturbed["scale"])
    assert baseline["basin_std"] == pytest.approx(perturbed["basin_std"])

    warmup = baseline["xarray"].sel(basin=_BASIN).isel(date=slice(0, 30))
    assert np.isnan(warmup[_TARGET].values).all()
    assert np.isfinite(warmup["forcing"].values).all()


def _write_attribute_tables(data_dir):
    attribute_dir = data_dir / "camels_attributes_v2.0"
    attribute_dir.mkdir()
    table_columns = {
        "camels_clim.txt": [
            "p_mean", "pet_mean", "p_seasonality", "frac_snow", "aridity", "high_prec_freq",
            "high_prec_dur", "high_prec_timing", "low_prec_freq", "low_prec_dur", "low_prec_timing"
        ],
        "camels_geol.txt": [
            "geol_1st_class", "glim_1st_class_frac", "geol_2nd_class", "glim_2nd_class_frac",
            "carbonate_rocks_frac", "geol_porostiy", "geol_permeability"
        ],
        "camels_hydro.txt": [
            "q_mean", "runoff_ratio", "slope_fdc", "baseflow_index", "stream_elas", "q5", "q95",
            "high_q_freq", "high_q_dur", "low_q_freq", "low_q_dur", "zero_q_freq", "hfd_mean"
        ],
        "camels_name.txt": ["huc_02", "gauge_name"],
        "camels_soil.txt": [
            "soil_depth_pelletier", "soil_depth_statsgo", "soil_porosity", "soil_conductivity",
            "max_water_content", "sand_frac", "silt_frac", "clay_frac", "water_frac", "organic_frac", "other_frac"
        ],
        "camels_topo.txt": [
            "gauge_lat", "gauge_lon", "elev_mean", "slope_mean", "area_gages2", "area_geospa_fabric"
        ],
        "camels_vege.txt": [
            "frac_forest", "lai_max", "lai_diff", "gvf_max", "gvf_diff", "dom_land_cover_frac",
            "dom_land_cover", "root_depth_50", "root_depth_99"
        ],
    }
    for filename, columns in table_columns.items():
        header = ";".join(["gauge_id", *columns])
        values = ";".join([_BASIN, *["1" for _ in columns]])
        (attribute_dir / filename).write_text(f"{header}\n{values}\n", encoding="utf-8")


def test_track0_attribute_selection_never_opens_hydrologic_signatures(tmp_path, monkeypatch):
    _write_attribute_tables(tmp_path)
    opened_files = []
    original_read_csv = pd.read_csv

    def recording_read_csv(path, *args, **kwargs):
        opened_files.append(path.name)
        return original_read_csv(path, *args, **kwargs)

    monkeypatch.setattr(pd, "read_csv", recording_read_csv)
    attributes = load_camels_us_attributes(tmp_path, basins=[_BASIN], attributes=_TRACK0_ATTRIBUTES)

    assert set(opened_files) == {
        "camels_clim.txt",
        "camels_geol.txt",
        "camels_soil.txt",
        "camels_topo.txt",
        "camels_vege.txt",
    }
    assert "camels_hydro.txt" not in opened_files
    assert list(attributes.columns) == _TRACK0_ATTRIBUTES


def test_camelsus_forwards_requested_static_attributes(monkeypatch, tmp_path):
    requested = ["p_mean", "elev_mean"]
    captured = {}
    expected = pd.DataFrame(index=[_BASIN], columns=requested)

    def fake_loader(data_dir, basins, attributes):
        captured.update(data_dir=data_dir, basins=basins, attributes=attributes)
        return expected

    monkeypatch.setattr("neuralhydrology.datasetzoo.camelsus.load_camels_us_attributes", fake_loader)
    dataset = object.__new__(CamelsUS)
    dataset.cfg = SimpleNamespace(data_dir=tmp_path, static_attributes=requested)
    dataset.basins = [_BASIN]

    result = dataset._load_attributes()

    assert result is expected
    assert captured == {"data_dir": tmp_path, "basins": [_BASIN], "attributes": requested}


def test_default_attribute_loading_keeps_all_tables_and_huc_alias(tmp_path):
    _write_attribute_tables(tmp_path)

    attributes = load_camels_us_attributes(tmp_path, basins=[_BASIN])

    assert {"p_mean", "q_mean", "gauge_name", "huc"}.issubset(attributes.columns)
    assert "huc_02" not in attributes.columns
    assert attributes.loc[_BASIN, "huc"] == "01"
