from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest

from neuralhydrology.datasetzoo.camelsus import CamelsUS
from neuralhydrology.datasetzoo.camelsus_track0_bundle import CamelsUSTrack0Bundle, _safe_file
from src.modern_transformer_moe.scripts.audit_track0_supervision_bundle import audit_bundles
from src.modern_transformer_moe.scripts.build_track0_development_forcing_bundle import build_forcing_bundle
from src.modern_transformer_moe.scripts.build_track0_supervision_bundle import build_supervision_bundle
from src.modern_transformer_moe.scripts.track0_bundle_common import (FORCING_VARIABLES, TARGET_COLUMN,
                                                                    TRACK0_STATIC_ATTRIBUTES)


_BASINS = ["01000001", "01000002"]


def _write_raw_forcing(raw_data_dir: Path, basin: str, dates: pd.DatetimeIndex, area: int = 1_000_000) -> None:
    forcing_dir = raw_data_dir / "basin_mean_forcing" / "maurer" / "01"
    forcing_dir.mkdir(parents=True, exist_ok=True)
    path = forcing_dir / f"{basin}_lump_maurer_forcing_leap.txt"
    lines = [
        "42.0",
        "-71.0",
        str(area),
        "Year Mnth Day Hr Dayl(s) PRCP(mm/day) SRAD(W/m2) SWE(mm) Tmax(C) Tmin(C) Vp(Pa)",
    ]
    for offset, date in enumerate(dates):
        lines.append(
            f"{date.year} {date.month} {date.day} 12 36000 {1.0 + offset} {100.0 + offset} 0 "
            f"{10.0 + offset} {0.0 + offset} {800.0 + offset}"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _write_raw_discharge(raw_data_dir: Path, basin: str, dates: pd.DatetimeIndex) -> None:
    discharge_dir = raw_data_dir / "usgs_streamflow" / "01"
    discharge_dir.mkdir(parents=True, exist_ok=True)
    path = discharge_dir / f"{basin}_streamflow_qc.txt"
    lines = [
        f"{basin} {date.year} {date.month} {date.day} {10.0 + offset} A" for offset, date in enumerate(dates)
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _write_source_inputs(tmp_path: Path) -> tuple[Path, Path, Path]:
    raw_data_dir = tmp_path / "raw_camels_us"
    raw_dates = pd.date_range("1999-12-30", "2000-01-05", freq="D")
    for basin in _BASINS:
        _write_raw_forcing(raw_data_dir, basin, raw_dates)
        _write_raw_discharge(raw_data_dir, basin, raw_dates)

    basin_file = tmp_path / "basins.txt"
    basin_file.write_text("\n".join(_BASINS) + "\n", encoding="utf-8")

    source_statics = tmp_path / "track0_statics.csv"
    rows = []
    for basin_index, basin in enumerate(_BASINS):
        rows.append([basin, *[float(basin_index + attribute_index) for attribute_index in range(27)]])
    pd.DataFrame(rows, columns=["gauge_id", *TRACK0_STATIC_ATTRIBUTES]).to_csv(source_statics, index=False)
    return raw_data_dir, basin_file, source_statics


def _build_tiny_bundles(tmp_path: Path):
    raw_data_dir, basin_file, source_statics = _write_source_inputs(tmp_path)
    forcing_dir = tmp_path / "safe_forcing"
    supervision_dir = tmp_path / "safe_supervision"
    registry_dir = tmp_path / "registry"
    forcing_manifest = registry_dir / "forcing.json"
    supervision_manifest = registry_dir / "supervision.json"

    build_forcing_bundle(
        raw_data_dir=raw_data_dir,
        source_statics=source_statics,
        basin_file=basin_file,
        start_date="1999-12-31",
        end_date="2000-01-04",
        output_dir=forcing_dir,
        manifest_path=forcing_manifest,
        expected_basin_count=2,
    )
    build_supervision_bundle(
        raw_data_dir=raw_data_dir,
        basin_file=basin_file,
        start_date="2000-01-01",
        end_date="2000-01-03",
        output_dir=supervision_dir,
        manifest_path=supervision_manifest,
        expected_basin_count=2,
    )
    return {
        "raw_data_dir": raw_data_dir,
        "source_statics": source_statics,
        "forcing_dir": forcing_dir,
        "supervision_dir": supervision_dir,
        "forcing_manifest": forcing_manifest,
        "supervision_manifest": supervision_manifest,
    }


def test_legacy_camelsus_materializes_discharge_before_period_slicing(monkeypatch, tmp_path):
    dates = pd.date_range("1980-01-01", "2008-12-31", freq="D", name="date")
    forcing = pd.DataFrame({FORCING_VARIABLES[0]: np.ones(len(dates))}, index=dates)
    discharge_calls = []

    monkeypatch.setattr("neuralhydrology.datasetzoo.camelsus.load_camels_us_forcings",
                        lambda *_args, **_kwargs: (forcing, 1_000_000))

    def fake_discharge(_data_dir, _basin, _area):
        discharge_calls.append("full-file-loader-called")
        return pd.Series(np.ones(len(dates)), index=dates)

    monkeypatch.setattr("neuralhydrology.datasetzoo.camelsus.load_camels_us_discharge", fake_discharge)
    dataset = object.__new__(CamelsUS)
    dataset.cfg = SimpleNamespace(data_dir=tmp_path, forcings=["maurer"])

    loaded = dataset._load_basin_data(_BASINS[0])

    assert discharge_calls == ["full-file-loader-called"]
    assert loaded.index.min() == pd.Timestamp("1980-01-01")
    assert loaded.index.max() == pd.Timestamp("2008-12-31")


def test_builders_create_exact_candidate_safe_ranges_and_write_once_manifests(tmp_path):
    paths = _build_tiny_bundles(tmp_path)

    forcing = pd.read_parquet(paths["forcing_dir"] / "track0_forcing.parquet")
    assert list(forcing.columns) == ["gauge_id", "date", *FORCING_VARIABLES]
    assert set(forcing["gauge_id"]) == set(_BASINS)
    assert forcing["date"].min() == pd.Timestamp("1999-12-31")
    assert forcing["date"].max() == pd.Timestamp("2000-01-04")
    assert len(forcing) == 2 * 5
    assert (paths["forcing_dir"] / "track0_statics.csv").read_bytes() == paths["source_statics"].read_bytes()

    target_files = sorted((paths["supervision_dir"] / "targets").glob("*.parquet"))
    assert [path.stem for path in target_files] == _BASINS
    for path in target_files:
        target = pd.read_parquet(path)
        assert list(target.columns) == ["date", TARGET_COLUMN]
        assert target["date"].min() == pd.Timestamp("2000-01-01")
        assert target["date"].max() == pd.Timestamp("2000-01-03")
        assert len(target) == 3

    assert paths["forcing_manifest"].is_file()
    assert paths["supervision_manifest"].is_file()
    with pytest.raises(FileExistsError, match="Refusing to overwrite"):
        build_supervision_bundle(
            raw_data_dir=paths["raw_data_dir"],
            basin_file=tmp_path / "basins.txt",
            start_date="2000-01-01",
            end_date="2000-01-03",
            output_dir=paths["supervision_dir"],
            manifest_path=paths["supervision_manifest"],
            expected_basin_count=2,
        )


def test_auditor_checks_hashes_schema_and_exact_daily_coverage(tmp_path):
    paths = _build_tiny_bundles(tmp_path)

    report = audit_bundles(
        forcing_manifest_path=paths["forcing_manifest"],
        supervision_manifest_path=paths["supervision_manifest"],
        expected_basin_count=2,
    )

    assert report["status"] == "PASS"
    assert report["basin_count"] == 2
    assert report["forcing_row_count"] == 10
    assert report["supervision_row_count"] == 6

    target_path = paths["supervision_dir"] / "targets" / f"{_BASINS[0]}.parquet"
    tampered = pd.read_parquet(target_path)
    tampered.loc[0, TARGET_COLUMN] += 1.0
    tampered.to_parquet(target_path, index=False)
    with pytest.raises(ValueError, match="SHA-256"):
        audit_bundles(
            forcing_manifest_path=paths["forcing_manifest"],
            supervision_manifest_path=paths["supervision_manifest"],
            expected_basin_count=2,
        )


def test_candidate_loader_reads_only_safe_bundle_paths(tmp_path, monkeypatch):
    paths = _build_tiny_bundles(tmp_path)
    opened_paths = []
    original_read_parquet = pd.read_parquet
    original_read_csv = pd.read_csv

    def recording_read_parquet(path, *args, **kwargs):
        opened_paths.append(Path(path).resolve())
        return original_read_parquet(path, *args, **kwargs)

    def recording_read_csv(path, *args, **kwargs):
        opened_paths.append(Path(path).resolve())
        return original_read_csv(path, *args, **kwargs)

    monkeypatch.setattr(pd, "read_parquet", recording_read_parquet)
    monkeypatch.setattr(pd, "read_csv", recording_read_csv)
    monkeypatch.setattr("neuralhydrology.datasetzoo.camelsus.load_camels_us_forcings",
                        lambda *_args, **_kwargs: pytest.fail("raw forcing loader was called"))
    monkeypatch.setattr("neuralhydrology.datasetzoo.camelsus.load_camels_us_discharge",
                        lambda *_args, **_kwargs: pytest.fail("raw discharge loader was called"))

    dataset = object.__new__(CamelsUSTrack0Bundle)
    dataset.cfg = SimpleNamespace(
        data_dir=paths["forcing_dir"],
        track0_supervision_dir=paths["supervision_dir"],
        static_attributes=TRACK0_STATIC_ATTRIBUTES,
    )
    dataset.basins = _BASINS

    basin_data = dataset._load_basin_data(_BASINS[0])
    attributes = dataset._load_attributes()

    assert list(basin_data.columns) == [*FORCING_VARIABLES, TARGET_COLUMN]
    assert basin_data.index.min() == pd.Timestamp("1999-12-31")
    assert basin_data.index.max() == pd.Timestamp("2000-01-04")
    assert basin_data.loc[pd.Timestamp("1999-12-31"), TARGET_COLUMN] != basin_data.loc[
        pd.Timestamp("1999-12-31"), TARGET_COLUMN]
    assert list(attributes.columns) == TRACK0_STATIC_ATTRIBUTES
    assert list(attributes.index) == _BASINS

    allowed_roots = [paths["forcing_dir"].resolve(), paths["supervision_dir"].resolve()]
    assert opened_paths
    assert all(any(path.is_relative_to(root) for root in allowed_roots) for path in opened_paths)
    assert all(not path.is_relative_to(paths["raw_data_dir"].resolve()) for path in opened_paths)


def test_candidate_loader_rejects_path_escape(tmp_path):
    paths = _build_tiny_bundles(tmp_path)
    with pytest.raises(ValueError, match="escapes configured safe root"):
        _safe_file(paths["supervision_dir"], "..", "raw_camels_us", "usgs_streamflow", "01",
                   f"{_BASINS[0]}_streamflow_qc.txt")
