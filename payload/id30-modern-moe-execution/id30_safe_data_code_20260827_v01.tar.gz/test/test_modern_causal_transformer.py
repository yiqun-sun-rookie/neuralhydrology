"""Unit tests for the modern causal Transformer implementation."""

import torch

from neuralhydrology.modelzoo import get_model
from neuralhydrology.modelzoo.modern_causal_transformer import ModernCausalTransformer, RMSNorm, RotaryEmbedding
from neuralhydrology.utils.config import Config


def _config(model: str = "modern_transformer", **updates) -> Config:
    values = {
        "model": model,
        "head": "regression",
        "target_variables": ["q"],
        "dynamic_inputs": ["precipitation", "temperature"],
        "static_attributes": ["area", "slope"],
        "dynamics_embedding": {
            "type": "fc",
            "hiddens": [8],
            "activation": "linear",
            "dropout": 0.0,
        },
        "statics_embedding": {
            "type": "fc",
            "hiddens": [8],
            "activation": "linear",
            "dropout": 0.0,
        },
        "seq_length": 30,
        "transformer_nheads": 4,
        "transformer_dim_feedforward": 32,
        "transformer_dropout": 0.0,
        "transformer_nlayers": 2,
        "output_dropout": 0.0,
    }
    values.update(updates)
    return Config(values)


def _data(batch_size: int = 3, sequence_length: int = 30) -> dict:
    return {
        "x_d": {
            "precipitation": torch.randn(batch_size, sequence_length, 1),
            "temperature": torch.randn(batch_size, sequence_length, 1),
        },
        "x_s": torch.randn(batch_size, 2),
    }


def test_factory_builds_modern_transformer_with_expected_output_shape():
    model = get_model(_config())

    output = model(_data())

    assert isinstance(model, ModernCausalTransformer)
    assert output["y_hat"].shape == (3, 30, 1)


def test_rms_norm_and_rotary_embedding_preserve_shape_dtype_and_device():
    x = torch.randn(2, 4, 7, 8, dtype=torch.float64)
    norm = RMSNorm(8).to(dtype=x.dtype)
    rotary = RotaryEmbedding(8)

    normalized = norm(x)
    query, key = rotary(x, x.clone())

    for tensor in (normalized, query, key):
        assert tensor.shape == x.shape
        assert tensor.dtype == x.dtype
        assert tensor.device == x.device


def test_rms_norm_preserves_low_precision_dtype_and_finite_values():
    for dtype in (torch.float16, torch.bfloat16):
        x = torch.randn(2, 5, 8, dtype=dtype)

        output = RMSNorm(8)(x)

        assert output.dtype == dtype
        assert output.device == x.device
        assert torch.isfinite(output).all()


def test_modern_transformer_is_causal():
    torch.manual_seed(7)
    model = get_model(_config())
    model.eval()
    original = _data(batch_size=2)
    perturbed = {
        "x_d": {name: values.clone() for name, values in original["x_d"].items()},
        "x_s": original["x_s"].clone(),
    }
    last_unchanged_index = 12
    for values in perturbed["x_d"].values():
        values[:, last_unchanged_index + 1:] += 100.0 * torch.randn_like(values[:, last_unchanged_index + 1:])

    with torch.no_grad():
        expected = model(original)["y_hat"]
        actual = model(perturbed)["y_hat"]

    prefix_error = (expected[:, :last_unchanged_index + 1] - actual[:, :last_unchanged_index + 1]).abs().max()
    future_difference = (expected[:, last_unchanged_index + 1:] - actual[:, last_unchanged_index + 1:]).abs().max()
    assert prefix_error.item() < 1e-7
    assert future_difference.item() > 0.0


def test_blocks_are_independently_initialized_and_all_core_parameters_receive_gradients():
    torch.manual_seed(11)
    model = get_model(_config(transformer_nlayers=3))

    first_query = model.blocks[0].attention.query_projection.weight
    second_query = model.blocks[1].attention.query_projection.weight
    assert not torch.equal(first_query, second_query)

    output = model(_data(batch_size=2, sequence_length=12))["y_hat"]
    output.square().mean().backward()

    core_parameters = [(name, parameter) for name, parameter in model.named_parameters()
                       if ".attention." in name or ".feed_forward." in name]
    assert core_parameters
    for name, parameter in core_parameters:
        assert parameter.grad is not None, name
        assert torch.isfinite(parameter.grad).all(), name


def test_missing_config_seed_preserves_global_random_initialization():
    torch.manual_seed(101)
    first = get_model(_config())
    torch.manual_seed(102)
    second = get_model(_config())

    assert not torch.equal(first.input_projection.weight, second.input_projection.weight)


def test_odd_attention_head_dimension_is_rejected():
    config = _config(transformer_nheads=4,
                     dynamics_embedding={"type": "fc", "hiddens": [6], "activation": "linear", "dropout": 0.0},
                     statics_embedding={"type": "fc", "hiddens": [6], "activation": "linear", "dropout": 0.0})

    try:
        get_model(config)
    except ValueError as error:
        assert "even" in str(error).lower()
    else:
        raise AssertionError("An odd attention-head dimension must be rejected.")
