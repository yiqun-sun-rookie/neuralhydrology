"""Preflight and postflight integrity checks for candidate-safe Track 0 data."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from src.modern_transformer_moe.scripts.audit_track0_supervision_bundle import audit_bundles
from src.modern_transformer_moe.scripts.track0_bundle_common import sha256_file


FORCING_MANIFEST_RELATIVE_PATH = Path(
    "src/modern_transformer_moe/registry/track0_development_forcing_manifest_v01.json"
)
SUPERVISION_MANIFEST_RELATIVE_PATH = Path(
    "src/modern_transformer_moe/registry/track0_supervision_manifest_v01.json"
)


def _resolve_config_path(repo_root: Path, value: str | Path) -> Path:
    path = Path(value)
    return path.resolve() if path.is_absolute() else (repo_root / path).resolve()


def capture_safe_data_snapshot(repo_root: Path,
                               config: dict[str, Any],
                               forcing_manifest_path: Path | None = None,
                               supervision_manifest_path: Path | None = None,
                               expected_basin_count: int = 531) -> dict[str, Any]:
    repo_root = Path(repo_root).resolve()
    forcing_manifest_path = (Path(forcing_manifest_path).resolve() if forcing_manifest_path is not None else
                             repo_root / FORCING_MANIFEST_RELATIVE_PATH)
    supervision_manifest_path = (Path(supervision_manifest_path).resolve() if supervision_manifest_path is not None else
                                 repo_root / SUPERVISION_MANIFEST_RELATIVE_PATH)
    forcing_manifest = json.loads(forcing_manifest_path.read_text(encoding="utf-8"))
    supervision_manifest = json.loads(supervision_manifest_path.read_text(encoding="utf-8"))

    configured_forcing_dir = _resolve_config_path(repo_root, config["data_dir"])
    configured_supervision_dir = _resolve_config_path(repo_root, config["track0_supervision_dir"])
    manifest_forcing_dir = Path(forcing_manifest["output_dir"]).resolve()
    manifest_supervision_dir = Path(supervision_manifest["output_dir"]).resolve()
    if configured_forcing_dir != manifest_forcing_dir:
        raise ValueError(
            f"Configured forcing bundle {configured_forcing_dir} differs from manifest output {manifest_forcing_dir}."
        )
    if configured_supervision_dir != manifest_supervision_dir:
        raise ValueError(
            f"Configured supervision bundle {configured_supervision_dir} differs from manifest output "
            f"{manifest_supervision_dir}."
        )

    audit = audit_bundles(
        forcing_manifest_path=forcing_manifest_path,
        supervision_manifest_path=supervision_manifest_path,
        expected_basin_count=expected_basin_count,
    )
    if audit["status"] != "PASS":
        raise ValueError(f"Candidate-safe data audit did not pass: {audit}")
    return {
        "status": "PASS",
        "forcing_manifest_path": str(forcing_manifest_path),
        "forcing_manifest_sha256": sha256_file(forcing_manifest_path),
        "supervision_manifest_path": str(supervision_manifest_path),
        "supervision_manifest_sha256": sha256_file(supervision_manifest_path),
        "forcing_dir": str(configured_forcing_dir),
        "supervision_dir": str(configured_supervision_dir),
        "forcing_file_sha256": forcing_manifest["outputs"]["track0_forcing.parquet"]["sha256"],
        "statics_file_sha256": forcing_manifest["outputs"]["track0_statics.csv"]["sha256"],
        "target_tree_sha256": supervision_manifest["outputs"]["target_tree_sha256"],
        "audit": audit,
    }


def assert_safe_data_unchanged(snapshot: dict[str, Any], repo_root: Path, config: dict[str, Any]) -> dict[str, Any]:
    current = capture_safe_data_snapshot(
        repo_root=repo_root,
        config=config,
        forcing_manifest_path=Path(snapshot["forcing_manifest_path"]),
        supervision_manifest_path=Path(snapshot["supervision_manifest_path"]),
        expected_basin_count=int(snapshot["audit"]["basin_count"]),
    )
    stable_fields = {
        "forcing_manifest_sha256",
        "supervision_manifest_sha256",
        "forcing_dir",
        "supervision_dir",
        "forcing_file_sha256",
        "statics_file_sha256",
        "target_tree_sha256",
    }
    changed = sorted(field for field in stable_fields if snapshot.get(field) != current.get(field))
    if changed:
        raise RuntimeError(f"Candidate-safe data changed during execution: {changed}")
    return current


def audit_access_log(path: Path, forcing_dir: Path, supervision_dir: Path) -> dict[str, Any]:
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Candidate data-access log is missing: {path}")
    records = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if not records:
        raise ValueError("Candidate data-access log is empty.")
    allowed_roots = [Path(forcing_dir).resolve(), Path(supervision_dir).resolve()]
    opened_paths = []
    violations = []
    for record in records:
        opened = Path(record["path"]).resolve()
        opened_paths.append(str(opened))
        if not any(opened.is_relative_to(root) for root in allowed_roots):
            violations.append(str(opened))
    if violations:
        raise ValueError(f"Candidate opened paths outside the safe data bundles: {sorted(set(violations))}")
    unique_paths = sorted(set(opened_paths))
    return {
        "status": "PASS",
        "record_count": len(records),
        "unique_path_count": len(unique_paths),
        "unique_paths": unique_paths,
        "log_sha256": sha256_file(path),
    }
