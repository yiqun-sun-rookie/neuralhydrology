"""Generate M01 only after a hash-bound dense validation-selection report exists."""

from __future__ import annotations

import argparse
import csv
import os
import tempfile
from copy import deepcopy
from pathlib import Path
from typing import Any

from ruamel.yaml import YAML

from neuralhydrology.utils.config import Config
from src.modern_transformer_moe.scripts import audit_configs


M01_CONFIG_RELATIVE_PATH = "src/modern_transformer_moe/configs/moe_selected_s100.yml"
LOCK_RELATIVE_PATH = "src/modern_transformer_moe/.generate_m01.lock"


def build_sparse_config(dense: dict[str, Any], selected_experiment_id: str) -> dict[str, Any]:
    """Return the preregistered expert-layer and load-balancing treatment for a selected dense model."""
    if selected_experiment_id not in audit_configs.DENSE_CONFIG_BY_ID:
        raise ValueError(f"selected dense experiment must be D01, D02, or D03, got {selected_experiment_id!r}")
    if dense.get("model") != "modern_transformer":
        raise ValueError("selected source configuration must use model modern_transformer")

    dense_width = int(dense["transformer_dim_feedforward"])
    shared_width, routed_width = audit_configs.expected_sparse_widths(dense_width)
    sparse = deepcopy(dense)
    sparse.update({
        "experiment_name": f"modern_transformer_moe_M01_selected_{selected_experiment_id}_s100",
        "run_dir": "results/30_modern_transformer_moe/M01",
        "model": "modern_transformer_moe",
        "transformer_moe_num_experts": 8,
        "transformer_moe_top_k": 2,
        "transformer_moe_first_layer": 2,
        "transformer_moe_shared_dim": shared_width,
        "transformer_moe_routed_dim": routed_width,
        "transformer_moe_router_jitter": 0.0,
        "regularization": [["moe_router", 0.01]],
    })
    return sparse


def _relative_to_repo(path: Path, repo_root: Path) -> str:
    resolved = path.resolve()
    try:
        return resolved.relative_to(repo_root.resolve()).as_posix()
    except ValueError as error:
        raise ValueError(f"selection report must be inside the repository: {resolved}") from error


def _write_yaml_temp(config: dict[str, Any], destination: Path) -> Path:
    yaml = YAML()
    yaml.default_flow_style = False
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        newline="\n",
        dir=destination.parent,
        prefix=".m01_config_",
        suffix=".tmp",
        delete=False,
    ) as stream:
        yaml.dump(config, stream)
        return Path(stream.name)


def _write_registry_temp(rows: list[dict[str, str]], destination: Path) -> Path:
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        newline="",
        dir=destination.parent,
        prefix=".m01_registry_",
        suffix=".tmp",
        delete=False,
    ) as stream:
        writer = csv.DictWriter(stream, fieldnames=audit_configs.REGISTRY_COLUMNS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
        return Path(stream.name)


def _write_bytes_temp(content: bytes, destination: Path) -> Path:
    with tempfile.NamedTemporaryFile(
        mode="wb", dir=destination.parent, prefix=".m01_rollback_", suffix=".tmp", delete=False
    ) as stream:
        stream.write(content)
        return Path(stream.name)


def _acquire_lock(lock_path: Path) -> None:
    try:
        descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as error:
        raise RuntimeError(f"M01 generation lock already exists: {lock_path}") from error
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        stream.write(f"pid={os.getpid()}\n")


def generate(selection_report_path: Path, repo_root: Path = audit_configs.REPO_ROOT) -> Path:
    """Validate selection provenance, then transactionally materialize M01 and update its registry row."""
    repo_root = Path(repo_root).resolve()
    report_path = Path(selection_report_path)
    if not report_path.is_absolute():
        report_path = repo_root / report_path
    report_relative = _relative_to_repo(report_path, repo_root)

    output_path = repo_root / M01_CONFIG_RELATIVE_PATH
    registry_path = repo_root / "src" / "modern_transformer_moe" / "registry" / "experiments.csv"
    lock_path = repo_root / LOCK_RELATIVE_PATH
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    _acquire_lock(lock_path)

    temporary_config: Path | None = None
    temporary_registry: Path | None = None
    temporary_rollback: Path | None = None
    original_registry: bytes | None = None
    config_installed = False
    try:
        if output_path.exists():
            raise FileExistsError(f"refusing to overwrite the generated M01 configuration: {output_path}")

        report = audit_configs.load_json(report_path)
        report_issues = audit_configs.audit_selection_report(report, repo_root)
        if report_issues:
            raise ValueError("invalid dense selection report: " + "; ".join(report_issues))

        rows = audit_configs.load_registry(registry_path)
        registry_issues = audit_configs.audit_registry(rows, repo_root)
        if registry_issues:
            raise ValueError("pre-generation registry audit failed: " + "; ".join(registry_issues))
        by_id = {row["exp_id"]: row for row in rows}
        m01 = by_id["M01"]
        if m01.get("status") != "awaiting_dense_selection":
            raise ValueError("M01 registry row must have status awaiting_dense_selection")

        report_metrics = {item["experiment_id"]: item for item in report["candidate_metrics"]}
        for experiment_id in ["D01", "D02", "D03"]:
            dense_row = by_id[experiment_id]
            metric_record = report_metrics[experiment_id]
            if dense_row.get("status") != "development_complete":
                raise ValueError(f"{experiment_id} must be development_complete before M01 generation")
            if dense_row.get("metrics_path") != metric_record["metrics_artifact_path"]:
                raise ValueError(f"{experiment_id} registry metrics_path disagrees with the selection report")
            if dense_row.get("metrics_sha256") != metric_record["metrics_artifact_sha256"]:
                raise ValueError(f"{experiment_id} registry metrics_sha256 disagrees with the selection report")

        selected_id = str(report["selected_experiment_id"])
        source_relative = audit_configs.DENSE_CONFIG_BY_ID[selected_id]
        source_path = repo_root / source_relative
        dense = audit_configs.load_yaml(source_path)
        sparse = build_sparse_config(dense, selected_id)
        issues = audit_configs.audit_common_contract(sparse, "generated M01", repo_root)
        issues.extend(audit_configs.audit_dense_sparse_pair(dense, sparse))
        if issues:
            raise ValueError("generated M01 failed static checks: " + "; ".join(issues))
        Config(deepcopy(sparse))

        output_path.parent.mkdir(parents=True, exist_ok=True)
        temporary_config = _write_yaml_temp(sparse, output_path)
        m01.update({
            "base_config": source_relative,
            "config_path": M01_CONFIG_RELATIVE_PATH,
            "config_sha256": audit_configs.sha256_file(temporary_config),
            "source_config_path": source_relative,
            "source_config_sha256": audit_configs.sha256_file(source_path),
            "selection_report_path": report_relative,
            "selection_report_sha256": audit_configs.sha256_file(report_path),
            "status": "planned",
            "active_feedforward_width": str(sparse["transformer_dim_feedforward"]),
            "notes": (
                f"Generated from {selected_id} after recomputing all three hash-bound epoch-30 metric artifacts."
            ),
        })
        temporary_registry = _write_registry_temp(rows, registry_path)
        original_registry = registry_path.read_bytes()

        os.replace(temporary_config, output_path)
        config_installed = True
        temporary_config = None
        os.replace(temporary_registry, registry_path)
        temporary_registry = None

        post_issues = audit_configs.audit_repository(repo_root)
        if post_issues:
            raise RuntimeError("post-generation repository audit failed: " + "; ".join(post_issues))
    except BaseException as error:
        rollback_errors: list[str] = []
        if original_registry is not None:
            try:
                if not registry_path.exists() or registry_path.read_bytes() != original_registry:
                    temporary_rollback = _write_bytes_temp(original_registry, registry_path)
                    os.replace(temporary_rollback, registry_path)
                    temporary_rollback = None
            except OSError as rollback_error:
                rollback_errors.append(f"registry rollback failed: {rollback_error}")
        if config_installed or output_path.exists():
            try:
                output_path.unlink(missing_ok=True)
            except OSError as rollback_error:
                rollback_errors.append(f"generated config rollback failed: {rollback_error}")
        if rollback_errors:
            raise RuntimeError("; ".join(rollback_errors)) from error
        raise
    finally:
        if temporary_config is not None:
            temporary_config.unlink(missing_ok=True)
        if temporary_registry is not None:
            temporary_registry.unlink(missing_ok=True)
        if temporary_rollback is not None:
            temporary_rollback.unlink(missing_ok=True)
        lock_path.unlink(missing_ok=True)
    return output_path


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Generate the selected dense model's M01 sparse pair without reading hydrological data."
    )
    parser.add_argument(
        "--selection-report",
        type=Path,
        required=True,
        help="Repository-local JSON report selecting D01, D02, or D03 using epoch-30 internal validation median NSE.",
    )
    args = parser.parse_args()
    output_path = generate(args.selection_report)
    print(f"Generated {output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
