"""Accumulate routed-expert token counts on the fixed internal-validation period."""

from __future__ import annotations

import argparse
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

import numpy as np
import torch

from neuralhydrology.evaluation import get_tester
from neuralhydrology.modelzoo.modern_causal_transformer import DroplessMoEFeedForward
from neuralhydrology.utils.config import Config
from src.modern_transformer_moe.scripts import audit_configs


OUTPUT_FILENAME = "router_diagnostics_epoch030.json"
ALLOWED_SEEDS = {100, 200, 300}
SCHEMA_VERSION = 2
VALIDATION_START_DATE = "2006-10-01"
VALIDATION_END_DATE = "2008-09-30"
ROUTER_DIAGNOSTIC_REQUIRED_KEYS = {
    "schema_version",
    "seed",
    "period",
    "checkpoint_path",
    "checkpoint_sha256",
    "run_config_path",
    "run_config_sha256",
    "scaler_path",
    "scaler_sha256",
    "basin_file_path",
    "basin_file_sha256",
    "basin_count",
    "validation_start_date",
    "validation_end_date",
    "validation_day_count",
    "validation_token_count",
    "top_k",
    "moe_layer_count",
    "total_routed_assignments",
    "dropped_token_count",
    "layers",
}
ROUTER_LAYER_REQUIRED_KEYS = {
    "layer_id",
    "validation_token_count",
    "dropped_token_count",
    "expert_token_counts",
}


@dataclass(frozen=True)
class LayerRoutingAccounting:
    """Auditable routed-token accounting for one stably named expert layer."""

    layer_id: str
    expert_token_counts: list[int]
    validation_token_count: int
    dropped_token_count: int


@dataclass(frozen=True)
class RoutingAccounting:
    """Auditable routed-token accounting accumulated during one validation pass."""

    layers: list[LayerRoutingAccounting]
    validation_token_count: int
    top_k: int
    moe_layer_count: int
    total_routed_assignments: int
    dropped_token_count: int


def _resolve_inside_repository(path: Path, repo_root: Path) -> Path:
    repo_root = Path(repo_root).resolve()
    path = Path(path)
    if not path.is_absolute():
        path = repo_root / path
    path = path.resolve()
    try:
        path.relative_to(repo_root)
    except ValueError as error:
        raise ValueError(f"path must remain inside the repository: {path}") from error
    return path


def _flatten_text(value: Any) -> list[str]:
    if isinstance(value, dict):
        return [text for child in value.values() for text in _flatten_text(child)]
    if isinstance(value, (list, tuple)):
        return [text for child in value for text in _flatten_text(child)]
    return [str(value).replace("\\", "/").lower()]


def _validate_internal_validation_config(config: dict[str, Any], run_dir: Path, repo_root: Path) -> int:
    forbidden_keys = sorted(set(config) & audit_configs.FORBIDDEN_CONFIG_KEYS)
    if forbidden_keys:
        raise ValueError(f"M01 run config contains forbidden input keys: {forbidden_keys}")
    for key in config:
        if key.lower().startswith("test_") or "evaluation" in key.lower():
            raise ValueError(f"M01 run config contains evaluation-facing key {key!r}")
    for text in _flatten_text(config):
        for fragment in audit_configs.FORBIDDEN_VALUE_FRAGMENTS:
            if fragment.lower() in text:
                raise ValueError(f"M01 run config contains forbidden value fragment {fragment!r}")

        expected = {
            "dataset": "camels_us_track0_bundle",
            "data_dir": "data/camels_us_track0_development_forcing_v01",
            "track0_supervision_dir": "data/camels_us_track0_supervision_v01",
        "number_of_basins": 531,
        "train_basin_file": audit_configs.BASIN_FILE,
        "validation_basin_file": audit_configs.BASIN_FILE,
        "train_start_date": "01/10/1999",
        "train_end_date": "30/09/2006",
        "validation_start_date": "01/10/2006",
        "validation_end_date": "30/09/2008",
        "forcings": ["maurer"],
        "dynamic_inputs": audit_configs.ALLOWED_DYNAMIC_INPUTS,
        "static_attributes": audit_configs.ALLOWED_STATIC_ATTRIBUTES,
        "target_variables": ["QObs(mm/d)"],
        "epochs": 30,
        "seq_length": 270,
        "validate_n_random_basins": 531,
        "model": "modern_transformer_moe",
        "transformer_moe_num_experts": 8,
        "transformer_moe_top_k": 2,
        "transformer_moe_first_layer": 2,
    }
    for key, expected_value in expected.items():
        actual = config.get(key)
        if key.endswith(("_dir", "_file")):
            actual = str(actual).replace("\\", "/")
        if actual != expected_value:
            raise ValueError(f"M01 run config {key}={actual!r}, expected {expected_value!r}")

    seed = config.get("seed")
    if not isinstance(seed, int) or isinstance(seed, bool) or seed not in ALLOWED_SEEDS:
        raise ValueError(f"M01 development seed must be one of {sorted(ALLOWED_SEEDS)}, got {seed!r}")
    configured_run_dir = _resolve_inside_repository(Path(str(config.get("run_dir"))), repo_root)
    if configured_run_dir != Path(run_dir).resolve():
        raise ValueError("M01 run config run_dir does not identify the supplied completed run")
    return seed


def collect_expert_token_counts(
    model: torch.nn.Module,
    evaluate: Callable[[], Any],
    *,
    expected_num_experts: int,
    expected_top_k: int,
    expected_module_count: int,
) -> tuple[RoutingAccounting, Any]:
    """Accumulate and cross-check actual routed-token diagnostics for every expert layer."""
    if expected_module_count <= 0 or expected_top_k <= 0 or expected_num_experts <= 0:
        raise ValueError("expected routed layer, top-k, and expert counts must all be positive")
    named_modules = [
        (name, module)
        for name, module in model.named_modules()
        if isinstance(module, DroplessMoEFeedForward)
    ]
    if len(named_modules) != expected_module_count:
        raise ValueError(
            f"model contains {len(named_modules)} routed feed-forward layers, expected {expected_module_count}"
        )
    if any(not name for name, _module in named_modules):
        raise ValueError("each routed feed-forward layer must have a stable non-empty module name")
    modules = [module for _name, module in named_modules]
    for module in modules:
        if module.num_experts != expected_num_experts or module.top_k != expected_top_k:
            raise ValueError("model routed-expert count or top-k does not match the bound run config")

    layer_names = {id(module): name for name, module in named_modules}
    counts_by_module = {
        id(module): torch.zeros(expected_num_experts, dtype=torch.long) for module in modules
    }
    calls = {id(module): 0 for module in modules}
    tokens_by_module = {id(module): 0 for module in modules}
    dropped_by_module = {id(module): 0 for module in modules}

    def accumulate(module: torch.nn.Module, inputs: tuple[Any, ...], output: Any) -> None:
        if len(inputs) != 1 or not isinstance(inputs[0], torch.Tensor):
            raise ValueError("routed feed-forward layer did not receive exactly one tensor input")
        input_tensor = inputs[0]
        if input_tensor.ndim < 2 or input_tensor.shape[-1] <= 0:
            raise ValueError("routed feed-forward input has no token and feature dimensions")
        token_count = input_tensor.numel() // input_tensor.shape[-1]
        if token_count <= 0:
            raise ValueError("routed feed-forward layer received no validation tokens")
        if not isinstance(output, tuple) or len(output) != 2 or not isinstance(output[1], dict):
            raise ValueError("routed feed-forward layer did not return its diagnostic dictionary")
        expert_load = output[1].get("expert_load")
        if not isinstance(expert_load, torch.Tensor) or expert_load.ndim != 1:
            raise ValueError("routed feed-forward diagnostic has no one-dimensional expert_load tensor")
        if expert_load.numel() != expected_num_experts or torch.is_floating_point(expert_load):
            raise ValueError("routed feed-forward expert_load has the wrong expert count or dtype")
        expert_load = expert_load.detach().to(device="cpu", dtype=torch.long)
        if torch.any(expert_load < 0):
            raise ValueError("routed feed-forward expert_load contains a negative count")
        if int(expert_load.sum().item()) != token_count * expected_top_k:
            raise ValueError("routed feed-forward expert_load violates tokens times top-k accounting")
        dropped_tokens = output[1].get("dropped_tokens")
        if (not isinstance(dropped_tokens, torch.Tensor) or dropped_tokens.numel() != 1
                or torch.is_floating_point(dropped_tokens)):
            raise ValueError("routed feed-forward diagnostic has no scalar integer dropped_tokens count")
        dropped_value = int(dropped_tokens.detach().to(device="cpu", dtype=torch.long).item())
        if dropped_value < 0:
            raise ValueError("routed feed-forward dropped_tokens count is negative")
        module_id = id(module)
        counts_by_module[module_id].add_(expert_load)
        calls[module_id] += 1
        tokens_by_module[module_id] += token_count
        dropped_by_module[module_id] += dropped_value

    handles = [module.register_forward_hook(accumulate) for module in modules]
    try:
        evaluation_results = evaluate()
    finally:
        for handle in handles:
            handle.remove()
    missing_calls = sum(call_count == 0 for call_count in calls.values())
    if missing_calls:
        raise ValueError(f"internal validation did not execute {missing_calls} routed feed-forward layer(s)")
    dropped_token_count = sum(dropped_by_module.values())
    if dropped_token_count != 0:
        raise ValueError(f"dropless routed layers reported {dropped_token_count} dropped token(s)")
    module_token_counts = set(tokens_by_module.values())
    if len(module_token_counts) != 1:
        raise ValueError("routed feed-forward layers did not process an identical validation-token count")
    validation_token_count = module_token_counts.pop()
    layers = []
    for name, module in named_modules:
        module_id = id(module)
        counts = [int(value) for value in counts_by_module[module_id].tolist()]
        if sum(counts) != validation_token_count * expected_top_k:
            raise ValueError(f"routed layer {name} violates tokens times top-k accounting")
        layers.append(
            LayerRoutingAccounting(
                layer_id=layer_names[module_id],
                expert_token_counts=counts,
                validation_token_count=tokens_by_module[module_id],
                dropped_token_count=dropped_by_module[module_id],
            )
        )
    total_routed_assignments = sum(sum(layer.expert_token_counts) for layer in layers)
    if total_routed_assignments <= 0:
        raise ValueError("internal validation produced no routed token assignments")
    expected_assignments = validation_token_count * expected_top_k * expected_module_count
    if total_routed_assignments != expected_assignments:
        raise ValueError("total routed assignments violate tokens times top-k times MoE-layer accounting")
    accounting = RoutingAccounting(
        layers=layers,
        validation_token_count=validation_token_count,
        top_k=expected_top_k,
        moe_layer_count=expected_module_count,
        total_routed_assignments=total_routed_assignments,
        dropped_token_count=dropped_token_count,
    )
    return accounting, evaluation_results


def _expected_basins(repo_root: Path) -> list[str]:
    basin_path = (repo_root / audit_configs.BASIN_FILE).resolve()
    if not basin_path.is_file():
        raise FileNotFoundError(f"frozen basin manifest does not exist: {basin_path}")
    basins = [line.strip() for line in basin_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(basins) != 531 or len(set(basins)) != 531:
        raise ValueError("frozen basin manifest must contain exactly 531 unique basin identifiers")
    return basins


def _validate_validation_coverage(results: Any, repo_root: Path) -> tuple[int, int]:
    """Require every frozen basin and every daily date in the declared validation period."""
    basins = _expected_basins(repo_root)
    if not isinstance(results, dict) or set(results) != set(basins):
        raise ValueError("internal validation results must contain exactly the frozen 531 basins")
    expected_dates = np.arange(
        np.datetime64(VALIDATION_START_DATE),
        np.datetime64(VALIDATION_END_DATE) + np.timedelta64(1, "D"),
        dtype="datetime64[D]",
    )
    expected_dates_ns = expected_dates.astype("datetime64[ns]")
    for basin in basins:
        basin_results = results[basin]
        if not isinstance(basin_results, dict) or len(basin_results) != 1:
            raise ValueError(f"internal validation result for basin {basin} must contain exactly one frequency")
        frequency_result = next(iter(basin_results.values()))
        dataset = frequency_result.get("xr") if isinstance(frequency_result, dict) else None
        if dataset is None or "date" not in dataset.coords:
            raise ValueError(f"internal validation result for basin {basin} has no date coordinate")
        dates = np.asarray(dataset["date"].values)
        try:
            dates_ns = dates.astype("datetime64[ns]")
        except (TypeError, ValueError) as error:
            raise ValueError(f"internal validation dates for basin {basin} are not datetimes") from error
        if dates_ns.ndim != 1 or not np.array_equal(dates_ns, expected_dates_ns):
            raise ValueError(
                f"internal validation dates for basin {basin} must be the complete daily "
                f"{VALIDATION_START_DATE} through {VALIDATION_END_DATE} period"
            )
    return len(basins), len(expected_dates)


def _find_scaler(run_dir: Path) -> Path:
    yaml_path = run_dir / "train_data" / "train_data_scaler.yml"
    pickle_path = run_dir / "train_data" / "train_data_scaler.p"
    if yaml_path.is_file():
        return yaml_path
    if pickle_path.is_file():
        return pickle_path
    raise FileNotFoundError(
        f"completed M01 run has no scaler; expected {yaml_path.relative_to(run_dir)} "
        f"or {pickle_path.relative_to(run_dir)}"
    )


def _write_new_json(path: Path, value: dict[str, Any]) -> None:
    lock_path = path.with_name(f".{path.name}.lock")
    temporary_path = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as error:
        raise RuntimeError(f"router diagnostic generation is already locked: {lock_path}") from error
    os.close(descriptor)
    try:
        if path.exists():
            raise FileExistsError(f"refusing to overwrite existing router diagnostic: {path}")
        temporary_path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(temporary_path, path)
    finally:
        temporary_path.unlink(missing_ok=True)
        lock_path.unlink(missing_ok=True)


def generate(
    run_dir: Path,
    *,
    repo_root: Path = audit_configs.REPO_ROOT,
    tester_factory: Callable[..., Any] | None = None,
) -> Path:
    """Run inference only on internal validation and write compare-compatible expert counts."""
    repo_root = Path(repo_root).resolve()
    run_dir = _resolve_inside_repository(run_dir, repo_root)
    output_path = run_dir / OUTPUT_FILENAME
    if output_path.exists():
        raise FileExistsError(f"refusing to overwrite existing router diagnostic: {output_path}")
    if not run_dir.is_dir():
        raise FileNotFoundError(f"completed M01 run directory does not exist: {run_dir}")

    run_config_path = _resolve_inside_repository(run_dir / "config.yml", repo_root)
    checkpoint_path = _resolve_inside_repository(run_dir / "model_epoch030.pt", repo_root)
    scaler_path = _resolve_inside_repository(_find_scaler(run_dir), repo_root)
    basin_file_path = _resolve_inside_repository(repo_root / audit_configs.BASIN_FILE, repo_root)
    validation_dir = _resolve_inside_repository(run_dir / "validation" / "model_epoch030", repo_root)
    required = (
        run_config_path,
        checkpoint_path,
        validation_dir / "validation_metrics.csv",
        validation_dir / "validation_results.p",
    )
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"completed M01 epoch-30 run is missing required products: {missing}")

    run_config = audit_configs.load_yaml(run_config_path)
    seed = _validate_internal_validation_config(run_config, run_dir, repo_root)
    cfg = Config(run_config_path)
    cfg.update_config({"cache_validation_data": False})
    bound_files = {
        "checkpoint": checkpoint_path,
        "run_config": run_config_path,
        "scaler": scaler_path,
        "basin_file": basin_file_path,
    }
    bound_hashes = {name: audit_configs.sha256_file(path) for name, path in bound_files.items()}
    factory = tester_factory or get_tester
    tester = factory(cfg=cfg, run_dir=run_dir, period="validation", init_model=True)
    expected_module_count = cfg.transformer_nlayers - cfg.transformer_moe_first_layer

    def evaluate_internal_validation() -> Any:
        return tester.evaluate(epoch=30, save_results=False, save_all_output=False, metrics=[])

    accounting, evaluation_results = collect_expert_token_counts(
        tester.model,
        evaluate_internal_validation,
        expected_num_experts=cfg.transformer_moe_num_experts,
        expected_top_k=cfg.transformer_moe_top_k,
        expected_module_count=expected_module_count,
    )
    basin_count, validation_day_count = _validate_validation_coverage(evaluation_results, repo_root)
    for name, path in bound_files.items():
        if audit_configs.sha256_file(path) != bound_hashes[name]:
            raise RuntimeError(f"{path.name} changed while router diagnostics were being generated")

    diagnostic = {
        "schema_version": SCHEMA_VERSION,
        "seed": seed,
        "period": audit_configs.SELECTION_PERIOD,
        "checkpoint_path": checkpoint_path.relative_to(repo_root).as_posix(),
        "checkpoint_sha256": bound_hashes["checkpoint"],
        "run_config_path": run_config_path.relative_to(repo_root).as_posix(),
        "run_config_sha256": bound_hashes["run_config"],
        "scaler_path": scaler_path.relative_to(repo_root).as_posix(),
        "scaler_sha256": bound_hashes["scaler"],
        "basin_file_path": basin_file_path.relative_to(repo_root).as_posix(),
        "basin_file_sha256": bound_hashes["basin_file"],
        "basin_count": basin_count,
        "validation_start_date": VALIDATION_START_DATE,
        "validation_end_date": VALIDATION_END_DATE,
        "validation_day_count": validation_day_count,
        "validation_token_count": accounting.validation_token_count,
        "top_k": accounting.top_k,
        "moe_layer_count": accounting.moe_layer_count,
        "total_routed_assignments": accounting.total_routed_assignments,
        "dropped_token_count": accounting.dropped_token_count,
        "layers": [
            {
                "layer_id": layer.layer_id,
                "validation_token_count": layer.validation_token_count,
                "dropped_token_count": layer.dropped_token_count,
                "expert_token_counts": layer.expert_token_counts,
            }
            for layer in accounting.layers
        ],
    }
    if set(diagnostic) != ROUTER_DIAGNOSTIC_REQUIRED_KEYS:
        raise RuntimeError("internal router-diagnostic schema drift")
    if any(set(layer) != ROUTER_LAYER_REQUIRED_KEYS for layer in diagnostic["layers"]):
        raise RuntimeError("internal per-layer router-diagnostic schema drift")
    _write_new_json(output_path, diagnostic)
    return output_path


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Count M01 routed-expert assignments using only the fixed 2006-10-01 through 2008-09-30 "
            "internal-validation period."
        )
    )
    parser.add_argument("--run-dir", type=Path, required=True, help="Completed M01 NeuralHydrology run directory.")
    args = parser.parse_args()
    output_path = generate(args.run_dir)
    print(f"Generated {output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
