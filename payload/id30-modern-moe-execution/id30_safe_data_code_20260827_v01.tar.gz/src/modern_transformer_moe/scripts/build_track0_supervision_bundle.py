"""Build a write-once, date-limited Track 0 development-supervision bundle."""

from __future__ import annotations

import argparse
import shutil
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

from src.modern_transformer_moe.scripts.track0_bundle_common import (EXPECTED_BASIN_COUNT, SCHEMA_VERSION,
                                                                    TARGET_COLUMN, builder_fingerprint,
                                                                    exact_daily_index, find_unique_file,
                                                                    publish_staged_bundle, read_basin_list,
                                                                    sha256_file, sha256_records)


def _read_area(forcing_path: Path) -> int:
    with forcing_path.open("r", encoding="utf-8") as file:
        file.readline()
        file.readline()
        area_text = file.readline().strip()
    try:
        area = int(float(area_text))
    except ValueError as error:
        raise ValueError(f"Invalid catchment area in {forcing_path}: {area_text!r}") from error
    if area <= 0:
        raise ValueError(f"Catchment area must be positive in {forcing_path}: {area}")
    return area


def _read_date_limited_discharge(path: Path, start: pd.Timestamp, end: pd.Timestamp,
                                 area: int) -> pd.DataFrame:
    dates = []
    values = []
    with path.open("r", encoding="utf-8") as file:
        for line_number, line in enumerate(file, start=1):
            fields = line.split()
            if len(fields) < 5:
                raise ValueError(f"Malformed discharge row at {path}:{line_number}")
            try:
                date = pd.Timestamp(year=int(fields[1]), month=int(fields[2]), day=int(fields[3]))
            except (TypeError, ValueError) as error:
                raise ValueError(f"Invalid discharge date at {path}:{line_number}") from error
            if date < start or date > end:
                continue
            try:
                cubic_feet_per_second = float(fields[4])
            except ValueError as error:
                raise ValueError(f"Invalid in-range discharge value at {path}:{line_number}") from error
            millimetres_per_day = 28316846.592 * cubic_feet_per_second * 86400 / (area * 10**6)
            dates.append(date)
            values.append(np.nan if cubic_feet_per_second < 0 else millimetres_per_day)
    return pd.DataFrame({"date": dates, TARGET_COLUMN: values})


def build_supervision_bundle(raw_data_dir: Path,
                             basin_file: Path,
                             start_date: str,
                             end_date: str,
                             output_dir: Path,
                             manifest_path: Path,
                             expected_basin_count: int = EXPECTED_BASIN_COUNT) -> dict:
    raw_data_dir = Path(raw_data_dir)
    basin_file = Path(basin_file)
    output_dir = Path(output_dir)
    manifest_path = Path(manifest_path)
    if output_dir.exists() or manifest_path.exists():
        raise FileExistsError(f"Refusing to overwrite output or manifest: {output_dir}, {manifest_path}")

    basins = read_basin_list(basin_file, expected_count=expected_basin_count)
    expected_dates = exact_daily_index(start_date, end_date)
    start = expected_dates.min()
    end = expected_dates.max()
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    staging_dir = Path(tempfile.mkdtemp(prefix=f".{output_dir.name}.staging-", dir=output_dir.parent))
    target_dir = staging_dir / "targets"
    target_dir.mkdir()
    source_discharge_hashes = {}
    source_area_hashes = {}
    output_hashes = {}
    try:
        forcing_root = raw_data_dir / "basin_mean_forcing" / "maurer"
        discharge_root = raw_data_dir / "usgs_streamflow"
        for basin in basins:
            forcing_path = find_unique_file(forcing_root, f"**/{basin}_*_forcing_leap.txt", "Maurer forcing file")
            discharge_path = find_unique_file(discharge_root, f"**/{basin}_streamflow_qc.txt", "streamflow file")
            source_area_hashes[basin] = sha256_file(forcing_path)
            source_discharge_hashes[basin] = sha256_file(discharge_path)
            target = _read_date_limited_discharge(discharge_path, start=start, end=end, area=_read_area(forcing_path))
            if target["date"].duplicated().any():
                raise ValueError(f"Discharge contains duplicate in-range dates for basin {basin}.")
            target = target.sort_values("date", ignore_index=True)
            actual_dates = pd.DatetimeIndex(target["date"], name="date")
            if not actual_dates.equals(expected_dates):
                missing = expected_dates.difference(actual_dates)
                extra = actual_dates.difference(expected_dates)
                raise ValueError(
                    f"Discharge coverage mismatch for basin {basin}: {len(missing)} missing and {len(extra)} extra dates."
                )
            target_path = target_dir / f"{basin}.parquet"
            target.to_parquet(target_path, index=False)
            output_hashes[basin] = sha256_file(target_path)

        manifest = {
            "schema_version": SCHEMA_VERSION,
            "bundle_type": "track0_development_supervision",
            "output_dir": str(output_dir.resolve()),
            "basin_count": len(basins),
            "basins": basins,
            "basin_list_sha256": sha256_file(basin_file),
            "date_range": {
                "start": start.date().isoformat(),
                "end": end.date().isoformat(),
                "days_per_basin": len(expected_dates),
            },
            "target_column": TARGET_COLUMN,
            "row_count": len(basins) * len(expected_dates),
            "source_hashes": {
                "streamflow_by_basin": source_discharge_hashes,
                "area_forcing_by_basin": source_area_hashes,
            },
            "outputs": {
                "target_sha256_by_basin": output_hashes,
                "target_tree_sha256": sha256_records(output_hashes.items()),
            },
            "builder": builder_fingerprint(Path(__file__)),
        }
        publish_staged_bundle(staging_dir, output_dir, manifest_path, manifest)
        return manifest
    except Exception:
        if staging_dir.exists():
            shutil.rmtree(staging_dir)
        raise


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-data-dir", type=Path, required=True)
    parser.add_argument("--basin-file", type=Path, required=True)
    parser.add_argument("--start-date", required=True)
    parser.add_argument("--end-date", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    args = parser.parse_args()
    manifest = build_supervision_bundle(
        raw_data_dir=args.raw_data_dir,
        basin_file=args.basin_file,
        start_date=args.start_date,
        end_date=args.end_date,
        output_dir=args.output_dir,
        manifest_path=args.manifest,
    )
    print(f"PASS: {manifest['row_count']} supervision rows for {manifest['basin_count']} basins")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
