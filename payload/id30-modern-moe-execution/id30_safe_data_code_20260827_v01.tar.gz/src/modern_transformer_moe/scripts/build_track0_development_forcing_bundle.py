"""Build a write-once forcing and static-attribute bundle for Track 0 development."""

from __future__ import annotations

import argparse
import shutil
import tempfile
from pathlib import Path

import pandas as pd

from neuralhydrology.datasetzoo.camelsus import load_camels_us_forcings
from src.modern_transformer_moe.scripts.track0_bundle_common import (EXPECTED_BASIN_COUNT, FORCING_VARIABLES,
                                                                    SCHEMA_VERSION, TRACK0_STATIC_ATTRIBUTES,
                                                                    builder_fingerprint, exact_daily_index,
                                                                    find_unique_file, publish_staged_bundle,
                                                                    read_basin_list, sha256_file)


def _validate_source_statics(source_statics: Path, basins: list[str]) -> None:
    frame = pd.read_csv(source_statics, dtype={"gauge_id": str})
    expected_columns = ["gauge_id", *TRACK0_STATIC_ATTRIBUTES]
    if list(frame.columns) != expected_columns:
        raise ValueError(f"Static table columns differ from the locked Track 0 schema: {list(frame.columns)}")
    if frame["gauge_id"].duplicated().any():
        raise ValueError("Static table contains duplicate basin identifiers.")
    if list(frame["gauge_id"]) != basins:
        raise ValueError("Static table basin order or membership differs from the frozen basin list.")


def build_forcing_bundle(raw_data_dir: Path,
                         source_statics: Path,
                         basin_file: Path,
                         start_date: str,
                         end_date: str,
                         output_dir: Path,
                         manifest_path: Path,
                         expected_basin_count: int = EXPECTED_BASIN_COUNT) -> dict:
    raw_data_dir = Path(raw_data_dir)
    source_statics = Path(source_statics)
    basin_file = Path(basin_file)
    output_dir = Path(output_dir)
    manifest_path = Path(manifest_path)
    if output_dir.exists() or manifest_path.exists():
        raise FileExistsError(f"Refusing to overwrite output or manifest: {output_dir}, {manifest_path}")

    basins = read_basin_list(basin_file, expected_count=expected_basin_count)
    expected_dates = exact_daily_index(start_date, end_date)
    _validate_source_statics(source_statics, basins)

    output_dir.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    staging_dir = Path(tempfile.mkdtemp(prefix=f".{output_dir.name}.staging-", dir=output_dir.parent))
    source_hashes = {}
    basin_frames = []
    try:
        forcing_root = raw_data_dir / "basin_mean_forcing" / "maurer"
        for basin in basins:
            source_path = find_unique_file(forcing_root, f"**/{basin}_*_forcing_leap.txt", "Maurer forcing file")
            source_hashes[basin] = sha256_file(source_path)
            frame, _ = load_camels_us_forcings(raw_data_dir, basin, "maurer")
            if frame.index.has_duplicates:
                raise ValueError(f"Maurer forcing contains duplicate dates for basin {basin}.")
            missing_columns = [column for column in FORCING_VARIABLES if column not in frame.columns]
            if missing_columns:
                raise ValueError(f"Maurer forcing for basin {basin} is missing {missing_columns}.")
            selected = frame.reindex(expected_dates)[FORCING_VARIABLES]
            if not selected.index.equals(expected_dates):
                raise ValueError(f"Maurer forcing date alignment failed for basin {basin}.")
            missing_dates = selected.index[selected.isna().all(axis=1)]
            if len(missing_dates):
                raise ValueError(f"Maurer forcing is missing {len(missing_dates)} required dates for basin {basin}.")
            selected = selected.reset_index()
            selected.insert(0, "gauge_id", basin)
            basin_frames.append(selected)

        forcing = pd.concat(basin_frames, ignore_index=True)
        expected_rows = len(basins) * len(expected_dates)
        if len(forcing) != expected_rows:
            raise ValueError(f"Expected {expected_rows} forcing rows, found {len(forcing)}.")
        forcing_path = staging_dir / "track0_forcing.parquet"
        forcing.to_parquet(forcing_path, index=False)

        statics_path = staging_dir / "track0_statics.csv"
        shutil.copyfile(source_statics, statics_path)
        if statics_path.read_bytes() != source_statics.read_bytes():
            raise RuntimeError("Static table byte-for-byte copy verification failed.")

        manifest = {
            "schema_version": SCHEMA_VERSION,
            "bundle_type": "track0_development_forcing",
            "output_dir": str(output_dir.resolve()),
            "basin_count": len(basins),
            "basins": basins,
            "basin_list_sha256": sha256_file(basin_file),
            "date_range": {
                "start": expected_dates.min().date().isoformat(),
                "end": expected_dates.max().date().isoformat(),
                "days_per_basin": len(expected_dates),
            },
            "forcing_variables": FORCING_VARIABLES,
            "static_attributes": TRACK0_STATIC_ATTRIBUTES,
            "row_count": len(forcing),
            "source_hashes": {
                "statics": sha256_file(source_statics),
                "maurer_forcing_by_basin": source_hashes,
            },
            "outputs": {
                "track0_forcing.parquet": {
                    "sha256": sha256_file(forcing_path),
                    "row_count": len(forcing),
                },
                "track0_statics.csv": {
                    "sha256": sha256_file(statics_path),
                    "row_count": len(basins),
                },
            },
            "builder": builder_fingerprint(Path(__file__)),
        }
        publish_staged_bundle(staging_dir, output_dir, manifest_path, manifest)
        return manifest
    except Exception:
        if staging_dir.exists():
            shutil.rmtree(staging_dir)
        raise


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-data-dir", type=Path, required=True)
    parser.add_argument("--source-statics", type=Path, required=True)
    parser.add_argument("--basin-file", type=Path, required=True)
    parser.add_argument("--start-date", required=True)
    parser.add_argument("--end-date", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    args = parser.parse_args()
    manifest = build_forcing_bundle(
        raw_data_dir=args.raw_data_dir,
        source_statics=args.source_statics,
        basin_file=args.basin_file,
        start_date=args.start_date,
        end_date=args.end_date,
        output_dir=args.output_dir,
        manifest_path=args.manifest,
    )
    print(f"PASS: {manifest['row_count']} forcing rows for {manifest['basin_count']} basins")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
