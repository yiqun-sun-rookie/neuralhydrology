"""Independently audit candidate-safe Track 0 forcing and supervision bundles."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from src.modern_transformer_moe.scripts.track0_bundle_common import (EXPECTED_BASIN_COUNT, FORCING_VARIABLES,
                                                                    SCHEMA_VERSION, TARGET_COLUMN,
                                                                    TRACK0_STATIC_ATTRIBUTES, exact_daily_index,
                                                                    sha256_file, sha256_records)


def _load_manifest(path: Path, expected_type: str) -> dict:
    manifest = json.loads(Path(path).read_text(encoding="utf-8"))
    if manifest.get("schema_version") != SCHEMA_VERSION:
        raise ValueError(f"Unsupported schema_version in {path}: {manifest.get('schema_version')}")
    if manifest.get("bundle_type") != expected_type:
        raise ValueError(f"Unexpected bundle_type in {path}: {manifest.get('bundle_type')}")
    return manifest


def _verify_builder(manifest: dict, scripts_dir: Path) -> None:
    files = manifest.get("builder", {}).get("files", {})
    if not files:
        raise ValueError("Manifest is missing builder hashes.")
    for filename, expected_hash in files.items():
        path = scripts_dir / filename
        if not path.is_file() or sha256_file(path) != expected_hash:
            raise ValueError(f"Builder SHA-256 mismatch for {filename}.")


def _verify_exact_basin_dates(frame: pd.DataFrame, basins: list[str], dates: pd.DatetimeIndex, label: str) -> None:
    frame = frame.copy()
    frame["gauge_id"] = frame["gauge_id"].astype(str).str.zfill(8)
    frame["date"] = pd.to_datetime(frame["date"], errors="raise")
    if frame[["gauge_id", "date"]].duplicated().any():
        raise ValueError(f"{label} contains duplicate basin-date rows.")
    if set(frame["gauge_id"]) != set(basins):
        raise ValueError(f"{label} basin membership differs from its manifest.")
    for basin in basins:
        actual = pd.DatetimeIndex(frame.loc[frame["gauge_id"] == basin, "date"], name="date")
        if not actual.equals(dates):
            raise ValueError(f"{label} daily coverage differs from its manifest for basin {basin}.")


def audit_bundles(forcing_manifest_path: Path,
                  supervision_manifest_path: Path,
                  expected_basin_count: int = EXPECTED_BASIN_COUNT) -> dict:
    forcing_manifest_path = Path(forcing_manifest_path)
    supervision_manifest_path = Path(supervision_manifest_path)
    forcing_manifest = _load_manifest(forcing_manifest_path, "track0_development_forcing")
    supervision_manifest = _load_manifest(supervision_manifest_path, "track0_development_supervision")
    scripts_dir = Path(__file__).resolve().parent
    _verify_builder(forcing_manifest, scripts_dir)
    _verify_builder(supervision_manifest, scripts_dir)

    forcing_basins = forcing_manifest.get("basins", [])
    supervision_basins = supervision_manifest.get("basins", [])
    if len(forcing_basins) != expected_basin_count or len(supervision_basins) != expected_basin_count:
        raise ValueError(f"Expected exactly {expected_basin_count} basins in both manifests.")
    if forcing_basins != supervision_basins:
        raise ValueError("Forcing and supervision basin lists differ.")
    if forcing_manifest.get("basin_list_sha256") != supervision_manifest.get("basin_list_sha256"):
        raise ValueError("Forcing and supervision basin-list hashes differ.")

    forcing_dir = Path(forcing_manifest["output_dir"])
    supervision_dir = Path(supervision_manifest["output_dir"])
    forcing_path = forcing_dir / "track0_forcing.parquet"
    statics_path = forcing_dir / "track0_statics.csv"
    forcing_output = forcing_manifest.get("outputs", {}).get("track0_forcing.parquet", {})
    statics_output = forcing_manifest.get("outputs", {}).get("track0_statics.csv", {})
    if sha256_file(forcing_path) != forcing_output.get("sha256"):
        raise ValueError("Forcing output SHA-256 mismatch.")
    if sha256_file(statics_path) != statics_output.get("sha256"):
        raise ValueError("Static output SHA-256 mismatch.")

    forcing = pd.read_parquet(forcing_path)
    if list(forcing.columns) != ["gauge_id", "date", *FORCING_VARIABLES]:
        raise ValueError("Forcing output schema differs from the locked schema.")
    forcing_dates = exact_daily_index(forcing_manifest["date_range"]["start"],
                                      forcing_manifest["date_range"]["end"])
    _verify_exact_basin_dates(forcing, forcing_basins, forcing_dates, "Forcing output")
    expected_forcing_rows = expected_basin_count * len(forcing_dates)
    if len(forcing) != expected_forcing_rows or forcing_manifest.get("row_count") != expected_forcing_rows:
        raise ValueError("Forcing row count differs from exact basin-by-date coverage.")
    if forcing_manifest.get("forcing_variables") != FORCING_VARIABLES:
        raise ValueError("Forcing manifest variables differ from the locked schema.")

    statics = pd.read_csv(statics_path, dtype={"gauge_id": str})
    if list(statics.columns) != ["gauge_id", *TRACK0_STATIC_ATTRIBUTES]:
        raise ValueError("Static output contains unexpected or hydro-signature columns.")
    if list(statics["gauge_id"]) != forcing_basins:
        raise ValueError("Static output basin order or membership differs from its manifest.")
    if forcing_manifest.get("static_attributes") != TRACK0_STATIC_ATTRIBUTES:
        raise ValueError("Static manifest attributes differ from the locked schema.")

    supervision_dates = exact_daily_index(supervision_manifest["date_range"]["start"],
                                          supervision_manifest["date_range"]["end"])
    declared_hashes = supervision_manifest.get("outputs", {}).get("target_sha256_by_basin", {})
    if set(declared_hashes) != set(supervision_basins):
        raise ValueError("Supervision manifest target hashes do not cover the exact basin list.")
    actual_hashes = {}
    supervision_rows = []
    for basin in supervision_basins:
        target_path = supervision_dir / "targets" / f"{basin}.parquet"
        actual_hash = sha256_file(target_path)
        actual_hashes[basin] = actual_hash
        if actual_hash != declared_hashes[basin]:
            raise ValueError(f"Supervision output SHA-256 mismatch for basin {basin}.")
        target = pd.read_parquet(target_path)
        if list(target.columns) != ["date", TARGET_COLUMN]:
            raise ValueError(f"Supervision schema differs from the locked schema for basin {basin}.")
        target.insert(0, "gauge_id", basin)
        supervision_rows.append(target)
    if sha256_records(actual_hashes.items()) != supervision_manifest.get("outputs", {}).get("target_tree_sha256"):
        raise ValueError("Supervision output tree SHA-256 mismatch.")
    supervision = pd.concat(supervision_rows, ignore_index=True)
    _verify_exact_basin_dates(supervision, supervision_basins, supervision_dates, "Supervision output")
    expected_supervision_rows = expected_basin_count * len(supervision_dates)
    if len(supervision) != expected_supervision_rows or supervision_manifest.get("row_count") != expected_supervision_rows:
        raise ValueError("Supervision row count differs from exact basin-by-date coverage.")
    if supervision_manifest.get("target_column") != TARGET_COLUMN:
        raise ValueError("Supervision manifest target differs from the locked schema.")
    if supervision_dates.min() < pd.Timestamp("1999-10-01") and expected_basin_count == EXPECTED_BASIN_COUNT:
        raise ValueError("Production supervision begins before the allowed development date.")
    if supervision_dates.max() > pd.Timestamp("2008-09-30") and expected_basin_count == EXPECTED_BASIN_COUNT:
        raise ValueError("Production supervision ends after the allowed development date.")

    return {
        "status": "PASS",
        "basin_count": expected_basin_count,
        "forcing_date_min": forcing_dates.min().date().isoformat(),
        "forcing_date_max": forcing_dates.max().date().isoformat(),
        "forcing_row_count": len(forcing),
        "supervision_date_min": supervision_dates.min().date().isoformat(),
        "supervision_date_max": supervision_dates.max().date().isoformat(),
        "supervision_row_count": len(supervision),
        "forcing_manifest_sha256": sha256_file(forcing_manifest_path),
        "supervision_manifest_sha256": sha256_file(supervision_manifest_path),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--forcing-manifest", type=Path, required=True)
    parser.add_argument("--supervision-manifest", type=Path, required=True)
    args = parser.parse_args()
    report = audit_bundles(args.forcing_manifest, args.supervision_manifest)
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
