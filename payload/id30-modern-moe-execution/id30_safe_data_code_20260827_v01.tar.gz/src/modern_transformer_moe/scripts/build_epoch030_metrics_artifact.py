"""Build a hash-bound epoch-30 validation artifact from one real NeuralHydrology run."""

from __future__ import annotations

import argparse
import json
import os
import statistics
from pathlib import Path
from typing import Any

import torch

from src.modern_transformer_moe.scripts import audit_configs


def _resolve_run_dir(run_dir: Path, repo_root: Path) -> Path:
    repo_root = Path(repo_root).resolve()
    run_dir = Path(run_dir)
    if not run_dir.is_absolute():
        run_dir = repo_root / run_dir
    run_dir = run_dir.resolve()
    try:
        run_dir.relative_to(repo_root)
    except ValueError as error:
        raise ValueError(f"run_dir must be inside the repository: {run_dir}") from error
    if not run_dir.is_dir():
        raise FileNotFoundError(f"run_dir does not exist: {run_dir}")
    return run_dir


def _repository_relative(path: Path, repo_root: Path) -> str:
    return Path(path).resolve().relative_to(Path(repo_root).resolve()).as_posix()


def _bound_record(path: Path, prefix: str, repo_root: Path) -> dict[str, str]:
    if not path.is_file():
        raise FileNotFoundError(f"required run product does not exist: {path}")
    return {
        f"{prefix}_path": _repository_relative(path, repo_root),
        f"{prefix}_sha256": audit_configs.sha256_file(path),
    }


def _write_new_json(path: Path, artifact: dict[str, Any]) -> None:
    lock_path = path.with_name(f".{path.name}.lock")
    temporary_path = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        lock_descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as error:
        raise RuntimeError(f"artifact generation is already locked: {lock_path}") from error
    os.close(lock_descriptor)
    try:
        if path.exists():
            raise FileExistsError(f"refusing to overwrite existing metrics artifact: {path}")
        temporary_path.write_text(json.dumps(artifact, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(temporary_path, path)
    finally:
        temporary_path.unlink(missing_ok=True)
        lock_path.unlink(missing_ok=True)


def preflight(
    experiment_id: str,
    run_dir: Path,
    repo_root: Path = audit_configs.REPO_ROOT,
    source_config_path: Path | None = None,
) -> dict[str, Any]:
    """Read and validate an epoch-30 run without writing or changing lifecycle state."""
    repo_root = Path(repo_root).resolve()
    allowed_experiment_ids = {*audit_configs.CONFIG_BY_ID, "SELECTED_DENSE"}
    if experiment_id not in allowed_experiment_ids:
        choices = sorted(allowed_experiment_ids)
        raise ValueError(f"experiment_id must be one of {choices}, got {experiment_id!r}")
    if experiment_id == "SELECTED_DENSE" and source_config_path is None:
        raise ValueError("SELECTED_DENSE requires an explicit derived source_config_path")
    run_dir = _resolve_run_dir(run_dir, repo_root)

    if source_config_path is None:
        source_config_path = repo_root / audit_configs.CONFIG_BY_ID[experiment_id]
    else:
        source_config_path = Path(source_config_path)
        if not source_config_path.is_absolute():
            source_config_path = repo_root / source_config_path
        source_config_path = source_config_path.resolve()
        try:
            source_config_path.relative_to(repo_root)
        except ValueError as error:
            raise ValueError(f"source_config_path must be inside the repository: {source_config_path}") from error
    run_config_path = run_dir / "config.yml"
    checkpoint_path = run_dir / "model_epoch030.pt"
    validation_metrics_path = run_dir / "validation" / "model_epoch030" / "validation_metrics.csv"
    validation_results_path = run_dir / "validation" / "model_epoch030" / "validation_results.p"
    source_config = audit_configs.load_yaml(source_config_path)
    expected_run_root = audit_configs._resolve_config_path(source_config.get("run_dir"), repo_root)
    if expected_run_root is None or run_dir.parent != expected_run_root:
        raise ValueError(f"run_dir must be one direct NeuralHydrology run below {expected_run_root}")

    for required_path in (run_config_path, checkpoint_path, validation_metrics_path, validation_results_path):
        if not required_path.is_file():
            raise FileNotFoundError(f"required run product does not exist: {required_path}")
    run_config = audit_configs.load_yaml(run_config_path)
    config_issues = audit_configs.audit_run_config_snapshot(source_config, run_config, run_dir, repo_root)
    if config_issues:
        raise ValueError("run config snapshot disagrees with the source config: " + "; ".join(config_issues))

    try:
        try:
            checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=True)
        except TypeError:
            checkpoint = torch.load(checkpoint_path, map_location="cpu")
    except Exception as error:
        raise ValueError(f"epoch-30 checkpoint cannot be loaded: {error}") from error
    if (not isinstance(checkpoint, dict) or not checkpoint
            or any(not isinstance(name, str) or not isinstance(value, torch.Tensor)
                   for name, value in checkpoint.items())):
        raise ValueError("epoch-30 checkpoint must be a non-empty tensor state_dict")

    basin_nse = audit_configs.load_validation_nse_csv(validation_metrics_path, repo_root)
    results_basin_nse = audit_configs.load_validation_results_nse(validation_results_path, repo_root)
    mismatched_basins = [
        basin
        for basin in basin_nse
        if abs(basin_nse[basin] - results_basin_nse[basin]) > 1e-12
    ]
    if mismatched_basins:
        raise ValueError(
            "validation metrics CSV disagrees with NSE recomputed from y_obs/y_sim for "
            f"{len(mismatched_basins)} basin(s)"
        )
    return {
        "run_dir": run_dir,
        "source_config_path": source_config_path,
        "run_config_path": run_config_path,
        "checkpoint_path": checkpoint_path,
        "validation_metrics_path": validation_metrics_path,
        "validation_results_path": validation_results_path,
        "basin_nse": basin_nse,
    }


def build(
    experiment_id: str,
    run_dir: Path,
    repo_root: Path = audit_configs.REPO_ROOT,
    source_config_path: Path | None = None,
) -> Path:
    """Validate a real development run and create ``epoch030_metrics.json`` beside its checkpoint."""
    repo_root = Path(repo_root).resolve()
    checked = preflight(experiment_id, run_dir, repo_root, source_config_path)
    run_dir = checked["run_dir"]
    output_path = run_dir / "epoch030_metrics.json"
    basin_nse = checked["basin_nse"]
    artifact: dict[str, Any] = {
        "experiment_id": experiment_id,
        **_bound_record(checked["source_config_path"], "source_config", repo_root),
        **_bound_record(checked["run_config_path"], "run_config", repo_root),
        **_bound_record(checked["checkpoint_path"], "checkpoint", repo_root),
        **_bound_record(checked["validation_metrics_path"], "validation_metrics", repo_root),
        **_bound_record(checked["validation_results_path"], "validation_results", repo_root),
        "epoch": 30,
        "metric": "NSE",
        "period": audit_configs.SELECTION_PERIOD,
        "basin_nse": basin_nse,
        "median_nse": float(statistics.median(basin_nse.values())),
    }
    issues, _ = audit_configs.audit_metrics_artifact(
        artifact,
        experiment_id,
        repo_root,
        artifact_path=output_path,
        expected_source_config_path=_repository_relative(checked["source_config_path"], repo_root),
    )
    if issues:
        raise ValueError("generated metrics artifact failed its own audit: " + "; ".join(issues))
    _write_new_json(output_path, artifact)
    return output_path


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Build a tamper-evident epoch-30 metric artifact from a completed dense run."
    )
    parser.add_argument(
        "--experiment-id", choices=sorted({*audit_configs.CONFIG_BY_ID, "SELECTED_DENSE"}), required=True
    )
    parser.add_argument("--source-config-path", type=Path,
                        help="Explicit repository-local derived config for development seeds 200/300.")
    parser.add_argument(
        "--run-dir",
        type=Path,
        required=True,
        help="Actual NeuralHydrology run directory containing config.yml and model_epoch030.pt.",
    )
    args = parser.parse_args()
    output_path = build(args.experiment_id, args.run_dir, source_config_path=args.source_config_path)
    print(f"Generated {output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
