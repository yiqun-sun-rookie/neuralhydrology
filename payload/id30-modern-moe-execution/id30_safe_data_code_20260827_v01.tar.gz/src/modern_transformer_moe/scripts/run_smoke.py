"""Launch the paired modern Transformer technical smoke runs on CPU.

The launcher materializes run-specific config copies so repeated invocations do
not collide with NeuralHydrology's minute-resolution output folder names. It
prints and records the exact generated run directories for downstream audits.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from neuralhydrology.utils.config import Config
from src.modern_transformer_moe.scripts import audit_configs
from src.modern_transformer_moe.scripts.candidate_safe_data import (assert_safe_data_unchanged, audit_access_log,
                                                                   capture_safe_data_snapshot)


REPO_ROOT = Path(__file__).resolve().parents[3]
SMOKE_CONFIG_DIR = REPO_ROOT / "src" / "modern_transformer_moe" / "configs" / "smoke"
SOURCE_CONFIGS = {
    "dense": SMOKE_CONFIG_DIR / "smoke_dense.yml",
    "moe": SMOKE_CONFIG_DIR / "smoke_moe.yml",
}
OUTPUT_ROOT = REPO_ROOT / "results" / "30_modern_transformer_moe" / "smoke" / "invocations"
CRITICAL_SOURCE_FILES = (
    REPO_ROOT / "neuralhydrology" / "nh_run.py",
    REPO_ROOT / "neuralhydrology" / "datasetzoo" / "__init__.py",
    REPO_ROOT / "neuralhydrology" / "datasetzoo" / "basedataset.py",
    REPO_ROOT / "neuralhydrology" / "datasetzoo" / "camelsus.py",
    REPO_ROOT / "neuralhydrology" / "datasetzoo" / "camelsus_track0_bundle.py",
    REPO_ROOT / "neuralhydrology" / "modelzoo" / "__init__.py",
    REPO_ROOT / "neuralhydrology" / "modelzoo" / "head.py",
    REPO_ROOT / "neuralhydrology" / "modelzoo" / "inputlayer.py",
    REPO_ROOT / "neuralhydrology" / "modelzoo" / "modern_causal_transformer.py",
    REPO_ROOT / "neuralhydrology" / "training" / "__init__.py",
    REPO_ROOT / "neuralhydrology" / "training" / "basetrainer.py",
    REPO_ROOT / "neuralhydrology" / "training" / "loss.py",
    REPO_ROOT / "neuralhydrology" / "training" / "regularization.py",
    REPO_ROOT / "neuralhydrology" / "utils" / "config.py",
    REPO_ROOT / "src" / "modern_transformer_moe" / "scripts" / "audit_track0_supervision_bundle.py",
    REPO_ROOT / "src" / "modern_transformer_moe" / "scripts" / "candidate_safe_data.py",
    REPO_ROOT / "src" / "modern_transformer_moe" / "scripts" / "track0_bundle_common.py",
    Path(__file__).resolve(),
    SMOKE_CONFIG_DIR / "smoke_basins.txt",
    SOURCE_CONFIGS["dense"],
    SOURCE_CONFIGS["moe"],
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as file:
        for block in iter(lambda: file.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _capture_source_snapshot() -> dict:
    """Bind a smoke invocation to dirty-worktree source content before training starts."""
    missing = [path for path in CRITICAL_SOURCE_FILES if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"Critical smoke source files are missing: {missing}")
    revision = subprocess.run(["git", "rev-parse", "HEAD"], cwd=REPO_ROOT, check=True, capture_output=True,
                              text=True).stdout.strip()
    git_status = subprocess.run(["git", "status", "--porcelain"], cwd=REPO_ROOT, check=True, capture_output=True,
                                text=True).stdout.splitlines()
    return {
        "captured_at_utc": datetime.now(timezone.utc).isoformat(),
        "git_revision": revision,
        "dirty_worktree": bool(git_status),
        "git_changed_path_count": len(git_status),
        "files": {
            path.resolve().relative_to(REPO_ROOT.resolve()).as_posix(): _sha256(path) for path in CRITICAL_SOURCE_FILES
        },
    }


def _write_manifest(path: Path, manifest: dict, *, create: bool) -> None:
    """Write the preflight manifest once, then atomically extend only this invocation's manifest."""
    if create:
        with path.open("x", encoding="utf-8") as file:
            json.dump(manifest, file, indent=2, ensure_ascii=False)
            file.write("\n")
        return
    temporary_path = path.with_suffix(".json.tmp")
    with temporary_path.open("x", encoding="utf-8") as file:
        json.dump(manifest, file, indent=2, ensure_ascii=False)
        file.write("\n")
    os.replace(temporary_path, path)


def _new_directories(path: Path, before: set[Path]) -> list[Path]:
    if not path.is_dir():
        return []
    return sorted(candidate.resolve() for candidate in path.iterdir() if candidate.is_dir())


def _materialize_runtime_config(source: Path, destination: Path, run_root: Path, label: str,
                                run_id: str) -> Path:
    config = Config(source)
    config.update_config({
        "device": "cpu",
        "experiment_name": f"{config.experiment_name}_{run_id}",
        "run_dir": run_root / label,
    })
    destination.parent.mkdir(parents=True, exist_ok=False)
    config.dump_config(destination.parent, destination.name)
    return destination


def _launch(config_path: Path, output_base: Path, data_access_log: Path) -> tuple[Path, float, list[str]]:
    before = {candidate.resolve() for candidate in output_base.iterdir()} if output_base.is_dir() else set()
    command = [
        sys.executable,
        "-m",
        "neuralhydrology.nh_run",
        "train",
        "--config-file",
        str(config_path),
        "--gpu",
        "-1",
    ]
    environment = os.environ.copy()
    environment.update({
        "CUDA_VISIBLE_DEVICES": "",
        "MKL_NUM_THREADS": "1",
        "OMP_NUM_THREADS": "1",
        "PYTHONHASHSEED": "100",
        "TQDM_DISABLE": "1",
        "NEURALHYDROLOGY_DATA_ACCESS_LOG": str(data_access_log),
    })

    started = time.perf_counter()
    completed = subprocess.run(command, cwd=REPO_ROOT, env=environment, check=False)
    elapsed_seconds = time.perf_counter() - started
    if completed.returncode != 0:
        raise RuntimeError(f"Training failed with exit code {completed.returncode}: {' '.join(command)}")

    created = [candidate for candidate in _new_directories(output_base, before) if candidate not in before]
    if len(created) != 1:
        raise RuntimeError(f"Expected exactly one new run directory below {output_base}, found {created}.")
    return created[0], elapsed_seconds, command


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--run-id",
        default=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ"),
        help="Unique identifier used for the isolated invocation directory.",
    )
    args = parser.parse_args()
    if re.fullmatch(r"[A-Za-z0-9_.-]+", args.run_id) is None:
        raise ValueError("--run-id may contain only letters, digits, dot, underscore, and hyphen.")

    invocation_dir = OUTPUT_ROOT / args.run_id
    if invocation_dir.exists():
        raise FileExistsError(f"Refusing to overwrite existing smoke invocation: {invocation_dir}")
    source_snapshot = _capture_source_snapshot()
    safe_config = audit_configs.load_yaml(SOURCE_CONFIGS["dense"])
    safe_data_snapshot = capture_safe_data_snapshot(REPO_ROOT, safe_config)
    runtime_config_dir = invocation_dir / "runtime_configs"
    run_root = invocation_dir / "runs"

    invocation_dir.mkdir(parents=True, exist_ok=False)
    manifest_path = invocation_dir / "run_manifest.json"
    data_access_log = invocation_dir / "data_access.jsonl"
    manifest = {
        "schema_version": 2,
        "run_id": args.run_id,
        "status": "RUNNING",
        "device": "cpu",
        "epochs": 1,
        "max_updates_per_epoch": 1,
        "source_snapshot": source_snapshot,
        "data_contract": safe_data_snapshot,
        "runs": {},
    }
    # Persist the dirty-worktree source hashes before either training process starts.
    _write_manifest(manifest_path, manifest, create=True)

    for label, source in SOURCE_CONFIGS.items():
        runtime_config = runtime_config_dir / label / source.name
        _materialize_runtime_config(source, runtime_config, run_root, label, args.run_id)
        output_base = run_root / label
        generated_run_dir, elapsed_seconds, command = _launch(runtime_config, output_base, data_access_log)
        manifest["runs"][label] = {
            "source_config": str(source.relative_to(REPO_ROOT)),
            "source_config_sha256": _sha256(source),
            "runtime_config": str(runtime_config.relative_to(REPO_ROOT)),
            "runtime_config_sha256": _sha256(runtime_config),
            "command": command,
            "elapsed_seconds": elapsed_seconds,
            "run_dir": str(generated_run_dir.relative_to(REPO_ROOT)),
        }
        manifest["status"] = f"{label.upper()}_COMPLETE"
        _write_manifest(manifest_path, manifest, create=False)
        print(f"{label}: {generated_run_dir}", flush=True)

    manifest["postflight_data_contract"] = assert_safe_data_unchanged(safe_data_snapshot, REPO_ROOT, safe_config)
    manifest["data_access"] = {
        "path": str(data_access_log.relative_to(REPO_ROOT)),
        **audit_access_log(data_access_log, safe_data_snapshot["forcing_dir"], safe_data_snapshot["supervision_dir"]),
    }
    manifest["status"] = "COMPLETE"
    _write_manifest(manifest_path, manifest, create=False)
    print(f"manifest: {manifest_path}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
