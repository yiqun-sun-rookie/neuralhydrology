"""Read-only static audit for the modern Transformer development family."""

from __future__ import annotations

import csv
import hashlib
import json
import math
import pickle
import statistics
from pathlib import Path
from typing import Any

from ruamel.yaml import YAML

from neuralhydrology.evaluation.metrics import nse
from neuralhydrology.utils.config import Config


REPO_ROOT = Path(__file__).resolve().parents[3]
IDEA_DIR = REPO_ROOT / "src" / "modern_transformer_moe"
CONFIG_DIR = IDEA_DIR / "configs"
REGISTRY_PATH = IDEA_DIR / "registry" / "experiments.csv"

BASE_CONFIG_FILE = "base_development.yml"
RUN_CONFIG_FILES = (
    "baseline_lstm_s100.yml",
    "dense_d128_l4_s100.yml",
    "dense_d256_l4_s100.yml",
    "dense_d256_l8_s100.yml",
)
OPTIONAL_SPARSE_CONFIG_FILE = "moe_selected_s100.yml"
DENSE_CONFIG_BY_ID = {
    "D01": "src/modern_transformer_moe/configs/dense_d128_l4_s100.yml",
    "D02": "src/modern_transformer_moe/configs/dense_d256_l4_s100.yml",
    "D03": "src/modern_transformer_moe/configs/dense_d256_l8_s100.yml",
}
CONFIG_BY_ID = {
    "B01": "src/modern_transformer_moe/configs/baseline_lstm_s100.yml",
    **DENSE_CONFIG_BY_ID,
    "M01": "src/modern_transformer_moe/configs/moe_selected_s100.yml",
}

BASIN_FILE = "src/fair_benchmark/frozen/track0_forcing_only_basins.txt"
ALLOWED_DYNAMIC_INPUTS = [
    "PRCP(mm/day)",
    "Tmin(C)",
    "Tmax(C)",
    "SRAD(W/m2)",
    "Vp(Pa)",
]
ALLOWED_STATIC_ATTRIBUTES = [
    "p_mean",
    "pet_mean",
    "aridity",
    "p_seasonality",
    "frac_snow",
    "high_prec_freq",
    "high_prec_dur",
    "low_prec_freq",
    "low_prec_dur",
    "elev_mean",
    "slope_mean",
    "area_gages2",
    "frac_forest",
    "lai_max",
    "lai_diff",
    "gvf_max",
    "gvf_diff",
    "soil_depth_pelletier",
    "soil_depth_statsgo",
    "soil_porosity",
    "soil_conductivity",
    "max_water_content",
    "sand_frac",
    "silt_frac",
    "clay_frac",
    "carbonate_rocks_frac",
    "geol_permeability",
]

COMMON_EXPECTED = {
    "dataset": "camels_us_track0_bundle",
    "data_dir": "data/camels_us_track0_development_forcing_v01",
    "track0_supervision_dir": "data/camels_us_track0_supervision_v01",
    "number_of_basins": 531,
    "train_basin_file": BASIN_FILE,
    "validation_basin_file": BASIN_FILE,
    "train_start_date": "01/10/1999",
    "train_end_date": "30/09/2006",
    "validation_start_date": "01/10/2006",
    "validation_end_date": "30/09/2008",
    "forcings": ["maurer"],
    "dynamic_inputs": ALLOWED_DYNAMIC_INPUTS,
    "target_variables": ["QObs(mm/d)"],
    "static_attributes": ALLOWED_STATIC_ATTRIBUTES,
    "head": "regression",
    "output_activation": "linear",
    "epochs": 30,
    "seq_length": 270,
    "predict_last_n": 1,
    "clip_gradient_norm": 1.0,
    "seed": 100,
    "loss": "NSE",
    "validate_every": 1,
    "validate_n_random_basins": 531,
    "metrics": ["NSE"],
    "save_weights_every": 10,
    "save_all_output": False,
    "save_train_data": False,
}

FORBIDDEN_CONFIG_KEYS = {
    "additional_feature_files",
    "autoregressive_inputs",
    "base_run_dir",
    "checkpoint_path",
    "concept_inputs",
    "continue_from_epoch",
    "custom_normalization",
    "evolving_attributes",
    "finetune_modules",
    "forecast_inputs",
    "hindcast_inputs",
    "lagged_features",
    "mass_inputs",
    "per_basin_test_periods_file",
    "per_basin_train_periods_file",
    "per_basin_validation_periods_file",
    "test_basin_file",
    "test_end_date",
    "test_start_date",
    "train_data_file",
}
FORBIDDEN_VALUE_FRAGMENTS = (
    "camels_hydro",
    "usgs_streamflow",
    "_obs_eval",
    "01/10/1989",
    "30/09/1999",
    "1989-10-01",
    "1999-09-30",
)

PAIR_ALLOWED_DIFFERENCES = {
    "experiment_name",
    "model",
    "regularization",
    "run_dir",
    "transformer_moe_first_layer",
    "transformer_moe_num_experts",
    "transformer_moe_router_jitter",
    "transformer_moe_routed_dim",
    "transformer_moe_shared_dim",
    "transformer_moe_top_k",
}

EXPECTED_REGISTRY_IDS = ["B01", "D01", "D02", "D03", "M01"]
REGISTRY_COLUMNS = (
    "exp_id",
    "type",
    "hypothesis",
    "base_config",
    "changed_factor",
    "fixed_factors",
    "seed",
    "config_path",
    "config_sha256",
    "source_config_path",
    "source_config_sha256",
    "selection_report_path",
    "selection_report_sha256",
    "run_dir",
    "status",
    "best_checkpoint",
    "checkpoint_sha256",
    "metrics_path",
    "metrics_sha256",
    "total_parameters",
    "active_parameters_per_token",
    "active_feedforward_width",
    "paper_name",
    "notes",
)
REQUIRED_REGISTRY_COLUMNS = set(REGISTRY_COLUMNS)

SELECTION_REPORT_REQUIRED_KEYS = {
    "candidate_experiment_ids",
    "candidate_metrics",
    "selected_experiment_id",
    "selected_config_path",
    "selected_config_sha256",
    "selection_metric",
    "selection_epoch",
    "selection_period",
    "selection_rule",
}
SELECTION_PERIOD = {"start": "2006-10-01", "end": "2008-09-30"}
SELECTION_RULE = "highest_median_validation_NSE_at_epoch_30_tie_break_D01_D02_D03"
CANDIDATE_METRIC_KEYS = {
    "experiment_id",
    "median_nse",
    "metrics_artifact_path",
    "metrics_artifact_sha256",
}
METRICS_ARTIFACT_REQUIRED_KEYS = {
    "experiment_id",
    "source_config_path",
    "source_config_sha256",
    "run_config_path",
    "run_config_sha256",
    "checkpoint_path",
    "checkpoint_sha256",
    "validation_metrics_path",
    "validation_metrics_sha256",
    "validation_results_path",
    "validation_results_sha256",
    "epoch",
    "metric",
    "period",
    "basin_nse",
    "median_nse",
}
RUN_CONFIG_ALLOWED_DIFFERENCE_KEYS = {
    "commit_hash",
    "img_log_dir",
    "package_version",
    "run_dir",
    "train_dir",
}


def load_yaml(path: Path) -> dict[str, Any]:
    """Load one YAML file without constructing a training dataset."""
    yaml = YAML(typ="safe")
    with Path(path).open("r", encoding="utf-8") as stream:
        config = yaml.load(stream)
    if not isinstance(config, dict):
        raise ValueError(f"{path} must contain a YAML mapping")
    return config


def load_json(path: Path) -> dict[str, Any]:
    """Load one JSON selection report."""
    with Path(path).open("r", encoding="utf-8") as stream:
        value = json.load(stream)
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return value


def load_registry(path: Path = REGISTRY_PATH) -> list[dict[str, str]]:
    """Load the experiment registry as strings."""
    with Path(path).open("r", encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        if tuple(reader.fieldnames or ()) != REGISTRY_COLUMNS:
            missing = sorted(REQUIRED_REGISTRY_COLUMNS - set(reader.fieldnames or []))
            extra = sorted(set(reader.fieldnames or []) - REQUIRED_REGISTRY_COLUMNS)
            raise ValueError(f"registry columns/order mismatch; missing={missing}, extra={extra}")
        return list(reader)


def sha256_file(path: Path) -> str:
    """Return the byte-level SHA-256 of a file."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def resolve_repository_file(value: Any, repo_root: Path = REPO_ROOT) -> Path:
    """Resolve a repository-relative artifact path and reject path traversal or external files."""
    if not isinstance(value, str) or not value or Path(value).is_absolute():
        raise ValueError(f"artifact path must be a non-empty repository-relative string, got {value!r}")
    repo_root = Path(repo_root).resolve()
    resolved = (repo_root / value).resolve()
    try:
        resolved.relative_to(repo_root)
    except ValueError as error:
        raise ValueError(f"artifact path escapes the repository: {value!r}") from error
    return resolved


def _is_finite_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value))


def _expected_basins(repo_root: Path) -> list[str]:
    basin_path = Path(repo_root) / BASIN_FILE
    if not basin_path.is_file():
        raise ValueError(f"basin manifest does not exist: {basin_path}")
    basins = [line.strip() for line in basin_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(basins) != 531 or len(set(basins)) != 531:
        raise ValueError("basin manifest must contain exactly 531 unique identifiers")
    return basins


def load_validation_nse_csv(path: Path, repo_root: Path = REPO_ROOT) -> dict[str, float]:
    """Read the exact single-target, single-frequency CSV emitted by ``metrics_to_dataframe``."""
    path = Path(path)
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames != ["basin", "NSE"]:
            raise ValueError(
                f"validation metrics columns must be exactly ['basin', 'NSE'], got {reader.fieldnames!r}"
            )
        rows = list(reader)

    expected_basins = _expected_basins(repo_root)
    if len(rows) != len(expected_basins):
        raise ValueError(f"validation metrics contains {len(rows)} rows, expected {len(expected_basins)}")

    values: dict[str, float] = {}
    for row_number, row in enumerate(rows, start=2):
        if set(row) != {"basin", "NSE"}:
            raise ValueError(f"validation metrics row {row_number} has unexpected columns")
        basin = row["basin"]
        if not isinstance(basin, str) or not basin or basin != basin.strip():
            raise ValueError(f"validation metrics row {row_number} has an invalid basin identifier")
        if basin in values:
            raise ValueError(f"validation metrics contains duplicate basin identifier {basin!r}")
        try:
            value = float(row["NSE"])
        except (TypeError, ValueError) as error:
            raise ValueError(f"validation metrics row {row_number} has a non-numeric NSE") from error
        if not math.isfinite(value):
            raise ValueError(f"validation metrics row {row_number} has a non-finite NSE")
        values[basin] = value

    if set(values) != set(expected_basins):
        missing = sorted(set(expected_basins) - set(values))
        extra = sorted(set(values) - set(expected_basins))
        raise ValueError(
            f"validation metrics basin identifiers mismatch; missing_count={len(missing)}, extra_count={len(extra)}"
        )
    return {basin: values[basin] for basin in expected_basins}


def load_validation_results_nse(path: Path, repo_root: Path = REPO_ROOT) -> dict[str, float]:
    """Recompute every basin's NSE directly from the saved NeuralHydrology result time series."""
    with Path(path).open("rb") as stream:
        results = pickle.load(stream)
    if not isinstance(results, dict):
        raise ValueError("validation results pickle must contain a basin-keyed dictionary")

    expected_basins = _expected_basins(repo_root)
    if set(results) != set(expected_basins):
        missing = sorted(set(expected_basins) - set(results))
        extra = sorted(set(results) - set(expected_basins))
        raise ValueError(
            f"validation results basin identifiers mismatch; missing_count={len(missing)}, extra_count={len(extra)}"
        )

    target = "QObs(mm/d)"
    recomputed: dict[str, float] = {}
    dataset_nse_cache: dict[int, float] = {}
    for basin in expected_basins:
        basin_results = results[basin]
        if not isinstance(basin_results, dict) or len(basin_results) != 1:
            raise ValueError(f"validation results for basin {basin} must contain exactly one frequency")
        frequency_results = next(iter(basin_results.values()))
        if not isinstance(frequency_results, dict) or "xr" not in frequency_results:
            raise ValueError(f"validation results for basin {basin} is missing its xarray dataset")
        dataset = frequency_results["xr"]
        dataset_identity = id(dataset)
        if dataset_identity in dataset_nse_cache:
            value = dataset_nse_cache[dataset_identity]
        else:
            observed_name = f"{target}_obs"
            simulated_name = f"{target}_sim"
            try:
                single_step = dataset.isel(time_step=slice(-1, None)).stack(datetime=["date", "time_step"])
                observed = single_step[observed_name]
                simulated = single_step[simulated_name]
            except (KeyError, TypeError) as error:
                raise ValueError(
                    f"validation results for basin {basin} must contain {observed_name!r} and {simulated_name!r}"
                ) from error
            if "samples" in simulated.dims:
                simulated = simulated.mean(dim="samples")
            try:
                value = float(nse(observed, simulated))
            except (RuntimeError, TypeError, ValueError) as error:
                raise ValueError(f"cannot recompute NSE from validation results for basin {basin}: {error}") from error
            dataset_nse_cache[dataset_identity] = value
        if not math.isfinite(value):
            raise ValueError(f"recomputed validation-results NSE is non-finite for basin {basin}")
        stored_value = frequency_results.get("NSE")
        if not _is_finite_number(stored_value):
            raise ValueError(f"validation results for basin {basin} has no finite stored NSE")
        if not math.isclose(float(stored_value), value, rel_tol=0.0, abs_tol=1e-12):
            raise ValueError(f"stored validation-results NSE disagrees with y_obs/y_sim for basin {basin}")
        recomputed[basin] = value
    return recomputed


def _normalize_config_value(key: str, value: Any) -> Any:
    if key.endswith(("_dir", "_path", "_file")):
        return _relative_text(value)
    if key.endswith("_files") and isinstance(value, list):
        return [_relative_text(item) for item in value]
    return value


def _resolve_config_path(value: Any, repo_root: Path) -> Path | None:
    if not isinstance(value, str) or not value:
        return None
    path = Path(value)
    if not path.is_absolute():
        path = Path(repo_root) / path
    return path.resolve()


def audit_run_config_snapshot(
    source_config: dict[str, Any], run_config: dict[str, Any], run_dir: Path, repo_root: Path = REPO_ROOT
) -> list[str]:
    """Require an exact scientific-config match while checking framework-derived paths separately."""
    issues: list[str] = []
    source_scientific = {
        key: _normalize_config_value(key, value)
        for key, value in source_config.items()
        if key not in RUN_CONFIG_ALLOWED_DIFFERENCE_KEYS
    }
    run_scientific = {
        key: _normalize_config_value(key, value)
        for key, value in run_config.items()
        if key not in RUN_CONFIG_ALLOWED_DIFFERENCE_KEYS
    }
    missing = sorted(set(source_scientific) - set(run_scientific))
    extra = sorted(set(run_scientific) - set(source_scientific))
    if missing or extra:
        issues.append(f"run config scientific keys mismatch; missing={missing}, extra={extra}")
    for key in sorted(set(source_scientific) & set(run_scientific)):
        if source_scientific[key] != run_scientific[key]:
            issues.append(
                f"run config scientific field {key} drifted: "
                f"{run_scientific[key]!r} != {source_scientific[key]!r}"
            )

    run_dir = Path(run_dir).resolve()
    expected_paths = {
        "run_dir": run_dir,
        "train_dir": run_dir / "train_data",
        "img_log_dir": run_dir / "img_log",
    }
    for key, expected_path in expected_paths.items():
        actual_path = _resolve_config_path(run_config.get(key), repo_root)
        if actual_path != expected_path.resolve():
            issues.append(f"run config derived field {key} does not identify {expected_path}")
    for key in ("commit_hash", "package_version"):
        if key not in run_config:
            issues.append(f"run config is missing framework metadata {key}")
    return issues


def _audit_bound_file(
    artifact: dict[str, Any], path_key: str, hash_key: str, label: str, repo_root: Path
) -> tuple[list[str], Path | None]:
    issues: list[str] = []
    try:
        path = resolve_repository_file(artifact.get(path_key), repo_root)
    except ValueError as error:
        return [f"{label}: invalid {path_key}: {error}"], None
    if not path.is_file():
        return [f"{label}: bound file does not exist for {path_key}: {path}"], path
    actual_hash = sha256_file(path)
    if artifact.get(hash_key) != actual_hash:
        issues.append(f"{label}: {hash_key} does not match {path_key}")
    return issues, path


def audit_metrics_artifact(
    artifact: dict[str, Any],
    expected_experiment_id: str,
    repo_root: Path = REPO_ROOT,
    artifact_path: Path | None = None,
    expected_source_config_path: str | Path | None = None,
) -> tuple[list[str], float | None]:
    """Re-read the hash-bound run products and recompute all 531 epoch-30 values."""
    issues: list[str] = []
    label = f"{expected_experiment_id} metrics artifact"
    if set(artifact) != METRICS_ARTIFACT_REQUIRED_KEYS:
        missing = sorted(METRICS_ARTIFACT_REQUIRED_KEYS - set(artifact))
        extra = sorted(set(artifact) - METRICS_ARTIFACT_REQUIRED_KEYS)
        issues.append(f"{label}: keys mismatch; missing={missing}, extra={extra}")

    expected_config_path = CONFIG_BY_ID.get(expected_experiment_id)
    if expected_source_config_path is not None:
        try:
            expected_config_path = Path(expected_source_config_path).as_posix()
            if Path(expected_config_path).is_absolute():
                expected_config_path = (
                    Path(expected_config_path).resolve().relative_to(Path(repo_root).resolve()).as_posix()
                )
        except ValueError as error:
            issues.append(f"{label}: expected source configuration escapes the repository")
            return issues, None
    if expected_config_path is None:
        issues.append(f"{label}: unknown experiment identifier")
        return issues, None
    if artifact.get("experiment_id") != expected_experiment_id:
        issues.append(f"{label}: experiment_id does not match")
    if _relative_text(artifact.get("source_config_path")) != expected_config_path:
        issues.append(f"{label}: source_config_path does not match the registered experiment")
    source_issues, source_config_path = _audit_bound_file(
        artifact, "source_config_path", "source_config_sha256", label, repo_root
    )
    run_config_issues, run_config_path = _audit_bound_file(
        artifact, "run_config_path", "run_config_sha256", label, repo_root
    )
    checkpoint_issues, checkpoint_path = _audit_bound_file(
        artifact, "checkpoint_path", "checkpoint_sha256", label, repo_root
    )
    metrics_issues, validation_metrics_path = _audit_bound_file(
        artifact, "validation_metrics_path", "validation_metrics_sha256", label, repo_root
    )
    results_issues, validation_results_path = _audit_bound_file(
        artifact, "validation_results_path", "validation_results_sha256", label, repo_root
    )
    issues.extend(source_issues + run_config_issues + checkpoint_issues + metrics_issues + results_issues)

    run_dir: Path | None = None
    if checkpoint_path is not None:
        run_dir = checkpoint_path.parent
        if checkpoint_path.name != "model_epoch030.pt":
            issues.append(f"{label}: checkpoint_path must end with model_epoch030.pt")
        if run_config_path is not None and run_config_path != run_dir / "config.yml":
            issues.append(f"{label}: run_config_path must be the checkpoint run's config.yml")
        expected_metrics_path = run_dir / "validation" / "model_epoch030" / "validation_metrics.csv"
        if validation_metrics_path is not None and validation_metrics_path != expected_metrics_path:
            issues.append(f"{label}: validation_metrics_path is not the checkpoint run's epoch-30 validation CSV")
        expected_results_path = run_dir / "validation" / "model_epoch030" / "validation_results.p"
        if validation_results_path is not None and validation_results_path != expected_results_path:
            issues.append(f"{label}: validation_results_path is not the checkpoint run's epoch-30 result pickle")
        if artifact_path is not None and Path(artifact_path).resolve() != (run_dir / "epoch030_metrics.json").resolve():
            issues.append(f"{label}: artifact must be stored as epoch030_metrics.json in the bound run directory")

    source_config: dict[str, Any] | None = None
    if source_config_path is not None and source_config_path.is_file():
        try:
            source_config = load_yaml(source_config_path)
        except (OSError, ValueError) as error:
            issues.append(f"{label}: cannot load source configuration: {error}")
    if source_config is not None and run_dir is not None:
        source_run_root = _resolve_config_path(source_config.get("run_dir"), repo_root)
        if source_run_root is None or run_dir.parent != source_run_root:
            issues.append(f"{label}: bound run directory is not a direct NeuralHydrology run under source run_dir")
    if source_config is not None and run_config_path is not None and run_config_path.is_file() and run_dir is not None:
        try:
            run_config = load_yaml(run_config_path)
        except (OSError, ValueError) as error:
            issues.append(f"{label}: cannot load run configuration snapshot: {error}")
        else:
            issues.extend(audit_run_config_snapshot(source_config, run_config, run_dir, repo_root))

    if artifact.get("epoch") != 30:
        issues.append(f"{label}: epoch must be 30")
    if artifact.get("metric") != "NSE":
        issues.append(f"{label}: metric must be NSE")
    if artifact.get("period") != SELECTION_PERIOD:
        issues.append(f"{label}: period must be {SELECTION_PERIOD!r}")

    if validation_metrics_path is None or not validation_metrics_path.is_file():
        return issues, None
    try:
        csv_basin_nse = load_validation_nse_csv(validation_metrics_path, repo_root)
    except (OSError, ValueError) as error:
        issues.append(f"{label}: invalid bound validation metrics CSV: {error}")
        return issues, None
    if validation_results_path is None or not validation_results_path.is_file():
        return issues, None
    try:
        results_basin_nse = load_validation_results_nse(validation_results_path, repo_root)
    except (OSError, ValueError, pickle.UnpicklingError) as error:
        issues.append(f"{label}: invalid bound validation results pickle: {error}")
        return issues, None
    csv_results_mismatches = [
        basin
        for basin in csv_basin_nse
        if not math.isclose(csv_basin_nse[basin], results_basin_nse[basin], rel_tol=0.0, abs_tol=1e-12)
    ]
    if csv_results_mismatches:
        issues.append(
            f"{label}: validation CSV disagrees with NSE recomputed from y_obs/y_sim for "
            f"{len(csv_results_mismatches)} basin(s)"
        )

    basin_nse = artifact.get("basin_nse")
    if not isinstance(basin_nse, dict):
        issues.append(f"{label}: basin_nse must be an object keyed by basin identifier")
        return issues, None
    expected_basins = list(csv_basin_nse)
    if set(basin_nse) != set(expected_basins):
        missing = sorted(set(expected_basins) - set(basin_nse))
        extra = sorted(set(basin_nse) - set(expected_basins))
        issues.append(
            f"{label}: basin_nse identifiers mismatch; missing_count={len(missing)}, extra_count={len(extra)}"
        )
        return issues, None
    invalid_basins = [basin for basin in expected_basins if not _is_finite_number(basin_nse[basin])]
    if invalid_basins:
        issues.append(f"{label}: basin_nse contains {len(invalid_basins)} non-finite or non-numeric values")
        return issues, None
    mismatched_values = [
        basin for basin in expected_basins if float(basin_nse[basin]) != csv_basin_nse[basin]
    ]
    if mismatched_values:
        issues.append(
            f"{label}: basin_nse disagrees with the bound validation CSV for "
            f"{len(mismatched_values)} basin(s)"
        )

    computed_median = float(statistics.median(results_basin_nse.values()))
    declared_median = artifact.get("median_nse")
    if not _is_finite_number(declared_median):
        issues.append(f"{label}: median_nse must be finite and numeric")
    elif not math.isclose(float(declared_median), computed_median, rel_tol=0.0, abs_tol=1e-12):
        issues.append(f"{label}: median_nse does not equal the median recomputed from bound y_obs/y_sim")
    return issues, computed_median


def embedding_width(config: dict[str, Any]) -> int:
    """Return the concatenated dynamic-plus-static projection width."""
    return int(config["dynamics_embedding"]["hiddens"][-1]) + int(
        config["statics_embedding"]["hiddens"][-1]
    )


def _relative_text(value: Any) -> str:
    return str(value).replace("\\", "/")


def _flatten_values(value: Any) -> list[str]:
    if isinstance(value, dict):
        return [item for child in value.values() for item in _flatten_values(child)]
    if isinstance(value, list):
        return [item for child in value for item in _flatten_values(child)]
    return [_relative_text(value)]


def audit_common_contract(config: dict[str, Any], label: str, repo_root: Path = REPO_ROOT) -> list[str]:
    """Check data, period, input, target, context, and training-budget invariants."""
    issues: list[str] = []
    for key, expected in COMMON_EXPECTED.items():
        actual = config.get(key)
        if key.endswith("_file") or key.endswith("_dir"):
            actual = _relative_text(actual)
        if actual != expected:
            issues.append(f"{label}: {key}={actual!r}, expected {expected!r}")

    for key in sorted(set(config) & FORBIDDEN_CONFIG_KEYS):
        issues.append(f"{label}: forbidden configuration key {key}")
    for key in config:
        lowered = key.lower()
        if key not in FORBIDDEN_CONFIG_KEYS and (lowered.startswith("test_") or "evaluation" in lowered):
            issues.append(f"{label}: evaluation-facing configuration key {key}")

    for value in _flatten_values(config):
        lowered = value.lower()
        for fragment in FORBIDDEN_VALUE_FRAGMENTS:
            if fragment.lower() in lowered:
                issues.append(f"{label}: forbidden value fragment {fragment!r}")

    basin_path = repo_root / BASIN_FILE
    if not basin_path.exists():
        issues.append(f"{label}: basin manifest is missing: {BASIN_FILE}")
    else:
        basins = [line.strip() for line in basin_path.read_text(encoding="utf-8").splitlines() if line.strip()]
        if len(basins) != 531:
            issues.append(f"{label}: basin manifest contains {len(basins)} rows, expected 531")
        if len(set(basins)) != len(basins):
            issues.append(f"{label}: basin manifest contains duplicate basin identifiers")
    return issues


def expected_sparse_widths(dense_width: int) -> tuple[int, int]:
    """Return the preregistered one-quarter shared and remaining top-two routed widths."""
    if dense_width not in {512, 1024}:
        raise ValueError(f"unsupported selected dense feed-forward width: {dense_width}")
    shared = dense_width // 4
    routed = (dense_width - shared) // 2
    return shared, routed


def audit_dense_sparse_pair(dense: dict[str, Any], sparse: dict[str, Any]) -> list[str]:
    """Restrict M01 changes to expert layers, router training, and experiment identity."""
    issues: list[str] = []
    for key in sorted((set(dense) | set(sparse)) - PAIR_ALLOWED_DIFFERENCES):
        if dense.get(key) != sparse.get(key):
            issues.append(f"dense/sparse pair drifted at {key}: {dense.get(key)!r} != {sparse.get(key)!r}")

    if dense.get("model") != "modern_transformer":
        issues.append("dense/sparse pair: dense model must be modern_transformer")
    if sparse.get("model") != "modern_transformer_moe":
        issues.append("dense/sparse pair: sparse model must be modern_transformer_moe")

    try:
        shared_width, routed_width = expected_sparse_widths(int(dense.get("transformer_dim_feedforward")))
    except (TypeError, ValueError) as error:
        issues.append(f"dense/sparse pair: {error}")
        shared_width, routed_width = -1, -1
    expected_sparse = {
        "transformer_moe_num_experts": 8,
        "transformer_moe_top_k": 2,
        "transformer_moe_first_layer": 2,
        "transformer_moe_shared_dim": shared_width,
        "transformer_moe_routed_dim": routed_width,
        "transformer_moe_router_jitter": 0.0,
        "regularization": [["moe_router", 0.01]],
    }
    for key, expected in expected_sparse.items():
        if sparse.get(key) != expected:
            issues.append(f"dense/sparse pair: {key}={sparse.get(key)!r}, expected {expected!r}")

    shared = sparse.get("transformer_moe_shared_dim")
    top_k = sparse.get("transformer_moe_top_k")
    routed = sparse.get("transformer_moe_routed_dim")
    dense_width = sparse.get("transformer_dim_feedforward")
    if all(isinstance(value, int) for value in (shared, top_k, routed, dense_width)):
        if shared + top_k * routed != dense_width:
            issues.append(
                "dense/sparse pair: active feed-forward width mismatch: "
                f"{shared} + {top_k} * {routed} != {dense_width}"
            )
    else:
        issues.append("dense/sparse pair: feed-forward widths must all be integers")

    option_names = {key.lower() for key in sparse}
    if any("capacity" in key or "drop_token" in key for key in option_names):
        issues.append("dense/sparse pair: capacity or token-dropping options are forbidden")
    return issues


def audit_selection_report(report: dict[str, Any], repo_root: Path = REPO_ROOT) -> list[str]:
    """Recompute all candidate medians and verify the declared deterministic winner."""
    issues: list[str] = []
    if set(report) != SELECTION_REPORT_REQUIRED_KEYS:
        missing = sorted(SELECTION_REPORT_REQUIRED_KEYS - set(report))
        extra = sorted(set(report) - SELECTION_REPORT_REQUIRED_KEYS)
        issues.append(f"selection report keys mismatch; missing={missing}, extra={extra}")

    candidate_ids = ["D01", "D02", "D03"]
    if report.get("candidate_experiment_ids") != candidate_ids:
        issues.append("selection report must list exactly D01, D02, D03 in preregistered order")
    if report.get("selection_period") != SELECTION_PERIOD:
        issues.append(f"selection report period must be {SELECTION_PERIOD!r}")
    if report.get("selection_metric") != "median_NSE":
        issues.append("selection report metric must be median_NSE")
    if report.get("selection_epoch") != 30:
        issues.append("selection report epoch must be 30")
    if report.get("selection_rule") != SELECTION_RULE:
        issues.append(f"selection report rule must be {SELECTION_RULE}")

    recomputed_medians: dict[str, float] = {}
    candidate_metrics = report.get("candidate_metrics")
    if not isinstance(candidate_metrics, list) or len(candidate_metrics) != len(candidate_ids):
        issues.append("selection report candidate_metrics must contain exactly three ordered records")
        candidate_metrics = []
    for expected_id, record in zip(candidate_ids, candidate_metrics):
        if not isinstance(record, dict):
            issues.append(f"selection report candidate_metrics entry for {expected_id} must be an object")
            continue
        if set(record) != CANDIDATE_METRIC_KEYS:
            missing = sorted(CANDIDATE_METRIC_KEYS - set(record))
            extra = sorted(set(record) - CANDIDATE_METRIC_KEYS)
            issues.append(f"selection report {expected_id} metric keys mismatch; missing={missing}, extra={extra}")
        if record.get("experiment_id") != expected_id:
            issues.append(f"selection report candidate metric order/identity mismatch at {expected_id}")
        try:
            artifact_path = resolve_repository_file(record.get("metrics_artifact_path"), repo_root)
        except ValueError as error:
            issues.append(f"selection report {expected_id}: {error}")
            continue
        if not artifact_path.exists():
            issues.append(f"selection report {expected_id}: metrics artifact does not exist: {artifact_path}")
            continue
        if record.get("metrics_artifact_sha256") != sha256_file(artifact_path):
            issues.append(f"selection report {expected_id}: metrics artifact SHA-256 mismatch")
            continue
        try:
            artifact = load_json(artifact_path)
        except (OSError, ValueError, json.JSONDecodeError) as error:
            issues.append(f"selection report {expected_id}: cannot load metrics artifact: {error}")
            continue
        artifact_issues, recomputed_median = audit_metrics_artifact(
            artifact, expected_id, repo_root, artifact_path=artifact_path
        )
        issues.extend(artifact_issues)
        if recomputed_median is None:
            continue
        recomputed_medians[expected_id] = recomputed_median
        declared_median = record.get("median_nse")
        if not _is_finite_number(declared_median):
            issues.append(f"selection report {expected_id}: median_nse must be finite and numeric")
        elif not math.isclose(float(declared_median), recomputed_median, rel_tol=0.0, abs_tol=1e-12):
            issues.append(f"selection report {expected_id}: median_nse does not match the metrics artifact")

    selected_id = str(report.get("selected_experiment_id"))
    if len(recomputed_medians) == len(candidate_ids):
        order = {experiment_id: index for index, experiment_id in enumerate(candidate_ids)}
        winner = max(
            candidate_ids,
            key=lambda experiment_id: (recomputed_medians[experiment_id], -order[experiment_id]),
        )
        if selected_id != winner:
            issues.append(
                f"selection report selected {selected_id}, but recomputed epoch-30 winner with tie-break is {winner}"
            )

    expected_path = DENSE_CONFIG_BY_ID.get(selected_id)
    if expected_path is None:
        issues.append(f"selection report selected_experiment_id is invalid: {selected_id!r}")
        return issues
    if _relative_text(report.get("selected_config_path")) != expected_path:
        issues.append(f"selection report path does not match {selected_id}: {report.get('selected_config_path')!r}")
        return issues

    selected_path = repo_root / expected_path
    if not selected_path.exists():
        issues.append(f"selected dense configuration does not exist: {selected_path}")
    elif report.get("selected_config_sha256") != sha256_file(selected_path):
        issues.append("selection report selected_config_sha256 does not match the selected dense configuration")
    return issues


def _audit_model_configs(configs: dict[str, dict[str, Any]]) -> list[str]:
    issues: list[str] = []
    baseline = configs["baseline_lstm_s100.yml"]
    baseline_expected = {
        "model": "cudalstm",
        "hidden_size": 256,
        "initial_forget_bias": 5,
        "output_dropout": 0.4,
        "optimizer": "Adam",
        "learning_rate": {0: 1e-3, 11: 5e-4, 21: 1e-4},
        "batch_size": 256,
    }
    for key, expected in baseline_expected.items():
        if baseline.get(key) != expected:
            issues.append(f"baseline_lstm_s100.yml: {key}={baseline.get(key)!r}, expected {expected!r}")

    dense_expected = {
        "dense_d128_l4_s100.yml": (128, 4, 4, 512),
        "dense_d256_l4_s100.yml": (256, 4, 8, 1024),
        "dense_d256_l8_s100.yml": (256, 8, 8, 1024),
    }
    for filename, (width, layers, heads, intermediate) in dense_expected.items():
        config = configs[filename]
        actual = (
            embedding_width(config),
            config.get("transformer_nlayers"),
            config.get("transformer_nheads"),
            config.get("transformer_dim_feedforward"),
        )
        if config.get("model") != "modern_transformer":
            issues.append(f"{filename}: model must be modern_transformer")
        if actual != (width, layers, heads, intermediate):
            issues.append(f"{filename}: capacity {actual!r}, expected {(width, layers, heads, intermediate)!r}")
        if width // heads != 32:
            issues.append(f"{filename}: attention head dimension must be 32")
        if config.get("optimizer") != "AdamW":
            issues.append(f"{filename}: optimizer must be AdamW")
        if config.get("learning_rate") != {0: 3e-4, 11: 1e-4, 21: 3e-5}:
            issues.append(f"{filename}: modern Transformer learning-rate schedule drifted")
        if config.get("output_dropout") != 0.0:
            issues.append(f"{filename}: output_dropout must be zero")
        if config.get("batch_size") != 64:
            issues.append(f"{filename}: provisional 12 GB memory-gated batch_size must be 64")
    return issues


def _audit_common_registry_sentinels(row: dict[str, str], exp_id: str) -> list[str]:
    issues: list[str] = []
    if row.get("seed") != "100":
        issues.append(f"{exp_id}: seed must be 100")
    if row.get("total_parameters") != "not_measured_pre_run":
        issues.append(f"{exp_id}: total_parameters must be not_measured_pre_run")
    if row.get("active_parameters_per_token") != "not_measured_pre_run":
        issues.append(f"{exp_id}: active_parameters_per_token must be not_measured_pre_run")
    return issues


def _audit_run_lifecycle(row: dict[str, str], exp_id: str, repo_root: Path) -> list[str]:
    """Accept either a pristine planned row or a hash-bound epoch-30 completed row."""
    issues: list[str] = []
    status = row.get("status")
    if status == "planned":
        for field in ("best_checkpoint", "checkpoint_sha256", "metrics_path", "metrics_sha256"):
            if row.get(field) != "not_run":
                issues.append(f"{exp_id}: planned row requires {field}=not_run")
        return issues
    if status != "development_complete":
        issues.append(f"{exp_id}: status must be planned or development_complete")
        return issues

    checkpoint_path: Path | None = None
    try:
        checkpoint_path = resolve_repository_file(row.get("best_checkpoint"), repo_root)
    except ValueError as error:
        issues.append(f"{exp_id}: invalid best_checkpoint: {error}")
    else:
        if checkpoint_path.name != "model_epoch030.pt":
            issues.append(f"{exp_id}: completed run must register model_epoch030.pt")
        if not checkpoint_path.is_file():
            issues.append(f"{exp_id}: registered epoch-30 checkpoint does not exist: {checkpoint_path}")
        elif row.get("checkpoint_sha256") != sha256_file(checkpoint_path):
            issues.append(f"{exp_id}: registered epoch-30 checkpoint SHA-256 mismatch")

    try:
        metrics_path = resolve_repository_file(row.get("metrics_path"), repo_root)
    except ValueError as error:
        issues.append(f"{exp_id}: invalid metrics_path: {error}")
        return issues
    if not metrics_path.is_file():
        issues.append(f"{exp_id}: registered metrics artifact does not exist: {metrics_path}")
        return issues
    if row.get("metrics_sha256") != sha256_file(metrics_path):
        issues.append(f"{exp_id}: registered metrics artifact SHA-256 mismatch")
        return issues
    try:
        artifact = load_json(metrics_path)
    except (OSError, ValueError, json.JSONDecodeError) as error:
        issues.append(f"{exp_id}: cannot load registered metrics artifact: {error}")
        return issues
    artifact_issues, _ = audit_metrics_artifact(artifact, exp_id, repo_root, artifact_path=metrics_path)
    issues.extend(artifact_issues)
    if _relative_text(artifact.get("checkpoint_path")) != _relative_text(row.get("best_checkpoint")):
        issues.append(f"{exp_id}: registered best_checkpoint disagrees with the metrics artifact")
    if artifact.get("checkpoint_sha256") != row.get("checkpoint_sha256"):
        issues.append(f"{exp_id}: registered checkpoint_sha256 disagrees with the metrics artifact")
    return issues


def audit_registry(rows: list[dict[str, str]], repo_root: Path = REPO_ROOT) -> list[str]:
    """Check identities, run lifecycle, hashes, output isolation, and both M01 gate states."""
    issues: list[str] = []
    ids = [row.get("exp_id", "") for row in rows]
    if ids != EXPECTED_REGISTRY_IDS:
        issues.append(f"registry experiment identifiers are {ids!r}, expected {EXPECTED_REGISTRY_IDS!r}")
        return issues

    run_dirs = [row.get("run_dir", "") for row in rows]
    if len(set(run_dirs)) != len(run_dirs):
        issues.append("registry run_dir values must be unique")
    material_config_paths = [row["config_path"] for row in rows if row.get("config_path") != "not_generated"]
    if len(set(material_config_paths)) != len(material_config_paths):
        issues.append("registry material config_path values must be unique")

    by_id = {row["exp_id"]: row for row in rows}
    for exp_id in ["B01", "D01", "D02", "D03"]:
        row = by_id[exp_id]
        issues.extend(_audit_common_registry_sentinels(row, exp_id))
        issues.extend(_audit_run_lifecycle(row, exp_id, repo_root))
        for field in (
            "source_config_path",
            "source_config_sha256",
            "selection_report_path",
            "selection_report_sha256",
        ):
            if row.get(field) != "not_applicable":
                issues.append(f"{exp_id}: {field} must be not_applicable")

        config_path = repo_root / row.get("config_path", "")
        if not config_path.exists():
            issues.append(f"{exp_id}: registered config does not exist: {config_path}")
            continue
        actual_hash = sha256_file(config_path)
        if actual_hash != row.get("config_sha256"):
            issues.append(f"{exp_id}: config SHA-256 mismatch: {actual_hash} != {row.get('config_sha256')}")
        config = load_yaml(config_path)
        if _relative_text(config.get("run_dir")) != row.get("run_dir"):
            issues.append(f"{exp_id}: registry run_dir does not match the configuration")
        active_width = row.get("active_feedforward_width")
        if exp_id == "B01":
            if active_width != "not_applicable":
                issues.append("B01: active_feedforward_width must be not_applicable")
        elif active_width != str(config.get("transformer_dim_feedforward")):
            issues.append(f"{exp_id}: active_feedforward_width does not match the configuration")

    m01 = by_id["M01"]
    issues.extend(_audit_common_registry_sentinels(m01, "M01"))
    if m01.get("status") == "awaiting_dense_selection":
        for field in ("best_checkpoint", "checkpoint_sha256", "metrics_path", "metrics_sha256"):
            if m01.get(field) != "not_run":
                issues.append(f"M01: pre-run sparse row requires {field}=not_run")
        expected = {
            "base_config": "not_selected",
            "config_path": "not_generated",
            "config_sha256": "not_generated",
            "source_config_path": "not_selected",
            "source_config_sha256": "not_selected",
            "selection_report_path": "not_available",
            "selection_report_sha256": "not_available",
            "active_feedforward_width": "not_selected",
        }
        for field, value in expected.items():
            if m01.get(field) != value:
                issues.append(f"M01: {field}={m01.get(field)!r}, expected pre-selection sentinel {value!r}")
        if (repo_root / "src" / "modern_transformer_moe" / "configs" / OPTIONAL_SPARSE_CONFIG_FILE).exists():
            issues.append("M01: moe_selected_s100.yml exists before a dense selection report was registered")
    elif m01.get("status") in {"planned", "development_complete"}:
        issues.extend(_audit_run_lifecycle(m01, "M01", repo_root))
        incomplete_dense = [
            exp_id for exp_id in ["D01", "D02", "D03"] if by_id[exp_id]["status"] != "development_complete"
        ]
        if incomplete_dense:
            issues.append(f"M01: generated state requires completed dense candidates, incomplete={incomplete_dense!r}")
        if m01.get("config_path") != f"src/modern_transformer_moe/configs/{OPTIONAL_SPARSE_CONFIG_FILE}":
            issues.append("M01: generated config_path is not the canonical moe_selected_s100.yml path")
            return issues
        sparse_path = repo_root / m01["config_path"]
        source_path = repo_root / m01.get("source_config_path", "")
        report_path = repo_root / m01.get("selection_report_path", "")
        for label, path, expected_hash_field in (
            ("generated sparse config", sparse_path, "config_sha256"),
            ("selected dense source", source_path, "source_config_sha256"),
            ("selection report", report_path, "selection_report_sha256"),
        ):
            if not path.exists():
                issues.append(f"M01: {label} does not exist: {path}")
            elif sha256_file(path) != m01.get(expected_hash_field):
                issues.append(f"M01: {label} SHA-256 mismatch")
        if source_path.exists() and report_path.exists() and sparse_path.exists():
            report = load_json(report_path)
            issues.extend(audit_selection_report(report, repo_root))
            report_metrics = {
                item.get("experiment_id"): item
                for item in report.get("candidate_metrics", [])
                if isinstance(item, dict)
            }
            for experiment_id in ["D01", "D02", "D03"]:
                metric_record = report_metrics.get(experiment_id, {})
                dense_row = by_id[experiment_id]
                if dense_row.get("metrics_path") != metric_record.get("metrics_artifact_path"):
                    issues.append(f"M01: {experiment_id} registry metrics_path disagrees with the selection report")
                if dense_row.get("metrics_sha256") != metric_record.get("metrics_artifact_sha256"):
                    issues.append(f"M01: {experiment_id} registry metrics_sha256 disagrees with the selection report")
            if m01.get("source_config_path") != report.get("selected_config_path"):
                issues.append("M01: registry source_config_path disagrees with the selection report")
            if m01.get("source_config_sha256") != report.get("selected_config_sha256"):
                issues.append("M01: registry source_config_sha256 disagrees with the selection report")
            dense = load_yaml(source_path)
            sparse = load_yaml(sparse_path)
            issues.extend(audit_dense_sparse_pair(dense, sparse))
            if m01.get("base_config") != m01.get("source_config_path"):
                issues.append("M01: base_config must identify the selected dense source")
            if m01.get("active_feedforward_width") != str(sparse.get("transformer_dim_feedforward")):
                issues.append("M01: active_feedforward_width does not match the generated configuration")
    else:
        issues.append("M01: status must be awaiting_dense_selection, planned, or development_complete")
    return issues


def audit_repository(repo_root: Path = REPO_ROOT) -> list[str]:
    """Run every static check without reading hydrological data or launching a model."""
    issues: list[str] = []
    mandatory_files = {BASE_CONFIG_FILE, *RUN_CONFIG_FILES}
    allowed_files = mandatory_files | {OPTIONAL_SPARSE_CONFIG_FILE}
    config_dir = repo_root / "src" / "modern_transformer_moe" / "configs"
    actual_files = {path.name for path in config_dir.glob("*.yml")}
    if not mandatory_files.issubset(actual_files):
        issues.append(f"missing mandatory configurations: {sorted(mandatory_files - actual_files)!r}")
    if not actual_files.issubset(allowed_files):
        issues.append(f"unexpected configurations: {sorted(actual_files - allowed_files)!r}")

    configs: dict[str, dict[str, Any]] = {}
    for filename in sorted(actual_files & allowed_files):
        path = config_dir / filename
        try:
            configs[filename] = load_yaml(path)
        except (OSError, ValueError) as error:
            issues.append(f"{filename}: cannot load YAML: {error}")
            continue
        issues.extend(audit_common_contract(configs[filename], filename, repo_root))
        try:
            Config(path)
        except (TypeError, ValueError) as error:
            issues.append(f"{filename}: strict NeuralHydrology Config rejected the file: {error}")

    if set(RUN_CONFIG_FILES).issubset(configs):
        issues.extend(_audit_model_configs(configs))

    registry_path = repo_root / "src" / "modern_transformer_moe" / "registry" / "experiments.csv"
    if not registry_path.exists():
        issues.append(f"missing experiment registry: {registry_path}")
    else:
        try:
            issues.extend(audit_registry(load_registry(registry_path), repo_root))
        except (OSError, ValueError, json.JSONDecodeError) as error:
            issues.append(f"cannot audit experiment registry: {error}")
    return issues


def main() -> int:
    issues = audit_repository(REPO_ROOT)
    if issues:
        print("CONFIG AUDIT: FAIL")
        for issue in issues:
            print(f"- {issue}")
        return 1
    rows = load_registry(REGISTRY_PATH)
    m01_status = next(row["status"] for row in rows if row["exp_id"] == "M01")
    if m01_status == "planned":
        state = "5 runnable configs; hash-bound M01 generation complete"
    else:
        state = "4 runnable configs; M01 is gated on dense validation selection"
    print(f"CONFIG AUDIT: PASS ({state}; no training launched)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
