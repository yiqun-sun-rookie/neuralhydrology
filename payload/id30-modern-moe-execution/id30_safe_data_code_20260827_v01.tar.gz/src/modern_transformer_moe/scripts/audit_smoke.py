"""Audit an isolated dense/mixture-of-experts CPU smoke invocation.

This audit never calls the validation or test evaluator. It reloads each epoch-1
checkpoint and runs one deterministic batch from the declared training period.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
import re
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch.utils.data import DataLoader

from neuralhydrology.datasetzoo import get_dataset
from neuralhydrology.datautils.utils import load_basin_file, load_scaler
from neuralhydrology.modelzoo import get_model
from neuralhydrology.utils.config import Config
from src.modern_transformer_moe.scripts.candidate_safe_data import audit_access_log


REPO_ROOT = Path(__file__).resolve().parents[3]
AUDIT_SCRIPT = Path(__file__).resolve()
DEFAULT_REPORT = REPO_ROOT / "results" / "30_modern_transformer_moe" / "_reports" / "smoke_report_v02.json"
LOSS_LINE = re.compile(r"Epoch\s+1\s+average loss:\s*(?P<values>.+)$")
LOSS_VALUE = re.compile(r"avg_(?P<name>[A-Za-z0-9_]+):\s*(?P<value>[-+0-9.eE]+|nan|inf|-inf)")
MOE_KEYS = {
    "transformer_moe_num_experts",
    "transformer_moe_top_k",
    "transformer_moe_first_layer",
    "transformer_moe_shared_dim",
    "transformer_moe_routed_dim",
    "transformer_moe_router_jitter",
}
PAIR_ALLOWED_DIFFERENCES = {"experiment_name", "run_dir", "model", "regularization", *MOE_KEYS}
CRITICAL_SOURCE_PATHS = (
    "neuralhydrology/nh_run.py",
    "neuralhydrology/datasetzoo/__init__.py",
    "neuralhydrology/datasetzoo/basedataset.py",
    "neuralhydrology/datasetzoo/camelsus.py",
    "neuralhydrology/datasetzoo/camelsus_track0_bundle.py",
    "neuralhydrology/modelzoo/__init__.py",
    "neuralhydrology/modelzoo/head.py",
    "neuralhydrology/modelzoo/inputlayer.py",
    "neuralhydrology/modelzoo/modern_causal_transformer.py",
    "neuralhydrology/training/__init__.py",
    "neuralhydrology/training/basetrainer.py",
    "neuralhydrology/training/loss.py",
    "neuralhydrology/training/regularization.py",
    "neuralhydrology/utils/config.py",
    "src/modern_transformer_moe/scripts/audit_track0_supervision_bundle.py",
    "src/modern_transformer_moe/scripts/candidate_safe_data.py",
    "src/modern_transformer_moe/scripts/track0_bundle_common.py",
    "src/modern_transformer_moe/scripts/run_smoke.py",
    "src/modern_transformer_moe/configs/smoke/smoke_basins.txt",
    "src/modern_transformer_moe/configs/smoke/smoke_dense.yml",
    "src/modern_transformer_moe/configs/smoke/smoke_moe.yml",
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as file:
        for block in iter(lambda: file.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _repo_path(value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else REPO_ROOT / path


def _relative(path: Path) -> str:
    try:
        return path.resolve().relative_to(REPO_ROOT.resolve()).as_posix()
    except ValueError:
        return str(path.resolve())


def _normalise(value: Any) -> Any:
    if isinstance(value, Path):
        return value.as_posix()
    if hasattr(value, "isoformat"):
        return value.isoformat()
    if isinstance(value, dict):
        return {str(key): _normalise(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_normalise(item) for item in value]
    return value


def _git_metadata() -> dict[str, Any]:
    revision = subprocess.run(["git", "rev-parse", "HEAD"], cwd=REPO_ROOT, check=True, capture_output=True,
                              text=True).stdout.strip()
    status_lines = subprocess.run(["git", "status", "--porcelain"], cwd=REPO_ROOT, check=True, capture_output=True,
                                  text=True).stdout.splitlines()
    return {
        "revision": revision,
        "dirty_worktree": bool(status_lines),
        "changed_path_count": len(status_lines),
    }


def _audit_source_snapshot(snapshot: dict[str, Any]) -> dict[str, Any]:
    if not snapshot:
        raise ValueError("Manifest has no pre-training source_snapshot.")
    expected_files = snapshot.get("files", {})
    required = set(CRITICAL_SOURCE_PATHS)
    missing_manifest_entries = sorted(required - set(expected_files))
    unexpected_manifest_entries = sorted(set(expected_files) - required)
    file_checks = {}
    for relative_path in sorted(required):
        path = REPO_ROOT / relative_path
        current_hash = _sha256(path) if path.is_file() else None
        expected_hash = expected_files.get(relative_path)
        file_checks[relative_path] = {
            "manifest_sha256": expected_hash,
            "current_sha256": current_hash,
            "matches": expected_hash is not None and expected_hash == current_hash,
        }
    current_git = _git_metadata()
    hashes_match = not missing_manifest_entries and all(item["matches"] for item in file_checks.values())
    revision_matches = snapshot.get("git_revision") == current_git["revision"]
    return {
        "captured_at_utc": snapshot.get("captured_at_utc"),
        "manifest_git_revision": snapshot.get("git_revision"),
        "current_git_revision": current_git["revision"],
        "git_revision_matches": revision_matches,
        "manifest_dirty_worktree": snapshot.get("dirty_worktree"),
        "missing_manifest_entries": missing_manifest_entries,
        "unexpected_manifest_entries": unexpected_manifest_entries,
        "files": file_checks,
        "all_required_hashes_match": hashes_match,
        "passed": hashes_match and revision_matches,
    }


def _parse_logged_losses(log_path: Path) -> dict[str, float]:
    matched_line = None
    for line in log_path.read_text(encoding="utf-8").splitlines():
        match = LOSS_LINE.search(line)
        if match:
            matched_line = match.group("values")
    if matched_line is None:
        raise ValueError(f"No epoch-1 average loss found in {log_path}.")
    losses = {match.group("name"): float(match.group("value")) for match in LOSS_VALUE.finditer(matched_line)}
    if not losses:
        raise ValueError(f"Could not parse losses from: {matched_line}")
    return losses


def _move_batch_to_cpu(batch: dict[str, Any]) -> dict[str, Any]:
    moved = {}
    for key, value in batch.items():
        if isinstance(value, dict):
            moved[key] = {name: tensor.to("cpu") for name, tensor in value.items()}
        elif isinstance(value, torch.Tensor):
            moved[key] = value.to("cpu")
        else:
            moved[key] = value
    return moved


def _load_state(path: Path) -> dict[str, torch.Tensor]:
    try:
        return torch.load(path, map_location="cpu", weights_only=True)
    except TypeError:
        return torch.load(path, map_location="cpu")


def _parameter_counts(model: torch.nn.Module) -> dict[str, int | float]:
    if hasattr(model, "parameter_counts"):
        return model.parameter_counts()
    total = sum(parameter.numel() for parameter in model.parameters())
    return {"total_parameters": total, "active_parameters_per_token": total, "active_to_total_ratio": 1.0}


def _parameter_update_evidence(config: Config, checkpoint: Path, optimizer_path: Path) -> dict[str, Any]:
    """Compare the saved model with its deterministic initialization and inspect Adam moments."""
    initial_state = get_model(config).to("cpu").state_dict()
    trained_state = _load_state(checkpoint)
    if set(initial_state) != set(trained_state):
        raise ValueError("Checkpoint state keys do not match a freshly initialized model.")

    changed = []
    maximum_absolute_delta = 0.0
    all_checkpoint_tensors_finite = True
    for name, initial_value in initial_state.items():
        trained_value = trained_state[name].detach().cpu()
        initial_value = initial_value.detach().cpu()
        all_checkpoint_tensors_finite &= bool(torch.isfinite(trained_value).all().item())
        if not torch.equal(initial_value, trained_value):
            changed.append(name)
            maximum_absolute_delta = max(maximum_absolute_delta,
                                         float((trained_value - initial_value).abs().max().item()))

    optimizer_state = _load_state(optimizer_path)
    state_entries = optimizer_state.get("state", {})
    nonzero_first_moments = 0
    finite_optimizer_tensors = True
    optimizer_steps = []
    for state in state_entries.values():
        first_moment = state.get("exp_avg")
        if isinstance(first_moment, torch.Tensor):
            finite_optimizer_tensors &= bool(torch.isfinite(first_moment).all().item())
            nonzero_first_moments += int(bool(torch.count_nonzero(first_moment).item()))
        step = state.get("step")
        if isinstance(step, torch.Tensor):
            optimizer_steps.append(int(step.detach().cpu().item()))
        elif step is not None:
            optimizer_steps.append(int(step))

    return {
        "state_keys_match_initial_model": True,
        "changed_parameter_tensor_count": len(changed),
        "changed_parameter_examples": changed[:20],
        "maximum_absolute_parameter_delta": maximum_absolute_delta,
        "checkpoint_tensors_all_finite": all_checkpoint_tensors_finite,
        "optimizer_state_entry_count": len(state_entries),
        "nonzero_first_moment_tensor_count": nonzero_first_moments,
        "optimizer_tensors_all_finite": finite_optimizer_tensors,
        "optimizer_step_values": sorted(set(optimizer_steps)),
    }


def _training_batch_forward(config: Config, run_dir: Path, checkpoint: Path, label: str) -> dict[str, Any]:
    scaler = load_scaler(run_dir)
    basins = load_basin_file(config.train_basin_file)
    # Evaluation-mode construction accepts the train period and the persisted scaler, but it does not call
    # BaseDataset._dump_scaler(). This keeps the audit strictly read-only with respect to the completed run directory.
    dataset = get_dataset(config, is_train=False, period="train", scaler=scaler)
    loader = DataLoader(dataset,
                        batch_size=config.batch_size,
                        shuffle=False,
                        num_workers=0,
                        collate_fn=dataset.collate_fn)
    batch = _move_batch_to_cpu(next(iter(loader)))

    model = get_model(config).to("cpu")
    model.load_state_dict(_load_state(checkpoint), strict=True)
    model.eval()
    batch = model.pre_model_hook(batch, is_train=False)
    with torch.no_grad():
        output = model(batch)

    prediction = output["y_hat"]
    prediction_finite = bool(torch.isfinite(prediction).all().item())
    prediction_summary = {
        "shape": list(prediction.shape),
        "minimum": float(prediction.min().item()),
        "maximum": float(prediction.max().item()),
        "mean": float(prediction.mean().item()),
        "all_finite": prediction_finite,
    }
    result = {
        "data_period": "train",
        "dataset_is_train": False,
        "read_only_dataset_interface": True,
        "basin_count": len(basins),
        "dataset_sample_count": len(dataset),
        "batch_size": int(prediction.shape[0]),
        "sequence_length": int(prediction.shape[1]),
        "checkpoint_loaded_strictly": True,
        "prediction": prediction_summary,
        "parameter_counts": _parameter_counts(model),
    }

    if label == "moe":
        expert_load = output["moe_expert_load"].detach().cpu().to(torch.long)
        dropped_tokens = int(output["moe_dropped_tokens"].detach().cpu().sum().item())
        top_k = config.transformer_moe_top_k
        moe_layers = config.transformer_nlayers - config.transformer_moe_first_layer
        tokens_per_layer = int(prediction.shape[0] * prediction.shape[1])
        expected_assignments = tokens_per_layer * top_k * moe_layers
        actual_assignments = int(expert_load.sum().item())
        result["routing"] = {
            "expert_load_by_layer": expert_load.tolist(),
            "tokens_per_layer": tokens_per_layer,
            "top_k": top_k,
            "moe_layer_count": moe_layers,
            "expected_assignment_count": expected_assignments,
            "actual_assignment_count": actual_assignments,
            "assignment_count_matches": actual_assignments == expected_assignments,
            "dropped_tokens": dropped_tokens,
            "zero_dropped_tokens": dropped_tokens == 0,
            "router_loss": float(output["moe_router_loss"].detach().cpu().reshape(-1)[0].item()),
        }
    return result


def _pair_contract(dense: Config, moe: Config) -> dict[str, Any]:
    dense_values = dense.as_dict()
    moe_values = moe.as_dict()
    compared_keys = (set(dense_values) | set(moe_values)) - PAIR_ALLOWED_DIFFERENCES
    differences = {
        key: {"dense": _normalise(dense_values.get(key)), "moe": _normalise(moe_values.get(key))}
        for key in sorted(compared_keys)
        if _normalise(dense_values.get(key)) != _normalise(moe_values.get(key))
    }
    active_width = moe.transformer_moe_shared_dim + moe.transformer_moe_top_k * moe.transformer_moe_routed_dim
    return {
        "common_fields_match": not differences,
        "unexpected_differences": differences,
        "dense_feed_forward_width": dense.transformer_dim_feedforward,
        "moe_active_feed_forward_width": active_width,
        "active_width_matches": active_width == dense.transformer_dim_feedforward,
    }


def _audit_run(label: str, manifest_entry: dict[str, Any]) -> tuple[dict[str, Any], Config]:
    source_config = _repo_path(manifest_entry["source_config"])
    runtime_config = _repo_path(manifest_entry["runtime_config"])
    run_dir = _repo_path(manifest_entry["run_dir"])
    artifacts = {
        "config_snapshot": run_dir / "config.yml",
        "scaler": run_dir / "train_data" / "train_data_scaler.yml",
        "checkpoint": run_dir / "model_epoch001.pt",
        "optimizer_state": run_dir / "optimizer_state_epoch001.pt",
        "log": run_dir / "output.log",
    }
    artifact_presence = {name: path.is_file() for name, path in artifacts.items()}
    if not all(artifact_presence.values()):
        missing = [name for name, present in artifact_presence.items() if not present]
        raise FileNotFoundError(f"{label} is missing required artifacts: {missing}")

    artifact_hashes_before = {name: _sha256(path) for name, path in artifacts.items()}
    config = Config(artifacts["config_snapshot"])
    logged_losses = _parse_logged_losses(artifacts["log"])
    forward = _training_batch_forward(config, run_dir, artifacts["checkpoint"], label)
    update_evidence = _parameter_update_evidence(config, artifacts["checkpoint"], artifacts["optimizer_state"])
    source_hash = _sha256(source_config)
    runtime_hash = _sha256(runtime_config)
    artifact_hashes_after = {name: _sha256(path) for name, path in artifacts.items()}
    artifacts_unchanged = artifact_hashes_before == artifact_hashes_after
    hash_checks = {
        "source_matches_manifest": source_hash == manifest_entry["source_config_sha256"],
        "runtime_matches_manifest": runtime_hash == manifest_entry["runtime_config_sha256"],
    }
    date_boundary_pass = (str(config.train_start_date.date()) >= "1999-10-01"
                          and str(config.train_end_date.date()) <= "2006-09-30")
    gates = {
        "required_artifacts_present": all(artifact_presence.values()),
        "configuration_hashes_match_manifest": all(hash_checks.values()),
        "cpu_device": config.device == "cpu",
        "one_epoch_one_update_contract": config.epochs == 1 and config.max_updates_per_epoch == 1,
        "full_270_day_window": config.seq_length == 270 and forward["sequence_length"] == 270,
        "training_target_period_unsealed": date_boundary_pass,
        "logged_losses_finite": all(math.isfinite(value) for value in logged_losses.values()),
        "checkpoint_reload_prediction_finite": forward["prediction"]["all_finite"],
        "checkpoint_differs_from_deterministic_initialization": update_evidence["changed_parameter_tensor_count"] > 0,
        "optimizer_records_nonzero_gradient_moments": update_evidence["nonzero_first_moment_tensor_count"] > 0,
        "optimizer_completed_exactly_one_step": update_evidence["optimizer_step_values"] == [1],
        "checkpoint_and_optimizer_tensors_finite": (update_evidence["checkpoint_tensors_all_finite"]
                                                    and update_evidence["optimizer_tensors_all_finite"]),
        "run_artifacts_unchanged_during_audit": artifacts_unchanged,
    }
    if label == "moe":
        gates.update({
            "expert_assignments_complete": forward["routing"]["assignment_count_matches"],
            "zero_dropped_tokens": forward["routing"]["zero_dropped_tokens"],
            "router_loss_finite": math.isfinite(forward["routing"]["router_loss"]),
        })

    return ({
        "status": "PASS" if all(gates.values()) else "FAIL",
        "run_dir": _relative(run_dir),
        "training_wall_seconds": manifest_entry["elapsed_seconds"],
        "artifacts": {
            name: {
                "path": _relative(path),
                "exists": artifact_presence[name],
                "sha256": artifact_hashes_before[name],
                "bytes": path.stat().st_size,
            }
            for name, path in artifacts.items()
        },
        "configuration_hashes": {
            "source": source_hash,
            "source_manifest": manifest_entry["source_config_sha256"],
            "runtime": runtime_hash,
            "runtime_manifest": manifest_entry["runtime_config_sha256"],
            **hash_checks,
        },
        "logged_epoch_1_losses": logged_losses,
        "training_update_evidence": update_evidence,
        "checkpoint_forward": forward,
        "artifact_hashes_unchanged_during_audit": artifacts_unchanged,
        "gates": gates,
    }, config)


def audit(manifest_path: Path) -> dict[str, Any]:
    started = time.perf_counter()
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("schema_version", 0) < 2 or manifest.get("status") != "COMPLETE":
        raise ValueError("Audit requires a completed schema-version-2 manifest with a pre-training source snapshot.")
    if set(manifest.get("runs", {})) != {"dense", "moe"}:
        raise ValueError("Manifest must contain exactly the dense and moe smoke runs.")
    source_snapshot = _audit_source_snapshot(manifest.get("source_snapshot", {}))
    safe_data = manifest.get("data_contract", {})
    postflight_safe_data = manifest.get("postflight_data_contract", {})
    if safe_data.get("status") != "PASS" or postflight_safe_data.get("status") != "PASS":
        raise ValueError("Smoke manifest is missing passing preflight and postflight safe-data contracts.")
    stable_data_fields = {
        "forcing_manifest_sha256",
        "supervision_manifest_sha256",
        "forcing_file_sha256",
        "statics_file_sha256",
        "target_tree_sha256",
    }
    safe_data_unchanged = all(safe_data.get(field) == postflight_safe_data.get(field)
                              for field in stable_data_fields)
    manifest_access = manifest.get("data_access", {})
    access_path = _repo_path(manifest_access.get("path", ""))
    recomputed_access = audit_access_log(access_path, safe_data["forcing_dir"], safe_data["supervision_dir"])
    data_access_pass = (manifest_access.get("status") == "PASS"
                        and manifest_access.get("log_sha256") == recomputed_access["log_sha256"])

    run_reports = {}
    source_configs = {}
    for label in ("dense", "moe"):
        run_reports[label], _ = _audit_run(label, manifest["runs"][label])
        source_configs[label] = Config(_repo_path(manifest["runs"][label]["source_config"]))
    pair_contract = _pair_contract(source_configs["dense"], source_configs["moe"])
    pair_pass = pair_contract["common_fields_match"] and pair_contract["active_width_matches"]
    cpu_pass = (source_snapshot["passed"] and pair_pass and safe_data_unchanged and data_access_pass
                and all(report["status"] == "PASS" for report in run_reports.values()))

    return {
        "schema_version": 2,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "invocation_id": manifest["run_id"],
        "manifest": {"path": _relative(manifest_path), "sha256": _sha256(manifest_path)},
        "code": {
            **_git_metadata(),
            "audit_script": {"path": _relative(AUDIT_SCRIPT), "sha256": _sha256(AUDIT_SCRIPT)},
            "pre_training_source_snapshot": source_snapshot,
        },
        "environment": {
            "platform": platform.platform(),
            "python": platform.python_version(),
            "torch": torch.__version__,
            "audit_device": "cpu",
            "cuda_used": False,
        },
        "data_contract": {
            "dataset": "candidate-safe CAMELS-US Track 0 bundle",
            "forcing_product": "Maurer",
            "basins": 4,
            "target_usage": "supervised target in the declared training period only",
            "checkpoint_forward_period": "train",
            "formal_evaluation_period_target_used": False,
            "preflight": safe_data,
            "postflight": postflight_safe_data,
            "safe_data_unchanged": safe_data_unchanged,
            "dynamic_file_access": recomputed_access,
            "dynamic_file_access_matches_manifest": data_access_pass,
        },
        "pair_contract": pair_contract,
        "runs": run_reports,
        "cpu_technical_gate": {
            "status": "PASS" if cpu_pass else "FAIL",
            "passed": cpu_pass,
            "meaning": (
                "Both one-update CPU jobs and checkpoint-reload invariants completed; "
                "this is not a hydrological skill result."
            ),
        },
        "full_size_gpu_resource_gate": {
            "status": "NOT_RUN",
            "passed": False,
            "required_for_cpu_technical_pass": False,
            "required_before_full_size_gpu_training": True,
            "criterion": "Measure the selected full-size configuration and confirm peak CUDA memory is below 12 GiB.",
        },
        "overall_status": "CPU_TECHNICAL_PASS_GPU_RESOURCE_GATE_NOT_RUN" if cpu_pass else "FAIL",
        "audit_wall_seconds": time.perf_counter() - started,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--report", type=Path, default=DEFAULT_REPORT)
    args = parser.parse_args()

    os.chdir(REPO_ROOT)
    torch.set_num_threads(1)
    manifest_path = _repo_path(args.manifest)
    report_path = _repo_path(args.report)
    if report_path.exists():
        raise FileExistsError(f"Refusing to overwrite existing smoke report: {report_path}")

    report = audit(manifest_path)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    with report_path.open("x", encoding="utf-8") as file:
        json.dump(report, file, indent=2, ensure_ascii=False)
        file.write("\n")
    print(json.dumps({"overall_status": report["overall_status"], "report": _relative(report_path)}, indent=2))
    return 0 if report["cpu_technical_gate"]["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
