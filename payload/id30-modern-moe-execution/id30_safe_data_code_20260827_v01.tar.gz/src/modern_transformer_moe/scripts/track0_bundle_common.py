"""Shared invariants for candidate-safe CAMELS-US development bundles."""

from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path
from typing import Iterable

import pandas as pd

from neuralhydrology.datasetzoo.camelsus_track0_bundle import (FORCING_VARIABLES, TARGET_COLUMN,
                                                               TRACK0_STATIC_ATTRIBUTES)


SCHEMA_VERSION = 1
EXPECTED_BASIN_COUNT = 531


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_records(records: Iterable[tuple[str, str]]) -> str:
    digest = hashlib.sha256()
    for name, value in sorted(records):
        digest.update(name.encode("utf-8"))
        digest.update(b"\0")
        digest.update(value.encode("ascii"))
        digest.update(b"\n")
    return digest.hexdigest()


def read_basin_list(path: Path, expected_count: int = EXPECTED_BASIN_COUNT) -> list[str]:
    basins = [line.strip() for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(basins) != expected_count:
        raise ValueError(f"Expected exactly {expected_count} basins, found {len(basins)} in {path}.")
    if len(set(basins)) != len(basins):
        raise ValueError(f"Duplicate basin identifiers found in {path}.")
    invalid = [basin for basin in basins if re.fullmatch(r"[0-9]{8}", basin) is None]
    if invalid:
        raise ValueError(f"Invalid eight-digit basin identifiers in {path}: {invalid[:5]}")
    return basins


def parse_date(value: str | pd.Timestamp) -> pd.Timestamp:
    timestamp = pd.Timestamp(value)
    if timestamp != timestamp.normalize():
        raise ValueError(f"Date must not include a time component: {value}")
    return timestamp


def exact_daily_index(start_date: str | pd.Timestamp, end_date: str | pd.Timestamp) -> pd.DatetimeIndex:
    start = parse_date(start_date)
    end = parse_date(end_date)
    if start > end:
        raise ValueError(f"Start date {start.date()} is after end date {end.date()}.")
    return pd.date_range(start, end, freq="D", name="date")


def find_unique_file(root: Path, pattern: str, description: str) -> Path:
    matches = sorted(Path(root).glob(pattern))
    if len(matches) != 1:
        raise FileNotFoundError(f"Expected exactly one {description} matching {root / pattern}, found {len(matches)}.")
    return matches[0]


def builder_fingerprint(builder_path: Path) -> dict:
    common_path = Path(__file__).resolve()
    builder_path = Path(builder_path).resolve()
    return {
        "files": {
            builder_path.name: sha256_file(builder_path),
            common_path.name: sha256_file(common_path),
        }
    }


def write_json_exclusive(path: Path, payload: dict) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as file:
        json.dump(payload, file, indent=2, ensure_ascii=False, sort_keys=True)
        file.write("\n")


def publish_staged_bundle(staging_dir: Path, output_dir: Path, manifest_path: Path, manifest: dict) -> None:
    """Publish a new directory and manifest without replacing either target."""
    output_dir = Path(output_dir)
    manifest_path = Path(manifest_path)
    if output_dir.exists() or manifest_path.exists():
        raise FileExistsError(f"Refusing to overwrite output or manifest: {output_dir}, {manifest_path}")

    temporary_manifest = manifest_path.with_name(f".{manifest_path.name}.{os.getpid()}.tmp")
    if temporary_manifest.exists():
        raise FileExistsError(f"Refusing to overwrite temporary manifest: {temporary_manifest}")
    write_json_exclusive(temporary_manifest, manifest)
    try:
        staging_dir.replace(output_dir)
        temporary_manifest.replace(manifest_path)
    except Exception:
        if temporary_manifest.exists():
            temporary_manifest.unlink()
        raise
