"""Compare hash-bound internal-validation artifacts without test-period access.

Inputs use ``ROLE:SEED=PATH``.  Roles are B01, D01, D02, D03,
SELECTED_DENSE, and M01.  The script recomputes every basin's Nash-Sutcliffe
efficiency from ``validation_results.p``; JSON summary values are never trusted.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import pickle
import statistics
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from src.fair_benchmark.stats import paired_comparison
from src.modern_transformer_moe.scripts import audit_configs


REPO_ROOT = Path(__file__).resolve().parents[3]
ALLOWED_ROLES = {"B01", "D01", "D02", "D03", "SELECTED_DENSE", "M01"}
SEEDS = (100, 200, 300)
MIN_EFFECT = 0.01
MAX_WILCOXON_P = 0.05
BOOTSTRAP_SEED = 20260826
FORBIDDEN_CONFIG_KEYS = audit_configs.FORBIDDEN_CONFIG_KEYS | {
    "test_basin_file", "test_start_date", "test_end_date"
}
EXPECTED_ARCHITECTURE = {
    "D01": (128, 4),
    "D02": (256, 4),
    "D03": (256, 8),
}
ROUTER_DIAGNOSTIC_REQUIRED_KEYS = {
    "schema_version",
    "seed",
    "period",
    "checkpoint_path",
    "checkpoint_sha256",
    "run_config_path",
    "run_config_sha256",
    "scaler_path",
    "scaler_sha256",
    "basin_file_path",
    "basin_file_sha256",
    "basin_count",
    "validation_start_date",
    "validation_end_date",
    "validation_day_count",
    "validation_token_count",
    "top_k",
    "moe_layer_count",
    "total_routed_assignments",
    "dropped_token_count",
    "layers",
}
ROUTER_LAYER_REQUIRED_KEYS = {
    "layer_id",
    "validation_token_count",
    "dropped_token_count",
    "expert_token_counts",
}


@dataclass(frozen=True)
class LoadedArtifact:
    role: str
    seed: int
    artifact_path: Path
    artifact_sha256: str
    artifact: dict[str, Any]
    source_config: dict[str, Any]
    basin_nse: dict[str, float]
    predictions_all_finite: bool
    complete_binding: dict[str, Any] | None


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _resolve_inside_repo(path_text: str | Path, repo_root: Path) -> Path:
    path = Path(path_text)
    if not path.is_absolute():
        path = repo_root / path
    path = path.resolve()
    try:
        path.relative_to(repo_root.resolve())
    except ValueError as error:
        raise ValueError(f"artifact path must remain inside the repository: {path}") from error
    return path


def parse_artifact_spec(text: str) -> tuple[str, int, Path]:
    try:
        identity, path_text = text.split("=", 1)
        role, seed_text = identity.split(":", 1)
        seed = int(seed_text)
    except (TypeError, ValueError) as error:
        raise ValueError(f"artifact input must use ROLE:SEED=PATH, got {text!r}") from error
    role = role.upper()
    if role not in ALLOWED_ROLES:
        raise ValueError(f"artifact role must be one of {sorted(ALLOWED_ROLES)}, got {role!r}")
    if seed not in SEEDS:
        raise ValueError(f"development seed must be one of {SEEDS}, got {seed}")
    if not path_text:
        raise ValueError("artifact path cannot be empty")
    return role, seed, Path(path_text)


def _config_contains_forbidden_value(value: Any) -> bool:
    if isinstance(value, dict):
        return any(_config_contains_forbidden_value(item) for item in value.values())
    if isinstance(value, (list, tuple)):
        return any(_config_contains_forbidden_value(item) for item in value)
    text = str(value).lower().replace("\\", "/")
    return any(fragment.lower() in text for fragment in audit_configs.FORBIDDEN_VALUE_FRAGMENTS)


def _validate_source_config(role: str, seed: int, config: dict[str, Any]) -> None:
    forbidden_keys = sorted(set(config) & FORBIDDEN_CONFIG_KEYS)
    if forbidden_keys:
        raise ValueError(f"{role}:{seed} source config contains forbidden keys: {forbidden_keys}")
    if _config_contains_forbidden_value(config):
        raise ValueError(f"{role}:{seed} source config refers to a sealed/forbidden input or date")
    expected = {
        "train_start_date": "01/10/1999",
        "train_end_date": "30/09/2006",
        "validation_start_date": "01/10/2006",
        "validation_end_date": "30/09/2008",
        "number_of_basins": 531,
        "epochs": 30,
        "seq_length": 270,
    }
    for key, value in expected.items():
        if config.get(key) != value:
            raise ValueError(f"{role}:{seed} source config {key}={config.get(key)!r}, expected {value!r}")
    if int(config.get("seed", -1)) != seed:
        raise ValueError(f"{role}:{seed} source config seed disagrees with the input identity")
    model = config.get("model")
    if role == "B01" and model != "cudalstm":
        raise ValueError(f"B01:{seed} must bind a cudalstm run")
    if role in {"D01", "D02", "D03", "SELECTED_DENSE"} and model != "modern_transformer":
        raise ValueError(f"{role}:{seed} must bind a dense modern_transformer run")
    if role == "M01" and model != "modern_transformer_moe":
        raise ValueError(f"M01:{seed} must bind a modern_transformer_moe run")
    if role in EXPECTED_ARCHITECTURE:
        expected_width, expected_layers = EXPECTED_ARCHITECTURE[role]
        width = sum(config.get("dynamics_embedding", {}).get("hiddens", [])[-1:]) + sum(
            config.get("statics_embedding", {}).get("hiddens", [])[-1:]
        )
        if (width, config.get("transformer_nlayers")) != (expected_width, expected_layers):
            raise ValueError(f"{role}:{seed} architecture does not match its preregistered capacity point")


def _predictions_are_finite(results_path: Path, expected_basins: set[str]) -> bool:
    with results_path.open("rb") as stream:
        results = pickle.load(stream)
    if not isinstance(results, dict) or set(results) != expected_basins:
        raise ValueError("validation_results.p does not contain exactly the frozen 531 basins")
    for basin in expected_basins:
        basin_results = results[basin]
        if not isinstance(basin_results, dict) or len(basin_results) != 1:
            raise ValueError(f"validation result for basin {basin} must contain exactly one frequency")
        frequency = next(iter(basin_results.values()))
        dataset = frequency.get("xr") if isinstance(frequency, dict) else None
        if dataset is None or "QObs(mm/d)_sim" not in dataset:
            raise ValueError(f"validation result for basin {basin} has no simulated discharge")
        simulated = np.asarray(dataset["QObs(mm/d)_sim"].values)
        if simulated.size == 0 or not np.isfinite(simulated).all():
            return False
    return True


def load_bound_artifact(
    role: str,
    seed: int,
    path: Path,
    *,
    repo_root: Path = REPO_ROOT,
    require_canonical_derived: bool = True,
    require_complete_binding: bool = True,
) -> LoadedArtifact:
    """Verify all hashes and recompute metrics from the bound validation pickle."""
    repo_root = Path(repo_root).resolve()
    path = _resolve_inside_repo(path, repo_root)
    artifact = audit_configs.load_json(path)
    if set(artifact) != audit_configs.METRICS_ARTIFACT_REQUIRED_KEYS:
        raise ValueError(f"{path} does not use the exact epoch-30 metrics artifact schema")
    if artifact.get("experiment_id") != role:
        raise ValueError(
            f"artifact experiment_id={artifact.get('experiment_id')!r} does not match input role {role!r}"
        )
    complete_binding: dict[str, Any] | None = None
    if require_complete_binding:
        from src.modern_transformer_moe.scripts import run_development

        complete_binding = run_development.verify_complete_run_binding(
            role, seed, path, repo_root=repo_root
        )
    for prefix in ("source_config", "run_config", "checkpoint", "validation_metrics", "validation_results"):
        bound_path = audit_configs.resolve_repository_file(artifact[f"{prefix}_path"], repo_root)
        if not bound_path.is_file() or _sha256(bound_path) != artifact[f"{prefix}_sha256"]:
            raise ValueError(f"{role}:{seed} {prefix} hash binding failed")
    if artifact.get("epoch") != 30 or artifact.get("metric") != "NSE":
        raise ValueError(f"{role}:{seed} must use epoch 30 and Nash-Sutcliffe efficiency")
    if artifact.get("period") != audit_configs.SELECTION_PERIOD:
        raise ValueError(f"{role}:{seed} artifact is not the declared internal-validation period")

    source_path = audit_configs.resolve_repository_file(artifact["source_config_path"], repo_root)
    if seed == 100 and require_canonical_derived:
        expected_relative = audit_configs.CONFIG_BY_ID.get(role)
        if expected_relative is None or source_path != (repo_root / expected_relative).resolve():
            raise ValueError(f"{role}:100 does not bind its canonical preregistered configuration")
    if seed in {200, 300} and require_canonical_derived:
        from src.modern_transformer_moe.scripts import run_development

        expected_path, _, _ = run_development._validate_derived_config(role, seed, repo_root)
        if source_path != expected_path:
            raise ValueError(f"{role}:{seed} does not bind its canonical immutable derived configuration")
    run_config_path = audit_configs.resolve_repository_file(artifact["run_config_path"], repo_root)
    checkpoint_path = audit_configs.resolve_repository_file(artifact["checkpoint_path"], repo_root)
    results_path = audit_configs.resolve_repository_file(artifact["validation_results_path"], repo_root)
    metrics_path = audit_configs.resolve_repository_file(artifact["validation_metrics_path"], repo_root)
    run_dir = checkpoint_path.parent
    if checkpoint_path.name != "model_epoch030.pt" or run_config_path != run_dir / "config.yml":
        raise ValueError(f"{role}:{seed} checkpoint/run-config topology is invalid")
    if results_path != run_dir / "validation/model_epoch030/validation_results.p":
        raise ValueError(f"{role}:{seed} validation-results path is not the epoch-30 validation product")
    if metrics_path != run_dir / "validation/model_epoch030/validation_metrics.csv":
        raise ValueError(f"{role}:{seed} validation-metrics path is not the epoch-30 validation product")

    source_config = audit_configs.load_yaml(source_path)
    run_config = audit_configs.load_yaml(run_config_path)
    _validate_source_config(role, seed, source_config)
    snapshot_issues = audit_configs.audit_run_config_snapshot(source_config, run_config, run_dir, repo_root)
    if snapshot_issues:
        raise ValueError(f"{role}:{seed} run config drifted: {'; '.join(snapshot_issues)}")

    basin_nse = audit_configs.load_validation_results_nse(results_path, repo_root)
    csv_nse = audit_configs.load_validation_nse_csv(metrics_path, repo_root)
    if any(not math.isclose(basin_nse[basin], csv_nse[basin], rel_tol=0.0, abs_tol=1e-12) for basin in basin_nse):
        raise ValueError(f"{role}:{seed} CSV disagrees with metrics recomputed from validation_results.p")
    declared = artifact.get("basin_nse")
    if not isinstance(declared, dict) or set(declared) != set(basin_nse):
        raise ValueError(f"{role}:{seed} declared basin metrics do not cover exactly 531 basins")
    if any(not math.isclose(float(declared[basin]), basin_nse[basin], rel_tol=0.0, abs_tol=1e-12)
           for basin in basin_nse):
        raise ValueError(f"{role}:{seed} declared scores disagree with recomputed scores")
    recomputed_median = float(statistics.median(basin_nse.values()))
    if not math.isclose(float(artifact.get("median_nse")), recomputed_median, rel_tol=0.0, abs_tol=1e-12):
        raise ValueError(f"{role}:{seed} declared median disagrees with recomputed scores")
    finite = _predictions_are_finite(results_path, set(basin_nse))
    return LoadedArtifact(
        role, seed, path, _sha256(path), artifact, source_config, basin_nse, finite, complete_binding
    )


def _mean_by_basin(items: list[LoadedArtifact]) -> dict[str, float]:
    basins = list(items[0].basin_nse)
    return {basin: float(np.mean([item.basin_nse[basin] for item in items])) for basin in basins}


def _load_router_diagnostics(
    texts: list[str], moe: dict[int, LoadedArtifact], repo_root: Path
) -> tuple[bool, list[str], dict[str, dict[str, str]]]:
    provided: dict[int, Path] = {}
    for text in texts:
        try:
            seed_text, path_text = text.split("=", 1)
            seed = int(seed_text)
        except ValueError as error:
            raise ValueError(f"router diagnostic must use SEED=PATH, got {text!r}") from error
        if seed in provided:
            raise ValueError(f"duplicate router diagnostic for seed {seed}")
        provided[seed] = Path(path_text)
    missing = [seed for seed in SEEDS if seed not in provided]
    if missing:
        return False, [f"missing_router_diagnostics_for_seeds={missing}"], {}
    reasons: list[str] = []
    bindings: dict[str, dict[str, str]] = {}
    for seed in SEEDS:
        path = _resolve_inside_repo(provided[seed], repo_root)
        content = path.read_bytes()
        value = json.loads(content)
        if not isinstance(value, dict):
            raise ValueError(f"router diagnostic {path} must contain a JSON object")
        bindings[str(seed)] = {
            "path": path.relative_to(repo_root).as_posix(),
            "sha256": hashlib.sha256(content).hexdigest(),
        }
        if set(value) != ROUTER_DIAGNOSTIC_REQUIRED_KEYS:
            raise ValueError(f"router diagnostic {path} has an unexpected schema")
        if value["schema_version"] != 2:
            raise ValueError(f"router diagnostic {path} has an unsupported schema version")
        if value["seed"] != seed or value["period"] != audit_configs.SELECTION_PERIOD:
            raise ValueError(f"router diagnostic {path} has the wrong seed or period")
        artifact = moe[seed].artifact
        if (value["checkpoint_path"] != artifact["checkpoint_path"]
                or value["checkpoint_sha256"] != artifact["checkpoint_sha256"]):
            raise ValueError(f"router diagnostic {path} is not bound to the compared checkpoint")
        if (value["run_config_path"] != artifact["run_config_path"]
                or value["run_config_sha256"] != artifact["run_config_sha256"]):
            raise ValueError(f"router diagnostic {path} is not bound to the compared run config")

        bound_paths = {
            prefix: audit_configs.resolve_repository_file(value[f"{prefix}_path"], repo_root)
            for prefix in ("checkpoint", "run_config", "scaler", "basin_file")
        }
        for prefix, bound_path in bound_paths.items():
            if not bound_path.is_file() or _sha256(bound_path) != value[f"{prefix}_sha256"]:
                raise ValueError(f"router diagnostic {path} {prefix} hash binding failed")
        run_dir = bound_paths["checkpoint"].parent
        if bound_paths["run_config"] != run_dir / "config.yml":
            raise ValueError(f"router diagnostic {path} has an invalid run-config topology")
        preferred_scaler = run_dir / "train_data/train_data_scaler.yml"
        if not preferred_scaler.is_file():
            preferred_scaler = run_dir / "train_data/train_data_scaler.p"
        if bound_paths["scaler"] != preferred_scaler:
            raise ValueError(f"router diagnostic {path} is not bound to the run's canonical scaler")
        if bound_paths["basin_file"] != (repo_root / audit_configs.BASIN_FILE).resolve():
            raise ValueError(f"router diagnostic {path} is not bound to the frozen basin manifest")

        expected_days = int(
            (np.datetime64(audit_configs.SELECTION_PERIOD["end"])
             - np.datetime64(audit_configs.SELECTION_PERIOD["start"])) / np.timedelta64(1, "D")
        ) + 1
        expected_coverage = {
            "basin_count": 531,
            "validation_start_date": audit_configs.SELECTION_PERIOD["start"],
            "validation_end_date": audit_configs.SELECTION_PERIOD["end"],
            "validation_day_count": expected_days,
        }
        for key, expected_value in expected_coverage.items():
            if value[key] != expected_value:
                raise ValueError(f"router diagnostic {path} {key}={value[key]!r}, expected {expected_value!r}")

        expected_count = int(moe[seed].source_config.get("transformer_moe_num_experts", 0))
        expected_top_k = int(moe[seed].source_config.get("transformer_moe_top_k", 0))
        first_moe_layer = int(moe[seed].source_config.get("transformer_moe_first_layer", 0))
        transformer_layer_count = int(moe[seed].source_config.get("transformer_nlayers", 0))
        expected_layer_count = (
            transformer_layer_count - first_moe_layer
        )
        expected_layer_ids = [
            f"blocks.{layer_index}.feed_forward"
            for layer_index in range(first_moe_layer, transformer_layer_count)
        ]
        integer_fields = (
            "validation_token_count",
            "top_k",
            "moe_layer_count",
            "total_routed_assignments",
            "dropped_token_count",
        )
        if any(not isinstance(value[key], int) or isinstance(value[key], bool) for key in integer_fields):
            raise ValueError(f"router diagnostic {path} has a non-integer routing-accounting field")
        if value["validation_token_count"] <= 0:
            raise ValueError(f"router diagnostic {path} has no validation tokens")
        if value["top_k"] != expected_top_k or value["moe_layer_count"] != expected_layer_count:
            raise ValueError(f"router diagnostic {path} disagrees with the compared MoE architecture")
        layers = value["layers"]
        if not isinstance(layers, list) or len(layers) != expected_layer_count:
            raise ValueError(f"router diagnostic {path} has the wrong number of per-layer records")
        per_layer_assignments = value["validation_token_count"] * expected_top_k
        counted_assignments = 0
        counted_dropped_tokens = 0
        for expected_layer_id, layer in zip(expected_layer_ids, layers):
            if not isinstance(layer, dict) or set(layer) != ROUTER_LAYER_REQUIRED_KEYS:
                raise ValueError(f"router diagnostic {path} has an invalid per-layer schema")
            if layer["layer_id"] != expected_layer_id:
                raise ValueError(f"router diagnostic {path} has an unstable or unexpected layer identifier")
            for key in ("validation_token_count", "dropped_token_count"):
                if not isinstance(layer[key], int) or isinstance(layer[key], bool):
                    raise ValueError(f"router diagnostic {path} layer {expected_layer_id} has non-integer accounting")
            if layer["validation_token_count"] != value["validation_token_count"]:
                raise ValueError(f"router diagnostic {path} routed layers processed different token counts")
            counts = layer["expert_token_counts"]
            if (not isinstance(counts, list) or len(counts) != expected_count
                    or any(not isinstance(count, int) or isinstance(count, bool) or count < 0 for count in counts)):
                raise ValueError(f"router diagnostic {path} layer {expected_layer_id} has invalid expert counts")
            if sum(counts) != per_layer_assignments:
                raise ValueError(
                    f"router diagnostic {path} layer {expected_layer_id} violates tokens times top-k accounting"
                )
            if layer["dropped_token_count"] != 0:
                raise ValueError(
                    f"router diagnostic {path} layer {expected_layer_id} violates zero-dropped-token accounting"
                )
            counted_assignments += sum(counts)
            counted_dropped_tokens += layer["dropped_token_count"]
            for expert_index, count in enumerate(counts):
                if count == 0:
                    reasons.append(f"dead_expert_seed_{seed}_layer_{expected_layer_id}_expert_{expert_index}")
        expected_assignments = per_layer_assignments * expected_layer_count
        if (value["total_routed_assignments"] != expected_assignments
                or counted_assignments != expected_assignments):
            raise ValueError(f"router diagnostic {path} violates routed-assignment accounting")
        if value["dropped_token_count"] != 0 or counted_dropped_tokens != value["dropped_token_count"]:
            raise ValueError(f"router diagnostic {path} violates the zero-dropped-token contract")
    return not reasons, reasons, bindings


def compare(
    artifact_specs: list[str],
    *,
    router_diagnostic_specs: list[str] | None = None,
    repo_root: Path = REPO_ROOT,
    n_bootstrap: int = 10000,
    require_canonical_derived: bool = True,
    require_complete_binding: bool = True,
) -> dict[str, Any]:
    """Return preregistered development gates, or honest NOT_RUN states."""
    repo_root = Path(repo_root).resolve()
    loaded: dict[tuple[str, int], LoadedArtifact] = {}
    for text in artifact_specs:
        role, seed, path = parse_artifact_spec(text)
        key = (role, seed)
        if key in loaded:
            raise ValueError(f"duplicate artifact input for {role}:{seed}")
        loaded[key] = load_bound_artifact(
            role,
            seed,
            path,
            repo_root=repo_root,
            require_canonical_derived=require_canonical_derived,
            require_complete_binding=require_complete_binding,
        )

    report: dict[str, Any] = {
        "schema_version": 1,
        "analysis_period": audit_configs.SELECTION_PERIOD,
        "metric": "NSE",
        "artifacts": {
            f"{role}:{seed}": {
                "path": item.artifact_path.relative_to(repo_root).as_posix(),
                "sha256": item.artifact_sha256,
                "run_id": item.complete_binding["run_id"] if item.complete_binding is not None else "not_checked",
                "binding_status": (
                    item.complete_binding["status"] if item.complete_binding is not None else "not_checked"
                ),
            }
            for (role, seed), item in sorted(loaded.items())
        },
    }
    single_required = [("B01", 100), ("D01", 100), ("D02", 100), ("D03", 100)]
    missing_single = [f"{role}:{seed}" for role, seed in single_required if (role, seed) not in loaded]
    selected_role: str | None = None
    if missing_single:
        report["single_seed_dense_gate"] = {"status": "NOT_RUN", "missing_artifacts": missing_single}
    else:
        medians = {
            role: float(statistics.median(loaded[(role, 100)].basin_nse.values()))
            for role in ("D01", "D02", "D03")
        }
        order = {"D01": 0, "D02": 1, "D03": 2}
        selected_role = max(medians, key=lambda role: (medians[role], -order[role]))
        baseline_median = float(statistics.median(loaded[("B01", 100)].basin_nse.values()))
        passed = medians[selected_role] >= baseline_median
        report["single_seed_dense_gate"] = {
            "status": "PASS" if passed else "HOLD",
            "selected_dense": selected_role,
            "candidate_median_nse": medians,
            "baseline_median_nse": baseline_median,
            "selected_minus_baseline_median": medians[selected_role] - baseline_median,
            "rule": "selected_dense_median_nse_greater_than_or_equal_to_corrected_lstm_median_nse",
        }

    if selected_role is None:
        report["three_seed_continuation_gate"] = {
            "status": "NOT_RUN", "reasons": ["single_seed_dense_selection_not_available"]
        }
        return report
    dense_by_seed = {100: loaded[(selected_role, 100)]}
    for seed in (200, 300):
        if ("SELECTED_DENSE", seed) in loaded:
            dense_by_seed[seed] = loaded[("SELECTED_DENSE", seed)]
    moe_by_seed = {seed: loaded[("M01", seed)] for seed in SEEDS if ("M01", seed) in loaded}
    baseline_by_seed = {seed: loaded[("B01", seed)] for seed in SEEDS if ("B01", seed) in loaded}
    missing_three = []
    for seed in SEEDS:
        if seed not in dense_by_seed:
            missing_three.append(f"SELECTED_DENSE:{seed}")
        if seed not in moe_by_seed:
            missing_three.append(f"M01:{seed}")
        if seed not in baseline_by_seed:
            missing_three.append(f"B01:{seed}")
    if missing_three:
        report["three_seed_continuation_gate"] = {"status": "NOT_RUN", "missing_artifacts": missing_three}
        return report

    for seed in SEEDS:
        pair_issues = audit_configs.audit_dense_sparse_pair(
            dense_by_seed[seed].source_config, moe_by_seed[seed].source_config
        )
        if pair_issues:
            raise ValueError(
                f"dense/M01 seed {seed} is not the preregistered paired treatment: "
                + "; ".join(pair_issues)
            )

    dense_mean = _mean_by_basin([dense_by_seed[seed] for seed in SEEDS])
    moe_mean = _mean_by_basin([moe_by_seed[seed] for seed in SEEDS])
    baseline_mean = _mean_by_basin([baseline_by_seed[seed] for seed in SEEDS])
    stats = paired_comparison(moe_mean, dense_mean, n_bootstrap=n_bootstrap, seed=BOOTSTRAP_SEED)
    finite_predictions = all(item.predictions_all_finite for item in [
        *dense_by_seed.values(), *moe_by_seed.values(), *baseline_by_seed.values()
    ])
    router_ok, router_reasons, router_bindings = _load_router_diagnostics(
        router_diagnostic_specs or [], moe_by_seed, repo_root
    )
    sparse_median = float(statistics.median(moe_mean.values()))
    baseline_median = float(statistics.median(baseline_mean.values()))
    checks = {
        "all_531_paired_basins": stats["n"] == 531,
        "median_paired_delta_at_least_0_01": stats["median_paired_delta"] >= MIN_EFFECT,
        "wilcoxon_p_below_0_05": math.isfinite(stats["wilcoxon_p"]) and stats["wilcoxon_p"] < MAX_WILCOXON_P,
        "bootstrap_95pct_lower_above_zero": stats["ci_low"] > 0.0,
        "all_validation_predictions_finite": finite_predictions,
        "no_dead_expert": router_ok,
        "sparse_not_below_corrected_lstm": sparse_median >= baseline_median,
        "single_seed_dense_gate_passed": report["single_seed_dense_gate"]["status"] == "PASS",
    }
    report["three_seed_continuation_gate"] = {
        "status": "PASS" if all(checks.values()) else "HOLD",
        "aggregation": "mean_NSE_across_seeds_100_200_300_per_basin_then_pair_531_basins",
        "statistics": stats,
        "router_diagnostics": router_bindings,
        "sparse_aggregate_median_nse": sparse_median,
        "baseline_aggregate_median_nse": baseline_median,
        "checks": checks,
        "reasons": router_reasons + [name for name, passed in checks.items() if not passed],
        "thresholds": {
            "median_paired_delta": MIN_EFFECT,
            "wilcoxon_p_exclusive_maximum": MAX_WILCOXON_P,
            "bootstrap_confidence": 0.95,
            "bootstrap_replicates": n_bootstrap,
            "bootstrap_seed": BOOTSTRAP_SEED,
        },
    }
    return report


def _write_new_report(path: Path, report: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        if path.exists():
            raise FileExistsError(f"refusing to overwrite development report: {path}")
        with temporary.open("x", encoding="utf-8") as stream:
            json.dump(report, stream, indent=2, sort_keys=True)
            stream.write("\n")
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifact", action="append", default=[], metavar="ROLE:SEED=PATH")
    parser.add_argument("--router-diagnostics", action="append", default=[], metavar="SEED=PATH")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--bootstrap-replicates", type=int, default=10000)
    args = parser.parse_args()
    report = compare(
        args.artifact,
        router_diagnostic_specs=args.router_diagnostics,
        n_bootstrap=args.bootstrap_replicates,
    )
    if args.output is not None:
        output = _resolve_inside_repo(args.output, REPO_ROOT)
        _write_new_report(output, report)
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
