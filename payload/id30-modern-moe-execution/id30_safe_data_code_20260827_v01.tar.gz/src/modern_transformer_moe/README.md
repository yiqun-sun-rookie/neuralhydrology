# Modern causal Transformer and mixture-of-experts development configurations

This directory contains the development-only comparison defined in
`docs/plans/2026-08-26-modern-causal-transformer-moe-fair-baseline.md`. It does
not contain results, does not access the sealed evaluation period, and does not
authorize an hours-long training run.

## Information contract

Every runnable configuration uses exactly the same 531 CAMELS-US basins, the
Maurer forcing product, five forcing variables, 27 allowed static attributes,
and one supervised streamflow target. The causal input window is 270 days.
Development training is 1999-10-01 through 2006-09-30; internal validation is
2006-10-01 through 2008-09-30.

There are intentionally no `test_*` fields, external scaler files, checkpoint
reuse fields, additional feature files, autoregressive inputs, or full-period
normalization fields. A fresh NeuralHydrology run computes normalization
statistics from the training dataset and passes the saved training scaler to
validation. Observed streamflow is a supervised target only and is never a
model input.

The configuration and audit code may read the frozen basin identifier list. It
must never open hydrological signature attributes, USGS streamflow files, the
held evaluation answer, or any evaluation-period prediction file.

## Development experiment family

- `B01`: corrected fused long short-term memory network control, hidden width
  256, Adam, batch size 256, and the historical learning-rate schedule.
- `D01`: dense modern Transformer, width 128, four layers, four heads, gated
  feed-forward width 512.
- `D02`: dense modern Transformer, width 256, four layers, eight heads, gated
  feed-forward width 1024.
- `D03`: dense modern Transformer, width 256, eight layers, eight heads, gated
  feed-forward width 1024.
- `M01`: a reserved sparse experiment identifier. Its configuration does not
  exist until internal validation has selected one dense candidate.

The three dense Transformers use AdamW, batch size 64, and learning rates
`3e-4`, `1e-4`, and `3e-5` beginning at epochs 0, 11, and 21. This is a
Transformer-specific optimization recipe, not a claim that architecture alone
explains differences from the long short-term memory network. All three dense
candidates share that recipe, so capacity selection is not confounded by batch
size or learning rate. The selected dense model and `M01` will be identical in
these fields.

Batch size 64 is a conservative pre-run choice because the training core has
no mixed-precision or gradient-accumulation interface and the target GPU has 12
GB of memory. Task 5 must still complete and measure one full training step,
including forward pass, loss, backward pass, and `optimizer.step()`, before any
long run; these files are planned configurations, not evidence that all
capacities fit in memory.

`save_all_output` is fixed to `false`. The sparse model returns scalar router
diagnostics that the current tester cannot concatenate as time-series outputs;
changing this flag requires a separate tester-compatibility fix and test.

`base_development.yml` is a non-run reference for shared information, period,
epoch, context, and logging fields. It intentionally omits batch size,
optimizer, and learning rate because those differ by model family. Every
registered runnable experiment is standalone and has an isolated output root.

## Two-stage dense selection and sparse generation

Dense architecture selection uses the median basin Nash-Sutcliffe efficiency
on the internal validation period at the fixed epoch 30. It does not select an
arbitrary best epoch. D01, D02, and D03 are the complete candidate set, and the
selection rule is
`highest_median_validation_NSE_at_epoch_30_tie_break_D01_D02_D03`. An exact
tie selects the smaller preregistered architecture first: D01, then D02, then
D03.

Before selection, the experiment registry marks `M01` as
`awaiting_dense_selection`; `moe_selected_s100.yml` must not exist. After the
dense runs, each D01-D03 registry row changes to `development_complete` and
records its `model_epoch030.pt` path and SHA-256 plus the metric artifact path
and SHA-256. First build each artifact from the actual NeuralHydrology run:

```powershell
python -m src.modern_transformer_moe.scripts.build_epoch030_metrics_artifact `
  --experiment-id D01 `
  --run-dir results/30_modern_transformer_moe/D01/<actual-run-directory>
```

The command refuses to overwrite an existing artifact. It requires the actual
run directory to contain `config.yml`, `model_epoch030.pt`, and
`validation/model_epoch030/{validation_metrics.csv,validation_results.p}`.
For this single-target, single-frequency experiment, NeuralHydrology's
`metrics_to_dataframe` writes exactly the columns `basin,NSE`. The CSV must
contain exactly the 531 frozen basin identifiers and one finite value per
basin. Each repository-local JSON metric artifact contains:

- experiment identifier and path plus SHA-256 for the source configuration,
  run configuration snapshot, epoch-30 checkpoint, validation metric CSV, and
  validation result pickle;
- `epoch: 30`, `metric: NSE`, and the declared internal-validation period;
- a `basin_nse` object with exactly the 531 frozen basin identifiers and one
  finite Nash-Sutcliffe efficiency per basin;
- `median_nse`, which the audit independently recomputes.

The source configuration and run snapshot must match on every scientific and
training field. Only NeuralHydrology-derived `run_dir`, `train_dir`,
`img_log_dir`, `commit_hash`, and `package_version` fields may differ, and the
three derived directories must point to the bound run. Artifact generation and
every later audit load `validation_results.p`, recompute every basin's
Nash-Sutcliffe efficiency from `QObs(mm/d)_obs` and `QObs(mm/d)_sim` with
`neuralhydrology.evaluation.metrics.nse`, then cross-check the result pickle,
CSV, JSON values, and median. These are internal-validation products for
2006-10-01 through 2008-09-30; this workflow does not read formal evaluation
products.

The selection report then records all three artifacts and their actual
recomputed values:

```json
{
  "candidate_experiment_ids": ["D01", "D02", "D03"],
  "candidate_metrics": [
    {
      "experiment_id": "D01",
      "median_nse": 0.70,
      "metrics_artifact_path": "results/30_modern_transformer_moe/D01/epoch030_metrics.json",
      "metrics_artifact_sha256": "the exact artifact hash"
    },
    {
      "experiment_id": "D02",
      "median_nse": 0.72,
      "metrics_artifact_path": "results/30_modern_transformer_moe/D02/epoch030_metrics.json",
      "metrics_artifact_sha256": "the exact artifact hash"
    },
    {
      "experiment_id": "D03",
      "median_nse": 0.73,
      "metrics_artifact_path": "results/30_modern_transformer_moe/D03/epoch030_metrics.json",
      "metrics_artifact_sha256": "the exact artifact hash"
    }
  ],
  "selected_experiment_id": "D03",
  "selected_config_path": "src/modern_transformer_moe/configs/dense_d256_l8_s100.yml",
  "selected_config_sha256": "the exact 64-character source hash",
  "selection_metric": "median_NSE",
  "selection_epoch": 30,
  "selection_period": {"start": "2006-10-01", "end": "2008-09-30"},
  "selection_rule": "highest_median_validation_NSE_at_epoch_30_tie_break_D01_D02_D03"
}
```

Then run:

```powershell
python -m src.modern_transformer_moe.scripts.generate_selected_moe_config `
  --selection-report path/to/dense_selection_report.json
```

The generator verifies all three artifact hashes and full provenance chains,
recomputes all three medians from the bound prediction pickles, applies the
fixed tie-break, and checks each artifact against its completed registry row
before creating `moe_selected_s100.yml`. It records the selected source
configuration and report hashes in the `M01` row. An exclusive lock prevents
concurrent generation. If either file replacement or the final audit fails, it
restores the original registry and removes the new configuration so the command
can be rerun safely.

The generated sparse experiment copies all common fields from the selected
dense model. Its treatment is the mixture-of-experts feed-forward layers plus
their router load-balancing training scheme: one always-active shared expert,
eight routed experts, top-two routing, zero-based first expert layer 2, no token
dropping, and router regularization coefficient 0.01. Claims must attribute any
difference to that combined treatment, not to feed-forward architecture alone.
Active feed-forward width is matched exactly:

- Dense width 512: `128 + 2 * 192 = 512`.
- Dense width 1024: `256 + 2 * 384 = 1024`.

## Audited development runner and seeds

`run_development` is dry-run by default. It prints the exact command and
budget, but does not create a configuration, output directory, or child
process:

```powershell
python -m src.modern_transformer_moe.scripts.run_development B01 --seed 200
```

A real run requires both `--execute` and
`--operator-approved-heavy-compute`. Seeds 200 and 300 are allowed only for
the corrected long short-term memory network (`B01`), the validation-selected
dense Transformer (`SELECTED_DENSE`), and its sparse pair (`M01`). The latter
two remain unavailable until the existing seed-100 dense-selection gate has
generated `M01`.

Derived configurations can be prepared without training by adding
`--prepare-derived-config`. They are stored under
`configs/development_seeds/`, never overwrite an existing file, and have a
`.provenance.json` sidecar binding the base configuration, selection report
when applicable, seed, and SHA-256 hashes. The seed-100 configurations and
registry rows are not rewritten by this mechanism.

Every completed development run creates the same hash-bound
`epoch030_metrics.json`, including derived seeds. If training succeeds but
artifact generation or registration fails, `--finalize-run-dir <run-dir>`
reuses the source-bound run without launching training again. The development
comparison accepts repeated `--artifact ROLE:SEED=PATH` inputs and recomputes
all basin metrics from each bound `validation_results.p`.

Before any training subprocess starts, the runner atomically reserves the
unique `(role, seed)` entry in `registry/development_run_bindings.json`. Its
state advances from `RUNNING` to `POSTPROCESSING` to `COMPLETE`; a different
run identifier is rejected once that pair is reserved. The completed entry
binds the one run directory and the exact metrics-artifact path and SHA-256.
Finalization is idempotent for the same reservation, including the case where
the main experiment registry was updated before the invocation manifest. The
comparison accepts an artifact only when it is the sole `COMPLETE` binding for
its declared role and seed.

An execution exception instead changes the unique binding to `FAILED`. The
failed record binds the retained invocation manifest, failure stage and reason,
and an inventory of every expected epoch-30 product (missing, or present with
size and SHA-256). A controlled retry must name both the exact failed attempt
and a new, globally unused run identifier:

```powershell
python -m src.modern_transformer_moe.scripts.run_development D01 `
  --retry-failed-run-id failed-attempt-01 `
  --run-id retry-attempt-02 `
  --execute --operator-approved-heavy-compute
```

The retry transition is allowed only while the active binding is `FAILED`, the
old manifest and recorded products are unchanged, and the old attempt has no
complete epoch-30 product set or metrics artifact. The old attempt is copied
unchanged into `history` before the new attempt becomes `RUNNING`. If complete
products exist, the command refuses retraining and requires
`--finalize-run-dir`; no failed manifest or partial run directory is deleted.

After each completed `M01` run, generate the routed-expert usage evidence with:

```powershell
python -m src.modern_transformer_moe.scripts.build_router_diagnostics `
  --run-dir results/30_modern_transformer_moe/M01/<actual-run-directory>
```

The script has no period option: it always uses the declared 2006-10-01 through
2008-09-30 internal-validation split, loads `model_epoch030.pt`, accumulates the
integer token assignments of all eight routed experts separately for every
stably named expert layer, and writes `router_diagnostics_epoch030.json`. Here, the validation-token
count is the number of token vectors processed by one routed layer over all
validation batches, including all 270 positions in each input window. The
generator verifies
`per-layer assignments = validation tokens * top-k` and
`total assignments = validation tokens * top-k * routed-layer count`, requires
zero dropped tokens, and checks that the returned results cover exactly all 531
frozen basins and every day from 2006-10-01 through 2008-09-30. The strict
output binds repository-relative paths and SHA-256 hashes for the epoch-30
checkpoint, run configuration, training scaler, and frozen basin manifest.
`compare_development.py` rechecks that exact schema, every hash, the run-file
topology, the configuration-derived top-k/layer counts, and the assignment
equations. Its no-dead-expert gate requires every layer-expert cell to have a
positive count, so complementary expert subsets in different layers cannot
hide a layer-local dead expert. It then records each diagnostic file's own path and SHA-256 in the
development comparison report. The generator disables validation-data caching, saves no new
predictions, and refuses to overwrite an existing diagnostic. Pass each file
to the comparison as `--router-diagnostics SEED=PATH`.

## Static audit

Run these read-only checks from the repository root:

```powershell
python -m src.modern_transformer_moe.scripts.audit_configs
pytest test/test_modern_transformer_moe_configs.py -v
```

The audit checks the strict NeuralHydrology `Config` interface, exact basin
count, dates, inputs, training-only statistics boundary, immutable hashes,
unique output roots, optimizer recipes, the fixed epoch-30 selection rule, and
the pre-selection and post-selection registry states. It independently
recomputes all 531 basin metrics from each hash-bound prediction pickle and
cross-checks the CSV, JSON, and median. Parameter counts remain
`not_measured_pre_run` until the Task 5 model-instantiation audit measures them.
