import json
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

from src.modern_transformer_moe.scripts import inspect_development_runs as inspector
from src.modern_transformer_moe.scripts import run_development


def _record(status="RUNNING"):
    now = datetime(2026, 8, 27, tzinfo=timezone.utc).isoformat()
    return {
        "role": "D01",
        "seed": 100,
        "run_id": "runtime_test",
        "status": status,
        "invocation_manifest_path": (
            run_development.INVOCATIONS_RELATIVE_ROOT / "runtime_test" / "run_manifest.json"
        ).as_posix(),
        "created_at_utc": now,
        "updated_at_utc": now,
    }


def _write_manifest(repo_root: Path, record: dict, heartbeat: datetime, host="compute01", pid=123, start=50.0,
                    slurm_job_id=None):
    path = repo_root / record["invocation_manifest_path"]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({
        "schema_version": 1,
        "run_id": record["run_id"],
        "status": "RUNNING",
        "started_at_utc": heartbeat.isoformat(),
        "last_heartbeat_at_utc": heartbeat.isoformat(),
        "runner_process": {
            "host": host,
            "process_id": pid,
            "process_start_time_epoch_seconds": start,
            "slurm_job_id": slurm_job_id,
        },
        "child_process": {},
    }), encoding="utf-8")
    return path


def test_live_process_wins_even_when_heartbeat_is_stale(tmp_path):
    now = datetime(2026, 8, 27, 1, tzinfo=timezone.utc)
    record = _record()
    _write_manifest(tmp_path, record, now - timedelta(hours=1), host="local")
    result = inspector.classify_record(
        record,
        tmp_path,
        now=now,
        current_host="local",
        process_identity_reader=lambda *_args, **_kwargs: True,
        slurm_reader=lambda _job_id: None,
    )
    assert result["classification"] == "RUNNING_ALIVE"
    assert result["heartbeat_stale"] is True


def test_reused_or_dead_process_with_stale_heartbeat_is_orphaned(tmp_path):
    now = datetime(2026, 8, 27, 1, tzinfo=timezone.utc)
    record = _record()
    _write_manifest(tmp_path, record, now - timedelta(hours=1), host="local")
    result = inspector.classify_record(
        record,
        tmp_path,
        now=now,
        current_host="local",
        process_identity_reader=lambda *_args, **_kwargs: False,
        slurm_reader=lambda _job_id: None,
    )
    assert result["classification"] == "RUNNING_ORPHANED"
    assert result["reason"] == "joint_absence_proof"


def test_remote_slurm_job_proves_liveness(tmp_path):
    now = datetime(2026, 8, 27, 1, tzinfo=timezone.utc)
    record = _record()
    _write_manifest(tmp_path, record, now - timedelta(hours=1), slurm_job_id="12345")
    result = inspector.classify_record(
        record,
        tmp_path,
        now=now,
        current_host="login4",
        process_identity_reader=lambda *_args, **_kwargs: None,
        slurm_reader=lambda _job_id: True,
    )
    assert result["classification"] == "RUNNING_ALIVE"
    assert result["slurm_job_active"] is True


def test_missing_manifest_has_startup_grace_then_becomes_orphaned(tmp_path):
    now = datetime(2026, 8, 27, 1, tzinfo=timezone.utc)
    recent = _record()
    recent["updated_at_utc"] = (now - timedelta(seconds=10)).isoformat()
    old = _record()
    old["updated_at_utc"] = (now - timedelta(minutes=10)).isoformat()

    assert inspector.classify_record(recent, tmp_path, now=now)["classification"] == "RUNNING_ALIVE"
    assert inspector.classify_record(old, tmp_path, now=now)["classification"] == "RUNNING_ORPHANED"


def test_nonrunning_bindings_preserve_their_lifecycle_classification(tmp_path):
    for status in ("POSTPROCESSING", "COMPLETE", "FAILED"):
        assert inspector.classify_record(_record(status), tmp_path)["classification"] == status


def test_observed_process_tees_both_streams_and_records_identity(tmp_path):
    invocation_dir = tmp_path / "invocation"
    invocation_dir.mkdir()
    manifest_path = invocation_dir / "run_manifest.json"
    manifest = {"schema_version": 1, "status": "RUNNING"}
    run_development._atomic_json(manifest_path, manifest, create=True)
    command = [sys.executable, "-c", "import sys,time; print('stdout-line'); print('stderr-line', file=sys.stderr); time.sleep(.05)"]

    return_code = run_development._run_training_process(
        command,
        repo_root=tmp_path,
        environment=os.environ.copy(),
        manifest=manifest,
        manifest_path=manifest_path,
        invocation_dir=invocation_dir,
        heartbeat_interval_seconds=0.01,
    )

    persisted = json.loads(manifest_path.read_text(encoding="utf-8"))
    assert return_code == 0
    assert persisted["child_process"]["return_code"] == 0
    assert persisted["child_process"]["process_start_time_epoch_seconds"] > 0
    assert "stdout-line" in (invocation_dir / "training_stdout.log").read_text(encoding="utf-8")
    assert "stderr-line" in (invocation_dir / "training_stderr.log").read_text(encoding="utf-8")
    assert persisted["last_heartbeat_at_utc"]
