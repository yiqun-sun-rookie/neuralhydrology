import json
from pathlib import Path

import pytest

from src.modern_transformer_moe.scripts import audit_configs
from src.modern_transformer_moe.scripts import build_dense_selection_report as selection_builder
from test.test_modern_transformer_moe_configs import (
    _complete_dense_candidates,
    _copy_task4_repository,
    _write_registry,
)


def _prepared_repository(tmp_path: Path) -> Path:
    repository = _copy_task4_repository(tmp_path)
    report_path, _ = _complete_dense_candidates(repository)
    report_path.unlink()
    return repository


def test_builder_recomputes_all_three_candidates_and_selects_the_preregistered_winner(tmp_path: Path) -> None:
    repository = _prepared_repository(tmp_path)

    output_path = selection_builder.build(repo_root=repository)
    report = json.loads(output_path.read_text(encoding="utf-8"))

    assert report["candidate_experiment_ids"] == ["D01", "D02", "D03"]
    assert [record["experiment_id"] for record in report["candidate_metrics"]] == ["D01", "D02", "D03"]
    assert report["selected_experiment_id"] == "D02"
    assert audit_configs.audit_selection_report(report, repository) == []


def test_builder_is_idempotent_only_when_the_existing_report_is_byte_identical(tmp_path: Path) -> None:
    repository = _prepared_repository(tmp_path)
    output_path = selection_builder.build(repo_root=repository)
    original = output_path.read_bytes()

    assert selection_builder.build(repo_root=repository) == output_path
    assert output_path.read_bytes() == original

    output_path.write_text("{}\n", encoding="utf-8")
    with pytest.raises(FileExistsError, match="different selection report"):
        selection_builder.build(repo_root=repository)
    assert output_path.read_text(encoding="utf-8") == "{}\n"


def test_builder_rejects_an_incomplete_or_non_seed100_dense_candidate(tmp_path: Path) -> None:
    repository = _prepared_repository(tmp_path)
    registry_path = repository / "src/modern_transformer_moe/registry/experiments.csv"
    rows = audit_configs.load_registry(registry_path)
    d03 = next(row for row in rows if row["exp_id"] == "D03")
    d03["status"] = "planned"
    _write_registry(registry_path, rows)

    with pytest.raises(ValueError, match="D03 must have status development_complete"):
        selection_builder.build(repo_root=repository)

    d03["status"] = "development_complete"
    d03["seed"] = "200"
    _write_registry(registry_path, rows)
    with pytest.raises(ValueError, match="D03 must be seed 100"):
        selection_builder.build(repo_root=repository)


def test_builder_rejects_duplicate_candidate_rows_and_tampered_metrics(tmp_path: Path) -> None:
    repository = _prepared_repository(tmp_path)
    registry_path = repository / "src/modern_transformer_moe/registry/experiments.csv"
    rows = audit_configs.load_registry(registry_path)
    rows.append(dict(next(row for row in rows if row["exp_id"] == "D01")))
    _write_registry(registry_path, rows)

    with pytest.raises(ValueError, match="exactly one registry row for D01"):
        selection_builder.build(repo_root=repository)

    rows.pop()
    _write_registry(registry_path, rows)
    d01 = next(row for row in rows if row["exp_id"] == "D01")
    artifact_path = repository / d01["metrics_path"]
    artifact_path.write_bytes(artifact_path.read_bytes() + b"tampered")
    with pytest.raises(ValueError, match="metrics SHA-256 mismatch"):
        selection_builder.build(repo_root=repository)
