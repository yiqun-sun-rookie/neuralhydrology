"""Inspect or conservatively recover hash-bound modern Transformer development runs."""

from __future__ import annotations

import argparse
import json
import os
import socket
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from src.modern_transformer_moe.scripts import run_development


REPO_ROOT = Path(__file__).resolve().parents[3]
ACTIVE_SLURM_STATES = {"PENDING", "RUNNING", "COMPLETING", "CONFIGURING", "REQUEUED", "RESIZING"}
DEFAULT_HEARTBEAT_STALE_SECONDS = 120.0


def _parse_time(value: str | None) -> datetime | None:
    if not value:
        return None
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    return parsed if parsed.tzinfo is not None else parsed.replace(tzinfo=timezone.utc)


def process_identity_alive(host: str | None,
                           process_id: int | None,
                           process_start_time: float | None,
                           current_host: str | None = None,
                           start_time_reader: Callable[[int], float] = run_development._process_start_time) -> bool | None:
    """Return true/false on the same host and unknown on a different host."""
    current_host = current_host or socket.gethostname()
    if not host or host != current_host:
        return None
    if process_id is None or process_start_time is None:
        return False
    try:
        actual_start = start_time_reader(int(process_id))
    except (OSError, RuntimeError):
        return False
    return abs(actual_start - float(process_start_time)) <= 1.0


def slurm_job_active(job_id: str | None) -> bool | None:
    if not job_id:
        return None
    try:
        completed = subprocess.run(
            ["squeue", "-h", "-j", str(job_id).split(";", 1)[0], "-o", "%T"],
            check=False,
            capture_output=True,
            text=True,
        )
    except OSError:
        return None
    if completed.returncode != 0:
        return None
    states = {line.strip().upper() for line in completed.stdout.splitlines() if line.strip()}
    return bool(states & ACTIVE_SLURM_STATES)


def classify_record(record: dict[str, Any],
                    repo_root: Path,
                    now: datetime | None = None,
                    heartbeat_stale_seconds: float = DEFAULT_HEARTBEAT_STALE_SECONDS,
                    current_host: str | None = None,
                    process_identity_reader=process_identity_alive,
                    slurm_reader=slurm_job_active) -> dict[str, Any]:
    status = record["status"]
    if status in {"POSTPROCESSING", "COMPLETE", "FAILED"}:
        return {"run_id": record["run_id"], "binding_status": status, "classification": status}
    if status != "RUNNING":
        raise ValueError(f"Unsupported development binding status: {status}")

    now = now or datetime.now(timezone.utc)
    manifest_path = Path(repo_root) / record["invocation_manifest_path"]
    if not manifest_path.is_file():
        reservation_time = _parse_time(record.get("updated_at_utc") or record.get("created_at_utc"))
        age = (now - reservation_time).total_seconds() if reservation_time is not None else float("inf")
        classification = "RUNNING_ALIVE" if age <= heartbeat_stale_seconds else "RUNNING_ORPHANED"
        return {
            "run_id": record["run_id"],
            "binding_status": status,
            "classification": classification,
            "manifest_exists": False,
            "age_seconds": age,
            "reason": "startup_grace" if classification == "RUNNING_ALIVE" else "reservation_without_manifest",
        }

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    heartbeat = _parse_time(manifest.get("last_heartbeat_at_utc") or manifest.get("started_at_utc"))
    heartbeat_age = (now - heartbeat).total_seconds() if heartbeat is not None else float("inf")
    heartbeat_stale = heartbeat_age > heartbeat_stale_seconds
    runner = manifest.get("runner_process", {})
    child = manifest.get("child_process", {})
    host = runner.get("host")
    runner_alive = process_identity_reader(
        host,
        runner.get("process_id"),
        runner.get("process_start_time_epoch_seconds"),
        current_host=current_host,
    )
    child_alive = process_identity_reader(
        host,
        child.get("process_id"),
        child.get("process_start_time_epoch_seconds"),
        current_host=current_host,
    )
    scheduler_alive = slurm_reader(runner.get("slurm_job_id"))
    positive_liveness = runner_alive is True or child_alive is True or scheduler_alive is True
    definitive_absence = ((runner_alive is False and child_alive is not True)
                          or (scheduler_alive is False and runner_alive is not True and child_alive is not True))
    orphaned = heartbeat_stale and definitive_absence and not positive_liveness
    return {
        "run_id": record["run_id"],
        "binding_status": status,
        "classification": "RUNNING_ORPHANED" if orphaned else "RUNNING_ALIVE",
        "manifest_exists": True,
        "manifest_path": str(manifest_path),
        "heartbeat_age_seconds": heartbeat_age,
        "heartbeat_stale": heartbeat_stale,
        "runner_identity_alive": runner_alive,
        "child_identity_alive": child_alive,
        "slurm_job_active": scheduler_alive,
        "reason": "joint_absence_proof" if orphaned else "active_or_not_jointly_disproved",
    }


def inspect_all(repo_root: Path = REPO_ROOT,
                now: datetime | None = None,
                heartbeat_stale_seconds: float = DEFAULT_HEARTBEAT_STALE_SECONDS) -> dict[str, Any]:
    repo_root = Path(repo_root).resolve()
    bindings = run_development._load_run_bindings(repo_root)
    records = [
        classify_record(
            record,
            repo_root,
            now=now,
            heartbeat_stale_seconds=heartbeat_stale_seconds,
        ) for record in bindings["records"]
    ]
    return {
        "schema_version": 1,
        "generated_at_utc": (now or datetime.now(timezone.utc)).isoformat(),
        "host": socket.gethostname(),
        "records": records,
    }


def _atomic_report(path: Path, report: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        with temporary.open("x", encoding="utf-8") as file:
            json.dump(report, file, indent=2, sort_keys=True)
            file.write("\n")
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def recover_orphaned(run_id: str,
                     repo_root: Path = REPO_ROOT,
                     heartbeat_stale_seconds: float = DEFAULT_HEARTBEAT_STALE_SECONDS) -> dict[str, Any]:
    """Change one jointly disproved RUNNING binding to FAILED without deleting or replacing any files."""
    repo_root = Path(repo_root).resolve()
    bindings = run_development._load_run_bindings(repo_root)
    matches = [record for record in bindings["records"] if record["run_id"] == run_id]
    if len(matches) != 1:
        raise ValueError(f"Expected exactly one binding for run_id={run_id!r}, found {len(matches)}.")
    record = matches[0]
    evidence = classify_record(
        record,
        repo_root,
        heartbeat_stale_seconds=heartbeat_stale_seconds,
    )
    if evidence["classification"] != "RUNNING_ORPHANED":
        raise RuntimeError(f"Refusing orphan recovery without joint absence proof: {evidence}")

    manifest_path = repo_root / record["invocation_manifest_path"]
    if manifest_path.is_file():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    else:
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        manifest = {
            "schema_version": 1,
            "run_id": run_id,
            "experiment_id": record["role"],
            "seed": int(record["seed"]),
        }
    manifest.update({
        "status": "FAILED",
        "failure_stage": "external_interruption",
        "error_type": "ExternalInterruption",
        "error": "RUNNING binding was jointly proven orphaned; no files were removed and no retry was created.",
        "orphan_recovery_evidence": evidence,
        "failed_at_utc": datetime.now(timezone.utc).isoformat(),
    })
    run_development._atomic_json(manifest_path, manifest, create=not manifest_path.exists())
    run_dir_value = record.get("run_dir")
    run_dir = None if run_dir_value in {None, "not_bound"} else repo_root / run_dir_value
    updated = run_development._mark_run_binding_failed(
        record["role"],
        int(record["seed"]),
        run_id,
        repo_root,
        manifest_path=manifest_path,
        failure_stage="external_interruption",
        failure_reason=manifest["error"],
        run_dir=run_dir,
    )
    return {"status": "RECOVERED_TO_FAILED", "binding": updated, "evidence": evidence}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--all", action="store_true", help="Inspect every active and completed binding.")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--recover-orphaned", metavar="RUN_ID")
    parser.add_argument("--heartbeat-stale-seconds", type=float, default=DEFAULT_HEARTBEAT_STALE_SECONDS)
    args = parser.parse_args()
    if bool(args.all) == bool(args.recover_orphaned):
        raise ValueError("Choose exactly one of --all or --recover-orphaned RUN_ID.")
    if args.recover_orphaned:
        report = recover_orphaned(args.recover_orphaned,
                                  heartbeat_stale_seconds=args.heartbeat_stale_seconds)
    else:
        report = inspect_all(heartbeat_stale_seconds=args.heartbeat_stale_seconds)
    if args.output is not None:
        _atomic_report(args.output, report)
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
