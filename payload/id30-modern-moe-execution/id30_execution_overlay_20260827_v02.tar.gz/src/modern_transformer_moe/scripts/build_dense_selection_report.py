"""Build the deterministic dense-Transformer selection report from completed validation artifacts."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any

from src.modern_transformer_moe.scripts import audit_configs


CANDIDATE_IDS = ("D01", "D02", "D03")
OUTPUT_RELATIVE_PATH = Path("results/30_modern_transformer_moe/dense_selection_report.json")


def _resolve_inside_repository(path: Path, repo_root: Path) -> Path:
    path = Path(path)
    if not path.is_absolute():
        path = repo_root / path
    path = path.resolve()
    try:
        path.relative_to(repo_root)
    except ValueError as error:
        raise ValueError(f"selection report must remain inside the repository: {path}") from error
    return path


def _candidate_record(experiment_id: str, rows: list[dict[str, str]], repo_root: Path) -> dict[str, Any]:
    matches = [row for row in rows if row.get("exp_id") == experiment_id]
    if len(matches) != 1:
        raise ValueError(f"expected exactly one registry row for {experiment_id}, found {len(matches)}")
    row = matches[0]
    if row.get("status") != "development_complete":
        raise ValueError(f"{experiment_id} must have status development_complete before dense selection")
    if row.get("seed") != "100":
        raise ValueError(f"{experiment_id} must be seed 100 before dense selection")

    artifact_path = audit_configs.resolve_repository_file(row.get("metrics_path"), repo_root)
    if not artifact_path.is_file():
        raise FileNotFoundError(f"{experiment_id} metrics artifact does not exist: {artifact_path}")
    artifact_sha256 = audit_configs.sha256_file(artifact_path)
    if row.get("metrics_sha256") != artifact_sha256:
        raise ValueError(f"{experiment_id} metrics SHA-256 mismatch against the registry")

    artifact = audit_configs.load_json(artifact_path)
    issues, median_nse = audit_configs.audit_metrics_artifact(
        artifact,
        experiment_id,
        repo_root,
        artifact_path=artifact_path,
        expected_source_config_path=audit_configs.DENSE_CONFIG_BY_ID[experiment_id],
    )
    if issues:
        raise ValueError(f"{experiment_id} metrics artifact failed audit: " + "; ".join(issues))
    if median_nse is None:
        raise ValueError(f"{experiment_id} metrics artifact did not yield a recomputed median NSE")
    return {
        "experiment_id": experiment_id,
        "median_nse": median_nse,
        "metrics_artifact_path": artifact_path.relative_to(repo_root).as_posix(),
        "metrics_artifact_sha256": artifact_sha256,
    }


def _serialize(report: dict[str, Any]) -> bytes:
    return (json.dumps(report, indent=2, sort_keys=True) + "\n").encode("utf-8")


def _write_new_or_identical(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lock_path = path.with_name(f".{path.name}.lock")
    temporary_path = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        lock_descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as error:
        raise RuntimeError(f"selection report generation is already locked: {lock_path}") from error
    os.close(lock_descriptor)
    try:
        if path.exists():
            if path.read_bytes() == payload:
                return
            raise FileExistsError(f"refusing to overwrite a different selection report: {path}")
        temporary_path.write_bytes(payload)
        os.replace(temporary_path, path)
    finally:
        temporary_path.unlink(missing_ok=True)
        lock_path.unlink(missing_ok=True)


def build(
    repo_root: Path = audit_configs.REPO_ROOT,
    output_path: Path = OUTPUT_RELATIVE_PATH,
) -> Path:
    """Validate three completed seed-100 dense runs and write their immutable selection report."""
    repo_root = Path(repo_root).resolve()
    registry_path = repo_root / "src/modern_transformer_moe/registry/experiments.csv"
    rows = audit_configs.load_registry(registry_path)
    candidate_metrics = [_candidate_record(experiment_id, rows, repo_root) for experiment_id in CANDIDATE_IDS]
    medians = {record["experiment_id"]: record["median_nse"] for record in candidate_metrics}
    order = {experiment_id: index for index, experiment_id in enumerate(CANDIDATE_IDS)}
    selected_id = max(CANDIDATE_IDS, key=lambda experiment_id: (medians[experiment_id], -order[experiment_id]))
    selected_config_path = audit_configs.DENSE_CONFIG_BY_ID[selected_id]
    report = {
        "candidate_experiment_ids": list(CANDIDATE_IDS),
        "candidate_metrics": candidate_metrics,
        "selected_experiment_id": selected_id,
        "selected_config_path": selected_config_path,
        "selected_config_sha256": audit_configs.sha256_file(repo_root / selected_config_path),
        "selection_metric": "median_NSE",
        "selection_epoch": 30,
        "selection_period": audit_configs.SELECTION_PERIOD,
        "selection_rule": audit_configs.SELECTION_RULE,
    }
    issues = audit_configs.audit_selection_report(report, repo_root)
    if issues:
        raise ValueError("generated dense selection report failed its own audit: " + "; ".join(issues))
    output_path = _resolve_inside_repository(output_path, repo_root)
    _write_new_or_identical(output_path, _serialize(report))
    return output_path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=OUTPUT_RELATIVE_PATH)
    args = parser.parse_args()
    output_path = build(output_path=args.output)
    print(f"Dense selection report: {output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
