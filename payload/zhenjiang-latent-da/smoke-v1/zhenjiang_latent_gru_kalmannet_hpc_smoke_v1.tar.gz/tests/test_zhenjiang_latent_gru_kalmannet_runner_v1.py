"""Tests for bounded two-stage smoke orchestration and evidence verification."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import pytest
import torch
from torch.utils.data import Dataset


ROOT = Path(__file__).resolve().parents[1]
for relative in ("scripts/modeling", "scripts/analysis"):
    candidate = str(ROOT / relative)
    if candidate not in sys.path:
        sys.path.insert(0, candidate)

import zhenjiang_oyv_v1_contract as contract  # noqa: E402
from zhenjiang_latent_gru_kalmannet_data_v1 import LatentDARecord  # noqa: E402
from zhenjiang_latent_gru_kalmannet_experiment_v1 import (  # noqa: E402
    SMOKE_OUTPUT_RELATIVE_PATH,
)
import zhenjiang_latent_gru_kalmannet_runner_v1 as runner  # noqa: E402
from zhenjiang_latent_gru_kalmannet_runner_v1 import (  # noqa: E402
    build_smoke_record_splits,
    collate_latent_da_batch,
    cyclic_one_station_availability,
    train_stage,
    verify_completed_output,
)
from zhenjiang_latent_gru_kalmannet_training_v1 import (  # noqa: E402
    PRETRAIN_BACKBONE,
    TRAIN_GAIN,
    SyntheticLearnedGain,
)
from zhenjiang_latent_gru_kalmannet_v1 import (  # noqa: E402
    AvailabilityGatedLatentGRUKalmanNet,
)


BEIJING = timezone(timedelta(hours=8))
CONFIG_PATH = (
    ROOT
    / "docs"
    / "records"
    / "ZHENJIANG_LATENT_GRU_KALMANNET_HPC_SMOKE_V1_CONFIG.json"
)
RUNNER_PATH = (
    ROOT / "scripts" / "modeling" / "zhenjiang_latent_gru_kalmannet_runner_v1.py"
)


class TinyDataset(Dataset):
    def __init__(self, count: int, one_station: bool):
        self.count = count
        self.one_station = one_station

    def __len__(self):
        return self.count

    def __getitem__(self, index):
        generator = torch.Generator(device="cpu")
        generator.manual_seed(5000 + index)
        availability = torch.ones(24, 6, dtype=torch.bool)
        if self.one_station:
            availability[:] = False
            availability[:, index % 6] = True
        observations = torch.randn(24, 6, generator=generator)
        observations = torch.where(
            availability, observations, torch.full_like(observations, float("nan"))
        )
        return {
            "warmup_levels": torch.randn(24, 6, generator=generator),
            "warmup_controls": torch.randn(24, 2, generator=generator),
            "analysis_observations": observations,
            "analysis_targets": torch.randn(24, 6, generator=generator),
            "analysis_availability": availability,
            "analysis_controls": torch.randn(24, 2, generator=generator),
            "future_controls": torch.randn(24, 2, generator=generator),
            "future_targets": torch.randn(24, 6, generator=generator),
            "issue_time_beijing": datetime(2022, 1, 1, tzinfo=BEIJING)
            + timedelta(hours=index),
            "issue_position": index,
        }


def _config():
    return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))


def test_collate_keeps_datetimes_out_of_tensor_collation():
    source = TinyDataset(2, one_station=True)
    batch = collate_latent_da_batch([source[0], source[1]])

    assert batch["warmup_levels"].shape == (2, 24, 6)
    assert batch["analysis_availability"].dtype == torch.bool
    assert batch["issue_positions"] == (0, 1)
    assert batch["issue_times_beijing"] == (
        source[0]["issue_time_beijing"],
        source[1]["issue_time_beijing"],
    )


def test_cyclic_one_station_mask_depends_only_on_issue_position():
    record = LatentDARecord(13, datetime(2022, 1, 1, tzinfo=BEIJING))
    mask = cyclic_one_station_availability(record)

    assert mask.shape == (24, 6)
    assert mask[:, 1].all()
    assert mask.sum() == 24


def test_smoke_split_builder_never_requests_the_held_out_year(monkeypatch):
    calls = []

    def fake_records(data, allowed_years):
        calls.append(tuple(allowed_years))
        return (
            LatentDARecord(
                len(calls), datetime(2022, 1, 1, tzinfo=BEIJING)
            ),
        )

    monkeypatch.setattr(runner, "accepted_latent_da_records", fake_records)
    training, validation = build_smoke_record_splits(object(), 2024)

    assert training and validation
    assert calls == [contract.training_years(2024), (2023,)]
    assert (2024,) not in calls


@pytest.mark.parametrize(
    "stage,one_station",
    [(PRETRAIN_BACKBONE, False), (TRAIN_GAIN, True)],
)
def test_train_stage_obeys_one_epoch_two_batch_ceiling_and_isolates_parameters(
    stage, one_station, tmp_path
):
    torch.manual_seed(20260827)
    model = AvailabilityGatedLatentGRUKalmanNet(SyntheticLearnedGain())
    before_backbone = {
        name: value.detach().clone() for name, value in model.backbone.state_dict().items()
    }
    before_gain = {
        name: value.detach().clone() for name, value in model.gain_module.state_dict().items()
    }

    result = train_stage(
        model,
        stage,
        TinyDataset(40, one_station=one_station),
        TinyDataset(40, one_station=one_station),
        torch.ones(6),
        _config(),
        torch.device("cpu"),
        tmp_path / stage,
    )

    assert result.completed_epochs == 1
    assert result.total_training_batches == 2
    assert result.total_validation_batches == 2
    assert result.best_epoch == 1
    assert result.best_validation_loss_m >= 0.0
    assert len(result.history) == 1
    after_backbone = model.backbone.state_dict()
    after_gain = model.gain_module.state_dict()
    if stage == PRETRAIN_BACKBONE:
        assert any(
            not torch.equal(before_backbone[name], after_backbone[name])
            for name in before_backbone
        )
        assert all(
            torch.equal(before_gain[name], after_gain[name]) for name in before_gain
        )
    else:
        assert all(
            torch.equal(before_backbone[name], after_backbone[name])
            for name in before_backbone
        )
        assert any(
            not torch.equal(before_gain[name], after_gain[name]) for name in before_gain
        )


def test_cli_refuses_real_data_access_before_checking_paths_without_authorization():
    completed = subprocess.run(
        [
            sys.executable,
            str(RUNNER_PATH),
            "--input-dir",
            str(ROOT / "missing_data"),
            "--kalmannet-source",
            str(ROOT / "missing_source.py"),
        ],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    )

    assert completed.returncode != 0
    assert "--allow-paid-smoke" in completed.stderr
    assert "does not exist" not in completed.stderr


def test_registered_output_suffix_is_required(tmp_path):
    accepted = tmp_path / Path(SMOKE_OUTPUT_RELATIVE_PATH)
    runner._verify_output_suffix(accepted)
    with pytest.raises(ValueError, match="registered run directory"):
        runner._verify_output_suffix(tmp_path / "wrong")


def test_completed_output_verifier_detects_tampering(tmp_path):
    output = tmp_path / "run"
    output.mkdir()
    artifact = output / "run_identity.json"
    artifact.write_text("{}\n", encoding="utf-8")
    content = artifact.read_bytes()
    manifest = {
        "schema_version": 1,
        "experiment_id": "ZLDA-SMOKE-01",
        "status": "technical_smoke_completed",
        "scientific_result": False,
        "held_out_target_score_count": 0,
        "artifacts": [
            {
                "relative_path": artifact.name,
                "byte_count": len(content),
                "sha256": hashlib.sha256(content).hexdigest(),
            }
        ],
    }
    (output / "completion_manifest.json").write_text(
        json.dumps(manifest), encoding="utf-8"
    )

    verified = verify_completed_output(output)
    assert verified["verification_status"] == "passed"
    artifact.write_text("changed\n", encoding="utf-8")
    with pytest.raises(ValueError, match="byte count|SHA-256"):
        verify_completed_output(output)
