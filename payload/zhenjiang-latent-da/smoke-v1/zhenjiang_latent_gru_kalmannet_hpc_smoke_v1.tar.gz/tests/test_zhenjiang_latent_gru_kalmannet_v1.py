"""Technical tests for the shared abstract latent-state prototype.

These tests use synthetic tensors only.  They do not load project data, train
on a held-out year, or establish forecast skill.
"""

from __future__ import annotations

import inspect
from pathlib import Path
import sys

import pytest
import torch


ROOT = Path(__file__).resolve().parents[1]
MODELING_DIR = ROOT / "scripts" / "modeling"
if str(MODELING_DIR) not in sys.path:
    sys.path.insert(0, str(MODELING_DIR))

from water_level_joint_encoder_decoder_v2 import (  # noqa: E402
    STATION_ORDER as CURRENT_STATION_ORDER,
)
from zhenjiang_latent_gru_kalmannet_v1 import (  # noqa: E402
    ANALYSIS_LENGTH_HOURS,
    CONTROL_DIMENSION,
    CONTROL_NAMES,
    FORECAST_LENGTH_HOURS,
    LATENT_STATE_DIMENSION,
    STATION_ORDER,
    WARMUP_LENGTH_HOURS,
    AvailabilityGatedLatentGRUKalmanNet,
    LatentGRUBackbone,
    architecture_description,
)
from zhenjiang_kalmannet_gain_adapter_v1 import (  # noqa: E402
    PinnedKalmanNetGainAdapter,
)


LOCAL_KALMANNET_SOURCE = Path(
    "G:/github/pycharm/projects/kalmannet/third_party/"
    "KalmanNet_TSP_828a2cf/KNet/KalmanNet_nn.py"
)


def _backbone_inputs(batch_size: int = 2):
    torch.manual_seed(20260827)
    warmup_levels = torch.randn(batch_size, 24, 6)
    warmup_controls = torch.randn(batch_size, 24, 2)
    future_controls = torch.randn(batch_size, 24, 2)
    return warmup_levels, warmup_controls, future_controls


def test_frozen_dimensions_and_station_order_match_active_model():
    assert STATION_ORDER == CURRENT_STATION_ORDER
    assert LATENT_STATE_DIMENSION == 16
    assert CONTROL_DIMENSION == 2
    assert len(CONTROL_NAMES) == 2
    assert WARMUP_LENGTH_HOURS == 24
    assert ANALYSIS_LENGTH_HOURS == 24
    assert FORECAST_LENGTH_HOURS == 24


def test_backbone_has_frozen_structural_components_and_parameter_counts():
    model = LatentGRUBackbone()

    assert isinstance(model.history_encoder, torch.nn.GRU)
    assert model.history_encoder.input_size == 8
    assert model.history_encoder.hidden_size == 16
    assert model.history_encoder.batch_first is True
    assert isinstance(model.process_cell, torch.nn.GRUCell)
    assert model.process_cell.input_size == 2
    assert model.process_cell.hidden_size == 16
    assert isinstance(model.decoder, torch.nn.Linear)
    assert (model.decoder.in_features, model.decoder.out_features) == (16, 6)

    process_parameters = sum(p.numel() for p in model.process_cell.parameters())
    decoder_parameters = sum(p.numel() for p in model.decoder.parameters())
    assert process_parameters == 960
    assert decoder_parameters == 102
    assert process_parameters + decoder_parameters == 1062
    assert not any(buffer.shape == (6, 6) for buffer in model.buffers())


def test_backbone_shapes_and_abstract_learned_observation_contract():
    model = LatentGRUBackbone()
    warmup_levels, warmup_controls, future_controls = _backbone_inputs()

    state = model.encode_warmup(warmup_levels, warmup_controls)
    next_state = model.transition_step(state, future_controls[:, 0])
    decoded = model.decode(next_state)
    forecasts = model.open_loop(state, future_controls)

    assert state.shape == (2, 16)
    assert next_state.shape == (2, 16)
    assert decoded.shape == (2, 6)
    assert forecasts.shape == (2, 24, 6)
    description = architecture_description()
    assert description["state_coordinates"] == "sixteen wholly abstract coordinates"
    assert description["observation_operator"] == "learned linear decoder"
    assert description["state_contains_station_level_coordinates"] is False
    assert description["future_observation_input"] is False


@pytest.mark.parametrize(
    "input_name,replacement,message",
    [
        ("warmup_levels", torch.zeros(2, 23, 6), "warm-up levels"),
        ("warmup_levels", torch.zeros(2, 24, 5), "warm-up levels"),
        ("warmup_controls", torch.zeros(2, 23, 2), "warm-up controls"),
        ("warmup_controls", torch.zeros(2, 24, 3), "warm-up controls"),
    ],
)
def test_encode_warmup_rejects_wrong_shapes(input_name, replacement, message):
    model = LatentGRUBackbone()
    warmup_levels, warmup_controls, _ = _backbone_inputs()
    inputs = {
        "warmup_levels": warmup_levels,
        "warmup_controls": warmup_controls,
    }
    inputs[input_name] = replacement

    with pytest.raises(ValueError, match=message):
        model.encode_warmup(inputs["warmup_levels"], inputs["warmup_controls"])


def test_transition_decode_and_open_loop_reject_wrong_shapes():
    model = LatentGRUBackbone()
    with pytest.raises(ValueError, match="state"):
        model.transition_step(torch.zeros(2, 15), torch.zeros(2, 2))
    with pytest.raises(ValueError, match="controls"):
        model.transition_step(torch.zeros(2, 16), torch.zeros(2, 3))
    with pytest.raises(ValueError, match="state"):
        model.decode(torch.zeros(2, 15))
    with pytest.raises(ValueError, match="future controls"):
        model.open_loop(torch.zeros(2, 16), torch.zeros(2, 25, 2))


@pytest.mark.parametrize("bad_value", [float("nan"), float("inf"), -float("inf")])
def test_backbone_rejects_nonfinite_values(bad_value):
    model = LatentGRUBackbone()
    warmup_levels, warmup_controls, future_controls = _backbone_inputs()
    warmup_levels[0, 0, 0] = bad_value
    with pytest.raises(ValueError, match="nonfinite"):
        model.encode_warmup(warmup_levels, warmup_controls)

    state = torch.zeros(2, 16)
    future_controls[0, 0, 0] = bad_value
    with pytest.raises(ValueError, match="nonfinite"):
        model.open_loop(state, future_controls)


def test_backbone_rejects_nonfloating_dtype_and_device_mismatch_without_gpu():
    model = LatentGRUBackbone()
    with pytest.raises(ValueError, match="floating-point"):
        model.encode_warmup(torch.zeros(2, 24, 6, dtype=torch.long), torch.zeros(2, 24, 2))

    meta_controls = torch.empty(2, 24, 2, device="meta")
    with pytest.raises(ValueError, match="device"):
        model.open_loop(torch.zeros(2, 16), meta_controls)


def test_backbone_rejects_dtype_mismatch():
    model = LatentGRUBackbone()
    warmup_levels, warmup_controls, _ = _backbone_inputs()
    with pytest.raises(ValueError, match="dtype"):
        model.encode_warmup(warmup_levels.double(), warmup_controls.double())


def test_future_decoded_loss_reaches_backbone_inputs_and_all_components():
    model = LatentGRUBackbone()
    warmup_levels, warmup_controls, future_controls = _backbone_inputs()
    warmup_levels.requires_grad_()
    warmup_controls.requires_grad_()
    future_controls.requires_grad_()

    state = model.encode_warmup(warmup_levels, warmup_controls)
    forecasts = model.open_loop(state, future_controls)
    forecasts.square().mean().backward()

    checked = {
        "history encoder": model.history_encoder.weight_ih_l0,
        "process cell": model.process_cell.weight_ih,
        "decoder": model.decoder.weight,
        "warm-up levels": warmup_levels,
        "warm-up controls": warmup_controls,
        "future controls": future_controls,
    }
    for name, tensor in checked.items():
        assert tensor.grad is not None, name
        assert torch.isfinite(tensor.grad).all(), name
        assert torch.count_nonzero(tensor.grad).item() > 0, name


class RecordingGain(torch.nn.Module):
    """Deterministic test double that records the four gain inputs."""

    def __init__(self, value: float = 0.025):
        super().__init__()
        self.value = torch.nn.Parameter(torch.tensor(float(value)))
        self.reset_calls = []
        self.records = []

    def reset(self, batch_size, *, device, dtype):
        self.reset_calls.append((int(batch_size), torch.device(device), dtype))
        self.records = []

    def gain_step(
        self,
        observation_difference,
        observation_innovation,
        state_evolution,
        previous_state_update,
        availability,
    ):
        self.records.append(
            tuple(
                value.detach().clone()
                for value in (
                    observation_difference,
                    observation_innovation,
                    state_evolution,
                    previous_state_update,
                    availability,
                )
            )
        )
        batch_size = observation_difference.shape[0]
        return self.value * torch.ones(
            batch_size,
            16,
            6,
            dtype=observation_difference.dtype,
            device=observation_difference.device,
        )


class StatefulResetGain(RecordingGain):
    """Output changes by step unless reset starts each forward from zero."""

    def reset(self, batch_size, *, device, dtype):
        super().reset(batch_size, device=device, dtype=dtype)
        self.step_index = 0

    def gain_step(self, *args):
        gain = super().gain_step(*args)
        self.step_index += 1
        return gain * float(self.step_index)


class ForbiddenGain(torch.nn.Module):
    def reset(self, *args, **kwargs):
        raise AssertionError("pure backbone path must not reset the gain module")

    def gain_step(self, *args, **kwargs):
        raise AssertionError("pure backbone path must not call the gain module")


def _assimilation_inputs(batch_size: int = 2):
    torch.manual_seed(314159)
    return {
        "warmup_levels": torch.randn(batch_size, 24, 6),
        "warmup_controls": torch.randn(batch_size, 24, 2),
        "analysis_observations": torch.randn(batch_size, 24, 6),
        "analysis_availability": torch.ones(
            batch_size, 24, 6, dtype=torch.bool
        ),
        "analysis_controls": torch.randn(batch_size, 24, 2),
        "future_controls": torch.randn(batch_size, 24, 2),
    }


def _call_model(model, inputs):
    return model(
        inputs["warmup_levels"],
        inputs["warmup_controls"],
        inputs["analysis_observations"],
        inputs["analysis_availability"],
        inputs["analysis_controls"],
        inputs["future_controls"],
    )


def test_forward_has_no_future_observation_argument_and_rejects_wrong_shape():
    parameters = inspect.signature(
        AvailabilityGatedLatentGRUKalmanNet.forward
    ).parameters
    assert "future_observations" not in parameters
    assert tuple(parameters) == (
        "self",
        "warmup_levels",
        "warmup_controls",
        "analysis_observations",
        "analysis_availability",
        "analysis_controls",
        "future_controls",
    )

    model = AvailabilityGatedLatentGRUKalmanNet(RecordingGain())
    inputs = _assimilation_inputs()
    inputs["analysis_controls"] = torch.zeros(2, 23, 2)
    with pytest.raises(ValueError, match="analysis controls"):
        _call_model(model, inputs)


def test_all_missing_analysis_is_exact_identity_and_matches_pure_backbone():
    model = AvailabilityGatedLatentGRUKalmanNet(RecordingGain(value=0.5))
    inputs = _assimilation_inputs()
    inputs["analysis_availability"].zero_()
    inputs["analysis_observations"].fill_(float("nan"))

    assimilated = _call_model(model, inputs)
    pure = model.backbone_only_forward(
        inputs["warmup_levels"],
        inputs["warmup_controls"],
        inputs["analysis_controls"],
        inputs["future_controls"],
    )

    assert torch.equal(
        assimilated["analysis_posterior_states"],
        assimilated["analysis_prior_states"],
    )
    assert torch.equal(assimilated["forecasts"], pure["forecasts"])


def test_first_analysis_step_uses_frozen_zero_state_differences_and_warmup_decode():
    gain = RecordingGain()
    model = AvailabilityGatedLatentGRUKalmanNet(gain)
    inputs = _assimilation_inputs(batch_size=1)
    _call_model(model, inputs)

    initial_state = model.backbone.encode_warmup(
        inputs["warmup_levels"], inputs["warmup_controls"]
    )
    initial_observation = model.backbone.decode(initial_state)
    first = gain.records[0]
    expected_prior = model.backbone.transition_step(
        initial_state, inputs["analysis_controls"][:, 0]
    )

    torch.testing.assert_close(first[0], inputs["analysis_observations"][:, 0] - initial_observation)
    torch.testing.assert_close(first[1], inputs["analysis_observations"][:, 0] - model.backbone.decode(expected_prior))
    assert torch.equal(first[2], torch.zeros_like(first[2]))
    assert torch.equal(first[3], torch.zeros_like(first[3]))


@pytest.mark.parametrize("missing_value", [float("nan"), float("inf"), 1.0e8])
def test_unavailable_observation_storage_cannot_change_states_gains_or_forecasts(
    missing_value,
):
    model = AvailabilityGatedLatentGRUKalmanNet(RecordingGain())
    inputs = _assimilation_inputs()
    inputs["analysis_availability"][:, 5:17, 2] = False
    baseline_inputs = {key: value.clone() for key, value in inputs.items()}
    baseline_inputs["analysis_observations"][
        ~baseline_inputs["analysis_availability"]
    ] = -123.0
    changed_inputs = {key: value.clone() for key, value in inputs.items()}
    changed_inputs["analysis_observations"][
        ~changed_inputs["analysis_availability"]
    ] = missing_value

    baseline = _call_model(model, baseline_inputs)
    changed = _call_model(model, changed_inputs)

    for key in (
        "analysis_posterior_states",
        "analysis_gains",
        "forecasts",
    ):
        torch.testing.assert_close(baseline[key], changed[key], rtol=0.0, atol=0.0)


def test_all_missing_sample_in_mixed_batch_receives_no_correction():
    model = AvailabilityGatedLatentGRUKalmanNet(RecordingGain(value=0.5))
    inputs = _assimilation_inputs()
    inputs["analysis_availability"][0].zero_()
    inputs["analysis_observations"][0].fill_(float("nan"))

    output = _call_model(model, inputs)

    assert torch.equal(
        output["analysis_posterior_states"][0],
        output["analysis_prior_states"][0],
    )
    assert torch.count_nonzero(
        output["analysis_posterior_states"][1]
        - output["analysis_prior_states"][1]
    ).item() > 0


def test_every_forward_resets_gain_memory_and_is_batch_independent():
    gain = StatefulResetGain()
    model = AvailabilityGatedLatentGRUKalmanNet(gain)
    inputs = _assimilation_inputs(batch_size=1)

    first = _call_model(model, inputs)["forecasts"].detach().clone()
    unrelated = _assimilation_inputs(batch_size=3)
    _call_model(model, unrelated)
    repeated = _call_model(model, inputs)["forecasts"]

    torch.testing.assert_close(first, repeated, rtol=0.0, atol=0.0)
    assert [call[0] for call in gain.reset_calls] == [1, 3, 1]


def test_one_station_innovation_can_change_other_decoded_stations_only_via_state():
    gain = RecordingGain(value=0.2)
    model = AvailabilityGatedLatentGRUKalmanNet(gain)
    with torch.no_grad():
        model.backbone.decoder.weight.fill_(0.1)
        model.backbone.decoder.bias.zero_()
    inputs = _assimilation_inputs(batch_size=1)
    inputs["analysis_availability"].zero_()
    inputs["analysis_availability"][:, -1, 0] = True
    inputs["analysis_observations"].fill_(float("nan"))

    pure = model.backbone_only_forward(
        inputs["warmup_levels"],
        inputs["warmup_controls"],
        inputs["analysis_controls"],
        inputs["future_controls"],
    )
    prior_observation = pure["analysis_prior_observations"][:, -1]
    inputs["analysis_observations"][:, -1, 0] = prior_observation[:, 0] + 2.0
    first = _call_model(model, inputs)
    alternative = {key: value.clone() for key, value in inputs.items()}
    alternative["analysis_observations"][:, -1, 4] = 1.0e8
    second = _call_model(model, alternative)

    decoded_prior = model.backbone.decode(first["analysis_prior_states"][:, -1])
    decoded_posterior = model.backbone.decode(first["issue_posterior_state"])
    assert torch.count_nonzero(decoded_posterior[:, 1:] - decoded_prior[:, 1:]).item() > 0
    torch.testing.assert_close(
        first["issue_posterior_state"], second["issue_posterior_state"], rtol=0.0, atol=0.0
    )


def test_composed_output_contract_and_no_probability_outputs():
    model = AvailabilityGatedLatentGRUKalmanNet(RecordingGain())
    output = _call_model(model, _assimilation_inputs(batch_size=3))

    assert output["analysis_prior_states"].shape == (3, 24, 16)
    assert output["analysis_posterior_states"].shape == (3, 24, 16)
    assert output["analysis_prior_observations"].shape == (3, 24, 6)
    assert output["analysis_gains"].shape == (3, 24, 16, 6)
    assert output["issue_posterior_state"].shape == (3, 16)
    assert output["forecasts"].shape == (3, 24, 6)
    assert not any("covariance" in key or "standard_deviation" in key for key in output)


def test_backbone_only_forward_never_touches_gain_module():
    model = AvailabilityGatedLatentGRUKalmanNet(ForbiddenGain())
    inputs = _assimilation_inputs()
    output = model.backbone_only_forward(
        inputs["warmup_levels"],
        inputs["warmup_controls"],
        inputs["analysis_controls"],
        inputs["future_controls"],
    )
    assert torch.equal(output["analysis_prior_states"], output["analysis_posterior_states"])


@pytest.mark.skipif(
    not LOCAL_KALMANNET_SOURCE.is_file(), reason="explicit pinned source is absent"
)
def test_real_pinned_core_completes_synthetic_forward_and_backward_on_cpu():
    gain = PinnedKalmanNetGainAdapter(LOCAL_KALMANNET_SOURCE)
    model = AvailabilityGatedLatentGRUKalmanNet(gain)
    inputs = _assimilation_inputs(batch_size=1)
    output = _call_model(model, inputs)
    loss = output["forecasts"].square().mean()
    loss.backward()

    assert torch.isfinite(output["forecasts"]).all()
    gradients = [parameter.grad for parameter in gain.parameters() if parameter.grad is not None]
    assert gradients
    assert all(torch.isfinite(gradient).all() for gradient in gradients)
