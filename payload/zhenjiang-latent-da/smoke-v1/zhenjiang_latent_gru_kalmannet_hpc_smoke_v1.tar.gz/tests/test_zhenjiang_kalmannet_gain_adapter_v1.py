"""Unit and pinned-source checks for the learned-gain adapter.

The real-core checks execute one synthetic central-processing-unit gain step.
They do not train a model or copy the external source into this repository.
"""

from __future__ import annotations

from pathlib import Path
import subprocess
import sys

import pytest
import torch
from torch.nn import functional as functional


ROOT = Path(__file__).resolve().parents[1]
MODELING_DIR = ROOT / "scripts" / "modeling"
if str(MODELING_DIR) not in sys.path:
    sys.path.insert(0, str(MODELING_DIR))

from zhenjiang_kalmannet_gain_adapter_v1 import (  # noqa: E402
    EXPECTED_KALMANNET_SHA256,
    PinnedKalmanNetGainAdapter,
)


LOCAL_SOURCE = Path(
    "G:/github/pycharm/projects/kalmannet/third_party/"
    "KalmanNet_TSP_828a2cf/KNet/KalmanNet_nn.py"
)
REAL_CORE_AVAILABLE = LOCAL_SOURCE.is_file()


def _features(batch_size: int):
    torch.manual_seed(1729)
    return (
        torch.randn(batch_size, 6),
        torch.randn(batch_size, 6),
        torch.randn(batch_size, 16),
        torch.randn(batch_size, 16),
    )


def test_importing_adapter_does_not_execute_external_kalmannet_source():
    code = (
        "import sys; "
        "sys.path.insert(0, r'%s'); "
        "import zhenjiang_kalmannet_gain_adapter_v1; "
        "print(any(name.startswith('_zhenjiang_pinned_kalmannet_') "
        "for name in sys.modules))"
    ) % str(MODELING_DIR)
    completed = subprocess.run(
        [sys.executable, "-c", code],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    )
    assert completed.stdout.strip() == "False"


def test_adapter_rejects_missing_path_and_changed_digest(tmp_path):
    with pytest.raises(FileNotFoundError, match="KalmanNet source"):
        PinnedKalmanNetGainAdapter(tmp_path / "missing.py")

    changed = tmp_path / "changed.py"
    changed.write_text("class KalmanNetNN: pass\n", encoding="utf-8")
    with pytest.raises(ValueError, match="SHA-256"):
        PinnedKalmanNetGainAdapter(changed)


@pytest.mark.skipif(not REAL_CORE_AVAILABLE, reason="explicit pinned source is absent")
def test_verified_source_exports_kalmannet_class_and_identity():
    adapter = PinnedKalmanNetGainAdapter(LOCAL_SOURCE)
    identity = adapter.source_identity()

    assert adapter.core.__class__.__name__ == "KalmanNetNN"
    assert Path(identity["absolute_path"]) == LOCAL_SOURCE.resolve()
    assert identity["byte_count"] == LOCAL_SOURCE.stat().st_size
    assert identity["sha256"] == EXPECTED_KALMANNET_SHA256


@pytest.mark.skipif(not REAL_CORE_AVAILABLE, reason="explicit pinned source is absent")
def test_reset_supports_new_batch_and_initializes_three_recurrent_memories():
    adapter = PinnedKalmanNetGainAdapter(LOCAL_SOURCE)

    adapter.reset(2, device=torch.device("cpu"), dtype=torch.float32)
    assert adapter.core.batch_size == 2
    assert adapter.core.h_Q.shape == (1, 2, 16**2)
    assert adapter.core.h_Sigma.shape == (1, 2, 16**2)
    assert adapter.core.h_S.shape == (1, 2, 6**2)

    adapter.reset(5, device=torch.device("cpu"), dtype=torch.float32)
    assert adapter.core.batch_size == 5
    assert adapter.core.h_Q.shape[1] == 5
    assert adapter.core.h_Sigma.shape[1] == 5
    assert adapter.core.h_S.shape[1] == 5


@pytest.mark.skipif(not REAL_CORE_AVAILABLE, reason="explicit pinned source is absent")
def test_gain_step_has_frozen_shape_and_float32_dtype():
    adapter = PinnedKalmanNetGainAdapter(LOCAL_SOURCE)
    adapter.reset(3, device=torch.device("cpu"), dtype=torch.float32)

    gain = adapter.gain_step(*_features(3), torch.ones(3, 6, dtype=torch.bool))

    assert gain.shape == (3, 16, 6)
    assert gain.dtype == torch.float32
    assert torch.isfinite(gain).all()


@pytest.mark.skipif(not REAL_CORE_AVAILABLE, reason="explicit pinned source is absent")
def test_all_64_availability_patterns_mask_columns_and_ignore_missing_storage():
    adapter = PinnedKalmanNetGainAdapter(LOCAL_SOURCE)
    pattern_count = 2**6
    availability = torch.tensor(
        [
            [(pattern >> station_index) & 1 for station_index in range(6)]
            for pattern in range(pattern_count)
        ],
        dtype=torch.bool,
    )
    observation_difference, innovation, evolution, update = _features(pattern_count)
    first_observation_difference = observation_difference.clone()
    first_innovation = innovation.clone()
    first_observation_difference[~availability] = torch.nan
    first_innovation[~availability] = torch.inf
    second_observation_difference = observation_difference.clone()
    second_innovation = innovation.clone()
    second_observation_difference[~availability] = -1.0e8
    second_innovation[~availability] = 1.0e8

    adapter.reset(pattern_count, device=torch.device("cpu"), dtype=torch.float32)
    first = adapter.gain_step(
        first_observation_difference,
        first_innovation,
        evolution,
        update,
        availability,
    )
    adapter.reset(pattern_count, device=torch.device("cpu"), dtype=torch.float32)
    second = adapter.gain_step(
        second_observation_difference,
        second_innovation,
        evolution,
        update,
        availability,
    )

    torch.testing.assert_close(first, second, rtol=0.0, atol=0.0)
    assert torch.equal(first.masked_select(~availability[:, None, :]), torch.zeros_like(first.masked_select(~availability[:, None, :])))
    assert torch.isfinite(first).all()


@pytest.mark.skipif(not REAL_CORE_AVAILABLE, reason="explicit pinned source is absent")
def test_invalid_nonbinary_availability_is_rejected():
    adapter = PinnedKalmanNetGainAdapter(LOCAL_SOURCE)
    adapter.reset(1, device=torch.device("cpu"), dtype=torch.float32)
    availability = torch.ones(1, 6)
    availability[0, 2] = 0.5

    with pytest.raises(ValueError, match="zero or one"):
        adapter.gain_step(*_features(1), availability)


@pytest.mark.skipif(not REAL_CORE_AVAILABLE, reason="explicit pinned source is absent")
def test_all_observed_adapter_matches_manual_normalize_and_core_path():
    adapter = PinnedKalmanNetGainAdapter(LOCAL_SOURCE)
    batch_size = 4
    features = _features(batch_size)
    availability = torch.ones(batch_size, 6, dtype=torch.bool)

    adapter.reset(batch_size, device=torch.device("cpu"), dtype=torch.float32)
    adapted = adapter.gain_step(*features, availability)
    adapter.reset(batch_size, device=torch.device("cpu"), dtype=torch.float32)
    manually_normalized = [
        functional.normalize(value, p=2, dim=1, eps=1.0e-12)
        for value in features
    ]
    manual = adapter.core.KGain_step(*manually_normalized).reshape(
        batch_size, 16, 6
    )

    torch.testing.assert_close(adapted, manual, rtol=0.0, atol=0.0)
