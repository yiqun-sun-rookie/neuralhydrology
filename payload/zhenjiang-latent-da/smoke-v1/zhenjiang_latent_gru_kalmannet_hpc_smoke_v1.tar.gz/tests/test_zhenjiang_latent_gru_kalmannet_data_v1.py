"""Leakage and indexing tests for the forty-eight-hour latent-state adapter."""

from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timedelta, timezone
from pathlib import Path
import sys

import numpy as np
import pytest
import torch


ROOT = Path(__file__).resolve().parents[1]
for relative in ("scripts/modeling", "scripts/analysis"):
    candidate = str(ROOT / relative)
    if candidate not in sys.path:
        sys.path.insert(0, candidate)

import zhenjiang_oyv_v1_contract as contract  # noqa: E402
from zhenjiang_oyv_v1_data import OutOfYearData  # noqa: E402
from zhenjiang_latent_gru_kalmannet_data_v1 import (  # noqa: E402
    FoldAstronomicalTideSeries,
    LatentDAFoldNormalization,
    LatentDARecord,
    LatentDAWindowDataset,
    accepted_latent_da_records,
    all_observed_availability,
    all_unobserved_availability,
    fit_latent_da_normalization,
    one_station_only_availability,
    station_outage_availability,
)


BEIJING = timezone(timedelta(hours=8))


def _synthetic_data(
    hour_count: int = 200,
    start: datetime = datetime(2022, 1, 1, tzinfo=BEIJING),
) -> OutOfYearData:
    times = tuple(start + timedelta(hours=index) for index in range(hour_count))
    hour_year = np.asarray([value.year for value in times], dtype=np.int64)
    time_index = np.arange(hour_count, dtype=np.float64)[:, None]
    station_index = np.arange(6, dtype=np.float64)[None, :]
    stages = time_index * 10.0 + station_index + 0.25
    targets = 1000.0 + time_index * 10.0 + station_index + 0.75
    complete = np.ones(hour_count, dtype=bool)
    accepted = np.arange(23, hour_count - 24, dtype=np.int64)
    return OutOfYearData(
        times_beijing=times,
        hour_year=hour_year,
        stages_m=stages.astype(np.float32),
        targets_m=targets.astype(np.float32),
        stage_direction_float32=stages[:, 0].astype(np.float32),
        astronomical_tide_m=np.full(hour_count, -99999.0, dtype=np.float64),
        complete_stage=complete.copy(),
        complete_target=complete.copy(),
        accepted_positions=accepted,
        single_year_window=np.ones(hour_count, dtype=bool),
        input_identity={},
    )


def _fold_tide(data: OutOfYearData, *, values=None) -> FoldAstronomicalTideSeries:
    if values is None:
        values = 10.0 + 0.25 * np.arange(len(data.times_beijing), dtype=np.float64)
    return FoldAstronomicalTideSeries(
        values_m=np.asarray(values, dtype=np.float64),
        test_year=2024,
        training_years=contract.training_years(2024),
        model_sha256="a" * 64,
        series_sha256="b" * 64,
    )


def _identity_normalization() -> LatentDAFoldNormalization:
    return LatentDAFoldNormalization(
        station_mean_m=np.zeros(6, dtype=np.float64),
        station_standard_deviation_m=np.ones(6, dtype=np.float64),
        tide_mean_m=0.0,
        tide_standard_deviation_m=1.0,
    )


def test_dataset_uses_exact_frozen_indices_and_only_t_minus_48_for_first_difference():
    data = _synthetic_data()
    tide = _fold_tide(data)
    issue_position = 100
    record = LatentDARecord(issue_position, data.times_beijing[issue_position])
    dataset = LatentDAWindowDataset(
        data, (record,), tide, _identity_normalization()
    )

    sample = dataset[0]

    np.testing.assert_array_equal(
        sample["warmup_levels"].numpy(), data.stages_m[53:77]
    )
    np.testing.assert_array_equal(
        sample["analysis_targets"].numpy(), data.stages_m[77:101]
    )
    np.testing.assert_array_equal(
        sample["future_targets"].numpy(), data.targets_m[101:125]
    )
    assert sample["warmup_controls"][0, 0].item() == pytest.approx(
        tide.values_m[53]
    )
    assert sample["warmup_controls"][0, 1].item() == pytest.approx(
        tide.values_m[53] - tide.values_m[52]
    )
    assert not np.any(sample["warmup_controls"].numpy() == -99999.0)


def test_record_eligibility_requires_complete_48_hour_history_and_24_targets():
    data = _synthetic_data()
    assert 100 in {record.issue_position for record in accepted_latent_da_records(data, (2022,))}

    stages = data.stages_m.copy()
    stages[100 - 47, 3] = np.nan
    missing_history = replace(data, stages_m=stages)
    assert 100 not in {
        record.issue_position
        for record in accepted_latent_da_records(missing_history, (2022,))
    }

    targets = data.targets_m.copy()
    targets[100 + 24, 4] = np.nan
    missing_target = replace(data, targets_m=targets)
    assert 100 not in {
        record.issue_position
        for record in accepted_latent_da_records(missing_target, (2022,))
    }


def test_record_eligibility_rejects_main_window_crossing_calendar_year():
    data = _synthetic_data(
        start=datetime(2021, 12, 29, tzinfo=BEIJING)
    )
    crossing_position = 80
    assert data.hour_year[crossing_position - 47] != data.hour_year[crossing_position + 24]

    accepted = accepted_latent_da_records(data, (2021, 2022))

    assert crossing_position not in {record.issue_position for record in accepted}


def test_dataset_requires_every_supplied_tide_hour_it_reads():
    data = _synthetic_data()
    values = _fold_tide(data).values_m.copy()
    values[52] = np.nan
    dataset = LatentDAWindowDataset(
        data,
        (LatentDARecord(100, data.times_beijing[100]),),
        _fold_tide(data, values=values),
        _identity_normalization(),
    )

    with pytest.raises(ValueError, match="tide window"):
        dataset[0]


def test_normalization_uses_only_48_stage_and_72_supplied_tide_hours_in_float64():
    data = _synthetic_data()
    tide = _fold_tide(data)
    records = tuple(
        LatentDARecord(position, data.times_beijing[position])
        for position in (100, 120)
    )

    normalization = fit_latent_da_normalization(data, records, tide)

    stage_positions = np.asarray((100, 120))[:, None] + np.arange(-47, 1)[None, :]
    tide_positions = np.asarray((100, 120))[:, None] + np.arange(-47, 25)[None, :]
    expected_stages = data.stages_m.astype(np.float64)[stage_positions]
    expected_tide = tide.values_m.astype(np.float64)[tide_positions]
    np.testing.assert_array_equal(
        normalization.station_mean_m,
        np.mean(expected_stages, axis=(0, 1), dtype=np.float64),
    )
    np.testing.assert_array_equal(
        normalization.station_standard_deviation_m,
        np.std(expected_stages, axis=(0, 1), ddof=0, dtype=np.float64),
    )
    assert normalization.tide_mean_m == np.mean(expected_tide, dtype=np.float64)
    assert normalization.tide_standard_deviation_m == np.std(
        expected_tide, ddof=0, dtype=np.float64
    )
    assert normalization.station_mean_m.dtype == np.float64
    assert normalization.station_standard_deviation_m.dtype == np.float64


def test_extreme_retrospective_targets_cannot_change_training_normalization():
    data = _synthetic_data()
    tide = _fold_tide(data)
    records = (LatentDARecord(100, data.times_beijing[100]),)
    baseline = fit_latent_da_normalization(data, records, tide)
    altered_targets = np.full_like(data.targets_m, 1.0e20)

    altered = fit_latent_da_normalization(
        replace(data, targets_m=altered_targets), records, tide
    )

    np.testing.assert_array_equal(baseline.station_mean_m, altered.station_mean_m)
    np.testing.assert_array_equal(
        baseline.station_standard_deviation_m,
        altered.station_standard_deviation_m,
    )
    assert baseline.tide_mean_m == altered.tide_mean_m
    assert baseline.tide_standard_deviation_m == altered.tide_standard_deviation_m


def test_normalization_rejects_manually_supplied_cross_year_training_record():
    data = _synthetic_data(start=datetime(2021, 12, 29, tzinfo=BEIJING))
    record = LatentDARecord(80, data.times_beijing[80])

    with pytest.raises(ValueError, match="single calendar year"):
        fit_latent_da_normalization(data, (record,), _fold_tide(data))


@pytest.mark.parametrize(
    "change,match",
    [
        ({"test_year": 2023}, "training years"),
        ({"training_years": (2017,)}, "training years"),
        ({"model_sha256": "A" * 64}, "lowercase"),
        ({"series_sha256": "b" * 63}, "64-character"),
    ],
)
def test_fold_tide_identity_must_match_fold_and_hash_contract(change, match):
    data = _synthetic_data()
    tide = replace(_fold_tide(data), **change)
    record = LatentDARecord(100, data.times_beijing[100])

    with pytest.raises(ValueError, match=match):
        fit_latent_da_normalization(data, (record,), tide)


def test_same_station_statistics_transform_every_level_role_and_mask_afterward():
    data = _synthetic_data()
    tide = _fold_tide(data)
    normalization = LatentDAFoldNormalization(
        station_mean_m=np.arange(6, dtype=np.float64) + 5.0,
        station_standard_deviation_m=np.arange(6, dtype=np.float64) + 2.0,
        tide_mean_m=3.0,
        tide_standard_deviation_m=4.0,
    )
    availability = all_observed_availability()
    availability[5:10, 2] = False
    record = LatentDARecord(100, data.times_beijing[100])
    dataset = LatentDAWindowDataset(
        data,
        (record,),
        tide,
        normalization,
        analysis_availability=availability,
    )

    sample = dataset[0]
    mean = normalization.station_mean_m
    scale = normalization.station_standard_deviation_m
    expected_analysis = (data.stages_m[77:101] - mean) / scale
    expected_future = (data.targets_m[101:125] - mean) / scale
    np.testing.assert_allclose(sample["analysis_targets"].numpy(), expected_analysis)
    np.testing.assert_allclose(sample["future_targets"].numpy(), expected_future)
    np.testing.assert_allclose(
        sample["analysis_observations"].numpy()[availability],
        expected_analysis[availability],
    )
    assert np.isnan(sample["analysis_observations"].numpy()[~availability]).all()


def test_input_mask_never_changes_analysis_or_future_labels():
    data = _synthetic_data()
    record = LatentDARecord(100, data.times_beijing[100])
    common = (data, (record,), _fold_tide(data), _identity_normalization())

    observed = LatentDAWindowDataset(
        *common, analysis_availability=all_observed_availability()
    )[0]
    missing = LatentDAWindowDataset(
        *common, analysis_availability=all_unobserved_availability()
    )[0]

    assert torch.equal(observed["analysis_targets"], missing["analysis_targets"])
    assert torch.equal(observed["future_targets"], missing["future_targets"])
    assert torch.isnan(missing["analysis_observations"]).all()


def test_technical_mask_builders_have_frozen_shapes_and_semantics():
    assert all_observed_availability().shape == (24, 6)
    assert all_observed_availability().all()
    assert not all_unobserved_availability().any()
    one_station = one_station_only_availability(3)
    assert one_station[:, 3].all()
    assert one_station.sum() == 24
    for duration in (0, 1, 3, 6, 12, 24):
        outage = station_outage_availability(2, duration)
        assert outage.shape == (24, 6)
        assert (~outage[:, 2]).sum() == duration
        assert outage[:, [0, 1, 3, 4, 5]].all()
    with pytest.raises(ValueError, match="duration"):
        station_outage_availability(2, 2)


def test_dataset_output_contract_has_frozen_keys_shapes_and_issue_identity():
    data = _synthetic_data()
    record = LatentDARecord(100, data.times_beijing[100])
    sample = LatentDAWindowDataset(
        data, (record,), _fold_tide(data), _identity_normalization()
    )[0]

    assert set(sample) == {
        "warmup_levels",
        "warmup_controls",
        "analysis_observations",
        "analysis_targets",
        "analysis_availability",
        "analysis_controls",
        "future_controls",
        "future_targets",
        "issue_time_beijing",
        "issue_position",
    }
    assert sample["warmup_levels"].shape == (24, 6)
    assert sample["warmup_controls"].shape == (24, 2)
    assert sample["analysis_observations"].shape == (24, 6)
    assert sample["analysis_targets"].shape == (24, 6)
    assert sample["analysis_availability"].shape == (24, 6)
    assert sample["analysis_controls"].shape == (24, 2)
    assert sample["future_controls"].shape == (24, 2)
    assert sample["future_targets"].shape == (24, 6)
    assert sample["issue_time_beijing"] == data.times_beijing[100]
    assert sample["issue_position"] == 100
