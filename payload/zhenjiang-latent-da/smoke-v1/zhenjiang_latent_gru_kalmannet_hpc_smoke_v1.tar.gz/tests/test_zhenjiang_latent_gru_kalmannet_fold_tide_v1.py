"""Tests for training-year-only harmonic tide construction and persistence."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
from types import SimpleNamespace
import sys

import numpy as np
import pytest


ROOT = Path(__file__).resolve().parents[1]
for relative in ("scripts/modeling", "scripts/analysis"):
    candidate = str(ROOT / relative)
    if candidate not in sys.path:
        sys.path.insert(0, candidate)

import zhenjiang_oyv_v1_contract as contract  # noqa: E402
from zhenjiang_oyv_v1_data import OutOfYearData  # noqa: E402
import zhenjiang_latent_gru_kalmannet_fold_tide_v1 as module  # noqa: E402
from zhenjiang_latent_gru_kalmannet_fold_tide_v1 import (  # noqa: E402
    fit_fold_astronomical_tide,
    load_fold_astronomical_tide,
    write_fold_astronomical_tide,
)


BEIJING = timezone(timedelta(hours=8))


class FakeTideModel:
    def __init__(self):
        self.model = [
            {
                "constituent": SimpleNamespace(name="M2"),
                "amplitude": 1.25,
                "phase": 32.5,
            },
            {
                "constituent": SimpleNamespace(name="S2"),
                "amplitude": 0.25,
                "phase": 91.0,
            },
        ]

    def at(self, times):
        return 0.5 + np.arange(len(times), dtype=np.float64) * 0.01


def _data() -> OutOfYearData:
    times = []
    years = []
    for year in contract.CANDIDATE_FOLD_YEARS:
        for hour in range(6):
            times.append(datetime(year, 7, 1, hour, tzinfo=BEIJING))
            years.append(year)
    hour_count = len(times)
    stages = np.zeros((hour_count, 6), dtype=np.float32)
    for index, year in enumerate(years):
        stages[index, :] = np.arange(6, dtype=np.float32) + float(year)
    targets = np.full((hour_count, 6), 9.0e8, dtype=np.float32)
    complete = np.ones(hour_count, dtype=bool)
    return OutOfYearData(
        times_beijing=tuple(times),
        hour_year=np.asarray(years, dtype=np.int64),
        stages_m=stages,
        targets_m=targets,
        stage_direction_float32=stages[:, 0].copy(),
        astronomical_tide_m=np.full(hour_count, -999.0),
        complete_stage=complete.copy(),
        complete_target=complete.copy(),
        accepted_positions=np.arange(hour_count, dtype=np.int64),
        single_year_window=complete.copy(),
        input_identity={"realtime_features/wusongkou.csv": {"sha256": "a" * 64}},
    )


def test_fit_uses_only_training_year_wusongkou_values(monkeypatch):
    captured = {}

    def fake_decompose(values, times):
        captured["values"] = np.asarray(values).copy()
        captured["times"] = tuple(times)
        return FakeTideModel()

    monkeypatch.setattr(module, "_decompose", fake_decompose)
    data = _data()
    series, metadata = fit_fold_astronomical_tide(data, 2024)
    training_years = contract.training_years(2024)
    expected_positions = np.flatnonzero(np.isin(data.hour_year, training_years))

    np.testing.assert_array_equal(
        captured["values"], data.stages_m[expected_positions, 5].astype(np.float64)
    )
    assert all(value.tzinfo is None for value in captured["times"])
    assert metadata["model"]["fit_years"] == list(training_years)
    assert metadata["model"]["inner_validation_year"] == 2023
    assert metadata["retrospective_target_values_used_for_fit"] is False
    assert metadata["inner_validation_values_used_for_fit"] is False
    assert metadata["test_year_values_used_for_fit"] is False
    assert series.test_year == 2024
    assert series.training_years == training_years
    assert series.values_m.shape == (len(data.times_beijing),)


def test_extreme_targets_cannot_change_fold_tide(monkeypatch):
    monkeypatch.setattr(module, "_decompose", lambda values, times: FakeTideModel())
    data = _data()
    first, _ = fit_fold_astronomical_tide(data, 2024)
    data.targets_m[:, :] = -9.0e20
    second, _ = fit_fold_astronomical_tide(data, 2024)

    np.testing.assert_array_equal(first.values_m, second.values_m)
    assert first.model_sha256 == second.model_sha256
    assert first.series_sha256 == second.series_sha256


def test_persistence_round_trip_verifies_float64_series_and_model(monkeypatch, tmp_path):
    monkeypatch.setattr(module, "_decompose", lambda values, times: FakeTideModel())
    series, metadata = fit_fold_astronomical_tide(_data(), 2024)
    output = tmp_path / "fold_2024"

    write_fold_astronomical_tide(output, series, metadata)
    loaded = load_fold_astronomical_tide(output, 2024)

    assert loaded.values_m.dtype == np.dtype("float64")
    np.testing.assert_array_equal(loaded.values_m, series.values_m)
    assert loaded.model_sha256 == series.model_sha256
    assert loaded.series_sha256 == series.series_sha256
    manifest = json.loads(
        (output / module.MANIFEST_FILENAME).read_text(encoding="utf-8")
    )
    assert manifest["status"] == "completed"
    assert len(manifest["artifacts"]) == 2


def test_persistence_refuses_overwrite(monkeypatch, tmp_path):
    monkeypatch.setattr(module, "_decompose", lambda values, times: FakeTideModel())
    series, metadata = fit_fold_astronomical_tide(_data(), 2024)
    output = tmp_path / "fold_2024"
    output.mkdir()

    with pytest.raises(FileExistsError):
        write_fold_astronomical_tide(output, series, metadata)


def test_series_file_tampering_is_rejected(monkeypatch, tmp_path):
    monkeypatch.setattr(module, "_decompose", lambda values, times: FakeTideModel())
    series, metadata = fit_fold_astronomical_tide(_data(), 2024)
    output = tmp_path / "fold_2024"
    write_fold_astronomical_tide(output, series, metadata)
    path = output / module.SERIES_FILENAME
    content = bytearray(path.read_bytes())
    content[-1] ^= 1
    path.write_bytes(bytes(content))

    with pytest.raises(ValueError, match="SHA-256"):
        load_fold_astronomical_tide(output, 2024)


def test_wrong_expected_fold_is_rejected(monkeypatch, tmp_path):
    monkeypatch.setattr(module, "_decompose", lambda values, times: FakeTideModel())
    series, metadata = fit_fold_astronomical_tide(_data(), 2024)
    output = tmp_path / "fold_2024"
    write_fold_astronomical_tide(output, series, metadata)

    with pytest.raises(ValueError, match="test year"):
        load_fold_astronomical_tide(output, 2022)
