"""Tests for the immutable technical-smoke configuration and registry."""

from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys

import pytest


ROOT = Path(__file__).resolve().parents[1]
MODELING_DIR = ROOT / "scripts" / "modeling"
if str(MODELING_DIR) not in sys.path:
    sys.path.insert(0, str(MODELING_DIR))

from zhenjiang_latent_gru_kalmannet_experiment_v1 import (  # noqa: E402
    SMOKE_EXPERIMENT_ID,
    SMOKE_EXPERIMENT_TYPE,
    SMOKE_OUTPUT_RELATIVE_PATH,
    load_registered_smoke_config,
    validate_smoke_config,
)


CONFIG_PATH = (
    ROOT
    / "docs"
    / "records"
    / "ZHENJIANG_LATENT_GRU_KALMANNET_HPC_SMOKE_V1_CONFIG.json"
)
REGISTRY_PATH = (
    ROOT
    / "docs"
    / "records"
    / "ZHENJIANG_LATENT_GRU_KALMANNET_EXPERIMENT_REGISTRY_V1.json"
)


def _valid_config():
    return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))


def test_registered_project_smoke_configuration_loads_by_exact_digest():
    config = load_registered_smoke_config(CONFIG_PATH, REGISTRY_PATH)
    assert config["experiment_id"] == SMOKE_EXPERIMENT_ID
    assert config["experiment_type"] == SMOKE_EXPERIMENT_TYPE
    assert config["output_relative_path"] == SMOKE_OUTPUT_RELATIVE_PATH
    assert config["test_split_access"] == "forbidden"
    assert config["scientific_result"] is False


@pytest.mark.parametrize(
    "mutator,match",
    [
        (lambda value: value.update(test_split_access="allowed"), "test split access"),
        (lambda value: value.update(scientific_result=True), "scientific result"),
        (lambda value: value.update(test_year=2023), "test year"),
        (
            lambda value: value["training"]["stage_one"].update(
                maximum_epochs=2
            ),
            "maximum epochs",
        ),
        (
            lambda value: value["training"]["stage_two"].update(
                maximum_training_batches_per_epoch=3
            ),
            "maximum training batches",
        ),
        (
            lambda value: value["availability"].update(mode="all_observed"),
            "availability mode",
        ),
    ],
)
def test_semantic_safety_changes_are_rejected(mutator, match):
    config = _valid_config()
    mutator(config)
    with pytest.raises(ValueError, match=match):
        validate_smoke_config(config)


def test_semantically_valid_but_byte_changed_config_fails_registry_digest(tmp_path):
    changed_config_path = tmp_path / "config.json"
    changed_config_path.write_text(
        json.dumps(_valid_config(), separators=(",", ":")), encoding="utf-8"
    )

    with pytest.raises(ValueError, match="SHA-256 mismatch"):
        load_registered_smoke_config(changed_config_path, REGISTRY_PATH)


def test_registry_has_one_atomic_experiment_row_and_required_tracking_fields():
    registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
    rows = [
        row for row in registry["experiments"] if row["exp_id"] == SMOKE_EXPERIMENT_ID
    ]
    assert len(rows) == 1
    row = rows[0]
    assert set(
        (
            "exp_id",
            "type",
            "hypothesis",
            "base_config",
            "changed_factor",
            "fixed_factors",
            "seeds",
            "status",
            "run_dir",
            "best_checkpoint",
            "metrics_path",
            "paper_name",
            "notes",
            "config_path",
            "config_sha256",
        )
    ).issubset(row)
    assert row["seeds"] == [20260827]
    assert row["run_dir"] == SMOKE_OUTPUT_RELATIVE_PATH
    assert row["config_sha256"] == hashlib.sha256(CONFIG_PATH.read_bytes()).hexdigest()


def test_duplicate_smoke_rows_are_rejected(tmp_path):
    registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
    registry["experiments"].append(deepcopy(registry["experiments"][0]))
    path = tmp_path / "registry.json"
    path.write_text(json.dumps(registry), encoding="utf-8")

    with pytest.raises(ValueError, match="one smoke row"):
        load_registered_smoke_config(CONFIG_PATH, path)
