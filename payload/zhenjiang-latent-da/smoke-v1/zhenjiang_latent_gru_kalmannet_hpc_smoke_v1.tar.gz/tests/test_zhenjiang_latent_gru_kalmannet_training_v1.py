"""Tests for staged losses, freezing, dispatch, and command-line safety."""

from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys

import pytest
import torch


ROOT = Path(__file__).resolve().parents[1]
MODELING_DIR = ROOT / "scripts" / "modeling"
if str(MODELING_DIR) not in sys.path:
    sys.path.insert(0, str(MODELING_DIR))

from zhenjiang_latent_gru_kalmannet_v1 import (  # noqa: E402
    AvailabilityGatedLatentGRUKalmanNet,
)
from zhenjiang_latent_gru_kalmannet_training_v1 import (  # noqa: E402
    PRETRAIN_BACKBONE,
    SMOOTH_ABSOLUTE_ERROR_TRANSITION_M,
    STATION_LOSS_WEIGHTS,
    TRAIN_GAIN,
    SyntheticLearnedGain,
    compute_stage_loss,
    configure_training_stage,
    forward_for_training_stage,
    metre_space_smooth_absolute_error,
)


TRAINING_SCRIPT = (
    ROOT / "scripts" / "modeling" / "zhenjiang_latent_gru_kalmannet_training_v1.py"
)


def _batch(batch_size: int = 2):
    torch.manual_seed(8675309)
    return {
        "warmup_levels": torch.randn(batch_size, 24, 6),
        "warmup_controls": torch.randn(batch_size, 24, 2),
        "analysis_observations": torch.randn(batch_size, 24, 6),
        "analysis_targets": torch.randn(batch_size, 24, 6),
        "analysis_availability": torch.ones(
            batch_size, 24, 6, dtype=torch.bool
        ),
        "analysis_controls": torch.randn(batch_size, 24, 2),
        "future_controls": torch.randn(batch_size, 24, 2),
        "future_targets": torch.randn(batch_size, 24, 6),
    }


def _new_model():
    return AvailabilityGatedLatentGRUKalmanNet(SyntheticLearnedGain())


def test_metre_space_loss_uses_equal_station_weights_and_point_one_transition():
    prediction = torch.zeros(1, 24, 6)
    target = torch.zeros_like(prediction)
    prediction[0, 0] = 0.05
    scales = torch.arange(1, 7, dtype=torch.float32)
    metre_errors = torch.tensor([0.05, 0.10, 0.15, 0.20, 0.25, 0.30])
    element_losses = torch.where(
        metre_errors < 0.10,
        0.5 * metre_errors.square() / 0.10,
        metre_errors - 0.05,
    )
    expected = element_losses.sum() / (24 * 6)

    actual = metre_space_smooth_absolute_error(prediction, target, scales)

    assert SMOOTH_ABSOLUTE_ERROR_TRANSITION_M == pytest.approx(0.10)
    assert STATION_LOSS_WEIGHTS == (1.0, 1.0, 1.0, 1.0, 1.0, 1.0)
    torch.testing.assert_close(actual, expected)


def test_stage_one_trains_backbone_only_and_dispatch_never_calls_gain(monkeypatch):
    model = _new_model()
    trainable = configure_training_stage(model, PRETRAIN_BACKBONE)
    for name, parameter in model.named_parameters():
        assert parameter.requires_grad is name.startswith("backbone.")
    assert trainable
    assert all(name.startswith("backbone.") for name in trainable)

    def forbidden(*args, **kwargs):
        raise AssertionError("stage one must not touch the gain module")

    monkeypatch.setattr(model.gain_module, "reset", forbidden)
    monkeypatch.setattr(model.gain_module, "gain_step", forbidden)
    output = forward_for_training_stage(model, _batch(), PRETRAIN_BACKBONE)
    assert torch.equal(output["analysis_prior_states"], output["analysis_posterior_states"])


def test_stage_one_loss_is_equal_analysis_prior_and_future_loss_only():
    model = _new_model()
    batch = _batch()
    output = forward_for_training_stage(model, batch, PRETRAIN_BACKBONE)
    output["analysis_posterior_observations"] = torch.full_like(
        output["analysis_prior_observations"], 1.0e12
    )
    scales = torch.tensor([1.0, 1.5, 2.0, 2.5, 3.0, 3.5])

    loss = compute_stage_loss(output, batch, scales, PRETRAIN_BACKBONE)
    expected = 0.5 * metre_space_smooth_absolute_error(
        output["analysis_prior_observations"], batch["analysis_targets"], scales
    ) + 0.5 * metre_space_smooth_absolute_error(
        output["forecasts"], batch["future_targets"], scales
    )

    torch.testing.assert_close(loss, expected)


def test_stage_one_outputs_and_loss_are_bitwise_independent_of_gain_parameters():
    model = _new_model()
    batch = _batch(batch_size=1)
    scales = torch.ones(6)
    first = forward_for_training_stage(model, batch, PRETRAIN_BACKBONE)
    first_loss = compute_stage_loss(first, batch, scales, PRETRAIN_BACKBONE)
    with torch.no_grad():
        for parameter in model.gain_module.parameters():
            parameter.copy_(torch.randn_like(parameter) * 1000.0)
    second = forward_for_training_stage(model, batch, PRETRAIN_BACKBONE)
    second_loss = compute_stage_loss(second, batch, scales, PRETRAIN_BACKBONE)

    for key in first:
        assert torch.equal(first[key], second[key]), key
    assert torch.equal(first_loss, second_loss)


def test_stage_two_freezes_backbone_and_uses_only_future_forecast_loss():
    model = _new_model()
    trainable = configure_training_stage(model, TRAIN_GAIN)
    for name, parameter in model.named_parameters():
        assert parameter.requires_grad is name.startswith("gain_module.")
    assert trainable
    assert all(name.startswith("gain_module.") for name in trainable)

    batch = _batch()
    output = forward_for_training_stage(model, batch, TRAIN_GAIN)
    scales = torch.arange(1, 7, dtype=torch.float32)
    actual = compute_stage_loss(output, batch, scales, TRAIN_GAIN)
    expected = metre_space_smooth_absolute_error(
        output["forecasts"], batch["future_targets"], scales
    )
    torch.testing.assert_close(actual, expected)


@pytest.mark.parametrize("stage", [PRETRAIN_BACKBONE, TRAIN_GAIN])
def test_gradients_are_isolated_by_stage_without_cutting_gain_forecast_path(stage):
    model = _new_model()
    configure_training_stage(model, stage)
    batch = _batch()
    output = forward_for_training_stage(model, batch, stage)
    loss = compute_stage_loss(output, batch, torch.ones(6), stage)
    loss.backward()

    backbone_gradients = [
        parameter.grad for parameter in model.backbone.parameters()
    ]
    gain_gradients = [
        parameter.grad for parameter in model.gain_module.parameters()
    ]
    if stage == PRETRAIN_BACKBONE:
        assert any(
            gradient is not None
            and torch.isfinite(gradient).all()
            and torch.count_nonzero(gradient).item() > 0
            for gradient in backbone_gradients
        )
        assert all(gradient is None for gradient in gain_gradients)
    else:
        assert all(gradient is None for gradient in backbone_gradients)
        assert any(
            gradient is not None
            and torch.isfinite(gradient).all()
            and torch.count_nonzero(gradient).item() > 0
            for gradient in gain_gradients
        )


def test_describe_works_without_data_or_external_source():
    completed = subprocess.run(
        [sys.executable, str(TRAINING_SCRIPT), "--describe", "--stage", TRAIN_GAIN],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    )
    description = json.loads(completed.stdout)
    assert description["formal_training_authorized"] is False
    assert description["external_kalmannet_source"] is None
    assert description["state_dimension"] == 16
    assert description["time_windows_hours"] == {
        "warmup": 24,
        "analysis": 24,
        "forecast": 24,
    }
    assert all(
        name.startswith("gain_module.")
        for name in description["trainable_parameter_names"]
    )


def test_dry_run_uses_synthetic_cpu_tensors_only():
    completed = subprocess.run(
        [
            sys.executable,
            str(TRAINING_SCRIPT),
            "--dry-run",
            "--stage",
            PRETRAIN_BACKBONE,
        ],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    )
    report = json.loads(completed.stdout)
    assert report["device"] == "cpu"
    assert report["synthetic_tensors_only"] is True
    assert report["stage"] == PRETRAIN_BACKBONE
    assert report["formal_training_authorized"] is False
    assert report["loss_is_finite"] is True


def test_real_training_request_is_refused_before_source_or_data_access():
    missing_source = ROOT / "does_not_exist" / "KalmanNet_nn.py"
    completed = subprocess.run(
        [
            sys.executable,
            str(TRAINING_SCRIPT),
            "--stage",
            TRAIN_GAIN,
            "--kalmannet-source",
            str(missing_source),
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    assert completed.returncode != 0
    assert "--allow-training" in completed.stderr
    assert "does not exist" not in completed.stderr
