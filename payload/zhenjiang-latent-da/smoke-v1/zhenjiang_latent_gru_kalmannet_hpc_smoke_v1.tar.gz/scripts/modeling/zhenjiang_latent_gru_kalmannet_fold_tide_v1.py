#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Fit and persist one fold-specific Wusongkou astronomical-tide series.

Inputs:
    The aligned six-station ``OutOfYearData`` object and one outer test year.
    Only finite Wusongkou real-time stage values in the six training years are
    supplied to the harmonic decomposition.

Outputs:
    A ``FoldAstronomicalTideSeries`` covering the complete active hourly axis,
    a model-provenance dictionary, or a non-overwriting directory containing
    ``fold_tide_series.npz``, ``fold_tide_metadata.json``, and a manifest.

Command-line arguments:
    ``--describe`` prints the fitting contract.  Real-data construction is
    performed by the bounded training runner after its smoke authorization
    and registry checks.

Example:
    python scripts/modeling/zhenjiang_latent_gru_kalmannet_fold_tide_v1.py --describe
"""

from __future__ import annotations

import argparse
from datetime import timedelta
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
from typing import Any, Dict, Sequence, Tuple
from uuid import uuid4

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[2]
for _relative in ("scripts/modeling", "scripts/analysis", "third_party/pytides"):
    _candidate = str(PROJECT_ROOT / _relative)
    if _candidate not in sys.path:
        sys.path.insert(0, _candidate)

from tide import Tide  # noqa: E402

import zhenjiang_oyv_v1_contract as contract  # noqa: E402
from zhenjiang_oyv_v1_data import OutOfYearData  # noqa: E402
from zhenjiang_latent_gru_kalmannet_data_v1 import (  # noqa: E402
    FoldAstronomicalTideSeries,
)
from zhenjiang_latent_gru_kalmannet_v1 import STATION_ORDER  # noqa: E402


SERIES_FILENAME = "fold_tide_series.npz"
METADATA_FILENAME = "fold_tide_metadata.json"
MANIFEST_FILENAME = "completion_manifest.json"
WUSONGKOU_INDEX = STATION_ORDER.index("wusongkou")
MINIMUM_FIT_AVAILABLE_HOURS = 24


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _canonical_json_bytes(value: object) -> bytes:
    return (
        json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
        + "\n"
    ).encode("utf-8")


def _series_bytes(values: np.ndarray) -> bytes:
    canonical = np.ascontiguousarray(np.asarray(values, dtype="<f8"))
    if canonical.ndim != 1 or not np.isfinite(canonical).all():
        raise ValueError("fold astronomical-tide series must be finite and one-dimensional")
    return canonical.tobytes(order="C")


def _naive_utc(value):
    if value.tzinfo is None or value.utcoffset() != timedelta(hours=8):
        raise ValueError("fold tide timestamps must use Beijing offset +08:00")
    return (value - value.utcoffset()).replace(tzinfo=None)


def _decompose(values: np.ndarray, times: Sequence[object]):
    """Small patch point around the deterministic PyTides decomposition."""

    return Tide.decompose(values, times)


def _constituent_rows(model: object) -> list[dict[str, object]]:
    rows = []
    for index, record in enumerate(model.model):
        rows.append(
            {
                "index": int(index),
                "constituent": str(record["constituent"].name),
                "amplitude_m": float(record["amplitude"]),
                "phase_degrees": float(record["phase"]),
            }
        )
    if not rows:
        raise ValueError("harmonic tide model contains no constituents")
    return rows


def fit_fold_astronomical_tide(
    data: OutOfYearData, test_year: int
) -> Tuple[FoldAstronomicalTideSeries, Dict[str, Any]]:
    """Fit only training-year Wusongkou stages, then predict the full axis."""

    if not isinstance(data, OutOfYearData):
        raise ValueError("aligned out-of-year data are required")
    test_year = int(test_year)
    training_years = tuple(contract.training_years(test_year))
    hour_count = len(data.times_beijing)
    years = np.asarray(data.hour_year, dtype=np.int64)
    stages = np.asarray(data.stages_m, dtype=np.float64)
    if years.shape != (hour_count,) or stages.shape != (hour_count, 6):
        raise ValueError("aligned years or stages have the wrong shape")
    wusongkou = stages[:, WUSONGKOU_INDEX]
    fit_mask = np.isin(years, np.asarray(training_years, dtype=np.int64))
    fit_mask &= np.isfinite(wusongkou)
    fit_positions = np.flatnonzero(fit_mask)
    if fit_positions.size < MINIMUM_FIT_AVAILABLE_HOURS:
        raise ValueError("too few finite training-year Wusongkou hours for tide fitting")
    fit_values = np.ascontiguousarray(wusongkou[fit_positions], dtype=np.float64)
    fit_times = [_naive_utc(data.times_beijing[int(i)]) for i in fit_positions]
    model = _decompose(fit_values, fit_times)
    all_times = [_naive_utc(value) for value in data.times_beijing]
    predictions = np.ascontiguousarray(
        np.asarray(model.at(all_times), dtype="<f8")
    )
    if predictions.shape != (hour_count,) or not np.isfinite(predictions).all():
        raise ValueError("fold astronomical-tide prediction is nonfinite or misaligned")

    model_payload = {
        "model_type": "fold_training_year_harmonic_astronomical_tide",
        "station_slug": "wusongkou",
        "test_year": test_year,
        "inner_validation_year": int(contract.inner_validation_year(test_year)),
        "fit_years": list(training_years),
        "fit_available_hour_count": int(fit_positions.size),
        "full_axis_hour_count": int(hour_count),
        "constituents": _constituent_rows(model),
    }
    model_sha256 = hashlib.sha256(_canonical_json_bytes(model_payload)).hexdigest()
    series_sha256 = hashlib.sha256(_series_bytes(predictions)).hexdigest()
    series = FoldAstronomicalTideSeries(
        values_m=predictions,
        test_year=test_year,
        training_years=training_years,
        model_sha256=model_sha256,
        series_sha256=series_sha256,
    )
    metadata = {
        "schema_version": 1,
        "model": model_payload,
        "model_sha256": model_sha256,
        "series_sha256": series_sha256,
        "series_dtype": "little_endian_float64",
        "series_shape": [int(hour_count)],
        "input_identity": dict(data.input_identity),
        "retrospective_target_values_used_for_fit": False,
        "inner_validation_values_used_for_fit": False,
        "test_year_values_used_for_fit": False,
    }
    return series, metadata


def write_fold_astronomical_tide(
    directory: Path,
    series: FoldAstronomicalTideSeries,
    metadata: Dict[str, Any],
) -> None:
    """Atomically publish one new fold-tide directory without overwriting."""

    directory = Path(directory)
    if directory.exists():
        raise FileExistsError(directory)
    parent = directory.parent
    parent.mkdir(parents=True, exist_ok=True)
    staging = parent / (".%s.partial_%s" % (directory.name, uuid4().hex[:10]))
    staging.mkdir(parents=False, exist_ok=False)
    try:
        values = np.asarray(series.values_m, dtype="<f8")
        observed_series_digest = hashlib.sha256(_series_bytes(values)).hexdigest()
        if observed_series_digest != series.series_sha256:
            raise ValueError("series object SHA-256 does not match its values")
        observed_model_digest = hashlib.sha256(
            _canonical_json_bytes(metadata.get("model"))
        ).hexdigest()
        if observed_model_digest != series.model_sha256:
            raise ValueError("series object model SHA-256 does not match metadata")
        if metadata.get("series_sha256") != series.series_sha256 or metadata.get(
            "model_sha256"
        ) != series.model_sha256:
            raise ValueError("fold tide metadata identity differs from the series")
        np.savez(staging / SERIES_FILENAME, values_m=values)
        (staging / METADATA_FILENAME).write_bytes(_canonical_json_bytes(metadata))
        artifacts = []
        for filename in (SERIES_FILENAME, METADATA_FILENAME):
            path = staging / filename
            artifacts.append(
                {
                    "relative_path": filename,
                    "byte_count": int(path.stat().st_size),
                    "sha256": _sha256_file(path),
                }
            )
        manifest = {
            "schema_version": 1,
            "status": "completed",
            "test_year": int(series.test_year),
            "training_years": list(series.training_years),
            "model_sha256": series.model_sha256,
            "series_sha256": series.series_sha256,
            "artifacts": artifacts,
        }
        (staging / MANIFEST_FILENAME).write_bytes(_canonical_json_bytes(manifest))
        os.replace(staging, directory)
    except BaseException:
        shutil.rmtree(staging, ignore_errors=True)
        raise


def load_fold_astronomical_tide(
    directory: Path, expected_test_year: int
) -> FoldAstronomicalTideSeries:
    """Load a persisted fold series and independently verify every identity."""

    directory = Path(directory)
    metadata = json.loads((directory / METADATA_FILENAME).read_text(encoding="utf-8"))
    manifest = json.loads((directory / MANIFEST_FILENAME).read_text(encoding="utf-8"))
    if metadata.get("schema_version") != 1 or manifest.get("schema_version") != 1:
        raise ValueError("fold tide schema version changed")
    if manifest.get("status") != "completed":
        raise ValueError("fold tide manifest is not completed")
    for artifact in manifest.get("artifacts", []):
        path = directory / artifact["relative_path"]
        if path.stat().st_size != artifact["byte_count"]:
            raise ValueError("fold tide artifact byte count mismatch")
        if _sha256_file(path) != artifact["sha256"]:
            raise ValueError("fold tide artifact SHA-256 mismatch")
    with np.load(directory / SERIES_FILENAME, allow_pickle=False) as payload:
        values = np.asarray(payload["values_m"], dtype="<f8")
    test_year = int(expected_test_year)
    model = metadata.get("model")
    if not isinstance(model, dict) or model.get("test_year") != test_year:
        raise ValueError("fold tide test year mismatch")
    training_years = tuple(contract.training_years(test_year))
    if tuple(model.get("fit_years", ())) != training_years:
        raise ValueError("fold tide training years mismatch")
    model_digest = hashlib.sha256(_canonical_json_bytes(model)).hexdigest()
    series_digest = hashlib.sha256(_series_bytes(values)).hexdigest()
    if model_digest != metadata.get("model_sha256") or model_digest != manifest.get(
        "model_sha256"
    ):
        raise ValueError("fold tide model SHA-256 mismatch")
    if series_digest != metadata.get(
        "series_sha256"
    ) or series_digest != manifest.get("series_sha256"):
        raise ValueError("fold tide series SHA-256 mismatch")
    return FoldAstronomicalTideSeries(
        values_m=values,
        test_year=test_year,
        training_years=training_years,
        model_sha256=model_digest,
        series_sha256=series_digest,
    )


def fold_tide_contract_description() -> Dict[str, object]:
    return {
        "fit_station": "wusongkou",
        "fit_source": "finite_realtime_stage_values",
        "fit_years": "outer_fold_training_years_only",
        "inner_validation_values_used_for_fit": False,
        "test_year_values_used_for_fit": False,
        "retrospective_target_values_used_for_fit": False,
        "series_dtype": "little_endian_float64",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--describe", action="store_true")
    arguments = parser.parse_args()
    if not arguments.describe:
        parser.error("this module exposes only --describe; use the bounded runner to fit")
    print(json.dumps(fold_tide_contract_description(), indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
