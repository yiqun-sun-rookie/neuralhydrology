#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Shared abstract latent-state backbone for six-station data assimilation.

Inputs:
    Synthetic or fold-standardized tensors for a complete twenty-four-hour old
    history, two causal astronomical-tide controls, a recent analysis window,
    and a twenty-four-hour future-control window.  No future measured water
    level is accepted by the model interface.

Outputs:
    A sixteen-dimensional wholly abstract state and standardized six-station
    water-level forecasts from a learned linear decoder.

Command-line arguments:
    ``--describe`` prints the frozen technical interface as JSON.  This module
    has no training command and writes no files.

Example:
    python scripts/modeling/zhenjiang_latent_gru_kalmannet_v1.py --describe

This technical prototype does not establish forecast improvement,
cross-station benefit, probability calibration, or publication novelty.
"""

from __future__ import annotations

import argparse
import json
from typing import Any, Dict, Optional, Tuple

import torch
from torch import nn


STATION_ORDER = (
    "datong",
    "nanjing",
    "zhenjiang",
    "jiangyin",
    "xuliujing",
    "wusongkou",
)
STATION_COUNT = len(STATION_ORDER)
LATENT_STATE_DIMENSION = 16
CONTROL_NAMES = (
    "standardized_wusongkou_astronomical_tide",
    "causal_one_hour_tide_difference",
)
CONTROL_DIMENSION = len(CONTROL_NAMES)
WARMUP_LENGTH_HOURS = 24
ANALYSIS_LENGTH_HOURS = 24
FORECAST_LENGTH_HOURS = 24


def _validate_float_tensor(
    value: torch.Tensor,
    *,
    name: str,
    expected_shape: Tuple[int, ...],
    reference: torch.Tensor,
) -> None:
    """Validate one finite floating tensor against a model parameter.

    Inputs:
        ``value`` is the tensor being checked; ``expected_shape`` is exact;
        ``reference`` supplies the required data type and device.

    Outputs:
        None.  Invalid shapes, data types, devices, or values raise
        ``ValueError`` before a neural-network operation is attempted.
    """

    if not isinstance(value, torch.Tensor):
        raise ValueError("%s must be a torch tensor" % name)
    if tuple(value.shape) != tuple(expected_shape):
        raise ValueError(
            "%s must have shape %s, received %s"
            % (name, expected_shape, tuple(value.shape))
        )
    if not value.dtype.is_floating_point:
        raise ValueError("%s must use a floating-point dtype" % name)
    if value.dtype != reference.dtype:
        raise ValueError("%s dtype differs from the model" % name)
    if value.device != reference.device:
        raise ValueError("%s device differs from the model" % name)
    if not bool(torch.isfinite(value).all()):
        raise ValueError("%s contains a nonfinite value" % name)


class LatentGRUBackbone(nn.Module):
    """Encode old history, advance one hour, and decode station observations.

    The sixteen state coordinates are deliberately unnamed and abstract.  The
    decoder is learned; it does not select station values from state positions.
    """

    def __init__(self) -> None:
        super().__init__()
        self.history_encoder = nn.GRU(
            input_size=STATION_COUNT + CONTROL_DIMENSION,
            hidden_size=LATENT_STATE_DIMENSION,
            batch_first=True,
        )
        self.process_cell = nn.GRUCell(
            input_size=CONTROL_DIMENSION,
            hidden_size=LATENT_STATE_DIMENSION,
        )
        self.decoder = nn.Linear(LATENT_STATE_DIMENSION, STATION_COUNT)

    def _reference(self) -> torch.Tensor:
        return self.decoder.weight

    def encode_warmup(
        self, levels: torch.Tensor, controls: torch.Tensor
    ) -> torch.Tensor:
        """Map complete old history to the initial abstract state.

        Inputs:
            ``levels`` has shape ``[batch,24,6]`` and ``controls`` has shape
            ``[batch,24,2]``.  Both must be finite and model-compatible.

        Outputs:
            The final history-encoder state with shape ``[batch,16]``.
        """

        if not isinstance(levels, torch.Tensor) or levels.ndim != 3:
            raise ValueError("warm-up levels must be [batch,24,6]")
        batch_size = int(levels.shape[0])
        if batch_size < 1:
            raise ValueError("warm-up levels must contain at least one sample")
        _validate_float_tensor(
            levels,
            name="warm-up levels",
            expected_shape=(batch_size, WARMUP_LENGTH_HOURS, STATION_COUNT),
            reference=self._reference(),
        )
        _validate_float_tensor(
            controls,
            name="warm-up controls",
            expected_shape=(batch_size, WARMUP_LENGTH_HOURS, CONTROL_DIMENSION),
            reference=self._reference(),
        )
        encoded_input = torch.cat((levels, controls), dim=-1)
        _, hidden = self.history_encoder(encoded_input)
        return hidden[-1]

    def transition_step(
        self, state: torch.Tensor, controls: torch.Tensor
    ) -> torch.Tensor:
        """Advance the abstract state by one hour using causal tide controls."""

        if not isinstance(state, torch.Tensor) or state.ndim != 2:
            raise ValueError("state must be [batch,16]")
        batch_size = int(state.shape[0])
        _validate_float_tensor(
            state,
            name="state",
            expected_shape=(batch_size, LATENT_STATE_DIMENSION),
            reference=self._reference(),
        )
        _validate_float_tensor(
            controls,
            name="controls",
            expected_shape=(batch_size, CONTROL_DIMENSION),
            reference=self._reference(),
        )
        return self.process_cell(controls, state)

    def decode(self, state: torch.Tensor) -> torch.Tensor:
        """Decode an abstract state into six standardized station levels."""

        if not isinstance(state, torch.Tensor) or state.ndim != 2:
            raise ValueError("state must be [batch,16]")
        batch_size = int(state.shape[0])
        _validate_float_tensor(
            state,
            name="state",
            expected_shape=(batch_size, LATENT_STATE_DIMENSION),
            reference=self._reference(),
        )
        return self.decoder(state)

    def open_loop(
        self, state: torch.Tensor, controls: torch.Tensor
    ) -> torch.Tensor:
        """Produce exactly twenty-four future one-hour open-loop forecasts.

        Inputs:
            ``state`` is ``[batch,16]`` and ``controls`` is ``[batch,24,2]``.

        Outputs:
            Standardized six-station forecasts with shape ``[batch,24,6]``.
        """

        if not isinstance(state, torch.Tensor) or state.ndim != 2:
            raise ValueError("state must be [batch,16]")
        batch_size = int(state.shape[0])
        _validate_float_tensor(
            state,
            name="state",
            expected_shape=(batch_size, LATENT_STATE_DIMENSION),
            reference=self._reference(),
        )
        _validate_float_tensor(
            controls,
            name="future controls",
            expected_shape=(batch_size, FORECAST_LENGTH_HOURS, CONTROL_DIMENSION),
            reference=self._reference(),
        )
        forecasts = []
        current_state = state
        for hour_index in range(FORECAST_LENGTH_HOURS):
            current_state = self.process_cell(controls[:, hour_index, :], current_state)
            forecasts.append(self.decoder(current_state))
        return torch.stack(forecasts, dim=1)


class AvailabilityGatedLatentGRUKalmanNet(nn.Module):
    """Compose sequential learned-gain updates and a strict open-loop forecast.

    ``gain_module`` must implement ``reset`` and ``gain_step``.  A test double
    may be supplied without loading external code; the real adapter requires an
    explicit, digest-verified source path.
    """

    def __init__(
        self,
        gain_module: nn.Module,
        backbone: Optional[LatentGRUBackbone] = None,
    ) -> None:
        super().__init__()
        if not isinstance(gain_module, nn.Module):
            raise TypeError("gain module must be a torch module")
        self.backbone = LatentGRUBackbone() if backbone is None else backbone
        if not isinstance(self.backbone, LatentGRUBackbone):
            raise TypeError("backbone must be a LatentGRUBackbone")
        if not callable(getattr(gain_module, "reset", None)) or not callable(
            getattr(gain_module, "gain_step", None)
        ):
            raise TypeError("gain module must implement reset and gain_step")
        self.gain_module = gain_module

    def _availability_boolean(
        self,
        availability: torch.Tensor,
        *,
        expected_shape: Tuple[int, ...],
        reference: torch.Tensor,
    ) -> torch.Tensor:
        if not isinstance(availability, torch.Tensor) or tuple(
            availability.shape
        ) != tuple(expected_shape):
            raise ValueError(
                "analysis availability must have shape %s" % (expected_shape,)
            )
        if availability.device != reference.device:
            raise ValueError("analysis availability device differs from the model")
        if availability.dtype == torch.bool:
            return availability
        if not bool(torch.isfinite(availability).all()) or not bool(
            ((availability == 0) | (availability == 1)).all()
        ):
            raise ValueError("analysis availability must contain only zero or one")
        return availability.to(dtype=torch.bool)

    def _validate_analysis_observation(
        self,
        observation: torch.Tensor,
        availability: torch.Tensor,
        *,
        expected_shape: Tuple[int, ...],
        reference: torch.Tensor,
    ) -> None:
        if not isinstance(observation, torch.Tensor) or tuple(
            observation.shape
        ) != tuple(expected_shape):
            raise ValueError(
                "analysis observations must have shape %s" % (expected_shape,)
            )
        if not observation.dtype.is_floating_point:
            raise ValueError("analysis observations must use a floating-point dtype")
        if observation.dtype != reference.dtype:
            raise ValueError("analysis observations dtype differs from the model")
        if observation.device != reference.device:
            raise ValueError("analysis observations device differs from the model")
        if not bool(torch.isfinite(observation[availability]).all()):
            raise ValueError("an available analysis observation is nonfinite")

    def _validate_sequence_inputs(
        self,
        warmup_levels: torch.Tensor,
        warmup_controls: torch.Tensor,
        analysis_observations: torch.Tensor,
        analysis_availability: torch.Tensor,
        analysis_controls: torch.Tensor,
        future_controls: torch.Tensor,
    ) -> torch.Tensor:
        if not isinstance(warmup_levels, torch.Tensor) or warmup_levels.ndim != 3:
            raise ValueError("warm-up levels must be [batch,24,6]")
        batch_size = int(warmup_levels.shape[0])
        reference = self.backbone.decoder.weight
        _validate_float_tensor(
            warmup_levels,
            name="warm-up levels",
            expected_shape=(batch_size, WARMUP_LENGTH_HOURS, STATION_COUNT),
            reference=reference,
        )
        _validate_float_tensor(
            warmup_controls,
            name="warm-up controls",
            expected_shape=(batch_size, WARMUP_LENGTH_HOURS, CONTROL_DIMENSION),
            reference=reference,
        )
        availability_boolean = self._availability_boolean(
            analysis_availability,
            expected_shape=(batch_size, ANALYSIS_LENGTH_HOURS, STATION_COUNT),
            reference=reference,
        )
        self._validate_analysis_observation(
            analysis_observations,
            availability_boolean,
            expected_shape=(batch_size, ANALYSIS_LENGTH_HOURS, STATION_COUNT),
            reference=reference,
        )
        _validate_float_tensor(
            analysis_controls,
            name="analysis controls",
            expected_shape=(batch_size, ANALYSIS_LENGTH_HOURS, CONTROL_DIMENSION),
            reference=reference,
        )
        _validate_float_tensor(
            future_controls,
            name="future controls",
            expected_shape=(batch_size, FORECAST_LENGTH_HOURS, CONTROL_DIMENSION),
            reference=reference,
        )
        return availability_boolean

    def analysis_step(
        self,
        prior_state: torch.Tensor,
        observation: torch.Tensor,
        availability: torch.Tensor,
        previous_effective_observation: torch.Tensor,
        previous_posterior_state: torch.Tensor,
        posterior_before_previous_state: torch.Tensor,
        previous_prior_state: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        """Apply one availability-gated learned-gain state correction.

        Missing stored values are replaced before differences are formed.  The
        state is not clamped.  If all six observations are missing for a sample,
        its returned posterior is selected directly from the prior tensor.
        """

        if not isinstance(prior_state, torch.Tensor) or prior_state.ndim != 2:
            raise ValueError("prior state must be [batch,16]")
        batch_size = int(prior_state.shape[0])
        reference = self.backbone.decoder.weight
        for value, name in (
            (prior_state, "prior state"),
            (previous_posterior_state, "previous posterior state"),
            (posterior_before_previous_state, "posterior before previous state"),
            (previous_prior_state, "previous prior state"),
        ):
            _validate_float_tensor(
                value,
                name=name,
                expected_shape=(batch_size, LATENT_STATE_DIMENSION),
                reference=reference,
            )
        availability_boolean = self._availability_boolean(
            availability,
            expected_shape=(batch_size, STATION_COUNT),
            reference=reference,
        )
        self._validate_analysis_observation(
            observation,
            availability_boolean,
            expected_shape=(batch_size, STATION_COUNT),
            reference=reference,
        )
        _validate_float_tensor(
            previous_effective_observation,
            name="previous effective observation",
            expected_shape=(batch_size, STATION_COUNT),
            reference=reference,
        )

        prior_observation = self.backbone.decode(prior_state)
        safe_observation = torch.where(
            availability_boolean, observation, torch.zeros_like(observation)
        )
        observation_difference = torch.where(
            availability_boolean,
            safe_observation - previous_effective_observation,
            torch.zeros_like(observation),
        )
        innovation = torch.where(
            availability_boolean,
            safe_observation - prior_observation,
            torch.zeros_like(observation),
        )
        state_evolution = (
            previous_posterior_state - posterior_before_previous_state
        )
        previous_state_update = previous_posterior_state - previous_prior_state
        gain = self.gain_module.gain_step(
            observation_difference,
            innovation,
            state_evolution,
            previous_state_update,
            availability_boolean,
        )
        if not isinstance(gain, torch.Tensor) or gain.shape != (
            batch_size,
            LATENT_STATE_DIMENSION,
            STATION_COUNT,
        ):
            raise ValueError("gain module must return [batch,16,6]")
        if gain.dtype != reference.dtype or gain.device != reference.device:
            raise ValueError("gain dtype/device differs from the model")
        if not bool(torch.isfinite(gain).all()):
            raise ValueError("gain contains a nonfinite value")
        masked_gain = torch.where(
            availability_boolean[:, None, :], gain, torch.zeros_like(gain)
        )
        correction = torch.bmm(masked_gain, innovation.unsqueeze(-1)).squeeze(-1)
        candidate_posterior = prior_state + correction
        any_available = availability_boolean.any(dim=1, keepdim=True)
        posterior_state = torch.where(
            any_available, candidate_posterior, prior_state
        )
        effective_observation = torch.where(
            availability_boolean, safe_observation, prior_observation
        )
        return {
            "prior_observation": prior_observation,
            "posterior_state": posterior_state,
            "gain": masked_gain,
            "innovation": innovation,
            "observation_difference": observation_difference,
            "state_evolution": state_evolution,
            "previous_state_update": previous_state_update,
            "effective_observation": effective_observation,
        }

    def backbone_only_forward(
        self,
        warmup_levels: torch.Tensor,
        warmup_controls: torch.Tensor,
        analysis_controls: torch.Tensor,
        future_controls: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        """Roll the backbone through analysis and forecast without gain access."""

        initial_state = self.backbone.encode_warmup(
            warmup_levels, warmup_controls
        )
        batch_size = int(initial_state.shape[0])
        reference = self.backbone.decoder.weight
        _validate_float_tensor(
            analysis_controls,
            name="analysis controls",
            expected_shape=(batch_size, ANALYSIS_LENGTH_HOURS, CONTROL_DIMENSION),
            reference=reference,
        )
        _validate_float_tensor(
            future_controls,
            name="future controls",
            expected_shape=(batch_size, FORECAST_LENGTH_HOURS, CONTROL_DIMENSION),
            reference=reference,
        )
        current_state = initial_state
        prior_states = []
        prior_observations = []
        for hour_index in range(ANALYSIS_LENGTH_HOURS):
            current_state = self.backbone.transition_step(
                current_state, analysis_controls[:, hour_index, :]
            )
            prior_states.append(current_state)
            prior_observations.append(self.backbone.decode(current_state))
        stacked_priors = torch.stack(prior_states, dim=1)
        return {
            "analysis_prior_states": stacked_priors,
            "analysis_posterior_states": stacked_priors,
            "analysis_prior_observations": torch.stack(
                prior_observations, dim=1
            ),
            "issue_posterior_state": current_state,
            "forecasts": self.backbone.open_loop(current_state, future_controls),
        }

    def forward(
        self,
        warmup_levels: torch.Tensor,
        warmup_controls: torch.Tensor,
        analysis_observations: torch.Tensor,
        analysis_availability: torch.Tensor,
        analysis_controls: torch.Tensor,
        future_controls: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        """Run twenty-four analysis updates and twenty-four open-loop steps."""

        availability_boolean = self._validate_sequence_inputs(
            warmup_levels,
            warmup_controls,
            analysis_observations,
            analysis_availability,
            analysis_controls,
            future_controls,
        )
        current_state = self.backbone.encode_warmup(
            warmup_levels, warmup_controls
        )
        batch_size = int(current_state.shape[0])
        reference = self.backbone.decoder.weight
        self.gain_module.reset(
            batch_size, device=reference.device, dtype=reference.dtype
        )

        previous_posterior_state = current_state
        posterior_before_previous_state = current_state
        previous_prior_state = current_state
        previous_effective_observation = self.backbone.decode(current_state)
        prior_states = []
        posterior_states = []
        prior_observations = []
        gains = []
        innovations = []
        for hour_index in range(ANALYSIS_LENGTH_HOURS):
            prior_state = self.backbone.transition_step(
                previous_posterior_state,
                analysis_controls[:, hour_index, :],
            )
            result = self.analysis_step(
                prior_state,
                analysis_observations[:, hour_index, :],
                availability_boolean[:, hour_index, :],
                previous_effective_observation,
                previous_posterior_state,
                posterior_before_previous_state,
                previous_prior_state,
            )
            posterior_state = result["posterior_state"]
            prior_states.append(prior_state)
            posterior_states.append(posterior_state)
            prior_observations.append(result["prior_observation"])
            gains.append(result["gain"])
            innovations.append(result["innovation"])

            posterior_before_previous_state = previous_posterior_state
            previous_posterior_state = posterior_state
            previous_prior_state = prior_state
            previous_effective_observation = result["effective_observation"]

        return {
            "analysis_prior_states": torch.stack(prior_states, dim=1),
            "analysis_posterior_states": torch.stack(posterior_states, dim=1),
            "analysis_prior_observations": torch.stack(
                prior_observations, dim=1
            ),
            "analysis_gains": torch.stack(gains, dim=1),
            "analysis_innovations": torch.stack(innovations, dim=1),
            "issue_posterior_state": previous_posterior_state,
            "forecasts": self.backbone.open_loop(
                previous_posterior_state, future_controls
            ),
        }


def architecture_description() -> Dict[str, object]:
    """Return the frozen technical contract without loading data or KalmanNet."""

    description: Dict[str, object] = {
        "station_order": list(STATION_ORDER),
        "state_dimension": LATENT_STATE_DIMENSION,
        "state_coordinates": "sixteen wholly abstract coordinates",
        "state_contains_station_level_coordinates": False,
        "control_names": list(CONTROL_NAMES),
        "control_dimension": CONTROL_DIMENSION,
        "warmup_length_hours": WARMUP_LENGTH_HOURS,
        "analysis_length_hours": ANALYSIS_LENGTH_HOURS,
        "forecast_length_hours": FORECAST_LENGTH_HOURS,
        "observation_operator": "learned linear decoder",
        "process_cell_parameter_count": 960,
        "decoder_parameter_count": 102,
        "process_and_decoder_parameter_count": 1062,
        "future_observation_input": False,
        "formal_training_authorized": False,
    }
    assert description["state_coordinates"] == "sixteen wholly abstract coordinates"
    assert description["observation_operator"] == "learned linear decoder"
    assert description["state_contains_station_level_coordinates"] is False
    return description


def main() -> int:
    """Print the interface description; no training entry point is provided."""

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--describe",
        action="store_true",
        help="print the frozen technical interface without running training",
    )
    arguments = parser.parse_args()
    if not arguments.describe:
        parser.error("this module only supports --describe")
    print(json.dumps(architecture_description(), indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
