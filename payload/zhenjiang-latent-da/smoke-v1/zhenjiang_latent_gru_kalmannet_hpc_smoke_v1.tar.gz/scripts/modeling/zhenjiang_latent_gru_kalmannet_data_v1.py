#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Leakage-safe forty-eight-hour adapter for the latent-state prototype.

Inputs:
    An active ``OutOfYearData`` object, explicit issue records, fold-local
    station normalization, and an explicitly supplied fold astronomical-tide
    series with fold years and hashes.  The active loader's global tide member
    is not used by this adapter.

Outputs:
    Central-processing-unit tensors for the old twenty-four-hour warm-up, the
    recent twenty-four-hour analysis window, and the future twenty-four-hour
    open-loop target and control window.  This module writes no files.

Command-line arguments:
    ``--describe`` prints the frozen indexing and mask contract as JSON.

Example:
    python scripts/modeling/zhenjiang_latent_gru_kalmannet_data_v1.py --describe

Availability builders in this file are technical data-assimilation stress
patterns.  They are not the active outage study's formal target-neighbor
conditions and they never inspect target values.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime
import json
from pathlib import Path
import re
import sys
from typing import Any, Callable, Dict, Optional, Tuple, Union

import numpy as np
import torch
from torch.utils.data import Dataset


PROJECT_ROOT = Path(__file__).resolve().parents[2]
for _relative in ("scripts/modeling", "scripts/analysis"):
    _candidate = str(PROJECT_ROOT / _relative)
    if _candidate not in sys.path:
        sys.path.insert(0, _candidate)

import zhenjiang_oyv_v1_contract as contract  # noqa: E402
from zhenjiang_oyv_v1_data import OutOfYearData  # noqa: E402


STATION_COUNT = 6
WARMUP_LENGTH_HOURS = 24
ANALYSIS_LENGTH_HOURS = 24
FORECAST_LENGTH_HOURS = 24
MAIN_WINDOW_START_OFFSET = -47
MAIN_WINDOW_STOP_OFFSET = 24
TIDE_DIFFERENCE_PREFIX_OFFSET = -48
TECHNICAL_OUTAGE_DURATIONS_HOURS = (0, 1, 3, 6, 12, 24)
_LOWERCASE_HEXADECIMAL = re.compile(r"^[0-9a-f]+$")


@dataclass(frozen=True)
class LatentDAFoldNormalization:
    """Fold-training station and astronomical-tide population statistics."""

    station_mean_m: np.ndarray
    station_standard_deviation_m: np.ndarray
    tide_mean_m: float
    tide_standard_deviation_m: float


@dataclass(frozen=True)
class FoldAstronomicalTideSeries:
    """Explicit fold astronomical tide plus auditable fold/source identity."""

    values_m: np.ndarray
    test_year: int
    training_years: Tuple[int, ...]
    model_sha256: str
    series_sha256: str


@dataclass(frozen=True)
class LatentDARecord:
    """One issue position and its aligned Beijing timestamp."""

    issue_position: int
    issue_time_beijing: datetime


def _validate_digest(value: str, name: str) -> None:
    if not isinstance(value, str) or len(value) != 64:
        raise ValueError("%s must be a 64-character lowercase hexadecimal string" % name)
    if _LOWERCASE_HEXADECIMAL.fullmatch(value) is None:
        raise ValueError("%s must be lowercase hexadecimal" % name)


def _validate_fold_tide(
    fold_tide: FoldAstronomicalTideSeries, hour_count: int
) -> np.ndarray:
    """Validate fold identity and return its one-dimensional float64 values."""

    if not isinstance(fold_tide, FoldAstronomicalTideSeries):
        raise ValueError("fold astronomical tide must be supplied explicitly")
    try:
        expected_training_years = contract.training_years(int(fold_tide.test_year))
    except ValueError as error:
        raise ValueError("fold tide test year is not a candidate fold year") from error
    if tuple(fold_tide.training_years) != tuple(expected_training_years):
        raise ValueError("fold tide training years do not match its test-year fold")
    _validate_digest(fold_tide.model_sha256, "model SHA-256")
    _validate_digest(fold_tide.series_sha256, "series SHA-256")
    values = np.asarray(fold_tide.values_m, dtype=np.float64)
    if values.shape != (hour_count,):
        raise ValueError("fold tide values must match the active hourly axis")
    return values


def _validate_normalization(
    normalization: LatentDAFoldNormalization,
) -> Tuple[np.ndarray, np.ndarray]:
    if not isinstance(normalization, LatentDAFoldNormalization):
        raise ValueError("latent data-assimilation normalization is required")
    mean = np.asarray(normalization.station_mean_m, dtype=np.float64)
    scale = np.asarray(
        normalization.station_standard_deviation_m, dtype=np.float64
    )
    if mean.shape != (STATION_COUNT,) or scale.shape != (STATION_COUNT,):
        raise ValueError("station normalization must contain six values")
    if not np.isfinite(mean).all() or not np.isfinite(scale).all():
        raise ValueError("station normalization must be finite")
    if np.any(scale <= 0.0):
        raise ValueError("station standard deviations must be positive")
    if not np.isfinite(normalization.tide_mean_m) or not np.isfinite(
        normalization.tide_standard_deviation_m
    ):
        raise ValueError("tide normalization must be finite")
    if float(normalization.tide_standard_deviation_m) <= 0.0:
        raise ValueError("tide standard deviation must be positive")
    return mean, scale


def _station_index(station_index: int) -> int:
    index = int(station_index)
    if index != station_index or not 0 <= index < STATION_COUNT:
        raise ValueError("station index must be an integer from zero to five")
    return index


def all_observed_availability() -> np.ndarray:
    """Return the technical stress pattern with all six stations available."""

    return np.ones((ANALYSIS_LENGTH_HOURS, STATION_COUNT), dtype=bool)


def all_unobserved_availability() -> np.ndarray:
    """Return the technical stress pattern with all six stations unavailable."""

    return np.zeros((ANALYSIS_LENGTH_HOURS, STATION_COUNT), dtype=bool)


def one_station_only_availability(station_index: int) -> np.ndarray:
    """Return a pattern in which exactly one named-by-index station is available."""

    index = _station_index(station_index)
    availability = all_unobserved_availability()
    availability[:, index] = True
    return availability


def station_outage_availability(
    station_index: int, duration_hours: int
) -> np.ndarray:
    """Mask the most recent allowed-duration hours for one station only."""

    index = _station_index(station_index)
    duration = int(duration_hours)
    if duration != duration_hours or duration not in TECHNICAL_OUTAGE_DURATIONS_HOURS:
        raise ValueError(
            "outage duration must be one of %s"
            % (TECHNICAL_OUTAGE_DURATIONS_HOURS,)
        )
    availability = all_observed_availability()
    if duration:
        availability[-duration:, index] = False
    return availability


def accepted_latent_da_records(
    data: OutOfYearData, allowed_years: Tuple[int, ...]
) -> Tuple[LatentDARecord, ...]:
    """Apply the active acceptance positions plus the wider frozen window.

    Every returned record has finite six-station levels from ``t-47`` through
    ``t``, finite retrospective targets from ``t+1`` through ``t+24``, an
    addressable tide prefix at ``t-48``, and a main window wholly inside one
    allowed calendar year.  Tide values themselves are checked only after an
    explicit fold series is supplied to the dataset.
    """

    allowed = tuple(int(year) for year in allowed_years)
    if not allowed or len(set(allowed)) != len(allowed):
        raise ValueError("allowed years must be a nonempty unique tuple")
    hour_count = len(data.times_beijing)
    stages = np.asarray(data.stages_m)
    targets = np.asarray(data.targets_m)
    years = np.asarray(data.hour_year, dtype=np.int64)
    if stages.shape != (hour_count, STATION_COUNT) or targets.shape != (
        hour_count,
        STATION_COUNT,
    ):
        raise ValueError("active stage or target arrays have the wrong shape")

    records = []
    for raw_position in np.asarray(data.accepted_positions, dtype=np.int64):
        position = int(raw_position)
        if position + TIDE_DIFFERENCE_PREFIX_OFFSET < 0:
            continue
        if position + MAIN_WINDOW_STOP_OFFSET >= hour_count:
            continue
        main_slice = slice(
            position + MAIN_WINDOW_START_OFFSET,
            position + MAIN_WINDOW_STOP_OFFSET + 1,
        )
        window_years = years[main_slice]
        if window_years.size != 72 or not np.all(window_years == window_years[0]):
            continue
        if int(window_years[0]) not in allowed:
            continue
        history = stages[position - 47 : position + 1]
        future_targets = targets[position + 1 : position + 25]
        if history.shape != (48, STATION_COUNT) or future_targets.shape != (
            24,
            STATION_COUNT,
        ):
            continue
        if not np.isfinite(history).all() or not np.isfinite(future_targets).all():
            continue
        records.append(
            LatentDARecord(position, data.times_beijing[position])
        )
    return tuple(records)


def fit_latent_da_normalization(
    data: OutOfYearData,
    training_records: Tuple[LatentDARecord, ...],
    fold_tide: FoldAstronomicalTideSeries,
) -> LatentDAFoldNormalization:
    """Fit float64 population statistics on training-record inputs only.

    Station statistics use each record's forty-eight real-time stage hours.
    Tide statistics use each record's seventy-two explicitly supplied tide
    hours.  Retrospective future targets are never read by this function.
    """

    if not training_records:
        raise ValueError("at least one training record is required")
    hour_count = len(data.times_beijing)
    tide_values = _validate_fold_tide(fold_tide, hour_count)
    positions = np.asarray(
        [int(record.issue_position) for record in training_records],
        dtype=np.int64,
    )
    if positions.min() < 47 or positions.max() + 24 >= hour_count:
        raise ValueError("a training record lies outside the frozen window")
    if not np.isin(
        positions, np.asarray(data.accepted_positions, dtype=np.int64)
    ).all():
        raise ValueError("a training record is not accepted by the active loader")
    for record in training_records:
        position = int(record.issue_position)
        if data.times_beijing[position] != record.issue_time_beijing:
            raise ValueError("training record time does not match its issue position")
        if int(data.hour_year[position]) not in fold_tide.training_years:
            raise ValueError("a training record is outside the fold training years")

    stage_positions = positions[:, None] + np.arange(-47, 1, dtype=np.int64)[None, :]
    tide_positions = positions[:, None] + np.arange(-47, 25, dtype=np.int64)[None, :]
    main_years = np.asarray(data.hour_year, dtype=np.int64)[tide_positions]
    if not np.all(main_years == main_years[:, :1]):
        raise ValueError("each training main window must remain in a single calendar year")
    if not np.isin(
        main_years, np.asarray(fold_tide.training_years, dtype=np.int64)
    ).all():
        raise ValueError("a training main window leaves the fold training years")
    stages = np.asarray(data.stages_m, dtype=np.float64)[stage_positions]
    selected_tide = tide_values[tide_positions]
    if not np.isfinite(stages).all():
        raise ValueError("a training stage window contains a nonfinite value")
    if not np.isfinite(selected_tide).all():
        raise ValueError("a training tide window contains a nonfinite value")

    station_mean = np.mean(stages, axis=(0, 1), dtype=np.float64)
    station_scale = np.std(
        stages, axis=(0, 1), ddof=0, dtype=np.float64
    )
    tide_mean = float(np.mean(selected_tide, dtype=np.float64))
    tide_scale = float(np.std(selected_tide, ddof=0, dtype=np.float64))
    if np.any(station_scale <= 0.0) or tide_scale <= 0.0:
        raise ValueError("normalization standard deviations must be positive")
    return LatentDAFoldNormalization(
        station_mean_m=station_mean,
        station_standard_deviation_m=station_scale,
        tide_mean_m=tide_mean,
        tide_standard_deviation_m=tide_scale,
    )


AvailabilitySpecification = Union[
    np.ndarray,
    torch.Tensor,
    Callable[[LatentDARecord], Union[np.ndarray, torch.Tensor]],
]


class LatentDAWindowDataset(Dataset):
    """Build one frozen warm-up, analysis, and forecast tensor dictionary."""

    def __init__(
        self,
        data: OutOfYearData,
        records: Tuple[LatentDARecord, ...],
        fold_tide: FoldAstronomicalTideSeries,
        normalization: LatentDAFoldNormalization,
        *,
        analysis_availability: Optional[AvailabilitySpecification] = None,
    ) -> None:
        self.data = data
        self.records = tuple(records)
        self.fold_tide = fold_tide
        self.tide_values = _validate_fold_tide(
            fold_tide, len(data.times_beijing)
        )
        self.station_mean, self.station_scale = _validate_normalization(
            normalization
        )
        self.normalization = normalization
        self.analysis_availability = (
            all_observed_availability()
            if analysis_availability is None
            else analysis_availability
        )
        for record in self.records:
            position = int(record.issue_position)
            if position < 48 or position + 24 >= len(data.times_beijing):
                raise ValueError("a dataset record lies outside the frozen window")
            if data.times_beijing[position] != record.issue_time_beijing:
                raise ValueError("dataset record time does not match issue position")

    def __len__(self) -> int:
        return len(self.records)

    def _availability_for(self, record: LatentDARecord) -> np.ndarray:
        specification = self.analysis_availability
        raw = specification(record) if callable(specification) else specification
        if isinstance(raw, torch.Tensor):
            raw = raw.detach().cpu().numpy()
        availability = np.asarray(raw)
        if availability.shape != (ANALYSIS_LENGTH_HOURS, STATION_COUNT):
            raise ValueError("analysis availability must be [24,6]")
        if availability.dtype != np.bool_:
            if not np.isfinite(availability).all() or not np.all(
                (availability == 0) | (availability == 1)
            ):
                raise ValueError("analysis availability must contain only zero or one")
        return availability.astype(bool, copy=True)

    def __getitem__(self, index: int) -> Dict[str, Any]:
        """Return one sample; apply controlled missingness after normalization."""

        record = self.records[index]
        position = int(record.issue_position)
        stages = np.asarray(self.data.stages_m, dtype=np.float64)
        targets = np.asarray(self.data.targets_m, dtype=np.float64)
        warmup_raw = stages[position - 47 : position - 23]
        analysis_raw = stages[position - 23 : position + 1]
        future_raw = targets[position + 1 : position + 25]
        if (
            warmup_raw.shape != (24, 6)
            or analysis_raw.shape != (24, 6)
            or future_raw.shape != (24, 6)
        ):
            raise ValueError("level windows do not match the frozen lengths")
        if not np.isfinite(warmup_raw).all() or not np.isfinite(analysis_raw).all():
            raise ValueError("a stage window contains a nonfinite value")
        if not np.isfinite(future_raw).all():
            raise ValueError("a future target window contains a nonfinite value")

        tide_window = self.tide_values[position - 48 : position + 25]
        if tide_window.shape != (73,) or not np.isfinite(tide_window).all():
            raise ValueError("the required tide window is wrong or nonfinite")
        standardized_tide = (
            tide_window - float(self.normalization.tide_mean_m)
        ) / float(self.normalization.tide_standard_deviation_m)
        main_tide = standardized_tide[1:]
        tide_difference = np.diff(standardized_tide)
        controls = np.stack((main_tide, tide_difference), axis=-1)

        warmup_levels = (warmup_raw - self.station_mean) / self.station_scale
        analysis_targets = (analysis_raw - self.station_mean) / self.station_scale
        future_targets = (future_raw - self.station_mean) / self.station_scale
        availability = self._availability_for(record)
        analysis_observations = analysis_targets.copy()
        analysis_observations[~availability] = np.nan

        return {
            "warmup_levels": torch.from_numpy(
                warmup_levels.astype(np.float32)
            ),
            "warmup_controls": torch.from_numpy(controls[:24].astype(np.float32)),
            "analysis_observations": torch.from_numpy(
                analysis_observations.astype(np.float32)
            ),
            "analysis_targets": torch.from_numpy(
                analysis_targets.astype(np.float32)
            ),
            "analysis_availability": torch.from_numpy(availability),
            "analysis_controls": torch.from_numpy(
                controls[24:48].astype(np.float32)
            ),
            "future_controls": torch.from_numpy(
                controls[48:72].astype(np.float32)
            ),
            "future_targets": torch.from_numpy(future_targets.astype(np.float32)),
            "issue_time_beijing": record.issue_time_beijing,
            "issue_position": position,
        }


def data_contract_description() -> Dict[str, object]:
    return {
        "warmup_offsets": [-47, -24],
        "analysis_offsets": [-23, 0],
        "forecast_offsets": [1, 24],
        "tide_difference_prefix_offset": -48,
        "station_normalization_shared_across_all_level_roles": True,
        "fold_astronomical_tide_required_explicitly": True,
        "technical_outage_durations_hours": list(
            TECHNICAL_OUTAGE_DURATIONS_HOURS
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--describe", action="store_true")
    arguments = parser.parse_args()
    if not arguments.describe:
        parser.error("this adapter only supports --describe")
    print(json.dumps(data_contract_description(), indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
