#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Validate the one registered high-performance-computing smoke experiment.

Inputs:
    An immutable JSON configuration and the experiment registry containing its
    exact Secure Hash Algorithm 256-bit digest.

Outputs:
    A validated configuration dictionary.  This module writes no files and
    does not load station data, model checkpoints, or held-out targets.

Command-line arguments:
    ``--config`` and ``--registry`` print the validated registration as JSON.

Example:
    python scripts/modeling/zhenjiang_latent_gru_kalmannet_experiment_v1.py --config docs/records/ZHENJIANG_LATENT_GRU_KALMANNET_HPC_SMOKE_V1_CONFIG.json --registry docs/records/ZHENJIANG_LATENT_GRU_KALMANNET_EXPERIMENT_REGISTRY_V1.json
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, Mapping


SMOKE_EXPERIMENT_ID = "ZLDA-SMOKE-01"
SMOKE_EXPERIMENT_TYPE = "technical_hpc_real_data_smoke"
SMOKE_OUTPUT_RELATIVE_PATH = (
    "results/runtime/zhenjiang_latent_gru_kalmannet_hpc_smoke_v1/"
    "ZLDA-SMOKE-01"
)
SMOKE_AVAILABILITY_MODE = "cyclic_one_station_only"
ALLOWED_REGISTRY_STATUSES = (
    "authorized_not_submitted",
    "submitted",
    "technical_pass",
    "technical_fail",
)
EXPECTED_TOP_LEVEL_KEYS = {
    "availability",
    "experiment_id",
    "experiment_type",
    "output_relative_path",
    "schema_version",
    "scientific_result",
    "seed",
    "test_split_access",
    "test_year",
    "training",
}
EXPECTED_TRAINING_KEYS = {
    "adam_betas",
    "adam_epsilon",
    "batch_size",
    "gradient_clip_norm",
    "stage_one",
    "stage_two",
}
EXPECTED_STAGE_KEYS = {
    "learning_rate",
    "maximum_epochs",
    "maximum_training_batches_per_epoch",
    "maximum_validation_batches",
    "weight_decay",
}


def sha256_bytes(value: bytes) -> str:
    """Return the lowercase Secure Hash Algorithm 256-bit digest."""

    return hashlib.sha256(value).hexdigest()


def _require_exact_keys(
    value: Mapping[str, object], expected: set[str], name: str
) -> None:
    observed = set(value)
    if observed != expected:
        raise ValueError(
            "%s keys differ: missing=%s extra=%s"
            % (name, sorted(expected - observed), sorted(observed - expected))
        )


def _positive_number(value: object, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("%s must be numeric" % name)
    parsed = float(value)
    if not parsed > 0.0:
        raise ValueError("%s must be positive" % name)
    return parsed


def _bounded_positive_integer(value: object, maximum: int, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError("%s must be an integer" % name)
    if not 1 <= value <= maximum:
        raise ValueError("%s must lie from one through %d" % (name, maximum))
    return int(value)


def validate_smoke_config(config: Mapping[str, object]) -> Dict[str, Any]:
    """Validate the fixed technical-smoke safety and resource ceilings."""

    if not isinstance(config, Mapping):
        raise ValueError("smoke configuration must be a mapping")
    _require_exact_keys(config, EXPECTED_TOP_LEVEL_KEYS, "smoke configuration")
    if config["schema_version"] != 1:
        raise ValueError("smoke schema version must equal one")
    if config["experiment_id"] != SMOKE_EXPERIMENT_ID:
        raise ValueError("smoke experiment identifier changed")
    if config["experiment_type"] != SMOKE_EXPERIMENT_TYPE:
        raise ValueError("experiment type is not the technical real-data smoke")
    if config["scientific_result"] is not False:
        raise ValueError("technical smoke cannot be marked as a scientific result")
    if config["test_split_access"] != "forbidden":
        raise ValueError("test split access must remain forbidden")
    if config["test_year"] != 2024:
        raise ValueError("technical smoke test year must remain 2024")
    if config["seed"] != 20260827:
        raise ValueError("technical smoke seed changed")
    if config["output_relative_path"] != SMOKE_OUTPUT_RELATIVE_PATH:
        raise ValueError("technical smoke output path changed")

    availability = config["availability"]
    if not isinstance(availability, Mapping):
        raise ValueError("availability must be a mapping")
    _require_exact_keys(
        availability,
        {
            "available_station_count_per_sample",
            "mode",
            "observed_station_hours",
        },
        "availability",
    )
    if availability["mode"] != SMOKE_AVAILABILITY_MODE:
        raise ValueError("availability mode changed")
    if availability["available_station_count_per_sample"] != 1:
        raise ValueError("technical smoke must expose one station per sample")
    if availability["observed_station_hours"] != 24:
        raise ValueError("technical smoke must expose that station for 24 hours")

    training = config["training"]
    if not isinstance(training, Mapping):
        raise ValueError("training must be a mapping")
    _require_exact_keys(training, EXPECTED_TRAINING_KEYS, "training")
    _bounded_positive_integer(training["batch_size"], 32, "batch size")
    _positive_number(training["gradient_clip_norm"], "gradient clip norm")
    betas = training["adam_betas"]
    if not isinstance(betas, list) or betas != [0.9, 0.999]:
        raise ValueError("Adam beta values changed")
    if _positive_number(training["adam_epsilon"], "Adam epsilon") != 1.0e-8:
        raise ValueError("Adam epsilon changed")

    for stage_name in ("stage_one", "stage_two"):
        stage = training[stage_name]
        if not isinstance(stage, Mapping):
            raise ValueError("%s must be a mapping" % stage_name)
        _require_exact_keys(stage, EXPECTED_STAGE_KEYS, stage_name)
        _bounded_positive_integer(stage["maximum_epochs"], 1, "maximum epochs")
        _bounded_positive_integer(
            stage["maximum_training_batches_per_epoch"],
            2,
            "maximum training batches per epoch",
        )
        _bounded_positive_integer(
            stage["maximum_validation_batches"],
            2,
            "maximum validation batches",
        )
        if _positive_number(stage["learning_rate"], "learning rate") != 0.001:
            raise ValueError("learning rate changed")
        if _positive_number(stage["weight_decay"], "weight decay") != 0.0001:
            raise ValueError("weight decay changed")
    return dict(config)


def load_registered_smoke_config(
    config_path: Path, registry_path: Path
) -> Dict[str, Any]:
    """Load the config only when one unique registry row pins its bytes."""

    config_path = Path(config_path)
    registry_path = Path(registry_path)
    config_bytes = config_path.read_bytes()
    config = json.loads(config_bytes.decode("utf-8"))
    validated = validate_smoke_config(config)
    registry = json.loads(registry_path.read_text(encoding="utf-8"))
    if registry.get("schema_version") != 1:
        raise ValueError("experiment registry schema version must equal one")
    rows = registry.get("experiments")
    if not isinstance(rows, list):
        raise ValueError("experiment registry must contain an experiments list")
    matches = [row for row in rows if row.get("exp_id") == SMOKE_EXPERIMENT_ID]
    if len(matches) != 1:
        raise ValueError("experiment registry must contain one smoke row")
    row = matches[0]
    if row.get("type") != SMOKE_EXPERIMENT_TYPE:
        raise ValueError("registered experiment type changed")
    if row.get("run_dir") != SMOKE_OUTPUT_RELATIVE_PATH:
        raise ValueError("registered output path changed")
    if row.get("status") not in ALLOWED_REGISTRY_STATUSES:
        raise ValueError("registered smoke status is invalid")
    observed_digest = sha256_bytes(config_bytes)
    if row.get("config_sha256") != observed_digest:
        raise ValueError("registered configuration SHA-256 mismatch")
    return validated


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--registry", type=Path, required=True)
    arguments = parser.parse_args()
    config = load_registered_smoke_config(arguments.config, arguments.registry)
    print(json.dumps(config, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
