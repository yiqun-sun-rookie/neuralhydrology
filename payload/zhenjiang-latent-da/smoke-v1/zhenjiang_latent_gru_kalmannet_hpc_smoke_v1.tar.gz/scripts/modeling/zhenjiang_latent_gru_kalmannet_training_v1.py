#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Staged-loss utilities and a strict safety gate for the latent prototype.

Inputs:
    Synthetic or separately constructed standardized batches matching the
    frozen warm-up, analysis, and future windows.  A real external KalmanNet
    source is optional for ``--describe`` and must be supplied explicitly.

Outputs:
    Pure loss tensors, trainable-parameter-name tuples, JSON descriptions, or a
    synthetic central-processing-unit dry-run report.  No checkpoints, result
    tables, or training data are read or written by this file.

Command-line arguments:
    ``--describe`` prints model and stage metadata; ``--dry-run`` performs one
    synthetic central-processing-unit forward/backward pass; ``--stage`` selects
    backbone pretraining or gain training; ``--kalmannet-source`` is an explicit
    external file path; and ``--allow-training`` is the mandatory safety token
    for any future substantive training request.

Example:
    python scripts/modeling/zhenjiang_latent_gru_kalmannet_training_v1.py --dry-run --stage pretrain_backbone

The current command does not implement substantive training even when the
safety token is supplied.  Technical loss or gradient checks do not establish
forecast benefit or scientific success.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, Union

import torch
from torch import nn

from zhenjiang_kalmannet_gain_adapter_v1 import PinnedKalmanNetGainAdapter
from zhenjiang_latent_gru_kalmannet_v1 import (
    ANALYSIS_LENGTH_HOURS,
    CONTROL_DIMENSION,
    FORECAST_LENGTH_HOURS,
    LATENT_STATE_DIMENSION,
    STATION_COUNT,
    WARMUP_LENGTH_HOURS,
    AvailabilityGatedLatentGRUKalmanNet,
    architecture_description,
)


PRETRAIN_BACKBONE = "pretrain_backbone"
TRAIN_GAIN = "train_gain"
TRAINING_STAGES = (PRETRAIN_BACKBONE, TRAIN_GAIN)
SMOOTH_ABSOLUTE_ERROR_TRANSITION_M = 0.10
STATION_LOSS_WEIGHTS = (1.0, 1.0, 1.0, 1.0, 1.0, 1.0)


class SyntheticLearnedGain(nn.Module):
    """Small deterministic learned-gain test double for synthetic dry runs."""

    def __init__(self) -> None:
        super().__init__()
        self.raw_gain = nn.Parameter(
            torch.full(
                (LATENT_STATE_DIMENSION, STATION_COUNT),
                0.01,
                dtype=torch.float32,
            )
        )
        self._batch_size = 0

    def reset(
        self, batch_size: int, *, device: torch.device, dtype: torch.dtype
    ) -> None:
        if int(batch_size) < 1:
            raise ValueError("batch size must be positive")
        if self.raw_gain.device != torch.device(device) or self.raw_gain.dtype != dtype:
            raise ValueError("synthetic gain dtype/device differs from the model")
        self._batch_size = int(batch_size)

    def gain_step(
        self,
        observation_difference: torch.Tensor,
        observation_innovation: torch.Tensor,
        state_evolution: torch.Tensor,
        previous_state_update: torch.Tensor,
        availability: torch.Tensor,
    ) -> torch.Tensor:
        if self._batch_size != observation_difference.shape[0]:
            raise RuntimeError("synthetic gain must be reset for the current batch")
        gain = torch.tanh(self.raw_gain).unsqueeze(0).expand(
            self._batch_size, -1, -1
        )
        return torch.where(
            availability[:, None, :], gain, torch.zeros_like(gain)
        )


def metre_space_smooth_absolute_error(
    prediction_standardized: torch.Tensor,
    target_standardized: torch.Tensor,
    station_standard_deviation_m: torch.Tensor,
) -> torch.Tensor:
    """Return equal-station smooth absolute error after metre conversion.

    Inputs:
        Prediction and target tensors are ``[batch,24,6]`` standardized values.
        The six station standard deviations convert their difference to metres.

    Outputs:
        One scalar mean with a fixed 0.10-metre quadratic-to-linear transition.
    """

    if (
        not isinstance(prediction_standardized, torch.Tensor)
        or prediction_standardized.ndim != 3
        or prediction_standardized.shape[1:] != (24, STATION_COUNT)
        or target_standardized.shape != prediction_standardized.shape
    ):
        raise ValueError("prediction and target must be [batch,24,6]")
    if prediction_standardized.shape[0] < 1:
        raise ValueError("loss batch must contain at least one sample")
    if prediction_standardized.dtype != torch.float32 or target_standardized.dtype != torch.float32:
        raise ValueError("prediction and target must use float32")
    if prediction_standardized.device != target_standardized.device:
        raise ValueError("prediction and target must use the same device")
    scale = torch.as_tensor(
        station_standard_deviation_m,
        dtype=prediction_standardized.dtype,
        device=prediction_standardized.device,
    )
    if scale.shape != (STATION_COUNT,):
        raise ValueError("station standard deviation must be [6]")
    if not bool(torch.isfinite(prediction_standardized).all()) or not bool(
        torch.isfinite(target_standardized).all()
    ) or not bool(torch.isfinite(scale).all()):
        raise ValueError("loss input contains a nonfinite value")
    if bool((scale <= 0.0).any()):
        raise ValueError("station standard deviations must be positive")
    error_m = (prediction_standardized - target_standardized) * scale[
        None, None, :
    ]
    absolute_error_m = torch.abs(error_m)
    transition = SMOOTH_ABSOLUTE_ERROR_TRANSITION_M
    element_loss = torch.where(
        absolute_error_m < transition,
        0.5 * absolute_error_m.square() / transition,
        absolute_error_m - 0.5 * transition,
    )
    weights = torch.as_tensor(
        STATION_LOSS_WEIGHTS,
        dtype=prediction_standardized.dtype,
        device=prediction_standardized.device,
    )
    denominator = (
        prediction_standardized.shape[0]
        * prediction_standardized.shape[1]
        * torch.sum(weights)
    )
    return torch.sum(element_loss * weights[None, None, :]) / denominator


def configure_training_stage(
    model: AvailabilityGatedLatentGRUKalmanNet,
    stage: str,
) -> Tuple[str, ...]:
    """Mechanically isolate trainable parameters for one frozen stage."""

    if stage not in TRAINING_STAGES:
        raise ValueError("unsupported training stage: %s" % stage)
    train_backbone = stage == PRETRAIN_BACKBONE
    for parameter in model.backbone.parameters():
        parameter.requires_grad_(train_backbone)
        parameter.grad = None
    for parameter in model.gain_module.parameters():
        parameter.requires_grad_(not train_backbone)
        parameter.grad = None
    return tuple(
        name for name, parameter in model.named_parameters() if parameter.requires_grad
    )


def forward_for_training_stage(
    model: AvailabilityGatedLatentGRUKalmanNet,
    batch: Dict[str, torch.Tensor],
    stage: str,
) -> Dict[str, torch.Tensor]:
    """Dispatch stage one to the pure backbone and stage two to assimilation."""

    if stage == PRETRAIN_BACKBONE:
        return model.backbone_only_forward(
            batch["warmup_levels"],
            batch["warmup_controls"],
            batch["analysis_controls"],
            batch["future_controls"],
        )
    if stage == TRAIN_GAIN:
        return model(
            batch["warmup_levels"],
            batch["warmup_controls"],
            batch["analysis_observations"],
            batch["analysis_availability"],
            batch["analysis_controls"],
            batch["future_controls"],
        )
    raise ValueError("unsupported training stage: %s" % stage)


def compute_stage_loss(
    model_output: Dict[str, torch.Tensor],
    batch: Dict[str, torch.Tensor],
    station_standard_deviation_m: torch.Tensor,
    stage: str,
) -> torch.Tensor:
    """Compute the frozen objective for one isolated training stage."""

    if stage == PRETRAIN_BACKBONE:
        analysis_loss = metre_space_smooth_absolute_error(
            model_output["analysis_prior_observations"],
            batch["analysis_targets"],
            station_standard_deviation_m,
        )
        future_loss = metre_space_smooth_absolute_error(
            model_output["forecasts"],
            batch["future_targets"],
            station_standard_deviation_m,
        )
        return 0.5 * analysis_loss + 0.5 * future_loss
    if stage == TRAIN_GAIN:
        return metre_space_smooth_absolute_error(
            model_output["forecasts"],
            batch["future_targets"],
            station_standard_deviation_m,
        )
    raise ValueError("unsupported training stage: %s" % stage)


def _build_model(
    kalmannet_source: Optional[Union[str, Path]] = None,
) -> AvailabilityGatedLatentGRUKalmanNet:
    gain_module: nn.Module
    if kalmannet_source is None:
        gain_module = SyntheticLearnedGain()
    else:
        gain_module = PinnedKalmanNetGainAdapter(kalmannet_source)
    return AvailabilityGatedLatentGRUKalmanNet(gain_module)


def model_and_stage_description(
    stage: str,
    *,
    kalmannet_source: Optional[Union[str, Path]] = None,
    formal_training_authorized: bool = False,
) -> Dict[str, Any]:
    """Return frozen dimensions, source identity, and trainable parameter names."""

    model = _build_model(kalmannet_source)
    trainable_names = configure_training_stage(model, stage)
    source_identity = (
        model.gain_module.source_identity()
        if isinstance(model.gain_module, PinnedKalmanNetGainAdapter)
        else None
    )
    description = dict(architecture_description())
    description.update(
        {
            "stage": stage,
            "time_windows_hours": {
                "warmup": WARMUP_LENGTH_HOURS,
                "analysis": ANALYSIS_LENGTH_HOURS,
                "forecast": FORECAST_LENGTH_HOURS,
            },
            "external_kalmannet_source": source_identity,
            "trainable_parameter_names": list(trainable_names),
            "formal_training_authorized": bool(formal_training_authorized),
        }
    )
    return description


def _synthetic_batch(batch_size: int = 2) -> Dict[str, torch.Tensor]:
    torch.manual_seed(20260827)
    return {
        "warmup_levels": torch.randn(batch_size, 24, 6, device="cpu"),
        "warmup_controls": torch.randn(batch_size, 24, 2, device="cpu"),
        "analysis_observations": torch.randn(batch_size, 24, 6, device="cpu"),
        "analysis_targets": torch.randn(batch_size, 24, 6, device="cpu"),
        "analysis_availability": torch.ones(
            batch_size, 24, 6, dtype=torch.bool, device="cpu"
        ),
        "analysis_controls": torch.randn(batch_size, 24, 2, device="cpu"),
        "future_controls": torch.randn(batch_size, 24, 2, device="cpu"),
        "future_targets": torch.randn(batch_size, 24, 6, device="cpu"),
    }


def synthetic_cpu_dry_run(stage: str) -> Dict[str, Any]:
    """Run one synthetic central-processing-unit forward and backward pass."""

    model = _build_model().to(device=torch.device("cpu"), dtype=torch.float32)
    trainable_names = configure_training_stage(model, stage)
    batch = _synthetic_batch()
    output = forward_for_training_stage(model, batch, stage)
    loss = compute_stage_loss(output, batch, torch.ones(6), stage)
    loss.backward()
    return {
        "stage": stage,
        "device": "cpu",
        "synthetic_tensors_only": True,
        "formal_training_authorized": False,
        "loss": float(loss.detach().cpu()),
        "loss_is_finite": bool(torch.isfinite(loss).item()),
        "trainable_parameter_names": list(trainable_names),
    }


def main() -> int:
    """Provide descriptions and synthetic checks while gating real training."""

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--describe", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--stage", choices=TRAINING_STAGES, default=PRETRAIN_BACKBONE)
    parser.add_argument("--kalmannet-source", type=Path)
    parser.add_argument("--allow-training", action="store_true")
    arguments = parser.parse_args()
    if arguments.describe and arguments.dry_run:
        parser.error("--describe and --dry-run are mutually exclusive")
    if arguments.describe:
        print(
            json.dumps(
                model_and_stage_description(
                    arguments.stage,
                    kalmannet_source=arguments.kalmannet_source,
                    formal_training_authorized=arguments.allow_training,
                ),
                indent=2,
                sort_keys=True,
            )
        )
        return 0
    if arguments.dry_run:
        print(json.dumps(synthetic_cpu_dry_run(arguments.stage), indent=2, sort_keys=True))
        return 0
    if not arguments.allow_training:
        parser.error(
            "substantive training is blocked; an approved future run must pass --allow-training"
        )
    parser.error(
        "formal training orchestration is not implemented in this technical prototype"
    )
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
