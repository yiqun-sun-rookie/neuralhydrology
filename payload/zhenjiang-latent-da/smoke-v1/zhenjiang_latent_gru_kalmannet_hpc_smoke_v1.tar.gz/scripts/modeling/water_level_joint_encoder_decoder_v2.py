#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Core data and model definitions for joint six-station forecasting.

This module contains no training command and writes no results. The public
clock is Beijing time; only the frozen astronomical-tide calculation receives
a naive coordinated-universal-time copy.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import hashlib
import io
from itertools import islice, zip_longest
import json
import math
from pathlib import Path
import sys
from typing import Sequence

import numpy as np
import torch
from torch import nn
from torch.utils.data import Dataset


PROJECT_ROOT = Path(__file__).resolve().parents[2]
ASTRONOMICAL_TIDE_DIR = PROJECT_ROOT / "scripts" / "astronomical_tide"
if str(ASTRONOMICAL_TIDE_DIR) not in sys.path:
    sys.path.insert(0, str(ASTRONOMICAL_TIDE_DIR))

from wusongkou_astronomical_tide_realtime_v2 import (  # noqa: E402
    ASTRONOMICAL_REFERENCE_BEIJING,
    ASTRONOMICAL_REFERENCE_UTC_NAIVE,
    EXPECTED_ASTRONOMICAL_DEPENDENCIES,
    EXPECTED_TIDE_MODEL_SHA256,
    FrozenAstronomicalTide,
    InputContentIdentity,
    beijing_to_astronomical_utc,
    load_frozen_astronomical_tide,
)


UTC = timezone.utc
BEIJING = timezone(timedelta(hours=8))
STATION_ORDER = (
    "datong",
    "nanjing",
    "zhenjiang",
    "jiangyin",
    "xuliujing",
    "wusongkou",
)
INPUT_LENGTH_HOURS = 24
FORECAST_LENGTH_HOURS = 24
TRAIN_START = datetime(2017, 1, 1, 0, tzinfo=BEIJING)
TRAIN_END = datetime(2022, 12, 31, 23, tzinfo=BEIJING)
VALIDATION_START = datetime(2023, 1, 1, 0, tzinfo=BEIJING)
VALIDATION_END = datetime(2023, 12, 31, 23, tzinfo=BEIJING)
TEST_START = datetime(2024, 1, 1, 0, tzinfo=BEIJING)
EXPECTED_TRAINING_SAMPLES = 46182
EXPECTED_VALIDATION_SAMPLES = 8046
EXPECTED_CONTRACT_ROWS = 61344
SMOOTH_ABSOLUTE_ERROR_TRANSITION_M = 0.10
STATION_LOSS_WEIGHTS = (1.0, 1.0, 2.0, 1.0, 1.0, 1.0)
TRANSFORMER_DROPOUT = 0.10
INPUT_DATASET_VERSION = "water_level_model_input_v7_beijing_realtime_verified"
DEFAULT_INPUT_DIR = Path(
    "data/processed/water_level_model_input_v7_beijing_realtime_verified"
)
DEFAULT_TIDE_MODEL_PATH = Path(
    "results/modeling/wusongkou_astronomical_tide_v1_validation/tide_model.json"
)
SOURCE_ROWS_BEFORE_TRAIN_START = {
    "datong": 0,
    "nanjing": 0,
    "zhenjiang": 0,
    "jiangyin": 0,
    "xuliujing": 0,
    "wusongkou": 0,
}
EXPECTED_INPUT_CONTENT_IDENTITIES = {
    "dataset_config.json": (
        "full_file", 2854,
        "63b2d3a33b249e1f598db2a1ffb2096c9d9006b366e4e913d594f74a6881d492",
    ),
    "realtime_features/datong_realtime_features.csv": (
        "header_plus_61344_rows", 5485506,
        "2024937a062df6df6d09eca8789e29aaf85e8734688836f702a3e37f8046e65c",
    ),
    "realtime_features/nanjing_realtime_features.csv": (
        "header_plus_61344_rows", 5452340,
        "405efee1787da935392c2175f9cd7dde5dd8a0a2b7960005ced76723c5ea94f9",
    ),
    "realtime_features/zhenjiang_realtime_features.csv": (
        "header_plus_61344_rows", 5490493,
        "fc35c509496d00599e85e021cfc7231a4f7201a750a3d444332daca746b7fa6b",
    ),
    "realtime_features/jiangyin_realtime_features.csv": (
        "header_plus_61344_rows", 5451807,
        "b3c3ccc8815cf7062f4d0858084c120daa42f5a00459ae885a230afc81821485",
    ),
    "realtime_features/xuliujing_realtime_features.csv": (
        "header_plus_61344_rows", 5452448,
        "23ae019c407523493d475a7d1119177d152877fc3359de3d4943a63134d6133a",
    ),
    "realtime_features/wusongkou_realtime_features.csv": (
        "header_plus_61344_rows", 5449542,
        "43d62a572c81f5f2e14b732022947cb4eeca32b8654d813ed34722f511a27316",
    ),
    "retrospective_targets/datong_retrospective_targets.csv": (
        "header_plus_61344_rows", 5486449,
        "94eb206cbd5b279c0f95bfc3d4642ad27947e2596d2f0242c0d23938a8ac8508",
    ),
    "retrospective_targets/nanjing_retrospective_targets.csv": (
        "header_plus_61344_rows", 5453455,
        "a9c650aef6b232baa423d2d2cdd1e2b30981608aca42e292fb944994f2b60f55",
    ),
    "retrospective_targets/zhenjiang_retrospective_targets.csv": (
        "header_plus_61344_rows", 5491015,
        "abb38bd543989c0fd0c17f597a36a33799c7816bdad021c9b36268322b169946",
    ),
    "retrospective_targets/jiangyin_retrospective_targets.csv": (
        "header_plus_61344_rows", 5452821,
        "5c07b7b61e1cf8301adcc9268d1a73fa5957ec2f1acdc86832dae3eb3dff5e76",
    ),
    "retrospective_targets/xuliujing_retrospective_targets.csv": (
        "header_plus_61344_rows", 5453528,
        "b676d2ca3e2f5af64c6eeb690fe39b77e9de25a96ab023a35e08fa60044a554a",
    ),
    "retrospective_targets/wusongkou_retrospective_targets.csv": (
        "header_plus_61344_rows", 5450428,
        "c5f40cc38ffc9874004efb9bc0837ac8a35d37c729891ee08657bf3d28dd95c5",
    ),
}
FEATURE_FIELDS = [
    "TIME",
    "STAGE",
    "time_beijing",
    "time_utc",
    "is_missing_for_model",
]
TARGET_FIELDS = [
    "TIME",
    "TARGET_STAGE",
    "time_beijing",
    "time_utc",
    "is_missing_for_target",
]


@dataclass(frozen=True)
class SampleRecord:
    """One accepted issue position and its Beijing issue time."""

    issue_position: int
    issue_time_beijing: datetime


@dataclass(frozen=True)
class StationReadAudit:
    """Observed feature and target reading boundaries for one station."""

    station_slug: str
    contract_target_rows_read: int
    last_target_time_beijing: datetime
    test_feature_rows_read: int
    test_target_rows_read: int
    test_target_values_parsed: int
    test_target_values_loaded: int


@dataclass(frozen=True)
class NormalizationStatistics:
    """Training-period-only statistics for the three numeric data groups."""

    input_mean_m: np.ndarray
    input_standard_deviation_m: np.ndarray
    target_mean_m: np.ndarray
    target_standard_deviation_m: np.ndarray
    tide_mean_m: float
    tide_standard_deviation_m: float
    input_value_count_per_station: np.ndarray
    target_value_count_per_station: np.ndarray
    tide_value_count: int


@dataclass(frozen=True)
class JointWaterLevelData:
    """Aligned values, accepted records, and audit counters."""

    times_beijing: np.ndarray
    stages_m: np.ndarray
    targets_m: np.ndarray
    astronomical_tide_m: np.ndarray
    normalization: NormalizationStatistics
    training_records: tuple[SampleRecord, ...]
    validation_records: tuple[SampleRecord, ...]
    station_read_audits: tuple[StationReadAudit, ...]
    input_content_identities: tuple[InputContentIdentity, ...]
    astronomical_dependency_identities: tuple[InputContentIdentity, ...]
    test_target_rows_read: int
    test_target_values_parsed: int
    test_target_values_loaded: int
    time_offset_error_count: int
    future_observation_input_count: int


def _parse_time(value: str, expected_offset: timedelta) -> datetime:
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None or parsed.utcoffset() != expected_offset:
        raise ValueError(f"time has wrong offset: {value}")
    return parsed


def _parse_optional_float(value: str, missing_flag: str) -> float:
    if missing_flag not in {"True", "False"}:
        raise ValueError("missing flag must be True or False")
    if missing_flag == "True":
        if value != "":
            raise ValueError("missing value must be empty")
        return float("nan")
    if value == "":
        raise ValueError("available value must be numeric")
    parsed = float(value)
    if not math.isfinite(parsed):
        raise ValueError("available value must be finite")
    return parsed


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _full_file_content_identity(
    relative_path: str, path: Path
) -> InputContentIdentity:
    digest = hashlib.sha256()
    byte_count = 0
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
            byte_count += len(block)
    return InputContentIdentity(
        relative_path=relative_path,
        verification_scope="full_file",
        byte_count=byte_count,
        sha256=digest.hexdigest(),
    )


def _read_exact_prefix_bytes(path: Path, expected_bytes: int) -> bytes:
    chunks = []
    remaining = expected_bytes
    with path.open("rb", buffering=0) as handle:
        while remaining:
            block = handle.read(min(1024 * 1024, remaining))
            if not block:
                raise RuntimeError(f"input prefix ended early: {path}")
            chunks.append(block)
            remaining -= len(block)
    return b"".join(chunks)


def _contract_prefix_content_identity(
    relative_path: str, path: Path
) -> InputContentIdentity:
    expected_bytes = EXPECTED_INPUT_CONTENT_IDENTITIES[relative_path][1]
    content = _read_exact_prefix_bytes(path, expected_bytes)
    lines = content.splitlines()
    if len(lines) != EXPECTED_CONTRACT_ROWS + 1:
        raise RuntimeError(f"contract prefix row count changed: {relative_path}")
    last_line = lines[-1]
    if not last_line.startswith(b"2023-12-31T23:00:00+08:00,"):
        raise RuntimeError(
            f"contract prefix final time changed: {relative_path}"
        )
    return InputContentIdentity(
        relative_path=relative_path,
        verification_scope="header_plus_61344_rows",
        byte_count=len(content),
        sha256=hashlib.sha256(content).hexdigest(),
    )


def verify_input_content_identity(
    relative_path: str, path: str | Path
) -> InputContentIdentity:
    """Verify one file against its frozen full-file or target-prefix identity."""
    if relative_path not in EXPECTED_INPUT_CONTENT_IDENTITIES:
        raise ValueError(f"unknown input content identity: {relative_path}")
    expected_scope, expected_bytes, expected_sha256 = (
        EXPECTED_INPUT_CONTENT_IDENTITIES[relative_path]
    )
    path = Path(path)
    if expected_scope == "full_file":
        actual = _full_file_content_identity(relative_path, path)
    else:
        actual = _contract_prefix_content_identity(relative_path, path)
    if (
        actual.verification_scope != expected_scope
        or actual.byte_count != expected_bytes
        or actual.sha256 != expected_sha256
    ):
        raise RuntimeError(f"input content identity changed: {relative_path}")
    return actual


def _verify_all_input_content(
    input_dir: Path,
) -> tuple[InputContentIdentity, ...]:
    return tuple(
        verify_input_content_identity(relative_path, input_dir / relative_path)
        for relative_path in EXPECTED_INPUT_CONTENT_IDENTITIES
    )


def _timeline() -> tuple[list[datetime], dict[datetime, int]]:
    hour_count = int(
        (VALIDATION_END - TRAIN_START).total_seconds() // 3600
    ) + 1
    times = [TRAIN_START + timedelta(hours=index) for index in range(hour_count)]
    return times, {value: index for index, value in enumerate(times)}


def _read_station(
    input_dir: Path,
    station: str,
    time_to_position: dict[datetime, int],
    stage_column: np.ndarray,
    target_column: np.ndarray,
) -> StationReadAudit:
    feature_path = (
        input_dir / "realtime_features" / f"{station}_realtime_features.csv"
    )
    target_path = (
        input_dir
        / "retrospective_targets"
        / f"{station}_retrospective_targets.csv"
    )
    feature_relative_path = (
        f"realtime_features/{station}_realtime_features.csv"
    )
    target_relative_path = (
        f"retrospective_targets/{station}_retrospective_targets.csv"
    )
    feature_prefix = _read_exact_prefix_bytes(
        feature_path,
        EXPECTED_INPUT_CONTENT_IDENTITIES[feature_relative_path][1],
    )
    target_prefix = _read_exact_prefix_bytes(
        target_path,
        EXPECTED_INPUT_CONTENT_IDENTITIES[target_relative_path][1],
    )
    previous_time = None
    yielded_row_count = 0
    test_feature_rows_read = 0
    test_target_rows_read = 0
    test_target_values_parsed = 0
    test_target_values_loaded = 0
    source_start = SOURCE_ROWS_BEFORE_TRAIN_START[station]
    source_stop = source_start + EXPECTED_CONTRACT_ROWS
    with io.StringIO(
        feature_prefix.decode("utf-8"), newline=""
    ) as feature_handle, io.StringIO(
        target_prefix.decode("utf-8"), newline=""
    ) as target_handle:
        features = csv.DictReader(feature_handle)
        targets = csv.DictReader(target_handle)
        if features.fieldnames != FEATURE_FIELDS:
            raise RuntimeError(f"realtime fields changed: {station}")
        if targets.fieldnames != TARGET_FIELDS:
            raise RuntimeError(f"target fields changed: {station}")
        selected_features = islice(features, source_start, source_stop)
        selected_targets = islice(targets, source_start, source_stop)
        for row_index, (feature, target) in enumerate(
            zip_longest(selected_features, selected_targets)
        ):
            if feature is None or target is None:
                raise RuntimeError(f"feature and target lengths differ: {station}")
            beijing = _parse_time(feature["time_beijing"], timedelta(hours=8))
            utc = _parse_time(feature["time_utc"], timedelta(0))
            target_beijing = _parse_time(
                target["time_beijing"], timedelta(hours=8)
            )
            target_utc = _parse_time(target["time_utc"], timedelta(0))
            if beijing >= TEST_START:
                test_feature_rows_read += 1
            if target_beijing >= TEST_START:
                test_target_rows_read += 1
            if (
                feature["TIME"] != feature["time_beijing"]
                or target["TIME"] != target["time_beijing"]
                or target_beijing != beijing
                or target_utc != utc
                or beijing.astimezone(UTC) != utc
            ):
                raise RuntimeError(f"time alignment changed: {station}")
            if previous_time is not None and beijing - previous_time != timedelta(
                hours=1
            ):
                raise RuntimeError(f"timeline is not hourly: {station}")
            previous_time = beijing
            expected_time = TRAIN_START + timedelta(hours=row_index)
            if beijing != expected_time:
                raise RuntimeError(f"contract timeline changed: {station}")
            position = time_to_position.get(beijing)
            if position is None:
                raise RuntimeError(f"contract time is outside timeline: {station}")
            stage_column[position] = _parse_optional_float(
                feature["STAGE"], feature["is_missing_for_model"]
            )
            target_column[position] = _parse_optional_float(
                target["TARGET_STAGE"], target["is_missing_for_target"]
            )
            if target_beijing >= TEST_START:
                test_target_values_parsed += 1
                test_target_values_loaded += 1
            yielded_row_count += 1
    if yielded_row_count != EXPECTED_CONTRACT_ROWS:
        raise RuntimeError(f"contract row count changed: {station}")
    if previous_time != VALIDATION_END:
        raise RuntimeError(f"contract final time changed: {station}")
    return StationReadAudit(
        station_slug=station,
        contract_target_rows_read=yielded_row_count,
        last_target_time_beijing=previous_time,
        test_feature_rows_read=test_feature_rows_read,
        test_target_rows_read=test_target_rows_read,
        test_target_values_parsed=test_target_values_parsed,
        test_target_values_loaded=test_target_values_loaded,
    )


def fit_training_normalization(
    times_beijing: np.ndarray,
    stages_m: np.ndarray,
    targets_m: np.ndarray,
    astronomical_tide_m: np.ndarray,
    training_records: Sequence[SampleRecord],
) -> NormalizationStatistics:
    """Fit population statistics over accepted training sample windows."""
    times = np.asarray(times_beijing, dtype=object)
    stages = np.asarray(stages_m, dtype=np.float64)
    targets = np.asarray(targets_m, dtype=np.float64)
    tide_values = np.asarray(astronomical_tide_m, dtype=np.float64)
    if stages.shape != (len(times), len(STATION_ORDER)):
        raise ValueError("stage shape must be [time, 6]")
    if targets.shape != stages.shape or tide_values.shape != (len(times),):
        raise ValueError("target or astronomical-tide shape changed")
    if np.isinf(stages).any() or np.isinf(targets).any() or np.isinf(tide_values).any():
        raise ValueError("normalization input contains an infinite value")
    if not training_records:
        raise ValueError("normalization has no training records")
    issue_positions = np.asarray(
        [record.issue_position for record in training_records], dtype=np.int64
    )
    for record in training_records:
        if (
            record.issue_position < INPUT_LENGTH_HOURS - 1
            or record.issue_position + FORECAST_LENGTH_HOURS >= len(times)
            or times[record.issue_position] != record.issue_time_beijing
            or record.issue_time_beijing - timedelta(hours=23) < TRAIN_START
            or record.issue_time_beijing + timedelta(hours=24) > TRAIN_END
        ):
            raise ValueError("normalization record crosses the training split")
    history_positions = issue_positions[:, None] + np.arange(-23, 1)[None, :]
    future_positions = issue_positions[:, None] + np.arange(1, 25)[None, :]
    input_values = stages[history_positions]
    target_values = targets[future_positions]
    tide_training_values = tide_values[future_positions]
    if (
        not np.isfinite(input_values).all()
        or not np.isfinite(target_values).all()
        or not np.isfinite(tide_training_values).all()
    ):
        raise ValueError("normalization accepted window contains a nonfinite value")
    input_mean = np.mean(input_values, axis=(0, 1), dtype=np.float64)
    input_scale = np.std(input_values, axis=(0, 1), ddof=0, dtype=np.float64)
    target_mean = np.mean(target_values, axis=(0, 1), dtype=np.float64)
    target_scale = np.std(target_values, axis=(0, 1), ddof=0, dtype=np.float64)
    tide_mean = float(np.mean(tide_training_values, dtype=np.float64))
    tide_scale = float(np.std(tide_training_values, ddof=0, dtype=np.float64))
    values_to_check = np.concatenate(
        [input_mean, input_scale, target_mean, target_scale, [tide_mean, tide_scale]]
    )
    if not np.isfinite(values_to_check).all():
        raise ValueError("normalization statistic is nonfinite")
    if (
        np.any(input_scale <= 0)
        or np.any(target_scale <= 0)
        or tide_scale <= 0
    ):
        raise ValueError("normalization standard deviation must be positive")
    return NormalizationStatistics(
        input_mean_m=input_mean.astype(np.float32),
        input_standard_deviation_m=input_scale.astype(np.float32),
        target_mean_m=target_mean.astype(np.float32),
        target_standard_deviation_m=target_scale.astype(np.float32),
        tide_mean_m=tide_mean,
        tide_standard_deviation_m=tide_scale,
        input_value_count_per_station=np.full(
            len(STATION_ORDER), input_values.shape[0] * input_values.shape[1]
        ),
        target_value_count_per_station=np.full(
            len(STATION_ORDER), target_values.shape[0] * target_values.shape[1]
        ),
        tide_value_count=int(tide_training_values.size),
    )


def _complete_records(
    times: list[datetime],
    stages_m: np.ndarray,
    targets_m: np.ndarray,
    split_start: datetime,
    split_end: datetime,
) -> tuple[SampleRecord, ...]:
    complete_stage = np.isfinite(stages_m).all(axis=1)
    complete_target = np.isfinite(targets_m).all(axis=1)
    stage_bad_prefix = np.concatenate(([0], np.cumsum(~complete_stage)))
    target_bad_prefix = np.concatenate(([0], np.cumsum(~complete_target)))
    first = times.index(split_start) + INPUT_LENGTH_HOURS - 1
    last = times.index(split_end) - FORECAST_LENGTH_HOURS
    positions = np.arange(first, last + 1, dtype=np.int64)
    history_bad = (
        stage_bad_prefix[positions + 1]
        - stage_bad_prefix[positions + 1 - INPUT_LENGTH_HOURS]
    )
    future_bad = (
        target_bad_prefix[positions + 1 + FORECAST_LENGTH_HOURS]
        - target_bad_prefix[positions + 1]
    )
    accepted = positions[(history_bad == 0) & (future_bad == 0)]
    return tuple(
        SampleRecord(int(position), times[int(position)])
        for position in accepted
    )


def load_joint_water_level_data(
    input_dir: str | Path = DEFAULT_INPUT_DIR,
    tide_model_path: str | Path = DEFAULT_TIDE_MODEL_PATH,
) -> JointWaterLevelData:
    """Load the fixed 2017-2023 joint data without parsing test targets."""
    input_dir = Path(input_dir)
    input_content_identities = _verify_all_input_content(input_dir)
    config = json.loads(
        (input_dir / "dataset_config.json").read_text(encoding="utf-8")
    )
    if config.get("dataset_version") != INPUT_DATASET_VERSION:
        raise RuntimeError("input dataset version changed")
    times, time_to_position = _timeline()
    stages = np.full((len(times), len(STATION_ORDER)), np.nan, dtype=np.float64)
    targets = np.full_like(stages, np.nan)
    station_read_audits = []
    for station_id, station in enumerate(STATION_ORDER):
        station_read_audits.append(
            _read_station(
                input_dir,
                station,
                time_to_position,
                stages[:, station_id],
                targets[:, station_id],
            )
        )
    training_records = _complete_records(
        times, stages, targets, TRAIN_START, TRAIN_END
    )
    validation_records = _complete_records(
        times, stages, targets, VALIDATION_START, VALIDATION_END
    )
    if len(training_records) != EXPECTED_TRAINING_SAMPLES:
        raise RuntimeError("joint training sample count changed")
    if len(validation_records) != EXPECTED_VALIDATION_SAMPLES:
        raise RuntimeError("joint validation sample count changed")
    frozen_tide = load_frozen_astronomical_tide(tide_model_path)
    tide_values = frozen_tide.predict(times)
    times_array = np.asarray(times, dtype=object)
    normalization = fit_training_normalization(
        times_array, stages, targets, tide_values, training_records
    )
    return JointWaterLevelData(
        times_beijing=times_array,
        stages_m=stages.astype(np.float32),
        targets_m=targets.astype(np.float32),
        astronomical_tide_m=tide_values,
        normalization=normalization,
        training_records=training_records,
        validation_records=validation_records,
        station_read_audits=tuple(station_read_audits),
        input_content_identities=input_content_identities,
        astronomical_dependency_identities=(
            frozen_tide.dependency_content_identities
        ),
        test_target_rows_read=sum(
            audit.test_target_rows_read for audit in station_read_audits
        ),
        test_target_values_parsed=sum(
            audit.test_target_values_parsed for audit in station_read_audits
        ),
        test_target_values_loaded=sum(
            audit.test_target_values_loaded for audit in station_read_audits
        ),
        time_offset_error_count=0,
        future_observation_input_count=sum(
            audit.test_feature_rows_read for audit in station_read_audits
        ),
    )


class JointWaterLevelDataset(Dataset):
    """Return normalized complete joint samples without copying all windows."""

    def __init__(
        self,
        data: JointWaterLevelData,
        records: Sequence[SampleRecord],
    ) -> None:
        self.data = data
        self.records = tuple(records)

    def __len__(self) -> int:
        return len(self.records)

    def __getitem__(self, index: int):
        record = self.records[index]
        issue = record.issue_position
        history = self.data.stages_m[
            issue + 1 - INPUT_LENGTH_HOURS : issue + 1
        ]
        future_tide = self.data.astronomical_tide_m[
            issue + 1 : issue + 1 + FORECAST_LENGTH_HOURS
        ]
        targets = self.data.targets_m[
            issue + 1 : issue + 1 + FORECAST_LENGTH_HOURS
        ]
        statistics = self.data.normalization
        normalized_history = (
            history - statistics.input_mean_m[None, :]
        ) / statistics.input_standard_deviation_m[None, :]
        normalized_tide = (
            future_tide - statistics.tide_mean_m
        ) / statistics.tide_standard_deviation_m
        normalized_targets = (
            targets - statistics.target_mean_m[None, :]
        ) / statistics.target_standard_deviation_m[None, :]
        if (
            normalized_history.shape != (INPUT_LENGTH_HOURS, len(STATION_ORDER))
            or normalized_tide.shape != (FORECAST_LENGTH_HOURS,)
            or normalized_targets.shape
            != (FORECAST_LENGTH_HOURS, len(STATION_ORDER))
            or not np.isfinite(normalized_history).all()
            or not np.isfinite(normalized_tide).all()
            or not np.isfinite(normalized_targets).all()
        ):
            raise ValueError("accepted joint sample is incomplete or nonfinite")
        return (
            torch.from_numpy(normalized_history.astype(np.float32, copy=True)),
            torch.from_numpy(normalized_tide.astype(np.float32, copy=True)),
            torch.from_numpy(normalized_targets.astype(np.float32, copy=True)),
        )


def trainable_parameter_count(model: nn.Module) -> int:
    """Return the exact number of trainable scalar parameters."""
    return sum(
        parameter.numel()
        for parameter in model.parameters()
        if parameter.requires_grad
    )


def _validate_model_inputs(
    history: torch.Tensor, future_tide: torch.Tensor
) -> None:
    if history.ndim != 3 or history.shape[1:] != (
        INPUT_LENGTH_HOURS,
        len(STATION_ORDER),
    ):
        raise ValueError("history shape must be [batch, 24, 6]")
    if future_tide.shape != (history.shape[0], FORECAST_LENGTH_HOURS):
        raise ValueError("future tide shape must be [batch, 24]")
    if history.shape[0] == 0:
        raise ValueError("model batch must contain at least one sample")
    if history.device != future_tide.device:
        raise ValueError("history and future tide must use the same device")
    if history.dtype != future_tide.dtype:
        raise ValueError("history and future tide must use the same data type")
    if history.dtype != torch.float32:
        raise ValueError("history and future tide must use float32")
    if not torch.isfinite(history).all() or not torch.isfinite(future_tide).all():
        raise ValueError("model input contains a nonfinite value")


class RiverBidirectionalRecurrentEncoderDecoder(nn.Module):
    """Encode shared station histories and both directions of river order."""

    PARAMETER_LIMIT = 250000

    def __init__(self) -> None:
        super().__init__()
        self.hidden_size = 64
        self.temporal_encoder = nn.LSTM(
            input_size=1,
            hidden_size=self.hidden_size,
            batch_first=True,
        )
        self.upstream_spatial_encoder = nn.LSTM(
            input_size=self.hidden_size,
            hidden_size=self.hidden_size,
            batch_first=True,
        )
        self.downstream_spatial_encoder = nn.LSTM(
            input_size=self.hidden_size,
            hidden_size=self.hidden_size,
            batch_first=True,
        )
        self.river_state_projection = nn.Linear(
            self.hidden_size * 2, self.hidden_size
        )
        self.forecast_hour_embedding = nn.Embedding(
            FORECAST_LENGTH_HOURS, 16
        )
        self.station_embedding = nn.Embedding(len(STATION_ORDER), 8)
        self.decoder = nn.LSTM(
            input_size=16 + 8 + 1,
            hidden_size=self.hidden_size,
            batch_first=True,
        )
        self.decoder_cell_projection = nn.Linear(
            self.hidden_size, self.hidden_size
        )
        self.output_projection = nn.Linear(self.hidden_size, 1)
        parameter_count = trainable_parameter_count(self)
        if parameter_count > self.PARAMETER_LIMIT:
            raise ValueError(
                f"recurrent parameter count {parameter_count} exceeds "
                f"{self.PARAMETER_LIMIT}"
            )

    def forward(
        self, history: torch.Tensor, future_tide: torch.Tensor
    ) -> torch.Tensor:
        _validate_model_inputs(history, future_tide)
        batch_size = history.shape[0]
        station_count = len(STATION_ORDER)
        temporal_input = history.transpose(1, 2).reshape(
            batch_size * station_count, INPUT_LENGTH_HOURS, 1
        )
        _, (temporal_hidden, _) = self.temporal_encoder(temporal_input)
        station_states = temporal_hidden[-1].reshape(
            batch_size, station_count, self.hidden_size
        )
        upstream_states, _ = self.upstream_spatial_encoder(station_states)
        downstream_reversed, _ = self.downstream_spatial_encoder(
            torch.flip(station_states, dims=[1])
        )
        downstream_states = torch.flip(downstream_reversed, dims=[1])
        river_states = torch.tanh(
            self.river_state_projection(
                torch.cat([upstream_states, downstream_states], dim=-1)
            )
        )

        hours = torch.arange(
            FORECAST_LENGTH_HOURS,
            device=history.device,
            dtype=torch.long,
        )
        stations = torch.arange(
            station_count, device=history.device, dtype=torch.long
        )
        hour_queries = self.forecast_hour_embedding(hours)[None, None, :, :]
        hour_queries = hour_queries.expand(batch_size, station_count, -1, -1)
        station_queries = self.station_embedding(stations)[None, :, None, :]
        station_queries = station_queries.expand(
            batch_size, -1, FORECAST_LENGTH_HOURS, -1
        )
        tide_queries = future_tide[:, None, :, None].expand(
            -1, station_count, -1, -1
        )
        decoder_input = torch.cat(
            [hour_queries, station_queries, tide_queries], dim=-1
        ).reshape(batch_size * station_count, FORECAST_LENGTH_HOURS, -1)
        decoder_hidden = river_states.reshape(
            1, batch_size * station_count, self.hidden_size
        )
        decoder_cell = torch.tanh(
            self.decoder_cell_projection(river_states)
        ).reshape(1, batch_size * station_count, self.hidden_size)
        decoded, _ = self.decoder(
            decoder_input, (decoder_hidden, decoder_cell)
        )
        station_predictions = self.output_projection(decoded).reshape(
            batch_size, station_count, FORECAST_LENGTH_HOURS
        )
        return station_predictions.transpose(1, 2).contiguous()


def build_river_neighbor_features(history: torch.Tensor) -> torch.Tensor:
    """Add upstream, downstream, and two explicit river-boundary channels."""
    if history.ndim != 3 or history.shape[1:] != (
        INPUT_LENGTH_HOURS,
        len(STATION_ORDER),
    ):
        raise ValueError("history shape must be [batch, 24, 6]")
    if not torch.isfinite(history).all():
        raise ValueError("history contains a nonfinite value")
    upstream = torch.zeros_like(history)
    downstream = torch.zeros_like(history)
    upstream[:, :, 1:] = history[:, :, :-1]
    downstream[:, :, :-1] = history[:, :, 1:]
    upstream_boundary = torch.zeros_like(history)
    downstream_boundary = torch.zeros_like(history)
    upstream_boundary[:, :, 0] = 1.0
    downstream_boundary[:, :, -1] = 1.0
    return torch.stack(
        [
            history,
            upstream,
            downstream,
            upstream_boundary,
            downstream_boundary,
        ],
        dim=-1,
    )


class RiverOrderTransformerEncoderDecoder(nn.Module):
    """Attend over 144 ordered river-history cells and future queries."""

    PARAMETER_LIMIT = 500000

    def __init__(self) -> None:
        super().__init__()
        self.model_width = 64
        self.attention_heads = 4
        self.history_feature_projection = nn.Linear(5, self.model_width)
        self.history_hour_embedding = nn.Embedding(
            INPUT_LENGTH_HOURS, self.model_width
        )
        self.station_embedding = nn.Embedding(
            len(STATION_ORDER), self.model_width
        )
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=self.model_width,
            nhead=self.attention_heads,
            dim_feedforward=128,
            dropout=TRANSFORMER_DROPOUT,
            activation="gelu",
            batch_first=True,
            norm_first=False,
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=2)
        self.future_hour_embedding = nn.Embedding(
            FORECAST_LENGTH_HOURS, self.model_width
        )
        self.future_tide_projection = nn.Linear(1, self.model_width)
        decoder_layer = nn.TransformerDecoderLayer(
            d_model=self.model_width,
            nhead=self.attention_heads,
            dim_feedforward=128,
            dropout=TRANSFORMER_DROPOUT,
            activation="gelu",
            batch_first=True,
            norm_first=False,
        )
        self.decoder = nn.TransformerDecoder(decoder_layer, num_layers=1)
        self.output_projection = nn.Linear(self.model_width, 1)
        parameter_count = trainable_parameter_count(self)
        if parameter_count > self.PARAMETER_LIMIT:
            raise ValueError(
                f"transformer parameter count {parameter_count} exceeds "
                f"{self.PARAMETER_LIMIT}"
            )

    def build_history_cells(self, history: torch.Tensor) -> torch.Tensor:
        features = build_river_neighbor_features(history)
        batch_size = history.shape[0]
        hours = torch.arange(
            INPUT_LENGTH_HOURS, device=history.device, dtype=torch.long
        )
        stations = torch.arange(
            len(STATION_ORDER), device=history.device, dtype=torch.long
        )
        cells = self.history_feature_projection(features)
        cells = cells + self.history_hour_embedding(hours)[None, :, None, :]
        cells = cells + self.station_embedding(stations)[None, None, :, :]
        return cells.reshape(
            batch_size,
            INPUT_LENGTH_HOURS * len(STATION_ORDER),
            self.model_width,
        )

    def build_future_queries(self, future_tide: torch.Tensor) -> torch.Tensor:
        if future_tide.ndim != 2 or future_tide.shape[1] != FORECAST_LENGTH_HOURS:
            raise ValueError("future tide shape must be [batch, 24]")
        if not torch.isfinite(future_tide).all():
            raise ValueError("future tide contains a nonfinite value")
        batch_size = future_tide.shape[0]
        hours = torch.arange(
            FORECAST_LENGTH_HOURS,
            device=future_tide.device,
            dtype=torch.long,
        )
        stations = torch.arange(
            len(STATION_ORDER), device=future_tide.device, dtype=torch.long
        )
        queries = self.future_hour_embedding(hours)[None, :, None, :]
        queries = queries + self.station_embedding(stations)[None, None, :, :]
        queries = queries + self.future_tide_projection(
            future_tide[:, :, None]
        )[:, :, None, :]
        return queries.expand(
            batch_size, -1, len(STATION_ORDER), -1
        ).reshape(
            batch_size,
            FORECAST_LENGTH_HOURS * len(STATION_ORDER),
            self.model_width,
        )

    def forward(
        self, history: torch.Tensor, future_tide: torch.Tensor
    ) -> torch.Tensor:
        _validate_model_inputs(history, future_tide)
        memory = self.encoder(self.build_history_cells(history))
        decoded = self.decoder(
            self.build_future_queries(future_tide), memory
        )
        return self.output_projection(decoded).reshape(
            history.shape[0], FORECAST_LENGTH_HOURS, len(STATION_ORDER)
        )


def weighted_smooth_absolute_error(
    predictions_standardized: torch.Tensor,
    targets_standardized: torch.Tensor,
    target_standard_deviations_m: torch.Tensor,
) -> torch.Tensor:
    """Compute the Zhenjiang-weighted smooth absolute error in metres."""
    expected_tail = (FORECAST_LENGTH_HOURS, len(STATION_ORDER))
    if (
        predictions_standardized.ndim != 3
        or predictions_standardized.shape[1:] != expected_tail
        or targets_standardized.shape != predictions_standardized.shape
    ):
        raise ValueError("prediction shape must be [batch, 24, 6]")
    if predictions_standardized.shape[0] == 0:
        raise ValueError("loss batch must contain at least one sample")
    if predictions_standardized.device != targets_standardized.device:
        raise ValueError("prediction and target must use the same device")
    if predictions_standardized.dtype != targets_standardized.dtype:
        raise ValueError("prediction and target must use the same data type")
    if predictions_standardized.dtype != torch.float32:
        raise ValueError("prediction and target must use float32")
    scale = torch.as_tensor(
        target_standard_deviations_m,
        device=predictions_standardized.device,
        dtype=torch.float32,
    )
    if scale.shape != (len(STATION_ORDER),):
        raise ValueError("target standard deviation shape must be [6]")
    if (
        not torch.isfinite(predictions_standardized).all()
        or not torch.isfinite(targets_standardized).all()
        or not torch.isfinite(scale).all()
    ):
        raise ValueError("loss input contains a nonfinite value")
    if torch.any(scale <= 0):
        raise ValueError("target standard deviations must be positive")
    error_m = (predictions_standardized - targets_standardized) * scale[
        None, None, :
    ]
    absolute_error_m = torch.abs(error_m)
    transition = SMOOTH_ABSOLUTE_ERROR_TRANSITION_M
    element_loss = torch.where(
        absolute_error_m < transition,
        0.5 * absolute_error_m.square() / transition,
        absolute_error_m - 0.5 * transition,
    )
    weights = torch.as_tensor(
        STATION_LOSS_WEIGHTS,
        device=predictions_standardized.device,
        dtype=predictions_standardized.dtype,
    )
    denominator = (
        predictions_standardized.shape[0]
        * FORECAST_LENGTH_HOURS
        * torch.sum(weights)
    )
    return torch.sum(element_loss * weights[None, None, :]) / denominator


def compute_forecast_metrics(
    predictions_standardized: np.ndarray,
    targets_standardized: np.ndarray,
    target_means_m: np.ndarray,
    target_standard_deviations_m: np.ndarray,
) -> list[dict]:
    """Return six-station by 24-hour validation metrics in metres."""
    predictions = np.asarray(predictions_standardized, dtype=np.float64)
    targets = np.asarray(targets_standardized, dtype=np.float64)
    means = np.asarray(target_means_m, dtype=np.float64)
    scales = np.asarray(target_standard_deviations_m, dtype=np.float64)
    if (
        predictions.ndim != 3
        or predictions.shape[1:]
        != (FORECAST_LENGTH_HOURS, len(STATION_ORDER))
        or targets.shape != predictions.shape
    ):
        raise ValueError("prediction shape must be [sample, 24, 6]")
    if predictions.shape[0] == 0:
        raise ValueError("metric batch must contain at least one sample")
    if means.shape != (len(STATION_ORDER),) or scales.shape != (
        len(STATION_ORDER),
    ):
        raise ValueError("target normalization shape must be [6]")
    if (
        not np.isfinite(predictions).all()
        or not np.isfinite(targets).all()
        or not np.isfinite(means).all()
        or not np.isfinite(scales).all()
    ):
        raise ValueError("metric input contains a nonfinite value")
    if np.any(scales <= 0):
        raise ValueError("target standard deviations must be positive")
    predictions_m = predictions * scales[None, None, :] + means[None, None, :]
    targets_m = targets * scales[None, None, :] + means[None, None, :]
    errors_m = predictions_m - targets_m
    rows = []
    for station_id, station in enumerate(STATION_ORDER):
        for horizon_index in range(FORECAST_LENGTH_HOURS):
            errors = errors_m[:, horizon_index, station_id]
            absolute_errors = np.abs(errors)
            rows.append(
                {
                    "station_slug": station,
                    "forecast_hour": horizon_index + 1,
                    "sample_count": int(len(errors)),
                    "mean_absolute_error_m": float(np.mean(absolute_errors)),
                    "root_mean_squared_error_m": float(
                        np.sqrt(np.mean(np.square(errors)))
                    ),
                    "mean_error_m": float(np.mean(errors)),
                    "absolute_error_95th_percentile_m": float(
                        np.percentile(absolute_errors, 95)
                    ),
                }
            )
    return rows
