#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Run the registered two-stage real-data integration smoke on one device.

Inputs:
    The digest-registered smoke configuration, six-station input directory,
    the accepted loader tide model, an explicit digest-verified KalmanNet
    source, and a new output directory whose suffix matches the registry.

Outputs:
    Fold-specific tide artifacts, stage histories, backbone and full-model
    checkpoints, run identity, and a completion manifest.  The held-out-year
    dataset is never constructed or scored by this smoke command.

Command-line arguments:
    ``--allow-paid-smoke`` is mandatory before any real-data or external-source
    access.  ``--verify-output`` independently checks a completed output.

Example:
    python -u scripts/modeling/zhenjiang_latent_gru_kalmannet_runner_v1.py --config docs/records/ZHENJIANG_LATENT_GRU_KALMANNET_HPC_SMOKE_V1_CONFIG.json --registry docs/records/ZHENJIANG_LATENT_GRU_KALMANNET_EXPERIMENT_REGISTRY_V1.json --input-dir data/processed/water_level_model_input_v7_beijing_realtime_verified --loader-tide-model results/modeling/wusongkou_astronomical_tide_v1_validation/tide_model.json --kalmannet-source G:/github/pycharm/projects/kalmannet/third_party/KalmanNet_TSP_828a2cf/KNet/KalmanNet_nn.py --output-root results/runtime/zhenjiang_latent_gru_kalmannet_hpc_smoke_v1/ZLDA-SMOKE-01 --device cpu --allow-paid-smoke
"""

from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import random
import sys
import time
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple
from uuid import uuid4

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset


PROJECT_ROOT = Path(__file__).resolve().parents[2]
for _relative in ("scripts/modeling", "scripts/analysis"):
    _candidate = str(PROJECT_ROOT / _relative)
    if _candidate not in sys.path:
        sys.path.insert(0, _candidate)

import zhenjiang_oyv_v1_contract as contract  # noqa: E402
from zhenjiang_oyv_v1_data import load_out_of_year_data  # noqa: E402
from zhenjiang_kalmannet_gain_adapter_v1 import (  # noqa: E402
    EXPECTED_KALMANNET_SHA256,
    PinnedKalmanNetGainAdapter,
)
from zhenjiang_latent_gru_kalmannet_data_v1 import (  # noqa: E402
    LatentDARecord,
    LatentDAWindowDataset,
    accepted_latent_da_records,
    fit_latent_da_normalization,
    one_station_only_availability,
)
from zhenjiang_latent_gru_kalmannet_experiment_v1 import (  # noqa: E402
    SMOKE_OUTPUT_RELATIVE_PATH,
    load_registered_smoke_config,
    sha256_bytes,
)
from zhenjiang_latent_gru_kalmannet_fold_tide_v1 import (  # noqa: E402
    fit_fold_astronomical_tide,
    write_fold_astronomical_tide,
)
from zhenjiang_latent_gru_kalmannet_training_v1 import (  # noqa: E402
    PRETRAIN_BACKBONE,
    TRAIN_GAIN,
    SyntheticLearnedGain,
    compute_stage_loss,
    configure_training_stage,
    forward_for_training_stage,
)
from zhenjiang_latent_gru_kalmannet_v1 import (  # noqa: E402
    AvailabilityGatedLatentGRUKalmanNet,
)


TENSOR_BATCH_KEYS = (
    "warmup_levels",
    "warmup_controls",
    "analysis_observations",
    "analysis_targets",
    "analysis_availability",
    "analysis_controls",
    "future_controls",
    "future_targets",
)
STAGE_HISTORY_FIELDS = (
    "epoch",
    "training_loss_m",
    "validation_loss_m",
    "training_batch_count",
    "validation_batch_count",
    "improved",
)


@dataclass(frozen=True)
class StageResult:
    """One bounded stage's best state and auditable loss history."""

    stage: str
    best_validation_loss_m: float
    best_epoch: int
    completed_epochs: int
    total_training_batches: int
    total_validation_batches: int
    best_state: Dict[str, torch.Tensor]
    history: Tuple[Dict[str, object], ...]


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _json_bytes(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode("utf-8")


def collate_latent_da_batch(
    samples: Sequence[Dict[str, object]],
) -> Dict[str, object]:
    """Stack tensors while preserving datetimes and positions as metadata."""

    if not samples:
        raise ValueError("cannot collate an empty latent data-assimilation batch")
    batch: Dict[str, object] = {}
    for key in TENSOR_BATCH_KEYS:
        values = [sample[key] for sample in samples]
        if not all(isinstance(value, torch.Tensor) for value in values):
            raise ValueError("batch field %s must contain tensors" % key)
        batch[key] = torch.stack(values, dim=0)
    batch["issue_times_beijing"] = tuple(
        sample["issue_time_beijing"] for sample in samples
    )
    batch["issue_positions"] = tuple(int(sample["issue_position"]) for sample in samples)
    return batch


def move_tensor_batch(
    batch: Mapping[str, object], device: torch.device
) -> Dict[str, object]:
    """Move only the frozen tensor fields and retain issue metadata on host."""

    moved: Dict[str, object] = dict(batch)
    for key in TENSOR_BATCH_KEYS:
        value = batch[key]
        if not isinstance(value, torch.Tensor):
            raise ValueError("batch field %s must be a tensor" % key)
        moved[key] = value.to(device=device, non_blocking=device.type == "cuda")
    return moved


def cyclic_one_station_availability(record: LatentDARecord) -> np.ndarray:
    """Expose one full-day station selected only from the issue position."""

    return one_station_only_availability(int(record.issue_position) % 6)


def build_smoke_record_splits(
    data, test_year: int
) -> Tuple[Tuple[LatentDARecord, ...], Tuple[LatentDARecord, ...]]:
    """Construct training and inner-validation records, never held-out records."""

    training_records = accepted_latent_da_records(
        data, tuple(contract.training_years(int(test_year)))
    )
    validation_records = accepted_latent_da_records(
        data, (int(contract.inner_validation_year(int(test_year))),)
    )
    if not training_records:
        raise ValueError("technical smoke has no accepted training records")
    if not validation_records:
        raise ValueError("technical smoke has no accepted inner-validation records")
    return training_records, validation_records


def _set_deterministic_runtime(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True)


def _state_dict_cpu(model: nn.Module) -> Dict[str, torch.Tensor]:
    return {
        name: value.detach().cpu().clone()
        for name, value in model.state_dict().items()
    }


def _evaluate_stage(
    model: AvailabilityGatedLatentGRUKalmanNet,
    stage: str,
    dataset: Dataset,
    station_scale: torch.Tensor,
    batch_size: int,
    maximum_batches: int,
    device: torch.device,
) -> Tuple[float, int]:
    loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        drop_last=False,
        num_workers=0,
        collate_fn=collate_latent_da_batch,
    )
    model.eval()
    weighted_loss = 0.0
    sample_count = 0
    batch_count = 0
    with torch.no_grad():
        for batch_index, host_batch in enumerate(loader):
            if batch_index >= maximum_batches:
                break
            batch = move_tensor_batch(host_batch, device)
            output = forward_for_training_stage(model, batch, stage)
            loss = compute_stage_loss(output, batch, station_scale, stage)
            if not bool(torch.isfinite(loss).item()):
                raise RuntimeError("validation loss is nonfinite")
            current_count = int(batch["warmup_levels"].shape[0])
            weighted_loss += float(loss.detach().cpu()) * current_count
            sample_count += current_count
            batch_count += 1
    if batch_count < 1 or sample_count < 1:
        raise RuntimeError("validation batch ceiling produced no observations")
    return weighted_loss / sample_count, batch_count


def train_stage(
    model: AvailabilityGatedLatentGRUKalmanNet,
    stage: str,
    training_dataset: Dataset,
    validation_dataset: Dataset,
    station_scale: torch.Tensor,
    config: Mapping[str, object],
    device: torch.device,
    output_directory: Path,
) -> StageResult:
    """Train one frozen stage within the registered one-epoch batch ceilings."""

    training_config = config["training"]
    if not isinstance(training_config, Mapping):
        raise ValueError("training configuration must be a mapping")
    stage_key = "stage_one" if stage == PRETRAIN_BACKBONE else "stage_two"
    stage_config = training_config[stage_key]
    if not isinstance(stage_config, Mapping):
        raise ValueError("stage configuration must be a mapping")
    trainable_names = configure_training_stage(model, stage)
    trainable_parameters = [
        parameter for parameter in model.parameters() if parameter.requires_grad
    ]
    if not trainable_names or not trainable_parameters:
        raise RuntimeError("training stage has no trainable parameters")
    optimizer = torch.optim.AdamW(
        trainable_parameters,
        lr=float(stage_config["learning_rate"]),
        betas=tuple(float(value) for value in training_config["adam_betas"]),
        eps=float(training_config["adam_epsilon"]),
        weight_decay=float(stage_config["weight_decay"]),
        amsgrad=False,
        fused=False,
    )
    seed = int(config["seed"]) + (0 if stage == PRETRAIN_BACKBONE else 1)
    generator = torch.Generator(device="cpu")
    generator.manual_seed(seed)
    batch_size = int(training_config["batch_size"])
    maximum_epochs = int(stage_config["maximum_epochs"])
    maximum_training_batches = int(
        stage_config["maximum_training_batches_per_epoch"]
    )
    maximum_validation_batches = int(stage_config["maximum_validation_batches"])
    station_scale = station_scale.to(device=device, dtype=torch.float32)
    history = []
    best_metric = float("inf")
    best_epoch = 0
    best_state: Optional[Dict[str, torch.Tensor]] = None
    total_training_batches = 0
    total_validation_batches = 0

    for epoch in range(1, maximum_epochs + 1):
        loader = DataLoader(
            training_dataset,
            batch_size=batch_size,
            shuffle=True,
            generator=generator,
            drop_last=False,
            num_workers=0,
            collate_fn=collate_latent_da_batch,
        )
        model.train()
        weighted_training_loss = 0.0
        training_sample_count = 0
        epoch_training_batches = 0
        for batch_index, host_batch in enumerate(loader):
            if batch_index >= maximum_training_batches:
                break
            batch = move_tensor_batch(host_batch, device)
            optimizer.zero_grad(set_to_none=True)
            output = forward_for_training_stage(model, batch, stage)
            loss = compute_stage_loss(output, batch, station_scale, stage)
            if not bool(torch.isfinite(loss).item()):
                raise RuntimeError("training loss is nonfinite")
            loss.backward()
            gradient_norm = torch.nn.utils.clip_grad_norm_(
                trainable_parameters,
                float(training_config["gradient_clip_norm"]),
            )
            if not bool(torch.isfinite(torch.as_tensor(gradient_norm)).item()):
                raise RuntimeError("gradient norm is nonfinite")
            optimizer.step()
            current_count = int(batch["warmup_levels"].shape[0])
            weighted_training_loss += float(loss.detach().cpu()) * current_count
            training_sample_count += current_count
            epoch_training_batches += 1
            total_training_batches += 1
        if epoch_training_batches < 1 or training_sample_count < 1:
            raise RuntimeError("training batch ceiling produced no observations")
        validation_loss, validation_batches = _evaluate_stage(
            model,
            stage,
            validation_dataset,
            station_scale,
            batch_size,
            maximum_validation_batches,
            device,
        )
        total_validation_batches += validation_batches
        improved = validation_loss < best_metric
        if improved:
            best_metric = validation_loss
            best_epoch = epoch
            best_state = _state_dict_cpu(model)
        history.append(
            {
                "epoch": epoch,
                "training_loss_m": weighted_training_loss / training_sample_count,
                "validation_loss_m": validation_loss,
                "training_batch_count": epoch_training_batches,
                "validation_batch_count": validation_batches,
                "improved": bool(improved),
            }
        )
    if best_state is None or not np.isfinite(best_metric):
        raise RuntimeError("training stage produced no finite best state")
    output_directory.mkdir(parents=True, exist_ok=True)
    return StageResult(
        stage=stage,
        best_validation_loss_m=float(best_metric),
        best_epoch=int(best_epoch),
        completed_epochs=len(history),
        total_training_batches=int(total_training_batches),
        total_validation_batches=int(total_validation_batches),
        best_state=best_state,
        history=tuple(history),
    )


def _write_stage_history(path: Path, result: StageResult) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=STAGE_HISTORY_FIELDS)
        writer.writeheader()
        for row in result.history:
            writer.writerow(row)


def _runtime_identity(device: torch.device) -> Dict[str, object]:
    identity: Dict[str, object] = {
        "python_version": platform.python_version(),
        "platform": platform.platform(),
        "numpy_version": np.__version__,
        "pandas_version": pd.__version__,
        "torch_version": torch.__version__,
        "cuda_runtime_version": torch.version.cuda,
        "device": str(device),
        "node_name": platform.node(),
        "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
        "slurm_job_name": os.environ.get("SLURM_JOB_NAME"),
    }
    if device.type == "cuda":
        properties = torch.cuda.get_device_properties(device)
        identity.update(
            {
                "graphics_processor_name": properties.name,
                "graphics_processor_total_memory_bytes": int(
                    properties.total_memory
                ),
                "graphics_processor_capability": list(
                    torch.cuda.get_device_capability(device)
                ),
            }
        )
    return identity


def _verify_output_suffix(output_root: Path) -> None:
    normalized = str(Path(output_root).resolve()).replace("\\", "/")
    if not normalized.endswith("/" + SMOKE_OUTPUT_RELATIVE_PATH):
        raise ValueError("output root does not end with the registered run directory")


def _artifact_rows(root: Path) -> list[dict[str, object]]:
    rows = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.name == "completion_manifest.json":
            continue
        rows.append(
            {
                "relative_path": path.relative_to(root).as_posix(),
                "byte_count": int(path.stat().st_size),
                "sha256": _sha256_file(path),
            }
        )
    return rows


def run_registered_smoke(
    *,
    config_path: Path,
    registry_path: Path,
    input_dir: Path,
    loader_tide_model: Path,
    kalmannet_source: Path,
    output_root: Path,
    device_name: str,
) -> Dict[str, object]:
    """Execute the registered bounded run and atomically publish success."""

    config = load_registered_smoke_config(config_path, registry_path)
    _verify_output_suffix(output_root)
    output_root = Path(output_root)
    if output_root.exists():
        raise FileExistsError(output_root)
    input_dir = Path(input_dir)
    loader_tide_model = Path(loader_tide_model)
    kalmannet_source = Path(kalmannet_source)
    for path, name in (
        (input_dir, "six-station input directory"),
        (loader_tide_model, "loader tide model"),
        (kalmannet_source, "KalmanNet source"),
    ):
        if not path.exists():
            raise FileNotFoundError("%s does not exist: %s" % (name, path))
    if _sha256_file(kalmannet_source) != EXPECTED_KALMANNET_SHA256:
        raise ValueError("KalmanNet source SHA-256 mismatch before data access")
    device = torch.device(device_name)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("requested graphics processor is unavailable")
    _set_deterministic_runtime(int(config["seed"]))

    output_root.parent.mkdir(parents=True, exist_ok=True)
    staging = output_root.parent / (
        ".%s.partial_%s" % (output_root.name, uuid4().hex[:10])
    )
    staging.mkdir(parents=False, exist_ok=False)
    started = time.perf_counter()
    data = load_out_of_year_data(input_dir, loader_tide_model)
    training_records, validation_records = build_smoke_record_splits(
        data, int(config["test_year"])
    )
    fold_tide, fold_tide_metadata = fit_fold_astronomical_tide(
        data, int(config["test_year"])
    )
    write_fold_astronomical_tide(
        staging / "fold_astronomical_tide", fold_tide, fold_tide_metadata
    )
    normalization = fit_latent_da_normalization(data, training_records, fold_tide)
    stage_one_training_dataset = LatentDAWindowDataset(
        data, training_records, fold_tide, normalization
    )
    stage_one_validation_dataset = LatentDAWindowDataset(
        data, validation_records, fold_tide, normalization
    )
    stage_two_training_dataset = LatentDAWindowDataset(
        data,
        training_records,
        fold_tide,
        normalization,
        analysis_availability=cyclic_one_station_availability,
    )
    stage_two_validation_dataset = LatentDAWindowDataset(
        data,
        validation_records,
        fold_tide,
        normalization,
        analysis_availability=cyclic_one_station_availability,
    )
    station_scale = torch.as_tensor(
        normalization.station_standard_deviation_m, dtype=torch.float32
    )

    stage_one_model = AvailabilityGatedLatentGRUKalmanNet(
        SyntheticLearnedGain()
    ).to(device=device, dtype=torch.float32)
    stage_one_result = train_stage(
        stage_one_model,
        PRETRAIN_BACKBONE,
        stage_one_training_dataset,
        stage_one_validation_dataset,
        station_scale,
        config,
        device,
        staging / "stage_one",
    )
    stage_one_model.load_state_dict(stage_one_result.best_state)
    backbone_state = _state_dict_cpu(stage_one_model.backbone)
    stage_one_checkpoint = staging / "stage_one" / "best_backbone_state.pt"
    torch.save(
        {
            "experiment_id": config["experiment_id"],
            "stage": PRETRAIN_BACKBONE,
            "backbone_state": backbone_state,
        },
        stage_one_checkpoint,
    )
    _write_stage_history(
        staging / "stage_one" / "training_history.csv", stage_one_result
    )

    stage_two_model = AvailabilityGatedLatentGRUKalmanNet(
        PinnedKalmanNetGainAdapter(kalmannet_source)
    ).to(device=device, dtype=torch.float32)
    stage_two_model.backbone.load_state_dict(backbone_state)
    stage_two_result = train_stage(
        stage_two_model,
        TRAIN_GAIN,
        stage_two_training_dataset,
        stage_two_validation_dataset,
        station_scale,
        config,
        device,
        staging / "stage_two",
    )
    stage_two_model.load_state_dict(stage_two_result.best_state)
    stage_two_checkpoint = staging / "stage_two" / "best_full_model_state.pt"
    torch.save(
        {
            "experiment_id": config["experiment_id"],
            "stage": TRAIN_GAIN,
            "model_state": stage_two_result.best_state,
            "kalmannet_source_identity": stage_two_model.gain_module.source_identity(),
        },
        stage_two_checkpoint,
    )
    _write_stage_history(
        staging / "stage_two" / "training_history.csv", stage_two_result
    )
    (staging / "config_snapshot.json").write_bytes(Path(config_path).read_bytes())
    (staging / "registry_snapshot.json").write_bytes(
        Path(registry_path).read_bytes()
    )
    elapsed = time.perf_counter() - started
    identity = {
        "schema_version": 1,
        "experiment_id": config["experiment_id"],
        "experiment_type": config["experiment_type"],
        "scientific_result": False,
        "test_year": int(config["test_year"]),
        "inner_validation_year": int(
            contract.inner_validation_year(int(config["test_year"]))
        ),
        "training_years": list(contract.training_years(int(config["test_year"]))),
        "training_sample_count": len(training_records),
        "inner_validation_sample_count": len(validation_records),
        "active_loader_opens_full_target_files": True,
        "active_loader_materializes_full_aligned_target_array": True,
        "held_out_record_construction_count": 0,
        "held_out_target_score_count": 0,
        "held_out_target_values_used_for_training_validation_selection_or_metrics": False,
        "test_split_access": "forbidden",
        "availability_mode": config["availability"]["mode"],
        "fold_tide_model_sha256": fold_tide.model_sha256,
        "fold_tide_series_sha256": fold_tide.series_sha256,
        "loader_global_tide_model_sha256": _sha256_file(loader_tide_model),
        "loader_global_tide_member_used_by_latent_adapter": False,
        "kalmannet_source_sha256": _sha256_file(kalmannet_source),
        "config_sha256": sha256_bytes(Path(config_path).read_bytes()),
        "normalization": {
            "station_mean_m": [
                float(value) for value in normalization.station_mean_m
            ],
            "station_standard_deviation_m": [
                float(value)
                for value in normalization.station_standard_deviation_m
            ],
            "tide_mean_m": float(normalization.tide_mean_m),
            "tide_standard_deviation_m": float(
                normalization.tide_standard_deviation_m
            ),
        },
        "stage_one": {
            "best_validation_loss_m": stage_one_result.best_validation_loss_m,
            "best_epoch": stage_one_result.best_epoch,
            "completed_epochs": stage_one_result.completed_epochs,
            "total_training_batches": stage_one_result.total_training_batches,
            "total_validation_batches": stage_one_result.total_validation_batches,
        },
        "stage_two": {
            "best_validation_loss_m": stage_two_result.best_validation_loss_m,
            "best_epoch": stage_two_result.best_epoch,
            "completed_epochs": stage_two_result.completed_epochs,
            "total_training_batches": stage_two_result.total_training_batches,
            "total_validation_batches": stage_two_result.total_validation_batches,
        },
        "runtime": _runtime_identity(device),
        "elapsed_seconds": float(elapsed),
        "written_utc": datetime.now(timezone.utc).isoformat(),
        "input_identity": data.input_identity,
    }
    (staging / "run_identity.json").write_bytes(_json_bytes(identity))
    manifest = {
        "schema_version": 1,
        "experiment_id": config["experiment_id"],
        "status": "technical_smoke_completed",
        "scientific_result": False,
        "held_out_target_score_count": 0,
        "artifacts": _artifact_rows(staging),
    }
    (staging / "completion_manifest.json").write_bytes(_json_bytes(manifest))
    os.replace(staging, output_root)
    return identity


def verify_completed_output(output_root: Path) -> Dict[str, object]:
    """Verify every manifest-declared byte count and digest."""

    output_root = Path(output_root)
    manifest_path = output_root / "completion_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("status") != "technical_smoke_completed":
        raise ValueError("output completion status is not technical smoke completed")
    if manifest.get("scientific_result") is not False:
        raise ValueError("technical smoke output is mislabeled as scientific")
    if manifest.get("held_out_target_score_count") != 0:
        raise ValueError("technical smoke output reports held-out target scoring")
    artifacts = manifest.get("artifacts")
    if not isinstance(artifacts, list) or not artifacts:
        raise ValueError("completion manifest contains no artifacts")
    seen = set()
    for artifact in artifacts:
        relative = artifact["relative_path"]
        if relative in seen or Path(relative).is_absolute() or ".." in Path(relative).parts:
            raise ValueError("completion manifest contains an unsafe artifact path")
        seen.add(relative)
        path = output_root / relative
        if path.stat().st_size != artifact["byte_count"]:
            raise ValueError("artifact byte count mismatch: %s" % relative)
        if _sha256_file(path) != artifact["sha256"]:
            raise ValueError("artifact SHA-256 mismatch: %s" % relative)
    return {
        "verification_status": "passed",
        "experiment_id": manifest.get("experiment_id"),
        "artifact_count": len(artifacts),
        "held_out_target_score_count": 0,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify-output", type=Path)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--registry", type=Path)
    parser.add_argument("--input-dir", type=Path)
    parser.add_argument("--loader-tide-model", type=Path)
    parser.add_argument("--kalmannet-source", type=Path)
    parser.add_argument("--output-root", type=Path)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--allow-paid-smoke", action="store_true")
    arguments = parser.parse_args()
    if arguments.verify_output is not None:
        if arguments.allow_paid_smoke:
            parser.error("--verify-output cannot be combined with --allow-paid-smoke")
        print(
            json.dumps(
                verify_completed_output(arguments.verify_output),
                indent=2,
                sort_keys=True,
            )
        )
        return 0
    if not arguments.allow_paid_smoke:
        parser.error(
            "real-data high-performance-computing smoke is blocked; pass --allow-paid-smoke only after explicit authorization"
        )
    required = {
        "--config": arguments.config,
        "--registry": arguments.registry,
        "--input-dir": arguments.input_dir,
        "--loader-tide-model": arguments.loader_tide_model,
        "--kalmannet-source": arguments.kalmannet_source,
        "--output-root": arguments.output_root,
    }
    missing = [name for name, value in required.items() if value is None]
    if missing:
        parser.error("missing required smoke arguments: %s" % ", ".join(missing))
    identity = run_registered_smoke(
        config_path=arguments.config,
        registry_path=arguments.registry,
        input_dir=arguments.input_dir,
        loader_tide_model=arguments.loader_tide_model,
        kalmannet_source=arguments.kalmannet_source,
        output_root=arguments.output_root,
        device_name=arguments.device,
    )
    print(json.dumps(identity, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
