#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Provenance-checked adapter for an explicitly supplied KalmanNet gain core.

Inputs:
    An explicit path to ``KalmanNet_nn.py`` whose Secure Hash Algorithm 256-bit
    digest matches the frozen source, followed by four finite-or-masked
    difference tensors and a six-station availability mask.

Outputs:
    A learned gain tensor with shape ``[batch,16,6]``.  Every unavailable
    observation column is exactly zero.  This module produces no files.

Command-line arguments:
    None.  The adapter is imported by the model or by synthetic tests.

The external file is loaded lazily only after path and digest verification.  It
is not copied into this repository.  The missing-observation adaptation changes
the upstream interface, so this code implements availability-gated KalmanNet
learned-gain updating rather than an unmodified upstream method.
"""

from __future__ import annotations

import hashlib
import importlib.util
from pathlib import Path
from types import SimpleNamespace
from typing import Dict, Protocol, Union

import torch
from torch import nn
from torch.nn import functional as functional


EXPECTED_KALMANNET_SHA256 = (
    "0cad52635723eaf8c4bbfc331a2d0614520363c71953f650794b4794d7aab33d"
)


class GainModuleProtocol(Protocol):
    """Interface required by the sequential data-assimilation model."""

    def reset(
        self, batch_size: int, *, device: torch.device, dtype: torch.dtype
    ) -> None:
        ...

    def gain_step(
        self,
        observation_difference: torch.Tensor,
        observation_innovation: torch.Tensor,
        state_evolution: torch.Tensor,
        previous_state_update: torch.Tensor,
        availability: torch.Tensor,
    ) -> torch.Tensor:
        ...


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _load_verified_module(source_path: Path):
    """Verify the frozen digest, then execute the external module lazily."""

    if not source_path.is_file():
        raise FileNotFoundError("KalmanNet source does not exist: %s" % source_path)
    observed_digest = _sha256(source_path)
    if observed_digest != EXPECTED_KALMANNET_SHA256:
        raise ValueError(
            "KalmanNet source SHA-256 mismatch: expected %s, observed %s"
            % (EXPECTED_KALMANNET_SHA256, observed_digest)
        )
    module_name = "_zhenjiang_pinned_kalmannet_%s" % observed_digest[:12]
    specification = importlib.util.spec_from_file_location(module_name, source_path)
    if specification is None or specification.loader is None:
        raise ImportError("cannot load verified KalmanNet source: %s" % source_path)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    if not hasattr(module, "KalmanNetNN"):
        raise ImportError("verified KalmanNet source does not export KalmanNetNN")
    return module


def _unused_state_transition(state: torch.Tensor) -> torch.Tensor:
    return state


def _unused_observation_map(state: torch.Tensor) -> torch.Tensor:
    return torch.zeros(
        state.shape[0],
        6,
        1,
        dtype=state.dtype,
        device=state.device,
    )


class PinnedKalmanNetGainAdapter(nn.Module):
    """Expose only the verified upstream four-difference gain-network path."""

    def __init__(
        self,
        source_path: Union[str, Path],
        *,
        state_dimension: int = 16,
        observation_dimension: int = 6,
        input_multiplier: int = 10,
        output_multiplier: int = 10,
    ) -> None:
        super().__init__()
        if int(state_dimension) != 16 or int(observation_dimension) != 6:
            raise ValueError("the frozen state and observation dimensions are 16 and 6")
        if int(input_multiplier) != 10 or int(output_multiplier) != 10:
            raise ValueError("the frozen KalmanNet input/output multipliers are 10 and 10")

        resolved_path = Path(source_path).expanduser().resolve()
        module = _load_verified_module(resolved_path)
        core = module.KalmanNetNN()
        core.device = torch.device("cpu")
        core.InitSystemDynamics(
            _unused_state_transition,
            _unused_observation_map,
            int(state_dimension),
            int(observation_dimension),
        )
        arguments = SimpleNamespace(
            n_batch=1,
            in_mult_KNet=int(input_multiplier),
            out_mult_KNet=int(output_multiplier),
        )
        core.InitKGainNet(
            torch.eye(state_dimension, dtype=torch.float32),
            torch.eye(state_dimension, dtype=torch.float32),
            torch.eye(observation_dimension, dtype=torch.float32),
            arguments,
        )
        for name in ("prior_Q", "prior_Sigma", "prior_S"):
            prior = getattr(core, name).clone()
            delattr(core, name)
            core.register_buffer(name, prior)

        self.core = core
        self.state_dimension = int(state_dimension)
        self.observation_dimension = int(observation_dimension)
        self.input_multiplier = int(input_multiplier)
        self.output_multiplier = int(output_multiplier)
        self._source_path = resolved_path
        self._source_byte_count = resolved_path.stat().st_size
        self._batch_size = 0

    def source_identity(self) -> Dict[str, object]:
        """Return path, byte count, and verified digest without a license claim."""

        return {
            "absolute_path": str(self._source_path),
            "byte_count": int(self._source_byte_count),
            "sha256": EXPECTED_KALMANNET_SHA256,
        }

    def reset(
        self, batch_size: int, *, device: torch.device, dtype: torch.dtype
    ) -> None:
        """Reset all three recurrent memories for an independent batch."""

        if int(batch_size) < 1:
            raise ValueError("batch size must be positive")
        if dtype != torch.float32:
            raise ValueError("the pinned upstream gain core requires float32")
        device = torch.device(device)
        self.to(device=device, dtype=dtype)
        self.core.device = device
        self.core.batch_size = int(batch_size)
        self.core.seq_len_input = 1
        self.core.init_hidden_KNet()
        self._batch_size = int(batch_size)

    def _validate_feature(
        self,
        value: torch.Tensor,
        *,
        name: str,
        feature_dimension: int,
        reference: torch.Tensor,
    ) -> None:
        if not isinstance(value, torch.Tensor) or value.shape != (
            self._batch_size,
            feature_dimension,
        ):
            raise ValueError(
                "%s must be [batch,%d]" % (name, feature_dimension)
            )
        if value.dtype != reference.dtype:
            raise ValueError("%s dtype differs from the gain core" % name)
        if value.device != reference.device:
            raise ValueError("%s device differs from the gain core" % name)

    def _availability_boolean(
        self, availability: torch.Tensor, reference: torch.Tensor
    ) -> torch.Tensor:
        if not isinstance(availability, torch.Tensor) or availability.shape != (
            self._batch_size,
            self.observation_dimension,
        ):
            raise ValueError("availability must be [batch,6]")
        if availability.device != reference.device:
            raise ValueError("availability device differs from the gain core")
        if availability.dtype == torch.bool:
            return availability
        if not bool(torch.isfinite(availability).all()) or not bool(
            ((availability == 0) | (availability == 1)).all()
        ):
            raise ValueError("availability must contain only zero or one")
        return availability.to(dtype=torch.bool)

    def gain_step(
        self,
        observation_difference: torch.Tensor,
        observation_innovation: torch.Tensor,
        state_evolution: torch.Tensor,
        previous_state_update: torch.Tensor,
        availability: torch.Tensor,
    ) -> torch.Tensor:
        """Normalize four differences, call the core, and mask gain columns.

        Unavailable observation features are replaced by finite zeros before
        Euclidean normalization.  Available observation features and both state
        features must be finite.
        """

        if self._batch_size < 1:
            raise RuntimeError("reset must be called before gain_step")
        reference = next(self.core.parameters())
        for value, name, dimension in (
            (observation_difference, "observation difference", 6),
            (observation_innovation, "observation innovation", 6),
            (state_evolution, "state evolution", 16),
            (previous_state_update, "previous state update", 16),
        ):
            self._validate_feature(
                value,
                name=name,
                feature_dimension=dimension,
                reference=reference,
            )
        availability_boolean = self._availability_boolean(availability, reference)
        if not bool(torch.isfinite(observation_difference[availability_boolean]).all()):
            raise ValueError("an available observation difference is nonfinite")
        if not bool(torch.isfinite(observation_innovation[availability_boolean]).all()):
            raise ValueError("an available observation innovation is nonfinite")
        if not bool(torch.isfinite(state_evolution).all()) or not bool(
            torch.isfinite(previous_state_update).all()
        ):
            raise ValueError("a state difference is nonfinite")

        zeros = torch.zeros_like(observation_difference)
        safe_observation_difference = torch.where(
            availability_boolean, observation_difference, zeros
        )
        safe_observation_innovation = torch.where(
            availability_boolean, observation_innovation, zeros
        )
        normalized = (
            functional.normalize(
                safe_observation_difference, p=2, dim=1, eps=1.0e-12
            ),
            functional.normalize(
                safe_observation_innovation, p=2, dim=1, eps=1.0e-12
            ),
            functional.normalize(state_evolution, p=2, dim=1, eps=1.0e-12),
            functional.normalize(
                previous_state_update, p=2, dim=1, eps=1.0e-12
            ),
        )
        gain_vector = self.core.KGain_step(*normalized)
        gain = gain_vector.reshape(
            self._batch_size, self.state_dimension, self.observation_dimension
        )
        return torch.where(
            availability_boolean[:, None, :], gain, torch.zeros_like(gain)
        )
