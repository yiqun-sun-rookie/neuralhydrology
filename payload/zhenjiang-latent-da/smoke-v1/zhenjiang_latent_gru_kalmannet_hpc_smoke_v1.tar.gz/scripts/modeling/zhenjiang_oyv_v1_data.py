"""Load and fold-partition the 2017-2024 six-station data without leakage.

The frozen loader ``load_joint_water_level_data`` verifies a 61344-row snapshot
covering 2017-2023 and would reject the current files, so this module provides
the wider window the leave-one-year-out design needs. Everything that can be
reused from the frozen modules is imported rather than restated: the sample
acceptance arithmetic, the normalisation fit, the dataset that builds model
tensors, and the astronomical tide.

What this module guarantees
---------------------------
1. The reference clock is the Datong hourly axis, which is the shortest of the
   twelve series and therefore defines the six-station common window. Every other
   file is reindexed onto it; hours a file does not carry count as unavailable.
2. A sample issued at hour t occupies [t-23, t+24]. It is assigned to a fold part
   only when every hour of that window lies inside the calendar years of that
   part, so no training sample can touch a held-out year and no test sample can
   borrow history from a training year.
3. Normalisation statistics are fitted on the training positions of the fold
   alone, and ``assert_fold_isolation`` re-derives the disjointness rather than
   trusting the construction.

Inputs
------
--input-dir       six-station model input directory
--tide-model      frozen Wusongkou tide model json
--test-year       fold to summarise when run as a script

Outputs
-------
When run as a script, a JSON summary of every fold partition on stdout. The
module writes no files of its own.

Usage
-----
python -u scripts/modeling/zhenjiang_oyv_v1_data.py --test-year 2024
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[2]
for _relative in ("scripts/modeling", "scripts/astronomical_tide", "scripts/analysis"):
    _candidate = str(PROJECT_ROOT / _relative)
    if _candidate not in sys.path:
        sys.path.insert(0, _candidate)

from water_level_joint_encoder_decoder_v2 import (  # noqa: E402
    FORECAST_LENGTH_HOURS,
    INPUT_LENGTH_HOURS,
    JointWaterLevelData,
    JointWaterLevelDataset,
    NormalizationStatistics,
    STATION_ORDER,
    SampleRecord,
)
from wusongkou_astronomical_tide_realtime_v2 import (  # noqa: E402
    load_frozen_astronomical_tide,
)

import zhenjiang_oyv_v1_contract as contract  # noqa: E402

BEIJING = timezone(timedelta(hours=8))
DEFAULT_INPUT_DIR = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "water_level_model_input_v7_beijing_realtime_verified"
)
DEFAULT_TIDE_MODEL_PATH = (
    PROJECT_ROOT
    / "results"
    / "modeling"
    / "wusongkou_astronomical_tide_v1_validation"
    / "tide_model.json"
)


@dataclass(frozen=True)
class OutOfYearData:
    """Aligned six-station values over the full common window."""

    times_beijing: tuple[datetime, ...]
    hour_year: np.ndarray
    stages_m: np.ndarray
    targets_m: np.ndarray
    stage_direction_float32: np.ndarray
    astronomical_tide_m: np.ndarray
    complete_stage: np.ndarray
    complete_target: np.ndarray
    accepted_positions: np.ndarray
    single_year_window: np.ndarray
    input_identity: dict


@dataclass(frozen=True)
class FoldPartition:
    """One leave-one-year-out partition of the accepted issue positions."""

    test_year: int
    inner_validation_year: int
    training_years: tuple[int, ...]
    training_positions: np.ndarray
    inner_validation_positions: np.ndarray
    test_positions: np.ndarray


def _read_station_columns(
    path: Path, value_column: str, flag_column: str, axis: pd.DatetimeIndex
) -> tuple[np.ndarray, np.ndarray]:
    """Return values reindexed onto the axis, and the availability mask."""
    frame = pd.read_csv(path, usecols=["time_beijing", value_column, flag_column])
    index = pd.DatetimeIndex(pd.to_datetime(frame["time_beijing"], utc=True))
    if index.has_duplicates:
        raise ValueError("duplicate timestamps in %s" % path.name)
    values = pd.to_numeric(frame[value_column], errors="coerce").to_numpy(
        dtype=np.float64
    )
    flagged = (
        frame[flag_column].astype(str).str.strip().str.lower() == "true"
    ).to_numpy()
    finite = np.isfinite(values)
    if np.any(finite & flagged):
        raise ValueError(
            "%s carries a finite value on a row flagged missing, which the "
            "frozen availability definition does not anticipate" % path.name
        )
    aligned_values = (
        pd.Series(np.where(finite & ~flagged, values, np.nan), index=index)
        .reindex(axis)
        .to_numpy(dtype=np.float64)
    )
    return aligned_values, np.isfinite(aligned_values)


def load_out_of_year_data(
    input_dir: str | Path = DEFAULT_INPUT_DIR,
    tide_model_path: str | Path = DEFAULT_TIDE_MODEL_PATH,
) -> OutOfYearData:
    """Load the twelve series onto the Datong reference axis."""
    input_dir = Path(input_dir)
    feature_paths = {
        station: input_dir
        / "realtime_features"
        / ("%s_realtime_features.csv" % station)
        for station in STATION_ORDER
    }
    target_paths = {
        station: input_dir
        / "retrospective_targets"
        / ("%s_retrospective_targets.csv" % station)
        for station in STATION_ORDER
    }
    for path in list(feature_paths.values()) + list(target_paths.values()):
        if not path.is_file():
            raise FileNotFoundError(str(path))

    input_identity = {
        str(path.relative_to(input_dir)).replace("\\", "/"): {
            "byte_count": path.stat().st_size,
            "sha256": contract.sha256_of(path),
        }
        for path in sorted(
            list(feature_paths.values()) + list(target_paths.values())
        )
    }

    reference_frame = pd.read_csv(
        feature_paths[contract.DIRECTION_STATION], usecols=["time_beijing"]
    )
    axis = pd.DatetimeIndex(
        pd.to_datetime(reference_frame["time_beijing"], utc=True)
    )
    if axis.has_duplicates or not axis.is_monotonic_increasing:
        raise ValueError("reference axis is not strictly increasing")
    spacing = np.unique(np.diff(axis.asi8))
    if spacing.shape[0] != 1 or int(spacing[0]) != 3_600_000_000_000:
        raise ValueError("reference axis is not hourly")

    hour_count = len(axis)
    beijing_index = axis.tz_convert(BEIJING)
    times_beijing = tuple(value.to_pydatetime() for value in beijing_index)
    hour_year = np.asarray(beijing_index.year, dtype=np.int64)

    stages = np.full((hour_count, len(STATION_ORDER)), np.nan, dtype=np.float64)
    targets = np.full_like(stages, np.nan)
    complete_stage = np.ones(hour_count, dtype=bool)
    complete_target = np.ones(hour_count, dtype=bool)
    for station_index, station in enumerate(STATION_ORDER):
        stage_values, stage_available = _read_station_columns(
            feature_paths[station], "STAGE", "is_missing_for_model", axis
        )
        target_values, target_available = _read_station_columns(
            target_paths[station], "TARGET_STAGE", "is_missing_for_target", axis
        )
        stages[:, station_index] = stage_values
        targets[:, station_index] = target_values
        complete_stage &= stage_available
        complete_target &= target_available

    direction_index = STATION_ORDER.index(contract.DIRECTION_STATION)
    stage_direction_float32 = stages[:, direction_index].astype(np.float32)

    frozen_tide = load_frozen_astronomical_tide(tide_model_path)
    tide_values = frozen_tide.predict(list(times_beijing))
    if tide_values.shape != (hour_count,) or not np.isfinite(tide_values).all():
        raise ValueError("astronomical tide is the wrong shape or nonfinite")

    accepted = _accepted_positions(complete_stage, complete_target)
    single_year = _single_year_window(hour_year)

    return OutOfYearData(
        times_beijing=times_beijing,
        hour_year=hour_year,
        stages_m=stages.astype(np.float32),
        targets_m=targets.astype(np.float32),
        stage_direction_float32=stage_direction_float32,
        astronomical_tide_m=tide_values,
        complete_stage=complete_stage,
        complete_target=complete_target,
        accepted_positions=accepted,
        single_year_window=single_year,
        input_identity=input_identity,
    )


def _accepted_positions(
    complete_stage: np.ndarray, complete_target: np.ndarray
) -> np.ndarray:
    """Apply the frozen sample acceptance rule over the whole window."""
    count = complete_stage.shape[0]
    stage_bad_prefix = np.concatenate(([0], np.cumsum(~complete_stage)))
    target_bad_prefix = np.concatenate(([0], np.cumsum(~complete_target)))
    first = INPUT_LENGTH_HOURS - 1
    last = count - 1 - FORECAST_LENGTH_HOURS
    positions = np.arange(first, last + 1, dtype=np.int64)
    history_bad = (
        stage_bad_prefix[positions + 1]
        - stage_bad_prefix[positions + 1 - INPUT_LENGTH_HOURS]
    )
    future_bad = (
        target_bad_prefix[positions + 1 + FORECAST_LENGTH_HOURS]
        - target_bad_prefix[positions + 1]
    )
    return positions[(history_bad == 0) & (future_bad == 0)]


def _single_year_window(hour_year: np.ndarray) -> np.ndarray:
    """Mark the issue hours whose whole [t-23, t+24] window is inside one year."""
    count = hour_year.shape[0]
    positions = np.arange(count)
    start = positions + contract.SAMPLE_WINDOW_START_OFFSET
    stop = positions + contract.SAMPLE_WINDOW_STOP_OFFSET
    inside = (start >= 0) & (stop <= count - 1)
    same_year = np.zeros(count, dtype=bool)
    valid = np.flatnonzero(inside)
    same_year[valid] = hour_year[start[valid]] == hour_year[stop[valid]]
    return same_year


def build_fold_partition(data: OutOfYearData, test_year: int) -> FoldPartition:
    """Split the accepted positions into the three parts of one fold."""
    assignment = contract.fold_assignment(test_year)
    usable = data.accepted_positions[
        data.single_year_window[data.accepted_positions]
    ]
    position_year = data.hour_year[usable]

    def part(years) -> np.ndarray:
        selected = np.isin(position_year, np.asarray(years, dtype=np.int64))
        return usable[selected]

    return FoldPartition(
        test_year=int(assignment["test_year"]),
        inner_validation_year=int(assignment["inner_validation_year"]),
        training_years=tuple(assignment["training_years"]),
        training_positions=part(assignment["training_years"]),
        inner_validation_positions=part([assignment["inner_validation_year"]]),
        test_positions=part([assignment["test_year"]]),
    )


def assert_fold_isolation(data: OutOfYearData, partition: FoldPartition) -> dict:
    """Re-derive the isolation of a fold instead of trusting its construction.

    Every hour that any training or inner-validation sample reads, whether as
    history, as tide or as target, must lie outside the test year. The check is
    performed on the hour sets themselves, not on the issue positions, because a
    24-hour history is what would carry a held-out year into training.
    """

    def touched_hours(positions: np.ndarray) -> np.ndarray:
        if positions.size == 0:
            return np.zeros(0, dtype=np.int64)
        offsets = np.arange(
            contract.SAMPLE_WINDOW_START_OFFSET,
            contract.SAMPLE_WINDOW_STOP_OFFSET + 1,
            dtype=np.int64,
        )
        return np.unique((positions[:, None] + offsets[None, :]).ravel())

    training_hours = touched_hours(partition.training_positions)
    inner_hours = touched_hours(partition.inner_validation_positions)
    test_hours = touched_hours(partition.test_positions)

    findings: list[str] = []
    if np.any(data.hour_year[training_hours] == partition.test_year):
        findings.append("a training sample reads an hour of the test year")
    if np.any(data.hour_year[inner_hours] == partition.test_year):
        findings.append("an inner validation sample reads an hour of the test year")
    if np.any(data.hour_year[training_hours] == partition.inner_validation_year):
        findings.append(
            "a training sample reads an hour of the inner validation year"
        )
    if np.any(data.hour_year[test_hours] != partition.test_year):
        findings.append("a test sample reads an hour outside the test year")
    if np.intersect1d(partition.training_positions, partition.test_positions).size:
        findings.append("training and test issue positions overlap")
    if np.intersect1d(
        partition.training_positions, partition.inner_validation_positions
    ).size:
        findings.append("training and inner validation issue positions overlap")
    if np.intersect1d(
        partition.inner_validation_positions, partition.test_positions
    ).size:
        findings.append("inner validation and test issue positions overlap")

    return {
        "test_year": partition.test_year,
        "training_sample_count": int(partition.training_positions.size),
        "inner_validation_sample_count": int(
            partition.inner_validation_positions.size
        ),
        "test_sample_count": int(partition.test_positions.size),
        "training_hours_touched": int(training_hours.size),
        "inner_validation_hours_touched": int(inner_hours.size),
        "test_hours_touched": int(test_hours.size),
        "finding_count": len(findings),
        "findings": findings,
    }


def fit_fold_normalization(
    data: OutOfYearData, partition: FoldPartition
) -> NormalizationStatistics:
    """Fit normalisation on the training positions of one fold.

    The frozen ``fit_training_normalization`` cannot be reused here. It validates
    every record against the frozen 2017-01-01 to 2022-12-31 training split, so it
    rejects any fold whose training years include 2023 or 2024, which is six of
    the eight folds. The arithmetic below is the frozen arithmetic, element for
    element: population statistics over the accepted training windows, float64
    accumulation, ddof zero, means and scales per station over the sample and hour
    axes together. Only the split validation is replaced, by a check that every
    training window lies inside the fold's own training years.
    """
    positions = np.asarray(partition.training_positions, dtype=np.int64)
    if positions.size == 0:
        raise ValueError("fold %d has no training samples" % partition.test_year)

    stages = data.stages_m.astype(np.float64)
    targets = data.targets_m.astype(np.float64)
    tide = np.asarray(data.astronomical_tide_m, dtype=np.float64)
    hour_count = stages.shape[0]
    if (
        positions.min() < INPUT_LENGTH_HOURS - 1
        or positions.max() + FORECAST_LENGTH_HOURS >= hour_count
    ):
        raise ValueError("a training position lies outside the usable window")

    history_positions = positions[:, None] + np.arange(-23, 1)[None, :]
    future_positions = positions[:, None] + np.arange(1, 25)[None, :]

    allowed = np.asarray(partition.training_years, dtype=np.int64)
    if not np.isin(data.hour_year[history_positions], allowed).all():
        raise ValueError("a training history window leaves the training years")
    if not np.isin(data.hour_year[future_positions], allowed).all():
        raise ValueError("a training forecast window leaves the training years")

    input_values = stages[history_positions]
    target_values = targets[future_positions]
    tide_values = tide[future_positions]
    if (
        not np.isfinite(input_values).all()
        or not np.isfinite(target_values).all()
        or not np.isfinite(tide_values).all()
    ):
        raise ValueError("a training window contains a nonfinite value")

    input_mean = np.mean(input_values, axis=(0, 1), dtype=np.float64)
    input_scale = np.std(input_values, axis=(0, 1), ddof=0, dtype=np.float64)
    target_mean = np.mean(target_values, axis=(0, 1), dtype=np.float64)
    target_scale = np.std(target_values, axis=(0, 1), ddof=0, dtype=np.float64)
    tide_mean = float(np.mean(tide_values, dtype=np.float64))
    tide_scale = float(np.std(tide_values, ddof=0, dtype=np.float64))
    if np.any(input_scale <= 0) or np.any(target_scale <= 0) or tide_scale <= 0:
        raise ValueError("normalisation standard deviation must be positive")

    return NormalizationStatistics(
        input_mean_m=input_mean.astype(np.float32),
        input_standard_deviation_m=input_scale.astype(np.float32),
        target_mean_m=target_mean.astype(np.float32),
        target_standard_deviation_m=target_scale.astype(np.float32),
        tide_mean_m=tide_mean,
        tide_standard_deviation_m=tide_scale,
        input_value_count_per_station=np.full(
            len(STATION_ORDER), input_values.shape[0] * input_values.shape[1]
        ),
        target_value_count_per_station=np.full(
            len(STATION_ORDER), target_values.shape[0] * target_values.shape[1]
        ),
        tide_value_count=int(tide_values.size),
    )


def build_joint_data(
    data: OutOfYearData, partition: FoldPartition
) -> JointWaterLevelData:
    """Assemble the frozen data container with fold-local normalisation."""
    training_records = tuple(
        SampleRecord(int(position), data.times_beijing[int(position)])
        for position in partition.training_positions
    )
    inner_records = tuple(
        SampleRecord(int(position), data.times_beijing[int(position)])
        for position in partition.inner_validation_positions
    )
    if not training_records:
        raise RuntimeError("fold %d has no training samples" % partition.test_year)

    times_array = np.asarray(data.times_beijing, dtype=object)
    normalization = fit_fold_normalization(data, partition)
    return JointWaterLevelData(
        times_beijing=times_array,
        stages_m=data.stages_m,
        targets_m=data.targets_m,
        astronomical_tide_m=data.astronomical_tide_m,
        normalization=normalization,
        training_records=training_records,
        validation_records=inner_records,
        station_read_audits=(),
        input_content_identities=(),
        astronomical_dependency_identities=(),
        test_target_rows_read=0,
        test_target_values_parsed=0,
        test_target_values_loaded=0,
        time_offset_error_count=0,
        future_observation_input_count=0,
    )


def build_dataset(joint: JointWaterLevelData, positions: np.ndarray):
    """Return the frozen dataset over an explicit set of issue positions."""
    records = tuple(
        SampleRecord(int(position), joint.times_beijing[int(position)])
        for position in positions
    )
    return JointWaterLevelDataset(joint, records)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", default=str(DEFAULT_INPUT_DIR))
    parser.add_argument("--tide-model", default=str(DEFAULT_TIDE_MODEL_PATH))
    parser.add_argument("--test-year", type=int, default=0)
    arguments = parser.parse_args()

    data = load_out_of_year_data(arguments.input_dir, arguments.tide_model)
    years = (
        (arguments.test_year,)
        if arguments.test_year
        else contract.CANDIDATE_FOLD_YEARS
    )
    report = {
        "experiment_id": contract.EXPERIMENT_ID,
        "hour_count": int(len(data.times_beijing)),
        "first_hour_beijing": data.times_beijing[0].isoformat(),
        "last_hour_beijing": data.times_beijing[-1].isoformat(),
        "common_valid_feature_hours": int(data.complete_stage.sum()),
        "common_valid_target_hours": int(data.complete_target.sum()),
        "accepted_issue_positions": int(data.accepted_positions.size),
        "accepted_and_single_year": int(
            data.single_year_window[data.accepted_positions].sum()
        ),
        "folds": [],
    }
    total_findings = 0
    for year in years:
        partition = build_fold_partition(data, year)
        isolation = assert_fold_isolation(data, partition)
        total_findings += isolation["finding_count"]
        isolation["training_years"] = list(partition.training_years)
        isolation["inner_validation_year"] = partition.inner_validation_year
        report["folds"].append(isolation)
    report["total_leakage_findings"] = total_findings
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if total_findings == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
