#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Immutable contract helpers for the hidden-gauge forecast experiment.

Inputs:
    docs/records/TIDAL_FLUVIAL_HIDDEN_GAUGE_V1_PREREGISTRATION.json

Outputs:
    Pure validation results and fixed station-history masks. This module does
    not train a model or write an experiment result.

Example:
    python scripts/analysis/tidal_fluvial_hidden_gauge_v1_contract.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Mapping

import torch


PROJECT_ROOT = Path(__file__).resolve().parents[2]
MODELING_DIR = PROJECT_ROOT / "scripts" / "modeling"
if str(MODELING_DIR) not in sys.path:
    sys.path.insert(0, str(MODELING_DIR))

from water_level_joint_encoder_decoder_v2 import STATION_ORDER  # noqa: E402


EXPERIMENT_FAMILY = "tidal_fluvial_hidden_gauge_v1"
TARGETS = ("zhenjiang", "jiangyin")
CONDITIONS = (
    "complete_observation",
    "hidden_target",
    "hidden_target_upstream",
    "hidden_target_downstream",
    "hidden_target_both_nearest",
    "endpoints_only",
)
SEEDS = (17, 29, 43, 57, 71, 83, 97, 109, 127, 139)
REPORT_HOURS = tuple(range(1, 11))
PRIMARY_HOURS = tuple(range(1, 7))
EXPECTED_PARAMETER_COUNT = 121_217
EXPECTED_TRAINING_RECORD_COUNT = 46_182
EXPECTED_VALIDATION_RECORD_COUNT = 8_046
EXPECTED_CONCURRENT_TRAINING_TASKS = 1
EXPECTED_RUNTIME_ENVIRONMENT = {
    "python_executable": r"C:\Users\yiqun\anaconda3\python.exe",
    "python_version": "3.11.5",
    "operating_system": "Windows-10-10.0.26200-SP0",
    "numpy_version": "1.26.4",
    "pandas_version": "2.3.3",
    "scipy_version": "1.17.0",
    "scikit_learn_version": "1.7.2",
    "psutil_version": "5.9.0",
    "threadpoolctl_version": "3.6.0",
    "threadpool_configuration_sha256": (
        "7beff26b927ce078855ac5d91b3cfe5b29be6c70d4f5fd37a532d16f92ceb5d5"
    ),
    "torch_version": "2.2.2",
    "cuda_version": "12.1",
    "cudnn_version": 8801,
    "graphics_processor_name": "NVIDIA GeForce RTX 4070 Ti",
    "graphics_processor_capability": [8, 9],
    "graphics_processor_driver_version": "595.95",
    "graphics_processor_unique_identifier": (
        "GPU-94fe92b0-8d2c-b688-5b39-0fc3939ca8a3"
    ),
}

_CONDITION_STATIONS = {
    "zhenjiang": {
        "complete_observation": tuple(STATION_ORDER),
        "hidden_target": (
            "datong",
            "nanjing",
            "jiangyin",
            "xuliujing",
            "wusongkou",
        ),
        "hidden_target_upstream": (
            "datong",
            "jiangyin",
            "xuliujing",
            "wusongkou",
        ),
        "hidden_target_downstream": (
            "datong",
            "nanjing",
            "xuliujing",
            "wusongkou",
        ),
        "hidden_target_both_nearest": (
            "datong",
            "xuliujing",
            "wusongkou",
        ),
        "endpoints_only": ("datong", "wusongkou"),
    },
    "jiangyin": {
        "complete_observation": tuple(STATION_ORDER),
        "hidden_target": (
            "datong",
            "nanjing",
            "zhenjiang",
            "xuliujing",
            "wusongkou",
        ),
        "hidden_target_upstream": (
            "datong",
            "nanjing",
            "xuliujing",
            "wusongkou",
        ),
        "hidden_target_downstream": (
            "datong",
            "nanjing",
            "zhenjiang",
            "wusongkou",
        ),
        "hidden_target_both_nearest": (
            "datong",
            "nanjing",
            "wusongkou",
        ),
        "endpoints_only": ("datong", "wusongkou"),
    },
}


def kept_stations(target: str, condition: str) -> tuple[str, ...]:
    """Return the exact river-ordered stations retained by one condition."""
    if target not in TARGETS:
        raise ValueError(f"unknown target: {target}")
    if condition not in CONDITIONS:
        raise ValueError(f"unknown condition: {condition}")
    return _CONDITION_STATIONS[target][condition]


def build_history_mask(target: str, condition: str) -> torch.Tensor:
    """Build a `[1, 1, 6]` standardized-history mask."""
    kept = set(kept_stations(target, condition))
    return torch.tensor(
        [float(station in kept) for station in STATION_ORDER],
        dtype=torch.float32,
    ).reshape(1, 1, len(STATION_ORDER))


def _require_exact(
    payload: Mapping[str, object],
    key: str,
    expected: object,
    message: str,
) -> None:
    if payload.get(key) != expected:
        raise ValueError(message)


def validate_preregistration(payload: Mapping[str, object]) -> None:
    """Reject any experiment contract that differs from the frozen design."""
    _require_exact(
        payload,
        "experiment_family",
        EXPERIMENT_FAMILY,
        "experiment family changed",
    )
    _require_exact(
        payload,
        "targets",
        list(TARGETS),
        "target set changed",
    )
    _require_exact(
        payload,
        "conditions",
        list(CONDITIONS),
        "condition set changed",
    )
    _require_exact(
        payload,
        "station_order",
        list(STATION_ORDER),
        "station order changed",
    )
    training = payload.get("training")
    if not isinstance(training, Mapping):
        raise ValueError("training contract missing")
    if training.get("seeds") != list(SEEDS):
        raise ValueError("ten paired seeds changed")
    expected_training = {
        "history_hours": 24,
        "reported_forecast_hours": list(REPORT_HOURS),
        "loss_forecast_hours": list(REPORT_HOURS),
        "target_specific_loss": True,
        "batch_size": 128,
        "maximum_epochs": 36,
        "patience_epochs": 4,
        "minimum_delta_m": 0.0001,
        "learning_rate": 0.001,
        "weight_decay": 0.0001,
        "gradient_clip_norm": 1.0,
        "optimizer": "AdamW",
        "model_structure": "RiverOrderTransformerEncoderDecoder",
        "trainable_parameter_count": EXPECTED_PARAMETER_COUNT,
    }
    for key, expected in expected_training.items():
        if training.get(key) != expected:
            raise ValueError(f"training field changed: {key}")
    information = payload.get("information_timing")
    if not isinstance(information, Mapping):
        raise ValueError("information timing contract missing")
    if information.get("future_observed_neighbor_stage_allowed") is not False:
        raise ValueError("future observed neighbor water level is forbidden")
    if information.get("target_history_allowed_when_hidden") is not False:
        raise ValueError("hidden target history must be unavailable")
    if information.get("future_astronomical_tide_allowed") is not True:
        raise ValueError("future astronomical tide rule changed")
    if information.get("future_astronomical_tide_hours_available") != list(
        range(1, 25)
    ):
        raise ValueError("future astronomical tide information set changed")
    data = payload.get("data")
    if not isinstance(data, Mapping):
        raise ValueError("data contract missing")
    if data.get("training_record_count") != EXPECTED_TRAINING_RECORD_COUNT:
        raise ValueError("training record count changed")
    if data.get("validation_record_count") != EXPECTED_VALIDATION_RECORD_COUNT:
        raise ValueError("validation record count changed")
    evaluation = payload.get("evaluation")
    if not isinstance(evaluation, Mapping):
        raise ValueError("evaluation contract missing")
    if evaluation.get("report_hours") != list(REPORT_HOURS):
        raise ValueError("report hours changed")
    if evaluation.get("primary_hours") != list(PRIMARY_HOURS):
        raise ValueError("primary hours changed")
    if evaluation.get("bootstrap_resamples") != 20_000:
        raise ValueError("bootstrap count changed")
    if evaluation.get("bootstrap_seed") != 20_260_731:
        raise ValueError("bootstrap seed changed")
    execution = payload.get("execution")
    if not isinstance(execution, Mapping):
        raise ValueError("execution contract missing")
    if (
        execution.get("maximum_concurrent_training_tasks")
        != EXPECTED_CONCURRENT_TRAINING_TASKS
    ):
        raise ValueError("training must remain serial")
    if execution.get("registered_task_count") != 120:
        raise ValueError("registered task count changed")
    if payload.get("runtime_environment_contract") != (
        EXPECTED_RUNTIME_ENVIRONMENT
    ):
        raise ValueError("runtime environment contract changed")
    resource = payload.get("resource_budget")
    if not isinstance(resource, Mapping):
        raise ValueError("resource budget missing")
    expected_resource = {
        "estimated_peak_memory_bytes": 3_613_081_600,
        "memory_safety_margin_bytes": 1_806_540_800,
        "required_available_memory_bytes": 5_419_622_400,
        "estimated_peak_graphics_memory_bytes": 2_563_768_320,
        "graphics_memory_safety_margin_bytes": 640_942_080,
        "required_free_graphics_memory_bytes": 3_204_710_400,
    }
    for key, expected in expected_resource.items():
        if resource.get(key) != expected:
            raise ValueError(f"resource field changed: {key}")
    if payload.get("status") != "preregistered_training_unauthorized":
        raise ValueError("preregistration status changed")


def load_preregistration(path: str | Path) -> dict[str, object]:
    """Load and validate the canonical preregistration JSON."""
    path = Path(path)
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("preregistration root must be an object")
    validate_preregistration(payload)
    return payload


def main() -> None:
    path = (
        PROJECT_ROOT
        / "docs"
        / "records"
        / "TIDAL_FLUVIAL_HIDDEN_GAUGE_V1_PREREGISTRATION.json"
    )
    payload = load_preregistration(path)
    print(
        json.dumps(
            {
                "experiment_family": payload["experiment_family"],
                "targets": payload["targets"],
                "conditions": payload["conditions"],
                "status": "contract_valid",
            },
            ensure_ascii=False,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
