"""Frozen contract for the leave-one-year-out stage-direction validation.

This module is the single source of truth for the experiment registered in
``docs/records/ZHENJIANG_OYV_LEAVE_ONE_YEAR_OUT_DIRECTION_VALIDATION_V1_PREREGISTRATION.json``.
Nothing here may be changed once a forecast error has been produced.

Design points that differ from the earlier frozen family, and why
----------------------------------------------------------------
The earlier contract pinned the runtime to one physical graphics card by its
unique identifier. Array execution across cluster nodes is impossible under such
a pin, so this contract requires equality on the card model, compute capability,
driver version and library versions, and records the card identifier as
provenance only. SLURM array job 205525 justified the relaxation: nine tasks
across two nodes and two physical cards, including three concurrent tasks on one
card, produced one model state digest and one prediction digest.

The threadpool digest is normalised before comparison. The cluster is
heterogeneous in core count, so the raw threadpoolctl digest embeds a
node-dependent ``num_threads`` and an absolute ``filepath`` and cannot be equal
across nodes. The normalised digest drops those two keys and therefore pins the
loaded library set and versions, which is the part that could affect numerics.

The condition-to-station map, the history mask, the seeds and the model
architecture are imported from the earlier frozen modules rather than restated,
so the two experiments cannot silently diverge.
"""

from __future__ import annotations

import hashlib
import json
import platform
import subprocess
import sys
from pathlib import Path
from typing import Mapping, Sequence

import numpy as np
import torch

PROJECT_ROOT = Path(__file__).resolve().parents[2]
ANALYSIS_DIR = PROJECT_ROOT / "scripts" / "analysis"
MODELING_DIR = PROJECT_ROOT / "scripts" / "modeling"
for _directory in (ANALYSIS_DIR, MODELING_DIR):
    if str(_directory) not in sys.path:
        sys.path.insert(0, str(_directory))

from tidal_fluvial_hidden_gauge_v1_contract import (  # noqa: E402
    CONDITIONS as FROZEN_CONDITIONS,
    SEEDS,
    build_history_mask,
    kept_stations,
)
from water_level_joint_encoder_decoder_v2 import (  # noqa: E402
    FORECAST_LENGTH_HOURS,
    INPUT_LENGTH_HOURS,
    STATION_ORDER,
)

EXPERIMENT_ID = "zhenjiang_oyv_leave_one_year_out_direction_validation_v1"
SCHEMA_VERSION = 1
PREREGISTRATION_RELATIVE_PATH = (
    "docs/records/"
    "ZHENJIANG_OYV_LEAVE_ONE_YEAR_OUT_DIRECTION_VALIDATION_V1_PREREGISTRATION.json"
)

# --- experimental matrix -------------------------------------------------

CANDIDATE_FOLD_YEARS = (2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024)
TARGETS = ("zhenjiang", "jiangyin")
PRIMARY_TARGET = "zhenjiang"
REPLICATION_TARGET = "jiangyin"
REFERENCE_CONDITION = "hidden_target"
REDUCED_CONDITIONS = ("hidden_target_both_nearest", "endpoints_only")
CONDITIONS = (REFERENCE_CONDITION,) + REDUCED_CONDITIONS
EXPECTED_TRAINING_TASK_COUNT = (
    len(CANDIDATE_FOLD_YEARS) * len(TARGETS) * len(CONDITIONS) * len(SEEDS)
)

# --- windows, thresholds and events --------------------------------------

PRIMARY_HORIZON_HOURS = tuple(range(1, 7))
REPORT_HORIZON_HOURS = tuple(range(1, 11))
HIGH_STAGE_THRESHOLD_M = 7.812333333333
DIRECTION_THRESHOLD_M = 0.10
DIRECTION_REFERENCE_LAG_HOURS = 23
DIRECTION_STATION = "datong"
EVENT_CLOSURE_HOURS = 24
SAMPLE_WINDOW_START_OFFSET = -(INPUT_LENGTH_HOURS - 1)
SAMPLE_WINDOW_STOP_OFFSET = FORECAST_LENGTH_HOURS

# --- optimisation, carried over unchanged --------------------------------

FORMAL_BATCH_SIZE = 128
FORMAL_MAXIMUM_EPOCHS = 36
FORMAL_PATIENCE_EPOCHS = 4
FORMAL_MINIMUM_DELTA_M = 0.0001
FORMAL_GRADIENT_CLIP_NORM = 1.0
FORMAL_LEARNING_RATE = 0.001
FORMAL_WEIGHT_DECAY = 0.0001
FORMAL_ADAM_BETAS = (0.9, 0.999)
FORMAL_ADAM_EPSILON = 1e-8
# The frozen trainer uses AdamW with amsgrad and fused both disabled.
FORMAL_OPTIMIZER = "AdamW"
FORMAL_AMSGRAD = False
FORMAL_FUSED = False
EXPECTED_PARAMETER_COUNT = 121_217

# --- inference -----------------------------------------------------------

MINIMUM_PAIRED_EVENT_COUNT = 10
MINIMUM_EFFECT_M = 0.010
FAMILY_ALPHA = 0.05
BOOTSTRAP_DRAWS = 10_000
BOOTSTRAP_SEED = 20260819
MINIMUM_POSITIVE_FOLD_YEARS = 6
CAUSAL_SENSITIVITY_FOLD_YEARS = (2020, 2021, 2022, 2023, 2024)

# --- runtime environment, measured on the cluster ------------------------

EXPECTED_RUNTIME_ENVIRONMENT_EQUALITY: dict[str, object] = {
    "python_version": "3.11.13",
    "operating_system": "Linux-5.14.0-503.14.1.el9_5.x86_64-x86_64-with-glibc2.34",
    "numpy_version": "2.3.3",
    "pandas_version": "2.3.2",
    "scipy_version": "1.16.2",
    "scikit_learn_version": "1.7.2",
    "psutil_version": "7.0.0",
    "threadpoolctl_version": "3.6.0",
    "torch_version": "2.4.0",
    "cuda_version": "12.1",
    "cudnn_version": 90100,
    "graphics_processor_name": "NVIDIA GeForce RTX 3090",
    "graphics_processor_capability": [8, 6],
    "graphics_processor_driver_version": "580.76.05",
    "graphics_processor_total_memory_bytes": 25296044032,
    "threadpool_row_count": 3,
    # Measured equal on ngu008 (96 cores) and ngu011 (32 cores) by jobs 205553
    # and 205555, while their raw digests differ. Libraries: two libgomp openmp
    # entries and libmkl_rt mkl 2022.1-Product.
    "normalised_threadpool_configuration_sha256": (
        "bd2d2073fc6f948a7af98ab30ed5debfafd2e0c5ceb02688141c56ad6e308a46"
    ),
}

RECORDED_ONLY_RUNTIME_FIELDS = (
    "python_executable",
    "graphics_processor_unique_identifier",
    "raw_threadpool_configuration_sha256",
    "threadpool_libraries",
    "node_name",
    "slurm_job_id",
    "slurm_array_task_id",
)


def inner_validation_year(test_year: int) -> int:
    """Return the inner validation year for one outer fold.

    The rule is deterministic and uses no outcome information: the latest
    candidate year strictly earlier than the test year, or, when the test year is
    the earliest candidate, the earliest candidate year later than it.
    """
    if test_year not in CANDIDATE_FOLD_YEARS:
        raise ValueError("test year is not a candidate fold year: %r" % test_year)
    earlier = [year for year in CANDIDATE_FOLD_YEARS if year < test_year]
    if earlier:
        return max(earlier)
    later = [year for year in CANDIDATE_FOLD_YEARS if year > test_year]
    if not later:
        raise ValueError("no inner validation year exists for %r" % test_year)
    return min(later)


def training_years(test_year: int) -> tuple[int, ...]:
    """Return the six training years for one outer fold."""
    excluded = {test_year, inner_validation_year(test_year)}
    years = tuple(year for year in CANDIDATE_FOLD_YEARS if year not in excluded)
    if len(years) != len(CANDIDATE_FOLD_YEARS) - 2:
        raise RuntimeError("training year count changed for fold %r" % test_year)
    return years


def fold_assignment(test_year: int) -> dict[str, object]:
    """Return the full year partition for one outer fold."""
    return {
        "test_year": int(test_year),
        "inner_validation_year": inner_validation_year(test_year),
        "training_years": list(training_years(test_year)),
    }


def all_fold_assignments() -> tuple[dict[str, object], ...]:
    """Return every fold partition, in candidate year order."""
    return tuple(fold_assignment(year) for year in CANDIDATE_FOLD_YEARS)


def task_id(test_year: int, target: str, condition: str, seed: int) -> str:
    """Return the registered identifier of one training task."""
    if target not in TARGETS:
        raise ValueError("unknown target: %r" % target)
    if condition not in CONDITIONS:
        raise ValueError("unknown condition: %r" % condition)
    if seed not in SEEDS:
        raise ValueError("unknown seed: %r" % seed)
    if test_year not in CANDIDATE_FOLD_YEARS:
        raise ValueError("unknown fold year: %r" % test_year)
    return "zhenjiang_oyv_v1__fold_%d__%s__%s__seed_%d" % (
        test_year,
        target,
        condition,
        seed,
    )


def enumerate_tasks() -> tuple[dict[str, object], ...]:
    """Return every registered training task, in a fixed order."""
    tasks = []
    for test_year in CANDIDATE_FOLD_YEARS:
        for target in TARGETS:
            for condition in CONDITIONS:
                for seed in SEEDS:
                    tasks.append(
                        {
                            "task_id": task_id(test_year, target, condition, seed),
                            "test_year": int(test_year),
                            "target": target,
                            "condition": condition,
                            "seed": int(seed),
                        }
                    )
    if len(tasks) != EXPECTED_TRAINING_TASK_COUNT:
        raise RuntimeError("task enumeration count changed")
    return tuple(tasks)


def _threadpool_digests() -> dict[str, object]:
    """Return the raw and normalised threadpool digests and the library list."""
    import threadpoolctl

    rows = sorted(
        threadpoolctl.threadpool_info(),
        key=lambda row: (str(row.get("prefix")), str(row.get("filepath"))),
    )
    raw_material = (
        json.dumps(rows, sort_keys=True, separators=(",", ":")) + "\n"
    ).encode("utf-8")
    normalised = sorted(
        (
            {
                key: value
                for key, value in row.items()
                if key not in ("num_threads", "filepath")
            }
            for row in rows
        ),
        key=lambda row: (
            str(row.get("prefix")),
            str(row.get("internal_api")),
            str(row.get("version")),
        ),
    )
    normalised_material = (
        json.dumps(normalised, sort_keys=True, separators=(",", ":")) + "\n"
    ).encode("utf-8")
    return {
        "raw_threadpool_configuration_sha256": hashlib.sha256(
            raw_material
        ).hexdigest(),
        "normalised_threadpool_configuration_sha256": hashlib.sha256(
            normalised_material
        ).hexdigest(),
        "threadpool_row_count": len(rows),
        "threadpool_libraries": [
            "%s/%s/%s"
            % (row.get("prefix"), row.get("internal_api"), row.get("version"))
            for row in normalised
        ],
    }


def runtime_identity() -> dict[str, object]:
    """Capture the exact numerical software and graphics environment."""
    import os

    import pandas as pd
    import psutil
    import scipy
    import sklearn

    if not torch.cuda.is_available():
        raise RuntimeError("runtime environment requires cuda:0")
    properties = torch.cuda.get_device_properties(0)
    completed = subprocess.run(
        [
            "nvidia-smi",
            "--query-gpu=driver_version,uuid",
            "--format=csv,noheader,nounits",
            "--id=0",
        ],
        check=True,
        capture_output=True,
        text=True,
        timeout=30,
    )
    parts = [part.strip() for part in completed.stdout.strip().split(",")]
    if len(parts) != 2:
        raise RuntimeError("graphics driver identity could not be parsed")

    identity: dict[str, object] = {
        "python_executable": str(Path(sys.executable).resolve()),
        "python_version": platform.python_version(),
        "operating_system": platform.platform(),
        "numpy_version": np.__version__,
        "pandas_version": pd.__version__,
        "scipy_version": scipy.__version__,
        "scikit_learn_version": sklearn.__version__,
        "psutil_version": psutil.__version__,
        "torch_version": torch.__version__,
        "cuda_version": torch.version.cuda,
        "cudnn_version": torch.backends.cudnn.version(),
        "graphics_processor_name": properties.name,
        "graphics_processor_capability": list(torch.cuda.get_device_capability(0)),
        "graphics_processor_total_memory_bytes": int(properties.total_memory),
        "graphics_processor_driver_version": parts[0],
        "graphics_processor_unique_identifier": parts[1],
        "node_name": platform.node(),
        "slurm_job_id": os.environ.get("SLURM_JOB_ID", "none"),
        "slurm_array_task_id": os.environ.get("SLURM_ARRAY_TASK_ID", "none"),
    }
    import threadpoolctl

    identity["threadpoolctl_version"] = threadpoolctl.__version__
    identity.update(_threadpool_digests())
    return identity


def require_frozen_runtime_environment() -> dict[str, object]:
    """Reject execution when any equality-required environment field drifts.

    Fields listed in RECORDED_ONLY_RUNTIME_FIELDS are captured for provenance and
    are deliberately not compared, because they legitimately differ between
    cluster nodes without affecting the numerical result.
    """
    identity = runtime_identity()
    differences = {}
    for name, expected in EXPECTED_RUNTIME_ENVIRONMENT_EQUALITY.items():
        observed = identity.get(name)
        if observed != expected:
            differences[name] = {"expected": expected, "observed": observed}
    if differences:
        raise RuntimeError(
            "runtime environment differs from preregistration: "
            + json.dumps(differences, sort_keys=True)
        )
    return identity


def apply_deterministic_settings(seed: int) -> None:
    """Apply the frozen deterministic random-number and kernel settings."""
    import os
    import random

    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.use_deterministic_algorithms(True, warn_only=False)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    if hasattr(torch.backends.cuda.matmul, "allow_tf32"):
        torch.backends.cuda.matmul.allow_tf32 = False
    if hasattr(torch.backends.cudnn, "allow_tf32"):
        torch.backends.cudnn.allow_tf32 = False


def sha256_of(path: str | Path) -> str:
    """Return the SHA-256 of a file read in binary chunks."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_contract_self_consistency() -> dict[str, object]:
    """Check the internal invariants a static audit will re-derive."""
    findings: list[str] = []
    if set(CONDITIONS) - set(FROZEN_CONDITIONS):
        findings.append("a condition is not present in the earlier frozen contract")
    if REFERENCE_CONDITION not in FROZEN_CONDITIONS:
        findings.append("reference condition is not a frozen condition")
    if len(set(SEEDS)) != len(SEEDS):
        findings.append("seed list contains a duplicate")
    if EXPECTED_TRAINING_TASK_COUNT != 480:
        findings.append("task count is not 480")
    for year in CANDIDATE_FOLD_YEARS:
        assignment = fold_assignment(year)
        parts = (
            {assignment["test_year"]},
            {assignment["inner_validation_year"]},
            set(assignment["training_years"]),
        )
        if set.union(*parts) != set(CANDIDATE_FOLD_YEARS):
            findings.append("fold %d does not cover every candidate year" % year)
        if sum(len(part) for part in parts) != len(CANDIDATE_FOLD_YEARS):
            findings.append("fold %d has overlapping parts" % year)
    if set(CAUSAL_SENSITIVITY_FOLD_YEARS) - set(CANDIDATE_FOLD_YEARS):
        findings.append("causal sensitivity subset is not a subset of the folds")
    for year in CAUSAL_SENSITIVITY_FOLD_YEARS:
        earlier = [other for other in CANDIDATE_FOLD_YEARS if other < year]
        if len(earlier) < 3:
            findings.append(
                "causal sensitivity year %d has fewer than three earlier years" % year
            )
    if not 0 < MINIMUM_EFFECT_M < 1:
        findings.append("minimum effect is outside a plausible metre range")
    return {
        "experiment_id": EXPERIMENT_ID,
        "task_count": EXPECTED_TRAINING_TASK_COUNT,
        "fold_count": len(CANDIDATE_FOLD_YEARS),
        "finding_count": len(findings),
        "findings": findings,
    }


def main() -> int:
    """Print the contract self-check, for use by the static audit."""
    report = validate_contract_self_consistency()
    report["fold_assignments"] = list(all_fold_assignments())
    report["station_order"] = list(STATION_ORDER)
    report["kept_stations"] = {
        "%s/%s" % (target, condition): list(kept_stations(target, condition))
        for target in TARGETS
        for condition in CONDITIONS
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["finding_count"] == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
