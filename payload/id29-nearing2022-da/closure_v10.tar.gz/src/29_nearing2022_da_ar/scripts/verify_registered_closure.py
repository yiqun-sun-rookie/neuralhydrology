"""Fail-closed completeness and hash audit for the registered Nearing et al. closure."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
from typing import Iterable

import pandas as pd


SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from aggregate_registered_results import _registered_run  # noqa: E402
from audit_formal_artifacts import sha256_file  # noqa: E402
from prepare_evaluation_run import resolve_source_run  # noqa: E402


EVALUATION_AGGREGATION_FILES = (
    "aggregation_summary.json",
    "per_basin_metrics.csv",
    "median_matrix.csv",
    "time_split_vs_author.csv",
    "basin_split_vs_author.csv",
)
HYPERPARAMETER_AGGREGATION_FILES = (
    "selection_summary.json",
    "per_basin_metrics.csv",
    "scores.csv",
)


def _read_registry(path: Path, id_column: str) -> pd.DataFrame:
    registry = pd.read_csv(path, keep_default_na=False, dtype=str)
    if id_column not in registry or not registry[id_column].is_unique:
        raise ValueError(f"Registry {path} lacks a unique {id_column} column")
    return registry


def _metrics_path(result_path: Path) -> Path:
    if result_path.name == "test_results.p":
        return result_path.with_name("test_metrics.csv")
    if result_path.name == "test_results_data_assimilation.p":
        return result_path.with_name("test_metrics_data_assimilation.csv")
    raise ValueError(f"Unsupported registered result filename: {result_path.name}")


def _record_artifact(
    artifacts: dict[Path, list[dict[str, str]]],
    missing: list[dict[str, str]],
    path: Path,
    coordinate_type: str,
    coordinate_id: str,
    role: str,
) -> None:
    path = Path(path).resolve()
    binding = {
        "coordinate_type": coordinate_type,
        "coordinate_id": coordinate_id,
        "role": role,
    }
    if path.is_file():
        artifacts.setdefault(path, []).append(binding)
    else:
        missing.append({**binding, "path": str(path)})


def _record_resolution_failure(
    missing: list[dict[str, str]], coordinate_type: str, coordinate_id: str, exc: Exception
) -> None:
    missing.append({
        "coordinate_type": coordinate_type,
        "coordinate_id": coordinate_id,
        "role": "run_resolution",
        "path": "",
        "error": f"{type(exc).__name__}: {exc}",
    })


def audit_registered_closure(
    repo_root: Path,
    training_registry_path: Path,
    evaluation_registry_path: Path,
    hyperparameter_registry_path: Path,
    evaluation_aggregation_dir: Path,
    hyperparameter_aggregation_dir: Path,
    *,
    expected_training: int = 46,
    expected_evaluations: int = 180,
    expected_hyperparameters: int = 660,
    extra_files: Iterable[Path] = (),
) -> dict[str, object]:
    """Bind every registered coordinate to the files required for a defensible reproduction."""
    repo_root = Path(repo_root).resolve()
    training_registry_path = Path(training_registry_path).resolve()
    evaluation_registry_path = Path(evaluation_registry_path).resolve()
    hyperparameter_registry_path = Path(hyperparameter_registry_path).resolve()
    training = _read_registry(training_registry_path, "exp_id")
    evaluations = _read_registry(evaluation_registry_path, "eval_id")
    hyperparameters = _read_registry(hyperparameter_registry_path, "eval_id")
    counts = {
        "training": len(training),
        "evaluations": len(evaluations),
        "hyperparameters": len(hyperparameters),
    }
    expected_counts = {
        "training": expected_training,
        "evaluations": expected_evaluations,
        "hyperparameters": expected_hyperparameters,
    }
    missing: list[dict[str, str]] = []
    for name, expected in expected_counts.items():
        if counts[name] != expected:
            missing.append({
                "coordinate_type": "registry",
                "coordinate_id": name,
                "role": "coordinate_count",
                "path": "",
                "error": f"expected {expected}, found {counts[name]}",
            })

    artifacts: dict[Path, list[dict[str, str]]] = {}
    for path, identifier in (
        (training_registry_path, "training"),
        (evaluation_registry_path, "evaluations"),
        (hyperparameter_registry_path, "hyperparameters"),
    ):
        _record_artifact(artifacts, missing, path, "registry", identifier, "registry")

    for _, row in training.iterrows():
        identifier = row["exp_id"]
        try:
            run = resolve_source_run(repo_root, training, identifier)
        except (FileNotFoundError, KeyError, ValueError) as exc:
            _record_resolution_failure(missing, "training", identifier, exc)
            continue
        roles = {
            "run_config": run / "config.yml",
            "checkpoint_epoch030": run / "model_epoch030.pt",
            "training_log": run / "output.log",
            "train_data_scaler": run / "train_data" / "train_data_scaler.yml",
        }
        for role, path in roles.items():
            _record_artifact(artifacts, missing, path, "training", identifier, role)

    for _, row in evaluations.iterrows():
        identifier = row["eval_id"]
        try:
            run = _registered_run(repo_root, training, row)
        except (FileNotFoundError, KeyError, ValueError) as exc:
            _record_resolution_failure(missing, "evaluation", identifier, exc)
            continue
        result = run / row["result_file"]
        roles = {
            "run_config": run / "config.yml",
            "checkpoint_epoch030": run / "model_epoch030.pt",
            "evaluation_log": run / "output.log",
            "prediction": result,
            "metrics": _metrics_path(result),
        }
        for role, path in roles.items():
            _record_artifact(artifacts, missing, path, "evaluation", identifier, role)

    for _, row in hyperparameters.iterrows():
        identifier = row["eval_id"]
        run = Path(row["run_dir"])
        run = run if run.is_absolute() else repo_root / run
        result = run / row["result_file"]
        roles = {
            "run_config": run / "config.yml",
            "checkpoint_epoch030": run / "model_epoch030.pt",
            "evaluation_log": run / "output.log",
            "prediction": result,
            "metrics": _metrics_path(result),
        }
        for role, path in roles.items():
            _record_artifact(artifacts, missing, path, "hyperparameter", identifier, role)

    for name in EVALUATION_AGGREGATION_FILES:
        _record_artifact(
            artifacts,
            missing,
            Path(evaluation_aggregation_dir) / name,
            "aggregation",
            "evaluations",
            name,
        )
    for name in HYPERPARAMETER_AGGREGATION_FILES:
        _record_artifact(
            artifacts,
            missing,
            Path(hyperparameter_aggregation_dir) / name,
            "aggregation",
            "hyperparameters",
            name,
        )
    for index, path in enumerate(extra_files):
        _record_artifact(artifacts, missing, path, "provenance", f"extra_{index:03d}", "provenance")

    artifact_rows = [
        {"path": str(path), "bindings": sorted(bindings, key=lambda item: tuple(item.values()))}
        for path, bindings in sorted(artifacts.items(), key=lambda item: item[0].as_posix())
    ]
    return {
        "schema": "nearing2022-registered-closure-audit-v1",
        "complete": not missing,
        "counts": counts,
        "expected_counts": expected_counts,
        "missing": missing,
        "artifacts": artifact_rows,
    }


def write_closure_manifest(audit: dict[str, object], root: Path, output_path: Path) -> dict[str, object]:
    """Hash a complete audit without accepting partial coordinates or files outside the closure root."""
    if not audit.get("complete"):
        raise ValueError("Refusing to hash an incomplete registered closure")
    root = Path(root).resolve()
    output_path = Path(output_path).resolve()
    entries: list[dict[str, object]] = []
    for artifact in audit["artifacts"]:
        path = Path(artifact["path"]).resolve()
        try:
            relative = path.relative_to(root)
        except ValueError as exc:
            raise ValueError(f"Artifact is outside closure root: {path}") from exc
        entries.append({
            "path": relative.as_posix(),
            "bytes": path.stat().st_size,
            "sha256": sha256_file(path),
            "bindings": artifact["bindings"],
        })
    relative_root = Path(os.path.relpath(root, output_path.parent)).as_posix()
    manifest = {
        "schema": "nearing2022-registered-closure-manifest-v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "root": relative_root,
        "counts": audit["counts"],
        "file_count": len(entries),
        "total_bytes": sum(int(entry["bytes"]) for entry in entries),
        "files": entries,
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = output_path.with_suffix(output_path.suffix + ".tmp")
    temporary.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    temporary.replace(output_path)
    return manifest


def verify_closure_manifest(manifest_path: Path) -> dict[str, object]:
    manifest_path = Path(manifest_path).resolve()
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("schema") != "nearing2022-registered-closure-manifest-v1":
        raise ValueError(f"Unsupported closure manifest schema in {manifest_path}")
    root = (manifest_path.parent / manifest["root"]).resolve()
    missing: list[str] = []
    size_mismatches: list[str] = []
    hash_mismatches: list[str] = []
    for entry in manifest["files"]:
        relative = entry["path"]
        path = root / relative
        if not path.is_file():
            missing.append(relative)
            continue
        if path.stat().st_size != int(entry["bytes"]):
            size_mismatches.append(relative)
        if sha256_file(path) != entry["sha256"]:
            hash_mismatches.append(relative)
    return {
        "ok": not missing and not size_mismatches and not hash_mismatches,
        "missing_files": sorted(missing),
        "size_mismatches": sorted(size_mismatches),
        "hash_mismatches": sorted(hash_mismatches),
    }


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, required=True)
    parser.add_argument("--training-registry", type=Path, required=True)
    parser.add_argument("--evaluation-registry", type=Path, required=True)
    parser.add_argument("--hyperparameter-registry", type=Path, required=True)
    parser.add_argument("--evaluation-aggregation-dir", type=Path, required=True)
    parser.add_argument("--hyperparameter-aggregation-dir", type=Path, required=True)
    parser.add_argument("--manifest-output", type=Path)
    parser.add_argument("--extra-file", type=Path, action="append", default=[])
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    audit = audit_registered_closure(
        args.repo_root,
        args.training_registry,
        args.evaluation_registry,
        args.hyperparameter_registry,
        args.evaluation_aggregation_dir,
        args.hyperparameter_aggregation_dir,
        extra_files=args.extra_file,
    )
    summary = {
        "complete": audit["complete"],
        "counts": audit["counts"],
        "missing_count": len(audit["missing"]),
        "missing_first": audit["missing"][:10],
    }
    if not audit["complete"]:
        print(json.dumps(summary, indent=2, sort_keys=True))
        return 2
    if args.manifest_output is not None:
        manifest = write_closure_manifest(audit, args.repo_root, args.manifest_output)
        verification = verify_closure_manifest(args.manifest_output)
        summary.update({
            "manifest": str(args.manifest_output),
            "file_count": manifest["file_count"],
            "total_bytes": manifest["total_bytes"],
            "manifest_verification": verification,
        })
        if not verification["ok"]:
            print(json.dumps(summary, indent=2, sort_keys=True))
            return 3
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
