"""Independently score Nearing et al. (2022) result pickles.

The decisive formulas are implemented with NumPy/SciPy here rather than routed
through ``neuralhydrology.evaluation.metrics``. Tests assert numerical parity
with the library definitions on controlled data. Observations always come from
the complete simulation result, which prevents evaluation holdout holes from
silently changing the scoring target.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import pickle
from typing import Iterable, Mapping

import numpy as np
import pandas as pd
from scipy import signal


METRICS = ("NSE", "KGE", "Alpha-NSE", "Pearson-r", "Beta-NSE", "Peak-Timing", "Missed-Peaks")


def _finite_common(dates: np.ndarray, obs: np.ndarray, sim: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    dates = np.asarray(dates)
    obs = np.asarray(obs, dtype=float).reshape(-1)
    sim = np.asarray(sim, dtype=float).reshape(-1)
    if not (len(dates) == len(obs) == len(sim)):
        raise ValueError(f"Mismatched series lengths: dates={len(dates)}, obs={len(obs)}, sim={len(sim)}")
    mask = np.isfinite(obs) & np.isfinite(sim) & ~pd.isna(dates)
    return dates[mask], obs[mask], sim[mask]


def _is_contiguous_daily(dates: np.ndarray, start: int, stop: int) -> bool:
    window = pd.DatetimeIndex(dates[start:stop])
    if len(window) <= 1:
        return True
    return bool(np.all(np.diff(window.values).astype("timedelta64[D]") == np.timedelta64(1, "D")))


def _mean_peak_timing(dates: np.ndarray, obs: np.ndarray, sim: np.ndarray, window: int = 3) -> float:
    peaks, _ = signal.find_peaks(obs, distance=100, prominence=np.std(obs))
    timing_errors: list[float] = []
    for idx in peaks:
        if idx - window < 0 or idx + window >= len(obs):
            continue
        if not _is_contiguous_daily(dates, idx - window, idx + window + 1):
            continue
        if sim[idx] > sim[idx - 1] and sim[idx] > sim[idx + 1]:
            simulated_idx = idx
        else:
            simulated_idx = idx - window + int(np.argmax(sim[idx - window:idx + window + 1]))
        delta_days = abs((np.datetime64(dates[idx], "ns") - np.datetime64(dates[simulated_idx], "ns"))
                         / np.timedelta64(1, "D"))
        timing_errors.append(float(delta_days))
    return float(np.mean(timing_errors)) if timing_errors else float("nan")


def _missed_peaks(dates: np.ndarray,
                  obs: np.ndarray,
                  sim: np.ndarray,
                  window: int = 1,
                  percentile: float = 80.0) -> float:
    observed_height = np.percentile(obs, percentile)
    simulated_height = np.percentile(sim, percentile)
    observed_peaks, _ = signal.find_peaks(obs, distance=30, height=observed_height)
    simulated_peaks, _ = signal.find_peaks(sim, distance=30, height=simulated_height)
    if len(observed_peaks) == 0:
        return 0.0
    missed = 0
    for idx in observed_peaks:
        if idx - window < 0 or idx + window >= len(obs):
            continue
        if not _is_contiguous_daily(dates, idx - window, idx + window + 1):
            continue
        if not np.any(np.abs(simulated_peaks - idx) <= window):
            missed += 1
    return float(missed / len(observed_peaks))


def independent_metrics(dates: np.ndarray, obs: np.ndarray, sim: np.ndarray) -> dict[str, float]:
    dates, obs, sim = _finite_common(dates, obs, sim)
    if len(obs) == 0:
        return {metric: float("nan") for metric in METRICS}

    obs_mean = float(np.mean(obs))
    sim_mean = float(np.mean(sim))
    obs_std = float(np.std(obs, ddof=0))
    sim_std = float(np.std(sim, ddof=0))
    denominator = float(np.sum((obs - obs_mean)**2))
    nse = float(1.0 - np.sum((sim - obs)**2) / denominator) if denominator != 0 else float("nan")
    alpha = float(sim_std / obs_std) if obs_std != 0 else float("nan")
    beta_nse = float((sim_mean - obs_mean) / obs_std) if obs_std != 0 else float("nan")
    if len(obs) < 2 or obs_std == 0 or sim_std == 0:
        pearson = float("nan")
    else:
        pearson = float(np.corrcoef(obs, sim)[0, 1])
    beta_kge = float(sim_mean / obs_mean) if obs_mean != 0 else float("nan")
    if np.all(np.isfinite([pearson, alpha, beta_kge])):
        kge = float(1.0 - np.sqrt((pearson - 1.0)**2 + (alpha - 1.0)**2 + (beta_kge - 1.0)**2))
    else:
        kge = float("nan")

    return {
        "NSE": nse,
        "KGE": kge,
        "Alpha-NSE": alpha,
        "Pearson-r": pearson,
        "Beta-NSE": beta_nse,
        "Peak-Timing": _mean_peak_timing(dates, obs, sim),
        "Missed-Peaks": _missed_peaks(dates, obs, sim),
    }


def _load_pickle(path: Path) -> Mapping[str, object]:
    # These files contain xarray objects and therefore require pickle. Only
    # load trusted artifacts produced by the registered experiment pipeline.
    with Path(path).open("rb") as fp:
        payload = pickle.load(fp)
    if not isinstance(payload, Mapping):
        raise TypeError(f"Expected mapping in {path}, got {type(payload).__name__}")
    return payload


def _dataset_for_basin(payload: Mapping[str, object], basin: str):
    basin_payload = payload[basin]
    if "1D" not in basin_payload or "xr" not in basin_payload["1D"]:
        raise KeyError(f"Basin {basin} lacks the required 1D/xr result structure")
    return basin_payload["1D"]["xr"]


def _extract_series(dataset, variable: str) -> tuple[np.ndarray, np.ndarray]:
    if variable not in dataset:
        raise KeyError(f"Missing variable {variable}")
    values = np.asarray(dataset[variable].values)
    if values.ndim == 2 and values.shape[1] == 1:
        values = values[:, 0]
    elif values.ndim != 1:
        raise ValueError(f"Expected one prediction per date for {variable}, got shape {values.shape}")
    dates = np.asarray(dataset["date"].values)
    if len(dates) != len(values):
        raise ValueError(f"Date/value mismatch for {variable}: {len(dates)} versus {len(values)}")
    return dates, values.astype(float)


def _align_reference_and_candidate(reference_dataset, candidate_dataset, target: str) -> tuple[np.ndarray, np.ndarray,
                                                                                               np.ndarray]:
    reference_dates, reference_obs = _extract_series(reference_dataset, f"{target}_obs")
    candidate_dates, candidate_sim = _extract_series(candidate_dataset, f"{target}_sim")
    reference = pd.DataFrame({"obs": reference_obs}, index=pd.DatetimeIndex(reference_dates))
    candidate = pd.DataFrame({"sim": candidate_sim}, index=pd.DatetimeIndex(candidate_dates))
    if reference.index.has_duplicates or candidate.index.has_duplicates:
        raise ValueError("Duplicate dates are not allowed in predict_last_n=1 scoring")
    aligned = reference.join(candidate, how="inner", sort=False)
    if aligned.empty:
        raise ValueError("Reference and candidate have no common dates")
    return aligned.index.values, aligned["obs"].to_numpy(), aligned["sim"].to_numpy()


def score_result_pickles(simulation_results: Path,
                         candidate_results: Path,
                         target: str = "QObs(mm/d)",
                         expected_basins: int | None = None) -> pd.DataFrame:
    simulation = _load_pickle(simulation_results)
    candidate = _load_pickle(candidate_results)
    simulation_basins = set(simulation)
    candidate_basins = set(candidate)
    if simulation_basins != candidate_basins:
        missing = sorted(simulation_basins - candidate_basins)
        extra = sorted(candidate_basins - simulation_basins)
        raise ValueError(f"Basin mismatch: missing={missing[:5]}, extra={extra[:5]}")
    if expected_basins is not None and len(simulation_basins) != expected_basins:
        raise ValueError(f"Expected {expected_basins} basins, found {len(simulation_basins)}")

    rows: list[dict[str, object]] = []
    for basin in sorted(simulation_basins):
        reference_dataset = _dataset_for_basin(simulation, basin)
        candidate_dataset = _dataset_for_basin(candidate, basin)
        dates, obs, sim = _align_reference_and_candidate(reference_dataset, candidate_dataset, target)
        finite_dates, finite_obs, finite_sim = _finite_common(dates, obs, sim)
        metrics = independent_metrics(finite_dates, finite_obs, finite_sim)
        rows.append({
            "basin": basin,
            "n_common": len(finite_obs),
            "start_date": str(pd.Timestamp(finite_dates[0]).date()) if len(finite_dates) else "",
            "end_date": str(pd.Timestamp(finite_dates[-1]).date()) if len(finite_dates) else "",
            **metrics,
        })
    return pd.DataFrame(rows, columns=["basin", "n_common", "start_date", "end_date", *METRICS])


def median_summary(per_basin: pd.DataFrame, label: str) -> pd.DataFrame:
    values = {metric: float(per_basin[metric].median(skipna=True)) for metric in METRICS}
    return pd.DataFrame({label: values}).reindex(METRICS)


def _atomic_csv(frame: pd.DataFrame, path: Path, index: bool) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temporary, index=index, lineterminator="\n", float_format="%.12g")
    temporary.replace(path)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--simulation-results", type=Path, required=True)
    parser.add_argument("--candidate-results", type=Path, required=True)
    parser.add_argument("--label", required=True)
    parser.add_argument("--expected-basins", type=int, default=531)
    parser.add_argument("--per-basin-out", type=Path, required=True)
    parser.add_argument("--median-out", type=Path, required=True)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    per_basin = score_result_pickles(
        args.simulation_results,
        args.candidate_results,
        expected_basins=args.expected_basins,
    )
    medians = median_summary(per_basin, args.label)
    _atomic_csv(per_basin, args.per_basin_out, index=False)
    _atomic_csv(medians, args.median_out, index=True)
    print(f"basins={len(per_basin)}")
    print(medians.to_string())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
