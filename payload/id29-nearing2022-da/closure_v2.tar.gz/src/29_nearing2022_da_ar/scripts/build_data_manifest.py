"""Hash the exact CAMELS-US files used by the Nearing et al. reproduction."""

from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
from typing import Iterable


FORCING_FILES = {
    "daymet": "basin_mean_forcing/daymet/{huc}/{basin}_lump_cida_forcing_leap.txt",
    "maurer_extended": "basin_mean_forcing/maurer_extended/{huc}/{basin}_lump_maurer_forcing_leap.txt",
    "nldas_extended": "basin_mean_forcing/nldas_extended/{huc}/{basin}_lump_nldas_forcing_leap.txt",
}
STREAMFLOW_FILE = "usgs_streamflow/{huc}/{basin}_streamflow_qc.txt"
ATTRIBUTE_FILES = (
    "camels_clim.txt",
    "camels_geol.txt",
    "camels_hydro.txt",
    "camels_name.txt",
    "camels_soil.txt",
    "camels_topo.txt",
    "camels_vege.txt",
)


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as fp:
        for chunk in iter(lambda: fp.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_basin_ids(path: Path) -> tuple[str, ...]:
    basin_ids = tuple(line.strip() for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip())
    invalid = tuple(basin for basin in basin_ids if re.fullmatch(r"\d{8}", basin) is None)
    if invalid:
        raise ValueError(f"Invalid eight-digit basin identifiers: {invalid[:5]}")
    if len(set(basin_ids)) != len(basin_ids):
        raise ValueError("Basin list contains duplicate identifiers")
    return tuple(sorted(basin_ids))


def read_huc_mapping(data_root: Path) -> dict[str, str]:
    path = Path(data_root) / "camels_attributes_v2.0" / "camels_name.txt"
    with path.open("r", encoding="utf-8", newline="") as fp:
        rows = csv.DictReader(fp, delimiter=";")
        mapping = {str(row["gauge_id"]).zfill(8): str(row["huc_02"]).zfill(2) for row in rows}
    return mapping


def expected_files(data_root: Path, basin_ids: Iterable[str]) -> list[tuple[str, str, Path]]:
    data_root = Path(data_root)
    basin_ids = tuple(basin_ids)
    huc_by_basin = read_huc_mapping(data_root)
    missing_huc = sorted(set(basin_ids) - set(huc_by_basin))
    if missing_huc:
        raise ValueError(f"CAMELS-US name attributes lack HUC-02 values for: {missing_huc[:5]}")
    expected: list[tuple[str, str, Path]] = []
    for basin in sorted(basin_ids):
        values = {"basin": basin, "huc": huc_by_basin[basin]}
        for forcing, template in FORCING_FILES.items():
            relative = template.format(**values)
            expected.append((f"forcing:{forcing}", basin, data_root / relative))
        relative = STREAMFLOW_FILE.format(**values)
        expected.append(("streamflow", basin, data_root / relative))
    for filename in ATTRIBUTE_FILES:
        expected.append(("static_attributes", "", data_root / "camels_attributes_v2.0" / filename))
    return expected


def build_manifest(data_root: Path, basin_file: Path, expected_basins: int | None = None) -> dict[str, object]:
    data_root = Path(data_root).resolve()
    basin_file = Path(basin_file).resolve()
    basin_ids = read_basin_ids(basin_file)
    if expected_basins is not None and len(basin_ids) != expected_basins:
        raise ValueError(f"Expected {expected_basins} basins, found {len(basin_ids)}")

    files = expected_files(data_root, basin_ids)
    missing = [path for _, _, path in files if not path.is_file()]
    if missing:
        preview = ", ".join(str(path) for path in missing[:5])
        raise FileNotFoundError(f"Missing {len(missing)} expected CAMELS-US files: {preview}")

    entries: list[dict[str, object]] = []
    dataset_digest = hashlib.sha256()
    for role, basin, path in files:
        relative = path.resolve().relative_to(data_root).as_posix()
        size = path.stat().st_size
        digest = sha256_file(path)
        entry = {"role": role, "basin": basin, "path": relative, "bytes": size, "sha256": digest}
        entries.append(entry)
        dataset_digest.update(f"{role}\t{basin}\t{relative}\t{size}\t{digest}\n".encode("utf-8"))

    basin_list_digest = sha256_file(basin_file)
    dataset_digest.update(f"basin_list\t{len(basin_ids)}\t{basin_list_digest}\n".encode("utf-8"))
    return {
        "schema": "nearing2022-camels-us-data-manifest-v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "data_root": ".",
        "basin_count": len(basin_ids),
        "basin_list_sha256": basin_list_digest,
        "file_count": len(entries),
        "total_bytes": sum(int(entry["bytes"]) for entry in entries),
        "dataset_sha256": dataset_digest.hexdigest(),
        "files": entries,
    }


def write_manifest(manifest: dict[str, object], output: Path) -> None:
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + ".tmp")
    temporary.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    temporary.replace(output)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--basin-file", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--expected-basins", type=int)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    manifest = build_manifest(args.data_root, args.basin_file, expected_basins=args.expected_basins)
    write_manifest(manifest, args.output)
    print(json.dumps({key: manifest[key] for key in ("basin_count", "file_count", "total_bytes", "dataset_sha256")}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
