"""Freeze all released evaluation and assimilation-hyperparameter coordinates."""

from __future__ import annotations

import argparse
import csv
from decimal import Decimal
from pathlib import Path
from typing import Iterable

import pandas as pd


AUTHOR_EXPERIMENT_COMMIT = "b254529deb75d950f6417b67e51a7292b7aed430"
LEADS = (1, 2, 4, 8, 10)
HOLDOUTS = (0.0, 0.25, 0.5, 0.75, 1.0)
BASIN_FOLDS = tuple(range(10))
HYPER_WINDOWS = (1, 3, 5, 20)
HYPER_EPOCHS = (5, 10, 100, 1000)
HYPER_HISTORIES = (1, 5, 20)
HYPER_LEARNING_RATES = (0.0001, 0.001, 0.01, 0.05, 0.1)
HYPER_DROP_FACTORS = (0.1, 0.5, 0.9)

EVALUATION_COLUMNS = (
    "eval_id",
    "family",
    "evaluation_mode",
    "source_exp_id",
    "reference_exp_id",
    "seed",
    "lead",
    "train_holdout",
    "test_holdout",
    "fold",
    "status",
    "run_dir",
    "result_file",
    "slurm_job_id",
    "submitted_at",
    "completed_at",
    "artifact_manifest",
    "source_commit",
    "notes",
)

HYPERPARAMETER_COLUMNS = (
    "grid_index",
    "eval_id",
    "family",
    "source_exp_id",
    "test_basin_file",
    "window",
    "epochs",
    "history",
    "learning_rate",
    "drop_factor",
    "targets",
    "status",
    "run_dir",
    "result_file",
    "slurm_job_id",
    "source_commit",
    "notes",
)


def _holdout_code(value: float) -> str:
    return f"{int(round(value * 100)):03d}"


def _float_text(value: float) -> str:
    return format(Decimal(str(value)), "f")


def _float_code(value: float) -> str:
    return _float_text(value).replace(".", "p")


def _row(columns: Iterable[str], **values: object) -> dict[str, str]:
    row = {column: "" for column in columns}
    unknown = set(values) - set(row)
    if unknown:
        raise KeyError(f"Unknown registry fields: {sorted(unknown)}")
    for key, value in values.items():
        row[key] = str(value)
    return row


def build_evaluation_registry() -> pd.DataFrame:
    """Return the author's 180 evaluation coordinates, excluding the one shared time-split baseline."""
    rows: list[dict[str, str]] = []
    source = AUTHOR_EXPERIMENT_COMMIT

    for lead in LEADS:
        for train_holdout in HOLDOUTS:
            source_exp_id = f"N22-TS-AR-L{lead:02d}-H{_holdout_code(train_holdout)}-S0"
            for test_holdout in HOLDOUTS:
                existing = lead == 1 and train_holdout == 0.0 and test_holdout == 0.0
                eval_id = (
                    f"N22-EVAL-TS-AR-L{lead:02d}-TR{_holdout_code(train_holdout)}-"
                    f"TE{_holdout_code(test_holdout)}-S0"
                )
                rows.append(
                    _row(
                        EVALUATION_COLUMNS,
                        eval_id=eval_id,
                        family="time_autoregression",
                        evaluation_mode="autoregression",
                        source_exp_id=source_exp_id,
                        reference_exp_id="N22-TS-SIM-S0",
                        seed=0,
                        lead=lead,
                        train_holdout=_float_text(train_holdout),
                        test_holdout=_float_text(test_holdout),
                        status="completed_unverified" if existing else "planned",
                        run_dir=(
                            "/data1/home/sunyiq/nearing2022_da/results/29_nearing2022_da_ar/"
                            "nearing2022_autoregression_lead1_holdout0.0_seed0_2026_0808_1648_ep30"
                            if existing else
                            f"closure_20260810/evaluations/time_split/autoregression/{eval_id}"
                        ),
                        result_file="test/model_epoch030/test_results.p",
                        slurm_job_id="201893" if existing else "",
                        source_commit=source,
                        notes="Evaluation observations must come from the complete time-split simulation result.",
                    ))

        for test_holdout in HOLDOUTS:
            existing = lead == 1 and test_holdout == 0.0
            eval_id = f"N22-EVAL-TS-DA-L{lead:02d}-TE{_holdout_code(test_holdout)}-S0"
            rows.append(
                _row(
                    EVALUATION_COLUMNS,
                    eval_id=eval_id,
                    family="time_assimilation",
                    evaluation_mode="data_assimilation",
                    source_exp_id="N22-TS-SIM-S0",
                    reference_exp_id="N22-TS-SIM-S0",
                    seed=0,
                    lead=lead,
                    test_holdout=_float_text(test_holdout),
                    status="completed_unverified" if existing else "planned",
                    run_dir=(
                        "/data1/home/sunyiq/nearing2022_da/results/29_nearing2022_da_ar/"
                        "assimilation_lead_1_holdout_0.0_from_nearing2022_simulation_seed0_2026_0808_1535_ep30"
                        if existing else f"closure_20260810/evaluations/time_split/assimilation/{eval_id}"
                    ),
                    result_file="test/model_epoch030/test_results_data_assimilation.p",
                    slurm_job_id="201890" if existing else "",
                    source_commit=source,
                    notes="Uses the released default assimilation settings and the simulation checkpoint.",
                ))

    for fold in BASIN_FOLDS:
        for method in ("simulation", "autoregression", "assimilation"):
            if method == "simulation":
                eval_id = f"N22-EVAL-BS-SIM-F{fold:02d}-S0"
                source_exp_id = f"N22-BS-SIM-F{fold:02d}-S0"
                result_file = "test/model_epoch030/test_results.p"
                mode = "simulation"
            elif method == "autoregression":
                eval_id = f"N22-EVAL-BS-AR-L01-TR050-TE050-F{fold:02d}-S0"
                source_exp_id = f"N22-BS-AR-L01-H050-F{fold:02d}-S0"
                result_file = "test/model_epoch030/test_results.p"
                mode = "autoregression"
            else:
                eval_id = f"N22-EVAL-BS-DA-L01-TE050-F{fold:02d}-S0"
                source_exp_id = f"N22-BS-SIM-F{fold:02d}-S0"
                result_file = "test/model_epoch030/test_results_data_assimilation.p"
                mode = "data_assimilation"
            rows.append(
                _row(
                    EVALUATION_COLUMNS,
                    eval_id=eval_id,
                    family=f"basin_{method}",
                    evaluation_mode=mode,
                    source_exp_id=source_exp_id,
                    reference_exp_id=f"N22-BS-SIM-F{fold:02d}-S0",
                    seed=0,
                    lead=1 if method != "simulation" else "",
                    train_holdout="0.5" if method == "autoregression" else "",
                    test_holdout="0.5" if method != "simulation" else "",
                    fold=fold,
                    status="planned",
                    run_dir=(
                        f"closure_20260810/basin_split/{method}"
                        if method != "assimilation" else
                        f"closure_20260810/evaluations/basin_split/assimilation/{eval_id}"
                    ),
                    result_file=result_file,
                    source_commit=source,
                    notes="Uses the author's released disjoint ten-fold basin partition.",
                ))

    registry = pd.DataFrame(rows, columns=EVALUATION_COLUMNS)
    if len(registry) != 180 or not registry["eval_id"].is_unique:
        raise RuntimeError("Released evaluation registry violates the frozen 180-coordinate contract")
    return registry


def build_hyperparameter_registry() -> pd.DataFrame:
    """Return the 660 released assimilation hyperparameter evaluations in notebook loop order."""
    rows: list[dict[str, str]] = []
    index = 0
    for epochs in HYPER_EPOCHS:
        for history in HYPER_HISTORIES:
            for drop_factor in HYPER_DROP_FACTORS:
                for window in HYPER_WINDOWS:
                    for learning_rate in HYPER_LEARNING_RATES:
                        if window * history > 300:
                            continue
                        eval_id = (
                            f"N22-HYP-W{window:02d}-E{epochs:04d}-H{history:02d}-"
                            f"D{_holdout_code(drop_factor)}-LR{_float_code(learning_rate)}-TCN"
                        )
                        rows.append(
                            _row(
                                HYPERPARAMETER_COLUMNS,
                                grid_index=index,
                                eval_id=eval_id,
                                family="assimilation_hyperparameter",
                                source_exp_id="N22-BS-SIM-F00-S0",
                                test_basin_file=(
                                    "src/29_nearing2022_da_ar/basin_lists/author_pub/test_kfold_0_seed_0.txt"
                                ),
                                window=window,
                                epochs=epochs,
                                history=history,
                                learning_rate=_float_text(learning_rate),
                                drop_factor=_float_text(drop_factor),
                                targets="c_n",
                                status="planned",
                                run_dir=f"closure_20260810/evaluations/hyperparameter_search/{eval_id}",
                                result_file="test/model_epoch030/test_results_data_assimilation.p",
                                source_commit=AUTHOR_EXPERIMENT_COMMIT,
                                notes="Fold-0 held-out basins; exclude coordinates where window multiplied by history exceeds 300.",
                            ))
                        index += 1

    registry = pd.DataFrame(rows, columns=HYPERPARAMETER_COLUMNS)
    if len(registry) != 660 or not registry["eval_id"].is_unique:
        raise RuntimeError("Assimilation grid violates the frozen 660-coordinate contract")
    return registry


def write_registry(registry: pd.DataFrame, output: Path) -> None:
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    registry.to_csv(output, index=False, quoting=csv.QUOTE_MINIMAL, lineterminator="\n")


def build_batches(evaluations: pd.DataFrame, hyperparameters: pd.DataFrame) -> dict[str, tuple[str, ...]]:
    time_rows = evaluations.loc[evaluations["family"].str.startswith("time_")]
    existing_source_ids = {"N22-TS-SIM-S0", "N22-TS-AR-L01-H000-S0"}
    batches = {
        "time_split_evaluation_batch.txt": tuple(time_rows["eval_id"]),
        "time_split_existing_source_evaluation_batch.txt": tuple(
            time_rows.loc[time_rows["source_exp_id"].isin(existing_source_ids), "eval_id"]
        ),
        "time_split_pending_source_evaluation_batch.txt": tuple(
            time_rows.loc[~time_rows["source_exp_id"].isin(existing_source_ids), "eval_id"]
        ),
        "basin_assimilation_evaluation_batch.txt": tuple(
            evaluations.loc[evaluations["family"] == "basin_assimilation", "eval_id"]
        ),
        "hyperparameter_evaluation_batch.txt": tuple(hyperparameters["eval_id"]),
    }
    expected = {
        "time_split_evaluation_batch.txt": 150,
        "time_split_existing_source_evaluation_batch.txt": 30,
        "time_split_pending_source_evaluation_batch.txt": 120,
        "basin_assimilation_evaluation_batch.txt": 10,
        "hyperparameter_evaluation_batch.txt": 660,
    }
    if {name: len(values) for name, values in batches.items()} != expected:
        raise RuntimeError("Evaluation batches violate the frozen coordinate counts")
    return batches


def write_batches(batches: dict[str, tuple[str, ...]], output_dir: Path) -> None:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    for name, values in batches.items():
        (output_dir / name).write_text("\n".join(values) + "\n", encoding="utf-8", newline="\n")


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    repo_root = Path(__file__).resolve().parents[3]
    parser.add_argument(
        "--evaluation-output",
        type=Path,
        default=repo_root / "src/29_nearing2022_da_ar/registry/evaluation_registry.csv",
    )
    parser.add_argument(
        "--hyperparameter-output",
        type=Path,
        default=repo_root / "src/29_nearing2022_da_ar/registry/assimilation_hyperparameter_registry.csv",
    )
    parser.add_argument(
        "--batch-output-dir",
        type=Path,
        default=repo_root / "src/29_nearing2022_da_ar/registry",
    )
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    evaluations = build_evaluation_registry()
    hyperparameters = build_hyperparameter_registry()
    write_registry(evaluations, args.evaluation_output)
    write_registry(hyperparameters, args.hyperparameter_output)
    write_batches(build_batches(evaluations, hyperparameters), args.batch_output_dir)
    print(f"evaluation_rows={len(evaluations)}")
    print(f"hyperparameter_rows={len(hyperparameters)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
