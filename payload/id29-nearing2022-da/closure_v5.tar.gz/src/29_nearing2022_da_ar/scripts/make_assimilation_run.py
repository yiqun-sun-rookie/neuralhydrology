"""Build a data-assimilation run directory from a trained simulation run.

Mirrors ``create_da_and_ar_test_directories.ipynb`` of grey-nearing/lstm-data-assimilation: assimilation reuses the
weights of the trained simulation model, so we copy the finished simulation run directory and append the
``assimilation_config`` block to its ``config.yml``.

Usage
-----
    python src/29_nearing2022_da_ar/scripts/make_assimilation_run.py \
        --simulation-run-dir results/29_nearing2022_da_ar/nearing2022_simulation_seed0_<timestamp> \
        --lead 1 --holdout 0.0

    python -m neuralhydrology.nh_run evaluate --run-dir <the printed directory> --period test --epoch 30 \
        --data-assimilation
"""
import argparse
import shutil
import sys
from pathlib import Path

from ruamel.yaml import YAML

REPO_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_BLOCK = REPO_ROOT / 'src/29_nearing2022_da_ar/configs/assimilation_block_lead1.yml'


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--simulation-run-dir', type=Path, required=True, help='Finished simulation run directory.')
    parser.add_argument('--lead', type=int, default=1, help='Assimilation lead time in days (paper: 1, 2, 4, 8, 10).')
    parser.add_argument('--holdout', type=float, default=0.0, help='Fraction of observations withheld at inference.')
    parser.add_argument('--assimilation-block', type=Path, default=DEFAULT_BLOCK, help='YAML fragment to inject.')
    parser.add_argument('--output-dir', type=Path, default=None, help='Target directory. Derived from lead/holdout '
                        'next to the simulation run if omitted.')
    parser.add_argument('--overwrite', action='store_true', help='Replace the target directory if it exists.')
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    yaml = YAML()
    yaml.preserve_quotes = True

    simulation_run_dir = args.simulation_run_dir.resolve()
    if not (simulation_run_dir / 'config.yml').is_file():
        raise FileNotFoundError(f'No config.yml in {simulation_run_dir}. Is this a finished run directory?')

    output_dir = args.output_dir
    if output_dir is None:
        name = f'assimilation_lead_{args.lead}_holdout_{args.holdout}_from_{simulation_run_dir.name}'
        output_dir = simulation_run_dir.parent / name
    output_dir = output_dir.resolve()

    if output_dir.exists():
        if not args.overwrite:
            raise FileExistsError(f'{output_dir} already exists. Pass --overwrite to replace it.')
        shutil.rmtree(output_dir)
    shutil.copytree(simulation_run_dir, output_dir)

    with args.assimilation_block.open('r', encoding='utf-8') as fp:
        block = yaml.load(fp)
    block['assimilation_config']['assimilation_lead_time'] = args.lead
    block['random_holdout_from_dynamic_features']['QObs(mm/d)']['missing_fraction'] = args.holdout

    config_file = output_dir / 'config.yml'
    with config_file.open('r', encoding='utf-8') as fp:
        config = yaml.load(fp)
    if args.holdout == 0.0:
        # avoid touching the observation record at all when nothing is withheld
        block.pop('random_holdout_from_dynamic_features')
    config.update(block)
    with config_file.open('w', encoding='utf-8') as fp:
        yaml.dump(config, fp)

    print(f'Assimilation run directory ready: {output_dir}')
    print('Evaluate with:')
    print(f'  python -m neuralhydrology.nh_run evaluate --run-dir {output_dir} --period test --data-assimilation')
    return 0


if __name__ == '__main__':
    sys.exit(main())
