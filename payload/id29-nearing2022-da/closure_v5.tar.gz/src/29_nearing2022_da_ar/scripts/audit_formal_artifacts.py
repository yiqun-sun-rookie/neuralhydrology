"""Audit and hash Nearing et al. (2022) formal run artifacts."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from typing import Iterable, NamedTuple


class RunAudit(NamedTuple):
    status: str
    found_roles: tuple[str, ...]
    missing_roles: tuple[str, ...]
    role_paths: dict[str, str]


class ManifestVerification(NamedTuple):
    ok: bool
    missing_files: tuple[str, ...]
    size_mismatches: tuple[str, ...]
    hash_mismatches: tuple[str, ...]


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as fp:
        for chunk in iter(lambda: fp.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def expected_run_roles(run_dir: Path, epoch: int = 30, assimilation: bool = False) -> dict[str, Path]:
    run_dir = Path(run_dir)
    epoch_name = f"model_epoch{epoch:03d}"
    test_dir = run_dir / "test" / epoch_name
    roles = {
        "config": run_dir / "config.yml",
        f"checkpoint_epoch{epoch:03d}": run_dir / f"model_epoch{epoch:03d}.pt",
        "training_log": run_dir / "output.log",
        "train_data_scaler": run_dir / "train_data" / "train_data_scaler.yml",
        "test_results": test_dir / "test_results.p",
        "test_metrics": test_dir / "test_metrics.csv",
    }
    if assimilation:
        roles.update({
            "test_results_data_assimilation": test_dir / "test_results_data_assimilation.p",
            "test_metrics_data_assimilation": test_dir / "test_metrics_data_assimilation.csv",
        })
    return roles


def audit_run(run_dir: Path, epoch: int = 30, assimilation: bool = False) -> RunAudit:
    run_dir = Path(run_dir)
    roles = expected_run_roles(run_dir, epoch=epoch, assimilation=assimilation)
    found = tuple(sorted(role for role, path in roles.items() if path.is_file()))
    missing = tuple(sorted(set(roles) - set(found)))
    role_paths = {role: path.relative_to(run_dir).as_posix() for role, path in roles.items() if path.is_file()}

    if not missing:
        status = "reproducible"
    elif found or any(run_dir.glob("*.csv")) or any(run_dir.glob("*.md")):
        status = "partially_reproducible"
    else:
        status = "not_auditable"
    return RunAudit(status=status, found_roles=found, missing_roles=missing, role_paths=role_paths)


def _manifest_entry(path: Path, root: Path) -> dict[str, object]:
    resolved = path.resolve()
    try:
        relative = resolved.relative_to(root.resolve())
    except ValueError as exc:
        raise ValueError(f"Artifact is outside manifest root: {path}") from exc
    return {
        "path": relative.as_posix(),
        "bytes": resolved.stat().st_size,
        "sha256": sha256_file(resolved),
    }


def write_manifest(files: Iterable[Path], root: Path, output_path: Path) -> dict[str, object]:
    root = Path(root).resolve()
    output_path = Path(output_path)
    unique_files = sorted({Path(path).resolve() for path in files}, key=lambda path: path.as_posix())
    entries = [_manifest_entry(path, root) for path in unique_files]
    manifest = {
        "schema": "nearing2022-artifact-manifest-v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "root": ".",
        "file_count": len(entries),
        "total_bytes": sum(int(entry["bytes"]) for entry in entries),
        "files": entries,
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = output_path.with_suffix(output_path.suffix + ".tmp")
    temporary.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    temporary.replace(output_path)
    return manifest


def verify_manifest(manifest_path: Path) -> ManifestVerification:
    manifest_path = Path(manifest_path).resolve()
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("schema") != "nearing2022-artifact-manifest-v1":
        raise ValueError(f"Unsupported manifest schema in {manifest_path}")
    root = manifest_path.parent / manifest.get("root", ".")
    missing: list[str] = []
    size_mismatches: list[str] = []
    hash_mismatches: list[str] = []
    for entry in manifest.get("files", []):
        relative = str(entry["path"])
        path = root / relative
        if not path.is_file():
            missing.append(relative)
            continue
        if path.stat().st_size != int(entry["bytes"]):
            size_mismatches.append(relative)
        if sha256_file(path) != entry["sha256"]:
            hash_mismatches.append(relative)
    ok = not missing and not size_mismatches and not hash_mismatches
    return ManifestVerification(
        ok=ok,
        missing_files=tuple(sorted(missing)),
        size_mismatches=tuple(sorted(size_mismatches)),
        hash_mismatches=tuple(sorted(hash_mismatches)),
    )


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    audit = subparsers.add_parser("audit-run")
    audit.add_argument("run_dir", type=Path)
    audit.add_argument("--epoch", type=int, default=30)
    audit.add_argument("--assimilation", action="store_true")
    build = subparsers.add_parser("build-manifest")
    build.add_argument("root", type=Path)
    build.add_argument("output", type=Path)
    verify = subparsers.add_parser("verify-manifest")
    verify.add_argument("manifest", type=Path)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    if args.command == "audit-run":
        report = audit_run(args.run_dir, epoch=args.epoch, assimilation=args.assimilation)
        print(json.dumps(report._asdict(), indent=2, sort_keys=True))
        return 0 if report.status == "reproducible" else 2
    if args.command == "build-manifest":
        root = args.root.resolve()
        output = args.output.resolve()
        files = [path for path in root.rglob("*") if path.is_file() and path.resolve() != output]
        manifest = write_manifest(files, root, output)
        print(json.dumps({"file_count": manifest["file_count"], "total_bytes": manifest["total_bytes"]}))
        return 0
    verification = verify_manifest(args.manifest)
    print(json.dumps(verification._asdict(), indent=2, sort_keys=True))
    return 0 if verification.ok else 3


if __name__ == "__main__":
    raise SystemExit(main())
