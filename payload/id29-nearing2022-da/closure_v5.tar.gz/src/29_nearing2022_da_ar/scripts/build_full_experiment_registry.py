"""Freeze the released Nearing et al. (2022) experiment matrix.

The author notebook creates 46 *training* runs: one time-split simulation,
25 time-split autoregressive models, ten basin-split simulations, and ten
basin-split autoregressive models. Data-assimilation and test-holdout variants
are evaluations of those trained checkpoints and are tracked separately by the
downstream scorer.

This script is deliberately deterministic. It does not inspect results and it
does not select hyperparameters from observed scores.
"""

from __future__ import annotations

import argparse
import copy
import csv
from pathlib import Path
from typing import Iterable

import pandas as pd
import yaml


IDEA_RELATIVE = Path("src/29_nearing2022_da_ar")
BASE_CONFIG_RELATIVE = IDEA_RELATIVE / "configs"
FULL_CONFIG_RELATIVE = BASE_CONFIG_RELATIVE / "full_reproduction"
REGISTRY_RELATIVE = IDEA_RELATIVE / "registry" / "experiment_registry.csv"

AUTHOR_EXPERIMENT_COMMIT = "b254529deb75d950f6417b67e51a7292b7aed430"
AUTHOR_MODEL_COMMIT = "a3f8bfc0781af44bfee4ed3b4fdfae5ec5aa9a70"
SEEDS = (0,)
LEADS = (1, 2, 4, 8, 10)
HOLDOUTS = (0.0, 0.25, 0.5, 0.75, 1.0)
BASIN_FOLDS = tuple(range(10))
BASIN_SPLIT_LEAD = 1
BASIN_SPLIT_TRAIN_HOLDOUT = 0.5
EPOCH = 30

REGISTRY_COLUMNS = [
    "exp_id",
    "type",
    "family",
    "hypothesis",
    "base_config",
    "changed_factor",
    "fixed_factors",
    "seed",
    "lead",
    "train_holdout",
    "test_holdout",
    "fold",
    "status",
    "config_path",
    "run_dir",
    "best_checkpoint",
    "metrics_path",
    "paper_name",
    "source_commit",
    "slurm_job_id",
    "submitted_at",
    "completed_at",
    "artifact_manifest",
    "notes",
]


def _posix(path: Path) -> str:
    return path.as_posix()


def _holdout_text(value: float) -> str:
    return str(float(value))


def _holdout_code(value: float) -> str:
    return f"{int(round(value * 100)):03d}"


def _row(**values: object) -> dict[str, str]:
    row = {column: "" for column in REGISTRY_COLUMNS}
    for key, value in values.items():
        if key not in row:
            raise KeyError(f"Unknown registry field: {key}")
        row[key] = str(value)
    return row


def _canonical_config_path(*parts: str) -> str:
    return _posix(FULL_CONFIG_RELATIVE.joinpath(*parts))


def build_registry(repo_root: Path) -> pd.DataFrame:
    """Return the released 46-training-run matrix as strings.

    ``repo_root`` is accepted so callers can use one stable interface when
    validating paths; matrix construction itself is result-independent.
    """
    repo_root = Path(repo_root).resolve()
    if not (repo_root / BASE_CONFIG_RELATIVE / "simulation_531.yml").is_file():
        raise FileNotFoundError(f"Not a neuralhydrology checkout: {repo_root}")

    rows: list[dict[str, str]] = []
    source = f"experiment={AUTHOR_EXPERIMENT_COMMIT};model={AUTHOR_MODEL_COMMIT}"
    common_fixed = "seed=0;epoch=30;forcings=maurer_extended+nldas_extended+daymet;hidden_size=256"

    for seed in SEEDS:
        rows.append(
            _row(
                exp_id=f"N22-TS-SIM-S{seed}",
                type="training",
                family="time_simulation",
                hypothesis="Meteorological forcings and static attributes provide the open-loop reference.",
                base_config=_posix(BASE_CONFIG_RELATIVE / "simulation_531.yml"),
                changed_factor="none",
                fixed_factors=common_fixed,
                seed=seed,
                status="completed_unverified",
                config_path=_canonical_config_path("time_split", "simulation", f"seed_{seed}.yml"),
                run_dir=(
                    "/data1/home/sunyiq/nearing2022_da/results/29_nearing2022_da_ar/"
                    "nearing2022_simulation_seed0_2026_0808_1535_ep30"
                ),
                best_checkpoint="model_epoch030",
                paper_name="Time-split simulation",
                source_commit=source,
                slurm_job_id="201858",
                notes="Existing formal run; recover raw artifacts before declaring reproducible.",
            ))

        for lead in LEADS:
            for holdout in HOLDOUTS:
                completed = lead == 1 and holdout == 0.0 and seed == 0
                rows.append(
                    _row(
                        exp_id=f"N22-TS-AR-L{lead:02d}-H{_holdout_code(holdout)}-S{seed}",
                        type="training",
                        family="time_autoregression",
                        hypothesis="Lagged observed discharge improves time-split nowcasting under controlled missingness.",
                        base_config=_posix(BASE_CONFIG_RELATIVE / "autoregression_531_lead1_holdout0.yml"),
                        changed_factor=f"lead={lead};train_holdout={_holdout_text(holdout)}",
                        fixed_factors=common_fixed,
                        seed=seed,
                        lead=lead,
                        train_holdout=_holdout_text(holdout),
                        status="completed_unverified" if completed else "planned",
                        config_path=_canonical_config_path(
                            "time_split",
                            "autoregression",
                            f"lead_{lead}_holdout_{_holdout_text(holdout)}_seed_{seed}.yml",
                        ),
                        run_dir=(
                            "/data1/home/sunyiq/nearing2022_da/results/29_nearing2022_da_ar/"
                            "nearing2022_autoregression_lead1_holdout0.0_seed0_2026_0808_1648_ep30"
                            if completed else
                            f"/data1/home/sunyiq/nearing2022_da/closure_20260810/time_split/autoregression/"
                            f"lead_{lead}_holdout_{_holdout_text(holdout)}_seed_{seed}"
                        ),
                        best_checkpoint="model_epoch030",
                        paper_name=f"Time-split autoregression lead {lead}, train holdout {_holdout_text(holdout)}",
                        source_commit=source,
                        slurm_job_id="201893" if completed else "",
                        notes="Five test-holdout evaluations are created from each trained checkpoint.",
                    ))

        for fold in BASIN_FOLDS:
            rows.append(
                _row(
                    exp_id=f"N22-BS-SIM-F{fold:02d}-S{seed}",
                    type="training",
                    family="basin_simulation",
                    hypothesis="Open-loop performance transfers to basins excluded from training.",
                    base_config=_posix(BASE_CONFIG_RELATIVE / "simulation_531.yml"),
                    changed_factor=f"author_basin_fold={fold}",
                    fixed_factors=common_fixed,
                    seed=seed,
                    fold=fold,
                    status="planned",
                    config_path=_canonical_config_path("basin_split", "simulation", f"fold_{fold}_seed_{seed}.yml"),
                    run_dir=(
                        f"/data1/home/sunyiq/nearing2022_da/closure_20260810/basin_split/simulation/"
                        f"fold_{fold}_seed_{seed}"
                    ),
                    best_checkpoint="model_epoch030",
                    paper_name=f"Basin-split simulation fold {fold}",
                    source_commit=source,
                    notes="Test basin lists are copied byte-for-byte from the author release.",
                ))
            rows.append(
                _row(
                    exp_id=f"N22-BS-AR-L01-H050-F{fold:02d}-S{seed}",
                    type="training",
                    family="basin_autoregression",
                    hypothesis="Lag-1 discharge with 50 percent training holdout transfers to unseen basins.",
                    base_config=_posix(BASE_CONFIG_RELATIVE / "autoregression_531_lead1_holdout0.yml"),
                    changed_factor=f"author_basin_fold={fold};lead=1;train_holdout=0.5",
                    fixed_factors=common_fixed,
                    seed=seed,
                    lead=BASIN_SPLIT_LEAD,
                    train_holdout=_holdout_text(BASIN_SPLIT_TRAIN_HOLDOUT),
                    fold=fold,
                    status="planned",
                    config_path=_canonical_config_path(
                        "basin_split", "autoregression", f"fold_{fold}_holdout_0.5_seed_{seed}.yml"
                    ),
                    run_dir=(
                        f"/data1/home/sunyiq/nearing2022_da/closure_20260810/basin_split/autoregression/"
                        f"fold_{fold}_holdout_0.5_seed_{seed}"
                    ),
                    best_checkpoint="model_epoch030",
                    paper_name=f"Basin-split autoregression fold {fold}",
                    source_commit=source,
                    notes="Author notebook explicitly sets the basin-split lead to 1 before config generation.",
                ))

    registry = pd.DataFrame(rows, columns=REGISTRY_COLUMNS)
    if len(registry) != 46 or not registry["exp_id"].is_unique or not registry["config_path"].is_unique:
        raise RuntimeError("Released experiment registry violates the frozen 46-run contract")
    return registry


def _read_yaml(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as fp:
        data = yaml.safe_load(fp)
    if not isinstance(data, dict):
        raise TypeError(f"Expected a mapping in {path}")
    return data


def _configure_autoregression(config: dict, lead: int, holdout: float) -> None:
    shifted = f"QObs(mm/d)_shift{lead}"
    config["lagged_features"] = {"QObs(mm/d)": [lead]}
    config["autoregressive_inputs"] = [shifted]
    config["random_holdout_from_dynamic_features"] = {
        shifted: {
            "missing_fraction": float(holdout),
            "mean_missing_length": 5,
        }
    }


def _config_output_path(output_dir: Path, row: object) -> Path:
    family = getattr(row, "family")
    seed = int(getattr(row, "seed"))
    if family == "time_simulation":
        return output_dir / "time_split" / "simulation" / f"seed_{seed}.yml"
    if family == "time_autoregression":
        return (
            output_dir
            / "time_split"
            / "autoregression"
            / f"lead_{int(getattr(row, 'lead'))}_holdout_{getattr(row, 'train_holdout')}_seed_{seed}.yml"
        )
    fold = int(getattr(row, "fold"))
    if family == "basin_simulation":
        return output_dir / "basin_split" / "simulation" / f"fold_{fold}_seed_{seed}.yml"
    if family == "basin_autoregression":
        return output_dir / "basin_split" / "autoregression" / f"fold_{fold}_holdout_0.5_seed_{seed}.yml"
    raise ValueError(f"Unknown family: {family}")


def write_frozen_configs(repo_root: Path, output_dir: Path, registry: pd.DataFrame | None = None) -> list[Path]:
    """Write one semantically frozen YAML config for each training row."""
    repo_root = Path(repo_root).resolve()
    output_dir = Path(output_dir)
    registry = build_registry(repo_root) if registry is None else registry
    simulation_base = _read_yaml(repo_root / BASE_CONFIG_RELATIVE / "simulation_531.yml")
    autoregression_base = _read_yaml(repo_root / BASE_CONFIG_RELATIVE / "autoregression_531_lead1_holdout0.yml")
    generated: list[Path] = []

    for row in registry.itertuples(index=False):
        is_ar = row.family.endswith("autoregression")
        config = copy.deepcopy(autoregression_base if is_ar else simulation_base)
        config["seed"] = int(row.seed)
        config["epochs"] = EPOCH

        if row.family == "time_simulation":
            config["experiment_name"] = f"nearing2022_full_time_simulation_seed{row.seed}"
            config["run_dir"] = "closure_20260810/time_split/simulation"
        elif row.family == "time_autoregression":
            lead = int(row.lead)
            holdout = float(row.train_holdout)
            config["experiment_name"] = (
                f"nearing2022_full_time_autoregression_lead{lead}_holdout{_holdout_text(holdout)}_seed{row.seed}"
            )
            config["run_dir"] = "closure_20260810/time_split/autoregression"
            _configure_autoregression(config, lead, holdout)
        else:
            fold = int(row.fold)
            train_list = _posix(
                IDEA_RELATIVE / "basin_lists" / "author_pub" / f"train_kfold_{fold}_seed_{row.seed}.txt"
            )
            test_list = _posix(
                IDEA_RELATIVE / "basin_lists" / "author_pub" / f"test_kfold_{fold}_seed_{row.seed}.txt"
            )
            config["train_basin_file"] = train_list
            config["validation_basin_file"] = test_list
            config["test_basin_file"] = test_list
            if row.family == "basin_simulation":
                config["experiment_name"] = f"nearing2022_full_basin_simulation_fold{fold}_seed{row.seed}"
                config["run_dir"] = "closure_20260810/basin_split/simulation"
            elif row.family == "basin_autoregression":
                config["experiment_name"] = (
                    f"nearing2022_full_basin_autoregression_fold{fold}_holdout0.5_seed{row.seed}"
                )
                config["run_dir"] = "closure_20260810/basin_split/autoregression"
                _configure_autoregression(config, BASIN_SPLIT_LEAD, BASIN_SPLIT_TRAIN_HOLDOUT)
            else:
                raise ValueError(f"Unknown family: {row.family}")

        output_path = _config_output_path(output_dir, row)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with output_path.open("w", encoding="utf-8", newline="\n") as fp:
            yaml.safe_dump(config, fp, sort_keys=False, allow_unicode=True, width=120)
        generated.append(output_path)

    return generated


def write_registry(registry: pd.DataFrame, output_path: Path) -> None:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    registry.to_csv(output_path, index=False, quoting=csv.QUOTE_MINIMAL, lineterminator="\n")


def update_execution(registry: pd.DataFrame, exp_id: str, **updates: str) -> pd.DataFrame:
    """Return a copy with one experiment's mutable execution fields updated."""
    mutable = {"status", "run_dir", "metrics_path", "slurm_job_id", "submitted_at", "completed_at",
               "artifact_manifest", "notes"}
    unknown = set(updates) - mutable
    if unknown:
        raise KeyError(f"Execution update contains immutable or unknown fields: {sorted(unknown)}")
    matches = registry.index[registry["exp_id"] == exp_id].tolist()
    if len(matches) != 1:
        raise KeyError(f"Expected one registry row for {exp_id}, found {len(matches)}")
    updated = registry.copy()
    row_index = matches[0]
    for key, value in updates.items():
        updated.at[row_index, key] = str(value)
    return updated


def register_array_submission(
    registry: pd.DataFrame,
    config_paths: Iterable[str],
    array_job_id: str,
    submitted_at: str,
) -> pd.DataFrame:
    """Register one Slurm array task for every config path in batch-file order."""
    updated = registry.copy()
    seen: set[str] = set()
    for task_index, config_path in enumerate(config_paths):
        config_path = str(config_path).strip()
        if not config_path or config_path in seen:
            raise ValueError(f"Blank or duplicate config path in array batch: {config_path!r}")
        seen.add(config_path)
        matches = updated.index[updated["config_path"] == config_path].tolist()
        if len(matches) != 1:
            raise KeyError(f"Expected one registry row for config {config_path}, found {len(matches)}")
        row_index = matches[0]
        if updated.at[row_index, "status"] != "planned":
            raise ValueError(
                f"Refusing to submit {config_path} from status {updated.at[row_index, 'status']!r}"
            )
        updated.at[row_index, "status"] = "submitted"
        updated.at[row_index, "slurm_job_id"] = f"{array_job_id}_{task_index}"
        updated.at[row_index, "submitted_at"] = submitted_at
    return updated


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=Path(__file__).resolve().parents[3])
    parser.add_argument("--config-output", type=Path)
    parser.add_argument("--registry-output", type=Path)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    repo_root = args.repo_root.resolve()
    config_output = args.config_output or repo_root / FULL_CONFIG_RELATIVE
    registry_output = args.registry_output or repo_root / REGISTRY_RELATIVE
    registry = build_registry(repo_root)
    generated = write_frozen_configs(repo_root, config_output, registry)
    write_registry(registry, registry_output)
    print(f"registry_rows={len(registry)}")
    print(f"generated_configs={len(generated)}")
    print(f"registry={registry_output}")
    print(f"config_root={config_output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
