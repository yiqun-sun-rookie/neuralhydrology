"""Prepare one immutable evaluation directory from a registered epoch-30 checkpoint."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import shutil
from typing import Iterable, NamedTuple

import pandas as pd
import yaml


class PreparedRun(NamedTuple):
    run_dir: Path
    data_assimilation: bool
    result_file: str
    status: str


def _read_registry(path: Path, id_column: str) -> pd.DataFrame:
    registry = pd.read_csv(path, keep_default_na=False, dtype=str)
    if id_column not in registry or not registry[id_column].is_unique:
        raise ValueError(f"Registry {path} lacks a unique {id_column} column")
    return registry


def _select(registry: pd.DataFrame, id_column: str, identifier: str) -> pd.Series:
    matches = registry.loc[registry[id_column] == identifier]
    if len(matches) != 1:
        raise KeyError(f"Expected one {id_column}={identifier}, found {len(matches)}")
    return matches.iloc[0]


def resolve_source_run(repo_root: Path, training_registry: pd.DataFrame, source_exp_id: str) -> Path:
    row = _select(training_registry, "exp_id", source_exp_id)
    registered = Path(row["run_dir"])
    registered = registered if registered.is_absolute() else repo_root / registered
    if (registered / "model_epoch030.pt").is_file():
        return registered.resolve()

    config_path = repo_root / row["config_path"]
    with config_path.open("r", encoding="utf-8") as fp:
        config = yaml.safe_load(fp)
    output_parent = Path(config["run_dir"])
    output_parent = output_parent if output_parent.is_absolute() else repo_root / output_parent
    experiment_name = str(config["experiment_name"])
    matches = sorted(
        path.resolve()
        for path in output_parent.glob(f"{experiment_name}_*_ep30")
        if (path / "model_epoch030.pt").is_file()
    )
    if len(matches) != 1:
        raise FileNotFoundError(
            f"Expected one completed source run for {source_exp_id} under {output_parent}, found {len(matches)}"
        )
    return matches[0]


def _assimilation_block(row: pd.Series, hyperparameter: bool) -> dict[str, object]:
    if hyperparameter:
        lead = 1
        window = int(row["window"])
        epochs = int(row["epochs"])
        history = int(row["history"])
        learning_rate = float(row["learning_rate"])
        drop_factor = float(row["drop_factor"])
    else:
        lead = int(row["lead"])
        window = 5
        epochs = 100
        history = 20
        learning_rate = 0.1
        drop_factor = 0.1
    return {
        "assimilation_lead_time": lead,
        "assimilation_targets": ["c_n"],
        "assimilation_window": window,
        "epochs": epochs,
        "history": history,
        "learning_rate": learning_rate,
        "learning_rate_drop_factor": drop_factor,
        "learning_rate_epoch_drop": 1001,
        "loss": "MSE",
        "model_dropout": 0.0,
        "optimizer": "Adam",
        "predict_last_n": 1,
        "regularization": [],
        "seq_length": 365,
        "target_variables": ["QObs(mm/d)"],
    }


def _evaluation_config(source_config: dict, row: pd.Series, hyperparameter: bool, target_dir: Path) -> dict:
    config = dict(source_config)
    config["experiment_name"] = row["eval_id"]
    config["run_dir"] = str(target_dir.parent)
    family = str(row["family"])

    if hyperparameter:
        config.pop("random_holdout_from_dynamic_features", None)
        config["assimilation_config"] = _assimilation_block(row, hyperparameter=True)
    elif family == "time_autoregression":
        holdout = config.get("random_holdout_from_dynamic_features")
        if not isinstance(holdout, dict) or len(holdout) != 1:
            raise ValueError("Autoregression source config must contain exactly one random-holdout feature")
        feature = next(iter(holdout))
        holdout[feature]["missing_fraction"] = float(row["test_holdout"])
    elif family in {"time_assimilation", "basin_assimilation"}:
        config["random_holdout_from_dynamic_features"] = {
            "QObs(mm/d)": {
                "missing_fraction": float(row["test_holdout"]),
                "mean_missing_length": 5,
            }
        }
        config["assimilation_config"] = _assimilation_block(row, hyperparameter=False)
    else:
        raise ValueError(f"This helper only prepares derived evaluations, not {family}")
    return config


def prepare_run(
    repo_root: Path,
    training_registry_path: Path,
    evaluation_registry_path: Path,
    identifier: str,
    hyperparameter: bool = False,
) -> PreparedRun:
    repo_root = Path(repo_root).resolve()
    training = _read_registry(training_registry_path, "exp_id")
    evaluations = _read_registry(evaluation_registry_path, "eval_id")
    row = _select(evaluations, "eval_id", identifier)
    source = resolve_source_run(repo_root, training, row["source_exp_id"])
    family = str(row["family"])
    result_file = str(row["result_file"])
    if not hyperparameter and family in {"basin_simulation", "basin_autoregression"}:
        expected_result = source / result_file
        status = "completed" if expected_result.is_file() else "prepared"
        return PreparedRun(source.resolve(), False, result_file, status)

    target = Path(row["run_dir"])
    target = target if target.is_absolute() else repo_root / target
    expected_result = target / result_file
    data_assimilation = hyperparameter or row["evaluation_mode"] == "data_assimilation"

    if target.exists():
        if expected_result.is_file():
            return PreparedRun(target.resolve(), data_assimilation, result_file, "completed")
        raise FileExistsError(f"Refusing to replace incomplete evaluation directory: {target}")

    required = (source / "config.yml", source / "model_epoch030.pt", source / "train_data")
    missing = [path for path in required if not path.exists()]
    if missing:
        raise FileNotFoundError(f"Source run lacks required evaluation artifacts: {missing}")

    with (source / "config.yml").open("r", encoding="utf-8") as fp:
        source_config = yaml.safe_load(fp)
    config = _evaluation_config(source_config, row, hyperparameter, target)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(f".{target.name}.preparing-{os.getpid()}")
    if temporary.exists():
        raise FileExistsError(f"Refusing to replace prior preparation evidence: {temporary}")
    temporary.mkdir()
    shutil.copy2(source / "model_epoch030.pt", temporary / "model_epoch030.pt")
    shutil.copytree(source / "train_data", temporary / "train_data")
    with (temporary / "config.yml").open("w", encoding="utf-8", newline="\n") as fp:
        yaml.safe_dump(config, fp, sort_keys=False, allow_unicode=True, width=120)
    os.replace(temporary, target)
    return PreparedRun(target.resolve(), data_assimilation, result_file, "prepared")


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, required=True)
    parser.add_argument("--training-registry", type=Path, required=True)
    parser.add_argument("--evaluation-registry", type=Path, required=True)
    parser.add_argument("--eval-id", required=True)
    parser.add_argument("--hyperparameter", action="store_true")
    parser.add_argument("--plain", action="store_true")
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    prepared = prepare_run(
        args.repo_root,
        args.training_registry,
        args.evaluation_registry,
        args.eval_id,
        hyperparameter=args.hyperparameter,
    )
    if args.plain:
        print(prepared.run_dir)
        print("1" if prepared.data_assimilation else "0")
        print(prepared.result_file)
        print(prepared.status)
    else:
        print(prepared)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
