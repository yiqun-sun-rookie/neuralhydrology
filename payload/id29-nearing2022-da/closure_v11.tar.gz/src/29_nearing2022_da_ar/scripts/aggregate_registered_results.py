"""Independently aggregate every registered Nearing et al. evaluation coordinate."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import pickle
import sys
import types
from typing import Iterable

import pandas as pd


SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from prepare_evaluation_run import resolve_source_run  # noqa: E402
from score_reproduction_matrix import METRICS, _load_pickle, score_payloads  # noqa: E402


def load_legacy_pandas_pickle(path: Path):
    """Load the author's pandas-1-era statistics with narrow pandas-2 compatibility shims."""
    import pandas.core.internals.blocks as blocks
    from pandas._libs.internals import BlockPlacement

    prior_numeric = sys.modules.get("pandas.core.indexes.numeric")
    numeric = types.ModuleType("pandas.core.indexes.numeric")
    numeric.Int64Index = pd.Index
    numeric.UInt64Index = pd.Index
    numeric.Float64Index = pd.Index
    sys.modules["pandas.core.indexes.numeric"] = numeric
    original_new_block = blocks.new_block

    def compatible_new_block(values, placement, *, ndim, refs=None):
        if isinstance(placement, slice):
            placement = BlockPlacement(placement)
        return original_new_block(values, placement=placement, ndim=ndim, refs=refs)

    blocks.new_block = compatible_new_block
    try:
        with Path(path).open("rb") as fp:
            return pickle.load(fp)
    finally:
        blocks.new_block = original_new_block
        if prior_numeric is None:
            sys.modules.pop("pandas.core.indexes.numeric", None)
        else:
            sys.modules["pandas.core.indexes.numeric"] = prior_numeric


def _read_registry(path: Path, id_column: str) -> pd.DataFrame:
    registry = pd.read_csv(path, keep_default_na=False, dtype=str)
    if id_column not in registry or not registry[id_column].is_unique:
        raise ValueError(f"Registry {path} lacks a unique {id_column} column")
    return registry


def _registered_run(repo_root: Path, training: pd.DataFrame, row: pd.Series) -> Path:
    if row["family"] in {"basin_simulation", "basin_autoregression"}:
        return resolve_source_run(repo_root, training, row["source_exp_id"])
    path = Path(row["run_dir"])
    return path if path.is_absolute() else repo_root / path


def _atomic_csv(frame: pd.DataFrame, path: Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temporary, index=False, lineterminator="\n", float_format="%.12g")
    temporary.replace(path)


def _atomic_json(payload: dict[str, object], path: Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    temporary.replace(path)


def _author_time_value(author_statistics, row: pd.Series, metric: str) -> float:
    _, autoregression, assimilation = author_statistics
    if row["family"] == "time_autoregression":
        coordinate = (
            float(row["train_holdout"]),
            float(row["test_holdout"]),
            int(row["lead"]),
            int(row["seed"]),
        )
        return float(autoregression[metric][coordinate].median())
    coordinate = (float(row["test_holdout"]), int(row["lead"]), int(row["seed"]))
    return float(assimilation[metric][coordinate].median())


def aggregate_evaluations(
    repo_root: Path,
    training_registry_path: Path,
    evaluation_registry_path: Path,
    author_time_statistics_path: Path,
    author_pub_statistics_path: Path,
    output_dir: Path,
) -> dict[str, int]:
    repo_root = Path(repo_root).resolve()
    training = _read_registry(training_registry_path, "exp_id")
    evaluations = _read_registry(evaluation_registry_path, "eval_id")
    author_time = load_legacy_pandas_pickle(author_time_statistics_path)
    author_pub = load_legacy_pandas_pickle(author_pub_statistics_path)

    time_simulation_rows = training.loc[training["family"] == "time_simulation"]
    if len(time_simulation_rows) != 1:
        raise ValueError(f"Expected one time-split simulation training coordinate, found {len(time_simulation_rows)}")
    time_simulation_id = str(time_simulation_rows.iloc[0]["exp_id"])
    time_simulation_run = resolve_source_run(repo_root, training, time_simulation_id)
    time_simulation_path = time_simulation_run / "test/model_epoch030/test_results.p"
    if not time_simulation_path.is_file():
        raise FileNotFoundError(f"Missing time-split simulation result: {time_simulation_path}")

    specs: list[tuple[pd.Series, Path, Path]] = []
    missing: list[str] = []
    for _, row in evaluations.iterrows():
        candidate_run = _registered_run(repo_root, training, row)
        candidate_path = candidate_run / row["result_file"]
        reference_run = resolve_source_run(repo_root, training, row["reference_exp_id"])
        reference_path = reference_run / "test/model_epoch030/test_results.p"
        specs.append((row, reference_path, candidate_path))
        for path in (reference_path, candidate_path):
            if not path.is_file():
                missing.append(f"{row['eval_id']}:{path}")
    if missing:
        raise FileNotFoundError(f"Missing {len(missing)} registered result artifacts; first entries: {missing[:5]}")

    reference_cache: dict[Path, object] = {}
    per_basin_frames: list[pd.DataFrame] = []
    median_rows: list[dict[str, object]] = []
    comparison_rows: list[dict[str, object]] = []
    for row, reference_path, candidate_path in specs:
        if reference_path not in reference_cache:
            reference_cache[reference_path] = _load_pickle(reference_path)
        reference = reference_cache[reference_path]
        candidate = _load_pickle(candidate_path)
        scored = score_payloads(reference, candidate, expected_basins=len(reference))
        metadata = {
            "eval_id": row["eval_id"],
            "family": row["family"],
            "seed": row["seed"],
            "lead": row["lead"],
            "train_holdout": row["train_holdout"],
            "test_holdout": row["test_holdout"],
            "fold": row["fold"],
        }
        per_basin_frames.append(scored.assign(**metadata))
        medians = {metric: float(scored[metric].median()) for metric in METRICS}
        median_rows.append({**metadata, "basins": len(scored), **medians})
        if row["family"].startswith("time_"):
            for metric in METRICS:
                author_value = _author_time_value(author_time, row, metric)
                comparison_rows.append({
                    **metadata,
                    "metric": metric,
                    "reproduction": medians[metric],
                    "author": author_value,
                    "difference": medians[metric] - author_value,
                })

    time_simulation_payload = _load_pickle(time_simulation_path)
    time_simulation_scores = score_payloads(
        time_simulation_payload,
        time_simulation_payload,
        expected_basins=531,
    )
    time_simulation_medians = {
        metric: float(time_simulation_scores[metric].median()) for metric in METRICS
    }
    for metric in METRICS:
        author_value = float(author_time[0][metric].median().iloc[0])
        comparison_rows.append({
            "eval_id": time_simulation_id,
            "family": "time_simulation",
            "seed": str(time_simulation_rows.iloc[0]["seed"]),
            "lead": "",
            "train_holdout": "",
            "test_holdout": "",
            "fold": "",
            "metric": metric,
            "reproduction": time_simulation_medians[metric],
            "author": author_value,
            "difference": time_simulation_medians[metric] - author_value,
        })

    per_basin = pd.concat(per_basin_frames, ignore_index=True)
    medians = pd.DataFrame(median_rows)
    comparisons = pd.DataFrame(comparison_rows)
    basin_summary_rows: list[dict[str, object]] = []
    author_pub_by_family = {
        "basin_simulation": author_pub[0],
        "basin_autoregression": author_pub[1],
        "basin_assimilation": author_pub[2],
    }
    for family, author_metrics in author_pub_by_family.items():
        family_scores = per_basin.loc[per_basin["family"] == family]
        if len(family_scores) != 531 or family_scores["basin"].nunique() != 531:
            raise ValueError(f"{family} must pool to exactly 531 unique basins, got {len(family_scores)} rows")
        for metric in METRICS:
            reproduction = float(family_scores[metric].median())
            author_value = float(author_metrics[metric][0].median())
            basin_summary_rows.append({
                "family": family,
                "metric": metric,
                "reproduction": reproduction,
                "author": author_value,
                "difference": reproduction - author_value,
                "basins": 531,
            })

    output_dir = Path(output_dir)
    _atomic_csv(per_basin, output_dir / "per_basin_metrics.csv")
    _atomic_csv(time_simulation_scores, output_dir / "time_simulation_per_basin_metrics.csv")
    _atomic_csv(medians, output_dir / "median_matrix.csv")
    _atomic_csv(comparisons, output_dir / "time_split_vs_author.csv")
    _atomic_csv(pd.DataFrame(basin_summary_rows), output_dir / "basin_split_vs_author.csv")
    summary = {
        "evaluation_coordinates": len(evaluations),
        "per_basin_rows": len(per_basin),
        "time_simulation_basins": len(time_simulation_scores),
        "time_comparison_rows": len(comparisons),
        "basin_comparison_rows": len(basin_summary_rows),
    }
    _atomic_json(summary, output_dir / "aggregation_summary.json")
    return summary


def aggregate_hyperparameters(
    repo_root: Path,
    training_registry_path: Path,
    hyperparameter_registry_path: Path,
    output_dir: Path,
) -> dict[str, object]:
    repo_root = Path(repo_root).resolve()
    training = _read_registry(training_registry_path, "exp_id")
    hyperparameters = _read_registry(hyperparameter_registry_path, "eval_id")
    reference_run = resolve_source_run(repo_root, training, "N22-BS-SIM-F00-S0")
    reference_path = reference_run / "test/model_epoch030/test_results.p"
    reference = _load_pickle(reference_path)

    paths = []
    for _, row in hyperparameters.iterrows():
        run_dir = Path(row["run_dir"])
        run_dir = run_dir if run_dir.is_absolute() else repo_root / run_dir
        path = run_dir / row["result_file"]
        if not path.is_file():
            raise FileNotFoundError(f"Missing hyperparameter result for {row['eval_id']}: {path}")
        paths.append(path)

    per_basin_frames: list[pd.DataFrame] = []
    median_rows: list[dict[str, object]] = []
    for (_, row), candidate_path in zip(hyperparameters.iterrows(), paths):
        scored = score_payloads(reference, _load_pickle(candidate_path), expected_basins=len(reference))
        metadata = {
            "grid_index": int(row["grid_index"]),
            "eval_id": row["eval_id"],
            "window": int(row["window"]),
            "epochs": int(row["epochs"]),
            "history": int(row["history"]),
            "learning_rate": float(row["learning_rate"]),
            "drop_factor": float(row["drop_factor"]),
            "targets": row["targets"],
        }
        per_basin_frames.append(scored.assign(**metadata))
        median_rows.append({**metadata, "basins": len(scored), **{
            metric: float(scored[metric].median()) for metric in METRICS
        }})

    per_basin = pd.concat(per_basin_frames, ignore_index=True)
    scores = pd.DataFrame(median_rows).sort_values(["NSE", "grid_index"], ascending=[False, True]).reset_index(drop=True)
    scores.insert(0, "nse_rank", scores.index + 1)
    selected = scores.loc[
        (scores["window"] == 5)
        & (scores["epochs"] == 100)
        & (scores["history"] == 20)
        & (scores["learning_rate"] == 0.1)
        & (scores["drop_factor"] == 0.1)
        & (scores["targets"] == "c_n")
    ]
    if len(selected) != 1:
        raise ValueError(f"Expected one released default hyperparameter row, found {len(selected)}")
    output_dir = Path(output_dir)
    _atomic_csv(per_basin, output_dir / "per_basin_metrics.csv")
    _atomic_csv(scores, output_dir / "scores.csv")
    summary = {
        "coordinates": len(scores),
        "per_basin_rows": len(per_basin),
        "best_eval_id": str(scores.iloc[0]["eval_id"]),
        "best_nse": float(scores.iloc[0]["NSE"]),
        "released_default_eval_id": str(selected.iloc[0]["eval_id"]),
        "released_default_nse": float(selected.iloc[0]["NSE"]),
        "released_default_nse_rank": int(selected.iloc[0]["nse_rank"]),
    }
    _atomic_json(summary, output_dir / "selection_summary.json")
    return summary


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--repo-root", type=Path, required=True)
    common.add_argument("--training-registry", type=Path, required=True)
    common.add_argument("--output-dir", type=Path, required=True)
    evaluations = subparsers.add_parser("evaluations", parents=[common])
    evaluations.add_argument("--evaluation-registry", type=Path, required=True)
    evaluations.add_argument("--author-time-statistics", type=Path, required=True)
    evaluations.add_argument("--author-pub-statistics", type=Path, required=True)
    hyperparameters = subparsers.add_parser("hyperparameters", parents=[common])
    hyperparameters.add_argument("--hyperparameter-registry", type=Path, required=True)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    if args.command == "evaluations":
        summary = aggregate_evaluations(
            args.repo_root,
            args.training_registry,
            args.evaluation_registry,
            args.author_time_statistics,
            args.author_pub_statistics,
            args.output_dir,
        )
    else:
        summary = aggregate_hyperparameters(
            args.repo_root,
            args.training_registry,
            args.hyperparameter_registry,
            args.output_dir,
        )
    print(json.dumps(summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
