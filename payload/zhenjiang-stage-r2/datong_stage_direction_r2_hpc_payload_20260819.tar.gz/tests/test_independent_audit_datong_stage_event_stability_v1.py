from __future__ import annotations

import ast
import csv
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import sys

import numpy as np
import pandas as pd
import pytest


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SOURCE = (
    PROJECT_ROOT
    / "scripts/analysis/independent_audit_datong_stage_event_stability_v1.py"
)
SPEC = importlib.util.spec_from_file_location("event_stability_audit_under_test", SOURCE)
assert SPEC is not None and SPEC.loader is not None
audit = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = audit
SPEC.loader.exec_module(audit)


def _bits(values: np.ndarray) -> np.ndarray:
    return np.asarray(values, dtype=np.float32).view(np.uint32).copy()


def _sha(path: Path) -> str:
    import hashlib

    return hashlib.sha256(path.read_bytes()).hexdigest()


def _write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def _identity(path: Path, root: Path) -> dict[str, object]:
    return {
        "relative_path": path.relative_to(root).as_posix(),
        "bytes": path.stat().st_size,
        "sha256": _sha(path),
    }


def _write_authorized_chain(root: Path) -> dict[str, object]:
    implementations = {}
    tests = {}
    for role, relative in audit.AUTHORIZED_IMPLEMENTATION_PATHS.items():
        path = root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(f"implementation:{role}\n", encoding="utf-8")
        implementations[role] = _identity(path, root)
    for role, relative in audit.AUTHORIZED_TEST_PATHS.items():
        path = root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(f"test:{role}\n", encoding="utf-8")
        tests[role] = _identity(path, root)
    interpreter = audit._observed_interpreter_identity()
    test_paths = list(audit.AUTHORIZED_TEST_PATHS.values())
    payload: dict[str, object] = {
        "schema_version": 1,
        "authorization_id": audit.AUTHORIZATION_ID,
        "experiment_id": audit.EXPERIMENT_ID,
        "authorized": True,
        "scope": dict(audit.AUTHORIZED_SCOPE),
        "preregistration": {
            "relative_path": audit.PREREGISTRATION_RELATIVE_PATH.as_posix(),
            "bytes": audit.PREREGISTRATION_BYTES,
            "sha256": audit.PREREGISTRATION_SHA256,
        },
        "interpreter": interpreter,
        "implementations": implementations,
        "tests": tests,
        "test_evidence": {
            "command": [
                interpreter["path"], "-m", "pytest", "-q", *test_paths
            ],
            "test_paths": test_paths,
            "passed": 1,
            "failed": 0,
            "exit_code": 0,
            "synthetic_only": True,
        },
        "static_review": {"p0": 0, "p1": 0},
    }
    _write_json(root / audit.AUTHORIZATION_RELATIVE_PATH, payload)
    return payload


def _write_r2_authorized_chain(
    root: Path, monkeypatch: pytest.MonkeyPatch
) -> tuple[dict[str, object], dict[str, object]]:
    r2_preregistration = root / audit.R2_PREREGISTRATION_RELATIVE_PATH
    r2_preregistration.parent.mkdir(parents=True, exist_ok=True)
    r2_preregistration.write_text("synthetic R2 preregistration\n", encoding="utf-8")
    monkeypatch.setattr(audit, "R2_PREREGISTRATION_BYTES", r2_preregistration.stat().st_size)
    monkeypatch.setattr(audit, "R2_PREREGISTRATION_SHA256", _sha(r2_preregistration))

    original_preregistration = root / audit.PREREGISTRATION_RELATIVE_PATH
    original_preregistration.write_text("synthetic original preregistration\n", encoding="utf-8")
    original_authorization = root / audit.AUTHORIZATION_RELATIVE_PATH
    original_authorization.write_text("{}\n", encoding="utf-8")

    blind_root = root / "results/blind"
    failed_root = root / "results/failed"
    blind_root.mkdir(parents=True)
    failed_root.mkdir(parents=True)
    blind_files = {}
    for name in ("completion_manifest.json", "blind_event_manifest.json", "coverage_decision.json"):
        path = blind_root / name
        path.write_text(f"synthetic:{name}\n", encoding="utf-8")
        blind_files[name] = _identity(path, root)
    failed_files = {}
    for name in ("completion_manifest.json", "independent_audit_summary.json", "mismatches.csv"):
        path = failed_root / name
        path.write_text(f"synthetic:{name}\n", encoding="utf-8")
        failed_files[name] = _identity(path, root)

    implementation = root / audit.R2_AUTHORIZED_IMPLEMENTATION_PATHS["independent_audit"]
    implementation.parent.mkdir(parents=True, exist_ok=True)
    implementation.write_text("synthetic repaired audit\n", encoding="utf-8")
    test = root / audit.R2_AUTHORIZED_TEST_PATHS["independent_audit"]
    test.parent.mkdir(parents=True, exist_ok=True)
    test.write_text("synthetic repaired audit test\n", encoding="utf-8")
    failed_history = {
        "independent_audit_source": {
            "relative_path": audit.SOURCE_RELATIVE_PATH.as_posix(),
            "bytes": 11,
            "sha256": "1" * 64,
        },
        "independent_audit_test": {
            "relative_path": audit.R2_AUTHORIZED_TEST_PATHS["independent_audit"],
            "bytes": 12,
            "sha256": "2" * 64,
        },
    }
    retry: dict[str, object] = {
        "bound_parent_contracts": {
            "original_event_preregistration": _identity(
                original_preregistration, root
            ),
            "original_execution_authorization": _identity(
                original_authorization, root
            ),
        },
        "bound_blind_catalogue_outputs": {
            "completion_manifest": blind_files["completion_manifest.json"],
            "blind_event_manifest": blind_files["blind_event_manifest.json"],
            "coverage_decision": blind_files["coverage_decision.json"],
            "expected_decision": "HOLD_EXPLORATORY_INSUFFICIENT_PAIRED_EVENT_COVERAGE",
            "expected_coverage_passed": False,
            "expected_paired_event_count": 1,
            "minimum_paired_event_count": 10,
        },
        "bound_failed_audit_outputs": {
            "completion_manifest": failed_files["completion_manifest.json"],
            "independent_audit_summary": failed_files[
                "independent_audit_summary.json"
            ],
            "mismatches": failed_files["mismatches.csv"],
            "recorded_audit_status": "not_reproducible",
            "recorded_mismatch_count": 60,
            "recorded_coverage_passed": False,
            "recorded_paired_event_count": 1,
            "prediction_package_read_count": 0,
        },
        "failed_run_source_and_test_identities": failed_history,
    }
    interpreter = audit._observed_interpreter_identity()
    test_paths = list(audit.R2_AUTHORIZED_TEST_PATHS.values())
    payload: dict[str, object] = {
        "schema_version": 1,
        "authorization_id": audit.R2_AUTHORIZATION_ID,
        "experiment_id": audit.EXPERIMENT_ID,
        "retry_id": audit.R2_RETRY_ID,
        "authorized": True,
        "scope": dict(audit.R2_AUTHORIZED_SCOPE),
        "retry_preregistration": {
            "relative_path": audit.R2_PREREGISTRATION_RELATIVE_PATH.as_posix(),
            "bytes": audit.R2_PREREGISTRATION_BYTES,
            "sha256": audit.R2_PREREGISTRATION_SHA256,
        },
        "original_event_preregistration": retry["bound_parent_contracts"][
            "original_event_preregistration"
        ],
        "original_execution_authorization": retry["bound_parent_contracts"][
            "original_execution_authorization"
        ],
        "bound_blind_catalogue_outputs": retry["bound_blind_catalogue_outputs"],
        "bound_failed_audit_outputs": retry["bound_failed_audit_outputs"],
        "failed_run_source_and_test_identities": failed_history,
        "interpreter": interpreter,
        "implementations": {"independent_audit": _identity(implementation, root)},
        "tests": {"independent_audit": _identity(test, root)},
        "test_evidence": {
            "command": [interpreter["path"], "-m", "pytest", "-q", *test_paths],
            "test_paths": test_paths,
            "passed": 1,
            "failed": 0,
            "exit_code": 0,
            "synthetic_only": True,
        },
        "static_review": {"p0": 0, "p1": 0},
    }
    _write_json(root / audit.R2_AUTHORIZATION_RELATIVE_PATH, payload)
    return retry, payload


def _reader_contract(start: str, end: str) -> dict[str, object]:
    return {
        "aligned_target_header_required": [
            "time_beijing",
            *[
                value
                for station in audit.STATIONS
                for value in (f"{station}_target_m", f"{station}_missing")
            ],
        ],
        "realtime_header_required": [
            "TIME", "STAGE", "time_beijing", "time_utc",
            "is_missing_for_model",
        ],
        "evaluation_start_beijing": start,
        "evaluation_end_beijing": end,
        "seven_day_block_hours": 168,
        "full_block_count_required": 71,
    }


def _write_csv(path: Path, columns: list[str], rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


def _issue_map(event_count: int = 10) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for record_index in range(event_count * 2):
        event_id = record_index // 2 + 1
        state = "rising" if record_index % 2 == 0 else "falling"
        issue = np.float32(8.0)
        reference = np.float32(7.8)
        delta = np.float32(0.2 if state == "rising" else -0.2)
        rows.append(
            {
                "record_index": record_index,
                "issue_position": 1000 + record_index,
                "issue_time_beijing": (
                    pd.Timestamp("2024-01-01T00:00:00+08:00")
                    + pd.Timedelta(hours=record_index)
                ).isoformat(),
                "block_id": record_index // 4 + 1,
                "event_id": event_id,
                "in_event": True,
                "event_status": "complete",
                "eligible_paired": True,
                "state": state,
                "issue_stage_m": issue,
                "reference_stage_m": reference,
                "delta_m": delta,
                "issue_stage_raw_uint32": int(np.asarray(issue).view(np.uint32)),
                "reference_stage_raw_uint32": int(
                    np.asarray(reference).view(np.uint32)
                ),
                "delta_raw_uint32": int(np.asarray(delta).view(np.uint32)),
            }
        )
    return pd.DataFrame(rows, columns=audit.ISSUE_MAP_COLUMNS)


def _task_id(target: str, condition: str, seed: int) -> str:
    return f"tidal_fluvial_hidden_gauge_v1__{target}__{condition}__seed_{seed}"


def _package(
    target: str, condition: str, seed: int, issue_map: pd.DataFrame
) -> dict[str, np.ndarray]:
    package_rows = issue_map.loc[
        issue_map["state"].isin(["rising", "falling"])
    ].reset_index(drop=True)
    targets = np.zeros((len(package_rows), 6), dtype=np.float32)
    predictions = np.zeros_like(targets)
    seed_index = audit.SEEDS.index(seed)
    condition_base = {
        "hidden_target": 0.0,
        "hidden_target_both_nearest": 0.02,
        "endpoints_only": 0.03,
    }[condition]
    for row_index, row in package_rows.iterrows():
        for lead_index, lead_hour in enumerate(audit.FORECAST_HOURS):
            if condition == "hidden_target":
                value = 0.0
            elif row["state"] == "rising":
                value = 0.005
            else:
                value = (
                    0.005
                    + condition_base
                    + seed_index * 0.001
                    + int(row["event_id"]) * 0.0001
                    + lead_hour * 0.00001
                )
            predictions[row_index, lead_index] = np.float32(value)
    issue_stage = package_rows["issue_stage_m"].to_numpy(dtype=np.float32)
    reference = package_rows["reference_stage_m"].to_numpy(dtype=np.float32)
    delta = package_rows["delta_m"].to_numpy(dtype=np.float32)
    return {
        "schema_version": np.asarray(1, dtype=np.int32),
        "task_id": np.asarray(_task_id(target, condition, seed)),
        "target": np.asarray(target),
        "condition": np.asarray(condition),
        "seed": np.asarray(seed, dtype=np.int32),
        "target_index": np.asarray(
            2 if target == "zhenjiang" else 3, dtype=np.int32
        ),
        "issue_positions": package_rows["issue_position"].to_numpy(np.int64),
        "issue_times_beijing": package_rows["issue_time_beijing"].to_numpy(
            dtype=np.str_
        ),
        "block_ids": package_rows["block_id"].to_numpy(np.int32),
        "states": package_rows["state"].to_numpy(dtype=np.str_),
        "issue_stage_m": issue_stage,
        "reference_stage_m": reference,
        "delta_m": delta,
        "issue_stage_raw_uint32": _bits(issue_stage),
        "reference_stage_raw_uint32": _bits(reference),
        "delta_raw_uint32": _bits(delta),
        "predictions_m": predictions,
        "targets_m": targets,
        "checkpoint_sha256": np.asarray("a" * 64),
        "completion_manifest_sha256": np.asarray("b" * 64),
        "source_identities_json": np.asarray("{}"),
    }


def _packages(issue_map: pd.DataFrame) -> list[dict[str, np.ndarray]]:
    return [
        _package(target, condition, seed, issue_map)
        for target in audit.TARGETS
        for condition in audit.CONDITIONS
        for seed in audit.SEEDS
    ]


def _decision_config() -> dict[str, object]:
    return {
        "formal_result_boundary": {
            "prior_machine_decision": "NOT_CONFIRMED_FOR_KEY_POINT"
        },
        "descriptive_stability_rules": {
            "minimum_overall_contrast_m": 0.01,
            "minimum_positive_seed_count": 8,
            "minimum_positive_event_fraction": 0.8,
            "every_leave_one_event_out_contrast_at_least_m": 0.01,
            "every_leave_one_event_out_positive_seed_count_at_least": 8,
        },
        "diagnostic_branches": {
            "effect_or_seed_failure": "EXPLORATORY_NO_STABLE_POSITIVE_PATTERN",
            "event_fraction_or_leave_one_out_failure": "EXPLORATORY_EVENT_SENSITIVE",
            "lead_hour_failure": "EXPLORATORY_LEAD_TIME_SENSITIVE",
            "all_descriptive_rules_pass": "EXPLORATORY_PATTERN_STABLE_NOT_CONFIRMATION",
            "overall_required_label": "EXPLORATORY_ONLY_FORMAL_CONFIRMATION_UNCHANGED",
        },
    }


def test_source_locks_preregistration_identity_and_is_independent() -> None:
    assert audit.PREREGISTRATION_BYTES == 22_267
    assert audit.PREREGISTRATION_SHA256 == (
        "efcd2a853c93be157f11d4ac6b77041107704fb24efb6cb3765ff1ddb9facf36"
    )
    assert audit.R2_PREREGISTRATION_BYTES == 10_987
    assert audit.R2_PREREGISTRATION_SHA256 == (
        "aac877051076d9a83871f2a78b56745c9aa88ec6e276b24ac638837fbee89a1b"
    )
    tree = ast.parse(SOURCE.read_text(encoding="utf-8"))
    imported = {
        alias.name
        for node in ast.walk(tree)
        if isinstance(node, (ast.Import, ast.ImportFrom))
        for alias in node.names
    }
    forbidden_modules = {
        "load_datong_stage_event_blind_inputs_v1",
        "build_datong_stage_event_catalog_v1",
        "datong_stage_event_stability_diagnostic_v1",
    }
    assert not any(
        forbidden in name for forbidden in forbidden_modules for name in imported
    )
    assert "subprocess" not in imported
    forbidden_attributes = {
        "kill", "terminate", "send_signal", "suspend", "resume",
        "setpriority", "nice", "Popen", "run", "call", "check_call",
        "check_output", "train", "backward", "step",
    }
    observed = {
        node.attr for node in ast.walk(tree) if isinstance(node, ast.Attribute)
    }
    assert not (observed & forbidden_attributes)


def test_independent_audit_parses_authorization_and_rejects_tamper(
    tmp_path: Path,
) -> None:
    payload = _write_authorized_chain(tmp_path)
    chain = audit.validate_execution_authorization(tmp_path)
    assert set(chain["implementations"]) == set(
        audit.AUTHORIZED_IMPLEMENTATION_PATHS
    )
    payload["test_evidence"] = {
        "command": [
            payload["interpreter"]["path"], "-m", "pytest", "-q",
            *audit.AUTHORIZED_TEST_PATHS.values(),
        ],
        "test_paths": list(audit.AUTHORIZED_TEST_PATHS.values()),
        "passed": True,
        "failed": 0,
        "exit_code": 0,
        "synthetic_only": True,
    }
    _write_json(tmp_path / audit.AUTHORIZATION_RELATIVE_PATH, payload)
    with pytest.raises(audit.AuditContractError, match="test evidence"):
        audit.validate_execution_authorization(tmp_path)


@pytest.mark.parametrize(
    "tamper",
    [
        "schema_bool",
        "authorization_false",
        "scope_bool",
        "interpreter_bytes_bool",
        "implementation_bytes_bool",
        "failed_bool",
        "synthetic_string",
        "duplicate_authorized",
    ],
)
def test_audit_authorization_rejects_ambiguous_types_and_duplicate_fields(
    tmp_path: Path,
    tamper: str,
) -> None:
    original = _write_authorized_chain(tmp_path)
    payload = json.loads(json.dumps(original))
    authorization = tmp_path / audit.AUTHORIZATION_RELATIVE_PATH
    if tamper == "schema_bool":
        payload["schema_version"] = True
    elif tamper == "authorization_false":
        payload["authorized"] = False
    elif tamper == "scope_bool":
        payload["scope"]["independent_audit_runs"] = True
    elif tamper == "interpreter_bytes_bool":
        payload["interpreter"]["bytes"] = True
    elif tamper == "implementation_bytes_bool":
        payload["implementations"]["independent_audit"]["bytes"] = True
    elif tamper == "failed_bool":
        payload["test_evidence"]["failed"] = False
    elif tamper == "synthetic_string":
        payload["test_evidence"]["synthetic_only"] = "True"
    elif tamper == "duplicate_authorized":
        encoded = json.dumps(payload, ensure_ascii=False).replace(
            '"authorized": true',
            '"authorized": false, "authorized": true',
            1,
        )
        authorization.write_text(encoded + "\n", encoding="utf-8")
    else:  # pragma: no cover
        raise AssertionError(tamper)
    if tamper != "duplicate_authorized":
        _write_json(authorization, payload)

    with pytest.raises(audit.AuditContractError):
        audit.validate_execution_authorization(tmp_path)


@pytest.mark.parametrize("reported", [None, "1", True, 0, -1, 2])
def test_independent_runtime_thread_pool_count_fails_closed(
    reported: object,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    for name, value in audit.LAUNCHER_THREAD_ENVIRONMENT.items():
        monkeypatch.setenv(name, value)
    monkeypatch.setattr(audit.torch, "set_num_threads", lambda value: None)
    monkeypatch.setattr(audit.torch, "set_num_interop_threads", lambda value: None)
    monkeypatch.setattr(audit.torch, "get_num_threads", lambda: 1)
    monkeypatch.setattr(audit.torch, "get_num_interop_threads", lambda: 1)
    monkeypatch.setattr(audit.torch.cuda, "is_initialized", lambda: False)
    with pytest.raises(audit.AuditContractError, match="exactly one"):
        audit.enforce_single_thread_runtime(
            threadpool_info_provider=lambda: [{"num_threads": reported}]
        )


def test_column_level_readers_never_parse_target_or_other_station_stage(
    tmp_path: Path,
) -> None:
    start = "2024-01-01T00:00:00+08:00"
    end = "2024-01-01T01:00:00+08:00"
    contract = _reader_contract(start, end)
    aligned_rows = []
    for stamp in pd.date_range(start, end, freq="h"):
        row: dict[str, object] = {"time_beijing": stamp.isoformat()}
        for station in audit.STATIONS:
            row[f"{station}_target_m"] = "NOT_NUMERIC"
            row[f"{station}_missing"] = "False"
        aligned_rows.append(row)
    outside = dict(aligned_rows[-1])
    outside["time_beijing"] = "2024-01-01T02:00:00+08:00"
    aligned_rows.append(outside)
    aligned = tmp_path / "aligned.csv"
    _write_csv(
        aligned,
        list(contract["aligned_target_header_required"]),
        aligned_rows,
    )
    times, missing, access = audit._read_aligned_target_flags(aligned, contract)
    assert len(times) == 2
    assert not missing.any()
    assert access["parsed_columns"] == [
        "time_beijing", *[f"{station}_missing" for station in audit.STATIONS]
    ]
    assert access["consistency_checked_non_numeric_columns"] == [
        f"{station}_target_m" for station in audit.STATIONS
    ]
    assert access["source_row_count"] == 3

    realtime_rows = []
    for stamp in pd.date_range(start, end, freq="h"):
        realtime_rows.append(
            {
                "TIME": stamp.isoformat(),
                "STAGE": "NOT_NUMERIC",
                "time_beijing": stamp.isoformat(),
                "time_utc": stamp.tz_convert("UTC").isoformat(),
                "is_missing_for_model": "False",
            }
        )
    outside = dict(realtime_rows[-1])
    outside["TIME"] = "2024-01-01T02:00:00+08:00"
    outside["time_beijing"] = "2024-01-01T02:00:00+08:00"
    outside["time_utc"] = "2023-12-31T18:00:00+00:00"
    realtime_rows.append(outside)
    realtime = tmp_path / "other.csv"
    _write_csv(
        realtime,
        list(contract["realtime_header_required"]),
        realtime_rows,
    )
    other_times, other_missing, stage, other_access = audit._read_realtime_flags(
        realtime, contract, parse_stage=False
    )
    assert other_times == times
    assert not other_missing.any()
    assert stage is None
    assert "STAGE" not in other_access["parsed_columns"]
    assert other_access["consistency_checked_non_numeric_columns"] == ["STAGE"]
    assert other_access["source_row_count"] == 3
    assert other_access["stage_numeric_parse_count"] == 0

    realtime_rows[0]["STAGE"] = "nan"
    _write_csv(
        realtime,
        list(contract["realtime_header_required"]),
        realtime_rows,
    )
    with pytest.raises(audit.AuditContractError, match="not finite"):
        audit._read_realtime_flags(realtime, contract, parse_stage=True)


def test_event_segmentation_handles_censoring_short_low_and_missing_gaps() -> None:
    times = tuple(
        pd.date_range("2024-01-01T00:00:00+08:00", periods=110, freq="h")
    )
    stage = np.zeros(110, dtype=np.float32)
    stage[0] = np.float32(8.0)
    stage[49] = np.float32(8.0)
    stage[50] = np.float32(0.0)
    stage[51] = np.float32(np.nan)
    stage[52] = np.float32(8.0)
    stage[80:] = np.float32(8.0)
    events = audit._segment_stage_events(times, stage, 7.0)
    assert [event["event_status"] for event in events] == [
        "left_censored", "complete", "right_censored"
    ]
    assert events[1]["start_index"] == 49
    assert events[1]["last_high_index"] == 52
    assert events[1]["closure_index"] == 76


def test_catalogue_reconstruction_uses_minus_one_outside_sentinel() -> None:
    times = tuple(
        pd.date_range("2024-01-01T00:00:00+08:00", periods=80, freq="h")
    )
    stage = np.zeros(80, dtype=np.float32)
    stage[24] = np.float32(9.0)
    stage[25] = np.float32(9.0)
    stage[26] = np.float32(8.0)
    positions = np.asarray([24, 26, 55], dtype=np.int64)
    loaded = audit.IndependentBlindInputs(
        times=times,
        datong_stage=stage,
        history_missing=np.zeros((80, 6), dtype=np.bool_),
        target_missing=np.zeros((80, 6), dtype=np.bool_),
        issue_positions=positions,
        block_ids=np.asarray([1, 1, 1], dtype=np.int32),
        access_audit={},
        identities={},
    )
    config = {
        "blind_event_catalogue": {"event_threshold_m": 7.0},
        "state_rule": {
            "change_reference_hours_before_issue": 1,
            "issue_stage_must_be_strictly_above_m": 7.0,
            "rising_if_issue_minus_reference_strictly_above_m": 0.1,
            "falling_if_issue_minus_reference_strictly_below_m": -0.1,
        },
    }
    catalog, issue_map, coverage = audit.reconstruct_catalogue(loaded, config)
    assert len(catalog) == 1
    assert catalog.iloc[0]["eligible_paired"]
    assert issue_map.loc[issue_map["issue_position"] == 55, "event_id"].item() == -1
    assert issue_map.loc[issue_map["issue_position"] == 55, "event_status"].item() == "none"
    assert coverage.iloc[0]["paired_event_count"] == 1
    tampered = issue_map.copy()
    tampered.loc[tampered["issue_position"] == 55, "event_id"] = 0
    with pytest.raises(audit.AuditContractError, match="semantics"):
        audit._normalise_issue_map_for_scoring(tampered)


def test_complete_event_with_neither_state_is_not_counted_as_one_sided() -> None:
    times = tuple(
        pd.date_range("2024-01-01T00:00:00+08:00", periods=80, freq="h")
    )
    stage = np.zeros(80, dtype=np.float32)
    stage[24] = np.float32(9.0)
    loaded = audit.IndependentBlindInputs(
        times=times,
        datong_stage=stage,
        history_missing=np.zeros((80, 6), dtype=np.bool_),
        target_missing=np.zeros((80, 6), dtype=np.bool_),
        issue_positions=np.asarray([], dtype=np.int64),
        block_ids=np.asarray([], dtype=np.int32),
        access_audit={},
        identities={},
    )
    config = {
        "blind_event_catalogue": {"event_threshold_m": 7.0},
        "state_rule": {
            "change_reference_hours_before_issue": 1,
            "issue_stage_must_be_strictly_above_m": 7.0,
            "rising_if_issue_minus_reference_strictly_above_m": 0.1,
            "falling_if_issue_minus_reference_strictly_below_m": -0.1,
        },
    }

    catalog, _, coverage = audit.reconstruct_catalogue(loaded, config)

    assert catalog.iloc[0]["event_status"] == "complete"
    assert catalog.iloc[0]["rising_issue_count"] == 0
    assert catalog.iloc[0]["falling_issue_count"] == 0
    assert coverage.iloc[0]["one_sided_complete_event_count"] == 0


def test_right_censored_empty_closure_round_trips_without_false_mismatch(
    tmp_path: Path,
) -> None:
    expected = pd.DataFrame(
        [
            {
                "event_id": 1,
                "event_status": "right_censored",
                "observed_start_beijing": "2024-01-01T00:00:00+08:00",
                "event_end_beijing": "2024-01-01T01:00:00+08:00",
                "closure_proof_end_beijing": "",
                "left_censored": False,
                "right_censored": True,
                "rising_issue_count": 1,
                "falling_issue_count": 0,
                "excluded_issue_count": 0,
                "eligible_paired": False,
            }
        ],
        columns=audit.CATALOG_COLUMNS,
    )
    path = tmp_path / "event_catalog_blind.csv"
    expected.to_csv(path, index=False)

    observed = audit._read_catalogue_csv_preserving_empty_closure(path)

    assert observed.loc[0, "closure_proof_end_beijing"] == ""
    assert audit.compare_tables(
        expected,
        observed,
        key_columns=("event_id",),
        artifact=path.name,
    ) == []


def test_independent_nested_scoring_matches_hand_formula_and_rejects_tamper() -> None:
    issue_map = _issue_map()
    packages = _packages(issue_map)
    scored = audit.independently_score_packages(
        packages, issue_map, _decision_config()
    )
    metric = scored["event_seed_lead_metrics"]
    row = metric.loc[
        (metric["target"] == "zhenjiang")
        & (metric["condition"] == "hidden_target_both_nearest")
        & (metric["seed"] == 17)
        & (metric["event_id"] == 1)
        & (metric["lead_hour"] == 1)
    ].iloc[0]
    assert row["contrast_m"] == pytest.approx(0.02011, abs=2e-8)
    assert len(scored["leave_one_event_out"]) == 40
    tampered = issue_map.copy()
    tampered.loc[0, "issue_time_beijing"] = "2025-01-01T00:00:00+08:00"
    with pytest.raises(audit.AuditContractError, match="alignment"):
        audit.independently_score_packages(packages, tampered, _decision_config())


def test_coverage_failure_never_invokes_prediction_package_loader() -> None:
    invoked = False

    def forbidden_loader() -> None:
        nonlocal invoked
        invoked = True
        raise AssertionError("prediction package loader must not be called")

    branch, payload = audit.choose_coverage_or_full_branch(
        False, full_branch=forbidden_loader
    )
    assert branch == "coverage_only"
    assert payload is None
    assert not invoked


def test_coverage_only_full_entry_never_loads_packages_or_main_results(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    preregistration = tmp_path / audit.PREREGISTRATION_RELATIVE_PATH
    preregistration.parent.mkdir(parents=True)
    preregistration.write_text("synthetic preregistration\n", encoding="utf-8")
    config = {
        "output_roots": {"independent_audit": "results/audit"},
    }
    loaded = audit.IndependentBlindInputs(
        times=(),
        datong_stage=np.asarray([], dtype=np.float32),
        history_missing=np.zeros((0, 6), dtype=np.bool_),
        target_missing=np.zeros((0, 6), dtype=np.bool_),
        issue_positions=np.asarray([], dtype=np.int64),
        block_ids=np.asarray([], dtype=np.int32),
        access_audit={},
        identities={},
    )
    reconstructed = (
        pd.DataFrame(columns=audit.CATALOG_COLUMNS),
        pd.DataFrame(columns=audit.ISSUE_MAP_COLUMNS),
        pd.DataFrame(
            [[0, 0, 0, 0, 0, 0, 10, False]],
            columns=audit.COVERAGE_COLUMNS,
        ),
    )
    package_calls = 0
    published_artifacts: set[str] = set()

    def forbidden_packages(*args: object, **kwargs: object) -> object:
        nonlocal package_calls
        package_calls += 1
        raise AssertionError("coverage-only audit must not load packages")

    def publish(
        output_root: Path,
        artifacts: dict[str, object],
        **kwargs: object,
    ) -> Path:
        published_artifacts.update(artifacts)
        return output_root.resolve()

    monkeypatch.setattr(audit, "load_frozen_config", lambda path, root: config)
    monkeypatch.setattr(audit, "enforce_single_thread_runtime", lambda: {})
    monkeypatch.setattr(
        audit, "audit_resource_gate", lambda *args, **kwargs: {"passed": True}
    )
    monkeypatch.setattr(audit, "capture_audit_execution_identity", lambda *args: {})
    monkeypatch.setattr(audit, "reconstruct_catalogue", lambda *args: reconstructed)
    monkeypatch.setattr(
        audit,
        "load_and_compare_blind_outputs",
        lambda *args: (
            [],
            {
                "completion_identity": {"relative_path": "blind/completion", "bytes": 1, "sha256": "a" * 64},
                "manifest_identity": {"relative_path": "blind/manifest", "bytes": 1, "sha256": "b" * 64},
            },
        ),
    )
    monkeypatch.setattr(audit, "publish_independent_audit", publish)

    result = audit.run_independent_audit(
        preregistration_path=preregistration,
        project_root=tmp_path,
        blind_input_loader=lambda config, root: loaded,
        full_package_loader=forbidden_packages,
    )

    assert result["coverage_passed"] is False
    assert package_calls == 0
    assert published_artifacts == set(audit.COVERAGE_AUDIT_ARTIFACTS)


def test_table_comparison_reports_numeric_and_bit_tamper() -> None:
    expected = _issue_map(1)
    observed = expected.copy()
    observed.loc[0, "delta_raw_uint32"] ^= 1
    differences = audit.compare_tables(
        expected,
        observed,
        key_columns=("record_index",),
        artifact="event_issue_map_blind.csv",
    )
    assert any(row["field"].startswith("delta_raw_uint32") for row in differences)


def test_blind_input_manifest_identity_tamper_is_reported(tmp_path: Path) -> None:
    _write_authorized_chain(tmp_path)
    preregistration = tmp_path / audit.PREREGISTRATION_RELATIVE_PATH
    preregistration.parent.mkdir(parents=True, exist_ok=True)
    preregistration.write_text("synthetic preregistration\n", encoding="utf-8")
    raw_identity = {
        "relative_path": "data/raw.csv",
        "bytes": 5,
        "sha256": "c" * 64,
    }
    parsed = {"data/raw.csv": ["time_beijing"]}
    rows = {"data/raw.csv": 2}
    axes = {"data/raw.csv": "d" * 64}
    loaded = audit.IndependentBlindInputs(
        times=(),
        datong_stage=np.asarray([], dtype=np.float32),
        history_missing=np.zeros((0, 6), dtype=np.bool_),
        target_missing=np.zeros((0, 6), dtype=np.bool_),
        issue_positions=np.asarray([], dtype=np.int64),
        block_ids=np.asarray([], dtype=np.int32),
        identities={"raw": raw_identity},
        access_audit={
            "parsed_columns_by_path": parsed,
            "consistency_checked_non_numeric_columns_by_path": {},
            "selected_row_count_by_path": rows,
            "source_row_count_by_path": rows,
            "selected_time_axis_sha256_by_path": axes,
        },
    )
    chain = audit.validate_execution_authorization(tmp_path)
    execution_identity = {
        "blind_catalogue_builder_source": chain["implementations"]["blind_catalogue"],
        "blind_input_reader_source": chain["implementations"]["blind_input_reader"],
        "authorization_id": audit.AUTHORIZATION_ID,
        "execution_authorization": chain["authorization_identity"],
        "interpreter": chain["interpreter"],
        "implementations": chain["implementations"],
        "tests": chain["tests"],
        "test_evidence": chain["test_evidence"],
        "static_review": chain["static_review"],
    }
    observed = {
        "schema_version": 1,
        "experiment_id": audit.EXPERIMENT_ID,
        "result_label": audit.RESULT_LABEL,
        "preregistration": _identity(preregistration, tmp_path),
        "execution_identity": execution_identity,
        "blind_input_identities": {"raw": raw_identity},
        "access_audit": {
            "opened_relative_paths": ["data/raw.csv"],
            "parsed_columns_by_path": parsed,
            "consistency_checked_non_numeric_columns_by_path": {},
            "target_numeric_parse_count": 0,
            "other_station_stage_numeric_parse_count": 0,
            "forbidden_result_file_open_count": 0,
            "formal_result_root_open_count": 0,
            "selected_row_count_by_path": rows,
            "source_row_count_by_path": rows,
            "selected_time_axis_sha256_by_path": axes,
            "cross_source_time_axis_exact_match": True,
        },
        "prediction_package_open_count": 0,
        "prediction_array_read_count": 0,
        "target_array_read_count": 0,
        "forecast_error_read_count": 0,
        "formal_result_root_open_count": 0,
    }
    assert audit._compare_blind_input_manifest(
        observed, loaded, {}, tmp_path
    ) == []

    tampered = json.loads(json.dumps(observed))
    tampered["blind_input_identities"]["raw"]["sha256"] = "e" * 64
    differences = audit._compare_blind_input_manifest(
        tampered, loaded, {}, tmp_path
    )
    assert any(
        row["field"].startswith("$.blind_input_identities")
        for row in differences
    )

    for field, replacement in (
        (
            "consistency_checked_non_numeric_columns_by_path",
            {"data/raw.csv": ["STAGE"]},
        ),
        ("source_row_count_by_path", {"data/raw.csv": 3}),
    ):
        tampered = json.loads(json.dumps(observed))
        tampered["access_audit"][field] = replacement
        differences = audit._compare_blind_input_manifest(
            tampered, loaded, {}, tmp_path
        )
        parent_path = f"$.access_audit.{field}"
        assert any(
            row["field"] == parent_path
            or row["field"].startswith(parent_path + ".")
            or row["field"].startswith(parent_path + "[")
            for row in differences
        )


def _main_identity_audit_fixture(
    tmp_path: Path,
) -> tuple[
    dict[str, object],
    dict[str, object],
    dict[str, object],
    dict[str, object],
    Path,
]:
    _write_authorized_chain(tmp_path)
    preregistration = tmp_path / audit.PREREGISTRATION_RELATIVE_PATH
    preregistration.parent.mkdir(parents=True, exist_ok=True)
    preregistration.write_text("synthetic preregistration\n", encoding="utf-8")
    config: dict[str, object] = {
        "output_roots": {"main_diagnostic": "results/main"},
        "output_contract": {
            "main_diagnostic_precompletion_artifacts_when_coverage_passes": [
                "event_seed_lead_metrics.csv",
                "event_level_summary.csv",
                "seed_level_summary.csv",
                "lead_hour_summary.csv",
                "leave_one_event_out.csv",
                "event_influence_summary.csv",
                "diagnostic_machine_decision.json",
                "input_manifest.json",
                "resource_snapshot.json",
            ]
        },
        "diagnostic_branches": {
            "overall_required_label": "EXPLORATORY_ONLY_FORMAL_CONFIRMATION_UNCHANGED"
        },
    }
    decision = {
        "schema_version": 1,
        "experiment_id": audit.EXPERIMENT_ID,
        "result_label": audit.RESULT_LABEL,
        "decision": "EXPLORATORY_ONLY_FORMAL_CONFIRMATION_UNCHANGED",
        "prior_machine_decision": "NOT_CONFIRMED_FOR_KEY_POINT",
        "formal_decision_unchanged": True,
        "comparison_count": 0,
        "comparisons": [],
    }
    reconstructed: dict[str, object] = {
        "event_seed_lead_metrics": pd.DataFrame(columns=audit.EVENT_SEED_LEAD_COLUMNS),
        "event_level_summary": pd.DataFrame(columns=audit.EVENT_LEVEL_COLUMNS),
        "seed_level_summary": pd.DataFrame(columns=audit.SEED_LEVEL_COLUMNS),
        "lead_hour_summary": pd.DataFrame(columns=audit.LEAD_LEVEL_COLUMNS),
        "leave_one_event_out": pd.DataFrame(columns=audit.LEAVE_ONE_OUT_COLUMNS),
        "event_influence_summary": pd.DataFrame(columns=audit.EVENT_INFLUENCE_COLUMNS),
        "diagnostic_machine_decision": decision,
    }
    blind_chain: dict[str, object] = {
        "completion_identity": {
            "relative_path": "results/blind/completion_manifest.json",
            "bytes": 10,
            "sha256": "a" * 64,
        },
        "manifest_identity": {
            "relative_path": "results/blind/blind_event_manifest.json",
            "bytes": 11,
            "sha256": "b" * 64,
        },
    }
    scoring_identity: dict[str, object] = {
        "top_level_scoring_input_identities": {},
        "prior_audit_status": "reproducible",
        "prior_audit_mismatch_count": 0,
        "prediction_package_identities": [],
    }
    chain = audit.validate_execution_authorization(tmp_path)
    execution_identity = {
        "main_source": chain["implementations"]["main_diagnostic"],
        "execution_authorization": chain["authorization_identity"],
        "authorized_chain": chain,
    }
    input_manifest = {
        "schema_version": 1,
        "experiment_id": audit.EXPERIMENT_ID,
        "result_label": audit.RESULT_LABEL,
        "preregistration": _identity(preregistration, tmp_path),
        "execution_identity": execution_identity,
        "blind_catalogue_completion": blind_chain["completion_identity"],
        "blind_event_manifest": blind_chain["manifest_identity"],
        "paired_event_count": 10,
        **scoring_identity,
    }
    main_root = tmp_path / "results/main"
    main_root.mkdir(parents=True)
    table_files = {
        "event_seed_lead_metrics.csv": reconstructed["event_seed_lead_metrics"],
        "event_level_summary.csv": reconstructed["event_level_summary"],
        "seed_level_summary.csv": reconstructed["seed_level_summary"],
        "lead_hour_summary.csv": reconstructed["lead_hour_summary"],
        "leave_one_event_out.csv": reconstructed["leave_one_event_out"],
        "event_influence_summary.csv": reconstructed["event_influence_summary"],
    }
    for name, frame in table_files.items():
        assert isinstance(frame, pd.DataFrame)
        frame.to_csv(main_root / name, index=False)
    _write_json(main_root / "diagnostic_machine_decision.json", decision)
    _write_json(main_root / "input_manifest.json", input_manifest)
    _write_json(main_root / "resource_snapshot.json", {"schema_version": 1})
    artifacts = [
        _identity(main_root / name, main_root)
        for name in config["output_contract"][
            "main_diagnostic_precompletion_artifacts_when_coverage_passes"
        ]
    ]
    _write_json(
        main_root / "completion_manifest.json",
        {
            "schema_version": 1,
            "experiment_id": audit.EXPERIMENT_ID,
            "result_label": audit.RESULT_LABEL,
            "status": "completed_exploratory_event_diagnostic",
            "decision": "EXPLORATORY_ONLY_FORMAL_CONFIRMATION_UNCHANGED",
            "artifact_count": 9,
            "artifacts": artifacts,
        },
    )
    return config, reconstructed, blind_chain, scoring_identity, main_root


def _refresh_main_completion_artifact(main_root: Path, name: str) -> None:
    path = main_root / "completion_manifest.json"
    completion = json.loads(path.read_text(encoding="utf-8"))
    replacement = _identity(main_root / name, main_root)
    completion["artifacts"] = [
        replacement if row["relative_path"] == name else row
        for row in completion["artifacts"]
    ]
    _write_json(path, completion)


def test_main_audit_rejects_input_chain_and_completion_status_tamper(
    tmp_path: Path,
) -> None:
    config, reconstructed, blind_chain, scoring_identity, main_root = (
        _main_identity_audit_fixture(tmp_path)
    )
    differences, _ = audit.compare_main_diagnostic(
        config,
        tmp_path,
        reconstructed,
        blind_chain=blind_chain,
        scoring_identity=scoring_identity,
        paired_event_count=10,
    )
    assert differences == []

    manifest_path = main_root / "input_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["paired_event_count"] = 11
    _write_json(manifest_path, manifest)
    _refresh_main_completion_artifact(main_root, "input_manifest.json")
    differences, _ = audit.compare_main_diagnostic(
        config,
        tmp_path,
        reconstructed,
        blind_chain=blind_chain,
        scoring_identity=scoring_identity,
        paired_event_count=10,
    )
    assert any(row["artifact"] == "input_manifest.json" for row in differences)

    completion_path = main_root / "completion_manifest.json"
    completion = json.loads(completion_path.read_text(encoding="utf-8"))
    completion["status"] = "wrong"
    _write_json(completion_path, completion)
    differences, _ = audit.compare_main_diagnostic(
        config,
        tmp_path,
        reconstructed,
        blind_chain=blind_chain,
        scoring_identity=scoring_identity,
        paired_event_count=10,
    )
    assert any(row["category"] == "main_completion" for row in differences)


def _empty_audit_artifacts(coverage_passed: bool) -> dict[str, object]:
    names = (
        audit.FULL_AUDIT_ARTIFACTS
        if coverage_passed
        else audit.COVERAGE_AUDIT_ARTIFACTS
    )
    return {
        name: pd.DataFrame()
        if name.endswith(".csv")
        else {"schema_version": 1}
        for name in names
    }


@pytest.mark.parametrize("coverage_passed,expected_count", [(False, 7), (True, 13)])
def test_atomic_audit_publication_has_exact_branch_artifact_set(
    tmp_path: Path, coverage_passed: bool, expected_count: int
) -> None:
    final = tmp_path / ("full" if coverage_passed else "coverage")
    audit.publish_independent_audit(
        final,
        _empty_audit_artifacts(coverage_passed),
        coverage_passed=coverage_passed,
        mismatch_count=0,
    )
    completion = json.loads(
        (final / "completion_manifest.json").read_text(encoding="utf-8")
    )
    assert completion["artifact_count"] == expected_count
    assert len(completion["artifacts"]) == expected_count
    with pytest.raises(FileExistsError):
        audit.publish_independent_audit(
            final,
            _empty_audit_artifacts(coverage_passed),
            coverage_passed=coverage_passed,
            mismatch_count=0,
        )


def _resource_config() -> dict[str, object]:
    return {
        "output_roots": {"independent_audit": "results/audit"},
        "resource_gate": {
            "minimum_available_physical_memory_bytes": 6_442_450_944,
            "maximum_mean_total_cpu_utilization_percent": 50.0,
            "minimum_free_output_disk_bytes": 1,
        },
    }


def test_independent_audit_fresh_resource_gate_uses_three_two_second_samples(
    tmp_path: Path,
) -> None:
    tmp_path.joinpath("results").mkdir()
    seen: list[tuple[int, float]] = []

    def sample(index: int, interval: float) -> dict[str, object]:
        seen.append((index, interval))
        return {
            "available_physical_memory_bytes": 7_000_000_000,
            "total_cpu_utilization_percent": [10.0, 20.0, 30.0][index],
        }

    snapshot = audit.audit_resource_gate(
        _resource_config(),
        tmp_path,
        snapshot_provider=sample,
        process_counter=lambda: 0,
    )
    assert seen == [(0, 2.0), (1, 2.0), (2, 2.0)]
    assert snapshot["mean_total_cpu_utilization_percent"] == 20.0
    with pytest.raises(audit.AuditResourceGateError):
        audit.audit_resource_gate(
            _resource_config(),
            tmp_path,
            snapshot_provider=sample,
            process_counter=lambda: 1,
        )


@pytest.mark.parametrize(
    "failure",
    ["memory", "cpu", "disk", "other_process", "final", "temporary", "cuda"],
)
def test_every_audit_resource_gate_failure_stops_before_output(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    failure: str,
) -> None:
    results = tmp_path / "results"
    results.mkdir()
    final = results / "audit"
    temporary = results / f"audit.incomplete_pid_{audit.os.getpid()}"
    if failure == "final":
        final.mkdir()
    if failure == "temporary":
        temporary.mkdir()
    monkeypatch.setattr(
        audit.shutil,
        "disk_usage",
        lambda path: SimpleNamespace(
            total=10, used=9, free=0 if failure == "disk" else 1
        ),
    )
    monkeypatch.setattr(
        audit.torch.cuda, "is_initialized", lambda: failure == "cuda"
    )

    with pytest.raises(audit.AuditResourceGateError):
        audit.audit_resource_gate(
            _resource_config(),
            tmp_path,
            snapshot_provider=lambda index, interval: {
                "available_physical_memory_bytes": (
                    6_442_450_943 if failure == "memory" else 6_442_450_944
                ),
                "total_cpu_utilization_percent": (
                    50.1 if failure == "cpu" else 50.0
                ),
            },
            process_counter=lambda: int(failure == "other_process"),
        )

    if failure != "final":
        assert not final.exists()
    if failure != "temporary":
        assert not temporary.exists()


class _FakeProcess:
    def __init__(self, pid: int, cmdline: list[str], cwd: str):
        self.info = {"pid": pid, "cmdline": cmdline, "cwd": cwd}


def test_process_matcher_counts_only_direct_registered_python_entrypoint(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    script = tmp_path / "scripts/analysis/independent_audit_datong_stage_event_stability_v1.py"
    script.parent.mkdir(parents=True)
    script.write_text("pass\n", encoding="utf-8")
    monkeypatch.setattr(
        audit,
        "REGISTERED_FAMILY_SCRIPTS",
        ("scripts/analysis/independent_audit_datong_stage_event_stability_v1.py",),
    )
    monkeypatch.setattr(audit.os, "getpid", lambda: 999)
    processes = [
        _FakeProcess(1, ["python.exe", str(script)], str(tmp_path)),
        _FakeProcess(2, ["python.exe", "-m", script.stem], str(tmp_path)),
        _FakeProcess(3, ["python.exe", "-c", str(script)], str(tmp_path)),
        _FakeProcess(4, ["powershell.exe", str(script)], str(tmp_path)),
        _FakeProcess(999, ["python.exe", str(script)], str(tmp_path)),
    ]
    assert audit.count_other_family_processes(
        tmp_path, process_iterator=lambda attrs: processes
    ) == 1


def test_audit_path_limit_is_checked_before_first_write(tmp_path: Path) -> None:
    long_root = tmp_path / ("x" * 230)
    with pytest.raises(audit.AuditContractError, match="240"):
        audit.publish_independent_audit(
            long_root,
            _empty_audit_artifacts(False),
            coverage_passed=False,
            mismatch_count=0,
        )
    assert not long_root.exists()


def test_frozen_r2_preregistration_identity_and_semantics_are_locked() -> None:
    path = PROJECT_ROOT / audit.R2_PREREGISTRATION_RELATIVE_PATH
    assert path.stat().st_size == audit.R2_PREREGISTRATION_BYTES
    assert _sha(path) == audit.R2_PREREGISTRATION_SHA256
    payload = json.loads(path.read_text(encoding="utf-8"))
    audit.validate_frozen_r2_contract(payload)
    assert payload["output_contract"]["retry_precompletion_artifacts"] == list(
        audit.COVERAGE_AUDIT_ARTIFACTS
    )


@pytest.mark.parametrize(
    "tamper",
    [
        "authorization_id",
        "scope_bool",
        "original_authorization_identity",
        "blind_binding",
        "failed_audit_binding",
        "failed_source_history",
        "interpreter_bytes_bool",
        "implementation_identity",
        "test_identity",
        "test_command",
        "passed_bool",
        "static_review_bool",
    ],
)
def test_r2_execution_authorization_binds_every_registered_layer_and_rejects_tamper(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    tamper: str,
) -> None:
    retry, original = _write_r2_authorized_chain(tmp_path, monkeypatch)
    chain = audit.validate_r2_execution_authorization(tmp_path, retry)
    assert set(chain["implementations"]) == {"independent_audit"}
    payload = json.loads(json.dumps(original))
    if tamper == "authorization_id":
        payload["authorization_id"] += "_changed"
    elif tamper == "scope_bool":
        payload["scope"]["independent_coverage_only_audit_runs"] = True
    elif tamper == "original_authorization_identity":
        payload["original_execution_authorization"]["sha256"] = "f" * 64
    elif tamper == "blind_binding":
        payload["bound_blind_catalogue_outputs"]["expected_paired_event_count"] = 2
    elif tamper == "failed_audit_binding":
        payload["bound_failed_audit_outputs"]["recorded_mismatch_count"] = 59
    elif tamper == "failed_source_history":
        payload["failed_run_source_and_test_identities"][
            "independent_audit_source"
        ]["sha256"] = "e" * 64
    elif tamper == "interpreter_bytes_bool":
        payload["interpreter"]["bytes"] = True
    elif tamper == "implementation_identity":
        payload["implementations"]["independent_audit"]["bytes"] += 1
    elif tamper == "test_identity":
        payload["tests"]["independent_audit"]["sha256"] = "d" * 64
    elif tamper == "test_command":
        payload["test_evidence"]["command"].append("unregistered.py")
    elif tamper == "passed_bool":
        payload["test_evidence"]["passed"] = True
    elif tamper == "static_review_bool":
        payload["static_review"]["p0"] = False
    else:  # pragma: no cover
        raise AssertionError(tamper)
    _write_json(tmp_path / audit.R2_AUTHORIZATION_RELATIVE_PATH, payload)
    with pytest.raises(audit.AuditContractError):
        audit.validate_r2_execution_authorization(tmp_path, retry)


def test_r2_execution_authorization_rejects_duplicate_json_key(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    retry, payload = _write_r2_authorized_chain(tmp_path, monkeypatch)
    encoded = json.dumps(payload, ensure_ascii=False).replace(
        '"authorized": true',
        '"authorized": false, "authorized": true',
        1,
    )
    (tmp_path / audit.R2_AUTHORIZATION_RELATIVE_PATH).write_text(
        encoded + "\n", encoding="utf-8"
    )
    with pytest.raises(audit.AuditContractError, match="duplicate JSON field"):
        audit.validate_r2_execution_authorization(tmp_path, retry)


def test_r2_execution_authorization_rejects_bound_file_content_tamper(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    retry, _ = _write_r2_authorized_chain(tmp_path, monkeypatch)
    summary = tmp_path / retry["bound_failed_audit_outputs"][
        "independent_audit_summary"
    ]["relative_path"]
    summary.write_text("tampered after authorization\n", encoding="utf-8")
    with pytest.raises(audit.AuditContractError, match="bound file identity"):
        audit.validate_r2_execution_authorization(tmp_path, retry)


def test_r2_shortest_roundtrip_decimal_restores_float32_without_false_mismatch(
    tmp_path: Path,
) -> None:
    expected = _issue_map(1)
    path = tmp_path / "event_issue_map_blind.csv"
    expected.to_csv(path, index=False, lineterminator="\n")
    observed = pd.read_csv(path)
    assert observed["delta_m"].dtype == np.dtype(np.float64)
    assert audit.compare_tables(
        expected,
        observed,
        key_columns=("record_index",),
        artifact=path.name,
    ) == []


def test_r2_changed_float32_value_and_raw_bit_tamper_remain_detectable(
    tmp_path: Path,
) -> None:
    expected = _issue_map(1)
    path = tmp_path / "event_issue_map_blind.csv"
    expected.to_csv(path, index=False, lineterminator="\n")
    observed = pd.read_csv(path)
    observed.loc[0, "delta_m"] = float(
        np.nextafter(
            np.float32(expected.loc[0, "delta_m"]), np.float32(np.inf)
        )
    )
    observed.loc[1, "delta_raw_uint32"] = int(
        observed.loc[1, "delta_raw_uint32"]
    ) ^ 1
    differences = audit.compare_tables(
        expected,
        observed,
        key_columns=("record_index",),
        artifact=path.name,
    )
    assert any(row["field"] == "delta_m[0]" for row in differences)
    assert any(row["field"] == "delta_raw_uint32[1]" for row in differences)


def test_r2_derived_float64_columns_keep_one_e_minus_twelve_tolerance() -> None:
    expected = pd.DataFrame(
        {"record_index": [0, 1], "derived_metric": np.asarray([1.0, 2.0])}
    )
    observed = expected.copy()
    observed.loc[0, "derived_metric"] += 5e-13
    assert audit.compare_tables(
        expected,
        observed,
        key_columns=("record_index",),
        artifact="derived.csv",
    ) == []
    observed.loc[1, "derived_metric"] += 2e-12
    differences = audit.compare_tables(
        expected,
        observed,
        key_columns=("record_index",),
        artifact="derived.csv",
    )
    assert any(row["field"] == "derived_metric[1]" for row in differences)


@pytest.mark.parametrize(
    "coverage_passed,paired_event_count",
    [(True, 1), (False, 0), (False, 2)],
)
def test_r2_coverage_or_count_drift_stops_before_any_package_access(
    monkeypatch: pytest.MonkeyPatch,
    coverage_passed: bool,
    paired_event_count: int,
) -> None:
    package_calls = 0

    def forbidden_package_access(path: Path) -> object:
        nonlocal package_calls
        package_calls += 1
        raise AssertionError(path)

    monkeypatch.setattr(audit, "_load_npz", forbidden_package_access)
    retry = {
        "coverage_only_precondition": {
            "coverage_passed_must_be": False,
            "paired_event_count_must_equal": 1,
            "minimum_paired_event_count_must_equal": 10,
            "coverage_decision_must_equal": (
                "HOLD_EXPLORATORY_INSUFFICIENT_PAIRED_EVENT_COVERAGE"
            ),
        }
    }
    with pytest.raises(audit.AuditContractError, match="forbidden access"):
        audit.assert_r2_coverage_only_precondition(
            coverage_passed=coverage_passed,
            paired_event_count=paired_event_count,
            minimum_paired_event_count=10,
            decision="HOLD_EXPLORATORY_INSUFFICIENT_PAIRED_EVENT_COVERAGE",
            retry=retry,
        )
    assert package_calls == 0


def test_r2_entry_has_no_prediction_package_or_main_result_branch() -> None:
    tree = ast.parse(SOURCE.read_text(encoding="utf-8"))
    function = next(
        node
        for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "run_r2_coverage_audit"
    )
    parameters = {
        argument.arg
        for argument in (*function.args.args, *function.args.kwonlyargs)
    }
    called_names = {
        node.func.id
        for node in ast.walk(function)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
    }
    assert "full_package_loader" not in parameters
    assert not (
        called_names
        & {
            "load_prior_packages_after_coverage",
            "_load_npz",
            "independently_score_packages",
            "compare_main_diagnostic",
        }
    )
    assert sum(
        1
        for node in ast.walk(function)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "verify_r2_old_failed_audit_root"
    ) == 2


def test_r2_publication_is_exactly_seven_plus_completion_and_is_atomic(
    tmp_path: Path,
) -> None:
    final = tmp_path / "independent_audit_r2"
    audit.publish_independent_audit(
        final,
        _empty_audit_artifacts(False),
        coverage_passed=False,
        mismatch_count=0,
        result_label=audit.R2_RESULT_LABEL,
        retry_id=audit.R2_RETRY_ID,
    )
    files = {
        path.relative_to(final).as_posix()
        for path in final.rglob("*")
        if path.is_file()
    }
    assert files == set(audit.COVERAGE_AUDIT_ARTIFACTS) | {
        "completion_manifest.json"
    }
    completion = json.loads(
        (final / "completion_manifest.json").read_text(encoding="utf-8")
    )
    assert completion["artifact_count"] == 7
    assert completion["retry_id"] == audit.R2_RETRY_ID
    assert completion["result_label"] == audit.R2_RESULT_LABEL
    assert completion["status"] == "completed_independent_coverage_audit_retry"
    assert not final.with_name(
        f"{final.name}.incomplete_pid_{audit.os.getpid()}"
    ).exists()


def test_r2_preexisting_output_refuses_overwrite_and_preserves_old_root(
    tmp_path: Path,
) -> None:
    old_root = tmp_path / "independent_audit"
    old_root.mkdir()
    old_marker = old_root / "completion_manifest.json"
    old_marker.write_text("frozen-old-root\n", encoding="utf-8")
    old_identity = (old_marker.stat().st_size, _sha(old_marker))
    retry_root = tmp_path / "independent_audit_r2"
    retry_root.mkdir()
    (retry_root / "existing.txt").write_text("do not overwrite\n", encoding="utf-8")
    with pytest.raises(FileExistsError):
        audit.publish_independent_audit(
            retry_root,
            _empty_audit_artifacts(False),
            coverage_passed=False,
            mismatch_count=0,
            result_label=audit.R2_RESULT_LABEL,
            retry_id=audit.R2_RETRY_ID,
        )
    assert (old_marker.stat().st_size, _sha(old_marker)) == old_identity
    assert (retry_root / "existing.txt").read_text(encoding="utf-8") == (
        "do not overwrite\n"
    )


def test_r2_old_and_retry_roots_must_never_alias(tmp_path: Path) -> None:
    shared = tmp_path / "shared"
    shared.mkdir()
    retry = {
        "output_contract": {
            "old_failed_output_root": "shared",
            "retry_output_root": "shared",
        }
    }
    with pytest.raises(audit.AuditContractError, match="aliases"):
        audit.verify_r2_old_failed_audit_root(tmp_path, retry)
