{
  "schema_version": 1,
  "authorization_id": "datong_stage_direction_event_stability_diagnostic_2024_2025_v1_execution_authorization",
  "experiment_id": "datong_stage_direction_event_stability_diagnostic_2024_2025_v1",
  "authorized": true,
  "scope": {
    "blind_catalogue_runs": 1,
    "main_diagnostic_runs_if_coverage_passes": 1,
    "independent_audit_runs": 1,
    "training_runs": 0,
    "gpu": false,
    "overwrite": false,
    "other_process_interference": false
  },
  "preregistration": {
    "relative_path": "docs/records/DATONG_STAGE_DIRECTION_EVENT_STABILITY_DIAGNOSTIC_2024_2025_V1_PREREGISTRATION.json",
    "bytes": 22267,
    "sha256": "efcd2a853c93be157f11d4ac6b77041107704fb24efb6cb3765ff1ddb9facf36"
  },
  "interpreter": {
    "path": "C:\\Users\\yiqun\\anaconda3\\python.exe",
    "bytes": 92160,
    "sha256": "c98caee82c66433f0e89d4abbf152b39a7dc2e99979b28dcb021598b4e3f5642",
    "version": "3.11.5 | packaged by Anaconda, Inc. | (main, Sep 11 2023, 13:26:23) [MSC v.1916 64 bit (AMD64)]"
  },
  "implementations": {
    "blind_input_reader": {
      "relative_path": "scripts/analysis/load_datong_stage_event_blind_inputs_v1.py",
      "bytes": 22200,
      "sha256": "3a0fa479e59562a3b12467ef628916fa3395dc2c5e07435ffbd9d7c9de7e5cf5"
    },
    "blind_catalogue": {
      "relative_path": "scripts/analysis/build_datong_stage_event_catalog_v1.py",
      "bytes": 55821,
      "sha256": "4271b6ded24266cb5ffbff9c1df5d8f3a39306003aefc7c0a318797fc9d2339a"
    },
    "main_diagnostic": {
      "relative_path": "scripts/analysis/datong_stage_event_stability_diagnostic_v1.py",
      "bytes": 83114,
      "sha256": "677ae5b4739eec24f3a5613ac362a5ea8002d821197a731a425eebcb944d995c"
    },
    "independent_audit": {
      "relative_path": "scripts/analysis/independent_audit_datong_stage_event_stability_v1.py",
      "bytes": 104877,
      "sha256": "ccf053d7944f47e2af8d4de3f90b686b06f38e2b2832b4121b6f3e2c0b987ee0"
    }
  },
  "tests": {
    "blind_input_reader": {
      "relative_path": "tests/test_load_datong_stage_event_blind_inputs_v1.py",
      "bytes": 9320,
      "sha256": "2dbce0052e369c062e06230decf7090afa1946f596bd4c6007185fe6eb36bf62"
    },
    "blind_catalogue": {
      "relative_path": "tests/test_build_datong_stage_event_catalog_v1.py",
      "bytes": 35963,
      "sha256": "7f2f43eaa01ac3955cf486173485dcc09ee171c3676fe3f6dc0a421af12b295e"
    },
    "main_diagnostic": {
      "relative_path": "tests/test_datong_stage_event_stability_diagnostic_v1.py",
      "bytes": 34625,
      "sha256": "2bb3e1200b5ca75c1a9f6c0651d929c342272ef67b9502df196be1ad21f6342f"
    },
    "independent_audit": {
      "relative_path": "tests/test_independent_audit_datong_stage_event_stability_v1.py",
      "bytes": 43266,
      "sha256": "e99d858cbf72c624476335194ae7c7072d7fe8e8b8adb257d9f749fe203694e7"
    }
  },
  "test_evidence": {
    "command": [
      "C:\\Users\\yiqun\\anaconda3\\python.exe",
      "-m",
      "pytest",
      "-q",
      "tests/test_load_datong_stage_event_blind_inputs_v1.py",
      "tests/test_build_datong_stage_event_catalog_v1.py",
      "tests/test_datong_stage_event_stability_diagnostic_v1.py",
      "tests/test_independent_audit_datong_stage_event_stability_v1.py"
    ],
    "test_paths": [
      "tests/test_load_datong_stage_event_blind_inputs_v1.py",
      "tests/test_build_datong_stage_event_catalog_v1.py",
      "tests/test_datong_stage_event_stability_diagnostic_v1.py",
      "tests/test_independent_audit_datong_stage_event_stability_v1.py"
    ],
    "passed": 153,
    "failed": 0,
    "exit_code": 0,
    "synthetic_only": true
  },
  "static_review": {
    "p0": 0,
    "p1": 0
  }
}
