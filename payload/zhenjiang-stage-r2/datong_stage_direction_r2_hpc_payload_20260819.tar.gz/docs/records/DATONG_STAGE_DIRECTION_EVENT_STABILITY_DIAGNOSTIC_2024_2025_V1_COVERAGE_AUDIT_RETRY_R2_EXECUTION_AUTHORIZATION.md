{
  "schema_version": 1,
  "authorization_id": "datong_stage_direction_event_stability_diagnostic_2024_2025_v1_coverage_audit_retry_r2_execution_authorization",
  "experiment_id": "datong_stage_direction_event_stability_diagnostic_2024_2025_v1",
  "retry_id": "coverage_audit_retry_r2",
  "authorized": true,
  "scope": {
    "independent_coverage_only_audit_runs": 1,
    "blind_catalogue_runs": 0,
    "main_diagnostic_runs": 0,
    "training_runs": 0,
    "prediction_package_open_count": 0,
    "prediction_array_read_count": 0,
    "target_array_read_count": 0,
    "target_numeric_parse_count": 0,
    "forecast_error_read_count": 0,
    "formal_result_root_open_count": 0,
    "gpu": false,
    "overwrite": false,
    "other_process_interference": false,
    "other_process_termination": false,
    "other_process_pause": false,
    "other_process_priority_change": false,
    "other_process_restart": false,
    "other_process_signal": false,
    "fresh_resource_gate_required": true,
    "resource_policy_inherited_unchanged_from_original_event_preregistration": true
  },
  "retry_preregistration": {
    "relative_path": "docs/records/DATONG_STAGE_DIRECTION_EVENT_STABILITY_DIAGNOSTIC_2024_2025_V1_COVERAGE_AUDIT_RETRY_R2_PREREGISTRATION.json",
    "bytes": 10987,
    "sha256": "aac877051076d9a83871f2a78b56745c9aa88ec6e276b24ac638837fbee89a1b"
  },
  "original_event_preregistration": {
    "relative_path": "docs/records/DATONG_STAGE_DIRECTION_EVENT_STABILITY_DIAGNOSTIC_2024_2025_V1_PREREGISTRATION.json",
    "bytes": 22267,
    "sha256": "efcd2a853c93be157f11d4ac6b77041107704fb24efb6cb3765ff1ddb9facf36"
  },
  "original_execution_authorization": {
    "relative_path": "docs/records/DATONG_STAGE_DIRECTION_EVENT_STABILITY_DIAGNOSTIC_2024_2025_V1_EXECUTION_AUTHORIZATION.md",
    "bytes": 3679,
    "sha256": "9e193723e69b0ebf488a30c48d53af18d4be64858703a62f32a3f336ac34c06a"
  },
  "bound_blind_catalogue_outputs": {
    "completion_manifest": {
      "relative_path": "results/analysis/datong_stage_event_catalog_2024_2025_v1/completion_manifest.json",
      "bytes": 1604,
      "sha256": "378c1ac095f8d55e4e9a96450b059010b06e309c563ed7aa96e8c456bf7ef2ee"
    },
    "blind_event_manifest": {
      "relative_path": "results/analysis/datong_stage_event_catalog_2024_2025_v1/blind_event_manifest.json",
      "bytes": 1378,
      "sha256": "d89f08572e628687a5c115e9ac1add4f4610fdb0791b1c1e2efebbc5adc5c667"
    },
    "coverage_decision": {
      "relative_path": "results/analysis/datong_stage_event_catalog_2024_2025_v1/coverage_decision.json",
      "bytes": 529,
      "sha256": "f487e79fcbde41b968f47764e0dc3e3715ece6d5a5573ae1b8a42d9012f77c06"
    },
    "expected_decision": "HOLD_EXPLORATORY_INSUFFICIENT_PAIRED_EVENT_COVERAGE",
    "expected_coverage_passed": false,
    "expected_paired_event_count": 1,
    "minimum_paired_event_count": 10
  },
  "bound_failed_audit_outputs": {
    "completion_manifest": {
      "relative_path": "results/analysis/datong_stage_event_stability_2024_2025_v1_independent_audit/completion_manifest.json",
      "bytes": 1557,
      "sha256": "97daa99f0325838dcf0c9c0f000e8ca91b3927fe05e4d0da6d659559e00217fc"
    },
    "independent_audit_summary": {
      "relative_path": "results/analysis/datong_stage_event_stability_2024_2025_v1_independent_audit/independent_audit_summary.json",
      "bytes": 430,
      "sha256": "ff56976f663fba782a6f577089b7c0906bc2662def494496d4b9382b274e7af5"
    },
    "mismatches": {
      "relative_path": "results/analysis/datong_stage_event_stability_2024_2025_v1_independent_audit/mismatches.csv",
      "bytes": 3802,
      "sha256": "2a5c54a6e447f5380cc28ec034df071f1e16855838b66ee287ac279e4d0c0bb6"
    },
    "recorded_audit_status": "not_reproducible",
    "recorded_mismatch_count": 60,
    "recorded_coverage_passed": false,
    "recorded_paired_event_count": 1,
    "prediction_package_read_count": 0
  },
  "failed_run_source_and_test_identities": {
    "independent_audit_source": {
      "relative_path": "scripts/analysis/independent_audit_datong_stage_event_stability_v1.py",
      "bytes": 104877,
      "sha256": "ccf053d7944f47e2af8d4de3f90b686b06f38e2b2832b4121b6f3e2c0b987ee0"
    },
    "independent_audit_test": {
      "relative_path": "tests/test_independent_audit_datong_stage_event_stability_v1.py",
      "bytes": 43266,
      "sha256": "e99d858cbf72c624476335194ae7c7072d7fe8e8b8adb257d9f749fe203694e7"
    }
  },
  "interpreter": {
    "path": "C:\\Users\\yiqun\\anaconda3\\python.exe",
    "bytes": 92160,
    "sha256": "c98caee82c66433f0e89d4abbf152b39a7dc2e99979b28dcb021598b4e3f5642",
    "version": "3.11.5 | packaged by Anaconda, Inc. | (main, Sep 11 2023, 13:26:23) [MSC v.1916 64 bit (AMD64)]"
  },
  "implementations": {
    "independent_audit": {
      "relative_path": "scripts/analysis/independent_audit_datong_stage_event_stability_v1.py",
      "bytes": 142531,
      "sha256": "4f3064da539ad7fc406c5f99b3ccc70fd65d5a04981edbf03aaa1f04c8b7025b"
    }
  },
  "tests": {
    "independent_audit": {
      "relative_path": "tests/test_independent_audit_datong_stage_event_stability_v1.py",
      "bytes": 59896,
      "sha256": "7aa4f069480e5291c05df99ab55ffdec172cc9caf9110687368ccdd32148fccc"
    }
  },
  "test_evidence": {
    "command": [
      "C:\\Users\\yiqun\\anaconda3\\python.exe",
      "-m",
      "pytest",
      "-q",
      "tests/test_independent_audit_datong_stage_event_stability_v1.py"
    ],
    "test_paths": [
      "tests/test_independent_audit_datong_stage_event_stability_v1.py"
    ],
    "passed": 64,
    "failed": 0,
    "exit_code": 0,
    "synthetic_only": true
  },
  "static_review": {
    "p0": 0,
    "p1": 0
  }
}
