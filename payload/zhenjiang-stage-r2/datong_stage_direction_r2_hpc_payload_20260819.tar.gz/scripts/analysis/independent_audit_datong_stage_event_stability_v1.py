#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Independently audit the frozen Datong event-stability diagnostic.

The audit intentionally does not import the blind reader, blind event builder,
or main event scorer.  It reads only the registered columns from the seven raw
timelines, reconstructs issue positions and events, and then either publishes
a coverage-only audit without touching a prediction package or independently
reconstructs all diagnostic tables from the previously audited sixty packages.
"""

from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
from typing import Any, Callable, Iterable, Mapping, Sequence

import numpy as np
import pandas as pd
import psutil
import threadpoolctl
import torch


PROJECT_ROOT = Path(__file__).resolve().parents[2]
PREREGISTRATION_RELATIVE_PATH = Path(
    "docs/records/"
    "DATONG_STAGE_DIRECTION_EVENT_STABILITY_DIAGNOSTIC_2024_2025_"
    "V1_PREREGISTRATION.json"
)
PREREGISTRATION_BYTES = 22_267
PREREGISTRATION_SHA256 = (
    "efcd2a853c93be157f11d4ac6b77041107704fb24efb6cb3765ff1ddb9facf36"
)
R2_PREREGISTRATION_RELATIVE_PATH = Path(
    "docs/records/"
    "DATONG_STAGE_DIRECTION_EVENT_STABILITY_DIAGNOSTIC_2024_2025_V1_"
    "COVERAGE_AUDIT_RETRY_R2_PREREGISTRATION.json"
)
R2_PREREGISTRATION_BYTES = 10_987
R2_PREREGISTRATION_SHA256 = (
    "aac877051076d9a83871f2a78b56745c9aa88ec6e276b24ac638837fbee89a1b"
)
R2_PREREGISTRATION_ID = (
    "datong_stage_direction_event_stability_diagnostic_2024_2025_v1_"
    "coverage_audit_retry_r2"
)
R2_RETRY_ID = "coverage_audit_retry_r2"
R2_RESULT_LABEL = "technical_coverage_audit_retry_only_not_scientific_reanalysis"
SOURCE_RELATIVE_PATH = Path(
    "scripts/analysis/independent_audit_datong_stage_event_stability_v1.py"
)
AUTHORIZATION_RELATIVE_PATH = Path(
    "docs/records/"
    "DATONG_STAGE_DIRECTION_EVENT_STABILITY_DIAGNOSTIC_2024_2025_"
    "V1_EXECUTION_AUTHORIZATION.md"
)
AUTHORIZATION_ID = (
    "datong_stage_direction_event_stability_diagnostic_2024_2025_v1_"
    "execution_authorization"
)
R2_AUTHORIZATION_RELATIVE_PATH = Path(
    "docs/records/"
    "DATONG_STAGE_DIRECTION_EVENT_STABILITY_DIAGNOSTIC_2024_2025_V1_"
    "COVERAGE_AUDIT_RETRY_R2_EXECUTION_AUTHORIZATION.md"
)
R2_AUTHORIZATION_ID = (
    "datong_stage_direction_event_stability_diagnostic_2024_2025_v1_"
    "coverage_audit_retry_r2_execution_authorization"
)
EXPERIMENT_ID = "datong_stage_direction_event_stability_diagnostic_2024_2025_v1"
RESULT_LABEL = "exploratory_post_outcome_event_diagnostic_not_confirmation"
TARGETS = ("zhenjiang", "jiangyin")
REFERENCE_CONDITION = "hidden_target"
CANDIDATE_CONDITIONS = ("hidden_target_both_nearest", "endpoints_only")
CONDITIONS = (REFERENCE_CONDITION,) + CANDIDATE_CONDITIONS
SEEDS = (17, 29, 43, 57, 71, 83, 97, 109, 127, 139)
FORECAST_HOURS = (1, 2, 3, 4, 5, 6)
STATIONS = ("datong", "nanjing", "zhenjiang", "jiangyin", "xuliujing", "wusongkou")
MINIMUM_PAIRED_EVENT_COUNT = 10
EXPECTED_PACKAGE_COUNT = 60
FLOAT_TOLERANCE = 1e-12
MAXIMUM_PATH_CHARACTERS = 240
LAUNCHER_THREAD_ENVIRONMENT = {
    "CUDA_VISIBLE_DEVICES": "-1",
    "OMP_NUM_THREADS": "1",
    "MKL_NUM_THREADS": "1",
    "OPENBLAS_NUM_THREADS": "1",
    "NUMEXPR_NUM_THREADS": "1",
}
REGISTERED_FAMILY_SCRIPTS = (
    "scripts/analysis/build_datong_stage_event_catalog_v1.py",
    "scripts/analysis/datong_stage_event_stability_diagnostic_v1.py",
    "scripts/analysis/independent_audit_datong_stage_event_stability_v1.py",
    "scripts/analysis/hidden_gauge_single_side_direction_diagnostic_v1.py",
    "scripts/analysis/independent_audit_hidden_gauge_single_side_direction_v1.py",
)
AUTHORIZED_IMPLEMENTATION_PATHS = {
    "blind_input_reader": "scripts/analysis/load_datong_stage_event_blind_inputs_v1.py",
    "blind_catalogue": "scripts/analysis/build_datong_stage_event_catalog_v1.py",
    "main_diagnostic": "scripts/analysis/datong_stage_event_stability_diagnostic_v1.py",
    "independent_audit": "scripts/analysis/independent_audit_datong_stage_event_stability_v1.py",
}
AUTHORIZED_TEST_PATHS = {
    "blind_input_reader": "tests/test_load_datong_stage_event_blind_inputs_v1.py",
    "blind_catalogue": "tests/test_build_datong_stage_event_catalog_v1.py",
    "main_diagnostic": "tests/test_datong_stage_event_stability_diagnostic_v1.py",
    "independent_audit": "tests/test_independent_audit_datong_stage_event_stability_v1.py",
}
AUTHORIZED_SCOPE = {
    "blind_catalogue_runs": 1,
    "main_diagnostic_runs_if_coverage_passes": 1,
    "independent_audit_runs": 1,
    "training_runs": 0,
    "gpu": False,
    "overwrite": False,
    "other_process_interference": False,
}
R2_AUTHORIZED_SCOPE = {
    "independent_coverage_only_audit_runs": 1,
    "blind_catalogue_runs": 0,
    "main_diagnostic_runs": 0,
    "training_runs": 0,
    "prediction_package_open_count": 0,
    "prediction_array_read_count": 0,
    "target_array_read_count": 0,
    "target_numeric_parse_count": 0,
    "forecast_error_read_count": 0,
    "formal_result_root_open_count": 0,
    "gpu": False,
    "overwrite": False,
    "other_process_interference": False,
    "other_process_termination": False,
    "other_process_pause": False,
    "other_process_priority_change": False,
    "other_process_restart": False,
    "other_process_signal": False,
    "fresh_resource_gate_required": True,
    "resource_policy_inherited_unchanged_from_original_event_preregistration": True,
}
R2_AUTHORIZED_IMPLEMENTATION_PATHS = {
    "independent_audit": SOURCE_RELATIVE_PATH.as_posix(),
}
R2_AUTHORIZED_TEST_PATHS = {
    "independent_audit": (
        "tests/test_independent_audit_datong_stage_event_stability_v1.py"
    ),
}
CATALOG_COLUMNS = (
    "event_id", "event_status", "observed_start_beijing",
    "event_end_beijing", "closure_proof_end_beijing", "left_censored",
    "right_censored", "rising_issue_count", "falling_issue_count",
    "excluded_issue_count", "eligible_paired",
)
ISSUE_MAP_COLUMNS = (
    "record_index", "issue_position", "issue_time_beijing", "block_id",
    "event_id", "in_event", "event_status", "eligible_paired", "state",
    "issue_stage_m", "reference_stage_m", "delta_m",
    "issue_stage_raw_uint32", "reference_stage_raw_uint32",
    "delta_raw_uint32",
)
COVERAGE_COLUMNS = (
    "total_event_count", "left_censored_event_count",
    "right_censored_event_count", "complete_event_count",
    "one_sided_complete_event_count", "paired_event_count",
    "minimum_paired_event_count", "coverage_passed",
)
BLIND_CATALOG_ARTIFACTS = (
    "event_catalog_blind.csv",
    "event_issue_map_blind.csv",
    "event_coverage_blind.csv",
    "coverage_decision.json",
)
BLIND_COVERAGE_DECISION_FIELDS = {
    "schema_version", "experiment_id", "result_label", "decision",
    "paired_event_count", "minimum_paired_event_count", "coverage_passed",
    "prediction_package_open_count", "prediction_array_read_count",
    "target_array_read_count", "forecast_error_read_count",
    "formal_result_root_open_count",
}
PACKAGE_KEYS = {
    "schema_version", "task_id", "target", "condition", "seed",
    "target_index", "issue_positions", "issue_times_beijing", "block_ids",
    "states", "issue_stage_m", "reference_stage_m", "delta_m",
    "issue_stage_raw_uint32", "reference_stage_raw_uint32",
    "delta_raw_uint32", "predictions_m", "targets_m", "checkpoint_sha256",
    "completion_manifest_sha256", "source_identities_json",
}
EVENT_SEED_LEAD_COLUMNS = (
    "target", "condition", "seed", "event_id", "lead_hour",
    "rising_issue_count", "falling_issue_count",
    "rising_mean_increment_m", "falling_mean_increment_m", "contrast_m",
)
EVENT_LEVEL_COLUMNS = (
    "target", "condition", "event_id", "event_contrast_m", "positive_event",
)
SEED_LEVEL_COLUMNS = (
    "target", "condition", "seed", "seed_contrast_m", "positive_seed",
)
LEAD_LEVEL_COLUMNS = (
    "target", "condition", "lead_hour", "lead_hour_contrast_m",
    "strictly_positive",
)
LEAVE_ONE_OUT_COLUMNS = (
    "target", "condition", "removed_event_id", "remaining_event_count",
    "overall_contrast_m", "positive_seed_count", "sign_flip_from_full",
    "below_0_01_m",
)
EVENT_INFLUENCE_COLUMNS = (
    "target", "condition", "removed_event_id", "full_overall_contrast_m",
    "leave_one_out_overall_contrast_m", "absolute_change_m",
    "is_maximum_absolute_change", "sign_flip_from_full", "below_0_01_m",
)
COVERAGE_AUDIT_ARTIFACTS = (
    "reconstructed_event_catalog.csv",
    "reconstructed_event_issue_map.csv",
    "reconstructed_event_coverage.csv",
    "mismatches.csv",
    "independent_audit_summary.json",
    "input_manifest.json",
    "resource_snapshot.json",
)
FULL_AUDIT_ARTIFACTS = (
    "reconstructed_event_catalog.csv",
    "reconstructed_event_issue_map.csv",
    "reconstructed_event_coverage.csv",
    "reconstructed_event_seed_lead_metrics.csv",
    "reconstructed_event_level_summary.csv",
    "reconstructed_seed_level_summary.csv",
    "reconstructed_lead_hour_summary.csv",
    "reconstructed_leave_one_event_out.csv",
    "reconstructed_event_influence_summary.csv",
    "mismatches.csv",
    "independent_audit_summary.json",
    "input_manifest.json",
    "resource_snapshot.json",
)
MISMATCH_COLUMNS = ("category", "artifact", "field", "detail")
R2_FLOAT32_CSV_COLUMNS = frozenset(
    {"issue_stage_m", "reference_stage_m", "delta_m"}
)
R2_RAW_UINT32_COLUMNS = frozenset(
    {
        "issue_stage_raw_uint32",
        "reference_stage_raw_uint32",
        "delta_raw_uint32",
    }
)


class AuditContractError(RuntimeError):
    """Raised when the independent audit cannot safely continue."""


class AuditResourceGateError(RuntimeError):
    """Raised before raw-data, result, or output access on contention."""

    def __init__(self, snapshot: Mapping[str, Any]):
        super().__init__("HOLD_RESOURCE_CONTENTION")
        self.snapshot = dict(snapshot)


@dataclass(frozen=True)
class IndependentBlindInputs:
    times: tuple[pd.Timestamp, ...]
    datong_stage: np.ndarray
    history_missing: np.ndarray
    target_missing: np.ndarray
    issue_positions: np.ndarray
    block_ids: np.ndarray
    access_audit: Mapping[str, Any]
    identities: Mapping[str, Any]


def _hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _json_text(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _safe_path(
    project_root: Path, path_value: str | Path, *, must_exist: bool
) -> Path:
    root = Path(project_root).resolve()
    candidate = Path(path_value)
    if not candidate.is_absolute():
        candidate = root / candidate
    resolved = candidate.resolve(strict=must_exist)
    try:
        resolved.relative_to(root)
    except ValueError as exc:
        raise AuditContractError(f"path escapes project root: {path_value}") from exc
    return resolved


def _relative(path: Path, project_root: Path) -> str:
    return Path(path).resolve().relative_to(Path(project_root).resolve()).as_posix()


def _read_json(path: Path) -> dict[str, Any]:
    def reject_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise AuditContractError(f"duplicate JSON field: {key}")
            result[key] = value
        return result

    try:
        payload = json.loads(
            Path(path).read_text(encoding="utf-8"),
            object_pairs_hook=reject_duplicates,
        )
    except json.JSONDecodeError as exc:
        raise AuditContractError(
            f"file must contain one pure JSON value: {path}"
        ) from exc
    if not isinstance(payload, dict):
        raise AuditContractError(f"JSON root changed: {path}")
    return payload


def _require_builtin_json_int(value: object, label: str) -> int:
    if type(value) is not int:
        raise AuditContractError(f"{label} must be a built-in integer")
    return value


def _strict_bool(value: object, label: str) -> bool:
    if isinstance(value, (bool, np.bool_)):
        return bool(value)
    if isinstance(value, str) and value in {"True", "False"}:
        return value == "True"
    raise AuditContractError(f"{label} is not a canonical Boolean")


def _parse_beijing(value: str, label: str) -> pd.Timestamp:
    stamp = pd.Timestamp(value)
    if stamp.tzinfo is None or stamp.utcoffset() != timedelta(hours=8):
        raise AuditContractError(f"{label} is not Beijing time with +08:00")
    return stamp


def _time_axis_digest(times: Sequence[pd.Timestamp]) -> str:
    text = "\n".join(stamp.isoformat() for stamp in times) + "\n"
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _verify_identity(
    project_root: Path, identity: Mapping[str, Any]
) -> dict[str, Any]:
    if set(identity) != {"relative_path", "bytes", "sha256"}:
        raise AuditContractError("registered file identity schema changed")
    path = _safe_path(project_root, str(identity["relative_path"]), must_exist=True)
    observed = {
        "relative_path": _relative(path, project_root),
        "bytes": path.stat().st_size,
        "sha256": _hash_file(path),
    }
    if observed != dict(identity):
        raise AuditContractError(f"registered file identity changed: {identity['relative_path']}")
    return observed


def validate_frozen_config(config: Mapping[str, Any]) -> None:
    if config.get("schema_version") != 1 or config.get("experiment_id") != EXPERIMENT_ID:
        raise AuditContractError("frozen configuration identity changed")
    if config.get("result_label") != RESULT_LABEL:
        raise AuditContractError("frozen result label changed")
    scoring = config.get("scoring_inputs")
    if not isinstance(scoring, Mapping) or (
        scoring.get("targets") != list(TARGETS)
        or scoring.get("reference_condition") != REFERENCE_CONDITION
        or scoring.get("candidate_conditions") != list(CANDIDATE_CONDITIONS)
        or scoring.get("seeds") != list(SEEDS)
        or scoring.get("checkpoint_load_allowed") is not False
        or scoring.get("inference_allowed") is not False
        or scoring.get("training_allowed") is not False
    ):
        raise AuditContractError("frozen scoring contract changed")
    output = config.get("output_contract")
    if not isinstance(output, Mapping) or (
        output.get("coverage_only_audit_precompletion_artifacts")
        != list(COVERAGE_AUDIT_ARTIFACTS)
        or output.get("full_audit_precompletion_artifacts")
        != list(FULL_AUDIT_ARTIFACTS)
        or output.get("coverage_only_audit_precompletion_artifact_count") != 7
        or output.get("full_audit_precompletion_artifact_count") != 13
        or output.get("maximum_absolute_path_characters") != 240
        or output.get("audit_exclusive_creation") is not True
        or output.get("audit_overwrite_allowed") is not False
        or output.get("audit_atomic_final_rename") is not True
        or output.get("audit_completion_manifest_written_last") is not True
    ):
        raise AuditContractError("frozen audit output contract changed")
    gate = config.get("resource_gate")
    protected = (
        "graphics_processor_use_allowed", "other_process_termination_allowed",
        "other_process_pause_allowed", "other_process_priority_change_allowed",
        "other_process_restart_allowed", "other_process_signal_allowed",
        "other_experiment_lock_access_or_change_allowed",
    )
    if not isinstance(gate, Mapping) or any(gate.get(name) is not False for name in protected):
        raise AuditContractError("other-process protection changed")
    if (
        gate.get("minimum_available_physical_memory_bytes") != 6_442_450_944
        or gate.get("maximum_mean_total_cpu_utilization_percent") != 50.0
        or gate.get("cpu_utilization_sample_count") != 3
        or gate.get("cpu_utilization_sample_interval_seconds") != 2.0
        or gate.get("minimum_free_output_disk_bytes") != 2_147_483_648
    ):
        raise AuditContractError("resource thresholds changed")
    runtime = config.get("runtime_thread_contract")
    if not isinstance(runtime, Mapping) or (
        runtime.get("launcher_environment_before_python")
        != LAUNCHER_THREAD_ENVIRONMENT
        or runtime.get("torch_set_num_threads") != 1
        or runtime.get("torch_set_num_interop_threads") != 1
        or runtime.get("every_reported_numerical_thread_pool_maximum") != 1
        or runtime.get("device") != "cpu"
        or runtime.get("torch_cuda_must_remain_uninitialized") is not True
    ):
        raise AuditContractError("runtime thread contract changed")


def load_frozen_config(
    path: Path = PROJECT_ROOT / PREREGISTRATION_RELATIVE_PATH,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    resolved = _safe_path(project_root, path, must_exist=True)
    if resolved.stat().st_size != PREREGISTRATION_BYTES:
        raise AuditContractError("preregistration byte count changed")
    if _hash_file(resolved) != PREREGISTRATION_SHA256:
        raise AuditContractError("preregistration SHA-256 changed")
    payload = _read_json(resolved)
    validate_frozen_config(payload)
    return payload


def enforce_single_thread_runtime(
    *,
    threadpool_info_provider: Callable[[], list[dict[str, Any]]] = (
        threadpoolctl.threadpool_info
    ),
) -> dict[str, Any]:
    drift = {
        key: os.environ.get(key)
        for key, expected in LAUNCHER_THREAD_ENVIRONMENT.items()
        if os.environ.get(key) != expected
    }
    if drift:
        raise AuditContractError("launcher environment changed: " + _json_text(drift))
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    pools = threadpool_info_provider()
    if torch.get_num_threads() != 1 or torch.get_num_interop_threads() != 1:
        raise AuditContractError("PyTorch thread count is not one")
    for row in pools:
        if (
            not isinstance(row, Mapping)
            or type(row.get("num_threads")) is not int
            or row["num_threads"] != 1
        ):
            raise AuditContractError(
                "a reported numerical thread pool is not exactly one thread"
            )
    if torch.cuda.is_initialized():
        raise AuditContractError("graphics-processor runtime already initialized")
    return {
        "launcher_environment": dict(LAUNCHER_THREAD_ENVIRONMENT),
        "torch_num_threads": torch.get_num_threads(),
        "torch_num_interop_threads": torch.get_num_interop_threads(),
        "threadpools": pools,
        "torch_device": "cpu",
        "torch_cuda_initialized": False,
    }


def _direct_python_script(
    command: Sequence[str], cwd: str | None, expected_script: Path
) -> bool:
    if not command:
        return False
    executable = Path(str(command[0])).name.casefold()
    if executable.endswith(".exe"):
        executable = executable[:-4]
    suffix = executable.removeprefix("python")
    versioned = bool(suffix) and all(part.isdigit() for part in suffix.split("."))
    if executable not in {"python", "pythonw"} and not versioned:
        return False
    base = Path(cwd).resolve() if cwd else Path.cwd().resolve()
    arguments = [str(item) for item in command[1:]]
    index = 0
    while index < len(arguments):
        item = arguments[index]
        if item in {"-c", "-m"}:
            return False
        if item == "--":
            index += 1
            if index >= len(arguments):
                return False
            item = arguments[index]
        elif item in {"-W", "-X"}:
            index += 2
            continue
        elif item.startswith(("-W", "-X")) or item.startswith("-"):
            index += 1
            continue
        candidate = Path(item)
        if not candidate.is_absolute():
            candidate = base / candidate
        try:
            return candidate.resolve() == expected_script.resolve()
        except (OSError, RuntimeError):
            return False
    return False


def count_other_family_processes(
    project_root: Path = PROJECT_ROOT,
    *,
    process_iterator: Callable[..., Any] = psutil.process_iter,
) -> int:
    scripts = tuple(
        _safe_path(project_root, value, must_exist=False)
        for value in REGISTERED_FAMILY_SCRIPTS
    )
    own_pid = os.getpid()
    count = 0
    for process in process_iterator(attrs=["pid", "cmdline", "cwd"]):
        try:
            if process.info["pid"] == own_pid:
                continue
            if any(
                _direct_python_script(
                    process.info.get("cmdline") or (), process.info.get("cwd"), script
                )
                for script in scripts
            ):
                count += 1
        except (psutil.AccessDenied, psutil.NoSuchProcess, psutil.ZombieProcess):
            continue
    return count


def _resource_sample(index: int, interval: float) -> dict[str, Any]:
    del index
    return {
        "available_physical_memory_bytes": int(psutil.virtual_memory().available),
        "total_cpu_utilization_percent": float(psutil.cpu_percent(interval=interval)),
    }


def _existing_parent(path: Path) -> Path:
    current = Path(path)
    while not current.exists():
        if current == current.parent:
            raise AuditContractError(f"no existing parent for {path}")
        current = current.parent
    return current


def audit_resource_gate(
    config: Mapping[str, Any],
    project_root: Path = PROJECT_ROOT,
    *,
    snapshot_provider: Callable[[int, float], Mapping[str, Any]] = _resource_sample,
    process_counter: Callable[[], int] | None = None,
) -> dict[str, Any]:
    gate = config["resource_gate"]
    output_root = _safe_path(
        project_root, config["output_roots"]["independent_audit"], must_exist=False
    )
    temporary_root = output_root.parent / (
        f"{output_root.name}.incomplete_pid_{os.getpid()}"
    )
    if process_counter is None:
        process_counter = lambda: count_other_family_processes(project_root)
    samples = []
    for index in range(3):
        raw = snapshot_provider(index, 2.0)
        memory = int(raw["available_physical_memory_bytes"])
        cpu = float(raw["total_cpu_utilization_percent"])
        if memory < 0 or not np.isfinite(cpu) or not 0.0 <= cpu <= 100.0:
            raise AuditContractError("invalid resource sample")
        samples.append(
            {
                "sample_index": index + 1,
                "available_physical_memory_bytes": memory,
                "total_cpu_utilization_percent": cpu,
            }
        )
    minimum_memory = min(row["available_physical_memory_bytes"] for row in samples)
    mean_cpu = float(np.mean([row["total_cpu_utilization_percent"] for row in samples]))
    disk = int(shutil.disk_usage(_existing_parent(output_root.parent)).free)
    other_count = int(process_counter())
    reasons = []
    if minimum_memory < int(gate["minimum_available_physical_memory_bytes"]):
        reasons.append("available physical memory below registered minimum")
    if mean_cpu > float(gate["maximum_mean_total_cpu_utilization_percent"]):
        reasons.append("mean processor utilization above registered maximum")
    if disk < int(gate["minimum_free_output_disk_bytes"]):
        reasons.append("free disk below registered minimum")
    if other_count != 0:
        reasons.append("another registered analysis process is running")
    if output_root.exists():
        reasons.append("exclusive audit output already exists")
    if temporary_root.exists():
        reasons.append("process-specific incomplete audit output already exists")
    if torch.cuda.is_initialized():
        reasons.append("graphics-processor runtime is initialized")
    snapshot = {
        "schema_version": 1,
        "experiment_id": EXPERIMENT_ID,
        "captured_at_utc": datetime.now(timezone.utc).isoformat(),
        "samples": samples,
        "minimum_available_physical_memory_bytes_observed": minimum_memory,
        "mean_total_cpu_utilization_percent": mean_cpu,
        "free_output_disk_bytes": disk,
        "other_matching_analysis_process_count": other_count,
        "output_root_preexisting": output_root.exists(),
        "temporary_output_root_preexisting": temporary_root.exists(),
        "graphics_processor_runtime_initialized": torch.cuda.is_initialized(),
        "passed": not reasons,
        "failure_reasons": reasons,
    }
    if reasons:
        raise AuditResourceGateError(snapshot)
    return snapshot


def _read_aligned_target_flags(
    path: Path, reader_contract: Mapping[str, Any]
) -> tuple[tuple[pd.Timestamp, ...], np.ndarray, dict[str, Any]]:
    required = list(reader_contract["aligned_target_header_required"])
    start = _parse_beijing(str(reader_contract["evaluation_start_beijing"]), "start")
    end = _parse_beijing(str(reader_contract["evaluation_end_beijing"]), "end")
    times: list[pd.Timestamp] = []
    flags: list[list[bool]] = []
    source_row_count = 0
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames != required:
            raise AuditContractError("aligned target header changed")
        for raw in reader:
            source_row_count += 1
            stamp = _parse_beijing(raw["time_beijing"], "aligned time")
            if stamp < start or stamp > end:
                continue
            row_flags = []
            for station in STATIONS:
                missing = _strict_bool(raw[f"{station}_missing"], "target missing")
                value_present = raw[f"{station}_target_m"].strip() != ""
                if missing == value_present:
                    raise AuditContractError("target missingness/value emptiness disagrees")
                row_flags.append(missing)
            times.append(stamp)
            flags.append(row_flags)
    return tuple(times), np.asarray(flags, dtype=np.bool_), {
        "parsed_columns": ["time_beijing"] + [f"{station}_missing" for station in STATIONS],
        "consistency_checked_non_numeric_columns": [
            f"{station}_target_m" for station in STATIONS
        ],
        "row_count": len(times),
        "source_row_count": source_row_count,
        "time_axis_sha256": _time_axis_digest(times),
    }


def _read_realtime_flags(
    path: Path,
    reader_contract: Mapping[str, Any],
    *,
    parse_stage: bool,
) -> tuple[tuple[pd.Timestamp, ...], np.ndarray, np.ndarray | None, dict[str, Any]]:
    required = list(reader_contract["realtime_header_required"])
    start = _parse_beijing(str(reader_contract["evaluation_start_beijing"]), "start")
    end = _parse_beijing(str(reader_contract["evaluation_end_beijing"]), "end")
    times: list[pd.Timestamp] = []
    missing_values: list[bool] = []
    stages: list[np.float32] = []
    for_stage_numeric_count = 0
    source_row_count = 0
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames != required:
            raise AuditContractError("realtime header changed")
        for raw in reader:
            source_row_count += 1
            stamp = _parse_beijing(raw["time_beijing"], "realtime time")
            if stamp < start or stamp > end:
                continue
            if raw["TIME"] != raw["time_beijing"]:
                raise AuditContractError("TIME and time_beijing differ")
            utc = pd.Timestamp(raw["time_utc"])
            if utc.tzinfo is None or utc.tz_convert("UTC") != stamp.tz_convert("UTC"):
                raise AuditContractError("UTC and Beijing timestamps differ")
            missing = _strict_bool(raw["is_missing_for_model"], "history missing")
            present = raw["STAGE"].strip() != ""
            if missing == present:
                raise AuditContractError("history missingness/value emptiness disagrees")
            if parse_stage:
                if present:
                    try:
                        stage_value = np.float32(raw["STAGE"])
                    except (TypeError, ValueError, OverflowError) as exc:
                        raise AuditContractError("Datong stage is not numeric") from exc
                    if not np.isfinite(stage_value):
                        raise AuditContractError("Datong stage is not finite")
                    stages.append(stage_value)
                else:
                    stages.append(np.float32(np.nan))
                for_stage_numeric_count += int(present)
            times.append(stamp)
            missing_values.append(missing)
    audit = {
        "parsed_columns": required if parse_stage else [
            "TIME", "time_beijing", "time_utc", "is_missing_for_model"
        ],
        "consistency_checked_non_numeric_columns": [] if parse_stage else ["STAGE"],
        "row_count": len(times),
        "source_row_count": source_row_count,
        "time_axis_sha256": _time_axis_digest(times),
        "stage_numeric_parse_count": for_stage_numeric_count,
    }
    return (
        tuple(times),
        np.asarray(missing_values, dtype=np.bool_),
        np.asarray(stages, dtype=np.float32) if parse_stage else None,
        audit,
    )


def _assert_hourly_time_axis(times: Sequence[pd.Timestamp], label: str) -> None:
    if len(times) == 0 or len(set(times)) != len(times):
        raise AuditContractError(f"{label} time axis is empty or duplicated")
    for left, right in zip(times, times[1:]):
        if right - left != pd.Timedelta(hours=1):
            raise AuditContractError(f"{label} time axis is not contiguous hourly")


def _reconstruct_issue_positions(
    history_missing: np.ndarray,
    target_missing: np.ndarray,
    reader_contract: Mapping[str, Any],
) -> tuple[np.ndarray, np.ndarray]:
    if history_missing.shape != target_missing.shape or history_missing.ndim != 2:
        raise AuditContractError("missingness arrays changed shape")
    if history_missing.shape[1] != len(STATIONS):
        raise AuditContractError("missingness station count changed")
    block_hours = int(reader_contract["seven_day_block_hours"])
    block_count = int(reader_contract["full_block_count_required"])
    if history_missing.shape[0] < block_hours * block_count:
        raise AuditContractError("fewer than seventy-one full blocks")
    positions: list[int] = []
    block_ids: list[int] = []
    for block_index in range(block_count):
        first = block_index * block_hours
        last = first + block_hours - 1
        for issue in range(first + 23, last - 24 + 1):
            history_ok = not history_missing[issue - 23 : issue + 1, :].any()
            future_ok = not target_missing[issue + 1 : issue + 25, :].any()
            if history_ok and future_ok:
                positions.append(issue)
                block_ids.append(block_index + 1)
    return np.asarray(positions, dtype=np.int64), np.asarray(block_ids, dtype=np.int32)


def load_independent_blind_inputs(
    config: Mapping[str, Any], project_root: Path = PROJECT_ROOT
) -> IndependentBlindInputs:
    identities = {
        name: _verify_identity(project_root, identity)
        for name, identity in config["blind_input_identities"].items()
    }
    contract = config["blind_input_reader"]
    aligned_path = _safe_path(
        project_root,
        config["blind_input_identities"]["aligned_target_missingness_source"][
            "relative_path"
        ],
        must_exist=True,
    )
    aligned_times, target_missing, aligned_audit = _read_aligned_target_flags(
        aligned_path, contract
    )
    _assert_hourly_time_axis(aligned_times, "aligned target")
    history_columns: list[np.ndarray] = []
    source_times: dict[str, tuple[pd.Timestamp, ...]] = {"aligned": aligned_times}
    audit_by_path: dict[str, Any] = {
        _relative(aligned_path, project_root): aligned_audit
    }
    datong_stage: np.ndarray | None = None
    for station in STATIONS:
        identity = config["blind_input_identities"][f"{station}_realtime_history"]
        path = _safe_path(project_root, identity["relative_path"], must_exist=True)
        times, missing, stage, audit = _read_realtime_flags(
            path, contract, parse_stage=(station == "datong")
        )
        _assert_hourly_time_axis(times, station)
        source_times[station] = times
        history_columns.append(missing)
        audit_by_path[_relative(path, project_root)] = audit
        if station == "datong":
            datong_stage = stage
    if any(times != aligned_times for times in source_times.values()):
        raise AuditContractError("seven selected time axes do not match exactly")
    history_missing = np.column_stack(history_columns).astype(np.bool_, copy=False)
    if datong_stage is None or datong_stage.shape != (len(aligned_times),):
        raise AuditContractError("Datong stage vector changed")
    if not np.array_equal(np.isnan(datong_stage), history_missing[:, 0]):
        raise AuditContractError("Datong stage and missingness disagree")
    issue_positions, block_ids = _reconstruct_issue_positions(
        history_missing, target_missing, contract
    )
    access_audit = {
        "opened_relative_paths": sorted(audit_by_path),
        "parsed_columns_by_path": {
            path: row["parsed_columns"] for path, row in sorted(audit_by_path.items())
        },
        "consistency_checked_non_numeric_columns_by_path": {
            path: row["consistency_checked_non_numeric_columns"]
            for path, row in sorted(audit_by_path.items())
            if row["consistency_checked_non_numeric_columns"]
        },
        "target_numeric_parse_count": 0,
        "other_station_stage_numeric_parse_count": 0,
        "forbidden_result_file_open_count": 0,
        "selected_row_count_by_path": {
            path: row["row_count"] for path, row in sorted(audit_by_path.items())
        },
        "source_row_count_by_path": {
            path: row["source_row_count"]
            for path, row in sorted(audit_by_path.items())
        },
        "selected_time_axis_sha256_by_path": {
            path: row["time_axis_sha256"] for path, row in sorted(audit_by_path.items())
        },
        "cross_source_time_axis_exact_match": True,
    }
    return IndependentBlindInputs(
        times=aligned_times,
        datong_stage=np.asarray(datong_stage, dtype=np.float32),
        history_missing=history_missing,
        target_missing=np.asarray(target_missing, dtype=np.bool_),
        issue_positions=issue_positions,
        block_ids=block_ids,
        access_audit=access_audit,
        identities=identities,
    )


def _state_for_issue(
    stage: np.ndarray, issue: int, state_rule: Mapping[str, Any]
) -> tuple[str, np.float32, np.float32, np.float32]:
    issue_value = np.float32(stage[issue])
    reference = np.float32(stage[issue - int(state_rule["change_reference_hours_before_issue"])])
    delta = np.subtract(issue_value, reference, dtype=np.float32)
    stage_threshold = np.float32(state_rule["issue_stage_must_be_strictly_above_m"])
    rising = np.float32(state_rule["rising_if_issue_minus_reference_strictly_above_m"])
    falling = np.float32(state_rule["falling_if_issue_minus_reference_strictly_below_m"])
    state = "excluded"
    if np.isfinite(issue_value) and np.isfinite(reference) and issue_value > stage_threshold:
        if delta > rising:
            state = "rising"
        elif delta < falling:
            state = "falling"
    return state, issue_value, reference, delta


def _segment_stage_events(
    times: Sequence[pd.Timestamp], stage: np.ndarray, threshold_value: float
) -> list[dict[str, Any]]:
    threshold = np.float32(threshold_value)
    events: list[dict[str, Any]] = []
    initial_proof = False
    consecutive_low = 0
    active: dict[str, Any] | None = None
    for index, raw_value in enumerate(np.asarray(stage, dtype=np.float32)):
        finite = bool(np.isfinite(raw_value))
        high = bool(finite and raw_value > threshold)
        low = bool(finite and raw_value <= threshold)
        if high:
            consecutive_low = 0
            if active is None:
                active = {
                    "start_index": index,
                    "last_high_index": index,
                    "left_censored": not initial_proof,
                }
            else:
                active["last_high_index"] = index
            continue
        if not low:
            consecutive_low = 0
            continue
        consecutive_low += 1
        if active is not None and consecutive_low == 24:
            events.append(
                {
                    **active,
                    "closure_index": index,
                    "right_censored": False,
                }
            )
            active = None
            initial_proof = True
            consecutive_low = 24
        elif active is None and not initial_proof and consecutive_low == 24:
            initial_proof = True
            consecutive_low = 24
    if active is not None:
        events.append({**active, "closure_index": None, "right_censored": True})
    for event_id, event in enumerate(events, 1):
        event["event_id"] = event_id
        left = bool(event["left_censored"])
        right = bool(event["right_censored"])
        event["event_status"] = (
            "left_and_right_censored" if left and right
            else "left_censored" if left
            else "right_censored" if right
            else "complete"
        )
    return events


def reconstruct_catalogue(
    loaded: IndependentBlindInputs, config: Mapping[str, Any]
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    events = _segment_stage_events(
        loaded.times,
        loaded.datong_stage,
        config["blind_event_catalogue"]["event_threshold_m"],
    )
    event_by_position: dict[int, dict[str, Any]] = {}
    for event in events:
        for position in range(int(event["start_index"]), int(event["last_high_index"]) + 1):
            event_by_position[position] = event
    issue_rows: list[dict[str, Any]] = []
    counts: dict[int, dict[str, int]] = {
        int(event["event_id"]): {"rising": 0, "falling": 0, "excluded": 0}
        for event in events
    }
    for record_index, (issue, block_id) in enumerate(
        zip(loaded.issue_positions.tolist(), loaded.block_ids.tolist())
    ):
        state, issue_value, reference, delta = _state_for_issue(
            loaded.datong_stage, int(issue), config["state_rule"]
        )
        event = event_by_position.get(int(issue))
        if event is not None:
            counts[int(event["event_id"])][state] += 1
        issue_rows.append(
            {
                "record_index": record_index,
                "issue_position": int(issue),
                "issue_time_beijing": loaded.times[int(issue)].isoformat(),
                "block_id": int(block_id),
                "event_id": int(event["event_id"]) if event else -1,
                "in_event": bool(event is not None),
                "event_status": str(event["event_status"]) if event else "none",
                "eligible_paired": False,
                "state": state,
                "issue_stage_m": issue_value,
                "reference_stage_m": reference,
                "delta_m": delta,
                "issue_stage_raw_uint32": int(np.asarray(issue_value).view(np.uint32)),
                "reference_stage_raw_uint32": int(np.asarray(reference).view(np.uint32)),
                "delta_raw_uint32": int(np.asarray(delta).view(np.uint32)),
            }
        )
    catalogue_rows: list[dict[str, Any]] = []
    eligibility: dict[int, bool] = {}
    for event in events:
        event_id = int(event["event_id"])
        event_counts = counts[event_id]
        eligible = bool(
            event["event_status"] == "complete"
            and event_counts["rising"] >= 1
            and event_counts["falling"] >= 1
        )
        eligibility[event_id] = eligible
        closure = event["closure_index"]
        catalogue_rows.append(
            {
                "event_id": event_id,
                "event_status": event["event_status"],
                "observed_start_beijing": loaded.times[int(event["start_index"])].isoformat(),
                "event_end_beijing": loaded.times[int(event["last_high_index"])].isoformat(),
                "closure_proof_end_beijing": (
                    loaded.times[int(closure)].isoformat() if closure is not None else ""
                ),
                "left_censored": bool(event["left_censored"]),
                "right_censored": bool(event["right_censored"]),
                "rising_issue_count": event_counts["rising"],
                "falling_issue_count": event_counts["falling"],
                "excluded_issue_count": event_counts["excluded"],
                "eligible_paired": eligible,
            }
        )
    for row in issue_rows:
        row["eligible_paired"] = bool(eligibility.get(int(row["event_id"]), False))
    catalog = pd.DataFrame(catalogue_rows, columns=CATALOG_COLUMNS)
    issue_map = pd.DataFrame(issue_rows, columns=ISSUE_MAP_COLUMNS)
    paired_count = int(sum(eligibility.values()))
    complete_count = int(sum(row["event_status"] == "complete" for row in catalogue_rows))
    one_sided_complete_count = int(
        sum(
            row["event_status"] == "complete"
            and ((row["rising_issue_count"] > 0) ^ (row["falling_issue_count"] > 0))
            for row in catalogue_rows
        )
    )
    coverage = pd.DataFrame(
        [
            {
                "total_event_count": len(catalogue_rows),
                "left_censored_event_count": int(sum(row["left_censored"] for row in catalogue_rows)),
                "right_censored_event_count": int(sum(row["right_censored"] for row in catalogue_rows)),
                "complete_event_count": complete_count,
                "one_sided_complete_event_count": one_sided_complete_count,
                "paired_event_count": paired_count,
                "minimum_paired_event_count": MINIMUM_PAIRED_EVENT_COUNT,
                "coverage_passed": bool(paired_count >= MINIMUM_PAIRED_EVENT_COUNT),
            }
        ],
        columns=COVERAGE_COLUMNS,
    )
    return catalog, issue_map, coverage


def mismatch(category: str, artifact: str, field: str, detail: str) -> dict[str, str]:
    return {"category": category, "artifact": artifact, "field": field, "detail": detail}


def compare_tables(
    expected: pd.DataFrame,
    observed: pd.DataFrame,
    *,
    key_columns: Sequence[str],
    artifact: str,
    tolerance: float = FLOAT_TOLERANCE,
) -> list[dict[str, str]]:
    differences: list[dict[str, str]] = []
    if tuple(observed.columns) != tuple(expected.columns):
        return [mismatch("columns", artifact, "columns", "column names or order differ")]
    if len(observed) != len(expected):
        return [mismatch("row_count", artifact, "rows", f"{len(observed)} != {len(expected)}")]
    left = expected.sort_values(list(key_columns), kind="mergesort").reset_index(drop=True)
    right = observed.sort_values(list(key_columns), kind="mergesort").reset_index(drop=True)
    for column in left.columns:
        expected_values = left[column]
        observed_values = right[column]
        observed_boolean = observed_values.map(
            lambda value: isinstance(value, (bool, np.bool_))
        ).to_numpy(dtype=np.bool_)
        if column in R2_RAW_UINT32_COLUMNS:
            expected_numeric = pd.to_numeric(
                expected_values, errors="coerce"
            ).to_numpy(dtype=np.float64)
            expected_boolean = expected_values.map(
                lambda value: isinstance(value, (bool, np.bool_))
            ).to_numpy(dtype=np.bool_)
            expected_valid = (
                ~expected_boolean
                & np.isfinite(expected_numeric)
                & (expected_numeric >= 0.0)
                & (expected_numeric <= float(np.iinfo(np.uint32).max))
                & (expected_numeric == np.floor(expected_numeric))
            )
            a = np.zeros(expected_numeric.shape, dtype=np.uint32)
            a[expected_valid] = expected_numeric[expected_valid].astype(np.uint32)
            parsed = pd.to_numeric(observed_values, errors="coerce").to_numpy(
                dtype=np.float64
            )
            valid = (
                ~observed_boolean
                & np.isfinite(parsed)
                & (parsed >= 0.0)
                & (parsed <= float(np.iinfo(np.uint32).max))
                & (parsed == np.floor(parsed))
            )
            b = np.zeros(parsed.shape, dtype=np.uint32)
            b[valid] = parsed[valid].astype(np.uint32)
            equal = expected_valid & valid & (a == b)
        elif pd.api.types.is_numeric_dtype(expected_values.dtype) and not pd.api.types.is_bool_dtype(expected_values.dtype):
            a = expected_values.to_numpy(dtype=np.float64)
            parsed = pd.to_numeric(observed_values, errors="coerce")
            if column in R2_FLOAT32_CSV_COLUMNS:
                if expected_values.dtype != np.dtype(np.float32):
                    raise AuditContractError(
                        f"registered float32 comparison column dtype changed: {column}"
                    )
                b = parsed.to_numpy(dtype=np.float32).astype(np.float64)
            else:
                b = parsed.to_numpy(dtype=np.float64)
            equal = (np.isnan(a) & np.isnan(b)) | (np.isfinite(a) & np.isfinite(b) & (np.abs(a - b) <= tolerance))
            equal &= ~observed_boolean
        else:
            a = expected_values.astype(str).to_numpy()
            b = observed_values.astype(str).to_numpy()
            equal = a == b
        bad = np.flatnonzero(~equal)
        for index in bad[:20]:
            differences.append(
                mismatch("value", artifact, f"{column}[{index}]", "value differs")
            )
    return differences


def compare_json(
    expected: object,
    observed: object,
    *,
    artifact: str,
    field: str = "$",
    tolerance: float = FLOAT_TOLERANCE,
) -> list[dict[str, str]]:
    differences: list[dict[str, str]] = []
    if isinstance(expected, Mapping):
        if not isinstance(observed, Mapping) or set(expected) != set(observed):
            return [mismatch("json_shape", artifact, field, "object keys differ")]
        for key in sorted(expected):
            differences.extend(
                compare_json(expected[key], observed[key], artifact=artifact, field=f"{field}.{key}", tolerance=tolerance)
            )
        return differences
    if isinstance(expected, list):
        if not isinstance(observed, list) or len(expected) != len(observed):
            return [mismatch("json_shape", artifact, field, "list length differs")]
        for index, value in enumerate(expected):
            differences.extend(
                compare_json(value, observed[index], artifact=artifact, field=f"{field}[{index}]", tolerance=tolerance)
            )
        return differences
    if isinstance(expected, (int, float)) and not isinstance(expected, bool):
        if not isinstance(observed, (int, float)) or isinstance(observed, bool) or not np.isfinite(float(observed)) or abs(float(expected) - float(observed)) > tolerance:
            differences.append(mismatch("json_value", artifact, field, "numeric value differs"))
    elif expected != observed:
        differences.append(mismatch("json_value", artifact, field, "value differs"))
    return differences


def _verified_root(
    root: Path, expected_artifacts: set[str]
) -> tuple[dict[str, Any], dict[str, Mapping[str, Any]]]:
    completion = _read_json(root / "completion_manifest.json")
    artifacts = completion.get("artifacts")
    if not isinstance(artifacts, list):
        raise AuditContractError("completion artifact list missing")
    by_path: dict[str, Mapping[str, Any]] = {}
    for entry in artifacts:
        if not isinstance(entry, Mapping) or set(entry) != {"relative_path", "bytes", "sha256"}:
            raise AuditContractError("completion identity schema changed")
        if (
            type(entry["relative_path"]) is not str
            or type(entry["bytes"]) is not int
            or type(entry["sha256"]) is not str
        ):
            raise AuditContractError("completion identity field type changed")
        relative = str(entry["relative_path"])
        if relative in by_path or Path(relative).is_absolute() or ".." in Path(relative).parts:
            raise AuditContractError("completion path unsafe or duplicated")
        by_path[relative] = entry
    if (
        set(by_path) != expected_artifacts
        or type(completion.get("artifact_count")) is not int
        or completion.get("artifact_count") != len(by_path)
    ):
        raise AuditContractError("completion artifact set changed")
    for relative, identity in by_path.items():
        path = (root / relative).resolve()
        try:
            path.relative_to(root.resolve())
        except ValueError as exc:
            raise AuditContractError("completion artifact escapes root") from exc
        if not path.is_file() or path.stat().st_size != identity["bytes"] or _hash_file(path) != identity["sha256"]:
            raise AuditContractError(f"artifact identity changed: {relative}")
    physical = {
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_file() and path.name != "completion_manifest.json"
    }
    if physical != expected_artifacts:
        raise AuditContractError("physical output set differs from completion")
    return completion, by_path


def _compare_blind_input_manifest(
    observed: Mapping[str, Any],
    loaded: IndependentBlindInputs,
    config: Mapping[str, Any],
    project_root: Path,
    *,
    original_authorization_chain: Mapping[str, Any] | None = None,
) -> list[dict[str, str]]:
    differences: list[dict[str, str]] = []
    expected_fields = {
        "schema_version", "experiment_id", "result_label", "preregistration",
        "execution_identity", "blind_input_identities", "access_audit",
        "prediction_package_open_count", "prediction_array_read_count",
        "target_array_read_count", "forecast_error_read_count",
        "formal_result_root_open_count",
    }
    if set(observed) != expected_fields:
        return [
            mismatch(
                "blind_input_manifest", "input_manifest.json", "$",
                "input-manifest fields differ",
            )
        ]
    preregistration = _safe_path(
        project_root, PREREGISTRATION_RELATIVE_PATH, must_exist=True
    )
    expected_preregistration = {
        "relative_path": _relative(preregistration, project_root),
        "bytes": preregistration.stat().st_size,
        "sha256": _hash_file(preregistration),
    }
    authorization_chain = (
        validate_execution_authorization(project_root)
        if original_authorization_chain is None
        else original_authorization_chain
    )
    expected_execution_identity = {
        "blind_catalogue_builder_source": authorization_chain["implementations"][
            "blind_catalogue"
        ],
        "blind_input_reader_source": authorization_chain["implementations"][
            "blind_input_reader"
        ],
        "authorization_id": AUTHORIZATION_ID,
        "execution_authorization": authorization_chain["authorization_identity"],
        "interpreter": authorization_chain["interpreter"],
        "implementations": authorization_chain["implementations"],
        "tests": authorization_chain["tests"],
        "test_evidence": authorization_chain["test_evidence"],
        "static_review": authorization_chain["static_review"],
    }
    for field, expected in (
        ("schema_version", 1),
        ("experiment_id", EXPERIMENT_ID),
        ("result_label", RESULT_LABEL),
        ("preregistration", expected_preregistration),
        ("execution_identity", expected_execution_identity),
        ("blind_input_identities", dict(loaded.identities)),
    ):
        differences.extend(
            compare_json(
                expected,
                observed.get(field),
                artifact="input_manifest.json",
                field=f"$.{field}",
            )
        )
    for field in (
        "prediction_package_open_count", "prediction_array_read_count",
        "target_array_read_count", "forecast_error_read_count",
        "formal_result_root_open_count",
    ):
        value = observed.get(field)
        if type(value) is not int or value != 0:
            differences.append(
                mismatch(
                    "blind_input_manifest", "input_manifest.json", f"$.{field}",
                    "forbidden-access count is not built-in integer zero",
                )
            )
    access = observed.get("access_audit")
    required_access_fields = {
        "opened_relative_paths", "parsed_columns_by_path",
        "consistency_checked_non_numeric_columns_by_path",
        "target_numeric_parse_count", "other_station_stage_numeric_parse_count",
        "forbidden_result_file_open_count", "formal_result_root_open_count",
        "selected_row_count_by_path", "source_row_count_by_path",
        "selected_time_axis_sha256_by_path",
        "cross_source_time_axis_exact_match",
    }
    if not isinstance(access, Mapping) or set(access) != required_access_fields:
        differences.append(
            mismatch(
                "blind_access_audit", "input_manifest.json", "$.access_audit",
                "blind access-audit fields differ",
            )
        )
        return differences
    expected_opened = {
        str(identity["relative_path"]) for identity in loaded.identities.values()
    }
    opened = access.get("opened_relative_paths")
    if (
        not isinstance(opened, list)
        or len(opened) != len(expected_opened)
        or set(map(str, opened)) != expected_opened
    ):
        differences.append(
            mismatch(
                "blind_access_audit", "input_manifest.json",
                "$.access_audit.opened_relative_paths", "opened path set differs",
            )
        )
    for field in (
        "target_numeric_parse_count", "other_station_stage_numeric_parse_count",
        "forbidden_result_file_open_count", "formal_result_root_open_count",
    ):
        value = access.get(field)
        if type(value) is not int or value != 0:
            differences.append(
                mismatch(
                    "blind_access_audit", "input_manifest.json",
                    f"$.access_audit.{field}", "access count is not integer zero",
                )
            )
    for field in (
        "parsed_columns_by_path",
        "consistency_checked_non_numeric_columns_by_path",
        "selected_row_count_by_path", "source_row_count_by_path",
        "selected_time_axis_sha256_by_path",
    ):
        differences.extend(
            compare_json(
                loaded.access_audit[field],
                access.get(field),
                artifact="input_manifest.json",
                field=f"$.access_audit.{field}",
            )
        )
    if access.get("cross_source_time_axis_exact_match") is not True:
        differences.append(
            mismatch(
                "blind_access_audit", "input_manifest.json",
                "$.access_audit.cross_source_time_axis_exact_match",
                "cross-source time-axis identity is not true",
            )
        )
    return differences


def _read_catalogue_csv_preserving_empty_closure(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, keep_default_na=False)


def load_and_compare_blind_outputs(
    config: Mapping[str, Any],
    project_root: Path,
    reconstructed: tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame],
    loaded: IndependentBlindInputs,
    *,
    original_authorization_chain: Mapping[str, Any] | None = None,
) -> tuple[list[dict[str, str]], dict[str, Any]]:
    root = _safe_path(project_root, config["output_roots"]["blind_catalogue"], must_exist=True)
    expected = set(config["output_contract"]["blind_precompletion_artifacts_for_both_coverage_branches"])
    completion, identities = _verified_root(root, expected)
    observed_catalog = _read_catalogue_csv_preserving_empty_closure(
        root / "event_catalog_blind.csv"
    )
    observed_map = pd.read_csv(root / "event_issue_map_blind.csv")
    observed_coverage = pd.read_csv(root / "event_coverage_blind.csv")
    catalog, issue_map, coverage = reconstructed
    differences = []
    differences.extend(compare_tables(catalog, observed_catalog, key_columns=("event_id",), artifact="event_catalog_blind.csv"))
    differences.extend(compare_tables(issue_map, observed_map, key_columns=("record_index",), artifact="event_issue_map_blind.csv"))
    differences.extend(compare_tables(coverage, observed_coverage, key_columns=("minimum_paired_event_count",), artifact="event_coverage_blind.csv"))
    observed_input_manifest = _read_json(root / "input_manifest.json")
    differences.extend(
        _compare_blind_input_manifest(
            observed_input_manifest,
            loaded,
            config,
            project_root,
            original_authorization_chain=original_authorization_chain,
        )
    )
    manifest = _read_json(root / "blind_event_manifest.json")
    decision = _read_json(root / "coverage_decision.json")
    reconstructed_pass = _strict_bool(coverage.iloc[0]["coverage_passed"], "coverage")
    paired_count = int(coverage.iloc[0]["paired_event_count"])
    expected_decision = (
        "ELIGIBLE_FOR_EVENT_SCORING"
        if reconstructed_pass
        else "HOLD_EXPLORATORY_INSUFFICIENT_PAIRED_EVENT_COVERAGE"
    )
    if (
        completion.get("status") != "completed_blind_catalogue"
        or completion.get("decision") != expected_decision
        or completion.get("coverage_passed") is not reconstructed_pass
        or _require_builtin_json_int(
            completion.get("paired_event_count"),
            "blind completion paired-event count",
        ) != paired_count
    ):
        differences.append(
            mismatch(
                "blind_completion", "completion_manifest.json", "coverage",
                "completion identity differs from reconstruction",
            )
        )
    if (
        manifest.get("coverage_passed") is not reconstructed_pass
        or _require_builtin_json_int(
            manifest.get("paired_event_count"), "blind manifest paired-event count"
        ) != paired_count
    ):
        differences.append(mismatch("blind_manifest", "blind_event_manifest.json", "coverage", "coverage differs from reconstruction"))
    if (
        manifest.get("schema_version") != 1
        or manifest.get("experiment_id") != EXPERIMENT_ID
        or manifest.get("result_label") != RESULT_LABEL
        or manifest.get("decision") != expected_decision
        or _require_builtin_json_int(
            manifest.get("minimum_paired_event_count"),
            "blind manifest minimum paired-event count",
        ) != MINIMUM_PAIRED_EVENT_COUNT
    ):
        differences.append(
            mismatch(
                "blind_manifest", "blind_event_manifest.json", "identity",
                "manifest identity differs from reconstruction",
            )
        )
    catalog_artifacts = manifest.get("catalog_artifacts")
    catalog_paths = (
        [str(item.get("relative_path", "")) for item in catalog_artifacts]
        if isinstance(catalog_artifacts, list)
        and all(isinstance(item, Mapping) for item in catalog_artifacts)
        else []
    )
    if catalog_paths != list(BLIND_CATALOG_ARTIFACTS):
        differences.append(
            mismatch(
                "blind_manifest", "blind_event_manifest.json",
                "catalog_artifacts", "catalog artifact order differs",
            )
        )
    elif any(
        set(item) != {"relative_path", "bytes", "sha256"}
        or dict(item) != dict(identities[str(item["relative_path"])])
        for item in catalog_artifacts
    ):
        differences.append(
            mismatch(
                "blind_manifest", "blind_event_manifest.json",
                "catalog_artifacts", "catalog artifact identity differs",
            )
        )
    if (
        decision.get("coverage_passed") is not reconstructed_pass
        or _require_builtin_json_int(
            decision.get("paired_event_count"), "blind decision paired-event count"
        ) != paired_count
    ):
        differences.append(mismatch("coverage_decision", "coverage_decision.json", "coverage", "coverage differs from reconstruction"))
    if (
        set(decision) != BLIND_COVERAGE_DECISION_FIELDS
        or decision.get("schema_version") != 1
        or decision.get("experiment_id") != EXPERIMENT_ID
        or decision.get("result_label") != RESULT_LABEL
        or decision.get("decision") != expected_decision
        or _require_builtin_json_int(
            decision.get("minimum_paired_event_count"),
            "blind decision minimum paired-event count",
        ) != MINIMUM_PAIRED_EVENT_COUNT
        or any(
            _require_builtin_json_int(
                decision.get(field), f"blind access count {field}"
            ) != 0
            for field in (
                "prediction_package_open_count",
                "prediction_array_read_count",
                "target_array_read_count",
                "forecast_error_read_count",
                "formal_result_root_open_count",
            )
        )
    ):
        differences.append(
            mismatch(
                "coverage_decision", "coverage_decision.json", "identity",
                "blind access counters or decision identity differ",
            )
        )
    return differences, {
        "root": root,
        "completion": completion,
        "completion_identity": {
            "relative_path": _relative(root / "completion_manifest.json", project_root),
            "bytes": (root / "completion_manifest.json").stat().st_size,
            "sha256": _hash_file(root / "completion_manifest.json"),
        },
        "manifest_identity": dict(identities["blind_event_manifest.json"]),
        "coverage_passed": reconstructed_pass,
        "paired_event_count": paired_count,
    }


def _scalar(package: Mapping[str, np.ndarray], key: str) -> Any:
    value = np.asarray(package[key])
    if value.shape != ():
        raise AuditContractError(f"package scalar is not scalar: {key}")
    return value.item()


def _task_id(target: str, condition: str, seed: int) -> str:
    return f"tidal_fluvial_hidden_gauge_v1__{target}__{condition}__seed_{seed}"


def _package_relative(target: str, condition: str, seed: int) -> str:
    return f"predictions/{target}__{condition}__seed_{seed}.npz"


def _load_npz(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as source:
        return {name: np.asarray(source[name]) for name in source.files}


def _authenticate_package(
    package: Mapping[str, np.ndarray], target: str, condition: str, seed: int
) -> None:
    if set(package) != PACKAGE_KEYS:
        raise AuditContractError("package key set changed")
    if (
        int(_scalar(package, "schema_version")) != 1
        or str(_scalar(package, "task_id")) != _task_id(target, condition, seed)
        or str(_scalar(package, "target")) != target
        or str(_scalar(package, "condition")) != condition
        or int(_scalar(package, "seed")) != seed
    ):
        raise AuditContractError("package task identity changed")
    prediction = np.asarray(package["predictions_m"])
    target_values = np.asarray(package["targets_m"])
    if prediction.dtype != np.float32 or target_values.dtype != np.float32 or prediction.ndim != 2 or prediction.shape != target_values.shape or prediction.shape[1] != 6 or not np.isfinite(prediction).all() or not np.isfinite(target_values).all():
        raise AuditContractError("package numeric contract changed")
    rows = prediction.shape[0]
    for name in (
        "issue_positions", "issue_times_beijing", "block_ids", "states",
        "issue_stage_m", "reference_stage_m", "delta_m",
        "issue_stage_raw_uint32", "reference_stage_raw_uint32", "delta_raw_uint32",
    ):
        if np.asarray(package[name]).shape != (rows,):
            raise AuditContractError("package audit-array shape changed")
    issue_positions = np.asarray(package["issue_positions"])
    issue_times = np.asarray(package["issue_times_beijing"])
    block_ids = np.asarray(package["block_ids"])
    states = np.asarray(package["states"])
    if (
        issue_positions.dtype != np.int64
        or issue_times.dtype.kind != "U"
        or block_ids.dtype != np.int32
        or states.dtype.kind != "U"
        or len(np.unique(issue_positions)) != rows
        or not set(states.astype(str)).issubset({"rising", "falling"})
    ):
        raise AuditContractError("package audit-array identity changed")
    for value_name, bits_name in (
        ("issue_stage_m", "issue_stage_raw_uint32"),
        ("reference_stage_m", "reference_stage_raw_uint32"),
        ("delta_m", "delta_raw_uint32"),
    ):
        value = np.asarray(package[value_name])
        bits = np.asarray(package[bits_name])
        if value.dtype != np.float32 or bits.dtype != np.uint32 or not np.array_equal(value.view(np.uint32), bits):
            raise AuditContractError("package source bits changed")


def load_prior_packages_after_coverage(
    config: Mapping[str, Any], project_root: Path = PROJECT_ROOT
) -> tuple[list[dict[str, np.ndarray]], dict[str, Any]]:
    verified = {
        name: _verify_identity(project_root, identity)
        for name, identity in config["scoring_input_identities"].items()
    }
    audit_summary_path = _safe_path(
        project_root,
        config["scoring_input_identities"]["prior_direction_audit_summary"]["relative_path"],
        must_exist=True,
    )
    audit_summary = _read_json(audit_summary_path)
    if audit_summary.get("audit_status") != "reproducible" or audit_summary.get("mismatch_count") != 0:
        raise AuditContractError("prior independent audit is not reproducible")
    completion_path = _safe_path(
        project_root,
        config["scoring_input_identities"]["prior_direction_main_completion_manifest"]["relative_path"],
        must_exist=True,
    )
    completion = _read_json(completion_path)
    artifacts = completion.get("artifacts")
    if not isinstance(artifacts, list) or completion.get("prediction_package_count") != EXPECTED_PACKAGE_COUNT:
        raise AuditContractError("prior package completion changed")
    by_path: dict[str, Mapping[str, Any]] = {}
    for identity in artifacts:
        if not isinstance(identity, Mapping) or set(identity) != {"relative_path", "bytes", "sha256"}:
            raise AuditContractError("prior artifact identity schema changed")
        relative = str(identity["relative_path"])
        if relative in by_path:
            raise AuditContractError("prior artifact path duplicated")
        by_path[relative] = identity
    expected = {
        _package_relative(target, condition, seed)
        for target in TARGETS for condition in CONDITIONS for seed in SEEDS
    }
    if {name for name in by_path if name.startswith("predictions/")} != expected:
        raise AuditContractError("prior package path set changed")
    root = completion_path.parent
    packages = []
    identities = []
    common: dict[str, np.ndarray] | None = None
    target_bits: dict[str, np.ndarray] = {}
    for target in TARGETS:
        for condition in CONDITIONS:
            for seed in SEEDS:
                relative = _package_relative(target, condition, seed)
                identity = by_path[relative]
                path = (root / relative).resolve()
                if not path.is_file() or path.stat().st_size != identity["bytes"] or _hash_file(path) != identity["sha256"]:
                    raise AuditContractError(f"prior package identity changed: {relative}")
                package = _load_npz(path)
                _authenticate_package(package, target, condition, seed)
                names = (
                    "issue_positions", "issue_times_beijing", "block_ids", "states",
                    "issue_stage_m", "reference_stage_m", "delta_m",
                    "issue_stage_raw_uint32", "reference_stage_raw_uint32", "delta_raw_uint32",
                )
                if common is None:
                    common = {name: np.asarray(package[name]).copy() for name in names}
                elif any(not np.array_equal(package[name], common[name]) for name in names):
                    raise AuditContractError("common package audit arrays differ")
                bits = np.asarray(package["targets_m"]).view(np.uint32)
                if target in target_bits and not np.array_equal(bits, target_bits[target]):
                    raise AuditContractError("target bits differ within target")
                target_bits.setdefault(target, bits.copy())
                packages.append(package)
                identities.append(dict(identity))
    return packages, {
        "top_level_scoring_input_identities": verified,
        "prior_audit_status": "reproducible",
        "prior_audit_mismatch_count": 0,
        "prediction_package_identities": identities,
    }


def _explicit_median(values: Iterable[float]) -> float:
    array = np.asarray(tuple(values), dtype=np.float64)
    if array.ndim != 1 or array.size == 0 or not np.isfinite(array).all():
        raise AuditContractError("median vector invalid")
    ordered = np.sort(array, kind="stable")
    index = ordered.size // 2
    if ordered.size % 2:
        return float(ordered[index])
    return float(np.add(ordered[index - 1], ordered[index], dtype=np.float64) / np.float64(2.0))


def _exact_issue_integer(
    values: pd.Series, label: str, *, minimum: int, maximum: int
) -> np.ndarray:
    try:
        numeric = pd.to_numeric(values, errors="raise").to_numpy(dtype=np.float64)
    except (TypeError, ValueError) as exc:
        raise AuditContractError(f"reconstructed issue-map {label} is not numeric") from exc
    if (
        not np.isfinite(numeric).all()
        or not np.equal(numeric, np.floor(numeric)).all()
        or (numeric < minimum).any()
        or (numeric > maximum).any()
    ):
        raise AuditContractError(
            f"reconstructed issue-map {label} is not an exact integer"
        )
    return numeric.astype(np.int64)


def _normalise_issue_map_for_scoring(issue_map: pd.DataFrame) -> pd.DataFrame:
    if tuple(issue_map.columns) != ISSUE_MAP_COLUMNS:
        raise AuditContractError("reconstructed issue-map columns changed")
    frame = issue_map.copy()
    frame["record_index"] = _exact_issue_integer(
        frame["record_index"], "record_index", minimum=0,
        maximum=np.iinfo(np.int64).max,
    )
    if not np.array_equal(
        frame["record_index"].to_numpy(), np.arange(len(frame), dtype=np.int64)
    ):
        raise AuditContractError("reconstructed issue-map record index changed")
    frame["issue_position"] = _exact_issue_integer(
        frame["issue_position"], "issue_position", minimum=0,
        maximum=np.iinfo(np.int64).max,
    )
    frame["block_id"] = _exact_issue_integer(
        frame["block_id"], "block_id", minimum=0,
        maximum=np.iinfo(np.int32).max,
    )
    frame["event_id"] = _exact_issue_integer(
        frame["event_id"], "event_id", minimum=-1,
        maximum=np.iinfo(np.int64).max,
    )
    if frame["issue_position"].duplicated().any():
        raise AuditContractError("reconstructed issue positions are duplicated")
    frame["in_event"] = frame["in_event"].map(
        lambda value: _strict_bool(value, "in_event")
    )
    frame["eligible_paired"] = frame["eligible_paired"].map(
        lambda value: _strict_bool(value, "eligible_paired")
    )
    frame["event_status"] = frame["event_status"].astype(str)
    frame["state"] = frame["state"].astype(str)
    outside = frame["event_id"] == -1
    if (
        not np.array_equal(outside.to_numpy(), (~frame["in_event"]).to_numpy())
        or (frame.loc[outside, "event_status"] != "none").any()
        or frame.loc[outside, "eligible_paired"].any()
        or (frame.loc[~outside, "event_id"] <= 0).any()
        or not frame.loc[~outside, "event_status"].isin(
            {
                "complete", "left_censored", "right_censored",
                "left_and_right_censored",
            }
        ).all()
        or (
            frame["eligible_paired"]
            & ((frame["event_status"] != "complete") | ~frame["in_event"])
        ).any()
        or not frame["state"].isin({"rising", "falling", "excluded"}).all()
    ):
        raise AuditContractError("reconstructed issue-map semantics changed")
    for value_name, bits_name in (
        ("issue_stage_m", "issue_stage_raw_uint32"),
        ("reference_stage_m", "reference_stage_raw_uint32"),
        ("delta_m", "delta_raw_uint32"),
    ):
        try:
            values = pd.to_numeric(frame[value_name], errors="raise").to_numpy(
                dtype=np.float32
            )
        except (TypeError, ValueError) as exc:
            raise AuditContractError(
                f"reconstructed issue-map {value_name} is not float32"
            ) from exc
        bits = _exact_issue_integer(
            frame[bits_name], bits_name, minimum=0,
            maximum=np.iinfo(np.uint32).max,
        ).astype(np.uint32)
        if not np.array_equal(values.view(np.uint32), bits):
            raise AuditContractError(
                f"reconstructed issue-map raw bits changed: {value_name}"
            )
        frame[value_name] = values
        frame[bits_name] = bits
    return frame


def _verify_issue_map_package_alignment(
    issue_map: pd.DataFrame, package: Mapping[str, np.ndarray]
) -> None:
    package_rows = issue_map.loc[
        issue_map["state"].isin(["rising", "falling"])
    ].copy()
    exact = {
        "issue_positions": package_rows["issue_position"].to_numpy(dtype=np.int64),
        "issue_times_beijing": package_rows["issue_time_beijing"].astype(str).to_numpy(dtype=np.str_),
        "block_ids": package_rows["block_id"].to_numpy(dtype=np.int32),
        "states": package_rows["state"].astype(str).to_numpy(dtype=np.str_),
        "issue_stage_raw_uint32": package_rows["issue_stage_raw_uint32"].to_numpy(dtype=np.uint32),
        "reference_stage_raw_uint32": package_rows["reference_stage_raw_uint32"].to_numpy(dtype=np.uint32),
        "delta_raw_uint32": package_rows["delta_raw_uint32"].to_numpy(dtype=np.uint32),
    }
    for name, expected in exact.items():
        if not np.array_equal(np.asarray(package[name]), expected):
            raise AuditContractError(
                f"reconstructed issue-map/package alignment differs: {name}"
            )
    for value_name, bits_name in (
        ("issue_stage_m", "issue_stage_raw_uint32"),
        ("reference_stage_m", "reference_stage_raw_uint32"),
        ("delta_m", "delta_raw_uint32"),
    ):
        values = np.asarray(package[value_name])
        if (
            values.dtype != np.float32
            or not np.array_equal(values.view(np.uint32), exact[bits_name])
        ):
            raise AuditContractError(
                f"reconstructed issue-map/package float32 differs: {value_name}"
            )


def independently_score_packages(
    packages: Sequence[Mapping[str, np.ndarray]],
    issue_map: pd.DataFrame,
    config: Mapping[str, Any],
) -> dict[str, Any]:
    package_by_task = {
        (str(_scalar(p, "target")), str(_scalar(p, "condition")), int(_scalar(p, "seed"))): p
        for p in packages
    }
    expected_tasks = {
        (target, condition, seed)
        for target in TARGETS for condition in CONDITIONS for seed in SEEDS
    }
    if set(package_by_task) != expected_tasks or len(packages) != len(expected_tasks):
        raise AuditContractError("package task grid changed")
    normalised_issue_map = _normalise_issue_map_for_scoring(issue_map)
    for package in package_by_task.values():
        _verify_issue_map_package_alignment(normalised_issue_map, package)
    paired = normalised_issue_map.loc[
        normalised_issue_map["eligible_paired"]
        & normalised_issue_map["state"].isin(["rising", "falling"])
    ].copy()
    paired["issue_position"] = paired["issue_position"].astype(np.int64)
    paired["event_id"] = paired["event_id"].astype(np.int64)
    metric_rows = []
    for target in TARGETS:
        for condition in CANDIDATE_CONDITIONS:
            for seed in SEEDS:
                candidate = package_by_task[(target, condition, seed)]
                reference = package_by_task[(target, REFERENCE_CONDITION, seed)]
                for name in (
                    "issue_positions", "issue_times_beijing", "block_ids", "states",
                    "issue_stage_raw_uint32", "reference_stage_raw_uint32",
                    "delta_raw_uint32", "targets_m",
                ):
                    left = np.asarray(candidate[name])
                    right = np.asarray(reference[name])
                    same = np.array_equal(left.view(np.uint32), right.view(np.uint32)) if name == "targets_m" else np.array_equal(left, right)
                    if not same:
                        raise AuditContractError(f"candidate/reference alignment differs: {name}")
                positions = np.asarray(candidate["issue_positions"], dtype=np.int64)
                position_index = {int(value): index for index, value in enumerate(positions)}
                if not set(paired["issue_position"].astype(int)).issubset(position_index):
                    raise AuditContractError("paired issue is absent from package")
                candidate_error = np.abs(np.asarray(candidate["predictions_m"]).astype(np.float64) - np.asarray(candidate["targets_m"]).astype(np.float64))
                reference_error = np.abs(np.asarray(reference["predictions_m"]).astype(np.float64) - np.asarray(reference["targets_m"]).astype(np.float64))
                increment = candidate_error - reference_error
                for event_id in sorted(paired["event_id"].unique().astype(int)):
                    event = paired.loc[paired["event_id"] == event_id]
                    indices = {
                        state: np.asarray(
                            [position_index[int(value)] for value in event.loc[event["state"] == state, "issue_position"]],
                            dtype=np.int64,
                        )
                        for state in ("rising", "falling")
                    }
                    if indices["rising"].size == 0 or indices["falling"].size == 0:
                        raise AuditContractError("paired event lacks a state")
                    for lead_index, lead_hour in enumerate(FORECAST_HOURS):
                        rise = increment[indices["rising"], lead_index]
                        fall = increment[indices["falling"], lead_index]
                        rise_mean = float(np.add.reduce(rise, dtype=np.float64) / rise.size)
                        fall_mean = float(np.add.reduce(fall, dtype=np.float64) / fall.size)
                        metric_rows.append(
                            {
                                "target": target, "condition": condition, "seed": seed,
                                "event_id": event_id, "lead_hour": lead_hour,
                                "rising_issue_count": int(rise.size),
                                "falling_issue_count": int(fall.size),
                                "rising_mean_increment_m": rise_mean,
                                "falling_mean_increment_m": fall_mean,
                                "contrast_m": fall_mean - rise_mean,
                            }
                        )
    metrics = pd.DataFrame(metric_rows, columns=EVENT_SEED_LEAD_COLUMNS).sort_values(
        ["target", "condition", "seed", "event_id", "lead_hour"], kind="stable"
    ).reset_index(drop=True)
    six_rows = []
    for key, frame in metrics.groupby(["target", "condition", "seed", "event_id"], sort=True):
        if tuple(sorted(frame["lead_hour"].astype(int))) != FORECAST_HOURS:
            raise AuditContractError("six-hour grid changed")
        six_rows.append(
            {
                "target": key[0], "condition": key[1], "seed": int(key[2]),
                "event_id": int(key[3]),
                "six_hour_contrast_m": float(np.add.reduce(frame["contrast_m"].to_numpy(np.float64), dtype=np.float64) / 6.0),
            }
        )
    six = pd.DataFrame(six_rows)
    event_rows, seed_rows, lead_rows, loo_rows, influence_rows, comparisons = [], [], [], [], [], []
    for target in TARGETS:
        for condition in CANDIDATE_CONDITIONS:
            subset = six.loc[(six["target"] == target) & (six["condition"] == condition)]
            event_ids = tuple(sorted(subset["event_id"].unique().astype(int)))
            if len(event_ids) < MINIMUM_PAIRED_EVENT_COUNT:
                raise AuditContractError("fewer than ten paired events reached full audit")
            for event_id in event_ids:
                value = _explicit_median(subset.loc[subset["event_id"] == event_id, "six_hour_contrast_m"])
                event_rows.append({"target": target, "condition": condition, "event_id": event_id, "event_contrast_m": value, "positive_event": bool(value > 0.0)})
            full_seed_values = []
            for seed in SEEDS:
                value = _explicit_median(subset.loc[subset["seed"] == seed, "six_hour_contrast_m"])
                full_seed_values.append(value)
                seed_rows.append({"target": target, "condition": condition, "seed": seed, "seed_contrast_m": value, "positive_seed": bool(value > 0.0)})
            for lead_hour in FORECAST_HOURS:
                values = []
                lead_frame = metrics.loc[(metrics["target"] == target) & (metrics["condition"] == condition) & (metrics["lead_hour"] == lead_hour)]
                for seed in SEEDS:
                    values.append(_explicit_median(lead_frame.loc[lead_frame["seed"] == seed, "contrast_m"]))
                value = _explicit_median(values)
                lead_rows.append({"target": target, "condition": condition, "lead_hour": lead_hour, "lead_hour_contrast_m": value, "strictly_positive": bool(value > 0.0)})
            full = _explicit_median(full_seed_values)
            local_loo = []
            for removed in event_ids:
                remaining = tuple(value for value in event_ids if value != removed)
                seed_values = [
                    _explicit_median(subset.loc[(subset["seed"] == seed) & subset["event_id"].isin(remaining), "six_hour_contrast_m"])
                    for seed in SEEDS
                ]
                value = _explicit_median(seed_values)
                sign_flip = bool((full > 0 and value <= 0) or (full < 0 and value >= 0) or (full == 0 and value != 0))
                row = {"target": target, "condition": condition, "removed_event_id": removed, "remaining_event_count": len(remaining), "overall_contrast_m": value, "positive_seed_count": int(sum(item > 0 for item in seed_values)), "sign_flip_from_full": sign_flip, "below_0_01_m": bool(value < 0.01)}
                loo_rows.append(row)
                local_loo.append(row)
            maximum = max(abs(row["overall_contrast_m"] - full) for row in local_loo)
            for row in local_loo:
                change = abs(row["overall_contrast_m"] - full)
                influence_rows.append({"target": target, "condition": condition, "removed_event_id": row["removed_event_id"], "full_overall_contrast_m": full, "leave_one_out_overall_contrast_m": row["overall_contrast_m"], "absolute_change_m": change, "is_maximum_absolute_change": bool(change == maximum), "sign_flip_from_full": row["sign_flip_from_full"], "below_0_01_m": row["below_0_01_m"]})
            positive_seed_count = int(sum(value > 0 for value in full_seed_values))
            target_events = [row for row in event_rows if row["target"] == target and row["condition"] == condition]
            positive_event_count = int(sum(row["positive_event"] for row in target_events))
            fraction = positive_event_count / len(target_events)
            local_leads = [row for row in lead_rows if row["target"] == target and row["condition"] == condition]
            rules = config["descriptive_stability_rules"]
            branches = config["diagnostic_branches"]
            if full < float(rules["minimum_overall_contrast_m"]) or positive_seed_count < int(rules["minimum_positive_seed_count"]):
                branch = branches["effect_or_seed_failure"]
            elif fraction < float(rules["minimum_positive_event_fraction"]) or any(row["overall_contrast_m"] < float(rules["every_leave_one_event_out_contrast_at_least_m"]) or row["positive_seed_count"] < int(rules["every_leave_one_event_out_positive_seed_count_at_least"]) for row in local_loo):
                branch = branches["event_fraction_or_leave_one_out_failure"]
            elif not all(row["lead_hour_contrast_m"] > 0.0 for row in local_leads):
                branch = branches["lead_hour_failure"]
            else:
                branch = branches["all_descriptive_rules_pass"]
            comparisons.append({"target": target, "condition": condition, "paired_event_count": len(event_ids), "overall_contrast_m": full, "positive_seed_count": positive_seed_count, "positive_event_count": positive_event_count, "positive_event_fraction": float(fraction), "minimum_leave_one_out_contrast_m": min(row["overall_contrast_m"] for row in local_loo), "minimum_leave_one_out_positive_seed_count": min(row["positive_seed_count"] for row in local_loo), "all_lead_hours_strictly_positive": bool(all(row["lead_hour_contrast_m"] > 0 for row in local_leads)), "branch": branch})
    return {
        "event_seed_lead_metrics": metrics,
        "event_level_summary": pd.DataFrame(event_rows, columns=EVENT_LEVEL_COLUMNS),
        "seed_level_summary": pd.DataFrame(seed_rows, columns=SEED_LEVEL_COLUMNS),
        "lead_hour_summary": pd.DataFrame(lead_rows, columns=LEAD_LEVEL_COLUMNS),
        "leave_one_event_out": pd.DataFrame(loo_rows, columns=LEAVE_ONE_OUT_COLUMNS),
        "event_influence_summary": pd.DataFrame(influence_rows, columns=EVENT_INFLUENCE_COLUMNS),
        "diagnostic_machine_decision": {"schema_version": 1, "experiment_id": EXPERIMENT_ID, "result_label": RESULT_LABEL, "decision": config["diagnostic_branches"]["overall_required_label"], "prior_machine_decision": config["formal_result_boundary"]["prior_machine_decision"], "formal_decision_unchanged": True, "comparison_count": len(comparisons), "comparisons": comparisons},
    }


def compare_main_diagnostic(
    config: Mapping[str, Any],
    project_root: Path,
    reconstructed: Mapping[str, Any],
    *,
    blind_chain: Mapping[str, Any],
    scoring_identity: Mapping[str, Any],
    paired_event_count: int,
) -> tuple[list[dict[str, str]], dict[str, Any]]:
    root = _safe_path(project_root, config["output_roots"]["main_diagnostic"], must_exist=True)
    expected_names = set(config["output_contract"]["main_diagnostic_precompletion_artifacts_when_coverage_passes"])
    completion, identities = _verified_root(root, expected_names)
    table_contracts = (
        ("event_seed_lead_metrics.csv", "event_seed_lead_metrics", ("target", "condition", "seed", "event_id", "lead_hour")),
        ("event_level_summary.csv", "event_level_summary", ("target", "condition", "event_id")),
        ("seed_level_summary.csv", "seed_level_summary", ("target", "condition", "seed")),
        ("lead_hour_summary.csv", "lead_hour_summary", ("target", "condition", "lead_hour")),
        ("leave_one_event_out.csv", "leave_one_event_out", ("target", "condition", "removed_event_id")),
        ("event_influence_summary.csv", "event_influence_summary", ("target", "condition", "removed_event_id")),
    )
    differences: list[dict[str, str]] = []
    expected_completion_fields = {
        "schema_version", "experiment_id", "result_label", "status",
        "decision", "artifact_count", "artifacts",
    }
    if (
        set(completion) != expected_completion_fields
        or type(completion.get("schema_version")) is not int
        or completion.get("schema_version") != 1
        or completion.get("experiment_id") != EXPERIMENT_ID
        or completion.get("result_label") != RESULT_LABEL
        or completion.get("status") != "completed_exploratory_event_diagnostic"
        or completion.get("decision")
        != config["diagnostic_branches"]["overall_required_label"]
        or type(completion.get("artifact_count")) is not int
        or completion.get("artifact_count") != len(expected_names)
    ):
        differences.append(
            mismatch(
                "main_completion", "completion_manifest.json", "$",
                "main completion status or decision identity differs",
            )
        )
    for filename, key, columns in table_contracts:
        differences.extend(compare_tables(reconstructed[key], pd.read_csv(root / filename), key_columns=columns, artifact=filename))
    differences.extend(compare_json(reconstructed["diagnostic_machine_decision"], _read_json(root / "diagnostic_machine_decision.json"), artifact="diagnostic_machine_decision.json"))
    authorization_chain = validate_execution_authorization(project_root)
    expected_execution_identity = {
        "main_source": authorization_chain["implementations"]["main_diagnostic"],
        "execution_authorization": authorization_chain["authorization_identity"],
        "authorized_chain": authorization_chain,
    }
    preregistration = _safe_path(
        project_root, PREREGISTRATION_RELATIVE_PATH, must_exist=True
    )
    expected_input_manifest = {
        "schema_version": 1,
        "experiment_id": EXPERIMENT_ID,
        "result_label": RESULT_LABEL,
        "preregistration": {
            "relative_path": _relative(preregistration, project_root),
            "bytes": preregistration.stat().st_size,
            "sha256": _hash_file(preregistration),
        },
        "execution_identity": expected_execution_identity,
        "blind_catalogue_completion": blind_chain["completion_identity"],
        "blind_event_manifest": blind_chain["manifest_identity"],
        "paired_event_count": paired_event_count,
        **dict(scoring_identity),
    }
    observed_input_manifest = _read_json(root / "input_manifest.json")
    differences.extend(
        compare_json(
            expected_input_manifest,
            observed_input_manifest,
            artifact="input_manifest.json",
        )
    )
    return differences, {
        "root": root,
        "completion": completion,
        "completion_identity": {
            "relative_path": _relative(root / "completion_manifest.json", project_root),
            "bytes": (root / "completion_manifest.json").stat().st_size,
            "sha256": _hash_file(root / "completion_manifest.json"),
        },
        "input_manifest_identity": dict(identities["input_manifest.json"]),
    }


def choose_coverage_or_full_branch(
    coverage_passed: bool,
    *,
    full_branch: Callable[[], Any],
) -> tuple[str, Any | None]:
    """Guarantee that a coverage failure never invokes result/package access."""
    if not coverage_passed:
        return "coverage_only", None
    return "full", full_branch()


def _write_json_x(path: Path, value: object) -> None:
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n")


def _write_csv_x(path: Path, frame: pd.DataFrame) -> None:
    with path.open("x", encoding="utf-8", newline="") as handle:
        frame.to_csv(handle, index=False, lineterminator="\n")


def _artifact_identities(root: Path) -> list[dict[str, Any]]:
    return [
        {"relative_path": path.relative_to(root).as_posix(), "bytes": path.stat().st_size, "sha256": _hash_file(path)}
        for path in sorted(root.rglob("*"))
        if path.is_file() and path.name != "completion_manifest.json"
    ]


def _assert_audit_paths(output_root: Path, names: Sequence[str]) -> None:
    if len(set(names)) != len(tuple(names)):
        raise AuditContractError("audit artifact names duplicated")
    incomplete = output_root.parent / f"{output_root.name}.incomplete_pid_{os.getpid()}"
    for root in (output_root, incomplete):
        for name in tuple(names) + ("completion_manifest.json",):
            if len(str((root / name).resolve(strict=False))) > MAXIMUM_PATH_CHARACTERS:
                raise AuditContractError("audit output path exceeds 240 characters")
    if output_root.exists():
        raise FileExistsError(f"audit output already exists: {output_root}")
    if incomplete.exists():
        raise FileExistsError(f"audit incomplete output already exists: {incomplete}")


def publish_independent_audit(
    output_root: Path,
    artifacts: Mapping[str, pd.DataFrame | Mapping[str, Any]],
    *,
    coverage_passed: bool,
    mismatch_count: int,
    result_label: str = RESULT_LABEL,
    retry_id: str | None = None,
) -> Path:
    names = FULL_AUDIT_ARTIFACTS if coverage_passed else COVERAGE_AUDIT_ARTIFACTS
    if set(artifacts) != set(names):
        raise AuditContractError("audit artifact mapping is not the registered exact set")
    final = Path(output_root).resolve(strict=False)
    _assert_audit_paths(final, names)
    final.parent.mkdir(parents=True, exist_ok=True)
    incomplete = final.parent / f"{final.name}.incomplete_pid_{os.getpid()}"
    incomplete.mkdir(exist_ok=False)
    for name in names:
        value = artifacts[name]
        if name.endswith(".csv"):
            if not isinstance(value, pd.DataFrame):
                raise AuditContractError(f"audit CSV payload changed: {name}")
            _write_csv_x(incomplete / name, value)
        else:
            if not isinstance(value, Mapping):
                raise AuditContractError(f"audit JSON payload changed: {name}")
            _write_json_x(incomplete / name, dict(value))
    actual = {path.relative_to(incomplete).as_posix() for path in incomplete.rglob("*") if path.is_file()}
    if actual != set(names):
        raise AuditContractError("audit precompletion file set changed")
    rows = _artifact_identities(incomplete)
    completion = {
        "schema_version": 1,
        "experiment_id": EXPERIMENT_ID,
        "result_label": result_label,
        "status": (
            "completed_independent_coverage_audit_retry"
            if retry_id is not None
            else "completed_independent_audit"
        ),
        "audit_status": "reproducible" if mismatch_count == 0 else "not_reproducible",
        "coverage_passed": coverage_passed,
        "mismatch_count": mismatch_count,
        "artifact_count": len(rows),
        "artifacts": rows,
    }
    if retry_id is not None:
        completion["retry_id"] = retry_id
    _write_json_x(incomplete / "completion_manifest.json", completion)
    if final.exists():
        raise FileExistsError("audit final output appeared before rename")
    incomplete.rename(final)
    return final


def _observed_authorized_identity(
    project_root: Path, relative_path: str
) -> dict[str, Any]:
    path = _safe_path(project_root, relative_path, must_exist=True)
    return {
        "relative_path": _relative(path, project_root),
        "bytes": path.stat().st_size,
        "sha256": _hash_file(path),
    }


def _observed_interpreter_identity() -> dict[str, Any]:
    executable = Path(sys.executable).resolve(strict=True)
    return {
        "path": str(executable),
        "bytes": executable.stat().st_size,
        "sha256": _hash_file(executable),
        "version": sys.version,
    }


def _validate_authorized_identity_group(
    project_root: Path,
    payload: object,
    expected_paths: Mapping[str, str],
    label: str,
) -> dict[str, dict[str, Any]]:
    if not isinstance(payload, Mapping) or set(payload) != set(expected_paths):
        raise AuditContractError(
            f"execution authorization {label} role set changed"
        )
    observed: dict[str, dict[str, Any]] = {}
    for role, relative_path in expected_paths.items():
        identity = payload[role]
        if not isinstance(identity, Mapping) or set(identity) != {
            "relative_path", "bytes", "sha256"
        }:
            raise AuditContractError(
                f"execution authorization {label} identity schema changed: {role}"
            )
        current = _observed_authorized_identity(project_root, relative_path)
        if (
            type(identity["relative_path"]) is not str
            or type(identity["bytes"]) is not int
            or type(identity["sha256"]) is not str
            or dict(identity) != current
        ):
            raise AuditContractError(
                f"execution authorization {label} identity changed: {role}"
            )
        observed[role] = current
    return observed


def validate_execution_authorization(project_root: Path = PROJECT_ROOT) -> dict[str, Any]:
    authorization = _safe_path(
        project_root, AUTHORIZATION_RELATIVE_PATH, must_exist=True
    )
    payload = _read_json(authorization)
    required_top = {
        "schema_version", "authorization_id", "experiment_id", "authorized",
        "scope", "preregistration", "interpreter", "implementations", "tests",
        "test_evidence", "static_review",
    }
    if set(payload) != required_top:
        raise AuditContractError("execution authorization top-level schema changed")
    if (
        type(payload.get("schema_version")) is not int
        or payload.get("schema_version") != 1
        or payload.get("authorization_id") != AUTHORIZATION_ID
        or payload.get("experiment_id") != EXPERIMENT_ID
        or payload.get("authorized") is not True
    ):
        raise AuditContractError("execution authorization identity changed")
    scope = payload.get("scope")
    if not isinstance(scope, Mapping) or set(scope) != set(AUTHORIZED_SCOPE):
        raise AuditContractError("execution authorization scope fields changed")
    for key, expected in AUTHORIZED_SCOPE.items():
        if type(scope[key]) is not type(expected) or scope[key] != expected:
            raise AuditContractError(
                f"execution authorization scope changed: {key}"
            )
    expected_preregistration = {
        "relative_path": PREREGISTRATION_RELATIVE_PATH.as_posix(),
        "bytes": PREREGISTRATION_BYTES,
        "sha256": PREREGISTRATION_SHA256,
    }
    preregistration = payload.get("preregistration")
    if (
        not isinstance(preregistration, Mapping)
        or set(preregistration) != {"relative_path", "bytes", "sha256"}
        or type(preregistration["relative_path"]) is not str
        or type(preregistration["bytes"]) is not int
        or type(preregistration["sha256"]) is not str
        or dict(preregistration) != expected_preregistration
    ):
        raise AuditContractError(
            "execution authorization preregistration identity changed"
        )
    interpreter = payload.get("interpreter")
    if (
        not isinstance(interpreter, Mapping)
        or set(interpreter) != {"path", "bytes", "sha256", "version"}
        or type(interpreter["path"]) is not str
        or type(interpreter["bytes"]) is not int
        or type(interpreter["sha256"]) is not str
        or type(interpreter["version"]) is not str
        or dict(interpreter) != _observed_interpreter_identity()
    ):
        raise AuditContractError(
            "execution authorization interpreter identity changed"
        )
    observed_implementations = _validate_authorized_identity_group(
        project_root, payload.get("implementations"),
        AUTHORIZED_IMPLEMENTATION_PATHS, "implementation",
    )
    observed_tests = _validate_authorized_identity_group(
        project_root, payload.get("tests"), AUTHORIZED_TEST_PATHS, "test",
    )
    evidence = payload.get("test_evidence")
    if not isinstance(evidence, Mapping) or set(evidence) != {
        "command", "test_paths", "passed", "failed", "exit_code",
        "synthetic_only",
    }:
        raise AuditContractError(
            "execution authorization test-evidence schema changed"
        )
    expected_test_paths = list(AUTHORIZED_TEST_PATHS.values())
    expected_command = [
        _observed_interpreter_identity()["path"], "-m", "pytest", "-q",
        *expected_test_paths,
    ]
    if (
        evidence.get("command") != expected_command
        or evidence.get("test_paths") != expected_test_paths
        or type(evidence.get("passed")) is not int
        or evidence["passed"] <= 0
        or type(evidence.get("failed")) is not int
        or evidence["failed"] != 0
        or type(evidence.get("exit_code")) is not int
        or evidence["exit_code"] != 0
        or type(evidence.get("synthetic_only")) is not bool
        or evidence.get("synthetic_only") is not True
    ):
        raise AuditContractError("execution authorization test evidence changed")
    review = payload.get("static_review")
    if (
        not isinstance(review, Mapping)
        or set(review) != {"p0", "p1"}
        or type(review.get("p0")) is not int
        or type(review.get("p1")) is not int
        or review.get("p0") != 0
        or review.get("p1") != 0
    ):
        raise AuditContractError(
            "execution authorization static review is not clean"
        )
    return {
        "authorization_id": AUTHORIZATION_ID,
        "authorization_identity": _observed_authorized_identity(
            project_root, AUTHORIZATION_RELATIVE_PATH.as_posix()
        ),
        "interpreter": _observed_interpreter_identity(),
        "implementations": observed_implementations,
        "tests": observed_tests,
        "test_evidence": dict(evidence),
        "static_review": dict(review),
    }


def _exact_file_identity(value: object, label: str) -> dict[str, Any]:
    if not isinstance(value, Mapping) or set(value) != {
        "relative_path", "bytes", "sha256"
    }:
        raise AuditContractError(f"{label} file-identity schema changed")
    if (
        type(value["relative_path"]) is not str
        or type(value["bytes"]) is not int
        or type(value["sha256"]) is not str
        or value["bytes"] < 0
        or len(value["sha256"]) != 64
    ):
        raise AuditContractError(f"{label} file-identity field changed")
    return dict(value)


def _verify_bound_file_identity(
    project_root: Path, value: object, label: str
) -> dict[str, Any]:
    expected = _exact_file_identity(value, label)
    observed = _observed_authorized_identity(
        project_root, str(expected["relative_path"])
    )
    if observed != expected:
        raise AuditContractError(f"{label} bound file identity changed")
    return observed


def validate_frozen_r2_contract(config: Mapping[str, Any]) -> None:
    required_top = {
        "schema_version", "preregistration_id", "experiment_id", "retry_id",
        "created_date", "status", "result_label", "purpose", "scope_boundary",
        "bound_parent_contracts", "bound_blind_catalogue_outputs",
        "bound_failed_audit_outputs", "failed_run_source_and_test_identities",
        "frozen_false_positive_evidence", "frozen_comparison_repair",
        "repair_implementation_boundary", "execution_scope",
        "coverage_only_precondition", "output_contract", "success_criteria",
        "stop_conditions",
    }
    if set(config) != required_top:
        raise AuditContractError("R2 preregistration top-level schema changed")
    if (
        type(config.get("schema_version")) is not int
        or config.get("schema_version") != 1
        or config.get("preregistration_id") != R2_PREREGISTRATION_ID
        or config.get("experiment_id") != EXPERIMENT_ID
        or config.get("retry_id") != R2_RETRY_ID
        or config.get("status") != "frozen"
        or config.get("result_label") != R2_RESULT_LABEL
    ):
        raise AuditContractError("R2 preregistration identity changed")
    scope = config.get("scope_boundary")
    if not isinstance(scope, Mapping) or (
        scope.get("only_changed_factor")
        != "independent_audit_float32_csv_comparison_semantics"
        or any(
            scope.get(key) is not False
            for key in (
                "scientific_reanalysis_allowed", "event_algorithm_change_allowed",
                "event_catalogue_change_allowed", "blind_catalogue_rebuild_allowed",
                "main_diagnostic_run_allowed", "prediction_package_access_allowed",
                "prediction_array_access_allowed", "target_array_access_allowed",
                "forecast_error_access_allowed", "formal_result_change_allowed",
            )
        )
    ):
        raise AuditContractError("R2 scope boundary changed")
    execution_scope = config.get("execution_scope")
    if not isinstance(execution_scope, Mapping) or set(execution_scope) != set(
        R2_AUTHORIZED_SCOPE
    ):
        raise AuditContractError("R2 execution-scope fields changed")
    for key, expected in R2_AUTHORIZED_SCOPE.items():
        if (
            type(execution_scope[key]) is not type(expected)
            or execution_scope[key] != expected
        ):
            raise AuditContractError(f"R2 execution scope changed: {key}")
    repair = config.get("frozen_comparison_repair")
    if not isinstance(repair, Mapping) or (
        repair.get("affected_expected_dtype") != "numpy.float32"
        or repair.get("affected_columns")
        != ["issue_stage_m", "reference_stage_m", "delta_m"]
        or repair.get("observed_conversion_before_comparison")
        != ["pandas.to_numeric_errors_coerce", "numpy.float32", "numpy.float64"]
        or repair.get("expected_conversion_before_comparison")
        != ["numpy.float32", "numpy.float64"]
        or repair.get("comparison_absolute_tolerance_after_float32_restoration")
        != FLOAT_TOLERANCE
        or repair.get("raw_uint32_columns")
        != [
            "issue_stage_raw_uint32", "reference_stage_raw_uint32",
            "delta_raw_uint32",
        ]
        or repair.get("raw_uint32_comparison") != "exact_zero_tolerance"
        or repair.get("derived_float64_absolute_tolerance") != FLOAT_TOLERANCE
        or repair.get("global_float64_tolerance_change_allowed") is not False
        or repair.get("blind_csv_writer_change_allowed") is not False
        or repair.get("event_reconstruction_change_allowed") is not False
    ):
        raise AuditContractError("R2 comparison repair changed")
    boundary = config.get("repair_implementation_boundary")
    expected_allowed_files = [
        SOURCE_RELATIVE_PATH.as_posix(),
        R2_AUTHORIZED_TEST_PATHS["independent_audit"],
    ]
    if not isinstance(boundary, Mapping) or (
        boundary.get("allowed_repair_files") != expected_allowed_files
        or boundary.get("all_other_existing_file_changes_allowed") is not False
        or boundary.get("new_retry_execution_authorization_required") is not True
    ):
        raise AuditContractError("R2 implementation boundary changed")
    precondition = config.get("coverage_only_precondition")
    if not isinstance(precondition, Mapping) or (
        precondition.get("coverage_passed_must_be") is not False
        or type(precondition.get("paired_event_count_must_equal")) is not int
        or precondition.get("paired_event_count_must_equal") != 1
        or type(precondition.get("minimum_paired_event_count_must_equal")) is not int
        or precondition.get("minimum_paired_event_count_must_equal")
        != MINIMUM_PAIRED_EVENT_COUNT
        or precondition.get("coverage_decision_must_equal")
        != "HOLD_EXPLORATORY_INSUFFICIENT_PAIRED_EVENT_COVERAGE"
        or precondition.get("on_any_difference")
        != "stop_before_prediction_target_error_or_output_access"
    ):
        raise AuditContractError("R2 coverage-only precondition changed")
    output = config.get("output_contract")
    if not isinstance(output, Mapping) or (
        output.get("old_failed_output_root")
        != "results/analysis/datong_stage_event_stability_2024_2025_v1_independent_audit"
        or output.get("retry_output_root")
        != "results/analysis/datong_stage_event_stability_2024_2025_v1_independent_audit_r2"
        or output.get("retry_precompletion_artifact_count") != 7
        or output.get("retry_precompletion_artifacts")
        != list(COVERAGE_AUDIT_ARTIFACTS)
        or output.get("completion_manifest") != "completion_manifest.json"
        or output.get("completion_manifest_written_last") is not True
        or output.get("exclusive_creation") is not True
        or output.get("overwrite_allowed") is not False
        or output.get("atomic_final_rename") is not True
        or output.get("temporary_root_same_parent_as_final_root") is not True
        or output.get("all_final_and_temporary_paths_checked_before_first_write")
        is not True
        or output.get("maximum_absolute_path_characters")
        != MAXIMUM_PATH_CHARACTERS
    ):
        raise AuditContractError("R2 output contract changed")


def load_frozen_r2_preregistration(
    path: Path = PROJECT_ROOT / R2_PREREGISTRATION_RELATIVE_PATH,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    resolved = _safe_path(project_root, path, must_exist=True)
    if _relative(resolved, project_root) != R2_PREREGISTRATION_RELATIVE_PATH.as_posix():
        raise AuditContractError("R2 preregistration path changed")
    if resolved.stat().st_size != R2_PREREGISTRATION_BYTES:
        raise AuditContractError("R2 preregistration byte count changed")
    if _hash_file(resolved) != R2_PREREGISTRATION_SHA256:
        raise AuditContractError("R2 preregistration SHA-256 changed")
    payload = _read_json(resolved)
    validate_frozen_r2_contract(payload)
    return payload


def _same_json_value(observed: object, expected: object) -> bool:
    return _json_text(observed) == _json_text(expected)


def validate_r2_execution_authorization(
    project_root: Path, retry: Mapping[str, Any]
) -> dict[str, Any]:
    authorization = _safe_path(
        project_root, R2_AUTHORIZATION_RELATIVE_PATH, must_exist=True
    )
    payload = _read_json(authorization)
    required_top = {
        "schema_version", "authorization_id", "experiment_id", "retry_id",
        "authorized", "scope", "retry_preregistration",
        "original_event_preregistration", "original_execution_authorization",
        "bound_blind_catalogue_outputs", "bound_failed_audit_outputs",
        "failed_run_source_and_test_identities", "interpreter",
        "implementations", "tests", "test_evidence", "static_review",
    }
    if set(payload) != required_top:
        raise AuditContractError("R2 execution authorization top-level schema changed")
    if (
        type(payload.get("schema_version")) is not int
        or payload.get("schema_version") != 1
        or payload.get("authorization_id") != R2_AUTHORIZATION_ID
        or payload.get("experiment_id") != EXPERIMENT_ID
        or payload.get("retry_id") != R2_RETRY_ID
        or payload.get("authorized") is not True
    ):
        raise AuditContractError("R2 execution authorization identity changed")
    scope = payload.get("scope")
    if not isinstance(scope, Mapping) or set(scope) != set(R2_AUTHORIZED_SCOPE):
        raise AuditContractError("R2 execution authorization scope fields changed")
    for key, expected in R2_AUTHORIZED_SCOPE.items():
        if type(scope[key]) is not type(expected) or scope[key] != expected:
            raise AuditContractError(f"R2 execution authorization scope changed: {key}")
    expected_retry_identity = {
        "relative_path": R2_PREREGISTRATION_RELATIVE_PATH.as_posix(),
        "bytes": R2_PREREGISTRATION_BYTES,
        "sha256": R2_PREREGISTRATION_SHA256,
    }
    bound_parent = retry["bound_parent_contracts"]
    exact_sections = (
        ("retry_preregistration", expected_retry_identity),
        ("original_event_preregistration", bound_parent["original_event_preregistration"]),
        ("original_execution_authorization", bound_parent["original_execution_authorization"]),
        ("bound_blind_catalogue_outputs", retry["bound_blind_catalogue_outputs"]),
        ("bound_failed_audit_outputs", retry["bound_failed_audit_outputs"]),
        (
            "failed_run_source_and_test_identities",
            retry["failed_run_source_and_test_identities"],
        ),
    )
    for field, expected in exact_sections:
        if not _same_json_value(payload.get(field), expected):
            raise AuditContractError(f"R2 execution authorization binding changed: {field}")
    _verify_bound_file_identity(project_root, payload["retry_preregistration"], "R2 preregistration")
    _verify_bound_file_identity(project_root, payload["original_event_preregistration"], "original event preregistration")
    _verify_bound_file_identity(project_root, payload["original_execution_authorization"], "original execution authorization")
    for field in ("completion_manifest", "blind_event_manifest", "coverage_decision"):
        _verify_bound_file_identity(
            project_root,
            payload["bound_blind_catalogue_outputs"][field],
            f"bound blind catalogue {field}",
        )
    for field in ("completion_manifest", "independent_audit_summary", "mismatches"):
        _verify_bound_file_identity(
            project_root,
            payload["bound_failed_audit_outputs"][field],
            f"bound failed audit {field}",
        )
    interpreter = payload.get("interpreter")
    if (
        not isinstance(interpreter, Mapping)
        or set(interpreter) != {"path", "bytes", "sha256", "version"}
        or type(interpreter["path"]) is not str
        or type(interpreter["bytes"]) is not int
        or type(interpreter["sha256"]) is not str
        or type(interpreter["version"]) is not str
        or dict(interpreter) != _observed_interpreter_identity()
    ):
        raise AuditContractError("R2 execution authorization interpreter changed")
    implementations = _validate_authorized_identity_group(
        project_root,
        payload.get("implementations"),
        R2_AUTHORIZED_IMPLEMENTATION_PATHS,
        "R2 implementation",
    )
    tests = _validate_authorized_identity_group(
        project_root,
        payload.get("tests"),
        R2_AUTHORIZED_TEST_PATHS,
        "R2 test",
    )
    evidence = payload.get("test_evidence")
    expected_paths = list(R2_AUTHORIZED_TEST_PATHS.values())
    expected_command = [
        _observed_interpreter_identity()["path"], "-m", "pytest", "-q",
        *expected_paths,
    ]
    if not isinstance(evidence, Mapping) or set(evidence) != {
        "command", "test_paths", "passed", "failed", "exit_code", "synthetic_only"
    } or (
        evidence.get("command") != expected_command
        or evidence.get("test_paths") != expected_paths
        or type(evidence.get("passed")) is not int
        or evidence["passed"] <= 0
        or type(evidence.get("failed")) is not int
        or evidence["failed"] != 0
        or type(evidence.get("exit_code")) is not int
        or evidence["exit_code"] != 0
        or type(evidence.get("synthetic_only")) is not bool
        or evidence["synthetic_only"] is not True
    ):
        raise AuditContractError("R2 execution authorization test evidence changed")
    review = payload.get("static_review")
    if (
        not isinstance(review, Mapping)
        or set(review) != {"p0", "p1"}
        or type(review.get("p0")) is not int
        or type(review.get("p1")) is not int
        or review.get("p0") != 0
        or review.get("p1") != 0
    ):
        raise AuditContractError("R2 execution authorization static review is not clean")
    return {
        "authorization_id": R2_AUTHORIZATION_ID,
        "authorization_identity": _observed_authorized_identity(
            project_root, R2_AUTHORIZATION_RELATIVE_PATH.as_posix()
        ),
        "interpreter": dict(interpreter),
        "implementations": implementations,
        "tests": tests,
        "test_evidence": dict(evidence),
        "static_review": dict(review),
    }


def load_bound_original_authorization_history(
    project_root: Path, retry: Mapping[str, Any]
) -> dict[str, Any]:
    identity = retry["bound_parent_contracts"]["original_execution_authorization"]
    observed_identity = _verify_bound_file_identity(
        project_root, identity, "original execution authorization"
    )
    payload = _read_json(
        _safe_path(project_root, identity["relative_path"], must_exist=True)
    )
    required_top = {
        "schema_version", "authorization_id", "experiment_id", "authorized",
        "scope", "preregistration", "interpreter", "implementations", "tests",
        "test_evidence", "static_review",
    }
    if set(payload) != required_top or (
        type(payload.get("schema_version")) is not int
        or payload.get("schema_version") != 1
        or payload.get("authorization_id") != AUTHORIZATION_ID
        or payload.get("experiment_id") != EXPERIMENT_ID
        or payload.get("authorized") is not True
    ):
        raise AuditContractError("bound original authorization schema changed")
    scope = payload.get("scope")
    if not isinstance(scope, Mapping) or set(scope) != set(AUTHORIZED_SCOPE):
        raise AuditContractError("bound original authorization scope changed")
    for key, expected in AUTHORIZED_SCOPE.items():
        if type(scope[key]) is not type(expected) or scope[key] != expected:
            raise AuditContractError("bound original authorization scope changed")
    expected_parent = retry["bound_parent_contracts"]["original_event_preregistration"]
    if not _same_json_value(payload.get("preregistration"), expected_parent):
        raise AuditContractError("bound original preregistration identity changed")
    implementations = payload.get("implementations")
    tests = payload.get("tests")
    if (
        not isinstance(implementations, Mapping)
        or set(implementations) != set(AUTHORIZED_IMPLEMENTATION_PATHS)
        or not isinstance(tests, Mapping)
        or set(tests) != set(AUTHORIZED_TEST_PATHS)
    ):
        raise AuditContractError("bound original source/test role set changed")
    for role, path in AUTHORIZED_IMPLEMENTATION_PATHS.items():
        value = _exact_file_identity(implementations[role], f"historical implementation {role}")
        if value["relative_path"] != path:
            raise AuditContractError("historical implementation path changed")
    for role, path in AUTHORIZED_TEST_PATHS.items():
        value = _exact_file_identity(tests[role], f"historical test {role}")
        if value["relative_path"] != path:
            raise AuditContractError("historical test path changed")
    failed = retry["failed_run_source_and_test_identities"]
    if (
        not _same_json_value(implementations["independent_audit"], failed["independent_audit_source"])
        or not _same_json_value(tests["independent_audit"], failed["independent_audit_test"])
    ):
        raise AuditContractError("failed audit source/test history changed")
    interpreter = payload.get("interpreter")
    if not isinstance(interpreter, Mapping) or set(interpreter) != {
        "path", "bytes", "sha256", "version"
    }:
        raise AuditContractError("historical interpreter schema changed")
    evidence = payload.get("test_evidence")
    expected_paths = list(AUTHORIZED_TEST_PATHS.values())
    expected_command = [str(interpreter["path"]), "-m", "pytest", "-q", *expected_paths]
    if not isinstance(evidence, Mapping) or set(evidence) != {
        "command", "test_paths", "passed", "failed", "exit_code", "synthetic_only"
    } or (
        evidence.get("command") != expected_command
        or evidence.get("test_paths") != expected_paths
        or type(evidence.get("passed")) is not int
        or evidence["passed"] <= 0
        or type(evidence.get("failed")) is not int
        or evidence["failed"] != 0
        or type(evidence.get("exit_code")) is not int
        or evidence["exit_code"] != 0
        or evidence.get("synthetic_only") is not True
    ):
        raise AuditContractError("historical test evidence changed")
    review = payload.get("static_review")
    if (
        not isinstance(review, Mapping)
        or set(review) != {"p0", "p1"}
        or type(review.get("p0")) is not int
        or type(review.get("p1")) is not int
        or review.get("p0") != 0
        or review.get("p1") != 0
    ):
        raise AuditContractError("historical static review changed")
    return {
        "authorization_id": AUTHORIZATION_ID,
        "authorization_identity": observed_identity,
        "interpreter": dict(interpreter),
        "implementations": {key: dict(value) for key, value in implementations.items()},
        "tests": {key: dict(value) for key, value in tests.items()},
        "test_evidence": dict(evidence),
        "static_review": dict(review),
    }


def assert_r2_coverage_only_precondition(
    *,
    coverage_passed: object,
    paired_event_count: object,
    minimum_paired_event_count: object,
    decision: object,
    retry: Mapping[str, Any],
) -> None:
    contract = retry["coverage_only_precondition"]
    if (
        type(coverage_passed) is not bool
        or coverage_passed is not contract["coverage_passed_must_be"]
        or type(paired_event_count) is not int
        or paired_event_count != contract["paired_event_count_must_equal"]
        or type(minimum_paired_event_count) is not int
        or minimum_paired_event_count
        != contract["minimum_paired_event_count_must_equal"]
        or type(decision) is not str
        or decision != contract["coverage_decision_must_equal"]
    ):
        raise AuditContractError(
            "R2 coverage-only precondition changed; stopped before forbidden access"
        )


def verify_r2_bound_blind_precondition(
    project_root: Path, retry: Mapping[str, Any]
) -> dict[str, Any]:
    bound = retry["bound_blind_catalogue_outputs"]
    identities = {
        field: _verify_bound_file_identity(
            project_root, bound[field], f"R2 blind catalogue {field}"
        )
        for field in ("completion_manifest", "blind_event_manifest", "coverage_decision")
    }
    decision = _read_json(
        _safe_path(project_root, bound["coverage_decision"]["relative_path"], must_exist=True)
    )
    assert_r2_coverage_only_precondition(
        coverage_passed=decision.get("coverage_passed"),
        paired_event_count=decision.get("paired_event_count"),
        minimum_paired_event_count=decision.get("minimum_paired_event_count"),
        decision=decision.get("decision"),
        retry=retry,
    )
    for field in (
        "prediction_package_open_count", "prediction_array_read_count",
        "target_array_read_count", "forecast_error_read_count",
        "formal_result_root_open_count",
    ):
        if type(decision.get(field)) is not int or decision[field] != 0:
            raise AuditContractError("R2 bound blind decision has forbidden access")
    return {"identities": identities, "decision": decision}


def verify_r2_old_failed_audit_root(
    project_root: Path, retry: Mapping[str, Any]
) -> dict[str, Any]:
    output = retry["output_contract"]
    old_root = _safe_path(project_root, output["old_failed_output_root"], must_exist=True)
    new_root = _safe_path(project_root, output["retry_output_root"], must_exist=False)
    if old_root == new_root:
        raise AuditContractError("R2 output root aliases the old failed audit root")
    completion, artifacts = _verified_root(old_root, set(COVERAGE_AUDIT_ARTIFACTS))
    bound = retry["bound_failed_audit_outputs"]
    identities = {
        field: _verify_bound_file_identity(
            project_root, bound[field], f"R2 failed audit {field}"
        )
        for field in ("completion_manifest", "independent_audit_summary", "mismatches")
    }
    summary = _read_json(
        _safe_path(
            project_root, bound["independent_audit_summary"]["relative_path"],
            must_exist=True,
        )
    )
    if (
        completion.get("status") != "completed_independent_audit"
        or completion.get("audit_status") != bound["recorded_audit_status"]
        or type(completion.get("mismatch_count")) is not int
        or completion.get("mismatch_count") != bound["recorded_mismatch_count"]
        or completion.get("coverage_passed") is not bound["recorded_coverage_passed"]
        or summary.get("audit_status") != bound["recorded_audit_status"]
        or type(summary.get("mismatch_count")) is not int
        or summary.get("mismatch_count") != bound["recorded_mismatch_count"]
        or summary.get("coverage_passed") is not bound["recorded_coverage_passed"]
        or type(summary.get("paired_event_count")) is not int
        or summary.get("paired_event_count") != bound["recorded_paired_event_count"]
        or type(summary.get("prediction_package_read_count")) is not int
        or summary.get("prediction_package_read_count")
        != bound["prediction_package_read_count"]
    ):
        raise AuditContractError("old failed audit recorded state changed")
    evidence = retry["frozen_false_positive_evidence"]
    blind_map = _verify_bound_file_identity(
        project_root, evidence["blind_event_issue_map"], "R2 blind issue map"
    )
    failed_map = _verify_bound_file_identity(
        project_root,
        evidence["failed_audit_reconstructed_event_issue_map"],
        "R2 failed audit issue map",
    )
    if (
        evidence.get("issue_map_files_are_byte_identical") is not True
        or blind_map["bytes"] != failed_map["bytes"]
        or blind_map["sha256"] != failed_map["sha256"]
        or artifacts["reconstructed_event_issue_map.csv"]["bytes"]
        != failed_map["bytes"]
        or artifacts["reconstructed_event_issue_map.csv"]["sha256"]
        != failed_map["sha256"]
    ):
        raise AuditContractError("frozen false-positive issue-map identity changed")
    return {
        "root": old_root,
        "completion": completion,
        "completion_identity": identities["completion_manifest"],
        "summary_identity": identities["independent_audit_summary"],
        "mismatches_identity": identities["mismatches"],
        "artifact_identities": {key: dict(value) for key, value in artifacts.items()},
    }


def capture_audit_execution_identity(
    project_root: Path, config: Mapping[str, Any]
) -> dict[str, Any]:
    del config
    source = _safe_path(project_root, SOURCE_RELATIVE_PATH, must_exist=True)
    authorization = _safe_path(project_root, AUTHORIZATION_RELATIVE_PATH, must_exist=True)
    authorization_chain = validate_execution_authorization(project_root)
    return {
        "independent_audit_source": {
            "relative_path": _relative(source, project_root),
            "bytes": source.stat().st_size,
            "sha256": _hash_file(source),
        },
        "execution_authorization": {
            "relative_path": _relative(authorization, project_root),
            "bytes": authorization.stat().st_size,
            "sha256": _hash_file(authorization),
        },
        "authorized_chain": authorization_chain,
    }


def run_independent_audit(
    *,
    preregistration_path: Path = PROJECT_ROOT / PREREGISTRATION_RELATIVE_PATH,
    project_root: Path = PROJECT_ROOT,
    snapshot_provider: Callable[[int, float], Mapping[str, Any]] = _resource_sample,
    process_counter: Callable[[], int] | None = None,
    blind_input_loader: Callable[[Mapping[str, Any], Path], IndependentBlindInputs] = load_independent_blind_inputs,
    full_package_loader: Callable[[Mapping[str, Any], Path], tuple[list[dict[str, np.ndarray]], dict[str, Any]]] = load_prior_packages_after_coverage,
) -> dict[str, Any]:
    root = Path(project_root).resolve()
    config = load_frozen_config(preregistration_path, root)
    thread_snapshot = enforce_single_thread_runtime()
    resource_snapshot = audit_resource_gate(
        config,
        root,
        snapshot_provider=snapshot_provider,
        process_counter=process_counter,
    )
    resource_snapshot["runtime_thread_identity"] = thread_snapshot
    execution_identity = capture_audit_execution_identity(root, config)
    loaded = blind_input_loader(config, root)
    reconstructed_catalogue = reconstruct_catalogue(loaded, config)
    differences, blind_chain = load_and_compare_blind_outputs(
        config, root, reconstructed_catalogue, loaded
    )
    coverage_passed = _strict_bool(
        reconstructed_catalogue[2].iloc[0]["coverage_passed"], "coverage"
    )
    scoring_identity: Mapping[str, Any] = {}
    main_chain: Mapping[str, Any] = {}
    reconstructed_scores: Mapping[str, Any] | None = None

    def full_branch() -> tuple[Mapping[str, Any], Mapping[str, Any], Mapping[str, Any], list[dict[str, str]]]:
        packages, identity = full_package_loader(config, root)
        scores = independently_score_packages(packages, reconstructed_catalogue[1], config)
        main_differences, chain = compare_main_diagnostic(
            config,
            root,
            scores,
            blind_chain=blind_chain,
            scoring_identity=identity,
            paired_event_count=int(
                reconstructed_catalogue[2].iloc[0]["paired_event_count"]
            ),
        )
        return scores, identity, chain, main_differences

    branch, full_payload = choose_coverage_or_full_branch(
        coverage_passed, full_branch=full_branch
    )
    if branch == "full":
        assert full_payload is not None
        reconstructed_scores, scoring_identity, main_chain, main_differences = full_payload
        differences.extend(main_differences)
    mismatch_frame = pd.DataFrame(differences, columns=MISMATCH_COLUMNS)
    prereg = _safe_path(root, preregistration_path, must_exist=True)
    input_manifest = {
        "schema_version": 1,
        "experiment_id": EXPERIMENT_ID,
        "result_label": RESULT_LABEL,
        "preregistration": {
            "relative_path": _relative(prereg, root),
            "bytes": prereg.stat().st_size,
            "sha256": _hash_file(prereg),
        },
        "execution_identity": execution_identity,
        "blind_input_identities": dict(loaded.identities),
        "blind_access_audit": dict(loaded.access_audit),
        "blind_catalogue_completion": blind_chain["completion_identity"],
        "blind_event_manifest": blind_chain["manifest_identity"],
        "scoring_identity": dict(scoring_identity),
        "main_diagnostic_chain": dict(main_chain),
    }
    summary = {
        "schema_version": 1,
        "experiment_id": EXPERIMENT_ID,
        "result_label": RESULT_LABEL,
        "audit_status": "reproducible" if not differences else "not_reproducible",
        "coverage_passed": coverage_passed,
        "paired_event_count": int(reconstructed_catalogue[2].iloc[0]["paired_event_count"]),
        "prediction_package_read_count": EXPECTED_PACKAGE_COUNT if coverage_passed else 0,
        "mismatch_count": len(differences),
        "derived_float64_absolute_tolerance": FLOAT_TOLERANCE,
        "formal_decision_unchanged": True,
    }
    artifacts: dict[str, pd.DataFrame | Mapping[str, Any]] = {
        "reconstructed_event_catalog.csv": reconstructed_catalogue[0],
        "reconstructed_event_issue_map.csv": reconstructed_catalogue[1],
        "reconstructed_event_coverage.csv": reconstructed_catalogue[2],
        "mismatches.csv": mismatch_frame,
        "independent_audit_summary.json": summary,
        "input_manifest.json": input_manifest,
        "resource_snapshot.json": resource_snapshot,
    }
    if coverage_passed:
        if reconstructed_scores is None:
            raise AuditContractError("full audit scores missing")
        artifacts.update(
            {
                "reconstructed_event_seed_lead_metrics.csv": reconstructed_scores["event_seed_lead_metrics"],
                "reconstructed_event_level_summary.csv": reconstructed_scores["event_level_summary"],
                "reconstructed_seed_level_summary.csv": reconstructed_scores["seed_level_summary"],
                "reconstructed_lead_hour_summary.csv": reconstructed_scores["lead_hour_summary"],
                "reconstructed_leave_one_event_out.csv": reconstructed_scores["leave_one_event_out"],
                "reconstructed_event_influence_summary.csv": reconstructed_scores["event_influence_summary"],
            }
        )
    output_root = _safe_path(
        root, config["output_roots"]["independent_audit"], must_exist=False
    )
    published = publish_independent_audit(
        output_root,
        artifacts,
        coverage_passed=coverage_passed,
        mismatch_count=len(differences),
    )
    return {
        "audit_status": summary["audit_status"],
        "coverage_passed": coverage_passed,
        "mismatch_count": len(differences),
        "output_root": str(published),
    }


def _r2_runtime_config(
    original: Mapping[str, Any], retry: Mapping[str, Any]
) -> dict[str, Any]:
    runtime = dict(original)
    roots = dict(original["output_roots"])
    roots["independent_audit"] = retry["output_contract"]["retry_output_root"]
    runtime["output_roots"] = roots
    return runtime


def run_r2_coverage_audit(
    *,
    preregistration_path: Path = PROJECT_ROOT / R2_PREREGISTRATION_RELATIVE_PATH,
    project_root: Path = PROJECT_ROOT,
    snapshot_provider: Callable[[int, float], Mapping[str, Any]] = _resource_sample,
    process_counter: Callable[[], int] | None = None,
    blind_input_loader: Callable[
        [Mapping[str, Any], Path], IndependentBlindInputs
    ] = load_independent_blind_inputs,
) -> dict[str, Any]:
    """Execute the one registered R2 coverage-only audit without package access."""
    root = Path(project_root).resolve()
    retry = load_frozen_r2_preregistration(preregistration_path, root)
    original_identity = retry["bound_parent_contracts"][
        "original_event_preregistration"
    ]
    _verify_bound_file_identity(
        root, original_identity, "R2 original event preregistration"
    )
    original = load_frozen_config(
        _safe_path(root, original_identity["relative_path"], must_exist=True), root
    )
    runtime_config = _r2_runtime_config(original, retry)
    thread_snapshot = enforce_single_thread_runtime()
    resource_snapshot = audit_resource_gate(
        runtime_config,
        root,
        snapshot_provider=snapshot_provider,
        process_counter=process_counter,
    )
    resource_snapshot["runtime_thread_identity"] = thread_snapshot
    r2_authorization = validate_r2_execution_authorization(root, retry)
    blind_precondition = verify_r2_bound_blind_precondition(root, retry)
    old_chain = verify_r2_old_failed_audit_root(root, retry)
    historical_authorization = load_bound_original_authorization_history(root, retry)

    loaded = blind_input_loader(original, root)
    reconstructed = reconstruct_catalogue(loaded, original)
    differences, blind_chain = load_and_compare_blind_outputs(
        original,
        root,
        reconstructed,
        loaded,
        original_authorization_chain=historical_authorization,
    )
    coverage_value = _strict_bool(
        reconstructed[2].iloc[0]["coverage_passed"], "R2 reconstructed coverage"
    )
    paired_count = int(reconstructed[2].iloc[0]["paired_event_count"])
    minimum_count = int(
        reconstructed[2].iloc[0]["minimum_paired_event_count"]
    )
    assert_r2_coverage_only_precondition(
        coverage_passed=coverage_value,
        paired_event_count=paired_count,
        minimum_paired_event_count=minimum_count,
        decision=(
            "ELIGIBLE_FOR_EVENT_SCORING"
            if coverage_value
            else "HOLD_EXPLORATORY_INSUFFICIENT_PAIRED_EVENT_COVERAGE"
        ),
        retry=retry,
    )
    assert_r2_coverage_only_precondition(
        coverage_passed=blind_chain["coverage_passed"],
        paired_event_count=blind_chain["paired_event_count"],
        minimum_paired_event_count=minimum_count,
        decision=blind_precondition["decision"]["decision"],
        retry=retry,
    )
    mismatch_frame = pd.DataFrame(differences, columns=MISMATCH_COLUMNS)
    r2_preregistration = _safe_path(root, preregistration_path, must_exist=True)
    r2_authorization_path = _safe_path(
        root, R2_AUTHORIZATION_RELATIVE_PATH, must_exist=True
    )
    input_manifest = {
        "schema_version": 1,
        "experiment_id": EXPERIMENT_ID,
        "retry_id": R2_RETRY_ID,
        "result_label": R2_RESULT_LABEL,
        "retry_preregistration": {
            "relative_path": _relative(r2_preregistration, root),
            "bytes": r2_preregistration.stat().st_size,
            "sha256": _hash_file(r2_preregistration),
        },
        "execution_identity": {
            "independent_audit_source": r2_authorization["implementations"][
                "independent_audit"
            ],
            "retry_execution_authorization": {
                "relative_path": _relative(r2_authorization_path, root),
                "bytes": r2_authorization_path.stat().st_size,
                "sha256": _hash_file(r2_authorization_path),
            },
            "authorized_chain": r2_authorization,
        },
        "bound_parent_contracts": dict(retry["bound_parent_contracts"]),
        "bound_blind_catalogue_outputs": dict(
            retry["bound_blind_catalogue_outputs"]
        ),
        "bound_failed_audit_outputs": dict(retry["bound_failed_audit_outputs"]),
        "failed_run_source_and_test_identities": dict(
            retry["failed_run_source_and_test_identities"]
        ),
        "old_failed_audit_chain": {
            "completion_identity": old_chain["completion_identity"],
            "summary_identity": old_chain["summary_identity"],
            "mismatches_identity": old_chain["mismatches_identity"],
            "artifact_identities": old_chain["artifact_identities"],
        },
        "blind_input_identities": dict(loaded.identities),
        "blind_access_audit": dict(loaded.access_audit),
        "blind_catalogue_completion": blind_chain["completion_identity"],
        "blind_event_manifest": blind_chain["manifest_identity"],
        "comparison_contract": dict(retry["frozen_comparison_repair"]),
        "prediction_package_open_count": 0,
        "prediction_array_read_count": 0,
        "target_array_read_count": 0,
        "target_numeric_parse_count": 0,
        "forecast_error_read_count": 0,
        "formal_result_root_open_count": 0,
    }
    summary = {
        "schema_version": 1,
        "experiment_id": EXPERIMENT_ID,
        "retry_id": R2_RETRY_ID,
        "result_label": R2_RESULT_LABEL,
        "audit_status": "reproducible" if not differences else "not_reproducible",
        "coverage_branch": "coverage_only",
        "coverage_passed": False,
        "paired_event_count": paired_count,
        "minimum_paired_event_count": minimum_count,
        "prediction_package_read_count": 0,
        "prediction_array_read_count": 0,
        "target_array_read_count": 0,
        "target_numeric_parse_count": 0,
        "forecast_error_read_count": 0,
        "formal_result_root_open_count": 0,
        "float32_csv_columns": [
            "issue_stage_m", "reference_stage_m", "delta_m"
        ],
        "float32_observed_conversion": [
            "pandas.to_numeric_errors_coerce", "numpy.float32", "numpy.float64"
        ],
        "raw_uint32_comparison": "exact_zero_tolerance",
        "derived_float64_absolute_tolerance": FLOAT_TOLERANCE,
        "mismatch_count": len(differences),
        "formal_decision_unchanged": True,
        "scientific_confirmation_claim_allowed": False,
    }
    artifacts: dict[str, pd.DataFrame | Mapping[str, Any]] = {
        "reconstructed_event_catalog.csv": reconstructed[0],
        "reconstructed_event_issue_map.csv": reconstructed[1],
        "reconstructed_event_coverage.csv": reconstructed[2],
        "mismatches.csv": mismatch_frame,
        "independent_audit_summary.json": summary,
        "input_manifest.json": input_manifest,
        "resource_snapshot.json": resource_snapshot,
    }
    old_before_publish = verify_r2_old_failed_audit_root(root, retry)
    if (
        old_before_publish["completion_identity"] != old_chain["completion_identity"]
        or old_before_publish["summary_identity"] != old_chain["summary_identity"]
        or old_before_publish["mismatches_identity"]
        != old_chain["mismatches_identity"]
    ):
        raise AuditContractError("old failed audit root changed during R2")
    output_root = _safe_path(
        root, retry["output_contract"]["retry_output_root"], must_exist=False
    )
    published = publish_independent_audit(
        output_root,
        artifacts,
        coverage_passed=False,
        mismatch_count=len(differences),
        result_label=R2_RESULT_LABEL,
        retry_id=R2_RETRY_ID,
    )
    return {
        "audit_status": summary["audit_status"],
        "coverage_passed": False,
        "paired_event_count": paired_count,
        "prediction_package_read_count": 0,
        "mismatch_count": len(differences),
        "output_root": str(published),
    }


def parse_arguments(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--preregistration",
        type=Path,
        default=PROJECT_ROOT / R2_PREREGISTRATION_RELATIVE_PATH,
    )
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    arguments = parse_arguments(argv)
    result = run_r2_coverage_audit(preregistration_path=arguments.preregistration)
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (AuditContractError, AuditResourceGateError, FileExistsError) as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(2) from exc
