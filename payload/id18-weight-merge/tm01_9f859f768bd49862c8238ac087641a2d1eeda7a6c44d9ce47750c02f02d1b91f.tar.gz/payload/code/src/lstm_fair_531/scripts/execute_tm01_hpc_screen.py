"""Execute the manifest-bound TM01 development screen on an isolated compute node."""

from __future__ import annotations

import argparse
import json
import os
import pickle
import platform
import shutil
import subprocess
import sys
from collections import OrderedDict
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from ruamel.yaml import YAML

from src.lstm_fair_531.scripts.run_tm01_sign_aware_task_vector_merge import (
    EXPECTED_METHODS,
    EXPECTED_SEEDS,
    canonical_state_dict_sha256,
    decide_conflict_resolution_signal,
    load_contract,
    merge_state_dicts,
    paired_basin_bootstrap,
    score_basin,
    sha256_file,
    task_vector_diagnostics,
    validate_state_dicts,
)


def _atomic_write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def _read_basins(path: Path) -> list[str]:
    basins = [line.strip().zfill(8) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(basins) != len(set(basins)):
        raise ValueError("basin file contains duplicate identifiers")
    return basins


def _load_checkpoint(path: Path) -> OrderedDict[str, torch.Tensor]:
    try:
        payload = torch.load(path, map_location="cpu", weights_only=True)
    except TypeError:
        payload = torch.load(path, map_location="cpu")
    if not isinstance(payload, dict) or not payload:
        raise ValueError(f"checkpoint is not a nonempty state dictionary: {path}")
    if not all(isinstance(name, str) and isinstance(tensor, torch.Tensor) for name, tensor in payload.items()):
        raise ValueError(f"checkpoint contains non-tensor state: {path}")
    return OrderedDict((name, tensor.detach().cpu()) for name, tensor in payload.items())


def verify_execution_data_root(contract: dict, payload_root: Path) -> dict:
    """Verify that the execution root contains exactly the approved restricted files."""
    data_root = payload_root / contract["safe_data"]["root"]
    manifest_path = payload_root / contract["safe_data"]["manifest"]
    if sha256_file(manifest_path) != contract["safe_data"]["manifest_sha256"]:
        raise ValueError("restricted-data manifest SHA-256 mismatch")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("time_series_start") != contract["safe_data"]["physical_start"]:
        raise ValueError("restricted-data physical start drifted")
    if manifest.get("time_series_end") != contract["safe_data"]["physical_end"]:
        raise ValueError("restricted-data physical end drifted")
    if manifest.get("sealed_paper_evaluation_values_in_output") is not False:
        raise ValueError("restricted-data manifest does not exclude sealed evaluation values")
    expected_basins = [str(value).zfill(8) for value in manifest.get("basins", [])]
    if len(expected_basins) != contract["expected_basin_count"] or len(set(expected_basins)) != len(expected_basins):
        raise ValueError("restricted-data basin population drifted")

    excluded = set(contract["safe_data"]["execution_excluded_files"])
    expected_files = {contract["safe_data"]["manifest"].split("/", 2)[-1]}
    verified_entries = []
    for record in manifest.get("files", []):
        relative = str(record["path"]).replace("\\", "/")
        if relative in excluded:
            continue
        path = data_root / Path(relative)
        if sha256_file(path) != record["sha256"]:
            raise ValueError(f"restricted execution file SHA-256 mismatch: {relative}")
        if record.get("kind") in {"forcing", "discharge"}:
            if record.get("start") != contract["safe_data"]["physical_start"]:
                raise ValueError(f"restricted time-series start drifted: {relative}")
            if record.get("end") != contract["safe_data"]["physical_end"]:
                raise ValueError(f"restricted time-series end drifted: {relative}")
            if int(record.get("row_count", -1)) != int(manifest["time_series_day_count"]):
                raise ValueError(f"restricted time-series row count drifted: {relative}")
        expected_files.add(relative)
        verified_entries.append({"path": relative, "sha256": record["sha256"]})

    for relative in excluded:
        if (data_root / Path(relative)).exists():
            raise ValueError(f"excluded hydrological-signature file is present: {relative}")
    actual_files = {
        path.relative_to(data_root).as_posix()
        for path in data_root.rglob("*")
        if path.is_file()
    }
    manifest_relative = Path(contract["safe_data"]["manifest"]).relative_to(contract["safe_data"]["root"]).as_posix()
    expected_files.discard(contract["safe_data"]["manifest"].split("/", 2)[-1])
    expected_files.add(manifest_relative)
    if actual_files != expected_files:
        unexpected = sorted(actual_files - expected_files)
        missing = sorted(expected_files - actual_files)
        raise ValueError(f"restricted execution file set drifted: unexpected={unexpected}, missing={missing}")
    return {
        "data_root": str(data_root.resolve()),
        "manifest_path": str(manifest_path.resolve()),
        "manifest_sha256": contract["safe_data"]["manifest_sha256"],
        "basins": expected_basins,
        "verified_file_count": len(verified_entries),
        "excluded_files_absent": sorted(excluded),
        "physical_start": manifest["time_series_start"],
        "physical_end": manifest["time_series_end"],
    }


def _write_yaml(path: Path, payload: dict) -> None:
    yaml = YAML()
    yaml.default_flow_style = False
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        yaml.dump(payload, handle)


def _prepare_run_directory(
    *,
    method: str,
    seed: int,
    state_dict: OrderedDict[str, torch.Tensor],
    source_config_path: Path,
    scaler_path: Path,
    data_root: Path,
    basin_file: Path,
    run_root: Path,
) -> tuple[Path, Path]:
    yaml = YAML(typ="safe")
    with source_config_path.open("r", encoding="utf-8") as handle:
        config = yaml.load(handle)
    if not isinstance(config, dict):
        raise ValueError("source configuration is not a mapping")
    run_directory = run_root / method / f"s{seed}"
    if run_directory.exists():
        raise FileExistsError(f"TM01 run directory already exists: {run_directory}")
    (run_directory / "train_data").mkdir(parents=True)
    config.update({
        "experiment_name": f"TM01_{method}_s{seed}",
        "data_dir": str(data_root.resolve()),
        "train_basin_file": str(basin_file.resolve()),
        "validation_basin_file": str(basin_file.resolve()),
        "test_basin_file": str(basin_file.resolve()),
        "run_dir": str(run_directory.resolve()),
        "train_dir": str((run_directory / "train_data").resolve()),
        "img_log_dir": str((run_directory / "img_log").resolve()),
        "number_of_basins": 24,
        "test_start_date": "01/10/2005",
        "test_end_date": "30/09/2008",
        "metrics": ["NSE"],
        "save_all_output": True,
        "num_workers": 0,
        "device": "cuda:0",
        "loss": "BasinAverageNSE",
    })
    config_path = run_directory / "config.yml"
    _write_yaml(config_path, config)
    shutil.copy2(scaler_path, run_directory / "train_data" / "train_data_scaler.yml")
    checkpoint_path = run_directory / "model_epoch030.pt"
    torch.save(state_dict, checkpoint_path)
    if canonical_state_dict_sha256(_load_checkpoint(checkpoint_path)) != canonical_state_dict_sha256(state_dict):
        raise RuntimeError(f"saved merged checkpoint failed canonical verification: {method}, seed {seed}")
    return run_directory, checkpoint_path


def _run_evaluation(run_directory: Path, code_root: Path, gpu: int, log_path: Path) -> Path:
    command = [
        sys.executable,
        "-X",
        "utf8",
        "-m",
        "neuralhydrology.nh_run",
        "evaluate",
        "--run-dir",
        str(run_directory),
        "--period",
        "test",
        "--epoch",
        "30",
        "--gpu",
        str(gpu),
    ]
    environment = os.environ.copy()
    environment["PYTHONPATH"] = str(code_root) + os.pathsep + environment.get("PYTHONPATH", "")
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write("COMMAND " + subprocess.list2cmdline(command) + "\n")
        handle.flush()
        subprocess.run(
            command,
            cwd=code_root,
            env=environment,
            stdout=handle,
            stderr=subprocess.STDOUT,
            check=True,
        )
    prediction_path = run_directory / "test" / "model_epoch030" / "test_results.p"
    if not prediction_path.exists():
        raise RuntimeError(f"evaluation did not create predictions: {run_directory}")
    return prediction_path


def _vector(dataset, variable: str) -> np.ndarray:
    values = np.asarray(dataset[variable].values)
    if values.ndim == 2 and values.shape[1] == 1:
        values = values[:, 0]
    if values.ndim != 1:
        raise ValueError(f"unexpected prediction vector shape for {variable}: {values.shape}")
    return values.astype(np.float64)


def extract_prediction_artifact(
    path: Path,
    *,
    basins: list[str],
    expected_start: str,
    expected_end: str,
) -> tuple[np.ndarray, np.ndarray]:
    """Extract one safe-period observation and simulation matrix with strict guards."""
    with Path(path).open("rb") as stream:
        payload = pickle.load(stream)
    if not isinstance(payload, dict):
        raise ValueError("prediction artifact is not a basin dictionary")
    normalized = {str(key).zfill(8): key for key in payload}
    if len(normalized) != len(payload) or set(normalized) != set(basins):
        raise ValueError("prediction basin population differs from the frozen list")
    expected_dates = pd.date_range(expected_start, expected_end, freq="D")
    observations = np.empty((len(basins), len(expected_dates)), dtype=np.float64)
    simulations = np.empty_like(observations)
    for index, basin in enumerate(basins):
        dataset = payload[normalized[basin]]["1D"]["xr"]
        dates = pd.DatetimeIndex(dataset["date"].values)
        if not dates.equals(expected_dates):
            raise ValueError(f"prediction dates drifted for basin {basin}")
        observation_variables = [name for name in dataset.data_vars if str(name).endswith("_obs")]
        simulation_variables = [name for name in dataset.data_vars if str(name).endswith("_sim")]
        if len(observation_variables) != 1 or len(simulation_variables) != 1:
            raise ValueError(f"prediction variables drifted for basin {basin}")
        observations[index] = _vector(dataset, observation_variables[0])
        simulations[index] = _vector(dataset, simulation_variables[0])
    if not np.isfinite(simulations).all():
        raise ValueError("prediction artifact contains non-finite simulation values")
    return observations, simulations


def _score_methods(
    basins: list[str],
    observations: np.ndarray,
    predictions: dict[str, list[np.ndarray]],
    contract: dict,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, dict]:
    per_seed_rows = []
    ensemble_rows = []
    ensemble_metrics: dict[str, dict[str, dict[str, float | int]]] = {}
    for method in EXPECTED_METHODS:
        cube = np.stack(predictions[method], axis=0)
        for seed_index, seed in enumerate(EXPECTED_SEEDS):
            for basin_index, basin in enumerate(basins):
                metrics = score_basin(observations[basin_index], cube[seed_index, basin_index])
                per_seed_rows.append({"method": method, "seed": seed, "basin_id": basin, **metrics})
        ensemble = np.median(cube, axis=0)
        ensemble_metrics[method] = {}
        for basin_index, basin in enumerate(basins):
            metrics = score_basin(observations[basin_index], ensemble[basin_index])
            ensemble_metrics[method][basin] = metrics
            ensemble_rows.append({"method": method, "basin_id": basin, **metrics})
    per_seed = pd.DataFrame(per_seed_rows)
    per_basin = pd.DataFrame(ensemble_rows)
    metric_columns = [column for column in per_basin.columns if column not in {"method", "basin_id"}]
    summary_rows = []
    for method in EXPECTED_METHODS:
        rows = per_basin[per_basin["method"] == method]
        summary_rows.append({
            "method": method,
            **{f"median_{metric}": float(rows[metric].median()) for metric in metric_columns},
        })
    summary = pd.DataFrame(summary_rows)

    comparison_rows = []
    bootstrap = contract["bootstrap"]
    for specification in contract["primary_comparisons"]:
        candidate = specification["candidate"]
        comparator = specification["comparator"]
        metric = specification["metric"]
        differences = np.asarray([
            ensemble_metrics[candidate][basin][metric] - ensemble_metrics[comparator][basin][metric]
            for basin in basins
        ])
        median, lower, upper = paired_basin_bootstrap(
            differences,
            replicates=bootstrap["replicates"],
            seed=bootstrap["seed"],
        )
        comparison_rows.append({
            "candidate": candidate,
            "comparator": comparator,
            "metric": metric,
            "basin_count": len(basins),
            "median_difference": median,
            "ci_lower": lower,
            "ci_upper": upper,
        })
    comparisons = pd.DataFrame(comparison_rows)
    decision = decide_conflict_resolution_signal(comparisons)
    return per_seed, per_basin, summary, comparisons, decision


def run_screen(
    *,
    contract_path: Path,
    payload_root: Path,
    code_root: Path,
    output_directory: Path,
    gpu: int,
) -> dict:
    """Run all fixed methods and score the restricted 24-basin development screen."""
    if output_directory.exists():
        raise FileExistsError(f"TM01 output directory already exists: {output_directory}")
    if gpu < 0 or not torch.cuda.is_available():
        raise RuntimeError("TM01 high-performance-computer screen requires an available CUDA device")
    contract = load_contract(contract_path)
    data_record = verify_execution_data_root(contract, payload_root)
    basin_file = payload_root / contract["basin_file"]
    if sha256_file(basin_file) != contract["basin_file_sha256"]:
        raise ValueError("basin-file SHA-256 mismatch")
    basins = _read_basins(basin_file)
    if basins != data_record["basins"]:
        raise ValueError("basin file order differs from restricted-data manifest")
    scaler_path = payload_root / contract["scaler"]["path"]
    if sha256_file(scaler_path) != contract["scaler"]["sha256"]:
        raise ValueError("scaler SHA-256 mismatch")

    sources = {}
    for source in contract["sources"]:
        checkpoint_path = payload_root / source["checkpoint"]
        config_path = payload_root / source["config"]
        if sha256_file(checkpoint_path) != source["checkpoint_sha256"]:
            raise ValueError("source checkpoint SHA-256 mismatch")
        if sha256_file(config_path) != source["config_sha256"]:
            raise ValueError("source config SHA-256 mismatch")
        sources[(source["objective"], int(source["seed"]))] = {
            "state": _load_checkpoint(checkpoint_path),
            "config": config_path,
        }

    output_directory.mkdir(parents=True, exist_ok=False)
    run_root = output_directory / "runs"
    log_root = output_directory / "logs"
    analysis_root = output_directory / "analysis"
    protocol_root = output_directory / "protocol"
    predictions: dict[str, list[np.ndarray]] = {method: [] for method in EXPECTED_METHODS}
    reference_observations = None
    prediction_records = []
    merge_records = []
    for seed in EXPECTED_SEEDS:
        base_path = payload_root / "reconstructed_bases" / f"reconstructed_base_s{seed}.pt"
        base = _load_checkpoint(base_path)
        expected_base_hash = contract["base_reconstruction"]["expected_state_dict_sha256"][str(seed)]
        if canonical_state_dict_sha256(base) != expected_base_hash:
            raise ValueError(f"reconstructed base SHA-256 mismatch for seed {seed}")
        nse = sources[("nse", seed)]["state"]
        flow = sources[("flow_regime_nse", seed)]["state"]
        validate_state_dicts(base, nse, flow)
        merged = merge_state_dicts(
            base,
            nse,
            flow,
            top_k_percent=contract["merge"]["top_k_percent"],
            scaling_factor=contract["merge"]["scaling_factor"],
        )
        diagnostics = task_vector_diagnostics(
            base,
            nse,
            flow,
            top_k_percent=contract["merge"]["top_k_percent"],
        )
        merge_records.append({
            "seed": seed,
            "base_provenance": contract["base_reconstruction"]["provenance"],
            "base_state_dict_sha256": expected_base_hash,
            "diagnostics": diagnostics,
            "method_state_dict_sha256": {
                method: canonical_state_dict_sha256(state) for method, state in merged.items()
            },
        })
        for method in EXPECTED_METHODS:
            run_directory, checkpoint_path = _prepare_run_directory(
                method=method,
                seed=seed,
                state_dict=merged[method],
                source_config_path=sources[("nse", seed)]["config"],
                scaler_path=scaler_path,
                data_root=Path(data_record["data_root"]),
                basin_file=basin_file,
                run_root=run_root,
            )
            prediction_path = _run_evaluation(
                run_directory,
                code_root,
                gpu,
                log_root / method / f"s{seed}.log",
            )
            observations, simulation = extract_prediction_artifact(
                prediction_path,
                basins=basins,
                expected_start=contract["development_period"]["start"],
                expected_end=contract["development_period"]["end"],
            )
            if reference_observations is None:
                reference_observations = observations
            elif not np.array_equal(reference_observations, observations, equal_nan=True):
                raise ValueError(f"observations differ across TM01 methods at {method}, seed {seed}")
            predictions[method].append(simulation)
            prediction_records.append({
                "method": method,
                "seed": seed,
                "checkpoint_path": str(checkpoint_path.resolve()),
                "checkpoint_file_sha256": sha256_file(checkpoint_path),
                "checkpoint_state_dict_sha256": canonical_state_dict_sha256(merged[method]),
                "prediction_path": str(prediction_path.resolve()),
                "prediction_sha256": sha256_file(prediction_path),
            })
    if reference_observations is None:
        raise RuntimeError("TM01 produced no predictions")

    per_seed, per_basin, summary, comparisons, decision = _score_methods(
        basins,
        reference_observations,
        predictions,
        contract,
    )
    analysis_root.mkdir(parents=True)
    per_seed.to_csv(analysis_root / "per_seed_per_basin_metrics.csv", index=False)
    per_basin.to_csv(analysis_root / "ensemble_per_basin_metrics.csv", index=False)
    summary.to_csv(analysis_root / "method_summary.csv", index=False)
    comparisons.to_csv(analysis_root / "paired_comparisons.csv", index=False)
    _atomic_write_json(analysis_root / "decision.json", decision)
    protocol = {
        "experiment_id": contract["experiment_id"],
        "status": "COMPLETE",
        "development_only": True,
        "sealed_period_opened": False,
        "base_provenance": contract["base_reconstruction"]["provenance"],
        "contract_sha256": sha256_file(contract_path),
        "data": data_record,
        "environment": {
            "python": sys.version.split()[0],
            "pytorch": torch.__version__,
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "platform": platform.platform(),
            "cuda": torch.version.cuda,
            "gpu": torch.cuda.get_device_name(gpu),
        },
        "merge_records": merge_records,
        "prediction_records": prediction_records,
        "analysis_files": {},
        "decision": decision,
    }
    protocol_root.mkdir(parents=True)
    for path in sorted(analysis_root.iterdir()):
        protocol["analysis_files"][path.name] = sha256_file(path)
    _atomic_write_json(protocol_root / "execution_manifest.json", protocol)
    return protocol


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--payload-root", type=Path, required=True)
    parser.add_argument("--code-root", type=Path, required=True)
    parser.add_argument("--output-directory", type=Path, required=True)
    parser.add_argument("--gpu", type=int, default=0)
    return parser


def main(argv=None) -> int:
    args = _build_parser().parse_args(argv)
    result = run_screen(
        contract_path=args.contract,
        payload_root=args.payload_root,
        code_root=args.code_root,
        output_directory=args.output_directory,
        gpu=args.gpu,
    )
    print(json.dumps({
        "experiment_id": result["experiment_id"],
        "status": result["status"],
        "verdict": result["decision"]["verdict"],
        "sealed_period_opened": result["sealed_period_opened"],
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
