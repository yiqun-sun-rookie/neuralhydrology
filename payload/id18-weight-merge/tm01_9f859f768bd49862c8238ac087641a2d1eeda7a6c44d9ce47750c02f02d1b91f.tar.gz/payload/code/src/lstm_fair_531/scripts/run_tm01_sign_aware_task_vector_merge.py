"""Run the ID18 reconstructed-base sign-aware task-vector merge screen.

The pure functions in this module do not open hydrological data. Hydrological
inference is added behind explicit manifest and date guards in the experiment
execution path.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
import random
import sys
from collections import OrderedDict
from datetime import date
from pathlib import Path
from typing import Mapping

import numpy as np
import pandas as pd
import torch


EXPERIMENT_ID = "TM01_reconstructed_base_sign_aware_merge_screen_20260826"
EXPECTED_METHODS = (
    "endpoint_nse",
    "endpoint_flow_regime_nse",
    "dense_midpoint",
    "ties_no_trim",
    "ties_no_elect",
    "ties_no_disjoint",
    "ties_full",
)
EXPECTED_SEEDS = (100, 200, 300)
EXPECTED_OBJECTIVES = ("nse", "flow_regime_nse")
SEALED_START = date.fromisoformat("1989-10-01")
SEALED_END = date.fromisoformat("1999-09-30")
SAFE_MANIFEST_SHA256 = "96bc30d6c6ff0771fb6d5d2585bffdc33e2ed1988572d9f3b22c14a28e679d6e"

StateDict = Mapping[str, torch.Tensor]
REPOSITORY_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_CONTRACT_PATH = (
    REPOSITORY_ROOT
    / "src/lstm_fair_531/configs/tm01_reconstructed_base_sign_aware_merge_screen_20260826.json"
)


def _parse_iso_date(value: str, field: str) -> date:
    try:
        return date.fromisoformat(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{field} must be an ISO date") from error


def _assert_no_sealed_overlap(start: str, end: str, field: str) -> None:
    start_date = _parse_iso_date(start, f"{field}.start")
    end_date = _parse_iso_date(end, f"{field}.end")
    if start_date > end_date:
        raise ValueError(f"{field} starts after it ends")
    if start_date <= SEALED_END and end_date >= SEALED_START:
        raise ValueError(f"{field} overlaps the sealed period")


def _require_sha256(value: object, field: str) -> str:
    normalized = str(value).lower()
    if len(normalized) != 64 or any(character not in "0123456789abcdef" for character in normalized):
        raise ValueError(f"{field} must be a lowercase SHA-256 digest")
    return normalized


def load_contract(path: Path) -> dict:
    """Load and validate the frozen TM01 contract without opening scientific data."""
    contract = json.loads(Path(path).read_text(encoding="utf-8"))
    if contract.get("experiment_id") != EXPERIMENT_ID:
        raise ValueError("unexpected TM01 experiment identifier")
    if tuple(contract.get("seeds", ())) != EXPECTED_SEEDS:
        raise ValueError("TM01 seeds drifted")
    if int(contract.get("source_epoch", -1)) != 30:
        raise ValueError("TM01 source epoch drifted")
    if tuple(contract.get("source_objectives", ())) != EXPECTED_OBJECTIVES:
        raise ValueError("TM01 source objectives drifted")
    if tuple(contract.get("methods", ())) != EXPECTED_METHODS:
        raise ValueError("TM01 methods drifted")

    merge = contract.get("merge", {})
    if int(merge.get("top_k_percent", -1)) != 20:
        raise ValueError("TM01 top-k percentage drifted")
    if float(merge.get("scaling_factor", math.nan)) != 1.0:
        raise ValueError("TM01 scaling factor drifted")
    if merge.get("exact_tie_rule") != "return_to_reconstructed_base":
        raise ValueError("TM01 exact sign-tie rule drifted")

    development = contract.get("development_period", {})
    sealed = contract.get("sealed_period", {})
    if sealed != {"start": SEALED_START.isoformat(), "end": SEALED_END.isoformat()}:
        raise ValueError("TM01 sealed-period declaration drifted")
    _assert_no_sealed_overlap(development.get("start"), development.get("end"), "development_period")
    if development != {"start": "2005-10-01", "end": "2008-09-30"}:
        raise ValueError("TM01 development period drifted")

    if int(contract.get("expected_basin_count", -1)) != 24:
        raise ValueError("TM01 basin count drifted")
    safe_data = contract.get("safe_data", {})
    if safe_data.get("root") != "data/camels_us_id18_20000105_20080930":
        raise ValueError("TM01 must use the physically restricted data root")
    if _require_sha256(safe_data.get("manifest_sha256"), "safe_data.manifest_sha256") != SAFE_MANIFEST_SHA256:
        raise ValueError("TM01 restricted-data manifest hash drifted")
    _assert_no_sealed_overlap(safe_data.get("physical_start"), safe_data.get("physical_end"), "safe_data")
    if safe_data.get("contains_rows_outside_physical_bounds") is not False:
        raise ValueError("TM01 safe-data contract must forbid rows outside physical bounds")
    if safe_data.get("execution_excluded_files") != ["camels_attributes_v2.0/camels_hydro.txt"]:
        raise ValueError("TM01 execution exclusion list drifted")

    reconstruction = contract.get("base_reconstruction", {})
    if reconstruction.get("provenance") != "RECONSTRUCTED_NOT_SAVED":
        raise ValueError("TM01 must disclose that epoch-0 checkpoints were not saved")
    if reconstruction.get("training_commit") != "9aa9d1ce":
        raise ValueError("TM01 reconstruction commit drifted")
    if reconstruction.get("recorded_package_version") != "1.12.0":
        raise ValueError("TM01 recorded package version drifted")
    reconstructed_hashes = reconstruction.get("expected_state_dict_sha256", {})
    if set(reconstructed_hashes) != {str(seed) for seed in EXPECTED_SEEDS}:
        raise ValueError("TM01 reconstructed-base hash seeds drifted")
    for seed, digest in reconstructed_hashes.items():
        _require_sha256(digest, f"base_reconstruction.expected_state_dict_sha256.{seed}")

    sources = contract.get("sources", [])
    expected_pairs = {(objective, seed) for objective in EXPECTED_OBJECTIVES for seed in EXPECTED_SEEDS}
    actual_pairs = {(item.get("objective"), item.get("seed")) for item in sources}
    if len(sources) != 6 or actual_pairs != expected_pairs:
        raise ValueError("TM01 source checkpoint population drifted")
    for index, source in enumerate(sources):
        if int(source.get("epoch", -1)) != 30:
            raise ValueError(f"TM01 source {index} epoch drifted")
        _require_sha256(source.get("checkpoint_sha256"), f"sources.{index}.checkpoint_sha256")
        _require_sha256(source.get("config_sha256"), f"sources.{index}.config_sha256")

    bootstrap = contract.get("bootstrap", {})
    if bootstrap != {"unit": "basin", "replicates": 10000, "seed": 20260826}:
        raise ValueError("TM01 bootstrap contract drifted")
    if contract.get("primary_comparisons") != [
        {"candidate": "ties_full", "comparator": "dense_midpoint", "metric": "nse"},
        {"candidate": "ties_full", "comparator": "ties_no_elect", "metric": "nse"},
    ]:
        raise ValueError("TM01 primary comparisons drifted")
    return contract


def canonical_state_dict_sha256(state_dict: StateDict) -> str:
    """Hash tensor names, schemas, and bytes independent of mapping order."""
    digest = hashlib.sha256()
    for name in sorted(state_dict):
        tensor = state_dict[name].detach().cpu().contiguous()
        metadata = {
            "name": name,
            "dtype": str(tensor.dtype),
            "shape": list(tensor.shape),
        }
        encoded = json.dumps(metadata, sort_keys=True, separators=(",", ":")).encode("utf-8")
        digest.update(len(encoded).to_bytes(8, "little"))
        digest.update(encoded)
        raw = tensor.view(torch.uint8).numpy().tobytes(order="C")
        digest.update(len(raw).to_bytes(8, "little"))
        digest.update(raw)
    return digest.hexdigest()


def sha256_file(path: Path) -> str:
    """Return the SHA-256 digest of one file."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def validate_state_dicts(base: StateDict, nse: StateDict, flow_regime: StateDict) -> None:
    """Reject any state dictionaries that cannot be merged coordinate by coordinate."""
    base_keys = list(base)
    if set(nse) != set(base_keys) or set(flow_regime) != set(base_keys):
        raise ValueError("state-dict keys differ")
    for name in base_keys:
        tensors = (base[name], nse[name], flow_regime[name])
        shapes = {tuple(tensor.shape) for tensor in tensors}
        if len(shapes) != 1:
            raise ValueError(f"state-dict shape mismatch for {name}")
        dtypes = {tensor.dtype for tensor in tensors}
        if len(dtypes) != 1:
            raise ValueError(f"state-dict dtype mismatch for {name}")
        if tensors[0].is_floating_point():
            if not all(bool(torch.isfinite(tensor).all().item()) for tensor in tensors):
                raise ValueError(f"state-dict contains non-finite values for {name}")
        elif not (torch.equal(tensors[0], tensors[1]) and torch.equal(tensors[0], tensors[2])):
            raise ValueError(f"non-floating state differs for {name}")


def _floating_names(base: StateDict) -> list[str]:
    return [name for name in base if base[name].is_floating_point()]


def _task_vectors(base: StateDict, endpoint: StateDict, names: list[str]) -> OrderedDict[str, torch.Tensor]:
    return OrderedDict((name, endpoint[name].detach().cpu() - base[name].detach().cpu()) for name in names)


def _flatten(vectors: StateDict, names: list[str]) -> torch.Tensor:
    if not names:
        return torch.empty(0, dtype=torch.float32)
    return torch.cat([vectors[name].reshape(-1) for name in names])


def _exact_top_k_mask(values: torch.Tensor, top_k_percent: int) -> torch.Tensor:
    if top_k_percent <= 0 or top_k_percent > 100:
        raise ValueError("top_k_percent must be in (0, 100]")
    total = int(values.numel())
    if total == 0:
        return torch.zeros_like(values, dtype=torch.bool)
    if top_k_percent == 100:
        return torch.ones_like(values, dtype=torch.bool)
    keep = max(1, int(math.floor(total * top_k_percent / 100.0)))
    order = torch.argsort(values.abs(), descending=True, stable=True)
    mask = torch.zeros(total, dtype=torch.bool, device=values.device)
    mask[order[:keep]] = True
    return mask


def _elect_sign(first: torch.Tensor, second: torch.Tensor) -> torch.Tensor:
    return torch.sign(first + second)


def _disjoint_mean(first: torch.Tensor, second: torch.Tensor, elected: torch.Tensor) -> torch.Tensor:
    stacked = torch.stack((first, second), dim=0)
    aligned = ((elected > 0) & (stacked > 0)) | ((elected < 0) & (stacked < 0))
    selected = torch.where(aligned, stacked, torch.zeros_like(stacked))
    counts = aligned.sum(dim=0)
    return torch.where(counts > 0, selected.sum(dim=0) / counts.clamp_min(1), torch.zeros_like(first))


def _nonzero_mean(first: torch.Tensor, second: torch.Tensor) -> torch.Tensor:
    stacked = torch.stack((first, second), dim=0)
    nonzero = stacked != 0
    counts = nonzero.sum(dim=0)
    return torch.where(counts > 0, stacked.sum(dim=0) / counts.clamp_min(1), torch.zeros_like(first))


def _diluted_disjoint_mean(first: torch.Tensor, second: torch.Tensor, elected: torch.Tensor) -> torch.Tensor:
    stacked = torch.stack((first, second), dim=0)
    aligned = ((elected > 0) & (stacked > 0)) | ((elected < 0) & (stacked < 0))
    selected = torch.where(aligned, stacked, torch.zeros_like(stacked))
    return selected.mean(dim=0)


def _restore_delta(
    base: StateDict,
    names: list[str],
    flat_delta: torch.Tensor,
    scaling_factor: float,
) -> OrderedDict[str, torch.Tensor]:
    result: OrderedDict[str, torch.Tensor] = OrderedDict()
    offset = 0
    for name, base_tensor in base.items():
        if name not in names:
            result[name] = base_tensor.detach().clone()
            continue
        count = base_tensor.numel()
        delta = flat_delta[offset:offset + count].reshape(base_tensor.shape).to(dtype=base_tensor.dtype)
        result[name] = base_tensor.detach().cpu() + float(scaling_factor) * delta
        offset += count
    if offset != int(flat_delta.numel()):
        raise RuntimeError("flat task-vector length did not match state dictionary")
    return result


def merge_state_dicts(
    base: StateDict,
    nse: StateDict,
    flow_regime: StateDict,
    *,
    top_k_percent: int,
    scaling_factor: float,
) -> dict[str, OrderedDict[str, torch.Tensor]]:
    """Construct endpoints, ordinary averaging, full TIES, and component ablations."""
    validate_state_dicts(base, nse, flow_regime)
    if not math.isfinite(float(scaling_factor)) or float(scaling_factor) <= 0.0:
        raise ValueError("scaling_factor must be finite and positive")
    names = _floating_names(base)
    nse_vector = _flatten(_task_vectors(base, nse, names), names)
    flow_vector = _flatten(_task_vectors(base, flow_regime, names), names)
    nse_mask = _exact_top_k_mask(nse_vector, top_k_percent)
    flow_mask = _exact_top_k_mask(flow_vector, top_k_percent)
    trimmed_nse = torch.where(nse_mask, nse_vector, torch.zeros_like(nse_vector))
    trimmed_flow = torch.where(flow_mask, flow_vector, torch.zeros_like(flow_vector))

    dense_mean = 0.5 * (nse_vector + flow_vector)
    dense_elected = _elect_sign(nse_vector, flow_vector)
    trimmed_elected = _elect_sign(trimmed_nse, trimmed_flow)
    deltas = {
        "dense_midpoint": dense_mean,
        "ties_no_trim": _disjoint_mean(nse_vector, flow_vector, dense_elected),
        "ties_no_elect": _nonzero_mean(trimmed_nse, trimmed_flow),
        "ties_no_disjoint": _diluted_disjoint_mean(trimmed_nse, trimmed_flow, trimmed_elected),
        "ties_full": _disjoint_mean(trimmed_nse, trimmed_flow, trimmed_elected),
    }
    result = {
        "endpoint_nse": OrderedDict((name, tensor.detach().cpu().clone()) for name, tensor in nse.items()),
        "endpoint_flow_regime_nse": OrderedDict(
            (name, tensor.detach().cpu().clone()) for name, tensor in flow_regime.items()
        ),
    }
    for method, flat_delta in deltas.items():
        result[method] = _restore_delta(base, names, flat_delta, scaling_factor)
    return {method: result[method] for method in EXPECTED_METHODS}


def _diagnostic_counts(first: torch.Tensor, second: torch.Tensor) -> dict[str, int | float]:
    first_nonzero = first != 0
    second_nonzero = second != 0
    overlap = first_nonzero & second_nonzero
    conflict = overlap & (torch.sign(first) != torch.sign(second))
    first_abs = first.abs()
    second_abs = second.abs()
    first_wins = conflict & (first_abs > second_abs)
    second_wins = conflict & (second_abs > first_abs)
    exact_ties = conflict & (first_abs == second_abs)
    denominator = first_abs + second_abs
    cancellation = torch.where(denominator > 0, 1.0 - (first + second).abs() / denominator, torch.zeros_like(denominator))
    overlap_count = int(overlap.sum().item())
    conflict_count = int(conflict.sum().item())
    return {
        "coordinate_count": int(first.numel()),
        "overlap_count": overlap_count,
        "conflict_count": conflict_count,
        "conflict_fraction_of_overlap": float(conflict_count / overlap_count) if overlap_count else 0.0,
        "conflict_fraction_of_all": float(conflict_count / first.numel()) if first.numel() else 0.0,
        "nse_wins_conflict_count": int(first_wins.sum().item()),
        "flow_regime_nse_wins_conflict_count": int(second_wins.sum().item()),
        "exact_tie_conflict_count": int(exact_ties.sum().item()),
        "nse_only_nonzero_count": int((first_nonzero & ~second_nonzero).sum().item()),
        "flow_regime_nse_only_nonzero_count": int((second_nonzero & ~first_nonzero).sum().item()),
        "mean_cancellation_ratio": float(cancellation.mean().item()),
    }


def task_vector_diagnostics(
    base: StateDict,
    nse: StateDict,
    flow_regime: StateDict,
    *,
    top_k_percent: int,
) -> dict:
    """Return raw and post-trim conflict counts globally and by tensor."""
    validate_state_dicts(base, nse, flow_regime)
    names = _floating_names(base)
    nse_vectors = _task_vectors(base, nse, names)
    flow_vectors = _task_vectors(base, flow_regime, names)
    flat_nse = _flatten(nse_vectors, names)
    flat_flow = _flatten(flow_vectors, names)
    nse_mask = _exact_top_k_mask(flat_nse, top_k_percent)
    flow_mask = _exact_top_k_mask(flat_flow, top_k_percent)
    trimmed_nse = torch.where(nse_mask, flat_nse, torch.zeros_like(flat_nse))
    trimmed_flow = torch.where(flow_mask, flat_flow, torch.zeros_like(flat_flow))

    raw = _diagnostic_counts(flat_nse, flat_flow)
    trimmed = _diagnostic_counts(trimmed_nse, trimmed_flow)
    global_record = {
        "coordinate_count": raw["coordinate_count"],
        "raw_overlap_count": raw["overlap_count"],
        "raw_conflict_count": raw["conflict_count"],
        "raw_conflict_fraction_of_overlap": raw["conflict_fraction_of_overlap"],
        "raw_conflict_fraction_of_all": raw["conflict_fraction_of_all"],
        "post_trim_overlap_count": trimmed["overlap_count"],
        "post_trim_conflict_count": trimmed["conflict_count"],
        "post_trim_conflict_fraction_of_overlap": trimmed["conflict_fraction_of_overlap"],
        "post_trim_conflict_fraction_of_all": trimmed["conflict_fraction_of_all"],
        "nse_wins_conflict_count": trimmed["nse_wins_conflict_count"],
        "flow_regime_nse_wins_conflict_count": trimmed["flow_regime_nse_wins_conflict_count"],
        "exact_tie_conflict_count": trimmed["exact_tie_conflict_count"],
        "nse_only_retained_count": trimmed["nse_only_nonzero_count"],
        "flow_regime_nse_only_retained_count": trimmed["flow_regime_nse_only_nonzero_count"],
        "dense_mean_cancellation_ratio": raw["mean_cancellation_ratio"],
    }

    per_tensor = {}
    offset = 0
    for name in names:
        count = nse_vectors[name].numel()
        per_tensor[name] = {
            "raw": _diagnostic_counts(flat_nse[offset:offset + count], flat_flow[offset:offset + count]),
            "post_trim": _diagnostic_counts(
                trimmed_nse[offset:offset + count], trimmed_flow[offset:offset + count]
            ),
        }
        offset += count
    return {"global": global_record, "per_tensor": per_tensor}


def score_basin(
    observed: np.ndarray,
    simulated: np.ndarray,
    *,
    minimum_paired_days: int = 30,
    high_flow_quantile: float = 0.9,
    low_flow_quantile: float = 0.1,
) -> dict[str, float | int]:
    """Compute the frozen primary metric and descriptive hydrological diagnostics."""
    observed = np.asarray(observed, dtype=np.float64)
    simulated = np.asarray(simulated, dtype=np.float64)
    if observed.shape != simulated.shape or observed.ndim != 1:
        raise ValueError(f"basin series shape mismatch: {observed.shape}, {simulated.shape}")
    valid = np.isfinite(observed) & np.isfinite(simulated)
    if int(valid.sum()) < int(minimum_paired_days):
        raise ValueError(f"fewer than {minimum_paired_days} paired finite days")
    valid_indices = np.flatnonzero(valid)
    observed = observed[valid]
    simulated = simulated[valid]
    observed_mean = float(observed.mean())
    simulated_mean = float(simulated.mean())
    observed_std = float(observed.std())
    simulated_std = float(simulated.std())
    denominator = float(np.sum((observed - observed_mean)**2))
    if denominator <= 0.0 or observed_std <= 0.0 or observed_mean == 0.0:
        raise ValueError("observed series must have positive variance and nonzero mean")
    correlation = float(np.corrcoef(observed, simulated)[0, 1])
    if not math.isfinite(correlation):
        raise ValueError("correlation is non-finite")
    variability_ratio = simulated_std / observed_std
    mean_ratio = simulated_mean / observed_mean
    kge = 1.0 - math.sqrt(
        (correlation - 1.0)**2 + (variability_ratio - 1.0)**2 + (mean_ratio - 1.0)**2
    )
    errors = simulated - observed
    high_threshold = float(np.quantile(observed, high_flow_quantile))
    low_threshold = float(np.quantile(observed, low_flow_quantile))
    high = observed >= high_threshold
    low = observed <= low_threshold
    observed_peak_index = int(np.argmax(observed))
    simulated_peak_index = int(np.argmax(simulated))
    observed_peak = float(observed[observed_peak_index])
    simulated_peak = float(simulated[simulated_peak_index])
    if observed_peak == 0.0:
        raise ValueError("observed peak must be nonzero")
    return {
        "nse": 1.0 - float(np.sum(errors**2)) / denominator,
        "kge": kge,
        "correlation": correlation,
        "variability_ratio": variability_ratio,
        "mean_ratio": mean_ratio,
        "rmse": float(np.sqrt(np.mean(errors**2))),
        "high_flow_mae_q90": float(np.mean(np.abs(errors[high]))),
        "low_flow_mae_q10": float(np.mean(np.abs(errors[low]))),
        "peak_timing_error_days": float(valid_indices[simulated_peak_index] - valid_indices[observed_peak_index]),
        "peak_magnitude_relative_error": (simulated_peak - observed_peak) / observed_peak,
        "paired_day_count": int(valid.sum()),
    }


def paired_basin_bootstrap(values: np.ndarray, *, replicates: int, seed: int) -> tuple[float, float, float]:
    """Return a median basin effect and deterministic percentile interval."""
    finite = np.asarray(values, dtype=np.float64)
    finite = finite[np.isfinite(finite)]
    if finite.size == 0:
        raise ValueError("paired bootstrap received no finite basin effects")
    if int(replicates) <= 0:
        raise ValueError("bootstrap replicates must be positive")
    generator = np.random.default_rng(int(seed))
    medians = np.empty(int(replicates), dtype=np.float64)
    block = 1000
    for start in range(0, int(replicates), block):
        stop = min(start + block, int(replicates))
        indices = generator.integers(0, finite.size, size=(stop - start, finite.size))
        medians[start:stop] = np.median(finite[indices], axis=1)
    lower, upper = np.quantile(medians, [0.025, 0.975])
    return float(np.median(finite)), float(lower), float(upper)


def decide_conflict_resolution_signal(comparisons: pd.DataFrame) -> dict:
    """Apply the frozen full-vs-average and full-vs-no-election primary gate."""
    required = (
        ("ties_full", "dense_midpoint", "nse"),
        ("ties_full", "ties_no_elect", "nse"),
    )
    details = []
    passes = True
    for candidate, comparator, metric in required:
        rows = comparisons[
            (comparisons["candidate"] == candidate)
            & (comparisons["comparator"] == comparator)
            & (comparisons["metric"] == metric)
        ]
        if len(rows) != 1:
            passes = False
            details.append({
                "candidate": candidate,
                "comparator": comparator,
                "passes": False,
                "reason": f"expected one comparison row, found {len(rows)}",
            })
            continue
        row = rows.iloc[0]
        row_passes = float(row["median_difference"]) > 0.0 and float(row["ci_lower"]) > 0.0
        passes = passes and row_passes
        details.append({
            "candidate": candidate,
            "comparator": comparator,
            "passes": bool(row_passes),
            "median_difference": float(row["median_difference"]),
            "ci_lower": float(row["ci_lower"]),
            "ci_upper": float(row["ci_upper"]),
        })
    return {
        "verdict": "CONFLICT_RESOLUTION_SIGNAL" if passes else "NO_CONFLICT_RESOLUTION_SIGNAL",
        "primary_gate_passed": bool(passes),
        "comparisons": details,
    }


def _resolve_repository_path(recorded: str, repository_root: Path) -> Path:
    path = Path(recorded)
    return path if path.is_absolute() else repository_root / path


def _load_checkpoint(path: Path) -> OrderedDict[str, torch.Tensor]:
    try:
        payload = torch.load(path, map_location="cpu", weights_only=True)
    except TypeError:
        payload = torch.load(path, map_location="cpu")
    if not isinstance(payload, Mapping) or not payload:
        raise ValueError(f"checkpoint is not a nonempty state dictionary: {path}")
    if not all(isinstance(name, str) and isinstance(tensor, torch.Tensor) for name, tensor in payload.items()):
        raise ValueError(f"checkpoint contains non-tensor state: {path}")
    return OrderedDict((name, tensor.detach().cpu()) for name, tensor in payload.items())


def _read_yaml_mapping(path: Path) -> dict:
    from ruamel.yaml import YAML

    with Path(path).open("r", encoding="utf-8") as handle:
        payload = YAML(typ="safe").load(handle)
    if not isinstance(payload, dict):
        raise ValueError(f"configuration is not a mapping: {path}")
    return payload


def _assert_same_seed_config_pair(nse_path: Path, flow_path: Path, expected_seed: int) -> None:
    nse = _read_yaml_mapping(nse_path)
    flow = _read_yaml_mapping(flow_path)
    allowed_differences = {
        "experiment_name",
        "img_log_dir",
        "loss",
        "run_dir",
        "train_dir",
    }
    if int(nse.get("seed", -1)) != expected_seed or int(flow.get("seed", -1)) != expected_seed:
        raise ValueError(f"same-seed source pair does not use seed {expected_seed}")
    nse_loss = nse.get("loss")
    flow_loss = flow.get("loss")
    if nse_loss != "BasinAverageNSE" or flow_loss != "BasinAverageFlowRegimeNSE":
        raise ValueError(f"source losses drifted for seed {expected_seed}: {nse_loss!r}, {flow_loss!r}")
    for key in allowed_differences:
        nse.pop(key, None)
        flow.pop(key, None)
    if nse != flow:
        differing = sorted(key for key in set(nse) | set(flow) if nse.get(key) != flow.get(key))
        raise ValueError(f"same-seed source configurations differ outside allowed fields: {differing}")


def reconstruct_base_state(config_path: Path, seed: int) -> OrderedDict[str, torch.Tensor]:
    """Reconstruct the recorded initialization without opening hydrological data."""
    from neuralhydrology.modelzoo import get_model
    from neuralhydrology.utils.config import Config

    config = Config(config_path)
    if int(config.seed) != int(seed):
        raise ValueError(f"configuration seed {config.seed} differs from requested seed {seed}")
    random.seed(seed)
    np.random.seed(seed)
    torch.cuda.manual_seed(seed)
    torch.manual_seed(seed)
    model = get_model(config)
    return OrderedDict((name, tensor.detach().cpu().clone()) for name, tensor in model.state_dict().items())


def _schema_record(state_dict: StateDict) -> dict:
    schema = [
        {
            "name": name,
            "shape": list(tensor.shape),
            "dtype": str(tensor.dtype),
            "parameter_count": int(tensor.numel()),
        }
        for name, tensor in state_dict.items()
    ]
    encoded = json.dumps(schema, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return {
        "tensor_count": len(schema),
        "parameter_count": sum(item["parameter_count"] for item in schema),
        "schema_sha256": hashlib.sha256(encoded).hexdigest(),
        "tensors": schema,
    }


def _atomic_write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def run_parameter_audit(
    contract_path: Path,
    output_directory: Path,
    *,
    repository_root: Path = REPOSITORY_ROOT,
    write_base_checkpoints: bool = False,
) -> dict:
    """Audit sources, reconstruct bases, and execute all merge methods without hydrological data."""
    contract_path = Path(contract_path)
    output_directory = Path(output_directory)
    if output_directory.exists():
        raise FileExistsError(f"parameter-audit output already exists: {output_directory}")
    contract = load_contract(contract_path)

    metadata_paths = {
        "contract": contract_path,
        "basin_file": _resolve_repository_path(contract["basin_file"], repository_root),
        "safe_manifest": _resolve_repository_path(contract["safe_data"]["manifest"], repository_root),
        "scaler": _resolve_repository_path(contract["scaler"]["path"], repository_root),
    }
    expected_metadata_hashes = {
        "basin_file": contract["basin_file_sha256"],
        "safe_manifest": contract["safe_data"]["manifest_sha256"],
        "scaler": contract["scaler"]["sha256"],
    }
    metadata_hashes = {name: sha256_file(path) for name, path in metadata_paths.items()}
    for name, expected in expected_metadata_hashes.items():
        if metadata_hashes[name] != expected:
            raise ValueError(f"{name} SHA-256 mismatch")

    sources = {}
    for source in contract["sources"]:
        key = (source["objective"], int(source["seed"]))
        checkpoint_path = _resolve_repository_path(source["checkpoint"], repository_root)
        config_path = _resolve_repository_path(source["config"], repository_root)
        if sha256_file(checkpoint_path) != source["checkpoint_sha256"]:
            raise ValueError(f"checkpoint SHA-256 mismatch for {key}")
        if sha256_file(config_path) != source["config_sha256"]:
            raise ValueError(f"config SHA-256 mismatch for {key}")
        sources[key] = {
            "checkpoint_path": checkpoint_path,
            "config_path": config_path,
            "state": _load_checkpoint(checkpoint_path),
            "checkpoint_sha256": source["checkpoint_sha256"],
            "config_sha256": source["config_sha256"],
        }

    seed_records = []
    reconstructed_bases: dict[int, OrderedDict[str, torch.Tensor]] = {}
    for seed in EXPECTED_SEEDS:
        nse_source = sources[("nse", seed)]
        flow_source = sources[("flow_regime_nse", seed)]
        _assert_same_seed_config_pair(nse_source["config_path"], flow_source["config_path"], seed)
        base_from_nse = reconstruct_base_state(nse_source["config_path"], seed)
        base_from_flow = reconstruct_base_state(flow_source["config_path"], seed)
        nse_base_hash = canonical_state_dict_sha256(base_from_nse)
        flow_base_hash = canonical_state_dict_sha256(base_from_flow)
        expected_base_hash = contract["base_reconstruction"]["expected_state_dict_sha256"][str(seed)]
        if nse_base_hash != flow_base_hash or nse_base_hash != expected_base_hash:
            raise ValueError(
                f"reconstructed base mismatch for seed {seed}: "
                f"nse={nse_base_hash}, flow={flow_base_hash}, expected={expected_base_hash}"
            )
        validate_state_dicts(base_from_nse, nse_source["state"], flow_source["state"])
        schema = _schema_record(base_from_nse)
        if schema["tensor_count"] != 6 or schema["parameter_count"] != 297217:
            raise ValueError(f"unexpected CudaLSTM schema for seed {seed}: {schema}")
        diagnostics = task_vector_diagnostics(
            base_from_nse,
            nse_source["state"],
            flow_source["state"],
            top_k_percent=contract["merge"]["top_k_percent"],
        )
        if diagnostics["global"]["post_trim_conflict_count"] <= 0:
            raise ValueError(f"seed {seed} has no post-trim sign conflicts to resolve")
        merged = merge_state_dicts(
            base_from_nse,
            nse_source["state"],
            flow_source["state"],
            top_k_percent=contract["merge"]["top_k_percent"],
            scaling_factor=contract["merge"]["scaling_factor"],
        )
        merged_hashes = {method: canonical_state_dict_sha256(state) for method, state in merged.items()}
        if write_base_checkpoints:
            reconstructed_bases[seed] = base_from_nse
        seed_records.append({
            "seed": seed,
            "base_provenance": contract["base_reconstruction"]["provenance"],
            "reconstructed_base_state_dict_sha256": nse_base_hash,
            "nse_checkpoint_sha256": nse_source["checkpoint_sha256"],
            "flow_regime_nse_checkpoint_sha256": flow_source["checkpoint_sha256"],
            "schema": schema,
            "diagnostics": diagnostics,
            "merged_state_dict_sha256": merged_hashes,
        })

    result = {
        "experiment_id": EXPERIMENT_ID,
        "status": "PARAMETER_AUDIT_PASS",
        "scientific_data_opened": False,
        "base_provenance": contract["base_reconstruction"]["provenance"],
        "contract_sha256": metadata_hashes["contract"],
        "metadata_hashes": {name: digest for name, digest in metadata_hashes.items() if name != "contract"},
        "environment": {
            "python": sys.version.split()[0],
            "pytorch": torch.__version__,
            "numpy": np.__version__,
            "platform": platform.platform(),
            "cuda_available": bool(torch.cuda.is_available()),
            "cuda_version": torch.version.cuda,
            "process_id": os.getpid(),
        },
        "seed_records": seed_records,
    }
    output_directory.mkdir(parents=True, exist_ok=False)
    if write_base_checkpoints:
        base_directory = output_directory / "reconstructed_bases"
        base_directory.mkdir()
        for seed, state in reconstructed_bases.items():
            base_path = base_directory / f"reconstructed_base_s{seed}.pt"
            torch.save(state, base_path)
            saved = _load_checkpoint(base_path)
            expected = contract["base_reconstruction"]["expected_state_dict_sha256"][str(seed)]
            if canonical_state_dict_sha256(saved) != expected:
                raise RuntimeError(f"saved reconstructed base failed verification for seed {seed}")
    _atomic_write_json(output_directory / "parameter_audit.json", result)
    return result


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--contract", type=Path, default=DEFAULT_CONTRACT_PATH)
    parser.add_argument("--parameter-audit-only", action="store_true")
    parser.add_argument("--output-directory", type=Path, required=True)
    parser.add_argument("--write-base-checkpoints", action="store_true")
    return parser


def main(argv=None) -> int:
    args = _build_parser().parse_args(argv)
    if not args.parameter_audit_only:
        raise ValueError("hydrological execution is not enabled in this entry point yet")
    result = run_parameter_audit(
        args.contract,
        args.output_directory,
        write_base_checkpoints=args.write_base_checkpoints,
    )
    print(json.dumps({
        "experiment_id": result["experiment_id"],
        "status": result["status"],
        "scientific_data_opened": result["scientific_data_opened"],
        "seed_count": len(result["seed_records"]),
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
