"""Tests for the ID18 sign-aware task-vector merge development screen."""

from __future__ import annotations

import hashlib
import json
from collections import OrderedDict
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import torch

from src.lstm_fair_531.scripts.run_tm01_sign_aware_task_vector_merge import (
    EXPECTED_METHODS,
    canonical_state_dict_sha256,
    decide_conflict_resolution_signal,
    load_contract,
    merge_state_dicts,
    paired_basin_bootstrap,
    score_basin,
    task_vector_diagnostics,
    validate_state_dicts,
)
from src.lstm_fair_531.scripts.execute_tm01_hpc_screen import verify_execution_data_root


CONTRACT_PATH = Path(
    "src/lstm_fair_531/configs/tm01_reconstructed_base_sign_aware_merge_screen_20260826.json"
)
SLURM_PATH = Path("src/lstm_fair_531/hpc/submit_tm01_sign_aware_task_vector_merge.slurm")


def _state(values: list[float]) -> OrderedDict[str, torch.Tensor]:
    return OrderedDict(weight=torch.tensor(values, dtype=torch.float32))


def test_contract_freezes_real_conflict_resolution_and_safe_boundary():
    contract = load_contract(CONTRACT_PATH)
    assert contract["experiment_id"] == "TM01_reconstructed_base_sign_aware_merge_screen_20260826"
    assert contract["seeds"] == [100, 200, 300]
    assert contract["source_epoch"] == 30
    assert contract["source_objectives"] == ["nse", "flow_regime_nse"]
    assert contract["merge"]["top_k_percent"] == 20
    assert contract["merge"]["scaling_factor"] == 1.0
    assert contract["methods"] == list(EXPECTED_METHODS)
    assert contract["development_period"] == {"start": "2005-10-01", "end": "2008-09-30"}
    assert contract["sealed_period"] == {"start": "1989-10-01", "end": "1999-09-30"}
    assert contract["expected_basin_count"] == 24
    assert contract["safe_data"]["manifest_sha256"] == (
        "96bc30d6c6ff0771fb6d5d2585bffdc33e2ed1988572d9f3b22c14a28e679d6e"
    )
    assert contract["safe_data"]["execution_excluded_files"] == [
        "camels_attributes_v2.0/camels_hydro.txt"
    ]
    assert contract["base_reconstruction"]["provenance"] == "RECONSTRUCTED_NOT_SAVED"
    assert contract["base_reconstruction"]["training_commit"] == "9aa9d1ce"
    assert len(contract["sources"]) == 6
    assert all(len(item["checkpoint_sha256"]) == 64 for item in contract["sources"])


def test_validate_state_dicts_rejects_schema_and_nonfinite_drift():
    base = _state([0.0, 0.0])
    nse = _state([1.0, 2.0])
    flow = _state([3.0, 4.0])
    validate_state_dicts(base, nse, flow)

    with pytest.raises(ValueError, match="keys"):
        validate_state_dicts(base, nse, OrderedDict(other=flow["weight"]))
    with pytest.raises(ValueError, match="shape"):
        validate_state_dicts(base, nse, _state([3.0]))
    with pytest.raises(ValueError, match="dtype"):
        validate_state_dicts(base, nse, OrderedDict(weight=flow["weight"].double()))
    with pytest.raises(ValueError, match="non-finite"):
        validate_state_dicts(base, nse, _state([float("nan"), 4.0]))


def test_full_merge_resolves_conflicts_and_exact_tie_returns_to_base():
    # Coordinates cover: same positive sign, unequal conflict, exact tie,
    # one-sided update after trimming, and same negative sign.
    base = _state([10.0, 10.0, 10.0, 10.0, 10.0])
    nse = _state([12.0, 14.0, 13.0, 10.0, 8.0])
    flow = _state([11.0, 9.0, 7.0, 15.0, 6.0])
    merged = merge_state_dicts(base, nse, flow, top_k_percent=100, scaling_factor=1.0)

    torch.testing.assert_close(merged["endpoint_nse"]["weight"], nse["weight"])
    torch.testing.assert_close(merged["endpoint_flow_regime_nse"]["weight"], flow["weight"])
    torch.testing.assert_close(merged["dense_midpoint"]["weight"], torch.tensor([11.5, 11.5, 10.0, 12.5, 7.0]))
    # Full conflict resolution selects the larger-magnitude direction at index 1,
    # returns to base for the exact tie at index 2, and keeps same-sign means.
    torch.testing.assert_close(merged["ties_full"]["weight"], torch.tensor([11.5, 14.0, 10.0, 15.0, 7.0]))
    # Removing sign election permits cancellation at both conflicting coordinates.
    torch.testing.assert_close(merged["ties_no_elect"]["weight"], torch.tensor([11.5, 11.5, 10.0, 15.0, 7.0]))


def test_trimming_is_global_exact_and_no_disjoint_retains_dilution():
    base = OrderedDict(
        first=torch.zeros(3, dtype=torch.float32),
        second=torch.zeros(2, dtype=torch.float32),
    )
    nse = OrderedDict(
        first=torch.tensor([10.0, 1.0, 0.5]),
        second=torch.tensor([0.25, 0.1]),
    )
    flow = OrderedDict(
        first=torch.tensor([-9.0, 0.9, 0.4]),
        second=torch.tensor([0.2, 0.05]),
    )
    merged = merge_state_dicts(base, nse, flow, top_k_percent=20, scaling_factor=1.0)
    # Five coordinates per task and floor(20%) retain exactly one update per task.
    torch.testing.assert_close(merged["ties_full"]["first"], torch.tensor([10.0, 0.0, 0.0]))
    torch.testing.assert_close(merged["ties_no_disjoint"]["first"], torch.tensor([5.0, 0.0, 0.0]))
    assert torch.count_nonzero(merged["ties_full"]["second"]) == 0


def test_diagnostics_measure_nonempty_sign_conflict_and_are_deterministic():
    base = _state([0.0, 0.0, 0.0, 0.0])
    nse = _state([4.0, 3.0, 2.0, 1.0])
    flow = _state([-5.0, -3.0, 2.0, 0.5])
    first = task_vector_diagnostics(base, nse, flow, top_k_percent=100)
    second = task_vector_diagnostics(base, nse, flow, top_k_percent=100)
    assert first == second
    assert first["global"]["raw_overlap_count"] == 4
    assert first["global"]["raw_conflict_count"] == 2
    assert first["global"]["post_trim_conflict_count"] == 2
    assert first["global"]["nse_wins_conflict_count"] == 0
    assert first["global"]["flow_regime_nse_wins_conflict_count"] == 1
    assert first["global"]["exact_tie_conflict_count"] == 1


def test_state_dict_hash_is_content_and_order_stable():
    first = OrderedDict(a=torch.tensor([1.0]), b=torch.tensor([2.0]))
    reordered = OrderedDict(b=torch.tensor([2.0]), a=torch.tensor([1.0]))
    changed = OrderedDict(a=torch.tensor([1.0]), b=torch.tensor([3.0]))
    assert canonical_state_dict_sha256(first) == canonical_state_dict_sha256(reordered)
    assert canonical_state_dict_sha256(first) != canonical_state_dict_sha256(changed)


def test_score_basin_returns_complete_perfect_prediction_diagnostics():
    observed = np.arange(1.0, 101.0)
    result = score_basin(observed, observed.copy())
    assert result["nse"] == pytest.approx(1.0)
    assert result["kge"] == pytest.approx(1.0)
    assert result["correlation"] == pytest.approx(1.0)
    assert result["variability_ratio"] == pytest.approx(1.0)
    assert result["mean_ratio"] == pytest.approx(1.0)
    assert result["rmse"] == pytest.approx(0.0)
    assert result["high_flow_mae_q90"] == pytest.approx(0.0)
    assert result["low_flow_mae_q10"] == pytest.approx(0.0)
    assert result["peak_timing_error_days"] == pytest.approx(0.0)
    assert result["peak_magnitude_relative_error"] == pytest.approx(0.0)


def test_peak_timing_uses_calendar_positions_across_missing_values():
    observed = np.linspace(1.0, 40.0, 40)
    simulated = observed.copy()
    observed[20] = 100.0
    simulated[20] = 10.0
    simulated[23] = 100.0
    observed[21] = np.nan
    simulated[21] = np.nan
    result = score_basin(observed, simulated)
    assert result["peak_timing_error_days"] == pytest.approx(3.0)


def test_bootstrap_and_conflict_resolution_gate_are_frozen():
    values = np.full(24, 0.02)
    assert paired_basin_bootstrap(values, replicates=1000, seed=20260826) == pytest.approx((0.02, 0.02, 0.02))
    comparisons = pd.DataFrame([
        {
            "candidate": "ties_full",
            "comparator": "dense_midpoint",
            "metric": "nse",
            "median_difference": 0.02,
            "ci_lower": 0.01,
            "ci_upper": 0.03,
        },
        {
            "candidate": "ties_full",
            "comparator": "ties_no_elect",
            "metric": "nse",
            "median_difference": 0.01,
            "ci_lower": 0.001,
            "ci_upper": 0.02,
        },
    ])
    assert decide_conflict_resolution_signal(comparisons)["verdict"] == "CONFLICT_RESOLUTION_SIGNAL"
    comparisons.loc[1, "ci_lower"] = 0.0
    assert decide_conflict_resolution_signal(comparisons)["verdict"] == "NO_CONFLICT_RESOLUTION_SIGNAL"


def test_execution_data_guard_rejects_excluded_or_extra_files(tmp_path):
    data_root = tmp_path / "data" / "camels_us_id18_20000105_20080930"
    attribute_path = data_root / "camels_attributes_v2.0" / "camels_name.txt"
    attribute_path.parent.mkdir(parents=True)
    attribute_path.write_text("safe synthetic attribute\n", encoding="utf-8")
    digest = hashlib.sha256(attribute_path.read_bytes()).hexdigest()
    manifest = {
        "basins": ["01022500"],
        "time_series_start": "2000-01-05",
        "time_series_end": "2008-09-30",
        "time_series_day_count": 3192,
        "sealed_paper_evaluation_values_in_output": False,
        "files": [{"path": "camels_attributes_v2.0/camels_name.txt", "sha256": digest, "row_count": 1}],
    }
    manifest_path = data_root / "ID18_RESTRICTED_DATA_MANIFEST.json"
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    contract = {
        "expected_basin_count": 1,
        "safe_data": {
            "root": "data/camels_us_id18_20000105_20080930",
            "manifest": "data/camels_us_id18_20000105_20080930/ID18_RESTRICTED_DATA_MANIFEST.json",
            "manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
            "physical_start": "2000-01-05",
            "physical_end": "2008-09-30",
            "execution_excluded_files": ["camels_attributes_v2.0/camels_hydro.txt"],
        },
    }
    assert verify_execution_data_root(contract, tmp_path)["verified_file_count"] == 1
    excluded = data_root / "camels_attributes_v2.0" / "camels_hydro.txt"
    excluded.write_text("must never be opened\n", encoding="utf-8")
    with pytest.raises(ValueError, match="excluded hydrological-signature file"):
        verify_execution_data_root(contract, tmp_path)
    excluded.unlink()
    (data_root / "unexpected.txt").write_text("extra\n", encoding="utf-8")
    with pytest.raises(ValueError, match="file set drifted"):
        verify_execution_data_root(contract, tmp_path)


def test_slurm_contract_requires_gpu_isolation_and_fail_closed_guards():
    text = SLURM_PATH.read_text(encoding="utf-8")
    assert "#SBATCH -p hgpu2p" in text
    assert "#SBATCH -N 1" in text
    assert "#SBATCH -n 1" in text
    assert "#SBATCH --cpus-per-task=4" in text
    assert "#SBATCH --gres=gpu:1" in text
    assert "#SBATCH --exclude=ngu002" in text
    assert "#SBATCH -t 01:00:00" in text
    assert "#SBATCH --mem" not in text
    assert "set -eo pipefail" in text
    assert "set -u" not in text
    assert "conda activate nh_final" in text
    assert "MKL_THREADING_LAYER=GNU" in text
    assert "MKL_SERVICE_FORCE_INTEL=1" in text
    assert "CUDA_NOT_AVAILABLE" in text
    assert "python -u -X utf8 -m src.lstm_fair_531.scripts.execute_tm01_hpc_screen" in text
