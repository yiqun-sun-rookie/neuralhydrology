"""Independent structural verification for the authorized precheck and probe."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
import math
from pathlib import Path
import sys
from typing import Any, Mapping
import zipfile

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
for _extra in (str(ROOT), str(ROOT / "src"), str(ROOT / "hpc")):
    if _extra not in sys.path:
        sys.path.insert(0, _extra)

import tukf09_455_scaled_noise_common_v1 as common  # noqa: E402


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _sha256_file(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as handle:
        while True:
            block = handle.read(1024 * 1024)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def _json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"), parse_constant=lambda token: (_ for _ in ()).throw(ValueError(token)))
    if not isinstance(value, dict):
        raise ValueError(f"JSON root is not an object: {path}")
    return value


def _verify_manifest(root: Path, *, expected_schema: str, expected_status: str) -> dict[str, Any]:
    manifest = _json(root / "manifest.final.sha256.json")
    if (
        manifest.get("schema_version") != expected_schema
        or manifest.get("experiment_id") != common.EXPERIMENT_ID
        or manifest.get("status") != expected_status
    ):
        raise RuntimeError(f"manifest identity or status changed: {root}")
    files = manifest.get("files")
    if not isinstance(files, dict) or int(manifest.get("file_count", -1)) != len(files):
        raise RuntimeError(f"manifest count changed: {root}")
    actual = {
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_file() and path.name != "manifest.final.sha256.json"
    }
    if set(files) != actual:
        raise RuntimeError(f"manifest member set changed: {root}")
    for relative, record in files.items():
        path = root / relative
        if path.is_symlink() or not path.is_file():
            raise RuntimeError(f"manifest member is linked or missing: {path}")
        if path.stat().st_size != int(record["size_bytes"]) or _sha256_file(path) != record["sha256"]:
            raise RuntimeError(f"manifest member hash changed: {path}")
    return manifest


def _independent_population() -> tuple[tuple[str, ...], dict[str, int]]:
    population_path = (
        ROOT
        / "artifacts"
        / "tukf09_455_basin_zero_validation_target_variance_revision_v1"
        / "preflight"
        / "population_registry.json"
    )
    parameter_path = population_path.parent / "parameters_only.npz"
    population = _json(population_path)
    basin_ids = tuple(str(value) for value in population["eligible"])
    with np.load(parameter_path, allow_pickle=False) as archive:
        parameter_basins = tuple(str(value) for value in archive["basin_ids"].tolist())
        names = tuple(str(value) for value in archive["parameter_names"].tolist())
        values = np.asarray(archive["values"], dtype=np.float64)
    if basin_ids != parameter_basins or values.shape != (455, 13):
        raise RuntimeError("independent population and parameters do not align")
    try:
        lag_column = names.index("lag_time")
    except ValueError as exc:
        raise RuntimeError("independent parameter snapshot lacks lag_time") from exc
    dimensions = {
        basin_id: 5 + max(1, math.ceil(float(values[index, lag_column])))
        for index, basin_id in enumerate(basin_ids)
    }
    order_hash = sha256("".join(f"{value}\n" for value in basin_ids).encode("utf-8")).hexdigest()
    if order_hash != "38987bce45fa38ff68f5b067db17e8cb3212d98fecdd106f57d268a130ee8fbd":
        raise RuntimeError("independent basin order hash changed")
    return basin_ids, dimensions


def verify_donor_precheck_independently() -> dict[str, Any]:
    root = common.RESULTS_ROOT / "control" / "donor_precheck_v1"
    _verify_manifest(
        root,
        expected_schema="tukf09_455_scaled_noise_donor_precheck_manifest_v1",
        expected_status="METADATA_ONLY_DONOR_PRECHECK_SEALED_PASS",
    )
    registry = _json(root / "donor_registry.json")
    basin_ids, dimensions = _independent_population()
    receivers = registry.get("receivers")
    if not isinstance(receivers, dict) or tuple(receivers) != basin_ids:
        raise RuntimeError("donor registry receiver order changed")
    coordinate_count = 0
    donor_reference_count = 0
    minimum = 455
    for receiver in basin_ids:
        record = receivers[receiver]
        dimension = dimensions[receiver]
        if int(record["state_dimension"]) != dimension:
            raise RuntimeError(f"donor registry state dimension changed for {receiver}")
        coordinates = record["coordinates"]
        if len(coordinates) != dimension:
            raise RuntimeError(f"donor registry coordinate count changed for {receiver}")
        for state_index, coordinate in enumerate(coordinates):
            if int(coordinate["state_index"]) != state_index:
                raise RuntimeError("donor registry state order changed")
            if state_index < 5:
                expected = tuple(value for value in basin_ids if value != receiver)
            else:
                expected = tuple(
                    value
                    for value in basin_ids
                    if value != receiver and dimensions[value] > state_index
                )
            actual = tuple(str(value) for value in coordinate["donors"])
            if actual != expected or int(coordinate["donor_count"]) != len(expected):
                raise RuntimeError(f"donor list changed for {receiver} state {state_index}")
            coordinate_count += 1
            donor_reference_count += len(actual)
            minimum = min(minimum, len(actual))
    if minimum != 13:
        raise RuntimeError("independent minimum donor count changed")
    return {
        "receiver_count": len(basin_ids),
        "coordinate_count": coordinate_count,
        "donor_reference_count": donor_reference_count,
        "minimum_donor_count": minimum,
        "mismatch_count": 0,
    }


def _npz(path: Path) -> dict[str, np.ndarray]:
    if not zipfile.is_zipfile(path):
        raise RuntimeError(f"probe array archive is not ZIP: {path}")
    with np.load(path, allow_pickle=False) as archive:
        return {name: np.asarray(archive[name]).copy() for name in archive.files}


def verify_probe_independently() -> dict[str, Any]:
    root = common.RESULTS_ROOT / "technical_probe_v1"
    _verify_manifest(
        root,
        expected_schema="tukf09_455_scaled_noise_technical_probe_manifest_v1",
        expected_status="TECHNICAL_PROBE_SEALED_PASS_FORMAL_EXPERIMENT_HOLD",
    )
    summary = _json(root / "probe_summary.json")
    if (
        summary.get("probe_id") != common.PROBE_ID
        or summary.get("scientific_result") is not False
        or int(summary.get("evaluation_access_count", -1)) != 0
        or int(summary.get("formal_state_scale_generation_count", -1)) != 0
        or int(summary.get("formal_local_selection_count", -1)) != 0
    ):
        raise RuntimeError("technical probe summary scope changed")
    expected = {"01047000": 7, "01142500": 20}
    basin_results: dict[str, Any] = {}
    for basin_id, dimension in expected.items():
        basin_root = root / f"basin_{basin_id}"
        basin_summary = _json(basin_root / "probe_summary.json")
        arrays = _npz(basin_root / "probe_arrays.npz")
        required = {
            "dates_ns",
            "initial_state",
            "deterministic_training_trajectory",
            "state_scale",
            "floor_hit",
            "theta_before",
            "theta_after",
            "gradient",
            "process_variance_before",
            "process_variance_after",
            "rho_before",
            "rho_after",
        }
        if set(arrays) != required:
            raise RuntimeError(f"technical probe arrays changed for {basin_id}")
        trajectory = np.asarray(arrays["deterministic_training_trajectory"], dtype=np.float64)
        scale = np.asarray(arrays["state_scale"], dtype=np.float64)
        floor_hit = np.asarray(arrays["floor_hit"], dtype=np.bool_)
        if trajectory.shape != (2557, dimension) or scale.shape != (dimension,):
            raise RuntimeError(f"technical probe array shape changed for {basin_id}")
        independent_raw = np.sqrt(
            np.mean(np.square(trajectory[365:2557]), axis=0, dtype=np.float64)
        )
        independent_scale = np.maximum(independent_raw, 0.01)
        if not np.array_equal(scale, independent_scale) or not np.array_equal(
            floor_hit, independent_raw <= 0.01
        ):
            raise RuntimeError(f"technical probe state scale mismatch for {basin_id}")
        for suffix in ("before", "after"):
            theta = np.asarray(arrays[f"theta_{suffix}"], dtype=np.float64)
            q = np.asarray(arrays[f"process_variance_{suffix}"], dtype=np.float64)
            rho = np.asarray(arrays[f"rho_{suffix}"], dtype=np.float64)
            if not np.allclose(q, np.exp(theta), rtol=0.0, atol=0.0):
                raise RuntimeError(f"technical probe q/theta mismatch for {basin_id}")
            restored = np.sqrt(q) / scale
            if not np.allclose(rho, restored, rtol=0.0, atol=1e-12):
                raise RuntimeError(f"technical probe rho/q mismatch for {basin_id}")
            if np.any(rho < 1e-4) or np.any(rho > 1.0):
                raise RuntimeError(f"technical probe rho bounds mismatch for {basin_id}")
        if (
            basin_summary.get("scientific_result") is not False
            or int(basin_summary.get("evaluation_access_count", -1)) != 0
            or int(basin_summary["optimization"]["adam_updates"]) != 1
            or int(basin_summary["optimization"]["training_objective_calls"]) != 2
            or int(basin_summary["optimization"]["validation_objective_calls"]) != 2
        ):
            raise RuntimeError(f"technical probe basin scope changed for {basin_id}")
        basin_results[basin_id] = {
            "state_dimension": dimension,
            "scale_max_abs_difference": float(np.max(np.abs(scale - independent_scale))),
            "rho_round_trip_max_abs_difference": float(
                max(
                    np.max(np.abs(arrays["rho_before"] - np.sqrt(arrays["process_variance_before"]) / scale)),
                    np.max(np.abs(arrays["rho_after"] - np.sqrt(arrays["process_variance_after"]) / scale)),
                )
            ),
        }
    actual_counts = summary["actual_counts"]
    if actual_counts != {
        "adam_updates": 2,
        "basins": 2,
        "deterministic_basin_day_steps": 5114,
        "evaluation_array_reads": 0,
        "training_objective_calls": 4,
        "validation_objective_calls": 4,
    }:
        raise RuntimeError("technical probe total counts changed")
    if (
        float(summary["total_wall_seconds"])
        > float(summary["resource_limits"]["wall_seconds"])
        or int(summary["peak_process_rss_bytes"])
        > int(summary["resource_limits"]["maximum_process_rss_bytes"])
    ):
        raise RuntimeError("technical probe exceeded its frozen resource cap")
    return {
        "probe_id": common.PROBE_ID,
        "basin_count": 2,
        "basins": basin_results,
        "evaluation_access_count": 0,
        "mismatch_count": 0,
    }


def verify_current_authorized_evidence() -> dict[str, Any]:
    common.load_execution_authorization()
    common.load_implementation_admission()
    common.require_formal_execution_denied()
    donor = verify_donor_precheck_independently()
    probe = verify_probe_independently()
    result = {
        "schema_version": "tukf09_455_scaled_noise_authorized_evidence_verification_v1",
        "experiment_id": common.EXPERIMENT_ID,
        "status": "AUTHORIZED_IMPLEMENTATION_DONOR_PRECHECK_AND_PROBE_VERIFIED_FORMAL_HOLD",
        "verified_at_utc": _utc_now(),
        "donor_precheck": donor,
        "technical_probe": probe,
        "evaluation_access_count": 0,
        "scientific_result_verified": False,
        "formal_experiment_authorized": False,
        "mismatch_count": 0,
    }
    output = common.ensure_allowed_results_path(
        common.RESULTS_ROOT / "control" / "tests_v1" / "current_evidence_verification.json",
        "control/tests_v1",
    )
    common.atomic_write_json_exclusive(output, result)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--mode",
        required=True,
        choices=("verify-current-authorized-evidence", "formal-independent-replay"),
    )
    args = parser.parse_args()
    if args.mode == "formal-independent-replay":
        common.load_execution_authorization()
        common.require_formal_execution_denied()
        raise PermissionError("independent formal-result replay is not authorized")
    result = verify_current_authorized_evidence()
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
