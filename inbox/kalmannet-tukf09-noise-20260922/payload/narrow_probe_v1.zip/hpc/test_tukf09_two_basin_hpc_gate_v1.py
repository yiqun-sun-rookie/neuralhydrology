"""No real model or scientific input data used by these negative tests."""
import json
import os
from pathlib import Path
import pytest
import tukf09_two_basin_hpc_gate_v1 as gate
from tukf09_two_basin_hpc_gate_v1 import checked_path, mapped_relative, read_json, verify_bundle

@pytest.mark.parametrize('name',['../escape','/absolute','a/../b','a\\b','G:/escape','a//b'])
def test_bad_paths(tmp_path,name):
    with pytest.raises((ValueError,FileNotFoundError)):
        checked_path(tmp_path,name)

def test_windows_mapping():
    assert mapped_relative('G:/github/pycharm/projects/kalmannet/scripts/a.py') == 'scripts/a.py'
    with pytest.raises(ValueError):
        mapped_relative('G:/github/pycharm/projects/other/scripts/a.py')
    with pytest.raises(ValueError):
        mapped_relative('G:/github/pycharm/projects/kalmannet/../a.py')

def test_wrong_root(tmp_path):
    with pytest.raises(PermissionError):
        verify_bundle(tmp_path,'0'*64)

def test_manifest_tamper(tmp_path):
    (tmp_path/'bundle_manifest.json').write_text('{}')
    with pytest.raises(RuntimeError,match='fingerprint'):
        verify_bundle(tmp_path,'0'*64,enforce_remote=False)

@pytest.mark.parametrize('text',['{"x":1,"x":2}','{"x":NaN}','[]'])
def test_json_rejection(tmp_path,text):
    file = tmp_path/'bad.json'
    file.write_text(text)
    with pytest.raises(ValueError):
        read_json(file)

def test_remote_mapping_is_posix_on_every_platform():
    assert gate.REMOTE_ROOT_POSIX.startswith('/data1/')
    assert '\\' not in gate.REMOTE_ROOT_POSIX
    assert gate.REMOTE_ROOT_POSIX == gate.PurePosixPath(gate.REMOTE_ROOT_POSIX).as_posix()

@pytest.fixture
def bundle(tmp_path, monkeypatch):
    root = tmp_path / 'bundle'
    root.mkdir()
    def put(name, value):
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value) if not isinstance(value, str) else value)
        return path
    science_name = gate.SCIENCE
    parent_name = 'input/parent.json'
    monkeypatch.setattr(gate, 'PARENT', parent_name)
    semantics_name = 'input/semantic.json'
    seal_name = 'input/seal.json'
    registry_name = 'input/registry.json'
    put(seal_name, 'seal')
    put(registry_name, 'registry')
    semantics = {f'{basin}/{period}/{field}': f'{basin}-{period}-{field}'
                 for basin, _ in gate.SAMPLES for period in ('training', 'validation')
                 for field in ('dates_ns', 'forcing', 'observations')}
    put(semantics_name, {'members': semantics})
    def binding(name):
        return {'path': name, **gate.file_record(root/name)}
    science = {'lineage': {'input_seals': {'semantic_input_manifest': binding(semantics_name)},
              'parent_scientific_contract': binding(seal_name),
              'completed_parent_evidence': {'filter_registry': binding(registry_name)}}}
    put(science_name, science)
    monkeypatch.setattr(gate, 'SCIENCE_SHA', gate.digest(root/science_name))
    sources = {}
    bindings = {}
    for number in range(13):
        name = f'hpc/synthetic_source_{number}.py'
        put(name, f'# synthetic {number}')
        sources[name] = gate.digest(root/name)
        bindings[name] = {'path': str(gate.WINDOWS_ROOT / name), **gate.file_record(root/name)}
    put(parent_name, {'production_source_sha256': sources, 'bindings': bindings})
    monkeypatch.setattr(gate, 'PARENT_SHA', gate.digest(root/parent_name))
    put('input/local_source_check.json', {'anchors': {science_name: binding(science_name)},
        'original_implementation_files': {seal_name: binding(seal_name)},
        'production_sources': {name: binding(name) for name in sources}})
    put('input/execution_authorization.json', {'stage_id': gate.STAGE,
        'authorized_mode': 'two-basin-one-update', 'remote_execution_authorized': True,
        'formal_local_search_authorized': False, 'evaluation_authorized': False,
        'counts': gate.COUNTS, 'samples': [{'basin_id': b, 'dimension': d} for b,d in gate.SAMPLES]})
    scale_dir = 'input/scales'
    monkeypatch.setattr(gate, 'SCALE_ROOT', scale_dir)
    scale_records = {}
    metadata = {'basins': {}, 'evaluation_array_reads': 0}
    for basin, dimension in gate.SAMPLES:
        unit = f'basin_{basin}'
        params = {'p': float(dimension)}
        for name, value in [('identity.json', {'parameter_row': {'parameter_names': ['p'], 'values': [float(dimension)]}}),
                            ('summary.json', {'state_dimension': dimension, 'state_scale': [1.0]*dimension}),
                            ('manifest.final.sha256.json', {}), ('state_scale_arrays.npz', 'synthetic')]:
            relative = f'{unit}/{name}'
            put(f'{scale_dir}/{relative}', value)
            scale_records[relative] = gate.file_record(root/scale_dir/relative)
        metadata['basins'][basin] = {'dimension': dimension, 'parameters': params,
            'state_scale': [1.0]*dimension, 'semantic_members': {
                period: {field: semantics[f'{basin}/{period}/{field}']
                         for field in ('dates_ns','forcing','observations')}
                for period in ('training','validation')}}
    put(f'{scale_dir}/manifest.final.sha256.json', {'files': scale_records})
    # Substitute the synthetic scale anchor, not the verifier.
    scale_path = root/scale_dir/'manifest.final.sha256.json'
    monkeypatch.setattr(gate, 'SCALE_SHA', gate.digest(scale_path))
    put('input/metadata.json', metadata)
    put('input/training_validation.npz', 'synthetic arrays, no model')
    def reseal():
        records = {p.relative_to(root).as_posix(): gate.file_record(p) for p in root.rglob('*')
                   if p.is_file() and p.name != 'bundle_manifest.json'}
        put('bundle_manifest.json', {'stage_id': gate.STAGE, 'path_mapping': {
            'windows_root': str(gate.WINDOWS_ROOT), 'remote_root': gate.REMOTE_ROOT_POSIX},
            'files': records})
        return gate.digest(root/'bundle_manifest.json')
    return root, put, reseal

def test_complete_synthetic_bundle(bundle):
    root, _, reseal = bundle
    result = verify_bundle(root, reseal(), enforce_remote=False)
    assert result['parent_source_count'] == 13
    assert result['model_import_performed'] is False

@pytest.mark.parametrize('change,expected', [
    ('missing', 'member set'), ('bytes', 'member changed'), ('link', 'linked'),
    ('budget', 'scope'), ('basin', 'sample order'), ('period', 'period'),
    ('dimension', 'dimension'), ('semantic', 'semantic input'),
    ('mapping', 'root mapping'), ('source', 'parent source')])
def test_synthetic_bundle_rejects_changes(bundle, change, expected, monkeypatch):
    root, put, reseal = bundle
    sha = reseal()
    if change == 'missing':
        (root/'input/training_validation.npz').unlink()
    elif change == 'bytes':
        put('input/training_validation.npz', 'changed')
    elif change == 'link':
        target = root/'input/training_validation.npz'
        target.unlink()
        try:
            target.symlink_to(root/'input/metadata.json')
        except OSError as exc:
            if os.name == 'nt' and getattr(exc, 'winerror', None) == 1314:
                pytest.skip('Windows account cannot create symbolic links')
            raise
        sha = reseal()
    else:
        file = 'bundle_manifest.json' if change == 'mapping' else (
            'input/execution_authorization.json' if change == 'budget' else (
            gate.PARENT if change == 'source' else 'input/metadata.json'))
        data = read_json(root/file)
        if change == 'mapping': data['path_mapping']['remote_root'] = 'wrong'
        elif change == 'budget': data['counts']['adam_updates'] = 3
        elif change == 'source':
            first = next(iter(data['production_source_sha256']))
            data['production_source_sha256'][first] = '0'*64
            monkeypatch.setattr(gate, 'PARENT_SHA', gate.digest(put(file, data)))
        elif change == 'basin': data['basins'] = dict(reversed(list(data['basins'].items())))
        elif change == 'period': data['basins']['01047000']['semantic_members'].pop('validation')
        elif change == 'dimension': data['basins']['01047000']['dimension'] = 8
        elif change == 'semantic': data['basins']['01047000']['semantic_members']['training']['forcing'] = 'changed'
        if change == 'mapping':
            sha = gate.digest(put(file, data))
        else:
            put(file, data)
            sha = reseal()
    with pytest.raises((RuntimeError, PermissionError, ValueError), match=expected):
        verify_bundle(root, sha, enforce_remote=False)
