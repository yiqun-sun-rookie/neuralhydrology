"""Standard-library-only gate for the separately authorized two-basin HPC probe."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path, PurePosixPath, PureWindowsPath

STAGE = "TUKF09_TWO_BASIN_HPC_NARROW_PROBE_20260922_V1"
WINDOWS_ROOT = PureWindowsPath("G:/github/pycharm/projects/kalmannet")
REMOTE_ROOT = Path("/data1/home/sunyiq/kalmannet_tukf09_scaled_noise_rehearsal_20260922/narrow_probe_v1/bundle")
REMOTE_ROOT_POSIX = "/data1/home/sunyiq/kalmannet_tukf09_scaled_noise_rehearsal_20260922/narrow_probe_v1/bundle"
SCIENCE = "hpc/tukf09_455_scaled_noise_local_transfer_contract_v1.json"
SCIENCE_SHA = "27239212680bd370bd76f40e53337b7d68d80cbe4dc01feac2164bab4917f8a1"
PARENT = "artifacts/tukf09_455_basin_zero_validation_target_variance_revision_v1/formal_evaluation_admission_compat_v5/formal_evaluation_admission.json"
PARENT_SHA = "1fbd45a829d2216d78e72a70c8ebc221a6e745d2078100ea895b4a44f6b15c5a"
SCALE_ROOT = 'results/tukf09_455_scaled_noise_local_transfer_v1/state_scales_v1'
SCALE_SHA = '449ac52f3d16b8ae8b390f7a73f1a170b80d9a78d5b231ba8c403d01fc793702'
SAMPLES = [("01047000", 7), ("01142500", 20)]
COUNTS = {"basins": 2, "deterministic_basin_day_steps": 5114, "adam_updates": 2,
          "training_objective_calls": 4, "validation_objective_calls": 4,
          "evaluation_array_reads": 0}


def read_json(path: Path) -> dict:
    def pairs(items):
        value = {}
        for key, item in items:
            if key in value:
                raise ValueError("duplicate JSON key: " + key)
            value[key] = item
        return value
    def constant(token):
        raise ValueError("non-finite JSON: " + token)
    value = json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=pairs,
                       parse_constant=constant)
    if not isinstance(value, dict):
        raise ValueError("expected JSON object")
    return value


def digest(path: Path) -> str:
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def file_record(path: Path) -> dict:
    return {"sha256": digest(path), "size_bytes": path.stat().st_size}


def checked_path(root: Path, relative: str) -> Path:
    rel = PurePosixPath(relative)
    if (not relative or relative != rel.as_posix() or rel.is_absolute()
            or ".." in rel.parts or ":" in relative or chr(92) in relative):
        raise ValueError("invalid bundle-relative path")
    target = root.joinpath(*rel.parts)
    target.resolve().relative_to(root.resolve())
    for candidate in [target, *target.parents]:
        if candidate.is_symlink() or getattr(candidate, "is_junction", lambda: False)():
            raise ValueError("linked bundle path")
        if candidate == root:
            break
    if not target.is_file():
        raise FileNotFoundError(target)
    return target


def mapped_relative(original: str) -> str:
    source = PureWindowsPath(original)
    if not source.is_absolute() or ".." in source.parts:
        raise ValueError("invalid original Windows path")
    relative = source.relative_to(WINDOWS_ROOT)
    if not relative.parts:
        raise ValueError("root is not a source file")
    return PurePosixPath(*relative.parts).as_posix()


def verify_bundle(root: Path, manifest_digest: str, *, enforce_remote: bool = True) -> dict:
    root = Path(root)
    if root.is_symlink() or not root.is_dir():
        raise ValueError("bundle root is not a plain directory")
    if enforce_remote and root.resolve() != REMOTE_ROOT:
        raise PermissionError("unapproved remote bundle root")
    manifest_path = checked_path(root, "bundle_manifest.json")
    if digest(manifest_path) != manifest_digest:
        raise RuntimeError("bundle manifest fingerprint changed")
    manifest = read_json(manifest_path)
    if manifest.get("stage_id") != STAGE:
        raise PermissionError("wrong stage")
    mapping = manifest.get("path_mapping")
    if mapping != {"windows_root": str(WINDOWS_ROOT), "remote_root": REMOTE_ROOT_POSIX}:
        raise PermissionError("root mapping changed")
    records = manifest["files"]
    actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    if set(records) | {"bundle_manifest.json"} != actual:
        raise RuntimeError("bundle member set changed")
    for relative, expected in records.items():
        if file_record(checked_path(root, relative)) != expected:
            raise RuntimeError("bundle member changed: " + relative)
    if digest(root / SCIENCE) != SCIENCE_SHA or digest(root / PARENT) != PARENT_SHA:
        raise RuntimeError("frozen anchor changed")
    science = read_json(root / SCIENCE)
    for binding in (*science['lineage']['input_seals'].values(), science['lineage']['parent_scientific_contract'],
                    science['lineage']['completed_parent_evidence']['filter_registry']):
        actual_record = file_record(checked_path(root, binding['path']))
        if actual_record != {k: binding[k] for k in ('sha256', 'size_bytes')}:
            raise RuntimeError('original input binding changed')
    parent = read_json(root / PARENT)
    sources = parent["production_source_sha256"]
    if len(sources) != 13:
        raise RuntimeError("parent source count changed")
    source_evidence = {}
    for name, sha in sources.items():
        record = parent["bindings"][name]
        relative = mapped_relative(record["path"])
        if relative in source_evidence or record["sha256"] != sha:
            raise RuntimeError("ambiguous parent source mapping")
        if file_record(checked_path(root, relative)) != {"sha256": sha, "size_bytes": record["size_bytes"]}:
            raise RuntimeError("parent source fingerprint changed")
        source_evidence[relative] = {"original": record["path"], "sha256": sha}
    # Every local pre-import check, including original admissions, stays bound.
    checks = read_json(root / "input/local_source_check.json")
    for group in (checks["anchors"], checks["original_implementation_files"], checks["production_sources"]):
        for key, record in group.items():
            relative = record.get("path", key)
            if PureWindowsPath(relative).is_absolute():
                relative = mapped_relative(relative)
            actual_record = file_record(checked_path(root, relative))
            if actual_record["sha256"] != record["sha256"] or actual_record["size_bytes"] != record["size_bytes"]:
                raise RuntimeError("local source gate binding changed: " + relative)
    auth = read_json(root / "input/execution_authorization.json")
    if (auth.get("stage_id") != STAGE or auth.get("authorized_mode") != "two-basin-one-update"
            or auth.get("remote_execution_authorized") is not True
            or auth.get("formal_local_search_authorized") is not False
            or auth.get("evaluation_authorized") is not False
            or auth.get("counts") != COUNTS
            or auth.get("samples") != [{"basin_id": b, "dimension": d} for b, d in SAMPLES]):
        raise PermissionError("execution scope or budget changed")
    metadata = read_json(root / "input/metadata.json")
    if metadata.get('evaluation_array_reads') != 0:
        raise PermissionError('evaluation access recorded')
    semantics = read_json(root / science['lineage']['input_seals']['semantic_input_manifest']['path'])['members']
    scales = root / SCALE_ROOT
    if digest(scales/'manifest.final.sha256.json') != SCALE_SHA:
        raise RuntimeError('scale provenance changed')
    scale_members = read_json(scales/'manifest.final.sha256.json')['files']
    if list(metadata["basins"]) != [b for b, _ in SAMPLES]:
        raise PermissionError("sample order changed")
    for basin, dimension in SAMPLES:
        row = metadata["basins"][basin]
        if row["dimension"] != dimension or set(row["semantic_members"]) != {"training", "validation"}:
            raise PermissionError("dimension or period changed")
        for period in ('training','validation'):
            if set(row['semantic_members'][period]) != {'dates_ns','forcing','observations'}:
                raise PermissionError('unexpected semantic field')
            for name, value in row['semantic_members'][period].items():
                if value != semantics[f'{basin}/{period}/{name}']:
                    raise RuntimeError('semantic input provenance changed')
        for name in ('identity.json','summary.json','manifest.final.sha256.json','state_scale_arrays.npz'):
            relative = f'basin_{basin}/{name}'
            if file_record(scales/relative) != scale_members[relative]:
                raise RuntimeError('scale member provenance changed')
        identity = read_json(scales/f'basin_{basin}/identity.json')
        summary = read_json(scales/f'basin_{basin}/summary.json')
        if row['state_scale'] != summary['state_scale'] or summary['state_dimension'] != dimension:
            raise RuntimeError('sealed scale value changed')
        if row['parameters'] != dict(zip(identity['parameter_row']['parameter_names'],identity['parameter_row']['values'])):
            raise RuntimeError('parameter row provenance changed')
    return {"stage_id": STAGE, "manifest_sha256": manifest_digest,
            "parent_source_count": len(source_evidence), "mapped_sources": source_evidence,
            "member_count": len(records), "model_import_performed": False}
