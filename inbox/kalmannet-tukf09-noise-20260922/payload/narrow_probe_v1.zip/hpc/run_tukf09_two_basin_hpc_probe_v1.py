"""New explicit remote entry; frozen numerical implementations remain unchanged."""
from __future__ import annotations
import json
import os
from pathlib import Path
import sys
import time
from tukf09_two_basin_hpc_gate_v1 import COUNTS, REMOTE_ROOT, SAMPLES, read_json, verify_bundle


def worker():
    started = time.monotonic()
    evidence = verify_bundle(REMOTE_ROOT, os.environ['TUKF09_BUNDLE_SHA256'])
    sys.dont_write_bytecode = True
    sys.path[:0] = [str(REMOTE_ROOT), str(REMOTE_ROOT/'src')]
    print('SOURCE_GATE_OK ' + json.dumps(evidence), flush=True)
    import numpy as np
    import torch
    from hpc import tukf09_455_scaled_noise_common_v1 as frozen
    from scripts.tukf09_training_common import semantic_array_identity
    frozen.configure_single_thread_execution()
    if np.__version__ != '1.26.4' or torch.__version__.split('+')[0] != '2.2.2':
        raise RuntimeError('runtime version changed')
    metadata = read_json(REMOTE_ROOT/'input/metadata.json')
    parent = read_json(REMOTE_ROOT/'configs/tukf09_455_basin_zero_validation_target_variance_revision_v1.json')
    science = frozen.load_science_contract()
    frozen_inputs = frozen.load_frozen_inputs()
    fixed = frozen.load_fixed_observation_noise(frozen_inputs)
    output = REMOTE_ROOT.parent/'run/model'
    output.mkdir(exist_ok=False)
    frozen.atomic_write_json_exclusive(output/'started.json', {
        'source_gate': evidence, 'counts_authorized': COUNTS,
        'runtime': {'python':sys.version, 'platform':list(os.uname()),
                    'numpy':np.__version__, 'torch':torch.__version__,
                    'numpy_path':np.__file__, 'torch_path':torch.__file__,
                    'torch_threads':torch.get_num_threads(), 'torch_interop_threads':torch.get_num_interop_threads(),
                    'device':'cpu', 'precision':'float64'}})
    expected = {f'{b}/{p}/{n}' for b,_ in SAMPLES for p in ('training','validation')
                for n in ('dates_ns','forcing','observations')}
    completed = []
    with np.load(REMOTE_ROOT/'input/training_validation.npz', allow_pickle=False) as archive:
        if set(archive.files) != expected or len(archive.files) != len(expected):
            raise RuntimeError('exported array membership changed')
        for basin, dimension in SAMPLES:
            row = metadata['basins'][basin]
            if fixed[basin] != row['fixed_r_b']:
                raise RuntimeError('observation noise mismatch')
            periods = {}
            for period, days, start, stop in (
                ('training',2557,'1999-10-01','2006-10-01'),
                ('validation',731,'2006-10-01','2008-10-01')):
                arrays = {}
                for name in ('dates_ns','forcing','observations'):
                    key = f'{basin}/{period}/{name}'
                    value = archive[key]
                    actual = semantic_array_identity(key, value, '<i8' if name == 'dates_ns' else '<f8')
                    if actual != row['semantic_members'][period][name]:
                        raise RuntimeError('input semantic mismatch: '+key)
                    arrays[name] = value
                dates = np.arange(np.datetime64(start),np.datetime64(stop)).astype('datetime64[ns]').astype('<i8')
                if not np.array_equal(arrays['dates_ns'], dates):
                    raise RuntimeError('period dates changed')
                periods[period] = frozen.period_data_from_loaded(arrays, expected_day_count=days)
            index = list(frozen_inputs.basin_ids).index(basin)
            parameters = dict(zip(frozen_inputs.parameter_names, frozen_inputs.parameter_values[index]))
            if parameters != row['parameters']:
                raise RuntimeError('sealed parameter row changed')
            scale = np.asarray(row['state_scale'], dtype=np.float64)
            context = frozen.build_causal_filter_context(basin, parameters, periods['training'].observations, parent)
            if context.dimension != dimension or scale.shape != (dimension,):
                raise RuntimeError('dimension mismatch')
            print(f'MODEL_STARTED basin={basin} dimension={dimension} deterministic_days=2557', flush=True)
            initial, trajectory = frozen.deterministic_training_trajectory(context, periods['training'].forcing)
            computed, floor_hits, units = frozen.compute_state_scale(trajectory)
            print(f'TRAJECTORY_COMPLETE basin={basin} OPTIMIZATION_STARTED anchor=0 updates=1', flush=True)
            summary, result_arrays = frozen.run_one_update_probe(context, periods['training'], periods['validation'],
                                                                scale, fixed[basin], parent, science)
            for key,value in {'anchor_index':0,'adam_updates':1,'training_objective_calls':2,'validation_objective_calls':2}.items():
                if summary[key] != value:
                    raise RuntimeError('actual budget changed: '+key)
            summary.update(basin_id=basin, dimension=dimension, evaluation_array_reads=0,
                           scale_used='original_sealed_scale', scale_recomputed_max_abs_difference=float(np.max(np.abs(computed-scale))))
            unit = output/f'basin_{basin}'
            unit.mkdir(exist_ok=False)
            frozen.atomic_write_json_exclusive(unit/'summary.json', summary)
            result_arrays.update(initial_state=initial, deterministic_trajectory=trajectory, sealed_state_scale=scale,
                                 recomputed_state_scale=computed)
            with (unit/'probe_arrays.npz').open('xb') as stream:
                stream.write(frozen.deterministic_npz_bytes(result_arrays))
            completed.append(summary)
            print('BASIN_COMPLETE '+json.dumps(summary), flush=True)
    frozen.atomic_write_json_exclusive(output/'run_summary.json', {
        'status':'TWO_BASIN_NARROW_PROBE_COMPLETE_NOT_FORMAL_SEARCH', 'counts':COUNTS,
        'basins':completed,'wall_seconds':time.monotonic()-started, 'scientific_performance_claim':False})
    frozen.atomic_write_json_exclusive(output/'manifest.final.sha256.json', frozen.build_directory_manifest(
        output, schema_version='tukf09_two_basin_hpc_probe_manifest_v1', status='TWO_BASIN_NARROW_PROBE_COMPLETE'))
    print('TWO_BASIN_NARROW_PROBE_COMPLETE', flush=True)


def main():
    verify_bundle(REMOTE_ROOT, os.environ['TUKF09_BUNDLE_SHA256'])
    if sys.argv[1:] == ['--worker']:
        worker()
    elif not sys.argv[1:]:
        import resource
        resource.setrlimit(resource.RLIMIT_AS, (256*2**20,8*2**30))
        from tukf09_two_basin_hpc_supervisor_v1 import run_supervised
        result = run_supervised([sys.executable, '-B', str(Path(__file__).resolve()), '--worker'], REMOTE_ROOT.parent/'run')
        print(json.dumps(result), flush=True)
        raise SystemExit(0 if result['success'] else 1)
    else:
        raise SystemExit('unexpected arguments')


if __name__ == '__main__':
    main()
