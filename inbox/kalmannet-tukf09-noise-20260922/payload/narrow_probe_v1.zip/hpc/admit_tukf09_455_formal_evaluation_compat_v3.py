"""Build the immutable technical admission for one formal evaluation.

Admission rehashes every authorization binding and the isolated evaluation-test
evidence.  It intentionally imports NumPy only so tests can prove that
``numpy.load`` is never called; no evaluation array is constructed here.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from typing import Any, Mapping
import uuid

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from hpc import register_tukf09_455_formal_evaluation_authorization_compat_v3 as registration
from hpc import tukf09_455_evaluation_compat_v3 as compat


EXPERIMENT_ID = registration.EXPERIMENT_ID
ZERO_EVALUATION_ACCESS_LEDGER = dict(registration.ZERO_EVALUATION_ACCESS_LEDGER)
EXECUTABLE_BINDINGS = registration.SOURCE_BINDING_LABELS
EVALUATION_SOURCE_RELATIVES = (
    "scripts/tukf09_455_evaluation_common.py",
    "scripts/register_tukf09_455_formal_evaluation_authorization.py",
    "scripts/admit_tukf09_455_formal_evaluation.py",
    "scripts/evaluate_tukf09_455_basin_revision.py",
    "scripts/verify_tukf09_455_basin_evaluation.py",
    "scripts/tukf07_information_matched_model.py",
    "scripts/run_tukf09_filter_training.py",
    "scripts/tukf09_confirmatory_common.py",
    "scripts/run_aligned_gr4j_da.py",
    "scripts/run_aligned_gr4j_differentiable_ukf.py",
    "src/global_hydrology/assimilation/conventional_ukf.py",
)
EVALUATION_TEST_RELATIVES = (
    "tests/test_tukf09_455_evaluation_authorization.py",
    "tests/test_tukf09_455_evaluation.py",
    "tests/test_tukf09_455_evaluation_audit.py",
)


@dataclass(frozen=True)
class EvaluationAdmission:
    path: Path
    file_sha256: str
    record: Mapping[str, Any]


def _absolute(path: str | Path) -> Path:
    return Path(os.path.abspath(os.fspath(path)))


def _require_file(path: str | Path, *, label: str) -> Path:
    candidate = _absolute(path)
    from scripts import tukf09_455_training_common as training_common

    training_common.ensure_no_symlink_components(candidate)
    if not candidate.is_file() or candidate.is_symlink() or candidate.stat().st_nlink != 1:
        raise FileNotFoundError(f"{label} is absent, linked, or not a regular file: {candidate}")
    return candidate


def _sha256_file(path: str | Path) -> str:
    source = _require_file(path, label="SHA-256 source")
    digest = sha256()
    with source.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _read_json(path: str | Path, *, label: str) -> dict[str, Any]:
    source = _require_file(path, label=label)
    try:
        value = json.loads(source.read_bytes())
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"{label} is not valid JSON") from exc
    if not isinstance(value, dict):
        raise RuntimeError(f"{label} must contain a JSON object")
    registration.canonical_json_bytes(value)
    return value


def _validate_authorization(
    authorization_path: Path,
    *,
    production: bool,
) -> tuple[dict[str, Any], dict[str, dict[str, Any]]]:
    authorization = _read_json(authorization_path, label="formal evaluation authorization")
    if (
        authorization.get("experiment_id") != EXPERIMENT_ID
        or authorization.get("status") != "FORMAL_EVALUATION_AUTHORIZED_ONE_TIME"
        or authorization.get("one_time") is not True
        or authorization.get("evaluation_arrays_loaded") is not False
        or authorization.get("evaluation_access_ledger") != ZERO_EVALUATION_ACCESS_LEDGER
        or authorization.get("record_sha256") != registration.record_sha256(authorization)
    ):
        raise PermissionError("formal evaluation authorization is invalid or records prior access")
    if production:
        compat.verify_authorization(authorization)
    gate_bindings = authorization.get("gate_implementation_bindings")
    if production and (
        not isinstance(gate_bindings, dict)
        or set(gate_bindings)
        != {
            "hpc/register_tukf09_455_formal_evaluation_authorization_compat_v3.py",
            "hpc/admit_tukf09_455_formal_evaluation_compat_v3.py",
        }
    ):
        raise RuntimeError("formal evaluation gate implementation binding set changed")
    if isinstance(gate_bindings, dict):
        for relative, binding in gate_bindings.items():
            if not isinstance(binding, dict) or set(binding) != {
                "path",
                "sha256",
                "size_bytes",
            }:
                raise RuntimeError(f"formal evaluation gate binding schema changed: {relative}")
            path = _require_file(binding["path"], label=f"authorized {relative}")
            if _sha256_file(path) != binding["sha256"] or path.stat().st_size != int(
                binding["size_bytes"]
            ):
                raise RuntimeError(f"formal evaluation gate implementation changed: {relative}")
    bindings = authorization.get("bindings")
    if not isinstance(bindings, dict) or set(bindings) != registration.REQUIRED_BINDING_LABELS:
        raise RuntimeError("formal evaluation authorization binding set changed")
    verified: dict[str, dict[str, Any]] = {}
    for label, binding in sorted(bindings.items()):
        if not isinstance(binding, dict) or set(binding) != {"path", "sha256", "size_bytes"}:
            raise RuntimeError(f"authorization binding schema changed: {label}")
        path = _require_file(binding["path"], label=f"authorized {label}")
        size = int(path.stat().st_size)
        digest = _sha256_file(path)
        if size != int(binding["size_bytes"]) or digest != binding["sha256"]:
            raise RuntimeError(f"authorized binding changed: {label}")
        verified[label] = {"path": os.fspath(path), "sha256": digest, "size_bytes": size}
    if authorization.get("selection_sha256") != verified["training_selection_seal"]["sha256"]:
        raise RuntimeError("authorized training selection identity changed")
    if (
        authorization.get("independent_selection_sha256")
        != verified["independent_training_selection_final_manifest"]["sha256"]
    ):
        raise RuntimeError("authorized independent training selection identity changed")
    output = _absolute(authorization["evaluation_output_root"])
    fixed = _absolute(authorization["fixed_results_root"])
    if os.path.commonpath([os.fspath(fixed), os.fspath(output)]) != os.fspath(fixed):
        raise RuntimeError("authorized evaluation output escaped the fixed results root")
    if output.exists() or output.is_symlink():
        raise FileExistsError("formal evaluation output exists before technical admission")
    expected_output_identity = sha256(
        registration.canonical_json_bytes(
            {
                "experiment_id": EXPERIMENT_ID,
                "fixed_results_root": os.fspath(fixed),
                "evaluation_output_root": os.fspath(output),
            }
        )
    ).hexdigest()
    if authorization.get("output_identity_sha256") != expected_output_identity:
        raise RuntimeError("authorized fixed output identity changed")
    return authorization, verified


def _validate_test_evidence(
    path: Path,
    bindings: Mapping[str, Mapping[str, Any]],
    *,
    production: bool,
) -> tuple[dict[str, Any], str]:
    evidence = _read_json(path, label="isolated evaluation test evidence")
    if (
        evidence.get("experiment_id") != EXPERIMENT_ID
        or evidence.get("status") != "EVALUATION_CODE_TESTS_PASSED"
        or int(evidence.get("passed", 0)) <= 0
        or int(evidence.get("failed", -1)) != 0
        or evidence.get("cache_disabled") is not True
        or evidence.get("bytecode_disabled") is not True
    ):
        raise RuntimeError("isolated evaluation tests are absent, failed, or ran with caches")
    command = evidence.get("command")
    if not isinstance(command, str) or not all(
        name in command
        for name in (
            "test_tukf09_455_evaluation_authorization.py",
            "test_tukf09_455_evaluation.py",
            "test_tukf09_455_evaluation_audit.py",
        )
    ):
        raise RuntimeError("isolated evaluation test command is incomplete")
    source_hashes = evidence.get("source_sha256")
    if not isinstance(source_hashes, dict) or set(source_hashes) != EXECUTABLE_BINDINGS:
        raise RuntimeError("evaluation test evidence executable set changed")
    for label in EXECUTABLE_BINDINGS:
        if source_hashes[label] != bindings[label]["sha256"]:
            raise RuntimeError(f"evaluation executable changed after its admitted tests: {label}")
    if production and int(evidence["passed"]) < 1:
        raise RuntimeError("production evaluation test evidence lacks a passing test")
    return evidence, _sha256_file(path)


def _revalidate_production_source_closure(
    bindings: Mapping[str, Mapping[str, Any]],
    authorization: Mapping[str, Any] | None = None,
) -> dict[str, Mapping[str, Any]]:
    if authorization is not None:
        compat.verify_authorization(authorization)
    documents = {
        label: _read_json(binding["path"], label=f"production binding {label}")
        for label, binding in bindings.items()
        if label in registration.JSON_BINDING_LABELS
    }
    registration._validate_upstream(documents, production=True)
    registration._validate_algorithm_source_closure(
        documents, bindings, production=True
    )
    executable_bindings = registration._validate_training_executable_closure(
        documents, bindings
    )
    anchor_bindings = registration._validate_all_contract_source_anchors(documents)
    selection_bundle = registration._validate_independent_training_selection_bundle(
        documents, bindings
    )
    identity_chain = registration._validate_pretraining_identity_chain(
        documents, bindings
    )
    if authorization is not None and (
        authorization.get("ordered_training_required_executables")
        != list(executable_bindings)
        or authorization.get("training_required_executable_bindings")
        != executable_bindings
        or authorization.get("scientific_contract_source_anchor_bindings")
        != anchor_bindings
        or authorization.get("independent_training_selection_bundle")
        != selection_bundle
        or authorization.get("pretraining_identity_chain") != identity_chain
    ):
        raise RuntimeError("formal evaluation authorization source closure changed")
    return documents


def _require_current_runtime_matches_training(
    bindings: Mapping[str, Mapping[str, Any]],
    *,
    expected_admission_identity: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Require byte-for-byte runtime identity equality with training admission."""

    from scripts import tukf09_455_training_common as training_common

    training = _read_json(
        bindings["training_admission"]["path"], label="pretraining technical admission"
    )
    expected = training_common.validate_runtime_environment_identity(
        training.get("runtime_environment_identity", {})
    )
    current = training_common.runtime_environment_identity()
    if current != expected:
        raise RuntimeError("formal evaluation runtime environment differs from training admission")
    if expected_admission_identity is not None and dict(expected_admission_identity) != expected:
        raise RuntimeError("formal evaluation admission runtime identity differs from training")
    return current


def _verify_pretraining_identities(
    *,
    training_admission_path: Path,
    formal_test_evidence: Mapping[str, Any],
    project_root: Path,
) -> None:
    training = _read_json(training_admission_path, label="pretraining technical admission")
    records = training.get("executables")
    if not isinstance(records, dict):
        raise RuntimeError("pretraining admission executable records are absent")
    for relative in EVALUATION_SOURCE_RELATIVES:
        current = _require_file(project_root / relative, label=f"evaluation source {relative}")
        expected = records.get(relative)
        actual = {"sha256": _sha256_file(current), "size_bytes": current.stat().st_size}
        if expected != actual:
            raise RuntimeError(f"evaluation source changed since pretraining admission: {relative}")
    pretraining_tests = training.get("test_evidence", {}).get("pytest_file_records")
    formal_tests = formal_test_evidence.get("pytest_file_records")
    if not isinstance(pretraining_tests, dict) or not isinstance(formal_tests, dict):
        raise RuntimeError("pretraining or formal evaluation test-file hashes are absent")
    if set(formal_tests) != set(EVALUATION_TEST_RELATIVES):
        raise RuntimeError("formal evaluation test-file hash set changed")
    for relative in EVALUATION_TEST_RELATIVES:
        current = _require_file(project_root / relative, label=f"evaluation test {relative}")
        actual = {"sha256": _sha256_file(current), "size_bytes": current.stat().st_size}
        if formal_tests.get(relative) != actual or pretraining_tests.get(relative) != actual:
            raise RuntimeError(f"evaluation test changed since pretraining admission: {relative}")


def _atomic_write_exclusive(path: Path, content: bytes) -> Path:
    destination = _absolute(path)
    if destination.exists() or destination.is_symlink():
        raise FileExistsError(f"evaluation admission destination already exists: {destination}")
    from scripts import tukf09_455_training_common as training_common

    training_common.ensure_no_symlink_components(destination.parent)
    destination.parent.mkdir(parents=True, exist_ok=True)
    training_common.ensure_no_symlink_components(destination.parent)
    temporary = destination.with_name(f".pending-{uuid.uuid4().hex[:10]}")
    try:
        with temporary.open("xb") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        if destination.exists() or destination.is_symlink():
            raise FileExistsError("evaluation admission destination appeared during publication")
        os.replace(temporary, destination)
    finally:
        if temporary.exists() or temporary.is_symlink():
            temporary.unlink()
    return destination


def admit_formal_evaluation(
    *,
    authorization_path: str | Path,
    test_evidence_path: str | Path,
    destination: str | Path,
    authorize: bool,
    production: bool = True,
    created_utc: str | None = None,
) -> EvaluationAdmission:
    """Recheck all frozen identities and admit exactly one evaluation attempt."""

    if authorize is not True:
        raise PermissionError("explicit formal evaluation technical admission is required")
    authorization_source = _absolute(authorization_path)
    authorization, bindings = _validate_authorization(
        authorization_source,
        production=production,
    )
    evidence_source = _absolute(test_evidence_path)
    evidence, evidence_hash = _validate_test_evidence(
        evidence_source,
        bindings,
        production=production,
    )
    runtime_identity: dict[str, Any] | None = None
    if production:
        _revalidate_production_source_closure(bindings, authorization)
        project_root = _absolute(__file__).parent.parent
        _verify_pretraining_identities(
            training_admission_path=Path(bindings["training_admission"]["path"]),
            formal_test_evidence=evidence,
            project_root=project_root,
        )
        runtime_identity = _require_current_runtime_matches_training(bindings)
    timestamp = created_utc or datetime.now(timezone.utc).isoformat()
    if not isinstance(timestamp, str) or not timestamp:
        raise ValueError("evaluation admission timestamp is invalid")
    unsigned: dict[str, Any] = {
        "schema_version": "tukf09_455_formal_evaluation_admission_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "FORMAL_EVALUATION_TECHNICALLY_ADMITTED_ONE_TIME",
        "created_utc": timestamp,
        "one_time": True,
        "authorization_path": os.fspath(authorization_source),
        "authorization_sha256": _sha256_file(authorization_source),
        "authorization_record_sha256": authorization["record_sha256"],
        "selection_sha256": authorization["selection_sha256"],
        "independent_selection_sha256": authorization["independent_selection_sha256"],
        "formal_evaluation_config_sha256": bindings["formal_evaluation_config"]["sha256"],
        "evaluation_common_sha256": bindings["evaluation_common_source"]["sha256"],
        "evaluator_sha256": bindings["evaluator_source"]["sha256"],
        "independent_evaluation_verifier_sha256": bindings[
            "independent_evaluation_verifier_source"
        ]["sha256"],
        "model_source_sha256": bindings["model_source"]["sha256"],
        "production_source_sha256": {
            label: bindings[label]["sha256"]
            for label in sorted(registration.SOURCE_BINDING_LABELS)
        },
        "fixed_results_identity_sha256": bindings["fixed_results_identity"]["sha256"],
        "fixed_results_root": authorization["fixed_results_root"],
        "evaluation_output_root": authorization["evaluation_output_root"],
        "output_identity_sha256": authorization["output_identity_sha256"],
        "bindings": bindings,
        "runtime_environment_identity": runtime_identity,
        "runtime_environment_identity_sha256": (
            registration._canonical_sha256(runtime_identity)
            if runtime_identity is not None
            else None
        ),
        "test_evidence": {
            "path": os.fspath(evidence_source),
            "sha256": evidence_hash,
            "passed": int(evidence["passed"]),
            "failed": 0,
            "cache_disabled": True,
            "bytecode_disabled": True,
            "source_sha256": dict(evidence["source_sha256"]),
        },
        "evaluation_arrays_loaded": False,
        "evaluation_access_ledger": dict(ZERO_EVALUATION_ACCESS_LEDGER),
    }
    record = dict(unsigned)
    record["record_sha256"] = sha256(registration.canonical_json_bytes(unsigned)).hexdigest()
    published = _atomic_write_exclusive(Path(destination), registration.canonical_json_bytes(record))
    return EvaluationAdmission(
        path=published,
        file_sha256=_sha256_file(published),
        record=record,
    )


def load_and_verify_evaluation_admission(
    admission_path: str | Path,
    *,
    production: bool = True,
) -> EvaluationAdmission:
    """Read-only revalidation used immediately before lock acquisition and inside it."""

    source = _require_file(admission_path, label="formal evaluation technical admission")
    record = _read_json(source, label="formal evaluation technical admission")
    unsigned = dict(record)
    stored_hash = unsigned.pop("record_sha256", None)
    if (
        record.get("experiment_id") != EXPERIMENT_ID
        or record.get("status") != "FORMAL_EVALUATION_TECHNICALLY_ADMITTED_ONE_TIME"
        or record.get("one_time") is not True
        or record.get("evaluation_arrays_loaded") is not False
        or record.get("evaluation_access_ledger") != ZERO_EVALUATION_ACCESS_LEDGER
        or stored_hash
        != sha256(registration.canonical_json_bytes(unsigned)).hexdigest()
    ):
        raise PermissionError("formal evaluation technical admission is invalid")
    authorization_path = _require_file(
        record["authorization_path"], label="bound formal evaluation authorization"
    )
    if (
        _sha256_file(authorization_path) != record.get("authorization_sha256")
        or registration.record_sha256(
            _read_json(authorization_path, label="bound formal evaluation authorization")
        )
        != record.get("authorization_record_sha256")
    ):
        raise RuntimeError("formal evaluation authorization changed after admission")
    bindings = record.get("bindings")
    if not isinstance(bindings, dict) or set(bindings) != registration.REQUIRED_BINDING_LABELS:
        raise RuntimeError("formal evaluation admission binding set changed")
    for label, binding in bindings.items():
        path = _require_file(binding["path"], label=f"admitted {label}")
        if _sha256_file(path) != binding["sha256"] or path.stat().st_size != int(
            binding["size_bytes"]
        ):
            raise RuntimeError(f"formal evaluation admitted binding changed: {label}")
    evidence = record.get("test_evidence")
    if production:
        if not isinstance(evidence, dict):
            raise RuntimeError("formal evaluation admission test evidence changed")
        evidence_record = _read_json(evidence["path"], label="formal evaluation test evidence")
        if _sha256_file(Path(evidence["path"])) != evidence["sha256"]:
            raise RuntimeError("formal evaluation test evidence file changed")
        authorization_record = _read_json(
            authorization_path, label="bound formal evaluation authorization"
        )
        _revalidate_production_source_closure(bindings, authorization_record)
        _verify_pretraining_identities(
            training_admission_path=Path(bindings["training_admission"]["path"]),
            formal_test_evidence=evidence_record,
            project_root=ROOT,
        )
        runtime_identity = record.get("runtime_environment_identity")
        if not isinstance(runtime_identity, Mapping) or record.get(
            "runtime_environment_identity_sha256"
        ) != registration._canonical_sha256(runtime_identity):
            raise RuntimeError("formal evaluation admission runtime identity changed")
        _require_current_runtime_matches_training(
            bindings, expected_admission_identity=runtime_identity
        )
    return EvaluationAdmission(path=source, file_sha256=_sha256_file(source), record=record)


def _evaluation_test_evidence(project_root: Path) -> dict[str, Any]:
    environment = dict(os.environ)
    environment.update(
        {
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1",
            "PYTEST_ADDOPTS": "",
        }
    )
    command = [
        sys.executable,
        "-B",
        "-m",
        "pytest",
        *EVALUATION_TEST_RELATIVES,
        "-q",
        "-p",
        "no:cacheprovider",
    ]
    completed = subprocess.run(
        command,
        cwd=project_root,
        env=environment,
        text=True,
        capture_output=True,
        check=False,
    )
    transcript = f"{completed.stdout}\n{completed.stderr}"
    match = re.search(r"(?P<passed>\d+) passed", transcript)
    if completed.returncode != 0 or match is None:
        raise RuntimeError(
            "isolated evaluation tests did not pass before formal evaluation admission: "
            + transcript[-4000:]
        )
    fixed_bindings = registration.fixed_production_bindings(project_root)
    source_label_paths = {
        label: fixed_bindings[label] for label in sorted(registration.SOURCE_BINDING_LABELS)
    }
    return {
        "schema_version": "tukf09_455_evaluation_test_evidence_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "EVALUATION_CODE_TESTS_PASSED",
        "command": " ".join(command),
        "passed": int(match.group("passed")),
        "failed": 0,
        "cache_disabled": True,
        "bytecode_disabled": True,
        "source_sha256": {
            label: _sha256_file(path) for label, path in source_label_paths.items()
        },
        "pytest_file_records": {
            relative: {
                "sha256": _sha256_file(project_root / relative),
                "size_bytes": (project_root / relative).stat().st_size,
            }
            for relative in EVALUATION_TEST_RELATIVES
        },
        "exit_code": 0,
    }


def admit_formal_evaluation_from_fixed_artifacts(
    *,
    authorize: bool,
    project_root: str | Path = ROOT,
    created_utc: str | None = None,
) -> EvaluationAdmission:
    """Run the fixed isolated suite and publish fixed test evidence plus admission."""

    if authorize is not True:
        raise PermissionError("explicit formal evaluation technical admission is required")
    root = _absolute(project_root)
    config = _read_json(
        root / "configs/tukf09_455_basin_zero_validation_target_variance_formal_evaluation_v1.json",
        label="fixed formal evaluation configuration",
    )
    paths = config.get("paths", {})
    fixed_paths = {
        "results_root": "results/tukf09_455_basin_zero_validation_target_variance_revision_v1",
        "formal_evaluation": (
            "results/tukf09_455_basin_zero_validation_target_variance_revision_v1/evaluation"
        ),
        "evaluation_summary": (
            "results/tukf09_455_basin_zero_validation_target_variance_revision_v1/"
            "evaluation/evaluation_summary.json"
        ),
        "independent_evaluation": (
            "results/tukf09_455_basin_zero_validation_target_variance_revision_v1/"
            "evaluation_independent"
        ),
        "authorization": (
            "artifacts/tukf09_455_basin_zero_validation_target_variance_revision_v1/"
            "authorizations/formal_evaluation_authorization.json"
        ),
        "admission": (
            "artifacts/tukf09_455_basin_zero_validation_target_variance_revision_v1/"
            "formal_evaluation_admission/formal_evaluation_admission.json"
        ),
    }
    if any(paths.get(key) != value for key, value in fixed_paths.items()):
        raise RuntimeError("fixed formal evaluation output paths changed")
    authorization_path = root / compat.AUTHORIZATION_RELATIVE
    admission_path = root / compat.ADMISSION_RELATIVE
    evidence_path = admission_path.with_name("evaluation_test_evidence.json")
    from scripts import tukf09_455_training_common as training_common

    for candidate in (authorization_path, admission_path, evidence_path):
        training_common.ensure_no_symlink_components(candidate, stop_at=root)
    # Complete the fixed-path and authorization/config read-only gate before
    # launching pytest or publishing test evidence.
    _validate_authorization(authorization_path, production=True)
    evidence = _evaluation_test_evidence(root)
    _atomic_write_exclusive(evidence_path, registration.canonical_json_bytes(evidence))
    return admit_formal_evaluation(
        authorization_path=authorization_path,
        test_evidence_path=evidence_path,
        destination=admission_path,
        authorize=True,
        production=True,
        created_utc=created_utc,
    )


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--admit-formal-evaluation", action="store_true")
    parser.add_argument("--project-root", type=Path, default=ROOT)
    return parser


def main() -> None:
    arguments = _parser().parse_args()
    admitted = admit_formal_evaluation_from_fixed_artifacts(
        authorize=bool(arguments.admit_formal_evaluation),
        project_root=arguments.project_root,
    )
    print(json.dumps(dict(admitted.record), ensure_ascii=False, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()


__all__ = [
    "EvaluationAdmission",
    "admit_formal_evaluation",
    "admit_formal_evaluation_from_fixed_artifacts",
    "load_and_verify_evaluation_admission",
    "np",
]
