from __future__ import annotations

import math
from pathlib import Path
import sys

import numpy as np
import pytest
import torch


ROOT = Path(__file__).resolve().parents[1]
for _extra in (str(ROOT), str(ROOT / "src"), str(ROOT / "hpc")):
    if _extra not in sys.path:
        sys.path.insert(0, _extra)

import build_tukf09_455_scaled_noise_transfer_v1 as transfer_module  # noqa: E402
import evaluate_tukf09_455_scaled_noise_local_transfer_v1 as evaluation  # noqa: E402
import tukf09_455_scaled_noise_common_v1 as common  # noqa: E402
import verify_tukf09_455_scaled_noise_local_transfer_v1 as verifier  # noqa: E402


@pytest.fixture(scope="session")
def science_contract() -> dict:
    return common.load_science_contract()


@pytest.fixture(scope="session")
def frozen() -> common.FrozenInputs:
    return common.load_frozen_inputs()


@pytest.fixture(scope="session")
def donor_registry(frozen: common.FrozenInputs) -> dict:
    return common.build_donor_registry(frozen)


def test_execution_authorization_is_narrow_and_formal_work_is_closed() -> None:
    authorization = common.load_execution_authorization()
    scope = authorization["authorization_scope"]
    assert scope["implementation"] is True
    assert scope["metadata_only_coordinate_donor_precheck"] is True
    assert scope["bounded_technical_probe"] is True
    assert scope["formal_state_scale_generation"] is False
    assert scope["formal_local_training_or_checkpoint_selection"] is False
    assert scope["formal_transfer_vector_build"] is False
    assert scope["evaluation_array_access"] is False
    assert scope["remote_or_hpc_submission"] is False
    common.require_formal_execution_denied()


def test_frozen_population_and_dimensions_match_contract(
    frozen: common.FrozenInputs, science_contract: dict
) -> None:
    assert len(frozen.basin_ids) == 455
    assert len(set(frozen.basin_ids)) == 455
    assert "08202700" not in frozen.basin_ids
    counts: dict[str, int] = {}
    for value in frozen.dimension_by_basin.values():
        counts[str(value)] = counts.get(str(value), 0) + 1
    assert counts == science_contract["population"]["state_dimension_counts"]
    assert next(b for b in frozen.basin_ids if frozen.dimension_by_basin[b] == 7) == "01047000"
    assert next(b for b in frozen.basin_ids if frozen.dimension_by_basin[b] == 20) == "01142500"


def test_donor_registry_covers_every_receiver_and_excludes_self(
    frozen: common.FrozenInputs, donor_registry: dict
) -> None:
    assert donor_registry["receiver_count"] == 455
    assert donor_registry["minimum_donor_count"] == 13
    assert tuple(donor_registry["receivers"]) == frozen.basin_ids
    for receiver in frozen.basin_ids:
        record = donor_registry["receivers"][receiver]
        assert record["state_dimension"] == frozen.dimension_by_basin[receiver]
        assert record["coordinate_count"] == len(record["coordinates"])
        for coordinate in record["coordinates"]:
            assert receiver not in coordinate["donors"]
            assert coordinate["donor_count"] == len(coordinate["donors"])
            assert coordinate["donor_count"] >= 13


def test_donor_registry_semantics_and_longest_coordinate_count(donor_registry: dict) -> None:
    receiver = "01142500"
    coordinates = donor_registry["receivers"][receiver]["coordinates"]
    assert [value["semantic_name"] for value in coordinates[:5]] == list(
        common.PHYSICAL_STATE_NAMES
    )
    assert coordinates[5]["semantic_name"] == "unrouted_runoff_lag_0_days"
    assert coordinates[-1]["semantic_name"] == "unrouted_runoff_lag_14_days"
    assert coordinates[-1]["donor_count"] == 13


def test_state_scale_uses_only_indices_365_through_2556() -> None:
    trajectory = np.zeros((2557, 7), dtype=np.float64)
    trajectory[:365] = 999.0
    trajectory[365:, 0] = 2.0
    trajectory[365:, 1] = 0.001
    trajectory[365:, 2:] = np.arange(1.0, 6.0)
    scale, floor_hit, units = common.compute_state_scale(trajectory)
    assert scale[0] == 2.0
    assert scale[1] == 0.01
    assert bool(floor_hit[1])
    assert not bool(floor_hit[0])
    assert units[:5] == ("millimetre",) * 5
    assert units[5:] == ("millimetre_per_day",) * 2


def test_ratio_to_variance_known_example_and_round_trip() -> None:
    rho = np.asarray([0.01, 0.0001, 1.0], dtype=np.float64)
    scale = np.asarray([10.0, 2.0, 0.5], dtype=np.float64)
    q = common.ratio_to_process_variance(rho, scale)
    assert q[0] == pytest.approx(0.01, rel=0.0, abs=1e-15)
    restored = common.process_variance_to_ratio(q, scale)
    assert np.allclose(restored, rho, rtol=0.0, atol=1e-12)


@pytest.mark.parametrize("rho", [0.000099, 1.0001, np.nan])
def test_ratio_to_variance_rejects_out_of_contract_values(rho: float) -> None:
    with pytest.raises((ValueError, FloatingPointError)):
        common.ratio_to_process_variance(
            np.asarray([rho], dtype=np.float64), np.asarray([1.0], dtype=np.float64)
        )


def test_eight_scaled_anchors_are_unique_and_inside_bounds(science_contract: dict) -> None:
    anchors = common.anchor_ratio_matrix(20, science_contract)
    assert anchors.shape == (8, 20)
    assert len({tuple(value) for value in anchors}) == 8
    assert np.all(anchors >= 1e-4)
    assert np.all(anchors <= 1.0)
    assert np.array_equal(anchors[0, :5], np.full(5, 0.01))
    assert np.array_equal(anchors[0, 5:], np.full(15, 0.01))
    assert np.array_equal(anchors[5, :5], np.ones(5))
    assert np.array_equal(anchors[5, 5:], np.full(15, 1e-4))


def test_theta_vector_contains_process_noise_only(science_contract: dict) -> None:
    scale = np.ones(7, dtype=np.float64)
    theta = common.anchor_theta_matrix(scale, science_contract)[0]
    assert theta.shape == (7,)
    q = common.decode_process_theta(torch.tensor(theta, dtype=torch.float64), scale)
    assert q.shape == (7,)
    outside = torch.tensor(theta, dtype=torch.float64)
    lower, _ = common.log_process_variance_bounds(scale, science_contract)
    outside[0] = lower[0] - 1.0
    with pytest.raises(ValueError, match="outside"):
        common.decode_process_theta(outside, scale)


def test_fixed_observation_noise_is_one_read_only_value_per_basin(
    frozen: common.FrozenInputs,
) -> None:
    values = common.load_fixed_observation_noise(frozen)
    assert tuple(values) == frozen.basin_ids
    assert len(values) == 455
    assert all(math.isfinite(value) and value > 0.0 for value in values.values())


def test_transfer_uses_even_log_median_and_excludes_receiver(
    frozen: common.FrozenInputs, donor_registry: dict
) -> None:
    receiver = "01047000"
    library = {
        basin: np.full(frozen.dimension_by_basin[basin], 0.01, dtype=np.float64)
        for basin in frozen.basin_ids
    }
    library[receiver][:] = 0.8
    donors = donor_registry["receivers"][receiver]["coordinates"][0]["donors"]
    assert len(donors) == 454
    for donor in donors[:227]:
        library[donor][0] = 0.001
    for donor in donors[227:]:
        library[donor][0] = 0.1
    transferred, evidence = common.transfer_ratios_from_local(
        library, frozen, donor_registry
    )
    assert transferred[receiver][0] == pytest.approx(0.01, rel=0.0, abs=1e-15)
    assert np.allclose(transferred[receiver][1:], 0.01, rtol=0.0, atol=1e-15)
    assert evidence[receiver]["coordinates"][0]["donor_count"] == 454


def test_transfer_rejects_incomplete_local_library(frozen: common.FrozenInputs) -> None:
    with pytest.raises(ValueError, match="exactly all 455"):
        transfer_module.build_transfer_vectors_in_memory(
            {
                frozen.basin_ids[0]: np.full(
                    frozen.dimension_by_basin[frozen.basin_ids[0]], 0.01
                )
            }
        )


def test_checkpoint_selection_uses_validation_then_training_then_actual_q() -> None:
    theta = np.log(
        np.asarray(
            [
                [0.2, 0.1],
                [0.1, 0.2],
                [0.3, 0.3],
            ],
            dtype=np.float64,
        )
    )
    training = np.asarray([2.0, 2.0, 1.0])
    validation = np.asarray([1.0, 1.0, 2.0])
    assert common.choose_checkpoint(theta, training, validation) == 1


def test_future_observations_do_not_change_earlier_filter_predictions(
    frozen: common.FrozenInputs, science_contract: dict
) -> None:
    parent_contract = common.read_json_strict(common.PARENT_CONFIG)
    basin = frozen.basin_ids[0]
    parameter_row = frozen.parameter_row(basin)
    observations = torch.linspace(0.2, 2.0, 12, dtype=torch.float64).reshape(-1, 1)
    context = common.build_causal_filter_context(
        basin, parameter_row, observations, parent_contract
    )
    forcing = torch.zeros((12, 1, 3), dtype=torch.float64)
    forcing[:, 0, 0] = 1.0
    forcing[:, 0, 1] = 5.0
    forcing[:, 0, 2] = 0.5
    changed = observations.clone()
    changed[7:] = changed[7:] + 100.0
    scale = np.ones(context.dimension, dtype=np.float64)
    theta = torch.tensor(
        common.anchor_theta_matrix(scale, science_contract)[0], dtype=torch.float64
    )
    original = common.run_scaled_filter(
        context, forcing, observations, theta, scale, 0.02, science_contract
    )
    altered = common.run_scaled_filter(
        context, forcing, changed, theta, scale, 0.02, science_contract
    )
    assert torch.equal(original["prediction"][:7], altered["prediction"][:7])
    assert torch.equal(original["posterior_state"][:7], altered["posterior_state"][:7])


def test_nash_sutcliffe_efficiency_uses_exact_mask() -> None:
    target = np.asarray([1.0, 2.0, 3.0, 100.0])
    prediction = np.asarray([1.0, 2.0, 4.0, -999.0])
    mask = np.asarray([True, True, True, False])
    assert evaluation.nash_sutcliffe_efficiency_on_mask(target, prediction, mask) == pytest.approx(0.5)


def test_common_index_bootstrap_preserves_exact_shift() -> None:
    base = np.linspace(-1.0, 1.0, 455)
    result = evaluation.common_index_bootstrap(
        {"base": base, "shifted": base + 0.25},
        seed=20260811,
        resamples=10000,
        confidence_level=0.95,
    )
    assert result["shifted"]["lower"] - result["base"]["lower"] == pytest.approx(0.25)
    assert result["shifted"]["upper"] - result["base"]["upper"] == pytest.approx(0.25)


def test_four_comparison_summary_reports_fixed_directions_and_decisions(
    frozen: common.FrozenInputs, science_contract: dict
) -> None:
    baseline = np.zeros((455, 3), dtype=np.float64)
    arms = {
        "original_filter_reference": baseline,
        "original_neural_ensemble_reference": baseline + 0.1,
        "local_scaled_process_noise": baseline + 0.2,
        "leave_one_basin_out_transfer_scaled_process_noise": baseline + 0.15,
    }
    summary = evaluation.summarize_four_comparisons(
        frozen.basin_ids, arms, science_contract=science_contract
    )
    assert tuple(summary["comparisons"]) == tuple(value[0] for value in evaluation.COMPARISONS)
    assert summary["comparisons"]["local_minus_original_filter"][
        "basin_mean_over_three_leads"
    ]["median"] == pytest.approx(0.2)
    assert summary["comparisons"]["transfer_minus_local"][
        "basin_mean_over_three_leads"
    ]["median"] == pytest.approx(-0.05)
    assert summary["comparisons"]["local_minus_original_neural_ensemble"][
        "retrospective_parent_decision"
    ]["verdict"] == "FILTER_PRACTICALLY_EXCEEDS_NEURAL_ENSEMBLE"
    assert summary["parent_verdict_overwritten"] is False


@pytest.mark.parametrize(
    "lower,upper,verdict",
    [
        (0.01, 0.02, "FILTER_PRACTICALLY_EXCEEDS_NEURAL_ENSEMBLE"),
        (-0.01, 0.02, "FILTER_REACHES_NEURAL_ENSEMBLE_WITHOUT_PROVEN_PRACTICAL_SUPERIORITY"),
        (-0.03, -0.01, "FILTER_BELOW_NEURAL_ENSEMBLE"),
        (-0.02, 0.0, "INCONCLUSIVE"),
    ],
)
def test_parent_decision_order_is_exact(lower: float, upper: float, verdict: str) -> None:
    assert evaluation.decision_from_interval(lower, upper)["verdict"] == verdict


def test_independent_population_parser_matches_frozen_inputs(
    frozen: common.FrozenInputs,
) -> None:
    basin_ids, dimensions = verifier._independent_population()
    assert basin_ids == frozen.basin_ids
    assert dimensions == dict(frozen.dimension_by_basin)
