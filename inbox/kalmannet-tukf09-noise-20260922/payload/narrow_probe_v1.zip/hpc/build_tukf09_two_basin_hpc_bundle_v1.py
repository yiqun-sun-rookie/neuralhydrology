"""Export only sealed training/validation data; never run a hydrological model."""
from __future__ import annotations
import ast
import json
from pathlib import Path
import shutil
import sys
import zipfile

from tukf09_two_basin_hpc_gate_v1 import (
    COUNTS, REMOTE_ROOT_POSIX, SAMPLES, STAGE, WINDOWS_ROOT, checked_path, digest,
    file_record, mapped_relative, read_json, verify_bundle,
)

ROOT = Path(__file__).resolve().parents[1]
CONTROL = ROOT / 'results/tukf09_455_scaled_noise_local_transfer_v1/control/two_basin_hpc_start_v1'
DESTINATION_CONTROL = Path('\\\\?\\' + str(CONTROL.resolve())) if sys.platform == 'win32' else CONTROL
SCALES = 'results/tukf09_455_scaled_noise_local_transfer_v1/state_scales_v1'
SCALE_SHA = '449ac52f3d16b8ae8b390f7a73f1a170b80d9a78d5b231ba8c403d01fc793702'


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, allow_nan=False, separators=(',', ':'))


def source_closure(paths):
    """Include original package initializers and recursively resolved local imports."""
    paths = set(paths)
    paths.update(p.relative_to(ROOT).as_posix() for p in (ROOT/'src/global_hydrology').rglob('*.py'))
    pending = list(paths)
    seen = set()
    while pending:
        relative = pending.pop()
        if relative in seen or not relative.endswith('.py'):
            continue
        seen.add(relative)
        tree = ast.parse((ROOT/relative).read_text(encoding='utf-8-sig'))
        modules = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                modules.extend(x.name for x in node.names)
            elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
                modules.append(node.module)
                modules.extend(node.module + '.' + x.name for x in node.names)
        for name in modules:
            for prefix in ('', 'src/', 'hpc/'):
                stem = prefix + name.replace('.', '/')
                for candidate in (stem + '.py', stem + '/__init__.py'):
                    if (ROOT/candidate).is_file() and candidate not in paths:
                        paths.add(candidate)
                        pending.append(candidate)
        for parent in Path(relative).parents:
            candidate = (parent/'__init__.py').as_posix()
            if (ROOT/candidate).is_file() and candidate not in paths:
                paths.add(candidate)
                pending.append(candidate)
    return paths


def build():
    sys.dont_write_bytecode = True
    sys.path[:0] = [str(ROOT), str(ROOT/'src')]
    from tukf09_455_state_scale_integrity_v2 import preexecution_source_check
    checks = preexecution_source_check()
    print('SOURCE_GATE_OK original_sources=13 model_calls=0', flush=True)
    from hpc import tukf09_455_scaled_noise_common_v1 as frozen
    import numpy as np
    context = frozen.load_parent_training_context()
    loaded = frozen.load_selected_training_validation(context, [b for b, _ in SAMPLES])
    fixed = frozen.load_fixed_observation_noise(frozen.load_frozen_inputs())
    science = frozen.load_science_contract()
    output = DESTINATION_CONTROL/'bundle_002'
    output.mkdir(parents=True, exist_ok=False)
    paths = set()
    for group in ('anchors', 'original_implementation_files', 'production_sources'):
        for key, record in checks[group].items():
            relative = record.get('path', key)
            if ':' in relative:
                relative = mapped_relative(relative)
            paths.add(relative)
    paths.update(['hpc/tukf09_455_state_scale_integrity_v2.py',
                  'hpc/tukf09_455_state_scale_generation_execution_authorization_v1.json',
                  'configs/tukf09_455_basin_zero_validation_target_variance_revision_v1.json'])
    prior = read_json(ROOT/'hpc/tukf09_455_state_scale_generation_execution_authorization_v1.json')
    paths.update(r['path'] for r in prior['prior_gate_bindings'].values())
    for record in (*science['lineage']['input_seals'].values(),
                   science['lineage']['parent_scientific_contract'],
                   science['lineage']['completed_parent_evidence']['filter_registry']):
        relative = record['path']
        if ':' in relative:
            relative = mapped_relative(relative)
        if digest(ROOT/relative) != record['sha256']:
            raise RuntimeError('frozen input changed: ' + relative)
        paths.add(relative)
    scale_manifest = ROOT/SCALES/'manifest.final.sha256.json'
    if digest(scale_manifest) != SCALE_SHA:
        raise RuntimeError('sealed scale manifest changed')
    paths.add(SCALES+'/manifest.final.sha256.json')
    scale_records = read_json(scale_manifest)['files']
    metadata = {'basins': {}, 'evaluation_array_reads': int(context.evaluation_access_count),
                'raw_file_policy': 'Full byte hashes checked; only training/validation dates parsed.',
                'raw_source_records': {k:v for k,v in context.raw_source_files.items()
                    if any(Path(k).name.startswith(b) for b,_ in SAMPLES)}}
    arrays = {}
    for basin, dimension in SAMPLES:
        for name in ('identity.json', 'summary.json', 'manifest.final.sha256.json', 'state_scale_arrays.npz'):
            relative = f'basin_{basin}/{name}'
            if file_record(ROOT/SCALES/relative) != scale_records[relative]:
                raise RuntimeError('sealed scale unit changed')
            paths.add(SCALES+'/'+relative)
        identity = read_json(ROOT/SCALES/f'basin_{basin}/identity.json')
        summary = read_json(ROOT/SCALES/f'basin_{basin}/summary.json')
        parameters = frozen.parameter_row_from_parent_context(context, basin)
        if parameters != dict(zip(identity['parameter_row']['parameter_names'], identity['parameter_row']['values'])):
            raise RuntimeError('parameter provenance mismatch')
        row = {'dimension': dimension, 'parameters': parameters, 'fixed_r_b': fixed[basin],
               'state_scale': summary['state_scale'], 'semantic_members': {}}
        for period in ('training', 'validation'):
            row['semantic_members'][period] = {}
            for name in ('dates_ns', 'forcing', 'observations'):
                arrays[f'{basin}/{period}/{name}'] = getattr(loaded[basin][period], name)
                row['semantic_members'][period][name] = context.semantic_members[period][f'{basin}/{name}']
        metadata['basins'][basin] = row
    if metadata['evaluation_array_reads'] != 0:
        raise PermissionError('evaluation access is forbidden')
    write_json(output/'input/local_source_check.json', checks)
    write_json(output/'input/metadata.json', metadata)
    write_json(output/'input/execution_authorization.json', {
        'stage_id': STAGE, 'authorized_mode': 'two-basin-one-update',
        'authorization_source': 'User requested actual isolated HPC model start, then go on 2026-09-22.',
        'remote_execution_authorized': True, 'formal_local_search_authorized': False,
        'evaluation_authorized': False, 'counts': COUNTS,
        'samples': [{'basin_id': b, 'dimension': d} for b,d in SAMPLES]})
    with (output/'input/training_validation.npz').open('xb') as stream:
        np.savez_compressed(stream, **arrays)
    paths.update(p.relative_to(ROOT).as_posix() for p in (ROOT/'hpc').glob('*two_basin_hpc*v1*') if p.is_file())
    paths = source_closure(paths)
    for relative in sorted(paths):
        source = checked_path(ROOT, relative)
        target = output/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with source.open('rb') as incoming, target.open('xb') as outgoing:
            shutil.copyfileobj(incoming, outgoing)
    records = {p.relative_to(output).as_posix(): file_record(p) for p in sorted(output.rglob('*')) if p.is_file()}
    write_json(output/'bundle_manifest.json', {'stage_id': STAGE,
        'path_mapping': {'windows_root': str(WINDOWS_ROOT), 'remote_root': REMOTE_ROOT_POSIX}, 'files': records})
    manifest_sha = digest(output/'bundle_manifest.json')
    gate = verify_bundle(output, manifest_sha, enforce_remote=False)
    with zipfile.ZipFile(DESTINATION_CONTROL/'narrow_probe_v1.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(output.rglob('*')):
            if path.is_file():
                archive.write(path, path.relative_to(output).as_posix())
    record = {'bundle_manifest_sha256': manifest_sha, 'archive': file_record(DESTINATION_CONTROL/'narrow_probe_v1.zip'),
              'source_gate': gate, 'model_calls': 0, 'evaluation_array_reads': 0}
    write_json(DESTINATION_CONTROL/'bundle_build_receipt.json', record)
    print(json.dumps(record), flush=True)


if __name__ == '__main__':
    build()
