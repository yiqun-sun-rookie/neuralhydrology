"""Execute the admitted 455-basin formal evaluation exactly once.

Importing this module performs no evaluation access.  The production command
constructs its loaders, selected checkpoints, predictors, capability, lock, and
fixed output paths automatically; production callers cannot inject scientific
dependencies.  Dependency injection remains available only to the nonproduction
library core used by isolated numerical tests.
"""

from __future__ import annotations

import argparse
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import date, datetime, timezone
from hashlib import sha256
from io import BytesIO
import json
import math
import os
from pathlib import Path, PurePosixPath
import shutil
import sys
from typing import Any, Callable, Mapping, Sequence
import uuid
import zipfile

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from hpc import tukf09_455_evaluation_common_compat_v5 as common


EXPERIMENT_ID = common.EXPERIMENT_ID
ROOT_RECORD_NAMES = frozenset(
    {
        "identity.json",
        "access_ledger.json",
        "evaluation_summary.json",
        "manifest.sha256.json",
    }
)
_PRODUCTION_ENTRY_TOKEN = object()
ATTEMPT_RECORD_NAME = "formal_evaluation_compat_v5_attempt.json"
CONSUMPTION_RECORD_NAME = "formal_evaluation_compat_v5_consumption.json"
FAILURE_RECORD_NAME = "formal_evaluation_compat_v5_failure.json"
SUCCESS_RECORD_NAME = "formal_evaluation_compat_v5_success.json"


def _absolute(path: str | Path) -> Path:
    return Path(os.path.abspath(os.fspath(path)))


def _safe_relative(text: str) -> PurePosixPath:
    relative = PurePosixPath(text)
    if (
        not text
        or relative.is_absolute()
        or "\\" in text
        or any(part in {"", ".", ".."} for part in relative.parts)
        or relative.as_posix() != text
    ):
        raise ValueError(f"unsafe evaluation relative path: {text!r}")
    return relative


def _npy_bytes(array: np.ndarray) -> bytes:
    buffer = BytesIO()
    np.lib.format.write_array(
        buffer,
        np.ascontiguousarray(array),
        allow_pickle=False,
        version=(2, 0),
    )
    return buffer.getvalue()


def deterministic_npz_bytes(arrays: Mapping[str, np.ndarray]) -> bytes:
    """Return an NPZ whose member order, metadata timestamps, and bytes are fixed."""

    buffer = BytesIO()
    with zipfile.ZipFile(
        buffer,
        mode="w",
        compression=zipfile.ZIP_STORED,
        allowZip64=True,
    ) as archive:
        for name in sorted(arrays):
            if not name or "/" in name or "\\" in name:
                raise ValueError(f"unsafe NPZ member name: {name!r}")
            info = zipfile.ZipInfo(f"{name}.npy", date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_STORED
            info.create_system = 0
            info.external_attr = 0
            archive.writestr(info, _npy_bytes(np.asarray(arrays[name])))
    return buffer.getvalue()


def _file_record(content: bytes) -> dict[str, Any]:
    return {"sha256": sha256(content).hexdigest(), "size_bytes": len(content)}


def _atomic_publish_directory(destination: Path, payloads: Mapping[str, bytes]) -> None:
    from scripts import tukf09_455_training_common as training_common

    target = _absolute(destination)
    training_common.ensure_no_symlink_components(target)
    if target.exists() or target.is_symlink():
        raise FileExistsError(f"formal evaluation destination already exists: {target}")
    target.parent.mkdir(parents=True, exist_ok=True)
    training_common.ensure_no_symlink_components(target.parent)
    token = uuid.uuid4().hex
    pending = target.with_name(f".pending-{token[:10]}")
    pending.mkdir(exist_ok=False)
    try:
        for relative_text, content in sorted(payloads.items()):
            relative = _safe_relative(relative_text)
            path = pending.joinpath(*relative.parts)
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("xb") as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
        actual = {
            path.relative_to(pending).as_posix()
            for path in pending.rglob("*")
            if path.is_file() and not path.is_symlink()
        }
        if actual != set(payloads):
            raise RuntimeError("pending formal evaluation member set changed")
        if target.exists() or target.is_symlink():
            raise FileExistsError("formal evaluation destination appeared during publication")
        os.replace(pending, target)
    finally:
        if pending.exists() or pending.is_symlink():
            if pending.parent != target.parent or token[:10] not in pending.name:
                raise RuntimeError("refusing to remove an unowned evaluation pending directory")
            shutil.rmtree(pending)


def _publish_failure_once(path: Path, payload: Mapping[str, Any]) -> None:
    content = common.canonical_json_bytes(payload)
    if path.exists() or path.is_symlink():
        if not path.is_dir() or path.is_symlink():
            raise FileExistsError("formal evaluation failure destination is invalid")
        members = [member for member in path.iterdir()]
        expected = path / "target_variance_failure.json"
        if members != [expected] or expected.is_symlink() or expected.read_bytes() != content:
            raise RuntimeError("existing formal evaluation failure evidence differs")
        return
    _atomic_publish_directory(path, {"target_variance_failure.json": content})


def _atomic_control_record(path: Path, payload: Mapping[str, Any]) -> dict[str, Any]:
    """Publish one immutable, self-hashed evaluation lifecycle record."""

    from scripts import tukf09_455_training_common as training_common

    destination = _absolute(path)
    if os.path.lexists(destination):
        raise FileExistsError(f"formal evaluation lifecycle record already exists: {destination}")
    training_common.ensure_no_symlink_components(destination.parent)
    destination.parent.mkdir(parents=True, exist_ok=True)
    training_common.ensure_no_symlink_components(destination.parent)
    unsigned = dict(payload)
    unsigned.pop("record_sha256", None)
    record = dict(unsigned)
    record["record_sha256"] = common.canonical_json_sha256(unsigned)
    content = common.canonical_json_bytes(record)
    temporary = destination.with_name(f".pending-{uuid.uuid4().hex[:10]}")
    try:
        with temporary.open("xb") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        if os.path.lexists(destination):
            raise FileExistsError("formal evaluation lifecycle destination appeared")
        os.replace(temporary, destination)
    finally:
        if os.path.lexists(temporary):
            temporary.unlink()
    return record


def _lifecycle_paths(results_root: Path) -> dict[str, Path]:
    control = _absolute(results_root) / "control"
    return {
        "attempt": control / ATTEMPT_RECORD_NAME,
        "consumption": control / CONSUMPTION_RECORD_NAME,
        "failure": control / FAILURE_RECORD_NAME,
        "success": control / SUCCESS_RECORD_NAME,
    }


def _assert_unused_lifecycle(paths: Mapping[str, Path]) -> None:
    existing = sorted(name for name, path in paths.items() if os.path.lexists(path))
    if existing:
        raise FileExistsError(
            "formal evaluation attempt was already consumed; silent retry is forbidden: "
            + ", ".join(existing)
        )


def _exception_evidence(exc: BaseException) -> dict[str, str]:
    return {
        "exception_type": f"{type(exc).__module__}.{type(exc).__qualname__}",
        "exception_message": str(exc),
    }


def _fixed_attempt_id(
    *, admission_sha256: str, output_root: Path, runtime_sha256: str
) -> str:
    return sha256(
        common.canonical_json_bytes(
            {
                "admission_sha256": admission_sha256,
                "output_root": os.fspath(_absolute(output_root)),
                "runtime_environment_identity_sha256": runtime_sha256,
            }
        )
    ).hexdigest()[:32]


def _reject_training_locks(control: Path) -> None:
    """Recursively reject every training controller/phase/sequence lock surface."""

    if not control.exists():
        return
    fixed = {
        ".training_phase.lock",
        ".filter_controller.lock",
        ".neural_controller.lock",
        ".sequence_controller.lock",
    }
    for path in control.rglob("*"):
        name = path.name.lower()
        if (
            name in fixed
            or name == "controller.lock"
            or name.endswith("_controller.lock")
            or name.endswith(".controller.lock")
        ):
            raise RuntimeError(f"training controller lock remains active or stale: {path}")


def _read_json(path: Path) -> dict[str, Any]:
    if not path.is_file() or path.is_symlink() or path.stat().st_nlink != 1:
        raise RuntimeError(f"formal evaluation JSON member is invalid: {path}")
    try:
        value = json.loads(path.read_bytes())
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"invalid formal evaluation JSON: {path}") from exc
    if not isinstance(value, dict):
        raise RuntimeError(f"formal evaluation JSON must be an object: {path}")
    return value


def _verify_existing_exact(
    output_root: Path,
    admitted_identity: Mapping[str, Any],
) -> dict[str, Any]:
    if not output_root.is_dir() or output_root.is_symlink():
        raise FileExistsError("formal evaluation output exists but is not an unlinked directory")
    identity = _read_json(output_root / "identity.json")
    manifest = _read_json(output_root / "manifest.sha256.json")
    summary = _read_json(output_root / "evaluation_summary.json")
    if (
        identity.get("experiment_id") != EXPERIMENT_ID
        or identity.get("admission_sha256") != admitted_identity.get("admission_sha256")
        or identity.get("attempt_id") != admitted_identity.get("attempt_id")
    ):
        raise RuntimeError("existing formal evaluation belongs to a different attempt")
    files = manifest.get("files")
    if not isinstance(files, dict) or int(manifest.get("file_count", -1)) != len(files):
        raise RuntimeError("existing formal evaluation manifest is malformed")
    actual_files = {
        path.relative_to(output_root).as_posix()
        for path in output_root.rglob("*")
        if path.is_file() and not path.is_symlink()
    }
    if actual_files != set(files) | {"manifest.sha256.json"}:
        raise RuntimeError("existing formal evaluation member set changed")
    for relative, record in files.items():
        path = output_root.joinpath(*_safe_relative(relative).parts)
        content = path.read_bytes()
        if record != _file_record(content):
            raise RuntimeError(f"existing formal evaluation hash changed: {relative}")
    result = dict(summary)
    result["reused"] = True
    return result


def _prediction_arrays(
    period: common.EvaluationPeriod,
    filter_predictions: Mapping[int, np.ndarray],
    seed_predictions: Mapping[int, Mapping[int, np.ndarray]],
    ensembles: Mapping[int, np.ndarray],
    scores: Mapping[int, common.ScoreRecord],
) -> dict[str, np.ndarray]:
    arrays: dict[str, np.ndarray] = {
        "dates_ns": period.dates_ns,
        "forcing": period.forcing,
        "target": period.observations,
    }
    for lead in common.FROZEN_LEADS:
        arrays[f"filter_lead_{lead}"] = np.asarray(filter_predictions[lead], dtype=np.float64)
        arrays[f"ensemble_lead_{lead}"] = np.asarray(ensembles[lead], dtype=np.float64)
        arrays[f"common_mask_lead_{lead}"] = np.asarray(scores[lead].mask, dtype=np.bool_)
        for seed in common.FROZEN_SEEDS:
            arrays[f"seed_lead_{lead}_seed_{seed}"] = np.asarray(
                seed_predictions[lead][seed], dtype=np.float64
            )
    return arrays


def _metrics_record(
    *,
    basin_id: str,
    scores: Mapping[int, common.ScoreRecord],
) -> dict[str, Any]:
    leads: dict[str, Any] = {}
    paired: list[float] = []
    for lead in common.FROZEN_LEADS:
        score = scores[lead]
        difference = float(score.filter_nse - score.ensemble_nse)
        paired.append(difference)
        leads[str(lead)] = {
            "support_count": score.support_count,
            "target_denominator_float64": score.target_denominator,
            "filter_nse": score.filter_nse,
            "neural_ensemble_nse": score.ensemble_nse,
            "filter_minus_neural_ensemble_nse": difference,
            "neural_seed_nse": {
                str(seed): score.seed_nse[index]
                for index, seed in enumerate(common.FROZEN_SEEDS)
            },
        }
    return {
        "schema_version": "tukf09_455_basin_evaluation_metrics_v1",
        "experiment_id": EXPERIMENT_ID,
        "basin_id": basin_id,
        "status": "BASIN_EVALUATION_COMPLETE_PENDING_INDEPENDENT_REPLAY",
        "leads": leads,
        "lead_mean_filter_minus_neural_ensemble_nse": float(np.mean(paired, dtype=np.float64)),
        "prediction_vector_count": 15,
        "primary_nse_count": 6,
        "supplemental_seed_nse_count": 9,
        "target_denominator_count": 3,
    }


@dataclass(frozen=True)
class ProductionEvaluationDependencies:
    admission_path: Path
    admission_sha256: str
    attempt_id: str
    output_root: Path
    ordered_basin_ids: tuple[str, ...]
    selection_sha256: str
    independent_selection_sha256: str
    lock_path: Path
    semantic_members: Mapping[str, Mapping[str, Any]]
    raw_reader: Any
    filter_predictor: Callable[[str, common.EvaluationPeriod], Mapping[int, np.ndarray]]
    neural_seed_predictor: Callable[
        [str, common.EvaluationPeriod], Mapping[int, Mapping[int, np.ndarray]]
    ]

    def issue_capability(self) -> common.EvaluationCapability:
        return common.issue_evaluation_capability(
            admission_path=self.admission_path,
            lock_path=self.lock_path,
            expected_selection_sha256=self.selection_sha256,
            expected_independent_selection_sha256=self.independent_selection_sha256,
            production=True,
        )

    def load_periods(
        self, capability: common.EvaluationCapability
    ) -> dict[str, common.EvaluationPeriod]:
        return common.load_evaluation_periods(
            capability,
            basin_ids=self.ordered_basin_ids,
            semantic_members=self.semantic_members,
            raw_loader=self.raw_reader.load,
            verify_raw_sources=self.raw_reader.verify_sources,
            expected_raw_source_count=common.FROZEN_RAW_SOURCE_COUNT,
            expected_semantic_aggregate_sha256=common.FROZEN_EVALUATION_SEMANTIC_SHA256,
            production=True,
        )


class _ProductionRawEvaluationReader:
    def __init__(
        self,
        *,
        contract: Mapping[str, Any],
        basin_ids: Sequence[str],
        raw_files: Mapping[str, Mapping[str, Any]],
    ) -> None:
        self.contract = contract
        self.basin_ids = tuple(basin_ids)
        self.raw_files = dict(raw_files)
        self.data_root = Path(str(contract["paths"]["data_root"]))
        self.verified = False
        self.paths: dict[str, tuple[Path, Path]] = {}
        self.areas: dict[str, float] = {}

    def verify_sources(self) -> int:
        from scripts import tukf09_training_common as training_common

        if self.verified:
            # An identical in-lock retry rehashes rather than trusting mutable state.
            self.verified = False
        for relative_text, record in sorted(self.raw_files.items()):
            relative = PurePosixPath(relative_text)
            if relative.is_absolute() or any(part in {"", ".", ".."} for part in relative.parts):
                raise RuntimeError(f"unsafe raw-source path: {relative_text}")
            path = training_common.require_regular_unlinked_file(
                self.data_root.joinpath(*relative.parts),
                label="formal evaluation raw source",
                stop_at=self.data_root,
            )
            if path.stat().st_size != int(record["size_bytes"]) or common.sha256_file(path) != record["sha256"]:
                raise RuntimeError(f"formal evaluation raw-source hash changed: {relative_text}")
        if len(self.raw_files) != common.FROZEN_RAW_SOURCE_COUNT:
            raise RuntimeError("formal evaluation raw-source count changed")
        all_paths = training_common._raw_paths_by_basin(self.raw_files, self.data_root)
        if not set(self.basin_ids).issubset(all_paths):
            raise RuntimeError("formal evaluation raw-source basin coverage changed")
        self.paths = {basin: all_paths[basin] for basin in self.basin_ids}
        self.areas = training_common._load_area_by_basin(self.data_root, self.basin_ids)
        self.verified = True
        return len(self.raw_files)

    @staticmethod
    def _layout() -> tuple[np.ndarray, dict[int, int]]:
        ordinals = np.arange(
            date.fromisoformat(common.FROZEN_EVALUATION_START).toordinal(),
            date.fromisoformat(common.FROZEN_EVALUATION_END).toordinal() + 1,
            dtype=np.int64,
        )
        if len(ordinals) != common.FROZEN_EVALUATION_DAY_COUNT:
            raise AssertionError("frozen evaluation date layout changed")
        return ordinals, {int(value): index for index, value in enumerate(ordinals)}

    def load(self, basin_id: str) -> common.EvaluationPeriod:
        if not self.verified:
            raise PermissionError("raw sources must be hash-verified before evaluation loading")
        flow_path, forcing_path = self.paths[basin_id]
        ordinals, lookup = self._layout()
        flow = np.empty(len(ordinals), dtype=np.float64)
        flow_counts = np.zeros(len(ordinals), dtype=np.int16)
        prior: int | None = None
        with flow_path.open("r", encoding="utf-8") as handle:
            for line in handle:
                fields = line.split()
                if len(fields) < 5:
                    continue
                try:
                    ordinal = date(int(fields[1]), int(fields[2]), int(fields[3])).toordinal()
                except (TypeError, ValueError):
                    continue
                index = lookup.get(ordinal)
                if index is None:
                    continue
                if prior is not None and ordinal <= prior:
                    raise RuntimeError(f"evaluation flow dates are not strictly increasing: {basin_id}")
                prior = ordinal
                value = float(fields[4])
                if not math.isfinite(value) or value < 0.0:
                    raise RuntimeError(f"evaluation discharge is invalid: {basin_id}")
                flow_counts[index] += 1
                flow[index] = value
        if not np.all(flow_counts == 1):
            raise RuntimeError(f"evaluation discharge support is incomplete: {basin_id}")
        observations = np.ascontiguousarray(
            flow * (2.4466 / self.areas[basin_id]), dtype=np.dtype("<f8")
        )

        raw = np.empty((len(ordinals), 5), dtype=np.float64)
        forcing_counts = np.zeros(len(ordinals), dtype=np.int16)
        prior = None
        with forcing_path.open("r", encoding="utf-8") as handle:
            for line in handle:
                fields = line.split()
                if len(fields) < 10:
                    continue
                try:
                    ordinal = date(int(fields[0]), int(fields[1]), int(fields[2])).toordinal()
                except (TypeError, ValueError):
                    continue
                index = lookup.get(ordinal)
                if index is None:
                    continue
                if prior is not None and ordinal <= prior:
                    raise RuntimeError(f"evaluation forcing dates are not strictly increasing: {basin_id}")
                prior = ordinal
                row = tuple(float(fields[position]) for position in (4, 5, 6, 8, 9))
                if not all(math.isfinite(value) for value in row):
                    raise RuntimeError(f"evaluation forcing is invalid: {basin_id}")
                forcing_counts[index] += 1
                raw[index] = row
        if not np.all(forcing_counts == 1):
            raise RuntimeError(f"evaluation forcing support is incomplete: {basin_id}")
        day_length = raw[:, 0]
        precipitation = raw[:, 1]
        shortwave = raw[:, 2]
        temperature = (raw[:, 3] + raw[:, 4]) / 2.0
        potential_evapotranspiration = np.where(
            temperature > -5.0,
            (shortwave * day_length / 1.0e6) * (temperature + 5.0) / 245.0,
            0.0,
        )
        forcing = np.ascontiguousarray(
            np.stack(
                [precipitation, temperature, np.maximum(potential_evapotranspiration, 0.0)],
                axis=-1,
            ),
            dtype=np.dtype("<f8"),
        )
        dates = np.arange(
            np.datetime64(common.FROZEN_EVALUATION_START, "D"),
            np.datetime64(common.FROZEN_EVALUATION_END, "D") + np.timedelta64(1, "D"),
            dtype="datetime64[D]",
        ).astype("datetime64[ns]").view("<i8")
        return common.EvaluationPeriod(
            basin_id=basin_id,
            dates_ns=dates,
            forcing=forcing,
            observations=observations,
            production=True,
        )


def _verified_json(path: Path) -> dict[str, Any]:
    return _read_json(_require_regular_file(path))


def _require_regular_file(path: Path) -> Path:
    from scripts import tukf09_455_training_common as training_common

    training_common.ensure_no_symlink_components(path)
    if not path.is_file() or path.is_symlink() or path.stat().st_nlink != 1:
        raise RuntimeError(f"fixed production artifact is absent or linked: {path}")
    return path


def _verify_record(path: Path, record: Mapping[str, Any], *, label: str) -> None:
    source = _require_regular_file(path)
    if record != {"sha256": common.sha256_file(source), "size_bytes": source.stat().st_size}:
        raise RuntimeError(f"{label} hash or size changed")


def build_production_dependencies(
    *,
    project_root: str | Path,
    admission_path: str | Path,
    lock_path: str | Path,
) -> ProductionEvaluationDependencies:
    """Construct the only production loaders and predictors from fixed sealed artifacts."""

    import torch
    from hpc import admit_tukf09_455_formal_evaluation_compat_v5 as admission_module
    from scripts import run_tukf09_filter_training as filter_training
    from scripts.tukf07_information_matched_model import DirectAutoregressiveLSTM

    root = _absolute(project_root)
    admitted = admission_module.load_and_verify_evaluation_admission(
        admission_path, production=True
    )
    record = admitted.record
    bindings = record["bindings"]
    contract = _verified_json(Path(bindings["scientific_contract"]["path"]))
    evaluation_config = _verified_json(Path(bindings["formal_evaluation_config"]["path"]))
    output_root = root / str(evaluation_config["paths"]["formal_evaluation"])
    if _absolute(record["evaluation_output_root"]) != _absolute(output_root):
        raise RuntimeError("admitted formal evaluation output path changed")
    results_root = root / str(evaluation_config["paths"]["results_root"])
    preflight_final_path = Path(bindings["independent_preflight_final_manifest"]["path"])
    preflight_root = preflight_final_path.parent.parent
    final = _verified_json(preflight_final_path)
    final_files = final.get("files")
    if not isinstance(final_files, dict):
        raise RuntimeError("independent preflight final manifest changed")
    for relative in (
        "population_registry.json",
        "parameters_only.npz",
        "raw_source_manifest.sha256.json",
        "semantic_input_manifest.sha256.json",
    ):
        _verify_record(preflight_root / relative, final_files[relative], label=f"preflight {relative}")
    population = _verified_json(preflight_root / "population_registry.json")
    ordered = tuple(str(value) for value in population.get("eligible", ()))
    if (
        len(ordered) != common.FROZEN_BASIN_COUNT
        or common.EXCLUDED_BASIN_ID in ordered
        or sha256("".join(f"{value}\n" for value in ordered).encode("utf-8")).hexdigest()
        != common.FROZEN_ORDERED_BASIN_NEWLINE_SHA256
    ):
        raise RuntimeError("fixed production population changed")
    with np.load(_require_regular_file(preflight_root / "parameters_only.npz"), allow_pickle=False) as archive:
        if set(archive.files) != {"basin_ids", "parameter_names", "values"}:
            raise RuntimeError("parameter-only archive member set changed")
        parameter_ids = tuple(str(value) for value in archive["basin_ids"].tolist())
        parameter_names = tuple(str(value) for value in archive["parameter_names"].tolist())
        parameter_values = np.asarray(archive["values"], dtype=np.float64).copy()
    if parameter_ids != ordered or parameter_values.shape != (455, 13) or not np.isfinite(parameter_values).all():
        raise RuntimeError("parameter-only population or values changed")
    parameter_rows = {
        basin: {name: float(parameter_values[index, column]) for column, name in enumerate(parameter_names)}
        for index, basin in enumerate(ordered)
    }
    semantic_manifest = _verified_json(preflight_root / "semantic_input_manifest.sha256.json")
    all_semantic = semantic_manifest.get("members")
    if not isinstance(all_semantic, dict):
        raise RuntimeError("semantic input manifest changed")
    semantic_members = {
        key: dict(value)
        for key, value in all_semantic.items()
        if key.split("/")[1] == "evaluation"
    }
    if len(semantic_members) != common.FROZEN_SEMANTIC_MEMBER_COUNT or sha256(common.canonical_json_bytes(semantic_members)[:-1]).hexdigest() != common.FROZEN_EVALUATION_SEMANTIC_SHA256:
        raise RuntimeError("evaluation semantic identity changed")
    raw_manifest = _verified_json(preflight_root / "raw_source_manifest.sha256.json")
    raw_files = raw_manifest.get("files")
    if not isinstance(raw_files, dict) or len(raw_files) != common.FROZEN_RAW_SOURCE_COUNT:
        raise RuntimeError("raw-source identity manifest changed")

    selection_seal_path = Path(bindings["training_selection_seal"]["path"])
    selection_seal = _verified_json(selection_seal_path)
    training_manifest_path = results_root / str(selection_seal["training_manifest_relative_path"])
    if common.sha256_file(training_manifest_path) != selection_seal["training_manifest_sha256"]:
        raise RuntimeError("training selection manifest changed")
    training_manifest = _verified_json(training_manifest_path)
    tree = training_manifest.get("files")
    if not isinstance(tree, dict):
        raise RuntimeError("training selection manifest file tree changed")
    filter_registry_path = results_root / "selection/filter_registry.json"
    neural_registry_path = results_root / "selection/neural_registry.json"
    selected_summary_path = results_root / "selection/selected_model_summary.json"
    for relative, path in (
        ("selection/filter_registry.json", filter_registry_path),
        ("selection/neural_registry.json", neural_registry_path),
        ("selection/selected_model_summary.json", selected_summary_path),
    ):
        _verify_record(path, tree[relative], label=relative)
    filter_registry = _verified_json(filter_registry_path)
    neural_registry = _verified_json(neural_registry_path)
    selected_summary = _verified_json(selected_summary_path)
    if (
        selected_summary.get("filter_registry_sha256") != common.sha256_file(filter_registry_path)
        or selected_summary.get("neural_registry_sha256") != common.sha256_file(neural_registry_path)
    ):
        raise RuntimeError("selected model summary registry hashes changed")
    filter_units = filter_registry.get("units")
    neural_units = neural_registry.get("units")
    if not isinstance(filter_units, list) or [unit.get("basin_id") for unit in filter_units] != list(ordered):
        raise RuntimeError("selected filter registry order changed")
    if not isinstance(neural_units, list) or [
        (unit.get("lead_days"), unit.get("seed")) for unit in neural_units
    ] != [(lead, seed) for lead in common.FROZEN_LEADS for seed in common.FROZEN_SEEDS]:
        raise RuntimeError("selected neural registry order changed")

    filter_specs: dict[str, dict[str, Any]] = {}
    filter_contexts: dict[str, Any] = {}
    for unit in filter_units:
        basin = str(unit["basin_id"])
        unit_root = results_root / str(unit["unit_relative_path"])
        manifest_path = unit_root / "manifest.sha256.json"
        if common.sha256_file(manifest_path) != unit["unit_manifest_sha256"]:
            raise RuntimeError(f"selected filter unit manifest changed: {basin}")
        unit_manifest = _verified_json(manifest_path)
        for name in ("identity.json", "selection.json"):
            _verify_record(unit_root / name, unit_manifest["files"][name], label=f"filter {basin} {name}")
        identity = _verified_json(unit_root / "identity.json")
        selection = _verified_json(unit_root / "selection.json")
        if (
            selection.get("selected_process_diagonal") != unit.get("selected_process_diagonal")
            or selection.get("selected_r_b") != unit.get("selected_r_b")
            or int(identity.get("state_dimension", -1)) != len(selection["selected_process_diagonal"])
        ):
            raise RuntimeError(f"selected filter identity changed: {basin}")
        dummy = np.asarray([0.0, 1.0], dtype=np.float64)
        context = filter_training.build_causal_filter_context(
            basin, parameter_rows[basin], dummy, contract
        )
        expected_initial = np.asarray(identity["initial_state"], dtype=np.float64)
        if not np.array_equal(context.initial_state[0].numpy(), expected_initial):
            raise RuntimeError(f"selected filter initial state changed: {basin}")
        base_variance = float(identity["base_observation_variance"])
        if not math.isfinite(base_variance) or base_variance <= 0.0:
            raise RuntimeError(f"selected filter base observation variance changed: {basin}")
        context.base_observation_variance = base_variance
        filter_contexts[basin] = context
        filter_specs[basin] = {
            "initial_state": expected_initial,
            "base_observation_variance": base_variance,
            "process_diagonal": np.asarray(selection["selected_process_diagonal"], dtype=np.float64),
            "r_b": float(selection["selected_r_b"]),
            "theta_log": np.asarray(selection["selected_theta_log"], dtype=np.float64),
        }

    scaler_path = results_root / str(neural_registry["training_scaler_relative_path"])
    if common.sha256_file(scaler_path) != neural_registry["training_scaler_sha256"]:
        raise RuntimeError("selected training-only neural scaler changed")
    scaler = _verified_json(scaler_path)
    if scaler.get("basin_ids") != list(ordered) or scaler.get("normalization_scope") != "training_only_global_population_statistics":
        raise RuntimeError("selected training-only neural scaler population changed")
    if not torch.cuda.is_available():
        raise RuntimeError("production formal evaluation requires CUDA for sealed neural replay")
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    device = torch.device("cuda")
    models: dict[tuple[int, int], Any] = {}
    checkpoint_hashes: dict[tuple[int, int], str] = {}
    for unit in neural_units:
        lead, seed = int(unit["lead_days"]), int(unit["seed"])
        checkpoint_path = results_root / str(unit["selected_checkpoint_relative_path"])
        current_hash = common.sha256_file(checkpoint_path)
        if current_hash != unit["selected_checkpoint_sha256"]:
            raise RuntimeError(f"selected neural checkpoint changed: lead {lead}, seed {seed}")
        checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
        if (
            checkpoint.get("experiment_id") != EXPERIMENT_ID
            or checkpoint.get("unit_id") != unit["unit_id"]
            or int(checkpoint.get("epoch", -1)) != int(unit["selected_epoch"])
            or checkpoint.get("training_scaler_sha256") != neural_registry["training_scaler_sha256"]
            or checkpoint.get("evaluation_access_count") != 0
        ):
            raise RuntimeError(f"selected neural checkpoint identity changed: lead {lead}, seed {seed}")
        model = DirectAutoregressiveLSTM(lead_days=lead).to(device)
        model.load_state_dict(checkpoint["model_state"], strict=True)
        model.eval()
        models[(lead, seed)] = model
        checkpoint_hashes[(lead, seed)] = current_hash

    def filter_predictor(basin: str, period: common.EvaluationPeriod) -> dict[int, np.ndarray]:
        context = filter_contexts[basin]
        spec = filter_specs[basin]
        forcing = torch.as_tensor(period.forcing, dtype=torch.float64).unsqueeze(1)
        observations = torch.as_tensor(period.observations, dtype=torch.float64).unsqueeze(1)

        def runner(
            _period: common.EvaluationPeriod,
            initial_state: np.ndarray,
            base_observation_variance: float,
            process_diagonal: np.ndarray,
            observation_noise_multiplier: float,
        ) -> dict[int, np.ndarray]:
            if (
                not np.array_equal(initial_state, spec["initial_state"])
                or base_observation_variance != spec["base_observation_variance"]
                or not np.array_equal(process_diagonal, spec["process_diagonal"])
                or observation_noise_multiplier != spec["r_b"]
            ):
                raise RuntimeError(f"selected filter evaluation identity changed: {basin}")
            result = filter_training.run_parameterized_filter(
                context,
                forcing,
                observations,
                torch.as_tensor(spec["theta_log"], dtype=torch.float64),
                contract,
            )
            forecasts = filter_training.multilead_torch(
                context.plain_model, result["posterior_state"][:, 0, :], forcing
            )
            aligned: dict[int, np.ndarray] = {}
            for lead, (prediction, indices) in forecasts.items():
                values = np.full(len(period.dates_ns), np.nan, dtype=np.float64)
                values[indices.detach().cpu().numpy()] = prediction.detach().cpu().numpy()
                aligned[int(lead)] = values
            return aligned

        return common.evaluate_filter(
            period,
            initial_state=spec["initial_state"],
            base_observation_variance=spec["base_observation_variance"],
            process_diagonal=spec["process_diagonal"],
            observation_noise_multiplier=spec["r_b"],
            runner=runner,
            production=True,
        )

    def neural_predictor(
        _basin: str, period: common.EvaluationPeriod
    ) -> dict[int, dict[int, np.ndarray]]:
        predictions: dict[int, dict[int, np.ndarray]] = {}
        for lead in common.FROZEN_LEADS:
            predictions[lead] = {}
            for seed in common.FROZEN_SEEDS:
                digest = checkpoint_hashes[(lead, seed)]
                predictions[lead][seed] = common.evaluate_neural_seed(
                    period,
                    lead_days=lead,
                    model=models[(lead, seed)],
                    scaler=scaler,
                    selected_checkpoint_sha256=digest,
                    current_checkpoint_sha256=digest,
                    production=True,
                )[lead]
        return predictions

    raw_reader = _ProductionRawEvaluationReader(
        contract=contract, basin_ids=ordered, raw_files=raw_files
    )
    runtime_sha256 = record.get("runtime_environment_identity_sha256")
    if not isinstance(runtime_sha256, str) or len(runtime_sha256) != 64:
        raise RuntimeError("admitted runtime identity is absent")
    attempt_id = _fixed_attempt_id(
        admission_sha256=admitted.file_sha256,
        output_root=output_root,
        runtime_sha256=runtime_sha256,
    )
    return ProductionEvaluationDependencies(
        admission_path=Path(admission_path),
        admission_sha256=admitted.file_sha256,
        attempt_id=attempt_id,
        output_root=output_root,
        ordered_basin_ids=ordered,
        selection_sha256=record["selection_sha256"],
        independent_selection_sha256=record["independent_selection_sha256"],
        lock_path=Path(lock_path),
        semantic_members=semantic_members,
        raw_reader=raw_reader,
        filter_predictor=filter_predictor,
        neural_seed_predictor=neural_predictor,
    )


@contextmanager
def _formal_evaluation_lock(
    *,
    results_root: Path,
    admission_sha256: str,
    runtime_environment_identity_sha256: str,
) -> Any:
    from scripts import tukf09_455_training_common as training_common

    control = results_root / "control"
    training_common.ensure_no_symlink_components(control)
    control.mkdir(parents=True, exist_ok=True)
    training_common.ensure_no_symlink_components(control)
    _reject_training_locks(control)
    lock_path = control / ".formal_evaluation.lock.json"
    if os.path.lexists(lock_path):
        raise RuntimeError("formal evaluation lock is active or stale and requires manual audit")
    lock_identity = uuid.uuid4().hex
    record = {
        "schema_version": "tukf09_455_formal_evaluation_lock_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "FORMAL_EVALUATION_LOCK_HELD",
        "lock_identity": lock_identity,
        "admission_sha256": admission_sha256,
        "runtime_environment_identity_sha256": runtime_environment_identity_sha256,
        "process_id": os.getpid(),
    }
    content = common.canonical_json_bytes(record)
    with lock_path.open("xb") as handle:
        handle.write(content)
        handle.flush()
        os.fsync(handle.fileno())
    try:
        yield lock_path
    finally:
        if not lock_path.is_file() or lock_path.is_symlink() or lock_path.read_bytes() != content:
            raise RuntimeError("formal evaluation lock identity changed or disappeared")
        lock_path.unlink()


def run_formal_evaluation_from_fixed_artifacts(
    *, authorize: bool, project_root: str | Path = ROOT
) -> dict[str, Any]:
    """Fixed production entry: no scientific loader or predictor can be injected."""

    if authorize is not True:
        raise PermissionError("explicit one-time formal evaluation execution is required")
    from hpc import admit_tukf09_455_formal_evaluation_compat_v5 as admission_module

    root = _absolute(project_root)
    config_path = root / "configs/tukf09_455_basin_zero_validation_target_variance_formal_evaluation_v1.json"
    config = _verified_json(config_path)
    expected_paths = {
        "results_root": "results/tukf09_455_basin_zero_validation_target_variance_revision_v1",
        "formal_evaluation": (
            "results/tukf09_455_basin_zero_validation_target_variance_revision_v1/evaluation"
        ),
        "evaluation_summary": (
            "results/tukf09_455_basin_zero_validation_target_variance_revision_v1/"
            "evaluation/evaluation_summary.json"
        ),
        "independent_evaluation": (
            "results/tukf09_455_basin_zero_validation_target_variance_revision_v1/"
            "evaluation_independent"
        ),
    }
    if any(config.get("paths", {}).get(key) != value for key, value in expected_paths.items()):
        raise RuntimeError("fixed formal evaluation output paths changed")
    admission_path = root / admission_module.compat.ADMISSION_RELATIVE
    prelock = admission_module.load_and_verify_evaluation_admission(
        admission_path, production=True
    )
    results_root = root / str(config["paths"]["results_root"])
    output_root = root / expected_paths["formal_evaluation"]
    lifecycle = _lifecycle_paths(results_root)
    _assert_unused_lifecycle(lifecycle)
    if os.path.lexists(output_root):
        raise FileExistsError("formal evaluation output already exists; retry is forbidden")
    runtime_sha256 = prelock.record.get("runtime_environment_identity_sha256")
    if not isinstance(runtime_sha256, str) or len(runtime_sha256) != 64:
        raise RuntimeError("formal evaluation admission runtime identity is absent")
    with _formal_evaluation_lock(
        results_root=results_root,
        admission_sha256=prelock.file_sha256,
        runtime_environment_identity_sha256=runtime_sha256,
    ) as lock_path:
        attempt_id = _fixed_attempt_id(
            admission_sha256=prelock.file_sha256,
            output_root=output_root,
            runtime_sha256=runtime_sha256,
        )
        attempt = _atomic_control_record(
            lifecycle["attempt"],
            {
                "schema_version": "tukf09_455_formal_evaluation_attempt_v1",
                "experiment_id": EXPERIMENT_ID,
                "status": "FORMAL_EVALUATION_ATTEMPT_REGISTERED_ZERO_ACCESS",
                "created_utc": datetime.now(timezone.utc).isoformat(),
                "attempt_id": attempt_id,
                "admission_sha256": prelock.file_sha256,
                "lock_sha256": common.sha256_file(lock_path),
                "runtime_environment_identity_sha256": runtime_sha256,
                "evaluation_output_root": os.fspath(_absolute(output_root)),
                "evaluation_arrays_loaded": False,
                "evaluation_access_ledger": dict(common.ZERO_EVALUATION_ACCESS_LEDGER),
                "retry_allowed": False,
            },
        )
        try:
            # This call is deliberately repeated after lock acquisition; it recomputes
            # the full Python/NumPy/PyTorch/CUDA/GPU/driver identity and the sealed tree.
            inside = admission_module.load_and_verify_evaluation_admission(
                admission_path, production=True
            )
            if inside.file_sha256 != prelock.file_sha256:
                raise RuntimeError("formal evaluation admission changed during lock acquisition")

            def consume_once() -> None:
                _atomic_control_record(
                    lifecycle["consumption"],
                    {
                        "schema_version": "tukf09_455_formal_evaluation_consumption_v1",
                        "experiment_id": EXPERIMENT_ID,
                        "status": "FORMAL_EVALUATION_ACCESS_CONSUMED_BEFORE_FIRST_ARRAY_READ",
                        "created_utc": datetime.now(timezone.utc).isoformat(),
                        "attempt_id": attempt_id,
                        "attempt_record_sha256": attempt["record_sha256"],
                        "admission_sha256": inside.file_sha256,
                        "evaluation_access_consumed": True,
                        "evaluation_array_read_attempts": 1,
                        "evaluation_arrays_loaded_at_publication": False,
                        "retry_allowed": False,
                    },
                )

            dependencies = build_production_dependencies(
                project_root=root,
                admission_path=admission_path,
                lock_path=lock_path,
            )
            if dependencies.attempt_id != attempt_id:
                raise RuntimeError("fixed formal evaluation attempt identity changed")
            result = run_formal_evaluation(
                authorize=True,
                output_root=dependencies.output_root,
                ordered_basin_ids=dependencies.ordered_basin_ids,
                admitted_identity={
                    "admission_sha256": dependencies.admission_sha256,
                    "attempt_id": dependencies.attempt_id,
                },
                acquire_verified_capability=dependencies.issue_capability,
                period_loader=dependencies.load_periods,
                filter_predictor=dependencies.filter_predictor,
                neural_seed_predictor=dependencies.neural_seed_predictor,
                consume_evaluation_access=consume_once,
                production=True,
                _production_token=_PRODUCTION_ENTRY_TOKEN,
            )
            summary_path = root / expected_paths["evaluation_summary"]
            manifest_path = output_root / "manifest.sha256.json"
            ledger_path = output_root / "access_ledger.json"
            success = _atomic_control_record(
                lifecycle["success"],
                {
                    "schema_version": "tukf09_455_formal_evaluation_success_v1",
                    "experiment_id": EXPERIMENT_ID,
                    "status": "FORMAL_EVALUATION_OUTPUT_PUBLISHED_RETRY_FORBIDDEN",
                    "created_utc": datetime.now(timezone.utc).isoformat(),
                    "attempt_id": attempt_id,
                    "attempt_record_sha256": attempt["record_sha256"],
                    "consumption_record_sha256": common.sha256_file(
                        lifecycle["consumption"]
                    ),
                    "evaluation_summary_path": os.fspath(_absolute(summary_path)),
                    "evaluation_summary_sha256": common.sha256_file(summary_path),
                    "evaluation_manifest_sha256": common.sha256_file(manifest_path),
                    "evaluation_access_ledger_sha256": common.sha256_file(ledger_path),
                    "retry_allowed": False,
                },
            )
            returned = dict(result)
            returned["attempt_record_sha256"] = attempt["record_sha256"]
            returned["success_record_sha256"] = success["record_sha256"]
            return returned
        except BaseException as exc:
            consumption_exists = os.path.lexists(lifecycle["consumption"])
            _atomic_control_record(
                lifecycle["failure"],
                {
                    "schema_version": "tukf09_455_formal_evaluation_failure_v1",
                    "experiment_id": EXPERIMENT_ID,
                    "status": "FORMAL_EVALUATION_FAILED_RETRY_FORBIDDEN",
                    "created_utc": datetime.now(timezone.utc).isoformat(),
                    "attempt_id": attempt_id,
                    "attempt_record_sha256": attempt["record_sha256"],
                    "evaluation_access_consumed": consumption_exists,
                    "consumption_record_sha256": (
                        common.sha256_file(lifecycle["consumption"])
                        if consumption_exists
                        else None
                    ),
                    "evaluation_output_exists": os.path.lexists(output_root),
                    "retry_allowed": False,
                    **_exception_evidence(exc),
                },
            )
            raise


def run_formal_evaluation(
    *,
    authorize: bool,
    output_root: str | Path,
    ordered_basin_ids: Sequence[str],
    admitted_identity: Mapping[str, Any],
    acquire_verified_capability: Callable[[], Any],
    period_loader: Callable[[Any], Mapping[str, common.EvaluationPeriod]],
    filter_predictor: Callable[[str, common.EvaluationPeriod], Mapping[int, np.ndarray]],
    neural_seed_predictor: Callable[
        [str, common.EvaluationPeriod], Mapping[int, Mapping[int, np.ndarray]]
    ],
    consume_evaluation_access: Callable[[], None] | None = None,
    first_scoring_index: int = common.FROZEN_FIRST_SCORING_INDEX,
    expected_supports: Mapping[int, int] | None = None,
    bootstrap_seed: int = common.FROZEN_BOOTSTRAP_SEED,
    bootstrap_resamples: int = common.FROZEN_BOOTSTRAP_RESAMPLES,
    production: bool = True,
    _production_token: object | None = None,
) -> dict[str, Any]:
    """Run the one-time evaluation after the caller acquires its verified lock."""

    if authorize is not True:
        raise PermissionError("explicit one-time formal evaluation execution is required")
    if production and _production_token is not _PRODUCTION_ENTRY_TOKEN:
        raise PermissionError("production evaluation is available only through the fixed entry")
    target = _absolute(output_root)
    if not isinstance(admitted_identity, Mapping):
        raise PermissionError("formal evaluation admission identity is required")
    admission_sha256 = admitted_identity.get("admission_sha256")
    attempt_id = admitted_identity.get("attempt_id")
    if not isinstance(admission_sha256, str) or len(admission_sha256) != 64:
        raise PermissionError("formal evaluation admission SHA-256 is invalid")
    if not isinstance(attempt_id, str) or not attempt_id or any(
        character not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_"
        for character in attempt_id
    ):
        raise PermissionError("formal evaluation attempt identity is invalid")
    if production and os.path.lexists(target):
        raise FileExistsError("formal evaluation output already exists; retry is forbidden")
    if target.exists() or target.is_symlink():
        return _verify_existing_exact(target, admitted_identity)

    ordered = tuple(str(value) for value in ordered_basin_ids)
    if not ordered or len(set(ordered)) != len(ordered):
        raise ValueError("formal evaluation population is empty or duplicated")
    if common.EXCLUDED_BASIN_ID in ordered:
        raise ValueError(f"excluded basin is forbidden: {common.EXCLUDED_BASIN_ID}")
    if production:
        if len(ordered) != common.FROZEN_BASIN_COUNT:
            raise ValueError("formal evaluation requires exactly 455 basins")
        if int(first_scoring_index) != common.FROZEN_FIRST_SCORING_INDEX:
            raise ValueError("formal evaluation first scoring index changed")
        if int(bootstrap_seed) != common.FROZEN_BOOTSTRAP_SEED or int(bootstrap_resamples) != common.FROZEN_BOOTSTRAP_RESAMPLES:
            raise ValueError("formal evaluation paired-basin bootstrap settings changed")

    # This callback must acquire the lock and repeat every upstream identity check.
    capability = acquire_verified_capability()
    if production and not isinstance(capability, common.EvaluationCapability):
        raise PermissionError("production period access requires a verified EvaluationCapability")
    if production and consume_evaluation_access is None:
        raise PermissionError("production evaluation requires immutable access consumption")
    if consume_evaluation_access is not None:
        consume_evaluation_access()
    periods = period_loader(capability)
    if tuple(periods) != ordered:
        raise RuntimeError("evaluation periods do not preserve the sealed 455-basin order")

    supports = dict(common.FROZEN_SUPPORTS if production else (expected_supports or {}))
    payloads: dict[str, bytes] = {}
    paired_values: list[float] = []
    support_totals = {lead: 0 for lead in common.FROZEN_LEADS}
    denominator_count = 0
    try:
        for basin_id in ordered:
            period = periods[basin_id]
            if not isinstance(period, common.EvaluationPeriod) or period.basin_id != basin_id:
                raise RuntimeError(f"evaluation period identity changed: {basin_id}")
            filter_predictions = filter_predictor(basin_id, period)
            seed_predictions = neural_seed_predictor(basin_id, period)
            if set(filter_predictions) != set(common.FROZEN_LEADS) or set(seed_predictions) != set(common.FROZEN_LEADS):
                raise RuntimeError(f"prediction lead set changed: {basin_id}")
            normalized_filter: dict[int, np.ndarray] = {}
            normalized_seeds: dict[int, dict[int, np.ndarray]] = {}
            ensembles: dict[int, np.ndarray] = {}
            scores: dict[int, common.ScoreRecord] = {}
            for lead in common.FROZEN_LEADS:
                filter_array = np.asarray(filter_predictions[lead], dtype=np.float64)
                if filter_array.shape != period.observations.shape or np.isinf(filter_array).any():
                    raise RuntimeError(f"filter prediction vector changed: {basin_id}, lead {lead}")
                per_seed = seed_predictions[lead]
                if set(per_seed) != set(common.FROZEN_SEEDS):
                    raise RuntimeError(f"neural seed set changed: {basin_id}, lead {lead}")
                seed_arrays = {
                    seed: np.asarray(per_seed[seed], dtype=np.float64)
                    for seed in common.FROZEN_SEEDS
                }
                if any(
                    value.shape != period.observations.shape or np.isinf(value).any()
                    for value in seed_arrays.values()
                ):
                    raise RuntimeError(f"neural prediction vector changed: {basin_id}, lead {lead}")
                ensemble = common.three_seed_ensemble(
                    [seed_arrays[seed] for seed in common.FROZEN_SEEDS]
                )
                score = common.common_mask_and_nse(
                    period.observations,
                    filter_array,
                    ensemble,
                    [seed_arrays[seed] for seed in common.FROZEN_SEEDS],
                    lead_days=lead,
                    first_scoring_index=int(first_scoring_index),
                    expected_count=supports.get(lead),
                    basin_id=basin_id,
                )
                normalized_filter[lead] = filter_array
                normalized_seeds[lead] = seed_arrays
                ensembles[lead] = ensemble
                scores[lead] = score
                support_totals[lead] += score.support_count
                denominator_count += 1
            metrics = _metrics_record(basin_id=basin_id, scores=scores)
            paired_values.append(metrics["lead_mean_filter_minus_neural_ensemble_nse"])
            archive_relative = f"basins/{basin_id}.predictions.npz"
            metrics_relative = f"basins/{basin_id}.metrics.json"
            payloads[archive_relative] = deterministic_npz_bytes(
                _prediction_arrays(period, normalized_filter, normalized_seeds, ensembles, scores)
            )
            payloads[metrics_relative] = common.canonical_json_bytes(metrics)
    except common.UndefinedEvaluationTargetVariance as exc:
        evidence = exc.evidence()
        evidence.update(
            {
                "attempt_id": attempt_id,
                "admission_sha256": admission_sha256,
                "denominators_checked_before_stop": denominator_count,
                "expected_denominator_count": len(ordered) * 3,
            }
        )
        failure_root = target.with_name(f"{target.name}.failed.{attempt_id}")
        _publish_failure_once(failure_root, evidence)
        raise

    expected_denominators = len(ordered) * 3
    if denominator_count != expected_denominators:
        raise RuntimeError("formal evaluation denominator count changed")
    paired = np.asarray(paired_values, dtype=np.float64)
    bootstrap = common.paired_basin_bootstrap(
        paired,
        seed=int(bootstrap_seed),
        resamples=int(bootstrap_resamples),
        expected_count=(common.FROZEN_BASIN_COUNT if production else len(ordered)),
    )
    decision, success = common.decision_from_interval(bootstrap.lower, bootstrap.upper)
    basin_count = len(ordered)
    primary_count = basin_count * 6
    supplemental_count = basin_count * 9
    prediction_count = basin_count * 15
    evaluation_day_count = len(next(iter(periods.values())).dates_ns)
    neural_scalar_prediction_count = (
        basin_count
        * len(common.FROZEN_LEADS)
        * len(common.FROZEN_SEEDS)
        * (evaluation_day_count - int(first_scoring_index))
    )
    identity = {
        "schema_version": "tukf09_455_formal_evaluation_identity_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "FORMAL_EVALUATION_COMPLETE_PENDING_INDEPENDENT_AUDIT",
        "attempt_id": attempt_id,
        "admission_sha256": admission_sha256,
        "ordered_basin_ids": list(ordered),
        "ordered_basin_newline_sha256": sha256(
            "".join(f"{value}\n" for value in ordered).encode("utf-8")
        ).hexdigest(),
        "basin_count": basin_count,
        "evaluation_day_count": evaluation_day_count,
        "first_scoring_index": int(first_scoring_index),
        "lead_days": list(common.FROZEN_LEADS),
        "neural_seeds": list(common.FROZEN_SEEDS),
    }
    ledger = {
        "schema_version": "tukf09_455_formal_evaluation_access_ledger_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "FORMAL_EVALUATION_ACCESS_COMPLETE_PENDING_INDEPENDENT_AUDIT",
        "raw_source_files_hashed": common.FROZEN_RAW_SOURCE_COUNT if production else None,
        "evaluation_array_reads": basin_count * 3,
        "evaluation_predictions": prediction_count,
        "neural_scalar_predictions": neural_scalar_prediction_count,
        "evaluation_metrics": primary_count + supplemental_count,
        "evaluation_outputs": basin_count * 2 + 4,
    }
    summary = {
        "schema_version": "tukf09_455_formal_evaluation_summary_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "FORMAL_EVALUATION_COMPLETE_PENDING_INDEPENDENT_AUDIT",
        "basin_count": basin_count,
        "target_denominator_count": denominator_count,
        "prediction_vector_count": prediction_count,
        "neural_scalar_prediction_count": neural_scalar_prediction_count,
        "primary_nse_count": primary_count,
        "supplemental_seed_nse_count": supplemental_count,
        "total_nse_count": primary_count + supplemental_count,
        "paired_basin_count": len(paired),
        "support_totals": {str(lead): support_totals[lead] for lead in common.FROZEN_LEADS},
        "population_median_filter_minus_neural_ensemble_nse": bootstrap.population_median,
        "paired_basin_bootstrap": {
            "seed": bootstrap.seed,
            "resamples": bootstrap.resamples,
            "confidence_level": bootstrap.confidence_level,
            "statistic": bootstrap.statistic,
            "quantile_method": bootstrap.quantile_method,
            "lower": bootstrap.lower,
            "upper": bootstrap.upper,
        },
        "scientific_decision": decision,
        "scientific_success": success,
        "independent_full_prediction_replay_required": True,
        "total_file_count": basin_count * 2 + 4,
    }
    payloads["identity.json"] = common.canonical_json_bytes(identity)
    payloads["access_ledger.json"] = common.canonical_json_bytes(ledger)
    payloads["evaluation_summary.json"] = common.canonical_json_bytes(summary)
    manifest_files = {relative: _file_record(content) for relative, content in sorted(payloads.items())}
    manifest = {
        "schema_version": "tukf09_455_formal_evaluation_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "FORMAL_EVALUATION_COMPLETE_PENDING_INDEPENDENT_AUDIT",
        "file_count": len(manifest_files),
        "files": manifest_files,
        "files_canonical_sha256": common.canonical_json_sha256(manifest_files),
        "manifest_excludes_itself": True,
        "total_file_count_including_manifest": len(manifest_files) + 1,
    }
    payloads["manifest.sha256.json"] = common.canonical_json_bytes(manifest)
    if production and (len(payloads) != 914 or len(manifest_files) != 913):
        raise AssertionError("production formal evaluation file counts changed")
    _atomic_publish_directory(target, payloads)
    result = dict(summary)
    result["reused"] = False
    return result


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-formal-evaluation", action="store_true")
    parser.add_argument("--project-root", type=Path, default=ROOT)
    return parser


def main() -> None:
    arguments = _parser().parse_args()
    result = run_formal_evaluation_from_fixed_artifacts(
        authorize=bool(arguments.run_formal_evaluation),
        project_root=arguments.project_root,
    )
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()


__all__ = [
    "ProductionEvaluationDependencies",
    "build_production_dependencies",
    "deterministic_npz_bytes",
    "run_formal_evaluation",
    "run_formal_evaluation_from_fixed_artifacts",
]
