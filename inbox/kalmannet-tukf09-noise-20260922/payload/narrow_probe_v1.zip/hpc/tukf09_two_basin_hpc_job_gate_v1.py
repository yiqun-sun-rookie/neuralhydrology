"""Verify payload and run only small non-model tests before starting a worker."""
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET
from tukf09_two_basin_hpc_gate_v1 import REMOTE_ROOT, verify_bundle

SOFT_BYTES = 256 * 2**20
HARD_BYTES = 8 * 2**30

def cap_address_space():
    import resource
    resource.setrlimit(resource.RLIMIT_AS, (SOFT_BYTES, HARD_BYTES))

if sys.platform == 'linux':
    cap_address_space()

verify_bundle(REMOTE_ROOT, os.environ['TUKF09_BUNDLE_SHA256'])
control = REMOTE_ROOT.parent/'control'
temp = control/'linux_tests_001'
report = control/'linux_tests.xml'
if temp.exists() or report.exists():
    raise FileExistsError('no test output overwrite')
command = [sys.executable,'-B','-m','pytest','-q','-p','no:cacheprovider',
           '--basetemp',str(temp),'--junitxml',str(report),
           str(REMOTE_ROOT/'hpc/test_tukf09_two_basin_hpc_supervisor_v1.py'),
           str(REMOTE_ROOT/'hpc/test_tukf09_two_basin_hpc_gate_v1.py')]
environment = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
subprocess.run(command, check=True, timeout=180, env=environment,
               preexec_fn=cap_address_space if sys.platform == 'linux' else None)
suites = list(ET.parse(report).getroot().iter('testsuite'))
if len(suites) != 1 or int(suites[0].attrib['tests']) != 17 + 24:
    raise RuntimeError('unexpected non-model protection test count')
if any(int(s.attrib[k]) for s in suites for k in ('errors','failures','skipped')):
    raise RuntimeError('Linux non-model protection tests not all passed')
print('LINUX_PROTECTION_TESTS_ALL_PASSED',flush=True)
