"""Independently reconstruct and verify all 455 formal state-scale artifacts."""
from __future__ import annotations

import argparse
from datetime import date, datetime, timezone
from hashlib import sha256
import json
import math
import os
from pathlib import Path, PurePosixPath
import sys
import time
from typing import Any, Mapping

import numpy as np
import psutil
import torch


ROOT = Path(__file__).resolve().parents[1]
for _extra in (str(ROOT), str(ROOT / "src"), str(ROOT / "hpc")):
    if _extra not in sys.path:
        sys.path.insert(0, _extra)

import tukf09_455_state_scale_generation_common_v1 as common  # noqa: E402
from scripts import tukf09_455_training_common as revision_training_common  # noqa: E402
from scripts import tukf09_training_common as parent_training_common  # noqa: E402
from scripts.tukf09_confirmatory_common import (  # noqa: E402
    PARAMETER_NAMES,
    default_routed_initial_state,
    routed_state_dimension,
)
from global_hydrology.models.differentiable_hbv_lite import (  # noqa: E402
    PARAM_NAMES as MODEL_PARAMETER_NAMES,
    recession_half_weights,
)
from global_hydrology.models.hbvlite_system_model import HBVLiteSystemModel  # noqa: E402


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _peak_rss_bytes(process: psutil.Process) -> int:
    info = process.memory_info()
    values = [int(info.rss)]
    for name in ("peak_wset", "peak_rss"):
        if hasattr(info, name):
            values.append(int(getattr(info, name)))
    return max(values)


def _resource_check(
    *, started: float, process: psutil.Process, limits: Mapping[str, Any], stage: str
) -> dict[str, Any]:
    elapsed = time.perf_counter() - started
    peak = _peak_rss_bytes(process)
    if elapsed > float(limits["wall_seconds"]):
        raise TimeoutError(f"independent state-scale verification exceeded wall cap: {stage}")
    if peak > int(limits["maximum_process_rss_bytes"]):
        raise MemoryError(f"independent state-scale verification exceeded memory cap: {stage}")
    return {"stage": stage, "elapsed_seconds": elapsed, "peak_process_rss_bytes": peak}


def _write_failure(root: Path, exc: BaseException, completed: list[str]) -> None:
    payload = {
        "schema_version": "tukf09_455_state_scale_independent_failure_v1",
        "experiment_id": common.EXPERIMENT_ID,
        "stage_id": common.STAGE_ID,
        "status": "INDEPENDENT_STATE_SCALE_VERIFICATION_FAILED_LATER_STAGES_HOLD",
        "failed_at_utc": _utc_now(),
        "exception_type": type(exc).__name__,
        "exception_message": str(exc),
        "completed_basin_count": len(completed),
        "completed_basins": completed,
        "automatic_retry_permitted": False,
        "validation_array_reads": 0,
        "evaluation_array_reads": 0,
        "discharge_observation_array_reads": 0,
        "scientific_performance_result": False,
    }
    try:
        common.base.atomic_write_json_exclusive(root / "failure.json", payload)
    except FileExistsError:
        pass
    try:
        manifest = common.build_tree_manifest(
            root,
            schema_version="tukf09_455_state_scale_independent_failure_manifest_v1",
            status="INDEPENDENT_STATE_SCALE_VERIFICATION_FAILED_LATER_STAGES_HOLD",
        )
        common.base.atomic_write_json_exclusive(root / "manifest.failure.sha256.json", manifest)
    except (FileExistsError, OSError, RuntimeError, ValueError):
        pass


def _independent_population() -> tuple[tuple[str, ...], tuple[str, ...], np.ndarray, dict[str, int]]:
    contract = common.base.load_science_contract()
    seals = contract["lineage"]["input_seals"]
    population_path = ROOT / seals["population_registry"]["path"]
    parameter_path = ROOT / seals["parameters_only"]["path"]
    common.base.verify_file_binding(population_path, seals["population_registry"], label="audit population")
    common.base.verify_file_binding(parameter_path, seals["parameters_only"], label="audit parameters")
    population = common.base.read_json_strict(population_path)
    basin_ids = tuple(str(value) for value in population["eligible"])
    with np.load(parameter_path, allow_pickle=False) as archive:
        parameter_basins = tuple(str(value) for value in archive["basin_ids"].tolist())
        names = tuple(str(value) for value in archive["parameter_names"].tolist())
        values = np.asarray(archive["values"], dtype=np.float64).copy()
    if (
        basin_ids != parameter_basins
        or len(basin_ids) != 455
        or names != tuple(PARAMETER_NAMES)
        or values.shape != (455, 13)
        or not np.isfinite(values).all()
    ):
        raise RuntimeError("independent state-scale population or parameters changed")
    dimensions = {
        basin_id: int(
            routed_state_dimension(
                {name: float(value) for name, value in zip(names, values[index])}
            )
        )
        for index, basin_id in enumerate(basin_ids)
    }
    order_hash = sha256("".join(f"{value}\n" for value in basin_ids).encode("utf-8")).hexdigest()
    if order_hash != contract["population"]["basin_order_newline_utf8_sha256"]:
        raise RuntimeError("independent state-scale basin order changed")
    return basin_ids, names, values, dimensions


def _forcing_record(parent_context: Any, basin_id: str) -> tuple[str, Mapping[str, Any], Path]:
    matches = [
        (str(relative), record)
        for relative, record in parent_context.raw_source_files.items()
        if str(relative).startswith("basin_mean_forcing/maurer/")
        and PurePosixPath(str(relative)).name.startswith(basin_id)
    ]
    if len(matches) != 1:
        raise RuntimeError(f"independent forcing source count changed for {basin_id}")
    relative, record = matches[0]
    path = parent_training_common.require_regular_unlinked_file(
        parent_context.data_root.joinpath(*PurePosixPath(relative).parts),
        label="independent sealed training forcing",
        stop_at=parent_context.data_root,
    )
    if path.stat().st_size != int(record["size_bytes"]) or common.base.sha256_file(path) != record["sha256"]:
        raise RuntimeError(f"independent forcing bytes changed for {basin_id}")
    return relative, record, path


def _independent_training_forcing(
    parent_context: Any, basin_id: str
) -> tuple[np.ndarray, np.ndarray, str, Mapping[str, Any], dict[str, Any], dict[str, Any]]:
    period = parent_context.periods["training"]
    start = date.fromisoformat(str(period.start_date)).toordinal()
    end = date.fromisoformat(str(period.end_date)).toordinal()
    if (
        str(period.start_date) != common.EXPECTED_TRAINING_START
        or str(period.end_date) != common.EXPECTED_TRAINING_END
        or int(period.day_count) != common.EXPECTED_TRAINING_DAYS
        or end - start + 1 != common.EXPECTED_TRAINING_DAYS
    ):
        raise RuntimeError("independent training-period identity changed")
    relative, raw_record, path = _forcing_record(parent_context, basin_id)
    raw = np.empty((common.EXPECTED_TRAINING_DAYS, 5), dtype=np.float64)
    counts = np.zeros(common.EXPECTED_TRAINING_DAYS, dtype=np.int16)
    previous: int | None = None
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            fields = line.split()
            if len(fields) < 3:
                continue
            try:
                ordinal = date(int(fields[0]), int(fields[1]), int(fields[2])).toordinal()
            except (TypeError, ValueError):
                continue
            if ordinal < start:
                continue
            if ordinal > end:
                break
            if len(fields) < 10 or (previous is not None and ordinal <= previous):
                raise ValueError(f"independent training forcing order changed: {path}")
            previous = ordinal
            index = ordinal - start
            counts[index] += 1
            values = np.asarray([float(fields[position]) for position in (4, 5, 6, 8, 9)])
            if not np.isfinite(values).all():
                raise ValueError(f"independent training forcing is non-finite: {path}")
            raw[index] = values
    if not np.all(counts == 1):
        raise ValueError(f"independent training forcing support changed: {path}")
    temperature = (raw[:, 3] + raw[:, 4]) / 2.0
    potential = np.where(
        temperature > -5.0,
        (raw[:, 2] * raw[:, 0] / 1.0e6) * (temperature + 5.0) / 245.0,
        0.0,
    )
    forcing = np.ascontiguousarray(
        np.column_stack((raw[:, 1], temperature, np.maximum(potential, 0.0))),
        dtype="<f8",
    )
    dates = np.arange(
        np.datetime64(common.EXPECTED_TRAINING_START, "D"),
        np.datetime64(common.EXPECTED_TRAINING_END, "D") + np.timedelta64(1, "D"),
        dtype="datetime64[D]",
    ).astype("datetime64[ns]").view("<i8")
    dates = np.ascontiguousarray(dates, dtype="<i8")
    dates_record = parent_training_common.semantic_array_identity(
        f"{basin_id}/training/dates_ns", dates, "<i8"
    )
    forcing_record = parent_training_common.semantic_array_identity(
        f"{basin_id}/training/forcing", forcing, "<f8"
    )
    if (
        dates_record
        != parent_context.semantic_members["training"][f"{basin_id}/dates_ns"]
        or forcing_record
        != parent_context.semantic_members["training"][f"{basin_id}/forcing"]
    ):
        raise RuntimeError(f"independent training semantic identity changed for {basin_id}")
    return dates, forcing, relative, dict(raw_record), dates_record, forcing_record


def _independent_open_loop(
    basin_id: str, row: Mapping[str, float], parent_contract: Mapping[str, Any]
) -> tuple[HBVLiteSystemModel, torch.Tensor, Any, int]:
    if tuple(MODEL_PARAMETER_NAMES) != tuple(PARAMETER_NAMES):
        raise RuntimeError("independent HBV-light parameter order changed")
    parameters = torch.tensor(
        [[row[name] for name in PARAMETER_NAMES]], dtype=torch.float64, device="cpu"
    )
    dimension = int(routed_state_dimension(row))
    weights = recession_half_weights(parameters[:, -1:], dimension - 5)
    model = HBVLiteSystemModel(
        parameters,
        emission="routed",
        lag_weights=weights,
        device=torch.device("cpu"),
        dtype=torch.float64,
    )
    field_capacity = parameters[:, PARAMETER_NAMES.index("parFC")]

    def project(state: torch.Tensor) -> torch.Tensor:
        first_five = torch.clamp(state[:, :5], min=0.0)
        soil = torch.clamp(first_five[:, 2:3], max=field_capacity)
        return torch.cat(
            [first_five[:, :2], soil, first_five[:, 3:5], torch.clamp(state[:, 5:], min=0.0)],
            dim=-1,
        )

    initialization = parent_contract["filter_system"]["initialization"]
    if (
        initialization.get("forbid_prior_x0_table") is not True
        or initialization.get("forbid_cal_final_2008_state_columns") is not True
    ):
        raise RuntimeError("independent initial-state policy changed")
    initial = torch.tensor(
        default_routed_initial_state(row), dtype=torch.float64, device="cpu"
    ).reshape(1, dimension)
    return model, initial, project, dimension


def _independent_trajectory_and_scale(
    basin_id: str,
    row: Mapping[str, float],
    forcing: np.ndarray,
    parent_contract: Mapping[str, Any],
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, tuple[str, ...], tuple[str, ...]]:
    model, state, project, dimension = _independent_open_loop(basin_id, row, parent_contract)
    initial = state[0].numpy().astype(np.float64, copy=True)
    trajectory = np.empty((common.EXPECTED_TRAINING_DAYS, dimension), dtype=np.float64)
    forcing_tensor = torch.tensor(forcing, dtype=torch.float64, device="cpu")
    with torch.no_grad():
        for day in range(common.EXPECTED_TRAINING_DAYS):
            state = project(model.f(state, forcing_tensor[day]))
            if not bool(torch.isfinite(state).all()):
                raise FloatingPointError(f"independent trajectory failed for {basin_id} day {day}")
            trajectory[day] = state[0].numpy()
    selected = trajectory[365:2557]
    raw_scale = np.sqrt(np.mean(selected * selected, axis=0, dtype=np.float64))
    floor = np.full(dimension, 0.01, dtype=np.float64)
    scale = np.maximum(raw_scale, floor)
    floor_hit = raw_scale <= floor
    names = tuple(common.base.PHYSICAL_STATE_NAMES) + tuple(
        f"unrouted_runoff_lag_{index}_days" for index in range(dimension - 5)
    )
    units = tuple(["millimetre"] * 5 + ["millimetre_per_day"] * (dimension - 5))
    return initial, trajectory, raw_scale, scale, floor_hit, names, units


def _load_npz(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as archive:
        return {name: np.asarray(archive[name]).copy() for name in archive.files}


def verify_all_state_scales() -> dict[str, Any]:
    authorization = common.load_authorization()
    common.load_implementation_admission()
    threads = common.configure_single_thread_execution()
    runtime = common.verify_runtime(authorization)
    limits = authorization["independent_verification_budget"]
    audit_root = common.ensure_stage_output_path(common.INDEPENDENT_ROOT, common.INDEPENDENT_ROOT)
    if audit_root.exists() or audit_root.is_symlink():
        raise FileExistsError(f"independent state-scale output already exists: {audit_root}")
    audit_root.mkdir(parents=True, exist_ok=False)
    common.base.atomic_write_json_exclusive(
        audit_root / "started.json",
        {
            "schema_version": "tukf09_455_state_scale_independent_started_v1",
            "experiment_id": common.EXPERIMENT_ID,
            "stage_id": common.STAGE_ID,
            "status": "INDEPENDENT_STATE_SCALE_RECOMPUTATION_RUNNING",
            "started_at_utc": _utc_now(),
            "process_id": os.getpid(),
            "runtime_environment": runtime,
            "thread_counts": threads,
            "validation_array_reads": 0,
            "evaluation_array_reads": 0,
            "discharge_observation_array_reads": 0,
        },
    )
    completed: list[str] = []
    process = psutil.Process(os.getpid())
    started = time.perf_counter()
    try:
        common.verify_tree_manifest(
            common.SCALE_ROOT,
            expected_schema="tukf09_455_state_scale_generation_manifest_v1",
            expected_status="FORMAL_455_BASIN_TRAINING_STATE_SCALES_SEALED_LATER_STAGES_HOLD",
        )
        registry = common.base.read_json_strict(common.SCALE_ROOT / "scale_registry.json")
        run_summary = common.base.read_json_strict(common.SCALE_ROOT / "run_summary.json")
        basin_ids, parameter_names, parameter_values, dimensions = _independent_population()
        parent_context = revision_training_common.verify_preflight_for_revision_training(
            common.base.PARENT_CONFIG,
            common.base.PARENT_PREFLIGHT_FINAL,
            common.base.PARENT_AUTHORIZATION,
            common.base.PARENT_RESULTS_ROOT,
            require_output_absent=False,
            recompute_training_validation_semantics=False,
            verify_all_raw_source_bytes=False,
        )
        if (
            int(parent_context.evaluation_access_count) != 0
            or tuple(str(value) for value in parent_context.ordered_basin_ids) != basin_ids
        ):
            raise RuntimeError("independent parent context population changed")
        units = registry.get("units")
        if (
            registry.get("status")
            != "FORMAL_455_BASIN_TRAINING_STATE_SCALE_LIBRARY_COMPLETE"
            or not isinstance(units, list)
            or len(units) != 455
            or int(registry.get("validation_array_reads", -1)) != 0
            or int(registry.get("evaluation_array_reads", -1)) != 0
            or int(registry.get("discharge_observation_array_reads", -1)) != 0
            or int(registry.get("local_noise_optimization_updates", -1)) != 0
        ):
            raise RuntimeError("independent state-scale registry scope changed")
        basin_results: list[dict[str, Any]] = []
        total_model_steps = 0
        total_floor_hits = 0
        for index, basin_id in enumerate(basin_ids):
            unit_root = common.SCALE_ROOT / f"basin_{basin_id}"
            common.verify_tree_manifest(
                unit_root,
                expected_schema="tukf09_455_state_scale_unit_manifest_v1",
                expected_status="FORMAL_TRAINING_STATE_SCALE_UNIT_SEALED",
            )
            arrays = _load_npz(unit_root / "state_scale_arrays.npz")
            expected_members = {
                "dates_ns",
                "initial_state",
                "deterministic_training_trajectory",
                "raw_state_scale",
                "state_scale",
                "floor_hit",
                "parameter_values",
            }
            if set(arrays) != expected_members:
                raise RuntimeError(f"state-scale NPZ member set changed for {basin_id}")
            identity = common.base.read_json_strict(unit_root / "identity.json")
            summary = common.base.read_json_strict(unit_root / "summary.json")
            dates, forcing, raw_relative, raw_record, dates_record, forcing_record = (
                _independent_training_forcing(parent_context, basin_id)
            )
            row = {
                name: float(value)
                for name, value in zip(parameter_names, parameter_values[index])
            }
            initial, trajectory, raw_scale, scale, floor_hit, names, state_units = (
                _independent_trajectory_and_scale(
                    basin_id, row, forcing, parent_context.contract
                )
            )
            comparisons = {
                "dates_ns": dates,
                "initial_state": initial,
                "deterministic_training_trajectory": trajectory,
                "raw_state_scale": raw_scale,
                "state_scale": scale,
                "floor_hit": floor_hit,
                "parameter_values": parameter_values[index],
            }
            for name, expected in comparisons.items():
                if not np.array_equal(arrays[name], expected):
                    raise RuntimeError(f"independent {name} mismatch for {basin_id}")
            registry_unit = units[index]
            if (
                int(identity.get("basin_index", -1)) != index
                or identity.get("basin_id") != basin_id
                or int(identity.get("state_dimension", -1)) != dimensions[basin_id]
                or identity.get("state_order") != list(names)
                or identity.get("state_units") != list(state_units)
                or identity["raw_training_forcing"]
                != {"path": raw_relative, **dict(raw_record)}
                or identity["training_semantic_arrays"]
                != {"dates_ns": dates_record, "forcing": forcing_record}
                or int(identity.get("validation_array_reads", -1)) != 0
                or int(identity.get("evaluation_array_reads", -1)) != 0
                or int(identity.get("discharge_observation_array_reads", -1)) != 0
                or identity.get("scientific_performance_result") is not False
            ):
                raise RuntimeError(f"independent state-scale identity mismatch for {basin_id}")
            if (
                summary.get("state_scale") != scale.tolist()
                or summary.get("raw_state_scale") != raw_scale.tolist()
                or summary.get("floor_hit") != floor_hit.astype(bool).tolist()
                or int(summary.get("trajectory_model_steps", -1)) != 2557
                or registry_unit.get("basin_id") != basin_id
                or int(registry_unit.get("basin_index", -1)) != index
                or int(registry_unit.get("state_dimension", -1)) != dimensions[basin_id]
            ):
                raise RuntimeError(f"independent state-scale summary mismatch for {basin_id}")
            unit_manifest_path = unit_root / "manifest.final.sha256.json"
            expected_unit_manifest = {
                "path": f"basin_{basin_id}/manifest.final.sha256.json",
                **common.base.file_record(unit_manifest_path),
            }
            if registry_unit.get("unit_manifest") != expected_unit_manifest:
                raise RuntimeError(f"state-scale registry manifest binding changed for {basin_id}")
            total_model_steps += trajectory.shape[0]
            total_floor_hits += int(np.count_nonzero(floor_hit))
            completed.append(basin_id)
            basin_results.append(
                {
                    "basin_index": index,
                    "basin_id": basin_id,
                    "state_dimension": dimensions[basin_id],
                    "trajectory_max_abs_difference": 0.0,
                    "state_scale_max_abs_difference": 0.0,
                    "floor_hit_count": int(np.count_nonzero(floor_hit)),
                }
            )
            stage = _resource_check(
                started=started,
                process=process,
                limits=limits,
                stage=f"basin_{index + 1:03d}_of_455_{basin_id}",
            )
            if (index + 1) % 25 == 0 or index + 1 == len(basin_ids):
                print(
                    json.dumps(
                        {
                            "verification_progress": index + 1,
                            "total": len(basin_ids),
                            "basin_id": basin_id,
                            "elapsed_seconds": stage["elapsed_seconds"],
                            "peak_process_rss_bytes": stage["peak_process_rss_bytes"],
                        },
                        sort_keys=True,
                    ),
                    flush=True,
                )
        if (
            completed != list(basin_ids)
            or total_model_steps != int(limits["recomputed_basin_day_model_steps"])
            or total_floor_hits != int(registry["total_floor_hit_count"])
            or int(run_summary.get("basin_count", -1)) != 455
            or int(run_summary.get("total_trajectory_model_steps", -1)) != total_model_steps
            or int(run_summary.get("validation_array_reads", -1)) != 0
            or int(run_summary.get("evaluation_array_reads", -1)) != 0
            or int(run_summary.get("discharge_observation_array_reads", -1)) != 0
            or run_summary.get("later_stages_authorized") is not False
        ):
            raise RuntimeError("independent state-scale total counts or scope changed")
        final_resources = _resource_check(
            started=started,
            process=process,
            limits=limits,
            stage="independent_state_scale_verification_complete",
        )
        result = {
            "schema_version": "tukf09_455_state_scale_independent_verification_v1",
            "experiment_id": common.EXPERIMENT_ID,
            "stage_id": common.STAGE_ID,
            "status": "ALL_455_FORMAL_TRAINING_STATE_SCALES_INDEPENDENTLY_VERIFIED_LATER_STAGES_HOLD",
            "verified_at_utc": _utc_now(),
            "runtime_environment": runtime,
            "basin_count": len(completed),
            "recomputed_trajectory_count": len(completed),
            "recomputed_trajectory_model_steps": total_model_steps,
            "total_floor_hit_count": total_floor_hits,
            "trajectory_max_abs_difference": 0.0,
            "state_scale_max_abs_difference": 0.0,
            "mismatch_count": 0,
            "total_wall_seconds": final_resources["elapsed_seconds"],
            "peak_process_rss_bytes": final_resources["peak_process_rss_bytes"],
            "resource_limits": dict(limits),
            "validation_array_reads": 0,
            "evaluation_array_reads": 0,
            "discharge_observation_array_reads": 0,
            "local_noise_optimization_updates": 0,
            "scientific_performance_result": False,
            "later_stages_authorized": False,
            "basins": basin_results,
        }
        common.base.atomic_write_json_exclusive(audit_root / "verification.json", result)
        manifest = common.build_tree_manifest(
            audit_root,
            schema_version="tukf09_455_state_scale_independent_manifest_v1",
            status="ALL_455_FORMAL_TRAINING_STATE_SCALES_INDEPENDENTLY_VERIFIED_LATER_STAGES_HOLD",
        )
        manifest_bytes = common.base.canonical_json_bytes(manifest)
        if common.directory_file_bytes(audit_root) + len(manifest_bytes) > int(
            limits["maximum_audit_output_bytes"]
        ):
            raise RuntimeError("independent state-scale audit output would exceed byte cap")
        common.base.atomic_write_bytes_exclusive(
            audit_root / "manifest.final.sha256.json", manifest_bytes
        )
        return result
    except BaseException as exc:
        _write_failure(audit_root, exc, completed)
        raise


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--mode",
        required=True,
        choices=("verify-formal-state-scales", "verify-local-noise-selection"),
    )
    args = parser.parse_args()
    if args.mode == "verify-local-noise-selection":
        common.load_authorization()
        raise PermissionError("local noise selection verification remains unauthorized")
    result = verify_all_state_scales()
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
