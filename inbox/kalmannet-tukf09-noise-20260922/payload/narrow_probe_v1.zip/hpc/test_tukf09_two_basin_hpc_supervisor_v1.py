"""Small-process tests; never import or execute the hydrology model."""
import os
from pathlib import Path
import subprocess
import sys
import time

import pytest

from tukf09_two_basin_hpc_supervisor_v1 import run_supervised


def test_invalid(tmp_path):
    with pytest.raises(ValueError):
        run_supervised([], tmp_path / "empty")
    with pytest.raises(ValueError):
        run_supervised([sys.executable], tmp_path / "zero", poll_seconds=0)
    with pytest.raises(ValueError):
        run_supervised([sys.executable], tmp_path / "large", poll_seconds=6)


def test_existing_directory(tmp_path):
    target = tmp_path / "existing"
    target.mkdir()
    with pytest.raises(FileExistsError):
        run_supervised([sys.executable], target)


@pytest.mark.skipif(sys.platform != "linux", reason="Linux process-group and resource test")
def test_normal_nonzero_and_unrelated(tmp_path):
    unrelated = subprocess.Popen([sys.executable, "-c", "import time;time.sleep(10)"])
    try:
        ok = run_supervised([sys.executable, "-c", "print('ok')"], tmp_path / "ok", poll_seconds=.1)
        bad = run_supervised([sys.executable, "-c", "raise SystemExit(7)"], tmp_path / "bad", poll_seconds=.1)
        assert ok["success"] and ok["exit_code"] == 0
        assert not bad["success"] and bad["reason"] == "nonzero_exit"
        assert unrelated.poll() is None
    finally:
        unrelated.terminate()
        unrelated.wait(timeout=5)


@pytest.mark.skipif(sys.platform != "linux", reason="Linux resource test")
@pytest.mark.parametrize("name,code,limits,reason", [
    ("wall", "import time;time.sleep(5)", {"wall_seconds": .3}, "wall_limit"),
    ("output", "print('x'*100000)", {"output_limit_bytes": 1000}, "output_limit"),
    ("memory", "import time;x=bytearray(40*1024*1024);time.sleep(5)", {"rss_limit_bytes": 20*2**20}, "rss_limit"),
])
def test_limits(tmp_path, name, code, limits, reason):
    result = run_supervised([sys.executable, "-c", code], tmp_path / name,
                            poll_seconds=.1, **limits)
    assert not result["success"] and result["reason"] == reason


@pytest.mark.skipif(sys.platform != "linux", reason="Linux fault test")
def test_supervisor_write_failure(tmp_path, monkeypatch):
    import tukf09_two_basin_hpc_supervisor_v1 as module
    original = module._write_status
    calls = 0
    def fail(path, record):
        nonlocal calls
        calls += 1
        if calls >= 3:
            raise OSError("injected write failure")
        return original(path, record)
    monkeypatch.setattr(module, "_write_status", fail)
    result = run_supervised([sys.executable, "-c", "import time;time.sleep(5)"],
                            tmp_path / "failure", poll_seconds=.1)
    assert result["reason"] == "monitor_write_failure"


@pytest.mark.skipif(sys.platform != "linux", reason="Linux fault test")
def test_parent_death(tmp_path):
    directory = tmp_path / "parent_death"
    script = ("import pathlib,sys,time;from tukf09_two_basin_hpc_supervisor_v1 import run_supervised;"
              "run_supervised([sys.executable,'-c','import time;time.sleep(20)'],"
              "pathlib.Path(sys.argv[1]),poll_seconds=.1)")
    parent = subprocess.Popen([sys.executable, "-c", script, str(directory)])
    try:
        deadline = time.time() + 5
        while not (directory / "worker.pid").exists() and time.time() < deadline:
            time.sleep(.05)
        assert (directory / "worker.pid").exists()
        worker_pid = int((directory / "worker.pid").read_text())
        parent.kill()
        parent.wait(timeout=5)
        deadline = time.time() + 5
        while time.time() < deadline:
            try:
                os.kill(worker_pid, 0)
            except ProcessLookupError:
                break
            stat = Path(f"/proc/{worker_pid}/stat")
            if stat.exists() and stat.read_text().split(") ", 1)[1].startswith("Z"):
                break
            time.sleep(.05)
        else:
            pytest.fail("worker survived supervisor death")
    finally:
        if parent.poll() is None:
            parent.kill()
            parent.wait()


@pytest.mark.skipif(sys.platform != "linux", reason="Linux child process test")
def test_unexpected_child(tmp_path):
    code = "import subprocess,sys,time;subprocess.Popen([sys.executable,'-c','import time;time.sleep(5)']);time.sleep(5)"
    result = run_supervised([sys.executable, "-c", code], tmp_path / "child", poll_seconds=.1)
    assert result["reason"] == "unexpected_child_process"


@pytest.mark.skipif(sys.platform != "linux", reason="Linux output scan test")
def test_written_file_counts_without_print(tmp_path):
    code = "from pathlib import Path;Path('run').mkdir();Path('run/data.bin').write_bytes(b'x'*5000)"
    result = run_supervised([sys.executable, "-c", code], tmp_path / "files",
                            output_limit_bytes=1000, poll_seconds=.1)
    assert result["reason"] == "output_limit"


@pytest.mark.skipif(sys.platform != "linux", reason="Linux output link test")
def test_output_link_rejected(tmp_path):
    code = "import os,time;os.symlink('/etc/passwd','linked');time.sleep(2)"
    result = run_supervised([sys.executable, "-c", code], tmp_path / "link", poll_seconds=.1)
    assert result["reason"] == "output_link"


@pytest.mark.skipif(sys.platform != "linux", reason="Linux limit test")
def test_supervisor_soft_cap_preserves_worker_hard_cap():
    import resource
    import tukf09_two_basin_hpc_supervisor_v1 as module
    old = resource.getrlimit(resource.RLIMIT_AS)
    try:
        module._limit_supervisor(8 * 2**30)
        soft, hard = resource.getrlimit(resource.RLIMIT_AS)
        assert 0 < soft <= 256 * 2**20
        assert hard == old[1]
    finally:
        resource.setrlimit(resource.RLIMIT_AS, old)


@pytest.mark.skipif(sys.platform != "linux", reason="Linux address limit test")
def test_infinite_soft_limit_is_bounded(monkeypatch):
    import resource
    import tukf09_two_basin_hpc_supervisor_v1 as module
    observed = []
    monkeypatch.setattr(resource, "getrlimit", lambda key: (resource.RLIM_INFINITY, resource.RLIM_INFINITY))
    monkeypatch.setattr(resource, "setrlimit", lambda key, limits: observed.append(limits))
    module._limit_supervisor(8 * 2**30)
    assert observed == [(256 * 2**20, resource.RLIM_INFINITY)]


@pytest.mark.skipif(sys.platform != "linux", reason="Linux parent death tree test")
def test_parent_death_stops_child_not_unrelated(tmp_path):
    import json
    import tukf09_two_basin_hpc_supervisor_v1 as module
    directory = tmp_path / "death_tree"
    worker = ("import pathlib,subprocess,sys,time;"
              "go=pathlib.Path('go');"
              "[time.sleep(.05) for _ in iter(lambda: not go.exists(),False)];"
              "p=subprocess.Popen([sys.executable,'-c','import time;time.sleep(20)']);"
              "pathlib.Path('child.pid').write_text(str(p.pid));time.sleep(20)")
    supervisor = ("import pathlib,sys;from tukf09_two_basin_hpc_supervisor_v1 import run_supervised;"
                  "run_supervised([sys.executable,'-c',sys.argv[2]],pathlib.Path(sys.argv[1]),poll_seconds=5)")
    parent = subprocess.Popen([sys.executable, "-c", supervisor, str(directory), worker])
    unrelated = subprocess.Popen([sys.executable, "-c", "import time;time.sleep(20)"])
    try:
        status_file = directory / "supervisor.json"
        deadline = time.time() + 5
        while time.time() < deadline:
            try:
                status = json.loads(status_file.read_text())
                if status.get("sample_count", 0) >= 1:
                    break
            except (FileNotFoundError, json.JSONDecodeError):
                pass
            time.sleep(.05)
        else:
            pytest.fail("supervisor did not take initial sample")
        worker_pid = status["worker_pid"]
        assert parent.poll() is None
        assert module._proc_identity(worker_pid)[4] != "Z"
        (directory / "go").write_text("start")
        child_file = directory / "child.pid"
        deadline = time.time() + 5
        while not child_file.exists() and time.time() < deadline:
            time.sleep(.05)
        assert child_file.exists()
        child_pid = int(child_file.read_text())
        observed_file = directory / "watchdog.children.json"
        deadline = time.time() + 5
        while time.time() < deadline:
            try:
                observed = json.loads(observed_file.read_text())
                if str(child_pid) in observed["children"]:
                    break
            except (FileNotFoundError, json.JSONDecodeError):
                pass
            time.sleep(.05)
        else:
            pytest.fail("watchdog did not bind child before parent death")
        assert parent.poll() is None
        assert module._proc_identity(worker_pid)[4] != "Z"
        assert module._proc_identity(child_pid)[4] != "Z"
        parent.kill(); parent.wait(timeout=5)
        deadline = time.time() + 5
        while time.time() < deadline:
            child = module._proc_identity(child_pid)
            if child is None or child[4] == "Z":
                break
            time.sleep(.05)
        else:
            pytest.fail("bound child survived supervisor death")
        assert unrelated.poll() is None
    finally:
        if parent.poll() is None:
            parent.kill(); parent.wait()
        unrelated.kill(); unrelated.wait()


@pytest.mark.skipif(sys.platform != "linux", reason="Linux detached child test")
def test_detached_child_is_stopped(tmp_path):
    child_pid_file = tmp_path / "detached" / "child.pid"
    code = ("import pathlib,subprocess,sys,time;"
            "p=subprocess.Popen([sys.executable,'-c','import time;time.sleep(20)'],start_new_session=True);"
            "pathlib.Path('child.pid').write_text(str(p.pid));time.sleep(20)")
    result = run_supervised([sys.executable, "-c", code], tmp_path / "detached", poll_seconds=.1)
    assert result["reason"] == "unexpected_child_process"
    pid = int(child_pid_file.read_text())
    identity = __import__("tukf09_two_basin_hpc_supervisor_v1")._proc_identity(pid)
    assert identity is None or identity[4] == "Z"


@pytest.mark.skipif(sys.platform != "linux", reason="Linux identity test")
def test_identity_mismatch_never_signals(tmp_path, monkeypatch):
    import tukf09_two_basin_hpc_supervisor_v1 as module
    target = subprocess.Popen([sys.executable, "-c", "import time;time.sleep(20)"], start_new_session=True)
    try:
        start = module._proc_identity(target.pid)[2]
        assert not module._kill_group(target.pid, start + 1)
        assert not module._kill_identity(target.pid, start + 1)
        assert target.poll() is None
    finally:
        target.kill(); target.wait()


@pytest.mark.skipif(sys.platform != "linux", reason="Linux independent watchdog test")
def test_stale_heartbeat_kills_only_registered_group(tmp_path):
    import tukf09_two_basin_hpc_supervisor_v1 as module
    target = subprocess.Popen([sys.executable, "-c", "import time;time.sleep(20)"], start_new_session=True)
    unrelated = subprocess.Popen([sys.executable, "-c", "import time;time.sleep(20)"], start_new_session=True)
    heartbeat = tmp_path / "heartbeat"
    heartbeat.write_text("stale")
    old = time.time() - 70
    os.utime(heartbeat, (old, old))
    guard = subprocess.Popen([sys.executable, str(Path(module.__file__).resolve()), "--watchdog",
                              str(os.getpid()), str(module._proc_identity(os.getpid())[2]),
                              str(target.pid), str(module._proc_identity(target.pid)[2]),
                              str(heartbeat), str(tmp_path / "stop")])
    try:
        assert guard.wait(timeout=5) == 0
        assert target.wait(timeout=5) != 0
        assert unrelated.poll() is None
    finally:
        if target.poll() is None:
            target.kill(); target.wait()
        unrelated.kill(); unrelated.wait()
