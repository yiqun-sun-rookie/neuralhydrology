"""Independently audit the 455-basin formal evaluation and replay predictions.

This implementation deliberately duplicates masks, efficiencies, ensemble
means, bootstrap draws, and decision logic.  It imports neither the production
evaluation runner nor its shared numerical helpers.
"""

from __future__ import annotations

import argparse
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from hashlib import sha256
import json
import math
import os
from pathlib import Path, PurePosixPath
import shutil
import struct
from typing import Any, Callable, Mapping, Sequence
import uuid

import numpy as np


EXPERIMENT_ID = "TUKF09_455_BASIN_ZERO_VALIDATION_TARGET_VARIANCE_REVISION_V1"
EXCLUDED_BASIN_ID = "08202700"
FROZEN_BASIN_COUNT = 455
FROZEN_DAY_COUNT = 3_287
FROZEN_FIRST_SCORING_INDEX = 365
FROZEN_LEADS = (1, 2, 3)
FROZEN_SEEDS = (0, 1, 2)
FROZEN_SUPPORTS = {1: 2_920, 2: 2_921, 3: 2_922}
FROZEN_BOOTSTRAP_SEED = 20_260_811
FROZEN_BOOTSTRAP_RESAMPLES = 10_000
FROZEN_ORDERED_BASIN_NEWLINE_SHA256 = (
    "38987bce45fa38ff68f5b067db17e8cb3212d98fecdd106f57d268a130ee8fbd"
)
FROZEN_EVALUATION_SEMANTIC_SHA256 = (
    "fac922d51908376d078a2d3abc023e065a8f785317e059d309dfbbabad37e4a5"
)
FROZEN_SEMANTIC_MEMBER_COUNT = 1_365
FROZEN_NEURAL_SCALAR_PREDICTIONS = 11_965_590
ROOT = Path(__file__).resolve().parents[1]
_PRODUCTION_ENTRY_TOKEN = object()


def _json_bytes(value: Any) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")


def _json_sha256(value: Any) -> str:
    return sha256(_json_bytes(value)).hexdigest()


def _absolute(path: str | Path) -> Path:
    return Path(os.path.abspath(os.fspath(path)))


def _safe_relative(text: str) -> PurePosixPath:
    relative = PurePosixPath(text)
    if (
        not text
        or relative.is_absolute()
        or "\\" in text
        or any(part in {"", ".", ".."} for part in relative.parts)
        or relative.as_posix() != text
    ):
        raise RuntimeError(f"unsafe evaluation manifest member: {text!r}")
    return relative


def _require_file(path: Path, *, label: str) -> Path:
    from scripts import tukf09_455_training_common as training_common

    training_common.ensure_no_symlink_components(path)
    if not path.is_file() or path.is_symlink() or path.stat().st_nlink != 1:
        raise RuntimeError(f"{label} is absent, linked, or not a regular file: {path}")
    return path


def _read_json(path: Path, *, label: str) -> dict[str, Any]:
    source = _require_file(path, label=label)
    try:
        value = json.loads(source.read_bytes())
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"{label} is not valid JSON") from exc
    if not isinstance(value, dict):
        raise RuntimeError(f"{label} must contain one JSON object")
    _json_bytes(value)
    return value


def _sha256_file(path: Path) -> str:
    source = _require_file(Path(path), label="SHA-256 source")
    digest = sha256()
    with source.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _record(path: Path) -> dict[str, Any]:
    return {"sha256": _sha256_file(path), "size_bytes": int(path.stat().st_size)}


def _verify_record(path: Path, record: Mapping[str, Any], *, label: str) -> None:
    source = _require_file(path, label=label)
    if record != _record(source):
        raise RuntimeError(f"{label} hash or size changed")


def _semantic_identity(name: str, array: np.ndarray, dtype: str) -> dict[str, Any]:
    if dtype not in {"<i8", "<f8"}:
        raise ValueError("independent semantic dtype is not canonical")
    canonical = np.ascontiguousarray(array, dtype=np.dtype(dtype))
    name_bytes = str(name).encode("utf-8")
    dtype_bytes = dtype.encode("utf-8")
    digest = sha256()
    digest.update(struct.pack("<Q", len(name_bytes)))
    digest.update(name_bytes)
    digest.update(struct.pack("<Q", len(dtype_bytes)))
    digest.update(dtype_bytes)
    digest.update(struct.pack("<q", canonical.ndim))
    for dimension in canonical.shape:
        digest.update(struct.pack("<q", int(dimension)))
    digest.update(canonical.tobytes(order="C"))
    return {
        "dtype": dtype,
        "shape": [int(value) for value in canonical.shape],
        "sha256": digest.hexdigest(),
    }


def _load_and_verify_manifest(root: Path, basin_count: int) -> tuple[dict[str, Any], str]:
    manifest_path = root / "manifest.sha256.json"
    manifest = _read_json(manifest_path, label="formal evaluation manifest")
    files = manifest.get("files")
    expected_count = basin_count * 2 + 3
    if (
        manifest.get("experiment_id") != EXPERIMENT_ID
        or manifest.get("status") != "FORMAL_EVALUATION_COMPLETE_PENDING_INDEPENDENT_AUDIT"
        or not isinstance(files, dict)
        or int(manifest.get("file_count", -1)) != expected_count
        or len(files) != expected_count
        or manifest.get("files_canonical_sha256") != _json_sha256(files)
        or manifest.get("manifest_excludes_itself") is not True
        or int(manifest.get("total_file_count_including_manifest", -1)) != expected_count + 1
    ):
        raise RuntimeError("formal evaluation manifest identity, hash, or count changed")
    expected_relatives = {
        "identity.json",
        "access_ledger.json",
        "evaluation_summary.json",
        *{
            relative
            for basin_id in _read_json(
                root / "identity.json", label="formal evaluation identity"
            ).get("ordered_basin_ids", [])
            for relative in (
                f"basins/{basin_id}.predictions.npz",
                f"basins/{basin_id}.metrics.json",
            )
        },
    }
    if set(files) != expected_relatives:
        raise RuntimeError("formal evaluation manifest member set changed")
    actual = {
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_file()
        and not path.is_symlink()
        and not path.relative_to(root).as_posix().startswith("independent/")
    }
    if actual != set(files) | {"manifest.sha256.json"}:
        raise RuntimeError("formal evaluation member set changed outside its manifest")
    for relative_text, expected in files.items():
        path = _require_file(
            root.joinpath(*_safe_relative(relative_text).parts),
            label="formal evaluation manifest member",
        )
        if expected != _record(path):
            raise RuntimeError(f"formal evaluation manifest hash changed: {relative_text}")
    return manifest, _sha256_file(manifest_path)


def _bit_equal(left: Any, right: Any) -> bool:
    left_array = np.ascontiguousarray(left)
    right_array = np.ascontiguousarray(right)
    return (
        left_array.dtype == right_array.dtype
        and left_array.shape == right_array.shape
        and left_array.tobytes(order="C") == right_array.tobytes(order="C")
    )


def _float_equal(left: Any, right: Any) -> bool:
    try:
        return np.float64(left).view(np.uint64) == np.float64(right).view(np.uint64)
    except (TypeError, ValueError):
        return False


def _score(target: np.ndarray, prediction: np.ndarray, mask: np.ndarray, denominator: float) -> float:
    residual = np.asarray(prediction[mask] - target[mask], dtype=np.float64)
    numerator = float(np.sum(np.square(residual), dtype=np.float64))
    value = 1.0 - numerator / denominator
    if not math.isfinite(numerator) or not math.isfinite(value):
        raise RuntimeError("independent Nash-Sutcliffe efficiency is non-finite")
    return float(value)


def _bootstrap(
    values: np.ndarray,
    *,
    seed: int,
    resamples: int,
) -> tuple[float, float, float]:
    generator = np.random.default_rng(int(seed))
    medians = np.empty(int(resamples), dtype=np.float64)
    cursor = 0
    while cursor < int(resamples):
        take = min(1024, int(resamples) - cursor)
        indices = generator.integers(0, len(values), size=(take, len(values)))
        medians[cursor : cursor + take] = np.median(values[indices], axis=1)
        cursor += take
    lower, upper = np.quantile(medians, [0.025, 0.975], method="linear")
    return float(np.median(values)), float(lower), float(upper)


def _decision(lower: float, upper: float) -> tuple[str, bool]:
    if lower >= 0.01:
        return "FILTER_PRACTICALLY_EXCEEDS_NEURAL_ENSEMBLE", True
    if lower >= -0.01:
        return (
            "FILTER_REACHES_NEURAL_ENSEMBLE_WITHOUT_PROVEN_PRACTICAL_SUPERIORITY",
            False,
        )
    if upper <= -0.01:
        return "FILTER_BELOW_NEURAL_ENSEMBLE", False
    return "INCONCLUSIVE", False


def _atomic_publish(destination: Path, payloads: Mapping[str, bytes]) -> None:
    from scripts import tukf09_455_training_common as training_common

    target = _absolute(destination)
    training_common.ensure_no_symlink_components(target)
    if target.exists() or target.is_symlink():
        raise FileExistsError("independent evaluation seal already exists")
    target.parent.mkdir(parents=True, exist_ok=True)
    training_common.ensure_no_symlink_components(target.parent)
    token = uuid.uuid4().hex
    pending = target.with_name(f".pending-{token[:10]}")
    pending.mkdir(exist_ok=False)
    try:
        for name, content in sorted(payloads.items()):
            if Path(name).name != name:
                raise ValueError("independent evaluation seal members must be direct files")
            with (pending / name).open("xb") as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
        if {path.name for path in pending.iterdir()} != set(payloads):
            raise RuntimeError("pending independent evaluation seal member set changed")
        if target.exists() or target.is_symlink():
            raise FileExistsError("independent evaluation seal appeared during publication")
        os.replace(pending, target)
    finally:
        if pending.exists() or pending.is_symlink():
            if pending.parent != target.parent or token[:10] not in pending.name:
                raise RuntimeError("refusing to remove an unowned independent pending directory")
            shutil.rmtree(pending)


def _verify_or_publish(destination: Path, payloads: Mapping[str, bytes]) -> bool:
    if destination.exists() or destination.is_symlink():
        if not destination.is_dir() or destination.is_symlink():
            raise RuntimeError("existing independent evaluation seal is invalid")
        actual = {
            path.name
            for path in destination.iterdir()
            if path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1
        }
        if actual != set(payloads) or len(list(destination.iterdir())) != len(payloads):
            raise RuntimeError("existing independent evaluation seal member set differs")
        for name, content in payloads.items():
            if (destination / name).read_bytes() != content:
                raise RuntimeError(f"existing independent evaluation seal differs: {name}")
        return True
    _atomic_publish(destination, payloads)
    return False


def _atomic_control_record(path: Path, payload: Mapping[str, Any]) -> dict[str, Any]:
    from scripts import tukf09_455_training_common as training_common

    destination = _absolute(path)
    if os.path.lexists(destination):
        raise FileExistsError(f"independent evaluation lifecycle record exists: {destination}")
    training_common.ensure_no_symlink_components(destination.parent)
    destination.parent.mkdir(parents=True, exist_ok=True)
    training_common.ensure_no_symlink_components(destination.parent)
    unsigned = dict(payload)
    unsigned.pop("record_sha256", None)
    record = dict(unsigned)
    record["record_sha256"] = _json_sha256(unsigned)
    content = _json_bytes(record)
    temporary = destination.with_name(f".pending-{uuid.uuid4().hex[:10]}")
    try:
        with temporary.open("xb") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        if os.path.lexists(destination):
            raise FileExistsError("independent evaluation lifecycle destination appeared")
        os.replace(temporary, destination)
    finally:
        if os.path.lexists(temporary):
            temporary.unlink()
    return record


def _reject_training_locks(control: Path) -> None:
    if not control.exists():
        return
    fixed = {
        ".training_phase.lock",
        ".filter_controller.lock",
        ".neural_controller.lock",
        ".sequence_controller.lock",
    }
    for path in control.rglob("*"):
        name = path.name.lower()
        if (
            name in fixed
            or name == "controller.lock"
            or name.endswith("_controller.lock")
            or name.endswith(".controller.lock")
        ):
            raise RuntimeError(f"training controller lock remains active or stale: {path}")


@contextmanager
def _independent_evaluation_lock(
    *, results_root: Path, admission_sha256: str, runtime_sha256: str
) -> Any:
    from scripts import tukf09_455_training_common as training_common

    control = _absolute(results_root) / "control"
    training_common.ensure_no_symlink_components(control)
    control.mkdir(parents=True, exist_ok=True)
    training_common.ensure_no_symlink_components(control)
    _reject_training_locks(control)
    if os.path.lexists(control / ".formal_evaluation.lock.json"):
        raise RuntimeError("active or stale formal evaluation lock forbids independent replay")
    lock_path = control / ".formal_evaluation_independent.lock.json"
    if os.path.lexists(lock_path):
        raise RuntimeError("independent formal-evaluation lock requires manual audit")
    record = {
        "schema_version": "tukf09_455_formal_evaluation_independent_lock_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "FORMAL_EVALUATION_INDEPENDENT_LOCK_HELD",
        "lock_identity": uuid.uuid4().hex,
        "admission_sha256": admission_sha256,
        "runtime_environment_identity_sha256": runtime_sha256,
        "process_id": os.getpid(),
    }
    content = _json_bytes(record)
    with lock_path.open("xb") as handle:
        handle.write(content)
        handle.flush()
        os.fsync(handle.fileno())
    try:
        yield lock_path
    finally:
        if not lock_path.is_file() or lock_path.is_symlink() or lock_path.read_bytes() != content:
            raise RuntimeError("independent formal-evaluation lock changed or disappeared")
        lock_path.unlink()


@dataclass
class IndependentProductionReplay:
    """A separately constructed replay of the sealed filter and neural models."""

    ordered_basin_ids: tuple[str, ...]
    admission_sha256: str
    semantic_members: Mapping[str, Mapping[str, Any]]
    contract: Mapping[str, Any]
    filter_training: Any
    filter_contexts: Mapping[str, Any]
    filter_specs: Mapping[str, Mapping[str, Any]]
    scaler: Mapping[str, Any]
    models: Mapping[tuple[int, int], Any]

    def _verify_period(
        self,
        basin_id: str,
        dates_ns: np.ndarray,
        forcing: np.ndarray,
        observations: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        if basin_id not in self.filter_contexts:
            raise RuntimeError(f"independent replay basin is not sealed: {basin_id}")
        dates = np.ascontiguousarray(dates_ns, dtype=np.dtype("<i8"))
        forcing_array = np.ascontiguousarray(forcing, dtype=np.dtype("<f8"))
        target = np.ascontiguousarray(observations, dtype=np.dtype("<f8"))
        arrays = {
            "dates_ns": (dates, "<i8"),
            "forcing": (forcing_array, "<f8"),
            "observations": (target, "<f8"),
        }
        for name, (array, dtype) in arrays.items():
            key = f"{basin_id}/evaluation/{name}"
            if _semantic_identity(key, array, dtype) != self.semantic_members.get(key):
                raise RuntimeError(f"independent replay semantic identity changed: {key}")
        return dates, forcing_array, target

    def _filter_predictions(
        self, basin_id: str, forcing: np.ndarray, observations: np.ndarray
    ) -> dict[int, np.ndarray]:
        import torch

        context = self.filter_contexts[basin_id]
        spec = self.filter_specs[basin_id]
        result = self.filter_training.run_parameterized_filter(
            context,
            torch.as_tensor(forcing, dtype=torch.float64).unsqueeze(1),
            torch.as_tensor(observations, dtype=torch.float64).unsqueeze(1),
            torch.as_tensor(spec["theta_log"], dtype=torch.float64),
            self.contract,
        )
        forecasts = self.filter_training.multilead_torch(
            context.plain_model,
            result["posterior_state"][:, 0, :],
            torch.as_tensor(forcing, dtype=torch.float64).unsqueeze(1),
        )
        aligned: dict[int, np.ndarray] = {}
        for lead, (prediction, indices) in forecasts.items():
            values = np.full(len(observations), np.nan, dtype=np.float64)
            values[indices.detach().cpu().numpy()] = prediction.detach().cpu().numpy()
            if int(np.count_nonzero(np.isfinite(values[FROZEN_FIRST_SCORING_INDEX :]))) != FROZEN_SUPPORTS[int(lead)]:
                raise RuntimeError(
                    f"independent filter replay support changed: {basin_id}, lead {lead}"
                )
            aligned[int(lead)] = values
        if set(aligned) != set(FROZEN_LEADS):
            raise RuntimeError(f"independent filter replay lead set changed: {basin_id}")
        return aligned

    def _neural_prediction(
        self,
        *,
        lead: int,
        seed: int,
        forcing: np.ndarray,
        observations: np.ndarray,
    ) -> np.ndarray:
        import torch

        model = self.models[(lead, seed)]
        forcing_center = np.asarray(self.scaler["forcing_center"], dtype=np.float64)
        forcing_scale = np.asarray(self.scaler["forcing_scale"], dtype=np.float64)
        discharge_center = float(self.scaler["discharge_center"])
        discharge_scale = float(self.scaler["discharge_scale"])
        device = next(model.parameters()).device
        length = 365
        batch_size = 256
        target_indices = np.arange(FROZEN_FIRST_SCORING_INDEX, len(observations), dtype=np.int64)
        aligned = np.full(len(observations), np.nan, dtype=np.float64)
        model.eval()
        with torch.no_grad():
            for cursor in range(0, len(target_indices), batch_size):
                targets = target_indices[cursor : cursor + batch_size]
                offsets = np.arange(length, dtype=np.int64) - (length - 1)
                forcing_indices = targets[:, None] + offsets[None, :]
                discharge_indices = forcing_indices - int(lead)
                observed = discharge_indices >= 0
                origins = np.broadcast_to(targets[:, None] - int(lead), discharge_indices.shape)
                if np.any(discharge_indices[observed] > origins[observed]):
                    raise RuntimeError("independent neural replay violated the causal lag")
                forcing_windows = (
                    forcing[forcing_indices] - forcing_center[None, None, :]
                ) / forcing_scale[None, None, :]
                lagged = np.full((len(targets), length, 1), np.nan, dtype=np.float64)
                rows, columns = np.nonzero(observed)
                lagged[rows, columns, 0] = observations[discharge_indices[rows, columns]]
                finite = np.isfinite(lagged)
                lagged[finite] = (lagged[finite] - discharge_center) / discharge_scale
                forcing_tensor = torch.as_tensor(
                    forcing_windows, dtype=torch.float32, device=device
                )
                lagged_tensor = torch.as_tensor(lagged, dtype=torch.float32, device=device)
                hidden = torch.zeros(
                    (1, len(targets), int(model.hidden_size)),
                    dtype=torch.float32,
                    device=device,
                )
                memory = torch.zeros_like(hidden)
                output = model(forcing_tensor, lagged_tensor, hidden, memory)
                if not isinstance(output, Mapping) or "y_hat" not in output:
                    raise RuntimeError("independent neural replay output changed")
                standardized = output["y_hat"]
                if standardized.shape != (len(targets), length, 1):
                    raise RuntimeError("independent neural replay shape changed")
                values = (
                    standardized[:, -1, 0] * discharge_scale + discharge_center
                ).detach().cpu().to(torch.float64).numpy()
                if not np.isfinite(values).all():
                    raise RuntimeError("independent neural replay is non-finite")
                aligned[targets] = values
        if int(np.count_nonzero(np.isfinite(aligned[FROZEN_FIRST_SCORING_INDEX :]))) != len(observations) - FROZEN_FIRST_SCORING_INDEX:
            raise RuntimeError("independent neural replay support changed")
        return aligned

    def replay(
        self,
        basin_id: str,
        dates_ns: np.ndarray,
        forcing: np.ndarray,
        observations: np.ndarray,
    ) -> tuple[dict[int, np.ndarray], dict[int, dict[int, np.ndarray]]]:
        _, forcing_array, target = self._verify_period(
            basin_id, dates_ns, forcing, observations
        )
        filter_predictions = self._filter_predictions(basin_id, forcing_array, target)
        neural_predictions = {
            lead: {
                seed: self._neural_prediction(
                    lead=lead,
                    seed=seed,
                    forcing=forcing_array,
                    observations=target,
                )
                for seed in FROZEN_SEEDS
            }
            for lead in FROZEN_LEADS
        }
        return filter_predictions, neural_predictions


def build_independent_production_replay(
    *, project_root: str | Path, admission_path: str | Path
) -> IndependentProductionReplay:
    """Bind an independent production replay without importing the evaluator."""

    import torch
    from hpc import admit_tukf09_455_formal_evaluation_compat_v5 as admission_module
    from scripts import run_tukf09_filter_training as filter_training
    from scripts.tukf07_information_matched_model import DirectAutoregressiveLSTM

    root = _absolute(project_root)
    admitted = admission_module.load_and_verify_evaluation_admission(
        admission_path, production=True
    )
    bindings = admitted.record["bindings"]
    contract = _read_json(
        Path(bindings["scientific_contract"]["path"]), label="scientific contract"
    )
    evaluation_config = _read_json(
        Path(bindings["formal_evaluation_config"]["path"]),
        label="formal evaluation configuration",
    )
    results_root = root / str(evaluation_config["paths"]["results_root"])

    preflight_final_path = Path(bindings["independent_preflight_final_manifest"]["path"])
    preflight_root = preflight_final_path.parent.parent
    preflight_final = _read_json(preflight_final_path, label="independent preflight final manifest")
    preflight_files = preflight_final.get("files")
    if not isinstance(preflight_files, Mapping):
        raise RuntimeError("independent preflight final file tree changed")
    for relative in (
        "population_registry.json",
        "parameters_only.npz",
        "semantic_input_manifest.sha256.json",
    ):
        _verify_record(
            preflight_root / relative,
            preflight_files[relative],
            label=f"independent preflight {relative}",
        )
    population = _read_json(
        preflight_root / "population_registry.json", label="population registry"
    )
    ordered = tuple(str(value) for value in population.get("eligible", ()))
    ordered_hash = sha256(
        "".join(f"{value}\n" for value in ordered).encode("utf-8")
    ).hexdigest()
    if (
        len(ordered) != FROZEN_BASIN_COUNT
        or EXCLUDED_BASIN_ID in ordered
        or ordered_hash != FROZEN_ORDERED_BASIN_NEWLINE_SHA256
    ):
        raise RuntimeError("independent replay population changed")
    with np.load(
        _require_file(preflight_root / "parameters_only.npz", label="parameters-only archive"),
        allow_pickle=False,
    ) as opened:
        if set(opened.files) != {"basin_ids", "parameter_names", "values"}:
            raise RuntimeError("parameters-only archive member set changed")
        parameter_ids = tuple(str(value) for value in opened["basin_ids"].tolist())
        parameter_names = tuple(str(value) for value in opened["parameter_names"].tolist())
        parameter_values = np.asarray(opened["values"], dtype=np.float64).copy()
    if parameter_ids != ordered or parameter_values.shape != (455, 13):
        raise RuntimeError("independent replay parameter population changed")
    parameter_rows = {
        basin: {
            name: float(parameter_values[index, column])
            for column, name in enumerate(parameter_names)
        }
        for index, basin in enumerate(ordered)
    }
    semantic_manifest = _read_json(
        preflight_root / "semantic_input_manifest.sha256.json",
        label="semantic input manifest",
    )
    all_members = semantic_manifest.get("members")
    if not isinstance(all_members, Mapping):
        raise RuntimeError("semantic input member tree changed")
    semantic_members = {
        key: dict(value)
        for key, value in all_members.items()
        if key.split("/")[1] == "evaluation"
    }
    if (
        len(semantic_members) != FROZEN_SEMANTIC_MEMBER_COUNT
        or sha256(_json_bytes(semantic_members)[:-1]).hexdigest() != FROZEN_EVALUATION_SEMANTIC_SHA256
    ):
        raise RuntimeError("independent replay evaluation semantics changed")

    selection_seal_path = Path(bindings["training_selection_seal"]["path"])
    selection_seal = _read_json(selection_seal_path, label="training selection seal")
    training_manifest_path = results_root / str(
        selection_seal["training_manifest_relative_path"]
    )
    if _sha256_file(training_manifest_path) != selection_seal["training_manifest_sha256"]:
        raise RuntimeError("independent replay training manifest changed")
    training_manifest = _read_json(training_manifest_path, label="training manifest")
    tree = training_manifest.get("files")
    if not isinstance(tree, Mapping):
        raise RuntimeError("training manifest file tree changed")
    filter_registry_path = results_root / "selection/filter_registry.json"
    neural_registry_path = results_root / "selection/neural_registry.json"
    for relative, path in (
        ("selection/filter_registry.json", filter_registry_path),
        ("selection/neural_registry.json", neural_registry_path),
    ):
        _verify_record(path, tree[relative], label=relative)
    filter_registry = _read_json(filter_registry_path, label="filter registry")
    neural_registry = _read_json(neural_registry_path, label="neural registry")
    filter_units = filter_registry.get("units")
    neural_units = neural_registry.get("units")
    if not isinstance(filter_units, list) or [unit.get("basin_id") for unit in filter_units] != list(ordered):
        raise RuntimeError("independent replay filter registry order changed")
    expected_neural = [(lead, seed) for lead in FROZEN_LEADS for seed in FROZEN_SEEDS]
    if not isinstance(neural_units, list) or [
        (unit.get("lead_days"), unit.get("seed")) for unit in neural_units
    ] != expected_neural:
        raise RuntimeError("independent replay neural registry order changed")

    filter_contexts: dict[str, Any] = {}
    filter_specs: dict[str, dict[str, Any]] = {}
    for unit in filter_units:
        basin = str(unit["basin_id"])
        unit_root = results_root / str(unit["unit_relative_path"])
        unit_manifest_path = unit_root / "manifest.sha256.json"
        if _sha256_file(unit_manifest_path) != unit["unit_manifest_sha256"]:
            raise RuntimeError(f"independent replay filter unit changed: {basin}")
        unit_manifest = _read_json(unit_manifest_path, label=f"filter manifest {basin}")
        for name in ("identity.json", "selection.json"):
            _verify_record(
                unit_root / name,
                unit_manifest["files"][name],
                label=f"filter {basin} {name}",
            )
        identity = _read_json(unit_root / "identity.json", label=f"filter identity {basin}")
        selection = _read_json(unit_root / "selection.json", label=f"filter selection {basin}")
        context = filter_training.build_causal_filter_context(
            basin, parameter_rows[basin], np.asarray([0.0, 1.0], dtype=np.float64), contract
        )
        initial_state = np.asarray(identity["initial_state"], dtype=np.float64)
        base_variance = float(identity["base_observation_variance"])
        theta_log = np.asarray(selection["selected_theta_log"], dtype=np.float64)
        process_diagonal = np.asarray(
            selection["selected_process_diagonal"], dtype=np.float64
        )
        r_b = float(selection["selected_r_b"])
        decoded_process, decoded_r_b = filter_training.decode_theta(
            torch.as_tensor(theta_log, dtype=torch.float64), context.dimension, contract
        )
        serialized_actual = np.exp(theta_log)
        if (
            not np.array_equal(context.initial_state[0].numpy(), initial_state)
            or not math.isfinite(base_variance)
            or base_variance <= 0.0
            or not np.array_equal(serialized_actual[:-1], process_diagonal)
            or float(serialized_actual[-1]) != r_b
            or process_diagonal.tolist() != unit.get("selected_process_diagonal")
            or r_b != unit.get("selected_r_b")
        ):
            raise RuntimeError(f"independent replay filter selection changed: {basin}")
        context.base_observation_variance = base_variance
        filter_contexts[basin] = context
        filter_specs[basin] = {"theta_log": theta_log}

    scaler_path = results_root / str(neural_registry["training_scaler_relative_path"])
    if _sha256_file(scaler_path) != neural_registry["training_scaler_sha256"]:
        raise RuntimeError("independent replay training-only scaler changed")
    scaler = _read_json(scaler_path, label="training-only neural scaler")
    if (
        scaler.get("basin_ids") != list(ordered)
        or scaler.get("normalization_scope")
        != "training_only_global_population_statistics"
    ):
        raise RuntimeError("independent replay scaler population changed")
    if not torch.cuda.is_available():
        raise RuntimeError("independent production replay requires CUDA")
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    device = torch.device("cuda")
    models: dict[tuple[int, int], Any] = {}
    for unit in neural_units:
        lead, seed = int(unit["lead_days"]), int(unit["seed"])
        checkpoint_path = results_root / str(unit["selected_checkpoint_relative_path"])
        if _sha256_file(checkpoint_path) != unit["selected_checkpoint_sha256"]:
            raise RuntimeError(f"independent replay checkpoint changed: lead {lead}, seed {seed}")
        checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
        if (
            checkpoint.get("experiment_id") != EXPERIMENT_ID
            or checkpoint.get("unit_id") != unit["unit_id"]
            or int(checkpoint.get("epoch", -1)) != int(unit["selected_epoch"])
            or checkpoint.get("training_scaler_sha256")
            != neural_registry["training_scaler_sha256"]
            or checkpoint.get("evaluation_access_count") != 0
        ):
            raise RuntimeError(f"independent replay checkpoint identity changed: lead {lead}, seed {seed}")
        model = DirectAutoregressiveLSTM(lead_days=lead).to(device)
        model.load_state_dict(checkpoint["model_state"], strict=True)
        model.eval()
        models[(lead, seed)] = model
    return IndependentProductionReplay(
        ordered_basin_ids=ordered,
        admission_sha256=admitted.file_sha256,
        semantic_members=semantic_members,
        contract=contract,
        filter_training=filter_training,
        filter_contexts=filter_contexts,
        filter_specs=filter_specs,
        scaler=scaler,
        models=models,
    )


def verify_formal_evaluation_independently(
    *,
    authorize: bool,
    evaluation_root: str | Path,
    independent_root: str | Path,
    expected_basin_ids: Sequence[str],
    replay_basin: Callable[
        [str], tuple[Mapping[int, np.ndarray], Mapping[int, Mapping[int, np.ndarray]]]
    ]
    | None,
    replay_basin_arrays: Callable[
        [str, np.ndarray, np.ndarray, np.ndarray],
        tuple[Mapping[int, np.ndarray], Mapping[int, Mapping[int, np.ndarray]]],
    ]
    | None = None,
    expected_admission_sha256: str | None = None,
    bootstrap_seed: int = FROZEN_BOOTSTRAP_SEED,
    bootstrap_resamples: int = FROZEN_BOOTSTRAP_RESAMPLES,
    production: bool = True,
    _production_token: object | None = None,
) -> dict[str, Any]:
    """Recompute stored metrics and optionally replay every model prediction."""

    if authorize is not True:
        raise PermissionError("explicit independent formal-evaluation verification is required")
    if production and _production_token is not _PRODUCTION_ENTRY_TOKEN:
        raise PermissionError("production independent replay is available only through the fixed entry")
    if replay_basin is not None and replay_basin_arrays is not None:
        raise ValueError("independent verification accepts only one prediction replay interface")
    root = _absolute(evaluation_root)
    destination = _absolute(independent_root)
    if not root.is_dir() or root.is_symlink():
        raise FileNotFoundError("formal evaluation root is absent or linked")
    ordered = tuple(str(value) for value in expected_basin_ids)
    if not ordered or len(set(ordered)) != len(ordered) or EXCLUDED_BASIN_ID in ordered:
        raise ValueError("independent evaluation population is empty, duplicated, or excluded")
    if production:
        if len(ordered) != FROZEN_BASIN_COUNT:
            raise ValueError("independent production evaluation requires exactly 455 basins")
        if int(bootstrap_seed) != FROZEN_BOOTSTRAP_SEED or int(bootstrap_resamples) != FROZEN_BOOTSTRAP_RESAMPLES:
            raise ValueError("independent production bootstrap settings changed")

    manifest, manifest_sha256 = _load_and_verify_manifest(root, len(ordered))
    identity = _read_json(root / "identity.json", label="formal evaluation identity")
    summary = _read_json(
        root / "evaluation_summary.json", label="formal evaluation summary"
    )
    ledger = _read_json(root / "access_ledger.json", label="formal evaluation access ledger")
    first = int(identity.get("first_scoring_index", -1))
    if (
        identity.get("experiment_id") != EXPERIMENT_ID
        or tuple(identity.get("ordered_basin_ids", ())) != ordered
        or int(identity.get("basin_count", -1)) != len(ordered)
        or tuple(identity.get("lead_days", ())) != FROZEN_LEADS
        or tuple(identity.get("neural_seeds", ())) != FROZEN_SEEDS
        or (production and first != FROZEN_FIRST_SCORING_INDEX)
        or (
            expected_admission_sha256 is not None
            and identity.get("admission_sha256") != expected_admission_sha256
        )
    ):
        raise RuntimeError("formal evaluation identity changed")
    if (
        int(ledger.get("evaluation_array_reads", -1)) != len(ordered) * 3
        or int(ledger.get("evaluation_predictions", -1)) != len(ordered) * 15
        or (
            production
            and int(ledger.get("neural_scalar_predictions", -1))
            != FROZEN_NEURAL_SCALAR_PREDICTIONS
        )
        or int(ledger.get("evaluation_metrics", -1)) != len(ordered) * 15
        or int(ledger.get("evaluation_outputs", -1)) != len(ordered) * 2 + 4
    ):
        raise RuntimeError("formal evaluation access ledger count changed")

    paired_values: list[float] = []
    support_totals = {lead: 0 for lead in FROZEN_LEADS}
    replayed_predictions = 0
    denominator_count = 0
    for basin_id in ordered:
        archive_path = root / "basins" / f"{basin_id}.predictions.npz"
        metrics = _read_json(
            root / "basins" / f"{basin_id}.metrics.json",
            label=f"basin {basin_id} metric record",
        )
        with np.load(_require_file(archive_path, label="basin prediction archive"), allow_pickle=False) as opened:
            arrays = {name: np.asarray(opened[name]) for name in opened.files}
        expected_names = {
            "dates_ns",
            "forcing",
            "target",
            *{f"filter_lead_{lead}" for lead in FROZEN_LEADS},
            *{f"ensemble_lead_{lead}" for lead in FROZEN_LEADS},
            *{f"common_mask_lead_{lead}" for lead in FROZEN_LEADS},
            *{
                f"seed_lead_{lead}_seed_{seed}"
                for lead in FROZEN_LEADS
                for seed in FROZEN_SEEDS
            },
        }
        if set(arrays) != expected_names:
            raise RuntimeError(f"basin prediction archive member set changed: {basin_id}")
        dates = np.asarray(arrays["dates_ns"])
        forcing = np.asarray(arrays["forcing"])
        target = np.asarray(arrays["target"])
        days = len(target)
        if (
            dates.dtype != np.dtype("int64")
            or target.dtype != np.dtype("float64")
            or forcing.dtype != np.dtype("float64")
            or dates.shape != (days,)
            or forcing.shape != (days, 3)
            or not np.isfinite(target).all()
            or np.any(target < 0.0)
            or not np.isfinite(forcing).all()
            or (production and days != FROZEN_DAY_COUNT)
        ):
            raise RuntimeError(f"basin evaluation arrays changed: {basin_id}")

        replay_filter: Mapping[int, np.ndarray] | None = None
        replay_seeds: Mapping[int, Mapping[int, np.ndarray]] | None = None
        if replay_basin_arrays is not None:
            replay_filter, replay_seeds = replay_basin_arrays(
                basin_id, dates, forcing, target
            )
            if set(replay_filter) != set(FROZEN_LEADS) or set(replay_seeds) != set(FROZEN_LEADS):
                raise RuntimeError(f"independent prediction replay lead set changed: {basin_id}")
        elif replay_basin is not None:
            replay_filter, replay_seeds = replay_basin(basin_id)
            if set(replay_filter) != set(FROZEN_LEADS) or set(replay_seeds) != set(FROZEN_LEADS):
                raise RuntimeError(f"independent prediction replay lead set changed: {basin_id}")
        per_lead_differences: list[float] = []
        lead_metrics = metrics.get("leads")
        if not isinstance(lead_metrics, dict) or set(lead_metrics) != {"1", "2", "3"}:
            raise RuntimeError(f"basin metric lead set changed: {basin_id}")
        for lead in FROZEN_LEADS:
            filter_prediction = np.asarray(arrays[f"filter_lead_{lead}"], dtype=np.float64)
            stored_ensemble = np.asarray(arrays[f"ensemble_lead_{lead}"], dtype=np.float64)
            seeds = [
                np.asarray(arrays[f"seed_lead_{lead}_seed_{seed}"], dtype=np.float64)
                for seed in FROZEN_SEEDS
            ]
            stored_mask = np.asarray(arrays[f"common_mask_lead_{lead}"])
            if any(value.shape != (days,) for value in [filter_prediction, stored_ensemble, *seeds]):
                raise RuntimeError(f"basin prediction shape changed: {basin_id}, lead {lead}")
            ensemble = np.mean(np.stack(seeds, axis=0), axis=0, dtype=np.float64)
            if not _bit_equal(stored_ensemble, ensemble):
                raise RuntimeError(f"stored three-seed ensemble changed: {basin_id}, lead {lead}")
            index_gate = np.arange(days, dtype=np.int64) >= first
            mask = index_gate & np.isfinite(target) & np.isfinite(filter_prediction) & np.isfinite(ensemble)
            if stored_mask.dtype != np.dtype("bool") or not _bit_equal(stored_mask, mask):
                raise RuntimeError(f"stored exact common mask changed: {basin_id}, lead {lead}")
            count = int(np.count_nonzero(mask))
            if production and count != FROZEN_SUPPORTS[lead]:
                raise RuntimeError(f"production support changed: {basin_id}, lead {lead}")
            selected_target = np.asarray(target[mask], dtype=np.float64)
            mean = float(np.mean(selected_target, dtype=np.float64))
            denominator = float(
                np.sum(np.square(selected_target - mean), dtype=np.float64)
            )
            if not math.isfinite(denominator) or denominator <= 0.0:
                raise RuntimeError(f"independent target variance is undefined: {basin_id}, lead {lead}")
            filter_nse = _score(target, filter_prediction, mask, denominator)
            ensemble_nse = _score(target, ensemble, mask, denominator)
            seed_nse = [_score(target, value, mask, denominator) for value in seeds]
            stored = lead_metrics[str(lead)]
            if (
                int(stored.get("support_count", -1)) != count
                or not _float_equal(stored.get("target_denominator_float64"), denominator)
                or not _float_equal(stored.get("filter_nse"), filter_nse)
                or not _float_equal(stored.get("neural_ensemble_nse"), ensemble_nse)
                or not _float_equal(
                    stored.get("filter_minus_neural_ensemble_nse"),
                    filter_nse - ensemble_nse,
                )
                or not isinstance(stored.get("neural_seed_nse"), dict)
                or any(
                    not _float_equal(stored["neural_seed_nse"].get(str(seed)), seed_nse[index])
                    for index, seed in enumerate(FROZEN_SEEDS)
                )
            ):
                raise RuntimeError(f"stored basin metrics differ from independent recomputation: {basin_id}, lead {lead}")
            if replay_filter is not None and replay_seeds is not None:
                if set(replay_seeds[lead]) != set(FROZEN_SEEDS):
                    raise RuntimeError(f"independent replay seed set changed: {basin_id}, lead {lead}")
                if not _bit_equal(
                    np.asarray(replay_filter[lead], dtype=np.float64), filter_prediction
                ):
                    raise RuntimeError(f"independent filter prediction replay differs: {basin_id}, lead {lead}")
                replayed_predictions += 1
                for index, seed in enumerate(FROZEN_SEEDS):
                    if not _bit_equal(
                        np.asarray(replay_seeds[lead][seed], dtype=np.float64), seeds[index]
                    ):
                        raise RuntimeError(
                            f"independent neural prediction replay differs: {basin_id}, lead {lead}, seed {seed}"
                        )
                    replayed_predictions += 1
                replayed_ensemble = np.mean(
                    np.stack(
                        [np.asarray(replay_seeds[lead][seed], dtype=np.float64) for seed in FROZEN_SEEDS],
                        axis=0,
                    ),
                    axis=0,
                    dtype=np.float64,
                )
                if not _bit_equal(replayed_ensemble, ensemble):
                    raise RuntimeError(f"independent ensemble replay differs: {basin_id}, lead {lead}")
                replayed_predictions += 1
            per_lead_differences.append(float(filter_nse - ensemble_nse))
            support_totals[lead] += count
            denominator_count += 1
        basin_paired = float(np.mean(per_lead_differences, dtype=np.float64))
        if not _float_equal(metrics.get("lead_mean_filter_minus_neural_ensemble_nse"), basin_paired):
            raise RuntimeError(f"stored basin paired value differs: {basin_id}")
        if (
            int(metrics.get("prediction_vector_count", -1)) != 15
            or int(metrics.get("primary_nse_count", -1)) != 6
            or int(metrics.get("supplemental_seed_nse_count", -1)) != 9
            or int(metrics.get("target_denominator_count", -1)) != 3
        ):
            raise RuntimeError(f"stored basin metric counts differ: {basin_id}")
        paired_values.append(basin_paired)

    paired = np.asarray(paired_values, dtype=np.float64)
    population_median, lower, upper = _bootstrap(
        paired,
        seed=int(bootstrap_seed),
        resamples=int(bootstrap_resamples),
    )
    decision, success = _decision(lower, upper)
    if (
        int(summary.get("target_denominator_count", -1)) != len(ordered) * 3
        or int(summary.get("prediction_vector_count", -1)) != len(ordered) * 15
        or int(summary.get("primary_nse_count", -1)) != len(ordered) * 6
        or int(summary.get("supplemental_seed_nse_count", -1)) != len(ordered) * 9
        or int(summary.get("total_nse_count", -1)) != len(ordered) * 15
        or int(summary.get("paired_basin_count", -1)) != len(ordered)
        or summary.get("support_totals") != {str(lead): support_totals[lead] for lead in FROZEN_LEADS}
        or not _float_equal(summary.get("population_median_filter_minus_neural_ensemble_nse"), population_median)
        or summary.get("scientific_decision") != decision
        or summary.get("scientific_success") is not success
    ):
        raise RuntimeError("formal evaluation population summary differs from independent recomputation")
    # Split the JSON key literal so this independent source never names the
    # production helper that implements the same algorithm.
    stored_bootstrap = summary.get("paired_" "basin_bootstrap")
    if (
        not isinstance(stored_bootstrap, dict)
        or int(stored_bootstrap.get("seed", -1)) != int(bootstrap_seed)
        or int(stored_bootstrap.get("resamples", -1)) != int(bootstrap_resamples)
        or stored_bootstrap.get("quantile_method") != "linear"
        or not _float_equal(stored_bootstrap.get("lower"), lower)
        or not _float_equal(stored_bootstrap.get("upper"), upper)
    ):
        raise RuntimeError("formal evaluation bootstrap differs from independent recomputation")

    full_replay = (
        replay_basin is not None or replay_basin_arrays is not None
    ) and replayed_predictions == len(ordered) * 15
    status = (
        "FULL_EVALUATION_INDEPENDENTLY_REPRODUCED"
        if full_replay
        else "METRICS_ONLY_NOT_FULL_PREDICTION_REPLAY"
    )
    audit = {
        "schema_version": "tukf09_455_formal_evaluation_independent_audit_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": status,
        "mismatch_count": 0,
        "source_evaluation_manifest_sha256": manifest_sha256,
        "basin_count": len(ordered),
        "target_denominator_count": denominator_count,
        "prediction_vectors_replayed": replayed_predictions,
        "prediction_vectors_expected": len(ordered) * 15,
        "metrics_independently_recomputed": len(ordered) * 15,
        "paired_basin_count": len(paired),
        "bootstrap_resamples_recomputed": int(bootstrap_resamples),
        "population_median_filter_minus_neural_ensemble_nse": population_median,
        "bootstrap_lower": lower,
        "bootstrap_upper": upper,
        "scientific_decision": decision,
        "scientific_success": success,
        "full_prediction_replay": full_replay,
    }
    audit_bytes = _json_bytes(audit)
    final_manifest = {
        "schema_version": "tukf09_455_formal_evaluation_independent_final_manifest_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": status,
        "file_count": 1,
        "files": {"independent_audit.json": {"sha256": sha256(audit_bytes).hexdigest(), "size_bytes": len(audit_bytes)}},
        "source_evaluation_manifest_sha256": manifest_sha256,
    }
    payloads = {
        "independent_audit.json": audit_bytes,
        "manifest.final.sha256.json": _json_bytes(final_manifest),
    }
    reused = _verify_or_publish(destination, payloads)
    return {
        "status": status,
        "mismatch_count": 0,
        "basin_count": len(ordered),
        "prediction_vectors_replayed": replayed_predictions,
        "reused": reused,
    }


def _validate_formal_lifecycle_for_independent_replay(
    *,
    control: Path,
    evaluation_root: Path,
    summary_path: Path,
    admission_sha256: str,
    runtime_sha256: str,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    """Validate the exact formal attempt/consumption/success cross-hash chain."""

    paths = {
        "attempt": control / "formal_evaluation_compat_v5_attempt.json",
        "consumption": control / "formal_evaluation_compat_v5_consumption.json",
        "success": control / "formal_evaluation_compat_v5_success.json",
    }
    records = {
        label: _read_json(path, label=f"formal evaluation {label}")
        for label, path in paths.items()
    }
    expected_keys = {
        "attempt": {
            "schema_version", "experiment_id", "status", "created_utc", "attempt_id",
            "admission_sha256", "lock_sha256", "runtime_environment_identity_sha256",
            "evaluation_output_root", "evaluation_arrays_loaded", "evaluation_access_ledger",
            "retry_allowed", "record_sha256",
        },
        "consumption": {
            "schema_version", "experiment_id", "status", "created_utc", "attempt_id",
            "attempt_record_sha256", "admission_sha256", "evaluation_access_consumed",
            "evaluation_array_read_attempts", "evaluation_arrays_loaded_at_publication",
            "retry_allowed", "record_sha256",
        },
        "success": {
            "schema_version", "experiment_id", "status", "created_utc", "attempt_id",
            "attempt_record_sha256", "consumption_record_sha256",
            "evaluation_summary_path", "evaluation_summary_sha256",
            "evaluation_manifest_sha256", "evaluation_access_ledger_sha256",
            "retry_allowed", "record_sha256",
        },
    }
    for label, record in records.items():
        if set(record) != expected_keys[label]:
            raise RuntimeError(f"formal evaluation {label} lifecycle schema changed")
        unsigned = dict(record)
        stored = unsigned.pop("record_sha256")
        if stored != _json_sha256(unsigned):
            raise RuntimeError(f"formal evaluation {label} lifecycle self-hash changed")
        if record.get("experiment_id") != EXPERIMENT_ID or not isinstance(
            record.get("created_utc"), str
        ):
            raise RuntimeError(f"formal evaluation {label} lifecycle identity changed")
    attempt, consumption, success = (
        records["attempt"], records["consumption"], records["success"]
    )
    zero_ledger = {
        "evaluation_array_reads": 0,
        "evaluation_predictions": 0,
        "evaluation_metrics": 0,
        "evaluation_outputs": 0,
    }
    if (
        attempt["schema_version"] != "tukf09_455_formal_evaluation_attempt_v1"
        or attempt["status"] != "FORMAL_EVALUATION_ATTEMPT_REGISTERED_ZERO_ACCESS"
        or attempt["admission_sha256"] != admission_sha256
        or attempt["runtime_environment_identity_sha256"] != runtime_sha256
        or attempt["evaluation_output_root"] != os.fspath(_absolute(evaluation_root))
        or attempt["evaluation_arrays_loaded"] is not False
        or attempt["evaluation_access_ledger"] != zero_ledger
        or attempt["retry_allowed"] is not False
        or not isinstance(attempt["lock_sha256"], str)
        or len(attempt["lock_sha256"]) != 64
    ):
        raise RuntimeError("formal evaluation attempt lifecycle binding changed")
    if (
        consumption["schema_version"] != "tukf09_455_formal_evaluation_consumption_v1"
        or consumption["status"]
        != "FORMAL_EVALUATION_ACCESS_CONSUMED_BEFORE_FIRST_ARRAY_READ"
        or consumption["attempt_id"] != attempt["attempt_id"]
        or consumption["attempt_record_sha256"] != attempt["record_sha256"]
        or consumption["admission_sha256"] != admission_sha256
        or consumption["evaluation_access_consumed"] is not True
        or consumption["evaluation_array_read_attempts"] != 1
        or consumption["evaluation_arrays_loaded_at_publication"] is not False
        or consumption["retry_allowed"] is not False
    ):
        raise RuntimeError("formal evaluation consumption lifecycle binding changed")
    if (
        success["schema_version"] != "tukf09_455_formal_evaluation_success_v1"
        or success["status"] != "FORMAL_EVALUATION_OUTPUT_PUBLISHED_RETRY_FORBIDDEN"
        or success["attempt_id"] != attempt["attempt_id"]
        or success["attempt_record_sha256"] != attempt["record_sha256"]
        or success["consumption_record_sha256"] != _sha256_file(paths["consumption"])
        or success["evaluation_summary_path"] != os.fspath(_absolute(summary_path))
        or success["evaluation_summary_sha256"] != _sha256_file(summary_path)
        or success["evaluation_manifest_sha256"]
        != _sha256_file(evaluation_root / "manifest.sha256.json")
        or success["evaluation_access_ledger_sha256"]
        != _sha256_file(evaluation_root / "access_ledger.json")
        or success["retry_allowed"] is not False
    ):
        raise RuntimeError("formal evaluation success lifecycle binding changed")
    return attempt, consumption, success


def verify_formal_evaluation_independently_from_fixed_artifacts(
    *, authorize: bool, project_root: str | Path = ROOT
) -> dict[str, Any]:
    """Fixed production CLI: rebuild all 6,825 prediction vectors with no injection."""

    if authorize is not True:
        raise PermissionError("explicit independent formal-evaluation verification is required")
    from hpc import admit_tukf09_455_formal_evaluation_compat_v5 as admission_module

    root = _absolute(project_root)
    config_path = root / (
        "configs/tukf09_455_basin_zero_validation_target_variance_formal_evaluation_v1.json"
    )
    config = _read_json(config_path, label="fixed formal evaluation configuration")
    expected_paths = {
        "results_root": "results/tukf09_455_basin_zero_validation_target_variance_revision_v1",
        "formal_evaluation": (
            "results/tukf09_455_basin_zero_validation_target_variance_revision_v1/evaluation"
        ),
        "evaluation_summary": (
            "results/tukf09_455_basin_zero_validation_target_variance_revision_v1/"
            "evaluation/evaluation_summary.json"
        ),
        "independent_evaluation": (
            "results/tukf09_455_basin_zero_validation_target_variance_revision_v1/"
            "evaluation_independent"
        ),
    }
    if any(config.get("paths", {}).get(key) != value for key, value in expected_paths.items()):
        raise RuntimeError("fixed independent evaluation paths changed")
    results_root = root / expected_paths["results_root"]
    evaluation_root = root / expected_paths["formal_evaluation"]
    independent_root = root / expected_paths["independent_evaluation"]
    admission_path = root / admission_module.compat.ADMISSION_RELATIVE
    admitted = admission_module.load_and_verify_evaluation_admission(
        admission_path, production=True
    )
    runtime_sha256 = admitted.record.get("runtime_environment_identity_sha256")
    if not isinstance(runtime_sha256, str) or len(runtime_sha256) != 64:
        raise RuntimeError("formal evaluation admission runtime identity is absent")
    control = results_root / "control"
    formal_failure_path = control / "formal_evaluation_compat_v5_failure.json"
    if os.path.lexists(formal_failure_path):
        raise RuntimeError("failed formal evaluation cannot enter independent replay")
    _validate_formal_lifecycle_for_independent_replay(
        control=control,
        evaluation_root=evaluation_root,
        summary_path=root / expected_paths["evaluation_summary"],
        admission_sha256=admitted.file_sha256,
        runtime_sha256=runtime_sha256,
    )

    lifecycle = {
        "attempt": control / "formal_evaluation_independent_compat_v5_attempt.json",
        "consumption": control / "formal_evaluation_independent_compat_v5_consumption.json",
        "failure": control / "formal_evaluation_independent_compat_v5_failure.json",
        "success": control / "formal_evaluation_independent_compat_v5_success.json",
    }
    existing = sorted(name for name, path in lifecycle.items() if os.path.lexists(path))
    if existing or os.path.lexists(independent_root):
        raise FileExistsError(
            "independent evaluation attempt was already consumed; retry is forbidden"
        )
    with _independent_evaluation_lock(
        results_root=results_root,
        admission_sha256=admitted.file_sha256,
        runtime_sha256=runtime_sha256,
    ) as lock_path:
        attempt_id = sha256(
            _json_bytes(
                {
                    "admission_sha256": admitted.file_sha256,
                    "source_evaluation_manifest_sha256": _sha256_file(
                        evaluation_root / "manifest.sha256.json"
                    ),
                    "independent_root": os.fspath(_absolute(independent_root)),
                    "runtime_environment_identity_sha256": runtime_sha256,
                }
            )
        ).hexdigest()[:32]
        attempt = _atomic_control_record(
            lifecycle["attempt"],
            {
                "schema_version": "tukf09_455_formal_evaluation_independent_attempt_v1",
                "experiment_id": EXPERIMENT_ID,
                "status": "INDEPENDENT_EVALUATION_ATTEMPT_REGISTERED_ZERO_ACCESS",
                "created_utc": datetime.now(timezone.utc).isoformat(),
                "attempt_id": attempt_id,
                "admission_sha256": admitted.file_sha256,
                "lock_sha256": _sha256_file(lock_path),
                "runtime_environment_identity_sha256": runtime_sha256,
                "evaluation_arrays_loaded": False,
                "evaluation_access_ledger": {
                    "evaluation_array_reads": 0,
                    "evaluation_predictions": 0,
                    "evaluation_metrics": 0,
                    "evaluation_outputs": 0,
                },
                "retry_allowed": False,
            },
        )
        try:
            inside = admission_module.load_and_verify_evaluation_admission(
                admission_path, production=True
            )
            if inside.file_sha256 != admitted.file_sha256:
                raise RuntimeError("formal evaluation admission changed inside independent lock")
            replay = build_independent_production_replay(
                project_root=root, admission_path=admission_path
            )
            _atomic_control_record(
                lifecycle["consumption"],
                {
                    "schema_version": "tukf09_455_formal_evaluation_independent_consumption_v1",
                    "experiment_id": EXPERIMENT_ID,
                    "status": "INDEPENDENT_EVALUATION_ACCESS_CONSUMED_BEFORE_FIRST_ARRAY_READ",
                    "created_utc": datetime.now(timezone.utc).isoformat(),
                    "attempt_id": attempt_id,
                    "attempt_record_sha256": attempt["record_sha256"],
                    "evaluation_access_consumed": True,
                    "evaluation_array_read_attempts": 1,
                    "evaluation_arrays_loaded_at_publication": False,
                    "retry_allowed": False,
                },
            )
            result = verify_formal_evaluation_independently(
                authorize=True,
                evaluation_root=evaluation_root,
                independent_root=independent_root,
                expected_basin_ids=replay.ordered_basin_ids,
                replay_basin=None,
                replay_basin_arrays=replay.replay,
                expected_admission_sha256=replay.admission_sha256,
                production=True,
                _production_token=_PRODUCTION_ENTRY_TOKEN,
            )
            if result.get("status") != "FULL_EVALUATION_INDEPENDENTLY_REPRODUCED":
                raise RuntimeError("fixed independent replay did not reproduce every prediction")
            success = _atomic_control_record(
                lifecycle["success"],
                {
                    "schema_version": "tukf09_455_formal_evaluation_independent_success_v1",
                    "experiment_id": EXPERIMENT_ID,
                    "status": "FULL_EVALUATION_INDEPENDENTLY_REPRODUCED_RETRY_FORBIDDEN",
                    "created_utc": datetime.now(timezone.utc).isoformat(),
                    "attempt_id": attempt_id,
                    "attempt_record_sha256": attempt["record_sha256"],
                    "consumption_record_sha256": _sha256_file(lifecycle["consumption"]),
                    "independent_final_manifest_sha256": _sha256_file(
                        independent_root / "manifest.final.sha256.json"
                    ),
                    "retry_allowed": False,
                },
            )
            returned = dict(result)
            returned["success_record_sha256"] = success["record_sha256"]
            return returned
        except BaseException as exc:
            consumed = os.path.lexists(lifecycle["consumption"])
            _atomic_control_record(
                lifecycle["failure"],
                {
                    "schema_version": "tukf09_455_formal_evaluation_independent_failure_v1",
                    "experiment_id": EXPERIMENT_ID,
                    "status": "INDEPENDENT_EVALUATION_FAILED_RETRY_FORBIDDEN",
                    "created_utc": datetime.now(timezone.utc).isoformat(),
                    "attempt_id": attempt_id,
                    "attempt_record_sha256": attempt["record_sha256"],
                    "evaluation_access_consumed": consumed,
                    "consumption_record_sha256": (
                        _sha256_file(lifecycle["consumption"]) if consumed else None
                    ),
                    "independent_output_exists": os.path.lexists(independent_root),
                    "exception_type": f"{type(exc).__module__}.{type(exc).__qualname__}",
                    "exception_message": str(exc),
                    "retry_allowed": False,
                },
            )
            raise


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify-formal-evaluation-independently", action="store_true")
    parser.add_argument("--project-root", type=Path, default=ROOT)
    return parser


def main() -> None:
    arguments = _parser().parse_args()
    result = verify_formal_evaluation_independently_from_fixed_artifacts(
        authorize=bool(arguments.verify_formal_evaluation_independently),
        project_root=arguments.project_root,
    )
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()


__all__ = [
    "verify_formal_evaluation_independently",
    "verify_formal_evaluation_independently_from_fixed_artifacts",
]
