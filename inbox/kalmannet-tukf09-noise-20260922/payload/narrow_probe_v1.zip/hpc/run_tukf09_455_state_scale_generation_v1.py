"""Generate and seal all 455 deterministic training-state scale trajectories."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import gc
import json
import os
from pathlib import Path
import sys
import time
from typing import Any, Mapping

import numpy as np
import psutil


ROOT = Path(__file__).resolve().parents[1]
for _extra in (str(ROOT), str(ROOT / "src"), str(ROOT / "hpc")):
    if _extra not in sys.path:
        sys.path.insert(0, _extra)

import tukf09_455_state_scale_generation_common_v1 as common  # noqa: E402


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _peak_rss_bytes(process: psutil.Process) -> int:
    info = process.memory_info()
    values = [int(info.rss)]
    for name in ("peak_wset", "peak_rss"):
        if hasattr(info, name):
            values.append(int(getattr(info, name)))
    return max(values)


def _resource_check(
    *,
    started: float,
    process: psutil.Process,
    limits: Mapping[str, Any],
    stage: str,
) -> dict[str, Any]:
    elapsed = time.perf_counter() - started
    peak = _peak_rss_bytes(process)
    if elapsed > float(limits["wall_seconds"]):
        raise TimeoutError(f"state-scale generation exceeded wall cap after {stage}: {elapsed}")
    if peak > int(limits["maximum_process_rss_bytes"]):
        raise MemoryError(f"state-scale generation exceeded memory cap after {stage}: {peak}")
    return {"stage": stage, "elapsed_seconds": elapsed, "peak_process_rss_bytes": peak}


def _write_failure(
    root: Path,
    exc: BaseException,
    *,
    completed_basins: list[str],
    resource_stages: list[dict[str, Any]],
) -> None:
    payload = {
        "schema_version": "tukf09_455_state_scale_generation_failure_v1",
        "experiment_id": common.EXPERIMENT_ID,
        "stage_id": common.STAGE_ID,
        "status": "FORMAL_STATE_SCALE_GENERATION_FAILED_LATER_STAGES_HOLD",
        "failed_at_utc": _utc_now(),
        "exception_type": type(exc).__name__,
        "exception_message": str(exc),
        "completed_basin_count": len(completed_basins),
        "completed_basins": completed_basins,
        "resource_stages": resource_stages,
        "automatic_retry_permitted": False,
        "validation_array_reads": 0,
        "evaluation_array_reads": 0,
        "discharge_observation_array_reads": 0,
        "local_noise_optimization_updates": 0,
        "scientific_performance_result": False,
    }
    try:
        common.base.atomic_write_json_exclusive(root / "failure.json", payload)
    except FileExistsError:
        pass
    try:
        manifest = common.build_tree_manifest(
            root,
            schema_version="tukf09_455_state_scale_generation_failure_manifest_v1",
            status="FORMAL_STATE_SCALE_GENERATION_FAILED_LATER_STAGES_HOLD",
        )
        common.base.atomic_write_json_exclusive(root / "manifest.failure.sha256.json", manifest)
    except (FileExistsError, OSError, RuntimeError, ValueError):
        pass


def _publish_basin(
    *,
    root: Path,
    basin_index: int,
    basin_id: str,
    frozen: common.base.FrozenInputs,
    training: common.TrainingForcing,
    initial_state: np.ndarray,
    trajectory: np.ndarray,
    raw_scale: np.ndarray,
    scale: np.ndarray,
    floor_hit: np.ndarray,
    state_names: tuple[str, ...],
    state_units: tuple[str, ...],
    trajectory_seconds: float,
    admission: Mapping[str, Any],
) -> dict[str, Any]:
    final_root = root / f"basin_{basin_id}"
    pending_root = root / f".basin_{basin_id}.pending.{os.getpid()}"
    if final_root.exists() or final_root.is_symlink() or pending_root.exists() or pending_root.is_symlink():
        raise FileExistsError(f"state-scale basin output already exists: {basin_id}")
    pending_root.mkdir(exist_ok=False)
    arrays = {
        "dates_ns": np.asarray(training.dates_ns, dtype="<i8"),
        "initial_state": np.asarray(initial_state, dtype="<f8"),
        "deterministic_training_trajectory": np.asarray(trajectory, dtype="<f8"),
        "raw_state_scale": np.asarray(raw_scale, dtype="<f8"),
        "state_scale": np.asarray(scale, dtype="<f8"),
        "floor_hit": np.asarray(floor_hit, dtype=np.bool_),
        "parameter_values": np.asarray(frozen.parameter_values[basin_index], dtype="<f8"),
    }
    common.base.atomic_write_bytes_exclusive(
        pending_root / "state_scale_arrays.npz",
        common.base.deterministic_npz_bytes(arrays),
    )
    parameter_record = common.parameter_row_record(frozen, basin_id)
    identity = {
        "schema_version": "tukf09_455_state_scale_identity_v1",
        "experiment_id": common.EXPERIMENT_ID,
        "stage_id": common.STAGE_ID,
        "status": "FORMAL_TRAINING_STATE_SCALE_UNIT_COMPLETE",
        "basin_index": basin_index,
        "basin_id": basin_id,
        "state_dimension": int(trajectory.shape[1]),
        "state_order": list(state_names),
        "state_units": list(state_units),
        "training_period": {
            "start_date": common.EXPECTED_TRAINING_START,
            "end_date": common.EXPECTED_TRAINING_END,
            "day_count": common.EXPECTED_TRAINING_DAYS,
            "scale_slice_python": "x[365:2557]",
            "scale_sample_count": common.EXPECTED_SCALE_SAMPLES,
        },
        "raw_training_forcing": {
            "path": training.raw_relative_path,
            **dict(training.raw_record),
        },
        "training_semantic_arrays": {
            "dates_ns": dict(training.dates_semantic_record),
            "forcing": dict(training.forcing_semantic_record),
        },
        "parameter_row": parameter_record,
        "parameter_snapshot": common.base.load_science_contract()["lineage"]["input_seals"][
            "parameters_only"
        ],
        "scientific_contract": common.base.file_record(common.base.SCIENCE_CONTRACT),
        "stage_authorization": {
            "path": common.AUTHORIZATION.relative_to(ROOT).as_posix(),
            **common.base.file_record(common.AUTHORIZATION),
        },
        "stage_admission": {
            "path": common.ADMISSION.relative_to(ROOT).as_posix(),
            **common.base.file_record(common.ADMISSION),
        },
        "generator_files": {
            relative: dict(admission["implementation_files"][relative])
            for relative in (
                "hpc/tukf09_455_state_scale_generation_common_v1.py",
                "hpc/run_tukf09_455_state_scale_generation_v1.py",
            )
        },
        "model_policy": {
            "deterministic_open_loop": True,
            "physical_projection_after_each_day": True,
            "unscented_sigma_points": 0,
            "covariance_propagations": 0,
            "artificial_process_noise_injections": 0,
            "discharge_observation_updates": 0,
        },
        "validation_array_reads": 0,
        "evaluation_array_reads": 0,
        "discharge_observation_array_reads": 0,
        "local_noise_optimization_updates": 0,
        "scientific_performance_result": False,
    }
    common.base.atomic_write_json_exclusive(pending_root / "identity.json", identity)
    summary = {
        "schema_version": "tukf09_455_state_scale_summary_v1",
        "experiment_id": common.EXPERIMENT_ID,
        "stage_id": common.STAGE_ID,
        "status": "FORMAL_TRAINING_STATE_SCALE_UNIT_COMPLETE",
        "basin_index": basin_index,
        "basin_id": basin_id,
        "state_dimension": int(trajectory.shape[1]),
        "trajectory_shape": list(trajectory.shape),
        "trajectory_model_steps": int(trajectory.shape[0]),
        "scale_sample_count": common.EXPECTED_SCALE_SAMPLES,
        "raw_state_scale": raw_scale.tolist(),
        "state_scale": scale.tolist(),
        "floor_hit": floor_hit.astype(bool).tolist(),
        "floor_hit_count": int(np.count_nonzero(floor_hit)),
        "trajectory_seconds": float(trajectory_seconds),
        "validation_array_reads": 0,
        "evaluation_array_reads": 0,
        "discharge_observation_array_reads": 0,
        "local_noise_optimization_updates": 0,
        "scientific_performance_result": False,
    }
    common.base.atomic_write_json_exclusive(pending_root / "summary.json", summary)
    manifest = common.build_tree_manifest(
        pending_root,
        schema_version="tukf09_455_state_scale_unit_manifest_v1",
        status="FORMAL_TRAINING_STATE_SCALE_UNIT_SEALED",
    )
    common.base.atomic_write_json_exclusive(
        pending_root / "manifest.final.sha256.json", manifest
    )
    pending_root.replace(final_root)
    return {
        "basin_index": basin_index,
        "basin_id": basin_id,
        "state_dimension": int(trajectory.shape[1]),
        "floor_hit_count": int(np.count_nonzero(floor_hit)),
        "trajectory_model_steps": int(trajectory.shape[0]),
        "trajectory_seconds": float(trajectory_seconds),
        "unit_manifest": {
            "path": f"basin_{basin_id}/manifest.final.sha256.json",
            **common.base.file_record(final_root / "manifest.final.sha256.json"),
        },
    }


def run_formal_state_scale_generation() -> dict[str, Any]:
    authorization = common.load_authorization()
    admission = common.load_implementation_admission()
    threads = common.configure_single_thread_execution()
    runtime = common.verify_runtime(authorization)
    if set(threads.values()) != {1}:
        raise RuntimeError("state-scale execution is not single-threaded")
    limits = authorization["formal_scale_budget"]
    output_root = common.ensure_stage_output_path(common.SCALE_ROOT, common.SCALE_ROOT)
    if output_root.exists() or output_root.is_symlink():
        raise FileExistsError(f"formal state-scale output already exists: {output_root}")
    output_root.mkdir(parents=True, exist_ok=False)
    common.base.atomic_write_json_exclusive(
        output_root / "started.json",
        {
            "schema_version": "tukf09_455_state_scale_generation_started_v1",
            "experiment_id": common.EXPERIMENT_ID,
            "stage_id": common.STAGE_ID,
            "status": "FORMAL_STATE_SCALE_GENERATION_RUNNING_LATER_STAGES_HOLD",
            "started_at_utc": _utc_now(),
            "process_id": os.getpid(),
            "runtime_environment": runtime,
            "validation_array_reads": 0,
            "evaluation_array_reads": 0,
            "discharge_observation_array_reads": 0,
            "local_noise_optimization_updates": 0,
        },
    )

    process = psutil.Process(os.getpid())
    started = time.perf_counter()
    resource_stages: list[dict[str, Any]] = []
    completed_basins: list[str] = []
    try:
        parent_context, frozen = common.load_parent_context_and_frozen_inputs()
        resource_stages.append(
            _resource_check(
                started=started,
                process=process,
                limits=limits,
                stage="input_identity_checks",
            )
        )
        registry_units: list[dict[str, Any]] = []
        total_model_steps = 0
        total_floor_hits = 0
        dimension_counts: dict[str, int] = {}
        for basin_index, basin_id in enumerate(frozen.basin_ids):
            basin_started = time.perf_counter()
            training = common.load_training_forcing(parent_context, basin_id)
            parameter_row = frozen.parameter_row(basin_id)
            context = common.build_open_loop_context(
                basin_id, parameter_row, parent_context.contract
            )
            if context.dimension != frozen.dimension_by_basin[basin_id]:
                raise RuntimeError(f"state dimension changed for {basin_id}")
            trajectory_started = time.perf_counter()
            initial_state, trajectory = common.deterministic_training_trajectory(
                context, training.forcing
            )
            raw_scale, scale, floor_hit, names, units = common.compute_state_scale_artifacts(
                trajectory
            )
            trajectory_seconds = time.perf_counter() - trajectory_started
            unit = _publish_basin(
                root=output_root,
                basin_index=basin_index,
                basin_id=basin_id,
                frozen=frozen,
                training=training,
                initial_state=initial_state,
                trajectory=trajectory,
                raw_scale=raw_scale,
                scale=scale,
                floor_hit=floor_hit,
                state_names=names,
                state_units=units,
                trajectory_seconds=trajectory_seconds,
                admission=admission,
            )
            unit["basin_total_seconds"] = time.perf_counter() - basin_started
            registry_units.append(unit)
            completed_basins.append(basin_id)
            total_model_steps += int(trajectory.shape[0])
            total_floor_hits += int(np.count_nonzero(floor_hit))
            key = str(context.dimension)
            dimension_counts[key] = dimension_counts.get(key, 0) + 1
            stage = _resource_check(
                started=started,
                process=process,
                limits=limits,
                stage=f"basin_{basin_index + 1:03d}_of_455_{basin_id}",
            )
            resource_stages.append(stage)
            if common.directory_file_bytes(output_root) > int(
                limits["maximum_stage_output_bytes"]
            ):
                raise RuntimeError("formal state-scale output exceeded its byte cap")
            if (basin_index + 1) % 25 == 0 or basin_index + 1 == len(frozen.basin_ids):
                print(
                    json.dumps(
                        {
                            "progress": basin_index + 1,
                            "total": len(frozen.basin_ids),
                            "basin_id": basin_id,
                            "elapsed_seconds": stage["elapsed_seconds"],
                            "peak_process_rss_bytes": stage["peak_process_rss_bytes"],
                        },
                        sort_keys=True,
                    ),
                    flush=True,
                )
            del training, context, initial_state, trajectory, raw_scale, scale, floor_hit
            if (basin_index + 1) % 25 == 0:
                gc.collect()

        expected_counts = {
            str(key): int(value)
            for key, value in common.base.load_science_contract()["population"][
                "state_dimension_counts"
            ].items()
        }
        if (
            completed_basins != list(frozen.basin_ids)
            or len(registry_units) != int(limits["basin_count"])
            or total_model_steps != int(limits["total_basin_day_model_steps"])
            or dimension_counts != expected_counts
        ):
            raise RuntimeError("formal state-scale population or budget count changed")
        registry = {
            "schema_version": "tukf09_455_state_scale_registry_v1",
            "experiment_id": common.EXPERIMENT_ID,
            "stage_id": common.STAGE_ID,
            "status": "FORMAL_455_BASIN_TRAINING_STATE_SCALE_LIBRARY_COMPLETE",
            "basin_count": len(registry_units),
            "basin_order_newline_utf8_sha256": _ordered_newline_sha256(completed_basins),
            "state_dimension_counts": dimension_counts,
            "total_trajectory_model_steps": total_model_steps,
            "total_floor_hit_count": total_floor_hits,
            "validation_array_reads": 0,
            "evaluation_array_reads": 0,
            "discharge_observation_array_reads": 0,
            "local_noise_optimization_updates": 0,
            "units": registry_units,
        }
        common.base.atomic_write_json_exclusive(output_root / "scale_registry.json", registry)
        final_resources = _resource_check(
            started=started,
            process=process,
            limits=limits,
            stage="formal_scale_generation_complete",
        )
        summary = {
            "schema_version": "tukf09_455_state_scale_generation_summary_v1",
            "experiment_id": common.EXPERIMENT_ID,
            "stage_id": common.STAGE_ID,
            "status": "FORMAL_455_BASIN_TRAINING_STATE_SCALES_GENERATED_LATER_STAGES_HOLD",
            "completed_at_utc": _utc_now(),
            "runtime_environment": runtime,
            "thread_counts": threads,
            "basin_count": len(registry_units),
            "trajectory_count": len(registry_units),
            "total_trajectory_model_steps": total_model_steps,
            "state_dimension_counts": dimension_counts,
            "total_floor_hit_count": total_floor_hits,
            "total_wall_seconds": final_resources["elapsed_seconds"],
            "peak_process_rss_bytes": final_resources["peak_process_rss_bytes"],
            "resource_limits": dict(limits),
            "resource_stages": resource_stages,
            "output_bytes_before_summary_and_manifest": common.directory_file_bytes(output_root),
            "validation_array_reads": 0,
            "evaluation_array_reads": 0,
            "discharge_observation_array_reads": 0,
            "local_noise_optimization_updates": 0,
            "formal_local_selection_count": 0,
            "formal_transfer_vector_count": 0,
            "scientific_performance_result": False,
            "later_stages_authorized": False,
        }
        common.base.atomic_write_json_exclusive(output_root / "run_summary.json", summary)
        manifest = common.build_tree_manifest(
            output_root,
            schema_version="tukf09_455_state_scale_generation_manifest_v1",
            status="FORMAL_455_BASIN_TRAINING_STATE_SCALES_SEALED_LATER_STAGES_HOLD",
        )
        manifest_bytes = common.base.canonical_json_bytes(manifest)
        if common.directory_file_bytes(output_root) + len(manifest_bytes) > int(
            limits["maximum_stage_output_bytes"]
        ):
            raise RuntimeError("formal state-scale sealed output would exceed its byte cap")
        common.base.atomic_write_bytes_exclusive(
            output_root / "manifest.final.sha256.json", manifest_bytes
        )
        return summary
    except BaseException as exc:
        _write_failure(
            output_root,
            exc,
            completed_basins=completed_basins,
            resource_stages=resource_stages,
        )
        raise


def _ordered_newline_sha256(values: list[str]) -> str:
    from hashlib import sha256

    return sha256("".join(f"{value}\n" for value in values).encode("utf-8")).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--mode",
        required=True,
        choices=("formal-state-scales", "formal-local-noise-selection"),
    )
    args = parser.parse_args()
    if args.mode == "formal-local-noise-selection":
        common.load_authorization()
        raise PermissionError("formal local noise optimization remains unauthorized")
    summary = run_formal_state_scale_generation()
    print(json.dumps(summary, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
