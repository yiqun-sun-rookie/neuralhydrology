"""Shared, contract-gated utilities for the scaled process-noise experiment.

The module exposes training/validation computations and metadata-only donor
construction.  It deliberately contains no evaluation-period loader.  Formal
scientific execution is denied by the current execution authorization; only
tests, donor precheck, and the bounded technical probe may call its I/O helpers.
"""
from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from io import BytesIO
import json
import math
import os
from pathlib import Path
import sys
from typing import Any, Mapping, Sequence
import uuid
import zipfile

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
for _extra in (str(ROOT), str(ROOT / "src")):
    if _extra not in sys.path:
        sys.path.insert(0, _extra)

from scripts import tukf09_455_training_common as revision_training_common  # noqa: E402
from scripts import tukf09_training_common as parent_training_common  # noqa: E402
from scripts.differentiable_ukf_hbvlite import run_hbvlite_corrected_ukf  # noqa: E402
from scripts.run_tukf09_filter_training import (  # noqa: E402
    FilterContext,
    PeriodData,
    build_causal_filter_context,
    choose_checkpoint,
    configure_single_thread_execution,
    equal_weight_multilead_mse,
    multilead_torch,
    normalize_period_data,
)
from scripts.tukf09_confirmatory_common import (  # noqa: E402
    PARAMETER_NAMES,
    routed_state_dimension,
)


EXPERIMENT_ID = "TUKF09_455_SCALED_NOISE_LOCAL_TRANSFER_V1"
PROBE_ID = "TUKF09_455_SCALED_NOISE_LOCAL_TRANSFER_TECHNICAL_PROBE_V1"
SCIENCE_CONTRACT = ROOT / "hpc" / "tukf09_455_scaled_noise_local_transfer_contract_v1.json"
HUMAN_CONTRACT = (
    ROOT
    / "docs"
    / "plans"
    / "2026-09-21-tukf09-455-scaled-noise-local-transfer-scientific-contract-v1.md"
)
EXECUTION_AUTHORIZATION = (
    ROOT / "hpc" / "tukf09_455_scaled_noise_local_transfer_execution_authorization_v1.json"
)
IMPLEMENTATION_ADMISSION = (
    ROOT / "hpc" / "tukf09_455_scaled_noise_local_transfer_implementation_admission_v1.json"
)
RESULTS_ROOT = ROOT / "results" / "tukf09_455_scaled_noise_local_transfer_v1"
PARENT_CONFIG = (
    ROOT / "configs" / "tukf09_455_basin_zero_validation_target_variance_revision_v1.json"
)
PARENT_PREFLIGHT_ROOT = (
    ROOT
    / "artifacts"
    / "tukf09_455_basin_zero_validation_target_variance_revision_v1"
    / "preflight"
)
PARENT_PREFLIGHT_FINAL = PARENT_PREFLIGHT_ROOT / "independent" / "manifest.final.sha256.json"
PARENT_AUTHORIZATION = (
    ROOT
    / "artifacts"
    / "tukf09_455_basin_zero_validation_target_variance_revision_v1"
    / "authorizations"
    / "all_scope_authorization.json"
)
PARENT_RESULTS_ROOT = (
    ROOT / "results" / "tukf09_455_basin_zero_validation_target_variance_revision_v1"
)
PARENT_FILTER_REGISTRY = PARENT_RESULTS_ROOT / "selection" / "filter_registry.json"
LEADS = (1, 2, 3)
PHYSICAL_STATE_NAMES = (
    "snow",
    "liquid_snow_or_meltwater",
    "soil_water",
    "upper_zone_storage",
    "lower_zone_storage",
)


def _reject_json_constant(token: str) -> None:
    raise ValueError(f"non-finite JSON constant is forbidden: {token}")


def _no_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def read_json_strict(path: str | Path) -> dict[str, Any]:
    value = json.loads(
        Path(path).read_text(encoding="utf-8"),
        parse_constant=_reject_json_constant,
        object_pairs_hook=_no_duplicate_keys,
    )
    if not isinstance(value, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return value


def canonical_json_bytes(value: Any) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")


def sha256_file(path: str | Path, *, chunk_size: int = 1024 * 1024) -> str:
    digest = sha256()
    with Path(path).open("rb") as handle:
        while True:
            block = handle.read(chunk_size)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def file_record(path: str | Path) -> dict[str, Any]:
    source = require_regular_unlinked_file(path, label="recorded file")
    return {"sha256": sha256_file(source), "size_bytes": source.stat().st_size}


def require_regular_unlinked_file(path: str | Path, *, label: str) -> Path:
    source = Path(path)
    if not source.is_file() or source.is_symlink():
        raise RuntimeError(f"{label} must be one regular unlinked file: {source}")
    return source


def ensure_within(path: str | Path, parent: str | Path) -> Path:
    candidate = Path(path).resolve()
    root = Path(parent).resolve()
    try:
        candidate.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"path escapes its allowed root: {candidate}") from exc
    return candidate


def _require_no_links_between(path: Path, stop: Path) -> None:
    resolved_stop = stop.resolve()
    current = path
    while True:
        if current.exists() and current.is_symlink():
            raise RuntimeError(f"linked path component is forbidden: {current}")
        if current.resolve() == resolved_stop:
            break
        if current.parent == current:
            raise ValueError(f"path does not descend from stop root: {path}")
        current = current.parent


def ensure_allowed_results_path(path: str | Path, allowed_subtree: str) -> Path:
    target = ensure_within(path, RESULTS_ROOT)
    allowed = (RESULTS_ROOT / allowed_subtree).resolve()
    try:
        target.relative_to(allowed)
    except ValueError as exc:
        raise PermissionError(f"write lies outside authorized result subtree: {target}") from exc
    _require_no_links_between(target.parent, RESULTS_ROOT)
    return target


def atomic_write_bytes_exclusive(path: str | Path, content: bytes) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() or target.is_symlink():
        raise FileExistsError(f"refusing to overwrite existing output: {target}")
    pending = target.with_name(f".{target.name}.pending.{os.getpid()}.{uuid.uuid4().hex}")
    try:
        with pending.open("xb") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        pending.replace(target)
    finally:
        if pending.exists():
            pending.unlink()
    return target


def atomic_write_json_exclusive(path: str | Path, value: Mapping[str, Any]) -> Path:
    return atomic_write_bytes_exclusive(path, canonical_json_bytes(dict(value)))


def deterministic_npz_bytes(arrays: Mapping[str, np.ndarray]) -> bytes:
    """Serialize NumPy arrays with fixed member order and ZIP timestamps."""

    output = BytesIO()
    with zipfile.ZipFile(output, mode="w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name in sorted(arrays):
            member = BytesIO()
            np.lib.format.write_array(
                member,
                np.ascontiguousarray(arrays[name]),
                allow_pickle=False,
            )
            info = zipfile.ZipInfo(f"{name}.npy", date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o600 << 16
            archive.writestr(info, member.getvalue())
    return output.getvalue()


def verify_file_binding(path: str | Path, record: Mapping[str, Any], *, label: str) -> Path:
    source = require_regular_unlinked_file(path, label=label)
    if sha256_file(source) != record.get("sha256"):
        raise RuntimeError(f"{label} SHA-256 changed: {source}")
    if "size_bytes" in record and source.stat().st_size != int(record["size_bytes"]):
        raise RuntimeError(f"{label} size changed: {source}")
    return source


def load_science_contract() -> dict[str, Any]:
    contract = read_json_strict(SCIENCE_CONTRACT)
    if (
        contract.get("schema_version")
        != "tukf09_455_scaled_noise_local_transfer_contract_v1"
        or contract.get("experiment_id") != EXPERIMENT_ID
        or contract.get("contract_status") != "SCIENTIFIC_CONTRACT_FROZEN_EXECUTION_HOLD"
    ):
        raise RuntimeError("scaled-noise scientific contract identity or status changed")
    return contract


def load_execution_authorization() -> dict[str, Any]:
    authorization = read_json_strict(EXECUTION_AUTHORIZATION)
    contract = load_science_contract()
    if (
        authorization.get("schema_version")
        != "tukf09_455_scaled_noise_local_transfer_execution_authorization_v1"
        or authorization.get("experiment_id") != EXPERIMENT_ID
        or authorization.get("status")
        != "IMPLEMENTATION_TESTS_DONOR_PRECHECK_AND_BOUNDED_TECHNICAL_PROBE_AUTHORIZED_FORMAL_EXPERIMENT_HOLD"
    ):
        raise PermissionError("execution authorization identity or status changed")
    verify_file_binding(
        SCIENCE_CONTRACT,
        authorization["scientific_contract"],
        label="scientific contract",
    )
    verify_file_binding(
        HUMAN_CONTRACT,
        authorization["human_contract"],
        label="human scientific contract",
    )
    scope = authorization.get("authorization_scope", {})
    required_true = (
        "implementation",
        "automated_tests",
        "metadata_only_coordinate_donor_precheck",
        "bounded_technical_probe",
        "resource_measurement_and_freeze",
        "new_results_root_creation_for_control_and_technical_probe_only",
    )
    required_false = (
        "formal_state_scale_generation",
        "formal_local_training_or_checkpoint_selection",
        "formal_local_selection_sealing",
        "formal_transfer_vector_build",
        "evaluation_array_access",
        "evaluation_prediction_generation",
        "evaluation_metric_computation",
        "bootstrap_computation_on_scientific_results",
        "independent_formal_result_verification",
        "remote_or_hpc_submission",
    )
    if any(scope.get(name) is not True for name in required_true) or any(
        scope.get(name) is not False for name in required_false
    ):
        raise PermissionError("execution authorization scope widened or became incomplete")
    if contract["experiment_registry"]["future_results_root"] != RESULTS_ROOT.relative_to(ROOT).as_posix():
        raise RuntimeError("scientific contract result root changed")
    return authorization


def require_formal_execution_denied() -> None:
    scope = load_execution_authorization()["authorization_scope"]
    forbidden = (
        "formal_state_scale_generation",
        "formal_local_training_or_checkpoint_selection",
        "formal_local_selection_sealing",
        "formal_transfer_vector_build",
        "evaluation_array_access",
        "evaluation_prediction_generation",
        "evaluation_metric_computation",
    )
    if any(bool(scope[name]) for name in forbidden):
        raise RuntimeError("this implementation version expects formal execution to remain closed")


@dataclass(frozen=True)
class FrozenInputs:
    basin_ids: tuple[str, ...]
    parameter_names: tuple[str, ...]
    parameter_values: np.ndarray
    dimension_by_basin: Mapping[str, int]

    def parameter_row(self, basin_id: str) -> dict[str, float]:
        try:
            index = self.basin_ids.index(str(basin_id))
        except ValueError as exc:
            raise KeyError(f"basin is outside the frozen population: {basin_id}") from exc
        return {
            name: float(self.parameter_values[index, column])
            for column, name in enumerate(self.parameter_names)
        }


def _ordered_newline_sha256(values: Sequence[str]) -> str:
    return sha256("".join(f"{value}\n" for value in values).encode("utf-8")).hexdigest()


def _ordered_compact_sha256(values: Sequence[str]) -> str:
    raw = json.dumps(list(values), ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return sha256(raw).hexdigest()


def _dimension_mapping_sha256(mapping: Mapping[str, int]) -> str:
    raw = json.dumps(
        {str(key): int(value) for key, value in mapping.items()},
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return sha256(raw).hexdigest()


def load_frozen_inputs() -> FrozenInputs:
    contract = load_science_contract()
    seals = contract["lineage"]["input_seals"]
    population_path = ROOT / seals["population_registry"]["path"]
    parameters_path = ROOT / seals["parameters_only"]["path"]
    verify_file_binding(population_path, seals["population_registry"], label="population registry")
    verify_file_binding(parameters_path, seals["parameters_only"], label="parameter snapshot")
    population = read_json_strict(population_path)
    basin_ids = tuple(str(value) for value in population.get("eligible", ()))
    expected_population = contract["population"]
    if (
        len(basin_ids) != int(expected_population["basin_count"])
        or len(set(basin_ids)) != len(basin_ids)
        or expected_population["excluded_basin_id"] in basin_ids
        or _ordered_newline_sha256(basin_ids)
        != expected_population["basin_order_newline_utf8_sha256"]
        or _ordered_compact_sha256(basin_ids)
        != expected_population["basin_order_compact_json_sha256"]
    ):
        raise RuntimeError("frozen population identity changed")
    with np.load(parameters_path, allow_pickle=False) as archive:
        if set(archive.files) != {"basin_ids", "parameter_names", "values"}:
            raise RuntimeError("parameter snapshot members changed")
        parameter_basins = tuple(str(value) for value in archive["basin_ids"].tolist())
        parameter_names = tuple(str(value) for value in archive["parameter_names"].tolist())
        parameter_values = np.asarray(archive["values"], dtype=np.float64).copy()
    if (
        parameter_basins != basin_ids
        or parameter_names != tuple(PARAMETER_NAMES)
        or parameter_values.shape != (455, 13)
        or not np.isfinite(parameter_values).all()
    ):
        raise RuntimeError("frozen parameter population, order, or shape changed")
    dimension_by_basin: dict[str, int] = {}
    for basin_id, row in zip(basin_ids, parameter_values):
        mapping = {name: float(value) for name, value in zip(parameter_names, row)}
        dimension_by_basin[basin_id] = int(routed_state_dimension(mapping))
    counts: dict[str, int] = {}
    for dimension in dimension_by_basin.values():
        counts[str(dimension)] = counts.get(str(dimension), 0) + 1
    if counts != {str(key): int(value) for key, value in expected_population["state_dimension_counts"].items()}:
        raise RuntimeError("state-dimension counts changed")
    if (
        _dimension_mapping_sha256(dimension_by_basin)
        != expected_population["state_dimension_mapping_compact_sorted_json_sha256"]
    ):
        raise RuntimeError("per-basin state-dimension mapping changed")
    parameter_values.setflags(write=False)
    return FrozenInputs(
        basin_ids=basin_ids,
        parameter_names=parameter_names,
        parameter_values=parameter_values,
        dimension_by_basin=dimension_by_basin,
    )


def load_fixed_observation_noise(frozen: FrozenInputs) -> dict[str, float]:
    contract = load_science_contract()
    record = contract["lineage"]["completed_parent_evidence"]["filter_registry"]
    verify_file_binding(ROOT / record["path"], record, label="parent filter registry")
    registry = read_json_strict(ROOT / record["path"])
    units = registry.get("units")
    if (
        registry.get("basin_count") != 455
        or registry.get("evaluation_access_count") != 0
        or not isinstance(units, list)
        or len(units) != 455
    ):
        raise RuntimeError("parent filter registry identity or access ledger changed")
    ordered = tuple(str(unit.get("basin_id")) for unit in units)
    if ordered != frozen.basin_ids:
        raise RuntimeError("parent filter registry basin order changed")
    result: dict[str, float] = {}
    for unit in units:
        basin_id = str(unit["basin_id"])
        value = float(unit["selected_r_b"])
        dimension = frozen.dimension_by_basin[basin_id]
        process = np.asarray(unit["selected_process_diagonal"], dtype=np.float64)
        if (
            not math.isfinite(value)
            or value <= 0.0
            or process.shape != (dimension,)
            or not np.isfinite(process).all()
            or np.any(process <= 0.0)
        ):
            raise RuntimeError(f"parent selected noise is invalid for {basin_id}")
        result[basin_id] = value
    return result


def build_donor_registry(frozen: FrozenInputs) -> dict[str, Any]:
    contract = load_science_contract()
    expected = {
        int(key): int(value)
        for key, value in contract["leave_one_basin_out_transfer"][
            "expected_eligible_basin_count_by_routing_coordinate_zero_based"
        ].items()
    }
    receivers: dict[str, Any] = {}
    minimum = len(frozen.basin_ids)
    for receiver in frozen.basin_ids:
        dimension = frozen.dimension_by_basin[receiver]
        coordinates: list[dict[str, Any]] = []
        for state_index in range(dimension):
            if state_index < 5:
                donors = [value for value in frozen.basin_ids if value != receiver]
                kind = "physical"
                semantic_index = state_index
                semantic_name = PHYSICAL_STATE_NAMES[state_index]
            else:
                lag = state_index - 5
                eligible = [
                    value
                    for value in frozen.basin_ids
                    if frozen.dimension_by_basin[value] > state_index
                ]
                if len(eligible) != expected[lag]:
                    raise RuntimeError(f"routing-coordinate {lag} eligible count changed")
                donors = [value for value in eligible if value != receiver]
                kind = "routing"
                semantic_index = lag
                semantic_name = f"unrouted_runoff_lag_{lag}_days"
            if receiver in donors or not donors:
                raise RuntimeError(f"invalid donor set for {receiver} state {state_index}")
            minimum = min(minimum, len(donors))
            coordinates.append(
                {
                    "state_index": state_index,
                    "kind": kind,
                    "semantic_index": semantic_index,
                    "semantic_name": semantic_name,
                    "donor_count": len(donors),
                    "donors": donors,
                }
            )
        receivers[receiver] = {
            "state_dimension": dimension,
            "coordinate_count": len(coordinates),
            "coordinates": coordinates,
        }
    required_minimum = int(
        contract["leave_one_basin_out_transfer"][
            "minimum_expected_donor_count_for_any_present_coordinate"
        ]
    )
    if minimum != required_minimum:
        raise RuntimeError(f"minimum donor count {minimum} differs from frozen {required_minimum}")
    return {
        "schema_version": "tukf09_455_scaled_noise_donor_precheck_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "METADATA_ONLY_DONOR_PRECHECK_PASS",
        "receiver_count": len(receivers),
        "minimum_donor_count": minimum,
        "evaluation_access_count": 0,
        "model_execution_count": 0,
        "receivers": receivers,
    }


def state_floor_vector(dimension: int) -> tuple[np.ndarray, tuple[str, ...]]:
    if int(dimension) < 6:
        raise ValueError("state dimension must include five physical states and routing")
    values = np.full(int(dimension), 0.01, dtype=np.float64)
    units = tuple(["millimetre"] * 5 + ["millimetre_per_day"] * (int(dimension) - 5))
    values.setflags(write=False)
    return values, units


def deterministic_training_trajectory(
    context: FilterContext,
    forcing: torch.Tensor,
) -> tuple[np.ndarray, np.ndarray]:
    values = torch.as_tensor(forcing, dtype=torch.float64, device="cpu")
    if values.ndim == 2:
        values = values.unsqueeze(1)
    if values.ndim != 3 or values.shape[1:] != (1, 3):
        raise ValueError("training forcing must have shape [days,1,3]")
    state = context.initial_state.detach().clone()
    initial = state[0].cpu().numpy().astype(np.float64, copy=True)
    states = np.empty((values.shape[0], context.dimension), dtype=np.float64)
    with torch.no_grad():
        for day in range(values.shape[0]):
            state = context.plain_model.f(state, values[day, 0, :])
            state = context.project_mean(state)
            if state.shape != (1, context.dimension) or not bool(torch.isfinite(state).all()):
                raise FloatingPointError(f"deterministic trajectory failed at day {day}")
            states[day] = state[0].cpu().numpy()
    if not np.isfinite(states).all():
        raise FloatingPointError("deterministic training trajectory is non-finite")
    return initial, states


def compute_state_scale(trajectory: np.ndarray) -> tuple[np.ndarray, np.ndarray, tuple[str, ...]]:
    values = np.asarray(trajectory, dtype=np.float64)
    if values.ndim != 2 or values.shape[0] != 2557 or values.shape[1] < 6:
        raise ValueError("formal training trajectory must have shape [2557,state_dimension]")
    selected = values[365:2557]
    if selected.shape[0] != 2192 or not np.isfinite(selected).all():
        raise RuntimeError("state-scale slice differs from the frozen 2192 values")
    floors, units = state_floor_vector(values.shape[1])
    raw = np.sqrt(np.mean(np.square(selected), axis=0, dtype=np.float64))
    if not np.isfinite(raw).all():
        raise FloatingPointError("raw state scale is non-finite")
    scale = np.maximum(raw, floors)
    floor_hit = raw <= floors
    return (
        np.ascontiguousarray(scale, dtype=np.float64),
        np.ascontiguousarray(floor_hit, dtype=np.bool_),
        units,
    )


def ratio_bounds(contract: Mapping[str, Any] | None = None) -> tuple[float, float]:
    source = load_science_contract() if contract is None else contract
    local = source["local_scaled_process_noise"]
    lower, upper = float(local["common_ratio_lower"]), float(local["common_ratio_upper"])
    if lower != 1e-4 or upper != 1.0:
        raise RuntimeError("scaled process-noise ratio bounds changed")
    return lower, upper


def log_process_variance_bounds(
    scale: np.ndarray | torch.Tensor,
    contract: Mapping[str, Any] | None = None,
) -> tuple[torch.Tensor, torch.Tensor]:
    values = torch.as_tensor(scale, dtype=torch.float64, device="cpu")
    if values.ndim != 1 or not bool(torch.isfinite(values).all()) or bool(torch.any(values <= 0)):
        raise ValueError("state scale must be one positive finite vector")
    lower, upper = ratio_bounds(contract)
    return 2.0 * torch.log(values) + 2.0 * math.log(lower), 2.0 * torch.log(values) + 2.0 * math.log(upper)


def ratio_to_process_variance(rho: np.ndarray, scale: np.ndarray) -> np.ndarray:
    ratios = np.asarray(rho, dtype=np.float64)
    scales = np.asarray(scale, dtype=np.float64)
    if ratios.shape != scales.shape or ratios.ndim != 1:
        raise ValueError("rho and scale must be aligned one-dimensional vectors")
    lower, upper = ratio_bounds()
    if (
        not np.isfinite(ratios).all()
        or not np.isfinite(scales).all()
        or np.any(scales <= 0.0)
        or np.any(ratios < lower)
        or np.any(ratios > upper)
    ):
        raise ValueError("rho or scale is outside the frozen positive range")
    result = np.square(ratios * scales)
    if not np.isfinite(result).all() or np.any(result <= 0.0):
        raise FloatingPointError("process variance conversion failed")
    return np.ascontiguousarray(result, dtype=np.float64)


def process_variance_to_ratio(process_variance: np.ndarray, scale: np.ndarray) -> np.ndarray:
    q = np.asarray(process_variance, dtype=np.float64)
    scales = np.asarray(scale, dtype=np.float64)
    if q.shape != scales.shape or q.ndim != 1:
        raise ValueError("process variance and scale must align")
    if not np.isfinite(q).all() or np.any(q <= 0.0) or not np.isfinite(scales).all() or np.any(scales <= 0.0):
        raise ValueError("process variance and scale must be finite and positive")
    rho = np.sqrt(q) / scales
    lower, upper = ratio_bounds()
    tolerance = float(load_science_contract()["local_scaled_process_noise"]["rho_q_round_trip_absolute_tolerance"])
    below = rho < lower
    above = rho > upper
    if np.any(rho[below] < lower - tolerance) or np.any(rho[above] > upper + tolerance):
        raise ValueError("restored rho lies outside the frozen range")
    rho = np.clip(rho, lower, upper)
    return np.ascontiguousarray(rho, dtype=np.float64)


def anchor_ratio_matrix(dimension: int, contract: Mapping[str, Any] | None = None) -> np.ndarray:
    source = load_science_contract() if contract is None else contract
    anchors = source["local_scaled_process_noise"]["anchors"]
    if len(anchors) != 8 or int(dimension) < 6:
        raise ValueError("eight anchors and at least one routing coordinate are required")
    rows = []
    for index, anchor in enumerate(anchors):
        if int(anchor["index"]) != index:
            raise RuntimeError("anchor order changed")
        rows.append(
            [float(anchor["physical_rho"])] * 5
            + [float(anchor["routing_rho"])] * (int(dimension) - 5)
        )
    result = np.asarray(rows, dtype=np.float64)
    if len({tuple(row) for row in result}) != 8:
        raise RuntimeError("scaled-noise anchors are not unique")
    lower, upper = ratio_bounds(source)
    if np.any(result < lower) or np.any(result > upper):
        raise RuntimeError("scaled-noise anchor lies outside the frozen range")
    return result


def anchor_theta_matrix(scale: np.ndarray, contract: Mapping[str, Any] | None = None) -> np.ndarray:
    scales = np.asarray(scale, dtype=np.float64)
    ratios = anchor_ratio_matrix(len(scales), contract)
    theta = 2.0 * np.log(scales[None, :]) + 2.0 * np.log(ratios)
    ratio_lower, ratio_upper = ratio_bounds(contract)
    lower = 2.0 * np.log(scales) + 2.0 * math.log(ratio_lower)
    upper = 2.0 * np.log(scales) + 2.0 * math.log(ratio_upper)
    if np.any(theta < lower[None, :]) or np.any(theta > upper[None, :]):
        raise RuntimeError("anchor natural-log variance lies outside frozen bounds")
    return np.ascontiguousarray(theta, dtype=np.float64)


def decode_process_theta(
    theta_log: torch.Tensor,
    scale: np.ndarray | torch.Tensor,
    contract: Mapping[str, Any] | None = None,
) -> torch.Tensor:
    theta = torch.as_tensor(theta_log)
    scales = torch.as_tensor(scale, dtype=torch.float64, device=theta.device)
    if theta.dtype != torch.float64 or theta.ndim != 1 or theta.shape != scales.shape:
        raise ValueError("theta must be a float64 state-dimension vector")
    if not bool(torch.isfinite(theta).all()):
        raise FloatingPointError("theta contains a non-finite value")
    lower, upper = log_process_variance_bounds(scales, contract)
    lower, upper = lower.to(theta.device), upper.to(theta.device)
    tolerance = float((load_science_contract() if contract is None else contract)["local_scaled_process_noise"]["rho_q_round_trip_absolute_tolerance"])
    if bool(torch.any(theta < lower - tolerance)) or bool(torch.any(theta > upper + tolerance)):
        raise ValueError("theta lies outside frozen scaled-noise bounds")
    bounded = torch.maximum(torch.minimum(theta, upper), lower)
    result = torch.exp(bounded)
    if not bool(torch.isfinite(result).all()) or bool(torch.any(result <= 0.0)):
        raise FloatingPointError("decoded process variance is non-finite or non-positive")
    return result


def run_scaled_filter(
    context: FilterContext,
    forcing: torch.Tensor,
    observations: torch.Tensor,
    theta_log: torch.Tensor,
    scale: np.ndarray | torch.Tensor,
    fixed_r_b: float,
    contract: Mapping[str, Any] | None = None,
) -> dict[str, torch.Tensor]:
    q = decode_process_theta(theta_log, scale, contract)
    r_b = torch.as_tensor(float(fixed_r_b), dtype=torch.float64, device="cpu")
    if not bool(torch.isfinite(r_b)) or float(r_b) <= 0.0:
        raise ValueError("fixed observation-noise multiplier must be positive and finite")
    result = run_hbvlite_corrected_ukf(
        context.adapter,
        forcing.to(dtype=torch.float64, device="cpu"),
        observations.to(dtype=torch.float64, device="cpu"),
        context.initial_state.clone(),
        context.initial_covariance.clone(),
        q,
        base_observation_variance=context.base_observation_variance,
        r_b=r_b,
        localization_multiplier=1.0,
        project_mean=context.project_mean,
    )
    for name in ("posterior_state", "prior_state", "prediction", "observation_variance"):
        if name not in result or not bool(torch.isfinite(result[name]).all()):
            raise FloatingPointError(f"scaled filter returned invalid {name} for {context.basin_id}")
    return result


def scaled_multilead_objective(
    context: FilterContext,
    forcing: torch.Tensor,
    observations: torch.Tensor,
    theta_log: torch.Tensor,
    scale: np.ndarray | torch.Tensor,
    fixed_r_b: float,
    parent_contract: Mapping[str, Any],
    period_name: str,
    *,
    grad: bool,
) -> torch.Tensor:
    manager = torch.enable_grad() if grad else torch.no_grad()
    with manager:
        filtered = run_scaled_filter(
            context,
            forcing,
            observations,
            theta_log,
            scale,
            fixed_r_b,
        )
        forecasts = multilead_torch(
            context.plain_model,
            filtered["posterior_state"][:, 0, :],
            forcing,
        )
        value, _ = equal_weight_multilead_mse(
            forecasts,
            observations,
            period_name=period_name,
            contract=parent_contract,
        )
    return value


@dataclass(frozen=True)
class LocalSearchHistory:
    theta_log: np.ndarray
    training_objective: np.ndarray
    validation_objective: np.ndarray
    selected_index: int
    training_queries: int
    validation_queries: int
    gradient_updates: int


def run_full_local_search(
    context: FilterContext,
    training: PeriodData,
    validation: PeriodData,
    scale: np.ndarray,
    fixed_r_b: float,
    parent_contract: Mapping[str, Any],
    science_contract: Mapping[str, Any] | None = None,
) -> LocalSearchHistory:
    """Execute the frozen full local search in memory.

    The current command-line authorization never calls this function.  It is
    implemented and unit-testable now so a later formal authorization can bind
    the exact source without changing the scientific algorithm.
    """

    contract = load_science_contract() if science_contract is None else science_contract
    settings = contract["local_scaled_process_noise"]["optimizer"]
    anchors = anchor_theta_matrix(scale, contract)
    starts = int(settings["start_count"])
    updates = int(settings["updates_per_start"])
    if starts != 8 or updates != 31 or anchors.shape != (8, context.dimension):
        raise RuntimeError("full local search budget or anchor shape changed")
    parameters = [
        torch.nn.Parameter(torch.tensor(row, dtype=torch.float64, device="cpu"))
        for row in anchors
    ]
    optimizers = [
        torch.optim.Adam(
            [theta],
            lr=float(settings["learning_rate"]),
            betas=tuple(float(value) for value in settings["betas"]),
            eps=float(settings["epsilon"]),
            weight_decay=float(settings["weight_decay"]),
            amsgrad=bool(settings["amsgrad"]),
        )
        for theta in parameters
    ]
    lower, upper = log_process_variance_bounds(scale, contract)
    theta_rows: list[np.ndarray] = []
    training_values: list[float] = []
    validation_values: list[float] = []
    training_queries = 0
    validation_queries = 0
    gradient_updates = 0
    for step in range(updates + 1):
        for start_index, (theta, optimizer) in enumerate(zip(parameters, optimizers)):
            optimizer.zero_grad(set_to_none=True)
            training_loss = scaled_multilead_objective(
                context,
                training.forcing,
                training.observations,
                theta,
                scale,
                fixed_r_b,
                parent_contract,
                "training",
                grad=True,
            )
            validation_loss = scaled_multilead_objective(
                context,
                validation.forcing,
                validation.observations,
                theta,
                scale,
                fixed_r_b,
                parent_contract,
                "validation",
                grad=False,
            )
            training_queries += 1
            validation_queries += 1
            theta_rows.append(theta.detach().cpu().numpy().astype(np.float64, copy=True))
            training_values.append(float(training_loss.detach()))
            validation_values.append(float(validation_loss.detach()))
            if step == updates:
                continue
            training_loss.backward()
            if theta.grad is None or not bool(torch.isfinite(theta.grad).all()):
                raise FloatingPointError(
                    f"non-finite gradient at start {start_index}, step {step}"
                )
            optimizer.step()
            with torch.no_grad():
                theta.clamp_(min=lower, max=upper)
            gradient_updates += 1
    theta_array = np.stack(theta_rows)
    training_array = np.asarray(training_values, dtype=np.float64)
    validation_array = np.asarray(validation_values, dtype=np.float64)
    if (
        theta_array.shape != (int(settings["checkpoints_per_basin"]), context.dimension)
        or training_queries != int(settings["checkpoints_per_basin"])
        or validation_queries != int(settings["checkpoints_per_basin"])
        or gradient_updates != int(settings["backpropagations_per_basin"])
        or not np.isfinite(theta_array).all()
        or not np.isfinite(training_array).all()
        or not np.isfinite(validation_array).all()
    ):
        raise RuntimeError("full local search did not consume the frozen budget")
    return LocalSearchHistory(
        theta_log=theta_array,
        training_objective=training_array,
        validation_objective=validation_array,
        selected_index=choose_checkpoint(theta_array, training_array, validation_array),
        training_queries=training_queries,
        validation_queries=validation_queries,
        gradient_updates=gradient_updates,
    )


def run_one_update_probe(
    context: FilterContext,
    training: PeriodData,
    validation: PeriodData,
    scale: np.ndarray,
    fixed_r_b: float,
    parent_contract: Mapping[str, Any],
    science_contract: Mapping[str, Any] | None = None,
) -> tuple[dict[str, Any], dict[str, np.ndarray]]:
    contract = load_science_contract() if science_contract is None else science_contract
    settings = contract["local_scaled_process_noise"]["optimizer"]
    anchors = anchor_theta_matrix(scale, contract)
    theta = torch.nn.Parameter(torch.tensor(anchors[0], dtype=torch.float64, device="cpu"))
    optimizer = torch.optim.Adam(
        [theta],
        lr=float(settings["learning_rate"]),
        betas=tuple(float(value) for value in settings["betas"]),
        eps=float(settings["epsilon"]),
        weight_decay=float(settings["weight_decay"]),
        amsgrad=bool(settings["amsgrad"]),
    )
    lower, upper = log_process_variance_bounds(scale, contract)
    optimizer.zero_grad(set_to_none=True)
    train_before = scaled_multilead_objective(
        context,
        training.forcing,
        training.observations,
        theta,
        scale,
        fixed_r_b,
        parent_contract,
        "training",
        grad=True,
    )
    validation_before = scaled_multilead_objective(
        context,
        validation.forcing,
        validation.observations,
        theta,
        scale,
        fixed_r_b,
        parent_contract,
        "validation",
        grad=False,
    )
    theta_before = theta.detach().cpu().numpy().astype(np.float64, copy=True)
    train_before.backward()
    if theta.grad is None or theta.grad.dtype != torch.float64 or not bool(torch.isfinite(theta.grad).all()):
        raise FloatingPointError("technical probe gradient is missing or non-finite")
    gradient = theta.grad.detach().cpu().numpy().astype(np.float64, copy=True)
    optimizer.step()
    with torch.no_grad():
        theta.clamp_(min=lower, max=upper)
    theta_after = theta.detach().cpu().numpy().astype(np.float64, copy=True)
    train_after = scaled_multilead_objective(
        context,
        training.forcing,
        training.observations,
        theta,
        scale,
        fixed_r_b,
        parent_contract,
        "training",
        grad=True,
    )
    validation_after = scaled_multilead_objective(
        context,
        validation.forcing,
        validation.observations,
        theta,
        scale,
        fixed_r_b,
        parent_contract,
        "validation",
        grad=False,
    )
    q_before = np.exp(theta_before)
    q_after = np.exp(theta_after)
    rho_before = process_variance_to_ratio(q_before, scale)
    rho_after = process_variance_to_ratio(q_after, scale)
    values = np.asarray(
        [
            float(train_before.detach()),
            float(validation_before.detach()),
            float(train_after.detach()),
            float(validation_after.detach()),
        ],
        dtype=np.float64,
    )
    if not np.isfinite(values).all():
        raise FloatingPointError("technical probe objective is non-finite")
    summary = {
        "anchor_index": 0,
        "adam_updates": 1,
        "training_objective_calls": 2,
        "validation_objective_calls": 2,
        "training_objective_before": float(values[0]),
        "validation_objective_before": float(values[1]),
        "training_objective_after": float(values[2]),
        "validation_objective_after": float(values[3]),
        "gradient_l2_norm": float(np.linalg.norm(gradient)),
        "all_values_finite": True,
    }
    arrays = {
        "theta_before": theta_before,
        "theta_after": theta_after,
        "gradient": gradient,
        "process_variance_before": q_before,
        "process_variance_after": q_after,
        "rho_before": rho_before,
        "rho_after": rho_after,
    }
    return summary, arrays


def transfer_ratios_from_local(
    local_ratio_by_basin: Mapping[str, np.ndarray],
    frozen: FrozenInputs,
    donor_registry: Mapping[str, Any] | None = None,
) -> tuple[dict[str, np.ndarray], dict[str, Any]]:
    registry = build_donor_registry(frozen) if donor_registry is None else donor_registry
    if set(local_ratio_by_basin) != set(frozen.basin_ids):
        raise ValueError("local ratio library must contain exactly all 455 basins")
    validated: dict[str, np.ndarray] = {}
    lower, upper = ratio_bounds()
    for basin_id in frozen.basin_ids:
        values = np.asarray(local_ratio_by_basin[basin_id], dtype=np.float64)
        if (
            values.shape != (frozen.dimension_by_basin[basin_id],)
            or not np.isfinite(values).all()
            or np.any(values < lower)
            or np.any(values > upper)
        ):
            raise ValueError(f"invalid sealed local ratios for {basin_id}")
        validated[basin_id] = values
    transferred: dict[str, np.ndarray] = {}
    evidence: dict[str, Any] = {}
    for receiver in frozen.basin_ids:
        receiver_record = registry["receivers"][receiver]
        values = np.empty(receiver_record["state_dimension"], dtype=np.float64)
        coordinate_evidence: list[dict[str, Any]] = []
        for coordinate in receiver_record["coordinates"]:
            state_index = int(coordinate["state_index"])
            donors = tuple(str(value) for value in coordinate["donors"])
            if receiver in donors or not donors:
                raise RuntimeError("receiver appeared in its transfer donor set")
            logs = np.sort(
                np.asarray(
                    [math.log(float(validated[donor][state_index])) for donor in donors],
                    dtype=np.float64,
                )
            )
            count = len(logs)
            if count % 2:
                log_median = float(logs[count // 2])
            else:
                log_median = float((logs[count // 2 - 1] + logs[count // 2]) / 2.0)
            values[state_index] = math.exp(log_median)
            coordinate_evidence.append(
                {
                    "state_index": state_index,
                    "donor_count": count,
                    "log_median": log_median,
                }
            )
        if not np.isfinite(values).all() or np.any(values < lower) or np.any(values > upper):
            raise RuntimeError(f"transferred ratio is invalid for {receiver}")
        transferred[receiver] = values
        evidence[receiver] = {
            "state_dimension": len(values),
            "coordinates": coordinate_evidence,
        }
    return transferred, evidence


def load_parent_training_context() -> Any:
    load_execution_authorization()
    return revision_training_common.verify_preflight_for_revision_training(
        PARENT_CONFIG,
        PARENT_PREFLIGHT_FINAL,
        PARENT_AUTHORIZATION,
        PARENT_RESULTS_ROOT,
        require_output_absent=False,
        recompute_training_validation_semantics=False,
        verify_all_raw_source_bytes=False,
    )


def load_selected_training_validation(
    parent_context: Any,
    basin_ids: Sequence[str],
) -> dict[str, dict[str, Any]]:
    result = parent_training_common.load_training_validation_periods(
        parent_context,
        basin_ids=tuple(str(value) for value in basin_ids),
    )
    if int(parent_context.evaluation_access_count) != 0:
        raise PermissionError("training loader recorded evaluation access")
    return result


def parameter_row_from_parent_context(parent_context: Any, basin_id: str) -> dict[str, float]:
    ordered = tuple(str(value) for value in parent_context.ordered_basin_ids)
    try:
        index = ordered.index(str(basin_id))
    except ValueError as exc:
        raise KeyError(f"basin is outside the parent training context: {basin_id}") from exc
    names = tuple(str(value) for value in parent_context.parameter_names)
    values = np.asarray(parent_context.parameter_values[index], dtype=np.float64)
    if names != tuple(PARAMETER_NAMES) or values.shape != (13,) or not np.isfinite(values).all():
        raise RuntimeError("parent parameter row changed")
    return {name: float(value) for name, value in zip(names, values)}


def period_data_from_loaded(value: Any, *, expected_day_count: int) -> PeriodData:
    return normalize_period_data(value, expected_day_count=expected_day_count)


def load_implementation_admission() -> dict[str, Any]:
    authorization = load_execution_authorization()
    admission = read_json_strict(IMPLEMENTATION_ADMISSION)
    if (
        admission.get("schema_version")
        != "tukf09_455_scaled_noise_local_transfer_implementation_admission_v1"
        or admission.get("experiment_id") != EXPERIMENT_ID
        or admission.get("status") != "IMPLEMENTATION_AND_TESTS_ADMITTED_FORMAL_EXPERIMENT_HOLD"
    ):
        raise PermissionError("implementation admission identity or status changed")
    if admission.get("scientific_contract_sha256") != sha256_file(SCIENCE_CONTRACT):
        raise PermissionError("implementation admission scientific contract binding changed")
    if admission.get("execution_authorization_sha256") != sha256_file(EXECUTION_AUTHORIZATION):
        raise PermissionError("implementation admission authorization binding changed")
    records = admission.get("implementation_files")
    required = set(authorization["write_scope"]["source_files"])
    if not isinstance(records, dict) or set(records) != required:
        raise PermissionError("implementation admission source member set changed")
    for relative, record in records.items():
        verify_file_binding(ROOT / relative, record, label=f"admitted implementation {relative}")
    test_report = admission.get("test_report")
    if not isinstance(test_report, dict):
        raise PermissionError("implementation admission lacks a test report")
    verify_file_binding(ROOT / test_report["path"], test_report, label="admitted test report")
    if int(test_report.get("failed", -1)) != 0 or int(test_report.get("errors", -1)) != 0:
        raise PermissionError("admitted test report is not passing")
    return admission


def build_directory_manifest(
    directory: str | Path,
    *,
    schema_version: str,
    status: str,
) -> dict[str, Any]:
    root = Path(directory)
    if not root.is_dir() or root.is_symlink():
        raise RuntimeError(f"manifest root must be one plain directory: {root}")
    files: dict[str, dict[str, Any]] = {}
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise RuntimeError(f"linked output is forbidden: {path}")
        if not path.is_file() or path.name == "manifest.final.sha256.json":
            continue
        relative = path.relative_to(root).as_posix()
        files[relative] = file_record(path)
    return {
        "schema_version": schema_version,
        "experiment_id": EXPERIMENT_ID,
        "status": status,
        "file_count": len(files),
        "files": files,
    }


def directory_file_bytes(directory: str | Path) -> int:
    root = Path(directory)
    return sum(path.stat().st_size for path in root.rglob("*") if path.is_file())


__all__ = [
    "EXECUTION_AUTHORIZATION",
    "EXPERIMENT_ID",
    "FrozenInputs",
    "HUMAN_CONTRACT",
    "IMPLEMENTATION_ADMISSION",
    "LEADS",
    "LocalSearchHistory",
    "PARENT_CONFIG",
    "PHYSICAL_STATE_NAMES",
    "PROBE_ID",
    "RESULTS_ROOT",
    "ROOT",
    "SCIENCE_CONTRACT",
    "anchor_ratio_matrix",
    "anchor_theta_matrix",
    "atomic_write_bytes_exclusive",
    "atomic_write_json_exclusive",
    "build_directory_manifest",
    "build_donor_registry",
    "canonical_json_bytes",
    "compute_state_scale",
    "configure_single_thread_execution",
    "decode_process_theta",
    "deterministic_npz_bytes",
    "deterministic_training_trajectory",
    "directory_file_bytes",
    "ensure_allowed_results_path",
    "file_record",
    "load_execution_authorization",
    "load_fixed_observation_noise",
    "load_frozen_inputs",
    "load_implementation_admission",
    "load_parent_training_context",
    "load_science_contract",
    "load_selected_training_validation",
    "log_process_variance_bounds",
    "parameter_row_from_parent_context",
    "period_data_from_loaded",
    "process_variance_to_ratio",
    "ratio_bounds",
    "ratio_to_process_variance",
    "read_json_strict",
    "require_formal_execution_denied",
    "run_full_local_search",
    "run_one_update_probe",
    "run_scaled_filter",
    "scaled_multilead_objective",
    "sha256_file",
    "state_floor_vector",
    "transfer_ratios_from_local",
]
