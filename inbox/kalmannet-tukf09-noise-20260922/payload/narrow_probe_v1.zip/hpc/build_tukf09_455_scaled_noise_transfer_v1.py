"""Metadata-only donor precheck and future transfer-vector builder."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
from typing import Any, Mapping


ROOT = Path(__file__).resolve().parents[1]
for _extra in (str(ROOT), str(ROOT / "src"), str(ROOT / "hpc")):
    if _extra not in sys.path:
        sys.path.insert(0, _extra)

import tukf09_455_scaled_noise_common_v1 as common  # noqa: E402


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def run_donor_precheck() -> dict[str, Any]:
    authorization = common.load_execution_authorization()
    common.require_formal_execution_denied()
    if authorization["donor_precheck"]["model_execution_allowed"] is not False:
        raise PermissionError("donor precheck unexpectedly permits model execution")
    frozen = common.load_frozen_inputs()
    registry = common.build_donor_registry(frozen)
    if (
        int(registry["receiver_count"])
        != int(authorization["donor_precheck"]["required_receiver_count"])
        or int(registry["minimum_donor_count"])
        != int(authorization["donor_precheck"]["required_minimum_donor_count"])
    ):
        raise RuntimeError("metadata donor precheck differs from the execution authorization")

    output_root = common.ensure_allowed_results_path(
        common.RESULTS_ROOT / "control" / "donor_precheck_v1",
        "control/donor_precheck_v1",
    )
    if output_root.exists() or output_root.is_symlink():
        raise FileExistsError(f"donor precheck output already exists: {output_root}")
    output_root.mkdir(parents=True, exist_ok=False)
    common.atomic_write_json_exclusive(output_root / "donor_registry.json", registry)
    coordinate_count = sum(
        int(value["coordinate_count"]) for value in registry["receivers"].values()
    )
    donor_reference_count = sum(
        int(coordinate["donor_count"])
        for value in registry["receivers"].values()
        for coordinate in value["coordinates"]
    )
    summary = {
        "schema_version": "tukf09_455_scaled_noise_donor_precheck_summary_v1",
        "experiment_id": common.EXPERIMENT_ID,
        "status": "METADATA_ONLY_DONOR_PRECHECK_PASS",
        "completed_at_utc": _utc_now(),
        "receiver_count": int(registry["receiver_count"]),
        "coordinate_count": coordinate_count,
        "donor_reference_count": donor_reference_count,
        "minimum_donor_count": int(registry["minimum_donor_count"]),
        "state_dimension_counts": common.load_science_contract()["population"][
            "state_dimension_counts"
        ],
        "population_order_sha256": common.load_science_contract()["population"][
            "basin_order_newline_utf8_sha256"
        ],
        "parameter_snapshot_sha256": common.load_science_contract()["lineage"][
            "input_seals"
        ]["parameters_only"]["sha256"],
        "model_execution_count": 0,
        "training_array_access_count": 0,
        "validation_array_access_count": 0,
        "evaluation_access_count": 0,
        "scientific_result": False,
    }
    common.atomic_write_json_exclusive(output_root / "precheck_summary.json", summary)
    manifest = common.build_directory_manifest(
        output_root,
        schema_version="tukf09_455_scaled_noise_donor_precheck_manifest_v1",
        status="METADATA_ONLY_DONOR_PRECHECK_SEALED_PASS",
    )
    common.atomic_write_json_exclusive(output_root / "manifest.final.sha256.json", manifest)
    return summary


def build_transfer_vectors_in_memory(
    local_ratio_by_basin: Mapping[str, Any],
) -> tuple[dict[str, Any], dict[str, Any]]:
    frozen = common.load_frozen_inputs()
    registry = common.build_donor_registry(frozen)
    return common.transfer_ratios_from_local(local_ratio_by_basin, frozen, registry)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--mode",
        required=True,
        choices=("donor-precheck", "formal-transfer"),
    )
    args = parser.parse_args()
    if args.mode == "formal-transfer":
        common.require_formal_execution_denied()
        raise PermissionError("formal transfer-vector construction is not authorized")
    summary = run_donor_precheck()
    print(json.dumps(summary, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
