"""Bounded probe runner and future local-search entry point.

The current execution authorization permits only ``technical-probe``.  The
``formal-local`` mode is present to make the denial explicit and cannot run
until a later authorization and admission are created.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import platform
import sys
import time
from typing import Any, Mapping

import numpy as np
import psutil
import torch


ROOT = Path(__file__).resolve().parents[1]
for _extra in (str(ROOT), str(ROOT / "src"), str(ROOT / "hpc")):
    if _extra not in sys.path:
        sys.path.insert(0, _extra)

import tukf09_455_scaled_noise_common_v1 as common  # noqa: E402


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _peak_rss_bytes(process: psutil.Process) -> int:
    info = process.memory_info()
    candidates = [int(info.rss)]
    for name in ("peak_wset", "peak_rss"):
        if hasattr(info, name):
            candidates.append(int(getattr(info, name)))
    return max(candidates)


def _runtime_identity() -> dict[str, Any]:
    return {
        "python_executable": Path(sys.executable).resolve().as_posix(),
        "python_version": platform.python_version(),
        "numpy_version": np.__version__,
        "torch_version": torch.__version__,
        "psutil_version": psutil.__version__,
        "platform": platform.platform(),
        "processor": platform.processor(),
        "device": "cpu",
        "torch_intraop_threads": int(torch.get_num_threads()),
        "torch_interop_threads": int(torch.get_num_interop_threads()),
    }


def _verify_runtime(authorization: Mapping[str, Any]) -> dict[str, Any]:
    expected = authorization["runtime_environment"]
    actual = _runtime_identity()
    comparisons = {
        "python_executable": Path(expected["python_executable"]).resolve().as_posix(),
        "python_version": str(expected["python_version"]),
        "numpy_version": str(expected["numpy_version"]),
        "torch_version": str(expected["torch_version"]),
        "psutil_version": str(expected["psutil_version"]),
        "platform": str(expected["platform"]),
        "processor": str(expected["processor"]),
        "device": "cpu",
        "torch_intraop_threads": int(expected["torch_intraop_threads"]),
        "torch_interop_threads": int(expected["torch_interop_threads"]),
    }
    if actual != comparisons:
        raise RuntimeError(f"technical-probe runtime identity changed: {actual!r}")
    return actual


def _verify_donor_precheck() -> dict[str, Any]:
    root = common.RESULTS_ROOT / "control" / "donor_precheck_v1"
    manifest_path = root / "manifest.final.sha256.json"
    manifest = common.read_json_strict(manifest_path)
    if (
        manifest.get("schema_version") != "tukf09_455_scaled_noise_donor_precheck_manifest_v1"
        or manifest.get("experiment_id") != common.EXPERIMENT_ID
        or manifest.get("status") != "METADATA_ONLY_DONOR_PRECHECK_SEALED_PASS"
    ):
        raise PermissionError("donor precheck is not sealed and passing")
    files = manifest.get("files")
    if not isinstance(files, dict) or set(files) != {"donor_registry.json", "precheck_summary.json"}:
        raise RuntimeError("donor precheck manifest member set changed")
    for relative, record in files.items():
        common.verify_file_binding(root / relative, record, label=f"donor precheck {relative}")
    registry = common.read_json_strict(root / "donor_registry.json")
    if (
        registry.get("status") != "METADATA_ONLY_DONOR_PRECHECK_PASS"
        or int(registry.get("receiver_count", -1)) != 455
        or int(registry.get("minimum_donor_count", -1)) != 13
        or int(registry.get("evaluation_access_count", -1)) != 0
        or int(registry.get("model_execution_count", -1)) != 0
    ):
        raise RuntimeError("donor precheck contents changed")
    return manifest


def _resource_check(
    *,
    started: float,
    process: psutil.Process,
    limits: Mapping[str, Any],
    stage: str,
) -> dict[str, Any]:
    elapsed = time.perf_counter() - started
    peak = _peak_rss_bytes(process)
    if elapsed > float(limits["wall_seconds"]):
        raise TimeoutError(f"technical probe exceeded wall-time cap after {stage}: {elapsed}")
    if peak > int(limits["maximum_process_rss_bytes"]):
        raise MemoryError(f"technical probe exceeded process-RSS cap after {stage}: {peak}")
    return {"stage": stage, "elapsed_seconds": elapsed, "peak_process_rss_bytes": peak}


def _write_failure(root: Path, exc: BaseException, stages: list[dict[str, Any]]) -> None:
    payload = {
        "schema_version": "tukf09_455_scaled_noise_technical_probe_failure_v1",
        "experiment_id": common.EXPERIMENT_ID,
        "probe_id": common.PROBE_ID,
        "status": "TECHNICAL_PROBE_FAILED_FORMAL_EXPERIMENT_HOLD",
        "failed_at_utc": _utc_now(),
        "exception_type": type(exc).__name__,
        "exception_message": str(exc),
        "completed_resource_stages": stages,
        "scientific_result": False,
        "automatic_retry_permitted": False,
        "evaluation_access_count": 0,
    }
    try:
        common.atomic_write_json_exclusive(root / "failure.json", payload)
    except FileExistsError:
        pass
    try:
        manifest = common.build_directory_manifest(
            root,
            schema_version="tukf09_455_scaled_noise_technical_probe_manifest_v1",
            status="TECHNICAL_PROBE_FAILED_FORMAL_EXPERIMENT_HOLD",
        )
        common.atomic_write_json_exclusive(root / "manifest.final.sha256.json", manifest)
    except (FileExistsError, OSError, RuntimeError, ValueError):
        pass


def run_technical_probe() -> dict[str, Any]:
    authorization = common.load_execution_authorization()
    common.load_implementation_admission()
    common.require_formal_execution_denied()
    _verify_donor_precheck()
    thread_counts = common.configure_single_thread_execution()
    runtime = _verify_runtime(authorization)
    if runtime["torch_intraop_threads"] != 1 or runtime["torch_interop_threads"] != 1:
        raise RuntimeError("technical probe did not enter one-thread PyTorch mode")

    probe = authorization["technical_probe"]
    limits = probe["total_limits"]
    output_root = common.ensure_allowed_results_path(
        ROOT / probe["output_root"], "technical_probe_v1"
    )
    if output_root.exists() or output_root.is_symlink():
        raise FileExistsError(f"technical probe output already exists: {output_root}")
    output_root.mkdir(parents=True, exist_ok=False)
    common.atomic_write_json_exclusive(
        output_root / "started.json",
        {
            "schema_version": "tukf09_455_scaled_noise_technical_probe_started_v1",
            "experiment_id": common.EXPERIMENT_ID,
            "probe_id": common.PROBE_ID,
            "status": "TECHNICAL_PROBE_RUNNING_FORMAL_EXPERIMENT_HOLD",
            "started_at_utc": _utc_now(),
            "process_id": os.getpid(),
            "scientific_result": False,
            "evaluation_access_count": 0,
        },
    )

    process = psutil.Process(os.getpid())
    started = time.perf_counter()
    stages: list[dict[str, Any]] = []
    try:
        frozen = common.load_frozen_inputs()
        fixed_r = common.load_fixed_observation_noise(frozen)
        science = common.load_science_contract()
        samples = tuple(str(item["basin_id"]) for item in probe["samples"])
        expected_dimensions = {str(item["basin_id"]): int(item["state_dimension"]) for item in probe["samples"]}
        first_by_dimension: dict[int, str] = {}
        for basin_id in frozen.basin_ids:
            first_by_dimension.setdefault(frozen.dimension_by_basin[basin_id], basin_id)
        if samples != (first_by_dimension[7], first_by_dimension[20]):
            raise RuntimeError("technical probe samples no longer follow the frozen selection rule")
        if any(frozen.dimension_by_basin[basin] != expected_dimensions[basin] for basin in samples):
            raise RuntimeError("technical probe sample dimensions changed")
        stages.append(_resource_check(started=started, process=process, limits=limits, stage="identity_checks"))

        parent_context = common.load_parent_training_context()
        loaded = common.load_selected_training_validation(parent_context, samples)
        if int(parent_context.evaluation_access_count) != 0:
            raise PermissionError("technical probe recorded evaluation access")
        stages.append(_resource_check(started=started, process=process, limits=limits, stage="training_validation_load"))

        basin_summaries: list[dict[str, Any]] = []
        total_training_calls = 0
        total_validation_calls = 0
        total_updates = 0
        total_trajectory_steps = 0
        for basin_id in samples:
            basin_started = time.perf_counter()
            periods = loaded[basin_id]
            training = common.period_data_from_loaded(periods["training"], expected_day_count=2557)
            validation = common.period_data_from_loaded(periods["validation"], expected_day_count=731)
            parameter_row = common.parameter_row_from_parent_context(parent_context, basin_id)
            context = common.build_causal_filter_context(
                basin_id,
                parameter_row,
                training.observations,
                parent_context.contract,
            )
            if context.dimension != expected_dimensions[basin_id]:
                raise RuntimeError(f"technical probe context dimension changed for {basin_id}")

            trajectory_started = time.perf_counter()
            initial_state, trajectory = common.deterministic_training_trajectory(
                context, training.forcing
            )
            scale, floor_hit, units = common.compute_state_scale(trajectory)
            trajectory_seconds = time.perf_counter() - trajectory_started
            total_trajectory_steps += int(trajectory.shape[0])
            stages.append(
                _resource_check(
                    started=started,
                    process=process,
                    limits=limits,
                    stage=f"{basin_id}_deterministic_scale",
                )
            )

            optimization_started = time.perf_counter()
            optimization, optimization_arrays = common.run_one_update_probe(
                context,
                training,
                validation,
                scale,
                fixed_r[basin_id],
                parent_context.contract,
                science,
            )
            optimization_seconds = time.perf_counter() - optimization_started
            total_training_calls += int(optimization["training_objective_calls"])
            total_validation_calls += int(optimization["validation_objective_calls"])
            total_updates += int(optimization["adam_updates"])
            stages.append(
                _resource_check(
                    started=started,
                    process=process,
                    limits=limits,
                    stage=f"{basin_id}_one_update",
                )
            )

            basin_root = output_root / f"basin_{basin_id}"
            basin_root.mkdir(exist_ok=False)
            arrays = {
                "dates_ns": np.asarray(training.dates_ns, dtype="<i8"),
                "initial_state": initial_state,
                "deterministic_training_trajectory": trajectory,
                "state_scale": scale,
                "floor_hit": floor_hit,
                **optimization_arrays,
            }
            common.atomic_write_bytes_exclusive(
                basin_root / "probe_arrays.npz", common.deterministic_npz_bytes(arrays)
            )
            basin_summary = {
                "schema_version": "tukf09_455_scaled_noise_technical_probe_basin_v1",
                "experiment_id": common.EXPERIMENT_ID,
                "probe_id": common.PROBE_ID,
                "status": "TECHNICAL_PROBE_BASIN_PASS_NOT_SCIENTIFIC",
                "basin_id": basin_id,
                "state_dimension": context.dimension,
                "state_units": list(units),
                "scale_floor_hit_count": int(np.count_nonzero(floor_hit)),
                "base_observation_variance": float(context.base_observation_variance),
                "fixed_parent_observation_noise_multiplier": float(fixed_r[basin_id]),
                "deterministic_trajectory_days": int(trajectory.shape[0]),
                "scale_sample_count": 2192,
                "trajectory_seconds": trajectory_seconds,
                "one_update_probe_seconds": optimization_seconds,
                "basin_total_seconds": time.perf_counter() - basin_started,
                "optimization": optimization,
                "scientific_result": False,
                "may_be_used_for_parameter_selection_or_claims": False,
                "evaluation_access_count": 0,
            }
            common.atomic_write_json_exclusive(basin_root / "probe_summary.json", basin_summary)
            basin_summaries.append(basin_summary)
            stages.append(
                _resource_check(
                    started=started,
                    process=process,
                    limits=limits,
                    stage=f"{basin_id}_published",
                )
            )

        expected = probe["total_limits"]
        actual_counts = {
            "basins": len(basin_summaries),
            "deterministic_basin_day_steps": total_trajectory_steps,
            "adam_updates": total_updates,
            "training_objective_calls": total_training_calls,
            "validation_objective_calls": total_validation_calls,
            "evaluation_array_reads": int(parent_context.evaluation_access_count),
        }
        for key, value in actual_counts.items():
            if value != int(expected[key]):
                raise RuntimeError(f"technical probe count {key}={value} differs from cap {expected[key]}")
        final_resources = _resource_check(
            started=started, process=process, limits=limits, stage="probe_complete"
        )
        summary = {
            "schema_version": "tukf09_455_scaled_noise_technical_probe_summary_v1",
            "experiment_id": common.EXPERIMENT_ID,
            "probe_id": common.PROBE_ID,
            "status": "TECHNICAL_PROBE_PASS_FORMAL_EXPERIMENT_HOLD",
            "completed_at_utc": _utc_now(),
            "runtime_environment": runtime,
            "thread_counts": thread_counts,
            "actual_counts": actual_counts,
            "resource_limits": dict(limits),
            "total_wall_seconds": final_resources["elapsed_seconds"],
            "peak_process_rss_bytes": final_resources["peak_process_rss_bytes"],
            "output_bytes_before_final_manifest": common.directory_file_bytes(output_root),
            "resource_stages": stages,
            "basins": basin_summaries,
            "scientific_result": False,
            "may_be_used_for_parameter_selection_or_claims": False,
            "evaluation_access_count": 0,
            "formal_state_scale_generation_count": 0,
            "formal_local_selection_count": 0,
        }
        common.atomic_write_json_exclusive(output_root / "probe_summary.json", summary)
        output_bytes = common.directory_file_bytes(output_root)
        if output_bytes > int(limits["maximum_output_bytes"]):
            raise RuntimeError(
                f"technical probe output exceeded cap: {output_bytes} > {limits['maximum_output_bytes']}"
            )
        manifest = common.build_directory_manifest(
            output_root,
            schema_version="tukf09_455_scaled_noise_technical_probe_manifest_v1",
            status="TECHNICAL_PROBE_SEALED_PASS_FORMAL_EXPERIMENT_HOLD",
        )
        common.atomic_write_json_exclusive(output_root / "manifest.final.sha256.json", manifest)
        return summary
    except BaseException as exc:
        _write_failure(output_root, exc, stages)
        raise


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--mode",
        required=True,
        choices=("technical-probe", "formal-local"),
    )
    args = parser.parse_args()
    if args.mode == "formal-local":
        common.require_formal_execution_denied()
        raise PermissionError(
            "455-basin formal state-scale generation and local search are not authorized"
        )
    summary = run_technical_probe()
    print(json.dumps(summary, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
