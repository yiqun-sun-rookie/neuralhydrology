"""Audited, explicitly authorized schema compatibility; no scientific changes.

This module verifies exact derivations of five successor entry points. The
original files and all 30 training-admitted executables remain untouched.
The producer payload hash excludes LF, while record/file hashes keep their frozen rules.
No dynamic patching, metadata rewriting, or evaluation-array loading occurs here.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
from typing import Any, Mapping
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
INCOMING = ROOT / "results/_incoming/tukf09_455_v2r14"
REVIEW = INCOMING / "compat_v5_repair_review.json"
TEST_XML = INCOMING / "compat_v5_tests_reviewed.xml"
SYNTHETIC_SOURCE = ROOT / "hpc/test_tukf09_455_evaluation_synthetic_compat_v5.py"
SYNTHETIC_XML = INCOMING / "compat_v5_synthetic_tests_reviewed.xml"
REQUIRED_SYNTHETIC_CASES = frozenset({
    "test_real_filter_callers_and_three_leads",
    "test_real_neural_callers_nine_units",
    "test_synthetic_formal_output_and_independent_verification",
})
TEST_SOURCE = ROOT / "hpc/test_tukf09_455_evaluation_compat_v5.py"
PLAN = ROOT / "docs/plans/2026-09-16-tukf09-455-shape-interface-compatibility-v5.md"
SLUG = "tukf09_455_basin_zero_validation_target_variance_revision_v1"
AUTHORIZATION_RELATIVE = f"artifacts/{SLUG}/authorizations/formal_evaluation_authorization_compat_v5.json"
ADMISSION_RELATIVE = f"artifacts/{SLUG}/formal_evaluation_admission_compat_v5/formal_evaluation_admission.json"
PREDECESSOR_FILES = {
    f"artifacts/{SLUG}/authorizations/formal_evaluation_authorization.json": "eb0db6be17fb599740749311b00c39150e8dd33dcfe49e2386483b54d01d6adc",
    f"artifacts/{SLUG}/formal_evaluation_admission/formal_evaluation_admission.json": "d3d51de49d97c765ea33c154d192e148ea43a34c5511d32854bf292c78053b52",
    f"results/{SLUG}/control/formal_evaluation_attempt.json": "c1c5aaa9432204710c24aa1effff1a55f1fb074d450e85b95c70f29ea4a79287",
    f"results/{SLUG}/control/formal_evaluation_failure.json": "516afa3ce1b10ef3fdf4f3cf0213de62f5f0799a39b4ea2d200f1dc1028da8a0",
}
PATCHES = json.loads(r'''{
  "register_tukf09_455_formal_evaluation_authorization": {
    "sha256": "b8e32bc18a4e5b25b8a7e71d476ac45367ab882e899bf37b6cc207f666c85952",
    "edits": [
      [
        "import uuid\n",
        "import uuid\n\nfrom hpc import tukf09_455_evaluation_compat_v5 as compat\n",
        1
      ],
      [
        "    selection = documents[\"training_selection_seal\"]\n",
        "    selection = documents[\"training_selection_seal\"]\n    if production:\n        compat.validate_seal_counts(selection)\n",
        1
      ],
      [
        "selection, \"filter_selected_model_count\", \"filter_basin_units\"",
        "selection, \"filter_selected_model_count\", \"rebound_filter_units\"",
        1
      ],
      [
        "\"scripts/register_tukf09_455_formal_evaluation_authorization.py\": {",
        "\"hpc/register_tukf09_455_formal_evaluation_authorization_compat_v5.py\": {",
        1
      ],
      [
        "\"scripts/admit_tukf09_455_formal_evaluation.py\": {",
        "\"hpc/admit_tukf09_455_formal_evaluation_compat_v5.py\": {",
        1
      ],
      [
        "\"admit_tukf09_455_formal_evaluation.py\"",
        "\"admit_tukf09_455_formal_evaluation_compat_v5.py\"",
        3
      ],
      [
        "    result = dict(unsigned)\n",
        "    if production:\n        unsigned[\"compatibility_repair\"] = compat.authorized_repair()\n        unsigned.update(compat.prior_consumed_authorization_fields())\n    result = dict(unsigned)\n",
        1
      ],
      [
        "\"scripts/evaluate_tukf09_455_basin_revision.py\"",
        "\"hpc/evaluate_tukf09_455_basin_revision_compat_v5.py\"",
        1
      ],
      [
        "\"scripts/verify_tukf09_455_basin_evaluation.py\"",
        "\"hpc/verify_tukf09_455_basin_evaluation_compat_v5.py\"",
        1
      ],
      [
        "_canonical_sha256(files)",
        "sha256(canonical_json_bytes(files)[:-1]).hexdigest()",
        3
      ],
      [
        "\"scripts/tukf09_455_evaluation_common.py\"",
        "\"hpc/tukf09_455_evaluation_common_compat_v5.py\"",
        1
      ],
      [
        "destination=root / expected_paths[\"authorization\"]",
        "destination=root / compat.AUTHORIZATION_RELATIVE",
        1
      ]
    ]
  },
  "admit_tukf09_455_formal_evaluation": {
    "sha256": "591d25f57cb1328d4da56d19177e0fdbefb8d052198982d746a311004078914f",
    "edits": [
      [
        "from scripts import register_tukf09_455_formal_evaluation_authorization as registration",
        "from hpc import register_tukf09_455_formal_evaluation_authorization_compat_v5 as registration\nfrom hpc import tukf09_455_evaluation_compat_v5 as compat",
        1
      ],
      [
        "    gate_bindings = authorization.get(\"gate_implementation_bindings\")",
        "    if production:\n        compat.verify_authorization(authorization)\n    gate_bindings = authorization.get(\"gate_implementation_bindings\")",
        1
      ],
      [
        "            \"scripts/register_tukf09_455_formal_evaluation_authorization.py\",\n            \"scripts/admit_tukf09_455_formal_evaluation.py\",",
        "            \"hpc/register_tukf09_455_formal_evaluation_authorization_compat_v5.py\",\n            \"hpc/admit_tukf09_455_formal_evaluation_compat_v5.py\",",
        1
      ],
      [
        "    documents = {\n",
        "    if authorization is not None:\n        compat.verify_authorization(authorization)\n    documents = {\n",
        1
      ],
      [
        "authorization_path = root / str(paths.get(\"authorization\"))",
        "authorization_path = root / compat.AUTHORIZATION_RELATIVE",
        1
      ],
      [
        "admission_path = root / str(paths.get(\"admission\"))",
        "admission_path = root / compat.ADMISSION_RELATIVE",
        1
      ]
    ]
  },
  "evaluate_tukf09_455_basin_revision": {
    "sha256": "9d0df7f8bcb9de9d17fa397ffdefaee254adce78ba478e97d23df11cea58b2c6",
    "edits": [
      [
        "from scripts import admit_tukf09_455_formal_evaluation as admission_module",
        "from hpc import admit_tukf09_455_formal_evaluation_compat_v5 as admission_module",
        2
      ],
      [
        "from scripts import tukf09_455_evaluation_common as common",
        "from hpc import tukf09_455_evaluation_common_compat_v5 as common",
        1
      ],
      [
        "common.canonical_json_sha256(semantic_members)",
        "sha256(common.canonical_json_bytes(semantic_members)[:-1]).hexdigest()",
        1
      ],
      [
        "admission_path = root / str(config[\"paths\"][\"admission\"])",
        "admission_path = root / admission_module.compat.ADMISSION_RELATIVE",
        1
      ],
      [
        "\"formal_evaluation_attempt.json\"",
        "\"formal_evaluation_compat_v5_attempt.json\"",
        1
      ],
      [
        "\"formal_evaluation_consumption.json\"",
        "\"formal_evaluation_compat_v5_consumption.json\"",
        1
      ],
      [
        "\"formal_evaluation_failure.json\"",
        "\"formal_evaluation_compat_v5_failure.json\"",
        1
      ],
      [
        "\"formal_evaluation_success.json\"",
        "\"formal_evaluation_compat_v5_success.json\"",
        1
      ],
      [
        "context.plain_model, result[\"posterior_state\"], forcing",
        "context.plain_model, result[\"posterior_state\"][:, 0, :], forcing",
        1
      ]
    ]
  },
  "verify_tukf09_455_basin_evaluation": {
    "sha256": "5cbccc442f7bb24f055a99f251c13ebd257f95103b617a5c508f77f696b4fc9d",
    "edits": [
      [
        "from scripts import admit_tukf09_455_formal_evaluation as admission_module",
        "from hpc import admit_tukf09_455_formal_evaluation_compat_v5 as admission_module",
        2
      ],
      [
        "admission_path = root / str(config[\"paths\"][\"admission\"])",
        "admission_path = root / admission_module.compat.ADMISSION_RELATIVE",
        1
      ],
      [
        "\"formal_evaluation_attempt.json\"",
        "\"formal_evaluation_compat_v5_attempt.json\"",
        1
      ],
      [
        "\"formal_evaluation_independent_attempt.json\"",
        "\"formal_evaluation_independent_compat_v5_attempt.json\"",
        1
      ],
      [
        "\"formal_evaluation_consumption.json\"",
        "\"formal_evaluation_compat_v5_consumption.json\"",
        1
      ],
      [
        "\"formal_evaluation_independent_consumption.json\"",
        "\"formal_evaluation_independent_compat_v5_consumption.json\"",
        1
      ],
      [
        "\"formal_evaluation_failure.json\"",
        "\"formal_evaluation_compat_v5_failure.json\"",
        1
      ],
      [
        "\"formal_evaluation_independent_failure.json\"",
        "\"formal_evaluation_independent_compat_v5_failure.json\"",
        1
      ],
      [
        "\"formal_evaluation_success.json\"",
        "\"formal_evaluation_compat_v5_success.json\"",
        1
      ],
      [
        "\"formal_evaluation_independent_success.json\"",
        "\"formal_evaluation_independent_compat_v5_success.json\"",
        1
      ],
      [
        "_json_sha256(semantic_members)",
        "sha256(_json_bytes(semantic_members)[:-1]).hexdigest()",
        1
      ],
      [
        "        decoded_process, decoded_r_b = filter_training.decode_theta(\n            torch.as_tensor(theta_log, dtype=torch.float64), context.dimension, contract\n        )\n",
        "        decoded_process, decoded_r_b = filter_training.decode_theta(\n            torch.as_tensor(theta_log, dtype=torch.float64), context.dimension, contract\n        )\n        serialized_actual = np.exp(theta_log)\n",
        1
      ],
      [
        "not np.array_equal(decoded_process.numpy(), process_diagonal)",
        "not np.array_equal(serialized_actual[:-1], process_diagonal)",
        1
      ],
      [
        "float(decoded_r_b) != r_b",
        "float(serialized_actual[-1]) != r_b",
        1
      ],
      [
        "            result[\"posterior_state\"],\n",
        "            result[\"posterior_state\"][:, 0, :],\n",
        1
      ]
    ]
  },
  "tukf09_455_evaluation_common": {
    "sha256": "ef5958d0288b95c125328f4654bbfa16e4c6aa748c439e656e9d9edb734d84ff",
    "edits": [
      [
        "aggregate = canonical_json_sha256(dict(semantic_members))",
        "aggregate = sha256(canonical_json_bytes(dict(semantic_members))[:-1]).hexdigest()",
        1
      ]
    ]
  }
}''')


def canonical(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")


def record(path: Path) -> dict[str, Any]:
    from scripts import tukf09_455_training_common as training_common
    training_common.ensure_no_symlink_components(path, stop_at=ROOT)
    if not path.is_file() or path.is_symlink() or path.stat().st_nlink != 1:
        raise RuntimeError(f"Compatibility member is absent or linked: {path}")
    data = path.read_bytes()
    return {"sha256": sha256(data).hexdigest(), "size_bytes": len(data)}


def derive_text(name: str, source: bytes) -> str:
    specification = PATCHES[name]
    if sha256(source).hexdigest() != specification["sha256"]:
        raise RuntimeError(f"Frozen predecessor changed: {name}")
    text = source.decode("utf-8").replace("\r\n", "\n")
    for before, after, count in specification["edits"]:
        if text.count(before) != count:
            raise RuntimeError(f"Compatibility substitution count changed: {name}")
        text = text.replace(before, after)
    return text


def validate_seal_counts(selection: Mapping[str, Any]) -> None:
    counts = selection.get("completion_counts")
    if not isinstance(counts, Mapping):
        raise RuntimeError("Real sealed completion_counts are missing")
    for name, expected in (("rebound_filter_units", 455), ("neural_model_units", 9)):
        if type(counts.get(name)) is not int or counts[name] != expected:
            raise RuntimeError(f"Real sealed count changed: {name}")
    for mapping, name, expected in (
        (counts, "filter_basin_units", 455),
        (selection, "filter_selected_model_count", 455),
        (selection, "neural_selected_model_count", 9),
    ):
        if name in mapping and (type(mapping[name]) is not int or mapping[name] != expected):
            raise RuntimeError(f"Conflicting compatibility count: {name}")


def implementation_record() -> dict[str, Any]:
    derivations = {}
    for name in PATCHES:
        old = ROOT / f"scripts/{name}.py"
        new = ROOT / f"hpc/{name}_compat_v5.py"
        original_record = record(old)
        expected = derive_text(name, old.read_bytes()).encode("utf-8")
        actual_record = record(new)
        if new.read_bytes() != expected:
            raise RuntimeError(f"Successor differs outside its reviewed substitutions: {name}")
        derivations[name] = {
            "predecessor": {"path": old.relative_to(ROOT).as_posix(), **original_record},
            "successor": {"path": new.relative_to(ROOT).as_posix(), **actual_record},
            "substitution_count": sum(edit[2] for edit in PATCHES[name]["edits"]),
            "newline_normalization": "CRLF to LF only",
        }
    return {
        "derivations": derivations,
        "review_guard": record(Path(__file__)),
        "regression_test_source": record(TEST_SOURCE),
        "synthetic_test_source": record(SYNTHETIC_SOURCE),
        "repair_plan": record(PLAN),
    }


def prepared_v3_proof() -> dict[str, Any]:
    from hpc import tukf09_455_evaluation_compat_v3 as predecessor
    previous_review = predecessor.authorized_repair()
    if previous_review["sha256"] != "a7bdfa3f93f36598ee082e039f60fc03a6063339c3b6df0eff165ced8ef32cfe":
        raise RuntimeError("Prepared v3 review changed")
    expected_files = {
        f"artifacts/{SLUG}/authorizations/formal_evaluation_authorization_compat_v3.json": "dda4927f264d88f27db31e9b22ed14b5824b0b360feb887b4d4e0e20706adb13",
        f"artifacts/{SLUG}/formal_evaluation_admission_compat_v3/formal_evaluation_admission.json": "efd10b8c2d8b191c5c6401529433f1562df9ae44d843d86ab45e9653d4f4d353",
        "results/_incoming/tukf09_455_v2r14/compat_v3_parameter_interface_blocker.json": "18a2dfdfa7c09dad6a591169d52d72d169d764a1dd0bf9f4194ecff7d9179533",
    }
    files = {}
    for relative, expected in expected_files.items():
        path = ROOT / relative
        actual = record(path)
        if actual["sha256"] != expected:
            raise RuntimeError(f"Prepared v3 evidence changed: {relative}")
        document = json.loads(path.read_bytes())
        unsigned = dict(document)
        claimed = unsigned.pop("record_sha256", None)
        if claimed != sha256(canonical(unsigned)).hexdigest():
            raise RuntimeError("Prepared v3 evidence self-hash changed")
        files[relative] = actual
    for prefix in ("formal_evaluation_compat_v3", "formal_evaluation_independent_compat_v3"):
        for stage in ("attempt", "consumption", "failure", "success"):
            if os.path.lexists(ROOT / f"results/{SLUG}/control/{prefix}_{stage}.json"):
                raise RuntimeError("Prepared v3 unexpectedly started a formal attempt")
    return {"review": previous_review, "files": files, "formal_attempt_started": False}


def earlier_predecessor_proof() -> dict[str, Any]:
    from hpc import tukf09_455_evaluation_compat_v2 as predecessor
    previous_review = predecessor.authorized_repair()
    records = {}
    documents = {}
    for relative, expected in PREDECESSOR_FILES.items():
        path = ROOT / relative
        actual = record(path)
        if actual["sha256"] != expected:
            raise RuntimeError(f"Preserved predecessor evidence changed: {relative}")
        document = json.loads(path.read_bytes())
        unsigned = dict(document)
        claimed = unsigned.pop("record_sha256", None)
        if claimed != sha256(canonical(unsigned)).hexdigest():
            raise RuntimeError("Preserved predecessor self-hash changed")
        records[relative] = actual
        documents[path.name] = document
    authorization = documents["formal_evaluation_authorization.json"]
    admission = documents["formal_evaluation_admission.json"]
    attempt = documents["formal_evaluation_attempt.json"]
    failure = documents["formal_evaluation_failure.json"]
    if (
        admission["authorization_sha256"] != PREDECESSOR_FILES[f"artifacts/{SLUG}/authorizations/formal_evaluation_authorization.json"]
        or admission["authorization_record_sha256"] != authorization["record_sha256"]
        or attempt["admission_sha256"] != PREDECESSOR_FILES[f"artifacts/{SLUG}/formal_evaluation_admission/formal_evaluation_admission.json"]
        or failure["attempt_record_sha256"] != attempt["record_sha256"]
        or failure["attempt_id"] != attempt["attempt_id"]
        or attempt["evaluation_arrays_loaded"] is not False
        or attempt["evaluation_access_ledger"] != {"evaluation_array_reads": 0, "evaluation_metrics": 0, "evaluation_outputs": 0, "evaluation_predictions": 0}
        or attempt["retry_allowed"] is not False
        or failure["evaluation_access_consumed"] is not False
        or failure["consumption_record_sha256"] is not None
        or failure["evaluation_output_exists"] is not False
        or failure["retry_allowed"] is not False
        or failure["exception_message"] != "evaluation semantic identity changed"
        or failure["status"] != "FORMAL_EVALUATION_FAILED_RETRY_FORBIDDEN"
    ):
        raise RuntimeError("Preserved attempt is not the explicitly authorized zero-access predecessor")
    for name in ("formal_evaluation_consumption.json", "formal_evaluation_success.json"):
        if os.path.lexists(ROOT / f"results/{SLUG}/control" / name):
            raise RuntimeError("Preserved predecessor has unexpected consumption or success evidence")
    return {"review": previous_review, "files": records, "attempt_id": attempt["attempt_id"], "evaluation_access_consumed": False, "prepared_v3": prepared_v3_proof()}


V4_ATTEMPT_ID = "98cc9571dd34fe9e77b4464c04ef5077"
V4_FILES = {
    f"artifacts/{SLUG}/authorizations/formal_evaluation_authorization_compat_v4.json": "e66a7b4d5a712a89c37b04e9824718e972a408e129fb40555eab312913f23f9a",
    f"artifacts/{SLUG}/formal_evaluation_admission_compat_v4/formal_evaluation_admission.json": "2cc9cdeff5fa76e84f7ec6386fb1da1d25d8c35db7ec10234cc81c03e1f0b4b1",
    f"results/{SLUG}/control/formal_evaluation_compat_v4_attempt.json": "a50e1b183ff9e2ce2bca724b8060e2cb8c0515b7d11cd6d08afee94ec0c95eee",
    f"results/{SLUG}/control/formal_evaluation_compat_v4_consumption.json": "30fddd6ccb512665aaee1095544d5a106b1505dafdf3f4df372d8b6f45209e9a",
    f"results/{SLUG}/control/formal_evaluation_compat_v4_failure.json": "2a2fb9cd01048ef3c7439ddcf974aaaa4bdc5688cba9ec70738a0652c56edba6",
    "results/_incoming/tukf09_455_v2r14/formal_evaluation_compat_v4_run.log": "97e943839bc7c4d9e68d4fb93a560bc3646fbff145c8ef1882c6d55789e2a61c",
}


def predecessor_proof() -> dict[str, Any]:
    """Prove consumed v4 failure, without claiming historical access was zero."""
    from hpc import tukf09_455_evaluation_compat_v4 as predecessor
    from scripts import tukf09_455_training_common as training_common
    previous_review = predecessor.authorized_repair()
    if previous_review["sha256"] != "2a77fef8b1ea7cd62b9e676f73f722e495a90be2ecf2788b983c8229dcf399a3":
        raise RuntimeError("Consumed v4 review changed")
    records = {}
    documents = {}
    for relative, expected in V4_FILES.items():
        path = ROOT / relative
        actual = record(path)
        if actual["sha256"] != expected:
            raise RuntimeError(f"Consumed v4 predecessor evidence changed: {relative}")
        records[relative] = actual
        if path.suffix == ".json":
            document = json.loads(path.read_bytes())
            unsigned = dict(document)
            claimed = unsigned.pop("record_sha256", None)
            if claimed != sha256(canonical(unsigned)).hexdigest():
                raise RuntimeError("Consumed v4 predecessor self-hash changed")
            documents[path.name] = document
    authorization = documents["formal_evaluation_authorization_compat_v4.json"]
    admission = documents["formal_evaluation_admission.json"]
    attempt = documents["formal_evaluation_compat_v4_attempt.json"]
    consumption = documents["formal_evaluation_compat_v4_consumption.json"]
    failure = documents["formal_evaluation_compat_v4_failure.json"]
    authorization_file_hash = V4_FILES[f"artifacts/{SLUG}/authorizations/formal_evaluation_authorization_compat_v4.json"]
    admission_file_hash = V4_FILES[f"artifacts/{SLUG}/formal_evaluation_admission_compat_v4/formal_evaluation_admission.json"]
    consumption_file_hash = V4_FILES[f"results/{SLUG}/control/formal_evaluation_compat_v4_consumption.json"]
    if (
        admission.get("authorization_sha256") != authorization_file_hash
        or admission.get("authorization_record_sha256") != authorization["record_sha256"]
        or attempt.get("admission_sha256") != admission_file_hash
        or consumption.get("admission_sha256") != admission_file_hash
        or any(doc.get("attempt_id") != V4_ATTEMPT_ID for doc in (attempt, consumption, failure))
        or consumption.get("attempt_record_sha256") != attempt["record_sha256"]
        or failure.get("attempt_record_sha256") != attempt["record_sha256"]
        # Frozen failure producer stores the consumption FILE hash, not its self-hash.
        or failure.get("consumption_record_sha256") != consumption_file_hash
        or consumption.get("evaluation_access_consumed") is not True
        or consumption.get("evaluation_array_read_attempts") != 1
        or failure.get("evaluation_access_consumed") is not True
        or any(doc.get("retry_allowed") is not False for doc in (attempt, consumption, failure))
        or failure.get("evaluation_output_exists") is not False
        or failure.get("status") != "FORMAL_EVALUATION_FAILED_RETRY_FORBIDDEN"
        or failure.get("exception_message") != "The size of tensor a (0) must match the size of tensor b (3284) at non-singleton dimension 1"
    ):
        raise RuntimeError("Consumed v4 predecessor lifecycle is conflicting")
    absent = [
        f"results/{SLUG}/control/formal_evaluation_compat_v4_success.json",
        "results/_incoming/tukf09_455_v2r14/formal_evaluation_independent_compat_v4_run.log",
    ]
    absent.extend(
        f"results/{SLUG}/control/formal_evaluation_independent_compat_v4_{stage}.json"
        for stage in ("attempt", "consumption", "failure", "success")
    )
    for relative in absent:
        path = ROOT / relative
        if os.path.lexists(path):
            raise RuntimeError(f"Consumed v4 predecessor has unexpected success/output/lock/independent lifecycle: {relative}")
        training_common.ensure_no_symlink_components(path, stop_at=ROOT)
    return {
        "review": previous_review, "files": records, "attempt_id": V4_ATTEMPT_ID,
        "evaluation_access_consumed": True, "retry_allowed": False,
        "earlier_predecessor": earlier_predecessor_proof(),
        "forbidden_lifecycle_paths_absent": absent,
        "no_new_evaluation_access": True,
    }


def prior_consumed_authorization_fields() -> dict[str, Any]:
    return {
        "prior_formal_evaluation_access_consumed": True,
        "prior_consumed_formal_evaluation_proof": predecessor_proof(),
        "zero_evaluation_access_ledger_scope": "new_compat_v5_attempt_start_only",
    }


def require_new_attempt_not_started() -> dict[str, Any]:
    """Initial-only shared absence check; never rechecked inside a legal own lock."""
    from scripts import tukf09_455_training_common as training_common
    paths = [
        AUTHORIZATION_RELATIVE, str(Path(ADMISSION_RELATIVE).parent),
        f"results/{SLUG}/evaluation", f"results/{SLUG}/evaluation_independent",
        f"results/{SLUG}/control/.formal_evaluation.lock.json",
        f"results/{SLUG}/control/.formal_evaluation_independent.lock.json",
    ]
    paths.extend(
        f"results/{SLUG}/control/{prefix}_{stage}.json"
        for prefix in ("formal_evaluation_compat_v5", "formal_evaluation_independent_compat_v5")
        for stage in ("attempt", "consumption", "failure", "success")
    )
    for relative in paths:
        path = ROOT / relative
        if os.path.lexists(path):
            raise RuntimeError(f"New compatibility attempt already has authorization/output/lock/lifecycle: {relative}")
        training_common.ensure_no_symlink_components(path, stop_at=ROOT)
    return {"checked_at_new_attempt_start_only": True, "absent_paths": paths}


def regression_xml_evidence(path: Path, *, required_cases: frozenset[str] = frozenset(), source: Path | None = None) -> dict[str, Any]:
    """Bind passing actual testcase elements, not only aggregate test counts."""
    file_record = record(path)
    xml = ET.fromstring(path.read_bytes())
    suites = list(xml.iter("testsuite"))
    cases = list(xml.iter("testcase"))
    if not suites or not cases:
        raise RuntimeError("Compatibility regression evidence is absent")
    declared = sum(int(suite.get("tests", "0")) for suite in suites)
    failed = sum(int(suite.get("failures", "0")) + int(suite.get("errors", "0")) for suite in suites)
    skipped = sum(int(suite.get("skipped", "0")) for suite in suites)
    if declared != len(cases) or failed or skipped or any(
        case.find(tag) is not None for case in cases for tag in ("failure", "error", "skipped")
    ):
        raise RuntimeError("Compatibility regression evidence is failed, skipped, or inconsistent")
    names = {case.get("name", "").split("[", 1)[0] for case in cases}
    if not required_cases.issubset(names):
        raise RuntimeError("Required named synthetic end-to-end cases are absent")
    if source is not None:
        import ast
        tree = ast.parse(source.read_text(encoding="utf-8"))
        source_names = {node.name for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
        if not required_cases.issubset(source_names):
            raise RuntimeError("Required named synthetic source cases are absent")
        for required in required_cases:
            matches = [case for case in cases if case.get("name", "").split("[", 1)[0] == required]
            if not matches or any(
                case.get("classname", "") != "hpc.test_tukf09_455_evaluation_synthetic_compat_v5"
                for case in matches
            ):
                raise RuntimeError("Required synthetic cases do not originate from the bound synthetic module")
    if len(cases) < (len(required_cases) if required_cases else 10):
        raise RuntimeError("Compatibility regression evidence has insufficient passing cases")
    result = {"path": path.relative_to(ROOT).as_posix(), **file_record, "passed": len(cases), "failed": 0, "skipped": 0}
    if source is not None:
        result["source"] = {"path": source.relative_to(ROOT).as_posix(), **record(source)}
        result["required_cases"] = sorted(required_cases)
    return result


def semantic_metadata_audit() -> dict[str, Any]:
    from hpc import register_tukf09_455_formal_evaluation_authorization_compat_v5 as registration
    from hpc import tukf09_455_evaluation_common_compat_v5 as common
    bindings = registration.fixed_production_bindings()
    final_path = bindings["independent_preflight_final_manifest"]
    final = json.loads(final_path.read_bytes())
    preflight = final_path.parent.parent
    documents = {}
    for name in ("population_registry.json", "semantic_input_manifest.sha256.json", "raw_source_manifest.sha256.json"):
        path = preflight / name
        if record(path) != final["files"][name]:
            raise RuntimeError(f"Frozen metadata file changed: {name}")
        documents[name] = json.loads(path.read_bytes())
    ordered = documents["population_registry.json"]["eligible"]
    if (len(ordered) != common.FROZEN_BASIN_COUNT
        or common.EXCLUDED_BASIN_ID in ordered
        or sha256("".join(value + "\n" for value in ordered).encode()).hexdigest() != common.FROZEN_ORDERED_BASIN_NEWLINE_SHA256):
        raise RuntimeError("Frozen ordered population changed")
    members = {key: value for key, value in documents["semantic_input_manifest.sha256.json"]["members"].items() if key.split("/")[1] == "evaluation"}
    expected = {f"{basin}/evaluation/{name}" for basin in ordered for name in ("dates_ns", "forcing", "observations")}
    if set(members) != expected or len(members) != common.FROZEN_SEMANTIC_MEMBER_COUNT:
        raise RuntimeError("Frozen semantic metadata member set changed")
    for key, member in members.items():
        kind = key.split("/")[-1]
        dtype = "<i8" if kind == "dates_ns" else "<f8"
        shape = [common.FROZEN_EVALUATION_DAY_COUNT, 3] if kind == "forcing" else [common.FROZEN_EVALUATION_DAY_COUNT]
        if (set(member) != {"dtype", "shape", "sha256"} or member["dtype"] != dtype or member["shape"] != shape
            or not isinstance(member["sha256"], str) or len(member["sha256"]) != 64
            or any(char not in "0123456789abcdef" for char in member["sha256"])):
            raise RuntimeError(f"Frozen semantic metadata descriptor changed: {key}")
    aggregate = sha256(canonical(members)[:-1]).hexdigest()
    if aggregate != common.FROZEN_EVALUATION_SEMANTIC_SHA256:
        raise RuntimeError("Frozen semantic payload identity changed")
    raw_files = documents["raw_source_manifest.sha256.json"]["files"]
    if len(raw_files) != common.FROZEN_RAW_SOURCE_COUNT:
        raise RuntimeError("Frozen raw source count changed")
    return {"evaluation_array_reads": 0, "member_count": len(members), "semantic_payload_sha256": aggregate,
            "raw_source_member_count": len(raw_files), "ordered_basin_count": len(ordered)}


def freeze_review() -> dict[str, Any]:
    if os.path.lexists(REVIEW):
        raise FileExistsError("Compatibility review already exists; do not overwrite")
    initial_absence = require_new_attempt_not_started()
    predecessor = predecessor_proof()
    metadata = semantic_metadata_audit()
    production_preflight = preflight(require_frozen_review=False)
    implementation = implementation_record()
    regression = regression_xml_evidence(TEST_XML)
    synthetic = regression_xml_evidence(SYNTHETIC_XML, required_cases=REQUIRED_SYNTHETIC_CASES, source=SYNTHETIC_SOURCE)
    result = {
        "schema_version": "tukf09_455_evaluation_shape_compatibility_review_v5",
        "status": "COMPATIBILITY_REPAIR_TESTED_ORIGINAL_EVIDENCE_PRESERVED",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "authorization_basis": "User explicitly authorized (授权) a new technical successor after consumed v4 failure: select the sole basin axis at the two posterior-state forecast calls, preserve the scientific contract and prior consumed access, and require synthetic end-to-end evidence before separately authorized formal comparison and independent verification.",
        "preserved_predecessor": predecessor,
        "initial_shared_output_lock_and_new_lifecycle_absence": initial_absence,
        "metadata_preflight": metadata,
        "production_preflight_status": production_preflight["status"],
        "new_authorization_relative_path": AUTHORIZATION_RELATIVE,
        "new_admission_relative_path": ADMISSION_RELATIVE,
        "scientific_contract_changed": False,
        "original_training_admission_changed": False,
        "original_source_files_changed": False,
        "evaluation_arrays_loaded": False,
        "original_failed_stage": "v4 formal evaluation consumed access then failed at the three-dimensional posterior-state forecast interface",
        "no_new_evaluation_access": True,
        "prior_formal_evaluation_access_consumed": True,
        "original_failure_consumed_evaluation_access": True,
        "implementation": implementation,
        "regression_evidence": regression,
        "synthetic_regression_evidence": synthetic,
    }
    result["record_sha256"] = sha256(canonical(result)).hexdigest()
    from scripts.register_tukf09_455_formal_evaluation_authorization import _atomic_write_exclusive
    _atomic_write_exclusive(REVIEW, canonical(result))
    return result


def authorized_repair() -> dict[str, Any]:
    review_file_record = record(REVIEW)
    review = json.loads(REVIEW.read_bytes())
    unsigned = dict(review)
    claimed = unsigned.pop("record_sha256", None)
    if claimed != sha256(canonical(unsigned)).hexdigest():
        raise RuntimeError("Compatibility review self-hash changed")
    if review.get("status") != "COMPATIBILITY_REPAIR_TESTED_ORIGINAL_EVIDENCE_PRESERVED":
        raise RuntimeError("Compatibility review status changed")
    if review.get("preserved_predecessor") != predecessor_proof():
        raise RuntimeError("Preserved predecessor proof changed after review")
    if review.get("metadata_preflight") != semantic_metadata_audit():
        raise RuntimeError("Metadata proof changed after review")
    if review.get("implementation") != implementation_record():
        raise RuntimeError("Compatibility implementation changed after review")
    if review.get("regression_evidence") != regression_xml_evidence(TEST_XML):
        raise RuntimeError("Compatibility regression evidence changed")
    if review.get("synthetic_regression_evidence") != regression_xml_evidence(
        SYNTHETIC_XML, required_cases=REQUIRED_SYNTHETIC_CASES, source=SYNTHETIC_SOURCE
    ):
        raise RuntimeError("Synthetic regression source/XML evidence changed")
    if (review.get("prior_formal_evaluation_access_consumed") is not True
        or review.get("original_failure_consumed_evaluation_access") is not True
        or review.get("no_new_evaluation_access") is not True
        or review.get("scientific_contract_changed") is not False):
        raise RuntimeError("Compatibility review misstates historical consumed access or scientific contract")
    return {"path": str(REVIEW), **review_file_record, "record_sha256": claimed}


def verify_authorization(authorization: Mapping[str, Any]) -> None:
    if authorization.get("compatibility_repair") != authorized_repair():
        raise RuntimeError("Authorization does not bind the reviewed compatibility repair")
    for key, expected_value in prior_consumed_authorization_fields().items():
        if canonical(authorization.get(key)) != canonical(expected_value):
            raise RuntimeError(f"Authorization does not bind prior consumed evaluation proof: {key}")
    unsigned = dict(authorization)
    claimed = unsigned.pop("record_sha256", None)
    if claimed != sha256(canonical(unsigned)).hexdigest():
        raise RuntimeError("Authorization prior-consumed fields are not self-hash bound")
    expected = {
        "evaluation_common_source": "tukf09_455_evaluation_common",
        "evaluator_source": "evaluate_tukf09_455_basin_revision",
        "independent_evaluation_verifier_source": "verify_tukf09_455_basin_evaluation",
    }
    for label, name in expected.items():
        path = ROOT / f"hpc/{name}_compat_v5.py"
        if authorization.get("bindings", {}).get(label) != {"path": str(path), **record(path)}:
            raise RuntimeError(f"Authorization does not bind the executed successor: {label}")
    gates = authorization.get("gate_implementation_bindings", {})
    expected_gates = {
        f"hpc/{name}_compat_v5.py": {"path": str(ROOT / f"hpc/{name}_compat_v5.py"), **record(ROOT / f"hpc/{name}_compat_v5.py")}
        for name in ("register_tukf09_455_formal_evaluation_authorization", "admit_tukf09_455_formal_evaluation")
    }
    if gates != expected_gates:
        raise RuntimeError("Authorization gate provenance is not the actual successor code")


def preflight(*, require_frozen_review: bool = True) -> dict[str, Any]:
    from hpc import register_tukf09_455_formal_evaluation_authorization_compat_v5 as registration
    from hpc import admit_tukf09_455_formal_evaluation_compat_v5 as admission
    require_new_attempt_not_started()
    predecessor_proof()
    metadata = semantic_metadata_audit()
    repair = authorized_repair() if require_frozen_review else implementation_record()
    bindings = registration.fixed_production_bindings()
    records = {}
    documents = {}
    for label, path in bindings.items():
        records[label] = {"path": str(path), **record(path)}
        if label in registration.JSON_BINDING_LABELS:
            documents[label] = registration._read_json(path, label=label)
    registration._validate_upstream(documents, production=True)
    registration._validate_algorithm_source_closure(documents, records, production=True)
    admission._require_current_runtime_matches_training(records)
    return {"status": "COMPATIBILITY_PRODUCTION_PREFLIGHT_PASSED_NO_NEW_EVALUATION_ACCESS", "prior_formal_evaluation_access_consumed": True, "no_new_evaluation_access": True, "semantic_metadata": metadata, "binding_count": len(bindings), "original_executables": 30, "compatibility_repair": repair}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--freeze-review", action="store_true")
    parser.add_argument("--preflight", action="store_true")
    parser.add_argument("--audit-unsealed", action="store_true")
    args = parser.parse_args()
    if sum((args.freeze_review, args.preflight, args.audit_unsealed)) != 1:
        raise ValueError("Choose exactly one explicit action")
    result = freeze_review() if args.freeze_review else preflight(require_frozen_review=not args.audit_unsealed)
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
