"""Additive provenance checks; imports no model and never reruns a model."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
from typing import Any, Mapping
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
EXPERIMENT_ID = "TUKF09_455_SCALED_NOISE_LOCAL_TRANSFER_V1"
STAGE_ID = "TUKF09_455_STATE_SCALE_GENERATION_V1"
RESULTS = Path("results/tukf09_455_scaled_noise_local_transfer_v1")
FORMAL = RESULTS / "state_scales_v1"
AUDIT = RESULTS / "control/state_scale_independent_v1"
SUPPLEMENT = RESULTS / "control/state_scale_provenance_supplement_v2"
REPAIR_ADMISSION = Path("hpc/tukf09_455_state_scale_provenance_repair_admission_v2.json")
SOURCE_FILES = (
    "hpc/tukf09_455_state_scale_integrity_v2.py",
    "hpc/run_tukf09_455_state_scale_guarded_v2.py",
    "hpc/test_tukf09_455_state_scale_integrity_v2.py",
)
SCIENCE = Path("hpc/tukf09_455_scaled_noise_local_transfer_contract_v1.json")
PARENT_ADMISSION = Path(
    "artifacts/tukf09_455_basin_zero_validation_target_variance_revision_v1/"
    "formal_evaluation_admission_compat_v5/formal_evaluation_admission.json"
)
STAGE_ADMISSION = Path("hpc/tukf09_455_state_scale_generation_implementation_admission_v1.json")
PINNED = {
    SCIENCE: "27239212680bd370bd76f40e53337b7d68d80cbe4dc01feac2164bab4917f8a1",
    PARENT_ADMISSION: "1fbd45a829d2216d78e72a70c8ebc221a6e745d2078100ea895b4a44f6b15c5a",
    STAGE_ADMISSION: "1ed149b68be52ab8fcb74c3a844d4524d3e7b4fb87ec3df305634c268341548a",
    FORMAL / "manifest.final.sha256.json": "449ac52f3d16b8ae8b390f7a73f1a170b80d9a78d5b231ba8c403d01fc793702",
    AUDIT / "manifest.final.sha256.json": "27dd37dc549c3fc28125aa9b63cd6059c7f7d5834d08baa8ad2651bc5d2cb8c9",
    AUDIT / "verification.json": "46732ee62f94f74526f2a5159559af4b1ae3712785aaa42a0bfa807b61371308",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for name, value in pairs:
        if name in result:
            raise ValueError(f"duplicate JSON key: {name}")
        result[name] = value
    return result


def _constant(value: str) -> None:
    raise ValueError(f"non-finite JSON constant: {value}")


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=_object, parse_constant=_constant)
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def regular_path(path: Path, root: Path) -> Path:
    candidate = path if path.is_absolute() else root / path
    if ".." in candidate.parts:
        raise ValueError(f"parent traversal is forbidden: {path}")
    base = root.resolve()
    candidate.resolve().relative_to(base)
    current = candidate
    while current != base:
        if current.is_symlink() or (
            current.exists() and getattr(current, "is_junction", lambda: False)()
        ):
            raise ValueError(f"linked path is forbidden: {current}")
        if current.parent == current:
            raise ValueError(f"path is outside the expected root: {path}")
        current = current.parent
    if not candidate.is_file():
        raise FileNotFoundError(candidate)
    return candidate


def file_record(path: Path) -> dict[str, Any]:
    with path.open("rb") as handle:
        digest = hashlib.file_digest(handle, "sha256").hexdigest()
    return {"sha256": digest, "size_bytes": path.stat().st_size}


def verify_file(path: Path, expected: Mapping[str, Any], *, root: Path = ROOT) -> dict[str, Any]:
    source = regular_path(path, root)
    actual = file_record(source)
    if actual["sha256"] != expected["sha256"] or (
        "size_bytes" in expected and actual["size_bytes"] != expected["size_bytes"]
    ):
        raise RuntimeError(f"file fingerprint mismatch: {source}")
    return {"path": source.relative_to(root).as_posix(), **actual}


def verify_source_records(
    root: Path, bindings: Mapping[str, Any], digests: Mapping[str, str]
) -> dict[str, Any]:
    if len(digests) != 13 or not set(digests).issubset(bindings):
        raise RuntimeError("parent production source member set changed")
    verified = {}
    for name, digest in sorted(digests.items()):
        record = bindings[name]
        if record["sha256"] != digest:
            raise RuntimeError(f"parent admission has inconsistent source binding: {name}")
        verified[name] = verify_file(Path(record["path"]), record, root=root)
    return verified


def preexecution_source_check() -> dict[str, Any]:
    """Run before importing any hydrology implementation, even on a denied entry."""
    anchors = {
        path.as_posix(): verify_file(path, {"sha256": PINNED[path]})
        for path in (SCIENCE, PARENT_ADMISSION, STAGE_ADMISSION)
    }
    science = read_json(ROOT / SCIENCE)
    parent_record = science["lineage"]["completed_parent_evidence"]["formal_evaluation_admission"]
    verify_file(PARENT_ADMISSION, parent_record)
    parent = read_json(ROOT / PARENT_ADMISSION)
    sources = verify_source_records(ROOT, parent["bindings"], parent["production_source_sha256"])
    stage = read_json(ROOT / STAGE_ADMISSION)
    implementation = {
        path: verify_file(Path(path), record)
        for path, record in stage["implementation_files"].items()
    }
    authorization = Path("hpc/tukf09_455_state_scale_generation_execution_authorization_v1.json")
    verify_file(authorization, {"sha256": stage["execution_authorization_sha256"]})
    auth = read_json(ROOT / authorization)
    for record in auth["prior_gate_bindings"].values():
        verify_file(Path(record["path"]), record)
    base_admission = read_json(ROOT / auth["prior_gate_bindings"]["base_implementation_admission"]["path"])
    for path, record in base_admission["implementation_files"].items():
        implementation[path] = verify_file(Path(path), record)
    return {
        "checked_at_utc": utc_now(), "parent_admission": anchors[PARENT_ADMISSION.as_posix()],
        "source_count": len(sources), "production_sources": sources,
        "original_implementation_files": implementation, "anchors": anchors,
        "mismatch_count": 0, "model_import_or_execution_performed": False,
    }


def verify_tree(directory: Path, expected_digest: str, expected_status: str) -> dict[str, Any]:
    manifest_path = directory / "manifest.final.sha256.json"
    manifest_record = verify_file(manifest_path, {"sha256": expected_digest})
    manifest = read_json(manifest_path)
    if manifest.get("experiment_id") != EXPERIMENT_ID or manifest.get("stage_id") != STAGE_ID:
        raise RuntimeError("result manifest experiment or stage mismatch")
    if manifest.get("status") != expected_status:
        raise RuntimeError("result manifest status mismatch")
    files = manifest.get("files", {})
    actual = {p.relative_to(directory).as_posix() for p in directory.rglob("*") if p.is_file() and p != manifest_path}
    if set(files) != actual or manifest.get("file_count") != len(actual):
        raise RuntimeError("result manifest member set mismatch")
    for relative, record in files.items():
        verify_file(directory / relative, record, root=directory)
    return {**manifest_record, "verified_member_count": len(files)}


def load_repair_admission() -> dict[str, Any]:
    admission = read_json(ROOT / REPAIR_ADMISSION)
    if admission.get("status") != "PROVENANCE_REPAIR_TESTED_NO_SCIENTIFIC_EXECUTION":
        raise PermissionError("provenance repair admission is not ready")
    if admission.get("experiment_id") != EXPERIMENT_ID or admission.get("stage_id") != STAGE_ID:
        raise PermissionError("provenance repair identity changed")
    if admission.get("model_execution_authorized") is not False:
        raise PermissionError("this repair does not authorize model execution")
    if set(admission.get("implementation_files", {})) != set(SOURCE_FILES):
        raise RuntimeError("provenance repair source set changed")
    for path, record in admission["implementation_files"].items():
        verify_file(Path(path), record)
    report = admission["test_report"]
    source = ROOT / report["path"]
    verify_file(source, report)
    suites = ET.parse(source).getroot()
    cases = list(suites.iter("testcase"))
    if len(cases) != report["tests"] or not cases or any(
        list(case.iter(tag)) for case in cases for tag in ("failure", "error", "skipped")
    ):
        raise RuntimeError("provenance repair tests are incomplete or failing")
    return admission


def collect_existing_evidence(source_check: Mapping[str, Any]) -> dict[str, Any]:
    formal = verify_tree(
        ROOT / FORMAL, PINNED[FORMAL / "manifest.final.sha256.json"],
        "FORMAL_455_BASIN_TRAINING_STATE_SCALES_SEALED_LATER_STAGES_HOLD",
    )
    audit = verify_tree(
        ROOT / AUDIT, PINNED[AUDIT / "manifest.final.sha256.json"],
        "ALL_455_FORMAL_TRAINING_STATE_SCALES_INDEPENDENTLY_VERIFIED_LATER_STAGES_HOLD",
    )
    report_record = verify_file(AUDIT / "verification.json", {"sha256": PINNED[AUDIT / "verification.json"]})
    report = read_json(ROOT / AUDIT / "verification.json")
    registry = read_json(ROOT / FORMAL / "scale_registry.json")
    summary = read_json(ROOT / FORMAL / "run_summary.json")
    science = read_json(ROOT / SCIENCE)
    population_record = science["lineage"]["input_seals"]["population_registry"]
    verify_file(Path(population_record["path"]), population_record)
    basins = read_json(ROOT / population_record["path"])["eligible"]
    order_digest = hashlib.sha256("".join(f"{b}\n" for b in basins).encode()).hexdigest()
    if (
        len(basins) != 455 or len(set(basins)) != 455
        or order_digest != science["population"]["basin_order_newline_utf8_sha256"]
        or [u["basin_id"] for u in registry["units"]] != basins
        or [u["basin_id"] for u in report["basins"]] != basins
        or report["mismatch_count"] != 0 or report["recomputed_trajectory_model_steps"] != 1163435
        or report["trajectory_max_abs_difference"] != 0 or report["state_scale_max_abs_difference"] != 0
        or summary["basin_count"] != 455 or summary["total_trajectory_model_steps"] != 1163435
    ):
        raise RuntimeError("saved formal and independent evidence do not agree")
    for name in ("validation_array_reads", "evaluation_array_reads", "discharge_observation_array_reads", "local_noise_optimization_updates"):
        if report.get(name) != 0 or summary.get(name) != 0:
            raise RuntimeError(f"saved evidence scope changed: {name}")
    return {
        "schema_version": "tukf09_455_state_scale_provenance_supplement_v2",
        "experiment_id": EXPERIMENT_ID, "stage_id": STAGE_ID,
        "status": "EXISTING_STATE_SCALE_EVIDENCE_BOUND_NO_MODEL_RERUN",
        "observed_at_utc": utc_now(),
        "source_formal_manifest": formal, "source_independent_manifest": audit,
        "source_independent_report": report_record,
        "source_scale_registry": {"path": (FORMAL / "scale_registry.json").as_posix(), **file_record(ROOT / FORMAL / "scale_registry.json")},
        "source_run_summary": {"path": (FORMAL / "run_summary.json").as_posix(), **file_record(ROOT / FORMAL / "run_summary.json")},
        "source_check_observed_now": dict(source_check),
        "historical_replay": {
            "verified_at_utc": report["verified_at_utc"], "basin_count": len(basins),
            "model_steps": report["recomputed_trajectory_model_steps"], "mismatch_count": report["mismatch_count"],
        },
        "evidence_limits": {
            "current_source_bytes_match_frozen_parent": True,
            "historical_runtime_source_guard_was_present": False,
            "historical_runtime_bytes_proven_by_this_supplement": False,
            "new_numerical_replay_performed": False,
            "original_verifier_shares_frozen_model_and_initial_state_helpers": True,
            "meaning": "retrospective artifact binding and current source verification; not a replacement or backdated runtime receipt",
        },
        "this_operation": {"model_runs": 0, "noise_updates": 0, "evaluation_runs": 0, "raw_data_arrays_loaded": 0},
        "later_stages_authorized": False,
    }


def write_json_exclusive(path: Path, payload: Mapping[str, Any]) -> None:
    raw = (json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")
    with path.open("xb") as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())


def publish_supplement() -> dict[str, Any]:
    admission = load_repair_admission()
    sources = preexecution_source_check()
    evidence = collect_existing_evidence(sources)
    output = ROOT / SUPPLEMENT
    output.resolve().relative_to((ROOT / RESULTS / "control").resolve())
    if output.exists() or output.is_symlink():
        raise FileExistsError(f"supplement already exists; preserve it: {output}")
    evidence["repair_admission"] = {"path": REPAIR_ADMISSION.as_posix(), **file_record(ROOT / REPAIR_ADMISSION)}
    evidence["repair_implementation_files"] = admission["implementation_files"]
    evidence["test_report"] = admission["test_report"]
    output.mkdir(exist_ok=False)
    try:
        write_json_exclusive(output / "verification_binding.json", evidence)
        # Check again before publishing the success seal, without recomputing trajectories.
        preexecution_source_check()
        for key in ("source_formal_manifest", "source_independent_manifest", "source_independent_report"):
            verify_file(Path(evidence[key]["path"]), evidence[key])
        manifest = {
            "schema_version": "tukf09_455_state_scale_provenance_supplement_manifest_v2",
            "experiment_id": EXPERIMENT_ID, "stage_id": STAGE_ID,
            "status": evidence["status"], "file_count": 1,
            "files": {"verification_binding.json": file_record(output / "verification_binding.json")},
        }
        write_json_exclusive(output / "manifest.final.sha256.json", manifest)
    except BaseException as exc:
        failure = {"status": "PROVENANCE_SUPPLEMENT_FAILED", "failed_at_utc": utc_now(), "error": str(exc), "automatic_retry_permitted": False}
        write_json_exclusive(output / "failure.json", failure)
        raise
    return {"status": evidence["status"], "source_files_checked": sources["source_count"],
            "formal_manifest_members_verified": evidence["source_formal_manifest"]["verified_member_count"],
            "independent_manifest_members_verified": evidence["source_independent_manifest"]["verified_member_count"],
            "supplement_manifest": {"path": (SUPPLEMENT / "manifest.final.sha256.json").as_posix(), **file_record(output / "manifest.final.sha256.json")},
            "model_runs": 0}
