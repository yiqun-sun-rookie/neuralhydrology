"""Contract-gated helpers for the formal 455-basin state-scale stage."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from hashlib import sha256
import json
import math
from pathlib import Path, PurePosixPath
import platform
import sys
from typing import Any, Callable, Mapping, Sequence

import numpy as np
import psutil
import torch


ROOT = Path(__file__).resolve().parents[1]
for _extra in (str(ROOT), str(ROOT / "src"), str(ROOT / "hpc")):
    if _extra not in sys.path:
        sys.path.insert(0, _extra)

import tukf09_455_scaled_noise_common_v1 as base  # noqa: E402
from scripts import tukf09_455_training_common as revision_training_common  # noqa: E402
from scripts import tukf09_training_common as parent_training_common  # noqa: E402
from scripts.tukf09_confirmatory_common import (  # noqa: E402
    PARAMETER_NAMES,
    default_routed_initial_state,
    routed_state_dimension,
)
from global_hydrology.models.differentiable_hbv_lite import (  # noqa: E402
    PARAM_NAMES as MODEL_PARAMETER_NAMES,
    recession_half_weights,
)
from global_hydrology.models.hbvlite_system_model import HBVLiteSystemModel  # noqa: E402


EXPERIMENT_ID = base.EXPERIMENT_ID
STAGE_ID = "TUKF09_455_STATE_SCALE_GENERATION_V1"
AUTHORIZATION = (
    ROOT / "hpc" / "tukf09_455_state_scale_generation_execution_authorization_v1.json"
)
ADMISSION = (
    ROOT / "hpc" / "tukf09_455_state_scale_generation_implementation_admission_v1.json"
)
SCALE_ROOT = base.RESULTS_ROOT / "state_scales_v1"
TEST_ROOT = base.RESULTS_ROOT / "control" / "state_scale_tests_v1"
INDEPENDENT_ROOT = base.RESULTS_ROOT / "control" / "state_scale_independent_v1"
SOURCE_FILES = (
    "hpc/tukf09_455_state_scale_generation_common_v1.py",
    "hpc/run_tukf09_455_state_scale_generation_v1.py",
    "hpc/verify_tukf09_455_state_scale_generation_v1.py",
    "hpc/test_tukf09_455_state_scale_generation_v1.py",
)
EXPECTED_TRAINING_START = "1999-10-01"
EXPECTED_TRAINING_END = "2006-09-30"
EXPECTED_TRAINING_DAYS = 2557
EXPECTED_SCALE_SLICE = (365, 2557)
EXPECTED_SCALE_SAMPLES = 2192


@dataclass(frozen=True)
class TrainingForcing:
    basin_id: str
    dates_ns: np.ndarray
    forcing: np.ndarray
    raw_relative_path: str
    raw_record: Mapping[str, Any]
    dates_semantic_record: Mapping[str, Any]
    forcing_semantic_record: Mapping[str, Any]


@dataclass(frozen=True)
class OpenLoopContext:
    basin_id: str
    plain_model: HBVLiteSystemModel
    initial_state: torch.Tensor
    parameters: torch.Tensor
    project_mean: Callable[[torch.Tensor], torch.Tensor]
    dimension: int


def _ordered_newline_sha256(values: Sequence[str]) -> str:
    return sha256("".join(f"{value}\n" for value in values).encode("utf-8")).hexdigest()


def _record_for_relative(relative: str) -> dict[str, Any]:
    return base.file_record(ROOT / relative)


def load_authorization() -> dict[str, Any]:
    authorization = base.read_json_strict(AUTHORIZATION)
    if (
        authorization.get("schema_version")
        != "tukf09_455_state_scale_generation_execution_authorization_v1"
        or authorization.get("experiment_id") != EXPERIMENT_ID
        or authorization.get("stage_id") != STAGE_ID
        or authorization.get("status")
        != "LOCAL_455_BASIN_TRAINING_STATE_SCALE_GENERATION_AND_INDEPENDENT_RECOMPUTATION_AUTHORIZED_LATER_STAGES_HOLD"
    ):
        raise PermissionError("state-scale authorization identity or status changed")
    base.verify_file_binding(
        base.SCIENCE_CONTRACT,
        authorization["scientific_contract"],
        label="state-scale scientific contract",
    )
    base.verify_file_binding(
        base.HUMAN_CONTRACT,
        authorization["human_contract"],
        label="state-scale human contract",
    )
    for name, record in authorization["prior_gate_bindings"].items():
        base.verify_file_binding(ROOT / record["path"], record, label=f"prior gate {name}")
    base.load_implementation_admission()

    verification = base.read_json_strict(
        ROOT
        / authorization["prior_gate_bindings"]["independent_probe_verification"]["path"]
    )
    if (
        verification.get("status")
        != "AUTHORIZED_EVIDENCE_INDEPENDENTLY_VERIFIED_AFTER_VERIFIER_ORDER_REPAIR_FORMAL_HOLD"
        or int(verification.get("mismatch_count", -1)) != 0
        or int(verification.get("evaluation_access_count", -1)) != 0
        or verification.get("formal_experiment_authorized") is not False
    ):
        raise PermissionError("prior independent probe verification is not sealed and passing")

    scope = authorization.get("authorization_scope", {})
    required_true = (
        "state_scale_stage_implementation",
        "state_scale_stage_automated_tests",
        "formal_training_state_scale_generation_for_exactly_455_basins",
        "independent_recomputation_of_all_455_state_scales",
    )
    required_false = (
        "formal_local_noise_optimization_or_checkpoint_selection",
        "formal_local_selection_sealing",
        "formal_transfer_vector_build",
        "validation_array_access",
        "evaluation_array_access",
        "discharge_observation_array_access",
        "evaluation_prediction_generation",
        "evaluation_metric_or_bootstrap_computation",
        "remote_or_hpc_submission",
        "scientific_performance_claim",
    )
    if any(scope.get(name) is not True for name in required_true) or any(
        scope.get(name) is not False for name in required_false
    ):
        raise PermissionError("state-scale authorization scope widened or became incomplete")

    outputs = authorization["output_roots"]
    expected_outputs = {
        "formal_state_scales": SCALE_ROOT.relative_to(ROOT).as_posix(),
        "tests": TEST_ROOT.relative_to(ROOT).as_posix(),
        "independent_verification": INDEPENDENT_ROOT.relative_to(ROOT).as_posix(),
    }
    if outputs != expected_outputs:
        raise PermissionError("state-scale output roots changed")
    budget = authorization["formal_scale_budget"]
    expected_budget = {
        "basin_count": 455,
        "training_days_per_basin": 2557,
        "total_basin_day_model_steps": 1163435,
        "scale_slice_start_zero_based_inclusive": 365,
        "scale_slice_stop_zero_based_exclusive": 2557,
        "scale_samples_per_state": 2192,
        "model_trajectory_count": 455,
        "validation_array_reads": 0,
        "evaluation_array_reads": 0,
        "discharge_observation_array_reads": 0,
        "local_noise_optimization_updates": 0,
        "wall_seconds": 3600,
        "maximum_process_rss_bytes": 4294967296,
        "maximum_stage_output_bytes": 2147483648,
    }
    if budget != expected_budget:
        raise PermissionError("formal state-scale budget changed")
    return authorization


def load_implementation_admission() -> dict[str, Any]:
    authorization = load_authorization()
    admission = base.read_json_strict(ADMISSION)
    if (
        admission.get("schema_version")
        != "tukf09_455_state_scale_generation_implementation_admission_v1"
        or admission.get("experiment_id") != EXPERIMENT_ID
        or admission.get("stage_id") != STAGE_ID
        or admission.get("status")
        != "STATE_SCALE_IMPLEMENTATION_AND_TESTS_ADMITTED_LATER_STAGES_HOLD"
    ):
        raise PermissionError("state-scale implementation admission identity changed")
    if admission.get("scientific_contract_sha256") != base.sha256_file(base.SCIENCE_CONTRACT):
        raise PermissionError("state-scale admission scientific-contract binding changed")
    if admission.get("execution_authorization_sha256") != base.sha256_file(AUTHORIZATION):
        raise PermissionError("state-scale admission authorization binding changed")
    records = admission.get("implementation_files")
    if not isinstance(records, dict) or set(records) != set(SOURCE_FILES):
        raise PermissionError("state-scale admitted source member set changed")
    for relative, record in records.items():
        base.verify_file_binding(
            ROOT / relative,
            record,
            label=f"admitted state-scale implementation {relative}",
        )
    report = admission.get("test_report")
    if not isinstance(report, dict):
        raise PermissionError("state-scale admission lacks test evidence")
    base.verify_file_binding(ROOT / report["path"], report, label="state-scale test report")
    if (
        int(report.get("tests", 0)) < 1
        or int(report.get("failed", -1)) != 0
        or int(report.get("errors", -1)) != 0
        or int(report.get("skipped", -1)) != 0
    ):
        raise PermissionError("state-scale admitted tests are not completely passing")
    if admission.get("later_stages_authorized") is not False:
        raise PermissionError("state-scale admission unexpectedly authorizes a later stage")
    return admission


def configure_single_thread_execution() -> dict[str, int]:
    torch.set_num_threads(1)
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        if torch.get_num_interop_threads() != 1:
            raise
    return {
        "torch_intraop_threads": int(torch.get_num_threads()),
        "torch_interop_threads": int(torch.get_num_interop_threads()),
    }


def runtime_identity() -> dict[str, Any]:
    return {
        "python_executable": Path(sys.executable).resolve().as_posix(),
        "python_version": platform.python_version(),
        "numpy_version": np.__version__,
        "torch_version": torch.__version__,
        "psutil_version": psutil.__version__,
        "platform": platform.platform(),
        "processor": platform.processor(),
        "device": "cpu",
        "precision": "float64",
        "process_count": 1,
        "torch_intraop_threads": int(torch.get_num_threads()),
        "torch_interop_threads": int(torch.get_num_interop_threads()),
    }


def verify_runtime(authorization: Mapping[str, Any]) -> dict[str, Any]:
    actual = runtime_identity()
    expected = dict(authorization["runtime_environment"])
    expected.pop("execution_host", None)
    expected["python_executable"] = Path(expected["python_executable"]).resolve().as_posix()
    if actual != expected:
        raise RuntimeError(f"state-scale runtime identity changed: {actual!r}")
    return actual


def load_parent_context_and_frozen_inputs() -> tuple[Any, base.FrozenInputs]:
    context = revision_training_common.verify_preflight_for_revision_training(
        base.PARENT_CONFIG,
        base.PARENT_PREFLIGHT_FINAL,
        base.PARENT_AUTHORIZATION,
        base.PARENT_RESULTS_ROOT,
        require_output_absent=False,
        recompute_training_validation_semantics=False,
        verify_all_raw_source_bytes=False,
    )
    frozen = base.load_frozen_inputs()
    if (
        int(context.evaluation_access_count) != 0
        or tuple(str(value) for value in context.ordered_basin_ids) != frozen.basin_ids
        or tuple(str(value) for value in context.parameter_names) != frozen.parameter_names
        or not np.array_equal(
            np.asarray(context.parameter_values, dtype=np.float64), frozen.parameter_values
        )
    ):
        raise RuntimeError("parent training context differs from frozen state-scale inputs")
    period = context.periods.get("training")
    if (
        period is None
        or str(period.start_date) != EXPECTED_TRAINING_START
        or str(period.end_date) != EXPECTED_TRAINING_END
        or int(period.day_count) != EXPECTED_TRAINING_DAYS
        or int(period.first_scoring_index) != EXPECTED_SCALE_SLICE[0]
    ):
        raise RuntimeError("frozen training period identity changed")
    return context, frozen


def _training_dates_ns(start_date: str, end_date: str, day_count: int) -> np.ndarray:
    values = np.arange(
        np.datetime64(start_date, "D"),
        np.datetime64(end_date, "D") + np.timedelta64(1, "D"),
        dtype="datetime64[D]",
    ).astype("datetime64[ns]")
    result = np.ascontiguousarray(values.view("<i8"), dtype=np.dtype("<i8"))
    if result.shape != (int(day_count),) or np.any(result[1:] <= result[:-1]):
        raise RuntimeError("training date construction changed")
    return result


def parse_training_forcing_file(
    path: Path,
    *,
    start_date: str,
    end_date: str,
    day_count: int,
) -> np.ndarray:
    start_ordinal = date.fromisoformat(start_date).toordinal()
    end_ordinal = date.fromisoformat(end_date).toordinal()
    if end_ordinal - start_ordinal + 1 != int(day_count):
        raise ValueError("training forcing period day count changed")
    raw = np.empty((int(day_count), 5), dtype=np.float64)
    counts = np.zeros(int(day_count), dtype=np.int16)
    prior_selected: int | None = None
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            fields = line.split()
            if len(fields) < 3:
                continue
            try:
                ordinal = date(int(fields[0]), int(fields[1]), int(fields[2])).toordinal()
            except (TypeError, ValueError):
                continue
            if ordinal < start_ordinal:
                continue
            if ordinal > end_ordinal:
                break
            if len(fields) < 10:
                raise ValueError(f"training forcing row is incomplete: {path}")
            if prior_selected is not None and ordinal <= prior_selected:
                raise ValueError(f"training forcing dates are not strictly increasing: {path}")
            prior_selected = ordinal
            index = ordinal - start_ordinal
            counts[index] += 1
            row = tuple(float(fields[position]) for position in (4, 5, 6, 8, 9))
            if not all(math.isfinite(value) for value in row):
                raise ValueError(f"training forcing contains a non-finite value: {path}")
            raw[index] = row
    if not np.all(counts == 1):
        raise ValueError(f"training forcing support is incomplete or duplicated: {path}")
    day_length = raw[:, 0]
    precipitation = raw[:, 1]
    shortwave = raw[:, 2]
    mean_temperature = (raw[:, 3] + raw[:, 4]) / 2.0
    shortwave_megajoule = shortwave * day_length / 1.0e6
    potential_evapotranspiration = np.where(
        mean_temperature > -5.0,
        shortwave_megajoule * (mean_temperature + 5.0) / 245.0,
        0.0,
    )
    forcing = np.ascontiguousarray(
        np.stack(
            [precipitation, mean_temperature, np.maximum(potential_evapotranspiration, 0.0)],
            axis=-1,
        ),
        dtype=np.dtype("<f8"),
    )
    if forcing.shape != (int(day_count), 3) or not np.isfinite(forcing).all():
        raise ValueError(f"derived training forcing is invalid: {path}")
    return forcing


def _forcing_source_record(parent_context: Any, basin_id: str) -> tuple[str, Mapping[str, Any]]:
    matches = [
        (str(relative), record)
        for relative, record in parent_context.raw_source_files.items()
        if str(relative).startswith("basin_mean_forcing/maurer/")
        and PurePosixPath(str(relative)).name.startswith(str(basin_id))
    ]
    if len(matches) != 1:
        raise RuntimeError(f"sealed training forcing source count changed for {basin_id}")
    return matches[0]


def load_training_forcing(parent_context: Any, basin_id: str) -> TrainingForcing:
    if int(parent_context.evaluation_access_count) != 0:
        raise PermissionError("parent context recorded evaluation access")
    period = parent_context.periods["training"]
    relative, raw_record = _forcing_source_record(parent_context, basin_id)
    path = parent_training_common.require_regular_unlinked_file(
        parent_context.data_root.joinpath(*PurePosixPath(relative).parts),
        label="sealed state-scale training forcing",
        stop_at=parent_context.data_root,
    )
    if (
        path.stat().st_size != int(raw_record["size_bytes"])
        or base.sha256_file(path) != raw_record["sha256"]
    ):
        raise RuntimeError(f"sealed state-scale forcing bytes changed for {basin_id}")
    dates_ns = _training_dates_ns(period.start_date, period.end_date, period.day_count)
    forcing = parse_training_forcing_file(
        path,
        start_date=period.start_date,
        end_date=period.end_date,
        day_count=period.day_count,
    )
    actual_dates = parent_training_common.semantic_array_identity(
        f"{basin_id}/training/dates_ns", dates_ns, "<i8"
    )
    actual_forcing = parent_training_common.semantic_array_identity(
        f"{basin_id}/training/forcing", forcing, "<f8"
    )
    expected_dates = parent_context.semantic_members["training"].get(
        f"{basin_id}/dates_ns"
    )
    expected_forcing = parent_context.semantic_members["training"].get(
        f"{basin_id}/forcing"
    )
    if actual_dates != expected_dates or actual_forcing != expected_forcing:
        raise RuntimeError(f"training forcing semantic identity changed for {basin_id}")
    dates_ns.setflags(write=False)
    forcing.setflags(write=False)
    return TrainingForcing(
        basin_id=str(basin_id),
        dates_ns=dates_ns,
        forcing=forcing,
        raw_relative_path=relative,
        raw_record=dict(raw_record),
        dates_semantic_record=dict(actual_dates),
        forcing_semantic_record=dict(actual_forcing),
    )


def build_open_loop_context(
    basin_id: str,
    parameter_row: Mapping[str, float],
    parent_contract: Mapping[str, Any],
) -> OpenLoopContext:
    basin = str(basin_id)
    if len(basin) != 8 or not basin.isascii() or not basin.isdigit():
        raise ValueError(f"invalid basin identifier: {basin_id!r}")
    if tuple(MODEL_PARAMETER_NAMES) != tuple(PARAMETER_NAMES):
        raise RuntimeError("HBV-light parameter order changed")
    if set(parameter_row) != set(PARAMETER_NAMES):
        raise ValueError("open-loop parameter member set changed")
    values = np.asarray([parameter_row[name] for name in PARAMETER_NAMES], dtype=np.float64)
    if values.shape != (13,) or not np.isfinite(values).all():
        raise ValueError("open-loop parameters are non-finite or incomplete")
    parameters = torch.tensor(values.reshape(1, -1), dtype=torch.float64, device="cpu")
    dimension = int(routed_state_dimension(parameter_row))
    weights = recession_half_weights(parameters[:, -1:], dimension - 5)
    model = HBVLiteSystemModel(
        parameters,
        emission="routed",
        lag_weights=weights,
        device=torch.device("cpu"),
        dtype=torch.float64,
    )
    field_capacity = parameters[:, PARAMETER_NAMES.index("parFC")]

    def project_mean(state: torch.Tensor) -> torch.Tensor:
        storages = torch.clamp(state[:, :5], min=0.0)
        soil = torch.clamp(storages[:, 2:3], max=field_capacity)
        routing = torch.clamp(state[:, 5:], min=0.0)
        return torch.cat([storages[:, :2], soil, storages[:, 3:5], routing], dim=-1)

    initialization = parent_contract["filter_system"]["initialization"]
    if (
        initialization.get("forbid_prior_x0_table") is not True
        or initialization.get("forbid_cal_final_2008_state_columns") is not True
        or float(initialization.get("initial_covariance_diagonal", -1.0)) != 0.001
    ):
        raise RuntimeError("frozen period-local initial-state policy changed")
    initial = torch.tensor(
        np.array(default_routed_initial_state(parameter_row), dtype=np.float64, copy=True),
        dtype=torch.float64,
        device="cpu",
    ).reshape(1, dimension)
    if initial.shape != (1, dimension) or not bool(torch.isfinite(initial).all()):
        raise RuntimeError(f"open-loop initial state is invalid for {basin}")
    return OpenLoopContext(
        basin_id=basin,
        plain_model=model,
        initial_state=initial,
        parameters=parameters,
        project_mean=project_mean,
        dimension=dimension,
    )


def deterministic_training_trajectory(
    context: OpenLoopContext,
    forcing: np.ndarray | torch.Tensor,
) -> tuple[np.ndarray, np.ndarray]:
    values = torch.as_tensor(np.asarray(forcing).copy(), dtype=torch.float64, device="cpu")
    if values.shape != (EXPECTED_TRAINING_DAYS, 3):
        raise ValueError("formal state-scale forcing shape changed")
    state = context.initial_state.detach().clone()
    initial = state[0].cpu().numpy().astype(np.float64, copy=True)
    trajectory = np.empty((EXPECTED_TRAINING_DAYS, context.dimension), dtype=np.float64)
    with torch.no_grad():
        for day in range(EXPECTED_TRAINING_DAYS):
            state = context.plain_model.f(state, values[day])
            state = context.project_mean(state)
            if state.shape != (1, context.dimension) or not bool(torch.isfinite(state).all()):
                raise FloatingPointError(
                    f"deterministic state-scale trajectory failed for {context.basin_id} at day {day}"
                )
            trajectory[day] = state[0].cpu().numpy()
    if not np.isfinite(trajectory).all():
        raise FloatingPointError(f"non-finite state-scale trajectory for {context.basin_id}")
    return initial, np.ascontiguousarray(trajectory, dtype=np.float64)


def compute_state_scale_artifacts(
    trajectory: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, tuple[str, ...], tuple[str, ...]]:
    values = np.asarray(trajectory, dtype=np.float64)
    if values.ndim != 2 or values.shape[0] != EXPECTED_TRAINING_DAYS or values.shape[1] < 6:
        raise ValueError("formal state-scale trajectory shape changed")
    selected = values[EXPECTED_SCALE_SLICE[0] : EXPECTED_SCALE_SLICE[1]]
    if selected.shape != (EXPECTED_SCALE_SAMPLES, values.shape[1]):
        raise RuntimeError("formal state-scale slice changed")
    raw = np.sqrt(np.mean(np.square(selected), axis=0, dtype=np.float64))
    floor = np.full(values.shape[1], 0.01, dtype=np.float64)
    scale = np.maximum(raw, floor)
    hit = raw <= floor
    if not np.isfinite(raw).all() or not np.isfinite(scale).all() or np.any(scale < floor):
        raise FloatingPointError("formal state-scale calculation is invalid")
    names = tuple(base.PHYSICAL_STATE_NAMES) + tuple(
        f"unrouted_runoff_lag_{index}_days" for index in range(values.shape[1] - 5)
    )
    units = tuple(["millimetre"] * 5 + ["millimetre_per_day"] * (values.shape[1] - 5))
    return (
        np.ascontiguousarray(raw, dtype=np.float64),
        np.ascontiguousarray(scale, dtype=np.float64),
        np.ascontiguousarray(hit, dtype=np.bool_),
        names,
        units,
    )


def parameter_row_record(frozen: base.FrozenInputs, basin_id: str) -> dict[str, Any]:
    index = frozen.basin_ids.index(str(basin_id))
    values = np.asarray(frozen.parameter_values[index], dtype="<f8")
    digest = sha256()
    digest.update(json.dumps(list(frozen.parameter_names), separators=(",", ":")).encode("utf-8"))
    digest.update(values.tobytes(order="C"))
    return {
        "basin_index": index,
        "parameter_names": list(frozen.parameter_names),
        "values": values.tolist(),
        "sha256": digest.hexdigest(),
    }


def ensure_stage_output_path(path: Path, allowed_root: Path) -> Path:
    target = path.resolve()
    allowed = allowed_root.resolve()
    try:
        target.relative_to(allowed)
    except ValueError as exc:
        raise PermissionError(f"state-scale write escapes authorized root: {target}") from exc
    current = path.parent
    stop = base.RESULTS_ROOT.resolve()
    while True:
        if current.exists() and current.is_symlink():
            raise RuntimeError(f"linked state-scale output path is forbidden: {current}")
        if current.resolve() == stop:
            break
        if current.parent == current:
            raise PermissionError(f"state-scale output path does not descend from result root: {path}")
        current = current.parent
    return path


def build_tree_manifest(
    directory: Path,
    *,
    schema_version: str,
    status: str,
) -> dict[str, Any]:
    if not directory.is_dir() or directory.is_symlink():
        raise RuntimeError(f"manifest root must be one plain directory: {directory}")
    files: dict[str, dict[str, Any]] = {}
    for path in sorted(directory.rglob("*")):
        if path.is_symlink():
            raise RuntimeError(f"linked state-scale artifact is forbidden: {path}")
        if not path.is_file():
            continue
        relative = path.relative_to(directory).as_posix()
        if relative == "manifest.final.sha256.json":
            continue
        files[relative] = base.file_record(path)
    return {
        "schema_version": schema_version,
        "experiment_id": EXPERIMENT_ID,
        "stage_id": STAGE_ID,
        "status": status,
        "file_count": len(files),
        "files": files,
    }


def verify_tree_manifest(
    directory: Path,
    *,
    expected_schema: str,
    expected_status: str,
) -> dict[str, Any]:
    manifest = base.read_json_strict(directory / "manifest.final.sha256.json")
    if (
        manifest.get("schema_version") != expected_schema
        or manifest.get("experiment_id") != EXPERIMENT_ID
        or manifest.get("stage_id") != STAGE_ID
        or manifest.get("status") != expected_status
    ):
        raise RuntimeError(f"state-scale manifest identity or status changed: {directory}")
    files = manifest.get("files")
    actual = {
        path.relative_to(directory).as_posix()
        for path in directory.rglob("*")
        if path.is_file() and path.relative_to(directory).as_posix() != "manifest.final.sha256.json"
    }
    if not isinstance(files, dict) or int(manifest.get("file_count", -1)) != len(files) or set(files) != actual:
        raise RuntimeError(f"state-scale manifest member set changed: {directory}")
    for relative, record in files.items():
        base.verify_file_binding(
            directory / relative,
            record,
            label=f"state-scale manifest member {relative}",
        )
    return manifest


def directory_file_bytes(directory: Path) -> int:
    return sum(path.stat().st_size for path in directory.rglob("*") if path.is_file())


def implementation_fingerprints(admission: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "stage_admission": {
            "path": ADMISSION.relative_to(ROOT).as_posix(),
            **base.file_record(ADMISSION),
        },
        "implementation_files": dict(admission["implementation_files"]),
    }


__all__ = [
    "ADMISSION",
    "AUTHORIZATION",
    "EXPECTED_SCALE_SAMPLES",
    "EXPECTED_SCALE_SLICE",
    "EXPECTED_TRAINING_DAYS",
    "EXPERIMENT_ID",
    "INDEPENDENT_ROOT",
    "OpenLoopContext",
    "ROOT",
    "SCALE_ROOT",
    "SOURCE_FILES",
    "STAGE_ID",
    "TEST_ROOT",
    "TrainingForcing",
    "base",
    "build_open_loop_context",
    "build_tree_manifest",
    "compute_state_scale_artifacts",
    "configure_single_thread_execution",
    "deterministic_training_trajectory",
    "directory_file_bytes",
    "ensure_stage_output_path",
    "implementation_fingerprints",
    "load_authorization",
    "load_implementation_admission",
    "load_parent_context_and_frozen_inputs",
    "load_training_forcing",
    "parameter_row_record",
    "parse_training_forcing_file",
    "runtime_identity",
    "verify_runtime",
    "verify_tree_manifest",
]
