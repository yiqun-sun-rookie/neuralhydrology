"""Tests for the isolated formal state-scale generation stage."""
from __future__ import annotations

import ast
import json
from pathlib import Path
import sys

import numpy as np
import pytest
import torch


ROOT = Path(__file__).resolve().parents[1]
for _extra in (str(ROOT), str(ROOT / "src"), str(ROOT / "hpc")):
    if _extra not in sys.path:
        sys.path.insert(0, _extra)

import tukf09_455_state_scale_generation_common_v1 as common  # noqa: E402


def test_authorization_opens_only_state_scale_stage() -> None:
    authorization = common.load_authorization()
    scope = authorization["authorization_scope"]
    assert scope["formal_training_state_scale_generation_for_exactly_455_basins"] is True
    assert scope["independent_recomputation_of_all_455_state_scales"] is True
    assert scope["formal_local_noise_optimization_or_checkpoint_selection"] is False
    assert scope["formal_transfer_vector_build"] is False
    assert scope["validation_array_access"] is False
    assert scope["evaluation_array_access"] is False
    assert scope["discharge_observation_array_access"] is False
    assert scope["remote_or_hpc_submission"] is False


def test_authorized_budget_and_output_roots_are_exact() -> None:
    authorization = common.load_authorization()
    budget = authorization["formal_scale_budget"]
    assert budget["basin_count"] == 455
    assert budget["training_days_per_basin"] == 2557
    assert budget["total_basin_day_model_steps"] == 1_163_435
    assert budget["scale_samples_per_state"] == 2192
    assert budget["local_noise_optimization_updates"] == 0
    assert authorization["output_roots"]["formal_state_scales"] == common.SCALE_ROOT.relative_to(ROOT).as_posix()
    assert not common.SCALE_ROOT.exists()
    assert not common.INDEPENDENT_ROOT.exists()


def test_frozen_population_and_dimensions_remain_exact() -> None:
    frozen = common.base.load_frozen_inputs()
    assert len(frozen.basin_ids) == 455
    assert frozen.parameter_values.shape == (455, 13)
    counts: dict[int, int] = {}
    for value in frozen.dimension_by_basin.values():
        counts[value] = counts.get(value, 0) + 1
    assert counts == {7: 312, 8: 61, 9: 25, 10: 7, 11: 11, 12: 10, 13: 6, 15: 3, 17: 3, 18: 3, 20: 14}


def _forcing_line(day: int, *, temperature_low: float, temperature_high: float) -> str:
    return f"2000 1 {day} 0 86400 2 100 0 {temperature_high} {temperature_low}\n"


def test_training_forcing_parser_uses_only_requested_dates(tmp_path: Path) -> None:
    path = tmp_path / "forcing.txt"
    path.write_text(
        "1999 12 31 0 86400 999 999 0 999 999\n"
        + _forcing_line(1, temperature_low=0.0, temperature_high=10.0)
        + _forcing_line(2, temperature_low=-7.0, temperature_high=-5.0)
        + "2000 1 3 0 86400 nan nan 0 nan nan\n",
        encoding="utf-8",
    )
    forcing = common.parse_training_forcing_file(
        path, start_date="2000-01-01", end_date="2000-01-02", day_count=2
    )
    expected_pet = (100.0 * 86400.0 / 1.0e6) * 10.0 / 245.0
    assert forcing.shape == (2, 3)
    assert np.array_equal(forcing[:, :2], np.array([[2.0, 5.0], [2.0, -6.0]]))
    assert forcing[0, 2] == pytest.approx(expected_pet, rel=0.0, abs=1e-15)
    assert forcing[1, 2] == 0.0


@pytest.mark.parametrize(
    "content,match",
    [
        (_forcing_line(1, temperature_low=0.0, temperature_high=0.0), "incomplete or duplicated"),
        (
            _forcing_line(1, temperature_low=0.0, temperature_high=0.0)
            + _forcing_line(1, temperature_low=0.0, temperature_high=0.0)
            + _forcing_line(2, temperature_low=0.0, temperature_high=0.0),
            "not strictly increasing",
        ),
    ],
)
def test_training_forcing_parser_rejects_missing_or_duplicate_days(
    tmp_path: Path, content: str, match: str
) -> None:
    path = tmp_path / "bad_forcing.txt"
    path.write_text(content, encoding="utf-8")
    with pytest.raises(ValueError, match=match):
        common.parse_training_forcing_file(
            path, start_date="2000-01-01", end_date="2000-01-02", day_count=2
        )


def test_actual_training_forcing_hash_and_semantics_pass_without_observations() -> None:
    context, frozen = common.load_parent_context_and_frozen_inputs()
    basin_id = frozen.basin_ids[0]
    training = common.load_training_forcing(context, basin_id)
    assert training.dates_ns.shape == (2557,)
    assert training.forcing.shape == (2557, 3)
    assert training.dates_ns.flags.writeable is False
    assert training.forcing.flags.writeable is False
    assert context.evaluation_access_count == 0


def test_open_loop_context_has_no_observation_or_covariance_input() -> None:
    parent_context, frozen = common.load_parent_context_and_frozen_inputs()
    basin_id = frozen.basin_ids[0]
    context = common.build_open_loop_context(
        basin_id, frozen.parameter_row(basin_id), parent_context.contract
    )
    assert context.dimension == frozen.dimension_by_basin[basin_id]
    assert not hasattr(context, "base_observation_variance")
    assert not hasattr(context, "initial_covariance")
    assert not hasattr(context, "adapter")


def test_deterministic_trajectory_saves_first_post_forcing_state() -> None:
    parent_context, frozen = common.load_parent_context_and_frozen_inputs()
    basin_id = frozen.basin_ids[0]
    context = common.build_open_loop_context(
        basin_id, frozen.parameter_row(basin_id), parent_context.contract
    )
    forcing = np.zeros((2557, 3), dtype=np.float64)
    with torch.no_grad():
        expected_first = context.project_mean(
            context.plain_model.f(
                context.initial_state.clone(), torch.zeros(3, dtype=torch.float64)
            )
        )[0].numpy()
    initial, trajectory = common.deterministic_training_trajectory(context, forcing)
    assert np.array_equal(initial, context.initial_state[0].numpy())
    assert np.array_equal(trajectory[0], expected_first)
    assert trajectory.shape == (2557, context.dimension)


def test_state_scale_formula_slice_floor_names_and_units() -> None:
    trajectory = np.zeros((2557, 7), dtype=np.float64)
    trajectory[365:, 0] = 2.0
    trajectory[365:, 5] = 0.005
    raw, scale, hit, names, units = common.compute_state_scale_artifacts(trajectory)
    assert raw[0] == 2.0
    assert scale[0] == 2.0
    assert hit[0] == np.bool_(False)
    assert raw[5] == pytest.approx(0.005, rel=0.0, abs=1e-15)
    assert scale[5] == 0.01
    assert hit[5] == np.bool_(True)
    assert names[:5] == common.base.PHYSICAL_STATE_NAMES
    assert names[5:] == ("unrouted_runoff_lag_0_days", "unrouted_runoff_lag_1_days")
    assert units[:5] == ("millimetre",) * 5
    assert units[5:] == ("millimetre_per_day",) * 2


def test_root_manifest_binds_nested_unit_manifest(tmp_path: Path) -> None:
    root = tmp_path / "root"
    unit = root / "basin_00000001"
    unit.mkdir(parents=True)
    (unit / "value.bin").write_bytes(b"value")
    (unit / "manifest.final.sha256.json").write_text("{}\n", encoding="utf-8")
    manifest = common.build_tree_manifest(
        root, schema_version="test_manifest_v1", status="PASS"
    )
    assert set(manifest["files"]) == {
        "basin_00000001/value.bin",
        "basin_00000001/manifest.final.sha256.json",
    }


def test_stage_path_rejects_writes_outside_authorized_subtree(tmp_path: Path) -> None:
    with pytest.raises(PermissionError, match="escapes"):
        common.ensure_stage_output_path(tmp_path / "outside", common.SCALE_ROOT)


def _called_attributes(path: Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    result: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            result.add(ast.unparse(node.func))
    return result


def test_formal_runner_has_no_training_validation_or_evaluation_loader() -> None:
    path = ROOT / "hpc" / "run_tukf09_455_state_scale_generation_v1.py"
    calls = _called_attributes(path)
    forbidden = {
        "parent_training_common.load_training_validation_periods",
        "common.base.load_selected_training_validation",
        "common.load_selected_training_validation",
    }
    assert calls.isdisjoint(forbidden)
    source = path.read_text(encoding="utf-8")
    assert "run_full_local_search(" not in source
    assert "run_one_update_probe(" not in source


def test_independent_verifier_does_not_call_generator_calculations() -> None:
    path = ROOT / "hpc" / "verify_tukf09_455_state_scale_generation_v1.py"
    calls = _called_attributes(path)
    forbidden = {
        "common.load_training_forcing",
        "common.build_open_loop_context",
        "common.deterministic_training_trajectory",
        "common.compute_state_scale_artifacts",
    }
    assert calls.isdisjoint(forbidden)


def test_parameter_row_fingerprint_is_stable_and_basin_specific() -> None:
    frozen = common.base.load_frozen_inputs()
    first = common.parameter_row_record(frozen, frozen.basin_ids[0])
    repeat = common.parameter_row_record(frozen, frozen.basin_ids[0])
    second = common.parameter_row_record(frozen, frozen.basin_ids[1])
    assert first == repeat
    assert first["sha256"] != second["sha256"]
    assert first["basin_index"] == 0


def test_execution_authorization_is_strict_json_and_has_no_duplicate_source_members() -> None:
    raw = common.AUTHORIZATION.read_text(encoding="utf-8")
    parsed = json.loads(raw)
    assert parsed["stage_id"] == common.STAGE_ID
    assert tuple(parsed["write_scope"]["source_files"]) == common.SOURCE_FILES
    assert len(set(parsed["write_scope"]["source_files"])) == len(common.SOURCE_FILES)
