"""Audited, explicitly authorized schema compatibility; no scientific changes.

This module verifies exact derivations of five successor entry points. The
original files and all 30 training-admitted executables remain untouched.
The producer payload hash excludes LF, while record/file hashes keep their frozen rules.
No dynamic patching, metadata rewriting, or evaluation-array loading occurs here.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
from typing import Any, Mapping
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
INCOMING = ROOT / "results/_incoming/tukf09_455_v2r14"
REVIEW = INCOMING / "compat_v3_repair_review.json"
TEST_XML = INCOMING / "compat_v3_tests.xml"
TEST_SOURCE = ROOT / "hpc/test_tukf09_455_evaluation_compat_v3.py"
PLAN = ROOT / "docs/plans/2026-09-16-tukf09-455-formal-evaluation-count-compatibility-v3.md"
SLUG = "tukf09_455_basin_zero_validation_target_variance_revision_v1"
AUTHORIZATION_RELATIVE = f"artifacts/{SLUG}/authorizations/formal_evaluation_authorization_compat_v3.json"
ADMISSION_RELATIVE = f"artifacts/{SLUG}/formal_evaluation_admission_compat_v3/formal_evaluation_admission.json"
PREDECESSOR_FILES = {
    f"artifacts/{SLUG}/authorizations/formal_evaluation_authorization.json": "eb0db6be17fb599740749311b00c39150e8dd33dcfe49e2386483b54d01d6adc",
    f"artifacts/{SLUG}/formal_evaluation_admission/formal_evaluation_admission.json": "d3d51de49d97c765ea33c154d192e148ea43a34c5511d32854bf292c78053b52",
    f"results/{SLUG}/control/formal_evaluation_attempt.json": "c1c5aaa9432204710c24aa1effff1a55f1fb074d450e85b95c70f29ea4a79287",
    f"results/{SLUG}/control/formal_evaluation_failure.json": "516afa3ce1b10ef3fdf4f3cf0213de62f5f0799a39b4ea2d200f1dc1028da8a0",
}
PATCHES = json.loads(r'''{
  "register_tukf09_455_formal_evaluation_authorization": {
    "sha256": "b8e32bc18a4e5b25b8a7e71d476ac45367ab882e899bf37b6cc207f666c85952",
    "edits": [
      [
        "import uuid\n",
        "import uuid\n\nfrom hpc import tukf09_455_evaluation_compat_v3 as compat\n",
        1
      ],
      [
        "    selection = documents[\"training_selection_seal\"]\n",
        "    selection = documents[\"training_selection_seal\"]\n    if production:\n        compat.validate_seal_counts(selection)\n",
        1
      ],
      [
        "selection, \"filter_selected_model_count\", \"filter_basin_units\"",
        "selection, \"filter_selected_model_count\", \"rebound_filter_units\"",
        1
      ],
      [
        "\"scripts/register_tukf09_455_formal_evaluation_authorization.py\": {",
        "\"hpc/register_tukf09_455_formal_evaluation_authorization_compat_v3.py\": {",
        1
      ],
      [
        "\"scripts/admit_tukf09_455_formal_evaluation.py\": {",
        "\"hpc/admit_tukf09_455_formal_evaluation_compat_v3.py\": {",
        1
      ],
      [
        "\"admit_tukf09_455_formal_evaluation.py\"",
        "\"admit_tukf09_455_formal_evaluation_compat_v3.py\"",
        3
      ],
      [
        "    result = dict(unsigned)\n",
        "    if production:\n        unsigned[\"compatibility_repair\"] = compat.authorized_repair()\n    result = dict(unsigned)\n",
        1
      ],
      [
        "\"scripts/evaluate_tukf09_455_basin_revision.py\"",
        "\"hpc/evaluate_tukf09_455_basin_revision_compat_v3.py\"",
        1
      ],
      [
        "\"scripts/verify_tukf09_455_basin_evaluation.py\"",
        "\"hpc/verify_tukf09_455_basin_evaluation_compat_v3.py\"",
        1
      ],
      [
        "_canonical_sha256(files)",
        "sha256(canonical_json_bytes(files)[:-1]).hexdigest()",
        3
      ],
      [
        "\"scripts/tukf09_455_evaluation_common.py\"",
        "\"hpc/tukf09_455_evaluation_common_compat_v3.py\"",
        1
      ],
      [
        "destination=root / expected_paths[\"authorization\"]",
        "destination=root / compat.AUTHORIZATION_RELATIVE",
        1
      ]
    ]
  },
  "admit_tukf09_455_formal_evaluation": {
    "sha256": "591d25f57cb1328d4da56d19177e0fdbefb8d052198982d746a311004078914f",
    "edits": [
      [
        "from scripts import register_tukf09_455_formal_evaluation_authorization as registration",
        "from hpc import register_tukf09_455_formal_evaluation_authorization_compat_v3 as registration\nfrom hpc import tukf09_455_evaluation_compat_v3 as compat",
        1
      ],
      [
        "    gate_bindings = authorization.get(\"gate_implementation_bindings\")",
        "    if production:\n        compat.verify_authorization(authorization)\n    gate_bindings = authorization.get(\"gate_implementation_bindings\")",
        1
      ],
      [
        "            \"scripts/register_tukf09_455_formal_evaluation_authorization.py\",\n            \"scripts/admit_tukf09_455_formal_evaluation.py\",",
        "            \"hpc/register_tukf09_455_formal_evaluation_authorization_compat_v3.py\",\n            \"hpc/admit_tukf09_455_formal_evaluation_compat_v3.py\",",
        1
      ],
      [
        "    documents = {\n",
        "    if authorization is not None:\n        compat.verify_authorization(authorization)\n    documents = {\n",
        1
      ],
      [
        "authorization_path = root / str(paths.get(\"authorization\"))",
        "authorization_path = root / compat.AUTHORIZATION_RELATIVE",
        1
      ],
      [
        "admission_path = root / str(paths.get(\"admission\"))",
        "admission_path = root / compat.ADMISSION_RELATIVE",
        1
      ]
    ]
  },
  "evaluate_tukf09_455_basin_revision": {
    "sha256": "9d0df7f8bcb9de9d17fa397ffdefaee254adce78ba478e97d23df11cea58b2c6",
    "edits": [
      [
        "from scripts import admit_tukf09_455_formal_evaluation as admission_module",
        "from hpc import admit_tukf09_455_formal_evaluation_compat_v3 as admission_module",
        2
      ],
      [
        "from scripts import tukf09_455_evaluation_common as common",
        "from hpc import tukf09_455_evaluation_common_compat_v3 as common",
        1
      ],
      [
        "common.canonical_json_sha256(semantic_members)",
        "sha256(common.canonical_json_bytes(semantic_members)[:-1]).hexdigest()",
        1
      ],
      [
        "admission_path = root / str(config[\"paths\"][\"admission\"])",
        "admission_path = root / admission_module.compat.ADMISSION_RELATIVE",
        1
      ],
      [
        "\"formal_evaluation_attempt.json\"",
        "\"formal_evaluation_compat_v3_attempt.json\"",
        1
      ],
      [
        "\"formal_evaluation_consumption.json\"",
        "\"formal_evaluation_compat_v3_consumption.json\"",
        1
      ],
      [
        "\"formal_evaluation_failure.json\"",
        "\"formal_evaluation_compat_v3_failure.json\"",
        1
      ],
      [
        "\"formal_evaluation_success.json\"",
        "\"formal_evaluation_compat_v3_success.json\"",
        1
      ]
    ]
  },
  "verify_tukf09_455_basin_evaluation": {
    "sha256": "5cbccc442f7bb24f055a99f251c13ebd257f95103b617a5c508f77f696b4fc9d",
    "edits": [
      [
        "from scripts import admit_tukf09_455_formal_evaluation as admission_module",
        "from hpc import admit_tukf09_455_formal_evaluation_compat_v3 as admission_module",
        2
      ],
      [
        "admission_path = root / str(config[\"paths\"][\"admission\"])",
        "admission_path = root / admission_module.compat.ADMISSION_RELATIVE",
        1
      ],
      [
        "\"formal_evaluation_attempt.json\"",
        "\"formal_evaluation_compat_v3_attempt.json\"",
        1
      ],
      [
        "\"formal_evaluation_independent_attempt.json\"",
        "\"formal_evaluation_independent_compat_v3_attempt.json\"",
        1
      ],
      [
        "\"formal_evaluation_consumption.json\"",
        "\"formal_evaluation_compat_v3_consumption.json\"",
        1
      ],
      [
        "\"formal_evaluation_independent_consumption.json\"",
        "\"formal_evaluation_independent_compat_v3_consumption.json\"",
        1
      ],
      [
        "\"formal_evaluation_failure.json\"",
        "\"formal_evaluation_compat_v3_failure.json\"",
        1
      ],
      [
        "\"formal_evaluation_independent_failure.json\"",
        "\"formal_evaluation_independent_compat_v3_failure.json\"",
        1
      ],
      [
        "\"formal_evaluation_success.json\"",
        "\"formal_evaluation_compat_v3_success.json\"",
        1
      ],
      [
        "\"formal_evaluation_independent_success.json\"",
        "\"formal_evaluation_independent_compat_v3_success.json\"",
        1
      ],
      [
        "_json_sha256(semantic_members)",
        "sha256(_json_bytes(semantic_members)[:-1]).hexdigest()",
        1
      ]
    ]
  },
  "tukf09_455_evaluation_common": {
    "sha256": "ef5958d0288b95c125328f4654bbfa16e4c6aa748c439e656e9d9edb734d84ff",
    "edits": [
      [
        "aggregate = canonical_json_sha256(dict(semantic_members))",
        "aggregate = sha256(canonical_json_bytes(dict(semantic_members))[:-1]).hexdigest()",
        1
      ]
    ]
  }
}''')


def canonical(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")


def record(path: Path) -> dict[str, Any]:
    from scripts import tukf09_455_training_common as training_common
    training_common.ensure_no_symlink_components(path, stop_at=ROOT)
    if not path.is_file() or path.is_symlink() or path.stat().st_nlink != 1:
        raise RuntimeError(f"Compatibility member is absent or linked: {path}")
    data = path.read_bytes()
    return {"sha256": sha256(data).hexdigest(), "size_bytes": len(data)}


def derive_text(name: str, source: bytes) -> str:
    specification = PATCHES[name]
    if sha256(source).hexdigest() != specification["sha256"]:
        raise RuntimeError(f"Frozen predecessor changed: {name}")
    text = source.decode("utf-8").replace("\r\n", "\n")
    for before, after, count in specification["edits"]:
        if text.count(before) != count:
            raise RuntimeError(f"Compatibility substitution count changed: {name}")
        text = text.replace(before, after)
    return text


def validate_seal_counts(selection: Mapping[str, Any]) -> None:
    counts = selection.get("completion_counts")
    if not isinstance(counts, Mapping):
        raise RuntimeError("Real sealed completion_counts are missing")
    for name, expected in (("rebound_filter_units", 455), ("neural_model_units", 9)):
        if type(counts.get(name)) is not int or counts[name] != expected:
            raise RuntimeError(f"Real sealed count changed: {name}")
    for mapping, name, expected in (
        (counts, "filter_basin_units", 455),
        (selection, "filter_selected_model_count", 455),
        (selection, "neural_selected_model_count", 9),
    ):
        if name in mapping and (type(mapping[name]) is not int or mapping[name] != expected):
            raise RuntimeError(f"Conflicting compatibility count: {name}")


def implementation_record() -> dict[str, Any]:
    derivations = {}
    for name in PATCHES:
        old = ROOT / f"scripts/{name}.py"
        new = ROOT / f"hpc/{name}_compat_v3.py"
        original_record = record(old)
        expected = derive_text(name, old.read_bytes()).encode("utf-8")
        actual_record = record(new)
        if new.read_bytes() != expected:
            raise RuntimeError(f"Successor differs outside its reviewed substitutions: {name}")
        derivations[name] = {
            "predecessor": {"path": old.relative_to(ROOT).as_posix(), **original_record},
            "successor": {"path": new.relative_to(ROOT).as_posix(), **actual_record},
            "substitution_count": sum(edit[2] for edit in PATCHES[name]["edits"]),
            "newline_normalization": "CRLF to LF only",
        }
    return {
        "derivations": derivations,
        "review_guard": record(Path(__file__)),
        "regression_test_source": record(TEST_SOURCE),
        "repair_plan": record(PLAN),
    }


def predecessor_proof() -> dict[str, Any]:
    from hpc import tukf09_455_evaluation_compat_v2 as predecessor
    previous_review = predecessor.authorized_repair()
    records = {}
    documents = {}
    for relative, expected in PREDECESSOR_FILES.items():
        path = ROOT / relative
        actual = record(path)
        if actual["sha256"] != expected:
            raise RuntimeError(f"Preserved predecessor evidence changed: {relative}")
        document = json.loads(path.read_bytes())
        unsigned = dict(document)
        claimed = unsigned.pop("record_sha256", None)
        if claimed != sha256(canonical(unsigned)).hexdigest():
            raise RuntimeError("Preserved predecessor self-hash changed")
        records[relative] = actual
        documents[path.name] = document
    authorization = documents["formal_evaluation_authorization.json"]
    admission = documents["formal_evaluation_admission.json"]
    attempt = documents["formal_evaluation_attempt.json"]
    failure = documents["formal_evaluation_failure.json"]
    if (
        admission["authorization_sha256"] != PREDECESSOR_FILES[f"artifacts/{SLUG}/authorizations/formal_evaluation_authorization.json"]
        or admission["authorization_record_sha256"] != authorization["record_sha256"]
        or attempt["admission_sha256"] != PREDECESSOR_FILES[f"artifacts/{SLUG}/formal_evaluation_admission/formal_evaluation_admission.json"]
        or failure["attempt_record_sha256"] != attempt["record_sha256"]
        or failure["attempt_id"] != attempt["attempt_id"]
        or attempt["evaluation_arrays_loaded"] is not False
        or attempt["evaluation_access_ledger"] != {"evaluation_array_reads": 0, "evaluation_metrics": 0, "evaluation_outputs": 0, "evaluation_predictions": 0}
        or attempt["retry_allowed"] is not False
        or failure["evaluation_access_consumed"] is not False
        or failure["consumption_record_sha256"] is not None
        or failure["evaluation_output_exists"] is not False
        or failure["retry_allowed"] is not False
        or failure["exception_message"] != "evaluation semantic identity changed"
        or failure["status"] != "FORMAL_EVALUATION_FAILED_RETRY_FORBIDDEN"
    ):
        raise RuntimeError("Preserved attempt is not the explicitly authorized zero-access predecessor")
    for name in ("formal_evaluation_consumption.json", "formal_evaluation_success.json"):
        if (ROOT / f"results/{SLUG}/control" / name).exists():
            raise RuntimeError("Preserved predecessor has unexpected consumption or success evidence")
    return {"review": previous_review, "files": records, "attempt_id": attempt["attempt_id"], "evaluation_access_consumed": False}


def semantic_metadata_audit() -> dict[str, Any]:
    from hpc import register_tukf09_455_formal_evaluation_authorization_compat_v3 as registration
    from hpc import tukf09_455_evaluation_common_compat_v3 as common
    bindings = registration.fixed_production_bindings()
    final_path = bindings["independent_preflight_final_manifest"]
    final = json.loads(final_path.read_bytes())
    preflight = final_path.parent.parent
    documents = {}
    for name in ("population_registry.json", "semantic_input_manifest.sha256.json", "raw_source_manifest.sha256.json"):
        path = preflight / name
        if record(path) != final["files"][name]:
            raise RuntimeError(f"Frozen metadata file changed: {name}")
        documents[name] = json.loads(path.read_bytes())
    ordered = documents["population_registry.json"]["eligible"]
    if (len(ordered) != common.FROZEN_BASIN_COUNT
        or common.EXCLUDED_BASIN_ID in ordered
        or sha256("".join(value + "\n" for value in ordered).encode()).hexdigest() != common.FROZEN_ORDERED_BASIN_NEWLINE_SHA256):
        raise RuntimeError("Frozen ordered population changed")
    members = {key: value for key, value in documents["semantic_input_manifest.sha256.json"]["members"].items() if key.split("/")[1] == "evaluation"}
    expected = {f"{basin}/evaluation/{name}" for basin in ordered for name in ("dates_ns", "forcing", "observations")}
    if set(members) != expected or len(members) != common.FROZEN_SEMANTIC_MEMBER_COUNT:
        raise RuntimeError("Frozen semantic metadata member set changed")
    for key, member in members.items():
        kind = key.split("/")[-1]
        dtype = "<i8" if kind == "dates_ns" else "<f8"
        shape = [common.FROZEN_EVALUATION_DAY_COUNT, 3] if kind == "forcing" else [common.FROZEN_EVALUATION_DAY_COUNT]
        if (set(member) != {"dtype", "shape", "sha256"} or member["dtype"] != dtype or member["shape"] != shape
            or not isinstance(member["sha256"], str) or len(member["sha256"]) != 64
            or any(char not in "0123456789abcdef" for char in member["sha256"])):
            raise RuntimeError(f"Frozen semantic metadata descriptor changed: {key}")
    aggregate = sha256(canonical(members)[:-1]).hexdigest()
    if aggregate != common.FROZEN_EVALUATION_SEMANTIC_SHA256:
        raise RuntimeError("Frozen semantic payload identity changed")
    raw_files = documents["raw_source_manifest.sha256.json"]["files"]
    if len(raw_files) != common.FROZEN_RAW_SOURCE_COUNT:
        raise RuntimeError("Frozen raw source count changed")
    return {"evaluation_array_reads": 0, "member_count": len(members), "semantic_payload_sha256": aggregate,
            "raw_source_member_count": len(raw_files), "ordered_basin_count": len(ordered)}


def freeze_review() -> dict[str, Any]:
    if REVIEW.exists():
        raise FileExistsError("Compatibility review already exists; do not overwrite")
    for relative in (
        AUTHORIZATION_RELATIVE,
        str(Path(ADMISSION_RELATIVE).parent),
        f"results/{SLUG}/evaluation",
        f"results/{SLUG}/control/formal_evaluation_compat_v3_attempt.json",
    ):
        if (ROOT / relative).exists():
            raise RuntimeError("Compatibility review must precede evaluation authorization")
    predecessor = predecessor_proof()
    metadata = semantic_metadata_audit()
    production_preflight = preflight(require_frozen_review=False)
    implementation = implementation_record()
    test_record = record(TEST_XML)
    suites = list(ET.fromstring(TEST_XML.read_bytes()).iter("testsuite"))
    count = sum(int(suite.get("tests", "0")) for suite in suites)
    failed = sum(int(suite.get("failures", "0")) + int(suite.get("errors", "0")) for suite in suites)
    skipped = sum(int(suite.get("skipped", "0")) for suite in suites)
    if count < 10 or failed or skipped:
        raise RuntimeError("Compatibility regression evidence is absent, failed, or skipped")
    result = {
        "schema_version": "tukf09_455_evaluation_count_compatibility_review_v3",
        "status": "COMPATIBILITY_REPAIR_TESTED_ORIGINAL_EVIDENCE_PRESERVED",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "authorization_basis": "User explicitly authorized (授权) correction of the three semantic fingerprint interfaces and a separately registered new technical attempt, with all old failure evidence preserved.",
        "preserved_predecessor": predecessor,
        "metadata_preflight": metadata,
        "production_preflight_status": production_preflight["status"],
        "new_authorization_relative_path": AUTHORIZATION_RELATIVE,
        "new_admission_relative_path": ADMISSION_RELATIVE,
        "scientific_contract_changed": False,
        "original_training_admission_changed": False,
        "original_source_files_changed": False,
        "evaluation_arrays_loaded": False,
        "original_failed_stage": "compatibility v2 formal dependency construction: semantic payload hash incorrectly includes LF; zero evaluation access",
        "original_failure_consumed_evaluation_access": False,
        "implementation": implementation,
        "regression_evidence": {"path": TEST_XML.relative_to(ROOT).as_posix(), **test_record, "passed": count, "failed": 0, "skipped": 0},
    }
    result["record_sha256"] = sha256(canonical(result)).hexdigest()
    from scripts.register_tukf09_455_formal_evaluation_authorization import _atomic_write_exclusive
    _atomic_write_exclusive(REVIEW, canonical(result))
    return result


def authorized_repair() -> dict[str, Any]:
    review_file_record = record(REVIEW)
    review = json.loads(REVIEW.read_bytes())
    unsigned = dict(review)
    claimed = unsigned.pop("record_sha256", None)
    if claimed != sha256(canonical(unsigned)).hexdigest():
        raise RuntimeError("Compatibility review self-hash changed")
    if review.get("status") != "COMPATIBILITY_REPAIR_TESTED_ORIGINAL_EVIDENCE_PRESERVED":
        raise RuntimeError("Compatibility review status changed")
    if review.get("preserved_predecessor") != predecessor_proof():
        raise RuntimeError("Preserved predecessor proof changed after review")
    if review.get("metadata_preflight") != semantic_metadata_audit():
        raise RuntimeError("Metadata proof changed after review")
    if review.get("implementation") != implementation_record():
        raise RuntimeError("Compatibility implementation changed after review")
    evidence = review.get("regression_evidence", {})
    if evidence.get("path") != TEST_XML.relative_to(ROOT).as_posix():
        raise RuntimeError("Compatibility regression path changed")
    if {key: evidence.get(key) for key in ("sha256", "size_bytes")} != record(TEST_XML):
        raise RuntimeError("Compatibility regression evidence changed")
    if evidence.get("failed") != 0 or evidence.get("skipped") != 0 or evidence.get("passed", 0) < 10:
        raise RuntimeError("Compatibility regression evidence is not passing")
    return {"path": str(REVIEW), **review_file_record, "record_sha256": claimed}


def verify_authorization(authorization: Mapping[str, Any]) -> None:
    if authorization.get("compatibility_repair") != authorized_repair():
        raise RuntimeError("Authorization does not bind the reviewed compatibility repair")
    expected = {
        "evaluation_common_source": "tukf09_455_evaluation_common",
        "evaluator_source": "evaluate_tukf09_455_basin_revision",
        "independent_evaluation_verifier_source": "verify_tukf09_455_basin_evaluation",
    }
    for label, name in expected.items():
        path = ROOT / f"hpc/{name}_compat_v3.py"
        if authorization.get("bindings", {}).get(label) != {"path": str(path), **record(path)}:
            raise RuntimeError(f"Authorization does not bind the executed successor: {label}")
    gates = authorization.get("gate_implementation_bindings", {})
    expected_gates = {
        f"hpc/{name}_compat_v3.py": {"path": str(ROOT / f"hpc/{name}_compat_v3.py"), **record(ROOT / f"hpc/{name}_compat_v3.py")}
        for name in ("register_tukf09_455_formal_evaluation_authorization", "admit_tukf09_455_formal_evaluation")
    }
    if gates != expected_gates:
        raise RuntimeError("Authorization gate provenance is not the actual successor code")


def preflight(*, require_frozen_review: bool = True) -> dict[str, Any]:
    from hpc import register_tukf09_455_formal_evaluation_authorization_compat_v3 as registration
    from hpc import admit_tukf09_455_formal_evaluation_compat_v3 as admission
    predecessor_proof()
    metadata = semantic_metadata_audit()
    repair = authorized_repair() if require_frozen_review else implementation_record()
    bindings = registration.fixed_production_bindings()
    records = {}
    documents = {}
    for label, path in bindings.items():
        records[label] = {"path": str(path), **record(path)}
        if label in registration.JSON_BINDING_LABELS:
            documents[label] = registration._read_json(path, label=label)
    registration._validate_upstream(documents, production=True)
    registration._validate_algorithm_source_closure(documents, records, production=True)
    admission._require_current_runtime_matches_training(records)
    return {"status": "COMPATIBILITY_PRODUCTION_PREFLIGHT_PASSED_ZERO_EVALUATION_ACCESS", "semantic_metadata": metadata, "binding_count": len(bindings), "original_executables": 30, "compatibility_repair": repair}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--freeze-review", action="store_true")
    parser.add_argument("--preflight", action="store_true")
    parser.add_argument("--audit-unsealed", action="store_true")
    args = parser.parse_args()
    if sum((args.freeze_review, args.preflight, args.audit_unsealed)) != 1:
        raise ValueError("Choose exactly one explicit action")
    result = freeze_review() if args.freeze_review else preflight(require_frozen_review=not args.audit_unsealed)
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
