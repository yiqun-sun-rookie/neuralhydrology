"""Bounded Linux supervisor for one short probe; no scheduler or shell access."""
from __future__ import annotations

import ctypes
import json
import math
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import time


def _write_status(path: Path, record: dict) -> None:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        json.dump(record, stream, sort_keys=True)
        stream.flush()
        os.fsync(stream.fileno())


def _proc_identity(pid: int) -> tuple[int, int, int, int, str] | None:
    try:
        raw = Path(f"/proc/{pid}/stat").read_text()
        fields = raw[raw.rfind(")") + 2:].split()
        return int(fields[1]), int(fields[2]), int(fields[19]), int(fields[21]), fields[0]
    except (OSError, ValueError, IndexError):
        return None


def _snapshot_processes() -> dict[int, tuple[int, int, int, int, str]]:
    return {int(item.name): identity for item in Path("/proc").iterdir()
            if item.name.isdigit() and (identity := _proc_identity(int(item.name))) is not None}


def _tree_stats(root_pid: int, entries: dict) -> tuple[int, set[int]]:
    """Read current descendants from procfs, including children of children."""
    members = {root_pid}
    changed = True
    while changed:
        old = len(members)
        members.update(pid for pid, (ppid, _, _, _, _) in entries.items() if ppid in members)
        changed = len(members) != old
    return (sum(entries[pid][3] for pid in members if pid in entries) * os.sysconf("SC_PAGE_SIZE"),
            members - {root_pid})


def _kill_group(pgid: int, starttime: int) -> bool:
    identity = _proc_identity(pgid)
    if identity is None or identity[2] != starttime or identity[1] != pgid:
        return False
    try:
        os.killpg(pgid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    return True


def _kill_identity(pid: int, starttime: int) -> bool:
    identity = _proc_identity(pid)
    if identity is None or identity[2] != starttime or identity[4] == "Z":
        return False
    try:
        os.kill(pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    return True


def _output_size(root: Path) -> int:
    total = 0
    pending = [root]
    while pending:
        directory = pending.pop()
        for entry in os.scandir(directory):
            info = entry.stat(follow_symlinks=False)
            if stat.S_ISLNK(info.st_mode):
                raise ValueError("output_link")
            if stat.S_ISDIR(info.st_mode):
                pending.append(Path(entry.path))
            elif stat.S_ISREG(info.st_mode):
                total += info.st_size
            else:
                raise ValueError("output_special_file")
    return total


def _limit_supervisor(address_limit: int) -> tuple[int, int]:
    import resource
    soft, hard = resource.getrlimit(resource.RLIMIT_AS)
    if hard != resource.RLIM_INFINITY and hard < address_limit:
        raise ValueError("supervisor inherited address hard limit below worker limit")
    bounded_soft = 256 * 2**20 if soft == resource.RLIM_INFINITY else min(soft, 256 * 2**20)
    if bounded_soft <= 0:
        raise ValueError("invalid supervisor address soft limit")
    resource.setrlimit(resource.RLIMIT_AS, (bounded_soft, hard))
    return soft, hard


def _watchdog(parent_pid: int, parent_start: int, pgid: int, worker_start: int,
              heartbeat: Path, stop: Path) -> None:
    """Independent bounded guard; acts only on its registered process group."""
    import resource
    resource.setrlimit(resource.RLIMIT_AS, (256 * 2**20, 256 * 2**20))
    observed_children: dict[int, int] = {}
    while not stop.exists():
        entries = _snapshot_processes()
        worker = entries.get(pgid)
        if worker is not None and worker[2] == worker_start:
            _, descendants = _tree_stats(pgid, entries)
            for pid in descendants:
                observed_children[pid] = entries[pid][2]
            if descendants:
                _write_status(heartbeat.with_name("watchdog.children.json"),
                              {"worker_pid": pgid, "worker_starttime": worker_start,
                               "children": observed_children})
        parent = _proc_identity(parent_pid)
        parent_dead = parent is None or parent[2] != parent_start or parent[4] == "Z"
        try:
            stale = time.time() - heartbeat.stat().st_mtime > 60
        except OSError:
            stale = True
        if parent_dead or stale:
            _kill_group(pgid, worker_start)
            for pid, starttime in observed_children.items():
                _kill_identity(pid, starttime)
            return
        time.sleep(1)


def _child_setup(limit: int, parent_pid: int) -> None:
    import resource
    os.setsid()
    resource.setrlimit(resource.RLIMIT_AS, (limit, limit))
    # If this supervisor disappears, Linux kills the registered group leader.
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(1, signal.SIGKILL, 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), "prctl(PR_SET_PDEATHSIG) failed")
    if os.getppid() != parent_pid:  # close the fork/prctl race
        os._exit(125)


def run_supervised(command: list[str], output_dir: Path, *,
                   wall_seconds: float = 1800,
                   rss_limit_bytes: int = 8 * 2**30,
                   address_space_limit_bytes: int = 8 * 2**30,
                   output_limit_bytes: int = 100 * 2**20,
                   poll_seconds: float = 2.0) -> dict:
    """Run one command in a new directory, returning a durable success/failure record.

    Linux only. Never retries. The caller may create task output *inside* output_dir.
    The address-space hard limit applies per process, whereas RSS is summed over
    the observed descendant tree and is a monitored stop threshold, not a cgroup.
    """
    if not isinstance(command, list) or not command or any(not isinstance(x, str) or not x for x in command):
        raise ValueError("command must be a nonempty list of nonempty strings")
    values = (wall_seconds, rss_limit_bytes, address_space_limit_bytes,
              output_limit_bytes, poll_seconds)
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v <= 0 for v in values):
        raise ValueError("all limits must be finite and positive")
    if poll_seconds > 5 or address_space_limit_bytes < 2**20:
        raise ValueError("poll interval exceeds five seconds or address space is too small")
    output_dir = Path(output_dir)
    if output_dir.exists():
        raise FileExistsError(output_dir)
    if sys.platform != "linux":
        raise RuntimeError("Linux is required for supervised execution")
    previous_limit = _limit_supervisor(int(address_space_limit_bytes))
    output_dir.mkdir(parents=True, exist_ok=False)
    status_path = output_dir / "supervisor.json"
    heartbeat_path = output_dir / "heartbeat.json"
    started = time.monotonic()
    record = {"success": False, "reason": "not_started", "exit_code": None,
              "wall_seconds": 0.0, "peak_tree_rss_bytes": 0, "output_bytes": 0,
              "worker_pid": None, "sample_count": 0}
    proc = None
    guard = None
    worker_start = None
    observed_children = {}
    try:
        _write_status(status_path, record)
        with (output_dir / "stdout.log").open("wb") as stdout, (output_dir / "stderr.log").open("wb") as stderr:
            parent_pid = os.getpid()
            proc = subprocess.Popen(command, cwd=output_dir, stdout=stdout, stderr=stderr,
                                    shell=False,
                                    preexec_fn=lambda: _child_setup(int(address_space_limit_bytes), parent_pid))
            worker_identity = _proc_identity(proc.pid)
            if worker_identity is None:
                raise RuntimeError("worker identity unavailable")
            worker_start = worker_identity[2]
            parent_identity = _proc_identity(parent_pid)
            if parent_identity is None:
                raise RuntimeError("supervisor identity unavailable")
            record["worker_pid"] = proc.pid
            (output_dir / "worker.pid").write_text(str(proc.pid), encoding="ascii")
            _write_status(heartbeat_path, {"time_unix": time.time(), "worker_pid": proc.pid})
            guard = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), "--watchdog",
                                      str(parent_pid), str(parent_identity[2]),
                                      str(proc.pid), str(worker_start), str(heartbeat_path),
                                      str(output_dir / "watchdog.stop")],
                                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                     stderr=subprocess.DEVNULL, shell=False, start_new_session=True)
            while True:
                elapsed = time.monotonic() - started
                entries = _snapshot_processes()
                rss, descendants = _tree_stats(proc.pid, entries)
                for pid in descendants:
                    observed_children[pid] = entries[pid][2]
                rss += sum(entries[pid][3] for pid in (parent_pid, guard.pid) if pid in entries) * os.sysconf("SC_PAGE_SIZE")
                output_bytes = _output_size(output_dir)
                record.update(wall_seconds=elapsed,
                              peak_tree_rss_bytes=max(record["peak_tree_rss_bytes"], rss),
                              output_bytes=output_bytes)
                record["sample_count"] += 1
                _write_status(heartbeat_path, {"time_unix": time.time(), "worker_pid": proc.pid})
                _write_status(status_path, record)
                if guard.poll() is not None:
                    record["reason"] = "watchdog_exited"
                    break
                if elapsed > wall_seconds:
                    record["reason"] = "wall_limit"
                    break
                if rss > rss_limit_bytes:
                    record["reason"] = "rss_limit"
                    break
                if descendants:
                    record["reason"] = "unexpected_child_process"
                    break
                if output_bytes > output_limit_bytes:
                    record["reason"] = "output_limit"
                    break
                code = proc.poll()
                if code is not None:
                    record["exit_code"] = code
                    record["reason"] = "complete" if code == 0 else "nonzero_exit"
                    record["success"] = code == 0
                    break
                time.sleep(poll_seconds)
    except Exception as exc:
        if str(exc) in ("output_link", "output_special_file"):
            record["reason"] = str(exc)
        else:
            record["reason"] = "monitor_write_failure" if isinstance(exc, OSError) and proc is not None else "supervisor_exception"
        record["error"] = type(exc).__name__ + ": " + str(exc)
    finally:
        if proc is not None:
            if worker_start is not None and proc.poll() is None:
                _kill_group(proc.pid, worker_start)
            for pid, starttime in observed_children.items():
                _kill_identity(pid, starttime)
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                record["reason"] = "cleanup_failure"
                record["success"] = False
            if record["exit_code"] is None:
                record["exit_code"] = proc.returncode
        if guard is not None:
            try:
                (output_dir / "watchdog.stop").write_text("complete", encoding="ascii")
                guard.wait(timeout=3)
            except (OSError, subprocess.TimeoutExpired):
                guard.kill()
                guard.wait(timeout=3)
        record["wall_seconds"] = time.monotonic() - started
        try:
            _write_status(status_path, record)
        except OSError:
            record["success"] = False
            record["reason"] = "monitor_write_failure"
        import resource
        resource.setrlimit(resource.RLIMIT_AS, previous_limit)
    return record


if __name__ == "__main__":
    if len(sys.argv) == 8 and sys.argv[1] == "--watchdog" and sys.platform == "linux":
        _watchdog(int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]),
                  int(sys.argv[5]), Path(sys.argv[6]), Path(sys.argv[7]))
    else:
        raise SystemExit("Import run_supervised; no implicit model execution")
