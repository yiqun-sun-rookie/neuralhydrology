"""Pure evaluation reductions for the scaled-noise comparison.

No production evaluation loader is exposed under the current authorization.
The numerical reducers are complete and testable on synthetic arrays; the
command-line production entry point stops before any evaluation-period access.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import sys
from typing import Any, Mapping, Sequence

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
for _extra in (str(ROOT), str(ROOT / "src"), str(ROOT / "hpc")):
    if _extra not in sys.path:
        sys.path.insert(0, _extra)

import tukf09_455_scaled_noise_common_v1 as common  # noqa: E402


ARM_NAMES = (
    "original_filter_reference",
    "original_neural_ensemble_reference",
    "local_scaled_process_noise",
    "leave_one_basin_out_transfer_scaled_process_noise",
)
COMPARISONS = (
    (
        "local_minus_original_filter",
        "local_scaled_process_noise",
        "original_filter_reference",
    ),
    (
        "transfer_minus_local",
        "leave_one_basin_out_transfer_scaled_process_noise",
        "local_scaled_process_noise",
    ),
    (
        "local_minus_original_neural_ensemble",
        "local_scaled_process_noise",
        "original_neural_ensemble_reference",
    ),
    (
        "transfer_minus_original_neural_ensemble",
        "leave_one_basin_out_transfer_scaled_process_noise",
        "original_neural_ensemble_reference",
    ),
)


def nash_sutcliffe_efficiency_on_mask(
    target: np.ndarray,
    prediction: np.ndarray,
    mask: np.ndarray,
) -> float:
    target_array = np.asarray(target, dtype=np.float64)
    prediction_array = np.asarray(prediction, dtype=np.float64)
    mask_array = np.asarray(mask, dtype=np.bool_)
    if (
        target_array.ndim != 1
        or prediction_array.shape != target_array.shape
        or mask_array.shape != target_array.shape
        or not np.any(mask_array)
    ):
        raise ValueError("target, prediction, and nonempty mask must align")
    if not np.isfinite(target_array[mask_array]).all() or not np.isfinite(
        prediction_array[mask_array]
    ).all():
        raise FloatingPointError("masked score values must be finite")
    selected = target_array[mask_array]
    denominator = float(
        np.sum(np.square(selected - np.mean(selected, dtype=np.float64)), dtype=np.float64)
    )
    if not math.isfinite(denominator) or denominator <= 0.0:
        raise ValueError("target variance on the frozen mask must be positive")
    numerator = float(
        np.sum(np.square(prediction_array[mask_array] - selected), dtype=np.float64)
    )
    value = 1.0 - numerator / denominator
    if not math.isfinite(value):
        raise FloatingPointError("Nash-Sutcliffe efficiency is non-finite")
    return value


def decision_from_interval(lower: float, upper: float) -> dict[str, Any]:
    lower_value, upper_value = float(lower), float(upper)
    if not math.isfinite(lower_value) or not math.isfinite(upper_value) or lower_value > upper_value:
        raise ValueError("bootstrap interval is invalid")
    if lower_value >= 0.01:
        verdict, success = "FILTER_PRACTICALLY_EXCEEDS_NEURAL_ENSEMBLE", True
    elif lower_value >= -0.01:
        verdict, success = (
            "FILTER_REACHES_NEURAL_ENSEMBLE_WITHOUT_PROVEN_PRACTICAL_SUPERIORITY",
            False,
        )
    elif upper_value <= -0.01:
        verdict, success = "FILTER_BELOW_NEURAL_ENSEMBLE", False
    else:
        verdict, success = "INCONCLUSIVE", False
    return {"verdict": verdict, "confirmatory_success": success}


def _distribution_summary(values: np.ndarray, basin_ids: Sequence[str]) -> dict[str, Any]:
    array = np.asarray(values, dtype=np.float64)
    if array.shape != (len(basin_ids),) or not np.isfinite(array).all():
        raise ValueError("comparison values must be one finite value per basin")
    quantiles = np.quantile(array, [0.1, 0.25, 0.5, 0.75, 0.9], method="linear")
    order = np.argsort(array, kind="stable")
    return {
        "count": len(array),
        "median": float(np.median(array)),
        "quantiles": {
            "0.10": float(quantiles[0]),
            "0.25": float(quantiles[1]),
            "0.50": float(quantiles[2]),
            "0.75": float(quantiles[3]),
            "0.90": float(quantiles[4]),
        },
        "win_count": int(np.count_nonzero(array > 0.0)),
        "tie_count": int(np.count_nonzero(array == 0.0)),
        "loss_count": int(np.count_nonzero(array < 0.0)),
        "ranked_low_to_high": [
            {"basin_id": str(basin_ids[index]), "difference": float(array[index])}
            for index in order
        ],
    }


def common_index_bootstrap(
    per_comparison_values: Mapping[str, np.ndarray],
    *,
    seed: int,
    resamples: int,
    confidence_level: float,
) -> dict[str, dict[str, Any]]:
    names = tuple(per_comparison_values)
    if not names:
        raise ValueError("at least one comparison is required")
    arrays = [np.asarray(per_comparison_values[name], dtype=np.float64) for name in names]
    population = len(arrays[0])
    if population < 1 or any(value.shape != (population,) for value in arrays):
        raise ValueError("all bootstrap comparisons must align by basin")
    if any(not np.isfinite(value).all() for value in arrays):
        raise FloatingPointError("bootstrap comparisons must be finite")
    count = int(resamples)
    confidence = float(confidence_level)
    if count != 10000 or confidence != 0.95:
        raise ValueError("bootstrap count or confidence differs from the frozen contract")
    generator = np.random.default_rng(int(seed))
    medians = {name: np.empty(count, dtype=np.float64) for name in names}
    cursor = 0
    while cursor < count:
        take = min(512, count - cursor)
        indices = generator.integers(0, population, size=(take, population))
        for name, array in zip(names, arrays):
            medians[name][cursor : cursor + take] = np.median(array[indices], axis=1)
        cursor += take
    tail = (1.0 - confidence) / 2.0
    result: dict[str, dict[str, Any]] = {}
    for name, array in zip(names, arrays):
        lower, upper = np.quantile(medians[name], [tail, 1.0 - tail], method="linear")
        result[name] = {
            "population_count": population,
            "population_median": float(np.median(array)),
            "confidence_level": confidence,
            "lower": float(lower),
            "upper": float(upper),
            "seed": int(seed),
            "resamples": count,
            "statistic": "median",
            "quantile_method": "linear",
            "common_resample_indices": True,
        }
    return result


def summarize_four_comparisons(
    basin_ids: Sequence[str],
    nse_by_arm: Mapping[str, np.ndarray],
    *,
    science_contract: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    contract = common.load_science_contract() if science_contract is None else science_contract
    ordered = tuple(str(value) for value in basin_ids)
    if len(ordered) != 455 or len(set(ordered)) != 455:
        raise ValueError("formal summary requires exactly 455 unique ordered basins")
    if set(nse_by_arm) != set(ARM_NAMES):
        raise ValueError("Nash-Sutcliffe efficiency arms differ from the four frozen arms")
    arrays: dict[str, np.ndarray] = {}
    for name in ARM_NAMES:
        value = np.asarray(nse_by_arm[name], dtype=np.float64)
        if value.shape != (455, 3) or not np.isfinite(value).all():
            raise ValueError(f"arm {name} must have finite shape [455,3]")
        arrays[name] = value
    comparison_values: dict[str, np.ndarray] = {}
    per_comparison: dict[str, Any] = {}
    for name, left, right in COMPARISONS:
        lead_difference = arrays[left] - arrays[right]
        basin_difference = np.mean(lead_difference, axis=1, dtype=np.float64)
        comparison_values[name] = basin_difference
        per_comparison[name] = {
            "left_arm": left,
            "right_arm": right,
            "basin_mean_over_three_leads": _distribution_summary(basin_difference, ordered),
            "by_lead": {
                str(lead): _distribution_summary(lead_difference[:, index], ordered)
                for index, lead in enumerate(common.LEADS)
            },
        }
    bootstrap_settings = contract["evaluation"]["bootstrap"]
    bootstrap = common_index_bootstrap(
        comparison_values,
        seed=int(bootstrap_settings["seed"]),
        resamples=int(bootstrap_settings["resamples"]),
        confidence_level=float(bootstrap_settings["confidence_level"]),
    )
    for name, record in bootstrap.items():
        per_comparison[name]["paired_basin_bootstrap"] = record
        if name in (
            "local_minus_original_neural_ensemble",
            "transfer_minus_original_neural_ensemble",
        ):
            per_comparison[name]["retrospective_parent_decision"] = decision_from_interval(
                record["lower"], record["upper"]
            )
        else:
            per_comparison[name]["retrospective_parent_decision"] = None
    return {
        "schema_version": "tukf09_455_scaled_noise_evaluation_summary_v1",
        "experiment_id": common.EXPERIMENT_ID,
        "status": "FORMAL_EVALUATION_SUMMARY",
        "basin_count": 455,
        "lead_days": list(common.LEADS),
        "comparisons": per_comparison,
        "parent_verdict_overwritten": False,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", required=True, choices=("formal-evaluation",))
    parser.parse_args()
    common.load_execution_authorization()
    common.load_implementation_admission()
    common.require_formal_execution_denied()
    raise PermissionError(
        "evaluation arrays, predictions, metrics, and scientific bootstrap are not authorized"
    )


if __name__ == "__main__":
    main()
