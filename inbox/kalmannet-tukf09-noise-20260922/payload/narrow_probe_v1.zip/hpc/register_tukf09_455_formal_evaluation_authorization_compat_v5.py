"""Register the immutable one-time authorization for the 455-basin evaluation.

The explicit boolean gate is checked before every filesystem operation.  This
script hashes metadata and executable files only; it contains no evaluation
array loader.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path, PurePosixPath
from typing import Any, Mapping
import uuid

from hpc import tukf09_455_evaluation_compat_v5 as compat


EXPERIMENT_ID = "TUKF09_455_BASIN_ZERO_VALIDATION_TARGET_VARIANCE_REVISION_V1"
REQUIRED_BINDING_LABELS = frozenset(
    {
        "scientific_contract",
        "independent_preflight_final_manifest",
        "all_scope_authorization",
        "filter_migration_final_manifest",
        "training_authorization",
        "training_admission",
        "filter_installation_final_manifest",
        "training_completion",
        "training_selection_seal",
        "independent_training_selection_final_manifest",
        "formal_training_execution_config",
        "formal_evaluation_config",
        "evaluation_common_source",
        "evaluator_source",
        "independent_evaluation_verifier_source",
        "model_source",
        "filter_runner_source",
        "confirmatory_common_source",
        "covariance_update_source",
        "differentiable_ukf_reference_source",
        "conventional_ukf_source",
        "differentiable_filter_engine_source",
        "differentiable_hbvlite_model_source",
        "hbvlite_system_model_source",
        "hbvlite_ukf_adapter_source",
        "fixed_results_identity",
    }
)
ROOT = Path(__file__).resolve().parents[1]
SOURCE_BINDING_LABELS = frozenset(
    {
    "evaluation_common_source",
    "evaluator_source",
    "independent_evaluation_verifier_source",
    "model_source",
        "filter_runner_source",
        "confirmatory_common_source",
        "covariance_update_source",
        "differentiable_ukf_reference_source",
        "conventional_ukf_source",
        "differentiable_filter_engine_source",
        "differentiable_hbvlite_model_source",
        "hbvlite_system_model_source",
        "hbvlite_ukf_adapter_source",
    }
)
JSON_BINDING_LABELS = REQUIRED_BINDING_LABELS - SOURCE_BINDING_LABELS
PRETRAINING_SOURCE_BINDINGS = {
    "filter_runner_source": "scripts/run_tukf09_filter_training.py",
    "confirmatory_common_source": "scripts/tukf09_confirmatory_common.py",
    "covariance_update_source": "scripts/run_aligned_gr4j_da.py",
    "differentiable_ukf_reference_source": "scripts/run_aligned_gr4j_differentiable_ukf.py",
    "conventional_ukf_source": "src/global_hydrology/assimilation/conventional_ukf.py",
    "model_source": "scripts/tukf07_information_matched_model.py",
}
CONTRACT_ANCHOR_BINDINGS = {
    "differentiable_filter_engine_source": "differentiable_filter_engine",
    "differentiable_hbvlite_model_source": "differentiable_hbvlite_model",
    "hbvlite_system_model_source": "hbvlite_system_model",
    "hbvlite_ukf_adapter_source": "hbvlite_ukf_adapter",
    "model_source": "neural_model_architecture",
}
NUMERICAL_SOURCE_ANCHOR_NAMES = frozenset(CONTRACT_ANCHOR_BINDINGS.values())
ZERO_EVALUATION_ACCESS_LEDGER = {
    "evaluation_array_reads": 0,
    "evaluation_predictions": 0,
    "evaluation_metrics": 0,
    "evaluation_outputs": 0,
}


def canonical_json_bytes(value: Any) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")


def _canonical_sha256(value: Any) -> str:
    return sha256(canonical_json_bytes(value)).hexdigest()


def record_sha256(record: Mapping[str, Any]) -> str:
    unsigned = dict(record)
    unsigned.pop("record_sha256", None)
    return _canonical_sha256(unsigned)


def _sha256_file(path: Path) -> str:
    source = _require_file(Path(path), label="SHA-256 source")
    digest = sha256()
    with source.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _require_file(path: Path, *, label: str) -> Path:
    from scripts import tukf09_455_training_common as training_common

    training_common.ensure_no_symlink_components(path)
    if not path.is_file() or path.is_symlink() or path.stat().st_nlink != 1:
        raise FileNotFoundError(f"{label} is absent, linked, or not a regular file: {path}")
    return path


def _read_json(path: Path, *, label: str) -> dict[str, Any]:
    source = _require_file(path, label=label)
    try:
        value = json.loads(source.read_bytes())
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"{label} is not valid JSON") from exc
    if not isinstance(value, dict):
        raise RuntimeError(f"{label} must contain one JSON object")
    canonical_json_bytes(value)
    return value


def _evaluation_access_proof(record: Mapping[str, Any]) -> tuple[bool, bool]:
    """Return whether a zero ledger was present and whether any violation exists."""

    found = False
    violation = False
    for key in ("evaluation_arrays_loaded", "arrays_loaded"):
        if key in record:
            found = True
            violation = violation or record[key] is not False
    evaluation_identity = record.get("evaluation_identity")
    if isinstance(evaluation_identity, Mapping) and "arrays_loaded" in evaluation_identity:
        found = True
        violation = violation or evaluation_identity["arrays_loaded"] is not False
    for key in ("evaluation_access_ledger", "access_ledger"):
        ledger = record.get(key)
        if isinstance(ledger, Mapping):
            matching = {name: ledger.get(name) for name in ZERO_EVALUATION_ACCESS_LEDGER}
            if any(name in ledger for name in ZERO_EVALUATION_ACCESS_LEDGER):
                found = True
                violation = violation or matching != ZERO_EVALUATION_ACCESS_LEDGER
    if "evaluation_access_count" in record:
        found = True
        violation = violation or record["evaluation_access_count"] != 0
    return found, violation


def _require_zero_access(record: Mapping[str, Any], *, label: str) -> None:
    found, violation = _evaluation_access_proof(record)
    if not found or violation:
        raise RuntimeError(f"{label} does not prove zero evaluation access")


def _require_experiment(record: Mapping[str, Any], *, label: str) -> None:
    if record.get("experiment_id") != EXPERIMENT_ID:
        raise RuntimeError(f"{label} experiment identity changed")


def _require_status_contains(record: Mapping[str, Any], text: str, *, label: str) -> None:
    status = record.get("status")
    if not isinstance(status, str) or text not in status:
        raise RuntimeError(f"{label} status is not complete: {status!r}")


def _selection_count(
    record: Mapping[str, Any], direct: str, nested: str
) -> int | None:
    if direct in record:
        return int(record[direct])
    counts = record.get("completion_counts")
    if isinstance(counts, Mapping) and nested in counts:
        return int(counts[nested])
    return None


def _validate_upstream(documents: Mapping[str, Mapping[str, Any]], *, production: bool) -> None:
    for label, record in documents.items():
        _require_experiment(record, label=label)
    _require_status_contains(documents["all_scope_authorization"], "AUTHORIZED", label="all-scope authorization")
    _require_status_contains(
        documents["filter_migration_final_manifest"],
        "INDEPENDENTLY_VERIFIED",
        label="filter migration final manifest",
    )
    _require_status_contains(documents["training_completion"], "COMPLETE", label="formal training completion")
    _require_status_contains(
        documents["training_authorization"],
        "AUTHORIZED",
        label="formal training authorization",
    )
    _require_status_contains(
        documents["training_admission"],
        "ADMITTED",
        label="formal training technical admission",
    )
    _require_status_contains(
        documents["filter_installation_final_manifest"],
        "INDEPENDENTLY_VERIFIED",
        label="filter installation final manifest",
    )
    _require_status_contains(
        documents["formal_evaluation_config"],
        "FROZEN",
        label="formal evaluation algorithm configuration",
    )
    _require_status_contains(documents["training_selection_seal"], "SEALED", label="training selection seal")
    _require_status_contains(
        documents["independent_training_selection_final_manifest"],
        "INDEPENDENTLY_VERIFIED",
        label="independent training selection final manifest",
    )
    for label in (
        "training_admission",
        "training_completion",
        "training_selection_seal",
        "fixed_results_identity",
    ):
        _require_zero_access(documents[label], label=label)

    selection = documents["training_selection_seal"]
    if production:
        compat.validate_seal_counts(selection)
    filters = _selection_count(
        selection, "filter_selected_model_count", "rebound_filter_units"
    )
    neural = _selection_count(
        selection, "neural_selected_model_count", "neural_model_units"
    )
    if filters != 455 or neural != 9:
        raise RuntimeError("training selection does not contain exactly 455 filters and 9 neural models")
    completion = documents["training_completion"]
    if "completed_neural_models" in completion and int(completion["completed_neural_models"]) != 9:
        raise RuntimeError("formal training is not complete for 9 of 9 neural models")
    if "expected_neural_models" in completion and int(completion["expected_neural_models"]) != 9:
        raise RuntimeError("formal training expected neural-model count changed")


def _validate_algorithm_source_closure(
    documents: Mapping[str, Mapping[str, Any]],
    records: Mapping[str, Mapping[str, Any]],
    *,
    production: bool,
) -> None:
    if not production:
        return
    training_sources = documents["training_admission"].get("executables")
    if not isinstance(training_sources, Mapping):
        raise RuntimeError("pretraining executable source records are absent")
    for label, relative in PRETRAINING_SOURCE_BINDINGS.items():
        expected = training_sources.get(relative)
        actual = {
            "sha256": records[label]["sha256"],
            "size_bytes": records[label]["size_bytes"],
        }
        if expected != actual:
            raise RuntimeError(
                f"production algorithm source was not frozen before training: {relative}"
            )
    anchors = documents["scientific_contract"].get("source_anchors")
    if not isinstance(anchors, Mapping):
        raise RuntimeError("scientific-contract source anchors are absent")
    for label, anchor_name in CONTRACT_ANCHOR_BINDINGS.items():
        anchor = anchors.get(anchor_name)
        if not isinstance(anchor, Mapping):
            raise RuntimeError(f"scientific-contract source anchor is absent: {anchor_name}")
        anchor_path = _absolute(ROOT / str(anchor.get("path")))
        if (
            _absolute(records[label]["path"]) != anchor_path
            or records[label]["sha256"] != anchor.get("sha256")
            or _sha256_file(_require_file(anchor_path, label=anchor_name))
            != anchor.get("sha256")
        ):
            raise RuntimeError(f"scientific-contract source anchor changed: {anchor_name}")
    _validate_training_executable_closure(documents, records)
    _validate_all_contract_source_anchors(documents)
    _validate_independent_training_selection_bundle(documents, records)
    _validate_pretraining_identity_chain(documents, records)


def _validate_training_executable_closure(
    documents: Mapping[str, Mapping[str, Any]],
    records: Mapping[str, Mapping[str, Any]],
) -> dict[str, dict[str, Any]]:
    """Rehash the exact ordered 30-file pretraining numerical/code closure."""

    from scripts import tukf09_455_training_common as training_common

    execution = documents["formal_training_execution_config"]
    configured = execution.get("required_executables")
    expected = list(training_common.REQUIRED_TRAINING_EXECUTABLE_RELATIVE_PATHS)
    if configured != expected or len(expected) != 30 or len(set(expected)) != 30:
        raise RuntimeError("formal training required-executable order or count changed")
    training = documents["training_admission"]
    admitted = training.get("executables")
    if not isinstance(admitted, Mapping) or set(admitted) != set(expected):
        raise RuntimeError("training admission does not bind exactly the 30 executables")
    execution_record = training.get("execution_config")
    if not isinstance(execution_record, Mapping) or (
        execution_record.get("path")
        != "configs/tukf09_455_basin_zero_validation_target_variance_formal_training_execution_v1.json"
        or execution_record.get("sha256")
        != records["formal_training_execution_config"]["sha256"]
    ):
        raise RuntimeError("training execution configuration changed after admission")
    current: dict[str, dict[str, Any]] = {}
    for relative in expected:
        source = _require_file(ROOT / relative, label=f"required executable {relative}")
        actual = {"sha256": _sha256_file(source), "size_bytes": int(source.stat().st_size)}
        if admitted.get(relative) != actual:
            raise RuntimeError(f"required executable changed after training admission: {relative}")
        current[relative] = {
            "path": os.fspath(_absolute(source)),
            **actual,
        }
    return current


def _validate_all_contract_source_anchors(
    documents: Mapping[str, Mapping[str, Any]],
) -> dict[str, dict[str, Any]]:
    """Rehash every frozen source anchor, including the numerical import closure."""

    anchors = documents["scientific_contract"].get("source_anchors")
    if not isinstance(anchors, Mapping) or not NUMERICAL_SOURCE_ANCHOR_NAMES.issubset(anchors):
        raise RuntimeError("scientific-contract source-anchor set is incomplete")
    verified: dict[str, dict[str, Any]] = {}
    for name, value in sorted(anchors.items()):
        if not isinstance(value, Mapping) or set(value) != {"path", "sha256"}:
            raise RuntimeError(f"scientific-contract source-anchor schema changed: {name}")
        raw_path = Path(str(value["path"]))
        source = _require_file(
            _absolute(raw_path if raw_path.is_absolute() else ROOT / raw_path),
            label=f"scientific-contract source anchor {name}",
        )
        digest = _sha256_file(source)
        if digest != value["sha256"]:
            raise RuntimeError(f"scientific-contract source anchor changed: {name}")
        verified[str(name)] = {
            "path": os.fspath(source),
            "sha256": digest,
            "size_bytes": int(source.stat().st_size),
        }
    return verified


def _validate_independent_training_selection_bundle(
    documents: Mapping[str, Mapping[str, Any]],
    records: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    """Cross-bind the current selection seal to its exact independent two-file seal."""

    final = documents["independent_training_selection_final_manifest"]
    final_path = _absolute(records["independent_training_selection_final_manifest"]["path"])
    independent_root = final_path.parent
    audit_path = independent_root / "independent_audit.json"
    if (
        not independent_root.is_dir()
        or independent_root.is_symlink()
        or {path.name for path in independent_root.iterdir()}
        != {"independent_audit.json", "manifest.final.sha256.json"}
    ):
        raise RuntimeError("independent training-selection exact member set changed")
    required_final_keys = {
        "schema_version",
        "experiment_id",
        "status",
        "file_count",
        "files",
        "source_training_selection_seal_sha256",
        "formal_evaluation_authorized",
    }
    if (
        set(final) != required_final_keys
        or final.get("schema_version")
        != "tukf09_training_selection_independent_final_manifest_v1"
        or final.get("experiment_id") != EXPERIMENT_ID
        or final.get("status")
        != "TRAINING_SELECTION_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
        or final.get("file_count") != 1
        or final.get("formal_evaluation_authorized") is not False
        or set(final.get("files", {})) != {"independent_audit.json"}
    ):
        raise RuntimeError("independent training-selection final manifest schema or status changed")
    audit_record = final["files"]["independent_audit.json"]
    if not isinstance(audit_record, Mapping) or set(audit_record) != {"sha256", "size_bytes"}:
        raise RuntimeError("independent training-selection audit member record changed")
    audit_source = _require_file(audit_path, label="independent training-selection audit")
    if audit_record != {
        "sha256": _sha256_file(audit_source),
        "size_bytes": int(audit_source.stat().st_size),
    }:
        raise RuntimeError("independent training-selection audit hash or size changed")
    audit = _read_json(audit_source, label="independent training-selection audit")
    current_seal_sha256 = records["training_selection_seal"]["sha256"]
    if (
        audit.get("schema_version") != "tukf09_training_selection_independent_audit_v1"
        or audit.get("experiment_id") != EXPERIMENT_ID
        or audit.get("status")
        != "TRAINING_SELECTION_INDEPENDENTLY_VERIFIED_EVALUATION_HOLD"
        or audit.get("mismatch_count") != 0
        or audit.get("formal_evaluation_authorized") is not False
        or audit.get("training_selection_seal_sha256") != current_seal_sha256
        or final.get("source_training_selection_seal_sha256") != current_seal_sha256
        or audit.get("evaluation_access_ledger") != ZERO_EVALUATION_ACCESS_LEDGER
    ):
        raise RuntimeError("independent training-selection seal is stale or internally inconsistent")
    selection_seal = documents["training_selection_seal"]
    results_root = _absolute(records["training_selection_seal"]["path"]).parent.parent
    manifest_relative = selection_seal.get("training_manifest_relative_path")
    if manifest_relative != "selection/training_manifest.sha256.json":
        raise RuntimeError("training selection manifest path changed")
    manifest_path = results_root / "selection" / "training_manifest.sha256.json"
    manifest_source = _require_file(manifest_path, label="sealed full training manifest")
    manifest_sha256 = _sha256_file(manifest_source)
    manifest = _read_json(manifest_source, label="sealed full training manifest")
    files = manifest.get("files")
    expected_counts = {
        "rebound_filter_units": 455,
        "new_filter_training_units": 0,
        "inherited_filter_checkpoint_records": 116480,
        "new_filter_training_objective_calls": 0,
        "new_filter_validation_objective_calls": 0,
        "new_filter_gradient_updates": 0,
        "neural_model_units": 9,
        "neural_checkpoints": 270,
        **ZERO_EVALUATION_ACCESS_LEDGER,
    }
    if (
        set(manifest)
        != {
            "schema_version",
            "experiment_id",
            "status",
            "file_count",
            "files",
            "files_canonical_sha256",
            "completion_counts",
            "formal_evaluation_authorized",
        }
        or manifest.get("schema_version") != "tukf09_full_training_manifest_v1"
        or manifest.get("experiment_id") != EXPERIMENT_ID
        or manifest.get("status") != "FULL_TRAINING_MANIFEST_COMPLETE_EVALUATION_HOLD"
        or not isinstance(files, Mapping)
        or manifest.get("file_count") != len(files)
        or manifest.get("files_canonical_sha256") != sha256(canonical_json_bytes(files)[:-1]).hexdigest()
        or manifest.get("completion_counts") != expected_counts
        or manifest.get("formal_evaluation_authorized") is not False
        or selection_seal.get("training_manifest_sha256") != manifest_sha256
        or selection_seal.get("training_manifest_file_count") != len(files)
        or selection_seal.get("completion_counts") != expected_counts
        or audit.get("training_manifest_sha256") != manifest_sha256
        or audit.get("training_tree_file_count") != len(files)
        or audit.get("training_tree_files_canonical_sha256") != sha256(canonical_json_bytes(files)[:-1]).hexdigest()
        or audit.get("completion_counts") != expected_counts
    ):
        raise RuntimeError("sealed full training manifest identity or completion counts changed")
    for relative_text, expected_record in sorted(files.items()):
        relative = PurePosixPath(str(relative_text))
        if (
            relative.is_absolute()
            or "\\" in str(relative_text)
            or any(part in {"", ".", ".."} for part in relative.parts)
            or relative.as_posix() != relative_text
            or not isinstance(expected_record, Mapping)
            or set(expected_record) != {"sha256", "size_bytes"}
        ):
            raise RuntimeError(f"sealed training-tree manifest record changed: {relative_text}")
        member = _require_file(
            results_root.joinpath(*relative.parts),
            label=f"sealed training-tree member {relative_text}",
        )
        actual_record = {
            "sha256": _sha256_file(member),
            "size_bytes": int(member.stat().st_size),
        }
        if expected_record != actual_record:
            raise RuntimeError(f"sealed training-tree member changed: {relative_text}")
    snapshot_record = files.get("training_admission.snapshot.json")
    current_admission_record = {
        "sha256": records["training_admission"]["sha256"],
        "size_bytes": records["training_admission"]["size_bytes"],
    }
    if snapshot_record != current_admission_record:
        raise RuntimeError("training admission snapshot differs from current training admission")
    return {
        "final_manifest_sha256": records[
            "independent_training_selection_final_manifest"
        ]["sha256"],
        "independent_audit_sha256": audit_record["sha256"],
        "training_selection_seal_sha256": current_seal_sha256,
        "training_manifest_sha256": manifest_sha256,
        "training_tree_files_canonical_sha256": sha256(canonical_json_bytes(files)[:-1]).hexdigest(),
        "training_admission_snapshot_sha256": snapshot_record["sha256"],
    }


def _validate_pretraining_identity_chain(
    documents: Mapping[str, Mapping[str, Any]],
    records: Mapping[str, Mapping[str, Any]],
) -> dict[str, str]:
    """Prove current contract/configuration identities are the pretraining identities."""

    training = documents["training_admission"]
    all_scope = documents["all_scope_authorization"]
    unsigned_training = dict(training)
    stored_training_hash = unsigned_training.pop("training_admission_record_sha256", None)
    if stored_training_hash != _canonical_sha256(unsigned_training):
        raise RuntimeError("training admission record self-hash changed")
    unsigned_authorization = dict(all_scope)
    stored_authorization_hash = unsigned_authorization.pop(
        "authorization_record_sha256", None
    )
    if stored_authorization_hash != _canonical_sha256(unsigned_authorization):
        raise RuntimeError("all-scope authorization record self-hash changed")
    if (
        records["all_scope_authorization"] != records["training_authorization"]
        or training.get("authorization", {}).get("file_sha256")
        != records["all_scope_authorization"]["sha256"]
        or training.get("authorization", {}).get("record_sha256")
        != stored_authorization_hash
    ):
        raise RuntimeError("all-scope authorization differs from the training admission")
    frozen = all_scope.get("frozen_inputs")
    if not isinstance(frozen, Mapping):
        raise RuntimeError("all-scope frozen-input identities are absent")
    checks = {
        "scientific_contract": (
            records["scientific_contract"]["sha256"],
            training.get("scientific_contract_sha256"),
            training.get("scientific_contract", {}).get("sha256"),
            frozen.get("scientific_contract", {}).get("sha256"),
        ),
        "independent_preflight_final_manifest": (
            records["independent_preflight_final_manifest"]["sha256"],
            training.get("preflight_final_manifest_sha256"),
            training.get("independent_preflight_final_manifest", {}).get("sha256"),
            frozen.get("independent_preflight_final_manifest", {}).get("sha256"),
        ),
        "formal_training_execution_config": (
            records["formal_training_execution_config"]["sha256"],
            training.get("execution_config", {}).get("sha256"),
            frozen.get("formal_training_execution_config", {}).get("sha256"),
        ),
        "formal_evaluation_config": (
            records["formal_evaluation_config"]["sha256"],
            frozen.get("formal_evaluation_algorithm_config", {}).get("sha256"),
        ),
    }
    verified: dict[str, str] = {}
    for label, values in checks.items():
        if not values or any(value != values[0] for value in values[1:]):
            raise RuntimeError(f"current {label} differs from its pretraining identity")
        verified[label] = str(values[0])
    return verified


def _absolute(path: str | Path) -> Path:
    return Path(os.path.abspath(os.fspath(path)))


def _atomic_write_exclusive(path: Path, content: bytes) -> None:
    destination = _absolute(path)
    if destination.exists() or destination.is_symlink():
        raise FileExistsError(f"authorization destination already exists: {destination}")
    from scripts import tukf09_455_training_common as training_common

    training_common.ensure_no_symlink_components(destination.parent)
    destination.parent.mkdir(parents=True, exist_ok=True)
    training_common.ensure_no_symlink_components(destination.parent)
    temporary = destination.with_name(f".pending-{uuid.uuid4().hex[:10]}")
    try:
        with temporary.open("xb") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        if destination.exists() or destination.is_symlink():
            raise FileExistsError(f"authorization destination appeared: {destination}")
        os.replace(temporary, destination)
    finally:
        if temporary.exists() or temporary.is_symlink():
            temporary.unlink()


def register_evaluation_authorization(
    *,
    bindings: Mapping[str, str | Path],
    fixed_results_root: str | Path,
    evaluation_output_root: str | Path,
    destination: str | Path,
    authorize: bool,
    production: bool = True,
    created_utc: str | None = None,
) -> dict[str, Any]:
    """Bind every fixed input for exactly one later formal-evaluation attempt."""

    if authorize is not True:
        raise PermissionError("explicit one-time formal evaluation authorization is required")
    if set(bindings) != REQUIRED_BINDING_LABELS:
        missing = sorted(REQUIRED_BINDING_LABELS - set(bindings))
        extra = sorted(set(bindings) - REQUIRED_BINDING_LABELS)
        raise ValueError(f"formal evaluation binding set changed; missing={missing}, extra={extra}")

    fixed_root = _absolute(fixed_results_root)
    output_root = _absolute(evaluation_output_root)
    if os.path.commonpath([os.fspath(fixed_root), os.fspath(output_root)]) != os.fspath(fixed_root):
        raise ValueError("formal evaluation output must be inside the fixed results root")
    if output_root.exists() or output_root.is_symlink():
        raise FileExistsError("formal evaluation output already exists before authorization")

    records: dict[str, dict[str, Any]] = {}
    documents: dict[str, Mapping[str, Any]] = {}
    for label in sorted(REQUIRED_BINDING_LABELS):
        path = _require_file(_absolute(bindings[label]), label=label)
        records[label] = {
            "path": os.fspath(path),
            "sha256": _sha256_file(path),
            "size_bytes": int(path.stat().st_size),
        }
        if label in JSON_BINDING_LABELS:
            documents[label] = _read_json(path, label=label)
    _validate_upstream(documents, production=production)
    _validate_algorithm_source_closure(documents, records, production=production)
    training_executable_bindings: dict[str, dict[str, Any]] = {}
    source_anchor_bindings: dict[str, dict[str, Any]] = {}
    independent_selection_bundle: dict[str, Any] = {}
    pretraining_identity_chain: dict[str, str] = {}
    if production:
        training_executable_bindings = _validate_training_executable_closure(
            documents, records
        )
        source_anchor_bindings = _validate_all_contract_source_anchors(documents)
        independent_selection_bundle = _validate_independent_training_selection_bundle(
            documents, records
        )
        pretraining_identity_chain = _validate_pretraining_identity_chain(
            documents, records
        )

    timestamp = created_utc or datetime.now(timezone.utc).isoformat()
    if not isinstance(timestamp, str) or not timestamp:
        raise ValueError("authorization timestamp is invalid")
    unsigned: dict[str, Any] = {
        "schema_version": "tukf09_455_formal_evaluation_authorization_v1",
        "experiment_id": EXPERIMENT_ID,
        "status": "FORMAL_EVALUATION_AUTHORIZED_ONE_TIME",
        "created_utc": timestamp,
        "one_time": True,
        "scope": {
            "evaluation_array_loading": True,
            "filter_prediction_generation": True,
            "neural_prediction_generation": True,
            "metric_computation": True,
            "paired_basin_bootstrap": True,
            "scientific_decision": True,
            "independent_full_prediction_replay": True,
        },
        "fixed_results_root": os.fspath(fixed_root),
        "evaluation_output_root": os.fspath(output_root),
        "output_identity_sha256": _canonical_sha256(
            {
                "experiment_id": EXPERIMENT_ID,
                "fixed_results_root": os.fspath(fixed_root),
                "evaluation_output_root": os.fspath(output_root),
            }
        ),
        "bindings": records,
        "ordered_training_required_executables": list(training_executable_bindings),
        "training_required_executable_bindings": training_executable_bindings,
        "scientific_contract_source_anchor_bindings": source_anchor_bindings,
        "independent_training_selection_bundle": independent_selection_bundle,
        "pretraining_identity_chain": pretraining_identity_chain,
        "gate_implementation_bindings": {
            "hpc/register_tukf09_455_formal_evaluation_authorization_compat_v5.py": {
                "path": os.fspath(_absolute(__file__)),
                "sha256": _sha256_file(_absolute(__file__)),
                "size_bytes": int(_absolute(__file__).stat().st_size),
            },
            "hpc/admit_tukf09_455_formal_evaluation_compat_v5.py": {
                "path": os.fspath(
                    _absolute(__file__).with_name(
                        "admit_tukf09_455_formal_evaluation_compat_v5.py"
                    )
                ),
                "sha256": _sha256_file(
                    _absolute(__file__).with_name(
                        "admit_tukf09_455_formal_evaluation_compat_v5.py"
                    )
                ),
                "size_bytes": int(
                    _absolute(__file__)
                    .with_name("admit_tukf09_455_formal_evaluation_compat_v5.py")
                    .stat()
                    .st_size
                ),
            },
        },
        "selection_sha256": records["training_selection_seal"]["sha256"],
        "independent_selection_sha256": records[
            "independent_training_selection_final_manifest"
        ]["sha256"],
        "evaluation_arrays_loaded": False,
        "evaluation_access_ledger": dict(ZERO_EVALUATION_ACCESS_LEDGER),
    }
    if production:
        unsigned["compatibility_repair"] = compat.authorized_repair()
        unsigned.update(compat.prior_consumed_authorization_fields())
    result = dict(unsigned)
    result["record_sha256"] = _canonical_sha256(unsigned)
    _atomic_write_exclusive(Path(destination), canonical_json_bytes(result))
    return result


def fixed_production_bindings(project_root: str | Path = ROOT) -> dict[str, Path]:
    """Return the only production binding layout admitted by this experiment."""

    root = _absolute(project_root)
    results = root / "results/tukf09_455_basin_zero_validation_target_variance_revision_v1"
    artifacts = root / "artifacts/tukf09_455_basin_zero_validation_target_variance_revision_v1"
    all_scope = artifacts / "authorizations/all_scope_authorization.json"
    return {
        "scientific_contract": root
        / "configs/tukf09_455_basin_zero_validation_target_variance_revision_v1.json",
        "independent_preflight_final_manifest": artifacts
        / "preflight/independent/manifest.final.sha256.json",
        "all_scope_authorization": all_scope,
        # The all-scope record is also the immutable upstream training authorization.
        "training_authorization": all_scope,
        "filter_migration_final_manifest": artifacts
        / "filter_migration_v1/independent/manifest.final.sha256.json",
        "training_admission": artifacts / "training_admission/training_admission.json",
        "filter_installation_final_manifest": results
        / "control/filter_rebinding/independent/manifest.final.sha256.json",
        "training_completion": results / "selection/selected_model_summary.json",
        "training_selection_seal": results / "selection/training_selection.sealed.json",
        "independent_training_selection_final_manifest": results
        / "independent/manifest.final.sha256.json",
        "formal_evaluation_config": root
        / "configs/tukf09_455_basin_zero_validation_target_variance_formal_evaluation_v1.json",
        "formal_training_execution_config": root
        / "configs/tukf09_455_basin_zero_validation_target_variance_formal_training_execution_v1.json",
        "evaluation_common_source": root / "hpc/tukf09_455_evaluation_common_compat_v5.py",
        "evaluator_source": root / "hpc/evaluate_tukf09_455_basin_revision_compat_v5.py",
        "independent_evaluation_verifier_source": root
        / "hpc/verify_tukf09_455_basin_evaluation_compat_v5.py",
        "model_source": root / "scripts/tukf07_information_matched_model.py",
        "filter_runner_source": root / "scripts/run_tukf09_filter_training.py",
        "confirmatory_common_source": root / "scripts/tukf09_confirmatory_common.py",
        "covariance_update_source": root / "scripts/run_aligned_gr4j_da.py",
        "differentiable_ukf_reference_source": root
        / "scripts/run_aligned_gr4j_differentiable_ukf.py",
        "conventional_ukf_source": root
        / "src/global_hydrology/assimilation/conventional_ukf.py",
        "differentiable_filter_engine_source": root
        / "scripts/differentiable_ukf_hbvlite.py",
        "differentiable_hbvlite_model_source": root
        / "src/global_hydrology/models/differentiable_hbv_lite.py",
        "hbvlite_system_model_source": root
        / "src/global_hydrology/models/hbvlite_system_model.py",
        "hbvlite_ukf_adapter_source": root
        / "src/global_hydrology/models/hbvlite_ukf_adapter.py",
        "fixed_results_identity": results / "training_context.json",
    }


def register_evaluation_authorization_from_fixed_artifacts(
    *,
    authorize: bool,
    project_root: str | Path = ROOT,
    created_utc: str | None = None,
) -> dict[str, Any]:
    """Production wrapper with no caller-selected scientific or output paths."""

    if authorize is not True:
        raise PermissionError("explicit one-time formal evaluation authorization is required")
    root = _absolute(project_root)
    config_path = root / (
        "configs/tukf09_455_basin_zero_validation_target_variance_formal_evaluation_v1.json"
    )
    config = _read_json(config_path, label="fixed formal evaluation configuration")
    paths = config.get("paths")
    if not isinstance(paths, Mapping):
        raise RuntimeError("fixed formal evaluation configuration paths changed")
    expected_paths = {
        "formal_evaluation": (
            "results/tukf09_455_basin_zero_validation_target_variance_revision_v1/"
            "evaluation"
        ),
        "evaluation_summary": (
            "results/tukf09_455_basin_zero_validation_target_variance_revision_v1/"
            "evaluation/evaluation_summary.json"
        ),
        "independent_evaluation": (
            "results/tukf09_455_basin_zero_validation_target_variance_revision_v1/"
            "evaluation_independent"
        ),
        "authorization": (
            "artifacts/tukf09_455_basin_zero_validation_target_variance_revision_v1/"
            "authorizations/formal_evaluation_authorization.json"
        ),
    }
    for key, relative in expected_paths.items():
        if paths.get(key) != relative:
            raise RuntimeError(f"fixed formal evaluation {key} path changed")
    return register_evaluation_authorization(
        bindings=fixed_production_bindings(root),
        fixed_results_root=root
        / "results/tukf09_455_basin_zero_validation_target_variance_revision_v1",
        evaluation_output_root=root / expected_paths["formal_evaluation"],
        destination=root / compat.AUTHORIZATION_RELATIVE,
        authorize=True,
        production=True,
        created_utc=created_utc,
    )


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--register-formal-evaluation", action="store_true")
    parser.add_argument("--project-root", type=Path, default=ROOT)
    return parser


def main() -> None:
    arguments = _parser().parse_args()
    result = register_evaluation_authorization_from_fixed_artifacts(
        authorize=bool(arguments.register_formal_evaluation),
        project_root=arguments.project_root,
    )
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()


__all__ = [
    "EXPERIMENT_ID",
    "REQUIRED_BINDING_LABELS",
    "ZERO_EVALUATION_ACCESS_LEDGER",
    "canonical_json_bytes",
    "fixed_production_bindings",
    "record_sha256",
    "register_evaluation_authorization",
    "register_evaluation_authorization_from_fixed_artifacts",
]
