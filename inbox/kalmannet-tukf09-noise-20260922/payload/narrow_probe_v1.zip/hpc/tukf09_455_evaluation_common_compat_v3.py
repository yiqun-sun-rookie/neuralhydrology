"""Pure numerical and capability primitives for the 455-basin formal evaluation.

Importing this module performs no file or data access.  The only public route to
an :class:`EvaluationCapability` revalidates a sealed technical admission and an
active exclusive-lock record.  Evaluation-period loaders recheck both records
immediately before the first raw-source callback.
"""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import json
import math
from pathlib import Path
import struct
from typing import Any, Callable, Mapping, Sequence

import numpy as np


EXPERIMENT_ID = "TUKF09_455_BASIN_ZERO_VALIDATION_TARGET_VARIANCE_REVISION_V1"
EXCLUDED_BASIN_ID = "08202700"
FROZEN_BASIN_COUNT = 455
FROZEN_EVALUATION_DAY_COUNT = 3_287
FROZEN_EVALUATION_START = "1980-10-01"
FROZEN_EVALUATION_END = "1989-09-30"
FROZEN_FIRST_SCORING_INDEX = 365
FROZEN_LEADS = (1, 2, 3)
FROZEN_SEEDS = (0, 1, 2)
FROZEN_SUPPORTS = {1: 2_920, 2: 2_921, 3: 2_922}
FROZEN_RAW_SOURCE_COUNT = 1_020
FROZEN_SEMANTIC_MEMBER_COUNT = 1_365
FROZEN_EVALUATION_SEMANTIC_SHA256 = (
    "fac922d51908376d078a2d3abc023e065a8f785317e059d309dfbbabad37e4a5"
)
FROZEN_ORDERED_BASIN_NEWLINE_SHA256 = (
    "38987bce45fa38ff68f5b067db17e8cb3212d98fecdd106f57d268a130ee8fbd"
)
FROZEN_BOOTSTRAP_SEED = 20_260_811
FROZEN_BOOTSTRAP_RESAMPLES = 10_000
FROZEN_BOOTSTRAP_CONFIDENCE = 0.95
FROZEN_TRAINING_SCALER_ROWS = 1_163_435
DAY_NS = 86_400_000_000_000

ZERO_EVALUATION_ACCESS_LEDGER = {
    "evaluation_array_reads": 0,
    "evaluation_predictions": 0,
    "evaluation_metrics": 0,
    "evaluation_outputs": 0,
}


def canonical_json_bytes(value: Any) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")


def canonical_json_sha256(value: Any) -> str:
    return sha256(canonical_json_bytes(value)).hexdigest()


def sha256_file(path: str | Path) -> str:
    source = _require_unlinked_file(path, label="SHA-256 source")
    digest = sha256()
    with source.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def record_sha256(record: Mapping[str, Any]) -> str:
    payload = dict(record)
    payload.pop("record_sha256", None)
    return canonical_json_sha256(payload)


def _require_unlinked_file(path: str | Path, *, label: str) -> Path:
    candidate = Path(path)
    from scripts import tukf09_455_training_common as training_common

    training_common.ensure_no_symlink_components(candidate)
    if not candidate.is_file() or candidate.is_symlink():
        raise FileNotFoundError(f"{label} is absent, linked, or not a regular file: {candidate}")
    if candidate.stat().st_nlink != 1:
        raise RuntimeError(f"linked {label} is forbidden: {candidate}")
    return candidate


def _read_json_object(path: str | Path, *, label: str) -> dict[str, Any]:
    source = _require_unlinked_file(path, label=label)
    try:
        value = json.loads(source.read_bytes())
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"{label} is not valid JSON: {source}") from exc
    if not isinstance(value, dict):
        raise RuntimeError(f"{label} must contain one JSON object")
    canonical_json_bytes(value)
    return value


_CAPABILITY_ISSUER_TOKEN = object()


@dataclass(frozen=True, slots=True, init=False)
class EvaluationCapability:
    """Proof that the one-time formal evaluation gate and lock were rechecked."""

    admission_path: Path
    admission_sha256: str
    selection_sha256: str
    independent_selection_sha256: str
    lock_path: Path
    lock_sha256: str
    lock_identity: str
    production: bool

    def __init__(
        self,
        *,
        _issuer_token: object | None = None,
        admission_path: Path | None = None,
        admission_sha256: str = "",
        selection_sha256: str = "",
        independent_selection_sha256: str = "",
        lock_path: Path | None = None,
        lock_sha256: str = "",
        lock_identity: str = "",
        production: bool = True,
    ) -> None:
        if _issuer_token is not _CAPABILITY_ISSUER_TOKEN:
            raise PermissionError(
                "EvaluationCapability can only be issued by verified formal-evaluation admission"
            )
        if admission_path is None or lock_path is None:
            raise PermissionError("verified admission and lock paths are required")
        object.__setattr__(self, "admission_path", Path(admission_path))
        object.__setattr__(self, "admission_sha256", str(admission_sha256))
        object.__setattr__(self, "selection_sha256", str(selection_sha256))
        object.__setattr__(
            self, "independent_selection_sha256", str(independent_selection_sha256)
        )
        object.__setattr__(self, "lock_path", Path(lock_path))
        object.__setattr__(self, "lock_sha256", str(lock_sha256))
        object.__setattr__(self, "lock_identity", str(lock_identity))
        object.__setattr__(self, "production", bool(production))


def _verify_zero_access(record: Mapping[str, Any], *, label: str) -> None:
    if record.get("evaluation_arrays_loaded") is not False:
        raise PermissionError(f"{label} does not prove evaluation arrays remained unloaded")
    ledger = record.get("evaluation_access_ledger")
    if ledger != ZERO_EVALUATION_ACCESS_LEDGER:
        raise PermissionError(f"{label} records nonzero or malformed evaluation access")


def _validate_admission_and_lock(
    *,
    admission_path: Path,
    lock_path: Path,
    expected_selection_sha256: str,
    expected_independent_selection_sha256: str,
    expected_admission_sha256: str | None,
    expected_lock_sha256: str | None,
    expected_lock_identity: str | None,
    production: bool,
) -> tuple[dict[str, Any], dict[str, Any], str, str]:
    admission = _read_json_object(admission_path, label="formal evaluation admission")
    admission_file_sha256 = sha256_file(admission_path)
    if expected_admission_sha256 is not None and admission_file_sha256 != expected_admission_sha256:
        raise PermissionError("formal evaluation admission changed after capability issuance")
    if (
        admission.get("experiment_id") != EXPERIMENT_ID
        or admission.get("status") != "FORMAL_EVALUATION_TECHNICALLY_ADMITTED_ONE_TIME"
    ):
        raise PermissionError("formal evaluation admission status or experiment identity changed")
    if production:
        if admission.get("record_sha256") != record_sha256(admission):
            raise PermissionError("formal evaluation admission self-hash is invalid")
        if admission.get("one_time") is not True:
            raise PermissionError("formal evaluation admission is not one-time")
        runtime_identity = admission.get("runtime_environment_identity")
        runtime_sha256 = admission.get("runtime_environment_identity_sha256")
        if (
            not isinstance(runtime_identity, Mapping)
            or runtime_sha256 != canonical_json_sha256(runtime_identity)
        ):
            raise PermissionError("formal evaluation admission runtime identity is invalid")
    _verify_zero_access(admission, label="formal evaluation admission")
    if admission.get("selection_sha256") != expected_selection_sha256:
        raise PermissionError("training selection hash differs from admitted identity")
    if (
        admission.get("independent_selection_sha256")
        != expected_independent_selection_sha256
    ):
        raise PermissionError("independent training selection hash differs from admitted identity")

    lock = _read_json_object(lock_path, label="formal evaluation exclusive lock")
    lock_file_sha256 = sha256_file(lock_path)
    if expected_lock_sha256 is not None and lock_file_sha256 != expected_lock_sha256:
        raise PermissionError("formal evaluation exclusive lock changed")
    if (
        lock.get("experiment_id") != EXPERIMENT_ID
        or lock.get("status") != "FORMAL_EVALUATION_LOCK_HELD"
        or lock.get("admission_sha256") != admission_file_sha256
    ):
        raise PermissionError("formal evaluation exclusive lock is not bound to admission")
    if production and lock.get("runtime_environment_identity_sha256") != admission.get(
        "runtime_environment_identity_sha256"
    ):
        raise PermissionError("formal evaluation lock runtime identity differs from admission")
    lock_identity = lock.get("lock_identity")
    if not isinstance(lock_identity, str) or not lock_identity:
        raise PermissionError("formal evaluation exclusive lock lacks an identity")
    admitted_lock_identity = admission.get("exclusive_lock_identity")
    if admitted_lock_identity not in (None, lock_identity):
        raise PermissionError("formal evaluation admission and exclusive lock identities differ")
    if expected_lock_identity is not None and lock_identity != expected_lock_identity:
        raise PermissionError("formal evaluation exclusive lock identity changed")
    if production:
        bindings = admission.get("bindings")
        if not isinstance(bindings, Mapping):
            raise PermissionError("formal evaluation admission bindings are absent")
        from scripts import admit_tukf09_455_formal_evaluation as admission_module

        admission_module._require_current_runtime_matches_training(
            bindings, expected_admission_identity=admission["runtime_environment_identity"]
        )
    return admission, lock, admission_file_sha256, lock_file_sha256


def issue_evaluation_capability(
    *,
    admission_path: str | Path,
    lock_path: str | Path,
    expected_selection_sha256: str,
    expected_independent_selection_sha256: str,
    production: bool = True,
) -> EvaluationCapability:
    """Issue a capability only after admission, selection, and lock revalidation."""

    if not all(
        isinstance(value, str) and len(value) == 64
        for value in (expected_selection_sha256, expected_independent_selection_sha256)
    ):
        raise ValueError("both sealed selection hashes must be 64-character SHA-256 values")
    admitted, lock, admission_hash, lock_hash = _validate_admission_and_lock(
        admission_path=Path(admission_path),
        lock_path=Path(lock_path),
        expected_selection_sha256=expected_selection_sha256,
        expected_independent_selection_sha256=expected_independent_selection_sha256,
        expected_admission_sha256=None,
        expected_lock_sha256=None,
        expected_lock_identity=None,
        production=production,
    )
    return EvaluationCapability(
        _issuer_token=_CAPABILITY_ISSUER_TOKEN,
        admission_path=Path(admission_path),
        admission_sha256=admission_hash,
        selection_sha256=str(admitted["selection_sha256"]),
        independent_selection_sha256=str(admitted["independent_selection_sha256"]),
        lock_path=Path(lock_path),
        lock_sha256=lock_hash,
        lock_identity=str(lock["lock_identity"]),
        production=production,
    )


def revalidate_evaluation_capability(capability: EvaluationCapability) -> None:
    if not isinstance(capability, EvaluationCapability):
        raise PermissionError("a verified EvaluationCapability is required before evaluation access")
    _validate_admission_and_lock(
        admission_path=capability.admission_path,
        lock_path=capability.lock_path,
        expected_selection_sha256=capability.selection_sha256,
        expected_independent_selection_sha256=capability.independent_selection_sha256,
        expected_admission_sha256=capability.admission_sha256,
        expected_lock_sha256=capability.lock_sha256,
        expected_lock_identity=capability.lock_identity,
        production=capability.production,
    )


def _normalize_basin_id(value: Any) -> str:
    text = str(value).strip()
    if len(text) != 8 or not text.isascii() or not text.isdigit():
        raise ValueError(f"basin identifier must contain exactly eight ASCII digits: {value!r}")
    return text


@dataclass(frozen=True)
class EvaluationPeriod:
    basin_id: str
    dates_ns: np.ndarray
    forcing: np.ndarray
    observations: np.ndarray
    production: bool = True

    def __post_init__(self) -> None:
        basin_id = _normalize_basin_id(self.basin_id)
        if basin_id == EXCLUDED_BASIN_ID:
            raise ValueError(f"excluded zero-validation-variance basin is forbidden: {basin_id}")
        dates = np.ascontiguousarray(self.dates_ns, dtype=np.dtype("<i8"))
        forcing = np.ascontiguousarray(self.forcing, dtype=np.dtype("<f8"))
        observations = np.ascontiguousarray(self.observations, dtype=np.dtype("<f8"))
        if dates.ndim != 1 or forcing.shape != (len(dates), 3):
            raise ValueError("evaluation dates and forcing must have shapes [days] and [days, 3]")
        if observations.shape != (len(dates),):
            raise ValueError("evaluation target must align one-to-one with dates")
        if len(dates) < 1:
            raise ValueError("evaluation period must contain at least one day")
        if len(dates) > 1 and not np.all(np.diff(dates) == DAY_NS):
            raise ValueError("evaluation dates must be strictly ordered consecutive days")
        if not np.isfinite(forcing).all():
            raise FloatingPointError("evaluation forcing contains a non-finite value")
        if not np.isfinite(observations).all() or np.any(observations < 0.0):
            raise ValueError("evaluation target contains a negative or non-finite value")
        if self.production:
            expected_start = int(np.datetime64(FROZEN_EVALUATION_START, "ns").view("i8"))
            expected_end = int(np.datetime64(FROZEN_EVALUATION_END, "ns").view("i8"))
            if (
                len(dates) != FROZEN_EVALUATION_DAY_COUNT
                or int(dates[0]) != expected_start
                or int(dates[-1]) != expected_end
            ):
                raise ValueError("production evaluation dates or 3,287-day support changed")
        dates.setflags(write=False)
        forcing.setflags(write=False)
        observations.setflags(write=False)
        object.__setattr__(self, "basin_id", basin_id)
        object.__setattr__(self, "dates_ns", dates)
        object.__setattr__(self, "forcing", forcing)
        object.__setattr__(self, "observations", observations)
        object.__setattr__(self, "production", bool(self.production))


def semantic_array_identity(name: str, array: np.ndarray, dtype: str) -> dict[str, Any]:
    """Match the preflight semantic identity byte-for-byte."""

    if dtype not in {"<i8", "<f8"}:
        raise ValueError("semantic array dtype must be canonical little-endian int64 or float64")
    canonical = np.ascontiguousarray(array, dtype=np.dtype(dtype))
    name_bytes = str(name).encode("utf-8")
    dtype_bytes = dtype.encode("utf-8")
    digest = sha256()
    digest.update(struct.pack("<Q", len(name_bytes)))
    digest.update(name_bytes)
    digest.update(struct.pack("<Q", len(dtype_bytes)))
    digest.update(dtype_bytes)
    digest.update(struct.pack("<q", canonical.ndim))
    for dimension in canonical.shape:
        digest.update(struct.pack("<q", int(dimension)))
    digest.update(canonical.tobytes(order="C"))
    return {
        "dtype": dtype,
        "shape": [int(value) for value in canonical.shape],
        "sha256": digest.hexdigest(),
    }


def _coerce_period(value: Any, *, basin_id: str, production: bool) -> EvaluationPeriod:
    if isinstance(value, EvaluationPeriod):
        if value.basin_id != basin_id or value.production != production:
            return EvaluationPeriod(
                basin_id=basin_id,
                dates_ns=value.dates_ns,
                forcing=value.forcing,
                observations=value.observations,
                production=production,
            )
        return value
    if isinstance(value, Mapping):
        required = {"dates_ns", "forcing", "observations"}
        if set(value) != required:
            raise ValueError("raw evaluation loader returned an unexpected member set")
        return EvaluationPeriod(
            basin_id=basin_id,
            dates_ns=np.asarray(value["dates_ns"]),
            forcing=np.asarray(value["forcing"]),
            observations=np.asarray(value["observations"]),
            production=production,
        )
    raise TypeError("raw evaluation loader must return EvaluationPeriod or its three arrays")


def load_evaluation_periods(
    capability: EvaluationCapability,
    *,
    basin_ids: Sequence[str],
    semantic_members: Mapping[str, Mapping[str, Any]],
    raw_loader: Callable[[str], Any],
    verify_raw_sources: Callable[[], int | Mapping[str, Any] | Sequence[Any]] | None = None,
    expected_raw_source_count: int | None = None,
    expected_semantic_aggregate_sha256: str | None = None,
    production: bool = True,
) -> dict[str, EvaluationPeriod]:
    """Load evaluation arrays only after rechecking the verified capability.

    The optional raw-source verifier is invoked before the first array loader;
    in production it must prove all 1,020 frozen source files.
    """

    revalidate_evaluation_capability(capability)
    if bool(production) != capability.production:
        raise PermissionError("loader production mode differs from the admitted capability")
    ordered = tuple(_normalize_basin_id(value) for value in basin_ids)
    if not ordered or len(set(ordered)) != len(ordered):
        raise ValueError("evaluation population is empty or contains duplicate basin identifiers")
    if EXCLUDED_BASIN_ID in ordered:
        raise ValueError(f"excluded basin is forbidden: {EXCLUDED_BASIN_ID}")
    if production:
        if len(ordered) != FROZEN_BASIN_COUNT:
            raise ValueError("production evaluation requires exactly 455 basins")
        ordered_digest = sha256("".join(f"{value}\n" for value in ordered).encode("utf-8")).hexdigest()
        if ordered_digest != FROZEN_ORDERED_BASIN_NEWLINE_SHA256:
            raise RuntimeError("ordered 455-basin population identity changed")

    expected_keys = {
        f"{basin_id}/evaluation/{array_name}"
        for basin_id in ordered
        for array_name in ("dates_ns", "forcing", "observations")
    }
    if set(semantic_members) != expected_keys:
        raise RuntimeError("evaluation semantic member set, order-independent coverage, or count changed")
    if production and len(semantic_members) != FROZEN_SEMANTIC_MEMBER_COUNT:
        raise RuntimeError("production evaluation requires exactly 1,365 semantic identities")
    for key, record in semantic_members.items():
        if set(record) != {"dtype", "shape", "sha256"}:
            raise RuntimeError(f"evaluation semantic record schema changed: {key}")
        array_name = key.rsplit("/", 1)[-1]
        dtype = "<i8" if array_name == "dates_ns" else "<f8"
        days = FROZEN_EVALUATION_DAY_COUNT if production else None
        expected_shape = (
            [days, 3] if array_name == "forcing" else [days]
        ) if days is not None else None
        if record.get("dtype") != dtype or (
            expected_shape is not None and record.get("shape") != expected_shape
        ):
            raise RuntimeError(f"evaluation semantic dtype or shape changed: {key}")
        digest = record.get("sha256")
        if not isinstance(digest, str) or len(digest) != 64:
            raise RuntimeError(f"evaluation semantic SHA-256 is malformed: {key}")
    aggregate = sha256(canonical_json_bytes(dict(semantic_members))[:-1]).hexdigest()
    required_aggregate = (
        FROZEN_EVALUATION_SEMANTIC_SHA256
        if production and expected_semantic_aggregate_sha256 is None
        else expected_semantic_aggregate_sha256
    )
    if required_aggregate is not None and aggregate != required_aggregate:
        raise RuntimeError("evaluation semantic aggregate identity changed")

    required_raw_count = (
        FROZEN_RAW_SOURCE_COUNT
        if production and expected_raw_source_count is None
        else expected_raw_source_count
    )
    if verify_raw_sources is None:
        if production:
            raise PermissionError("production evaluation requires a 1,020-file raw-source recheck")
    else:
        verified = verify_raw_sources()
        verified_count = int(verified) if isinstance(verified, (int, np.integer)) else len(verified)
        if required_raw_count is not None and verified_count != int(required_raw_count):
            raise RuntimeError("raw-source verification count changed")

    # The source hash pass may take time; repeat the admission/lock check before arrays.
    revalidate_evaluation_capability(capability)
    result: dict[str, EvaluationPeriod] = {}
    for basin_id in ordered:
        revalidate_evaluation_capability(capability)
        period = _coerce_period(raw_loader(basin_id), basin_id=basin_id, production=production)
        for array_name in ("dates_ns", "forcing", "observations"):
            full_name = f"{basin_id}/evaluation/{array_name}"
            actual = semantic_array_identity(
                full_name,
                getattr(period, array_name),
                "<i8" if array_name == "dates_ns" else "<f8",
            )
            if actual != semantic_members[full_name]:
                raise RuntimeError(f"evaluation semantic identity changed: {full_name}")
        result[basin_id] = period
    if tuple(result) != ordered:
        raise RuntimeError("evaluation loader changed sealed basin order")
    return result


def _readonly_float64(array: Any, *, label: str, shape: tuple[int, ...]) -> np.ndarray:
    value = np.ascontiguousarray(array, dtype=np.float64)
    if value.shape != shape:
        raise ValueError(f"{label} has shape {value.shape}; expected {shape}")
    if np.isinf(value).any():
        raise FloatingPointError(f"{label} contains an infinite value")
    value.setflags(write=False)
    return value


def evaluate_filter(
    period: EvaluationPeriod,
    *,
    initial_state: np.ndarray,
    base_observation_variance: float,
    process_diagonal: np.ndarray,
    observation_noise_multiplier: float,
    runner: Callable[..., Mapping[int, np.ndarray]],
    first_scoring_index: int = FROZEN_FIRST_SCORING_INDEX,
    expected_supports: Mapping[int, int] | None = None,
    production: bool = True,
) -> dict[int, np.ndarray]:
    """Run one filter from a fresh evaluation-period state under selected noise."""

    if bool(production) != period.production:
        raise ValueError("filter production mode and evaluation period differ")
    state = np.ascontiguousarray(initial_state, dtype=np.float64)
    diagonal = np.ascontiguousarray(process_diagonal, dtype=np.float64)
    if state.ndim != 1 or diagonal.shape != state.shape or not np.isfinite(state).all():
        raise ValueError("filter initial state and full process-noise diagonal must align")
    if not np.isfinite(diagonal).all() or np.any(diagonal <= 0.0):
        raise ValueError("selected full process-noise diagonal must be finite and positive")
    if not math.isfinite(float(base_observation_variance)) or base_observation_variance <= 0.0:
        raise ValueError("training-period base observation variance must be finite and positive")
    if (
        not math.isfinite(float(observation_noise_multiplier))
        or observation_noise_multiplier <= 0.0
    ):
        raise ValueError("selected observation-noise multiplier must be finite and positive")
    first = int(first_scoring_index)
    if first < 0 or first >= len(period.dates_ns):
        raise ValueError("first scoring index is outside the evaluation period")
    raw = runner(
        period,
        state.copy(),
        float(base_observation_variance),
        diagonal.copy(),
        float(observation_noise_multiplier),
    )
    if set(raw) != set(FROZEN_LEADS):
        raise RuntimeError("filter runner must return exactly the one-, two-, and three-day leads")
    expected = dict(FROZEN_SUPPORTS if production else (expected_supports or {}))
    result: dict[int, np.ndarray] = {}
    for lead in FROZEN_LEADS:
        values = _readonly_float64(
            raw[lead], label=f"filter lead-{lead} prediction", shape=(len(period.dates_ns),)
        )
        count = int(np.count_nonzero(np.isfinite(values[first:])))
        if lead in expected and count != int(expected[lead]):
            raise RuntimeError(f"filter lead-{lead} support changed: {count}")
        result[lead] = values
    return result


def _scaler_value(scaler: Any, name: str) -> Any:
    if isinstance(scaler, Mapping):
        if name not in scaler:
            raise KeyError(f"training scaler lacks {name}")
        return scaler[name]
    if not hasattr(scaler, name):
        raise AttributeError(f"training scaler lacks {name}")
    return getattr(scaler, name)


def evaluate_neural_seed(
    period: EvaluationPeriod,
    *,
    lead_days: int,
    model: Any,
    scaler: Any,
    selected_checkpoint_sha256: str,
    current_checkpoint_sha256: str,
    sequence_length: int = 365,
    first_scoring_index: int = FROZEN_FIRST_SCORING_INDEX,
    batch_size: int = 256,
    production: bool = True,
) -> dict[int, np.ndarray]:
    """Predict one selected neural seed with zero state for every causal window."""

    import torch  # Deliberately lazy: import alone never opens a checkpoint or array.

    lead = int(lead_days)
    if lead not in FROZEN_LEADS:
        raise ValueError("neural lead must be one, two, or three days")
    if bool(production) != period.production:
        raise ValueError("neural production mode and evaluation period differ")
    if (
        not isinstance(selected_checkpoint_sha256, str)
        or len(selected_checkpoint_sha256) != 64
        or selected_checkpoint_sha256 != current_checkpoint_sha256
    ):
        raise PermissionError("selected neural checkpoint hash changed")
    if int(getattr(model, "lead_days", lead)) != lead:
        raise ValueError("selected neural model lead differs from evaluation lead")
    length = int(sequence_length)
    first = int(first_scoring_index)
    batch = int(batch_size)
    if length <= 0 or batch <= 0 or first < length - 1 or first >= len(period.dates_ns):
        raise ValueError("neural sequence, batch, or first scoring index is invalid")
    if production and (length != 365 or first != FROZEN_FIRST_SCORING_INDEX or batch != 256):
        raise ValueError("production neural inference settings changed")

    forcing_center = np.asarray(_scaler_value(scaler, "forcing_center"), dtype=np.float64)
    forcing_scale = np.asarray(_scaler_value(scaler, "forcing_scale"), dtype=np.float64)
    discharge_center = float(_scaler_value(scaler, "discharge_center"))
    discharge_scale = float(_scaler_value(scaler, "discharge_scale"))
    if forcing_center.shape != (3,) or forcing_scale.shape != (3,):
        raise ValueError("training forcing scaler must have three features")
    if (
        not np.isfinite(forcing_center).all()
        or not np.isfinite(forcing_scale).all()
        or np.any(forcing_scale <= 0.0)
        or not math.isfinite(discharge_center)
        or not math.isfinite(discharge_scale)
        or discharge_scale <= 0.0
    ):
        raise ValueError("training-only scaler contains invalid values")
    normalization_scope = getattr(
        scaler,
        "normalization_scope",
        scaler.get("normalization_scope") if isinstance(scaler, Mapping) else None,
    )
    if normalization_scope not in (None, "training_only_global_population_statistics"):
        raise PermissionError("neural evaluation scaler was not fitted on training data only")
    training_rows = getattr(
        scaler,
        "training_row_count",
        scaler.get("training_row_count") if isinstance(scaler, Mapping) else None,
    )
    if production and int(training_rows) != FROZEN_TRAINING_SCALER_ROWS:
        raise PermissionError("training-only scaler row count changed")

    parameters = list(model.parameters()) if hasattr(model, "parameters") else []
    device = parameters[0].device if parameters else torch.device("cpu")
    hidden_size = int(getattr(model, "hidden_size", 0))
    if hidden_size <= 0:
        raise ValueError("selected neural model lacks a positive hidden-state size")
    model.eval()
    target_indices = np.arange(first, len(period.dates_ns), dtype=np.int64)
    aligned = np.full(len(period.dates_ns), np.nan, dtype=np.float64)
    with torch.no_grad():
        for cursor in range(0, len(target_indices), batch):
            targets = target_indices[cursor : cursor + batch]
            offsets = np.arange(length, dtype=np.int64) - (length - 1)
            forcing_indices = targets[:, None] + offsets[None, :]
            if np.any(forcing_indices < 0) or np.any(forcing_indices >= len(period.dates_ns)):
                raise RuntimeError("neural window exceeds evaluation reset-period bounds")
            discharge_indices = forcing_indices - lead
            observed = discharge_indices >= 0
            origins = np.broadcast_to(
                targets[:, None] - lead, discharge_indices.shape
            )
            if np.any(discharge_indices[observed] > origins[observed]):
                raise RuntimeError("lagged discharge reads later than target minus lead time")
            forcing_windows = (
                period.forcing[forcing_indices] - forcing_center[None, None, :]
            ) / forcing_scale[None, None, :]
            lagged = np.full((len(targets), length, 1), np.nan, dtype=np.float64)
            row_indices, column_indices = np.nonzero(observed)
            lagged[row_indices, column_indices, 0] = period.observations[
                discharge_indices[row_indices, column_indices]
            ]
            finite_lagged = np.isfinite(lagged)
            lagged[finite_lagged] = (
                lagged[finite_lagged] - discharge_center
            ) / discharge_scale
            if not np.isfinite(forcing_windows).all() or np.isinf(lagged).any():
                raise FloatingPointError("standardized neural evaluation window is invalid")
            forcing_tensor = torch.as_tensor(
                forcing_windows, dtype=torch.float32, device=device
            )
            lagged_tensor = torch.as_tensor(lagged, dtype=torch.float32, device=device)
            hidden = torch.zeros(
                (1, len(targets), hidden_size), dtype=torch.float32, device=device
            )
            memory = torch.zeros_like(hidden)
            output = model(forcing_tensor, lagged_tensor, hidden, memory)
            if not isinstance(output, Mapping) or "y_hat" not in output:
                raise RuntimeError("selected neural model did not return y_hat")
            standardized = output["y_hat"]
            if standardized.shape != (len(targets), length, 1):
                raise RuntimeError("selected neural model output shape changed")
            raw = (
                standardized[:, -1, 0] * discharge_scale + discharge_center
            ).detach().cpu().to(torch.float64).numpy()
            if not np.isfinite(raw).all():
                raise FloatingPointError("neural evaluation prediction is non-finite")
            aligned[targets] = raw
    if int(np.count_nonzero(np.isfinite(aligned[first:]))) != len(period.dates_ns) - first:
        raise RuntimeError("neural evaluation prediction support changed")
    aligned.setflags(write=False)
    return {lead: aligned}


def three_seed_ensemble(seed_predictions: Sequence[np.ndarray]) -> np.ndarray:
    if len(seed_predictions) != 3:
        raise ValueError("the frozen neural ensemble requires exactly three seed predictions")
    arrays = [np.asarray(value, dtype=np.float64) for value in seed_predictions]
    if any(array.shape != arrays[0].shape for array in arrays[1:]):
        raise ValueError("three neural seed prediction shapes differ")
    if any(np.isinf(array).any() for array in arrays):
        raise FloatingPointError("neural seed prediction contains infinity")
    result = np.mean(np.stack(arrays, axis=0), axis=0, dtype=np.float64)
    result = np.ascontiguousarray(result, dtype=np.float64)
    result.setflags(write=False)
    return result


class UndefinedEvaluationTargetVariance(RuntimeError):
    def __init__(
        self,
        *,
        basin_id: str | None,
        lead_days: int,
        support_count: int,
        denominator: float,
    ) -> None:
        self.basin_id = basin_id
        self.lead_days = int(lead_days)
        self.support_count = int(support_count)
        self.denominator = float(denominator)
        super().__init__(
            "formal evaluation target variance is non-finite or nonpositive "
            f"for basin={basin_id!r}, lead_days={lead_days}, "
            f"support_count={support_count}, denominator={denominator!r}"
        )

    def evidence(self) -> dict[str, Any]:
        denominator: float | None = self.denominator if math.isfinite(self.denominator) else None
        return {
            "schema_version": "tukf09_455_evaluation_target_variance_failure_v1",
            "experiment_id": EXPERIMENT_ID,
            "status": "FORMAL_EVALUATION_STOPPED_UNDEFINED_TARGET_VARIANCE",
            "basin_id": self.basin_id,
            "lead_days": self.lead_days,
            "support_count": self.support_count,
            "target_denominator": denominator,
            "population_aggregation_performed": False,
            "evaluation_summary_published": False,
            "scientific_decision_published": False,
            "post_hoc_basin_exclusion_permitted": False,
        }


@dataclass(frozen=True)
class ScoreRecord:
    lead_days: int
    mask: np.ndarray
    support_count: int
    target_denominator: float
    filter_nse: float
    ensemble_nse: float
    seed_nse: tuple[float, float, float]


def _nse_on_mask(target: np.ndarray, prediction: np.ndarray, mask: np.ndarray, denominator: float) -> float:
    residual = np.asarray(prediction[mask] - target[mask], dtype=np.float64)
    numerator = float(np.sum(np.square(residual), dtype=np.float64))
    value = 1.0 - numerator / denominator
    if not math.isfinite(numerator) or not math.isfinite(value):
        raise FloatingPointError("evaluation Nash-Sutcliffe efficiency is non-finite")
    return float(value)


def common_mask_and_nse(
    target: np.ndarray,
    filter_prediction: np.ndarray,
    ensemble_prediction: np.ndarray,
    seed_predictions: Sequence[np.ndarray],
    *,
    lead_days: int,
    first_scoring_index: int = FROZEN_FIRST_SCORING_INDEX,
    expected_count: int | None = None,
    basin_id: str | None = None,
) -> ScoreRecord:
    """Compute all system and seed scores on one exact per-lead common mask."""

    lead = int(lead_days)
    if lead not in FROZEN_LEADS:
        raise ValueError("score lead must be one, two, or three days")
    target_array = np.asarray(target, dtype=np.float64)
    filter_array = np.asarray(filter_prediction, dtype=np.float64)
    ensemble_array = np.asarray(ensemble_prediction, dtype=np.float64)
    if target_array.ndim != 1 or filter_array.shape != target_array.shape or ensemble_array.shape != target_array.shape:
        raise ValueError("target, filter, and ensemble predictions must be aligned vectors")
    if len(seed_predictions) != 3:
        raise ValueError("supplemental neural scoring requires exactly three seeds")
    seed_arrays = [np.asarray(value, dtype=np.float64) for value in seed_predictions]
    if any(value.shape != target_array.shape for value in seed_arrays):
        raise ValueError("neural seed predictions do not align with the common target")
    first = int(first_scoring_index)
    if first < 0 or first >= len(target_array):
        raise ValueError("first scoring index is outside the score vectors")
    index_gate = np.arange(len(target_array), dtype=np.int64) >= first
    mask = (
        index_gate
        & np.isfinite(target_array)
        & np.isfinite(filter_array)
        & np.isfinite(ensemble_array)
    )
    count = int(np.count_nonzero(mask))
    if expected_count is not None and count != int(expected_count):
        raise RuntimeError(f"lead-{lead} exact common-mask support changed: {count}")
    if count < 1:
        raise UndefinedEvaluationTargetVariance(
            basin_id=basin_id,
            lead_days=lead,
            support_count=count,
            denominator=0.0,
        )
    selected_target = np.asarray(target_array[mask], dtype=np.float64)
    mean = float(np.mean(selected_target, dtype=np.float64))
    centered = np.asarray(selected_target - mean, dtype=np.float64)
    denominator = float(np.sum(np.square(centered), dtype=np.float64))
    if not math.isfinite(denominator) or denominator <= 0.0:
        raise UndefinedEvaluationTargetVariance(
            basin_id=basin_id,
            lead_days=lead,
            support_count=count,
            denominator=denominator,
        )
    seed_scores = tuple(
        _nse_on_mask(target_array, value, mask, denominator) for value in seed_arrays
    )
    mask = np.ascontiguousarray(mask, dtype=np.bool_)
    mask.setflags(write=False)
    return ScoreRecord(
        lead_days=lead,
        mask=mask,
        support_count=count,
        target_denominator=denominator,
        filter_nse=_nse_on_mask(target_array, filter_array, mask, denominator),
        ensemble_nse=_nse_on_mask(target_array, ensemble_array, mask, denominator),
        seed_nse=(float(seed_scores[0]), float(seed_scores[1]), float(seed_scores[2])),
    )


@dataclass(frozen=True)
class BootstrapRecord:
    population_count: int
    population_median: float
    confidence_level: float
    lower: float
    upper: float
    seed: int
    resamples: int
    statistic: str = "median"
    quantile_method: str = "linear"


def paired_basin_bootstrap(
    values: Sequence[float] | np.ndarray,
    *,
    seed: int = FROZEN_BOOTSTRAP_SEED,
    resamples: int = FROZEN_BOOTSTRAP_RESAMPLES,
    confidence_level: float = FROZEN_BOOTSTRAP_CONFIDENCE,
    expected_count: int | None = None,
) -> BootstrapRecord:
    array = np.asarray(values, dtype=np.float64)
    if array.ndim != 1 or len(array) < 1 or not np.isfinite(array).all():
        raise ValueError("paired-basin bootstrap values must be one finite vector")
    if expected_count is not None and len(array) != int(expected_count):
        raise ValueError("paired-basin bootstrap population count changed")
    count = int(resamples)
    confidence = float(confidence_level)
    if count <= 0 or not 0.0 < confidence < 1.0:
        raise ValueError("bootstrap resample count and confidence level are invalid")
    generator = np.random.default_rng(int(seed))
    medians = np.empty(count, dtype=np.float64)
    # Chunking preserves the exact default_rng draw order while bounding memory.
    cursor = 0
    chunk_size = max(1, min(count, 1024))
    while cursor < count:
        take = min(chunk_size, count - cursor)
        indices = generator.integers(0, len(array), size=(take, len(array)))
        medians[cursor : cursor + take] = np.median(array[indices], axis=1)
        cursor += take
    tail = (1.0 - confidence) / 2.0
    lower, upper = np.quantile(medians, [tail, 1.0 - tail], method="linear")
    return BootstrapRecord(
        population_count=len(array),
        population_median=float(np.median(array)),
        confidence_level=confidence,
        lower=float(lower),
        upper=float(upper),
        seed=int(seed),
        resamples=count,
    )


def decision_from_interval(lower: float, upper: float) -> tuple[str, bool]:
    lower_value = float(lower)
    upper_value = float(upper)
    if not math.isfinite(lower_value) or not math.isfinite(upper_value) or lower_value > upper_value:
        raise ValueError("bootstrap interval is invalid")
    if lower_value >= 0.01:
        return "FILTER_PRACTICALLY_EXCEEDS_NEURAL_ENSEMBLE", True
    if lower_value >= -0.01:
        return (
            "FILTER_REACHES_NEURAL_ENSEMBLE_WITHOUT_PROVEN_PRACTICAL_SUPERIORITY",
            False,
        )
    if upper_value <= -0.01:
        return "FILTER_BELOW_NEURAL_ENSEMBLE", False
    return "INCONCLUSIVE", False


__all__ = [
    "BootstrapRecord",
    "EvaluationCapability",
    "EvaluationPeriod",
    "ScoreRecord",
    "UndefinedEvaluationTargetVariance",
    "canonical_json_bytes",
    "canonical_json_sha256",
    "common_mask_and_nse",
    "decision_from_interval",
    "evaluate_filter",
    "evaluate_neural_seed",
    "issue_evaluation_capability",
    "load_evaluation_periods",
    "paired_basin_bootstrap",
    "record_sha256",
    "revalidate_evaluation_capability",
    "semantic_array_identity",
    "sha256_file",
    "three_seed_ensemble",
]
