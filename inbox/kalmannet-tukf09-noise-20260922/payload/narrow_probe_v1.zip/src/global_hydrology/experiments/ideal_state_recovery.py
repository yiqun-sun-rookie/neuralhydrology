"""Known-truth initial-state recovery for a frozen neural state-space model.

The experiment deliberately uses one fully observed latent state.  Truth,
open loop, the conventional unscented Kalman filter, and KalmanNet all call the
same frozen ``DLSSMSystemModel``.  The only estimator mismatch is its initial
state, which makes failure attributable to filter wiring or learning rather
than model, forcing, parameter, or observability mismatch.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, replace
import hashlib
import json
import math
from pathlib import Path
from typing import Iterable, Mapping

import numpy as np
import torch

from global_hydrology.models.dl_ssm import DLSSMConfig, DLSSMSystemModel
from global_hydrology.models.kalman_net import KalmanNet, KalmanNetConfig


DTYPE = torch.float64
DEVICE = torch.device("cpu")


@dataclass(frozen=True)
class IdealRecoveryConfig:
    """Frozen contract for a known-truth recovery experiment."""

    schema_version: str = "ideal_neural_state_recovery_v1"
    experiment_id: str = "ISR01"
    dtype: str = "float64"
    device: str = "cpu"
    sequence_length: int = 24
    n_train_cases: int = 64
    n_evaluation_cases: int = 32
    training_seed: int = 20260801
    evaluation_seed: int = 20260802
    knet_seeds: tuple[int, ...] = (11, 22, 33)
    knet_epochs: int = 120
    knet_learning_rate: float = 1e-3
    process_variance: float = 1e-10
    observation_variance: float = 1e-8
    initial_variance: float = 1.0

    def validate(self) -> None:
        supported_contracts = {
            "ideal_neural_state_recovery_v1": "ISR01",
            "ideal_neural_state_recovery_v2_100step": "ISR02",
        }
        expected_experiment_id = supported_contracts.get(self.schema_version)
        if expected_experiment_id is None:
            raise ValueError("unsupported ideal-recovery config schema")
        if self.experiment_id != expected_experiment_id:
            raise ValueError(
                "schema_version and experiment_id do not identify the same "
                "frozen experiment contract"
            )
        if self.dtype != "float64" or self.device != "cpu":
            raise ValueError("version 1 requires float64 on cpu")
        if self.sequence_length < 4:
            raise ValueError("sequence_length must be at least four")
        if self.n_train_cases < 1 or self.n_evaluation_cases < 1:
            raise ValueError("training and evaluation case counts must be positive")
        if not self.knet_seeds or len(set(self.knet_seeds)) != len(self.knet_seeds):
            raise ValueError("knet_seeds must be nonempty and unique")
        if self.knet_epochs < 1 or self.knet_learning_rate <= 0.0:
            raise ValueError("KalmanNet training budget must be positive")
        for name in ("process_variance", "observation_variance", "initial_variance"):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be positive and finite")

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["knet_seeds"] = list(self.knet_seeds)
        return payload

    @classmethod
    def from_json(cls, path: str | Path) -> "IdealRecoveryConfig":
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        payload["knet_seeds"] = tuple(int(seed) for seed in payload["knet_seeds"])
        config = cls(**payload)
        config.validate()
        return config


@dataclass(frozen=True)
class IdealCases:
    """Synthetic cases with truth hidden from the filter interfaces."""

    forcing: torch.Tensor
    observations: torch.Tensor
    truth_states: torch.Tensor
    true_initial_state: torch.Tensor
    estimated_initial_state: torch.Tensor
    model_contract_hash: str
    estimator_contract_hash: str
    split: str

    @property
    def initial_rmse(self) -> float:
        error = self.estimated_initial_state - self.true_initial_state
        return float(torch.sqrt(torch.mean(error.square())).detach().cpu())

    def with_observations_after(self, cutoff: int, value: float) -> "IdealCases":
        if cutoff < 0 or cutoff >= self.observations.shape[1]:
            raise ValueError("cutoff is outside the observation sequence")
        changed = self.observations.clone()
        changed[:, cutoff + 1 :, :] = float(value)
        return replace(self, observations=changed)


@dataclass(frozen=True)
class OpenLoopTrace:
    states: torch.Tensor
    observations: torch.Tensor


@dataclass(frozen=True)
class AssimilationTrace:
    prior_states: torch.Tensor
    posterior_states: torch.Tensor
    predicted_observations: torch.Tensor
    innovations: torch.Tensor
    gains: torch.Tensor
    posterior_covariances: torch.Tensor
    truth_states: torch.Tensor
    forward_evolution_features: torch.Tensor
    forward_update_features: torch.Tensor

    @property
    def posterior_rmse_by_time(self) -> torch.Tensor:
        return torch.sqrt(torch.mean(
            (self.posterior_states - self.truth_states).square(), dim=(0, 2)))

    @property
    def prior_rmse_by_time(self) -> torch.Tensor:
        return torch.sqrt(torch.mean(
            (self.prior_states - self.truth_states).square(), dim=(0, 2)))


@dataclass(frozen=True)
class ExperimentResult:
    output_dir: Path
    verdict: str
    metrics: dict


def state_dict_sha256(model: torch.nn.Module) -> str:
    """Hash tensor keys, metadata, and bytes without serialization timestamps."""

    digest = hashlib.sha256()
    for name, tensor in sorted(model.state_dict().items()):
        value = tensor.detach().cpu().contiguous()
        digest.update(name.encode("utf-8"))
        digest.update(str(value.dtype).encode("ascii"))
        digest.update(json.dumps(list(value.shape)).encode("ascii"))
        digest.update(value.numpy().tobytes(order="C"))
    return digest.hexdigest()


def build_ideal_neural_model() -> DLSSMSystemModel:
    """Build the actual project neural SSM with deterministic observable weights."""

    config = DLSSMConfig(
        state_dim=1,
        obs_dim=1,
        forcing_dim=1,
        static_dim=1,
        static_embed_dim=1,
        init_hidden=1,
        obs_hidden=2,
        dropout=0.0,
        use_static_in_transition=False,
    )
    model = DLSSMSystemModel(config).to(device=DEVICE, dtype=DTYPE)
    with torch.no_grad():
        for parameter in model.parameters():
            parameter.zero_()

        # PyTorch GRU gate order is reset, update, candidate.  The nearly-one
        # reset and nearly-zero update gates give x_t ~= tanh(.8*x_{t-1}+.2*u_t).
        model.gru_cell.bias_ih[0] = 20.0
        model.gru_cell.bias_ih[1] = -20.0
        model.gru_cell.weight_ih[2, 0] = 0.2
        model.gru_cell.weight_hh[2, 0] = 0.8

        first = model.obs_net[0]
        last = model.obs_net[3]
        first.weight[:, 0] = torch.tensor([1.0, -1.0], dtype=DTYPE)
        last.weight[0, :] = torch.tensor([1.0, -1.0], dtype=DTYPE)

        model.prior_q.fill_(1.0)
        model.prior_state_cov.fill_(1.0)
        model.prior_r.fill_(1.0)

    model.eval()
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    return model


def _validate_sequence_inputs(forcing: torch.Tensor, initial_state: torch.Tensor) -> None:
    if forcing.ndim != 3 or forcing.shape[2] != 1:
        raise ValueError("forcing must have shape [case, time, 1]")
    if initial_state.shape != (forcing.shape[0], 1):
        raise ValueError("initial_state must have shape [case, 1]")
    if forcing.dtype != DTYPE or initial_state.dtype != DTYPE:
        raise ValueError("ideal experiment tensors must use float64")
    if not torch.isfinite(forcing).all() or not torch.isfinite(initial_state).all():
        raise ValueError("forcing and initial_state must be finite")


def rollout_open_loop(
    model: DLSSMSystemModel,
    forcing: torch.Tensor,
    initial_state: torch.Tensor,
) -> OpenLoopTrace:
    """Roll out the frozen model without reading observations."""

    _validate_sequence_inputs(forcing, initial_state)
    state = initial_state
    states: list[torch.Tensor] = []
    observations: list[torch.Tensor] = []
    for time_index in range(forcing.shape[1]):
        state = model.f(state, forcing[:, time_index, :])
        observation = model.h(state)
        states.append(state)
        observations.append(observation)
    return OpenLoopTrace(
        states=torch.stack(states, dim=1),
        observations=torch.stack(observations, dim=1),
    )


def generate_cases(
    model: DLSSMSystemModel,
    config: IdealRecoveryConfig,
    *,
    split: str,
) -> IdealCases:
    """Generate disjoint deterministic training or evaluation trajectories."""

    config.validate()
    if split == "training":
        count, seed = config.n_train_cases, config.training_seed
    elif split == "evaluation":
        count, seed = config.n_evaluation_cases, config.evaluation_seed
    else:
        raise ValueError("split must be 'training' or 'evaluation'")

    generator = torch.Generator(device="cpu")
    generator.manual_seed(seed)
    time = torch.arange(config.sequence_length, dtype=DTYPE).reshape(1, -1, 1)
    phase = 2.0 * math.pi * torch.rand((count, 1, 1), generator=generator, dtype=DTYPE)
    amplitude = 0.35 + 0.30 * torch.rand((count, 1, 1), generator=generator, dtype=DTYPE)
    secondary = 0.08 + 0.08 * torch.rand((count, 1, 1), generator=generator, dtype=DTYPE)
    forcing = (
        amplitude * torch.sin((2.0 * math.pi / 12.0) * time + phase)
        + secondary * torch.cos((2.0 * math.pi / 5.0) * time - phase)
    )

    true_initial = -0.4 + 0.8 * torch.rand((count, 1), generator=generator, dtype=DTYPE)
    magnitude = 0.5 + 0.4 * torch.rand((count, 1), generator=generator, dtype=DTYPE)
    sign = torch.where(
        torch.rand((count, 1), generator=generator, dtype=DTYPE) < 0.5,
        torch.tensor(-1.0, dtype=DTYPE),
        torch.tensor(1.0, dtype=DTYPE),
    )
    estimated_initial = true_initial + sign * magnitude

    with torch.no_grad():
        truth = rollout_open_loop(model, forcing, true_initial)
    contract_hash = state_dict_sha256(model)
    return IdealCases(
        forcing=forcing,
        observations=truth.observations,
        truth_states=truth.states,
        true_initial_state=true_initial,
        estimated_initial_state=estimated_initial,
        model_contract_hash=contract_hash,
        estimator_contract_hash=contract_hash,
        split=split,
    )


def _positive_covariance(matrix: torch.Tensor, floor: float = 1e-14) -> torch.Tensor:
    symmetric = 0.5 * (matrix + matrix.T)
    eigenvalues, eigenvectors = torch.linalg.eigh(symmetric)
    eigenvalues = torch.clamp(eigenvalues, min=floor)
    return eigenvectors @ torch.diag(eigenvalues) @ eigenvectors.T


def run_conventional_ukf(
    model: DLSSMSystemModel,
    cases: IdealCases,
    config: IdealRecoveryConfig,
) -> AssimilationTrace:
    """Run a conventional causal Merwe-sigma-point unscented Kalman filter."""

    from scripts.run_aligned_gr4j_da import (  # Local audited primitives.
        constrained_covariance_update,
        merwe_sigma_points,
    )

    config.validate()
    case_count, time_count, state_dim = cases.truth_states.shape
    if state_dim != 1:
        raise ValueError("version 1 conventional filter requires one fully observed state")
    prior = torch.empty_like(cases.truth_states)
    posterior = torch.empty_like(cases.truth_states)
    prediction = torch.empty_like(cases.observations)
    innovation = torch.empty_like(cases.observations)
    gains = torch.empty((case_count, time_count, 1, 1), dtype=DTYPE)
    covariances = torch.empty((case_count, time_count, 1, 1), dtype=DTYPE)

    with torch.no_grad():
        for case_index in range(case_count):
            mean = cases.estimated_initial_state[case_index].clone()
            covariance = torch.eye(1, dtype=DTYPE) * config.initial_variance
            for time_index in range(time_count):
                sigma, mean_weight, covariance_weight = merwe_sigma_points(
                    mean,
                    covariance,
                    alpha=0.3,
                    beta=2.0,
                    kappa=0.0,
                )
                control = cases.forcing[case_index, time_index].expand(sigma.shape[0], 1)
                propagated = model.f(sigma, control)
                observed_sigma = model.h(propagated)
                prior_mean = torch.sum(mean_weight[:, None] * propagated, dim=0)
                observation_mean = torch.sum(mean_weight[:, None] * observed_sigma, dim=0)
                state_deviation = propagated - prior_mean
                observation_deviation = observed_sigma - observation_mean
                prior_covariance = torch.einsum(
                    "s,si,sj->ij",
                    covariance_weight,
                    state_deviation,
                    state_deviation,
                )
                prior_covariance = _positive_covariance(
                    prior_covariance + torch.eye(1, dtype=DTYPE) * config.process_variance)
                cross_covariance = torch.einsum(
                    "s,si,sj->ij",
                    covariance_weight,
                    state_deviation,
                    observation_deviation,
                )
                innovation_covariance = torch.einsum(
                    "s,si,sj->ij",
                    covariance_weight,
                    observation_deviation,
                    observation_deviation,
                )
                innovation_covariance = _positive_covariance(
                    innovation_covariance
                    + torch.eye(1, dtype=DTYPE) * config.observation_variance)
                gain = torch.linalg.solve(
                    innovation_covariance.T, cross_covariance.T).T

                # The prior is now complete.  The current observation first enters here.
                current_innovation = (
                    cases.observations[case_index, time_index] - observation_mean)
                mean = prior_mean + (gain @ current_innovation[:, None]).squeeze(1)
                covariance = constrained_covariance_update(
                    prior_covariance,
                    cross_covariance,
                    innovation_covariance,
                    gain,
                )
                covariance = _positive_covariance(covariance)

                prior[case_index, time_index] = prior_mean
                posterior[case_index, time_index] = mean
                prediction[case_index, time_index] = observation_mean
                innovation[case_index, time_index] = current_innovation
                gains[case_index, time_index] = gain
                covariances[case_index, time_index] = covariance

    zeros = torch.zeros_like(cases.truth_states)
    return AssimilationTrace(
        prior_states=prior,
        posterior_states=posterior,
        predicted_observations=prediction,
        innovations=innovation,
        gains=gains,
        posterior_covariances=covariances,
        truth_states=cases.truth_states,
        forward_evolution_features=zeros,
        forward_update_features=zeros,
    )


def _build_kalmannet(config: IdealRecoveryConfig, seed: int) -> KalmanNet:
    torch.manual_seed(int(seed))
    knet_config = KalmanNetConfig(
        m=1,
        n=1,
        in_mult_KNet=4,
        out_mult_KNet=4,
        d_hidden_Q=8,
        d_hidden_Sigma=8,
        d_hidden_S=8,
        diff_guard_enable=True,
        diff_guard_obs=10.0,
        diff_guard_state=10.0,
    )
    network = KalmanNet(knet_config, device=DEVICE).to(device=DEVICE, dtype=DTYPE)
    with torch.no_grad():
        network.FC2[-1].weight.zero_()
        network.FC2[-1].bias.zero_()
    return network


def run_kalmannet(
    model: DLSSMSystemModel,
    knet: KalmanNet,
    cases: IdealCases,
) -> AssimilationTrace:
    """Run KalmanNet with explicit causal and previous-update bookkeeping."""

    case_count, time_count, state_dim = cases.truth_states.shape
    if state_dim != 1 or knet.m != 1 or knet.n != 1:
        raise ValueError("version 1 KalmanNet path requires m=n=1")
    knet.init_hidden(case_count, model.prior_q, model.prior_state_cov, model.prior_r)

    previous_posterior = cases.estimated_initial_state
    posterior_before_previous = previous_posterior.clone()
    previous_prior = previous_posterior.clone()
    previous_observation = model.h(previous_posterior)

    priors: list[torch.Tensor] = []
    posteriors: list[torch.Tensor] = []
    predictions: list[torch.Tensor] = []
    innovations: list[torch.Tensor] = []
    gains: list[torch.Tensor] = []
    evolution_features: list[torch.Tensor] = []
    update_features: list[torch.Tensor] = []

    for time_index in range(time_count):
        current_prior = model.f(
            previous_posterior,
            cases.forcing[:, time_index, :],
        )
        current_prediction = model.h(current_prior)

        # Current observation is first consumed after the prior and prediction exist.
        current_observation = cases.observations[:, time_index, :]
        observation_change = current_observation - previous_observation
        current_innovation = current_observation - current_prediction
        forward_evolution = previous_posterior - posterior_before_previous
        previous_analysis_update = previous_posterior - previous_prior
        gain = knet.compute_gain(
            observation_change,
            current_innovation,
            forward_evolution,
            previous_analysis_update,
        )
        correction = torch.bmm(gain, current_innovation.unsqueeze(2)).squeeze(2)
        current_posterior = current_prior + correction

        priors.append(current_prior)
        posteriors.append(current_posterior)
        predictions.append(current_prediction)
        innovations.append(current_innovation)
        gains.append(gain)
        evolution_features.append(forward_evolution)
        update_features.append(previous_analysis_update)

        posterior_before_previous = previous_posterior
        previous_posterior = current_posterior
        previous_prior = current_prior
        previous_observation = current_observation

    posterior_states = torch.stack(posteriors, dim=1)
    return AssimilationTrace(
        prior_states=torch.stack(priors, dim=1),
        posterior_states=posterior_states,
        predicted_observations=torch.stack(predictions, dim=1),
        innovations=torch.stack(innovations, dim=1),
        gains=torch.stack(gains, dim=1),
        posterior_covariances=torch.zeros(
            (case_count, time_count, 1, 1), dtype=DTYPE),
        truth_states=cases.truth_states,
        forward_evolution_features=torch.stack(evolution_features, dim=1),
        forward_update_features=torch.stack(update_features, dim=1),
    )


def train_kalmannet(
    model: DLSSMSystemModel,
    training_cases: IdealCases,
    config: IdealRecoveryConfig,
    *,
    seed: int,
    epochs: int | None = None,
) -> tuple[KalmanNet, list[float]]:
    """Train only KalmanNet against known synthetic posterior states."""

    config.validate()
    budget = int(config.knet_epochs if epochs is None else epochs)
    if budget < 1:
        raise ValueError("epochs must be positive")
    model_hash = state_dict_sha256(model)
    if any(parameter.requires_grad for parameter in model.parameters()):
        raise ValueError("neural system model must be frozen before KalmanNet training")
    knet = _build_kalmannet(config, seed)
    optimizer = torch.optim.Adam(knet.parameters(), lr=config.knet_learning_rate)
    history: list[float] = []
    knet.train()
    for _ in range(budget):
        optimizer.zero_grad(set_to_none=True)
        trace = run_kalmannet(model, knet, training_cases)
        loss = torch.mean((trace.posterior_states - training_cases.truth_states).square())
        if not torch.isfinite(loss):
            raise RuntimeError("KalmanNet ideal-recovery loss became nonfinite")
        loss.backward()
        gradient_norm = torch.nn.utils.clip_grad_norm_(knet.parameters(), max_norm=10.0)
        if not torch.isfinite(torch.as_tensor(gradient_norm)):
            raise RuntimeError("KalmanNet ideal-recovery gradient became nonfinite")
        optimizer.step()
        history.append(float(loss.detach().cpu()))
    if state_dict_sha256(model) != model_hash:
        raise RuntimeError("KalmanNet training changed the frozen neural system model")
    knet.eval()
    return knet, history


def _rmse_by_time(states: torch.Tensor, truth: torch.Tensor) -> np.ndarray:
    value = torch.sqrt(torch.mean((states - truth).square(), dim=(0, 2)))
    return value.detach().cpu().numpy().astype(np.float64)


def _trace_metrics(trace: AssimilationTrace, initial_rmse: float) -> dict:
    rmse = _rmse_by_time(trace.posterior_states, trace.truth_states)
    prior_rmse = _rmse_by_time(trace.prior_states, trace.truth_states)
    return {
        "initial_rmse": float(initial_rmse),
        "prior_rmse_by_time": prior_rmse.tolist(),
        "posterior_rmse_by_time": rmse.tolist(),
        "step1_posterior_rmse": float(rmse[0]),
        "step4_posterior_rmse": float(rmse[3]),
        "final_posterior_rmse": float(rmse[-1]),
        "step4_ratio_to_initial": float(rmse[3] / initial_rmse),
        "final_ratio_to_initial": float(rmse[-1] / initial_rmse),
        "all_states_finite": bool(torch.isfinite(trace.posterior_states).all()),
    }


def _open_loop_metrics(trace: OpenLoopTrace, cases: IdealCases) -> dict:
    rmse = _rmse_by_time(trace.states, cases.truth_states)
    return {
        "initial_rmse": cases.initial_rmse,
        "rmse_by_time": rmse.tolist(),
        "early_four_step_rmse": float(torch.sqrt(torch.mean(
            (trace.states[:, :4] - cases.truth_states[:, :4]).square())).detach().cpu()),
        "final_rmse": float(rmse[-1]),
        "all_states_finite": bool(torch.isfinite(trace.states).all()),
    }


def _tensor_arrays(prefix: str, trace: AssimilationTrace) -> dict[str, np.ndarray]:
    fields = {
        "prior_states": trace.prior_states,
        "posterior_states": trace.posterior_states,
        "predicted_observations": trace.predicted_observations,
        "innovations": trace.innovations,
        "gains": trace.gains,
        "posterior_covariances": trace.posterior_covariances,
        "forward_evolution_features": trace.forward_evolution_features,
        "forward_update_features": trace.forward_update_features,
    }
    return {
        f"{prefix}_{name}": value.detach().cpu().numpy()
        for name, value in fields.items()
    }


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _write_manifest(output_dir: Path) -> None:
    paths = sorted(
        path for path in output_dir.iterdir()
        if path.is_file() and path.name != "manifest.sha256"
    )
    lines = [f"{_file_sha256(path)}  {path.name}" for path in paths]
    (output_dir / "manifest.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8")


def _verify_manifest(output_dir: Path) -> bool:
    manifest = output_dir / "manifest.sha256"
    if not manifest.is_file():
        return False
    for line in manifest.read_text(encoding="utf-8").splitlines():
        expected, name = line.split("  ", maxsplit=1)
        path = output_dir / name
        if not path.is_file() or _file_sha256(path) != expected:
            return False
    return True


def _causality_check(
    method,
    model: DLSSMSystemModel,
    cases: IdealCases,
    cutoff: int,
) -> bool:
    baseline = method(cases)
    changed = method(cases.with_observations_after(cutoff, value=999.0))
    return bool(
        torch.equal(
            baseline.prior_states[:, : cutoff + 1],
            changed.prior_states[:, : cutoff + 1],
        )
        and torch.equal(
            baseline.posterior_states[:, : cutoff + 1],
            changed.posterior_states[:, : cutoff + 1],
        )
    )


def run_experiment(
    config: IdealRecoveryConfig,
    *,
    output_dir: str | Path,
) -> ExperimentResult:
    """Run the complete experiment and write one fail-closed result bundle."""

    config.validate()
    output_path = Path(output_dir)
    if output_path.exists() and any(output_path.iterdir()):
        raise FileExistsError(f"refusing nonempty output directory: {output_path}")
    output_path.mkdir(parents=True, exist_ok=True)

    model = build_ideal_neural_model()
    model_hash_before = state_dict_sha256(model)
    training_cases = generate_cases(model, config, split="training")
    evaluation_cases = generate_cases(model, config, split="evaluation")
    truth_replay = rollout_open_loop(
        model, evaluation_cases.forcing, evaluation_cases.true_initial_state)
    truth_replay_max_error = float(torch.max(torch.abs(
        truth_replay.states - evaluation_cases.truth_states)).detach().cpu())
    open_loop = rollout_open_loop(
        model, evaluation_cases.forcing, evaluation_cases.estimated_initial_state)
    ukf = run_conventional_ukf(model, evaluation_cases, config)

    knet_metrics: dict[str, dict] = {}
    knet_traces: dict[int, AssimilationTrace] = {}
    training_history: dict[str, list[float]] = {}
    for seed in config.knet_seeds:
        network, history = train_kalmannet(
            model, training_cases, config, seed=int(seed))
        trace = run_kalmannet(model, network, evaluation_cases)
        seed_key = str(seed)
        knet_metrics[seed_key] = _trace_metrics(trace, evaluation_cases.initial_rmse)
        knet_metrics[seed_key]["training_loss_first"] = history[0]
        knet_metrics[seed_key]["training_loss_final"] = history[-1]
        training_history[seed_key] = history
        knet_traces[int(seed)] = trace
        torch.save(
            {
                "schema_version": config.schema_version,
                "experiment_id": config.experiment_id,
                "seed": int(seed),
                "knet_state_dict": network.state_dict(),
                "training_history": history,
            },
            output_path / f"kalmannet_seed_{seed}.pt",
        )

    model_hash_after = state_dict_sha256(model)
    open_metrics = _open_loop_metrics(open_loop, evaluation_cases)
    ukf_metrics = _trace_metrics(ukf, evaluation_cases.initial_rmse)
    cutoff = min(7, config.sequence_length - 2)
    ukf_causal = _causality_check(
        lambda selected: run_conventional_ukf(model, selected, config),
        model,
        evaluation_cases,
        cutoff,
    )
    knet_causal = all(
        _causality_check(
            lambda selected, network_seed=seed: run_kalmannet(
                model,
                _restore_knet_from_checkpoint(
                    config, output_path / f"kalmannet_seed_{network_seed}.pt"),
                selected,
            ),
            model,
            evaluation_cases,
            cutoff,
        )
        for seed in config.knet_seeds
    )

    gates = {
        "truth_replay_max_abs_le_1e-12": truth_replay_max_error <= 1e-12,
        "open_loop_early_rmse_ge_0_05": open_metrics["early_four_step_rmse"] >= 0.05,
        "ukf_final_ratio_le_1e-4": ukf_metrics["final_ratio_to_initial"] <= 1e-4,
        "ukf_all_states_finite": ukf_metrics["all_states_finite"],
        "ukf_causal": ukf_causal,
        "kalmannet_all_seeds_step4_ratio_le_0_05": all(
            row["step4_ratio_to_initial"] <= 0.05 for row in knet_metrics.values()),
        "kalmannet_all_seeds_final_ratio_le_0_01": all(
            row["final_ratio_to_initial"] <= 0.01 for row in knet_metrics.values()),
        "kalmannet_all_states_finite": all(
            row["all_states_finite"] for row in knet_metrics.values()),
        "kalmannet_causal": knet_causal,
        "frozen_neural_model_hash_unchanged": model_hash_before == model_hash_after,
    }
    verdict = "PASS" if all(gates.values()) else "FAIL"
    metrics = {
        "schema_version": config.schema_version,
        "experiment_id": config.experiment_id,
        "verdict": verdict,
        "truth_replay_max_abs_error": truth_replay_max_error,
        "open_loop": open_metrics,
        "conventional_ukf": ukf_metrics,
        "kalmannet": knet_metrics,
        "model_hash_before": model_hash_before,
        "model_hash_after": model_hash_after,
        "causality_cutoff_index": cutoff,
        "gates": gates,
    }

    arrays: dict[str, np.ndarray] = {
        "forcing": evaluation_cases.forcing.numpy(),
        "observations": evaluation_cases.observations.numpy(),
        "truth_states": evaluation_cases.truth_states.numpy(),
        "true_initial_state": evaluation_cases.true_initial_state.numpy(),
        "estimated_initial_state": evaluation_cases.estimated_initial_state.numpy(),
        "open_loop_states": open_loop.states.detach().numpy(),
        **_tensor_arrays("ukf", ukf),
    }
    for seed, trace in knet_traces.items():
        arrays.update(_tensor_arrays(f"kalmannet_seed_{seed}", trace))

    (output_path / "config.snapshot.json").write_text(
        json.dumps(config.to_dict(), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (output_path / "metrics.json").write_text(
        json.dumps(metrics, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (output_path / "training_history.json").write_text(
        json.dumps(training_history, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    np.savez_compressed(output_path / "trajectories.npz", **arrays)
    _write_manifest(output_path)
    if not _verify_manifest(output_path):
        raise RuntimeError("result manifest verification failed")

    registry_path = output_path.parent / "registry.jsonl"
    registry_row = {
        "exp_id": config.experiment_id,
        "type": "known_truth_state_recovery",
        "hypothesis": "UKF and KalmanNet remove isolated initial-state error",
        "base_config": config.schema_version,
        "changed_factor": "filter_type",
        "fixed_factors": "frozen neural model, forcing, observation operator, exact observations",
        "seeds": list(config.knet_seeds),
        "status": verdict,
        "run_dir": str(output_path.resolve()),
        "best_checkpoint": None,
        "metrics_path": str((output_path / "metrics.json").resolve()),
        "paper_name": None,
        "notes": "Engineering ideal case; not real-basin evidence",
    }
    with registry_path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(registry_row, sort_keys=True) + "\n")
    return ExperimentResult(output_dir=output_path, verdict=verdict, metrics=metrics)


def _restore_knet_from_checkpoint(
    config: IdealRecoveryConfig,
    checkpoint_path: Path,
) -> KalmanNet:
    payload = torch.load(checkpoint_path, map_location=DEVICE, weights_only=False)
    network = _build_kalmannet(config, int(payload["seed"]))
    network.load_state_dict(payload["knet_state_dict"])
    network.eval()
    return network


def load_and_verify_result(output_dir: str | Path) -> dict:
    """Reload a completed result bundle and verify every recorded file hash."""

    output_path = Path(output_dir)
    if not _verify_manifest(output_path):
        raise ValueError("result manifest is missing or invalid")
    return {
        "manifest_verified": True,
        "config": json.loads((output_path / "config.snapshot.json").read_text(encoding="utf-8")),
        "metrics": json.loads((output_path / "metrics.json").read_text(encoding="utf-8")),
    }


def independently_recompute_metrics(output_dir: str | Path) -> dict:
    """Recompute decisive ratios from persisted raw trajectories only."""

    output_path = Path(output_dir)
    loaded = load_and_verify_result(output_path)
    arrays = np.load(output_path / "trajectories.npz")
    truth = arrays["truth_states"]
    initial_error = arrays["estimated_initial_state"] - arrays["true_initial_state"]
    initial_rmse = float(np.sqrt(np.mean(initial_error ** 2)))

    def summarize(states: np.ndarray) -> dict:
        rmse = np.sqrt(np.mean((states - truth) ** 2, axis=(0, 2)))
        return {
            "initial_rmse": initial_rmse,
            "step1_posterior_rmse": float(rmse[0]),
            "step4_posterior_rmse": float(rmse[3]),
            "final_posterior_rmse": float(rmse[-1]),
            "step4_ratio_to_initial": float(rmse[3] / initial_rmse),
            "final_ratio_to_initial": float(rmse[-1] / initial_rmse),
        }

    recomputed = {
        "manifest_verified": True,
        "ukf": summarize(arrays["ukf_posterior_states"]),
        "kalmannet": {},
    }
    for seed in loaded["config"]["knet_seeds"]:
        recomputed["kalmannet"][str(seed)] = summarize(
            arrays[f"kalmannet_seed_{seed}_posterior_states"])
    return recomputed


def write_independent_audit(
    output_dir: str | Path,
    *,
    tolerance: float = 1e-12,
) -> dict:
    """Reload raw trajectories, compare decisive metrics, and re-seal the bundle."""

    output_path = Path(output_dir)
    persisted = load_and_verify_result(output_path)["metrics"]
    recomputed = independently_recompute_metrics(output_path)
    comparisons: dict[str, float] = {}
    for key in (
        "initial_rmse",
        "step1_posterior_rmse",
        "step4_posterior_rmse",
        "final_posterior_rmse",
        "step4_ratio_to_initial",
        "final_ratio_to_initial",
    ):
        comparisons[f"ukf.{key}"] = abs(
            float(recomputed["ukf"][key])
            - float(persisted["conventional_ukf"][key])
        )
    for seed, values in recomputed["kalmannet"].items():
        for key in (
            "initial_rmse",
            "step1_posterior_rmse",
            "step4_posterior_rmse",
            "final_posterior_rmse",
            "step4_ratio_to_initial",
            "final_ratio_to_initial",
        ):
            comparisons[f"kalmannet.{seed}.{key}"] = abs(
                float(values[key]) - float(persisted["kalmannet"][seed][key]))
    maximum_difference = max(comparisons.values(), default=0.0)
    audit = {
        "schema_version": "ideal_neural_state_recovery_independent_audit_v1",
        "manifest_verified_before_recompute": True,
        "absolute_tolerance": float(tolerance),
        "maximum_absolute_metric_difference": maximum_difference,
        "metric_differences": comparisons,
        "status": "PASS" if maximum_difference <= tolerance else "FAIL",
        "recomputed": recomputed,
    }
    (output_path / "independent_recompute.json").write_text(
        json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    _write_manifest(output_path)
    if not _verify_manifest(output_path):
        raise RuntimeError("result manifest failed after independent audit")
    return audit


__all__ = [
    "AssimilationTrace",
    "ExperimentResult",
    "IdealCases",
    "IdealRecoveryConfig",
    "build_ideal_neural_model",
    "generate_cases",
    "independently_recompute_metrics",
    "load_and_verify_result",
    "rollout_open_loop",
    "run_conventional_ukf",
    "run_experiment",
    "run_kalmannet",
    "state_dict_sha256",
    "train_kalmannet",
    "write_independent_audit",
]
