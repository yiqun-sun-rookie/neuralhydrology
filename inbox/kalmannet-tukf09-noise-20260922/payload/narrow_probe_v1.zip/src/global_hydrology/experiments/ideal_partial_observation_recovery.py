"""Four-state known-truth recovery when only state 1 is observed.

ISR04 changes exactly one scientific factor from ISR03: both filters receive
only the first component of the exact four-state observation.  The frozen
neural transition, forcings, initial-state errors, splits, seeds, and training
budget remain paired with ISR03.  Success is judged against the paired open
loop at a preregistered time so natural decay cannot masquerade as recovery.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json
import math
from pathlib import Path

import numpy as np
import torch

from global_hydrology.experiments.ideal_multistate_recovery import (
    MultiStateRecoveryConfig,
    _decisive_filter_metrics,
    _initial_rmses,
    _numeric_leaf_map,
    _numpy_filter_summary,
    _open_loop_metrics,
    _trace_metrics,
    build_multistate_neural_model,
    generate_multistate_cases,
    rollout_multistate_open_loop,
)
from global_hydrology.experiments.ideal_state_recovery import (
    AssimilationTrace,
    ExperimentResult,
    IdealCases,
    _causality_check,
    _positive_covariance,
    _tensor_arrays,
    _verify_manifest,
    _write_manifest,
    state_dict_sha256,
)
from global_hydrology.models.dl_ssm import DLSSMSystemModel
from global_hydrology.models.kalman_net import KalmanNet, KalmanNetConfig


DTYPE = torch.float64
DEVICE = torch.device("cpu")


@dataclass(frozen=True)
class PartialObservationRecoveryConfig:
    """Frozen contract for the ISR04 partial-observation experiment."""

    schema_version: str = "ideal_partial_observation_state_recovery_v1"
    experiment_id: str = "ISR04"
    dtype: str = "float64"
    device: str = "cpu"
    state_dim: int = 4
    observation_dim: int = 1
    forcing_dim: int = 4
    observed_state_index: int = 0
    sequence_length: int = 100
    n_train_cases: int = 64
    n_evaluation_cases: int = 32
    training_seed: int = 20260811
    evaluation_seed: int = 20260812
    knet_seeds: tuple[int, ...] = (11, 22, 33)
    knet_epochs: int = 200
    knet_learning_rate: float = 1e-3
    process_variance: float = 1e-10
    observation_variance: float = 1e-8
    initial_variance: float = 1.0
    observability_horizon: int = 8
    observability_rank_tolerance: float = 1e-10
    observability_min_singular_value: float = 1e-4
    recovery_gate_step: int = 16
    ukf_each_state_gate_vs_open_loop_max: float = 0.05
    knet_observed_gate_vs_open_loop_max: float = 0.25
    knet_unobserved_gate_vs_open_loop_max: float = 0.50
    knet_overall_gate_vs_open_loop_max: float = 0.40

    def validate(self) -> None:
        if self.schema_version != "ideal_partial_observation_state_recovery_v1":
            raise ValueError("unsupported partial-observation config schema")
        if self.experiment_id != "ISR04":
            raise ValueError("experiment_id must be ISR04")
        if self.dtype != "float64" or self.device != "cpu":
            raise ValueError("ISR04 requires float64 on cpu")
        if self.state_dim != 4 or self.forcing_dim != 4:
            raise ValueError("ISR04 requires four states and four forcings")
        if self.observation_dim != 1:
            raise ValueError("ISR04 requires exactly one observation")
        if self.observed_state_index != 0:
            raise ValueError("ISR04 observes only state 1 at zero-based index 0")
        if self.sequence_length < self.recovery_gate_step:
            raise ValueError("recovery_gate_step must be inside the sequence")
        if self.recovery_gate_step < 4:
            raise ValueError("recovery_gate_step must be at least four")
        if not 4 <= self.observability_horizon <= self.sequence_length:
            raise ValueError("observability_horizon must be from four to sequence length")
        if self.n_train_cases < 1 or self.n_evaluation_cases < 1:
            raise ValueError("training and evaluation case counts must be positive")
        if not self.knet_seeds or len(set(self.knet_seeds)) != len(self.knet_seeds):
            raise ValueError("knet_seeds must be nonempty and unique")
        if self.knet_epochs < 1 or self.knet_learning_rate <= 0.0:
            raise ValueError("KalmanNet training budget must be positive")
        positive_fields = (
            "process_variance",
            "observation_variance",
            "initial_variance",
            "observability_rank_tolerance",
            "observability_min_singular_value",
            "ukf_each_state_gate_vs_open_loop_max",
            "knet_observed_gate_vs_open_loop_max",
            "knet_unobserved_gate_vs_open_loop_max",
            "knet_overall_gate_vs_open_loop_max",
        )
        for name in positive_fields:
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be positive and finite")

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["knet_seeds"] = list(self.knet_seeds)
        return payload

    @classmethod
    def from_json(cls, path: str | Path) -> "PartialObservationRecoveryConfig":
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        payload["knet_seeds"] = tuple(int(seed) for seed in payload["knet_seeds"])
        config = cls(**payload)
        config.validate()
        return config


def _multistate_base_config(
    config: PartialObservationRecoveryConfig,
) -> MultiStateRecoveryConfig:
    """Translate paired fields into the sealed ISR03 generator contract."""

    config.validate()
    return MultiStateRecoveryConfig(
        sequence_length=config.sequence_length,
        n_train_cases=config.n_train_cases,
        n_evaluation_cases=config.n_evaluation_cases,
        training_seed=config.training_seed,
        evaluation_seed=config.evaluation_seed,
        knet_seeds=config.knet_seeds,
        knet_epochs=config.knet_epochs,
        knet_learning_rate=config.knet_learning_rate,
        process_variance=config.process_variance,
        observation_variance=config.observation_variance,
        initial_variance=config.initial_variance,
        knet_gate_step=min(config.recovery_gate_step, config.sequence_length),
    )


def build_partial_observation_model(
    config: PartialObservationRecoveryConfig,
) -> DLSSMSystemModel:
    """Build the same frozen four-state neural model used by ISR03."""

    return build_multistate_neural_model(_multistate_base_config(config))


def _observe_state_one(
    model: DLSSMSystemModel,
    states: torch.Tensor,
) -> torch.Tensor:
    full_observation = model.h(states)
    return full_observation[..., :1]


def generate_partial_observation_cases(
    model: DLSSMSystemModel,
    config: PartialObservationRecoveryConfig,
    *,
    split: str,
) -> IdealCases:
    """Generate ISR03-paired cases while exposing only exact state 1."""

    base_cases = generate_multistate_cases(
        model,
        _multistate_base_config(config),
        split=split,
    )
    observations = base_cases.truth_states[..., :1].clone()
    return IdealCases(
        forcing=base_cases.forcing,
        observations=observations,
        truth_states=base_cases.truth_states,
        true_initial_state=base_cases.true_initial_state,
        estimated_initial_state=base_cases.estimated_initial_state,
        model_contract_hash=base_cases.model_contract_hash,
        estimator_contract_hash=base_cases.estimator_contract_hash,
        split=base_cases.split,
    )


def local_observability_metrics(
    model: DLSSMSystemModel,
    cases: IdealCases,
    *,
    horizon: int,
    rank_tolerance: float = 1e-10,
) -> dict:
    """Measure local initial-state observability from state-1 sequences."""

    if horizon < 4 or horizon > cases.forcing.shape[1]:
        raise ValueError("observability horizon must be between four and sequence length")
    if rank_tolerance <= 0.0:
        raise ValueError("rank_tolerance must be positive")

    ranks: list[int] = []
    smallest: list[float] = []
    condition_numbers: list[float] = []
    singular_values: list[list[float]] = []
    for case_index in range(cases.forcing.shape[0]):
        selected_forcing = cases.forcing[case_index, :horizon]

        def observation_sequence(initial_state: torch.Tensor) -> torch.Tensor:
            state = initial_state.unsqueeze(0)
            values: list[torch.Tensor] = []
            for time_index in range(horizon):
                state = model.f(
                    state,
                    selected_forcing[time_index].unsqueeze(0),
                )
                values.append(_observe_state_one(model, state)[0, 0])
            return torch.stack(values)

        jacobian = torch.autograd.functional.jacobian(
            observation_sequence,
            cases.true_initial_state[case_index],
            vectorize=True,
        )
        values = torch.linalg.svdvals(jacobian)
        rank = int(torch.linalg.matrix_rank(jacobian, tol=rank_tolerance))
        ranks.append(rank)
        smallest.append(float(values[-1].detach().cpu()))
        condition_numbers.append(float((values[0] / values[-1]).detach().cpu()))
        singular_values.append(values.detach().cpu().tolist())

    return {
        "case_count": int(cases.forcing.shape[0]),
        "horizon": int(horizon),
        "rank_tolerance": float(rank_tolerance),
        "ranks": ranks,
        "minimum_rank": min(ranks),
        "smallest_singular_values": smallest,
        "minimum_smallest_singular_value": min(smallest),
        "median_smallest_singular_value": float(np.median(smallest)),
        "condition_numbers": condition_numbers,
        "maximum_condition_number": max(condition_numbers),
        "median_condition_number": float(np.median(condition_numbers)),
        "singular_values": singular_values,
    }


def run_partial_observation_ukf(
    model: DLSSMSystemModel,
    cases: IdealCases,
    config: PartialObservationRecoveryConfig,
) -> AssimilationTrace:
    """Run a causal full-covariance filter with a scalar observation."""

    from scripts.run_aligned_gr4j_da import (
        constrained_covariance_update,
        merwe_sigma_points,
    )

    config.validate()
    case_count, time_count, state_dim = cases.truth_states.shape
    if state_dim != 4 or cases.observations.shape != (case_count, time_count, 1):
        raise ValueError("ISR04 requires four states and one observation")
    prior = torch.empty_like(cases.truth_states)
    posterior = torch.empty_like(cases.truth_states)
    prediction = torch.empty_like(cases.observations)
    innovation = torch.empty_like(cases.observations)
    gains = torch.empty((case_count, time_count, 4, 1), dtype=DTYPE)
    covariances = torch.empty((case_count, time_count, 4, 4), dtype=DTYPE)
    process_covariance = torch.eye(4, dtype=DTYPE) * config.process_variance
    observation_covariance = (
        torch.eye(1, dtype=DTYPE) * config.observation_variance
    )

    with torch.no_grad():
        for case_index in range(case_count):
            mean = cases.estimated_initial_state[case_index].clone()
            covariance = torch.eye(4, dtype=DTYPE) * config.initial_variance
            for time_index in range(time_count):
                sigma, mean_weight, covariance_weight = merwe_sigma_points(
                    mean,
                    covariance,
                    alpha=0.3,
                    beta=2.0,
                    kappa=0.0,
                )
                control = cases.forcing[case_index, time_index].expand(
                    sigma.shape[0], 4
                )
                propagated = model.f(sigma, control)
                observed_sigma = _observe_state_one(model, propagated)
                prior_mean = torch.sum(mean_weight[:, None] * propagated, dim=0)
                observation_mean = torch.sum(
                    mean_weight[:, None] * observed_sigma, dim=0
                )
                state_deviation = propagated - prior_mean
                observation_deviation = observed_sigma - observation_mean
                prior_covariance = torch.einsum(
                    "s,si,sj->ij",
                    covariance_weight,
                    state_deviation,
                    state_deviation,
                )
                prior_covariance = _positive_covariance(
                    prior_covariance + process_covariance
                )
                cross_covariance = torch.einsum(
                    "s,si,sj->ij",
                    covariance_weight,
                    state_deviation,
                    observation_deviation,
                )
                innovation_covariance = torch.einsum(
                    "s,si,sj->ij",
                    covariance_weight,
                    observation_deviation,
                    observation_deviation,
                )
                innovation_covariance = _positive_covariance(
                    innovation_covariance + observation_covariance
                )
                gain = torch.linalg.solve(
                    innovation_covariance.T, cross_covariance.T
                ).T
                current_innovation = (
                    cases.observations[case_index, time_index] - observation_mean
                )
                mean = prior_mean + (gain @ current_innovation[:, None]).squeeze(1)
                covariance = constrained_covariance_update(
                    prior_covariance,
                    cross_covariance,
                    innovation_covariance,
                    gain,
                )
                covariance = _positive_covariance(covariance)

                prior[case_index, time_index] = prior_mean
                posterior[case_index, time_index] = mean
                prediction[case_index, time_index] = observation_mean
                innovation[case_index, time_index] = current_innovation
                gains[case_index, time_index] = gain
                covariances[case_index, time_index] = covariance

    zeros = torch.zeros_like(cases.truth_states)
    return AssimilationTrace(
        prior_states=prior,
        posterior_states=posterior,
        predicted_observations=prediction,
        innovations=innovation,
        gains=gains,
        posterior_covariances=covariances,
        truth_states=cases.truth_states,
        forward_evolution_features=zeros,
        forward_update_features=zeros,
    )


def build_partial_observation_kalmannet(
    config: PartialObservationRecoveryConfig,
    *,
    seed: int,
) -> KalmanNet:
    """Create the ISR04 four-state/one-observation gain network."""

    config.validate()
    torch.manual_seed(int(seed))
    network_config = KalmanNetConfig(
        m=4,
        n=1,
        in_mult_KNet=4,
        out_mult_KNet=4,
        d_hidden_Q=16,
        d_hidden_Sigma=24,
        d_hidden_S=16,
        diff_guard_enable=True,
        diff_guard_obs=10.0,
        diff_guard_state=10.0,
    )
    network = KalmanNet(network_config, device=DEVICE).to(
        device=DEVICE, dtype=DTYPE
    )
    with torch.no_grad():
        network.FC2[-1].weight.zero_()
        network.FC2[-1].bias.zero_()
    return network


def run_partial_observation_kalmannet(
    model: DLSSMSystemModel,
    knet: KalmanNet,
    cases: IdealCases,
) -> AssimilationTrace:
    """Run the causal `4 x 1` learned-gain update."""

    case_count, time_count, state_dim = cases.truth_states.shape
    if (
        state_dim != 4
        or cases.observations.shape != (case_count, time_count, 1)
        or knet.m != 4
        or knet.n != 1
    ):
        raise ValueError("ISR04 KalmanNet requires m=4 and n=1")
    knet.init_hidden(
        case_count,
        model.prior_q,
        model.prior_state_cov,
        torch.eye(1, dtype=DTYPE),
    )

    previous_posterior = cases.estimated_initial_state
    posterior_before_previous = previous_posterior.clone()
    previous_prior = previous_posterior.clone()
    previous_observation = _observe_state_one(model, previous_posterior)

    priors: list[torch.Tensor] = []
    posteriors: list[torch.Tensor] = []
    predictions: list[torch.Tensor] = []
    innovations: list[torch.Tensor] = []
    gains: list[torch.Tensor] = []
    evolution_features: list[torch.Tensor] = []
    update_features: list[torch.Tensor] = []

    for time_index in range(time_count):
        current_prior = model.f(
            previous_posterior,
            cases.forcing[:, time_index, :],
        )
        current_prediction = _observe_state_one(model, current_prior)
        current_observation = cases.observations[:, time_index, :]
        observation_change = current_observation - previous_observation
        current_innovation = current_observation - current_prediction
        forward_evolution = previous_posterior - posterior_before_previous
        previous_analysis_update = previous_posterior - previous_prior
        gain = knet.compute_gain(
            observation_change,
            current_innovation,
            forward_evolution,
            previous_analysis_update,
        )
        correction = torch.bmm(gain, current_innovation.unsqueeze(2)).squeeze(2)
        current_posterior = current_prior + correction

        priors.append(current_prior)
        posteriors.append(current_posterior)
        predictions.append(current_prediction)
        innovations.append(current_innovation)
        gains.append(gain)
        evolution_features.append(forward_evolution)
        update_features.append(previous_analysis_update)

        posterior_before_previous = previous_posterior
        previous_posterior = current_posterior
        previous_prior = current_prior
        previous_observation = current_observation

    return AssimilationTrace(
        prior_states=torch.stack(priors, dim=1),
        posterior_states=torch.stack(posteriors, dim=1),
        predicted_observations=torch.stack(predictions, dim=1),
        innovations=torch.stack(innovations, dim=1),
        gains=torch.stack(gains, dim=1),
        posterior_covariances=torch.zeros(
            (case_count, time_count, 4, 4), dtype=DTYPE
        ),
        truth_states=cases.truth_states,
        forward_evolution_features=torch.stack(evolution_features, dim=1),
        forward_update_features=torch.stack(update_features, dim=1),
    )


def train_partial_observation_kalmannet(
    model: DLSSMSystemModel,
    training_cases: IdealCases,
    config: PartialObservationRecoveryConfig,
    *,
    seed: int,
    epochs: int | None = None,
) -> tuple[KalmanNet, list[float]]:
    """Train only KalmanNet using known truths for all four states."""

    config.validate()
    budget = int(config.knet_epochs if epochs is None else epochs)
    if budget < 1:
        raise ValueError("epochs must be positive")
    model_hash = state_dict_sha256(model)
    if any(parameter.requires_grad for parameter in model.parameters()):
        raise ValueError("neural system model must be frozen before training")
    knet = build_partial_observation_kalmannet(config, seed=seed)
    optimizer = torch.optim.Adam(knet.parameters(), lr=config.knet_learning_rate)
    history: list[float] = []
    knet.train()
    for _ in range(budget):
        optimizer.zero_grad(set_to_none=True)
        trace = run_partial_observation_kalmannet(model, knet, training_cases)
        loss = torch.mean(
            (trace.posterior_states - training_cases.truth_states).square()
        )
        if not torch.isfinite(loss):
            raise RuntimeError("partial-observation KalmanNet loss became nonfinite")
        loss.backward()
        gradient_norm = torch.nn.utils.clip_grad_norm_(
            knet.parameters(), max_norm=10.0
        )
        if not torch.isfinite(torch.as_tensor(gradient_norm)):
            raise RuntimeError("partial-observation KalmanNet gradient became nonfinite")
        optimizer.step()
        history.append(float(loss.detach().cpu()))
    if state_dict_sha256(model) != model_hash:
        raise RuntimeError("training changed the frozen neural system model")
    knet.eval()
    return knet, history


def _add_open_loop_comparison(
    metrics: dict,
    open_loop_metrics: dict,
    gate_step: int,
) -> dict:
    gate_index = gate_step - 1
    open_overall = float(open_loop_metrics["rmse_by_time"][gate_index])
    open_statewise = np.asarray(
        open_loop_metrics["statewise_rmse_by_time"][gate_index],
        dtype=np.float64,
    )
    result = dict(metrics)
    result["gate_open_loop_rmse"] = open_overall
    result["statewise_gate_open_loop_rmse"] = open_statewise.tolist()
    result["gate_ratio_to_open_loop"] = float(
        metrics["gate_posterior_rmse"] / open_overall
    )
    result["statewise_gate_ratio_to_open_loop"] = (
        np.asarray(metrics["statewise_gate_posterior_rmse"], dtype=np.float64)
        / open_statewise
    ).tolist()
    return result


def _restore_partial_observation_kalmannet(
    config: PartialObservationRecoveryConfig,
    checkpoint_path: Path,
) -> KalmanNet:
    payload = torch.load(checkpoint_path, map_location=DEVICE, weights_only=False)
    network = build_partial_observation_kalmannet(
        config, seed=int(payload["seed"])
    )
    network.load_state_dict(payload["knet_state_dict"])
    network.eval()
    return network


def run_partial_observation_experiment(
    config: PartialObservationRecoveryConfig,
    *,
    output_dir: str | Path,
) -> ExperimentResult:
    """Run ISR04 and publish an atomic manifest-verified result bundle."""

    config.validate()
    output_path = Path(output_dir)
    incomplete_path = output_path.with_name(output_path.name + ".incomplete")
    if output_path.exists():
        raise FileExistsError(f"refusing existing output directory: {output_path}")
    if incomplete_path.exists():
        raise FileExistsError(f"refusing existing incomplete directory: {incomplete_path}")
    incomplete_path.mkdir(parents=True, exist_ok=False)

    model = build_partial_observation_model(config)
    model_hash_before = state_dict_sha256(model)
    training_cases = generate_partial_observation_cases(
        model, config, split="training"
    )
    evaluation_cases = generate_partial_observation_cases(
        model, config, split="evaluation"
    )
    truth_replay = rollout_multistate_open_loop(
        model,
        evaluation_cases.forcing,
        evaluation_cases.true_initial_state,
    )
    truth_replay_max_error = float(
        torch.max(torch.abs(truth_replay.states - evaluation_cases.truth_states))
        .detach()
        .cpu()
    )
    observation_truth_max_error = float(
        torch.max(
            torch.abs(
                evaluation_cases.observations
                - evaluation_cases.truth_states[..., :1]
            )
        )
        .detach()
        .cpu()
    )
    observability = local_observability_metrics(
        model,
        evaluation_cases,
        horizon=config.observability_horizon,
        rank_tolerance=config.observability_rank_tolerance,
    )
    open_loop = rollout_multistate_open_loop(
        model,
        evaluation_cases.forcing,
        evaluation_cases.estimated_initial_state,
    )
    open_metrics = _open_loop_metrics(open_loop, evaluation_cases)
    ukf = run_partial_observation_ukf(model, evaluation_cases, config)
    initial_rmse, statewise_initial_rmse = _initial_rmses(evaluation_cases)
    ukf_metrics = _add_open_loop_comparison(
        _trace_metrics(
            ukf,
            initial_rmse,
            statewise_initial_rmse,
            config.recovery_gate_step,
        ),
        open_metrics,
        config.recovery_gate_step,
    )

    knet_metrics: dict[str, dict] = {}
    knet_traces: dict[int, AssimilationTrace] = {}
    training_history: dict[str, list[float]] = {}
    network: KalmanNet | None = None
    for seed in config.knet_seeds:
        network, history = train_partial_observation_kalmannet(
            model,
            training_cases,
            config,
            seed=int(seed),
        )
        trace = run_partial_observation_kalmannet(
            model, network, evaluation_cases
        )
        row = _add_open_loop_comparison(
            _trace_metrics(
                trace,
                initial_rmse,
                statewise_initial_rmse,
                config.recovery_gate_step,
            ),
            open_metrics,
            config.recovery_gate_step,
        )
        row["training_loss_first"] = history[0]
        row["training_loss_final"] = history[-1]
        seed_key = str(seed)
        knet_metrics[seed_key] = row
        knet_traces[int(seed)] = trace
        training_history[seed_key] = history
        torch.save(
            {
                "schema_version": config.schema_version,
                "experiment_id": config.experiment_id,
                "seed": int(seed),
                "knet_state_dict": network.state_dict(),
                "training_history": history,
            },
            incomplete_path / f"kalmannet_seed_{seed}.pt",
        )

    model_hash_after = state_dict_sha256(model)
    cutoff = min(config.recovery_gate_step - 1, config.sequence_length - 2)
    ukf_causal = _causality_check(
        lambda selected: run_partial_observation_ukf(model, selected, config),
        model,
        evaluation_cases,
        cutoff,
    )
    knet_causal = all(
        _causality_check(
            lambda selected, network_seed=seed: run_partial_observation_kalmannet(
                model,
                _restore_partial_observation_kalmannet(
                    config,
                    incomplete_path / f"kalmannet_seed_{network_seed}.pt",
                ),
                selected,
            ),
            model,
            evaluation_cases,
            cutoff,
        )
        for seed in config.knet_seeds
    )

    observed_index = config.observed_state_index
    unobserved_indices = tuple(
        index for index in range(config.state_dim) if index != observed_index
    )
    gates = {
        "truth_replay_max_abs_le_1e-12": truth_replay_max_error <= 1e-12,
        "observed_state_equals_truth_max_abs_le_1e-12": (
            observation_truth_max_error <= 1e-12
        ),
        "local_observability_rank_is_four": (
            observability["minimum_rank"] == config.state_dim
        ),
        "local_observability_minimum_singular_ge_preregistered": (
            observability["minimum_smallest_singular_value"]
            >= config.observability_min_singular_value
        ),
        "open_loop_each_state_early_rmse_ge_0_05": all(
            value >= 0.05
            for value in open_metrics["statewise_early_four_step_rmse"]
        ),
        "ukf_each_state_gate_vs_open_loop_le_preregistered": all(
            value <= config.ukf_each_state_gate_vs_open_loop_max
            for value in ukf_metrics["statewise_gate_ratio_to_open_loop"]
        ),
        "ukf_all_states_finite": ukf_metrics["all_states_finite"],
        "ukf_causal": ukf_causal,
        "kalmannet_all_seeds_observed_gate_vs_open_loop_le_preregistered": all(
            row["statewise_gate_ratio_to_open_loop"][observed_index]
            <= config.knet_observed_gate_vs_open_loop_max
            for row in knet_metrics.values()
        ),
        "kalmannet_all_seeds_unobserved_gate_vs_open_loop_le_preregistered": all(
            all(
                row["statewise_gate_ratio_to_open_loop"][index]
                <= config.knet_unobserved_gate_vs_open_loop_max
                for index in unobserved_indices
            )
            for row in knet_metrics.values()
        ),
        "kalmannet_all_seeds_overall_gate_vs_open_loop_le_preregistered": all(
            row["gate_ratio_to_open_loop"]
            <= config.knet_overall_gate_vs_open_loop_max
            for row in knet_metrics.values()
        ),
        "kalmannet_all_seeds_training_loss_decreased": all(
            row["training_loss_final"] < row["training_loss_first"]
            for row in knet_metrics.values()
        ),
        "kalmannet_all_states_finite": all(
            row["all_states_finite"] for row in knet_metrics.values()
        ),
        "kalmannet_causal": knet_causal,
        "frozen_neural_model_hash_unchanged": model_hash_before == model_hash_after,
    }
    verdict = "PASS" if all(gates.values()) else "FAIL"
    if network is None:
        raise RuntimeError("no KalmanNet seed was trained")
    metrics = {
        "schema_version": config.schema_version,
        "experiment_id": config.experiment_id,
        "verdict": verdict,
        "observed_state_index_zero_based": observed_index,
        "truth_replay_max_abs_error": truth_replay_max_error,
        "observation_truth_max_abs_error": observation_truth_max_error,
        "local_observability": observability,
        "open_loop": open_metrics,
        "conventional_ukf": ukf_metrics,
        "kalmannet": knet_metrics,
        "kalmannet_parameter_count": int(
            sum(parameter.numel() for parameter in network.parameters())
        ),
        "model_hash_before": model_hash_before,
        "model_hash_after": model_hash_after,
        "causality_cutoff_index": cutoff,
        "gates": gates,
    }

    arrays: dict[str, np.ndarray] = {
        "forcing": evaluation_cases.forcing.numpy(),
        "observations": evaluation_cases.observations.numpy(),
        "truth_states": evaluation_cases.truth_states.numpy(),
        "true_initial_state": evaluation_cases.true_initial_state.numpy(),
        "estimated_initial_state": evaluation_cases.estimated_initial_state.numpy(),
        "open_loop_states": open_loop.states.detach().numpy(),
        **_tensor_arrays("ukf", ukf),
    }
    for seed, trace in knet_traces.items():
        arrays.update(_tensor_arrays(f"kalmannet_seed_{seed}", trace))

    (incomplete_path / "config.snapshot.json").write_text(
        json.dumps(config.to_dict(), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    (incomplete_path / "metrics.json").write_text(
        json.dumps(metrics, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    (incomplete_path / "training_history.json").write_text(
        json.dumps(training_history, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    np.savez_compressed(incomplete_path / "trajectories.npz", **arrays)
    _write_manifest(incomplete_path)
    if not _verify_manifest(incomplete_path):
        raise RuntimeError("ISR04 manifest verification failed before publication")
    incomplete_path.replace(output_path)

    registry_path = output_path.parent / "registry.jsonl"
    registry_row = {
        "exp_id": config.experiment_id,
        "type": "known_truth_partial_observation_state_recovery",
        "hypothesis": (
            "UKF and KalmanNet infer three unobserved coupled states from exact state-1 observations"
        ),
        "base_config": config.schema_version,
        "changed_factor": "four_exact_state_observations_to_exact_state_1_only",
        "fixed_factors": (
            "ISR03 frozen neural model, forcing, initial errors, splits, seeds, and training budget"
        ),
        "seeds": list(config.knet_seeds),
        "status": verdict,
        "run_dir": str(output_path.resolve()),
        "best_checkpoint": None,
        "metrics_path": str((output_path / "metrics.json").resolve()),
        "paper_name": None,
        "notes": (
            "Engineering partial-observation ideal case; not real-basin or 33-state evidence"
        ),
    }
    with registry_path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(registry_row, sort_keys=True) + "\n")
    return ExperimentResult(output_dir=output_path, verdict=verdict, metrics=metrics)


def load_and_verify_partial_observation_result(output_dir: str | Path) -> dict:
    """Verify the manifest before loading ISR04 metadata and metrics."""

    output_path = Path(output_dir)
    if not _verify_manifest(output_path):
        raise ValueError("ISR04 result manifest is missing or invalid")
    return {
        "manifest_verified": True,
        "config": json.loads(
            (output_path / "config.snapshot.json").read_text(encoding="utf-8")
        ),
        "metrics": json.loads(
            (output_path / "metrics.json").read_text(encoding="utf-8")
        ),
    }


def _numpy_open_loop_summary(
    states: np.ndarray,
    truth: np.ndarray,
    true_initial: np.ndarray,
    estimated_initial: np.ndarray,
) -> dict:
    initial_error = estimated_initial - true_initial
    initial_rmse = float(np.sqrt(np.mean(initial_error**2)))
    statewise_initial = np.sqrt(np.mean(initial_error**2, axis=0))
    error = states - truth
    overall = np.sqrt(np.mean(error**2, axis=(0, 2)))
    by_state = np.sqrt(np.mean(error**2, axis=0))
    early = error[:, :4, :]
    return {
        "initial_rmse": initial_rmse,
        "statewise_initial_rmse": statewise_initial.tolist(),
        "rmse_by_time": overall.tolist(),
        "statewise_rmse_by_time": by_state.tolist(),
        "early_four_step_rmse": float(np.sqrt(np.mean(early**2))),
        "statewise_early_four_step_rmse": np.sqrt(
            np.mean(early**2, axis=(0, 1))
        ).tolist(),
        "final_rmse": float(overall[-1]),
        "statewise_final_rmse": by_state[-1].tolist(),
        "all_states_finite": bool(np.isfinite(states).all()),
    }


def _decisive_partial_filter_metrics(row: dict) -> dict:
    result = _decisive_filter_metrics(row)
    for key in (
        "gate_open_loop_rmse",
        "statewise_gate_open_loop_rmse",
        "gate_ratio_to_open_loop",
        "statewise_gate_ratio_to_open_loop",
    ):
        result[key] = row[key]
    return result


def independently_recompute_partial_observation_metrics(
    output_dir: str | Path,
) -> dict:
    """Recompute decisive ISR04 metrics from persisted raw trajectories."""

    output_path = Path(output_dir)
    loaded = load_and_verify_partial_observation_result(output_path)
    config = PartialObservationRecoveryConfig(**{
        **loaded["config"],
        "knet_seeds": tuple(loaded["config"]["knet_seeds"]),
    })
    config.validate()
    with np.load(output_path / "trajectories.npz") as arrays:
        truth = arrays["truth_states"]
        true_initial = arrays["true_initial_state"]
        estimated_initial = arrays["estimated_initial_state"]
        open_metrics = _numpy_open_loop_summary(
            arrays["open_loop_states"],
            truth,
            true_initial,
            estimated_initial,
        )
        ukf = _add_open_loop_comparison(
            _numpy_filter_summary(
                arrays["ukf_posterior_states"],
                truth,
                true_initial,
                estimated_initial,
                config.recovery_gate_step,
            ),
            open_metrics,
            config.recovery_gate_step,
        )
        knet: dict[str, dict] = {}
        for seed in config.knet_seeds:
            knet[str(seed)] = _add_open_loop_comparison(
                _numpy_filter_summary(
                    arrays[f"kalmannet_seed_{seed}_posterior_states"],
                    truth,
                    true_initial,
                    estimated_initial,
                    config.recovery_gate_step,
                ),
                open_metrics,
                config.recovery_gate_step,
            )
        replay_model = build_partial_observation_model(config)
        cases = IdealCases(
            forcing=torch.from_numpy(arrays["forcing"].copy()),
            observations=torch.from_numpy(arrays["observations"].copy()),
            truth_states=torch.from_numpy(truth.copy()),
            true_initial_state=torch.from_numpy(true_initial.copy()),
            estimated_initial_state=torch.from_numpy(estimated_initial.copy()),
            model_contract_hash=state_dict_sha256(replay_model),
            estimator_contract_hash=state_dict_sha256(replay_model),
            split="evaluation",
        )
        observability = local_observability_metrics(
            replay_model,
            cases,
            horizon=config.observability_horizon,
            rank_tolerance=config.observability_rank_tolerance,
        )
        truth_replay = rollout_multistate_open_loop(
            replay_model,
            cases.forcing,
            cases.true_initial_state,
        )
        return {
            "manifest_verified": True,
            "truth_replay_max_abs_error": float(
                np.max(np.abs(truth_replay.states.detach().numpy() - truth))
            ),
            "observation_truth_max_abs_error": float(
                np.max(np.abs(arrays["observations"] - truth[..., :1]))
            ),
            "local_observability": observability,
            "open_loop": open_metrics,
            "ukf": ukf,
            "kalmannet": knet,
        }


def write_partial_observation_independent_audit(
    output_dir: str | Path,
    *,
    tolerance: float = 1e-12,
) -> dict:
    """Compare persisted ISR04 metrics with raw-trajectory recomputation."""

    output_path = Path(output_dir)
    persisted = load_and_verify_partial_observation_result(output_path)["metrics"]
    recomputed = independently_recompute_partial_observation_metrics(output_path)
    observability_keys = (
        "minimum_rank",
        "minimum_smallest_singular_value",
        "median_smallest_singular_value",
        "maximum_condition_number",
        "median_condition_number",
    )
    open_keys = (
        "initial_rmse",
        "statewise_initial_rmse",
        "rmse_by_time",
        "statewise_rmse_by_time",
        "early_four_step_rmse",
        "statewise_early_four_step_rmse",
        "final_rmse",
        "statewise_final_rmse",
    )
    persisted_decisive = {
        "truth_replay_max_abs_error": persisted["truth_replay_max_abs_error"],
        "observation_truth_max_abs_error": persisted[
            "observation_truth_max_abs_error"
        ],
        "local_observability": {
            key: persisted["local_observability"][key]
            for key in observability_keys
        },
        "open_loop": {key: persisted["open_loop"][key] for key in open_keys},
        "ukf": _decisive_partial_filter_metrics(persisted["conventional_ukf"]),
        "kalmannet": {
            seed: _decisive_partial_filter_metrics(row)
            for seed, row in persisted["kalmannet"].items()
        },
    }
    recomputed_decisive = {
        "truth_replay_max_abs_error": recomputed["truth_replay_max_abs_error"],
        "observation_truth_max_abs_error": recomputed[
            "observation_truth_max_abs_error"
        ],
        "local_observability": {
            key: recomputed["local_observability"][key]
            for key in observability_keys
        },
        "open_loop": {key: recomputed["open_loop"][key] for key in open_keys},
        "ukf": _decisive_partial_filter_metrics(recomputed["ukf"]),
        "kalmannet": {
            seed: _decisive_partial_filter_metrics(row)
            for seed, row in recomputed["kalmannet"].items()
        },
    }
    persisted_leaves = _numeric_leaf_map(persisted_decisive)
    recomputed_leaves = _numeric_leaf_map(recomputed_decisive)
    if persisted_leaves.keys() != recomputed_leaves.keys():
        raise RuntimeError("persisted and recomputed ISR04 metric keys differ")
    differences = {
        key: abs(persisted_leaves[key] - recomputed_leaves[key])
        for key in sorted(persisted_leaves)
    }
    maximum_difference = max(differences.values(), default=0.0)
    audit = {
        "schema_version": "ideal_partial_observation_independent_audit_v1",
        "manifest_verified_before_recompute": True,
        "absolute_tolerance": float(tolerance),
        "maximum_absolute_metric_difference": maximum_difference,
        "metric_differences": differences,
        "status": "PASS" if maximum_difference <= tolerance else "FAIL",
        "recomputed": recomputed,
    }
    (output_path / "independent_recompute.json").write_text(
        json.dumps(audit, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    _write_manifest(output_path)
    if not _verify_manifest(output_path):
        raise RuntimeError("ISR04 manifest failed after independent audit")
    return audit


__all__ = [
    "PartialObservationRecoveryConfig",
    "build_partial_observation_kalmannet",
    "build_partial_observation_model",
    "generate_partial_observation_cases",
    "independently_recompute_partial_observation_metrics",
    "load_and_verify_partial_observation_result",
    "local_observability_metrics",
    "run_partial_observation_experiment",
    "run_partial_observation_kalmannet",
    "run_partial_observation_ukf",
    "train_partial_observation_kalmannet",
    "write_partial_observation_independent_audit",
]
