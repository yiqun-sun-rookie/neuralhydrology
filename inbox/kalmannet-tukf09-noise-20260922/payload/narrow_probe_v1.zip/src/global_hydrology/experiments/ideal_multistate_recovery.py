"""Four-state known-truth recovery for a frozen coupled neural model.

This module is intentionally separate from the sealed one-state ISR01/ISR02
implementation.  The project neural state-space model has four coupled hidden
states and four exact observations.  Truth and estimators share the same
frozen neural model; only their initial states differ.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json
import math
from pathlib import Path

import numpy as np
import torch

from global_hydrology.experiments.ideal_state_recovery import (
    AssimilationTrace,
    ExperimentResult,
    IdealCases,
    OpenLoopTrace,
    _causality_check,
    _positive_covariance,
    _tensor_arrays,
    _verify_manifest,
    _write_manifest,
    state_dict_sha256,
)
from global_hydrology.models.dl_ssm import DLSSMConfig, DLSSMSystemModel
from global_hydrology.models.kalman_net import KalmanNet, KalmanNetConfig


DTYPE = torch.float64
DEVICE = torch.device("cpu")


@dataclass(frozen=True)
class MultiStateRecoveryConfig:
    """Frozen contract for the four-state known-truth recovery experiment."""

    schema_version: str = "ideal_multistate_neural_state_recovery_v1"
    experiment_id: str = "ISR03"
    dtype: str = "float64"
    device: str = "cpu"
    state_dim: int = 4
    observation_dim: int = 4
    forcing_dim: int = 4
    sequence_length: int = 100
    n_train_cases: int = 64
    n_evaluation_cases: int = 32
    training_seed: int = 20260811
    evaluation_seed: int = 20260812
    knet_seeds: tuple[int, ...] = (11, 22, 33)
    knet_epochs: int = 200
    knet_learning_rate: float = 1e-3
    process_variance: float = 1e-10
    observation_variance: float = 1e-8
    initial_variance: float = 1.0
    knet_gate_step: int = 8

    def validate(self) -> None:
        if self.schema_version != "ideal_multistate_neural_state_recovery_v1":
            raise ValueError("unsupported multistate ideal-recovery config schema")
        if self.experiment_id != "ISR03":
            raise ValueError("experiment_id must be ISR03")
        if self.dtype != "float64" or self.device != "cpu":
            raise ValueError("ISR03 requires float64 on cpu")
        if (
            self.state_dim != 4
            or self.observation_dim != 4
            or self.forcing_dim != 4
        ):
            raise ValueError(
                "ISR03 requires exactly four states, observations, and forcings"
            )
        if self.sequence_length < self.knet_gate_step:
            raise ValueError("sequence_length must include the KalmanNet gate step")
        if self.knet_gate_step < 4:
            raise ValueError("knet_gate_step must be at least four")
        if self.n_train_cases < 1 or self.n_evaluation_cases < 1:
            raise ValueError("training and evaluation case counts must be positive")
        if not self.knet_seeds or len(set(self.knet_seeds)) != len(self.knet_seeds):
            raise ValueError("knet_seeds must be nonempty and unique")
        if self.knet_epochs < 1 or self.knet_learning_rate <= 0.0:
            raise ValueError("KalmanNet training budget must be positive")
        for name in (
            "process_variance",
            "observation_variance",
            "initial_variance",
        ):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be positive and finite")

    def to_dict(self) -> dict:
        payload = asdict(self)
        payload["knet_seeds"] = list(self.knet_seeds)
        return payload

    @classmethod
    def from_json(cls, path: str | Path) -> "MultiStateRecoveryConfig":
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        payload["knet_seeds"] = tuple(int(seed) for seed in payload["knet_seeds"])
        config = cls(**payload)
        config.validate()
        return config


def build_multistate_neural_model(
    config: MultiStateRecoveryConfig,
) -> DLSSMSystemModel:
    """Build the actual project neural model with deterministic coupled weights."""

    config.validate()
    model_config = DLSSMConfig(
        state_dim=4,
        obs_dim=4,
        forcing_dim=4,
        static_dim=1,
        static_embed_dim=1,
        init_hidden=4,
        obs_hidden=8,
        dropout=0.0,
        use_static_in_transition=False,
    )
    model = DLSSMSystemModel(model_config).to(device=DEVICE, dtype=DTYPE)
    recurrent = torch.tensor(
        [
            [0.62, 0.10, 0.00, 0.05],
            [0.05, 0.58, 0.12, 0.00],
            [0.00, 0.10, 0.55, 0.14],
            [0.08, 0.00, 0.10, 0.58],
        ],
        dtype=DTYPE,
    )
    forcing = torch.tensor(
        [
            [0.18, 0.02, 0.00, 0.00],
            [0.00, 0.17, 0.03, 0.00],
            [0.00, 0.00, 0.16, 0.04],
            [0.03, 0.00, 0.00, 0.17],
        ],
        dtype=DTYPE,
    )

    with torch.no_grad():
        for parameter in model.parameters():
            parameter.zero_()

        # PyTorch gate order is reset, update, candidate.  The reset gate is
        # nearly one and the update gate nearly zero, so the candidate block
        # defines the intended stable coupled recurrence.
        model.gru_cell.bias_ih[:4] = 20.0
        model.gru_cell.bias_ih[4:8] = -20.0
        model.gru_cell.weight_ih[8:12, :] = forcing
        model.gru_cell.weight_hh[8:12, :] = recurrent

        first = model.obs_net[0]
        last = model.obs_net[3]
        for state_index in range(4):
            positive = 2 * state_index
            negative = positive + 1
            first.weight[positive, state_index] = 1.0
            first.weight[negative, state_index] = -1.0
            last.weight[state_index, positive] = 1.0
            last.weight[state_index, negative] = -1.0

        model.prior_q.copy_(torch.eye(4, dtype=DTYPE))
        model.prior_state_cov.copy_(torch.eye(4, dtype=DTYPE))
        model.prior_r.copy_(torch.eye(4, dtype=DTYPE))

    model.eval()
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    return model


def _validate_multistate_inputs(
    forcing: torch.Tensor,
    initial_state: torch.Tensor,
) -> None:
    if forcing.ndim != 3 or forcing.shape[2] != 4:
        raise ValueError("forcing must have shape [case, time, 4]")
    if initial_state.shape != (forcing.shape[0], 4):
        raise ValueError("initial_state must have shape [case, 4]")
    if forcing.dtype != DTYPE or initial_state.dtype != DTYPE:
        raise ValueError("multistate ideal tensors must use float64")
    if not torch.isfinite(forcing).all() or not torch.isfinite(initial_state).all():
        raise ValueError("forcing and initial_state must be finite")


def rollout_multistate_open_loop(
    model: DLSSMSystemModel,
    forcing: torch.Tensor,
    initial_state: torch.Tensor,
) -> OpenLoopTrace:
    """Roll out the frozen four-state model without reading observations."""

    _validate_multistate_inputs(forcing, initial_state)
    state = initial_state
    states: list[torch.Tensor] = []
    observations: list[torch.Tensor] = []
    for time_index in range(forcing.shape[1]):
        state = model.f(state, forcing[:, time_index, :])
        observation = model.h(state)
        states.append(state)
        observations.append(observation)
    return OpenLoopTrace(
        states=torch.stack(states, dim=1),
        observations=torch.stack(observations, dim=1),
    )


def generate_multistate_cases(
    model: DLSSMSystemModel,
    config: MultiStateRecoveryConfig,
    *,
    split: str,
) -> IdealCases:
    """Generate disjoint deterministic four-state training or evaluation cases."""

    config.validate()
    if split == "training":
        count, seed = config.n_train_cases, config.training_seed
    elif split == "evaluation":
        count, seed = config.n_evaluation_cases, config.evaluation_seed
    else:
        raise ValueError("split must be 'training' or 'evaluation'")

    generator = torch.Generator(device="cpu")
    generator.manual_seed(seed)
    time = torch.arange(config.sequence_length, dtype=DTYPE).reshape(1, -1, 1)
    periods = torch.tensor([9.0, 13.0, 17.0, 23.0], dtype=DTYPE).reshape(1, 1, 4)
    phase = 2.0 * math.pi * torch.rand(
        (count, 1, 4), generator=generator, dtype=DTYPE
    )
    amplitude = 0.30 + 0.25 * torch.rand(
        (count, 1, 4), generator=generator, dtype=DTYPE
    )
    secondary = 0.06 + 0.06 * torch.rand(
        (count, 1, 4), generator=generator, dtype=DTYPE
    )
    forcing = (
        amplitude * torch.sin((2.0 * math.pi / periods) * time + phase)
        + secondary
        * torch.cos((2.0 * math.pi / (periods + 4.0)) * time - phase)
    )

    true_initial = -0.35 + 0.70 * torch.rand(
        (count, 4), generator=generator, dtype=DTYPE
    )
    magnitude = 0.45 + 0.40 * torch.rand(
        (count, 4), generator=generator, dtype=DTYPE
    )
    sign = torch.where(
        torch.rand((count, 4), generator=generator, dtype=DTYPE) < 0.5,
        torch.tensor(-1.0, dtype=DTYPE),
        torch.tensor(1.0, dtype=DTYPE),
    )
    estimated_initial = true_initial + sign * magnitude

    with torch.no_grad():
        truth = rollout_multistate_open_loop(model, forcing, true_initial)
    contract_hash = state_dict_sha256(model)
    return IdealCases(
        forcing=forcing,
        observations=truth.observations,
        truth_states=truth.states,
        true_initial_state=true_initial,
        estimated_initial_state=estimated_initial,
        model_contract_hash=contract_hash,
        estimator_contract_hash=contract_hash,
        split=split,
    )


def run_multistate_ukf(
    model: DLSSMSystemModel,
    cases: IdealCases,
    config: MultiStateRecoveryConfig,
) -> AssimilationTrace:
    """Run a causal full-covariance four-state unscented Kalman filter."""

    from scripts.run_aligned_gr4j_da import (
        constrained_covariance_update,
        merwe_sigma_points,
    )

    config.validate()
    case_count, time_count, state_dim = cases.truth_states.shape
    observation_dim = cases.observations.shape[2]
    if state_dim != 4 or observation_dim != 4:
        raise ValueError("ISR03 requires four states and four observations")
    prior = torch.empty_like(cases.truth_states)
    posterior = torch.empty_like(cases.truth_states)
    prediction = torch.empty_like(cases.observations)
    innovation = torch.empty_like(cases.observations)
    gains = torch.empty((case_count, time_count, 4, 4), dtype=DTYPE)
    covariances = torch.empty((case_count, time_count, 4, 4), dtype=DTYPE)
    process_covariance = torch.eye(4, dtype=DTYPE) * config.process_variance
    observation_covariance = (
        torch.eye(4, dtype=DTYPE) * config.observation_variance
    )

    with torch.no_grad():
        for case_index in range(case_count):
            mean = cases.estimated_initial_state[case_index].clone()
            covariance = torch.eye(4, dtype=DTYPE) * config.initial_variance
            for time_index in range(time_count):
                sigma, mean_weight, covariance_weight = merwe_sigma_points(
                    mean,
                    covariance,
                    alpha=0.3,
                    beta=2.0,
                    kappa=0.0,
                )
                control = cases.forcing[case_index, time_index].expand(
                    sigma.shape[0], 4
                )
                propagated = model.f(sigma, control)
                observed_sigma = model.h(propagated)
                prior_mean = torch.sum(mean_weight[:, None] * propagated, dim=0)
                observation_mean = torch.sum(
                    mean_weight[:, None] * observed_sigma, dim=0
                )
                state_deviation = propagated - prior_mean
                observation_deviation = observed_sigma - observation_mean
                prior_covariance = torch.einsum(
                    "s,si,sj->ij",
                    covariance_weight,
                    state_deviation,
                    state_deviation,
                )
                prior_covariance = _positive_covariance(
                    prior_covariance + process_covariance
                )
                cross_covariance = torch.einsum(
                    "s,si,sj->ij",
                    covariance_weight,
                    state_deviation,
                    observation_deviation,
                )
                innovation_covariance = torch.einsum(
                    "s,si,sj->ij",
                    covariance_weight,
                    observation_deviation,
                    observation_deviation,
                )
                innovation_covariance = _positive_covariance(
                    innovation_covariance + observation_covariance
                )
                gain = torch.linalg.solve(
                    innovation_covariance.T, cross_covariance.T
                ).T

                # Current observation first enters after prior and prediction exist.
                current_innovation = (
                    cases.observations[case_index, time_index]
                    - observation_mean
                )
                mean = prior_mean + (gain @ current_innovation[:, None]).squeeze(1)
                covariance = constrained_covariance_update(
                    prior_covariance,
                    cross_covariance,
                    innovation_covariance,
                    gain,
                )
                covariance = _positive_covariance(covariance)

                prior[case_index, time_index] = prior_mean
                posterior[case_index, time_index] = mean
                prediction[case_index, time_index] = observation_mean
                innovation[case_index, time_index] = current_innovation
                gains[case_index, time_index] = gain
                covariances[case_index, time_index] = covariance

    zeros = torch.zeros_like(cases.truth_states)
    return AssimilationTrace(
        prior_states=prior,
        posterior_states=posterior,
        predicted_observations=prediction,
        innovations=innovation,
        gains=gains,
        posterior_covariances=covariances,
        truth_states=cases.truth_states,
        forward_evolution_features=zeros,
        forward_update_features=zeros,
    )


def build_multistate_kalmannet(
    config: MultiStateRecoveryConfig,
    *,
    seed: int,
) -> KalmanNet:
    """Create the four-state/four-observation KalmanNet gain model."""

    config.validate()
    torch.manual_seed(int(seed))
    network_config = KalmanNetConfig(
        m=4,
        n=4,
        in_mult_KNet=4,
        out_mult_KNet=4,
        d_hidden_Q=16,
        d_hidden_Sigma=24,
        d_hidden_S=16,
        diff_guard_enable=True,
        diff_guard_obs=10.0,
        diff_guard_state=10.0,
    )
    network = KalmanNet(network_config, device=DEVICE).to(
        device=DEVICE, dtype=DTYPE
    )
    with torch.no_grad():
        network.FC2[-1].weight.zero_()
        network.FC2[-1].bias.zero_()
    return network


def run_multistate_kalmannet(
    model: DLSSMSystemModel,
    knet: KalmanNet,
    cases: IdealCases,
) -> AssimilationTrace:
    """Run KalmanNet with causal four-state feature bookkeeping."""

    case_count, time_count, state_dim = cases.truth_states.shape
    observation_dim = cases.observations.shape[2]
    if state_dim != 4 or observation_dim != 4 or knet.m != 4 or knet.n != 4:
        raise ValueError("ISR03 KalmanNet requires m=n=4")
    knet.init_hidden(case_count, model.prior_q, model.prior_state_cov, model.prior_r)

    previous_posterior = cases.estimated_initial_state
    posterior_before_previous = previous_posterior.clone()
    previous_prior = previous_posterior.clone()
    previous_observation = model.h(previous_posterior)

    priors: list[torch.Tensor] = []
    posteriors: list[torch.Tensor] = []
    predictions: list[torch.Tensor] = []
    innovations: list[torch.Tensor] = []
    gains: list[torch.Tensor] = []
    evolution_features: list[torch.Tensor] = []
    update_features: list[torch.Tensor] = []

    for time_index in range(time_count):
        current_prior = model.f(
            previous_posterior,
            cases.forcing[:, time_index, :],
        )
        current_prediction = model.h(current_prior)

        current_observation = cases.observations[:, time_index, :]
        observation_change = current_observation - previous_observation
        current_innovation = current_observation - current_prediction
        forward_evolution = previous_posterior - posterior_before_previous
        previous_analysis_update = previous_posterior - previous_prior
        gain = knet.compute_gain(
            observation_change,
            current_innovation,
            forward_evolution,
            previous_analysis_update,
        )
        correction = torch.bmm(gain, current_innovation.unsqueeze(2)).squeeze(2)
        current_posterior = current_prior + correction

        priors.append(current_prior)
        posteriors.append(current_posterior)
        predictions.append(current_prediction)
        innovations.append(current_innovation)
        gains.append(gain)
        evolution_features.append(forward_evolution)
        update_features.append(previous_analysis_update)

        posterior_before_previous = previous_posterior
        previous_posterior = current_posterior
        previous_prior = current_prior
        previous_observation = current_observation

    return AssimilationTrace(
        prior_states=torch.stack(priors, dim=1),
        posterior_states=torch.stack(posteriors, dim=1),
        predicted_observations=torch.stack(predictions, dim=1),
        innovations=torch.stack(innovations, dim=1),
        gains=torch.stack(gains, dim=1),
        posterior_covariances=torch.zeros(
            (case_count, time_count, 4, 4), dtype=DTYPE
        ),
        truth_states=cases.truth_states,
        forward_evolution_features=torch.stack(evolution_features, dim=1),
        forward_update_features=torch.stack(update_features, dim=1),
    )


def train_multistate_kalmannet(
    model: DLSSMSystemModel,
    training_cases: IdealCases,
    config: MultiStateRecoveryConfig,
    *,
    seed: int,
    epochs: int | None = None,
) -> tuple[KalmanNet, list[float]]:
    """Train only KalmanNet against all four known posterior-state truths."""

    config.validate()
    budget = int(config.knet_epochs if epochs is None else epochs)
    if budget < 1:
        raise ValueError("epochs must be positive")
    model_hash = state_dict_sha256(model)
    if any(parameter.requires_grad for parameter in model.parameters()):
        raise ValueError("neural system model must be frozen before KalmanNet training")
    knet = build_multistate_kalmannet(config, seed=seed)
    optimizer = torch.optim.Adam(knet.parameters(), lr=config.knet_learning_rate)
    history: list[float] = []
    knet.train()
    for _ in range(budget):
        optimizer.zero_grad(set_to_none=True)
        trace = run_multistate_kalmannet(model, knet, training_cases)
        loss = torch.mean(
            (trace.posterior_states - training_cases.truth_states).square()
        )
        if not torch.isfinite(loss):
            raise RuntimeError("multistate KalmanNet loss became nonfinite")
        loss.backward()
        gradient_norm = torch.nn.utils.clip_grad_norm_(
            knet.parameters(), max_norm=10.0
        )
        if not torch.isfinite(torch.as_tensor(gradient_norm)):
            raise RuntimeError("multistate KalmanNet gradient became nonfinite")
        optimizer.step()
        history.append(float(loss.detach().cpu()))
    if state_dict_sha256(model) != model_hash:
        raise RuntimeError("KalmanNet training changed the frozen neural system model")
    knet.eval()
    return knet, history


def statewise_rmse(estimate: torch.Tensor, truth: torch.Tensor) -> torch.Tensor:
    """Return one root-mean-square error for each final state coordinate."""

    if estimate.shape != truth.shape or estimate.shape[-1] != 4:
        raise ValueError("estimate and truth must share a final dimension of four")
    reduction_dimensions = tuple(range(estimate.ndim - 1))
    return torch.sqrt(torch.mean((estimate - truth).square(), dim=reduction_dimensions))


def _rmse_by_time(
    estimate: torch.Tensor,
    truth: torch.Tensor,
) -> tuple[np.ndarray, np.ndarray]:
    error = estimate - truth
    overall = torch.sqrt(torch.mean(error.square(), dim=(0, 2)))
    by_state = torch.sqrt(torch.mean(error.square(), dim=0))
    return (
        overall.detach().cpu().numpy().astype(np.float64),
        by_state.detach().cpu().numpy().astype(np.float64),
    )


def _initial_rmses(cases: IdealCases) -> tuple[float, np.ndarray]:
    error = cases.estimated_initial_state - cases.true_initial_state
    overall = float(torch.sqrt(torch.mean(error.square())).detach().cpu())
    by_state = (
        torch.sqrt(torch.mean(error.square(), dim=0))
        .detach()
        .cpu()
        .numpy()
        .astype(np.float64)
    )
    return overall, by_state


def _trace_metrics(
    trace: AssimilationTrace,
    initial_rmse: float,
    statewise_initial_rmse: np.ndarray,
    gate_step: int,
) -> dict:
    posterior, statewise_posterior = _rmse_by_time(
        trace.posterior_states, trace.truth_states
    )
    prior, statewise_prior = _rmse_by_time(trace.prior_states, trace.truth_states)
    gate_index = gate_step - 1
    return {
        "initial_rmse": float(initial_rmse),
        "statewise_initial_rmse": statewise_initial_rmse.tolist(),
        "prior_rmse_by_time": prior.tolist(),
        "posterior_rmse_by_time": posterior.tolist(),
        "statewise_prior_rmse_by_time": statewise_prior.tolist(),
        "statewise_posterior_rmse_by_time": statewise_posterior.tolist(),
        "step1_posterior_rmse": float(posterior[0]),
        "step4_posterior_rmse": float(posterior[3]),
        "gate_step": int(gate_step),
        "gate_posterior_rmse": float(posterior[gate_index]),
        "final_posterior_rmse": float(posterior[-1]),
        "statewise_step1_posterior_rmse": statewise_posterior[0].tolist(),
        "statewise_step4_posterior_rmse": statewise_posterior[3].tolist(),
        "statewise_gate_posterior_rmse": statewise_posterior[gate_index].tolist(),
        "statewise_final_posterior_rmse": statewise_posterior[-1].tolist(),
        "step4_ratio_to_initial": float(posterior[3] / initial_rmse),
        "gate_ratio_to_initial": float(posterior[gate_index] / initial_rmse),
        "final_ratio_to_initial": float(posterior[-1] / initial_rmse),
        "statewise_step4_ratio_to_initial": (
            statewise_posterior[3] / statewise_initial_rmse
        ).tolist(),
        "statewise_gate_ratio_to_initial": (
            statewise_posterior[gate_index] / statewise_initial_rmse
        ).tolist(),
        "statewise_final_ratio_to_initial": (
            statewise_posterior[-1] / statewise_initial_rmse
        ).tolist(),
        "all_states_finite": bool(torch.isfinite(trace.posterior_states).all()),
    }


def _open_loop_metrics(trace: OpenLoopTrace, cases: IdealCases) -> dict:
    initial_rmse, statewise_initial = _initial_rmses(cases)
    overall, by_state = _rmse_by_time(trace.states, cases.truth_states)
    early_error = trace.states[:, :4, :] - cases.truth_states[:, :4, :]
    early_overall = float(
        torch.sqrt(torch.mean(early_error.square())).detach().cpu()
    )
    early_by_state = (
        torch.sqrt(torch.mean(early_error.square(), dim=(0, 1)))
        .detach()
        .cpu()
        .numpy()
        .astype(np.float64)
    )
    return {
        "initial_rmse": initial_rmse,
        "statewise_initial_rmse": statewise_initial.tolist(),
        "rmse_by_time": overall.tolist(),
        "statewise_rmse_by_time": by_state.tolist(),
        "early_four_step_rmse": early_overall,
        "statewise_early_four_step_rmse": early_by_state.tolist(),
        "final_rmse": float(overall[-1]),
        "statewise_final_rmse": by_state[-1].tolist(),
        "all_states_finite": bool(torch.isfinite(trace.states).all()),
    }


def _restore_multistate_kalmannet(
    config: MultiStateRecoveryConfig,
    checkpoint_path: Path,
) -> KalmanNet:
    payload = torch.load(checkpoint_path, map_location=DEVICE, weights_only=False)
    network = build_multistate_kalmannet(config, seed=int(payload["seed"]))
    network.load_state_dict(payload["knet_state_dict"])
    network.eval()
    return network


def run_multistate_experiment(
    config: MultiStateRecoveryConfig,
    *,
    output_dir: str | Path,
) -> ExperimentResult:
    """Run ISR03 and write an atomic fail-closed result bundle."""

    config.validate()
    output_path = Path(output_dir)
    if output_path.exists() and any(output_path.iterdir()):
        raise FileExistsError(f"refusing nonempty output directory: {output_path}")
    output_path.mkdir(parents=True, exist_ok=True)

    model = build_multistate_neural_model(config)
    model_hash_before = state_dict_sha256(model)
    training_cases = generate_multistate_cases(model, config, split="training")
    evaluation_cases = generate_multistate_cases(model, config, split="evaluation")
    truth_replay = rollout_multistate_open_loop(
        model,
        evaluation_cases.forcing,
        evaluation_cases.true_initial_state,
    )
    truth_replay_max_error = float(
        torch.max(torch.abs(truth_replay.states - evaluation_cases.truth_states))
        .detach()
        .cpu()
    )
    observation_truth_max_error = float(
        torch.max(torch.abs(evaluation_cases.observations - evaluation_cases.truth_states))
        .detach()
        .cpu()
    )
    open_loop = rollout_multistate_open_loop(
        model,
        evaluation_cases.forcing,
        evaluation_cases.estimated_initial_state,
    )
    ukf = run_multistate_ukf(model, evaluation_cases, config)
    initial_rmse, statewise_initial_rmse = _initial_rmses(evaluation_cases)

    knet_metrics: dict[str, dict] = {}
    knet_traces: dict[int, AssimilationTrace] = {}
    training_history: dict[str, list[float]] = {}
    for seed in config.knet_seeds:
        network, history = train_multistate_kalmannet(
            model,
            training_cases,
            config,
            seed=int(seed),
        )
        trace = run_multistate_kalmannet(model, network, evaluation_cases)
        seed_key = str(seed)
        row = _trace_metrics(
            trace,
            initial_rmse,
            statewise_initial_rmse,
            config.knet_gate_step,
        )
        row["training_loss_first"] = history[0]
        row["training_loss_final"] = history[-1]
        knet_metrics[seed_key] = row
        knet_traces[int(seed)] = trace
        training_history[seed_key] = history
        torch.save(
            {
                "schema_version": config.schema_version,
                "experiment_id": config.experiment_id,
                "seed": int(seed),
                "knet_state_dict": network.state_dict(),
                "training_history": history,
            },
            output_path / f"kalmannet_seed_{seed}.pt",
        )

    model_hash_after = state_dict_sha256(model)
    open_metrics = _open_loop_metrics(open_loop, evaluation_cases)
    ukf_metrics = _trace_metrics(
        ukf,
        initial_rmse,
        statewise_initial_rmse,
        config.knet_gate_step,
    )
    cutoff = min(config.knet_gate_step - 1, config.sequence_length - 2)
    ukf_causal = _causality_check(
        lambda selected: run_multistate_ukf(model, selected, config),
        model,
        evaluation_cases,
        cutoff,
    )
    knet_causal = all(
        _causality_check(
            lambda selected, network_seed=seed: run_multistate_kalmannet(
                model,
                _restore_multistate_kalmannet(
                    config, output_path / f"kalmannet_seed_{network_seed}.pt"
                ),
                selected,
            ),
            model,
            evaluation_cases,
            cutoff,
        )
        for seed in config.knet_seeds
    )

    gates = {
        "truth_replay_max_abs_le_1e-12": truth_replay_max_error <= 1e-12,
        "observations_equal_truth_max_abs_le_1e-12": (
            observation_truth_max_error <= 1e-12
        ),
        "open_loop_each_state_early_rmse_ge_0_05": all(
            value >= 0.05
            for value in open_metrics["statewise_early_four_step_rmse"]
        ),
        "ukf_step4_overall_ratio_le_1e-4": (
            ukf_metrics["step4_ratio_to_initial"] <= 1e-4
        ),
        "ukf_each_state_step4_ratio_le_1e-4": all(
            value <= 1e-4
            for value in ukf_metrics["statewise_step4_ratio_to_initial"]
        ),
        "ukf_all_states_finite": ukf_metrics["all_states_finite"],
        "ukf_causal": ukf_causal,
        "kalmannet_all_seeds_gate_overall_ratio_le_0_10": all(
            row["gate_ratio_to_initial"] <= 0.10
            for row in knet_metrics.values()
        ),
        "kalmannet_all_seeds_each_state_gate_ratio_le_0_20": all(
            all(value <= 0.20 for value in row["statewise_gate_ratio_to_initial"])
            for row in knet_metrics.values()
        ),
        "kalmannet_all_seeds_final_overall_ratio_le_0_01": all(
            row["final_ratio_to_initial"] <= 0.01
            for row in knet_metrics.values()
        ),
        "kalmannet_all_seeds_each_state_final_ratio_le_0_02": all(
            all(value <= 0.02 for value in row["statewise_final_ratio_to_initial"])
            for row in knet_metrics.values()
        ),
        "kalmannet_all_states_finite": all(
            row["all_states_finite"] for row in knet_metrics.values()
        ),
        "kalmannet_causal": knet_causal,
        "frozen_neural_model_hash_unchanged": model_hash_before == model_hash_after,
    }
    verdict = "PASS" if all(gates.values()) else "FAIL"
    metrics = {
        "schema_version": config.schema_version,
        "experiment_id": config.experiment_id,
        "verdict": verdict,
        "truth_replay_max_abs_error": truth_replay_max_error,
        "observation_truth_max_abs_error": observation_truth_max_error,
        "open_loop": open_metrics,
        "conventional_ukf": ukf_metrics,
        "kalmannet": knet_metrics,
        "kalmannet_parameter_count": int(
            sum(parameter.numel() for parameter in network.parameters())
        ),
        "model_hash_before": model_hash_before,
        "model_hash_after": model_hash_after,
        "causality_cutoff_index": cutoff,
        "gates": gates,
    }

    arrays: dict[str, np.ndarray] = {
        "forcing": evaluation_cases.forcing.numpy(),
        "observations": evaluation_cases.observations.numpy(),
        "truth_states": evaluation_cases.truth_states.numpy(),
        "true_initial_state": evaluation_cases.true_initial_state.numpy(),
        "estimated_initial_state": evaluation_cases.estimated_initial_state.numpy(),
        "open_loop_states": open_loop.states.detach().numpy(),
        **_tensor_arrays("ukf", ukf),
    }
    for seed, trace in knet_traces.items():
        arrays.update(_tensor_arrays(f"kalmannet_seed_{seed}", trace))

    (output_path / "config.snapshot.json").write_text(
        json.dumps(config.to_dict(), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    (output_path / "metrics.json").write_text(
        json.dumps(metrics, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    (output_path / "training_history.json").write_text(
        json.dumps(training_history, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    np.savez_compressed(output_path / "trajectories.npz", **arrays)
    _write_manifest(output_path)
    if not _verify_manifest(output_path):
        raise RuntimeError("multistate result manifest verification failed")

    registry_path = output_path.parent / "registry.jsonl"
    registry_row = {
        "exp_id": config.experiment_id,
        "type": "known_truth_multistate_state_recovery",
        "hypothesis": (
            "UKF and KalmanNet remove coupled four-state initial-state error"
        ),
        "base_config": config.schema_version,
        "changed_factor": "one_to_four_coupled_state_dimensions",
        "fixed_factors": (
            "frozen neural model, forcing, exact full-state observations, "
            "initial-error-only mismatch"
        ),
        "seeds": list(config.knet_seeds),
        "status": verdict,
        "run_dir": str(output_path.resolve()),
        "best_checkpoint": None,
        "metrics_path": str((output_path / "metrics.json").resolve()),
        "paper_name": None,
        "notes": (
            "Engineering multistate ideal case; not partial-observation or "
            "real-basin evidence"
        ),
    }
    with registry_path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(registry_row, sort_keys=True) + "\n")
    return ExperimentResult(output_dir=output_path, verdict=verdict, metrics=metrics)


def load_and_verify_multistate_result(output_dir: str | Path) -> dict:
    """Verify the manifest before loading ISR03 metadata and metrics."""

    output_path = Path(output_dir)
    if not _verify_manifest(output_path):
        raise ValueError("multistate result manifest is missing or invalid")
    return {
        "manifest_verified": True,
        "config": json.loads(
            (output_path / "config.snapshot.json").read_text(encoding="utf-8")
        ),
        "metrics": json.loads(
            (output_path / "metrics.json").read_text(encoding="utf-8")
        ),
    }


def _numpy_filter_summary(
    states: np.ndarray,
    truth: np.ndarray,
    true_initial: np.ndarray,
    estimated_initial: np.ndarray,
    gate_step: int,
) -> dict:
    initial_error = estimated_initial - true_initial
    initial_rmse = float(np.sqrt(np.mean(initial_error**2)))
    statewise_initial = np.sqrt(np.mean(initial_error**2, axis=0))
    error = states - truth
    overall = np.sqrt(np.mean(error**2, axis=(0, 2)))
    by_state = np.sqrt(np.mean(error**2, axis=0))
    gate_index = gate_step - 1
    return {
        "initial_rmse": initial_rmse,
        "statewise_initial_rmse": statewise_initial.tolist(),
        "step1_posterior_rmse": float(overall[0]),
        "step4_posterior_rmse": float(overall[3]),
        "gate_posterior_rmse": float(overall[gate_index]),
        "final_posterior_rmse": float(overall[-1]),
        "statewise_step1_posterior_rmse": by_state[0].tolist(),
        "statewise_step4_posterior_rmse": by_state[3].tolist(),
        "statewise_gate_posterior_rmse": by_state[gate_index].tolist(),
        "statewise_final_posterior_rmse": by_state[-1].tolist(),
        "step4_ratio_to_initial": float(overall[3] / initial_rmse),
        "gate_ratio_to_initial": float(overall[gate_index] / initial_rmse),
        "final_ratio_to_initial": float(overall[-1] / initial_rmse),
        "statewise_step4_ratio_to_initial": (
            by_state[3] / statewise_initial
        ).tolist(),
        "statewise_gate_ratio_to_initial": (
            by_state[gate_index] / statewise_initial
        ).tolist(),
        "statewise_final_ratio_to_initial": (
            by_state[-1] / statewise_initial
        ).tolist(),
    }


def _decisive_filter_metrics(row: dict) -> dict:
    keys = (
        "initial_rmse",
        "statewise_initial_rmse",
        "step1_posterior_rmse",
        "step4_posterior_rmse",
        "gate_posterior_rmse",
        "final_posterior_rmse",
        "statewise_step1_posterior_rmse",
        "statewise_step4_posterior_rmse",
        "statewise_gate_posterior_rmse",
        "statewise_final_posterior_rmse",
        "step4_ratio_to_initial",
        "gate_ratio_to_initial",
        "final_ratio_to_initial",
        "statewise_step4_ratio_to_initial",
        "statewise_gate_ratio_to_initial",
        "statewise_final_ratio_to_initial",
    )
    return {key: row[key] for key in keys}


def independently_recompute_multistate_metrics(output_dir: str | Path) -> dict:
    """Recompute decisive ISR03 metrics from persisted raw trajectories only."""

    output_path = Path(output_dir)
    loaded = load_and_verify_multistate_result(output_path)
    config = loaded["config"]
    with np.load(output_path / "trajectories.npz") as arrays:
        truth = arrays["truth_states"]
        true_initial = arrays["true_initial_state"]
        estimated_initial = arrays["estimated_initial_state"]
        recomputed = {
            "manifest_verified": True,
            "ukf": _numpy_filter_summary(
                arrays["ukf_posterior_states"],
                truth,
                true_initial,
                estimated_initial,
                int(config["knet_gate_step"]),
            ),
            "kalmannet": {},
        }
        for seed in config["knet_seeds"]:
            recomputed["kalmannet"][str(seed)] = _numpy_filter_summary(
                arrays[f"kalmannet_seed_{seed}_posterior_states"],
                truth,
                true_initial,
                estimated_initial,
                int(config["knet_gate_step"]),
            )
    return recomputed


def _numeric_leaf_map(value, prefix: str = "") -> dict[str, float]:
    leaves: dict[str, float] = {}
    if isinstance(value, dict):
        for key, child in value.items():
            child_prefix = f"{prefix}.{key}" if prefix else str(key)
            leaves.update(_numeric_leaf_map(child, child_prefix))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            leaves.update(_numeric_leaf_map(child, f"{prefix}[{index}]"))
    elif isinstance(value, (int, float)) and not isinstance(value, bool):
        leaves[prefix] = float(value)
    return leaves


def write_multistate_independent_audit(
    output_dir: str | Path,
    *,
    tolerance: float = 1e-12,
) -> dict:
    """Compare persisted ISR03 metrics with raw-trajectory recomputation."""

    output_path = Path(output_dir)
    persisted = load_and_verify_multistate_result(output_path)["metrics"]
    recomputed = independently_recompute_multistate_metrics(output_path)
    persisted_decisive = {
        "ukf": _decisive_filter_metrics(persisted["conventional_ukf"]),
        "kalmannet": {
            seed: _decisive_filter_metrics(row)
            for seed, row in persisted["kalmannet"].items()
        },
    }
    recomputed_decisive = {
        "ukf": recomputed["ukf"],
        "kalmannet": recomputed["kalmannet"],
    }
    persisted_leaves = _numeric_leaf_map(persisted_decisive)
    recomputed_leaves = _numeric_leaf_map(recomputed_decisive)
    if persisted_leaves.keys() != recomputed_leaves.keys():
        raise RuntimeError("persisted and recomputed ISR03 metric keys differ")
    differences = {
        key: abs(persisted_leaves[key] - recomputed_leaves[key])
        for key in sorted(persisted_leaves)
    }
    maximum_difference = max(differences.values(), default=0.0)
    audit = {
        "schema_version": "ideal_multistate_recovery_independent_audit_v1",
        "manifest_verified_before_recompute": True,
        "absolute_tolerance": float(tolerance),
        "maximum_absolute_metric_difference": maximum_difference,
        "metric_differences": differences,
        "status": "PASS" if maximum_difference <= tolerance else "FAIL",
        "recomputed": recomputed,
    }
    (output_path / "independent_recompute.json").write_text(
        json.dumps(audit, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    _write_manifest(output_path)
    if not _verify_manifest(output_path):
        raise RuntimeError("multistate result manifest failed after independent audit")
    return audit


__all__ = [
    "MultiStateRecoveryConfig",
    "build_multistate_kalmannet",
    "build_multistate_neural_model",
    "generate_multistate_cases",
    "independently_recompute_multistate_metrics",
    "load_and_verify_multistate_result",
    "rollout_multistate_open_loop",
    "run_multistate_experiment",
    "run_multistate_kalmannet",
    "run_multistate_ukf",
    "statewise_rmse",
    "train_multistate_kalmannet",
    "write_multistate_independent_audit",
]
