"""Complete, non-interpretive trajectory diagnostics for the HBV filter state."""

from __future__ import annotations

import csv
from dataclasses import dataclass
import json
from pathlib import Path
from typing import Sequence

import numpy as np


@dataclass(frozen=True)
class StateDefinition:
    index: int
    name: str
    group: str
    unit: str
    active: bool
    description: str


@dataclass(frozen=True)
class StateTrajectoryBundle:
    basin_id: str
    dates: np.ndarray
    open_loop: np.ndarray
    prior: np.ndarray
    posterior: np.ndarray
    correction: np.ndarray
    definitions: Sequence[StateDefinition]

    def __post_init__(self) -> None:
        arrays = (self.open_loop, self.prior, self.posterior, self.correction)
        if any(array.ndim != 2 for array in arrays):
            raise ValueError("every state trajectory array must be two-dimensional")
        if len({array.shape for array in arrays}) != 1:
            raise ValueError("state trajectory arrays must have identical shapes")
        time_steps, state_count = self.open_loop.shape
        if len(self.dates) != time_steps:
            raise ValueError("date count does not match trajectory length")
        if len(self.definitions) != state_count:
            raise ValueError("state definitions do not match trajectory width")
        if not all(np.isfinite(array).all() for array in arrays):
            raise ValueError("state trajectories contain nonfinite values")


def build_state_definitions(
    maximum_routing_lag: int,
    active_routing_lag: int,
    residual_memory_order: int = 2,
) -> tuple[StateDefinition, ...]:
    """List every physical storage, routed-memory, and residual-memory state."""

    if maximum_routing_lag < 1:
        raise ValueError("maximum_routing_lag must be positive")
    if not 1 <= active_routing_lag <= maximum_routing_lag:
        raise ValueError("active_routing_lag is outside the padded routing state")
    if residual_memory_order not in (0, 2):
        raise ValueError("residual_memory_order must be zero or two")
    storage = (
        ("snowpack solid-water storage", "solid snow water equivalent"),
        ("liquid water held in snowpack", "liquid meltwater retained in snow"),
        ("soil-moisture storage", "water held in the soil reservoir"),
        ("upper groundwater-reservoir storage", "fast groundwater reservoir"),
        ("lower groundwater-reservoir storage", "slow groundwater reservoir"),
    )
    definitions: list[StateDefinition] = []
    for index, (name, description) in enumerate(storage):
        definitions.append(
            StateDefinition(index, name, "HBV storage", "mm", True, description)
        )
    for lag in range(maximum_routing_lag):
        active = lag < active_routing_lag
        definitions.append(
            StateDefinition(
                index=5 + lag,
                name=f"routed-discharge memory at lag {lag} day",
                group="routing memory",
                unit="mm day-1",
                active=active,
                description=(
                    "active routed discharge memory"
                    if active
                    else "inactive zero padding used only to share one state dimension"
                ),
            )
        )
    if residual_memory_order == 2:
        definitions.extend(
            (
                StateDefinition(
                    len(definitions),
                    "current autoregressive discharge residual",
                    "discharge residual memory",
                    "mm day-1",
                    True,
                    "signed current model-discharge residual",
                ),
                StateDefinition(
                    len(definitions) + 1,
                    "previous autoregressive discharge residual",
                    "discharge residual memory",
                    "mm day-1",
                    True,
                    "signed one-day-old model-discharge residual",
                ),
            )
        )
    return tuple(definitions)


def load_state_trajectory_bundle(
    prediction_path: Path,
    metric_path: Path,
    *,
    basin_id: str,
    maximum_routing_lag: int = 15,
    residual_memory_order: int = 2,
) -> StateTrajectoryBundle:
    basin_id = str(basin_id).zfill(8)
    metrics = json.loads(metric_path.read_text(encoding="utf-8"))
    matching = [row for row in metrics if str(row.get("basin", "")).zfill(8) == basin_id]
    if len(matching) != 1:
        raise ValueError(f"expected one metric row for basin {basin_id}")
    active_lag = int(matching[0]["active_routing_lag"])
    definitions = build_state_definitions(
        maximum_routing_lag, active_lag, residual_memory_order
    )
    prefix = f"basin_{basin_id}__"
    with np.load(prediction_path, allow_pickle=False) as bundle:
        required = {
            "dates": prefix + "dates",
            "open_loop": prefix + "open_loop_states",
            "prior": prefix + "prior_states",
            "posterior": prefix + "posterior_states",
            "correction": prefix + "corrections",
        }
        missing = [key for key in required.values() if key not in bundle.files]
        if missing:
            raise KeyError(f"prediction bundle is missing arrays: {missing}")
        arrays = {name: np.asarray(bundle[key]).copy() for name, key in required.items()}
    open_loop = arrays["open_loop"]
    if open_loop.ndim == 3 and open_loop.shape[1] == 1:
        open_loop = open_loop[:, 0, :]
    return StateTrajectoryBundle(
        basin_id=basin_id,
        dates=arrays["dates"],
        open_loop=open_loop,
        prior=arrays["prior"],
        posterior=arrays["posterior"],
        correction=arrays["correction"],
        definitions=definitions,
    )


def _write_state_summary(bundle: StateTrajectoryBundle, path: Path) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=(
                "state_index",
                "state_name",
                "group",
                "unit",
                "active",
                "description",
                "open_loop_minimum",
                "open_loop_maximum",
                "prior_minimum",
                "prior_maximum",
                "posterior_minimum",
                "posterior_maximum",
                "mean_absolute_proposed_correction",
                "maximum_absolute_proposed_correction",
                "mean_absolute_realized_update",
                "maximum_absolute_realized_update",
            ),
        )
        writer.writeheader()
        for definition in bundle.definitions:
            index = definition.index
            writer.writerow(
                {
                    "state_index": index,
                    "state_name": definition.name,
                    "group": definition.group,
                    "unit": definition.unit,
                    "active": definition.active,
                    "description": definition.description,
                    "open_loop_minimum": float(np.min(bundle.open_loop[:, index])),
                    "open_loop_maximum": float(np.max(bundle.open_loop[:, index])),
                    "prior_minimum": float(np.min(bundle.prior[:, index])),
                    "prior_maximum": float(np.max(bundle.prior[:, index])),
                    "posterior_minimum": float(np.min(bundle.posterior[:, index])),
                    "posterior_maximum": float(np.max(bundle.posterior[:, index])),
                    "mean_absolute_proposed_correction": float(
                        np.mean(np.abs(bundle.correction[:, index]))
                    ),
                    "maximum_absolute_proposed_correction": float(
                        np.max(np.abs(bundle.correction[:, index]))
                    ),
                    "mean_absolute_realized_update": float(
                        np.mean(np.abs(bundle.posterior[:, index] - bundle.prior[:, index]))
                    ),
                    "maximum_absolute_realized_update": float(
                        np.max(np.abs(bundle.posterior[:, index] - bundle.prior[:, index]))
                    ),
                }
            )


def _write_long_trajectory(bundle: StateTrajectoryBundle, path: Path) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=(
                "date",
                "state_index",
                "state_name",
                "active",
                "open_loop",
                "prior",
                "posterior",
                "proposed_correction_before_state_projection",
                "realized_update_after_state_projection",
            ),
        )
        writer.writeheader()
        for time_index, date in enumerate(bundle.dates):
            for definition in bundle.definitions:
                state_index = definition.index
                writer.writerow(
                    {
                        "date": str(date),
                        "state_index": state_index,
                        "state_name": definition.name,
                        "active": definition.active,
                        "open_loop": float(bundle.open_loop[time_index, state_index]),
                        "prior": float(bundle.prior[time_index, state_index]),
                        "posterior": float(bundle.posterior[time_index, state_index]),
                        "proposed_correction_before_state_projection": float(
                            bundle.correction[time_index, state_index]
                        ),
                        "realized_update_after_state_projection": float(
                            bundle.posterior[time_index, state_index]
                            - bundle.prior[time_index, state_index]
                        ),
                    }
                )


def _plot_state_grid(
    bundle: StateTrajectoryBundle,
    path: Path,
    *,
    corrections_only: bool,
) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.dates as mdates
    import matplotlib.pyplot as plt

    state_count = len(bundle.definitions)
    columns = 4
    rows = int(np.ceil(state_count / columns))
    dates = np.asarray(bundle.dates, dtype="datetime64[D]")
    figure, axes = plt.subplots(
        rows, columns, figsize=(20, 4.0 * rows), sharex=True, constrained_layout=True
    )
    axes_flat = np.asarray(axes).reshape(-1)
    for definition, axis in zip(bundle.definitions, axes_flat):
        index = definition.index
        inactive_suffix = " [inactive padding]" if not definition.active else ""
        if corrections_only:
            axis.axhline(0.0, color="#666666", linewidth=0.7)
            axis.plot(
                dates,
                bundle.correction[:, index],
                color="#E69F00",
                linestyle="--",
                linewidth=0.7,
                alpha=0.8,
                label="proposed correction before projection",
            )
            axis.plot(
                dates,
                bundle.posterior[:, index] - bundle.prior[:, index],
                color="#0072B2",
                linewidth=0.9,
                label="realized posterior minus prior",
            )
            axis.set_ylabel(f"Correction ({definition.unit})", fontsize=7)
        else:
            axis.plot(
                dates,
                bundle.open_loop[:, index],
                color="#777777",
                linestyle="--",
                linewidth=0.8,
                label="HBV open loop",
            )
            axis.plot(
                dates,
                bundle.prior[:, index],
                color="#E69F00",
                linewidth=0.8,
                alpha=0.85,
                label="filter prior",
            )
            axis.plot(
                dates,
                bundle.posterior[:, index],
                color="#0072B2",
                linewidth=0.9,
                label="filter posterior",
            )
            axis.set_ylabel(definition.unit, fontsize=7)
        axis.set_title(
            f"{definition.index:02d}. {definition.name}{inactive_suffix}", fontsize=8
        )
        axis.grid(alpha=0.2, linewidth=0.5)
        axis.tick_params(labelsize=7)
        axis.xaxis.set_major_locator(mdates.AutoDateLocator(minticks=3, maxticks=5))
        axis.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m"))
    for axis in axes_flat[state_count:]:
        axis.set_visible(False)
    axes_flat[0].legend(loc="upper right", fontsize=6, framealpha=0.8)
    title = (
        "All state corrections through time"
        if corrections_only
        else "All HBV, routing-memory, and residual-memory state trajectories"
    )
    figure.suptitle(f"Basin {bundle.basin_id}: {title}", fontsize=14)
    figure.savefig(path, dpi=180)
    plt.close(figure)


def create_state_diagnostic_artifacts(
    bundle: StateTrajectoryBundle, output_directory: Path
) -> dict[str, Path]:
    """Write complete plots and tables without treating internal states as truth."""

    output_directory = Path(output_directory)
    output_directory.mkdir(parents=True, exist_ok=True)
    outputs = {
        "trajectory_figure": output_directory / "all_state_trajectories.png",
        "correction_figure": output_directory / "all_state_corrections.png",
        "state_summary": output_directory / "all_state_summary.csv",
        "state_trajectory_table": output_directory / "all_state_trajectories.csv",
        "manifest": output_directory / "state_diagnostics_manifest.json",
    }
    _write_state_summary(bundle, outputs["state_summary"])
    _write_long_trajectory(bundle, outputs["state_trajectory_table"])
    _plot_state_grid(bundle, outputs["trajectory_figure"], corrections_only=False)
    _plot_state_grid(bundle, outputs["correction_figure"], corrections_only=True)
    proposed_to_realized_difference = float(
        np.max(np.abs((bundle.posterior - bundle.prior) - bundle.correction))
    )
    manifest = {
        "basin_id": bundle.basin_id,
        "time_steps": int(len(bundle.dates)),
        "state_count": int(len(bundle.definitions)),
        "proposed_correction_to_realized_update_maximum_absolute_difference": (
            proposed_to_realized_difference
        ),
        "correction_definition": (
            "The stored correction is the network proposal before state-bound projection; "
            "the realized update is posterior minus prior after projection."
        ),
        "interpretation_limit": (
            "These are model-internal states. Real-basin state truth is unavailable, "
            "so the plots diagnose updates but do not validate physical state accuracy."
        ),
        "outputs": {name: str(path.resolve()) for name, path in outputs.items() if name != "manifest"},
    }
    outputs["manifest"].write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    return outputs
