"""Reference contract for basin-balanced daily CAMELS KalmanNet training loss.

This module intentionally depends only on the Python standard library.  It is
an auditable reference for a future shared-training integration; importing it
does not import NumPy, PyTorch, a data loader, or any evaluation code.

For basins ``b`` and daily forecast leads ``h in {1, 2, 3}``, the contract is

    L = mean_b(mean_h(mean_t((prediction[b,h,t] - target[b,h,t])**2)
                         / effective_training_variance[b]))

where each ``t`` mean contains only finite targets for that basin and lead.
The target count therefore changes only the within-cell event weight.  It does
not change the weight of a lead or basin.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from hashlib import sha256
import json
import math
from typing import Iterable, Mapping, Sequence


CONTRACT_NAME = "daily_camels_training_variance_basin_lead_equal_v1"
DAILY_FORECAST_LEADS = (1, 2, 3)
DEFAULT_VARIANCE_FLOOR = 1.0e-6


@dataclass(frozen=True)
class TrainingVarianceEvidence:
    """Training-only population-variance evidence for one basin.

    ``validation_start_index`` is also the exclusive end of the statistics
    window.  This naming is deliberate: callers cannot provide a separate,
    later end index that silently includes validation or evaluation targets.
    """

    contract_name: str
    basin_id: str
    training_start_index: int
    validation_start_index: int
    finite_observation_count: int
    missing_observation_count: int
    finite_observation_mean: float
    raw_population_variance: float
    variance_floor: float
    effective_training_variance: float
    variance_floor_applied: bool

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True)
class BasinLeadLossEvidence:
    """One equally weighted basin/lead cell in the shared objective."""

    basin_id: str
    lead_days: int
    finite_target_count: int
    missing_target_count: int
    physical_mean_squared_error: float
    normalized_mean_squared_error: float
    physical_squared_error_weight_per_finite_target: float


@dataclass(frozen=True)
class SharedLossReference:
    """Standard-library recomputation of the complete shared loss."""

    contract_name: str
    objective: float
    basin_count: int
    leads: tuple[int, ...]
    per_basin_objective: Mapping[str, float]
    cells: tuple[BasinLeadLossEvidence, ...]


def _finite_float(value: object, *, label: str) -> float:
    try:
        converted = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"{label} must be convertible to a finite float") from exc
    if not math.isfinite(converted):
        raise ValueError(f"{label} must be finite")
    return converted


def fit_training_population_variance(
    observations: Sequence[object],
    *,
    basin_id: str,
    training_start_index: int,
    validation_start_index: int,
    variance_floor: float = DEFAULT_VARIANCE_FLOOR,
) -> TrainingVarianceEvidence:
    """Fit one basin denominator using only its pre-validation training slice.

    Non-finite observations inside ``[training_start_index,
    validation_start_index)`` are omitted and counted.  At least two finite
    observations are required.  A zero or near-zero population variance is
    replaced by ``variance_floor`` and the replacement is recorded explicitly.
    Values outside the half-open training slice are never inspected.
    """

    basin = str(basin_id).strip()
    if not basin:
        raise ValueError("basin_id must be non-empty")
    start = int(training_start_index)
    stop = int(validation_start_index)
    if start < 0 or stop <= start or stop > len(observations):
        raise ValueError(
            "training statistics require 0 <= training_start_index "
            "< validation_start_index <= observation count"
        )
    floor = _finite_float(variance_floor, label="variance_floor")
    if floor <= 0.0:
        raise ValueError("variance_floor must be positive")

    # Welford's recurrence is a stable one-pass population-variance reference.
    count = 0
    missing = 0
    mean = 0.0
    second_central_moment_sum = 0.0
    for index in range(start, stop):
        try:
            value = float(observations[index])
        except (TypeError, ValueError, OverflowError) as exc:
            raise ValueError(
                f"training observation at index {index} is not numeric"
            ) from exc
        if not math.isfinite(value):
            missing += 1
            continue
        count += 1
        delta = value - mean
        mean += delta / count
        second_central_moment_sum += delta * (value - mean)

    if count < 2:
        raise ValueError(
            f"basin {basin} has fewer than two finite training observations"
        )
    raw_variance = max(second_central_moment_sum / count, 0.0)
    if not math.isfinite(raw_variance):
        raise FloatingPointError(f"basin {basin} training variance is non-finite")
    effective = max(raw_variance, floor)
    return TrainingVarianceEvidence(
        contract_name=CONTRACT_NAME,
        basin_id=basin,
        training_start_index=start,
        validation_start_index=stop,
        finite_observation_count=count,
        missing_observation_count=missing,
        finite_observation_mean=mean,
        raw_population_variance=raw_variance,
        variance_floor=floor,
        effective_training_variance=effective,
        variance_floor_applied=raw_variance < floor,
    )


def variance_evidence_sha256(
    evidence_by_basin: Mapping[str, TrainingVarianceEvidence],
) -> str:
    """Hash canonical, basin-sorted variance evidence for artifact manifests."""

    normalized = _validated_variance_evidence(evidence_by_basin)
    payload = [normalized[basin_id].to_dict() for basin_id in sorted(normalized)]
    encoded = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("utf-8")
    return sha256(encoded).hexdigest()


def _validated_variance_evidence(
    evidence_by_basin: Mapping[str, TrainingVarianceEvidence],
) -> dict[str, TrainingVarianceEvidence]:
    if not evidence_by_basin:
        raise ValueError("shared loss requires at least one basin")
    output: dict[str, TrainingVarianceEvidence] = {}
    for key, evidence in evidence_by_basin.items():
        if not isinstance(evidence, TrainingVarianceEvidence):
            raise TypeError("variance evidence values must be TrainingVarianceEvidence")
        basin_id = str(key)
        if basin_id != evidence.basin_id:
            raise ValueError("variance evidence key differs from its basin_id")
        if evidence.contract_name != CONTRACT_NAME:
            raise ValueError("variance evidence belongs to a different loss contract")
        if evidence.training_start_index < 0 or (
            evidence.validation_start_index <= evidence.training_start_index
        ):
            raise ValueError("variance evidence has an invalid training boundary")
        if evidence.finite_observation_count < 2:
            raise ValueError("variance evidence has fewer than two finite observations")
        if evidence.missing_observation_count < 0:
            raise ValueError("variance evidence has a negative missing count")
        expected_window_count = (
            evidence.validation_start_index - evidence.training_start_index
        )
        if (
            evidence.finite_observation_count + evidence.missing_observation_count
            != expected_window_count
        ):
            raise ValueError("variance evidence counts differ from its training window")
        _finite_float(
            evidence.finite_observation_mean,
            label=f"training observation mean for basin {basin_id}",
        )
        raw_variance = _finite_float(
            evidence.raw_population_variance,
            label=f"raw training variance for basin {basin_id}",
        )
        floor = _finite_float(
            evidence.variance_floor,
            label=f"training variance floor for basin {basin_id}",
        )
        if raw_variance < 0.0 or floor <= 0.0:
            raise ValueError("raw variance must be nonnegative and its floor positive")
        variance = _finite_float(
            evidence.effective_training_variance,
            label=f"effective training variance for basin {basin_id}",
        )
        if variance <= 0.0:
            raise ValueError("effective training variance must be positive")
        expected_variance = max(raw_variance, floor)
        expected_floor_applied = raw_variance < floor
        if variance != expected_variance or (
            evidence.variance_floor_applied != expected_floor_applied
        ):
            raise ValueError("variance evidence is internally inconsistent")
        output[basin_id] = evidence
    return output


def shared_basin_lead_equal_reference_loss(
    pairs_by_basin: Mapping[
        str,
        Mapping[int, Iterable[tuple[object, object]]],
    ],
    evidence_by_basin: Mapping[str, TrainingVarianceEvidence],
    *,
    leads: tuple[int, ...] = DAILY_FORECAST_LEADS,
) -> SharedLossReference:
    """Recompute the contract from ``(prediction, target)`` pairs.

    Rules are deliberately fail-closed:

    * basin sets must match exactly;
    * leads must be exactly 1, 2, and 3 days;
    * every issued prediction must be finite, even when its target is missing;
    * a non-finite target is omitted without imputation;
    * every basin/lead cell must retain at least one finite target.

    The physical squared-error coefficient for an event in cell ``(b, h)`` is
    ``1 / (number_of_basins * 3 * finite_count[b,h] * variance[b])``.
    """

    requested_leads = tuple(int(value) for value in leads)
    if requested_leads != DAILY_FORECAST_LEADS:
        raise ValueError("this contract requires exactly daily leads 1, 2, and 3")
    variances = _validated_variance_evidence(evidence_by_basin)
    if set(pairs_by_basin) != set(variances):
        raise ValueError("forecast-pair basin set differs from variance-evidence basin set")

    basin_count = len(variances)
    cells: list[BasinLeadLossEvidence] = []
    per_basin: dict[str, float] = {}
    for basin_id in sorted(variances):
        lead_pairs = pairs_by_basin[basin_id]
        if set(lead_pairs) != set(requested_leads):
            raise ValueError(
                f"basin {basin_id} must contain exactly leads 1, 2, and 3"
            )
        variance = variances[basin_id].effective_training_variance
        normalized_cell_values: list[float] = []
        for lead in requested_leads:
            squared_error_sum = 0.0
            finite_count = 0
            missing_count = 0
            for pair_index, pair in enumerate(lead_pairs[lead]):
                try:
                    prediction_raw, target_raw = pair
                except (TypeError, ValueError) as exc:
                    raise ValueError(
                        f"basin {basin_id} lead {lead} pair {pair_index} "
                        "must contain prediction and target"
                    ) from exc
                prediction = _finite_float(
                    prediction_raw,
                    label=(
                        f"basin {basin_id} lead {lead} prediction {pair_index}"
                    ),
                )
                try:
                    target = float(target_raw)
                except (TypeError, ValueError, OverflowError) as exc:
                    raise ValueError(
                        f"basin {basin_id} lead {lead} target {pair_index} "
                        "must be numeric or a non-finite missing marker"
                    ) from exc
                if not math.isfinite(target):
                    missing_count += 1
                    continue
                error = prediction - target
                squared_error = error * error
                if not math.isfinite(squared_error):
                    raise FloatingPointError(
                        f"basin {basin_id} lead {lead} squared error is non-finite"
                    )
                squared_error_sum += squared_error
                finite_count += 1
            if finite_count < 1:
                raise ValueError(
                    f"basin {basin_id} lead {lead} has no finite forecast target"
                )
            physical_mse = squared_error_sum / finite_count
            normalized_mse = physical_mse / variance
            if not math.isfinite(normalized_mse):
                raise FloatingPointError(
                    f"basin {basin_id} lead {lead} normalized loss is non-finite"
                )
            normalized_cell_values.append(normalized_mse)
            cells.append(
                BasinLeadLossEvidence(
                    basin_id=basin_id,
                    lead_days=lead,
                    finite_target_count=finite_count,
                    missing_target_count=missing_count,
                    physical_mean_squared_error=physical_mse,
                    normalized_mean_squared_error=normalized_mse,
                    physical_squared_error_weight_per_finite_target=(
                        1.0
                        / (
                            basin_count
                            * len(requested_leads)
                            * finite_count
                            * variance
                        )
                    ),
                )
            )
        per_basin[basin_id] = sum(normalized_cell_values) / len(
            normalized_cell_values
        )

    objective = sum(per_basin.values()) / basin_count
    if not math.isfinite(objective):
        raise FloatingPointError("shared basin-balanced objective is non-finite")
    return SharedLossReference(
        contract_name=CONTRACT_NAME,
        objective=objective,
        basin_count=basin_count,
        leads=requested_leads,
        per_basin_objective=per_basin,
        cells=tuple(cells),
    )


def contract_manifest() -> dict[str, object]:
    """Return JSON-safe frozen semantics for config snapshots and handoffs."""

    return {
        "contract_name": CONTRACT_NAME,
        "forecast_leads_days": list(DAILY_FORECAST_LEADS),
        "formula": (
            "mean_over_basins(mean_over_leads_1_2_3("
            "mean_over_finite_targets(squared_physical_flow_error) / "
            "effective_training_population_variance))"
        ),
        "training_statistics_window": (
            "half_open_[training_start_index,validation_start_index)"
        ),
        "training_variance_definition": (
            "population_variance_over_finite_training_observations"
        ),
        "minimum_finite_training_observations": 2,
        "variance_floor": DEFAULT_VARIANCE_FLOOR,
        "zero_or_near_zero_variance_policy": (
            "replace_with_variance_floor_and_record_variance_floor_applied"
        ),
        "missing_target_policy": (
            "omit_nonfinite_target_within_cell_without_imputation;"
            "require_at_least_one_finite_target_per_basin_and_lead"
        ),
        "nonfinite_prediction_policy": (
            "fail_even_when_the_corresponding_target_is_missing"
        ),
        "weighting_order": [
            "mean_finite_targets_within_each_basin_and_lead",
            "equal_mean_of_leads_1_2_3_within_each_basin",
            "equal_mean_of_basins",
        ],
        "compatibility": (
            "opt_in_reference_only; does_not_change_or_redefine_the_existing_"
            "single_basin_physical_mse_path"
        ),
    }
