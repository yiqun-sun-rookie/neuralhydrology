"""Frozen per-basin GR4J+PDD prior (FINAL_pt_v1) for continental DA.

Mirror of :mod:`global_hydrology.data.hbvlite_prior`, but for the GR4J+PDD school.
Loads the neuralhydrology CMA-ES-calibrated 8 params + 65-dim warmup-year-end eval
state from the benchmark summary CSV into frozen lookup tables indexed by basin_idx
(canonical 531-basin order). GR4J median eval NSE = 0.6533 (vs HBV-lite 0.6170).

CSV: ``camels_us_531_repro_v01/summary/gr4j_pdd_cma_FINAL_pt_v1_local_full.csv``
  - 8  ``p_*`` cols     -> PDD_GR4J params (PARAM_NAMES order)
  - 65 ``state_*`` cols -> warmup-year-end eval-init state (full numpy layout)
  - ``nse`` col         -> published eval NSE (FORM-gate cross-check)
"""
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Union

import torch

from ..models.differentiable_gr4j_pdd import PARAM_NAMES

NH_ROOT = Path("G:/github/pycharm/projects/neuralhydrology")
_CSV = (NH_ROOT / "results/10_global_conceptual_model_benchmark/"
        "camels_us_531_repro_v01/summary/gr4j_pdd_cma_FINAL_pt_v1_local_full.csv")
_BASIN_LIST = (NH_ROOT / "src/xaj_global_pilot/configs/"
               "conceptual_benchmark_camels_us_531_repro.txt")

# 65-dim numpy state layout (gr4j_core STATE_NAMES order)
STATE_NAMES = (["snow", "ice", "last_temp", "S", "R"]
               + [f"uh1_{i}" for i in range(20)] + [f"uh2_{i}" for i in range(40)])


@dataclass
class GR4JPrior:
    basin_ids: List[str]                # len B, zfill-8, canonical order
    param_table: torch.Tensor           # [B, 8] params, PARAM_NAMES order
    state_table: torch.Tensor           # [B, 65] eval-init state, STATE_NAMES order
    csv_nse: torch.Tensor               # [B] published eval NSE
    id2idx: Dict[str, int]

    @property
    def n_basins(self) -> int:
        return len(self.basin_ids)

    def params_dict(self, idx: int) -> Dict[str, float]:
        row = self.param_table[idx]
        return {name: float(row[i]) for i, name in enumerate(PARAM_NAMES)}


def load_gr4j_prior(csv_path: Union[str, Path, None] = None,
                    basin_list_path: Union[str, Path, None] = None,
                    dtype: torch.dtype = torch.float64) -> GR4JPrior:
    import csv as _csv
    csv_path = Path(csv_path or _CSV)
    basin_list_path = Path(basin_list_path or _BASIN_LIST)

    ids = [ln.strip().zfill(8) for ln in basin_list_path.read_text().splitlines()
           if ln.strip()]
    by_id = {}
    with open(csv_path, newline="") as fh:
        for r in _csv.DictReader(fh):
            by_id[r["basin_id"].zfill(8)] = r
    missing = [b for b in ids if b not in by_id]
    if missing:
        raise KeyError(f"{len(missing)} list basins absent from CSV, e.g. {missing[:3]}")

    params = torch.empty(len(ids), len(PARAM_NAMES), dtype=dtype)
    state = torch.empty(len(ids), len(STATE_NAMES), dtype=dtype)
    nse = torch.empty(len(ids), dtype=dtype)
    for i, b in enumerate(ids):
        row = by_id[b]
        for j, name in enumerate(PARAM_NAMES):
            params[i, j] = float(row["p_" + name])
        for j, name in enumerate(STATE_NAMES):
            state[i, j] = float(row["state_" + name])
        nse[i] = float(row["nse"])
    return GR4JPrior(basin_ids=ids, param_table=params, state_table=state,
                     csv_nse=nse, id2idx={b: i for i, b in enumerate(ids)})


if __name__ == "__main__":
    prior = load_gr4j_prior()
    print(f"loaded {prior.n_basins} basins; params {tuple(prior.param_table.shape)}, "
          f"state {tuple(prior.state_table.shape)}; median csv_nse={prior.csv_nse.median():.4f}")
