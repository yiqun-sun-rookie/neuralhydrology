# Utility functions for global hydrology module
