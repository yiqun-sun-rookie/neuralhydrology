"""Narrow, audited bridge from HBV states to the original trainable UKF.

The external trainable Unscented Kalman Filter and its covariance layer are
imported directly from the ``filters`` repository.  This module does not copy,
subclass, monkey-patch, or replace either class.  It only makes HBV state and
observation magnitudes dimensionless before the original float32 filter sees
them, then maps the result back to physical units.
"""

from __future__ import annotations

import hashlib
import inspect
from pathlib import Path
import sys
from typing import Any

import torch


DEFAULT_FILTERS_ROOT = Path("G:/github/pycharm/projects/filters")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _load_original_components(filters_root: Path = DEFAULT_FILTERS_ROOT):
    root = filters_root.resolve()
    if not root.is_dir():
        raise FileNotFoundError(f"original filters repository is unavailable: {root}")
    root_text = str(root)
    if root_text not in sys.path:
        sys.path.insert(0, root_text)
    from filters.adapt_trainable_kf.adaptive_cov import LearnableCov
    from filters.adapt_trainable_kf.adaptive_ukf import TrainableUKF
    from filters.filter.batch.my_version.batch_unscentedkalmanfilter_gpu import (
        BatchUnscentedKalmanFilterGPU,
    )
    from filters.filter.non_batch.kalman import MerweScaledSigmaPoints

    return (
        BatchUnscentedKalmanFilterGPU,
        TrainableUKF,
        LearnableCov,
        MerweScaledSigmaPoints,
    )


def original_trainable_ukf_provenance(
    filters_root: Path = DEFAULT_FILTERS_ROOT,
) -> dict[str, dict[str, str]]:
    """Return resolved source files and hashes for every executed UKF component."""

    BatchFilter, TrainableFilter, LearnableCovariance, SigmaPoints = (
        _load_original_components(filters_root)
    )
    from filters.da_coupler import walrus_batch

    components = {
        "trainable_filter": TrainableFilter,
        "trainable_covariance": LearnableCovariance,
        "batch_unscented_filter": BatchFilter,
        "sigma_points": SigmaPoints,
        "generic_process_observation_bridge": walrus_batch,
    }
    output: dict[str, dict[str, str]] = {}
    for name, component in components.items():
        source = inspect.getsourcefile(component)
        if source is None:
            raise RuntimeError(f"cannot resolve source file for {name}")
        path = Path(source).resolve()
        output[name] = {
            "path": str(path),
            "sha256": _sha256(path),
            "qualified_name": (
                component.__name__
                if inspect.ismodule(component)
                else f"{component.__module__}.{component.__qualname__}"
            ),
        }
    return output


def _positive_scale(
    value: torch.Tensor | float | list[float],
    *,
    dimension: int,
    device: torch.device,
    dtype: torch.dtype,
    name: str,
) -> torch.Tensor:
    scale = torch.as_tensor(value, device=device, dtype=dtype)
    if scale.ndim == 0:
        scale = scale.repeat(dimension)
    if scale.numel() != dimension:
        raise ValueError(f"{name} must contain {dimension} values")
    scale = scale.reshape(1, dimension)
    if not bool(torch.isfinite(scale).all()) or not bool((scale > 0).all()):
        raise ValueError(f"{name} must be finite and strictly positive")
    return scale.detach().clone()


class DimensionlessHBVSystemAdapter:
    """Apply an exact diagonal unit transformation around an HBV system."""

    def __init__(
        self,
        system: Any,
        *,
        state_scale: torch.Tensor | list[float],
        observation_scale: torch.Tensor | list[float] | float,
    ) -> None:
        if getattr(system, "dtype", None) != torch.float32:
            raise ValueError("the original trainable UKF requires a float32 HBV system")
        self.system = system
        self.device = torch.device(system.device)
        self.dtype = system.dtype
        self.m = int(system.m)
        self.n = int(system.n)
        self.state_scale = _positive_scale(
            state_scale,
            dimension=self.m,
            device=self.device,
            dtype=self.dtype,
            name="state_scale",
        )
        self.observation_scale = _positive_scale(
            observation_scale,
            dimension=self.n,
            device=self.device,
            dtype=self.dtype,
            name="observation_scale",
        )

    def to_dimensionless_state(self, state: torch.Tensor) -> torch.Tensor:
        return state.to(device=self.device, dtype=self.dtype) / self.state_scale

    def to_physical_state(self, state: torch.Tensor) -> torch.Tensor:
        return state.to(device=self.device, dtype=self.dtype) * self.state_scale

    def to_dimensionless_observation(self, observation: torch.Tensor) -> torch.Tensor:
        return (
            observation.to(device=self.device, dtype=self.dtype)
            / self.observation_scale
        )

    def to_physical_observation(self, observation: torch.Tensor) -> torch.Tensor:
        return (
            observation.to(device=self.device, dtype=self.dtype)
            * self.observation_scale
        )

    def f(
        self, state: torch.Tensor, controls: torch.Tensor | None = None
    ) -> torch.Tensor:
        physical_state = self.to_physical_state(state)
        physical_next = self.system.f(physical_state, controls)
        return self.to_dimensionless_state(physical_next)

    def h(self, state: torch.Tensor) -> torch.Tensor:
        physical_observation = self.system.h(self.to_physical_state(state))
        return self.to_dimensionless_observation(physical_observation)


def _diagonal(
    value: torch.Tensor | list[float] | float,
    dimension: int,
    *,
    device: torch.device,
) -> torch.Tensor:
    vector = torch.as_tensor(value, dtype=torch.float32, device=device)
    if vector.ndim == 0:
        vector = vector.repeat(dimension)
    if vector.numel() != dimension:
        raise ValueError(f"covariance diagonal must contain {dimension} values")
    if not bool(torch.isfinite(vector).all()) or not bool((vector > 0).all()):
        raise ValueError("covariance diagonal must be finite and strictly positive")
    return torch.diag(vector.reshape(dimension))


def build_original_trainable_ukf_for_hbv(
    system: Any,
    *,
    state_scale: torch.Tensor | list[float],
    observation_scale: torch.Tensor | list[float] | float,
    batch_size: int = 1,
    process_noise_initial_diagonal: torch.Tensor | list[float] | float = 1e-3,
    observation_noise_initial_diagonal: torch.Tensor | list[float] | float = 1e-3,
    initial_covariance_diagonal: torch.Tensor | list[float] | float = 1e-3,
    learn_process_noise: bool = True,
    learn_observation_noise: bool = True,
    alpha: float = 1.0,
    beta: float = 2.0,
    kappa: float = 0.0,
    filters_root: Path = DEFAULT_FILTERS_ROOT,
):
    """Build the exact external TrainableUKF around a dimensionless HBV adapter."""

    if batch_size < 1:
        raise ValueError("batch_size must be positive")
    if alpha <= 0:
        raise ValueError("alpha must be positive")
    BatchFilter, TrainableFilter, _, SigmaPoints = _load_original_components(
        filters_root
    )
    adapter = DimensionlessHBVSystemAdapter(
        system,
        state_scale=state_scale,
        observation_scale=observation_scale,
    )
    device = adapter.device
    points = SigmaPoints(
        n=adapter.m, alpha=float(alpha), beta=float(beta), kappa=float(kappa)
    )
    # The original batch filter reads this scaling factor directly, while the
    # imported sigma-point class exposes only its weights.
    points.c = points.alpha**2 * (points.n + points.kappa)

    def identity_transition(sigmas, _time_step):
        return sigmas

    def first_observation(sigmas):
        return sigmas[..., : adapter.n]

    base_filter = BatchFilter(
        dim_x=adapter.m,
        dim_z=adapter.n,
        dt=1.0,
        hx=first_observation,
        fx=identity_transition,
        points=points,
        batch_size=batch_size,
        device=device,
    )
    base_filter.Q = _diagonal(
        process_noise_initial_diagonal, adapter.m, device=device
    )
    base_filter.R = _diagonal(
        observation_noise_initial_diagonal, adapter.n, device=device
    )
    model = TrainableFilter(
        base_filter=base_filter,
        system_model=adapter,
        learn_q=learn_process_noise,
        learn_r=learn_observation_noise,
        cov_type="diag",
        adapt_online=False,
        q_init=process_noise_initial_diagonal,
        r_init=observation_noise_initial_diagonal,
        p0_scale=initial_covariance_diagonal,
        device=device,
    )
    # The original constructor omits this field although init_sequence reads it.
    # Setting it is an integration repair; the original implementation remains untouched.
    model.batch_size = int(batch_size)
    return model, adapter
