"""
Soft Actor-Critic (SAC) reinforcement learning agent for hydrological data
assimilation.

This module provides an RL-based alternative to KalmanNet / UKF for state
correction in differentiable hydrological models (e.g. DifferentiableM4).
The agent observes innovation signals, current model states, and forcing data,
then outputs additive corrections to the four M4 reservoir states
(S_snow, S_soil, S_fast, S_slow).

Key components
--------------
- **RLDAConfig**           -- dataclass holding all hyper-parameters.
- **RecurrentActor**       -- LSTM-based stochastic policy with tanh-squashed
                              Gaussian actions.
- **RecurrentCritic**      -- Twin recurrent Q-networks.
- **SequenceReplayBuffer** -- Episode-level replay buffer that samples
                              fixed-length sub-sequences.
- **SACAgent**             -- Orchestrator: owns actor, critic, target critic,
                              optimisers, entropy temperature, and replay
                              buffer.
"""

from __future__ import annotations

import random
from collections import deque
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import Adam


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class RLDAConfig:
    """Hyper-parameters for the SAC data-assimilation agent."""

    # Observation / action dimensions
    agent_obs_dim: int = 18          # obs/innovation features + state + forcing
    action_dim: int = 4              # M4 state correction (S_snow, S_soil, S_fast, S_slow)
    action_scale: list = field(default_factory=lambda: [500, 200, 500, 500])  # mm per state

    # Actor architecture
    actor_hidden: int = 128
    actor_lstm_hidden: int = 64
    actor_lstm_layers: int = 1

    # Critic architecture
    critic_hidden: int = 128
    critic_lstm_hidden: int = 64

    # SAC hyper-parameters
    gamma: float = 0.99
    tau: float = 0.005
    alpha_init: float = 0.2
    auto_alpha: bool = True
    target_entropy: float = -4.0

    # Learning rates
    lr_actor: float = 3e-4
    lr_critic: float = 3e-4
    lr_alpha: float = 3e-4

    # Replay buffer
    buffer_size: int = 10000         # episodes
    batch_size_rl: int = 32
    seq_chunk_len: int = 64

    # Training helpers
    warmup_steps: int = 5000
    hydro_warmup: int = 90
    max_grad_norm: float = 1.0


# ---------------------------------------------------------------------------
# Actor
# ---------------------------------------------------------------------------

class RecurrentActor(nn.Module):
    """LSTM-based stochastic policy with tanh-squashed Gaussian output.

    Architecture
    ------------
    obs [B, obs_dim]
        -> Linear(obs_dim, actor_hidden) -> ReLU
        -> LSTM(actor_hidden, actor_lstm_hidden)
        -> mu_head  Linear(actor_lstm_hidden, action_dim)
           log_std_head Linear(actor_lstm_hidden, action_dim)
        -> tanh squash + scale
    """

    def __init__(self, config: RLDAConfig) -> None:
        super().__init__()
        self.config = config

        self.fc_in = nn.Linear(config.agent_obs_dim, config.actor_hidden)
        self.lstm = nn.LSTM(
            input_size=config.actor_hidden,
            hidden_size=config.actor_lstm_hidden,
            num_layers=config.actor_lstm_layers,
            batch_first=True,
        )
        self.mu_head = nn.Linear(config.actor_lstm_hidden, config.action_dim)
        self.log_std_head = nn.Linear(config.actor_lstm_hidden, config.action_dim)

        # action_scale is a constant -- register as buffer (not a parameter)
        self.register_buffer(
            "action_scale",
            torch.tensor(
                config.action_scale if config.action_scale is not None else [500, 200, 500, 500],
                dtype=torch.float32,
            ),
        )

    # --------------------------------------------------------------------- #

    def forward(
        self,
        obs: torch.Tensor,
        h_state: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
        """Forward pass with stochastic sampling.

        Parameters
        ----------
        obs : Tensor  [B, obs_dim] or [B, T, obs_dim]
        h_state : optional LSTM hidden state tuple (h, c)

        Returns
        -------
        action     : Tensor [B, T, action_dim]  (scaled)
        log_prob   : Tensor [B, T]
        mu         : Tensor [B, T, action_dim]   (pre-tanh mean)
        h_state_new: tuple  (h, c)
        """
        squeezed = False
        if obs.dim() == 2:
            obs = obs.unsqueeze(1)  # [B, 1, obs_dim]
            squeezed = True

        x = F.relu(self.fc_in(obs))                         # [B, T, actor_hidden]
        lstm_out, h_state_new = self.lstm(x, h_state)       # [B, T, lstm_hidden]

        mu = self.mu_head(lstm_out)                          # [B, T, action_dim]
        log_std = self.log_std_head(lstm_out)                # [B, T, action_dim]
        log_std = log_std.clamp(-20.0, 2.0)
        std = log_std.exp()

        # Reparameterised sample
        dist = torch.distributions.Normal(mu, std)
        u = dist.rsample()                                   # pre-tanh sample

        # Tanh squashing
        action_normalized = torch.tanh(u)                    # in (-1, 1)
        action = action_normalized * self.action_scale       # scaled

        # Log-prob with tanh correction
        log_prob = dist.log_prob(u)                          # [B, T, action_dim]
        log_prob -= torch.log(1.0 - action_normalized.pow(2) + 1e-6)
        log_prob = log_prob.sum(dim=-1)                      # [B, T]

        if squeezed:
            action = action.squeeze(1)
            log_prob = log_prob.squeeze(1)
            mu = mu.squeeze(1)

        return action, log_prob, mu, h_state_new

    # --------------------------------------------------------------------- #

    def get_deterministic_action(
        self,
        obs: torch.Tensor,
        h_state: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    ) -> Tuple[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
        """Return the mean action (no sampling).

        Parameters
        ----------
        obs : Tensor  [B, obs_dim] or [B, T, obs_dim]
        h_state : optional LSTM hidden state

        Returns
        -------
        action      : Tensor  (same leading dims as obs)
        h_state_new : tuple (h, c)
        """
        squeezed = False
        if obs.dim() == 2:
            obs = obs.unsqueeze(1)
            squeezed = True

        x = F.relu(self.fc_in(obs))
        lstm_out, h_state_new = self.lstm(x, h_state)

        mu = self.mu_head(lstm_out)
        action = torch.tanh(mu) * self.action_scale

        if squeezed:
            action = action.squeeze(1)

        return action, h_state_new


# ---------------------------------------------------------------------------
# Critic
# ---------------------------------------------------------------------------

class RecurrentCritic(nn.Module):
    """Twin recurrent Q-networks.

    Each Q-network:
        [obs, action] concat
        -> Linear(obs_dim + action_dim, critic_hidden) -> ReLU
        -> LSTM(critic_hidden, critic_lstm_hidden)
        -> Linear(critic_lstm_hidden, 1)
    """

    def __init__(self, config: RLDAConfig) -> None:
        super().__init__()
        in_dim = config.agent_obs_dim + config.action_dim

        # Q1
        self.q1_fc = nn.Linear(in_dim, config.critic_hidden)
        self.q1_lstm = nn.LSTM(
            input_size=config.critic_hidden,
            hidden_size=config.critic_lstm_hidden,
            num_layers=1,
            batch_first=True,
        )
        self.q1_out = nn.Linear(config.critic_lstm_hidden, 1)

        # Q2
        self.q2_fc = nn.Linear(in_dim, config.critic_hidden)
        self.q2_lstm = nn.LSTM(
            input_size=config.critic_hidden,
            hidden_size=config.critic_lstm_hidden,
            num_layers=1,
            batch_first=True,
        )
        self.q2_out = nn.Linear(config.critic_lstm_hidden, 1)

    # --------------------------------------------------------------------- #

    def forward(
        self,
        obs: torch.Tensor,
        action: torch.Tensor,
        h_state: Optional[Tuple[
            Tuple[torch.Tensor, torch.Tensor],
            Tuple[torch.Tensor, torch.Tensor],
        ]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, Tuple]:
        """Compute twin Q-values.

        Parameters
        ----------
        obs    : Tensor [B, T, obs_dim] or [B, obs_dim]
        action : Tensor [B, T, action_dim] or [B, action_dim]
        h_state: optional ((h1,c1), (h2,c2))

        Returns
        -------
        q1          : Tensor [B, T, 1]
        q2          : Tensor [B, T, 1]
        h_state_new : ((h1,c1), (h2,c2))
        """
        squeezed = False
        if obs.dim() == 2:
            obs = obs.unsqueeze(1)
            action = action.unsqueeze(1)
            squeezed = True

        x = torch.cat([obs, action], dim=-1)  # [B, T, obs_dim+action_dim]

        h1, h2 = (None, None) if h_state is None else h_state

        # Q1
        q1 = F.relu(self.q1_fc(x))
        q1, h1_new = self.q1_lstm(q1, h1)
        q1 = self.q1_out(q1)  # [B, T, 1]

        # Q2
        q2 = F.relu(self.q2_fc(x))
        q2, h2_new = self.q2_lstm(q2, h2)
        q2 = self.q2_out(q2)  # [B, T, 1]

        if squeezed:
            q1 = q1.squeeze(1)
            q2 = q2.squeeze(1)

        return q1, q2, (h1_new, h2_new)


# ---------------------------------------------------------------------------
# Replay Buffer
# ---------------------------------------------------------------------------

class SequenceReplayBuffer:
    """Episode-level replay buffer that samples fixed-length sub-sequences.

    Each episode is stored as a list of transition dicts, one per timestep.
    At sample time, random sub-sequences of length ``seq_chunk_len`` are drawn.
    Episodes shorter than the chunk length are zero-padded.
    """

    def __init__(self, capacity: int, seq_chunk_len: int) -> None:
        self.capacity = capacity
        self.seq_chunk_len = seq_chunk_len
        self.episodes: deque[List[Dict[str, torch.Tensor]]] = deque(maxlen=capacity)

    def add_episode(self, episode: List[Dict[str, torch.Tensor]]) -> None:
        """Store one complete episode.

        Parameters
        ----------
        episode : list of dicts
            Each dict has keys ``obs``, ``action``, ``reward``, ``next_obs``,
            ``done`` -- all 1-D tensors (no batch dim).
        """
        self.episodes.append(episode)

    def sample(self, batch_size: int) -> Dict[str, torch.Tensor]:
        """Sample ``batch_size`` sub-sequences of length ``seq_chunk_len``.

        Returns
        -------
        dict with keys
            obs      : [B, T, obs_dim]
            action   : [B, T, action_dim]
            reward   : [B, T, 1]
            next_obs : [B, T, obs_dim]
            done     : [B, T, 1]
        """
        T = self.seq_chunk_len
        obs_list, act_list, rew_list, nobs_list, done_list = [], [], [], [], []

        for _ in range(batch_size):
            ep = random.choice(self.episodes)
            ep_len = len(ep)

            if ep_len >= T:
                start = random.randint(0, ep_len - T)
                chunk = ep[start : start + T]
            else:
                # Episode shorter than chunk -- use entire episode then pad
                chunk = list(ep)

            # Stack the chunk into tensors
            obs_seq = torch.stack([s["obs"] for s in chunk])         # [L, obs_dim]
            act_seq = torch.stack([s["action"] for s in chunk])      # [L, act_dim]
            rew_seq = torch.stack([s["reward"] for s in chunk])      # [L] or [L,1]
            nobs_seq = torch.stack([s["next_obs"] for s in chunk])   # [L, obs_dim]
            done_seq = torch.stack([s["done"] for s in chunk])       # [L] or [L,1]

            # Ensure reward / done are [L, 1]
            if rew_seq.dim() == 1:
                rew_seq = rew_seq.unsqueeze(-1)
            if done_seq.dim() == 1:
                done_seq = done_seq.unsqueeze(-1)

            # Zero-pad if necessary
            L = obs_seq.size(0)
            if L < T:
                pad_len = T - L
                obs_seq = F.pad(obs_seq, (0, 0, 0, pad_len))
                act_seq = F.pad(act_seq, (0, 0, 0, pad_len))
                rew_seq = F.pad(rew_seq, (0, 0, 0, pad_len))
                nobs_seq = F.pad(nobs_seq, (0, 0, 0, pad_len))
                done_seq = F.pad(done_seq, (0, 0, 0, pad_len), value=1.0)

            obs_list.append(obs_seq)
            act_list.append(act_seq)
            rew_list.append(rew_seq)
            nobs_list.append(nobs_seq)
            done_list.append(done_seq)

        return {
            "obs": torch.stack(obs_list),          # [B, T, obs_dim]
            "action": torch.stack(act_list),       # [B, T, act_dim]
            "reward": torch.stack(rew_list),       # [B, T, 1]
            "next_obs": torch.stack(nobs_list),    # [B, T, obs_dim]
            "done": torch.stack(done_list),        # [B, T, 1]
        }

    def __len__(self) -> int:
        return len(self.episodes)


# ---------------------------------------------------------------------------
# SAC Agent
# ---------------------------------------------------------------------------

class SACAgent:
    """Soft Actor-Critic agent with recurrent actor and critic.

    Owns the actor, twin critic, target critic, three optimisers (actor,
    critic, entropy temperature), and the sequence replay buffer.
    """

    def __init__(self, config: RLDAConfig, device: torch.device) -> None:
        self.config = config
        self.device = device

        # Networks
        self.actor = RecurrentActor(config).to(device)
        self.critic = RecurrentCritic(config).to(device)
        self.critic_target = RecurrentCritic(config).to(device)
        # Hard copy critic -> critic_target
        self.critic_target.load_state_dict(self.critic.state_dict())

        # Optimisers
        self.actor_optimizer = Adam(self.actor.parameters(), lr=config.lr_actor)
        self.critic_optimizer = Adam(self.critic.parameters(), lr=config.lr_critic)

        # Entropy temperature (auto-tuned or fixed)
        if config.auto_alpha:
            self.log_alpha = torch.tensor(
                np.log(config.alpha_init), device=device, requires_grad=True,
            )
            self.alpha_optimizer = Adam([self.log_alpha], lr=config.lr_alpha)
            self.target_entropy = config.target_entropy
        else:
            self.log_alpha = torch.tensor(
                np.log(config.alpha_init), device=device,
            )

        # Replay buffer
        self.buffer = SequenceReplayBuffer(config.buffer_size, config.seq_chunk_len)
        self.total_steps: int = 0

    # -- properties -------------------------------------------------------- #

    @property
    def alpha(self) -> torch.Tensor:
        return self.log_alpha.exp()

    # -- action selection -------------------------------------------------- #

    def act(
        self,
        obs: torch.Tensor,
        h_state: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
        deterministic: bool = False,
    ) -> Tuple[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
        """Select an action for environment interaction (no grad).

        Parameters
        ----------
        obs : Tensor [B, obs_dim]
        h_state : optional LSTM hidden state
        deterministic : if True use mean action

        Returns
        -------
        action      : Tensor [B, action_dim]
        h_state_new : tuple (h, c)
        """
        with torch.no_grad():
            if deterministic:
                action, h_new = self.actor.get_deterministic_action(obs, h_state)
            else:
                action, _, _, h_new = self.actor(obs, h_state)
        return action, h_new

    # -- SAC update -------------------------------------------------------- #

    def update(self, batch: Dict[str, torch.Tensor]) -> Dict[str, float]:
        """One SAC update step on a batch of sub-sequences.

        Parameters
        ----------
        batch : dict
            obs [B, T, obs_dim], action [B, T, action_dim],
            reward [B, T, 1], next_obs [B, T, obs_dim], done [B, T, 1]

        Returns
        -------
        dict with scalar losses for logging
        """
        obs = batch["obs"]
        action = batch["action"]
        reward = batch["reward"]
        next_obs = batch["next_obs"]
        done = batch["done"]

        # ---- Critic update ------------------------------------------------
        with torch.no_grad():
            next_action, next_log_prob, _, _ = self.actor(next_obs)
            q1_target, q2_target, _ = self.critic_target(next_obs, next_action)
            q_target = (
                torch.min(q1_target, q2_target)
                - self.alpha * next_log_prob.unsqueeze(-1)
            )
            target_q = reward + self.config.gamma * (1.0 - done) * q_target

        q1, q2, _ = self.critic(obs, action)
        critic_loss = F.mse_loss(q1, target_q) + F.mse_loss(q2, target_q)

        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        torch.nn.utils.clip_grad_norm_(
            self.critic.parameters(), self.config.max_grad_norm,
        )
        self.critic_optimizer.step()

        # ---- Actor update -------------------------------------------------
        new_action, log_prob, _, _ = self.actor(obs)
        q1_new, q2_new, _ = self.critic(obs, new_action)
        q_new = torch.min(q1_new, q2_new)
        actor_loss = (self.alpha.detach() * log_prob.unsqueeze(-1) - q_new).mean()

        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        torch.nn.utils.clip_grad_norm_(
            self.actor.parameters(), self.config.max_grad_norm,
        )
        self.actor_optimizer.step()

        # ---- Alpha (temperature) update -----------------------------------
        alpha_loss_val = 0.0
        if self.config.auto_alpha:
            alpha_loss = -(
                self.log_alpha * (log_prob.detach() + self.target_entropy)
            ).mean()
            self.alpha_optimizer.zero_grad()
            alpha_loss.backward()
            self.alpha_optimizer.step()
            alpha_loss_val = alpha_loss.item()

        # ---- Soft target update -------------------------------------------
        with torch.no_grad():
            for p, p_targ in zip(
                self.critic.parameters(), self.critic_target.parameters(),
            ):
                p_targ.data.mul_(1.0 - self.config.tau)
                p_targ.data.add_(self.config.tau * p.data)

        return {
            "critic_loss": critic_loss.item(),
            "actor_loss": actor_loss.item(),
            "alpha_loss": alpha_loss_val,
            "alpha": self.alpha.item(),
        }

    # -- persistence ------------------------------------------------------- #

    def save(self, path, epoch: int = 0) -> None:
        """Save full agent state to *path*."""
        ckpt = {
            "actor": self.actor.state_dict(),
            "critic": self.critic.state_dict(),
            "critic_target": self.critic_target.state_dict(),
            "actor_optimizer": self.actor_optimizer.state_dict(),
            "critic_optimizer": self.critic_optimizer.state_dict(),
            "log_alpha": self.log_alpha,
            "total_steps": self.total_steps,
            "epoch": epoch,
            "config": self.config,
        }
        if self.config.auto_alpha:
            ckpt["alpha_optimizer"] = self.alpha_optimizer.state_dict()
        torch.save(ckpt, path)

    def load(self, path, map_location=None) -> None:
        """Restore agent state from a checkpoint at *path*."""
        ckpt = torch.load(path, map_location=map_location, weights_only=False)
        self.actor.load_state_dict(ckpt["actor"])
        self.critic.load_state_dict(ckpt["critic"])
        self.critic_target.load_state_dict(ckpt["critic_target"])
        self.actor_optimizer.load_state_dict(ckpt["actor_optimizer"])
        self.critic_optimizer.load_state_dict(ckpt["critic_optimizer"])
        self.log_alpha = ckpt["log_alpha"]
        if self.config.auto_alpha:
            self.alpha_optimizer = Adam([self.log_alpha], lr=self.config.lr_alpha)
            if "alpha_optimizer" in ckpt:
                self.alpha_optimizer.load_state_dict(ckpt["alpha_optimizer"])
        self.total_steps = ckpt.get("total_steps", 0)
