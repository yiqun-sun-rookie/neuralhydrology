"""Differentiable (torch) GR4J + PDD-noice — UKF process model for continental DA.

Mirrors the HBV-lite DA stack (``DifferentiableHBVLite`` / ``HBVLiteSystemModel`` /
``RoutedHBVLiteUKFAdapter``) but with GR4J as the physical core. The numpy ground
truth is ``neuralhydrology/src/xaj_global_pilot/gr4j_core.py`` (``_gr4j_step`` /
``_snow_noice_step`` / ``simulate_pdd_gr4j``); this file ports the GR4J step to a
batched torch tensor op so the UKF can propagate sigma points through it.

DA state design (the key difference from the 65-dim numpy state):
  - **Snow is precomputed** (deterministic). With ``Q_snow = 0`` the snow channel has
    zero sigma spread, so pulling it OUT of the UKF and feeding the precomputed
    liquid input is *mathematically identical* to keeping a frozen snow state — and
    much cheaper. ``snow_liquid_input`` produces ``liquid[t]`` via the numpy
    reference ``_snow_noice_step`` (bit-faithful to the calibration front-end).
  - **Active-trimmed** UH queues: only the first ``nuh1 = ceil(x4)`` / ``nuh2 =
    ceil(2 x4)`` ordinates are non-zero, so the queue tail (always 0) is dropped.
  - **Augmented discharge** channel: ``_gr4j_step`` computes ``q`` mid-step from the
    *pre-shift* queue heads + pre-extraction R, so ``h(post-step state)`` cannot
    recover it (same timing issue HBV solved with a routed buffer). We append a
    readout channel ``q`` that ``f`` writes and ``h`` selects — a standard augmented
    UKF emission whose cross-covariance back-propagates the innovation onto S/R/UH.

  state = [S, R, UH1[0:nuh1], UH2[0:nuh2], q]   dim_x = 2 + nuh1 + nuh2 + 1
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import sys
from typing import Optional

import numpy as np
import torch

# numpy reference (ground truth for the snow front-end + UH ordinates + validation)
_NH_SRC = Path("G:/github/pycharm/projects/neuralhydrology/src")
if str(_NH_SRC) not in sys.path:
    sys.path.insert(0, str(_NH_SRC))
from xaj_global_pilot.gr4j_core import (  # noqa: E402
    _snow_noice_step, uh1_ordinates, uh2_ordinates, simulate_pdd_gr4j,
    PDD_GR4J_PARAM_NAMES, NUH1_MAX, NUH2_MAX,
    _IDX_SNOW, _IDX_TEMP, _IDX_S, _IDX_R, _IDX_UH1, _IDX_UH2,
)

PARAM_NAMES = list(PDD_GR4J_PARAM_NAMES)  # 8: 4 PDD snow + x1..x4
SNOW_PARAM_NAMES = PARAM_NAMES[:4]
GR4J_PARAM_NAMES = PARAM_NAMES[4:]


def snow_liquid_input(snow0: float, prec: np.ndarray, temp: np.ndarray,
                      params: dict) -> np.ndarray:
    """Deterministic PDD-noice front-end -> liquid water input ``P[t]`` (mm/day).

    Uses the numpy reference ``_snow_noice_step`` so the snow physics are bit-identical
    to the calibration. Returns ``liquid`` of shape ``(T,)``; the final snow state is
    not needed (frozen in DA).
    """
    fsnow = params["pdd_factor_snow"]; rfsnow = params["refreeze_snow"]
    t_snow = params["temp_snow"]; t_rain = params["temp_rain"]
    snow = float(snow0)
    liquid = np.empty(len(prec), dtype=np.float64)
    for t in range(len(prec)):
        snow, liq = _snow_noice_step(snow, float(temp[t]), float(prec[t]),
                                     fsnow, rfsnow, t_snow, t_rain)
        liquid[t] = liq
    return liquid


def uh_ordinates_active(x4: float, dtype=torch.float64):
    """Return (uh1[nuh1], uh2[nuh2], nuh1, nuh2) torch tensors (active head only)."""
    nuh1 = max(1, int(np.ceil(x4)))
    nuh2 = max(1, int(np.ceil(2.0 * x4)))
    uh1 = torch.tensor(uh1_ordinates(x4)[:nuh1].copy(), dtype=dtype)
    uh2 = torch.tensor(uh2_ordinates(x4)[:nuh2].copy(), dtype=dtype)
    return uh1, uh2, nuh1, nuh2


class GR4JPDDSystemModel:
    """Per-basin GR4J core as a UKF process model: ``f(state, liquid, pet)`` / ``h``.

    ``params`` is a dict of the 8 PDD+GR4J params (scalars). The snow front-end is NOT
    inside ``f`` — feed ``liquid`` (precomputed via :func:`snow_liquid_input`). State
    layout = ``[S, R, UH1[0:nuh1], UH2[0:nuh2], q]``.
    """

    def __init__(self, params: dict, dtype: torch.dtype = torch.float64,
                 device: Optional[torch.device] = None):
        self.dtype = dtype
        self.device = device or torch.device("cpu")
        self.x1 = float(params["x1"]); self.x2 = float(params["x2"])
        self.x3 = float(params["x3"]); self.x4 = float(params["x4"])
        uh1, uh2, nuh1, nuh2 = uh_ordinates_active(self.x4, dtype=dtype)
        self.uh1 = uh1.to(self.device); self.uh2 = uh2.to(self.device)
        self.nuh1 = nuh1; self.nuh2 = nuh2
        self._s0 = 2                      # UH1 starts at channel 2
        self._s1 = 2 + nuh1               # UH2 starts here
        self._sq = 2 + nuh1 + nuh2        # q channel (last)
        self.dim_x = self._sq + 1         # 2 + nuh1 + nuh2 + 1
        self.m = self.dim_x               # alias (smoke parity)

    def f(self, state: torch.Tensor, liquid, pet) -> torch.Tensor:
        """One GR4J step over a batch of states ``[B, dim_x]`` -> ``[B, dim_x]``.

        ``liquid``/``pet`` are scalars (deterministic across the sigma batch, since the
        snow front-end is precomputed). The discharge is written into the last channel.
        S,R are clamped >=0 on ENTRY (per-sigma NaN guard for ``(R/x3)**3.5``; with
        det-mean this only bounds the spread, not the forecast mean).
        """
        x1, x2, x3 = self.x1, self.x2, self.x3
        S = state[:, 0].clamp(min=0.0)
        R = state[:, 1].clamp(min=0.0)
        uh1q = state[:, self._s0:self._s1]              # [B,nuh1]
        uh2q = state[:, self._s1:self._sq]              # [B,nuh2]
        P = float(liquid); E = float(pet)

        # 1. production store (scalar branch: P,E identical across the sigma batch)
        if P >= E:
            Pn = P - E
            sr = S / x1
            tws = np.tanh(Pn / x1)                       # scalar
            Ps = x1 * (1.0 - sr * sr) * tws / (1.0 + sr * tws)
            S = S + Ps
            pr_excess = Pn - Ps
        else:
            En = E - P
            sr = S / x1
            tws = np.tanh(En / x1)                       # scalar
            Es = S * (2.0 - sr) * tws / (1.0 + (1.0 - sr) * tws)
            S = S - Es
            pr_excess = torch.zeros_like(S)

        # 2. percolation
        perc = S * (1.0 - (1.0 + (S / (2.25 * x1)) ** 4) ** (-0.25))
        S = S - perc

        # 3. routing input + 90/10 split
        Pr = perc + pr_excess
        prr = 0.9 * Pr
        prd = 0.1 * Pr

        # 4. UH convolution (StUH[0] = today's output), then shift-left + zero tail
        uh1q = uh1q + self.uh1.unsqueeze(0) * prr.unsqueeze(1)
        q9 = uh1q[:, 0]
        uh1q = torch.cat([uh1q[:, 1:], torch.zeros_like(uh1q[:, :1])], dim=1)
        uh2q = uh2q + self.uh2.unsqueeze(0) * prd.unsqueeze(1)
        q1 = uh2q[:, 0]
        uh2q = torch.cat([uh2q[:, 1:], torch.zeros_like(uh2q[:, :1])], dim=1)

        # 5. groundwater exchange (R>=0 guaranteed by entry clamp)
        F = x2 * (R / x3) ** 3.5

        # 6. routing store
        R = (R + q9 + F).clamp(min=0.0)
        qr = R * (1.0 - (1.0 + (R / x3) ** 4) ** (-0.25))
        R = R - qr

        # 7. direct flow
        qd = (q1 + F).clamp(min=0.0)
        q = (qr + qd).clamp(min=0.0)

        out = torch.cat([S.unsqueeze(1), R.unsqueeze(1), uh1q, uh2q, q.unsqueeze(1)], dim=1)
        return out

    def h(self, state: torch.Tensor) -> torch.Tensor:
        """Augmented emission: read the discharge channel -> ``[B,1]``."""
        return state[:, self._sq:self._sq + 1].clamp(min=0.0)

    def initial_state(self, eval_state65: np.ndarray) -> torch.Tensor:
        """Build the active DA state ``[1, dim_x]`` from the 65-dim warmup-year-end state."""
        S = float(eval_state65[_IDX_S]); R = float(eval_state65[_IDX_R])
        uh1 = eval_state65[_IDX_UH1:_IDX_UH1 + self.nuh1]
        uh2 = eval_state65[_IDX_UH2:_IDX_UH2 + self.nuh2]
        vec = np.concatenate([[S, R], uh1, uh2, [0.0]]).astype(np.float64)
        return torch.tensor(vec, dtype=self.dtype, device=self.device).unsqueeze(0)

    def openloop(self, liquid: np.ndarray, pet: np.ndarray,
                 init_state: torch.Tensor) -> np.ndarray:
        """Deterministic open-loop discharge (FORM gate). ``[T]`` numpy array."""
        x = init_state.clone()
        q = np.empty(len(liquid))
        with torch.no_grad():
            for t in range(len(liquid)):
                x = self.f(x, liquid[t], pet[t])
                q[t] = float(x[0, self._sq])
        return q


class GR4JPDDUKFAdapter:
    """Expose a per-basin GR4J core as Batch-UKF ``fx``/``hx`` (single-basin, B=1).

    ``fx(sigmas[1,S,dim]) -> [1,S,dim]`` runs one GR4J step over the sigma batch;
    ``hx`` selects the augmented discharge channel. The snow front-end is precomputed,
    so the current-step liquid input + PET are injected via :meth:`set_forcing`.
    """

    def __init__(self, sm: GR4JPDDSystemModel, dtype: torch.dtype = torch.float32,
                 device: Optional[torch.device] = None):
        self.sm = sm
        self.dtype = dtype
        self.device = device or torch.device("cpu")
        self.dim_x = sm.dim_x
        self.m_phys = sm.dim_x          # the augmented q is part of the filtered state
        self.num_sigmas = 2 * self.dim_x + 1
        self._liquid: Optional[float] = None
        self._pet: Optional[float] = None

    def set_forcing(self, liquid, pet):
        self._liquid = float(liquid); self._pet = float(pet)

    def fx(self, sigmas: torch.Tensor, dt: float = 1.0) -> torch.Tensor:
        if self._liquid is None:
            raise ValueError("call set_forcing(liquid, pet) before fx().")
        B, S, m = sigmas.shape
        flat = sigmas.reshape(B * S, m).to(self.device, self.dtype)
        out = self.sm.f(flat, self._liquid, self._pet)
        return out.reshape(B, S, m)

    def hx(self, sigmas: torch.Tensor) -> torch.Tensor:
        B, S, m = sigmas.shape
        flat = sigmas.reshape(B * S, m).to(self.device, self.dtype)
        return self.sm.h(flat).reshape(B, S, 1)


def validate_openloop(prec, pet, temp, params: dict, eval_state65: np.ndarray,
                      dtype=torch.float64):
    """Cross-check the torch active OL against the numpy reference simulate_pdd_gr4j.

    Returns ``(max_abs_diff, q_torch, q_numpy)``. Both start from the SAME eval-init
    state; the torch path precomputes snow then runs the active GR4J core. A small
    max_abs_diff (<~1e-4) proves the port is faithful.
    """
    sm = GR4JPDDSystemModel(params, dtype=dtype)
    liquid = snow_liquid_input(eval_state65[_IDX_SNOW], prec, temp, params)
    x0 = sm.initial_state(eval_state65)
    q_torch = sm.openloop(liquid, np.asarray(pet, dtype=np.float64), x0)
    q_numpy, _ = simulate_pdd_gr4j(np.asarray(prec, dtype=np.float64),
                                   np.asarray(pet, dtype=np.float64),
                                   np.asarray(temp, dtype=np.float64),
                                   params, initial_state=eval_state65.astype(np.float64))
    return float(np.max(np.abs(q_torch - q_numpy))), q_torch, q_numpy
