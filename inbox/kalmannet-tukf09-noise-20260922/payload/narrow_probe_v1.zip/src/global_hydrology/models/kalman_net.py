"""
KalmanNet for Global Hydrology (M4 Model)
=========================================

This module implements the KalmanNet architecture adapted for the M4 hydrological model.
It learns to compute the Kalman Gain (K) dynamically based on the state and observation evolution.

Key differences from legacy version:
1. Optimized for m=4 (M4 states), n=1 (Discharge)
2. Simplified initialization (removed dependency on global 'args')
3. Integrated with M4SystemModel interfaces

Author: KalmanNet Global DA Project
Date: 2026-01-20
"""

import torch
import torch.nn as nn
from dataclasses import dataclass, field
from typing import List, Tuple, Optional

@dataclass
class KalmanNetConfig:
    # Model dimensions
    m: int = 4  # State dimension (Snow, Soil, Fast, Slow)
    n: int = 1  # Observation dimension (Q)

    # Network architecture
    in_mult_KNet: int = 40
    out_mult_KNet: int = 40
    d_hidden_Q: int = 40
    d_hidden_Sigma: int = 40
    d_hidden_S: int = 40
    num_layers_GRU_Q: int = 1
    num_layers_GRU_Sigma: int = 1
    num_layers_GRU_S: int = 1
    dropout_prob: float = 0.0

    # Activation
    activation_function: str = 'relu'

    # Attribute conditioning (0 = disabled, backward compatible)
    n_static_attrs: int = 0
    d_attr_emb: int = 16

    # G1 — UNCONDITIONAL extreme-value guard on the 4 input diffs. Faithful port of the
    # always-on branch of knet/dl/nn_kalman_clamp_5.py:293-299 (apply_clamp_scale_to_diffs),
    # which the migrated net dropped. Applied EVERY step regardless of enable_clamp_scale, so a
    # NaN/OOD feature on a held-out (PUB) basin cannot blow up the learned gain — the root cause
    # of the 12488500/12114500 eval blowups (-154/-433). Defaults = mature RAW-unit bounds (the
    # per-basin script feeds raw diffs); the shared script overrides these to O(1) bounds since
    # it scale-normalizes features before calling compute_gain.
    diff_guard_enable: bool = True
    diff_guard_obs: float = 100.0      # |obs_diff|, |obs_innov_diff|
    diff_guard_state: float = 5000.0   # |fw_evol_diff|, |fw_update_diff|

    # Clamp + Scale normalization for KalmanNet input features.
    # Derived from open-loop model state/observation statistics.
    # Each input is: clamp(x, min, max) / scale  →  roughly [-1, 1]
    enable_clamp_scale: bool = False
    # obs_diff and obs_innov_diff (both [B, n])
    obs_clamp: Tuple[float, float] = (-10.0, 10.0)
    obs_scale: float = 10.0
    # fw_evol_diff and fw_update_diff (both [B, m]) — per state dimension
    # Default: HBV 4-state ranges from 50-basin open-loop P1/P99 + 20% margin
    state_clamp: Optional[List[Tuple[float, float]]] = None
    state_scale: Optional[List[float]] = None

class KalmanNet(nn.Module):
    def __init__(self, config: KalmanNetConfig = KalmanNetConfig(), device=None):
        super().__init__()
        self.config = config
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        self.m = config.m
        self.n = config.n
        
        # Define constraints (from M4 physical ranges approximately)
        # S_snow, S_soil, S_fast, S_slow
        self.state_lb = torch.tensor([0.0, 0.0, 0.0, 0.0], device=self.device)
        self.state_ub = torch.tensor([10000.0, 2000.0, 10000.0, 10000.0], device=self.device) # Broad limits
        
        # Activation map
        activations = {
            'relu': nn.ReLU(),
            'tanh': nn.Tanh(),
            'leaky_relu': nn.LeakyReLU(0.01),
            'softplus': nn.Softplus(),
            'silu': nn.SiLU()
        }
        self.act = activations.get(config.activation_function, nn.ReLU())

        # Register clamp/scale buffers (move with model to GPU)
        if config.enable_clamp_scale:
            self.register_buffer('_obs_clamp_min', torch.tensor(config.obs_clamp[0]))
            self.register_buffer('_obs_clamp_max', torch.tensor(config.obs_clamp[1]))
            self.register_buffer('_obs_scale_val', torch.tensor(config.obs_scale))

            if config.state_clamp is not None and config.state_scale is not None:
                sc = config.state_clamp
                ss = config.state_scale
            else:
                # HBV 4-state defaults (from 50-basin open-loop, P1/P99 + 20% margin)
                sc = [(-20.0, 20.0), (-30.0, 30.0), (-16.0, 16.0), (-7.0, 7.0)]
                ss = [20.0, 30.0, 16.0, 7.0]
            self.register_buffer('_state_clamp_min', torch.tensor([c[0] for c in sc]))
            self.register_buffer('_state_clamp_max', torch.tensor([c[1] for c in sc]))
            self.register_buffer('_state_scale_val', torch.tensor(ss))

        self._build_net()
        
    def _build_net(self):
        c = self.config
        d_attr = c.d_attr_emb if c.n_static_attrs > 0 else 0

        # --- Attribute Encoder (optional) ---
        if c.n_static_attrs > 0:
            self.attr_encoder = nn.Sequential(
                nn.Linear(c.n_static_attrs, c.d_attr_emb),
                nn.ReLU(),
                nn.Linear(c.d_attr_emb, c.d_attr_emb),
            )
        else:
            self.attr_encoder = None

        # --- 1. Q-Path (Process Noise) ---
        # Input: FC5 output (+ attr_emb if configured)
        self.d_input_Q = self.m * c.in_mult_KNet + d_attr
        self.LSTM_Q = nn.LSTM(self.d_input_Q, c.d_hidden_Q, c.num_layers_GRU_Q, dropout=c.dropout_prob)
        self.fc_inQ_to_outQ = nn.Linear(self.d_input_Q, c.d_hidden_Q) # Residual mapping

        # --- 2. Sigma-Path (State Covariance) ---
        # Input: Q output + FC6 output (+ attr_emb if configured)
        self.d_input_Sigma = c.d_hidden_Q + self.m * c.in_mult_KNet + d_attr
        self.LSTM_Sigma = nn.LSTM(self.d_input_Sigma, c.d_hidden_Sigma, c.num_layers_GRU_Sigma, dropout=c.dropout_prob)
        self.fc_in_Sigma_to_out_Sigma = nn.Linear(self.d_input_Sigma, c.d_hidden_Sigma)

        # --- 3. S-Path (Observation Covariance) ---
        # Input: FC1 output + FC7 output (+ attr_emb if configured)
        self.d_output_FC1 = self.n ** 2
        self.d_output_FC7 = 2 * self.n * c.in_mult_KNet
        self.d_input_S = self.d_output_FC1 + self.d_output_FC7 + d_attr
        self.LSTM_S = nn.LSTM(self.d_input_S, c.d_hidden_S, c.num_layers_GRU_S, dropout=c.dropout_prob)
        self.fc_in_S_to_out_S = nn.Linear(self.d_input_S, c.d_hidden_S)
        
        # --- 4. Fully Connected Layers ---
        
        # FC1: Sigma -> S input
        self.FC1 = nn.Sequential(
            nn.Linear(c.d_hidden_Sigma, self.d_output_FC1),
            self.act
        )
        
        # FC2: Gain Calculation (Sigma + S -> Gain)
        d_input_FC2 = c.d_hidden_S + c.d_hidden_Sigma
        d_hidden_FC2 = d_input_FC2 * c.out_mult_KNet
        d_output_FC2 = self.n * self.m
        self.FC2 = nn.Sequential(
            nn.Linear(d_input_FC2, d_hidden_FC2),
            self.act,
            nn.Linear(d_hidden_FC2, d_output_FC2)
        )
        
        # FC3 & FC4: Backward/Recurrent connections
        d_input_FC3 = c.d_hidden_S + d_output_FC2
        d_output_FC3 = self.m ** 2
        self.FC3 = nn.Sequential(
            nn.Linear(d_input_FC3, d_output_FC3),
            self.act
        )
        
        d_input_FC4 = c.d_hidden_Sigma + d_output_FC3
        d_output_FC4 = c.d_hidden_Sigma
        self.FC4 = nn.Sequential(
            nn.Linear(d_input_FC4, d_output_FC4),
            self.act
        )
        
        # FC5: Update diff -> Q input
        self.FC5 = nn.Sequential(
            nn.Linear(self.m, self.m * c.in_mult_KNet),
            self.act
        )
        
        # FC6: Evol diff -> Sigma input
        self.FC6 = nn.Sequential(
            nn.Linear(self.m, self.m * c.in_mult_KNet),
            self.act
        )
        
        # FC7: Obs diffs -> S input
        self.FC7 = nn.Sequential(
            nn.Linear(2 * self.n, 2 * self.n * c.in_mult_KNet),
            self.act
        )
        
        # Initial hidden states projectors
        self.q_prior_to_hidden = nn.Linear(self.m**2, c.d_hidden_Q)
        self.q_prior_to_cell = nn.Linear(self.m**2, c.d_hidden_Q)
        
        self.sigma_prior_to_hidden = nn.Linear(self.m**2, c.d_hidden_Sigma)
        self.sigma_prior_to_cell = nn.Linear(self.m**2, c.d_hidden_Sigma)
        
        self.r_prior_to_hidden = nn.Linear(self.n**2, c.d_hidden_S)
        self.r_prior_to_cell = nn.Linear(self.n**2, c.d_hidden_S)

    def init_hidden(self, batch_size, prior_q, prior_cov, prior_r):
        """Initialize LSTM hidden states from prior covariance matrices"""
        def expand(prior, mapper, layers):
            # prior: [m, m] or similar -> flatten -> map -> [layers, B, hidden]
            flat = prior.flatten().unsqueeze(0) # [1, Dim]
            mapped = mapper(flat) # [1, hidden]
            return mapped.unsqueeze(0).repeat(layers, batch_size, 1)

        c = self.config
        self.h_Q = expand(prior_q, self.q_prior_to_hidden, c.num_layers_GRU_Q)
        self.c_Q = expand(prior_q, self.q_prior_to_cell, c.num_layers_GRU_Q)
        
        self.h_Sigma = expand(prior_cov, self.sigma_prior_to_hidden, c.num_layers_GRU_Sigma)
        self.c_Sigma = expand(prior_cov, self.sigma_prior_to_cell, c.num_layers_GRU_Sigma)
        
        self.h_S = expand(prior_r, self.r_prior_to_hidden, c.num_layers_GRU_S)
        self.c_S = expand(prior_r, self.r_prior_to_cell, c.num_layers_GRU_S)

    def encode_attrs(self, static_attrs: torch.Tensor) -> torch.Tensor:
        """Encode static attributes to embedding. Call once per sequence."""
        if self.attr_encoder is None:
            raise ValueError("KalmanNet not configured for attributes (n_static_attrs=0)")
        return self.attr_encoder(static_attrs)

    def compute_gain(self, obs_diff, obs_innov_diff, fw_evol_diff, fw_update_diff, attr_emb=None):
        """
        Compute Kalman Gain step

        Args:
            obs_diff: [B, n] observation difference
            obs_innov_diff: [B, n] observation innovation difference
            fw_evol_diff: [B, m] forward evolution difference
            fw_update_diff: [B, m] forward update difference
            attr_emb: [B, d_attr_emb] optional attribute embedding (from encode_attrs)
        """
        c = self.config
        d_attr = c.d_attr_emb if c.n_static_attrs > 0 else 0

        # Default to zeros if attr configured but not provided
        if d_attr > 0 and attr_emb is None:
            attr_emb = torch.zeros(obs_diff.shape[0], d_attr, device=obs_diff.device)

        # G1: UNCONDITIONAL extreme-value guard (port of nn_kalman_clamp_5.py:293-299).
        # Always clamp the incoming diffs (raw for per-basin, scale-normalized for shared) so a
        # NaN/OOD feature cannot blow up the gain. Runs BEFORE the optional scale-norm below,
        # matching the mature ordering. No-op for in-distribution features -> gradient unaffected.
        if c.diff_guard_enable:
            go, gs = c.diff_guard_obs, c.diff_guard_state
            obs_diff = torch.clamp(obs_diff, -go, go)
            obs_innov_diff = torch.clamp(obs_innov_diff, -go, go)
            fw_evol_diff = torch.clamp(fw_evol_diff, -gs, gs)
            fw_update_diff = torch.clamp(fw_update_diff, -gs, gs)

        # Clamp + Scale normalization (data-driven, from open-loop statistics)
        if c.enable_clamp_scale:
            obs_diff = torch.clamp(obs_diff, self._obs_clamp_min, self._obs_clamp_max) / self._obs_scale_val
            obs_innov_diff = torch.clamp(obs_innov_diff, self._obs_clamp_min, self._obs_clamp_max) / self._obs_scale_val
            fw_evol_diff = torch.clamp(fw_evol_diff, self._state_clamp_min, self._state_clamp_max) / self._state_scale_val
            fw_update_diff = torch.clamp(fw_update_diff, self._state_clamp_min, self._state_clamp_max) / self._state_scale_val

        # 1. Feature Extraction
        # fw_update_diff [B, m] -> FC5 -> Q input
        out_FC5 = self.FC5(fw_update_diff)

        # 2. Q-LSTM Step
        # in_Q [1, B, feature_dim]
        if d_attr > 0:
            in_Q = torch.cat([out_FC5, attr_emb], dim=-1).unsqueeze(0)
        else:
            in_Q = out_FC5.unsqueeze(0)
        out_Q, (self.h_Q, self.c_Q) = self.LSTM_Q(in_Q, (self.h_Q, self.c_Q))
        # Residual
        res_Q = self.fc_inQ_to_outQ(in_Q)
        out_Q = out_Q + res_Q

        # 3. Sigma-LSTM Step
        # fw_evol_diff [B, m] -> FC6
        out_FC6 = self.FC6(fw_evol_diff)
        if d_attr > 0:
            in_Sigma = torch.cat([out_Q, out_FC6.unsqueeze(0), attr_emb.unsqueeze(0)], dim=2)
        else:
            in_Sigma = torch.cat([out_Q, out_FC6.unsqueeze(0)], dim=2)

        out_Sigma, (self.h_Sigma, self.c_Sigma) = self.LSTM_Sigma(in_Sigma, (self.h_Sigma, self.c_Sigma))
        # Residual
        res_Sigma = self.fc_in_Sigma_to_out_Sigma(in_Sigma)
        out_Sigma = out_Sigma + res_Sigma

        # 4. S-LSTM Step
        # FC1 (Sigma -> S)
        out_FC1 = self.FC1(out_Sigma)

        # FC7 (Obs info)
        in_FC7 = torch.cat([obs_diff, obs_innov_diff], dim=1)
        out_FC7 = self.FC7(in_FC7).unsqueeze(0)

        if d_attr > 0:
            in_S = torch.cat([out_FC1, out_FC7, attr_emb.unsqueeze(0)], dim=2)
        else:
            in_S = torch.cat([out_FC1, out_FC7], dim=2)
        out_S, (self.h_S, self.c_S) = self.LSTM_S(in_S, (self.h_S, self.c_S))
        # Residual
        res_S = self.fc_in_S_to_out_S(in_S)
        out_S = out_S + res_S

        # 5. Compute Gain (FC2)
        in_FC2 = torch.cat([out_Sigma, out_S], dim=2)
        gain_flat = self.FC2(in_FC2) # [1, B, m*n]

        # 6. Backward Flow (Update Sigma Hidden State)
        in_FC3 = torch.cat([out_S, gain_flat], dim=2) # Note: simplified from original which used out_FC2
        out_FC3 = self.FC3(in_FC3)

        in_FC4 = torch.cat([out_Sigma, out_FC3], dim=2)
        out_FC4 = self.FC4(in_FC4)

        # Update hidden state h_Sigma with feedback (simplified recurrence)
        self.h_Sigma = out_FC4.repeat(self.config.num_layers_GRU_Sigma, 1, 1)

        # Reshape Gain
        batch_size = obs_diff.shape[0]
        K = gain_flat.squeeze(0).reshape(batch_size, self.m, self.n)

        return K
