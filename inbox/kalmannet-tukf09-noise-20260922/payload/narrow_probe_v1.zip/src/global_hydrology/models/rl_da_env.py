"""
Gym-like Environment for RL-based Hydrological Data Assimilation
================================================================

This module provides ``HydroDAEnv``, a Gym-style environment that wraps
:class:`M4SystemModel` so that a reinforcement-learning agent can perform
data assimilation by outputting additive corrections to the M4 state vector
at every time-step.

MDP formulation
---------------
- **Observation (agent sees)**: dim = 18

  ``[obs_diff(1), obs_innov_diff(1), fw_evol_diff(4), fw_update_diff(4),
     x_prior(4), innovation(1), forcing(3)]``

  The first four signals are identical to the ones KalmanNet consumes;
  the remaining entries provide extra context (absolute prior state and
  current forcing).

- **Action**: dim = 4, continuous additive corrections to the four M4
  reservoir states ``[S_snow, S_soil, S_fast, S_slow]``.

- **Reward**: ``-|Q_corrected - Q_obs| * high_flow_weight
  - penalty * ||action||``.  Reward is zeroed during the hydrological
  warm-up period.

The environment also exposes :meth:`collect_expert_data` which rolls out a
pre-trained KalmanNet on the same batch and records ``(observation, expert_action)``
pairs suitable for behavioural cloning.

Author: KalmanNet Global DA Project
Date: 2026-03-04
"""

import torch
import torch.nn as nn
from typing import Dict, List, Tuple

from .m4_system_model import M4SystemModel, GlobalHydroSystem
from .kalman_net import KalmanNet


class HydroDAEnv:
    """
    Gym-like environment for RL-based hydrological data assimilation.

    Wraps M4SystemModel: the RL agent observes innovation signals and states,
    and outputs corrections (actions) to the M4 state vector.

    MDP:
    - State (agent observation): dim=18, [obs_diff(1), obs_innov_diff(1),
      fw_evol_diff(4), fw_update_diff(4), x_prior(4), innovation(1), forcing(3)]
      These are the same 4 signals KalmanNet uses + extra context.
    - Action: dim=4, continuous corrections to [S_snow, S_soil, S_fast, S_slow]
    - Reward: -|Q_corrected - Q_obs| * high_flow_weight - penalty * ||action||
    """

    def __init__(
        self,
        global_system: GlobalHydroSystem,
        device: torch.device,
        action_scale: torch.Tensor = None,
        hydro_warmup: int = 90,
        high_flow_threshold: float = 0.9,
        high_flow_weight: float = 3.0,
        correction_penalty: float = 0.01,
    ):
        """
        Args:
            global_system: Frozen Phase 1 model (StaticEncoder + M4).
            device: torch device.
            action_scale: [4,] scaling for tanh output -> mm corrections.
                Defaults to ``[500., 200., 500., 500.]``.
            hydro_warmup: Number of initial warm-up days where reward is 0.
            high_flow_threshold: Quantile threshold (per-basin) above which
                a time-step is considered high-flow.
            high_flow_weight: Reward multiplier for high-flow time-steps.
            correction_penalty: L2 penalty coefficient on correction magnitude.
        """
        self.global_system = global_system
        self.device = device
        self.action_scale = (
            action_scale
            if action_scale is not None
            else torch.tensor([500.0, 200.0, 500.0, 500.0], device=device)
        )
        self.hydro_warmup = hydro_warmup
        self.high_flow_threshold = high_flow_threshold
        self.high_flow_weight = high_flow_weight
        self.correction_penalty = correction_penalty

        # Episode state (set in reset)
        self.sys_model: M4SystemModel = None
        self.forcing: torch.Tensor = None       # [B, T, 3]
        self.target: torch.Tensor = None        # [B, T, 1]
        self.x_posterior: torch.Tensor = None   # [B, 4]
        self.x_post_prev: torch.Tensor = None   # [B, 4]
        self.y_prev: torch.Tensor = None        # [B, 1]
        self.t: int = 0                          # Current timestep
        self.seq_len: int = 0
        self.batch_size: int = 0
        self.high_flow_mask: torch.Tensor = None  # [B, T] bool

    # ------------------------------------------------------------------
    # Core Gym-like interface
    # ------------------------------------------------------------------

    def reset(self, batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        """
        Reset environment with a new data batch.

        Args:
            batch: dict with keys ``'forcing'`` [B,T,3],
                ``'target'`` [B,T,1], ``'static'`` [B,n_attrs].

        Returns:
            obs: [B, 18] initial agent observation (zeros since no prior
                information is available at t=0).
        """
        self.forcing = batch["forcing"].to(self.device)   # [B, T, 3]
        self.target = batch["target"].to(self.device)     # [B, T, 1]
        static = batch["static"].to(self.device)          # [B, n_attrs]

        self.batch_size = self.forcing.shape[0]
        self.seq_len = self.forcing.shape[1]
        self.t = 0

        # Create system model from frozen encoder
        with torch.no_grad():
            hydro_params = self.global_system.static_encoder(static)
        self.sys_model = M4SystemModel(hydro_params, device=self.device)

        # Initialize states
        self.x_posterior = self.sys_model.get_default_initial_state()  # [B, 4]
        self.x_post_prev = self.x_posterior.clone()
        self.y_prev = self.sys_model.h(self.x_posterior)              # [B, 1]

        # Compute high-flow mask for reward weighting
        target_squeeze = self.target.squeeze(-1)  # [B, T]
        # Per-basin high flow threshold
        thresholds = torch.quantile(
            target_squeeze, self.high_flow_threshold, dim=1, keepdim=True
        )
        self.high_flow_mask = target_squeeze > thresholds  # [B, T]

        # Initial observation is zeros (no prior information)
        obs = torch.zeros(self.batch_size, 18, device=self.device)
        return obs

    def step(
        self, action: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor, bool, Dict]:
        """
        Execute one DA timestep.

        Args:
            action: [B, 4] raw corrections (already scaled by actor's
                action_scale).

        Returns:
            next_obs: [B, 18]
            reward: [B, 1]
            done: bool (True when ``t >= seq_len``)
            info: dict with ``'q_corrected'`` [B,1], ``'x_posterior'`` [B,4],
                ``'x_prior'`` [B,4], ``'y_prior'`` [B,1].
        """
        # 1. Physics prediction
        u_t = self.forcing[:, self.t, :]       # [B, 3]
        y_t = self.target[:, self.t, :]        # [B, 1]

        x_prior = self.sys_model.f(self.x_posterior, u_t)   # [B, 4]
        y_prior = self.sys_model.h(x_prior)                 # [B, 1]

        # 2. Apply correction (action IS the correction delta_x)
        x_corrected = x_prior + action                      # [B, 4]
        x_corrected = torch.clamp(x_corrected, min=0.0)    # Physical constraint

        # 3. Corrected observation
        y_corrected = self.sys_model.h(x_corrected)         # [B, 1]

        # 4. Compute reward
        reward = self._compute_reward(y_corrected, y_t, y_prior, action, self.t)  # [B, 1]

        # 5. Build next observation
        obs_diff = y_t - self.y_prev                         # [B, 1]
        obs_innov_diff = y_t - y_prior                       # [B, 1]
        fw_evol_diff = self.x_posterior - self.x_post_prev   # [B, 4]
        fw_update_diff = self.x_posterior - x_prior             # [B, 4] previous posterior vs current prior (matches KalmanNet convention)
        innovation = y_t - y_prior                           # [B, 1]

        next_obs = torch.cat(
            [
                obs_diff,        # [B, 1]
                obs_innov_diff,  # [B, 1]
                fw_evol_diff,    # [B, 4]
                fw_update_diff,  # [B, 4]
                x_prior,         # [B, 4]
                innovation,      # [B, 1]
                u_t,             # [B, 3]
            ],
            dim=-1,
        )  # [B, 18]

        # 6. Update internal state
        self.x_post_prev = self.x_posterior.clone()
        self.x_posterior = x_corrected
        self.y_prev = y_t
        self.t += 1

        done = self.t >= self.seq_len

        info = {
            "q_corrected": y_corrected.detach(),
            "x_posterior": x_corrected.detach(),
            "x_prior": x_prior.detach(),
            "y_prior": y_prior.detach(),
        }

        return next_obs, reward, done, info

    # ------------------------------------------------------------------
    # Reward
    # ------------------------------------------------------------------

    def _compute_reward(
        self,
        y_corrected: torch.Tensor,
        y_obs: torch.Tensor,
        y_prior: torch.Tensor,
        action: torch.Tensor,
        t: int,
    ) -> torch.Tensor:
        """
        Bounded reward based on relative improvement over open-loop.

        Design principles:
        - **Bounded [-1, 1]**: prevents critic Q-value explosion.
        - **Scale-independent**: uses log-ratio, works across flow magnitudes.
        - **Sparse penalty**: correction penalty relative to action_scale.

        r = clip(tanh(log(err_prior / err_corrected)), -1, 1) * flow_weight
            - penalty * ||action/action_scale||

        - r > 0 when correction improves over prior
        - r < 0 when correction worsens
        - log-ratio naturally handles large error differences
        - tanh squashes extreme ratios

        During warm-up (t < hydro_warmup), reward = 0.

        Returns:
            reward: [B, 1]
        """
        if t < self.hydro_warmup:
            return torch.zeros(self.batch_size, 1, device=self.device)

        eps = 0.01  # mm/d floor

        # Errors
        err_prior = torch.abs(y_prior - y_obs) + eps       # [B, 1]
        err_corrected = torch.abs(y_corrected - y_obs) + eps  # [B, 1]

        # Log-ratio improvement: positive when correction helps
        log_ratio = torch.log(err_prior / err_corrected)   # [B, 1]
        improvement = torch.tanh(log_ratio)                  # [B, 1] in (-1, 1)

        # High flow weighting
        is_high = self.high_flow_mask[:, t].unsqueeze(-1).float()  # [B, 1]
        flow_weight = 1.0 + (self.high_flow_weight - 1.0) * is_high

        # Relative correction penalty (bounded ~[0, 1])
        relative_correction = torch.norm(action, dim=-1, keepdim=True) / (torch.norm(self.action_scale) + 1e-6)

        reward = improvement * flow_weight - self.correction_penalty * relative_correction

        return reward

    # ------------------------------------------------------------------
    # BPTT-compatible differentiable rollout
    # ------------------------------------------------------------------

    def differentiable_rollout(
        self,
        actor: "RecurrentActor",
        batch: Dict[str, torch.Tensor],
        deterministic: bool = True,
    ) -> Dict[str, torch.Tensor]:
        """
        Run the full DA sequence with actor corrections, keeping gradients.

        Unlike :meth:`step`, this method does **not** detach intermediate
        states, so the entire computation graph from actor parameters to
        the sequence-level forecast loss is preserved for BPTT — the same
        training paradigm as KalmanNet.

        Args:
            actor: RecurrentActor producing state corrections.
            batch: dict with ``'forcing'`` [B,T,3], ``'target'`` [B,T,1],
                ``'static'`` [B,n_attrs].
            deterministic: if True use mean action (no sampling noise).

        Returns:
            dict with:
                - ``'q_corrected'``: [B, T, 1] corrected discharge
                - ``'q_prior'``:     [B, T, 1] open-loop discharge
                - ``'corrections'``: [B, T, 4] applied state corrections
        """
        # Reset creates M4SystemModel from frozen encoder
        self.reset(batch)

        h_state = None
        obs = torch.zeros(self.batch_size, 18, device=self.device)

        q_corrected_list: List[torch.Tensor] = []
        q_prior_list: List[torch.Tensor] = []
        corrections_list: List[torch.Tensor] = []

        for t in range(self.seq_len):
            # Actor produces correction (gradient flows through)
            if deterministic:
                action, h_state = actor.get_deterministic_action(obs, h_state)
            else:
                action, _, _, h_state = actor(obs, h_state)

            # Physics: predict → correct → observe
            u_t = self.forcing[:, t, :]       # [B, 3]
            y_t = self.target[:, t, :]        # [B, 1]

            x_prior = self.sys_model.f(self.x_posterior, u_t)   # [B, 4]
            y_prior = self.sys_model.h(x_prior)                 # [B, 1]

            x_corrected = torch.clamp(x_prior + action, min=0.0)  # [B, 4]
            y_corrected = self.sys_model.h(x_corrected)            # [B, 1]

            q_corrected_list.append(y_corrected)
            q_prior_list.append(y_prior)
            corrections_list.append(action)

            # Build next observation (NO detach — gradients propagate)
            obs_diff = y_t - self.y_prev
            obs_innov_diff = y_t - y_prior
            fw_evol_diff = self.x_posterior - self.x_post_prev
            fw_update_diff = self.x_posterior - x_prior
            innovation = y_t - y_prior

            obs = torch.cat(
                [
                    obs_diff,        # [B, 1]
                    obs_innov_diff,  # [B, 1]
                    fw_evol_diff,    # [B, 4]
                    fw_update_diff,  # [B, 4]
                    x_prior,         # [B, 4]
                    innovation,      # [B, 1]
                    u_t,             # [B, 3]
                ],
                dim=-1,
            )  # [B, 18]

            # Update state (NO detach — this is what makes BPTT work)
            self.x_post_prev = self.x_posterior
            self.x_posterior = x_corrected
            self.y_prev = y_t

        return {
            "q_corrected": torch.stack(q_corrected_list, dim=1),   # [B, T, 1]
            "q_prior": torch.stack(q_prior_list, dim=1),           # [B, T, 1]
            "corrections": torch.stack(corrections_list, dim=1),   # [B, T, 4]
        }

    # ------------------------------------------------------------------
    # Expert data collection (behavioural cloning from KalmanNet)
    # ------------------------------------------------------------------

    def collect_expert_data(
        self, knet: KalmanNet, batch: Dict[str, torch.Tensor]
    ) -> List[Dict[str, torch.Tensor]]:
        """
        Run KalmanNet on a batch and collect ``(obs, expert_action)`` pairs
        for behavioural cloning.

        The environment is reset internally.  KalmanNet state tracking is
        maintained separately so that the expert roll-out is self-consistent.

        Args:
            knet: A pre-trained KalmanNet instance.
            batch: dict with ``'forcing'``, ``'target'``, ``'static'``.

        Returns:
            List of dicts per timestep, each containing:
                - ``'obs'``: [B, 18] RL observation vector
                - ``'expert_action'``: [B, 4] KalmanNet state correction
        """
        self.reset(batch)
        expert_data: List[Dict[str, torch.Tensor]] = []

        # Initialise KalmanNet hidden states
        knet.init_hidden(
            self.batch_size,
            self.sys_model.prior_q,
            self.sys_model.prior_state_cov,
            self.sys_model.prior_r,
        )

        # Separate state tracking for KalmanNet
        x_post_knet = self.sys_model.get_default_initial_state()  # [B, 4]
        y_prev_knet = self.sys_model.h(x_post_knet)              # [B, 1]
        x_post_prev_knet = x_post_knet.clone()

        with torch.no_grad():
            for t in range(self.seq_len):
                u_t = self.forcing[:, t, :]   # [B, 3]
                y_t = self.target[:, t, :]    # [B, 1]

                # KalmanNet prediction
                x_prior_knet = self.sys_model.f(x_post_knet, u_t)  # [B, 4]
                y_prior_knet = self.sys_model.h(x_prior_knet)      # [B, 1]

                obs_diff = y_t - y_prev_knet                        # [B, 1]
                obs_innov = y_t - y_prior_knet                      # [B, 1]
                fw_evol = x_post_knet - x_post_prev_knet            # [B, 4]
                fw_update = x_post_knet - x_prior_knet              # [B, 4]

                K = knet.compute_gain(obs_diff, obs_innov, fw_evol, fw_update)
                innovation = (y_t - y_prior_knet).unsqueeze(2)     # [B, 1, 1]
                correction = torch.bmm(K, innovation).squeeze(2)   # [B, 4]

                # Build RL observation (same signals)
                rl_obs = torch.cat(
                    [
                        obs_diff,       # [B, 1]
                        obs_innov,      # [B, 1]
                        fw_evol,        # [B, 4]
                        fw_update,      # [B, 4]
                        x_prior_knet,   # [B, 4]
                        obs_innov,      # [B, 1] (innovation = obs_innov for single obs)
                        u_t,            # [B, 3]
                    ],
                    dim=-1,
                )  # [B, 18]

                expert_data.append(
                    {
                        "obs": rl_obs,                 # [B, 18]
                        "expert_action": correction,   # [B, 4]
                    }
                )

                # Update KalmanNet states
                x_post_prev_knet = x_post_knet.clone()
                x_post_knet = torch.clamp(x_prior_knet + correction, min=0.0)
                y_prev_knet = y_t

        return expert_data
