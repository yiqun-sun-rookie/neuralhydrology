"""
End-to-end observation-configurable latent SSM for streamflow prediction.

See spec §3–§4 for the architectural rationale.
"""

from __future__ import annotations

from typing import Dict, List

import torch
import torch.nn as nn

from .networks import (
    DecoderHead,
    PredictionNet,
    StaticContextEncoder,
    UpdateNet,
)


class LatentSSMFilter(nn.Module):
    """
    Observation-configurable latent state-space filter.

    Forward produces per-stream predictions at every timestep along with the
    posterior latent trajectory. Observation streams can be any subset active
    at any subset of timesteps, controlled by `mask`.

    Args:
        n_attrs: number of static attributes
        forcing_dim: forcing vector size (typically 3 for [P, T, PET])
        obs_names: ordered list of observation stream names (e.g., ["Q", "SM", "SWE"]).
            The order defines which mask index corresponds to which stream.
        bias_head_streams: subset of `obs_names` whose decoders include a bias head.
        latent_dim: x dimension
        context_dim: c dimension
        update_hidden: hidden dim of UpdateNet trunk
        decoder_hidden: hidden dim of each DecoderHead
    """

    def __init__(
        self,
        n_attrs: int,
        forcing_dim: int = 3,
        obs_names: List[str] | None = None,
        bias_head_streams: List[str] | None = None,
        latent_dim: int = 32,
        context_dim: int = 32,
        context_hidden: int = 32,
        update_hidden: int = 64,
        decoder_hidden: int = 32,
    ):
        super().__init__()

        self.obs_names = obs_names or ["Q", "SM", "SWE"]
        self.bias_head_streams = set(bias_head_streams or [])
        self.latent_dim = latent_dim
        self.obs_dim = len(self.obs_names)

        self.context = StaticContextEncoder(
            n_attrs=n_attrs, context_dim=context_dim, hidden_dim=context_hidden
        )
        self.predict = PredictionNet(
            latent_dim=latent_dim, forcing_dim=forcing_dim, context_dim=context_dim
        )
        self.update = UpdateNet(
            latent_dim=latent_dim,
            obs_dim=self.obs_dim,
            context_dim=context_dim,
            hidden_dim=update_hidden,
        )
        self.decoders = nn.ModuleDict({
            name: DecoderHead(
                latent_dim=latent_dim,
                context_dim=context_dim,
                hidden_dim=decoder_hidden,
                use_bias_head=name in self.bias_head_streams,
            )
            for name in self.obs_names
        })

    def forward(
        self,
        forcing: torch.Tensor,
        attrs: torch.Tensor,
        obs: Dict[str, torch.Tensor],
        mask: torch.Tensor,
    ) -> Dict:
        """
        Args:
            forcing: [B, T, forcing_dim]
            attrs: [B, n_attrs]
            obs: dict mapping stream name -> [B, T] tensor. Keys must match obs_names.
                 Values may contain NaN as long as the corresponding mask is 0.
            mask: [B, T, len(obs_names)] binary mask, matching obs_names order.

        Returns:
            {
                "predictions": {name: [B, T] tensor, ...},
                "latents": [B, T, latent_dim] posterior latent trajectory
            }
        """
        B, T, _ = forcing.shape
        if mask.shape != (B, T, self.obs_dim):
            raise ValueError(
                f"mask.shape must be (B, T, obs_dim) = ({B}, {T}, {self.obs_dim}); "
                f"got {tuple(mask.shape)}"
            )

        c = self.context(attrs)  # [B, context_dim]
        x = self.predict.initial_state(c)  # [B, latent_dim]

        latents = []
        preds: Dict[str, list[torch.Tensor]] = {name: [] for name in self.obs_names}

        for t in range(T):
            # Predict: x_{t|t-1}
            x_prior = self.predict(x, forcing[:, t, :], c)

            # Assemble observation vector + mask for this step.
            mask_t = mask[:, t, :]  # [B, S]
            # Sanitize NaN obs values BEFORE assembling y_t. UpdateNet does y * mask
            # internally, but 0 * NaN = NaN would propagate — explicit sanitization
            # here is the actual safeguard, not the mask multiplication.
            y_list = []
            for name in self.obs_names:
                y_i = obs[name][:, t]
                y_i = torch.where(torch.isnan(y_i), torch.zeros_like(y_i), y_i)
                y_list.append(y_i)
            y_t = torch.stack(y_list, dim=-1)  # [B, S]

            # Update: x_{t|t}
            x = self.update(x_prior, y_t, mask_t, c)

            # Decode all streams from posterior x
            for name in self.obs_names:
                preds[name].append(self.decoders[name](x, c))

            latents.append(x)

        return {
            "predictions": {
                name: torch.stack(preds[name], dim=1) for name in self.obs_names
            },
            "latents": torch.stack(latents, dim=1),
        }
