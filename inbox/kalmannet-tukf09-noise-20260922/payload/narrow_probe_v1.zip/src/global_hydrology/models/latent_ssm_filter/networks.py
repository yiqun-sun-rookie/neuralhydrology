"""
Neural network modules for the I14 latent SSM.

Modules:
- StaticContextEncoder: attrs -> context vector c
- PredictionNet: (x, u, c) -> x_prior        (Task 5)
- UpdateNet: (x_prior, y_masked, mask, c) -> x_posterior   (Task 6)
- DecoderHead: (x, c) -> y_i (+ optional bias head)        (Task 7)
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class StaticContextEncoder(nn.Module):
    """
    Encode static catchment attributes to a fixed-size context vector `c`.

    `c` conditions PredictionNet, UpdateNet, and decoders. Using a single shared
    context avoids duplicating attribute processing and improves consistency.
    """

    def __init__(self, n_attrs: int, context_dim: int = 32, hidden_dim: int = 32,
                 n_layers: int = 2, dropout: float = 0.1):
        super().__init__()
        layers: list[nn.Module] = [
            nn.Linear(n_attrs, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
        ]
        for _ in range(n_layers - 1):
            layers.extend([
                nn.Linear(hidden_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout),
            ])
        layers.append(nn.Linear(hidden_dim, context_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, attrs: torch.Tensor) -> torch.Tensor:
        """
        Args:
            attrs: [B, n_attrs] normalized static attributes

        Returns:
            context: [B, context_dim]
        """
        return self.net(attrs)


class PredictionNet(nn.Module):
    """
    Latent dynamics f_θ: (x_t, u_t, c) -> x_prior_{t+1}

    Implementation: GRUCell on concatenation [u, c] with hidden state x.
    This gives a Markov latent update where the 'input' is forcing + static context
    and the 'hidden state' is the latent x.

    Static context `c` is fed as part of the GRUCell input (not as initial hidden
    state at every step) so that it continuously conditions dynamics.
    """

    def __init__(self, latent_dim: int, forcing_dim: int, context_dim: int):
        super().__init__()
        self.latent_dim = latent_dim
        self.forcing_dim = forcing_dim
        self.context_dim = context_dim

        # Per step input: [u_t, c]. Hidden: x_t.
        self.cell = nn.GRUCell(input_size=forcing_dim + context_dim, hidden_size=latent_dim)

        # Initial state network: c -> x_0
        self.init_proj = nn.Linear(context_dim, latent_dim)

    def forward(self, x: torch.Tensor, u: torch.Tensor, c: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: [B, latent_dim] current latent (posterior at t, or prior if no update)
            u: [B, forcing_dim] forcing at step t
            c: [B, context_dim] static context

        Returns:
            x_prior: [B, latent_dim] predicted prior at step t+1
        """
        inp = torch.cat([u, c], dim=-1)
        return self.cell(inp, x)

    def initial_state(self, c: torch.Tensor) -> torch.Tensor:
        """
        Produce x_0 from static context.

        Args:
            c: [B, context_dim]

        Returns:
            x_0: [B, latent_dim]
        """
        return torch.tanh(self.init_proj(c))


class UpdateNet(nn.Module):
    """
    Learned observation update g_φ: (x_prior, y, mask, c) -> x_posterior

    Structure: gated residual over x_prior.

        y_masked = y * mask                   # zero out missing streams
        h = MLP([x_prior, y_masked, mask, c])
        delta = W_delta * h
        gate = sigmoid(W_gate * h) * mask_any # gate closes when no obs
        x_posterior = x_prior + gate * delta

    `mask_any = max_i mask_i`, ensuring that when all streams are masked the gate
    is exactly 0 and the residual vanishes (spec §3.2 guarantee).
    """

    def __init__(self, latent_dim: int, obs_dim: int, context_dim: int,
                 hidden_dim: int = 64):
        super().__init__()
        self.latent_dim = latent_dim
        self.obs_dim = obs_dim
        self.context_dim = context_dim

        in_dim = latent_dim + obs_dim + obs_dim + context_dim  # x, y_masked, mask, c
        self.trunk = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
        )
        self.delta_head = nn.Linear(hidden_dim, latent_dim)
        self.gate_head = nn.Linear(hidden_dim, latent_dim)

    def forward(
        self,
        x_prior: torch.Tensor,
        y: torch.Tensor,
        mask: torch.Tensor,
        c: torch.Tensor,
    ) -> torch.Tensor:
        """
        Args:
            x_prior: [B, latent_dim]
            y: [B, obs_dim]
            mask: [B, obs_dim] in {0, 1}
            c: [B, context_dim]

        Returns:
            x_posterior: [B, latent_dim]
        """
        y_masked = y * mask
        h = self.trunk(torch.cat([x_prior, y_masked, mask, c], dim=-1))
        delta = self.delta_head(h)
        gate = torch.sigmoid(self.gate_head(h))
        # Any-observation indicator: shape [B, 1]
        mask_any = mask.amax(dim=-1, keepdim=True)
        return x_prior + gate * delta * mask_any


class DecoderHead(nn.Module):
    """
    Per-stream decoder d_i: (x, c) -> y_i (scalar per step).

    Structure:
        trunk: MLP([x, c]) -> scalar (zero-initialized output layer)
        bias_head (optional): MLP(c) -> scalar, added to trunk output

    The bias head is used for RS streams (SM, SWE, ET, TWS) to absorb
    systematic reanalysis/satellite biases. Q decoder does not use a bias head
    (Q is the prediction target, not a corrigible quantity — see spec §4.1).
    """

    def __init__(
        self,
        latent_dim: int,
        context_dim: int,
        hidden_dim: int = 32,
        use_bias_head: bool = False,
    ):
        super().__init__()
        self.use_bias_head = use_bias_head

        self.trunk = nn.Sequential(
            nn.Linear(latent_dim + context_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )
        # Zero-init trunk output so initial predictions are near-zero
        nn.init.zeros_(self.trunk[-1].weight)
        nn.init.zeros_(self.trunk[-1].bias)

        if use_bias_head:
            self.bias_head = nn.Sequential(
                nn.Linear(context_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, 1),
            )
        else:
            self.bias_head = None

    def forward(self, x: torch.Tensor, c: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: [B, latent_dim]
            c: [B, context_dim]

        Returns:
            y: [B] scalar prediction
        """
        trunk_out = self.trunk(torch.cat([x, c], dim=-1)).squeeze(-1)
        if self.bias_head is not None:
            bias_out = self.bias_head(c).squeeze(-1)
            return trunk_out + bias_out
        return trunk_out
