"""
Uncertainty-weighted multi-task loss (Kendall & Gal 2017).

For K streams:

    L = Σ_i [ (1 / (2 σ_i²)) · MSE_i + log σ_i ]

where each `σ_i` is a learnable parameter per stream with a lower-bound clamp
to prevent degenerate collapse to σ → 0.

`valid` masks are per-step indicators of whether supervision is available
for that stream at that step (e.g., an observation is present). Masked
entries contribute 0 to the MSE sum. The denominator is the total number of
elements (B*T), so the loss scales linearly with the number of valid entries —
more valid entries means more MSE contribution.

This differs from a per-valid-entry mean (sum/n_valid) which would be
invariant to the number of valid entries when per-element residuals are
uniform. Using a fixed denominator (total elements) ensures that having more
valid supervision signal genuinely increases gradient magnitude.
"""

from __future__ import annotations

from typing import Dict, Iterable

import torch
import torch.nn as nn


class UncertaintyWeightedMultiTaskLoss(nn.Module):
    def __init__(
        self,
        stream_names: Iterable[str],
        sigma_lower_bound: float = 0.01,
        initial_log_sigma: float = 0.0,
    ):
        super().__init__()
        self.stream_names = list(stream_names)
        self.sigma_lower_bound = float(sigma_lower_bound)
        # Store as a buffer (float32 tensor) so clamp uses the same dtype as
        # log_sigma parameters, avoiding precision loss from Python float conversion.
        self.register_buffer(
            "log_sigma_lower",
            torch.log(torch.tensor(sigma_lower_bound, dtype=torch.float32)),
        )
        self.log_sigma = nn.ParameterDict({
            name: nn.Parameter(torch.tensor(initial_log_sigma))
            for name in self.stream_names
        })

    def get_sigma(self, name: str) -> torch.Tensor:
        # Clamp sigma post-exp to guarantee the lower bound is met exactly,
        # avoiding float32 round-trip precision loss from log→exp.
        return torch.clamp(
            torch.exp(self.log_sigma[name]),
            min=self.sigma_lower_bound,
        )

    def forward(
        self,
        preds: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
        valid: Dict[str, torch.Tensor],
    ) -> torch.Tensor:
        """
        Args:
            preds: {stream_name: [B, T]}
            targets: {stream_name: [B, T]}  — may contain NaN in invalid positions
            valid: {stream_name: [B, T] in {0, 1}} — 1 where supervision is present

        Returns:
            scalar loss
        """
        total = preds[self.stream_names[0]].new_zeros(())
        for name in self.stream_names:
            p = preds[name]
            t = targets[name]
            v = valid[name]
            # Replace NaN in targets by 0 for safe arithmetic; v zeroes them anyway.
            t_safe = torch.where(torch.isnan(t), torch.zeros_like(t), t)
            sq_err = (p - t_safe) ** 2 * v
            # Use total element count as denominator so that the MSE contribution
            # scales linearly with the number of valid entries (more valid → higher
            # loss). Using n_valid as denominator would make the per-element mean
            # invariant to coverage, which defeats the purpose of the valid mask.
            n_total = float(v.numel())
            mse = sq_err.sum() / n_total

            sigma = self.get_sigma(name)
            sigma_sq = sigma ** 2
            log_sigma = torch.log(sigma)
            total = total + 0.5 * mse / sigma_sq + log_sigma
        return total
