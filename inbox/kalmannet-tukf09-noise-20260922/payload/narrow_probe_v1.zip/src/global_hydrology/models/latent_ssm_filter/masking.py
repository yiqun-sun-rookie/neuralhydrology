"""
Per-sample per-stream Bernoulli mask sampler.

Masking strategy (from spec §5.1):
- `mask_i ~ Bernoulli(p_i)` per stream i
- `p_i` drawn per sample from `Uniform(0, 1)` when `p_keep_mode='uniform'`
  → uniform coverage of mask configurations from all-zeros (forcing-only)
    to all-ones (full observation)
- Fixed `p_keep` available for evaluation modes (e.g., p_keep=1.0 for E1 in-sample,
  p_keep=0.0 for E3 PUB-degraded).
"""

import torch


def sample_observation_mask(
    batch_size: int,
    seq_len: int,
    n_streams: int,
    p_keep: float | None = None,
    p_keep_mode: str = "uniform",
    seed: int | None = None,
    device: torch.device | str = "cpu",
) -> torch.Tensor:
    """
    Sample observation availability mask.

    Args:
        batch_size: B
        seq_len: T
        n_streams: S (e.g., 3 for [Q, SM, SWE] in Phase 0)
        p_keep: If given, use this fixed Bernoulli probability for every element.
            Overrides `p_keep_mode`.
        p_keep_mode: Only used when `p_keep is None`. One of:
            - 'uniform': per sample, draw p ~ Uniform(0, 1), apply to all (T, S)
              positions of that sample. This is the default training mode.
            - 'per_stream_uniform': per (sample, stream), draw p ~ Uniform(0, 1),
              apply to all T positions. Allows different streams of the same sample
              to have independent observation density.
        seed: Reproducibility seed. When provided, affects only this call via a
            fresh local generator (does not perturb global RNG state).
        device: Torch device.

    Returns:
        Mask tensor of shape [B, T, S] with values in {0.0, 1.0}.
    """
    if seed is not None:
        gen = torch.Generator(device=device).manual_seed(seed)
    else:
        gen = None

    if p_keep is not None:
        probs = torch.full((batch_size, seq_len, n_streams), float(p_keep), device=device)
    elif p_keep_mode == "uniform":
        p_per_sample = torch.rand((batch_size, 1, 1), generator=gen, device=device)
        probs = p_per_sample.expand(batch_size, seq_len, n_streams)
    elif p_keep_mode == "per_stream_uniform":
        p_per_sample_stream = torch.rand((batch_size, 1, n_streams), generator=gen, device=device)
        probs = p_per_sample_stream.expand(batch_size, seq_len, n_streams)
    else:
        raise ValueError(f"Unknown p_keep_mode: {p_keep_mode!r}")

    mask = torch.bernoulli(probs, generator=gen)
    return mask
