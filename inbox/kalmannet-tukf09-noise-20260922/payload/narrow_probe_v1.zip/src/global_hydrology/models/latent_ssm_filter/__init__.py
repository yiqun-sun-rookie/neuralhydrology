"""
Observation-configurable latent state-space filter for streamflow prediction.

Spec: docs/superpowers/specs/2026-04-22-observation-configurable-latent-ssm-design.md
"""

from .baselines import LSTMMultiOutputBaseline, LSTMQOnlyBaseline
from .loss import UncertaintyWeightedMultiTaskLoss
from .masking import sample_observation_mask
from .model import LatentSSMFilter
from .networks import (
    DecoderHead,
    PredictionNet,
    StaticContextEncoder,
    UpdateNet,
)

__all__ = [
    "DecoderHead",
    "LSTMMultiOutputBaseline",
    "LSTMQOnlyBaseline",
    "LatentSSMFilter",
    "PredictionNet",
    "StaticContextEncoder",
    "UncertaintyWeightedMultiTaskLoss",
    "UpdateNet",
    "sample_observation_mask",
]
