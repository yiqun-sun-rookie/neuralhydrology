"""
LSTM baselines for I14 Phase 0 comparisons.

- LSTMQOnlyBaseline (B0): standard CAMELS-style LSTM with static attrs.
  Input [forcing, attrs_tiled], output Q only.
- LSTMMultiOutputBaseline (B1): same input, multi-head output [Q, SM, SWE, ...].
  Isolates "multi-task output benefit without latent SSM/mask structure".
"""

from __future__ import annotations

from typing import Dict, List

import torch
import torch.nn as nn


class _LSTMTrunk(nn.Module):
    def __init__(self, n_attrs: int, forcing_dim: int, hidden: int):
        super().__init__()
        self.lstm = nn.LSTM(
            input_size=forcing_dim + n_attrs,
            hidden_size=hidden,
            batch_first=True,
        )

    def forward(self, forcing: torch.Tensor, attrs: torch.Tensor) -> torch.Tensor:
        """
        Args:
            forcing: [B, T, F]
            attrs: [B, A]

        Returns:
            hidden_seq: [B, T, hidden]
        """
        B, T, _ = forcing.shape
        attrs_tiled = attrs.unsqueeze(1).expand(B, T, -1)
        x = torch.cat([forcing, attrs_tiled], dim=-1)
        h, _ = self.lstm(x)
        return h


class LSTMQOnlyBaseline(nn.Module):
    """B0 baseline: Q-only prediction, standard CAMELS LSTM setup."""

    def __init__(self, n_attrs: int, forcing_dim: int = 3, hidden: int = 64):
        super().__init__()
        self.trunk = _LSTMTrunk(n_attrs, forcing_dim, hidden)
        self.head = nn.Linear(hidden, 1)

    def forward(self, forcing: torch.Tensor, attrs: torch.Tensor) -> Dict:
        h = self.trunk(forcing, attrs)
        q = self.head(h).squeeze(-1)
        return {"predictions": {"Q": q}}


class LSTMMultiOutputBaseline(nn.Module):
    """B1 baseline: multi-head output, same input as B0."""

    def __init__(
        self,
        n_attrs: int,
        forcing_dim: int = 3,
        hidden: int = 64,
        obs_names: List[str] | None = None,
    ):
        super().__init__()
        self.obs_names = obs_names or ["Q", "SM", "SWE"]
        self.trunk = _LSTMTrunk(n_attrs, forcing_dim, hidden)
        self.heads = nn.ModuleDict({
            name: nn.Linear(hidden, 1) for name in self.obs_names
        })

    def forward(self, forcing: torch.Tensor, attrs: torch.Tensor) -> Dict:
        h = self.trunk(forcing, attrs)
        preds = {name: self.heads[name](h).squeeze(-1) for name in self.obs_names}
        return {"predictions": preds}
