"""GR4J-PDD transition with only cross-day hydrological memory in the state.

The persistent state is ``[snow, S, R, UH1 active queue, UH2 active queue]``.
Discharge is an emission of the transition and is deliberately not an input state.
All water quantities are in millimetres and the daily transition uses float64.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Mapping, Sequence

import torch

from .differentiable_gr4j_pdd import PARAM_NAMES, uh_ordinates_active


@dataclass(frozen=True)
class StateChannel:
    """Metadata and physical bounds for one persistent state channel."""

    index: int
    name: str
    role: str
    lower: float
    upper: float
    queue_position: int | None = None
    release_lag_days: int | None = None


class AlignedGR4JPDD:
    """Batched float64 GR4J-PDD state transition.

    ``transition(state, (precipitation, temperature, potential_evapotranspiration))``
    accepts ``state`` with shape ``[batch, dim_x]``. Each forcing item may be a
    scalar shared by the batch or a length-``batch`` tensor. It returns the next
    persistent state and discharge with shapes ``[batch, dim_x]`` and ``[batch]``.
    """

    dtype = torch.float64

    def __init__(self, params: Mapping[str, float], device: torch.device | str | None = None):
        missing = [name for name in PARAM_NAMES if name not in params]
        if missing:
            raise KeyError(f"missing GR4J-PDD parameters: {missing}")
        values = {name: float(params[name]) for name in PARAM_NAMES}
        if not all(math.isfinite(value) for value in values.values()):
            raise ValueError("GR4J-PDD parameters must be finite")
        if values["x1"] <= 0.0 or values["x3"] <= 0.0 or values["x4"] <= 0.0:
            raise ValueError("x1, x3, and x4 must be positive")
        if values["pdd_factor_snow"] < 0.0:
            raise ValueError("pdd_factor_snow must be nonnegative")
        if not 0.0 <= values["refreeze_snow"] <= 1.0:
            raise ValueError("refreeze_snow must be between zero and one")

        self.device = torch.device(device or "cpu")
        self.params = values
        self.pdd_factor_snow = values["pdd_factor_snow"]
        self.refreeze_snow = values["refreeze_snow"]
        self.temp_snow = values["temp_snow"]
        self.temp_rain = values["temp_rain"]
        self.x1 = values["x1"]
        self.x2 = values["x2"]
        self.x3 = values["x3"]
        self.x4 = values["x4"]

        uh1, uh2, self.nuh1, self.nuh2 = uh_ordinates_active(
            self.x4, dtype=self.dtype)
        self.uh1 = uh1.to(device=self.device, dtype=self.dtype)
        self.uh2 = uh2.to(device=self.device, dtype=self.dtype)

        self._snow = 0
        self._production_store = 1
        self._routing_store = 2
        self._s0 = 3
        self._s1 = self._s0 + self.nuh1
        self.dim_x = self._s1 + self.nuh2
        self.m = self.dim_x

        metadata = [
            StateChannel(0, "snow", "snow_store", 0.0, math.inf),
            StateChannel(1, "S", "production_store", 0.0, self.x1),
            StateChannel(2, "R", "routing_store", 0.0, self.x3),
        ]
        metadata.extend(
            StateChannel(
                self._s0 + position,
                f"UH1[{position}]",
                "uh1_queue",
                0.0,
                math.inf,
                queue_position=position,
                release_lag_days=position + 1,
            )
            for position in range(self.nuh1)
        )
        metadata.extend(
            StateChannel(
                self._s1 + position,
                f"UH2[{position}]",
                "uh2_queue",
                0.0,
                math.inf,
                queue_position=position,
                release_lag_days=position + 1,
            )
            for position in range(self.nuh2)
        )
        self.state_metadata = tuple(metadata)
        self.state_names = tuple(channel.name for channel in self.state_metadata)
        self.lower_bounds = torch.tensor(
            [channel.lower for channel in self.state_metadata],
            dtype=self.dtype,
            device=self.device,
        )
        self.upper_bounds = torch.tensor(
            [channel.upper for channel in self.state_metadata],
            dtype=self.dtype,
            device=self.device,
        )

    def default_state(self, batch_size: int = 1) -> torch.Tensor:
        """Return the reference initial state for one or more independent batches."""
        if not isinstance(batch_size, int) or isinstance(batch_size, bool) or batch_size < 1:
            raise ValueError("batch_size must be a positive integer")
        state = torch.zeros(
            (batch_size, self.dim_x), dtype=self.dtype, device=self.device)
        state[:, self._production_store] = 0.5 * self.x1
        state[:, self._routing_store] = 0.5 * self.x3
        return state

    def project_state(self, state: torch.Tensor) -> torch.Tensor:
        """Project every persistent channel onto its physical state bounds."""
        values = torch.as_tensor(state, dtype=self.dtype, device=self.device)
        if values.ndim not in (1, 2) or values.shape[-1] != self.dim_x:
            raise ValueError(
                f"persistent state must end with exactly {self.dim_x} channels")
        if not torch.isfinite(values).all():
            raise ValueError("persistent state must be finite")
        return torch.maximum(torch.minimum(values, self.upper_bounds), self.lower_bounds)

    def _forcing_vector(self, value, batch_size: int, name: str) -> torch.Tensor:
        result = torch.as_tensor(value, dtype=self.dtype, device=self.device)
        if result.ndim == 0:
            result = result.expand(batch_size)
        elif result.ndim == 2 and result.shape == (batch_size, 1):
            result = result[:, 0]
        elif result.ndim != 1 or result.shape[0] != batch_size:
            raise ValueError(f"{name} must be scalar or have one value per state batch")
        if not torch.isfinite(result).all():
            raise ValueError(f"{name} must be finite")
        return result

    def transition(
        self,
        state: torch.Tensor,
        forcing: Sequence,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Advance one day and return ``(next_persistent_state, discharge)``."""
        values = torch.as_tensor(state, dtype=self.dtype, device=self.device)
        if values.ndim != 2 or values.shape[1] != self.dim_x:
            raise ValueError(
                f"persistent state must have shape [batch, {self.dim_x}]")
        if len(forcing) != 3:
            raise ValueError(
                "forcing must be (precipitation, temperature, potential evapotranspiration)")
        values = self.project_state(values)
        batch_size = values.shape[0]
        precipitation = self._forcing_vector(forcing[0], batch_size, "precipitation")
        temperature = self._forcing_vector(forcing[1], batch_size, "temperature")
        potential_evapotranspiration = self._forcing_vector(
            forcing[2], batch_size, "potential evapotranspiration")
        if torch.any(precipitation < 0.0):
            raise ValueError("precipitation must be nonnegative")
        if torch.any(potential_evapotranspiration < 0.0):
            raise ValueError("potential evapotranspiration must be nonnegative")

        snow = values[:, self._snow]
        production_store = values[:, self._production_store]
        routing_store = values[:, self._routing_store]
        uh1_queue = values[:, self._s0:self._s1]
        uh2_queue = values[:, self._s1:self.dim_x]

        snow_fraction = torch.clamp(
            (self.temp_rain - temperature)
            / (self.temp_rain - self.temp_snow + 1e-12),
            min=0.0,
            max=1.0,
        )
        snowfall = precipitation * snow_fraction
        rainfall = precipitation - snowfall
        snow = snow + snowfall
        potential_melt = self.pdd_factor_snow * torch.clamp(temperature, min=0.0)
        actual_melt = torch.minimum(snow, potential_melt)
        refrozen = actual_melt * self.refreeze_snow
        snow = torch.clamp(snow - actual_melt + refrozen, min=0.0)
        liquid = actual_melt - refrozen + rainfall

        net_precipitation = torch.clamp(
            liquid - potential_evapotranspiration, min=0.0)
        net_evaporation = torch.clamp(
            potential_evapotranspiration - liquid, min=0.0)
        storage_fraction = production_store / self.x1

        precipitation_tanh = torch.tanh(net_precipitation / self.x1)
        stored_precipitation = (
            self.x1
            * (1.0 - storage_fraction * storage_fraction)
            * precipitation_tanh
            / (1.0 + storage_fraction * precipitation_tanh)
        )
        evaporation_tanh = torch.tanh(net_evaporation / self.x1)
        actual_evaporation = (
            production_store
            * (2.0 - storage_fraction)
            * evaporation_tanh
            / (1.0 + (1.0 - storage_fraction) * evaporation_tanh)
        )
        wet = liquid >= potential_evapotranspiration
        production_store = torch.where(
            wet,
            production_store + stored_precipitation,
            production_store - actual_evaporation,
        )
        production_excess = torch.where(
            wet,
            net_precipitation - stored_precipitation,
            torch.zeros_like(production_store),
        )

        percolation = production_store * (
            1.0
            - (1.0 + (production_store / (2.25 * self.x1)) ** 4) ** (-0.25)
        )
        production_store = production_store - percolation
        routing_input = percolation + production_excess

        uh1_queue = uh1_queue + self.uh1.unsqueeze(0) * (0.9 * routing_input).unsqueeze(1)
        routed_ninety_percent = uh1_queue[:, 0]
        uh1_queue = torch.cat(
            [uh1_queue[:, 1:], torch.zeros_like(uh1_queue[:, :1])], dim=1)
        uh2_queue = uh2_queue + self.uh2.unsqueeze(0) * (0.1 * routing_input).unsqueeze(1)
        routed_ten_percent = uh2_queue[:, 0]
        uh2_queue = torch.cat(
            [uh2_queue[:, 1:], torch.zeros_like(uh2_queue[:, :1])], dim=1)

        groundwater_exchange = self.x2 * (routing_store / self.x3) ** 3.5
        routing_store = torch.clamp(
            routing_store + routed_ninety_percent + groundwater_exchange, min=0.0)
        routing_outflow = routing_store * (
            1.0 - (1.0 + (routing_store / self.x3) ** 4) ** (-0.25)
        )
        routing_store = routing_store - routing_outflow
        direct_outflow = torch.clamp(
            routed_ten_percent + groundwater_exchange, min=0.0)
        discharge = torch.clamp(routing_outflow + direct_outflow, min=0.0)

        next_state = torch.cat(
            [
                snow.unsqueeze(1),
                production_store.unsqueeze(1),
                routing_store.unsqueeze(1),
                uh1_queue,
                uh2_queue,
            ],
            dim=1,
        )
        return self.project_state(next_state), discharge


__all__ = ["AlignedGR4JPDD", "StateChannel"]
