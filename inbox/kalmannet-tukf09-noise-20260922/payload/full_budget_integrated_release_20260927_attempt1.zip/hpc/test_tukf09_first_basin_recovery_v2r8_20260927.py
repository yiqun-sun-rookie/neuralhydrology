"""No-model release checks for one isolated recovery after job 228078."""
from __future__ import annotations

import ast
import json
from pathlib import Path
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import build_tukf09_first_basin_recovery_v2r8_20260927 as builder


@pytest.fixture(scope="module")
def derived(tmp_path_factory):
    report = tmp_path_factory.mktemp("release_report") / "local_pass.xml"
    report.write_text('<testsuite tests="11" failures="0" errors="0" skipped="0"/>', encoding="utf-8")
    return builder.derive_files(report)


def test_source_archive_failure_receipt_and_local_repair_are_exact():
    original, manifest = builder.read_sealed_source()
    supervisor, regression, combined = builder.read_local_repair()
    assert len(original) == len(manifest["files"]) + 1 == 312
    assert builder.sha(builder.SOURCE.read_bytes()) == builder.SOURCE_SHA
    assert builder.sha(builder.FAILURE.read_bytes()) == builder.FAILURE_SHA
    assert builder.sha(original[builder.SUPERVISOR]) == builder.OLD_SUPERVISOR_SHA
    assert builder.sha(supervisor) == builder.SUPERVISOR_SHA
    assert builder.sha(regression) == builder.REGRESSION_SHA
    assert builder.sha(combined) == builder.COMBINED_REPORT_SHA


def test_only_listed_technical_members_change_and_science_is_frozen(derived):
    old, final, manifest = derived
    changed = {name for name in old if final[name] != old[name]}
    assert changed == builder.PATCHED | {"bundle_manifest.json"}
    assert set(final) - set(old) == builder.ADDED
    for name in old:
        if name.startswith(("src/", "configs/", "input/", "results/", "artifacts/")):
            assert final[name] == old[name], name
    assert builder.sha(final["hpc/tukf09_455_scaled_noise_local_transfer_contract_v1.json"]) == builder.SCIENCE_SHA
    assert manifest["parent_bundle_manifest_sha256"] == builder.SOURCE_MANIFEST_SHA


def test_first_basin_only_and_historical_sample_identity(derived):
    _, final, _ = derived
    source = final[builder.DEPLOYER].decode("utf-8")
    namespace = {"__name__": "first_only_release_test"}
    exec(compile(source, builder.DEPLOYER, "exec"), namespace)
    assert namespace["SAMPLES"] == ("01047000", "01142500")
    assert namespace["EXECUTABLE_BASINS"] == ("01047000",)
    assert "for basin_id in EXECUTABLE_BASINS:" in source
    assert "if basin_id not in EXECUTABLE_BASINS:" in source
    with pytest.raises(PermissionError, match="unauthorized basin"):
        namespace["_submit_once"]("01142500", "a" * 64, "b" * 64, prerequisite=None)
    with pytest.raises(PermissionError, match="second basin"):
        namespace["submit_second"]("a" * 64, "b" * 64, "c" * 64)


def test_new_exclusive_paths_and_frozen_model_pythonpath(derived):
    old, final, manifest = derived
    deploy = final[builder.DEPLOYER].decode("utf-8")
    slurm = final[builder.SLURM].decode("utf-8")
    prior_slurm = old[builder.SLURM].decode("utf-8")
    assert builder.OLD_PHASE not in deploy + slurm
    assert builder.NEW_PHASE in deploy and builder.NEW_PHASE in slurm
    assert builder.NEW_ARCHIVE in deploy
    assert f"#SBATCH --job-name={builder.NEW_NAME}" in slurm
    assert "  01047000) ;;" in slurm and "01047000|01142500" not in slurm
    assert f"export PYTHONPATH={builder.PRIVATE}" in slurm
    assert f"export PYTHONPATH={builder.PRIVATE}" in prior_slurm
    assert "bundle/vendor" not in slurm
    assert manifest["path_mapping"]["remote_root"] == builder.NEW_PHASE + "/bundle"


def test_new_authorization_admission_and_gate_are_bound(derived):
    _, final, _ = derived
    authorization = json.loads(final[builder.AUTH_PATH])
    admission = json.loads(final[builder.ADMISSION_PATH])
    gate = final[builder.GATE].decode("utf-8")
    assert authorization["failed_job_id"] == "228078"
    assert authorization["failed_evidence_sha256"] == builder.FAILURE_SHA
    assert authorization["source_bundle_sha256"] == builder.SOURCE_SHA
    assert authorization["repaired_supervisor_sha256"] == builder.SUPERVISOR_SHA
    assert authorization["authorized_basin_id"] == "01047000"
    assert authorization["maximum_new_submissions"] == 1
    for name in ("second_basin_authorized", "formal_evaluation_authorized",
                 "scientific_contract_changes_authorized", "automatic_retry_or_requeue_authorized"):
        assert authorization[name] is False
    assert admission["recovery_authorization_sha256"] == builder.sha(final[builder.AUTH_PATH])
    assert admission["remote_test_partition"]["final_output_guard_regressions"] == 3
    assert admission["second_job_submission_authorized"] is False
    assert 'RECOVERY_AUTH = "' + builder.AUTH_PATH + '"' in gate
    assert 'ADMISSION = "' + builder.ADMISSION_PATH + '"' in gate
    assert 'recovery.get("failed_job_id") != "228078"' in gate


def test_job_gate_runs_new_regression_before_model_without_changing_original_count(derived):
    _, final, _ = derived
    job_gate = final[builder.JOB_GATE].decode("utf-8")
    deployer = final[builder.DEPLOYER].decode("utf-8")
    assert job_gate.index("regression = _run_small_tests") < job_gate.index("new_gate = _run_small_tests")
    assert job_gate.index("regression = _run_small_tests") < job_gate.index("from tukf09_two_basin_hpc_supervisor_v1 import run_supervised")
    assert "original = _run_small_tests(original_command, original_report, 41, environment)" in job_gate
    assert "regression = _run_small_tests(regression_command, regression_report, 3, environment)" in job_gate
    assert '"final_output_guard_regressions": regression' in job_gate
    assert '_require_test_totals(job_gate.get("final_output_guard_regressions"), 3' in deployer


def test_existing_44_test_suite_changes_only_its_synthetic_passing_record(derived):
    old, final, _ = derived
    before = old[builder.TEST_SUITE].decode("utf-8")
    after = final[builder.TEST_SUITE].decode("utf-8")
    expected = builder.replace_once(
        before,
        '        "original_linux_protection_tests": totals(41),\n',
        '        "original_linux_protection_tests": totals(41),\n'
        '        "final_output_guard_regressions": totals(3),\n',
    )
    assert after == expected


def test_all_changed_python_is_syntactically_valid(derived):
    _, final, _ = derived
    for name in builder.PATCHED:
        if name.endswith(".py"):
            ast.parse(final[name].decode("utf-8"), filename=name)


def test_complete_derived_bundle_passes_final_gate(derived, tmp_path):
    _, final, _ = derived
    bundle = builder.long_path(tmp_path / "bundle")
    bundle.mkdir()
    for name, data in final.items():
        path = bundle.joinpath(*name.split("/"))
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    gate_path = bundle / builder.GATE
    namespace = {"__name__": "release_gate_test"}
    exec(compile(gate_path.read_bytes(), str(gate_path), "exec"), namespace)
    result = namespace["verify_bundle"](bundle, builder.sha(final["bundle_manifest.json"]), enforce_remote=False)
    assert result["model_import_performed"] is False
    assert result["evaluation_array_reads"] == 0
    assert result["member_count"] == len(final) - 1


def test_failed_local_report_is_rejected(tmp_path):
    report = tmp_path / "local_fail.xml"
    report.write_text('<testsuite tests="11" failures="1" errors="0" skipped="0"/>', encoding="utf-8")
    with pytest.raises(RuntimeError, match="not all passing"):
        builder.derive_files(report)


def test_changed_supervisor_hash_is_rejected(monkeypatch):
    monkeypatch.setattr(builder, "SUPERVISOR_SHA", "0" * 64)
    with pytest.raises(RuntimeError, match="local repair evidence changed"):
        builder.read_local_repair()


def test_preexisting_destination_and_ambiguous_replacement_are_rejected(tmp_path, monkeypatch):
    monkeypatch.setattr(builder, "DESTINATION", tmp_path)
    with pytest.raises(FileExistsError, match="already exists"):
        builder.build()
    with pytest.raises(RuntimeError):
        builder.replace_once("x", "y", "z")
    with pytest.raises(RuntimeError):
        builder.replace_once("y y", "y", "z")
