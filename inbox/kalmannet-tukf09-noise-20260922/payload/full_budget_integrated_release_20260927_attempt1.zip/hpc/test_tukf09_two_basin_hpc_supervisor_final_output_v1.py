"""Deterministic technical regression; never runs the hydrology model."""
import json
import sys
import time

import pytest

from tukf09_two_basin_hpc_supervisor_v1 import run_supervised


@pytest.mark.skipif(sys.platform != "linux", reason="Linux output-finalization test")
def test_final_output_scan_rejects_stale_sample(tmp_path, monkeypatch):
    import tukf09_two_basin_hpc_supervisor_v1 as module

    original_size = module._output_size
    calls = 0

    def stale_first_sample(root):
        nonlocal calls
        calls += 1
        if calls != 1:
            return original_size(root)
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            stdout = root / "stdout.log"
            pid_file = root / "worker.pid"
            if stdout.exists() and pid_file.exists() and stdout.stat().st_size >= 100001:
                worker = module._proc_identity(int(pid_file.read_text()))
                if worker is None or worker[4] == "Z":
                    return 226
            time.sleep(.01)
        pytest.fail("short worker did not complete before the forced stale sample")

    monkeypatch.setattr(module, "_output_size", stale_first_sample)
    output_dir = tmp_path / "stale_final_output"
    result = run_supervised([sys.executable, "-c", "import time;time.sleep(1);print('x'*100000)"],
                            output_dir, output_limit_bytes=1000, poll_seconds=.1)
    saved = json.loads((output_dir / "supervisor.json").read_text())
    assert calls >= 2
    assert not result["success"] and result["reason"] == "output_limit"
    assert result["output_bytes"] >= 100001
    assert saved == result


@pytest.mark.skipif(sys.platform != "linux", reason="Linux output-finalization test")
@pytest.mark.parametrize("failure,expected_reason", [
    pytest.param(OSError("injected final verification scan failure"),
                 "monitor_write_failure", id="read_error"),
    pytest.param(ValueError("output_link"), "output_link", id="unsafe_link"),
])
def test_final_verification_scan_error_rewrites_status(tmp_path, monkeypatch,
                                                       failure, expected_reason):
    import tukf09_two_basin_hpc_supervisor_v1 as module

    original_size = module._output_size
    original_write = module._write_status
    wrote_success = False
    raised = False

    def observe_write(path, record):
        nonlocal wrote_success
        original_write(path, record)
        if record.get("success") and record.get("reason") == "complete":
            wrote_success = True

    def fail_once_after_success(root):
        nonlocal raised
        if wrote_success and not raised:
            raised = True
            raise failure
        return original_size(root)

    monkeypatch.setattr(module, "_write_status", observe_write)
    monkeypatch.setattr(module, "_output_size", fail_once_after_success)
    output_dir = tmp_path / "final_scan_error"
    result = run_supervised([sys.executable, "-c", "import time;time.sleep(.5);print('ok')"], output_dir,
                            output_limit_bytes=1000, poll_seconds=.1)
    saved = json.loads((output_dir / "supervisor.json").read_text())
    assert wrote_success and raised
    assert not result["success"] and result["reason"] == expected_reason
    assert saved == result
