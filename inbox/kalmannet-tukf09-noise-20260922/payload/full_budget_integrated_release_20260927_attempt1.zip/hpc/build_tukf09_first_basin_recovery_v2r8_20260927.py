"""Derive one first-basin output-guard release from the sealed v2r7 package."""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import sys
import xml.etree.ElementTree as ET
import zipfile


ROOT = Path(__file__).resolve().parents[1]
CONTROL = ROOT / "results/tukf09_455_scaled_noise_local_transfer_v1/control/two_basin_full_budget_hpc_v2"
SOURCE = CONTROL / "recovery_v2r7_release_20260927/bundle/full_budget_recovery_v2r7_20260927.zip"
SOURCE_SHA = "41b81765600449683b2dc158de1bd110b7a2e77b5c1c532073ae4da87f2ea697"
SOURCE_MANIFEST_SHA = "d1806b57a4b42d9b63269da7d04eef0b1ac3e8b51710ea6412db869b1aa1a79d"
FAILURE = CONTROL / "recovery_v2r7_release_20260927/failure_evidence_seq25_receipt.txt"
FAILURE_SHA = "73c2bc03e2f0385687b3fe04ec94093e998e9b9ed9de685b486e9dd23b75d9fd"
SUPERVISOR_SOURCE = ROOT / "hpc/tukf09_two_basin_hpc_supervisor_v1.py"
SUPERVISOR_SHA = "4daed58001f95c474b633191454b1a664dce2596e676d4f701188c9c2b240e83"
OLD_SUPERVISOR_SHA = "983980f1887c651217e2d7ba0def34dc23a3d1522a5c79966529c47017bddbf5"
REGRESSION_SOURCE = ROOT / "hpc/test_tukf09_two_basin_hpc_supervisor_final_output_v1.py"
REGRESSION_SHA = "ba073bf0956142774724953bb211a39b1053f17d379d4baad012f2c86c23a957"
COMBINED_REPORT = CONTROL / "recovery_v2r8_supervisor_fix_local_20260927/combined_002.xml"
COMBINED_REPORT_SHA = "d405406d5ee36253ff4965d09a383859971817b9338a205a5c7a0d697a4a918d"
SCIENCE_SHA = "27239212680bd370bd76f40e53337b7d68d80cbe4dc01feac2164bab4917f8a1"
RELEASE_ROOT = CONTROL / "recovery_v2r8_release_20260927_attempt2"
DESTINATION = RELEASE_ROOT / "bundle"
REPORT = CONTROL / "recovery_v2r8_supervisor_fix_local_20260927/release_builder_tests_002.xml"
OLD_PHASE = "/data1/home/sunyiq/kalmannet_tukf09_scaled_noise_rehearsal_20260922/full_budget_recovery_v2r7_20260927"
NEW_PHASE = "/data1/home/sunyiq/kalmannet_tukf09_scaled_noise_rehearsal_20260922/full_budget_recovery_v2r8_20260927"
OLD_ARCHIVE = "/data1/home/sunyiq/hpc_mailbox/inbox/kalmannet-tukf09-noise-20260922/payload/full_budget_recovery_v2r7_20260927.zip"
NEW_ARCHIVE = "/data1/home/sunyiq/hpc_mailbox/inbox/kalmannet-tukf09-noise-20260922/payload/full_budget_recovery_v2r8_20260927.zip"
OLD_NAME = "tukf09-noise-recover-v2r7-0927"
NEW_NAME = "tukf09-noise-recover-v2r8-0927"
PRIVATE = "/data1/home/sunyiq/kalmannet_tukf09_455_basin_zero_validation_target_variance_revision_v1_a800_exclusive_v2r14_20260909/runtime_v2r14/pysite"
DEPLOYER = "hpc/tukf09_two_basin_full_budget_deploy_v2.py"
GATE = "hpc/tukf09_two_basin_full_budget_gate_v2.py"
JOB_GATE = "hpc/tukf09_two_basin_full_budget_job_gate_v2.py"
TEST_SUITE = "hpc/test_tukf09_two_basin_full_budget_v2.py"
SLURM = "hpc/tukf09_two_basin_full_budget_job_v2.slurm"
SUPERVISOR = "hpc/tukf09_two_basin_hpc_supervisor_v1.py"
REGRESSION = "hpc/test_tukf09_two_basin_hpc_supervisor_final_output_v1.py"
AUTH_PATH = "hpc/tukf09_first_basin_recovery_authorization_v2r8_20260927.json"
OLD_AUTH_PATH = "hpc/tukf09_first_basin_recovery_authorization_v2r7_20260927.json"
ADMISSION_PATH = "hpc/tukf09_two_basin_full_budget_implementation_admission_v2r8_20260927.json"
OLD_ADMISSION_PATH = "hpc/tukf09_two_basin_full_budget_implementation_admission_v2r7_20260927.json"
BUILDER_PATH = "hpc/build_tukf09_first_basin_recovery_v2r8_20260927.py"
TEST_PATH = "hpc/test_tukf09_first_basin_recovery_v2r8_20260927.py"
PLAN_PATH = "docs/plans/2026-09-27-first-basin-output-guard-recovery-v2r8-plan.md"
REPORT_PATH = "input/recovery_v2r8_20260927/local_tests_002.xml"
COMBINED_REPORT_PATH = "input/recovery_v2r8_20260927/combined_002.xml"
PATCHED = frozenset({DEPLOYER, GATE, JOB_GATE, TEST_SUITE, SLURM, SUPERVISOR})
ADDED = frozenset({
    AUTH_PATH, ADMISSION_PATH, BUILDER_PATH, TEST_PATH, PLAN_PATH,
    REPORT_PATH, COMBINED_REPORT_PATH, REGRESSION,
})


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def record(data: bytes) -> dict[str, object]:
    return {"sha256": sha(data), "size_bytes": len(data)}


def json_bytes(value: dict) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")


def long_path(path: Path) -> Path:
    resolved = path.resolve()
    return Path("\\\\?\\" + str(resolved)) if sys.platform == "win32" else resolved


def replace_once(source: str, old: str, new: str) -> str:
    count = source.count(old)
    if count != 1:
        raise RuntimeError(f"expected one occurrence of {old!r}, found {count}")
    return source.replace(old, new)


def replace_section_once(source: str, start: str, end: str, replacement: str) -> str:
    if source.count(start) != 1 or source.count(end) != 1:
        raise RuntimeError("release source section is missing or ambiguous")
    first = source.index(start)
    last = source.index(end)
    if last <= first:
        raise RuntimeError("release source section is out of order")
    return source[:first] + replacement + source[last:]


def report_totals(data: bytes) -> dict[str, int]:
    suites = list(ET.fromstring(data).iter("testsuite"))
    if not suites:
        raise RuntimeError("test report has no suite")
    return {key: sum(int(suite.get(key, "0")) for suite in suites) for key in ("tests", "failures", "errors", "skipped")}


def read_sealed_source() -> tuple[dict[str, bytes], dict]:
    if not SOURCE.is_file() or SOURCE.is_symlink() or sha(SOURCE.read_bytes()) != SOURCE_SHA:
        raise RuntimeError("sealed v2r7 archive missing, linked, or changed")
    files: dict[str, bytes] = {}
    with zipfile.ZipFile(SOURCE) as archive:
        for member in archive.infolist():
            name = member.filename
            relative = PurePosixPath(name)
            mode = member.external_attr >> 16
            if (
                not name or relative.as_posix() != name or relative.is_absolute()
                or ".." in relative.parts or ":" in name or "\\" in name
                or member.is_dir() or stat.S_IFMT(mode) not in (0, stat.S_IFREG)
                or name in files
            ):
                raise RuntimeError("unsafe or duplicate sealed archive member")
            files[name] = archive.read(member)
    if sha(files["bundle_manifest.json"]) != SOURCE_MANIFEST_SHA:
        raise RuntimeError("sealed v2r7 manifest changed")
    manifest = json.loads(files["bundle_manifest.json"])
    if set(manifest["files"]) | {"bundle_manifest.json"} != set(files):
        raise RuntimeError("sealed source member set changed")
    for name, expected in manifest["files"].items():
        if record(files[name]) != expected:
            raise RuntimeError("sealed source member changed: " + name)
    if sha(files[SUPERVISOR]) != OLD_SUPERVISOR_SHA or REGRESSION in files:
        raise RuntimeError("unexpected sealed supervisor or regression identity")
    return files, manifest


def read_local_repair() -> tuple[bytes, bytes, bytes]:
    for path in (SUPERVISOR_SOURCE, REGRESSION_SOURCE, COMBINED_REPORT):
        if not path.is_file() or path.is_symlink():
            raise RuntimeError("local repair evidence missing or linked: " + str(path))
    supervisor = SUPERVISOR_SOURCE.read_bytes()
    regression = REGRESSION_SOURCE.read_bytes()
    combined = COMBINED_REPORT.read_bytes()
    if (sha(supervisor) != SUPERVISOR_SHA or sha(regression) != REGRESSION_SHA
            or sha(combined) != COMBINED_REPORT_SHA):
        raise RuntimeError("local repair evidence changed")
    if report_totals(combined) != {"tests": 44, "failures": 0, "errors": 0, "skipped": 0}:
        raise RuntimeError("local combined protection tests did not all pass")
    return supervisor, regression, combined


def patch_gate(source: str) -> str:
    value = replace_once(source, OLD_PHASE, NEW_PHASE)
    value = replace_once(value, f'ADMISSION = "{OLD_ADMISSION_PATH}"', f'ADMISSION = "{ADMISSION_PATH}"')
    value = replace_once(value, f'RECOVERY_AUTH = "{OLD_AUTH_PATH}"', f'RECOVERY_AUTH = "{AUTH_PATH}"')
    replacement = (
        "    recovery = read_json(root / RECOVERY_AUTH)\n"
        "    if (recovery.get(\"schema_version\") != \"tukf09_first_basin_recovery_authorization_v2r8_20260927\"\n"
        "            or recovery.get(\"remote_phase\") != REMOTE_PHASE.as_posix()\n"
        "            or recovery.get(\"remote_phase_must_not_exist_before_deployment\") is not True\n"
        "            or recovery.get(\"authorized_basin_id\") != \"01047000\"\n"
        "            or recovery.get(\"maximum_new_submissions\") != 1\n"
        "            or recovery.get(\"second_basin_authorized\") is not False\n"
        "            or recovery.get(\"formal_evaluation_authorized\") is not False\n"
        "            or recovery.get(\"scientific_contract_changes_authorized\") is not False\n"
        "            or recovery.get(\"automatic_retry_or_requeue_authorized\") is not False\n"
        "            or recovery.get(\"failed_job_id\") != \"228078\"\n"
        f"            or recovery.get(\"failed_evidence_sha256\") != \"{FAILURE_SHA}\"\n"
        f"            or recovery.get(\"source_bundle_sha256\") != \"{SOURCE_SHA}\"\n"
        f"            or recovery.get(\"source_bundle_manifest_sha256\") != \"{SOURCE_MANIFEST_SHA}\"\n"
        f"            or recovery.get(\"repaired_supervisor_sha256\") != \"{SUPERVISOR_SHA}\"\n"
        f"            or recovery.get(\"local_combined_test_report_sha256\") != \"{COMBINED_REPORT_SHA}\"\n"
        "            or recovery.get(\"scientific_contract_sha256\") != SCIENCE_SHA):\n"
        "        raise PermissionError(\"technical recovery authorization changed\")\n"
    )
    value = replace_section_once(
        value, "    recovery = read_json(root / RECOVERY_AUTH)\n",
        "    admission = read_json(root / ADMISSION)\n", replacement,
    )
    value = replace_once(
        value,
        'admission.get("schema_version") != "tukf09_two_basin_full_budget_implementation_admission_v2r7_20260927"',
        'admission.get("schema_version") != "tukf09_two_basin_full_budget_implementation_admission_v2r8_20260927"',
    )
    value = replace_once(
        value,
        'admission.get("status") != "FIRST_BASIN_IDENTITY_REPAIR_RELEASE_ADMITTED"',
        'admission.get("status") != "FIRST_BASIN_OUTPUT_GUARD_REPAIR_RELEASE_ADMITTED"',
    )
    marker = '    implementation = admission.get("implementation_files")\n'
    expected = (
        '    if admission.get("remote_test_partition") != {\n'
        '        "original_linux_protection_tests": 41,\n'
        '        "final_output_guard_regressions": 3,\n'
        '        "new_standard_library_gate_tests": 44,\n'
        '        "synthetic_tensor_loop_tests": 14,\n'
        '        "failures": 0, "errors": 0, "skipped": 0,\n'
        '    }:\n'
        '        raise PermissionError("remote test partition changed")\n'
    )
    value = replace_once(value, marker, expected + marker)
    ast.parse(value, filename=GATE)
    return value


def patch_deployer(source: str) -> str:
    value = replace_once(source, OLD_PHASE, NEW_PHASE)
    value = replace_once(value, OLD_ARCHIVE, NEW_ARCHIVE)
    value = replace_once(value, f'JOB_NAME = "{OLD_NAME}"', f'JOB_NAME = "{NEW_NAME}"')
    marker = '    _require_test_totals(job_gate.get("new_standard_library_gate_tests"), 44, "new standard-library gate")'
    value = replace_once(
        value, marker,
        '    _require_test_totals(job_gate.get("final_output_guard_regressions"), 3, "final output guard")\n' + marker,
    )
    if ('SAMPLES = ("01047000", "01142500")' not in value
            or 'EXECUTABLE_BASINS = ("01047000",)' not in value
            or "for basin_id in EXECUTABLE_BASINS:" not in value
            or "if basin_id not in EXECUTABLE_BASINS:" not in value):
        raise RuntimeError("first-only dispatch guard changed")
    ast.parse(value, filename=DEPLOYER)
    return value


def patch_job_gate(source: str) -> str:
    value = replace_once(
        source,
        '    original_report = control / "original_tests.xml"\n',
        '    original_report = control / "original_tests.xml"\n'
        '    regression_temp = control / "output_guard_regression_tmp"\n'
        '    regression_report = control / "output_guard_regression.xml"\n',
    )
    value = replace_once(
        value,
        'for path in (final_record, original_temp, original_report, new_temp, new_report, tensor_run):',
        'for path in (final_record, original_temp, original_report, regression_temp, regression_report, new_temp, new_report, tensor_run):',
    )
    value = replace_once(
        value,
        '    original = _run_small_tests(original_command, original_report, 41, environment)\n\n',
        '    original = _run_small_tests(original_command, original_report, 41, environment)\n'
        '    regression_command = base + [\n'
        '        "--basetemp", str(regression_temp),\n'
        '        "--junitxml", str(regression_report),\n'
        '        str(REMOTE_ROOT / "hpc/test_tukf09_two_basin_hpc_supervisor_final_output_v1.py"),\n'
        '    ]\n'
        '    regression = _run_small_tests(regression_command, regression_report, 3, environment)\n\n',
    )
    value = replace_once(
        value,
        '        "original_linux_protection_tests": original,\n',
        '        "original_linux_protection_tests": original,\n'
        '        "final_output_guard_regressions": regression,\n',
    )
    ast.parse(value, filename=JOB_GATE)
    return value


def patch_test_suite(source: str) -> str:
    """Keep the 44 tests; update only the synthetic passing record's new field."""
    value = replace_once(
        source,
        '        "original_linux_protection_tests": totals(41),\n',
        '        "original_linux_protection_tests": totals(41),\n'
        '        "final_output_guard_regressions": totals(3),\n',
    )
    ast.parse(value, filename=TEST_SUITE)
    return value


def patch_slurm(source: str) -> str:
    value = replace_once(source, f"#SBATCH --job-name={OLD_NAME}", f"#SBATCH --job-name={NEW_NAME}")
    if value.count(OLD_PHASE) != 5:
        raise RuntimeError("old phase occurrence count changed in Slurm script")
    value = value.replace(OLD_PHASE, NEW_PHASE)
    if ("  01047000) ;;" not in value or "01047000|01142500" in value
            or value.count(f"export PYTHONPATH={PRIVATE}") != 1
            or "bundle/vendor" in value):
        raise RuntimeError("Slurm first-only or model runtime guard changed")
    return value


def derive_files(report_path: Path) -> tuple[dict[str, bytes], dict[str, bytes], dict]:
    original, old_manifest = read_sealed_source()
    supervisor, regression, combined = read_local_repair()
    if not FAILURE.is_file() or FAILURE.is_symlink() or sha(FAILURE.read_bytes()) != FAILURE_SHA:
        raise RuntimeError("job 228078 failure evidence changed")
    files = dict(original)
    files[SUPERVISOR] = supervisor
    files[GATE] = patch_gate(original[GATE].decode("utf-8")).encode("utf-8")
    files[DEPLOYER] = patch_deployer(original[DEPLOYER].decode("utf-8")).encode("utf-8")
    files[JOB_GATE] = patch_job_gate(original[JOB_GATE].decode("utf-8")).encode("utf-8")
    files[TEST_SUITE] = patch_test_suite(original[TEST_SUITE].decode("utf-8")).encode("utf-8")
    files[SLURM] = patch_slurm(original[SLURM].decode("utf-8")).encode("utf-8")
    files[REGRESSION] = regression
    files[COMBINED_REPORT_PATH] = combined
    source_paths = (
        (AUTH_PATH, ROOT / AUTH_PATH), (BUILDER_PATH, ROOT / BUILDER_PATH),
        (TEST_PATH, ROOT / TEST_PATH), (PLAN_PATH, ROOT / PLAN_PATH),
        (REPORT_PATH, report_path),
    )
    for name, path in source_paths:
        if not path.is_file() or path.is_symlink():
            raise RuntimeError("new source missing or linked: " + str(path))
        files[name] = path.read_bytes()
    recovery = json.loads(files[AUTH_PATH])
    expected_recovery = {
        "schema_version": "tukf09_first_basin_recovery_authorization_v2r8_20260927",
        "authorized_basin_id": "01047000",
        "maximum_new_submissions": 1,
        "second_basin_authorized": False,
        "formal_evaluation_authorized": False,
        "scientific_contract_changes_authorized": False,
        "automatic_retry_or_requeue_authorized": False,
        "failed_job_id": "228078",
        "failed_evidence_sha256": FAILURE_SHA,
        "source_bundle_sha256": SOURCE_SHA,
        "source_bundle_manifest_sha256": SOURCE_MANIFEST_SHA,
        "repaired_supervisor_sha256": SUPERVISOR_SHA,
        "local_combined_test_report_sha256": COMBINED_REPORT_SHA,
        "scientific_contract_sha256": SCIENCE_SHA,
        "remote_phase": NEW_PHASE,
        "remote_phase_must_not_exist_before_deployment": True,
        "old_remote_phase_read_only": OLD_PHASE,
    }
    if any(recovery.get(key) != value for key, value in expected_recovery.items()):
        raise PermissionError("one-time first-basin authorization changed")
    old_admission = json.loads(original[OLD_ADMISSION_PATH])
    if (old_admission.get("schema_version") != "tukf09_two_basin_full_budget_implementation_admission_v2r7_20260927"
            or old_admission.get("status") != "FIRST_BASIN_IDENTITY_REPAIR_RELEASE_ADMITTED"):
        raise RuntimeError("source admission identity changed")
    admission = dict(old_admission)
    admission["schema_version"] = "tukf09_two_basin_full_budget_implementation_admission_v2r8_20260927"
    admission["status"] = "FIRST_BASIN_OUTPUT_GUARD_REPAIR_RELEASE_ADMITTED"
    admission["previous_implementation_admission_sha256"] = sha(original[OLD_ADMISSION_PATH])
    admission["recovery_authorization_sha256"] = sha(files[AUTH_PATH])
    implementation = dict(old_admission["implementation_files"])
    for name in PATCHED | {BUILDER_PATH, TEST_PATH, REGRESSION}:
        implementation[name] = record(files[name])
    admission["implementation_files"] = implementation
    totals = report_totals(files[REPORT_PATH])
    if totals["tests"] < 9 or any(totals[key] for key in ("failures", "errors", "skipped")):
        raise RuntimeError("new local tests are not all passing")
    admission["local_test_report"] = {"path": REPORT_PATH, **record(files[REPORT_PATH]), **totals}
    admission["remote_test_partition"] = {
        "original_linux_protection_tests": 41,
        "final_output_guard_regressions": 3,
        "new_standard_library_gate_tests": 44,
        "synthetic_tensor_loop_tests": 14,
        "failures": 0, "errors": 0, "skipped": 0,
    }
    admission["second_job_requires_first_job_independent_acceptance"] = False
    admission["second_job_submission_authorized"] = False
    files[ADMISSION_PATH] = json_bytes(admission)
    manifest = dict(old_manifest)
    manifest["schema_version"] = "tukf09_two_basin_full_budget_bundle_manifest_v2r8_20260927"
    manifest["path_mapping"] = dict(old_manifest["path_mapping"], remote_root=NEW_PHASE + "/bundle")
    manifest["parent_bundle_manifest_sha256"] = SOURCE_MANIFEST_SHA
    manifest["files"] = {name: record(data) for name, data in sorted(files.items()) if name != "bundle_manifest.json"}
    files["bundle_manifest.json"] = json_bytes(manifest)
    changed = {name for name in original if files[name] != original[name]}
    if changed != PATCHED | {"bundle_manifest.json"} or set(files) - set(original) != ADDED:
        raise RuntimeError("release member change set is not exact")
    for name, data in original.items():
        if name.startswith(("src/", "configs/", "input/", "results/", "artifacts/")) and files[name] != data:
            raise RuntimeError("scientific or sealed evidence member changed: " + name)
    if sha(files["hpc/tukf09_455_scaled_noise_local_transfer_contract_v1.json"]) != SCIENCE_SHA:
        raise RuntimeError("scientific contract changed")
    return original, files, manifest


def build() -> dict:
    destination = long_path(DESTINATION)
    if destination.exists() or destination.is_symlink():
        raise FileExistsError("exclusive release bundle already exists")
    original, files, _ = derive_files(REPORT)
    extracted = long_path(DESTINATION / "extracted")
    extracted.mkdir(parents=True, exist_ok=False)
    for name, data in sorted(files.items()):
        path = extracted.joinpath(*PurePosixPath(name).parts)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as stream:
            stream.write(data)
    gate_path = extracted / GATE
    namespace = {"__name__": "first_basin_release_gate_v2r8"}
    exec(compile(gate_path.read_bytes(), str(gate_path), "exec"), namespace)
    gate = namespace["verify_bundle"](extracted, sha(files["bundle_manifest.json"]), enforce_remote=False)
    archive_path = long_path(DESTINATION / "full_budget_recovery_v2r8_20260927.zip")
    with zipfile.ZipFile(archive_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 9, 27, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (stat.S_IFREG | 0o640) << 16
            archive.writestr(info, data)
    if archive_path.stat().st_size > 10 * 2**20:
        raise RuntimeError("release payload exceeds mailbox limit")
    with zipfile.ZipFile(archive_path) as archive:
        if set(archive.namelist()) != set(files):
            raise RuntimeError("release archive member set changed")
        for name, data in files.items():
            if archive.read(name) != data:
                raise RuntimeError("release archive bytes differ from extracted bundle: " + name)
    receipt = {
        "status": "FIRST_BASIN_OUTPUT_GUARD_RELEASE_BUILT_NOT_PUBLISHED",
        "source_archive_sha256": SOURCE_SHA,
        "source_manifest_sha256": SOURCE_MANIFEST_SHA,
        "failure_evidence_sha256": FAILURE_SHA,
        "repaired_supervisor_sha256": SUPERVISOR_SHA,
        "source_member_count": len(original),
        "new_member_count": len(files),
        "patched_source_members": sorted(PATCHED),
        "added_members": sorted(ADDED),
        "bundle_manifest_sha256": sha(files["bundle_manifest.json"]),
        "archive": record(archive_path.read_bytes()),
        "gate": gate,
        "model_calls": 0,
        "evaluation_array_reads": 0,
    }
    with long_path(DESTINATION / "bundle_build_receipt.json").open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")
    return receipt


if __name__ == "__main__":
    print(json.dumps(build(), ensure_ascii=False, sort_keys=True, indent=2))
