"""Keep technical pytest scratch inside the scanned basin without lingering links.

Only the two existing negative tests may create links. Their link identities
are recorded before unlinking, after their assertions pass. Any other link
is an error and is deliberately left in place as failure evidence.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import stat

import pytest


def _links(root: Path) -> list[tuple[Path, str]]:
    found = []
    for current, directories, files in os.walk(root, topdown=True, followlinks=False):
        parent = Path(current)
        for name in directories + files:
            path = parent / name
            mode = path.lstat().st_mode
            if stat.S_ISLNK(mode):
                found.append((path, os.readlink(path)))
            elif not (stat.S_ISDIR(mode) or stat.S_ISREG(mode)):
                raise RuntimeError("unexpected temporary object: " + str(path))
        directories[:] = [name for name in directories if not (parent / name).is_symlink()]
    return sorted(found, key=lambda item: item[0].as_posix())


def _allowed(request: pytest.FixtureRequest, root: Path) -> dict[str, str]:
    name = request.node.originalname
    if name == "test_output_link_rejected":
        return {"link/linked": "/etc/passwd"}
    if name == "test_synthetic_bundle_rejects_changes":
        callspec = getattr(request.node, "callspec", None)
        if callspec is not None and callspec.params.get("change") == "link":
            return {"bundle/input/training_validation.npz": str(root / "bundle/input/metadata.json")}
    return {}


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item: pytest.Item, call: pytest.CallInfo):
    outcome = yield
    if call.when == "call":
        item._tukf09_call_passed = outcome.get_result().passed


@pytest.fixture
def tmp_path(request: pytest.FixtureRequest, tmp_path_factory: pytest.TempPathFactory) -> Path:
    """Use one plain, test-specific directory; never create pytest's current link."""
    identity = hashlib.sha256(request.node.nodeid.encode("utf-8")).hexdigest()[:20]
    root = tmp_path_factory.mktemp("case_" + identity, numbered=False)
    yield root

    found = _links(root)
    expected = _allowed(request, root)
    observed = {path.relative_to(root).as_posix(): target for path, target in found}
    if observed != expected:
        raise AssertionError("unexpected temporary links: " + repr(observed))
    if expected and not getattr(request.node, "_tukf09_call_passed", False):
        raise AssertionError("link-producing rejection test did not pass")
    if not found:
        return
    record = {
        "schema_version": "tukf09_test_link_disposition_v1",
        "test_node_id": request.node.nodeid,
        "assertion_passed": True,
        "links": [{"relative_path": relative, "target_text": target}
                  for relative, target in sorted(observed.items())],
        "disposition": "registered_test_links_only",
    }
    with (root / "test_link_disposition.json").open("x", encoding="utf-8") as stream:
        json.dump(record, stream, sort_keys=True, separators=(",", ":"))
        stream.write("\n")
    for path, target in found:
        if not path.is_symlink() or os.readlink(path) != target:
            raise RuntimeError("test link changed after recording: " + str(path))
        path.unlink()
    if _links(root):
        raise AssertionError("temporary test links remain after disposition")
