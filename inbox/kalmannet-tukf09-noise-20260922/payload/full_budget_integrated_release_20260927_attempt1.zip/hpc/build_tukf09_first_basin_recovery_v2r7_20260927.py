"""Build one exclusive first-basin release from sealed v2r6 and reviewed v2r7 bytes."""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import sys
import xml.etree.ElementTree as ET
import zipfile


ROOT = Path(__file__).resolve().parents[1]
CONTROL = ROOT / "results/tukf09_455_scaled_noise_local_transfer_v1/control/two_basin_full_budget_hpc_v2"
SOURCE = CONTROL / "recovery_v2r6/bundle/full_budget_recovery_v2r6.zip"
SOURCE_SHA = "c44a5cda5cb19cc0736c60442476110fe86cf7237f57c013e3d280b35ba8ce7a"
SOURCE_MANIFEST_SHA = "72329a2a38c1616513fbd1ca97d6abcb7c4d665c45040d0fbf6e9d0d9b4feb5e"
FAILURE = CONTROL / "recovery_v2r6_failure_evidence_seq21_receipt.txt"
FAILURE_SHA = "4f63b9d065c2d2a2bf123528b2a10fb4d7d3e6ca05fad01bdb8cb8a15310250b"
LEDGER = CONTROL / "recovery_v2r7_candidate/candidate_member_ledger.json"
LEDGER_SHA = "e1a406540b44512d48323909dea42e3947a02ad430c19fe5a89d6a8687a5dca6"
CANDIDATE = CONTROL / "recovery_v2r7_candidate/extracted"
CANDIDATE_DEPLOYER_SHA = "0f3853353f385276343b977367ea4650ad1a094d06847fcd8c714570ebdf065b"
SCIENCE_SHA = "27239212680bd370bd76f40e53337b7d68d80cbe4dc01feac2164bab4917f8a1"
RELEASE_ROOT = CONTROL / "recovery_v2r7_release_20260927"
DESTINATION = RELEASE_ROOT / "bundle"
REPORT = RELEASE_ROOT / "local_tests_001.xml"
OLD_PHASE = "/data1/home/sunyiq/kalmannet_tukf09_scaled_noise_rehearsal_20260922/full_budget_recovery_v2r6"
NEW_PHASE = "/data1/home/sunyiq/kalmannet_tukf09_scaled_noise_rehearsal_20260922/full_budget_recovery_v2r7_20260927"
OLD_ARCHIVE = "/data1/home/sunyiq/hpc_mailbox/inbox/kalmannet-tukf09-noise-20260922/payload/full_budget_recovery_v2r6.zip"
NEW_ARCHIVE = "/data1/home/sunyiq/hpc_mailbox/inbox/kalmannet-tukf09-noise-20260922/payload/full_budget_recovery_v2r7_20260927.zip"
NEW_NAME = "tukf09-noise-recover-v2r7-0927"
PRIVATE = "/data1/home/sunyiq/kalmannet_tukf09_455_basin_zero_validation_target_variance_revision_v1_a800_exclusive_v2r14_20260909/runtime_v2r14/pysite"
DEPLOYER = "hpc/tukf09_two_basin_full_budget_deploy_v2.py"
GATE = "hpc/tukf09_two_basin_full_budget_gate_v2.py"
SLURM = "hpc/tukf09_two_basin_full_budget_job_v2.slurm"
AUTH_PATH = "hpc/tukf09_first_basin_recovery_authorization_v2r7_20260927.json"
ADMISSION_PATH = "hpc/tukf09_two_basin_full_budget_implementation_admission_v2r7_20260927.json"
OLD_ADMISSION_PATH = "hpc/tukf09_two_basin_full_budget_implementation_admission_v2r6.json"
BUILDER_PATH = "hpc/build_tukf09_first_basin_recovery_v2r7_20260927.py"
TEST_PATH = "hpc/test_tukf09_first_basin_recovery_v2r7_20260927.py"
PLAN_PATH = "docs/plans/2026-09-27-tukf09-first-basin-single-submit-release-plan.md"
REPORT_PATH = "input/recovery_v2r7_20260927/local_tests_001.xml"
PATCHED = frozenset({DEPLOYER, GATE, SLURM})
ADDED = frozenset({AUTH_PATH, ADMISSION_PATH, BUILDER_PATH, TEST_PATH, PLAN_PATH, REPORT_PATH})


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def record(data: bytes) -> dict[str, object]:
    return {"sha256": sha(data), "size_bytes": len(data)}


def json_bytes(value: dict) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")


def long_path(path: Path) -> Path:
    resolved = path.resolve()
    return Path("\\\\?\\" + str(resolved)) if sys.platform == "win32" else resolved


def replace_once(source: str, old: str, new: str) -> str:
    count = source.count(old)
    if count != 1:
        raise RuntimeError(f"expected one occurrence of {old!r}, found {count}")
    return source.replace(old, new)


def read_sealed_source() -> tuple[dict[str, bytes], dict]:
    if not SOURCE.is_file() or SOURCE.is_symlink() or sha(SOURCE.read_bytes()) != SOURCE_SHA:
        raise RuntimeError("sealed v2r6 archive missing, linked, or changed")
    files: dict[str, bytes] = {}
    with zipfile.ZipFile(SOURCE) as archive:
        for member in archive.infolist():
            name = member.filename
            relative = PurePosixPath(name)
            mode = member.external_attr >> 16
            if (
                not name or relative.as_posix() != name or relative.is_absolute()
                or ".." in relative.parts or ":" in name or "\\" in name
                or member.is_dir() or stat.S_IFMT(mode) not in (0, stat.S_IFREG)
                or name in files
            ):
                raise RuntimeError("unsafe or duplicate sealed archive member")
            files[name] = archive.read(member)
    if sha(files["bundle_manifest.json"]) != SOURCE_MANIFEST_SHA:
        raise RuntimeError("sealed v2r6 manifest changed")
    manifest = json.loads(files["bundle_manifest.json"])
    if set(manifest["files"]) | {"bundle_manifest.json"} != set(files):
        raise RuntimeError("sealed source member set changed")
    for name, expected in manifest["files"].items():
        if record(files[name]) != expected:
            raise RuntimeError("sealed source member changed: " + name)
    return files, manifest


def read_reviewed_candidate(original: dict[str, bytes]) -> bytes:
    if not LEDGER.is_file() or LEDGER.is_symlink() or sha(LEDGER.read_bytes()) != LEDGER_SHA:
        raise RuntimeError("reviewed candidate ledger changed")
    ledger = json.loads(LEDGER.read_bytes())
    if (ledger.get("status") != "LOCAL_NON_DEPLOYABLE_CANDIDATE_ONLY"
            or ledger.get("changed_members") != [DEPLOYER]
            or ledger.get("source_archive", {}).get("sha256") != SOURCE_SHA
            or ledger.get("member_count") != len(original)):
        raise RuntimeError("reviewed candidate identity changed")
    for name, source_bytes in original.items():
        path = long_path(CANDIDATE.joinpath(*PurePosixPath(name).parts))
        if not path.is_file() or path.is_symlink():
            raise RuntimeError("reviewed candidate member missing or linked: " + name)
        actual = path.read_bytes()
        if name == DEPLOYER:
            if sha(actual) != CANDIDATE_DEPLOYER_SHA:
                raise RuntimeError("reviewed candidate deployer changed")
            deployer = actual
        elif actual != source_bytes:
            raise RuntimeError("reviewed candidate differs beyond deployer: " + name)
    return deployer


def patch_gate(source: str) -> str:
    value = replace_once(source, OLD_PHASE, NEW_PHASE)
    value = replace_once(value, f'ADMISSION = "{OLD_ADMISSION_PATH}"', f'ADMISSION = "{ADMISSION_PATH}"')
    value = replace_once(value,
        'RECOVERY_AUTH = "hpc/tukf09_first_basin_recovery_authorization_v2r6.json"',
        f'RECOVERY_AUTH = "{AUTH_PATH}"')
    value = replace_once(value,
        'recovery.get("schema_version") != "tukf09_first_basin_recovery_authorization_v2r6"',
        'recovery.get("schema_version") != "tukf09_first_basin_recovery_authorization_v2r7_20260927"')
    value = replace_once(value,
        'recovery.get("failed_job_id") != "227494"):  # technical retry, not a new science contract',
        'recovery.get("failed_job_id") != "227637"\n'
        f'            or recovery.get("failed_evidence_sha256") != "{FAILURE_SHA}"\n'
        f'            or recovery.get("source_bundle_sha256") != "{SOURCE_SHA}"\n'
        f'            or recovery.get("candidate_deployer_sha256") != "{CANDIDATE_DEPLOYER_SHA}"\n'
        '            or recovery.get("automatic_retry_or_requeue_authorized") is not False):')
    value = replace_once(value,
        'admission.get("schema_version") != "tukf09_two_basin_full_budget_implementation_admission_v2r6"',
        'admission.get("schema_version") != "tukf09_two_basin_full_budget_implementation_admission_v2r7_20260927"')
    value = replace_once(value,
        'admission.get("status") != "FIRST_BASIN_TECHNICAL_RECOVERY_ONLY_ADMITTED"',
        'admission.get("status") != "FIRST_BASIN_IDENTITY_REPAIR_RELEASE_ADMITTED"')
    ast.parse(value, filename=GATE)
    return value


def patch_deployer(candidate: bytes) -> str:
    source = candidate.decode("utf-8")
    value = replace_once(source, OLD_PHASE, NEW_PHASE)
    value = replace_once(value, OLD_ARCHIVE, NEW_ARCHIVE)
    value = replace_once(value, 'JOB_NAME = "tukf09-noise-recover-v2r6"', f'JOB_NAME = "{NEW_NAME}"')
    if ('SAMPLES = ("01047000", "01142500")' not in value
            or 'EXECUTABLE_BASINS = ("01047000",)' not in value
            or "for basin_id in EXECUTABLE_BASINS:" not in value
            or "if basin_id not in EXECUTABLE_BASINS:" not in value):
        raise RuntimeError("first-only candidate guard changed")
    ast.parse(value, filename=DEPLOYER)
    return value


def patch_slurm(source: str) -> str:
    value = replace_once(source, "#SBATCH --job-name=tukf09-noise-recover-v2r6", f"#SBATCH --job-name={NEW_NAME}")
    if value.count(OLD_PHASE) != 5:
        raise RuntimeError("old phase occurrence count changed in Slurm script")
    value = value.replace(OLD_PHASE, NEW_PHASE)
    if ("  01047000) ;;" not in value or "01047000|01142500" in value
            or value.count(f"export PYTHONPATH={PRIVATE}") != 1 or "bundle/vendor" in value):
        raise RuntimeError("Slurm first-only or model runtime guard changed")
    return value


def derive_files(report_path: Path) -> tuple[dict[str, bytes], dict[str, bytes], dict]:
    original, old_manifest = read_sealed_source()
    candidate = read_reviewed_candidate(original)
    if sha(FAILURE.read_bytes()) != FAILURE_SHA:
        raise RuntimeError("job 227637 failure evidence changed")
    files = dict(original)
    files[GATE] = patch_gate(original[GATE].decode("utf-8")).encode("utf-8")
    files[DEPLOYER] = patch_deployer(candidate).encode("utf-8")
    files[SLURM] = patch_slurm(original[SLURM].decode("utf-8")).encode("utf-8")
    source_paths = ((AUTH_PATH, ROOT / AUTH_PATH), (BUILDER_PATH, ROOT / BUILDER_PATH),
                    (TEST_PATH, ROOT / TEST_PATH), (PLAN_PATH, ROOT / PLAN_PATH),
                    (REPORT_PATH, report_path))
    for name, path in source_paths:
        if not path.is_file() or path.is_symlink():
            raise RuntimeError("new source missing or linked: " + str(path))
        files[name] = path.read_bytes()
    recovery = json.loads(files[AUTH_PATH])
    if (recovery.get("schema_version") != "tukf09_first_basin_recovery_authorization_v2r7_20260927"
            or recovery.get("failed_job_id") != "227637"
            or recovery.get("failed_evidence_sha256") != FAILURE_SHA
            or recovery.get("source_bundle_sha256") != SOURCE_SHA
            or recovery.get("source_bundle_manifest_sha256") != SOURCE_MANIFEST_SHA
            or recovery.get("reviewed_candidate_ledger_sha256") != LEDGER_SHA
            or recovery.get("candidate_deployer_sha256") != CANDIDATE_DEPLOYER_SHA
            or recovery.get("scientific_contract_sha256") != SCIENCE_SHA
            or recovery.get("authorized_basin_id") != "01047000"
            or recovery.get("maximum_new_submissions") != 1
            or recovery.get("second_basin_authorized") is not False
            or recovery.get("formal_evaluation_authorized") is not False
            or recovery.get("scientific_contract_changes_authorized") is not False
            or recovery.get("automatic_retry_or_requeue_authorized") is not False
            or recovery.get("remote_phase") != NEW_PHASE
            or recovery.get("remote_phase_must_not_exist_before_deployment") is not True):
        raise PermissionError("one-time first-basin authorization changed")
    old_admission = json.loads(original[OLD_ADMISSION_PATH])
    admission = dict(old_admission)
    admission["schema_version"] = "tukf09_two_basin_full_budget_implementation_admission_v2r7_20260927"
    admission["status"] = "FIRST_BASIN_IDENTITY_REPAIR_RELEASE_ADMITTED"
    admission["previous_implementation_admission_sha256"] = sha(original[OLD_ADMISSION_PATH])
    admission["recovery_authorization_sha256"] = sha(files[AUTH_PATH])
    implementation = dict(old_admission["implementation_files"])
    for name in PATCHED | {BUILDER_PATH, TEST_PATH}:
        implementation[name] = record(files[name])
    admission["implementation_files"] = implementation
    suites = list(ET.fromstring(files[REPORT_PATH]).iter("testsuite"))
    totals = {key: sum(int(suite.get(key, "0")) for suite in suites) for key in ("tests", "failures", "errors", "skipped")}
    if not suites or totals["tests"] < 9 or any(totals[key] for key in ("failures", "errors", "skipped")):
        raise RuntimeError("new local tests are not all passing")
    admission["local_test_report"] = {"path": REPORT_PATH, **record(files[REPORT_PATH]), **totals}
    admission["second_job_requires_first_job_independent_acceptance"] = False
    admission["second_job_submission_authorized"] = False
    files[ADMISSION_PATH] = json_bytes(admission)
    manifest = dict(old_manifest)
    manifest["schema_version"] = "tukf09_two_basin_full_budget_bundle_manifest_v2r7_20260927"
    manifest["path_mapping"] = dict(old_manifest["path_mapping"], remote_root=NEW_PHASE + "/bundle")
    manifest["parent_bundle_manifest_sha256"] = SOURCE_MANIFEST_SHA
    manifest["files"] = {name: record(data) for name, data in sorted(files.items()) if name != "bundle_manifest.json"}
    files["bundle_manifest.json"] = json_bytes(manifest)
    changed = {name for name in original if files[name] != original[name]}
    if changed != PATCHED | {"bundle_manifest.json"} or set(files) - set(original) != ADDED:
        raise RuntimeError("release member change set is not exact")
    return original, files, manifest


def build() -> dict:
    destination = long_path(DESTINATION)
    if destination.exists() or destination.is_symlink():
        raise FileExistsError("exclusive release bundle already exists")
    original, files, _ = derive_files(REPORT)
    extracted = long_path(DESTINATION / "extracted")
    extracted.mkdir(parents=True, exist_ok=False)
    for name, data in sorted(files.items()):
        path = extracted.joinpath(*PurePosixPath(name).parts)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as stream:
            stream.write(data)
    gate_path = extracted / GATE
    namespace = {"__name__": "first_basin_release_gate_v2r7"}
    exec(compile(gate_path.read_bytes(), str(gate_path), "exec"), namespace)
    gate = namespace["verify_bundle"](extracted, sha(files["bundle_manifest.json"]), enforce_remote=False)
    archive_path = long_path(DESTINATION / "full_budget_recovery_v2r7_20260927.zip")
    with zipfile.ZipFile(archive_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 9, 27, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (stat.S_IFREG | 0o640) << 16
            archive.writestr(info, data)
    if archive_path.stat().st_size > 10 * 2**20:
        raise RuntimeError("release payload exceeds mailbox limit")
    receipt = {
        "status": "FIRST_BASIN_RELEASE_BUILT_NOT_PUBLISHED",
        "source_archive_sha256": SOURCE_SHA,
        "source_manifest_sha256": SOURCE_MANIFEST_SHA,
        "candidate_deployer_sha256": CANDIDATE_DEPLOYER_SHA,
        "source_member_count": len(original),
        "new_member_count": len(files),
        "patched_source_members": sorted(PATCHED),
        "added_members": sorted(ADDED),
        "bundle_manifest_sha256": sha(files["bundle_manifest.json"]),
        "archive": record(archive_path.read_bytes()),
        "gate": gate,
        "model_calls": 0,
        "evaluation_array_reads": 0,
    }
    with long_path(DESTINATION / "bundle_build_receipt.json").open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")
    return receipt


if __name__ == "__main__":
    print(json.dumps(build(), ensure_ascii=False, sort_keys=True, indent=2))
