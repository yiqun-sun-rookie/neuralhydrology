"""No-model checks for one isolated first-basin release after job 227637."""
from __future__ import annotations

import ast
import json
from pathlib import Path
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import build_tukf09_first_basin_recovery_v2r7_20260927 as builder


@pytest.fixture
def derived(tmp_path):
    report = tmp_path / "local_pass.xml"
    report.write_text('<testsuite tests="9" failures="0" errors="0" skipped="0"/>', encoding="utf-8")
    return builder.derive_files(report)


def test_sealed_inputs_and_reviewed_candidate_are_exact():
    original, old_manifest = builder.read_sealed_source()
    candidate = builder.read_reviewed_candidate(original)
    assert builder.sha(builder.SOURCE.read_bytes()) == builder.SOURCE_SHA
    assert builder.sha(original["bundle_manifest.json"]) == builder.SOURCE_MANIFEST_SHA
    assert len(old_manifest["files"]) + 1 == len(original) == 306
    assert builder.sha(candidate) == builder.CANDIDATE_DEPLOYER_SHA
    assert builder.sha(builder.FAILURE.read_bytes()) == builder.FAILURE_SHA
    assert builder.sha(builder.LEDGER.read_bytes()) == builder.LEDGER_SHA


def test_exact_changes_and_science_bytes(derived):
    old, final, _ = derived
    changed = {name for name in old if final[name] != old[name]}
    assert changed == builder.PATCHED | {"bundle_manifest.json"}
    assert set(final) - set(old) == builder.ADDED
    for name in old:
        if name.startswith(("src/", "configs/", "input/", "results/", "artifacts/")):
            assert final[name] == old[name], name
    assert builder.sha(final["hpc/tukf09_455_scaled_noise_local_transfer_contract_v1.json"]) == builder.SCIENCE_SHA


def test_first_only_dispatch_and_historical_identity(derived):
    _, final, _ = derived
    name = "hpc/tukf09_two_basin_full_budget_deploy_v2.py"
    source = final[name].decode("utf-8")
    namespace = {"__name__": "first_only_release_test"}
    exec(compile(source, name, "exec"), namespace)
    assert namespace["SAMPLES"] == ("01047000", "01142500")
    assert namespace["EXECUTABLE_BASINS"] == ("01047000",)
    assert "for basin_id in EXECUTABLE_BASINS:" in source
    assert "if basin_id not in EXECUTABLE_BASINS:" in source
    with pytest.raises(PermissionError, match="unauthorized basin"):
        namespace["_submit_once"]("01142500", "a" * 64, "b" * 64, prerequisite=None)
    with pytest.raises(PermissionError, match="second basin"):
        namespace["submit_second"]("a" * 64, "b" * 64, "c" * 64)


def test_new_exclusive_paths_and_frozen_model_pythonpath(derived):
    old, final, _ = derived
    deploy = final["hpc/tukf09_two_basin_full_budget_deploy_v2.py"].decode("utf-8")
    slurm = final["hpc/tukf09_two_basin_full_budget_job_v2.slurm"].decode("utf-8")
    prior_slurm = old["hpc/tukf09_two_basin_full_budget_job_v2.slurm"].decode("utf-8")
    assert builder.OLD_PHASE not in deploy + slurm
    assert builder.NEW_PHASE in deploy and builder.NEW_PHASE in slurm
    assert builder.NEW_ARCHIVE in deploy
    assert f"#SBATCH --job-name={builder.NEW_NAME}" in slurm
    assert "  01047000) ;;" in slurm and "01047000|01142500" not in slurm
    assert f"export PYTHONPATH={builder.PRIVATE}" in slurm
    assert f"export PYTHONPATH={builder.PRIVATE}" in prior_slurm
    assert "bundle/vendor" not in slurm


def test_new_authorization_and_admission_are_bound(derived):
    _, final, manifest = derived
    auth = json.loads(final[builder.AUTH_PATH])
    admission = json.loads(final[builder.ADMISSION_PATH])
    gate = final["hpc/tukf09_two_basin_full_budget_gate_v2.py"].decode("utf-8")
    assert auth["failed_job_id"] == "227637"
    assert auth["failed_evidence_sha256"] == builder.FAILURE_SHA
    assert auth["source_bundle_sha256"] == builder.SOURCE_SHA
    assert auth["candidate_deployer_sha256"] == builder.CANDIDATE_DEPLOYER_SHA
    assert auth["authorized_basin_id"] == "01047000"
    assert auth["maximum_new_submissions"] == 1
    assert auth["second_basin_authorized"] is False
    assert auth["automatic_retry_or_requeue_authorized"] is False
    assert admission["recovery_authorization_sha256"] == builder.sha(final[builder.AUTH_PATH])
    assert admission["local_test_report"]["tests"] == 9
    assert admission["second_job_submission_authorized"] is False
    assert manifest["path_mapping"]["remote_root"] == builder.NEW_PHASE + "/bundle"
    assert 'RECOVERY_AUTH = "' + builder.AUTH_PATH + '"' in gate
    assert 'ADMISSION = "' + builder.ADMISSION_PATH + '"' in gate
    assert 'recovery.get("failed_job_id") != "227637"' in gate


def test_all_patched_python_is_valid(derived):
    _, final, _ = derived
    for name in builder.PATCHED:
        if name.endswith(".py"):
            ast.parse(final[name].decode("utf-8"), filename=name)


def test_complete_derived_bundle_passes_final_gate(derived, tmp_path):
    _, final, _ = derived
    bundle = builder.long_path(tmp_path / "bundle")
    bundle.mkdir()
    for name, data in final.items():
        path = bundle.joinpath(*name.split("/"))
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    gate_path = bundle / "hpc/tukf09_two_basin_full_budget_gate_v2.py"
    namespace = {"__name__": "release_gate_test"}
    exec(compile(gate_path.read_bytes(), str(gate_path), "exec"), namespace)
    result = namespace["verify_bundle"](bundle, builder.sha(final["bundle_manifest.json"]), enforce_remote=False)
    assert result["model_import_performed"] is False
    assert result["evaluation_array_reads"] == 0


def test_failed_report_is_rejected(tmp_path):
    report = tmp_path / "local_fail.xml"
    report.write_text('<testsuite tests="10" failures="1" errors="0" skipped="0"/>', encoding="utf-8")
    with pytest.raises(RuntimeError, match="not all passing"):
        builder.derive_files(report)


def test_exact_replacement_rejects_ambiguity():
    with pytest.raises(RuntimeError):
        builder.replace_once("x", "y", "z")
    with pytest.raises(RuntimeError):
        builder.replace_once("y y", "y", "z")
