# First-basin single-submit release Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking. Neither execution sub-skill is installed here; execute inline with the same review gates. Independent review is required before publication.

**Goal:** Derive, fully verify, independently audit, and submit one isolated full-budget technical rehearsal for basin `01047000` after the failed job 227637.

**Architecture:** Use the sealed v2r6 archive plus the independently reviewed v2r7 identity-only deployer as immutable inputs. Change only technical release identity/path/authorization members, rebuild a complete manifest in a new exclusive release root, test the exact final archive bytes, then publish one mailbox command that can submit only the first basin once. Preserve all old packages and receipts.

**Tech Stack:** Python 3.11, ZIP, pytest 8.3.5, PowerShell, GitHub mailbox API, Slurm on the existing `hcpu48y` partition.

## Global Constraints

- Fresh user authority: “允许只为首个流域新提交一次” (2026-09-27). It supersedes the previous no-resubmit decision **only for one new job for `01047000`**. No automatic retry, requeue, second-basin execution, 455-basin formal run, or scientific-contract change.
- Sealed source: `results/tukf09_455_scaled_noise_local_transfer_v1/control/two_basin_full_budget_hpc_v2/recovery_v2r6/bundle/full_budget_recovery_v2r6.zip`, SHA-256 `c44a5cda5cb19cc0736c60442476110fe86cf7237f57c013e3d280b35ba8ce7a`; its manifest SHA-256 is `72329a2a38c1616513fbd1ca97d6abcb7c4d665c45040d0fbf6e9d0d9b4feb5e`.
- Failed-job receipt: `results/tukf09_455_scaled_noise_local_transfer_v1/control/two_basin_full_budget_hpc_v2/recovery_v2r6_failure_evidence_seq21_receipt.txt`, SHA-256 `4f63b9d065c2d2a2bf123528b2a10fb4d7d3e6ca05fad01bdb8cb8a15310250b`; job 227637 failed before model start. The `recovery_v2r7_candidate` ledger SHA-256 is `e1a406540b44512d48323909dea42e3947a02ad430c19fe5a89d6a8687a5dca6` and its reviewed deployer SHA-256 is `0f3853353f385276343b977367ea4650ad1a094d06847fcd8c714570ebdf065b`.
- New local output root: `results/tukf09_455_scaled_noise_local_transfer_v1/control/two_basin_full_budget_hpc_v2/recovery_v2r7_release_20260927/` (absent at preflight). New remote phase: `/data1/home/sunyiq/kalmannet_tukf09_scaled_noise_rehearsal_20260922/full_budget_recovery_v2r7_20260927`. New mailbox payload: `inbox/kalmannet-tukf09-noise-20260922/payload/full_budget_recovery_v2r7_20260927.zip`. These are exclusive; any collision is STOP.
- Writable local files are new files under `hpc/` top-level, `docs/plans/`, and the new release root. Old evidence/archive/candidate and all scientific sources, data, configs, original tests and evaluation outputs remain read-only. No deletion.
- Scientific contract, two-basin planned identity, model, basin list, periods, seeds, budget, noise method, mask, metrics, thresholds, and decision order remain unchanged. The recovery runs only `01047000`; `01142500` remains inert.
- The mailbox channel is `kalmannet-tukf09-noise-20260922`. Live read-only API snapshot at 2026-09-27 showed `seq=21` and exact complete `result_21.txt` (22,790 bytes, SHA-256 equal to the failed-job receipt). Every later publication must re-read the live head and channel sequence; do not assume `22` or `23` remains free.

---

### Task 1: Build a release generator and first-only regression tests

**Files:**
- Create: `hpc/build_tukf09_first_basin_recovery_v2r7_20260927.py`
- Create: `hpc/test_tukf09_first_basin_recovery_v2r7_20260927.py`
- Create: `hpc/tukf09_first_basin_recovery_authorization_v2r7_20260927.json`

**Interfaces:**
- Consumes: sealed v2r6 archive, candidate deployer, old v2r6 implementation admission, and the new one-time authorization.
- Produces: `derive_files(report_path: Path)` returning `(old_members, final_members, manifest)`; `build()` writes exclusively to the new release root.

- [x] Write tests first. Assert old archive/manifest, candidate ledger/deployer, failed receipt, and scientific-contract hashes; assert exact changed/added member sets. Check `SAMPLES=("01047000","01142500")`, `EXECUTABLE_BASINS=("01047000",)`, direct second-basin rejection before side effects, first-only initialization, first-only Slurm case, unique release paths/name, and unchanged model `PYTHONPATH`. The initial targeted run failed at collection with `ModuleNotFoundError` for the not-yet-written generator, as expected.
- [x] Implement the minimal generator using exact-once replacements and syntax checks. The final gate binds the **new** authorization to failed job `227637`, a new admission schema/path, the exact new remote phase, and one authorized basin. The admission binds each changed technical source and a passing local report; the manifest binds every final member. Existing output destinations, symlinks, duplicate/unsafe ZIP members, unexpected changes, and report failures are rejected.
- [x] Run focused tests until all pass, with a unique short temporary directory inside the new release root. The trial run passed 9/9. The original 41, 44, and 14 tests were not modified.

### Task 2: Create and verify the final archive bytes

**Files:**
- Create generated files only under `results/tukf09_455_scaled_noise_local_transfer_v1/control/two_basin_full_budget_hpc_v2/recovery_v2r7_release_20260927/`

**Interfaces:**
- Consumes: Task 1 generator and passing focused report.
- Produces: an exclusive ZIP, extracted final bytes, build receipt, and machine-readable test receipts.

- [ ] Build the archive once, verify its full manifest with the **final gate**, and independently compare member names/digests with both source archive and candidate. Confirm no scientific member changed and no second-basin directory is created locally.
- [ ] Re-extract the ZIP into a new verification directory and run the original 41 Linux protection checks, original 44 non-tensor checks, original 14 synthetic tensor checks, and new focused isolation checks **against that extraction**. Save counts, full test names, module import paths, and SHA-256 of each report. A Windows pass alone does not replace Linux checks; do not invoke the real model.
- [ ] Verify the final archive's embedded admission, authorization, paths, first-only Slurm script, manifest, and external test receipts. Any mismatch is STOP; preserve the failed attempt and use another exclusive release name rather than overwriting it.

### Task 3: Independent final-release audit

**Files:**
- Create: `docs/plans/2026-09-27-tukf09-first-basin-single-submit-release-review.md`

**Interfaces:**
- Consumes: the exact final archive/extraction, complete reports, source/candidate hashes, and proposed mailbox command.
- Produces: explicit GO/STOP for this one submission, not a scientific result.

- [ ] Have a separate reviewer reconstruct all changed and added members, verify the four execution barriers (`initialize_and_submit_first`, `_submit_once`, `submit_second`, Slurm), match every test report to the final archive, and check that the remote path/job name/mailbox command cannot touch older runs. Record findings and close all important/critical issues before proceeding.

### Task 4: One exclusive mailbox publication and one possible Slurm submission

**Files:**
- Create new publication/command/admission/status files in `hpc/` top-level and the new release root only.

**Interfaces:**
- Consumes: Task 3 GO and fresh GitHub channel/head snapshot.
- Produces: one immutable publication attempt, one complete mailbox result, and (only if accepted) one numeric Slurm job ID.

- [ ] Publish a short **read-only** remote preflight first: confirm parent directory, unused exact new phase path and job name, no second-basin path, current partition/runtime availability, and no competing same-stage job. Wait for a complete receipt; do not restart or repeat it on an observation timeout.
- [ ] Build a one-time publication admission binding exact payload/command/publisher hashes and the immediately previous complete channel receipt. The submission command must preflight archive SHA-256, manifest SHA-256, authorization, exclusive remote phase, and first-only deployer, then call only `--first` once. It must never fall back to `--second` or retry `sbatch`.
- [ ] Re-read live mailbox head, sequence, and previous receipt. Publish the exact payload and command to the same channel using an atomic non-force ref update, with an exclusive local attempt record written **before** network mutation. On any ambiguous outcome, read back remote state and stop rather than republish blindly.
- [ ] Accept “submitted” only if the returned mailbox receipt is complete and contains one exact `Submitted batch job <number>` line, with matching `submission.json`/queue record. Preserve this job ID and immediately report it; `RUNNING` alone is not model start.

### Task 5: Observe the authorized first-basin run

**Files:**
- Create any new read-only status/evidence receipts only under the new release root and `hpc/` top-level.

**Interfaces:**
- Consumes: Task 4's one numeric job ID.
- Produces: a bounded, evidence-backed state assessment: submitted, model started, terminal technical state, and scientific result availability kept separate.

- [ ] Check the exact job ID and its own phase/log/`started.json` via read-only mailbox commands. Never requeue, retry, cancel, or submit the second basin. If the job fails, preserve evidence and stop; if it is still running, report the verified state and continue monitoring by the authorized mechanism.

## Self-review

The plan covers the one-basin authorization, immutable science, exclusive outputs, final-byte test scope, independent audit, single mailbox publication, one `sbatch`, and no automatic recovery. It deliberately does not authorize a second basin or any noise-selection redesign.
