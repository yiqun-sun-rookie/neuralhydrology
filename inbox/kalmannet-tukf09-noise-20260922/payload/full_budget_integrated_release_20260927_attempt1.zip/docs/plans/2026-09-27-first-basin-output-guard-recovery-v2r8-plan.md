# First-Basin Output-Guard Recovery Implementation Plan

> **For agentic workers:** Execute the checked steps in this session. The user has already authorized one new isolated package and, only after acceptance, one submission for basin `01047000`. No second-basin submission or automatic retry is authorized.

**Goal:** Run the unchanged full-budget experiment for basin `01047000` on the supercomputer using the locally repaired final-output guard, and verify that the model actually completes.

**Architecture:** Derive a new immutable package from the sealed release whose job `228078` failed before model start. Change only the technical output guard and the release, authorization, and pre-model checks needed to bind it to a fresh path. Keep the scientific contract and all scientific inputs byte-identical; publish through the existing task-specific supercomputer mailbox only after exact-byte local acceptance.

**Tech Stack:** Python 3, bundled pytest 8.3.5, ZIP with SHA-256 manifest, Slurm, existing `kalmannet-tukf09-noise-20260922` mailbox.

## Global Constraints

- Source package: `results/tukf09_455_scaled_noise_local_transfer_v1/control/two_basin_full_budget_hpc_v2/recovery_v2r7_release_20260927/bundle/full_budget_recovery_v2r7_20260927.zip`, SHA-256 `41b81765600449683b2dc158de1bd110b7a2e77b5c1c532073ae4da87f2ea697`; never edit it or its receipts.
- Source manifest SHA-256: `d1806b57a4b42d9b63269da7d04eef0b1ac3e8b51710ea6412db869b1aa1a79d`. Failed-job evidence: `failure_evidence_seq25_receipt.txt`, SHA-256 `73c2bc03e2f0385687b3fe04ec94093e998e9b9ed9de685b486e9dd23b75d9fd`.
- Scientific contract SHA-256 remains `27239212680bd370bd76f40e53337b7d68d80cbe4dc01feac2164bab4917f8a1`; no change to data, model, seeds, periods, training budget, scoring, thresholds, or decision order.
- Contract sample identities remain `("01047000", "01142500")`, but executable-basin set and Slurm argument guard remain `("01047000",)` only. Formal evaluation and automatic requeue remain prohibited.
- The first local candidate `recovery_v2r8_release_20260927` is retained: its final-byte standard-library preflight failed 1/44 because the old synthetic passing record lacked the new three-test field. It was never published or submitted. The new candidate root is `results/tukf09_455_scaled_noise_local_transfer_v1/control/two_basin_full_budget_hpc_v2/recovery_v2r8_release_20260927_attempt2`; the still-unused remote phase is `/data1/home/sunyiq/kalmannet_tukf09_scaled_noise_rehearsal_20260922/full_budget_recovery_v2r8_20260927`. Both the new local root and remote phase must be absent before creation, with no symlink ancestor.
- One submission attempt consumes the new permission. An ambiguous submission or failed job stops work; it does not trigger a second submission.
- Allowed repository writes: new files in `hpc/`, `docs/plans/`, and the new isolated result root. Other repository paths and all older releases remain read-only.

---

### Task 1: Freeze authority and the release delta

**Files:**
- Create: `hpc/tukf09_first_basin_recovery_authorization_v2r8_20260927.json`
- Create: `hpc/build_tukf09_first_basin_recovery_v2r8_20260927.py`
- Create: `hpc/test_tukf09_first_basin_recovery_v2r8_20260927.py`
- Read only: the sealed source ZIP, failed-job receipt, current repaired supervisor, and the three-source-file `combined_002.xml` report.

**Interfaces:** The builder exposes `derive_files(report_path: Path) -> tuple[dict[str, bytes], dict[str, bytes], dict]` and `build() -> dict`; the tests verify the exact changed-member set, single-basin dispatch, hashes, and rejection of altered authority or failed test reports.

- [ ] **Step 1:** Verify all four source SHA-256 values and that the new local release root is absent. Expected: exact hashes above plus repaired supervisor `4daed58001f95c474b633191454b1a664dce2596e676d4f701188c9c2b240e83`.
- [ ] **Step 2:** Save the user’s 2026-09-27 authorization as one consumable first-basin attempt bound to failed job `228078`, old package/manifest/failure hashes, new remote phase, and unchanged science hash. Set second basin, formal evaluation, contract changes, and automatic retry to `false`.
- [ ] **Step 3:** Write the builder and negative tests so an old or modified source file, pre-existing destination, changed science member, wrong job identity, or failing local report is rejected before package creation.
- [ ] **Step 4:** Run the new builder test module against synthetic temporary reports with bytecode and external pytest plugins disabled. Expected: zero failures and no hydrology-model import.

### Task 2: Assemble and locally accept the exact package

**Files:**
- Build into: `results/tukf09_455_scaled_noise_local_transfer_v1/control/two_basin_full_budget_hpc_v2/recovery_v2r8_release_20260927/bundle/`
- Package changes: `hpc/tukf09_two_basin_hpc_supervisor_v1.py`, `hpc/tukf09_two_basin_full_budget_gate_v2.py`, `hpc/tukf09_two_basin_full_budget_deploy_v2.py`, `hpc/tukf09_two_basin_full_budget_job_gate_v2.py`, `hpc/tukf09_two_basin_full_budget_job_v2.slurm`, the old 44-test suite's synthetic passing-record fixture only, new authorization/admission/builder/tests, and `bundle_manifest.json`.
- Preserve byte-exact: every `src/`, `configs/`, `input/`, `results/`, and `artifacts/` source member except the new technical test receipt under `input/`.

**Interfaces:** `verify_bundle(extracted_root, manifest_sha, enforce_remote=False)` must validate every member and return `model_import_performed=false` and `evaluation_array_reads=0`. The job gate runs the original 41 protection tests, the new 3 final-output regressions separately, 44 existing non-tensor checks, and 14 synthetic tensor checks before the model.

- [ ] **Step 1:** Generate the local builder test report, run `derive_files`, and inspect the exact changed and added member lists. Expected: no scientific member changed and no second-basin execution path opened.
- [ ] **Step 2:** Build the package once in the absent isolated root; verify archive SHA-256, manifest SHA-256, member count, and exact extracted-member hashes independently of the builder.
- [ ] **Step 3:** Run the original 41 tests and new 3 regressions against the final extracted bytes; run the 44 non-tensor checks with the corrected synthetic passing record and the 14 synthetic tensor checks. Expected: `41/41`, `3/3`, `44/44`, and `14/14`, with report hashes saved in the new root.
- [ ] **Step 4:** Execute the packaged verifier on the final extracted bytes and inspect the packaged Slurm/deployer paths, job name, runtime, and single-basin guard. If any gate fails, stop before publication.

### Task 3: Publish once, then prove model completion

**Files:**
- Remote: the new phase above and a unique payload path in the existing task-specific mailbox.
- Local receipts: only under the new isolated release root.

**Interfaces:** The deployer’s `initialize_and_submit_first(archive_sha, manifest_sha)` may run once only after preflight. Success requires the exact text `Submitted batch job <number>`; a successful command exit without this text is not submission evidence.

- [ ] **Step 1:** Through read-only mailbox commands, verify the remote phase and new payload path do not exist, inspect the channel sequence/last receipt, resource state, and competing work. Do not edit another channel.
- [ ] **Step 2:** Publish the accepted archive under a unique path, compare its remote SHA-256 with the local archive, and retain the publication receipt.
- [ ] **Step 3:** Issue one deploy-and-submit command for `01047000`; save the exact command receipt and job number. Never rerun that command after an ambiguous or failed response.
- [ ] **Step 4:** Follow that job without resubmission. Require Slurm `COMPLETED 0:0`, all four pre-model test groups passing, a model-start receipt, successful supervisor status, final result manifest, and independent exact-file audit before reporting successful execution. If any condition fails, preserve evidence and stop without retry.

## Self-review

- The plan keeps science members byte-identical and changes only technical release and guard files.
- The new three-test check is separate from the frozen 41-test count.
- One submitted job is the maximum; second basin and formal evaluation remain excluded.
- No placeholder step or unapproved path is needed to execute the plan.
