"""Build one exclusive full-budget payload from the sealed successful short-probe bundle."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
CONTROL = ROOT / "results/tukf09_455_scaled_noise_local_transfer_v1/control/two_basin_full_budget_hpc_v2"
BASE_ARCHIVE = ROOT / "results/tukf09_455_scaled_noise_local_transfer_v1/control/two_basin_hpc_start_v2/ready/narrow_probe_v2.zip"
BASE_ARCHIVE_SHA = "026c5a0ba6dafcbf84bf8ce4a1a97ad849032b354379a171c10b274733b435ca"
BASE_MANIFEST_SHA = "cb560e388dae4ee9817d1f72dd7126ba3a78dba956d7575fd9cf2fc699393302"
DESTINATION = CONTROL / "bundle_v2r4"
EXTRACTED = DESTINATION / "extracted"
ARCHIVE = DESTINATION / "full_budget_v2r4.zip"
STAGE = "TUKF09_455_TWO_BASIN_FULL_BUDGET_HPC_REHEARSAL_V2"
REMOTE_ROOT = "/data1/home/sunyiq/kalmannet_tukf09_scaled_noise_rehearsal_20260922/full_budget_v2/bundle"
MANIFEST = "bundle_manifest.json"
ADMISSION = "hpc/tukf09_two_basin_full_budget_implementation_admission_v2r4.json"
LOCAL_TEST_REPORT = "input/full_budget_v2r4/local_tests_final_008.xml"
ADDED_LOCAL_FILES = {
    "hpc/tukf09_two_basin_full_budget_gate_v2.py": ROOT / "hpc/tukf09_two_basin_full_budget_gate_v2.py",
    "hpc/verify_tukf09_two_basin_full_budget_v2.py": ROOT / "hpc/verify_tukf09_two_basin_full_budget_v2.py",
    "hpc/run_tukf09_two_basin_full_budget_v2.py": ROOT / "hpc/run_tukf09_two_basin_full_budget_v2.py",
    "hpc/test_tukf09_two_basin_full_budget_v2.py": ROOT / "hpc/test_tukf09_two_basin_full_budget_v2.py",
    "hpc/tukf09_two_basin_full_budget_job_gate_v2.py": ROOT / "hpc/tukf09_two_basin_full_budget_job_gate_v2.py",
    "hpc/tukf09_two_basin_full_budget_job_v2.slurm": ROOT / "hpc/tukf09_two_basin_full_budget_job_v2.slurm",
    "hpc/tukf09_two_basin_full_budget_deploy_v2.py": ROOT / "hpc/tukf09_two_basin_full_budget_deploy_v2.py",
    "hpc/build_tukf09_two_basin_full_budget_bundle_v2.py": ROOT / "hpc/build_tukf09_two_basin_full_budget_bundle_v2.py",
    "hpc/tukf09_two_basin_full_budget_execution_authorization_v2.json": ROOT / "hpc/tukf09_two_basin_full_budget_execution_authorization_v2.json",
    ADMISSION: ROOT / ADMISSION,
    "docs/plans/2026-09-23-tukf09-two-basin-full-budget-final-gate-review-v1.md": ROOT / "docs/plans/2026-09-23-tukf09-two-basin-full-budget-final-gate-review-v1.md",
    "input/full_budget_v2r4/short_probe_array_audit.json": CONTROL / "short_probe_array_audit.json",
    "input/full_budget_v2r4/resource_query_seq13.txt": CONTROL / "resource_query_seq13.txt",
    LOCAL_TEST_REPORT: CONTROL / "implementation_v2r4/local_tests_final_008.xml",
}


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _record(data: bytes) -> dict:
    return {"sha256": _sha(data), "size_bytes": len(data)}


def _json_bytes(value: dict) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")


def _long(path: Path) -> Path:
    resolved = path.resolve()
    return Path("\\\\?\\" + str(resolved)) if sys.platform == "win32" else resolved


def _safe_name(name: str) -> None:
    value = PurePosixPath(name)
    if (
        not name
        or name != value.as_posix()
        or value.is_absolute()
        or ".." in value.parts
        or ":" in name
        or "\\" in name
        or name.startswith("./")
    ):
        raise ValueError("unsafe archive member: " + name)


def _archive_files(archive: zipfile.ZipFile) -> dict[str, bytes]:
    files = {}
    for member in archive.infolist():
        _safe_name(member.filename)
        mode = member.external_attr >> 16
        if member.is_dir() or stat.S_IFMT(mode) not in (0, stat.S_IFREG):
            raise ValueError("non-regular archive member: " + member.filename)
        if member.filename in files:
            raise ValueError("duplicate archive member: " + member.filename)
        files[member.filename] = archive.read(member)
    return files


def _verify_base(files: dict[str, bytes]) -> dict:
    if MANIFEST not in files or _sha(files[MANIFEST]) != BASE_MANIFEST_SHA:
        raise RuntimeError("sealed short-probe bundle manifest changed")
    manifest = json.loads(files[MANIFEST])
    records = manifest.get("files")
    if not isinstance(records, dict) or set(records) | {MANIFEST} != set(files):
        raise RuntimeError("sealed short-probe bundle member set changed")
    for name, expected in records.items():
        if _record(files[name]) != expected:
            raise RuntimeError("sealed short-probe member changed: " + name)
    return manifest


def _verify_admission(files: dict[str, bytes]) -> None:
    admission = json.loads(files[ADMISSION])
    if admission.get("stage_id") != STAGE or admission.get("status") != "IMPLEMENTATION_AND_TESTS_ADMITTED_FOR_SERIAL_CHAIN_WITH_FIRST_JOB_GATE":
        raise RuntimeError("implementation admission status changed")
    implementation = admission.get("implementation_files")
    if not isinstance(implementation, dict) or set(implementation) != {
        name for name in ADDED_LOCAL_FILES if name.startswith("hpc/") and name not in {
            "hpc/tukf09_two_basin_full_budget_execution_authorization_v2.json",
            ADMISSION,
        }
    }:
        raise RuntimeError("implementation admission member set changed")
    for name, expected in implementation.items():
        if _record(files[name]) != expected:
            raise RuntimeError("admitted implementation changed before build: " + name)
    report = admission.get("local_test_report")
    if report.get("path") != LOCAL_TEST_REPORT or _record(files[LOCAL_TEST_REPORT]) != {
        "sha256": report.get("sha256"),
        "size_bytes": report.get("size_bytes"),
    }:
        raise RuntimeError("admitted local test report changed before build")
    if (report.get("tests"), report.get("failures"), report.get("errors"), report.get("skipped")) != (58, 0, 0, 0):
        raise RuntimeError("local test outcome is not the admitted all-pass result")


def build() -> None:
    if DESTINATION.exists() or DESTINATION.is_symlink():
        raise FileExistsError("full-budget bundle destination already exists")
    if _sha(BASE_ARCHIVE.read_bytes()) != BASE_ARCHIVE_SHA:
        raise RuntimeError("sealed successful short-probe archive changed")
    with zipfile.ZipFile(BASE_ARCHIVE) as source:
        files = _archive_files(source)
    base_manifest = _verify_base(files)
    base_members = set(files)
    for name, source in ADDED_LOCAL_FILES.items():
        _safe_name(name)
        if name in files and name != MANIFEST:
            raise RuntimeError("new full-budget member collides with sealed short-probe member: " + name)
        if not source.is_file() or source.is_symlink():
            raise RuntimeError("new bundle source is absent or linked: " + str(source))
        files[name] = source.read_bytes()
    _verify_admission(files)
    manifest = {
        "schema_version": "tukf09_two_basin_full_budget_bundle_manifest_v2",
        "stage_id": STAGE,
        "path_mapping": {
            "windows_root": "G:\\github\\pycharm\\projects\\kalmannet",
            "remote_root": REMOTE_ROOT,
        },
        "base_short_probe_archive": {
            "sha256": BASE_ARCHIVE_SHA,
            "manifest_sha256": BASE_MANIFEST_SHA,
            "stage_id": base_manifest["stage_id"],
            "member_count": len(base_members),
        },
        "files": {name: _record(content) for name, content in sorted(files.items()) if name != MANIFEST},
    }
    files[MANIFEST] = _json_bytes(manifest)
    manifest_sha = _sha(files[MANIFEST])

    extracted = _long(EXTRACTED)
    extracted.mkdir(parents=True, exist_ok=False)
    for name, content in sorted(files.items()):
        target = extracted.joinpath(*PurePosixPath(name).parts)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(content)
    gate_path = extracted / "hpc/tukf09_two_basin_full_budget_gate_v2.py"
    namespace = {"__name__": "full_budget_gate_built_v2"}
    exec(compile(gate_path.read_bytes(), str(gate_path), "exec"), namespace)
    gate = namespace["verify_bundle"](extracted, manifest_sha, enforce_remote=False)

    archive_path = _long(ARCHIVE)
    with zipfile.ZipFile(archive_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, content in sorted(files.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 9, 23, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (stat.S_IFREG | 0o640) << 16
            archive.writestr(info, content)
    archive_bytes = archive_path.read_bytes()
    if len(archive_bytes) > 10 * 2**20:
        raise RuntimeError("full-budget payload exceeds mailbox size limit")
    receipt = {
        "status": "FULL_BUDGET_BUNDLE_V2R4_BUILT_NOT_PUBLISHED",
        "base_archive_sha256": BASE_ARCHIVE_SHA,
        "base_member_count": len(base_members),
        "full_member_count": len(files),
        "added_member_count": len(set(files) - base_members),
        "bundle_manifest_sha256": manifest_sha,
        "archive": _record(archive_bytes),
        "gate": gate,
        "model_calls": 0,
        "evaluation_array_reads": 0,
    }
    with (_long(DESTINATION / "bundle_build_receipt.json")).open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")
    print(json.dumps(receipt, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    build()
