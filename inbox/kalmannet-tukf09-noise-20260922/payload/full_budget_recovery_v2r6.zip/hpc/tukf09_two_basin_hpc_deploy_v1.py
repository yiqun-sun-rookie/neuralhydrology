"""Lightweight, exclusive extraction and one scheduler submission; no model here."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import sys
import zipfile

PHASE = Path('/data1/home/sunyiq/kalmannet_tukf09_scaled_noise_rehearsal_20260922/narrow_probe_v2')
ARCHIVE = Path('/data1/home/sunyiq/hpc_mailbox/inbox/kalmannet-tukf09-noise-20260922/payload/narrow_probe_v2.zip')

def deploy(archive_sha, manifest_sha):
    if not all(len(s)==64 and set(s)<=set('0123456789abcdef') for s in (archive_sha,manifest_sha)):
        raise ValueError('invalid fingerprints')
    if PHASE.exists() or PHASE.is_symlink() or PHASE.parent.resolve() != PHASE.parent:
        raise FileExistsError('phase already exists or ancestor is linked')
    if not PHASE.parent.is_dir() or ARCHIVE.is_symlink() or ARCHIVE.stat().st_size > 10*2**20:
        raise RuntimeError('unexpected parent/archive')
    if hashlib.file_digest(ARCHIVE.open('rb'),'sha256').hexdigest() != archive_sha:
        raise RuntimeError('payload fingerprint changed')
    queue = subprocess.run(['squeue','-u','sunyiq','-h','-o','%i|%j|%T|%R'],check=True,text=True,capture_output=True).stdout
    if any('|tukf09-noise-2probe-v2|' in line for line in queue.splitlines()):
        raise RuntimeError('same named active job already exists')
    PHASE.mkdir(mode=0o750,exist_ok=False)
    for name in ('bundle','control','logs','tmp','cache'):
        (PHASE/name).mkdir(mode=0o750)
    (PHASE/'control/queue_before.txt').write_text(queue)
    with zipfile.ZipFile(ARCHIVE) as archive:
        members = archive.infolist()
        names = [member.filename for member in members]
        if len(names)!=len(set(names)) or sum(m.file_size for m in members)>32*2**20:
            raise RuntimeError('invalid payload membership/size')
        for member in members:
            relative = PurePosixPath(member.filename)
            mode = member.external_attr >> 16
            if (relative.is_absolute() or '..' in relative.parts or ':' in member.filename
                    or '\\' in member.filename or relative.as_posix()!=member.filename
                    or member.is_dir() or stat.S_ISLNK(mode)):
                raise RuntimeError('unsafe archive member')
            destination = PHASE/'bundle'/relative
            destination.parent.mkdir(parents=True,exist_ok=True)
            with destination.open('xb') as stream:
                stream.write(archive.read(member))
    sys.path.insert(0,str(PHASE/'bundle/hpc'))
    from tukf09_two_basin_hpc_gate_v1 import verify_bundle
    gate = verify_bundle(PHASE/'bundle',manifest_sha)
    with (PHASE/'control/deployed.json').open('x') as stream:
        json.dump({'archive_sha256':archive_sha,'gate':gate,'model_calls':0},stream)
    environment = dict(os.environ,TUKF09_BUNDLE_SHA256=manifest_sha)
    vendor = PHASE/'bundle/vendor'
    python = '/data1/home/sunyiq/miniconda3/envs/knet_clean/bin/python'
    check = r"""import importlib, importlib.metadata as md, pathlib
vendor=pathlib.Path(__VENDOR__).resolve()
for name, version in __PINS_IN_CODE__.items():
    module=importlib.import_module(name)
    actual=md.version(name)
    source=pathlib.Path(module.__file__).resolve()
    if actual != version or not source.is_relative_to(vendor):
        raise RuntimeError('dependency mismatch: %s %s %s' % (name, actual, source))
print('PRE_SUBMIT_TEST_DEPENDENCIES_OK', flush=True)
""".replace('__VENDOR__', repr(str(vendor))).replace('__PINS_IN_CODE__', "{'pytest': '8.3.5', 'iniconfig': '2.0.0', 'packaging': '24.2', 'pluggy': '1.5.0', 'colorama': '0.4.6'}")
    check_env = dict(os.environ, PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1',
                     PYTHONPATH=str(vendor) + ':' + '/data1/home/sunyiq/kalmannet_tukf09_455_basin_zero_validation_target_variance_revision_v1_a800_exclusive_v2r14_20260909/runtime_v2r14/pysite')
    checked = subprocess.run([python, '-B', '-c', check], env=check_env,
                             text=True, capture_output=True, timeout=30, check=True)
    print(checked.stdout, flush=True)
    result = subprocess.run(['sbatch',str(PHASE/'bundle/hpc/tukf09_two_basin_hpc_job_v1.slurm')],
                            env=environment,text=True,capture_output=True)
    with (PHASE/'control/submission.json').open('x') as stream:
        json.dump({'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr},stream)
    print(result.stdout,flush=True)
    print(result.stderr,file=sys.stderr,flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
    import re
    if not re.fullmatch(r'Submitted batch job [0-9]+\s*',result.stdout):
        raise RuntimeError('ambiguous submission, do not retry')

if __name__=='__main__':
    if len(sys.argv)!=3:
        raise SystemExit('requires archive and manifest digests')
    deploy(*sys.argv[1:])
