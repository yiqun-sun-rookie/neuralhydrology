"""No-model regression checks for the isolated first-basin technical recovery."""
from __future__ import annotations

import ast
import json
import os
from pathlib import Path
import subprocess
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import build_tukf09_first_basin_recovery_v2r6 as builder


@pytest.fixture(scope="module")
def source_files():
    return builder._read_source()


@pytest.fixture
def derived(tmp_path, monkeypatch):
    report = tmp_path / "all_pass.xml"
    report.write_text('<testsuite tests="8" failures="0" errors="0" skipped="0"/>', encoding="utf-8")
    monkeypatch.setattr(builder, "REPORT", report)
    return builder.derive_files()


def test_old_archive_and_manifest_are_exactly_sealed(source_files):
    files, manifest = source_files
    assert builder.sha(builder.SOURCE.read_bytes()) == builder.SOURCE_SHA
    assert builder.sha(files["bundle_manifest.json"]) == builder.SOURCE_MANIFEST_SHA
    assert len(manifest["files"]) + 1 == len(files)


def test_single_replacement_rejects_absent_and_ambiguous_text():
    with pytest.raises(RuntimeError):
        builder.replace_once("alpha", "beta", "gamma")
    with pytest.raises(RuntimeError):
        builder.replace_once("beta beta", "beta", "gamma")


def test_only_four_old_technical_members_change(derived):
    original, files, _ = derived
    changed = {name for name in original if files[name] != original[name]}
    assert changed == builder.PATCHED | {"bundle_manifest.json"}
    assert set(files) - set(original) == builder.ADDED


def test_scientific_sources_and_inputs_are_byte_identical(derived):
    original, files, _ = derived
    for name in original:
        if name.startswith(("src/", "configs/", "input/", "results/", "artifacts/")):
            assert files[name] == original[name], name
    assert builder.sha(files["hpc/tukf09_455_scaled_noise_local_transfer_contract_v1.json"]) == "27239212680bd370bd76f40e53337b7d68d80cbe4dc01feac2164bab4917f8a1"


def test_slurm_keeps_model_python_path_unchanged_and_allows_one_basin(derived, source_files):
    _, files, _ = derived
    old, _ = source_files
    script = files["hpc/tukf09_two_basin_full_budget_job_v2.slurm"].decode("utf-8")
    old_script = old["hpc/tukf09_two_basin_full_budget_job_v2.slurm"].decode("utf-8")
    assert builder.OLD_PHASE not in script
    assert f"#SBATCH --job-name={builder.NEW_NAME}" in script
    assert "  01047000) ;;" in script
    assert "01047000|01142500" not in script
    expected_path = f"export PYTHONPATH={builder.PRIVATE}"
    assert expected_path in script
    assert expected_path in old_script
    assert "bundle/vendor" not in script
    assert script.count("export PYTHONPATH=") == 1


def test_only_tensor_supervised_child_gets_vendor_and_parent_is_restored(derived, tmp_path):
    _, files, _ = derived
    source = files["hpc/tukf09_two_basin_full_budget_job_gate_v2.py"].decode("utf-8")
    assert "supervised = _run_with_test_pythonpath(" in source
    namespace = {"__name__": "recovery_job_gate_test"}
    exec(compile(source, "recovery_job_gate_test.py", "exec"), namespace)
    vendor = builder.CONTROL / "bundle_v2r4/extracted/vendor"
    old_path = os.environ.get("PYTHONPATH")
    seen = []

    def inherited_child(command, output_dir, **limits):
        seen.append(os.environ.get("PYTHONPATH"))
        result = subprocess.run(command, text=True, capture_output=True, timeout=30)
        assert result.returncode == 0, result.stderr
        assert Path(result.stdout.strip()).is_relative_to(vendor.resolve())
        return {"success": True}

    code = "import pathlib,pytest; print(pathlib.Path(pytest.__file__).resolve())"
    command = [sys.executable, "-S", "-B", "-c", code]
    result = namespace["_run_with_test_pythonpath"](
        inherited_child, command, tmp_path, environment={"PYTHONPATH": str(vendor)}, wall_seconds=30
    )
    assert result == {"success": True}
    assert seen == [str(vendor)]
    assert os.environ.get("PYTHONPATH") == old_path

    def failing_child(command, output_dir, **limits):
        raise RuntimeError("synthetic failure")

    with pytest.raises(RuntimeError, match="synthetic failure"):
        namespace["_run_with_test_pythonpath"](
            failing_child, command, tmp_path, environment={"PYTHONPATH": str(vendor)}
        )
    assert os.environ.get("PYTHONPATH") == old_path


def test_second_basin_is_rejected_before_any_side_effect(derived):
    _, files, _ = derived
    source = files["hpc/tukf09_two_basin_full_budget_deploy_v2.py"].decode("utf-8")
    namespace = {"__name__": "recovery_deploy_test"}
    exec(compile(source, "recovery_deploy_test.py", "exec"), namespace)
    assert namespace["SAMPLES"] == ("01047000",)
    with pytest.raises(PermissionError, match="second basin"):
        namespace["submit_second"]("a" * 64, "b" * 64, "c" * 64)
    with pytest.raises(PermissionError, match="unauthorized basin"):
        namespace["_submit_once"]("01142500", "a" * 64, "b" * 64, prerequisite=None)


def test_recovery_gate_rejects_wrong_authorization_and_binds_hash(derived):
    _, files, _ = derived
    gate = files["hpc/tukf09_two_basin_full_budget_gate_v2.py"].decode("utf-8")
    assert 'RECOVERY_AUTH = "' + builder.AUTH_PATH + '"' in gate
    assert 'admission.get("recovery_authorization_sha256") != digest(root / RECOVERY_AUTH)' in gate
    assert 'recovery.get("authorized_basin_id") != "01047000"' in gate
    assert 'recovery.get("second_basin_authorized") is not False' in gate


def test_patched_python_is_syntactically_valid(derived):
    _, files, _ = derived
    for name in builder.PATCHED:
        if name.endswith(".py"):
            ast.parse(files[name].decode("utf-8"), filename=name)


def test_bundled_pytest_is_importable_without_user_site():
    vendor = builder.CONTROL / "bundle_v2r4/extracted/vendor"
    environment = dict(os.environ, PYTHONNOUSERSITE="1", PYTHONPATH=str(vendor))
    code = "import pathlib,pytest,sys; print(pathlib.Path(pytest.__file__).resolve())"
    result = subprocess.run([sys.executable, "-S", "-B", "-c", code], env=environment, text=True, capture_output=True, timeout=30)
    assert result.returncode == 0, result.stderr
    assert Path(result.stdout.strip()).is_relative_to(vendor.resolve())


def test_new_manifest_and_admission_bind_local_test_report(derived):
    _, files, manifest = derived
    admission = json.loads(files[builder.ADMISSION_PATH])
    assert manifest["path_mapping"]["remote_root"] == builder.NEW_PHASE + "/bundle"
    assert admission["local_test_report"]["tests"] == 8
    assert admission["local_test_report"]["failures"] == 0
    assert admission["recovery_authorization_sha256"] == builder.sha(files[builder.AUTH_PATH])
    assert admission["second_job_submission_authorized"] is False


def test_complete_derived_bundle_passes_local_gate(derived, tmp_path):
    _, files, _ = derived
    bundle = builder.long_path(tmp_path / "bundle")
    bundle.mkdir()
    for name, data in files.items():
        path = bundle.joinpath(*name.split("/"))
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    gate_path = bundle / "hpc/tukf09_two_basin_full_budget_gate_v2.py"
    namespace = {"__name__": "recovery_gate_test"}
    exec(compile(gate_path.read_bytes(), str(gate_path), "exec"), namespace)
    result = namespace["verify_bundle"](bundle, builder.sha(files["bundle_manifest.json"]), enforce_remote=False)
    assert result["model_import_performed"] is False
    assert result["evaluation_array_reads"] == 0
