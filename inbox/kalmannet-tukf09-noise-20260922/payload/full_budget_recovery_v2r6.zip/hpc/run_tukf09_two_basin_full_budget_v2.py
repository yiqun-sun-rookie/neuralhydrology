"""Run one authorized basin with the frozen full local-search implementation."""
from __future__ import annotations

import json
import os
from pathlib import Path
import sys
import time

from tukf09_two_basin_full_budget_gate_v2 import (
    PER_BASIN_COUNTS,
    PRIVATE_PYTHON_PATH,
    PYTHON_EXECUTABLE,
    REMOTE_PHASE,
    REMOTE_ROOT,
    STAGE,
    read_json,
    verify_basin,
    verify_bundle,
)


def _tree_file_bytes(root: Path) -> int:
    if not root.exists():
        return 0
    total = 0
    for path in root.rglob("*"):
        if path.is_symlink():
            raise RuntimeError("linked output is forbidden")
        if path.is_file():
            total += path.stat().st_size
    return total


def _worker(basin_id: str) -> None:
    dimension = verify_basin(basin_id)
    manifest_sha = os.environ["TUKF09_BUNDLE_SHA256"]
    gate = verify_bundle(REMOTE_ROOT, manifest_sha)
    expected_run = REMOTE_PHASE / f"basin_{basin_id}" / "run"
    if Path.cwd().resolve() != expected_run.resolve():
        raise PermissionError("worker current directory changed")
    output = expected_run / "model"
    output.mkdir(exist_ok=False)

    sys.dont_write_bytecode = True
    sys.path[:0] = [str(REMOTE_ROOT), str(REMOTE_ROOT / "src")]
    import numpy as np
    import torch
    from hpc import tukf09_455_scaled_noise_common_v1 as frozen
    from scripts.tukf09_training_common import semantic_array_identity

    frozen.configure_single_thread_execution()
    private = Path(PRIVATE_PYTHON_PATH).resolve()
    if (
        Path(sys.executable).resolve() != Path(PYTHON_EXECUTABLE).resolve()
        or not sys.version.startswith("3.11.13")
        or np.__version__ != "1.26.4"
        or not torch.__version__.startswith("2.2.2")
        or not Path(np.__file__).resolve().is_relative_to(private)
        or not Path(torch.__file__).resolve().is_relative_to(private)
        or torch.get_num_threads() != 1
        or torch.get_num_interop_threads() != 1
    ):
        raise RuntimeError("private numerical runtime identity changed")

    metadata = read_json(REMOTE_ROOT / "input/metadata.json")
    row = metadata["basins"][basin_id]
    parent = read_json(REMOTE_ROOT / "configs/tukf09_455_basin_zero_validation_target_variance_revision_v1.json")
    science = frozen.load_science_contract()
    frozen_inputs = frozen.load_frozen_inputs()
    fixed = frozen.load_fixed_observation_noise(frozen_inputs)
    if fixed[basin_id] != row["fixed_r_b"]:
        raise RuntimeError("fixed observation-noise multiplier changed")

    frozen.atomic_write_json_exclusive(
        output / "started.json",
        {
            "stage_id": STAGE,
            "basin_id": basin_id,
            "dimension": dimension,
            "source_gate": gate,
            "counts_authorized": PER_BASIN_COUNTS,
            "evaluation_array_reads": 0,
            "runtime": {
                "python": sys.version,
                "python_executable": sys.executable,
                "platform": list(os.uname()),
                "numpy": np.__version__,
                "torch": torch.__version__,
                "numpy_path": str(Path(np.__file__).resolve()),
                "torch_path": str(Path(torch.__file__).resolve()),
                "torch_threads": torch.get_num_threads(),
                "torch_interop_threads": torch.get_num_interop_threads(),
                "device": "cpu",
                "precision": "float64",
            },
        },
    )

    expected_members = {
        f"{basin_id}/{period}/{name}"
        for period in ("training", "validation")
        for name in ("dates_ns", "forcing", "observations")
    }
    periods = {}
    with np.load(REMOTE_ROOT / "input/training_validation.npz", allow_pickle=False) as archive:
        available = {name for name in archive.files if name.startswith(basin_id + "/")}
        if available != expected_members or len(available) != len(expected_members):
            raise RuntimeError("authorized basin input membership changed")
        for period, days, start, stop in (
            ("training", 2557, "1999-10-01", "2006-10-01"),
            ("validation", 731, "2006-10-01", "2008-10-01"),
        ):
            arrays = {}
            for name in ("dates_ns", "forcing", "observations"):
                key = f"{basin_id}/{period}/{name}"
                value = archive[key]
                expected_dtype = "<i8" if name == "dates_ns" else "<f8"
                if semantic_array_identity(key, value, expected_dtype) != row["semantic_members"][period][name]:
                    raise RuntimeError("semantic input mismatch: " + key)
                arrays[name] = value
            dates = np.arange(np.datetime64(start), np.datetime64(stop)).astype("datetime64[ns]").astype("<i8")
            if not np.array_equal(arrays["dates_ns"], dates):
                raise RuntimeError("period dates changed")
            periods[period] = frozen.period_data_from_loaded(arrays, expected_day_count=days)

    index = list(frozen_inputs.basin_ids).index(basin_id)
    parameters = dict(zip(frozen_inputs.parameter_names, frozen_inputs.parameter_values[index]))
    if parameters != row["parameters"]:
        raise RuntimeError("sealed hydrological parameter row changed")
    scale = np.asarray(row["state_scale"], dtype=np.float64)
    context = frozen.build_causal_filter_context(basin_id, parameters, periods["training"].observations, parent)
    if context.dimension != dimension or scale.shape != (dimension,):
        raise RuntimeError("state dimension changed")

    started_monotonic = time.monotonic()
    print(f"FULL_BUDGET_MODEL_STARTED basin={basin_id} dimension={dimension}", flush=True)
    history = frozen.run_full_local_search(
        context,
        periods["training"],
        periods["validation"],
        scale,
        fixed[basin_id],
        parent,
        science,
    )
    theta = np.ascontiguousarray(history.theta_log, dtype=np.float64)
    q_rows = []
    for row_theta in theta:
        tensor = torch.from_numpy(np.ascontiguousarray(row_theta, dtype=np.float64))
        q_rows.append(frozen.decode_process_theta(tensor, scale, science).detach().cpu().numpy().copy())
    process_variance = np.ascontiguousarray(np.stack(q_rows), dtype=np.float64)
    training = np.ascontiguousarray(history.training_objective, dtype=np.float64)
    validation = np.ascontiguousarray(history.validation_objective, dtype=np.float64)
    selected_actual = min(
        range(256),
        key=lambda checkpoint: (
            float(validation[checkpoint]),
            float(training[checkpoint]),
            tuple(float(value) for value in process_variance[checkpoint]),
            checkpoint,
        ),
    )
    if selected_actual != history.selected_index:
        raise RuntimeError("production and actual-process-variance selection differ")
    if (
        history.training_queries != 256
        or history.validation_queries != 256
        or history.gradient_updates != 248
        or theta.shape != (256, dimension)
        or process_variance.shape != (256, dimension)
    ):
        raise RuntimeError("frozen full-search budget changed")

    raw_ratio = np.sqrt(process_variance) / scale[None, :]
    tolerance = 1e-12
    if np.any(raw_ratio < 1e-4 - tolerance) or np.any(raw_ratio > 1.0 + tolerance):
        raise RuntimeError("full-search result left frozen ratio bounds")
    clipped_ratio = np.clip(raw_ratio, 1e-4, 1.0)
    summary = {
        "stage_id": STAGE,
        "status": "FULL_BUDGET_SINGLE_BASIN_COMPLETE_NOT_FORMAL_EVALUATION",
        "basin_id": basin_id,
        "dimension": dimension,
        "counts": PER_BASIN_COUNTS,
        "fixed_observation_noise_multiplier": float(fixed[basin_id]),
        "selected_index": int(selected_actual),
        "selected_training_objective": float(training[selected_actual]),
        "selected_validation_objective": float(validation[selected_actual]),
        "selected_process_variance": [float(value) for value in process_variance[selected_actual]],
        "ratio_lower_bound_hits": int(np.count_nonzero(np.abs(clipped_ratio - 1e-4) <= tolerance)),
        "ratio_upper_bound_hits": int(np.count_nonzero(np.abs(clipped_ratio - 1.0) <= tolerance)),
        "roundoff_ratio_clip_count": int(np.count_nonzero(clipped_ratio != raw_ratio)),
        "model_wall_seconds": time.monotonic() - started_monotonic,
        "evaluation_array_reads": 0,
        "scientific_performance_claim": False,
    }
    arrays = {
        "checkpoint_index": np.arange(256, dtype=np.int64),
        "start_index": np.tile(np.arange(8, dtype=np.int64), 32),
        "update_index": np.repeat(np.arange(32, dtype=np.int64), 8),
        "theta_log": theta,
        "process_variance_actual": process_variance,
        "training_objective": training,
        "validation_objective": validation,
        "sealed_state_scale": np.ascontiguousarray(scale, dtype=np.float64),
    }
    with (output / "history.npz").open("xb") as stream:
        stream.write(frozen.deterministic_npz_bytes(arrays))
    frozen.atomic_write_json_exclusive(output / "summary.json", summary)
    frozen.atomic_write_json_exclusive(
        output / "manifest.final.sha256.json",
        frozen.build_directory_manifest(
            output,
            schema_version="tukf09_two_basin_full_budget_result_manifest_v2",
            status="TWO_BASIN_FULL_BUDGET_SINGLE_BASIN_COMPLETE",
        ),
    )
    print("FULL_BUDGET_SINGLE_BASIN_COMPLETE " + json.dumps(summary, separators=(",", ":")), flush=True)


def _supervise(basin_id: str) -> None:
    verify_basin(basin_id)
    verify_bundle(REMOTE_ROOT, os.environ["TUKF09_BUNDLE_SHA256"])
    basin_root = REMOTE_PHASE / f"basin_{basin_id}"
    run_root = basin_root / "run"
    if not basin_root.is_dir() or basin_root.is_symlink() or run_root.exists():
        raise RuntimeError("basin root missing, linked, or already run")
    job_start = float(os.environ["TUKF09_JOB_START_UNIX"])
    elapsed = time.time() - job_start
    wall_remaining = 14400.0 - elapsed - 60.0
    job_id = os.environ["SLURM_JOB_ID"]
    used = _tree_file_bytes(basin_root)
    for suffix in ("out", "err"):
        log = REMOTE_PHASE / "logs" / f"job-{job_id}.{suffix}"
        if log.is_file() and not log.is_symlink():
            used += log.stat().st_size
    output_remaining = 100 * 2**20 - used - 1 * 2**20
    if wall_remaining <= 60.0 or output_remaining <= 1 * 2**20:
        raise RuntimeError("insufficient authorized time or output budget remains after tests")
    from tukf09_two_basin_hpc_supervisor_v1 import run_supervised

    command = [sys.executable, "-B", str(Path(__file__).resolve()), "--worker", basin_id]
    result = run_supervised(
        command,
        run_root,
        wall_seconds=wall_remaining,
        rss_limit_bytes=8 * 2**30,
        address_space_limit_bytes=8 * 2**30,
        output_limit_bytes=output_remaining,
        poll_seconds=2.0,
    )
    print(json.dumps({"basin_id": basin_id, "limits_after_tests": {"wall_seconds": wall_remaining, "output_bytes": output_remaining}, "supervisor": result}, separators=(",", ":")), flush=True)
    raise SystemExit(0 if result["success"] else 1)


def main() -> None:
    if len(sys.argv) == 3 and sys.argv[1] == "--worker":
        _worker(sys.argv[2])
    elif len(sys.argv) == 2:
        _supervise(sys.argv[1])
    else:
        raise SystemExit("requires one authorized basin id, or --worker and basin id")


if __name__ == "__main__":
    main()
