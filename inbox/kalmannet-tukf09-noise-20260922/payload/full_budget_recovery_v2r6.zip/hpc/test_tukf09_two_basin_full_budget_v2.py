from __future__ import annotations

import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

import tukf09_two_basin_full_budget_gate_v2 as gate
import tukf09_two_basin_full_budget_deploy_v2 as deploy


def _authorization() -> dict:
    return json.loads((Path(__file__).with_name("tukf09_two_basin_full_budget_execution_authorization_v2.json")).read_text(encoding="utf-8"))


def _valid_first_control_chain() -> dict:
    archive_sha = "a" * 64
    manifest_sha = "b" * 64
    attempt_sha = "c" * 64
    expected_gate = {
        "stage_id": gate.STAGE,
        "manifest_sha256": manifest_sha,
        "parent_source_count": 13,
        "member_count": 299,
        "samples": [
            {"basin_id": "01047000", "dimension": 7},
            {"basin_id": "01142500", "dimension": 20},
        ],
        "model_import_performed": False,
        "evaluation_array_reads": 0,
    }
    runtime = {"python": "3.11.13 synthetic", "numpy": "1.26.4", "torch": "2.2.2"}
    supervisor = {
        "success": True,
        "reason": "complete",
        "exit_code": 0,
        "wall_seconds": 60.0,
        "peak_tree_rss_bytes": 2**30,
        "output_bytes": 2**20,
        "worker_pid": 123,
        "sample_count": 5,
    }
    attempt = {
        "status": "SUBMISSION_ATTEMPT_CONSUMED_OUTCOME_UNKNOWN_UNTIL_SEPARATE_RECEIPT",
        "basin_id": "01047000",
        "archive_sha256": archive_sha,
        "bundle_manifest_sha256": manifest_sha,
        "partition_preflight": "PartitionName=hcpu48y OverSubscribe=NO State=UP",
        "queue_before": "",
        "runtime_preflight": runtime,
        "prerequisite": None,
        "automatic_retry_authorized": False,
    }
    submission = {
        "basin_id": "01047000",
        "archive_sha256": archive_sha,
        "bundle_manifest_sha256": manifest_sha,
        "partition_preflight": attempt["partition_preflight"],
        "queue_before": attempt["queue_before"],
        "runtime_preflight": runtime,
        "prerequisite": None,
        "submission_attempt_sha256": attempt_sha,
        "returncode": 0,
        "stdout": "Submitted batch job 123\n",
        "stderr": "",
    }
    totals = lambda tests: {"tests": tests, "failures": 0, "errors": 0, "skipped": 0}
    job_gate = {
        "stage_id": gate.STAGE,
        "basin_id": "01047000",
        "status": "ALL_JOB_TESTS_PASSED_MODEL_MAY_START",
        "original_linux_protection_tests": totals(41),
        "new_standard_library_gate_tests": totals(44),
        "synthetic_tensor_loop_tests": totals(14),
        "synthetic_tensor_supervisor": dict(supervisor, wall_seconds=20.0, output_bytes=1024),
        "model_calls": 0,
        "evaluation_array_reads": 0,
        "elapsed_seconds": 100.0,
    }
    return {
        "deployed": {
            "archive_sha256": archive_sha,
            "bundle_manifest_sha256": manifest_sha,
            "gate": dict(expected_gate),
            "runtime": runtime,
            "model_calls": 0,
            "evaluation_array_reads": 0,
        },
        "attempt": attempt,
        "submission": submission,
        "job_gate": job_gate,
        "supervisor": supervisor,
        "started": {"source_gate": dict(expected_gate)},
        "archive_sha": archive_sha,
        "manifest_sha": manifest_sha,
        "attempt_sha": attempt_sha,
        "expected_gate": expected_gate,
    }


def _write_mutated_synthetic_result(root: Path, mutation: str):
    import numpy as np

    root.mkdir()
    dimension = 7
    scale = np.ones(dimension, dtype=np.float64)
    count = 255 if mutation == "missing_checkpoint" else 256
    theta = np.full((count, dimension), np.log(0.01), dtype=np.float64)
    q = np.exp(theta)
    training = np.arange(count, dtype=np.float64) + 1.0
    validation = np.arange(count, dtype=np.float64) + 2.0
    checkpoint = np.arange(count, dtype=np.int64)
    start = np.tile(np.arange(8, dtype=np.int64), 32)[:count]
    update = np.repeat(np.arange(32, dtype=np.int64), 8)[:count]
    if mutation == "wrong_checkpoint_order":
        checkpoint[:2] = checkpoint[1::-1]
    if mutation == "wrong_update_order":
        update[-1] = 30
    if mutation == "nonfinite_objective":
        training[0] = np.nan
    with (root / "history.npz").open("wb") as stream:
        np.savez(
            stream,
            checkpoint_index=checkpoint,
            start_index=start,
            update_index=update,
            theta_log=theta,
            process_variance_actual=q,
            training_objective=training,
            validation_objective=validation,
            sealed_state_scale=scale,
        )
    started = {
        "stage_id": gate.STAGE,
        "basin_id": "01047000",
        "dimension": dimension,
        "evaluation_array_reads": 0,
        "counts_authorized": gate.PER_BASIN_COUNTS,
        "source_gate": {
            "stage_id": gate.STAGE,
            "manifest_sha256": "a" * 64,
            "model_import_performed": False,
            "evaluation_array_reads": 0,
        },
        "runtime": {
            "python": "3.11.13 synthetic",
            "python_executable": "/private/bin/python",
            "numpy": "1.26.4",
            "torch": "2.2.2+cu121",
            "numpy_path": "/private/pysite/numpy/__init__.py",
            "torch_path": "/private/pysite/torch/__init__.py",
            "device": "cpu",
            "precision": "float64",
            "torch_threads": 1,
            "torch_interop_threads": 1,
        },
    }
    selected_q = [float(value) for value in q[0]]
    summary = {
        "stage_id": gate.STAGE,
        "status": "FULL_BUDGET_SINGLE_BASIN_COMPLETE_NOT_FORMAL_EVALUATION",
        "basin_id": "01047000",
        "dimension": dimension,
        "counts": gate.PER_BASIN_COUNTS,
        "fixed_observation_noise_multiplier": 0.6 if mutation == "wrong_observation_noise" else 0.5,
        "selected_index": 0,
        "selected_training_objective": 1.0,
        "selected_validation_objective": 2.0,
        "selected_process_variance": selected_q,
        "roundoff_ratio_clip_count": 0,
        "ratio_lower_bound_hits": 0,
        "ratio_upper_bound_hits": 0,
        "evaluation_array_reads": 0,
    }
    for name, value in (("started.json", started), ("summary.json", summary)):
        (root / name).write_text(json.dumps(value, separators=(",", ":")), encoding="utf-8")
    records = {}
    for name in ("history.npz", "started.json", "summary.json"):
        path = root / name
        records[name] = {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "size_bytes": path.stat().st_size}
    manifest = {
        "schema_version": "tukf09_two_basin_full_budget_result_manifest_v2",
        "experiment_id": "TUKF09_455_SCALED_NOISE_LOCAL_TRANSFER_V1",
        "status": "TWO_BASIN_FULL_BUDGET_SINGLE_BASIN_COMPLETE",
        "file_count": 3,
        "files": records,
    }
    (root / "manifest.final.sha256.json").write_text(json.dumps(manifest, separators=(",", ":")), encoding="utf-8")
    if mutation == "extra_result_member":
        (root / "unexpected.txt").write_text("unexpected", encoding="ascii")
    return scale


def test_read_json_rejects_duplicate_key(tmp_path):
    path = tmp_path / "duplicate.json"
    path.write_text('{"a":1,"a":2}', encoding="utf-8")
    with pytest.raises(ValueError, match="duplicate JSON"):
        gate.read_json(path)


def test_read_json_rejects_nonfinite_constant(tmp_path):
    path = tmp_path / "nonfinite.json"
    path.write_text('{"a":NaN}', encoding="utf-8")
    with pytest.raises(ValueError, match="non-finite JSON"):
        gate.read_json(path)


def test_authorization_exact_record_passes():
    gate.validate_authorization(_authorization())


def test_authorization_rejects_partition_change():
    value = _authorization()
    value["resources"]["partition"] = "hcpu48"
    with pytest.raises(PermissionError, match="scheduler"):
        gate.validate_authorization(value)


def test_authorization_rejects_evaluation_access():
    value = _authorization()
    value["evaluation_authorized"] = True
    with pytest.raises(PermissionError, match="scope"):
        gate.validate_authorization(value)


def test_authorization_rejects_more_jobs():
    value = _authorization()
    value["resources"]["maximum_jobs"] = 3
    with pytest.raises(PermissionError, match="scheduler"):
        gate.validate_authorization(value)


def test_authorization_rejects_default_runtime():
    value = _authorization()
    value["runtime"]["numpy_version"] = "2.3.3"
    with pytest.raises(PermissionError, match="runtime"):
        gate.validate_authorization(value)


def test_verify_basin_accepts_exact_samples():
    assert gate.verify_basin("01047000") == 7
    assert gate.verify_basin("01142500") == 20


def test_verify_basin_rejects_other_sample():
    with pytest.raises(PermissionError, match="authorized samples"):
        gate.verify_basin("00000000")


def test_checked_path_accepts_regular_member(tmp_path):
    path = tmp_path / "a" / "b.txt"
    path.parent.mkdir()
    path.write_text("ok", encoding="ascii")
    assert gate.checked_path(tmp_path, "a/b.txt") == path


def test_verify_bundle_rejects_wrong_execution_root(tmp_path):
    with pytest.raises(PermissionError, match="unapproved remote"):
        gate.verify_bundle(tmp_path, "0" * 64)


def test_admitted_source_record_rejects_changed_bytes(tmp_path):
    path = tmp_path / "source.py"
    path.write_text("first", encoding="ascii")
    expected = gate.file_record(path)
    path.write_text("changed", encoding="ascii")
    with pytest.raises(RuntimeError, match="fingerprint or size changed"):
        gate.require_file_record(path, expected, label="admitted source")


@pytest.mark.parametrize("relative", ["../x", "/x", "a\\b", "C:/x", "./x", ""])
def test_checked_path_rejects_unsafe_relative(tmp_path, relative):
    with pytest.raises((ValueError, FileNotFoundError)):
        gate.checked_path(tmp_path, relative)


def test_per_basin_counts_are_frozen():
    assert gate.PER_BASIN_COUNTS == {
        "start_count": 8,
        "updates_per_start": 31,
        "checkpoints": 256,
        "gradient_updates": 248,
        "training_objective_calls": 256,
        "validation_objective_calls": 256,
        "evaluation_array_reads": 0,
    }


def test_deploy_partition_rejects_exclusive(monkeypatch):
    response = SimpleNamespace(
        stdout="PartitionName=hcpu48y OverSubscribe=EXCLUSIVE State=UP\n",
        stderr="",
        returncode=0,
    )
    monkeypatch.setattr(deploy.subprocess, "run", lambda *args, **kwargs: response)
    with pytest.raises(RuntimeError, match="not in the admitted"):
        deploy._partition_record()


def test_deploy_refuses_duplicate_submission_before_scheduler(tmp_path, monkeypatch):
    phase = tmp_path / "phase"
    control = phase / "basin_01047000" / "control"
    control.mkdir(parents=True)
    (control / "submission.json").write_text("{}", encoding="ascii")
    monkeypatch.setattr(deploy, "PHASE", phase)
    with pytest.raises(FileExistsError, match="already consumed"):
        deploy._submit_once("01047000", "a" * 64, "b" * 64, prerequisite=None)


def test_deploy_attempt_survives_post_sbatch_receipt_failure(tmp_path, monkeypatch):
    phase = tmp_path / "phase"
    control = phase / "basin_01047000" / "control"
    control.mkdir(parents=True)
    monkeypatch.setattr(deploy, "PHASE", phase)
    monkeypatch.setattr(deploy, "_partition_record", lambda: "partition-ok")
    monkeypatch.setattr(deploy, "_queue_snapshot", lambda: "")
    monkeypatch.setattr(deploy, "_runtime_check", lambda: {"runtime": "ok"})
    scheduler_calls = []

    def fake_scheduler(*args, **kwargs):
        scheduler_calls.append(args)
        return SimpleNamespace(returncode=0, stdout="Submitted batch job 123\n", stderr="")

    monkeypatch.setattr(deploy.subprocess, "run", fake_scheduler)
    original_write = deploy._write_json_exclusive

    def fail_submission_receipt(path, value):
        if path.name == "submission_attempt.json":
            return original_write(path, value)
        raise OSError("simulated receipt write failure after scheduler acceptance")

    monkeypatch.setattr(deploy, "_write_json_exclusive", fail_submission_receipt)
    with pytest.raises(OSError, match="simulated receipt"):
        deploy._submit_once("01047000", "a" * 64, "b" * 64, prerequisite=None)
    assert (control / "submission_attempt.json").is_file()
    assert len(scheduler_calls) == 1
    with pytest.raises(FileExistsError, match="attempt is already consumed"):
        deploy._submit_once("01047000", "a" * 64, "b" * 64, prerequisite=None)
    assert len(scheduler_calls) == 1


def test_tres_requires_exact_one_not_prefix_ten():
    deploy._require_exact_one_core_tres("billing=1,cpu=1,node=1", "billing=1,cpu=1,node=1")
    with pytest.raises(RuntimeError, match="not exactly"):
        deploy._require_exact_one_core_tres("billing=10,cpu=10,node=1", "billing=1,cpu=1,node=1")


def test_first_acceptance_control_chain_exact_record_passes():
    assert deploy._validate_first_control_chain(**_valid_first_control_chain()) == "123"


@pytest.mark.parametrize(
    "mutation",
    [
        "deployed_archive",
        "attempt_basin",
        "submission_manifest",
        "submission_attempt_digest",
        "original_count",
        "new_skipped",
        "synthetic_errors",
        "job_stage",
        "job_basin",
        "job_model_calls",
        "job_evaluation_reads",
        "supervisor_reason",
        "supervisor_exit",
        "supervisor_peak",
        "supervisor_wall",
        "supervisor_output",
        "synthetic_output",
        "source_gate_extra",
    ],
)
def test_first_acceptance_control_chain_rejects_mutation(mutation):
    from copy import deepcopy

    values = deepcopy(_valid_first_control_chain())
    if mutation == "deployed_archive":
        values["deployed"]["archive_sha256"] = "d" * 64
    elif mutation == "attempt_basin":
        values["attempt"]["basin_id"] = "01142500"
    elif mutation == "submission_manifest":
        values["submission"]["bundle_manifest_sha256"] = "e" * 64
    elif mutation == "submission_attempt_digest":
        values["submission"]["submission_attempt_sha256"] = "f" * 64
    elif mutation == "original_count":
        values["job_gate"]["original_linux_protection_tests"]["tests"] = 40
    elif mutation == "new_skipped":
        values["job_gate"]["new_standard_library_gate_tests"]["skipped"] = 1
    elif mutation == "synthetic_errors":
        values["job_gate"]["synthetic_tensor_loop_tests"]["errors"] = 1
    elif mutation == "job_stage":
        values["job_gate"]["stage_id"] = "wrong-stage"
    elif mutation == "job_basin":
        values["job_gate"]["basin_id"] = "01142500"
    elif mutation == "job_model_calls":
        values["job_gate"]["model_calls"] = 1
    elif mutation == "job_evaluation_reads":
        values["job_gate"]["evaluation_array_reads"] = 1
    elif mutation == "supervisor_reason":
        values["supervisor"]["reason"] = "wall_limit"
    elif mutation == "supervisor_exit":
        values["supervisor"]["exit_code"] = 1
    elif mutation == "supervisor_peak":
        values["supervisor"]["peak_tree_rss_bytes"] = 8 * 2**30 + 1
    elif mutation == "supervisor_wall":
        values["supervisor"]["wall_seconds"] = 14400.1
    elif mutation == "supervisor_output":
        values["supervisor"]["output_bytes"] = 100 * 2**20 + 1
    elif mutation == "synthetic_output":
        values["job_gate"]["synthetic_tensor_supervisor"]["output_bytes"] = 16 * 2**20 + 1
    elif mutation == "source_gate_extra":
        values["started"]["source_gate"]["unexpected"] = True
    with pytest.raises(RuntimeError):
        deploy._validate_first_control_chain(**values)


def test_deploy_sample_order_is_fixed():
    assert deploy.SAMPLES == ("01047000", "01142500")


def test_slurm_resources_and_no_requeue_are_exact():
    text = Path(__file__).with_name("tukf09_two_basin_full_budget_job_v2.slurm").read_text(encoding="utf-8")
    required = {
        "#SBATCH --partition=hcpu48y",
        "#SBATCH --nodes=1",
        "#SBATCH --ntasks=1",
        "#SBATCH --cpus-per-task=1",
        "#SBATCH --time=04:00:00",
        "#SBATCH --no-requeue",
    }
    assert required <= set(text.splitlines())
    assert text.count("#SBATCH --partition=") == 1
    assert text.count("#SBATCH --cpus-per-task=") == 1
    assert "#SBATCH --mem=" not in text
    assert "set -u" not in text


def test_tensor_full_loop_budget_and_round_robin(monkeypatch):
    import numpy as np
    import torch
    from hpc import tukf09_455_scaled_noise_common_v1 as common

    events = []
    parameter_order = {}

    def objective(context, forcing, observations, theta, scale, fixed_r_b, parent_contract, period_name, *, grad):
        identity = id(theta)
        if identity not in parameter_order:
            parameter_order[identity] = len(parameter_order)
        events.append((period_name, grad, parameter_order[identity]))
        target = torch.full_like(theta, 0.01 * (parameter_order[identity] + 1))
        value = torch.mean((theta - target) ** 2)
        return value if grad else value.detach()

    monkeypatch.setattr(common, "scaled_multilead_objective", objective)
    science = common.load_science_contract()
    history = common.run_full_local_search(
        SimpleNamespace(dimension=7),
        SimpleNamespace(forcing=object(), observations=object()),
        SimpleNamespace(forcing=object(), observations=object()),
        np.ones(7, dtype=np.float64),
        0.5,
        {},
        science,
    )
    assert history.theta_log.shape == (256, 7)
    assert history.training_objective.shape == (256,)
    assert history.validation_objective.shape == (256,)
    assert history.training_queries == 256
    assert history.validation_queries == 256
    assert history.gradient_updates == 248
    assert len(events) == 512
    assert len(parameter_order) == 8
    assert [(events[2 * i][0], events[2 * i][1]) for i in range(256)] == [("training", True)] * 256
    assert [(events[2 * i + 1][0], events[2 * i + 1][1]) for i in range(256)] == [("validation", False)] * 256
    assert [events[2 * i][2] for i in range(256)] == list(np.tile(np.arange(8), 32))


def test_tensor_independent_selection_uses_all_four_tiers():
    import numpy as np
    from verify_tukf09_two_basin_full_budget_v2 import independent_selected_index

    q = np.asarray([[9.0], [3.0], [1.0], [1.0]], dtype=np.float64)
    training = np.asarray([0.0, 1.0, 0.0, 0.0], dtype=np.float64)
    validation = np.asarray([1.0, 0.0, 0.0, 0.0], dtype=np.float64)
    assert independent_selected_index(q, training, validation) == 2


def test_tensor_one_ulp_is_accepted_in_both_directions():
    import numpy as np
    from verify_tukf09_two_basin_full_budget_v2 import require_q_exp_within_one_ulp

    theta = np.zeros((1, 2), dtype=np.float64)
    q = np.asarray([[np.nextafter(1.0, 0.0), np.nextafter(1.0, np.inf)]], dtype=np.float64)
    result = require_q_exp_within_one_ulp(theta, q)
    assert result == {"unequal_coordinates": 2, "maximum_ulp_distance": 1}


def test_tensor_two_ulps_are_rejected_in_both_directions():
    import numpy as np
    from verify_tukf09_two_basin_full_budget_v2 import require_q_exp_within_one_ulp

    lower = np.nextafter(np.nextafter(1.0, 0.0), 0.0)
    upper = np.nextafter(np.nextafter(1.0, np.inf), np.inf)
    theta = np.zeros((1, 2), dtype=np.float64)
    with pytest.raises(RuntimeError, match="more than one"):
        require_q_exp_within_one_ulp(theta, np.asarray([[lower, upper]], dtype=np.float64))


def test_tensor_nonfinite_process_variance_is_rejected():
    import numpy as np
    from verify_tukf09_two_basin_full_budget_v2 import require_q_exp_within_one_ulp

    with pytest.raises(ValueError, match="positive finite"):
        require_q_exp_within_one_ulp(np.zeros((1, 1), dtype=np.float64), np.asarray([[np.nan]], dtype=np.float64))


def test_tensor_complete_synthetic_result_verifies(tmp_path):
    import numpy as np
    from verify_tukf09_two_basin_full_budget_v2 import verify_result_directory

    root = tmp_path / "model"
    root.mkdir()
    dimension = 7
    scale = np.ones(dimension, dtype=np.float64)
    theta = np.full((256, dimension), np.log(0.01), dtype=np.float64)
    q = np.exp(theta)
    training = np.arange(256, dtype=np.float64) + 1.0
    validation = np.arange(256, dtype=np.float64) + 2.0
    with (root / "history.npz").open("wb") as stream:
        np.savez(
            stream,
            checkpoint_index=np.arange(256, dtype=np.int64),
            start_index=np.tile(np.arange(8, dtype=np.int64), 32),
            update_index=np.repeat(np.arange(32, dtype=np.int64), 8),
            theta_log=theta,
            process_variance_actual=q,
            training_objective=training,
            validation_objective=validation,
            sealed_state_scale=scale,
        )
    started = {
        "stage_id": gate.STAGE,
        "basin_id": "01047000",
        "dimension": dimension,
        "evaluation_array_reads": 0,
        "counts_authorized": gate.PER_BASIN_COUNTS,
        "source_gate": {
            "stage_id": gate.STAGE,
            "manifest_sha256": "c" * 64,
            "model_import_performed": False,
            "evaluation_array_reads": 0,
        },
        "runtime": {
            "python": "3.11.13 synthetic",
            "python_executable": "/private/bin/python",
            "numpy": "1.26.4",
            "torch": "2.2.2+cu121",
            "numpy_path": "/private/pysite/numpy/__init__.py",
            "torch_path": "/private/pysite/torch/__init__.py",
            "device": "cpu",
            "precision": "float64",
            "torch_threads": 1,
            "torch_interop_threads": 1,
        },
    }
    summary = {
        "stage_id": gate.STAGE,
        "status": "FULL_BUDGET_SINGLE_BASIN_COMPLETE_NOT_FORMAL_EVALUATION",
        "basin_id": "01047000",
        "dimension": dimension,
        "counts": gate.PER_BASIN_COUNTS,
        "fixed_observation_noise_multiplier": 0.5,
        "selected_index": 0,
        "selected_training_objective": 1.0,
        "selected_validation_objective": 2.0,
        "selected_process_variance": [float(value) for value in q[0]],
        "roundoff_ratio_clip_count": 0,
        "ratio_lower_bound_hits": 0,
        "ratio_upper_bound_hits": 0,
        "evaluation_array_reads": 0,
    }
    for name, value in (("started.json", started), ("summary.json", summary)):
        (root / name).write_text(json.dumps(value, separators=(",", ":")), encoding="utf-8")
    records = {}
    for name in ("history.npz", "started.json", "summary.json"):
        path = root / name
        records[name] = {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "size_bytes": path.stat().st_size}
    manifest = {
        "schema_version": "tukf09_two_basin_full_budget_result_manifest_v2",
        "experiment_id": "TUKF09_455_SCALED_NOISE_LOCAL_TRANSFER_V1",
        "status": "TWO_BASIN_FULL_BUDGET_SINGLE_BASIN_COMPLETE",
        "file_count": 3,
        "files": records,
    }
    (root / "manifest.final.sha256.json").write_text(json.dumps(manifest, separators=(",", ":")), encoding="utf-8")
    result = verify_result_directory(
        root,
        basin_id="01047000",
        dimension=dimension,
        expected_scale=scale,
        expected_fixed_r_b=0.5,
        expected_source_gate=started["source_gate"],
        expected_bundle_manifest_sha256="c" * 64,
        expected_python_executable="/private/bin/python",
        expected_private_python_path="/private/pysite",
    )
    assert result["status"] == "PASS_NOT_FORMAL_EVALUATION"
    assert result["selected_index"] == 0
    assert result["maximum_q_exp_ulp_distance"] == 0


def test_tensor_started_identity_rejects_shared_runtime_path():
    from verify_tukf09_two_basin_full_budget_v2 import validate_started_identity

    started = {
        "counts_authorized": gate.PER_BASIN_COUNTS,
        "source_gate": {
            "stage_id": gate.STAGE,
            "manifest_sha256": "d" * 64,
            "model_import_performed": False,
            "evaluation_array_reads": 0,
        },
        "runtime": {
            "python": "3.11.13 synthetic",
            "python_executable": "/private/bin/python",
            "numpy": "1.26.4",
            "torch": "2.2.2+cu121",
            "numpy_path": "/shared/nh_final/numpy/__init__.py",
            "torch_path": "/private/pysite/torch/__init__.py",
            "device": "cpu",
            "precision": "float64",
            "torch_threads": 1,
            "torch_interop_threads": 1,
        },
    }
    for invalid in ("/shared/nh_final/numpy/__init__.py", "/private/pysite/../shared/numpy/__init__.py"):
        started["runtime"]["numpy_path"] = invalid
        with pytest.raises(RuntimeError, match="private path|canonical"):
            validate_started_identity(
                started,
                expected_source_gate=started["source_gate"],
                expected_bundle_manifest_sha256="d" * 64,
                expected_python_executable="/private/bin/python",
                expected_private_python_path="/private/pysite",
            )


def test_tensor_started_identity_rejects_bundle_or_budget_tampering():
    from copy import deepcopy
    from verify_tukf09_two_basin_full_budget_v2 import validate_started_identity

    started = {
        "counts_authorized": gate.PER_BASIN_COUNTS,
        "source_gate": {
            "stage_id": gate.STAGE,
            "manifest_sha256": "e" * 64,
            "model_import_performed": False,
            "evaluation_array_reads": 0,
        },
        "runtime": {
            "python": "3.11.13 synthetic",
            "python_executable": "/private/bin/python",
            "numpy": "1.26.4",
            "torch": "2.2.2+cu121",
            "numpy_path": "/private/pysite/numpy/__init__.py",
            "torch_path": "/private/pysite/torch/__init__.py",
            "device": "cpu",
            "precision": "float64",
            "torch_threads": 1,
            "torch_interop_threads": 1,
        },
    }
    changed_manifest = deepcopy(started)
    changed_manifest["source_gate"]["manifest_sha256"] = "f" * 64
    changed_budget = deepcopy(started)
    changed_budget["counts_authorized"] = dict(gate.PER_BASIN_COUNTS, checkpoints=255)
    for tampered in (changed_manifest, changed_budget):
        with pytest.raises(RuntimeError, match="bundle fingerprint|authorized counts"):
            validate_started_identity(
                tampered,
                expected_source_gate=started["source_gate"],
                expected_bundle_manifest_sha256="e" * 64,
                expected_python_executable="/private/bin/python",
                expected_private_python_path="/private/pysite",
            )


@pytest.mark.parametrize(
    "mutation",
    [
        "wrong_checkpoint_order",
        "wrong_update_order",
        "missing_checkpoint",
        "nonfinite_objective",
        "wrong_observation_noise",
        "extra_result_member",
    ],
)
def test_tensor_result_mutations_are_rejected(tmp_path, mutation):
    from verify_tukf09_two_basin_full_budget_v2 import verify_result_directory

    root = tmp_path / mutation
    scale = _write_mutated_synthetic_result(root, mutation)
    with pytest.raises(RuntimeError):
        verify_result_directory(
            root,
            basin_id="01047000",
            dimension=7,
            expected_scale=scale,
            expected_fixed_r_b=0.5,
            expected_source_gate={
                "stage_id": gate.STAGE,
                "manifest_sha256": "a" * 64,
                "model_import_performed": False,
                "evaluation_array_reads": 0,
            },
            expected_bundle_manifest_sha256="a" * 64,
            expected_python_executable="/private/bin/python",
            expected_private_python_path="/private/pysite",
        )
