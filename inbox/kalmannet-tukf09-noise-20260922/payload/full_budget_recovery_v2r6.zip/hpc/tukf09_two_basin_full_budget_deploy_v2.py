"""Exclusive deployment and serial one-time submission for the two authorized basins."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import zipfile

PHASE = Path("/data1/home/sunyiq/kalmannet_tukf09_scaled_noise_rehearsal_20260922/full_budget_recovery_v2r6")
ARCHIVE = Path("/data1/home/sunyiq/hpc_mailbox/inbox/kalmannet-tukf09-noise-20260922/payload/full_budget_recovery_v2r6.zip")
PYTHON = "/data1/home/sunyiq/miniconda3/envs/knet_clean/bin/python"
PRIVATE = "/data1/home/sunyiq/kalmannet_tukf09_455_basin_zero_validation_target_variance_revision_v1_a800_exclusive_v2r14_20260909/runtime_v2r14/pysite"
JOB_NAME = "tukf09-noise-recover-v2r6"
SAMPLES = ("01047000",)


def _digest(path: Path) -> str:
    with Path(path).open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def _write_json_exclusive(path: Path, value: dict) -> None:
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
        stream.write("\n")


def _read_json(path: Path) -> dict:
    def pairs(items):
        value = {}
        for key, item in items:
            if key in value:
                raise ValueError("duplicate JSON key: " + key)
            value[key] = item
        return value

    def constant(token):
        raise ValueError("non-finite JSON: " + token)

    value = json.loads(Path(path).read_text(encoding="utf-8"), object_pairs_hook=pairs, parse_constant=constant)
    if not isinstance(value, dict):
        raise ValueError("expected JSON object")
    return value


def _parse_tres(value: str) -> dict[str, str]:
    result = {}
    for item in value.split(","):
        pair = item.split("=", 1)
        if len(pair) != 2 or not pair[0] or not pair[1] or pair[0] in result:
            raise ValueError("malformed or duplicate TRES field")
        result[pair[0]] = pair[1]
    return result


def _require_exact_one_core_tres(allocated: str, requested: str) -> None:
    expected = {"billing": "1", "cpu": "1", "node": "1"}
    for label, raw in (("allocated", allocated), ("requested", requested)):
        parsed = _parse_tres(raw)
        if {key: parsed.get(key) for key in expected} != expected:
            raise RuntimeError(label + " TRES is not exactly billing=1,cpu=1,node=1")


def _require_supervisor_pass(record: dict, *, wall_limit: float, rss_limit: int, output_limit: int, label: str) -> None:
    wall = record.get("wall_seconds")
    peak = record.get("peak_tree_rss_bytes")
    output = record.get("output_bytes")
    worker = record.get("worker_pid")
    samples = record.get("sample_count")
    if (
        record.get("success") is not True
        or record.get("reason") != "complete"
        or isinstance(record.get("exit_code"), bool)
        or record.get("exit_code") != 0
        or isinstance(wall, bool)
        or not isinstance(wall, (int, float))
        or not math.isfinite(wall)
        or not 0.0 < wall <= wall_limit
        or isinstance(peak, bool)
        or not isinstance(peak, int)
        or not 0 < peak <= rss_limit
        or isinstance(output, bool)
        or not isinstance(output, int)
        or not 0 <= output <= output_limit
        or isinstance(worker, bool)
        or not isinstance(worker, int)
        or worker <= 0
        or isinstance(samples, bool)
        or not isinstance(samples, int)
        or samples <= 0
    ):
        raise RuntimeError(label + " supervisor identity, exit, time, memory, or output changed")


def _require_test_totals(value: object, expected: int, label: str) -> None:
    if value != {"tests": expected, "failures": 0, "errors": 0, "skipped": 0}:
        raise RuntimeError(label + " exact test totals changed")


def _validate_first_control_chain(
    *,
    deployed: dict,
    attempt: dict,
    submission: dict,
    job_gate: dict,
    supervisor: dict,
    started: dict,
    archive_sha: str,
    manifest_sha: str,
    attempt_sha: str,
    expected_gate: dict,
) -> str:
    identity = {"basin_id": "01047000", "archive_sha256": archive_sha, "bundle_manifest_sha256": manifest_sha}
    if (
        deployed.get("archive_sha256") != archive_sha
        or deployed.get("bundle_manifest_sha256") != manifest_sha
        or deployed.get("gate") != expected_gate
        or deployed.get("model_calls") != 0
        or deployed.get("evaluation_array_reads") != 0
        or not isinstance(deployed.get("runtime"), dict)
    ):
        raise RuntimeError("deployed package, gate, runtime, or access identity changed")
    if (
        any(attempt.get(key) != value for key, value in identity.items())
        or attempt.get("status") != "SUBMISSION_ATTEMPT_CONSUMED_OUTCOME_UNKNOWN_UNTIL_SEPARATE_RECEIPT"
        or attempt.get("automatic_retry_authorized") is not False
        or attempt.get("prerequisite") is not None
        or not isinstance(attempt.get("partition_preflight"), str)
        or not isinstance(attempt.get("queue_before"), str)
        or not isinstance(attempt.get("runtime_preflight"), dict)
    ):
        raise RuntimeError("first submission-attempt identity or one-use policy changed")
    if (
        any(submission.get(key) != value for key, value in identity.items())
        or submission.get("submission_attempt_sha256") != attempt_sha
        or submission.get("partition_preflight") != attempt.get("partition_preflight")
        or submission.get("queue_before") != attempt.get("queue_before")
        or submission.get("runtime_preflight") != attempt.get("runtime_preflight")
        or submission.get("prerequisite") is not None
        or deployed.get("runtime") != attempt.get("runtime_preflight")
        or isinstance(submission.get("returncode"), bool)
        or submission.get("returncode") != 0
        or not isinstance(submission.get("stderr"), str)
    ):
        raise RuntimeError("first submission receipt does not match deployment and consumed attempt")
    match = re.fullmatch(r"Submitted batch job ([0-9]+)\s*", submission.get("stdout", ""))
    if match is None:
        raise RuntimeError("first job was not uniquely submitted")
    _require_test_totals(job_gate.get("original_linux_protection_tests"), 41, "original Linux protection")
    _require_test_totals(job_gate.get("new_standard_library_gate_tests"), 44, "new standard-library gate")
    _require_test_totals(job_gate.get("synthetic_tensor_loop_tests"), 14, "synthetic tensor loop")
    gate_elapsed = job_gate.get("elapsed_seconds")
    if (
        job_gate.get("stage_id") != expected_gate.get("stage_id")
        or job_gate.get("basin_id") != "01047000"
        or job_gate.get("status") != "ALL_JOB_TESTS_PASSED_MODEL_MAY_START"
        or job_gate.get("model_calls") != 0
        or job_gate.get("evaluation_array_reads") != 0
        or isinstance(gate_elapsed, bool)
        or not isinstance(gate_elapsed, (int, float))
        or not math.isfinite(gate_elapsed)
        or not 0.0 < gate_elapsed < 14400.0
    ):
        raise RuntimeError("first job test-gate identity, access count, or duration changed")
    _require_supervisor_pass(
        job_gate.get("synthetic_tensor_supervisor", {}),
        wall_limit=600.0,
        rss_limit=8 * 2**30,
        output_limit=16 * 2**20,
        label="synthetic tensor",
    )
    _require_supervisor_pass(
        supervisor,
        wall_limit=14400.0,
        rss_limit=8 * 2**30,
        output_limit=100 * 2**20,
        label="first model",
    )
    if started.get("source_gate") != expected_gate:
        raise RuntimeError("first result source gate does not exactly match the current verified bundle")
    return match.group(1)


def _partition_record() -> str:
    result = subprocess.run(
        ["scontrol", "show", "partition", "hcpu48y", "-o"],
        check=True,
        text=True,
        capture_output=True,
        timeout=30,
    )
    lines = [line.strip() for line in result.stdout.splitlines() if line.strip()]
    if len(lines) != 1:
        raise RuntimeError("hcpu48y partition query was not unique")
    line = lines[0]
    if "PartitionName=hcpu48y " not in line or " OverSubscribe=NO " not in " " + line + " " or " State=UP " not in " " + line + " ":
        raise RuntimeError("hcpu48y is not in the admitted shared and available state")
    return line


def _queue_snapshot() -> str:
    result = subprocess.run(
        ["squeue", "-u", "sunyiq", "-h", "-o", "%i|%j|%T|%R"],
        check=True,
        text=True,
        capture_output=True,
        timeout=30,
    )
    if any(f"|{JOB_NAME}|" in line for line in result.stdout.splitlines()):
        raise RuntimeError("same-stage job is already active")
    return result.stdout


def _safe_extract(archive: zipfile.ZipFile, destination: Path) -> None:
    members = archive.infolist()
    names = [member.filename for member in members]
    if len(names) != len(set(names)) or sum(member.file_size for member in members) > 64 * 2**20:
        raise RuntimeError("invalid archive membership or expanded size")
    for member in members:
        relative = PurePosixPath(member.filename)
        mode = member.external_attr >> 16
        if (
            relative.is_absolute()
            or ".." in relative.parts
            or ":" in member.filename
            or "\\" in member.filename
            or relative.as_posix() != member.filename
            or member.is_dir()
            or stat.S_ISLNK(mode)
            or stat.S_IFMT(mode) not in (0, stat.S_IFREG)
        ):
            raise RuntimeError("unsafe archive member")
        target = destination.joinpath(*relative.parts)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(archive.read(member))


def _load_gate(manifest_sha: str) -> dict:
    path = PHASE / "bundle/hpc/tukf09_two_basin_full_budget_gate_v2.py"
    spec = importlib.util.spec_from_file_location("full_budget_gate_deployed_v2", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module.verify_bundle(PHASE / "bundle", manifest_sha)


def _runtime_check() -> dict:
    code = r'''import importlib, importlib.metadata as md, json, pathlib, sys
private=pathlib.Path(__PRIVATE__).resolve()
vendor=pathlib.Path(__VENDOR__).resolve()
import numpy, torch, pytest
if not sys.version.startswith('3.11.13'):
    raise RuntimeError('python version changed')
if numpy.__version__!='1.26.4' or not torch.__version__.startswith('2.2.2') or md.version('pytest')!='8.3.5':
    raise RuntimeError('runtime package version changed')
if not pathlib.Path(numpy.__file__).resolve().is_relative_to(private) or not pathlib.Path(torch.__file__).resolve().is_relative_to(private):
    raise RuntimeError('numerical package source changed')
if not pathlib.Path(pytest.__file__).resolve().is_relative_to(vendor):
    raise RuntimeError('test package source changed')
print(json.dumps({'python':sys.version,'numpy':numpy.__version__,'torch':torch.__version__,'pytest':md.version('pytest'),'numpy_path':numpy.__file__,'torch_path':torch.__file__,'pytest_path':pytest.__file__},sort_keys=True))
'''.replace("__PRIVATE__", repr(PRIVATE)).replace("__VENDOR__", repr(str(PHASE / "bundle/vendor")))
    environment = dict(
        os.environ,
        PYTHONNOUSERSITE="1",
        PYTHONDONTWRITEBYTECODE="1",
        PYTHONPATH=str(PHASE / "bundle/vendor") + ":" + PRIVATE,
        OMP_NUM_THREADS="1",
        MKL_NUM_THREADS="1",
        OPENBLAS_NUM_THREADS="1",
        NUMEXPR_NUM_THREADS="1",
    )
    result = subprocess.run([PYTHON, "-B", "-c", code], env=environment, text=True, capture_output=True, timeout=60, check=True)
    return json.loads(result.stdout)


def _submit_once(basin_id: str, manifest_sha: str, archive_sha: str, *, prerequisite: dict | None) -> str:
    if basin_id not in SAMPLES:
        raise PermissionError("unauthorized basin")
    basin = PHASE / f"basin_{basin_id}"
    control = basin / "control"
    attempt = control / "submission_attempt.json"
    submission = control / "submission.json"
    if attempt.exists() or attempt.is_symlink() or submission.exists() or submission.is_symlink():
        raise FileExistsError("basin submission attempt is already consumed")
    partition = _partition_record()
    queue = _queue_snapshot()
    runtime = _runtime_check()
    attempt_record = {
        "status": "SUBMISSION_ATTEMPT_CONSUMED_OUTCOME_UNKNOWN_UNTIL_SEPARATE_RECEIPT",
        "basin_id": basin_id,
        "archive_sha256": archive_sha,
        "bundle_manifest_sha256": manifest_sha,
        "partition_preflight": partition,
        "queue_before": queue,
        "runtime_preflight": runtime,
        "prerequisite": prerequisite,
        "automatic_retry_authorized": False,
    }
    _write_json_exclusive(attempt, attempt_record)
    environment = dict(os.environ, TUKF09_BUNDLE_SHA256=manifest_sha)
    result = subprocess.run(
        ["sbatch", str(PHASE / "bundle/hpc/tukf09_two_basin_full_budget_job_v2.slurm"), basin_id],
        env=environment,
        text=True,
        capture_output=True,
    )
    record = {
        "basin_id": basin_id,
        "archive_sha256": archive_sha,
        "bundle_manifest_sha256": manifest_sha,
        "partition_preflight": partition,
        "queue_before": queue,
        "runtime_preflight": runtime,
        "prerequisite": prerequisite,
        "submission_attempt_sha256": _digest(attempt),
        "returncode": result.returncode,
        "stdout": result.stdout,
        "stderr": result.stderr,
    }
    _write_json_exclusive(submission, record)
    print(result.stdout, flush=True)
    print(result.stderr, file=sys.stderr, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
    match = re.fullmatch(r"Submitted batch job ([0-9]+)\s*", result.stdout)
    if match is None:
        raise RuntimeError("ambiguous submission; do not retry")
    return match.group(1)


def initialize_and_submit_first(archive_sha: str, manifest_sha: str) -> None:
    for value in (archive_sha, manifest_sha):
        if len(value) != 64 or any(char not in "0123456789abcdef" for char in value):
            raise ValueError("invalid fingerprint")
    if PHASE.exists() or PHASE.is_symlink() or PHASE.parent.resolve() != PHASE.parent:
        raise FileExistsError("full-budget phase already exists or ancestor is linked")
    if not PHASE.parent.is_dir() or ARCHIVE.is_symlink() or ARCHIVE.stat().st_size > 10 * 2**20:
        raise RuntimeError("unexpected phase parent or archive")
    if _digest(ARCHIVE) != archive_sha:
        raise RuntimeError("payload archive fingerprint changed")
    _partition_record()
    _queue_snapshot()
    PHASE.mkdir(mode=0o750, exist_ok=False)
    for name in ("bundle", "control", "logs"):
        (PHASE / name).mkdir(mode=0o750)
    for basin_id in SAMPLES:
        for name in ("control", "tmp", "cache"):
            (PHASE / f"basin_{basin_id}" / name).mkdir(parents=True, mode=0o750)
    with zipfile.ZipFile(ARCHIVE) as archive:
        _safe_extract(archive, PHASE / "bundle")
    gate = _load_gate(manifest_sha)
    deployed = {
        "archive_sha256": archive_sha,
        "bundle_manifest_sha256": manifest_sha,
        "gate": gate,
        "runtime": _runtime_check(),
        "model_calls": 0,
        "evaluation_array_reads": 0,
    }
    _write_json_exclusive(PHASE / "control/deployed.json", deployed)
    _submit_once("01047000", manifest_sha, archive_sha, prerequisite=None)


def _first_job_acceptance(first_manifest_sha: str, manifest_sha: str, archive_sha: str, expected_gate: dict) -> dict:
    if len(first_manifest_sha) != 64 or any(char not in "0123456789abcdef" for char in first_manifest_sha):
        raise ValueError("invalid first-result manifest fingerprint")
    first = PHASE / "basin_01047000"
    acceptance_path = first / "control/first_acceptance.json"
    if acceptance_path.exists() or acceptance_path.is_symlink():
        raise FileExistsError("first-basin acceptance already exists; no second attempt")
    deployed = _read_json(PHASE / "control/deployed.json")
    attempt_path = first / "control/submission_attempt.json"
    attempt = _read_json(attempt_path)
    submission = _read_json(first / "control/submission.json")
    job_gate = _read_json(first / "control/job_gate.json")
    supervisor = _read_json(first / "run/supervisor.json")
    started = _read_json(first / "run/model/started.json")
    job_id = _validate_first_control_chain(
        deployed=deployed,
        attempt=attempt,
        submission=submission,
        job_gate=job_gate,
        supervisor=supervisor,
        started=started,
        archive_sha=archive_sha,
        manifest_sha=manifest_sha,
        attempt_sha=_digest(attempt_path),
        expected_gate=expected_gate,
    )
    accounting = subprocess.run(
        ["sacct", "-X", "-j", job_id, "-P", "-n", "--format=JobID,JobName,Partition,AllocCPUS,ReqCPUS,AllocTRES,ReqTRES,ElapsedRaw,State,ExitCode"],
        check=True,
        text=True,
        capture_output=True,
        timeout=30,
    ).stdout
    rows = [line for line in accounting.splitlines() if line.strip()]
    if len(rows) != 1:
        raise RuntimeError("first-job accounting record was not unique")
    fields = rows[0].split("|")
    if len(fields) == 10:
        _require_exact_one_core_tres(fields[5], fields[6])
    if (
        len(fields) != 10
        or fields[0] != job_id
        or fields[1] != JOB_NAME
        or fields[2] != "hcpu48y"
        or fields[3:5] != ["1", "1"]
        or not fields[7].isdigit()
        or fields[8:] != ["COMPLETED", "0:0"]
    ):
        raise RuntimeError("first-job terminal state or billed resources changed")
    manifest = first / "run/model/manifest.final.sha256.json"
    if _digest(manifest) != first_manifest_sha:
        raise RuntimeError("first-result manifest fingerprint changed")
    sys.path.insert(0, str(PHASE / "bundle/hpc"))
    from verify_tukf09_two_basin_full_budget_v2 import verify_result_directory

    import numpy as np

    metadata = json.loads((PHASE / "bundle/input/metadata.json").read_text(encoding="utf-8"))
    row = metadata["basins"]["01047000"]
    audit = verify_result_directory(
        first / "run/model",
        basin_id="01047000",
        dimension=7,
        expected_scale=np.asarray(row["state_scale"], dtype=np.float64),
        expected_fixed_r_b=float(row["fixed_r_b"]),
        expected_source_gate=expected_gate,
        expected_bundle_manifest_sha256=manifest_sha,
        expected_python_executable=PYTHON,
        expected_private_python_path=PRIVATE,
    )
    output_bytes = sum(path.stat().st_size for path in first.rglob("*") if path.is_file())
    for path in (PHASE / "logs").glob(f"job-{job_id}.*"):
        if path.is_file() and not path.is_symlink():
            output_bytes += path.stat().st_size
    if output_bytes > 100 * 2**20:
        raise RuntimeError("first-job output exceeded the authorized threshold")
    record = {
        "status": "FIRST_BASIN_TECHNICAL_ACCEPTANCE_PASS_SECOND_NOT_AUTHORIZED",
        "bundle_manifest_sha256": manifest_sha,
        "result_manifest_sha256": first_manifest_sha,
        "job_id": job_id,
        "accounting": rows[0],
        "output_bytes": output_bytes,
        "independent_array_audit": audit,
    }
    _write_json_exclusive(acceptance_path, record)
    return record


def submit_second(archive_sha: str, manifest_sha: str, first_manifest_sha: str) -> None:
    raise PermissionError("second basin is not authorized in this recovery")
    if not PHASE.is_dir() or PHASE.is_symlink() or _digest(ARCHIVE) != archive_sha:
        raise RuntimeError("deployed phase or payload identity changed")
    expected_gate = _load_gate(manifest_sha)
    prerequisite = _first_job_acceptance(first_manifest_sha, manifest_sha, archive_sha, expected_gate)
    _submit_once("01142500", manifest_sha, archive_sha, prerequisite=prerequisite)


def main() -> None:
    if len(sys.argv) == 4 and sys.argv[1] == "--first":
        initialize_and_submit_first(sys.argv[2], sys.argv[3])
    elif len(sys.argv) == 5 and sys.argv[1] == "--second":
        submit_second(sys.argv[2], sys.argv[3], sys.argv[4])
    else:
        raise SystemExit("usage: deploy --first ARCHIVE_SHA MANIFEST_SHA | --second ARCHIVE_SHA MANIFEST_SHA FIRST_RESULT_MANIFEST_SHA")


if __name__ == "__main__":
    main()
