"""Standard-library gate for the authorized two-basin full-budget rehearsal."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path, PurePosixPath, PureWindowsPath
from typing import Any

STAGE = "TUKF09_455_TWO_BASIN_FULL_BUDGET_HPC_REHEARSAL_V2"
WINDOWS_ROOT = PureWindowsPath("G:/github/pycharm/projects/kalmannet")
REMOTE_PHASE = Path("/data1/home/sunyiq/kalmannet_tukf09_scaled_noise_rehearsal_20260922/full_budget_recovery_v2r6")
REMOTE_ROOT = REMOTE_PHASE / "bundle"
REMOTE_ROOT_POSIX = REMOTE_ROOT.as_posix()
SCIENCE = "hpc/tukf09_455_scaled_noise_local_transfer_contract_v1.json"
SCIENCE_SHA = "27239212680bd370bd76f40e53337b7d68d80cbe4dc01feac2164bab4917f8a1"
PARENT = "artifacts/tukf09_455_basin_zero_validation_target_variance_revision_v1/formal_evaluation_admission_compat_v5/formal_evaluation_admission.json"
PARENT_SHA = "1fbd45a829d2216d78e72a70c8ebc221a6e745d2078100ea895b4a44f6b15c5a"
SCALE_ROOT = "results/tukf09_455_scaled_noise_local_transfer_v1/state_scales_v1"
SCALE_SHA = "449ac52f3d16b8ae8b390f7a73f1a170b80d9a78d5b231ba8c403d01fc793702"
AUTH = "hpc/tukf09_two_basin_full_budget_execution_authorization_v2.json"
ADMISSION = "hpc/tukf09_two_basin_full_budget_implementation_admission_v2r6.json"
RECOVERY_AUTH = "hpc/tukf09_first_basin_recovery_authorization_v2r6.json"
SHORT_AUDIT = "input/full_budget_v2r4/short_probe_array_audit.json"
SHORT_AUDIT_SHA = "e924b61d0bb2d2220920da6d99515f97c1a3f9451d382d43ca94b50e28726697"
RESOURCE_RECEIPT = "input/full_budget_v2r4/resource_query_seq13.txt"
RESOURCE_RECEIPT_SHA = "cd24638fd726ff2ccabaf3ba2ac2ffa8754eda497b8892820080dd6ab6730269"
SAMPLES = (("01047000", 7), ("01142500", 20))
PER_BASIN_COUNTS = {
    "start_count": 8,
    "updates_per_start": 31,
    "checkpoints": 256,
    "gradient_updates": 248,
    "training_objective_calls": 256,
    "validation_objective_calls": 256,
    "evaluation_array_reads": 0,
}
PYTHON_EXECUTABLE = "/data1/home/sunyiq/miniconda3/envs/knet_clean/bin/python"
PRIVATE_PYTHON_PATH = "/data1/home/sunyiq/kalmannet_tukf09_455_basin_zero_validation_target_variance_revision_v1_a800_exclusive_v2r14_20260909/runtime_v2r14/pysite"


def read_json(path: Path) -> dict[str, Any]:
    def pairs(items):
        value = {}
        for key, item in items:
            if key in value:
                raise ValueError("duplicate JSON key: " + key)
            value[key] = item
        return value

    def constant(token):
        raise ValueError("non-finite JSON: " + token)

    value = json.loads(
        Path(path).read_text(encoding="utf-8"),
        object_pairs_hook=pairs,
        parse_constant=constant,
    )
    if not isinstance(value, dict):
        raise ValueError("expected JSON object")
    return value


def digest(path: Path) -> str:
    with Path(path).open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def file_record(path: Path) -> dict[str, Any]:
    source = Path(path)
    if not source.is_file() or source.is_symlink():
        raise RuntimeError("expected one regular unlinked file: " + str(source))
    return {"sha256": digest(source), "size_bytes": source.stat().st_size}


def require_file_record(path: Path, expected: dict[str, Any], *, label: str) -> None:
    if file_record(path) != expected:
        raise RuntimeError(label + " fingerprint or size changed")


def checked_path(root: Path, relative: str) -> Path:
    rel = PurePosixPath(relative)
    if (
        not relative
        or relative != rel.as_posix()
        or rel.is_absolute()
        or ".." in rel.parts
        or ":" in relative
        or "\\" in relative
    ):
        raise ValueError("invalid bundle-relative path")
    root = Path(root)
    target = root.joinpath(*rel.parts)
    target.resolve().relative_to(root.resolve())
    for candidate in (target, *target.parents):
        if candidate.is_symlink() or getattr(candidate, "is_junction", lambda: False)():
            raise ValueError("linked bundle path")
        if candidate == root:
            break
    if not target.is_file():
        raise FileNotFoundError(target)
    return target


def mapped_relative(original: str) -> str:
    source = PureWindowsPath(original)
    if not source.is_absolute() or ".." in source.parts:
        raise ValueError("invalid original Windows path")
    relative = source.relative_to(WINDOWS_ROOT)
    if not relative.parts:
        raise ValueError("root is not a source file")
    return PurePosixPath(*relative.parts).as_posix()


def validate_authorization(value: dict[str, Any]) -> None:
    expected_samples = [
        {"basin_id": basin, "dimension": dimension, "order": index + 1}
        for index, (basin, dimension) in enumerate(SAMPLES)
    ]
    resources = value.get("resources", {})
    runtime = value.get("runtime", {})
    if (
        value.get("schema_version") != "tukf09_two_basin_full_budget_execution_authorization_v2"
        or value.get("stage_id") != STAGE
        or value.get("authorized_mode") != "two-basin-serial-full-budget-technical-rehearsal"
        or value.get("remote_execution_authorized") is not True
        or value.get("formal_455_basin_execution_authorized") is not False
        or value.get("evaluation_authorized") is not False
        or value.get("transfer_authorized") is not False
        or value.get("scientific_contract_changes_authorized") is not False
        or value.get("samples") != expected_samples
        or value.get("per_basin_budget") != PER_BASIN_COUNTS
        or value.get("stop_on_any_failure") is not True
    ):
        raise PermissionError("execution authorization identity or scope changed")
    expected_resources = {
        "partition": "hcpu48y",
        "nodes": 1,
        "tasks": 1,
        "cpus_per_task": 1,
        "wall_seconds_per_job": 14400,
        "maximum_jobs": 2,
        "maximum_concurrent_jobs": 1,
        "maximum_scheduler_billed_core_hours": 8,
        "worker_address_space_bytes": 8 * 2**30,
        "process_tree_rss_stop_bytes": 8 * 2**30,
        "output_stop_bytes_per_job": 100 * 2**20,
        "automatic_retry_or_requeue": False,
    }
    if resources != expected_resources:
        raise PermissionError("authorized scheduler or process limits changed")
    if (
        runtime.get("python_executable") != PYTHON_EXECUTABLE
        or runtime.get("python_version_prefix") != "3.11.13"
        or runtime.get("private_python_path") != PRIVATE_PYTHON_PATH
        or runtime.get("numpy_version") != "1.26.4"
        or runtime.get("torch_version_prefix") != "2.2.2"
        or runtime.get("device") != "cpu"
        or runtime.get("precision") != "float64"
        or runtime.get("threads") != 1
    ):
        raise PermissionError("authorized numerical runtime changed")


def verify_basin(basin_id: str) -> int:
    matches = [dimension for basin, dimension in SAMPLES if basin == basin_id]
    if len(matches) != 1:
        raise PermissionError("basin is not one of the two authorized samples")
    return matches[0]


def verify_bundle(root: Path, manifest_digest: str, *, enforce_remote: bool = True) -> dict[str, Any]:
    root = Path(root)
    if root.is_symlink() or not root.is_dir():
        raise ValueError("bundle root is not one plain directory")
    if enforce_remote and root.resolve() != REMOTE_ROOT:
        raise PermissionError("unapproved remote bundle root")
    if len(manifest_digest) != 64 or any(c not in "0123456789abcdef" for c in manifest_digest):
        raise ValueError("invalid bundle manifest digest")
    manifest_path = checked_path(root, "bundle_manifest.json")
    if digest(manifest_path) != manifest_digest:
        raise RuntimeError("bundle manifest fingerprint changed")
    manifest = read_json(manifest_path)
    if manifest.get("stage_id") != STAGE:
        raise PermissionError("wrong full-budget stage")
    if manifest.get("path_mapping") != {
        "windows_root": str(WINDOWS_ROOT),
        "remote_root": REMOTE_ROOT_POSIX,
    }:
        raise PermissionError("root mapping changed")
    records = manifest.get("files")
    if not isinstance(records, dict) or not records:
        raise RuntimeError("bundle manifest has no file records")
    actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    if set(records) | {"bundle_manifest.json"} != actual:
        raise RuntimeError("bundle member set changed")
    for relative, expected in records.items():
        require_file_record(checked_path(root, relative), expected, label="bundle member " + relative)

    if digest(root / SCIENCE) != SCIENCE_SHA or digest(root / PARENT) != PARENT_SHA:
        raise RuntimeError("frozen scientific anchor changed")
    science = read_json(root / SCIENCE)
    for binding in (
        *science["lineage"]["input_seals"].values(),
        science["lineage"]["parent_scientific_contract"],
        science["lineage"]["completed_parent_evidence"]["filter_registry"],
    ):
        expected = {key: binding[key] for key in ("sha256", "size_bytes")}
        if file_record(checked_path(root, binding["path"])) != expected:
            raise RuntimeError("original input binding changed")

    parent = read_json(root / PARENT)
    sources = parent.get("production_source_sha256")
    if not isinstance(sources, dict) or len(sources) != 13:
        raise RuntimeError("parent production source count changed")
    mapped_sources = {}
    for name, sha in sources.items():
        record = parent["bindings"][name]
        relative = mapped_relative(record["path"])
        expected = {"sha256": sha, "size_bytes": record["size_bytes"]}
        if relative in mapped_sources or record["sha256"] != sha:
            raise RuntimeError("ambiguous parent source mapping")
        if file_record(checked_path(root, relative)) != expected:
            raise RuntimeError("parent production source changed")
        mapped_sources[relative] = {"original": record["path"], "sha256": sha}

    local_checks = read_json(root / "input/local_source_check.json")
    for group in (
        local_checks["anchors"],
        local_checks["original_implementation_files"],
        local_checks["production_sources"],
    ):
        for key, record in group.items():
            relative = record.get("path", key)
            if PureWindowsPath(relative).is_absolute():
                relative = mapped_relative(relative)
            actual_record = file_record(checked_path(root, relative))
            if actual_record != {"sha256": record["sha256"], "size_bytes": record["size_bytes"]}:
                raise RuntimeError("local source binding changed: " + relative)

    authorization = read_json(root / AUTH)
    validate_authorization(authorization)
    recovery = read_json(root / RECOVERY_AUTH)
    if (recovery.get("schema_version") != "tukf09_first_basin_recovery_authorization_v2r6"
            or recovery.get("remote_phase") != REMOTE_PHASE.as_posix()
            or recovery.get("authorized_basin_id") != "01047000"
            or recovery.get("maximum_new_submissions") != 1
            or recovery.get("second_basin_authorized") is not False
            or recovery.get("formal_evaluation_authorized") is not False
            or recovery.get("failed_job_id") != "227494"):  # technical retry, not a new science contract
        raise PermissionError("technical recovery authorization changed")
    admission = read_json(root / ADMISSION)
    if admission.get("recovery_authorization_sha256") != digest(root / RECOVERY_AUTH):
        raise PermissionError("technical recovery authorization fingerprint changed")
    if (
        admission.get("schema_version") != "tukf09_two_basin_full_budget_implementation_admission_v2r6"
        or admission.get("stage_id") != STAGE
        or admission.get("status") != "FIRST_BASIN_TECHNICAL_RECOVERY_ONLY_ADMITTED"
        or admission.get("authorization_sha256") != digest(root / AUTH)
        or admission.get("scientific_contract_sha256") != SCIENCE_SHA
    ):
        raise PermissionError("implementation admission identity or anchor changed")
    implementation = admission.get("implementation_files")
    if not isinstance(implementation, dict) or not implementation:
        raise PermissionError("implementation admission file set missing")
    for relative, expected in implementation.items():
        if file_record(checked_path(root, relative)) != expected:
            raise RuntimeError("admitted implementation changed: " + relative)
    report = admission.get("local_test_report")
    if not isinstance(report, dict) or file_record(checked_path(root, report["path"])) != {
        "sha256": report["sha256"],
        "size_bytes": report["size_bytes"],
    }:
        raise RuntimeError("admitted local test report changed")
    if report.get("failures") != 0 or report.get("errors") != 0 or report.get("skipped") != 0:
        raise PermissionError("admitted local tests were not all passing")

    if digest(root / SHORT_AUDIT) != SHORT_AUDIT_SHA:
        raise RuntimeError("short-probe audit evidence changed")
    short_audit = read_json(root / SHORT_AUDIT)
    if short_audit.get("status") != "PASS_NOT_FORMAL_RESULT":
        raise PermissionError("short-probe array audit did not pass")
    if digest(root / RESOURCE_RECEIPT) != RESOURCE_RECEIPT_SHA:
        raise RuntimeError("resource query receipt changed")
    receipt = (root / RESOURCE_RECEIPT).read_text(encoding="utf-8")
    for required in (
        "### channel=kalmannet-tukf09-noise-20260922 seq=13",
        "OverSubscribe=NO",
        "State=UP",
        "227288|tukf09-noise-2probe-v2|hcpu48y|1|1|billing=1,cpu=1,node=1|billing=1,cpu=1,node=1|135|COMPLETED|0:0",
        "### exit_code=0",
    ):
        if receipt.count(required) != 1:
            raise RuntimeError("resource query evidence is missing or ambiguous")

    metadata = read_json(root / "input/metadata.json")
    if metadata.get("evaluation_array_reads") != 0 or list(metadata.get("basins", {})) != [b for b, _ in SAMPLES]:
        raise PermissionError("sample order or evaluation boundary changed")
    semantics = read_json(root / science["lineage"]["input_seals"]["semantic_input_manifest"]["path"])["members"]
    scales = root / SCALE_ROOT
    if digest(scales / "manifest.final.sha256.json") != SCALE_SHA:
        raise RuntimeError("scale provenance changed")
    scale_members = read_json(scales / "manifest.final.sha256.json")["files"]
    for basin, dimension in SAMPLES:
        row = metadata["basins"][basin]
        if row.get("dimension") != dimension or set(row.get("semantic_members", {})) != {"training", "validation"}:
            raise PermissionError("dimension or period changed")
        for period in ("training", "validation"):
            if set(row["semantic_members"][period]) != {"dates_ns", "forcing", "observations"}:
                raise PermissionError("unexpected semantic input field")
            for name, value in row["semantic_members"][period].items():
                if value != semantics[f"{basin}/{period}/{name}"]:
                    raise RuntimeError("semantic input provenance changed")
        for name in ("identity.json", "summary.json", "manifest.final.sha256.json", "state_scale_arrays.npz"):
            relative = f"basin_{basin}/{name}"
            if file_record(scales / relative) != scale_members[relative]:
                raise RuntimeError("sealed scale member changed")
        identity = read_json(scales / f"basin_{basin}/identity.json")
        summary = read_json(scales / f"basin_{basin}/summary.json")
        if row["state_scale"] != summary["state_scale"] or summary["state_dimension"] != dimension:
            raise RuntimeError("sealed scale value changed")
        expected_parameters = dict(zip(identity["parameter_row"]["parameter_names"], identity["parameter_row"]["values"]))
        if row["parameters"] != expected_parameters:
            raise RuntimeError("parameter row provenance changed")

    return {
        "stage_id": STAGE,
        "manifest_sha256": manifest_digest,
        "parent_source_count": len(mapped_sources),
        "member_count": len(records),
        "samples": [{"basin_id": b, "dimension": d} for b, d in SAMPLES],
        "model_import_performed": False,
        "evaluation_array_reads": 0,
    }


__all__ = [
    "ADMISSION",
    "AUTH",
    "PER_BASIN_COUNTS",
    "PRIVATE_PYTHON_PATH",
    "PYTHON_EXECUTABLE",
    "REMOTE_PHASE",
    "REMOTE_ROOT",
    "SAMPLES",
    "STAGE",
    "checked_path",
    "digest",
    "file_record",
    "require_file_record",
    "read_json",
    "validate_authorization",
    "verify_basin",
    "verify_bundle",
]
