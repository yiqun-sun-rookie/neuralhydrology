"""Run fixed no-model and synthetic checks inside each authorized job."""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

from tukf09_two_basin_full_budget_gate_v2 import (
    PRIVATE_PYTHON_PATH,
    REMOTE_PHASE,
    REMOTE_ROOT,
    verify_basin,
    verify_bundle,
)

SMALL_SOFT_BYTES = 256 * 2**20
WORKER_HARD_BYTES = 8 * 2**30


def _small_process_limit() -> None:
    import resource

    resource.setrlimit(resource.RLIMIT_AS, (SMALL_SOFT_BYTES, WORKER_HARD_BYTES))


def _parse_report(path: Path, expected: int) -> dict[str, int]:
    suites = list(ET.parse(path).getroot().iter("testsuite"))
    if not suites:
        raise RuntimeError("pytest report contains no test suite")
    totals = {
        name: sum(int(suite.attrib.get(name, "0")) for suite in suites)
        for name in ("tests", "failures", "errors", "skipped")
    }
    if totals != {"tests": expected, "failures": 0, "errors": 0, "skipped": 0}:
        raise RuntimeError("unexpected pytest result: " + json.dumps(totals, sort_keys=True))
    return totals


def _run_small_tests(command: list[str], report: Path, expected: int, environment: dict[str, str]) -> dict[str, int]:
    subprocess.run(
        command,
        check=True,
        timeout=240,
        env=environment,
        preexec_fn=_small_process_limit if sys.platform == "linux" else None,
    )
    return _parse_report(report, expected)


def _run_with_test_pythonpath(runner, command, output_dir, *, environment, **limits):
    """Give only the supervised tensor-test subprocess the bundled test tools."""
    previous = os.environ.get("PYTHONPATH")
    try:
        os.environ["PYTHONPATH"] = environment["PYTHONPATH"]
        return runner(command, output_dir, **limits)
    finally:
        if previous is None:
            os.environ.pop("PYTHONPATH", None)
        else:
            os.environ["PYTHONPATH"] = previous


def main(basin_id: str) -> None:
    verify_basin(basin_id)
    gate = verify_bundle(REMOTE_ROOT, os.environ["TUKF09_BUNDLE_SHA256"])
    basin = REMOTE_PHASE / f"basin_{basin_id}"
    control = basin / "control"
    if not control.is_dir() or control.is_symlink():
        raise RuntimeError("exclusive basin control directory is missing")
    final_record = control / "job_gate.json"
    original_temp = control / "original_tests_tmp"
    original_report = control / "original_tests.xml"
    new_temp = control / "new_gate_tests_tmp"
    new_report = control / "new_gate_tests.xml"
    tensor_run = control / "tensor_tests"
    for path in (final_record, original_temp, original_report, new_temp, new_report, tensor_run):
        if path.exists() or path.is_symlink():
            raise FileExistsError("job-gate output already exists: " + str(path))

    python_path = ":".join(
        (
            str(REMOTE_ROOT / "vendor"),
            PRIVATE_PYTHON_PATH,
            str(REMOTE_ROOT),
            str(REMOTE_ROOT / "hpc"),
        )
    )
    environment = dict(
        os.environ,
        PYTHONNOUSERSITE="1",
        PYTHONDONTWRITEBYTECODE="1",
        PYTEST_DISABLE_PLUGIN_AUTOLOAD="1",
        PYTHONPATH=python_path,
    )
    base = [sys.executable, "-B", "-m", "pytest", "-q", "-p", "no:cacheprovider"]
    original_command = base + [
        "--basetemp",
        str(original_temp),
        "--junitxml",
        str(original_report),
        str(REMOTE_ROOT / "hpc/test_tukf09_two_basin_hpc_supervisor_v1.py"),
        str(REMOTE_ROOT / "hpc/test_tukf09_two_basin_hpc_gate_v1.py"),
    ]
    original = _run_small_tests(original_command, original_report, 41, environment)

    new_command = base + [
        "-k",
        "not tensor",
        "--basetemp",
        str(new_temp),
        "--junitxml",
        str(new_report),
        str(REMOTE_ROOT / "hpc/test_tukf09_two_basin_full_budget_v2.py"),
    ]
    new_gate = _run_small_tests(new_command, new_report, 44, environment)

    job_start = float(os.environ["TUKF09_JOB_START_UNIX"])
    remaining = 14400.0 - (time.time() - job_start) - 120.0
    if remaining <= 120.0:
        raise RuntimeError("insufficient job time remains for synthetic tests and model")
    from tukf09_two_basin_hpc_supervisor_v1 import run_supervised

    tensor_report = tensor_run / "tensor_tests.xml"
    tensor_command = base + [
        "-k",
        "tensor",
        "--basetemp",
        str(tensor_run / "tmp"),
        "--junitxml",
        str(tensor_report),
        str(REMOTE_ROOT / "hpc/test_tukf09_two_basin_full_budget_v2.py"),
    ]
    supervised = _run_with_test_pythonpath(
        run_supervised,
        tensor_command,
        tensor_run,
        environment=environment,
        wall_seconds=min(600.0, remaining - 60.0),
        rss_limit_bytes=WORKER_HARD_BYTES,
        address_space_limit_bytes=WORKER_HARD_BYTES,
        output_limit_bytes=16 * 2**20,
        poll_seconds=1.0,
    )
    if not supervised["success"]:
        raise RuntimeError("supervised tensor tests failed: " + json.dumps(supervised, sort_keys=True))
    tensor = _parse_report(tensor_report, 14)
    record = {
        "stage_id": gate["stage_id"],
        "basin_id": basin_id,
        "status": "ALL_JOB_TESTS_PASSED_MODEL_MAY_START",
        "original_linux_protection_tests": original,
        "new_standard_library_gate_tests": new_gate,
        "synthetic_tensor_loop_tests": tensor,
        "synthetic_tensor_supervisor": supervised,
        "model_calls": 0,
        "evaluation_array_reads": 0,
        "elapsed_seconds": time.time() - job_start,
    }
    with final_record.open("x", encoding="utf-8") as stream:
        json.dump(record, stream, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
        stream.write("\n")
    print("FULL_BUDGET_JOB_GATE_ALL_TESTS_PASSED " + json.dumps(record, separators=(",", ":")), flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("requires one authorized basin id")
    main(sys.argv[1])
