"""Derive an isolated first-basin technical retry from the sealed v2r4 bundle."""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
CONTROL = ROOT / "results/tukf09_455_scaled_noise_local_transfer_v1/control/two_basin_full_budget_hpc_v2"
SOURCE = CONTROL / "bundle_v2r4/full_budget_v2r4.zip"
DESTINATION = CONTROL / "recovery_v2r6/bundle"
REPORT = CONTROL / "recovery_v2r6/local_tests_final_001.xml"
SOURCE_SHA = "724e7d8816aad8ce9b83775e21130645e066cc61e1488bf349f3429d8b0b431d"
SOURCE_MANIFEST_SHA = "03efc5f263779b6341e9580bc8cde42308adf9e816247ebaa235431d91996662"
FAILURE_SHA = "e1a2feba3379cfbc17f9204ca794405ac6df4202018f5d379a323b4db76a7f10"
OLD_PHASE = "/data1/home/sunyiq/kalmannet_tukf09_scaled_noise_rehearsal_20260922/full_budget_v2"
NEW_PHASE = "/data1/home/sunyiq/kalmannet_tukf09_scaled_noise_rehearsal_20260922/full_budget_recovery_v2r6"
OLD_ARCHIVE = "/data1/home/sunyiq/hpc_mailbox/inbox/kalmannet-tukf09-noise-20260922/payload/full_budget_v2r4.zip"
NEW_ARCHIVE = "/data1/home/sunyiq/hpc_mailbox/inbox/kalmannet-tukf09-noise-20260922/payload/full_budget_recovery_v2r6.zip"
NEW_NAME = "tukf09-noise-recover-v2r6"
AUTH_PATH = "hpc/tukf09_first_basin_recovery_authorization_v2r6.json"
ADMISSION_PATH = "hpc/tukf09_two_basin_full_budget_implementation_admission_v2r6.json"
REPORT_PATH = "input/recovery_v2r6/local_tests_final_001.xml"
BUILDER_PATH = "hpc/build_tukf09_first_basin_recovery_v2r6.py"
TEST_PATH = "hpc/test_tukf09_first_basin_recovery_v2r6.py"
PLAN_PATH = "docs/plans/2026-09-24-tukf09-first-basin-supervised-test-path-recovery-v2r6.md"
PATCHED = frozenset({
    "hpc/tukf09_two_basin_full_budget_gate_v2.py",
    "hpc/tukf09_two_basin_full_budget_job_gate_v2.py",
    "hpc/tukf09_two_basin_full_budget_job_v2.slurm",
    "hpc/tukf09_two_basin_full_budget_deploy_v2.py",
})
ADDED = frozenset({AUTH_PATH, ADMISSION_PATH, REPORT_PATH, BUILDER_PATH, TEST_PATH, PLAN_PATH})
PRIVATE = "/data1/home/sunyiq/kalmannet_tukf09_455_basin_zero_validation_target_variance_revision_v1_a800_exclusive_v2r14_20260909/runtime_v2r14/pysite"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def record(data: bytes) -> dict[str, object]:
    return {"sha256": sha(data), "size_bytes": len(data)}


def json_bytes(value: dict) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")


def long_path(path: Path) -> Path:
    resolved = path.resolve()
    return Path("\\\\?\\" + str(resolved)) if sys.platform == "win32" else resolved


def replace_once(source: str, old: str, new: str) -> str:
    if source.count(old) != 1:
        raise RuntimeError(f"expected exactly one occurrence of {old!r}, found {source.count(old)}")
    return source.replace(old, new)


def _read_source() -> tuple[dict[str, bytes], dict]:
    if sha(SOURCE.read_bytes()) != SOURCE_SHA:
        raise RuntimeError("sealed v2r4 archive changed")
    files: dict[str, bytes] = {}
    with zipfile.ZipFile(SOURCE) as archive:
        for member in archive.infolist():
            name = member.filename
            relative = PurePosixPath(name)
            mode = member.external_attr >> 16
            if (
                not name or relative.as_posix() != name or relative.is_absolute()
                or ".." in relative.parts or ":" in name or "\\" in name
                or member.is_dir() or stat.S_IFMT(mode) not in (0, stat.S_IFREG)
                or name in files
            ):
                raise RuntimeError("unsafe source archive member")
            files[name] = archive.read(member)
    if sha(files["bundle_manifest.json"]) != SOURCE_MANIFEST_SHA:
        raise RuntimeError("sealed v2r4 manifest changed")
    manifest = json.loads(files["bundle_manifest.json"])
    if set(manifest["files"]) | {"bundle_manifest.json"} != set(files):
        raise RuntimeError("source manifest member set changed")
    for name, expected in manifest["files"].items():
        if record(files[name]) != expected:
            raise RuntimeError("source bundle member changed: " + name)
    return files, manifest


def _patch_gate(source: str) -> str:
    value = replace_once(source, OLD_PHASE, NEW_PHASE)
    value = replace_once(
        value,
        'ADMISSION = "hpc/tukf09_two_basin_full_budget_implementation_admission_v2r4.json"',
        f'ADMISSION = "{ADMISSION_PATH}"\nRECOVERY_AUTH = "{AUTH_PATH}"',
    )
    value = replace_once(
        value,
        'admission.get("schema_version") != "tukf09_two_basin_full_budget_implementation_admission_v2r4"',
        'admission.get("schema_version") != "tukf09_two_basin_full_budget_implementation_admission_v2r6"',
    )
    value = replace_once(
        value,
        'admission.get("status") != "IMPLEMENTATION_AND_TESTS_ADMITTED_FOR_SERIAL_CHAIN_WITH_FIRST_JOB_GATE"',
        'admission.get("status") != "FIRST_BASIN_TECHNICAL_RECOVERY_ONLY_ADMITTED"',
    )
    value = replace_once(
        value,
        '    admission = read_json(root / ADMISSION)\n',
        '    recovery = read_json(root / RECOVERY_AUTH)\n'
        '    if (recovery.get("schema_version") != "tukf09_first_basin_recovery_authorization_v2r6"\n'
        '            or recovery.get("remote_phase") != REMOTE_PHASE.as_posix()\n'
        '            or recovery.get("authorized_basin_id") != "01047000"\n'
        '            or recovery.get("maximum_new_submissions") != 1\n'
        '            or recovery.get("second_basin_authorized") is not False\n'
        '            or recovery.get("formal_evaluation_authorized") is not False\n'
        '            or recovery.get("failed_job_id") != "227494"):  # technical retry, not a new science contract\n'
        '        raise PermissionError("technical recovery authorization changed")\n'
        '    admission = read_json(root / ADMISSION)\n'
        '    if admission.get("recovery_authorization_sha256") != digest(root / RECOVERY_AUTH):\n'
        '        raise PermissionError("technical recovery authorization fingerprint changed")\n',
    )
    ast.parse(value)
    return value


def _patch_job_gate(source: str) -> str:
    helper = '''def _run_with_test_pythonpath(runner, command, output_dir, *, environment, **limits):
    """Give only the supervised tensor-test subprocess the bundled test tools."""
    previous = os.environ.get("PYTHONPATH")
    try:
        os.environ["PYTHONPATH"] = environment["PYTHONPATH"]
        return runner(command, output_dir, **limits)
    finally:
        if previous is None:
            os.environ.pop("PYTHONPATH", None)
        else:
            os.environ["PYTHONPATH"] = previous


'''
    value = replace_once(source, 'def main(basin_id: str) -> None:\n', helper + 'def main(basin_id: str) -> None:\n')
    value = replace_once(
        value,
        '    supervised = run_supervised(\n        tensor_command,\n        tensor_run,\n',
        '    supervised = _run_with_test_pythonpath(\n        run_supervised,\n        tensor_command,\n        tensor_run,\n        environment=environment,\n',
    )
    ast.parse(value)
    return value


def _patch_slurm(source: str) -> str:
    value = replace_once(source, "#SBATCH --job-name=tukf09-noise-full-v2", f"#SBATCH --job-name={NEW_NAME}")
    if value.count(OLD_PHASE) != 5:
        raise RuntimeError("unexpected old phase occurrences in job script")
    value = value.replace(OLD_PHASE, NEW_PHASE)
    value = replace_once(value, "  01047000|01142500) ;;", "  01047000) ;;")
    if value.count(f"export PYTHONPATH={PRIVATE}") != 1 or "bundle/vendor" in value:
        raise RuntimeError("model Python path must remain unchanged")
    return value


def _patch_deploy(source: str) -> str:
    if source.count(OLD_PHASE) != 1:
        raise RuntimeError("unexpected old phase occurrences in deployer")
    value = source.replace(OLD_PHASE, NEW_PHASE)
    value = replace_once(value, OLD_ARCHIVE, NEW_ARCHIVE)
    value = replace_once(value, 'JOB_NAME = "tukf09-noise-full-v2"', f'JOB_NAME = "{NEW_NAME}"')
    value = replace_once(value, 'SAMPLES = ("01047000", "01142500")', 'SAMPLES = ("01047000",)')
    value = replace_once(
        value,
        'def submit_second(archive_sha: str, manifest_sha: str, first_manifest_sha: str) -> None:\n',
        'def submit_second(archive_sha: str, manifest_sha: str, first_manifest_sha: str) -> None:\n'
        '    raise PermissionError("second basin is not authorized in this recovery")\n',
    )
    value = replace_once(
        value,
        'FIRST_BASIN_TECHNICAL_ACCEPTANCE_PASS_SECOND_SUBMISSION_ALLOWED',
        'FIRST_BASIN_TECHNICAL_ACCEPTANCE_PASS_SECOND_NOT_AUTHORIZED',
    )
    ast.parse(value)
    return value


def derive_files() -> tuple[dict[str, bytes], dict[str, bytes], dict]:
    original, old_manifest = _read_source()
    files = dict(original)
    for name, patcher in (
        ("hpc/tukf09_two_basin_full_budget_gate_v2.py", _patch_gate),
        ("hpc/tukf09_two_basin_full_budget_job_gate_v2.py", _patch_job_gate),
        ("hpc/tukf09_two_basin_full_budget_job_v2.slurm", _patch_slurm),
        ("hpc/tukf09_two_basin_full_budget_deploy_v2.py", _patch_deploy),
    ):
        files[name] = patcher(original[name].decode("utf-8")).encode("utf-8")
    for name, path in ((AUTH_PATH, ROOT / AUTH_PATH), (BUILDER_PATH, ROOT / BUILDER_PATH),
                       (TEST_PATH, ROOT / TEST_PATH), (PLAN_PATH, ROOT / PLAN_PATH), (REPORT_PATH, REPORT)):
        if not path.is_file() or path.is_symlink():
            raise RuntimeError("new source missing or linked: " + str(path))
        files[name] = path.read_bytes()
    recovery_auth = json.loads(files[AUTH_PATH])
    if (
        recovery_auth.get("failed_evidence_sha256") != FAILURE_SHA
        or recovery_auth.get("remote_phase") != NEW_PHASE
        or recovery_auth.get("authorized_basin_id") != "01047000"
        or recovery_auth.get("maximum_new_submissions") != 1
    ):
        raise PermissionError("local recovery authorization does not match failed job or scope")
    old_admission = json.loads(original["hpc/tukf09_two_basin_full_budget_implementation_admission_v2r4.json"])
    admission = dict(old_admission)
    admission["schema_version"] = "tukf09_two_basin_full_budget_implementation_admission_v2r6"
    admission["status"] = "FIRST_BASIN_TECHNICAL_RECOVERY_ONLY_ADMITTED"
    admission["previous_implementation_admission_sha256"] = sha(original["hpc/tukf09_two_basin_full_budget_implementation_admission_v2r4.json"])
    admission["recovery_authorization_sha256"] = sha(files[AUTH_PATH])
    implementation = dict(old_admission["implementation_files"])
    for name in PATCHED | {BUILDER_PATH, TEST_PATH}:
        implementation[name] = record(files[name])
    admission["implementation_files"] = implementation
    import xml.etree.ElementTree as ET
    suites = list(ET.fromstring(files[REPORT_PATH]).iter("testsuite"))
    totals = {key: sum(int(suite.get(key, "0")) for suite in suites) for key in ("tests", "failures", "errors", "skipped")}
    if not suites or totals["tests"] < 6 or any(totals[key] for key in ("failures", "errors", "skipped")):
        raise RuntimeError("new local tests are not all passing")
    admission["local_test_report"] = {"path": REPORT_PATH, **record(files[REPORT_PATH]), **totals}
    admission["second_job_requires_first_job_independent_acceptance"] = False
    admission["second_job_submission_authorized"] = False
    files[ADMISSION_PATH] = json_bytes(admission)
    manifest = dict(old_manifest)
    manifest["schema_version"] = "tukf09_two_basin_full_budget_bundle_manifest_v2r6"
    manifest["path_mapping"] = dict(old_manifest["path_mapping"], remote_root=NEW_PHASE + "/bundle")
    manifest["parent_bundle_manifest_sha256"] = SOURCE_MANIFEST_SHA
    manifest["files"] = {name: record(data) for name, data in sorted(files.items()) if name != "bundle_manifest.json"}
    files["bundle_manifest.json"] = json_bytes(manifest)
    changed = {name for name in original if files[name] != original[name]}
    if changed != PATCHED | {"bundle_manifest.json"}:
        raise RuntimeError("unexpected source-bundle member change: " + repr(sorted(changed)))
    if set(files) - set(original) != ADDED:
        raise RuntimeError("unexpected added bundle members")
    return original, files, manifest


def build() -> dict:
    if DESTINATION.exists() or DESTINATION.is_symlink():
        raise FileExistsError("recovery bundle destination already exists")
    evidence = CONTROL / "tensor_failure_evidence_seq18_v5.txt"
    if sha(evidence.read_bytes()) != FAILURE_SHA:
        raise RuntimeError("failed-job evidence changed")
    original, files, manifest = derive_files()
    extracted = long_path(DESTINATION / "extracted")
    extracted.mkdir(parents=True, exist_ok=False)
    for name, data in sorted(files.items()):
        target = extracted.joinpath(*PurePosixPath(name).parts)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(data)
    gate_path = extracted / "hpc/tukf09_two_basin_full_budget_gate_v2.py"
    namespace = {"__name__": "first_basin_recovery_gate_v2r6"}
    exec(compile(gate_path.read_bytes(), str(gate_path), "exec"), namespace)
    gate = namespace["verify_bundle"](extracted, sha(files["bundle_manifest.json"]), enforce_remote=False)
    archive_path = long_path(DESTINATION / "full_budget_recovery_v2r6.zip")
    with zipfile.ZipFile(archive_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 9, 24, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (stat.S_IFREG | 0o640) << 16
            archive.writestr(info, data)
    if archive_path.stat().st_size > 10 * 2**20:
        raise RuntimeError("recovery payload exceeds mailbox limit")
    receipt = {
        "status": "FIRST_BASIN_RECOVERY_BUNDLE_BUILT_NOT_PUBLISHED",
        "source_archive_sha256": SOURCE_SHA,
        "source_manifest_sha256": SOURCE_MANIFEST_SHA,
        "source_member_count": len(original),
        "new_member_count": len(files),
        "patched_source_members": sorted(PATCHED),
        "added_members": sorted(ADDED),
        "bundle_manifest_sha256": sha(files["bundle_manifest.json"]),
        "archive": record(archive_path.read_bytes()),
        "gate": gate,
        "model_calls": 0,
        "evaluation_array_reads": 0,
    }
    with long_path(DESTINATION / "bundle_build_receipt.json").open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")
    return receipt


if __name__ == "__main__":
    print(json.dumps(build(), ensure_ascii=False, sort_keys=True, indent=2))
