"""Independent array/result verifier; does not import the production selector or model."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from pathlib import PurePosixPath
from typing import Any

import numpy as np

STAGE = "TUKF09_455_TWO_BASIN_FULL_BUDGET_HPC_REHEARSAL_V2"
EXPERIMENT = "TUKF09_455_SCALED_NOISE_LOCAL_TRANSFER_V1"
EXPECTED_HISTORY_MEMBERS = {
    "checkpoint_index",
    "start_index",
    "update_index",
    "theta_log",
    "process_variance_actual",
    "training_objective",
    "validation_objective",
    "sealed_state_scale",
}


def _read_json(path: Path) -> dict[str, Any]:
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate JSON key: " + key)
            result[key] = value
        return result

    def constant(token):
        raise ValueError("non-finite JSON token: " + token)

    value = json.loads(Path(path).read_text(encoding="utf-8"), object_pairs_hook=pairs, parse_constant=constant)
    if not isinstance(value, dict):
        raise ValueError("JSON root must be an object")
    return value


def _sha256(path: Path) -> str:
    with Path(path).open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def _record(path: Path) -> dict[str, Any]:
    source = Path(path)
    if not source.is_file() or source.is_symlink():
        raise RuntimeError("result member must be a regular unlinked file")
    return {"sha256": _sha256(source), "size_bytes": source.stat().st_size}


def positive_float64_ulp_distance(left: np.ndarray, right: np.ndarray) -> np.ndarray:
    """Return bit-pattern distance for aligned positive finite native float64 arrays."""
    a = np.asarray(left)
    b = np.asarray(right)
    if (
        a.shape != b.shape
        or a.dtype != np.dtype(np.float64)
        or b.dtype != np.dtype(np.float64)
        or not a.dtype.isnative
        or not b.dtype.isnative
        or not np.isfinite(a).all()
        or not np.isfinite(b).all()
        or np.any(a <= 0.0)
        or np.any(b <= 0.0)
    ):
        raise ValueError("ULP comparison requires aligned positive finite native float64 arrays")
    au = np.ascontiguousarray(a).view(np.uint64)
    bu = np.ascontiguousarray(b).view(np.uint64)
    return np.maximum(au, bu) - np.minimum(au, bu)


def require_q_exp_within_one_ulp(theta_log: np.ndarray, process_variance: np.ndarray) -> dict[str, int]:
    theta = np.asarray(theta_log)
    q = np.asarray(process_variance)
    if theta.dtype != np.dtype(np.float64) or not theta.dtype.isnative or not np.isfinite(theta).all():
        raise ValueError("theta history must be finite native float64")
    recomputed = np.exp(theta)
    distance = positive_float64_ulp_distance(q, recomputed)
    maximum = int(distance.max(initial=np.uint64(0)))
    if maximum > 1:
        raise RuntimeError("saved process variance differs from exp(theta) by more than one float64 ULP")
    return {"unequal_coordinates": int(np.count_nonzero(distance)), "maximum_ulp_distance": maximum}


def independent_selected_index(
    process_variance: np.ndarray,
    training_objective: np.ndarray,
    validation_objective: np.ndarray,
) -> int:
    q = np.asarray(process_variance)
    training = np.asarray(training_objective)
    validation = np.asarray(validation_objective)
    if (
        q.ndim != 2
        or q.dtype != np.dtype(np.float64)
        or not q.dtype.isnative
        or training.shape != (len(q),)
        or validation.shape != (len(q),)
        or training.dtype != np.dtype(np.float64)
        or validation.dtype != np.dtype(np.float64)
        or not np.isfinite(q).all()
        or np.any(q <= 0.0)
        or not np.isfinite(training).all()
        or not np.isfinite(validation).all()
    ):
        raise ValueError("invalid checkpoint arrays for independent selection")
    return min(
        range(len(q)),
        key=lambda index: (
            float(validation[index]),
            float(training[index]),
            tuple(float(value) for value in q[index]),
            int(index),
        ),
    )


def validate_started_identity(
    started: dict[str, Any],
    *,
    expected_source_gate: dict[str, Any],
    expected_bundle_manifest_sha256: str,
    expected_python_executable: str,
    expected_private_python_path: str,
) -> None:
    runtime = started.get("runtime", {})
    source_gate = started.get("source_gate", {})
    expected_counts = {
        "start_count": 8,
        "updates_per_start": 31,
        "checkpoints": 256,
        "gradient_updates": 248,
        "training_objective_calls": 256,
        "validation_objective_calls": 256,
        "evaluation_array_reads": 0,
    }
    private = PurePosixPath(expected_private_python_path)
    if not private.is_absolute() or ".." in private.parts:
        raise RuntimeError("admitted private path is not absolute and canonical")
    runtime_paths = [PurePosixPath(str(runtime.get(name, ""))) for name in ("numpy_path", "torch_path")]
    if any(not path.is_absolute() or ".." in path.parts for path in runtime_paths):
        raise RuntimeError("numerical package path is not absolute and canonical")
    try:
        numpy_relative = runtime_paths[0].relative_to(private)
        torch_relative = runtime_paths[1].relative_to(private)
    except ValueError as exc:
        raise RuntimeError("numerical package was not loaded from the admitted private path") from exc
    if not numpy_relative.parts or not torch_relative.parts:
        raise RuntimeError("numerical package path equals rather than lies below the private path")
    if (
        started.get("counts_authorized") != expected_counts
        or source_gate != expected_source_gate
        or source_gate.get("stage_id") != STAGE
        or source_gate.get("manifest_sha256") != expected_bundle_manifest_sha256
        or source_gate.get("model_import_performed") is not False
        or source_gate.get("evaluation_array_reads") != 0
        or runtime.get("python_executable") != expected_python_executable
        or not str(runtime.get("python", "")).startswith("3.11.13")
        or runtime.get("numpy") != "1.26.4"
        or not str(runtime.get("torch", "")).startswith("2.2.2")
        or runtime.get("device") != "cpu"
        or runtime.get("precision") != "float64"
        or runtime.get("torch_threads") != 1
        or runtime.get("torch_interop_threads") != 1
    ):
        raise RuntimeError("runtime, source gate, bundle fingerprint, or authorized counts changed")


def verify_result_directory(
    result_root: Path,
    *,
    basin_id: str,
    dimension: int,
    expected_scale: np.ndarray,
    expected_fixed_r_b: float,
    expected_source_gate: dict[str, Any],
    expected_bundle_manifest_sha256: str,
    expected_python_executable: str,
    expected_private_python_path: str,
) -> dict[str, Any]:
    root = Path(result_root)
    if not root.is_dir() or root.is_symlink():
        raise RuntimeError("result root must be one plain directory")
    manifest_path = root / "manifest.final.sha256.json"
    manifest = _read_json(manifest_path)
    expected_files = {"started.json", "summary.json", "history.npz"}
    actual_files = {path.relative_to(root).as_posix() for path in root.rglob("*") if path.is_file()}
    if actual_files != expected_files | {"manifest.final.sha256.json"}:
        raise RuntimeError("result member set changed")
    if (
        manifest.get("schema_version") != "tukf09_two_basin_full_budget_result_manifest_v2"
        or manifest.get("experiment_id") != EXPERIMENT
        or manifest.get("status") != "TWO_BASIN_FULL_BUDGET_SINGLE_BASIN_COMPLETE"
        or manifest.get("file_count") != 3
        or set(manifest.get("files", {})) != expected_files
    ):
        raise RuntimeError("result manifest identity or membership changed")
    for relative, record in manifest["files"].items():
        if _record(root / relative) != record:
            raise RuntimeError("result manifest binding changed: " + relative)

    started = _read_json(root / "started.json")
    summary = _read_json(root / "summary.json")
    if (
        started.get("stage_id") != STAGE
        or started.get("basin_id") != basin_id
        or started.get("dimension") != dimension
        or started.get("evaluation_array_reads") != 0
        or summary.get("stage_id") != STAGE
        or summary.get("status") != "FULL_BUDGET_SINGLE_BASIN_COMPLETE_NOT_FORMAL_EVALUATION"
        or summary.get("basin_id") != basin_id
        or summary.get("dimension") != dimension
        or summary.get("evaluation_array_reads") != 0
    ):
        raise RuntimeError("started/summary stage or sample identity changed")
    validate_started_identity(
        started,
        expected_source_gate=expected_source_gate,
        expected_bundle_manifest_sha256=expected_bundle_manifest_sha256,
        expected_python_executable=expected_python_executable,
        expected_private_python_path=expected_private_python_path,
    )

    with np.load(root / "history.npz", allow_pickle=False) as archive:
        if set(archive.files) != EXPECTED_HISTORY_MEMBERS or len(archive.files) != len(EXPECTED_HISTORY_MEMBERS):
            raise RuntimeError("history member set changed")
        arrays = {name: archive[name] for name in archive.files}
    for name in ("theta_log", "process_variance_actual"):
        value = arrays[name]
        if value.shape != (256, dimension) or value.dtype != np.dtype(np.float64) or not value.dtype.isnative:
            raise RuntimeError(name + " shape or dtype changed")
    for name in ("training_objective", "validation_objective"):
        value = arrays[name]
        if value.shape != (256,) or value.dtype != np.dtype(np.float64) or not value.dtype.isnative:
            raise RuntimeError(name + " shape or dtype changed")
    for name in ("checkpoint_index", "start_index", "update_index"):
        value = arrays[name]
        if value.shape != (256,) or value.dtype != np.dtype(np.int64) or not value.dtype.isnative:
            raise RuntimeError(name + " shape or dtype changed")
    scale = arrays["sealed_state_scale"]
    expected_scale = np.asarray(expected_scale, dtype=np.float64)
    if (
        scale.shape != (dimension,)
        or scale.dtype != np.dtype(np.float64)
        or not scale.dtype.isnative
        or not np.array_equal(scale, expected_scale)
        or not np.isfinite(scale).all()
        or np.any(scale <= 0.0)
    ):
        raise RuntimeError("sealed state scale changed")
    if not np.array_equal(arrays["checkpoint_index"], np.arange(256, dtype=np.int64)):
        raise RuntimeError("checkpoint numbering changed")
    if not np.array_equal(arrays["start_index"], np.tile(np.arange(8, dtype=np.int64), 32)):
        raise RuntimeError("start order changed")
    if not np.array_equal(arrays["update_index"], np.repeat(np.arange(32, dtype=np.int64), 8)):
        raise RuntimeError("update/start round-robin order changed")
    if not all(np.isfinite(arrays[name]).all() for name in ("theta_log", "process_variance_actual", "training_objective", "validation_objective")):
        raise RuntimeError("history contains a non-finite value")
    if np.any(arrays["process_variance_actual"] <= 0.0):
        raise RuntimeError("history contains non-positive process variance")

    ulp = require_q_exp_within_one_ulp(arrays["theta_log"], arrays["process_variance_actual"])
    raw_ratio = np.sqrt(arrays["process_variance_actual"]) / scale[None, :]
    tolerance = 1e-12
    if np.any(raw_ratio < 1e-4 - tolerance) or np.any(raw_ratio > 1.0 + tolerance):
        raise RuntimeError("process-noise ratio lies outside the frozen range")
    clipped = np.clip(raw_ratio, 1e-4, 1.0)
    roundoff_clips = int(np.count_nonzero(clipped != raw_ratio))
    lower = 2.0 * np.log(scale) + 2.0 * np.log(1e-4)
    upper = 2.0 * np.log(scale)
    theta = arrays["theta_log"]
    if np.any(theta < lower[None, :] - tolerance) or np.any(theta > upper[None, :] + tolerance):
        raise RuntimeError("natural-log process variance lies outside the frozen bounds")

    selected = independent_selected_index(
        arrays["process_variance_actual"],
        arrays["training_objective"],
        arrays["validation_objective"],
    )
    expected_counts = {
        "start_count": 8,
        "updates_per_start": 31,
        "checkpoints": 256,
        "gradient_updates": 248,
        "training_objective_calls": 256,
        "validation_objective_calls": 256,
        "evaluation_array_reads": 0,
    }
    if summary.get("counts") != expected_counts:
        raise RuntimeError("full-budget counts changed")
    if (
        summary.get("selected_index") != selected
        or summary.get("fixed_observation_noise_multiplier") != float(expected_fixed_r_b)
        or summary.get("selected_training_objective") != float(arrays["training_objective"][selected])
        or summary.get("selected_validation_objective") != float(arrays["validation_objective"][selected])
        or summary.get("selected_process_variance") != [float(value) for value in arrays["process_variance_actual"][selected]]
        or summary.get("roundoff_ratio_clip_count") != roundoff_clips
    ):
        raise RuntimeError("summary selection, observation noise, or roundoff record changed")
    if float(arrays["validation_objective"][selected]) > float(np.min(arrays["validation_objective"][:8])):
        raise RuntimeError("selected validation objective is worse than every initial checkpoint")

    lower_hits = int(np.count_nonzero(np.abs(clipped - 1e-4) <= tolerance))
    upper_hits = int(np.count_nonzero(np.abs(clipped - 1.0) <= tolerance))
    if summary.get("ratio_lower_bound_hits") != lower_hits or summary.get("ratio_upper_bound_hits") != upper_hits:
        raise RuntimeError("summary boundary-hit count changed")
    return {
        "status": "PASS_NOT_FORMAL_EVALUATION",
        "basin_id": basin_id,
        "dimension": dimension,
        "manifest_sha256": _sha256(manifest_path),
        "selected_index": selected,
        "selected_training_objective": float(arrays["training_objective"][selected]),
        "selected_validation_objective": float(arrays["validation_objective"][selected]),
        "maximum_q_exp_ulp_distance": ulp["maximum_ulp_distance"],
        "q_exp_unequal_coordinates": ulp["unequal_coordinates"],
        "roundoff_ratio_clip_count": roundoff_clips,
        "ratio_lower_bound_hits": lower_hits,
        "ratio_upper_bound_hits": upper_hits,
        "evaluation_array_reads": 0,
    }


__all__ = [
    "independent_selected_index",
    "positive_float64_ulp_distance",
    "require_q_exp_within_one_ulp",
    "validate_started_identity",
    "verify_result_directory",
]
