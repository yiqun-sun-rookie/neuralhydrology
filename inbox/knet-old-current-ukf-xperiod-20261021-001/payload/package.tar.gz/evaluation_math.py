"""Frozen scalar metrics and all ten pairs; no model execution."""
import itertools
import numpy as np
NAMES=['all_mse','all_mae','low_mse','low_mae','middle_mse','middle_mae','high_mse','high_mae']
def forecast_indices(score_start=365,end=3652):
    issues=np.arange(score_start,end-3,dtype=np.int64)
    return issues,issues[:,None]+np.arange(1,4,dtype=np.int64)
def scores(prediction,target,thresholds):
    p=np.asarray(prediction,dtype=np.float64);y=np.asarray(target,dtype=np.float64)
    assert p.shape==y.shape and p.ndim==2 and p.shape[1]==3 and np.isfinite(p).all() and np.isfinite(y).all()
    q50,q90=thresholds[:2];groups=[np.ones(y.shape,dtype=bool),y<=q50,(y>q50)&(y<=q90),y>q90];err=p-y
    values=[]
    for g in groups:values.extend([float(np.mean(err[g]**2)),float(np.mean(np.abs(err[g])))]) if g.any() else values.extend([None,None])
    by={}
    for k in range(3):
        den=np.sum((y[:,k]-y[:,k].mean())**2)
        by[str(k+1)]=dict(mse=float(np.mean(err[:,k]**2)),mae=float(np.mean(np.abs(err[:,k]))),bias=float(np.mean(err[:,k])),nse=None if den==0 else float(1-np.sum(err[:,k]**2)/den),count=len(y))
    return dict(scores=values,group_counts=[int(g.sum()) for g in groups],by_lead=by)
def scalar(a,b):
    if a is None or b is None:return dict(a=a,b=b,difference=None,relative_change_percent=None,tolerance=None,direction='undefined',engineering_a_vs_b=None,engineering_b_vs_a=None)
    tol=max(1e-10,1e-7*max(abs(a),abs(b)));d=a-b
    return dict(a=a,b=b,difference=d,relative_change_percent=None if b==0 else 100*d/b,tolerance=tol,direction='a_lower' if d < -tol else 'b_lower' if d > tol else 'within_numeric_tolerance',engineering_a_vs_b=bool(a<=b*1.001+max(1e-10,1e-7*abs(b))),engineering_b_vs_a=bool(b<=a*1.001+max(1e-10,1e-7*abs(a))))
def comparisons(metrics):
    out={}
    for a,b in itertools.combinations(metrics,2):
        flow={key:scalar(x,y) for key,x,y in zip(NAMES,metrics[a]['scores'],metrics[b]['scores'])}
        leads={k:scalar(metrics[a]['by_lead'][k]['mse'],metrics[b]['by_lead'][k]['mse']) for k in ['1','2','3']}
        out[a+'__vs__'+b]=dict(a=a,b=b,flow=flow,lead_mse=leads)
    return out
