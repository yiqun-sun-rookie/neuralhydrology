"""Publish only an already prepared command, with an immutable intent record."""
import sys,json,datetime,hashlib
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parent
sys.dont_write_bytecode=True;sys.stdout.reconfigure(encoding='utf-8')
import mailbox_api as m
sequence=int(sys.argv[1]);command=BASE/f'mailbox/submit_{sequence:03d}.sh'
extra_path=BASE/f'mailbox/extras_{sequence:03d}.json'
extras=json.loads(m.s.read_checked(extra_path)) if extra_path.exists() else None
intent=BASE/f'mailbox/publication_intent_{sequence:03d}.json'
expected=hashlib.sha256(m.s.read_checked(command)).hexdigest()
if not intent.exists():m.s.create(str(intent.relative_to(ROOT)),dict(sequence=sequence,command_sha256=expected,
    created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),uncertain_outcome_requires_read_only_inspection=True))
else:
    assert json.loads(m.s.read_checked(intent))['command_sha256']==expected
    sha,_=m.snapshot();live=m.content(f'inbox/{m.CHANNEL}/seq',sha)
    assert live is not None and int(live)==sequence,'Previous publication outcome needs read-only inspection; no retry'
result=m.publish(sequence,command,extras);result['published_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
target=BASE/f'mailbox/published_{sequence:03d}.json'
if not target.exists():m.s.create(str(target.relative_to(ROOT)),result)
print(json.dumps(result),flush=True)
