"""One bounded syntax, binding, count and comparison-boundary check; no models."""
from pathlib import Path
import ast,hashlib,json
import numpy as np
from evaluation_math import scores,forecast_indices,comparisons,scalar
BASE=Path(__file__).resolve().parent
c=json.loads((BASE/'replay_contract.json').read_bytes())
for p in BASE.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'),filename=str(p))
for r in c['input_bindings']:assert hashlib.sha256((BASE/r['path']).read_bytes()).hexdigest()==r['sha256']
days=events=0
with np.load(BASE/'inputs/historical_period.npz',allow_pickle=False) as z:dates=z['dates_ns'].astype('datetime64[ns]').astype('datetime64[D]')
for case,expected in zip(c['cases'],[('1989-10-01','1990-10-01',3652,3284),('1994-10-01','1995-10-01',1826,1458)]):
    issues,targets=forecast_indices(case['score_start'],case['end'])
    assert (str(dates[case['filter_start']]),str(dates[case['score_start']]),case['filter_days'],len(issues))==expected
    assert targets.max()==case['end']-1 and case['score_start']-case['filter_start']==365
    days+=5*case['filter_days'];events+=5*targets.size
assert days==c['maximum_filter_days']==27390 and events==c['maximum_forecast_events']==71130
assert c['maximum_filter_trajectories']==c['maximum_forecast_batches']==10
assert c['maximum_total_optimizer_calls']==c['maximum_autograd_calls']==c['maximum_qp_calls']==0
y=np.array([[0.,1.,3.],[2.,5.,6.]])
metric=scores(y+1,y,[1.,3.]);assert metric['scores']==[1.]*8
assert len(comparisons({a:metric for a in c['trajectory_order']}))==10
assert scalar(1.,0.)['relative_change_percent'] is None
assert scalar(1.,1.+1e-8)['direction']=='within_numeric_tolerance'
assert scalar(1.,2.)['tolerance']==scalar(2.,1.)['tolerance']
assert scores(np.zeros((2,3)),np.zeros((2,3)),[1.,3.])['by_lead']['1']['nse'] is None
assert scores(np.zeros((2,3)),np.zeros((2,3)),[1.,3.])['scores'][4] is None
slurm=(BASE/'replay.slurm').read_bytes();assert b'--mem' not in slurm and b'\r' not in slurm and b'00:15:00' in slurm
w=(BASE/'replay_worker.py').read_text();assert w.index("assert value.shape==built[key].shape")<w.index("net.load_state_dict(raw,strict=True)")
assert "'h_Q','c_Q','h_Sigma','c_Sigma','h_S','c_S','y_previous'" in w
out=dict(status='STATIC_CHECKS_PASS',trajectories=10,filter_days=days,forecast_events=events,local_model_calls=0,checks=['syntax','inputs_SHA','dates_and_counts','all_10_pairs','symmetric_tolerance','zero_and_null','raw_dtype_before_load','initial_memory_capture','slurm_budget'])
with (BASE/'static_checks.json').open('x',encoding='utf-8') as f:json.dump(out,f,indent=2)
print(json.dumps(out))
