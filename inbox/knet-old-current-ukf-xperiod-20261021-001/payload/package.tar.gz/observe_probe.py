"""Single local owner: receive pending sequence, query progress, collect all terminal pieces."""
import sys,json,time,datetime,subprocess,hashlib,msvcrt
from pathlib import Path
from local_io import BASE,read_checked,create
from replay_protocol import assess
REMOTE='/data1/home/sunyiq/knet_camels_hpc_20261012_001/attempts/knet_old_current_ukf_xperiod_20261021_001'
def now():return datetime.datetime.now(datetime.timezone.utc)
def stamp():return now().strftime('%Y%m%dT%H%M%S%fZ')
def obj(p):return json.loads(read_checked(p))
def save_state(value):
    (BASE/'active_execution.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def run(script,*args,timeout=600):
    p=subprocess.run([sys.executable,'-X','utf8','-B',str(BASE/script),*map(str,args)],capture_output=True,text=True,timeout=timeout)
    return dict(exit_code=p.returncode,stdout=p.stdout[-16000:],stderr=p.stderr[-4000:])
def received(sequence):return (BASE/f'monitoring/accepted_{sequence:03d}.json').exists()
def prepare(kind,arg=None):
    numbers=sorted(int(p.stem.split('_')[-1]) for p in (BASE/'mailbox').glob('published_*.json'))
    assert numbers==list(range(1,max(numbers,default=0)+1))
    if numbers and not received(numbers[-1]):return numbers[-1]
    sequence=max(numbers,default=0)+1
    assert sequence>1,'Deployment must already be published'
    if kind=='query':command=f'{REMOTE}/query_replay.py {obj(BASE/"execution_identity.json")["job_id"]}'
    else:command=f'{REMOTE}/collect_terminal.py {arg}'
    raw=('#!/bin/bash\nset -eo pipefail\nexport TZ=UTC\n/data1/home/sunyiq/miniconda3/envs/nh_final/bin/python -u -B '+command+'\n').encode()
    create(f'mailbox/submit_{sequence:03d}.sh',raw);create(f'mailbox/request_{sequence:03d}.json',dict(kind=kind,arg=arg,created_utc=now().isoformat(),command_sha256=hashlib.sha256(raw).hexdigest()))
    result=run('publish.py',sequence,timeout=180);create(f'monitoring/publication_{sequence:03d}.json',result)
    assert result['exit_code']==0,result
    return sequence
def transfer_diagnosis(sequence):
    import mailbox_api as m
    snapshot,_=m.snapshot();meta=m.api('/contents/outbox/'+m.CHANNEL+'/result_'+str(sequence)+'.txt?ref='+snapshot)
    own=m.content('inbox/'+m.CHANNEL+'/seq',snapshot);command=m.content('inbox/'+m.CHANNEL+'/cmd.sh',snapshot)
    assert int(own)==sequence and command==read_checked(BASE/f'mailbox/submit_{sequence:03d}.sh')
    count=0
    if meta:
        cache=BASE/'mailbox'/('chunks_'+meta['sha'])
        if cache.exists():count=sum(p.stat().st_size for p in cache.glob('*.bin'))
    value=dict(sequence=sequence,pinned_ref=snapshot,remote_receipt=None if not meta else {k:meta[k] for k in ['sha','size']},cache_bytes=count,utc=now().isoformat(),command_matched=True)
    create('monitoring/transport_diagnosis_'+stamp()+'.json',value);return (None if not meta else meta['sha'],count)
def receive(sequence):
    started=time.monotonic();attempts=[]
    while True:
        try:result=run('fetch_receipt.py',sequence,timeout=610)
        except subprocess.TimeoutExpired:result=dict(exit_code=124,stdout='',stderr='fetch deadline; cache preserved')
        attempts.append(dict(exit_code=result['exit_code'],stderr=result['stderr'],utc=now().isoformat()))
        if result['exit_code']==0 and (BASE/f'mailbox/result_{sequence:03d}.txt').exists():break
        if result['exit_code']!=0 or time.monotonic()-started>=600:
            failure=dict(status='MONITOR_FAILED',healthy=False,sequence=sequence,exit_code=2,attempts=attempts,utc=now().isoformat())
            create('monitoring/round_'+stamp()+'_result.json',failure);print(json.dumps(failure),flush=True);return None
        time.sleep(15)
    raw=read_checked(BASE/f'mailbox/result_{sequence:03d}.txt');lines=raw.decode().splitlines();codes=[x for x in lines if x.startswith('### exit_code=')]
    assert codes==['### exit_code=0'],codes
    requested=datetime.datetime.fromisoformat(obj(BASE/f'mailbox/publication_intent_{sequence:03d}.json')['created_utc']);upper=(now()-requested).total_seconds()
    request=obj(BASE/f'mailbox/request_{sequence:03d}.json');record=dict(sequence=sequence,utc=now().isoformat(),native_exit_code=0,request_to_return_upper_seconds=upper,kind=request['kind'])
    if request['kind']=='deploy':
        identity=json.loads(next(x.split('=',1)[1] for x in lines if x.startswith('DEPLOYMENT_RESULT=')))
        assert identity['remote_root']==REMOTE and identity['archive_sha256']==obj(BASE/'registry_frozen.json')['payload_sha256']
        if not (BASE/'execution_identity.json').exists():create('execution_identity.json',identity)
        if identity['status']=='SUBMITTED' and not (BASE/'submission.json').exists():create('submission.json',identity)
        record.update(status=identity['status'],healthy=False,job_id=identity['job_id'])
        assert identity['status'] in ('SUBMITTED','SUBMISSION_REJECTED'),'Unknown submission outcome; read-only diagnosis required'
    elif request['kind']=='collect':
        assert any(x.startswith('ARTIFACT_COLLECTION_INDEX=') for x in lines)
        record.update(status='TERMINAL_ARTIFACT_RECEIVED',healthy=False,part=request['arg'])
    else:
        row=json.loads(next(x.split('=',1)[1] for x in lines if x.startswith('PROBE_STATUS_JSON=')))
        assert row['identity']==obj(BASE/'execution_identity.json');create(f'monitoring/status_{sequence:03d}.json',row)
        record.update(assess(row,upper));record['current_status']=row
    create('monitoring/round_'+stamp()+'_result.json',record);create(f'monitoring/accepted_{sequence:03d}.json',record)
    print(json.dumps({k:v for k,v in record.items() if k!='current_status'}),flush=True)
    return record
def main():
    (BASE/'monitoring').mkdir(exist_ok=True);f=(BASE/'monitoring/observe_process.lock').open('a+b');f.seek(0)
    if f.read(1)==b'':f.write(b'0');f.flush()
    f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
    sequence=1;terminal=False;failed_rounds=0;unchanged=0;prior=None
    numbers=sorted(int(p.stem.split('_')[-1]) for p in (BASE/'mailbox').glob('published_*.json'));assert numbers
    if (BASE/'execution_identity.json').exists():terminal=obj(BASE/'execution_identity.json')['status']=='SUBMISSION_REJECTED'
    if numbers[-1]>1:
        for p in sorted((BASE/'monitoring').glob('status_*.json')):
            if obj(p)['terminal']:terminal=True
    while True:
        if (BASE/'collection/verified.json').exists():
            numbers=sorted(int(p.stem.split('_')[-1]) for p in (BASE/'mailbox').glob('published_*.json'))
            verified=obj(BASE/'collection/verified.json');save_state(dict(status='COLLECTED_AWAITING_ACCEPTANCE',pending_queries=[],latest_sequence=max(numbers),collection=verified));print(json.dumps(verified),flush=True);return 0
        numbers=sorted(int(p.stem.split('_')[-1]) for p in (BASE/'mailbox').glob('published_*.json'))
        if not received(numbers[-1]):sequence=numbers[-1]
        elif terminal:
            if (BASE/'collection/index.json').exists():
                index=obj(BASE/'collection/index.json');missing=[x['part'] for x in index['parts'] if not (BASE/f"collection/parts/part_{x['part']:05d}.bin").exists()];part=missing[0] if missing else -1
            else:part=-1
            sequence=prepare('collect',part)
        else:sequence=prepare('query')
        save_state(dict(status='COLLECTING' if terminal else 'OBSERVING',pending_queries=[sequence],latest_sequence=sequence,terminal=terminal))
        record=receive(sequence)
        if record is None:
            key=transfer_diagnosis(sequence);unchanged=unchanged+1 if key==prior else 0;prior=key
            if unchanged>=3:raise RuntimeError('Three further transfer windows without change; needs action')
            continue
        unchanged=0;prior=None
        if record['status']=='MONITOR_FAILED':
            transfer_diagnosis(sequence);failed_rounds+=1
            if failed_rounds>=3:raise RuntimeError('Persistent current monitoring failure needs diagnosis')
        else:failed_rounds=0
        if record['status']=='SUBMISSION_REJECTED' or record.get('current_status',{}).get('terminal'):terminal=True
        if not terminal and record['kind']!='deploy':time.sleep(60)

if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as exc:
        create('monitoring/round_'+stamp()+'_exception_result.json',dict(status='MONITOR_FAILED',healthy=False,error=type(exc).__name__+': '+str(exc),utc=now().isoformat()))
        raise
