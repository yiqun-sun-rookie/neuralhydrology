"""Freeze this user-authorized implementation of the once-reviewed plan."""
from pathlib import Path
import datetime,gzip,hashlib,io,json,tarfile
BASE=Path(__file__).resolve().parent
def obj(p):return json.loads(p.read_bytes())
def put(name,value):
    p=BASE/name;p.parent.mkdir(parents=True,exist_ok=True)
    raw=value if isinstance(value,bytes) else (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
    with p.open('xb') as f:f.write(raw)
def row(p):return dict(path=p.relative_to(BASE).as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)
p=obj(BASE/'reviewed_plan/plan.json');r=obj(BASE/'reviewed_plan/independent_review.json');c=obj(BASE/'replay_contract.json')
assert r['status']=='PASS' and r['review_round']==1 and obj(BASE/'static_checks.json')['status']=='STATIC_CHECKS_PASS'
assert obj(BASE/'user_authorization.json')['plan_sha256']==row(BASE/'reviewed_plan/plan.json')['sha256']
paths=sorted(x for x in BASE.iterdir() if x.is_file() and x.suffix in ['.py','.json','.slurm','.md'])+sorted((BASE/'inputs').iterdir())+sorted((BASE/'reviewed_plan').iterdir())
put('execution_authorization.json',dict(status='AUTHORIZED',family=c['family'],authority=obj(BASE/'user_authorization.json'),authorized_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),independent_review_count=1,independent_plan_review_status='PASS',independent_implementation_review=False,blockers=0,template_manifest_sha256=p['future_execution']['template_manifest_sha256'],remote_root=c['remote_root'],channel=c['channel'],maximum_submissions=1,retry_science=False,new_training_budget=0,files=[row(x) for x in paths]))
paths.append(BASE/'execution_authorization.json');put('deployment_manifest.json',dict(files=[row(x) for x in paths]));paths.append(BASE/'deployment_manifest.json')
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w') as tar:
    for x in paths:
        raw=x.read_bytes();info=tarfile.TarInfo(x.relative_to(BASE).as_posix());info.size=len(raw);info.mtime=0;tar.addfile(info,io.BytesIO(raw))
payload=gzip.compress(stream.getvalue(),mtime=0);digest=hashlib.sha256(payload).hexdigest();put('payload/package.tar.gz',payload)
channel=c['channel'];command=('#!/bin/bash\nset -eo pipefail\n'+f'/data1/home/sunyiq/miniconda3/envs/nh_final/bin/python -u -B "$PWD/inbox/{channel}/payload/deploy.py" "$PWD/inbox/{channel}/payload/package.tar.gz" {digest}\n').encode()
put('mailbox/submit_001.sh',command);put('mailbox/request_001.json',dict(kind='deploy',remote_root=c['remote_root'],payload_sha256=digest));put('mailbox/extras_001.json',{f'inbox/{channel}/payload/deploy.py':str(BASE/'deploy.py'),f'inbox/{channel}/payload/package.tar.gz':str(BASE/'payload/package.tar.gz')})
put('registry_frozen.json',dict(exp_id=c['family'],status='AUTHORIZED_FROZEN_READY_TO_SUBMIT',type='frozen recipe cross-period comparison',hypothesis=p['hypothesis'],fixed_factors='HBV physics, both UKFs, data, states at initialization, windows, metrics, weights',changed_factor='fixed KNet recipe/checkpoint',seeds=[20260922],run_dir=c['remote_root'],channel=channel,payload_sha256=digest,checkpoints=c['checkpoints'],budget=p['future_execution'],independent_review_rounds=1,notes=c['scope']))
put('active_execution.json',dict(status='READY_TO_SUBMIT',job_id=None,pending_queries=[]))
print(json.dumps(dict(status='FROZEN_READY_TO_SUBMIT',payload_bytes=len(payload),payload_sha256=digest)))
