"""Prepare the user-authorized, reviewed comparison without local model calls."""
from pathlib import Path
import ast, datetime, hashlib, json
import torch
BASE=Path(__file__).resolve().parent
ROOT=BASE.parent
OLD=ROOT/'hpc_knet_epochscan_20261021_001'
PLAN=ROOT/'knet_old_current_ukf_xperiod_plan_20261021_001'
FAMILY='KNET-OLD-CURRENT-UKF-XPERIOD-01'
def obj(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(name,value):
    p=BASE/name;p.parent.mkdir(parents=True,exist_ok=True)
    raw=value if isinstance(value,bytes) else (value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
    with p.open('xb') as f:f.write(raw)
def row(p):return dict(path=str(p.resolve()),sha256=sha(p),bytes=p.stat().st_size)
def derive(name):
    return (OLD/name).read_text(encoding='utf-8').replace('knet_epochscan_20261021_001','knet_old_current_ukf_xperiod_20261021_001').replace('knet-epochscan-20261021-001','knet-old-current-ukf-xperiod-20261021-001').replace('KNET-EPOCHSCAN-01',FAMILY).replace('EPOCHSCAN','OLD_CURRENT_XPERIOD').replace('knet_epochscan_020_c01','knet_old_current_020_c01').replace('six-arm','five-arm')
p=obj(PLAN/'plan.json');review=obj(PLAN/'independent_review.json');final=obj(PLAN/'final_receipt.json')
assert review['status']=='PASS' and review['review_round']==1 and final['blocking_findings']==0
for r in final['files']:
    f=Path(r['path']);assert sha(f)==r['sha256'] and f.stat().st_size==r['bytes']
sources=obj(PLAN/'input_manifest.json')['files']
for r in sources:
    f=Path(r['path']);assert sha(f)==r['sha256'] and f.stat().st_size==r['bytes']
for name in ['plan.json','independent_review.json','independent_review.md','review_response.md','final_receipt.json','input_manifest.json']:
    put('reviewed_plan/'+name,(PLAN/name).read_bytes())
put('user_authorization.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),request='按审核后的计划执行这次跨时段对照，旧e127、当前e81、两种UKF和HBV基线都保留。严格按冻结预算，不改模型、不重训、不调参，完整报告好坏结果，最后说清楚谁更好、代价是什么。',plan_sha256=sha(PLAN/'plan.json'),review_sha256=sha(PLAN/'independent_review.json'),note='This later user authorization supersedes the historical plan-only execution=false fields; one review only.'))
for name in ['historical_period.npz','input_snapshot.npz','ukf_selection.json','frozen_data_loader.py']:
    source=OLD/'inputs'/name;r=next(r for r in obj(OLD/'replay_contract.json')['input_bindings'] if r['path']=='inputs/'+name)
    assert sha(source)==r['sha256'];put('inputs/'+name,source.read_bytes())
checkpoints={};raw_reference=None;metadata={}
buffers=['state_feature_scale','observation_feature_scale','correction_cap_by_state_scale_units']
for model in p['models']:
    source=Path(model['checkpoint']['path']);assert sha(source)==model['checkpoint']['sha256']
    cp=torch.load(source,weights_only=True,map_location='cpu');network=cp['network']
    assert cp['epoch']==cp['optimizer_steps']==model['epoch'] and cp['seed']==p['seed'] and cp['parameter_sha256']==model['parameter_sha256']
    signature={k:dict(shape=list(v.shape),dtype=str(v.dtype)) for k,v in network.items()}
    if raw_reference is not None:
        assert signature==raw_reference[0]
        for key in buffers:assert torch.equal(network[key],raw_reference[1][key])
    else:raw_reference=(signature,network)
    name='inputs/'+model['label']+'.pt';put(name,source.read_bytes())
    checkpoints[model['label']]=dict(epoch=model['epoch'],path=name,sha256=sha(source),parameter_sha256=cp['parameter_sha256'],seed=cp['seed'],optimizer_steps=cp['optimizer_steps'])
    metadata[model['label']]=dict(source=row(source),raw_state_dict=signature,fixed_buffers={k:network[k].tolist() for k in buffers})
put('checkpoint_provenance.json',dict(status='RAW_CHECKPOINT_PAIR_COMPATIBLE',checkpoints=checkpoints,metadata=metadata,local_model_calls=0,runtime_raw_check_still_required=True))
put('data_provenance.json',obj(OLD/'data_provenance.json'))
put('input_bindings.json',dict(files=[]))
bindings=[dict(path=x.relative_to(BASE).as_posix(),sha256=sha(x),bytes=x.stat().st_size) for x in sorted((BASE/'inputs').iterdir())]
c=obj(OLD/'replay_contract.json');future=p['future_execution']
for key in ['remote_root','channel','maximum_submissions','maximum_filter_trajectories','maximum_filter_days','maximum_forecast_batches','maximum_forecast_events']:c[key]=future[key]
c.update(family=FAMILY,trajectory_order=p['arms'],checkpoints=checkpoints,input_bindings=bindings,cases=p['cases'],subwindows=p['subwindows'],comparison_policy=p['comparison_policy'],reviewed_plan_sha256=sha(PLAN/'plan.json'))
c.pop('checkpoint_rules');c['historical_training']=p['models']
c['scope']='02092500 seed20260922; frozen old150-forward/full150-backprop e127 versus current800-forward/last150-backprop e81 and both UKFs/HBV. Historical period previously exposed, known future forcing, unequal training coverage and cost; descriptive recipe-level comparison, no single-change attribution or universal superiority claim.'
put('replay_contract.json',c)
transport=[]
for name in ['safe_io.py','local_io.py','replay_protocol.py','replay_controller.py','query_replay.py','collect_terminal.py','assemble_archive.py','fetch_receipt.py','mailbox_api.py','publish.py','observe_probe.py','deploy.py','replay.slurm']:
    put(name,derive(name));transport.append(dict(path=name,source=row(OLD/name),derived_sha256=sha(BASE/name)))
put('transport_sources.json',dict(files=transport,changes='new owned root/channel/name and success token; same controller/resource/transport behavior'))
t=derive('replay_worker.py').replace('Twelve bounded checkpoint-comparison','Ten bounded frozen-recipe comparison').replace("cp=checkpoints['KNet_e081']","cp=checkpoints['KNet_current_e081']").replace("COUNTERS['filter_trajectories']<12","COUNTERS['filter_trajectories']<10").replace("purpose='frozen_epochscan'","purpose='frozen_old_current_xperiod'").replace('<=32868','<=27390').replace('<=85356','<=71130').replace('filter_trajectories=12,filter_days=32868,forecast_batches=12,forecast_events=85356','filter_trajectories=10,filter_days=27390,forecast_batches=10,forecast_events=71130')
t=t.replace("net.load_state_dict(cp['network'],strict=True);net.eval()",'''raw=cp['network'];built=net.state_dict()
                assert raw.keys()==built.keys()
                signature={}
                for key,value in raw.items():
                    assert value.shape==built[key].shape and value.dtype==built[key].dtype,(key,value.dtype,built[key].dtype)
                    signature[key]=dict(shape=list(value.shape),dtype=str(value.dtype))
                for key in ['state_feature_scale','observation_feature_scale','correction_cap_by_state_scale_units']:assert torch.equal(raw[key],built[key])
                proof['raw_checkpoint_runtime_compatibility']=dict(status='PASS_BEFORE_LOAD',tensors=signature,fixed_buffers_identical=True)
                net.load_state_dict(raw,strict=True);net.eval()''')
t=t.replace("if day==0:np.testing.assert_array_equal(arr(net.m1x_posterior),arr(physical_initial))",'''if day==0:
                        np.testing.assert_array_equal(arr(net.m1x_posterior),arr(physical_initial))
                        init={key:arr(getattr(net,key)) for key in ['m1x_posterior','m1x_posterior_previous','m1x_prior_previous','h_Q','c_Q','h_Sigma','c_Sigma','h_S','c_S','y_previous']}
                        init.update(initial_state=arr(physical_initial),previous_observation_is_none=np.asarray(True))
                        np_save(arm+'/initialization.npz',init)''')
t=t.replace("if label=='HBV':\n                state", "if label not in checkpoints:\n                init=dict(initial_state=arr(physical_initial),previous_observation_is_none=np.asarray(True))\n                if label.startswith('UKF_'):init['initial_covariance']=arr(initial_covariance)\n                np_save(arm+'/initialization.npz',init)\n            if label=='HBV':\n                state")
put('replay_worker.py',t)
t=derive('accept_results.py')
start=t.index('def compare_candidate(');end=t.index('def close_tree(',start)
t=t[:start]+"from evaluation_math import comparisons as compare\n\n"+t[end:]
t=t.replace('filter_trajectories=12,filter_days=32868,forecast_batches=12,forecast_events=85356','filter_trajectories=10,filter_days=27390,forecast_batches=10,forecast_events=71130').replace('len(required)==20','len(required)==16')
t=t.replace("assert g.any();v.extend([float(np.mean(err[g]**2)),float(np.mean(abs(err[g])))])", "v.extend([float(np.mean(err[g]**2)),float(np.mean(abs(err[g])))]) if g.any() else v.extend([None,None])")
t=t.replace(";assert den>0", "").replace("nse=float(1-np.sum(e*e)/den)","nse=None if den==0 else float(1-np.sum(e*e)/den)")
t=t.replace("assert a['prior_states'].shape", "init=load(RUN/name/arm/'initialization.npz');np.testing.assert_array_equal(init['initial_state'],initial);assert bool(init['previous_observation_is_none'])\n            assert a['prior_states'].shape")
t=t.replace("state[name][arm]={}",'''state[name][arm]={}
                assert proof['raw_checkpoint_runtime_compatibility']['status']=='PASS_BEFORE_LOAD'
                for k,v in cp['network'].items():
                    assert after[k].dtype==v.dtype and after[k].shape==v.shape
                    assert proof['raw_checkpoint_runtime_compatibility']['tensors'][k]==dict(shape=list(v.shape),dtype=str(v.dtype))
                for key in ['m1x_posterior','m1x_posterior_previous','m1x_prior_previous']:np.testing.assert_array_equal(init[key],initial)
                for key in ['h_Q','c_Q','h_Sigma','c_Sigma','h_S','c_S','y_previous']:assert np.isfinite(init[key]).all()
                assert init['y_previous'].shape==(1,1)
                state[name][arm]['initialization_shapes']={k:list(v.shape) for k,v in init.items()}''')
t=t.replace("state[name][arm]['cap_boundary_fraction_score_days']=float(boundary[warm:].mean())", "state[name][arm]['cap_boundary_fraction_common_issues']=float(boundary[warm:warm+n].mean());state[name][arm]['cap_denominator_common_issues']=int(boundary[warm:warm+n].size)")
t=t.replace("annual[name][arm][str(wy)]=leadmetrics", "annual[name][arm][str(wy)]=leadmetrics\n                for j in range(3):\n                    mask=water[:,j]==wy;dd=targetdates[mask,j];leadmetrics[str(j+1)].update(first_target_date=str(dd.min()),last_target_date=str(dd.max()),partial=bool(str(dd.min())!=str(int(wy)-1)+'-10-01' or str(dd.max())!=str(int(wy))+'-09-30'))")
t=t.replace("ratios={case:",'''reproduction=[]
if complete:
    plan=obj(BASE/'reviewed_plan/plan.json')
    for control in plan['archived_controls']:
        path=Path(control['input']['path']);assert sha(path)==control['input']['sha256']
        previous=load(path);current=arrays[control['case']][control['new_label']]
        for key in plan['reproduction_policy']['exact_required_keys']:np.testing.assert_array_equal(current[key],previous[key])
        reproduction.append(dict(case=control['case'],arm=control['new_label'],status='EXACT_ARRAY_REPRODUCTION',keys=plan['reproduction_policy']['exact_required_keys']))
    assert len(reproduction)==8
ratios={case:''')
t=t.replace("out=dict(status=", "out=dict(archived_control_reproductions=reproduction,initialization_records_verified=10 if complete else 0,status=")
put('accept_results.py',t)
put('preparation_receipt.json',dict(status='PREPARED_WITHOUT_MODEL_CALLS',reviewed_sources_verified=len(sources),plan=row(PLAN/'plan.json'),models=list(checkpoints),budget=future,model_changes=0,local_model_calls=0,training_calls=0,hpc_submissions=0))
for path in BASE.glob('*.py'):ast.parse(path.read_text(encoding='utf-8'))
print(json.dumps(dict(status='PREPARED_WITHOUT_MODEL_CALLS',sources=len(sources),checkpoints=list(checkpoints))))
