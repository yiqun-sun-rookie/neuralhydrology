"""Checked immutable receipt retrieval; large receipts use verified bounded ranges."""
import sys,json,base64,hashlib,io,tarfile,datetime,urllib.request,urllib.parse,concurrent.futures,time
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parent
sys.dont_write_bytecode=True;sys.stdout.reconfigure(encoding='utf-8')
import mailbox_api as m
import msvcrt
lockpath=m.s.checked_path(BASE/'mailbox/fetch_process.lock',False);lockpath.parent.mkdir(parents=True,exist_ok=True)
process_lock=lockpath.open('a+b')
try:
    process_lock.seek(0)
    if process_lock.read(1)==b'':process_lock.write(b'0');process_lock.flush()
    process_lock.seek(0)
    msvcrt.locking(process_lock.fileno(),msvcrt.LK_NBLCK,1)
except OSError:
    process_lock.close()
    print(json.dumps(dict(status='OWNED_FETCH_ALREADY_RUNNING')));raise SystemExit(4)
number=int(sys.argv[1]);snapshot,commit=m.snapshot()
remote=f'outbox/{m.CHANNEL}/result_{number}.txt'
# Direct own-file metadata avoids transferring the large shared outbox tree.
entry=m.api('/contents/'+remote+'?ref='+snapshot)
if entry is None:
    print(json.dumps(dict(status='NO_RECEIPT_YET',sequence=number,branch_sha=snapshot)));raise SystemExit(0)
assert entry['type']=='file';size=entry['size'];dest=BASE/f'mailbox/result_{number:03d}.txt'
if dest.exists():raw=m.s.read_checked(dest)
elif size<1024*1024:raw=base64.b64decode(entry['content'])
else:
    meta=entry
    assert meta['sha']==entry['sha'] and meta['size']==size
    url=meta['download_url'];parsed=urllib.parse.urlsplit(url)
    assert parsed.scheme=='https' and parsed.hostname=='raw.githubusercontent.com'
    chunk_size=8192
    def chunk(start):
        end=min(start+chunk_size,size)-1
        cache=BASE/'mailbox'/('chunks_'+entry['sha'])/(str(start)+'_'+str(end)+'.bin')
        if cache.exists():
            body=m.s.read_checked(cache)
            assert len(body)==end-start+1
            return start,body
        for attempt in range(4):
            try:
                req=urllib.request.Request(url+('&' if parsed.query else '?')+'range_start='+str(start)+'&range_end='+str(end)+'&read_attempt='+str(attempt),
                    headers={'Accept-Encoding':'identity','Range':f'bytes={start}-{end}'})
                with urllib.request.urlopen(req,timeout=45) as response:
                    assert response.status==206 and response.headers.get('Content-Range')==f'bytes {start}-{end}/{size}'
                    pieces=[]
                    while True:
                        piece=response.read(4096)
                        if not piece:break
                        pieces.append(piece)
                    body=b''.join(pieces)
                assert len(body)==end-start+1
                try:m.s.create(str(cache.relative_to(ROOT)),body)
                except FileExistsError:assert m.s.read_checked(cache)==body
                return start,body
            except Exception:
                if attempt==3:raise
                time.sleep(.3)
    with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:parts=dict(pool.map(chunk,range(0,size,chunk_size)))
    raw=b''.join(parts[k] for k in sorted(parts))
assert len(raw)==size and hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==entry['sha']
lines=raw.decode('utf-8').splitlines()
assert lines[0]==f'### channel={m.CHANNEL} seq={number}'
assert any(x.startswith('### exit_code=') for x in lines) and any(x.startswith('### finished=') for x in lines)
if not dest.exists():m.s.create(str(dest.relative_to(ROOT)),raw)
indexes=[x for x in lines if x.startswith('ARTIFACT_COLLECTION_INDEX=')]
parts=[x for x in lines if x.startswith('ARTIFACT_PART_BASE64=')]
if indexes:
    from assemble_archive import accept_index,accept_part,assemble
    index=json.loads(indexes[-1].split('=',1)[1]);accept_index(index)
    if parts:
        meta=json.loads(next(x.split('=',1)[1] for x in lines if x.startswith('ARTIFACT_PART_METADATA=')))
        accept_part(meta,base64.b64decode(parts[-1].split('=',1)[1],validate=True))
    print(json.dumps(assemble()))
archives=[x for x in lines if x.startswith('ARTIFACT_ARCHIVE_BASE64=')]
if archives:
    payload=base64.b64decode(archives[-1].split('=',1)[1],validate=True)
    meta=json.loads(next(x.split('=',1)[1] for x in lines if x.startswith('ARTIFACT_ARCHIVE_METADATA=')))
    assert len(payload)==meta['bytes'] and hashlib.sha256(payload).hexdigest()==meta['sha256']
    with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as tar:
        for item in tar.getmembers():
            rel=Path(item.name)
            assert item.isfile() and not rel.is_absolute() and '..' not in rel.parts and not m.s.DENY.search(item.name)
            value=tar.extractfile(item).read();target=BASE/'hpc_results'/rel
            if target.exists():assert m.s.read_checked(target)==value
            else:m.s.create(str(target.relative_to(ROOT)),value)
    print(json.dumps(dict(status='ARTIFACTS_HASH_VERIFIED',archive_bytes=len(payload))))
for line in lines:
    if line.startswith(('SUBMISSION_JSON=','JOB_STATUS_JSON=','### exit_code=')):print(line)
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
m.s.create(BASE.name+'/mailbox/verified_'+str(number)+'_'+stamp+'.json',dict(sequence=number,snapshot=snapshot,
    receipt_git_sha=entry['sha'],receipt_bytes=size,archives_extracted=len(archives)))
