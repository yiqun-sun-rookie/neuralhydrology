"""Verify all pieces and all file identities before declaring an archive complete."""
import json,hashlib,tarfile
from pathlib import Path
from local_io import BASE,read_checked,checked_path,create
def obj(p):return json.loads(read_checked(p))
def accept_index(index):
    identity=obj(BASE/'execution_identity.json');assert index['identity']==identity and index['job_id']==identity['job_id'];offset=0
    assert index['chunk_size']==8*1024**2
    for i,row in enumerate(index['parts']):
        assert row['part']==i and row['offset']==offset and 0<row['bytes']<=index['chunk_size'];offset+=row['bytes']
    assert offset==index['archive_bytes']
    if (BASE/'collection/index.json').exists():assert obj(BASE/'collection/index.json')==index
    else:create('collection/index.json',index)
def accept_part(meta,payload):
    index=obj(BASE/'collection/index.json');row=index['parts'][meta['part']]
    assert meta['job_id']==index['job_id'] and meta['archive_sha256']==index['archive_sha256']
    assert all(meta[k]==v for k,v in row.items()) and len(payload)==row['bytes'] and hashlib.sha256(payload).hexdigest()==row['sha256']
    name=f"collection/parts/part_{row['part']:05d}.bin"
    if (BASE/name).exists():assert read_checked(BASE/name)==payload
    else:create(name,payload)
def assemble():
    if not (BASE/'collection/index.json').exists():return dict(status='INDEX_PENDING')
    index=obj(BASE/'collection/index.json');accept_index(index)
    missing=[r['part'] for r in index['parts'] if not (BASE/f"collection/parts/part_{r['part']:05d}.bin").exists()]
    if missing:return dict(status='PARTS_PENDING',missing=missing)
    archive=BASE/'collection/archive.tar.gz'
    if not archive.exists():
        partial=checked_path(BASE/'collection/assembling.tar.gz',False)
        with partial.open('xb') as f:
            for row in index['parts']:f.write(read_checked(BASE/f"collection/parts/part_{row['part']:05d}.bin",row['sha256']))
        assert hashlib.sha256(read_checked(partial)).hexdigest()==index['archive_sha256'];partial.rename(archive)
    assert archive.stat().st_size==index['archive_bytes'] and hashlib.sha256(read_checked(archive)).hexdigest()==index['archive_sha256']
    with tarfile.open(archive,'r:gz') as tar:
        members=tar.getmembers();names=[m.name for m in members];assert len(set(names))==len(names)==index['files']
        manifest=json.loads(tar.extractfile('collection_manifest.json').read());assert manifest['identity']==index['identity']
        assert set(names)=={r['path'] for r in manifest['files']}|{'collection_manifest.json'}
        rows={r['path']:r for r in manifest['files']}
        for member in members:
            rel=Path(member.name);assert member.isfile() and not rel.is_absolute() and '..' not in rel.parts
            raw=tar.extractfile(member).read()
            if member.name in rows:
                row=rows[member.name];assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
            name='hpc_results/'+member.name
            if (BASE/name).exists():assert read_checked(BASE/name)==raw
            else:create(name,raw)
    result=dict(status='FULL_ARCHIVE_HASH_VERIFIED',job_id=index['job_id'],archive_sha256=index['archive_sha256'],archive_bytes=index['archive_bytes'],files=index['files'],scientific_success_not_implied=True)
    if not (BASE/'collection/verified.json').exists():create('collection/verified.json',result)
    return result
if __name__=='__main__':print(json.dumps(assemble()))
