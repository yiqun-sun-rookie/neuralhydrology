"""Keep local artifact IO independent of mailbox module import aliases."""
import importlib.util
from pathlib import Path
BASE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('owned_artifact_io',BASE/'safe_io.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
read_checked=module.read_checked
checked_path=module.checked_path
create=module.create
