import hashlib, runpy, sys
from pathlib import Path
p=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/hybrid_v024_20261014_001/federated_v010.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='a2f0234fb9e5003522105b92975a72b9b0f4db6bbbbf5125391487213dcf2aee'
assert sys.argv[1:] == ['export','--config','export_config.json','--assignment','assignment.json','--destination','/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/workflow_v010_20261012_001/hpc_packet_001']
sys.argv[sys.argv.index('--assignment')+1]='/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/hybrid_v024_20261014_001/assignment.json'
sys.argv[sys.argv.index('--destination')+1]='/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/hybrid_v024_20261014_001/hpc_packet_001'
runpy.run_path(str(p),run_name='__main__')
