import hashlib, runpy
from pathlib import Path
p=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/hybrid_v025_20261014_001/worker.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='393023d0bd3ea652e1f92cc5826879d3292f9eecaf112e8fbdd30e28d5affe33'
runpy.run_path(str(p),run_name='__main__')
