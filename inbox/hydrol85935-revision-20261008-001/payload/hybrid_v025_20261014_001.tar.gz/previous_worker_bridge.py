import hashlib, runpy
from pathlib import Path
p=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/hybrid_v024_20261014_001/worker.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='3f7235512a1fc8d52ea6eb743187a4012492e0caa6600166b41f84f49788e549'
runpy.run_path(str(p),run_name='__main__')
