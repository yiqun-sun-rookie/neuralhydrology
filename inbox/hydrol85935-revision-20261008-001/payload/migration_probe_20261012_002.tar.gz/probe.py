import datetime,json,os,platform,subprocess,traceback
from pathlib import Path
root=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001')
directory=root/'control/migration_probe_20261012_002'
node=os.environ['SLURMD_NODENAME']
if node not in ('ngu201','ngu002'):raise ValueError('Unregistered probe node')
job=os.environ['SLURM_JOB_ID']
registry=json.loads((directory/'jobs.json').read_text())
if str(registry['probes'][node])!=job:raise ValueError('Unregistered probe job')
if int(os.environ['SLURM_CPUS_PER_TASK'])!=4:raise ValueError('CPU allocation changed')
report=dict(node=node,job_id=job,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            platform=platform.platform(),libc=platform.libc_ver(),python=platform.python_version(),
            cuda_visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'),
            scope='Existing isolated runtime import and small CUDA health test; no hydrological predictions or training')
failed=False
try:
    result=subprocess.run(['nvidia-smi','--query-gpu=index,uuid,name,driver_version,memory.total','--format=csv,noheader'],capture_output=True,text=True,timeout=30)
    report['nvidia_smi']=dict(returncode=result.returncode,stdout=result.stdout,stderr=result.stderr)
    if result.returncode:raise RuntimeError('GPU metadata command failed')
    import torch
    report.update(torch=torch.__version__,torch_source=torch.__file__,cuda_runtime=torch.version.cuda,
                  cuda_available=torch.cuda.is_available(),cuda_device_count=torch.cuda.device_count())
    Path(torch.__file__).resolve().relative_to(root/'runtime_torch271cu118/site')
    if torch.__version__!='2.7.1+cu118' or torch.cuda.device_count()!=1:raise ValueError('Approved runtime or single GPU allocation changed')
    torch.set_num_threads(4)
    x=torch.ones((64,64),device='cuda:0',requires_grad=True)
    y=(x@x).square().mean();y.backward();torch.cuda.synchronize()
    if not torch.isfinite(y).item() or not torch.isfinite(x.grad).all().item():raise ValueError('CUDA health test produced nonfinite values')
    report.update(status='PASS',cuda_device=torch.cuda.get_device_name(0),
                  cuda_peak_allocated_bytes=torch.cuda.max_memory_allocated(),
                  tested_allocated_gpus=1,all_node_gpus_tested=False)
except Exception as error:
    failed=True;report.update(status='FAIL',reason=type(error).__name__+': '+str(error),traceback=traceback.format_exc())
with (directory/(node+'_report.json')).open('x') as stream:json.dump(report,stream,indent=2)
print('COMPATIBILITY_REPORT '+json.dumps(report),flush=True)
if failed:raise SystemExit(4)
