import datetime,json,re,subprocess
from pathlib import Path
root=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001')
directory=root/'control/migration_probe_20261012_002'
assert root.resolve()==root and (root/'OWNER').read_text().strip()=='hydrol85935_revision_20261008_001'
assert directory.resolve().parent==root/'control'
expected=dict(train=240076,attacks=240077,report=240078)
assert json.loads((root/'control/full_v004/jobs.json').read_text())==expected
def record(event,**fields):
    value=dict(event=event,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**fields)
    with (directory/'submission.jsonl').open('a') as f:f.write(json.dumps(value)+'\n')
    print('MIGRATION_PROBE '+json.dumps(value),flush=True)
def run(command):
    result=subprocess.run(command,text=True,capture_output=True,timeout=45)
    record('COMMAND',command=command,returncode=result.returncode,stdout=result.stdout,stderr=result.stderr)
    if result.returncode:raise RuntimeError('Command failed: '+command[0])
    return result.stdout
def parent_pending(expected_dependency="(null)"):
    for kind,job in expected.items():
        text=run(['scontrol','-o','show','job',str(job)])
        lines=[line for line in text.splitlines() if line.startswith('JobId=')]
        if len(lines)!=1:raise ValueError('Parent has expanded or changed; do not alter running work')
        fields=dict(item.split('=',1) for item in lines[0].split() if '=' in item)
        if (fields.get('JobId')!=str(job) or fields.get('JobState')!='PENDING'
                or fields.get('Command')!=str(root/'control/full_v004'/(kind+'.sbatch'))
                or fields.get('WorkDir')!=str(root/'control/continuation_v004')
                or fields.get('NumCPUs')!='4' or fields.get('TresPerNode')!='gpu:1'):
            raise ValueError('Parent scheduler identity or state changed')
    detail=run(['scontrol','-o','show','job','240076'])
    fields=dict(item.split('=',1) for item in detail.split() if '=' in item)
    if fields.get('Dependency')!=expected_dependency:raise ValueError('Parent dependency changed; do not overwrite it')
    rows=run(['squeue','-h','-j',','.join(str(j) for j in expected.values()),'-o','%i|%T']).splitlines()
    if len(rows)!=3 or any(row.split('|')[-1].strip()!='PENDING' for row in rows):raise ValueError('Parent is no longer wholly pending')
def verify_probe(node,job):
    text=run(['scontrol','-o','show','job',str(job)])
    rows=[line for line in text.splitlines() if line.startswith('JobId=')]
    if len(rows)!=1:raise ValueError('Probe scheduler identity missing')
    fields=dict(item.split('=',1) for item in rows[0].split() if '=' in item)
    if fields.get('Command')!=str(directory/(node+'.sbatch')) or fields.get('WorkDir')!=str(directory):
        raise ValueError('Probe path identity mismatch')
    return fields
record('BEGIN',science_started=False,formal_jobs=expected,maximum_simultaneous_gpus=1,maximum_simultaneous_cpu_cores=4)
parent_pending()
for node in ('ngu201','ngu002'):
    text=run(['scontrol','-o','show','node',node])
    if not any('State='+state in text for state in ('IDLE','MIXED')) or any(flag in text for flag in ('DRAIN','DOWN','RESERVED')):
        raise ValueError('Candidate became unavailable')
inventory=run(['sinfo','-N','-h','-n','ngu201,ngu002','-O','nodelist:20,statelong:20,gres:20,gresused:30,cpusstate:22'])
seen=set()
for line in inventory.splitlines():
    node,state,configured,used,cpus=line.split()
    total=int(re.fullmatch(r'gpu:([0-9]+)',configured).group(1))
    match=re.search(r'(?:^|,)gpu:([0-9]+)',used)
    if node not in ('ngu201','ngu002') or state not in ('idle','mixed') or match is None:
        raise ValueError('Candidate inventory became unavailable or ambiguous')
    if total-int(match.group(1))<1 or int(cpus.split('/')[1])<4:
        raise ValueError('Candidate no longer has one free GPU and four idle CPU cores')
    seen.add(node)
if seen!={'ngu201','ngu002'}:raise ValueError('Incomplete candidate inventory')
probes={};dependency_changed=False;first_released=False;first_release_attempted=False
try:
    for node,partition in [('ngu201','hgpu8'),('ngu002','hgpu2p')]:
        command=['sbatch','--parsable','--hold','--partition='+partition,'--nodelist='+node,
                 '--gres=gpu:1','--cpus-per-task=4','--time=00:03:00','--no-requeue',
                 '--job-name=hydrol85935-compat-'+node,'--chdir='+str(directory),
                 '--output='+str(directory/(node+'-%j.out')),'--error='+str(directory/(node+'-%j.err'))]
        if probes:command.append('--dependency=afterany:'+str(probes['ngu201']))
        command.append(str(directory/(node+'.sbatch')))
        result=run(command).strip().split(';')[0]
        if not re.fullmatch('[0-9]+',result):raise RuntimeError('Submission outcome uncertain; do not resubmit')
        probes[node]=int(result)
        # Persist every confirmed ID before another scheduler mutation.
        with (directory/('submission_'+node+'.json')).open('x') as f:json.dump(dict(node=node,job_id=int(result)),f)
        verify_probe(node,int(result))
    registry=dict(probes=probes,formal_jobs=expected,resource_chain='ngu201 -> ngu002 -> original formal train array',
                  formal_dependency_before='(null)',maximum_simultaneous_gpus=1,maximum_simultaneous_cpu_cores=4)
    with (directory/'jobs.json').open('x') as f:json.dump(registry,f,indent=2)
    parent_pending()
    run(['scontrol','update','JobId=240076','Dependency=afterany:'+str(probes['ngu002'])]);dependency_changed=True
    parent_pending('afterany:'+str(probes['ngu002']))
    detail=run(['scontrol','-o','show','job','240076'])
    if 'Dependency=afterany:'+str(probes['ngu002']) not in detail:raise ValueError('Serial dependency was not confirmed')
    # First probe remains held until all downstream dependencies are installed and checked.
    run(['scontrol','release',str(probes['ngu002'])])
    first_release_attempted=True
    run(['scontrol','release',str(probes['ngu201'])]);first_released=True
    record('SUBMITTED_SERIAL_COMPATIBILITY_PROBES',**registry,other_jobs_modified=False,
           original_formal_job_ids_preserved=True,automatic_resume='afterany dependency, including probe failure')
except Exception as error:
    record('SUBMISSION_FAILED',reason=type(error).__name__+': '+str(error),probes=probes,
           dependency_changed=dependency_changed,first_released=first_released,
           first_release_attempted=first_release_attempted)
    # A release with an uncertain reply may already have started the probe.
    # Keep the parent dependency in that case rather than allow concurrent GPUs.
    if not first_release_attempted:
        for node,job in probes.items():
            fields=verify_probe(node,job)
            if fields['JobState']=='PENDING':run(['scancel',str(job)])
        if dependency_changed:run(['scontrol','update','JobId=240076','Dependency='])
    raise
