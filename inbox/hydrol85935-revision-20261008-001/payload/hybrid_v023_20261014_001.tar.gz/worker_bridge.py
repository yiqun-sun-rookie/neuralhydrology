import hashlib, runpy
from pathlib import Path
p=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/hybrid_v023_20261014_001/worker.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='b4e05169b036ef936a26b7cbd09c2216533019053eabfbd1662d51d1b941cfd8'
runpy.run_path(str(p),run_name='__main__')
