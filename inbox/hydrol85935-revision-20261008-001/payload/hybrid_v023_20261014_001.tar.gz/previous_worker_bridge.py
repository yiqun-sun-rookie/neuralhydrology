import hashlib, runpy
from pathlib import Path
p=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/hybrid_v022_20261014_001/worker.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='0330bce87d6e6740dc352440bafc9cc18066947ca029b5aa6eb4fb9f25adb495'
runpy.run_path(str(p),run_name='__main__')
