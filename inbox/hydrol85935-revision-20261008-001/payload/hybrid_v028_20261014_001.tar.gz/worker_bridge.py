import hashlib, runpy
from pathlib import Path
p=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/hybrid_v028_20261014_001/worker.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='dede5cd6969003a4e917c621eb3d1ec579b93f4fbc03f2baba1643d3279a6431'
runpy.run_path(str(p),run_name='__main__')
