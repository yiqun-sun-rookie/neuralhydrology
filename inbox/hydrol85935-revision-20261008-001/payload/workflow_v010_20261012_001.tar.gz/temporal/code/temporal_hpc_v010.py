"""Bind the unchanged temporal experiment to actual hpc_v009 trained assets.

The parent queue stays untouched. The new preflight waits for its export job,
which waits for parent validation; later temporal phases are strictly serial.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys


def load_base(root):
    path = root / 'versions/v002/advance.py'
    spec = importlib.util.spec_from_file_location('temporal_reviewed_base_v004', path)
    base = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    return base


def bind(base, root):
    binding = base.read(root / 'control/parent_binding_v010.json')
    if binding['parent_execution_version'] != 'hpc_v009' or binding['parent_code_version'] != 'v004':
        raise ValueError('Unknown actual parent binding')
    original_probe, original_script = base.training_probe, base.job_script
    base.training_probe = lambda parent, version: original_probe(parent, 'hpc_v009')
    def script(root, parent, version, stage, chunk=1):
        result = original_script(root, parent, version, stage, chunk)
        old = '--parent-root ' + (parent / 'execution/v004').as_posix()
        new = '--parent-root ' + (parent / 'execution/hpc_v009').as_posix()
        # Preflight contains two original commands (interface and resource pilot).
        if result.count(old) != (2 if stage == 'preflight' else 1):
            raise ValueError('Unexpected reviewed parent command layout')
        result = result.replace(old, new)
        return result
    base.job_script = script
    return binding


def preregister(base, root, parent, dependency):
    """Queue only the fixed preflight; actual assets are verified in allocation."""
    base.verify_parent_version(parent, 'v004')
    deployment = base.verify_bundle(root)
    folder = root / 'control/submissions'
    folder.mkdir(parents=True, exist_ok=True)
    receipt = folder / 'preflight.json'
    if receipt.exists():
        item = base.read(receipt)
        if item['deployment_sha256'] != deployment:
            raise ValueError('Different preflight deployment')
        return item
    if (folder / 'preflight.attempt.json').exists():
        raise RuntimeError('Unconfirmed prior preflight attempt: reconcile, never resubmit')
    script = base.job_script(root, parent, 'v004', 'preflight')
    script = script.replace('set -eo pipefail\n', f'#SBATCH --dependency=afterany:{dependency}\nset -eo pipefail\n', 1)
    path = folder / 'preflight.sbatch'
    with path.open('x', encoding='utf8', newline='\n') as f: f.write(script)
    record = dict(stage='preflight', parent_version='v004', actual_parent_execution='hpc_v009',
                  script_sha256=base.sha(path), deployment_sha256=deployment, array_tasks=0,
                  serial_parent_dependency=dependency)
    base.write_new(folder / 'preflight.attempt.json', record)
    result = subprocess.run(['sbatch', str(path)], capture_output=True, text=True, timeout=120)
    output = result.stdout + result.stderr
    (folder / 'preflight.submission.txt').write_text(output)
    ids = re.findall(r'(?m)^Submitted batch job ([0-9]+)$', output)
    if result.returncode or len(ids) != 1:
        raise RuntimeError('Unconfirmed preflight submission; preserve attempt')
    record.update(job_id=int(ids[0]), status='SUBMITTED')
    base.write_new(receipt, record)
    return record


def main():
    p=argparse.ArgumentParser();p.add_argument('--root',required=True,type=Path);p.add_argument('--parent',required=True,type=Path)
    p.add_argument('--register-after',type=int);a=p.parse_args()
    root,parent=a.root.resolve(),a.parent.resolve()
    if root.name!='hydrol85935_temporal_persistence_20261011_001' or root.is_relative_to(parent) or parent.is_relative_to(root):
        raise ValueError('Temporal and parent roots must be independent')
    base=load_base(root);binding=bind(base,root)
    if base.sha(root/'code/temporal_hpc_v010.py')!=base.sha(__file__):
        raise ValueError('Wrong deployed wrapper')
    if a.register_after:
        if a.register_after!=binding['serial_dependency_job']:
            raise ValueError('Wrong parent serialization dependency')
        result=preregister(base,root,parent,a.register_after)
    else:
        result=base.advance(root,parent,'v004',sys.executable)
    print('TEMPORAL_V010 '+json.dumps(result),flush=True)


if __name__=='__main__': main()
