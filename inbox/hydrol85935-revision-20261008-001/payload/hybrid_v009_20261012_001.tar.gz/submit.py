import json,subprocess,re,sys
from pathlib import Path
ROOT=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001');folder=ROOT/'control/hybrid_v009_20261012_001'
sys.path.insert(0,str(ROOT/'control/full_v004'))
from verify_preflight import verify,resource_layout
gate=verify(ROOT,'v004');layout=resource_layout(ROOT,'v004')
assert layout['chunk_size']>=25
jobs={}
with (folder/'submission_attempt.json').open('x') as f:json.dump(dict(status='STARTED',gate=gate,resource_layout=layout),f,indent=2)
with (folder/'jobs.json').open('x') as f:json.dump(jobs,f)
for stage,dependency in [('train',None),('attacks','train'),('validate','attacks')]:
    command=['sbatch']
    if dependency:command+=['--dependency=afterany:'+str(jobs[dependency])]
    command += [str(folder/(stage+'.sbatch'))]
    with (folder/(stage+'_submission_command.json')).open('x') as f:json.dump(command,f)
    try:r=subprocess.run(command,capture_output=True,text=True,timeout=120)
    except subprocess.TimeoutExpired as e:
        (folder/(stage+'_submission_unknown.txt')).write_text(str(e));raise RuntimeError('Submission uncertain; inspect before any retry')
    text=r.stdout+r.stderr;(folder/(stage+'_submission.txt')).write_text(text);print(text,flush=True)
    ids=re.findall(r'(?m)^Submitted batch job ([0-9]+)$',text)
    if r.returncode or len(ids)!=1:raise RuntimeError('Unconfirmed submission; no automatic retry')
    jobs[stage]=int(ids[0]);tmp=folder/'jobs.tmp';tmp.write_text(json.dumps(jobs,indent=2));tmp.replace(folder/'jobs.json')
print('NEW_HYBRID_JOBS '+json.dumps(jobs),flush=True)
for stage,jid in jobs.items():
    r=subprocess.run(['scontrol','show','job','-o',str(jid)],capture_output=True,text=True,timeout=30)
    print('NEW_JOB_'+stage+' '+json.dumps(dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr)),flush=True)
