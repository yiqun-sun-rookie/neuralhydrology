"""Scheduling-only wrapper; frozen v004 science and genuine endpoint identity."""
import argparse, hashlib, json, os, sys, time, traceback
from pathlib import Path
ROOT=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001')
CONTROL=ROOT/'control/hybrid_v019_20261014_001'
CODE=ROOT/'versions/v004/code'
OUTPUT=ROOT/'execution/hpc_v009'
ASSIGNMENT_SHA='30edb3afe29d820c582fcd5aa5309254f42870683030abe44e59c879371b658d'
sys.path.insert(0,str(CODE))
def read(p):return json.loads(p.read_text())
def save(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:json.dump(v,f,indent=2,allow_nan=False)
def main():
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['train','attacks','validate']);p.add_argument('index',type=int,default=0,nargs='?');args=p.parse_args()
    assert os.environ.get('SLURM_JOB_ID'), 'Compute allocation required'
    raw=(CONTROL/'assignment.json').read_bytes();assert hashlib.sha256(raw).hexdigest()==ASSIGNMENT_SHA
    assignment=json.loads(raw)
    from src.adversarial.scripts.revision_20261008.run import cli
    argv=['--root',str(OUTPUT),'--data-dir',str(ROOT/'inputs_v001'),'--data-manifest',str(ROOT/'versions/v004/DATA.sha256'),
          '--original-models-root',str(ROOT/'original_models'),'--device','cuda:0','--chunk','256']
    started=time.time();result={'stage':args.stage,'index':args.index,'job_id':os.environ['SLURM_JOB_ID'],
                              'assignment_sha256':ASSIGNMENT_SHA,'global_science_complete':False}
    rc=1
    try:
        if args.stage=='train':
            seed=assignment['hpc_training_seeds'][args.index]
            assert cli(argv+['--mode','plan'])==0
            rc=cli(argv+['--mode','train','--seed',str(seed)])
        elif args.stage=='attacks':
            task=assignment['hpc_tasks'][args.index];assert task['index']==args.index
            if task.get('delegated_to'):
                assert not task['basins'] and task['basin_count'] == 0
                result.update(status='DELEGATED_NO_SCIENCE', exit_code=0, delegated_to=task['delegated_to'],
                              original_task=task['original_task'], wall_seconds=time.time()-started)
                save(CONTROL/'stage_results'/f"attacks_{args.index}_{os.environ['SLURM_JOB_ID']}.json",result)
                print(json.dumps(result),flush=True)
                return 0
            from src.adversarial.scripts.revision_20261008.contracts import Workspace,combinations
            w=Workspace(OUTPUT,ROOT/'inputs_v001',CODE,ROOT/'original_models',ROOT/'versions/v004/DATA.sha256')
            assert w.basins()[0][task['basin_start']:task['basin_start']+task['basin_count']]==task['basins']
            assert [c.id for c in combinations() if c.model_id==task['model']]==task['combinations']
            for local in assignment['local_assignments']:
                assert task['model']!=local['model'] or not set(task['basins']) & set(local['basins'])
            rc=cli(argv+['--mode','main','--model-id',task['model'],'--basin-start',str(task['basin_start']),'--basin-count',str(task['basin_count'])])
        else:
            from src.adversarial.scripts.revision_20261008.contracts import Workspace,combinations
            from src.adversarial.scripts.revision_20261008.validation import SlotValidator,latest_ledger
            from src.adversarial.scripts.revision_20261008.assets import verify_training_assets
            w=Workspace(OUTPUT,ROOT/'inputs_v001',CODE,ROOT/'original_models',ROOT/'versions/v004/DATA.sha256')
            v=SlotValidator(w);ledger=latest_ledger(w,v.fingerprint);combos={c.id:c for c in combinations()}
            clean={(t['model'],b) for t in assignment['hpc_tasks'] for b in t['basins']}
            attacks={(c,b) for t in assignment['hpc_tasks'] for c in t['combinations'] for b in t['basins']}
            counts=dict(attacks=0,clean=0,restore_series=0,trainings=0);failures=[]
            for seed in assignment['hpc_training_seeds']:
                try:verify_training_assets(w,seed);counts['trainings']+=1
                except Exception as e:failures.append(dict(kind='training',seed=seed,error=str(e)))
            for model,basin in sorted(clean):
                try:v.clean(model,basin);counts['clean']+=1
                except Exception as e:failures.append(dict(kind='clean',model=model,basin=basin,error=str(e)))
            for c,basin in sorted(attacks):
                try:
                    record=v.attack(combos[c],basin)
                    if record is None:raise ValueError(str(ledger.get((c,basin),{'status':'not_executed'})))
                    arrays,metadata=record;counts['attacks']+=1
                    if 'importance' in metadata['details']:counts['restore_series']+=int(arrays['q_signal_restored'].shape[0])
                except Exception as e:failures.append(dict(kind='attack',combination=c,basin=basin,error=str(e)))
            unexpected=sorted(v.present_clean-clean)+sorted(v.present_attacks-attacks)
            result.update(counts=counts,failures=failures,unexpected=unexpected,expected=assignment['hpc_counts'])
            rc=0 if counts==assignment['hpc_counts'] and not failures and not unexpected else 4
            result['hpc_subset_complete']=rc==0
    except Exception:
        result['traceback']=traceback.format_exc();traceback.print_exc();rc=4
    result.update(exit_code=rc,wall_seconds=time.time()-started,status='PASS' if rc==0 else 'FAIL')
    save(CONTROL/'stage_results'/f"{args.stage}_{args.index}_{os.environ['SLURM_JOB_ID']}.json",result)
    print(json.dumps(result),flush=True);return rc
if __name__=='__main__':raise SystemExit(main())
