import hashlib, runpy
from pathlib import Path
p=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/hybrid_v018_20261014_001/worker.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='af90dc1f723de2cb4c8a314399f62359f404214f753c8e5c2d42a45224139e4a'
runpy.run_path(str(p),run_name='__main__')
