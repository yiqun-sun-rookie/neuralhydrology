import hashlib, runpy
from pathlib import Path
p=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/hybrid_v019_20261014_001/worker.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='a5ca0cc764c54e386a5728b5fc0e3e91890cadb82b7c74f57a457109fa16c730'
runpy.run_path(str(p),run_name='__main__')
