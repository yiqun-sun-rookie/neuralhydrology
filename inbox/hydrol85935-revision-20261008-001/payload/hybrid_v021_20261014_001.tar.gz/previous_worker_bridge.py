import hashlib, runpy
from pathlib import Path
p=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/hybrid_v020_20261014_001/worker.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='963f33dbb3a9d50e9d122e2877d9e31261a989214e6408985093b34d725e2cb3'
runpy.run_path(str(p),run_name='__main__')
