"""Single-temperature training, preserving all original scientific settings."""
from __future__ import annotations

import json
from pathlib import Path

import yaml

from .contracts import IDENTITY, FEATURES4, FEATURES5, SEEDS, sha256, digest_json
from .records import json_write


def training_config(workspace, seed, device):
    if seed not in SEEDS:
        raise ValueError("Only seeds 100, 200, 300 are permitted")
    source = workspace.model_dir(f"original_s{seed}") / "config.yml"
    original = yaml.safe_load(source.read_text(encoding="utf-8"))
    if original["dynamic_inputs"] != list(FEATURES5) or original["epochs"] != 30 or original["seed"] != seed:
        raise ValueError("Original frozen training contract does not match")
    basins, _ = workspace.basins()
    basin_file = workspace.repo / "src/xaj_global_pilot/configs/conceptual_benchmark_camels_us_531_repro.txt"
    cfg = dict(original)
    cfg["dynamic_inputs"] = list(FEATURES4)
    cfg["experiment_name"] = f"{IDENTITY}_single_temperature_s{seed}"
    cfg["data_dir"] = str(workspace.data_dir)
    cfg["run_dir"] = str(workspace.output(f"training/s{seed}/runs"))
    cfg["device"] = device
    for key in ("train_basin_file", "test_basin_file", "validation_basin_file"):
        cfg[key] = str(basin_file)
    # NH sets these new paths when it creates the training run; omit historical derived fields.
    removed = {k: cfg.pop(k) for k in ("train_dir", "img_log_dir", "commit_hash", "package_version") if k in cfg}
    changed = {key: {"before": original.get(key), "after": value} for key, value in cfg.items() if original.get(key) != value}
    allowed = {"dynamic_inputs", "experiment_name", "data_dir", "run_dir", "device", "train_basin_file", "test_basin_file", "validation_basin_file"}
    if set(changed) - allowed:
        raise ValueError("Unapproved scientific training changes")
    metadata = dict(source_config_sha256=sha256(source), config_sha256=digest_json(cfg), seed=seed, epoch=30,
                    changed_fields=changed, removed_derived_fields=removed, no_evaluation_based_selection=True,
                    temperature_semantics="Tmin(C) is Maurer daily mean temperature; Tmax(C) duplicate deleted")
    return cfg, metadata


def prepare_training(workspace, seed, device, manifest_hash):
    cfg, metadata = training_config(workspace, seed, device)
    metadata["manifest_sha256"] = manifest_hash
    directory = workspace.output(f"training/s{seed}")
    path = directory / "training_config.yml"
    if path.exists():
        if yaml.safe_load(path.read_text()) != cfg or json.loads((directory / "training_metadata.json").read_text())["manifest_sha256"] != manifest_hash:
            raise ValueError("Existing training configuration has different identity")
    else:
        directory.mkdir(parents=True, exist_ok=True)
        path.write_text(yaml.safe_dump(cfg, sort_keys=False), encoding="utf-8")
        json_write(directory / "training_metadata.json", metadata)
    return path, metadata


def train(workspace, seed, device, manifest_hash):
    path, metadata = prepare_training(workspace, seed, device, manifest_hash)
    complete = workspace.output(f"training/s{seed}/complete.json")
    if complete.exists():
        marker = json.loads(complete.read_text())
        if marker["manifest_sha256"] != manifest_hash or marker["config_sha256"] != metadata["config_sha256"]:
            raise ValueError("Existing completed training has different identity")
        run = workspace.model_dir(f"single_temperature_s{seed}")
        return dict(status="reused", run_relative_path=str(run.relative_to(workspace.root)))
    runs = workspace.output(f"training/s{seed}/runs")
    if runs.exists() and any(runs.iterdir()):
        raise ValueError("Incomplete prior training exists; refused silent retry or seed replacement")
    from neuralhydrology.nh_run import start_run
    gpu = -1 if device == "cpu" else int(device.split(":")[-1])
    start_run(path, gpu=gpu)
    directories = list(runs.iterdir())
    if len(directories) != 1 or not (directories[0] / "model_epoch030.pt").exists():
        raise ValueError("Training did not produce exactly one fixed epoch30 run")
    run = directories[0]
    marker = dict(status="complete", run_relative_path=str(run.relative_to(workspace.root)),
                  weight_sha256=sha256(run / "model_epoch030.pt"), manifest_sha256=manifest_hash,
                  config_sha256=metadata["config_sha256"], epoch=30, seed=seed)
    json_write(complete, marker)
    return marker


def training_smoke(workspace, seed, basin, device):
    """One original-size batch through fresh four-column NH model/loss/Adam; no scientific weights saved."""
    import time
    import torch
    from torch.utils.data import DataLoader
    from neuralhydrology.datasetzoo import get_dataset
    from neuralhydrology.datautils.utils import load_scaler
    from neuralhydrology.modelzoo import get_model
    from neuralhydrology.training import get_loss_obj, get_optimizer
    from neuralhydrology.utils.config import Config
    cfg_dict, metadata = training_config(workspace, seed, device)
    smoke_dir = workspace.output(f"preflight/training_smoke_s{seed}_{basin}")
    smoke_dir.mkdir(parents=True, exist_ok=True)
    cfg_dict["train_dir"] = str(smoke_dir)
    cfg = Config(cfg_dict)
    started = time.perf_counter()
    torch.manual_seed(seed)
    dataset = get_dataset(cfg=cfg, is_train=True, period="train", basin=basin,
                          scaler=load_scaler(workspace.model_dir(f"original_s{seed}")), id_to_int={})
    loader = DataLoader(dataset, batch_size=cfg.batch_size, shuffle=False, collate_fn=dataset.collate_fn, num_workers=0)
    batch = next(iter(loader))
    for key in batch:
        if isinstance(batch[key], dict):
            batch[key] = {f: value.to(device) for f, value in batch[key].items()}
        elif torch.is_tensor(batch[key]):
            batch[key] = batch[key].to(device)
    model = get_model(cfg).to(device).train()
    optimizer, loss_obj = get_optimizer(model, cfg), get_loss_obj(cfg).to(device)
    if device.startswith("cuda"):
        torch.cuda.reset_peak_memory_stats(device)
        torch.cuda.synchronize(device)
    t = time.perf_counter()
    optimizer.zero_grad()
    predictions = model(batch)
    loss, _ = loss_obj(predictions, batch)
    if not torch.isfinite(loss):
        raise ValueError("Nonfinite single-batch training loss")
    loss.backward()
    if any(p.grad is not None and not torch.isfinite(p.grad).all() for p in model.parameters()):
        raise ValueError("Nonfinite single-batch training gradients")
    torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.clip_gradient_norm)
    optimizer.step()
    if device.startswith("cuda"):
        torch.cuda.synchronize(device)
    return dict(status="PASS", scope="one batch resource/interface check; not one of three scientific trainings",
                basin=basin, batch_size=int(batch["y"].shape[0]), features=cfg.dynamic_inputs,
                prediction_dates="training interval only", training_windows=len(dataset), single_update_seconds=time.perf_counter() - t,
                total_seconds=time.perf_counter() - started, training_loss=float(loss.detach()),
                reference_scaler="original scaler supplied and reused for this smoke; full training computes its own 531-basin scaler",
                weights_saved=False, optimizer_updates=1, configured_epochs=30, config_identity=metadata["config_sha256"],
                cuda_peak_allocated_bytes=torch.cuda.max_memory_allocated(device) if device.startswith("cuda") else 0)
