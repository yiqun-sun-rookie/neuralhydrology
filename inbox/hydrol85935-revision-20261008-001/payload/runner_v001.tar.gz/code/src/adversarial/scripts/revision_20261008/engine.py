"""One perturbation per calendar date and independent meteorological signal."""
from __future__ import annotations

import numpy as np
import torch
from scipy.signal import find_peaks

from .contracts import FEATURES4, FEATURES5, SIGNALS, CONDITIONS, SCIENCE, stable_seed


class UndefinedTarget(ValueError):
    """A scientific target cannot be computed; never replace its denominator."""


class SignalMap:
    def __init__(self, features, center, scale, reference_std, epsilon, device="cpu"):
        self.features = tuple(features)
        if self.features not in (FEATURES4, FEATURES5):
            raise ValueError("Unknown, duplicate, missing or reordered feature mapping")
        self.groups = [[self.features.index(f)] for f in FEATURES4]
        if "Tmax(C)" in self.features:
            self.groups[1].append(self.features.index("Tmax(C)"))
        self.signal_to_feature_columns = dict(zip(SIGNALS, self.groups))
        self.feature_to_signal = [next(i for i, g in enumerate(self.groups) if j in g)
                                  for j in range(len(self.features))]
        c, s = np.asarray(center), np.asarray(scale)
        r = np.asarray(reference_std)
        if c.shape != (len(features),) or s.shape != c.shape or r.shape != (4,):
            raise ValueError("Scaler/reference shapes disagree")
        if not np.isfinite(c).all() or not np.isfinite(s).all() or not np.isfinite(r).all() or (s <= 0).any() or (r <= 0).any() or epsilon <= 0:
            raise ValueError("Invalid scale or budget")
        if len(self.groups[1]) == 2 and (c[self.groups[1][0]] != c[self.groups[1][1]] or s[self.groups[1][0]] != s[self.groups[1][1]]):
            raise ValueError("Two temperature scalers differ")
        self.center = torch.tensor(c[[g[0] for g in self.groups]], dtype=torch.float32, device=device)
        self.scale = torch.tensor(s[[g[0] for g in self.groups]], dtype=torch.float32, device=device)
        self.reference_std = torch.tensor(r, dtype=torch.float32, device=device)
        self.budget_physical = self.reference_std * epsilon
        self.budget = self.budget_physical / self.scale
        self.minimum = torch.tensor([0., -50., 0., 0.], device=device)
        self.maximum = torch.tensor([500., 50., 1361., 10000.], device=device)

    def collapse_clean(self, calendar):
        if calendar.shape[1] != len(self.features):
            raise ValueError("Model input dimension disagrees")
        if len(self.groups[1]) == 2 and not torch.equal(calendar[:, self.groups[1][0]], calendar[:, self.groups[1][1]]):
            raise ValueError("Original temperature daily values differ; cannot bind")
        return calendar[:, [g[0] for g in self.groups]]

    def expand(self, delta):
        return delta[:, self.feature_to_signal]

    def sum_gradient(self, gradient):
        return torch.stack([gradient[:, g].sum(dim=1) for g in self.groups], dim=1)

    def metadata(self):
        return dict(dynamic_feature_names=list(self.features), signal_to_feature_columns=self.signal_to_feature_columns,
                    reference_signal_std_physical=self.reference_std.cpu().tolist(),
                    signal_budget_physical=self.budget_physical.cpu().tolist(), signal_budget_normalized=self.budget.cpu().tolist(),
                    signal_center_physical=self.center.cpu().tolist(), signal_scale_physical=self.scale.cpu().tolist(),
                    signal_units=["mm/day", "degree Celsius (daily mean)", "W/m2", "Pa"])


def physical_metrics(obs, pred, mask, high_mask=None):
    obs, pred, mask = np.asarray(obs, dtype=np.float64), np.asarray(pred, dtype=np.float64), np.asarray(mask, bool)
    if obs.shape != pred.shape or mask.shape != obs.shape or not np.isfinite(pred).all():
        raise ValueError("Nonfinite predictions or inconsistent metric dimensions")
    if not np.isfinite(obs[mask]).all():
        raise ValueError("Fixed scoring mask contains nonfinite observations")
    y, p = obs[mask], pred[mask]
    n = len(y)
    def result(value, reason="", count=n):
        return dict(value=float(value) if value is not None else None, count=int(count),
                    status="complete" if value is not None else "uncomputable", reason=reason)
    out = {}
    out["rmse"] = result(np.sqrt(np.mean((y - p) ** 2))) if n else result(None, "no_valid_observations")
    if n < 2:
        out["nse"], out["kge"] = result(None, "fewer_than_two_observations"), result(None, "fewer_than_two_observations")
    elif np.sum((y - y.mean()) ** 2) == 0:
        out["nse"], out["kge"] = result(None, "zero_observed_variance"), result(None, "zero_observed_variance")
    else:
        out["nse"] = result(1 - np.sum((y - p) ** 2) / np.sum((y - y.mean()) ** 2))
        if abs(y.mean()) <= SCIENCE["mean_zero_tolerance"]:
            out["kge"] = result(None, "zero_or_near_zero_observed_mean")
        elif np.std(p) == 0:
            out["kge"] = result(None, "constant_prediction_correlation_undefined")
        else:
            r, alpha, beta = np.corrcoef(y, p)[0, 1], np.std(p) / np.std(y), p.mean() / y.mean()
            out["kge"] = result(1 - np.sqrt((r - 1) ** 2 + (alpha - 1) ** 2 + (beta - 1) ** 2))
    if high_mask is None:
        high_mask = mask & (obs > np.quantile(y, .9)) if n else np.zeros_like(mask)
    high_mask = np.asarray(high_mask, bool)
    count = int(high_mask.sum())
    out["high_flow_rmse"] = result(np.sqrt(np.mean((obs[high_mask] - pred[high_mask]) ** 2)), count=count) if count else result(None, "no_fixed_high_flow_days", 0)
    return out


def metric_changes(clean, attacked):
    return {name: dict(clean=c["value"], attacked=attacked[name]["value"],
                       change=(None if c["value"] is None or attacked[name]["value"] is None else
                               (c["value"] - attacked[name]["value"] if name in ("nse", "kge") else attacked[name]["value"] - c["value"])),
                       count=attacked[name]["count"], status=attacked[name]["status"], reason=attacked[name]["reason"])
            for name, c in clean.items()}


def peak_locations(observations, scoring_mask, length, window_length, device="cpu"):
    y = np.asarray(observations, float).copy()
    mask = np.asarray(scoring_mask, bool)
    if mask.sum() < 2:
        raise UndefinedTarget("fewer_than_two_valid_observations")
    threshold = float(np.quantile(y[mask], .95))
    y[~mask] = -1e30
    peaks = find_peaks(y, height=threshold, distance=14)[0]
    if len(peaks) < 2:
        raise UndefinedTarget("fewer_than_two_observed_peaks")
    if np.sum((y[peaks] - y[peaks].mean()) ** 2) == 0:
        raise UndefinedTarget("zero_peak_observed_variance")
    peak_cal = peaks + window_length - 1
    pre = np.zeros(length, bool)
    for index in peak_cal:
        pre[max(0, index - 14):index] = True
    target_days = int(pre.sum())
    peak_mask = np.zeros(length, bool)
    peak_mask[peak_cal] = True
    random = np.zeros(length, bool)
    gen = torch.Generator().manual_seed(9973)
    hi = max(1, length - 14)
    max_draws = 200 + 40 * (target_days // 14 + 1)
    draws = 0
    while random.sum() < target_days and draws < max_draws:
        start = int(torch.randint(0, hi, (1,), generator=gen))
        draws += 1
        segment = slice(start, min(start + 14, length))
        if not peak_mask[segment].any():
            random[segment] = True
    if random.sum() < target_days:
        raise ValueError(f"random_location_construction_failed: target={target_days}, actual={random.sum()}, draws={draws}")
    target = np.zeros(len(y), bool)
    target[peaks] = True
    metadata = dict(threshold=threshold, distance=14, window_days=14, target_days=target_days,
                    actual_random_days=int(random.sum()), max_draws=max_draws, draws=draws,
                    randint_low_inclusive=0, randint_high_exclusive=hi, location_seed=9973,
                    overlap_days=int((pre & random).sum()), pre_allowed_peak_count=int(pre[peak_cal].sum()),
                    random_allowed_peak_count=int(random[peak_cal].sum()))
    return peaks, peak_cal, torch.tensor(pre, device=device), torch.tensor(random, device=device), torch.tensor(target, device=device), metadata


class BasinEngine:
    def __init__(self, wrapper, data, mapping, q_center, q_scale, chunk=64):
        if chunk <= 0:
            raise ValueError("chunk must be positive")
        self.wrapper, self.data, self.map = wrapper, data, mapping
        self.q_center, self.q_scale, self.chunk = q_center, q_scale, chunk
        self.clean = mapping.collapse_clean(data.calendar)
        self.zero = torch.zeros_like(self.clean)
        self.mask, self.y = data.scoring_mask, data.observations
        if self.mask.sum() < 2:
            raise UndefinedTarget("fewer_than_two_observations")
        y = self.y[self.mask]
        self.denominator = ((y - y.mean()) ** 2).sum()
        if self.denominator <= 0 or not torch.isfinite(self.denominator):
            raise UndefinedTarget("zero_or_nonfinite_observed_variance")
        self.clean_pred = self.predict(self.zero)
        self.clean_nse = self.score(self.clean_pred)
        self.common_observations = None
        self.common_peak_observations = None

    def predict(self, delta, grad=False):
        values = []
        length, n = self.data.window_length, len(self.y)
        calendar = self.data.calendar + self.map.expand(delta)
        context = torch.enable_grad() if grad else torch.no_grad()
        with context:
            for start in range(0, n, self.chunk):
                stop = min(start + self.chunk, n)
                x = calendar[start:stop + length - 1].unfold(0, length, 1).permute(0, 2, 1)
                static = self.data.static.unsqueeze(0).expand(stop - start, -1)
                pred = self.wrapper(x, static)[:, -1, 0]
                if not torch.isfinite(pred).all():
                    raise ValueError("nonfinite_model_prediction")
                values.append(pred)
        return torch.cat(values)

    def score(self, prediction, target=None):
        mask = self.mask if target is None else target
        y, p = self.y[mask], prediction[mask]
        denominator = ((y - y.mean()) ** 2).sum()
        if mask.sum() < 2 or denominator <= 0:
            raise UndefinedTarget("undefined_target_variance")
        value = 1 - ((y - p) ** 2).sum() / denominator
        if not torch.isfinite(value):
            raise ValueError("nonfinite_target_score")
        return float(value.detach())

    def gradient(self, delta, target=None):
        d = delta.detach().clone().requires_grad_(True)
        mask = self.mask if target is None else target
        length, n = self.data.window_length, len(self.y)
        # Each backward builds its own calendar expression, retaining no old chunk graph.
        for start in range(0, n, self.chunk):
            stop = min(start + self.chunk, n)
            subset = mask[start:stop]
            if not subset.any():
                continue
            calendar = self.data.calendar[start:stop + length - 1] + self.map.expand(d[start:stop + length - 1])
            x = calendar.unfold(0, length, 1).permute(0, 2, 1)
            static = self.data.static.unsqueeze(0).expand(stop - start, -1)
            p = self.wrapper(x, static)[:, -1, 0]
            if not torch.isfinite(p).all():
                raise ValueError("nonfinite_gradient_path_prediction")
            (((self.y[start:stop][subset] - p[subset]) ** 2).sum() / self.denominator).backward()
        if d.grad is None or not torch.isfinite(d.grad).all():
            raise ValueError("missing_or_nonfinite_gradient")
        return d.grad.detach()

    def project(self, delta, condition):
        if condition not in CONDITIONS:
            raise ValueError(f"Unknown constraint: {condition}")
        b, scale, center = self.map.budget, self.map.scale, self.map.center
        def hard(d):
            d = torch.maximum(torch.minimum(d, b), -b)
            if condition != "bound_only":
                lower = (self.map.minimum - center) / scale - self.clean
                upper = (self.map.maximum - center) / scale - self.clean
                if ((lower > b + 1e-6) | (upper < -b - 1e-6)).any():
                    raise ValueError("physical_and_amplitude_constraints_have_empty_intersection")
                d = torch.maximum(torch.minimum(d, upper), lower)
                d = torch.maximum(torch.minimum(d, b), -b)
            return d
        projected = hard(delta)
        if condition == "whole_period_moment_adjustment":
            values = self.clean + projected
            values = (values - values.mean(0)) / values.std(0, correction=1).clamp(min=1e-8)
            projected = hard(values * self.clean.std(0, correction=1) + self.clean.mean(0) - self.clean)
        checks = self.check(projected, condition)
        if checks["amplitude_violations"] or checks["physical_violations"] or not checks["finite"]:
            raise ValueError(f"Final hard constraint violation: {checks}")
        return projected.detach()

    def check(self, delta, condition):
        physical_clean = self.clean * self.map.scale + self.map.center
        physical = (self.clean + delta) * self.map.scale + self.map.center
        tolerance = 1e-6 * self.map.scale
        return dict(finite=bool(torch.isfinite(delta).all()),
                    amplitude_violations=int((delta.abs() > self.map.budget + 1e-6).sum()),
                    physical_violations=(int(((physical < self.map.minimum - tolerance) | (physical > self.map.maximum + tolerance)).sum()) if condition != "bound_only" else 0),
                    clean_physical_violations=int(((physical_clean < self.map.minimum - tolerance) | (physical_clean > self.map.maximum + tolerance)).sum()),
                    actual_max_abs_normalized=delta.abs().amax(0).cpu().tolist(),
                    physical_minimum=physical.amin(0).cpu().tolist(), physical_maximum=physical.amax(0).cpu().tolist(),
                    physical_mean_shift=(physical.mean(0) - physical_clean.mean(0)).cpu().tolist(),
                    physical_std_shift=(physical.std(0, correction=1) - physical_clean.std(0, correction=1)).cpu().tolist())

    def sample(self, seed, kind):
        gen = torch.Generator().manual_seed(seed)
        length = len(self.clean)
        if kind == "uniform":
            values = torch.rand((length, 4), generator=gen) * 2 - 1
        elif kind == "gaussian":
            values = torch.randn((length, 4), generator=gen).clamp(-1, 1)
        elif kind in ("random_sign", "block_sign"):
            blocks = (length + 6) // 7 if kind == "block_sign" else length
            values = (torch.randint(0, 2, (blocks, 4), generator=gen) * 2 - 1).float()
            if kind == "block_sign":
                values = values.repeat_interleave(7, 0)[:length]
        else:
            raise ValueError("Unknown random method")
        return values.to(self.clean.device) * self.map.budget

    def attack(self, combination, basin_id, steps=50, candidates=100):
        c = combination
        target, location, peak_info = None, torch.ones(len(self.clean), dtype=torch.bool, device=self.clean.device), {}
        peaks, peak_cal = np.array([], int), np.array([], int)
        if c.target == "observed_peaks":
            shared_y = self.common_peak_observations if self.common_peak_observations is not None else self.y.detach().cpu().numpy()
            peaks, peak_cal, pre, random, target, peak_info = peak_locations(
                shared_y, self.mask.cpu().numpy(), len(self.clean), self.data.window_length, self.clean.device)
            location = pre if c.location == "pre_peak" else random
        elif c.target != "whole_period" or c.location != "whole_calendar":
            raise ValueError("Unknown target/location")
        trajectory, candidate_table = [], []
        clean_score = self.score(self.clean_pred, target)
        include_clean = c.method in ("gaussian", "random_sign", "block_sign") or target is not None
        best_score, best_delta, best_iteration = (clean_score, self.zero.clone(), -1) if include_clean else (float("inf"), None, None)
        def evaluate(delta, iteration, step_size, seed=None):
            nonlocal best_score, best_delta, best_iteration
            pred = self.predict(delta)
            current = self.score(pred, target)
            if current < best_score:
                best_score, best_delta, best_iteration = current, delta.clone(), iteration
            item = dict(iteration=iteration, step_size=step_size.cpu().tolist(), current_nse=current,
                        best_nse=best_score, best_iteration=best_iteration, feasibility_status="PASS")
            if seed is not None:
                item["seed"] = seed
            trajectory.append(item)
            return current
        if c.method in ("gaussian", "random_sign", "block_sign"):
            initial = self.zero.clone()
            unmasked_initial = initial.clone()
            candidate_table.append(dict(candidate=-1, seed=None, nse=clean_score))
            for k in range(candidates):
                seed = stable_seed(basin_id, c.method, c.epsilon, k)
                d = self.project(self.sample(seed, c.method), c.condition)
                score = evaluate(d, k, self.zero[0], seed)
                candidate_table.append(dict(candidate=k, seed=seed, nse=score))
            initial_seed = None
        elif c.method == "single_step":
            initial, initial_seed = self.zero.clone(), None
            unmasked_initial = initial.clone()
            d = self.project(self.map.budget * self.gradient(self.zero, target).sign(), c.condition)
            evaluate(d, 1, self.map.budget)
        elif c.method == "iterative":
            initial_seed = 0 if target is not None else stable_seed(basin_id, "iterative", c.epsilon, -1)
            unmasked_initial = self.zero.clone() if c.initialization == "zero" else self.sample(initial_seed, "uniform")
            initial = self.project(unmasked_initial * location[:, None], c.condition)
            d, alpha = initial.clone(), 2 * self.map.budget
            evaluate(d, 0, alpha, initial_seed)
            for t in range(steps):
                gradient = self.gradient(d, target) * location[:, None]
                d = self.project(d + alpha * gradient.sign(), c.condition) * location[:, None]
                evaluate(d, t + 1, alpha)
                if t in (11, 25, 37):
                    alpha = alpha * .5
        else:
            raise ValueError("Unknown method")
        best_pred = self.predict(best_delta)
        if abs(self.score(best_pred, target) - best_score) > 1e-6:
            raise ValueError("Saved best array and prediction/score disagree")
        physical_obs = self.y.detach().cpu().numpy() * self.q_scale + self.q_center
        physical_clean = self.clean_pred.detach().cpu().numpy() * self.q_scale + self.q_center
        physical_adv = best_pred.detach().cpu().numpy() * self.q_scale + self.q_center
        mask = self.mask.cpu().numpy()
        high_mask = mask & (physical_obs > np.quantile(physical_obs[mask], .9))
        changes = metric_changes(physical_metrics(physical_obs, physical_clean, mask, high_mask),
                                 physical_metrics(physical_obs, physical_adv, mask, high_mask))
        nonzero = best_delta.abs().amax(1).cpu().numpy() > 0
        peak_info.update(allowed_days=int(location.sum()), actual_nonzero_days=int(nonzero.sum()),
                         allowed_peak_dates=self.data.calendar_dates[peak_cal[location.cpu().numpy()[peak_cal]]].astype(str).tolist(),
                         actually_modified_peak_dates=self.data.calendar_dates[peak_cal[nonzero[peak_cal]]].astype(str).tolist())
        if c.location == "random_non_peak" and (peak_info["allowed_peak_dates"] or peak_info["actually_modified_peak_dates"]):
            raise ValueError("Random non-peak location modifies observed peak dates")
        arrays = dict(delta_signals=best_delta.cpu().numpy(), delta_features=self.map.expand(best_delta).cpu().numpy(),
                      initial_delta_signals=initial.cpu().numpy(), unmasked_initial_delta_signals=unmasked_initial.cpu().numpy(),
                      q_observed=physical_obs, q_clean=physical_clean, q_attacked=physical_adv,
                      calendar_dates=self.data.calendar_dates.astype(str), prediction_dates=self.data.prediction_dates.astype(str),
                      scoring_mask=mask, high_flow_mask=high_mask, location_mask=location.cpu().numpy(),
                      target_mask=(self.mask if target is None else target).cpu().numpy(),
                      peak_prediction_index=peaks, peak_calendar_index=peak_cal,
                      clean_calendar_features=self.data.calendar.cpu().numpy(),
                      window_start_calendar_index=self.data.window_index[:, 0],
                      block_start_index=np.arange(0, len(self.clean), 7, dtype=np.int64) if c.method == "block_sign" else np.array([], np.int64),
                      block_length=np.minimum(7, len(self.clean) - np.arange(0, len(self.clean), 7)) if c.method == "block_sign" else np.array([], np.int64))
        event_source = self.common_observations if self.common_observations is not None else physical_obs
        event_y = event_source.astype(float).copy()
        event_y[~mask] = -1e30
        event_peaks = find_peaks(event_y, height=float(np.quantile(event_source[mask], .95)), distance=14)[0]
        events = []
        for p in event_peaks:
            lo, hi = max(0, int(p) - 7), min(len(self.y), int(p) + 8)
            clean_peak, adv_peak = float(physical_clean[lo:hi].max()), float(physical_adv[lo:hi].max())
            events.append(dict(date=str(self.data.prediction_dates[p]), prediction_index=int(p),
                               window_start=str(self.data.prediction_dates[lo]), window_end=str(self.data.prediction_dates[hi - 1]),
                               clean_local_peak=clean_peak, attacked_local_peak=adv_peak,
                               amplitude_change_fraction=(adv_peak - clean_peak) / clean_peak if clean_peak > .1 else None,
                               exclusion_reason="" if clean_peak > .1 else "clean_local_peak_at_most_0p1_mm_day"))
        metadata = dict(metrics=changes, clean_target_nse=clean_score, selected_target_nse=best_score,
                        target_nse_loss=clean_score - best_score, selected_iteration=best_iteration,
                        initial_seed=initial_seed, include_clean_candidate=include_clean,
                        trajectory=trajectory, candidates=candidate_table, constraints=self.check(best_delta, c.condition),
                        mapping=self.map.metadata(), peak_location=peak_info, snow_fraction=self.data.snow_fraction,
                        snow_group="snow_affected" if self.data.snow_fraction > .2 else "low_snow",
                        q_center=self.q_center, q_scale=self.q_scale, q_units="mm/day", window_length=self.data.window_length,
                        flood_amplitude_events=events, std_correction=1,
                        generator="torch CPU Generator; four independent signals; new supplementary path")
        return arrays, metadata

    def restore(self, delta):
        predictions, effects = [], []
        full_score = self.score(self.predict(delta))
        for index in range(4):
            d = delta.clone()
            d[:, index] = 0
            p = self.predict(d)
            predictions.append(p.cpu().numpy() * self.q_scale + self.q_center)
            effects.append(self.score(p) - full_score)
        denominator = float(sum(effects))
        return np.stack(predictions), dict(raw_importance=dict(zip(SIGNALS, effects)), normalization_denominator=denominator,
                                          normalized_importance=(dict(zip(SIGNALS, [x / denominator for x in effects])) if denominator > 0 else None),
                                          normalization_reason="" if denominator > 0 else "nonpositive_sum_not_suitable_for_ranking")
