"""Contract tests runnable with unittest, without optional pytest installation."""
import json
from pathlib import Path
import tempfile
import unittest
import sys

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from src.adversarial.scripts.revision_20261008.contracts import Combination, combinations, FEATURES4, FEATURES5, stable_seed, Workspace
from src.adversarial.scripts.revision_20261008.data import reconstruct_windows
from src.adversarial.scripts.revision_20261008.engine import SignalMap, BasinEngine, physical_metrics, peak_locations, UndefinedTarget
from src.adversarial.scripts.revision_20261008.records import save, load_complete
from src.adversarial.scripts.revision_20261008.training import training_config


class TinyModel(torch.nn.Module):
    def __init__(self, weights):
        super().__init__()
        self.register_buffer("weights", torch.tensor(weights, dtype=torch.float32))

    def forward(self, x, static):
        # Depend on the full overlapping window, preserving autograd's shared-date sum.
        pred = (x * self.weights).sum(-1).cumsum(1) / x.shape[1]
        return pred.unsqueeze(-1)


def engine5(chunk=3):
    n, length = 12, 4
    clean = torch.stack([torch.linspace(.1, .8, n + length - 1), torch.linspace(.2, .4, n + length - 1),
                         torch.linspace(.2, .4, n + length - 1), torch.linspace(.3, .8, n + length - 1),
                         torch.linspace(.6, .9, n + length - 1)], dim=-1)
    dates = np.arange(np.datetime64("1989-01-05"), np.datetime64("1989-01-05") + np.timedelta64(len(clean), "D"))
    index = np.arange(n)[:, None] + np.arange(length)[None, :]
    windows = clean.unfold(0, length, 1).permute(0, 2, 1)
    obs = torch.linspace(1., 3., n) + torch.arange(n) % 3 * .3
    data = reconstruct_windows(windows, dates[index], torch.zeros(n, 0), obs, length, False)
    data.snow_fraction = .3
    mapping = SignalMap(FEATURES5, [0, 0, 0, 0, 0], [2, 3, 3, 4, 5], [2, 3, 4, 5], .1)
    return BasinEngine(TinyModel([.4, .2, .3, .5, .1]), data, mapping, 1.5, 3.6, chunk)


class ContractTests(unittest.TestCase):
    def test_52_exact_scopes(self):
        rows = combinations()
        self.assertEqual(len(rows), 52)
        self.assertEqual(sum(c.target == "observed_peaks" for c in rows), 6)
        self.assertEqual(sum(c.epsilon == .2 for c in rows), 3)
        self.assertEqual(sum(c.id.startswith("original_s100_diagnostic") for c in rows), 4)
        for model in {c.model_id for c in rows}:
            main = [c for c in rows if c.model_id == model and "diagnostic" not in c.id and c.target == "whole_period"]
            self.assertEqual(len(main), 7)

    def test_name_mapping_and_temperature_gradient_sum(self):
        m = SignalMap(FEATURES5, [0]*5, [1]*5, [1]*4, .1)
        g = torch.tensor([[1., 2., -3., 4., 5.]])
        torch.testing.assert_close(m.sum_gradient(g), torch.tensor([[1., -1., 4., 5.]]))
        m4 = SignalMap(FEATURES4, [0]*4, [1]*4, [1]*4, .1)
        torch.testing.assert_close(m4.expand(torch.tensor([[1., 2., 8., 4.]])), torch.tensor([[1., 2., 8., 4.]]))
        self.assertEqual(m4.groups[1], [1])
        self.assertEqual(m4.groups[2], [2])

    def test_physical_budget_conversion(self):
        m = SignalMap(FEATURES4, [0]*4, [2, 4, 8, 10], [1, 2, 4, 5], .1)
        torch.testing.assert_close(m.budget, torch.full((4,), .05))
        torch.testing.assert_close(m.budget * m.scale, torch.tensor([.1, .2, .4, .5]))

    def test_duplicate_temperature_and_scaler_refused(self):
        with self.assertRaises(ValueError):
            SignalMap(FEATURES5, [0]*5, [1, 1, 2, 1, 1], [1]*4, .1)
        e = engine5()
        bad = e.data.calendar.clone()
        bad[3, 2] += .1
        with self.assertRaises(ValueError):
            e.map.collapse_clean(bad)

    def test_overlapping_gradient_is_chunk_independent(self):
        a, b = engine5(3), engine5(20)
        torch.testing.assert_close(a.gradient(a.zero), b.gradient(b.zero), atol=1e-6, rtol=1e-6)
        # Independently form one complete shared-date graph.
        d = a.zero.clone().requires_grad_(True)
        pred = a.predict(d, grad=True)
        ((a.y - pred).square().sum() / a.denominator).backward()
        torch.testing.assert_close(a.gradient(a.zero), d.grad, atol=1e-6, rtol=1e-6)

    def test_actual_dates_gaps_and_overlap_refused(self):
        e = engine5()
        d = e.data
        windows = d.calendar.unfold(0, d.window_length, 1).permute(0, 2, 1).clone()
        dates = d.calendar_dates[d.window_index]
        bad_dates = dates.copy()
        bad_dates[3] += np.timedelta64(1, "D")
        with self.assertRaises(ValueError):
            reconstruct_windows(windows, bad_dates, torch.zeros(len(windows), 0), d.observations, 4, False)
        windows[1, 0, 0] += 1
        with self.assertRaises(ValueError):
            reconstruct_windows(windows, dates, torch.zeros(len(windows), 0), d.observations, 4, False)

    def test_zero_start_first_update_equals_single_step(self):
        e = engine5()
        fgsm = e.project(e.map.budget * e.gradient(e.zero).sign(), "bound_only")
        first = e.project(2 * e.map.budget * e.gradient(e.zero).sign(), "bound_only")
        torch.testing.assert_close(fgsm, first)
        single = Combination("single", "original_s100", "single_step")
        zero = Combination("zero", "original_s100", "iterative", initialization="zero")
        _, a = e.attack(single, "01022500")
        _, b = e.attack(zero, "01022500", steps=3)
        self.assertAlmostEqual(a["selected_target_nse"], b["trajectory"][1]["current_nse"], places=6)

    def test_step_schedule_and_best_prediction_arrays(self):
        e = engine5()
        c = Combination("iterative", "original_s100", "iterative")
        arrays, info = e.attack(c, "01022500")
        self.assertEqual(len(info["trajectory"]), 51)
        step = lambda i: info["trajectory"][i]["step_size"][0]
        self.assertAlmostEqual(step(12), .2, places=6)
        self.assertAlmostEqual(step(13), .1, places=6)
        self.assertAlmostEqual(step(26), .1, places=6)
        self.assertAlmostEqual(step(27), .05, places=6)
        self.assertAlmostEqual(step(39), .025, places=6)
        d = torch.as_tensor(arrays["delta_signals"])
        p = e.predict(d).numpy() * e.q_scale + e.q_center
        np.testing.assert_allclose(p, arrays["q_attacked"])
        self.assertAlmostEqual(e.score(e.predict(d)), min(r["current_nse"] for r in info["trajectory"]), places=6)

    def test_100_candidates_with_clean_and_seven_day_blocks(self):
        e = engine5()
        samples = e.sample(123, "block_sign")
        for start in range(0, len(samples), 7):
            torch.testing.assert_close(samples[start:min(start+7, len(samples))], samples[start].expand(min(7, len(samples)-start), -1))
        c = Combination("block", "original_s100", "block_sign")
        arrays, info = e.attack(c, "01022500")
        self.assertEqual(len(info["candidates"]), 101)
        self.assertTrue(info["include_clean_candidate"])
        self.assertGreaterEqual(info["target_nse_loss"], 0)
        self.assertEqual(stable_seed("01022500", "block_sign", .1, 2), stable_seed("01022500", "block_sign", .1, 2))

    def test_peak_before_union_includes_other_peak_but_random_excludes(self):
        y = np.ones(100)
        y[30], y[44], y[75] = 10., 9., 11.
        peaks, calendar_peaks, pre, random, target, info = peak_locations(y, np.ones(100, bool), 103, 4)
        self.assertIn(30, peaks)
        self.assertIn(44, peaks)
        self.assertTrue(pre[33])  # Earlier peak calendar date is inside later peak's 14-day window.
        self.assertFalse(random[calendar_peaks].any())
        self.assertEqual(info["random_allowed_peak_count"], 0)
        self.assertGreaterEqual(int(random.sum()), int(pre.sum()))

    def test_undefined_peak_target_is_not_epsilon_denominator(self):
        y = np.ones(40)
        y[10], y[30] = 10, 10
        with self.assertRaises(UndefinedTarget):
            peak_locations(y, np.ones(40, bool), 43, 4)

    def test_physical_metrics_kge_not_normalized_and_undefined(self):
        observed = np.array([1., 2., 4., 8.])
        predicted = np.array([2., 3., 5., 9.])
        mask = np.ones(4, bool)
        m = physical_metrics(observed, predicted, mask)
        normalized = physical_metrics((observed-3)/2, (predicted-3)/2, mask)
        self.assertNotAlmostEqual(m["kge"]["value"], normalized["kge"]["value"])
        self.assertAlmostEqual(m["rmse"]["value"], 1.)
        self.assertIsNone(physical_metrics(observed, np.ones(4), mask)["kge"]["value"])
        with self.assertRaises(ValueError):
            physical_metrics(observed, [1, 2, float("nan"), 4], mask)

    def test_physical_projection_and_unknown_constraint(self):
        e = engine5()
        for level in ("physical_range", "whole_period_moment_adjustment"):
            d = e.project(e.zero + 99, level)
            check = e.check(d, level)
            self.assertEqual(check["amplitude_violations"], 0)
            self.assertEqual(check["physical_violations"], 0)
        with self.assertRaises(ValueError):
            e.project(e.zero, "typo")
        e.clean[:, 0] = -100
        with self.assertRaises(ValueError):
            e.project(e.zero, "physical_range")

    def test_nonfinite_model_output_fails(self):
        e = engine5()
        e.wrapper.weights[0] = float("nan")
        with self.assertRaises(ValueError):
            e.predict(e.zero)
        with self.assertRaises(ValueError):
            e.gradient(e.zero)

    def test_complete_record_identity_checksum_and_partial(self):
        e = engine5()
        c = Combination("test", "original_s100", "iterative")
        arrays, details = e.attack(c, "01022500", steps=2)
        identity = {"combination": c.metadata(), "input_identity": "test"}
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            (base / "data").mkdir()
            (base / "originals").mkdir()
            w = Workspace(base / "hydrol85935_revision_20261008_001", base / "data", Path(__file__).resolve().parents[2], base / "originals")
            self.assertIsNone(load_complete(w, "records/test", identity))
            save(w, "records/test", identity, arrays, details)
            loaded = load_complete(w, "records/test", identity)
            self.assertIsNotNone(loaded)
            with self.assertRaises(ValueError):
                load_complete(w, "records/test", {"wrong": "identity"})
            (w.root / "records/test/arrays.npz").write_bytes(b"corrupt")
            with self.assertRaises(ValueError):
                load_complete(w, "records/test", identity)

    def test_output_path_isolation_and_training_only_duplicate_removed(self):
        repo = Path(__file__).resolve().parents[2]
        with tempfile.TemporaryDirectory() as temp:
            data = repo / "data/camels_us"
            w = Workspace(Path(temp) / "hydrol85935_revision_20261008_001", data, repo)
            with self.assertRaises(ValueError):
                w.output("../outside")
            cfg, meta = training_config(w, 100, "cpu")
            self.assertEqual(cfg["dynamic_inputs"], list(FEATURES4))
            self.assertEqual(cfg["epochs"], 30)
            self.assertEqual(cfg["hidden_size"], 256)
            self.assertEqual(cfg["learning_rate"], {0: .001, 11: .0005, 21: .0001})
            self.assertTrue(meta["no_evaluation_based_selection"])
        with self.assertRaises(ValueError):
            Workspace(repo / "results/18_lstm_fair_531", data, repo)


if __name__ == "__main__":
    torch.set_num_threads(2)
    unittest.main()
