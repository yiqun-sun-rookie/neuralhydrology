import hashlib, runpy
from pathlib import Path
p=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/hybrid_v013_20261014_001/worker.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='877457ca47010ad0da8999ed156154a469808b1a8af89c99709ae82c97ec9783'
runpy.run_path(str(p),run_name='__main__')
