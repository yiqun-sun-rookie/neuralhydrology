import hashlib, runpy
from pathlib import Path
p=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/hybrid_v014_20261014_001/worker.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='493e5121ac5e44160ecf2f1a1605923e24e6aa1ca89121fb761924290d7de5ed'
runpy.run_path(str(p),run_name='__main__')
