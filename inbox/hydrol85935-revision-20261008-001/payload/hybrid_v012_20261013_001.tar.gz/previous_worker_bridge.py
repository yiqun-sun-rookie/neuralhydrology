import hashlib, runpy
from pathlib import Path
p=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/hybrid_v011_20261013_001/worker.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='7f531145d8fcbdcde3499a0f72badf4640aa252a3ae73cc898427578c1a67c72'
runpy.run_path(str(p),run_name='__main__')
