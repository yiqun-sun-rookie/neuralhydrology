import hashlib, runpy
from pathlib import Path
p=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/hybrid_v012_20261013_001/worker.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='b09f6d157f8ae90b4e285fe9469a89dc69258255082b53c26d799c2677309c0e'
runpy.run_path(str(p),run_name='__main__')
