"""Validate records at their genuine source, then report a disjoint verified union.

No inference, retraining, rewritten record identities, or scientific-code changes.
The packet is transport evidence, not a replacement for the source arrays.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import sys
import types
from contextlib import contextmanager


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def write_new(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf8') as f:
        json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.write('\n')


@contextmanager
def packet_rows(folder):
    """Small independent compressed files can be transported without huge blobs."""
    state = dict(stream=None, number=0, size=0)
    def emit(row):
        line = json.dumps(row, ensure_ascii=False, allow_nan=False) + '\n'
        size = len(line.encode('utf8'))
        if state['stream'] is None or state['size'] + size > 8 * 1024 * 1024:
            if state['stream'] is not None: state['stream'].close()
            state['number'] += 1
            state['stream'] = gzip.open(folder / ('rows_%04d.jsonl.gz' % state['number']), 'wt', encoding='utf8')
            state['size'] = 0
        state['stream'].write(line)
        state['size'] += size
    try:
        yield emit
    finally:
        if state['stream'] is not None: state['stream'].close()


def scopes(assignment, basins, combos):
    expected = {(c.id, b) for c in combos for b in basins}
    allocations = {}
    for row in assignment['local_assignments']:
        allocations[row['version']] = {(c, b) for c in row['combinations'] for b in row['basins']}
    allocations['hpc_v009'] = {(c, b) for t in assignment['hpc_tasks'] for c in t['combinations'] for b in t['basins']}
    seen = set()
    for name, slots in allocations.items():
        if seen & slots:
            raise ValueError('Overlapping assignments: ' + name)
        seen |= slots
    if seen != expected or len(expected) != 27612:
        raise ValueError('Assignment union differs from frozen full scope')
    return allocations


def shared_science(manifest):
    # Explicit location-only normalization; real manifests/fingerprints are retained.
    value = {k: v for k, v in manifest.items() if k not in ('runtime', 'data_identity')}
    data = manifest['data_identity']['manifest']
    if data is None or data['verified_files'] != 1069:
        raise ValueError('Full verified input manifest required')
    value['data_identity'] = {k: data[k] for k in ('sha256', 'verified_files')}
    return value


def endpoint(config, assignment_path, destination):
    cfg, assignment = read(config), read(assignment_path)
    sys.path.insert(0, cfg['code'])
    from src.adversarial.scripts.revision_20261008.contracts import Workspace, combinations
    from src.adversarial.scripts.revision_20261008.validation import SlotValidator, latest_ledger
    from src.adversarial.scripts.revision_20261008.assets import verify_training_assets
    w = Workspace(cfg['output'], cfg['inputs'], cfg['code'], cfg['original_models'], cfg['data_manifest'])
    v = SlotValidator(w)
    combos = {c.id: c for c in combinations()}
    planned = scopes(assignment, v.basins, list(combos.values()))[cfg['endpoint']]
    clean = {(combos[c].model_id, b) for c, b in planned}
    unexpected = sorted(v.present_attacks - planned) + sorted(v.present_clean - clean)
    if unexpected:
        raise ValueError('Unassigned completed slots at endpoint: ' + str(unexpected[:10]))
    latest = latest_ledger(w, v.fingerprint)
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=False)
    manifest_path = destination / 'manifest.json'
    write_new(manifest_path, v.manifest)
    counts = Counter()
    failure_rows = []
    training = []
    if cfg['endpoint'] == 'hpc_v009':
        for seed in assignment['hpc_training_seeds']:
            try:
                _, identity = verify_training_assets(w, seed)
                training.append(identity)
            except Exception as e:
                failure_rows.append(dict(kind='training', seed=seed, status='missing_or_failed', reason=str(e)))
    def provenance(folder):
        return {n: sha(folder / n) for n in ('complete.json', 'metadata.json', 'arrays.npz')}
    with packet_rows(destination) as emit:
        for model, basin in sorted(clean):
            try:
                _, meta = v.clean(model, basin)
                emit(dict(kind='clean', key=[model, basin], status='complete', metadata=meta,
                          hashes=provenance(w.output(f'records/clean/{model}/{basin}'))))
                counts['clean'] += 1
            except Exception as e:
                emit(dict(kind='clean', key=[model, basin], status='missing_or_failed', reason=str(e)))
        for cid, basin in sorted(planned):
            try:
                record = v.attack(combos[cid], basin)
                if record is None:
                    old = latest.get((cid, basin), {})
                    status = old.get('status', 'not_executed')
                    status = status if status in ('failed', 'uncomputable') else 'not_executed'
                    emit(dict(kind='attack', key=[cid, basin], status=status, reason=old.get('reason', '')))
                    counts[status] += 1
                    continue
                arrays, meta = record
                restores = int(arrays['q_signal_restored'].shape[0]) if 'importance' in meta['details'] else 0
                emit(dict(kind='attack', key=[cid, basin], status='complete', metadata=meta, restores=restores,
                          hashes=provenance(w.output(f'records/attacks/{cid}/{basin}'))))
                counts['complete'] += 1
                counts['restores'] += restores
            except Exception as e:
                emit(dict(kind='attack', key=[cid, basin], status='failed', reason=str(e)))
                counts['failed'] += 1
    # Preserve the whole ledger, including superseded failed attempts.
    ledger = w.output('records/ledger.jsonl')
    with gzip.open(destination / 'ledger_history.jsonl.gz', 'wb') as out:
        if ledger.exists():
            with ledger.open('rb') as inp:
                for block in iter(lambda: inp.read(1024 * 1024), b''):
                    out.write(block)
    index = dict(schema=1, endpoint=cfg['endpoint'], source_root=str(w.root), code_root=str(w.repo),
                 created_utc=datetime.now(timezone.utc).isoformat(), assignment_sha256=sha(assignment_path),
                 manifest_sha256=v.fingerprint, shared_science_sha256=digest(shared_science(v.manifest)),
                 basins=v.basins, counts=dict(counts), training=training, failures=failure_rows,
                 exporter_sha256=sha(__file__), scientific_inference=False,
                 files={p.name: sha(p) for p in destination.iterdir()})
    write_new(destination / 'index.json', index)
    print(json.dumps(dict(destination=str(destination), endpoint=cfg['endpoint'], counts=dict(counts))))
    return index


def load_packet(folder, assignment_sha, exporter_sha):
    folder = Path(folder)
    index = read(folder / 'index.json')
    if index['assignment_sha256'] != assignment_sha or index['exporter_sha256'] != exporter_sha:
        raise ValueError('Packet assignment/exporter identity changed')
    for name, expected in index['files'].items():
        if Path(name).name != name or sha(folder / name) != expected:
            raise ValueError('Packet content changed: ' + name)
    manifest = read(folder / 'manifest.json')
    if digest(manifest) != index['manifest_sha256'] or digest(shared_science(manifest)) != index['shared_science_sha256']:
        raise ValueError('Packet frozen identity mismatch')
    return index, manifest


def merge(code, assignment_path, packets, destination):
    sys.path.insert(0, str(code))
    from src.adversarial.scripts.revision_20261008.contracts import combinations
    from src.adversarial.scripts.revision_20261008 import reporting
    combos = {c.id: c for c in combinations()}
    basins = (Path(code) / 'src/xaj_global_pilot/configs/conceptual_benchmark_camels_us_531_repro.txt').read_text().split()
    assignments = scopes(read(assignment_path), basins, list(combos.values()))
    rows, clean, indices, training, failures = {}, {}, {}, {}, []
    canonical = None
    for folder in packets:
        idx, manifest = load_packet(folder, sha(assignment_path), sha(__file__))
        name = idx['endpoint']
        if name in indices or name not in assignments or idx['basins'] != basins:
            raise ValueError('Duplicate/unknown endpoint or different ordered basin list')
        if canonical is not None and shared_science(manifest) != canonical:
            raise ValueError('Endpoint scientific rules/input/model/source mismatch')
        canonical = shared_science(manifest)
        indices[name] = idx
        allowed_clean = {(combos[c].model_id, b) for c, b in assignments[name]}
        received = {'attack': set(), 'clean': set()}
        for part in sorted(n for n in idx['files'] if n.startswith('rows_')):
          with gzip.open(Path(folder) / part, 'rt', encoding='utf8') as inp:
            for line in inp:
                row = json.loads(line)
                kind, key = row['kind'], tuple(row['key'])
                allowed = assignments[name] if kind == 'attack' else allowed_clean
                target = rows if kind == 'attack' else clean
                if kind not in received or key not in allowed or key in target:
                    raise ValueError('Duplicated or unassigned packet slot')
                if row['status'] == 'complete' and row['metadata']['identity']['manifest_sha256'] != idx['manifest_sha256']:
                    raise ValueError('Record fingerprint not bound to real endpoint')
                target[key] = dict(row, endpoint=name)
                received[kind].add(key)
        if received['attack'] != assignments[name] or received['clean'] != allowed_clean:
            raise ValueError('Packet omitted planned statuses')
        for item in idx['training']:
            if name != 'hpc_v009' or item['seed'] in training or item['manifest_sha256'] != idx['manifest_sha256']:
                raise ValueError('Training ownership or frozen identity mismatch')
            training[item['seed']] = item
        failures.extend(idx['failures'])
    counts, validated = [], {}
    for c in combos.values():
        count = dict(combination_id=c.id, model_id=c.model_id, planned=len(basins), complete=0, failed=0, uncomputable=0, not_executed=0)
        for b in basins:
            row = rows.get((c.id, b), dict(status='not_executed', reason='endpoint packet unavailable'))
            count[row['status']] += 1
            if row['status'] == 'complete':
                ref = clean.get((c.model_id, b))
                if ref is None or ref['status'] != 'complete' or row['metadata']['identity']['clean_record_id'] != ref['metadata']['record_id'] or ref['endpoint'] != row['endpoint']:
                    raise ValueError('Cross-packet clean reference mismatch')
                validated[c.id, b] = row['metadata']
            else:
                failures.append(dict(kind='attack', combination_id=c.id, basin_id=b, status=row['status'], reason=row.get('reason', '')))
        counts.append(count)
    models = set(c.model_id for c in combos.values())
    for m in sorted(models):
        for b in basins:
            row = clean.get((m, b), dict(status='missing_or_failed', reason='endpoint packet unavailable'))
            if row['status'] != 'complete':
                failures.append(dict(kind='clean', model_id=m, basin_id=b, status=row['status'], reason=row.get('reason', '')))
    totals = {s: sum(r[s] for r in counts) for s in ('complete', 'failed', 'uncomputable', 'not_executed')}
    auxiliary = dict(planned_trainings=3, complete_trainings=len(training), missing_or_failed_trainings=3-len(training),
                     planned_clean_records=3186, complete_clean_records=sum(r['status']=='complete' for r in clean.values()),
                     planned_restore_series=12744, complete_restore_series=sum(r.get('restores', 0) for r in rows.values()))
    auxiliary['missing_or_failed_clean_records'] = 3186-auxiliary['complete_clean_records']
    complete = (set(indices) == set(assignments) and totals['complete']+totals['uncomputable']==27612 and
                auxiliary['complete_trainings']==3 and auxiliary['complete_clean_records']==3186 and auxiliary['complete_restore_series']==12744)
    summary = dict(scope='genuine endpoint union; primary full 531 basins', planned_combinations=52, planned_attack_slots=27612,
                   complete_attack_records=totals['complete'], **{k:v for k,v in totals.items() if k!='complete'}, auxiliary=auxiliary,
                   unexpected_slots=[], task_complete=complete, status=('COMPLETE_WITH_UNCOMPUTABLE' if totals['uncomputable'] else 'PASS') if complete else 'INCOMPLETE',
                   manifest_sha256=None, source_manifests={k:v['manifest_sha256'] for k,v in indices.items()},
                   missing_endpoint_packets=sorted(set(assignments)-set(indices)), scientific_conclusions_validated=False)
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=False)
    class ReportWorkspace:
        def __init__(self, root, chosen): self.root, self.chosen = root, chosen
        def output(self, relative): return self.root / relative
        def basins(self): return self.chosen, None
    # Reuse the frozen statistics function with an explicit verified-union input.
    def render(root, chosen, selected, result_summary):
        env = dict(reporting.report.__globals__)
        scoped_counts = counts
        scoped_failures = failures
        if len(chosen) != 531:
            scoped_counts = []
            for c in combos.values():
                statuses = Counter(rows.get((c.id,b),dict(status='not_executed'))['status'] for b in chosen)
                scoped_counts.append(dict(combination_id=c.id, model_id=c.model_id, planned=len(chosen),
                                          **{s:statuses[s] for s in ('complete','failed','uncomputable','not_executed')}))
            scoped_failures = [f for f in failures if f.get('basin_id') in chosen]
        env['audit_all'] = lambda w, collect=False: (result_summary, scoped_counts, scoped_failures, selected)
        types.FunctionType(reporting.report.__code__, env)(ReportWorkspace(root, chosen))
    render(destination, basins, validated, summary)
    write_new(destination/'source_index.json', dict(assignment_sha256=sha(assignment_path), endpoints=indices,
              record_sources=[dict(key=list(k), endpoint=r['endpoint'], **r.get('hashes', {})) for k,r in rows.items() if r['status']=='complete']))
    # Descriptive diagnostics; never replace the 531-basin primary denominator.
    for name, chosen in [('common_hpc_481', basins[50:]), ('local_cpu_25', basins[:25]), ('local_gpu_25', basins[25:50])]:
        selected = {k:v for k,v in validated.items() if k[1] in chosen}
        detail = dict(summary, scope='descriptive sensitivity only: '+name, task_complete=False, status='DIAGNOSTIC_ONLY', planned_basins=len(chosen))
        render(destination/'sensitivity'/name, chosen, selected, detail)
    print(json.dumps(summary))
    return summary


def main():
    p=argparse.ArgumentParser();p.add_argument('mode', choices=['export','merge']);p.add_argument('--assignment',required=True)
    p.add_argument('--config');p.add_argument('--code');p.add_argument('--packet',action='append',default=[]);p.add_argument('--destination',required=True)
    a=p.parse_args()
    if a.mode=='export': endpoint(a.config,a.assignment,a.destination)
    else: merge(a.code,a.assignment,a.packet,a.destination)


if __name__=='__main__': main()
