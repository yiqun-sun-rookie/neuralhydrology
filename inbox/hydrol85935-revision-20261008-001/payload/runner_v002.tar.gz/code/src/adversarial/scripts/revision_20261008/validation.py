"""No-inference slot validation against current frozen assets and clean references."""
from __future__ import annotations

from collections import OrderedDict
import json

import numpy as np

from .assets import expected_model_identity, frozen_manifest, verify_training_assets
from .contracts import combinations, SEEDS, sha256, digest_json
from .records import load_complete


class SlotValidator:
    def __init__(self, workspace):
        self.workspace = workspace
        self.manifest, self.fingerprint = frozen_manifest(workspace)
        # This comparison is independent of record labels and also guards direct report() calls.
        current = workspace.manifest()
        for key, value in current.items():
            if self.manifest.get(key) != value:
                raise ValueError(f"Current source/contracts/basins/original assets differ from frozen manifest: {key}")
        self.basins = workspace.basins()[0]
        self.combinations = {c.id: c for c in combinations()}
        self.models = {}
        self.clean_cache, self.shared_cache = OrderedDict(), OrderedDict()
        self.present_clean = {(p.parent.parent.name, p.parent.name) for p in workspace.output("records/clean").glob("*/*/complete.json")}
        self.present_attacks = {(p.parent.parent.name, p.parent.name) for p in workspace.output("records/attacks").glob("*/*/complete.json")}

    def model(self, model_id):
        if model_id not in self.models:
            self.models[model_id] = expected_model_identity(self.workspace, model_id)
        return self.models[model_id]

    def shared(self, basin):
        if basin in self.shared_cache:
            return self.shared_cache[basin]
        root = self.workspace.output(f"shared_observations/{basin}")
        marker = json.loads((root / "complete.json").read_text(encoding="utf-8"))
        actual_hash = sha256(root / "arrays.npz")
        if marker["arrays_sha256"] != actual_hash or marker["manifest_sha256"] != self.fingerprint or marker["source"] != "original_s100" or marker["source_model_identity"] != self.model("original_s100"):
            raise ValueError("Shared observation archive/current model/manifest provenance mismatch")
        with np.load(root / "arrays.npz", allow_pickle=False) as archive:
            arrays = {key: archive[key] for key in archive.files}
        value = actual_hash, arrays
        self.shared_cache[basin] = value
        if len(self.shared_cache) > 64:
            self.shared_cache.popitem(last=False)
        return value

    def check_base_identity(self, identity, model, basin):
        expected = dict(manifest_sha256=self.fingerprint, model=self.model(model), basin_id=basin,
                        data_dir=str(self.workspace.data_dir))
        for key, value in expected.items():
            if identity.get(key) != value:
                raise ValueError(f"Record slot/current frozen identity mismatch: {key}")
        shared_hash, _ = self.shared(basin)
        if identity.get("shared_observation_sha256") != shared_hash:
            raise ValueError("Record common observation digest mismatch")
        if not isinstance(identity.get("input_identity"), str) or len(identity["input_identity"]) != 64:
            raise ValueError("Missing complete input identity")
        if identity.get("chunk") != 256 or identity.get("device") not in ("cpu", "cuda:0"):
            raise ValueError("Record execution chunk/device differs from fixed contract")

    def clean(self, model, basin):
        key = model, basin
        if key in self.clean_cache:
            return self.clean_cache[key]
        if key not in self.present_clean:
            raise ValueError("Required clean reference is missing or incomplete")
        loaded = load_complete(self.workspace, f"records/clean/{model}/{basin}")
        if loaded is None:
            raise ValueError("Required clean reference is missing or incomplete")
        arrays, metadata = loaded
        identity = metadata["identity"]
        self.check_base_identity(identity, model, basin)
        if metadata["kind"] != "clean" or identity.get("target") != "clean" or "combination" in identity:
            raise ValueError("Wrong kind or target in clean slot")
        expected_dates = np.arange(np.datetime64("1989-10-01"), np.datetime64("1999-10-01")).astype(str)
        if metadata["details"].get("window_length") != 270 or not np.array_equal(arrays["prediction_dates"], expected_dates):
            raise ValueError("Clean slot does not cover the complete frozen 270-day evaluation contract")
        _, shared = self.shared(basin)
        for field in ("prediction_dates", "calendar_dates", "scoring_mask"):
            if not np.array_equal(arrays[field], shared[field]):
                raise ValueError("Clean dates/mask differ from common observations")
        if not np.allclose(arrays["q_observed"], shared["q_observed"], atol=1e-5, rtol=1e-5, equal_nan=True):
            raise ValueError("Clean observations differ from common physical observations")
        self.clean_cache[key] = loaded
        if len(self.clean_cache) > 64:
            self.clean_cache.popitem(last=False)
        return loaded

    def attack(self, combination, basin):
        if basin not in self.basins or combination.id not in self.combinations or combination.metadata() != self.combinations[combination.id].metadata():
            raise ValueError("Unknown planned basin/combination slot")
        if (combination.id, basin) not in self.present_attacks:
            return None
        loaded = load_complete(self.workspace, f"records/attacks/{combination.id}/{basin}")
        if loaded is None:
            return None
        arrays, metadata = loaded
        identity = metadata["identity"]
        self.check_base_identity(identity, combination.model_id, basin)
        if metadata["kind"] != "attack" or identity.get("combination") != combination.metadata():
            raise ValueError("Complete record placed in a wrong combination slot")
        clean_arrays, clean_metadata = self.clean(combination.model_id, basin)
        base = {k: v for k, v in clean_metadata["identity"].items() if k != "target"}
        expected = dict(**base, combination=combination.metadata(), clean_record_id=clean_metadata["record_id"])
        if identity != expected:
            raise ValueError("Attack identity does not match current clean reference/input/execution identity")
        for field in ("calendar_dates", "prediction_dates", "scoring_mask", "q_observed", "q_clean", "q_observed_normalized", "q_clean_normalized"):
            equal = np.array_equal(arrays[field], clean_arrays[field], equal_nan=True) if arrays[field].dtype.kind in "fc" else np.array_equal(arrays[field], clean_arrays[field])
            if not equal:
                raise ValueError(f"Selected record differs from its clean reference: {field}")
        return loaded


def latest_ledger(workspace, fingerprint):
    path = workspace.output("records/ledger.jsonl")
    latest = {}
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            row = json.loads(line)
            if row.get("manifest_sha256") == fingerprint:
                latest[(row.get("combination_id"), row.get("basin_id"))] = row
    return latest


def audit_all(workspace, collect=False):
    validator = SlotValidator(workspace)
    latest = latest_ledger(workspace, validator.fingerprint)
    counts, failures, records = [], [], {}
    models = list(dict.fromkeys(c.model_id for c in combinations()))
    auxiliary = dict(planned_trainings=3, complete_trainings=0, missing_or_failed_trainings=0,
                     planned_clean_records=3186, complete_clean_records=0, missing_or_failed_clean_records=0,
                     planned_restore_series=12744, complete_restore_series=0)
    for seed in SEEDS:
        try:
            verify_training_assets(workspace, seed)
            auxiliary["complete_trainings"] += 1
        except Exception as error:
            auxiliary["missing_or_failed_trainings"] += 1
            failures.append(dict(kind="training", seed=seed, status="missing_or_failed", reason=str(error)))
    for model in models:
        for basin in validator.basins:
            try:
                validator.clean(model, basin)
                auxiliary["complete_clean_records"] += 1
            except Exception as error:
                auxiliary["missing_or_failed_clean_records"] += 1
                # Full coverage remains explicit without allocating a large repeated traceback.
                failures.append(dict(kind="clean", model_id=model, basin_id=basin, status="missing_or_failed", reason=str(error)))
    for c in combinations():
        row = dict(combination_id=c.id, model_id=c.model_id, planned=531, complete=0, failed=0, uncomputable=0, not_executed=0)
        for basin in validator.basins:
            try:
                loaded = validator.attack(c, basin)
            except Exception as error:
                loaded = None
                status, reason = "failed", str(error)
            else:
                if loaded is None:
                    entry = latest.get((c.id, basin), {})
                    status = entry.get("status", "not_executed")
                    status = status if status in ("failed", "uncomputable") else "not_executed"
                    reason = entry.get("reason", "")
                else:
                    status, reason = "complete", ""
            row[status] += 1
            if status != "complete":
                failures.append(dict(kind="attack", combination_id=c.id, basin_id=basin, status=status, reason=reason))
            else:
                arrays, metadata = loaded
                if "importance" in metadata["details"]:
                    auxiliary["complete_restore_series"] += int(arrays["q_signal_restored"].shape[0])
                if collect:
                    records[(c.id, basin)] = metadata
        counts.append(row)
    unexpected = []
    for marker in workspace.output("records/attacks").glob("*/*/complete.json"):
        combination, basin = marker.parent.parent.name, marker.parent.name
        if combination not in validator.combinations or basin not in validator.basins:
            unexpected.append(str(marker.parent.relative_to(workspace.root)))
    for model, basin in validator.present_clean:
        if model not in models or basin not in validator.basins:
            unexpected.append(f"records/clean/{model}/{basin}")
    attack_counts = {status: sum(row[status] for row in counts) for status in ("complete", "failed", "uncomputable", "not_executed")}
    auxiliary_complete = (auxiliary["complete_trainings"] == 3 and auxiliary["complete_clean_records"] == 3186 and auxiliary["complete_restore_series"] == 12744)
    accounted = attack_counts["complete"] + attack_counts["uncomputable"] == 27612
    task_complete = accounted and auxiliary_complete and not unexpected and not attack_counts["failed"]
    summary = dict(scope="full task: 52*531 attack slots, 3 trainings, 6*531 clean sequences, 6*531*4 restore sequences",
                   planned_combinations=52, planned_attack_slots=27612, complete_attack_records=attack_counts["complete"],
                   failed=attack_counts["failed"], uncomputable=attack_counts["uncomputable"], not_executed=attack_counts["not_executed"],
                   auxiliary=auxiliary, unexpected_slots=unexpected, task_complete=task_complete,
                   status=("COMPLETE_WITH_UNCOMPUTABLE" if task_complete and attack_counts["uncomputable"] else "PASS" if task_complete else "INCOMPLETE"),
                   manifest_sha256=validator.fingerprint)
    return summary, counts, failures, records
