"""Pre-registered original assets and append-only completed-training provenance."""
from __future__ import annotations

import json
from pathlib import Path

import yaml

from .contracts import ORIGINAL_NAMES, SEEDS, FEATURES4, digest_json, sha256

ASSET_FILES = {"config": "config.yml", "weight": "model_epoch030.pt", "scaler": "train_data/train_data_scaler.yml"}


def frozen_manifest(workspace):
    manifest = json.loads(workspace.output("frozen/manifest.json").read_text(encoding="utf-8"))
    return manifest, digest_json(manifest)


def capture_original_assets(workspace):
    result = {}
    for seed in SEEDS:
        directory = workspace.original_models_root / ORIGINAL_NAMES[seed]
        files = dict(ASSET_FILES)
        files["baseline"] = "baseline_epoch030.npz" if (directory / "baseline_epoch030.npz").exists() else "test/model_epoch030/test_results.p"
        result[f"original_s{seed}"] = dict(directory=ORIGINAL_NAMES[seed],
                                          files={name: dict(relative_path=relative, sha256=sha256(directory / relative)) for name, relative in files.items()})
    return result


def verify_original_assets(workspace, model_id):
    manifest, _ = frozen_manifest(workspace)
    expected = manifest["original_assets"][model_id]
    directory = workspace.original_models_root / expected["directory"]
    if expected["directory"] != ORIGINAL_NAMES[int(model_id.rsplit("_s", 1)[1])]:
        raise ValueError("Original asset directory differs from pre-registration")
    for name, item in expected["files"].items():
        relative = Path(item["relative_path"])
        if relative.is_absolute() or not (directory / relative).resolve().is_relative_to(directory.resolve()):
            raise ValueError("Original asset path escapes its directory")
        if sha256(directory / relative) != item["sha256"]:
            raise ValueError(f"Pre-registered original {model_id}/{name} changed before model load")
    return directory, expected


def training_index_path(workspace, seed):
    return workspace.output(f"frozen/training_assets/s{seed}.json")


def verify_training_assets(workspace, seed):
    manifest, fingerprint = frozen_manifest(workspace)
    expected = json.loads(training_index_path(workspace, seed).read_text(encoding="utf-8"))
    marker = json.loads(workspace.output(f"training/s{seed}/complete.json").read_text(encoding="utf-8"))
    if marker != expected or expected["manifest_sha256"] != fingerprint or expected["seed"] != seed or expected["epoch"] != 30 or expected["status"] != "complete":
        raise ValueError("Training completion marker/index/current manifest provenance mismatch")
    if expected["source_config_sha256"] != manifest["original_assets"][f"original_s{seed}"]["files"]["config"]["sha256"]:
        raise ValueError("Training originated from a different original configuration")
    run = workspace.output(expected["run_relative_path"])
    for name, relative in ASSET_FILES.items():
        if sha256(run / relative) != expected["assets"][name]["sha256"] or expected["assets"][name]["relative_path"] != relative:
            raise ValueError(f"Registered training {name} asset changed")
    cfg_file = workspace.output(f"training/s{seed}/training_config.yml")
    metadata_file = workspace.output(f"training/s{seed}/training_metadata.json")
    if sha256(cfg_file) != expected["prepared_config_file_sha256"] or sha256(metadata_file) != expected["training_metadata_sha256"]:
        raise ValueError("Training prepared configuration/metadata provenance changed")
    cfg = yaml.safe_load(cfg_file.read_text(encoding="utf-8"))
    metadata = json.loads(metadata_file.read_text(encoding="utf-8"))
    if (digest_json(cfg) != expected["config_sha256"] or metadata["config_sha256"] != expected["config_sha256"] or metadata["manifest_sha256"] != fingerprint
            or metadata["source_config_sha256"] != expected["source_config_sha256"] or metadata["seed"] != seed or metadata["epoch"] != 30
            or not metadata["no_evaluation_based_selection"]):
        raise ValueError("Training source configuration digest/manifest mismatch")
    verify_actual_training_config(cfg, yaml.safe_load((run / "config.yml").read_text(encoding="utf-8")), seed, run)
    return run, expected


def verify_actual_training_config(prepared, actual, seed, run):
    derived = {"run_dir", "train_dir", "img_log_dir", "commit_hash", "package_version"}
    if {k: v for k, v in prepared.items() if k not in derived} != {k: v for k, v in actual.items() if k not in derived}:
        raise ValueError("Actual trained scientific settings differ from prepared configuration")
    if actual["seed"] != seed or actual["epochs"] != 30 or actual["dynamic_inputs"] != list(FEATURES4):
        raise ValueError("Actual trained seed/epoch/features mismatch")
    if Path(actual["run_dir"]).resolve() != run.resolve() or Path(actual["train_dir"]).resolve() != (run / "train_data").resolve():
        raise ValueError("Actual trained execution paths mismatch")


def register_training_assets(workspace, seed, run, metadata):
    from .records import json_write
    _, fingerprint = frozen_manifest(workspace)
    index = training_index_path(workspace, seed)
    if index.exists() and workspace.output(f"training/s{seed}/complete.json").exists():
        registered_run, registered = verify_training_assets(workspace, seed)
        expected_metadata = json.loads(workspace.output(f"training/s{seed}/training_metadata.json").read_text(encoding="utf-8"))
        if registered_run != run or metadata != expected_metadata:
            raise ValueError("Refusing to rewrite an existing immutable training asset index")
        return registered
    prepared_file = workspace.output(f"training/s{seed}/training_config.yml")
    if metadata != json.loads(workspace.output(f"training/s{seed}/training_metadata.json").read_text(encoding="utf-8")):
        raise ValueError("Training metadata differs from its immutable prepared provenance")
    prepared = yaml.safe_load(prepared_file.read_text(encoding="utf-8"))
    actual = yaml.safe_load((run / "config.yml").read_text(encoding="utf-8"))
    verify_actual_training_config(prepared, actual, seed, run)
    if metadata["manifest_sha256"] != fingerprint:
        raise ValueError("Training completion uses a different frozen manifest")
    entry = dict(status="complete", run_relative_path=str(run.relative_to(workspace.root)), seed=seed, epoch=30,
                 manifest_sha256=fingerprint, source_config_sha256=metadata["source_config_sha256"],
                 config_sha256=metadata["config_sha256"], prepared_config_file_sha256=sha256(prepared_file),
                 training_metadata_sha256=sha256(workspace.output(f"training/s{seed}/training_metadata.json")),
                 assets={name: dict(relative_path=relative, sha256=sha256(run / relative)) for name, relative in ASSET_FILES.items()})
    if index.exists():
        if json.loads(index.read_text(encoding="utf-8")) != entry:
            raise ValueError("Refusing to rewrite an existing immutable training asset index")
    else:
        json_write(index, entry)
    complete = workspace.output(f"training/s{seed}/complete.json")
    if complete.exists() and json.loads(complete.read_text(encoding="utf-8")) != entry:
        raise ValueError("Refusing to replace a completed training marker")
    if not complete.exists():
        json_write(complete, entry)
    verify_training_assets(workspace, seed)
    return entry


def expected_model_identity(workspace, model_id):
    if model_id.startswith("original_"):
        run, index = verify_original_assets(workspace, model_id)
        asset_files = index["files"]
    else:
        seed = int(model_id.rsplit("_s", 1)[1])
        run, index = verify_training_assets(workspace, seed)
        asset_files = index["assets"]
    cfg = yaml.safe_load((run / "config.yml").read_text(encoding="utf-8"))
    return dict(model_id=model_id, config_sha256=asset_files["config"]["sha256"], weight_sha256=asset_files["weight"]["sha256"],
                scaler_sha256=asset_files["scaler"]["sha256"], epoch=30, dynamic_feature_names=cfg["dynamic_inputs"],
                static_feature_names=cfg.get("static_attributes", []), asset_index_sha256=digest_json(index))
