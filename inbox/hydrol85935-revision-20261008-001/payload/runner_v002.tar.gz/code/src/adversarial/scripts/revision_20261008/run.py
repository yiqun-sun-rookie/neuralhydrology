#!/usr/bin/env python
"""Explicit, isolated CLI for plan/preflight/train/main/validate/report."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import platform
import sys
import time
import traceback

# A deployment is a standalone repo-shaped code tree; prioritize its frozen NH package.
REPO = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(REPO))
if __package__ in (None, ""):
    __package__ = "src.adversarial.scripts.revision_20261008"

import numpy as np
import torch

from .contracts import Workspace, SCIENCE, CONTRACT_DIR, CONTRACT_FILES, combinations, digest_json, SEEDS
from .data import load_model, load_basin, scaler_fields, reference_std, baseline_check, reconstruct_windows
from .engine import BasinEngine, SignalMap, UndefinedTarget, physical_metrics, denormalize
from .records import json_write, save, load_complete, append_ledger
from .training import prepare_training, train


def runtime():
    import neuralhydrology
    return dict(python=platform.python_version(), torch=torch.__version__, numpy=np.__version__,
                platform=platform.platform(), cuda_runtime=torch.version.cuda,
                cuda_device=torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
                scipy=__import__("scipy").__version__, cudnn_version=torch.backends.cudnn.version(),
                neuralhydrology_source=str(Path(neuralhydrology.__file__).resolve()),
                cuda_visible_devices=os.environ.get("CUDA_VISIBLE_DEVICES"), cuda_device_count=torch.cuda.device_count(),
                cudnn_enabled=torch.backends.cudnn.enabled, cudnn_allow_tf32=torch.backends.cudnn.allow_tf32,
                cudnn_benchmark=torch.backends.cudnn.benchmark, cudnn_deterministic=torch.backends.cudnn.deterministic,
                matmul_allow_tf32=torch.backends.cuda.matmul.allow_tf32)


def freeze(workspace):
    manifest = workspace.manifest()
    # Scheduler allocation IDs can vary between jobs without changing scientific arithmetic.
    manifest["runtime"] = {k: v for k, v in runtime().items() if k != "cuda_visible_devices"}
    fingerprint = digest_json(manifest)
    path = workspace.output("frozen/manifest.json")
    if path.exists():
        if json.loads(path.read_text(encoding="utf-8")) != manifest:
            raise ValueError("Frozen manifest mismatch; do not mix code/contracts/environment in this root")
    else:
        for name in CONTRACT_FILES:
            output = workspace.output("frozen/" + name)
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_bytes((workspace.repo / CONTRACT_DIR / name).read_bytes())
        json_write(path, manifest)
    return fingerprint


def make_engine(workspace, model_id, basin_id, device, chunk, reference):
    wrapper, model_identity = load_model(workspace, model_id, device)
    data = load_basin(workspace, wrapper, basin_id, device)
    center, scale, q_center, q_scale = scaler_fields(wrapper)
    mapping = SignalMap(wrapper.dynamic_features, center, scale, reference, .1, device)
    engine = BasinEngine(wrapper, data, mapping, q_center, q_scale, chunk)
    baseline = baseline_check(workspace, wrapper, basin_id, data, engine.clean_pred, q_center, q_scale) if model_id.startswith("original_") else None
    return engine, model_identity, baseline


def shared_observations(workspace, basin_id, engine, model_id):
    """Freeze original-seed100 physical observations and dates once, independent of model predictions."""
    from .contracts import sha256
    from .assets import expected_model_identity, frozen_manifest
    directory = workspace.output(f"shared_observations/{basin_id}")
    archive, marker = directory / "arrays.npz", directory / "complete.json"
    if marker.exists():
        info = json.loads(marker.read_text())
        if info["arrays_sha256"] != sha256(archive):
            raise ValueError("Shared observation archive checksum mismatch")
        if info["manifest_sha256"] != frozen_manifest(workspace)[1] or info["source_model_identity"] != expected_model_identity(workspace, "original_s100") or info["source"] != "original_s100":
            raise ValueError("Shared observation archive source/manifest identity mismatch before reuse")
        with np.load(archive, allow_pickle=False) as f:
            shared = {k: f[k] for k in f.files}
    else:
        if model_id == "original_s100":
            data, scale, center = engine.data, engine.q_scale, engine.q_center
        else:
            reference_model, _ = load_model(workspace, "original_s100", "cpu")
            data = load_basin(workspace, reference_model, basin_id, "cpu")
            _, _, center, scale = scaler_fields(reference_model)
        shared = dict(q_observed=denormalize(data.observations, center, scale),
                      q_normalized_original=data.observations.cpu().numpy(),
                      prediction_dates=data.prediction_dates.astype(str), calendar_dates=data.calendar_dates.astype(str),
                      scoring_mask=data.scoring_mask.cpu().numpy())
        directory.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(directory / "arrays.partial.npz", **shared)
        os.replace(directory / "arrays.partial.npz", archive)
        json_write(marker, dict(arrays_sha256=sha256(archive), source="original_s100", input_identity=data.input_identity,
                                manifest_sha256=frozen_manifest(workspace)[1],
                                source_model_identity=expected_model_identity(workspace, "original_s100")))
    d = engine.data
    if not np.array_equal(shared["prediction_dates"], d.prediction_dates.astype(str)) or not np.array_equal(shared["calendar_dates"], d.calendar_dates.astype(str)) or not np.array_equal(shared["scoring_mask"], d.scoring_mask.cpu().numpy()):
        raise ValueError("Shared event dates or fixed masks differ across models")
    own_q = denormalize(d.observations, engine.q_center, engine.q_scale)
    if not np.allclose(shared["q_observed"], own_q, atol=1e-5, rtol=1e-5, equal_nan=True):
        raise ValueError("Shared physical observations differ across models")
    engine.common_observations = shared["q_observed"]
    engine.common_peak_observations = shared["q_normalized_original"]
    return sha256(archive)


def failure(workspace, basin, combination, error, manifest_hash):
    row = dict(basin_id=basin, combination_id=combination, status="uncomputable" if isinstance(error, UndefinedTarget) else "failed",
               reason=f"{type(error).__name__}: {error}", manifest_sha256=manifest_hash, timestamp_utc=__import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat())
    append_ledger(workspace, row)
    return row


def plan(workspace, args, manifest_hash):
    rows = [dict(**c.metadata(), planned_basins=531, planned_records=531, status="not_executed") for c in combinations()]
    json_write(workspace.output("control/execution_plan.json"), dict(combinations=rows, combination_count=52,
               planned_attack_slots=27612, planned_clean_records=3186, planned_restore_series=12744,
               training_seeds=list(SEEDS), planned_trainings=3, manifest_sha256=manifest_hash))
    for seed in SEEDS:
        prepare_training(workspace, seed, args.device, manifest_hash)
    return dict(status="prepared", combinations=52, attack_slots=27612, training_configs=3, experiments_executed=0)


def preflight(workspace, args, manifest_hash):
    started = time.perf_counter()
    basins, _ = workspace.basins()
    basin = basins[args.basin_start]
    model = args.model_id or "original_s100"
    if torch.cuda.is_available() and args.device.startswith("cuda"):
        torch.cuda.reset_peak_memory_stats(args.device)
    timings = {}
    reference = reference_std(workspace)
    t = time.perf_counter()
    engine, identity, baseline = make_engine(workspace, model, basin, args.device, args.chunk, reference)
    timings["full_baseline_seconds"] = time.perf_counter() - t
    d = engine.data
    n = min(args.preflight_windows, len(d.observations))
    if n < 2:
        raise ValueError("preflight-windows must be at least 2")
    calendar = d.calendar[:n + d.window_length - 1]
    windows = calendar.unfold(0, d.window_length, 1).permute(0, 2, 1)
    tiny = reconstruct_windows(windows, d.calendar_dates[d.window_index[:n]],
                               d.static.unsqueeze(0).expand(n, -1), d.observations[:n], 270, enforce_period=False)
    tiny.snow_fraction = d.snow_fraction
    smoke = BasinEngine(engine.wrapper, tiny, engine.map, engine.q_center, engine.q_scale, args.chunk)
    gradient_prediction = smoke.predict(smoke.zero.detach().requires_grad_(True), grad=True).detach()
    gradient = smoke.gradient(smoke.zero)
    if not torch.isfinite(gradient).all() or not torch.count_nonzero(gradient):
        raise ValueError("Missing, nonfinite or all-zero attack gradient")
    gradient_path = dict(max_prediction_difference_mm_day=float((gradient_prediction - smoke.clean_pred).abs().max()) * smoke.q_scale,
                         gradient_path_nse=smoke.score(gradient_prediction), inference_path_nse=smoke.clean_nse,
                         absolute_nse_difference=abs(smoke.score(gradient_prediction) - smoke.clean_nse),
                         nonzero_gradient_entries=int(torch.count_nonzero(gradient)), finite_gradient=True,
                         rule="record numerical path differences; require finite nonzero gradient; no unregistered allclose gate")
    # The smoke is deliberately two updates and tiny dates, never an experiment record.
    c = next(c for c in combinations() if c.model_id == model and c.method == "iterative" and c.condition == "bound_only" and c.target == "whole_period")
    t = time.perf_counter()
    arrays, details = smoke.attack(c, basin, steps=2)
    timings["tiny_two_update_attack_seconds"] = time.perf_counter() - t
    try:
        import psutil
        rss = psutil.Process().memory_info().rss
    except ImportError:
        import resource
        rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
    info = dict(status="PASS", scope="one basin interface smoke; not full scientific experiment",
                model_id=model, basin_id=basin, full_prediction_count=len(d.prediction_dates), full_calendar_count=len(d.calendar_dates),
                tiny_prediction_count=n, tiny_updates=2, baseline=baseline, model_identity=identity,
                actual_prediction_start=str(d.prediction_dates[0]), actual_prediction_end=str(d.prediction_dates[-1]),
                actual_calendar_start=str(d.calendar_dates[0]), date_validation="PASS", gradient_path_check=gradient_path,
                constraints=details["constraints"], mapping=details["mapping"], runtime=runtime(), timings=timings,
                wall_seconds=time.perf_counter() - started, rss_bytes=rss,
                cuda_peak_allocated_bytes=torch.cuda.max_memory_allocated(args.device) if args.device.startswith("cuda") else 0,
                cuda_peak_reserved_bytes=torch.cuda.max_memory_reserved(args.device) if args.device.startswith("cuda") else 0,
                chunk=args.chunk, manifest_sha256=manifest_hash)
    if args.training_smoke:
        from .training import training_smoke
        info["single_batch_training_smoke"] = training_smoke(workspace, 100, basin, args.device)
    info["wall_seconds"] = time.perf_counter() - started
    json_write(workspace.output(f"preflight/{model}_{basin}/report.json"), info)
    directory = workspace.output(f"preflight/{model}_{basin}")
    np.savez_compressed(directory / "tiny_arrays.npz", **arrays)
    return info


def main_experiments(workspace, args, manifest_hash):
    basins, _ = workspace.basins()
    selected = basins[args.basin_start:args.basin_start + (args.basin_count or len(basins))]
    selected_combinations = [c for c in combinations() if (args.model_id is None or c.model_id == args.model_id) and
                             (not args.combination_id or c.id in args.combination_id)]
    if args.combination_id and set(args.combination_id) - {c.id for c in selected_combinations}:
        raise ValueError("Requested combinations missing or incompatible with selected model")
    if not selected or not selected_combinations:
        raise ValueError("Empty basin/combination selection")
    reference = reference_std(workspace)
    summary = dict(complete=0, reused=0, failed=0, uncomputable=0, expected=len(selected) * len(selected_combinations))
    for model in dict.fromkeys(c.model_id for c in selected_combinations):
        model_combinations = [c for c in selected_combinations if c.model_id == model]
        try:
            wrapper, model_identity = load_model(workspace, model, args.device)
            center, scale, q_center, q_scale = scaler_fields(wrapper)
        except Exception as error:
            for basin in selected:
                for c in model_combinations:
                    summary[failure(workspace, basin, c.id, error, manifest_hash)["status"]] += 1
            continue
        for basin in selected:
            try:
                data = load_basin(workspace, wrapper, basin, args.device)
                identity_base = dict(manifest_sha256=manifest_hash, model=model_identity, basin_id=basin,
                                     input_identity=data.input_identity, chunk=args.chunk, device=args.device,
                                     data_dir=str(workspace.data_dir))
                mapping = SignalMap(wrapper.dynamic_features, center, scale, reference, .1, args.device)
                engine = BasinEngine(wrapper, data, mapping, q_center, q_scale, args.chunk)
                identity_base["shared_observation_sha256"] = shared_observations(workspace, basin, engine, model)
                baseline = baseline_check(workspace, wrapper, basin, data, engine.clean_pred, q_center, q_scale) if model.startswith("original_") else None
                clean_path = f"records/clean/{model}/{basin}"
                clean_identity = dict(**identity_base, target="clean")
                prior = load_complete(workspace, clean_path, clean_identity)
                if prior is None:
                    clean_id = save(workspace, clean_path, clean_identity,
                                    dict(calendar_dates=data.calendar_dates.astype(str), prediction_dates=data.prediction_dates.astype(str),
                                         scoring_mask=data.scoring_mask.cpu().numpy(), q_observed=denormalize(data.observations, q_center, q_scale),
                                         q_clean=denormalize(engine.clean_pred, q_center, q_scale),
                                         q_observed_normalized=data.observations.cpu().numpy(),
                                         q_clean_normalized=engine.clean_pred.cpu().numpy()),
                                    dict(window_length=270, baseline=baseline, mapping=mapping.metadata(), snow_fraction=data.snow_fraction,
                                         q_center=q_center, q_scale=q_scale), kind="clean")
                else:
                    clean_id = prior[1]["record_id"]
            except Exception as error:
                for c in model_combinations:
                    summary[failure(workspace, basin, c.id, error, manifest_hash)["status"]] += 1
                continue
            for c in model_combinations:
                relative = f"records/attacks/{c.id}/{basin}"
                identity = dict(**identity_base, combination=c.metadata(), clean_record_id=clean_id)
                try:
                    prior = load_complete(workspace, relative, identity)
                    if prior is not None:
                        summary["reused"] += 1
                        append_ledger(workspace, dict(basin_id=basin, combination_id=c.id, record_id=prior[1]["record_id"], status="reused", manifest_sha256=manifest_hash))
                        continue
                    engine.map = SignalMap(wrapper.dynamic_features, center, scale, reference, c.epsilon, args.device)
                    arrays, details = engine.attack(c, basin)
                    details["baseline"] = baseline
                    details["execution_runtime"] = runtime()
                    if c.method == "iterative" and c.condition == "bound_only" and c.epsilon == .1 and c.target == "whole_period" and c.initialization == "random":
                        restored, importance = engine.restore(torch.as_tensor(arrays["delta_signals"], device=args.device))
                        arrays["q_signal_restored"] = restored
                        details["importance"] = importance
                    record_id = save(workspace, relative, identity, arrays, details)
                    append_ledger(workspace, dict(basin_id=basin, combination_id=c.id, record_id=record_id, status="complete", manifest_sha256=manifest_hash))
                    summary["complete"] += 1
                except Exception as error:
                    summary[failure(workspace, basin, c.id, error, manifest_hash)["status"]] += 1
    json_write(workspace.output(f"control/chunk_{args.model_id or 'all'}_{args.basin_start}_{len(selected)}.json"), summary)
    return summary


def validate_all(workspace):
    from .validation import audit_all
    info, counts, failures, _ = audit_all(workspace)
    json_write(workspace.output("control/validation_slots.json"), dict(combinations=counts, failures=failures))
    json_write(workspace.output("control/validation.json"), info)
    return info


def get_args(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", required=True)
    p.add_argument("--data-dir", required=True)
    p.add_argument("--mode", required=True, choices=("plan", "preflight", "train", "main", "validate", "report"))
    p.add_argument("--original-models-root")
    p.add_argument("--data-manifest", help="SHA-256 file with paths relative to data-dir; every file is verified before freeze/load")
    p.add_argument("--device", default="cpu")
    p.add_argument("--seed", type=int, choices=SEEDS)
    p.add_argument("--model-id", choices=tuple(dict.fromkeys(c.model_id for c in combinations())))
    p.add_argument("--combination-id", action="append")
    p.add_argument("--basin-start", type=int, default=0)
    p.add_argument("--basin-count", type=int)
    p.add_argument("--chunk", type=int, default=256)
    p.add_argument("--preflight-windows", type=int, default=8)
    p.add_argument("--training-smoke", action="store_true", help="preflight only: one fresh four-feature training batch, no saved weights")
    args = p.parse_args(argv)
    if args.basin_start < 0 or args.basin_start >= 531 or (args.basin_count is not None and args.basin_count <= 0) or args.chunk <= 0:
        p.error("Invalid basin slice/chunk")
    if args.device != "cpu" and args.device != "cuda:0":
        p.error("Only cpu or cuda:0 is allowed; maximum one GPU")
    if args.mode == "main" and args.chunk != 256:
        p.error("Formal main execution requires the fixed original evaluation batch/chunk 256")
    return args


def cli(argv=None):
    args = get_args(argv)
    workspace, fingerprint = None, None
    torch.set_num_threads(4)
    try:
        if args.device.startswith("cuda") and torch.cuda.device_count() != 1:
            raise ValueError("Exactly one visible CUDA device is required")
        workspace = Workspace(args.root, args.data_dir, REPO, args.original_models_root, args.data_manifest)
        fingerprint = freeze(workspace)
        if args.mode == "plan":
            result = plan(workspace, args, fingerprint)
        elif args.mode == "preflight":
            result = preflight(workspace, args, fingerprint)
        elif args.mode == "train":
            result = {f"s{seed}": train(workspace, seed, args.device, fingerprint) for seed in ([args.seed] if args.seed else SEEDS)}
        elif args.mode == "main":
            result = main_experiments(workspace, args, fingerprint)
        elif args.mode == "report":
            from .reporting import report
            result = report(workspace)
        else:
            result = validate_all(workspace)
        print(json.dumps(result, ensure_ascii=False, allow_nan=False))
        return result_exit_code(args.mode, result)
    except Exception as error:
        if workspace is not None:
            failure(workspace, None, f"mode:{args.mode}", error, fingerprint)
            json_write(workspace.output(f"control/{args.mode}_failure.json"), dict(status="FAIL", reason=str(error), traceback=traceback.format_exc()))
        print(f"FAIL: {type(error).__name__}: {error}", file=sys.stderr)
        return 1


def result_exit_code(mode, result):
    if mode in ("validate", "report"):
        return 0 if result.get("task_complete") else 1
    return 1 if result.get("failed", 0) or result.get("uncomputable", 0) or result.get("failures", []) or result.get("status") == "FAIL" else 0


if __name__ == "__main__":
    raise SystemExit(cli())
