"""Isolated HYDROL85935 supplement; never writes historical artifacts."""
