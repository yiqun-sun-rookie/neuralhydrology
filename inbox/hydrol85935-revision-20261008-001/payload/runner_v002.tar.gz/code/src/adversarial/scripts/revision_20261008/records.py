"""Atomic complete records; exact identity and checksum validation before reuse."""
from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np

from .contracts import digest_json, sha256
from .engine import physical_metrics, metric_changes


def json_write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".partial")
    with temp.open("w", encoding="utf-8", newline="\n") as f:
        json.dump(value, f, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(temp, path)


def append_ledger(workspace, value):
    path = workspace.output("records/ledger.jsonl")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False) + "\n")
        f.flush()
        os.fsync(f.fileno())


def save(workspace, relative, identity, arrays, details, kind="attack"):
    directory = workspace.output(relative)
    directory.mkdir(parents=True, exist_ok=True)
    for value in arrays.values():
        if np.asarray(value).dtype.hasobject:
            raise ValueError("Object arrays are forbidden")
    record_id = digest_json(identity)
    old = directory / "complete.json"
    if old.exists():
        raise ValueError("Refusing to overwrite a complete record; validate it for reuse")
    temp = directory / "arrays.partial.npz"
    np.savez_compressed(temp, **arrays)
    os.replace(temp, directory / "arrays.npz")
    metadata = dict(record_id=record_id, identity=identity, kind=kind, details=details,
                    arrays_sha256=sha256(directory / "arrays.npz"))
    json_write(directory / "metadata.json", metadata)
    marker = dict(record_id=record_id, metadata_sha256=sha256(directory / "metadata.json"),
                  arrays_sha256=metadata["arrays_sha256"], status="complete", kind=kind)
    # Validate partial contents before publishing the completion marker.
    validate_contents(metadata, arrays)
    json_write(old, marker)
    return record_id


def load_complete(workspace, relative, identity=None):
    directory = workspace.output(relative)
    if not (directory / "complete.json").exists():
        return None
    marker = json.loads((directory / "complete.json").read_text(encoding="utf-8"))
    if marker["status"] != "complete" or marker["metadata_sha256"] != sha256(directory / "metadata.json") or marker["arrays_sha256"] != sha256(directory / "arrays.npz"):
        raise ValueError("Complete record checksum mismatch")
    metadata = json.loads((directory / "metadata.json").read_text(encoding="utf-8"))
    if digest_json(metadata["identity"]) != marker["record_id"] or metadata["record_id"] != marker["record_id"]:
        raise ValueError("Complete record identity checksum mismatch")
    if identity is not None and metadata["identity"] != identity:
        raise ValueError("Existing record has different full identity; never reuse")
    with np.load(directory / "arrays.npz", allow_pickle=False) as archive:
        arrays = {k: archive[k] for k in archive.files}
    validate_contents(metadata, arrays)
    return arrays, metadata


def validate_contents(metadata, a):
    mandatory = {"calendar_dates", "prediction_dates", "scoring_mask", "q_observed", "q_clean", "q_observed_normalized", "q_clean_normalized"}
    if metadata["kind"] == "attack":
        mandatory |= {"delta_signals", "delta_features", "q_attacked", "initial_delta_signals", "target_mask", "location_mask",
                      "clean_calendar_features", "window_start_calendar_index", "q_attacked_normalized"}
    if not mandatory.issubset(a):
        raise ValueError(f"Incomplete arrays: {sorted(mandatory - set(a))}")
    calendar = a["calendar_dates"].astype("datetime64[D]")
    prediction = a["prediction_dates"].astype("datetime64[D]")
    if np.isnat(calendar).any() or np.isnat(prediction).any() or not np.all(np.diff(calendar) == np.timedelta64(1, "D")):
        raise ValueError("Invalid stored calendar dates")
    n = len(prediction)
    length = metadata["details"].get("window_length", 270)
    if not np.array_equal(calendar[length - 1:], prediction):
        raise ValueError("Prediction/calendar dates disagree")
    for key in ("q_observed", "q_clean", "scoring_mask"):
        if a[key].shape != (n,):
            raise ValueError(f"Incomplete or wrong shape: {key}")
    if not np.isfinite(a["q_clean"]).all() or not np.isfinite(a["q_observed"][a["scoring_mask"]]).all():
        raise ValueError("Nonfinite clean prediction/fixed observations")
    details = metadata["details"]
    for name in ("q_observed", "q_clean", "q_attacked"):
        if name in a:
            normalized = a[name + "_normalized"]
            if normalized.shape != (n,) or a[name].dtype != np.float64:
                raise ValueError("Physical records require pre-conversion float64 and complete normalized targets")
            physical = normalized.astype(np.float64) * details["q_scale"] + details["q_center"]
            if not np.array_equal(a[name], physical, equal_nan=True):
                raise ValueError("Physical array differs from double-precision normalized conversion")
    if metadata["kind"] != "attack":
        return
    d, details = a["delta_signals"], metadata["details"]
    mapping = details["mapping"]
    if d.shape != (len(calendar), 4) or a["initial_delta_signals"].shape != d.shape or not np.isfinite(d).all():
        raise ValueError("Incomplete perturbation array")
    if not np.array_equal(a["window_start_calendar_index"], np.arange(n)):
        raise ValueError("Stored window index cannot reconstruct actual dates")
    expanded = np.zeros_like(a["delta_features"])
    from .contracts import SIGNALS
    for i, signal in enumerate(SIGNALS):
        for column in mapping["signal_to_feature_columns"][signal]:
            expanded[:, column] = d[:, i]
    if not np.array_equal(expanded, a["delta_features"]):
        raise ValueError("Stored independent-signal and expanded feature arrays disagree")
    b = np.asarray(mapping["signal_budget_normalized"])
    if (np.abs(d) > b + 1e-6).any() or np.any(d[~a["location_mask"]] != 0):
        raise ValueError("Stored perturbation exceeds amplitude/location")
    condition = metadata["identity"]["combination"]["condition"]
    columns = [mapping["signal_to_feature_columns"][signal][0] for signal in SIGNALS]
    clean_signals = a["clean_calendar_features"][:, columns]
    physical = (clean_signals + d) * np.asarray(mapping["signal_scale_physical"]) + np.asarray(mapping["signal_center_physical"])
    tolerance = 1e-6 * np.asarray(mapping["signal_scale_physical"])
    if condition != "bound_only" and ((physical < np.array([0, -50, 0, 0]) - tolerance) | (physical > np.array([500, 50, 1361, 10000]) + tolerance)).any():
        raise ValueError("Stored final input violates physical constraint")
    if not np.isfinite(a["q_attacked"]).all() or a["q_attacked"].shape != (n,):
        raise ValueError("Invalid stored selected prediction")
    clean_metrics = physical_metrics(a["q_observed"], a["q_clean"], a["scoring_mask"], a["high_flow_mask"])
    adv_metrics = physical_metrics(a["q_observed"], a["q_attacked"], a["scoring_mask"], a["high_flow_mask"])
    expected = metric_changes(clean_metrics, adv_metrics)
    for metric, values in expected.items():
        stored = details["metrics"][metric]
        for key in ("clean", "attacked", "change"):
            if (stored[key] is None) != (values[key] is None) or (values[key] is not None and not np.isclose(stored[key], values[key], rtol=1e-6, atol=1e-6)):
                raise ValueError(f"Stored {metric}/{key} does not match selected arrays")
        for key in ("status", "reason", "clean_status", "attacked_status", "clean_reason", "attacked_reason"):
            if stored.get(key) != values[key]:
                raise ValueError(f"Stored {metric}/{key} state does not match its two metric sides")
    target = a["target_mask"]
    obs = a["q_observed_normalized"][target].astype(float)
    pred = a["q_attacked_normalized"][target].astype(float)
    target_nse = 1 - np.sum((obs - pred) ** 2) / np.sum((obs - obs.mean()) ** 2)
    if not np.isclose(target_nse, details["selected_target_nse"], rtol=1e-5, atol=1e-5):
        raise ValueError("Selected target score does not match stored prediction")
    candidates = details["candidates"]
    trajectory = details["trajectory"]
    scores = [r["nse"] for r in candidates] if candidates else [r["current_nse"] for r in trajectory]
    if details["include_clean_candidate"]:
        scores.append(details["clean_target_nse"])
    if not np.isclose(min(scores), details["selected_target_nse"], rtol=1e-7, atol=1e-7):
        raise ValueError("Stored selected score is not the permitted candidate minimum")
    combination = metadata["identity"]["combination"]
    if combination["target"] == "observed_peaks":
        if "peak_day_metrics" not in details:
            raise ValueError("Required selected peak-day auxiliary metrics missing")
        peak_expected = metric_changes(physical_metrics(a["q_observed"], a["q_clean"], target), physical_metrics(a["q_observed"], a["q_attacked"], target))
        stored = details["peak_day_metrics"]["rmse"]
        for key in ("clean", "attacked", "change"):
            if not np.isclose(stored[key], peak_expected["rmse"][key], rtol=1e-6, atol=1e-6):
                raise ValueError("Peak-day RMSE does not match selected prediction/mask")
    requires_restore = (combination["method"] == "iterative" and combination["condition"] == "bound_only" and combination["epsilon"] == .1
                        and combination["target"] == "whole_period" and combination["initialization"] == "random")
    if requires_restore and "importance" not in details:
        raise ValueError("Required four-signal restoration metadata missing for main iterative slot")
    if "importance" in details:
        restored = a.get("q_signal_restored")
        if restored is None or restored.shape != (4, n) or not np.isfinite(restored).all():
            raise ValueError("Missing or invalid four-signal restore predictions")
        full_nse = expected["nse"]["attacked"]
        for index, signal in enumerate(SIGNALS):
            restored_nse = physical_metrics(a["q_observed"], restored[index], a["scoring_mask"])["nse"]["value"]
            if not np.isclose(restored_nse - full_nse, details["importance"]["raw_importance"][signal], rtol=1e-5, atol=1e-5):
                raise ValueError("Restored prediction and raw importance disagree")
