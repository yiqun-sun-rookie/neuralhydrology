"""Reconstruct scientific tables from validated selected arrays, including failures."""
from __future__ import annotations

import csv
import json

import numpy as np
from scipy.stats import pearsonr, spearmanr

from .contracts import combinations
from .records import json_write
from .validation import audit_all


def csv_write(workspace, relative, rows):
    path = workspace.output(relative)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v for k, v in row.items()})


def finite_median(values):
    values = [x for x in values if x is not None and np.isfinite(x)]
    return float(np.median(values)) if values else None


def correlation(x, y, control=None):
    x, y = np.asarray(x), np.asarray(y)
    if len(x) < 3 or np.ptp(x) == 0 or np.ptp(y) == 0:
        return dict(count=len(x), value=None, reason="insufficient_data_or_constant_variable")
    if control is None:
        r = spearmanr(x, y).statistic
        method = "Spearman rank correlation"
    else:
        design = np.column_stack((np.ones(len(x)), np.asarray(control)))
        x = x - design @ np.linalg.lstsq(design, x, rcond=None)[0]
        y = y - design @ np.linalg.lstsq(design, y, rcond=None)[0]
        if np.ptp(x) <= 1e-12 or np.ptp(y) <= 1e-12:
            return dict(count=len(x), value=None, reason="zero_residual_variance")
        r = pearsonr(x, y).statistic
        method = "Pearson correlation of linear residuals controlling clean NSE"
    return dict(count=len(x), value=float(r) if np.isfinite(r) else None, method=method,
                reason="" if np.isfinite(r) else "undefined_correlation")


def report(workspace):
    basins, _ = workspace.basins()
    summary, counts, failures, validated = audit_all(workspace, collect=True)
    metrics, importance, events, peak_metrics = [], [], [], []
    records = {key: metadata["details"] for key, metadata in validated.items()}
    for c in combinations():
        for basin in basins:
            metadata = validated.get((c.id, basin))
            if metadata is None:
                continue
            d = metadata["details"]
            for name, values in d["metrics"].items():
                metrics.append(dict(combination_id=c.id, model_id=c.model_id, basin_id=basin, metric=name,
                                    record_id=metadata["record_id"], **values))
            for event in d["flood_amplitude_events"]:
                events.append(dict(combination_id=c.id, model_id=c.model_id, basin_id=basin,
                                   record_id=metadata["record_id"], **event))
            if "importance" in d:
                for signal, raw in d["importance"]["raw_importance"].items():
                    importance.append(dict(model_id=c.model_id, basin_id=basin, signal=signal, raw=raw,
                                           normalized=(d["importance"]["normalized_importance"] or {}).get(signal),
                                           denominator=d["importance"]["normalization_denominator"], record_id=metadata["record_id"]))
            if "peak_day_metrics" in d:
                peak_metrics.append(dict(combination_id=c.id, model_id=c.model_id, basin_id=basin, metric="peak_day_rmse_mm_day",
                                         record_id=metadata["record_id"], **d["peak_day_metrics"]["rmse"]))
    snow_rows, ratio_rows, peak_rows, diagnostic_rows, comparison_rows, correlation_rows = [], [], [], [], [], []
    models = list(dict.fromkeys(c.model_id for c in combinations()))
    for model in models:
        bound_id = f"{model}_iterative_eps0p1_bound_only"
        group_rows = {condition: [] for condition in ("bound_only", "physical_range", "whole_period_moment_adjustment")}
        for condition in group_rows:
            cid = f"{model}_iterative_eps0p1_{condition}"
            available = [(b, records[(cid, b)]) for b in basins if (cid, b) in records]
            for group in ("snow_affected", "low_snow"):
                values = [d["metrics"]["nse"]["change"] for b, d in available if d["snow_group"] == group]
                group_rows[condition].append(dict(model_id=model, condition=condition, group=group, successful_basins=len(values),
                                                  median_nse_loss=finite_median(values)))
            high, low = group_rows[condition]
            high["snow_minus_low_median_loss"] = (high["median_nse_loss"] - low["median_nse_loss"] if high["median_nse_loss"] is not None and low["median_nse_loss"] is not None else None)
            snow_rows.extend(group_rows[condition])
            if condition != "bound_only":
                for basin, d in available:
                    bound = records.get((bound_id, basin))
                    if bound is None:
                        continue
                    numerator, denominator = d["metrics"]["nse"]["change"], bound["metrics"]["nse"]["change"]
                    ratio_rows.append(dict(model_id=model, basin_id=basin, condition=condition, numerator=numerator, denominator=denominator,
                                           remaining_loss_ratio=numerator / denominator if denominator != 0 else None,
                                           reason="" if denominator != 0 else "zero_bound_loss"))
            if available:
                x = [d["snow_fraction"] for b, d in available]
                y = [d["metrics"]["nse"]["change"] for b, d in available]
                clean = [d["metrics"]["nse"]["clean"] for b, d in available]
                correlation_rows.append(dict(model_id=model, condition=condition, variable="snow_fraction_vs_loss", **correlation(x, y)))
                correlation_rows.append(dict(model_id=model, condition=condition, variable="snow_fraction_vs_loss_controlled", **correlation(x, y, clean)))
        for basin in basins:
            pre = records.get((f"{model}_peak14_pre_peak_eps0p1", basin))
            random = records.get((f"{model}_peak14_random_non_peak_eps0p1", basin))
            if pre and random:
                peak_rows.append(dict(model_id=model, basin_id=basin, pre_peak_loss=pre["target_nse_loss"], random_location_loss=random["target_nse_loss"],
                                      paired_difference=pre["target_nse_loss"] - random["target_nse_loss"],
                                      allowed_pre_peak_dates=pre["peak_location"]["allowed_peak_dates"],
                                      modified_pre_peak_dates=pre["peak_location"]["actually_modified_peak_dates"],
                                      pre_days=pre["peak_location"]["allowed_days"], random_days=random["peak_location"]["allowed_days"],
                                      overlap_days=pre["peak_location"]["overlap_days"]))
            bound = records.get((bound_id, basin))
            if bound and "importance" in bound:
                temp = bound["importance"]["raw_importance"]["temperature_mean"]
                values = bound["importance"]["raw_importance"]
                comparison_rows.append(dict(model_id=model, basin_id=basin, comparison="temperature_importance_rank",
                                            value=1 + sum(v > temp for v in values.values()), normalized_denominator=bound["importance"]["normalization_denominator"]))
        available_importance = [records[(bound_id, b)] for b in basins if (bound_id, b) in records and "importance" in records[(bound_id, b)]]
        if available_importance:
            correlation_rows.append(dict(model_id=model, condition="bound_only", variable="snow_fraction_vs_raw_temperature_importance",
                                         **correlation([d["snow_fraction"] for d in available_importance],
                                                       [d["importance"]["raw_importance"]["temperature_mean"] for d in available_importance])))
        usable = [d for d in available_importance if d["importance"]["normalized_importance"] is not None]
        correlation_rows.append(dict(model_id=model, condition="bound_only", variable="snow_fraction_vs_normalized_temperature_importance",
                                     planned_basins=531, available_restore_records=len(available_importance),
                                     usable_normalized_records=len(usable), uncomputable_normalized_records=len(available_importance) - len(usable),
                                     unavailable_restore_records=531 - len(available_importance),
                                     **correlation([d["snow_fraction"] for d in usable],
                                                   [d["importance"]["normalized_importance"]["temperature_mean"] for d in usable])))
        # Every method remains a paired basin comparison within one trained model.
        for method in ("gaussian", "random_sign", "block_sign", "single_step"):
            cid = f"{model}_{method}_eps0p1_bound_only"
            for basin in basins:
                b, other = records.get((bound_id, basin)), records.get((cid, basin))
                if b and other:
                    comparison_rows.append(dict(model_id=model, basin_id=basin, comparison=f"iterative_minus_{method}_nse_loss",
                                                value=b["metrics"]["nse"]["change"] - other["metrics"]["nse"]["change"]))
    for seed in (100, 200, 300):
        for condition in ("bound_only", "physical_range", "whole_period_moment_adjustment"):
            old, new = f"original_s{seed}_iterative_eps0p1_{condition}", f"single_temperature_s{seed}_iterative_eps0p1_{condition}"
            for basin in basins:
                a, b = records.get((old, basin)), records.get((new, basin))
                if a and b:
                    comparison_rows.append(dict(model_id=f"seed{seed}", basin_id=basin, comparison=f"single_temperature_minus_original_loss_{condition}",
                                                value=b["metrics"]["nse"]["change"] - a["metrics"]["nse"]["change"]))
    for epsilon, random_id, zero_id, single_id in (
            (.1, "original_s100_iterative_eps0p1_bound_only", "original_s100_diagnostic_iterative_zero_0p1", "original_s100_single_step_eps0p1_bound_only"),
            (.2, "original_s100_diagnostic_iterative_random_trace_0p2", "original_s100_diagnostic_iterative_zero_0p2", "original_s100_diagnostic_single_step_reference_0p2")):
        for basin in basins:
            r, z, s = records.get((random_id, basin)), records.get((zero_id, basin)), records.get((single_id, basin))
            if r and z and s:
                diagnostic_rows.append(dict(basin_id=basin, epsilon=epsilon,
                                             random_best_minus_last_damage=r["trajectory"][-1]["current_nse"] - r["selected_target_nse"],
                                             zero_subsequent_gain=z["trajectory"][1]["current_nse"] - z["selected_target_nse"],
                                             random_minus_zero_best_damage=z["selected_target_nse"] - r["selected_target_nse"],
                                             zero_first_vs_single_score_difference=z["trajectory"][1]["current_nse"] - s["selected_target_nse"],
                                             random_best_update=r["selected_iteration"], zero_best_update=z["selected_iteration"]))
    event_pairs, event_denominators = paired_flood_events(records, basins, models)
    for name, rows in (("completeness", counts), ("metrics", metrics), ("failures", failures), ("importance", importance),
                       ("flood_events", events), ("snow_group_summary", snow_rows), ("remaining_loss_ratios", ratio_rows),
                       ("peak_location_pairs", peak_rows), ("iteration_diagnostics", diagnostic_rows), ("paired_comparisons", comparison_rows),
                       ("snow_correlations", correlation_rows), ("peak_day_metrics", peak_metrics),
                       ("paired_flood_events", event_pairs), ("paired_flood_event_denominators", event_denominators)):
        csv_write(workspace, f"analysis/{name}.csv", rows)
    result = dict(**summary, paired_peak_records=len(peak_rows), paired_diagnostic_records=len(diagnostic_rows),
                  all_required_attacks_complete=all(r["complete"] == 531 for r in counts),
                  interpretation="negative changes retained; paired basin differences are not causal decompositions; no historical claims replaced")
    json_write(workspace.output("analysis/summary.json"), result)
    return result


def paired_flood_events(records, basins, models):
    """Same observed-event dates, main bound-only selected iterative records; exclusions stay explicit."""
    from itertools import combinations as pairs
    rows, denominators = [], []
    for model_a, model_b in pairs(models, 2):
        cid_a, cid_b = f"{model_a}_iterative_eps0p1_bound_only", f"{model_b}_iterative_eps0p1_bound_only"
        count = dict(model_a=model_a, model_b=model_b, condition="bound_only", planned_basins=len(basins),
                     basins_with_both_records=0, observed_events_union=0, eligible_paired_events=0,
                     excluded_or_missing_model_a=0, excluded_or_missing_model_b=0)
        for basin in basins:
            a, b = records.get((cid_a, basin)), records.get((cid_b, basin))
            if a is None or b is None:
                continue
            count["basins_with_both_records"] += 1
            events_a = {e["date"]: e for e in a["flood_amplitude_events"]}
            events_b = {e["date"]: e for e in b["flood_amplitude_events"]}
            for date in sorted(set(events_a) | set(events_b)):
                event_a, event_b = events_a.get(date), events_b.get(date)
                reason_a = event_a["exclusion_reason"] if event_a else "event_missing_from_model_record"
                reason_b = event_b["exclusion_reason"] if event_b else "event_missing_from_model_record"
                eligible = not reason_a and not reason_b
                count["observed_events_union"] += 1
                count["eligible_paired_events"] += int(eligible)
                count["excluded_or_missing_model_a"] += int(bool(reason_a))
                count["excluded_or_missing_model_b"] += int(bool(reason_b))
                change_a = event_a["amplitude_change_fraction"] if event_a else None
                change_b = event_b["amplitude_change_fraction"] if event_b else None
                rows.append(dict(model_a=model_a, model_b=model_b, basin_id=basin, event_date=date, eligible_pair=eligible,
                                 amplitude_change_fraction_a=change_a, amplitude_change_fraction_b=change_b,
                                 paired_difference_b_minus_a=change_b - change_a if eligible else None,
                                 exclusion_reason_a=reason_a, exclusion_reason_b=reason_b))
        count["unavailable_paired_basins"] = len(basins) - count["basins_with_both_records"]
        denominators.append(count)
    return rows, denominators
