"""Frozen science, experiment enumeration and output isolation."""
from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from pathlib import Path

IDENTITY = "hydrol85935_revision_20261008_001"
SEEDS = (100, 200, 300)
ORIGINAL_NAMES = {
    100: "lstm_cudalstm_maurer_s100_2026_0616_1513_ep30",
    200: "lstm_cudalstm_maurer_s200_2026_0616_1831_ep30",
    300: "lstm_cudalstm_maurer_s300_2026_0616_2016_ep30",
}
CONTRACT_DIR = Path("draft/papers/05_adversarial_latex/revision_HYDROL85935_20261006/parallel_tasks_20261008/experiment_preparation")
CONTRACT_FILES = ("implementation_spec.md", "supplemented_experiment_plan.md", "proposed_execution_matrix.csv")
FEATURES5 = ("PRCP(mm/day)", "Tmin(C)", "Tmax(C)", "SRAD(W/m2)", "Vp(Pa)")
FEATURES4 = tuple(f for f in FEATURES5 if f != "Tmax(C)")
SIGNALS = ("precipitation", "temperature_mean", "shortwave_radiation", "vapor_pressure")
CONDITIONS = ("bound_only", "physical_range", "whole_period_moment_adjustment")
SCIENCE = dict(epoch=30, n_basins=531, seq_length=270, train_start="1999-10-01", train_end="2008-09-30",
               test_start="1989-10-01", test_end="1999-09-30", steps=50, candidates=100, block_days=7,
               base_seed=0, location_seed=9973, temperature_range=[-50., 50.], amplitude_tolerance=1e-6,
               baseline_nse_tolerance=1e-5, moment_std_correction=1, mean_zero_tolerance=1e-12,
               halve_after_updates=[12, 26, 38], scope="new supplemental validation, not exact historical replay")


def digest_json(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def stable_seed(basin, method, epsilon, candidate):
    return int(digest_json([0, str(basin), method, float(epsilon), candidate])[:15], 16)


@dataclass(frozen=True)
class Combination:
    id: str
    model_id: str
    method: str
    condition: str = "bound_only"
    epsilon: float = .1
    initialization: str = "random"
    target: str = "whole_period"
    location: str = "whole_calendar"
    window_days: int = 0

    def metadata(self):
        return asdict(self)


def combinations():
    result = []
    for representation in ("original", "single_temperature"):
        for seed in SEEDS:
            model = f"{representation}_s{seed}"
            for method in ("gaussian", "random_sign", "block_sign", "single_step", "iterative"):
                result.append(Combination(f"{model}_{method}_eps0p1_bound_only", model, method))
            for condition in CONDITIONS[1:]:
                result.append(Combination(f"{model}_iterative_eps0p1_{condition}", model, "iterative", condition))
            if representation == "single_temperature":
                for location in ("pre_peak", "random_non_peak"):
                    result.append(Combination(f"{model}_peak14_{location}_eps0p1", model, "iterative",
                                              target="observed_peaks", location=location, window_days=14))
    for epsilon, initialization, method, suffix in (
            (.1, "zero", "iterative", "iterative_zero_0p1"),
            (.2, "random", "iterative", "iterative_random_trace_0p2"),
            (.2, "zero", "iterative", "iterative_zero_0p2"),
            (.2, "zero", "single_step", "single_step_reference_0p2")):
        result.append(Combination(f"original_s100_diagnostic_{suffix}", "original_s100", method,
                                  epsilon=epsilon, initialization=initialization))
    assert len(result) == 52 and len({c.id for c in result}) == 52
    return result


class Workspace:
    def __init__(self, root, data_dir, repo, original_models_root=None, data_manifest=None):
        # Require an explicit revision identity in the output path and reject symlink ancestors.
        raw = Path(root).absolute()
        if not any("revision_HYDROL85935_20261008_001" in p or IDENTITY in p for p in raw.parts):
            raise ValueError("Output root must contain this revision's exact identity")
        for ancestor in (raw, *raw.parents):
            if ancestor.exists() and ancestor.resolve() != ancestor.absolute():
                raise ValueError(f"Symlink/junction output ancestor is forbidden: {ancestor}")
        self.root, self.repo = raw.resolve(), Path(repo).resolve()
        self.data_dir = Path(data_dir).resolve(strict=True)
        if not self.data_dir.is_dir():
            raise ValueError("data-dir is not a directory")
        self.original_models_root = Path(original_models_root or self.repo / "results/18_lstm_fair_531").resolve(strict=True)
        candidate = Path(data_manifest) if data_manifest else self.data_dir / "DATA.sha256"
        self.data_manifest = candidate.resolve(strict=True) if data_manifest or candidate.exists() else None
        for forbidden in (self.original_models_root, self.data_dir, self.repo / "src", self.repo / "draft"):
            if self.root == forbidden or forbidden in self.root.parents:
                raise ValueError(f"Output root overlaps protected input: {forbidden}")

    def output(self, relative):
        path = self.root / relative
        if not path.resolve().is_relative_to(self.root):
            raise ValueError("Output escapes revision root")
        if path.resolve() == self.original_models_root or self.original_models_root in path.resolve().parents:
            raise ValueError("Cannot write original model assets")
        for ancestor in (path, *path.parents):
            if ancestor.exists() and ancestor.resolve() != ancestor.absolute():
                raise ValueError("Symlink/junction output is forbidden")
        return path

    def basins(self):
        path = self.repo / "src/xaj_global_pilot/configs/conceptual_benchmark_camels_us_531_repro.txt"
        values = [x.strip() for x in path.read_text().splitlines() if x.strip()]
        if len(values) != 531 or len(set(values)) != 531 or any(len(x) != 8 or not x.isdigit() for x in values):
            raise ValueError("Expected 531 unique eight-digit basin IDs")
        return values, sha256(path)

    def model_dir(self, model_id):
        seed = int(model_id.rsplit("_s", 1)[1])
        if model_id == f"original_s{seed}" and seed in SEEDS:
            return self.original_models_root / ORIGINAL_NAMES[seed]
        if model_id == f"single_temperature_s{seed}" and seed in SEEDS:
            from .assets import verify_training_assets
            return verify_training_assets(self, seed)[0]
        raise ValueError(f"Unknown model: {model_id}")

    def manifest(self):
        import neuralhydrology
        from .assets import capture_original_assets
        _, basin_hash = self.basins()
        sources = list(Path(__file__).parent.glob("*.py"))
        core_root = Path(neuralhydrology.__file__).parent
        source_hashes = {"src/adversarial/scripts/revision_20261008/" + p.name: sha256(p) for p in sorted(sources)}
        source_hashes["src/adversarial/model_wrapper.py"] = sha256(self.repo / "src/adversarial/model_wrapper.py")
        source_hashes.update({"neuralhydrology/" + str(p.relative_to(core_root)).replace("\\", "/"): sha256(p)
                              for p in sorted(core_root.rglob("*.py"))})
        contract_hashes = {name: sha256(self.repo / CONTRACT_DIR / name) for name in CONTRACT_FILES}
        return dict(identity=IDENTITY, science=SCIENCE, basin_list_sha256=basin_hash,
                    contract_sha256=contract_hashes, source_sha256=source_hashes,
                    original_assets=capture_original_assets(self), data_identity=self.data_identity(),
                    combinations=[c.metadata() for c in combinations()],
                    diagnostic_references={"original_s100_diagnostic_iterative_random_trace_0p1":
                                           "original_s100_iterative_eps0p1_bound_only",
                                           "original_s100_diagnostic_single_step_reference_0p1":
                                           "original_s100_single_step_eps0p1_bound_only"})

    def data_identity(self):
        identity = dict(data_dir=str(self.data_dir), manifest=None)
        if self.data_manifest is not None:
            seen = set()
            for line in self.data_manifest.read_text(encoding="utf-8-sig").splitlines():
                if not line.strip():
                    continue
                expected, relative = line.split(None, 1)
                relative = relative.lstrip("*")
                path = (self.data_dir / relative).resolve(strict=True)
                if not path.is_relative_to(self.data_dir) or path in seen or len(expected) != 64:
                    raise ValueError("Invalid, duplicate or escaping data manifest entry")
                seen.add(path)
                if sha256(path) != expected:
                    raise ValueError(f"Frozen input data checksum mismatch: {relative}")
            if not seen:
                raise ValueError("Input data manifest is empty")
            identity["manifest"] = dict(path=str(self.data_manifest), sha256=sha256(self.data_manifest), verified_files=len(seen))
        return identity
