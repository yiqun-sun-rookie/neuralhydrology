"""Read authentic NH windows and their actual date arrays; fixed epoch only."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
import yaml

from .contracts import FEATURES4, FEATURES5, SCIENCE, sha256, digest_json


@dataclass
class BasinData:
    calendar: torch.Tensor
    static: torch.Tensor
    observations: torch.Tensor
    calendar_dates: np.ndarray
    prediction_dates: np.ndarray
    window_index: np.ndarray
    scoring_mask: torch.Tensor
    window_length: int
    input_identity: str
    snow_fraction: float


def reconstruct_windows(windows, dates, static, observations, window_length=None, enforce_period=True):
    dates = np.asarray(dates).astype("datetime64[D]")
    n, length, _ = windows.shape
    if dates.shape != (n, length) or n < 1 or (window_length is not None and length != window_length):
        raise ValueError("Window/date dimensions disagree")
    if np.isnat(dates).any() or not np.all(np.diff(dates, axis=1) == np.timedelta64(1, "D")):
        raise ValueError("Actual window dates must be consecutive daily dates")
    if n > 1 and not np.all(np.diff(dates[:, -1]) == np.timedelta64(1, "D")):
        raise ValueError("Prediction dates have gaps or duplicates; no fabricated calendar")
    cal_dates = np.concatenate((dates[0], dates[1:, -1]))
    index = np.arange(n)[:, None] + np.arange(length)[None, :]
    if not np.array_equal(cal_dates[index], dates):
        raise ValueError("Overlapping dates disagree")
    clean = torch.cat((windows[0], windows[1:, -1]), dim=0)
    for start in range(0, n, 128):
        stop = min(start + 128, n)
        expected = clean[start:stop + length - 1].unfold(0, length, 1).permute(0, 2, 1)
        if not torch.equal(expected, windows[start:stop]):
            raise ValueError("Nonfinite input or inconsistent overlapping forcing windows")
    if not torch.isfinite(clean).all() or not torch.isfinite(static).all():
        raise ValueError("Nonfinite forcing or static inputs; basin is a numerical failure")
    if not torch.equal(static, static[0].expand_as(static)):
        raise ValueError("Unexpected evolving static attributes")
    if observations.shape != (n,):
        raise ValueError("Observations do not match dated last-step outputs")
    pred_dates = dates[:, -1]
    if enforce_period:
        expected_dates = np.arange(np.datetime64(SCIENCE["test_start"]),
                                   np.datetime64(SCIENCE["test_end"]) + np.timedelta64(1, "D"))
        if not np.array_equal(pred_dates, expected_dates):
            raise ValueError("Actual dates must exactly cover the frozen evaluation interval")
    mask = torch.isfinite(observations)
    identity = digest_json({"calendar_dates": cal_dates.astype(str).tolist(),
                            "calendar": array_digest(clean), "static": array_digest(static[0]),
                            "observations": array_digest(observations), "window_length": length})
    return BasinData(clean, static[0], observations, cal_dates, pred_dates, index, mask, length, identity, float("nan"))


def array_digest(value):
    import hashlib
    a = value.detach().cpu().numpy() if torch.is_tensor(value) else np.asarray(value)
    return hashlib.sha256(a.dtype.str.encode() + str(a.shape).encode() + a.tobytes()).hexdigest()


def validate_config(cfg, representation):
    expected = list(FEATURES5 if representation == "original" else FEATURES4)
    if list(cfg.dynamic_inputs) != expected or cfg.seq_length != 270 or cfg.predict_last_n != 1:
        raise ValueError("Feature order/window/last-step contract mismatch")
    if cfg.model != "cudalstm" or cfg.epochs != 30 or list(cfg.forcings) != ["maurer"]:
        raise ValueError("Frozen network/training/forcing contract mismatch")
    if cfg.seed not in (100, 200, 300):
        raise ValueError("Unexpected training seed")
    for key in ("train_start", "train_end", "test_start", "test_end"):
        if getattr(cfg, key + "_date").strftime("%Y-%m-%d") != SCIENCE[key]:
            raise ValueError(f"Date contract mismatch: {key}")


def load_model(workspace, model_id, device):
    from .assets import expected_model_identity
    identity = expected_model_identity(workspace, model_id)  # Verify assets before allocating/loading a model.
    from src.adversarial.model_wrapper import CudaLSTMWrapper
    run = workspace.model_dir(model_id)
    wrapper = CudaLSTMWrapper(run, device=device, epoch=30)
    validate_config(wrapper.cfg, "original" if model_id.startswith("original_") else "single_temperature")
    if wrapper.cfg.seed != int(model_id.rsplit("_s", 1)[1]):
        raise ValueError("Model ID/seed mismatch")
    wrapper.model.requires_grad_(False)
    return wrapper, identity


def load_basin(workspace, wrapper, basin_id, device):
    from neuralhydrology.datasetzoo import get_dataset
    from neuralhydrology.utils.config import Config
    from torch.utils.data import DataLoader
    cfg = Config(wrapper.run_dir / "config.yml")
    # Override only read/execution paths; no dated samples are synthesized.
    cfg.update_config({"data_dir": workspace.data_dir})
    ds = get_dataset(cfg=cfg, is_train=False, period="test", basin=basin_id,
                     scaler=wrapper.get_scaler(), id_to_int={})
    if not len(ds):
        raise ValueError("No actual dated windows")
    batch = next(iter(DataLoader(ds, batch_size=len(ds), collate_fn=ds.collate_fn, shuffle=False)))
    windows = torch.cat([batch["x_d"][f] for f in wrapper.dynamic_features], dim=-1).to(device)
    static = batch.get("x_s", torch.zeros(len(ds), 0)).to(device)
    data = reconstruct_windows(windows, batch["date"], static, batch["y"][:, -1, 0].to(device), 270)
    sc = wrapper.get_scaler()
    if "frac_snow" not in wrapper.static_features:
        raise ValueError("Frozen snow grouping attribute missing")
    # Use the actual raw attribute, avoiding threshold changes from float32 normalization reversal.
    attributes = ds._load_attributes()
    data.snow_fraction = float(attributes.loc[basin_id, "frac_snow"])
    if not np.isfinite(data.snow_fraction):
        raise ValueError("Nonfinite raw snow grouping attribute")
    return data


def scaler_fields(wrapper):
    sc = wrapper.get_scaler()
    center = np.array([float(sc["xarray_feature_center"][f].values) for f in wrapper.dynamic_features])
    scale = np.array([float(sc["xarray_feature_scale"][f].values) for f in wrapper.dynamic_features])
    q_center = float(sc["xarray_feature_center"]["QObs(mm/d)"].values)
    q_scale = float(sc["xarray_feature_scale"]["QObs(mm/d)"].values)
    if not np.isfinite(center).all() or not np.isfinite(scale).all() or (scale <= 0).any() or not np.isfinite([q_center, q_scale]).all() or q_scale <= 0:
        raise ValueError("Nonfinite or nonpositive normalization parameters")
    return center, scale, q_center, q_scale


def reference_std(workspace):
    from neuralhydrology.datautils.utils import load_scaler
    values = []
    for seed in (100, 200, 300):
        from .assets import verify_original_assets
        verify_original_assets(workspace, f"original_s{seed}")
        sc = load_scaler(workspace.model_dir(f"original_s{seed}"))
        center, scale = sc["xarray_feature_center"], sc["xarray_feature_scale"]
        if float(center["Tmin(C)"].values) != float(center["Tmax(C)"].values) or float(scale["Tmin(C)"].values) != float(scale["Tmax(C)"].values):
            raise ValueError("Original temperature normalization differs; cannot bind")
        values.append([float(scale[f].values) for f in FEATURES4])
    if not np.array_equal(values[0], values[1]) or not np.array_equal(values[0], values[2]):
        raise ValueError("Original shared training reference standard deviations differ")
    return np.asarray(values[0])


def baseline_check(workspace, wrapper, basin_id, data, prediction, q_center, q_scale):
    """Compact NPZ has only dates and clean predictions; falls back to trusted local pickle."""
    from .assets import verify_original_assets
    _, assets = verify_original_assets(workspace, f"original_s{wrapper.cfg.seed}")
    source = wrapper.run_dir / assets["files"]["baseline"]["relative_path"]
    if source.suffix == ".npz":
        with np.load(source, allow_pickle=False) as archive:
            dates = archive["prediction_dates"].astype("datetime64[D]")
            saved = archive[f"q_{basin_id}"]
        source_hash = sha256(source)
    else:
        import pickle
        with source.open("rb") as f:
            xr = pickle.load(f)[basin_id]["1D"]["xr"]
        dates = xr.date.values.astype("datetime64[D]")
        saved = xr["QObs(mm/d)_sim"].values[:, -1]
        source_hash = sha256(source)
    from .engine import denormalize
    actual = denormalize(prediction, q_center, q_scale)
    obs = denormalize(data.observations, q_center, q_scale)
    saved = np.asarray(saved, np.float64)
    mask = data.scoring_mask.cpu().numpy()
    if not np.array_equal(dates, data.prediction_dates) or saved.shape != actual.shape or not np.isfinite(saved).all():
        raise ValueError("Saved clean baseline dates/shape/finiteness mismatch")
    denominator = np.sum((obs[mask] - obs[mask].mean()) ** 2)
    if mask.sum() < 2 or denominator == 0:
        raise ValueError("Baseline NSE is undefined")
    old = 1 - np.sum((obs[mask] - saved[mask]) ** 2) / denominator
    new = 1 - np.sum((obs[mask] - actual[mask]) ** 2) / denominator
    error = float(np.max(np.abs(actual - saved)))
    if abs(old - new) > SCIENCE["baseline_nse_tolerance"]:
        raise ValueError(f"Baseline reproduction failed: NSE difference={abs(old-new)}, max prediction error={error}")
    return dict(status="PASS", stored_nse=float(old), reproduced_nse=float(new), nse_difference=float(abs(old-new)),
                max_daily_error_mm_day=error, baseline_sha256=source_hash)
