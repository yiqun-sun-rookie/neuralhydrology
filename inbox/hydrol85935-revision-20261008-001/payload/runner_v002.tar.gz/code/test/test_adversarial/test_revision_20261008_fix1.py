"""Independent-review counterexamples; synthetic fixtures, no external data or trained weights."""
import copy
import csv
import json
from pathlib import Path
import shutil
import sys
import unittest
from unittest.mock import patch

import numpy as np
import torch
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_revision_20261008_runner import FakeWorkspace, TinyModel, engine5
from src.adversarial.scripts.revision_20261008.contracts import combinations, Combination, digest_json, sha256, FEATURES4
from src.adversarial.scripts.revision_20261008.assets import expected_model_identity, verify_training_assets, register_training_assets
from src.adversarial.scripts.revision_20261008.data import load_model, reconstruct_windows
from src.adversarial.scripts.revision_20261008.engine import BasinEngine, SignalMap, denormalize, physical_metrics, metric_changes
from src.adversarial.scripts.revision_20261008.records import save, load_complete, json_write
from src.adversarial.scripts.revision_20261008.training import prepare_training
from src.adversarial.scripts.revision_20261008.validation import SlotValidator
from src.adversarial.scripts.revision_20261008.run import validate_all, result_exit_code
from src.adversarial.scripts.revision_20261008.reporting import report, paired_flood_events


def full_engine():
    n, length = 3652, 270
    e = engine5(256)
    calendar = e.data.calendar[0].repeat(n + length - 1, 1)
    calendar[:, 0] = torch.linspace(.1, .8, len(calendar))
    dates = np.arange(np.datetime64("1989-01-05"), np.datetime64("1999-10-01"))
    index = np.arange(n)[:, None] + np.arange(length)[None, :]
    windows = calendar.unfold(0, length, 1).permute(0, 2, 1)
    data = reconstruct_windows(windows, dates[index], torch.zeros(n, 0), torch.linspace(1., 3., n), 270)
    data.snow_fraction = .3
    return BasinEngine(e.wrapper, data, e.map, e.q_center, e.q_scale, 256)


def install_clean(fixture, engine, model="original_s100", basin="00000000"):
    w, e = fixture.workspace, engine
    shared_root = w.output(f"shared_observations/{basin}")
    shared_root.mkdir(parents=True, exist_ok=True)
    shared = dict(q_observed=denormalize(e.y, e.q_center, e.q_scale), q_normalized_original=e.y.numpy(),
                  calendar_dates=e.data.calendar_dates.astype(str), prediction_dates=e.data.prediction_dates.astype(str),
                  scoring_mask=e.mask.numpy())
    np.savez_compressed(shared_root / "arrays.npz", **shared)
    shared_hash = sha256(shared_root / "arrays.npz")
    json_write(shared_root / "complete.json", dict(arrays_sha256=shared_hash, source="original_s100", input_identity=e.data.input_identity,
                                                   manifest_sha256=fixture.fingerprint, source_model_identity=expected_model_identity(w, "original_s100")))
    base = dict(manifest_sha256=fixture.fingerprint, model=expected_model_identity(w, model), basin_id=basin,
                input_identity=e.data.input_identity, chunk=256, device="cpu", data_dir=str(w.data_dir), shared_observation_sha256=shared_hash)
    clean_arrays = dict(calendar_dates=shared["calendar_dates"], prediction_dates=shared["prediction_dates"], scoring_mask=shared["scoring_mask"],
                        q_observed=shared["q_observed"], q_clean=denormalize(e.clean_pred, e.q_center, e.q_scale),
                        q_observed_normalized=e.y.numpy(), q_clean_normalized=e.clean_pred.numpy())
    clean_id = save(w, f"records/clean/{model}/{basin}", dict(**base, target="clean"), clean_arrays,
                    dict(window_length=270, q_center=e.q_center, q_scale=e.q_scale), kind="clean")
    return base, clean_id


def install_single_step(fixture):
    e = full_engine()
    base, clean_id = install_clean(fixture, e)
    c = next(c for c in combinations() if c.model_id == "original_s100" and c.method == "single_step")
    arrays, details = e.attack(c, "00000000")
    identity = dict(**base, combination=c.metadata(), clean_record_id=clean_id)
    relative = f"records/attacks/{c.id}/00000000"
    save(fixture.workspace, relative, identity, arrays, details)
    return e, c, relative, arrays, details, identity


def install_training(fixture, seed=100):
    w = fixture.workspace
    cfg_file, metadata = prepare_training(w, seed, "cpu", fixture.fingerprint)
    prepared = yaml.safe_load(cfg_file.read_text())
    run = w.output(f"training/s{seed}/runs/fixture_complete")
    (run / "train_data").mkdir(parents=True)
    actual = dict(prepared, run_dir=str(run), train_dir=str(run / "train_data"), img_log_dir=str(run / "img_log"),
                  commit_hash="1f9804e", package_version="1.12.0")
    (run / "config.yml").write_text(yaml.safe_dump(actual))
    (run / "model_epoch030.pt").write_bytes(b"fixture-new-weight")
    (run / "train_data/train_data_scaler.yml").write_text("fixture_new_scaler: true\n")
    register_training_assets(w, seed, run, metadata)
    return run, metadata


class ReviewFixTests(unittest.TestCase):
    def test_each_original_asset_changed_before_inference_fails(self):
        for asset in ("config", "weight", "scaler", "baseline"):
            with self.subTest(asset=asset), FakeWorkspace() as fixture:
                w = fixture.workspace
                m = json.loads(w.output("frozen/manifest.json").read_text())
                original = m["original_assets"]["original_s100"]
                path = w.original_models_root / original["directory"] / original["files"][asset]["relative_path"]
                path.write_bytes(path.read_bytes() + b"changed")
                with patch("src.adversarial.model_wrapper.CudaLSTMWrapper") as constructor:
                    with self.assertRaisesRegex(ValueError, "changed before model load"):
                        load_model(w, "original_s100", "cpu")
                    constructor.assert_not_called()

    def test_training_foreign_manifest_rejected_before_model_load(self):
        with FakeWorkspace() as fixture:
            install_training(fixture)
            w = fixture.workspace
            for path in (w.output("training/s100/complete.json"), w.output("frozen/training_assets/s100.json")):
                marker = json.loads(path.read_text())
                marker["manifest_sha256"] = "foreign manifest"
                json_write(path, marker)
            with patch("src.adversarial.model_wrapper.CudaLSTMWrapper") as constructor:
                with self.assertRaisesRegex(ValueError, "provenance mismatch"):
                    load_model(w, "single_temperature_s100", "cpu")
                constructor.assert_not_called()

    def test_training_actual_scaler_config_and_index_are_verified(self):
        for asset in ("config.yml", "train_data/train_data_scaler.yml", "model_epoch030.pt"):
            with self.subTest(asset=asset), FakeWorkspace() as fixture:
                run, metadata = install_training(fixture)
                self.assertEqual(verify_training_assets(fixture.workspace, 100)[0], run)
                (run / asset).write_bytes((run / asset).read_bytes() + b"changed")
                with self.assertRaises(ValueError):
                    verify_training_assets(fixture.workspace, 100)
                with self.assertRaises(ValueError):
                    register_training_assets(fixture.workspace, 100, run, metadata)

    def test_wrong_combination_and_basin_slots_rejected_by_validator(self):
        with FakeWorkspace() as fixture:
            e, c, relative, arrays, details, identity = install_single_step(fixture)
            validator = SlotValidator(fixture.workspace)
            self.assertIsNotNone(validator.attack(c, "00000000"))
            other = next(x for x in combinations() if x.model_id == c.model_id and x.method == "gaussian")
            wrong = fixture.workspace.output(f"records/attacks/{other.id}/00000000")
            shutil.copytree(fixture.workspace.output(relative), wrong)
            with self.assertRaisesRegex(ValueError, "wrong combination slot"):
                SlotValidator(fixture.workspace).attack(other, "00000000")
            wrong_basin = fixture.workspace.output(f"records/attacks/{c.id}/00000001")
            shutil.copytree(fixture.workspace.output(relative), wrong_basin)
            with self.assertRaises(ValueError):
                SlotValidator(fixture.workspace).attack(c, "00000001")

    def test_old_manifest_record_rejected_without_trusting_internal_hash(self):
        with FakeWorkspace() as fixture:
            e, c, relative, arrays, details, identity = install_single_step(fixture)
            # Write an internally valid stale archive into a second real planned slot.
            diagnostic = next(x for x in combinations() if "single_step_reference_0p2" in x.id)
            old_identity = dict(identity, manifest_sha256="old manifest", combination=diagnostic.metadata())
            save(fixture.workspace, f"records/attacks/{diagnostic.id}/00000000", old_identity, arrays, details)
            with self.assertRaisesRegex(ValueError, "frozen identity mismatch"):
                SlotValidator(fixture.workspace).attack(diagnostic, "00000000")

    def test_missing_and_wrong_clean_reference_rejected(self):
        with FakeWorkspace() as fixture:
            e, c, relative, arrays, details, identity = install_single_step(fixture)
            clean = fixture.workspace.output("records/clean/original_s100/00000000/complete.json")
            original = clean.read_bytes()
            clean.unlink()
            with self.assertRaisesRegex(ValueError, "clean reference is missing"):
                SlotValidator(fixture.workspace).attack(c, "00000000")
            clean.write_bytes(original)
            other = next(x for x in combinations() if "single_step_reference_0p2" in x.id)
            save(fixture.workspace, f"records/attacks/{other.id}/00000000", dict(identity, combination=other.metadata(), clean_record_id="wrong"), arrays, details)
            with self.assertRaisesRegex(ValueError, "current clean reference"):
                SlotValidator(fixture.workspace).attack(other, "00000000")

    def test_validation_and_report_both_exclude_wrong_stale_and_missing_reference(self):
        with FakeWorkspace() as fixture:
            e, c, relative, arrays, details, identity = install_single_step(fixture)
            w = fixture.workspace
            gaussian = next(x for x in combinations() if x.model_id == c.model_id and x.method == "gaussian")
            shutil.copytree(w.output(relative), w.output(f"records/attacks/{gaussian.id}/00000000"))
            old = next(x for x in combinations() if "single_step_reference_0p2" in x.id)
            save(w, f"records/attacks/{old.id}/00000000", dict(identity, combination=old.metadata(), manifest_sha256="old"), arrays, details)
            # The legitimate slot now also has a missing clean reference.
            w.output("records/clean/original_s100/00000000/complete.json").unlink()
            validated = validate_all(w)
            reported = report(w)
            for result in (validated, reported):
                self.assertEqual(result["complete_attack_records"], 0)
                self.assertEqual(result["failed"], 3)
                self.assertFalse(result["task_complete"])
            with w.output("analysis/metrics.csv").open(encoding="utf-8-sig") as f:
                self.assertEqual(f.read(), "")

    def test_low_flow_large_negative_nse_float64_roundtrip(self):
        e = engine5()
        e.q_center, e.q_scale = 1.5118002891540527, 3.629760980606079
        e.y = torch.full((12,), -e.q_center / e.q_scale) + torch.linspace(0, .0001, 12)
        e.data.observations = e.y
        e.denominator = ((e.y - e.y.mean()) ** 2).sum()
        e.clean_nse = e.score(e.clean_pred)
        c = Combination("low_flow", "original_s100", "single_step")
        arrays, details = e.attack(c, "00000000")
        self.assertLess(details["selected_target_nse"], -1e8)
        self.assertEqual(arrays["q_observed"].dtype, np.float64)
        with FakeWorkspace() as fixture:
            save(fixture.workspace, "synthetic/low_flow", {"combination": c.metadata()}, arrays, details)
            loaded = load_complete(fixture.workspace, "synthetic/low_flow")
            self.assertEqual(loaded[1]["details"]["selected_target_nse"], details["selected_target_nse"])

    def test_empty_and_partial_full_acceptance_never_overall_pass(self):
        with FakeWorkspace() as fixture:
            empty = validate_all(fixture.workspace)
            self.assertEqual(empty["not_executed"], 27612)
            self.assertEqual(empty["auxiliary"]["complete_trainings"], 0)
            self.assertEqual(result_exit_code("validate", empty), 1)
            install_single_step(fixture)
            partial = report(fixture.workspace)
            self.assertEqual(partial["complete_attack_records"], 1)
            self.assertEqual(partial["auxiliary"]["complete_clean_records"], 1)
            self.assertEqual(partial["auxiliary"]["complete_restore_series"], 0)
            self.assertEqual(result_exit_code("report", partial), 1)

    def test_required_restore_missing_fails_even_without_importance_metadata(self):
        e = engine5()
        c = Combination("required_restore", "original_s100", "iterative")
        arrays, details = e.attack(c, "00000000", steps=2)
        with FakeWorkspace() as fixture:
            with self.assertRaisesRegex(ValueError, "Required four-signal"):
                save(fixture.workspace, "synthetic/missing_restore", {"combination": c.metadata()}, arrays, details)
            arrays["q_signal_restored"], details["importance"] = e.restore(torch.as_tensor(arrays["delta_signals"]))
            save(fixture.workspace, "synthetic/with_restore", {"combination": c.metadata()}, arrays, details)
            self.assertEqual(load_complete(fixture.workspace, "synthetic/with_restore")[0]["q_signal_restored"].shape, (4, 12))

    def test_undefined_clean_metric_change_has_both_sides_and_reason(self):
        y, mask = np.array([1., 2., 4.]), np.ones(3, bool)
        changes = metric_changes(physical_metrics(y, np.ones(3), mask), physical_metrics(y, np.array([2., 3., 5.]), mask))
        kge = changes["kge"]
        self.assertIsNone(kge["change"])
        self.assertEqual(kge["status"], "uncomputable")
        self.assertEqual(kge["clean_status"], "uncomputable")
        self.assertEqual(kge["attacked_status"], "complete")
        self.assertIn("clean: constant_prediction", kge["reason"])

    def test_auxiliary_peak_rmse_normalized_correlation_and_event_pairs(self):
        n, length = 100, 4
        calendar = torch.full((n + length - 1, 4), .3)
        dates = np.arange(np.datetime64("1989-01-05"), np.datetime64("1989-01-05") + np.timedelta64(len(calendar), "D"))
        index = np.arange(n)[:, None] + np.arange(length)[None, :]
        y = torch.ones(n)
        y[30], y[44], y[75] = 10., 9., 11.
        data = reconstruct_windows(calendar.unfold(0, length, 1).permute(0, 2, 1), dates[index], torch.zeros(n, 0), y, 4, False)
        data.snow_fraction = .3
        engine = BasinEngine(TinyModel([.4, .2, .5, .1]), data, SignalMap(FEATURES4, [0]*4, [1]*4, [1]*4, .1), 1.5, 3.6, 32)
        c = next(x for x in combinations() if x.model_id == "single_temperature_s100" and x.location == "pre_peak")
        arrays, details = engine.attack(c, "00000000", steps=2)
        mask = arrays["target_mask"]
        expected_rmse = np.sqrt(np.mean((arrays["q_observed"][mask] - arrays["q_attacked"][mask]) ** 2))
        self.assertAlmostEqual(details["peak_day_metrics"]["rmse"]["attacked"], expected_rmse)
        with FakeWorkspace() as fixture:
            save(fixture.workspace, "synthetic/peaks", {"combination": c.metadata()}, arrays, details)
            self.assertIsNotNone(load_complete(fixture.workspace, "synthetic/peaks"))
            records = {(c.id, "00000000"): {"details": details, "record_id": "synthetic-peak"}}
            primary = "original_s100_iterative_eps0p1_bound_only"
            for i, norm in enumerate((.2, .4, None)):
                d = copy.deepcopy(details)
                d.pop("peak_day_metrics")
                d["snow_fraction"] = .1 + .2*i
                d["importance"] = dict(raw_importance={"precipitation":1., "temperature_mean":2., "shortwave_radiation":3., "vapor_pressure":4.},
                                       normalized_importance={"temperature_mean":norm} if norm is not None else None,
                                       normalization_denominator=10. if norm is not None else 0.)
                records[(primary, f"{i:08d}")] = {"details": d, "record_id": f"synthetic-importance-{i}"}
            summary = dict(task_complete=False, status="INCOMPLETE", failed=0, uncomputable=0, not_executed=27608)
            with patch("src.adversarial.scripts.revision_20261008.reporting.audit_all", return_value=(summary, [], [], records)):
                report(fixture.workspace)
            with fixture.workspace.output("analysis/peak_day_metrics.csv").open(encoding="utf-8-sig") as f:
                self.assertEqual(len(list(csv.DictReader(f))), 1)
            with fixture.workspace.output("analysis/snow_correlations.csv").open(encoding="utf-8-sig") as f:
                rows = list(csv.DictReader(f))
            row = next(r for r in rows if r["model_id"] == "original_s100" and r["variable"] == "snow_fraction_vs_normalized_temperature_importance")
            self.assertEqual(row["usable_normalized_records"], "2")
            self.assertEqual(row["uncomputable_normalized_records"], "1")
        event = dict(date="1989-11-01", amplitude_change_fraction=.2, exclusion_reason="")
        excluded = dict(event, amplitude_change_fraction=None, exclusion_reason="clean_local_peak_at_most_0p1_mm_day")
        rows, counts = paired_flood_events({("original_s100_iterative_eps0p1_bound_only", "00000000"): {"flood_amplitude_events":[event]},
                                            ("single_temperature_s100_iterative_eps0p1_bound_only", "00000000"): {"flood_amplitude_events":[excluded]}},
                                           ["00000000"], ["original_s100", "single_temperature_s100"])
        self.assertFalse(rows[0]["eligible_pair"])
        self.assertIsNone(rows[0]["paired_difference_b_minus_a"])
        self.assertEqual(counts[0]["eligible_paired_events"], 0)
        self.assertEqual(counts[0]["excluded_or_missing_model_b"], 1)

    def test_data_manifest_change_fails_before_freeze_or_inference(self):
        with FakeWorkspace() as fixture:
            w = fixture.workspace
            source = w.data_dir / "forcing.txt"
            source.write_text("actual fixture input\n")
            manifest = w.data_dir / "DATA.sha256"
            manifest.write_text(sha256(source) + "  forcing.txt\n")
            w.data_manifest = manifest
            identity = w.data_identity()
            self.assertEqual(identity["manifest"]["verified_files"], 1)
            source.write_text("changed input\n")
            with self.assertRaisesRegex(ValueError, "input data checksum"):
                w.manifest()


if __name__ == "__main__":
    torch.set_num_threads(2)
    unittest.main()
