"""Copy the explicitly hashed 531-basin input set into the exclusive task root."""
import argparse
import hashlib
import json
import os
import shutil
from pathlib import Path, PurePosixPath


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--version-dir', required=True, type=Path)
    args = p.parse_args()
    version = args.version_dir.resolve(strict=True)
    task = Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001')
    shared = Path('/data1/home/sunyiq/neuralhydrology/data/camels_us').resolve(strict=True)
    target = task / 'inputs_v001'
    if not version.is_relative_to(task / 'versions') or (task / 'OWNER').read_text().strip() != task.name:
        raise ValueError('Wrong task ownership')
    manifest_file = version / 'data_identity.json'
    document = json.loads(manifest_file.read_text())
    manifest_hash = sha(manifest_file)
    if document['files'] != 1069 or document['basins'] != 531:
        raise ValueError('Incorrect input inventory')
    completion = target / 'INPUTS_COMPLETE.json'
    if target.exists():
        if target.is_symlink() or not completion.is_file():
            raise ValueError('Incomplete/unowned input target exists; do not silently overwrite')
        if json.loads(completion.read_text())['manifest_sha256'] != manifest_hash:
            raise ValueError('Different completed input identity')
        for entry in document['entries']:
            path = target / entry['path']
            if path.is_symlink() or not path.resolve().is_relative_to(target) or sha(path) != entry['sha256']:
                raise ValueError('Previously completed input changed')
        print('EXISTING_INPUTS_VERIFIED 1069')
        return
    target.mkdir(exist_ok=False)
    provenance = []
    allowed = {'basin_mean_forcing/maurer/03/02108000_lump_maurer_forcing_leap.txt',
               'basin_mean_forcing/maurer/09/05120500_lump_maurer_forcing_leap.txt',
               'basin_mean_forcing/maurer/15/09492400_lump_maurer_forcing_leap.txt'}
    for entry in document['entries']:
        relative = PurePosixPath(entry['path'])
        if relative.is_absolute() or '..' in relative.parts or not relative.parts:
            raise ValueError('Unsafe input inventory path')
        source = shared / relative
        if not source.resolve(strict=True).is_relative_to(shared):
            raise ValueError('Shared source escaped its approved data root')
        observed_hash = sha(source)
        if entry['path'] in allowed:
            source = version / 'input_overrides' / relative
            if not source.is_file() or sha(source) != entry['sha256']:
                raise ValueError('Replacement is not the verified local source')
            source_kind = 'verified_local_snapshot'
        else:
            if observed_hash != entry['sha256']:
                raise ValueError('Unlisted shared data difference; preserve partial evidence and stop')
            source_kind = 'matching_shared_snapshot'
        output = target / relative
        output.parent.mkdir(parents=True, exist_ok=True)
        if output.exists() or output.is_symlink() or not output.resolve().is_relative_to(target):
            raise ValueError('Destination already exists or escaped new input root')
        with source.open('rb') as incoming, output.open('xb') as outgoing:
            shutil.copyfileobj(incoming, outgoing)
        if sha(output) != entry['sha256']:
            raise ValueError('Copied input failed hash verification')
        provenance.append(dict(path=entry['path'], sha256=entry['sha256'], shared_sha256=observed_hash,
                               source_kind=source_kind, bytes=entry['bytes']))
    shutil.copyfile(version / 'DATA.sha256', target / 'DATA.sha256')
    with (target / 'INPUT_PROVENANCE.json').open('x') as stream:
        json.dump(provenance, stream, indent=2)
    with completion.open('x') as stream:
        json.dump(dict(status='COMPLETE', files=len(provenance), manifest_sha256=manifest_hash,
                       data_sha256=sha(target / 'DATA.sha256'), shared_data_modified=False), stream, indent=2)
    print('INPUTS_MATERIALIZED_AND_VERIFIED 1069; SHARED_DATA_UNCHANGED')


if __name__ == '__main__':
    main()
