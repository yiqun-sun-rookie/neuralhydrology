"""Finite login-node file/scheduler coordinator; all scientific work uses Slurm."""
import datetime
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001')
VERSION = 'v003'
SETUP = ROOT / 'control/runtime_setup_20261009_001'
CONTROL = ROOT / 'control/continuation_v003'
DEADLINE_SECONDS = 48 * 60 * 60


def record(phase, **detail):
    value = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), phase=phase, **detail)
    with (CONTROL / 'events.jsonl').open('a') as stream:
        stream.write(json.dumps(value) + '\n')
    temporary = CONTROL / 'status.partial.json'
    temporary.write_text(json.dumps(value, indent=2))
    temporary.replace(CONTROL / 'status.json')
    print(json.dumps(value), flush=True)


def check_time(deadline):
    if time.monotonic() > deadline:
        raise TimeoutError('48-hour coordinator deadline reached; no job was cancelled or resubmitted')


def timeout(deadline, maximum):
    check_time(deadline)
    return min(maximum, max(0.001, deadline - time.monotonic()))


def captured(error):
    def decode(value):
        return value.decode(errors='replace') if isinstance(value, bytes) else (value or '')
    return decode(error.stdout) + decode(error.stderr)


def wait_runtime_job(deadline):
    while True:
        check_time(deadline)
        path = SETUP / 'job_id'
        if path.exists():
            job = path.read_text().strip()
            if not job.isdigit():
                raise ValueError('Invalid isolated-runtime scheduler receipt')
            check_time(deadline)
            return job
        exit_path = SETUP / 'supervisor_exit_code'
        if exit_path.exists():
            raise RuntimeError('Download/install supervisor finished without a job receipt: ' + exit_path.read_text())
        time.sleep(timeout(deadline, 60))


def wait_job(job, stage, deadline):
    previous = None
    while True:
        check_time(deadline)
        result = subprocess.run(['sacct', '-j', job, '-n', '-P', '--format=JobIDRaw,State,ExitCode'],
                                text=True, capture_output=True, check=True, timeout=timeout(deadline, 60))
        check_time(deadline)
        rows = [line.split('|') for line in result.stdout.splitlines() if line.split('|')[0] == job]
        if len(rows) > 1:
            raise ValueError('Ambiguous scheduler identity')
        if rows:
            state, exit_code = rows[0][1:3]
            if (state, exit_code) != previous:
                record(stage, scheduler_job_id=job, scheduler_state=state, exit_code=exit_code)
                previous = state, exit_code
            if state == 'COMPLETED' and exit_code == '0:0':
                return
            if state not in {'PENDING', 'RUNNING', 'CONFIGURING', 'COMPLETING', 'RESIZING', 'SUSPENDED', 'REQUEUED', 'REQUEUE_FED', 'REQUEUE_HOLD'}:
                raise RuntimeError(f'{stage} job {job} stopped with {state} {exit_code}; no automatic retry')
        time.sleep(timeout(deadline, 60))


def submit(stage, script, deadline):
    check_time(deadline)
    marker = ROOT / 'control' / (stage + '_submission_attempt')
    with marker.open('x') as stream:
        stream.write(datetime.datetime.now(datetime.timezone.utc).isoformat())
    try:
        result = subprocess.run(['sbatch', str(script)], text=True, capture_output=True,
                                timeout=timeout(deadline, 120))
    except subprocess.TimeoutExpired as error:
        (ROOT / 'control' / (stage + '_submission.txt')).write_text(captured(error) + '\nSUBMISSION_TIMEOUT_OUTCOME_UNCERTAIN; NO_RETRY\n')
        raise
    output = result.stdout + result.stderr
    (ROOT / 'control' / (stage + '_submission.txt')).write_text(output)
    ids = re.findall(r'(?m)^Submitted batch job ([0-9]+)$', output)
    if result.returncode or len(ids) != 1:
        raise RuntimeError('Unconfirmed submission; preserve receipts and do not retry: ' + output)
    with (ROOT / 'control' / (stage + '_job_id')).open('x') as stream:
        stream.write(ids[0] + '\n')
    record(stage + '_SUBMITTED', scheduler_job_id=ids[0])
    check_time(deadline)
    return ids[0]


def check_prediction_results(job):
    folder = ROOT / 'diagnostics/matched_runtime_20261009'
    summary = json.loads((folder / 'summary.json').read_text())
    if summary.get('status') != 'PASS' or summary.get('cases') != 12 or summary.get('passed') != 12 or summary.get('tolerance') != 1e-5 or str(summary.get('job_id')) != job:
        raise ValueError('The twelve original-prediction cases did not all pass in the matched runtime job')
    rows = json.loads((folder / 'results.json').read_text())
    expected = {(model, basin) for model in ('original_s100', 'original_s200', 'original_s300')
                for basin in ('01022500', '02108000', '05120500', '09492400')}
    if len(rows) != 12 or {(r['model'], r['basin']) for r in rows} != expected:
        raise ValueError('Wrong matched-runtime case coverage')
    for row in rows:
        difference = row.get('baseline', {}).get('nse_difference', float('nan'))
        if row.get('status') != 'PASS' or row.get('baseline', {}).get('status') != 'PASS' or not math.isfinite(difference) or abs(difference) > 1e-5:
            raise ValueError('Original prediction case did not meet the unchanged tolerance')


def main():
    if ROOT.resolve(strict=True) != ROOT or (ROOT / 'OWNER').read_text().strip() != ROOT.name:
        raise ValueError('Unowned or redirected task directory')
    if CONTROL.resolve(strict=True) != CONTROL:
        raise ValueError('Redirected continuation directory')
    with (CONTROL / 'attempt').open('x') as stream:
        stream.write(datetime.datetime.now(datetime.timezone.utc).isoformat())
    deadline = time.monotonic() + DEADLINE_SECONDS
    try:
        record('WAITING_FOR_APPROVED_DOWNLOAD_AND_RUNTIME_JOB')
        runtime_job = wait_runtime_job(deadline)
        wait_job(runtime_job, 'RUNTIME_VALIDATION', deadline)
        check_prediction_results(runtime_job)
        preflight_job = submit('preflight_' + VERSION, ROOT / 'versions' / VERSION / 'preflight.sbatch', deadline)
        wait_job(preflight_job, 'PREFLIGHT', deadline)
        # The standard-library gate imports no torch on this old login-node OS.
        sys.path.insert(0, str(ROOT / 'control' / ('full_' + VERSION)))
        from verify_preflight import verify
        gate = verify(ROOT, VERSION)
        check_time(deadline)
        record('PREFLIGHT_ASSET_GATE_PASS', gate=gate)
        pilot_job = submit('resource_pilot_' + VERSION, CONTROL / 'resource_pilot.sbatch', deadline)
        wait_job(pilot_job, 'RESOURCE_PILOT', deadline)
        pilot = json.loads((ROOT / 'control' / ('resource_pilot_' + VERSION + '.json')).read_text())
        if pilot.get('status') != 'PASS' or str(pilot.get('scheduler_job_id')) != pilot_job:
            raise ValueError('Resource pilot did not pass in its assigned job')
        check_time(deadline)
        record('FORMAL_SUBMISSION_STARTED', resource_pilot_job=pilot_job)
        try:
            result = subprocess.run([sys.executable, str(ROOT / 'control' / ('full_' + VERSION) / 'submit_full.py')],
                                    text=True, capture_output=True, timeout=timeout(deadline, 600))
        except subprocess.TimeoutExpired as error:
            (CONTROL / 'formal_submission.log').write_text(captured(error) + '\nSUBMISSION_TIMEOUT_OUTCOME_UNCERTAIN; INSPECT_JOBS_JSON; NO_RETRY\n')
            raise
        (CONTROL / 'formal_submission.log').write_text(result.stdout + result.stderr)
        if result.returncode:
            raise RuntimeError('Formal submission did not finish; inspect its saved receipts without resubmitting')
        jobs = json.loads((ROOT / 'control' / ('full_' + VERSION) / 'jobs.json').read_text())
        check_time(deadline)
        record('FORMAL_PIPELINE_SUBMITTED_NOT_SCIENTIFICALLY_COMPLETE', jobs=jobs, resource_pilot=pilot)
    except Exception as error:
        record('STOPPED_WITHOUT_RETRY', error_type=type(error).__name__, reason=str(error))
        raise


if __name__ == '__main__':
    main()
