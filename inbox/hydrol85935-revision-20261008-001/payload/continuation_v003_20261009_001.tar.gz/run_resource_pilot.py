"""Time two prespecified full-calendar records; reuse them in the formal run."""
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001')
VERSION = 'v003'
CODE = ROOT / 'versions' / VERSION / 'code'
sys.path.insert(0, str(CODE))
import torch
from src.adversarial.scripts.revision_20261008.run import cli, runtime


def main():
    assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count() == 1
    output = ROOT / 'control/resource_pilot_v003.json'
    if output.exists():
        raise ValueError('Resource pilot already attempted; do not overwrite evidence')
    args = ['--root', str(ROOT / 'execution' / VERSION), '--data-dir', str(ROOT / 'inputs_v001'),
            '--data-manifest', str(ROOT / 'versions' / VERSION / 'DATA.sha256'),
            '--original-models-root', str(ROOT / 'original_models'), '--device', 'cuda:0', '--chunk', '256']
    rows = []
    failed = False
    for combination in ('original_s100_gaussian_eps0p1_bound_only', 'original_s100_iterative_eps0p1_bound_only'):
        torch.cuda.reset_peak_memory_stats()
        started = time.perf_counter()
        code = cli(args + ['--mode', 'main', '--model-id', 'original_s100', '--basin-start', '0',
                           '--basin-count', '1', '--combination-id', combination])
        torch.cuda.synchronize()
        import resource
        rows.append(dict(combination=combination, exit_code=code, wall_seconds=time.perf_counter()-started,
                         peak_allocated_bytes=torch.cuda.max_memory_allocated(),
                         peak_reserved_bytes=torch.cuda.max_memory_reserved(),
                         max_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024))
        failed = failed or code != 0
        if failed:
            break
    report = dict(status='FAIL' if failed else 'PASS', scheduler_job_id=os.environ['SLURM_JOB_ID'],
                  scope='Two fixed planned records on the first basin; no search or hyperparameter selection',
                  basin='01022500', runtime=runtime(), records=rows)
    with output.open('x') as stream:
        json.dump(report, stream, indent=2)
    print(json.dumps(report), flush=True)
    if failed:
        raise SystemExit(4)


if __name__ == '__main__':
    main()
