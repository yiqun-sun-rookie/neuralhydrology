import hashlib, runpy
from pathlib import Path
p=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/hybrid_v021_20261014_001/worker.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='759f0794204e47b15d66db5a5aac2036879bdd8e8121607b326cde42ed28151a'
runpy.run_path(str(p),run_name='__main__')
