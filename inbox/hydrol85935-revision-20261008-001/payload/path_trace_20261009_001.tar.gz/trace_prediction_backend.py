"""Read-only numerical-path diagnosis; never train, attack or alter acceptance rules."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
import time

BASINS = ("01022500", "02108000", "05120500", "09492400")
MODEL_NAMES = (
    "lstm_cudalstm_maurer_s100_2026_0616_1513_ep30",
    "lstm_cudalstm_maurer_s200_2026_0616_1831_ep30",
    "lstm_cudalstm_maurer_s300_2026_0616_2016_ep30",
)


def file_hash(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def write_json(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--core-root", type=Path, required=True)
    parser.add_argument("--models-root", type=Path, required=True)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--local-trace", type=Path)
    parser.add_argument("--require-compute-allocation", action="store_true")
    args = parser.parse_args()
    if args.require_compute_allocation and not os.environ.get("SLURM_JOB_ID"):
        raise ValueError("Scientific diagnostics require a compute allocation")
    repo, core, models, inputs = [p.resolve(strict=True) for p in
                                  (args.repo, args.core_root, args.models_root, args.inputs)]
    output = args.output.absolute()
    if any(output.resolve().is_relative_to(p) for p in (core, models)) or output.exists():
        raise ValueError("Refuse to overwrite evidence or read-only assets")
    output.mkdir(parents=True, exist_ok=False)
    sys.path.insert(0, str(core))
    import neuralhydrology
    if Path(neuralhydrology.__file__).resolve().parent != core / "neuralhydrology":
        raise ValueError("Imported core identity differs from frozen requested core")
    sys.path.insert(0, str(repo))
    import numpy as np
    import torch
    from src.adversarial.model_wrapper import CudaLSTMWrapper
    from src.adversarial.scripts.revision_20261008.data import array_digest, scaler_fields, validate_config

    if not torch.cuda.is_available() or torch.__version__ != "2.7.1+cu118":
        raise ValueError("This diagnosis requires the aligned torch 2.7.1 CUDA 11.8 runtime")
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.allow_tf32 = True
    torch.backends.cuda.matmul.allow_tf32 = False
    runtime = dict(python=platform.python_version(), platform=platform.platform(), torch=torch.__version__,
                   torch_source=torch.__file__, cuda=torch.version.cuda, cudnn=torch.backends.cudnn.version(),
                   gpu=torch.cuda.get_device_name(0), capability=list(torch.cuda.get_device_capability(0)),
                   job_id=os.environ.get("SLURM_JOB_ID"), core_source=neuralhydrology.__file__,
                   script_sha256=file_hash(__file__), input_npz_sha256=file_hash(inputs),
                   note="Fixed default and deterministic diagnostics; no gate or scientific source changes")
    write_json(output / "runtime.json", runtime)
    with np.load(inputs, allow_pickle=False) as archive:
        reference = {k: archive[k] for k in archive.files}
    local = None
    if args.local_trace:
        with np.load(args.local_trace, allow_pickle=False) as archive:
            local = {k: archive[k] for k in archive.files}
    traces, rows, kernels, comparisons = {}, [], {}, []
    source_hashes = {}
    for name in MODEL_NAMES:
        model_path = models / name
        for path in (model_path / "config.yml", model_path / "model_epoch030.pt",
                     model_path / "train_data/train_data_scaler.yml", model_path / "baseline_epoch030.npz"):
            source_hashes[str(path)] = file_hash(path)
        wrapper = CudaLSTMWrapper(model_path, "cuda:0", epoch=30)
        wrapper.model.requires_grad_(False)
        validate_config(wrapper.cfg, "original")
        seed = wrapper.cfg.seed
        center, scale, q_center, q_scale = scaler_fields(wrapper)
        # All three original models use the same training normalization. Bind it
        # explicitly to the input reference's provenance before reusing tensors.
        provenance = json.loads(inputs.with_suffix(".json").read_text(encoding="utf-8"))
        normalization = provenance["scaler"]
        if not np.array_equal(center, normalization["dynamic_center"]) or not np.array_equal(scale, normalization["dynamic_scale"]):
            raise ValueError("Model scaler differs from exported input reference")
        if q_center != normalization["q_center"] or q_scale != normalization["q_scale"]:
            raise ValueError("Target scaler differs from input reference")
        for feature in wrapper.static_features:
            if float(wrapper.get_scaler()["attribute_means"][feature]) != normalization["attribute_means"][feature] or float(wrapper.get_scaler()["attribute_stds"][feature]) != normalization["attribute_stds"][feature]:
                raise ValueError("Static scaler differs from input reference")
        with np.load(model_path / "baseline_epoch030.npz", allow_pickle=False) as archive:
            baselines = {k: archive[k] for k in archive.files}
        for setting in ("default", "deterministic"):
            torch.backends.cudnn.deterministic = setting == "deterministic"
            for basin in BASINS:
                started = time.perf_counter()
                calendar = torch.tensor(reference[basin + "__calendar"], device="cuda:0")
                static = torch.tensor(reference[basin + "__static"], device="cuda:0")
                observations = reference[basin + "__observations"].astype(np.float64) * q_scale + q_center
                saved = baselines["q_" + basin].astype(np.float64)
                if not np.array_equal(baselines["prediction_dates"].astype("datetime64[D]"), reference[basin + "__prediction_dates"].astype("datetime64[D]")):
                    raise ValueError("Prediction dates differ from fixed input reference")
                values = []
                stage = {}

                def lstm_hook(module, arguments, keywords, result):
                    lstm_input = arguments[0] if arguments else keywords["input"]
                    stage["lstm_input_sha256"] = array_digest(lstm_input)
                    stage["lstm_input_shape"] = list(lstm_input.shape)
                    stage["lstm_input_stride"] = list(lstm_input.stride())
                    traces[setting + "__lstm_last"] = result[0][-1].detach().cpu().numpy()
                    traces[setting + "__hidden"] = result[1][0].detach().cpu().numpy()
                    traces[setting + "__cell"] = result[1][1].detach().cpu().numpy()

                hook = None
                with torch.no_grad():
                    for start in range(0, 3652, 256):
                        stop = min(start + 256, 3652)
                        # Match BasinEngine.predict's zero-addition, strides and chunk.
                        block = calendar[start:stop + 269] + torch.zeros_like(calendar[start:stop + 269])
                        x = block.unfold(0, 270, 1).permute(0, 2, 1)
                        s = static.unsqueeze(0).expand(stop - start, -1)
                        trace_case = seed == 100 and basin == BASINS[0] and start == 0
                        if trace_case:
                            hook = wrapper.model.lstm.register_forward_hook(lstm_hook, with_kwargs=True)
                        p = wrapper(x, s)[:, -1, 0]
                        values.append(p.detach().cpu().numpy())
                        if trace_case:
                            hook.remove()
                            traces[setting + "__prediction"] = p.detach().cpu().numpy()
                            write_json(output / (setting + "_stage.json"), stage)
                            if local is not None:
                                for key in ("lstm_last", "hidden", "cell", "prediction"):
                                    actual = traces[setting + "__" + key]
                                    expected = local[setting + "__" + key]
                                    comparisons.append(dict(setting=setting, stage=key, shape=list(actual.shape),
                                                            exact_equal=bool(np.array_equal(actual, expected)),
                                                            max_absolute_error=float(np.max(np.abs(actual.astype(np.float64) - expected.astype(np.float64)))),
                                                            mean_absolute_error=float(np.mean(np.abs(actual.astype(np.float64) - expected.astype(np.float64))))))
                                local_state = torch.tensor(local[setting + "__lstm_last"], device="cuda:0")
                                replay = wrapper.model.head(local_state)["y_hat"][:, 0].cpu().numpy()
                                comparisons.append(dict(setting=setting, stage="head_replay_on_local_lstm_last",
                                                        max_absolute_error=float(np.max(np.abs(replay.astype(np.float64) - local[setting + "__prediction"].astype(np.float64))))))
                            # Profile a second unchanged first-batch invocation. The
                            # accepted comparison above comes from unprofiled inference.
                            try:
                                with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU, torch.profiler.ProfilerActivity.CUDA]) as profile:
                                    wrapper(x, s)
                                    torch.cuda.synchronize()
                                events = [event for event in profile.events() if "CUDA" in str(event.device_type)]
                                kernels[setting] = sorted(set(event.name for event in events))
                            except Exception as error:
                                kernels[setting] = dict(profiler_error=type(error).__name__ + ": " + str(error))
                normalized_prediction = np.concatenate(values)
                traces[setting + "__s" + str(seed) + "__" + basin + "__prediction_full"] = normalized_prediction
                pred = normalized_prediction.astype(np.float64) * q_scale + q_center
                mask = np.isfinite(observations)
                denominator = np.sum((observations[mask] - observations[mask].mean()) ** 2)
                old = 1 - np.sum((observations[mask] - saved[mask]) ** 2) / denominator
                new = 1 - np.sum((observations[mask] - pred[mask]) ** 2) / denominator
                diff = float(abs(new - old))
                row = dict(model="original_s" + str(seed), basin=basin, setting=setting,
                           nse_difference=diff, passed=diff <= 1e-5, tolerance=1e-5,
                           max_daily_error=float(np.max(np.abs(pred - saved))), seconds=time.perf_counter() - started)
                rows.append(row)
                print(json.dumps(row), flush=True)
    if source_hashes != {path: file_hash(path) for path in source_hashes}:
        raise ValueError("Read-only model assets changed during diagnosis")
    with (output / "traces.npz").open("xb") as stream:
        np.savez_compressed(stream, **traces)
    write_json(output / "kernels.json", kernels)
    write_json(output / "comparisons.json", comparisons)
    write_json(output / "source_hashes.json", source_hashes)
    write_json(output / "results.json", rows)
    summary = dict(status="DIAGNOSTIC_COMPLETE_NOT_SCIENTIFIC_ACCEPTANCE", cases=len(rows),
                   settings={setting: dict(cases=12, passed=sum(r["passed"] for r in rows if r["setting"] == setting))
                             for setting in ("default", "deterministic")},
                   tolerance=1e-5, job_id=os.environ.get("SLURM_JOB_ID"),
                   trace_sha256=file_hash(output / "traces.npz"))
    write_json(output / "summary.json", summary)
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    main()
