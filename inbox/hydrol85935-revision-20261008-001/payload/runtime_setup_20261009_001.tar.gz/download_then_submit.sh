#!/usr/bin/env bash
set -eo pipefail
SETUP=/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/runtime_setup_20261009_001
trap 'rc=$?; printf "%s\n" "$rc" > "$SETUP/supervisor_exit_code"' EXIT
cd "$SETUP"
sha256sum -c SETUP.sha256
/data1/home/sunyiq/miniconda3/envs/nh_final/bin/python -u prepare_isolated_runtime.py --manifest "$SETUP/proposed_runtime_downloads.json" --mode download
test ! -e "$SETUP/submission_attempt"
date -Is > "$SETUP/submission_attempt"
set +e
out=$(sbatch "$SETUP/install_validate.sbatch" 2>&1)
rc=$?
set -e
printf '%s\n' "$out" | tee "$SETUP/submission.txt"
test "$rc" -eq 0 || exit "$rc"
job=$(printf '%s\n' "$out" | sed -n 's/^Submitted batch job \([0-9][0-9]*\)$/\1/p')
test -n "$job" && test "$(printf '%s\n' "$job" | wc -l)" -eq 1
printf '%s\n' "$job" > "$SETUP/job_id"
