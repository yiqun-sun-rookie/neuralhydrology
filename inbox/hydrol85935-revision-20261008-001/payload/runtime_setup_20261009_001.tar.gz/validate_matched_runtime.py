"""Check the approved isolated runtime and twelve original prediction cases."""
import importlib.metadata
import json
import os
from pathlib import Path
import sys

ROOT = Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001')
SITE = ROOT / 'runtime_torch271cu118/site'
CODE = ROOT / 'versions/v002/code'
sys.path.insert(0, str(CODE))
import torch
from packaging.requirements import Requirement
from src.adversarial.scripts.revision_20261008.contracts import Workspace
from src.adversarial.scripts.revision_20261008.data import reference_std
from src.adversarial.scripts.revision_20261008.run import freeze, make_engine, runtime


def main():
    assert os.environ.get('SLURM_JOB_ID'), 'Compute allocation required'
    assert torch.__version__ == '2.7.1+cu118' and torch.version.cuda == '11.8'
    assert Path(torch.__file__).resolve().is_relative_to(SITE)
    assert torch.cuda.is_available() and torch.cuda.device_count() == 1
    torch.set_num_threads(4)
    output = ROOT / 'diagnostics/matched_runtime_20261009'
    output.mkdir(parents=True, exist_ok=False)
    dependencies = []
    for raw in importlib.metadata.requires('torch'):
        requirement = Requirement(raw)
        if requirement.marker and not requirement.marker.evaluate({'extra': ''}):
            continue
        installed = importlib.metadata.version(requirement.name)
        assert installed in requirement.specifier, (raw, installed)
        dependencies.append(dict(name=requirement.name, version=installed))
    info = dict(runtime(), job_id=os.environ['SLURM_JOB_ID'], torch_source=torch.__file__, dependencies=dependencies)
    (output / 'runtime.json').write_text(json.dumps(info, indent=2))
    print(json.dumps(info), flush=True)
    workspace = Workspace(output / 'workspace', ROOT / 'inputs_v001', CODE,
                          ROOT / 'original_models', ROOT / 'versions/v002/DATA.sha256')
    fingerprint = freeze(workspace)
    reference = reference_std(workspace)
    rows = []
    for model in ('original_s100', 'original_s200', 'original_s300'):
        for basin in ('01022500', '02108000', '05120500', '09492400'):
            try:
                engine, identity, baseline = make_engine(workspace, model, basin, 'cuda:0', 256, reference)
                row = dict(model=model, basin=basin, status='PASS', baseline=baseline)
                del engine
            except Exception as error:
                row = dict(model=model, basin=basin, status='FAIL', error=str(error))
            row['manifest_sha256'] = fingerprint
            rows.append(row)
            (output / 'results.json').write_text(json.dumps(rows, indent=2))
            print(json.dumps(row), flush=True)
    passed = len(rows) == 12 and all(row['status'] == 'PASS' for row in rows)
    summary = dict(status='PASS' if passed else 'FAIL', cases=len(rows), passed=sum(r['status'] == 'PASS' for r in rows),
                   tolerance=1e-5, job_id=os.environ['SLURM_JOB_ID'], manifest_sha256=fingerprint)
    (output / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary), flush=True)
    if not passed:
        raise SystemExit(4)


if __name__ == '__main__':
    main()
