"""Explicit download/install steps for a pinned task-local runtime; not executed by preparation."""
import argparse
import hashlib
import json
import os
import platform
import subprocess
import sys
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001')
TARGET = ROOT / 'runtime_torch271cu118'


def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--mode', choices=('download', 'install'), required=True)
    args = parser.parse_args()
    if ROOT.resolve(strict=True) != ROOT or (ROOT / 'OWNER').read_text().strip() != ROOT.name:
        raise ValueError('Unowned or redirected task root')
    manifest = args.manifest.resolve(strict=True)
    if not manifest.is_relative_to(ROOT):
        raise ValueError('Manifest must be deployed within the exclusive task root')
    spec = json.loads(manifest.read_text())
    if spec['target'] != str(TARGET) or spec['packages'] != 14 or sum(x['size_bytes'] for x in spec['files']) != spec['total_bytes'] or spec['total_bytes'] != 2892971578:
        raise ValueError('Download scope differs from the prepared 14-file, 2.893 GB proposal')
    files = spec['files']
    for entry in files:
        url = urllib.parse.urlsplit(entry['url'])
        if url.scheme != 'https' or url.hostname not in {'download.pytorch.org', 'files.pythonhosted.org'}:
            raise ValueError('Unapproved package source')
        if Path(entry['filename']).name != entry['filename'] or not entry['filename'].endswith('.whl') or len(entry['sha256']) != 64:
            raise ValueError('Invalid pinned package path/digest')
    if args.mode == 'download':
        TARGET.mkdir(exist_ok=False)
        wheelhouse = TARGET / 'wheels'
        wheelhouse.mkdir()
        (TARGET / 'REQUEST.json').write_text(json.dumps(spec, indent=2))
        for entry in files:
            final = wheelhouse / entry['filename']
            partial = wheelhouse / (entry['filename'] + '.partial')
            value, size = hashlib.sha256(), 0
            print(json.dumps(dict(filename=entry['filename'], expected_bytes=entry['size_bytes'])), flush=True)
            with urllib.request.urlopen(entry['url'], timeout=60) as response, partial.open('xb') as stream:
                for block in iter(lambda: response.read(1024 * 1024), b''):
                    size += len(block)
                    if size > entry['size_bytes']:
                        raise ValueError('Response exceeded the pinned package size')
                    value.update(block)
                    stream.write(block)
            if size != entry['size_bytes'] or value.hexdigest() != entry['sha256']:
                raise ValueError('Downloaded package size or hash mismatch; partial evidence preserved')
            partial.rename(final)
        (TARGET / 'DOWNLOAD_COMPLETE.json').write_text(json.dumps(dict(status='COMPLETE', manifest_sha256=sha(manifest), files=14, bytes=spec['total_bytes']), indent=2))
        print('PINNED_DOWNLOAD_COMPLETE', flush=True)
        return
    if not os.environ.get('SLURM_JOB_ID') or platform.system() != 'Linux':
        raise ValueError('Install only in an assigned compute job')
    if TARGET.resolve(strict=True) != TARGET:
        raise ValueError('Runtime root redirected')
    completion = json.loads((TARGET / 'DOWNLOAD_COMPLETE.json').read_text())
    if completion['manifest_sha256'] != sha(manifest):
        raise ValueError('Different download inventory')
    site = TARGET / 'site'
    if site.exists():
        raise ValueError('Installation already attempted; no overwrite or automatic repair')
    paths = []
    for entry in files:
        path = TARGET / 'wheels' / entry['filename']
        if path.resolve(strict=True) != path or path.stat().st_size != entry['size_bytes'] or sha(path) != entry['sha256']:
            raise ValueError('Pinned wheel changed before installation')
        paths.append(str(path))
    site.mkdir()
    subprocess.run([sys.executable, '-m', 'pip', 'install', '--no-index', '--no-deps', '--no-compile', '--no-cache-dir', '--disable-pip-version-check', '--target', str(site), *paths], check=True)
    (TARGET / 'INSTALL_COMPLETE.json').write_text(json.dumps(dict(status='INSTALLED_NOT_VALIDATED', manifest_sha256=sha(manifest), site=str(site), scheduler_job_id=os.environ['SLURM_JOB_ID']), indent=2))
    print('ISOLATED_RUNTIME_INSTALLED_NOT_YET_VALIDATED', flush=True)


if __name__ == '__main__':
    main()
