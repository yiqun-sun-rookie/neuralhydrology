import hashlib, runpy
from pathlib import Path
p=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/hybrid_v027_20261014_001/worker.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='7d1fe05a2ca3fe07da989b13edf328441fa7ac4e67a46e8bb8cfdede783478c4'
runpy.run_path(str(p),run_name='__main__')
