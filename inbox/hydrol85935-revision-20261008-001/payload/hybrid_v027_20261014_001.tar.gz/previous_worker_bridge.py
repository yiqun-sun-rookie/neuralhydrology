import hashlib, runpy
from pathlib import Path
p=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/hybrid_v026_20261014_001/worker.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='edfbe72dd36a496391c01199253b30e5313250b112da39e085e47aab96cbf767'
runpy.run_path(str(p),run_name='__main__')
