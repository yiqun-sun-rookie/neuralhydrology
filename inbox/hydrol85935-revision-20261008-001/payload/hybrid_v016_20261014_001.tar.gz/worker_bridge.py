import hashlib, runpy
from pathlib import Path
p=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/hybrid_v016_20261014_001/worker.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='935d158826612f5df64415f1ed831addf4f5e4610ee4f219268dab0106f7e06e'
runpy.run_path(str(p),run_name='__main__')
