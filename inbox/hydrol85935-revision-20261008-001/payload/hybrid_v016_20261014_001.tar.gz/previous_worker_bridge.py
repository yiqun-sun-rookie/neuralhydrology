import hashlib, runpy
from pathlib import Path
p=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/hybrid_v015_20261014_001/worker.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='67000e71a6b50b594d87db71ae10026a22f5a3ffc374d4366f6fadb41c66d8f8'
runpy.run_path(str(p),run_name='__main__')
