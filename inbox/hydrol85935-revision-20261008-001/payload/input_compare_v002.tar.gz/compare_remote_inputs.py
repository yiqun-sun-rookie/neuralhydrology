"""Compare exact prepared inputs and run only original clean predictions for diagnosis."""
import json
import sys
from pathlib import Path
from dataclasses import replace

ROOT = Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001')
CODE = ROOT / 'versions/v002/code'
sys.path.insert(0, str(CODE))
import numpy as np
import torch
from src.adversarial.scripts.revision_20261008.contracts import Workspace
from src.adversarial.scripts.revision_20261008.data import load_model, load_basin, reference_std, scaler_fields, baseline_check, array_digest
from src.adversarial.scripts.revision_20261008.engine import SignalMap, BasinEngine
from src.adversarial.scripts.revision_20261008.run import freeze, runtime

torch.set_num_threads(4)
assert torch.cuda.is_available() and torch.cuda.device_count() == 1
output = ROOT / 'diagnostics/input_compare_v002'
output.mkdir(parents=True, exist_ok=False)
workspace = Workspace(output, ROOT / 'inputs_v001', CODE, ROOT / 'original_models', ROOT / 'versions/v002/DATA.sha256')
freeze(workspace)
reference = reference_std(workspace)
wrapper, identity = load_model(workspace, 'original_s100', 'cuda:0')
center, scale, q_center, q_scale = scaler_fields(wrapper)
mapping = SignalMap(wrapper.dynamic_features, center, scale, reference, .1, 'cuda:0')
source = np.load(ROOT / 'control/input_compare/local_input_reference_s100.npz', allow_pickle=False)
rows = []
for basin in ('01022500', '02108000', '05120500', '09492400'):
    data = load_basin(workspace, wrapper, basin, 'cuda:0')
    fields = {}
    for field in ('calendar', 'static', 'observations', 'calendar_dates', 'prediction_dates'):
        actual = getattr(data, field)
        actual = actual.detach().cpu().numpy() if torch.is_tensor(actual) else np.asarray(actual)
        local = source[basin + '__' + field]
        if field.endswith('dates'):
            actual, local = actual.astype('datetime64[D]'), local.astype('datetime64[D]')
            fields[field] = dict(equal=bool(np.array_equal(actual, local)))
        else:
            diff = actual.astype(float) - local.astype(float)
            fields[field] = dict(equal=bool(np.array_equal(actual, local, equal_nan=True)),
                                 shape=list(actual.shape), remote_dtype=str(actual.dtype), local_dtype=str(local.dtype),
                                 max_abs_difference=float(np.nanmax(np.abs(diff))),
                                 differing_entries=int(np.sum(~(np.equal(actual,local)|(np.isnan(actual)&np.isnan(local))))),
                                 remote_sha256=array_digest(actual), local_sha256=array_digest(local))
    local_data = replace(data, calendar=torch.as_tensor(source[basin+'__calendar'],device='cuda:0'),
                         static=torch.as_tensor(source[basin+'__static'],device='cuda:0'),
                         observations=torch.as_tensor(source[basin+'__observations'],device='cuda:0'))
    row = dict(basin=basin, inputs=fields, predictions=[])
    for name, prepared in [('remote', data), ('local_reference', local_data)]:
        for flag in (True, False):
            torch.backends.cudnn.allow_tf32 = flag
            torch.backends.cuda.matmul.allow_tf32 = False
            engine = BasinEngine(wrapper, prepared, mapping, q_center, q_scale, 256)
            try:
                check=baseline_check(workspace,wrapper,basin,prepared,engine.clean_pred,q_center,q_scale)
                result=dict(status='PASS',baseline=check)
            except Exception as error:
                result=dict(status='FAIL',error=str(error))
            row['predictions'].append(dict(input_source=name,cudnn_allow_tf32=flag,**result))
            del engine
    rows.append(row)
    print(json.dumps(row),flush=True)
(output/'results.json').write_text(json.dumps(dict(runtime=runtime(),rows=rows),indent=2))
print('INPUT_COMPARISON_COMPLETE',flush=True)
for environment in sorted(Path('/data1/home/sunyiq/miniconda3/envs').iterdir()):
    for path in environment.glob('lib/python*/site-packages/torch/version.py'):
        lines = [line.strip() for line in path.read_text().splitlines()
                 if line.startswith(('__version__', 'cuda', 'hip', 'git_version'))]
        print(json.dumps(dict(environment=environment.name, torch_version_file=lines)), flush=True)
