import datetime,hashlib,json,os,subprocess,sys,time,traceback,re
from pathlib import Path
root=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001')
directory=root/'control/migration_gate_v005_20261012_002'
code=root/'versions/v005/code'
data_manifest=root/'versions/v005/DATA.sha256'
job=os.environ['SLURM_JOB_ID']
registry=json.loads((directory/'jobs.json').read_text())
assert registry['probes']=={'ngu002':int(job)}
assert os.environ['SLURMD_NODENAME']=='ngu002' and int(os.environ['SLURM_CPUS_PER_TASK'])==4
sys.path.insert(0,str(code))
import numpy as np
import torch
from src.adversarial.scripts.revision_20261008.contracts import Workspace,SCIENCE
from src.adversarial.scripts.revision_20261008.data import reference_std
from src.adversarial.scripts.revision_20261008.run import freeze,make_engine,runtime,cli
torch.set_num_threads(4)
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
def log(phase,**fields):
    row=dict(phase=phase,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**fields)
    with (directory/'progress.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
    print('MIGRATION_GATE '+json.dumps(row),flush=True)
def run(args):
    result=cli(args)
    if result!=0:raise RuntimeError('Scientific interface stage failed with exit '+str(result))
started=time.perf_counter();phase='runtime'
try:
    assert torch.cuda.is_available() and torch.cuda.device_count()==1
    info=runtime()
    expected=dict(python='3.11.13',torch='2.7.1+cu118',numpy='2.3.3',scipy='1.16.2',cuda_runtime='11.8',cudnn_version=90100,cuda_device='NVIDIA GeForce RTX 3090')
    assert all(info[k]==v for k,v in expected.items())
    assert 'glibc2.34' in info['platform']
    Path(torch.__file__).resolve().relative_to(root/'runtime_torch271cu118/site')
    policy=root/'control/continuation_v004/reproduction_acceptance_amendment.json'
    policy_sha=hashlib.sha256(policy.read_bytes()).hexdigest()
    assert policy_sha=='2325729582c264dae40b226b8c1189196077e7cf2a768f6c715080375d0825ed'
    assert SCIENCE['baseline_nse_tolerance']==1e-4 and SCIENCE['original_baseline_nse_tolerance']==1e-5
    sys.path.insert(0,str(root/'versions/v005'))
    from verify_isolated_runtime import verify_evidence,compute_identity
    evidence,diagnostic_runtime,diagnostic_frozen=verify_evidence(root)
    current_identity=compute_identity(root,code,evidence,diagnostic_runtime,diagnostic_frozen)
    (root/'preflight/v005').mkdir(parents=True,exist_ok=True)
    save(root/'preflight/v005/isolated_runtime.json',current_identity)
    save(directory/'runtime.json',dict(runtime=info,job_id=job,acceptance_amendment_sha256=policy_sha))
    log('RUNTIME_PASS',runtime=info)
    phase='code_tests'
    test=subprocess.run([sys.executable,'-m','unittest','discover','-s','test/test_adversarial','-p','test_revision_20261008*.py','-v'],cwd=code,capture_output=True)
    (directory/'code_tests.stdout').write_bytes(test.stdout);(directory/'code_tests.stderr').write_bytes(test.stderr)
    match=re.search(rb'Ran ([0-9]+) tests?',test.stderr)
    if test.returncode or not match or int(match.group(1))!=31:raise RuntimeError('Thirty-one frozen code tests were not confirmed')
    log('CODE_TESTS_PASS',tests=31)
    phase='original_predictions'
    workspace=Workspace(root/'preflight/v005_original_cases',root/'inputs_v001',code,root/'original_models',data_manifest)
    fingerprint=freeze(workspace);reference=reference_std(workspace);rows=[]
    for model in ('original_s100','original_s200','original_s300'):
        for basin in ('01022500','02108000','05120500','09492400'):
            try:
                engine,identity,baseline=make_engine(workspace,model,basin,'cuda:0',256,reference)
                difference=baseline['nse_difference']
                if not np.isfinite(difference) or difference>1e-4 or len(engine.data.prediction_dates)!=3652:raise ValueError('Original prediction acceptance failed')
                row=dict(model=model,basin=basin,status='PASS',baseline=baseline,manifest_sha256=fingerprint)
                del engine
            except Exception as error:row=dict(model=model,basin=basin,status='FAIL',reason=type(error).__name__+': '+str(error))
            rows.append(row);log('ORIGINAL_CASE',**row)
    save(directory/'original_cases.json',rows)
    if len(rows)!=12 or any(row['status']!='PASS' for row in rows):raise RuntimeError('Fresh twelve-case original prediction acceptance failed')
    strict=sum(row['baseline']['nse_difference']<=1e-5 for row in rows)
    log('ORIGINAL_PREDICTIONS_PASS',accepted=12,strict_original_passed=strict,accepted_tolerance=1e-4,original_strict_tolerance=1e-5)
    phase='training_interface'
    common=['--data-dir',str(root/'inputs_v001'),'--data-manifest',str(data_manifest),'--original-models-root',str(root/'original_models'),'--device','cuda:0','--chunk','256']
    run(['--root',str(root/'preflight/v005')]+common+['--mode','preflight','--preflight-windows','256','--training-smoke'])
    report=json.loads((root/'preflight/v005/preflight/original_s100_01022500/report.json').read_text())
    assert report['status']=='PASS' and report['single_batch_training_smoke']['status']=='PASS' and report['single_batch_training_smoke']['optimizer_updates']==1
    sys.path.insert(0,str(directory))
    from verify_migration_artifacts import verify,resource_layout
    asset_acceptance=verify(root,'v005',scheduler=False)
    assert asset_acceptance['status']=='PASS' and asset_acceptance['verified_input_files']==1069
    log('TRAINING_INTERFACE_PASS',optimizer_updates=1)
    phase='prepare_plan'
    run(['--root',str(root/'execution/v005')]+common+['--mode','plan'])
    phase='resource_pilot';timings=[]
    for combination in ('original_s100_gaussian_eps0p1_bound_only','original_s100_iterative_eps0p1_bound_only'):
        torch.cuda.reset_peak_memory_stats();begin=time.perf_counter()
        run(['--root',str(root/'execution/v005')]+common+['--mode','main','--model-id','original_s100','--basin-start','0','--basin-count','1','--combination-id',combination])
        torch.cuda.synchronize();import resource
        timings.append(dict(combination=combination,exit_code=0,wall_seconds=time.perf_counter()-begin,peak_allocated_bytes=torch.cuda.max_memory_allocated(),peak_reserved_bytes=torch.cuda.max_memory_reserved(),max_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024))
    resource_report=dict(status='PASS',scheduler_job_id=job,scope='Two fixed planned full-calendar records on the first basin; no selection',basin='01022500',runtime=runtime(),records=timings)
    save(root/'control/resource_pilot_v005.json',resource_report)
    assert all(np.isfinite(row['wall_seconds']) and row['wall_seconds']>0 for row in timings)
    layout=resource_layout(root,'v005',scheduler=False)
    save(directory/'resource_layout.json',layout)
    value=dict(status='PASS',execution_version='v005',scheduler_job_id=job,node='ngu002',accepted_original_cases=12,strict_original_cases_passed=strict,code_tests=31,training_interface_updates=1,resource_records=2,accepted_tolerance=1e-4,original_strict_tolerance=1e-5,acceptance_amendment_sha256=policy_sha,runtime=runtime(),wall_seconds=time.perf_counter()-started,formal_training_started=False,formal_migration_performed=False,maximum_simultaneous_gpus=1,maximum_simultaneous_cpu_cores=4)
    save(root/'control/migration_gate_v005.json',value);log('ALL_GATES_PASS',**value)
except Exception as error:
    value=dict(status='FAIL',phase=phase,job_id=job,reason=type(error).__name__+': '+str(error),traceback=traceback.format_exc(),wall_seconds=time.perf_counter()-started)
    save(directory/'failure.json',value);log('GATE_FAILED',**value);raise
