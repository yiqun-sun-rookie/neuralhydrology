"""Read-only final asset and completed-preflight gate; uses only the standard library."""
import argparse
import hashlib
import json
import math
import subprocess
from pathlib import Path

from verify_isolated_runtime import verify_evidence, verify_reference
from verify_isolated_runtime import scheduler_completed


def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def checked(root, relative, expected):
    path = (root / relative).resolve(strict=True)
    if not path.is_relative_to(root.resolve()) or sha(path) != expected:
        raise ValueError('Changed or escaping frozen asset: ' + str(relative))


def manifest_files(root, path):
    count = 0
    seen = set()
    for line in path.read_text(encoding='utf-8-sig').splitlines():
        if not line.strip():
            continue
        expected, relative = line.split(None, 1)
        relative = relative.lstrip('*')
        if relative in seen:
            raise ValueError('Duplicate manifest path')
        checked(root, relative, expected)
        seen.add(relative)
        count += 1
    return count


def verify(root, version, scheduler=True):
    root = root.resolve(strict=True)
    if root.name != 'hydrol85935_revision_20261008_001' or (root / 'OWNER').read_text().strip() != root.name:
        raise ValueError('Wrong task ownership')
    # This imports only the standard library on login nodes. Even when the
    # already-gated preflight scheduler query is skipped within a formal task,
    # the explicitly accepted historical numerical-drift failure must retain its original identity.
    runtime_evidence, _, diagnostic_frozen = verify_evidence(root)
    runtime_reference = verify_reference(root, version, runtime_evidence)
    job = (root / 'control' / ('preflight_' + version + '_job_id')).read_text().strip()
    if not job.isdigit():
        raise ValueError('Invalid preflight job id')
    if scheduler:
        result = subprocess.run(['sacct', '-j', job, '-n', '-P', '--format=JobIDRaw,State,ExitCode'],
                                check=True, text=True, capture_output=True, timeout=60)
        matches = [line.strip().split('|') for line in result.stdout.splitlines() if line.strip().split('|')[0] == job]
        if len(matches) != 1 or matches[0][1:3] != ['COMPLETED', '0:0']:
            raise ValueError('Preflight scheduler job has not completed successfully: ' + result.stdout)
    folder = root / 'versions' / version
    manifest_files(folder, folder / 'CODE.sha256')
    frozen = json.loads((root / 'preflight' / version / 'frozen/manifest.json').read_text())
    report = json.loads((root / 'preflight' / version / 'preflight/original_s100_01022500/report.json').read_text())
    if report.get('status') != 'PASS' or report.get('manifest_sha256') != digest(frozen):
        raise ValueError('Preflight report/frozen manifest identity mismatch')
    if frozen.get('runtime') != runtime_reference['runtime']:
        raise ValueError('Scientific preflight used a different runtime from its isolated-runtime receipt')
    if {k: v for k, v in report.get('runtime', {}).items() if k != 'cuda_visible_devices'} != frozen['runtime']:
        raise ValueError('Preflight report runtime differs from the exact frozen runtime')
    if frozen['original_assets'] != diagnostic_frozen['original_assets']:
        raise ValueError('Original models changed since twelve-case runtime validation')
    if (report.get('model_id'), report.get('basin_id'), report.get('chunk'), report.get('full_prediction_count'),
        report.get('full_calendar_count')) != ('original_s100', '01022500', 256, 3652, 3921):
        raise ValueError('Wrong original-baseline preflight scope')
    baseline = report.get('baseline', {})
    difference = baseline.get('nse_difference', float('nan'))
    if baseline.get('status') != 'PASS' or not math.isfinite(difference) or difference > 1e-4:
        raise ValueError('Original-model reproduction did not pass')
    smoke = report.get('single_batch_training_smoke', {})
    if smoke.get('status') != 'PASS' or smoke.get('optimizer_updates') != 1 or smoke.get('batch_size') != 256 or smoke.get('weights_saved') is not False or smoke.get('features') != ['PRCP(mm/day)', 'Tmin(C)', 'SRAD(W/m2)', 'Vp(Pa)']:
        raise ValueError('Required four-feature training interface check is missing')
    code = folder / 'code'
    for relative, expected in frozen['source_sha256'].items():
        checked(code, relative, expected)
    contract = code / 'draft/papers/05_adversarial_latex/revision_HYDROL85935_20261006/parallel_tasks_20261008/experiment_preparation'
    for relative, expected in frozen['contract_sha256'].items():
        checked(contract, relative, expected)
    checked(code, 'src/xaj_global_pilot/configs/conceptual_benchmark_camels_us_531_repro.txt', frozen['basin_list_sha256'])
    for original in frozen['original_assets'].values():
        model = root / 'original_models' / original['directory']
        for item in original['files'].values():
            checked(model, item['relative_path'], item['sha256'])
    data = root / 'inputs_v001'
    data_manifest = folder / 'DATA.sha256'
    expected_identity = dict(data_dir=str(data), manifest=dict(path=str(data_manifest), sha256=sha(data_manifest), verified_files=1069))
    if frozen['data_identity'] != expected_identity or sha(data / 'DATA.sha256') != sha(data_manifest):
        raise ValueError('Preflight input inventory identity changed')
    if manifest_files(data, data_manifest) != 1069:
        raise ValueError('Expected 1069 input files')
    return dict(status='PASS', preflight_job_id=int(job), version=version, manifest_sha256=digest(frozen),
                code_manifest_sha256=sha(folder / 'CODE.sha256'), verified_input_files=1069,
                runtime_identity_sha256=digest(runtime_evidence), runtime_install_job_id=runtime_evidence['install_job_id'],
                runtime_validation_job_id=runtime_evidence['validation_job_id'], runtime_cases=12, runtime_accepted=12, runtime_original_strict_passed=3,
                acceptance_amendment_sha256=runtime_evidence["acceptance_amendment_sha256"])


def resource_layout(root, version, scheduler=True):
    """Choose execution chunks from two complete records, without scientific imports."""
    path = root / 'control' / ('resource_pilot_' + version + '.json')
    pilot = json.loads(path.read_text())
    if pilot.get('status') != 'PASS' or pilot.get('basin') != '01022500' or len(pilot.get('records', [])) != 2:
        raise ValueError('Both prespecified full-record resource checks must pass before submission')
    if scheduler:
        scheduler_completed(pilot.get('scheduler_job_id', ''))
    elif str(pilot.get('scheduler_job_id', '')) != __import__('os').environ.get('SLURM_JOB_ID'):
        raise ValueError('Only the current compute job may defer its own scheduler completion check')
    frozen = json.loads((root / 'execution' / version / 'frozen/manifest.json').read_text())
    preflight = json.loads((root / 'preflight' / version / 'frozen/manifest.json').read_text())
    if frozen != preflight or {k: v for k, v in pilot.get('runtime', {}).items() if k != 'cuda_visible_devices'} != frozen['runtime']:
        raise ValueError('Resource timing used a different frozen scientific/runtime identity')
    expected = {'original_s100_gaussian_eps0p1_bound_only': 'gaussian', 'original_s100_iterative_eps0p1_bound_only': 'iterative'}
    rows = {r['combination']: r for r in pilot['records']}
    if set(rows) != set(expected):
        raise ValueError('Resource pilot contains wrong or duplicated combinations')
    record_hashes = {}
    for combination, method in expected.items():
        row = rows[combination]
        duration = row.get('wall_seconds', float('nan'))
        if (row.get('exit_code') != 0 or not isinstance(duration, (int, float)) or not math.isfinite(duration) or duration <= 0
                or any(not isinstance(row.get(k), (int, float)) or not math.isfinite(row[k]) or row[k] <= 0
                       for k in ('peak_allocated_bytes', 'peak_reserved_bytes', 'max_rss_bytes'))):
            raise ValueError('Missing or invalid full-record timing/resource result')
        directory = root / 'execution' / version / 'records/attacks' / combination / '01022500'
        marker = json.loads((directory / 'complete.json').read_text())
        metadata = json.loads((directory / 'metadata.json').read_text())
        arrays_hash, metadata_hash = sha(directory / 'arrays.npz'), sha(directory / 'metadata.json')
        identity = metadata['identity']
        c = identity['combination']
        if (marker.get('status') != 'complete' or marker.get('kind') != 'attack' or metadata.get('kind') != 'attack'
                or marker.get('metadata_sha256') != metadata_hash or marker.get('arrays_sha256') != arrays_hash
                or metadata.get('arrays_sha256') != arrays_hash or marker.get('record_id') != digest(identity)
                or metadata.get('record_id') != marker['record_id'] or identity.get('manifest_sha256') != digest(frozen)
                or identity.get('basin_id') != '01022500' or c.get('id') != combination or c.get('method') != method
                or c.get('model_id') != 'original_s100' or c.get('condition') != 'bound_only' or c.get('epsilon') != .1
                or c.get('target') != 'whole_period' or c.get('initialization') != 'random' or c.get('location') != 'whole_calendar'):
            raise ValueError('Resource timing is not backed by a current complete planned record')
        clean = root / 'execution' / version / 'records/clean/original_s100/01022500'
        clean_marker = json.loads((clean / 'complete.json').read_text())
        clean_metadata = json.loads((clean / 'metadata.json').read_text())
        if (clean_marker.get('status') != 'complete' or clean_marker.get('kind') != 'clean'
                or clean_marker.get('metadata_sha256') != sha(clean / 'metadata.json')
                or clean_marker.get('arrays_sha256') != sha(clean / 'arrays.npz')
                or clean_metadata.get('record_id') != digest(clean_metadata['identity'])
                or identity.get('clean_record_id') != clean_metadata['record_id']
                or clean_metadata['identity'].get('manifest_sha256') != digest(frozen)
                or clean_metadata['identity'].get('basin_id') != '01022500'):
            raise ValueError('Resource record has no matching current complete clean reference')
        details = metadata['details']
        if method == 'gaussian' and len(details.get('candidates', [])) != 101:
            raise ValueError('Gaussian resource record did not cover one hundred candidates and clean')
        if method == 'iterative' and (len(details.get('trajectory', [])) != 51
                or set(details.get('importance', {}).get('raw_importance', {})) != {'precipitation', 'temperature_mean', 'shortwave_radiation', 'vapor_pressure'}):
            raise ValueError('Iterative resource record lacks fifty updates or four-signal restoration')
        record_hashes[combination] = dict(record_id=marker['record_id'], metadata_sha256=metadata_hash, arrays_sha256=arrays_hash)
    gaussian = rows['original_s100_gaussian_eps0p1_bound_only']['wall_seconds']
    iterative = rows['original_s100_iterative_eps0p1_bound_only']['wall_seconds']
    per_basin = 3 * gaussian + 6 * iterative + 2 * iterative / 50
    chunk = next((c for c in (25, 10, 5) if c * per_basin * 2 <= 6 * 3600), None)
    if chunk is None:
        raise ValueError('Even five basins exceed the six-hour resource estimate with twofold allowance; no submission')
    blocks = math.ceil(531 / chunk)
    return dict(chunk_size=chunk, blocks_per_model=blocks, attack_array_tasks=6 * blocks, attack_array_max=6 * blocks - 1,
                estimated_seconds_per_basin=per_basin, allowance_factor=2, estimated_chunk_seconds=chunk * per_basin * 2,
                wall_limit_seconds=21600, gaussian_seconds=gaussian, iterative_seconds=iterative,
                formula='3*tGaussian + 6*tIterative + 2*tIterative/50; execution estimate, not a wall-time guarantee',
                resource_pilot_sha256=sha(path), scheduler_job_id=str(pilot['scheduler_job_id']), complete_records=record_hashes)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', required=True, type=Path)
    parser.add_argument('--version', required=True)
    parser.add_argument('--skip-scheduler', action='store_true', help='Only within already-gated formal jobs')
    args = parser.parse_args()
    print(json.dumps(verify(args.root, args.version, scheduler=not args.skip_scheduler)))
