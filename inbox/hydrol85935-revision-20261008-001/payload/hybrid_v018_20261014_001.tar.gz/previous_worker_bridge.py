import hashlib, runpy
from pathlib import Path
p=Path('/data1/home/sunyiq/hydrol85935_revision_20261008_001/control/hybrid_v017_20261014_001/worker.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='140b0b73b9c160a4c43590bea2a37bfeb4728edd816060ba5a49cc98aee8213c'
runpy.run_path(str(p),run_name='__main__')
