from dataclasses import replace
from datetime import date
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest
import torch

from precip_input_assimilation.selfrule.data import read_maurer_forcing
from precip_input_assimilation.selfrule.fit import fit_flow_history, fit_rain_rule, predict_flow_history
from precip_input_assimilation.selfrule.flow_data import read_flow_slice
from precip_input_assimilation.selfrule.manifest import claim_task, validate_stage_request
from precip_input_assimilation.selfrule.pipeline import (_cluster_bootstrap_median, _delta_summary, _load_huc2,
                                                         _low_snow_fraction, _nse_from_reference, _score_quality,
                                                         sha256_file, verify_frozen)
from precip_input_assimilation.selfrule.protocol import load_protocol, validate_protocol
from precip_input_assimilation.selfrule.rules import (apply_rule_numpy, apply_rule_torch, build_rain_rule,
                                                      parameter_index_by_day)
from precip_input_assimilation.selfrule.witness import (_period_row, nonoverlapping_three_day_mae,
                                                        precipitation_metrics, read_product_precipitation)


def _write_forcing(root: Path, basin: str) -> None:
    path = root / "basin_mean_forcing" / "maurer" / "01" / f"{basin}_lump_maurer_forcing_leap.txt"
    path.parent.mkdir(parents=True)
    path.write_text(
        " 1\n 2\n 1000000\n"
        "Year Mnth Day Hr Dayl(s) PRCP(mm/day) SRAD(W/m2) SWE(mm) Tmax(C) Tmin(C) Vp(Pa)\n"
        "1980 01 01 12 1 2 3 0 4 5 6\n"
        "1980 01 02 12 1 7 8 0 9 10 11\n"
        "1980 01 03 12 forbidden values are not parsed\n",
        encoding="utf-8",
    )


def test_forcing_reader_stops_before_forbidden_values(tmp_path: Path):
    _write_forcing(tmp_path, "00000001")
    result = read_maurer_forcing(tmp_path, "00000001", date(1980, 1, 1), date(1980, 1, 2))
    assert result.values.tolist() == [[2.0, 5.0, 4.0, 3.0, 6.0], [7.0, 10.0, 9.0, 8.0, 11.0]]


def test_flow_reader_parses_values_only_inside_allowed_interval(tmp_path: Path):
    basin = "00000001"
    path = tmp_path / "usgs_streamflow" / "01" / f"{basin}_streamflow_qc.txt"
    path.parent.mkdir(parents=True)
    path.write_text(
        f"{basin} 1979 12 31 SECRET A\n"
        f"{basin} 1980 01 01 1.0 A\n"
        f"{basin} 1980 01 02 -999.0 M\n"
        f"{basin} 1980 01 03 SECRET A\n",
        encoding="utf-8",
    )
    result = read_flow_slice(tmp_path, basin, 1_000_000, date(1980, 1, 1), date(1980, 1, 2))
    assert np.isfinite(result.values_mm_day[0])
    assert np.isnan(result.values_mm_day[1])
    assert result.missing_count == 1
    assert len(result.canonical_sha256) == 64


def test_rain_rule_keeps_dry_days_fixed_and_backpropagates_on_wet_days():
    dates = np.arange(np.datetime64("1980-01-01"), np.datetime64("1981-01-01"), dtype="datetime64[D]")
    rain = np.tile(np.asarray([0.0, 0.2, 2.0, 20.0]), len(dates) // 4 + 1)[:len(dates)]
    effective = np.ones(len(dates), dtype=bool)
    rule = build_rain_rule("rain_intensity", dates, rain, date(1980, 1, 1), date(1980, 12, 31), effective)
    indices = parameter_index_by_day(rule, dates, rain)
    assert np.all(indices[rain < 0.1] == -1)
    theta = torch.zeros(rule.n_parameters, requires_grad=True)
    output = apply_rule_torch(torch.tensor(rain, dtype=torch.float32), torch.tensor(indices), theta)
    output.sum().backward()
    assert theta.grad is not None and torch.isfinite(theta.grad).all() and torch.any(theta.grad != 0)
    changed = apply_rule_numpy(rain, indices, np.full(rule.n_parameters, np.log(2.0)))
    assert np.array_equal(changed[rain < 0.1], rain[rain < 0.1])


def test_flow_history_reference_recovers_expressible_residual():
    dates = np.arange(np.datetime64("1980-01-01"), np.datetime64("1984-01-01"), dtype="datetime64[D]")
    rain = 2.0 + np.sin(np.arange(len(dates)) / 11.0)
    fit_targets = np.arange(269, 1000)
    select_targets = np.arange(1000, len(dates))
    original_fit = 1.0 + 0.1 * np.sin(fit_targets / 7.0)
    original_select = 1.0 + 0.1 * np.sin(select_targets / 7.0)
    observed_fit = original_fit + 0.3
    observed_select = original_select + 0.3
    result = fit_flow_history(dates, rain, fit_targets, original_fit, observed_fit,
                              select_targets, original_select, observed_select, (0.0, 0.1))
    prediction = predict_flow_history(result, dates, rain, select_targets, original_select)
    assert result.complete
    assert np.max(np.abs(prediction - observed_select)) < 1e-9


def test_selfrule_source_does_not_import_frozen_assimilation_modules():
    root = Path(__file__).resolve().parents[1] / "selfrule"
    text = "\n".join(path.read_text(encoding="utf-8") for path in root.glob("*.py"))
    assert "neuralhydrology.evaluation" not in text
    assert "assimilationconfig" not in text.lower()


def test_prediction_module_has_no_discharge_reader_import():
    import os
    import subprocess
    import sys

    code = ("import sys; import precip_input_assimilation.selfrule.predict; "
            "raise SystemExit(int('precip_input_assimilation.selfrule.flow_data' in sys.modules))")
    env = os.environ.copy()
    env["PYTHONPATH"] = str(Path(__file__).resolve().parents[2])
    completed = subprocess.run([sys.executable, "-c", code], check=False, env=env)
    assert completed.returncode == 0


def test_protocol_rejects_any_date_drift():
    root = Path(__file__).resolve().parents[3]
    protocol = load_protocol(root / "src/precip_input_assimilation/configs/selfrule_time_v05.yml", repo_root=root)
    changed = replace(protocol, score_end=date(1989, 10, 1))
    try:
        validate_protocol(changed, verify_files=False)
    except ValueError as exc:
        assert "score_end" in str(exc)
    else:
        raise AssertionError("Date drift was accepted")


def test_technical_mode_rejects_prediction_and_duplicate_basins():
    root = Path(__file__).resolve().parents[3]
    protocol = load_protocol(root / "src/precip_input_assimilation/configs/selfrule_time_v05.yml", repo_root=root)
    basin = "02137727"
    for stage, basins in (("predict", [basin]), ("witness", [basin]), ("fit", [basin, basin])):
        try:
            validate_stage_request(protocol, stage, basins, technical=True)
        except ValueError:
            pass
        else:
            raise AssertionError(f"Invalid technical request was accepted: {stage}, {basins}")


def test_atomic_task_claim_cannot_be_taken_twice(tmp_path: Path):
    path = tmp_path / "locks" / "fit-00000001.lock"
    claim_task(path, {"stage": "fit", "basin": "00000001"})
    try:
        claim_task(path, {"stage": "fit", "basin": "00000001"})
    except FileExistsError:
        pass
    else:
        raise AssertionError("Duplicate task claim was accepted")


class _NonFiniteRunner:
    device = torch.device("cpu")
    precipitation_index = 0

    def predict_candidates(self, raw_dynamic, static, target_indices, parameter_indices, theta):
        output = theta[:, :1].expand(-1, len(target_indices)) * 0
        return torch.cat((output[:1], torch.full_like(output[1:], float("nan"))), dim=0)


def test_nonfinite_candidate_makes_the_whole_search_incomplete():
    dates = np.arange(np.datetime64("1980-01-01"), np.datetime64("1981-01-01"), dtype="datetime64[D]")
    rain = np.full(len(dates), 2.0, dtype=np.float32)
    rule = build_rain_rule("rain_season", dates, rain, date(1980, 1, 1), date(1980, 12, 31),
                           np.ones(len(dates), dtype=bool))
    raw = torch.as_tensor(rain[:, None])
    targets = np.arange(20, 40)
    observed = np.linspace(0.0, 1.0, len(targets))
    result = fit_rain_rule(_NonFiniteRunner(), raw, dates, torch.zeros(1), rule, targets,
                           observed, targets, observed, (0.0, 0.1), (0.0,), 0.01,
                           2, 1, 8, np.log(0.5), np.log(2.0))
    assert not result.complete
    assert "non-finite" in result.reason
    assert all(record["best_selection_mse"] is None for record in result.candidate_records)


def test_low_snow_fraction_uses_only_fitting_period_precipitation():
    dates = np.arange(np.datetime64("1980-09-30"), np.datetime64("1980-10-04"), dtype="datetime64[D]")
    names = ("PRCP(mm/day)", "Tmin(C)", "Tmax(C)")
    values = np.asarray([
        [100.0, -5.0, -1.0],  # outside the fitting interval
        [2.0, -2.0, 0.0],
        [6.0, 2.0, 4.0],
        [2.0, -4.0, -2.0],
    ])
    fraction = _low_snow_fraction(dates, values, names, date(1980, 10, 1), date(1980, 10, 3))
    assert fraction == 0.4


def test_cluster_bootstrap_resamples_whole_groups_deterministically():
    values = np.asarray([1.0, 2.0, 10.0, 20.0])
    groups = np.asarray(["01", "01", "02", "02"])
    first = _cluster_bootstrap_median(values, groups, seed=7, repetitions=200)
    second = _cluster_bootstrap_median(values, groups, seed=7, repetitions=200)
    assert first == second
    assert len(first) == 2 and first[0] <= np.median(values) <= first[1]


def test_nse_recovery_uses_the_same_observation_variance():
    # Reference MSE 2 at NSE 0.5 implies an observation variance of 4.
    assert _nse_from_reference(0.5, 2.0, 1.0) == 0.75


def test_empty_delta_summary_is_strict_json_compatible():
    payload = _delta_summary([])
    assert payload["median"] is None
    assert payload["count"] == 0


def test_score_quality_rejects_one_constant_water_year():
    observed = np.asarray([1.0, 2.0, 3.0, 3.0])
    common = np.ones(4, dtype=bool)
    labels = np.asarray(["1985-1986", "1985-1986", "1986-1987", "1986-1987"])
    coverage, variance, overall, valid = _score_quality(observed, common, labels)
    assert coverage == {"1985-1986": 1.0, "1986-1987": 1.0}
    assert variance["1986-1987"] == 0.0
    assert overall is not None and overall > 0
    assert not valid


def test_frozen_verification_rejects_an_empty_file_inventory(tmp_path: Path, monkeypatch):
    basins = [f"{index:08d}" for index in range(96)]
    basin_file = tmp_path / "basins.txt"
    basin_file.write_text("\n".join(basins) + "\n", encoding="utf-8")
    required = tmp_path / "required.txt"
    required.write_text("bound", encoding="utf-8")
    protocol = SimpleNamespace(output_dir=tmp_path, basin_file=basin_file,
                               score_start=date(1985, 10, 1), score_end=date(1989, 9, 30))
    (tmp_path / "FROZEN.json").write_text(json.dumps({
        "protocol": "selfrule_time_v05",
        "score_period": ["1985-10-01", "1989-09-30"],
        "basins": basins,
        "files": [],
    }), encoding="utf-8")
    monkeypatch.setattr("precip_input_assimilation.selfrule.pipeline._manifest_files",
                        lambda _protocol, _basins: [required])
    with pytest.raises(RuntimeError, match="inventory"):
        verify_frozen(protocol)
    valid = {
        "protocol": "selfrule_time_v05",
        "score_period": ["1985-10-01", "1989-09-30"],
        "basins": basins,
        "files": [{"path": str(required.resolve()), "sha256": sha256_file(required),
                   "bytes": required.stat().st_size}],
    }
    (tmp_path / "FROZEN.json").write_text(json.dumps(valid), encoding="utf-8")
    assert verify_frozen(protocol) == valid


def test_huc2_mapping_requires_every_requested_basin_once(tmp_path: Path):
    root = tmp_path / "camels_attributes_v2.0"
    root.mkdir(parents=True)
    (root / "camels_name.txt").write_text(
        "gauge_id;huc_02\n00000001;1\n00000001;1\n",
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="Duplicate"):
        _load_huc2(SimpleNamespace(data_dir=tmp_path), ["00000001"])


def test_witness_reader_stops_before_disallowed_value(tmp_path: Path):
    basin = "00000001"
    path = tmp_path / "basin_mean_forcing" / "daymet" / "01" / f"{basin}_lump_cida_forcing_leap.txt"
    path.parent.mkdir(parents=True)
    path.write_text(
        "1\n2\n1000000\n"
        "Year Mnth Day Hr dayl(s) prcp(mm/day) srad(W/m2)\n"
        "1985 10 01 12 1 2.5 3\n"
        "1985 10 02 12 1 4.5 3\n"
        "1985 10 03 12 1 FORBIDDEN 3\n",
        encoding="utf-8",
    )
    result = read_product_precipitation(tmp_path, "daymet", basin, date(1985, 10, 1), date(1985, 10, 2))
    assert result.values_mm_day.tolist() == [2.5, 4.5]
    assert len(result.canonical_sha256) == 64


def test_witness_metrics_keep_daily_and_nonoverlapping_block_definitions_separate():
    values = np.asarray([0.0, 0.5, 1.0, 2.0, 3.0, 4.0])
    metrics = precipitation_metrics(values)
    assert metrics["drizzle_fraction_0_1_to_1_mm"] == 1 / 6
    mae, blocks = nonoverlapping_three_day_mae(values, np.zeros_like(values))
    assert blocks == 2
    assert mae == 5.25


def test_three_day_blocks_restart_at_each_water_year_without_dropping_daily_metrics():
    original = np.arange(9, dtype=np.float64)
    adjusted = original.copy()
    witness = np.zeros(9, dtype=np.float64)
    groups = [(original[:4], adjusted[:4], witness[:4]),
              (original[4:], adjusted[4:], witness[4:])]
    row = _period_row("00000001", "daymet", "all", original, adjusted, witness, block_groups=groups)
    assert row["days"] == 9
    assert row["three_day_blocks"] == 2
    assert row["total_mm_original"] == float(original.sum())
