"""Run the four strictly separated stages of the self-correction experiment."""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import replace
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO_ROOT / "src"))

from precip_input_assimilation.selfrule.data import read_basin_list  # noqa: E402
from precip_input_assimilation.selfrule.protocol import load_protocol  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("prepare", "fit", "predict", "freeze", "score", "witness"))
    parser.add_argument("--protocol", type=Path,
                        default=REPO_ROOT / "src/precip_input_assimilation/configs/selfrule_time_v05.yml")
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--data-dir", type=Path)
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--basin-file", type=Path)
    parser.add_argument("--basin", action="append", default=[])
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--technical", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    protocol = load_protocol(args.protocol, output_dir=args.output_dir, repo_root=REPO_ROOT)
    updates = {}
    for key in ("data_dir", "run_dir"):
        value = getattr(args, key)
        if value is not None:
            updates[key] = value.resolve()
    if updates:
        protocol = replace(protocol, **updates)
    basin_file = args.basin_file.resolve() if args.basin_file else (
        protocol.technical_basin_file if args.technical else protocol.basin_file)
    basins = args.basin or read_basin_list(basin_file)
    from precip_input_assimilation.selfrule.manifest import validate_stage_request
    validate_stage_request(protocol, args.stage, basins, args.technical)
    if args.stage == "prepare":
        from precip_input_assimilation.selfrule.manifest import prepare_run_manifest
        manifest = prepare_run_manifest(protocol, basins, args.technical, args.device)
        result = {
            "stage": "prepare",
            "scope": manifest["scope"],
            "manifest": str(protocol.output_dir / "RUN_MANIFEST.json"),
            "allowed_basins": len(manifest["allowed_basins"]),
            "source_files": len(manifest["source_files"]),
            "frozen_inputs": len(manifest["frozen_inputs"]),
            "intended_device": manifest["intended_device"],
        }
    elif args.stage == "fit":
        from precip_input_assimilation.selfrule.pipeline import fit_stage
        result = fit_stage(protocol, basins, args.device, technical=args.technical)
    elif args.stage == "predict":
        from precip_input_assimilation.selfrule.predict import predict_stage
        result = predict_stage(protocol, basins, args.device)
    elif args.stage == "freeze":
        from precip_input_assimilation.selfrule.pipeline import freeze_stage
        result = freeze_stage(protocol, basins)
    elif args.stage == "score":
        from precip_input_assimilation.selfrule.pipeline import score_stage
        result = score_stage(protocol)
    else:
        from precip_input_assimilation.selfrule.witness import witness_stage
        result = witness_stage(protocol)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
