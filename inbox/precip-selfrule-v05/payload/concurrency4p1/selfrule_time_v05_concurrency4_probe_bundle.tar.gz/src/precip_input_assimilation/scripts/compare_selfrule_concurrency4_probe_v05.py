"""Validate four independent batch-128 basin processes sharing one allocated GPU."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reference-manifest", type=Path, required=True)
    parser.add_argument("--expected-reference-manifest-sha256", required=True)
    parser.add_argument("--candidate-manifest", type=Path, required=True)
    parser.add_argument("--reference-record", type=Path, required=True)
    parser.add_argument("--expected-reference-record-sha256", required=True)
    parser.add_argument("--reference-prediction", type=Path, required=True)
    parser.add_argument("--expected-reference-prediction-sha256", required=True)
    parser.add_argument("--technical-reference-dir", type=Path, required=True)
    parser.add_argument("--expected-technical-record-sha256", action="append", required=True)
    parser.add_argument("--technical-summary", type=Path, required=True)
    parser.add_argument("--expected-technical-summary-sha256", required=True)
    parser.add_argument("--candidate-output-dir", type=Path, required=True)
    parser.add_argument("--basin-file", type=Path, required=True)
    parser.add_argument("--expected-basin-file-sha256", required=True)
    parser.add_argument("--timing", type=Path, required=True)
    parser.add_argument("--cumulative-gpu-seconds-before-probe", type=float, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--relative-tolerance", type=float, default=2e-4)
    parser.add_argument("--theta-tolerance", type=float, default=5e-3)
    parser.add_argument("--max-aggregate-gpu-bytes", type=int, default=22 * 1024**3)
    parser.add_argument("--max-actual-gpu-used-mib", type=int, default=23 * 1024)
    return parser.parse_args()


def _relative_difference(left: float, right: float) -> float:
    return abs(left - right) / max(abs(left), abs(right), 1e-12)


def _max_absolute_difference(left: object, right: object) -> float:
    left_array = np.asarray(left, dtype=np.float64)
    right_array = np.asarray(right, dtype=np.float64)
    if left_array.shape != right_array.shape or not np.isfinite(left_array).all() or not np.isfinite(right_array).all():
        return float("inf")
    return float(np.max(np.abs(left_array - right_array))) if left_array.size else 0.0


def _source_key(entry: dict) -> str:
    path = str(entry["path"]).replace("\\", "/")
    marker = "/src/precip_input_assimilation/"
    return "idea/" + path.split(marker, 1)[1] if marker in path else path


def _source_map(manifest: dict) -> dict[str, tuple[int, str]]:
    result: dict[str, tuple[int, str]] = {}
    for entry in manifest["source_files"]:
        key = _source_key(entry)
        if key in result:
            raise RuntimeError(f"Duplicate source entry: {key}")
        result[key] = (int(entry["bytes"]), str(entry["sha256"]))
    return result


def _compare_reference_record(reference: dict, candidate: dict, relative_tolerance: float,
                              theta_tolerance: float) -> tuple[dict[str, bool], dict]:
    provenance = ("basin", "area_m2", "forcing_sha256", "fit_flow_sha256", "select_flow_sha256",
                  "fit_targets", "select_targets", "fit_coverage", "select_coverage", "static_normalized")
    checks = {
        "record_provenance_same": all(reference.get(key) == candidate.get(key) for key in provenance),
        "both_complete": reference.get("technical_complete") is True and candidate.get("technical_complete") is True,
        "original_metrics_close": True,
        "flow_history_close": True,
        "flow_history_parameters_close": True,
        "flow_history_candidates_close": True,
        "rain_rules_same": True,
        "rain_candidates_same": True,
        "rain_candidate_parameters_close": True,
        "rain_candidate_histories_close": True,
        "rain_selection_same": True,
        "rain_metrics_close": True,
        "rain_theta_close": True,
    }
    details: dict[str, object] = {}
    original_differences = {
        key: _relative_difference(float(reference["original"][key]), float(candidate["original"][key]))
        for key in ("fit_mse", "selection_mse", "fit_nse", "selection_nse")
    }
    checks["original_metrics_close"] = max(original_differences.values()) <= relative_tolerance
    reference_flow = reference["flow_history"]
    candidate_flow = candidate["flow_history"]
    flow_differences = {
        key: _relative_difference(float(reference_flow[key]), float(candidate_flow[key]))
        for key in ("selection_mse", "fit_mse", "sigma_fit")
    }
    checks["flow_history_close"] = (
        max(flow_differences.values()) <= relative_tolerance
        and reference_flow["selected_lambda"] == candidate_flow["selected_lambda"]
    )
    flow_parameter_difference = max(
        _max_absolute_difference(reference_flow["coefficients"], candidate_flow["coefficients"]),
        _max_absolute_difference(reference_flow["feature_mean"], candidate_flow["feature_mean"]),
        _max_absolute_difference(reference_flow["feature_std"], candidate_flow["feature_std"]),
    )
    checks["flow_history_parameters_close"] = flow_parameter_difference <= theta_tolerance
    reference_flow_candidates = reference_flow["candidate_records"]
    candidate_flow_candidates = candidate_flow["candidate_records"]
    flow_candidate_metric_difference = 0.0
    flow_candidate_parameter_difference = 0.0
    if len(reference_flow_candidates) != len(candidate_flow_candidates) or len(reference_flow_candidates) != 4:
        checks["flow_history_candidates_close"] = False
    else:
        for left, right in zip(reference_flow_candidates, candidate_flow_candidates, strict=True):
            if left["lambda"] != right["lambda"]:
                checks["flow_history_candidates_close"] = False
            flow_candidate_metric_difference = max(
                flow_candidate_metric_difference,
                _relative_difference(float(left["selection_mse"]), float(right["selection_mse"])),
                _relative_difference(float(left["fit_mse"]), float(right["fit_mse"])),
            )
            flow_candidate_parameter_difference = max(
                flow_candidate_parameter_difference,
                _max_absolute_difference(left["coefficients"], right["coefficients"]),
            )
        checks["flow_history_candidates_close"] &= (
            flow_candidate_metric_difference <= relative_tolerance
            and flow_candidate_parameter_difference <= theta_tolerance
        )
    arms: dict[str, dict] = {}
    for arm in ("rain_intensity", "rain_season"):
        reference_arm = reference["rain"][arm]
        candidate_arm = candidate["rain"][arm]
        reference_fit = reference_arm["fit"]
        candidate_fit = candidate_arm["fit"]
        reference_candidates = reference_fit["candidate_records"]
        candidate_candidates = candidate_fit["candidate_records"]
        checks["rain_rules_same"] &= reference_arm["rule"] == candidate_arm["rule"]
        reference_identities = [{key: row[key] for key in ("candidate", "lambda", "start")}
                                for row in reference_candidates]
        candidate_identities = [{key: row[key] for key in ("candidate", "lambda", "start")}
                                for row in candidate_candidates]
        checks["rain_candidates_same"] &= (
            len(reference_candidates) == len(candidate_candidates) == 12
            and candidate_fit.get("completed_steps") == 300
            and reference_identities == candidate_identities
        )
        checks["rain_selection_same"] &= all(reference_fit[key] == candidate_fit[key]
                                              for key in ("selected_lambda", "selected_start", "selected_step"))
        mse_differences = {
            key: _relative_difference(float(reference_fit[key]), float(candidate_fit[key]))
            for key in ("fit_mse", "selection_mse")
        }
        candidate_mse_differences = [
            _relative_difference(float(left["best_selection_mse"]), float(right["best_selection_mse"]))
            for left, right in zip(reference_candidates, candidate_candidates, strict=True)
        ]
        candidate_theta_differences = [
            _max_absolute_difference(left["best_theta"], right["best_theta"])
            for left, right in zip(reference_candidates, candidate_candidates, strict=True)
        ]
        candidate_step_same = all(left["best_step"] == right["best_step"]
                                  for left, right in zip(reference_candidates, candidate_candidates, strict=True))
        history_metric_differences: list[float] = []
        history_steps_same = True
        for left, right in zip(reference_candidates, candidate_candidates, strict=True):
            left_history, right_history = left["history"], right["history"]
            if len(left_history) != len(right_history):
                history_steps_same = False
                continue
            history_steps_same &= [row["step"] for row in left_history] == [row["step"] for row in right_history]
            history_metric_differences.extend(
                _relative_difference(float(left_row["selection_mse"]), float(right_row["selection_mse"]))
                for left_row, right_row in zip(left_history, right_history, strict=True)
            )
        theta_difference = float(np.max(np.abs(np.asarray(reference_fit["theta"], dtype=np.float64)
                                               - np.asarray(candidate_fit["theta"], dtype=np.float64))))
        checks["rain_metrics_close"] &= (
            max(mse_differences.values()) <= relative_tolerance
            and max(candidate_mse_differences) <= relative_tolerance
            and _relative_difference(float(reference_fit["sigma_fit"]),
                                     float(candidate_fit["sigma_fit"])) <= relative_tolerance
        )
        checks["rain_theta_close"] &= theta_difference <= theta_tolerance
        checks["rain_candidate_parameters_close"] &= (
            candidate_step_same and max(candidate_theta_differences) <= theta_tolerance)
        max_history_difference = max(history_metric_differences, default=float("inf"))
        checks["rain_candidate_histories_close"] &= (
            history_steps_same and bool(history_metric_differences)
            and max_history_difference <= relative_tolerance)
        arms[arm] = {
            "selected_mse_relative_differences": mse_differences,
            "max_candidate_selection_mse_relative_difference": max(candidate_mse_differences),
            "max_candidate_theta_absolute_difference": max(candidate_theta_differences),
            "max_candidate_history_mse_relative_difference": max_history_difference,
            "candidate_best_steps_same": candidate_step_same,
            "candidate_history_steps_same": history_steps_same,
            "theta_max_absolute_difference": theta_difference,
        }
    details["original_metric_relative_differences"] = original_differences
    details["flow_history_metric_relative_differences"] = flow_differences
    details["flow_history_parameter_max_absolute_difference"] = flow_parameter_difference
    details["flow_history_candidate_metric_max_relative_difference"] = flow_candidate_metric_difference
    details["flow_history_candidate_parameter_max_absolute_difference"] = flow_candidate_parameter_difference
    details["arms"] = arms
    return checks, details


def main() -> None:
    args = parse_args()
    if hashlib.sha256(args.basin_file.read_bytes()).hexdigest() != args.expected_basin_file_sha256:
        raise RuntimeError("Frozen four-basin file hash mismatch")
    if hashlib.sha256(args.technical_summary.read_bytes()).hexdigest() != args.expected_technical_summary_sha256:
        raise RuntimeError("Eight-basin technical summary hash mismatch")
    basins = [line.strip() for line in args.basin_file.read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(basins) != 4 or len(set(basins)) != 4 or basins[0] != "02137727":
        raise RuntimeError("Concurrency probe requires the frozen four-basin list with 02137727 first")
    pinned_paths = (
        (args.reference_manifest, args.expected_reference_manifest_sha256, "REFERENCE_MANIFEST"),
        (args.reference_record, args.expected_reference_record_sha256, "REFERENCE_RECORD"),
        (args.reference_prediction, args.expected_reference_prediction_sha256, "REFERENCE_PREDICTION"),
    )
    for path, expected, label in pinned_paths:
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise RuntimeError(f"{label}_HASH_MISMATCH")
    technical_hashes = dict(item.split("=", 1) for item in args.expected_technical_record_sha256)
    if set(technical_hashes) != set(basins[1:]):
        raise RuntimeError("Technical reference hash arguments do not match the frozen probe basins")
    for basin, expected in technical_hashes.items():
        path = args.technical_reference_dir / f"{basin}.json"
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise RuntimeError(f"TECHNICAL_REFERENCE_HASH_MISMATCH {basin}")
    reference_manifest = json.loads(args.reference_manifest.read_text(encoding="utf-8"))
    candidate_manifest = json.loads(args.candidate_manifest.read_text(encoding="utf-8"))
    reference = json.loads(args.reference_record.read_text(encoding="utf-8"))
    candidate = json.loads((args.candidate_output_dir / "fit" / f"{basins[0]}.json").read_text(encoding="utf-8"))

    path_fields = {"repo_root", "protocol_file", "data_dir", "run_dir", "basin_file",
                   "technical_basin_file", "basin_draw_file", "output_dir"}
    reference_protocol = {key: value for key, value in reference_manifest["effective_protocol"].items()
                          if key not in path_fields}
    candidate_protocol = {key: value for key, value in candidate_manifest["effective_protocol"].items()
                          if key not in path_fields}
    reference_sources = _source_map(reference_manifest)
    candidate_sources = _source_map(candidate_manifest)
    allowed_additions = {
        "idea/hpc/prepare_and_submit_selfrule_time_v05_concurrency4_probe.sh",
        "idea/hpc/prepare_and_submit_selfrule_time_v05_formal96.sh",
        "idea/hpc/selfrule_time_v05_concurrency4_probe.slurm",
        "idea/hpc/selfrule_time_v05_finalize.slurm",
        "idea/hpc/selfrule_time_v05_formal96.slurm",
        "idea/scripts/compare_selfrule_concurrency4_probe_v05.py",
    }
    shared_sources_same = all(candidate_sources.get(key) == value for key, value in reference_sources.items())
    source_additions = set(candidate_sources) - set(reference_sources)
    manifest_checks = {
        "manifest_identity_same": (
            reference_manifest.get("schema") == candidate_manifest.get("schema") == 1
            and reference_manifest.get("protocol") == candidate_manifest.get("protocol") == "selfrule_time_v05"
            and reference_manifest.get("scope") == candidate_manifest.get("scope") == "formal_96"
            and reference_manifest.get("allowed_basins") == candidate_manifest.get("allowed_basins")
            and reference_manifest.get("intended_device") == candidate_manifest.get("intended_device") == "cuda:0"),
        "protocol_same_batch128": (reference_protocol == candidate_protocol
                                    and int(candidate_protocol["batch_targets"]) == 128),
        "runtime_same": reference_manifest.get("runtime") == candidate_manifest.get("runtime"),
        "frozen_inputs_same": ([(row["bytes"], row["sha256"]) for row in reference_manifest["frozen_inputs"]]
                               == [(row["bytes"], row["sha256"]) for row in candidate_manifest["frozen_inputs"]]),
        "shared_sources_same": shared_sources_same and not (set(reference_sources) - set(candidate_sources)),
        "source_additions_exact": source_additions == allowed_additions,
    }
    record_checks, record_details = _compare_reference_record(
        reference, candidate, args.relative_tolerance, args.theta_tolerance)
    record_checks = {f"{basins[0]}_{key}": value for key, value in record_checks.items()}
    all_record_details = {basins[0]: record_details}
    for basin in basins[1:]:
        technical_reference = json.loads((args.technical_reference_dir / f"{basin}.json")
                                         .read_text(encoding="utf-8"))
        concurrent_record = json.loads((args.candidate_output_dir / "fit" / f"{basin}.json")
                                       .read_text(encoding="utf-8"))
        basin_checks, basin_details = _compare_reference_record(
            technical_reference, concurrent_record, args.relative_tolerance, args.theta_tolerance)
        record_checks.update({f"{basin}_{key}": value for key, value in basin_checks.items()})
        all_record_details[basin] = basin_details

    completion_checks: dict[str, bool] = {}
    aggregate_peak = 0
    for basin in basins:
        record = json.loads((args.candidate_output_dir / "fit" / f"{basin}.json").read_text(encoding="utf-8"))
        fit_summary = json.loads((args.candidate_output_dir / "fit_summaries" / f"{basin}.json")
                                 .read_text(encoding="utf-8"))
        predict_summary = json.loads((args.candidate_output_dir / "predict_summaries" / f"{basin}.json")
                                     .read_text(encoding="utf-8"))
        prediction_path = args.candidate_output_dir / "predictions" / f"{basin}.npz"
        completion_checks[f"{basin}_complete"] = (
            record.get("basin") == basin and record.get("technical_complete") is True
            and fit_summary.get("all_complete") is True and fit_summary.get("complete_basins") == [basin]
            and predict_summary.get("complete") is True
            and [row.get("basin") for row in predict_summary.get("basins", [])] == [basin]
            and prediction_path.is_file() and prediction_path.stat().st_size > 0
        )
        aggregate_peak += int(record.get("peak_gpu_bytes", -1))

    prediction_checks = {"prediction_keys_same": True, "prediction_dates_same": True,
                         "held_out_predictions_close": True}
    prediction_differences: dict[str, dict[str, float]] = {}
    candidate_prediction_path = args.candidate_output_dir / "predictions" / f"{basins[0]}.npz"
    with np.load(args.reference_prediction) as reference_prediction, np.load(
            candidate_prediction_path) as candidate_prediction:
        prediction_checks["prediction_keys_same"] = set(reference_prediction.files) == set(candidate_prediction.files)
        prediction_checks["prediction_dates_same"] = np.array_equal(reference_prediction["date"],
                                                                     candidate_prediction["date"])
        for key in sorted(set(reference_prediction.files) - {"date"}):
            left = reference_prediction[key].astype(np.float64)
            right = candidate_prediction[key].astype(np.float64)
            difference = left - right
            close = bool(np.allclose(left, right, rtol=args.relative_tolerance, atol=1e-4))
            prediction_checks["held_out_predictions_close"] &= close
            prediction_differences[key] = {
                "max_absolute_difference": float(np.max(np.abs(difference))),
                "relative_l2_difference": float(np.linalg.norm(difference)
                                                / max(np.linalg.norm(left), np.linalg.norm(right), 1e-12)),
            }

    timing = json.loads(args.timing.read_text(encoding="utf-8"))
    group_seconds = float(timing["group_fit_plus_predict_seconds"])
    if not np.isfinite(group_seconds) or group_seconds <= 0:
        raise RuntimeError("Concurrency timing must be finite and positive")
    actual_gpu_peak_mib = int(timing["gpu_peak_used_mib"])
    gpu_memory_samples = int(timing["gpu_memory_samples"])
    gpu_monitor_last_sample_epoch = int(timing["gpu_monitor_last_sample_epoch"])
    group_end_epoch = int(timing["group_end_epoch"])
    technical = json.loads(args.technical_summary.read_text(encoding="utf-8"))
    if technical.get("technical_complete") is not True or technical.get("basin_count") != 8:
        raise RuntimeError("Eight-basin technical summary is incomplete")
    technical_times = [float(row["elapsed_seconds"]) for row in technical["basins"]]
    variation_guard = max(1.05, max(technical_times) / (sum(technical_times) / len(technical_times)))
    projected_formal_seconds = group_seconds * 24.0 * variation_guard + 15.0 * 24.0
    projected_cumulative_before_formal = args.cumulative_gpu_seconds_before_probe + group_seconds + 30.0
    projected_cumulative_seconds = projected_cumulative_before_formal + projected_formal_seconds
    slurm_termination_reserve_seconds_per_task = 60
    remaining_after_reserve = (6.0 * 3600.0 - projected_cumulative_before_formal
                               - 24.0 * slurm_termination_reserve_seconds_per_task)
    formal_task_minutes = int(remaining_after_reserve // (24.0 * 60.0))
    projected_group_with_variation = group_seconds * variation_guard + 15.0
    resource_checks = {
        "group_timing_valid": True,
        "gpu_memory_monitor_complete": gpu_memory_samples >= 10,
        "gpu_memory_monitor_covered_group_end": gpu_monitor_last_sample_epoch >= group_end_epoch,
        "aggregate_memory_within_limit": 0 <= aggregate_peak <= args.max_aggregate_gpu_bytes,
        "actual_gpu_memory_within_limit": 0 < actual_gpu_peak_mib <= args.max_actual_gpu_used_mib,
        "cumulative_six_gpu_hour_budget": projected_cumulative_seconds <= 6.0 * 3600.0,
        "formal_integer_minute_hard_window_sufficient": (
            formal_task_minutes >= 1 and projected_group_with_variation <= formal_task_minutes * 60.0),
    }
    checks = {**manifest_checks, **record_checks, **completion_checks, **prediction_checks, **resource_checks}
    payload = {
        "protocol": "selfrule_time_v05_concurrency4_probe",
        "basins": basins,
        "checks": checks,
        "equivalence_passed": all(value for key, value in checks.items()
                                  if key != "cumulative_six_gpu_hour_budget"),
        "resource_line_passed": (
            resource_checks["cumulative_six_gpu_hour_budget"]
            and resource_checks["formal_integer_minute_hard_window_sufficient"]),
        "passed": all(checks.values()),
        "group_fit_plus_predict_seconds": group_seconds,
        "projected_formal_gpu_hours": projected_formal_seconds / 3600.0,
        "projected_formal_task_seconds_with_variation": projected_group_with_variation,
        "formal_task_time_limit_minutes": formal_task_minutes,
        "slurm_termination_reserve_seconds_per_task": slurm_termination_reserve_seconds_per_task,
        "cumulative_gpu_seconds_before_probe": args.cumulative_gpu_seconds_before_probe,
        "projected_cumulative_gpu_hours": projected_cumulative_seconds / 3600.0,
        "aggregate_process_peak_gpu_bytes": aggregate_peak,
        "actual_gpu_peak_used_mib": actual_gpu_peak_mib,
        "gpu_memory_samples": gpu_memory_samples,
        "gpu_monitor_last_sample_epoch": gpu_monitor_last_sample_epoch,
        "group_end_epoch": group_end_epoch,
        "technical_eight_basin_variation_guard": variation_guard,
        "frozen_four_basin_file_sha256": args.expected_basin_file_sha256,
        "technical_summary_sha256": args.expected_technical_summary_sha256,
        "pinned_reference_sha256": {
            "reference_manifest": args.expected_reference_manifest_sha256,
            "reference_record_02137727": args.expected_reference_record_sha256,
            "reference_prediction_02137727": args.expected_reference_prediction_sha256,
            **{f"technical_record_{basin}": digest for basin, digest in sorted(technical_hashes.items())},
        },
        "allowed_source_additions": sorted(allowed_additions),
        "held_out_prediction_differences": prediction_differences,
        "record_comparisons": all_record_details,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
    print(json.dumps(payload, sort_keys=True, allow_nan=False))
    if not payload["passed"]:
        raise SystemExit("CONCURRENCY4_PROBE_FAILED")


if __name__ == "__main__":
    main()
