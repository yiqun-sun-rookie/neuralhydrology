"""Compare a larger target batch with the validated batch-128 technical run."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reference-manifest", type=Path, required=True)
    parser.add_argument("--candidate-manifest", type=Path, required=True)
    parser.add_argument("--reference-record", type=Path, required=True)
    parser.add_argument("--reference-summary", type=Path, required=True)
    parser.add_argument("--candidate-record", type=Path, required=True)
    parser.add_argument("--candidate-summary", type=Path, required=True)
    parser.add_argument("--reference-prediction", type=Path, required=True)
    parser.add_argument("--candidate-prediction", type=Path, required=True)
    parser.add_argument("--probe-timing", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--relative-mse-tolerance", type=float, default=2e-4)
    parser.add_argument("--theta-tolerance", type=float, default=5e-3)
    parser.add_argument("--max-gpu-bytes", type=int, default=22 * 1024**3)
    return parser.parse_args()


def relative_difference(left: float, right: float) -> float:
    return abs(left - right) / max(abs(left), abs(right), 1e-12)


def main() -> None:
    args = parse_args()
    reference_manifest = json.loads(args.reference_manifest.read_text(encoding="utf-8"))
    candidate_manifest = json.loads(args.candidate_manifest.read_text(encoding="utf-8"))
    reference = json.loads(args.reference_record.read_text(encoding="utf-8"))
    candidate = json.loads(args.candidate_record.read_text(encoding="utf-8"))
    reference_summary = json.loads(args.reference_summary.read_text(encoding="utf-8"))
    candidate_summary = json.loads(args.candidate_summary.read_text(encoding="utf-8"))
    if reference.get("basin") != candidate.get("basin"):
        raise RuntimeError("Probe records refer to different basins")

    reference_protocol = dict(reference_manifest["effective_protocol"])
    candidate_protocol = dict(candidate_manifest["effective_protocol"])
    protocol_differences = {key for key in reference_protocol
                            if reference_protocol.get(key) != candidate_protocol.get(key)}
    permitted_protocol_differences = {"batch_targets", "output_dir", "protocol_file"}
    reference_protocol_path = reference_protocol["protocol_file"]
    candidate_protocol_path = candidate_protocol["protocol_file"]

    def non_protocol_sources(manifest: dict, protocol_path: str) -> list[dict]:
        return [entry for entry in manifest["source_files"] if entry["path"] != protocol_path]

    provenance_fields = ("area_m2", "forcing_sha256", "fit_flow_sha256", "select_flow_sha256",
                         "fit_targets", "select_targets", "fit_coverage", "select_coverage",
                         "static_normalized")

    checks: dict[str, bool] = {
        "manifest_schema_scope_and_basins_same": (
            reference_manifest.get("schema") == candidate_manifest.get("schema") == 1
            and reference_manifest.get("scope") == candidate_manifest.get("scope") == "formal_96"
            and reference_manifest.get("allowed_basins") == candidate_manifest.get("allowed_basins")
            and reference_manifest.get("intended_device") == candidate_manifest.get("intended_device") == "cuda:0"),
        "only_protocol_batch_and_paths_differ": (
            protocol_differences == permitted_protocol_differences
            and int(reference_protocol["batch_targets"]) == 128
            and int(candidate_protocol["batch_targets"]) == 384),
        "source_code_same": (non_protocol_sources(reference_manifest, reference_protocol_path)
                             == non_protocol_sources(candidate_manifest, candidate_protocol_path)),
        "frozen_inputs_same": reference_manifest["frozen_inputs"] == candidate_manifest["frozen_inputs"],
        "runtime_same": reference_manifest["runtime"] == candidate_manifest["runtime"],
        "record_provenance_same": all(reference.get(key) == candidate.get(key) for key in provenance_fields),
        "both_complete": reference.get("technical_complete") is True and candidate.get("technical_complete") is True,
        "candidate_steps_complete": True,
        "rules_same": True,
        "candidate_identities_same": True,
        "selected_lambda_same": True,
        "selected_start_same": True,
        "selected_step_same": True,
        "candidate_selection_mse_close": True,
        "selected_mse_close": True,
        "selected_theta_close": True,
        "original_metrics_close": True,
        "flow_history_selection_mse_close": True,
        "candidate_memory_within_limit": 0 <= int(candidate.get("peak_gpu_bytes", -1)) <= args.max_gpu_bytes,
    }
    arms: dict[str, dict] = {}
    for arm in ("rain_intensity", "rain_season"):
        ref = reference["rain"][arm]["fit"]
        cand = candidate["rain"][arm]["fit"]
        ref_candidates = ref["candidate_records"]
        cand_candidates = cand["candidate_records"]
        if len(ref_candidates) != 12 or len(cand_candidates) != 12 or cand.get("completed_steps") != 300:
            checks["candidate_steps_complete"] = False
        checks["rules_same"] &= reference["rain"][arm]["rule"] == candidate["rain"][arm]["rule"]
        reference_identities = [{key: item[key] for key in ("candidate", "lambda", "start")}
                                for item in ref_candidates]
        candidate_identities = [{key: item[key] for key in ("candidate", "lambda", "start")}
                                for item in cand_candidates]
        checks["candidate_identities_same"] &= reference_identities == candidate_identities
        candidate_differences = [
            relative_difference(float(ref_item["best_selection_mse"]), float(cand_item["best_selection_mse"]))
            for ref_item, cand_item in zip(ref_candidates, cand_candidates, strict=True)
        ]
        theta_ref = np.asarray(ref["theta"], dtype=np.float64)
        theta_cand = np.asarray(cand["theta"], dtype=np.float64)
        theta_difference = float(np.max(np.abs(theta_ref - theta_cand))) if theta_ref.size else 0.0
        selected_differences = {
            key: relative_difference(float(ref[key]), float(cand[key])) for key in ("selection_mse", "fit_mse")
        }
        checks["selected_lambda_same"] &= float(ref["selected_lambda"]) == float(cand["selected_lambda"])
        checks["selected_start_same"] &= float(ref["selected_start"]) == float(cand["selected_start"])
        checks["selected_step_same"] &= int(ref["selected_step"]) == int(cand["selected_step"])
        checks["candidate_selection_mse_close"] &= max(candidate_differences) <= args.relative_mse_tolerance
        checks["selected_mse_close"] &= max(selected_differences.values()) <= args.relative_mse_tolerance
        checks["selected_theta_close"] &= theta_difference <= args.theta_tolerance
        arms[arm] = {
            "selected_lambda_reference": ref["selected_lambda"],
            "selected_lambda_candidate": cand["selected_lambda"],
            "selected_start_reference": ref["selected_start"],
            "selected_start_candidate": cand["selected_start"],
            "selected_step_reference": ref["selected_step"],
            "selected_step_candidate": cand["selected_step"],
            "max_candidate_selection_mse_relative_difference": max(candidate_differences),
            "selected_mse_relative_differences": selected_differences,
            "theta_max_absolute_difference": theta_difference,
        }

    original_differences = {
        key: relative_difference(float(reference["original"][key]), float(candidate["original"][key]))
        for key in ("fit_mse", "selection_mse", "fit_nse", "selection_nse")
    }
    checks["original_metrics_close"] = max(original_differences.values()) <= args.relative_mse_tolerance
    flow_difference = relative_difference(float(reference["flow_history"]["selection_mse"]),
                                          float(candidate["flow_history"]["selection_mse"]))
    checks["flow_history_selection_mse_close"] = (
        flow_difference <= args.relative_mse_tolerance
        and reference["flow_history"]["selected_lambda"] == candidate["flow_history"]["selected_lambda"]
        and [{"lambda": item["lambda"]} for item in reference["flow_history"]["candidate_records"]]
        == [{"lambda": item["lambda"]} for item in candidate["flow_history"]["candidate_records"]])

    prediction_differences: dict[str, dict[str, float]] = {}
    with np.load(args.reference_prediction) as reference_prediction, np.load(
            args.candidate_prediction) as candidate_prediction:
        checks["prediction_keys_same"] = set(reference_prediction.files) == set(candidate_prediction.files)
        checks["prediction_dates_same"] = np.array_equal(reference_prediction["date"], candidate_prediction["date"])
        checks["held_out_predictions_close"] = True
        for key in sorted(set(reference_prediction.files) - {"date"}):
            left = reference_prediction[key].astype(np.float64)
            right = candidate_prediction[key].astype(np.float64)
            difference = left - right
            relative_l2 = float(np.linalg.norm(difference) / max(np.linalg.norm(left), np.linalg.norm(right), 1e-12))
            max_absolute = float(np.max(np.abs(difference)))
            close = bool(np.allclose(left, right, rtol=args.relative_mse_tolerance, atol=1e-4))
            checks["held_out_predictions_close"] &= close
            prediction_differences[key] = {
                "max_absolute_difference": max_absolute,
                "relative_l2_difference": relative_l2,
            }

    reference_seconds = float(reference_summary["elapsed_seconds"])
    candidate_seconds = float(candidate_summary["elapsed_seconds"])
    projected_core_gpu_hours = candidate_seconds * 96 / 3600
    timing = json.loads(args.probe_timing.read_text(encoding="utf-8"))
    projected_total_gpu_hours = (float(timing["candidate_fit_seconds"])
                                 + float(timing["candidate_predict_seconds"])) * 96 / 3600
    payload = {
        "protocol": "selfrule_time_v05_batch384_probe",
        "basin": reference["basin"],
        "checks": checks,
        "equivalence_passed": all(checks.values()),
        "reference_elapsed_seconds": reference_seconds,
        "candidate_elapsed_seconds": candidate_seconds,
        "speedup": reference_seconds / candidate_seconds,
        "projected_96_basin_core_gpu_hours": projected_core_gpu_hours,
        "projected_96_basin_fit_plus_predict_gpu_hours": projected_total_gpu_hours,
        "resource_line_passed": projected_total_gpu_hours <= 6.0,
        "reference_peak_gpu_bytes": int(reference["peak_gpu_bytes"]),
        "candidate_peak_gpu_bytes": int(candidate["peak_gpu_bytes"]),
        "thresholds": {
            "relative_mse_tolerance": args.relative_mse_tolerance,
            "theta_tolerance": args.theta_tolerance,
            "max_gpu_bytes": args.max_gpu_bytes,
            "projected_96_basin_fit_plus_predict_gpu_hours": 6.0,
        },
        "probe_timing_seconds": timing,
        "held_out_prediction_differences": prediction_differences,
        "protocol_difference_keys": sorted(protocol_differences),
        "original_metric_relative_differences": original_differences,
        "flow_history_selection_mse_relative_difference": flow_difference,
        "arms": arms,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
    print(json.dumps(payload, sort_keys=True, allow_nan=False))
    if not payload["equivalence_passed"]:
        raise SystemExit("BATCH_PROBE_EQUIVALENCE_FAILED")


if __name__ == "__main__":
    main()
