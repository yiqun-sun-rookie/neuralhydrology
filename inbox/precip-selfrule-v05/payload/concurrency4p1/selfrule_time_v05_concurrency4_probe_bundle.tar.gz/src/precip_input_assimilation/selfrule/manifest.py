"""Immutable run manifest and atomic task claims for the v0.5 protocol."""

from __future__ import annotations

import json
import os
import platform
import sys
import time
from dataclasses import asdict
from datetime import date
from pathlib import Path
from typing import Any

import neuralhydrology
import numpy as np
import pandas as pd
import torch
import yaml

from .data import read_basin_list
from .protocol import Protocol, sha256_file, validate_protocol


def _json_value(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_value(item) for item in value]
    if isinstance(value, Path):
        return str(value.resolve())
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, (np.integer, )):
        return int(value)
    if isinstance(value, (np.floating, )):
        return float(value)
    return value


def _write_exclusive_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    descriptor = os.open(path, flags, 0o644)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            descriptor = -1
            json.dump(payload, handle, indent=2, sort_keys=True, allow_nan=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
    finally:
        if descriptor >= 0:
            os.close(descriptor)


def claim_task(path: Path, payload: dict) -> None:
    """Atomically claim a task and retain the claim as an audit receipt."""
    receipt = {"claimed_at_unix": time.time(), "pid": os.getpid(), "host": platform.node(), **payload}
    try:
        _write_exclusive_json(path, receipt)
    except FileExistsError as exc:
        raise FileExistsError(f"Task is already claimed: {path}") from exc


def expected_basins(protocol: Protocol, technical: bool) -> list[str]:
    return read_basin_list(protocol.technical_basin_file if technical else protocol.basin_file)


def validate_stage_request(protocol: Protocol, stage: str, basins: list[str], technical: bool) -> None:
    validate_protocol(protocol, verify_files=True)
    if len(basins) != len(set(basins)):
        raise ValueError("A stage request contains duplicate basins")
    expected = expected_basins(protocol, technical)
    if technical:
        if stage not in {"prepare", "fit"}:
            raise ValueError("Technical mode permits only prepare and fit")
        if stage == "prepare" and basins != expected:
            raise ValueError("Technical preparation requires the exact frozen eight-basin list")
        if stage == "fit" and (not basins or any(basin not in expected for basin in basins)):
            raise ValueError("Technical fitting is restricted to the frozen eight-basin list")
    else:
        if stage in {"prepare", "freeze", "score", "witness"} and basins != expected:
            raise ValueError(f"Formal {stage} requires the exact frozen 96-basin list in order")
        if stage in {"fit", "predict"} and (not basins or any(basin not in expected for basin in basins)):
            raise ValueError(f"Formal {stage} is restricted to the frozen 96-basin list")
    if stage in {"fit", "predict"} and len(basins) != 1:
        raise ValueError(f"{stage} requires exactly one basin per process")


def _source_files(protocol: Protocol) -> list[Path]:
    files: list[Path] = [protocol.protocol_file]
    line_root = protocol.repo_root / "src" / "precip_input_assimilation"
    # Importing ``precip_input_assimilation.selfrule`` executes the parent
    # package initializer, so bind the complete idea package rather than only
    # the new subpackage.
    files.extend(sorted(line_root.rglob("*.py")))
    files.extend(sorted(path for path in (line_root / "hpc").glob("*selfrule*time*v05*") if path.is_file()))
    package_root = Path(neuralhydrology.__file__).resolve().parent
    files.extend(sorted(package_root.rglob("*.py")))
    return list(dict.fromkeys(path.resolve() for path in files))


def _frozen_input_files(protocol: Protocol) -> list[Path]:
    return [protocol.weight_file, protocol.config_file, protocol.scaler_file,
            protocol.basin_file, protocol.technical_basin_file, protocol.basin_draw_file,
            protocol.data_dir / "camels_attributes_v2.0" / "camels_name.txt"]


def _entries(paths: list[Path]) -> list[dict]:
    missing = [str(path) for path in paths if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"Run manifest inputs are missing: {missing}")
    return [{"path": str(path), "sha256": sha256_file(path), "bytes": path.stat().st_size} for path in paths]


def prepare_run_manifest(protocol: Protocol, basins: list[str], technical: bool, device: str) -> dict:
    """Freeze effective paths and code before any fitted output is created."""
    validate_stage_request(protocol, "prepare", basins, technical)
    output = protocol.output_dir
    manifest_path = output / "RUN_MANIFEST.json"
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"Preparation requires an empty output directory: {output}")
    output.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema": 1,
        "protocol": "selfrule_time_v05",
        "scope": "technical_8" if technical else "formal_96",
        "intended_device": device,
        "prepared_at_unix": time.time(),
        "allowed_basins": basins,
        "effective_protocol": _json_value(asdict(protocol)),
        "source_files": _entries(_source_files(protocol)),
        "frozen_inputs": _entries([path.resolve() for path in _frozen_input_files(protocol)]),
        "runtime": {
            "python": sys.version,
            "torch": torch.__version__,
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "pyyaml": yaml.__version__,
            "platform": platform.platform(),
        },
    }
    _write_exclusive_json(manifest_path, payload)
    return payload


def verify_run_manifest(protocol: Protocol,
                        *,
                        technical: bool | None = None,
                        requested_basins: list[str] | None = None,
                        device: str | None = None) -> dict:
    validate_protocol(protocol, verify_files=True)
    path = protocol.output_dir / "RUN_MANIFEST.json"
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("protocol") != "selfrule_time_v05" or payload.get("schema") != 1:
        raise RuntimeError("Unknown or malformed run manifest")
    expected_scope = None if technical is None else ("technical_8" if technical else "formal_96")
    if expected_scope is not None and payload.get("scope") != expected_scope:
        raise RuntimeError(f"Run scope mismatch: {payload.get('scope')} != {expected_scope}")
    if device is not None and payload.get("intended_device") != device:
        raise RuntimeError(f"Prepared device mismatch: {payload.get('intended_device')} != {device}")
    if payload.get("effective_protocol") != _json_value(asdict(protocol)):
        raise RuntimeError("Effective protocol or command-line paths changed after preparation")
    allowed = payload.get("allowed_basins", [])
    if len(allowed) != len(set(allowed)):
        raise RuntimeError("Run manifest contains duplicate basins")
    if requested_basins is not None and any(basin not in allowed for basin in requested_basins):
        raise RuntimeError("Requested basin is outside the prepared run")
    current_source_paths = [str(path) for path in _source_files(protocol)]
    prepared_source_paths = [entry["path"] for entry in payload["source_files"]]
    if current_source_paths != prepared_source_paths:
        raise RuntimeError("Source-file inventory changed after preparation")
    current_input_paths = [str(path.resolve()) for path in _frozen_input_files(protocol)]
    prepared_input_paths = [entry["path"] for entry in payload["frozen_inputs"]]
    if current_input_paths != prepared_input_paths:
        raise RuntimeError("Frozen-input inventory changed after preparation")
    for section in ("source_files", "frozen_inputs"):
        for entry in payload[section]:
            current = Path(entry["path"])
            if not current.is_file() or sha256_file(current) != entry["sha256"]:
                raise RuntimeError(f"Prepared file changed or disappeared: {current}")
    return payload
