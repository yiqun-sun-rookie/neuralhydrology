"""Post-freeze precipitation-product comparisons for the v0.5 experiment.

This stage never reads discharge.  Daymet and NLDAS are opened only after the
fitted rules and all four held-out prediction series have been frozen.
"""

from __future__ import annotations

import csv
import hashlib
import json
import os
import sys
from dataclasses import dataclass
from datetime import date, timedelta
from pathlib import Path

import numpy as np

from .data import find_unique
from .manifest import claim_task, verify_run_manifest
from .pipeline import verify_frozen, write_json_atomic
from .protocol import Protocol


@dataclass(frozen=True)
class ProductPrecipitation:
    product: str
    basin: str
    dates: np.ndarray
    values_mm_day: np.ndarray

    @property
    def canonical_sha256(self) -> str:
        digest = hashlib.sha256()
        digest.update(b"date,precipitation_mm_day\n")
        for current, value in zip(self.dates.astype("datetime64[D]"), self.values_mm_day, strict=True):
            digest.update(f"{current},{format(float(value), '.9g')}\n".encode("utf-8"))
        return digest.hexdigest()


def read_product_precipitation(data_dir: Path,
                               product: str,
                               basin: str,
                               start: date,
                               end: date) -> ProductPrecipitation:
    """Read one product over an explicit allowed interval and stop at its end."""
    root = Path(data_dir) / "basin_mean_forcing" / product
    path = find_unique(root, f"{basin}_*_forcing_leap.txt")
    dates: list[np.datetime64] = []
    values: list[float] = []
    with path.open("r", encoding="utf-8") as handle:
        handle.readline()
        handle.readline()
        handle.readline()
        header = handle.readline().split()
        normalized = [name.lower() for name in header]
        try:
            precipitation_column = normalized.index("prcp(mm/day)")
        except ValueError as exc:
            raise ValueError(f"{path}: precipitation column is missing") from exc
        previous: date | None = None
        for line_number, line in enumerate(handle, start=5):
            tokens = line.split()
            if len(tokens) < 4:
                continue
            current = date(int(tokens[0]), int(tokens[1]), int(tokens[2]))
            if previous is not None and current <= previous:
                raise ValueError(f"{path}:{line_number}: product dates are not strictly increasing")
            previous = current
            if current < start:
                continue
            if current > end:
                break
            value = float(tokens[precipitation_column])
            if not np.isfinite(value) or value < 0:
                raise ValueError(f"{path}:{line_number}: invalid precipitation value")
            dates.append(np.datetime64(current, "D"))
            values.append(value)
    expected = np.arange(np.datetime64(start), np.datetime64(end) + np.timedelta64(1, "D"),
                         dtype="datetime64[D]")
    actual = np.asarray(dates, dtype="datetime64[D]")
    if not np.array_equal(actual, expected):
        raise ValueError(f"{basin}: {product} is not a complete daily grid for {start} through {end}")
    return ProductPrecipitation(product, basin, actual, np.asarray(values, dtype=np.float64))


def _year_label(current: np.datetime64) -> str:
    rendered = str(current)
    year, month = int(rendered[:4]), int(rendered[5:7])
    start = year if month >= 10 else year - 1
    return f"{start}-{start + 1}"


def precipitation_metrics(values: np.ndarray) -> dict[str, float]:
    values = np.asarray(values, dtype=np.float64)
    if len(values) == 0 or not np.isfinite(values).all():
        raise ValueError("Precipitation metrics require a non-empty finite series")
    return {
        "p90_mm": float(np.quantile(values, 0.90)),
        "p99_mm": float(np.quantile(values, 0.99)),
        "drizzle_fraction_0_1_to_1_mm": float(np.mean((values >= 0.1) & (values < 1.0))),
        "total_mm": float(np.sum(values)),
    }


def nonoverlapping_three_day_mae(candidate: np.ndarray, witness: np.ndarray) -> tuple[float, int]:
    candidate = np.asarray(candidate, dtype=np.float64)
    witness = np.asarray(witness, dtype=np.float64)
    if candidate.shape != witness.shape:
        raise ValueError("Candidate and witness precipitation shapes differ")
    blocks = len(candidate) // 3
    if blocks == 0:
        raise ValueError("At least three daily values are required")
    candidate_total = candidate[:blocks * 3].reshape(blocks, 3).sum(axis=1)
    witness_total = witness[:blocks * 3].reshape(blocks, 3).sum(axis=1)
    return float(np.mean(np.abs(candidate_total - witness_total))), blocks


def _aligned_witness(data_dir: Path,
                     product: str,
                     basin: str,
                     start: date,
                     end: date) -> ProductPrecipitation:
    if product == "daymet":
        raw = read_product_precipitation(data_dir, product, basin, start + timedelta(days=1), end)
        return ProductPrecipitation(product, basin, raw.dates - np.timedelta64(1, "D"), raw.values_mm_day)
    if product == "nldas":
        return read_product_precipitation(data_dir, product, basin, start, end)
    raise ValueError(f"Unsupported witness product: {product}")


def _period_row(basin: str,
                product: str,
                period: str,
                original: np.ndarray,
                adjusted: np.ndarray,
                witness: np.ndarray,
                block_groups: list[tuple[np.ndarray, np.ndarray, np.ndarray]] | None = None) -> dict:
    original_metrics = precipitation_metrics(original)
    adjusted_metrics = precipitation_metrics(adjusted)
    witness_metrics = precipitation_metrics(witness)
    if block_groups is None:
        original_mae, blocks = nonoverlapping_three_day_mae(original, witness)
        adjusted_mae, _ = nonoverlapping_three_day_mae(adjusted, witness)
    else:
        original_weighted = 0.0
        adjusted_weighted = 0.0
        blocks = 0
        for original_group, adjusted_group, witness_group in block_groups:
            original_group_mae, group_blocks = nonoverlapping_three_day_mae(original_group, witness_group)
            adjusted_group_mae, _ = nonoverlapping_three_day_mae(adjusted_group, witness_group)
            original_weighted += original_group_mae * group_blocks
            adjusted_weighted += adjusted_group_mae * group_blocks
            blocks += group_blocks
        original_mae = original_weighted / blocks
        adjusted_mae = adjusted_weighted / blocks
    row = {
        "basin": basin,
        "product": product,
        "period": period,
        "days": int(len(original)),
        "three_day_blocks": blocks,
        "three_day_mae_original_mm": original_mae,
        "three_day_mae_adjusted_mm": adjusted_mae,
        "three_day_mae_change_adjusted_minus_original_mm": adjusted_mae - original_mae,
    }
    for metric in original_metrics:
        row[f"{metric}_original"] = original_metrics[metric]
        row[f"{metric}_adjusted"] = adjusted_metrics[metric]
        row[f"{metric}_witness"] = witness_metrics[metric]
        row[f"{metric}_absolute_gap_change_adjusted_minus_original"] = (
            abs(adjusted_metrics[metric] - witness_metrics[metric])
            - abs(original_metrics[metric] - witness_metrics[metric]))
    return row


def witness_stage(protocol: Protocol) -> dict:
    """Compare frozen adjusted rain with Daymet and NLDAS without using discharge."""
    prepared = verify_run_manifest(protocol, technical=False)
    frozen = verify_frozen(protocol)
    basins = list(frozen.get("basins", []))
    if basins != prepared.get("allowed_basins") or len(basins) != 96:
        raise RuntimeError("Formal witness comparison requires the exact frozen 96-basin list")

    def reject_discharge_open(event: str, args: tuple) -> None:
        if event == "open" and args and isinstance(args[0], (str, bytes, os.PathLike)):
            candidate = os.fsdecode(os.fspath(args[0])).replace("\\", "/")
            if "usgs_streamflow" in candidate:
                raise PermissionError("Witness process attempted to open discharge data")

    sys.addaudithook(reject_discharge_open)
    claim_task(protocol.output_dir / "locks" / "witness.lock", {"stage": "witness"})
    output_dir = protocol.output_dir / "witness"
    if (output_dir / "summary.json").exists() or (output_dir / "per_basin_period.csv").exists():
        raise FileExistsError(f"Refusing to overwrite an existing witness comparison: {output_dir}")

    rows: list[dict] = []
    input_records: list[dict] = []
    for basin in basins:
        prediction_path = protocol.output_dir / "predictions" / f"{basin}.npz"
        with np.load(prediction_path) as data:
            dates = data["date"].astype("datetime64[D]")
            original_all = data["precip_original"].astype(np.float64)
            adjusted_all = data["precip_rain_intensity"].astype(np.float64)
        for product in ("daymet", "nldas"):
            witness = _aligned_witness(protocol.data_dir, product, basin, protocol.score_start, protocol.score_end)
            positions = np.searchsorted(dates, witness.dates)
            if np.any(positions >= len(dates)) or not np.array_equal(dates[positions], witness.dates):
                raise ValueError(f"{basin}: frozen prediction dates do not align with {product}")
            original = original_all[positions]
            adjusted = adjusted_all[positions]
            labels = np.asarray([_year_label(current) for current in witness.dates])
            for period in ("all", *sorted(np.unique(labels))):
                mask = np.ones(len(labels), dtype=bool) if period == "all" else labels == period
                # Build non-overlapping blocks independently inside each water year.
                if period == "all":
                    period_rows = []
                    for year in sorted(np.unique(labels)):
                        year_mask = labels == year
                        period_rows.append((original[year_mask], adjusted[year_mask], witness.values_mm_day[year_mask]))
                    row = _period_row(basin, product, period, original, adjusted, witness.values_mm_day,
                                      block_groups=period_rows)
                else:
                    row = _period_row(basin, product, period, original[mask], adjusted[mask],
                                      witness.values_mm_day[mask])
                rows.append(row)
            input_records.append({
                "basin": basin,
                "product": product,
                "first_aligned_date": str(witness.dates[0]),
                "last_aligned_date": str(witness.dates[-1]),
                "days": int(len(witness.dates)),
                "canonical_sha256": witness.canonical_sha256,
            })

    output_dir.mkdir(parents=True, exist_ok=True)
    with (output_dir / "per_basin_period.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    write_json_atomic(output_dir / "inputs.json", {"products": input_records})

    overall = [row for row in rows if row["period"] == "all"]
    comparison_keys = [
        "three_day_mae_change_adjusted_minus_original_mm",
        "p90_mm_absolute_gap_change_adjusted_minus_original",
        "p99_mm_absolute_gap_change_adjusted_minus_original",
        "drizzle_fraction_0_1_to_1_mm_absolute_gap_change_adjusted_minus_original",
        "total_mm_absolute_gap_change_adjusted_minus_original",
    ]
    by_product = {
        product: {
            key: {
                "median": float(np.median([row[key] for row in overall if row["product"] == product])),
                "closer_fraction": float(np.mean([row[key] < 0 for row in overall if row["product"] == product])),
            }
            for key in comparison_keys
        }
        for product in ("daymet", "nldas")
    }
    agreement = {}
    for key in comparison_keys:
        daymet = {row["basin"]: row[key] < 0 for row in overall if row["product"] == "daymet"}
        nldas = {row["basin"]: row[key] < 0 for row in overall if row["product"] == "nldas"}
        common = sorted(set(daymet).intersection(nldas))
        agreement[key] = {
            "both_closer": sum(daymet[basin] and nldas[basin] for basin in common),
            "daymet_only_closer": sum(daymet[basin] and not nldas[basin] for basin in common),
            "nldas_only_closer": sum(not daymet[basin] and nldas[basin] for basin in common),
            "neither_closer": sum(not daymet[basin] and not nldas[basin] for basin in common),
        }
    summary = {
        "stage": "witness",
        "technical_complete": len(input_records) == 192 and len(overall) == 192,
        "basins": len(basins),
        "daymet_alignment": "Daymet(d+1) compared with Maurer(d); 1989-09-30 Maurer omitted",
        "nldas_alignment": "NLDAS(d) compared with Maurer(d)",
        "interpretation": "Negative gap changes mean the frozen adjusted rain is closer to that product.",
        "by_product": by_product,
        "product_agreement": agreement,
    }
    write_json_atomic(output_dir / "summary.json", summary)
    return summary
