"""Stage-separated experiment pipeline.

``fit`` reads only fitting and selection discharge. ``predict`` cannot open a
discharge file. ``freeze`` hashes every fitted object and prediction. ``score``
refuses to read held-out discharge until that frozen record verifies.
"""

from __future__ import annotations

import csv
import hashlib
import json
import os
import time
import traceback
from dataclasses import asdict
from datetime import date
from pathlib import Path
from typing import Iterable

import numpy as np
import torch

from .data import (load_normalization, load_normalized_attributes, read_basin_list, read_maurer_forcing,
                   slice_indices, valid_target_indices)
from .fit import fit_flow_history, fit_rain_rule, predict_batched
from .flow_data import align_flow_to_forcing, read_flow_slice
from .manifest import claim_task, verify_run_manifest
from .model import FrozenC4, configure_determinism
from .protocol import Protocol
from .rules import build_rain_rule


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def _json_ready(value):
    if isinstance(value, (np.integer, )):
        return int(value)
    if isinstance(value, (np.floating, )):
        return float(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, date):
        return value.isoformat()
    raise TypeError(f"Cannot serialize {type(value)}")


def write_json_atomic(path: Path, payload: dict) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + f".tmp-{os.getpid()}")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True, default=_json_ready, allow_nan=False) + "\n",
                         encoding="utf-8")
    temporary.replace(path)


def append_jsonl(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(payload, sort_keys=True, default=_json_ready, allow_nan=False) + "\n")


def _nse(observed: np.ndarray, simulated: np.ndarray) -> float:
    observed = np.asarray(observed, dtype=np.float64)
    simulated = np.asarray(simulated, dtype=np.float64)
    denominator = float(np.sum((observed - observed.mean())**2))
    return float("nan") if denominator <= 0 else 1.0 - float(np.sum((observed - simulated)**2)) / denominator


def _usable_targets(raw_dynamic: np.ndarray,
                    dates: np.ndarray,
                    start: date,
                    end: date,
                    sequence_length: int,
                    flow_aligned: np.ndarray | None = None) -> tuple[np.ndarray, float]:
    requested = slice_indices(dates, start, end)
    valid = valid_target_indices(raw_dynamic, requested, sequence_length)
    if flow_aligned is not None:
        valid = valid[np.isfinite(flow_aligned[valid])]
    coverage = len(valid) / len(requested) if len(requested) else 0.0
    return valid, coverage


def _effective_fit_days(n_days: int,
                        targets: np.ndarray,
                        fit_indices: np.ndarray,
                        sequence_length: int) -> np.ndarray:
    difference = np.zeros(n_days + 1, dtype=np.int64)
    fit_lo, fit_hi = int(fit_indices[0]), int(fit_indices[-1])
    for target in targets:
        lo = max(int(target) - sequence_length + 1, fit_lo)
        hi = min(int(target), fit_hi)
        if lo <= hi:
            difference[lo] += 1
            difference[hi + 1] -= 1
    return np.cumsum(difference[:-1]) > 0


def _make_runner(protocol: Protocol, device: str) -> tuple[FrozenC4, tuple[str, ...]]:
    _, names, center, scale, q_center, q_scale = load_normalization(protocol.run_dir)
    runner = FrozenC4(protocol.run_dir, device, names, center, scale, q_center, q_scale)
    if runner.sequence_length != protocol.sequence_length:
        raise ValueError("Protocol and frozen model use different sequence lengths")
    return runner, names


def fit_one_basin(protocol: Protocol,
                  basin: str,
                  static_values: np.ndarray,
                  device: str,
                  absolute_deadline: float | None = None) -> dict:
    """Fit one basin without touching held-out scoring discharge."""
    final_path = protocol.output_dir / "fit" / f"{basin}.json"
    progress_file = protocol.output_dir / "progress" / f"{basin}.jsonl"
    if final_path.exists() or progress_file.exists():
        raise FileExistsError(f"Refusing to overwrite an existing basin run: {basin}")
    claim_task(protocol.output_dir / "locks" / f"fit-{basin}.lock",
               {"stage": "fit", "basin": basin, "technical": absolute_deadline is not None})
    try:
        result = _fit_one_basin_claimed(protocol, basin, static_values, device, absolute_deadline,
                                        final_path, progress_file)
        if not final_path.exists():
            write_json_atomic(final_path, result)
        return result
    except Exception as exc:
        failure = {
            "protocol": "selfrule_time_v05",
            "basin": basin,
            "technical_complete": False,
            "reason": f"{type(exc).__name__}: {exc}",
            "traceback": traceback.format_exc(),
        }
        write_json_atomic(final_path, failure)
        raise


def _fit_one_basin_claimed(protocol: Protocol,
                           basin: str,
                           static_values: np.ndarray,
                           device: str,
                           absolute_deadline: float | None,
                           final_path: Path,
                           progress_file: Path) -> dict:
    """Implementation after the caller has atomically claimed this basin."""
    configure_determinism(protocol.seed)
    runner, dynamic_names = _make_runner(protocol, device)
    forcing = read_maurer_forcing(protocol.data_dir, basin, protocol.forcing_start, protocol.select_end)
    if forcing.names != dynamic_names:
        raise ValueError(f"{basin}: forcing order {forcing.names} differs from model order {dynamic_names}")
    fit_flow = read_flow_slice(protocol.data_dir, basin, forcing.area_m2, protocol.fit_start, protocol.fit_end)
    select_flow = read_flow_slice(protocol.data_dir, basin, forcing.area_m2,
                                  protocol.select_start, protocol.select_end)
    fit_aligned = align_flow_to_forcing(fit_flow, forcing.dates)
    select_aligned = align_flow_to_forcing(select_flow, forcing.dates)
    fit_targets, fit_coverage = _usable_targets(forcing.values, forcing.dates, protocol.fit_start, protocol.fit_end,
                                                protocol.sequence_length, fit_aligned)
    select_targets, select_coverage = _usable_targets(forcing.values, forcing.dates,
                                                      protocol.select_start, protocol.select_end,
                                                      protocol.sequence_length, select_aligned)
    if fit_coverage < 0.70 or select_coverage < 0.70:
        return {"basin": basin, "technical_complete": False, "reason": "fit or selection coverage below 70%",
                "fit_coverage": fit_coverage, "select_coverage": select_coverage,
                "fit_flow_sha256": fit_flow.canonical_sha256,
                "select_flow_sha256": select_flow.canonical_sha256}

    raw = torch.as_tensor(forcing.values, dtype=torch.float32, device=runner.device)
    static = torch.as_tensor(static_values, dtype=torch.float32, device=runner.device)
    fit_observed = fit_aligned[fit_targets]
    select_observed = select_aligned[select_targets]
    original_fit = predict_batched(runner, raw, static, fit_targets, protocol.batch_targets)
    original_select = predict_batched(runner, raw, static, select_targets, protocol.batch_targets)
    flow_history = fit_flow_history(forcing.dates, forcing.values[:, 0], fit_targets, original_fit, fit_observed,
                                    select_targets, original_select, select_observed, protocol.lambdas)
    fit_indices = slice_indices(forcing.dates, protocol.fit_start, protocol.fit_end)
    effective = _effective_fit_days(len(forcing.dates), fit_targets, fit_indices, protocol.sequence_length)
    payload: dict = {
        "protocol": "selfrule_time_v05",
        "basin": basin,
        "technical_complete": False,
        "device": device,
        "area_m2": forcing.area_m2,
        "static_normalized": static_values.astype(float).tolist(),
        "forcing_sha256": forcing.canonical_sha256,
        "fit_flow_sha256": fit_flow.canonical_sha256,
        "select_flow_sha256": select_flow.canonical_sha256,
        "fit_flow_missing": fit_flow.missing_count,
        "select_flow_missing": select_flow.missing_count,
        "fit_coverage": fit_coverage,
        "select_coverage": select_coverage,
        "fit_targets": len(fit_targets),
        "select_targets": len(select_targets),
        "original": {
            "fit_mse": float(np.mean((original_fit - fit_observed)**2)),
            "selection_mse": float(np.mean((original_select - select_observed)**2)),
            "fit_nse": _nse(fit_observed, original_fit),
            "selection_nse": _nse(select_observed, original_select),
        },
        "flow_history": asdict(flow_history),
        "rain": {},
    }
    for kind in ("rain_intensity", "rain_season"):
        rule = build_rain_rule(kind, forcing.dates, forcing.values[:, 0], protocol.fit_start, protocol.fit_end,
                               effective, protocol.wet_threshold_mm, protocol.min_bin_support)
        append_jsonl(progress_file, {"event": "arm_start", "arm": kind, "wall_time": time.time()})
        result = fit_rain_rule(
            runner=runner,
            raw_dynamic=raw,
            dates=forcing.dates,
            static=static,
            rule=rule,
            fit_targets=fit_targets,
            fit_observed=fit_observed,
            select_targets=select_targets,
            select_observed=select_observed,
            lambdas=protocol.lambdas,
            starts=protocol.starts,
            learning_rate=protocol.learning_rate,
            max_steps=protocol.max_steps,
            selection_interval=protocol.selection_interval,
            batch_targets=protocol.batch_targets,
            theta_min=float(np.log(protocol.multiplier_min)),
            theta_max=float(np.log(protocol.multiplier_max)),
            candidate_wall_seconds=protocol.candidate_wall_minutes * 60,
            absolute_deadline=absolute_deadline,
            progress=lambda event, arm=kind: append_jsonl(progress_file, {"arm": arm, **event}),
        )
        payload["rain"][kind] = {"rule": rule.to_dict(), "fit": asdict(result)}
        write_json_atomic(final_path, payload)
        if not result.complete:
            payload["reason"] = f"{kind}: {result.reason}"
            write_json_atomic(final_path, payload)
            return payload
    payload["technical_complete"] = True
    payload["reason"] = "complete"
    if runner.device.type == "cuda":
        payload["peak_gpu_bytes"] = int(torch.cuda.max_memory_allocated(runner.device))
    write_json_atomic(final_path, payload)
    return payload


def fit_stage(protocol: Protocol,
              basins: list[str],
              device: str,
              technical: bool = False) -> dict:
    if len(basins) != 1:
        raise ValueError("fit_stage requires exactly one basin per process")
    verify_run_manifest(protocol, technical=technical, requested_basins=basins, device=device)
    protocol.output_dir.mkdir(parents=True, exist_ok=True)
    static = load_normalized_attributes(protocol.data_dir, protocol.run_dir, basins)
    started = time.monotonic()
    deadline = started + protocol.technical_wall_minutes * 60 if technical else None
    results: list[dict] = []
    for index, basin in enumerate(basins):
        if deadline is not None and time.monotonic() >= deadline:
            break
        result = fit_one_basin(protocol, basin, static[index], device, deadline)
        results.append(result)
        if technical and not result.get("technical_complete", False):
            break
    elapsed = time.monotonic() - started
    summary = {
        "stage": "fit",
        "technical_probe": technical,
        "requested_basins": basins,
        "attempted_basins": [result["basin"] for result in results],
        "complete_basins": [result["basin"] for result in results if result.get("technical_complete")],
        "elapsed_seconds": elapsed,
        "all_complete": len(results) == len(basins) and all(result.get("technical_complete") for result in results),
        "peak_gpu_bytes": max((int(result.get("peak_gpu_bytes", 0)) for result in results), default=0),
    }
    summary_path = protocol.output_dir / "fit_summaries" / f"{basins[0]}.json"
    if summary_path.exists():
        raise FileExistsError(f"Refusing to overwrite fit summary: {summary_path}")
    write_json_atomic(summary_path, summary)
    return summary


def _manifest_files(protocol: Protocol, basins: Iterable[str]) -> list[Path]:
    files = [protocol.output_dir / "RUN_MANIFEST.json", protocol.protocol_file, protocol.config_file,
             protocol.weight_file, protocol.scaler_file, protocol.basin_file, protocol.technical_basin_file,
             protocol.basin_draw_file,
             protocol.data_dir / "camels_attributes_v2.0" / "camels_name.txt"]
    plan = protocol.repo_root / "docs" / "plans" / "2026-09-29-precip-selfcorrection-time-generalization-plan-v0.5.md"
    if plan.is_file():
        files.append(plan)
    source_root = protocol.repo_root / "src" / "precip_input_assimilation" / "selfrule"
    files.extend(sorted(source_root.glob("*.py")))
    script_root = protocol.repo_root / "src" / "precip_input_assimilation" / "scripts"
    files.extend(sorted(script_root.glob("*selfrule*time*v05*.py")))
    for basin in basins:
        files.append(protocol.output_dir / "fit" / f"{basin}.json")
        files.append(protocol.output_dir / "predictions" / f"{basin}.npz")
    return files


def freeze_stage(protocol: Protocol, basins: list[str]) -> dict:
    prepared = verify_run_manifest(protocol, technical=False, requested_basins=basins)
    if basins != prepared["allowed_basins"] or len(basins) != 96:
        raise RuntimeError("Formal freeze requires the exact prepared 96-basin list")
    claim_task(protocol.output_dir / "locks" / "freeze.lock", {"stage": "freeze"})
    for basin in basins:
        fit_record = json.loads((protocol.output_dir / "fit" / f"{basin}.json").read_text(encoding="utf-8"))
        if not fit_record.get("technical_complete"):
            raise RuntimeError(f"{basin}: cannot freeze incomplete fit")
    files = _manifest_files(protocol, basins)
    missing = [str(path) for path in files if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"Cannot freeze; missing files: {missing}")
    entries = [{"path": str(path.resolve()), "sha256": sha256_file(path), "bytes": path.stat().st_size}
               for path in files]
    payload = {
        "protocol": "selfrule_time_v05",
        "frozen_at_unix": time.time(),
        "score_period": [protocol.score_start.isoformat(), protocol.score_end.isoformat()],
        "basins": basins,
        "files": entries,
    }
    frozen_path = protocol.output_dir / "FROZEN.json"
    if frozen_path.exists():
        existing = json.loads(frozen_path.read_text(encoding="utf-8"))
        comparable_existing = {key: value for key, value in existing.items() if key != "frozen_at_unix"}
        comparable_new = {key: value for key, value in payload.items() if key != "frozen_at_unix"}
        if comparable_existing != comparable_new:
            raise FileExistsError(f"Existing frozen manifest differs: {frozen_path}")
        return existing
    write_json_atomic(frozen_path, payload)
    return payload


def verify_frozen(protocol: Protocol) -> dict:
    frozen_path = protocol.output_dir / "FROZEN.json"
    payload = json.loads(frozen_path.read_text(encoding="utf-8"))
    expected_basins = read_basin_list(protocol.basin_file)
    expected_period = [protocol.score_start.isoformat(), protocol.score_end.isoformat()]
    if payload.get("protocol") != "selfrule_time_v05":
        raise RuntimeError("Frozen manifest has the wrong protocol")
    if payload.get("score_period") != expected_period:
        raise RuntimeError("Frozen manifest has the wrong scoring period")
    if payload.get("basins") != expected_basins or len(expected_basins) != 96:
        raise RuntimeError("Frozen manifest has the wrong basin list")
    expected_paths = [str(path.resolve()) for path in _manifest_files(protocol, expected_basins)]
    entries = payload.get("files")
    if not isinstance(entries, list):
        raise RuntimeError("Frozen manifest has no file list")
    actual_paths = [entry.get("path") for entry in entries if isinstance(entry, dict)]
    if len(actual_paths) != len(entries) or len(actual_paths) != len(set(actual_paths)):
        raise RuntimeError("Frozen manifest contains malformed or duplicate file entries")
    if actual_paths != expected_paths:
        raise RuntimeError("Frozen manifest file inventory is incomplete, reordered, or unexpected")
    for entry in entries:
        path = Path(entry["path"])
        if (not path.is_file() or path.stat().st_size != entry.get("bytes")
                or sha256_file(path) != entry.get("sha256")):
            raise RuntimeError(f"Frozen file changed or disappeared: {path}")
    return payload


def _year_label(current: np.datetime64) -> str:
    rendered = str(current)
    year, month = int(rendered[:4]), int(rendered[5:7])
    start = year if month >= 10 else year - 1
    return f"{start}-{start + 1}"


def _score_quality(observed: np.ndarray,
                   common: np.ndarray,
                   year_labels: np.ndarray) -> tuple[dict[str, float], dict[str, float | None], float | None, bool]:
    years = np.unique(year_labels)
    coverage = {year: float(np.mean(common[year_labels == year])) for year in years}
    variance = {
        year: (float(np.var(observed[common & (year_labels == year)], ddof=0))
               if int(np.sum(common & (year_labels == year))) else None)
        for year in years
    }
    overall_variance = float(np.var(observed[common], ddof=0)) if int(common.sum()) else None
    valid = (all(value >= 0.70 for value in coverage.values()) and overall_variance is not None
             and overall_variance > 0 and all(value is not None and value > 0 for value in variance.values()))
    return coverage, variance, overall_variance, valid


def _load_huc2(protocol: Protocol, basins: list[str]) -> dict[str, str]:
    path = protocol.data_dir / "camels_attributes_v2.0" / "camels_name.txt"
    mapping: dict[str, str] = {}
    requested = set(basins)
    with path.open("r", encoding="utf-8") as handle:
        reader = csv.DictReader(handle, delimiter=";")
        for row in reader:
            basin = row["gauge_id"]
            if basin not in requested:
                continue
            if basin in mapping:
                raise ValueError(f"Duplicate HUC-2 mapping for basin {basin}")
            group = str(row["huc_02"]).zfill(2)
            if len(group) != 2 or not group.isdigit():
                raise ValueError(f"Invalid HUC-2 mapping for basin {basin}: {group}")
            mapping[basin] = group
    if set(mapping) != requested:
        missing = sorted(requested - set(mapping))
        raise ValueError(f"Missing HUC-2 mappings for basins: {missing}")
    return mapping


def _sign_flip(values: np.ndarray, groups: np.ndarray, seed: int, repetitions: int = 10_000) -> float:
    finite = np.isfinite(values)
    values, groups = values[finite], groups[finite]
    observed = float(np.median(values))
    unique = np.unique(groups)
    rng = np.random.default_rng(seed)
    exceed = 0
    for _ in range(repetitions):
        signs = {group: rng.choice((-1.0, 1.0)) for group in unique}
        statistic = float(np.median([value * signs[group] for value, group in zip(values, groups, strict=True)]))
        exceed += abs(statistic) >= abs(observed)
    return (exceed + 1) / (repetitions + 1)


def _cluster_bootstrap_median(values: np.ndarray,
                              groups: np.ndarray,
                              seed: int,
                              repetitions: int = 10_000) -> list[float]:
    """Return a 95% interval after resampling complete HUC-2 groups."""
    finite = np.isfinite(values)
    values, groups = values[finite], groups[finite]
    unique = np.unique(groups)
    if len(values) == 0 or len(unique) == 0:
        return []
    grouped = {group: values[groups == group] for group in unique}
    rng = np.random.default_rng(seed)
    statistics = np.empty(repetitions, dtype=np.float64)
    for index in range(repetitions):
        sampled = rng.choice(unique, size=len(unique), replace=True)
        statistics[index] = np.median(np.concatenate([grouped[group] for group in sampled]))
    return np.quantile(statistics, [0.025, 0.975]).astype(float).tolist()


def _low_snow_fraction(dates: np.ndarray,
                       values: np.ndarray,
                       names: tuple[str, ...],
                       start: date,
                       end: date) -> float | None:
    """Fraction of fitting-period precipitation falling on sub-zero mean-temperature days."""
    required = {name: names.index(name) for name in ("PRCP(mm/day)", "Tmin(C)", "Tmax(C)")}
    mask = (dates >= np.datetime64(start)) & (dates <= np.datetime64(end))
    precipitation = values[mask, required["PRCP(mm/day)"]].astype(np.float64)
    mean_temperature = 0.5 * (values[mask, required["Tmin(C)"]] + values[mask, required["Tmax(C)"]])
    total = float(np.sum(precipitation))
    if not np.isfinite(total) or total <= 0:
        return None
    fraction = float(np.sum(precipitation[mean_temperature < 0]) / total)
    return fraction if np.isfinite(fraction) else None


def _nse_from_reference(reference_nse: float, reference_mse: float, candidate_mse: float) -> float | None:
    """Recover a candidate NSE from a reference NSE/MSE pair on the same observations."""
    if not all(np.isfinite(value) for value in (reference_nse, reference_mse, candidate_mse)):
        return None
    denominator_factor = 1.0 - reference_nse
    if reference_mse < 0 or candidate_mse < 0 or denominator_factor <= 0:
        return None
    variance = reference_mse / denominator_factor
    if variance <= 0:
        return None
    return float(1.0 - candidate_mse / variance)


def _fit_selection_diagnostics(fit_records: dict[str, dict], theta_min: float, theta_max: float) -> dict:
    arms = ("rain_season", "rain_intensity")
    periods: dict[str, dict[str, list[float]]] = {
        period: {arm: [] for arm in arms + ("flow_history", )} for period in ("fit", "selection")
    }
    boundary_parameters = {arm: 0 for arm in arms}
    parameter_counts = {arm: 0 for arm in arms}
    boundary_basins = {arm: 0 for arm in arms}
    selected_step_zero = {arm: 0 for arm in arms}
    tolerance = 1e-6
    for record in fit_records.values():
        original = record["original"]
        fit_variance = float(record["rain"]["rain_intensity"]["fit"]["sigma_fit"])**2
        for arm in arms:
            result = record["rain"][arm]["fit"]
            fit_nse = None if fit_variance <= 0 else float(1.0 - float(result["fit_mse"]) / fit_variance)
            selection_nse = _nse_from_reference(float(original["selection_nse"]),
                                                float(original["selection_mse"]),
                                                float(result["selection_mse"]))
            if fit_nse is not None:
                periods["fit"][arm].append(fit_nse - float(original["fit_nse"]))
            if selection_nse is not None:
                periods["selection"][arm].append(selection_nse - float(original["selection_nse"]))
            theta = np.asarray(result["theta"], dtype=np.float64)
            on_boundary = np.isclose(theta, theta_min, atol=tolerance, rtol=0) | np.isclose(
                theta, theta_max, atol=tolerance, rtol=0)
            boundary_parameters[arm] += int(on_boundary.sum())
            parameter_counts[arm] += int(theta.size)
            boundary_basins[arm] += int(on_boundary.any())
            selected_step_zero[arm] += int(result["selected_step"] == 0)
        flow = record["flow_history"]
        flow_fit_nse = None if fit_variance <= 0 else float(1.0 - float(flow["fit_mse"]) / fit_variance)
        flow_selection_nse = _nse_from_reference(float(original["selection_nse"]),
                                                 float(original["selection_mse"]),
                                                 float(flow["selection_mse"]))
        if flow_fit_nse is not None:
            periods["fit"]["flow_history"].append(flow_fit_nse - float(original["fit_nse"]))
        if flow_selection_nse is not None:
            periods["selection"]["flow_history"].append(flow_selection_nse - float(original["selection_nse"]))
    count = len(fit_records)
    return {
        "delta_nse_medians": {
            period: {arm: float(np.median(values)) if values else None for arm, values in arm_values.items()}
            for period, arm_values in periods.items()
        },
        "selected_parameter_boundary_fraction": {
            arm: boundary_parameters[arm] / parameter_counts[arm] if parameter_counts[arm] else None for arm in arms
        },
        "basin_with_boundary_parameter_fraction": {
            arm: boundary_basins[arm] / count if count else None for arm in arms
        },
        "selected_at_step_zero_fraction": {
            arm: selected_step_zero[arm] / count if count else None for arm in arms
        },
    }


def _delta_summary(values: list[float] | np.ndarray) -> dict:
    array = np.asarray(values, dtype=np.float64)
    array = array[np.isfinite(array)]
    if len(array) == 0:
        return {"count": 0, "median": None, "quantiles_10_50_90": [], "win_fraction": None,
                "drop_below_minus_0_02_fraction": None}
    return {
        "count": int(len(array)),
        "median": float(np.median(array)),
        "quantiles_10_50_90": np.quantile(array, [0.1, 0.5, 0.9]).astype(float).tolist(),
        "win_fraction": float(np.mean(array > 0)),
        "drop_below_minus_0_02_fraction": float(np.mean(array < -0.02)),
    }


def score_stage(protocol: Protocol) -> dict:
    """Verify the frozen record, then and only then parse scoring discharge."""
    prepared = verify_run_manifest(protocol, technical=False)
    frozen = verify_frozen(protocol)
    if frozen.get("basins") != prepared.get("allowed_basins") or len(frozen.get("basins", [])) != 96:
        raise RuntimeError("Formal scoring requires the exact prepared 96-basin list")
    claim_task(protocol.output_dir / "locks" / "score.lock", {"stage": "score"})
    score_dir = protocol.output_dir / "score"
    if (score_dir / "summary.json").exists() or (score_dir / "per_basin_period.csv").exists():
        raise FileExistsError(f"Refusing to overwrite an existing score: {score_dir}")
    basins = list(frozen["basins"])
    draw = json.loads(protocol.basin_draw_file.read_text(encoding="utf-8"))["basins"]
    stratum = {basin: group for group, members in draw.items() for basin in members}
    huc2 = _load_huc2(protocol, basins)
    rows: list[dict] = []
    exclusions: list[dict] = []
    fit_records: dict[str, dict] = {}
    arms = ("original", "rain_season", "rain_intensity", "flow_history")
    for basin in basins:
        prediction_path = protocol.output_dir / "predictions" / f"{basin}.npz"
        with np.load(prediction_path) as data:
            dates = data["date"].astype("datetime64[D]")
            predictions = {arm: data[arm].astype(np.float64) for arm in arms}
        fit_record = json.loads((protocol.output_dir / "fit" / f"{basin}.json").read_text(encoding="utf-8"))
        fit_records[basin] = fit_record
        forcing = read_maurer_forcing(protocol.data_dir, basin, protocol.forcing_start, protocol.select_end)
        if forcing.canonical_sha256 != fit_record["forcing_sha256"]:
            raise RuntimeError(f"{basin}: fitting-period forcing changed before scoring")
        snow_fraction = _low_snow_fraction(forcing.dates, forcing.values, forcing.names,
                                           protocol.fit_start, protocol.fit_end)
        snow_class = "unknown" if snow_fraction is None else ("low_snow" if snow_fraction < 0.15 else "snowy")
        score_flow = read_flow_slice(protocol.data_dir, basin, int(fit_record["area_m2"]),
                                     protocol.score_start, protocol.score_end)
        positions = np.searchsorted(score_flow.dates, dates)
        if not np.array_equal(score_flow.dates[positions], dates):
            raise ValueError(f"{basin}: prediction and scoring dates do not align")
        observed = score_flow.values_mm_day[positions]
        common = np.isfinite(observed)
        for arm in arms:
            common &= np.isfinite(predictions[arm])
        year_labels = np.asarray([_year_label(current) for current in dates])
        year_coverage, year_variance, overall_variance, quality_valid = _score_quality(
            observed, common, year_labels)
        if not quality_valid:
            exclusions.append({"basin": basin, "reason": "score coverage below 70% or zero annual variance",
                               "year_coverage": year_coverage,
                               "year_variance": year_variance,
                               "overall_variance": overall_variance,
                               "score_flow_sha256": score_flow.canonical_sha256})
            continue
        for period in ("all", *sorted(np.unique(year_labels))):
            mask = common if period == "all" else common & (year_labels == period)
            row = {"basin": basin, "period": period, "n": int(mask.sum()),
                   "stratum": stratum.get(basin, "unknown"), "huc2": huc2.get(basin, "unknown"),
                   "snow_class": snow_class, "fit_snow_precipitation_fraction": snow_fraction,
                   "score_flow_sha256": score_flow.canonical_sha256}
            for arm in arms:
                values = predictions[arm][mask]
                row[f"nse_{arm}"] = _nse(observed[mask], values)
                row[f"nse_clipped_{arm}"] = _nse(observed[mask], np.maximum(values, 0.0))
                row[f"negative_fraction_{arm}"] = float(np.mean(values < 0))
            for arm in arms[1:]:
                row[f"delta_{arm}"] = row[f"nse_{arm}"] - row["nse_original"]
            rows.append(row)
    score_dir.mkdir(parents=True, exist_ok=True)
    if rows:
        with (score_dir / "per_basin_period.csv").open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    write_json_atomic(score_dir / "exclusions.json", {"excluded": exclusions})
    overall = [row for row in rows if row["period"] == "all"]
    annual = [row for row in rows if row["period"] != "all"]
    main = np.asarray([row["delta_rain_intensity"] for row in overall], dtype=np.float64)
    annual_medians = {period: float(np.median([row["delta_rain_intensity"] for row in annual
                                               if row["period"] == period]))
                      for period in sorted({row["period"] for row in annual})}
    groups = np.asarray([row["huc2"] for row in overall])
    sign_p = _sign_flip(main, groups, protocol.seed) if len(main) else None
    bootstrap_interval = _cluster_bootstrap_median(main, groups, protocol.seed) if len(main) else []
    huc2_medians = {group: float(np.median([row["delta_rain_intensity"] for row in overall
                                            if row["huc2"] == group]))
                    for group in sorted({row["huc2"] for row in overall})}
    leave_one_huc2_out = {
        group: float(np.median([row["delta_rain_intensity"] for row in overall if row["huc2"] != group]))
        for group in sorted({row["huc2"] for row in overall})
        if any(row["huc2"] != group for row in overall)
    }
    pipeline_complete = len(overall) + len(exclusions) == 96
    analysis_eligible = (len(overall) >= 60 and
                         all(sum(row["stratum"] == group for row in overall) >= 20
                             for group in ("j_negative", "west", "rest")))
    summary = {
        "stage": "score",
        "technical_complete": pipeline_complete,
        "analysis_eligible": analysis_eligible,
        "included_basins": len(overall),
        "excluded_basins": len(exclusions),
        "main_delta_median": float(np.median(main)) if len(main) else None,
        "main_delta_quantiles_10_50_90": np.quantile(main, [0.1, 0.5, 0.9]).tolist() if len(main) else [],
        "main_win_fraction": float(np.mean(main > 0)) if len(main) else None,
        "main_drop_below_minus_0_02_fraction": float(np.mean(main < -0.02)) if len(main) else None,
        "annual_main_delta_medians": annual_medians,
        "years_positive": int(sum(value > 0 for value in annual_medians.values())),
        "working_threshold_pass": bool(pipeline_complete and analysis_eligible and len(main)
                                        and np.median(main) >= 0.005
                                       and sum(value > 0 for value in annual_medians.values()) >= 3),
        "huc2_sign_flip_p_two_sided": sign_p,
        "huc2_bootstrap_median_95_interval": bootstrap_interval,
        "huc2_main_delta_medians": huc2_medians,
        "leave_one_huc2_out_main_delta_medians": leave_one_huc2_out,
        "arm_delta_medians": {arm: float(np.median([row[f"delta_{arm}"] for row in overall]))
                              for arm in arms[1:]} if overall else {},
        "stratum_main_delta_medians": {group: float(np.median([row["delta_rain_intensity"] for row in overall
                                                               if row["stratum"] == group]))
                                       for group in ("j_negative", "west", "rest")
                                       if any(row["stratum"] == group for row in overall)},
        "stratum_main_delta_summary": {
            group: _delta_summary([row["delta_rain_intensity"] for row in overall if row["stratum"] == group])
            for group in ("j_negative", "west", "rest")
        },
        "snow_class_main_delta_medians": {
            group: float(np.median([row["delta_rain_intensity"] for row in overall
                                    if row["snow_class"] == group]))
            for group in ("low_snow", "snowy") if any(row["snow_class"] == group for row in overall)
        },
        "snow_class_main_delta_summary": {
            group: _delta_summary([row["delta_rain_intensity"] for row in overall
                                   if row["snow_class"] == group])
            for group in ("low_snow", "snowy", "unknown")
        },
        "fit_selection_diagnostics": _fit_selection_diagnostics(
            fit_records, float(np.log(protocol.multiplier_min)), float(np.log(protocol.multiplier_max))),
    }
    write_json_atomic(score_dir / "summary.json", summary)
    return summary
