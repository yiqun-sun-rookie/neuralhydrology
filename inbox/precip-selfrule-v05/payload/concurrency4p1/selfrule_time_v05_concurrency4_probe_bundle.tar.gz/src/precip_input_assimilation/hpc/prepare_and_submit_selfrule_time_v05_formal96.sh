#!/usr/bin/env bash
# Promote the exact validated four-process batch-128 package and submit the 96-basin array.
set -eo pipefail

ROOT=/data1/home/sunyiq/precip_input_selfrule_time_v05_formal96_20260929
PROBE_ROOT=/data1/home/sunyiq/precip_input_selfrule_time_v05_concurrency4_probe_20260929
CODE="$ROOT/code"
ASSET="$ROOT/assets/c4_s100"
DATA="$HOME/neuralhydrology/data/camels_us"
OUT="$ROOT/formal_96/run01"
PROTOCOL="$CODE/src/precip_input_assimilation/configs/selfrule_time_v05.yml"
SCRIPT="$CODE/src/precip_input_assimilation/scripts/run_selfrule_time_v05.py"
PROBE_GATE="$PROBE_ROOT/candidate_concurrency4/run01/concurrency_probe_comparison.json"
PROBE_MANIFEST="$PROBE_ROOT/candidate_concurrency4/run01/RUN_MANIFEST.json"
PROBE_SUBMISSION="$PROBE_ROOT/submission.txt"
TECHNICAL_SUMMARY=/data1/home/sunyiq/precip_input_selfrule_time_v05_20260929_r03/technical_8/run01/technical_summary.json
EXPECTED_PROBE_GATE_SHA256=${EXPECTED_PROBE_GATE_SHA256:?EXPECTED_PROBE_GATE_SHA256 is required}
EXPECTED_PROBE_MANIFEST_SHA256=${EXPECTED_PROBE_MANIFEST_SHA256:?EXPECTED_PROBE_MANIFEST_SHA256 is required}
EXPECTED_TECHNICAL_SUMMARY_SHA256=${EXPECTED_TECHNICAL_SUMMARY_SHA256:?EXPECTED_TECHNICAL_SUMMARY_SHA256 is required}
CUMULATIVE_GPU_SECONDS_BEFORE_FORMAL=${CUMULATIVE_GPU_SECONDS_BEFORE_FORMAL:?CUMULATIVE_GPU_SECONDS_BEFORE_FORMAL is required}

test -f "$SCRIPT" || { echo "SCRIPT_MISSING"; exit 1; }
test -f "$ASSET/model_epoch030.pt" || { echo "WEIGHT_MISSING"; exit 1; }
test ! -e "$OUT" || { echo "FORMAL_OUTPUT_ALREADY_EXISTS"; exit 1; }
test -f "$PROBE_GATE" || { echo "PROBE_GATE_MISSING"; exit 1; }
test -f "$PROBE_MANIFEST" || { echo "PROBE_MANIFEST_MISSING"; exit 1; }
test -f "$PROBE_SUBMISSION" || { echo "PROBE_SUBMISSION_MISSING"; exit 1; }
test -f "$TECHNICAL_SUMMARY" || { echo "TECHNICAL_SUMMARY_MISSING"; exit 1; }
mkdir -p "$ROOT/logs"

case "$CUMULATIVE_GPU_SECONDS_BEFORE_FORMAL" in
  ''|*[!0-9]*) echo "CUMULATIVE_GPU_SECONDS_MUST_BE_INTEGER"; exit 1 ;;
esac
probe_job=$(awk -F= '$1 == "concurrency_probe_job" { print $2 }' "$PROBE_SUBMISSION")
case "$probe_job" in
  ''|*[!0-9]*) echo "PROBE_JOB_ID_INVALID"; exit 1 ;;
esac
mapfile -t probe_rows < <(sacct -j "$probe_job" --noheader --parsable2 \
  --format=JobIDRaw,State,ExitCode,ElapsedRaw | awk -F'|' -v job="$probe_job" '$1 == job { print }')
test "${#probe_rows[@]}" -eq 1 || { echo "PROBE_TOP_LEVEL_SACCT_RECORD_COUNT=${#probe_rows[@]}"; exit 1; }
IFS='|' read -r recorded_probe_job probe_state probe_exit_code probe_elapsed _ <<< "${probe_rows[0]}"
test "$recorded_probe_job" = "$probe_job" || { echo "PROBE_JOB_ID_MISMATCH"; exit 1; }
test "$probe_state" = "COMPLETED" || { echo "PROBE_NOT_COMPLETED state=$probe_state"; exit 1; }
test "$probe_exit_code" = "0:0" || { echo "PROBE_EXIT_CODE_FAILED=$probe_exit_code"; exit 1; }
case "$probe_elapsed" in
  ''|*[!0-9]*) echo "PROBE_ELAPSED_UNAVAILABLE"; exit 1 ;;
esac
expected_cumulative=$((4794 + probe_elapsed))
test "$CUMULATIVE_GPU_SECONDS_BEFORE_FORMAL" -eq "$expected_cumulative" || {
  echo "CUMULATIVE_GPU_SECONDS_NOT_EXACT expected=$expected_cumulative actual=$CUMULATIVE_GPU_SECONDS_BEFORE_FORMAL"
  exit 1
}
slurm_config=$(scontrol show config)
kill_wait=$(awk -F= '/^[[:space:]]*KillWait[[:space:]]*=/ {
  value=$2; gsub(/^[[:space:]]+|[[:space:]]+$/, "", value); print value; exit
}' <<< "$slurm_config")
over_time_limit=$(awk -F= '/^[[:space:]]*OverTimeLimit[[:space:]]*=/ {
  value=$2; gsub(/^[[:space:]]+|[[:space:]]+$/, "", value); print value; exit
}' <<< "$slurm_config")
test "$kill_wait" = "30 sec" || { echo "UNEXPECTED_SLURM_KILL_WAIT=$kill_wait"; exit 1; }
test "$over_time_limit" = "0 min" || { echo "UNEXPECTED_SLURM_OVER_TIME_LIMIT=$over_time_limit"; exit 1; }

python - "$PROBE_GATE" "$PROBE_MANIFEST" "$CODE" "$EXPECTED_PROBE_GATE_SHA256" \
  "$EXPECTED_PROBE_MANIFEST_SHA256" "$TECHNICAL_SUMMARY" "$EXPECTED_TECHNICAL_SUMMARY_SHA256" \
  "$CUMULATIVE_GPU_SECONDS_BEFORE_FORMAL" <<'PY'
import hashlib
import json
import pathlib
import sys

gate_path = pathlib.Path(sys.argv[1])
manifest_path = pathlib.Path(sys.argv[2])
code_root = pathlib.Path(sys.argv[3])
expected_gate_hash = sys.argv[4]
expected_manifest_hash = sys.argv[5]
technical_path = pathlib.Path(sys.argv[6])
expected_technical_hash = sys.argv[7]
cumulative_gpu_seconds = float(sys.argv[8])
for path, expected, label in (
        (gate_path, expected_gate_hash, "PROBE_GATE"),
        (manifest_path, expected_manifest_hash, "PROBE_MANIFEST"),
        (technical_path, expected_technical_hash, "TECHNICAL_SUMMARY")):
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise SystemExit(f"{label}_HASH_MISMATCH")

gate = json.loads(gate_path.read_text(encoding="utf-8"))
if gate.get("passed") is not True or gate.get("equivalence_passed") is not True:
    raise SystemExit("CONCURRENCY_PROBE_NOT_PASSED")
if gate.get("resource_line_passed") is not True:
    raise SystemExit("CONCURRENCY_RESOURCE_LINE_NOT_PASSED")
technical = json.loads(technical_path.read_text(encoding="utf-8"))
if technical.get("technical_complete") is not True or technical.get("basin_count") != 8:
    raise SystemExit("EIGHT_BASIN_TECHNICAL_SUMMARY_INCOMPLETE")
minimum_consumed = (float(gate["cumulative_gpu_seconds_before_probe"])
                    + float(gate["group_fit_plus_predict_seconds"]))
if cumulative_gpu_seconds < minimum_consumed:
    raise SystemExit("CUMULATIVE_GPU_SECONDS_UNDERREPORTED")
group_seconds = float(gate["group_fit_plus_predict_seconds"])
eight_times = [float(row["elapsed_seconds"]) for row in technical["basins"]]
variation_guard = max(1.05, max(eight_times) / (sum(eight_times) / len(eight_times)))
formal_seconds = group_seconds * 24.0 * variation_guard + 15.0 * 24.0
projected_total = cumulative_gpu_seconds + formal_seconds
if projected_total > 6.0 * 3600.0:
    raise SystemExit(f"CUMULATIVE_GPU_BUDGET_EXCEEDED projected_seconds={projected_total:.1f}")
termination_reserve_seconds_per_task = 60
remaining_after_reserve = (6.0 * 3600.0 - cumulative_gpu_seconds
                           - 24.0 * termination_reserve_seconds_per_task)
formal_task_minutes = int(remaining_after_reserve // (24.0 * 60.0))
projected_task_seconds = group_seconds * variation_guard + 15.0
if formal_task_minutes < 1 or projected_task_seconds > formal_task_minutes * 60.0:
    raise SystemExit("FORMAL_INTEGER_MINUTE_HARD_WINDOW_INSUFFICIENT "
                     f"limit_minutes={formal_task_minutes} projected_task_seconds={projected_task_seconds:.1f}")

probe_manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
marker = "/src/precip_input_assimilation/"
checked = 0
for entry in probe_manifest.get("source_files", []):
    prepared_path = str(entry.get("path", "")).replace("\\", "/")
    if marker not in prepared_path:
        continue
    relative = "src/precip_input_assimilation/" + prepared_path.split(marker, 1)[1]
    promoted_path = code_root / relative
    if (not promoted_path.is_file() or promoted_path.stat().st_size != int(entry["bytes"])
            or hashlib.sha256(promoted_path.read_bytes()).hexdigest() != entry["sha256"]):
        raise SystemExit(f"PROMOTED_SOURCE_MISMATCH {relative}")
    checked += 1
if checked == 0:
    raise SystemExit("NO_PROMOTED_SOURCE_FILES_CHECKED")
print("CONCURRENCY_PROMOTION_GATE_OK", "SOURCE_FILES_CHECKED", checked,
      "PROJECTED_CUMULATIVE_GPU_SECONDS", round(projected_total, 1),
      "FORMAL_TASK_TIME_LIMIT_MINUTES", formal_task_minutes)
PY

source /data1/home/${USER}/miniconda3/etc/profile.d/conda.sh || \
source "$HOME/miniconda3/etc/profile.d/conda.sh"
conda activate nh_final || { echo "CONDA_FAILED"; exit 1; }
export PYTHONPATH="$CODE/src:$HOME/neuralhydrology:${PYTHONPATH:-}"

python -u "$SCRIPT" prepare \
  --protocol "$PROTOCOL" \
  --device cuda:0 \
  --data-dir "$DATA" \
  --run-dir "$ASSET" \
  --output-dir "$OUT"

python - "$PROBE_MANIFEST" "$OUT/RUN_MANIFEST.json" <<'PY'
import json
import pathlib
import sys

probe_path, formal_path = map(pathlib.Path, sys.argv[1:])
probe = json.loads(probe_path.read_text(encoding="utf-8"))
formal = json.loads(formal_path.read_text(encoding="utf-8"))
for key in ("schema", "protocol", "scope", "intended_device", "allowed_basins", "runtime"):
    if probe.get(key) != formal.get(key):
        raise SystemExit(f"PROMOTION_MANIFEST_FIELD_MISMATCH {key}")
path_fields = {"repo_root", "protocol_file", "data_dir", "run_dir", "basin_file",
               "technical_basin_file", "basin_draw_file", "output_dir"}
probe_protocol = {key: value for key, value in probe["effective_protocol"].items() if key not in path_fields}
formal_protocol = {key: value for key, value in formal["effective_protocol"].items() if key not in path_fields}
if probe_protocol != formal_protocol or int(formal_protocol["batch_targets"]) != 128:
    raise SystemExit("PROMOTION_EFFECTIVE_PROTOCOL_MISMATCH")
if probe["effective_protocol"]["data_dir"] != formal["effective_protocol"]["data_dir"]:
    raise SystemExit("PROMOTION_DATA_DIR_MISMATCH")
probe_inputs = [(entry["bytes"], entry["sha256"]) for entry in probe["frozen_inputs"]]
formal_inputs = [(entry["bytes"], entry["sha256"]) for entry in formal["frozen_inputs"]]
if probe_inputs != formal_inputs:
    raise SystemExit("PROMOTION_FROZEN_INPUTS_MISMATCH")

marker = "/src/precip_input_assimilation/"
def source_map(manifest):
    result = {}
    for entry in manifest["source_files"]:
        path = str(entry["path"]).replace("\\", "/")
        key = "idea/" + path.split(marker, 1)[1] if marker in path else path
        if key in result:
            raise SystemExit(f"PROMOTION_DUPLICATE_SOURCE {key}")
        result[key] = (entry["bytes"], entry["sha256"])
    return result

if source_map(probe) != source_map(formal):
    raise SystemExit("PROMOTION_SOURCE_MANIFEST_MISMATCH")
print("FORMAL_MANIFEST_EXACTLY_MATCHES_CONCURRENCY_PROBE")
PY

remaining_gpu_seconds=$((6 * 3600 - CUMULATIVE_GPU_SECONDS_BEFORE_FORMAL))
termination_reserve_seconds_per_task=60
remaining_after_reserve=$((remaining_gpu_seconds - 24 * termination_reserve_seconds_per_task))
formal_task_minutes=$((remaining_after_reserve / (24 * 60)))
test "$formal_task_minutes" -ge 1 || { echo "FORMAL_TASK_BUDGET_BELOW_ONE_MINUTE"; exit 1; }
submit=$(sbatch --hold --time="$formal_task_minutes" \
  "$CODE/src/precip_input_assimilation/hpc/selfrule_time_v05_formal96.slurm" 2>&1)
echo "$submit"
if [[ "$submit" =~ ^Submitted\ batch\ job\ ([0-9]+)$ ]]; then
  job=${BASH_REMATCH[1]}
else
  echo "FORMAL_SBATCH_FAILED"
  exit 1
fi
final_submit=$(sbatch --dependency="afterok:$job" \
  "$CODE/src/precip_input_assimilation/hpc/selfrule_time_v05_finalize.slurm" 2>&1)
echo "$final_submit"
if [[ "$final_submit" =~ ^Submitted\ batch\ job\ ([0-9]+)$ ]]; then
  final_job=${BASH_REMATCH[1]}
else
  echo "FINALIZE_SBATCH_FAILED"
  scancel "$job" || true
  exit 1
fi
if ! release_output=$(scontrol release "$job" 2>&1); then
  echo "$release_output"
  echo "FORMAL_ARRAY_RELEASE_FAILED"
  scancel "$job" "$final_job" || true
  exit 1
fi
echo "$release_output"
printf 'formal_array_job=%s\nfinalize_job=%s\nfinalize_dependency=afterok:%s\nprobe_gate=%s\nprobe_job=%s\nprobe_elapsed_seconds=%s\ncumulative_gpu_seconds_before_formal=%s\nformal_task_time_limit_minutes=%s\nslurm_kill_wait=%s\nslurm_over_time_limit=%s\ntermination_reserve_seconds_per_task=%s\n' \
  "$job" "$final_job" "$job" "$PROBE_GATE" "$probe_job" "$probe_elapsed" \
  "$CUMULATIVE_GPU_SECONDS_BEFORE_FORMAL" "$formal_task_minutes" "$kill_wait" "$over_time_limit" \
  "$termination_reserve_seconds_per_task" \
  > "$ROOT/submission.txt"
echo "FORMAL_ARRAY_JOB_ID=$job"
echo "FINALIZE_JOB_ID=$final_job"
squeue -j "$job,$final_job" -o "%.22i %.24j %.10P %.2t %.10M %.6D %R"
