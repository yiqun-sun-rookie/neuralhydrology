#!/usr/bin/env bash
# Prepare a fresh formal-scope manifest, then submit one conservative one-GPU concurrency probe.
set -eo pipefail

ROOT=/data1/home/sunyiq/precip_input_selfrule_time_v05_concurrency4_probe_20260929
CODE="$ROOT/code"
ASSET="$ROOT/assets/c4_s100"
DATA="$HOME/neuralhydrology/data/camels_us"
OUT="$ROOT/candidate_concurrency4/run01"
PROTOCOL="$CODE/src/precip_input_assimilation/configs/selfrule_time_v05.yml"
SCRIPT="$CODE/src/precip_input_assimilation/scripts/run_selfrule_time_v05.py"

test -f "$SCRIPT" || { echo "SCRIPT_MISSING"; exit 1; }
test -f "$ASSET/model_epoch030.pt" || { echo "WEIGHT_MISSING"; exit 1; }
test ! -e "$OUT" || { echo "CONCURRENCY_PROBE_OUTPUT_ALREADY_EXISTS"; exit 1; }
mkdir -p "$ROOT/logs"

source /data1/home/${USER}/miniconda3/etc/profile.d/conda.sh || \
source "$HOME/miniconda3/etc/profile.d/conda.sh"
conda activate nh_final || { echo "CONDA_FAILED"; exit 1; }
export PYTHONPATH="$CODE/src:$HOME/neuralhydrology:${PYTHONPATH:-}"

python -u "$SCRIPT" prepare \
  --protocol "$PROTOCOL" \
  --device cuda:0 \
  --data-dir "$DATA" \
  --run-dir "$ASSET" \
  --output-dir "$OUT"

submit=$(sbatch "$CODE/src/precip_input_assimilation/hpc/selfrule_time_v05_concurrency4_probe.slurm" 2>&1)
echo "$submit"
if [[ "$submit" =~ ^Submitted\ batch\ job\ ([0-9]+)$ ]]; then
  job=${BASH_REMATCH[1]}
else
  echo "CONCURRENCY_PROBE_SBATCH_FAILED"
  exit 1
fi
printf 'concurrency_probe_job=%s\ncumulative_gpu_seconds_before_probe=4794\n' "$job" > "$ROOT/submission.txt"
echo "CONCURRENCY_PROBE_JOB_ID=$job"
squeue -j "$job" -o "%.22i %.24j %.10P %.2t %.10M %.6D %R"
