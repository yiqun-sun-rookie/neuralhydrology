#!/usr/bin/env bash
# Prepare two source-identical probe runs, then submit them behind the completed eight-basin array.
set -eo pipefail

ROOT=/data1/home/sunyiq/precip_input_selfrule_time_v05_batch384_probe_20260929
CODE="$ROOT/code"
ASSET="$ROOT/assets/c4_s100"
DATA="$HOME/neuralhydrology/data/camels_us"
REFERENCE_OUT="$ROOT/reference_batch128/run01"
CANDIDATE_OUT="$ROOT/candidate_batch384/run01"
SCRIPT="$CODE/src/precip_input_assimilation/scripts/run_selfrule_time_v05.py"
REFERENCE_PROTOCOL="$CODE/src/precip_input_assimilation/configs/selfrule_time_v05.yml"
CANDIDATE_PROTOCOL="$CODE/src/precip_input_assimilation/configs/selfrule_time_v05_batch384_probe.yml"
DEPENDENCY_JOB_ID=${DEPENDENCY_JOB_ID:?DEPENDENCY_JOB_ID is required}

test -f "$SCRIPT" || { echo "SCRIPT_MISSING"; exit 1; }
test -f "$ASSET/model_epoch030.pt" || { echo "WEIGHT_MISSING"; exit 1; }
test ! -e "$REFERENCE_OUT" || { echo "REFERENCE_OUTPUT_ALREADY_EXISTS"; exit 1; }
test ! -e "$CANDIDATE_OUT" || { echo "CANDIDATE_OUTPUT_ALREADY_EXISTS"; exit 1; }
mkdir -p "$ROOT/logs"

source /data1/home/${USER}/miniconda3/etc/profile.d/conda.sh || \
source "$HOME/miniconda3/etc/profile.d/conda.sh"
conda activate nh_final || { echo "CONDA_FAILED"; exit 1; }
export PYTHONPATH="$CODE/src:$HOME/neuralhydrology:${PYTHONPATH:-}"

python -u "$SCRIPT" prepare \
  --protocol "$REFERENCE_PROTOCOL" \
  --device cuda:0 \
  --data-dir "$DATA" \
  --run-dir "$ASSET" \
  --output-dir "$REFERENCE_OUT"

python -u "$SCRIPT" prepare \
  --protocol "$CANDIDATE_PROTOCOL" \
  --device cuda:0 \
  --data-dir "$DATA" \
  --run-dir "$ASSET" \
  --output-dir "$CANDIDATE_OUT"

submit=$(sbatch --dependency="afterok:$DEPENDENCY_JOB_ID" \
  "$CODE/src/precip_input_assimilation/hpc/selfrule_time_v05_batch384_probe.slurm")
case "$submit" in
  "Submitted batch job "*) ;;
  *) echo "PROBE_SBATCH_FAILED $submit"; exit 1 ;;
esac
job=${submit##* }
printf 'probe_job=%s\ndependency=afterok:%s\n' "$job" "$DEPENDENCY_JOB_ID" > "$ROOT/submission.txt"
echo "PROBE_JOB_ID=$job"
squeue -j "$job" -o "%.22i %.24j %.10P %.2t %.10M %.6D %R"
