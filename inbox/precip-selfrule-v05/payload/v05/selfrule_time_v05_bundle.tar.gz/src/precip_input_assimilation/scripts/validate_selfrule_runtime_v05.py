"""Run model-level checks that require the real frozen C4 network and forcing."""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import replace
from datetime import date
from pathlib import Path

import numpy as np
import torch

REPO_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO_ROOT / "src"))

from precip_input_assimilation.selfrule.data import (load_normalization, load_normalized_attributes,  # noqa: E402
                                                      read_maurer_forcing, slice_indices)
from precip_input_assimilation.selfrule.model import FrozenC4, configure_determinism  # noqa: E402
from precip_input_assimilation.selfrule.manifest import verify_run_manifest  # noqa: E402
from precip_input_assimilation.selfrule.protocol import load_protocol, validate_protocol  # noqa: E402
from precip_input_assimilation.selfrule.rules import build_rain_rule, parameter_index_by_day  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", type=Path,
                        default=REPO_ROOT / "src/precip_input_assimilation/configs/selfrule_time_v05.yml")
    parser.add_argument("--data-dir", type=Path)
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--basin", default="02137727")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def _theta_gradient(runner: FrozenC4,
                    raw: torch.Tensor,
                    static: torch.Tensor,
                    targets: np.ndarray,
                    parameter_indices: torch.Tensor,
                    n_parameters: int,
                    batch: int | None = None) -> np.ndarray:
    theta = torch.zeros(n_parameters, dtype=torch.float32, device=runner.device, requires_grad=True)
    size = len(targets) if batch is None else batch
    for offset in range(0, len(targets), size):
        current = torch.as_tensor(targets[offset:offset + size], device=runner.device)
        prediction = runner.predict(raw, static, current, parameter_indices, theta)
        prediction.square().sum().backward()
    if theta.grad is None:
        raise RuntimeError("Rain multiplier received no gradient")
    return theta.grad.detach().cpu().numpy().copy()


def main() -> None:
    args = parse_args()
    protocol = load_protocol(args.protocol, repo_root=REPO_ROOT)
    updates = {}
    if args.data_dir:
        updates["data_dir"] = args.data_dir.resolve()
    if args.run_dir:
        updates["run_dir"] = args.run_dir.resolve()
    updates["output_dir"] = args.output_dir.resolve()
    if updates:
        protocol = replace(protocol, **updates)
    validate_protocol(protocol, verify_files=True)
    verify_run_manifest(protocol, technical=True, requested_basins=[args.basin], device=args.device)
    configure_determinism(protocol.seed)
    _, names, center, scale, q_center, q_scale = load_normalization(protocol.run_dir)
    runner = FrozenC4(protocol.run_dir, args.device, names, center, scale, q_center, q_scale)
    forcing = read_maurer_forcing(protocol.data_dir, args.basin, protocol.forcing_start, protocol.select_end)
    static_values = load_normalized_attributes(protocol.data_dir, protocol.run_dir, [args.basin])[0]
    raw = torch.as_tensor(forcing.values, dtype=torch.float32, device=runner.device)
    static = torch.as_tensor(static_values, dtype=torch.float32, device=runner.device)
    fit_mask = ((forcing.dates >= np.datetime64(protocol.fit_start)) &
                (forcing.dates <= np.datetime64(protocol.fit_end)))
    rule = build_rain_rule("rain_intensity", forcing.dates, forcing.values[:, 0], protocol.fit_start,
                           protocol.fit_end, fit_mask, protocol.wet_threshold_mm, protocol.min_bin_support)
    day_index = torch.as_tensor(parameter_index_by_day(rule, forcing.dates, forcing.values[:, 0]),
                                dtype=torch.long, device=runner.device)
    candidate_targets = slice_indices(forcing.dates, date(1985, 8, 1), protocol.select_end)[-16:]
    targets = candidate_targets[candidate_targets >= runner.sequence_length - 1]
    target_tensor = torch.as_tensor(targets, device=runner.device)

    with torch.no_grad():
        original = runner.predict(raw, static, target_tensor)
        zero = runner.predict(raw, static, target_tensor, day_index,
                              torch.zeros(rule.n_parameters, device=runner.device))
        repeated = runner.predict(raw, static, target_tensor)
    identity_max_abs = float(torch.max(torch.abs(original - zero)).cpu())
    repeat_max_abs = float(torch.max(torch.abs(original - repeated)).cpu())
    if not torch.allclose(original, zero, rtol=1e-5, atol=1e-5):
        raise RuntimeError(f"Identity rule mismatch: {identity_max_abs}")
    if not torch.equal(original, repeated):
        raise RuntimeError(f"Repeated frozen forward is not stable: {repeat_max_abs}")

    full_gradient = _theta_gradient(runner, raw, static, targets, day_index, rule.n_parameters)
    micro_gradient = _theta_gradient(runner, raw, static, targets, day_index, rule.n_parameters, batch=4)
    gradient_max_abs = float(np.max(np.abs(full_gradient - micro_gradient)))
    if not np.allclose(full_gradient, micro_gradient, rtol=1e-5, atol=1e-5):
        raise RuntimeError(f"Microbatch gradient mismatch: {gradient_max_abs}")
    if not np.isfinite(full_gradient).all() or not np.any(full_gradient != 0):
        raise RuntimeError("Rain multiplier gradient is missing or non-finite")

    raw_leaf = raw.detach().clone().requires_grad_(True)
    single_target = torch.as_tensor(targets[-1:], device=runner.device)
    runner.predict(raw_leaf, static, single_target).sum().backward()
    window_start = int(targets[-1]) - runner.sequence_length + 1
    warmup_gradient = float(raw_leaf.grad[window_start, runner.precipitation_index].detach().cpu())
    if not np.isfinite(warmup_gradient) or warmup_gradient == 0:
        raise RuntimeError("The first warm-up precipitation day has no finite nonzero target gradient")
    if any(parameter.grad is not None for parameter in runner.model.parameters()):
        raise RuntimeError("A frozen model weight received a gradient")
    if runner.model.dropout.training or runner.model.training:
        raise RuntimeError("Output dropout or the full model was left in training mode")

    payload = {
        "protocol": "selfrule_time_v05",
        "basin": args.basin,
        "device": args.device,
        "identity_max_abs": identity_max_abs,
        "repeat_max_abs": repeat_max_abs,
        "multiplier_gradient_max_abs": float(np.max(np.abs(full_gradient))),
        "microbatch_gradient_max_abs_difference": gradient_max_abs,
        "first_warmup_day_precipitation_gradient": warmup_gradient,
        "frozen_weight_gradient_count": 0,
        "dropout_training": runner.model.dropout.training,
        "full_model_training": runner.model.training,
        "recurrent_module_training": runner.model.lstm.training,
        "passed": True,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    descriptor = args.output.open("x", encoding="utf-8", newline="\n")
    with descriptor:
        json.dump(payload, descriptor, indent=2, sort_keys=True, allow_nan=False)
        descriptor.write("\n")
    print(json.dumps(payload, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()
