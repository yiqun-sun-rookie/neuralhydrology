"""Configuration block for input-space precipitation assimilation.

The block is deliberately a superset of the ID29 ``assimilation_config`` block (same key names, same defaults) so that
a Nearing-style state-assimilation block can be pasted in unchanged. The additional ``input_*`` keys switch on the
precipitation channel. The class exposes the handful of properties that ``neuralhydrology.training.get_loss_obj`` and
``get_optimizer`` read from a config object, so the frozen loss/optimizer factories can be reused without touching
ID29's ``AssimilationConfig``.
"""

from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from ruamel.yaml import YAML

_INPUT_TARGET_PREFIX = 'x_d:'


class InputAssimilationConfig(object):
    """Settings for one assimilation run (state targets, input target, or both).

    Parameters
    ----------
    yml_path_or_dict : Union[Path, dict]
        Path to a YAML file holding the block under the key ``input_assimilation_config`` (or the bare block), or a
        dict with the block itself.
    """

    # keys shared with the ID29 block (same semantics)
    _NEARING_KEYS = {
        'assimilation_lead_time', 'assimilation_targets', 'assimilation_window', 'history', 'epochs', 'learning_rate',
        'learning_rate_drop_factor', 'learning_rate_epoch_drop', 'loss', 'model_dropout', 'optimizer',
        'predict_last_n', 'regularization', 'seq_length', 'target_variables', 'timestep_dropout',
        'no_loss_frequencies', 'target_loss_weights'
    }
    # keys specific to this module
    _INPUT_KEYS = {
        'input_adjust_mode', 'input_adjust_days', 'input_skip_dry_days', 'input_dry_threshold_mm', 'input_l1_lambda',
        'input_l2_lambda', 'input_learning_rate_mm', 'steps_early_windows', 'lr_reset_per_window', 'accept_rule',
        'rollback_mode', 'export_input_adjustments'
    }
    _KNOWN_KEYS = _NEARING_KEYS | _INPUT_KEYS

    def __init__(self, yml_path_or_dict: Union[Path, dict]):
        if isinstance(yml_path_or_dict, Path):
            yaml = YAML(typ='safe')
            with yml_path_or_dict.open('r', encoding='utf-8') as fp:
                loaded = yaml.load(fp)
            if 'input_assimilation_config' in loaded:
                loaded = loaded['input_assimilation_config']
            self._cfg = dict(loaded)
        elif isinstance(yml_path_or_dict, dict):
            self._cfg = dict(yml_path_or_dict)
        else:
            raise ValueError(f'Cannot create a config from input of type {type(yml_path_or_dict)}.')

        unknown = sorted(k for k in self._cfg if k not in self._KNOWN_KEYS)
        if unknown:
            raise ValueError(f'{unknown} are not recognized input-assimilation config keys.')
        self._validate()

    # ------------------------------------------------------------------------------------------------------------
    def as_dict(self) -> dict:
        return dict(self._cfg)

    def _required(self, key: str) -> Any:
        if key not in self._cfg or self._cfg[key] is None:
            raise ValueError(f"'{key}' is mandatory in the input-assimilation config.")
        return self._cfg[key]

    @staticmethod
    def _as_list(value: Any) -> list:
        if value is None:
            return []
        return list(value) if isinstance(value, (list, tuple)) else [value]

    def _validate(self):
        targets = self.assimilation_targets
        input_targets = [t for t in targets if t.startswith(_INPUT_TARGET_PREFIX)]
        if len(input_targets) > 1:
            raise ValueError('At most one input target (x_d:<feature>) is supported.')
        if self.input_adjust_mode not in ('additive', 'multiplicative'):
            raise ValueError("input_adjust_mode must be 'additive' or 'multiplicative'.")
        if self.accept_rule not in ('batch', 'per_sample'):
            raise ValueError("accept_rule must be 'batch' or 'per_sample'.")
        if self.rollback_mode not in ('freeze', 'continue'):
            raise ValueError("rollback_mode must be 'freeze' or 'continue'.")
        days = self.input_adjust_days
        if not (days == 'all' or (isinstance(days, str) and days.startswith('t-') and days[2:].isdigit())):
            raise ValueError("input_adjust_days must be 'all' or 't-<k>' (k = days before the forecast day).")
        if self.timestep_dropout != 0.0:
            raise NotImplementedError('timestep_dropout > 0 is not supported by this module.')
        if self.input_learning_rate_mm is not None:
            if 'learning_rate' in self._cfg and self._cfg['learning_rate'] is not None:
                raise ValueError("Give either 'learning_rate' or 'input_learning_rate_mm', not both.")
            if self.state_targets or self.input_target is None or self.input_adjust_mode != 'additive':
                raise ValueError("'input_learning_rate_mm' is only valid for an additive, input-only run.")
        if self.steps_early_windows < 1:
            raise ValueError('steps_early_windows must be >= 1.')

    # --- Nearing-compatible keys --------------------------------------------------------------------------------
    @property
    def assimilation_lead_time(self) -> int:
        return int(self._required('assimilation_lead_time'))

    @property
    def assimilation_targets(self) -> List[str]:
        targets = self._as_list(self._cfg.get('assimilation_targets'))
        if not targets:
            raise ValueError('At least one assimilation target has to be specified.')
        return targets

    @property
    def assimilation_window(self) -> int:
        return int(self._required('assimilation_window'))

    @property
    def epochs(self) -> int:
        return int(self._cfg.get('epochs', 200))

    @property
    def history(self) -> int:
        return int(self._required('history'))

    @property
    def learning_rate(self) -> Dict[int, float]:
        """Learning rate in the units of the leaf tensors (states: state units; input: standardized precipitation).

        Only entry ``0`` is used. When ``input_learning_rate_mm`` is given instead, the caller (the assimilator, which
        knows the scaler) derives the standardized-space value.
        """
        value = self._cfg.get('learning_rate')
        if value is None:
            if self.input_learning_rate_mm is not None:
                raise ValueError("'learning_rate' is derived from 'input_learning_rate_mm' by the assimilator; "
                                 "call InputAssimilator to resolve it.")
            raise ValueError('No learning rate specified in the input-assimilation config.')
        if isinstance(value, (int, float)):
            return {0: float(value)}
        if isinstance(value, dict):
            return {int(k): float(v) for k, v in value.items()}
        raise ValueError('Unsupported learning rate type. Use a float or a dict (epoch -> float).')

    @property
    def learning_rate_drop_factor(self) -> float:
        return float(self._cfg.get('learning_rate_drop_factor', 0.9))

    @property
    def learning_rate_epoch_drop(self) -> int:
        return int(self._cfg.get('learning_rate_epoch_drop', 5))

    @property
    def loss(self) -> str:
        return self._required('loss')

    @property
    def model_dropout(self) -> bool:
        value = self._cfg.get('model_dropout', False)
        return bool(value) if value is not None else False

    @property
    def no_loss_frequencies(self) -> List[str]:
        return self._as_list(self._cfg.get('no_loss_frequencies', []))

    @property
    def optimizer(self) -> str:
        return self._required('optimizer')

    @property
    def predict_last_n(self) -> int:
        return int(self._required('predict_last_n'))

    @property
    def regularization(self) -> List[str]:
        return self._as_list(self._cfg.get('regularization', []))

    @property
    def seq_length(self) -> int:
        return int(self._required('seq_length'))

    @property
    def target_loss_weights(self) -> Optional[List[float]]:
        return self._cfg.get('target_loss_weights', None)

    @property
    def target_variables(self) -> List[str]:
        return self._as_list(self._required('target_variables'))

    @property
    def timestep_dropout(self) -> float:
        value = self._cfg.get('timestep_dropout', 0.0)
        return float(value) if value is not None else 0.0

    # --- derived target split -----------------------------------------------------------------------------------
    @property
    def state_targets(self) -> List[str]:
        """Model state names to optimize (e.g. ``['c_n']``)."""
        return [t for t in self.assimilation_targets if not t.startswith(_INPUT_TARGET_PREFIX)]

    @property
    def input_target(self) -> Optional[str]:
        """Name of the dynamic input feature to adjust (e.g. ``'PRCP(mm/day)'``), or None."""
        inputs = [t for t in self.assimilation_targets if t.startswith(_INPUT_TARGET_PREFIX)]
        return inputs[0][len(_INPUT_TARGET_PREFIX):] if inputs else None

    # --- input-channel keys -------------------------------------------------------------------------------------
    @property
    def input_adjust_mode(self) -> str:
        """'additive' (P + delta, delta in standardized space, clamped so P >= 0) or 'multiplicative' (P * k^4)."""
        return str(self._cfg.get('input_adjust_mode', 'additive'))

    @property
    def input_adjust_days(self) -> str:
        """'all' (every day of every window) or 't-<k>' (only the day k steps before the forecast day)."""
        return str(self._cfg.get('input_adjust_days', 'all'))

    @property
    def input_skip_dry_days(self) -> bool:
        return bool(self._cfg.get('input_skip_dry_days', False))

    @property
    def input_dry_threshold_mm(self) -> float:
        return float(self._cfg.get('input_dry_threshold_mm', 0.1))

    @property
    def input_l1_lambda(self) -> float:
        """Additive mode: weight of ``mean_batch(sum_days |delta_mm|)`` added to the loss."""
        return float(self._cfg.get('input_l1_lambda', 0.0))

    @property
    def input_l2_lambda(self) -> float:
        """Multiplicative mode: weight of ``mean_batch(sum_days (k - 1)^2)`` added to the loss."""
        return float(self._cfg.get('input_l2_lambda', 0.0))

    @property
    def input_learning_rate_mm(self) -> Optional[float]:
        value = self._cfg.get('input_learning_rate_mm', None)
        return float(value) if value is not None else None

    @property
    def steps_early_windows(self) -> int:
        """Max update steps in every window except the last. 6 reproduces ID29's ``epoch >= 5`` break."""
        return int(self._cfg.get('steps_early_windows', 6))

    @property
    def lr_reset_per_window(self) -> bool:
        """If True, the learning rate restarts at its initial value in every window (ID29 carries it over)."""
        return bool(self._cfg.get('lr_reset_per_window', False))

    @property
    def accept_rule(self) -> str:
        """'batch' (one accept/reject decision on the batch-mean loss, as ID29) or 'per_sample'."""
        return str(self._cfg.get('accept_rule', 'batch'))

    @property
    def rollback_mode(self) -> str:
        """'freeze' (ID29 behaviour: after the first rejected step the window stays at its last good state) or
        'continue' (roll back and keep optimizing with the reduced learning rate)."""
        return str(self._cfg.get('rollback_mode', 'freeze'))

    @property
    def export_input_adjustments(self) -> bool:
        return bool(self._cfg.get('export_input_adjustments', True))
