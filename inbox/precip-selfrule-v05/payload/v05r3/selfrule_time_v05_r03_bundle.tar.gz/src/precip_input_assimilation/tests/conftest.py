"""Shared fixtures: the toy 4-basin CudaLSTM run, an ID29-style copy of it, and one evaluation batch.

Run from the repo root:  pytest src/precip_input_assimilation/tests -q
"""
import os
import shutil
import sys
from pathlib import Path

import pytest
import torch
from ruamel.yaml import YAML
from torch.utils.data import DataLoader

REPO_ROOT = Path(__file__).resolve().parents[3]
SRC_ROOT = REPO_ROOT / 'src'
for p in (str(REPO_ROOT), str(SRC_ROOT)):
    if p not in sys.path:
        sys.path.insert(0, p)

from precip_input_assimilation.scripts.make_toy_run import ensure_toy_run  # noqa: E402

TEST_EPOCH = 2

# Nearing et al. (2022) block as released (ID29 assimilation_block_lead1.yml), shrunk to the toy sequence length:
# 4 windows x 5 days instead of 20 x 5, seq_length 60 instead of 365.
NEARING_TOY_BLOCK = {
    'assimilation_lead_time': 1,
    'assimilation_targets': ['c_n'],
    'assimilation_window': 5,
    'history': 4,
    'epochs': 100,
    'learning_rate': 0.1,
    'learning_rate_drop_factor': 0.1,
    'learning_rate_epoch_drop': 1001,
    'loss': 'MSE',
    'model_dropout': 0.0,
    'optimizer': 'Adam',
    'predict_last_n': 1,
    'regularization': [],
    'seq_length': 60,
    'target_variables': ['QObs(mm/d)'],
}


@pytest.fixture(scope='session', autouse=True)
def _repo_cwd():
    """Run configs use repo-relative paths."""
    cwd = os.getcwd()
    os.chdir(REPO_ROOT)
    yield
    os.chdir(cwd)


@pytest.fixture(scope='session')
def toy_run_dir() -> Path:
    return ensure_toy_run()


def make_id29_run_dir(toy_run_dir: Path, target_dir: Path, block: dict) -> Path:
    """Copy the toy run and append an ID29 ``assimilation_config`` block (what make_assimilation_run.py does)."""
    if target_dir.exists():
        shutil.rmtree(target_dir)
    shutil.copytree(toy_run_dir, target_dir)
    yaml = YAML()
    config_file = target_dir / 'config.yml'
    with config_file.open('r', encoding='utf-8') as fp:
        config = yaml.load(fp)
    config['run_dir'] = str(target_dir)
    config['train_dir'] = str(target_dir / 'train_data')
    config['img_log_dir'] = str(target_dir / 'img_log')
    config['assimilation_config'] = dict(block)
    with config_file.open('w', encoding='utf-8') as fp:
        yaml.dump(config, fp)
    return target_dir


@pytest.fixture(scope='session')
def toy_model_and_batch(toy_run_dir):
    """Frozen toy model plus the first evaluation batch of the first basin (test period)."""
    from neuralhydrology.datasetzoo import get_dataset
    from neuralhydrology.datautils.utils import load_basin_file, load_scaler
    from neuralhydrology.utils.config import Config
    from precip_input_assimilation.evaluate import load_frozen_model

    cfg = Config(toy_run_dir / 'config.yml')
    cfg.update_config({'device': 'cpu'})
    scaler = load_scaler(toy_run_dir)
    model = load_frozen_model(toy_run_dir, cfg, TEST_EPOCH, 'cpu')
    basin = load_basin_file(cfg.test_basin_file)[0]
    ds = get_dataset(cfg, is_train=False, period='test', basin=basin, scaler=scaler)
    loader = DataLoader(ds, batch_size=cfg.batch_size, num_workers=0, collate_fn=ds.collate_fn)
    batch = next(iter(loader))
    batch = model.pre_model_hook(batch, is_train=False)
    return {'cfg': cfg, 'scaler': scaler, 'model': model, 'batch': batch, 'basin': basin}


def clone_batch(batch: dict) -> dict:
    out = {}
    for k, v in batch.items():
        if isinstance(v, dict):
            out[k] = {kk: vv.clone() for kk, vv in v.items()}
        elif isinstance(v, torch.Tensor):
            out[k] = v.clone()
        else:
            out[k] = v.copy()
    return out
