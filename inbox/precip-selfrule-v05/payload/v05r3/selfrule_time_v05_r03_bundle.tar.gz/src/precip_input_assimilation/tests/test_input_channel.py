"""Unit tests of the input channel (plan v1.1 §5 item 8).

Two kinds of model are used: the frozen toy CudaLSTM (real data path) and a tiny analytic stub model
(``y_hat_t = P_t + c``) whose loss is a known quadratic, so that loop mechanics (acceptance rule, learning-rate
bookkeeping, penalty in the acceptance test) can be checked against hand-computed expectations.
"""
import numpy as np
import pytest
import torch
import torch.nn as nn

from conftest import NEARING_TOY_BLOCK, clone_batch

from precip_input_assimilation import InputAssimilationConfig, InputAssimilator

PRCP = 'PRCP(mm/day)'


def _cfg(**overrides) -> InputAssimilationConfig:
    block = {**NEARING_TOY_BLOCK, 'assimilation_targets': [f'x_d:{PRCP}'], 'predict_last_n': 5}
    block.update(overrides)
    return InputAssimilationConfig(block)


def _open_loop(model, batch):
    with torch.no_grad():
        return model(batch)['y_hat']


# --------------------------------------------------------------------------------------------------------------
# analytic stub: y_hat[b, t] = P[b, t] + c[b]; states pass through unchanged (h_n = c_n = c)
class _StubModel(nn.Module):
    state_var_names = ['h_n', 'c_n']

    def __init__(self):
        super().__init__()
        self.dummy = nn.Parameter(torch.zeros(1))  # so that model.parameters() is non-empty

    def pre_model_hook(self, data, is_train):
        return data

    def forward(self, data):
        p = data['x_d'][PRCP]  # [B, T, 1]
        batch = p.shape[0]
        c = data['c_n'] if 'c_n' in data else p.new_zeros((batch, 1, 1))
        y_hat = p + c
        return {'y_hat': y_hat, 'h_n': c, 'c_n': c}


STUB_SCALER = {'xarray_feature_center': {PRCP: 2.0}, 'xarray_feature_scale': {PRCP: 4.0}}  # z0 = -0.5
STUB_SEQ, STUB_WIN, STUB_HIST = 12, 2, 2  # warm-up 7, windows [7,9) [9,11), lead 1


def _stub_batch(batch_size=1, p_mm=8.0, obs_offset_z=1.0):
    """Precipitation constant p_mm (standardized (p-2)/4), observations = truth + obs_offset_z (per sample)."""
    p_z = torch.full((batch_size, STUB_SEQ, 1), (p_mm - 2.0) / 4.0)
    offset = torch.as_tensor(obs_offset_z, dtype=torch.float32).reshape(-1, 1, 1).expand(batch_size, STUB_SEQ, 1)
    return {'x_d': {PRCP: p_z}, 'y': p_z + offset, 'date': np.zeros((batch_size, STUB_SEQ), dtype='datetime64[D]')}


def _stub_cfg(**overrides):
    block = {
        'assimilation_lead_time': 1, 'assimilation_targets': [f'x_d:{PRCP}'], 'assimilation_window': STUB_WIN,
        'history': STUB_HIST, 'epochs': 1, 'learning_rate': 0.1, 'learning_rate_drop_factor': 0.5,
        'learning_rate_epoch_drop': 1001, 'loss': 'MSE', 'optimizer': 'Adam', 'predict_last_n': STUB_WIN,
        'seq_length': STUB_SEQ, 'target_variables': ['QObs(mm/d)']
    }
    block.update(overrides)
    return InputAssimilationConfig(block)


# --------------------------------------------------------------------------------------------------------------
def test_delta_only_touches_the_precipitation_column(toy_model_and_batch):
    model, batch = toy_model_and_batch['model'], clone_batch(toy_model_and_batch['batch'])
    seen = []
    handle = model.register_forward_pre_hook(
        lambda m, args: seen.append({k: v.clone() for k, v in args[0]['x_d'].items()}))
    try:
        out = InputAssimilator(_cfg(rollback_mode='continue'),
                               scaler=toy_model_and_batch['scaler']).assimilate(model, batch)
    finally:
        handle.remove()
    assert out['delta_prcp_mm'].abs().max() > 0, 'no correction was applied at all'
    window_calls = [x for x in seen if x[PRCP].shape[1] == NEARING_TOY_BLOCK['assimilation_window']]
    assert window_calls, 'no window forward pass recorded'
    # every non-precipitation feature is bit-identical to the batch in every forward pass
    for x_d in seen:
        length = x_d[PRCP].shape[1]
        for name, tensor in x_d.items():
            if name == PRCP:
                continue
            raw = batch['x_d'][name]
            candidates = [raw[:, s:s + length] for s in range(raw.shape[1] - length + 1)]
            assert any(torch.equal(c, tensor) for c in candidates), f'{name} was modified'
    # the corrected precipitation never goes below 0 mm
    z0 = -float(toy_model_and_batch['scaler']['xarray_feature_center'][PRCP]) / float(
        toy_model_and_batch['scaler']['xarray_feature_scale'][PRCP])
    assert min(float(x[PRCP].min()) for x in window_calls) >= z0 - 1e-6


def test_clamp_lower_bound_is_zero_mm(toy_model_and_batch):
    """Observations far below the open-loop simulation push delta negative; the projection must stop at 0 mm."""
    model, scaler = toy_model_and_batch['model'], toy_model_and_batch['scaler']
    batch = clone_batch(toy_model_and_batch['batch'])
    batch['y'] = torch.full_like(batch['y'], -3.0)  # absurdly low flow in standardized units
    out = InputAssimilator(_cfg(input_learning_rate_mm=20.0, learning_rate=None, rollback_mode='continue'),
                           scaler=scaler).assimilate(model, batch)
    delta = out['delta_prcp_mm'][:, :, 0]
    cfg = _cfg()
    start = cfg.seq_length - cfg.assimilation_lead_time - cfg.history * cfg.assimilation_window
    base_mm = batch['x_d'][PRCP][:, start:start + delta.shape[1], 0] * float(
        scaler['xarray_feature_scale'][PRCP]) + float(scaler['xarray_feature_center'][PRCP])
    adjusted = base_mm + delta
    assert float(adjusted.min()) >= -1e-4
    at_bound = (adjusted.abs() < 1e-4) & (base_mm > 1.0)
    assert at_bound.any(), 'expected some rainy days to be zeroed out by the clamp'
    assert (delta <= 1e-6).float().mean() > 0.8, 'with observations far below the simulation, rain should be removed'


def test_infinite_penalty_gives_zero_delta(toy_model_and_batch):
    model, scaler = toy_model_and_batch['model'], toy_model_and_batch['scaler']
    batch = clone_batch(toy_model_and_batch['batch'])
    reference = _open_loop(model, batch)
    for rollback_mode in ('freeze', 'continue'):
        out = InputAssimilator(_cfg(input_l1_lambda=1e9, rollback_mode=rollback_mode),
                               scaler=scaler).assimilate(model, clone_batch(batch))
        assert torch.equal(out['delta_prcp_mm'], torch.zeros_like(out['delta_prcp_mm']))
        assert (out['n_effective_updates'] == 0).all()
        torch.testing.assert_close(out['y_hat'], reference, rtol=0, atol=1e-6)


def test_multiplicative_gradient_is_zero_on_dry_days(toy_model_and_batch):
    scaler = toy_model_and_batch['scaler']
    assimilator = InputAssimilator(_cfg(input_adjust_mode='multiplicative', rollback_mode='continue'), scaler=scaler)
    base = torch.tensor([[[0.0], [5.0], [0.0], [12.0], [0.3]]]) - float(scaler['xarray_feature_center'][PRCP])
    base = base / float(scaler['xarray_feature_scale'][PRCP])  # days 0 and 2 are exactly 0 mm
    leaf = assimilator._new_input_leaf(base)
    adjusted, adj_z = assimilator._adjusted_feature(base, leaf, torch.ones_like(base))
    (adjusted * torch.randn_like(adjusted)).sum().backward()
    grad = leaf.grad[0, :, 0]
    # float32 reconstruction of 0 mm from its standardized value is ~1e-7 mm, hence tolerances
    assert abs(grad[0]) < 1e-6 and abs(grad[2]) < 1e-6 and abs(grad[1]) > 1e-3 and abs(grad[3]) > 1e-3
    assert torch.equal(adj_z, torch.zeros_like(adj_z))  # k = 1 applies no change

    # end-to-end: after assimilation the zero-precipitation days carry no correction
    model, batch = toy_model_and_batch['model'], clone_batch(toy_model_and_batch['batch'])
    out = assimilator.assimilate(model, batch)
    cfg = assimilator.cfg
    start = cfg.seq_length - cfg.assimilation_lead_time - cfg.history * cfg.assimilation_window
    base_mm = batch['x_d'][PRCP][:, start:start + out['delta_prcp_mm'].shape[1], 0] * float(
        scaler['xarray_feature_scale'][PRCP]) + float(scaler['xarray_feature_center'][PRCP])
    zero_days = base_mm.abs() < 1e-6
    assert zero_days.any()
    assert out['delta_prcp_mm'][:, :, 0][zero_days].abs().max() < 1e-5
    assert out['delta_prcp_mm'].abs().max() > 0


def test_a2j_only_moves_t_minus_2_and_skips_dry_days(toy_model_and_batch):
    model, scaler = toy_model_and_batch['model'], toy_model_and_batch['scaler']
    batch = clone_batch(toy_model_and_batch['batch'])
    cfg = _cfg(history=1, input_adjust_mode='multiplicative', input_adjust_days='t-2', input_skip_dry_days=True,
               input_dry_threshold_mm=0.1, epochs=100, rollback_mode='continue')
    assimilator = InputAssimilator(cfg, scaler=scaler)
    assert assimilator._adjust_index == 3  # window 5, lead 1: day t-2 is window index 3
    out = assimilator.assimilate(model, batch)
    delta = out['delta_prcp_mm'][:, :, 0]
    assert delta.shape[1] == 5
    other_days = torch.cat([delta[:, :3], delta[:, 4:]], 1)
    assert torch.equal(other_days, torch.zeros_like(other_days))
    start = cfg.seq_length - cfg.assimilation_lead_time - 5
    base_mm = batch['x_d'][PRCP][:, start + 3, 0] * float(scaler['xarray_feature_scale'][PRCP]) + float(
        scaler['xarray_feature_center'][PRCP])
    dry = base_mm < 0.1
    skipped = out['input_dry_skipped'][:, :, 0]
    assert torch.equal(skipped[:, 3], dry)
    assert torch.equal(skipped[:, [0, 1, 2, 4]], torch.zeros_like(skipped[:, [0, 1, 2, 4]]))
    assert torch.equal(delta[:, 3][dry], torch.zeros(int(dry.sum())))
    assert dry.any() and (~dry).any(), 'batch should contain both dry and wet t-2 days for this test to bite'
    assert delta[:, 3][~dry].abs().max() > 0


def test_steps_early_windows_caps_non_final_windows(toy_model_and_batch):
    model, scaler = toy_model_and_batch['model'], toy_model_and_batch['scaler']
    batch = toy_model_and_batch['batch']
    out_default = InputAssimilator(_cfg(rollback_mode='continue'), scaler=scaler).assimilate(model, clone_batch(batch))
    out_capped = InputAssimilator(_cfg(steps_early_windows=2, rollback_mode='continue'),
                                  scaler=scaler).assimilate(model, clone_batch(batch))
    assert (out_default['n_effective_updates'][:, :-1] <= 6).all()
    assert (out_capped['n_effective_updates'][:, :-1] <= 2).all()
    assert out_default['n_effective_updates'][:, :-1].max() > 2
    assert out_capped['n_effective_updates'][:, -1].max() > 2  # the final window is not capped


def test_lr_reset_per_window_with_stub():
    """One Adam step per window (|step| = lr at the first step). learning_rate_epoch_drop=1 halves the lr after the
    accepted step of window 1; without reset window 2 moves by lr/2, with reset by lr."""
    model, lr = _StubModel(), 0.1
    scale = STUB_SCALER['xarray_feature_scale'][PRCP]
    deltas = {}
    for reset in (False, True):
        cfg = _stub_cfg(learning_rate=lr, learning_rate_epoch_drop=1, lr_reset_per_window=reset)
        out = InputAssimilator(cfg, scaler=STUB_SCALER).assimilate(model, _stub_batch())
        deltas[reset] = out['delta_prcp_mm'][0, :, 0] / scale  # back to standardized units
        assert (out['n_effective_updates'] == 1).all()
    torch.testing.assert_close(deltas[False][:STUB_WIN], torch.full((STUB_WIN,), lr), rtol=0, atol=1e-6)
    torch.testing.assert_close(deltas[False][STUB_WIN:], torch.full((STUB_WIN,), lr / 2), rtol=0, atol=1e-6)
    torch.testing.assert_close(deltas[True][STUB_WIN:], torch.full((STUB_WIN,), lr), rtol=0, atol=1e-6)


def test_accept_rule_per_sample_with_stub():
    """Sample 0 is far from its observations (step helps), sample 1 almost matches them (a full step hurts). The batch
    rule accepts the step for both; the per-sample rule rolls sample 1 back."""
    model = _StubModel()
    batch = _stub_batch(batch_size=2, obs_offset_z=[1.0, 0.02])  # sample 1: tiny offset, Adam still steps by lr
    out_batch = InputAssimilator(_stub_cfg(accept_rule='batch'), scaler=STUB_SCALER).assimilate(model, batch)
    out_sample = InputAssimilator(_stub_cfg(accept_rule='per_sample'), scaler=STUB_SCALER).assimilate(model, batch)
    assert out_batch['n_effective_updates'].tolist() == [[1, 1], [1, 1]]
    assert out_batch['delta_prcp_mm'][1].abs().max() > 0
    assert out_sample['n_effective_updates'].tolist() == [[1, 1], [0, 0]]
    assert torch.equal(out_sample['delta_prcp_mm'][1], torch.zeros_like(out_sample['delta_prcp_mm'][1]))
    assert out_sample['delta_prcp_mm'][0].abs().max() > 0


def test_l1_penalty_enters_acceptance_test_with_stub():
    """A step that lowers the MSE but raises MSE + lambda*|delta| must be rejected (audit B11)."""
    model = _StubModel()
    scale = STUB_SCALER['xarray_feature_scale'][PRCP]
    lr, offset = 0.1, 1.0  # one Adam step moves delta by lr on every day of the window
    # MSE before = 0.5*offset^2, after = 0.5*(offset-lr)^2 -> gain 0.5*(1 - 0.81) = 0.095 (standardized units)
    # penalty after = lambda * window * lr * scale (mm); lambda = 1 -> 2*0.1*4 = 0.8 > 0.095 -> reject
    out_no_pen = InputAssimilator(_stub_cfg(learning_rate=lr, epochs=1), scaler=STUB_SCALER).assimilate(
        model, _stub_batch(obs_offset_z=offset))
    # epochs=2 so that the ID29-faithful frozen tail recomputes the window at its last good state (see
    # test_freeze_carries_rejected_step_when_loop_ends_in_that_epoch for what happens with epochs=1)
    out_pen = InputAssimilator(_stub_cfg(learning_rate=lr, epochs=2, input_l1_lambda=1.0),
                               scaler=STUB_SCALER).assimilate(model, _stub_batch(obs_offset_z=offset))
    assert (out_no_pen['n_effective_updates'] == 1).all()
    torch.testing.assert_close(out_no_pen['delta_prcp_mm'][0, :STUB_WIN, 0], torch.full((STUB_WIN,), lr * scale))
    assert (out_pen['n_effective_updates'] == 0).all()
    assert torch.equal(out_pen['delta_prcp_mm'], torch.zeros_like(out_pen['delta_prcp_mm']))
    # a small penalty (0.01 -> 0.008 < 0.095) keeps the step
    out_small = InputAssimilator(_stub_cfg(learning_rate=lr, epochs=1, input_l1_lambda=0.01),
                                 scaler=STUB_SCALER).assimilate(model, _stub_batch(obs_offset_z=offset))
    assert (out_small['n_effective_updates'] == 1).all()


def test_freeze_carries_rejected_step_when_loop_ends_in_that_epoch():
    """ID29 quirk 3 (reproduced on purpose in rollback_mode 'freeze'): the prediction carried out of a window is
    that of the last forward pass. If the epoch loop ends in the very epoch of a rejected step (epochs exhausted,
    lr < 1e-5, or the early-window cap), the *rejected* state is what leaves the window. 'continue' recomputes at the
    last good state immediately and therefore carries delta = 0 here."""
    model = _StubModel()
    scale = STUB_SCALER['xarray_feature_scale'][PRCP]
    lr = 0.1
    out_freeze = InputAssimilator(_stub_cfg(learning_rate=lr, epochs=1, input_l1_lambda=1.0, rollback_mode='freeze'),
                                  scaler=STUB_SCALER).assimilate(model, _stub_batch(obs_offset_z=1.0))
    out_cont = InputAssimilator(_stub_cfg(learning_rate=lr, epochs=1, input_l1_lambda=1.0, rollback_mode='continue'),
                                scaler=STUB_SCALER).assimilate(model, _stub_batch(obs_offset_z=1.0))
    assert (out_freeze['n_effective_updates'] == 0).all() and (out_cont['n_effective_updates'] == 0).all()
    # freeze: window 1 carries the rejected step (lr), window 2 the rejected half-lr step (lr decayed once)
    torch.testing.assert_close(out_freeze['delta_prcp_mm'][0, :STUB_WIN, 0], torch.full((STUB_WIN,), lr * scale))
    torch.testing.assert_close(out_freeze['delta_prcp_mm'][0, STUB_WIN:, 0], torch.full((STUB_WIN,), lr * scale / 2))
    assert torch.equal(out_cont['delta_prcp_mm'], torch.zeros_like(out_cont['delta_prcp_mm']))


def test_rollback_continue_keeps_optimizing_with_stub():
    """freeze: after the first rejection nothing moves any more; continue: the reduced lr step is retried."""
    model = _StubModel()
    # lr 2.5 overshoots (offset 1.0): step 1 rejected in both modes, lr -> 1.25 -> retried step lands at 1.25
    kwargs = dict(learning_rate=2.5, learning_rate_drop_factor=0.5, epochs=3, history=1)
    out_freeze = InputAssimilator(_stub_cfg(rollback_mode='freeze', **kwargs),
                                  scaler=STUB_SCALER).assimilate(model, _stub_batch(obs_offset_z=1.0))
    out_cont = InputAssimilator(_stub_cfg(rollback_mode='continue', **kwargs),
                                scaler=STUB_SCALER).assimilate(model, _stub_batch(obs_offset_z=1.0))
    assert (out_freeze['n_effective_updates'] == 0).all()
    assert (out_cont['n_effective_updates'] >= 1).all()
    assert out_cont['delta_prcp_mm'].abs().max() > 0


def test_config_rejects_unknown_keys_and_bad_values():
    with pytest.raises(ValueError):
        _cfg(no_such_key=1)
    with pytest.raises(ValueError):
        _cfg(input_adjust_mode='divide')
    with pytest.raises(ValueError):
        _cfg(input_adjust_days='yesterday')
    with pytest.raises(ValueError):
        InputAssimilationConfig({**NEARING_TOY_BLOCK, 'assimilation_targets': ['x_d:a', 'x_d:b']})
    with pytest.raises(ValueError):  # mm learning rate only for additive, input-only runs
        _cfg(input_learning_rate_mm=1.0, learning_rate=None, input_adjust_mode='multiplicative')
    with pytest.raises(ValueError):  # t-2 outside a 1-day window
        InputAssimilator(_cfg(assimilation_window=1, history=5, input_adjust_days='t-2'),
                         scaler={'xarray_feature_center': {PRCP: 1.0}, 'xarray_feature_scale': {PRCP: 1.0}})
