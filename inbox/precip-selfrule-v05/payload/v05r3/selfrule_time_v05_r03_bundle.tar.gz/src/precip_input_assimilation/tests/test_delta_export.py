"""The exported corrections must be attributable to calendar days exactly as plan v1.1 §3 defines delta(d)."""
import pickle

import numpy as np
import pandas as pd

from conftest import NEARING_TOY_BLOCK, TEST_EPOCH

PRCP = 'PRCP(mm/day)'


def test_delta_export_matches_section3_definition(toy_run_dir, tmp_path):
    from precip_input_assimilation.evaluate import delta_tables, run_input_assimilation

    block = {**NEARING_TOY_BLOCK, 'assimilation_targets': [f'x_d:{PRCP}'], 'predict_last_n': 5,
             'rollback_mode': 'continue'}
    window, lead, history = block['assimilation_window'], block['assimilation_lead_time'], block['history']
    results = run_input_assimilation(toy_run_dir, block, period='test', epoch=TEST_EPOCH, device='cpu',
                                     output_dir=tmp_path, basins=['01022500'])
    assert '01022500' in results
    with (tmp_path / 'test_adjustments_input_assimilation.p').open('rb') as fp:
        adjustments = pickle.load(fp)
    adj = adjustments['01022500']

    n_samples = adj['delta_prcp_mm'].shape[0]
    assert adj['delta_prcp_mm'].shape == (n_samples, history * window)
    assert adj['assim_dates'].shape == (n_samples, history * window)
    assert adj['n_effective_updates'].shape == (n_samples, history)
    assert np.abs(adj['delta_prcp_mm']).max() > 0

    end = adj['sample_end_date'].astype('datetime64[D]')
    dates = adj['assim_dates'].astype('datetime64[D]')
    # the assimilated days are the history*window days ending `lead` days before each sample's last step
    np.testing.assert_array_equal(dates[:, -1], end - np.timedelta64(lead, 'D'))
    np.testing.assert_array_equal(dates[:, 0], end - np.timedelta64(lead + history * window - 1, 'D'))
    assert (np.diff(dates.astype('int64'), axis=1) == 1).all()

    tables = delta_tables(adj, window=window, lead=lead)
    last = tables['last_window']
    # delta(d) := estimate of the last window for its first day d, from the sample whose forecast day is d+window+lead-1
    for i in range(0, n_samples, 7):
        d = end[i] - np.timedelta64(window + lead - 1, 'D')
        assert last.loc[pd.Timestamp(d), 'day0'] == adj['delta_prcp_mm'][i, -window]
    # sensitivity table: interior days are covered by exactly `window` samples
    med = tables['median_over_samples']
    assert med['n_samples'].max() == window
    interior = med.iloc[window:-window]
    assert (interior['n_samples'] == window).all()
    # and the median is the median of the raw estimates for that day
    day = interior.index[3]
    raw = adj['delta_prcp_mm'][:, -window:][dates[:, -window:] == np.datetime64(day, 'D')]
    assert len(raw) == window and np.isclose(np.median(raw), med.loc[day, 'delta_mm_median'])
