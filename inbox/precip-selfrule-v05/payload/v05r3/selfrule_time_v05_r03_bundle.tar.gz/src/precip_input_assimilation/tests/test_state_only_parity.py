"""Parity gate (plan v1.1 §12): configured with state targets only, the new module must reproduce the ID29
``--data-assimilation`` path value-for-value (tolerance 1e-6) on the 4 toy basins. Only after this passes may the
input channel be used.

The ID29 side is exercised exactly as a user would: run directory + ``assimilation_config`` block +
``BaseTester.evaluate(data_assimilation=True)``. Nothing from ``neuralhydrology.evaluation.assimilation`` is imported
here.
"""
import numpy as np
import pytest

from conftest import NEARING_TOY_BLOCK, TEST_EPOCH, make_id29_run_dir

TOL = 1e-6

# Arms of plan §2 that go through the ID29 path, plus two blocks that exercise the loop's branches the Nearing
# settings never reach (counter-driven lr drop; several rejections in early windows).
ARMS = {
    'A1_c_n': {},
    'A1prime_h_n_c_n': {'assimilation_targets': ['h_n', 'c_n']},
    'A1_5day_loss': {'predict_last_n': 5},
    'counter_lr_drop': {'learning_rate_epoch_drop': 3, 'learning_rate_drop_factor': 0.5},
    'high_lr_many_rejections': {'learning_rate': 2.0, 'learning_rate_drop_factor': 0.3, 'epochs': 12},
}


def _id29_results(toy_run_dir, tmp_path_factory, block: dict, name: str, data_assimilation: bool = True):
    from neuralhydrology.evaluation import get_tester
    from neuralhydrology.utils.config import Config

    run_dir = make_id29_run_dir(toy_run_dir, tmp_path_factory.mktemp(f'id29_{name}'), block)
    cfg = Config(run_dir / 'config.yml')
    cfg.update_config({'device': 'cpu'})
    tester = get_tester(cfg, run_dir, 'test', init_model=True)
    return tester.evaluate(epoch=TEST_EPOCH, save_results=False, data_assimilation=data_assimilation)


def _sim(results: dict, basin: str, var: str = 'QObs(mm/d)') -> np.ndarray:
    return results[basin]['1D']['xr'][f'{var}_sim'].values


@pytest.mark.parametrize('arm', sorted(ARMS))
def test_state_only_matches_id29_path(toy_run_dir, tmp_path_factory, arm):
    from precip_input_assimilation.evaluate import run_input_assimilation

    block = {**NEARING_TOY_BLOCK, **ARMS[arm]}
    reference = _id29_results(toy_run_dir, tmp_path_factory, block, arm)
    candidate = run_input_assimilation(toy_run_dir, dict(block), period='test', epoch=TEST_EPOCH, device='cpu')

    assert set(candidate) == set(reference) and len(reference) == 4
    worst = 0.0
    for basin in reference:
        ref, cand = _sim(reference, basin), _sim(candidate, basin)
        assert ref.shape == cand.shape
        np.testing.assert_array_equal(np.isnan(ref), np.isnan(cand))
        worst = max(worst, float(np.nanmax(np.abs(ref - cand))))
        # observations must be identical too (same dataset, same rescaling)
        obs_ref = reference[basin]['1D']['xr']['QObs(mm/d)_obs'].values
        obs_cand = candidate[basin]['1D']['xr']['QObs(mm/d)_obs'].values
        np.testing.assert_allclose(obs_cand, obs_ref, rtol=0, atol=0, equal_nan=True)
    assert worst <= TOL, f'{arm}: max |ID29 - new| = {worst:.3e} > {TOL}'


def test_assimilation_actually_changes_predictions(toy_run_dir, tmp_path_factory):
    """Guard against a vacuous parity: the assimilated series must differ from the open loop."""
    from precip_input_assimilation.evaluate import run_input_assimilation

    open_loop = _id29_results(toy_run_dir, tmp_path_factory, NEARING_TOY_BLOCK, 'open_loop', data_assimilation=False)
    candidate = run_input_assimilation(toy_run_dir, dict(NEARING_TOY_BLOCK), period='test', epoch=TEST_EPOCH,
                                       device='cpu')
    diffs = [float(np.nanmax(np.abs(_sim(open_loop, b) - _sim(candidate, b)))) for b in open_loop]
    assert max(diffs) > 1e-3, f'assimilation had no visible effect: {diffs}'
