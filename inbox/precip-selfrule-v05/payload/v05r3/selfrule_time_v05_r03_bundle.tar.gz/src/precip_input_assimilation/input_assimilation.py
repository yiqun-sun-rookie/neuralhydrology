"""Variational assimilation into model states and/or one dynamic input feature at inference time.

Own implementation of the Nearing et al. (2022) window loop, extended with an input channel: besides (or instead of)
the LSTM states at the start of each assimilation window, a per-day correction of one dynamic input feature (the
Maurer precipitation column) inside the window is treated as the free variable. Model weights stay frozen.

Design contract (plan v1.1 §12): this module does not import, subclass or patch
``neuralhydrology.evaluation.assimilation.Assimilation``. When configured with state targets only and the Nearing
hyper-parameters, it must reproduce that path value-for-value (tolerance 1e-6) — this is checked by
``tests/test_state_only_parity.py``. To make that possible the loop reproduces three behaviours of the released
implementation that are not in the paper (``rollback_mode: freeze`` + ``accept_rule: batch``, the defaults):

1. after the first update step that increases the batch loss, the window stays at its last good state while the
   learning-rate bookkeeping keeps running until an early-stopping criterion trips;
2. the learning rate is initialised once per batch and carries its decayed value from one window to the next
   (``lr_reset_per_window: false``);
3. the prediction carried out of a window is the one of the *last forward pass*, which after a rejected step
   followed by an immediate early stop is the rejected step's prediction, not the last good one.

Setting ``rollback_mode: continue`` and/or ``accept_rule: per_sample`` gives the sane variants (roll back, recompute,
keep optimizing with the reduced learning rate; decide per sample instead of per batch).

Input channel
-------------
``assimilation_targets`` may contain one entry ``x_d:<feature>`` (e.g. ``x_d:PRCP(mm/day)``). Per window a leaf
tensor ``[batch, window, 1]`` is optimized:

* ``additive``: ``P_z = P_z_base + delta`` in standardized space; after every optimizer step ``delta`` is projected
  so that the adjusted precipitation is ``>= 0 mm`` (``P_z >= z0 = -center/scale``). Penalty
  ``input_l1_lambda * mean_batch(sum_days |delta * scale|)`` (mm) is part of the loss that is back-propagated *and*
  of both values compared in the accept/reject test.
* ``multiplicative``: ``P = P_base * k^4`` (Jamaat et al. 2025 form), ``k`` initialised at 1 and clamped to
  ``>= 0``. Penalty ``input_l2_lambda * mean_batch(sum_days (k - 1)^2)``. On days with ``P_base = 0`` the gradient
  w.r.t. ``k`` is identically zero.

``input_adjust_days: t-<k>`` restricts the correction to the single day ``k`` steps before the forecast day (the last
predicted step; window-relative index ``window + lead - 1 - k``), ``input_skip_dry_days`` freezes days whose base
precipitation is below ``input_dry_threshold_mm`` and reports them.
"""

from typing import Any, Dict, List, Optional, Tuple

import torch
import torch.nn as nn

from neuralhydrology.modelzoo.basemodel import BaseModel
from neuralhydrology.training import get_loss_obj, get_optimizer, get_regularization_obj

from .config import InputAssimilationConfig


def _clone(value: Any, detach: bool = False) -> Any:
    if isinstance(value, dict):
        return {k: _clone(v, detach=detach) for k, v in value.items()}
    if isinstance(value, torch.Tensor):
        return value.detach().clone() if detach else value.clone()
    return value


def _slice_time(value: Any, start: Optional[int], end: Optional[int]) -> Any:
    if isinstance(value, dict):
        return {k: _slice_time(v, start, end) for k, v in value.items()}
    if isinstance(value, torch.Tensor) and value.dim() >= 2:
        return value[:, start:end].clone()
    return value


def _sequence_length(x_d: Dict[str, torch.Tensor]) -> int:
    for tensor in x_d.values():
        if isinstance(tensor, torch.Tensor) and tensor.dim() >= 2:
            return tensor.shape[1]
    raise ValueError('Could not determine the sequence length from the dynamic inputs.')


def _finite_sample_mask(x_d: Dict[str, torch.Tensor]) -> torch.Tensor:
    mask = None
    for tensor in x_d.values():
        if not isinstance(tensor, torch.Tensor) or tensor.dim() < 2:
            continue
        feature_mask = ~torch.isnan(tensor).flatten(start_dim=1).any(dim=1)
        mask = feature_mask if mask is None else (mask & feature_mask)
    return mask


def _apply_mask(value: Any, mask: torch.Tensor) -> Any:
    if isinstance(value, dict):
        return {k: _apply_mask(v, mask) for k, v in value.items()}
    if isinstance(value, torch.Tensor) and value.dim() >= 1 and value.shape[0] == mask.shape[0]:
        return value[mask]
    return value


class _OptimizerCfg(object):
    """Minimal config view for ``neuralhydrology.training.get_optimizer``."""

    def __init__(self, optimizer: str, learning_rate: float):
        self.optimizer = optimizer
        self.learning_rate = {0: learning_rate}


class InputAssimilator(object):
    """Assimilate streamflow observations into LSTM states and/or the precipitation input of a frozen model.

    Parameters
    ----------
    cfg : InputAssimilationConfig
        The assimilation settings.
    scaler : dict, optional
        Feature scaler of the training run (``neuralhydrology.datautils.utils.load_scaler``). Required when an input
        target is configured; used for the mm <-> standardized conversion and the non-negativity bound.
    """

    def __init__(self, cfg: InputAssimilationConfig, scaler: Optional[dict] = None):
        self.cfg = cfg
        self._end_timestep = cfg.seq_length - cfg.assimilation_lead_time
        self._start_timestep = self._end_timestep - cfg.history * cfg.assimilation_window
        if self._start_timestep < 0:
            raise ValueError('The sum of the warmup and assimilation period has to be smaller than the sequence length')

        self._loss_obj = get_loss_obj(cfg)
        self._loss_obj.set_regularization_terms(get_regularization_obj(cfg=cfg))

        self._input_feature = cfg.input_target
        self._center = self._scale = self._z0 = None
        self._adjust_index = None
        if self._input_feature is not None:
            if scaler is None:
                raise ValueError('A scaler is required when an input target is configured.')
            self._center = float(scaler['xarray_feature_center'][self._input_feature])
            self._scale = float(scaler['xarray_feature_scale'][self._input_feature])
            self._z0 = -self._center / self._scale
            if cfg.input_adjust_days != 'all':
                k = int(cfg.input_adjust_days[2:])
                self._adjust_index = cfg.assimilation_window + cfg.assimilation_lead_time - 1 - k
                if not 0 <= self._adjust_index < cfg.assimilation_window:
                    raise ValueError(f"input_adjust_days '{cfg.input_adjust_days}' falls outside the assimilation "
                                     f'window (window {cfg.assimilation_window}, lead {cfg.assimilation_lead_time}).')

        if cfg.input_learning_rate_mm is not None:
            self._initial_lr = cfg.input_learning_rate_mm / self._scale
        else:
            self._initial_lr = cfg.learning_rate[0]

        # the two ID29-faithful quirks (frozen tail with lazy recompute) only apply to the default rule combination
        self._faithful = cfg.accept_rule == 'batch' and cfg.rollback_mode == 'freeze'

    # ------------------------------------------------------------------------------------------------------------
    @property
    def input_feature(self) -> Optional[str]:
        return self._input_feature

    @property
    def z0(self) -> Optional[float]:
        """Standardized value of 0 mm precipitation (lower bound of the adjusted input)."""
        return self._z0

    @property
    def initial_learning_rate(self) -> float:
        return self._initial_lr

    # --- input channel helpers ----------------------------------------------------------------------------------
    def _adjust_masks(self, base_win: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """Return (adjustable-day mask as float [B, W, 1], dry-skipped flags as bool [B, W, 1])."""
        day_mask = torch.ones_like(base_win)
        if self._adjust_index is not None:
            day_mask = torch.zeros_like(base_win)
            day_mask[:, self._adjust_index] = 1.0
        dry_skipped = torch.zeros_like(base_win, dtype=torch.bool)
        if self.cfg.input_skip_dry_days:
            base_mm = base_win * self._scale + self._center
            dry_skipped = (base_mm < self.cfg.input_dry_threshold_mm) & (day_mask > 0)
            day_mask = day_mask * (~dry_skipped).to(day_mask.dtype)
        return day_mask, dry_skipped

    def _new_input_leaf(self, base_win: torch.Tensor) -> torch.Tensor:
        if self.cfg.input_adjust_mode == 'additive':
            leaf = torch.zeros_like(base_win)
        else:
            leaf = torch.ones_like(base_win)
        return leaf.requires_grad_(True)

    def _adjusted_feature(self, base_win: torch.Tensor, leaf: torch.Tensor,
                          adj_mask: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """Return (adjusted standardized feature, applied adjustment in standardized space)."""
        if self.cfg.input_adjust_mode == 'additive':
            adj_z = leaf * adj_mask
        else:
            base_mm = base_win * self._scale + self._center
            adj_z = base_mm * (leaf**4 - 1.0) / self._scale * adj_mask
        return base_win + adj_z, adj_z

    def _project_input_leaf(self, leaf: torch.Tensor, base_win: torch.Tensor):
        with torch.no_grad():
            if self.cfg.input_adjust_mode == 'additive':
                leaf.data.copy_(torch.maximum(leaf.data, self._z0 - base_win))
            else:
                leaf.data.clamp_(min=0.0)

    def _input_penalty(self, leaf: torch.Tensor, adj_z: torch.Tensor, adj_mask: torch.Tensor) -> Optional[torch.Tensor]:
        """Per-sample penalty [B] (None when the penalty weight is zero)."""
        if self.cfg.input_adjust_mode == 'additive':
            if self.cfg.input_l1_lambda == 0.0:
                return None
            return self.cfg.input_l1_lambda * (adj_z * self._scale).abs().sum(dim=(1, 2))
        if self.cfg.input_l2_lambda == 0.0:
            return None
        return self.cfg.input_l2_lambda * (((leaf - 1.0)**2) * adj_mask).sum(dim=(1, 2))

    # --- loss ---------------------------------------------------------------------------------------------------
    def _per_sample_fit(self, pred: Dict[str, torch.Tensor], loss_data: Dict[str, Any]) -> torch.Tensor:
        """Per-sample data-fit term [B], mirroring MaskedMSELoss / MaskedNSELoss over the last predict_last_n steps."""
        n = self.cfg.predict_last_n
        y_hat = pred['y_hat'][:, -n:, :]
        y = loss_data['y'][:, -n:, :]
        valid = ~torch.isnan(y)
        se = torch.where(valid, (y_hat - y)**2, torch.zeros_like(y_hat))
        count = valid.sum(dim=(1, 2)).clamp(min=1)
        if self.cfg.loss.lower() == 'mse':
            return 0.5 * se.sum(dim=(1, 2)) / count
        if self.cfg.loss.lower() == 'nse':
            stds = loss_data['per_basin_target_stds'].expand_as(y_hat)
            weights = 1 / (stds + self._loss_obj.eps)**2
            return (weights * se).sum(dim=(1, 2)) / count
        raise NotImplementedError(f"accept_rule 'per_sample' is only implemented for MSE and NSE, not {self.cfg.loss}.")

    def _total_loss(self, pred: Dict[str, torch.Tensor], loss_data: Dict[str, Any], sample_mask: torch.Tensor,
                    penalty: Optional[torch.Tensor]) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        """Return (batch objective, per-sample objective [B] or None). The batch objective is the frozen nh loss on
        the NaN-masked batch plus the batch-mean input penalty."""
        masked_pred = {k: pred[k][sample_mask] for k in self._loss_obj._prediction_keys}
        masked_data = {k: _apply_mask(v, sample_mask) for k, v in loss_data.items()}
        total, _ = self._loss_obj(masked_pred, masked_data)
        if penalty is not None:
            total = total + penalty[sample_mask].mean()
        per_sample = None
        if self.cfg.accept_rule == 'per_sample':
            per_sample = self._per_sample_fit(pred, loss_data)
            if penalty is not None:
                per_sample = per_sample + penalty
            per_sample = per_sample.detach()
        return total, per_sample

    # --- main loop ----------------------------------------------------------------------------------------------
    def assimilate(self, model: BaseModel, data: Dict[str, Any], x_d_key: str = 'x_d') -> Dict[str, torch.Tensor]:
        """Assimilate one batch and predict the full sequence.

        Returns
        -------
        Dict[str, torch.Tensor]
            ``y_hat`` [batch, seq, targets]; ``n_effective_updates`` [batch, history] (accepted steps per window);
            with an input target additionally ``delta_prcp_mm`` [batch, history*window, 1] (applied correction in
            mm, both modes) and ``input_dry_skipped`` [batch, history*window, 1] (bool).
        """
        cfg = self.cfg
        if not model.state_var_names:
            raise RuntimeError(f'{model.__class__.__name__} does not expose state variables required for assimilation.')
        for var in cfg.state_targets:
            if var not in model.state_var_names:
                raise ValueError(f"State target '{var}' is not a state of {model.__class__.__name__}.")
        if self._input_feature is not None and self._input_feature not in data[x_d_key]:
            raise ValueError(f"Input target '{self._input_feature}' is not among the dynamic inputs of the batch.")

        seq_length = _sequence_length(data[x_d_key])
        if seq_length != cfg.seq_length:
            raise ValueError(f'Sequence length of the batch ({seq_length}) does not match the config '
                             f'({cfg.seq_length}).')

        # cuDNN only tracks gradients in train mode (no-op on CPU; the dropout layer of CudaLSTM stays in eval mode)
        if cfg.model_dropout:
            model.train()
        else:
            for module in model.modules():
                if isinstance(module, (nn.LSTM, nn.GRU)):
                    module.train()

        window = cfg.assimilation_window
        batch_size = data['y'].shape[0]
        device = data['y'].device
        rest = {k: _clone(v, detach=True) for k, v in data.items() if k != x_d_key}

        # warm-up: integrate from zero states up to the first assimilation window. Deliberately NOT under no_grad:
        # on CPU nn.LSTM takes a different kernel path without autograd and the ~1e-7 differences flip accept/reject
        # decisions downstream, which breaks the 1e-6 parity with the ID29 path.
        pred = model({**rest, x_d_key: _slice_time(data[x_d_key], None, self._start_timestep)})
        y_hat = [pred['y_hat'].detach().clone()]

        learning_rate = self._initial_lr
        n_updates = torch.zeros(batch_size, cfg.history, dtype=torch.long, device=device)
        delta_chunks: List[torch.Tensor] = []
        dry_chunks: List[torch.Tensor] = []

        for w_idx, timestep in enumerate(range(self._start_timestep, self._end_timestep, window)):
            window_end = timestep + window
            is_last_window = timestep >= self._end_timestep - window
            x_d_win = _slice_time(data[x_d_key], timestep, window_end)
            loss_data = {**rest, 'y': data['y'][:, timestep:window_end].clone()}
            sample_mask = _finite_sample_mask(x_d_win)

            states = {var: pred[var].detach().clone() for var in model.state_var_names}
            leaves: Dict[str, torch.Tensor] = {}
            for var in cfg.state_targets:
                states[var].requires_grad_(True)
                leaves[var] = states[var]
            input_leaf = base_win = adj_mask = dry_skipped = None
            if self._input_feature is not None:
                base_win = x_d_win[self._input_feature]
                adj_mask, dry_skipped = self._adjust_masks(base_win)
                input_leaf = self._new_input_leaf(base_win)
                leaves['input'] = input_leaf
            snapshot = {k: v.detach().clone() for k, v in leaves.items()}

            def forward() -> Tuple[Dict[str, torch.Tensor], Optional[torch.Tensor], Optional[torch.Tensor]]:
                x_d = dict(x_d_win)
                adj_z = penalty = None
                if input_leaf is not None:
                    x_d[self._input_feature], adj_z = self._adjusted_feature(base_win, input_leaf, adj_mask)
                    penalty = self._input_penalty(input_leaf, adj_z, adj_mask)
                out = model({**rest, x_d_key: x_d, **states})
                return out, adj_z, penalty

            if cfg.lr_reset_per_window:
                learning_rate = self._initial_lr
            optimizer = get_optimizer(list(leaves.values()), _OptimizerCfg(cfg.optimizer, learning_rate))
            for group in optimizer.param_groups:
                group['lr'] = learning_rate

            pred, adj_z, penalty = forward()
            counter = 0
            frozen_mask = torch.zeros(batch_size, dtype=torch.bool, device=device)
            fully_frozen = False
            pending_recompute = False
            current_loss = None

            for epoch in range(cfg.epochs):
                if fully_frozen:
                    # ID29 frozen tail: inputs no longer change, only the bookkeeping runs on
                    if pending_recompute:
                        pred, adj_z, penalty = forward()
                        current_loss, _ = self._total_loss(pred, loss_data, sample_mask, penalty)
                        current_loss = current_loss.detach()
                        pending_recompute = False
                    loss_before = loss_after = current_loss
                    bad_mask = torch.zeros(batch_size, dtype=torch.bool, device=device)
                else:
                    optimizer.zero_grad()
                    loss_before, per_sample_before = self._total_loss(pred, loss_data, sample_mask, penalty)
                    loss_before.backward()
                    optimizer.step()
                    if input_leaf is not None:
                        self._project_input_leaf(input_leaf, base_win)
                    if frozen_mask.any():
                        with torch.no_grad():
                            for k, leaf in leaves.items():
                                leaf.data[frozen_mask] = snapshot[k][frozen_mask]

                    pred, adj_z, penalty = forward()
                    loss_after, per_sample_after = self._total_loss(pred, loss_data, sample_mask, penalty)

                    if cfg.accept_rule == 'batch':
                        bad_mask = torch.full((batch_size,), bool(loss_before < loss_after), dtype=torch.bool,
                                              device=device)
                    else:
                        bad_mask = (per_sample_after > per_sample_before) & sample_mask & ~frozen_mask

                    good_mask = ~bad_mask & ~frozen_mask
                    with torch.no_grad():
                        for k, leaf in leaves.items():
                            leaf.data[bad_mask] = snapshot[k][bad_mask]
                            snapshot[k][good_mask] = leaf.detach()[good_mask]
                    n_updates[good_mask, w_idx] += 1
                    if cfg.rollback_mode == 'freeze':
                        frozen_mask |= bad_mask
                    if bad_mask.any():
                        if self._faithful:
                            # ID29 carries the rejected prediction until the next epoch's forward pass
                            pending_recompute = True
                        else:
                            pred, adj_z, penalty = forward()
                    if frozen_mask.all():
                        fully_frozen = True
                        if not pending_recompute:
                            current_loss, _ = self._total_loss(pred, loss_data, sample_mask, penalty)
                            current_loss = current_loss.detach()

                # batch-level learning-rate bookkeeping (ID29 order)
                if loss_before < loss_after:
                    learning_rate = learning_rate * cfg.learning_rate_drop_factor
                    for group in optimizer.param_groups:
                        group['lr'] = learning_rate
                    counter = 0
                else:
                    counter += 1
                    if counter == cfg.learning_rate_epoch_drop:
                        learning_rate = learning_rate * cfg.learning_rate_drop_factor
                        for group in optimizer.param_groups:
                            group['lr'] = learning_rate
                        counter = 0

                if learning_rate < 1e-5 or loss_after < 1e-5:
                    break
                if (not is_last_window) and (epoch >= cfg.steps_early_windows - 1):
                    break

            y_hat.append(pred['y_hat'].detach())
            if input_leaf is not None:
                delta_chunks.append((adj_z * self._scale).detach())
                dry_chunks.append(dry_skipped)

        # lead time: predict beyond the assimilation period from the assimilated states with unchanged inputs
        if self._end_timestep < seq_length:
            states = {var: pred[var].detach().clone() for var in model.state_var_names}
            pred = model({**rest, x_d_key: _slice_time(data[x_d_key], self._end_timestep, None), **states})
            y_hat.append(pred['y_hat'].detach())

        # the model's own parameter gradients are never used; drop them so they do not pile up across batches
        for param in model.parameters():
            param.grad = None

        output = {'y_hat': torch.cat(y_hat, 1), 'n_effective_updates': n_updates}
        if self._input_feature is not None and cfg.export_input_adjustments:
            output['delta_prcp_mm'] = torch.cat(delta_chunks, 1)
            output['input_dry_skipped'] = torch.cat(dry_chunks, 1)
        return output
