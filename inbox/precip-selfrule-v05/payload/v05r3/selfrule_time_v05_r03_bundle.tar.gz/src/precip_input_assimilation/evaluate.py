"""Evaluate a frozen run with input-space (and/or state) assimilation, basin by basin.

Own evaluation loop (the core tester's ``--data-assimilation`` path is ID29's and stays untouched). Output layout
mirrors ``BaseTester.evaluate`` so results can be compared one-to-one: ``{basin: {'1D': {'xr': Dataset, 'NSE': ...}}}``
with ``<target>_obs`` / ``<target>_sim`` over ``(date, time_step)``. The applied input corrections are exported
separately, keyed by the date of each sample's last time step, together with the dates of the assimilated days.
"""

import logging
import pickle
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd
import torch
import xarray
from torch.utils.data import DataLoader

from neuralhydrology.datasetzoo import get_dataset
from neuralhydrology.datautils.utils import load_basin_file, load_scaler
from neuralhydrology.evaluation.metrics import calculate_metrics
from neuralhydrology.modelzoo import get_model
from neuralhydrology.utils.config import Config
from neuralhydrology.utils.errors import NoEvaluationDataError

from .config import InputAssimilationConfig
from .input_assimilation import InputAssimilator

LOGGER = logging.getLogger(__name__)


def load_frozen_model(run_dir: Path, cfg: Config, epoch: Optional[int], device: str) -> torch.nn.Module:
    """Build the model of a run directory and load the checkpoint of `epoch` (last one if None)."""
    if epoch is None:
        weight_file = sorted(run_dir.glob('model_epoch*.pt'))[-1]
    else:
        weight_file = run_dir / f'model_epoch{str(epoch).zfill(3)}.pt'
    model = get_model(cfg).to(device)
    model.load_state_dict(torch.load(weight_file, map_location=device))
    model.eval()
    LOGGER.info(f'Loaded weights from {weight_file}')
    return model


def _to_device(data: Dict[str, Any], device: str) -> Dict[str, Any]:
    out = {}
    for key, value in data.items():
        if key.startswith('x_d'):
            out[key] = {k: v.to(device) for k, v in value.items()}
        elif key.startswith('date'):
            out[key] = value
        else:
            out[key] = value.to(device)
    return out


def run_input_assimilation(run_dir: Path,
                           assimilation_cfg: Union[InputAssimilationConfig, Path, dict],
                           period: str = 'test',
                           epoch: Optional[int] = None,
                           device: str = 'cpu',
                           basins: Optional[List[str]] = None,
                           output_dir: Optional[Path] = None,
                           tag: str = 'input_assimilation',
                           config_overrides: Optional[dict] = None) -> Dict[str, dict]:
    """Run assimilation for every basin of `period` and return results in the core tester's layout.

    Parameters
    ----------
    run_dir : Path
        Finished training run (config.yml, train_data/train_data_scaler.yml, model_epochNNN.pt).
    assimilation_cfg : InputAssimilationConfig | Path | dict
        The ``input_assimilation_config`` block.
    period : str
        'train', 'validation' or 'test'; selects basin file and date range from the run config.
    epoch : int, optional
        Checkpoint epoch (last available if None).
    device : str
        'cpu' or 'cuda:N'.
    basins : List[str], optional
        Subset of basins to evaluate (default: the period's basin file).
    output_dir : Path, optional
        If given, results/metrics/input adjustments are pickled there.
    tag : str
        File-name suffix for the saved outputs.
    config_overrides : dict, optional
        Keys to override in the run config before building datasets (e.g. a local ``data_dir``).
    """
    run_dir = Path(run_dir)
    cfg = Config(run_dir / 'config.yml')
    overrides = {'device': device}
    if config_overrides:
        overrides.update(config_overrides)
    cfg.update_config(overrides)

    if not isinstance(assimilation_cfg, InputAssimilationConfig):
        assimilation_cfg = InputAssimilationConfig(assimilation_cfg)
    if assimilation_cfg.seq_length != cfg.seq_length:
        raise ValueError(f'seq_length of the assimilation block ({assimilation_cfg.seq_length}) must equal the run '
                         f'config ({cfg.seq_length}).')

    scaler = load_scaler(run_dir)
    model = load_frozen_model(run_dir, cfg, epoch, device)
    assimilator = InputAssimilator(assimilation_cfg, scaler=scaler)

    if basins is None:
        basins = load_basin_file(getattr(cfg, f'{period}_basin_file'))
    target_variables = cfg.target_variables
    feature_scale = scaler['xarray_feature_scale'][target_variables].to_array().values
    feature_center = scaler['xarray_feature_center'][target_variables].to_array().values
    predict_last_n = cfg.predict_last_n
    n_assim = assimilation_cfg.history * assimilation_cfg.assimilation_window
    assim_start = assimilation_cfg.seq_length - assimilation_cfg.assimilation_lead_time - n_assim

    results: Dict[str, dict] = {}
    adjustments: Dict[str, dict] = {}
    for basin in basins:
        try:
            ds = get_dataset(cfg, is_train=False, period=period, basin=basin, scaler=scaler)
        except NoEvaluationDataError:
            LOGGER.warning(f'No evaluation data for basin {basin}; skipped.')
            continue
        loader = DataLoader(ds, batch_size=cfg.batch_size, num_workers=0, collate_fn=ds.collate_fn)

        collected = defaultdict(list)
        for data in loader:
            data = _to_device(data, device)
            data = model.pre_model_hook(data, is_train=False)
            out = assimilator.assimilate(model, data)
            collected['y_hat'].append(out['y_hat'][:, -predict_last_n:, :].detach().cpu().numpy())
            collected['y'].append(data['y'][:, -predict_last_n:, :].cpu().numpy())
            collected['date'].append(data['date'][:, -predict_last_n:])
            collected['sample_end_date'].append(data['date'][:, -1])
            collected['assim_dates'].append(data['date'][:, assim_start:assim_start + n_assim])
            collected['n_effective_updates'].append(out['n_effective_updates'].cpu().numpy())
            if 'delta_prcp_mm' in out:
                collected['delta_prcp_mm'].append(out['delta_prcp_mm'][:, :, 0].cpu().numpy())
                collected['input_dry_skipped'].append(out['input_dry_skipped'][:, :, 0].cpu().numpy())
        if not collected['y_hat']:
            continue
        stacked = {k: np.concatenate(v, 0) for k, v in collected.items()}

        y_hat = stacked['y_hat'] * feature_scale + feature_center
        y = stacked['y'] * feature_scale + feature_center
        data_vars = {}
        for i, var in enumerate(target_variables):
            data_vars[f'{var}_obs'] = (('date', 'time_step'), y[:, :, i])
            data_vars[f'{var}_sim'] = (('date', 'time_step'), y_hat[:, :, i])
        coords = {
            'date': stacked['date'][:, -1],
            'time_step': np.arange(-predict_last_n + 1, 1, dtype=np.int64),
        }
        xr = xarray.Dataset(data_vars=data_vars, coords=coords)
        xr = xr.reindex({
            'date': pd.DatetimeIndex(pd.date_range(xr['date'].values[0], xr['date'].values[-1], freq='1D'),
                                     name='date')
        })
        results[basin] = {'1D': {'xr': xr}}
        for var in target_variables:
            obs = xr[f'{var}_obs'].sel(time_step=0)
            sim = xr[f'{var}_sim'].sel(time_step=0)
            if var in cfg.clip_targets_to_zero:
                sim = xarray.where(sim < 0, 0, sim)
            values = calculate_metrics(obs, sim, metrics=cfg.metrics or ['NSE'], resolution='1D')
            if len(target_variables) > 1:
                values = {f'{var}_{k}': v for k, v in values.items()}
            results[basin]['1D'].update(values)

        adjustments[basin] = {
            'sample_end_date': stacked['sample_end_date'],
            'assim_dates': stacked['assim_dates'],
            'n_effective_updates': stacked['n_effective_updates'],
        }
        if 'delta_prcp_mm' in stacked:
            adjustments[basin]['delta_prcp_mm'] = stacked['delta_prcp_mm']
            adjustments[basin]['input_dry_skipped'] = stacked['input_dry_skipped']

    if output_dir is not None:
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        with (output_dir / f'{period}_results_{tag}.p').open('wb') as fp:
            pickle.dump(results, fp)
        with (output_dir / f'{period}_adjustments_{tag}.p').open('wb') as fp:
            pickle.dump(adjustments, fp)
        rows = {b: {k: v for k, v in r['1D'].items() if k != 'xr'} for b, r in results.items()}
        pd.DataFrame.from_dict(rows, orient='index').rename_axis('basin').to_csv(output_dir /
                                                                                 f'{period}_metrics_{tag}.csv')
        LOGGER.info(f'Stored results, adjustments and metrics under {output_dir}')

    return results


def metrics_frame(results: Dict[str, dict], freq: str = '1D') -> pd.DataFrame:
    rows = {b: {k: v for k, v in r[freq].items() if k != 'xr'} for b, r in results.items()}
    return pd.DataFrame.from_dict(rows, orient='index').rename_axis('basin')


def delta_tables(basin_adjustments: dict, window: int, lead: int) -> Dict[str, pd.DataFrame]:
    """Turn one basin's exported corrections into the two daily tables of plan v1.1 §3.

    ``last_window``: indexed by the first day ``d`` of each sample's *last* assimilation window (the sample whose
    forecast day is ``d + window + lead - 1``); column ``day0`` is the plan's ``delta(d)``, ``day1..`` the same
    window's estimates for the following days. ``median_over_samples``: for every calendar day, the median of the
    estimates it received from the last windows of the ``window`` samples that contain it (sensitivity definition).
    """
    delta = np.asarray(basin_adjustments['delta_prcp_mm'])[:, -window:]
    dates = np.asarray(basin_adjustments['assim_dates'])[:, -window:].astype('datetime64[D]')
    end = np.asarray(basin_adjustments['sample_end_date']).astype('datetime64[D]')
    expected_first = end - np.timedelta64(window + lead - 1, 'D')
    if not np.array_equal(dates[:, 0], expected_first):
        raise ValueError('assimilation-window dates are inconsistent with the sample end dates.')
    last_window = pd.DataFrame(delta, index=pd.DatetimeIndex(dates[:, 0], name='date'),
                               columns=[f'day{i}' for i in range(window)])
    stacked = pd.DataFrame({'date': dates.ravel(), 'delta_mm': delta.ravel()})
    median = stacked.groupby('date')['delta_mm'].agg(['median', 'count']).rename(columns={
        'median': 'delta_mm_median', 'count': 'n_samples'})
    median.index.name = 'date'
    return {'last_window': last_window, 'median_over_samples': median}
