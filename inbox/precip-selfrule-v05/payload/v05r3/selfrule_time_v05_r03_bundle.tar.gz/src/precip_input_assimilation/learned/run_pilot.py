"""Pilot of plan v0.1: does a learned additive rain corrector beat the same network correcting C4's output or state?

Data flow
---------
* frozen C4 seed 100 (epoch 30), 96 pre-registered basins, local CAMELS-US Maurer.
* train the correctors on 1980-10..1988-09 and early-stop on 1988-10..1989-09 (both never seen by C4; track0 seals
  only 1989-10..1999-09);
* report once, after training, on the tuning year 2006-10..2007-09 (all 96 basins) -- it is never used for selection;
* the exam year 2007-10..2008-09 is NOT touched.

Also reported on the tuning year: A0 (open loop), persistence (A0 + yesterday's error), and the "peek at the answer"
oracle -- rain on days t-100..t-1 optimized per sample to hit day t's observation, within the same cap (and without
it). The oracle is the ceiling of what any rain-only correction can do at lead 1.

Usage (repo root):
    python src/precip_input_assimilation/learned/run_pilot.py [--arms output,state,input] [--max-basins 96]
"""
import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch

REPO_ROOT = Path(__file__).resolve().parents[3]
for p in (str(REPO_ROOT), str(REPO_ROOT / 'src')):
    if p not in sys.path:
        sys.path.insert(0, p)

from neuralhydrology.datautils.utils import load_scaler  # noqa: E402
from neuralhydrology.utils.config import Config  # noqa: E402
from precip_input_assimilation.evaluate import load_frozen_model  # noqa: E402
from precip_input_assimilation.learned.corrector import Arms, Corrector, features  # noqa: E402
from precip_input_assimilation.learned.data import PRCP, SEQ, TARGET, WIN, load_period, windows  # noqa: E402

RUN_DIR = REPO_ROOT / 'results/precip_input_da_2026_09/local/c4_s100_96basins'
CAPS = REPO_ROOT / 'results/precip_input_da_2026_09/analysis/maurer_daymet_gap_caps.csv'
OUT = REPO_ROOT / 'results/precip_input_da_2026_09/learned_pilot'


def nse_per_basin(pd_, pred, b, t, qc, qs):
    """NSE per basin (raw mm/d) over the given samples."""
    y = pd_.y[b, t] * qs + qc
    p = pred * qs + qc
    out = {}
    for bi in torch.unique(b).tolist():
        m = b == bi
        yy, pp = y[m], p[m]
        out[pd_.basins[bi]] = float(1 - ((pp - yy)**2).sum() / ((yy - yy.mean())**2).sum())
    return out


def batched(fn, samples, bs):
    outs = []
    for s in range(0, len(samples), bs):
        b, t = samples[s:s + bs, 0], samples[s:s + bs, 1]
        outs.append(fn(b, t))
    return torch.cat(outs)


def perm_p(d, n=20000, seed=0):
    """One-sided sign-flip permutation p for median(d) > 0."""
    d = np.asarray(d, float)
    rng = np.random.default_rng(seed)
    obs = np.median(d)
    flips = rng.choice([-1.0, 1.0], size=(n, len(d)))
    return float((np.median(flips * d, axis=1) >= obs).mean())


def oracle(arms, pd_, b, t, capped, steps, lr):
    """Per-sample rain optimization that sees day t's observation (ceiling of any rain-only correction)."""
    x = torch.nan_to_num(windows(pd_.dyn, b, t, SEQ))
    xs = pd_.stat[b]
    h, c = arms._warm(x, xs, SEQ - 1 - WIN)
    seg0 = x[:, SEQ - 1 - WIN:]
    p_mm = seg0[:, :WIN, arms.ip] * arms.ps + arms.pc
    y = pd_.y[b, t]
    u = torch.zeros(len(b), WIN, device=x.device, requires_grad=True)
    opt = torch.optim.Adam([u], lr=lr)
    best = torch.full_like(y, float('inf'))
    best_pred = pd_.sim[b, t].clone()
    cap = arms.cap_mm[b][:, None]
    for _ in range(steps):
        delta = cap * torch.tanh(u) if capped else 10.0 * u
        p_new = (torch.relu(p_mm + delta) - arms.pc) / arms.ps
        rain = torch.cat([p_new, seg0[:, WIN:, arms.ip]], 1)
        seg = torch.cat([seg0[..., :arms.ip], rain[..., None], seg0[..., arms.ip + 1:]], -1)
        from precip_input_assimilation.learned.data import c4_forward
        pred = c4_forward(arms.model, seg, xs, arms.dyn_names, h, c)['y_hat'][:, -1, 0]
        err = (pred - y)**2
        with torch.no_grad():
            better = err < best
            best = torch.where(better, err, best)
            best_pred = torch.where(better, pred, best_pred)
        opt.zero_grad()
        err.sum().backward()
        opt.step()
    return best_pred.detach()


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--arms', default='output,state,input')
    ap.add_argument('--max-basins', type=int, default=96)
    ap.add_argument('--epochs', type=int, default=30)
    ap.add_argument('--patience', type=int, default=5)
    ap.add_argument('--batch', type=int, default=256)
    ap.add_argument('--lr', type=float, default=1e-3)
    ap.add_argument('--oracle-steps', type=int, default=300)
    ap.add_argument('--skip-oracle', action='store_true')
    ap.add_argument('--seed', type=int, default=0)
    ap.add_argument('--tag', default='pilot')
    args = ap.parse_args()
    torch.manual_seed(args.seed)
    dev = 'cuda:0' if torch.cuda.is_available() else 'cpu'
    t_start = time.time()
    OUT.mkdir(parents=True, exist_ok=True)

    cfg = Config(RUN_DIR / 'config.yml')
    cfg.update_config({'device': dev})
    scaler = load_scaler(RUN_DIR)
    model = load_frozen_model(RUN_DIR, cfg, 30, dev)
    for prm in model.parameters():
        prm.requires_grad_(False)
    model.eval()
    model.lstm.train()   # cuDNN needs train mode for backward; single layer, no dropout -> same forward
    dyn_names = list(cfg.dynamic_inputs)
    ip = dyn_names.index(PRCP)
    pc = float(scaler['xarray_feature_center'][PRCP])
    ps = float(scaler['xarray_feature_scale'][PRCP])
    qc = float(scaler['xarray_feature_center'][TARGET])
    qs = float(scaler['xarray_feature_scale'][TARGET])

    draw = json.loads((RUN_DIR / 'basin_draw.json').read_text())
    stratum = {b: g for g, bs in draw['basins'].items() for b in bs}
    basins = (Path(REPO_ROOT / 'src/precip_input_assimilation/configs/basins_96.txt').read_text().split())[:args.max_basins]

    t0 = time.time()
    train = load_period(RUN_DIR, basins, '01/10/1980', '30/09/1989', model, dev)
    val = load_period(RUN_DIR, basins, '23/06/2006', '30/09/2007', model, dev, eval_from='2006-10-01')
    print(f'data: train samples {len(train.samples):,} (1981-01-09..1989-09-30), val samples {len(val.samples):,} '
          f'(2006-10-01..2007-09-30), {time.time() - t0:.0f}s', flush=True)

    caps = pd.read_csv(CAPS, dtype={'basin': str}).set_index('basin')['maurer_p99']
    cap_mm = torch.tensor([caps[b] for b in basins], dtype=torch.float32, device=dev)
    arms = Arms(model, dyn_names, ip, pc, ps, cap_mm, float(cap_mm.median()))

    vb, vt = val.samples[:, 0], val.samples[:, 1]
    es_day = torch.as_tensor(train.dates[train.samples[:, 1].cpu().numpy()] >= np.datetime64('1988-10-01', 'D'),
                             device=dev)
    es_samples = train.samples[es_day]            # early stopping: 1988-10..1989-09
    fit_samples = train.samples[~es_day]          # fitting: 1981-01..1988-09
    eb, et = es_samples[:, 0], es_samples[:, 1]
    tb, tt = fit_samples[:, 0], fit_samples[:, 1]
    print(f'fit samples {len(fit_samples):,}, early-stop samples {len(es_samples):,}', flush=True)
    rows = {b: {'basin': b, 'stratum': stratum.get(b, '?')} for b in basins}

    # --- prerequisite check: C4 open loop in the 1980s vs the tuning year; 1980s missing obs
    ab, at = train.samples[:, 0], train.samples[:, 1]
    a0_train = nse_per_basin(train, train.sim[ab, at], ab, at, qc, qs)
    a0_val = nse_per_basin(val, val.sim[vb, vt], vb, vt, qc, qs)
    per_t = pd.Series(train.dates)
    miss_1980s = {}
    lo = int(np.searchsorted(train.dates, np.datetime64('1980-10-01', 'D')))
    for bi, b in enumerate(basins):
        miss_1980s[b] = float(torch.isnan(train.y[bi, lo:]).float().mean())
    for b in basins:
        rows[b].update({'A0_1980s': a0_train.get(b, np.nan), 'A0': a0_val.get(b, np.nan),
                        'obs_missing_1980s': miss_1980s[b]})

    # --- persistence: open loop + yesterday's error
    def persist(b, t):
        e = val.y[b, t - 1] - val.sim[b, t - 1]
        return val.sim[b, t] + torch.nan_to_num(e)
    for b, v in nse_per_basin(val, batched(persist, val.samples, 4096), vb, vt, qc, qs).items():
        rows[b]['persistence'] = v

    # --- oracle ceilings (see the answer)
    if not args.skip_oracle:
        for capped in (True, False):
            t0 = time.time()
            pred = batched(lambda b, t: oracle(arms, val, b, t, capped, args.oracle_steps, 0.05), val.samples, 1024)
            name = 'oracle_cap' if capped else 'oracle_nocap'
            for b, v in nse_per_basin(val, pred, vb, vt, qc, qs).items():
                rows[b][name] = v
            print(f'{name}: {time.time() - t0:.0f}s', flush=True)

    # --- learned arms
    log = {}
    for arm in args.arms.split(','):
        torch.manual_seed(args.seed)
        g = Corrector(arm, n_in=2 + train.dyn.shape[-1] + train.stat.shape[-1]).to(dev)
        opt = torch.optim.Adam(g.parameters(), lr=args.lr)
        # zero-init sanity: every arm starts at the open loop
        with torch.no_grad():
            chk = val.samples[:512]
            d0 = (arms.predict(g, val, chk[:, 0], chk[:, 1]) - val.sim[chk[:, 0], chk[:, 1]]).abs().max().item()
        print(f'[{arm}] zero-init max |pred - A0| = {d0:.2e}', flush=True)
        best, best_state, bad, hist = -np.inf, None, 0, []
        for ep in range(args.epochs):
            t0 = time.time()
            g.train()
            perm = torch.randperm(len(fit_samples), device=dev)
            tot, n = 0.0, 0
            for s in range(0, len(perm), args.batch):
                idx = perm[s:s + args.batch]
                b, t = tb[idx], tt[idx]
                pred = arms.predict(g, train, b, t)
                w = 1.0 / (train.std[b] + 0.1)**2
                loss = (w * (pred - train.y[b, t])**2).mean()
                opt.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(g.parameters(), 1.0)
                opt.step()
                tot += loss.item() * len(idx)
                n += len(idx)
            g.eval()
            with torch.no_grad():
                ep_pred = batched(lambda b, t: arms.predict(g, train, b, t), es_samples, 1024)
            en = nse_per_basin(train, ep_pred, eb, et, qc, qs)
            med = float(np.median(list(en.values())))
            hist.append({'epoch': ep + 1, 'train_loss': tot / n, 'es_median_nse': med, 'seconds': time.time() - t0})
            print(f'[{arm}] ep {ep + 1:2d} loss {tot / n:.4f} early-stop (1988-89) median NSE {med:.4f} '
                  f'({time.time() - t0:.0f}s)', flush=True)
            if med > best + 1e-5:
                best, bad = med, 0
                best_state = {k: v.detach().clone() for k, v in g.state_dict().items()}
            else:
                bad += 1
                if bad >= args.patience:
                    break
        g.load_state_dict(best_state)
        g.eval()
        torch.save(best_state, OUT / f'{args.tag}_{arm}.pt')
        with torch.no_grad():
            if arm == 'input':
                preds, deltas = [], []
                for s in range(0, len(val.samples), 1024):
                    b, t = vb[s:s + 1024], vt[s:s + 1024]
                    p, d = arms.predict(g, val, b, t, return_delta=True)
                    preds.append(p)
                    deltas.append(d)
                vp, dl = torch.cat(preds), torch.cat(deltas).cpu().numpy()
                np.savez_compressed(OUT / f'{args.tag}_input_delta_val.npz', delta_mm=dl,
                                    basin=np.array(basins)[vb.cpu().numpy()],
                                    date=val.dates[vt.cpu().numpy()])
                log['input_delta'] = {'mean_abs_mm': float(np.abs(dl).mean()),
                                      'frac_days_abs_gt_0.5mm': float((np.abs(dl) > 0.5).mean()),
                                      'p99_abs_mm': float(np.percentile(np.abs(dl), 99))}
            else:
                vp = batched(lambda b, t: arms.predict(g, val, b, t), val.samples, 1024)
        for b, v in nse_per_basin(val, vp, vb, vt, qc, qs).items():
            rows[b][arm] = v
        log[arm] = hist

    df = pd.DataFrame(list(rows.values()))
    df.to_csv(OUT / f'{args.tag}_per_basin.csv', index=False)
    cols = [c for c in ['A0_1980s', 'A0', 'persistence', 'oracle_cap', 'oracle_nocap', 'output', 'state', 'input']
            if c in df.columns]
    summary = df.groupby('stratum')[cols].median()
    summary.loc['all'] = df[cols].median()
    print('\nmedian NSE by stratum (validation = tuning year 2006-10..2007-09; A0_1980s = C4 open loop 1980s)')
    print(summary.round(4).to_string())
    print(f'\n1980s obs missing fraction: median {df.obs_missing_1980s.median():.3f}, max {df.obs_missing_1980s.max():.3f}')

    jn = df[df.stratum == 'j_negative']
    lines = []
    for a in [c for c in ['persistence', 'output', 'state', 'input', 'oracle_cap'] if c in df.columns]:
        d = (jn[a] - jn['A0']).dropna()
        lines.append(f'J-negative {a} - A0: median {d.median():+.4f}, wins {int((d > 0).sum())}/{len(d)}, p {perm_p(d):.4f}')
    if 'input' in df.columns:
        for other in [c for c in ['output', 'state'] if c in df.columns]:
            d = (jn['input'] - jn[other]).dropna()
            lines.append(f'J-negative input - {other}: median {d.median():+.4f}, wins {int((d > 0).sum())}/{len(d)}, '
                         f'p {perm_p(d):.4f}')
    print('\n' + '\n'.join(lines))
    peak = torch.cuda.max_memory_allocated() / 2**30 if dev.startswith('cuda') else float('nan')
    log.update({'summary': summary.round(5).to_dict(), 'paired_j_negative': lines, 'wall_seconds': time.time() - t_start,
                'gpu_peak_gib': peak, 'args': vars(args)})
    (OUT / f'{args.tag}_log.json').write_text(json.dumps(log, indent=2, default=str), encoding='utf-8')
    print(f'\nwall {time.time() - t_start:.0f}s, GPU peak {peak:.2f} GiB -> {OUT}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
