"""One small GRU reads the last 100 days (C4 error, missing flag, Maurer inputs, static attributes) and drives one
of three arms through the frozen C4. All heads start at zero, so every arm starts exactly at the open loop (A0).

* input  - one additive rain change per day, delta = cap_b * tanh((cap_med / cap_b) * z), new rain = max(0, P + delta)
* output - one number c added to C4's open-loop forecast (same information, no detour through rain)
* state  - an update to C4's hidden and cell state at the end of day t-1, then one C4 step for day t
"""
import torch
import torch.nn as nn

from .data import SEQ, WIN, PeriodData, c4_forward, windows


class Corrector(nn.Module):

    def __init__(self, arm: str, n_in: int, hidden: int = 64, state_size: int = 256):
        super().__init__()
        self.arm = arm
        self.gru = nn.GRU(n_in, hidden, batch_first=True)
        n_out = {'input': 1, 'output': 1, 'state': 2 * state_size}[arm]
        self.head = nn.Linear(hidden, n_out)
        nn.init.zeros_(self.head.weight)
        nn.init.zeros_(self.head.bias)

    def forward(self, feats: torch.Tensor) -> torch.Tensor:
        seq, _ = self.gru(feats)
        if self.arm == 'input':
            return self.head(seq)[..., 0]          # [B, WIN]
        return self.head(seq[:, -1])                # [B, 1] or [B, 512]


def features(pd_: PeriodData, b: torch.Tensor, t: torch.Tensor) -> torch.Tensor:
    """[B, WIN, 1 + 1 + F + S]: error y - sim, missing flag, dynamic inputs, statics, for days t-100..t-1."""
    y = windows(pd_.y.unsqueeze(-1), b, t - 1, WIN)[..., 0]
    s = windows(pd_.sim.unsqueeze(-1), b, t - 1, WIN)[..., 0]
    miss = torch.isnan(y)
    err = torch.where(miss, torch.zeros_like(y), y - s)
    dyn = torch.nan_to_num(windows(pd_.dyn, b, t - 1, WIN))
    stat = pd_.stat[b][:, None, :].expand(-1, WIN, -1)
    return torch.cat([err[..., None], miss.float()[..., None], dyn, stat], -1)


class Arms:
    """Forward passes of the three arms (and the per-sample oracle) through the frozen C4."""

    def __init__(self, model, dyn_names, prcp_index, prcp_center, prcp_scale, cap_mm, cap_med):
        self.model, self.dyn_names = model, dyn_names
        self.ip, self.pc, self.ps = prcp_index, prcp_center, prcp_scale
        self.cap_mm, self.cap_med = cap_mm, cap_med      # cap_mm: [NB] tensor (mm)

    def _warm(self, x, xs, upto):
        with torch.no_grad():
            out = c4_forward(self.model, x[:, :upto], xs, self.dyn_names)
        return out['h_n'], out['c_n']

    def rain_forecast(self, pd_, b, t, delta_mm):
        """C4 forecast for day t with delta_mm [B, WIN] added to the rain on days t-100..t-1 (floored at 0 mm)."""
        x = torch.nan_to_num(windows(pd_.dyn, b, t, SEQ))
        xs = pd_.stat[b]
        h, c = self._warm(x, xs, SEQ - 1 - WIN)
        seg = x[:, SEQ - 1 - WIN:]                                   # days t-100..t (101 steps)
        p_mm = seg[:, :WIN, self.ip] * self.ps + self.pc
        p_new = (torch.relu(p_mm + delta_mm) - self.pc) / self.ps
        rain = torch.cat([p_new, seg[:, WIN:, self.ip]], 1)          # forecast-day rain unchanged
        seg = torch.cat([seg[..., :self.ip], rain[..., None], seg[..., self.ip + 1:]], -1)
        return c4_forward(self.model, seg, xs, self.dyn_names, h, c)['y_hat'][:, -1, 0]

    def input_delta(self, z, b):
        cap = self.cap_mm[b][:, None]
        return cap * torch.tanh((self.cap_med / cap) * z)

    def predict(self, g: Corrector, pd_: PeriodData, b, t, return_delta=False):
        feats = features(pd_, b, t)
        out = g(feats)
        if g.arm == 'output':
            return pd_.sim[b, t] + out[:, 0]
        if g.arm == 'state':
            x = torch.nan_to_num(windows(pd_.dyn, b, t, SEQ))
            xs = pd_.stat[b]
            h, c = self._warm(x, xs, SEQ - 1)
            hs = h.shape[-1]
            h = h + out[:, None, :hs]
            c = c + out[:, None, hs:]
            return c4_forward(self.model, x[:, SEQ - 1:], xs, self.dyn_names, h, c)['y_hat'][:, -1, 0]
        delta = self.input_delta(out, b)
        pred = self.rain_forecast(pd_, b, t, delta)
        return (pred, delta) if return_delta else pred
