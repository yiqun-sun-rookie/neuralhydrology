"""Per-basin daily arrays for the learned correctors, normalized exactly as C4 sees them, plus C4's open-loop
prediction for every day (computed once, on the GPU).

A sample is (basin, t): the 270-day C4 input window ends at day t (the forecast day, lead 1). The corrector reads days
t-100..t-1 (sample indices 169..268) and may change the rain on exactly those days.
"""
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List

import numpy as np
import torch

from neuralhydrology.datasetzoo import get_dataset
from neuralhydrology.datautils.utils import load_scaler
from neuralhydrology.utils.config import Config

SEQ = 270
WIN = 100
PRCP = 'PRCP(mm/day)'
TARGET = 'QObs(mm/d)'


@dataclass
class PeriodData:
    basins: List[str]
    dyn: torch.Tensor        # [NB, T, F] normalized dynamic inputs, cfg.dynamic_inputs order (NaN kept)
    stat: torch.Tensor       # [NB, S] normalized static attributes
    y: torch.Tensor          # [NB, T] normalized target, NaN = missing
    std: torch.Tensor        # [NB] per-basin target std used by nh's NSE loss
    sim: torch.Tensor        # [NB, T] C4 open-loop prediction (normalized), NaN where no full 270-day window
    dates: np.ndarray        # [T] datetime64[D]
    samples: torch.Tensor    # [N, 2] long (basin number, t) with full inputs, finite target, sims for t-100..t-1


def windows(arr: torch.Tensor, b: torch.Tensor, t: torch.Tensor, length: int) -> torch.Tensor:
    """arr [NB, T, ...] -> [B, length, ...], the `length` days ending at t (inclusive)."""
    idx = t[:, None] + torch.arange(-length + 1, 1, device=arr.device)[None, :]
    return arr[b[:, None], idx]


def c4_forward(model, x: torch.Tensor, xs: torch.Tensor, dyn_names: List[str], h=None, c=None) -> Dict:
    data = {'x_d': {k: x[..., i:i + 1] for i, k in enumerate(dyn_names)}, 'x_s': xs}
    if h is not None:
        data['h_n'], data['c_n'] = h, c
    return model(data)


def load_period(run_dir: Path, basins: List[str], start: str, end: str, model, device: str,
                eval_from: str = None) -> PeriodData:
    """Build arrays for `basins` over [start, end] (DD/MM/YYYY; nh adds the 269-day warm-up itself) and run C4
    open loop on every day. Samples are restricted to forecast days >= eval_from (default: start + 100 days is
    implied by the requirement that sims exist for t-100..t-1)."""
    cfg = Config(Path(run_dir) / 'config.yml')
    cfg.update_config({'device': device, 'test_start_date': start, 'test_end_date': end})
    scaler = load_scaler(Path(run_dir))
    dyn_names = list(cfg.dynamic_inputs)
    dyn, stat, y, std, dates = [], [], [], [], None
    for b in basins:
        ds = get_dataset(cfg, is_train=False, period='test', basin=b, scaler=scaler)
        xd = ds._x_d[b]['1D']
        dyn.append(torch.cat([xd[k].reshape(-1, 1) for k in dyn_names], dim=1))
        stat.append(ds._attributes[b].reshape(-1))
        y.append(ds._y[b]['1D'].reshape(-1))
        std.append(ds._per_basin_target_stds[b].reshape(-1)[0])
        d = np.asarray(ds._dates[b]['1D']).astype('datetime64[D]')
        if dates is None:
            dates = d
        elif len(d) != len(dates) or (d != dates).any():
            raise ValueError(f'basin {b}: date grid differs from the first basin')
    dyn = torch.stack(dyn).to(device)
    stat = torch.stack(stat).to(device)
    y = torch.stack(y).to(device)
    std = torch.stack(std).to(device)
    NB, T, _ = dyn.shape

    # open loop for every day with a full window
    sim = torch.full((NB, T), float('nan'), device=device)
    nan_in = torch.isnan(dyn).any(-1).float()
    nan_cum = torch.cat([torch.zeros(NB, 1, device=device), nan_in.cumsum(1)], 1)
    all_t = torch.arange(SEQ - 1, T, device=device)
    with torch.no_grad():
        for bi in range(NB):
            for s in range(0, len(all_t), 1024):
                t = all_t[s:s + 1024]
                bb = torch.full_like(t, bi)
                x = windows(dyn, bb, t, SEQ)
                ok = (nan_cum[bi, t + 1] - nan_cum[bi, t + 1 - SEQ]) == 0
                out = c4_forward(model, torch.nan_to_num(x), stat[bb], dyn_names)['y_hat'][:, -1, 0]
                sim[bi, t] = torch.where(ok, out, torch.full_like(out, float('nan')))

    # usable samples: full input window, finite target, sims available for t-100..t-1
    first = SEQ - 1 + WIN
    if eval_from is not None:
        first = max(first, int(np.searchsorted(dates, np.datetime64(eval_from, 'D'))))
    t_all = torch.arange(first, T, device=device)
    samples = []
    for bi in range(NB):
        ok_in = (nan_cum[bi, t_all + 1] - nan_cum[bi, t_all + 1 - SEQ]) == 0
        ok_y = torch.isfinite(y[bi, t_all])
        sim_win = windows(sim[bi:bi + 1].unsqueeze(-1), torch.zeros_like(t_all), t_all - 1, WIN)[..., 0]
        ok_sim = torch.isfinite(sim_win).all(1)
        keep = t_all[ok_in & ok_y & ok_sim]
        samples.append(torch.stack([torch.full_like(keep, bi), keep], 1))
    samples = torch.cat(samples).long()
    return PeriodData(basins, dyn, stat, y, std, sim, dates, samples)
