"""Learned (amortized) correctors on top of the frozen C4 LSTM: rain, output and state arms (plan v0.1)."""
