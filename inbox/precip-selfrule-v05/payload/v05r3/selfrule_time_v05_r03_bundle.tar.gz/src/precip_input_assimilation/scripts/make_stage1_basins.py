"""Draw the pre-registered 96-basin subset (32 per stratum) used by Stage 0b-4 and Stage 1, and build a local
CPU run directory for the frozen C4 seed-100 checkpoint on those basins (tuning year).

Strata come from the 0b-3 table ``results/precip_input_da_2026_09/analysis/enrichment_0b3_per_basin.csv``
(central 65 + se 71 = J-negative 136, west 116, rest 279). The draw is a fixed-seed simple random sample within each
stratum; J-negative is drawn from the pooled 136 so that the central/se mix is whatever the draw gives (reported).

Usage (repo root):
    python src/precip_input_assimilation/scripts/make_stage1_basins.py [--seed 20260922] [--check]

Writes src/precip_input_assimilation/configs/basins_96.txt and
results/precip_input_da_2026_09/local/c4_s100_96basins/ (config.yml, weights, scaler).
With --check it also compares the local open-loop tuning-year predictions against the cluster npz for all 96 basins.
"""
import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from ruamel.yaml import YAML

REPO_ROOT = Path(__file__).resolve().parents[3]
for p in (str(REPO_ROOT), str(REPO_ROOT / 'src')):
    if p not in sys.path:
        sys.path.insert(0, p)

PER_BASIN = REPO_ROOT / 'results/precip_input_da_2026_09/analysis/enrichment_0b3_per_basin.csv'
PACKAGE = REPO_ROOT / 'results/precip_input_da_2026_09/received/seq1/pida_0b1'
SOURCE_RUN = PACKAGE / 'C4_s100'
NPZ = PACKAGE / 'c4_s100_tune_year_sim_obs.npz'
BASIN_FILE = REPO_ROOT / 'src/precip_input_assimilation/configs/basins_96.txt'
TARGET = REPO_ROOT / 'results/precip_input_da_2026_09/local/c4_s100_96basins'
EXPECTED_WEIGHT_SHA = '1c755b0d6ce977db'
EPOCH = 30
PER_STRATUM = 32


def draw_basins(seed: int) -> pd.DataFrame:
    df = pd.read_csv(PER_BASIN, dtype={'basin': str})
    df['group'] = df['stratum'].map({'central': 'j_negative', 'se': 'j_negative', 'west': 'west', 'rest': 'rest'})
    rng = np.random.default_rng(seed)
    picks = []
    for group in ('j_negative', 'west', 'rest'):
        pool = df[df['group'] == group].sort_values('basin')
        idx = rng.choice(len(pool), size=PER_STRATUM, replace=False)
        picks.append(pool.iloc[np.sort(idx)])
    return pd.concat(picks).reset_index(drop=True)


def build_run_dir(basins: list, force: bool = False) -> Path:
    if TARGET.exists() and not force and (TARGET / f'model_epoch{EPOCH:03d}.pt').is_file():
        return TARGET
    if TARGET.exists():
        shutil.rmtree(TARGET)
    (TARGET / 'train_data').mkdir(parents=True)
    weight = SOURCE_RUN / f'model_epoch{EPOCH:03d}.pt'
    got = hashlib.sha256(weight.read_bytes()).hexdigest()[:16]
    if got != EXPECTED_WEIGHT_SHA:
        raise RuntimeError(f'{weight} sha256 prefix {got} != {EXPECTED_WEIGHT_SHA} (handoff section 5).')
    shutil.copy2(weight, TARGET / weight.name)
    shutil.copy2(SOURCE_RUN / 'train_data/train_data_scaler.yml', TARGET / 'train_data/train_data_scaler.yml')

    yaml = YAML()
    with (SOURCE_RUN / 'config.yml').open('r', encoding='utf-8') as fp:
        cfg = yaml.load(fp)
    cfg['dataset'] = 'camels_us'
    cfg['data_dir'] = 'data/camels_us'
    cfg.pop('track0_supervision_dir', None)
    cfg['device'] = 'cpu'
    cfg['num_workers'] = 0
    cfg['run_dir'] = str(TARGET.relative_to(REPO_ROOT)).replace('\\', '/')
    cfg['train_dir'] = cfg['run_dir'] + '/train_data'
    cfg['img_log_dir'] = cfg['run_dir'] + '/img_log'
    rel_basin_file = str(BASIN_FILE.relative_to(REPO_ROOT)).replace('\\', '/')
    for period in ('train', 'validation', 'test'):
        cfg[f'{period}_basin_file'] = rel_basin_file
    cfg['test_start_date'] = '01/10/2006'
    cfg['test_end_date'] = '30/09/2007'   # tuning year only
    cfg['cache_validation_data'] = False
    with (TARGET / 'config.yml').open('w', encoding='utf-8') as fp:
        yaml.dump(cfg, fp)
    (TARGET / 'SOURCE.txt').write_text(
        f'weights + scaler from {SOURCE_RUN.relative_to(REPO_ROOT)} (C4 seed 100, epoch 30, sha256[:16] '
        f'{EXPECTED_WEIGHT_SHA}); config rewritten for local camels_us / cpu / {len(basins)} basins / tuning year.\n',
        encoding='utf-8')
    return TARGET


def check_alignment(run_dir: Path, tolerance: float = 1e-3) -> pd.DataFrame:
    """Local open-loop tuning-year predictions vs the cluster npz, per basin."""
    import logging
    from neuralhydrology.evaluation import get_tester
    from neuralhydrology.utils.config import Config
    logging.disable(logging.CRITICAL)

    cfg = Config(run_dir / 'config.yml')
    tester = get_tester(cfg, run_dir, 'test', init_model=True)
    results = tester.evaluate(epoch=EPOCH, save_results=False, metrics=['NSE'])
    npz = np.load(NPZ, allow_pickle=True)
    cluster_basins, dates = list(npz['basins']), npz['dates'].astype('datetime64[ns]')
    rows = []
    for basin, res in results.items():
        local = res['1D']['xr']['QObs(mm/d)_sim'].sel(time_step=0).to_series().reindex(dates).values
        cluster = npz['sim'][cluster_basins.index(basin)]
        rows.append({'basin': basin, 'nse_local': float(res['1D']['NSE']),
                     'max_abs_diff': float(np.nanmax(np.abs(local - cluster))),
                     'n_nan_local': int(np.isnan(local).sum())})
    df = pd.DataFrame(rows)
    print(f'basins evaluated: {len(df)}; median local NSE {df["nse_local"].median():.4f}; '
          f'max |local - cluster| over all basins/days: {df["max_abs_diff"].max():.2e}  '
          f'-> {"PASS" if df["max_abs_diff"].max() <= tolerance else "FAIL"} (tolerance {tolerance:g})')
    worst = df.nlargest(3, 'max_abs_diff')
    print('worst 3 basins:', ', '.join(f'{r.basin} {r.max_abs_diff:.1e}' for r in worst.itertuples()))
    return df


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--seed', type=int, default=20260922)
    parser.add_argument('--force', action='store_true')
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()

    picks = draw_basins(args.seed)
    BASIN_FILE.write_text('\n'.join(picks['basin']) + '\n', encoding='utf-8')
    counts = picks['stratum'].value_counts().to_dict()
    print(f'drew {len(picks)} basins (seed {args.seed}): ' + ', '.join(f'{k} {v}' for k, v in sorted(counts.items())))
    print(f'median 0b-3 E_dis of the draw: ' + ', '.join(
        f'{g} {picks[picks["group"] == g]["E_dis"].median():.2f}' for g in ('j_negative', 'west', 'rest')))
    run_dir = build_run_dir(list(picks['basin']), force=args.force)
    print(f'run directory: {run_dir}')
    meta = {'seed': args.seed, 'per_stratum': PER_STRATUM, 'strata_counts': counts,
            'basins': {g: list(picks[picks['group'] == g]['basin']) for g in ('j_negative', 'west', 'rest')}}
    (TARGET / 'basin_draw.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')
    if args.check:
        df = check_alignment(run_dir)
        df.to_csv(TARGET / 'open_loop_alignment.csv', index=False)
    return 0


if __name__ == '__main__':
    sys.exit(main())
