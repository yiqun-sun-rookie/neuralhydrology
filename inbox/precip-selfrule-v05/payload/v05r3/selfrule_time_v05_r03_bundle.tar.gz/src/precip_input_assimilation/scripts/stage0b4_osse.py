"""Stage 0b-4 gate: OSSE twin experiment on the pre-registered 96 basins, tuning year, frozen C4 seed 100.

Design (plan v1.1 section 4 + audit v1 B7)
-----------------------------------------
Perfect model, wrong input: the "observations" are C4's own open-loop simulation on the *original* Maurer forcing, so
every error the assimilation sees is caused by the corruption we introduced and nothing else.

* forward arm  - 30% of the >= 15 mm days that lie inside the samples' assimilation windows are set to 0 mm;
                 can the additive correction put the rain back, on those days and not elsewhere?
* reverse arm  - 15 mm of fake rain is inserted on the same number of dry (< 0.1 mm) window days; can it be removed?

A corrupted calendar day is corrupted in the window region of *every* sample that contains it; days that fall into a
sample's warm-up are left alone there (audit B7 (i): only events inside assimilation windows).

Scoring. Primary definition is plan section 3: delta(d) = the estimate that the *last* assimilation window of the
sample whose forecast day is d + window + lead - 1 makes for its first day d, i.e. one number per calendar day with
5 streamflow observations constraining it. Pooled over the 96 basins (audit B7: pool events, do not take per-basin
medians):

    recovery_same_day = sum delta+(corrupted days)        / sum corrupted amount
    recovery_pm1      = sum delta+(corrupted days +-1 day) / sum corrupted amount
    precision_pm1     = sum delta+(corrupted days +-1 day) / sum delta+(all days)

with delta+ = max(+delta, 0) in the forward arm and max(-delta, 0) in the reverse arm. Also reported: the sensitivity
definition (median over the up-to-`window` samples that see the day in their last window) and the all-windows
version (mean over every window that touched the day), which includes the early windows that only get
`steps_early_windows` update steps. Recovery can exceed 1 when the correction overshoots; precision is what keeps
an overshooting setting honest.

Only days that can carry a delta(d) under the primary definition are eligible for corruption (the first and last few
days of the year are inside windows but are never a window's first day). The all-windows numbers are computed on the
same events, so the two definitions are directly comparable.

GATE (pre-registered): recovery < 50% or precision < 50% -> the line closes.

Usage (repo root):
    python src/precip_input_assimilation/scripts/stage0b4_osse.py [--settings a,b] [--max-basins N] [--dry-run]
"""
import argparse
import json
import logging
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader

REPO_ROOT = Path(__file__).resolve().parents[3]
for p in (str(REPO_ROOT), str(REPO_ROOT / 'src')):
    if p not in sys.path:
        sys.path.insert(0, p)

from neuralhydrology.datasetzoo import get_dataset  # noqa: E402
from neuralhydrology.datautils.utils import load_basin_file, load_scaler  # noqa: E402
from neuralhydrology.utils.config import Config  # noqa: E402
from precip_input_assimilation import InputAssimilationConfig, InputAssimilator  # noqa: E402
from precip_input_assimilation.evaluate import _to_device, delta_tables, load_frozen_model  # noqa: E402

RUN_DIR = REPO_ROOT / 'results/precip_input_da_2026_09/local/c4_s100_96basins'
OUT_DIR = REPO_ROOT / 'results/precip_input_da_2026_09/osse_0b4'
PRCP = 'PRCP(mm/day)'
EPOCH = 30
EVENT_MM = 15.0
DRY_MM = 0.1
DELETE_FRACTION = 0.3
GATE = 0.5

BASE_BLOCK = {
    'assimilation_lead_time': 1, 'assimilation_window': 5, 'history': 20, 'epochs': 100,
    'learning_rate_drop_factor': 0.1, 'learning_rate_epoch_drop': 1001, 'loss': 'MSE', 'model_dropout': 0.0,
    'optimizer': 'Adam', 'regularization': [], 'seq_length': 270, 'target_variables': ['QObs(mm/d)'],
    'assimilation_targets': [f'x_d:{PRCP}'], 'predict_last_n': 5, 'input_adjust_mode': 'additive',
}
# lambda grid moved down two orders of magnitude from plan v1.1 after the 0b-2 smoke: with the batch-mean
# standardized MSE one accepted step gains ~1e-3, so lambda = 0.01 rejects every step (nothing moves at all).
SETTINGS = {
    'lr0.5_l0': {'input_learning_rate_mm': 0.5, 'input_l1_lambda': 0.0},
    'lr0.5_l1e-4': {'input_learning_rate_mm': 0.5, 'input_l1_lambda': 1e-4},
    'lr0.5_l1e-3': {'input_learning_rate_mm': 0.5, 'input_l1_lambda': 1e-3},
    'lr2.0_l1e-4': {'input_learning_rate_mm': 2.0, 'input_l1_lambda': 1e-4},
    # step budget of the early windows is a Stage 1 grid axis in plan v1.1 section 4 ({5, 20}); 6 reproduces ID29's
    # `epoch >= 5` break and is what the four settings above use.
    # two interpolation points on the recovery/precision seesaw of the reverse arm (lambda 0 -> 1e-4). Flagged as
    # weak evidence in the report: a gate that only passes at a lambda picked by interpolating toward the threshold
    # is a tuned pass, not a demonstration.
    'lr0.5_l1e-5': {'input_learning_rate_mm': 0.5, 'input_l1_lambda': 1e-5},
    'lr0.5_l3e-5': {'input_learning_rate_mm': 0.5, 'input_l1_lambda': 3e-5},
    'lr0.5_l1e-4_steps20': {'input_learning_rate_mm': 0.5, 'input_l1_lambda': 1e-4, 'steps_early_windows': 20},
    'lr2.0_l1e-4_steps20': {'input_learning_rate_mm': 2.0, 'input_l1_lambda': 1e-4, 'steps_early_windows': 20},
}


def _corrupt(batch, days, start, end, value_z):
    """Set the precipitation of `days` to `value_z` inside [start, end) of every sample."""
    out = {k: ({kk: vv.clone() for kk, vv in v.items()} if isinstance(v, dict) else v) for k, v in batch.items()}
    out['y'] = batch['y'].clone()
    mask = np.isin(batch['date'][:, start:end].astype('datetime64[D]'), days)
    window = out['x_d'][PRCP][:, start:end, 0]
    window[torch.as_tensor(mask)] = value_z
    out['x_d'][PRCP][:, start:end, 0] = window
    return out


def _daily_precip(batches, scale, center) -> pd.Series:
    series = {}
    for b in batches:
        p_mm = b['x_d'][PRCP][:, :, 0].numpy() * scale + center
        for i in range(p_mm.shape[0]):
            series.update(zip(b['date'][i].astype('datetime64[D]'), p_mm[i]))
    return pd.Series(series).sort_index()


def _sums(delta: pd.Series, days: np.ndarray, sign: int) -> dict:
    """delta+ mass on the corrupted days, on their +-1 neighbourhood, and everywhere."""
    positive = np.maximum(sign * delta.to_numpy(), 0.0)
    index = delta.index.values.astype('datetime64[D]')
    on_day = np.isin(index, days)
    near = on_day.copy()
    for shift in (-1, 1):
        near |= np.isin(index, days + np.timedelta64(shift, 'D'))
    return {'same_day': float(positive[on_day].sum()), 'pm1': float(positive[near].sum()),
            'all': float(positive.sum()), 'opposite': float(np.maximum(-sign * delta.to_numpy(), 0.0).sum())}


def run(settings, max_basins, seed):
    logging.disable(logging.CRITICAL)
    cfg = Config(RUN_DIR / 'config.yml')
    cfg.update_config({'device': 'cpu'})
    scaler = load_scaler(RUN_DIR)
    scale = float(scaler['xarray_feature_scale'][PRCP])
    center = float(scaler['xarray_feature_center'][PRCP])
    z0, z_event = -center / scale, (EVENT_MM - center) / scale
    model = load_frozen_model(RUN_DIR, cfg, EPOCH, 'cpu')
    basins = load_basin_file(cfg.test_basin_file)[:max_basins]
    strata = pd.read_csv(REPO_ROOT / 'results/precip_input_da_2026_09/analysis/enrichment_0b3_per_basin.csv',
                         dtype={'basin': str}).set_index('basin')['stratum'].map(
                             {'central': 'j_negative', 'se': 'j_negative', 'west': 'west', 'rest': 'rest'})

    window, lead = BASE_BLOCK['assimilation_window'], BASE_BLOCK['assimilation_lead_time']
    n_assim = BASE_BLOCK['history'] * window
    start = BASE_BLOCK['seq_length'] - lead - n_assim
    end = start + n_assim

    assimilators = {name: InputAssimilator(InputAssimilationConfig({**BASE_BLOCK, **over}), scaler=scaler)
                    for name, over in settings.items()}
    rows, peak_rss = [], 0.0
    try:
        import psutil
        process = psutil.Process()
    except ImportError:
        process = None

    for n_basin, basin in enumerate(basins, 1):
        t_basin = time.time()
        ds = get_dataset(cfg, is_train=False, period='test', basin=basin, scaler=scaler)
        loader = DataLoader(ds, batch_size=cfg.batch_size, num_workers=0, collate_fn=ds.collate_fn)
        batches = [model.pre_model_hook(_to_device(b, 'cpu'), is_train=False) for b in loader]
        precip = _daily_precip(batches, scale, center)
        with torch.no_grad():
            truths = [model(b)['y_hat'] for b in batches]

        # days that can carry a delta(d) under the primary definition = first day of some sample's last window
        day0 = np.unique(np.concatenate([b['date'][:, -1].astype('datetime64[D]') for b in batches])) \
            - np.timedelta64(window + lead - 1, 'D')
        interior = day0[1:-1]  # +-1 neighbours must exist as well
        eligible_wet = interior[precip.reindex(interior).to_numpy() >= EVENT_MM]
        eligible_dry = interior[precip.reindex(interior).to_numpy() < DRY_MM]
        rng = np.random.default_rng(seed + int(basin))
        n_events = int(round(DELETE_FRACTION * len(eligible_wet)))
        if n_events == 0 or len(eligible_dry) < n_events:
            print(f'{basin}: skipped (wet eligible {len(eligible_wet)}, dry eligible {len(eligible_dry)})', flush=True)
            continue
        deleted = np.sort(rng.choice(eligible_wet, size=n_events, replace=False))
        inserted = np.sort(rng.choice(eligible_dry, size=n_events, replace=False))
        amounts = {'forward_delete': float(precip.reindex(deleted).sum()), 'reverse_insert': n_events * EVENT_MM}

        for direction, days, value_z, sign in (('forward_delete', deleted, z0, +1),
                                               ('reverse_insert', inserted, z_event, -1)):
            corrupted = [_corrupt(b, days, start, end, value_z) for b in batches]
            for c, t in zip(corrupted, truths):
                c['y'] = t.detach().clone()          # twin observations
            with torch.no_grad():
                mse_open = float(np.mean([((model(c)['y_hat'][:, -1] - t[:, -1])**2).mean().item()
                                          for c, t in zip(corrupted, truths)]))

            for name, assimilator in assimilators.items():
                t0 = time.time()
                outs = [assimilator.assimilate(model, c) for c in corrupted]
                elapsed = time.time() - t0
                collected = {
                    'delta_prcp_mm': np.concatenate([o['delta_prcp_mm'][:, :, 0].numpy() for o in outs], 0),
                    'assim_dates': np.concatenate([c['date'][:, start:end] for c in corrupted], 0),
                    'sample_end_date': np.concatenate([c['date'][:, -1] for c in corrupted], 0),
                }
                tables = delta_tables(collected, window=window, lead=lead)
                primary = tables['last_window']['day0']
                primary.index = primary.index.values.astype('datetime64[D]')
                sensitivity = tables['median_over_samples']['delta_mm_median']
                sensitivity.index = sensitivity.index.values.astype('datetime64[D]')
                # every window that touched the day contributes its own estimate of it; averaging (not summing)
                # keeps this comparable with the one-estimate-per-day primary definition
                all_windows = pd.Series(collected['delta_prcp_mm'].ravel(),
                                        index=collected['assim_dates'].astype('datetime64[D]').ravel()
                                        ).groupby(level=0).mean()

                mse_da = float(np.mean([((o['y_hat'][:, -1] - t[:, -1])**2).mean().item()
                                        for o, t in zip(outs, truths)]))
                row = {'basin': basin, 'stratum': strata.get(basin, 'unknown'), 'direction': direction,
                       'setting': name, 'n_events': n_events, 'amount_mm': amounts[direction],
                       'mse_open': mse_open, 'mse_da': mse_da, 'mse_ratio': mse_da / mse_open if mse_open else np.nan,
                       'seconds': elapsed,
                       'n_eff_early_mean': float(np.mean([o['n_effective_updates'][:, :-1].float().mean().item()
                                                          for o in outs])),
                       'n_eff_last_mean': float(np.mean([o['n_effective_updates'][:, -1].float().mean().item()
                                                         for o in outs]))}
                for label, series in (('primary', primary), ('sens', sensitivity), ('allwin', all_windows)):
                    row.update({f'{label}_{k}': v for k, v in _sums(series, days, sign).items()})
                rows.append(row)
                if process is not None:
                    peak_rss = max(peak_rss, process.memory_info().rss / 2**30)
        print(f'[{n_basin}/{len(basins)}] {basin} ({strata.get(basin, "?")}) {n_events} events, '
              f'{time.time() - t_basin:.0f}s, rss {peak_rss:.2f} GiB', flush=True)

    return pd.DataFrame(rows), peak_rss


def summarize(df: pd.DataFrame) -> pd.DataFrame:
    """Pooled (not per-basin) gate metrics, per direction x setting."""
    out = []
    for (direction, setting), g in df.groupby(['direction', 'setting']):
        row = {'direction': direction, 'setting': setting, 'basins': g['basin'].nunique(),
               'events': int(g['n_events'].sum()), 'amount_mm': g['amount_mm'].sum(),
               'mse_ratio_mean': g['mse_ratio'].mean(), 'seconds': g['seconds'].sum(),
               'n_eff_early_mean': g['n_eff_early_mean'].mean(), 'n_eff_last_mean': g['n_eff_last_mean'].mean()}
        for label in ('primary', 'sens', 'allwin'):
            amount = g['amount_mm'].sum()
            row[f'{label}_recovery_same_day'] = g[f'{label}_same_day'].sum() / amount
            row[f'{label}_recovery_pm1'] = g[f'{label}_pm1'].sum() / amount
            row[f'{label}_precision_pm1'] = (g[f'{label}_pm1'].sum() / g[f'{label}_all'].sum()
                                             if g[f'{label}_all'].sum() > 0 else np.nan)
        out.append(row)
    return pd.DataFrame(out)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--settings', default=','.join(SETTINGS))
    parser.add_argument('--max-basins', type=int, default=96)
    parser.add_argument('--seed', type=int, default=20260922)
    parser.add_argument('--tag', default='stage0b4')
    args = parser.parse_args()

    chosen = {k: SETTINGS[k] for k in args.settings.split(',')}
    t0 = time.time()
    df, peak_rss = run(chosen, args.max_basins, args.seed)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUT_DIR / f'{args.tag}_rows.csv', index=False)
    summary = summarize(df)
    summary.to_csv(OUT_DIR / f'{args.tag}_summary.csv', index=False)
    with (OUT_DIR / f'{args.tag}_setup.json').open('w', encoding='utf-8') as fp:
        json.dump({'base_block': BASE_BLOCK, 'settings': chosen, 'delete_fraction': DELETE_FRACTION,
                   'event_mm': EVENT_MM, 'dry_mm': DRY_MM, 'seed': args.seed, 'gate': GATE,
                   'basins': sorted(df['basin'].unique().tolist()), 'run_dir': str(RUN_DIR.relative_to(REPO_ROOT)),
                   'wall_seconds': time.time() - t0, 'peak_rss_gib': peak_rss}, fp, indent=2, default=str)

    pd.set_option('display.width', 250)
    pd.set_option('display.max_columns', 40)
    cols = ['direction', 'setting', 'basins', 'events', 'mse_ratio_mean', 'primary_recovery_same_day',
            'primary_recovery_pm1', 'primary_precision_pm1', 'sens_recovery_pm1', 'sens_precision_pm1',
            'allwin_recovery_pm1', 'allwin_precision_pm1', 'n_eff_early_mean', 'n_eff_last_mean']
    print('\n' + summary[cols].round(3).to_string(index=False))
    passed = summary[(summary['primary_recovery_pm1'] >= GATE) & (summary['primary_precision_pm1'] >= GATE)]
    print(f'\nGATE (primary definition, recovery_pm1 >= {GATE} AND precision_pm1 >= {GATE}): '
          f'{len(passed)}/{len(summary)} direction x setting combinations pass')
    if len(passed):
        print(passed[['direction', 'setting', 'primary_recovery_pm1', 'primary_precision_pm1']].round(3)
              .to_string(index=False))
    print(f'wall {time.time() - t0:.0f}s, peak RSS {peak_rss:.2f} GiB, rows -> {OUT_DIR / (args.tag + "_rows.csv")}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
