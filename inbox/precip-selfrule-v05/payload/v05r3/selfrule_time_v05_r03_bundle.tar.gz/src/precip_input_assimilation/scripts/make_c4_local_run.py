"""Assemble a local, CPU, 4-basin run directory for the frozen C4 seed-100 checkpoint retrieved in Stage 0b-1, and
check that the local data path reproduces the cluster's tuning-year open-loop predictions.

Usage (repo root):
    python src/precip_input_assimilation/scripts/make_c4_local_run.py [--skip-check]

Source package: results/precip_input_da_2026_09/received/seq1/pida_0b1/ (weights, config, scaler, tuning-year npz).
Target:         results/precip_input_da_2026_09/local/c4_s100_4basins/
The run config is rewritten to the plain ``camels_us`` dataset on data/camels_us (Stage 0b-1 verified that the local
Maurer files equal the cluster's track0 parquet for these 4 basins value for value); the test period is the tuning
year 2006-10-01..2007-09-30.
"""
import argparse
import hashlib
import shutil
import sys
from pathlib import Path

import numpy as np
from ruamel.yaml import YAML

REPO_ROOT = Path(__file__).resolve().parents[3]
PACKAGE = REPO_ROOT / 'results/precip_input_da_2026_09/received/seq1/pida_0b1'
SOURCE_RUN = PACKAGE / 'C4_s100'
NPZ = PACKAGE / 'c4_s100_tune_year_sim_obs.npz'
TARGET = REPO_ROOT / 'results/precip_input_da_2026_09/local/c4_s100_4basins'
BASIN_FILE = 'src/precip_input_assimilation/configs/basins_4.txt'
EXPECTED_WEIGHT_SHA = '1c755b0d6ce977db'
EPOCH = 30


def sha16(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()[:16]


def build_run_dir(force: bool = False) -> Path:
    if TARGET.exists() and not force and (TARGET / f'model_epoch{EPOCH:03d}.pt').is_file():
        return TARGET
    if TARGET.exists():
        shutil.rmtree(TARGET)
    (TARGET / 'train_data').mkdir(parents=True)
    weight = SOURCE_RUN / f'model_epoch{EPOCH:03d}.pt'
    if sha16(weight) != EXPECTED_WEIGHT_SHA:
        raise RuntimeError(f'{weight} sha256 prefix {sha16(weight)} != {EXPECTED_WEIGHT_SHA} (handoff §5).')
    shutil.copy2(weight, TARGET / weight.name)
    shutil.copy2(SOURCE_RUN / 'train_data/train_data_scaler.yml', TARGET / 'train_data/train_data_scaler.yml')

    yaml = YAML()
    with (SOURCE_RUN / 'config.yml').open('r', encoding='utf-8') as fp:
        cfg = yaml.load(fp)
    cfg['dataset'] = 'camels_us'
    cfg['data_dir'] = 'data/camels_us'
    cfg.pop('track0_supervision_dir', None)
    cfg['device'] = 'cpu'
    cfg['num_workers'] = 0
    cfg['run_dir'] = str(TARGET.relative_to(REPO_ROOT)).replace('\\', '/')
    cfg['train_dir'] = cfg['run_dir'] + '/train_data'
    cfg['img_log_dir'] = cfg['run_dir'] + '/img_log'
    for period in ('train', 'validation', 'test'):
        cfg[f'{period}_basin_file'] = BASIN_FILE
    cfg['test_start_date'] = '01/10/2006'
    cfg['test_end_date'] = '30/09/2007'
    cfg['cache_validation_data'] = False
    with (TARGET / 'config.yml').open('w', encoding='utf-8') as fp:
        yaml.dump(cfg, fp)
    (TARGET / 'SOURCE.txt').write_text(
        f'weights + scaler copied from {SOURCE_RUN.relative_to(REPO_ROOT)} (seed 100, epoch 30, '
        f'sha256[:16] {EXPECTED_WEIGHT_SHA}); config rewritten for local camels_us / cpu / 4 basins / tuning year.\n',
        encoding='utf-8')
    return TARGET


def check_against_cluster(run_dir: Path, tolerance: float = 1e-4) -> float:
    """Open-loop tuning-year predictions on the 4 basins vs the npz extracted on the cluster. Returns max |diff|."""
    sys.path.insert(0, str(REPO_ROOT))
    import logging
    from neuralhydrology.evaluation import get_tester
    from neuralhydrology.utils.config import Config
    logging.disable(logging.CRITICAL)

    cfg = Config(run_dir / 'config.yml')
    tester = get_tester(cfg, run_dir, 'test', init_model=True)
    results = tester.evaluate(epoch=EPOCH, save_results=False, metrics=['NSE'])
    npz = np.load(NPZ, allow_pickle=True)
    basins, dates = list(npz['basins']), npz['dates']
    worst = 0.0
    for basin, res in results.items():
        xr = res['1D']['xr']
        local = xr['QObs(mm/d)_sim'].sel(time_step=0).to_series()
        local = local.reindex(dates.astype('datetime64[ns]'))
        cluster = npz['sim'][basins.index(basin)]
        nse = float(res['1D']['NSE'])
        diff = float(np.nanmax(np.abs(local.values - cluster)))
        worst = max(worst, diff)
        print(f'{basin}: local NSE {nse:.4f}  max|local - cluster| = {diff:.2e}  '
              f'(nan local {int(np.isnan(local.values).sum())}, cluster {int(np.isnan(cluster).sum())})')
    print(f'max abs difference over 4 basins x 365 days: {worst:.2e}  ->  {"PASS" if worst <= tolerance else "FAIL"} '
          f'(tolerance {tolerance:g})')
    return worst


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--force', action='store_true')
    parser.add_argument('--skip-check', action='store_true')
    args = parser.parse_args()
    run_dir = build_run_dir(force=args.force)
    print(f'Local C4 run directory: {run_dir}')
    if not args.skip_check:
        import os
        os.chdir(REPO_ROOT)
        worst = check_against_cluster(run_dir)
        return 0 if worst <= 1e-4 else 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
