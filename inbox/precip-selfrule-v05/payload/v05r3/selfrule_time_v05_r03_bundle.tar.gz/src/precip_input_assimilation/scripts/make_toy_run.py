"""Train (once) the toy 4-basin CudaLSTM used by the unit and parity tests, and record its run directory.

Usage (repo root):
    python src/precip_input_assimilation/scripts/make_toy_run.py [--force]

Writes results/precip_input_da_2026_09/local/toy_runs/<experiment>_<timestamp>/ and a pointer file
results/precip_input_da_2026_09/local/toy_runs/LATEST holding that path. Re-running without --force reuses it.
"""
import argparse
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[3]
CONFIG_FILE = REPO_ROOT / 'src/precip_input_assimilation/configs/toy_cudalstm_4basins.yml'
TOY_ROOT = REPO_ROOT / 'results/precip_input_da_2026_09/local/toy_runs'
POINTER = TOY_ROOT / 'LATEST'


def existing_toy_run() -> Path | None:
    """Return the recorded toy run directory if it exists and holds a final checkpoint."""
    if not POINTER.is_file():
        return None
    run_dir = Path(POINTER.read_text(encoding='utf-8').strip())
    if not run_dir.is_absolute():
        run_dir = REPO_ROOT / run_dir
    if (run_dir / 'config.yml').is_file() and list(run_dir.glob('model_epoch*.pt')):
        return run_dir
    return None


def ensure_toy_run(force: bool = False) -> Path:
    """Train the toy run if missing (or `force`) and return its directory."""
    run_dir = existing_toy_run()
    if run_dir is not None and not force:
        return run_dir

    sys.path.insert(0, str(REPO_ROOT))
    import os
    from neuralhydrology.nh_run import start_run

    TOY_ROOT.mkdir(parents=True, exist_ok=True)
    before = {p for p in TOY_ROOT.iterdir() if p.is_dir()}
    cwd = os.getcwd()
    os.chdir(REPO_ROOT)  # the config uses repo-relative paths
    try:
        start_run(config_file=CONFIG_FILE, gpu=-1)
    finally:
        os.chdir(cwd)
    new_dirs = sorted(p for p in TOY_ROOT.iterdir() if p.is_dir() and p not in before)
    if not new_dirs:
        raise RuntimeError(f'Training finished but no new run directory appeared under {TOY_ROOT}.')
    run_dir = new_dirs[-1]
    POINTER.write_text(str(run_dir.relative_to(REPO_ROOT)).replace('\\', '/') + '\n', encoding='utf-8')
    return run_dir


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--force', action='store_true', help='Retrain even if a toy run is recorded.')
    args = parser.parse_args()
    run_dir = ensure_toy_run(force=args.force)
    print(f'Toy run directory: {run_dir}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
