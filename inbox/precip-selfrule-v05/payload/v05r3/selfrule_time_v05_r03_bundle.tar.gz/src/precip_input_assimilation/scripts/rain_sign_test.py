"""Diagnostic (not a pre-registered gate): does Maurer's rain error push C4's flow error in the predicted direction?

Two independent witnesses (Daymet aligned daymet(t+1)->t, and NLDAS) must both disagree with Maurer in the same
direction by more than a threshold. If rain error drives flow error, then after an OVER-report day (Maurer above both)
C4 -- which is fed Maurer -- should predict too much flow, i.e. obs - sim should DROP; after an UNDER-report day it
should RISE. We measure the change of the error over the following days relative to the day before the event
(innovation, to remove any pre-existing bias) and count how often its sign matches the prediction.

Controls: (i) 50% chance level; (ii) matched "agreement storms" (all three products within the threshold of each
other, Maurer > 10 mm), where no direction is predicted, given a random sign -> should sit at 50%.
Also reported: share of C4's squared error that falls in dry spells (all three products < 0.1 mm for the past 7 days),
which bounds how much of the error cannot be rain-driven at all.

Data: C4 seed 100 tuning-year sim/obs for 531 basins (received/seq1/.../c4_s100_tune_year_sim_obs.npz; exam year
untouched) + local CAMELS-US forcings. CPU only.

Usage (repo root):  python src/precip_input_assimilation/scripts/rain_sign_test.py
"""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

REPO = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO))
from neuralhydrology.datasetzoo.camelsus import load_camels_us_forcings  # noqa: E402

DATA = REPO / 'data/camels_us'
NPZ = REPO / 'results/precip_input_da_2026_09/received/seq1/pida_0b1/c4_s100_tune_year_sim_obs.npz'
ANALYSIS = REPO / 'results/precip_input_da_2026_09/analysis'
THRESHOLDS_MM = (5.0, 10.0)
HORIZONS = (1, 3)
RNG = np.random.default_rng(20260927)


def main() -> int:
    z = np.load(NPZ, allow_pickle=True)
    basins, dates = [str(b) for b in z['basins']], pd.DatetimeIndex(z['dates'])
    err = pd.DataFrame((z['obs'] - z['sim']).T, index=dates, columns=basins)          # obs - sim, mm/d
    strat = pd.read_csv(ANALYSIS / 'enrichment_0b3_per_basin.csv', dtype={'basin': str}).set_index('basin')['stratum'] \
        .map({'central': 'j_negative', 'se': 'j_negative', 'west': 'west', 'rest': 'rest'})
    ext = pd.date_range(dates[0] - pd.Timedelta(days=10), dates[-1] + pd.Timedelta(days=3), freq='D')
    M, D, N = {}, {}, {}
    for b in basins:
        fm, _ = load_camels_us_forcings(DATA, b, 'maurer')
        fd, _ = load_camels_us_forcings(DATA, b, 'daymet')
        fn, _ = load_camels_us_forcings(DATA, b, 'nldas')
        M[b] = fm['PRCP(mm/day)'].reindex(ext)
        D[b] = fd['prcp(mm/day)'].shift(-1, freq='D').reindex(ext)
        N[b] = fn['PRCP(mm/day)'].reindex(ext)
    M, D, N = pd.DataFrame(M), pd.DataFrame(D), pd.DataFrame(N)
    err = err.reindex(ext)

    rows, per_basin = [], {}
    for thr in THRESHOLDS_MM:
        over = (M - D > thr) & (M - N > thr)
        under = (D - M > thr) & (N - M > thr)
        agree = (M > 10) & ((M - D).abs() <= thr) & ((M - N).abs() <= thr)
        for H in HORIZONS:
            # innovation: mean error over days d+1..d+H minus error on d-1 (rain on day d shows in flow from d/d+1 on)
            fut = sum(err.shift(-k) for k in range(1, H + 1)) / H
            innov = fut - err.shift(1)
            in_year = innov.index.isin(dates)
            out = {}
            for name, ev, sign in (('over', over, -1.0), ('under', under, +1.0)):
                m = ev & in_year[:, None] & innov.notna()
                s = np.sign(innov.where(m))
                hit = (s == sign).sum().sum()
                n = m.sum().sum()
                mag = innov.where(m).abs().stack().median() if n else np.nan
                out[name] = {'events': int(n), 'hit_rate': float(hit / n) if n else np.nan, 'median_abs_innov': float(mag),
                             'basins_with_event': int((m.sum() > 0).sum())}
                # per-basin hit rates for the stratified view
                pb = ((s == sign).sum() / m.sum()).where(m.sum() >= 5)
                per_basin[(thr, H, name)] = pb
            ma = agree & in_year[:, None] & innov.notna()
            rs = RNG.choice([-1.0, 1.0], size=innov.shape)
            hit_pl = ((np.sign(innov.where(ma)) == rs).sum().sum())
            n_pl = ma.sum().sum()
            out['placebo_agree_random_sign'] = {'events': int(n_pl), 'hit_rate': float(hit_pl / n_pl) if n_pl else np.nan,
                                                'median_abs_innov': float(innov.where(ma).abs().stack().median()) if n_pl else np.nan}
            both = int(out['over']['events'] + out['under']['events'])
            both_hit = out['over']['hit_rate'] * out['over']['events'] + out['under']['hit_rate'] * out['under']['events']
            out['combined'] = {'events': both, 'hit_rate': float(both_hit / both) if both else np.nan,
                               'binomial_se': float(np.sqrt(0.25 / both)) if both else np.nan}
            by_str = {}
            for g in ('j_negative', 'west', 'rest'):
                bs = [b for b in basins if strat.get(b) == g]
                h = hits = 0
                for name, sign in (('over', -1.0), ('under', +1.0)):
                    ev = (over if name == 'over' else under)[bs] & in_year[:, None] & innov[bs].notna()
                    hits += (np.sign(innov[bs].where(ev)) == sign).sum().sum()
                    h += ev.sum().sum()
                by_str[g] = {'events': int(h), 'hit_rate': float(hits / h) if h else np.nan}
            out['by_stratum_combined'] = by_str
            rows.append({'threshold_mm': thr, 'horizon_days': H, **out})
            print(f'thr {thr:>4} mm, next {H} day(s): over-report {out["over"]["events"]} events hit {out["over"]["hit_rate"]:.3f} | '
                  f'under-report {out["under"]["events"]} events hit {out["under"]["hit_rate"]:.3f} | combined {out["combined"]["hit_rate"]:.3f} '
                  f'(±{out["combined"]["binomial_se"]:.3f}) | placebo {out["placebo_agree_random_sign"]["hit_rate"]:.3f} | '
                  f'J-neg {by_str["j_negative"]["hit_rate"]:.3f} ({by_str["j_negative"]["events"]}), west {by_str["west"]["hit_rate"]:.3f}, '
                  f'rest {by_str["rest"]["hit_rate"]:.3f}')

    # dry-spell share of squared error (tuning year)
    wet_any = np.fmax(np.fmax(M, D), N)
    dry7 = wet_any.shift(1).rolling(7, min_periods=7).max() < 0.1
    e2 = (err.loc[dates]**2)
    share = {}
    for g in ('j_negative', 'west', 'rest', 'all'):
        bs = basins if g == 'all' else [b for b in basins if strat.get(b) == g]
        d = dry7.loc[dates, bs].fillna(False)
        share[g] = {'sse_share_in_dry_spells': float(e2[bs].where(d).sum().sum() / e2[bs].sum().sum()),
                    'day_share_dry_spells': float(d.mean().mean())}
    print('dry-spell (7 d, all products < 0.1 mm) share of squared error vs share of days:',
          {g: (round(v['sse_share_in_dry_spells'], 3), round(v['day_share_dry_spells'], 3)) for g, v in share.items()})

    ANALYSIS.mkdir(parents=True, exist_ok=True)
    (ANALYSIS / 'rain_sign_test.json').write_text(json.dumps({'rows': rows, 'dry_spell_share': share}, indent=2, default=str),
                                                  encoding='utf-8')
    pd.DataFrame({f'{k[0]}mm_H{k[1]}_{k[2]}': v for k, v in per_basin.items()}).assign(stratum=strat.reindex(basins)) \
        .to_csv(ANALYSIS / 'rain_sign_test_per_basin.csv')
    return 0


if __name__ == '__main__':
    sys.exit(main())
