"""Run model-level checks that require the real frozen C4 network and forcing."""

from __future__ import annotations

import argparse
import json
import sys
import traceback
from dataclasses import replace
from datetime import date
from pathlib import Path

import numpy as np
import torch

REPO_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO_ROOT / "src"))

from precip_input_assimilation.selfrule.data import (load_normalization, load_normalized_attributes,  # noqa: E402
                                                      read_maurer_forcing, slice_indices)
from precip_input_assimilation.selfrule.manifest import verify_run_manifest  # noqa: E402
from precip_input_assimilation.selfrule.model import FrozenC4, configure_determinism  # noqa: E402
from precip_input_assimilation.selfrule.protocol import load_protocol, sha256_file, validate_protocol  # noqa: E402
from precip_input_assimilation.selfrule.rules import build_rain_rule, parameter_index_by_day  # noqa: E402

_GRADIENT_MAX_ABS_LIMIT = 1.0e-4
_GRADIENT_RELATIVE_L2_LIMIT = 5.0e-4


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", type=Path,
                        default=REPO_ROOT / "src/precip_input_assimilation/configs/selfrule_time_v05.yml")
    parser.add_argument("--data-dir", type=Path)
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--basin", default="02137727")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def _finite_list(values: np.ndarray) -> list[float | None]:
    return [float(value) if np.isfinite(value) else None for value in np.asarray(values).ravel()]


def _write_report(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")


def _gradient_run(runner: FrozenC4,
                  raw: torch.Tensor,
                  static: torch.Tensor,
                  targets: np.ndarray,
                  parameter_indices: torch.Tensor,
                  n_parameters: int,
                  batch: int | None = None) -> tuple[np.ndarray, np.ndarray, float]:
    """Differentiate the same sum of squared predictions, optionally in microbatches."""
    theta = torch.zeros(n_parameters, dtype=torch.float32, device=runner.device, requires_grad=True)
    size = len(targets) if batch is None else batch
    predictions: list[np.ndarray] = []
    objective = 0.0
    for offset in range(0, len(targets), size):
        current = torch.as_tensor(targets[offset:offset + size], device=runner.device)
        prediction = runner.predict(raw, static, current, parameter_indices, theta)
        loss = prediction.square().sum()
        loss.backward()
        objective += float(loss.detach().cpu())
        predictions.append(prediction.detach().cpu().numpy())
    if theta.grad is None:
        raise RuntimeError("Rain multiplier received no gradient")
    return (theta.grad.detach().cpu().numpy().copy(), np.concatenate(predictions), objective)


def _parameter_descriptions(rule) -> list[dict]:
    descriptions = []
    for parameter in range(rule.n_parameters):
        members = []
        for season in rule.seasons:
            for original_bin, assigned in enumerate(season.parameter_indices):
                if assigned == parameter:
                    members.append({"season": season.season, "original_bin": original_bin,
                                    "quantile_edges_mm": list(season.quantile_edges_mm)})
        descriptions.append({"parameter": parameter, "members": members})
    return descriptions


def main() -> None:
    args = parse_args()
    if args.output.exists():
        raise FileExistsError(f"Refusing to overwrite runtime validation: {args.output}")
    payload: dict = {
        "protocol": "selfrule_time_v05",
        "basin": args.basin,
        "device": args.device,
        "passed": False,
        "thresholds": {
            "gradient_max_absolute_difference": _GRADIENT_MAX_ABS_LIMIT,
            "gradient_relative_l2_difference": _GRADIENT_RELATIVE_L2_LIMIT,
        },
    }
    try:
        protocol = load_protocol(args.protocol, repo_root=REPO_ROOT)
        updates = {"output_dir": args.output_dir.resolve()}
        if args.data_dir:
            updates["data_dir"] = args.data_dir.resolve()
        if args.run_dir:
            updates["run_dir"] = args.run_dir.resolve()
        protocol = replace(protocol, **updates)
        validate_protocol(protocol, verify_files=True)
        verify_run_manifest(protocol, technical=True, requested_basins=[args.basin], device=args.device)
        configure_determinism(protocol.seed)
        _, names, center, scale, q_center, q_scale = load_normalization(protocol.run_dir)
        runner = FrozenC4(protocol.run_dir, args.device, names, center, scale, q_center, q_scale)
        forcing = read_maurer_forcing(protocol.data_dir, args.basin, protocol.forcing_start, protocol.select_end)
        static_values = load_normalized_attributes(protocol.data_dir, protocol.run_dir, [args.basin])[0]
        raw = torch.as_tensor(forcing.values, dtype=torch.float32, device=runner.device)
        static = torch.as_tensor(static_values, dtype=torch.float32, device=runner.device)
        fit_mask = ((forcing.dates >= np.datetime64(protocol.fit_start)) &
                    (forcing.dates <= np.datetime64(protocol.fit_end)))
        rule = build_rain_rule("rain_intensity", forcing.dates, forcing.values[:, 0], protocol.fit_start,
                               protocol.fit_end, fit_mask, protocol.wet_threshold_mm, protocol.min_bin_support)
        day_index = torch.as_tensor(parameter_index_by_day(rule, forcing.dates, forcing.values[:, 0]),
                                    dtype=torch.long, device=runner.device)
        candidate_targets = slice_indices(forcing.dates, date(1985, 8, 1), protocol.select_end)[-16:]
        targets = candidate_targets[candidate_targets >= runner.sequence_length - 1]
        target_tensor = torch.as_tensor(targets, device=runner.device)

        with torch.no_grad():
            original = runner.predict(raw, static, target_tensor)
            zero = runner.predict(raw, static, target_tensor, day_index,
                                  torch.zeros(rule.n_parameters, device=runner.device))
            repeated = runner.predict(raw, static, target_tensor)
        identity_max_abs = float(torch.max(torch.abs(original - zero)).cpu())
        repeat_max_abs = float(torch.max(torch.abs(original - repeated)).cpu())

        full_gradient, full_prediction, full_objective = _gradient_run(
            runner, raw, static, targets, day_index, rule.n_parameters)
        full_repeat_gradient, _, _ = _gradient_run(
            runner, raw, static, targets, day_index, rule.n_parameters)
        micro_gradient, micro_prediction, micro_objective = _gradient_run(
            runner, raw, static, targets, day_index, rule.n_parameters, batch=4)
        micro_repeat_gradient, _, _ = _gradient_run(
            runner, raw, static, targets, day_index, rule.n_parameters, batch=4)

        difference = full_gradient - micro_gradient
        absolute_difference = np.abs(difference)
        max_index = int(np.argmax(absolute_difference))
        max_absolute_difference = float(absolute_difference[max_index])
        difference_l2 = float(np.linalg.norm(difference))
        full_l2 = float(np.linalg.norm(full_gradient))
        micro_l2 = float(np.linalg.norm(micro_gradient))
        relative_l2 = difference_l2 / max(full_l2, micro_l2, 1.0e-12)
        full_repeat_max_abs = float(np.max(np.abs(full_gradient - full_repeat_gradient)))
        micro_repeat_max_abs = float(np.max(np.abs(micro_gradient - micro_repeat_gradient)))
        prediction_max_abs = float(np.max(np.abs(full_prediction - micro_prediction)))
        objective_difference = float(full_objective - micro_objective)

        raw_leaf = raw.detach().clone().requires_grad_(True)
        single_target = torch.as_tensor(targets[-1:], device=runner.device)
        runner.predict(raw_leaf, static, single_target).sum().backward()
        window_start = int(targets[-1]) - runner.sequence_length + 1
        warmup_gradient = float(raw_leaf.grad[window_start, runner.precipitation_index].detach().cpu())
        frozen_weight_gradient_count = sum(parameter.grad is not None for parameter in runner.model.parameters())

        gradient_finite = bool(np.isfinite(full_gradient).all() and np.isfinite(micro_gradient).all())
        checks = {
            "identity_rule": bool(torch.allclose(original, zero, rtol=1e-5, atol=1e-5)),
            "repeat_forward_exact": bool(torch.equal(original, repeated)),
            "gradient_finite_and_nonzero": bool(gradient_finite and np.any(full_gradient != 0)
                                                and np.any(micro_gradient != 0)),
            "gradient_max_absolute_difference": max_absolute_difference <= _GRADIENT_MAX_ABS_LIMIT,
            "gradient_relative_l2_difference": relative_l2 <= _GRADIENT_RELATIVE_L2_LIMIT,
            "full_shape_repeat_exact": full_repeat_max_abs == 0.0,
            "micro_shape_repeat_exact": micro_repeat_max_abs == 0.0,
            "warmup_gradient_finite_and_nonzero": bool(np.isfinite(warmup_gradient) and warmup_gradient != 0),
            "frozen_weights_have_no_gradient": frozen_weight_gradient_count == 0,
            "dropout_disabled": not runner.model.dropout.training and not runner.model.training,
        }
        failure_reasons = [name for name, passed in checks.items() if not passed]
        payload.update({
            "passed": not failure_reasons,
            "failure_reasons": failure_reasons,
            "checks": checks,
            "identity_max_abs": identity_max_abs,
            "repeat_max_abs": repeat_max_abs,
            "first_warmup_day_precipitation_gradient": warmup_gradient,
            "frozen_weight_gradient_count": frozen_weight_gradient_count,
            "dropout_training": runner.model.dropout.training,
            "full_model_training": runner.model.training,
            "recurrent_module_training": runner.model.lstm.training,
            "target_dates": [str(value) for value in forcing.dates[targets]],
            "microbatch_size": 4,
            "target_count": len(targets),
            "rule_parameter_count": rule.n_parameters,
            "rule_parameters": _parameter_descriptions(rule),
            "gradient": {
                "full": _finite_list(full_gradient),
                "micro": _finite_list(micro_gradient),
                "difference": _finite_list(difference),
                "full_max_abs": float(np.max(np.abs(full_gradient))),
                "micro_max_abs": float(np.max(np.abs(micro_gradient))),
                "full_l2": full_l2,
                "micro_l2": micro_l2,
                "difference_max_abs": max_absolute_difference,
                "difference_l2": difference_l2,
                "difference_relative_l2": relative_l2,
                "max_difference_parameter": max_index,
                "max_difference_full_value": float(full_gradient[max_index]),
                "max_difference_micro_value": float(micro_gradient[max_index]),
                "max_difference_sign_flip": bool(np.sign(full_gradient[max_index]) !=
                                                 np.sign(micro_gradient[max_index])),
                "full_shape_repeat_max_abs": full_repeat_max_abs,
                "micro_shape_repeat_max_abs": micro_repeat_max_abs,
            },
            "prediction": {
                "full": _finite_list(full_prediction),
                "micro": _finite_list(micro_prediction),
                "max_abs_difference": prediction_max_abs,
            },
            "objective": {
                "full": full_objective,
                "micro_sum": micro_objective,
                "difference": objective_difference,
            },
            "runtime": {
                "torch": torch.__version__,
                "cuda": torch.version.cuda,
                "cudnn": torch.backends.cudnn.version(),
                "gpu": torch.cuda.get_device_name(runner.device) if runner.device.type == "cuda" else None,
                "dtype": str(raw.dtype),
                "deterministic_algorithms": torch.are_deterministic_algorithms_enabled(),
                "cudnn_deterministic": torch.backends.cudnn.deterministic,
                "cudnn_benchmark": torch.backends.cudnn.benchmark,
                "cuda_matmul_allow_tf32": torch.backends.cuda.matmul.allow_tf32,
                "cudnn_allow_tf32": torch.backends.cudnn.allow_tf32,
                "float32_matmul_precision": torch.get_float32_matmul_precision(),
            },
            "hashes": {
                "model_weight": sha256_file(protocol.weight_file),
                "model_config": sha256_file(protocol.config_file),
                "model_scaler": sha256_file(protocol.scaler_file),
                "validation_script": sha256_file(Path(__file__)),
                "protocol_file": sha256_file(protocol.protocol_file),
                "run_manifest": sha256_file(protocol.output_dir / "RUN_MANIFEST.json"),
            },
        })
        _write_report(args.output, payload)
        print(json.dumps(payload, sort_keys=True, allow_nan=False))
        if failure_reasons:
            raise RuntimeError(f"Runtime validation failed: {failure_reasons}")
    except Exception as exc:
        if not args.output.exists():
            payload.update({
                "passed": False,
                "failure_reasons": ["exception"],
                "exception": f"{type(exc).__name__}: {exc}",
                "traceback": traceback.format_exc(),
            })
            _write_report(args.output, payload)
        raise


if __name__ == "__main__":
    main()
