"""Geometry facts only (no hydrological outcome): how far apart the 531 basins are, and which pairs are nested.

Reads the CAMELS basin polygons straight from data/camels_us/raw/basin_set_full_res.zip (nothing is extracted), projects
to CONUS Albers (EPSG:5070), and writes results/precip_input_da_2026_09/analysis/basin_geometry.csv (centroids, areas,
nearest non-nested neighbour) and basin_nested_pairs.csv. A pair is "nested" when the polygons overlap by more than half
of the smaller basin's area.

Usage (repo root):  python src/precip_input_assimilation/scripts/basin_geometry.py
"""
import numpy as np, pandas as pd, geopandas as gpd
from pathlib import Path
basins = Path('src/fair_benchmark/frozen/track0_forcing_only_basins.txt').read_text().split()
g = gpd.read_file('zip://data/camels_us/raw/basin_set_full_res.zip!HCDN_nhru_final_671.shp')
g['basin'] = g['hru_id'].astype(int).astype(str).str.zfill(8)
g = g[g.basin.isin(basins)].to_crs('EPSG:5070').reset_index(drop=True)   # CONUS Albers, metres
print('polygons matched:', len(g), 'of', len(basins))
c = np.c_[g.geometry.centroid.x, g.geometry.centroid.y] / 1000.0
D = np.sqrt(((c[:, None, :] - c[None, :, :])**2).sum(-1)); np.fill_diagonal(D, np.inf)
area = g.geometry.area.values / 1e6
# nesting: intersection covers >50% of the smaller basin
nested = np.zeros_like(D, dtype=bool)
sidx = g.sindex
for i, geom in enumerate(g.geometry):
    for j in sidx.query(geom, predicate='intersects'):
        if j <= i: continue
        inter = geom.intersection(g.geometry[j]).area / 1e6
        if inter > 0.5 * min(area[i], area[j]):
            nested[i, j] = nested[j, i] = True
Dn = np.where(nested, np.inf, D)
nn = Dn.min(1)
print(f'nested pairs (overlap >50% of smaller basin): {int(nested.sum() // 2)}; basins involved: {int(nested.any(1).sum())}')
print('centroid distance to nearest NON-nested neighbour (km): p10 {:.0f} / median {:.0f} / p90 {:.0f}'.format(*np.percentile(nn, [10, 50, 90])))
for r in (50, 100, 150, 200):
    k = (Dn < r).sum(1)
    print(f'  within {r:3d} km: basins with >=1 neighbour {100*(k>=1).mean():.0f}%, >=3 neighbours {100*(k>=3).mean():.0f}%, median count {np.median(k):.0f}')
print('basin area km2: median {:.0f}, p10-p90 {:.0f}-{:.0f}'.format(np.median(area), *np.percentile(area, [10, 90])))
per = pd.read_csv('results/precip_input_da_2026_09/analysis/enrichment_0b3_per_basin.csv', dtype={'basin': str}).set_index('basin')['stratum']
grp = g.basin.map(per).map({'central': 'j_negative', 'se': 'j_negative', 'west': 'west', 'rest': 'rest'})
for s in ('j_negative', 'west', 'rest'):
    m = (grp == s).values
    k100 = (Dn[m] < 100).sum(1)
    print(f'{s:10s} n={m.sum():3d}: nearest non-nested median {np.median(nn[m]):.0f} km; >=1 within 100 km {100*(k100>=1).mean():.0f}%, >=3 within 100 km {100*(k100>=3).mean():.0f}%')
out = Path('results/precip_input_da_2026_09/analysis')
out.mkdir(parents=True, exist_ok=True)
pd.DataFrame({'basin': g.basin, 'cx_km': c[:, 0], 'cy_km': c[:, 1], 'area_km2': area, 'nn_nonnested_km': nn,
              'n_nested_partners': nested.sum(1)}).to_csv(out / 'basin_geometry.csv', index=False)
ii, jj = np.where(np.triu(nested, 1))
pd.DataFrame({'basin_a': g.basin.values[ii], 'basin_b': g.basin.values[jj], 'centroid_km': D[ii, jj]}).to_csv(
    out / 'basin_nested_pairs.csv', index=False)
print('wrote', out / 'basin_geometry.csv', 'and basin_nested_pairs.csv')
