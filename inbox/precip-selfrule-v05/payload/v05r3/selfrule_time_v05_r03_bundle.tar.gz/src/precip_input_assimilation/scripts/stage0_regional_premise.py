"""Stage 0 of plan v1.1 (docs/plans/2026-09-27-precip-regional-joint-corrector-plan-v1.1.md): zero-training checks that
decide whether the regional "rain + memory" corrector line lives.

Data flow (nothing is trained; the tuning and exam years are not touched):
  * rainfall products, 531 basins: Maurer, Daymet aligned as daymet(t+1)->t, NLDAS (local CAMELS-US files);
  * C4 seed 100 (frozen) open loop on 1980-10-01..1989-09-30 for all 531 basins (local GPU) -> daily error
    e_t = obs_t - sim_t (normalized flow units);
  * geometry: basin centroids / nested pairs from scripts/basin_geometry.py; HUC-2 regions from camels_name.txt.

0a  (descriptive; kill only): 1999-10..2006-09, non-nested pairs within 200 km, Pearson correlation of the daily
    difference Maurer - Daymet(aligned) on days where either basin has Maurer >= 1 mm; same for the 2-day-sum difference
    Maurer - NLDAS (sidesteps day-boundary misalignment). Distance bins 0-25/25-50/50-100/100-150/150-200 km.
    Fit r(d) = c * exp(-d / L) to the Daymet pairs -> correlation length L.
    KILL: median correlation in the 25-50 km bin (Daymet version) < 0.1.
Neighbour graph for 0b/0c: up to K = 8 nearest non-nested basins within R = clip(2 L, 50, 150) km.
    (The 50 km floor is an implementation choice fixed before any outcome is computed.)
0b  (report, soft gate): innovations de_t = e_t - e_{t-1}; per neighbour pair, correlation of de over
    "disagreement days + following 3 days" (either basin |Maurer - Daymet| > 10 mm) vs "agreement storm days + 3"
    (either basin Maurer > 10 and Daymet > 10 and |diff| <= 10, excluding disagreement spans), agreement events
    subsampled to match the disagreement events' Maurer-amount histogram (bins 10-20/20-40/>=40 mm, pair maximum).
    Pair difference corr_dis - corr_agree; median; HUC-2 block bootstrap (pair assigned to the first basin's region).
0c  (HARD gate; ID28-style ridge + spatial block bootstrap):
    per basin, ridge (alpha = 1, standardized features, unpenalized intercept):
        base: e_t ~ own e_{t-1}, e_{t-2}
        full: base + neighbours' e_{t-1}, e_{t-2}      (neighbour NaN -> 0)
    fit on target days 1981-01-01..1988-09-30, score on 1988-10-01..1989-09-30; incremental R^2 = R2_full - R2_base.
    Summary = median over basins; 95% CI from 10,000 HUC-2 block-bootstrap resamples.
    dry(i, t): max over basin i and its neighbours, over days t-7..t-1, of max(Maurer(d), Daymet(d+1), NLDAS(d),
    NLDAS(d+1)) < 0.1 mm; wet = not dry. Increment computed within each group on the scoring year with the same fit.
    A basin enters the dry comparison only with >= 20 dry scoring days; if fewer than 100 basins qualify, the
    pre-registered fallback threshold 1.0 mm replaces 0.1 mm (reported).
    Near-distance excess: per basin, k = min(#non-nested neighbours at 25-50 km, # at 150-200 km, 8) closest in each
    bin; excess = increment(near k) - increment(far k).
    GATE 0c-1: lower 95% bound of the all-basin median increment < 0.02            -> close the line.
    GATE 0c-2: median dry increment >= 0.5 x median wet increment                    -> co-movement is not mainly rain.
    GATE 0c-3: lower 95% bound of the median near-distance excess <= 0               -> only regional bias.
    Robustness (reported, not gating): leave-one-water-year-out (1981..1989) out-of-sample increments.

Usage (repo root):  python src/precip_input_assimilation/scripts/stage0_regional_premise.py [--max-basins N] [--tag X]
"""
import argparse
import hashlib
import json
import logging
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch

REPO = Path(__file__).resolve().parents[3]
for p in (str(REPO), str(REPO / 'src')):
    if p not in sys.path:
        sys.path.insert(0, p)

from neuralhydrology.datasetzoo.camelsus import load_camels_us_forcings  # noqa: E402
from neuralhydrology.utils.config import Config  # noqa: E402
from precip_input_assimilation.evaluate import load_frozen_model  # noqa: E402
from precip_input_assimilation.learned.data import load_period  # noqa: E402

DATA = REPO / 'data/camels_us'
RUN_DIR = REPO / 'results/precip_input_da_2026_09/local/c4_s100_96basins'
ANALYSIS = REPO / 'results/precip_input_da_2026_09/analysis'
OUT_ROOT = REPO / 'results/precip_input_da_2026_09/stage0_regional'
PLAN = REPO / 'docs/plans/2026-09-27-precip-regional-joint-corrector-plan-v1.1.md'
BINS = [0, 25, 50, 100, 150, 200]
K = 8
ALPHA = 1.0
N_BOOT = 10000
GATES = {'0a_kill_corr_25_50_lt': 0.1, '0c1_lower_ci_lt': 0.02, '0c2_dry_over_wet_ge': 0.5, '0c3_lower_ci_le': 0.0}
DRY_MM, DRY_FALLBACK_MM, MIN_DRY_DAYS, MIN_DRY_BASINS = 0.1, 1.0, 20, 100


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_products(basins, start, end):
    """Daily Maurer, Daymet aligned (t+1 -> t), NLDAS as DataFrames [dates x basins] (mm/day)."""
    dates = pd.date_range(start, end, freq='D')
    m, d, n = {}, {}, {}
    for b in basins:
        fm, _ = load_camels_us_forcings(DATA, b, 'maurer')
        fd, _ = load_camels_us_forcings(DATA, b, 'daymet')
        fn, _ = load_camels_us_forcings(DATA, b, 'nldas')
        m[b] = fm['PRCP(mm/day)'].reindex(dates)
        d[b] = fd['prcp(mm/day)'].shift(-1, freq='D').reindex(dates)
        n[b] = fn['PRCP(mm/day)'].reindex(dates)
    return pd.DataFrame(m), pd.DataFrame(d), pd.DataFrame(n)


def pair_corr(a: np.ndarray, b: np.ndarray, mask: np.ndarray, min_n: int = 100) -> float:
    ok = mask & np.isfinite(a) & np.isfinite(b)
    if ok.sum() < min_n or np.std(a[ok]) == 0 or np.std(b[ok]) == 0:
        return np.nan
    return float(np.corrcoef(a[ok], b[ok])[0, 1])


def fit_exp(d: np.ndarray, r: np.ndarray):
    """Least-squares fit r = c * exp(-d / L) on a grid (no scipy dependency)."""
    ok = np.isfinite(r)
    d, r = d[ok], r[ok]
    best = (np.inf, None, None)
    for L in np.geomspace(5, 2000, 400):
        g = np.exp(-d / L)
        c = float(np.clip((g * r).sum() / (g * g).sum(), 0, 1))
        sse = float(((r - c * g)**2).sum())
        if sse < best[0]:
            best = (sse, c, float(L))
    return best[1], best[2]


def ridge_fit(X, y):
    mu, sd = X.mean(0), X.std(0)
    sd[sd == 0] = 1.0
    Xs = (X - mu) / sd
    ym = y.mean()
    beta = np.linalg.solve(Xs.T @ Xs + ALPHA * np.eye(Xs.shape[1]), Xs.T @ (y - ym))
    return lambda Z: ((Z - mu) / sd) @ beta + ym


def r2(y, yhat):
    sst = ((y - y.mean())**2).sum()
    return np.nan if sst <= 0 else float(1 - ((y - yhat)**2).sum() / sst)


def block_ci(values: pd.Series, region: pd.Series, rng, stat=np.nanmedian, n=N_BOOT):
    """Point estimate and 95% interval of stat(values) under resampling HUC-2 regions with replacement."""
    v = values.dropna()
    vals = v.to_numpy(dtype=float)
    regs = region.reindex(v.index).to_numpy()
    groups = [vals[regs == g] for g in sorted(set(regs))]
    point = float(stat(vals))
    boot = np.empty(n)
    for k in range(n):
        pick = rng.integers(0, len(groups), len(groups))
        boot[k] = stat(np.concatenate([groups[i] for i in pick]))
    return point, float(np.nanpercentile(boot, 2.5)), float(np.nanpercentile(boot, 97.5))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--max-basins', type=int, default=None)
    ap.add_argument('--tag', default='full')
    args = ap.parse_args()
    logging.disable(logging.CRITICAL)
    t_start = time.time()
    out = OUT_ROOT / args.tag
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(20260927)

    prereg = {'plan': str(PLAN.relative_to(REPO)), 'plan_sha256': sha(PLAN),
              'script_sha256': sha(Path(__file__)), 'gates': GATES, 'K': K, 'alpha': ALPHA, 'n_boot': N_BOOT,
              'dry_mm': DRY_MM, 'dry_fallback_mm': DRY_FALLBACK_MM, 'min_dry_days': MIN_DRY_DAYS,
              'min_dry_basins': MIN_DRY_BASINS, 'written_before_outcomes': time.strftime('%Y-%m-%d %H:%M:%S')}
    (out / 'prereg.json').write_text(json.dumps(prereg, indent=2), encoding='utf-8')

    geo = pd.read_csv(ANALYSIS / 'basin_geometry.csv', dtype={'basin': str}).set_index('basin')
    nested = pd.read_csv(ANALYSIS / 'basin_nested_pairs.csv', dtype={'basin_a': str, 'basin_b': str})
    names = pd.read_csv(DATA / 'camels_attributes_v2.0/camels_name.txt', sep=';', dtype={'gauge_id': str, 'huc_02': str})
    huc2 = names.set_index('gauge_id')['huc_02']
    strat = pd.read_csv(ANALYSIS / 'enrichment_0b3_per_basin.csv', dtype={'basin': str}).set_index('basin')['stratum'] \
        .map({'central': 'j_negative', 'se': 'j_negative', 'west': 'west', 'rest': 'rest'})
    basins = list(geo.index)[:args.max_basins] if args.max_basins else list(geo.index)
    geo = geo.loc[basins]
    xy = geo[['cx_km', 'cy_km']].to_numpy()
    D = np.sqrt(((xy[:, None, :] - xy[None, :, :])**2).sum(-1))
    np.fill_diagonal(D, np.inf)
    idx = {b: i for i, b in enumerate(basins)}
    for a, b in zip(nested.basin_a, nested.basin_b):
        if a in idx and b in idx:
            D[idx[a], idx[b]] = D[idx[b], idx[a]] = np.inf      # nested pairs are never neighbours
    region = huc2.reindex(basins)

    # ---------------- 0a: spatial structure of product disagreement (1999-10..2006-09) ----------------
    t0 = time.time()
    M_all, D_all, N_all = load_products(basins, '1980-01-01', '2006-12-31')
    sl = slice('1999-10-01', '2006-09-30')
    M, Dy, N = M_all.loc[sl], D_all.loc[sl], N_all.loc[sl]
    diffD = (M - Dy).to_numpy()
    M2 = (M + M.shift(-1)).to_numpy()
    diffN2 = ((M + M.shift(-1)) - (N + N.shift(-1))).to_numpy()
    Mv = M.to_numpy()
    rows = []
    ii, jj = np.where(np.triu(D < BINS[-1], 1))
    for i, j in zip(ii, jj):
        wet1 = (Mv[:, i] >= 1) | (Mv[:, j] >= 1)
        wet2 = (M2[:, i] >= 1) | (M2[:, j] >= 1)
        rows.append({'a': basins[i], 'b': basins[j], 'dist_km': D[i, j],
                     'r_daymet': pair_corr(diffD[:, i], diffD[:, j], wet1),
                     'r_nldas2d': pair_corr(diffN2[:, i], diffN2[:, j], wet2)})
    pairs = pd.DataFrame(rows)
    pairs['bin'] = pd.cut(pairs.dist_km, BINS)
    pairs.to_csv(out / 'pairs_0a.csv', index=False)
    bin_tab = pairs.groupby('bin', observed=True).agg(n=('r_daymet', 'size'), r_daymet_median=('r_daymet', 'median'),
                                                      r_nldas2d_median=('r_nldas2d', 'median'))
    c_fit, L_fit = fit_exp(pairs.dist_km.to_numpy(), pairs.r_daymet.to_numpy())
    cN, LN = fit_exp(pairs.dist_km.to_numpy(), pairs.r_nldas2d.to_numpy())
    r_25_50 = float(pairs.loc[(pairs.dist_km > 25) & (pairs.dist_km <= 50), 'r_daymet'].median())
    R_km = float(np.clip(2 * L_fit, 50, 150))
    print(f'[0a] {len(pairs)} pairs, {time.time() - t0:.0f}s\n{bin_tab.round(3).to_string()}\n'
          f'fit Daymet: c={c_fit:.2f} L={L_fit:.0f} km | fit NLDAS 2-day: c={cN:.2f} L={LN:.0f} km | '
          f'25-50 km median r = {r_25_50:.3f} -> {"KILL" if r_25_50 < GATES["0a_kill_corr_25_50_lt"] else "pass"}; '
          f'neighbour radius R = {R_km:.0f} km', flush=True)

    # neighbour lists
    nbrs = {}
    for i, b in enumerate(basins):
        order = np.argsort(D[i])
        nbrs[b] = [basins[j] for j in order[:K] if D[i, j] <= R_km]
    n_nb = pd.Series({b: len(v) for b, v in nbrs.items()})

    # ---------------- C4 open loop 1980-10..1989-09 ----------------
    t0 = time.time()
    dev = 'cuda:0' if torch.cuda.is_available() else 'cpu'
    cfg = Config(RUN_DIR / 'config.yml')
    cfg.update_config({'device': dev})
    model = load_frozen_model(RUN_DIR, cfg, 30, dev)
    pdat = load_period(RUN_DIR, basins, '01/10/1980', '30/09/1989', model, dev)
    dates = pd.DatetimeIndex(pdat.dates)
    E = pd.DataFrame((pdat.y - pdat.sim).cpu().numpy().T, index=dates, columns=basins)   # e = obs - sim
    Yobs = pd.DataFrame(pdat.y.cpu().numpy().T, index=dates, columns=basins)
    gpu_peak = torch.cuda.max_memory_allocated() / 2**30 if dev.startswith('cuda') else float('nan')
    del pdat, model
    torch.cuda.empty_cache() if dev.startswith('cuda') else None
    period = (dates >= '1980-10-01')
    miss = Yobs.loc[period].isna().mean()
    print(f'[C4] open loop {len(basins)} basins 1980-10..1989-09 in {time.time() - t0:.0f}s, GPU peak {gpu_peak:.2f} GiB; '
          f'obs missing median {miss.median():.3f}, max {miss.max():.3f}; neighbours per basin median {n_nb.median():.0f} '
          f'(0 neighbours: {int((n_nb == 0).sum())})', flush=True)

    # products for the 1980s (dryness, 0b classes)
    M8, D8, N8 = M_all.reindex(dates), D_all.reindex(dates), N_all.reindex(dates)
    wetness = np.fmax(np.fmax(M8, D8), np.fmax(N8, N8.shift(-1, freq='D').reindex(dates)))

    def dry_mask(thr):
        """dry[t, i]: basin i and its neighbours all below thr on days t-7..t-1 (all products)."""
        out_ = {}
        for b in basins:
            hood = wetness[[b] + nbrs[b]].max(axis=1)
            out_[b] = hood.shift(1).rolling(7, min_periods=7).max() < thr
        return pd.DataFrame(out_)

    # ---------------- 0c: ridge increments ----------------
    t0 = time.time()
    fit_end, sc_start, sc_end = pd.Timestamp('1988-09-30'), pd.Timestamp('1988-10-01'), pd.Timestamp('1989-09-30')
    tgt_start = pd.Timestamp('1981-01-01')
    lag1, lag2 = E.shift(1), E.shift(2)

    def design(b, nb_list):
        own = np.c_[lag1[b].to_numpy(), lag2[b].to_numpy()]
        if nb_list:
            nb = np.concatenate([np.nan_to_num(lag1[nb_list].to_numpy()), np.nan_to_num(lag2[nb_list].to_numpy())], 1)
        else:
            nb = np.zeros((len(dates), 0))
        return own, nb

    def increments(b, nb_list, groups=None, folds=False):
        y = E[b].to_numpy()
        own, nb = design(b, nb_list)
        ok = np.isfinite(y) & np.isfinite(own).all(1) & (dates >= tgt_start) & (dates <= sc_end)
        fit = ok & (dates <= fit_end)
        sc = ok & (dates >= sc_start)
        if fit.sum() < 500 or sc.sum() < 100 or nb.shape[1] == 0:
            return None
        Xb, Xf = own, np.c_[own, nb]
        fb, ff = ridge_fit(Xb[fit], y[fit]), ridge_fit(Xf[fit], y[fit])
        pb, pf = fb(Xb), ff(Xf)
        res = {'inc': r2(y[sc], pf[sc]) - r2(y[sc], pb[sc]), 'r2_base': r2(y[sc], pb[sc]), 'n_score': int(sc.sum())}
        if groups is not None:
            for name, g in groups.items():
                m = sc & g
                res[f'n_{name}'] = int(m.sum())
                if m.sum() >= MIN_DRY_DAYS:
                    res[f'inc_{name}'] = r2(y[m], pf[m]) - r2(y[m], pb[m])
                    res[f'dmse_{name}'] = float(((y[m] - pb[m])**2).mean() - ((y[m] - pf[m])**2).mean())
        if folds:
            wy = dates.year + (dates.month >= 10)
            pb_oos, pf_oos = np.full(len(y), np.nan), np.full(len(y), np.nan)
            for w in range(1981, 1990):
                tr, te = ok & (wy != w), ok & (wy == w)
                if te.sum() < 50:
                    continue
                pb_oos[te] = ridge_fit(Xb[tr], y[tr])(Xb[te])
                pf_oos[te] = ridge_fit(Xf[tr], y[tr])(Xf[te])
            m = ok & np.isfinite(pb_oos)
            res['inc_lowo'] = r2(y[m], pf_oos[m]) - r2(y[m], pb_oos[m])
        return res

    dry01 = dry_mask(DRY_MM)
    per = {}
    for b in basins:
        g = {'dry': dry01[b].fillna(False).to_numpy(), 'wet': ~dry01[b].fillna(False).to_numpy()}
        r = increments(b, nbrs[b], groups=g, folds=True)
        if r is not None:
            per[b] = r
    per = pd.DataFrame(per).T.apply(pd.to_numeric, errors='coerce')
    n_dry_ok = int(per['inc_dry'].notna().sum()) if 'inc_dry' in per else 0
    dry_thr_used = DRY_MM
    if n_dry_ok < MIN_DRY_BASINS:
        dry_thr_used = DRY_FALLBACK_MM
        dry1 = dry_mask(DRY_FALLBACK_MM)
        for b in per.index:
            g = {'dry': dry1[b].fillna(False).to_numpy(), 'wet': ~dry1[b].fillna(False).to_numpy()}
            r = increments(b, nbrs[b], groups=g)
            for k_ in ('n_dry', 'inc_dry', 'dmse_dry', 'n_wet', 'inc_wet', 'dmse_wet'):
                per.loc[b, k_] = r.get(k_, np.nan) if r else np.nan
        n_dry_ok = int(per['inc_dry'].notna().sum())

    # near-distance excess
    exc = {}
    for i, b in enumerate(basins):
        near = [basins[j] for j in np.argsort(D[i]) if 25 < D[i, j] <= 50]
        far = [basins[j] for j in np.argsort(D[i]) if 150 < D[i, j] <= 200]
        k = min(len(near), len(far), K)
        if k < 1:
            continue
        rn, rf = increments(b, near[:k]), increments(b, far[:k])
        if rn and rf:
            exc[b] = {'k': k, 'inc_near': rn['inc'], 'inc_far': rf['inc'], 'excess': rn['inc'] - rf['inc']}
    exc = pd.DataFrame(exc).T.apply(pd.to_numeric, errors='coerce')
    per = per.join(exc, how='left')
    per['stratum'] = strat.reindex(per.index)
    per['huc2'] = region.reindex(per.index)
    per['n_neighbours'] = n_nb.reindex(per.index)
    per['obs_missing_1980s'] = miss.reindex(per.index)
    per.to_csv(out / 'per_basin_0c.csv')
    print(f'[0c] ridge fits for {len(per)} basins in {time.time() - t0:.0f}s; dry threshold used {dry_thr_used} mm '
          f'({n_dry_ok} basins with >= {MIN_DRY_DAYS} dry scoring days); excess on {exc.shape[0]} basins', flush=True)

    reg = per['huc2']
    inc_pt, inc_lo, inc_hi = block_ci(per['inc'].astype(float), reg, rng)
    dry_pt = float(per['inc_dry'].astype(float).median())
    wet_pt = float(per.loc[per['inc_dry'].notna(), 'inc_wet'].astype(float).median())
    exc_pt, exc_lo, exc_hi = block_ci(per['excess'].astype(float), reg, rng) if 'excess' in per else (np.nan,) * 3
    lowo_pt, lowo_lo, lowo_hi = block_ci(per['inc_lowo'].astype(float), reg, rng)
    ratio = dry_pt / wet_pt if wet_pt and np.isfinite(wet_pt) and wet_pt != 0 else np.nan

    # ---------------- 0b: innovation correlations, rain-matched ----------------
    t0 = time.time()
    dE = E - E.shift(1)
    in_err = (dates >= tgt_start) & (dates <= sc_end)
    dis = ((M8 - D8).abs() > 10)
    agree = (M8 > 10) & (D8 > 10) & ((M8 - D8).abs() <= 10)

    def span(mask):
        m = mask.copy()
        for s in range(1, 4):
            m |= mask.shift(s, fill_value=False)
        return m

    rows_b = []
    bins_mm = [10, 20, 40, np.inf]
    for i, b in enumerate(basins):
        for c in nbrs[b]:
            if basins.index(c) < i:
                continue
            ev_dis = (dis[b] | dis[c]) & in_err
            ev_agr = (agree[b] | agree[c]) & in_err & ~span(ev_dis)
            amt = np.fmax(M8[b], M8[c])
            hd = np.histogram(amt[ev_dis], bins_mm)[0]
            pick = []
            for lo_, hi_, need in zip(bins_mm[:-1], bins_mm[1:], hd):
                cand = np.where(ev_agr & (amt >= lo_) & (amt < hi_))[0]
                if need > 0 and len(cand) > 0:
                    pick.extend(rng.choice(cand, size=min(need, len(cand)), replace=False))
            ev_agr_m = pd.Series(False, index=dates)
            ev_agr_m.iloc[pick] = True
            sd_, sa_ = span(ev_dis) & in_err, span(ev_agr_m) & in_err
            x, y = dE[b].to_numpy(), dE[c].to_numpy()
            rd = pair_corr(x, y, sd_.to_numpy(), min_n=30)
            ra = pair_corr(x, y, sa_.to_numpy(), min_n=30)
            rows_b.append({'a': b, 'b': c, 'dist_km': D[i, basins.index(c)], 'r_dis': rd, 'r_agree_matched': ra,
                           'n_dis_events': int(ev_dis.sum()), 'n_agree_events_matched': len(pick)})
    pb = pd.DataFrame(rows_b)
    pb['diff'] = pb.r_dis - pb.r_agree_matched
    pb.to_csv(out / 'pairs_0b.csv', index=False)
    b_pt, b_lo, b_hi = block_ci(pb.set_index('a')['diff'].astype(float), region, rng) if len(pb) else (np.nan,) * 3
    print(f'[0b] {len(pb)} neighbour pairs in {time.time() - t0:.0f}s', flush=True)

    # ---------------- summary & gates ----------------
    by_stratum = per.groupby('stratum')[['inc', 'inc_dry', 'inc_wet', 'excess', 'inc_lowo']].median()
    g0a = 'KILL' if r_25_50 < GATES['0a_kill_corr_25_50_lt'] else 'pass'
    g1 = 'CLOSE' if inc_lo < GATES['0c1_lower_ci_lt'] else 'pass'
    if n_dry_ok < MIN_DRY_BASINS or not np.isfinite(ratio):
        g2 = f'NOT_EVALUABLE ({n_dry_ok} basins with >= {MIN_DRY_DAYS} dry scoring days at {dry_thr_used} mm)'
    else:
        g2 = 'NOT_MAINLY_RAIN' if ratio >= GATES['0c2_dry_over_wet_ge'] else 'pass'
    g3 = 'REGIONAL_BIAS_ONLY' if (np.isfinite(exc_lo) and exc_lo <= GATES['0c3_lower_ci_le']) else 'pass'
    summary = {
        '0a': {'bins': bin_tab.round(4).reset_index().astype(str).to_dict('records'), 'r_25_50_median': r_25_50,
               'fit_daymet_c_L': [c_fit, L_fit], 'fit_nldas2d_c_L': [cN, LN], 'gate': g0a, 'R_km': R_km},
        '0b': {'n_pairs': len(pb), 'median_diff_dis_minus_agree': b_pt, 'ci95': [b_lo, b_hi],
               'median_r_dis': float(pb.r_dis.median()), 'median_r_agree_matched': float(pb.r_agree_matched.median())},
        '0c': {'n_basins': len(per), 'median_increment': inc_pt, 'ci95': [inc_lo, inc_hi], 'gate_0c1': g1,
               'dry_threshold_mm': dry_thr_used, 'n_basins_dry_ok': n_dry_ok, 'median_inc_dry': dry_pt,
               'median_inc_wet_same_basins': wet_pt, 'dry_over_wet': ratio, 'gate_0c2': g2,
               'median_excess_near_minus_far': exc_pt, 'excess_ci95': [exc_lo, exc_hi], 'n_basins_excess': int(exc.shape[0]),
               'gate_0c3': g3, 'robustness_leave_one_wy_out': {'median': lowo_pt, 'ci95': [lowo_lo, lowo_hi]},
               'median_r2_base': float(per.r2_base.median()),
               'by_stratum_median': by_stratum.round(4).to_dict()},
        'resources': {'gpu_peak_gib': gpu_peak, 'wall_s': time.time() - t_start},
    }
    (out / 'summary.json').write_text(json.dumps(summary, indent=2, default=str), encoding='utf-8')
    print('\n==== Stage 0 summary ====')
    print(f'0a  25-50 km median corr(Maurer-Daymet) = {r_25_50:.3f}  -> {g0a};  L = {L_fit:.0f} km (NLDAS 2-day L = {LN:.0f} km)')
    print(f'0b  median [r(dis+3) - r(agree matched +3)] = {b_pt:+.3f}  95% [{b_lo:+.3f}, {b_hi:+.3f}]  ({len(pb)} pairs)')
    print(f'0c-1 median incremental R2 = {inc_pt:.4f}  95% [{inc_lo:.4f}, {inc_hi:.4f}]  -> {g1}   '
          f'(base R2 median {per.r2_base.median():.3f}; leave-one-WY-out {lowo_pt:.4f} [{lowo_lo:.4f}, {lowo_hi:.4f}])')
    print(f'0c-2 dry ({dry_thr_used} mm, {n_dry_ok} basins) median inc {dry_pt:.4f} vs wet {wet_pt:.4f} -> ratio '
          f'{ratio:.2f} -> {g2}')
    print(f'0c-3 near-far excess median {exc_pt:+.4f}  95% [{exc_lo:+.4f}, {exc_hi:+.4f}]  ({exc.shape[0]} basins) -> {g3}')
    print(by_stratum.round(4).to_string())
    print(f'wall {time.time() - t_start:.0f}s -> {out}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
