"""Placebo control for the Stage 0b-4 precision number: how much delta+ mass would land on a *matched* set of days
that were never corrupted?

The gate asks for precision >= 50%, an absolute threshold. That number only becomes interpretable next to a chance
level, and "chance" must be matched: delta+ concentrates on rainy days anyway, so the honest placebo is a set of
>= 15 mm days of the same size that we did *not* corrupt (plus, for the reverse arm, uncorrupted dry days).

For each basin this re-runs one setting of the twin experiment, keeps the per-day delta(d) series (plan section 3
definition), and scores it twice: against the truly corrupted days and against `--draws` matched placebo day sets.

Usage (repo root):
    python src/precip_input_assimilation/scripts/stage0b4_placebo.py --setting lr0.5_l1e-4 [--max-basins 96]
"""
import argparse
import json
import logging
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader

REPO_ROOT = Path(__file__).resolve().parents[3]
for p in (str(REPO_ROOT), str(REPO_ROOT / 'src')):
    if p not in sys.path:
        sys.path.insert(0, p)

from neuralhydrology.datasetzoo import get_dataset  # noqa: E402
from neuralhydrology.datautils.utils import load_basin_file, load_scaler  # noqa: E402
from neuralhydrology.utils.config import Config  # noqa: E402
from precip_input_assimilation import InputAssimilationConfig, InputAssimilator  # noqa: E402
from precip_input_assimilation.evaluate import _to_device, delta_tables, load_frozen_model  # noqa: E402
from precip_input_assimilation.scripts.stage0b4_osse import (BASE_BLOCK, DELETE_FRACTION, DRY_MM, EPOCH, EVENT_MM,
                                                             OUT_DIR, PRCP, RUN_DIR, SETTINGS, _corrupt, _daily_precip,
                                                             _sums)  # noqa: E402


def run(setting: str, max_basins: int, seed: int, draws: int, reverse_pool_kind: str = 'wet'):
    logging.disable(logging.CRITICAL)
    cfg = Config(RUN_DIR / 'config.yml')
    cfg.update_config({'device': 'cpu'})
    scaler = load_scaler(RUN_DIR)
    scale = float(scaler['xarray_feature_scale'][PRCP])
    center = float(scaler['xarray_feature_center'][PRCP])
    z0, z_event = -center / scale, (EVENT_MM - center) / scale
    model = load_frozen_model(RUN_DIR, cfg, EPOCH, 'cpu')
    basins = load_basin_file(cfg.test_basin_file)[:max_basins]
    assimilator = InputAssimilator(InputAssimilationConfig({**BASE_BLOCK, **SETTINGS[setting]}), scaler=scaler)

    window, lead = BASE_BLOCK['assimilation_window'], BASE_BLOCK['assimilation_lead_time']
    n_assim = BASE_BLOCK['history'] * window
    start = BASE_BLOCK['seq_length'] - lead - n_assim
    end = start + n_assim

    rows = []
    for n_basin, basin in enumerate(basins, 1):
        ds = get_dataset(cfg, is_train=False, period='test', basin=basin, scaler=scaler)
        loader = DataLoader(ds, batch_size=cfg.batch_size, num_workers=0, collate_fn=ds.collate_fn)
        batches = [model.pre_model_hook(_to_device(b, 'cpu'), is_train=False) for b in loader]
        precip = _daily_precip(batches, scale, center)
        with torch.no_grad():
            truths = [model(b)['y_hat'] for b in batches]

        day0 = np.unique(np.concatenate([b['date'][:, -1].astype('datetime64[D]') for b in batches])) \
            - np.timedelta64(window + lead - 1, 'D')
        interior = day0[1:-1]
        wet = interior[precip.reindex(interior).to_numpy() >= EVENT_MM]
        dry = interior[precip.reindex(interior).to_numpy() < DRY_MM]
        rng = np.random.default_rng(seed + int(basin))
        n_events = int(round(DELETE_FRACTION * len(wet)))
        if n_events == 0 or len(dry) < n_events or len(wet) - n_events < 1:
            continue
        deleted = np.sort(rng.choice(wet, size=n_events, replace=False))
        inserted = np.sort(rng.choice(dry, size=n_events, replace=False))

        # Matched placebo pools. Forward: uncorrupted >= 15 mm days (the method must add rain, and rain days are
        # where it would add it anyway). Reverse: by default genuine >= 15 mm days, NOT other dry days -- on a dry
        # day P = 0 and the non-negativity projection forces delta >= 0, so delta- there is zero *by construction*
        # and a dry-day placebo measures the clamp, not skill. The honest question is whether the method can tell
        # 15 mm of fake rain from 15 mm of real rain.
        reverse_pool = dry if reverse_pool_kind == 'dry' else wet
        for direction, days, pool, value_z, sign in (
                ('forward_delete', deleted, wet, z0, +1),
                ('reverse_insert', inserted, reverse_pool, z_event, -1)):
            corrupted = [_corrupt(b, days, start, end, value_z) for b in batches]
            for c, t in zip(corrupted, truths):
                c['y'] = t.detach().clone()
            outs = [assimilator.assimilate(model, c) for c in corrupted]
            collected = {
                'delta_prcp_mm': np.concatenate([o['delta_prcp_mm'][:, :, 0].numpy() for o in outs], 0),
                'assim_dates': np.concatenate([c['date'][:, start:end] for c in corrupted], 0),
                'sample_end_date': np.concatenate([c['date'][:, -1] for c in corrupted], 0),
            }
            delta = delta_tables(collected, window=window, lead=lead)['last_window']['day0']
            delta.index = delta.index.values.astype('datetime64[D]')
            amount = float(precip.reindex(days).sum()) if direction == 'forward_delete' else n_events * EVENT_MM

            true_sums = _sums(delta, days, sign)
            # matched placebo: same number of days drawn from the same pool, excluding the corrupted ones and their
            # +-1 neighbourhood (so a placebo day can never be a true neighbour)
            forbidden = set(days) | {d + np.timedelta64(s, 'D') for d in days for s in (-1, 1)}
            candidates = np.array([d for d in pool if d not in forbidden], dtype='datetime64[D]')
            if len(candidates) < n_events:
                continue
            placebo = []
            for _ in range(draws):
                pick = rng.choice(candidates, size=n_events, replace=False)
                placebo.append(_sums(delta, np.sort(pick), sign))
            rows.append({
                'basin': basin, 'direction': direction, 'setting': setting, 'n_events': n_events, 'amount_mm': amount,
                'true_pm1': true_sums['pm1'], 'true_same_day': true_sums['same_day'], 'delta_all': true_sums['all'],
                'placebo_pm1_mean': float(np.mean([p['pm1'] for p in placebo])),
                'placebo_pm1_p95': float(np.percentile([p['pm1'] for p in placebo], 95)),
                'n_candidates': len(candidates),
            })
        if n_basin % 16 == 0:
            print(f'[{n_basin}/{len(basins)}] {basin}', flush=True)
    return pd.DataFrame(rows)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--setting', default='lr0.5_l1e-4')
    parser.add_argument('--max-basins', type=int, default=96)
    parser.add_argument('--seed', type=int, default=20260922)
    parser.add_argument('--draws', type=int, default=50)
    parser.add_argument('--reverse-pool', choices=['wet', 'dry'], default='wet',
                        help="placebo pool for the reverse arm; 'dry' only measures the non-negativity clamp")
    args = parser.parse_args()

    t0 = time.time()
    df = run(args.setting, args.max_basins, args.seed, args.draws, args.reverse_pool)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    suffix = f'{args.setting}_rev{args.reverse_pool}'
    df.to_csv(OUT_DIR / f'placebo_{suffix}_rows.csv', index=False)
    out = []
    for direction, g in df.groupby('direction'):
        out.append({
            'direction': direction, 'basins': g['basin'].nunique(), 'events': int(g['n_events'].sum()),
            'true_precision_pm1': g['true_pm1'].sum() / g['delta_all'].sum(),
            'placebo_precision_pm1': g['placebo_pm1_mean'].sum() / g['delta_all'].sum(),
            'placebo_precision_p95': g['placebo_pm1_p95'].sum() / g['delta_all'].sum(),
            'true_recovery_pm1': g['true_pm1'].sum() / g['amount_mm'].sum(),
            'placebo_recovery_pm1': g['placebo_pm1_mean'].sum() / g['amount_mm'].sum(),
        })
    summary = pd.DataFrame(out)
    summary['ratio_true_over_placebo'] = summary['true_precision_pm1'] / summary['placebo_precision_pm1']
    summary.to_csv(OUT_DIR / f'placebo_{suffix}_summary.csv', index=False)
    pd.set_option('display.width', 220)
    print('\n' + summary.round(3).to_string(index=False))
    print(f'wall {time.time() - t0:.0f}s -> {OUT_DIR / f"placebo_{suffix}_summary.csv"}')
    with (OUT_DIR / f'placebo_{suffix}_setup.json').open('w', encoding='utf-8') as fp:
        json.dump({'setting': args.setting, 'block': {**BASE_BLOCK, **SETTINGS[args.setting]}, 'draws': args.draws,
                   'seed': args.seed, 'reverse_pool': args.reverse_pool}, fp, indent=2, default=str)
    return 0


if __name__ == '__main__':
    sys.exit(main())
