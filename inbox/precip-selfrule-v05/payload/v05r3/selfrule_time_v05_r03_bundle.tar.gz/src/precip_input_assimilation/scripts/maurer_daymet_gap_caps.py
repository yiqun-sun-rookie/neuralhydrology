"""Per-basin plausibility caps for an additive precipitation correction, and how much of Maurer's under-reporting a
bounded multiplier could reach at all.

Reference product: Daymet, aligned as daymet(t+1) -> t (memory camels_daymet_one_day_offset.md). Period: the C4
training years 1999-10-01..2006-09-30 only, so nothing from the tuning/exam years leaks into the caps. Daymet is a
second estimate, not truth; the caps encode "how far the two products have historically disagreed", nothing more.

Outputs (results/precip_input_da_2026_09/analysis/):
  maurer_daymet_gap_caps.csv     per basin: p99 / p99.9 of max(D - M, 0) and of |D - M|, p99 of Maurer rain
  maurer_daymet_gap_summary.txt  pooled percentiles and the multiplier-reach table

Usage (repo root):  python src/precip_input_assimilation/scripts/maurer_daymet_gap_caps.py
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

REPO_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO_ROOT))
from neuralhydrology.datasetzoo.camelsus import load_camels_us_forcings  # noqa: E402

DATA = REPO_ROOT / 'data/camels_us'
BASINS = REPO_ROOT / 'src/fair_benchmark/frozen/track0_forcing_only_basins.txt'
OUT = REPO_ROOT / 'results/precip_input_da_2026_09/analysis'
START, END = '1999-10-01', '2006-09-30'


def main() -> int:
    basins = BASINS.read_text().split()
    dates = pd.date_range(START, END, freq='D')
    rows, Ms, Ds = [], [], []
    for b in basins:
        m, _ = load_camels_us_forcings(DATA, b, 'maurer')
        d, _ = load_camels_us_forcings(DATA, b, 'daymet')
        M = m['PRCP(mm/day)'].reindex(dates).to_numpy()
        D = d['prcp(mm/day)'].shift(-1).reindex(dates).to_numpy()
        ok = np.isfinite(M) & np.isfinite(D)
        M, D = M[ok], D[ok]
        under, absgap = np.maximum(D - M, 0.0), np.abs(D - M)
        rows.append({'basin': b, 'n_days': int(ok.sum()),
                     'under_p99': np.percentile(under, 99), 'under_p999': np.percentile(under, 99.9),
                     'absgap_p99': np.percentile(absgap, 99), 'absgap_p999': np.percentile(absgap, 99.9),
                     'maurer_p99': np.percentile(M, 99)})
        Ms.append(M)
        Ds.append(D)
    caps = pd.DataFrame(rows)
    OUT.mkdir(parents=True, exist_ok=True)
    caps.to_csv(OUT / 'maurer_daymet_gap_caps.csv', index=False)

    M, D = np.concatenate(Ms), np.concatenate(Ds)
    under, over = np.maximum(D - M, 0.0), np.maximum(M - D, 0.0)
    big = (D - M) > 10
    lines = [f'basin-days {len(M):,}, {len(basins)} basins, {START}..{END}, Daymet aligned daymet(t+1)->t',
             'pooled percentiles (mm) p90 / p99 / p99.9:',
             f'  Daymet > Maurer (would need adding):   ' + ' / '.join(f'{np.percentile(under, q):.1f}' for q in (90, 99, 99.9)),
             f'  Maurer > Daymet (would need removing): ' + ' / '.join(f'{np.percentile(over, q):.1f}' for q in (90, 99, 99.9)),
             f'  Daymet on Maurer-dry (<1 mm) days, p99 / p99.9: {np.percentile(D[M < 1], 99):.1f} / {np.percentile(D[M < 1], 99.9):.1f}',
             f'  Maurer daily rain p99 / p99.9: {np.percentile(M, 99):.1f} / {np.percentile(M, 99.9):.1f}',
             'share of days with Daymet - Maurer > X mm: ' + ', '.join(f'>{x}: {100 * (under > x).mean():.2f}%' for x in (5, 10, 15, 20, 30)),
             'per-basin caps (mm): under_p999 median {:.1f} (5-95% {:.1f}-{:.1f}); absgap_p999 median {:.1f} (5-95% {:.1f}-{:.1f})'.format(
                 caps.under_p999.median(), caps.under_p999.quantile(.05), caps.under_p999.quantile(.95),
                 caps.absgap_p999.median(), caps.absgap_p999.quantile(.05), caps.absgap_p999.quantile(.95)),
             'multiplier reach (share of under-reported rain mass a capped multiplier cannot reach):']
    for k in (3.0, 5.0):
        unreach = np.maximum(D - k * M, 0.0)
        lines.append(f'  x{k:g}: all days {100 * unreach.sum() / under.sum():.1f}%; days missing >10 mm ({100 * big.mean():.2f}% of days): '
                     f'{100 * unreach[big].sum() / under[big].sum():.1f}% of mass, {100 * (M[big] < 1).mean():.1f}% fully missed, '
                     f'{100 * (D[big] > k * M[big]).mean():.1f}% of those days need >x{k:g}')
    text = '\n'.join(lines)
    (OUT / 'maurer_daymet_gap_summary.txt').write_text(text + '\n', encoding='utf-8')
    print(text)
    return 0


if __name__ == '__main__':
    sys.exit(main())
