"""Create one strict receipt after all eight technical basin tasks finish."""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import replace
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO_ROOT / "src"))

from precip_input_assimilation.selfrule.manifest import verify_run_manifest  # noqa: E402
from precip_input_assimilation.selfrule.protocol import load_protocol  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--basin-file", type=Path, required=True)
    parser.add_argument("--protocol", type=Path,
                        default=REPO_ROOT / "src/precip_input_assimilation/configs/selfrule_time_v05.yml")
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--expected-steps", type=int, default=300)
    parser.add_argument("--max-gpu-bytes", type=int, default=6 * 1024**3)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    basins = [line.strip() for line in args.basin_file.read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(basins) != 8 or len(set(basins)) != 8:
        raise RuntimeError("Technical summary requires eight unique frozen basins")
    protocol = load_protocol(args.protocol, repo_root=REPO_ROOT)
    protocol = replace(protocol, data_dir=args.data_dir.resolve(), run_dir=args.run_dir.resolve(),
                       output_dir=args.output_dir.resolve())
    verify_run_manifest(protocol, technical=True, requested_basins=basins, device=args.device)
    manifest = json.loads((args.output_dir / "RUN_MANIFEST.json").read_text(encoding="utf-8"))
    runtime = json.loads((args.output_dir / "runtime_validation.json").read_text(encoding="utf-8"))
    if manifest.get("scope") != "technical_8" or manifest.get("allowed_basins") != basins:
        raise RuntimeError("Run manifest does not match the frozen technical basin list")
    if runtime.get("passed") is not True:
        raise RuntimeError("Runtime model validation did not pass")
    rows = []
    for basin in basins:
        record = json.loads((args.output_dir / "fit" / f"{basin}.json").read_text(encoding="utf-8"))
        summary = json.loads((args.output_dir / "fit_summaries" / f"{basin}.json").read_text(encoding="utf-8"))
        if record.get("basin") != basin or record.get("technical_complete") is not True:
            raise RuntimeError(f"{basin}: incomplete fit record")
        if summary.get("all_complete") is not True or summary.get("complete_basins") != [basin]:
            raise RuntimeError(f"{basin}: incomplete per-basin summary")
        for arm in ("rain_intensity", "rain_season"):
            fit = record["rain"][arm]["fit"]
            if fit["completed_steps"] != args.expected_steps or len(fit["candidate_records"]) != 12:
                raise RuntimeError(f"{basin} {arm}: incomplete candidate search")
            if any(candidate["best_step"] is None for candidate in fit["candidate_records"]):
                raise RuntimeError(f"{basin} {arm}: candidate without a finite selection result")
        peak = int(record.get("peak_gpu_bytes", -1))
        if peak < 0 or peak > args.max_gpu_bytes:
            raise RuntimeError(f"{basin}: GPU peak {peak} exceeds the limit")
        rows.append({"basin": basin, "elapsed_seconds": float(summary["elapsed_seconds"]),
                     "peak_gpu_bytes": peak})
    payload = {
        "protocol": "selfrule_time_v05",
        "technical_complete": True,
        "runtime_validation_passed": True,
        "basins": rows,
        "basin_count": len(rows),
        "sum_gpu_seconds": sum(row["elapsed_seconds"] for row in rows),
        "max_gpu_bytes": max(row["peak_gpu_bytes"] for row in rows),
    }
    destination = args.output_dir / "technical_summary.json"
    with destination.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
    print(json.dumps(payload, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()
