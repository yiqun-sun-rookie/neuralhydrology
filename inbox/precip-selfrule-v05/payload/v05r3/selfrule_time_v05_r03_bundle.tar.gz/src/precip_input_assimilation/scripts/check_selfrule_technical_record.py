"""Validate one completed technical fit record without reading source data."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("record", type=Path)
    parser.add_argument("--expected-steps", type=int, required=True)
    parser.add_argument("--max-gpu-bytes", type=int, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    record = json.loads(args.record.read_text(encoding="utf-8"))
    if record.get("technical_complete") is not True:
        raise RuntimeError(f"Incomplete technical record: {args.record}")
    for arm in ("rain_intensity", "rain_season"):
        steps = int(record["rain"][arm]["fit"]["completed_steps"])
        if steps != args.expected_steps:
            raise RuntimeError(f"{arm}: expected {args.expected_steps} completed steps, got {steps}")
    peak = int(record.get("peak_gpu_bytes", -1))
    if peak < 0 or peak > args.max_gpu_bytes:
        raise RuntimeError(f"GPU peak {peak} is outside the allowed range 0..{args.max_gpu_bytes}")
    print("TECHNICAL_RECORD_OK", record["basin"], peak)


if __name__ == "__main__":
    main()
