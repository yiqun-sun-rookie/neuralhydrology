"""Stage 0b-2 smoke test: observing-system simulation (OSSE) with the frozen C4 seed-100 model on 4 basins, CPU.

Twin design (plan v1.1 §4, 0b-4, shrunk to a smoke): the "observations" are C4's own open-loop simulation on the
original Maurer forcing (perfect model, only the input is wrong). Forward arm: a fraction of the >= 15 mm days that
fall inside a sample's assimilation windows are deleted (set to 0 mm) in that sample's input; does the additive
correction put the rain back on those days (recovery rate) and only there (precision)? Reverse arm: 15 mm of fake
rain is inserted on the same number of randomly chosen dry window days; does the correction remove it?

This is a pipeline smoke on 4 basins and one hyper-parameter point. It is NOT the 0b-4 gate (96 basins, 3 lr/lambda
settings, pooled events) and its numbers must not be used as one.

Usage (repo root):
    python src/precip_input_assimilation/scripts/osse_smoke.py [--arms additive,a2j,state] [--delete-fraction 0.3]
"""
import argparse
import json
import logging
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader

REPO_ROOT = Path(__file__).resolve().parents[3]
for p in (str(REPO_ROOT), str(REPO_ROOT / 'src')):
    if p not in sys.path:
        sys.path.insert(0, p)

from neuralhydrology.datasetzoo import get_dataset  # noqa: E402
from neuralhydrology.datautils.utils import load_basin_file, load_scaler  # noqa: E402
from neuralhydrology.utils.config import Config  # noqa: E402
from precip_input_assimilation import InputAssimilationConfig, InputAssimilator  # noqa: E402
from precip_input_assimilation.evaluate import _to_device, load_frozen_model  # noqa: E402

RUN_DIR = REPO_ROOT / 'results/precip_input_da_2026_09/local/c4_s100_4basins'
OUT_DIR = REPO_ROOT / 'results/precip_input_da_2026_09/local/osse_smoke'
PRCP = 'PRCP(mm/day)'
EPOCH = 30
EVENT_MM = 15.0

# common part of every block: C4 sequence length, lead 1, 20 windows x 5 days
BASE_BLOCK = {
    'assimilation_lead_time': 1, 'assimilation_window': 5, 'history': 20, 'epochs': 100,
    'learning_rate_drop_factor': 0.1, 'learning_rate_epoch_drop': 1001, 'loss': 'MSE', 'model_dropout': 0.0,
    'optimizer': 'Adam', 'regularization': [], 'seq_length': 270, 'target_variables': ['QObs(mm/d)'],
}
ARMS = {
    # A1: Nearing block verbatim (except seq_length) -> only c_n, 1 day in the loss
    'state': {**BASE_BLOCK, 'assimilation_targets': ['c_n'], 'learning_rate': 0.1, 'predict_last_n': 1},
    # A2: additive delta on PRCP, all 5 days of every window, 5 days in the loss. NOTE (smoke finding 2026-09-22):
    # with the batch-mean standardized MSE, one accepted step gains ~1e-3 while lambda=0.01 * 0.5 mm * 5 days costs
    # 0.025, so every step is rejected and nothing moves; lambda must be O(1e-4..1e-3). Main smoke arm: lambda 0.
    'additive': {**BASE_BLOCK, 'assimilation_targets': [f'x_d:{PRCP}'], 'input_learning_rate_mm': 0.5,
                 'predict_last_n': 5, 'input_l1_lambda': 0.0},
    'additive_l1e-3': {**BASE_BLOCK, 'assimilation_targets': [f'x_d:{PRCP}'], 'input_learning_rate_mm': 0.5,
                       'predict_last_n': 5, 'input_l1_lambda': 1e-3},
    'additive_l1e-2': {**BASE_BLOCK, 'assimilation_targets': [f'x_d:{PRCP}'], 'input_learning_rate_mm': 0.5,
                       'predict_last_n': 5, 'input_l1_lambda': 1e-2},
    # A2-J: Jamaat structure (1 window, only t-2, k^4, dry days skipped)
    'a2j': {**BASE_BLOCK, 'assimilation_targets': [f'x_d:{PRCP}'], 'history': 1, 'learning_rate': 0.1,
            'predict_last_n': 5, 'input_adjust_mode': 'multiplicative', 'input_adjust_days': 't-2',
            'input_skip_dry_days': True, 'input_dry_threshold_mm': 0.1},
}


def _calendar_precip(batches, scale, center):
    """Reconstruct the basin's daily precipitation (mm) from the samples (all samples agree on a given day)."""
    series = {}
    for b in batches:
        p_mm = b['x_d'][PRCP][:, :, 0].numpy() * scale + center
        for i in range(p_mm.shape[0]):
            series.update(zip(b['date'][i].astype('datetime64[D]'), p_mm[i]))
    return pd.Series(series).sort_index()


def _corrupt(batch, days_to_zero, days_to_insert, start, end, z0, scale, center):
    """Apply the twin corruption inside [start, end) of every sample; return the corrupted batch."""
    out = {k: ({kk: vv.clone() for kk, vv in v.items()} if isinstance(v, dict) else v) for k, v in batch.items()}
    out['y'] = batch['y'].clone()
    p = out['x_d'][PRCP]
    dates = batch['date'][:, start:end].astype('datetime64[D]')
    zero_mask = np.isin(dates, days_to_zero)
    insert_mask = np.isin(dates, days_to_insert)
    window = p[:, start:end, 0]
    window[torch.as_tensor(zero_mask)] = z0
    window[torch.as_tensor(insert_mask)] = (EVENT_MM - center) / scale
    p[:, start:end, 0] = window
    return out, zero_mask, insert_mask


def _score(delta_mm, mask, amounts, sign):
    """Recovery (same day, +-1 day) and precision for one basin's samples.

    delta_mm : [N, L] applied corrections (mm); mask : [N, L] corrupted days; amounts : [N, L] mm removed/inserted.
    sign : +1 (deleted rain, expect delta > 0) or -1 (inserted rain, expect delta < 0).
    """
    d = np.maximum(sign * delta_mm, 0.0)
    total_amount = float(amounts[mask].sum())
    if total_amount == 0:
        return {'events': 0}
    same_day = float(d[mask].sum())
    near = mask.copy()
    near[:, 1:] |= mask[:, :-1]
    near[:, :-1] |= mask[:, 1:]
    near_sum = float(d[near].sum())
    return {
        'events': int(mask.sum()),
        'amount_mm': total_amount,
        'recovery_same_day': same_day / total_amount,
        'recovery_pm1': near_sum / total_amount,
        'precision_pm1': near_sum / float(d.sum()) if d.sum() > 0 else np.nan,
        'total_signed_correction_mm': float(d.sum()),
        'total_opposite_correction_mm': float(np.maximum(-sign * delta_mm, 0.0).sum()),
    }


def run(arms, delete_fraction, seed, max_basins):
    logging.disable(logging.CRITICAL)
    torch.manual_seed(0)
    cfg = Config(RUN_DIR / 'config.yml')
    cfg.update_config({'device': 'cpu'})
    scaler = load_scaler(RUN_DIR)
    scale = float(scaler['xarray_feature_scale'][PRCP])
    center = float(scaler['xarray_feature_center'][PRCP])
    z0 = -center / scale
    model = load_frozen_model(RUN_DIR, cfg, EPOCH, 'cpu')
    basins = load_basin_file(cfg.test_basin_file)[:max_basins]
    rng = np.random.default_rng(seed)

    n_assim = BASE_BLOCK['history'] * BASE_BLOCK['assimilation_window']
    start = BASE_BLOCK['seq_length'] - BASE_BLOCK['assimilation_lead_time'] - n_assim
    end = start + n_assim

    rows = []
    for basin in basins:
        ds = get_dataset(cfg, is_train=False, period='test', basin=basin, scaler=scaler)
        loader = DataLoader(ds, batch_size=cfg.batch_size, num_workers=0, collate_fn=ds.collate_fn)
        batches = [model.pre_model_hook(_to_device(b, 'cpu'), is_train=False) for b in loader]
        precip = _calendar_precip(batches, scale, center)

        # twin observations: open-loop simulation on the original input
        with torch.no_grad():
            truths = [model(b)['y_hat'] for b in batches]

        # events that can fall inside some sample's windows
        window_days = np.unique(np.concatenate([b['date'][:, start:end].astype('datetime64[D]').ravel()
                                                for b in batches]))
        wet = [d for d in window_days if precip.get(d, 0.0) >= EVENT_MM]
        dry = [d for d in window_days if precip.get(d, 1.0) < 0.1]
        n_delete = int(round(delete_fraction * len(wet)))
        days_to_zero = np.array(sorted(rng.choice(wet, size=n_delete, replace=False)), dtype='datetime64[D]')
        days_to_insert = np.array(sorted(rng.choice(dry, size=min(n_delete, len(dry)), replace=False)),
                                  dtype='datetime64[D]')

        for direction, zero_days, insert_days in (('forward_delete', days_to_zero, np.array([], 'datetime64[D]')),
                                                  ('reverse_insert', np.array([], 'datetime64[D]'), days_to_insert)):
            corrupted, masks_zero, masks_insert = [], [], []
            for b in batches:
                c, mz, mi = _corrupt(b, zero_days, insert_days, start, end, z0, scale, center)
                corrupted.append(c)
                masks_zero.append(mz)
                masks_insert.append(mi)
            for i, (c, t) in enumerate(zip(corrupted, truths)):
                c['y'] = t.detach().clone()  # observations = twin truth (standardized)

            # open-loop error caused by the corruption (lead-1 step), for reference
            with torch.no_grad():
                corrupted_pred = [model(c)['y_hat'] for c in corrupted]
            mse_open = float(np.mean([((p[:, -1] - t[:, -1])**2).mean().item()
                                      for p, t in zip(corrupted_pred, truths)]))

            for arm in arms:
                block = ARMS[arm]
                assimilator = InputAssimilator(InputAssimilationConfig(dict(block)), scaler=scaler)
                t0 = time.time()
                outs = [assimilator.assimilate(model, c) for c in corrupted]
                elapsed = time.time() - t0
                mse_da = float(np.mean([((o['y_hat'][:, -1] - t[:, -1])**2).mean().item()
                                        for o, t in zip(outs, truths)]))
                row = {'basin': basin, 'direction': direction, 'arm': arm,
                       'n_samples': sum(len(c['y']) for c in corrupted),
                       'events_in_windows': int(sum(m.sum() for m in (masks_zero if direction == 'forward_delete'
                                                                      else masks_insert))),
                       'mse_lead1_corrupted_open_loop': mse_open, 'mse_lead1_after_assimilation': mse_da,
                       'mse_ratio_after_over_open': mse_da / mse_open if mse_open > 0 else np.nan,
                       'seconds': elapsed,
                       'mean_effective_updates_last_window': float(np.mean(
                           [o['n_effective_updates'][:, -1].float().mean().item() for o in outs]))}
                if 'delta_prcp_mm' in outs[0]:
                    delta = np.concatenate([o['delta_prcp_mm'][:, :, 0].numpy() for o in outs], 0)
                    L = delta.shape[1]
                    if direction == 'forward_delete':
                        mask = np.concatenate(masks_zero, 0)[:, -L:]
                        window_dates = [c['date'][:, end - L:end].astype('datetime64[D]') for c in corrupted]
                        amounts = np.concatenate([np.isin(d, zero_days) *
                                                  precip.reindex(d.ravel()).values.reshape(-1, L)
                                                  for d in window_dates], 0)
                        row.update({f'fwd_{k}': v for k, v in _score(delta, mask, amounts, +1).items()})
                        # plan §3 definition: only the last window's estimates (delta(d) of the sample whose last
                        # window starts at d), i.e. each calendar day judged by one window instead of up to 20
                        w = block['assimilation_window']
                        row.update({f'fwd_lastwin_{k}': v
                                    for k, v in _score(delta[:, -w:], mask[:, -w:], amounts[:, -w:], +1).items()})
                    else:
                        mask = np.concatenate(masks_insert, 0)[:, -L:]
                        amounts = mask * EVENT_MM
                        row.update({f'rev_{k}': v for k, v in _score(delta, mask, amounts, -1).items()})
                        w = block['assimilation_window']
                        row.update({f'rev_lastwin_{k}': v
                                    for k, v in _score(delta[:, -w:], mask[:, -w:], amounts[:, -w:], -1).items()})
                    row['delta_abs_mean_mm'] = float(np.abs(delta).mean())
                    row['delta_nonzero_frac'] = float((np.abs(delta) > 1e-6).mean())
                    if 'input_dry_skipped' in outs[0]:
                        row['dry_skipped_frac'] = float(np.concatenate([o['input_dry_skipped'][:, :, 0].numpy()
                                                                        for o in outs], 0).mean())
                rows.append(row)
                print(f"{basin} {direction:14s} {arm:8s} mse open {mse_open:.5f} -> DA {mse_da:.5f} "
                      f"({row['mse_ratio_after_over_open']:.2f}x)  "
                      + (f"recov same {row.get('fwd_recovery_same_day', row.get('rev_recovery_same_day', np.nan)):.2f} "
                         f"pm1 {row.get('fwd_recovery_pm1', row.get('rev_recovery_pm1', np.nan)):.2f} "
                         f"prec {row.get('fwd_precision_pm1', row.get('rev_precision_pm1', np.nan)):.2f}  "
                         if 'delta_prcp_mm' in outs[0] else '')
                      + f"{elapsed:.0f}s", flush=True)

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(rows)
    df.to_csv(OUT_DIR / 'osse_smoke_rows.csv', index=False)
    with (OUT_DIR / 'osse_smoke_setup.json').open('w', encoding='utf-8') as fp:
        json.dump({'arms': {a: ARMS[a] for a in arms}, 'delete_fraction': delete_fraction, 'seed': seed,
                   'event_mm': EVENT_MM, 'basins': basins, 'run_dir': str(RUN_DIR.relative_to(REPO_ROOT))}, fp,
                  indent=2, default=str)
    return df


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--arms', default='additive,additive_l1e-3,additive_l1e-2,a2j,state')
    parser.add_argument('--delete-fraction', type=float, default=0.3)
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--max-basins', type=int, default=4)
    args = parser.parse_args()
    df = run(args.arms.split(','), args.delete_fraction, args.seed, args.max_basins)
    pd.set_option('display.width', 250)
    pd.set_option('display.max_columns', 40)
    summary = df.groupby(['direction', 'arm']).agg({
        c: 'mean' for c in df.columns if c.startswith(('fwd_', 'rev_', 'mse_', 'delta_', 'seconds', 'dry_'))}).round(3)
    print(summary.T)
    print(f'rows written to {OUT_DIR / "osse_smoke_rows.csv"}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
