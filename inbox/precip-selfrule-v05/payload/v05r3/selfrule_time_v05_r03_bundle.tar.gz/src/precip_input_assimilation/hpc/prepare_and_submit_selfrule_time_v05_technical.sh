#!/usr/bin/env bash
# Login-node preparation followed by a dependent real-model gate and array.
set -eo pipefail

ROOT=/data1/home/sunyiq/precip_input_selfrule_time_v05_20260929_r03
CODE="$ROOT/code"
ASSET="$ROOT/assets/c4_s100"
DATA="$HOME/neuralhydrology/data/camels_us"
OUT="$ROOT/technical_8/run01"
SCRIPT="$CODE/src/precip_input_assimilation/scripts/run_selfrule_time_v05.py"
BASIN_FILE="$CODE/src/precip_input_assimilation/configs/basins_8_selfrule_v05.txt"

test -d "$ROOT" || { echo "ROOT_MISSING"; exit 1; }
test -f "$SCRIPT" || { echo "SCRIPT_MISSING"; exit 1; }
test -f "$ASSET/model_epoch030.pt" || { echo "WEIGHT_MISSING"; exit 1; }
test ! -e "$OUT" || { echo "TECHNICAL_OUTPUT_ALREADY_EXISTS"; exit 1; }
mkdir -p "$ROOT/logs"

source /data1/home/${USER}/miniconda3/etc/profile.d/conda.sh || \
source "$HOME/miniconda3/etc/profile.d/conda.sh"
conda activate nh_final || { echo "CONDA_FAILED"; exit 1; }
export PYTHONPATH="$CODE/src:$HOME/neuralhydrology:${PYTHONPATH:-}"

python -u "$SCRIPT" prepare \
  --technical \
  --device cuda:0 \
  --data-dir "$DATA" \
  --run-dir "$ASSET" \
  --output-dir "$OUT" \
  --basin-file "$BASIN_FILE"

runtime_submit=$(sbatch "$CODE/src/precip_input_assimilation/hpc/selfrule_time_v05_runtime_check.slurm")
case "$runtime_submit" in
  "Submitted batch job "*) ;;
  *) echo "RUNTIME_SBATCH_FAILED $runtime_submit"; exit 1 ;;
esac
runtime_job=${runtime_submit##* }

array_submit=$(sbatch --dependency="afterok:$runtime_job" \
  "$CODE/src/precip_input_assimilation/hpc/selfrule_time_v05_technical.slurm")
case "$array_submit" in
  "Submitted batch job "*) ;;
  *) echo "ARRAY_SBATCH_FAILED $array_submit"; exit 1 ;;
esac
array_job=${array_submit##* }

printf 'runtime_job=%s\narray_job=%s\n' "$runtime_job" "$array_job" > "$ROOT/technical_8/submission.txt"
echo "RUNTIME_JOB_ID=$runtime_job"
echo "ARRAY_JOB_ID=$array_job"
squeue -j "$runtime_job,$array_job" -o "%.18i %.24j %.10P %.2t %.10M %.6D %R"
