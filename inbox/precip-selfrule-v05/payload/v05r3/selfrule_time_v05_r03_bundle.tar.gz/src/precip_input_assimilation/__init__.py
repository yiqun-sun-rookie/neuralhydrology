"""Input-space precipitation assimilation for frozen neuralhydrology LSTMs (candidate ID36).

Standalone module. It imports the frozen model, dataset and scaler from the core package but does *not* import,
subclass or patch ``neuralhydrology.evaluation.assimilation.Assimilation`` (ID29 code, frozen by user instruction
2026-09-20). Equivalence with the ID29 state-assimilation path is guaranteed by a parity test, not by shared code.
"""

from .config import InputAssimilationConfig
from .input_assimilation import InputAssimilator

__all__ = ['InputAssimilationConfig', 'InputAssimilator']
