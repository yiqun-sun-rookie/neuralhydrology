"""Frozen protocol and path handling for the self-correction experiment."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any

import yaml


def _as_date(value: str) -> date:
    return date.fromisoformat(value)


@dataclass(frozen=True)
class Protocol:
    protocol_file: Path
    repo_root: Path
    data_dir: Path
    run_dir: Path
    basin_file: Path
    technical_basin_file: Path
    basin_draw_file: Path
    output_dir: Path
    forcing_start: date
    forcing_end: date
    fit_start: date
    fit_end: date
    select_start: date
    select_end: date
    score_start: date
    score_end: date
    sequence_length: int
    wet_threshold_mm: float
    min_bin_support: int
    multiplier_min: float
    multiplier_max: float
    lambdas: tuple[float, ...]
    starts: tuple[float, ...]
    learning_rate: float
    max_steps: int
    selection_interval: int
    batch_targets: int
    technical_wall_minutes: float
    candidate_wall_minutes: float
    seed: int
    expected_weight_sha256: str
    expected_config_sha256: str
    expected_scaler_sha256: str
    expected_basin_file_sha256: str
    expected_technical_basin_file_sha256: str
    expected_basin_draw_sha256: str

    @property
    def weight_file(self) -> Path:
        return self.run_dir / "model_epoch030.pt"

    @property
    def config_file(self) -> Path:
        return self.run_dir / "config.yml"

    @property
    def scaler_file(self) -> Path:
        return self.run_dir / "train_data" / "train_data_scaler.yml"


_EXPECTED_DATES = {
    "forcing_start": date(1980, 1, 1),
    "forcing_end": date(1989, 9, 30),
    "fit_start": date(1980, 10, 1),
    "fit_end": date(1984, 9, 30),
    "select_start": date(1984, 10, 1),
    "select_end": date(1985, 9, 30),
    "score_start": date(1985, 10, 1),
    "score_end": date(1989, 9, 30),
}
_SEALED_FLOW_START = date(1989, 10, 1)
_EXAM_START = date(2007, 10, 1)
_EXAM_END = date(2008, 9, 30)


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def validate_protocol(protocol: Protocol, *, verify_files: bool = True) -> None:
    """Reject any drift in dates, model assets, or frozen basin definitions."""
    for field, expected in _EXPECTED_DATES.items():
        actual = getattr(protocol, field)
        if actual != expected:
            raise ValueError(f"Protocol {field} must be {expected}, got {actual}")
    periods = ((protocol.fit_start, protocol.fit_end),
               (protocol.select_start, protocol.select_end),
               (protocol.score_start, protocol.score_end))
    if any(start > end for start, end in periods):
        raise ValueError("Protocol contains a reversed date interval")
    if not (protocol.fit_end < protocol.select_start <= protocol.select_end < protocol.score_start):
        raise ValueError("Fit, selection, and score periods overlap or are out of order")
    if protocol.score_end >= _SEALED_FLOW_START:
        raise ValueError("Protocol reaches the sealed flow period")
    if any(not (end < _EXAM_START or start > _EXAM_END) for start, end in periods):
        raise ValueError("Protocol reaches the forbidden exam year")
    if protocol.sequence_length != 270:
        raise ValueError("Frozen protocol requires 270-day input windows")
    if not verify_files:
        return
    expected = {
        protocol.weight_file: protocol.expected_weight_sha256,
        protocol.config_file: protocol.expected_config_sha256,
        protocol.scaler_file: protocol.expected_scaler_sha256,
        protocol.basin_file: protocol.expected_basin_file_sha256,
        protocol.technical_basin_file: protocol.expected_technical_basin_file_sha256,
        protocol.basin_draw_file: protocol.expected_basin_draw_sha256,
    }
    for path, expected_hash in expected.items():
        if not path.is_file():
            raise FileNotFoundError(f"Required frozen input is missing: {path}")
        actual_hash = sha256_file(path)
        if actual_hash != expected_hash:
            raise RuntimeError(f"Frozen input hash mismatch for {path}: {actual_hash} != {expected_hash}")


def _resolve(repo_root: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else repo_root / path


def load_protocol(path: Path, *, output_dir: Path | None = None, repo_root: Path | None = None) -> Protocol:
    """Load the immutable experiment settings from a small YAML file."""
    path = Path(path).resolve()
    raw: dict[str, Any] = yaml.safe_load(path.read_text(encoding="utf-8"))
    root = Path(repo_root).resolve() if repo_root else path.parents[3]
    configured_output = output_dir if output_dir is not None else raw["output_dir"]
    starts = tuple(float(value) for value in raw["starts_log_multiplier"])
    return Protocol(
        protocol_file=path,
        repo_root=root,
        data_dir=_resolve(root, raw["data_dir"]),
        run_dir=_resolve(root, raw["run_dir"]),
        basin_file=_resolve(root, raw["basin_file"]),
        technical_basin_file=_resolve(root, raw["technical_basin_file"]),
        basin_draw_file=_resolve(root, raw["basin_draw_file"]),
        output_dir=_resolve(root, configured_output),
        forcing_start=_as_date(raw["forcing_start"]),
        forcing_end=_as_date(raw["forcing_end"]),
        fit_start=_as_date(raw["fit_start"]),
        fit_end=_as_date(raw["fit_end"]),
        select_start=_as_date(raw["select_start"]),
        select_end=_as_date(raw["select_end"]),
        score_start=_as_date(raw["score_start"]),
        score_end=_as_date(raw["score_end"]),
        sequence_length=int(raw["sequence_length"]),
        wet_threshold_mm=float(raw["wet_threshold_mm"]),
        min_bin_support=int(raw["min_bin_support"]),
        multiplier_min=float(raw["multiplier_min"]),
        multiplier_max=float(raw["multiplier_max"]),
        lambdas=tuple(float(value) for value in raw["lambdas"]),
        starts=starts,
        learning_rate=float(raw["learning_rate"]),
        max_steps=int(raw["max_steps"]),
        selection_interval=int(raw["selection_interval"]),
        batch_targets=int(raw["batch_targets"]),
        technical_wall_minutes=float(raw["technical_wall_minutes"]),
        candidate_wall_minutes=float(raw["candidate_wall_minutes"]),
        seed=int(raw["seed"]),
        expected_weight_sha256=str(raw["expected_weight_sha256"]),
        expected_config_sha256=str(raw["expected_config_sha256"]),
        expected_scaler_sha256=str(raw["expected_scaler_sha256"]),
        expected_basin_file_sha256=str(raw["expected_basin_file_sha256"]),
        expected_technical_basin_file_sha256=str(raw["expected_technical_basin_file_sha256"]),
        expected_basin_draw_sha256=str(raw["expected_basin_draw_sha256"]),
    )
