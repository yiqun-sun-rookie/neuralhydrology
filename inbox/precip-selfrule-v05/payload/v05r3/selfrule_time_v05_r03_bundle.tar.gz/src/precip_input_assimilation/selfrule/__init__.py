"""Single-basin precipitation rules with strict time-split data access."""

from .protocol import Protocol, load_protocol

__all__ = ["Protocol", "load_protocol"]
