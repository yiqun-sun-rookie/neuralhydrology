"""Rainfall rule construction and sparse-bin merging."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import date

import numpy as np
import torch


@dataclass(frozen=True)
class SeasonRule:
    season: str
    quantile_edges_mm: tuple[float, ...]
    original_support: tuple[int, ...]
    effective_support: tuple[int, ...]
    original_to_merged: tuple[int, ...]
    parameter_indices: tuple[int, ...]
    merge_log: tuple[str, ...]


@dataclass(frozen=True)
class RainRule:
    kind: str
    wet_threshold_mm: float
    n_parameters: int
    seasons: tuple[SeasonRule, ...]

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: dict) -> "RainRule":
        return cls(kind=payload["kind"],
                   wet_threshold_mm=float(payload["wet_threshold_mm"]),
                   n_parameters=int(payload["n_parameters"]),
                   seasons=tuple(SeasonRule(**item) for item in payload["seasons"]))


def _is_warm(dates: np.ndarray) -> np.ndarray:
    months = dates.astype("datetime64[M]").astype(int) % 12 + 1
    return (months >= 5) & (months <= 10)


def _linear_quantiles(values: np.ndarray) -> tuple[float, ...]:
    if not len(values):
        return ()
    edges = np.quantile(values, [1 / 3, 2 / 3], method="linear")
    return tuple(float(value) for value in np.unique(edges))


def _initial_bins(values: np.ndarray, edges: tuple[float, ...]) -> np.ndarray:
    # side='right' sends values equal to a boundary to the upper bin.
    return np.searchsorted(np.asarray(edges, dtype=np.float64), values, side="right").astype(np.int64)


def _merge_mapping(counts: list[int], minimum: int) -> tuple[list[int], list[str]]:
    groups = [[index] for index in range(len(counts))]
    support = list(counts)
    log: list[str] = []
    while len(groups) > 1:
        failing = next((index for index, count in enumerate(support) if count < minimum), None)
        if failing is None:
            break
        neighbor = failing - 1 if failing > 0 else 1
        lo, hi = sorted((failing, neighbor))
        log.append(f"merge original bins {groups[lo]} and {groups[hi]}: support {support[lo]}+{support[hi]}")
        groups[lo] = groups[lo] + groups[hi]
        support[lo] += support[hi]
        del groups[hi]
        del support[hi]
    mapping = [0] * len(counts)
    for merged, originals in enumerate(groups):
        for original in originals:
            mapping[original] = merged
    return mapping, log


def build_rain_rule(kind: str,
                    dates: np.ndarray,
                    precipitation_mm: np.ndarray,
                    fit_start: date,
                    fit_end: date,
                    effective_day_mask: np.ndarray,
                    wet_threshold_mm: float = 0.1,
                    min_support: int = 20) -> RainRule:
    if kind not in {"rain_intensity", "rain_season"}:
        raise ValueError(f"Unknown rain rule kind: {kind}")
    if effective_day_mask.shape != precipitation_mm.shape:
        raise ValueError("effective_day_mask has the wrong shape")
    fit_mask = (dates >= np.datetime64(fit_start)) & (dates <= np.datetime64(fit_end))
    warm = _is_warm(dates)
    next_parameter = 0
    season_rules: list[SeasonRule] = []
    for label, season_mask in (("cold", ~warm), ("warm", warm)):
        wet_fit = fit_mask & season_mask & (precipitation_mm >= wet_threshold_mm) & np.isfinite(precipitation_mm)
        wet_values = precipitation_mm[wet_fit]
        edges = () if kind == "rain_season" else _linear_quantiles(wet_values)
        n_original = len(edges) + 1
        original_labels = _initial_bins(wet_values, edges)
        original_support = [int((original_labels == index).sum()) for index in range(n_original)]
        effective_mask = wet_fit & effective_day_mask
        effective_labels = _initial_bins(precipitation_mm[effective_mask], edges)
        effective_support = [int((effective_labels == index).sum()) for index in range(n_original)]
        if sum(effective_support) < min_support:
            mapping = [-1] * n_original
            log = [f"season fixed at 1: total effective support {sum(effective_support)} < {min_support}"]
            parameter_indices = [-1] * n_original
        else:
            mapping, log = _merge_mapping(effective_support, min_support)
            n_merged = max(mapping) + 1
            parameter_indices = [next_parameter + merged for merged in mapping]
            next_parameter += n_merged
        season_rules.append(
            SeasonRule(season=label,
                       quantile_edges_mm=tuple(edges),
                       original_support=tuple(original_support),
                       effective_support=tuple(effective_support),
                       original_to_merged=tuple(mapping),
                       parameter_indices=tuple(parameter_indices),
                       merge_log=tuple(log)))
    return RainRule(kind=kind,
                    wet_threshold_mm=float(wet_threshold_mm),
                    n_parameters=next_parameter,
                    seasons=tuple(season_rules))


def parameter_index_by_day(rule: RainRule, dates: np.ndarray, precipitation_mm: np.ndarray) -> np.ndarray:
    warm = _is_warm(dates)
    output = np.full(len(dates), -1, dtype=np.int64)
    for season_rule, season_mask in zip(rule.seasons, (~warm, warm), strict=True):
        wet = season_mask & np.isfinite(precipitation_mm) & (precipitation_mm >= rule.wet_threshold_mm)
        original = _initial_bins(precipitation_mm[wet], season_rule.quantile_edges_mm)
        params = np.asarray(season_rule.parameter_indices, dtype=np.int64)
        output[wet] = params[original]
    return output


def apply_rule_numpy(precipitation_mm: np.ndarray, parameter_indices: np.ndarray, theta: np.ndarray) -> np.ndarray:
    output = np.asarray(precipitation_mm, dtype=np.float64).copy()
    active = parameter_indices >= 0
    if active.any():
        output[active] *= np.exp(np.asarray(theta, dtype=np.float64)[parameter_indices[active]])
    return output


def apply_rule_torch(precipitation_mm: torch.Tensor,
                     parameter_indices: torch.Tensor,
                     theta: torch.Tensor) -> torch.Tensor:
    if theta.numel() == 0:
        return precipitation_mm
    active = parameter_indices >= 0
    safe = parameter_indices.clamp_min(0)
    factors = torch.exp(theta[safe])
    return torch.where(active, precipitation_mm * factors, precipitation_mm)
