"""Direct frozen-C4 loading and differentiable sliding-window prediction."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import torch

from neuralhydrology.modelzoo import get_model
from neuralhydrology.utils.config import Config

from .rules import apply_rule_torch


class FrozenC4:
    def __init__(self,
                 run_dir: Path,
                 device: str,
                 dynamic_names: tuple[str, ...],
                 dynamic_center: np.ndarray,
                 dynamic_scale: np.ndarray,
                 q_center: float,
                 q_scale: float):
        self.device = torch.device(device)
        cfg = Config(Path(run_dir) / "config.yml")
        cfg.update_config({"device": device})
        self.model = get_model(cfg).to(self.device)
        state = torch.load(Path(run_dir) / "model_epoch030.pt", map_location=self.device, weights_only=True)
        self.model.load_state_dict(state)
        self.model.eval()
        for parameter in self.model.parameters():
            parameter.requires_grad_(False)
        # cuDNN requires the recurrent module in training mode for gradients to inputs.
        # C4 has one recurrent layer and therefore no recurrent dropout.  The model's
        # separate output dropout module stays in evaluation mode.
        self.model.lstm.train()
        self.model.dropout.eval()
        self.dynamic_names = dynamic_names
        self.center = torch.as_tensor(dynamic_center, dtype=torch.float32, device=self.device)
        self.scale = torch.as_tensor(dynamic_scale, dtype=torch.float32, device=self.device)
        self.q_center = float(q_center)
        self.q_scale = float(q_scale)
        self.sequence_length = int(cfg.seq_length)
        self.precipitation_index = dynamic_names.index("PRCP(mm/day)")

    def _forward(self, normalized: torch.Tensor, static: torch.Tensor) -> torch.Tensor:
        data = {
            "x_d": {name: normalized[..., index:index + 1] for index, name in enumerate(self.dynamic_names)},
            "x_s": static,
        }
        return self.model(data)["y_hat"][:, -1, 0] * self.q_scale + self.q_center

    def make_windows(self, raw_dynamic: torch.Tensor, target_indices: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        offsets = torch.arange(-self.sequence_length + 1, 1, device=self.device)
        indices = target_indices[:, None] + offsets[None, :]
        return raw_dynamic[indices], indices

    def predict(self,
                raw_dynamic: torch.Tensor,
                static: torch.Tensor,
                target_indices: torch.Tensor,
                parameter_indices: torch.Tensor | None = None,
                theta: torch.Tensor | None = None) -> torch.Tensor:
        windows, calendar_indices = self.make_windows(raw_dynamic, target_indices)
        if parameter_indices is not None and theta is not None:
            adjusted = apply_rule_torch(windows[..., self.precipitation_index],
                                        parameter_indices[calendar_indices], theta)
            windows = windows.clone()
            windows[..., self.precipitation_index] = adjusted
        normalized = (windows - self.center) / self.scale
        repeated_static = static.reshape(1, -1).expand(len(target_indices), -1)
        return self._forward(normalized, repeated_static)

    def predict_candidates(self,
                           raw_dynamic: torch.Tensor,
                           static: torch.Tensor,
                           target_indices: torch.Tensor,
                           parameter_indices: torch.Tensor,
                           theta: torch.Tensor) -> torch.Tensor:
        """Predict all candidate parameter rows for the same target dates.

        Returns a tensor shaped ``[candidate, target]``.  Candidate rows are
        independent; batching only avoids thousands of tiny recurrent calls.
        """
        windows, calendar_indices = self.make_windows(raw_dynamic, target_indices)
        n_candidates, n_parameters = theta.shape
        n_targets, length, n_features = windows.shape
        day_parameters = parameter_indices[calendar_indices]
        if n_parameters:
            safe = day_parameters.clamp_min(0)
            factors = torch.exp(theta[:, safe])
            base_rain = windows[None, ..., self.precipitation_index]
            rain = torch.where(day_parameters[None, ...] >= 0, base_rain * factors, base_rain)
            expanded = windows[None, ...].expand(n_candidates, -1, -1, -1).clone()
            expanded[..., self.precipitation_index] = rain
        else:
            expanded = windows[None, ...].expand(n_candidates, -1, -1, -1)
        normalized = (expanded.reshape(n_candidates * n_targets, length, n_features) - self.center) / self.scale
        repeated_static = static.reshape(1, -1).expand(n_candidates * n_targets, -1)
        prediction = self._forward(normalized, repeated_static)
        return prediction.reshape(n_candidates, n_targets)


def configure_determinism(seed: int) -> None:
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
