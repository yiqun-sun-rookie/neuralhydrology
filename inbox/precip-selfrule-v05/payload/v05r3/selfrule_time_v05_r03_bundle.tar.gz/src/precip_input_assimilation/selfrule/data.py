"""Strict readers for the allowed forcing and discharge date ranges.

The discharge reader tests the date before converting the discharge token to a
number.  Separate processes call it for fitting, selection, and scoring.  The
prediction process never imports or calls the discharge reader.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import pandas as pd

from neuralhydrology.datautils.utils import load_scaler
from neuralhydrology.utils.config import Config

_ATTRIBUTE_FILES = {
    "camels_clim.txt": {"p_mean", "pet_mean", "p_seasonality", "frac_snow", "aridity", "high_prec_freq",
                        "high_prec_dur", "high_prec_timing", "low_prec_freq", "low_prec_dur", "low_prec_timing"},
    "camels_geol.txt": {"geol_1st_class", "glim_1st_class_frac", "geol_2nd_class", "glim_2nd_class_frac",
                        "carbonate_rocks_frac", "geol_porostiy", "geol_permeability"},
    "camels_name.txt": {"huc", "gauge_name"},
    "camels_soil.txt": {"soil_depth_pelletier", "soil_depth_statsgo", "soil_porosity", "soil_conductivity",
                        "max_water_content", "sand_frac", "silt_frac", "clay_frac", "water_frac",
                        "organic_frac", "other_frac"},
    "camels_topo.txt": {"gauge_lat", "gauge_lon", "elev_mean", "slope_mean", "area_gages2",
                        "area_geospa_fabric"},
    "camels_vege.txt": {"frac_forest", "lai_max", "lai_diff", "gvf_max", "gvf_diff",
                        "dom_land_cover_frac", "dom_land_cover", "root_depth_50", "root_depth_99"},
}

@dataclass(frozen=True)
class ForcingData:
    basin: str
    dates: np.ndarray
    values: np.ndarray
    names: tuple[str, ...]
    area_m2: int

    @property
    def canonical_sha256(self) -> str:
        return canonical_forcing_sha256(self.names, self.dates, self.values)

    def canonical_sha256_through(self, end: date) -> str:
        keep = self.dates <= np.datetime64(end)
        return canonical_forcing_sha256(self.names, self.dates[keep], self.values[keep])


def canonical_forcing_sha256(names: Sequence[str], dates: np.ndarray, values: np.ndarray) -> str:
    digest = hashlib.sha256()
    digest.update(("date," + ",".join(names) + "\n").encode("utf-8"))
    for current, row in zip(dates.astype("datetime64[D]"), values, strict=True):
        rendered = ",".join(format(float(value), ".9g") for value in row)
        digest.update(f"{current},{rendered}\n".encode("utf-8"))
    return digest.hexdigest()


def read_basin_list(path: Path) -> list[str]:
    basins = [line.strip() for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(basins) != len(set(basins)):
        raise ValueError(f"Duplicate basin in {path}")
    if any(len(basin) != 8 or not basin.isdigit() for basin in basins):
        raise ValueError(f"Invalid basin identifier in {path}")
    return basins


def find_unique(root: Path, pattern: str) -> Path:
    matches = list(Path(root).glob(f"**/{pattern}"))
    if len(matches) != 1:
        raise FileNotFoundError(f"Expected one file matching {pattern} below {root}, found {len(matches)}")
    return matches[0]


def _date_from_tokens(tokens: Sequence[str], offset: int = 0) -> date:
    return date(int(tokens[offset]), int(tokens[offset + 1]), int(tokens[offset + 2]))


def read_maurer_forcing(data_dir: Path, basin: str, start: date, end: date) -> ForcingData:
    """Read only Maurer values in ``[start, end]`` and stop before later years."""
    path = find_unique(Path(data_dir) / "basin_mean_forcing" / "maurer", f"{basin}_*_forcing_leap.txt")
    dates: list[np.datetime64] = []
    rows: list[list[float]] = []
    with path.open("r", encoding="utf-8") as handle:
        handle.readline()
        handle.readline()
        area_m2 = int(handle.readline().strip())
        header = handle.readline().split()
        required = ["PRCP(mm/day)", "Tmin(C)", "Tmax(C)", "SRAD(W/m2)", "Vp(Pa)"]
        value_columns = {name: header.index(name) for name in required}
        previous: date | None = None
        for line_number, line in enumerate(handle, start=5):
            tokens = line.split()
            if len(tokens) < 4:
                continue
            current = _date_from_tokens(tokens)
            if previous is not None and current <= previous:
                raise ValueError(f"{path}:{line_number}: forcing dates are not strictly increasing")
            previous = current
            if current < start:
                continue
            if current > end:
                break
            # Data rows have Year/Mnth/Day/Hr before the named meteorological columns.
            values = [float(tokens[4 + value_columns[name] - 4]) for name in required]
            dates.append(np.datetime64(current, "D"))
            rows.append(values)
    expected = np.arange(np.datetime64(start), np.datetime64(end) + np.timedelta64(1, "D"), dtype="datetime64[D]")
    actual = np.asarray(dates, dtype="datetime64[D]")
    if not np.array_equal(actual, expected):
        raise ValueError(f"{basin}: Maurer forcing is not a complete daily grid for {start} through {end}")
    values = np.asarray(rows, dtype=np.float32)
    if values.shape != (len(expected), len(required)) or not np.isfinite(values).all():
        raise ValueError(f"{basin}: forcing contains missing or malformed values")
    return ForcingData(basin=basin, dates=actual, values=values, names=tuple(required), area_m2=area_m2)


def load_normalization(run_dir: Path) -> tuple[Config, tuple[str, ...], np.ndarray, np.ndarray, float, float]:
    cfg = Config(Path(run_dir) / "config.yml")
    scaler = load_scaler(Path(run_dir))
    names = tuple(cfg.dynamic_inputs)
    center = np.asarray([float(scaler["xarray_feature_center"][name]) for name in names], dtype=np.float32)
    scale = np.asarray([float(scaler["xarray_feature_scale"][name]) for name in names], dtype=np.float32)
    q_center = float(scaler["xarray_feature_center"][cfg.target_variables[0]])
    q_scale = float(scaler["xarray_feature_scale"][cfg.target_variables[0]])
    return cfg, names, center, scale, q_center, q_scale


def load_normalized_attributes(data_dir: Path, run_dir: Path, basins: Iterable[str]) -> np.ndarray:
    cfg, _, _, _, _, _ = load_normalization(run_dir)
    basin_list = list(basins)
    requested = list(cfg.static_attributes)
    known = {name for names in _ATTRIBUTE_FILES.values() for name in names}
    unknown = [name for name in requested if name not in known]
    if unknown:
        raise ValueError(f"Unknown CAMELS-US static attributes: {unknown}")
    root = Path(data_dir) / "camels_attributes_v2.0"
    frames = []
    for filename, names in _ATTRIBUTE_FILES.items():
        if not set(requested).intersection(names):
            continue
        frame = pd.read_csv(root / filename, sep=";", dtype={"gauge_id": str}).set_index("gauge_id")
        if "huc" in requested and "huc_02" in frame:
            frame["huc"] = frame["huc_02"].map(lambda value: str(value).zfill(2))
        keep = [name for name in requested if name in frame.columns]
        frames.append(frame[keep])
    attrs = pd.concat(frames, axis=1)
    if any(basin not in attrs.index for basin in basin_list):
        raise ValueError("Some basins are missing static attributes")
    attrs = attrs.loc[basin_list, requested]
    scaler = load_scaler(Path(run_dir))
    normalized = (attrs - scaler["attribute_means"]) / scaler["attribute_stds"]
    normalized = normalized.loc[basin_list, list(cfg.static_attributes)]
    values = normalized.to_numpy(dtype=np.float32)
    if not np.isfinite(values).all():
        raise ValueError("Static attributes contain missing values after normalization")
    return values


def slice_indices(dates: np.ndarray, start: date, end: date) -> np.ndarray:
    mask = (dates >= np.datetime64(start)) & (dates <= np.datetime64(end))
    return np.flatnonzero(mask).astype(np.int64)


def valid_target_indices(values: np.ndarray, target_indices: np.ndarray, sequence_length: int) -> np.ndarray:
    finite_day = np.isfinite(values).all(axis=1).astype(np.int64)
    prefix = np.concatenate(([0], np.cumsum(1 - finite_day)))
    valid: list[int] = []
    for target in target_indices:
        start = int(target) - sequence_length + 1
        if start >= 0 and prefix[int(target) + 1] == prefix[start]:
            valid.append(int(target))
    return np.asarray(valid, dtype=np.int64)


