"""Discharge-only readers used by fitting and scoring processes.

The prediction entry point does not import this module.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from datetime import date
from pathlib import Path

import numpy as np

from .data import _date_from_tokens, find_unique

_CFS_TO_MM_DAY = 28316846.592 * 86400.0 / 1_000_000.0


@dataclass(frozen=True)
class FlowSlice:
    basin: str
    dates: np.ndarray
    values_mm_day: np.ndarray
    canonical_sha256: str
    missing_count: int


def _canonical_flow_hash(basin: str, dates: np.ndarray, values: np.ndarray) -> str:
    lines = ["basin,date,QObs(mm/d),missing\n"]
    for current, value in zip(dates.astype("datetime64[D]"), values, strict=True):
        rendered = "NA" if not np.isfinite(value) else format(float(value), ".17g")
        lines.append(f"{basin},{current},{rendered},{int(not np.isfinite(value))}\n")
    return hashlib.sha256("".join(lines).encode("utf-8")).hexdigest()


def read_flow_slice(data_dir: Path, basin: str, area_m2: int, start: date, end: date) -> FlowSlice:
    """Read streamflow in one explicitly allowed interval.

    Tokens after the date are left untouched for lines outside the interval.
    This is deliberate: malformed or sentinel values in forbidden years are
    never parsed into numbers by this function.
    """
    path = find_unique(Path(data_dir) / "usgs_streamflow", f"{basin}_streamflow_qc.txt")
    expected = np.arange(np.datetime64(start), np.datetime64(end) + np.timedelta64(1, "D"), dtype="datetime64[D]")
    by_date: dict[np.datetime64, float] = {}
    previous: date | None = None
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            tokens = line.split()
            if len(tokens) < 4:
                continue
            if tokens[0] != basin:
                raise ValueError(f"{path}:{line_number}: unexpected basin {tokens[0]}")
            current = _date_from_tokens(tokens, 1)
            if previous is not None and current <= previous:
                raise ValueError(f"{path}:{line_number}: discharge dates are not strictly increasing")
            previous = current
            if current < start:
                continue
            if current > end:
                break
            if len(tokens) < 5:
                raise ValueError(f"{path}:{line_number}: missing discharge token in allowed interval")
            raw = float(tokens[4])
            value = np.nan if raw < 0 else _CFS_TO_MM_DAY * raw / float(area_m2)
            key = np.datetime64(current, "D")
            if key in by_date:
                raise ValueError(f"{path}:{line_number}: duplicate date {current}")
            by_date[key] = value
    values = np.asarray([by_date.get(current, np.nan) for current in expected], dtype=np.float64)
    return FlowSlice(basin=basin,
                     dates=expected,
                     values_mm_day=values,
                     canonical_sha256=_canonical_flow_hash(basin, expected, values),
                     missing_count=int(np.isnan(values).sum()))


def align_flow_to_forcing(flow: FlowSlice, forcing_dates: np.ndarray) -> np.ndarray:
    output = np.full(len(forcing_dates), np.nan, dtype=np.float64)
    positions = np.searchsorted(forcing_dates, flow.dates)
    in_range = (positions >= 0) & (positions < len(forcing_dates))
    if not in_range.all() or not np.array_equal(forcing_dates[positions], flow.dates):
        raise ValueError(f"{flow.basin}: flow dates do not align with forcing dates")
    output[positions] = flow.values_mm_day
    return output
