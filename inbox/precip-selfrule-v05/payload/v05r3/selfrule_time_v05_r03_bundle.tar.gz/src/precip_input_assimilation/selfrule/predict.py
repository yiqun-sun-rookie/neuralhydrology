"""Held-out prediction process with no discharge-reader import."""

from __future__ import annotations

import hashlib
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch

from .data import load_normalization, read_maurer_forcing, slice_indices, valid_target_indices
from .fit import predict_batched, predict_flow_history
from .manifest import claim_task, verify_run_manifest
from .model import FrozenC4, configure_determinism
from .protocol import Protocol
from .rules import RainRule, parameter_index_by_day


def _sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def _write_json_atomic(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + f".tmp-{os.getpid()}")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def _make_runner(protocol: Protocol, device: str) -> tuple[FrozenC4, tuple[str, ...]]:
    _, names, center, scale, q_center, q_scale = load_normalization(protocol.run_dir)
    runner = FrozenC4(protocol.run_dir, device, names, center, scale, q_center, q_scale)
    if runner.sequence_length != protocol.sequence_length:
        raise ValueError("Protocol and frozen model use different sequence lengths")
    return runner, names


def _selected_rain_prediction(runner: FrozenC4,
                              raw: torch.Tensor,
                              static: torch.Tensor,
                              dates: np.ndarray,
                              targets: np.ndarray,
                              arm: dict,
                              batch_targets: int) -> np.ndarray:
    rule = RainRule.from_dict(arm["rule"])
    theta = torch.as_tensor(arm["fit"]["theta"], dtype=torch.float32, device=runner.device)
    indices = torch.as_tensor(parameter_index_by_day(rule, dates, raw[:, runner.precipitation_index]
                                                      .detach().cpu().numpy()),
                              dtype=torch.long,
                              device=runner.device)
    return predict_batched(runner, raw, static, targets, batch_targets, indices, theta)


def predict_stage(protocol: Protocol, basins: list[str], device: str) -> dict:
    """Create held-out predictions without importing or opening discharge data."""
    if len(basins) != 1:
        raise ValueError("predict_stage requires exactly one basin per process")
    verify_run_manifest(protocol, technical=False, requested_basins=basins, device=device)
    def reject_discharge_open(event: str, args: tuple) -> None:
        if event == "open" and args and isinstance(args[0], (str, bytes, os.PathLike)):
            candidate = os.fsdecode(os.fspath(args[0])).replace("\\", "/")
            if "usgs_streamflow" in candidate:
                raise PermissionError("Prediction process attempted to open discharge data")
    sys.addaudithook(reject_discharge_open)
    configure_determinism(protocol.seed)
    runner, dynamic_names = _make_runner(protocol, device)
    records: list[dict] = []
    for basin in basins:
        claim_task(protocol.output_dir / "locks" / f"predict-{basin}.lock", {"stage": "predict", "basin": basin})
        fit_path = protocol.output_dir / "fit" / f"{basin}.json"
        fit_record = json.loads(fit_path.read_text(encoding="utf-8"))
        if not fit_record.get("technical_complete"):
            raise RuntimeError(f"{basin}: fit record is incomplete")
        forcing = read_maurer_forcing(protocol.data_dir, basin, protocol.forcing_start, protocol.forcing_end)
        if forcing.names != dynamic_names:
            raise ValueError(f"{basin}: forcing names differ from frozen model")
        if forcing.canonical_sha256_through(protocol.select_end) != fit_record["forcing_sha256"]:
            raise RuntimeError(f"{basin}: fitting-period forcing changed before prediction")
        requested = slice_indices(forcing.dates, protocol.score_start, protocol.score_end)
        targets = valid_target_indices(forcing.values, requested, protocol.sequence_length)
        coverage = len(targets) / len(requested) if len(requested) else 0.0
        raw = torch.as_tensor(forcing.values, dtype=torch.float32, device=runner.device)
        static = torch.as_tensor(fit_record["static_normalized"], dtype=torch.float32, device=runner.device)
        original = predict_batched(runner, raw, static, targets, protocol.batch_targets)
        rain_intensity = _selected_rain_prediction(runner, raw, static, forcing.dates, targets,
                                                   fit_record["rain"]["rain_intensity"], protocol.batch_targets)
        rain_season = _selected_rain_prediction(runner, raw, static, forcing.dates, targets,
                                                fit_record["rain"]["rain_season"], protocol.batch_targets)
        flow_history = predict_flow_history(fit_record["flow_history"], forcing.dates, forcing.values[:, 0], targets,
                                            original)
        predictions = {
            "original": original,
            "rain_season": rain_season,
            "rain_intensity": rain_intensity,
            "flow_history": flow_history,
        }
        nonfinite = {name: int((~np.isfinite(values)).sum()) for name, values in predictions.items()}
        if any(nonfinite.values()):
            raise RuntimeError(f"{basin}: non-finite held-out predictions: {nonfinite}")
        precipitation = forcing.values[:, runner.precipitation_index]
        intensity_rule = RainRule.from_dict(fit_record["rain"]["rain_intensity"]["rule"])
        season_rule = RainRule.from_dict(fit_record["rain"]["rain_season"]["rule"])
        intensity_indices = parameter_index_by_day(intensity_rule, forcing.dates, precipitation)
        season_indices = parameter_index_by_day(season_rule, forcing.dates, precipitation)
        intensity_theta = np.asarray(fit_record["rain"]["rain_intensity"]["fit"]["theta"], dtype=np.float64)
        season_theta = np.asarray(fit_record["rain"]["rain_season"]["fit"]["theta"], dtype=np.float64)
        from .rules import apply_rule_numpy
        adjusted_intensity = apply_rule_numpy(precipitation, intensity_indices, intensity_theta)
        adjusted_season = apply_rule_numpy(precipitation, season_indices, season_theta)
        output_path = protocol.output_dir / "predictions" / f"{basin}.npz"
        if output_path.exists():
            raise FileExistsError(f"Refusing to overwrite prediction: {output_path}")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = output_path.with_suffix(f".tmp-{os.getpid()}.npz")
        np.savez_compressed(temporary,
                            date=forcing.dates[targets].astype("datetime64[D]").astype(np.int64),
                            original=original.astype(np.float32),
                            rain_season=rain_season.astype(np.float32),
                            rain_intensity=rain_intensity.astype(np.float32),
                            flow_history=flow_history.astype(np.float32),
                            precip_original=precipitation[targets].astype(np.float32),
                            precip_rain_season=adjusted_season[targets].astype(np.float32),
                            precip_rain_intensity=adjusted_intensity[targets].astype(np.float32))
        temporary.replace(output_path)
        records.append({"basin": basin, "prediction_file": str(output_path.relative_to(protocol.output_dir)),
                        "prediction_sha256": _sha256_file(output_path), "forcing_sha256": forcing.canonical_sha256,
                        "target_count": len(targets), "forcing_coverage": coverage})
    summary = {"stage": "predict", "basins": records, "complete": len(records) == len(basins)}
    summary_path = protocol.output_dir / "predict_summaries" / f"{basins[0]}.json"
    if summary_path.exists():
        raise FileExistsError(f"Refusing to overwrite prediction summary: {summary_path}")
    _write_json_atomic(summary_path, summary)
    return summary
