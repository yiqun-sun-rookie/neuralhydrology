"""Fitting routines for the two rain rules and the output-only reference."""

from __future__ import annotations

import math
import time
from dataclasses import asdict, dataclass
from typing import Callable

import numpy as np
import torch

from .model import FrozenC4
from .rules import RainRule, parameter_index_by_day


@dataclass
class RainFitResult:
    complete: bool
    reason: str
    theta: list[float]
    selected_lambda: float | None
    selected_start: float | None
    selected_step: int | None
    selection_mse: float | None
    fit_mse: float | None
    sigma_fit: float
    elapsed_seconds: float
    completed_steps: int
    candidate_records: list[dict]


@dataclass
class FlowHistoryResult:
    complete: bool
    coefficients: list[float]
    selected_lambda: float
    selection_mse: float
    fit_mse: float
    feature_mean: list[list[float]]
    feature_std: list[list[float]]
    sigma_fit: float
    candidate_records: list[dict]


def predict_batched(runner: FrozenC4,
                    raw_dynamic: torch.Tensor,
                    static: torch.Tensor,
                    target_indices: np.ndarray,
                    batch_targets: int,
                    parameter_indices: torch.Tensor | None = None,
                    theta: torch.Tensor | None = None) -> np.ndarray:
    predictions: list[np.ndarray] = []
    with torch.no_grad():
        for offset in range(0, len(target_indices), batch_targets):
            target = torch.as_tensor(target_indices[offset:offset + batch_targets], device=runner.device)
            value = runner.predict(raw_dynamic, static, target, parameter_indices, theta)
            predictions.append(value.detach().cpu().numpy())
    return np.concatenate(predictions) if predictions else np.empty(0, dtype=np.float32)


def _candidate_specs(lambdas: tuple[float, ...], starts: tuple[float, ...]) -> list[dict]:
    return [{"candidate": index, "lambda": lam, "start": start}
            for index, (lam, start) in enumerate((lam, start) for lam in lambdas for start in starts)]


def _is_better(mse: float, best: float, *, tolerance: float = 1e-12) -> bool:
    return math.isfinite(mse) and (not math.isfinite(best) or mse < best - tolerance)


def fit_rain_rule(runner: FrozenC4,
                  raw_dynamic: torch.Tensor,
                  dates: np.ndarray,
                  static: torch.Tensor,
                  rule: RainRule,
                  fit_targets: np.ndarray,
                  fit_observed: np.ndarray,
                  select_targets: np.ndarray,
                  select_observed: np.ndarray,
                  lambdas: tuple[float, ...],
                  starts: tuple[float, ...],
                  learning_rate: float,
                  max_steps: int,
                  selection_interval: int,
                  batch_targets: int,
                  theta_min: float,
                  theta_max: float,
                  candidate_wall_seconds: float | None = None,
                  absolute_deadline: float | None = None,
                  progress: Callable[[dict], None] | None = None) -> RainFitResult:
    started = time.monotonic()
    sigma_fit = float(np.std(fit_observed, ddof=0))
    if not np.isfinite(sigma_fit) or sigma_fit <= 0:
        return RainFitResult(False, "fit flow has zero or invalid variance", [], None, None, None, None, None,
                             sigma_fit, 0.0, 0, [])
    specs = _candidate_specs(lambdas, starts)
    n_candidates = len(specs)
    n_parameters = rule.n_parameters
    parameter_indices = torch.as_tensor(parameter_index_by_day(rule, dates, raw_dynamic[:, runner.precipitation_index]
                                                                 .detach().cpu().numpy()),
                                        dtype=torch.long,
                                        device=runner.device)
    if n_parameters == 0:
        original_fit = predict_batched(runner, raw_dynamic, static, fit_targets, batch_targets)
        original_select = predict_batched(runner, raw_dynamic, static, select_targets, batch_targets)
        return RainFitResult(True, "all seasonal parameters fixed at one", [], max(lambdas), 0.0, 0,
                             float(np.mean((original_select - select_observed)**2)),
                             float(np.mean((original_fit - fit_observed)**2)), sigma_fit,
                             time.monotonic() - started, 0, [])

    initial = torch.as_tensor([spec["start"] for spec in specs], dtype=torch.float32,
                              device=runner.device)[:, None].expand(-1, n_parameters).clone()
    theta = torch.nn.Parameter(initial)
    optimizer = torch.optim.Adam([theta], lr=learning_rate)
    lambda_tensor = torch.as_tensor([spec["lambda"] for spec in specs], dtype=torch.float32,
                                    device=runner.device)
    fit_y = torch.as_tensor(fit_observed, dtype=torch.float32, device=runner.device)
    select_y = torch.as_tensor(select_observed, dtype=torch.float32, device=runner.device)
    best_mse = np.full(n_candidates, np.inf, dtype=np.float64)
    best_step = np.full(n_candidates, -1, dtype=np.int64)
    best_theta = np.full((n_candidates, n_parameters), np.nan, dtype=np.float32)
    histories: list[list[dict]] = [[] for _ in specs]

    def candidate_records() -> list[dict]:
        records: list[dict] = []
        for index, spec in enumerate(specs):
            finite_best = math.isfinite(float(best_mse[index])) and int(best_step[index]) >= 0
            records.append({**spec,
                            "best_step": int(best_step[index]) if finite_best else None,
                            "best_selection_mse": float(best_mse[index]) if finite_best else None,
                            "best_theta": best_theta[index].astype(float).tolist() if finite_best else None,
                            "history": histories[index]})
        return records

    def evaluate(step: int) -> str | None:
        chunks: list[torch.Tensor] = []
        with torch.no_grad():
            for offset in range(0, len(select_targets), batch_targets):
                target = torch.as_tensor(select_targets[offset:offset + batch_targets], device=runner.device)
                prediction = runner.predict_candidates(raw_dynamic, static, target, parameter_indices, theta)
                if not torch.isfinite(prediction).all():
                    return f"non-finite selection prediction at step {step}"
                chunks.append(prediction)
            pred = torch.cat(chunks, dim=1)
            mse = torch.mean((pred - select_y[None, :])**2, dim=1).detach().cpu().numpy()
            if not np.isfinite(mse).all():
                return f"non-finite selection loss at step {step}"
        snapshot = theta.detach().cpu().numpy()
        if not np.isfinite(snapshot).all():
            return f"non-finite parameter at step {step}"
        for index, value in enumerate(mse):
            histories[index].append({"step": step, "selection_mse": float(value)})
            if _is_better(float(value), float(best_mse[index])):
                best_mse[index] = float(value)
                best_step[index] = step
                best_theta[index] = snapshot[index]
        if progress:
            progress({"event": "selection", "step": step, "best_selection_mse": float(np.min(best_mse)),
                      "elapsed_seconds": time.monotonic() - started})
        return None

    initial_failure = evaluate(0)
    if initial_failure is not None:
        return RainFitResult(False, initial_failure, [], None, None, None, None, None, sigma_fit,
                             time.monotonic() - started, 0, candidate_records())
    completed_steps = 0
    reason = "completed"
    complete = True
    n_fit = len(fit_targets)
    scale_squared = (sigma_fit + 0.1)**2
    for step in range(1, max_steps + 1):
        optimizer.zero_grad(set_to_none=True)
        for offset in range(0, n_fit, batch_targets):
            stop = min(offset + batch_targets, n_fit)
            target = torch.as_tensor(fit_targets[offset:stop], device=runner.device)
            pred = runner.predict_candidates(raw_dynamic, static, target, parameter_indices, theta)
            if not torch.isfinite(pred).all():
                complete = False
                reason = f"non-finite fit prediction at step {step}"
                break
            residual = pred - fit_y[None, offset:stop]
            data_loss = residual.square().sum(dim=1) / (n_fit * scale_squared)
            if not torch.isfinite(data_loss).all():
                complete = False
                reason = f"non-finite fit loss at step {step}"
                break
            data_loss.sum().backward()
        if not complete:
            break
        regularization = (lambda_tensor * theta.square().mean(dim=1)).sum()
        if not torch.isfinite(regularization):
            complete = False
            reason = f"non-finite regularization at step {step}"
            break
        regularization.backward()
        if theta.grad is None or not torch.isfinite(theta.grad).all():
            complete = False
            reason = f"missing or non-finite parameter gradient at step {step}"
            break
        optimizer.step()
        with torch.no_grad():
            theta.clamp_(theta_min, theta_max)
            if not torch.isfinite(theta).all():
                complete = False
                reason = f"non-finite parameter after step {step}"
                break
        completed_steps = step
        if step % selection_interval == 0 or step == max_steps:
            evaluation_failure = evaluate(step)
            if evaluation_failure is not None:
                complete = False
                reason = evaluation_failure
                break
        elapsed = time.monotonic() - started
        # All candidates start and end together, so each candidate's wall time
        # is the elapsed group time even though the GPU evaluates them in one
        # batch.
        if candidate_wall_seconds is not None and elapsed >= candidate_wall_seconds:
            complete = False
            reason = "per-candidate equivalent wall limit reached"
            break
        if absolute_deadline is not None and time.monotonic() >= absolute_deadline:
            complete = False
            reason = "experiment wall limit reached"
            break

    records = candidate_records()
    if not complete:
        return RainFitResult(False, reason, [], None, None, None, None, None, sigma_fit,
                             time.monotonic() - started, completed_steps, records)
    if any(record["best_step"] is None for record in records):
        return RainFitResult(False, "one or more required candidates never produced a finite selection score", [],
                             None, None, None, None, None, sigma_fit, time.monotonic() - started,
                             completed_steps, records)

    # Lowest selection error wins.  Exact ties prefer larger lambda, earlier
    # iteration, then the zero start; the candidate index is the final stable key.
    minimum = float(np.min(best_mse))
    tied = [index for index, value in enumerate(best_mse) if abs(float(value) - minimum) <= 1e-12]
    def tie_key(index: int) -> tuple:
        start = float(specs[index]["start"])
        start_priority = 0 if start == 0 else (1 if start > 0 else 2)
        return (-float(specs[index]["lambda"]), int(best_step[index]), start_priority, index)
    selected = min(tied, key=tie_key)
    chosen = torch.as_tensor(best_theta[selected], dtype=torch.float32, device=runner.device)
    fit_prediction = predict_batched(runner, raw_dynamic, static, fit_targets, batch_targets,
                                     parameter_indices, chosen)
    if not np.isfinite(fit_prediction).all():
        return RainFitResult(False, "selected candidate produced a non-finite fit prediction", [], None, None, None,
                             None, None, sigma_fit, time.monotonic() - started, completed_steps, records)
    return RainFitResult(True, "completed", best_theta[selected].astype(float).tolist(),
                         float(specs[selected]["lambda"]), float(specs[selected]["start"]),
                         int(best_step[selected]), float(best_mse[selected]),
                         float(np.mean((fit_prediction - fit_observed)**2)), sigma_fit,
                          time.monotonic() - started, completed_steps, records)


_LAG_RANGES = ((0, 0), (1, 2), (3, 7), (8, 30), (31, 100), (101, 269))


def flow_history_features(precipitation_mm: np.ndarray,
                          original_prediction: np.ndarray,
                          target_indices: np.ndarray) -> np.ndarray:
    features = [np.asarray(original_prediction, dtype=np.float64)]
    log_rain = np.log1p(np.maximum(np.asarray(precipitation_mm, dtype=np.float64), 0.0))
    for lag_start, lag_end in _LAG_RANGES:
        values = []
        for target in target_indices:
            lo = int(target) - lag_end
            hi = int(target) - lag_start + 1
            values.append(float(np.mean(log_rain[lo:hi])))
        features.append(np.asarray(values))
    return np.column_stack(features)


def _warm_for_targets(dates: np.ndarray, target_indices: np.ndarray) -> np.ndarray:
    months = dates[target_indices].astype("datetime64[M]").astype(int) % 12 + 1
    return (months >= 5) & (months <= 10)


def _standardize_by_season(features: np.ndarray,
                           warm: np.ndarray,
                           means: np.ndarray | None = None,
                           stds: np.ndarray | None = None) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    if means is None or stds is None:
        means = np.zeros((2, features.shape[1]), dtype=np.float64)
        stds = np.ones((2, features.shape[1]), dtype=np.float64)
        for season, mask in enumerate((~warm, warm)):
            if not mask.any():
                raise ValueError("Both seasons need fitting samples")
            means[season] = np.mean(features[mask], axis=0)
            stds[season] = np.std(features[mask], axis=0, ddof=0)
            stds[season, stds[season] == 0] = 1.0
    z = np.zeros_like(features, dtype=np.float64)
    for season, mask in enumerate((~warm, warm)):
        z[mask] = (features[mask] - means[season]) / stds[season]
    return z, means, stds


def _block_design(standardized: np.ndarray, warm: np.ndarray) -> np.ndarray:
    design = np.zeros((len(standardized), 2 * (standardized.shape[1] + 1)), dtype=np.float64)
    width = standardized.shape[1] + 1
    for season, mask in enumerate((~warm, warm)):
        design[mask, season * width] = 1.0
        design[mask, season * width + 1:(season + 1) * width] = standardized[mask]
    return design


def _ridge_min_norm(design: np.ndarray, target: np.ndarray, alpha: float, slope_mask: np.ndarray) -> np.ndarray:
    if alpha > 0:
        penalty = np.diag(np.sqrt(alpha) * slope_mask.astype(np.float64))
        x = np.vstack([design, penalty])
        y = np.concatenate([target, np.zeros(design.shape[1])])
    else:
        x, y = design, target
    return np.linalg.lstsq(x, y, rcond=1e-12)[0]


def fit_flow_history(dates: np.ndarray,
                     precipitation_mm: np.ndarray,
                     fit_targets: np.ndarray,
                     fit_original: np.ndarray,
                     fit_observed: np.ndarray,
                     select_targets: np.ndarray,
                     select_original: np.ndarray,
                     select_observed: np.ndarray,
                     lambdas: tuple[float, ...]) -> FlowHistoryResult:
    sigma_fit = float(np.std(fit_observed, ddof=0))
    fit_features = flow_history_features(precipitation_mm, fit_original, fit_targets)
    select_features = flow_history_features(precipitation_mm, select_original, select_targets)
    fit_warm = _warm_for_targets(dates, fit_targets)
    select_warm = _warm_for_targets(dates, select_targets)
    z_fit, means, stds = _standardize_by_season(fit_features, fit_warm)
    z_select, _, _ = _standardize_by_season(select_features, select_warm, means, stds)
    x_fit = _block_design(z_fit, fit_warm)
    x_select = _block_design(z_select, select_warm)
    residual_target = fit_observed - fit_original
    slope_mask = np.ones(x_fit.shape[1], dtype=bool)
    slope_mask[[0, x_fit.shape[1] // 2]] = False
    records: list[dict] = []
    for lam in lambdas:
        n_slopes = int(slope_mask.sum())
        alpha = float(lam) * len(fit_observed) * (sigma_fit + 0.1)**2 / n_slopes
        coefficients = _ridge_min_norm(x_fit, residual_target, alpha, slope_mask)
        if not np.isfinite(coefficients).all():
            raise FloatingPointError(f"Flow-history reference produced non-finite coefficients for lambda={lam}")
        fit_prediction = fit_original + x_fit @ coefficients
        select_prediction = select_original + x_select @ coefficients
        if not np.isfinite(fit_prediction).all() or not np.isfinite(select_prediction).all():
            raise FloatingPointError(f"Flow-history reference produced non-finite predictions for lambda={lam}")
        records.append({"lambda": float(lam),
                        "coefficients": coefficients.tolist(),
                        "fit_mse": float(np.mean((fit_prediction - fit_observed)**2)),
                        "selection_mse": float(np.mean((select_prediction - select_observed)**2))})
    minimum = min(record["selection_mse"] for record in records)
    tied = [record for record in records if abs(record["selection_mse"] - minimum) <= 1e-12]
    selected = max(tied, key=lambda record: record["lambda"])
    return FlowHistoryResult(True, selected["coefficients"], selected["lambda"], selected["selection_mse"],
                             selected["fit_mse"], means.tolist(), stds.tolist(), sigma_fit, records)


def predict_flow_history(record: FlowHistoryResult | dict,
                         dates: np.ndarray,
                         precipitation_mm: np.ndarray,
                         targets: np.ndarray,
                         original: np.ndarray) -> np.ndarray:
    payload = asdict(record) if isinstance(record, FlowHistoryResult) else record
    features = flow_history_features(precipitation_mm, original, targets)
    warm = _warm_for_targets(dates, targets)
    z, _, _ = _standardize_by_season(features, warm,
                                      np.asarray(payload["feature_mean"]), np.asarray(payload["feature_std"]))
    design = _block_design(z, warm)
    return original + design @ np.asarray(payload["coefficients"], dtype=np.float64)
