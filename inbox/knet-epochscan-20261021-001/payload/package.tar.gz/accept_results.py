"""Independent native-identity, complete-array, metric and no-update acceptance."""
from pathlib import Path
import json,hashlib,datetime
import numpy as np
import torch
BASE=Path(__file__).resolve().parent;HPC=BASE/'hpc_results';RUN=HPC/'runs/02092500/attempt_001'
def obj(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):
    with np.load(p,allow_pickle=False) as z:return {k:z[k].copy() for k in z.files}
def compute(pred,truth,thresholds):
    assert pred.shape==truth.shape and pred.ndim==2 and pred.shape[1]==3 and np.isfinite(pred).all() and np.isfinite(truth).all()
    err=pred.astype(np.float64)-truth;groups=[np.ones(truth.shape,bool),truth<=thresholds[0],(truth>thresholds[0])&(truth<=thresholds[1]),truth>thresholds[1]];v=[]
    for g in groups:
        assert g.any();v.extend([float(np.mean(err[g]**2)),float(np.mean(abs(err[g])))])
    by={}
    for k in range(3):
        e=err[:,k];y=truth[:,k];den=float(np.sum((y-y.mean())**2));assert den>0
        by[str(k+1)]=dict(mse=float(np.mean(e*e)),mae=float(np.mean(abs(e))),bias=float(e.mean()),nse=float(1-np.sum(e*e)/den),count=len(e))
    return dict(scores=v,group_counts=[int(g.sum()) for g in groups],by_lead=by)
def compare_candidate(metrics,candidate):
    p=np.array(metrics[candidate]['scores']);out={}
    for arm in ['HBV','UKF_sampling','UKF_backprop']:
        r=np.array(metrics[arm]['scores']);tol=np.maximum(1e-10,1e-7*abs(r));limit=r*1.001+tol
        out[arm]=dict(difference=(p-r).tolist(),relative_change_percent=(100*(p-r)/r).tolist(),numerical_tolerances=tol.tolist(),flow_limits=limit.tolist(),flow_passed=(p<=limit).tolist(),all_flow_pass=bool((p<=limit).all()),overall_mse_improves=bool(r[0]-p[0]>tol[0]))
    return out

def compare(metrics):
    return {candidate:compare_candidate(metrics,candidate) for candidate in ['KNet_e040','KNet_e081','KNet_e121']}

def close_tree(left,right):
    assert type(left)==type(right)
    if isinstance(left,dict):
        assert left.keys()==right.keys()
        for key in left:close_tree(left[key],right[key])
    elif isinstance(left,list):
        assert len(left)==len(right)
        for a,b in zip(left,right):close_tree(a,b)
    elif isinstance(left,float):np.testing.assert_allclose(left,right,rtol=1e-12,atol=1e-14)
    else:assert left==right

identity=obj(BASE/'execution_identity.json');verified=obj(BASE/'collection/verified.json');manifest=obj(HPC/'collection_manifest.json');c=obj(BASE/'replay_contract.json')
assert verified['status']=='FULL_ARCHIVE_HASH_VERIFIED' and verified['job_id']==identity['job_id'] and manifest['identity']==identity
assert sha(HPC/'replay_contract.json')==sha(BASE/'replay_contract.json')==identity['contract_sha256']
declared={r['path']:r for r in manifest['files']}
for row in manifest['files']:assert (HPC/row['path']).stat().st_size==row['bytes'] and sha(HPC/row['path'])==row['sha256']
for row in obj(HPC/'deployment_manifest.json')['files']:assert sha(HPC/row['path'])==row['sha256']
for row in c['input_bindings']:assert sha(HPC/row['path'])==sha(BASE/row['path'])==row['sha256']
native_rows=manifest['native_status'].get('native_job_row',[]);native=native_rows[0] if len(native_rows)==1 else None
receipt=obj(RUN/'receipt.json') if (RUN/'receipt.json').exists() else None;result=obj(RUN/'result.json') if (RUN/'result.json').exists() else None
complete=bool(result and result['status']=='EPOCHSCAN_COMPLETE');computed={};paired={};subsets={};annual={};state={};history={};required=[]
if complete:
    assert native and native['JobID']==identity['job_id'] and native['State']=='COMPLETED' and native['ExitCode']=='0:0'
    assert receipt['status']=='COMPLETED' and receipt['exit_code']==0 and receipt['startup_admission_verified'] and receipt['budget_pass']
    assert int(native['ElapsedRaw'])<=900 and receipt['wall_seconds_upper']<=890 and receipt['combined_rss_peak_bytes']<=6*1024**3 and receipt['system_free_min_bytes']>=2*1024**3 and len(receipt['affinity'])==1 and receipt['mathematical_threads']==1
    assert result['total_optimizer_calls']==receipt['total_optimizer_calls']==result['total_effective_nonzero_steps']==receipt['total_effective_nonzero_steps']==0
    assert result['counters']==dict(filter_trajectories=12,filter_days=32868,forecast_batches=12,forecast_events=85356,optimizer_calls=0,autograd_calls=0,qp_calls=0)
    historical=load(HPC/'inputs/historical_period.npz');snapshot=load(HPC/'inputs/input_snapshot.npz');checkpoints={label:torch.load(HPC/b['path'],weights_only=True,map_location='cpu') for label,b in c['checkpoints'].items()};selection=obj(HPC/'inputs/ukf_selection.json')
    assert all(cp['epoch']==cp['optimizer_steps']==c['checkpoints'][label]['epoch'] and cp['parameter_sha256']==c['checkpoints'][label]['parameter_sha256'] for label,cp in checkpoints.items());thresholds=np.quantile(snapshot['observations'][:2557],[.5,.9,.99],method='linear');dates=historical['dates_ns'].astype('datetime64[ns]').astype('datetime64[D]')
    assert str(dates[0])=='1989-10-01' and str(dates[-1])=='1999-09-30' and np.all(np.diff(dates).astype(int)==1) and np.isfinite(historical['forcing']).all() and np.isfinite(historical['observations']).all()
    arrays={};counts=dict(filter_trajectories=0,filter_days=0,forecast_batches=0,forecast_events=0,optimizer_calls=0,autograd_calls=0,qp_calls=0)
    first_initial=None
    for case in c['cases']:
        name=case['name'];start=case['filter_start'];score=case['score_start'];end=case['end'];days=end-start;warm=score-start
        assert warm==365;issues=np.arange(score,end-3);targets=issues[:,None]+np.arange(1,4);truth=historical['observations'][targets];n=len(issues)
        required.append(f'runs/02092500/attempt_001/{name}/shared_arrays.npz')
        shared=load(RUN/name/'shared_arrays.npz');np.testing.assert_array_equal(shared['filter_global_indices'],np.arange(start,end));np.testing.assert_array_equal(shared['score_global_indices'],np.arange(score,end));np.testing.assert_array_equal(shared['thresholds'],thresholds)
        for key in historical:np.testing.assert_array_equal(shared[key],historical[key])
        initial=shared['initial_state'];assert initial.shape==(1,11) and np.all(initial[0,:2]==0) and initial[0,3]==5 and initial[0,4]==10 and np.all(initial[0,5:]==0)
        # PARAM_NAMES is frozen in the shipped physics source; parFC is coordinate 4.
        assert initial[0,2]==.3*shared['physical_parameters'][0,4]
        if first_initial is None:first_initial=initial.copy()
        np.testing.assert_array_equal(initial,first_initial);np.testing.assert_array_equal(shared['initial_covariance'],np.eye(11)[None]*.001);assert np.isnan(shared['previous_observation']).all()
        computed[name]={};arrays[name]={};state[name]={};annual[name]={}
        for arm in c['trajectory_order']:
            rel=f'runs/02092500/attempt_001/{name}/{arm}/evaluation.npz';required.append(rel);a=load(HPC/rel);arrays[name][arm]=a;proof=result['trajectories'][name][arm]
            assert rel in declared and sha(HPC/rel)==proof['arrays']['sha256'] and (HPC/rel).stat().st_size==proof['arrays']['bytes']
            assert a['prior_states'].shape==a['posterior_states'].shape==(days,1,11) and a['prediction'].shape==(n,3) and np.isfinite(a['prior_states']).all() and np.isfinite(a['posterior_states']).all()
            for key,value in [('initial_state',initial),('issue_indices',issues),('target_indices',targets),('target',truth)]:np.testing.assert_array_equal(a[key],value)
            assert np.isnan(a['previous_observation']).all();np.testing.assert_array_equal(a['corrections'],a['posterior_states']-a['prior_states'])
            assert proof['network_updates']==0 and proof['physical_parameters_sha_before']==proof['physical_parameters_sha_after'] and proof['filter_days']==days and proof['score_days']==end-score
            if arm=='HBV':
                assert proof['observation_updates']==0 and not a['valid_updates'].any() and np.isnan(a['observations_assimilated']).all();np.testing.assert_array_equal(a['prior_states'],a['posterior_states'])
            else:
                assert proof['observation_updates']==days and a['valid_updates'].all();np.testing.assert_array_equal(a['observations_assimilated'].reshape(-1),historical['observations'][start:end])
            if arm.startswith('UKF_'):
                key='sampling_search' if arm=='UKF_sampling' else 'backpropagation';params=selection[key]['selected'];np.testing.assert_array_equal(a['process_diagonal'],params['q_diagonal']);assert float(a['r_b'])==params['r_b'];assert proof['noise_sha_before']==proof['noise_sha_after'] and proof['selected_index']==selection[key]['selected_index'];np.testing.assert_array_equal(a['initial_covariance'],shared['initial_covariance'])
                np.testing.assert_allclose(a['innovation'],a['observations_assimilated']-a['filter_prediction'],rtol=1e-13,atol=1e-14);level=np.maximum(np.maximum(a['filter_prediction'],a['observations_assimilated']),0);variance=np.maximum(float(shared['base_observation_variance']),(params['r_b']*level)**2);np.testing.assert_allclose(a['observation_variance'],variance,rtol=1e-13,atol=1e-14)
            if arm in checkpoints:
                cp=checkpoints[arm];required.append(f'runs/02092500/attempt_001/{name}/{arm}_network_after.pt')
                after=torch.load(RUN/name/(arm+'_network_after.pt'),weights_only=True,map_location='cpu');assert after.keys()==cp['network'].keys() and all(torch.equal(after[k],v) for k,v in cp['network'].items())
                state[name][arm]={}
                assert proof['checkpoint_epoch']==c['checkpoints'][arm]['epoch'] and proof['parameters_require_grad'] is False and proof['state_dict_sha_before']==proof['state_dict_sha_after'] and proof['parameter_sha_before']==proof['parameter_sha_after']==cp['parameter_sha256']
                np.testing.assert_array_equal(a['state_feature_scale'],cp['network']['state_feature_scale'].numpy());np.testing.assert_array_equal(a['correction_cap'],cp['network']['correction_cap_by_state_scale_units'].numpy())
                normalized=abs(a['requested_corrections']/a['state_feature_scale']);boundary=normalized>=a['correction_cap']-1e-12
                state[name][arm]['cap_boundary_fraction_all_days']=float(boundary.mean());state[name][arm]['cap_boundary_fraction_score_days']=float(boundary[warm:].mean())
                state[name][arm]['cap_denominator_all_days']=int(boundary.size)
            metric=compute(a['prediction'],truth,thresholds);computed[name][arm]=metric
            np.testing.assert_allclose(a['scores'],metric['scores'],rtol=1e-12,atol=1e-14)
            close_tree(metric,result['metrics'][name][arm])
            targetdates=dates[targets];years=targetdates.astype('datetime64[Y]').astype(int)+1970;months=targetdates.astype('datetime64[M]').astype(int)%12+1;water=years+(months>=10);annual[name][arm]={}
            for wy in sorted(set(water.reshape(-1))):
                leadmetrics={}
                for j in range(3):
                    mask=water[:,j]==wy;yy=truth[mask,j];e=a['prediction'][mask,j]-yy;den=float(np.sum((yy-yy.mean())**2));leadmetrics[str(j+1)]=dict(count=int(mask.sum()),mse=float(np.mean(e*e)),mae=float(np.mean(abs(e))),bias=float(e.mean()),nse=None if den==0 else float(1-np.sum(e*e)/den))
                annual[name][arm][str(wy)]=leadmetrics
            counts['filter_trajectories']+=1;counts['filter_days']+=days;counts['forecast_batches']+=1;counts['forecast_events']+=a['prediction'].size
        paired[name]=compare(computed[name]);close_tree(paired[name],result['comparisons'][name])
        state[name]['posterior_quantiles_by_arm']={arm:np.quantile(a['posterior_states'][warm:,0],[.05,.5,.95],axis=0).tolist() for arm,a in arrays[name].items()}
    assert counts==result['counters'] and all(p in declared for p in required) and len(required)==20
    for sub in c['subwindows']:
        name=sub['name'];case=sub['case'];issues=np.arange(sub['score_start'],sub['end']-3);a0=arrays[case]['HBV'];mask=np.isin(a0['issue_indices'],issues);np.testing.assert_array_equal(a0['issue_indices'][mask],issues)
        subsets[name]=dict(case=case,issue_count=int(mask.sum()),score_start=str(dates[sub['score_start']]),score_end=str(dates[sub['end']-1]),metrics={arm:compute(a['prediction'][mask],a['target'][mask],thresholds) for arm,a in arrays[case].items()})
        subsets[name]['comparisons']=compare(subsets[name]['metrics'])
    full=arrays['full_history'];restart=arrays['restart_1994']
    for arm in c['trajectory_order']:
        mask=np.isin(full[arm]['issue_indices'],restart[arm]['issue_indices']);np.testing.assert_array_equal(full[arm]['target_indices'][mask],restart[arm]['target_indices']);np.testing.assert_array_equal(full[arm]['target'][mask],restart[arm]['target'])
        d=restart[arm]['prediction']-full[arm]['prediction'][mask];history[arm]=dict(same_late_targets_verified=True,exact_forecast_equality=bool(np.array_equal(d,np.zeros_like(d))),maximum_absolute_forecast_difference=float(abs(d).max()),restart_minus_continuous_mse=float(subsets['late_1995_1999_restart']['metrics'][arm]['scores'][0]-subsets['late_1995_1999_full']['metrics'][arm]['scores'][0]))
ratios={case:{arm:metric['scores'][0]/metrics['HBV']['scores'][0] for arm,metric in metrics.items()} for case,metrics in computed.items()}
ratios.update({case:{arm:metric['scores'][0]/row['metrics']['HBV']['scores'][0] for arm,metric in row['metrics'].items()} for case,row in subsets.items()})
out=dict(status='ACCEPTED_EPOCHSCAN_ARTIFACTS' if complete else 'TECHNICALLY_INCOMPLETE',family=c['family'],job_id=identity['job_id'],native_status=native,receipt=receipt,result=result,computed=computed,comparisons=paired,subwindows=subsets,water_year_metrics=annual,state_summaries=state,history_comparison=history,mse_ratios_to_hbv=ratios,severe_instability_detected=None if not complete else any(v[arm]>100 for v in ratios.values() for arm in checkpoints),archive=verified,required_scientific_files=required,all_required_arrays_hash_verified=complete,network_all_tensors_unchanged=complete,new_acceptance_model_calls=0,new_acceptance_gradient_calls=0,new_acceptance_qp_calls=0,scope=c['scope'],accepted_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
with (BASE/'acceptance.json').open('x',encoding='utf-8') as f:json.dump(out,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
print(json.dumps(dict(status=out['status'],job_id=out['job_id'],mse_ratios=ratios,severe_instability=out['severe_instability_detected'])))
