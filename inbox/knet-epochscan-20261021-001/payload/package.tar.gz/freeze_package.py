"""Seal the reviewed files and prepare exactly one deployment command."""
from pathlib import Path
import json,hashlib,io,tarfile,gzip,datetime
BASE=Path(__file__).resolve().parent
def obj(p):return json.loads(p.read_bytes())
def put(name,value):
    p=BASE/name;p.parent.mkdir(parents=True,exist_ok=True)
    raw=value if isinstance(value,bytes) else (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
    with p.open('xb') as f:f.write(raw)
def row(p):return dict(path=p.relative_to(BASE).as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)
r=obj(BASE/'independent_review.json');assert r['status']=='PASS' and r['review_rounds']==1 and not r['blockers']
for entry in r['reviewed_files']:
    p=Path(entry['path']);p=p if p.is_absolute() else BASE/p
    assert hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
c=obj(BASE/'replay_contract.json');channel=c['channel'];remote=c['remote_root']
paths=sorted(p for p in BASE.iterdir() if p.is_file() and p.suffix in ['.py','.md','.json','.slurm'] and p.name not in ['channel_preflight.json'])+sorted((BASE/'inputs').iterdir())
assert BASE/'replay.slurm' in paths
put('execution_authorization.json',dict(status='AUTHORIZED',family=c['family'],authority='explicit user fixed40/81/121 checkpoints, same historical windows, one independent review then HPC',authorized_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),independent_review_count=1,independent_review_status='PASS',blockers=0,template_manifest_sha256='34afa64ad7f77df8dd365a16030c770e96b281da5ff2f0d8e48890a927b637d7',remote_root=remote,channel=channel,maximum_submissions=1,retry_science=False,new_training_budget=0,files=[row(p) for p in paths]))
paths.append(BASE/'execution_authorization.json');put('deployment_manifest.json',dict(files=[row(p) for p in paths]));paths.append(BASE/'deployment_manifest.json')
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w') as tar:
    for p in paths:
        raw=p.read_bytes();info=tarfile.TarInfo(p.relative_to(BASE).as_posix());info.size=len(raw);info.mtime=0;tar.addfile(info,io.BytesIO(raw))
payload=gzip.compress(stream.getvalue(),mtime=0);digest=hashlib.sha256(payload).hexdigest();put('payload/package.tar.gz',payload)
command=('#!/bin/bash\nset -eo pipefail\n'+f'/data1/home/sunyiq/miniconda3/envs/nh_final/bin/python -u -B "$PWD/inbox/{channel}/payload/deploy.py" "$PWD/inbox/{channel}/payload/package.tar.gz" {digest}\n').encode()
put('mailbox/submit_001.sh',command);put('mailbox/request_001.json',dict(kind='deploy',remote_root=remote,payload_sha256=digest));put('mailbox/extras_001.json',{f'inbox/{channel}/payload/deploy.py':str(BASE/'deploy.py'),f'inbox/{channel}/payload/package.tar.gz':str(BASE/'payload/package.tar.gz')})
put('registry_frozen.json',dict(exp_id=c['family'],type='saved checkpoint training-dose comparison',hypothesis='does81to121 improve both frozen historical cases',base_config='same800-forward150-derivative seed20260922',changed_factor='KNet epoch40/81/121',fixed_factors='physics,UKFs,scale,caps,initialization,windows,mask,metrics',seeds=[20260922],status='REVIEWED_PASS_READY_TO_SUBMIT',run_dir=remote,channel=channel,payload_sha256=digest,checkpoints=c['checkpoints'],metrics_path='runs/02092500/attempt_001/result.json',budget_seconds=900,new_training_calls=0,trajectories=12,maximum_filter_days=32868,maximum_forecast_events=85356,maximum_submissions=1,independent_review_rounds=1,notes=c['scope']))
put('active_execution.json',dict(status='READY_TO_SUBMIT',job_id=None,pending_queries=[]))
print(json.dumps(dict(status='FROZEN_READY_TO_SUBMIT',payload_bytes=len(payload),payload_sha256=digest)))
