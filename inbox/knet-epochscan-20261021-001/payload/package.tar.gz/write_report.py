"""Deliver all frozen-window results and costs, without new model execution."""
from pathlib import Path
import csv,io,json
BASE=Path(__file__).resolve().parent
def obj(p):return json.loads(p.read_bytes())
def put(name,text):
    with (BASE/name).open('x',encoding='utf-8',newline='\n') as f:f.write(text)
a=obj(BASE/'acceptance.json');c=obj(BASE/'replay_contract.json');names=['总体MSE','总体MAE','低流量MSE','低流量MAE','中流量MSE','中流量MAE','高流量MSE','高流量MAE']
lines=['# KNET-EPOCHSCAN-01 运行报告','',f"技术验收：{a['status']}；唯一作业 {a['job_id']}。",'']
if a['status']!='ACCEPTED_EPOCHSCAN_ARTIFACTS':
    lines+=['输出未完整验收，不下训练轮次效果结论。失败原样保留，不重复提交。',json.dumps(dict(native=a['native_status'],receipt=a['receipt']),ensure_ascii=False,indent=2)]
else:
    e=obj(BASE/'epoch_comparison.json');n=a['native_status'];r=a['receipt']
    conclusion={'CONSISTENT_IMPROVEMENT_ON_BOTH_PRIMARY_WINDOWS':'81到121轮在两个主窗口总体MSE均改善，且未触发相对81轮的八项工程退化界限。','MIXED_OR_COSTLY_IMPROVEMENT':'81到121轮有部分改善，但存在窗口差异或流量指标代价，不能概括为越训练越好。','NO_PRIMARY_WINDOW_IMPROVEMENT':'81到121轮在两个主窗口均未检测到总体MSE改善；本结果不支持仅继续同一训练就能改善跨时段表现。'}[e['classification']]
    lines += [conclusion,f"40→81→121在两主窗口总体MSE单调改善：{e['primary_mse_monotonic_40_81_121']}。各子窗、提前量和逐年不利项仍见下表，不能以主窗口概括所有情况。",'', '## 原生状态与预算','',f"Slurm {n['State']}/{n['ExitCode']}；ElapsedRaw={n['ElapsedRaw']}秒 / 900秒；控制器上界{r['wall_seconds_upper']:.6f}秒 / 890秒；CPU请求1、原生AllocCPUS={n.get('AllocCPUS')}、实际亲和性{r['affinity']}、数学线程1、无GPU。CPU子进程秒数{r['child_cpu_seconds']}；RSS峰值{r['combined_rss_peak_bytes']}字节，可用内存最低{r['system_free_min_bytes']}字节。",f"实际计数 {json.dumps(a['result']['counters'])}。已有训练共121次非零更新，检查点分别经历40/81/121次更新；本轮不训练，optimizer/autograd/QP均0。六次KNet网络运行前后所有张量完全相同。",f"完整归档{a['archive']['files']}文件、{a['archive']['archive_bytes']}字节，SHA256={a['archive']['archive_sha256']}。全部文件hash、12模型NPZ+2共享NPZ+6运行后网络共20必需科学文件核验通过。上一轮HBV/两UKF/epoch81共8条输出精确重现={e['previous_run_exact_reproduction']}，逐项证据见epoch_comparison.json。",'', '## 全部固定窗与模型','', '| 窗口 | 模型 | 总体MSE | 总体MAE | 1日MSE | 2日MSE | 3日MSE |','|---|---|---:|---:|---:|---:|---:|']
    tables={**a['computed'],**{k:v['metrics'] for k,v in a['subwindows'].items()}};csvrows=[]
    for case,metrics in tables.items():
        for arm,m in metrics.items():
            b=m['by_lead'];lines.append(f"| {case} | {arm} | {m['scores'][0]:.10g} | {m['scores'][1]:.10g} | {b['1']['mse']:.10g} | {b['2']['mse']:.10g} | {b['3']['mse']:.10g} |")
            for lead,v in b.items():csvrows.append(dict(window=case,arm=arm,lead=lead,**v))
    stream=io.StringIO();writer=csv.DictWriter(stream,fieldnames=list(csvrows[0]));writer.writeheader();writer.writerows(csvrows);put('全部逐提前量指标.csv',stream.getvalue())
    lines+=['','## 训练轮次变化（负百分比为误差下降）','','| 窗口 | 转换 | 总体MSE变化% | 判定 | 八项通过数 | 1日变化% | 2日变化% | 3日变化% |','|---|---|---:|---|---:|---:|---:|---:|']
    for case,comparisons in e['transitions'].items():
        for transition,v in comparisons.items():
            b=v['by_lead'];lines.append(f"| {case} | {transition} | {v['relative_change_percent']:+.6f} | {v['direction']} | {sum(v['eight_metric_pass'])}/8 | {b['1']['relative_change_percent']:+.6f} | {b['2']['relative_change_percent']:+.6f} | {b['3']['relative_change_percent']:+.6f} |")
    lines+=['','## 与HBV/两UKF逐项检查','','检查顺序：'+ '、'.join(names)+'。原0.1%允许退化和数值容差保持；这八项流量检查与旧雪约束研究九门槛不同，未改旧门槛。','', '| 窗口 | 检查点 | 对照 | 总体MSE变化% | 八项逐项结果 |','|---|---|---|---:|---|']
    for case in tables:
        pairs=a['comparisons'][case] if case in a['comparisons'] else a['subwindows'][case]['comparisons']
        for arm,refs in pairs.items():
            for ref,v in refs.items():lines.append(f"| {case} | {arm} | {ref} | {v['relative_change_percent'][0]:+.6f} | {','.join('通过' if p else '失败' for p in v['flow_passed'])} |")
    lines+=['','## 总体与低中高流量完整指标','','| 窗口 | 模型 | '+' | '.join(names)+' |','|---|---|'+'---:|'*8]
    for case,metrics in tables.items():
        for arm,v in metrics.items():lines.append('| '+case+' | '+arm+' | '+' | '.join(f'{x:.10g}' for x in v['scores'])+' |')
    lines+=['','## 逐水文年与不利项','','| 运行历史 | 转换 | 年×提前量数 | 改善数 | 恶化数 | 新/旧误差>2倍数 | 最坏倍数 |','|---|---|---:|---:|---:|---:|---:|']
    for v in e['annual_transitions']:lines.append(f"| {v['case']} | {v['transition']} | {v['count']} | {v['improved']} | {v['worse']} | {v['above2']} | {v['worst_ratio']:.8g} |")
    lines+=['','逐水文年×提前量相对HBV的MSE倍数统计（全部比值保存在epoch_comparison.json）：','','| 运行历史 | 检查点 | 总数 | >2倍 | >10倍 | >100倍 | 最坏倍数 |','|---|---|---:|---:|---:|---:|---:|']
    for v in e['annual_mse_ratios_to_hbv']:lines.append(f"| {v['case']} | {v['arm']} | {v['count']} | {v['above2']} | {v['above10']} | {v['above100']} | {v['worst_ratio']:.8g} |")
    annualrows=[]
    for case,arms in a['water_year_metrics'].items():
        for arm,years in arms.items():
            for wy,leads in years.items():
                for lead,v in leads.items():annualrows.append(dict(case=case,arm=arm,water_year=wy,lead=lead,**v))
    stream=io.StringIO();writer=csv.DictWriter(stream,fieldnames=list(annualrows[0]));writer.writeheader();writer.writerows(annualrows);put('全部水文年指标.csv',stream.getvalue())
    lines+=['','完整逐年1/2/3日MSE、MAE、bias、NSE在全部水文年指标.csv；全部固定窗/分组/提前量、数值容差、工程失败在acceptance.json。全部轮次及对照不利项如下：','']
    for v in e['adverse_items']:
        if 'comparison' in v:lines.append(f"- {v['window']} {v['comparison']}：{v['direction']}；未通过项目："+'、'.join(names[i] for i in v['failed_metric_indices']))
        else:lines.append(f"- {v['window']} {v['arm']} {v['lead']}日MSE高于{v['reference']} {v['mse_relative_change_percent']:.5f}%。")
    lines+=['','## 运行历史与状态描述','',f"严重失稳规则（非有限或总体MSE>100×同窗HBV）检测={a['severe_instability_detected']}；低于此界限不代表稳定。全部固定窗MSE/HBV倍数：",json.dumps(a['mse_ratios_to_hbv'],ensure_ascii=False,indent=2),'','同后窗重启减连续运行MSE及最大预报差：',json.dumps(a['history_comparison'],ensure_ascii=False,indent=2),'','各检查点触及原生改正上限的比例：']
    lines+=['','全部固定窗相对HBV的MSE倍数；括号为>2/>10/>100的布尔标记：','','| 窗口 | 检查点 | 合并 | 1日 | 2日 | 3日 |','|---|---|---|---|---|---|']
    for case,arms in e['fixed_window_mse_ratios_to_hbv'].items():
        for arm,v in arms.items():lines.append('| '+case+' | '+arm+' | '+' | '.join(f"{v[k]['ratio']:.7g} ({int(v[k]['above2'])}/{int(v[k]['above10'])}/{int(v[k]['above100'])})" for k in ['pooled','1','2','3'])+' |')
    for case,v in a['state_summaries'].items():
        for arm in c['checkpoints']:
            z=v[arm];lines.append(f"- {case} {arm}：{z['cap_denominator_all_days']}个状态日分量，全部日{z['cap_boundary_fraction_all_days']:.6%}，评分日{z['cap_boundary_fraction_score_days']:.6%}。")
    lines+=['','## 下一步建议','']
    if e['classification']=='NO_PRIMARY_WINDOW_IMPROVEMENT':lines+=['先用本次已有数组定位40→81→121的退化年份和起点，核对开发期选模趋势与历史期是否相反。当前证据不支持直接加长同一配方训练；下一实验应在固定预算下检验训练目标、长历史记忆或当前配方多种子，须另行冻结，不能以历史期挑最优检查点宣称泛化。']
    elif e['classification']=='MIXED_OR_COSTLY_IMPROVEMENT':lines+=['先用已有数组检查改善与退化分别集中在哪些年份、流量组和提前量。当前只支持带条件的训练轮次变化，下一步再冻结当前配方多种子与未参与选模窗口；不据局部改善直接扩大训练。']
    else:lines+=['本单种子支持81→121在两个固定主窗继续改善，先核查全部子窗与年度代价，再冻结当前配方多种子与独立评估；尚不足以推断超过121轮会继续改善，也不能自动替换生产检查点。']
    rounds=[]
    for p in sorted((BASE/'monitoring').glob('*result.json')):
        v=obj(p)
        if v.get('status')=='MONITOR_FAILED':rounds.append(dict(file=p.name,status=v['status'],reason=v.get('reason',v.get('error')),sequence=v.get('sequence')))
    lines+=['','## 过程异常保留','',json.dumps(rounds,ensure_ascii=False,indent=2) if rounds else '保存监控中没有MONITOR_FAILED记录。','上一轮验收浮点字典精确比较失败在本轮冻结前改为原有重算容差；布尔/整数/结构精确，科学门槛未放宽。原上一轮文件与失败证据保留。']
lines+=['','## 边界','',c['scope'],'','初始化、评分窗口、因果日期、观测和已知未来气象均同条件；历史训练/调参预算不相等。历史期已使用，本轮是针对性复核；没有实测雪量真值。三个轮次来自同一条训练轨迹，不能当作三个独立种子；旧合同A五种子失稳证据保留，不因本轮变化而作废。','', '白话总结：这次直接比较同一个模型练到40、81、121轮后的历史期成绩。多练是否有用，要看所有固定窗口和代价，不能只挑最好的一项。','']
put('运行报告.md','\n'.join(lines))
print(json.dumps(dict(status='REPORT_WRITTEN',path=str(BASE/'运行报告.md')),ensure_ascii=False))
