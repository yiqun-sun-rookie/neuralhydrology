"""Prepare an isolated checkpoint-dose evaluation; no model execution or submission."""
from pathlib import Path
import ast, datetime, hashlib, json
import numpy as np
import torch

BASE=Path(__file__).resolve().parent
ROOT=BASE.parent
OLD=ROOT/'hpc_knet_xperiod_20261021_001'
TRAIN=ROOT/'last150_full_training_20261011_001'
FAMILY='KNET-EPOCHSCAN-01'
ARMS=['HBV','UKF_sampling','UKF_backprop','KNet_e040','KNet_e081','KNet_e121']

def obj(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(name,value):
    p=BASE/name;p.parent.mkdir(parents=True,exist_ok=True)
    raw=value if isinstance(value,bytes) else (value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
    with p.open('xb') as f:f.write(raw)
def row(p):return dict(path=str(p.resolve()),sha256=sha(p),bytes=p.stat().st_size)
def derive(name):
    return (OLD/name).read_text(encoding='utf-8').replace('knet_xperiod_20261021_001','knet_epochscan_20261021_001').replace('knet-xperiod-20261021-001','knet-epochscan-20261021-001').replace('KNET-XPERIOD-01',FAMILY).replace('XPERIOD_COMPLETE','EPOCHSCAN_COMPLETE').replace('XPERIOD_FAILED','EPOCHSCAN_FAILED').replace('ACCEPTED_XPERIOD_ARTIFACTS','ACCEPTED_EPOCHSCAN_ARTIFACTS').replace('knet_xperiod_020_c01','knet_epochscan_020_c01')

assert obj(OLD/'acceptance.json')['status']=='ACCEPTED_XPERIOD_ARTIFACTS'
sources=[]
for name in ['historical_period.npz','input_snapshot.npz','ukf_selection.json','frozen_data_loader.py']:
    p=OLD/'inputs'/name;expected=next(r for r in obj(OLD/'replay_contract.json')['input_bindings'] if r['path']=='inputs/'+name)
    assert sha(p)==expected['sha256'];put('inputs/'+name,p.read_bytes());sources.append(row(p))
audit=obj(ROOT/'hpc_knet_baseline_20261021_001/training_audit.json')
checkpoints={};reference=None
for epoch in [40,81,121]:
    p=TRAIN/'long/checkpoints'/f'epoch_{epoch:03d}.pt'
    recorded=next(r for r in audit['sources'] if Path(r['path']).name==p.name)
    assert sha(p)==recorded['sha256']
    cp=torch.load(p,weights_only=True,map_location='cpu')
    assert cp['epoch']==cp['optimizer_steps']==epoch and cp['seed']==20260922
    buffers={k:v for k,v in cp['network'].items() if k in ['state_feature_scale','observation_feature_scale','correction_cap_by_state_scale_units']}
    assert len(buffers)==3
    if reference is None:reference=buffers
    else:assert all(torch.equal(reference[k],v) for k,v in buffers.items())
    name=f'inputs/knet_e{epoch:03d}.pt';put(name,p.read_bytes());sources.append(row(p))
    checkpoints[f'KNet_e{epoch:03d}']=dict(epoch=epoch,path=name,sha256=sha(p),parameter_sha256=cp['parameter_sha256'],seed=cp['seed'],optimizer_steps=cp['optimizer_steps'])
assert checkpoints['KNet_e081']['sha256']==sha(OLD/'inputs/knet_selected.pt')
put('checkpoint_provenance.json',dict(status='THREE_EXISTING_CHECKPOINTS_VERIFIED',checkpoints=checkpoints,sources=sources,training_audit=row(ROOT/'hpc_knet_baseline_20261021_001/training_audit.json'),training_plan=row(TRAIN/'plan.json'),feature_scales_and_correction_caps_identical=True,new_training_calls=0,selection='user-fixed 40/81/121; no historical-period reselection'))
put('data_provenance.json',obj(OLD/'data_provenance.json'))
put('input_bindings.json',dict(files=[]))
bindings=[dict(path=p.relative_to(BASE).as_posix(),sha256=sha(p),bytes=p.stat().st_size) for p in sorted((BASE/'inputs').iterdir())]
put('checkpoint_bindings.json',dict(files=bindings))
c=obj(OLD/'replay_contract.json')
c.update(family=FAMILY,remote_root='/data1/home/sunyiq/knet_camels_hpc_20261012_001/attempts/knet_epochscan_20261021_001',channel='knet-epochscan-20261021-001',trajectory_order=ARMS,checkpoints=checkpoints,input_bindings=bindings,maximum_filter_trajectories=12,maximum_filter_days=32868,maximum_forecast_batches=12,maximum_forecast_events=85356)
c.pop('knet_selected_epoch');c.pop('knet_parameter_sha256')
c['scope']='02092500 / seed20260922 / same 800-day forward and last150 derivative training trajectory, frozen epochs40/81/121; previously exposed historical period, known future meteorology. No new training, untouched test, statistical significance, equal historical compute or true state accuracy claim.'
c['checkpoint_rules']=dict(primary=['full_history','restart_1994'],transitions=[[40,81],[81,121],[40,121]],metric='pooled three-lead MSE',improvement='old_mse-new_mse > max(1e-10,1e-7*abs(old_mse))',consistent_improvement='81->121 improves both primary cases AND no eight-metric engineering failure vs81 in either primary case',monotonic='40->81 and 81->121 improve both primary cases',mixed='any primary-case improvement with any other primary-case regression, or MSE improvement with flow metric cost',no_improvement='no primary case improves beyond numerical tolerance',secondary='all frozen subwindows, water years and leads; no selection or dropping',limits='diagnoses saved training trajectory only; cannot prove additional updates beyond121 would help, or identify training length as sole cause')
c['array_recomputation_tolerances']=dict(relative=1e-12,absolute=1e-14,exact_keys_booleans_integers=True)
put('replay_contract.json',c)
names=['safe_io.py','local_io.py','replay_protocol.py','replay_controller.py','query_replay.py','collect_terminal.py','assemble_archive.py','fetch_receipt.py','mailbox_api.py','publish.py','observe_probe.py','deploy.py','replay.slurm']
transport=[]
for name in names:
    text=derive(name).replace('one 020 four-arm frozen-model evaluation job','one 020 six-arm two-history checkpoint evaluation job')
    put(name,text);transport.append(dict(path=name,source=str(OLD/name),source_sha256=sha(OLD/name),derived_sha256=sha(BASE/name)))
put('transport_sources.json',dict(files=transport,change='new owned root/channel/job name; controller recognizes EPOCHSCAN_COMPLETE; scientific rules unchanged'))

text=derive('evaluation_math.py').replace('def comparisons(metrics):','def compare_candidate(metrics,label):').replace("metrics['KNet_selected']['scores']","metrics[label]['scores']")
text+='\ndef comparisons(metrics):\n    return {label:compare_candidate(metrics,label) for label in ["KNet_e040","KNet_e081","KNet_e121"]}\n'
put('evaluation_math.py',text)
text=derive('replay_worker.py').replace('Eight bounded frozen-model trajectories','Twelve bounded checkpoint-comparison trajectories')
text=text.replace("cp=torch.load(io.BytesIO(read_input('inputs/knet_selected.pt')),weights_only=True,map_location='cpu')\n    assert cp['epoch']==cp['optimizer_steps']==81 and cp['seed']==20260922 and cp['parameter_sha256']==contract['knet_parameter_sha256']", "checkpoints={}\n    for label,binding in contract['checkpoints'].items():\n        cp=torch.load(io.BytesIO(read_input(binding['path'])),weights_only=True,map_location='cpu')\n        assert cp['epoch']==cp['optimizer_steps']==binding['epoch'] and cp['seed']==20260922 and cp['parameter_sha256']==binding['parameter_sha256']\n        checkpoints[label]=cp\n    cp=checkpoints['KNet_e081']\n    for other in checkpoints.values():\n        for key in ['state_feature_scale','observation_feature_scale','correction_cap_by_state_scale_units']:assert torch.equal(cp['network'][key],other['network'][key])")
text=text.replace("COUNTERS['filter_trajectories']<8","COUNTERS['filter_trajectories']<12").replace("assert label=='KNet_selected'","assert label in checkpoints\n                cp=checkpoints[label]").replace("contract['knet_parameter_sha256']","contract['checkpoints'][label]['parameter_sha256']").replace("purpose='frozen_xperiod'","purpose='frozen_epochscan'").replace("put(cname+'/KNet_selected_network_after.pt',stream.getvalue())","put(cname+'/'+label+'_network_after.pt',stream.getvalue())").replace('checkpoint_epoch=81','checkpoint_epoch=cp[\'epoch\']').replace('<=21912','<=32868').replace('<=56904','<=85356').replace('filter_trajectories=8,filter_days=21912,forecast_batches=8,forecast_events=56904','filter_trajectories=12,filter_days=32868,forecast_batches=12,forecast_events=85356')
put('replay_worker.py',text)

text=derive('accept_results.py').replace('def compare(metrics):','def compare_candidate(metrics,candidate):').replace("metrics['KNet_selected']['scores']","metrics[candidate]['scores']")
insert='''
def compare(metrics):
    return {candidate:compare_candidate(metrics,candidate) for candidate in ['KNet_e040','KNet_e081','KNet_e121']}

def close_tree(left,right):
    assert type(left)==type(right)
    if isinstance(left,dict):
        assert left.keys()==right.keys()
        for key in left:close_tree(left[key],right[key])
    elif isinstance(left,list):
        assert len(left)==len(right)
        for a,b in zip(left,right):close_tree(a,b)
    elif isinstance(left,float):np.testing.assert_allclose(left,right,rtol=1e-12,atol=1e-14)
    else:assert left==right

'''
text=text.replace("identity=obj(BASE/'execution_identity.json')",insert+"identity=obj(BASE/'execution_identity.json')")
text=text.replace('filter_trajectories=8,filter_days=21912,forecast_batches=8,forecast_events=56904','filter_trajectories=12,filter_days=32868,forecast_batches=12,forecast_events=85356')
text=text.replace("cp=torch.load(HPC/'inputs/knet_selected.pt',weights_only=True,map_location='cpu');", "checkpoints={label:torch.load(HPC/b['path'],weights_only=True,map_location='cpu') for label,b in c['checkpoints'].items()};")
text=text.replace("assert cp['epoch']==cp['optimizer_steps']==81 and cp['parameter_sha256']==c['knet_parameter_sha256'];thresholds=", "assert all(cp['epoch']==cp['optimizer_steps']==c['checkpoints'][label]['epoch'] and cp['parameter_sha256']==c['checkpoints'][label]['parameter_sha256'] for label,cp in checkpoints.items());thresholds=")
text=text.replace("required.extend([f'runs/02092500/attempt_001/{name}/shared_arrays.npz',f'runs/02092500/attempt_001/{name}/KNet_selected_network_after.pt'])","required.append(f'runs/02092500/attempt_001/{name}/shared_arrays.npz')")
text=text.replace("        after=torch.load(RUN/name/'KNet_selected_network_after.pt',weights_only=True,map_location='cpu');assert after.keys()==cp['network'].keys() and all(torch.equal(after[k],v) for k,v in cp['network'].items())\n",'')
text=text.replace("if arm=='KNet_selected':", "if arm in checkpoints:\n                cp=checkpoints[arm];required.append(f'runs/02092500/attempt_001/{name}/{arm}_network_after.pt')\n                after=torch.load(RUN/name/(arm+'_network_after.pt'),weights_only=True,map_location='cpu');assert after.keys()==cp['network'].keys() and all(torch.equal(after[k],v) for k,v in cp['network'].items())\n                state[name][arm]={}")
text=text.replace("proof['checkpoint_epoch']==81","proof['checkpoint_epoch']==c['checkpoints'][arm]['epoch']")
for key in ['cap_boundary_fraction_all_days','cap_boundary_fraction_score_days','cap_denominator_all_days']:
    text=text.replace("state[name]['"+key+"']","state[name][arm]['"+key+"']")
text=text.replace("paired[name]=compare(computed[name]);assert paired[name]==result['comparisons'][name]","paired[name]=compare(computed[name]);close_tree(paired[name],result['comparisons'][name])")
text=text.replace('len(required)==12','len(required)==20').replace("any(v['KNet_selected']>100 for v in ratios.values())","any(v[arm]>100 for v in ratios.values() for arm in checkpoints)")
put('accept_results.py',text)
put('user_authorization.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),request='用已有第40、81、121轮检查点，在相同历史窗口与HBV、UKF对照，判断多训练是否改善跨时段表现。先冻结窗口、规则和预算，独立审核一次，没问题就去HPC跑。新的独立目录，不覆盖现有实验，跑完给结果和下一步建议。'))
print(json.dumps(dict(status='INPUTS_CONTRACT_AND_EXECUTION_PREPARED',checkpoints=checkpoints,local_model_calls=0)))
