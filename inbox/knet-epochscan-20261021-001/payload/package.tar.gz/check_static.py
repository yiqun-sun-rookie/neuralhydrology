"""Bounded syntax, provenance, dates, counters and scalar-boundary checks only."""
from pathlib import Path
import ast,json,hashlib
import numpy as np
from evaluation_math import scores,forecast_indices,comparisons
BASE=Path(__file__).resolve().parent
c=json.loads((BASE/'replay_contract.json').read_bytes())
for p in BASE.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'),filename=str(p))
for r in c['input_bindings']:assert hashlib.sha256((BASE/r['path']).read_bytes()).hexdigest()==r['sha256']
with np.load(BASE/'inputs/historical_period.npz',allow_pickle=False) as z:dates=z['dates_ns'].astype('datetime64[ns]').astype('datetime64[D]')
total_days=total_events=0
for case,expected in zip(c['cases'],[('1989-10-01','1990-10-01',3652,3284),('1994-10-01','1995-10-01',1826,1458)]):
    start=case['filter_start'];score=case['score_start'];end=case['end'];issues,targets=forecast_indices(score,end)
    assert (str(dates[start]),str(dates[score]),end-start,len(issues))==expected
    assert str(dates[end-1])=='1999-09-30' and score-start==365 and targets.min()==score+1 and targets.max()==end-1
    total_days+=6*(end-start);total_events+=6*targets.size
assert total_days==c['maximum_filter_days']==32868 and total_events==c['maximum_forecast_events']==85356
assert c['maximum_filter_trajectories']==c['maximum_forecast_batches']==12
assert c['maximum_total_optimizer_calls']==c['maximum_autograd_calls']==c['maximum_qp_calls']==0
y=np.array([[0.,1.,3.],[2.,5.,6.]])
np.testing.assert_array_equal(scores(y+1,y,[1.,3.])['scores'],np.ones(8))
m={k:dict(scores=[1.]*8) for k in c['trajectory_order']}
m['KNet_e040']['scores']=[1.001+1e-7]*8
assert comparisons(m)['KNet_e040']['HBV']['all_flow_pass']
m['KNet_e040']['scores'][0]+=1e-8
assert not comparisons(m)['KNet_e040']['HBV']['all_flow_pass']
slurm=(BASE/'replay.slurm').read_bytes();assert b'--mem' not in slurm and b'\r' not in slurm and b'00:15:00' in slurm
assert "folder2.rglob('*')" in (BASE/'collect_terminal.py').read_text()
assert "len(required)==20" in (BASE/'accept_results.py').read_text()
assert "'.slurm'" in (BASE/'freeze_package.py').read_text()
out=dict(status='STATIC_CHECKS_PASS',filter_days=total_days,forecast_events=total_events,trajectories=12,local_model_calls=0,checks=['syntax','input_SHA','fixed_dates','counter_budget','metric_boundary','complete_collector','slurm_in_payload'])
with (BASE/'static_checks.json').open('x',encoding='utf-8') as f:json.dump(out,f,indent=2)
print(json.dumps(out))
