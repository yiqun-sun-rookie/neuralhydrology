"""Read accepted arrays only. Apply predeclared checkpoint-dose decisions."""
from pathlib import Path
import json,hashlib
import numpy as np
BASE=Path(__file__).resolve().parent
OLD=BASE.parent/'hpc_knet_xperiod_20261021_001'
def obj(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):
    with np.load(p,allow_pickle=False) as z:return {k:z[k].copy() for k in z.files}
a=obj(BASE/'acceptance.json');c=obj(BASE/'replay_contract.json')
assert a['status']=='ACCEPTED_EPOCHSCAN_ARTIFACTS' and a['all_required_arrays_hash_verified']
tables={**a['computed'],**{name:row['metrics'] for name,row in a['subwindows'].items()}}
transitions={};adverse=[]
for case,metrics in tables.items():
    transitions[case]={}
    for old,new in c['checkpoint_rules']['transitions']:
        before=metrics[f'KNet_e{old:03d}'];after=metrics[f'KNet_e{new:03d}'];r=np.asarray(before['scores']);p=np.asarray(after['scores']);tol=np.maximum(1e-10,1e-7*abs(r));passed=p<=r*1.001+tol
        direction='IMPROVED' if r[0]-p[0]>tol[0] else 'WORSE' if p[0]-r[0]>tol[0] else 'NO_DETECTED_CHANGE'
        leads={lead:dict(old_mse=before['by_lead'][lead]['mse'],new_mse=v['mse'],delta=v['mse']-before['by_lead'][lead]['mse'],relative_change_percent=100*(v['mse']/before['by_lead'][lead]['mse']-1)) for lead,v in after['by_lead'].items()}
        transitions[case][f'{old}_to_{new}']=dict(direction=direction,old_mse=float(r[0]),new_mse=float(p[0]),mse_delta=float(p[0]-r[0]),relative_change_percent=float(100*(p[0]/r[0]-1)),numerical_tolerance=float(tol[0]),eight_metric_pass=passed.tolist(),all_flow_pass=bool(passed.all()),metric_differences=(p-r).tolist(),by_lead=leads)
        if direction=='WORSE' or not passed.all():adverse.append(dict(window=case,comparison=f'{old}_to_{new}',direction=direction,failed_metric_indices=np.where(~passed)[0].tolist()))
    for arm in c['checkpoints']:
        for ref in ['HBV','UKF_sampling','UKF_backprop']:
            for j in ['1','2','3']:
                p=metrics[arm]['by_lead'][j]['mse'];r=metrics[ref]['by_lead'][j]['mse']
                if p-r>max(1e-10,1e-7*abs(r)):adverse.append(dict(window=case,arm=arm,reference=ref,lead=int(j),mse_relative_change_percent=100*(p/r-1)))
primary=c['checkpoint_rules']['primary'];late=[transitions[name]['81_to_121'] for name in primary]
consistent=all(v['direction']=='IMPROVED' and v['all_flow_pass'] for v in late)
monotonic=all(transitions[name][t]['direction']=='IMPROVED' for name in primary for t in ['40_to_81','81_to_121'])
any_improvement=any(v['direction']=='IMPROVED' for v in late)
classification='CONSISTENT_IMPROVEMENT_ON_BOTH_PRIMARY_WINDOWS' if consistent else 'MIXED_OR_COSTLY_IMPROVEMENT' if any_improvement else 'NO_PRIMARY_WINDOW_IMPROVEMENT'
annual=[]
for case,metrics in a['water_year_metrics'].items():
    for old,new in c['checkpoint_rules']['transitions']:
        rows=[]
        for wy,leads in metrics[f'KNet_e{old:03d}'].items():
            for lead,v in leads.items():
                r=v['mse'];p=metrics[f'KNet_e{new:03d}'][wy][lead]['mse'];tol=max(1e-10,1e-7*abs(r))
                rows.append(dict(water_year=int(wy),lead=int(lead),old_mse=r,new_mse=p,ratio=p/r,improved=r-p>tol,worse=p-r>tol))
        annual.append(dict(case=case,transition=f'{old}_to_{new}',count=len(rows),improved=sum(v['improved'] for v in rows),worse=sum(v['worse'] for v in rows),above2=sum(v['ratio']>2 for v in rows),worst_ratio=max(v['ratio'] for v in rows),rows=rows))
fixed_window_ratios={}
for case,metrics in tables.items():
    fixed_window_ratios[case]={}
    for arm in c['checkpoints']:
        values={'pooled':metrics[arm]['scores'][0]/metrics['HBV']['scores'][0],**{lead:metrics[arm]['by_lead'][lead]['mse']/metrics['HBV']['by_lead'][lead]['mse'] for lead in ['1','2','3']}}
        fixed_window_ratios[case][arm]={key:dict(ratio=value,above2=value>2,above10=value>10,above100=value>100) for key,value in values.items()}
annual_baseline=[]
for case,metrics in a['water_year_metrics'].items():
    for arm in c['checkpoints']:
        rows=[]
        for wy,leads in metrics[arm].items():
            for lead,v in leads.items():
                ref=metrics['HBV'][wy][lead]['mse'];ratio=v['mse']/ref
                rows.append(dict(water_year=int(wy),lead=int(lead),mse=v['mse'],hbv_mse=ref,ratio=ratio))
        annual_baseline.append(dict(case=case,arm=arm,count=len(rows),above2=sum(v['ratio']>2 for v in rows),above10=sum(v['ratio']>10 for v in rows),above100=sum(v['ratio']>100 for v in rows),worst_ratio=max(v['ratio'] for v in rows),rows=rows))
reproduction=[]
assert obj(OLD/'acceptance.json')['status']=='ACCEPTED_XPERIOD_ARTIFACTS'
old_manifest={r['path']:r for r in obj(OLD/'hpc_results/collection_manifest.json')['files']}
for case in primary:
    for new,old in [('HBV','HBV'),('UKF_sampling','UKF_sampling'),('UKF_backprop','UKF_backprop'),('KNet_e081','KNet_selected')]:
        rel=f'runs/02092500/attempt_001/{case}/{old}/evaluation.npz';path=OLD/'hpc_results'/rel
        assert sha(path)==old_manifest[rel]['sha256'];before=load(path);after=load(BASE/f'hpc_results/runs/02092500/attempt_001/{case}/{new}/evaluation.npz')
        checks={k:bool(np.array_equal(before[k],after[k])) for k in ['issue_indices','target_indices','target','prior_states','posterior_states','prediction']}
        reproduction.append(dict(case=case,arm=new,source=str(path),source_sha256=sha(path),exact_array_equal=checks,maximum_forecast_absolute_difference=float(np.max(abs(before['prediction']-after['prediction'])))))
out=dict(status='CHECKPOINT_COMPARISON_COMPLETE',classification=classification,epoch81_to121_consistent_improvement=consistent,primary_mse_monotonic_40_81_121=monotonic,transitions=transitions,annual_transitions=annual,fixed_window_mse_ratios_to_hbv=fixed_window_ratios,annual_mse_ratios_to_hbv=annual_baseline,adverse_items=adverse,previous_run_reproduction=reproduction,previous_run_exact_reproduction=all(all(r['exact_array_equal'].values()) for r in reproduction),prior_acceptance_sha256=sha(OLD/'acceptance.json'),accepted_source_sha256=sha(BASE/'acceptance.json'),local_model_calls=0,scope=c['scope'])
with (BASE/'epoch_comparison.json').open('x',encoding='utf-8') as f:json.dump(out,f,ensure_ascii=False,indent=2,allow_nan=False)
print(json.dumps(dict(status=out['status'],classification=classification,monotonic=monotonic,previous_run_exact=out['previous_run_exact_reproduction'],primary={case:transitions[case] for case in primary})))
