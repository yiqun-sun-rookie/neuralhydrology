"""One resumable developmental training run; no discharge or sealed inputs."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import random
import sys
import time
import traceback

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from id25.regional_daily_storage import RegionalDailyStorage
from id25.regional_storage_observation import center_on_fit_windows, project_storage


def now():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False), encoding="utf-8")
    os.replace(temporary, path)


def save_checkpoint(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(value, temporary)
    os.replace(temporary, path)


def run(args):
    config = json.loads(args.config.read_text())
    root = args.config.resolve().parent
    transforms = json.loads((root / "inputs/transforms.json").read_text())
    receipt = json.loads((root / "inputs/input_receipt.json").read_text())
    args.output.mkdir(parents=True, exist_ok=True)
    if (args.output / "last.pt").exists() and not args.resume:
        raise ValueError("Existing run requires explicit checkpoint continuation")
    torch.set_num_threads(config["cpu_threads"])
    torch.set_num_interop_threads(1)
    torch.manual_seed(config["seed"])
    random.seed(config["seed"])
    np.random.seed(config["seed"])
    with np.load(root / "inputs/inputs.npz", allow_pickle=False) as z:
        data = {name: z[name] for name in z.files}
    forcing = torch.from_numpy(data["forcing"])
    statics = torch.from_numpy(data["static_features"])
    targets = torch.from_numpy(data["targets_cm"])
    weights = torch.from_numpy(data["sampling_weights"])
    fit_mask = torch.from_numpy(data["fit_mask"])
    model = RegionalDailyStorage(statics.shape[1], transforms["dynamic_mean"], transforms["dynamic_scale"])
    optimizer = torch.optim.Adam(model.parameters(), lr=config["learning_rate"])
    start, best = 0, float("inf")
    if args.resume:
        checkpoint = torch.load(args.resume, map_location="cpu", weights_only=False)
        if checkpoint["input_sha256"] != receipt["inputs_sha256"] or checkpoint["config"] != config:
            raise ValueError("Resume requires identical inputs and training configuration")
        model.load_state_dict(checkpoint["model"])
        optimizer.load_state_dict(checkpoint["optimizer"])
        start, best = checkpoint["epoch"], checkpoint["best_val_mse_cm2"]
        torch.set_rng_state(checkpoint["rng_state"])
    print(json.dumps({"event": "START", "time": now(), "epoch": start,
                      "regions": statics.shape[0], "days": forcing.shape[0],
                      "torch": torch.__version__, "device": "cpu", "seed": config["seed"]}), flush=True)
    write_json(args.output / "status.json", {"state": "RUNNING", "epoch": start,
               "updated_at": now(), "job_id": os.environ.get("SLURM_JOB_ID"), "config": config})
    for epoch in range(start + 1, config["epochs"] + 1):
        began = time.monotonic()
        model.train()
        optimizer.zero_grad(set_to_none=True)
        daily, _, _, _ = model(forcing, statics)
        predictions = project_storage(daily, weights)
        pc, yc, _, _, valid = center_on_fit_windows(predictions, targets, fit_mask)
        loss = (pc[valid] - yc[valid]).square().mean()
        if not torch.isfinite(loss):
            raise FloatingPointError("Nonfinite training loss")
        loss.backward()
        grad = torch.nn.utils.clip_grad_norm_(model.parameters(), config["gradient_clip"], error_if_nonfinite=True)
        optimizer.step()
        del daily, predictions, pc, yc, valid, loss
        model.eval()
        with torch.no_grad():
            daily, state, _, _ = model(forcing, statics)
            prediction = project_storage(daily, weights)
            pc, yc, p_ref, y_ref, valid = center_on_fit_windows(prediction, targets, fit_mask)
            train_mse = float((pc[valid] - yc[valid]).square().mean())
            val_valid = (~fit_mask[:, None]) & torch.isfinite(targets)
            val_mse = float((pc[val_valid] - yc[val_valid]).square().mean())
        if not np.isfinite([train_mse, val_mse]).all():
            raise FloatingPointError("Nonfinite post-update score")
        improved = val_mse < best
        best = min(best, val_mse)
        checkpoint = {"model": model.state_dict(), "optimizer": optimizer.state_dict(),
                      "epoch": epoch, "best_val_mse_cm2": best, "config": config,
                      "input_sha256": receipt["inputs_sha256"], "transforms": transforms,
                      "prediction_reference_cm": p_ref, "observation_reference_cm": y_ref,
                      "state": state, "state_date": str(data["dates"][-1]),
                      "region_ids": data["support_ids"].astype(str).tolist(),
                      "fit_solution_ids": data["solution_ids"][data["fit_mask"]].astype(str).tolist(),
                      "rng_state": torch.get_rng_state(), "saved_at": now()}
        if improved:
            save_checkpoint(args.output / "best.pt", checkpoint)
        save_checkpoint(args.output / "last.pt", checkpoint)
        status = {"state": "RUNNING", "epoch": epoch, "epochs": config["epochs"],
                  "train_rmse_cm": train_mse ** .5, "val_rmse_cm": val_mse ** .5,
                  "best_val_rmse_cm": best ** .5, "gradient_norm": float(grad),
                  "epoch_seconds": time.monotonic() - began, "updated_at": now(),
                  "job_id": os.environ.get("SLURM_JOB_ID")}
        with (args.output / "metrics.jsonl").open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(status, allow_nan=False) + "\n")
        write_json(args.output / "status.json", status)
        print(json.dumps(status), flush=True)
    best_checkpoint = torch.load(args.output / "best.pt", map_location="cpu", weights_only=False)
    model.load_state_dict(best_checkpoint["model"])
    with torch.no_grad():
        params, initial = model.initialize(statics)
        daily, state, states, fluxes = model(forcing, statics, record=True)
        prediction = project_storage(daily, weights)
        pc, yc, p_ref, y_ref, valid = center_on_fit_windows(prediction, targets, fit_mask)
        previous = torch.cat([initial.sum(1)[None], states[:-1].sum(-1)], dim=0)
        residual = states.sum(-1) - previous - forcing[:, :, 0] + fluxes[:, :, 1] + fluxes[:, :, 2]
        max_balance = float(residual.abs().max())
        if float(states.min()) < -1e-5 or max_balance > 1e-3:
            raise ValueError("Export failed the daily nonnegative-stock/water-balance check")
    np.savez_compressed(args.output / "daily_states.npz", dates=data["dates"],
                        support_ids=data["support_ids"], daily_mean_total_mm=daily.numpy(),
                        states_mm=states.numpy(), fluxes_mm_day=fluxes.numpy(),
                        state_names=np.array(["snow", "fast", "slow"]),
                        flux_names=np.array(["melt", "evaporation", "drainage", "recharge"]))
    np.savez_compressed(args.output / "monthly_predictions.npz", solution_ids=data["solution_ids"],
                        support_ids=data["support_ids"], prediction_anomaly_cm=pc.numpy(),
                        observed_anomaly_cm=yc.numpy(), fit_mask=data["fit_mask"],
                        prediction_reference_cm=p_ref.numpy(), observation_reference_cm=y_ref.numpy())
    report = {"state": "COMPLETED", "finished_at": now(), "epochs_completed": config["epochs"],
              "best_epoch": best_checkpoint["epoch"], "region_count": len(data["support_ids"]),
              "fit_window_count": int(fit_mask.sum()), "validation_window_count": int((~fit_mask).sum()),
              "train_rmse_cm": float((pc[valid] - yc[valid]).square().mean().sqrt()),
              "val_rmse_cm": float((pc[val_valid] - yc[val_valid]).square().mean().sqrt()),
              "maximum_daily_balance_error_mm": max_balance, "minimum_stock_mm": float(states.min()),
              "input_receipt": receipt, "checkpoint": "best.pt",
              "interpretation": "Developmental total-storage fit; daily components and drainage have no independent validation"}
    write_json(args.output / "report.json", report)
    write_json(args.output / "status.json", report)
    print(json.dumps(report), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--resume", type=Path)
    parsed = parser.parse_args()
    try:
        run(parsed)
    except Exception as exc:
        parsed.output.mkdir(parents=True, exist_ok=True)
        write_json(parsed.output / "status.json", {"state": "FAILED", "updated_at": now(),
                   "job_id": os.environ.get("SLURM_JOB_ID"), "error": str(exc)})
        traceback.print_exc()
        sys.exit(1)
