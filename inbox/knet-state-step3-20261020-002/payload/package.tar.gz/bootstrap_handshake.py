"""Complete the same ready/nonce acknowledgement on HPC, without Git return latency."""
import json,time,datetime,traceback
from pathlib import Path
import safe_io as s
from query_replay import query
BASE=Path(__file__).resolve().parent
identity=json.loads(s.read_checked(BASE/'execution_identity.json'))
start=time.monotonic();attempt=0
try:
    while time.monotonic()-start < 21600:
        attempt+=1
        row=query(identity['job_id'])
        s.create('logs/bootstrap_query_%03d.json'%attempt,row)
        if row['terminal']:
            raise RuntimeError('Job ended before ready acknowledgement')
        snap=row.get('fresh_snapshot')
        if snap and snap['phase']=='WAITING_FOR_HANDSHAKE':
            s.create('logs/bootstrap_handshake.json',dict(status='ACKNOWLEDGED',job_id=identity['job_id'],
                nonce=snap['nonce'],contract_sha256=snap['contract_sha256'],controller_pid=snap['controller_pid'],
                origin='login-node query process launched by this deployment',
                query_wait_seconds=row['snapshot_wait_seconds'],utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
            break
        time.sleep(20)
    else:
        raise RuntimeError('Queue-only bootstrap deadline exceeded')
except BaseException as exc:
    s.create('logs/bootstrap_failure.json',dict(error=repr(exc),traceback=traceback.format_exc()))
    raise
