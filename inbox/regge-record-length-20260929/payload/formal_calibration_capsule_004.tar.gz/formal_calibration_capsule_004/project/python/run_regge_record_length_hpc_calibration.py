"""Command-line entry for the isolated Regge calibration HPC bridge."""
from __future__ import annotations

import argparse
from pathlib import Path

from regge_record_length_study.hpc_calibration import (
    build_capsule,
    import_remote_batch,
    record_return_transport_verification,
    run_remote_batch,
    verify_decrypted_archive,
    verify_capsule,
    verify_remote_batch,
    verify_return_package,
    write_deployment_binding,
    write_encrypted_return_manifest,
)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Build, run, verify, or import the six-calibration HPC bridge"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    build = subparsers.add_parser("build-capsule")
    build.add_argument("--capsule-root", type=Path, required=True)
    build.add_argument("--output-recipient-certificate", type=Path, required=True)
    build.add_argument("--hpc-signing-public-key", type=Path, required=True)
    binding = subparsers.add_parser("write-deployment-binding")
    binding.add_argument("--capsule-root", type=Path, required=True)
    binding.add_argument("--capsule-archive", type=Path, required=True)
    binding.add_argument("--hpc-signing-public-key", type=Path, required=True)
    binding.add_argument("--destination", type=Path, required=True)
    verify_capsule_parser = subparsers.add_parser("verify-capsule")
    verify_capsule_parser.add_argument("--capsule-root", type=Path, required=True)
    run = subparsers.add_parser("run-remote-batch")
    run.add_argument("--capsule-root", type=Path, required=True)
    run.add_argument("--output-root", type=Path, required=True)
    verify = subparsers.add_parser("verify-remote-batch")
    verify.add_argument("--remote-root", type=Path, required=True)
    import_parser = subparsers.add_parser("import-remote-batch")
    import_parser.add_argument("--remote-root", type=Path, required=True)
    manifest_parser = subparsers.add_parser("write-return-manifest")
    manifest_parser.add_argument("--package-root", type=Path, required=True)
    manifest_parser.add_argument("--source-root", type=Path, required=True)
    manifest_parser.add_argument("--capsule-root", type=Path, required=True)
    verify_return = subparsers.add_parser("verify-return-package")
    verify_return.add_argument("--package-root", type=Path, required=True)
    verify_return.add_argument("--deployment-binding", type=Path, required=True)
    verify_return.add_argument("--hpc-signing-public-key", type=Path, required=True)
    verify_plain = subparsers.add_parser("verify-decrypted-archive")
    verify_plain.add_argument("--archive", type=Path, required=True)
    verify_plain.add_argument("--transport-manifest", type=Path, required=True)
    record_transport = subparsers.add_parser("record-return-transport")
    record_transport.add_argument("--package-root", type=Path, required=True)
    record_transport.add_argument("--decrypted-archive", type=Path, required=True)
    record_transport.add_argument("--remote-root", type=Path, required=True)
    record_transport.add_argument(
        "--hpc-signing-public-key", type=Path, required=True,
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if args.command == "build-capsule":
        build_capsule(
            args.capsule_root, args.output_recipient_certificate,
            args.hpc_signing_public_key,
        )
    elif args.command == "write-deployment-binding":
        write_deployment_binding(
            args.capsule_root, args.capsule_archive,
            args.hpc_signing_public_key, args.destination,
        )
    elif args.command == "verify-capsule":
        verify_capsule(args.capsule_root)
    elif args.command == "run-remote-batch":
        run_remote_batch(args.capsule_root, args.output_root)
    elif args.command == "verify-remote-batch":
        verify_remote_batch(args.remote_root)
    elif args.command == "import-remote-batch":
        import_remote_batch(args.remote_root)
    elif args.command == "write-return-manifest":
        write_encrypted_return_manifest(
            args.package_root, args.source_root, args.capsule_root,
        )
    elif args.command == "verify-return-package":
        verify_return_package(
            args.package_root, args.deployment_binding,
            args.hpc_signing_public_key,
        )
    elif args.command == "verify-decrypted-archive":
        verify_decrypted_archive(args.archive, args.transport_manifest)
    elif args.command == "record-return-transport":
        record_return_transport_verification(
            args.package_root, args.decrypted_archive, args.remote_root,
            args.hpc_signing_public_key,
        )
    else:  # pragma: no cover
        raise AssertionError(args.command)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
