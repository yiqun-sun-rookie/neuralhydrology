"""Frozen design and score primitives for the Regge process-noise search."""
from __future__ import annotations

import numpy as np


_ORIGINAL = np.array([0.014, 0.1, 0.0004, 0.12, 0.0], dtype=np.float64)
_LOWER = np.array([0.00014, 0.001, 0.000004, 0.0012, 0.00000015], dtype=np.float64)
_UPPER = np.array([1.4, 10.0, 0.04, 12.0, 0.0015], dtype=np.float64)


def _log_latin_hypercube(rng: np.random.Generator, count: int, dimensions: int) -> np.ndarray:
    """Draw one independently jittered and permuted stratum per dimension."""
    unit = (np.arange(count, dtype=np.float64)[:, None] + rng.random((count, dimensions))) / count
    for column in range(dimensions):
        unit[:, column] = unit[rng.permutation(count), column]
    return np.exp(np.log(_LOWER[:dimensions]) + unit * (np.log(_UPPER[:dimensions]) -
                                                          np.log(_LOWER[:dimensions])))


def build_noise_design(seed: int = 909001) -> np.ndarray:
    """Return the fixed 128-by-5 two-branch process-variance design."""
    rng = np.random.default_rng(seed)
    design = np.empty((128, 5), dtype=np.float64)
    design[0] = _ORIGINAL
    design[1:32, :4] = _log_latin_hypercube(rng, 31, 4)
    design[1:32, 4] = 0.0
    design[32:] = _log_latin_hypercube(rng, 96, 5)
    return design


def forecast_metrics(predictions, observations) -> dict[str, np.ndarray]:
    """Compute four lead-wise RMSE values without dropping candidate origins."""
    prediction = np.asarray(predictions, dtype=np.float64)
    observation = np.asarray(observations, dtype=np.float64)
    if prediction.ndim != 3 or prediction.shape[-1] != 4:
        raise ValueError("predictions must have shape [candidates, origins, 4]")
    if observation.ndim != 2 or observation.shape[-1] != 4:
        raise ValueError("observations must have shape [origins, 4]")
    if prediction.shape[1] != observation.shape[0] or observation.shape[0] == 0:
        raise ValueError("predictions and observations must contain the same nonzero origins")
    if not np.isfinite(observation).all():
        raise ValueError("observations must be finite; target origins cannot be dropped")

    valid = np.isfinite(prediction).all(axis=(1, 2))
    rmse = np.full((prediction.shape[0], 4), np.inf, dtype=np.float64)
    if valid.any():
        with np.errstate(over="ignore", invalid="ignore"):
            values = np.sqrt(np.mean((prediction[valid] - observation[None])**2, axis=1))
        finite_values = np.isfinite(values).all(axis=1)
        valid_indices = np.flatnonzero(valid)
        rmse[valid_indices[finite_values]] = values[finite_values]
        valid[valid_indices[~finite_values]] = False
    return {"rmse": rmse, "valid": valid}


def relative_scores(rmse, reference_rmse) -> np.ndarray:
    """Return the equal mean of the four RMSE ratios for every candidate."""
    values = np.asarray(rmse, dtype=np.float64)
    reference = np.asarray(reference_rmse, dtype=np.float64)
    if values.ndim != 2 or values.shape[1] != 4:
        raise ValueError("rmse must have shape [candidates, 4]")
    if reference.shape != (4,) or not np.isfinite(reference).all() or np.any(reference <= 0):
        raise ValueError("reference_rmse must contain four finite strictly positive values")
    if np.any(values < 0):
        raise ValueError("rmse values cannot be negative")
    scores = np.full(values.shape[0], np.inf, dtype=np.float64)
    valid = np.isfinite(values).all(axis=1)
    if valid.any():
        with np.errstate(over="ignore", invalid="ignore"):
            candidate_scores = np.mean(values[valid] / reference, axis=1)
        valid_indices = np.flatnonzero(valid)
        finite = np.isfinite(candidate_scores)
        scores[valid_indices[finite]] = candidate_scores[finite]
    return scores


def training_shortlist(scores, count: int = 8) -> list[int]:
    """Keep original candidate zero and the best finite non-original candidates."""
    values = np.asarray(scores, dtype=np.float64)
    if values.ndim != 1 or values.size == 0:
        raise ValueError("scores must be a nonempty one-dimensional array")
    if not isinstance(count, (int, np.integer)) or count < 1:
        raise ValueError("count must be a positive integer")
    if np.any(values[np.isfinite(values)] < 0):
        raise ValueError("finite scores cannot be negative")
    if not np.isfinite(values[0]):
        raise ValueError("original candidate 0 must have a finite training score")
    valid_ids = np.flatnonzero(np.isfinite(values))
    if valid_ids.size < count:
        raise ValueError(f"fewer than {count} valid candidates, including original candidate 0, are available")
    nonoriginal = valid_ids[valid_ids != 0]
    ordered = sorted(nonoriginal.tolist(), key=lambda candidate: (values[candidate], candidate))
    return [0, *ordered[:count - 1]]


def select_candidates(ids, training_scores, selection_scores, keep: int = 3) -> list[int]:
    """Rank aligned shortlist members by selection, training, then candidate ID."""
    candidate_ids = list(ids)
    training = np.asarray(training_scores, dtype=np.float64)
    selection = np.asarray(selection_scores, dtype=np.float64)
    if not isinstance(keep, (int, np.integer)) or keep < 1:
        raise ValueError("keep must be a positive integer")
    if training.ndim != 1 or selection.ndim != 1 or len(candidate_ids) != training.size or training.shape != selection.shape:
        raise ValueError("ids, training_scores, and selection_scores must be aligned one-dimensional sequences")
    if any(not isinstance(candidate, (int, np.integer)) or candidate < 0 for candidate in candidate_ids):
        raise ValueError("candidate ids must be nonnegative integers")
    candidate_ids = [int(candidate) for candidate in candidate_ids]
    if len(set(candidate_ids)) != len(candidate_ids):
        raise ValueError("candidate ids must be unique")
    if 0 not in candidate_ids:
        raise ValueError("original candidate 0 must be present")
    if not np.isfinite(training).all() or np.any(training < 0):
        raise ValueError("training scores for shortlisted candidates must be finite and nonnegative")
    if np.isnan(selection).any() or np.isneginf(selection).any() or np.any(selection < 0):
        raise ValueError("selection scores must be finite nonnegative values or positive infinity")
    original_position = candidate_ids.index(0)
    if not np.isfinite(selection[original_position]):
        raise ValueError("original candidate 0 must have a finite selection score")

    survivors = [position for position, score in enumerate(selection) if np.isfinite(score)]
    if len(survivors) < keep:
        raise ValueError(f"fewer than {keep} candidates survive selection")
    survivors.sort(key=lambda position: (selection[position], training[position], candidate_ids[position]))
    return [candidate_ids[position] for position in survivors[:keep]]
