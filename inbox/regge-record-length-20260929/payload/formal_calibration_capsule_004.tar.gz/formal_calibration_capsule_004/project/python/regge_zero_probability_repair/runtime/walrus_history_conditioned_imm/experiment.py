"""Finite-history development runner with isolated artifacts and causal replay."""
from contextlib import nullcontext
from dataclasses import fields
from datetime import datetime, timezone
import csv
import hashlib
import json
import os
from pathlib import Path
import platform
import time
import traceback

import numpy as np
import torch

from .data import choose_windows, load_reference, window_origins
from .filter import DifferentiableWalrusIMM, FilterState
from .forecast import forecast_global_state
from .network import TransitionNetwork

FROZEN_CONFIG_SHA256 = 'a3707905bfd68c0a257293fd75a571116530b5a7c39538061ece7d603c2f2911'


def validate_frozen_config(config):
    scientific = {key: value for key, value in config.items() if key != 'reference_root'}
    digest = hashlib.sha256(json.dumps(scientific, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    if digest != FROZEN_CONFIG_SHA256:
        raise ValueError('Configuration differs from frozen development design')


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False), encoding='utf-8')


def create_run_directory(output_root, run_id):
    if not run_id or Path(run_id).name != run_id or run_id in {'.', '..'}:
        raise ValueError('run_id must be a single directory name')
    root = Path(output_root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    target = root / run_id
    target.mkdir(exist_ok=False)
    return target


def detach_state(state):
    return FilterState(*(getattr(state, f.name).detach().clone() for f in fields(FilterState)))


def combine_features(forcing, state):
    global_state = torch.einsum('bm,bmd->bd', state.probabilities, state.states)
    return torch.cat([forcing, global_state, state.probabilities], dim=-1)


def empty_diagnostics():
    return {'update_batch_members': 0, 'all_likelihoods_underflow': 0, 'prior_weighted_evidence_underflow': 0}


def source_arithmetic_likelihoods(innovation, variance):
    """Diagnostic-only reproduction of source _gaussian_likelihood for scalar Q.

    Keep determinant, inverse, left-associated quadratic form, and the final
    normalizer*exp(exponent) as distinct NumPy operations. exp(log_likelihood)
    can miss source underflow. Nothing returned here feeds the tensor filter.
    """
    innovation = innovation.detach().cpu().numpy()[..., None]
    covariance = variance.detach().cpu().numpy()[..., None, None]
    shape = covariance.shape[:-2]
    likelihoods = np.full(shape, 1e-300, dtype=np.float64)
    # A scalar zero covariance is exactly the source's singular-inverse case.
    invertible = covariance[..., 0, 0] != 0
    if np.any(invertible):
        selected = covariance[invertible]
        residual = innovation[invertible]
        determinant = np.linalg.det(selected)
        determinant = np.where(determinant <= 0, 1e-300, determinant)
        inverse = np.linalg.inv(selected)
        exponent = ((-.5 * residual[:, None, :]) @ inverse @ residual[..., None])[:, 0, 0]
        normalizer = 1.0 / np.sqrt((2.0 * np.pi) ** 1 * determinant)
        likelihoods[invertible] = normalizer * np.exp(exponent)
    return likelihoods


def add_diagnostics(total, result):
    with torch.no_grad():
        likelihoods = source_arithmetic_likelihoods(result.diagnostic_innovation, result.diagnostic_observation_variance)
        priors = result.prior_probabilities.detach().cpu().numpy()
        total['update_batch_members'] += len(likelihoods)
        total['all_likelihoods_underflow'] += int((likelihoods == 0).all(-1).sum())
        total['prior_weighted_evidence_underflow'] += int(((likelihoods * priors).sum(-1) == 0).sum())


def merge_diagnostics(target, source):
    for key, value in source.items():
        target[key] += value


def sequential_rollout(filt, network, state, previous_features, forcing, observations, *, burn_in, capture=False):
    """Matrix[t] precedes Q[t]; saved posterior[t] follows Q[t].

    Initial state is posterior after start-1. Hidden state resets at start.
    Burn-in is own-rule/no-grad; only the remaining scored hours retain graphs.
    """
    if forcing.ndim != 3 or observations.shape != forcing.shape[:2] or forcing.shape[-1] != 2:
        raise ValueError('Expected forcing [batch,hours,2] and observations [batch,hours]')
    if not 0 <= burn_in < forcing.shape[1]:
        raise ValueError('Burn-in must leave at least one scored hour')
    hidden = network.initial_hidden(len(forcing))
    evidence, transitions, posteriors, globals_ = [], [], [], []
    diagnostics = empty_diagnostics()
    for t in range(forcing.shape[1]):
        with torch.no_grad() if t < burn_in else nullcontext():
            matrix, hidden = network(previous_features, hidden)
            result = filt.step(state, forcing[:, t], observations[:, t], matrix)
            if not torch.isfinite(result.log_evidence).all() or not torch.isfinite(result.global_state).all():
                raise FloatingPointError(f'Nonfinite filter output at window hour {t}')
            state = result.filter_state
            previous_features = combine_features(forcing[:, t], state)
            add_diagnostics(diagnostics, result)
            if t >= burn_in:
                evidence.append(result.log_evidence)
                if capture:
                    transitions.append(matrix)
                    posteriors.append(state)
                    globals_.append(result.global_state)
    loss = -torch.stack(evidence).mean()
    if loss.ndim != 0:
        raise AssertionError('Training objective must be scalar')
    return {'loss': loss, 'state': state, 'transitions': transitions, 'posteriors': posteriors,
            'global_states': globals_, 'diagnostics': diagnostics}


def fixed_stream_snapshots(filt, forcing, observations, timestamps, starts, *, fit_normalizer, progress=None):
    """Snapshots BEFORE start update, not posterior after start observation."""
    state = filt.initial_state(1)
    previous = combine_features(torch.zeros(1, 2, dtype=torch.float64), state)
    network = TransitionNetwork('fixed', filt.n_models, torch.zeros(7 + filt.n_models), torch.ones(7 + filt.n_models))
    snapshots, features = {}, []
    wanted = set(starts)
    diagnostics = empty_diagnostics()
    years = timestamps.astype('datetime64[Y]').astype(int) + 1970
    # Fit all fixed-rule training features; snapshot causally through last start.
    end = max(max(starts), int(np.flatnonzero(np.isin(years, [2000, 2001, 2002]))[-1]) if fit_normalizer else 0)
    with torch.no_grad():
        for t in range(end + 1):
            if t in wanted:
                snapshots[t] = (detach_state(state), previous.detach().clone())
            matrix, _ = network(previous, network.initial_hidden(1))
            result = filt.step(state, forcing[t:t + 1], observations[t:t + 1], matrix)
            add_diagnostics(diagnostics, result)
            state = result.filter_state
            previous = combine_features(forcing[t:t + 1], state)
            if not torch.isfinite(previous).all() or not torch.isfinite(result.log_evidence).all():
                raise FloatingPointError(f'Nonfinite fixed stream at index {t}')
            if fit_normalizer and years[t] in [2000, 2001, 2002]:
                features.append(previous[0].clone())
            if progress and t % 720 == 0:
                progress('fixed_stream', hour=t, total_hours=end + 1, model_count=filt.n_models)
    normalizer = None
    if fit_normalizer:
        tensor = torch.stack(features)
        scale = tensor.std(0, unbiased=False)
        normalizer = {'mean': tensor.mean(0), 'scale': torch.where(scale > 0, scale, torch.ones_like(scale)),
                      'feature_count': len(tensor), 'years': [2000, 2001, 2002]}
    return snapshots, normalizer, diagnostics


def window_batch(starts, snapshots, forcing, observations, length):
    state = FilterState(*(torch.cat([getattr(snapshots[s][0], f.name) for s in starts]) for f in fields(FilterState)))
    previous = torch.cat([snapshots[s][1] for s in starts])
    return state, previous, torch.stack([forcing[s:s + length] for s in starts]), torch.stack([observations[s:s + length] for s in starts])


def evidence_epoch(filt, network, starts, snapshots, forcing, observations, config, optimizer=None):
    losses = []
    diagnostics = empty_diagnostics()
    for offset in range(0, len(starts), config['batch_size']):
        group = starts[offset:offset + config['batch_size']]
        args = window_batch(group, snapshots, forcing, observations, config['burn_in'] + config['scored_hours'])
        with nullcontext() if optimizer is not None else torch.no_grad():
            result = sequential_rollout(filt, network, *args, burn_in=config['burn_in'])
        loss = result['loss']
        if optimizer is not None:
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            gradients = [p.grad for p in network.parameters() if p.grad is not None]
            if not gradients or not all(torch.isfinite(g).all() for g in gradients):
                raise FloatingPointError('Missing/nonfinite parameter gradients')
            torch.nn.utils.clip_grad_norm_(network.parameters(), config['gradient_clip'], error_if_nonfinite=True)
            optimizer.step()
        losses.append((float(loss.detach()), len(group)))
        merge_diagnostics(diagnostics, result['diagnostics'])
    return sum(loss * count for loss, count in losses) / sum(count for _, count in losses), diagnostics


def restore_checkpoint(network, path):
    record = torch.load(path, map_location='cpu', weights_only=True)
    if not np.isfinite(record['selection_negative_log_evidence']):
        raise ValueError('Selected checkpoint evidence is nonfinite')
    network.load_state_dict(record['state_dict'], strict=True)
    return {key: value for key, value in record.items() if key != 'state_dict'}


def checkpoint_causality_probe(checkpoint_path, filt, initial_state, previous_features, forcing, observations,
                              *, burn_in, probe_scored_hour=12):
    """Read a selected history checkpoint and test its actual sequential dependency.

    Inputs use window-batch shapes. Returns JSON-ready numerical gate evidence.
    No optimizer step, source write, or forecast assessment occurs here.
    """
    record = torch.load(checkpoint_path, map_location='cpu', weights_only=True)
    weights = record['state_dict']
    if 'cell.weight_hh' not in weights:
        raise ValueError('Causal checkpoint probe requires a history network')
    hidden_size = weights['cell.weight_hh'].shape[1]
    network = TransitionNetwork('history', filt.n_models, weights['feature_mean'], weights['feature_scale'], hidden_size)
    restore_checkpoint(network, checkpoint_path)
    q = observations.detach().clone().requires_grad_()
    result = sequential_rollout(filt, network, detach_state(initial_state), previous_features.detach(), forcing,
                                q, burn_in=burn_in, capture=True)
    if not 0 < probe_scored_hour < len(result['transitions']):
        raise ValueError('Probe must have at least one previous scored hour')
    index = burn_in + probe_scored_hour
    matrix_element = result['transitions'][probe_scored_hour][0, 0, 0]
    gradient = torch.autograd.grad(matrix_element, q, retain_graph=True)[0]
    leaking_gradient = torch.autograd.grad(matrix_element + q[0, index], q)[0]
    evidence = {'checkpoint': str(checkpoint_path), 'checkpoint_epoch': record['epoch'], 'probe_window_hour': index,
                'all_gradients_finite': bool(torch.isfinite(gradient).all()),
                'past_observation_gradient_max_abs': float(gradient[:, burn_in:index].abs().max()),
                'same_and_future_nonzero_gradient_count': int(torch.count_nonzero(gradient[:, index:])),
                'burn_in_nonzero_gradient_count': int(torch.count_nonzero(gradient[:, :burn_in])),
                'deliberately_leaking_control_rejected': bool(torch.count_nonzero(leaking_gradient[:, index:]) > 0)}
    evidence['pass'] = (evidence['all_gradients_finite'] and evidence['past_observation_gradient_max_abs'] > 0
                       and evidence['same_and_future_nonzero_gradient_count'] == 0
                       and evidence['burn_in_nonzero_gradient_count'] == 0
                       and evidence['deliberately_leaking_control_rejected'])
    return evidence


def train_rule(filt, kind, seed, normalizer, windows, snapshots, forcing, observations, config, run_dir, progress):
    torch.manual_seed(seed)
    network = TransitionNetwork(kind, filt.n_models, normalizer['mean'], normalizer['scale'],
                                config['hidden_size'], config['correction_bound'])
    optimizer = torch.optim.AdamW(network.parameters(), lr=config['learning_rate'], weight_decay=config['weight_decay'])
    name = f'{kind}_{seed}'
    history, best, best_path = [], float('inf'), None
    diagnostics = empty_diagnostics()
    for epoch in range(1, config['epochs'] + 1):
        progress('training', arm=name, epoch=epoch)
        train_loss, train_diag = evidence_epoch(filt, network, windows['training'], snapshots, forcing, observations, config, optimizer)
        selection_loss, selection_diag = evidence_epoch(filt, network, windows['selection'], snapshots, forcing, observations, config)
        merge_diagnostics(diagnostics, train_diag)
        merge_diagnostics(diagnostics, selection_diag)
        record = {'epoch': epoch, 'training_negative_log_evidence': train_loss,
                  'selection_negative_log_evidence': selection_loss}
        path = run_dir / f'checkpoint_{name}_epoch{epoch}.pt'
        torch.save({'state_dict': network.state_dict(), **record}, path)
        history.append({**record, 'checkpoint': path.name})
        write_json(run_dir / f'selection_{name}.json', history)
        if selection_loss < best:
            best, best_path = selection_loss, path
    selected = restore_checkpoint(network, best_path)
    selected['checkpoint'] = best_path.name
    return network, selected, diagnostics


def metrics(prediction, observation, leads):
    if prediction.shape != observation.shape or prediction.ndim != 2 or prediction.shape[1] != len(leads):
        raise ValueError('Prediction/observation must both have shape [origins,leads]')
    if len(prediction) < 2 or not np.isfinite(prediction).all() or not np.isfinite(observation).all():
        raise ValueError('Need at least two finite forecast origins')
    result = {}
    for column, lead in enumerate(leads):
        error = prediction[:, column] - observation[:, column]
        denominator = np.sum((observation[:, column] - observation[:, column].mean()) ** 2)
        result[str(lead)] = {'root_mean_squared_error': float(np.sqrt(np.mean(error ** 2))),
                             'mean_absolute_error': float(np.mean(abs(error))),
                             'nash_sutcliffe_efficiency': float(1 - np.sum(error ** 2) / denominator) if denominator > 0 else None}
    return result


def assess_rule(filt, network, arm, starts, snapshots, forcing, observations, timestamps, config, run_dir):
    operators = ['frozen'] if filt.n_models == 1 else ['frozen', 'evolving']
    predictions = {key: [] for key in operators}
    origins, window_ids = [], []
    diagnostics = empty_diagnostics()
    with torch.no_grad():
        for offset in range(0, len(starts), config['batch_size']):
            group = starts[offset:offset + config['batch_size']]
            args = window_batch(group, snapshots, forcing, observations, config['burn_in'] + config['scored_hours'])
            result = sequential_rollout(filt, network, *args, burn_in=config['burn_in'], capture=True)
            merge_diagnostics(diagnostics, result['diagnostics'])
            for batch, start in enumerate(group):
                for origin in window_origins(timestamps, start, config['burn_in'], config['scored_hours'], config['leads']):
                    step = int(origin - start - config['burn_in'])
                    posterior = result['posteriors'][step]
                    future = forcing[origin + 1:origin + 1 + max(config['leads'])][None]
                    for operator in operators:
                        prediction = forecast_global_state(result['global_states'][step][batch:batch + 1], future,
                                                           filt.candidate_parameters, posterior.probabilities[batch:batch + 1],
                                                           result['transitions'][step][batch:batch + 1], config['leads'],
                                                           evolve=operator == 'evolving')
                        predictions[operator].append(prediction[0].numpy())
                    origins.append(int(origin))
                    window_ids.append(start)
    origins = np.asarray(origins, dtype=np.int64)
    targets = origins[:, None] + np.asarray(config['leads'], dtype=np.int64)[None]
    observed = observations.numpy()[targets]
    arm_metrics = {}
    for operator in operators:
        prediction = np.asarray(predictions[operator], dtype=np.float64)
        arm_metrics[operator] = metrics(prediction, observed, config['leads'])
        np.savez_compressed(run_dir / f'forecast_{arm}_{operator}.npz', prediction=prediction, observation=observed,
                            origin_timestamps=timestamps[origins], target_timestamps=timestamps[targets],
                            leads=np.asarray(config['leads'], dtype=np.int64), origin_indices=origins,
                            window_start_indices=np.asarray(window_ids, dtype=np.int64))
    return arm_metrics, diagnostics


def peak_memory_bytes():
    if os.name == 'nt':
        import ctypes
        from ctypes import wintypes
        class Counters(ctypes.Structure):
            _fields_ = [('cb', wintypes.DWORD), ('PageFaultCount', wintypes.DWORD)] + [
                (name, ctypes.c_size_t) for name in ['PeakWorkingSetSize', 'WorkingSetSize', 'QuotaPeakPagedPoolUsage',
                'QuotaPagedPoolUsage', 'QuotaPeakNonPagedPoolUsage', 'QuotaNonPagedPoolUsage', 'PagefileUsage', 'PeakPagefileUsage']]
        counter = Counters()
        counter.cb = ctypes.sizeof(counter)
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.GetCurrentProcess.restype = wintypes.HANDLE
        psapi = ctypes.WinDLL('psapi', use_last_error=True)
        psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(Counters), wintypes.DWORD]
        if not psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(), ctypes.byref(counter), counter.cb):
            raise ctypes.WinError(ctypes.get_last_error())
        return int(counter.PeakWorkingSetSize)
    import resource
    return int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * (1 if platform.system() == 'Darwin' else 1024))


def run_development(config_path, output_root, run_id, *, mode='development', reference_root=None):
    run_dir = create_run_directory(output_root, run_id)
    started = time.monotonic()
    status = {'run_id': run_id, 'mode': mode, 'status': 'RUNNING', 'started_at': utc_now()}
    def progress(stage, **details):
        status.update(stage=stage, updated_at=utc_now(), elapsed_seconds=time.monotonic() - started, details=details)
        write_json(run_dir / 'status.json', status)
        with (run_dir / 'progress.jsonl').open('a', encoding='utf-8') as handle:
            handle.write(json.dumps(status) + '\n')
    try:
        progress('configuration')
        config = json.loads(Path(config_path).read_text(encoding='utf-8'))
        validate_frozen_config(config)
        if mode not in {'smoke', 'development'}:
            raise ValueError('Only smoke/development modes are supported')
        if reference_root is not None:
            config['reference_root'] = str(Path(reference_root).resolve())
        config['mode'] = mode
        config['computational_overrides'] = {}
        if mode == 'smoke':
            overrides = {'epochs': 1, 'training_windows': 4, 'selection_windows': 2,
                         'assessment_windows': 2, 'burn_in': 24, 'history_seeds': [config['history_seeds'][0]]}
            config.update(overrides)
            config['computational_overrides'] = overrides
        write_json(run_dir / 'config.json', config)
        torch.set_num_threads(1)
        torch.set_default_dtype(torch.float64)
        write_json(run_dir / 'versions.json', {'python': platform.python_version(), 'numpy': np.__version__,
                   'torch': torch.__version__, 'platform': platform.platform(), 'cpu_threads': torch.get_num_threads()})
        progress('loading_original_data')
        timestamps, forcing_array, observation_array, reference, source_paths = load_reference(config['reference_root'])
        own_paths = sorted(Path(__file__).parent.rglob('*.py')) + [Path(config_path)]
        write_json(run_dir / 'hashes.json', {str(path.resolve()): hashlib.sha256(path.read_bytes()).hexdigest()
                   for path in [*source_paths, *own_paths]})
        candidates = [dict(reference, cw=cw) for cw in config['candidate_cw']]
        write_json(run_dir / 'parameters.json', {'candidate_records': candidates, 'calibrated_reference': reference})
        forcing = torch.as_tensor(forcing_array, dtype=torch.float64)
        observations = torch.as_tensor(observation_array, dtype=torch.float64)
        windows = {split: choose_windows(timestamps, config[f'{split}_years'], config[f'{split}_windows'],
                   config['burn_in'], config['scored_hours'], max(config['leads']) if split == 'assessment' else 0,
                   config['window_seed'] + i) for i, split in enumerate(['training', 'selection', 'assessment'])}
        metadata = {split: [{'start_index': s, 'snapshot_after_index': s - 1, 'start_timestamp': str(timestamps[s]),
                     'snapshot_after_timestamp': str(timestamps[s - 1]),
                     'scored_start_timestamp': str(timestamps[s + config['burn_in']]),
                     'scored_end_timestamp': str(timestamps[s + config['burn_in'] + config['scored_hours'] - 1])}
                    for s in starts] for split, starts in windows.items()}
        all_origins = np.concatenate([window_origins(timestamps, s, config['burn_in'], config['scored_hours'], config['leads'])
                                      for s in windows['assessment']])
        counts = {'assessment_origins': len(all_origins), 'unique_assessment_origins': len(np.unique(all_origins)),
                  'scored_hours_per_split': {k: len(v) * config['scored_hours'] for k, v in windows.items()},
                  'burn_in_hours_per_split': {k: len(v) * config['burn_in'] for k, v in windows.items()},
                  'loaded_hours': len(timestamps), 'normalizer_years': [2000, 2001, 2002]}
        if counts['assessment_origins'] != counts['unique_assessment_origins']:
            raise ValueError('Assessment origins must be unique')
        write_json(run_dir / 'windows.json', {'windows': metadata, 'counts': counts})
        # Preserve the source multiplication order, including float64 rounding.
        process = 1e-4 * torch.diag(torch.tensor([140., 1000., 4., 1200., 0.], dtype=torch.float64))
        filt = DifferentiableWalrusIMM(candidates, process, config['observation_variance'], alpha=config['sigma_alpha'],
                                      beta=config['sigma_beta'], kappa=config['sigma_kappa'])
        all_starts = sorted(set(s for values in windows.values() for s in values))
        snapshots, normalizer, fixed_diagnostics = fixed_stream_snapshots(filt, forcing, observations, timestamps,
                                                all_starts, fit_normalizer=True, progress=progress)
        write_json(run_dir / 'normalizer.json', {key: value.tolist() if isinstance(value, torch.Tensor) else value
                                               for key, value in normalizer.items()})
        torch.save({s: {'states': state.states, 'covariances': state.covariances, 'probabilities': state.probabilities,
                        'previous_features': previous} for s, (state, previous) in snapshots.items()}, run_dir / 'fixed_snapshots.pt')
        single = DifferentiableWalrusIMM([reference], process, config['observation_variance'], alpha=config['sigma_alpha'],
                                        beta=config['sigma_beta'], kappa=config['sigma_kappa'])
        single_snapshots, _, single_diagnostics = fixed_stream_snapshots(single, forcing, observations, timestamps,
                                  windows['assessment'], fit_normalizer=False, progress=progress)
        torch.save({s: {'states': state.states, 'covariances': state.covariances, 'probabilities': state.probabilities,
                        'previous_features': previous} for s, (state, previous) in single_snapshots.items()}, run_dir / 'single_snapshots.pt')
        networks = {'fixed': TransitionNetwork('fixed', 5, normalizer['mean'], normalizer['scale'])}
        selected, diagnostics = {}, {'fixed_full_stream': fixed_diagnostics, 'single_full_stream': single_diagnostics}
        write_json(run_dir / 'underflow_diagnostics.json', diagnostics)
        for kind, seeds in [('static', [config['static_seed']]), ('history', config['history_seeds'])]:
            for seed in seeds:
                name = f'{kind}_{seed}'
                networks[name], selected[name], diagnostics[f'{name}_training_selection'] = train_rule(
                    filt, kind, seed, normalizer, windows, snapshots, forcing, observations, config, run_dir, progress)
                write_json(run_dir / 'underflow_diagnostics.json', diagnostics)
                write_json(run_dir / 'selected_checkpoints.json', selected)
        write_json(run_dir / 'selected_checkpoints.json', selected)
        results = {}
        for name, network in networks.items():
            progress('assessment', arm=name)
            results[name], diagnostics[f'{name}_assessment'] = assess_rule(filt, network, name, windows['assessment'],
                                            snapshots, forcing, observations, timestamps, config, run_dir)
            write_json(run_dir / 'underflow_diagnostics.json', diagnostics)
        single_network = TransitionNetwork('fixed', 1, torch.zeros(8), torch.ones(8))
        results['calibrated_single'], diagnostics['single_assessment'] = assess_rule(single, single_network,
            'calibrated_single', windows['assessment'], single_snapshots, forcing, observations, timestamps, config, run_dir)
        history_results = [results[f'history_{seed}'] for seed in config['history_seeds']]
        mean_metrics = {operator: {str(lead): {metric: float(np.mean([item[operator][str(lead)][metric] for item in history_results]))
                        if all(item[operator][str(lead)][metric] is not None for item in history_results) else None
                        for metric in ['root_mean_squared_error', 'mean_absolute_error', 'nash_sutcliffe_efficiency']}
                        for lead in config['leads']} for operator in ['frozen', 'evolving']}
        write_json(run_dir / 'metrics.json', {'arms': results, 'history_mean_of_per_seed_metrics': mean_metrics,
                                             'counts': counts, 'mode': mode})
        write_json(run_dir / 'underflow_diagnostics.json', diagnostics)
        status['status'] = 'COMPLETED'
        status['peak_memory_bytes'] = peak_memory_bytes()
        progress('completed', assessment_origins=counts['assessment_origins'])
    except Exception as exc:
        status['status'] = 'FAILED'
        write_json(run_dir / 'failure.json', {'error_type': type(exc).__name__, 'message': str(exc), 'traceback': traceback.format_exc()})
        status['peak_memory_bytes'] = peak_memory_bytes()
        progress('failed', error=str(exc))
        raise
    finally:
        columns = ['exp_id', 'type', 'hypothesis', 'base_config', 'changed_factor', 'fixed_factors', 'seeds', 'status',
                   'run_dir', 'best_checkpoint', 'metrics_path', 'paper_name', 'notes']
        row = dict(exp_id=run_id, type=mode, hypothesis='causal_history_transition', base_config=str(config_path),
                   changed_factor='transition_rule', fixed_factors='candidate_bank_noise_windows_objective',
                   seeds=';'.join(map(str, [config.get('static_seed'), *config.get('history_seeds', [])])) if 'config' in locals() else '',
                   status=status['status'], run_dir=str(run_dir), best_checkpoint='selected_checkpoints.json',
                   metrics_path='metrics.json', paper_name='', notes='Preliminary development; ideal future forcing; no sealed evidence')
        with (run_dir / 'experiment_registry.csv').open('w', newline='', encoding='utf-8') as handle:
            writer = csv.DictWriter(handle, fieldnames=columns)
            writer.writeheader()
            writer.writerow(row)
    return run_dir
