"""Fully interacting modified unscented filter, with regenerated update points."""
from dataclasses import dataclass
import math

import torch

from .walrus import parameter_tensors, walrus_step


@dataclass(frozen=True)
class FilterState:
    states: torch.Tensor
    covariances: torch.Tensor
    probabilities: torch.Tensor


@dataclass(frozen=True)
class StepResult:
    filter_state: FilterState
    global_state: torch.Tensor
    global_covariance: torch.Tensor
    log_likelihoods: torch.Tensor
    prior_probabilities: torch.Tensor
    log_evidence: torch.Tensor
    diagnostic_innovation: torch.Tensor
    diagnostic_observation_variance: torch.Tensor


class DifferentiableWalrusIMM:
    """Batch five-state filter sharing the reference equations and noise handling.

    candidate_parameters is a mapping of scalars/model vectors or a sequence of
    complete parameter mappings/dataclasses. Noise has shape [models,5,5] or
    [5,5]. Transition matrices have shape [models,models] or [batch,models,models].
    """
    def __init__(self, candidate_parameters, process_covariances, observation_variance,
                 *, alpha=.6874, beta=2., kappa=-2.):
        self.candidate_parameters = candidate_parameters
        self.process_covariances = process_covariances
        self.observation_variance = observation_variance
        self.alpha, self.beta, self.kappa = alpha, beta, kappa
        parameters = parameter_tensors(candidate_parameters, torch.empty((), dtype=torch.float64))
        self.n_models = parameters["cw"].numel()
        self.scale = alpha**2 * (5 + kappa)
        if self.scale <= 0:
            raise ValueError("Sigma-point scale must be positive")

    def initial_state(self, batch_size, *, dtype=torch.float64, device="cpu"):
        x = torch.tensor([140., 1000., 4., 1200., .1], dtype=dtype, device=device)
        covariance = torch.diag((.001 * x)**2)
        return FilterState(x.expand(batch_size, self.n_models, 5).clone(),
                           covariance.expand(batch_size, self.n_models, 5, 5).clone(),
                           torch.full((batch_size, self.n_models), 1 / self.n_models, dtype=dtype, device=device))

    def _weights(self, x):
        mean = x.new_full((11,), 1 / (2 * self.scale))
        mean[0] = (self.scale - 5) / self.scale
        covariance = mean.clone()
        covariance[0] += 1 - self.alpha**2 + self.beta
        return mean, covariance

    def _sigma_points(self, x, covariance):
        covariance = .5 * (covariance + covariance.transpose(-1, -2))
        # Probe without autograd: failed Cholesky factors must not enter backward.
        # Only failed matrices receive the reference's one fallback of 1e-8.
        with torch.no_grad():
            _, info = torch.linalg.cholesky_ex(self.scale * covariance)
        if torch.any(info != 0):
            jitter = (info != 0).to(x.dtype)[..., None, None] * 1e-8 * torch.eye(5, dtype=x.dtype, device=x.device)
            covariance = covariance + jitter
        lower = torch.linalg.cholesky(self.scale * covariance)
        offsets = lower.transpose(-1, -2)
        return torch.cat([x.unsqueeze(-2), x.unsqueeze(-2) + offsets, x.unsqueeze(-2) - offsets], dim=-2)

    def step(self, state, forcing, observation, transition_matrix):
        """Full interaction, modified update, and one global posterior output.

        Outputs: global_state [B,5], global_covariance [B,5,5], per-model
        log_likelihoods/prior_probabilities [B,M], and log_evidence [B].
        """
        x = state.states
        matrix = torch.as_tensor(transition_matrix, dtype=x.dtype, device=x.device)
        forcing = torch.as_tensor(forcing, dtype=x.dtype, device=x.device)
        observation = torch.as_tensor(observation, dtype=x.dtype, device=x.device).reshape(-1, 1)
        incoming = state.probabilities.unsqueeze(-1) * matrix
        prior = incoming.sum(dim=1).clamp_min(1e-300)
        mix = (incoming / prior.unsqueeze(1)).transpose(1, 2)
        mixed = torch.einsum("bji,bid->bjd", mix, x)
        delta = x[:, None] - mixed[:, :, None]
        mixed_cov = torch.einsum("bji,bjide->bjde", mix,
                                 state.covariances[:, None] + delta.unsqueeze(-1) * delta.unsqueeze(-2))
        points = self._sigma_points(mixed, mixed_cov)
        parameters = parameter_tensors(self.candidate_parameters, x)
        parameters = {key: value.unsqueeze(-1) if value.ndim else value for key, value in parameters.items()}
        propagated = walrus_step(points, forcing[:, None, None, :], parameters)
        wm, wc = self._weights(x)
        predicted = torch.einsum("s,bmsd->bmd", wm, propagated)
        delta = propagated - predicted.unsqueeze(-2)
        process = torch.as_tensor(self.process_covariances, dtype=x.dtype, device=x.device)
        predicted_cov = torch.einsum("s,bmsd,bmse->bmde", wc, delta, delta) + process
        # Regeneration incorporates process noise into the measurement update.
        measurement_points = self._sigma_points(predicted, predicted_cov)
        q_points = measurement_points[..., 4]
        q_mean = torch.einsum("s,bms->bm", wm, q_points)
        dq = q_points - q_mean.unsqueeze(-1)
        variance = torch.einsum("s,bms,bms->bm", wc, dq, dq) + torch.as_tensor(
            self.observation_variance, dtype=x.dtype, device=x.device)
        cross = torch.einsum("s,bmsd,bms->bmd", wc, measurement_points - predicted.unsqueeze(-2), dq)
        gain = cross / variance.unsqueeze(-1)
        innovation = observation - q_mean
        updated = predicted + gain * innovation.unsqueeze(-1)
        covariance = predicted_cov - gain.unsqueeze(-1) * variance[..., None, None] * gain.unsqueeze(-2)
        covariance = .5 * (covariance + covariance.transpose(-1, -2))
        log_likelihoods = -.5 * (math.log(2 * math.pi) + variance.log() + innovation**2 / variance)
        # Required log-domain recursion. This agrees with the NumPy likelihood
        # recursion when prior-weighted likelihood products and their normalizing
        # sum are representable and nonzero, but intentionally does
        # not emulate its uniform reset when every likelihood underflows to 0.
        # The real-data parity test explicitly rejects that unverified edge.
        log_joint = prior.log() + log_likelihoods
        probabilities = torch.softmax(log_joint, dim=-1)
        global_state = torch.einsum("bm,bmd->bd", probabilities, updated)
        delta = updated - global_state.unsqueeze(1)
        global_cov = torch.einsum("bm,bmde->bde", probabilities,
                                  covariance + delta.unsqueeze(-1) * delta.unsqueeze(-2))
        return StepResult(FilterState(updated, covariance, probabilities), global_state, global_cov,
                          log_likelihoods, prior, torch.logsumexp(log_joint, dim=-1),
                          innovation.detach(), variance.detach())
