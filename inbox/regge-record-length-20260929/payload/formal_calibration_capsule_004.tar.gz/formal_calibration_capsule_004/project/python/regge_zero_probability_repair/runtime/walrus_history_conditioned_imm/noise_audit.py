"""Independent artifact-only audit: no imports of search/scoring/selection code.

Hashes detect ordinary changes; independent arithmetic, calendar reconstruction,
budget checks and event dependencies also detect changes accompanied by a
rewritten generic artifact hash. This is an integrity audit, not a signature or
an independent rerun of 52,607 filter updates.
"""
from __future__ import annotations

from datetime import datetime, timedelta
import hashlib
import json
from pathlib import Path
import time

import numpy as np


_ARMS = ['original_calibrated_single', 'selected_calibrated_single', 'calibrated_three_noise_imm',
         'original_five_parameter_imm', 'matched_five_parameter_imm',
         'matched_fifteen_full_interaction', 'matched_fifteen_equal_parameter_interaction']
_LOWER = np.array([.00014, .001, .000004, .0012, .00000015])
_UPPER = np.array([1.4, 10., .04, 12., .0015])
_ORIGINAL = np.array([.014, .1, .0004, .12, 0.])
_ROOT = Path('G:/wt/id23-readout')
_SOURCE = Path('G:/github/pycharm/projects/paper-imm-variable-params')
_PARAM = _ROOT / 'results/regge_history_conditioned_imm/20260907-regge-history-development-001/parameters.json'
_LEGACY = _ROOT / '.superpowers/sdd/2026-09-09-regge-full-diagonal-noise-search/legacy-source-hashes.json'


def _sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def _read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def _numbers(value):
    if isinstance(value, list):
        return [_numbers(v) for v in value]
    return np.inf if value is None else value


def _close(actual, expected, label):
    a, b = np.asarray(_numbers(actual)), np.asarray(expected)
    if a.shape != b.shape or not np.allclose(a, b, rtol=2e-12, atol=1e-12, equal_nan=True):
        raise ValueError(f'{label}: numeric values or shape disagree')


def _same(actual, expected, label):
    if not np.array_equal(actual, expected):
        raise ValueError(f'{label}: values disagree')


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _independent_design():
    rng = np.random.default_rng(909001)
    result = np.zeros((128, 5), dtype=np.float64)
    result[0] = _ORIGINAL
    for offset, n, d in [(1, 31, 4), (32, 96, 5)]:
        jitter = rng.random((n, d))
        strata = (np.arange(n)[:, None] + jitter) / n
        for column in range(d):
            permutation = rng.permutation(n)
            strata[:, column] = strata[permutation, column]
        result[offset:offset+n, :d] = np.exp(np.log(_LOWER[:d]) + strata * (np.log(_UPPER[:d])-np.log(_LOWER[:d])))
    return result


def _raw_series(path, count):
    """Read only retained date rows; reconstruct raw dates without source loader."""
    timestamps, values = [], []
    with Path(path).open('r', encoding='utf-8-sig') as stream:
        columns = stream.readline().split()
        for line in stream:
            row = dict(zip(columns, line.split()))
            if not row:
                continue
            date = int(row['date'])
            if date < 1999010101:
                continue
            if date > 2004123123 or len(values) >= count:
                break
            day, hour = str(date)[:-2], int(str(date)[-2:])
            timestamp = datetime.strptime(day, '%Y%m%d') + timedelta(hours=hour)
            timestamps.append(np.datetime64(timestamp, 's').astype(np.int64))
            values.append([float(row[key]) for key in ['P', 'ETpot', 'Q']])
    return np.asarray(timestamps, dtype=np.int64), np.asarray(values, dtype=np.float64)


def _rmse(predictions, targets):
    _require(predictions.ndim == 3 and predictions.shape[1:] == targets.shape and targets.shape[0] > 0,
             'Prediction/target dimensions or empty origin set')
    valid = np.isfinite(predictions).all(axis=(1, 2))
    values = np.full((len(predictions), 4), np.inf)
    for i in np.flatnonzero(valid):
        with np.errstate(over='ignore', invalid='ignore'):
            residual = predictions[i] - targets
            values[i] = np.sqrt(np.sum(residual * residual, axis=0) / len(targets))
        if not np.isfinite(values[i]).all():
            valid[i] = False
            values[i] = np.inf
    return values, valid


def _ratios(values, reference):
    _require(np.isfinite(reference).all() and (reference > 0).all(), 'Reference denominator is not strictly positive finite')
    return np.sum(values / reference, axis=1) / 4.


def _expected_origins(dates, bounds, leads):
    start, stop = bounds
    output = []
    for index in range(start, stop - max(leads)):
        date = dates[index]
        if int(date.astype('datetime64[h]').astype(np.int64)) % 24 != 0:
            continue
        if date.astype('datetime64[Y]') == dates[index + max(leads)].astype('datetime64[Y]'):
            output.append(index)
    return np.asarray(output, dtype=np.int64)


def _forecast_audit(data, forcing, parameter_banks, matrix, leads):
    """Independently advance saved global origins using only the shared physical equations.

    This deliberately does not call forecast_global_state or any runner helper.
    It verifies first future forcing = origin+1, both probability evolutions,
    weighted parameter readout and every saved lead, in bounded origin chunks.
    """
    import torch
    from .walrus import walrus_step
    ids = np.flatnonzero(data['alive'])
    if not len(ids):
        return
    keys = parameter_banks[0][0].keys()
    banks = {key: torch.tensor([[record[key] for record in parameter_banks[i]] for i in ids], dtype=torch.float64)
             for key in keys}
    transition = torch.tensor(matrix, dtype=torch.float64)
    with torch.no_grad():
        for offset in range(0, len(data['origin_indices']), 16):
            columns = np.arange(offset, min(offset+16, len(data['origin_indices'])))
            origins = data['origin_indices'][columns]
            n, c = len(ids), len(columns)
            params = {key: value[:, None, :].expand(-1, c, -1).reshape(n*c, -1) for key, value in banks.items()}
            for form in ['frozen', 'evolving']:
                state = torch.tensor(data['global_states'][ids[:, None], columns].reshape(n*c, 5), dtype=torch.float64)
                p = torch.tensor(data['probabilities'][ids[:, None], columns].reshape(n*c, -1), dtype=torch.float64)
                for lead in range(1, max(leads)+1):
                    if form == 'evolving':
                        p = (p.unsqueeze(1) @ transition).squeeze(1)
                    parameters = {key: torch.sum(p * values, dim=1) for key, values in params.items()}
                    future = torch.tensor(np.broadcast_to(forcing[origins+lead], (n, c, 2)).copy(), dtype=torch.float64).reshape(n*c, 2)
                    state = walrus_step(state, future, parameters)
                    if lead in leads:
                        expected = state[:, 4].reshape(n, c).numpy()
                        _close(data[form][ids[:, None], columns, leads.index(lead)], expected,
                               f'Independent {form} forecast at lead {lead} (forcing origin+lead)')


def _audit_protocol(root, config, design, records, dates, before, after, test_only, preflight):
    _require(before == after, 'Input hashes before/after disagree')
    for path, expected in before.items():
        _require(Path(path).is_file() and _sha(path) == expected, f'Input changed or missing: {path}')
    _require(len(records) == 6, 'Exactly six parameter records required')
    _require(design.shape == (config['budget'], 5), 'Design dimension/budget disagreement')
    _same(design[0], _ORIGINAL, 'Original noise vector')
    _require(np.isfinite(design).all() and (design >= 0).all(), 'Design variances invalid')
    provenance = _read(root / 'design_provenance.json')
    _require(provenance['array_sha256'] == hashlib.sha256(design.tobytes()).hexdigest(), 'Frozen design array hash')
    _require(provenance['shape'] == list(design.shape) and provenance['budget_per_parameter'] == len(design)
             and provenance['parameter_count'] == 6, 'Design provenance dimensions/budget')
    if test_only:
        _require(config['evidence'] == 'synthetic_test_only' and len(dates) <= 1000 and len(design) <= 8,
                 'Synthetic tag or size constraint violated')
        _require(before == {} and after == {}, 'Synthetic test cannot claim production provenance')
        return
    expected = {
        'schema': 'regge_full_diagonal_noise_v01', 'budget': 128, 'seed': 909001,
        'zero_branch_nonoriginal': 31, 'positive_branch': 96,
        'original_diagonal': _ORIGINAL.tolist(), 'lower': _LOWER.tolist(), 'upper': _UPPER.tolist(),
        'observation_variance': 1.5e-5, 'alpha': .6874, 'beta': 2, 'kappa': -2,
        'initial_state': [140, 1000, 4, 1200, .1], 'initial_covariance_fraction': .001,
        'wetness_parameters': [200, 320, 450, 650, 900, 413.6718976768621],
        'warmup_years': [1999], 'training_years': [2000, 2001, 2002],
        'selection_years': [2003], 'assessment_years': [2004],
        'leads': [1, 24, 48, 120], 'shortlist_count': 8, 'keep': 3,
        'transition_diagonal': .99, 'origin_hour': 0, 'origin_stride_hours': 24,
        'forecast_probability_forms': ['frozen', 'evolving'], 'parameter_readout': 'posterior_weighted',
        'selection_score': 'equal_mean_four_rmse_ratios_to_original_calibrated_single',
        'selection_tiebreak': ['selection_score', 'training_score', 'candidate_id'],
        'assessment_arms': _ARMS, 'forecast_chunk_origins': 16, 'progress_filter_hours': 720,
        'torch_threads': 1, 'dtype': 'float64', 'source_root': _SOURCE.as_posix(),
        'parameter_records': _PARAM.as_posix(), 'legacy_manifest': _LEGACY.as_posix(),
        'evidence': 'previously_inspected_development_perfect_forcing',
        'bounds_interpretation': 'prespecified_engineering_bounds_not_true_noise_bounds',
    }
    if preflight:
        expected['mode'] = 'preflight'
    _require(config == expected, 'Production configuration is not the exact independent frozen protocol')
    _same(design, _independent_design(), 'Independent seeded design')
    _require(hashlib.sha256(design.tobytes()).hexdigest() ==
             'e30047bf3fb5b240aaf6ede664e9c89d72257aa1b717cb486de55477d6173d8b', 'Design byte fingerprint')
    for offset, n, d in [(1, 31, 4), (32, 96, 5)]:
        values = design[offset:offset+n, :d]
        _require((values >= _LOWER[:d]).all() and (values <= _UPPER[:d]).all(), 'Variance search bounds')
        unit = (np.log(values)-np.log(_LOWER[:d])) / (np.log(_UPPER[:d])-np.log(_LOWER[:d]))
        for column in range(d):
            _same(np.sort(np.floor(unit[:, column]*n).astype(int)), np.arange(n), 'Latin hypercube strata')
    _same(design[:32, 4], np.zeros(32), 'Zero-discharge branch')
    parameter_source = _read(_PARAM)
    _require(records == parameter_source['candidate_records'] + [parameter_source['calibrated_reference']],
             'Complete parameter records differ from preserved source')
    _same([record['cw'] for record in records], expected['wetness_parameters'], 'Frozen wetness parameters')
    legacy = _read(_LEGACY)
    _require(_read(root / 'legacy_source_hashes.json') == legacy, 'Legacy manifest changed')
    for item in legacy:
        _require(_sha(item['path']) == item['sha256'], f"Legacy code changed: {item['path']}")
    required = [_PARAM, _LEGACY, *(_SOURCE / 'python/imm_da').glob('*.py'),
                *(_ROOT / 'src/walrus_history_conditioned_imm').glob('*.py'),
                _ROOT / 'src/walrus_history_conditioned_imm/scripts/run_noise_search.py']
    for path in required:
        _require(str(path.resolve()) in before, f'Unhashed required input: {path}')
    _require(len(dates) == (256 if preflight else 52607), 'Retained source row budget')


def _phase_audit(root, phase, dates, observations, bounds, leads, labels, events, failures, models):
    with np.load(root / f'{phase}.npz', allow_pickle=False) as npz:
        data = {key: npz[key] for key in npz.files}
    origins = _expected_origins(dates, bounds, leads)
    targets = origins[:, None] + np.asarray(leads)
    _same(data['origin_indices'], origins, f'{phase} all common origins')
    _same(data['target_indices'], targets, f'{phase} target indices origin+lead')
    _same(data['origin_dates'], dates[origins].astype(np.int64), f'{phase} origin dates')
    _same(data['target_dates'], dates[targets].astype(np.int64), f'{phase} target dates')
    _same(data['targets'], observations[targets], f'{phase} target observations')
    _require(data['global_states'].shape == (len(labels), len(origins), 5), f'{phase} complete global state dimensions')
    _require(data['global_covariances'].shape == (len(labels), len(origins), 5, 5), f'{phase} global covariance dimensions')
    _require(data['probabilities'].shape == (len(labels), len(origins), models), f'{phase} probability dimensions')
    _require(_read(root / f'{phase}_members.json') == labels, f'{phase} candidate budget/order')
    phase_failures = [failure for failure in failures if failure['phase'] == phase]
    _require(all(any(all(failure.get(k) == v for k, v in label.items()) for label in labels)
                 for failure in phase_failures), f'{phase} unmapped failure member')
    for i, label in enumerate(labels):
        mine = [failure for failure in phase_failures if all(failure.get(k) == v for k, v in label.items())]
        _require(len(mine) <= 1, f'{phase} invalidated candidate was retried')
        _require(bool(data['alive'][i]) == (not mine), f'{phase} failure/invalidation membership')
        if mine:
            _require(np.isnan(data['frozen'][i]).all() and np.isnan(data['evolving'][i]).all(),
                     f'{phase} failed candidate was not wholly invalidated')
        else:
            _require(np.isfinite(data['global_states'][i]).all() and np.isfinite(data['global_covariances'][i]).all(),
                     f'{phase} finite complete global posterior')
            p = data['probabilities'][i]
            _require(np.isfinite(p).all() and (p >= 0).all(), f'{phase} finite probabilities')
            _close(p.sum(axis=-1), np.ones(len(origins)), f'{phase} probability normalization')
        for failure in mine:
            lower = bounds[0] if phase == 'selection' else 0
            _require(lower <= failure['index'] < bounds[1] and failure['reason'], f'{phase} failure index/reason')
            _require(failure['date'] == str(dates[failure['index']]), f'{phase} failure date')
            _require(failure['stage'] in ['filter', 'forecast'], f'{phase} unknown failure stage')
            if failure['stage'] == 'forecast':
                _require(failure['index'] in origins, f'{phase} failure forecast origin')
    starts = [e for e in events if e['event'] == 'phase_start' and e['phase'] == phase]
    _require(len(starts) == 1, f'{phase} must have one phase start')
    start = starts[0]
    replay_start = bounds[0] if phase == 'selection' else 0
    _require((start['replay_start'], start['replay_stop'], start['score_start'], start['score_stop'],
              start['members'], start['models']) == (replay_start, bounds[1], *bounds, len(labels), models),
             f'{phase} full own-history replay metadata')
    progress = [e['index'] for e in events if e['event'] == 'filter_progress' and e['phase'] == phase]
    expected_progress = list(range(replay_start+719, bounds[1], 720))
    if not expected_progress or expected_progress[-1] != bounds[1]-1:
        expected_progress.append(bounds[1]-1)
    _require(progress == expected_progress, f'{phase} missing chronological filter progress')
    with np.load(root / f'{phase}_start.npz') as initial:
        _require(int(initial['first_index']) == replay_start, f'{phase} first filter index')
        if phase != 'selection':
            x = np.array([140, 1000, 4, 1200, .1])
            _same(initial['states'], np.broadcast_to(x, (len(labels), models, 5)), f'{phase} common initial state')
            _same(initial['covariances'], np.broadcast_to(np.diag((.001*x)**2), (len(labels), models, 5, 5)),
                  f'{phase} common initial covariance')
            _same(initial['probabilities'], np.full((len(labels), models), 1/models), f'{phase} initial probabilities')
    with np.load(root / f'{phase}_end.npz') as end:
        _require(int(end['last_index']) == bounds[1]-1, f'{phase} endpoint date')
    return data


def _ranking_audit(root, phase, data, labels, reference, dates, previous=None):
    metrics = _read(root / f'{phase}_metrics.json')
    rmse, valid = _rmse(data['frozen'], data['targets'])
    scores = _ratios(rmse, rmse[reference])
    _require(metrics['reference_position'] == reference and metrics['origins'] == len(data['origin_indices']),
             f'{phase} reference/origin budget')
    _require(len(metrics['rows']) == len(labels), f'{phase} score row budget')
    for i, (label, row) in enumerate(zip(labels, metrics['rows'])):
        _require(all(row.get(k) == v for k, v in label.items()), f'{phase} score candidate identity')
        _require(row['valid'] == bool(valid[i]), f'{phase} candidate validity')
        _close(row['rmse'], rmse[i], f'{phase} independent RMSE')
        _close(row['score'], scores[i], f'{phase} independent relative score')
    expected_ranks = {}
    for record in range(6):
        candidates = [i for i, label in enumerate(labels) if label['record'] == record]
        candidates.sort(key=lambda i: (scores[i], 0. if previous is None else previous[(record, labels[i]['candidate'])],
                                      labels[i]['candidate']))
        expected_ranks[str(record)] = [labels[i]['candidate'] for i in candidates]
        _require(0 in expected_ranks[str(record)], f'{phase} original candidate absent')
    _require(metrics['rankings'] == expected_ranks, f'{phase} independent ranking')
    years = dates[data['origin_indices']].astype('datetime64[Y]').astype(int) + 1970
    _require(set(metrics['by_year']) == {str(year) for year in np.unique(years)}, f'{phase} year diagnostics')
    for year in np.unique(years):
        selected = years == year
        yearly, _ = _rmse(data['frozen'][:, selected], data['targets'][selected])
        _close(metrics['by_year'][str(year)]['rmse'], yearly, f'{phase} yearly RMSE')
        _close(metrics['by_year'][str(year)]['scores'], _ratios(yearly, yearly[reference]), f'{phase} yearly scores')
        _require(metrics['by_year'][str(year)]['origins'] == int(selected.sum()), f'{phase} yearly origin count')
    _close(data['frozen'], data['evolving'], f'{phase} single-filter probability-form invariance')
    return {(label['record'], label['candidate']): scores[i] for i, label in enumerate(labels)}


def _chronology(root, events, preflight):
    _require([e['sequence'] for e in events] == list(range(1, len(events)+1)), 'Event sequence has gaps/duplicates')
    _require(all(a['elapsed_seconds'] <= b['elapsed_seconds'] for a, b in zip(events, events[1:])), 'Event time decreased')
    snapshots = {}
    for event in events:
        if event['event'] == 'snapshot':
            name = event['file']
            _require(name not in snapshots, f'Snapshot written more than once: {name}')
            _require(_sha(root / name) == event['sha256'], f'Frozen snapshot changed: {name}')
            snapshots[name] = event['sequence']
    starts = [e for e in events if e['event'] == 'phase_start']
    if preflight:
        _require(not starts and not (root / 'selected.json').exists() and not (root / 'shortlist.json').exists(),
                 'Preflight performed scientific selection')
        return
    _require(starts and starts[0]['phase'] == 'training', 'Training must be first')
    for name in ['config.json', 'design.npz', 'design_provenance.json', 'parameters.json', 'series.npz',
                 'input_hashes_before.json', 'registration.json']:
        _require(snapshots[name] < starts[0]['sequence'], f'Input not frozen before scores: {name}')
    selection = [e for e in starts if e['phase'] == 'selection']
    assessment = [e for e in starts if e['phase'].startswith('assessment_')]
    _require(len(selection) == 1 and len(assessment) == 4, 'Missing/extra scientific phases')
    _require(snapshots['training_metrics.json'] < snapshots['shortlist.json'] < selection[0]['sequence'],
             'Shortlist not frozen before selection')
    _require(snapshots['selection_metrics.json'] < snapshots['selected.json'] < snapshots['assessment_arms.json']
             < min(e['sequence'] for e in assessment), 'Selected vectors not frozen before assessment')
    _require(snapshots['training_end.npz'] < snapshots['selection_start.npz'], 'Selection state chronology')


def _audit_preflight(root, dates, forcing, observations, records, design, events, runtime):
    """Validate the actual fixed-size workload, then replay its small numerical prefix."""
    import torch
    from .filter import DifferentiableWalrusIMM

    shapes = {'global_states': (768, 1, 5), 'global_covariances': (768, 1, 5, 5),
              'probabilities': (768, 1, 1), 'frozen': (768, 1, 4), 'evolving': (768, 1, 4), 'alive': (768,)}
    with np.load(root / 'preflight.npz', allow_pickle=False) as archive:
        data = {key: archive[key] for key in archive.files}
    for name, shape in shapes.items():
        _require(name in data and data[name].shape == shape, f'Preflight {name} must have actual shape {shape}')
        _require(np.isfinite(data[name]).all(), f'Preflight nonfinite {name}')
    _require(data['alive'].dtype == np.dtype(bool) and data['alive'].all(), 'Preflight alive must contain 768 true booleans')
    _same(data['probabilities'], np.ones((768, 1, 1)), 'Preflight independent single-filter probabilities')
    _require(len(dates) == 256, 'Preflight requires exactly 256 retained input hours')
    origin = np.array([128], dtype=np.int64)
    leads = [1, 24, 48, 120]
    targets = origin[:, None] + np.asarray(leads)
    metadata = {'origin_indices': origin, 'origin_dates': dates[origin].astype(np.int64),
                'target_indices': targets, 'target_dates': dates[targets].astype(np.int64),
                'filter_start_index': np.array(0), 'filter_stop_index': np.array(129)}
    for name, expected in metadata.items():
        _require(name in data and np.issubdtype(data[name].dtype, np.integer), f'Preflight missing/integer {name}')
        _same(data[name], expected, f'Preflight prescribed {name}')
    _require(runtime['filter_member_hours'] == 768*129, 'Preflight requires 129 updates for each of 768 independent members')
    _require(runtime['forecast_member_origins'] == 768, 'Preflight requires one forecast origin for each of 768 members')
    filter_events = [event for event in events if event['event'] == 'filter_progress']
    forecast_events = [event for event in events if event['event'] == 'forecast_progress']
    _require(len(filter_events) == 1 and len(forecast_events) == 1, 'Preflight requires its exact filter and forecast progress records')
    filtered, forecasted = filter_events[0], forecast_events[0]
    _require(all(filtered.get(key) == value for key, value in
                 dict(phase='preflight', index=128, date=str(dates[128]), alive=768, members=768).items()),
             'Preflight filter progress must end at retained index 128 with all 768 members')
    _require(all(forecasted.get(key) == value for key, value in
                 dict(phase='preflight', completed_origins=1, total_origins=1, alive=768).items()),
             'Preflight forecast progress must complete all 768 member-origins')
    snapshots = {event['file']: event['sequence'] for event in events if event['event'] == 'snapshot'}
    _require(all(snapshots[name] < filtered['sequence'] for name in
                 ['config.json', 'parameters.json', 'design.npz', 'series.npz', 'registration.json']),
             'Preflight inputs were not frozen before filter work')
    _require(filtered['sequence'] < forecasted['sequence'] < snapshots['preflight.npz'] < snapshots['preflight_checks.json'],
             'Preflight numerical work/snapshot order')

    # A valid progress declaration alone does not establish that the updates happened.
    # This small prefix is cheap enough to reconstruct from the unchanged filter core.
    _require(len(records) == 6 and design.shape == (128, 5), 'Preflight parameter/noise member budget')
    parameter_banks = [[record] for record in records for _ in range(128)]
    mappings = {key: torch.tensor([[bank[0][key]] for bank in parameter_banks], dtype=torch.float64)
                for key in records[0]}
    diagonals = torch.tensor(np.tile(design, (6, 1))[:, None, :], dtype=torch.float64)
    engine = DifferentiableWalrusIMM([records[0]], torch.diag_embed(diagonals), 1.5e-5)
    engine.candidate_parameters = mappings
    matrix = torch.ones((1, 1), dtype=torch.float64)
    with torch.no_grad():
        state = engine.initial_state(768)
        for index in range(129):
            result = engine.step(state, np.broadcast_to(forcing[index], (768, 2)).copy(),
                                 np.full(768, observations[index]), matrix)
            state = result.filter_state
        _close(data['global_states'][:, 0], result.global_state.numpy(), 'Preflight independently replayed global state')
        _close(data['global_covariances'][:, 0], result.global_covariance.numpy(), 'Preflight independently replayed global covariance')
        _close(data['probabilities'][:, 0], state.probabilities.numpy(), 'Preflight independently replayed probabilities')
    _forecast_audit(data, forcing, parameter_banks, [[1.]], leads)


def _audit(root):
    manifest = _read(root / 'artifacts.json')
    actual_files = {p.name for p in root.iterdir() if p.is_file()} - {'artifacts.json', 'audit.json'}
    _require(set(manifest) == actual_files, 'Artifact inventory differs from complete manifest')
    for name, expected in manifest.items():
        _require(Path(name).name == name and _sha(root / name) == expected, f'Artifact hash: {name}')
    config = _read(root / 'config.json')
    test_only, preflight = config.get('test_only', False), config.get('mode') == 'preflight'
    runtime = _read(root / 'runtime.json')
    _require(runtime['status'] == ('preflight_complete' if preflight else 'complete'), 'Run incomplete or failed')
    before, after = _read(root / 'input_hashes_before.json'), _read(root / 'input_hashes_after.json')
    records = _read(root / 'parameters.json')
    with np.load(root / 'design.npz') as data:
        design = data['diagonals']
        _same(data['candidate_ids'], np.arange(len(design)), 'Design candidate ids')
    with np.load(root / 'series.npz') as series:
        dates = series['timestamps'].astype('datetime64[s]')
        forcing, observations = series['forcing'], series['observations']
    _require(forcing.shape == (len(dates), 2) and observations.shape == (len(dates),), 'Input series dimensions')
    _require(np.isfinite(forcing).all() and np.isfinite(observations).all(), 'Nonfinite input series')
    _require(np.all(np.diff(dates) == np.timedelta64(3600, 's')), 'Input timestamps are not exactly hourly')
    _audit_protocol(root, config, design, records, dates, before, after, test_only, preflight)
    if not test_only:
        candidates = [path for path in before if Path(path).name == 'PEQ_Regge_hour.txt']
        _require(len(candidates) == 1, 'Missing/ambiguous raw data source')
        _require(Path(candidates[0]).resolve() in [(_SOURCE / 'forecast/data/PEQ_Regge_hour.txt').resolve(),
                                                  (_SOURCE / 'for_submit/forecast/data/PEQ_Regge_hour.txt').resolve()],
                 'Raw source outside the frozen reference root')
        raw_dates, raw = _raw_series(candidates[0], len(dates))
        _same(dates.astype(np.int64), raw_dates, 'Raw retained observation dates')
        _require(np.allclose(forcing, raw[:, :2], atol=1e-10, rtol=0) and
                 np.allclose(observations, raw[:, 2], atol=1e-10, rtol=0), 'Saved data differ from raw source')
        _require(dates[0] == np.datetime64('1999-01-01T01', 's'), 'Source first timestamp')
    registry = _read(root / 'registry.json')
    _require(registry['run_id'] == root.name and Path(registry['run_dir']).resolve() == root.resolve(), 'Unique run registry')
    _require(registry['status'] == runtime['status'], 'Registry final execution status')
    required_registry = ['exp_id', 'type', 'hypothesis', 'base_config', 'changed_factor', 'fixed_factors', 'seeds',
                         'status', 'run_dir', 'best_checkpoint', 'metrics_path', 'paper_name', 'notes']
    _require(all(key in registry for key in required_registry), 'Final registry traceability fields')
    for name in ['config', 'design', 'parameters']:
        suffix = '.npz' if name == 'design' else '.json'
        _require(registry[name + '_sha256'] == _sha(root / (name + suffix)), f'Registry {name} snapshot hash')
    events = [json.loads(line) for line in (root / 'events.jsonl').read_text().splitlines()]
    failures = [json.loads(line) for line in (root / 'failures.jsonl').read_text().splitlines()]
    _chronology(root, events, preflight)
    if preflight:
        _require((dates.astype('datetime64[Y]').astype(int) + 1970 == 1999).all(), 'Preflight used non-1999 inputs')
        checks = _read(root / 'preflight_checks.json')
        _require(checks == dict(finite_states=True, finite_forecasts=True, members=768, selection_performed=False),
                 'Preflight finite/selection checks')
        _require(not failures, 'Preflight had numerical failures')
        _audit_preflight(root, dates, forcing, observations, records, design, events, runtime)
        return dict(evidence='numerical_preflight_only', origins={'preflight': 1}, candidate_failures=0)
    phases = _read(root / 'phases.json')
    if not test_only:
        years = dates.astype('datetime64[Y]').astype(int) + 1970
        for name, expected_years in [('training', [2000, 2001, 2002]), ('selection', [2003]), ('assessment', [2004])]:
            ix = np.flatnonzero(np.isin(years, expected_years))
            _require(phases[name] == [int(ix[0]), int(ix[-1]+1)], f'{name} exact calendar split')
        for year, count in zip(range(2000, 2005), [361, 360, 360, 360, 361]):
            ix = np.flatnonzero(years == year)
            _require(len(_expected_origins(dates, [int(ix[0]), int(ix[-1]+1)], config['leads'])) == count,
                     f'Year {year} complete midnight-origin budget')
    else:
        _require(phases['training'][1] == phases['selection'][0] and phases['selection'][1] == phases['assessment'][0]
                 and phases['assessment'][1] == len(dates), 'Synthetic phase chronology')
    labels = [dict(record=p, candidate=c) for p in range(6) for c in range(len(design))]
    train = _phase_audit(root, 'training', dates, observations, phases['training'], config['leads'], labels,
                         events, failures, 1)
    training = _ranking_audit(root, 'training', train, labels, 5*len(design), dates)
    _forecast_audit(train, forcing, [[records[label['record']]] for label in labels], [[1.]], config['leads'])
    shortlist = _read(root / 'shortlist.json')
    expected_shortlist = {}
    for p in range(6):
        _require(np.isfinite(training[(p, 0)]), 'Original training candidate invalid')
        ranked = sorted([c for c in range(1, len(design)) if np.isfinite(training[(p, c)])],
                        key=lambda c: (training[(p, c)], c))
        expected_shortlist[str(p)] = [0] + ranked[:config['shortlist_count']-1]
        _require(len(expected_shortlist[str(p)]) == config['shortlist_count'], 'Insufficient training candidates')
    _require(shortlist == expected_shortlist, 'Shortlist does not match train-only independent ranking')
    short_labels = [dict(record=p, candidate=c) for p in range(6) for c in shortlist[str(p)]]
    positions = [p*len(design)+c for p in range(6) for c in shortlist[str(p)]]
    with np.load(root / 'training_end.npz') as end, np.load(root / 'selection_start.npz') as start:
        _same(start['training_positions'], positions, 'Selection continuation identities')
        for name in ['states', 'covariances', 'probabilities']:
            _same(start[name], end[name][positions], f'Selection continues own end-2002 {name}')
    selection_data = _phase_audit(root, 'selection', dates, observations, phases['selection'], config['leads'],
                                 short_labels, events, failures, 1)
    reference = short_labels.index(dict(record=5, candidate=0))
    selection = _ranking_audit(root, 'selection', selection_data, short_labels, reference, dates, training)
    _forecast_audit(selection_data, forcing, [[records[label['record']]] for label in short_labels], [[1.]], config['leads'])
    selected = _read(root / 'selected.json')
    expected_selected = {}
    for p in range(6):
        _require(np.isfinite(selection[(p, 0)]), 'Original selection candidate invalid')
        valid = [c for c in shortlist[str(p)] if np.isfinite(selection[(p, c)])]
        valid.sort(key=lambda c: (selection[(p, c)], training[(p, c)], c))
        _require(len(valid) >= 3, 'Insufficient valid selection candidates')
        expected_selected[str(p)] = valid[:3]
    _require(selected == expected_selected, 'Selected vectors differ from selection-only independent ranking')
    expected_pairs = [[(5, 0)], [(5, selected['5'][0])], [(5, c) for c in selected['5']],
                      [(p, 0) for p in range(5)], [(p, selected[str(p)][0]) for p in range(5)],
                      [(p, c) for p in range(5) for c in selected[str(p)]],
                      [(p, c) for p in range(5) for c in selected[str(p)]]]
    arms = _read(root / 'assessment_arms.json')
    _require([arm['name'] for arm in arms] == _ARMS, 'Frozen assessment arm order/count')
    for i, (arm, pairs) in enumerate(zip(arms, expected_pairs)):
        _require(arm['members'] == [dict(record=p, candidate=c) for p, c in pairs], 'Assessment selected member provenance')
        _require(arm['parameters'] == [records[p] for p, _ in pairs], 'Assessment complete parameter records')
        _same(arm['diagonals'], [design[c] for _, c in pairs], 'Assessment selected noise vectors')
        groups = [p for p, _ in pairs] if i == 6 else None
        _require(arm['interaction_groups'] == groups, 'Assessment state-interaction groups')
        n = len(pairs)
        matrix = np.ones((1, 1)) if n == 1 else np.full((n, n), .01/(n-1))
        if n > 1:
            np.fill_diagonal(matrix, .99)
        _same(arm['transition_matrix'], matrix, 'Frozen transition matrix')
    arm_results = {}
    for models in [1, 3, 5, 15]:
        group = [arm for arm in arms if len(arm['members']) == models]
        data = _phase_audit(root, f'assessment_m{models}', dates, observations, phases['assessment'], config['leads'],
                            [dict(arm=arm['name']) for arm in group], events, failures, models)
        _forecast_audit(data, forcing, [arm['parameters'] for arm in group], group[0]['transition_matrix'], config['leads'])
        for i, arm in enumerate(group):
            arm_results[arm['name']] = {form: _rmse(data[form][i:i+1], data['targets']) for form in ['frozen', 'evolving']}
        if models in [1, 3]:
            _close(data['frozen'], data['evolving'], 'Identical hydrological parameters probability-form invariance')
    metrics = _read(root / 'assessment_metrics.json')
    _require(set(metrics['probability_forms']) == {'frozen', 'evolving'}, 'Both assessment probability forms required')
    for form in ['frozen', 'evolving']:
        _require(list(metrics['probability_forms'][form]) == _ARMS, 'Assessment metrics arm coverage/order')
        reference = arm_results[_ARMS[0]][form][0][0]
        for name in _ARMS:
            rmse, valid = arm_results[name][form]
            row = metrics['probability_forms'][form][name]
            _close(row['rmse'], rmse[0], 'Assessment independent RMSE')
            _close(row['score'], _ratios(rmse, reference)[0], 'Assessment independent score')
            _require(row['valid'] == bool(valid[0]), 'Assessment invalid candidate status')
    _require(metrics['by_year'] == {'synthetic' if test_only else '2004': metrics['probability_forms']},
             'Assessment phase-by-year metrics')
    allowed_phases = {'training', 'selection', 'assessment_m1', 'assessment_m3', 'assessment_m5', 'assessment_m15'}
    _require(all(f['phase'] in allowed_phases for f in failures), 'Unmapped candidate failure')
    return dict(evidence=config['evidence'], origins={name: len(_expected_origins(dates, bounds, config['leads']))
                                                    for name, bounds in phases.items()}, candidate_failures=len(failures))


def audit_noise_run(run_dir):
    """Return an explicit failure report for missing/corrupt/semantically invalid artifacts."""
    import torch
    root = Path(run_dir).resolve()
    old_threads = torch.get_num_threads()
    started = time.perf_counter()
    try:
        torch.set_num_threads(1)
        details = _audit(root)
        return dict(passed=True, errors=[], audit_elapsed_seconds=time.perf_counter()-started,
                    audit_torch_threads=1, **details)
    except Exception as error:
        return dict(passed=False, errors=[f'{type(error).__name__}: {error}'], evidence='unverified',
                    audit_elapsed_seconds=time.perf_counter()-started, audit_torch_threads=1)
    finally:
        torch.set_num_threads(old_threads)
