"""Independent analytic likelihood arithmetic around the unchanged original filters."""
import numpy as np

from . import short_record_audit as audit


def _vector(value, label):
    value = np.asarray(value, dtype=float)
    audit._require(value.ndim == 1 and value.size > 0 and np.isfinite(value).all(), label)
    return value


def _prior(value):
    value = _vector(value, 'reference prior shape/nonfinite')
    audit._require((value > 0).all() and abs(value.sum()-1.) <= 1e-12, 'reference prior nonpositive/unnormalized')
    return value


def log_gaussian_scalar(innovation, variance):
    innovation, variance = np.asarray(innovation, dtype=float), np.asarray(variance, dtype=float)
    audit._require(innovation.ndim == variance.ndim == 0 and np.isfinite(innovation) and
                   np.isfinite(variance) and variance > 0, 'reference scalar Gaussian input')
    with np.errstate(over='ignore', invalid='ignore', divide='ignore'):
        value = -.5*(np.log(2.*np.pi)+np.log(variance)+innovation*innovation/variance)
    audit._require(np.isfinite(value), 'reference analytic log likelihood nonfinite')
    return float(value)


def normalize_log_weights(log_likelihoods, prior):
    logs, prior = _vector(log_likelihoods, 'reference log likelihood shape/nonfinite'), _prior(prior)
    audit._require(logs.shape == prior.shape, 'reference log/prior shape')
    weights = logs + np.log(prior)
    audit._require(np.isfinite(weights).all(), 'reference log weights nonfinite')
    maximum = np.max(weights)
    with np.errstate(under='ignore', over='ignore'):
        shifted = weights-maximum
        audit._require(np.isfinite(shifted).all(), 'reference shifted log weights nonfinite')
        scaled = np.exp(shifted)
    total = scaled.sum()
    audit._require(np.isfinite(total) and total > 0, 'reference log normalization')
    posterior, mass = scaled/total, maximum+np.log(total)
    audit._require(np.isfinite(posterior).all() and np.isfinite(mass), 'reference log posterior nonfinite')
    return posterior, float(mass)


def reference_update_log(estimator, observation, reference, reached=None):
    """Advance original members once; never call the original uniform fallback."""
    incoming = _vector(estimator.mu, 'reference incoming posterior shape/nonfinite')
    audit._require((incoming >= 0).all() and abs(incoming.sum()-1.) <= 1e-12,
                   'reference incoming posterior negative/unnormalized')
    prior = _prior(estimator.Pi.T @ incoming)
    values = dict(prior_probabilities=prior.copy())
    if reached is not None:
        reached(values)
    # Validate before the original interaction routine's denominator floor.
    groups = estimator.state_interaction_groups
    if groups is not None:
        for j in range(estimator.n_models):
            audit._require(np.sum(incoming[groups == groups[j]]*estimator.Pi[groups == groups[j], j]) > 0,
                           'reference state-interaction group zero incoming probability')
    mixed_x, mixed_p = estimator._interaction_step()
    logs = np.full(estimator.n_models, np.nan)
    states = np.full((estimator.n_models, *estimator.filters[0].x.shape), np.nan)
    covariances = np.full((estimator.n_models, *estimator.filters[0].P.shape), np.nan)
    for j, model in enumerate(estimator.filters):
        model.x, model.P = mixed_x[j].copy(), mixed_p[j].copy()
        try:
            model.predict_update(observation)
            states[j], covariances[j] = model.x, model.P
            audit._require(np.isfinite(states[j]).all() and np.isfinite(covariances[j]).all(), 'reference nonfinite member')
            points = model.sigma_gen.sigma_points(model._x_pred, model._P_pred)
            transformed = np.array([model.hx(point) for point in points]).reshape(len(points), 1)
            mean, covariance = reference[2].unscented_transform(transformed, model.sigma_gen.Wm,
                model.sigma_gen.Wc, np.array([[model.R]]))
            logs[j] = log_gaussian_scalar(float(np.asarray(observation)-mean[0]), covariance[0, 0])
        finally:
            states[j], covariances[j] = model.x, model.P
            if reached is not None:
                reached(dict(member_states=states.copy(), member_covariances=covariances.copy(), log_likelihoods=logs.copy()))
    posterior, log_mass = normalize_log_weights(logs, prior)
    with np.errstate(under='ignore', over='ignore'):
        likelihoods, mass = np.exp(logs), np.exp(log_mass)
    audit._require(np.isfinite(likelihoods).all() and np.isfinite(mass), 'reference diagnostic likelihood overflow')
    estimator.mu = posterior
    estimator._combination_step()
    estimator.mu_history.append(estimator.mu.copy())
    values.update(member_states=states, member_covariances=covariances, global_states=estimator.x.copy(),
        global_covariances=estimator.P.copy(), probabilities=posterior.copy(), log_likelihoods=logs,
        log_normalization_mass=np.asarray(log_mass), likelihoods=likelihoods, normalization_mass=np.asarray(mass))
    if reached is not None:
        reached(values)
    audit._require(all(np.isfinite(value).all() for value in values.values()), 'reference nonfinite combined update')
    return values
