"""Read-only source loading and calendar-contained deterministic window selection."""
from dataclasses import asdict
from pathlib import Path
import importlib
import sys

import numpy as np


def validate_series(timestamps, forcing, observations):
    if forcing.shape != (len(timestamps), 2) or observations.shape != (len(timestamps),):
        raise ValueError('Unexpected forcing/observation shape')
    if len(timestamps) < 2 or np.isnat(timestamps).any():
        raise ValueError('Missing or invalid dates')
    if not np.isfinite(forcing).all() or not np.isfinite(observations).all():
        raise ValueError('Data must be finite')
    if not np.all(np.diff(timestamps).astype('timedelta64[s]') == np.timedelta64(3600, 's')):
        raise ValueError('Data must have exact one-hour spacing')
    years = timestamps.astype('datetime64[Y]').astype(int) + 1970
    if years.min() < 1999 or years.max() > 2004:
        raise ValueError('Only years 1999 through 2004 are permitted')


def load_reference(root):
    root = Path(root).resolve()
    sys.path.insert(0, str(root / 'python'))
    loader = importlib.import_module('imm_da.data_loader')
    walrus = importlib.import_module('imm_da.walrus')
    for module in [loader, walrus]:
        if root not in Path(module.__file__).resolve().parents:
            raise RuntimeError('An already imported reference module comes from a different root')
    data_path = root / 'forecast/data/PEQ_Regge_hour.txt'
    if not data_path.exists():
        data_path = root / 'for_submit/forecast/data/PEQ_Regge_hour.txt'
    raw = loader.load_peq_data(str(data_path), 1999010101, 2004123123)
    if raw.empty or not np.isfinite(raw.to_numpy(dtype=float)).all():
        raise ValueError('Reject missing/nonfinite raw values before original preprocessing')
    cumulative, p, et, q = loader.load_and_preprocess(str(data_path), 1999010101, 2004123123)
    dates = cumulative.output_date[:-1].astype('datetime64[s]')
    forcing = np.stack([p, et], axis=-1)
    validate_series(dates, forcing, q)
    for actual, column in [(p, 'P'), (et, 'ETpot'), (q, 'Q')]:
        if not np.allclose(actual, raw[column].to_numpy(), atol=1e-10, rtol=0):
            raise ValueError('Original preprocessing does not match same-index raw values')
    parameters = asdict(walrus.get_default_params('regge_fixed_tm_step_cw_cg_cq'))
    source_paths = sorted((root / 'python/imm_da').glob('*.py'))
    return dates, forcing, q, parameters, [data_path, *source_paths]


def choose_windows(timestamps, years, count, burn_in, scored_hours, forecast_hours, seed):
    """Select nonoverlapping complete blocks, including assessment forecast tails."""
    year_array = timestamps.astype('datetime64[Y]').astype(int) + 1970
    hours = timestamps.astype('datetime64[h]').astype(np.int64)
    length = burn_in + scored_hours + forecast_hours
    candidates = [i for i in range(1, len(timestamps) - length + 1)
                  if hours[i] % 24 == 0 and year_array[i] in years
                  and year_array[i + length - 1] == year_array[i]]
    rng = np.random.default_rng(seed)
    chosen = []
    for start in rng.permutation(candidates):
        start = int(start)
        if all(abs(start - old) >= length for old in chosen):
            chosen.append(start)
        if len(chosen) == count:
            return sorted(chosen)
    raise ValueError(f'Cannot choose {count} disjoint year-contained windows')


def window_origins(timestamps, start, burn_in, scored_hours, leads):
    indices = np.arange(start + burn_in, start + burn_in + scored_hours)
    indices = indices[timestamps[indices].astype('datetime64[h]').astype(np.int64) % 24 == 0]
    if len(indices):
        targets = indices[:, None] + np.asarray(leads)[None, :]
        if targets.max() >= len(timestamps):
            raise ValueError('Forecast target outside available data')
        if not np.all(timestamps[targets].astype('datetime64[Y]') == timestamps[indices, None].astype('datetime64[Y]')):
            raise ValueError('Forecast targets cross calendar year')
    return indices
