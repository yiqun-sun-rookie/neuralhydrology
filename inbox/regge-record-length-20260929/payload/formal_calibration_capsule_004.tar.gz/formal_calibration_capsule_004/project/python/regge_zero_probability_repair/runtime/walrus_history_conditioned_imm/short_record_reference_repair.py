"""Exclusive repair-only preflight and read-only saved-evidence audit.

No entry in this module can dispatch calibration or produce eligible evidence.
"""
from pathlib import Path
from datetime import datetime
import json
import re
import time
import zipfile

import numpy as np

from . import short_record_audit as audit
from . import short_record_experiment as writer
from .data import load_reference, validate_series
from .short_record_contract import validate_config, validate_fixed_field_provenance

OUTPUT_ROOT = writer.WORKTREE / 'results/regge_short_record_reference_repair'
DEFAULT_CONFIG = writer.PACKAGE / 'configs/regge_short_record_v01.json'
CONFIG_HASH = '5f175b2f09613b2090c379f57378cffd84daffb46d2a26b95fa3ec4bb2b1de0c'
PREDECESSOR = writer.WORKTREE / 'results/regge_short_record_calibration/20260915-regge-short-record-preflight-001'
PREDECESSOR_RECEIPT_HASH = 'fad84557a5297e1ba79acb6397fa68c2014f55addbe467ef4dbc95a8941a3a51'
PREDECESSOR_MANIFEST_HASH = '1bc8dc22300c77f1757a004d7ef61ae6701fe8cf9c0854b26d59d2d1ce72c4f4'
ARITHMETIC = 'independent_log'


def _predecessor():
    audit._require(audit._hash(PREDECESSOR/'receipt.json') == PREDECESSOR_RECEIPT_HASH and
                   audit._hash(PREDECESSOR/'manifest.json') == PREDECESSOR_MANIFEST_HASH, 'pinned predecessor identity')
    audit._manifest(PREDECESSOR.resolve())
    receipt = audit._json(PREDECESSOR/'receipt.json')
    audit._require(receipt.get('mode') == 'preflight' and receipt.get('status') == 'failed' and receipt.get('passed') is False,
                   'predecessor must be failed original preflight')
    return dict(path=str(PREDECESSOR.resolve()), receipt_sha256=PREDECESSOR_RECEIPT_HASH,
                manifest_sha256=PREDECESSOR_MANIFEST_HASH)


def _protocol(config):
    return dict(schema='regge_short_record_reference_repair_protocol_v01', base_config_sha256=CONFIG_HASH,
        predecessor=_predecessor(), reference_arithmetic=ARITHMETIC, preflight_contract=config['preflight'],
        formal_execution_authorized=False,
        arithmetic_provenance='Original interaction/member predict_update/combination; independent analytic scalar Gaussian and max-shift log normalization; exponentiated diagnostics may underflow to zero; no floor, epsilon, clipping or uniform fallback')


def _target(output_root, run_id):
    audit._require(isinstance(run_id,str) and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*',run_id) is not None
                   and not run_id.endswith('.'), 'run_id must be one safe component')
    audit._require(run_id.split('.')[0].upper() not in {'CON','PRN','AUX','NUL',*[f'COM{i}' for i in range(1,10)],
        *[f'LPT{i}' for i in range(1,10)]}, 'run_id must not be a reserved device')
    root = Path(output_root)
    audit._require(root.absolute() == OUTPUT_ROOT.absolute() and root.resolve() == OUTPUT_ROOT.absolute(), 'repair output family/path escape')
    for part in (root, *root.parents):
        audit._require(not part.is_symlink() and not (hasattr(part,'is_junction') and part.is_junction()), 'repair symlink/path escape')
    target = root/run_id
    audit._require(target.resolve().parent == root.resolve() and not target.exists() and not target.is_symlink(), 'repair target exists or escapes')
    return target


def _finalize(art, status, binding, error=None):
    art.json('runtime.json', dict(elapsed_seconds=time.perf_counter()-art.started,
        observed_execution_settings=getattr(art,'execution_threads',None), restored_finalization_settings=writer._thread_settings(),
        peak_sampled_rss_bytes=art.peak_rss or None, memory_measurement_kind='sampled_process_rss',
        continuous_monitoring=False))
    art.json('receipt.json', dict(schema='regge_short_record_reference_repair_receipt_v01',
        mode='reference_repair_preflight', status=status, passed=status=='reference_repair_complete',
        scientific_binding_eligible=False, test_only=art.test_only, reference_arithmetic=ARITHMETIC,
        error=error, binding=binding))
    files={path.relative_to(art.root).as_posix():audit._hash(path) for path in sorted(art.root.rglob('*')) if path.is_file()}
    art.json('manifest.json',dict(schema='regge_short_record_manifest_v01', excluded=['manifest.json','audit.json'], files=files))


def run_reference_repair(config_path, output_root, run_id):
    target = _target(output_root, run_id)
    config_path = Path(config_path).resolve()
    audit._require(audit._hash(config_path)==CONFIG_HASH, 'repair frozen config hash')
    config = audit._json(config_path)
    validate_config(config); validate_fixed_field_provenance(config)
    protocol = _protocol(config)
    art = writer._Artifacts(target, test_only=False)
    before, binding = {}, None
    try:
        sources = [config_path, *sorted(writer.PACKAGE.glob('*.py')),
            *sorted((writer.PACKAGE/'scripts').glob('*.py')),
            *sorted((writer.REFERENCE_ROOT/'python/imm_da').glob('*.py'))]
        before = writer._persist_snapshot(art,sources)
        binding = writer._binding(audit._hash(config_path),before)
        art.json('config.json',config); art.json('repair_protocol.json',protocol)
        art.json('provenance_before_load.json',before)
        dates, weather, flows, _, _ = load_reference(writer.REFERENCE_ROOT)
        validate_series(dates,weather,flows)
        expected = np.arange(np.datetime64(config['data_start'],'h'),np.datetime64(config['data_stop'],'h'))
        audit._same(np.asarray(dates).astype('datetime64[h]'),expected,'repair full frozen input axis')
        art.npz('inputs.npz',dict(timestamps=dates,forcing=weather,observations=flows))
        art.event('reference_repair_started', reference_arithmetic=ARITHMETIC)
        with writer._one_thread() as settings:
            art.execution_threads = settings
            result = audit.numerical_preflight(config,dates,weather,flows,writer.REFERENCE_ROOT,art.event,
                reference_arithmetic=ARITHMETIC)
            art.npz('preflight/arrays.npz',result['arrays'])
            art.json('preflight/checks.json',result['checks']); art.json('preflight/runtime.json',result['runtime'])
            if not result['passed']:
                raise RuntimeError('reference repair numerical preflight failed: '+str(result['checks'].get('stop_reason')))
        after = {path:audit._hash(path) if Path(path).is_file() else None for path in before}
        art.json('input_hashes_after.json',after)
        audit._require(before==after, 'repair source/config changed during execution')
        art.event('reference_repair_complete')
        _finalize(art,'reference_repair_complete',binding)
    except BaseException as error:
        if not (art.root/'input_hashes_after.json').exists():
            art.json('input_hashes_after.json',{path:audit._hash(path) if Path(path).is_file() else None for path in before})
        art.event('reference_repair_failed',error=f'{type(error).__name__}: {error}')
        if not (art.root/'receipt.json').exists():
            _finalize(art,'failed',binding,f'{type(error).__name__}: {error}')
        raise
    return dict(run_dir=str(art.root),status='reference_repair_complete',passed=True,scientific_binding_eligible=False)


def audit_reference_repair_run(run_dir):
    """Read and independently check evidence; no model or data loader is called."""
    root = Path(run_dir).resolve()
    try:
        files = audit._manifest(root)
        required = {'config.json','repair_protocol.json','inputs.npz','provenance_before_load.json',
            'input_hashes_after.json','source_snapshot/index.json','preflight/arrays.npz',
            'preflight/checks.json','preflight/runtime.json','runtime.json','events.jsonl',
            'failures.jsonl','receipt.json'}
        audit._require(required.issubset(files), 'repair mandatory artifact set incomplete')
        receipt = audit._json(root/'receipt.json')
        audit._require(receipt.get('schema')=='regge_short_record_reference_repair_receipt_v01' and
            receipt.get('mode')=='reference_repair_preflight' and receipt.get('reference_arithmetic')==ARITHMETIC and
            receipt.get('scientific_binding_eligible') is False and receipt.get('test_only') is False, 'repair receipt identity')
        audit._require(receipt.get('status')=='reference_repair_complete' and receipt.get('passed') is True, 'failed/incomplete repair receipt')
        _audit_execution_evidence(root)
        config = audit._json(root/'config.json'); validate_config(config); validate_fixed_field_provenance(config)
        audit._require(receipt['binding']['config_sha256']==CONFIG_HASH, 'repair config identity')
        audit._require(audit._json(root/'repair_protocol.json')==_protocol(config), 'repair protocol identity')
        checks = audit._json(root/'preflight/checks.json')
        audit._require(checks.get('reference_arithmetic')==ARITHMETIC, 'repair check arithmetic')
        with np.load(root/'inputs.npz',allow_pickle=False) as inputs:
            validate_series(inputs['timestamps'],inputs['forcing'],inputs['observations'])
            expected = np.arange(np.datetime64(config['data_start'],'h'),np.datetime64(config['data_stop'],'h'))
            audit._same(inputs['timestamps'].astype('datetime64[h]'),expected,'repair saved input axis')
            evidence=audit._preflight_saved_evidence(root,receipt,config,inputs,reference_arithmetic=ARITHMETIC)
        return dict(passed=True,status='reference_repair_complete',scientific_binding_eligible=False,**evidence)
    except (ValueError,KeyError,OSError,TypeError,zipfile.BadZipFile,EOFError) as error:
        return dict(passed=False,status='failed_or_incomplete_repair',scientific_binding_eligible=False,error=f'{type(error).__name__}: {error}')


def _audit_execution_evidence(root):
    """Require the writer's observed runtime labels and complete success chronology."""
    runtime = audit._json(root/'runtime.json')
    audit._require(isinstance(runtime,dict), 'repair runtime object')
    for label in ('elapsed_seconds','peak_sampled_rss_bytes'):
        value = runtime.get(label)
        audit._require(type(value) in (int,float) and np.isfinite(value) and value>0, 'repair runtime '+label)
    audit._require(runtime.get('memory_measurement_kind')=='sampled_process_rss' and
                   runtime.get('continuous_monitoring') is False, 'repair runtime observation labels')
    for label in ('observed_execution_settings','restored_finalization_settings'):
        settings = runtime.get(label)
        audit._require(isinstance(settings,dict), 'repair runtime '+label)
        count = settings.get('torch_threads')
        audit._require(type(count) is int and count>0, 'repair runtime torch threads')
        pools = settings.get('loaded_threadpools')
        audit._require(isinstance(pools,list), 'repair runtime loaded threadpools')
        if label=='observed_execution_settings':
            audit._require(count==1, 'repair observed execution must be one thread')
        for pool in pools:
            audit._require(isinstance(pool,dict) and type(pool.get('num_threads')) is int and pool['num_threads']>0,
                           'repair runtime threadpool count')
            if label=='observed_execution_settings':
                audit._require(pool['num_threads']==1, 'repair observed threadpool must be one thread')
    events = [json.loads(line) for line in (root/'events.jsonl').read_text(encoding='utf-8').splitlines()]
    audit._require(len(events)==len(audit.METHODS)+2 and all(isinstance(row,dict) for row in events),
                   'repair successful event count')
    for sequence,row in enumerate(events,1):
        audit._require(type(row.get('sequence')) is int and row['sequence']==sequence, 'repair event sequence')
        stamp = datetime.fromisoformat(row['utc'])
        audit._require(stamp.tzinfo is not None and stamp.utcoffset().total_seconds()==0, 'repair event UTC')
    audit._require(events[0].get('event')=='reference_repair_started' and
                   events[0].get('reference_arithmetic')==ARITHMETIC, 'repair start event')
    for row,method in zip(events[1:-1],audit.METHODS):
        audit._require(row.get('event')=='numerical_preflight_method_complete' and row.get('method')==method
            and type(row.get('updates')) is int and row['updates']==129
            and type(row.get('forecast_hours')) is int and row['forecast_hours']==120, 'repair method event')
    audit._require(events[-1].get('event')=='reference_repair_complete', 'repair complete event')
    audit._require((root/'failures.jsonl').read_text(encoding='utf-8')=='', 'successful repair contains failure records')
