"""Exclusive, chronological runner for the frozen Regge short-record study.

Importing this module performs no work.  Production and explicitly synthetic
test orchestration share artifact/chronology gates, but synthetic receipts are
permanently ineligible to authorize a formal run.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import shutil
import time

import numpy as np
import torch

from .data import load_reference, validate_series
from .filter import FilterState
from .noise_filter import BatchedNoiseFilters
from .short_record_calibration import (ForecastNumericalFailure, NumericalFailure,
                                       calibrate_window, checked_deterministic_forecasts,
                                       isolated_filter_step)
from .short_record_contract import (build_assessment_arms, calibration_windows,
                                    complete_origins, information_slices,
                                    validate_config, validate_fixed_field_provenance)


WORKTREE = Path("G:/wt/id23-readout")
REFERENCE_ROOT = Path("G:/github/pycharm/projects/paper-imm-variable-params")
PACKAGE = Path(__file__).resolve().parent
STATIC_RESOURCES = {
    "hydrologic_prediction_float64_bytes": 969670656,
    "calibration_four_lead_prediction_float64_bytes": 159645696,
    "assessment_two_form_prediction_float64_bytes": 20755200,
    "complete_calibration_numeric_arrays_bytes": 1521716736,
    # Included in the complete payload above, not added twice by the disk gate.
    "calibration_progress_arrays_per_window_bytes": 600064,
    "calibration_progress_arrays_all_windows_bytes": 3600384,
    "assessment_arm_numeric_arrays_bytes": 94453456,
    "assessment_shared_numeric_arrays_bytes": 4168336,
    "frozen_input_numeric_arrays_bytes": 1683424,
    "largest_hydrologic_array_bytes": 287440896,
    "warmup_steps_without_cache": 142362,
    "warmup_plus_calibration_candidate_steps": 412766208,
    "joint_filter_member_hours": 121208832,
    "calibration_forecast_origins": 4988928,
    "calibration_forecast_hydrologic_steps": 598671360,
}


def _hash(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _jsonable(value):
    if isinstance(value, dict): return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)): return [_jsonable(v) for v in value]
    if isinstance(value, np.ndarray): return _jsonable(value.tolist())
    if isinstance(value, np.generic): return _jsonable(value.item())
    if isinstance(value, float) and not np.isfinite(value): return None
    return value


class _Artifacts:
    def __init__(self, root, *, test_only=False):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=False)
        self.test_only, self.sequence, self.started, self.peak_rss = test_only, 0, time.perf_counter(), 0
        (self.root / "events.jsonl").touch(exist_ok=False)
        (self.root / "failures.jsonl").touch(exist_ok=False)

    def event(self, event, **fields):
        self.sequence += 1
        row = dict(sequence=self.sequence, event=event, utc=datetime.now(timezone.utc).isoformat(), **fields)
        with (self.root / "events.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(_jsonable(row), allow_nan=False) + "\n")
        try:
            import psutil
            self.peak_rss = max(self.peak_rss, psutil.Process().memory_info().rss)
        except ImportError:
            pass

    def json(self, relative, value):
        path = self.root / relative; path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("x", encoding="utf-8") as stream:
            json.dump(_jsonable(value), stream, indent=2, allow_nan=False); stream.write("\n")

    def npz(self, relative, values):
        path = self.root / relative; path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as stream: np.savez(stream, **values)

    def calibration(self, key, result):
        base = Path("calibration") / key
        self.npz(base / "raw.npz", {k: v for k, v in result.get("raw", {}).items() if isinstance(v, np.ndarray)})
        self.json(base / "result.json", {k: v for k, v in result.items() if k != "raw"})

    def assessment(self, key, result):
        base = Path("assessment") / key
        arrays, metadata = {}, {}
        for name, value in result.items():
            if isinstance(value, np.ndarray):
                arrays[name] = value
            elif name == "arms":
                metadata[name] = []
                for rank, arm in enumerate(value):
                    arm_name = arm["arm"]["name"]
                    prefix = f"arm_{rank:02d}__{arm_name}"
                    for field, field_value in arm.items():
                        if isinstance(field_value, np.ndarray): arrays[f"{prefix}__{field}"] = field_value
                    metadata[name].append({field: field_value for field, field_value in arm.items()
                                           if not isinstance(field_value, np.ndarray)})
                    for failure in arm.get("failures", []):
                        with (self.root / "failures.jsonl").open("a", encoding="utf-8") as stream:
                            stream.write(json.dumps(_jsonable(dict(window=key, arm=arm_name, **failure)), allow_nan=False) + "\n")
            else:
                metadata[name] = value
        self.npz(base / "arrays.npz", arrays)
        self.json(base / "metadata.json", metadata)

    def assessment_arm(self, key, rank, result, *, checkpoint=False):
        arm_name = result["arm"]["name"]
        suffix = f"checkpoint_{self.sequence:06d}" if checkpoint else "complete"
        base = Path("assessment") / key / "arms" / f"{rank:02d}__{arm_name}__{suffix}"
        self.npz(base.with_suffix(".npz"), {k: v for k, v in result.items() if isinstance(v, np.ndarray)})
        self.json(base.with_suffix(".json"), {k: v for k, v in result.items() if not isinstance(v, np.ndarray)})
        for failure in result.get("failures", []):
            with (self.root / "failures.jsonl").open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(_jsonable(dict(window=key, arm=arm_name, checkpoint=checkpoint, **failure)),
                                        allow_nan=False) + "\n")

    def finalize(self, status, error=None, **extra):
        runtime = dict(python=platform.python_version(), numpy=np.__version__, torch=torch.__version__,
                       execution_threads=getattr(self, 'execution_threads', None),
                       restored_finalization_threads=_thread_settings(), elapsed_seconds=time.perf_counter()-self.started,
                       peak_sampled_rss_bytes=self.peak_rss or None, cpu_threads_required=1,
                       static_resource_counts=STATIC_RESOURCES)
        try:
            import threadpoolctl
            runtime["threadpoolctl"] = getattr(threadpoolctl, "__version__", None)
        except ImportError:
            runtime["threadpoolctl"] = None
        self.json("runtime.json", runtime)
        self.json("receipt.json", dict(schema="regge_short_record_receipt_v01", status=status,
                  error=error, test_only=self.test_only, scientific_binding_eligible=not self.test_only, **extra))
        manifest = {}
        for path in sorted(self.root.rglob("*")):
            if path.is_file() and path.relative_to(self.root).as_posix() not in {"manifest.json", "audit.json"}:
                if not path.resolve().is_relative_to(self.root.resolve()):
                    raise RuntimeError('manifest artifact escapes run directory')
                manifest[path.relative_to(self.root).as_posix()] = _hash(path)
        self.json("manifest.json", dict(schema="regge_short_record_manifest_v01",
                  excluded=["manifest.json", "audit.json"], files=manifest))


@contextmanager
def _one_thread():
    previous = torch.get_num_threads()
    torch.set_num_threads(1)
    try:
        from threadpoolctl import threadpool_limits
        with threadpool_limits(limits=1):
            yield _thread_settings()
    finally:
        torch.set_num_threads(previous)


def _thread_settings():
    from threadpoolctl import threadpool_info
    return dict(torch_threads=torch.get_num_threads(), loaded_threadpools=threadpool_info())


def replay_assessment_arm(arm, warmup_states, timestamps, forcing, observations,
                          calibration_start, calibration_stop, assessment_start, assessment_stop,
                          *, adapter=None, forecast_fn=checked_deterministic_forecasts, record_event=lambda *a, **k: None,
                          preserve_on_error=lambda result: None):
    """Replay one method continuously and save complete origin/forecast evidence."""
    dates = np.asarray(timestamps).astype("datetime64[h]")
    forcing, observations = np.asarray(forcing, float), np.asarray(observations, float)
    origins = complete_origins(dates, assessment_start, assessment_stop, (1, 24, 48, 120))
    targets = origins[:, None] + np.arange(1, 121, dtype=np.int64)[None]
    models = len(arm["parameters"])
    if adapter is None:
        adapter = BatchedNoiseFilters([arm["parameters"]], np.asarray([arm["diagonals"]]),
                                      interaction_groups=[arm["interaction_groups"]])
    initial = adapter.initial_state()
    warm = torch.as_tensor(warmup_states, dtype=torch.float64).reshape(1, models, 5)
    probabilities = torch.as_tensor([arm["initial_probabilities"]], dtype=torch.float64)
    state = FilterState(warm, initial.covariances, probabilities)
    shape = (len(origins),)
    arrays = dict(origin_indices=origins, target_indices=targets,
        origin_timestamps=dates[origins], target_timestamps=dates[targets], target_observations=observations[targets],
        origin_forcing=forcing[origins], future_forcing=forcing[targets],
        persistence_predictions=np.broadcast_to(observations[origins, None], targets.shape).copy(),
        global_states=np.full((*shape, 5), np.nan), global_covariances=np.full((*shape, 5, 5), np.nan),
        member_states=np.full((*shape, models, 5), np.nan), member_covariances=np.full((*shape, models, 5, 5), np.nan),
        probabilities=np.full((*shape, models), np.nan), fixed_predictions=np.full((*shape, 120), np.nan),
        hourly_evolving_predictions=np.full((*shape, 120), np.nan))
    origin_map = {int(v): i for i, v in enumerate(origins)}
    alive = np.ones(1, bool); failures = []
    matrix = arm["transition_matrix"]
    def current_result():
        arrays["fixed_prediction_mask"] = np.isfinite(arrays["fixed_predictions"])
        arrays["hourly_evolving_prediction_mask"] = np.isfinite(arrays["hourly_evolving_predictions"])
        return dict(**arrays, arm=arm, valid=False, failures=list(failures),
                    replay_bounds=[int(calibration_start), int(assessment_stop)], calibration_stop=int(calibration_stop))
    try:
        for hour in range(calibration_start, assessment_stop):
            if not alive[0]: break
            update = isolated_filter_step(adapter, state, forcing[hour:hour+1], observations[hour:hour+1], matrix, alive)
            state, alive = update["state"], update["alive"]
            if update["failures"]:
                failures.extend(dict(stage="filter", index=hour, timestamp=str(dates[hour]), **f) for f in update["failures"])
                break
            if hour not in origin_map: continue
            column = origin_map[hour]
            arrays["global_states"][column] = update["global_states"][0].numpy()
            arrays["global_covariances"][column] = update["global_covariances"][0].numpy()
            arrays["member_states"][column] = state.states[0].numpy()
            arrays["member_covariances"][column] = state.covariances[0].numpy()
            arrays["probabilities"][column] = state.probabilities[0].numpy()
            future = forcing[hour+1:hour+121][None]
            for key, evolve in (("fixed_predictions", False), ("hourly_evolving_predictions", True)):
                try:
                    prediction = forecast_fn(update["global_states"], state.probabilities, future,
                                             [arm["parameters"]], matrix, tuple(range(1, 121)), evolve=evolve)
                    arrays[key][column] = prediction[0].numpy()
                except ForecastNumericalFailure as error:
                    partial = error.predictions[0].numpy(); mask = error.prediction_mask[0].numpy()
                    arrays[key][column, mask] = partial[mask]
                    failures.append(dict(stage="forecast", form=key, index=hour, timestamp=str(dates[hour]),
                                         completed_hours=error.completed_hours, failed_hour=error.failed_hour, reason=str(error)))
                    alive[0] = False; break
                except (NumericalFailure, torch.linalg.LinAlgError) as error:
                    failures.append(dict(stage="forecast", form=key, index=hour, timestamp=str(dates[hour]), reason=str(error)))
                    alive[0] = False; break
    except BaseException:
        preserve_on_error(current_result())
        raise
    arrays["fixed_prediction_mask"] = np.isfinite(arrays["fixed_predictions"])
    arrays["hourly_evolving_prediction_mask"] = np.isfinite(arrays["hourly_evolving_predictions"])
    return dict(**arrays, arm=arm, valid=bool(alive[0] and arrays["fixed_prediction_mask"].all()
                                             and arrays["hourly_evolving_prediction_mask"].all()), failures=failures,
                replay_bounds=[int(calibration_start), int(assessment_stop)], calibration_stop=int(calibration_stop))


def _window_key(window): return f'{window["name"]}__{int(window["months"])}'


def _selected_warmup_states(calibration, member_ids):
    warmup_states = calibration['warmup_states']
    return {pid: warmup_states[pid].copy() for pid in member_ids}


def _persist_snapshot(art, paths):
    mapping = []
    for number, source in enumerate(sorted({Path(p).resolve() for p in paths}, key=str)):
        target = art.root / "source_snapshot" / f"{number:03d}_{source.name}"
        target.parent.mkdir(parents=True, exist_ok=True)
        with source.open("rb") as inp, target.open("xb") as out: shutil.copyfileobj(inp, out)
        mapping.append(dict(original_path=str(source), snapshot_path=target.relative_to(art.root).as_posix(), sha256=_hash(source)))
    art.json("source_snapshot/index.json", mapping)
    return {row["original_path"]: row["sha256"] for row in mapping}


def _orchestrate(art, windows, calibrate_fn, assess_fn):
    selected = {}
    for window in windows:
        key = _window_key(window); art.event("calibration_start", window=key)
        try:
            result = calibrate_fn(window, art.event)
        except BaseException as error:
            partial = getattr(error, 'short_record_partial_result', None)
            if partial is not None:
                try:
                    art.calibration(key, partial)
                except BaseException as checkpoint_error:
                    error.add_note(f'Partial calibration checkpoint also failed: {type(checkpoint_error).__name__}: {checkpoint_error}')
                    raise error from checkpoint_error
            raise
        art.calibration(key, result)  # persistence precedes status inspection
        if result.get("status") != "complete": raise RuntimeError(f"calibration failed for {key}")
        selected[key] = result["selected"]
        art.event("selection_frozen", window=key, cutoff=result["selected"].get("selection_cutoff"))
    art.json("all_selections.json", selected)
    art.event("all_selections_frozen", count=len(selected))
    for window in windows:
        key = _window_key(window); art.event("assessment_start", window=key)
        result = assess_fn(window, selected[key], art.event)
        art.assessment(key, result); art.event("assessment_complete", window=key)
    return selected


def _run_synthetic_test(run_dir, *, windows, calibrate_fn, assess_fn):
    """Tiny TEST-ONLY orchestration double; its receipt can never authorize production."""
    art = _Artifacts(run_dir, test_only=True)
    try:
        _orchestrate(art, windows, calibrate_fn, assess_fn)
        art.finalize("complete", evidence="synthetic_test_only")
    except BaseException as error:
        art.finalize("failed", f"{type(error).__name__}: {error}", evidence="synthetic_test_only")
        raise
    return dict(run_dir=str(art.root), status="complete", test_only=True)


def _binding(config_hash, sources):
    return dict(config_sha256=config_hash, source_hashes=sources, python=platform.python_version(),
                numpy=np.__version__, torch=torch.__version__, cpu_threads=1, dtype="float64")


def _eligible_preflight(output_root, binding, config, current_inputs):
    matches = []
    for path in Path(output_root).glob("*/receipt.json"):
        receipt = json.loads(path.read_text(encoding="utf-8"))
        if (receipt.get("mode") == "preflight" and receipt.get("status") == "preflight_complete"
                and receipt.get("passed") is True and receipt.get("test_only") is False
                and receipt.get("binding") == binding):
            matches.append(path)
    if len(matches) != 1:
        raise RuntimeError("formal run requires exactly one matching passed real preflight receipt")
    _validate_preflight_evidence(matches[0], binding, config, current_inputs)
    return matches[0]


def _positive_number(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not np.isfinite(value) or value <= 0:
        raise RuntimeError(f"preflight {name} must be finite and positive")
    return float(value)


def _validate_preflight_evidence(receipt_path, binding, config, current_inputs):
    root = receipt_path.parent
    required = [Path("preflight/arrays.npz"), Path("preflight/checks.json"), Path("preflight/runtime.json"),
                Path("receipt.json"), Path("runtime.json"), Path("manifest.json")]
    if any(not (root / path).is_file() for path in required):
        raise RuntimeError("matching preflight is missing required evidence")
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    if manifest.get("schema") != "regge_short_record_manifest_v01" or manifest.get("excluded") != ["manifest.json", "audit.json"]:
        raise RuntimeError("preflight manifest schema/exclusions are invalid")
    files = manifest.get("files")
    if not isinstance(files, dict): raise RuntimeError("preflight manifest file map is invalid")
    if any(Path(name).is_absolute() or '..' in Path(name).parts or not (root/name).resolve().is_relative_to(root.resolve()) for name in files):
        raise RuntimeError('preflight manifest unsafe path')
    actual = {}
    for path in root.rglob('*'):
        relative = path.relative_to(root).as_posix()
        if path.is_file() and relative not in {'manifest.json','audit.json'}:
            if not path.resolve().is_relative_to(root.resolve()):
                raise RuntimeError('preflight manifest artifact escapes run directory')
            actual[relative] = _hash(path)
    if files != actual:
        raise RuntimeError("preflight complete manifest file set or hashes changed")
    snapshot_index = root / "source_snapshot/index.json"
    if not snapshot_index.is_file(): raise RuntimeError("preflight source snapshot index is missing")
    snapshots = json.loads(snapshot_index.read_text(encoding="utf-8"))
    if not isinstance(snapshots, list) or {row.get("original_path"): row.get("sha256") for row in snapshots} != binding["source_hashes"]:
        raise RuntimeError("preflight source snapshot index differs from binding")
    for row in snapshots:
        relative = row.get("snapshot_path")
        if (not isinstance(relative, str) or Path(relative).is_absolute() or ".." in Path(relative).parts
                or not (root / relative).resolve().is_relative_to(root.resolve())
                or not (root / relative).is_file() or _hash(root / relative) != row["sha256"]):
            raise RuntimeError("preflight source snapshot is missing, unsafe, or changed")
    checks = json.loads((root / "preflight/checks.json").read_text(encoding="utf-8"))
    methods = {"single_model": 1, "same_parameter_three_noise": 3,
               "five_parameter_fully_interacting": 5, "five_parameter_no_cross_parameter_interaction": 5}
    if (checks.get("schema") != "regge_short_record_preflight_checks_v01" or checks.get("passed") is not True
            or checks.get("completed_update_hours") != 129 or checks.get("forecast_hours") != 120
            or checks.get("arm_model_counts") != methods):
        raise RuntimeError("preflight passed-check schema is incomplete or failed")
    with np.load(root / "preflight/arrays.npz", allow_pickle=False) as archive:
        arrays = {name: archive[name] for name in archive.files}
    common = {"timestamps": ("datetime64[h]", (256,)), "forcing": ("float64", (256, 2)),
              "observations": ("float64", (256,)), "update_indices": ("int64", (129,)),
              "forecast_indices": ("int64", (120,)), "parameter_values": ("float64", (5, 5)),
              "noise_diagonals": ("float64", (3, 5))}
    for name, (dtype, shape) in common.items():
        value = arrays.get(name)
        if value is None or value.shape != shape or str(value.dtype) != dtype:
            raise RuntimeError(f"preflight common array schema mismatch: {name}")
    timestamps, forcing, observations = current_inputs
    if (not np.array_equal(arrays["timestamps"], timestamps[:256].astype("datetime64[h]"))
            or not np.array_equal(arrays["forcing"], forcing[:256]) or not np.array_equal(arrays["observations"], observations[:256])
            or not np.array_equal(arrays["update_indices"], np.arange(129))
            or not np.array_equal(arrays["forecast_indices"], np.arange(129, 249))):
        raise RuntimeError("preflight common arrays do not match frozen inputs/indices")
    coords = np.asarray(config["preflight"]["coordinates"])
    bounds = np.asarray([config["parameter_bounds"][field] for field in config["parameter_fields"]])
    expected_parameters = 10 ** (np.log10(bounds[:, 0]) + coords[:, None] * (np.log10(bounds[:, 1])-np.log10(bounds[:, 0])))
    from .noise_search import build_noise_design
    expected_noise = build_noise_design(config["noise_design"]["seed"])[config["preflight"]["noise_rows"]]
    if not np.array_equal(arrays["parameter_values"], expected_parameters) or not np.array_equal(arrays["noise_diagonals"], expected_noise):
        raise RuntimeError("preflight parameter/noise arrays differ from frozen construction")
    shapes = {"member_states": lambda m: (129,m,5), "member_covariances": lambda m: (129,m,5,5),
              "global_states": lambda m: (129,5), "global_covariances": lambda m: (129,5,5),
              "probabilities": lambda m: (129,m), "log_likelihoods": lambda m: (129,m),
              "fixed_predictions": lambda m: (120,), "hourly_evolving_predictions": lambda m: (120,)}
    tolerances = dict(member_states=config["preflight"]["state_absolute_tolerance"],
                      member_covariances=config["preflight"]["covariance_absolute_tolerance"],
                      global_states=config["preflight"]["state_absolute_tolerance"],
                      global_covariances=config["preflight"]["covariance_absolute_tolerance"],
                      probabilities=config["preflight"]["probability_absolute_tolerance"],
                      log_likelihoods=config["preflight"]["log_likelihood_absolute_tolerance"],
                      fixed_predictions=config["preflight"]["forecast_absolute_tolerance"],
                      hourly_evolving_predictions=config["preflight"]["forecast_absolute_tolerance"])
    for method, members in methods.items():
        for quantity, shape_fn in shapes.items():
            native, reference = arrays.get(f"{method}__native__{quantity}"), arrays.get(f"{method}__reference__{quantity}")
            if native is None or reference is None or native.shape != shape_fn(members) or reference.shape != shape_fn(members) \
                    or native.dtype != np.float64 or reference.dtype != np.float64 or not np.isfinite(native).all() or not np.isfinite(reference).all():
                raise RuntimeError(f"preflight method array schema mismatch: {method}/{quantity}")
            if np.max(np.abs(native-reference)) > tolerances[quantity]:
                raise RuntimeError(f"preflight recomputed maximum failed: {method}/{quantity}")
        if np.max(np.abs(arrays[f"{method}__native__global_states"][:,4]-arrays[f"{method}__reference__global_states"][:,4])) > config["preflight"]["global_discharge_absolute_tolerance"]:
            raise RuntimeError(f"preflight tighter global discharge maximum failed: {method}")
        likelihoods = arrays.get(f"{method}__reference__likelihoods")
        mass = arrays.get(f"{method}__reference__normalization_mass")
        if likelihoods is None or likelihoods.shape != (129,members) or mass is None or mass.shape != (129,) \
                or likelihoods.dtype != np.float64 or mass.dtype != np.float64 or np.any(likelihoods <= 0) or np.any(mass <= 0) \
                or not np.isfinite(likelihoods).all() or not np.isfinite(mass).all():
            raise RuntimeError(f"preflight likelihood/mass evidence invalid: {method}")
    for side in ("native", "reference"):
        if not np.array_equal(arrays[f"single_model__{side}__fixed_predictions"], arrays[f"single_model__{side}__hourly_evolving_predictions"]):
            raise RuntimeError("preflight single-model forecast forms differ")
        if not np.allclose(arrays[f"same_parameter_three_noise__{side}__fixed_predictions"],
                           arrays[f"same_parameter_three_noise__{side}__hourly_evolving_predictions"], rtol=1e-10, atol=1e-12):
            raise RuntimeError("preflight same-parameter forecast forms exceed tolerance")
    runtime = json.loads((root / "preflight/runtime.json").read_text(encoding="utf-8"))
    for name in ("elapsed_seconds", "native_seconds", "reference_seconds", "baseline_rss_bytes", "peak_rss_bytes"):
        _positive_number(runtime.get(name), name)
    if runtime.get("memory_measurement_kind") != "sampled_process_rss" or runtime["peak_rss_bytes"] < runtime["baseline_rss_bytes"]:
        raise RuntimeError("preflight memory measurement schema is invalid")
    work = runtime.get("work_counts")
    components = runtime.get("component_seconds")
    required_work = {"filter_member_hours", "forecast_hydrologic_steps", "max_concurrent_candidates"}
    if not isinstance(work, dict) or not isinstance(components, dict):
        raise RuntimeError("preflight runtime work-count schema is missing")
    if work != {"filter_member_hours":1806, "forecast_hydrologic_steps":960, "max_concurrent_candidates":5}:
        raise RuntimeError("preflight work counts differ from frozen schema")
    for name in ("filter", "forecast", "reference_filter", "reference_forecast"):
        _positive_number(components.get(name), f"component_seconds.{name}")
    return dict(checks=checks, runtime=runtime)


def _resource_gate(path, *, disk_free=None, memory_available=None):
    """Conservative storage/memory gate; estimates never alter frozen budgets."""
    if disk_free is None:
        disk_free = shutil.disk_usage(path).free
    if memory_available is None:
        try:
            import psutil
            memory_available = psutil.virtual_memory().available
        except ImportError as error:
            raise RuntimeError("psutil is required for the formal resource gate") from error
    static_total = sum(STATIC_RESOURCES[name] for name in (
        "complete_calibration_numeric_arrays_bytes", "assessment_arm_numeric_arrays_bytes",
        "assessment_shared_numeric_arrays_bytes", "frozen_input_numeric_arrays_bytes"))
    required_disk = int(static_total * 1.25)
    required_memory = STATIC_RESOURCES["largest_hydrologic_array_bytes"] * 4
    receipt = dict(disk_free_bytes=int(disk_free), memory_available_bytes=int(memory_available),
                   required_disk_bytes=required_disk, required_memory_bytes=required_memory,
                   assumptions="static float64 payload plus 25 percent disk margin; four largest arrays memory bound",
                   passed=bool(disk_free >= required_disk and memory_available >= required_memory))
    if not receipt["passed"]:
        raise RuntimeError("resources do not meet frozen evidence gate; scientific budget unchanged")
    return receipt


def _formal_resource_estimate(resource, runtime):
    work, seconds = runtime["work_counts"], runtime["component_seconds"]
    targets = dict(filter=122116656, forecast=601265760,
                   warmup_forecast_rate_proxy=STATIC_RESOURCES["warmup_plus_calibration_candidate_steps"],
                   reference_forecast_audit=2594400)
    estimates = dict(
        filter=float(seconds["filter"]) * targets["filter"] / work["filter_member_hours"],
        forecast=float(seconds["forecast"]) * targets["forecast"] / work["forecast_hydrologic_steps"],
        warmup_forecast_rate_proxy=float(seconds["forecast"]) * targets["warmup_forecast_rate_proxy"] / work["forecast_hydrologic_steps"],
        reference_forecast_audit=float(seconds["reference_forecast"]) * targets["reference_forecast_audit"] / work["forecast_hydrologic_steps"])
    concurrency_ratio = 128 / float(work["max_concurrent_candidates"])
    baseline = float(runtime["baseline_rss_bytes"])
    increment = max(0., float(runtime["peak_rss_bytes"])-baseline)
    # Assignment of the next calibration result can briefly retain the previous
    # result, so include two windows, matching the two existing large buffers.
    progress_buffer = 2 * STATIC_RESOURCES["calibration_progress_arrays_per_window_bytes"]
    known_buffers = 2 * STATIC_RESOURCES["largest_hydrologic_array_bytes"] + progress_buffer
    estimated_memory = 1.25 * (baseline + concurrency_ratio*increment + known_buffers)
    return dict(resource_gate=resource, preflight_measurements=runtime, full_static_work=STATIC_RESOURCES,
                estimated_component_seconds=estimates, estimated_total_seconds=sum(estimates.values()),
                estimated_peak_rss_bytes=estimated_memory, measured_baseline_rss_bytes=baseline,
                measured_incremental_rss_bytes=increment, known_buffer_bytes=known_buffers,
                known_progress_buffer_bytes=progress_buffer,
                assumptions={"throughput":"linear scaling of each measured small-preflight component",
                             "warmup":"native forecast-step rate is a proxy; warmup was not measured",
                             "memory":"baseline plus concurrency-scaled incremental RSS plus two largest buffers and two windows of progress arrays, then 25 percent margin",
                             "limitations":"small-bank rates are measured; full-run rates, I/O, audit overhead and peak are extrapolations"},
                scientific_budget_changed=False)


def run_short_record(config_path, output_root, run_id, preflight=False) -> dict:
    """Run one exclusive real preflight or one separately gated formal study."""
    if not isinstance(run_id, str) or not run_id or Path(run_id).name != run_id or Path(run_id).is_absolute() or run_id in {".", ".."}:
        raise ValueError("run_id must be one nonempty directory-name component")
    config_path, output_root = Path(config_path).resolve(), Path(output_root).resolve()
    allowed = WORKTREE.resolve()
    run_dir = (output_root / run_id).resolve()
    if (output_root == allowed or allowed not in output_root.parents or PACKAGE.resolve() in output_root.parents
            or run_dir.parent != output_root or run_dir == PACKAGE.resolve() or PACKAGE.resolve() in run_dir.parents):
        raise ValueError("output_root must be strictly inside the worktree and outside source")
    config = json.loads(config_path.read_text(encoding="utf-8")); validate_config(config); validate_fixed_field_provenance(config)
    art = _Artifacts(run_dir, test_only=False)
    sources = [config_path, *sorted(PACKAGE.glob("*.py")), PACKAGE / "scripts/run_short_record.py",
               *sorted((REFERENCE_ROOT / "python/imm_da").glob("*.py"))]
    try:
        before = _persist_snapshot(art, sources); binding = _binding(_hash(config_path), before)
        art.json("config.json", config); art.json("provenance_before_load.json", before)
        dates, forcing, observations, _, loaded = load_reference(REFERENCE_ROOT)
        validate_series(dates, forcing, observations)
        if dates[0].astype("datetime64[h]") != np.datetime64(config["data_start"], "h") or dates[-1].astype("datetime64[h]") != np.datetime64(config["data_stop"], "h")-np.timedelta64(1,"h"):
            raise ValueError("formal input does not cover the exact frozen interval")
        art.npz("inputs.npz", dict(timestamps=dates, forcing=forcing, observations=observations))
        resource = _resource_gate(art.root)
        art.json("resource_plan.json", dict(static_counts=STATIC_RESOURCES, estimates_are_not_measurements=True,
                                             budgets_must_not_be_reduced=True, gate=resource))
        with _one_thread() as execution_threads:
            art.execution_threads = execution_threads
            if preflight:
                from .short_record_audit import numerical_preflight
                result = numerical_preflight(config, dates, forcing, observations, REFERENCE_ROOT, art.event)
                art.npz("preflight/arrays.npz", result.get("arrays", {}))
                art.json("preflight/checks.json", result.get("checks", {})); art.json("preflight/runtime.json", result.get("runtime", {}))
                if not result.get("passed"): raise RuntimeError("numerical preflight failed")
                final_status = "preflight_complete"
            else:
                current_inputs = (dates, forcing, observations)
                preflight_receipt = _eligible_preflight(output_root, binding, config, current_inputs)
                validated_preflight = _validate_preflight_evidence(preflight_receipt, binding, config, current_inputs)
                art.json("preflight_binding.json", dict(receipt_path=str(preflight_receipt), receipt_sha256=_hash(preflight_receipt)))
                formal_resource = _formal_resource_estimate(resource, validated_preflight["runtime"])
                art.json("formal_resource_receipt.json", formal_resource)
                if formal_resource["estimated_peak_rss_bytes"] > resource["memory_available_bytes"]:
                    raise RuntimeError("extrapolated formal memory exceeds live availability; scientific budget unchanged")
                windows = calibration_windows(config)
                def calibrate(window, event): return calibrate_window(config, information_slices(dates, forcing, observations, window), event)
                def assess(window, selected, event):
                    arms = build_assessment_arms(selected, int(window["months"]) == 3)
                    c0 = int(np.flatnonzero(dates.astype("datetime64[h]") == np.datetime64(window["calibration_start"],"h"))[0])
                    c1 = int(np.flatnonzero(dates.astype("datetime64[h]") == np.datetime64(window["calibration_stop"],"h"))[0])
                    a0, a1 = c1, int(np.flatnonzero(dates.astype("datetime64[h]") == np.datetime64(window["assessment_stop"],"h"))[0]) if np.datetime64(window["assessment_stop"],"h") in dates.astype("datetime64[h]") else len(dates)
                    with np.load(art.root / "calibration" / _window_key(window) / "raw.npz") as calibration:
                        member_ids = [m["parameter_id"] for m in selected["members"]]
                        warm_by_id = _selected_warmup_states(calibration, member_ids)
                    results = []
                    for rank, arm in enumerate(arms):
                        warm = np.asarray([warm_by_id[next(m["parameter_id"] for m in selected["members"] if m["parameters"] == p)] for p in arm["parameters"]])
                        result = replay_assessment_arm(arm, warm, dates, forcing, observations, c0, c1, a0, a1,
                            record_event=event, preserve_on_error=lambda partial, r=rank: art.assessment_arm(_window_key(window), r, partial, checkpoint=True))
                        art.assessment_arm(_window_key(window), rank, result)
                        results.append(result)
                    origins = results[0]["origin_indices"]
                    summaries = [{k: v for k, v in result.items() if not isinstance(v, np.ndarray)} for result in results]
                    return dict(arm_summaries=summaries, persistence_predictions=np.broadcast_to(observations[origins,None], (len(origins),120)).copy(),
                                target_observations=observations[origins[:,None]+np.arange(1,121)[None]], origin_indices=origins)
                _orchestrate(art, windows, calibrate, assess); final_status = "complete"
        after = {path: _hash(path) if Path(path).is_file() else None for path in before}
        art.json("input_hashes_after.json", after)
        if before != after: raise RuntimeError("source/config changed during execution")
        art.finalize(final_status, mode="preflight" if preflight else "formal", passed=True, binding=binding)
    except BaseException as error:
        if not (art.root / "receipt.json").exists():
            art.finalize("failed", f"{type(error).__name__}: {error}", mode="preflight" if preflight else "formal", passed=False,
                         binding=locals().get("binding"))
        raise
    return dict(run_dir=str(art.root), status=final_status)
