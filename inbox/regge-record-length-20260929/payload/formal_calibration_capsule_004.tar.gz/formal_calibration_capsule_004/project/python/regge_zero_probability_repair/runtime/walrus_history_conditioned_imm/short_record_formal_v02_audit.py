"""Read-only independent artifact audit for the V02 Regge formal study.

The V02 receipt and repair binding are validated independently here.  Raw
calibration ranking, complete forecast reconstruction, metrics, chronology,
and thresholds reuse the existing independent audit helpers, not production
selection or scoring helpers.
"""
from __future__ import annotations

import json
from pathlib import Path
import platform

import numpy as np
import torch

from . import short_record_audit as audit
from . import short_record_formal_v02 as formal
from . import short_record_reference_repair as repair
from .short_record_contract import validate_config, validate_fixed_field_provenance


EXPECTED_STATIC_RESOURCES = {
    "hydrologic_prediction_float64_bytes": 969670656,
    "calibration_four_lead_prediction_float64_bytes": 159645696,
    "assessment_two_form_prediction_float64_bytes": 20755200,
    "complete_calibration_numeric_arrays_bytes": 1521716736,
    "calibration_progress_arrays_per_window_bytes": 600064,
    "calibration_progress_arrays_all_windows_bytes": 3600384,
    "assessment_arm_numeric_arrays_bytes": 94453456,
    "assessment_shared_numeric_arrays_bytes": 4168336,
    "frozen_input_numeric_arrays_bytes": 1683424,
    "largest_hydrologic_array_bytes": 287440896,
    "warmup_steps_without_cache": 142362,
    "warmup_plus_calibration_candidate_steps": 412766208,
    "joint_filter_member_hours": 121208832,
    "calibration_forecast_origins": 4988928,
    "calibration_forecast_hydrologic_steps": 598671360,
}


def _required_source_paths():
    """Independently enumerate the complete formal source set."""
    package = Path(__file__).resolve().parent
    return {str(path.resolve()) for path in [
        formal.DEFAULT_CONFIG, *sorted(package.glob("*.py")),
        *sorted((package / "scripts").glob("*.py")),
        *sorted((audit.REFERENCE_ROOT / "python/imm_da").glob("*.py")),
    ]}


def _validate_source_set(binding):
    sources = binding.get("source_hashes")
    audit._require(isinstance(sources, dict) and set(sources) == _required_source_paths(),
                   "formal V02 complete source path set mismatch")


def _formal_receipt(receipt):
    audit._require(
        receipt.get("schema") == formal.RECEIPT_SCHEMA
        and receipt.get("status") == "complete"
        and receipt.get("mode") == formal.MODE
        and receipt.get("passed") is True
        and receipt.get("test_only") is False
        and receipt.get("scientific_binding_eligible") is True
        and receipt.get("reference_arithmetic") == "independent_log",
        "formal V02 receipt failed/stale/test-only",
    )


def _expected_protocol(config):
    """Independent expected protocol; do not call the production builder."""
    return {
        "schema": "regge_short_record_formal_protocol_v02",
        "base_config_sha256": formal.CONFIG_HASH,
        "reference_arithmetic": "independent_log",
        "reference_repair": {
            "root": str(formal.REPAIR_ROOT.resolve()),
            "receipt_sha256": formal.REPAIR_RECEIPT_HASH,
            "manifest_sha256": formal.REPAIR_MANIFEST_HASH,
            "audit_sha256": formal.REPAIR_AUDIT_HASH,
            "promoted_to_legacy_preflight": False,
        },
        "formal_execution_authorized": True,
        "legacy_gate_modified": False,
        "scientific_design_changed": False,
        "preflight_contract": config["preflight"],
        "interpretation": (
            "Retrospective development study of practical later forecast skill after three months of "
            "discharge calibration; not global optimality, statistical noninferiority, flood-peak skill, "
            "operational causality, or a pure calibration-length effect."
        ),
    }


def _repair_binding(root, receipt, config, inputs):
    for name, expected in {
        "receipt.json": formal.REPAIR_RECEIPT_HASH,
        "manifest.json": formal.REPAIR_MANIFEST_HASH,
        "audit.json": formal.REPAIR_AUDIT_HASH,
    }.items():
        path = formal.REPAIR_ROOT / name
        audit._require(path.is_file() and audit._hash(path) == expected,
                       "formal V02 pinned repair " + name)
    result = repair.audit_reference_repair_run(formal.REPAIR_ROOT)
    audit._require(isinstance(result, dict) and result.get("passed") is True
                   and result.get("status") == "reference_repair_complete"
                   and result.get("scientific_binding_eligible") is False,
                   "formal V02 independent repair audit")
    prior = audit._json(formal.REPAIR_ROOT / "receipt.json")
    prior_binding = prior["binding"]
    binding = receipt["binding"]
    audit._require(prior_binding["config_sha256"] == binding["config_sha256"] == formal.CONFIG_HASH,
                   "formal V02 repair configuration binding")
    for field in ("python", "numpy", "torch", "cpu_threads", "dtype"):
        audit._require(prior_binding.get(field) == binding.get(field),
                       "formal V02 repair runtime binding: " + field)
    for path, digest in prior_binding["source_hashes"].items():
        audit._require(binding["source_hashes"].get(path) == digest,
                       "formal V02 repair source binding: " + path)
    with np.load(formal.REPAIR_ROOT / "inputs.npz", allow_pickle=False) as saved:
        for name in ("timestamps", "forcing", "observations"):
            audit._same(saved[name], inputs[name], "formal V02 repair full input " + name)
        prefix = audit._preflight_saved_evidence(
            formal.REPAIR_ROOT, prior, config, saved, reference_arithmetic="independent_log")
    expected = {
        "schema": "regge_short_record_reference_repair_binding_v02",
        "repair_root": str(formal.REPAIR_ROOT.resolve()),
        "receipt_sha256": formal.REPAIR_RECEIPT_HASH,
        "manifest_sha256": formal.REPAIR_MANIFEST_HASH,
        "audit_sha256": formal.REPAIR_AUDIT_HASH,
        "reference_arithmetic": "independent_log",
        "independent_saved_audit_passed": True,
        "scientific_binding_eligible_in_repair_receipt": False,
        "promoted_to_legacy_preflight": False,
        "overlapping_source_count": len(prior_binding["source_hashes"]),
        "filtering_scope": result.get("filtering_scope"),
    }
    audit._require(audit._json(root / "reference_repair_binding.json") == expected,
                   "formal V02 saved repair binding changed")
    return prefix


def _expected_resource_estimate(gate, runtime):
    """Independently reproduce all frozen extrapolation fields."""
    counts = EXPECTED_STATIC_RESOURCES
    work = runtime["work_counts"]
    seconds = runtime["component_seconds"]
    audit._require(work == dict(filter_member_hours=1806, forecast_hydrologic_steps=960,
                                max_concurrent_candidates=5), "formal V02 resource work counts")
    for name in ("filter", "forecast", "reference_filter", "reference_forecast"):
        value = seconds.get(name)
        audit._require(type(value) in (int, float) and np.isfinite(value) and value > 0,
                       "formal V02 resource measured component " + name)
    baseline = runtime["baseline_rss_bytes"]
    measured_peak = runtime["peak_rss_bytes"]
    audit._require(type(baseline) in (int, float) and type(measured_peak) in (int, float)
                   and np.isfinite(baseline) and np.isfinite(measured_peak)
                   and measured_peak >= baseline > 0, "formal V02 resource measured memory")
    targets = dict(filter=122116656, forecast=601265760,
                   warmup_forecast_rate_proxy=412766208, reference_forecast_audit=2594400)
    estimates = dict(
        filter=float(seconds["filter"]) * targets["filter"] / work["filter_member_hours"],
        forecast=float(seconds["forecast"]) * targets["forecast"] / work["forecast_hydrologic_steps"],
        warmup_forecast_rate_proxy=float(seconds["forecast"]) * targets["warmup_forecast_rate_proxy"] / work["forecast_hydrologic_steps"],
        reference_forecast_audit=float(seconds["reference_forecast"]) * targets["reference_forecast_audit"] / work["forecast_hydrologic_steps"],
    )
    baseline = float(baseline)
    increment = max(0.0, float(measured_peak) - baseline)
    progress_buffer = 2 * counts["calibration_progress_arrays_per_window_bytes"]
    known_buffers = 2 * counts["largest_hydrologic_array_bytes"] + progress_buffer
    peak = 1.25 * (baseline + 128 / float(work["max_concurrent_candidates"]) * increment + known_buffers)
    return dict(
        resource_gate=gate, preflight_measurements=runtime, full_static_work=counts,
        estimated_component_seconds=estimates, estimated_total_seconds=sum(estimates.values()),
        estimated_peak_rss_bytes=peak, measured_baseline_rss_bytes=baseline,
        measured_incremental_rss_bytes=increment, known_buffer_bytes=known_buffers,
        known_progress_buffer_bytes=progress_buffer,
        assumptions={
            "throughput": "linear scaling of each measured small-preflight component",
            "warmup": "native forecast-step rate is a proxy; warmup was not measured",
            "memory": "baseline plus concurrency-scaled incremental RSS plus two largest buffers and two windows of progress arrays, then 25 percent margin",
            "limitations": "small-bank rates are measured; full-run rates, I/O, audit overhead and peak are extrapolations",
        },
        scientific_budget_changed=False,
    )


def _resource_evidence(root):
    plan = audit._json(root / "resource_plan.json")
    estimate = audit._json(root / "formal_resource_receipt.json")
    counts = EXPECTED_STATIC_RESOURCES
    audit._require(plan.get("static_counts") == counts and plan.get("estimates_are_not_measurements") is True
                   and plan.get("budgets_must_not_be_reduced") is True,
                   "formal V02 resource plan")
    gate = plan["gate"]
    for field in ("disk_free_bytes", "memory_available_bytes"):
        value = gate.get(field)
        audit._require(type(value) is int and value > 0, "formal V02 resource " + field)
    payload = sum(counts[name] for name in (
        "complete_calibration_numeric_arrays_bytes", "assessment_arm_numeric_arrays_bytes",
        "assessment_shared_numeric_arrays_bytes", "frozen_input_numeric_arrays_bytes"))
    required_disk = int(payload * 1.25)
    required_memory = counts["largest_hydrologic_array_bytes"] * 4
    expected_gate = dict(
        disk_free_bytes=gate["disk_free_bytes"], memory_available_bytes=gate["memory_available_bytes"],
        required_disk_bytes=required_disk, required_memory_bytes=required_memory,
        assumptions="static float64 payload plus 25 percent disk margin; four largest arrays memory bound",
        passed=bool(gate["disk_free_bytes"] >= required_disk and gate["memory_available_bytes"] >= required_memory),
    )
    audit._require(gate == expected_gate and expected_gate["passed"] is True,
                   "formal V02 independently recomputed resource gate")
    expected_estimate = _expected_resource_estimate(
        expected_gate, audit._json(formal.REPAIR_ROOT / "preflight/runtime.json"))
    audit._require(estimate == expected_estimate, "formal V02 independently recomputed resource estimate")
    peak = estimate.get("estimated_peak_rss_bytes")
    total = estimate.get("estimated_total_seconds")
    audit._require(type(peak) in (int, float) and np.isfinite(peak) and peak > 0
                   and peak <= gate["memory_available_bytes"], "formal V02 extrapolated memory gate")
    audit._require(type(total) in (int, float) and np.isfinite(total) and total > 0,
                   "formal V02 extrapolated runtime")
    return {"passed": True, "estimates_are_not_measurements": True,
            "estimated_total_seconds": total, "estimated_peak_rss_bytes": peak}


def audit_short_record_run_v02(run_dir):
    """Read, independently validate, and return unrounded JSON-compatible tables."""
    root = Path(run_dir).resolve()
    manifest = audit._manifest(root)
    required = {
        "receipt.json", "runtime.json", "config.json", "inputs.npz",
        "formal_protocol_v02.json", "reference_repair_binding.json", "resource_plan.json",
        "formal_resource_receipt.json", "source_snapshot/index.json", "provenance_before_load.json",
        "input_hashes_after.json", "events.jsonl", "failures.jsonl", "all_selections.json",
    }
    audit._require(required.issubset(manifest), "formal V02 mandatory artifact set incomplete")
    receipt = audit._json(root / "receipt.json")
    _formal_receipt(receipt)
    config = audit._json(root / "config.json")
    validate_config(config)
    validate_fixed_field_provenance(config)
    audit._require(audit._json(root / "formal_protocol_v02.json") == _expected_protocol(config),
                   "formal V02 protocol changed")
    binding = receipt["binding"]
    runtime = audit._json(root / "runtime.json")
    for field, value in {
        "python": platform.python_version(), "numpy": np.__version__, "torch": torch.__version__,
        "cpu_threads": 1, "dtype": "float64",
    }.items():
        audit._require(binding.get(field) == value, "formal V02 current runtime binding: " + field)
    audit._require(runtime["cpu_threads_required"] == 1, "formal V02 required threads")
    observed = runtime.get("execution_threads")
    audit._require(isinstance(observed, dict) and observed.get("torch_threads") == 1
                   and all(pool.get("num_threads") == 1 for pool in observed.get("loaded_threadpools", [])),
                   "formal V02 observed execution threads")
    for field in ("python", "numpy", "torch"):
        audit._require(runtime[field] == binding[field], "formal V02 recorded runtime drift: " + field)
    _validate_source_set(binding)
    audit._source_binding(root, receipt)
    with np.load(root / "inputs.npz", allow_pickle=False) as archive:
        inputs = {name: archive[name] for name in archive.files}
    dates = inputs["timestamps"].astype("datetime64[h]")
    weather = inputs["forcing"]
    flows = inputs["observations"]
    expected = np.arange(np.datetime64(config["data_start"], "h"), np.datetime64(config["data_stop"], "h"))
    audit._same(dates, expected, "formal V02 full frozen input timeline")
    audit._same(inputs["timestamps"], dates, "formal V02 subhour timestamps")
    audit._require(weather.shape == (len(dates), 2) and flows.shape == (len(dates),)
                   and np.isfinite(weather).all() and np.isfinite(flows).all(), "formal V02 full raw inputs")
    original_inputs = audit._original_inputs(audit.REFERENCE_ROOT, inputs)
    prefix = _repair_binding(root, receipt, config, inputs)
    resources = _resource_evidence(root)
    events = [json.loads(line) for line in (root / "events.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
    windows = config["windows"]
    audit._chronology(events, windows)
    selections = audit._json(root / "all_selections.json")
    audit._require(set(selections) == {audit._key(window) for window in windows}, "formal V02 six selected windows")
    calibration = {}
    assessments = {}
    expected_failures = []
    reference = audit._reference_modules(audit.REFERENCE_ROOT)
    current = None
    failure_events = {}
    budgets = {}
    for event in events:
        if event["event"] == "calibration_start":
            current = event["window"]
            failure_events[current] = []
        elif event["event"] == "candidate_failure":
            audit._require(current is not None, "formal V02 failure event before calibration")
            failure_events[current].append({name: value for name, value in event.items()
                                            if name not in ("event", "sequence", "utc")})
        elif event["event"] == "search_budget":
            audit._require(current not in budgets, "formal V02 duplicate budget event")
            budgets[current] = {name: value for name, value in event.items()
                                if name not in ("event", "sequence", "utc")}
    audit._require(set(budgets) == set(selections), "formal V02 missing budget event")
    for window in windows:
        key = audit._key(window)
        folder = root / "calibration" / key
        result = audit._json(folder / "result.json")
        audit._require(result["failures"] == failure_events[key], "formal V02 candidate failure event evidence")
        audit._frozen_budget(budgets[key])
        with np.load(folder / "raw.npz", allow_pickle=False) as raw:
            calibration[key] = audit._calibration_audit(raw, result, config, window, dates, weather, flows)
        audit._require(selections[key] == calibration[key]["selected"], "formal V02 independent raw selection ranking")
        arms = audit._expected_arms(calibration[key]["selected"], window["months"] == 3)
        assessments[key] = []
        folder = root / "assessment" / key
        summaries = audit._json(folder / "metadata.json")["arm_summaries"]
        audit._require(len(summaries) == len(arms), "formal V02 assessment arm count")
        for rank, arm in enumerate(arms):
            stem = folder / "arms" / f"{rank:02d}__{arm['name']}__complete"
            metadata = audit._json(stem.with_suffix(".json"))
            audit._require(metadata == summaries[rank], "formal V02 immediate arm summary evidence")
            expected_failures.extend(dict(window=key, arm=arm["name"], checkpoint=False, **failure)
                                     for failure in metadata["failures"])
            with np.load(stem.with_suffix(".npz"), allow_pickle=False) as raw:
                assessments[key].append(audit._assessment_audit(
                    raw, metadata, arm, window, config, dates, weather, flows, reference))
        with np.load(folder / "arrays.npz", allow_pickle=False) as shared:
            start = int(np.searchsorted(dates, np.datetime64(window["assessment_start"], "h")))
            stop = int(np.searchsorted(dates, np.datetime64(window["assessment_stop"], "h")))
            origins = audit._origins(dates, start, stop, 120)
            targets = origins[:, None] + np.arange(1, 121)[None]
            audit._same(shared["origin_indices"], origins, "formal V02 shared assessment origins")
            audit._same(shared["target_observations"], flows[targets], "formal V02 shared assessment targets")
            audit._same(shared["persistence_predictions"], np.broadcast_to(flows[origins, None], targets.shape),
                        "formal V02 shared persistence")
    failures = [json.loads(line) for line in (root / "failures.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
    audit._require(failures == expected_failures, "formal V02 whole assessment failure log")
    report = {
        "schema": "regge_short_record_independent_audit_v02",
        "passed": True,
        "run_dir": str(root),
        "calibration": calibration,
        "assessments": assessments,
        "reference_verification": prefix,
        "original_inputs": original_inputs,
        "resources": resources,
        **audit._comparison_tables(windows, assessments, config["leads"]),
        "limits": [
            "Development retrospective evaluation using observed future precipitation and potential evapotranspiration.",
            "Overlapping windows are not independent statistical samples.",
            "No independent replay of complete formal filtering histories; origin states have only 129-hour independent log-reference prefix fidelity evidence.",
            "Full forecast reconstruction validates propagation from saved global states, not all filtering origins.",
            "Finite-budget staged selection is not global optimality; thresholds are proposed research criteria.",
        ],
    }
    _validate_source_set(binding)
    audit._source_binding(root, receipt)
    audit._require(audit._manifest(root) == manifest, "formal V02 artifacts changed during independent audit")
    json.dumps(report, allow_nan=False)
    return report
