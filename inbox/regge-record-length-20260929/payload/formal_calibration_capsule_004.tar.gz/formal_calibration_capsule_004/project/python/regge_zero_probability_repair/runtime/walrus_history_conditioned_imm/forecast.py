"""Single-global-state deterministic forecasts; no observation input is accepted."""
import torch

from .walrus import parameter_tensors, walrus_step


def forecast_global_state(initial_state, future_forcing, candidate_parameters,
                          probabilities, transition_matrix, leads, *, evolve):
    """Return discharge [batch,len(leads)] in supplied lead order.

    future_forcing [batch,hours,2] starts at the FIRST future hour. Evolving
    forecasts advance probabilities with the unchanged origin matrix before
    each state step. Frozen forecasts retain origin probabilities. Neither
    operator carries a covariance or separately propagates candidate states.
    """
    leads = tuple(leads)
    if not leads or any(not isinstance(lead, int) or lead < 1 for lead in leads):
        raise ValueError("leads must contain positive integer hours")
    if max(leads) > future_forcing.shape[-2]:
        raise ValueError("future_forcing does not cover every requested lead")
    x = initial_state
    bank = parameter_tensors(candidate_parameters, x)
    p = torch.as_tensor(probabilities, dtype=x.dtype, device=x.device)
    matrix = torch.as_tensor(transition_matrix, dtype=x.dtype, device=x.device)
    predictions = {}
    for hour in range(1, max(leads) + 1):
        if evolve:
            p = torch.matmul(p.unsqueeze(-2), matrix).squeeze(-2)
        weighted = {key: (p * value).sum(dim=-1) if value.ndim else value for key, value in bank.items()}
        x = walrus_step(x, future_forcing[:, hour - 1], weighted)
        if hour in leads:
            predictions[hour] = x[..., 4]
    return torch.stack([predictions[lead] for lead in leads], dim=-1)
