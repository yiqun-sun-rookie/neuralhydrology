"""Frozen Regge chronological noise search. Importing this module runs nothing.

Production configuration is an exact protocol, not a collection of tunable CLI
options. The separate underscore-prefixed synthetic entry never loads real data
and marks every artifact as test-only. No failed run can be resumed/overwritten.
"""
from __future__ import annotations

from dataclasses import fields
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import re
import time

import numpy as np
import torch

from .data import load_reference, validate_series
from .filter import FilterState
from .forecast import forecast_global_state
from .noise_filter import BatchedNoiseFilters
from .noise_search import (build_noise_design, forecast_metrics, relative_scores,
                           select_candidates, training_shortlist)


WORKTREE = Path('G:/wt/id23-readout')
SOURCE = Path('G:/github/pycharm/projects/paper-imm-variable-params')
PACKAGE = Path(__file__).resolve().parent
PARAMETERS = WORKTREE / 'results/regge_history_conditioned_imm/20260907-regge-history-development-001/parameters.json'
LEGACY = WORKTREE / '.superpowers/sdd/2026-09-09-regge-full-diagonal-noise-search/legacy-source-hashes.json'
ARM_NAMES = ['original_calibrated_single', 'selected_calibrated_single', 'calibrated_three_noise_imm',
             'original_five_parameter_imm', 'matched_five_parameter_imm',
             'matched_fifteen_full_interaction', 'matched_fifteen_equal_parameter_interaction']


def frozen_config():
    """Return a fresh complete production protocol; every value is enforced."""
    return {
        'schema': 'regge_full_diagonal_noise_v01', 'seed': 909001, 'budget': 128,
        'zero_branch_nonoriginal': 31, 'positive_branch': 96,
        'original_diagonal': [.014, .1, .0004, .12, 0.],
        'lower': [.00014, .001, .000004, .0012, .00000015],
        'upper': [1.4, 10., .04, 12., .0015],
        'observation_variance': 1.5e-5, 'alpha': .6874, 'beta': 2, 'kappa': -2,
        'initial_state': [140, 1000, 4, 1200, .1], 'initial_covariance_fraction': .001,
        'wetness_parameters': [200, 320, 450, 650, 900, 413.6718976768621],
        'warmup_years': [1999], 'training_years': [2000, 2001, 2002],
        'selection_years': [2003], 'assessment_years': [2004],
        'leads': [1, 24, 48, 120], 'shortlist_count': 8, 'keep': 3,
        'transition_diagonal': .99, 'origin_hour': 0, 'origin_stride_hours': 24,
        'forecast_probability_forms': ['frozen', 'evolving'],
        'parameter_readout': 'posterior_weighted',
        'selection_score': 'equal_mean_four_rmse_ratios_to_original_calibrated_single',
        'selection_tiebreak': ['selection_score', 'training_score', 'candidate_id'],
        'assessment_arms': list(ARM_NAMES), 'forecast_chunk_origins': 16,
        'progress_filter_hours': 720, 'torch_threads': 1, 'dtype': 'float64',
        'source_root': SOURCE.as_posix(), 'parameter_records': PARAMETERS.as_posix(),
        'legacy_manifest': LEGACY.as_posix(),
        'evidence': 'previously_inspected_development_perfect_forcing',
        'bounds_interpretation': 'prespecified_engineering_bounds_not_true_noise_bounds',
    }


def validate_config(config):
    expected = frozen_config()
    if config != expected:
        changed = sorted(k for k in set(config) | set(expected) if config.get(k) != expected.get(k))
        raise ValueError(f'Production protocol differs from frozen values: {changed}')


def _hash(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def _json_value(value):
    if isinstance(value, dict):
        return {str(k): _json_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_value(v) for v in value]
    if isinstance(value, np.ndarray):
        return _json_value(value.tolist())
    if isinstance(value, np.generic):
        return _json_value(value.item())
    if isinstance(value, float) and not np.isfinite(value):
        return None
    return value


class _Artifacts:
    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=False)
        self.started = time.perf_counter()
        self.sequence = 0
        self.peak_rss = 0
        self.filter_member_hours = 0
        self.forecast_member_origins = 0
        # Exclusive files establish one writer and retain failure evidence.
        for name in ['events.jsonl', 'failures.jsonl']:
            (self.root / name).touch(exist_ok=False)

    def event(self, event, **payload):
        self.sequence += 1
        record = dict(sequence=self.sequence, event=event,
                      utc=datetime.now(timezone.utc).isoformat(),
                      elapsed_seconds=time.perf_counter() - self.started, **payload)
        with (self.root / 'events.jsonl').open('a', encoding='utf-8') as stream:
            stream.write(json.dumps(_json_value(record), allow_nan=False) + '\n')
        if event in ['filter_progress', 'forecast_progress', 'phase_start', 'phase_complete']:
            print(json.dumps(_json_value(record), allow_nan=False), flush=True)
        try:
            import psutil
            self.peak_rss = max(self.peak_rss, psutil.Process().memory_info().rss)
        except ImportError:
            pass

    def failure(self, value):
        with (self.root / 'failures.jsonl').open('a', encoding='utf-8') as stream:
            stream.write(json.dumps(_json_value(value), allow_nan=False) + '\n')
        self.event('candidate_failure', **value)

    def json(self, name, value):
        with (self.root / name).open('x', encoding='utf-8') as stream:
            json.dump(_json_value(value), stream, indent=2, allow_nan=False)
            stream.write('\n')
        self.event('snapshot', file=name, sha256=_hash(self.root / name))

    def npz(self, name, **values):
        with (self.root / name).open('xb') as stream:
            np.savez(stream, **values)
        self.event('snapshot', file=name, sha256=_hash(self.root / name))

    def finalize(self, status, error=None):
        elapsed = time.perf_counter() - self.started
        registration = self.root / 'registration.json'
        if registration.exists():
            final = json.loads(registration.read_text(encoding='utf-8'))
            final.update(status=status, error=error, audit_path='audit.json',
                         metrics_path='assessment_metrics.json' if (self.root / 'assessment_metrics.json').exists()
                         else ('preflight_checks.json' if (self.root / 'preflight_checks.json').exists() else None))
            self.json('registry.json', final)
        self.json('runtime.json', dict(status=status, error=error, elapsed_seconds=elapsed,
                  peak_sampled_rss_bytes=self.peak_rss or None,
                  filter_member_hours=self.filter_member_hours,
                  filter_member_hours_per_wall_second=self.filter_member_hours / max(elapsed, 1e-9),
                  forecast_member_origins=self.forecast_member_origins,
                  python=platform.python_version(), numpy=np.__version__, torch=torch.__version__,
                  torch_threads=torch.get_num_threads(), device='cpu', dtype='float64'))
        # Final content manifest excludes itself and audit, avoiding circular hashes.
        manifest = {p.name: _hash(p) for p in sorted(self.root.iterdir()) if p.is_file()}
        with (self.root / 'artifacts.json').open('x', encoding='utf-8') as stream:
            json.dump(manifest, stream, indent=2)


def daily_origins(timestamps, start, stop, leads):
    """All midnight origins whose entire forecast stays within year AND phase."""
    dates = np.asarray(timestamps)
    indices = np.arange(start, max(start, stop - max(leads)), dtype=np.int64)
    midnight = dates[indices].astype('datetime64[h]').astype(np.int64) % 24 == 0
    same_year = dates[indices].astype('datetime64[Y]') == dates[indices + max(leads)].astype('datetime64[Y]')
    return indices[midnight & same_year]


def _slice_state(state, indices):
    return FilterState(*(getattr(state, field.name)[indices].clone() for field in fields(FilterState)))


def _is_numerical_failure(error):
    """Narrow numerical taxonomy. Shape/API/unknown engine errors stop the run."""
    if isinstance(error, (FloatingPointError, torch.linalg.LinAlgError)):
        return True
    message = str(error).lower()
    if isinstance(error, RuntimeError):
        return 'cholesky' in message or 'not positive-definite' in message
    return isinstance(error, ValueError) and message in {
        'state values and covariances must be finite',
        'probabilities must be finite and nonnegative',
        'every destination model must have strictly positive incoming probability',
        'state-interaction group has zero incoming probability',
    }


def isolated_step(adapter, state, forcing, observation, matrix, alive, labels, phase, index, date, record_failure):
    """Split only an unsuccessful batch; every subcall uses the unadvanced state.

    Failed members retain their old finite internal storage but are permanently
    excluded from updates, saved origins, and scoring. No jitter/clipping is added.
    """
    next_state = _slice_state(state, np.arange(adapter.batch_size))
    global_state = torch.full((adapter.batch_size, 5), float('nan'), dtype=torch.float64)
    global_cov = torch.full((adapter.batch_size, 5, 5), float('nan'), dtype=torch.float64)
    survivors = np.array(alive, copy=True)

    def visit(indices):
        if len(indices) == 0:
            return
        current = adapter if len(indices) == adapter.batch_size else adapter.subset(indices)
        original = _slice_state(state, indices)
        try:
            result = current.step(original, np.broadcast_to(forcing, (len(indices), 2)).copy(),
                                  np.full(len(indices), observation), matrix)
            tensors = [result.global_state, result.global_covariance, result.log_likelihoods,
                       result.filter_state.states, result.filter_state.covariances, result.filter_state.probabilities]
            if not all(torch.isfinite(tensor).all() for tensor in tensors):
                raise FloatingPointError('nonfinite posterior or likelihood')
            for field in fields(FilterState):
                getattr(next_state, field.name)[indices] = getattr(result.filter_state, field.name)
            global_state[indices] = result.global_state
            global_cov[indices] = result.global_covariance
        except (RuntimeError, ValueError, FloatingPointError) as error:
            if not _is_numerical_failure(error):
                raise
            if len(indices) > 1:
                middle = len(indices) // 2
                visit(indices[:middle])
                visit(indices[middle:])
            else:
                member = int(indices[0])
                survivors[member] = False
                record_failure(dict(**labels[member], phase=phase, stage='filter', index=int(index),
                                    date=str(date), reason=f'{type(error).__name__}: {error}'))

    visit(np.flatnonzero(alive))
    return next_state, global_state, global_cov, survivors


def _matrix(models):
    if models == 1:
        return torch.ones((1, 1), dtype=torch.float64)
    matrix = torch.full((models, models), .01 / (models - 1), dtype=torch.float64)
    matrix.fill_diagonal_(.99)
    return matrix


def _state_arrays(state):
    return {field.name: getattr(state, field.name).detach().numpy() for field in fields(FilterState)}


@torch.no_grad()
def _replay(art, phase, adapter, labels, dates, forcing, observations, start, stop, origins,
            state=None, alive=None):
    state = adapter.initial_state() if state is None else state
    alive = np.ones(adapter.batch_size, dtype=bool) if alive is None else alive.copy()
    matrix = _matrix(adapter.model_count)
    shapes = (adapter.batch_size, len(origins))
    global_states = np.full((*shapes, 5), np.nan)
    global_covariances = np.full((*shapes, 5, 5), np.nan)
    probabilities = np.full((*shapes, adapter.model_count), np.nan)
    origin_lookup = {int(index): position for position, index in enumerate(origins)}
    for index in range(start, stop):
        art.filter_member_hours += int(alive.sum())
        try:
            state, combined, covariance, alive = isolated_step(
                adapter, state, forcing[index], observations[index], matrix, alive, labels,
                phase, index, dates[index], art.failure)
        except BaseException:
            art.npz(f'{phase}_partial.npz', **_state_arrays(state), alive=alive,
                    last_completed_index=index-1, failed_index=index, origin_indices=origins,
                    global_states=global_states, global_covariances=global_covariances, origin_probabilities=probabilities)
            raise
        if index in origin_lookup:
            column = origin_lookup[index]
            global_states[:, column] = combined.numpy()
            global_covariances[:, column] = covariance.numpy()
            probabilities[alive, column] = state.probabilities[alive].numpy()
        if (index - start + 1) % 720 == 0 or index == stop - 1:
            art.event('filter_progress', phase=phase, index=index, date=str(dates[index]),
                      alive=int(alive.sum()), members=adapter.batch_size)
    return state, alive, dict(global_states=global_states, global_covariances=global_covariances,
                             probabilities=probabilities)


@torch.no_grad()
def _forecast(art, phase, adapter, labels, dates, forcing, origins, snapshots, alive, leads, chunk_size):
    """Flatten members x origins with broadcast parameter mappings, never scalar stacks."""
    predictions = {form: np.full((adapter.batch_size, len(origins), len(leads)), np.nan)
                   for form in ['frozen', 'evolving']}
    survivors = alive.copy()
    bank = adapter.engine.candidate_parameters
    matrix = _matrix(adapter.model_count)

    def visit(members, columns):
        members = members[survivors[members]]
        if not len(members) or not len(columns):
            return
        n, c = len(members), len(columns)
        try:
            states = torch.from_numpy(snapshots['global_states'][members[:, None], columns]).reshape(n*c, 5)
            probability = torch.from_numpy(snapshots['probabilities'][members[:, None], columns]).reshape(n*c, -1)
            future_indices = origins[columns, None] + np.arange(1, max(leads) + 1)
            future = torch.from_numpy(forcing[future_indices]).unsqueeze(0).expand(n, -1, -1, -1).reshape(n*c, max(leads), 2)
            mappings = {key: value[members, None, :].expand(-1, c, -1).reshape(n*c, -1) for key, value in bank.items()}
            results = {}
            for form in predictions:
                result = forecast_global_state(states, future, mappings, probability, matrix,
                                               tuple(leads), evolve=form == 'evolving')
                if not torch.isfinite(result).all():
                    raise FloatingPointError(f'nonfinite {form} deterministic forecast')
                results[form] = result.reshape(n, c, -1).numpy()
            for form, value in results.items():
                predictions[form][members[:, None], columns] = value
            art.forecast_member_origins += n*c
        except (RuntimeError, ValueError, FloatingPointError) as error:
            if not _is_numerical_failure(error):
                raise
            if n > 1:
                split = n // 2
                visit(members[:split], columns)
                visit(members[split:], columns)
            elif c > 1:
                split = c // 2
                visit(members, columns[:split])
                visit(members, columns[split:])
            else:
                member, index = int(members[0]), int(origins[columns[0]])
                survivors[member] = False
                art.failure(dict(**labels[member], phase=phase, stage='forecast', index=index,
                                 date=str(dates[index]), reason=f'{type(error).__name__}: {error}'))

    for start in range(0, len(origins), chunk_size):
        columns = np.arange(start, min(start + chunk_size, len(origins)))
        visit(np.flatnonzero(survivors), columns)
        art.event('forecast_progress', phase=phase, completed_origins=int(columns[-1] + 1),
                  total_origins=len(origins), alive=int(survivors.sum()))
    for values in predictions.values():
        values[~survivors] = np.nan  # Whole-phase invalidation, never favorable-origin deletion.
    return predictions, survivors


def score_phase(predictions, targets, reference_position):
    result = forecast_metrics(predictions, targets)
    scores = relative_scores(result['rmse'], result['rmse'][reference_position])
    return dict(**result, scores=scores)


def _metrics(art, phase, labels, predictions, targets, reference, dates, origins, training_scores=None):
    result = score_phase(predictions['frozen'], targets, reference)
    rows = [dict(**label, valid=bool(result['valid'][i]), rmse=result['rmse'][i], score=result['scores'][i])
            for i, label in enumerate(labels)]
    rankings = {}
    for record in sorted({label['record'] for label in labels}):
        indices = [i for i, label in enumerate(labels) if label['record'] == record]
        def key(i):
            label = labels[i]
            training = 0. if training_scores is None else training_scores[(record, label['candidate'])]
            return (result['scores'][i], training, label['candidate'])
        rankings[str(record)] = [labels[i]['candidate'] for i in sorted(indices, key=key)]
    yearly = {}
    years = dates[origins].astype('datetime64[Y]').astype(int) + 1970
    for year in np.unique(years):
        mask = years == year
        scores = score_phase(predictions['frozen'][:, mask], targets[mask], reference)
        yearly[str(year)] = dict(rmse=scores['rmse'], scores=scores['scores'], origins=int(mask.sum()))
    art.json(f'{phase}_metrics.json', dict(rows=rows, rankings=rankings, by_year=yearly,
                                         reference_position=reference, origins=len(origins)))
    return result['scores']


def _phase(art, phase, adapter, labels, dates, forcing, observations, bounds, leads, chunk,
           replay_start=0, state=None, alive=None, training_positions=None):
    start, stop = bounds
    origins = daily_origins(dates, start, stop, leads)
    if not len(origins):
        raise ValueError(f'No complete origins in {phase}')
    art.event('phase_start', phase=phase, replay_start=replay_start, replay_stop=stop,
              score_start=start, score_stop=stop, members=adapter.batch_size, models=adapter.model_count)
    art.json(f'{phase}_members.json', labels)
    if state is None:
        state = adapter.initial_state()
    start_extra = {} if training_positions is None else {'training_positions': training_positions}
    art.npz(f'{phase}_start.npz', **_state_arrays(state), first_index=replay_start, **start_extra)
    state, alive, snapshots = _replay(art, phase, adapter, labels, dates, forcing, observations,
                                     replay_start, stop, origins, state, alive)
    art.npz(f'{phase}_end.npz', **_state_arrays(state), alive=alive, last_index=stop - 1)
    predictions, alive = _forecast(art, phase, adapter, labels, dates, forcing, origins, snapshots,
                                   alive, leads, chunk)
    targets = origins[:, None] + np.asarray(leads)[None, :]
    art.npz(f'{phase}.npz', **snapshots, **predictions, alive=alive,
            origin_indices=origins, target_indices=targets,
            origin_dates=dates[origins].astype('datetime64[s]').astype(np.int64),
            target_dates=dates[targets].astype('datetime64[s]').astype(np.int64),
            targets=observations[targets])
    art.event('phase_complete', phase=phase, valid_members=int(alive.sum()))
    return state, alive, predictions, observations[targets], origins


def assessment_banks(records, design, selected):
    """Seven frozen arms with provenance for every constituent filter."""
    selected = {int(key): value for key, value in selected.items()}
    members = [([(5, 0)], None), ([(5, selected[5][0])], None),
               ([(5, c) for c in selected[5]], None),
               ([(p, 0) for p in range(5)], None),
               ([(p, selected[p][0]) for p in range(5)], None),
               ([(p, c) for p in range(5) for c in selected[p]], None),
               ([(p, c) for p in range(5) for c in selected[p]], [p for p in range(5) for _ in selected[p]])]
    return [dict(name=name, members=[dict(record=p, candidate=c) for p, c in pairs],
                 parameters=[records[p] for p, _ in pairs], diagonals=[design[c].tolist() for _, c in pairs],
                 interaction_groups=groups, transition_matrix=_matrix(len(pairs)).tolist())
            for name, (pairs, groups) in zip(ARM_NAMES, members)]


def _execute(art, config, dates, forcing, observations, records, design, phases):
    count = len(design)
    labels = [dict(record=p, candidate=c) for p in range(6) for c in range(count)]
    adapter = BatchedNoiseFilters([[records[label['record']]] for label in labels],
                                  np.asarray([[design[label['candidate']]] for label in labels]))
    art.event('search_budget', parameters=6, candidates_per_parameter=count, total=6*count)
    state, alive, pred, targets, origins = _phase(
        art, 'training', adapter, labels, dates, forcing, observations, phases['training'],
        config['leads'], config['forecast_chunk_origins'])
    scores = _metrics(art, 'training', labels, pred, targets, 5*count, dates, origins)
    shortlist = {str(p): training_shortlist(scores[p*count:(p+1)*count], config['shortlist_count']) for p in range(6)}
    art.json('shortlist.json', shortlist)  # Must precede any 2003 filtering/scoring.
    positions = np.array([p*count+c for p in range(6) for c in shortlist[str(p)]], dtype=np.int64)
    short_labels = [labels[i] for i in positions]
    training_scores = {(label['record'], label['candidate']): float(scores[i]) for i, label in enumerate(labels)}
    short_adapter = adapter.subset(positions)
    _, _, pred, targets, origins = _phase(
        art, 'selection', short_adapter, short_labels, dates, forcing, observations, phases['selection'],
        config['leads'], config['forecast_chunk_origins'], replay_start=phases['training'][1],
        state=_slice_state(state, positions), alive=alive[positions], training_positions=positions)
    reference = next(i for i, label in enumerate(short_labels) if label == dict(record=5, candidate=0))
    selection_scores = _metrics(art, 'selection', short_labels, pred, targets, reference, dates, origins, training_scores)
    selected = {}
    for p in range(6):
        ix = [i for i, label in enumerate(short_labels) if label['record'] == p]
        selected[str(p)] = select_candidates(shortlist[str(p)],
            [training_scores[(p, c)] for c in shortlist[str(p)]], selection_scores[ix], keep=config['keep'])
    art.json('selected.json', selected)
    arms = assessment_banks(records, design, selected)
    art.json('assessment_arms.json', arms)  # Complete vectors are frozen before any assessment replay.
    assessment = {}
    for models in sorted({len(arm['members']) for arm in arms}):
        group = [arm for arm in arms if len(arm['members']) == models]
        groups = [arm['interaction_groups'] if arm['interaction_groups'] is not None else [0]*models for arm in group]
        # Full arms share one group; restricted arm retains parameter groups.
        batch = BatchedNoiseFilters([arm['parameters'] for arm in group],
                                    [arm['diagonals'] for arm in group], interaction_groups=groups)
        phase = f'assessment_m{models}'
        _, _, pred, targets, origins = _phase(
            art, phase, batch, [dict(arm=arm['name']) for arm in group], dates, forcing, observations,
            phases['assessment'], config['leads'], config['forecast_chunk_origins'])
        for i, arm in enumerate(group):
            assessment[arm['name']] = {form: forecast_metrics(values[i:i+1], targets) for form, values in pred.items()}
    summary = {}
    for form in ['frozen', 'evolving']:
        reference = assessment[ARM_NAMES[0]][form]['rmse'][0]
        summary[form] = {arm: dict(rmse=assessment[arm][form]['rmse'][0],
                         valid=bool(assessment[arm][form]['valid'][0]),
                         score=relative_scores(assessment[arm][form]['rmse'], reference)[0]) for arm in ARM_NAMES}
    art.json('assessment_metrics.json', dict(by_year={'2004' if not config.get('test_only') else 'synthetic': summary},
                                           probability_forms=summary))
    return selected


def _verify_legacy():
    manifest = json.loads(LEGACY.read_text(encoding='utf-8'))
    for row in manifest:
        if _hash(row['path']) != row['sha256']:
            raise RuntimeError(f"Legacy source hash changed: {row['path']}")
    return manifest


def _freeze(art, config, records, design, dates, forcing, observations, phases, inputs, legacy):
    art.json('config.json', config)
    art.json('parameters.json', records)
    art.npz('design.npz', diagonals=design, candidate_ids=np.arange(len(design)))
    art.json('design_provenance.json', dict(seed=config['seed'], array_sha256=hashlib.sha256(design.tobytes()).hexdigest(),
              shape=list(design.shape), rng='numpy.default_rng; whole jitter array then column permutations',
              budget_per_parameter=len(design), parameter_count=6))
    art.json('phases.json', phases)
    art.json('input_hashes_before.json', inputs)
    art.json('legacy_source_hashes.json', legacy)
    art.npz('series.npz', timestamps=dates.astype('datetime64[s]').astype(np.int64),
            forcing=forcing, observations=observations)
    art.json('registration.json', dict(run_id=art.root.name, exp_id=art.root.name,
              type='numerical_preflight' if config.get('mode') == 'preflight' else 'noise_search_and_control_comparison',
              hypothesis='Compare optimized noise, parameter-bank changes, and equal-bank interaction separately',
              base_config='config.json', changed_factor='process_noise_diagonal_and_frozen_assessment_arm',
              fixed_factors=['hydrological_parameters', 'observations', 'forcing', 'initial_conditions', 'filter_equations'],
              seeds=[config['seed']], best_checkpoint=None, metrics_path=None,
              paper_name='Adaptive State Updating for Flood Forecasting Under Joint Parameter and Noise Uncertainty',
              notes='Finite prespecified search; not global optimality or true-noise identification. Audit determines acceptance.',
              run_dir=str(art.root.resolve()),
              evidence=config['evidence'], status='registered', config_sha256=_hash(art.root / 'config.json'),
              design_sha256=_hash(art.root / 'design.npz'), parameters_sha256=_hash(art.root / 'parameters.json')))


def _finish_audit(art):
    from .noise_audit import audit_noise_run
    result = audit_noise_run(art.root)
    with (art.root / 'audit.json').open('x', encoding='utf-8') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
    return result


def run_noise_search(config_path, output_root, run_id, *, preflight=False):
    """Execute the frozen scientific run only when explicitly invoked by caller."""
    config_path = Path(config_path).resolve()
    config = json.loads(config_path.read_text(encoding='utf-8'))
    validate_config(config)
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,95}', run_id):
        raise ValueError('run_id must be a single safe directory name')
    root = Path(output_root)
    if '..' in root.parts or WORKTREE.resolve() not in root.resolve().parents:
        raise ValueError('output_root must be strictly inside the allowed worktree')
    if root.resolve() == PACKAGE or PACKAGE in root.resolve().parents:
        raise ValueError('Results cannot be written into source code')
    art = _Artifacts(root / run_id)
    old_threads = torch.get_num_threads()
    inputs = {}
    try:
        torch.set_num_threads(1)
        legacy = _verify_legacy()
        data_path = SOURCE / 'forecast/data/PEQ_Regge_hour.txt'
        if not data_path.exists():
            data_path = SOURCE / 'for_submit/forecast/data/PEQ_Regge_hour.txt'
        paths = [config_path, PARAMETERS, LEGACY, data_path, *sorted((SOURCE / 'python/imm_da').glob('*.py')),
                 *sorted(PACKAGE.glob('*.py')), PACKAGE / 'scripts/run_noise_search.py']
        inputs = {str(p.resolve()): _hash(p) for p in paths}
        art.json('provenance_before_load.json', inputs)
        dates, forcing, observations, _, loaded = load_reference(SOURCE)
        if any(str(Path(p).resolve()) not in inputs for p in loaded):
            raise RuntimeError('Unhashed input returned by reference loader')
        raw = json.loads(PARAMETERS.read_text(encoding='utf-8'))
        records = raw['candidate_records'] + [raw['calibrated_reference']]
        if [p['cw'] for p in records] != config['wetness_parameters']:
            raise ValueError('Parameter provenance differs from frozen records')
        validate_series(dates, forcing, observations)
        years = dates.astype('datetime64[Y]').astype(int) + 1970
        if len(dates) != 52607 or years[0] != 1999 or years[-1] != 2004:
            raise ValueError('Reference retained series does not match frozen 52607-hour period')
        phases = {name: [int(np.flatnonzero(np.isin(years, config[name + '_years']))[0]),
                         int(np.flatnonzero(np.isin(years, config[name + '_years']))[-1] + 1)]
                  for name in ['training', 'selection', 'assessment']}
        design = build_noise_design(config['seed'])
        if preflight:
            # Numerical workload only: first 256 early-1999 inputs, no rank/score/selection.
            config = dict(config, mode='preflight')
            dates, forcing, observations = dates[:256], forcing[:256], observations[:256]
            _freeze(art, config, records, design, dates, forcing, observations, {}, inputs, legacy)
            labels = [dict(record=p, candidate=c) for p in range(6) for c in range(128)]
            adapter = BatchedNoiseFilters([[records[label['record']]] for label in labels],
                                          [[design[label['candidate']]] for label in labels])
            origin = np.array([128], dtype=np.int64)
            _, alive, snapshots = _replay(art, 'preflight', adapter, labels, dates, forcing, observations, 0, 129, origin)
            pred, alive = _forecast(art, 'preflight', adapter, labels, dates, forcing, origin, snapshots,
                                     alive, config['leads'], 1)
            targets = origin[:, None] + np.asarray(config['leads'])
            art.npz('preflight.npz', **snapshots, **pred, alive=alive,
                    origin_indices=origin, origin_dates=dates[origin].astype('datetime64[s]').astype(np.int64),
                    target_indices=targets, target_dates=dates[targets].astype('datetime64[s]').astype(np.int64),
                    filter_start_index=np.array(0), filter_stop_index=np.array(129))
            art.json('preflight_checks.json', dict(finite_states=bool(np.isfinite(snapshots['global_states']).all()),
                                                 finite_forecasts=bool(all(np.isfinite(v).all() for v in pred.values())),
                                                 members=768, selection_performed=False))
            if not alive.all():
                raise RuntimeError('Preflight numerical member failure; preserve and diagnose')
        else:
            _freeze(art, config, records, design, dates, forcing, observations, phases, inputs, legacy)
            _execute(art, config, dates, forcing, observations, records, design, phases)
        _verify_legacy()
        after = {path: _hash(path) for path in inputs}
        art.json('input_hashes_after.json', after)
        if inputs != after:
            raise RuntimeError('Code/data inputs changed during run')
        art.finalize('preflight_complete' if preflight else 'complete')
    except BaseException as error:
        if not (art.root / 'runtime.json').exists():
            if inputs and not (art.root / 'input_hashes_after.json').exists():
                art.json('input_hashes_after.json', {path: _hash(path) if Path(path).exists() else None for path in inputs})
            art.finalize('failed', f'{type(error).__name__}: {error}')
        _finish_audit(art)
        raise
    finally:
        torch.set_num_threads(old_threads)
    audit = _finish_audit(art)
    if not audit['passed']:
        raise RuntimeError(f"Independent artifact audit failed: {audit['errors']}")
    return dict(run_dir=str(art.root), audit=audit)


def _run_synthetic_test(run_dir, *, timestamps, forcing, observations, records, design, phases,
                        leads, shortlist_count, keep):
    """Explicit TEST-ONLY in-memory entry. It cannot load or score production data.

    Small contiguous arrays have artificial phase boundaries. Artifacts are
    permanently tagged synthetic and cannot pass the production protocol audit.
    """
    dates = np.asarray(timestamps).astype('datetime64[s]')
    forcing, observations, design = map(lambda x: np.asarray(x, dtype=np.float64), (forcing, observations, design))
    if len(dates) > 1000 or len(design) > 8 or len(records) != 6 or len(leads) != 4 or keep != 3:
        raise ValueError('Synthetic test helper permits only tiny arrays, six records and three selected noises')
    if not np.all(np.diff(dates) == np.timedelta64(3600, 's')):
        raise ValueError('Synthetic timestamps must still be exactly hourly')
    if phases['training'][1] != phases['selection'][0] or phases['selection'][1] != phases['assessment'][0]:
        raise ValueError('Synthetic phase boundaries must be adjacent')
    if phases['assessment'][1] != len(dates):
        raise ValueError('Synthetic assessment must end at data boundary')
    config = dict(frozen_config(), test_only=True, evidence='synthetic_test_only', budget=len(design),
                  leads=leads, shortlist_count=shortlist_count, keep=keep, forecast_chunk_origins=2)
    art = _Artifacts(run_dir)
    old_threads = torch.get_num_threads()
    torch.set_num_threads(1)
    try:
        _freeze(art, config, records, design, dates, forcing, observations, phases, {}, [])
        _execute(art, config, dates, forcing, observations, records, design, phases)
        art.json('input_hashes_after.json', {})
        art.finalize('complete')
    except BaseException as error:
        if not (art.root / 'runtime.json').exists():
            art.finalize('failed', f'{type(error).__name__}: {error}')
        raise
    finally:
        torch.set_num_threads(old_threads)
    return dict(run_dir=str(art.root))
