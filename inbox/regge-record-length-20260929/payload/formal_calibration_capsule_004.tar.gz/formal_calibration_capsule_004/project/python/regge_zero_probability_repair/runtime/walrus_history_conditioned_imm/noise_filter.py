"""Batched adapters over the unchanged Regge filtering and forecast equations."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, is_dataclass
from collections.abc import Mapping, Sequence

import numpy as np
import torch

from .filter import DifferentiableWalrusIMM, FilterState
from .forecast import forecast_global_state


def _record_mapping(record):
    if is_dataclass(record):
        record = asdict(record)
    if not isinstance(record, Mapping) or not record:
        raise ValueError("every parameter record must be a nonempty mapping or dataclass")
    return record


def _normalize_parameter_banks(parameter_banks):
    if not isinstance(parameter_banks, Sequence) or isinstance(parameter_banks, (str, bytes)) or not parameter_banks:
        raise ValueError("parameter_banks must contain at least one batch member")
    banks = []
    expected_models = None
    expected_keys = None
    for bank in parameter_banks:
        if not isinstance(bank, Sequence) or isinstance(bank, (str, bytes)) or not bank:
            raise ValueError("each parameter bank must contain at least one model")
        records = []
        if expected_models is None:
            expected_models = len(bank)
        elif len(bank) != expected_models:
            raise ValueError("all parameter banks must have the same model count")
        for record in bank:
            mapping = _record_mapping(record)
            keys = tuple(mapping.keys())
            if expected_keys is None:
                expected_keys = keys
            elif set(keys) != set(expected_keys):
                raise ValueError("all parameter records must contain identical fields")
            try:
                normalized = {key: float(mapping[key]) for key in expected_keys}
            except (TypeError, ValueError) as error:
                raise ValueError("parameter values must be numeric scalars") from error
            if not np.isfinite(np.fromiter(normalized.values(), dtype=np.float64)).all():
                raise ValueError("parameter values must be finite")
            records.append(normalized)
        banks.append(records)
    arrays = {key: np.asarray([[record[key] for record in bank] for bank in banks], dtype=np.float64)
              for key in expected_keys}
    tensors = {key: torch.from_numpy(value.copy()) for key, value in arrays.items()}
    return banks, tensors


def _normalize_groups(groups, batch_size, model_count):
    if groups is None:
        return None, None
    array = np.asarray(groups, dtype=object)
    if array.shape != (batch_size, model_count):
        raise ValueError("interaction_groups must have shape [batch, models]")
    for label in array.flat:
        if label is None:
            raise ValueError("interaction_groups cannot contain missing labels")
        try:
            if bool(np.isnan(label)):
                raise ValueError("interaction_groups cannot contain missing labels")
        except TypeError:
            pass
    mask = np.empty((batch_size, model_count, model_count), dtype=bool)
    for member in range(batch_size):
        mask[member] = array[member, :, None] == array[member, None, :]
    return array.copy(), torch.from_numpy(mask)


def _transition_tensor(matrix, batch_size, model_count, reference):
    value = torch.as_tensor(matrix, dtype=reference.dtype, device=reference.device)
    if value.ndim == 2:
        if value.shape != (model_count, model_count):
            raise ValueError("transition matrix must have shape [models, models]")
        expanded = value.unsqueeze(0).expand(batch_size, -1, -1)
    elif value.ndim == 3:
        if value.shape != (batch_size, model_count, model_count):
            raise ValueError("batched transition matrix must have shape [batch, models, models]")
        expanded = value
    else:
        raise ValueError("transition matrix must be two- or three-dimensional")
    if not torch.isfinite(expanded).all() or torch.any(expanded < 0):
        raise ValueError("transition probabilities must be finite and nonnegative")
    if not torch.allclose(expanded.sum(dim=-1), torch.ones((batch_size, model_count), dtype=reference.dtype,
                                                           device=reference.device), rtol=1e-10, atol=1e-12):
        raise ValueError("every transition-matrix row must sum to one")
    return value, expanded


def _validate_probabilities(probabilities, batch_size, model_count):
    if probabilities.shape != (batch_size, model_count):
        raise ValueError("probabilities must have shape [batch, models]")
    if not torch.isfinite(probabilities).all() or torch.any(probabilities < 0):
        raise ValueError("probabilities must be finite and nonnegative")
    if not torch.allclose(probabilities.sum(dim=-1), torch.ones(batch_size, dtype=probabilities.dtype,
                                                                device=probabilities.device), rtol=1e-10, atol=1e-12):
        raise ValueError("probabilities must sum to one without normalization")


class BatchedNoiseFilters:
    """Run differently parameterized/noised filters in one tensor batch."""

    def __init__(self, parameter_banks, diagonals, observation_variance=1.5e-5, interaction_groups=None):
        banks, mappings = _normalize_parameter_banks(parameter_banks)
        batch_size, model_count = len(banks), len(banks[0])
        diagonal_array = np.asarray(diagonals, dtype=np.float64)
        if diagonal_array.shape != (batch_size, model_count, 5):
            raise ValueError("diagonals must have shape [batch, models, 5]")
        if not np.isfinite(diagonal_array).all() or np.any(diagonal_array < 0):
            raise ValueError("process-noise diagonals must be finite and nonnegative")
        if not np.isfinite(observation_variance) or observation_variance <= 0:
            raise ValueError("observation_variance must be finite and strictly positive")
        groups, group_mask = _normalize_groups(interaction_groups, batch_size, model_count)

        covariance = torch.diag_embed(torch.from_numpy(diagonal_array.copy()))
        engine = DifferentiableWalrusIMM(banks[0], covariance, float(observation_variance))
        engine.candidate_parameters = mappings
        self._engine = engine
        self._parameter_banks = deepcopy(banks)
        self._parameter_mappings = mappings
        self._diagonals = diagonal_array.copy()
        self._groups = groups
        self._group_mask = group_mask
        self._batch_size = batch_size
        self._model_count = model_count
        self._observation_variance = float(observation_variance)

    @property
    def engine(self):
        return self._engine

    @property
    def batch_size(self):
        return self._batch_size

    @property
    def model_count(self):
        return self._model_count

    def initial_state(self):
        """Return the original immutable FilterState container."""
        return self._engine.initial_state(self._batch_size)

    def _validate_state(self, state):
        if not isinstance(state, FilterState):
            raise ValueError("state must be a FilterState")
        expected = (self._batch_size, self._model_count)
        if state.states.shape != (*expected, 5):
            raise ValueError("state values must have shape [batch, models, 5]")
        if state.covariances.shape != (*expected, 5, 5):
            raise ValueError("state covariances must have shape [batch, models, 5, 5]")
        if not torch.isfinite(state.states).all() or not torch.isfinite(state.covariances).all():
            raise ValueError("state values and covariances must be finite")
        _validate_probabilities(state.probabilities, *expected)

    def step(self, state, forcing, observations, matrix):
        """Perform one unchanged filter update, with optional grouped interaction."""
        self._validate_state(state)
        forcing_value = torch.as_tensor(forcing, dtype=state.states.dtype, device=state.states.device)
        observation_value = torch.as_tensor(observations, dtype=state.states.dtype, device=state.states.device)
        if forcing_value.shape != (self._batch_size, 2):
            raise ValueError("forcing must have shape [batch, 2]")
        if observation_value.shape != (self._batch_size,):
            raise ValueError("observations must have shape [batch]")
        if not torch.isfinite(forcing_value).all() or not torch.isfinite(observation_value).all():
            raise ValueError("forcing and observations must be finite")
        matrix_value, expanded_matrix = _transition_tensor(matrix, self._batch_size, self._model_count,
                                                            state.states)
        incoming = state.probabilities.unsqueeze(-1) * expanded_matrix
        prior = incoming.sum(dim=1)
        if torch.any(prior <= 0) or not torch.isfinite(prior).all():
            raise ValueError("every destination model must have strictly positive incoming probability")

        if self._group_mask is None:
            return self._engine.step(state, forcing_value, observation_value, matrix_value)

        mask = self._group_mask.to(device=state.states.device)
        within_group = torch.where(mask, incoming, torch.zeros_like(incoming))
        group_mass = within_group.sum(dim=1)
        singleton = mask.sum(dim=1) == 1
        if (not torch.isfinite(group_mass).all()
                or torch.any((~singleton) & (group_mass <= 0))):
            raise ValueError("state-interaction group has zero incoming probability")
        # A singleton always retains its own state, including at zero weight.
        denominator = torch.where(singleton, torch.ones_like(group_mass), group_mass)
        normalized = within_group / denominator.unsqueeze(1)
        identity = torch.eye(self._model_count, dtype=state.states.dtype,
                             device=state.states.device).unsqueeze(0)
        mixing = torch.where(singleton.unsqueeze(1), identity, normalized).transpose(1, 2)
        mixed_state = torch.einsum("bji,bid->bjd", mixing, state.states)
        delta = state.states[:, None] - mixed_state[:, :, None]
        mixed_covariance = torch.einsum(
            "bji,bjide->bjde",
            mixing,
            state.covariances[:, None] + delta.unsqueeze(-1) * delta.unsqueeze(-2),
        )
        identity = torch.eye(self._model_count, dtype=state.states.dtype, device=state.states.device)
        prepared = FilterState(mixed_state, mixed_covariance, prior)
        return self._engine.step(prepared, forcing_value, observation_value, identity)

    def subset(self, indices):
        """Return an equivalent adapter containing selected batch members."""
        values = np.asarray(indices)
        if values.ndim != 1 or values.size == 0 or not np.issubdtype(values.dtype, np.integer):
            raise ValueError("indices must be a nonempty one-dimensional integer sequence")
        values = values.astype(np.int64, copy=False)
        if np.any(values < 0) or np.any(values >= self._batch_size):
            raise ValueError("subset index is outside the batch")
        groups = None if self._groups is None else self._groups[values]
        return BatchedNoiseFilters([self._parameter_banks[index] for index in values], self._diagonals[values],
                                   self._observation_variance, groups)


def deterministic_forecasts(global_states, probabilities, future_forcing, parameter_banks, matrix,
                            leads=(1, 24, 48, 120), evolve=False):
    """Broadcast parameter banks into the unchanged single-global-state forecast."""
    banks, mappings = _normalize_parameter_banks(parameter_banks)
    batch_size, model_count = len(banks), len(banks[0])
    states = torch.as_tensor(global_states)
    if not states.is_floating_point():
        states = states.to(torch.float64)
    probability = torch.as_tensor(probabilities, dtype=states.dtype, device=states.device)
    forcing = torch.as_tensor(future_forcing, dtype=states.dtype, device=states.device)
    if states.shape != (batch_size, 5):
        raise ValueError("global_states must have shape [batch, 5]")
    if forcing.ndim != 3 or forcing.shape[0] != batch_size or forcing.shape[2] != 2:
        raise ValueError("future_forcing must have shape [batch, hours, 2]")
    if not torch.isfinite(states).all() or not torch.isfinite(forcing).all():
        raise ValueError("global_states and future_forcing must be finite")
    _validate_probabilities(probability, batch_size, model_count)
    matrix_value, _ = _transition_tensor(matrix, batch_size, model_count, states)
    device_mappings = {key: value.to(dtype=states.dtype, device=states.device) for key, value in mappings.items()}
    return forecast_global_state(states, forcing, device_mappings, probability, matrix_value, tuple(leads), evolve=evolve)
