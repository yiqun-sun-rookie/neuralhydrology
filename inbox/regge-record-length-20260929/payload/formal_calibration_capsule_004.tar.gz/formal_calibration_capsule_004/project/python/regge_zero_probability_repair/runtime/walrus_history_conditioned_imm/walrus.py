"""Tensor port of the read-only Regge WALRUS scalar equations and branch order.

Five state components are vadose storage deficit, groundwater depth, quickflow
level, surface-water level, and discharge. Forcing contains hourly precipitation
and potential evapotranspiration. External fluxes and minimum discharge level
remain zero, matching the agreed Regge experiment.
"""
from collections.abc import Mapping
from dataclasses import asdict, is_dataclass

import torch


def parameter_tensors(parameters, reference):
    """Normalize scalar/vector mappings or a sequence of parameter records.

    Conversion preserves the autograd graph of tensor-valued parameters.
    Mapping values follow normal broadcasting against the state leading axes.
    """
    if not isinstance(parameters, Mapping):
        records = [asdict(p) if is_dataclass(p) else p for p in parameters]
        parameters = {key: torch.stack([torch.as_tensor(p[key], dtype=reference.dtype,
                                                        device=reference.device) for p in records])
                      for key in records[0]}
    return {key: torch.as_tensor(value, dtype=reference.dtype, device=reference.device)
            for key, value in parameters.items()}


def pond_flood(dv, hs, dg, cd, as_, ag):
    """Sequential source branches; a branch may enable the following branch."""
    active = (dv < 0) | (hs > cd)
    pond = active & (dv < 0) & (hs <= cd)
    hs = torch.where(pond, hs + (-dv) * ag / as_, hs)
    dv = torch.where(pond, torch.zeros_like(dv), dv)
    flood = active & (dv >= 0) & (hs > cd)
    dv = torch.where(flood, dv - (hs - cd) * as_ / ag, dv)
    hs = torch.where(flood, cd, hs)
    both = active & (dv <= 0) & (hs >= cd)
    dv = torch.where(both, dv * ag - (hs - cd) * as_, dv)
    hs = torch.where(both, cd - dv, hs)
    dg = torch.where(active & (dv < 0), dv, dg)
    return dv, hs, dg


def walrus_step(states, forcing, parameters):
    """Advance states [...,5] with forcing [...,2], preserving source branches."""
    p = parameter_tensors(parameters, states)
    cw, cv, cg, cq = (p[k] for k in ("cw", "cv", "cg", "cq"))
    cd, cs, ag, as_ = (p[k] for k in ("cd", "cs", "ag", "as_"))
    b, psi, theta = (p[k] for k in ("b", "psi_ae", "theta_s"))
    dv0, dg0, hq_raw, hs0, q_raw = states.unbind(-1)
    hq0, q0 = hq_raw.clamp_min(0), q_raw.clamp_min(0)
    precipitation, etpot = forcing.unbind(-1)
    w = .5 * torch.cos(torch.minimum(dv0.clamp_min(0), cw) * torch.pi / cw) + .5
    # Inactive fractional powers receive positive arguments to keep backward finite.
    dg_power = torch.where(dg0 > psi, dg0, torch.ones_like(dg0))
    equilibrium = (dg0 - psi / (1 - b) - dg_power ** (1 - 1 / b) * psi ** (1 / b) / (1 - 1 / b)) * theta
    equilibrium = torch.where(dg0 > psi, equilibrium, torch.where(dg0 < 0, dg0, torch.zeros_like(dg0)))
    pq = precipitation * w * ag
    pv = precipitation * (1 - w) * ag
    ps = precipitation * as_
    beta = .5 * (1 - torch.tanh(.5 * p["zeta1"] * (dv0 - p["zeta2"])))
    etv = etpot * beta * ag
    ets = torch.where(hs0 < p["min_h"] * 1e3, torch.zeros_like(hs0), etpot * as_)
    fqs = hq0 / cq
    fgs = (cd - dg0 - hs0) * torch.maximum(cd - dg0, hs0) / cg
    dv = dv0 - (pv - etv - fgs) / ag
    dg = dg0 + (dv0 - equilibrium) / cv
    hq = hq0 + (pq - fqs) / ag
    hs = hs0 + (ps - ets + fgs + fqs - q0) / as_
    # Discharge is evaluated BEFORE ponding/flooding and safety corrections.
    lower = torch.where((hs > 0) & (hs <= cd), hs / cd, torch.ones_like(hs))
    upper = torch.where(hs > cd, (hs - cd) / cd, torch.ones_like(hs))
    discharge = torch.where(hs <= cd, cs * lower ** p["exps"], cs + cs * upper ** p["exps"])
    discharge = torch.where(hs <= 0, torch.zeros_like(discharge), discharge)
    dv, hs, dg = pond_flood(dv, hs, dg, cd, as_, ag)
    negative_hs = hs < -.001
    hq = torch.where((~negative_hs) & (hq < -.001), torch.full_like(hq, .001), hq)
    hs = torch.where(negative_hs, torch.full_like(hs, .1), hs)
    return torch.stack([dv, dg, hq, hs, discharge.clamp_min(0)], dim=-1)
