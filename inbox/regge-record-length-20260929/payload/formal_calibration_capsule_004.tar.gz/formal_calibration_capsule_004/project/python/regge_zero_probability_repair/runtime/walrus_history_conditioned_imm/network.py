"""Causal transition rules: callers supply features through the previous hour."""
import torch
from torch import nn


class TransitionNetwork(nn.Module):
    def __init__(self, kind, model_count, feature_mean, feature_scale, hidden_size=8, correction_bound=3):
        super().__init__()
        if kind not in {'fixed', 'static', 'history'}:
            raise ValueError('Unknown transition rule')
        self.kind, self.model_count = kind, model_count
        self.hidden_size, self.correction_bound = hidden_size, correction_bound
        mean = torch.as_tensor(feature_mean, dtype=torch.float64)
        scale = torch.as_tensor(feature_scale, dtype=torch.float64)
        if mean.shape != (7 + model_count,) or scale.shape != mean.shape:
            raise ValueError('Feature count must be 2 + 5 + model_count')
        if not torch.isfinite(mean).all() or not torch.isfinite(scale).all() or not (scale > 0).all():
            raise ValueError('Normalizer must be finite with positive scales')
        self.register_buffer('feature_mean', mean.clone())
        self.register_buffer('feature_scale', scale.clone())
        base = torch.full((model_count, model_count), .0025, dtype=torch.float64)
        base.fill_diagonal_(.99)
        if model_count == 1:
            base.fill_(1.)
        elif model_count != 5:
            raise ValueError('Only the frozen five-model bank or one-model reference is supported')
        self.register_buffer('base', base)
        if kind == 'static':
            self.correction = nn.Parameter(torch.zeros(model_count, model_count, dtype=torch.float64))
        elif kind == 'history':
            self.cell = nn.GRUCell(7 + model_count, hidden_size, dtype=torch.float64)
            self.output = nn.Linear(hidden_size, model_count * model_count, dtype=torch.float64)
            nn.init.zeros_(self.output.weight)
            nn.init.zeros_(self.output.bias)

    def initial_hidden(self, batch_size):
        return self.base.new_zeros(batch_size, self.hidden_size)

    def forward(self, previous_features, hidden):
        batch = previous_features.shape[0]
        if self.kind == 'fixed':
            return self.base.expand(batch, -1, -1), hidden
        if self.kind == 'history':
            hidden = self.cell((previous_features - self.feature_mean) / self.feature_scale, hidden)
            raw = self.output(hidden).reshape(batch, self.model_count, self.model_count)
        else:
            raw = self.correction.expand(batch, -1, -1)
        correction = self.correction_bound * torch.tanh(raw)
        calculated = torch.softmax(self.base.log() + correction, dim=-1)
        exact_base = calculated + (self.base - calculated).detach()
        matrix = torch.where((correction == 0).all((-1, -2), keepdim=True), exact_base, calculated)
        return matrix, hidden
