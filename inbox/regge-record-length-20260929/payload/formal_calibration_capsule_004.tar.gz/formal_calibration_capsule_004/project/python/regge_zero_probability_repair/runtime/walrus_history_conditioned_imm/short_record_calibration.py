"""Finite, staged short-record calibration; no file reads or writes during selection.

Numerical gates return status='failed' with all reached raw evidence. Unknown
engineering errors propagate. All indices in raw evidence are calibration-local.
"""
from __future__ import annotations

import hashlib
from contextlib import contextmanager

import numpy as np
import torch

from .filter import FilterState
from .noise_filter import BatchedNoiseFilters, _normalize_parameter_banks, _transition_tensor
from .noise_search import build_noise_design
from .short_record_contract import validate_config, validate_fixed_field_provenance, complete_origins, _hourly_timestamps
from .walrus import walrus_step, parameter_tensors


class NumericalFailure(ValueError):
    """Identified nonfinite/invalid numerical output, not an interface error."""


class ForecastNumericalFailure(NumericalFailure):
    """Known forecast failure carrying already completed requested lead values.

    predictions/prediction_mask are CPU tensors [batch,len(requested_leads)] in
    requested order. Missing leads are NaN/False. completed_hours counts complete
    validated steps before failed_hour. A finite mask is evidence of generation,
    NEVER permission to score a candidate whose overall validity is false.
    """

    def __init__(self, reason, predictions, completed_hours, failed_hour):
        super().__init__(reason)
        self.predictions = predictions.detach().clone()
        self.prediction_mask = torch.isfinite(self.predictions)
        self.completed_hours = int(completed_hours)
        self.failed_hour = int(failed_hour)


class SelectionFailure(ValueError):
    """Finite-budget or reference-error scientific gate failure."""


_INPUT_KEYS = {'warmup_timestamps', 'warmup_forcing', 'calibration_timestamps',
               'calibration_forcing', 'calibration_observations'}


@contextmanager
def _numerical_context():
    previous = torch.get_num_threads()
    torch.set_num_threads(1)
    try:
        with torch.no_grad():
            yield
    finally:
        torch.set_num_threads(previous)


def array_hash(values):
    """SHA-256 of C-contiguous raw array bytes; dtype/shape stored alongside."""
    return hashlib.sha256(np.ascontiguousarray(values).tobytes()).hexdigest()


def build_parameter_design(config: dict, fixed_fields: dict) -> tuple[list[dict], np.ndarray]:
    validate_config(config)
    if fixed_fields != config['fixed_fields']:
        raise ValueError('fixed_fields differ from frozen configuration')
    rng = np.random.default_rng(915031)
    jitter = rng.random((2048, 5))
    unit = np.empty_like(jitter)
    for column in range(5):
        unit[:, column] = (rng.permutation(2048) + jitter[:, column]) / 2048
    bounds = np.asarray([config['parameter_bounds'][field] for field in config['parameter_fields']])
    lower, upper = np.log10(bounds[:, 0]), np.log10(bounds[:, 1])
    values = 10 ** (lower + unit * (upper - lower))
    records = [dict(fixed_fields, **dict(zip(config['parameter_fields'], row.tolist()))) for row in values]
    return records, values


def joint_candidate_ids(shortlist, noise_count):
    ids = np.asarray(shortlist, dtype=np.int64)
    return np.repeat(ids, noise_count), np.tile(np.arange(noise_count, dtype=np.int64), len(ids))


def hydrologic_shortlist(errors):
    values = np.asarray(errors)
    valid = np.flatnonzero(np.isfinite(values))
    if len(valid) < 16:
        raise SelectionFailure('fewer than 16 valid hydrologic candidates')
    return sorted(valid.tolist(), key=lambda row: (values[row], row))[:16]


def prefix_diagnostics(errors):
    values = np.asarray(errors)
    return {count: float(np.min(values[:count])) for count in (512, 1024, 2048) if count <= len(values)}


def _selection_scores(errors, reference):
    scores = np.full(len(errors), np.inf)
    for row in np.flatnonzero(np.isfinite(errors).all(axis=1)):
        try:
            with np.errstate(over='raise', invalid='raise', divide='raise'):
                scores[row] = (errors[row]/reference).mean()
        except FloatingPointError:
            pass  # Nonfinite score remains invalid and is recorded by caller.
    return scores


def rank_joint_candidates(parameter_ids, noise_ids, errors, reference_errors) -> dict:
    p, n = np.asarray(parameter_ids), np.asarray(noise_ids)
    errors, reference = np.asarray(errors, dtype=np.float64), np.asarray(reference_errors, dtype=np.float64)
    if errors.shape != (len(p), 4) or p.ndim != 1 or n.shape != p.shape:
        raise ValueError('candidate identifiers and errors must have aligned shapes')
    if not np.issubdtype(p.dtype, np.integer) or not np.issubdtype(n.dtype, np.integer) or np.any(p < 0) or np.any(n < 0):
        raise ValueError('candidate identifiers must be nonnegative integers')
    if len(set(zip(p.tolist(), n.tolist()))) != len(p) or np.any(errors < 0):
        raise ValueError('duplicate candidates or negative errors')
    if reference.shape != (4,) or not np.isfinite(reference).all() or np.any(reference <= 0):
        raise SelectionFailure('invalid calibration reference')
    valid = np.isfinite(errors).all(axis=1)
    scores = _selection_scores(errors, reference)
    valid &= np.isfinite(scores)
    order = sorted(np.flatnonzero(valid).tolist(), key=lambda row: (scores[row], int(p[row]), int(n[row])))
    noise_rows = {}
    for row in order:
        noise_rows.setdefault(int(p[row]), []).append(row)
    members = sorted(noise_rows, key=lambda parameter: (scores[noise_rows[parameter][0]], parameter))
    if len(members) < 5:
        raise SelectionFailure('fewer than five parameters with valid noise')
    if len(noise_rows[members[0]]) < 3:
        raise SelectionFailure('independently ranked primary parameter lacks three valid noises')
    return dict(scores=scores, valid=valid, order=np.asarray(order, dtype=np.int64),
                member_parameter_ids=members[:5], noise_rows_by_parameter={p: rows[:3] for p, rows in noise_rows.items()})


def slice_filter_state(state, indices):
    """Copy an unadvanced snapshot, preserving batch/model dimensions."""
    return FilterState(*(value[indices].clone() for value in (state.states, state.covariances, state.probabilities)))


def _finite(value, name):
    if not torch.isfinite(value).all():
        raise NumericalFailure(f'nonfinite {name}')


def _probabilities(values, name):
    _finite(values, name)
    total = values.sum(dim=-1)
    if torch.any(values < 0) or torch.any(total <= 0) or not torch.isfinite(total).all():
        raise NumericalFailure(f'invalid {name}')
    if not torch.allclose(total, torch.ones_like(total), rtol=1e-10, atol=1e-12):
        raise NumericalFailure(f'unnormalized {name}')


def _state_shapes(state, batch, models):
    if not isinstance(state, FilterState):
        raise TypeError('state must be FilterState')
    for value, shape in zip((state.states, state.covariances, state.probabilities),
                            ((batch, models, 5), (batch, models, 5, 5), (batch, models))):
        if value.shape != shape:
            raise ValueError(f'filter state shape must be {shape}')
        if value.dtype != torch.float64 or value.device.type != 'cpu':
            raise ValueError('filter state must use CPU float64')


def _validate_state(state):
    _finite(state.states, 'member state')
    _finite(state.covariances, 'member covariance')
    _probabilities(state.probabilities, 'posterior probabilities')


def isolated_filter_step(adapter, state, forcing, observations, matrix, alive):
    """One update with permanent batch-item isolation from unadvanced snapshots.

    Inputs: adapter(B,M), FilterState[B,M,...], forcing[B,2], observations[B],
    shared matrix[M,M] or matrix[B,M,M], alive bool[B]. A multi-model method is
    ONE batch item. Returns state, alive, global_states[B,5],
    global_covariances[B,5,5], log_likelihoods[B,M], prior_probabilities[B,M],
    log_evidence[B], failures[{batch_index,reason}]. Failed outputs are NaN;
    failed stored states remain the input snapshot and are never advanced again.
    The helper never changes input objects or catches unknown exceptions.
    """
    batch, models = adapter.batch_size, adapter.model_count
    _state_shapes(state, batch, models)
    forcing, observations, matrix = [torch.as_tensor(x, dtype=torch.float64) for x in (forcing, observations, matrix)]
    alive = np.asarray(alive)
    if forcing.shape != (batch, 2) or observations.shape != (batch,) or alive.shape != (batch,) or alive.dtype != bool:
        raise ValueError('forcing/observation/alive shape or dtype mismatch')
    if matrix.shape not in ((models, models), (batch, models, models)):
        raise ValueError('transition matrix shape mismatch')
    if not torch.isfinite(forcing).all() or not torch.isfinite(observations).all():
        raise ValueError('input forcing/observations must be finite')
    output = dict(state=slice_filter_state(state, np.arange(batch)), alive=alive.copy(), failures=[])
    for key, shape in [('global_states', (batch, 5)), ('global_covariances', (batch, 5, 5)),
                       ('log_likelihoods', (batch, models)), ('prior_probabilities', (batch, models)), ('log_evidence', (batch,))]:
        output[key] = torch.full(shape, np.nan, dtype=torch.float64)

    def visit(ids):
        if not len(ids):
            return
        sub = adapter.subset(ids)
        snapshot = slice_filter_state(state, ids)
        transition = matrix if matrix.ndim == 2 else matrix[ids]
        try:
            _validate_state(snapshot)
            _probabilities(transition, 'transition probabilities')
            incoming = snapshot.probabilities.unsqueeze(-1) * transition
            if torch.any(incoming.sum(dim=1) <= 0):
                raise NumericalFailure('no valid incoming transition source')
            groups = getattr(sub, '_groups', None)
            if groups is not None:
                mask = torch.as_tensor(groups[:, :, None] == groups[:, None, :])
                group_mass = torch.where(mask, incoming, 0.).sum(dim=1)
                singleton = mask.sum(dim=1) == 1
                if torch.any((~singleton) & (group_mass <= 0)):
                    raise NumericalFailure('no valid incoming interaction source')
            result = sub.step(snapshot, forcing[ids], observations[ids], transition)
            _state_shapes(result.filter_state, len(ids), models)
            _validate_state(result.filter_state)
            fields = [('global_states', 'global_state'), ('global_covariances', 'global_covariance'),
                      ('log_likelihoods', 'log_likelihoods'), ('prior_probabilities', 'prior_probabilities'),
                      ('log_evidence', 'log_evidence')]
            for dest, source in fields:
                value = getattr(result, source)
                if value.shape != output[dest][ids].shape:
                    raise ValueError(f'{source} output shape mismatch')
                _finite(value, source)
            _probabilities(result.prior_probabilities, 'prior probabilities')
            if result.diagnostic_innovation.shape != (len(ids), models) or result.diagnostic_observation_variance.shape != (len(ids), models):
                raise ValueError('diagnostic output shape mismatch')
            _finite(result.diagnostic_innovation, 'innovation')
            _finite(result.diagnostic_observation_variance, 'observation variance')
            if torch.any(result.diagnostic_observation_variance <= 0):
                raise NumericalFailure('nonpositive observation variance')
        except (NumericalFailure, torch.linalg.LinAlgError) as error:
            if len(ids) > 1:
                split = len(ids)//2
                visit(ids[:split])
                visit(ids[split:])
            else:
                output['alive'][ids[0]] = False
                output['failures'].append(dict(batch_index=int(ids[0]), reason=f'{type(error).__name__}: {error}'))
            return
        for destination, source in zip((output['state'].states, output['state'].covariances, output['state'].probabilities),
                                        (result.filter_state.states, result.filter_state.covariances, result.filter_state.probabilities)):
            destination[ids] = source
        for dest, source in fields:
            output[dest][ids] = getattr(result, source)

    with torch.no_grad():
        visit(np.flatnonzero(alive))
    return output


def checked_deterministic_forecasts(global_states, probabilities, future_forcing, parameter_banks,
                                    matrix, leads=(1, 24, 48, 120), evolve=False):
    """Original single-path forecast loop plus complete-state numerical checks.

    Same interface/output as noise_filter.deterministic_forecasts. No covariance,
    no observation access, no independent horizon runs. NumericalFailure denotes
    any nonfinite full propagated state even when discharge alone remains finite.
    Failure during a step raises ForecastNumericalFailure with completed requested
    predictions/mask. Using leads=tuple(range(1,121)) supplies full-path partial
    evidence for either probability form without additional model propagation.
    """
    banks, mappings = _normalize_parameter_banks(parameter_banks)
    batch, models = len(banks), len(banks[0])
    x, p, forcing = [torch.as_tensor(value, dtype=torch.float64) for value in (global_states, probabilities, future_forcing)]
    if x.device.type != 'cpu' or x.shape != (batch, 5) or p.shape != (batch, models):
        raise ValueError('forecast state/probability shape or device mismatch')
    leads = tuple(leads)
    if len(leads) == 0 or any(not isinstance(lead, (int, np.integer)) or lead < 1 for lead in leads):
        raise ValueError('positive integer forecast leads required')
    if forcing.ndim != 3 or forcing.shape[0] != batch or forcing.shape[2] != 2 or forcing.shape[1] < max(leads):
        raise ValueError('future forcing shape/coverage mismatch')
    _finite(x, 'forecast initial state')
    _probabilities(p, 'forecast probabilities')
    if not torch.isfinite(forcing).all():
        raise ValueError('nonfinite input forecast forcing')
    matrix = torch.as_tensor(matrix, dtype=torch.float64)
    if matrix.shape not in ((models, models), (batch, models, models)):
        raise ValueError('forecast transition shape mismatch')
    _probabilities(matrix, 'forecast transition probabilities')
    matrix, _ = _transition_tensor(matrix, batch, models, x)
    bank = parameter_tensors(mappings, x)
    predictions = {}
    with torch.no_grad():
        for hour in range(1, max(leads)+1):
            try:
                if evolve:
                    p = torch.matmul(p.unsqueeze(-2), matrix).squeeze(-2)
                    _probabilities(p, 'evolving forecast probabilities')
                weighted = {key: (p * value).sum(dim=-1) if value.ndim else value for key, value in bank.items()}
                x = walrus_step(x, forcing[:, hour-1], weighted)
                _finite(x, f'complete forecast state at lead {hour}')
            except (NumericalFailure, torch.linalg.LinAlgError) as error:
                partial = torch.full((batch, len(leads)), np.nan, dtype=torch.float64)
                for column, lead in enumerate(leads):
                    if lead in predictions:
                        partial[:, column] = predictions[lead]
                raise ForecastNumericalFailure(str(error), partial, hour-1, hour) from error
            if hour in leads:
                predictions[hour] = x[..., 4]
        return torch.stack([predictions[lead] for lead in leads], dim=-1)


def _validated_inputs(inputs):
    if set(inputs) != _INPUT_KEYS:
        raise ValueError('input keys must contain only meteorological warmup and calibration data')
    warm, dates = _hourly_timestamps(inputs['warmup_timestamps']), _hourly_timestamps(inputs['calibration_timestamps'])
    if dates[0] != warm[-1] + np.timedelta64(1, 'h'):
        raise ValueError('warmup and calibration window must be contiguous')
    forcing = np.asarray(inputs['calibration_forcing'], dtype=np.float64)
    warm_forcing = np.asarray(inputs['warmup_forcing'], dtype=np.float64)
    obs = np.asarray(inputs['calibration_observations'], dtype=np.float64)
    if forcing.shape != (len(dates), 2) or warm_forcing.shape != (len(warm), 2) or obs.shape != (len(dates),):
        raise ValueError('input shape mismatch')
    if not all(np.isfinite(value).all() for value in (forcing, warm_forcing, obs)):
        raise ValueError('input records must be complete and finite')
    return warm, dates, warm_forcing, forcing, obs


def _errors(predictions, targets, alive):
    errors = np.full((len(predictions), *predictions.shape[2:]), np.inf)
    ids = np.flatnonzero(alive)
    if len(ids):
        try:
            with np.errstate(over='raise', invalid='raise'):
                errors[ids] = np.sqrt(np.mean((predictions[ids] - targets)**2, axis=1))
        except FloatingPointError:
            # Classify arithmetic overflow per row; never rerun a model/date.
            for row in ids:
                try:
                    with np.errstate(over='raise', invalid='raise'):
                        errors[row] = np.sqrt(np.mean((predictions[row] - targets)**2, axis=0))
                except FloatingPointError:
                    pass  # The caller records each newly nonfinite error row.
    return errors


def _execute(inputs, records, design, parameter_values, leads, record_event, *, synthetic):
    result = {}
    try:
        return _execute_reached(inputs, records, design, parameter_values, leads, record_event,
                                synthetic=synthetic, result=result)
    except BaseException as error:
        if result:
            raw = result['raw']
            for name in ('hydrologic_predictions', 'joint_predictions'):
                if name in raw:
                    raw[name.replace('predictions', 'prediction_mask')] = np.isfinite(raw[name])
            for prefix in ('hydrologic','joint'):
                if prefix+'_valid' in raw:
                    raw[prefix+'_valid'] &= raw[prefix+'_completed']
            result.update(status='engineering_failed', partial=True, selected=None,
                engineering_error=dict(type=type(error).__name__, reason=str(error)),
                array_hashes={key: dict(sha256=array_hash(value), dtype=str(value.dtype), shape=list(value.shape))
                              for key, value in raw.items() if isinstance(value, np.ndarray)})
            result['available_arrays'] = sorted(raw)
            result['unavailable_derived_arrays'] = [key for key in ('hydrologic_errors','shortlist_parameter_ids',
                'reference_errors','joint_errors','joint_scores','joint_rank_order') if key not in raw]
            # Preserve the ORIGINAL exception type, object and traceback. Only
            # reached arrays exist; no scoring or model computation occurs here.
            error.short_record_partial_result = result
        raise


def _execute_reached(inputs, records, design, parameter_values, leads, record_event, *, synthetic, result):
    warm_dates, dates, warm_forcing, forcing, observations = _validated_inputs(inputs)
    count, hours = len(records), len(dates)
    raw = dict(parameter_values=parameter_values, parameter_ids=np.arange(count, dtype=np.int64),
               noise_design=np.array(design, copy=True), warmup_timestamps=warm_dates.copy(),
               warmup_forcing=warm_forcing.copy(), calibration_timestamps=dates.copy(),
               calibration_forcing=forcing.copy(), calibration_observations=observations.copy(),
               calibration_indices=np.arange(hours, dtype=np.int64),
               hydrologic_predictions=np.full((count, hours), np.nan), warmup_states=np.full((count, 5), np.nan))
    failures = []
    result.update(status='running', selected=None, raw=raw, failures=failures, parameters=records,
                  evidence='synthetic_test_only' if synthetic else 'development_perfect_forcing',
                  leads=list(leads), selection_failure=None, partial=False, phase='initialized')

    def fail(stage, row, index, reason):
        record = dict(stage=stage, candidate_row=int(row), index=int(index), reason=reason)
        if stage == 'warmup':
            record['timestamp'] = str(warm_dates[index])
            record['parameter_id'] = int(row)
        else:
            record['timestamp'] = str(dates[index])
            if stage in ('filter', 'forecast'):
                record.update(parameter_id=int(raw['joint_parameter_ids'][row]), noise_id=int(raw['joint_noise_ids'][row]))
            else:
                record['parameter_id'] = int(row)
        failures.append(record)
        record_event('candidate_failure', **record)

    record_event('selection_observation_access', earliest=str(dates[0]), latest=str(dates[-1]), observation_count=hours)
    record_event('search_budget', hydrologic_candidates=count, shortlisted_parameters=16,
                 noises_per_parameter=len(design), joint_candidates=16*len(design))
    alive = np.ones(count, bool)
    raw['hydrologic_alive'] = alive
    raw['hydrologic_completed'] = np.zeros(count, bool)
    raw['hydrologic_last_states'] = np.full((count,5), np.nan)
    raw['warmup_completed'] = np.zeros(count, bool)
    # Bounded chunks preserve all raw predictions and full warmup state per row.
    for start in range(0, count, 128):
        ids = np.arange(start, min(start+128, count))
        states = torch.tensor([140., 1000., 4., 1200., .1], dtype=torch.float64).expand(len(ids), 5).clone()
        raw['hydrologic_last_states'][ids] = states.numpy()
        for stage, stage_forcing in [('warmup', warm_forcing), ('hydrologic', forcing)]:
            result['phase'] = stage
            for hour, met in enumerate(stage_forcing):
                result['progress'] = dict(batch_start=start, hour=hour)
                positions = np.flatnonzero(alive[ids])
                if not len(positions):
                    break
                next_states = walrus_step(states[positions], torch.from_numpy(met), [records[ids[i]] for i in positions])
                good = torch.isfinite(next_states).all(dim=1).numpy()
                for position in positions[~good]:
                    alive[ids[position]] = False
                    fail(stage, ids[position], hour, 'nonfinite complete hydrologic state')
                states[positions[good]] = next_states[good]
                raw['hydrologic_last_states'][ids] = states.numpy()
                if stage == 'hydrologic':
                    raw['hydrologic_predictions'][ids[positions[good]], hour] = next_states[good, 4].numpy()
            if stage == 'warmup':
                raw['warmup_states'][ids[alive[ids]]] = states[alive[ids]].numpy()
                raw['warmup_completed'][ids] = True
        raw['hydrologic_completed'][ids] = True
        record_event('hydrologic_progress', completed_candidates=int(ids[-1]+1), total_candidates=count)
    result['phase'] = 'hydrologic_scoring'
    raw['hydrologic_valid'] = alive.copy()
    raw['hydrologic_prediction_mask'] = np.isfinite(raw['hydrologic_predictions'])
    raw['hydrologic_errors'] = _errors(raw['hydrologic_predictions'], observations, alive)
    for row in np.flatnonzero(alive & ~np.isfinite(raw['hydrologic_errors'])):
        fail('hydrologic_score', row, hours-1, 'nonfinite hydrologic error arithmetic')
    raw['hydrologic_valid'] &= np.isfinite(raw['hydrologic_errors'])
    result['prefix_diagnostics'] = prefix_diagnostics(raw['hydrologic_errors'])
    try:
        shortlist = hydrologic_shortlist(raw['hydrologic_errors'])
        raw['shortlist_parameter_ids'] = np.asarray(shortlist, dtype=np.int64)
        origins = complete_origins(dates, 0, hours, leads)
        if not len(origins):
            raise SelectionFailure('no complete calibration origins')
        targets = origins[:, None] + np.asarray(leads)[None, :]
        raw.update(origin_indices=origins, target_indices=targets, origin_timestamps=dates[origins],
                   target_timestamps=dates[targets], target_observations=observations[targets],
                   persistence_predictions=np.broadcast_to(observations[origins, None], targets.shape).copy())
        raw['persistence_mask'] = np.isfinite(raw['persistence_predictions']) & np.isfinite(raw['target_observations'])
        reference = _errors(raw['persistence_predictions'][None], raw['target_observations'], np.array([True]))[0]
        raw['reference_errors'] = reference
        if not np.isfinite(reference).all() or np.any(reference <= 0):
            raise SelectionFailure('invalid calibration reference')
        pids, nids = joint_candidate_ids(shortlist, len(design))
        joint_count = len(pids)
        raw.update(joint_parameter_ids=pids, joint_noise_ids=nids,
                   joint_predictions=np.full((joint_count, len(origins), 4), np.nan),
                   joint_origin_global_states=np.full((joint_count, len(origins), 5), np.nan),
                   joint_origin_probabilities=np.full((joint_count, len(origins), 1), np.nan),
                   joint_valid=np.ones(joint_count, bool), joint_alive=np.ones(joint_count, bool),
                   joint_completed=np.zeros(joint_count, bool),
                   joint_last_member_states=np.full((joint_count,1,5),np.nan),
                   joint_last_member_covariances=np.full((joint_count,1,5,5),np.nan),
                   joint_last_probabilities=np.full((joint_count,1),np.nan))
        origin_columns = {int(origin): col for col, origin in enumerate(origins)}
        for start in range(0, joint_count, 128):
            ids = np.arange(start, min(start+128, joint_count))
            banks = [[records[pids[i]]] for i in ids]
            adapter = BatchedNoiseFilters(banks, design[nids[ids], None, :])
            initial = adapter.initial_state()
            state = FilterState(torch.from_numpy(raw['warmup_states'][pids[ids], None, :].copy()), initial.covariances, initial.probabilities)
            def retain_state():
                for key,value in [('joint_last_member_states',state.states),('joint_last_member_covariances',state.covariances),
                                  ('joint_last_probabilities',state.probabilities)]:
                    raw[key][ids] = value.numpy()
            retain_state()
            local_alive = np.ones(len(ids), bool)
            for hour in range(hours):
                result['phase'] = 'joint_filter'
                result['progress'] = dict(batch_start=start, hour=hour)
                if not local_alive.any():
                    break
                update = isolated_filter_step(adapter, state, np.broadcast_to(forcing[hour], (len(ids), 2)).copy(),
                                               np.full(len(ids), observations[hour]), [[1.]], local_alive)
                state, local_alive = update['state'], update['alive']
                retain_state()
                raw['joint_alive'][ids] = local_alive
                for failure in update['failures']:
                    fail('filter', ids[failure['batch_index']], hour, failure['reason'])
                if hour in origin_columns:
                    result['phase'] = 'joint_forecast'
                    column = origin_columns[hour]
                    live_positions = np.flatnonzero(local_alive)
                    raw['joint_origin_global_states'][ids[live_positions], column] = update['global_states'][live_positions].numpy()
                    raw['joint_origin_probabilities'][ids[live_positions], column] = state.probabilities[live_positions].numpy()

                    def forecast_visit(positions):
                        if not len(positions):
                            return
                        try:
                            future = np.broadcast_to(forcing[hour+1:hour+max(leads)+1], (len(positions), max(leads), 2)).copy()
                            prediction = checked_deterministic_forecasts(update['global_states'][positions], state.probabilities[positions],
                                future, [banks[i] for i in positions], [[1.]], leads)
                            _finite(prediction, 'forecast discharge')
                        except (NumericalFailure, torch.linalg.LinAlgError) as error:
                            if isinstance(error, ForecastNumericalFailure):
                                # Preserve generated evidence before splitting or
                                # invalidating. Finite values never rescue rows.
                                partial = error.predictions.numpy()
                                mask = error.prediction_mask.numpy()
                                saved = raw['joint_predictions'][ids[positions], column].copy()
                                saved[mask] = partial[mask]
                                raw['joint_predictions'][ids[positions], column] = saved
                            if len(positions) > 1:
                                split = len(positions)//2
                                forecast_visit(positions[:split])
                                forecast_visit(positions[split:])
                            else:
                                local_alive[positions[0]] = False
                                raw['joint_alive'][ids[positions[0]]] = False
                                fail('forecast', ids[positions[0]], hour, f'{type(error).__name__}: {error}')
                            return
                        raw['joint_predictions'][ids[positions], column] = prediction.numpy()

                    forecast_visit(np.flatnonzero(local_alive))
                    raw['joint_alive'][ids] = local_alive
                if (hour+1) % 720 == 0:
                    record_event('filter_progress', batch_start=start, completed_hours=hour+1, total_hours=hours, alive=int(local_alive.sum()))
            raw['joint_valid'][ids] = local_alive
            raw['joint_completed'][ids] = True
            record_event('joint_progress', completed_candidates=int(ids[-1]+1), total_candidates=joint_count)
        result['phase'] = 'joint_scoring'
        raw['joint_prediction_mask'] = np.isfinite(raw['joint_predictions'])
        raw['joint_errors'] = _errors(raw['joint_predictions'], raw['target_observations'], raw['joint_valid'])
        for row in np.flatnonzero(raw['joint_valid'] & ~np.isfinite(raw['joint_errors']).all(axis=1)):
            fail('filter', row, hours-1, 'nonfinite joint error arithmetic')
        raw['joint_valid'] &= np.isfinite(raw['joint_errors']).all(axis=1)
        raw['joint_scores'] = _selection_scores(raw['joint_errors'], reference)
        for row in np.flatnonzero(raw['joint_valid'] & ~np.isfinite(raw['joint_scores'])):
            fail('filter', row, hours-1, 'nonfinite joint relative-score arithmetic')
        raw['joint_valid'] &= np.isfinite(raw['joint_scores'])
        ranked = rank_joint_candidates(pids, nids, raw['joint_errors'], reference)
        raw['joint_rank_order'] = ranked['order']
        members = []
        for parameter in ranked['member_parameter_ids']:
            rows = ranked['noise_rows_by_parameter'][parameter]
            noise_ids = nids[rows]
            members.append(dict(parameter_id=parameter, parameters=records[parameter], noise_id=int(noise_ids[0]),
                diagonal=design[noise_ids[0]].tolist(), score=float(ranked['scores'][rows[0]]),
                top_three_noise_ids=noise_ids.tolist(), top_three_noise_diagonals=design[noise_ids].tolist()))
        result['selected'] = dict(members=members, prespecified_single_parameter_id=members[0]['parameter_id'],
            prespecified_single_noise_id=members[0]['noise_id'], selection_cutoff=str(dates[-1]+np.timedelta64(1, 'h')),
            source_hashes={key: array_hash(raw[key]) for key in ('parameter_values', 'noise_design', 'warmup_forcing', 'calibration_forcing',
                                                                     'calibration_observations', 'calibration_timestamps')})
        result['status'] = 'complete'
        result['phase'] = 'complete'
    except SelectionFailure as error:
        result['status'] = 'failed'
        result['selection_failure'] = str(error)
        record_event('selection_failure', reason=str(error))
    result['array_hashes'] = {key: dict(sha256=array_hash(value), dtype=str(value.dtype), shape=list(value.shape))
                              for key, value in raw.items() if isinstance(value, np.ndarray)}
    return result


def calibrate_window(config: dict, inputs: dict, record_event) -> dict:
    """Validate frozen production config and supplied slice, then finite calibration.

    Caller MUST persist the returned dict before acting on status. Failed window
    has selected=None, selection_failure text, reached raw arrays and failures.
    Window identity is inferred by its exact calibration bounds (no extra key).
    An engineering exception after allocation retains its original type/object
    and carries short_record_partial_result. The caller must exclusively save
    that partial record before re-raising; it must never retry the window.
    """
    validate_config(config)
    warm, dates, *_ = _validated_inputs(inputs)
    matches = [w for w in config['windows'] if np.datetime64(w['calibration_start'], 'h') == dates[0]
               and np.datetime64(w['calibration_stop'], 'h') == dates[-1]+np.timedelta64(1, 'h')]
    if len(matches) != 1 or warm[0] != np.datetime64(config['data_start'], 'h'):
        raise ValueError('input calibration window or warmup bounds do not match frozen configuration')
    validate_fixed_field_provenance(config)
    records, values = build_parameter_design(config, config['fixed_fields'])
    design = build_noise_design(config['noise_design']['seed'])
    if array_hash(design) != config['noise_design']['hash_sha256']:
        raise ValueError('noise design hash mismatch')
    try:
        with _numerical_context():
            result = _execute(inputs, records, design, values, tuple(config['leads']), record_event, synthetic=False)
    except BaseException as error:
        if hasattr(error, 'short_record_partial_result'):
            error.short_record_partial_result['window'] = dict(matches[0])
        raise
    result['window'] = dict(matches[0])
    return result


def _calibrate_synthetic_for_test(inputs, records, design, *, leads=(1, 2, 3, 4), record_event=lambda *args, **kwargs: None):
    """Explicit tiny synthetic-only entry; cannot relax production validation."""
    if len(records) != 16 or np.asarray(design).shape != (3, 5) or len(inputs['calibration_timestamps']) > 256 or len(inputs['warmup_timestamps']) > 256:
        raise ValueError('test-only entry requires 16 parameters, three noises and at most 256 hours per phase')
    if len(leads) != 4:
        raise ValueError('test-only entry still requires four leads')
    values = np.asarray([[p[k] for k in ('cw', 'cv', 'cg', 'cq', 'cs')] for p in records])
    with _numerical_context():
        return _execute(inputs, records, np.asarray(design), values, tuple(leads), record_event, synthetic=True)
