"""Versioned formal entry for the frozen Regge short-record study.

This module does not promote or edit the failed legacy preflight or the
reference-repair receipt.  It independently revalidates the exact repair
evidence, binds it into a new protocol, and then reuses the frozen production
calibration and assessment functions.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import platform
import re
import stat
import time

import numpy as np
import torch

from . import short_record_audit as audit
from . import short_record_experiment as writer
from . import short_record_reference_repair as repair
from .data import load_reference, validate_series
from .short_record_contract import validate_config, validate_fixed_field_provenance


OUTPUT_ROOT = writer.WORKTREE / "results/regge_short_record_calibration_v02"
DEFAULT_CONFIG = writer.PACKAGE / "configs/regge_short_record_v01.json"
CONFIG_HASH = "5f175b2f09613b2090c379f57378cffd84daffb46d2a26b95fa3ec4bb2b1de0c"
REPAIR_ROOT = writer.WORKTREE / "results/regge_short_record_reference_repair/20260916-regge-log-reference-repair-preflight-001"
REPAIR_RECEIPT_HASH = "3f5f99bf3cd062dde60df85c61af8e1bacd29d5b47c707b6edbee6ff9facb57b"
REPAIR_MANIFEST_HASH = "9c58ec5b7bf4a9f5c7cf2d4f900eee5dc8c2493267fc7637bb43c5de6e33e8ca"
REPAIR_AUDIT_HASH = "85a8b9c5582de9c09a78e1a95fc5760ef641481a02c30abaaf9f557f484a66dc"
RECEIPT_SCHEMA = "regge_short_record_formal_receipt_v02"
MODE = "short_record_formal_v02"
PROTOCOL_SCHEMA = "regge_short_record_formal_protocol_v02"
REFERENCE_ARITHMETIC = "independent_log"


def _target(output_root, run_id):
    """Return one absent, confined target in the one V02 output family."""
    if (not isinstance(run_id, str) or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", run_id) is None
            or run_id.endswith(".") or run_id.split(".")[0].upper() in {
                "CON", "PRN", "AUX", "NUL", *[f"COM{i}" for i in range(1, 10)],
                *[f"LPT{i}" for i in range(1, 10)]}):
        raise ValueError("run_id must be one safe non-reserved directory-name component")
    supplied = Path(output_root)
    expected = Path(OUTPUT_ROOT)
    if supplied.absolute() != expected.absolute() or supplied.resolve() != expected.absolute():
        raise ValueError("output family must be the exact V02 production output root")
    for part in (supplied, *supplied.parents):
        if os.path.lexists(part):
            attributes = getattr(os.lstat(part), "st_file_attributes", 0)
            if part.is_symlink() or attributes & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0):
                raise ValueError("output family must not traverse a symlink or Windows reparse point")
    target = supplied / run_id
    if target.resolve().parent != supplied.resolve():
        raise ValueError("run_id escapes the V02 output family")
    if target.exists() or target.is_symlink():
        raise ValueError("formal V02 target already exists")
    return target


def _sources(config_path):
    return [Path(config_path).resolve(), *sorted(writer.PACKAGE.glob("*.py")),
            *sorted((writer.PACKAGE / "scripts").glob("*.py")),
            *sorted((writer.REFERENCE_ROOT / "python/imm_da").glob("*.py"))]


def _protocol(config):
    return {
        "schema": PROTOCOL_SCHEMA,
        "base_config_sha256": CONFIG_HASH,
        "reference_arithmetic": REFERENCE_ARITHMETIC,
        "reference_repair": {
            "root": str(REPAIR_ROOT.resolve()),
            "receipt_sha256": REPAIR_RECEIPT_HASH,
            "manifest_sha256": REPAIR_MANIFEST_HASH,
            "audit_sha256": REPAIR_AUDIT_HASH,
            "promoted_to_legacy_preflight": False,
        },
        "formal_execution_authorized": True,
        "legacy_gate_modified": False,
        "scientific_design_changed": False,
        "preflight_contract": config["preflight"],
        "interpretation": (
            "Retrospective development study of practical later forecast skill after three months of "
            "discharge calibration; not global optimality, statistical noninferiority, flood-peak skill, "
            "operational causality, or a pure calibration-length effect."
        ),
    }


def _validate_repair_evidence(binding, current_inputs):
    """Validate the pinned repair without making it a legacy passed preflight."""
    required = {
        "receipt.json": REPAIR_RECEIPT_HASH,
        "manifest.json": REPAIR_MANIFEST_HASH,
        "audit.json": REPAIR_AUDIT_HASH,
    }
    for relative, expected in required.items():
        path = REPAIR_ROOT / relative
        audit._require(path.is_file() and audit._hash(path) == expected,
                       f"repair pinned {relative} hash")
    result = repair.audit_reference_repair_run(REPAIR_ROOT)
    audit._require(isinstance(result, dict) and result.get("passed") is True
                   and result.get("status") == "reference_repair_complete"
                   and result.get("scientific_binding_eligible") is False,
                   "repair independent saved-evidence audit failed")
    receipt = audit._json(REPAIR_ROOT / "receipt.json")
    repair_binding = receipt.get("binding")
    audit._require(isinstance(repair_binding, dict), "repair binding missing")
    audit._require(repair_binding.get("config_sha256") == binding.get("config_sha256") == CONFIG_HASH,
                   "repair configuration binding mismatch")
    for field in ("python", "numpy", "torch", "cpu_threads", "dtype"):
        audit._require(repair_binding.get(field) == binding.get(field),
                       f"repair runtime binding mismatch: {field}")
    previous_sources = repair_binding.get("source_hashes")
    current_sources = binding.get("source_hashes")
    audit._require(isinstance(previous_sources, dict) and isinstance(current_sources, dict),
                   "repair source binding missing")
    for path, digest in previous_sources.items():
        audit._require(current_sources.get(path) == digest,
                       f"repair overlapping source changed: {path}")
    dates, forcing, observations = current_inputs
    with np.load(REPAIR_ROOT / "inputs.npz", allow_pickle=False) as saved:
        audit._same(saved["timestamps"], dates, "repair full input timestamps")
        audit._same(saved["forcing"], forcing, "repair full input forcing")
        audit._same(saved["observations"], observations, "repair full input observations")
    return {
        "schema": "regge_short_record_reference_repair_binding_v02",
        "repair_root": str(REPAIR_ROOT.resolve()),
        "receipt_sha256": REPAIR_RECEIPT_HASH,
        "manifest_sha256": REPAIR_MANIFEST_HASH,
        "audit_sha256": REPAIR_AUDIT_HASH,
        "reference_arithmetic": REFERENCE_ARITHMETIC,
        "independent_saved_audit_passed": True,
        "scientific_binding_eligible_in_repair_receipt": False,
        "promoted_to_legacy_preflight": False,
        "overlapping_source_count": len(previous_sources),
        "filtering_scope": result.get("filtering_scope"),
    }


def _finalize(art, status, binding, error=None):
    runtime = {
        "python": platform.python_version(),
        "numpy": np.__version__,
        "torch": torch.__version__,
        "execution_threads": getattr(art, "execution_threads", None),
        "restored_finalization_threads": writer._thread_settings(),
        "elapsed_seconds": time.perf_counter() - art.started,
        "peak_sampled_rss_bytes": art.peak_rss or None,
        "cpu_threads_required": 1,
        "static_resource_counts": writer.STATIC_RESOURCES,
    }
    try:
        import threadpoolctl
        runtime["threadpoolctl"] = getattr(threadpoolctl, "__version__", None)
    except ImportError:
        runtime["threadpoolctl"] = None
    art.json("runtime.json", runtime)
    passed = status == "complete"
    art.json("receipt.json", {
        "schema": RECEIPT_SCHEMA,
        "status": status,
        "mode": MODE,
        "passed": passed,
        "error": error,
        "test_only": art.test_only,
        "scientific_binding_eligible": passed and not art.test_only,
        "reference_arithmetic": REFERENCE_ARITHMETIC,
        "binding": binding,
    })
    files = {}
    for path in sorted(art.root.rglob("*")):
        if path.is_file() and path.relative_to(art.root).as_posix() not in {"manifest.json", "audit.json"}:
            if not path.resolve().is_relative_to(art.root.resolve()):
                raise RuntimeError("formal V02 manifest artifact escapes run directory")
            files[path.relative_to(art.root).as_posix()] = audit._hash(path)
    art.json("manifest.json", {
        "schema": "regge_short_record_manifest_v01",
        "excluded": ["manifest.json", "audit.json"],
        "files": files,
    })


def _assessment(window, selected, art, dates, forcing, observations):
    arms = writer.build_assessment_arms(selected, int(window["months"]) == 3)
    hourly_dates = dates.astype("datetime64[h]")
    c0 = int(np.flatnonzero(hourly_dates == np.datetime64(window["calibration_start"], "h"))[0])
    c1 = int(np.flatnonzero(hourly_dates == np.datetime64(window["calibration_stop"], "h"))[0])
    a0 = c1
    stop = np.datetime64(window["assessment_stop"], "h")
    a1 = int(np.flatnonzero(hourly_dates == stop)[0]) if stop in hourly_dates else len(dates)
    key = writer._window_key(window)
    with np.load(art.root / "calibration" / key / "raw.npz", allow_pickle=False) as calibration:
        member_ids = [member["parameter_id"] for member in selected["members"]]
        warm_by_id = writer._selected_warmup_states(calibration, member_ids)
    results = []
    for rank, arm in enumerate(arms):
        warm = np.asarray([
            warm_by_id[next(member["parameter_id"] for member in selected["members"]
                            if member["parameters"] == parameters)]
            for parameters in arm["parameters"]
        ])
        result = writer.replay_assessment_arm(
            arm, warm, dates, forcing, observations, c0, c1, a0, a1,
            record_event=art.event,
            preserve_on_error=lambda partial, current_rank=rank: art.assessment_arm(
                key, current_rank, partial, checkpoint=True),
        )
        art.assessment_arm(key, rank, result)
        results.append(result)
    origins = results[0]["origin_indices"]
    summaries = [{name: value for name, value in result.items() if not isinstance(value, np.ndarray)}
                 for result in results]
    return {
        "arm_summaries": summaries,
        "persistence_predictions": np.broadcast_to(observations[origins, None], (len(origins), 120)).copy(),
        "target_observations": observations[origins[:, None] + np.arange(1, 121)[None]],
        "origin_indices": origins,
    }


def run_short_record_formal_v02(config_path=DEFAULT_CONFIG, output_root=OUTPUT_ROOT, run_id=None):
    """Execute one exclusive V02 formal attempt after all pinned gates pass."""
    if run_id is None:
        raise ValueError("run_id is required")
    target = _target(output_root, run_id)
    config_path = Path(config_path).resolve()
    audit._require(config_path == Path(DEFAULT_CONFIG).resolve() and config_path.is_file()
                   and audit._hash(config_path) == CONFIG_HASH,
                   "formal V02 frozen configuration path/hash")
    config = audit._json(config_path)
    validate_config(config)
    validate_fixed_field_provenance(config)
    art = writer._Artifacts(target, test_only=False)
    before = {}
    binding = None
    try:
        before = writer._persist_snapshot(art, _sources(config_path))
        binding = writer._binding(audit._hash(config_path), before)
        art.json("config.json", config)
        art.json("formal_protocol_v02.json", _protocol(config))
        art.json("provenance_before_load.json", before)
        dates, forcing, observations, _, _ = load_reference(writer.REFERENCE_ROOT)
        validate_series(dates, forcing, observations)
        expected = np.arange(np.datetime64(config["data_start"], "h"),
                             np.datetime64(config["data_stop"], "h"))
        audit._same(np.asarray(dates).astype("datetime64[h]"), expected,
                    "formal V02 full frozen input timeline")
        art.npz("inputs.npz", {"timestamps": dates, "forcing": forcing, "observations": observations})
        repair_evidence = _validate_repair_evidence(binding, (dates, forcing, observations))
        art.json("reference_repair_binding.json", repair_evidence)
        resource = writer._resource_gate(art.root)
        art.json("resource_plan.json", {
            "static_counts": writer.STATIC_RESOURCES,
            "estimates_are_not_measurements": True,
            "budgets_must_not_be_reduced": True,
            "gate": resource,
        })
        repair_runtime = audit._json(REPAIR_ROOT / "preflight/runtime.json")
        formal_resource = writer._formal_resource_estimate(resource, repair_runtime)
        art.json("formal_resource_receipt.json", formal_resource)
        if formal_resource["estimated_peak_rss_bytes"] > resource["memory_available_bytes"]:
            raise RuntimeError("formal V02 extrapolated memory exceeds live availability; scientific budget unchanged")
        with writer._one_thread() as execution_threads:
            art.execution_threads = execution_threads
            windows = writer.calibration_windows(config)

            def calibrate(window, event):
                return writer.calibrate_window(
                    config, writer.information_slices(dates, forcing, observations, window), event)

            def assess(window, selected, event):
                del event
                return _assessment(window, selected, art, dates, forcing, observations)

            writer._orchestrate(art, windows, calibrate, assess)
        after = {path: audit._hash(path) if Path(path).is_file() else None for path in before}
        art.json("input_hashes_after.json", after)
        audit._require(before == after, "formal V02 source/config changed during execution")
        _finalize(art, "complete", binding)
    except BaseException as error:
        if not (art.root / "input_hashes_after.json").exists():
            art.json("input_hashes_after.json", {
                path: audit._hash(path) if Path(path).is_file() else None for path in before
            })
        if not (art.root / "receipt.json").exists():
            _finalize(art, "failed", binding, f"{type(error).__name__}: {error}")
        raise
    return {"run_dir": str(art.root), "status": "complete", "passed": True, "mode": MODE}
