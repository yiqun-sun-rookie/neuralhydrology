"""Pure contracts for the Regge short-discharge-record workflow.

The shipped fixed-field provenance is verified and hash-locked.  Every formal
run must recheck those window-safe sources through the provenance gate.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
from typing import Sequence

import numpy as np


_CONFIG_PATH = Path(__file__).with_name("configs") / "regge_short_record_v01.json"
_DATA_START = np.datetime64("1999-01-01T01", "h")
_DATA_STOP = np.datetime64("2005-01-01T00", "h")
_FROZEN_SCIENTIFIC_CONFIG_SHA256 = "734d36c52c054a270a5e56c766795cc7b2c42819a5abf2f976c500edee9f10f6"
_PROVENANCE_KEYS = {"fixed_field_provenance", "provenance_sources", "provenance_checked_on", "provenance_scope"}
_WINDOW_KEYS = ("name", "months", "calibration_start", "calibration_stop", "assessment_start", "assessment_stop")
_SELECTED_KEYS = ("members", "prespecified_single_parameter_id", "prespecified_single_noise_id", "selection_cutoff", "source_hashes")


def proposed_config() -> dict:
    """Load a fresh JSON-compatible copy of the frozen proposed configuration."""
    with _CONFIG_PATH.open("r", encoding="utf-8") as stream:
        config = json.load(stream)
    validate_config(config)
    return config


def validate_config(config: dict) -> bool:
    """Validate every binding scientific setting against an independent lock."""
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")
    if config.get("config_version") != "regge_short_record_v01":
        raise ValueError("unsupported config_version")
    windows = config.get("windows")
    if not isinstance(windows, list) or len(windows) != 6:
        raise ValueError("config must contain six calibration windows")
    for window in windows:
        missing = [key for key in _WINDOW_KEYS if key not in window]
        if missing:
            raise ValueError(f"window is missing fields: {missing}")
        start = np.datetime64(window["calibration_start"], "h")
        stop = np.datetime64(window["calibration_stop"], "h")
        assess_start = np.datetime64(window["assessment_start"], "h")
        assess_stop = np.datetime64(window["assessment_stop"], "h")
        if not start < stop == assess_start < assess_stop:
            raise ValueError("window dates must be ordered and contiguous")
        actual_hours = int((stop - start) / np.timedelta64(1, "h"))
        if actual_hours != window.get("expected_calibration_hours"):
            raise ValueError("window expected_calibration_hours does not match dates")
    if config.get("fixed_fields", {}).get("ag") != 1 - config.get("fixed_fields", {}).get("as_", np.nan):
        raise ValueError("fixed fields must satisfy ag = 1 - as_")
    if config.get("leads") != [1, 24, 48, 120]:
        raise ValueError("forecast leads must be [1, 24, 48, 120]")
    scientific = {key: value for key, value in config.items() if key not in _PROVENANCE_KEYS}
    try:
        normalized = json.dumps(scientific, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False)
    except (TypeError, ValueError) as error:
        raise ValueError("scientific configuration is not canonical JSON") from error
    fingerprint = hashlib.sha256(normalized.encode("utf-8")).hexdigest()
    if fingerprint != _FROZEN_SCIENTIFIC_CONFIG_SHA256:
        raise ValueError("frozen scientific configuration fingerprint mismatch")
    return True


def validate_fixed_field_provenance(config: dict) -> bool:
    """Fail closed unless every fixed field has a verified, flow-safe source."""
    validate_config(config)
    fields = config["fixed_fields"]
    records = config.get("fixed_field_provenance")
    if not isinstance(records, dict) or set(records) != set(fields):
        raise ValueError("fixed-field provenance must cover every fixed field exactly")
    sources = config.get("provenance_sources")
    if not isinstance(sources, dict) or not sources:
        raise ValueError("fixed-field provenance sources are unresolved")
    failures = []
    for name, record in records.items():
        if not isinstance(record, dict):
            failures.append(f"{name}: unresolved record")
            continue
        if record.get("status") != "verified" or not isinstance(record.get("category"), str) or not record["category"].strip():
            failures.append(f"{name}: unresolved source")
        if record.get("uses_post_window_flow") is not False:
            failures.append(f"{name}: unresolved or post-window flow dependence")
        if not isinstance(record.get("enters_hydrologic_propagation"), bool):
            failures.append(f"{name}: unresolved propagation status")
        source_ids = record.get("source_ids")
        if not isinstance(source_ids, list) or not source_ids or any(source_id not in sources for source_id in source_ids):
            failures.append(f"{name}: unresolved source identifiers")
    for source_id, source in sources.items():
        if "path" not in source:
            if not source.get("url") or not source.get("locator"):
                failures.append(f"{source_id}: unresolved documentary source")
            continue
        path = Path(source["path"])
        expected_hash = source.get("sha256")
        if not path.is_file() or not isinstance(expected_hash, str):
            failures.append(f"{source_id}: local source or hash unavailable")
            continue
        actual_hash = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual_hash != expected_hash:
            failures.append(f"{source_id}: local source hash mismatch")
    if failures:
        raise ValueError("fixed-field provenance unresolved: " + "; ".join(failures))
    return True


def calibration_windows(config: dict) -> list[dict]:
    """Return independent copies of the six frozen calibration windows."""
    validate_config(config)
    return copy.deepcopy(config["windows"])


def _hourly_timestamps(timestamps) -> np.ndarray:
    values = np.asarray(timestamps)
    if values.ndim != 1 or values.size == 0 or not np.issubdtype(values.dtype, np.datetime64):
        raise ValueError("timestamps must be a nonempty one-dimensional datetime array")
    hours = values.astype("datetime64[h]")
    if np.any(values != hours) or (hours.size > 1 and np.any(np.diff(hours) != np.timedelta64(1, "h"))):
        raise ValueError("timestamps must be unique and strictly hourly")
    if hours[0] < _DATA_START or hours[-1] >= _DATA_STOP:
        raise ValueError("timestamps fall outside configured data bounds")
    return hours


def complete_origins(timestamps, start: int, stop: int, leads: Sequence[int]) -> np.ndarray:
    """Return midnight origin indices whose exact lead targets remain in bounds."""
    dates = _hourly_timestamps(timestamps)
    if not isinstance(start, (int, np.integer)) or not isinstance(stop, (int, np.integer)) or not (0 <= start <= stop <= len(dates)):
        raise ValueError("start and stop bounds are invalid")
    lead_array = np.asarray(tuple(leads))
    if lead_array.ndim != 1 or lead_array.size == 0 or not np.issubdtype(lead_array.dtype, np.integer) or np.any(lead_array <= 0):
        raise ValueError("leads must be nonempty positive integer hours")
    candidates = np.arange(start, stop, dtype=np.int64)
    candidates = candidates[dates[candidates].astype("datetime64[D]") == dates[candidates]]
    if candidates.size == 0:
        return candidates
    targets = candidates[:, None] + lead_array[None, :]
    in_bounds = np.all(targets < stop, axis=1)
    exact = np.zeros(candidates.size, dtype=bool)
    exact[in_bounds] = np.all(
        dates[targets[in_bounds]] == dates[candidates[in_bounds], None] + lead_array[None, :].astype("timedelta64[h]"),
        axis=1,
    )
    return candidates[in_bounds & exact]


def information_slices(timestamps, forcing, observations, window: dict) -> dict:
    """Copy only meteorological warmup and the calibration-window flow record."""
    dates = _hourly_timestamps(timestamps)
    forcing_values = np.asarray(forcing)
    observation_values = np.asarray(observations)
    if forcing_values.ndim < 1 or observation_values.ndim != 1 or len(forcing_values) != len(dates) or len(observation_values) != len(dates):
        raise ValueError("timestamps, forcing, and observations must have aligned first dimensions")
    missing = [key for key in _WINDOW_KEYS if key not in window]
    if missing:
        raise ValueError(f"window is missing fields: {missing}")
    start_time = np.datetime64(window["calibration_start"], "h")
    stop_time = np.datetime64(window["calibration_stop"], "h")
    start_matches = np.flatnonzero(dates == start_time)
    stop_matches = np.flatnonzero(dates == stop_time)
    if start_matches.size != 1 or stop_matches.size != 1:
        raise ValueError("calibration boundaries must each occur exactly once")
    start, stop = int(start_matches[0]), int(stop_matches[0])
    if start <= 0 or stop <= start:
        raise ValueError("calibration window requires nonempty meteorological warmup and calibration data")
    expected = window.get("expected_calibration_hours")
    if expected is not None and stop - start != expected:
        raise ValueError("calibration window has an unexpected number of hourly records")
    return {
        "warmup_timestamps": dates[:start].copy(),
        "warmup_forcing": forcing_values[:start].copy(),
        "calibration_timestamps": dates[start:stop].copy(),
        "calibration_forcing": forcing_values[start:stop].copy(),
        "calibration_observations": observation_values[start:stop].copy(),
    }


def _transition(count: int, diagonal: float = 0.99) -> list[list[float]]:
    if count == 1:
        return [[1.0]]
    off_diagonal = (1.0 - diagonal) / (count - 1)
    return [[diagonal if row == column else off_diagonal for column in range(count)] for row in range(count)]


def _arm(name: str, parameters: list[dict], diagonals: list[list[float]], groups: list[int]) -> dict:
    count = len(parameters)
    return {
        "name": name,
        "parameters": copy.deepcopy(parameters),
        "diagonals": copy.deepcopy(diagonals),
        "interaction_groups": list(groups),
        "transition_matrix": _transition(count),
        "initial_probabilities": [1.0 / count] * count,
    }


def build_assessment_arms(selected: dict, short_record: bool) -> list[dict]:
    """Build the frozen eight short-record or two long-record method definitions."""
    if not isinstance(selected, dict) or any(key not in selected for key in _SELECTED_KEYS):
        raise ValueError(f"selected must contain fields {_SELECTED_KEYS}")
    members = selected["members"]
    if not isinstance(members, list) or len(members) != 5:
        raise ValueError("selected members must contain five ordered records")
    required = {"parameter_id", "parameters", "noise_id", "diagonal", "score", "top_three_noise_ids", "top_three_noise_diagonals"}
    for rank, member in enumerate(members):
        missing = required - set(member)
        if missing:
            raise ValueError(f"member is missing fields: {sorted(missing)}")
        noise_count = len(member["top_three_noise_ids"])
        if noise_count != len(member["top_three_noise_diagonals"]) or not 1 <= noise_count <= 3:
            raise ValueError("top_three_noise_ids and top_three_noise_diagonals must have equal lengths from one to three")
        if rank == 0 and noise_count != 3:
            raise ValueError("prespecified single model must have three valid noise records")
        if member["noise_id"] != member["top_three_noise_ids"][0] or member["diagonal"] != member["top_three_noise_diagonals"][0]:
            raise ValueError("member primary noise must equal the first ranked top-three noise record")
    first = members[0]
    if first["parameter_id"] != selected["prespecified_single_parameter_id"] or first["noise_id"] != selected["prespecified_single_noise_id"]:
        raise ValueError("first ordered member must be the prespecified single model")
    single = _arm("prespecified_single_model", [first["parameters"]], [first["diagonal"]], [0])
    noise = _arm("same_parameter_three_noise_fully_interacting", [first["parameters"]] * 3, first["top_three_noise_diagonals"], [0, 0, 0])
    if not short_record:
        return [single, noise]
    arms = [_arm(f"independent_single_model_rank_{rank}", [member["parameters"]], [member["diagonal"]], [0])
            for rank, member in enumerate(members, start=1)]
    parameters = [member["parameters"] for member in members]
    diagonals = [member["diagonal"] for member in members]
    arms.extend([
        noise,
        _arm("five_parameter_fully_interacting", parameters, diagonals, [0, 0, 0, 0, 0]),
        _arm("five_parameter_no_cross_parameter_interaction", parameters, diagonals, [0, 1, 2, 3, 4]),
    ])
    return arms
