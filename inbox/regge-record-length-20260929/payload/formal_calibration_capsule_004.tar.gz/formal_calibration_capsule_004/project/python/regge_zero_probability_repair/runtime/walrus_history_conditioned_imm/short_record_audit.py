"""Read-only evidence audit and one bounded native/original numerical preflight.

No scoring, ranking, arm construction or forecast production helper is used by
the saved-run audit. The preflight alone calls the checked production path on
its native side; its reference side loads the original scalar/NumPy modules.
Neither public function writes artifacts. The caller exclusively persists them.
"""
from __future__ import annotations

import hashlib
import importlib
import importlib.util
import json
from pathlib import Path
import platform
import sys
import time

import numpy as np

from .short_record_contract import validate_config, validate_fixed_field_provenance


METHODS = {'single_model': 1, 'same_parameter_three_noise': 3,
           'five_parameter_fully_interacting': 5,
           'five_parameter_no_cross_parameter_interaction': 5}
FORMS = ('fixed', 'hourly_evolving')
REFERENCE_ROOT = Path('G:/github/pycharm/projects/paper-imm-variable-params')


class AuditError(ValueError):
    """Saved evidence violates the frozen contract or numerical fidelity."""


def _require(condition, message):
    if not condition:
        raise AuditError(message)


def _json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def _hash(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def _array_hash(value):
    return hashlib.sha256(np.ascontiguousarray(value).tobytes()).hexdigest()


def _same(actual, expected, label):
    a, b = np.asarray(actual), np.asarray(expected)
    _require(a.shape == b.shape and np.array_equal(a, b, equal_nan=a.dtype.kind in 'fc'), label)


def _close(actual, expected, tolerance, label):
    a, b = np.asarray(actual), np.asarray(expected)
    _require(a.shape == b.shape and np.isfinite(a).all() and np.isfinite(b).all(), label + ': shape/nonfinite')
    error = float(np.max(np.abs(a - b))) if a.size else 0.
    _require(error <= tolerance, f'{label}: maximum absolute error {error} exceeds {tolerance}')
    return error


def _matrix(count):
    return np.asarray([[1.]] if count == 1 else
        [[0.99 if i == j else (1. - 0.99)/(count - 1) for j in range(count)] for i in range(count)])


def _key(window):
    return f"{window['name']}__{window['months']}"


def _origins(dates, start, stop, maximum):
    indices = np.arange(start, stop, dtype=np.int64)
    midnight = dates[indices] == dates[indices].astype('datetime64[D]')
    return indices[midnight & (indices + maximum < stop)]


def _preflight_parameters(config):
    bounds = np.array([config['parameter_bounds'][k] for k in config['parameter_fields']])
    coordinates = np.asarray(config['preflight']['coordinates'])[:, None]
    values = 10 ** (np.log10(bounds[:, 0]) + coordinates * (np.log10(bounds[:, 1])-np.log10(bounds[:, 0])))
    return [dict(config['fixed_fields'], **dict(zip(config['parameter_fields'], row))) for row in values], values


def _reference_modules(root):
    """Load exact original package by path under an isolated module name."""
    folder = Path(root).resolve() / 'python' / 'imm_da'
    name = '_short_record_original_' + hashlib.sha256(str(folder).encode()).hexdigest()[:12]
    if name not in sys.modules:
        spec = importlib.util.spec_from_file_location(name, folder / '__init__.py', submodule_search_locations=[str(folder)])
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
    return tuple(importlib.import_module(name + '.' + part) for part in ('walrus', 'imm', 'ukf'))


def _reference_forecast(state, probabilities, forcing, parameters, matrix, evolve, reference, out=None):
    water = reference[0]
    x, p = np.asarray(state).copy(), np.asarray(probabilities).copy()
    result = np.full(len(forcing), np.nan) if out is None else out
    keys = list(parameters[0])
    _require(set(keys) == set(water.WalrusParams.__dataclass_fields__), 'incomplete scalar parameter record')
    values = {key: np.array([record[key] for record in parameters]) for key in keys}
    for hour, weather in enumerate(forcing):
        if evolve:
            p = p @ matrix
        _require(np.isfinite(p).all() and (p >= 0).all() and p.sum() > 0, 'reference forecast probabilities')
        weighted = {key: np.sum(p * value) for key, value in values.items()}
        x = water.walrus_step_with_params(x, water.WalrusParams(**weighted), *weather)
        _require(np.isfinite(x).all(), 'reference forecast nonfinite complete state')
        result[hour] = x[4]
    return result


def _positive_likelihoods(likelihoods, prior):
    _require(np.isfinite(likelihoods).all() and (likelihoods > 0).all(), 'reference likelihood nonpositive/nonfinite')
    _require(np.isfinite(prior).all() and (prior > 0).all(), 'reference prior nonpositive/nonfinite')
    mass = float(np.sum(likelihoods * prior))
    _require(np.isfinite(mass) and mass > 0, 'reference likelihood normalization mass')
    return mass


def _reference_update(estimator, observation, reference, reached=None):
    prior = estimator.Pi.T @ estimator.mu
    _require(np.isfinite(prior).all() and (prior > 0).all(), 'reference zero incoming probability')
    estimator.step(observation)
    values = dict(member_states=np.array([f.x for f in estimator.filters]),
        member_covariances=np.array([f.P for f in estimator.filters]),
        global_states=estimator.x.copy(), global_covariances=estimator.P.copy(),
        probabilities=estimator.mu.copy())
    if reached is not None: reached(values)
    likelihoods = []
    for model in estimator.filters:
        points = model.sigma_gen.sigma_points(model._x_pred, model._P_pred)
        transformed = np.array([model.hx(point) for point in points]).reshape(len(points), 1)
        mean, covariance = reference[2].unscented_transform(transformed, model.sigma_gen.Wm,
            model.sigma_gen.Wc, np.array([[model.R]]))
        _require(np.isfinite(covariance).all() and covariance[0, 0] > 0, 'reference observation covariance')
        likelihoods.append(reference[2]._gaussian_likelihood(np.atleast_1d(observation)-mean, covariance))
    likelihoods = np.asarray(likelihoods)
    if reached is not None:
        logs=np.full(likelihoods.shape,np.nan)
        positive=np.isfinite(likelihoods)&(likelihoods>0); logs[positive]=np.log(likelihoods[positive])
        reached(dict(likelihoods=likelihoods,normalization_mass=np.asarray(np.sum(likelihoods*prior)),log_likelihoods=logs))
    mass = _positive_likelihoods(likelihoods, prior)
    values.update(log_likelihoods=np.log(likelihoods),likelihoods=likelihoods, normalization_mass=np.asarray(mass))
    _require(all(np.isfinite(value).all() for value in values.values()), 'reference nonfinite update')
    _require((estimator.mu >= 0).all() and estimator.mu.sum() > 0, 'reference posterior probabilities')
    return values


def numerical_preflight(config, timestamps, forcing, observations, reference_root, record_event, *, reference_arithmetic='original_linear'):
    """Execute exactly the frozen 129 updates and two 120-hour forms per method.

    Known numerical/fidelity failures return all reached evidence. Unknown
    interface errors propagate. No restart, alternative bank or persistence.
    """
    _require(reference_arithmetic in ('original_linear', 'independent_log'), 'unknown reference arithmetic')
    update_reference = _reference_update
    if reference_arithmetic == 'independent_log':
        from .short_record_log_reference import reference_update_log
        update_reference = reference_update_log
    import psutil
    import torch
    from threadpoolctl import threadpool_limits
    from .noise_filter import BatchedNoiseFilters
    from .noise_search import build_noise_design
    from .short_record_calibration import isolated_filter_step, checked_deterministic_forecasts, NumericalFailure, ForecastNumericalFailure

    validate_config(config)
    dates = np.asarray(timestamps).astype('datetime64[h]')[:256]
    weather = np.asarray(forcing, dtype=np.float64)[:256]
    flows = np.asarray(observations, dtype=np.float64)[:256]
    _require(dates.shape == (256,) and weather.shape == (256, 2) and flows.shape == (256,), 'preflight first 256 shapes')
    _require(dates[0] == np.datetime64(config['data_start'], 'h') and np.all(np.diff(dates) == np.timedelta64(1, 'h')), 'preflight first 256 timestamps')
    _require(np.isfinite(weather).all() and np.isfinite(flows).all(), 'preflight nonfinite inputs')
    records, values = _preflight_parameters(config)
    noise = build_noise_design(config['noise_design']['seed'])
    _require(_array_hash(noise) == config['noise_design']['hash_sha256'], 'preflight frozen noise hash')
    arrays = dict(timestamps=dates.copy(), forcing=weather.copy(), observations=flows.copy(),
        update_indices=np.arange(129, dtype=np.int64), forecast_indices=np.arange(129,249,dtype=np.int64),
        parameter_values=values, noise_diagonals=noise[:3].copy())
    for name, count in METHODS.items():
        shapes = dict(member_states=(129,count,5), member_covariances=(129,count,5,5),
            global_states=(129,5), global_covariances=(129,5,5), probabilities=(129,count),
            log_likelihoods=(129,count), fixed_predictions=(120,), hourly_evolving_predictions=(120,))
        for side in ('native', 'reference'):
            for quantity, shape in shapes.items(): arrays[f'{name}__{side}__{quantity}'] = np.full(shape,np.nan)
        arrays[f'{name}__reference__likelihoods'] = np.full((129,count),np.nan)
        arrays[f'{name}__reference__normalization_mass'] = np.full(129,np.nan)
        if reference_arithmetic == 'independent_log':
            arrays[f'{name}__reference__prior_probabilities'] = np.full((129,count),np.nan)
            arrays[f'{name}__reference__log_normalization_mass'] = np.full(129,np.nan)
    checks = dict(schema='regge_short_record_preflight_checks_v01', passed=False,
        completed_update_hours=0, forecast_hours=0, arm_model_counts=METHODS.copy(), maxima={}, stop_reason=None)
    if reference_arithmetic == 'independent_log':
        checks.update(schema='regge_short_record_log_reference_checks_v01', reference_arithmetic=reference_arithmetic)
    components = dict(filter=0., forecast=0., reference_filter=0., reference_forecast=0.)
    counts = dict(filter_member_hours=0, forecast_hydrologic_steps=0, max_concurrent_candidates=5)
    process = psutil.Process(); baseline = process.memory_info().rss; peak = baseline
    started = time.perf_counter(); reference = _reference_modules(reference_root)
    previous_threads = torch.get_num_threads(); torch.set_num_threads(1)
    phase, name, form = 'setup', None, None
    try:
        with threadpool_limits(limits=1), torch.no_grad():
            for name, count in METHODS.items():
                phase, form = 'setup', None
                bank = [records[0]] * count if count < 5 else records
                diagonals = noise[np.arange(count) % 3] if count > 1 else noise[:1]
                groups = list(range(count)) if name.endswith('no_cross_parameter_interaction') else [0]*count
                matrix = _matrix(count)
                adapter = BatchedNoiseFilters([bank], diagonals[None], interaction_groups=[groups])
                state = adapter.initial_state(); current_forcing = np.zeros(2)
                functions = [lambda x, p=reference[0].WalrusParams(**record): reference[0].walrus_step_with_params(x,p,*current_forcing) for record in bank]
                x0 = np.asarray(config['initial_state'],float)
                estimator = reference[1].build_imm_mukf(5,1,functions,lambda x: x[4], np.diag(diagonals[0]),
                    config['observation_variance'], x0, np.diag((config['initial_covariance_fraction']*x0)**2),
                    matrix, np.full(count,1/count), **config['sigma_points'],
                    Q_list=[np.diag(row) for row in diagonals], mix_states=True, state_interaction_groups=np.asarray(groups))
                for hour in range(129):
                    phase = 'update'
                    tick=time.perf_counter()
                    native=isolated_filter_step(adapter,state,weather[hour:hour+1],flows[hour:hour+1],matrix,np.ones(1,bool))
                    components['filter'] += time.perf_counter()-tick
                    _require(native['alive'][0], f'{name} native update failure: {native["failures"]}')
                    state=native['state']; counts['filter_member_hours'] += count
                    native_values=dict(member_states=state.states[0].numpy(),member_covariances=state.covariances[0].numpy(),
                        probabilities=state.probabilities[0].numpy(), **{q:native[q][0].numpy() for q in ('global_states','global_covariances','log_likelihoods')})
                    for quantity,value in native_values.items(): arrays[f'{name}__native__{quantity}'][hour]=value
                    current_forcing[:]=weather[hour]
                    tick=time.perf_counter()
                    def retain(values_reached):
                        for quantity,value in values_reached.items(): arrays[f'{name}__reference__{quantity}'][hour]=value
                    try: reference_values=update_reference(estimator,flows[hour],reference,retain)
                    finally: components['reference_filter'] += time.perf_counter()-tick
                    for quantity,value in reference_values.items(): arrays[f'{name}__reference__{quantity}'][hour]=value
                    for quantity,value in native_values.items():
                        tolerance=_quantity_tolerance(quantity,config)
                        error=_close(value,reference_values[quantity],tolerance,f'{name} hour {hour} {quantity}')
                        key=f'{name}__{quantity}'; checks['maxima'][key]=max(checks['maxima'].get(key,0.),error)
                    error=_close(native_values['global_states'][4], reference_values['global_states'][4],
                        config['preflight']['global_discharge_absolute_tolerance'],f'{name} hour {hour} global discharge')
                    key=f'{name}__global_discharge'; checks['maxima'][key]=max(checks['maxima'].get(key,0.),error)
                    peak=max(peak,process.memory_info().rss)
                checks['completed_update_hours']=129
                for form in FORMS:
                    phase = 'forecast'
                    tick=time.perf_counter()
                    try:
                        predicted=checked_deterministic_forecasts(native['global_states'],state.probabilities,
                            weather[129:249][None],[bank],matrix,tuple(range(1,121)),evolve=form=='hourly_evolving')
                        arrays[f'{name}__native__{form}_predictions'][:]=predicted[0].numpy()
                        counts['forecast_hydrologic_steps']+=120
                    except ForecastNumericalFailure as error:
                        arrays[f'{name}__native__{form}_predictions'][:]=error.predictions[0].numpy()
                        raise
                    finally: components['forecast']+=time.perf_counter()-tick
                    tick=time.perf_counter()
                    try: _reference_forecast(estimator.x,estimator.mu,weather[129:249],bank,matrix,
                        form=='hourly_evolving',reference,arrays[f'{name}__reference__{form}_predictions'])
                    finally: components['reference_forecast']+=time.perf_counter()-tick
                    checks['maxima'][f'{name}__{form}_predictions']=_close(arrays[f'{name}__native__{form}_predictions'],
                        arrays[f'{name}__reference__{form}_predictions'],config['preflight']['forecast_absolute_tolerance'],name+' forecast')
                for side in ('native','reference'):
                    _form_identity(arrays[f'{name}__{side}__fixed_predictions'],arrays[f'{name}__{side}__hourly_evolving_predictions'],count,count==3)
                peak=max(peak,process.memory_info().rss)
                record_event('numerical_preflight_method_complete',method=name,updates=129,forecast_hours=120)
            checks.update(passed=True,forecast_hours=120)
    except (AuditError,NumericalFailure,np.linalg.LinAlgError,torch.linalg.LinAlgError,FloatingPointError) as error:
        checks['stop_reason']=f'{type(error).__name__}: {error}'
        context = {}
        if reference_arithmetic == 'independent_log':
            context = dict(phase=phase, method=name)
            if phase == 'update':
                context.update(hour=hour, timestamp=str(dates[hour]))
            elif phase == 'forecast':
                failed_offset = getattr(error, 'failed_hour', None)
                failed_time = None
                if type(failed_offset) is int and 0 < failed_offset < len(dates)-128:
                    failed_time = str(dates[128+failed_offset])
                context.update(forecast_form=form, forecast_origin_hour=128,
                    forecast_origin_timestamp=str(dates[128]), failed_forecast_offset_hours=failed_offset,
                    failed_forecast_timestamp=failed_time)
            checks['failure_context'] = context
        record_event('numerical_preflight_failed',reason=checks['stop_reason'], **context)
    finally:
        torch.set_num_threads(previous_threads)
    runtime=dict(elapsed_seconds=time.perf_counter()-started,native_seconds=components['filter']+components['forecast'],
        reference_seconds=components['reference_filter']+components['reference_forecast'], baseline_rss_bytes=baseline,
        peak_rss_bytes=peak,memory_measurement_kind='sampled_process_rss',component_seconds=components,work_counts=counts)
    return dict(passed=checks['passed'],checks=checks,arrays=arrays,runtime=runtime)


def _quantity_tolerance(quantity,config):
    suffix = ('covariance' if 'covariances' in quantity else 'probability' if quantity=='probabilities'
              else 'log_likelihood' if quantity=='log_likelihoods' else 'forecast' if 'predictions' in quantity else 'state')
    return config['preflight'][suffix+'_absolute_tolerance']


def _form_identity(fixed,evolving,count,same_parameter):
    if count==1: _same(fixed,evolving,'single-model forecast form identity')
    elif same_parameter:
        _require(np.allclose(fixed,evolving,rtol=1e-10,atol=1e-12,equal_nan=True),'same-parameter forecast form identity')


def _manifest(root):
    root=Path(root).resolve(); manifest=_json(root/'manifest.json')
    _require(manifest.get('schema')=='regge_short_record_manifest_v01' and manifest.get('excluded')==['manifest.json','audit.json'], 'manifest schema/exclusions')
    files=manifest.get('files'); _require(isinstance(files,dict),'manifest file map')
    for name in files:
        path=Path(name)
        _require(not path.is_absolute() and '..' not in path.parts and (root/path).resolve().is_relative_to(root), 'manifest unsafe path')
    actual={p.relative_to(root).as_posix():_hash(p) for p in root.rglob('*')
            if p.is_file() and p.relative_to(root).as_posix() not in ('manifest.json','audit.json')}
    _require(actual==files,'manifest file set/hash mismatch')
    return files


def _source_binding(root,receipt,check_current=True):
    binding=receipt['binding']; rows=_json(root/'source_snapshot/index.json')
    _require(isinstance(rows,list) and len(rows)==len(binding['source_hashes']),'source snapshot count')
    _require({r['original_path']:r['sha256'] for r in rows}==binding['source_hashes'],'source snapshot binding')
    for row in rows:
        relative=Path(row['snapshot_path'])
        _require(not relative.is_absolute() and '..' not in relative.parts and (root/relative).resolve().is_relative_to(root.resolve()),'source unsafe snapshot')
        _require(_hash(root/relative)==row['sha256'],'source snapshot changed')
        if check_current: _require(_hash(row['original_path'])==row['sha256'],'source current code changed')
    _require(_json(root/'provenance_before_load.json')==binding['source_hashes']==_json(root/'input_hashes_after.json'),'source changed during run')
    matching=[r for r in rows if r['sha256']==binding['config_sha256']]
    _require(any(_json(root/r['snapshot_path'])==_json(root/'config.json') for r in matching),'configuration snapshot mismatch')


def _chronology(events,windows):
    _same([r['sequence'] for r in events],np.arange(1,len(events)+1),'event sequence')
    keys=[_key(w) for w in windows]; lookup=dict(zip(keys,windows)); starts=[]; freezes=[]; assessments=[]
    current=None; access=[]; all_frozen=False
    for row in events:
        event=row['event']
        if event=='calibration_start':
            _require(not all_frozen and not assessments and (current is None or current in freezes),'calibration chronology')
            current=row['window']; starts.append(current); _require(current in lookup,'unknown calibration window')
        elif event=='selection_observation_access':
            _require(current is not None and current not in access and current not in freezes,'observation access chronology')
            w=lookup[current]
            _require(np.datetime64(row['earliest'],'h')==np.datetime64(w['calibration_start'],'h') and
                np.datetime64(row['latest'],'h')==np.datetime64(w['calibration_stop'],'h')-np.timedelta64(1,'h') and
                row['observation_count']==w['expected_calibration_hours'],'forbidden warmup/assessment observation access')
            access.append(current)
        elif event=='selection_frozen':
            _require(row['window']==current and current in access and current not in freezes,'selection chronology')
            _require(np.datetime64(row['cutoff'],'h')==np.datetime64(lookup[current]['calibration_stop'],'h'),'selection cutoff')
            freezes.append(current)
        elif event=='all_selections_frozen':
            _require(not all_frozen and freezes==keys and row['count']==len(keys),'all selections chronology')
            all_frozen=True
        elif event.startswith('assessment'):
            _require(all_frozen,'assessment before six selections frozen')
            if event=='assessment_start': assessments.append(row['window'])
        elif 'observation_access' in event or 'warmup_flow' in event:
            raise AuditError('unpermitted observation access event')
    _require(starts==keys and freezes==keys and access==keys and assessments==keys and all_frozen,'incomplete chronology')


def _metrics(predictions,targets,valid):
    prediction=np.asarray(predictions,float); target=np.asarray(targets,float)
    _require(prediction.shape==target.shape and target.ndim==2 and len(target)>0 and np.isfinite(target).all(),'metric shape/target')
    if not valid: return dict(valid=False,count=len(target),rmse=[None]*target.shape[1],nse=[None]*target.shape[1],reason='whole method unavailable')
    _require(np.isfinite(prediction).all(),'valid arm missing predictions')
    try:
        with np.errstate(over='raise',invalid='raise',divide='raise'):
            squared=np.sum((prediction-target)**2,axis=0)
            rmse=np.sqrt(squared/len(target))
        if not np.isfinite(rmse).all(): raise FloatingPointError('nonfinite root mean square error')
    except FloatingPointError:
        return dict(valid=False,count=len(target),rmse=[None]*target.shape[1],nse=[None]*target.shape[1],
                    reason='unrepresentable root mean square error arithmetic')
    efficiency=[]; reasons=[]
    for column in range(target.shape[1]):
        try:
            with np.errstate(over='raise',invalid='raise',divide='raise'):
                variance=np.sum((target[:,column]-np.mean(target[:,column]))**2)
                value=1-squared[column]/variance if variance>0 else np.nan
            if not np.isfinite(value): raise FloatingPointError('undefined efficiency')
            efficiency.append(float(value)); reasons.append(None)
        except FloatingPointError:
            efficiency.append(None); reasons.append('undefined or unrepresentable efficiency arithmetic')
    return dict(valid=True,count=len(target),rmse=rmse.tolist(),nse=efficiency,reason=None,nse_unavailable_reasons=reasons)


def _ratio(value,reference):
    if value is None or reference is None or not np.isfinite(value) or not np.isfinite(reference) or reference<=0: return None
    return _finite_arithmetic(lambda: value/reference)


def _finite_arithmetic(operation):
    try:
        with np.errstate(over='raise',invalid='raise',divide='raise'):
            value=float(operation())
        return value if np.isfinite(value) else None
    except (FloatingPointError, OverflowError, ZeroDivisionError):
        return None


def _percent(ratio):
    return None if ratio is None else _finite_arithmetic(lambda: 100*(ratio-1))


def _threshold(value,reference,persistence):
    ratio=_ratio(value,reference); baseline=_ratio(reference,persistence); improvement=_ratio(value,persistence)
    eligible=all(v is not None and np.isfinite(v) for v in (value,reference,persistence)) and reference>0 and persistence>0
    tolerance=bool(eligible and value<=1.05*reference)
    minimum=bool(eligible and value<=0.95*persistence)
    reference_minimum=bool(eligible and reference<=0.95*persistence)
    return dict(rmse=value,reference_rmse=reference,persistence_rmse=persistence,reference_ratio=ratio,
        persistence_ratio=improvement,reference_persistence_ratio=baseline,
        relative_error_change_percent=_percent(ratio),
        ratio_unavailable_reason=None if all(v is not None for v in (ratio,baseline,improvement)) else 'unavailable or unrepresentable ratio or nonpositive reference',
        percent_unavailable_reason=None if _percent(ratio) is not None else 'unavailable or unrepresentable percent change',
        allowed_loss_satisfied=tolerance,minimum_improvement_satisfied=minimum,
        reference_minimum_improvement_satisfied=reference_minimum,passed=bool(tolerance and minimum and reference_minimum))


def _parameter_design(config):
    rng=np.random.default_rng(config['parameter_design']['seed']); count=config['parameter_design']['count']
    jitter=rng.random((count,5)); coordinates=np.empty_like(jitter)
    for column in range(5): coordinates[:,column]=(rng.permutation(count)+jitter[:,column])/count
    bounds=np.array([config['parameter_bounds'][key] for key in config['parameter_fields']])
    return 10**(np.log10(bounds[:,0])+coordinates*(np.log10(bounds[:,1])-np.log10(bounds[:,0])))


def _raw_schema(raw,shapes):
    for key,(shape,dtype) in shapes.items():
        value=raw[key]
        _require(value.shape==shape and value.dtype==np.dtype(dtype),f'raw array schema: {key}')


def _calibration_audit(raw,result,config,window,dates,weather,flows):
    """Independent complete raw-derived errors, ranking and selected records."""
    start=int(np.searchsorted(dates,np.datetime64(window['calibration_start'],'h')))
    stop=int(np.searchsorted(dates,np.datetime64(window['calibration_stop'],'h')))
    local_dates=dates[start:stop]; hours=len(local_dates); count=config['parameter_design']['count']
    noise_count=config['noise_design']['count']; joints=16*noise_count
    origins=_origins(local_dates,0,hours,120); targets=origins[:,None]+np.array(config['leads'])[None]
    sizes=dict(parameter_values=((count,5),'float64'),parameter_ids=((count,),'int64'),noise_design=((noise_count,5),'float64'),
        warmup_states=((count,5),'float64'),hydrologic_predictions=((count,hours),'float64'),hydrologic_prediction_mask=((count,hours),'bool'),
        hydrologic_valid=((count,),'bool'),hydrologic_errors=((count,),'float64'),shortlist_parameter_ids=((16,),'int64'),
        joint_parameter_ids=((joints,),'int64'),joint_noise_ids=((joints,),'int64'),joint_predictions=((joints,len(origins),4),'float64'),
        joint_prediction_mask=((joints,len(origins),4),'bool'),joint_valid=((joints,),'bool'),joint_errors=((joints,4),'float64'),joint_scores=((joints,),'float64'))
    _raw_schema(raw,sizes)
    _require(result['status']=='complete' and result['window']==window,'calibration status/window')
    hashes=result['array_hashes']; _require(set(hashes)==set(raw.files if hasattr(raw,'files') else raw),'calibration array hash keys')
    for key,spec in hashes.items():
        value=raw[key]
        _require(spec==dict(sha256=_array_hash(value),dtype=str(value.dtype),shape=list(value.shape)),f'calibration array hash: {key}')
    expected_values=_parameter_design(config); _same(raw['parameter_values'],expected_values,'parameter candidate design')
    _same(raw['parameter_ids'],np.arange(count),'parameter row IDs')
    _require(_array_hash(raw['noise_design'])==config['noise_design']['hash_sha256'],'noise design hash')
    records=[dict(config['fixed_fields'],**dict(zip(config['parameter_fields'],row.tolist()))) for row in expected_values]
    _require(result['parameters']==records,'complete parameter records')
    alignment=dict(warmup_timestamps=dates[:start],warmup_forcing=weather[:start],
        calibration_timestamps=local_dates,calibration_forcing=weather[start:stop],calibration_observations=flows[start:stop],
        calibration_indices=np.arange(hours),origin_indices=origins,target_indices=targets,
        origin_timestamps=local_dates[origins],target_timestamps=local_dates[targets],target_observations=flows[start:stop][targets],
        persistence_predictions=np.broadcast_to(flows[start:stop][origins,None],targets.shape),persistence_mask=np.ones(targets.shape,bool))
    for key,expected in alignment.items(): _same(raw[key],expected,'calibration alignment: '+key)
    _require(hours==window['expected_calibration_hours'],'calibration hour denominator')
    failures=result['failures']; hydro_failed=set(); joint_failed=set()
    hydro_score_failed=set(); joint_error_failed=set(); joint_score_failed=set()
    for failure in failures:
        stage=failure['stage']; row=failure['candidate_row']; index=failure['index']
        axis=dates[:start] if stage=='warmup' else local_dates
        _require(0<=index<len(axis) and np.datetime64(failure['timestamp'],'h')==axis[index] and bool(failure['reason']),'failure time/reason')
        if stage in ('warmup','hydrologic'):
            _require(0<=row<count and failure['parameter_id']==row,'hydrologic failure identity'); hydro_failed.add(row)
        elif stage=='hydrologic_score':
            _require(0<=row<count and failure['parameter_id']==row and index==hours-1 and
                     failure['reason']=='nonfinite hydrologic error arithmetic','hydrologic scoring failure identity')
            hydro_score_failed.add(row)
        elif stage in ('filter','forecast'):
            _require(0<=row<joints and failure['parameter_id']==raw['joint_parameter_ids'][row] and failure['noise_id']==raw['joint_noise_ids'][row],'joint failure identity')
            if failure['reason'] in ('nonfinite joint error arithmetic','nonfinite joint relative-score arithmetic'):
                _require(stage=='filter' and index==hours-1,'joint scoring failure identity')
                (joint_error_failed if failure['reason']=='nonfinite joint error arithmetic' else joint_score_failed).add(row)
            else: joint_failed.add(row)
        else: raise AuditError('unknown candidate failure stage')
    hydro=raw['hydrologic_predictions']; joint=raw['joint_predictions']
    _same(raw['hydrologic_prediction_mask'],np.isfinite(hydro),'hydrologic mask')
    _same(raw['joint_prediction_mask'],np.isfinite(joint),'joint mask')
    _require(not hydro_failed.intersection(hydro_score_failed),'hydrologic scoring after propagation failure')
    _require(not (joint_failed.intersection(joint_error_failed|joint_score_failed) or joint_error_failed.intersection(joint_score_failed)),
             'joint scoring after earlier failure')
    hydro_eligible=np.ones(count,bool); hydro_eligible[list(hydro_failed)]=False
    _require(np.isfinite(raw['warmup_states'][hydro_eligible]).all(),'valid hydrologic warmup state')
    hydro_errors=np.full(count,np.inf)
    for row in np.flatnonzero(hydro_eligible):
        _require(np.isfinite(hydro[row]).all(),'valid hydrologic missing predictions')
        try:
            with np.errstate(over='raise',invalid='raise'):
                hydro_errors[row]=np.sqrt(np.mean((hydro[row]-flows[start:stop])**2))
        except FloatingPointError:
            pass  # Reproduce arithmetic classification; never propagate a model.
    _require(set(np.flatnonzero(hydro_eligible & ~np.isfinite(hydro_errors)))==hydro_score_failed,'hydrologic arithmetic failure evidence')
    hydro_valid=hydro_eligible & np.isfinite(hydro_errors)
    _same(raw['hydrologic_valid'],hydro_valid,'whole hydrologic validity')
    _same(raw['hydrologic_errors'],hydro_errors,'raw recomputed hydrologic errors')
    shortlist=np.array(sorted(np.flatnonzero(hydro_valid),key=lambda row:(hydro_errors[row],row))[:16],dtype=np.int64)
    _require(len(shortlist)==16,'insufficient hydrologic candidates')
    _same(raw['shortlist_parameter_ids'],shortlist,'hydrologic shortlist order')
    pids=np.repeat(shortlist,noise_count); nids=np.tile(np.arange(noise_count),16)
    _same(raw['joint_parameter_ids'],pids,'joint parameter order'); _same(raw['joint_noise_ids'],nids,'joint noise order')
    target=alignment['target_observations']; reference=np.sqrt(np.mean((alignment['persistence_predictions']-target)**2,axis=0))
    _require(np.isfinite(reference).all() and (reference>0).all(),'calibration persistence denominator')
    _same(raw['reference_errors'],reference,'reference errors')
    joint_errors=np.full((joints,4),np.inf); scores=np.full(joints,np.inf)
    joint_eligible=np.ones(joints,bool); joint_eligible[list(joint_failed)]=False
    for row in np.flatnonzero(joint_eligible):
        _require(np.isfinite(joint[row]).all(),'valid joint missing predictions')
        try:
            with np.errstate(over='raise',invalid='raise'):
                joint_errors[row]=np.sqrt(np.mean((joint[row]-target)**2,axis=0))
        except FloatingPointError:
            pass
    finite_errors=np.isfinite(joint_errors).all(axis=1)
    _require(set(np.flatnonzero(joint_eligible & ~finite_errors))==joint_error_failed,'joint error arithmetic failure evidence')
    for row in np.flatnonzero(finite_errors):
        try:
            with np.errstate(over='raise',invalid='raise',divide='raise'):
                scores[row]=np.mean(joint_errors[row]/reference)
        except FloatingPointError:
            pass  # Finite errors remain evidence when the relative score overflows.
    _require(set(np.flatnonzero(finite_errors & ~np.isfinite(scores)))==joint_score_failed,'joint relative-score arithmetic failure evidence')
    joint_valid=joint_eligible & finite_errors & np.isfinite(scores)
    _same(raw['joint_valid'],joint_valid,'whole joint validity')
    _same(raw['joint_errors'],joint_errors,'raw recomputed joint errors'); _same(raw['joint_scores'],scores,'raw recomputed joint scores')
    order=sorted(np.flatnonzero(joint_valid),key=lambda row:(scores[row],pids[row],nids[row]))
    _same(raw['joint_rank_order'],order,'joint rank order')
    by_parameter={}
    for row in order: by_parameter.setdefault(int(pids[row]),[]).append(row)
    members_order=sorted(by_parameter,key=lambda pid:(scores[by_parameter[pid][0]],pid))[:5]
    _require(len(members_order)==5 and len(by_parameter[members_order[0]])>=3,'selected candidate count gates')
    members=[]
    for pid in members_order:
        rows=by_parameter[pid][:3]; noises=nids[rows]; first=rows[0]
        members.append(dict(parameter_id=pid,parameters=records[pid],noise_id=int(noises[0]),
            diagonal=raw['noise_design'][noises[0]].tolist(),score=float(scores[first]),
            top_three_noise_ids=noises.tolist(),top_three_noise_diagonals=raw['noise_design'][noises].tolist()))
    selected=dict(members=members,prespecified_single_parameter_id=members_order[0],prespecified_single_noise_id=members[0]['noise_id'],
        selection_cutoff=str(np.datetime64(window['calibration_stop'],'h')),
        source_hashes={key:_array_hash(raw[key]) for key in ('parameter_values','noise_design','warmup_forcing','calibration_forcing','calibration_observations','calibration_timestamps')})
    _require(result['selected']==selected,'independent selected members/noises/order')
    availability={str(n):bool(np.isfinite(hydro_errors[:n]).any()) for n in config['parameter_design']['prefix_diagnostics']}
    prefix={str(n):float(np.min(hydro_errors[:n])) if availability[str(n)] else None for n in config['parameter_design']['prefix_diagnostics']}
    _require(result['prefix_diagnostics']==prefix,'prefix diagnostic')
    return dict(selected=selected,hydrologic_error_sha256=_array_hash(hydro_errors),joint_error_sha256=_array_hash(joint_errors),
        joint_score_sha256=_array_hash(scores),prefix_diagnostics=prefix,prefix_availability=availability,
        calibration_hours=hours,selection_origin_count=len(origins),
        valid_hydrologic_candidates=int(hydro_valid.sum()),valid_joint_candidates=int(joint_valid.sum()),
        selected_parameter_values=expected_values[members_order].tolist(),
        pairwise_log10_parameter_distances=[[float(np.linalg.norm(np.log10(expected_values[i])-np.log10(expected_values[j]))) for j in members_order] for i in members_order])


def _expected_arms(selected,short):
    """Derive the frozen bank definitions independently from audited selection."""
    members=selected['members']; first=members[0]
    def make(name,bank,diagonals,groups):
        return dict(name=name,parameters=bank,diagonals=diagonals,interaction_groups=groups,
            transition_matrix=_matrix(len(bank)).tolist(),initial_probabilities=[1/len(bank)]*len(bank))
    singles=[make(f'independent_single_model_rank_{rank+1}',[member['parameters']],[member['diagonal']],[0]) for rank,member in enumerate(members)]
    noise=make('same_parameter_three_noise_fully_interacting',[first['parameters']]*3,first['top_three_noise_diagonals'],[0]*3)
    if not short: return [make('prespecified_single_model',[first['parameters']],[first['diagonal']],[0]),noise]
    return singles+[noise,make('five_parameter_fully_interacting',[m['parameters'] for m in members],[m['diagonal'] for m in members],[0]*5),
        make('five_parameter_no_cross_parameter_interaction',[m['parameters'] for m in members],[m['diagonal'] for m in members],list(range(5)))]


def _assessment_audit(raw,metadata,arm,window,config,dates,weather,flows,reference):
    start=int(np.searchsorted(dates,np.datetime64(window['assessment_start'],'h')))
    stop=int(np.searchsorted(dates,np.datetime64(window['assessment_stop'],'h')))
    calstart=int(np.searchsorted(dates,np.datetime64(window['calibration_start'],'h')))
    origins=_origins(dates,start,stop,120); targets=origins[:,None]+np.arange(1,121)[None]
    _require(len(origins)==window['expected_complete_origins'],'assessment origin count')
    _require(metadata['arm']==arm,'assessment member bank/noise/group/matrix')
    _require(metadata['replay_bounds']==[calstart,stop] and metadata['calibration_stop']==start,'continuous replay bounds')
    alignment=dict(origin_indices=origins,target_indices=targets,origin_timestamps=dates[origins],target_timestamps=dates[targets],
        origin_forcing=weather[origins],future_forcing=weather[targets],target_observations=flows[targets],
        persistence_predictions=np.broadcast_to(flows[origins,None],targets.shape))
    for key,value in alignment.items(): _same(raw[key],value,'assessment alignment: '+key)
    models=len(arm['parameters']); count=len(origins)
    schema=dict(global_states=((count,5),'float64'),global_covariances=((count,5,5),'float64'),
        member_states=((count,models,5),'float64'),member_covariances=((count,models,5,5),'float64'),probabilities=((count,models),'float64'))
    for form in FORMS:
        schema[form+'_predictions']=((count,120),'float64'); schema[form+'_prediction_mask']=((count,120),'bool')
    _raw_schema(raw,schema)
    valid=metadata['valid']; _require(isinstance(valid,bool),'whole arm validity type')
    failures=metadata['failures']; _require(valid == (len(failures)==0),'whole arm failure flag')
    for failure in failures:
        index=failure['index']; _require(calstart<=index<stop and np.datetime64(failure['timestamp'],'h')==dates[index] and failure['reason'],'assessment failure index/reason')
    for form in FORMS:
        _same(raw[form+'_prediction_mask'],np.isfinite(raw[form+'_predictions']),'assessment prediction mask')
        if valid: _require(np.isfinite(raw[form+'_predictions']).all(),'valid arm full forecast requirement')
    # Form identity is required on completed pairs, including retained evidence of
    # invalid arms; unavailable later forms are not claimed as matching pairs.
    fixed=raw['fixed_predictions']; evolving=raw['hourly_evolving_predictions']
    both=np.isfinite(fixed)&np.isfinite(evolving)
    _form_identity(fixed[both],evolving[both],models,models==3)
    maxima={form:0. for form in FORMS}; steps=0
    for row in range(count):
        x=raw['global_states'][row]; p=raw['probabilities'][row]
        if not np.isfinite(x).all():
            _require(not valid and not any(np.isfinite(raw[form+'_predictions'][row]).any() for form in FORMS),'forecast without finite origin state')
            continue
        _require(np.isfinite(p).all() and (p>=0).all() and abs(p.sum()-1)<=config['preflight']['probability_absolute_tolerance'],'origin probabilities')
        states=raw['member_states'][row]; covariances=raw['member_covariances'][row]
        global_state=np.sum(p[:,None]*states,axis=0)
        difference=states-global_state
        global_cov=np.sum(p[:,None,None]*(covariances+difference[:,:,None]*difference[:,None,:]),axis=0)
        _close(x,global_state,config['preflight']['state_absolute_tolerance'],'combined global state')
        _close(raw['global_covariances'][row],global_cov,config['preflight']['covariance_absolute_tolerance'],'combined global covariance')
        for form in FORMS:
            mask=raw[form+'_prediction_mask'][row]; reached=int(mask.sum())
            _same(mask,np.arange(120)<reached,'forecast finite prefix')
            if not reached: continue
            predicted=_reference_forecast(x,p,weather[targets[row,:reached]],arm['parameters'],np.asarray(arm['transition_matrix']),form=='hourly_evolving',reference)
            maxima[form]=max(maxima[form],_close(raw[form+'_predictions'][row,:reached],predicted,
                config['preflight']['forecast_absolute_tolerance'],'full scalar forecast reconstruction'))
            steps+=reached
    first_month=dates[origins]<np.datetime64(window['assessment_start'],'h')+np.timedelta64(30,'D')
    _require(int(first_month.sum())==30,'first 30 day origin count')
    metrics={}
    for period,mask in (('full',np.ones(count,bool)),('first_30_days',first_month)):
        target=flows[targets[mask]][:,np.array(config['leads'])-1]
        metrics[period]={form:_metrics(raw[form+'_predictions'][mask][:,np.array(config['leads'])-1],target,valid) for form in FORMS}
        metrics[period]['persistence']=_metrics(alignment['persistence_predictions'][mask][:,np.array(config['leads'])-1],target,True)
    score_valid=valid and all(metrics[period][form]['valid'] for period in metrics for form in FORMS)
    score_reasons=sorted({metrics[period][form]['reason'] for period in metrics for form in FORMS if not metrics[period][form]['valid']})
    if not score_valid:
        for period in metrics:
            for form in FORMS:
                metrics[period][form].update(valid=False,rmse=[None]*len(config['leads']),nse=[None]*len(config['leads']),
                    reason='whole method unscorable: '+'; '.join(score_reasons))
    return dict(name=arm['name'],valid=score_valid,source_valid=valid,score_valid=score_valid,score_unavailable_reasons=score_reasons,
        metrics=metrics,reconstruction_maximum_absolute_errors=maxima,
        reconstructed_hour_count=steps,origin_count=count,first_30_days_origin_count=int(first_month.sum()))


def _preflight_saved(root,receipt,config,inputs):
    """Check saved short-prefix evidence without dispatching a model."""
    _preflight_receipt(receipt)
    return _preflight_saved_evidence(root,receipt,config,inputs)


def _preflight_receipt(receipt):
    _require(receipt.get('mode')=='preflight' and receipt.get('status')=='preflight_complete' and receipt.get('passed') is True
        and receipt.get('test_only') is False and receipt.get('scientific_binding_eligible') is True,'stale/test-only/failed preflight receipt')


def _preflight_saved_evidence(root,receipt,config,inputs, *, reference_arithmetic='original_linear'):
    _require(reference_arithmetic in ('original_linear','independent_log'), 'unknown reference arithmetic')
    _manifest(root); _source_binding(root,receipt)
    checks=_json(root/'preflight/checks.json')
    schema = 'regge_short_record_log_reference_checks_v01' if reference_arithmetic == 'independent_log' else 'regge_short_record_preflight_checks_v01'
    _require(checks.get('schema')==schema and checks.get('passed') is True and
        checks.get('completed_update_hours')==129 and checks.get('forecast_hours')==120 and checks.get('arm_model_counts')==METHODS,'preflight checks schema')
    with np.load(root/'preflight/arrays.npz',allow_pickle=False) as raw:
        _raw_schema(raw,dict(timestamps=((256,),'datetime64[h]'),forcing=((256,2),'float64'),observations=((256,),'float64'),
            update_indices=((129,),'int64'),forecast_indices=((120,),'int64'),parameter_values=((5,5),'float64'),noise_diagonals=((3,5),'float64')))
        for key in ('timestamps','forcing','observations'): _same(raw[key],inputs[key][:256],'preflight input identity')
        _same(raw['update_indices'],np.arange(129),'preflight update indices'); _same(raw['forecast_indices'],np.arange(129,249),'preflight forecast indices')
        _same(raw['parameter_values'],_preflight_parameters(config)[1],'preflight parameter bank')
        from .noise_search import build_noise_design
        _same(raw['noise_diagonals'],build_noise_design(config['noise_design']['seed'])[:3],'preflight noise bank')
        maxima={}
        for method,count in METHODS.items():
            shapes=dict(member_states=(129,count,5),member_covariances=(129,count,5,5),global_states=(129,5),
                global_covariances=(129,5,5),probabilities=(129,count),log_likelihoods=(129,count),fixed_predictions=(120,),hourly_evolving_predictions=(120,))
            for quantity,shape in shapes.items():
                for side in ('native','reference'): _raw_schema(raw,{f'{method}__{side}__{quantity}':(shape,'float64')})
                maxima[f'{method}__{quantity}']=_close(raw[f'{method}__native__{quantity}'],raw[f'{method}__reference__{quantity}'],
                    _quantity_tolerance(quantity,config),'saved preflight '+quantity)
            _close(raw[f'{method}__native__global_states'][:,4],raw[f'{method}__reference__global_states'][:,4],config['preflight']['global_discharge_absolute_tolerance'],'preflight global discharge')
            _raw_schema(raw,{f'{method}__reference__likelihoods':((129,count),'float64'),f'{method}__reference__normalization_mass':((129,),'float64')})
            for quantity in ('likelihoods','normalization_mass'):
                v=raw[f'{method}__reference__{quantity}']; _require(np.isfinite(v).all() and (v>=0 if reference_arithmetic == 'independent_log' else v>0).all(),'preflight reference likelihood/mass')
            if reference_arithmetic == 'independent_log':
                _saved_log_arithmetic(raw, method, count, config)
            for side in ('native','reference'):
                _form_identity(raw[f'{method}__{side}__fixed_predictions'],raw[f'{method}__{side}__hourly_evolving_predictions'],count,count==3)
    runtime=_json(root/'preflight/runtime.json')
    for key in ('elapsed_seconds','native_seconds','reference_seconds','baseline_rss_bytes','peak_rss_bytes'):
        _require(type(runtime.get(key)) in (int,float) and np.isfinite(runtime[key]) and runtime[key]>0,'preflight runtime '+key)
    _require(runtime['peak_rss_bytes']>=runtime['baseline_rss_bytes'] and runtime['memory_measurement_kind']=='sampled_process_rss','preflight memory measurement')
    _require(runtime['work_counts']==dict(filter_member_hours=1806,forecast_hydrologic_steps=960,max_concurrent_candidates=5),'preflight work counts')
    for key in ('filter','forecast','reference_filter','reference_forecast'):
        v=runtime['component_seconds'][key]; _require(type(v) in (int,float) and np.isfinite(v) and v>0,'preflight component time')
    return dict(maxima=maxima,filtering_scope='129 prefix hours only; no independent formal filter replay')


def _saved_log_arithmetic(raw, method, count, config):
    prefix = method+'__reference__'
    _raw_schema(raw,{prefix+'prior_probabilities':((129,count),'float64'),prefix+'log_normalization_mass':((129,),'float64')})
    prior, logs = raw[prefix+'prior_probabilities'], raw[prefix+'log_likelihoods']
    posterior, masses = raw[prefix+'probabilities'], raw[prefix+'log_normalization_mass']
    _require(np.isfinite(prior).all() and (prior>0).all() and np.isfinite(logs).all() and np.isfinite(masses).all(), 'saved log reference finite/positive')
    for side in ('native','reference'):
        p = raw[method+'__'+side+'__probabilities']
        _require(np.isfinite(p).all() and (p>=0).all(), 'saved posterior invalid')
        _close(p.sum(axis=1), np.ones(129), 1e-12, 'saved posterior normalization')
    _close(prior.sum(axis=1), np.ones(129), 1e-12, 'saved prior normalization')
    previous = np.vstack([np.full(count,1/count), posterior[:-1]])
    if method.endswith('no_cross_parameter_interaction'):
        _require((previous>0).all(), 'saved reference zero state-interaction-group mass')
    _close(prior, previous @ _matrix(count), 1e-12, 'saved transition prior')
    expected_mass = np.logaddexp.reduce(logs+np.log(prior),axis=1)
    _close(masses, expected_mass, config['preflight']['log_likelihood_absolute_tolerance'], 'saved log normalization mass')
    _close(posterior, np.exp(logs+np.log(prior)-expected_mass[:,None]), config['preflight']['probability_absolute_tolerance'], 'saved log posterior')
    _same(raw[prefix+'likelihoods'], np.exp(logs), 'saved diagnostic likelihood identity')
    _same(raw[prefix+'normalization_mass'], np.exp(masses), 'saved diagnostic mass identity')


def _comparison_tables(windows,assessments,leads):
    comparisons=[]; thresholds=[]
    for window in windows:
        if window['months']!=3: continue
        short=assessments[_key(window)]; long=assessments[f"{window['name']}__24"]
        for period in ('full','first_30_days'):
            for form in FORMS:
                references=[('24_month_single',long[0]),('24_month_three_noise',long[1]),
                    ('3_month_prespecified_single',short[0]),('3_month_three_noise',short[5]),('3_month_no_cross_interaction',short[7])]
                for item in short:
                    values=item['metrics'][period][form]['rmse']; persistence=item['metrics'][period]['persistence']['rmse']
                    for reference_name,reference_arm in references:
                        ref=reference_arm['metrics'][period][form]['rmse']; ratios=[_ratio(a,b) for a,b in zip(values,ref)]
                        comparisons.append(dict(window=window['name'],period=period,form=form,method=item['name'],reference=reference_name,
                            leads=leads,rmse=values,reference_rmse=ref,ratios=ratios,
                            relative_error_change_percent=[_percent(r) for r in ratios],
                            ratio_unavailable_reasons=[None if r is not None else 'unavailable or unrepresentable ratio or nonpositive reference' for r in ratios],
                            percent_unavailable_reasons=[None if _percent(r) is not None else 'unavailable or unrepresentable percent change' for r in ratios],
                            mean_four_lead_ratio=None if any(r is None for r in ratios) else _finite_arithmetic(lambda: np.mean(ratios)),
                            mean_ratio_unavailable_reason=None if all(r is not None for r in ratios) and _finite_arithmetic(lambda: np.mean(ratios)) is not None else 'unavailable or unrepresentable mean ratio'))
                    ref=long[0]['metrics'][period][form]['rmse']
                    for column,lead in enumerate(leads):
                        thresholds.append(dict(window=window['name'],period=period,form=form,method=item['name'],lead=lead,
                            primary_lead=lead in (48,120),**_threshold(values[column],ref[column],persistence[column])))
                # All five single members are shown; the minimum is explicitly retrospective.
                best=[]
                for column in range(len(leads)):
                    candidates=[(item['metrics'][period][form]['rmse'][column],item['name']) for item in short[:5]
                        if item['metrics'][period][form]['rmse'][column] is not None]
                    best.append(min(candidates) if candidates else None)
                comparisons.append(dict(window=window['name'],period=period,form=form,
                    diagnostic='retrospective_best_of_five_single_models_only',leads=leads,best=best))
    counts=[]
    methods=sorted({row['method'] for row in thresholds})
    for method in methods:
        for period in ('full','first_30_days'):
            for form in FORMS:
                rows=[r for r in thresholds if r['method']==method and r['period']==period and r['form']==form and r['primary_lead']]
                passed=sum(all(r['passed'] for r in rows if r['window']==w['name']) for w in windows if w['months']==3)
                ratios=[r['reference_ratio'] for r in rows]
                counts.append(dict(method=method,period=period,form=form,passed_windows=passed,total_windows=3,
                    maximum_primary_lead_reference_ratio=None if any(v is None for v in ratios) else max(ratios)))
    return dict(comparisons=comparisons,thresholds=thresholds,window_counts=counts)


def _original_inputs(root,inputs):
    """Check current bounded source values, without claiming historical byte identity."""
    reference=_reference_modules(root)
    loader=importlib.import_module(reference[0].__package__+'.data_loader')
    path=Path(root)/'forecast/data/PEQ_Regge_hour.txt'
    if not path.is_file(): path=Path(root)/'for_submit/forecast/data/PEQ_Regge_hour.txt'
    before=_hash(path)
    raw=loader.load_peq_data(str(path),1999010101,2004123123)
    _require(not raw.empty and np.isfinite(raw.to_numpy(dtype=float)).all(),'original nonfinite raw input')
    cumulative,p,et,q=loader.load_and_preprocess(str(path),1999010101,2004123123)
    original_dates=cumulative.output_date[:-1].astype('datetime64[s]').astype('datetime64[h]')
    _same(inputs['timestamps'].astype('datetime64[h]'),original_dates,'original source timestamps')
    _same(inputs['forcing'],np.stack([p,et],axis=-1),'original source forcing')
    _same(inputs['observations'],q,'original source observations')
    _require(before==_hash(path),'original data changed during audit read')
    return dict(path=str(path),audit_time_sha256=before,numeric_identity_checked=True,
        pre_run_raw_container_byte_identity='unavailable: runner saved bounded inputs but no pre-run container hash')


def audit_short_record_run(run_dir):
    """Read artifacts, independently audit and return JSON-compatible unrounded tables.

    Existing audit.json does not affect validation. Any rejected evidence raises
    AuditError (missing/malformed files remain explicit engineering exceptions).
    """
    root=Path(run_dir).resolve(); manifest=_manifest(root); receipt=_json(root/'receipt.json')
    _formal_receipt(receipt)
    config=_json(root/'config.json'); validate_config(config); validate_fixed_field_provenance(config)
    import torch
    binding=receipt['binding']; runtime=_json(root/'runtime.json')
    for key,value in dict(python=platform.python_version(),numpy=np.__version__,torch=torch.__version__,cpu_threads=1,dtype='float64').items():
        _require(binding.get(key)==value,'current runtime binding: '+key)
    _require(runtime['cpu_threads_required']==1,'runtime required threads')
    observed=runtime.get('execution_threads')
    _require(isinstance(observed,dict) and observed.get('torch_threads')==1 and
        all(pool.get('num_threads')==1 for pool in observed.get('loaded_threadpools',[])), 'observed execution threads')
    for key in ('python','numpy','torch'): _require(runtime[key]==binding[key],'recorded runtime drift: '+key)
    _source_binding(root,receipt)
    with np.load(root/'inputs.npz',allow_pickle=False) as archive: inputs={key:archive[key] for key in archive.files}
    dates=inputs['timestamps'].astype('datetime64[h]'); weather=inputs['forcing']; flows=inputs['observations']
    expected=np.arange(np.datetime64(config['data_start'],'h'),np.datetime64(config['data_stop'],'h'))
    _same(dates,expected,'full frozen input timeline'); _same(inputs['timestamps'],dates,'subhour timestamps')
    _require(weather.shape==(len(dates),2) and flows.shape==(len(dates),) and np.isfinite(weather).all() and np.isfinite(flows).all(),'full raw inputs')
    original_inputs=_original_inputs(REFERENCE_ROOT,inputs)
    preflight=_json(root/'preflight_binding.json'); receipt_path=Path(preflight['receipt_path'])
    _require(_hash(receipt_path)==preflight['receipt_sha256'],'preflight receipt hash')
    prior=_json(receipt_path); _require(prior['binding']==receipt['binding'],'stale preflight source/config/runtime binding')
    prefix=_preflight_saved(receipt_path.parent,prior,config,dict(inputs,timestamps=dates))
    events=[json.loads(line) for line in (root/'events.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
    windows=config['windows']; _chronology(events,windows)
    selections=_json(root/'all_selections.json'); _require(set(selections)=={_key(w) for w in windows},'six selected windows')
    calibration={}; assessments={}; expected_failures=[]; reference=_reference_modules(REFERENCE_ROOT)
    current=None; failure_events={}; budgets={}
    for event in events:
        if event['event']=='calibration_start': current=event['window']; failure_events[current]=[]
        elif event['event']=='candidate_failure':
            _require(current is not None,'failure event before calibration')
            failure_events[current].append({key:value for key,value in event.items() if key not in ('event','sequence','utc')})
        elif event['event']=='search_budget':
            _require(current not in budgets,'duplicate budget event')
            budgets[current]={key:value for key,value in event.items() if key not in ('event','sequence','utc')}
    _require(set(budgets)==set(selections),'missing budget event')
    for window in windows:
        key=_key(window); folder=root/'calibration'/key
        result=_json(folder/'result.json')
        _require(result['failures']==failure_events[key],'candidate failure records differ from event evidence')
        _frozen_budget(budgets[key])
        with np.load(folder/'raw.npz',allow_pickle=False) as raw:
            calibration[key]=_calibration_audit(raw,result,config,window,dates,weather,flows)
        _require(selections[key]==calibration[key]['selected'],'all selections differ from independent raw ranking')
        arms=_expected_arms(calibration[key]['selected'],window['months']==3); assessments[key]=[]
        folder=root/'assessment'/key; summaries=_json(folder/'metadata.json')['arm_summaries']
        _require(len(summaries)==len(arms),'assessment arm count')
        for rank,arm in enumerate(arms):
            stem=folder/'arms'/f"{rank:02d}__{arm['name']}__complete"
            metadata=_json(stem.with_suffix('.json')); _require(metadata==summaries[rank],'arm summary differs from immediate evidence')
            expected_failures.extend(dict(window=key,arm=arm['name'],checkpoint=False,**failure) for failure in metadata['failures'])
            with np.load(stem.with_suffix('.npz'),allow_pickle=False) as raw:
                assessments[key].append(_assessment_audit(raw,metadata,arm,window,config,dates,weather,flows,reference))
        with np.load(folder/'arrays.npz',allow_pickle=False) as shared:
            start=int(np.searchsorted(dates,np.datetime64(window['assessment_start'],'h'))); stop=int(np.searchsorted(dates,np.datetime64(window['assessment_stop'],'h')))
            origins=_origins(dates,start,stop,120); targets=origins[:,None]+np.arange(1,121)[None]
            _same(shared['origin_indices'],origins,'shared assessment origins'); _same(shared['target_observations'],flows[targets],'shared assessment targets')
            _same(shared['persistence_predictions'],np.broadcast_to(flows[origins,None],targets.shape),'shared persistence')
    actual_failures=[json.loads(line) for line in (root/'failures.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
    _require(actual_failures==expected_failures,'whole assessment failure log differs from saved arm evidence')
    report=dict(schema='regge_short_record_independent_audit_v01',passed=True,run_dir=str(root),
        calibration=calibration,assessments=assessments,preflight=prefix,original_inputs=original_inputs,
        **_comparison_tables(windows,assessments,config['leads']),
        limits=['Development retrospective evaluation using observed future precipitation and potential evapotranspiration.',
            'Overlapping windows are not independent statistical samples.',
            'No independent replay of the complete formal filtering history; origin states only have short-prefix fidelity evidence.',
            'Full forecast reconstruction validates propagation from saved global states, not all filtering origins.',
            'Finite-budget staged selection is not global optimality; thresholds are proposed research criteria.'])
    _require(_manifest(root)==manifest,'artifacts changed during independent audit')
    json.dumps(report,allow_nan=False)
    return report


def _formal_receipt(receipt):
    _require(receipt.get('schema')=='regge_short_record_receipt_v01' and receipt.get('status')=='complete' and
        receipt.get('mode')=='formal' and receipt.get('passed') is True and receipt.get('test_only') is False and
        receipt.get('scientific_binding_eligible') is True,'formal receipt failed/stale/test-only')


def _frozen_budget(budget):
    _require(budget==dict(hydrologic_candidates=2048,shortlisted_parameters=16,noises_per_parameter=128,joint_candidates=2048),
             'frozen finite search budget')
